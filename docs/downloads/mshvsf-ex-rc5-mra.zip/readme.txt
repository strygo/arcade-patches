Marvel Super Heroes vs. Street Fighter EX · Enhanced version
============================================================

Version:  rc5 (2026-11-03)
Target:   MAME set 'mshvsfj' (Marvel Super Heroes vs. Street Fighter (Japan 970707))
Hardware: Capcom CPS-2
Patch by: Steve Gordon (https://x.com/strygo)
Website:  https://arcadepatches.com/mshvsf-ex/

ABOUT THIS PROJECT

Marvel Super Heroes vs. Street Fighter kept a lot from you. Outside Japan
there was no Norimaro. Nowhere could you play as Cyber-Akuma or Apocalypse, or
put the same fighter on a team twice. The console ports later added extra
colors and more speeds, but only at home.

EX gives the arcade game all of it. Norimaro is on the select screen in both
builds, with his own ending. Hold Start on any fighter for two seconds and
their hidden version appears, no codes needed, though the old codes still
work. Any two fighters make a team. Cyber-Akuma and Apocalypse are playable
too, each with a spot on the select screen. Every fighter gets the Saturn
version's two extra colors, on the HP and HK buttons, and the service menu
goes from three speeds to eight.

Console mode gives the game a home-style title menu: Arcade, Versus against a
friend or the computer, Training, and Options with a time limit setting. The
MiSTer MRAs start in Console mode; MAME and HBMAME start in Arcade mode, and
GAME MODE in the service menu's EX page switches between them.

The fighting itself is untouched: no changes to moves, damage, hitboxes or the
computer. The USA build also gets a new translation, straight from the
Japanese: sixteen win quotes per fighter instead of eight, and every ending
retold. It comes in two builds, USA and Japan, both with Free Play, and runs
in MAME, HBMAME and on MiSTer.

This is a release candidate.

WHAT'S CHANGED

  - Norimaro in both builds, with his own ending
  - Cyber-Akuma and Apocalypse playable, each with a spot on the select
    screen. Their special moves work on the Easy control setting too
  - Hidden characters with a two-second Start hold; the old codes still work
  - Any team, including the same fighter twice, in a different color (one
    Apocalypse per match, so his stage stays intact)
  - Every ending in both languages, including Mech-Zangief's, Shadow's and
    Dark Sakura's
  - Apocalypse and Cyber-Akuma have character-specific ending artwork, layered
    over the animated arcade burst
  - A new English translation from the Japanese: sixteen win quotes per
    fighter instead of eight, and all seventeen standard endings
  - U.S. Agent, Mephisto and Shadow get their names in the fight HUD, which
    the original game leaves blank
  - M. Bison's Hyper Combo is Knee Press Nightmare in every region, the name
    Capcom has used since Alpha 3
  - Two extra colors per fighter from the Saturn version: pick your fighter
    with HP or HK; the selected color appears in portraits, intros, special
    moves and hypers
  - Versus names in the arcade lettering, centered, with two lines when long
    names would crowd the middle; selected names stay visible above the
    fighters
  - Eight game speeds instead of three
  - Console mode with Arcade, Versus, Training and Options on the title
    screen; MiSTer starts in Console mode, and GAME MODE in the service menu's
    EX page selects Console or Arcade
  - Versus: against a friend or the computer, with a stage choice, then
    Rematch or Change Characters with the wins kept
  - Training: set the computer's action and guard, both gauges, speed and
    stage; restart or change characters from the pause menu
  - Options: difficulty, speed, damage, sound, and a time limit of 25, 50, 75
    or 99 seconds, or none
  - Pause any Console fight with Coin, or by holding Start
  - USA and Japan builds, both with Free Play
  - Gameplay untouched

MISTER SETUP

1. Copy the _Arcade/ folder from this download to the root of your MiSTer SD
   card (the MRAs land in _Arcade/_Arcade Patches/_Enhanced Versions/), or just the MRAs you want:
       "Marvel Super Heroes Vs. Street Fighter EX (USA).mra"
       "_Japan/Marvel Super Heroes Vs. Street Fighter EX (Japan).mra"
2. Have the stock, unmodified romset at games/mame/mshvsfj.zip
   (split sets also need the parent and QSound ZIPs named in the MRA).
3. You need Jotego's jtcps2 core; the standard MiSTer downloader /
   update_all installs it automatically.

Each MRA references your original romset and applies the patch in
memory while the game loads. Nothing on your SD card is modified. Each
build keeps its own settings and saves under its own setname:
    USA              mshvsfex
    Japan            mshvsfej

LEGAL

This is a free, unofficial fan patch. It is not affiliated with or endorsed
by Capcom. All game titles, characters, and artwork remain the property of
their respective owners. You must own the game to use this patch. Do not
sell this patch or distribute it applied to a ROM image.
