# Media tools

The builder fetches the pinned FFmpeg and ffprobe pair when a conversion first
needs them. The archive and every installed file are checked against the kit's
trusted SHA-256 manifest. Subsequent runs reuse the verified cache.

Use `--tools-cache DIRECTORY` to choose the cache. To work without internet,
provide `--tools-bundle cpsplus-tools-v3-offline.zip --offline`. Use these options on the kit’s build command. The equivalent environment variables are
`CPSPLUS_SWITCH_TOOLS_CACHE`, `CPSPLUS_SWITCH_TOOLS_BUNDLE` and
`CPSPLUS_SWITCH_TOOLS_OFFLINE=1`; the names are shared with Switch extraction
helpers so one cache and offline bundle work across kits.

Advanced users can select their own executables with `CPSPLUS_FFMPEG` and
`CPSPLUS_FFPROBE`. Explicit overrides must name working executables. They are
outside the pinned helper qualification; builds still enforce output hashes
where the pack declares them.

Helpers are available for macOS 11+ (Apple Silicon and Intel), Ubuntu 24.04+
(ARM64 and x86-64), Windows x64, and Windows 11 ARM through x64 emulation.
The FFmpeg build includes built-in codecs, formats and filters, with optional
external libraries, networking, GPL and nonfree features disabled. Both tools
are LGPL 2.1 or later. Each host archive includes licenses, the source identity,
configuration and a standalone producer recipe. Corresponding unmodified
source is included in the offline bundle and provided beside the binaries at:
https://github.com/strygo/arcade-patches/releases/tag/ffmpeg-helpers-v1

The selected MIDI packs also fetch pinned extractors and renderers. Optional
CHD and `.7z` inputs retain installed chdman/7-Zip support and fetch a pinned
fallback when needed. ZIP inputs use Python directly. No recipient compiler,
Git or CMake is required for these helpers.

The optional helper archives retain separate licenses: GPL/LGPL components
and the SC-55 renderer's original MAME noncommercial license. Complete source
companions are provided separately as `optional-helpers-v1-sources.zip`.
Source and binary release assets are prepared for review and remain unpublished.
Use the review offline bundle until publication is authorized.

Python, the kit's declared Python packages, owned games, keys and instrument
firmware remain required. Packs that record a game's sound test still need
MAME and the corresponding BIOS. No game data or firmware is downloaded.

Explicit optional helper overrides use `CPSPLUS_X68K_SPS_DEC`,
`CPSPLUS_M2SEQ22MID`, `CPSPLUS_SC55`, `CPSPLUS_MT32`, `CPSPLUS_ADLMIDI`,
`CPSPLUS_CHDMAN` and `CPSPLUS_SEVENZIP`.
