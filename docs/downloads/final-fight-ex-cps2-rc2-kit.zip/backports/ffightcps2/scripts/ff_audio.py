#!/usr/bin/env python3
"""Convert Final Fight's CPS1 sound into a QSound driver 1.71 image.

The audio pilot (AUDIO_PILOT.md): scores are rewritten op by op (the two
drivers share one bytecode family), YM2151 voices are rendered through ymfm
into 8-bit samples, OKI phrases become one-shot samples, and OKI triggers
become effect scores. Every recipe parameter is a constant here and goes in
the receipt. Runs under the repository venv (numpy, scipy):

    CAPCOM_WORK_ROOT=/Volumes/CapcomScratch venv/bin/python ff_audio.py --work DIR
"""
from __future__ import annotations

import argparse
from fractions import Fraction
import hashlib
import json
import math
from pathlib import Path
import struct

try:                                    # the renders and their analysis; the public kit's kit mode
    import numpy as np                  #   (build's products) runs without them
    from scipy.signal import firwin, resample_poly
except ImportError:
    np = firwin = resample_poly = None

import build_m1_spike as spike
import ff_sound as fs
import qsound171 as q
import ym_voice as yv

PILOT_MUSIC = (0x40, 0x50)
CATALOG_COUNT = 96                 # Final Fight wraps commands modulo 96
ZONE_SEMITONES = 3                 # FM notes within a zone share one render
QSOUND_RATE = Fraction(60_000_000, 2496)
FM_COARSE = 60                     # pitch table index of word 4096 (the QSound rate)
OKI_RATE = Fraction(1_000_000, 132)
# OKI phrases are resampled to the fastest rate whose sample fits a half-bank,
# as (rate, pitch table index playing it at its own speed): the QSound rate,
# half of it, the OKI's own rate (index 40, 7,559 Hz against 7,576 Hz), then
# the pitch table's semitone steps below it for the longest phrases. QSound
# steps through samples without interpolation, so a sample slower than the
# QSound rate carries images of itself, from the lower its rate the lower.
OKI_FAST = ((QSOUND_RATE, 60), (QSOUND_RATE / 2, 48))   # words 4096 and 2048
OKI_NATIVE = 40
OKI_LOWEST = 24
OKI_OCTAVE, OKI_KEY = 3, 12        # every OKI note plays as note 48
OKI_NOTE = 36 + OKI_KEY
UPDATE_HZ = {"cps1": Fraction(3_579_545, 64 * 448 * 2), "qsound": Fraction(125, 2)}
TEMPO_CELLS = range(0xE0, 0xFF)    # music and scored-effect tempo cells
TRIGGER_TEMPO_CELLS = range(0x80, 0xE0)   # one per OKI trigger length (no SFA3 score remains)
DEFAULT_TEMPO = 0x199              # driver 2.00's increment at song start
SLOW_TEMPO = 128                   # looping triggers: a tied note holds at any tempo
TRIGGER_TICKS = 192                # an OKI trigger's note: duration index 7
MASTER_VOLUME = 0x7F               # op 1A and the effects' master (table 0x2F92: 0 dB)
# 13 October 2026: normalized to CPS1's level, which the masters at
# SFA3's 0x6E left 4.2 dB under (stage 1 against CPS1); the masters give
# 1.24 dB of it and the channel volume table, scaled, the rest.
VOLUME_GAIN_DB = 2.96
PAN = q.PAN_DRY_CENTER             # op 18: the CPS1 board is mono; no spatial filter

# Mix: MAME's CPS1 board sums both YM2151 outputs at 0.35 and the OKI at
# 0.30 into one speaker; ymfm writes 16-bit, the OKI 12-bit (/2048).
YM_ROUTE, OKI_ROUTE = 0.35, 0.30
OKI_VOLUME = [0x20, 0x16, 0x10, 0x0B, 0x08, 0x06, 0x04, 0x03, 0x02]   # /0x20, MSM6295
HEADROOM = 0.98
# Samples are scaled by SAMPLE_SCALE, the factor the normalization to CPS1
# (VOLUME_GAIN_DB, 13 October) was measured with, or less where the loudest
# sample would clip: the level must not move with the catalog's loudest
# render (one at the QSound rate peaks lower than at half rate, 15 October).
SAMPLE_SCALE = 2.032646

# FM render recipe.
RENDER_SECONDS = 4.0               # key held: long enough to see the timbre settle
RELEASE_SECONDS = 1.0              # after key-off, for the release fit
# 1.71's envelope ramps are linear in level; the YM2151's envelope falls a
# fixed number of dB a second. Each ramp is as long as fits that fall best
# in dB down to RAMP_FIT_DB under its start, where a mix hides what is left
# (ramp_seconds). For a release that is 2.75 half-level times (h): mean
# error 1.6 dB, at most 5.1, where a ramp at half level with the render, and
# so silent at 2h, erred 2.5 and 9.2; the bonus round's bass rang on into
# its rests on CPS1 and stopped short here (15 October). A held
# note's decay starts from the key-on, but the sample carries the render's
# own decay up to its loop: the ramp follows a level that holds until the
# loop and falls from there. (Fitted from the key-on, the ending's voice 12
# fell silent in 0.3 s where CPS1's fades for 2 s.) A deeper fit holds the
# note louder early.
RAMP_FIT_DB = 20.0
ENVELOPE_HOP = 0.01                # seconds per level frame
SETTLE_DB_PER_S = 4.0              # the loop starts once the level moves slower
SETTLE_SPAN = 0.15                 # seconds of level fitted for that slope
SETTLE_LATEST = 1.0
UNSETTLED_LOOP_AT = 0.15           # a steadily decaying voice loops here
DECAYING_DB = -30.0                # level at 1.2 s below the peak: one-shot
ONESHOT_FLOOR_DB = -60.0           # a one-shot ends where it falls this far
ONESHOT_MAX = q.HALF_BANK - 4      # samples
LOOP_SECONDS = (0.08, 0.30)        # loop length
SEAM_CLEAN = 0.05                  # seam error (relative energy) a short fade hides
NOISY_LOOP_SECONDS = (0.30, 0.60)  # loop length where the seam is not clean
LOOP_SEARCH_SECONDS = 0.20         # loop starts tried after settling
LOOP_LENGTHS = 12                  # whole-period lengths tried
CROSSFADE = 256                    # samples
DECAY_FLOOR_DB_PER_S = 0.5         # slower held-note decay is left out
HELD_SLOPE_RANGE = 40.0            # dB of a held note's decay its slope is fitted over
# A loop also waits for the timbre: until every band holding at least
# TIMBRE_FLOOR_DB of the energy stays within TIMBRE_DB of its final share (a
# feedback modulator decaying slowly keeps changing it for seconds). A render
# that then outgrows a half-bank at the QSound rate loops as late as a loop
# found fits one if less than LATE_TOP_DB of its energy lies above LATE_EDGE
# (the slowly evolving voices half the rate used to carry, which keep their
# room); a brighter one loops where the worst case would fit, as before.
TIMBRE_BANDS = ((0, 250), (250, 1000), (1000, 2000), (2000, 4000), (4000, 8000), (8000, 12000))
TIMBRE_DB = 3.0
TIMBRE_FLOOR_DB = -30.0
LATE_TOP_DB = -25.0
LATE_EDGE = 5500                   # Hz
LATE_STEP = 0.05                   # seconds: a loop too late to fit a half-bank tries
                                   #   this much earlier, down to the worst case's start
ENVELOPE_HZ = 62.5                 # 1.71 updates envelopes once per tick
HALF_LEVEL_DB = 20 * math.log10(2)
# SFA3's QSound jingle (QSOUND_LOGO.md): sfa3u's music command 0x2F with the
# four instruments it plays, copied from the user's set (checked by SHA-256)
# as our command JINGLE (13 October: Final Fight's unused 0x5C).
JINGLE = 0x5C
# The opening song (cue 0x52) runs 5400 ticks, about 50.6 s: Capcom timed its
# last chord to the arcade title. Longer scenes take more of its own mid-song
# repeat (ffightcd build/fmloop.py, as CPS1 EX does): ``opening`` in build()
# gives (rounds, tail) per use. "arcade" replaces cue 0x52 itself (the English
# restoration's intro, whose captions type at the Japanese speed); "cd" adds
# the SEGA CD opening's song at CD_OPENING, Final Fight's unused 0x5B, which
# the layer's EX alias $76 plays (CPS1 EX loops 0x52 the same way for it:
# rom.py fm_open_loop, US (12, 1), Japan (12, 0)).
CD_OPENING = fs.CD_OPENING
# The SEGA CD ending's song, in Japan's and the restoration's EX: cue 0x54
# with more passes of its closing vamp (ff_sound.ending_vamp), at CD_ENDING;
# ``opening`` in build() gives "ending": passes.
CD_ENDING = fs.CD_ENDING
FMLOOP = Path(__file__).resolve().parents[2] / "ffightcd" / "build"
SFA3_JINGLE = 0x2F
SFA3_SAMPLES = (("sz3.11m", 0x1C89EED1), ("sz3.12m", 0xF392B13A))
JINGLE_SCORE = (497, "5c342c1f9a3f8304f0a25487d03c13e4b4a185b53a20fa8e0bf5ef0073fee271")
JINGLE_SAMPLES = {0x57: "b446d9ec9b5ae047d9ff85831596f1b486d05e4cb5c180de2c612ca8b544c265",
                  0x64: "6415faff3a9d179670b23dcc20b38f0d627794c9353e5a1be475c4748a22547e",
                  0x67: "e87294f8cbf9ebf9d3a9a4c1a153ffb3427e69d3609a773b475e5dfd982abcd4",
                  0x71: "0ab0bcc9cd24e04e4516f5d745d367b844975ce8d36b87e102e19ee54ee42b69"}
JINGLE_TEMPO_CELL = (0x5A, 0x128)    # left as SFA3 has it: our cells are 0x80-0xFE
# Re-keys. Driver 2.00 keys a note off at its gate and the next one on when
# its duration ends; the YM2151 attacks from wherever the release has left
# the envelope, a render from silence. A note keyed while its channel still
# sounds therefore enters its render warm, at an upward zero crossing where
# the cold attack reaches one of WARM_ENTRIES_DB below its peak: the entry
# nearest the level the envelope had at the key-on (the released note's level
# at its key-off, less its rendered release over the gap). Under
# WARM_FLOOR_DB the note starts cold.
WARM_ENTRIES_DB = (3.0, 12.0, 24.0, 40.0)
WARM_FLOOR_DB = 52.0
WARM_LEAD = 0.010                  # seconds: an attack this quick needs no warm entry


def pitch_word(flat, coarse, frac=0):
    shift = flat[0x2145 + coarse]
    relative = coarse - flat[0x21B1 + shift]
    return (struct.unpack_from("<H", flat, 0x21BA + 2 * coarse)[0]
            + (flat[0x2292 + relative * 256 + frac] << shift)) & 0xFFFF


def root_for(note, coarse):
    """Descriptor root that plays note at the pitch table's coarse index."""
    return note - 1 + 0x3C - coarse


# ---------------------------------------------------------------- scores

def global_transpose(song):
    values = {i.args[0] for c in song.channels if c for i in c.code.values() if i.op == 0x0A}
    if len(values) > 1:
        raise ValueError(f"cue {song.cue:02x}: several global transposes {values}")
    t = values.pop() if values else 0
    return t if t < 128 else t - 256


def channel_fine(channel):
    """A channel's fine tune (op 0C, 1/256 semitone) when it holds one value
    throughout: driver 2.00 plays it through the YM2151's key fraction, which
    1.71's pitch table does not reproduce in small steps (-6 plays as about
    -35), so renders carry it and the op is dropped. A changing bend would
    need the op; Final Fight has none."""
    values = {i.args[0] - 256 if i.args[0] > 127 else i.args[0] for i in channel.code.values() if i.op == 0x0C}
    if len(values) > 1:
        raise ValueError(f"channel {channel.index}: a changing fine tune {sorted(values)}")
    return values.pop() if values else 0


def keyed_notes(z80, song):
    """Each FM channel's keyed notes over one cycle, as (channel, site, voice,
    note, top, ticks, rekeys), top being the highest note of the tied group
    the note starts and ticks its length; and, per tied site, the sites of
    the notes it continues. rekeys lists each way the note follows a keyed-off
    group in its channel, as (release ticks before it, that group's index in
    the returned list, ticks from its key-on to its key-off): the YM2151
    attacks from wherever that release has left the envelope."""
    transpose = global_transpose(song) & 0xFF
    keyed, tied = [], {}
    for channel in song.channels:
        if not channel or channel.index >= 8:
            continue
        events = fs.play(z80, channel, transpose)
        fine = channel_fine(channel)
        groups, i = [], 0
        while i < len(events):
            if events[i].tied or events[i].voice is None:
                raise ValueError(f"cue {song.cue:02x} channel {channel.index}: note at "
                                 f"{events[i].address:04x} has no keyed start or voice")
            j = i + 1
            while j < len(events) and events[j].tied:
                tied.setdefault((channel.index, events[j].address), set()).add(events[i].address)
                j += 1
            groups.append((i, j))
            i = j

        base = len(keyed)

        def released(n, rest):
            i, j = groups[n]
            last = events[j - 1]
            if last.gate is None:
                return None
            hold = sum(e.ticks for e in events[i:j - 1]) + last.gate
            return (last.ticks - last.gate + rest, base + n, hold)
        for n, (i, j) in enumerate(groups):
            rekeys = []
            if n and events[i].after_note:
                rekeys.append(released(n - 1, events[i].rest))
            if events.wrap and events.wrap[0] == i:      # the cycle comes back to this note
                rekeys.append(released(len(groups) - 1, events.wrap[1]))
            keyed.append((channel.index, events[i].address, (events[i].voice, fine), events[i].note,
                          max(e.note for e in events[i:j]), sum(e.ticks for e in events[i:j]),
                          [r for r in rekeys if r is not None]))
    return keyed, tied


def zone_plan(z80, songs):
    """The program slot of every keyed FM note site, keyed (cue, channel,
    site), and the note each (voice, slot) is rendered at: the highest note
    any pass needs there, so playback only ever shifts down. A site keyed on
    one pass and tied on another shares the slot of the notes it continues,
    which leaves its program change a no-op on the tied pass."""
    visits, links = [], {}
    for song in songs:
        keyed, tied = keyed_notes(z80, song)
        # held seconds at the song's slowest tempo (driver 2.00 at 62.42 Hz)
        slowest = min({DEFAULT_TEMPO} | {fs.word(i.args, 0) for c in song.channels if c
                                         for i in c.code.values() if i.op == 0x05})
        tick_seconds = 256 / (slowest * float(UPDATE_HZ["cps1"]))
        visits += [(song.cue,) + v[:5] + (v[5] * tick_seconds,) for v in keyed]
        for (channel, site), starts in tied.items():
            links[(song.cue, channel, site)] = {(song.cue, channel, s) for s in starts}
    sites = {v[:3] for v in visits}
    parent = {k: k for k in sites}

    def root(k):
        while parent[k] != k:
            parent[k] = parent[parent[k]]
            k = parent[k]
        return k
    shared = sorted(k for k in links if k in sites)
    for site in shared:
        for start in links[site]:
            parent[root(start)] = root(site)
    top = {}
    for v in visits:
        r = root(v[:3])
        top[r] = max(top.get(r, 0), v[5])
    slot = {k: (top[root(k)] - 1) // ZONE_SEMITONES for k in sites}
    render, held = {}, {}
    for cue, channel, site, voice, note, group_top, seconds in visits:
        key = (voice, slot[(cue, channel, site)])
        render[key] = max(render.get(key, 0), group_top)
        held[key] = max(held.get(key, 0.0), seconds)
    shifts = {}
    for cue, channel, site, voice, note, _, _ in visits:
        d = render[(voice, slot[(cue, channel, site)])] - note
        shifts[d] = shifts.get(d, 0) + 1
    return slot, render, held, {"keyed_notes": len(visits), "sites": len(sites),
                          "shared_tie_sites": [f"{c:02x}/{ch}/{a:04x}" for c, ch, a in shared],
                          "shift_semitones": dict(sorted(shifts.items()))}, {k: root(k) for k in sites}


def fm_volume(image, v):
    attenuation_db = 0.75 * (0x7F - v)
    return image.volume_index(10 ** (-attenuation_db / 20))


def oki_volume(image, attenuation, gain_db=0.0):
    return image.volume_index(OKI_VOLUME[min(attenuation, 8)] / 0x20 * 10 ** (gain_db / 20))


def rel(at, size, target):
    offset = target - (at + size)
    if not -0x8000 <= offset < 0x8000:
        raise ValueError("branch out of range")
    return struct.pack(">h", offset)


def translate(song, image, tempo_cell, fm_banks, programs, oki_programs, oki_bank, effect=False):
    """One song's channels in 1.71 bytecode. Each channel gets its own copy
    of the code it reaches, in address order, branches relocated. FM voice n
    becomes a bank (op 1F) and every keyed FM note is preceded by its
    program (op 08: its zone, or its zone's warm entry); OKI phrases are
    programs of the OKI bank."""
    transpose = global_transpose(song)
    first = min(c.index for c in song.channels if c)
    if effect:
        tempos = {fs.word(i.args, 0) for c in song.channels if c for i in c.code.values() if i.op == 0x05}
        if len(tempos) > 1:
            raise ValueError(f"cue {song.cue:02x}: an effect with several tempos {tempos}")
        effect_tempo = tempos.pop() if tempos else DEFAULT_TEMPO
    body, entries = bytearray(), [None] * 16
    for channel in song.channels:
        if not channel:
            continue
        is_oki = channel.index >= 8
        fine = 0 if is_oki else channel_fine(channel)

        def encode(instruction, at=0, target=0):
            op, args = instruction.op, instruction.args
            if op >= 0x20:
                if is_oki:
                    return bytes([(op & 0xE0) | OKI_KEY if op & 0x1F else op])
                program = programs.get((song.cue, channel.index, instruction.address))
                return (b"" if program is None else bytes([8, program])) + bytes([op])
            if op == 0x05:
                return bytes([5, tempo_cell[fs.word(args, 0)]])
            if op == 0x06 and not is_oki:
                return bytes([6, args[0] or 1])     # see the prefix
            if op == 0x07:
                return bytes([7, oki_volume(image, 8 - args[0]) if is_oki else fm_volume(image, args[0])])
            if op == 0x08:
                if is_oki:      # an empty phrase entry plays nothing on the OKI
                    return bytes([8, oki_programs.get(args[0] & 0x7F, oki_programs["silent"])])
                return bytes([0x1F, fm_banks[(args[0], fine)]])
            if is_oki and op in (0x03, 0x09, 0x0B, 0x0C, 0x0D):
                return b""
            if op == 0x0C:              # carried by the renders (channel_fine)
                return b""
            if is_oki and op == 0x04:
                return bytes([4, args[0] & ~0x08])
            if op == 0x19:
                return b""
            if op == 0x18:
                raise ValueError(f"cue {song.cue:02x}: pan op not yet mapped")
            if 0x0E <= op <= 0x15:
                return bytes([op, args[0]]) + rel(at, 4, target)
            if op == 0x16:
                return bytes([op]) + rel(at, 3, target)
            return bytes([op]) + args

        # Music: the song-wide tempo and master volume are set once, by the
        # first channel, before its own ops (a later channel's default would
        # override its op 05 within the same update). Effects: 1.71 keeps a
        # tempo per effect channel, driver 2.00 one for the effect bank, so
        # every channel starts at the tempo the effect sets. OKI channels take
        # the OKI bank, a fixed octave and the global transpose's cancellation.
        if effect:
            prefix = bytearray([5, tempo_cell[effect_tempo]])
        else:
            prefix = bytearray([0x1A, MASTER_VOLUME, 5, tempo_cell[DEFAULT_TEMPO]] if channel.index == first else [])
        prefix += bytes([0x18, PAN])
        # Gate ratio 0 (driver 2.00's at song start) keys a note off at its
        # first update; 1.71 never keys off a note whose gate is 0. Its
        # durations count 1/256 ticks, so ratio 1 gives a gate under one
        # update's ticks: off at the first update, as on CPS1.
        if not is_oki:
            prefix += bytes([6, 1])
        if is_oki:
            prefix += bytes([0x1F, oki_bank, 9, OKI_OCTAVE, 0x0B, (-transpose) & 0xFF, 4, 0])
        order = sorted(channel.code)
        sizes = {a: len(encode(channel.code[a])) for a in order}
        entries[channel.index] = len(body)
        body += prefix
        layout, cursor = {}, len(body) + 3
        for a in order:
            layout[a] = cursor
            cursor += sizes[a]
        body += b"\x16" + rel(len(body), 3, layout[channel.start])
        for a in order:
            instruction = channel.code[a]
            target = layout[instruction.targets[0]] if instruction.targets else 0
            encoded = encode(instruction, layout[a], target)
            if len(encoded) != sizes[a] or len(body) != layout[a]:
                raise ValueError("encoding size changed between passes")
            body += encoded
    return body, entries


def score(mode, body, entries):
    """Header + body; entries are channel entry offsets within body."""
    header = bytearray(33)
    header[0] = mode
    for i, entry in enumerate(entries):
        if entry is not None:
            struct.pack_into(">H", header, 1 + 2 * i, 33 + entry)
    return bytes(header) + bytes(body)


# ---------------------------------------------------------------- samples

def top_share(x, rate):
    """dB of the render's energy above LATE_EDGE, past its first half second."""
    seg = x[int(0.5 * rate):]
    power = np.abs(np.fft.rfft(seg * np.hanning(len(seg)))) ** 2
    freqs = np.fft.rfftfreq(len(seg), 1 / rate)
    return 10 * math.log10(power[freqs >= LATE_EDGE].sum() / (power.sum() + 1e-12) + 1e-12)


def to_qsound_rate(pcm, source_rate, target=QSOUND_RATE):
    ratio = (target / Fraction(source_rate)).limit_denominator(4096)
    out = resample_poly(np.asarray(pcm, dtype=np.float64), ratio.numerator, ratio.denominator,
                        window=("kaiser", 8.6), padtype="constant")
    error_cents = 1200 * math.log2(float(ratio / (target / Fraction(source_rate))))
    return out, ratio, error_cents


def timbre_settle(x, rate, earliest):
    """Seconds from which the render's band shares stay within TIMBRE_DB of
    their final values (the last half second), for bands above the floor."""
    hop, win = int(0.05 * rate), 2048
    freqs = np.fft.rfftfreq(win, 1 / rate)
    window = np.hanning(win)
    rows = []
    for i in range(0, len(x) - win, hop):
        power = np.abs(np.fft.rfft(x[i:i + win] * window)) ** 2
        rows.append([power[(freqs >= lo) & (freqs < hi)].sum() for lo, hi in TIMBRE_BANDS])
    shares = np.array(rows) / (np.array(rows).sum(axis=1, keepdims=True) + 1e-12)
    final = shares[-int(0.5 * rate / hop):].mean(axis=0)
    bands = 10 * np.log10(final + 1e-12) > TIMBRE_FLOOR_DB
    off = np.abs(10 * np.log10(shares[:, bands] + 1e-12) - 10 * np.log10(final[bands]))
    bad = np.nonzero((off > TIMBRE_DB).any(axis=1))[0]
    return max(earliest, (bad[-1] + 1) * hop / rate if len(bad) else 0.0)


def envelope_db(x, rate):
    """Level in dB per ENVELOPE_HOP frame."""
    hop = int(ENVELOPE_HOP * rate)
    frames = np.asarray(x[:len(x) // hop * hop]).reshape(-1, hop)
    return 20 * np.log10(np.maximum(1e-9, np.sqrt((frames ** 2).mean(axis=1))))


def slope_db(db, first, last):
    """dB per second fitted over frames first..last."""
    t = np.arange(first, last) * ENVELOPE_HOP
    return float(np.polyfit(t, db[first:last], 1)[0])


def held_slope_db(db, first, last):
    """slope_db over the audible part of first..last: until the level falls
    HELD_SLOPE_RANGE under its first frame (past that a render that dies out
    reads as silence, which steepened the fit: the ending's voice 12 read -49
    dB/s where CPS1's note falls about 23)."""
    below = np.nonzero(db[first:last] < db[first] - HELD_SLOPE_RANGE)[0]
    return slope_db(db, first, first + max(int(below[0]), 3) if len(below) else last)


def settle_time(db):
    """Seconds until the level moves slower than SETTLE_DB_PER_S, or None."""
    span = int(SETTLE_SPAN / ENVELOPE_HOP)
    for i in range(int(0.05 / ENVELOPE_HOP), int(SETTLE_LATEST / ENVELOPE_HOP)):
        if abs(slope_db(db, i, i + span)) < SETTLE_DB_PER_S:
            return i * ENVELOPE_HOP
    return None


def loop_points(x, rate, f0, earliest, seconds):
    """A loop of a whole number of periods (give or take a sample, which
    finds the rendered period) starting within LOOP_SEARCH_SECONDS of
    earliest, chosen for the closest match across the seam; None when the
    render ends before any fits."""
    period = rate / f0
    counts = range(max(1, math.ceil(seconds[0] * rate / period)), int(seconds[1] * rate / period) + 1)
    if not counts:
        counts = range(1, 2)
    picks = sorted({counts[round(i * (len(counts) - 1) / max(1, LOOP_LENGTHS - 1))] for i in range(LOOP_LENGTHS)})
    window = 64
    lo = max(window, int(earliest * rate))
    starts = np.arange(lo, lo + int(LOOP_SEARCH_SECONDS * rate), 3)
    offsets = np.arange(-window // 2, window // 2)
    best = None
    for m in picks:
        for length in (round(m * period) - 1, round(m * period), round(m * period) + 1):
            if starts[-1] + length + window >= len(x):
                continue
            a = x[starts[:, None] + offsets]
            b = x[starts[:, None] + length + offsets]
            error = ((a - b) ** 2).sum(axis=1) / ((a ** 2).sum(axis=1) + 1e-12)
            i = int(np.argmin(error))
            if best is None or error[i] < best[0]:
                best = (float(error[i]), int(starts[i]), length, m)
    if best is None:
        return None
    error, start, length, m = best
    cents = 1200 * math.log2(length / (m * period))
    return start, length, cents, error


def ramp_seconds(hold, db_per_s, depth=RAMP_FIT_DB):
    """Length of a linear ramp from full level to zero that best follows, in
    dB down to depth under full, a level holding for hold seconds and then
    falling db_per_s."""
    end = hold + depth / db_per_s
    t = np.linspace(0, end, 512)
    want = np.maximum(-db_per_s * np.maximum(t - hold, 0), -depth)
    best = None
    for length in end * np.geomspace(0.5, 4.0, 400):
        ramp = np.maximum(20 * np.log10(np.maximum(1 - t / length, 1e-9)), -depth)
        error = float(np.abs(ramp - want).mean())
        if best is None or error < best[0]:
            best = (error, float(length))
    return best[1]


def rate_selector(flat, seconds):
    """Index into 1.71's rate table (0x3112) whose linear ramp from full
    level to zero takes the given time at one step per tick."""
    values = struct.unpack_from("<64H", flat, 0x3112)
    return min(range(1, 64), key=lambda i: abs(math.log((65535 / values[i]) / ENVELOPE_HZ / seconds)))


def fm_sample(binary, flat, z80, voice_number, note, fine=0, held=None):
    """One voice at one note (and fine tune, as driver 2.00 adds it: key code
    and key fraction of note * 256 + fine): rendered as the driver plays it,
    resampled to the QSound rate, cut to a one-shot or a loop, with the
    articulation that continues its held-note decay and its release. held is
    the longest the songs hold it (seconds): the loop waits for the timbre
    only that long."""
    raw = bytes.fromhex(fs.voice(z80, voice_number)["raw"])
    pitch = note * 256 + fine
    kc, kf = yv.key_code(z80, pitch >> 8), pitch & 0xFF
    rate, left = yv.render(binary, yv.script(raw, kc, int(RENDER_SECONDS * 55930), 1, kf=kf))
    _, held_release = yv.render(binary, yv.script(raw, kc, int(0.5 * 55930), int(RELEASE_SECONDS * 55930), kf=kf))
    mono = 2 * YM_ROUTE * np.asarray(left, dtype=np.float64) / 32768      # both outputs, mono mix
    x, ratio, resample_cents = to_qsound_rate(mono, rate)
    qrate = float(QSOUND_RATE)
    db = envelope_db(x, qrate)
    peak_db = float(db[:int(0.5 / ENVELOPE_HOP)].max())
    release = half_level_time(np.asarray(held_release, dtype=np.float64), rate, 0.5)
    info = {"voice": voice_number, "note": note, "fine": fine, "key_code": f"{kc:02x}", "key_fraction": kf,
            "resample_ratio": [ratio.numerator, ratio.denominator],
            "resample_error_cents": round(resample_cents, 4), "release_half_seconds": release,
            "held_seconds": None if held is None else round(held, 2)}
    decay, coarse = 0, FM_COARSE
    if db[int(1.2 / ENVELOPE_HOP)] - peak_db < DECAYING_DB:
        below = np.nonzero(db < peak_db + ONESHOT_FLOOR_DB)[0]
        below = below[below > int(0.05 / ENVELOPE_HOP)]
        n = min(len(x), ONESHOT_MAX, int(below[0] * ENVELOPE_HOP * qrate) if len(below) else len(x))
        y = x[:n].copy()
        fade = min(2048, n // 4)
        y[n - fade:] *= np.linspace(1, 0, fade)
        loop = None
        info.update(kind="one-shot", samples=n)
    else:
        settled = settle_time(db)
        earliest = settled if settled is not None else UNSETTLED_LOOP_AT
        timbre = timbre_settle(x, qrate, earliest)
        if held is not None:
            timbre = max(earliest, min(timbre, held))
        f0 = 440 * 2 ** ((yv.midi_note(z80, pitch >> 8) + kf / 256 - 69) / 12)
        latest = ONESHOT_MAX / qrate - LOOP_SEARCH_SECONDS - NOISY_LOOP_SECONDS[1]
        found = None
        # Past latest even the worst case (a noisy loop found late) cannot
        # fit a half-bank, but the loop actually found often does: the loop
        # waits for the timbre. Failing that, a slowly evolving voice's loop
        # waits as long as a loop found fits, at the QSound rate. (These were
        # made at half the rate, which fitted twice as long, but 1.71 plays
        # samples without interpolation, so half the rate imaged every
        # harmonic around 12 kHz: a bass's 0.6-1.3 kHz rang at 10.7-12.6 kHz,
        # about -30 dB, audible in the bonus round, 15 October.)
        wait = timbre if timbre <= latest else min(timbre, ONESHOT_MAX / qrate - LOOP_SECONDS[0])
        if wait > latest:
            found = find_loop(x, qrate, f0, wait)
            if found is not None and found[0] + found[1] > ONESHOT_MAX:
                found = None
            if found is None and top_share(x, qrate) >= LATE_TOP_DB:
                wait = latest                   # bright: where the worst case fits
            wait = round(wait - LATE_STEP, 3)
        while found is None and wait > latest:
            found = find_loop(x, qrate, f0, wait)
            if found is not None and found[0] + found[1] > ONESHOT_MAX:
                found = None
            wait = round(wait - LATE_STEP, 3)
        if found is None:
            found = find_loop(x, qrate, f0, min(timbre, latest))
        start, length, loop_cents, seam, noisy = found
        if noisy:
            fade = min(length // 2, start)
            t = np.linspace(0, math.pi / 2, fade)
            fade_out, fade_in = np.cos(t), np.sin(t)
        else:
            fade = min(CROSSFADE, length // 4, start)
            fade_in = np.linspace(0, 1, fade)
            fade_out = 1 - fade_in
        y = x[:start + length].copy()
        # crossfade the loop's tail into the material just before its start
        y[start + length - fade:start + length] = (y[start + length - fade:start + length] * fade_out
                                                   + x[start - fade:start] * fade_in)
        loop = start
        held = held_slope_db(db, int(start / qrate / ENVELOPE_HOP), int((RENDER_SECONDS - 0.1) / ENVELOPE_HOP))
        if held < -DECAY_FLOOR_DB_PER_S:
            decay = rate_selector(flat, ramp_seconds(start / qrate, -held))
        info.update(kind="loop", settle_seconds=settled, timbre_seconds=round(timbre, 2),
                    loop_start=start, loop_length=length, crossfade=fade,
                    loop_pitch_error_cents=round(loop_cents, 3), seam_error=round(seam, 5),
                    held_decay_db_per_s=round(held, 2), decay_selector=decay)
    # Attack and decay at once, so the envelope reaches its held phase
    # (with decay 0 it would stay in decay and never apply the held slope).
    articulation = [63, 63, 127, decay,
                    rate_selector(flat, ramp_seconds(0, HALF_LEVEL_DB / release)) if release > 0 else 63,
                    0, 0, 0]
    info["articulation"] = articulation
    info["pitch_index"] = coarse
    info["peak"] = float(np.max(np.abs(y)))
    starts = [warm_entry(y, qrate, below) for below in WARM_ENTRIES_DB]
    starts = [None if w is None else min(w, loop) if loop is not None else w for w in starts]
    info["warm_starts"] = starts
    info["warm_seconds"] = [None if w is None else round(w / qrate, 4) for w in starts]
    # build-time only: the level against the peak, and the release against
    # the level at key-off (the held render keys off at 0.5 s)
    db = envelope_db(x, qrate)
    info["_level_db"] = db - float(db[:int(0.5 / ENVELOPE_HOP)].max())
    released = envelope_db(np.asarray(held_release, dtype=np.float64), rate)
    off = int(0.5 / ENVELOPE_HOP)
    info["_release_db"] = released[off:] - released[off - 1]
    return y, loop, info


def find_loop(x, qrate, f0, earliest):
    """(start, length, pitch error in cents, seam error, noisy): a short
    loop from earliest, or where feedback noise or detune leave no short
    loop that joins cleanly, a longer one (faded over half its length);
    None when the render ends first."""
    short = loop_points(x, qrate, f0, earliest, LOOP_SECONDS)
    if short is not None and short[3] <= SEAM_CLEAN:
        return (*short, False)
    noisy = loop_points(x, qrate, f0, earliest, NOISY_LOOP_SECONDS)
    return None if noisy is None else (*noisy, True)


def warm_entry(x, rate, below):
    """Where a re-keyed note enters its render: the first upward zero
    crossing once the cold attack is within below dB of its peak (in the
    first half second), or None when the attack gets there within WARM_LEAD."""
    hop = max(1, int(0.002 * rate))
    n = min(len(x), int(0.5 * rate)) // hop * hop
    db = 20 * np.log10(np.maximum(1e-9, np.sqrt((np.asarray(x[:n]).reshape(-1, hop) ** 2).mean(axis=1))))
    at = int(np.argmax(db >= db.max() - below)) * hop
    if at < WARM_LEAD * rate:
        return None
    for i in range(at, min(len(x) - 1, at + int(0.01 * rate))):
        if x[i] < 0 <= x[i + 1]:
            return i + 1
    return at


def warm_sites(z80, songs, slot, groups, renders):
    """The warm entry (an index into WARM_ENTRIES_DB) of each keyed FM site
    that enters its render warm, the voices each site plays with, and counts
    for the receipt. A site takes the warmest entry any pass re-keys it with,
    and so does every site of its tie group (a tied pass's program change
    must stay a no-op)."""
    root_entry, site_voices = {}, {}
    counts = {"rekeys": 0, "warm_rekeys": [0] * len(WARM_ENTRIES_DB), "warm_rekeys_without_entry": 0}
    for song in songs:
        tempos = {fs.word(i.args, 0) for c in song.channels if c for i in c.code.values() if i.op == 0x05}
        # the fastest tempo: the shortest release, the longest-held note
        tick_seconds = 256 / (max(tempos or {DEFAULT_TEMPO}) * float(UPDATE_HZ["cps1"]))
        keyed, _ = keyed_notes(z80, song)
        info = [renders[(k[2], slot[(song.cue, k[0], k[1])])][2] for k in keyed]
        # Seconds into its render each note starts: a note that entered warm
        # was louder at its key-off than its cold attack says, so the state
        # chains along the channel; a second sweep settles the cycle's wrap.
        entry = [0.0] * len(keyed)
        for sweep in range(2):
            chosen = [None] * len(keyed)
            for n, (_, _, _, _, _, _, rekeys) in enumerate(keyed):
                for gap, prev, hold in rekeys:
                    level = info[prev]["_level_db"]
                    at = entry[prev] + hold * tick_seconds
                    release = info[prev]["_release_db"]
                    keyed_level = (level[min(len(level) - 1, int(at / ENVELOPE_HOP))]
                                   + release[min(len(release) - 1, int(gap * tick_seconds / ENVELOPE_HOP))])
                    if keyed_level >= -WARM_FLOOR_DB:
                        k = min(range(len(WARM_ENTRIES_DB)), key=lambda k: abs(keyed_level + WARM_ENTRIES_DB[k]))
                        chosen[n] = k if chosen[n] is None else min(chosen[n], k)
                entry[n] = 0.0 if chosen[n] is None else info[n]["warm_seconds"][chosen[n]] or 0.0
        for n, (channel, site, voice, _, _, _, rekeys) in enumerate(keyed):
            key = (song.cue, channel, site)
            site_voices.setdefault(key, set()).add(voice)
            counts["rekeys"] += len(rekeys)
            k = chosen[n]
            if k is not None:
                counts["warm_rekeys"][k] += 1
                if info[n]["warm_starts"][k] is None:
                    counts["warm_rekeys_without_entry"] += 1
                else:
                    root = groups[key]
                    root_entry[root] = min(root_entry.get(root, k), k)
    warm = {site: root_entry[r] for site, r in groups.items() if r in root_entry}
    counts["warm_sites"] = len(warm)
    return warm, site_voices, counts


def half_level_time(x, rate, key_off_seconds):
    """Seconds from key-off until the level falls to half its level at
    key-off (the YM2151 release, carriers as heard)."""
    at = int(key_off_seconds * rate)
    win = int(0.01 * rate)
    ref = float(np.sqrt(np.mean(x[at - win:at] ** 2))) or 1e-9
    for i in range(at, len(x) - win, win // 4):
        if float(np.sqrt(np.mean(x[i:i + win] ** 2))) < ref / 2:
            return round((i - at) / rate, 4)
    return round((len(x) - at) / rate, 4)


def oki_targets(flat):
    """(rate, pitch index) from the fastest, as OKI_FAST etc. describe."""
    yield from OKI_FAST
    yield OKI_RATE, OKI_NATIVE
    for coarse in range(OKI_NATIVE - 1, OKI_LOWEST - 1, -1):
        yield QSOUND_RATE * pitch_word(flat, coarse) / 4096, coarse


def oki_pcm(oki, start, end, flat):
    """A phrase at the fastest rate that fits a half-bank, as (samples, pitch
    table index), or None. The resampler keeps the OKI DAC's hold (each
    sample held for its period) and band-limits at the lower of the two
    Nyquist frequencies."""
    x = np.asarray(fs.decode_oki(oki, start, end), dtype=np.float64) * OKI_ROUTE / 2048
    for rate, coarse in oki_targets(flat):
        ratio = rate / OKI_RATE
        if coarse < OKI_NATIVE:
            ratio = ratio.limit_denominator(64)          # under half a cent
        if math.ceil(len(x) * ratio) + 2 >= q.HALF_BANK:
            continue
        if coarse == OKI_NATIVE:
            return x, coarse
        up, down = ratio.numerator, ratio.denominator
        lowpass = firwin(24 * max(up, down) | 1, 1 / max(up, down), window=("kaiser", 8.6))
        hold = np.convolve(lowpass, np.ones(up))
        return resample_poly(x, up, down, window=hold / hold.sum()), coarse
    return None


def to_pcm8(y):
    return np.clip(np.rint(y * 127), -128, 127).astype(np.int8).tobytes()


def quiet_end(pcm8):
    """A one-shot without its tail within one step of silence (an 8-bit step
    is -42 dB of full scale): the room the QSound-rate renders need."""
    end = len(pcm8)
    while end > 1 and pcm8[end - 1] in (0x00, 0x01, 0xFF):
        end -= 1
    return pcm8[:end]


# ---------------------------------------------------------------- build

def opening_songs(z80, songs, opening):
    """songs with the opening song's variants: opening = {"arcade": (rounds,
    tail), "cd": (rounds, tail), "ending": passes}, each optional (see
    CD_OPENING and CD_ENDING)."""
    import sys
    sys.path.insert(0, str(FMLOOP))
    import fmloop
    from dataclasses import replace
    out = list(songs)
    if opening.get("arcade"):
        patched = fs.songs(fmloop.apply_opening_loop(z80, *opening["arcade"])[0])[0x52]
        out = [patched if s.cue == 0x52 else s for s in out]
    if opening.get("cd"):
        if any(s.cue == CD_OPENING for s in out):
            raise ValueError(f"cue {CD_OPENING:02x} is taken")
        out.append(replace(fs.songs(fmloop.apply_opening_loop(z80, *opening["cd"])[0])[0x52], cue=CD_OPENING))
    if opening.get("ending"):
        if any(s.cue == CD_ENDING for s in out):
            raise ValueError(f"cue {CD_ENDING:02x} is taken")
        out.append(replace(fs.songs(fs.ending_vamp(z80, opening["ending"])[0])[0x54], cue=CD_ENDING))
    return out


def build(rompaths, binary, music=PILOT_MUSIC, effect_gains=None, opening=None, products=None, capture=None):
    """(image, receipt). products (the public kit's kit mode, KIT.md) replaces the floating-point
    stage: each render's and OKI phrase's 8-bit sample, its loop and analysis, the scale and the warm
    entries, as capture (a dict) records them from a normal build; the rest runs as it is."""
    z80, oki = fs.load(rompaths)
    sfa3 = spike.find_archive(rompaths, "sfa3u")
    flat = spike.read_checked(sfa3, "sz3.01", 0xDE810084) + spike.read_checked(sfa3, "sz3.02", 0x72445DC4)
    jingle_score, jingle = jingle_parts(flat, b"".join(q.swap_words(spike.read_checked(sfa3, *member))
                                                      for member in SFA3_SAMPLES))
    image = q.Image(flat, CATALOG_COUNT, effect_master=MASTER_VOLUME)
    volume_top = image.scale_volumes(10 ** (VOLUME_GAIN_DB / 20))
    # The DSP delays its dry path 46 samples on the left and 48 on the right;
    # equal delays keep a mono voice identical on both sides, so a mono
    # cabinet's sum has no comb (a notch at 6 kHz).
    image.boot_register(0xE1, image.boot_register(0xDF))
    # Effects take their pan (dry center) from their own scores.
    patched = image.effect_pan_from_score()
    table = fs.songs(z80)
    songs = [table[cue] for cue in music]
    if opening:
        songs = opening_songs(z80, songs, opening)
    # Scored effects (a nonzero mode below 0x80: FM channels 6 and 7).
    scored = [song for song in table if song and 0 < song.mode < 0x80 and any(song.channels)]
    receipt = {"recipe": {k: (str(v) if isinstance(v, Fraction) else v) for k, v in {
        "music": [f"{c:02x}" for c in music], "opening": opening, "zone_semitones": ZONE_SEMITONES,
        "fm_coarse": FM_COARSE, "oki_targets": {"fast": [[str(r), c] for r, c in OKI_FAST], "native": OKI_NATIVE, "lowest": OKI_LOWEST}, "oki_note": OKI_NOTE,
        "render_seconds": RENDER_SECONDS, "settle_db_per_s": SETTLE_DB_PER_S,
        "timbre_db": TIMBRE_DB, "timbre_floor_db": TIMBRE_FLOOR_DB, "late_step": LATE_STEP,
        "late_top_db": LATE_TOP_DB, "late_edge": LATE_EDGE,
        "ramp_fit_db": RAMP_FIT_DB,
        "settle_span": SETTLE_SPAN, "unsettled_loop_at": UNSETTLED_LOOP_AT,
        "decaying_db": DECAYING_DB, "oneshot_floor_db": ONESHOT_FLOOR_DB,
        "loop_seconds": LOOP_SECONDS, "seam_clean": SEAM_CLEAN, "noisy_loop_seconds": NOISY_LOOP_SECONDS,
        "loop_search_seconds": LOOP_SEARCH_SECONDS,
        "loop_lengths": LOOP_LENGTHS, "crossfade": CROSSFADE,
        "decay_floor_db_per_s": DECAY_FLOOR_DB_PER_S, "held_slope_range": HELD_SLOPE_RANGE, "envelope_hz": ENVELOPE_HZ,
        "warm_entries_db": WARM_ENTRIES_DB, "warm_floor_db": WARM_FLOOR_DB, "warm_lead": WARM_LEAD,
        "ym_route": YM_ROUTE, "oki_route": OKI_ROUTE, "headroom": HEADROOM, "sample_scale": SAMPLE_SCALE,
        "master_volume": MASTER_VOLUME, "effect_master": MASTER_VOLUME, "volume_gain_db": VOLUME_GAIN_DB,
        "volume_top": volume_top, "pan": PAN, "dry_delay": "right = left",
        "update_hz": {k: float(v) for k, v in UPDATE_HZ.items()}}.items()}}

    # Tempo: each increment the music uses, scaled from 62.42 Hz to 62.5 Hz.
    increments = {DEFAULT_TEMPO}
    for song in songs + scored:
        for c in song.channels:
            if c:
                increments |= {fs.word(i.args, 0) for i in c.code.values() if i.op == 0x05}
    if len(increments) >= len(TEMPO_CELLS):
        raise ValueError("more tempo increments than tempo cells")
    scale_t = UPDATE_HZ["cps1"] / UPDATE_HZ["qsound"]
    tempo_cell = {}
    for cell, inc in zip(TEMPO_CELLS, sorted(increments)):
        image.tempo(cell, round(inc * scale_t))
        tempo_cell[inc] = cell
    slow_cell = TEMPO_CELLS[-1]
    image.tempo(slow_cell, SLOW_TEMPO)
    receipt["driver_changes"] = {"boot_register_e1": image.boot_register(0xE1),
                                 "effect_pan_gate_removed": f"{patched:04x}"}
    receipt["tempo"] = {f"{inc:04x}": {"cell": c, "increment": image.tempo_increment(c)}
                        for inc, c in tempo_cell.items()}

    # FM: one render per (voice, zone), at the highest note the zone plays.
    slot, render_notes, held, plan, groups = zone_plan(z80, songs + scored)
    receipt["zones"] = plan
    if products is None:
        renders = {key: fm_sample(binary, image.flat, z80, key[0][0], note, key[0][1], held[key])
                   for key, note in sorted(render_notes.items())}
        warm, site_voices, receipt["warm"] = warm_sites(z80, songs + scored, slot, groups, renders)
        phrases = fs.oki_phrases(oki)
        okis = {p: oki_pcm(oki, *phrases[p], image.flat) for p in sorted(set(range(1, 128)) & set(phrases))}
        long_phrases = sorted(p for p, v in okis.items() if v is None)
        okis = {p: v for p, v in okis.items() if v is not None}
        peak = max([info["peak"] for _, _, info in renders.values()]
                   + [float(np.max(np.abs(y))) for y, _ in okis.values()])
        scale = min(SAMPLE_SCALE, HEADROOM / peak)
        fm_pcm = {key: to_pcm8(y * scale) if loop is not None else quiet_end(to_pcm8(y * scale))
                  for key, (y, loop, _) in renders.items()}
        oki_pcm8 = {p: quiet_end(to_pcm8(y * scale)) for p, (y, _) in okis.items()}
        oki_len = {p: len(y) for p, (y, _) in okis.items()}
    else:
        if sorted(products["renders"]) != sorted(render_notes):
            raise ValueError("the kit's renders are not the zones this score plays")
        renders = {key: (None, value["loop"], value["info"]) for key, value in products["renders"].items()}
        warm, site_voices, receipt["warm"] = products["warm"], products["site_voices"], products["warm_counts"]
        okis = {p: (None, value["coarse"]) for p, value in products["okis"].items()}
        long_phrases, scale = products["long_phrases"], products["scale"]
        fm_pcm = {key: value["pcm8"] for key, value in products["renders"].items()}
        oki_pcm8 = {p: value["pcm8"] for p, value in products["okis"].items()}
        oki_len = {p: value["samples"] for p, value in products["okis"].items()}
    if capture is not None:
        capture.update(
            renders={key: {"loop": loop, "info": {k: v for k, v in info.items() if not k.startswith("_")},
                           "pcm8": fm_pcm[key]} for key, (_, loop, info) in renders.items()},
            warm=warm, site_voices=site_voices, warm_counts=receipt["warm"],
            okis={p: {"coarse": coarse, "samples": oki_len[p], "pcm8": oki_pcm8[p]} for p, (_, coarse) in okis.items()},
            long_phrases=long_phrases, scale=scale)
    receipt["sample_scale"] = scale

    # Every sample is packed into half-banks at once, largest first; then the
    # silent row, descriptors and articulations, in that order.
    placed = iter(image.pack([(bytes(16), None)]
                             + [(fm_pcm[key], loop) for key, (_, loop, _) in sorted(renders.items())]
                             + [(oki_pcm8[p], None) for p in sorted(okis)]
                             + [(part["data"], part["loop"]) for part in jingle]))
    row, art = 1, 1
    bank_, start, loop_at, end = next(placed)
    image.descriptor(row, bank_, start, loop_at, end, root_for(OKI_NOTE, FM_COARSE))
    silent_row = row
    row += 1
    hold = art                                      # no envelope: plays out
    image.articulation(hold, [63, 0, 127, 0, 0, 0, 0, 0])
    art += 1
    rows, receipt["fm"], envelopes = {}, [], {}     # renders sharing an envelope share its row
    warm_rows = [{} for _ in WARM_ENTRIES_DB]       # warm entries: the same sample from a warm start
    for (voice, zone), (y, loop, info) in sorted(renders.items()):
        bank_, start, loop_at, end = next(placed)
        root = root_for(info["note"], info["pitch_index"])
        image.descriptor(row, bank_, start, loop_at, end, root)
        if any(w is not None and w >= end - start for w in info["warm_starts"]):
            raise ValueError(f"voice {voice} zone {zone}: a warm entry past its trimmed end")
        envelope = tuple(info["articulation"])
        if envelope not in envelopes:
            image.articulation(art, info["articulation"])
            envelopes[envelope] = art
            art += 1
        rows[(voice, zone)] = (row, envelopes[envelope])
        receipt["fm"].append({**{k: v for k, v in info.items() if not k.startswith("_")}, "zone": zone,
                              "row": row, "articulation_index": envelopes[envelope],
                              "address": bank_ << 16 | start, "bytes": end - start})
        row += 1
        receipt["fm"][-1]["warm_rows"] = []
        for k, warm_start in enumerate(info["warm_starts"]):
            if warm_start is not None:
                image.descriptor(row, bank_, start + warm_start, loop_at, end, root)
                warm_rows[k][(voice, zone)] = (row, envelopes[envelope])
                receipt["fm"][-1]["warm_rows"].append(row)
                row += 1

    # Banks: one per FM voice (its programs are zones), then the OKI bank.
    # Warm programs follow, one per (zone, warm entry) the warm sites use,
    # numbered from the zone count of every voice sharing a site with it, so
    # a site keeps one program number whichever voice plays it.
    voices = sorted({voice for voice, _ in renders})
    fm_banks = {voice: bank for bank, voice in enumerate(voices)}
    last_zone = {voice: max(zone for v, zone in renders if v == voice) for voice in voices}
    family = {voice: voice for voice in voices}

    def head(v):
        while family[v] != v:
            v = family[v]
        return v
    for vs in site_voices.values():
        first = sorted(vs)[0]
        for v in vs:
            family[head(v)] = head(first)
    width = {}
    for voice in voices:
        width[head(voice)] = max(width.get(head(voice), 0), last_zone[voice] + 1)
    family_of = {site: head(sorted(site_voices[site])[0]) for site in slot}
    used = {}
    for site, k in warm.items():
        used.setdefault(family_of[site], set()).add((slot[site], k))
    used = {h: sorted(combos) for h, combos in used.items()}
    for voice in voices:
        records = [(rows[(voice, zone)][0], 0, rows[(voice, zone)][1]) if (voice, zone) in rows
                   else (silent_row, 0, hold) for zone in range(last_zone[voice] + 1)]
        combos = used.get(head(voice), [])
        records += [(silent_row, 0, hold)] * ((width[head(voice)] - len(records)) if combos else 0)
        for zone, k in combos:
            found = warm_rows[k].get((voice, zone)) or rows.get((voice, zone))
            records.append((found[0], 0, found[1]) if found else (silent_row, 0, hold))
        if len(records) > 256:
            raise ValueError(f"voice {voice}: {len(records)} programs")
        image.instrument_bank(fm_banks[voice], records)
    programs = {site: width[family_of[site]] + used[family_of[site]].index((zone, warm[site]))
                if site in warm else zone for site, zone in slot.items()}
    # A voice that op 08 selects but no keyed note plays gets a silent bank.
    silent_bank = len(voices)
    zones = 1 + max(zone for _, zone in renders)
    image.instrument_bank(silent_bank, [(silent_row, 0, hold)] * zones)
    for song in songs + scored:
        for c in song.channels:
            if c and c.index < 8:
                for i in c.code.values():
                    if i.op == 0x08:
                        fm_banks.setdefault((i.args[0], channel_fine(c)), silent_bank)
    oki_bank = silent_bank + 1
    oki_programs, oki_records, receipt["oki"] = {}, [], []
    for program, p in enumerate(sorted(okis)):
        coarse = okis[p][1]
        bank_, start, loop_at, end = next(placed)
        image.descriptor(row, bank_, start, loop_at, end, root_for(OKI_NOTE, coarse))
        oki_records.append((row, 0, hold))
        oki_programs[p] = program
        receipt["oki"].append({"phrase": p, "program": program, "row": row, "samples": oki_len[p],
                               "pitch_index": coarse, "address": bank_ << 16 | start})
        row += 1
    oki_programs["silent"] = len(oki_records)
    oki_records.append((silent_row, 0, hold))
    receipt["banks"] = {"fm": {f"{v}{f:+d}" if f else str(v): b for (v, f), b in fm_banks.items()}, "oki": oki_bank}
    receipt["oki_left_out"] = long_phrases
    receipt["sample_bytes"] = {"fm": sum(f["bytes"] for f in receipt["fm"]),
                               "oki": sum(o["samples"] + 2 for o in receipt["oki"]), "used": image.sample_cursor,
                               "capacity": q.SAMPLE_BYTES}

    # Music.
    receipt["music"] = {}
    for song in songs:
        body, entries = translate(song, image, tempo_cell, fm_banks, programs, oki_programs, oki_bank)
        at = image.command(song.cue, score(0, body, entries))
        receipt["music"][f"{song.cue:02x}"] = {"address": at, "bytes": 33 + len(body)}
    receipt["scored_effects"] = {}
    for song in scored:      # driver 2.00's effect mode is its priority, as 1.71's score mode is
        body, entries = translate(song, image, tempo_cell, fm_banks, programs, oki_programs, oki_bank, effect=True)
        at = image.command(song.cue, score(song.mode, body, entries))
        receipt["scored_effects"][f"{song.cue:02x}"] = {"mode": song.mode, "address": at, "bytes": 33 + len(body),
                                                       "channels": [c.index for c in song.channels if c]}

    # OKI triggers as effect scores. Each plays on effect channel 8 + its OKI
    # voice, the voice of the music's OKI channel for that OKI voice, as CPS1
    # shares OKI voices between them; channels 0-7 would silence FM music
    # voices. The score's mode is the trigger's priority: 1.71 starts an effect
    # channel only for a mode at or above the one playing there, the rule
    # driver 2.00 keeps per OKI voice. The note lasts as long as the phrase,
    # through a tempo of its own, so the channel and its priority free when
    # the phrase ends, as the OKI voice does. A looping trigger holds a tied
    # note on a descriptor that loops the whole phrase, until replaced.
    receipt["effects"] = {}
    loop_programs, trigger_cells = {}, {}
    free_cells = iter(TRIGGER_TEMPO_CELLS)
    for song in table:
        if song is None or not song.mode & 0x80:
            continue
        t = fs.oki_trigger(z80, song)
        if t["phrase"] not in oki_programs:
            continue
        o = next(o for o in receipt["oki"] if o["phrase"] == t["phrase"])
        program = oki_programs[t["phrase"]]
        if t["loops"]:
            if t["phrase"] not in loop_programs:
                bank_, start = o["address"] >> 16, o["address"] & 0xFFFF
                image.descriptor(row, bank_, start, start, start + o["samples"], root_for(OKI_NOTE, o["pitch_index"]))
                loop_programs[t["phrase"]] = len(oki_records)
                oki_records.append((row, 0, hold))
                row += 1
            program, cell = loop_programs[t["phrase"]], slow_cell
        else:
            seconds = o["samples"] / (float(QSOUND_RATE) * pitch_word(image.flat, o["pitch_index"]) / 4096)
            increment = min(0xFFFF, int(TRIGGER_TICKS * 256 / (float(UPDATE_HZ["qsound"]) * seconds)))
            if increment not in trigger_cells:
                trigger_cells[increment] = next(free_cells)
                image.tempo(trigger_cells[increment], increment)
            cell = trigger_cells[increment]
        channel = 8 + {1: 0, 2: 1, 4: 2, 8: 3}[t["voice_bit"]]
        note = 0xE0 | OKI_KEY
        gain = (effect_gains or {}).get(song.cue, 0.0)   # a test kit's level change (sound_members)
        body = bytes([5, cell, 0x18, PAN, 6, 255, 7, oki_volume(image, t["attenuation"], gain), 0x1F, oki_bank,
                      8, program, 9, OKI_OCTAVE, 0x0B, 0, 4, 0])
        if t["loops"]:
            body += bytes([1, note, 0x16]) + rel(len(body) + 2, 3, len(body) + 1)
        else:
            body += bytes([note, 0x17])
        entries = [None] * 16
        entries[channel] = 0
        at = image.command(song.cue, score(max(1, t["priority"]), body, entries))
        receipt["effects"][f"{song.cue:02x}"] = {**t, "channel": channel, "tempo_cell": cell, "address": at,
                                                 **({"gain_db": gain} if gain else {})}
    image.instrument_bank(oki_bank, oki_records)

    # The jingle: its samples were packed with ours; SFA3's own loop and end
    # offsets (its end addresses are inclusive), articulations and fine tune.
    if image.tempo_increment(JINGLE_TEMPO_CELL[0]) != JINGLE_TEMPO_CELL[1]:
        raise ValueError("the jingle's tempo cell changed")
    jingle_bank, records, arts = oki_bank + 1, [], {}
    for part in jingle:
        bank_, start, _, _ = next(placed)
        image.descriptor(row, bank_, start, start + part["loop"], start + part["end"], part["root"])
        if part["articulation"] not in arts:
            image.articulation(art, list(part["articulation"]))
            arts[part["articulation"]] = art
            art += 1
        records.append((row, part["fine"], arts[part["articulation"]]))
        part.update(row=row, address=bank_ << 16 | start)
        row += 1
    image.instrument_bank(jingle_bank, records)
    at = image.command(JINGLE, relocate_jingle(jingle_score, jingle_bank, [p["program"] for p in jingle]))
    receipt["jingle"] = {"command": f"{JINGLE:02x}", "sfa3_command": f"{SFA3_JINGLE:02x}", "address": at,
                         "bank": jingle_bank, "score_sha256": JINGLE_SCORE[1],
                         "samples": [{k: (f"{v:#x}" if k == "address" else v) for k, v in p.items()
                                      if k in ("program", "row", "address")} | {"bytes": len(p["data"])}
                                     for p in jingle]}
    return image, receipt


def jingle_parts(sfa3_flat, sfa3_samples):
    """sfa3u's jingle: its score and, per program it selects (in the order
    the new bank lists them), the sample, its loop and end offsets, root,
    fine tune and articulation bytes, each checked against its pinned hash."""
    src = int.from_bytes(sfa3_flat[q.CATALOG + 6 + 4 * SFA3_JINGLE:q.CATALOG + 9 + 4 * SFA3_JINGLE], "big")
    length, digest = JINGLE_SCORE
    score_bytes = bytes(sfa3_flat[src:src + length])
    if hashlib.sha256(score_bytes).hexdigest() != digest:
        raise ValueError("sfa3u's jingle score does not match its pinned hash")
    bank0 = struct.unpack_from("<H", sfa3_flat, q.CONFIG + 5)[0]
    parts = []
    for program in sorted(JINGLE_SAMPLES):
        row, fine, art = struct.unpack_from("<HbB", sfa3_flat, bank0 + 4 * program)
        b, s, loop, end, root = struct.unpack_from("<BHHHB", sfa3_flat, q.DESCRIPTORS + 8 * row)
        data = bytes(sfa3_samples[(b << 16) | s:((b << 16) | s) + end - s + 1])
        if hashlib.sha256(data).hexdigest() != JINGLE_SAMPLES[program]:
            raise ValueError(f"sfa3u's jingle sample for program {program:#x} does not match its pinned hash")
        parts.append({"program": program, "data": data, "loop": loop - s, "end": end - s, "root": root, "fine": fine,
                      "articulation": bytes(sfa3_flat[q.ARTICULATIONS + 8 * art:q.ARTICULATIONS + 8 * art + 8])})
    return score_bytes, parts


def relocate_jingle(score_bytes, bank, programs):
    """The score with its bank (op 1F, all 0) and programs (op 08) pointed at
    ours; it has no branches, so it moves as it is."""
    out = bytearray(score_bytes)
    lengths = {**fs.ARGLEN, 0x05: 1, 0x1A: 1, 0x1F: 1}
    for entry in struct.unpack_from(">16H", out, 1):
        if not entry:
            continue
        at = entry
        while True:
            op = out[at]
            if op >= 0x20:
                at += 1
                continue
            if op == 0x17:
                break
            if 0x0E <= op <= 0x16:
                raise ValueError("the jingle score branches")
            if op == 0x1F:
                if out[at + 1] != 0:
                    raise ValueError("the jingle score selects a bank other than 0")
                out[at + 1] = bank
            if op == 0x08:
                out[at + 1] = programs.index(out[at + 1])
            at += 1 + lengths[op]
    return bytes(out)


def walk_171(body, entry):
    """Instruction starts reachable from a translated channel entry, read
    with 1.71's operand lengths (relative branches); fails on a branch into
    the middle of an instruction."""
    lengths = {**fs.ARGLEN, 0x05: 1, 0x1A: 1, 0x1F: 1}
    starts, pending = {}, [entry]
    while pending:
        at = pending.pop()
        while at not in starts:
            op = body[at]
            size = 1 if op >= 0x20 else 1 + lengths[op]
            starts[at] = size
            if 0x0E <= op <= 0x16:
                pending.append(at + size + struct.unpack_from(">h", body, at + size - 2)[0])
            if op in (0x16, 0x17):
                break
            at += size
    for at, size in starts.items():
        if any(at + i in starts for i in range(1, size)):
            raise ValueError(f"a branch lands inside the instruction at {at:#x}")
    return set(starts)


def self_test(rompaths):
    z80, oki = fs.load(rompaths)
    assert quiet_end(bytes([5, 0, 0xFF, 1, 0])) == bytes([5]) and quiet_end(bytes([0, 0])) == bytes([0])
    assert abs(ramp_seconds(0, HALF_LEVEL_DB) / 2.75 - 1) < 0.03      # a release: 2.75 half-level times
    assert ramp_seconds(0.69, 39.9) > 1.0                               # voice 12: past its loop, not 0.3 s
    dying = np.concatenate([-23.0 * np.arange(200) * ENVELOPE_HOP, np.full(200, -180.0)])
    assert abs(held_slope_db(dying, 0, 390) + 23.0) < 0.5 and slope_db(dying, 0, 390) < -40
    table = fs.songs(z80)
    slum = table[0x40]
    keyed, _ = keyed_notes(z80, slum)
    # Keyed notes per cycle, as the CPS1 YM2151 trace of cue 40 shows them.
    assert [sum(1 for k in keyed if k[0] == ch) for ch in range(6)] == [11, 24, 2, 35, 29, 29]
    slot, render, held, plan, _ = zone_plan(z80, [table[c] for c in PILOT_MUSIC])
    assert max(plan["shift_semitones"]) <= ZONE_SEMITONES + 1 and min(plan["shift_semitones"]) == 0
    sfa3 = spike.find_archive(rompaths, "sfa3u")
    flat = spike.read_checked(sfa3, "sz3.01", 0xDE810084) + spike.read_checked(sfa3, "sz3.02", 0x72445DC4)
    image = q.Image(flat, CATALOG_COUNT)
    tempo_cell = {inc: 0xE0 for c in slum.channels if c for inc in
                  [fs.word(i.args, 0) for i in c.code.values() if i.op == 0x05] + [DEFAULT_TEMPO]}
    banks = {v: b for b, v in enumerate(sorted({v for v, _ in render}))}
    oki_programs = {p: 0 for p in range(128)} | {"silent": 0}
    body, entries = translate(slum, image, tempo_cell, banks, slot, oki_programs, len(banks))
    for channel, entry in enumerate(entries[:8]):
        if entry is None:
            continue
        reached = walk_171(body, entry)       # also checks every branch lands on an instruction
        programs = sum(1 for a in reached if body[a] == 0x08 and body[a + 2] >= 0x20)
        assert programs == len({s for c, s, *_ in keyed if c == channel}), "each keyed FM site sets its zone"
    y, coarse = oki_pcm(oki, *fs.oki_phrases(oki)[1], image.flat)
    assert coarse == 60 and abs(len(y) / (2 * (1919 - 1024 + 1)) - float(QSOUND_RATE / OKI_RATE)) < 0.01
    y, coarse = oki_pcm(oki, *fs.oki_phrases(oki)[52], image.flat)     # 5.7 s: below the OKI's rate
    assert coarse < OKI_NATIVE and len(y) + 2 < q.HALF_BANK
    print("self-test passed")


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--rompath", action="append", default=[])
    parser.add_argument("--work", type=Path)
    parser.add_argument("--renderer", type=Path, help="ym2151_render binary (else bootstrap)")
    parser.add_argument("--all-music", action="store_true", help="every music cue, not the pilot's")
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args(argv)
    rompaths = [Path(p) for p in args.rompath] + spike.default_rompaths()
    if args.self_test:
        self_test(rompaths)
        return 0
    if args.work is None:
        parser.error("--work is required")
    work = args.work.resolve()
    work.mkdir(parents=True, exist_ok=True)
    binary = args.renderer
    if binary is None:
        import bootstrap_ymfm
        binary, _ = bootstrap_ymfm.build(work)
    music = PILOT_MUSIC
    if args.all_music:
        z80, _ = fs.load(rompaths)
        music = tuple(s.cue for s in fs.songs(z80) if s and s.mode == 0 and any(s.channels))
    image, receipt = build(rompaths, binary, music)
    out = work / "audio"
    out.mkdir(exist_ok=True)
    members = image.members()
    for name, data in members.items():
        (out / name).write_bytes(data)
    receipt["members"] = {name: spike.identity(data) for name, data in members.items()}
    (out / "audio.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps({k: receipt[k] for k in ("zones", "sample_bytes", "sample_scale", "music", "members")}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
