#!/usr/bin/env python3
"""Read Final Fight's CPS1 sound data: Capcom sound driver 2.00.

Parses the Z80 program (`ff_09.12b`, parent `ffight` set) and the OKI sample
ROM (`ff_18.11c`, `ff_19.12c`) as the driver itself reads them; see
AUDIO_PILOT.md. Addresses are Z80 addresses; the driver banks fetches at or
above 0xC000, which leaves the address equal to the file offset.

    python3 ff_sound.py --self-test
    python3 ff_sound.py --summary [--rompath DIR]
"""
from __future__ import annotations

import argparse
from dataclasses import dataclass, field
import json
import sys

import audit_upstream as upstream
import build_m1_spike as spike

Z80_MEMBER = ("ff_09.12b", 0xB8367EB5)
OKI_MEMBERS = (("ff_18.11c", 0x375C66E7), ("ff_19.12c", 0x1EF137F9))

SONG_TABLE = 0x1000
CHANNELS = 12                 # 0-7 YM2151, 8-11 OKI
VOICE_BYTES = 32
OKI_RATE = 1_000_000 / 132    # 1 MHz clock, pin 7 high
END = 0x17

# Operand bytes per opcode (< 0x20); bytes >= 0x20 are notes and rests.
# The same table as ffightcd/build/fmloop.py, checked against the driver's
# handlers (jump table at 0x08A1).
ARGLEN = {0x00: 0, 0x01: 0, 0x02: 0, 0x03: 0, 0x04: 1, 0x05: 2, 0x06: 1,
          0x07: 1, 0x08: 1, 0x09: 1, 0x0A: 1, 0x0B: 1, 0x0C: 1, 0x0D: 1,
          0x0E: 3, 0x0F: 3, 0x10: 3, 0x11: 3, 0x12: 3, 0x13: 3, 0x14: 3,
          0x15: 3, 0x16: 2, 0x17: 0, 0x18: 1, 0x19: 1}
# The SEGA CD opening's song: cue 0x52 with more of its own mid-song repeat
# (ff_audio.opening_songs), in Final Fight's unused command 0x5B, which the
# layer's EX alias $76 plays; its (rounds, tail) per edition are CPS1 EX's
# (ffightcd build/rom.py fm_open_loop), the restoration on Japan's timing.
CD_OPENING = 0x5B
CD_OPENING_ROUNDS = {"usa": (12, 1), "japan": (12, 0), "english": (12, 0)}
# The SEGA CD ending's song: cue 0x54 with more passes of its closing vamp
# (ending_vamp), in Final Fight's unused command 0x5A, which the layer's EX
# alias $78 plays (CD_ENDING); 0x54 stays Capcom's for CUT SCENES ARCADE.
# Japan's CD reunion runs 1,289 frames longer than the US disc's (the
# farewell's INIT 5,620 frames after the reunion's, against 4,331), so the
# stock song ended before Japan's farewell (22 October, on Japanese
# EX: "the ending song ended early"). Five more passes (1,920 ticks, 1,262
# frames) end it as far into Japan's farewell as the US song runs into the
# US one; the restoration has Japan's scenes, and the US keeps 0x54.
CD_ENDING = 0x5A
CD_ENDING_PASSES = {"usa": 0, "japan": 5, "english": 5}
# Duration tables (ticks for index 1-7): plain, flag 0x20, one-note flag 0x10.
DURATION_TABLES = {"plain": 0x0B51, "alternate": 0x0B58, "single": 0x0B5F}


@dataclass
class Instruction:
    address: int
    op: int                    # opcode, or the note byte (>= 0x20)
    args: bytes
    targets: tuple = ()        # branch destinations
    falls_through: bool = True

    @property
    def size(self):
        return 1 + len(self.args)


@dataclass
class Channel:
    index: int
    start: int
    code: dict = field(default_factory=dict)    # address -> Instruction

    def ops(self, op):
        return [i for i in self.code.values() if i.op == op]


@dataclass
class Song:
    cue: int
    header: int
    mode: int
    channels: list             # Channel or None, 12 entries

    @property
    def music(self):
        return self.mode == 0


def load(rompaths):
    ffight = spike.find_archive(rompaths, "ffight")
    z80 = spike.read_checked(ffight, *Z80_MEMBER)
    oki = b"".join(spike.read_checked(ffight, *member) for member in OKI_MEMBERS)
    return z80, oki


def word(data, address):
    return data[address] << 8 | data[address + 1]


def walk(z80, start):
    """Every instruction reachable from a channel's start, following the
    driver's control flow: repeats and last-pass exits may fall through or
    branch; jumps and the end op do not fall through."""
    code, pending = {}, [start]
    while pending:
        address = pending.pop()
        while address not in code:
            op = z80[address]
            length = ARGLEN.get(op, 0) if op < 0x20 else 0
            if op < 0x20 and op not in ARGLEN:
                raise ValueError(f"unknown op {op:02x} at {address:04x}")
            args = bytes(z80[address + 1:address + 1 + length])
            targets, falls = (), True
            if 0x0E <= op <= 0x15:
                targets = (word(args, 1),)
            elif op == 0x16:
                targets, falls = (word(args, 0),), False
            elif op == END:
                falls = False
            code[address] = Instruction(address, op, args, targets, falls)
            pending.extend(targets)
            if not falls:
                break
            address += 1 + length
    return code


@dataclass
class Note:
    address: int
    voice: int
    note: int                  # driver note, the key-code table index + 1
    tied: bool                 # follows a tied note: pitch change, no key-on
    ticks: int = 0             # its duration (handler 0609)
    gate: int | None = None    # ticks to its key-off; None: tied into the next note
    rest: int = 0              # rest ticks between the note before it and it
    after_note: bool = False   # a note comes before it in this pass


class Notes(list):
    """play()'s notes, and wrap: (index of the note the cycle returns to,
    rest ticks between the cycle's last note and it), or None when the
    channel ends or holds no note to return to."""
    wrap = None


def play(z80, channel, transpose=0, limit=200_000):
    """Run one channel as the driver does (handlers 0626, 0A5B, 0AB4) and
    return its notes in order, through one whole cycle: until the end op, or
    until the channel comes back to a state it has been in. transpose is the
    song's global transpose (op 0A, which the music bank shares).
    A note's gate is the driver's key-off countdown (handler 06C2): the gate
    ratio (op 06, handler 0914; 0 when the song starts, which clears channel
    RAM at 021D) times the duration, over 256. A note tied into the next one
    has none and is not keyed off."""
    pc, flags, octave, shift, voice, ratio = channel.start, 0, 0, 0, None, 0
    counters, seen, notes, rest = [0, 0, 0, 0], {}, Notes(), 0
    for _ in range(limit):
        instruction = channel.code[pc]
        op, args = instruction.op, instruction.args
        state = (pc, flags, octave, shift, voice, ratio, tuple(counters))
        if state in seen:
            index, rest_then = seen[state]
            if index < len(notes):
                notes.wrap = (index, rest + notes[index].rest - rest_then)
            return notes
        seen[state] = (len(notes), rest)
        nxt = pc + instruction.size
        if op >= 0x20:
            table = (DURATION_TABLES["plain"] if not flags & 0x30 else
                     DURATION_TABLES["single"] if flags & 0x10 else DURATION_TABLES["alternate"])
            ticks = z80[table + (op >> 5) - 1]
            if op & 0x1F == 0:
                flags |= 0x01
                rest += ticks
            else:
                note = (op & 0x1F) + octave + (0x18 if flags & 0x08 else 0) + transpose + shift
                tied = bool(flags & 0x80)
                flags = (flags & 0x7E) | (flags & 0x40) << 1
                gate = None if flags & 0x80 else ratio * ticks >> 8
                notes.append(Note(pc, voice, min(note & 0xFF, 0x61), tied, ticks, gate, rest, bool(notes)))
                rest = 0
            flags &= ~0x10
        elif op in (0x00, 0x01, 0x03):
            flags ^= {0x00: 0x20, 0x01: 0x40, 0x03: 0x08}[op]
        elif op == 0x02:
            flags |= 0x10
        elif op == 0x04:
            flags = (flags & 0x97) | args[0]
        elif op == 0x06:
            ratio = args[0]
        elif op == 0x08:
            voice = args[0]
        elif op == 0x09:
            octave = 12 * args[0] & 0xFF
        elif op == 0x0A:
            transpose = args[0]
        elif op == 0x0B:
            shift = args[0]
        elif 0x0E <= op <= 0x11:
            k = op - 0x0E
            if counters[k] == 0:
                counters[k], nxt = args[0], instruction.targets[0]
            else:
                counters[k] -= 1
                if counters[k]:
                    nxt = instruction.targets[0]
        elif 0x12 <= op <= 0x15:
            k = op - 0x12
            if counters[k] == 1:
                counters[k] = 0
                flags = (flags & 0x97) | args[0]
                nxt = instruction.targets[0]
        elif op == 0x16:
            nxt = instruction.targets[0]
        elif op == END:
            return notes
        pc = nxt
    raise ValueError(f"channel {channel.index} did not settle in {limit} steps")


def cd_ending(edition):
    """The command the layer's EX alias $78 plays in this edition."""
    return CD_ENDING if CD_ENDING_PASSES[edition] else 0x54


# Cue 0x54 (Capcom's arcade ending, 90.4 s): section A (bars 0-13, 2688
# ticks) twice, a bridge (bars 28-33), the closing vamp (bars 34-39: a
# 2-bar figure on A's opening motif, 384 ticks) three times, then the tail
# (bars 40-41, the final chord) at the slower tempo channel 0 sets as it
# starts (op05 0x111 after 0x174). Channels 1-6 repeat the vamp with an
# op0E (count 2; channel 6's figure counts 3, the tail being its fourth
# pass), channel 7 echoes channel 4's code 18 ticks late, and channel 0
# writes its three passes out before its tempo change.
ENDING_HEADER = 0x597B
ENDING_VAMP = {1: (0x5A72, 2), 2: (0x5AAC, 2), 3: (0x5AE0, 2), 4: (0x5B7A, 2), 5: (0x5C72, 2), 6: (0x5CFE, 3)}
ENDING_CH0 = (0x5994, bytes.fromhex(
    "0501740902080606f0077d0400cdcff1cdcff1cdcfecedeff0f1edefcdcff10e01599f"
    "edeff1ced0edefcdcfeccdcfeccdcfec050111cdcfec17"))
ENDING_CH0_LOOP = 0x1F                  # its op0E: section A twice, to +0x0B
ENDING_CH0_PASS = (0x2A, bytes.fromhex("cdcfec"))   # its first vamp pass; the tail's op05 at +0x33
ENDING_CH7 = (0x5D0B, bytes.fromhex("165aee"))      # channel 7 runs channel 4's code
ENDING_COPY = 0x8800                    # free m1 space (fmloop's opening fragments start at 0x8000)


def ending_vamp(z80, extra):
    """(z80 with extra more passes of cue 0x54's closing vamp, summary): each
    op0E count rises by extra, and channel 0 starts from a copy of its code
    with extra more passes written in. Every seam is the score's own vamp
    repeat and the tail is Capcom's; each pass is 384 ticks at 0x174 (90.70
    ticks a second), 4.23 s. (A jump from channel 0's code into its extra
    passes made driver 1.71 play its first two passes slightly differently,
    MEASURED; the copy converts to the stock stream with more passes.)"""
    if not 1 <= extra <= 40:
        raise ValueError("extra passes must be 1-40")
    rom, stock = bytearray(z80), bytes(z80)
    for ch, (site, count) in ENDING_VAMP.items():
        if stock[site] != 0x0E or stock[site + 1] != count:
            raise ValueError(f"cue 0x54 channel {ch}: no vamp repeat at {site:#06x}")
        rom[site + 1] = count + extra
    at, code = ENDING_CH0
    pass_at, one = ENDING_CH0_PASS
    if (stock[at:at + len(code)] != code or word(stock, ENDING_HEADER + 1) != at
            or stock[ENDING_CH7[0]:ENDING_CH7[0] + 3] != ENDING_CH7[1]
            or code[ENDING_CH0_LOOP:ENDING_CH0_LOOP + 4] != bytes([0x0E, 0x01]) + (at + 0x0B).to_bytes(2, "big")
            or code[pass_at:pass_at + 9] != one * 3 or code[pass_at + 9] != 0x05):
        raise ValueError("cue 0x54's channels are not the stock ones")
    copy = bytearray(code[:pass_at] + one * (3 + extra) + code[pass_at + 9:])
    copy[ENDING_CH0_LOOP + 2:ENDING_CH0_LOOP + 4] = (ENDING_COPY + 0x0B).to_bytes(2, "big")
    if any(b != 0xFF for b in stock[ENDING_COPY:ENDING_COPY + len(copy)]):
        raise ValueError("the copy's space is not free")
    rom[ENDING_COPY:ENDING_COPY + len(copy)] = copy
    rom[ENDING_HEADER + 1:ENDING_HEADER + 3] = ENDING_COPY.to_bytes(2, "big")
    return bytes(rom), f"ending vamp +{extra}: {len(ENDING_VAMP)} counts, channel 0 at {ENDING_COPY:04X}"


def songs(z80):
    count = z80[SONG_TABLE]
    result = []
    for cue in range(count):
        header = word(z80, SONG_TABLE + 3 + 2 * cue)
        if not header:
            result.append(None)
            continue
        mode = z80[header]
        if mode & 0x80:           # another handler (0x031B), not a channel list
            result.append(Song(cue, header, mode, [None] * CHANNELS))
            continue
        channels = []
        for index in range(CHANNELS):
            start = word(z80, header + 1 + 2 * index)
            channels.append(None if z80[start] == END else Channel(index, start, walk(z80, start)))
        result.append(Song(cue, header, mode, channels))
    return result


def oki_trigger(z80, song):
    """A mode-0x80 cue (handler 0x031B): one OKI phrase on one OKI voice.
    Mode bit 0 loops it: the request goes in the voice's loop slot, which the
    driver replays whenever the voice falls idle, until a request of the same
    priority without the bit clears it (or a lower-priority loop request
    waits there for the voice)."""
    b = z80[song.header:song.header + 5]
    return {"cue": song.cue, "phrase": b[1], "attenuation": b[2], "voice_bit": b[3],
            "priority": b[4], "loops": bool(b[0] & 1)}


def voice_table(z80):
    return word(z80, SONG_TABLE + 1)


def voice(z80, number):
    base = voice_table(z80) + VOICE_BYTES * number
    raw = bytes(z80[base:base + VOICE_BYTES])
    return {
        "number": number,
        "key_mask": raw[0],
        "lfo": None if raw[1] == 0 else {"waveform": raw[2] & 0x7F, "rate": raw[3],
                                          "pmd": raw[4], "amd": raw[5], "pms_ams": raw[6]},
        "feedback_connection": raw[7],
        "dt1_mul": list(raw[8:12]),
        "tl": list(raw[12:16]),
        "ks_ar": list(raw[16:20]),
        "ams_d1r": list(raw[20:24]),
        "dt2_d2r": list(raw[24:28]),
        "d1l_rr": list(raw[28:32]),
        "raw": raw.hex(),
    }


def durations(z80):
    return {name: list(z80[address:address + 7]) for name, address in DURATION_TABLES.items()}


def oki_phrases(oki):
    phrases = {}
    for number in range(1, 128):
        entry = oki[number * 8:number * 8 + 8]
        start, end = int.from_bytes(entry[0:3], "big"), int.from_bytes(entry[3:6], "big")
        if start and start < end < len(oki):
            phrases[number] = (start, end)
    return phrases


STEPS = [int(16 * (11 / 10) ** n) for n in range(49)]
ADJUST = (-1, -1, -1, -1, 2, 4, 6, 8)


def decode_oki(oki, start, end):
    """OKI MSM6295 ADPCM (high nibble first) to 12-bit samples."""
    signal, step, out = 0, 0, []
    for byte in oki[start:end + 1]:
        for nibble in (byte >> 4, byte & 15):
            size = STEPS[step]
            delta = size >> 3
            if nibble & 1:
                delta += size >> 2
            if nibble & 2:
                delta += size >> 1
            if nibble & 4:
                delta += size
            signal = max(-2048, min(2047, signal - delta if nibble & 8 else signal + delta))
            step = max(0, min(48, step + ADJUST[nibble & 7]))
            out.append(signal)
    return out


def summary(z80, oki):
    table = songs(z80)
    used_voices, tempos, music, effects = set(), set(), [], []
    for song in table:
        if song is None or song.mode & 0x80:
            continue
        (music if song.music else effects).append(song.cue)
        for channel in song.channels:
            if channel is None:
                continue
            for instruction in channel.code.values():
                if instruction.op == 0x08 and channel.index < 8:
                    used_voices.add(instruction.args[0])
                if instruction.op == 0x05:
                    tempos.add(word(instruction.args, 0))
    phrases = oki_phrases(oki)
    return {
        "songs": len(table),
        "music_cues": [f"{c:02x}" for c in music],
        "effect_cues": [f"{c:02x}" for c in effects],
        "oki_trigger_cues": [f"{s.cue:02x}" for s in table if s and s.mode & 0x80],
        "voice_table": f"{voice_table(z80):04x}",
        "fm_voices_used": sorted(used_voices),
        "tempo_increments": sorted(f"{t:04x}" for t in tempos),
        "durations": durations(z80),
        "oki_phrases": len(phrases),
        "oki_seconds": round(sum(2 * (e - s + 1) for s, e in phrases.values()) / OKI_RATE, 1),
    }


def self_test(rompaths):
    z80, oki = load(rompaths)
    table = songs(z80)
    assert len(table) == 96 and voice_table(z80) == 0x10C3
    slum = table[0x40]
    assert slum.music and [c.start if c else None for c in slum.channels] == [
        0x1E9C, 0x1EBD, 0x1F0A, 0x1F20, 0x1F8F, 0x1FFF, None, None, 0x200F, 0x2076, None, None]
    opening = table[0x52]
    # fmloop.py's measured sites: each melody channel's last-pass exit (op 12)
    # and repeat count (op 0E); the OKI channels' repeats.
    for index, (exit_site, repeat_site) in {0: (0x52C5, 0x52D4), 1: (0x5354, 0x5363),
                                            2: (0x53F8, 0x5408), 3: (0x549C, 0x54AB),
                                            4: (0x5567, 0x5579)}.items():
        code = opening.channels[index].code
        assert code[exit_site].op == 0x12 and code[repeat_site].op == 0x0E, index
    assert opening.channels[8].code[0x5742].op == 0x0E
    assert durations(z80)["plain"] == [3, 6, 12, 24, 48, 96, 192]
    assert durations(z80)["alternate"] == [2, 4, 8, 16, 32, 64, 128]
    phrases = oki_phrases(oki)
    assert len(phrases) == 70 and phrases[1] == (1024, 1919)
    samples = decode_oki(oki, *phrases[1])
    assert len(samples) == 2 * (1919 - 1024 + 1) and max(map(abs, samples)) > 100
    assert voice(z80, 0)["key_mask"] == 0x78
    ring, laugh = oki_trigger(z80, table[0x35]), oki_trigger(z80, table[0x28])
    assert (ring["phrase"], ring["voice_bit"], ring["loops"]) == (0x36, 8, True)
    assert (laugh["phrase"], laugh["priority"]) == (0x29, 8)
    print("self-test passed")


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--rompath", action="append", default=[])
    parser.add_argument("--self-test", action="store_true")
    parser.add_argument("--summary", action="store_true")
    args = parser.parse_args(argv)
    rompaths = [spike.Path(p) for p in args.rompath] + spike.default_rompaths()
    if args.self_test:
        self_test(rompaths)
        return 0
    z80, oki = load(rompaths)
    json.dump(summary(z80, oki), sys.stdout, indent=2)
    print()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
