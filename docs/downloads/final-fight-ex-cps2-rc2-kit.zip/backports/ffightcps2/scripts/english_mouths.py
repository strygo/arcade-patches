#!/usr/bin/env python3
"""The restoration EX's English lips: every talking face in the CD scenes follows the redub.

Japanese EX's CD scenes animate each speaker's mouth on the Japanese voice. The
redub's English lines run longer or shorter, start later (a pushed line) or
end sooner, so the Japanese flapping no longer matches what is heard. 21
October: "When hagger says 'Son of a...' his mouth needs to move more for the
longer english phrase (USA had this)"; and on MiSTer kit 261021-18: "Haggers
mouth mismatch during the first phone scene", "Count me in has the wrong mouth
movement", "Ending captions and mouth don't align with vocals".

FACES lists every face that animates speech in Japanese EX's scenes, with the
English lines (manifests/dub_mix_receipt.json) of its speaker:

- the opening (the opening engine): Haggar on the phone (op06, op10), Haggar
  beside the TV (op12, the whole face as Japanese EX draws it), Cody (op15,
  op17, op19) and Guy (op16, op18) in the Guy/Cody two-shot;
- the ending's reunion engine: Jessica (en01, en06) and Haggar (en02-en05) in
  the reunion, and the hall scene's Cody (en07, en09) and Guy (en08), whose
  figures are the walker's sprites (a cel per event, SPREVT);
- the farewell engine: Jessica (en11) and Cody (en12) in the close-up before
  the camera tilts down (their faces leave the screen; en13 plays over the
  pan, as the Japanese line does).

Each face's drawings come from Japanese EX's own animation (Face.drawings: the
face cells' state after the named events, or the walker's cel numbers), grouped by
class (closed, open, wide, rest; chosen by viewing the rendered states) and
family (the phone's three eye and brow poses each have their own mouth
drawings; the hall's Cody has a standing and a turned pose). The build checks
them by digest. Where the mouth and the eyes are separate cells (Guy, the
reunion, the farewell), only the mouth cells are the English's and the eyes keep
Japanese EX's blinks.

Over a face's shot (Face.shot, its events), every frame shows the drawing its moment
of the English voice calls for: the speaker's takes' speech-band level frame by
frame (manifests/dub_mouths.json, measured from the durable take store by
``measure`` and pinned to the mix receipt's takes and placements), WIDE at
WIDE_DB or more under the take's loud level (its 95th percentile), OPEN at
OPEN_DB, CLOSED at CLOSED_DB, silent below; the face leads the voice by a
frame; a silence shorter than GAP_FRAMES inside speech stays closed; no class
shows for less than HOLD frames, open and wide counting as one talking stretch;
a mouth open longer than MAX_OPEN frames closes for HOLD frames at the voice's
quietest moment there when that is a dip (DIP_DB), so a word with syllables
flaps and a steady vowel stays open. In silence the face shows Japanese EX's own
frame unless that is a talking drawing, then its family's closed (or rest)
drawing. Within a class the drawings follow each other in the animation's order,
the next every HOLD frames. The shot's last HOLD frames are Japanese EX's again:
the face is handed back, and every later event draws as before.

The map faces' cells are written per vblank where the engines already write
(vbsched.py's sinks): an event's now-list as it lands (the opening's late
records, 64 cells or more, one vblank after their load), else, on its later
frames, its spill chunks (ex_regulation keeps spills out of the TV's picture
columns only where REG_TV runs). Japanese EX's own writes to the face's cells inside
the shot are dropped; every other cell of every event (the TV's picture, which
REGULATION's table pairs by state, the scenes' other cells) stays the script's,
the records' flags and durations too. A face change waits for the next vblank
that has a sink and is no scene cut (TRANSITION_CELLS) and has room in the
engine's budget (vbsched's cycle model). A rebuilt event list goes back in
place when it fits, else to MOUTH_HOME in the scenes' data ROM. The sprite
faces rewrite SPREVT's cel for their character (the walker draws a whole cel
every vblank, so its load does not change).

The build simulates both scripts vblank by vblank: every face cell is the plan
(as realized) inside its shot, every other cell and every cell outside the shots
is Japanese EX's, and the receipt gives the cells each vblank adds (worst).

    python3 english_mouths.py measure       # dub_mouths.json from the receipt's takes (needs the take store)
    python3 english_mouths.py --self-test
"""
from __future__ import annotations

import argparse
from collections import namedtuple
import hashlib
import importlib.util
import json
import math
import struct
import sys
from pathlib import Path

import english_ex
import ex_regulation as R

TRACK = Path(__file__).resolve().parents[1]
MOUTHS = TRACK / "manifests" / "dub_mouths.json"
DUB_MIX = TRACK / "manifests" / "dub_mix_receipt.json"
VBSCHED = TRACK.parents[0] / "ffightcd" / "build" / "vbsched.py"
FRAME_HZ = english_ex.FRAME_HZ
WALKER_CYC = 7_000              # the hall walker's vblank work (rom.py's vbsched budget for its events)
WIDE_DB, OPEN_DB, CLOSED_DB = -7.0, -15.0, -30.0
GAP_FRAMES = 6                  # a silence this short inside speech stays closed
MAX_OPEN = 15                   # frames a mouth stays open before it may close, at a dip in the voice
DIP_DB = 6.0                    # a dip: a frame this far under the open stretch's loudest
HOLD = 3                        # frames a drawing holds at least, and a flap closes (op12: its events' two)
BAND = (300.0, 3400.0)          # the speech band (Hz)
DATA = 0x310000                 # the scenes' data ROM in the CPS2 program (ffightcd build/target.py)
MOUTH_HOME = 0xE2000            # rebuilt event lists that do not fit in place, in the data ROM's free top
DATA_REACH = 0xF0000            # the CPU reaches the data ROM only to the 4 MB program's end
TRANSITION_CELLS = 128          # a vblank already landing this many cells (a cut) takes none of the lips'
CLEAR = R.CLEAR
CLASS_ORDER = ("rest", "closed", "open", "wide")
TALK = ("open", "wide")

# The engines (ffightcd build/rom.py): their code in the scenes' program, whether the record rule's late
# lists land a vblank after their load (the opening only), when their event 0 plays on the scene's game
# clock (frames: event-start frame f plays at (f + lead) / FRAME_HZ), and vbsched's budget for their other
# per-vblank work (rom.py). The clocks are english_ex's, MEASURED: the opening's SCHEDULE_LEAD; the ending
# engines' frames from INIT (ENDING_BASE), whose event 0 loads a vblank after INIT (lead_in 1; Japanese EX
# 471f38a9: the reunion's INIT at frame 21105, its event 0 and the Arrange ROM's voiced ending key at
# 21106, the farewell's INIT 5620 frames later and its event 0 a frame after that).
Engine = namedtuple("Engine", "code late lead fixed_cyc")
ENGINES = {
    "opening": Engine(0xD6000, True, english_ex.SCHEDULE_LEAD, 2_600),
    "reunion": Engine(0xD7000, False, english_ex.ENDING_BASE["ending"] + 1, 2_500),
    "farewell": Engine(0xD8000, False, english_ex.ENDING_BASE["farewell"] + 1, 13_000),
}

# A face: its engine, speaker and English lines, its shot (first and last event of the frames it owns),
# its cells (scroll 2 map (row, col); an event range: the cells those events redraw outside the TV's
# picture; or "cody"/"guy": the hall walker's character), its drawings {family: {class: events (or
# cels)}}, the frames a drawing holds, and the drawings' digest.
Face = namedtuple("Face", "name engine speaker lines shot cells drawings hold digest")
TV_TALK = range(953, 1020)      # Japanese EX's events that redraw Haggar's face beside the TV for op12
FACES = (
    # The phone (Japanese EX's events 810-867): his eyes look down (810-820), up (821-834), then he
    # frowns (835 on); each pose has its closed and open mouth (the eye cells are drawn with them).
    Face("phone", "opening", "Haggar", ("op06", "op10"), (810, 867),
         ((21, 47), (21, 48), (22, 47), (22, 48)),
         {"down": {"closed": (810,), "open": (811,)}, "up": {"closed": (821,), "open": (822,)},
          "frown": {"closed": (835,), "open": (836,)}}, HOLD,
         "d41efff2668d7d68d7193b533ad56c27fc08e10f8d94ce290f27802011a6499d"),
    # Beside the TV (c8091c4e9): from the phone's raise (970) through the rest he holds after it; teeth
    # showing (open), shut under the mustache (closed), shouting (wide), gritted with the phone hand
    # trembling (rest, two states in turn).
    Face("tv", "opening", "Haggar", ("op12",), (970, 1100), TV_TALK,
         {"": {"open": tuple(range(970, 979)), "closed": tuple(range(979, 989)),
               "wide": tuple(range(989, 1002)), "rest": (1019, 1020)}}, 2,
         "8f1ade55409bdcf29e809289f0a58734f0799db12852ced62b2604c494bc093a"),
    # The Guy/Cody two-shot (1713-1874, before the cut to Cody's fist): Cody's mouth and jaw; Guy's
    # mouth (his eyes, the row above, keep Japanese EX's blinks and shut eyes).
    Face("cody", "opening", "Cody", ("op15", "op17", "op19"), (1713, 1874),
         ((22, 44), (22, 45), (22, 46), (23, 44), (23, 45), (23, 46)),
         {"": {"closed": (1713,), "open": (1717,), "wide": (1718,)}}, HOLD,
         "35d7261e0ccfb4b233b27fc0ffa8574ac2c37d1cb10e3dad684c473bd6b84d21"),
    Face("guy", "opening", "Guy", ("op16", "op18"), (1713, 1874),
         ((22, 53), (22, 54), (23, 53), (23, 54)),
         {"": {"closed": (1713,), "open": (1749,), "wide": (1750,)}}, HOLD,
         "8df333fa77b08dcdaab0757c6c0409e9c48f92b119c5a38d95d6203140d53970"),
    # The reunion (events 30-278, before the fade-out's redraws): Jessica's lips; Haggar's mouth under
    # the mustache (half open and open in turn for OPEN), his eye cells Japanese EX's.
    Face("reunion-jessica", "reunion", "Jessica", ("en01", "en06"), (30, 278),
         ((25, 50), (25, 51)),
         {"": {"closed": (37,), "open": (38,), "wide": (39,)}}, HOLD,
         "758dc7b6d3a90dcd1ce0869b3835fb748c2b10404078da993ceb5742142838cc"),
    Face("reunion-haggar", "reunion", "Haggar", ("en02", "en03", "en04", "en05"), (30, 278),
         ((22, 45), (22, 46), (22, 47), (23, 45), (23, 46), (23, 47), (24, 45), (24, 46), (24, 47), (24, 48)),
         {"": {"closed": (73,), "open": (74, 72), "wide": (207,)}}, HOLD,
         "644efc3faa4494bf669369a47fe2b1f7e452be2e850437e9bad4a006bc3b1b52"),
    # The hall (the walker's events 296-603): Cody standing (cels 1, 2) and turned to Guy (4, 5, 6) until
    # he walks off; Guy with his arms folded (18, 20, 19).
    Face("hall-cody", "reunion", "Cody", ("en07", "en09"), (296, 599), "cody",
         {"standing": {"closed": (1,), "open": (2,)}, "turned": {"closed": (4,), "open": (5,), "wide": (6,)}},
         HOLD, "134713e1f7a1e29b5921ac613fd01f7be3110edfbb6e2a4c574b07888ba14abc"),
    Face("hall-guy", "reunion", "Guy", ("en08",), (296, 603), "guy",
         {"": {"closed": (18,), "open": (20,), "wide": (19,)}}, HOLD,
         "9a5d253d91e58cc104a3fe564c420a37e8c9f9fda062cc89e418fcc5ce09f3cb"),
    # The farewell's close-up (events 1-70, before the tilt): Jessica's lips (her eye cell keeps its
    # blinks) and Cody's mouth (his eye too).
    Face("farewell-jessica", "farewell", "Jessica", ("en11",), (1, 70), ((23, 49),),
         {"": {"closed": (1,), "open": (6,), "wide": (7,)}}, HOLD,
         "abad4356782c720046520bbbf8c15c089b02d5643164f51e3886fb5e33dfb37f"),
    Face("farewell-cody", "farewell", "Cody", ("en12",), (1, 70), ((21, 46), (21, 47), (22, 46), (22, 47)),
         {"": {"closed": (1,), "open": (30,), "wide": (31,)}}, HOLD,
         "b061665232a308f1ffa3b7c77e9469aa712a4506ce90dc4d45eff622dee593bc"),
)
SPRITES = {"cody": 0, "guy": 1}  # the walker's characters, in SPREVT's row order


def lines():
    """Every line FACES draw, in order."""
    return [lid for face in FACES for lid in face.lines]


# ---------------------------------------------------------------- the takes

def scene_of(lid):
    return "opening" if lid.startswith("op") else "ending"


def receipt_rows(receipt=None):
    receipt = receipt or json.loads(DUB_MIX.read_text())
    return receipt, {r["id"]: r for s in ("opening", "ending") for r in receipt["scenes"][s]["lines"]}


def measure(receipt_path=DUB_MIX):
    """{line: {take_sha256, takes_set, start, end, ratio, first, levels_db}}: each line's take as the mix
    places it (its run's piece and ratio for a run), as speech-band levels per frame of its scene's game
    clock from first = floor(start * FRAME_HZ), dB under the take's 95th percentile, rounded."""
    import numpy as np
    from scipy.signal import butter, sosfiltfilt
    import dub_mix as dm
    import dub_refs as DR
    receipt, rows = receipt_rows(json.loads(Path(receipt_path).read_text()))
    takes = DR.take_set(receipt["takes_set"])
    out = {}
    for lid in lines():
        row = rows[lid]
        run = receipt["scenes"][scene_of(lid)]["runs"].get(row.get("run")) if row.get("run") else None
        x = dm.line_take(takes, lid, run["lines"], run["apart"]) if run else dm.line_take(takes, lid)
        if row["ratio"] < 1:
            x = dm.wsola(x, row["ratio"])
        if abs(len(x) / dm.SR - (row["end"] - row["start"])) > 0.02:
            raise ValueError(f"{lid}: the take runs {len(x) / dm.SR:.3f} s, the mix places {row['end'] - row['start']:.3f}")
        y = sosfiltfilt(butter(4, BAND, btype="band", fs=dm.SR, output="sos"), x)
        first = math.floor(row["start"] * FRAME_HZ)
        levels, k = [], first
        while True:
            a = round((k / FRAME_HZ - row["start"]) * dm.SR)
            b = round(((k + 1) / FRAME_HZ - row["start"]) * dm.SR)
            if a >= len(y):
                break
            seg = y[max(a, 0):max(b, 0)]
            levels.append(20 * math.log10(math.sqrt(float((seg ** 2).mean())) + 1e-3) if len(seg) else -120.0)
            k += 1
        ref = float(np.percentile(levels, 95))
        out[lid] = {"take_sha256": receipt["takes_sha256"][lid], "takes_set": receipt["takes_set"],
                    "start": row["start"], "end": row["end"], "ratio": row["ratio"], "first": first,
                    "levels_db": [max(round(v - ref), -60) for v in levels]}
    return out


def pinned(mouths, receipt):
    """The measured lines, checked against the mix receipt's takes and placements."""
    receipt, rows = receipt_rows(receipt)
    out = {}
    for lid in lines():
        m = mouths["lines"].get(lid)
        row = rows[lid]
        if m is None or (m["take_sha256"], m["start"], m["ratio"]) != (
                receipt["takes_sha256"][lid], row["start"], row["ratio"]):
            raise ValueError(f"dub_mouths.json's {lid} is not the mix receipt's take and placement: "
                             "run english_mouths.py measure")
        out[lid] = m
    return out


# ---------------------------------------------------------------- the scripts

def _find(code, before, after):
    i = code.find(before)
    while i >= 0:
        j = i + len(before)
        if code[j + 4:j + 4 + len(after)] == after:
            return struct.unpack(">I", code[j:j + 4])[0]
        i = code.find(before, i + 1)
    raise ValueError(f"no {before.hex()}..{after.hex()} in the engine")


def bases(program, engine):
    """{script, pal, delta: data ROM offsets, events, (walker: sprevt, celoff, celtab, first, count)} from
    an engine's code (ffightcd build/engine.py: its record lookup, palette copy, delta and walker
    immediates)."""
    code = bytes(program[engine.code:engine.code + 0x1000])
    out = {"script": _find(code, bytes.fromhex("48c0e98843f9"), bytes.fromhex("d3c0")) - DATA,
           "pal": _find(code, bytes.fromhex("e189e58945f9"), bytes.fromhex("d5c1")) - DATA,
           "delta": _find(code, bytes.fromhex("2229000445f9"), bytes.fromhex("d5c1")) - DATA}
    i = code.find(bytes.fromhex("52400c40"))           # addq.w #1,d0; cmpi.w #nevents,d0
    out["events"] = struct.unpack(">H", code[i + 4:i + 6])[0]
    for k in range(0, len(code) - 12, 2):               # subi.w #first,d0; bcs; cmpi.w #count,d0
        if code[k:k + 2] == b"\x04\x40" and code[k + 4:k + 6] == b"\x65\x00" and code[k + 8:k + 10] == b"\x0c\x40":
            i = code.find(bytes.fromhex("381b3a3c"))   # move.w (a3)+,d4; move.w #maxc-1,d5
            out["walker"] = {"first": struct.unpack(">H", code[k + 2:k + 4])[0],
                             "count": struct.unpack(">H", code[k + 10:k + 12])[0],
                             "maxc": struct.unpack(">H", code[i + 4:i + 6])[0] + 1,
                             "sprevt": _find(code, bytes.fromhex("e748e549d04145f9"), bytes.fromhex("d4c0")) - DATA,
                             "celoff": _find(code, bytes.fromhex("d64347f9"), bytes.fromhex("36333000")) - DATA,
                             "celtab": _find(code, bytes.fromhex("3633300047f9"), bytes.fromhex("d6c3")) - DATA}
            break
    return out


def records(data, b):
    at = b["script"]
    return [struct.unpack(">HHIHHHH", data[at + 16 * k:at + 16 * k + 16]) for k in range(b["events"])]


def blob(data, b, rec):
    """A record's now-cells and spill chunks [[cell], ...] (chunk j at index j - 1), and its blob's length."""
    at = start = b["delta"] + rec[2]
    count = rec[3] & 0x1FFF
    now = [struct.unpack(">HHH", data[at + 6 * k:at + 6 * k + 6]) for k in range(count)]
    at += 6 * count
    chunks = []
    if rec[3] & R.SPILL:
        while True:
            n = struct.unpack(">H", data[at:at + 2])[0]
            at += 2
            if n == 0xFFFF:
                break
            chunks.append([struct.unpack(">HHH", data[at + 6 * k:at + 6 * k + 6]) for k in range(n)])
            at += 6 * n
    return now, chunks, at - start


def starts(recs):
    out, t = [], 0
    for r in recs:
        out.append(t)
        t += r[4]
    return out


def sinks(recs, late):
    """{vblank: [sink]} in the order the engine applies them (vbsched.py, engine.py): the opening's
    catch-up lands each late record's now-list a vblank after its load, then tick B lands a fresh early
    record's now-list or the live record's spill chunk j (j = vblanks since its load, from 1); the
    ending engines land every now-list at its load. A sink is ("now", event) or ("spill", event, j)."""
    st = starts(recs)
    out = {}
    for e, r in enumerate(recs):
        if late and r[3] & R.LATE:
            out.setdefault(st[e] + 1, []).append(("now", e))
    for e, r in enumerate(recs):
        if not (late and r[3] & R.LATE):
            out.setdefault(st[e], []).append(("now", e))
        for j in range(1, r[4]):
            out.setdefault(st[e] + j, []).append(("spill", e, j))
    for v, row in out.items():                          # catch-up (late) before tick B
        row.sort(key=lambda s: (0 if s[0] == "now" and late and recs[s[1]][3] & R.LATE else 1, s[1]))
    return out


def sink_cells(data, b, recs, sink, cache):
    e = sink[1]
    if e not in cache:
        cache[e] = blob(data, b, recs[e])
    now, chunks, _ = cache[e]
    if sink[0] == "now":
        return now
    return chunks[sink[2] - 1] if sink[2] - 1 < len(chunks) else []


def replay(data, b, recs, late):
    """[(vblank, [(offset, (code, attr))])]: every vblank's writes in order."""
    order = sinks(recs, late)
    cache = {}
    frames = starts(recs)[-1] + recs[-1][4]
    return [[(o, (c, a)) for s in order.get(v, ()) for o, c, a in sink_cells(data, b, recs, s, cache)]
            for v in range(frames + 1)]


def live_events(recs):
    """[event] live at each frame."""
    out = []
    for e, r in enumerate(recs):
        out += [e] * r[4]
    return out + [len(recs) - 1]


def capacity(engine, recs, v, live, st, walker=None):
    """Cells a vblank has room for (vbsched's cycle model): less the engine's other work at that vblank,
    a palette block copy at a load that changes the block, the hall walker inside its events."""
    vb = vbsched()
    cyc = vb.VBLANK_CYC - vb.STOCK_ISR_CYC - engine.fixed_cyc - vb.SAFETY_CYC
    e = live[min(v, len(live) - 1)]
    if st[e] == v and (e == 0 or (recs[e][1] & 0xFF) != (recs[e - 1][1] & 0xFF)):
        cyc -= vb.PAL_CYC
    if walker and walker["first"] <= e < walker["first"] + walker["count"]:
        cyc -= WALKER_CYC
    return max(0, cyc // vb.CELL_CYC)


_VB = None


def vbsched():
    global _VB
    if _VB is None:
        spec = importlib.util.spec_from_file_location("ffcd_vbsched", VBSCHED)
        _VB = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(_VB)
    return _VB


def cel(data, w, n):
    off = struct.unpack(">H", data[w["celoff"] + 2 * n:w["celoff"] + 2 * n + 2])[0]
    at = w["celtab"] + off
    count = struct.unpack(">H", data[at:at + 2])[0]
    return [struct.unpack(">4H", data[at + 2 + 8 * k:at + 10 + 8 * k]) for k in range(count)]


def sprevt(data, w, e, who):
    at = w["sprevt"] + 12 * (e - w["first"]) + 6 * SPRITES[who]
    return struct.unpack(">3H", data[at:at + 6])


# ---------------------------------------------------------------- the faces

def face_cells(face, data, b, recs):
    """A map face's cells as offsets, in offset order (op12's: the TV talk events' cells off the picture)."""
    if isinstance(face.cells, range):
        written = set()
        for j in face.cells:
            written |= {o for o, _, _ in blob(data, b, recs[j])[0]}
        return sorted(written - set(R.PICTURE_CELLS))
    return sorted(((row & 0x0F) + ((col & 0x3F) << 4) + ((row & 0x30) << 6)) * 4 for row, col in face.cells)


def event_states(data, b, recs, last, offsets):
    """The face cells' state after each event's cells through last (now and spills)."""
    state = {o: CLEAR for o in offsets}
    want = set(offsets)
    out = []
    for j in range(last + 1):
        now, chunks, _ = blob(data, b, recs[j])
        for o, c, a in now + [x for ch in chunks for x in ch]:
            if o in want:
                state[o] = (c, a)
        out.append(tuple(state[o] for o in offsets))
    return out


def drawings(face, data, b, recs, offsets):
    """{family: {class: [drawing]}}: map faces' drawings as cell states, sprite faces' as cel numbers."""
    if isinstance(face.cells, str):
        return {f: {k: list(v) for k, v in cls.items()} for f, cls in face.drawings.items()}
    last = max(j for cls in face.drawings.values() for js in cls.values() for j in js)
    states = event_states(data, b, recs, last, offsets)
    return {f: {k: [states[j] for j in js] for k, js in cls.items()} for f, cls in face.drawings.items()}


def digest(vocab, data=None, walker=None):
    """The drawings' digest: classes in order, map drawings as their cells' words (op12's c8091c4e9
    vocabulary_digest), cels as their entries; families in name order."""
    h = hashlib.sha256()
    for fam in sorted(vocab):
        if fam:
            h.update(fam.encode())
        for k in sorted(vocab[fam]):
            for state in vocab[fam][k]:
                if isinstance(state, int):
                    for entry in cel(data, walker, state):
                        h.update(struct.pack(">4H", *entry))
                else:
                    for code, attr in state:
                        h.update(struct.pack(">HH", code, attr))
    return h.hexdigest()


def classify(level):
    if level >= WIDE_DB:
        return "wide"
    if level >= OPEN_DB:
        return "open"
    if level >= CLOSED_DB:
        return "closed"
    return "rest"


def talk_level(face, mouths, engine):
    """level(f): the face's speaker's English at the engine's frame f (dB, -120 when silent)."""
    rows = [mouths[lid] for lid in face.lines]

    def level(f):
        k = f + engine.lead
        best = -120
        for m in rows:
            i = k - m["first"]
            if 0 <= i < len(m["levels_db"]):
                best = max(best, m["levels_db"][i])
        return best
    return level


def runs(seq):
    """[(start, end, value)] of a sequence's runs."""
    out, k = [], 0
    while k < len(seq):
        m = k
        while m < len(seq) and seq[m] == seq[k]:
            m += 1
        out.append((k, m, seq[k]))
        k = m
    return out


def steady(seq, hold, talk_only=False):
    """seq with open and wide as one talking stretch (21 October, on the restoration's intro: "Some
    of the Cody and guy mouth movements don't line up to vocals": a syllable whose frames went open, wide,
    wide, open was all runs shorter than hold, each taken back to the closed frame before it). A closure
    shorter than hold between talking frames joins the talk around it, and a talking stretch shorter than
    hold opens for hold frames (unless talk_only); inside a stretch, and inside a silence, no class shows for
    less than hold frames (it takes the class before it)."""
    out = list(seq)
    if not talk_only:
        for a, b, t in runs([c in TALK for c in out]):
            if not t and 0 < a and b < len(out) and b - a < hold:
                out[a:b] = [out[a - 1]] * (b - a)
        for a, b, t in runs([c in TALK for c in out]):
            if t and b - a < hold:
                loud = "wide" if "wide" in out[a:b] else "open"
                out[a:a + hold] = [loud] * len(out[a:a + hold])
    for a, b, t in runs([c in TALK for c in out]):
        if b - a < hold:
            continue
        for s, e, c in runs(out[a:b]):
            if e - s < hold and e - s < b - a:
                fill = out[a + s - 1] if s > 0 else out[a + e]
                out[a + s:a + e] = [fill] * (e - s)
    return out


def classes(level, frames, hold):
    """[class] per frame from the English level: the face leads the voice by a frame; a silence shorter
    than GAP_FRAMES inside speech stays closed; no class shows for less than hold frames (steady()); a
    mouth open (or wide) longer than MAX_OPEN frames closes for hold frames at its quietest moment, again
    until no open stretch is longer (a held vowel still flaps, at the syllables' dips)."""
    lv = [level(f + 1) for f in frames]
    raw = [classify(x) for x in lv]
    for a, b, c in runs(raw):
        if c == "rest" and a > 0 and b < len(raw) and b - a < GAP_FRAMES:
            raw[a:b] = ["closed"] * (b - a)
    raw = steady(raw, hold)

    def split(a, b):
        if b - a <= MAX_OPEN:
            return
        inner = range(a + hold, b - 2 * hold + 1)
        if not inner:
            return
        k = min(inner, key=lambda i: (sum(lv[i:i + hold]), abs(2 * i + hold - a - b)))
        if min(lv[k:k + hold]) > max(lv[a:b]) - DIP_DB:
            return                                  # a steady vowel: the mouth stays open
        raw[k:k + hold] = ["closed"] * hold
        split(a, k)
        split(k + hold, b)
    for a, b, t in runs([c in TALK for c in raw]):
        if t:
            split(a, b)
    return steady(raw, hold, talk_only=True)


def plan(face, vocab, level, frames, japanese):
    """({frame: drawing}, classes) over the face's frames: each frame's class (classes()) drawn in the
    family Japanese EX's frame is in, a class's drawings in turn (the next every hold frames); in silence,
    and where Japanese EX's frame has no family, Japanese EX's own frame, unless that talks in silence
    (then its family's rest or closed drawing); the last hold frames Japanese EX's (the hand-back)."""
    family_of = {}
    for fam, cls in vocab.items():
        for states in cls.values():
            for s in states:
                family_of.setdefault(s, fam)
    talk = talking(vocab)
    cls = classes(level, frames, face.hold)
    fallback = {"wide": "open", "open": "wide", "closed": "rest", "rest": "closed"}
    turn, out = {}, {}
    last_family = next(iter(vocab))
    for a, b, c in runs(cls):
        n = turn.get(c, 0)
        for k in range(a, b):
            f = frames[k]
            fam = family_of.get(japanese[f])
            if fam is not None:
                last_family = fam
            if c == "rest" or fam is None:
                if japanese[f] not in talk:
                    out[f] = japanese[f]
                    continue
                fam = last_family
            options = vocab[fam].get(c) or vocab[fam].get(fallback[c]) or vocab[fam]["closed"]
            if c == "rest":
                options = vocab[fam].get("rest") or vocab[fam]["closed"]
            out[f] = options[(n + (k - a) // face.hold) % len(options)]
        turn[c] = n + 1 + (b - a - 1) // face.hold
    for f in frames[-face.hold:]:                   # the hand-back
        out[f] = japanese[f]
    return out, cls


# ---------------------------------------------------------------- applying

def map_japanese(writes, offsets, f0, f1):
    """{frame: the face's cells} from f0 - 1 through f1 in Japanese EX's script (after each vblank)."""
    index = {o: i for i, o in enumerate(offsets)}
    state = [CLEAR] * len(offsets)
    out = {-1: tuple(state)}
    for v in range(f1 + 1):
        for o, val in writes[v]:
            i = index.get(o)
            if i is not None:
                state[i] = val
        if v >= f0 - 1:
            out[v] = tuple(state)
    return out


def talking(vocab):
    return {s for cls in vocab.values() for k, states in cls.items() if k in TALK for s in states}


def lips(face, engine, data, b, recs, st, writes, m):
    """(drawings digest, frames, {frame: wanted}, {frame: Japanese EX's}, classes, offsets or None) of a face."""
    first, last = face.shot
    frames = list(range(st[first], st[last] + recs[last][4]))
    level = talk_level(face, m, engine)
    if isinstance(face.cells, str):                 # the hall walker: a cel per event
        w = b["walker"]
        vocab = drawings(face, data, b, recs, None)
        got = digest(vocab, data, w)
        live = live_events(recs)
        japanese = {f: sprevt(data, w, live[f], face.cells)[2] for f in frames}
        offsets = None
    else:
        offsets = face_cells(face, data, b, recs)
        vocab = drawings(face, data, b, recs, offsets)
        got = digest(vocab)
        japanese = map_japanese(writes, offsets, frames[0], frames[-1])
    if got != face.digest:
        raise ValueError(f"{face.name}'s drawings changed: {got} against {face.digest}")
    if any(japanese[f] in talking(vocab) for f in frames[-face.hold:]):
        raise ValueError(f"{face.name}: Japanese EX's face still talks at the shot's end")
    want, cls = plan(face, vocab, level, frames, japanese)
    return got, frames, want, japanese, cls, offsets


def apply(data, program=None, mouths=None, receipt=None):
    """(data with every face's English lips, receipt) for the restoration EX's scenes data ROM; program:
    the scenes' program (the engines' code), else the restoration EX's pieces'."""
    if program is None:
        import ex_scenes
        program = ex_scenes.pieces("english")["program.bin"]
    m = pinned(mouths or json.loads(MOUTHS.read_text()), receipt)
    data = bytearray(data)
    original = bytes(data)
    out = {"faces": {}, "engines": {}}
    home = bytearray()
    for name, engine in ENGINES.items():
        b = bases(program, engine)
        recs = records(original, b)
        st, live = starts(recs), live_events(recs)
        writes = replay(original, b, recs, engine.late)
        order = sinks(recs, engine.late)
        cache, home_from = {}, len(home)
        drop, add, added, spans, owned, sprite = {}, {}, {}, [], {}, {}
        for face in (f for f in FACES if f.engine == name):
            got, frames, want, japanese, cls, offsets = lips(face, engine, original, b, recs, st, writes, m)
            if offsets is None:                     # the walker's cel, event by event
                rows = {e: want[st[e]] for e in range(face.shot[0], face.shot[1] + 1)}
                for e, c in rows.items():
                    if c != japanese[st[e]]:
                        sprite[(e, face.cells)] = c
                realized = {f: rows[live[f]] for f in frames}
            else:                                   # the map's cells, vblank by vblank
                for o in offsets:
                    for other, f0, f1 in owned.get(o, ()):
                        if f0 <= frames[-1] and frames[0] <= f1:
                            raise ValueError(f"{face.name} and {other} share a cell")
                    owned.setdefault(o, []).append((face.name, frames[0], frames[-1]))
                index = set(offsets)
                shown, realized = japanese[frames[0] - 1], {}
                for v in frames:
                    for s in order.get(v, ()):      # Japanese EX's writes to the face inside the shot
                        hit = {o for o, _, _ in sink_cells(original, b, recs, s, cache) if o in index}
                        if hit:
                            drop.setdefault(s, set()).update(hit)
                    change = [(o, t) for o, t, s0 in zip(offsets, want[v], shown) if t != s0]
                    usable = [s for s in order.get(v, ()) if s[0] == "now"] or order.get(v)
                    if change and usable and len(writes[v]) < TRANSITION_CELLS and len(writes[v]) + \
                            added.get(v, 0) + len(change) <= capacity(engine, recs, v, live, st, b.get("walker")):
                        add.setdefault(usable[-1], []).extend((o, *t) for o, t in change)
                        added[v] = added.get(v, 0) + len(change)
                        shown = want[v]
                    realized[v] = shown
                spans.append((frames[0], frames[-1], offsets, realized))
            if realized[frames[-1]] != japanese[frames[-1]]:
                raise ValueError(f"{face.name}: the hand-back at frame {frames[-1]} is not Japanese EX's face")
            out["faces"][face.name] = {
                "engine": name, "speaker": face.speaker, "lines": list(face.lines), "events": list(face.shot),
                "frames": [frames[0], frames[-1]], "drawings_sha256": got,
                "classes": {k: cls.count(k) for k in CLASS_ORDER},
                "frames_redrawn": sum(1 for f in frames if realized[f] != japanese[f]),
                "changes": sum(1 for f in frames[1:] if realized[f] != realized[f - 1]),
                "japanese_changes": sum(1 for f in frames[1:] if japanese[f] != japanese[f - 1]),
                "frames_late": sum(1 for f in frames if realized[f] != want[f])}
        # the touched records: rebuilt in place when they fit, else at MOUTH_HOME
        rebuilt = moved = 0
        for e in sorted({s[1] for s in list(drop) + list(add)}):
            now, chunks, length = blob(original, b, recs[e])
            new_now = [c for c in now if c[0] not in drop.get(("now", e), ())] + add.get(("now", e), [])
            n = max([len(chunks)] + [s[2] for s in add if s[0] == "spill" and s[1] == e])
            new_chunks = [[c for c in (chunks[j - 1] if j <= len(chunks) else [])
                           if c[0] not in drop.get(("spill", e, j), ())] + add.get(("spill", e, j), [])
                          for j in range(1, n + 1)]
            while new_chunks and not new_chunks[-1]:
                new_chunks.pop()
            if sorted(new_now) == sorted(now) and [sorted(c) for c in new_chunks] == [sorted(c) for c in chunks]:
                continue
            if len(new_now) > 0x1FFF:
                raise ValueError(f"{name} event {e}: too many cells")
            body = b"".join(struct.pack(">HHH", *c) for c in new_now)
            if new_chunks:
                body += b"".join(struct.pack(">H", len(ch)) + b"".join(struct.pack(">HHH", *c) for c in ch)
                                 for ch in new_chunks) + b"\xff\xff"
            flags = (recs[e][3] & (R.LATE | R.DEFERRED)) | (R.SPILL if new_chunks else 0) | len(new_now)
            at = b["delta"] + recs[e][2]
            if len(body) <= length:
                data[at:at + length] = body + b"\xff" * (length - len(body))
                offset = recs[e][2]
            else:
                offset = MOUTH_HOME + len(home) - b["delta"]
                home += body
                moved += 1
            base = b["script"] + 16 * e
            data[base + 4:base + 8] = struct.pack(">I", offset)
            data[base + 8:base + 10] = struct.pack(">H", flags)
            rebuilt += 1
        for (e, who), c in sprite.items():
            w = b["walker"]
            at = w["sprevt"] + 12 * (e - w["first"]) + 6 * SPRITES[who] + 4
            data[at:at + 2] = struct.pack(">H", c)
        if any(x != 0xFF for x in original[MOUTH_HOME + home_from:MOUTH_HOME + len(home)]):
            raise ValueError(f"MOUTH_HOME {MOUTH_HOME:#x} is not free")
        data[MOUTH_HOME + home_from:MOUTH_HOME + len(home)] = home[home_from:]
        # the patched script, vblank by vblank, against Japanese EX's
        new_recs = records(bytes(data), b)
        if [r[:2] + r[4:] for r in new_recs] != [r[:2] + r[4:] for r in recs]:
            raise ValueError(f"{name}: a record changed beyond its cells")
        patched = replay(bytes(data), b, new_recs, engine.late)
        verify(writes, patched, spans, name)
        if "walker" in b:
            w = b["walker"]
            span = slice(w["sprevt"], w["sprevt"] + 12 * w["count"])
            new, old = bytes(data[span]), original[span]
            for k in range(0, len(new), 2):
                if new[k:k + 2] != old[k:k + 2] and (k % 6 != 4 or (k // 12 + w["first"],
                                                                     ("cody", "guy")[k % 12 // 6]) not in sprite):
                    raise ValueError(f"{name}: the walker's table changed beyond the faces' cels")
        grown = [(len(p) - len(q), v) for v, (q, p) in enumerate(zip(writes, patched))]
        worst = max(grown)
        busiest = max([(len(patched[v]), v) for f0, f1, _, _ in spans for v in range(f0, f1 + 1)] or [(0, 0)])
        out["engines"][name] = {
            "records_rebuilt": rebuilt, "records_moved_home": moved, "walker_cels": len(sprite),
            "vblanks_adding_cells": sum(1 for g, _ in grown if g > 0),
            "worst_added": {"cells": worst[0], "vblank": worst[1], "of": len(patched[worst[1]])},
            "busiest_face_vblank": {"cells": busiest[0], "vblank": busiest[1],
                                    "room": capacity(engine, new_recs, busiest[1], live, st, b.get("walker"))}}
        out["engines"][name]["home_bytes"] = len(home) - home_from
        original = bytes(data)                      # the next engine's lists follow these at MOUTH_HOME
    if MOUTH_HOME + len(home) > DATA_REACH:
        raise ValueError(f"MOUTH_HOME {MOUTH_HOME:#x} has no room the CPU reaches for {len(home)} bytes")
    out.update({"home": f"{MOUTH_HOME:#x}", "bytes": len(home), "sha256": hashlib.sha256(bytes(data)).hexdigest(),
                "mouths_sha256": hashlib.sha256(MOUTHS.read_bytes()).hexdigest() if mouths is None else None})
    return bytes(data), out


def verify(writes, patched, spans, name):
    """Every vblank: off the faces' cells and shots the patched map is Japanese EX's; inside a shot, its
    face's cells are the realized plan."""
    a, p, diff = {}, {}, set()
    for v, (wa, wp) in enumerate(zip(writes, patched)):
        for o, val in wa:
            a[o] = val
        for o, val in wp:
            p[o] = val
        for o, _ in wa + wp:
            if a.get(o, CLEAR) != p.get(o, CLEAR):
                diff.add(o)
            else:
                diff.discard(o)
        live = [s for s in spans if s[0] <= v <= s[1]]
        allowed = set().union(*[set(s[2]) for s in live]) if live else set()
        if diff - allowed:
            raise ValueError(f"{name} vblank {v}: cells off the faces differ from Japanese EX's: "
                             f"{sorted(diff - allowed)[:4]}")
        for f0, f1, offsets, realized in live:
            if tuple(p.get(o, CLEAR) for o in offsets) != realized[v]:
                raise ValueError(f"{name} vblank {v}: a face is not its plan")


def faces(data, program):
    """{face: (engine, offsets or the walker's character, (first frame, last frame))}, for the gate."""
    out = {}
    for face in FACES:
        engine = ENGINES[face.engine]
        b = bases(program, engine)
        recs = records(data, b)
        st = starts(recs)
        first, last = face.shot
        cells = face.cells if isinstance(face.cells, str) else face_cells(face, data, b, recs)
        out[face.name] = (face.engine, cells, (st[first], st[last] + recs[last][4] - 1))
    return out


# ---------------------------------------------------------------- self-test and CLI

def self_test():
    assert classify(-3) == "wide" and classify(-10) == "open" and classify(-20) == "closed" and classify(-40) == "rest"
    levels = {f: v for f, v in enumerate([-50] * 4 + [-5] * 7 + [-50] * 3 + [-12] * 6 + [-50] * 20)}
    got = classes(lambda f: levels.get(f, -120), list(range(40)), 3)
    assert got[3:10] == ["wide"] * 7 and got[2] == "rest"   # the face leads by a frame
    assert got[10:13] == ["closed"] * 3                       # a short pause inside speech stays closed
    assert got[13:19] == ["open"] * 6 and got[-4:] == ["rest"] * 4
    long = {f: (-20 if f == 9 else -3) for f in range(20)}  # a held vowel closes at its dip
    got = classes(lambda f: long.get(f, -120), list(range(24)), 3)
    assert got[8:11] == ["closed"] * 3 and got[:8] == ["wide"] * 8 and got[11:19] == ["wide"] * 8
    flat = classes(lambda f: -3 if f < 20 else -120, list(range(24)), 3)
    assert "closed" not in flat[:19]                          # a steady vowel stays open: no dip, no flap
    mixed = {f: v for f, v in enumerate([-40] * 3 + [-12, -5, -4, -12] + [-40] * 6)}
    got = classes(lambda f: mixed.get(f, -120), list(range(13)), 3)
    assert all(c in TALK for c in got[2:6])                   # open, wide, wide, open: one syllable, open
    blip = {f: v for f, v in enumerate([-40] * 3 + [-10] + [-40] * 6)}
    got = classes(lambda f: blip.get(f, -120), list(range(10)), 3)
    assert got[2:5] == ["open"] * 3                           # a one-frame syllable opens for the hold
    assert [c for _, _, c in runs(["a", "a", "b", "a"])] == ["a", "b", "a"]
    vocab = {"a": {"closed": [("c",)], "open": [("o",)]}}
    face = Face("t", "opening", "x", (), (0, 0), (), {}, 2, "")
    japanese = {f: ("o",) if 4 <= f < 8 else ("c",) for f in range(12)}
    want, _ = plan(face, vocab, lambda f: -40, list(range(12)), japanese)
    assert all(want[f] == ("c",) for f in range(12))   # silence closes a talking Japanese frame
    want, _ = plan(face, vocab, lambda f: -10 if 2 <= f < 6 else -40, list(range(12)), {f: ("c",) for f in range(12)})
    assert want[2] == ("o",) and want[10] == ("c",)
    recs = [(0, 0, 0, 0x2040, 2, 0, 0), (0, 0, 0, 0x0001, 3, 0, 0)]
    order = sinks(recs, True)
    assert order[1] == [("now", 0), ("spill", 0, 1)] and order[2] == [("now", 1)] and order[4] == [("spill", 1, 2)]
    assert order.get(0) is None
    print("self-test passed")


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    p.add_argument("--self-test", action="store_true")
    sub = p.add_subparsers(dest="cmd")
    s = sub.add_parser("measure", help="write manifests/dub_mouths.json from the mix receipt's takes")
    s.add_argument("--receipt", type=Path, default=DUB_MIX)
    a = p.parse_args(argv)
    if a.self_test:
        self_test()
        return 0
    if a.cmd != "measure":
        p.error("name a command or --self-test")
    rows = measure(a.receipt)
    doc = {"schema": 2, "what": "the redub's lines whose lips the restoration EX redraws (english_mouths.py): "
                                "each take's speech-band level per frame of its scene's game clock from first "
                                "(floor(start * 59.637)), dB under the take's 95th percentile",
           "lines": rows}
    text = json.dumps(doc, indent=1)
    for row in rows.values():
        text = text.replace(json.dumps(row["levels_db"], indent=1).replace("\n", "\n   "), json.dumps(row["levels_db"]))
    MOUTHS.write_text(text + "\n")
    for lid, row in rows.items():
        print(f"{lid}: {len(row['levels_db'])} frames from {row['first']} ({row['takes_set']})")
    return 0


if __name__ == "__main__":
    sys.exit(main())
