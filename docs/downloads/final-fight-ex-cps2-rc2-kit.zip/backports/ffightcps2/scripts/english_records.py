#!/usr/bin/env python3
"""The English restoration's story records, on the Japanese timeline.

The approved English (text/english_decisions.json, text/english_round2.json)
is laid out by english_layout.py and written into new typewriter records:

- **Which records.** The restoration fires the Japanese script (line table
  0x179A1) and the Japanese ending ids, so every line keeps its Japanese
  slot and hold (the export script, 0x17986, types the TV lines in slots 10,
  12 and 14, the Japanese in 10, 11 and 15); each Japanese text record is
  replaced by its approved English.
- **Placement.** The typewriter ($1380) finds a record through the 16-bit
  offset table at 0x68566 (``lea (a1,d0.w),a1``, so within 32 KiB of it),
  where no space is free. Its lookup at 0x139E (14 bytes) becomes a call to
  a four-instruction routine at 0x72602 that reads a table of long pointers
  (the stock record's address for every record the restoration keeps), and
  the new records follow it in the free run 0x72602-0x7FFFF. The same bytes
  go into the CPS1 oracle (english_oracle.py), so both boards spend the same
  cycles.
- **Timing.** A scene moves on when its line has typed and its hold has
  run. A record that fits types in exactly its Japanese line's frames: the
  slowest speed up to the Japanese one that fits and divides those frames,
  then spaces typed off screen at cell (0, 0) for the rest. Spaces between
  words are segment breaks and cost nothing. Story captions longer than
  their Japanese lines (17 October: squeezed into the Japanese
  frames, they typed at twice the speed of every other caption) type at the
  Japanese speed, as the USA arcade's English does, and the scene waits for
  them; the intro then runs longer, so the opening song (cue 0x52, timed by
  Capcom to end on the title) plays one more round of its own mid-song
  repeat (ARCADE_OPENING_ROUNDS, ff_audio.opening_songs), 768 ticks, and
  the frames that round adds beyond the slower typing go to those
  captions' holds, in proportion to the frames each typed past its
  Japanese line, so the intro grows by exactly the round
  (SONG_EXTRA_FRAMES) and the song still ends on the title. Guy's and
  Haggar's profiles type longer than theirs even at a frame a character
  (the name line types twice, as its upper and lower halves; the Japanese
  and USA profiles type at that speed too), so their 90-frame holds shrink
  by the difference.
- **The year card** (group A 0x08, drawn at once) is rewritten in place:
  its stock record is longer.
- **The staff messages after END** (group A 0x0A, 0x0B, 0x0D, 0x0E,
  text/english_staff.json): the instant printer ($1308) has the same 16-bit
  reach from 0x67082, so its two lookups (0x130E draws, 0x1350 erases) call
  the same routine with a table of its own. Records 0x0D and 0x0E draw a
  32x32 portrait from tiles 0x4900-0x4937, which hold part of the FBI seal
  in the World set the edition uses; the portraits move to scroll 1 codes
  0x8000-0x8037 (glyphs 0x3C00 on), which address CPS2 graphics past the
  CPS1 copy (build_m1_spike places the Japanese tiles there; the CPS1
  oracle has no such tiles and leaves those two portraits blank).

``patches(stock)`` returns stock-checked patch entries for
build_m1_spike.apply_patches; ``receipt`` describes them.

    python3 english_records.py --self-test
"""
from __future__ import annotations

import json
from pathlib import Path
import struct
import sys

import english_layout as layout
import text_catalog as tc

TRACK = Path(__file__).resolve().parents[1]
TEXT = TRACK / "text"
LOOKUP = 0x139E
LOOKUP_STOCK = "43f9000685663031000043f10000"   # lea $68566,a1; move.w (a1,d0.w),d0; lea (a1,d0.w),a1
HOME, HOME_END = 0x72602, 0x80000
RECORDS = 63                                    # entries of the group 1 table
STAFF_LOOKUPS = (0x130E, 0x1350)                # the instant printer's draw and erase lookups
STAFF_LOOKUP_STOCK = "43f9000670823031000043f10000"
STAFF = (0x0A, 0x0B, 0x0D, 0x0E)
PORTRAIT_GLYPHS = (0x500, 0x538)                # tiles 0x4900-0x4937
PORTRAIT_BASE = 0x3C00                          # glyph of scroll 1 code 0x8000 (CPS2 only)
PROFILE_HOLDS = {"profile-guy": 0x17BBC, "profile-cody": 0x17CF4, "profile-haggar": 0x17E2C}
PROFILE_HOLD = 90
STORY_LINES = 0x179A1                           # the Japanese script's line table (text_catalog.LINES)
# The hold each story line's state sets as it fires the line, run after the
# line has typed: the immediate word of its move.w #n,-$6d70(a5) (stock frames).
STORY_HOLDS = {0: (0x1718E, 50), 1: (0x17220, 50), 2: (0x1724C, 50), 3: (0x17274, 50),
               4: (0x17376, 40), 5: (0x1739E, 40), 6: (0x173C8, 40), 7: (0x17444, 40),
               8: (0x1746C, 40), 9: (0x17494, 40), 10: (0x1767E, 40), 11: (0x176A6, 40),
               12: (0x176D0, 40), 13: (0x1772C, 40), 14: (0x17754, 40), 15: (0x17786, 40),
               16: (0x17846, 40), 17: (0x178D0, 40), 18: (0x178FA, 50), 19: (0x17922, 40)}
ARCADE_OPENING_ROUNDS = (2, 0)                  # fmloop.apply_opening_loop: the song's repeat once more
SONG_EXTRA_FRAMES = 429                         # that round: 768 ticks at 0.5585 frames a tick (fmloop.py)
YEAR = ("year", 0x08)
ENDINGS = {   # approved passages: (palette, first line, line count, first row, pause) per block,
              #   the blocks and pauses of the stock English records 0x13A and 0x13C
    "ending-reunion": [(6, 0, 2, 6, 0), (14, 2, 2, 11, 0), (14, 4, 5, 15, 16)],
    "ending-father": [(6, 0, 1, 26, 16)],
}


def approved():
    """id -> (Japanese record id, layout record at delay 1)."""
    lines = {r["id"]: r for r in json.loads((TEXT / "english_decisions.json").read_text())["lines"]}
    round2 = {p["id"]: p for p in json.loads((TEXT / "english_round2.json").read_text())["proposals"]}
    props = {e["id"]: e for e in json.loads((TEXT / "english_proposals.json").read_text())["entries"]}
    out = {}
    for pid, row in lines.items():
        if not row["decision"].startswith(("approved", "author's wording")):
            raise ValueError(f"{pid} is not approved: {row['decision']}")
        text = row.get("lines") or row["text"]
        if pid in round2 and round2[pid]["layout"] == "profile":
            rec = layout.profile(round2[pid]["name"], round2[pid]["body"])
        elif pid in round2:
            rec = layout.ending([(p["pal"], p["lines"], p["row"], p["pause"]) for p in round2[pid]["parts"]], 1)
        elif pid in ENDINGS:
            rec = layout.ending([(pal, text[a:a + n], r, pause) for pal, a, n, r, pause in ENDINGS[pid]], 1)
        elif pid == YEAR[0]:
            rec = layout.caption(text, "card", 14, 1)
        else:
            rec = layout.caption(text, "map" if pid.startswith("map") else "story", 14, 1)
        out[pid] = (int(props[pid]["japan_record"], 16), rec)
    return out


def glyph_words(rec):
    return sum(len(s["glyphs"]) for s in rec["segments"])


def fit(rec, jp_frames, jp_delay, mode):
    """The record at the slowest delay (up to the Japanese one) that types in
    at most ``jp_frames`` and divides them, padded to exactly ``jp_frames``;
    when none fits, delay 1 and the overflow in frames (for the hold)."""
    words = glyph_words(rec)
    space = layout.LARGE_SPACE if mode == 2 else layout.SMALL_SPACE
    for delay in range(jp_delay, 0, -1):
        if delay * words <= jp_frames and jp_frames % delay == 0:
            pad = jp_frames // delay - words
            segs = rec["segments"] + ([{"col": 0, "row": 0, "pal": 0, "glyphs": [space] * pad}] if pad else [])
            return {**rec, "delay": delay, "segments": segs}, 0
    return {**rec, "delay": 1}, words - jp_frames


def fit_story(rec, jp_frames, jp_delay):
    """A story caption at the Japanese speed: (record, frames it types past
    the Japanese line). One that fits is fit()'s; a longer one types on."""
    words = glyph_words(rec)
    if jp_delay * words <= jp_frames:
        return fit(rec, jp_frames, jp_delay, rec["mode"])
    return {**rec, "delay": jp_delay}, jp_delay * words - jp_frames


def share(total, weights):
    """total frames shared in proportion to weights {key: w}, largest
    remainders rounded up, so the parts add up to total exactly."""
    whole = sum(weights.values())
    raw = {k: total * w / whole for k, w in weights.items()}
    out = {k: int(v) for k, v in raw.items()}
    for k in sorted(raw, key=lambda k: (out[k] - raw[k], k))[:total - sum(out.values())]:
        out[k] += 1
    return out


def encode(rec, header=True):
    out = bytes([rec["delay"], rec["mode"]]) if header else b""
    for k, s in enumerate(rec["segments"]):
        if k:
            out += b"\x80\x00"
        out += struct.pack(">HH", s["col"] * 0x80 + s["row"] * 4, s["pal"])
        out += b"".join(struct.pack(">H", g) for g in s["glyphs"])
    return out + b"\x00\x00"


def year_record(rec):
    """Group A draws at once, both rows given: the glyphs, then their lower
    halves (spaces stay spaces)."""
    segs = rec["segments"]
    col, row = segs[0]["col"], segs[0]["row"]
    line = [layout.LARGE_SPACE] * (max(s["col"] + len(s["glyphs"]) for s in segs) - col)
    for s in segs:
        line[s["col"] - col:s["col"] - col + len(s["glyphs"])] = s["glyphs"]
    lower = [g if g == layout.LARGE_SPACE else g + 0x10 for g in line]
    return {"delay": None, "mode": 0, "segments": [{"col": col, "row": row, "pal": segs[0]["pal"], "glyphs": line},
                                                    {"col": col, "row": row + 1, "pal": segs[0]["pal"], "glyphs": lower}]}


def staff_records(stock):
    """index -> segments for the instant records of the staff messages."""
    entries = json.loads((TEXT / "english_staff.json").read_text())["entries"]
    out = {}
    for index in STAFF:
        mine = [e for e in entries if int(e["japan_record"], 16) == 0xA00 + index]
        if mine[0]["layout"]["kind"] == "box":
            segs = layout.staff_box(mine[0]["lines"])
        else:
            segs = layout.staff_list([(e["lines"], e["layout"]) for e in sorted(mine, key=lambda e: e["message"])])
        for s in tc.record(stock, "gA", index)["segments"]:
            if s["glyphs"] and all(PORTRAIT_GLYPHS[0] <= g < PORTRAIT_GLYPHS[1] for g in s["glyphs"]):
                segs.append({**s, "glyphs": [g - PORTRAIT_GLYPHS[0] + PORTRAIT_BASE for g in s["glyphs"]]})
        out[index] = segs
    return out


def build(stock):
    """(patch entries, receipt) for the stock program bytes."""
    stock = bytes(stock)
    if stock[LOOKUP:LOOKUP + 14].hex() != LOOKUP_STOCK:
        raise ValueError("the typewriter's record lookup is not stock")
    if any(stock[a:a + 14].hex() != STAFF_LOOKUP_STOCK for a in STAFF_LOOKUPS):
        raise ValueError("the instant printer's record lookups are not stock")
    table = [tc.GROUP1 + tc.word(stock, tc.GROUP1 + 2 * i) for i in range(RECORDS)]
    staff_count = tc.word(stock, tc.GROUPA) // 2
    table_a = [tc.GROUPA + tc.word(stock, tc.GROUPA + 2 * i) for i in range(staff_count)]
    lines = approved()
    code_end = HOME + 24
    story_line = {0x100 + stock[STORY_LINES + n]: n for n in STORY_HOLDS}
    records, holds, rows, extra = {}, {}, [], {}
    for pid, (jp_id, rec) in lines.items():
        if pid == YEAR[0]:
            continue
        jp = tc.record(stock, "g1", jp_id - 0x100)
        jp_frames = jp["delay"] * sum(len(s["glyphs"]) for s in jp["segments"])
        if rec["mode"] == 2:                # a caption: the Japanese speaker's palette
            pal = next(s["pal"] for s in jp["segments"] if s["glyphs"])
            rec["segments"] = [{**s, "pal": pal} for s in rec["segments"]]
        if jp_id in story_line:             # a story caption: the Japanese speed, the scene waits
            fitted, longer = fit_story(rec, jp_frames, jp["delay"])
            over = 0
            if longer:
                extra[pid] = longer
        else:
            fitted, over = fit(rec, jp_frames, jp["delay"], rec["mode"])
        if over:
            if pid not in PROFILE_HOLDS:
                raise ValueError(f"{pid} cannot type within its Japanese {jp_frames} frames")
            holds[pid] = PROFILE_HOLD - over
        records[jp_id - 0x100] = encode(fitted)
        rows.append({"id": pid, "record": f"{jp_id:#05x}", "japanese_frames": jp_frames, "delay": fitted["delay"],
                     "frames": fitted["delay"] * glyph_words(fitted), "hold_change": -over or None,
                     "palettes": sorted({s["pal"] for s in fitted["segments"] if s["col"] or s["row"]}),
                     "bytes": len(records[jp_id - 0x100])})
    spare = SONG_EXTRA_FRAMES - sum(extra.values())
    if spare < 0:
        raise ValueError(f"the story captions type {-spare} frames past the opening song's extra round")
    added = share(spare, extra) if extra else {}
    by_id = {pid: jp_id for pid, (jp_id, _) in lines.items()}
    story_holds = {}
    for row in rows:
        if row["id"] in extra:
            line = story_line[by_id[row["id"]]]
            address, stock_hold = STORY_HOLDS[line]
            row.update(line=line, extra_frames=extra[row["id"]], hold=stock_hold + added[row["id"]],
                       hold_added=added[row["id"]])
            story_holds[row["id"]] = (address, stock_hold, stock_hold + added[row["id"]])
    staff = {index: encode({"segments": segs}, header=False) for index, segs in staff_records(stock).items()}
    blob = bytearray()
    table_at = code_end
    table_a_at = table_at + 4 * RECORDS
    at = table_a_at + 4 * staff_count
    for index in sorted(records):
        table[index] = at + len(blob)
        blob += records[index]
    for index in sorted(staff):
        table_a[index] = at + len(blob)
        blob += staff[index]
    lookup = struct.pack(">HHhHHH", 0xD040, 0x43FA, table_at - (HOME + 4), 0x2271, 0x0000, 0x4E75)
    lookup_a = struct.pack(">HHhHHH", 0xD040, 0x43FA, table_a_at - (HOME + 16), 0x2271, 0x0000, 0x4E75)
    block = (lookup + lookup_a + b"".join(struct.pack(">I", a) for a in table)
             + b"".join(struct.pack(">I", a) for a in table_a) + bytes(blob))
    if HOME + len(block) > HOME_END:
        raise ValueError("the restoration's records overrun their free space")
    if any(b != 0xFF for b in stock[HOME:HOME + len(block)]):
        raise ValueError("the restoration's record space is not free")
    patches = [
        (LOOKUP, LOOKUP_STOCK, "4eb9" + f"{HOME:08x}" + "4e71" * 4,
         "story text: the typewriter's record lookup calls the restoration's long-pointer table (english_records.py)"),
        (HOME, "ff" * len(block), block.hex(),
         "story text: the lookup routines, their tables and the restoration's records (english_records.py)"),
    ] + [(a, STAFF_LOOKUP_STOCK, "4eb9" + f"{HOME + 12:08x}" + "4e71" * 4,
          "staff messages: the instant printer's record lookup calls the restoration's table (english_records.py)")
         for a in STAFF_LOOKUPS]
    for pid, value in holds.items():
        a = PROFILE_HOLDS[pid]
        patches.append((a, f"{PROFILE_HOLD:04x}", f"{value:04x}",
                        f"{pid}: the hold after typing, {PROFILE_HOLD} -> {value} frames (english_records.py)"))
    for pid, (a, old_hold, value) in story_holds.items():
        if value != old_hold:
            patches.append((a, f"{old_hold:04x}", f"{value:04x}",
                            f"{pid}: the hold after typing, {old_hold} -> {value} frames, its share of the "
                            "opening song's extra round (english_records.py)"))
    # the year card, in place
    rec = tc.record(stock, "gA", YEAR[1])
    year = year_record(lines[YEAR[0]][1])
    year["segments"] = [{**s, "pal": rec["segments"][0]["pal"]} for s in year["segments"]]
    end = rec["address"]
    while True:                             # the stock record's own bytes, through its 0 word
        end += 4
        while (g := tc.word(stock, end)) and not g & 0x8000:
            end += 2
        end += 2
        if not g:
            break
    old = bytes(stock[rec["address"]:end])
    new = encode(year, header=False)
    if len(new) > len(old):
        raise ValueError("the year card does not fit in place")
    new += bytes(stock[rec["address"] + len(new):rec["address"] + len(old)])
    patches.append((rec["address"], old.hex(), new.hex(), "the year card: \"Sometime in 1989...\" (english_records.py)"))
    receipt = {"lookup": f"{LOOKUP:#x}", "home": f"{HOME:#x}", "block_bytes": len(block),
               "table": f"{table_at:#x}", "records": rows,
               "staff": {"lookups": [f"{a:#x}" for a in STAFF_LOOKUPS], "table": f"{table_a_at:#x}",
                         "records": {f"{0xA00 + i:#05x}": len(b) for i, b in staff.items()},
                         "portraits": "scroll 1 codes 0x8000-0x8037 (CPS2 only)",
                         "status": "approved in round 3 (text/english_decisions.json)"},
               "profile_holds": {k: v for k, v in holds.items()},
               "story": {"arcade_opening_rounds": list(ARCADE_OPENING_ROUNDS),
                         "song_extra_frames": SONG_EXTRA_FRAMES,
                         "typing_past_japanese": dict(extra), "holds_added": added,
                         "intro_longer_by_frames": sum(extra.values()) + sum(added.values())}}
    return patches, receipt


def hyphen_cells():
    """(column, row) of the top cell of each caption hyphen the restoration's
    story records draw (build_m1_spike.CAPTION_HYPHEN, whose bar is on rows
    6-7 of that cell): the CPS2 build draws it there, and the CPS1 oracle,
    without CPS2's tiles, draws nothing. One column a glyph, as captions go."""
    return sorted({(s["col"] + i, s["row"]) for _, rec in approved().values() for s in rec["segments"]
                   for i, g in enumerate(s["glyphs"]) if g == layout.LARGE["-"]})


def self_test():
    rec = {"delay": 1, "mode": 2, "segments": [{"col": 9, "row": 23, "pal": 15, "glyphs": [0x580] * 10}]}
    fitted, over = fit(rec, 64, 2, 2)
    assert fitted["delay"] == 2 and glyph_words(fitted) * 2 == 64 and not over
    assert fitted["segments"][-1]["glyphs"] == [layout.LARGE_SPACE] * 22
    fitted, over = fit(rec, 15, 2, 2)
    assert fitted["delay"] == 1 and glyph_words(fitted) == 15
    _, over = fit(rec, 7, 1, 0)
    assert over == 3
    fitted, longer = fit_story(rec, 15, 2)
    assert fitted["delay"] == 2 and longer == 5 and glyph_words(fitted) == 10
    fitted, longer = fit_story(rec, 64, 2)
    assert fitted["delay"] == 2 and not longer and glyph_words(fitted) * 2 == 64
    assert share(10, {"a": 1, "b": 1, "c": 1}) == {"a": 4, "b": 3, "c": 3}
    assert sum(share(209, {"x": 14, "y": 58, "z": 4}).values()) == 209
    assert round(768 * 0.5585) == SONG_EXTRA_FRAMES
    assert encode({"delay": 2, "mode": 2, "segments": [{"col": 1, "row": 2, "pal": 3, "glyphs": [5]},
                                                        {"col": 4, "row": 2, "pal": 3, "glyphs": [6]}]}).hex() == \
        "0202" + "0088" + "0003" + "0005" + "8000" + "0208" + "0003" + "0006" + "0000"
    print("self-test passed")


if __name__ == "__main__":
    if "--self-test" in sys.argv:
        self_test()
    else:
        import build_m1_spike as spike
        program = spike.stock_program(spike.find_archive(spike.default_rompaths(), "ffightj"))
        patches, receipt = build(program)
        print(json.dumps(receipt, indent=1))
