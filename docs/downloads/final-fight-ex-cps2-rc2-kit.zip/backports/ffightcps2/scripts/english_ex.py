#!/usr/bin/env python3
"""The restoration EX's captions: the approved English in Japanese EX's Sega CD scenes.

The restoration EX (EX_PHASE0.md, "The English restoration and EX") plays
Japanese EX's scenes on the English restoration. Its CD opening shows the
captions CPS1 Final Fight EX's Japanese build shows: the arcade's own
Japanese story records (map, phone, TV, Guy and Cody, the year card), fired
by the opening engine's caption schedule. Here those records carry the
restoration's approved English (text/english_decisions.json), the same
wording the restoration's stock story shows for the same records (the
translation guidelines' presumption of reuse), laid out for the CD scenes as
CPS1 EX lays out its US captions: centered, large, on rows 21/23/25, 22/24
or 23 (english_layout's ``story`` band).

Where CPS1 EX's Japanese records differ from the arcade's, the English
follows the same structure without changing approved wording:

- map 0x12C keeps its first two lines and the last two move to 0x122 (empty
  in the arcade's Japanese), so map-2's four approved lines split after the
  second;
- map 0x12A drops ちょうはんざいとし (crime capital) in Japanese EX; map-0's
  approved English is kept whole;
- the year card reads 1992年 in Japanese EX (the Japanese disc's year, which
  the narration speaks): "Sometime in 1992..." (YEAR_PROPOSAL, approved
  on 17 October; text/english_ex_decisions.json), where the
  restoration's stock-story card keeps the approved 1989.

The decisions (text/english_ex_decisions.json) approve new wording by id
and the exact lines' hash; a line whose hash does not match is not shown (the
year card falls back to the approved 1989), so a wording change needs a new
approval.

Each CD record types at Japanese EX's delay when it fits its caption window
(the schedule's time from the record to the band's next clear, less
MARGIN frames), else a frame a glyph; the build fails when even that does
not fit. Every other record is the restoration's (english_records.py).

The schedule is the redub's (retime(), DUB.md): each caption moves with its
English line when the line starts late and stays until the English voice
ends; captions show what is spoken (Damnd's phone-5 as the approved spoken
variant, SPOKEN_CAPTIONS) and the redub's new line "Hang on, Jessica!" has a
caption of its own (NEW_CAPTIONS) in record 0x123, empty in the Japanese.

The typewriter's and instant printer's lookups (0x139E, 0x130E, 0x1350),
which CUT SCENES and the restoration both replace, call the layer's
ex_text_1e and ex_text_ae, which take the restoration's long-pointer tables
with CUT SCENES ARCADE and these CD tables with SEGA CD.

    python3 english_ex.py --self-test
"""
from __future__ import annotations

import hashlib
import json
import struct
import sys

import dub_words
import english_layout as layout
import english_records as er
import text_catalog as tc

HOME = 0x2E0000             # the CD tables and records, in free upper program ROM
CAPTAB = 0x2C0              # the opening's caption schedule in the scenes' data ROM (engine.py)
CLEAR = 0x0200              # its band clear
MARGIN = 4                  # frames a record finishes typing before the clear
# Japanese EX's caption records -> (approved English id, its lines), in the
# CD layout; 0x12C and 0x122 share map-2.
CD_RECORDS = {
    0x12A: ("map-0", None), 0x12B: ("map-1", None), 0x12C: ("map-2", (0, 2)), 0x122: ("map-2", (2, 4)),
    0x12D: ("map-3", None), 0x11A: ("phone-4", None), 0x11B: ("phone-5", None), 0x11C: ("phone-6", None),
    0x11D: ("phone-7", None), 0x11E: ("phone-8", None), 0x11F: ("phone-9", None), 0x120: ("tv-10", None),
    0x121: ("tv-11", None), 0x125: ("tv-15", None), 0x126: ("guycody-16", None), 0x127: ("guycody-17", None),
    0x128: ("guycody-18", None), 0x129: ("guycody-19", None),
}
# A caption whose spoken English is the approved shorter variant shows what
# is spoken (17 October: "caption should match what's spoken"): its approval in
# text/english_ex_decisions.json, by the spoken wording's hash, gives the
# caption's line breaks (caption_lines, the same words).
SPOKEN_CAPTIONS = {"phone-5": "dub-spoken-op07"}
YEAR_RECORD = 0x09          # group A: Japanese EX's year card
# The dub's caption timing (17 October: captions move with the English
# when it starts late, and match what is spoken; DUB.md). The opening's
# schedule frame f types at t = (f + SCHEDULE_LEAD) / FRAME_HZ on the redub's
# game clock: MEASURED in MAME on program 0edae41e, the scene state took CAFE
# at frame 1164, the voiced key 0x0172 posted at 1166 (the clock's zero), and
# every caption started typing 150 frames after the anchor plus its schedule
# frame. The mix's receipt (dub_mix_receipt.json) gives each line's English
# start and end.
DUB_MIX = er.TRACK / "manifests" / "dub_mix_receipt.json"
DUB_LINES = er.TRACK / "manifests" / "dub_lines.json"
FRAME_HZ = 59.637
SCHEDULE_LEAD = 148
PRE_CLEAR = 6               # the band clears this many frames before a caption types (Japanese EX's spacing)
HOLD_S = 0.4                # a caption stays at least this long after its English voice ends
JOIN_S = 1.0                # a caption ending closer than this to the next one's clear stays until that clear
# Each caption types from CAPTION_LEAD_S before the English word it begins with (dub_words.json: the
# words as the mix places them; 21 October, on the redub's Arrange kit: "Captions don't line up
# to vocals in some spots", "Ending captions ... don't align with vocals"). Japanese EX's own captions
# sit as much as 1.7 s off its voices (the arcade's text schedule), so a caption moved only by its
# line's push kept that.
CAPTION_LEAD_S = 0.1
# The ending's engines count their own frames: the voiced ending key posts a frame after the reunion
# engine's INIT (the ending track's zero), and the farewell engine's INIT comes FAREWELL_INIT_FRAMES
# after the reunion's (MEASURED in MAME, the restoration program on 21 October; the restoration gate
# measures it again and fails when it moves). An engine frame f plays at (f + base) / FRAME_HZ.
ENDING_KEY_LAG = 1
FAREWELL_INIT_FRAMES = 5620
ENDING_BASE = {"ending": -ENDING_KEY_LAG, "farewell": FAREWELL_INIT_FRAMES - ENDING_KEY_LAG}
SLOTS = (0x380 - 0x2C0) // 4    # the schedule's room: CAPTAB to CAPPAL (ffightcd build/engine.py), the end mark included
# The Japanese opening's shots (ffightcd data/ending/jp_opening_shots.tsv: f_start, f_end in the engine's
# frames, the caption schedule's numbering). A caption moved for the English stays inside its shot: it
# starts no earlier than its shot and is held no later than the shot's last frame, unless Japanese
# EX's own caption already ran past it (21 October: "Some of the captions linger after a scene
# changes (launching an... as an example)").
SHOTS = er.TRACK.parents[1] / "backports" / "ffightcd" / "data" / "ending" / "jp_opening_shots.tsv"


def shots():
    """[(f_start, f_end)] of the Japanese opening's shots, in order, in the caption schedule's frames (the
    table counts from the scene's start: schedule frame + SCHEDULE_LEAD; the 0x12c caption types 13
    frames into shot 2)."""
    rows = []
    for line in SHOTS.read_text().splitlines():
        if line.strip() and not line.startswith("#"):
            cells = line.split("\t")
            rows.append((int(cells[1]) - SCHEDULE_LEAD, int(cells[2]) - SCHEDULE_LEAD))
    return rows


def in_shot(t, ja_t, ja_end, end):
    """(start, end) of a moved caption kept inside the shot its Japanese caption types in."""
    rows = shots()
    k = max((i for i, (a, _) in enumerate(rows) if a <= ja_t), default=0)
    first = rows[k][0]
    cut = rows[k][1] + 1 if k + 1 < len(rows) else None     # the frame after the shot's last
    start = max(t, first)
    if cut is not None and ja_end <= cut:
        end = min(end, cut)
    return start, max(end, start + 1)
DUB_CAPTIONS = {0x12A: "op01", 0x12B: "op02", 0x12C: "op03", 0x122: "op03", 0x12D: "op04", 0xA09: "op05",
                0x11A: "op06", 0x11B: "op07", 0x11C: "op08", 0x11D: "op09", 0x11E: "op10", 0x11F: "op11",
                0x120: "op12", 0x121: "op13", 0x125: "op14", 0x126: "op15", 0x127: "op16", 0x128: "op17",
                0x129: "op18"}
# Spoken lines no Japanese caption carries, captioned in a record empty in the
# Japanese schedule: record -> (approval id, dub line, the record whose
# palette (speaker) it takes, the records whose timing against their voices it takes).
NEW_CAPTIONS = {0x123: ("dub-op19", "op19", 0x126, (0x126, 0x127, 0x128, 0x129))}
YEAR_PROPOSAL = {"id": "year-cd", "japanese_ex": "1992年のことである・・・", "approved": "year",
                 "proposed": ["Sometime in 1992..."],         # approved 17 October
                 "reason": "Japanese EX's card (CPS1 EX) gives the Japanese disc's year, 1992, which its "
                           "narration speaks; the restoration's approved card gives the arcade's 1989"}


ENDING = er.TEXT / "english_ex_ending.json"
DECISIONS = er.TEXT / "english_ex_decisions.json"


def approved_new(pid, lines):
    """Whether these exact lines are approved for a new id."""
    row = json.loads(DECISIONS.read_text())["approvals"].get(pid)
    return bool(row) and row["sha256"] == wording_hash(lines) and row["lines"] == list(lines)


def ending_lines():
    """{"ending": [...], "farewell": [...]} for CPS1 EX's rom.py --captions: each
    entry's lines, or None for a new translation whose exact lines are
    not approved (text/english_ex_decisions.json). Fails unless every catalog
    id's lines, joined, are its approved wording."""
    plan = json.loads(ENDING.read_text())
    approved = decisions()
    out, joined = {}, {}
    for key in ("ending", "farewell"):
        out[key] = []
        for entry in plan[key]:
            if entry["id"] not in approved:
                ok = approved_new(entry["id"], entry["lines"])
                out[key].append(list(entry["lines"]) if ok else None)
                continue
            joined.setdefault(entry["id"], []).extend(entry["lines"])
            out[key].append(list(entry["lines"]))
    for pid, lines in joined.items():
        row = approved[pid]
        if not row["decision"].startswith(("approved", "author's wording")):
            raise ValueError(f"{pid} is not approved: {row['decision']}")
        want = row.get("lines") or row["text"]
        if " ".join(lines) != " ".join(want):
            raise ValueError(f"the CD ending's lines for {pid} are not its approved wording")
    return out


# The speakers' palettes of Japanese EX's ending entries, in order (rom.py
# keeps each entry's own: Jessica and Guy 6, Haggar and Cody 14), for checks.
ENDING_PALETTES = {"ending": [6, 14, 14, 14, 14, 6, 14, 6, 14], "farewell": [6, 14, 14, 14, 6]}


def ending_palettes():
    return ENDING_PALETTES


def decisions():
    return {r["id"]: r for r in json.loads((er.TEXT / "english_decisions.json").read_text())["lines"]}


def wording_hash(lines):
    return hashlib.sha256("\n".join(lines).encode()).hexdigest()


def schedule(data):
    """[(frame, text id)] of the opening's caption schedule."""
    out, at = [], CAPTAB
    while True:
        t, tid = struct.unpack(">HH", data[at:at + 4])
        if t == 0xFFFF:
            return out
        out.append((t, tid))
        at += 4


# The ending's captions (E-CAPS windows, ffightcd build/rom.py --captions) per
# English line, in schedule order; the farewell's middle three are en12's.
DUB_ENDING = {"ending": ["en01", "en02", "en03", "en04", "en05", "en06", "en07", "en08", "en09"],
              "farewell": ["en11", "en12", "en12", "en12", "en13"]}


def ending_frames():
    """{key: [[start, end]]}: each ending caption's frames on its engine's clock (ENDING_BASE), from
    CAPTION_LEAD_S before the English word it begins with (dub_words.json), a line's last caption held
    to its English end plus HOLD_S, an earlier one until the next (rom.py english_captions keeps every
    entry before the next one's start)."""
    mix = {r["id"]: r for r in json.loads(DUB_MIX.read_text())["scenes"]["ending"]["lines"]}
    texts = ending_lines()
    out = {}
    for key, ids in DUB_ENDING.items():
        base = ENDING_BASE[key]
        starts = word_starts([(k, lid, " ".join(texts[key][k] or [])) for k, lid in enumerate(ids)], "ending")
        rows = [[round((starts.get(k, mix[lid]["start"]) - CAPTION_LEAD_S) * FRAME_HZ) - base, 0]
                for k, lid in enumerate(ids)]
        for k, lid in enumerate(ids):
            last = k + 1 == len(ids) or ids[k + 1] != lid
            rows[k][1] = (round((mix[lid]["end"] + HOLD_S) * FRAME_HZ) - base) if last else rows[k + 1][0] - 1
        out[key] = rows
    return out


ALIGN_EARLY_S, ALIGN_LATE_S = 0.4, 0.1   # a caption's start against its first English word (gates)


def opening_alignment(data):
    """[(record, line, start s, word s, clamped)] for the opening's captions as retime() schedules them:
    each start against the English word it begins with; clamped when its shot holds it later."""
    rows = schedule(data)
    order = [(rid, DUB_CAPTIONS[rid], record_text(rid)) for _, rid in rows if rid in DUB_CAPTIONS]
    order += [(rid, lid, record_text(rid)) for rid, (_, lid, _, _) in NEW_CAPTIONS.items()]
    words = word_starts(order)
    out = []
    for start, rid, _, lid in _dub_events(data):
        if rid in words:
            want = t_frame(words[rid] - CAPTION_LEAD_S)
            out.append((rid, lid, (start + SCHEDULE_LEAD) / FRAME_HZ, words[rid], start != want))
    return out


def ending_alignment(band_frames):
    """[(key, entry, line, shown s, word s)]: band_frames {(key, entry): the frame its caption showed, on
    its engine's clock}, each against the English word it begins with."""
    texts = ending_lines()
    out = []
    for key, ids in DUB_ENDING.items():
        words = word_starts([(k, lid, " ".join(texts[key][k] or [])) for k, lid in enumerate(ids)], "ending")
        for k, lid in enumerate(ids):
            if (key, k) in band_frames and k in words:
                out.append((key, k, lid, (band_frames[(key, k)] + ENDING_BASE[key]) / FRAME_HZ, words[k]))
    return out


def t_frame(t):
    """The opening's schedule frame for game-clock time t (s)."""
    return round(t * FRAME_HZ) - SCHEDULE_LEAD


def record_text(rid):
    """The words a caption record shows: its approved lines (or the approved spoken variant), joined."""
    approvals = json.loads(DECISIONS.read_text())["approvals"]
    if rid in CD_RECORDS:
        pid, part = CD_RECORDS[rid]
        spoken = SPOKEN_CAPTIONS.get(pid)
        if spoken and approvals.get(spoken) and approved_new(spoken, approvals[spoken]["lines"]):
            return " ".join(approvals[spoken]["caption_lines"])
        row = decisions()[pid]
        text = row.get("lines") or row["text"]
        text = [text] if isinstance(text, str) else text
        return " ".join(text[part[0]:part[1]] if part else text)
    if rid == 0xA00 + YEAR_RECORD:
        return " ".join(YEAR_PROPOSAL["proposed"])
    if rid in NEW_CAPTIONS and approvals.get(NEW_CAPTIONS[rid][0]):
        return " ".join(approvals[NEW_CAPTIONS[rid][0]]["lines"])
    return ""


def word_starts(records, scene="opening"):
    """{record: time (s) of the English word it begins with} for (record, line) pairs in their order: a
    line's first record at its first word, each later one at its own first word (dub_words.find)."""
    words = dub_words.load(scene)
    out, at = {}, {}
    for rid, lid, text in records:
        heard = words.get(lid, {}).get("words")
        if not heard:
            continue
        k = 0 if lid not in at else dub_words.find(heard, text, at[lid] + 1)
        at[lid] = k
        out[rid] = heard[k][1]
    return out


def _dub_events(data):
    """[(start frame, record, end frame, line)]: each caption from CAPTION_LEAD_S before the English word
    it begins with, held to its English voice's end (DUB_CAPTIONS), plus the new lines' captions."""
    rows = schedule(data)
    mix = {r["id"]: r for r in json.loads(DUB_MIX.read_text())["scenes"]["opening"]["lines"]}
    order = [(rid, DUB_CAPTIONS[rid], record_text(rid)) for _, rid in rows if rid in DUB_CAPTIONS]
    order += [(rid, lid, record_text(rid)) for rid, (_, lid, _, _) in NEW_CAPTIONS.items()]
    starts = word_starts(order)
    out = []
    for k, (t, rid) in enumerate(rows):
        if rid == CLEAR:
            continue
        end = next(u for u, v in rows[k + 1:] if v == CLEAR)
        lid = DUB_CAPTIONS.get(rid)
        if lid in mix:
            shift = round(mix[lid]["pushed_s"] * FRAME_HZ)
            want = t_frame(starts[rid] - CAPTION_LEAD_S) if rid in starts else t + shift
            hold = t_frame(mix[lid]["end"] + HOLD_S)            # a later record of the line clears it first
            start_, end_ = in_shot(want, t, end, max(end + shift, hold))
            out.append([start_, rid, end_, lid])
        else:
            out.append([t, rid, end, lid])
    for rid, (approval, lid, _, _) in NEW_CAPTIONS.items():
        row = json.loads(DECISIONS.read_text())["approvals"].get(approval)
        if lid not in mix or not row or not approved_new(approval, row["lines"]):
            continue
        t_new = t_frame((starts.get(rid) or mix[lid]["start"]) - CAPTION_LEAD_S)
        start_, end_ = in_shot(t_new, t_new, t_new, t_frame(mix[lid]["end"] + HOLD_S))
        out.append([start_, rid, end_, lid])
    return sorted(out)


def retime(data):
    """(data with the dub's caption schedule at CAPTAB, receipt): each caption
    starts where Japanese EX's does plus its line's push and stays until its
    English voice ends (plus HOLD_S) or the next caption's clear; a clear
    before each caption, and after it only when the next is JOIN_S or more
    away. Fails unless the schedule fits its SLOTS."""
    events = _dub_events(data)
    entries = []
    for k, (start, rid, end, lid) in enumerate(events):
        nxt = events[k + 1][0] if k + 1 < len(events) else None
        if entries and entries[-1][0] >= start - PRE_CLEAR:
            raise ValueError(f"caption {rid:#05x} at {start} runs into the one before it")
        if not (entries and entries[-1][1] == CLEAR and entries[-1][0] == start - PRE_CLEAR):
            entries.append((start - PRE_CLEAR, CLEAR))
        entries.append((start, rid))
        if nxt is None or end < nxt - PRE_CLEAR - round(JOIN_S * FRAME_HZ):
            entries.append((min(end, nxt - PRE_CLEAR - 1) if nxt is not None else end, CLEAR))
    if len(entries) + 1 > SLOTS:
        raise ValueError(f"the dub's caption schedule needs {len(entries) + 1} entries, room for {SLOTS}")
    out = bytearray(data)
    block = b"".join(struct.pack(">HH", t, rid) for t, rid in entries) + b"\xff\xff\x00\x00"
    out[CAPTAB:CAPTAB + 4 * SLOTS] = block + bytes(out[CAPTAB + len(block):CAPTAB + 4 * SLOTS])
    receipt = {"rule": "Japanese EX's caption start plus its line's push; held to the English voice's end plus "
                       f"{HOLD_S} s; new lines' captions at their voices' start plus the neighbours' median offset",
               "frame_hz": FRAME_HZ, "schedule_lead_frames": SCHEDULE_LEAD, "mix_sha256": hashlib.sha256(
                   DUB_MIX.read_bytes()).hexdigest(), "entries": len(entries),
               "captions": [{"record": f"{rid:#05x}", "line": lid, "start": s_, "end": e,
                             "start_s": round((s_ + SCHEDULE_LEAD) / FRAME_HZ, 2)} for s_, rid, e, lid in events]}
    return bytes(out), receipt


def windows(data):
    """{text id: frames from its job to the band's next clear}."""
    rows = schedule(data)
    out = {}
    for k, (t, tid) in enumerate(rows):
        if tid != CLEAR:
            nxt = next((u for u, v in rows[k + 1:] if v == CLEAR), None)
            if nxt is None:
                raise ValueError(f"caption {tid:#05x} at {t} is never cleared")
            out[tid] = min(out.get(tid, 1 << 30), nxt - t)
    return out


def english_tables(story_patches, stock):
    """The restoration's group 1 and group A long-pointer tables, from its block patch."""
    block = next(bytes.fromhex(new) for address, _, new, _ in story_patches if address == er.HOME)
    staff_count = tc.word(stock, tc.GROUPA) // 2
    at = 24
    table = list(struct.unpack(f">{er.RECORDS}I", block[at:at + 4 * er.RECORDS]))
    at += 4 * er.RECORDS
    table_a = list(struct.unpack(f">{staff_count}I", block[at:at + 4 * staff_count]))
    return table, table_a, er.HOME + 24, er.HOME + 24 + 4 * er.RECORDS


def build(stock, scenes_program, scenes_data, story_patches):
    """(block, receipt, (cd table 1, cd table A)) for the restoration EX."""
    stock = bytes(stock)
    lines = decisions()
    table, table_a, _, _ = english_tables(story_patches, stock)
    wins = windows(scenes_data)
    records, rows = {}, []
    for jp_id, (pid, part) in sorted(CD_RECORDS.items()):
        row = lines[pid]
        if not row["decision"].startswith(("approved", "author's wording")):
            raise ValueError(f"{pid} is not approved: {row['decision']}")
        text = row.get("lines") or row["text"]
        shown = text[part[0]:part[1]] if part else text
        decision = row["decision"]
        spoken = SPOKEN_CAPTIONS.get(pid)
        if spoken:
            approval = json.loads(DECISIONS.read_text())["approvals"].get(spoken)
            if approval and approved_new(spoken, approval["lines"]):
                if " ".join(approval["caption_lines"]) != " ".join(approval["lines"]):
                    raise ValueError(f"{spoken}: its caption lines are not its spoken words")
                shown, text = list(approval["caption_lines"]), list(approval["lines"])
                decision = f"the approved spoken variant ({spoken}), captioned as spoken"
        jp = tc.record(scenes_program, "g1", jp_id - 0x100)
        pal = next(s["pal"] for s in jp["segments"] if s["glyphs"])
        rec = layout.caption(shown, "story", pal, jp["delay"])
        glyphs = er.glyph_words(rec)
        window = wins.get(jp_id)
        if window is None:
            raise ValueError(f"{jp_id:#05x} is not in the opening's caption schedule")
        delay = next((d for d in range(jp["delay"], 0, -1) if d * glyphs <= window - MARGIN), None)
        if delay is None:
            raise ValueError(f"{pid} ({jp_id:#05x}) cannot type in its {window}-frame window")
        rec["delay"] = delay
        records[jp_id - 0x100] = er.encode(rec)
        rows.append({"record": f"{jp_id:#05x}", "id": pid, "lines": shown, "wording_sha256": wording_hash(text),
                     "decision": decision, "palette": pal, "delay": delay, "frames": delay * glyphs,
                     "window": window, "rows": sorted({s["row"] for s in rec["segments"]})})
    for jp_id, (approval, lid, like_pal, _) in NEW_CAPTIONS.items():
        row = json.loads(DECISIONS.read_text())["approvals"].get(approval)
        if jp_id not in wins or not row or not approved_new(approval, row["lines"]):
            continue                        # not in the schedule (retime() places it), or not approved
        shown = list(row["lines"])
        like = tc.record(scenes_program, "g1", like_pal - 0x100)
        pal = next(s_["pal"] for s_ in like["segments"] if s_["glyphs"])
        rec = layout.caption(shown, "story", pal, like["delay"])
        glyphs = er.glyph_words(rec)
        delay = next((d for d in range(like["delay"], 0, -1) if d * glyphs <= wins[jp_id] - MARGIN), None)
        if delay is None:
            raise ValueError(f"{approval} ({jp_id:#05x}) cannot type in its {wins[jp_id]}-frame window")
        rec["delay"] = delay
        records[jp_id - 0x100] = er.encode(rec)
        rows.append({"record": f"{jp_id:#05x}", "id": approval, "lines": shown, "wording_sha256": wording_hash(shown),
                     "decision": f"the approved new line ({approval}), captioned as spoken", "palette": pal,
                     "delay": delay, "frames": delay * glyphs, "window": wins[jp_id],
                     "rows": sorted({s_["row"] for s_ in rec["segments"]})})
    year = lines[YEAR_PROPOSAL["approved"]]
    year_text = year.get("lines") or year["text"]
    year_decision = year["decision"]
    if approved_new(YEAR_PROPOSAL["id"], YEAR_PROPOSAL["proposed"]):
        year_text, year_decision = YEAR_PROPOSAL["proposed"], "approved 17 October (english_ex_decisions.json)"
    jp_year = tc.record(scenes_program, "gA", YEAR_RECORD)
    year_rec = er.year_record(layout.caption(year_text, "story", jp_year["segments"][0]["pal"], 1))
    year_bytes = er.encode(year_rec, header=False)

    cd_table, cd_table_a = list(table), list(table_a)
    blob = bytearray()
    at = HOME + 4 * (len(table) + len(table_a))
    for index in sorted(records):
        cd_table[index] = at + len(blob)
        blob += records[index]
    cd_table_a[YEAR_RECORD] = at + len(blob)
    blob += year_bytes
    block = (b"".join(struct.pack(">I", a) for a in cd_table) + b"".join(struct.pack(">I", a) for a in cd_table_a)
             + bytes(blob))
    receipt = {"home": f"{HOME:#x}", "bytes": len(block), "sha256": hashlib.sha256(block).hexdigest(),
               "table_1": f"{HOME:#x}", "table_a": f"{HOME + 4 * len(table):#x}", "records": rows,
               "year_card": {"record": f"{0xA00 + YEAR_RECORD:#05x}", "lines": year_text,
                             "wording_sha256": wording_hash(year_text), "decision": year_decision}}
    return block, receipt, (HOME, HOME + 4 * len(table))


def self_test():
    data = bytearray(0x400)
    rows = [(10, 0x200), (16, 0x12A), (300, 0x200), (306, 0xA09), (500, 0x200)]
    for k, (t, tid) in enumerate(rows):
        data[CAPTAB + 4 * k:CAPTAB + 4 * k + 4] = struct.pack(">HH", t, tid)
    data[CAPTAB + 4 * len(rows):CAPTAB + 4 * len(rows) + 4] = b"\xff\xff\x00\x00"
    assert windows(bytes(data)) == {0x12A: 284, 0xA09: 194}
    assert t_frame((232 + SCHEDULE_LEAD) / FRAME_HZ) == 232
    assert set(DUB_CAPTIONS) == set(CD_RECORDS) | {0x0A00 + YEAR_RECORD}
    assert set(CD_RECORDS[k][0] for k in CD_RECORDS) <= set(decisions())
    assert CD_RECORDS[0x12C][1] == (0, 2) and CD_RECORDS[0x122][1] == (2, 4)
    ending = ending_lines()
    assert len(ending["ending"]) == 9 and len(ending["farewell"]) == 5
    assert all(ending["ending"][k] for k in (6, 7, 8)) and approved_new("year-cd", YEAR_PROPOSAL["proposed"])
    assert not approved_new("ex-hall-1", ["Something else"])
    assert all(len(e) <= 2 and all(len(t) <= 48 for t in e) for e in ending["ending"] + ending["farewell"] if e)
    rec = layout.caption(["Hello, Mike Haggar here."], "story", 14, 2)
    assert {s["row"] for s in rec["segments"]} == {23}
    rec = layout.caption(["a", "b", "c"], "story", 14, 2)
    assert {s["row"] for s in rec["segments"]} == {21, 23, 25}
    print("self-test passed")


if __name__ == "__main__":
    if "--self-test" in sys.argv:
        self_test()
    else:
        import build_m1_spike as spike
        import ex_scenes
        stock = spike.stock_program(spike.find_archive(spike.default_rompaths(), "ffightj"))
        patches, _ = er.build(stock)
        pieces = ex_scenes.pieces("english")
        _, receipt, _ = build(stock, pieces["program.bin"], pieces["data.bin"], patches)
        print(json.dumps(receipt, indent=1, ensure_ascii=False))
