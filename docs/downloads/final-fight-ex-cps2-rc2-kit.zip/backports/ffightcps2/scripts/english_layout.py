#!/usr/bin/env python3
"""Lay out the English restoration's text as story records and render them.

The English restoration (ENGLISH_EDITION.md) writes its reviewed English into
new story records. This module turns text into those records, in the formats
text_catalog.py reads, and renders them from the edition's own scroll 1 tiles
(the World set's text tiles over ffightj's), so the review sees the screen
the game will draw. Two fonts:

- large, the story font: drawn double height (the glyph, and the glyph +
  0x10 below) in mode 2, except the single-height '-' and quotes. Its
  digits are the decorative set (1-8 at 0x628, 9 and 0 at 0x64C) and it has
  no '/'. Its '-' is the restoration's own lowered hyphen
  (build_m1_spike.CAPTION_HYPHEN), centered in the line as CPS1 EX centers
  it; render with build_m1_spike.hyphen_region, which holds its CPS2-only
  tiles.
- small, 8x8 ASCII (tile 0x4400 + the character code), with lower case, '/',
  and the single tiles 'ft.' (0x5C) and 'lb.' (0x5D) the select screen uses.

Layouts:

- ``caption``: the intro's story lines, large, centered as EX centers them
  (backports/ffightcd tools/gen_caption_repos.py: column (48 - longest) // 2
  + 8, at least 9; lines 16 pixels apart, the block centered in the scene's
  text band: rows 20-27 for the phone call, the TV and Guy and Cody, as
  EX's 21/23/25, 22/24 and 23, and rows 22-29 under the map);
- ``profile``: mode 0, the name line large as two rows (the glyphs, then
  their lower halves), the rest small from row 11, column 27, at most 29
  columns, as the Japanese profiles use the small font;
- ``ending``: mode 0, the small font in the speakers' palettes, with the
  stock pauses (spaces typed at cell 0, 0) where each stock record has them;
- the year card (``caption`` in the ``card`` band): large, rows 14-15;
- the staff messages after END (instant records, small font): ``staff_box``
  centers a framed message in its box (columns 12-51, rows 8-23) 16 pixels
  a line; ``staff_list`` lays the messages beside the portraits on their
  Japanese rows, left ones from column 17, right ones ending at column 46
  (a column before the right portrait), a signature line right-aligned.

Words are separate segments, so a space costs no typing time: the typewriter
sleeps ``delay`` frames per glyph word it draws, and a segment break draws
none (``typing_frames``).
"""
from __future__ import annotations

from PIL import Image

import build_m1_spike as spike
import text_catalog as tc

SCREEN = (384, 224)
LARGE_SPACE, SMALL_SPACE = 0x010, 0x020
SINGLE_HEIGHT = {0x02D, 0x5E6, 0x5E7}
LARGE = {c: g for g, c in tc.ENGLISH.items() if len(c) == 1 and c != " "}
LARGE.update({"'": 0x5E5, "“": 0x5E6, "”": 0x5E7, ",": 0x5E8, ":": 0x5E9, "(": 0x5EA,
              ")": 0x5EB, "?": 0x5EC, "!": 0x5ED, ".": 0x5AA, "-": spike.CAPTION_HYPHEN, "9": 0x64C, "0": 0x64D})
LARGE.update({str(d): 0x627 + d for d in range(1, 9)})
LARGE.pop('"', None)
SMALL_UNITS = {"ft.": 0x5C, "lb.": 0x5D}
BANDS = {"map": (22, 29), "story": (20, 27), "card": (14, 15)}
PROFILE_COL, PROFILE_ROW, PROFILE_WIDTH = 27, 8, 29
ENDING_COL, ENDING_WIDTH = 32, 24


def large(text):
    out = []
    for c in text:
        if c == " ":
            out.append(LARGE_SPACE)
        elif c in LARGE:
            out.append(LARGE[c])
        else:
            raise ValueError(f"the large font has no {c!r} ({text!r})")
    return out


def small(text):
    out, i = [], 0
    while i < len(text):
        unit = next((u for u in SMALL_UNITS if text.startswith(u, i) and i and text[i - 1].isdigit()), None)
        if unit:
            out.append(SMALL_UNITS[unit])
            i += len(unit)
            continue
        if not 0x20 <= ord(text[i]) < 0x7B or text[i] in "\\[]^_`":
            raise ValueError(f"the small font has no {text[i]!r} ({text!r})")
        out.append(ord(text[i]))
        i += 1
    return out


def words(col, row, pal, glyphs, space):
    """One segment per word: the spaces become cell offsets."""
    segs, start = [], None
    for k, g in enumerate(glyphs + [space]):
        if g != space and start is None:
            start = k
        elif g == space and start is not None:
            segs.append({"col": col + start, "row": row, "pal": pal, "glyphs": glyphs[start:k]})
            start = None
    return segs


def caption(lines, band, pal, delay=2):
    if len(lines) > 4:
        raise ValueError("a caption has at most four lines")
    longest = max(len(line) for line in lines)
    col = max(9, (48 - longest) // 2 + 8)
    if col + longest > 56:
        raise ValueError(f"caption line too long for the screen: {longest}")
    top, bottom = BANDS[band]
    first = top + (bottom - top + 1 - 2 * len(lines)) // 2
    if first < top:
        raise ValueError(f"{len(lines)} lines do not fit the {band} band")
    segs = []
    for k, line in enumerate(lines):
        segs += words(col, first + 2 * k, pal, large(line), LARGE_SPACE)
    return {"delay": delay, "mode": 2, "segments": segs}


def profile(name, body, pal=14, delay=1, pitch=2):
    """The name line large (two rows), then the body small, ``pitch`` rows
    apart, a blank row between groups (an empty string in ``body``)."""
    if len(name) > PROFILE_WIDTH or any(len(line) > PROFILE_WIDTH for line in body):
        raise ValueError("a profile line is wider than the text area")
    top = large(name)
    segs = words(PROFILE_COL, PROFILE_ROW, pal, top, LARGE_SPACE)
    bottom = [LARGE_SPACE if g == LARGE_SPACE else (g + 0x10 if g not in SINGLE_HEIGHT else None) for g in top]
    lower = words(PROFILE_COL, PROFILE_ROW + 1, pal, [LARGE_SPACE if g is None else g for g in bottom], LARGE_SPACE)
    segs += lower
    row = PROFILE_ROW + 3
    for line in body:
        if line:
            segs += words(PROFILE_COL, row, pal, small(line), SMALL_SPACE)
            row += pitch
        else:
            row += 1
    if row - pitch > 27:                   # the last line's row; row 29 is the screen's last
        raise ValueError(f"the profile runs past its area (row {row - pitch})")
    return {"delay": delay, "mode": 0, "segments": segs}


def ending(parts, delay):
    """parts: (palette, lines, first row, pause): ``pause`` spaces typed at
    cell (0, 0) before the part, as the stock records pause (0: none)."""
    segs = []
    for pal, lines, row, pause in parts:
        if pause:
            segs.append({"col": 0, "row": 0, "pal": pal, "glyphs": [SMALL_SPACE] * pause})
        for i, line in enumerate(lines):
            if len(line) > ENDING_WIDTH:
                raise ValueError(f"ending line wider than {ENDING_WIDTH}: {line!r}")
            segs += words(ENDING_COL, row + 2 * i, pal, small(line), SMALL_SPACE)
    return {"delay": delay, "mode": 0, "segments": segs}


BOX_COLS, BOX_CENTER_ROW = (12, 52), 16
LIST_LEFT, LEFT_END, LIST_END = 17, 48, 47 # left messages up to column 47; right ones end at
                                           #   46, a column short of the right portrait (48)
TEXT_PAL = 14


def staff_box(lines):
    longest = max(len(line) for line in lines)
    if longest > BOX_COLS[1] - BOX_COLS[0] - 2:
        raise ValueError(f"a box line is wider than the box: {longest}")
    col = BOX_COLS[0] + (BOX_COLS[1] - BOX_COLS[0] - longest) // 2
    top = BOX_CENTER_ROW - len(lines)
    if top < 8:
        raise ValueError(f"{len(lines)} lines do not fit the box")
    segs = []
    for k, line in enumerate(lines):
        segs += words(col, top + 2 * k, TEXT_PAL, small(line), SMALL_SPACE)
    return segs


def staff_list(entries):
    """entries: (lines, layout) per message, layout as text/english_staff.json
    gives it (side, rows, page, signature, label)."""
    segs = []
    for lines, lay in entries:
        page = 64 * lay["page"]
        if lay.get("label"):
            label, lines = lines[0], lines[1:]
            segs += words(page + lay["label"]["col"], lay["label"]["row"], lay["label"]["pal"], small(label),
                          SMALL_SPACE)
        body = lines[:-1] if lay.get("signature") else lines
        longest = max(len(line) for line in body)
        col = LIST_LEFT if lay["side"] == "left" else LIST_END - longest
        if col < LIST_LEFT or col + longest > (LEFT_END if lay["side"] == "left" else LIST_END):
            raise ValueError(f"a staff message is wider than its slot: {body}")
        for k, line in enumerate(body):
            segs += words(page + col, lay["rows"][k], TEXT_PAL, small(line), SMALL_SPACE)
        if lay.get("signature"):
            sig = lines[-1]
            segs += words(page + LIST_END - len(sig), lay["rows"][len(body)], TEXT_PAL, small(sig), SMALL_SPACE)
    return segs


def typing_frames(rec):
    return rec["delay"] * sum(len(s["glyphs"]) for s in rec["segments"])


def screen(region, image, rec, background=None):
    """The record on a 384x224 screen: map column 8 at x 0, row 2 at y 0."""
    out = background.copy().convert("RGB") if background else Image.new("RGB", SCREEN)
    shown = [s for s in rec["segments"] if not (s["col"] == 0 and s["row"] == 0)]
    if not shown:
        return out
    piece = tc.render(region, image, {**rec, "segments": shown})
    c0, r0 = min(s["col"] for s in shown), min(s["row"] for s in shown)
    mask = piece.convert("L").point(lambda v: 255 if v else 0)
    out.paste(piece, ((c0 - 8) * 8, (r0 - 2) * 8), mask)
    return out


def self_test():
    assert large("Mike!") == [0x58C, 0x5C3, 0x5C5, 0x5AF, 0x5ED]
    assert small("159lb.") == [0x31, 0x35, 0x39, 0x5D] and small("lb.") == [0x6C, 0x62, 0x2E]
    rec = caption(["Don't hang up, or you'll regret it!"], "story", 15)
    assert rec["segments"][0]["row"] == 23 and rec["segments"][0]["col"] == (48 - 35) // 2 + 8
    assert [s["row"] for s in caption(["a", "b", "c"], "story", 14)["segments"]] == [21, 23, 25]
    assert [s["row"] for s in caption(["a", "b"], "map", 14)["segments"]] == [24, 26]
    assert typing_frames(caption(["Not so fast, Mike."], "story", 15)) == 2 * 15
    p = profile("GUY (24)", ["Born 8/12/1965"])
    assert p["segments"][0]["glyphs"] == large("GUY") and p["segments"][2]["row"] == 9
    assert p["segments"][2]["glyphs"][0] == large("G")[0] + 0x10
    try:
        large("8/12")
    except ValueError:
        pass
    else:
        raise AssertionError("the large font has no slash")
    rec = ending([(6, ["Oh Cody!"], 25, 16)], 4)
    assert rec["segments"][0]["glyphs"] == [SMALL_SPACE] * 16 and typing_frames(rec) == 4 * (16 + 7)
    assert caption(["Sometime in 1989..."], "card", 14)["segments"][0]["row"] == 14
    print("self-test passed")


if __name__ == "__main__":
    self_test()
