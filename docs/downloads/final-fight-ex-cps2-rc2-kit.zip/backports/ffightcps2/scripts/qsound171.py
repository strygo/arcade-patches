#!/usr/bin/env python3
"""Compose a sound image for Capcom's QSound driver 1.71 (sfa3u).

The image keeps the driver and its tables from the user's sfa3u set
(`sz3.01` bytes 0000-3BFF, which the upstream Final Fight port also keeps)
and replaces everything else with the caller's content: configuration,
instrument banks, articulations, sample descriptors, the command catalog,
scores and the sample region. No SFA3 score or sample remains.

Layout (flat addresses: `sz3.01` + `sz3.02`, MAME's 0x8000 hole removed):
configuration 3C00 (+0 the effects' master volume selector, +1 catalog
pointer, +3 descriptor pointer, +5 instrument bank pointers), instruments 4000-5FFF, descriptors 6000-7FFF (1,024 rows of
8 bytes), articulations 8000-87FF (256 of 8), catalog 8C00 (big-endian count,
then 4-byte records at +6), scores from SCORE_FIRST. The driver reads flat
addresses at or above 8000 through a 16 KiB window, so a score never crosses a
window. Samples are signed 8-bit; a sample never crosses a 32 KiB half-bank,
and its end address stays inside it (at most 7FFF or FFFF, as in SFA3: the
DSP's addresses are signed 16-bit).
"""
from __future__ import annotations

import struct

FLAT_BYTES = 0x40000
MEMBER_BYTES = 0x20000
DRIVER_END = 0x3C00
CONFIG = 0x3C00
INSTRUMENTS = (0x4000, 0x6000)
DESCRIPTORS = 0x6000
DESCRIPTOR_ROWS = 1024
ARTICULATIONS = 0x8000
ARTICULATION_COUNT = 256
CATALOG = 0x8C00
TEMPO_TABLE = 0x3492
VOLUME_TABLE = 0x2E92
WINDOW = 0x4000
SAMPLE_BYTES = 0x800000
HALF_BANK = 0x8000
FLAT_ARTICULATION = bytes([63, 0, 127, 0, 63, 0, 0, 0])
MASTER_SELECTOR = 0x7F
# The driver programs the DSP at boot from a register list (0x00D5) and a
# value list (0x00E1, little-endian words), ending with register E3.
BOOT_REGISTERS, BOOT_VALUES, BOOT_COUNT = 0x00D5, 0x00E1, 12
# Op 18 writes pan register 0x110 + p. Positions 0x00-0x20 of the DSP's pan
# table mix each voice into both the dry path and the FIR-filtered wet path
# (QSound's spatial effect, which colors the sound even at center 0x10);
# positions 0x30-0x50 feed the dry path only, 0x40 being center at -3 dB per
# side. The driver forces 0x10 unless the 68000's stereo flag ($CFFE) is set.
PAN_DRY_CENTER = 0x40
# Op 18 returns early unless F004 is set, which it is only for music
# channels: SFA3 places each effect from the 68000's command record, which
# clamps pan to 0x00-0x20. Removing that early return lets an effect's own
# score set its pan, as music does.
EFFECT_PAN_GATE = (0x16C0, bytes.fromhex("ca7012"))       # jp z,$1270


def swap_words(data):
    out = bytearray(data)
    out[0::2], out[1::2] = data[1::2], data[0::2]
    return bytes(out)


class Image:
    def __init__(self, sfa3_flat, catalog_count, effect_master=None):
        if len(sfa3_flat) != FLAT_BYTES:
            raise ValueError("expected the 256 KiB sz3.01+sz3.02 image")
        self.flat = bytearray(FLAT_BYTES)
        self.flat[:DRIVER_END] = sfa3_flat[:DRIVER_END]
        # Byte 0 selects the effects' master volume (F00D) through the table
        # at 0x2F92; SFA3's 0x2C sets its effects 9 dB under full scale.
        self.flat[CONFIG] = sfa3_flat[CONFIG] if effect_master is None else effect_master
        struct.pack_into("<HH", self.flat, CONFIG + 1, CATALOG, DESCRIPTORS)
        self.catalog_count = catalog_count
        # Count, then two master volume selectors (through the table at
        # 0x2F92) the driver reads at boot into F024 and F009 (music); SFA3
        # uses 7F 7F. Zero here silences everything.
        struct.pack_into(">HBB", self.flat, CATALOG, catalog_count, MASTER_SELECTOR, MASTER_SELECTOR)
        self.score_cursor = CATALOG + 6 + 4 * catalog_count
        self.instrument_cursor = INSTRUMENTS[0]
        self.samples = bytearray(b"\x00" * SAMPLE_BYTES)
        self.sample_cursor = 0
        self.used_rows, self.used_articulations, self.commands = set(), set(), {}
        self.articulation(0, FLAT_ARTICULATION)
        self.tempo_cells = {}

    def boot_register(self, register, value=None):
        """Read, or set, the value the driver writes to a DSP register at boot."""
        registers = self.flat[BOOT_REGISTERS:BOOT_REGISTERS + BOOT_COUNT]
        if register not in registers:
            raise ValueError(f"DSP register {register:02x} is not in the boot list")
        at = BOOT_VALUES + 2 * registers.index(register)
        if value is not None:
            struct.pack_into("<H", self.flat, at, value)
        return struct.unpack_from("<H", self.flat, at)[0]

    def effect_pan_from_score(self):
        """Let op 18 pan effect channels too (three bytes of driver code)."""
        at, code = EFFECT_PAN_GATE
        if bytes(self.flat[at:at + len(code)]) != code:
            raise ValueError("op 18 is not the driver 1.71 handler this patch expects")
        self.flat[at:at + len(code)] = bytes(len(code))     # nop nop nop
        return at

    def tempo(self, cell, increment):
        if not 0 <= cell < 256 or not 0 < increment < 0x10000:
            raise ValueError("tempo cell or increment out of range")
        struct.pack_into("<H", self.flat, TEMPO_TABLE + 2 * cell, increment)
        self.tempo_cells[cell] = increment

    def tempo_increment(self, cell):
        return struct.unpack_from("<H", self.flat, TEMPO_TABLE + 2 * cell)[0]

    def gain(self, index):
        """The driver's linear amplitude for volume selector index (0-127)."""
        top = struct.unpack_from("<H", self.flat, VOLUME_TABLE + 254)[0]
        return struct.unpack_from("<H", self.flat, VOLUME_TABLE + 2 * index)[0] / top

    def scale_volumes(self, factor):
        """Scale the channel volume table (index to DSP volume) by factor;
        volume_index maps relative to its top, so every channel gains alike."""
        values = struct.unpack_from("<128H", self.flat, VOLUME_TABLE)
        scaled = [round(v * factor) for v in values]
        if max(scaled) > 0x7FFF:
            raise ValueError("scaled volume table exceeds the DSP's signed range")
        struct.pack_into("<128H", self.flat, VOLUME_TABLE, *scaled)
        return scaled[127]

    def volume_index(self, gain):
        top = struct.unpack_from("<H", self.flat, VOLUME_TABLE + 254)[0]
        values = struct.unpack_from("<128H", self.flat, VOLUME_TABLE)
        return min(range(128), key=lambda i: (abs(values[i] - gain * top), i))

    def instrument_bank(self, bank, records):
        """records: (descriptor row, fine tune, articulation) per program."""
        size = 4 * len(records)
        if self.instrument_cursor + size > INSTRUMENTS[1] or not 0 <= bank < 256:
            raise ValueError("instrument area or bank exhausted")
        struct.pack_into("<H", self.flat, CONFIG + 5 + 2 * bank, self.instrument_cursor)
        for i, (row, fine, articulation) in enumerate(records):
            struct.pack_into("<HbB", self.flat, self.instrument_cursor + 4 * i, row, fine, articulation)
        self.instrument_cursor += size

    def articulation(self, index, values):
        if not 0 <= index < ARTICULATION_COUNT or len(values) != 8:
            raise ValueError("articulation index or size")
        a = values
        if not (a[0] < 64 and a[1] < 64 and a[2] < 128 and a[3] < 64 and a[4] < 64):
            raise ValueError(f"articulation selectors out of range: {list(a)}")
        self.flat[ARTICULATIONS + 8 * index:ARTICULATIONS + 8 * index + 8] = bytes(values)
        self.used_articulations.add(index)

    def sample(self, pcm8, loop=None):
        """Place signed 8-bit PCM; returns (bank, start, loop, end) for a
        descriptor. A one-shot gets two zero samples and loops over them."""
        data = bytes(pcm8) + (b"" if loop is not None else b"\x00\x00")
        if len(data) >= HALF_BANK:
            raise ValueError(f"sample of {len(data)} bytes exceeds a 32 KiB half-bank")
        cursor = (self.sample_cursor + 15) // 16 * 16
        if cursor // HALF_BANK != (cursor + len(data)) // HALF_BANK:
            cursor = (cursor // HALF_BANK + 1) * HALF_BANK
        if cursor + len(data) > SAMPLE_BYTES:
            raise ValueError("sample region exhausted")
        self.samples[cursor:cursor + len(data)] = data
        self.sample_cursor = cursor + len(data)
        start, end = cursor & 0xFFFF, (cursor & 0xFFFF) + len(data)
        loop_at = start + (loop if loop is not None else len(data) - 2)
        return cursor >> 16, start, loop_at, end

    def pack(self, samples):
        """Place (pcm8, loop) samples at once, largest first, each in the
        first half-bank with room (16-byte aligned), after anything sample()
        placed; returns (bank, start, loop, end) per sample, in order. A
        one-shot gets two zero samples and loops over them, as in sample()."""
        items = [bytes(pcm8) + (b"" if loop is not None else b"\x00\x00") for pcm8, loop in samples]
        if any(len(data) >= HALF_BANK for data in items):
            raise ValueError("a sample exceeds a 32 KiB half-bank")
        used = [HALF_BANK] * (self.sample_cursor // HALF_BANK) + [self.sample_cursor % HALF_BANK]
        used += [0] * (SAMPLE_BYTES // HALF_BANK - len(used))
        results = [None] * len(items)
        for i in sorted(range(len(items)), key=lambda i: (-len(items[i]), i)):
            data, loop = items[i], samples[i][1]
            for half, filled in enumerate(used):
                at = (filled + 15) // 16 * 16
                if at + len(data) < HALF_BANK:          # the end address stays inside
                    break
            else:
                raise ValueError(f"sample region exhausted: {len(items)} samples, "
                                 f"{sum(len(d) for d in items)} bytes for {SAMPLE_BYTES - self.sample_cursor} free")
            cursor = half * HALF_BANK + at
            self.samples[cursor:cursor + len(data)] = data
            used[half] = at + len(data)
            start = cursor & 0xFFFF
            results[i] = (cursor >> 16, start, start + (loop if loop is not None else len(data) - 2),
                          start + len(data))
        last = max(h for h, filled in enumerate(used) if filled)
        self.sample_cursor = max(self.sample_cursor, last * HALF_BANK + used[last])
        return results

    def descriptor(self, row, bank, start, loop, end, root):
        if not 0 <= row < DESCRIPTOR_ROWS or row in self.used_rows:
            raise ValueError(f"descriptor row {row} invalid or used")
        struct.pack_into("<BHHHB", self.flat, DESCRIPTORS + 8 * row, bank, start, loop, end, root)
        self.used_rows.add(row)

    def command(self, number, score):
        """Place a score (33-byte header and its channels) inside one window
        and enter it in the catalog."""
        if not 0 <= number < self.catalog_count or number in self.commands:
            raise ValueError(f"command {number:#x} invalid or used")
        if len(score) > WINDOW:
            raise ValueError("score larger than a window")
        at = self.score_cursor
        if at >= 0x8000 and (at - 0x8000) // WINDOW != (at + len(score) - 1 - 0x8000) // WINDOW:
            at = 0x8000 + ((at - 0x8000) // WINDOW + 1) * WINDOW
        if at + len(score) > FLAT_BYTES:
            raise ValueError("score area exhausted")
        self.flat[at:at + len(score)] = score
        self.flat[CATALOG + 6 + 4 * number:CATALOG + 9 + 4 * number] = at.to_bytes(3, "big")
        self.commands[number] = (at, len(score))
        self.score_cursor = at + len(score)
        return at

    def members(self):
        """Program members as stored (sz3.01, sz3.02) and sample members as
        stored (word-swapped, as MAME's ROM_LOAD16_WORD_SWAP expects)."""
        flat = bytes(self.flat)
        return {"sz3.01": flat[:MEMBER_BYTES], "sz3.02": flat[MEMBER_BYTES:],
                "sz3.11m": swap_words(bytes(self.samples[:0x400000])),
                "sz3.12m": swap_words(bytes(self.samples[0x400000:]))}


def score_header(mode, channels):
    """33-byte header: mode, then 16 big-endian channel offsets relative to
    the header (0 = unused), followed by the channels' bytes."""
    if len(channels) > 16:
        raise ValueError("at most 16 channels")
    header = bytearray(33)
    header[0] = mode
    body = bytearray()
    for i, code in enumerate(channels):
        if code is None:
            continue
        struct.pack_into(">H", header, 1 + 2 * i, 33 + len(body))
        body += code
    return bytes(header + body)


def self_test():
    flat = bytearray(FLAT_BYTES)
    struct.pack_into("<128H", flat, VOLUME_TABLE, *range(0, 128 * 64, 64))
    flat[BOOT_REGISTERS:BOOT_REGISTERS + BOOT_COUNT] = bytes.fromhex("dedfe0e1e4e5e6e7e2dadce3")
    struct.pack_into("<H", flat, BOOT_VALUES + 2, 0x2E)
    struct.pack_into("<H", flat, BOOT_VALUES + 6, 0x30)
    image = Image(bytes(flat), 0x60)
    image.boot_register(0xE1, image.boot_register(0xDF))
    assert image.boot_register(0xE1) == 0x2E
    try:
        image.effect_pan_from_score()
        raise AssertionError("patched a handler that is not there")
    except ValueError:
        pass
    image.flat[0x16C0:0x16C3] = EFFECT_PAN_GATE[1]
    assert image.effect_pan_from_score() == 0x16C0 and image.flat[0x16C0:0x16C3] == bytes(3)
    image.tempo(0xE0, 0x1C6)
    assert image.tempo_increment(0xE0) == 0x1C6
    image.articulation(1, [63, 0, 127, 0, 40, 0, 0, 0])
    bank, start, loop, end = image.sample(bytes([1, 2, 3, 4]))
    assert (bank, start, loop, end) == (0, 0, 4, 6) and image.samples[4:6] == b"\0\0"
    bank, start, loop, end = image.sample(bytes(32760))      # forced to the next half-bank
    assert (bank, start) == (0, 0x8000)
    image.descriptor(5, bank, start, loop, end, 0x47)
    placed = image.pack([(bytes(20000), None), (bytes(30000), 0), (bytes(12000), None)])
    # sample() filled two half-banks; largest first: 30000 opens the third,
    # 20002 the fourth, and 12002 fits after it there.
    assert placed[1][:3] == (1, 0, 0) and placed[0][:2] == (1, 0x8000)
    assert placed[2][:2] == (1, 0x8000 + 20016) and placed[2][3] == 0x8000 + 20016 + 12002
    image.instrument_bank(0, [(5, 0, 1)])
    assert struct.unpack_from("<H", image.flat, CONFIG + 5)[0] == INSTRUMENTS[0]
    score = score_header(0, [bytes([0x17]), None, bytes([0x20, 0x17])])
    assert score[1:3] == bytes([0, 33]) and score[5:7] == bytes([0, 34])
    at = image.command(0x40, score)
    assert image.flat[CATALOG + 6 + 4 * 0x40:CATALOG + 9 + 4 * 0x40] == at.to_bytes(3, "big")
    members = image.members()
    assert len(members["sz3.11m"]) == 0x400000 and members["sz3.11m"][0:2] == bytes([2, 1])
    print("self-test passed")


if __name__ == "__main__":
    self_test()
