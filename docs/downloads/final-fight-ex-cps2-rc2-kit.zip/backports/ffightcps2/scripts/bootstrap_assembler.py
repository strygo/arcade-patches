#!/usr/bin/env python3
"""Build the pinned native ASM68K-compatible assembler in disposable scratch."""
from __future__ import annotations

import argparse
import io
import os
from pathlib import Path
import subprocess
import tarfile

from audit_upstream import download, identity

PINS = {
    "assembler": ("Clownacy/clownassembler", "420b8013e17dbbaa56d7f6e8d415e1ad27c67a13"),
    "common": ("Clownacy/clowncommon", "37d1efd90725a7c30dce5f38ea14f1bc3c29a52f"),
}
SOURCES = (
    "frontend_asm68k.c dictionary.c io.c lexical.c options.c p2bin.c semantic.c "
    "shared-memory.c strcmpci.c string.c string-stack.c substitute.c syntactic.c"
).split()


def require_scratch(work):
    configured = os.environ.get("CAPCOM_WORK_ROOT")
    if not configured:
        raise ValueError("set CAPCOM_WORK_ROOT to the mounted scratch filesystem")
    root = Path(configured).resolve()
    if not root.is_mount() or not work.resolve().is_relative_to(root):
        raise ValueError("--work must be on the mounted configured scratch filesystem")


def fetch_tree(repo, revision, destination):
    blob = download(f"https://codeload.github.com/{repo}/tar.gz/{revision}")
    destination.mkdir(parents=True, exist_ok=False)
    with tarfile.open(fileobj=io.BytesIO(blob), mode="r:gz") as archive:
        for item in archive.getmembers():
            parts = Path(item.name).parts[1:]
            if not parts:
                continue
            if ".." in parts or item.issym() or item.islnk():
                raise ValueError("unsafe upstream archive member")
            target = destination.joinpath(*parts)
            if item.isdir():
                target.mkdir(parents=True, exist_ok=True)
            elif item.isfile():
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(archive.extractfile(item).read())
    return identity(blob)


def build(work):
    # Always build from this run's downloads; there is no external tool cache.
    require_scratch(work)
    root = work / "assembler"
    receipt = {"sources": {}}
    repo, revision = PINS["assembler"]
    receipt["sources"]["assembler"] = {
        "repository": repo, "revision": revision,
        **fetch_tree(repo, revision, root),
    }
    common = root / "clowncommon"
    # The git archive contains the empty submodule directory.
    if common.is_dir():
        common.rmdir()
    repo, revision = PINS["common"]
    receipt["sources"]["common"] = {
        "repository": repo, "revision": revision,
        **fetch_tree(repo, revision, common),
    }
    command = ["cc", "-ansi", "-Wno-long-long", "-O2", "-DNDEBUG", *SOURCES,
               "-o", "clownassembler_asm68k"]
    subprocess.run(command, cwd=root, check=True, capture_output=True)
    receipt["build_command"] = command
    return root / "clownassembler_asm68k", receipt


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--work", required=True, type=Path)
    args = parser.parse_args()
    require_scratch(args.work)
    args.work.mkdir(parents=True, exist_ok=True)
    binary, _ = build(args.work)
    print(binary)
