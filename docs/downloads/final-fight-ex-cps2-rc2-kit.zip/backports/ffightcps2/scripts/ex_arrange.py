#!/usr/bin/env python3
"""EX's CPS+ Arrange posting table: which commands the Arrange MRA sends to the pack.

EX's layer posts every Final Fight command byte b as the SFA3 driver word
0x00bb. Its program carries a capability byte, 0 in the ROM, which only the
CPS+ Arrange MRA patches to 1 (EX_BUILD.md, "MUSIC and voices"). With it set,
the layer's ex_arrange posts b by its class in EX_CLASSES, a table of one byte
per command below $f0 that this module builds from cpsplus's trigger map
(cpsplus/manifests/ffightcps2_ex_arrange_trigger_map.tsv, which also builds
the packs, pack/build_ffightcps2_ex_arrange.py):

- 0: natively;
- 1 (arrange): as the pack's word 0x0100|b in place of 0x00bb, with MUSIC
  ARRANGE (the stage themes and screens, the gated opening song, the region's
  voiced keys and the scene aliases $74-$78);
- 2 (companion): as 0x0100|b and 0x00bb, with MUSIC ARRANGE (the US opening's
  entry on the phone's ring, which stays the board's sound).

The English restoration EX posts the opening song ($52) as its own row's word
(restoration_word, the layer's EX_OPEN_EN): its arcade intro runs longer than
Japan's (english_records.py "Timing"), and that row plays Japan's arranged
opening with its own seam wrapped three times instead of once, so its outro
still ends by the title.

The pack maps every 0x01xx word with suppress, so the driver never takes one.
MUSIC ORIGINAL posts every command natively: the port's own music, and the CD
scenes without voices on their native cues (17 October).

    python3 ex_arrange.py --self-test
"""
from __future__ import annotations

import argparse
from pathlib import Path
import sys

TRACK = Path(__file__).resolve().parents[1]
CPSPLUS = TRACK.parents[1] / "cpsplus"
REGIONS = {"usa": "us", "japan": "jp", "english": "jp"}
HOME = 0x2EFF00             # EX_CLASSES, in free upper program ROM below REG_TV


def builder():
    """cpsplus's pack builder, the map's one reader."""
    if str(CPSPLUS) not in sys.path:
        sys.path.insert(0, str(CPSPLUS))
    from pack import build_ffightcps2_ex_arrange as module
    if Path(module.__file__).resolve().parent != CPSPLUS / "pack":
        raise ImportError(f"'pack' resolved to {module.__file__}, not cpsplus's")
    return module


def classes(edition):
    """EX_CLASSES for an edition: 0xF0 bytes."""
    return builder().posting_classes(REGIONS[edition])


def restoration_word():
    """The byte the restoration EX posts as 0x0100|byte for the opening song."""
    word = builder().own_word("jp", "restoration")
    return word & 0xFF


def describe(table):
    names = ("native", "arrange", "companion")
    return {f"{b:#04x}": names[c] for b, c in enumerate(table) if c}


def self_test():
    us, jp = classes("usa"), classes("japan")
    assert len(us) == len(jp) == 0xF0 and classes("english") == jp
    assert us[0x35] == 2 and jp[0x35] == 0 and us[0x52] == jp[0x52] == 1
    assert us[0x70] == us[0x71] == 1 and not us[0x72] and jp[0x72] == jp[0x73] == 1 and not jp[0x70]
    assert all(us[b] == jp[b] == 1 for b in range(0x74, 0x79))
    assert all(us[b] == jp[b] == 1 for b in (0x40, 0x48, 0x54, 0x58))
    assert not us[0x28] and not us[0x36] and not any(us[0x59:0x70])
    assert restoration_word() == 0x79 and not jp[0x79]
    print("self-test passed")


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--self-test", action="store_true")
    parser.add_argument("--edition", choices=sorted(REGIONS))
    args = parser.parse_args(argv)
    if args.self_test:
        self_test()
    elif args.edition:
        print(describe(classes(args.edition)))
    else:
        parser.print_help()
    return 0


if __name__ == "__main__":
    sys.exit(main())
