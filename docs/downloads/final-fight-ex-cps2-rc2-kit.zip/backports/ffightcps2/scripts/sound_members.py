#!/usr/bin/env python3
"""QSound members for the CPS2 development archive, from a keyed cache.

The converter (ff_audio.py) takes about a minute for the whole catalog, so
the archive builder reuses its output. A cache entry's key covers the
converter's sources, the pinned renderer revision, the identities of the
input members and the cue list; an entry is used only when every member
matches the digest its receipt records, and is rebuilt otherwise. The cache
lives in the track's scratch tree and may be deleted at any time. A rebuild
needs the repository venv (numpy, scipy).

    CAPCOM_WORK_ROOT=/Volumes/CapcomScratch venv/bin/python sound_members.py
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import shutil

import audit_upstream as upstream
import bootstrap_assembler as bootstrap
import build_m1_spike as spike
import ff_sound as fs

HERE = Path(__file__).resolve().parent
CACHE = HERE.parent / "work" / "cache" / "sound"
SOURCES = ("ff_audio.py", "qsound171.py", "ff_sound.py", "ym_voice.py", "ym2151_render.cpp",
           "bootstrap_ymfm.py", "sound_members.py")
NAMES = ("sz3.01", "sz3.02", "sz3.11m", "sz3.12m")
SFA3_SAMPLES = (("sz3.11m", 0x1C89EED1), ("sz3.12m", 0xF392B13A))   # as ff_audio reads them
FMLOOP = HERE.parents[1] / "ffightcd" / "build" / "fmloop.py"      # ff_audio's opening variants


def music_cues(z80):
    """Every music cue: mode 0 with at least one channel."""
    return tuple(s.cue for s in fs.songs(z80) if s and s.mode == 0 and any(s.channels))


def key(rompaths, music, effect_gains=None, opening=None):
    z80, oki = fs.load(rompaths)
    sfa3 = spike.find_archive(rompaths, "sfa3u")
    digest = hashlib.sha256()
    for name in SOURCES:
        digest.update(name.encode() + b"\0" + (HERE / name).read_bytes())
    digest.update(repr(upstream.PINS["hbmame_reference"]).encode())
    digest.update(z80 + oki)
    for name, crc in (("sz3.01", 0xDE810084), ("sz3.02", 0x72445DC4)) + SFA3_SAMPLES:
        digest.update(spike.read_checked(sfa3, name, crc))     # the samples: the jingle's
    digest.update(",".join(f"{c:02x}" for c in music).encode())
    if effect_gains:                        # effect levels: the editions' EFFECT_GAINS or a test kit's
        digest.update(repr(sorted(effect_gains.items())).encode())
    if opening:                             # the opening song's variants (ff_audio.CD_OPENING)
        digest.update(repr(sorted(opening.items())).encode() + FMLOOP.read_bytes())
    return digest.hexdigest()[:32]


def members(rompaths, music=None, cache=CACHE, effect_gains=None, opening=None):
    """(members, receipt) for the cue list (default: every music cue);
    effect_gains: {OKI trigger cue: dB}, a test kit's level changes;
    opening: the opening song's variants (ff_audio.build)."""
    bootstrap.require_scratch(cache)
    if music is None:
        music = music_cues(fs.load(rompaths)[0])
    entry = cache / key(rompaths, music, effect_gains, opening)
    receipt_path = entry / "audio.json"
    if receipt_path.exists():
        receipt = json.loads(receipt_path.read_text())
        found = {name: (entry / name).read_bytes() for name in NAMES if (entry / name).exists()}
        if len(found) == len(NAMES) and all(
                spike.identity(found[n])["sha256"] == receipt["members"][n]["sha256"] for n in NAMES):
            return found, receipt
    try:
        import bootstrap_ymfm      # a rebuild: the renderer and the converter (numpy, scipy)
        import ff_audio
    except ImportError as error:
        raise SystemExit(f"the sound cache needs a rebuild, which needs numpy and scipy ({error}); "
                         "run scripts/sound_members.py once with the repository venv") from None
    staging = entry.with_name(entry.name + ".building")
    if staging.exists():
        shutil.rmtree(staging)
    staging.mkdir(parents=True)
    binary, renderer = bootstrap_ymfm.build(staging)
    image, receipt = ff_audio.build(rompaths, binary, music, effect_gains, opening)
    built = image.members()
    for name in NAMES:
        (staging / name).write_bytes(built[name])
    receipt["members"] = {name: spike.identity(built[name]) for name in NAMES}
    receipt["renderer"] = renderer
    receipt["cache_key"] = entry.name
    (staging / "audio.json").write_text(json.dumps(receipt, indent=2) + "\n")
    shutil.rmtree(staging / "ymfm")
    if entry.exists():
        shutil.rmtree(entry)
    staging.rename(entry)
    return {name: built[name] for name in NAMES}, receipt


def captured(rompaths, staging, effect_gains=None, opening=None):
    """(members, receipt, products) from a full rebuild in staging: ff_audio's
    products (renders, OKI phrases, scale, warm entries) for the public kit's
    generator (gen_public_kit.py)."""
    import bootstrap_ymfm
    import ff_audio
    music = music_cues(fs.load(rompaths)[0])
    binary, renderer = bootstrap_ymfm.build(staging)
    products = {}
    image, receipt = ff_audio.build(rompaths, binary, music, effect_gains, opening, capture=products)
    built = image.members()
    receipt["members"] = {name: spike.identity(built[name]) for name in NAMES}
    receipt["renderer"] = renderer
    receipt["cache_key"] = "captured"
    return {name: built[name] for name in NAMES}, receipt, products


def from_products(rompaths, products, effect_gains=None, opening=None):
    """(members, receipt) from ff_audio's products, without the renderer or
    numpy: the public kit's kit mode (KIT.md)."""
    import ff_audio
    music = music_cues(fs.load(rompaths)[0])
    image, receipt = ff_audio.build(rompaths, None, music, effect_gains, opening, products=products)
    built = image.members()
    receipt["members"] = {name: spike.identity(built[name]) for name in NAMES}
    receipt["cache_key"] = "kit"
    return {name: built[name] for name in NAMES}, receipt


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--rompath", action="append", default=[])
    args = parser.parse_args(argv)
    rompaths = [Path(p) for p in args.rompath] + spike.default_rompaths()
    _, receipt = members(rompaths)
    print(json.dumps({k: receipt[k] for k in ("cache_key", "members", "sample_bytes")}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
