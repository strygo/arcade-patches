#!/usr/bin/env python3
"""The USA edition's story text with stock Final Fight USA's typos fixed.

The misspellings of the USA game are fixed (15 October): in its
typewriter records (group 1 of the table at 0x68566), "Mr.Haggar",
"can not", "course,you'll", "sweet heart since child hood", "Ninjitsu",
"martialarts", "girl friend" and "half way". Each fix is made in place.
A record's lines are typed glyph by glyph, spaces included, and a scene
moves on when its record has typed, so every fixed record keeps its stock
glyph count: its last line ends in typed spaces, and one fewer or more of
them takes up the difference. The record's bytes, its typing frames and
the timeline stay stock; only the letters change. (The HUD's GRANADE is a
fix of every edition, build_m1_spike.TEXT_FIXES.)

``patches(program)`` returns stock-checked entries for
build_m1_spike.apply_patches. ``oracle(rompaths, directory)`` writes stock
``ffightu`` with the same bytes and build_m1_spike.TEXT_FIXES, the CPS1 reference the USA edition's gates
compare with (run_m1_spike.py, run_tick_compare.py).

    python3 usa_text.py --self-test
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys
import zipfile

import build_m1_spike as spike
import text_catalog as tc

TRACK = Path(__file__).resolve().parents[1]
# The spelling rules and record codec are shared with CPS1 EX.
FFCD = Path(__file__).resolve().parents[2] / "ffightcd"
sys.path.insert(0, str(FFCD))
from ffcd.story_text import TYPOS, SPACE, parse, encode, text, fixed, patches, self_test  # noqa: E402,F401

STOCK_HYPHEN = 0x2D


def lowered(rec):
    """The record with every '-' it types (the 8x8 single-height 0x2D) as the
    lowered caption hyphen (build_m1_spike.CAPTION_HYPHEN), as CPS1 Final
    Fight EX lowers that tile's bar for all of them (backports/ffightcd
    build/rom.py patch_dash_tile); here a glyph of its own does it, so the
    8x8 '-' elsewhere (the test menu's titles) stays as it is."""
    return {**rec, "segments": [dict(s, glyphs=[spike.CAPTION_HYPHEN if g == STOCK_HYPHEN else g
                                                for g in s["glyphs"]]) for s in rec["segments"]]}


def lowered_block(block, group1):
    """EX's text (its copy of the text block, SEGA CD's; EX_BUILD.md) with
    every record's '-' lowered: block = the block's bytes, group1 = group
    1's offset table within it. Returns (bytes, records changed)."""
    out, changed = bytearray(block), 0
    for index in range(tc.word(out, group1) // 2):
        start = group1 + tc.word(out, group1 + 2 * index)
        rec = parse(out, start)
        new = encode(lowered(rec))
        if new != bytes(out[start:start + len(new)]):
            out[start:start + len(new)] = new
            changed += 1
    return bytes(out), changed


def oracle(rompaths, directory):
    """Stock ffightu with the fixes, as ffightu.zip in ``directory``."""
    import english_oracle                   # here: it imports build_m1_spike
    ffightu = spike.find_archive(rompaths, "ffightu")
    program = spike.usa_program(ffightu)
    entries, receipt = patches(program)
    applied = spike.apply_patches(program, {}, entries)
    applied += spike.apply_patches(program, {}, spike.TEXT_FIXES)
    out = {name: spike.upstream.member(ffightu, name) for name in english_oracle.member_names(ffightu)}
    for name, offset, _ in spike.FFIGHTU_PROGRAM:
        out[name] = bytes(program[offset:offset + 0x40000:2])
    directory.mkdir(parents=True, exist_ok=True)
    archive = directory / "ffightu.zip"
    with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED) as z:
        for name in sorted(out):
            info = zipfile.ZipInfo(name, date_time=(1990, 1, 12, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            z.writestr(info, out[name])
    receipt = {**receipt, "source": ffightu.name, "program_patches": applied,
               "program_sha256": spike.sha256(bytes(program))}
    (directory / "usa_oracle.json").write_text(json.dumps(receipt, indent=2) + "\n")
    return archive, receipt


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--self-test", action="store_true")
    parser.add_argument("--rompath", action="append", type=Path, default=[])
    args = parser.parse_args(argv)
    if args.self_test:
        self_test()
        return 0
    program = spike.usa_program(spike.find_archive(args.rompath + spike.default_rompaths(), "ffightu"))
    entries, receipt = patches(program)
    for e in entries:
        print(f"{e[0]:#x} {len(e[1]) // 2} bytes: {e[3]}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
