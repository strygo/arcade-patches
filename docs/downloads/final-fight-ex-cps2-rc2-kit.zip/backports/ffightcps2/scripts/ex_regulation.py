#!/usr/bin/env python3
"""REGULATION in EX's SEGA CD intro: the other disc's picture on Haggar's TV.

The CD intro (CPS1 EX's scenes, ex_scenes.py) shows Jessica on Haggar's TV,
in lingerie on the Japanese disc and in a red dress on the US disc. Each EX
edition can show the other disc's picture: Japan EX (and the restoration EX,
on Japan's scenes) the US dress with REGULATION ON (EX_PHASE0.md, decision
3), USA EX the Japanese picture with REGULATION OFF (21 October
2026: mirror Japan EX, factory ON). The two discs frame the shot alike: the
TV and Haggar slide in from opposite corners frame for frame (Japan's events
914-945, the US disc's 1016-1047, the same durations and cell counts), then
the picture flickers between two states until Damnd takes the TV (Japan's
event 1445, the US disc's 1895). The picture never leaves the scene window's
left eight columns; Haggar, on the right, moves his lips on each disc's own
timing and stays the edition's own, as do the captions.

build() reads both regions' scene pieces (the data ROM's script, map deltas
and palette blocks, and the scene art) and returns, for the edition's own
scenes (the base) and the other disc's picture:

- copies of the other picture's cells as new scroll 2 tiles after the base
  scene art, their pens renumbered into the palettes below;
- for each of the base's palette blocks the picture shows in, palette slots
  holding the other picture's colors in pens that none of the base's cells
  draws with while that block is loaded (pens the base's cells use keep
  their colors, so every base cell, Damnd's shot included, draws as before);
  the cells counted run from the event before the block's copy through the
  event after its last, or, where the other picture does not fit that (USA
  EX: Damnd's shot takes most of the US block's free slots), through its
  last when the event after is a late record, whose cells land with the
  next block's palettes;
- REG_TV, the layer's table: for each event from the one before the slide
  to the one after the picture, the cells that show the other picture (cells
  whose pixels differ from the base's), the cells to hand back to the base's
  picture where the engine stops rewriting them, and the block's palettes.

Both editions' kits carry what they show: the tiles go into the edition's own
graphics and the table into its own program (the other region's pieces are
read only at build time).

The layer's ex_reg_tail runs the table at the end of the opening engine's
vblank override (the override's epilogue jumps there, and the epilogue's own
`lea $ff8000,a5; jmp $984` ends it) while REGULATION's bit is clear (Japan:
ON; USA EX: OFF). It mirrors the engine (backports/ffightcd/build/engine.py,
vbsched.py): the map cells of a late record (count 64 or more) land one
vblank after its load, so on that vblank the screen still shows the event
before, while the record's palette block is copied to the staging page at
its load and published at the next vblank, so the palettes follow the event
loaded.

    python3 ex_regulation.py --self-test
"""
from __future__ import annotations

import argparse
from collections import namedtuple
import hashlib
import json
import struct
import sys

import regulation

SCRIPT, PALBLOCKS, DELTAS = 0x400, 0x9000, 0x29000  # engine.py's, from the data ROM's start
COLS, ROWS, ROW0, COL0 = 20, 14, 0x11, 0x26         # the scene window in the scroll 2 map
LATE, SPILL, DEFERRED = 0x2000, 0x4000, 0x8000      # record count-word flags (vbsched.py)
ART_BASE = 0x5000                                   # the scenes' first scroll 2 code (target.py)
CLEAR = (ART_BASE, 0)                               # the map's cells before any delta (vbsched.py)
# Each disc's events that show the picture: the slide's first and last, then
# the flicker's last (the next event is Damnd's shot).
Shot = namedtuple("Shot", "first slide_end last")
SHOTS = {"jp": Shot(914, 945, 1444), "us": Shot(1016, 1047, 1894)}
OTHER = {"jp": "us", "us": "jp"}                    # whose picture each region's EX can show
PIECES = {"jp": "japan", "us": "usa"}               # the ex_scenes edition holding a region's pieces
DISC = {"jp": "Japan's", "us": "the US disc's"}
PICTURE = SHOTS["jp"].first, SHOTS["jp"].last       # Japan's, as before
SLIDE_END = SHOTS["jp"].slide_end
US_SHIFT = SHOTS["us"].first - SHOTS["jp"].first    # 102
PICTURE_COLUMNS = 8         # window columns the picture stays in
TRANSPARENT = 15            # scroll 2's transparent pen
HOME = 0x2F0000             # REG_TV, in free upper program ROM


def window_offsets():
    """The 280 window cells' byte offsets in the scroll 2 map, row by row."""
    out = []
    for cy in range(ROWS):
        for cx in range(COLS):
            row, col = ROW0 + cy, COL0 + cx
            out.append(((row & 0x0F) + ((col & 0x3F) << 4) + ((row & 0x30) << 6)) * 4)
    return out


OFFSETS = window_offsets()
PICTURE_CELLS = [o for i, o in enumerate(OFFSETS) if i % COLS < PICTURE_COLUMNS]


def records(data):
    """The opening's script records: (bi|fade, pal|cue, delta offset, count|flags, frames, sx, sy)."""
    out, at = [], SCRIPT
    while data[at:at + 2] != b"\xff\xff":
        out.append(struct.unpack(">HHIHHHH", data[at:at + 16]))
        at += 16
    return out


def blob(data, record):
    """A record's now-cells and spill cells: [(offset, code, attr)], [(offset, code, attr)]."""
    at = DELTAS + record[2]
    count = record[3] & 0x1FFF
    now = [struct.unpack(">HHH", data[at + 6 * k:at + 6 * k + 6]) for k in range(count)]
    spill = []
    if record[3] & SPILL:
        at += 6 * count
        while True:
            n = struct.unpack(">H", data[at:at + 2])[0]
            at += 2
            if n == 0xFFFF:
                break
            spill += [struct.unpack(">HHH", data[at + 6 * k:at + 6 * k + 6]) for k in range(n)]
            at += 6 * n
    return now, spill


def map_states(data, recs, last, guard=None):
    """The scene window's cells after each event through last, as the engine
    leaves them: [{offset: (code, attr)}] by event. Spill cells (not yet
    visible, vbsched.py) must never touch the picture's columns in the events
    of guard (all when None), where REG_TV models them event by event (the
    restoration EX's lips, english_mouths.py, spill visible cells into those
    columns in later shots)."""
    state = {o: CLEAR for o in OFFSETS}
    picture = set(PICTURE_CELLS)
    out = []
    for index, record in enumerate(recs[:last + 1]):
        now, spill = blob(data, record)
        if (guard is None or index in guard) and any(o in picture for o, _, _ in spill):
            raise ValueError(f"event {index} spills a cell into the picture's columns")
        for o, code, attr in now + spill:
            if o in state:
                state[o] = (code, attr)
        out.append(dict(state))
    return out


def picture(state):
    return tuple(state[o] for o in PICTURE_CELLS)


def palette(data, block, slot):
    at = PALBLOCKS + block * 1024 + slot * 32
    return struct.unpack(">16H", data[at:at + 32])


class Art:
    """A region's scene tiles as pens, decoded once each."""

    def __init__(self, art):
        self.art, self.cache = art, {}

    def pens(self, code):
        if code not in self.cache:
            t = code - ART_BASE
            if not 0 <= t * 128 < len(self.art):
                raise ValueError(f"scroll 2 code {code:#x} is outside the scene art")
            self.cache[code] = regulation.tile_pens(self.art[t * 128:(t + 1) * 128])
        return self.cache[code]

    def used(self, code):
        return {p for row in self.pens(code) for p in row} - {TRANSPARENT}


def flipped(rows, attr):
    if attr & 0x20:
        rows = [row[::-1] for row in rows]
    if attr & 0x40:
        rows = rows[::-1]
    return rows


def pixels(art, data, block, cell):
    """A cell as palette words (None where transparent), flips applied."""
    code, attr = cell
    words = palette(data, block, attr & 0x1F)
    return [[None if p == TRANSPARENT else words[p] for p in row] for row in flipped(art.pens(code), attr)]


def flicker_end(states, slide_end):
    """The last event after the slide whose picture is one of the flicker's
    two states (the next is Damnd's shot)."""
    two = {picture(states[slide_end + 1]), picture(states[slide_end + 2])}
    if len(two) != 2:
        raise ValueError("the picture does not flicker after the slide")
    j = slide_end + 1
    while j + 1 < len(states) and picture(states[j + 1]) in two:
        j += 1
    return j


def pair(base, other, region="jp"):
    """[(base event, other event)] over the picture, with the records and the
    map states: the slide event for event, then each flicker event with the
    other disc's event in its paired state; None before and after."""
    shot, oshot = SHOTS[region], SHOTS[OTHER[region]]
    name, oname = DISC[region], DISC[OTHER[region]]
    shift = oshot.first - shot.first
    if oshot.slide_end - oshot.first != shot.slide_end - shot.first:
        raise ValueError("the two slides differ in length")
    brecs, orecs = records(base["data.bin"]), records(other["data.bin"])
    first, last = shot.first, shot.last
    for j in range(first, shot.slide_end + 1):
        a, b = brecs[j], orecs[j + shift]
        if a[4] != b[4] or (a[3] & LATE) != (b[3] & LATE):
            raise ValueError(f"{name} event {j} and {oname} {j + shift} are not the same frame")
    bstates = map_states(base["data.bin"], brecs, len(brecs) - 1, range(first - 1, last + 3))   # the table's events
    ostates = map_states(other["data.bin"], orecs, oshot.slide_end + 2)
    end = flicker_end(bstates, shot.slide_end)
    if last is None:
        raise ValueError(f"{name} flicker ends at event {end}; pin it in SHOTS")
    if end != last:
        raise ValueError(f"{name} flicker ends at event {end}, not {last}")
    a, b = shot.slide_end + 1, shot.slide_end + 2
    flicker = {picture(bstates[a]): a + shift, picture(bstates[b]): b + shift}
    if picture(ostates[a + shift]) == picture(ostates[b + shift]):
        raise ValueError(f"{oname} picture does not flicker after the slide")
    pairs = []
    for j in range(first - 1, last + 2):
        if j < first or j > last:
            u = None
        elif j <= shot.slide_end:
            u = j + shift
        else:
            u = flicker.get(picture(bstates[j]))
            if u is None:
                raise ValueError(f"{name} event {j} shows a third picture")
        pairs.append((j, u))
    # The cells of a late record land a vblank after its load: a late record
    # of a single frame (the US disc's Damnd shot) never shows its own entry,
    # so the base's cells are handed back at the event after it.
    while brecs[pairs[-1][0]][3] & LATE and brecs[pairs[-1][0]][4] < 2:
        pairs.append((pairs[-1][0] + 1, None))
    return brecs, orecs, bstates, ostates, pairs


def pack(cells, slots):
    """Assign each cell's color set to a slot: slots = {slot: (locked words,
    free pens)}. Returns ({colors: slot}, {slot: added words}) or raises."""
    added = {s: [] for s in slots}
    where = {}
    for colors in sorted(cells, key=lambda c: (-len(c), sorted(c))):
        best = None
        for s in sorted(slots):
            have = slots[s][0] | set(added[s])
            extra = sorted(colors - have)
            if len(added[s]) + len(extra) <= slots[s][1]:
                score = (len(extra), -len(colors & have), s)
                if best is None or score < best[0]:
                    best = (score, s, extra)
        if best is None:
            raise ValueError("the other picture's colors do not fit the base's free pens")
        _, s, extra = best
        added[s] += extra
        where[colors] = s
    return where, added


def build(base, other, first_code, region="jp", counterparts=None):
    """(tiles [(code, 128 bytes)], table bytes, receipt) for an EX edition:
    base = ex_scenes.pieces() of the edition (its region's scenes), other =
    the other region's pieces (the picture it can show, PIECES[OTHER[region]]);
    first_code = the first free scroll 2 code after the base's scene art.
    counterparts, a list, receives each output datum's corresponding piece of
    the base (the public kit's keyed items, KIT.md): each tile, the base's
    tile in the screen cell where it first shows (one holding art where there
    is one); the table's events and cell lists, the base's script records over
    its events; each palette set, the base's palette block it amends."""
    jdata, udata = base["data.bin"], other["data.bin"]
    jart, uart = Art(base["art.bin"]), Art(other["art.bin"])
    jrecs, urecs, jstates, ustates, pairs = pair(base, other, region)
    first = pairs[0][0]

    def jblock(j):
        return jrecs[j][1] & 0xFF

    def ublock(u):
        return urecs[u][1] & 0xFF

    # the cells that show the other picture: pixels differ from the base's;
    # each with the other disc's palette block at its event
    shown = {}
    for j, u in pairs:
        shown[j] = {}
        if u is None:
            continue
        for o in PICTURE_CELLS:
            jc, uc = jstates[j][o], ustates[u][o]
            if pixels(jart, jdata, jblock(j), jc) != pixels(uart, udata, ublock(u), uc):
                shown[j][o] = (uc, ublock(u))
    if shown[first] or shown[pairs[-1][0]]:
        raise ValueError("the table's first and last events must show the base's picture")

    # every palette block the picture shows in, from its copy to the next one
    blocks = []
    for j, u in pairs:
        if u is not None and (not blocks or blocks[-1][0] != jblock(j)):
            start = j
            while jblock(start - 1) == jblock(j):
                start -= 1
            end = j
            while jblock(end + 1) == jblock(j):
                end += 1
            if jrecs[start][3] & DEFERRED:
                raise ValueError(f"event {start} defers its palette copy")
            blocks.append((jblock(j), start, end))
    palettes, recolor, receipt_blocks = {}, {}, []
    for block, start, end in blocks:
        words = {s: palette(jdata, block, s) for s in range(32)}

        def lock(last):
            locked = {s: set() for s in range(32)}
            for j in range(start - 1, last + 1):
                for o in OFFSETS:
                    if o not in shown.get(j, {}):
                        code, attr = jstates[j][o]
                        locked[attr & 0x1F] |= jart.used(code)
            return locked

        cells = {}
        for j, _ in pairs:
            if jblock(j) == block:
                for o, ((code, attr), ub) in shown[j].items():
                    uw = palette(udata, ub, attr & 0x1F)
                    cells[(code, ub, attr & 0x1F)] = frozenset(uw[p] for p in uart.used(code))
        # The pens the base's cells draw with while the block's palettes show,
        # from the event before its copy: first one event either side (a late
        # record's lag); where the other picture does not fit that, the event
        # after only when it is not a late record (a late record's cells land
        # with the next block's palettes, engine.py)
        lag = "either side"
        locked = lock(end + 1)
        slots = {s: ({words[s][p] for p in locked[s]}, 15 - len(locked[s])) for s in range(32)}
        try:
            where, added = pack(set(cells.values()), slots)
        except ValueError:
            if not jrecs[end + 1][3] & LATE:
                raise
            lag, locked = "before", lock(end)
            slots = {s: ({words[s][p] for p in locked[s]}, 15 - len(locked[s])) for s in range(32)}
            where, added = pack(set(cells.values()), slots)
        built = {}
        for s, extra in added.items():
            if not extra:
                continue
            free = [p for p in range(15) if p not in locked[s]]
            pal = list(words[s])
            for p, w in zip(free, extra):
                pal[p] = w
            built[s] = pal
        palettes[block] = built
        for key, colors in cells.items():
            s = where[colors]
            pal = built.get(s, words[s])
            uw = palette(udata, key[1], key[2])
            pen_of = {}
            for p in uart.used(key[0]):
                if uw[p] not in pal[:15]:
                    raise ValueError(f"slot {s} lost the other picture's color {uw[p]:#06x}")
                pen_of[p] = pal.index(uw[p])
            recolor[(block, key)] = (s, pen_of)
        receipt_blocks.append({"block": block, "events": [start, end], "locked": lag,
                               "slots": {str(s): len(added[s]) for s in sorted(added) if s in set(where.values())}})

    # the tiles: each of the other picture's cells renumbered into its slot's pens
    tiles, codes = [], {}
    for (block, (code, _, _)), (s, pen_of) in sorted(recolor.items()):
        rows = [[TRANSPARENT if p == TRANSPARENT else pen_of[p] for p in row] for row in uart.pens(code)]
        data = regulation.tile_bytes(rows)
        if data not in codes:
            codes[data] = first_code + len(tiles)
            tiles.append((codes[data], data))

    def cell_of(block, shown_cell):
        (code, attr), ub = shown_cell
        s, pen_of = recolor[(block, (code, ub, attr & 0x1F))]
        rows = [[TRANSPARENT if p == TRANSPARENT else pen_of[p] for p in row] for row in uart.pens(code)]
        return codes[regulation.tile_bytes(rows)], (attr & ~0x1F) | s

    # each event's cell list: the other picture's cells, then the base's cells
    # that still hold one of them the engine will not rewrite
    lists, entries = [], []
    held = {}                               # offset: the base's cell when the other one went up
    for j, u in pairs:
        block = jblock(j)
        cells = []
        for o in PICTURE_CELLS:
            if o in shown[j]:
                cells.append((o, *cell_of(block, shown[j][o])))
                held[o] = jstates[j][o]
            elif o in held:
                if jstates[j][o] == held[o]:    # the engine has not rewritten it
                    cells.append((o, *jstates[j][o]))
                else:
                    del held[o]
        late = jrecs[j][4] if jrecs[j][3] & LATE and j != first else 0
        pal = block if (u is not None and block in palettes) else None
        entries.append((late, cells, pal))
    last = pairs[-1][0]
    if shown[last] or (jrecs[last][3] & LATE and jrecs[last][4] < 2):
        raise ValueError("the table's last event must show the base's picture for a vblank of its own")

    # REG_TV: first event, count, entries (late duration, cells, palettes),
    # then the cell lists (count - 1, (offset, code, attr)...) and the
    # palette sets (count - 1, (slot * 32, 16 words)...); offsets from REG_TV
    head = 4 + 6 * len(entries)
    body, list_at, pal_at = bytearray(), {}, {}
    for _, cells, _ in entries:
        key = tuple(cells)
        if cells and key not in list_at:
            list_at[key] = head + len(body)
            body += struct.pack(">H", len(cells) - 1)
            for o, code, attr in cells:
                body += struct.pack(">HHH", o, code, attr)
    lists_end = head + len(body)
    for block, built in palettes.items():
        if built:
            pal_at[block] = head + len(body)
            body += struct.pack(">H", len(built) - 1)
            for s, words in sorted(built.items()):
                body += struct.pack(">H16H", s * 32, *words)
    table = bytearray(struct.pack(">HH", first, len(entries)))
    for late, cells, pal in entries:
        table += struct.pack(">HHH", late, list_at[tuple(cells)] if cells else 0,
                             pal_at[pal] if pal is not None else 0)
    table += body
    if any(o >= 0x8000 for o in PICTURE_CELLS) or len(table) >= 0x8000:
        raise ValueError("REG_TV's offsets must fit a signed word")
    if counterparts is not None:
        where = {}
        for j, _ in pairs:
            for o, cell in shown[j].items():
                code, base_code = cell_of(jblock(j), cell)[0], jstates[j][o][0]
                if code not in where or (where[code] == ART_BASE and base_code != ART_BASE):
                    where[code] = base_code
        counterparts += [{"item": f"tile {code:#x}", "source": "art.bin", "offset": (where[code] - ART_BASE) * 128,
                          "length": 128} for code, _ in tiles]
        spans = [{"item": "table lists", "span": [0, lists_end], "source": "data.bin",
                  "offset": SCRIPT + 16 * first, "length": 16 * (last - first + 1)}]
        for block, at in pal_at.items():
            spans.append({"item": f"table palettes {block:#x}", "span": [at, at + 2 + 34 * len(palettes[block])],
                          "source": "data.bin", "offset": PALBLOCKS + block * 1024, "length": 1024})
        edges = [row["span"] for row in spans]
        if edges[-1][1] != len(table) or any(a[1] != b[0] for a, b in zip(edges, edges[1:])):
            raise ValueError("REG_TV's keyed spans do not cover the table in order")
        counterparts += spans
    receipt = {"events": [first, pairs[-1][0]],
               "picture": {"region": OTHER[region], "events": [pairs[1][1], max(u for _, u in pairs if u)],
                           "palette_blocks": sorted({ublock(u) for _, u in pairs if u is not None})},
               "blocks": receipt_blocks,
               "tiles": {"first": f"{first_code:#x}", "count": len(tiles),
                         "sha256": hashlib.sha256(b"".join(t for _, t in tiles)).hexdigest()},
               "lists": len(list_at), "table": {"home": f"{HOME:#x}", "bytes": len(table),
                                                 "sha256": hashlib.sha256(table).hexdigest()}}
    return tiles, bytes(table), receipt


def self_test():
    assert len(OFFSETS) == 280 and len(set(OFFSETS)) == 280 and len(PICTURE_CELLS) == 8 * ROWS
    assert OFFSETS[0] == ((0x11 & 0x0F) + (0x26 << 4) + ((0x11 & 0x30) << 6)) * 4
    slots = {1: ({0x0111}, 2), 2: (set(), 15)}
    where, added = pack({frozenset({0x0111, 0x0222}), frozenset({0x0333, 0x0444, 0x0555})}, slots)
    assert where[frozenset({0x0111, 0x0222})] == 1 and added[1] == [0x0222]
    assert where[frozenset({0x0333, 0x0444, 0x0555})] == 2
    try:
        pack({frozenset(range(16))}, {1: (set(), 15)})
    except ValueError:
        pass
    else:
        raise AssertionError("an oversized color set packed")
    rows = [[(x + y) % 15 for x in range(16)] for y in range(16)]
    assert regulation.tile_pens(regulation.tile_bytes(rows)) == rows
    assert flipped(rows, 0x20)[0] == rows[0][::-1] and flipped(rows, 0x40)[0] == rows[15]
    for region, shot in SHOTS.items():      # the two discs' shots pair up
        other = SHOTS[OTHER[region]]
        assert OTHER[OTHER[region]] == region and shot.first < shot.slide_end < shot.last
        assert shot.slide_end - shot.first == other.slide_end - other.first
    assert US_SHIFT == 102 and PICTURE == (914, 1444) and SLIDE_END == 945
    a, b, c = ({o: (ART_BASE + k, 0) for o in OFFSETS} for k in range(3))
    assert flicker_end([c, c, a, b, a, b, c], 1) == 5
    print("self-test passed")


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--self-test", action="store_true")
    parser.add_argument("--receipt", action="store_true", help="build from the cached pieces and print the receipt")
    parser.add_argument("--edition", choices=("japan", "usa"), default="japan",
                        help="whose EX build: japan (the US picture) or usa (Japan's)")
    args = parser.parse_args(argv)
    if args.self_test:
        self_test()
        return 0
    if args.receipt:
        import ex_scenes
        region = ex_scenes.REGIONS[args.edition]
        base, other = ex_scenes.pieces(args.edition), ex_scenes.pieces(PIECES[OTHER[region]])
        first = ART_BASE + base["manifest"]["art_tiles"]
        tiles, table, receipt = build(base, other, first, region)
        print(json.dumps(receipt, indent=2))
        return 0
    parser.print_help()
    return 0


if __name__ == "__main__":
    sys.exit(main())
