#!/usr/bin/env python3
"""EX's cut scenes: CPS1 Final Fight EX's scene engine and art, built for CPS2.

CPS1 EX's own build (backports/ffightcd: render.py, ending.py esnaps,
opening.py, pipeline.py, rom.py) runs with its CPS2 target (its
build/target.py: data at 0x310000, state at 0xFFFFB0, CPS-B-21's layer
control, scene art from code 0x5000) and writes three pieces: the whole
1 MiB program as it built it (the CD timeline's retime of the story block,
the three engines at 0xD6000-0xD8FFF and every hook), its data ROM and the
appended art. pieces() builds them into this track's cache, keyed by every
input, and rebuilds them when the cache is missing or stale; merge() lays
them into the CPS2 build (EX_BUILD.md). The chain's two generated inputs, the
region's program ROMs with the retime patches and the appended graphics'
pattern fill, come from the user's romset (its build/stage_inputs.py). merge()
lays the pieces into the CPS2 build:

- program: every byte EX changed against the stock program, except where
  the layer patches the same bytes. Those collisions are resolved here or
  fail: EX's object-base hook at 0x584 (its title slide) is called from the
  layer's vblank_entry instead (EX_OBJHOOK); in a story text record this
  port rewrote (usa_text.py's typo fixes, which can shift a record's later
  lines), EX's caption moves go to the same line's position word.
- data: the data ROM's used span at 0x310000.
- art: the scene art and EX lettering at graphics 0x800000 plus their
  offset from the scroll layers' start (target.py).

    python3 ex_scenes.py --self-test
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

TRACK = Path(__file__).resolve().parents[1]
ROOT = TRACK.parents[1]
FFCD = ROOT / "backports" / "ffightcd"
REGIONS = {"usa": "us", "japan": "jp", "english": "jp"}
BASE_CODE = 0x5000                  # ffightcd's target.py ART_BASE_CODE for cps2
SCROLL_GFX = 0x800000               # CPS2 scroll layers' graphics start
# Bytes the layer and EX both patch, and how the CPS2 build resolves them.
RESOLVED = {
    0x584: "EX's object-base hook (jsr + nop): the layer's vblank_entry calls it (EX_OBJHOOK)",
}
SOURCES = ("build", "ffcd", "data", "control")


def digest(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def input_key(region, target="cps2", captions=None):
    """Every input of the scene build: CPS1 EX's sources and data, the
    owner's disc and arcade sets as CPS1 EX's build finds them, and the
    restoration EX's English ending captions when given."""
    files = {}
    if captions is not None:
        files["captions"] = hashlib.sha256(json.dumps(captions, sort_keys=True).encode()).hexdigest()
    for part in SOURCES:
        for path in sorted((FFCD / part).rglob("*")):
            if path.is_file() and "__pycache__" not in path.parts:
                files[str(path.relative_to(FFCD))] = digest(path)
    disc = disc_files(region)
    if not disc:
        raise SystemExit(f"EX scenes need the {region} disc (backports/ffightcd/BUILDING.md)")
    roms = romset_dir()
    sets = [next((roms / f"{name}{ext}" for ext in (".7z", ".zip") if (roms / f"{name}{ext}").exists()),
                 roms / f"{name}.7z") for name in ("ffight", "ffightu", "ffightj")]
    for path in disc + sets:
        if not path.exists():
            raise SystemExit(f"EX scenes need {path} (backports/ffightcd/BUILDING.md)")
        files[f"input:{path.name}"] = digest(path)
    if target == "cps2":
        files["option:repair_cody_back"] = "on"     # build_pieces passes it to the chain
    return {"region": region, "target": target, "base_code": f"{BASE_CODE:#x}",
            "sha256": hashlib.sha256(json.dumps(files, sort_keys=True).encode()).hexdigest(), "files": files}


def disc_files(region):
    """The disc the chain reads for a region: the image its paths.json names (backports/ffightcd/ffcd/
    disc.py; the public kit and release candidates write it), else the user's rip in FFCD_DISCDIR
    or roms/segacd."""
    config = FFCD / "paths.json"
    if config.exists() and region in json.loads(config.read_text()):
        return [Path(json.loads(config.read_text())[region])]
    discs = Path(os.environ.get("FFCD_DISCDIR", ROOT / "roms" / "segacd"))
    return sorted(discs.glob("Final Fight CD (JP).*" if region == "jp" else "Final Fight CD (USA).*"))


def romset_dir():
    return Path(os.environ.get("FFCD_ROMPATH", ROOT / "roms" / "mame0260"))


def chain_inputs(region, romset, out):
    """(stage0, parts): the chain's generated inputs in out, from the user's
    romset folder (CPS1 EX's build/stage_inputs.py)."""
    if str(FFCD / "build") not in sys.path:
        sys.path.insert(0, str(FFCD / "build"))
    import stage_inputs
    return stage_inputs.write(region, out, romset)


def run(cmd, log):
    with log.open("a") as handle:
        handle.write("+ " + " ".join(map(str, cmd)) + "\n")
        handle.flush()
        result = subprocess.run([str(c) for c in cmd], cwd=FFCD, stdout=handle, stderr=subprocess.STDOUT)
    if result.returncode:
        raise SystemExit(f"EX scene stage failed ({result.returncode}): {cmd[1:3]}; see {log}")


def build_pieces(region, root, target="cps2", captions=None, romset=None):
    """CPS1 EX's chain with the CPS2 target (or, for the comparison's
    reference, its own CPS1 target), from a fresh root; captions: the
    restoration EX's English ending lines (rom.py --captions); romset: the
    owner's romset folder (romset_dir())."""
    base = BASE_CODE if target == "cps2" else 0x4000
    if root.exists():
        shutil.rmtree(root)
    root.mkdir(parents=True)
    log = root / "build.log"
    stage0, parts = chain_inputs(region, romset or romset_dir(), root / "inputs")
    extra = []
    if captions is not None:
        (root / "captions.json").write_text(json.dumps(captions, indent=1, ensure_ascii=False) + "\n")
        extra = ["--captions", root / "captions.json"]
    py = sys.executable
    run([py, "build/render.py", region, "O", root / f"{region}_open"], log)
    run([py, "build/render.py", region, "E", root / f"{region}_end"], log)
    run([py, "build/ending.py", "esnaps", "--root", root], log)
    run([py, "build/opening.py", region, "--vmsweep", root / f"{region}_open",
         "--aligned", root / f"{region}_open_aligned", "--conv-out", root / f"{region}_conv",
         "--base-code", hex(base)], log)
    if target == "cps2":
        extra.append("--repair-cody-back")      # build/cody_back.py
    run([py, "build/pipeline.py", region, "--root", root, "--base-code", hex(base),
         "--target", target, "--stage0", stage0, "--parts", parts, *extra], log)
    return root / f"{region}_set" / ("cps2" if target == "cps2" else "")


def captions_for(edition):
    """The restoration EX's English ending captions (english_ex.py), at the
    redub's words; None for the other editions."""
    if edition != "english":
        return None
    import english_ex
    return {**english_ex.ending_lines(), "frames": english_ex.ending_frames()}


def load(out, inputs_sha256):
    """The pieces in a built set folder, after checking them against its manifest."""
    if not valid(out):
        raise SystemExit(f"EX scene pieces at {out} do not match their manifest")
    manifest = json.loads((out / "pieces.json").read_text())
    if manifest["target"] != "cps2" or int(manifest["art_base_code"], 16) != BASE_CODE:
        raise SystemExit("EX scene pieces were not built for the CPS2 target")
    return {"manifest": manifest, "inputs_sha256": inputs_sha256,
            **{name: (out / name).read_bytes() for name in ("program.bin", "data.bin", "art.bin")}}


def pieces(edition, cache=None):
    """The CPS2 pieces for an edition, built when the cache lacks them or
    was built from other inputs."""
    region = REGIONS[edition]
    captions = captions_for(edition)
    cache = cache or TRACK / "work" / "cache" / "ex-scenes" / (region + ("-en" if captions else ""))
    key = input_key(region, captions=captions)
    out = cache / f"{region}_set" / "cps2"
    stamp = cache / "inputs.json"
    if not (stamp.exists() and json.loads(stamp.read_text())["sha256"] == key["sha256"] and valid(out)):
        out = build_pieces(region, cache, captions=captions)
        stamp.write_text(json.dumps(key, indent=2) + "\n")
    return load(out, key["sha256"])


def reference(edition, cache=None):
    """CPS1 Final Fight EX's set for the edition's region, built by the same
    chain at its CPS1 target from the same inputs (the comparison's oracle;
    rc3's members when the inputs are rc3's). Returns the set's folder."""
    region = REGIONS[edition]
    cache = cache or TRACK / "work" / "cache" / "ex-scenes" / f"{region}-cps1"
    key = input_key(region, "cps1")
    name = {"us": "ffightus01", "jp": "ffightjs01"}[region]
    out = cache / f"{region}_set"
    stamp = cache / "inputs.json"
    if not (stamp.exists() and json.loads(stamp.read_text())["sha256"] == key["sha256"]
            and (out / f"{name}.zip").exists()):
        build_pieces(region, cache, "cps1")
        stamp.write_text(json.dumps(key, indent=2) + "\n")
    return out, name


def valid(out):
    path = out / "pieces.json"
    if not path.exists():
        return False
    files = json.loads(path.read_text())["files"]
    return all((out / name).exists() and digest(out / name) == row["sha256"] for name, row in files.items())


def changed_spans(stock, built):
    """[(start, end)] of the bytes built differs from stock in."""
    spans, start = [], None
    for i in range(len(stock)):
        if stock[i] != built[i]:
            if start is None:
                start = i
        elif start is not None:
            spans.append((start, i))
            start = None
    if start is not None:
        spans.append((start, len(stock)))
    return spans


def line_cells(record, start):
    """Addresses of each line's position word in a story text record at start:
    [u16 header][u16 cell][u16 attr][char words...], lines separated by $FFFF,
    ended by $0000 (the typewriter's format, usa_text.py)."""
    cells, at = [start + 2], start + 6
    while at + 2 <= start + len(record):
        word = int.from_bytes(record[at - start:at - start + 2], "big")
        if word == 0xFFFF:
            cells.append(at + 2)
            at += 6
        elif word == 0:
            break
        else:
            at += 2
    return cells


def move_lines(program, stock, built, records):
    """EX's changes inside the text records this port rewrote: where EX moved
    a line (its position word), move the same line of the rewritten record;
    where both agree, nothing. Returns (addresses handled, moves)."""
    handled, moves = set(), []
    for start, length in records:
        end = start + length
        changed = [a for a in range(start, end) if built[a] != stock[a]]
        if not changed:
            continue
        old = line_cells(bytes(stock[start:end]), start)
        new = line_cells(bytes(program[start:end]), start)
        if len(old) != len(new):
            raise SystemExit(f"text record {start:#x}: {len(old)} lines in stock, {len(new)} rewritten")
        for a in changed:
            if built[a] == program[a]:
                handled.add(a)
                continue
            line = next((k for k, c in enumerate(old) if c <= a < c + 2), None)
            if line is None:
                continue                    # not a position word: left as a collision
            target = new[line] + (a - old[line])
            program[target] = built[a]
            handled.add(a)
            moves.append({"line": f"{old[line]:#x}", "to": f"{new[line]:#x}", "byte": f"{built[a]:02x}"})
    return handled, moves


def merge(program, stock, covered, scenes, records=(), sites=None, text=None, retime=frozenset()):
    """Lay the pieces into program (stock plus this port's patches; covered =
    the byte addresses those patches own; records = (start, length) of the
    story text records this port rewrote). sites: {address: (length, what)}
    of EX's hook sites the build patched itself (the CUT SCENES switch), on
    top of RESOLVED. text: {"block": (start, end), "home": address, "stock":
    [(start, end)]}: EX's changes inside the text block go to a copy of it at
    home (SEGA CD's text), but for the stock spans, left out of both; with
    "drop" (the restoration EX, whose SEGA CD text comes from english_ex.py's
    own tables) they are left out, the copy with them. retime:
    the addresses of CPS1 EX's story retime, which stays out (only the stock
    story, ARCADE's, runs those scenes). Returns (graphics pieces, receipt);
    nothing is written unless every change fits."""
    built = scenes["program.bin"]
    sites = {**{a: (8, why) for a, why in RESOLVED.items()}, **(sites or {})}
    trial, shadow = bytearray(program), bytearray(program)
    handled, moves = move_lines(shadow, stock, built, records)
    lo, hi = text["block"] if text else (0, 0)
    stock_spans = [range(s, e) for s, e in (text or {}).get("stock", ())]
    drop = bool((text or {}).get("drop"))
    resolved, conflicts, applied, copied, skipped, dropped, unchanged = {}, [], 0, 0, 0, 0, 0
    for start, end in changed_spans(bytes(stock[:0x100000]), built):
        for a in range(start, end):
            site = next((s for s, (n, _) in sites.items() if s <= a < s + n), None)
            if site is not None:
                resolved[site] = sites[site][1]
                continue
            if a in retime:
                skipped += 1
                continue
            mine = a in covered or program[a] != stock[a]
            if lo <= a < hi and drop:
                dropped += 1
                continue
            if lo <= a < hi:
                if any(a in r for r in stock_spans):
                    unchanged += 1
                    continue
                if a in handled:
                    continue
                if mine:
                    conflicts.append(a)
                    continue
                shadow[a] = built[a]
                copied += 1
                continue
            if mine:
                conflicts.append(a)
                continue
            trial[a] = built[a]
            applied += 1
    if conflicts:
        raise SystemExit("EX's program changes collide with this port's patches at "
                         + ", ".join(f"{a:#x}" for a in conflicts[:24]))
    receipt_text = None
    if text and drop:
        receipt_text = {"block": [f"{lo:#x}", f"{hi:#x}"], "dropped_bytes": dropped, "why": text["drop"]}
    elif text:
        home = text["home"]
        block = bytes(shadow[lo:hi])
        if any(b != 0xFF for b in trial[home:home + len(block)]):
            raise SystemExit(f"EX's text copy home {home:#x} is not free")
        trial[home:home + len(block)] = block
        receipt_text = {"block": [f"{lo:#x}", f"{hi:#x}"], "home": f"{home:#x}", "changed_bytes": copied,
                        "stock_bytes": unchanged, "sha256": hashlib.sha256(block).hexdigest()}
    manifest = scenes["manifest"]
    data_base = int(manifest["data"], 16)
    data = scenes["data.bin"].rstrip(b"\xff")
    if data_base + len(data) > len(trial):          # a slice past the end would grow the image, not fail
        raise SystemExit(f"EX's data ROM ({len(data)} bytes at {data_base:#x}) runs past the program's end")
    if any(b != 0xFF for b in trial[data_base:data_base + len(data)]):
        raise SystemExit(f"EX's data ROM home {data_base:#x} is not free")
    trial[data_base:data_base + len(data)] = data
    program[:] = trial
    art_at = SCROLL_GFX + BASE_CODE * 128
    receipt = {"inputs_sha256": scenes["inputs_sha256"], "pieces": manifest["files"],
               "program_bytes": applied, "retime_bytes_left_out": skipped,
               "resolved": {f"{a:#x}": why for a, why in sorted(resolved.items())},
               "text": receipt_text, "moved_lines": moves,
               "data": {"home": f"{data_base:#x}", "bytes": len(data)},
               "art": {"home": f"{art_at:#x}", "bytes": len(scenes["art.bin"])},
               "entries": manifest["entries"]}
    return [(art_at, scenes["art.bin"])], receipt


def retime_addresses(region, stock):
    """The bytes CPS1 EX's story retime to the CD timeline (its stage0 program
    chips: the region's retime patches, build/stage_inputs.py) changes in the
    stock program."""
    if str(FFCD / "build") not in sys.path:
        sys.path.insert(0, str(FFCD / "build"))
    import stage_inputs
    even, odd = stage_inputs.retimed(region, bytes(stock[0:0x40000:2]), bytes(stock[1:0x40000:2]))
    out = set()
    for i in range(len(even)):
        if even[i] != stock[2 * i]:
            out.add(2 * i)
        if odd[i] != stock[2 * i + 1]:
            out.add(2 * i + 1)
    return frozenset(out)


def self_test():
    stock = bytes(16)
    built = bytes([0, 1, 1, 0, 0, 0, 2, 0] + [0] * 7 + [3])
    assert changed_spans(stock, built) == [(1, 3), (6, 7), (15, 16)]
    program = bytearray(b"\xff" * 0x400000)
    program[:16] = stock
    scenes = {"program.bin": built + bytes(0x100000 - 16), "data.bin": b"\x12\x34" + b"\xff" * 30,
              "art.bin": b"\x00" * 4, "inputs_sha256": "x",
              "manifest": {"data": "0x310000", "files": {}, "entries": {}}}
    try:
        merge(program, stock + bytes(0x100000 - 16), {6}, scenes)
        raise AssertionError("a collision passed")
    except SystemExit as e:
        assert "0x6" in str(e) and program[1] == 0
    gfx, receipt = merge(program, stock + bytes(0x100000 - 16), set(), scenes, retime={15})
    assert program[1:3] == b"\x01\x01" and program[15] == 0 and program[0x310000:0x310002] == b"\x12\x34"
    assert gfx == [(SCROLL_GFX + BASE_CODE * 128, b"\x00" * 4)] and receipt["program_bytes"] == 3
    assert receipt["retime_bytes_left_out"] == 1
    # a text block: EX's change goes to the copy, a stock span's to neither
    program = bytearray(b"\xff" * 0x400000)
    program[:16] = stock
    gfx, receipt = merge(program, stock + bytes(0x100000 - 16), set(), scenes,
                         text={"block": (0, 8), "home": 0x302000, "stock": [(6, 7)]})
    assert program[1:3] == b"\x00\x00" and program[0x302001:0x302003] == b"\x01\x01"
    assert program[6] == stock[6] and program[0x302006] == stock[6] and receipt["text"]["stock_bytes"] == 1
    # a site the build patched itself is left alone
    program = bytearray(b"\xff" * 0x400000)
    program[:16] = stock
    gfx, receipt = merge(program, stock + bytes(0x100000 - 16), {1, 2}, scenes, sites={1: (2, "switch")})
    assert receipt["resolved"] == {"0x1": "switch"}
    # a record whose fix inserted a word: EX's move of line 2 lands two bytes on
    rec = bytes.fromhex("0202" "08d0" "000f" "0587" "ffff" "08dc" "000f" "0588" "0000")
    fixed = bytes.fromhex("0202" "08d0" "000f" "0587" "0010" "ffff" "08dc" "000f" "0588")
    moved = bytearray(rec); moved[10:12] = bytes.fromhex("07dc")
    assert line_cells(rec, 0) == [2, 10] and line_cells(fixed, 0) == [2, 12]
    prog2 = bytearray(fixed) + bytes(0x100000 - len(fixed))
    stock2 = rec + bytes(0x100000 - len(rec))
    built2 = bytes(moved) + bytes(0x100000 - len(moved))
    handled, moves = move_lines(prog2, stock2, built2, [(0, len(rec))])
    assert prog2[12:14] == bytes.fromhex("07dc") and 10 in handled and 11 not in handled
    print("self-test passed")


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--self-test", action="store_true")
    parser.add_argument("--edition", choices=sorted(REGIONS), help="build (or reuse) that edition's pieces")
    args = parser.parse_args(argv)
    if args.self_test:
        self_test()
        return 0
    if args.edition:
        scenes = pieces(args.edition)
        print(json.dumps(scenes["manifest"]["files"], indent=2))
        return 0
    parser.error("nothing to do")


if __name__ == "__main__":
    sys.exit(main())
