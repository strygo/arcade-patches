BUILD OR UPDATE

Run python apply.py in a terminal (Windows: py -3.13 apply.py).
Choose Build or update, then select your media and available outputs.
Settings are remembered; intact outputs can be reused safely.
Check requirements is optional. Change settings saves without building.
Enter q at any prompt to quit. Run apply.py --help for the existing
command-line options and specialized workflows described below.

Vampire Savior 2 Arrange — reconstruction kit



Version: rc4 (2026-11-07)

Backport by: Steve Gordon (https://x.com/strygo)



Vampire Savior 2 Arrange is one of the arranged editions in Capcom's 2005 PlayStation 2 Vampire: Darkstalkers Collection, and it never had an arcade release. This backport rebuilds it as a CPS-2 game.

It keeps Vampire Savior 2's game system, with Jedah as the final boss, and brings back Jon Talbain, Rikuo and Sasquatch (Gallon, Aulbath and Sasquatch in Japan) with their Vampire Hunter 2 move sets, so every fighter is selectable. Dee, the fighter Capcom made for the Arrange, has his own cell at the bottom of the select screen, and Pyron becomes an ordinary opponent.

Hidden fighters are picked from the bottom cell: press Down to spin the roulette, Start five times for Shadow, or Start seven times for Marionette. Hold Start while confirming Bishamon for Oboro Bishamon, or Jon Talbain for his dark form.

The operator menu adds a ninth difficulty, NIGHTMARE. At NIGHTMARE, a player who wins the secret Oboro Bishamon fight then faces Dee.

B.B. Hood's spoken intro against Jon Talbain is back, from the original Vampire Savior, and Dee has his own voice. On MiSTer, Dee uses the Collection music and the other music remains the arcade game's own.

The USA build is in English, with our translation; the Japan build keeps the Japanese.

This is a release candidate.



Changes:

- Jon Talbain, Rikuo and Sasquatch (Gallon, Aulbath and Sasquatch in Japan) with their Vampire Hunter 2 move sets

- Dee on his own select cell, with his own voice

- Roulette, Shadow and Marionette from the bottom cell; Oboro Bishamon and Jon Talbain's dark form with Start

- NIGHTMARE difficulty, and a secret fight with Dee

- Pyron as an ordinary opponent

- B.B. Hood's spoken intro against Jon Talbain

- The Collection’s Dee music on MiSTer, with the shared music pack built from your disc

- USA (English) and Japan builds

WHAT YOU NEED
-------------

  1. Your PlayStation 2 disc image:
     "Vampire: Darkstalkers Collection" (Japan).
  2. Your arcade romsets, all Japanese:
       - vhunt2.zip  Vampire Hunter 2
       - vsav2.zip   Vampire Savior 2
       - vsavj.zip   Vampire Savior (its sound ROMs; a merged or split set
                     with vsav.zip works too)
  3. Python 3.10 or newer. Nothing else — no emulator, no assembler.

The Collection input may be an ISO or a DVD CHD. --disc and --iso accept either;
the Japanese disc is still verified. DVD CHDs are decoded temporarily with
chdman, using an installed copy or a verified download. Use --chdman to select
its executable or containing folder. Allow extra storage for the uncompressed
DVD. Offline use needs chdman installed, cached, or in your tools bundle.

USAGE
-----

    python3 apply.py --iso <collection.iso> --rompath <romset folder> \
                     --out-dir out

This builds both regions (add --region us or --region jp for one) and creates:

    out/hbmame/<set>.zip    HBMAME
    out/mister/             ready to copy to a MiSTer SD card

The kit verifies every finished file automatically. It stops with an error if
the disc or a romset does not match.

SETS
----

    us    vsav2s05   Vampire Savior 2 Arrange (USA)
    jp    vsav2s06   Vampire Savior 2 Arrange (Japan)

ON MISTER
---------

Copy the contents of out/mister/ to the root of the MiSTer SD card:

    _Arcade/_Arcade Patches/_Restorations/<name>.mra          USA
    _Arcade/_Arcade Patches/_Restorations/_Japan/<name>.mra   Japan
    _Arcade/cores/jtcps2-cpsplus_20261101.rbf                  the CPS+ core
    games/hbmame/<set>.zip                                     the sets
    games/CPS+/vampire_arrange.zip                          the music pack

These sets need the CPS+ core included here, not the standard jtCPS2 core,
and 128 MB of SDRAM. MiSTer uses the newest dated CPS+ core it finds.
If QSound was absent from your input, keep qsound.zip or qsound_hle.zip in
games/mame.

The MiSTer entries load the shared Vampire Arrange music pack. Dee uses the
Collection music; the other music remains the arcade game's own. This is the
same pack used by Vampire Savior Arrange, so it can be shared by all three
games. The kit copies the original stereo ADX frames and their loop points
from your disc; no music recordings are included in this download.

To build just the shared pack:

    python3 music.py --iso <collection.iso> --out vampire_arrange.cpk

The normal apply.py command builds it and installs it in the correct ZIP.

ON HBMAME
---------

The sets need HBMAME's CPS+ machine driver. Start them by set name.
HBMAME uses native QSound music; the external pack plays on MiSTer.

LEGAL
-----

Unofficial fan backport. Not affiliated with or endorsed by Capcom. All game
titles, characters, and artwork remain the property of their owners. You must
own the disc and romsets used as inputs. The recipes carry only our own work:
code, translated text and layout. Do not sell this kit or distribute it
applied to game images. The CPS+ core's source and licenses are in core/.

ROM COLLECTIONS
---------------
Merged, split and complete ZIP/7z sets and extracted folders are accepted.
Use --rompath DIR (repeatable) or --romset FILE (repeatable). Names may
differ; required contents are verified by strong hashes. 7z needs installed
7-Zip. Use --check to preflight arcade inputs without supplying the disc.
Source archives are never modified.
