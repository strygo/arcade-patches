"""Kit-owned SFZ3 Upper native input/export implementation.

One reconstruction from original media (both arcade sets, both PS2 discs, the
NAOMI GD-ROM and its PIC) produces every platform layout for both regions. It
is cached per kit and input identity, and each target copies its own files
from that tree.
"""
import hashlib
import json
import os
from pathlib import Path
import shutil
from native_support import (check, execute, require, sha, source, write_zip,
    file_sha, inventory, stage_components)


def run(request, layout, kit, workspace):
    target = layout['targets'][request['target']]
    shared = Path(request['run_cache'])
    shared.mkdir(parents=True, exist_ok=True)
    os.environ.update(CPSPLUS_SWITCH_TOOLS_CACHE=request['tools_cache'], ARCADE_PYTHON_CACHE=str(Path(request['tools_cache']) / 'python'))
    os.environ.pop('CAPCOM_ARCADE_ROM_PATH', None)
    if request.get('offline'):
        os.environ['CPSPLUS_SWITCH_TOOLS_OFFLINE'] = '1'
    bindings = request['bindings']
    identity = sha(json.dumps({'kit': layout['manifest_sha256'], 'inputs': {k: b['sha256'] for k, b in bindings.items()}}, sort_keys=True).encode())
    root = shared / ('sfz3upper-' + identity)
    raw, marker = root / 'outputs', root / 'complete.json'
    from fetch_optional_tools import resolve
    chdman = Path(resolve('chdman'))
    response = {'status': 'ok', 'dependencies': {'chdman': file_sha(chdman)}}
    if marker.exists():
        require(inventory(raw) == json.loads(marker.read_text()), 'Upper reconstruction cache changed')
    elif request['operation'] != 'preflight':
        if root.exists():
            shutil.rmtree(root)
        inputs = root / 'inputs'
        for setname, members in layout['sets'].items():
            write_zip(inputs / 'roms' / (setname + '.zip'), {n: source(bindings[k]) for n, k in members.items()})
        write_zip(inputs / (layout['naomi_set'] + '.zip'), {layout['pic_member']: source(bindings[layout['pic']])})
        discs = {}
        for role, key in layout['discs'].items():
            binding = bindings[key]
            if 'member' in binding:
                stage_components(bindings, {role + '.chd': key}, inputs / 'discs')
                discs[role] = inputs / 'discs' / (role + '.chd')
            else:
                discs[role] = Path(binding['path'])
                require(discs[role].stat().st_size == binding['size'], 'Upper source disc changed')
        argv = ['--rompath', inputs / 'roms', '--ps2-us', discs['ps2-us'], '--ps2-jp', discs['ps2-jp'],
                '--naomi-chd', discs['naomi'], '--naomi-pic', inputs / (layout['naomi_set'] + '.zip'),
                '--chdman', chdman, '--work', root / 'work', '--out-dir', raw]
        execute(kit, argv)
        for name, spec in layout['original_outputs'].items():
            check(raw / name, spec)
        require(set(inventory(raw)) == set(layout['original_outputs']), 'Upper native output extent differs')
        shutil.rmtree(root / 'work')
        shutil.rmtree(inputs)
        marker.write_text(json.dumps(inventory(raw)))
    if request['operation'] == 'build':
        staging = Path(request['staging'])
        for origin, mapping in ((raw, target['mapping']), (kit, target['kit_mapping'])):
            for old, new in mapping.items():
                destination = staging / new
                destination.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(origin / old, destination)
        for name, spec in target['outputs'].items():
            check(staging / name, spec)
        response['outputs'] = target['outputs']
    return response


import native_support as contracts

SETS = {'us': 'sfa3up', 'jp': 'sfz3up'}


def define(root, slug, version, revision, native, registry):
    archive = contracts.Directory(root)
    qualified = dict(native)
    release = {'game_version': version, 'kit_revision': revision, 'requires': ['file-inputs-v1', 'zip-outputs-v1', 'run-cache-v1', 'locked-wheels-v1', 'worker-timeout-v1'], 'prerequisites': {}, 'targets': {}}

    def prerequisite(title, kind, pin, formats, action):
        contracts.file_contract(pin)
        key = kind + '-' + pin['sha256'][:20]
        release['prerequisites'][key] = {'title': title, 'kind': kind, 'formats': formats, 'alternatives': [pin], 'action': action}
        return key
    sets = {}
    for setname, rows in registry['arcade'].items():
        sets[setname] = {name: prerequisite(f'{setname}: {name}', 'rom', pin, ['ZIP', 'loose ROM files', '7z member'],
                                            'Add your canonical MAME Street Fighter Alpha 3 (USA) and Street Fighter Zero 3 (Japan) sets with QSound.')
                         for name, pin in rows.items()}
    titles = {'us': 'Street Fighter Alpha Anthology (USA), PS2 disc CHD', 'jp': "Street Fighter Zero - Fighter's Generation (Japan), PS2 disc CHD"}
    discs = {'ps2-' + region: prerequisite(titles[region], 'disc', registry['ps2'][region]['chd'], ['CHD', 'ZIP member', '7z member'],
                                            'Add the matching PS2 disc as a CHD. Files are identified by content; names may differ.')
             for region in ('us', 'jp')}
    naomi = registry['naomi']
    discs['naomi'] = prerequisite('Street Fighter Zero 3 Upper (NAOMI GD-ROM), gdl-0002.chd', 'disc', naomi['chd'], ['CHD', 'ZIP member', '7z member'],
                                  'Add your canonical MAME sfz3ugd GD-ROM CHD (gdl-0002.chd).')
    pic = prerequisite('Street Fighter Zero 3 Upper NAOMI security PIC (' + naomi['pic_member'] + ')', 'firmware', naomi['pic'], ['ZIP member', 'loose file', '7z member'],
                       'Add your canonical MAME ' + naomi['set'] + '.zip; only its security PIC is read.')
    recipe = {'manifest_sha256': 'native-manifest', 'sets': sets, 'discs': discs, 'pic': pic, 'pic_member': naomi['pic_member'],
              'naomi_set': naomi['set'], 'original_outputs': qualified, 'targets': {}}
    inputs = sorted({*discs.values(), pic, *[k for rows in sets.values() for k in rows.values()]})
    covered = set()
    for region, setname in SETS.items():
        other = SETS['jp' if region == 'us' else 'us']
        for platform in ('hbmame', 'fbneo', 'mister'):
            mapping = {}
            for name in qualified:
                if name == 'verification.json':
                    mapping[name] = f'support/{slug}/verification.json'
                    continue
                if not name.startswith(platform + '/') or other in Path(name).name:
                    continue
                if '/_Arcade/' in name and name.endswith('.mra') and ('/_Japan/' in name) != (region == 'jp'):
                    continue
                relative = name[len(platform) + 1:]
                if platform in ('hbmame', 'fbneo'):
                    relative = 'roms/' + relative if relative.endswith('.zip') else f'support/{slug}/{platform}/' + relative
                mapping[name] = relative
            contracts.require(any(n.endswith(setname + '.zip') for n in mapping), 'Missing Upper regional platform output')
            covered.update(mapping)
            support = {'readme.txt': f'support/{slug}/readme.txt'}
            outputs = {new: qualified[old] for old, new in mapping.items()}
            outputs.update({new: {'sha256': hashlib.sha256(archive.read(old)).hexdigest()} for old, new in support.items()})
            target = region + '-' + platform
            release['targets'][target] = {'platform': platform, 'variant': region, 'region': region, 'inputs': inputs, 'outputs': outputs,
                'timeout_seconds': 14400, 'minimum_free_bytes': 16 * 1024 ** 3,
                'software_notes': ['Rebuilds both regions from the original arcade sets, both PS2 disc CHDs and the NAOMI GD-ROM, then exports this layout. Later layouts reuse that reconstruction.',
                                   'chdman and the pinned NumPy/SciPy wheels are prepared automatically. Allow about 16 GB of temporary space; the first reconstruction can take an hour.'],
                'destination_requirements': {'hbmame': 'An HBMAME build that includes the Street Fighter Alpha 3 Upper sets.',
                                             'fbneo': 'An FBNeo build that includes the Street Fighter Alpha 3 Upper sets.',
                                             'mister': 'Copy to the SD card root. MiSTer requires 128 MB SDRAM; the CPS+ core is included.'}[platform]}
            recipe['targets'][target] = {'mapping': mapping, 'kit_mapping': support, 'outputs': outputs}
    contracts.require(covered == set(qualified), 'Unaccounted Upper output role')
    release['api'] = 1
    release['project'] = slug
    release['native_outputs'] = qualified
    release['requires'] = sorted(set(release['requires']) | {'native-context-v1', 'native-bindings-v1'})
    return (release, recipe)
