"""Bundled API-1 boundary for native reconstruction/export implementations.

A kit owns its family implementation, input declarations and generated export
layout. The launcher invokes apply.py directly and uses generic dependency data.
"""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import sys
import tempfile

from kit_collection import require, safe_name, load_bindings, read_binding


def digest(path):
    value = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 ** 2), b''):value.update(block)
    return value.hexdigest()


def encoded(value):return (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()


def provider(root):
    spec = importlib.util.spec_from_file_location('native_family', Path(root) / 'native_family.py')
    module = importlib.util.module_from_spec(spec)
    previous = sys.dont_write_bytecode
    try:
        sys.dont_write_bytecode = True;spec.loader.exec_module(module)
    finally:sys.dont_write_bytecode = previous
    return module


def seal(root, project, version, revision, native, media, dependencies=None):
    root = Path(root)
    if dependencies is None:
        path = root / 'native-dependencies.json'
        dependencies = json.loads(path.read_text()) if path.is_file() else {}
    # Existing source manifests keep their format; generated native metadata is
    # bound by a separate noncircular manifest after the producer's own pins.
    (root / 'native-media.json').write_bytes(encoded(media))
    identity = root / 'kit.json'
    if identity.is_file():
        value = json.loads(identity.read_text())
        if isinstance(value.get('files'), dict):
            value['files'] = {name: digest(root / name) for name in value['files']}
            identity.write_bytes(encoded(value))
    native = json.loads(json.dumps(native))
    if project == 'usf2-backport':
        for name in list(native):
            if not name.startswith(('mame/', 'hbmame/', 'mister/', 'darksoft/')) and name not in ('files.json', 'verification.json'):
                source = root / ('kit.json' if name == 'source-kit.json' else name)
                require(source.is_file(), 'Missing native USF2 software output: ' + name)
                native[name] = {'sha256': digest(source)}
    description, layout = provider(root).define(root, project, version, revision, native, media)
    description.update({key: dependencies[key] for key in ('environments', 'helpers', 'artifacts') if dependencies.get(key)})
    if any(dependencies.get(key) for key in ('environments', 'helpers', 'artifacts')):
        description['requires'] = sorted(set(description['requires']) | {'native-dependencies-v1'})
    description['execution'] = layout
    if project == 'usf2-backport':
        description['native_reports'] = ['files.json', 'verification.json']
        for name in description['native_reports']:description['native_outputs'].pop(name, None)
        layout.pop('private_reports', None)
    manifest = {'api': 1, 'project': project, 'version': version, 'kit_revision': revision,
        'files': {p.relative_to(root).as_posix(): digest(p) for p in sorted(root.rglob('*')) if p.is_file()
            and p.relative_to(root).as_posix() not in ('manifest.json', 'collection.json') and '__pycache__' not in p.parts}}
    (root / 'manifest.json').write_bytes(encoded(manifest))
    description['manifest_sha256'] = digest(root / 'manifest.json')
    description['execution']['manifest_sha256'] = description['manifest_sha256']
    (root / 'collection.json').write_bytes(encoded(description));return description


def describe(root):
    root = Path(root);definition = json.loads((root / 'collection.json').read_text())
    manifest = json.loads((root / 'manifest.json').read_text())
    require(definition.get('api') == 1 and definition['manifest_sha256'] == digest(root / 'manifest.json')
            and all(definition[a] == manifest[b] for a, b in (('project', 'project'), ('game_version', 'version'), ('kit_revision', 'kit_revision'))),
            'Native definition identity differs')
    for name, expected in manifest['files'].items():safe_name(name);require(digest(root / name) == expected, 'Native producer changed: ' + name)
    return definition


def run(root, args):
    from kit_collection import verify_binding
    root = Path(root);definition = describe(root)
    choices = [(name, target) for name, target in definition['targets'].items()
               if target['platform'] == args.platform and target.get('native_variant', target['variant']) == args.variant]
    require(len(choices) == 1, 'Unknown or ambiguous native target')
    target_id, target = choices[0];value = json.loads(args.inputs_json.read_text());load_bindings(args.inputs_json)
    bindings = value['bindings'];context = value['context']
    require(set(bindings) == set(target['inputs']), 'Incomplete or unexpected native bindings')
    require(Path(context['run_cache']).is_absolute() and Path(context['tools_cache']).is_absolute(), 'Native cache paths must be absolute')
    for key, binding in bindings.items():
        verify_binding(binding)
        requirement = definition['prerequisites'][key]
        if 'text_keys' in requirement:
            # Verify the selected private file and its required fields without
            # returning key names or values in diagnostics or result JSON.
            text = read_binding(binding).decode('utf-8-sig');rows = {}
            for line in text.splitlines():
                line = line.split('#', 1)[0].strip()
                if '=' in line:
                    name, entry = line.split('=', 1);name = name.strip().lower()
                    require(name not in rows, 'Duplicate private key field');rows[name] = entry.strip()
            require(all(name in rows and re.fullmatch('[0-9a-fA-F]{' + str(length) + '}', rows[name])
                        for name, length in requirement['text_keys'].items()), 'Private key file lacks required fields')
        else:
            require(any(binding['size'] == pin['size'] and binding['sha256'] == pin['sha256'] for pin in requirement['alternatives']),
                    'Undeclared native source identity')
    if context['offline']:os.environ['CPSPLUS_SWITCH_TOOLS_OFFLINE'] = '1'
    else:os.environ.pop('CPSPLUS_SWITCH_TOOLS_OFFLINE', None)
    with tempfile.TemporaryDirectory(prefix='native-worker-', dir=context['run_cache']) as temporary:
        request = {'target': target_id, 'operation': 'preflight' if args.check else 'build', 'bindings': bindings,
            'staging': str(args.out_dir), 'run_cache': context['run_cache'], 'tools_cache': context['tools_cache'], 'offline': context['offline']}
        result = provider(root).run(request, definition['execution'], root, Path(temporary))
    require(result['status'] == 'ok', 'Native producer failed')
    return {'api': 1, 'target': target_id, 'operation': 'check' if args.check else 'build', **result}


def main(root):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--emit-definition', metavar='PROJECT')
    parser.add_argument('--game-version');parser.add_argument('--kit-revision', type=int)
    parser.add_argument('--native-output-root', type=Path);parser.add_argument('--source-media', type=Path)
    parser.add_argument('--dependencies-json', type=Path)
    parser.add_argument('--describe-json', action='store_true');parser.add_argument('--collection-layout', action='store_true')
    parser.add_argument('--inputs-json', type=Path);parser.add_argument('--report-json', type=Path)
    parser.add_argument('--platform');parser.add_argument('--variant');parser.add_argument('--out-dir', type=Path);parser.add_argument('--check', action='store_true')
    args = parser.parse_args()
    if args.emit_definition:
        require(args.game_version and args.kit_revision and args.native_output_root and args.source_media,
                'Definition generation needs the native output tree, source identities, version and revision')
        from native_support import output_inventory
        media = json.loads(args.source_media.read_text())
        dependencies = json.loads(args.dependencies_json.read_text()) if args.dependencies_json else None
        seal(root, args.emit_definition, args.game_version, args.kit_revision, output_inventory(args.native_output_root), media, dependencies)
        return 0
    if args.describe_json:print(json.dumps(describe(root), sort_keys=True));return 0
    require(args.collection_layout and args.inputs_json and args.report_json and args.out_dir, 'Use exact bound native inputs')
    try:result = run(root, args)
    except (Exception, SystemExit) as exc:
        candidates = [name for name, target in json.loads((Path(root) / 'collection.json').read_text())['targets'].items()
                      if target['platform'] == args.platform and target.get('native_variant', target['variant']) == args.variant]
        args.report_json.write_bytes(encoded({'api': 1, 'target': candidates[0] if len(candidates) == 1 else '',
            'operation': 'check' if args.check else 'build', 'status': 'error', 'message': str(exc)}));return 2
    args.report_json.write_bytes(encoded(result));return 0
