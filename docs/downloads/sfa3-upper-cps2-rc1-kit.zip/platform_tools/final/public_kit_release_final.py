"""Deterministic public date/checksum maintenance after exact baseline rebuilding."""
import hashlib
import zlib

TABLE=0x10b54
TEXT=0x3c8580
RELEASE_DATE='261104'  # lower build date of the public release
PREVIOUS_DATE='261027'

def require(ok,message):
    if not ok:raise ValueError(message)

def identity(b):
    return {'bytes':len(b),'crc32':f'{zlib.crc32(b):08x}','sha1':hashlib.sha1(b).hexdigest(),'sha256':hashlib.sha256(b).hexdigest()}

def swap(b):
    require(len(b)%2==0,'Word extent');out=bytearray(len(b));out[::2]=b[1::2];out[1::2]=b[::2];return bytes(out)

def stream(region,date):
    name,original,country,x={'us':('STREET FIGHTER ALPHA3 UPPER','060613','U S A',0x15),'jp':('STREET FIGHTER ZERO3 UPPER','060525','J A P A N',0x13)}[region]
    return bytes([11,0x24,1])+name.encode()+bytes([0x7f,0x12,0x30,1])+' '.join(original).encode()+bytes([0x7f,x,0x3c,1])+country.encode()+bytes([0x7f,0x14,0x54,1])+b'BACKPORT'+bytes([0x7f,0x12,0x60,1])+' '.join(date).encode()+b'\0'

def checksums(raw):return [sum(raw[a:a+0x80000:0xfff])&0xffff for a in range(0,0x400000,0x80000)]

def derive(members,region,row):
    require({n:identity(b) for n,b in members.items()}==row['baseline_members'],'Complete release baseline identities')
    order=row['program_order'];raw=bytearray(swap(b''.join(members[n] for n in order)))
    old=stream(region,PREVIOUS_DATE);new=stream(region,RELEASE_DATE)
    require(raw[TEXT:TEXT+len(old)]==old and len(old)==len(new),'Original PS2/edition/date stream')
    raw[TEXT:TEXT+len(new)]=new
    values=checksums(raw);raw[TABLE:TABLE+16]=b''.join(v.to_bytes(2,'big') for v in values)
    allowed={TABLE+i for bank in (0,1,6,7) for i in (bank*2,bank*2+1)}|{TEXT+len(old)-12+i*2 for i in range(6)}
    before=swap(b''.join(members[n] for n in order));actual={i for i,(a,b) in enumerate(zip(before,raw)) if a!=b}
    digits={TEXT+len(old)-12+i*2 for i in range(6) if PREVIOUS_DATE[i]!=RELEASE_DATE[i]}
    require(actual<=allowed and digits<=actual,'Only four checksum words and the changed date digits may change')
    require(all(not(TABLE<=a<TABLE+16) for base in range(0,0x400000,0x80000) for a in range(base,base+0x80000,0xfff)),'Checksum self-overlap')
    require(checksums(raw)==[int.from_bytes(raw[a:a+2],'big') for a in range(TABLE,TABLE+16,2)],'All original checksum expectations')
    output=dict(members);physical=swap(raw)
    for i,n in enumerate(order):output[n]=physical[i*0x80000:(i+1)*0x80000]
    return output

def apply_release(members,region,recipe):
    require(recipe['schema']==1 and recipe['display_date']==RELEASE_DATE and recipe['hardware_approved'] is False,'Explicit release identity')
    row=recipe['regions'][region];output=derive(members,region,row)
    require({n:identity(b) for n,b in output.items()}==row['output_members'],'Complete corrected release identities')
    inverse=dict(output)
    for write in row['writes']:
        n=write['member'];off=write['offset'];a=bytes.fromhex(write['before_hex']);b=bytes.fromhex(write['after_hex'])
        require(len(a)==len(b) and output[n][off:off+len(b)]==b,'Declared final write')
        inverse[n]=inverse[n][:off]+a+inverse[n][off+len(a):]
    require(inverse==members,'Exact declared write inverse')
    return output
