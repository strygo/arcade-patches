"""Portable Upper naming and reversible emulator-layout adapters; no game edits."""
import argparse
import hashlib
import json
from pathlib import Path
import zipfile
import zlib


def identity(blob):
    return {'bytes':len(blob),'crc32':f'{zlib.crc32(blob):08x}',
            'sha1':hashlib.sha1(blob).hexdigest(),'sha256':hashlib.sha256(blob).hexdigest()}


def require(ok, message):
    if not ok: raise ValueError(message)


def read_zip(path):
    with zipfile.ZipFile(path) as z:
        names=z.namelist()
        require(len(names)==len(set(names)) and all(Path(n).name==n for n in names),'ZIP inventory')
        return {n:z.read(n) for n in names}


def write_zip(path, members):
    require(not path.exists(),'Output exists')
    path.parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(path,'w',compression=zipfile.ZIP_STORED) as z:
        for name,blob in sorted(members.items()):
            info=zipfile.ZipInfo(name,(1980,1,1,0,0,0));info.create_system=3;info.external_attr=0o100644<<16
            z.writestr(info,blob)


def validate(contract):
    require(contract['schema']==1 and set(contract['regions'])=={'us','jp'},'Naming schema')
    shared={}
    for region,row in contract['regions'].items():
        require(row['set_id']=={'us':'sfa3up','jp':'sfz3up'}[region] and len(row['members'])==26,'Set inventory')
        names=set()
        for old,m in row['members'].items():
            require(Path(old).name==old and Path(m['name']).name==m['name'] and m['name'] not in names,'Unsafe/duplicate name')
            names.add(m['name'])
            require(m['name'] not in shared or shared[m['name']]==m['sha256'],'Shared-name content conflict')
            shared[m['name']]=m['sha256']
            require(not m['stock'] or m['name']==m['stock']['name'],'Stock filename changed')
    return contract


def canonicalize(members, row):
    require(set(members)==set(row['members']),'Release member inventory')
    result={}
    for old,m in row['members'].items():
        require(identity(members[old])=={k:m[k] for k in ('bytes','crc32','sha1','sha256')},'Member identity: '+old)
        result[m['name']]=members[old]
    return result


def wordswap(blob):
    require(len(blob)%2==0,'Odd word stream')
    out=bytearray(len(blob));out[::2]=blob[1::2];out[1::2]=blob[::2];return bytes(out)


def fbneo(members,row):
    """Split the upper bus into equal ROM_LOAD64_WORD lanes; swap raw samples."""
    require(set(members)=={m['name'] for m in row['members'].values()},'Canonical inventory')
    result=dict(members);gfx=result.pop(row['members']['upper.gfx']['name'])
    require(len(gfx)==0x2000000,'Upper graphics extent')
    for desc in row['fbneo_adapters']['graphics']:
        start=desc['group']*0x1000000;lane=desc['lane']*2
        part=bytearray(0x400000);part[::2]=gfx[start+lane:start+0x1000000:8];part[1::2]=gfx[start+lane+1:start+0x1000000:8]
        require(identity(part)=={k:desc[k] for k in ('bytes','crc32','sha1','sha256')},'Graphics adapter identity')
        result[desc['name']]=bytes(part)
    sample=row['fbneo_adapters']['samples'];out=wordswap(result.pop(row['members']['upper.snd']['name']))
    require(identity(out)=={k:sample[k] for k in ('bytes','crc32','sha1','sha256')},'Sample adapter identity')
    result[sample['name']]=out
    result.pop('dl-1425.bin')
    return result


def inverse_fbneo(members,row):
    result=dict(members);gfx=bytearray(0x2000000)
    for d in row['fbneo_adapters']['graphics']:
        blob=result.pop(d['name']);start=d['group']*0x1000000;lane=d['lane']*2
        require(identity(blob)=={k:d[k] for k in ('bytes','crc32','sha1','sha256')},'Inverse lane identity')
        gfx[start+lane:start+0x1000000:8]=blob[::2];gfx[start+lane+1:start+0x1000000:8]=blob[1::2]
    result[row['members']['upper.gfx']['name']]=bytes(gfx)
    d=row['fbneo_adapters']['samples'];result[row['members']['upper.snd']['name']]=wordswap(result.pop(d['name']))
    return result


def hbmame_definition(row):
    m=row['members'];name=row['set_id'];lines=[f'ROM_START( {name} )']
    def load(old,offset,macro='ROM_LOAD',length=None):
        d=m[old];return f'\t{macro}( "{d["name"]}", 0x{offset:x}, 0x{length or d["bytes"]:x}, CRC({d["crc32"]}) SHA1({d["sha1"]}) )'
    lines+=['\tROM_REGION( 0x800000, "maincpu", ROMREGION_ERASEFF )']
    for i,old in enumerate(row['program_order']):lines+=[load(old,i*0x80000,'ROM_LOAD16_WORD_SWAP')]
    lines += [load('upper.prg',0x400000,'ROM_LOAD16_WORD_SWAP'),'\tROM_REGION( 0x4000000, "gfx", ROMREGION_ERASEFF )']
    for i,old in enumerate(row['graphics_order']):lines+=[load(old,(i//4)*0x1000000+(i%4)*2,'ROM_LOAD64_WORD')]
    lines += [load('upper.gfx',0x2000000),'\tROM_REGION( 0x88000, "audiocpu", 0 )',load('sz3.01',0,length=0x8000),'\tROM_CONTINUE( 0x10000, 0x18000 )',load('sz3.02',0x28000),load('upper.z80',0x48000),'\tROM_REGION( 0x2000000, "qsound", 0 )',load('sz3.11m',0,'ROM_LOAD16_WORD_SWAP'),load('sz3.12m',0x400000,'ROM_LOAD16_WORD_SWAP'),load('upper.snd',0x800000),'\tROM_REGION( 0x20, "key", 0 )',load(row['key'],0),'ROM_END',f'GAME( 2026, {name}, sfa3, cps2plus, cps2_2p6b, cps2plus_state, init_cps2plus, ROT0, "Capcom / backport", "{row["title"]}", 0 )']
    return '\n'.join(lines)+'\n'


def fbneo_definition(row):
    m=row['members'];name=row['set_id'];symbol=name.capitalize();lines=[f'static struct BurnRomInfo {symbol}RomDesc[] = {{']
    def add(d,kind):lines.append(f'\t{{ "{d["name"]}", 0x{d["bytes"]:x}, 0x{d["crc32"]}, {kind} }},')
    for old in row['program_order']+['upper.prg']:add(m[old],'CPS2_PRG_68K | BRF_ESS | BRF_PRG')
    for old in row['graphics_order']:add(m[old],'CPS2_GFX | BRF_GRA')
    for d in row['fbneo_adapters']['graphics']:add(d,'CPS2_GFX | BRF_GRA')
    for old in ('sz3.01','sz3.02','upper.z80'):add(m[old],'CPS2_PRG_Z80 | BRF_ESS | BRF_PRG')
    for old in ('sz3.11m','sz3.12m'):add(m[old],'CPS2_QSND | BRF_SND')
    add(row['fbneo_adapters']['samples'],'CPS2_QSND | BRF_SND');add(m[row['key']],'CPS2_ENCRYPTION_KEY')
    lines += ['};',f'STD_ROM_PICK({symbol})',f'STD_ROM_FN({symbol})',f'struct BurnDriver BurnDrvCps{symbol} = {{',f'\t"{name}", "sfa3", NULL, NULL, "2026",',f'\t"{row["title"]}\\0", NULL, "Capcom / backport", "CPS2",','\tNULL, NULL, NULL, NULL,','\tBDF_GAME_WORKING | BDF_CLONE | BDF_HACK, 2, HARDWARE_CAPCOM_CPS2, GBF_VSFIGHT, FBF_SF,',f'\tNULL, {symbol}RomInfo, {symbol}RomName, NULL, NULL, NULL, NULL, Cps2CustomInputInfo, NULL,','\tUpperBackportInit, Cps2PlusExit, Cps2Frame, CpsRedraw, Cps2PlusScan,','\t&CpsRecalcPal, 0x1000, 384, 224, 4, 3','};']
    return '\n'.join(lines)+'\n'


def export_archives(contract, archives, out):
    validate(contract);out=Path(out);require(not out.exists(),'Output exists')
    report={}
    for r,row in contract['regions'].items():
        canonical=canonicalize(read_zip(archives[r]),row);adapted=fbneo(canonical,row)
        require(inverse_fbneo(adapted,row)=={n:b for n,b in canonical.items() if n!='dl-1425.bin'},'Reversible mapping')
        for platform,blobs in (('hbmame',canonical),('fbneo',adapted)):
            path=out/platform/(row['set_id']+'.zip');write_zip(path,blobs)
            report[r+'_'+platform]=identity(path.read_bytes())
    (out/'qualification.json').write_text(json.dumps({'schema':1,'byte_preserving':True,'archives':report,'runtime_qualified':False},indent=2)+'\n',newline='\n')
    return report


def main():
    p=argparse.ArgumentParser();p.add_argument('--contract',type=Path,required=True);p.add_argument('--us',type=Path,required=True);p.add_argument('--jp',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args()
    export_archives(json.loads(a.contract.read_text()),{'us':a.us,'jp':a.jp},a.out)

if __name__=='__main__':main()
