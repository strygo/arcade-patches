"""Pure native image projection from the qualified MiSTer packager."""
import hashlib,copy
import xml.etree.ElementTree as ET
MIB = 1 << 20
MACHINES = {'us': 'sfa3u', 'jp': 'sfz3j'}

def require(ok, message):
    if not ok:
        raise ValueError(message)

def digest(data):
    return hashlib.sha256(data).hexdigest()

def wordswap(data):
    require(len(data) % 2 == 0, 'Word-aligned input required')
    out = bytearray(len(data))
    out[::2] = data[1::2]
    out[1::2] = data[::2]
    return bytes(out)
LEGACY_TO_SFZ3J = {'sz3u.03c': 'sz3j.03c', 'sz3u.04c': 'sz3j.04c', 'sfa3u.key': 'sfz3j.key'}

def names(region, template=None):
    """Program member names: from the MRA template's set when given, else the legacy regional rule."""
    machine = template_set(template) if template is not None else MACHINES[region]
    prefix = 'sz3u' if machine == 'sfa3u' else 'sz3j'
    return [prefix + '.03c', prefix + '.04c'] + [f'sz3.{n:02d}c' for n in range(5, 10)] + ['sz3.10b']

def template_set(template):
    """'sfa3u' or 'sfz3j': the stock set whose key part the template names."""
    keys = [p.get('name') for p in template.iter('part') if (p.get('name') or '').endswith('.key')]
    require(len(keys) == 1 and keys[0] in ('sfa3u.key', 'sfz3j.key'), 'Template must name exactly one SFA3 key part')
    return keys[0][:-4]

def members_for(template, members):
    """The same member bytes under the template's names (a pure, checked rename)."""
    machine = template_set(template)
    table = LEGACY_TO_SFZ3J if machine == 'sfz3j' else {v: k for k, v in LEGACY_TO_SFZ3J.items()}
    out = {table.get(n, n): v for n, v in members.items()}
    require(len(out) == len(members) and sorted(map(digest, out.values())) == sorted(map(digest, members.values())), 'Template member rename must preserve every byte')
    require(machine + '.key' in out and all((n in out for n in names(None, template))), 'Archive lacks the template program members')
    return out

def graphics(members):
    out = bytearray(b'\xff' * (64 * MIB))
    for bank in range(2):
        for lane in range(4):
            data = members[f'sz3.{13 + lane * 2 + bank}m']
            require(len(data) == 4 * MIB, 'Canonical graphics member extent')
            begin = bank * 16 * MIB + lane * 2
            end = (bank + 1) * 16 * MIB
            out[begin:end:8] = data[::2]
            out[begin + 1:end:8] = data[1::2]
    require(len(members['upper.gfx']) == 32 * MIB, 'Upper graphics extent')
    out[32 * MIB:] = members['upper.gfx']
    return bytes(out)

def image(template, members, region):
    from image_format import layout, decode
    first = template.find("./rom[@index='0']/part")
    members = members_for(template, members)
    original = bytes.fromhex(first.text) + members[template_set(template) + '.key']
    require(len(original) == 64, 'Stock regional configuration/key header required')
    envelope = layout(32, 512 * 1024)
    header = envelope.encode(original, resident_limit=128 * MIB)
    cpu = b''.join((members[n] for n in names(region, template))) + members['upper.prg']
    z80 = members['sz3.01'] + members['sz3.02'] + members['upper.z80']
    samples = wordswap(members['sz3.11m']) + wordswap(members['sz3.12m']) + members['upper.snd']
    regions = (cpu, z80, samples, members['dl-1425.bin'][:8192], graphics(members))
    require(tuple(map(len, regions)) == tuple((n for at, n in envelope.regions)), 'Complete native capacity extents')
    native = header + b''.join(regions)
    require(decode(header, resident_limit=128 * MIB, actual_bytes=len(native)) == envelope, 'Native descriptor closure')
    return (native, header, {name: {'offset': at, 'bytes': n, 'sha256': digest(data)} for name, (at, n), data in zip(('cpu', 'z80', 'samples', 'dsp', 'graphics'), envelope.regions, regions, strict=True)})

def xml(root):
    root = copy.deepcopy(root)
    ET.indent(root)
    return ET.tostring(root, encoding='utf-8', xml_declaration=True) + b'\n'
