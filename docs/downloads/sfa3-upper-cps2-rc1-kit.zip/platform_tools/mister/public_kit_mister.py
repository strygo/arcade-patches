"""Package and verify public Upper MiSTer SD trees without changing game bytes."""
import argparse,copy,hashlib,json,shutil,xml.etree.ElementTree as ET,zipfile,zlib
from pathlib import Path
import mister_native as native
import mra_assembly

ROOT=Path(__file__).resolve().parent
REGIONS={'us':('sfa3up','Street Fighter Alpha 3 Upper (USA) [Backport]',''),
         'jp':('sfz3up','Street Fighter Zero 3 Upper (Japan) [Backport]','_Japan/')}
MENU='_Arcade/_Arcade Patches/_Restorations/'
def require(ok,msg):
    if not ok:raise ValueError(msg)
def sha(b):return hashlib.sha256(b).hexdigest()
def identity(b):return {'bytes':len(b),'sha256':sha(b)}
def read_json(p):return json.loads(p.read_text())
def checked_tools():
    pins=read_json(ROOT/'mister-tools.json')
    for n,p in pins['files'].items():require(identity((ROOT/n).read_bytes())==p,'MiSTer helper changed: '+n)
    return pins

def members(path,contract,region):
    row=contract['regions'][region];require(row['set_id']==REGIONS[region][0],'Public set identity')
    with zipfile.ZipFile(path) as archive:
        require(len(archive.namelist())==26 and len(set(archive.namelist()))==26,'Complete unambiguous game archive')
        require(set(archive.namelist())=={r['name'] for r in row['members'].values()},'Canonical archive inventory')
        original={}
        for old,p in row['members'].items():
            b=archive.read(p['name'])
            require(identity(b)=={'bytes':p['bytes'],'sha256':p['sha256']} and hashlib.sha1(b).hexdigest()==p['sha1'] and f'{zlib.crc32(b):08x}'==p['crc32'],'Canonical member identity: '+p['name'])
            original[old]=b
    return original

def mra(template,legacy,contract,region,header,md5,core):
    row=contract['regions'][region];set_id,title,subdir=REGIONS[region];tree=copy.deepcopy(template)
    for tag,value in [('name',title),('setname',set_id),('rbf',core['binding'])]:
        node=tree.find(tag)
        if node is None:node=ET.SubElement(tree,tag)
        node.text=value
    rom=tree.find("./rom[@index='0']");require(rom is not None,'Template ROM index0')
    old=list(rom);program_names=native.names(region,template)
    program=[p for p in old if p.tag=='part' and p.get('name') in program_names]
    key=next(p for p in old if p.get('name')=='sfz3j.key')
    sound=[p for p in old if p.get('name') in ('sz3.01','sz3.02')]
    samples=[p for p in old if p.tag=='interleave' and p.get('output')=='16']
    graphics=[p for p in old if p.tag=='interleave' and p.get('output')=='64']
    dsp=next(p for p in old if p.get('name')=='dl-1425.bin')
    require([p.get('name') for p in program]==program_names and len(sound)==len(samples)==len(graphics)==2,'Complete original physical MRA layout')
    rom.clear();rom.attrib.update(index='0',zip='/mame/'+set_id+'.zip',md5='None',asm_md5=md5,address='0x30000000')
    ET.SubElement(rom,'part').text=header[:44].hex(' ');rom.append(key);ET.SubElement(rom,'part').text=header[64:].hex(' ')
    for group,extra in ((program,'upper.prg'),(sound,'upper.z80'),(samples,'upper.snd')):
        for node in group:rom.append(node)
        ET.SubElement(rom,'part',name=extra)
    rom.append(dsp)
    for node in graphics:rom.append(node)
    ET.SubElement(rom,'part',name='upper.gfx')
    rename={native.LEGACY_TO_SFZ3J.get(n,n):p['name'] for n,p in row['members'].items()}
    normalized=native.members_for(template,legacy)
    for part in rom.iter('part'):
        name=part.get('name')
        if name:
            require(name in normalized and name in rename,'Unbound MRA member')
            part.set('crc',f'{zlib.crc32(normalized[name]):08x}');part.set('name',rename[name])
    require(not list(rom.iter('patch')),'Unexpected game patch in public MRA')
    return tree,MENU+subdir+title+'.mra'

def verify_region(archive,contract,region,core,actual=None):
    legacy=members(archive,contract,region);template=ET.parse(ROOT/'jp.mra').getroot()
    image,header,regions=native.image(template,legacy,region)
    tree,name=mra(template,legacy,contract,region,header,hashlib.md5(image).hexdigest(),core);text=native.xml(tree)
    if actual is not None:require(actual==text,'Public MRA metadata/ordering/bindings changed')
    assembled=mra_assembly.assemble(text.decode(),mra_assembly.ZipSource([archive],check_crc=True))
    require(assembled==image,'Independent MRA assembly differs from complete native physical layout')
    require(sha(image)==checked_tools()['image_authority']['native_images'][region],'Native image differs from release image contract')
    return text,name,{'archive':{'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes())},'mra_sha256':sha(text),'image':{'bytes':len(image),'sha256':sha(image),'md5':hashlib.md5(image).hexdigest()},'header_sha256':sha(header),'native_regions':regions,'independent_mra_assembly':True}

def package(archives,names,core,out):
    tools=checked_tools();contract=read_json(names) if isinstance(names,(str,Path)) else names;lock=read_json(ROOT/'core.json')
    require(identity(Path(core).read_bytes())=={'bytes':lock['bytes'],'sha256':lock['sha256']},'Approved public core identity')
    require(not out.exists(),'Fresh public SD tree required');out.mkdir(parents=True);rows={}
    for region,(set_id,_,_) in REGIONS.items():
        archive=Path(archives)/(set_id+'.zip');text,name,report=verify_region(archive,contract,region,lock)
        target=out/'games/mame'/archive.name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(archive,target)
        target=out/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(text);rows[region]={**report,'mra':name,'archive_path':'games/mame/'+archive.name}
    target=out/'_Arcade/cores'/lock['filename'];target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(core,target)
    metadata=out/'licenses';metadata.mkdir()
    for name in ('MRA-GPL-2.0.txt','jp.mra','core.json',*(n+'-LICENSE.txt' for n in tools['core_license_sources']['licenses'])):
        shutil.copyfile(ROOT/name,metadata/name)
    (metadata/'SOURCES.txt').write_text('MRA template: https://github.com/'+tools['template']['repository']+'/blob/'+tools['template']['revision']+'/'+tools['template']['path']+'\nCore: https://github.com/'+lock['repository']+'/tree/'+lock['source_revision']+'\nApproved core workflow run '+str(lock['workflow_run_id'])+'. No core modifications.\n',newline='\n')
    (out/'INSTALL-MISTER.txt').write_text('Copy _Arcade and games to the matching folders on your MiSTer SD card. Keep both game ZIPs zipped. Requires 128 MiB SDRAM and the included dated jtcps2-cpsplus core. The games appear under _Arcade/_Arcade Patches/_Restorations; the Japanese game is in _Japan.\n',newline='\n')
    auxiliary={p.relative_to(out).as_posix():identity(p.read_bytes()) for p in metadata.iterdir()}
    auxiliary['INSTALL-MISTER.txt']=identity((out/'INSTALL-MISTER.txt').read_bytes())
    record={'auxiliary':auxiliary,'schema':1,'public_mister':True,'game_bytes_changed':tools['image_authority']['game_bytes_changed'],'image_authority':tools['image_authority'],'core':lock,'names':contract,'regions':rows,'tools_sha256':sha((ROOT/'mister-tools.json').read_bytes())}
    (out/'public-mister.json').write_text(json.dumps(record,sort_keys=True,indent=2)+'\n',newline='\n');return verify(out)

def verify(out):
    checked_tools();record=read_json(out/'public-mister.json');lock=read_json(ROOT/'core.json')
    require(record['image_authority']==checked_tools()['image_authority'],'Native image authority changed')
    require(record['core']==lock and record['tools_sha256']==sha((ROOT/'mister-tools.json').read_bytes()),'Public core/tool contract changed')
    require(identity((out/'_Arcade/cores'/lock['filename']).read_bytes())=={'bytes':lock['bytes'],'sha256':lock['sha256']},'Approved delivered core changed')
    for name,pin in record['auxiliary'].items():require(identity((out/name).read_bytes())==pin,'Public license/source notice changed: '+name)
    for region,row in record['regions'].items():
        _,name,report=verify_region(out/row['archive_path'],record['names'],region,lock,(out/row['mra']).read_bytes())
        require(name==row['mra'] and all(row[k]==v for k,v in report.items()),'Public MiSTer receipt changed')
    require(set(record['regions'])==set(REGIONS),'Missing regional public MRA')
    return record

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--verify',type=Path)
    for n in ('archives','names','core','out'):p.add_argument('--'+n,type=Path)
    a=p.parse_args()
    if a.verify:report=verify(a.verify)
    else:
        require(all((a.archives,a.names,a.core,a.out)),'Archives/names/core/out required');report=package(a.archives,a.names,a.core,a.out)
    print(json.dumps(report,sort_keys=True))
if __name__=='__main__':main()
