#!/usr/bin/env python3
"""Executable draft of the bounded capacity image envelope; not a release ABI.

Validates native-memory metadata without allocating ROM buffers. CPS+ packs
are outside this stage. Versions 2 and 3 are development identities. This
reference must agree with the native loader and DDR readback before freeze.
"""
from __future__ import annotations

import argparse
from dataclasses import dataclass
import json
from pathlib import Path
import struct

MIB = 1 << 20
HEADER_BYTES = 128
MARKER = b"C2\x02\x07"
DESCRIPTOR = b"C2EX"
REGIONS = ("cpu", "z80", "samples", "dsp", "graphics")
SIZES = (8 * MIB, 256 * 1024, 16 * MIB, 8192, 64 * MIB)
VERSIONS = {16: 2, 32: 3}
Z80_SIZES = (256 * 1024, 512 * 1024)


def require(ok, message):
    if not ok: raise ValueError(message)


@dataclass(frozen=True)
class Envelope:
    regions: tuple[tuple[int, int], ...]
    native_end: int
    sample_mib: int = 16

    @property
    def image_bytes(self):
        return self.native_end

    def validate(self, *, resident_limit, actual_bytes=None):
        require(HEADER_BYTES <= resident_limit <= 0xffffffff, "invalid resident image budget")
        require(len(self.regions) == 5, "exactly five native regions required")
        require(self.sample_mib in VERSIONS, "unknown native sample profile")
        end = HEADER_BYTES
        require(self.regions[1][1] in Z80_SIZES, "Z80 ROM must be 256 or 512 KiB")
        sizes = (SIZES[0], self.regions[1][1], self.sample_mib * MIB, *SIZES[3:])
        for name, (offset, size), expected in zip(REGIONS, self.regions, sizes):
            require(offset == end, f"{name}: region must follow preceding region without gaps or overlaps")
            require(size == expected, f"{name}: draft capacity profile requires {expected} bytes")
            require(0 < offset + size <= 0xffffffff, f"{name}: 32-bit range overflow")
            end = offset + size
        require(end == self.native_end and end < 1 << 27, "native end is inconsistent or exceeds the 27-bit core bus")
        require(self.regions[3][0] - HEADER_BYTES & 8191 == 0, "DSP bulk offset must be 8 KiB aligned")
        require(self.image_bytes <= resident_limit, "native image exceeds the declared resident DDR budget")
        if actual_bytes is not None:
            require(actual_bytes == self.image_bytes, "truncated image or unexpected trailing bytes")
        return self

    def encode(self, native_header, *, resident_limit):
        self.validate(resident_limit=resident_limit)
        require(len(native_header) == 64, "original CPS header must be exactly 64 bytes")
        require(all(n in (0, 0xffff) for n in struct.unpack_from("<2H", native_header, 8)),
                "template already has music metadata")
        header = bytearray(native_header + bytes(64))
        # Keep the original config/keys (16..63) at their native addresses. The
        # old four KiB starts are a redundant checked mirror, relative to payload.
        starts = [self.regions[i][0] - HEADER_BYTES for i in (1, 2, 4, 3)]
        require(all(n % 1024 == 0 and n // 1024 < 65536 for n in starts), "native starts cannot be mirrored")
        struct.pack_into("<4H", header, 0, *(n // 1024 for n in starts))
        header[8:12] = bytes(4)
        header[12:16] = b"C2" + bytes((VERSIONS[self.sample_mib], 7))
        header[64:68] = DESCRIPTOR
        struct.pack_into("<HH", header, 68, VERSIONS[self.sample_mib], 64)
        fields = [n for region in self.regions for n in region]
        fields += [self.native_end, 0, 0, 0]
        struct.pack_into("<14I", header, 72, *fields)
        return bytes(header)


def decode(header, *, resident_limit, actual_bytes=None):
    require(len(header) == HEADER_BYTES, "capacity header must be exactly 128 bytes")
    sample_mib = next((m for m, v in VERSIONS.items() if header[12:16] == b"C2" + bytes((v, 7))), None)
    require(sample_mib is not None and header[64:68] == DESCRIPTOR, "unknown capacity identity")
    require(header[8:12] == bytes(4), "legacy music pointer must be disabled for capacity images")
    require(struct.unpack_from("<HH", header, 68) == (VERSIONS[sample_mib], 64), "unknown descriptor version or size")
    fields = struct.unpack_from("<14I", header, 72)
    require(fields[11:] == (0, 0, 0), "reserved descriptor fields must be zero; appended packs are unsupported")
    envelope = Envelope(tuple(zip(fields[:10:2], fields[1:10:2])), fields[10], sample_mib)
    envelope.validate(resident_limit=resident_limit, actual_bytes=actual_bytes)
    starts = struct.unpack_from("<4H", header)
    expected = tuple((envelope.regions[i][0] - HEADER_BYTES) // 1024 for i in (1, 2, 4, 3))
    require(starts == expected, "legacy region mirror disagrees with descriptor")
    return envelope


def layout(sample_mib=16, z80_bytes=Z80_SIZES[0]):
    require(sample_mib in VERSIONS, "unknown native sample profile")
    regions = []
    end = HEADER_BYTES
    require(z80_bytes in Z80_SIZES, "Z80 ROM must be 256 or 512 KiB")
    for size in (SIZES[0], z80_bytes, sample_mib * MIB, *SIZES[3:]):
        regions.append((end, size)); end += size
    return Envelope(tuple(regions), end, sample_mib)


def self_test():
    for sample_mib in VERSIONS:
        wide = layout(sample_mib)
        encoded = wide.encode(bytes(64), resident_limit=128 * MIB)
        assert decode(encoded, resident_limit=128 * MIB, actual_bytes=wide.image_bytes) == wide
        for offset in [*range(16), *range(64, 128)]:
            altered = bytearray(encoded); altered[offset] ^= 1
            try: decode(bytes(altered), resident_limit=128 * MIB, actual_bytes=wide.image_bytes)
            except ValueError: pass
            else: raise AssertionError(f"{sample_mib} MiB: corrupt field at {offset} accepted")
        for length in (wide.image_bytes-1, wide.image_bytes+1, wide.image_bytes+(1 << 27),
                       layout(48-sample_mib).image_bytes):
            try: decode(encoded, resident_limit=128 * MIB, actual_bytes=length)
            except ValueError: pass
            else: raise AssertionError(f"{sample_mib} MiB: wrong extent admitted")
        mixed = bytearray(encoded); mixed[14] = 5 - mixed[14]
        try: decode(bytes(mixed), resident_limit=128 * MIB, actual_bytes=wide.image_bytes)
        except ValueError: pass
        else: raise AssertionError("cross-profile envelope accepted")
    for sample_mib in VERSIONS:
        expanded = layout(sample_mib, Z80_SIZES[1])
        header = expanded.encode(bytes(64), resident_limit=128 * MIB)
        assert decode(header, resident_limit=128 * MIB, actual_bytes=expanded.image_bytes) == expanded
        assert expanded.native_end == layout(sample_mib).native_end + 256 * 1024
        for size in (0, 0x3ffff, 0x60000, 0x80001):
            try: layout(sample_mib, size)
            except ValueError: pass
            else: raise AssertionError("unsupported Z80 extent accepted")
    limit = 128 * MIB  # Test parameter, not a claim about the available host window.
    original = bytes([255]) * 64
    envelope = layout()
    for budget in (limit, envelope.image_bytes):
        header = envelope.encode(original, resident_limit=budget)
        assert header[16:64] == original[16:64]
        assert decode(header, resident_limit=budget, actual_bytes=envelope.image_bytes) == envelope
    mixed = bytearray(original); mixed[8:10] = bytes(2)
    assert envelope.encode(bytes(mixed), resident_limit=limit)[16:64] == original[16:64]
    good = envelope.encode(original, resident_limit=limit)
    for offset in (12, 14, 15, 64, 68, 70, 72, 76, 80, 84, 88, 92,
                   96, 100, 104, 108, 112, 116, 120, 124, 0, 8):
        altered = bytearray(good); altered[offset] ^= 1
        try: decode(bytes(altered), resident_limit=limit, actual_bytes=envelope.image_bytes)
        except ValueError: pass
        else: raise AssertionError(f"corrupt field at {offset} accepted")
    for length in (envelope.image_bytes - 1, envelope.image_bytes + 1,
                   envelope.image_bytes + (1 << 27)):
        try: decode(good, resident_limit=limit, actual_bytes=length)
        except ValueError: pass
        else: raise AssertionError("wrong image length accepted")
    bad_regions = list(envelope.regions)
    bad_regions[-1] = (0xfffffc00, SIZES[-1])
    for invalid, budget in (
            (envelope, envelope.image_bytes - 1),
            (Envelope(tuple(bad_regions), envelope.native_end), limit)):
        try: invalid.validate(resident_limit=budget)
        except ValueError: pass
        else: raise AssertionError("invalid native range or budget accepted")
    print("PASS native-only envelope: round trips, exact length, fields, reserved pack fields, ranges, DDR budget")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("image", type=Path, nargs="?")
    parser.add_argument("--resident-limit-mib", type=int)
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args()
    if args.self_test: self_test(); return
    if args.image is None or args.resident_limit_mib is None:
        parser.error("image and explicit validated resident budget required")
    with args.image.open("rb") as file: header = file.read(HEADER_BYTES)
    envelope = decode(header, resident_limit=args.resident_limit_mib * MIB,
                      actual_bytes=args.image.stat().st_size)
    print(json.dumps({"regions": dict(zip(REGIONS, envelope.regions)), "native_end": envelope.native_end,
                      "image_bytes": envelope.image_bytes, "sample_mib": envelope.sample_mib}, indent=2))


if __name__ == "__main__": main()
