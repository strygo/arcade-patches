Street Fighter Alpha 3 Upper (CPS-2) — reconstruction kit

Version: rc1 (2026-11-04)
Backport by: Steve Gordon (https://x.com/strygo)

Street Fighter Alpha 3 Upper comes to CPS-2 with Guile, Fei Long, Dee Jay, T. Hawk, Evil Ryu and Shin Akuma. The boxer, Juli and Juni have their own cells on the select screen.
Guile, Fei Long, Dee Jay and T. Hawk bring their stages, music and arcade endings. The USA build includes the Street Fighter Alpha 3 English restoration; the Japan build keeps Japanese text and names.
This version includes Arcade mode and its two-player challenge. World Tour, Dramatic Battle and the other console modes are not included.
On MiSTer, it requires the included CPS+ core and 128 MB SDRAM. Computer play requires an HBMAME or FBNeo build that includes the Upper sets. This is a release candidate.

Changes:
- Guile, Fei Long, Dee Jay, T. Hawk, Evil Ryu and Shin Akuma join the playable roster
- The boxer, Juli and Juni have their own select cells
- Added stages, arcade endings, voices and QSound music
- USA (English) and Japan versions

INPUTS AND BUILD

The Arcade Patches builder app prepares everything it needs. To build by
hand, use Python 3.12 or newer with NumPy 2.2.6, SciPy 1.15.3 and chdman.
Supply the original arcade ROM sets, USA Alpha
Anthology and Japanese Zero Fighter’s Generation PS2 discs, and the
Zero 3 Upper NAOMI GD-ROM CHD and sfz3ugd.zip security PIC archive.
The exact accepted input identities are listed in builder/media/inputs.json.

python3 apply.py --rompath /path/to/roms --ps2-us /path/to/us.chd \
  --ps2-jp /path/to/jp.chd --naomi-chd /path/to/gdl-0002.chd \
  --naomi-pic /path/to/sfz3ugd.zip --chdman /path/to/chdman \
  --work /external/fresh-work --out-dir /external/fresh-output

Both output directories must be new. Allow at least 8 GiB of free storage.
--rompath may be repeated; --platform selects hbmame, fbneo or mister.
The default builds all three layouts. No network download is needed.

OUTPUTS

hbmame/ and fbneo/ contain the regional game ZIPs. Use an HBMAME or FBNeo
build that includes the Upper sets. The mister/ tree contains
the regional launchers, game ZIPs and CPS+ core; copy its contents to the
root of your MiSTer SD card. MiSTer requires 128 MB SDRAM.
The builder never uploads or installs files automatically.
