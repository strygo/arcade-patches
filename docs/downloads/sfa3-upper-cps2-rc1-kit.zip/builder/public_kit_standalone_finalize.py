"""Seal both complete release-baseline archives from the rebuilt program and nonprogram members.

Contains no game bytes. This finalizer certifies exact member and container identities only.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import tempfile
import public_kit_archive as archive

PROGRAM = {'jp': ('sz3j.03c', 'sz3j.04c', 'sz3.05c', 'sz3.06c', 'sz3.07c', 'sz3.08c', 'sz3.09c', 'sz3.10b', 'upper.prg'),
           'us': ('sz3u.03c', 'sz3u.04c', 'sz3.05c', 'sz3.06c', 'sz3.07c', 'sz3.08c', 'sz3.09c', 'sz3.10b', 'upper.prg')}


def require(ok,message):
    if not ok:raise ValueError(message)


def sha(blob):return hashlib.sha256(blob).hexdigest()


def members(folder,names):
    require(folder.is_dir() and not folder.is_symlink(),'Real component member directory required')
    actual={p.name for p in folder.iterdir()}
    require(actual==set(names),'Exact component member inventory differs: '+str(folder))
    result={}
    for name in names:
        require(type(name)is str and Path(name).name==name and '\\'not in name and name not in ('.','..'),'Local physical member basename required')
        p=folder/name;require(p.is_file()and not p.is_symlink(),'Regular physical member required')
        result[name]=p.read_bytes()
    return result


def construct(program,nonprogram,contracts):
    require(set(program)==set(nonprogram)==set(contracts)=={'us','jp'},'Both complete regions required')
    outputs={};report={}
    for region in ('us','jp'):
        wanted=set(contracts[region]['members']);require(len(wanted)==26,'Exact26-member contract')
        require(set(program[region])==set(PROGRAM[region]),'Exact nine program members required')
        require(set(nonprogram[region])==wanted-set(PROGRAM[region]),'Exact17 nonprogram members required')
        all_members={**nonprogram[region],**program[region]}
        outputs[region]=archive.encode(all_members,contracts[region])
        report[region]={'members':{n:archive.identity(b)for n,b in sorted(all_members.items())},'archive':archive.identity(outputs[region])}
    return outputs,report


def finalize(program,nonprogram,contracts,out,archive_names):
    require(not out.exists()and out.parent.is_dir(),'Fresh final output with existing parent required')
    require(set(archive_names)=={'us','jp'}and len(set(archive_names.values()))==2,'Unique regional archive names')
    require(all(Path(n).name==n and n.endswith('.zip')and '\\'not in n for n in archive_names.values()),'Archive names must be local ZIP basenames')
    programs={r:members(program/r,PROGRAM[r])for r in ('us','jp')}
    others={r:members(nonprogram/r,set(contracts[r]['members'])-set(PROGRAM[r]))for r in ('us','jp')}
    outputs,regions=construct(programs,others,contracts)
    report={'schema':2,'exact_members':52,'exact_archives':2,'regions':regions,'publication_approved':False}
    stage=Path(tempfile.mkdtemp(prefix='.upper-delivery-',dir=out.parent))
    try:
        for region,blob in outputs.items():(stage/archive_names[region]).write_bytes(blob)
        (stage/'rebuild.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
        require(not out.exists(),'Output appeared during rebuild')
        os.rename(stage,out)
    finally:
        if stage.exists():shutil.rmtree(stage)
    return report


def self_test():
    # Independent full-size nine-member physical fixture and 17 tiny other files.
    import copy,io,zipfile
    program={};others={};contracts={}
    for region,names in PROGRAM.items():
        program[region]={n:b'\0'*(0x400000 if n=='upper.prg'else 0x80000)for n in names}
        others[region]={f'other{n:02}.bin':bytes([n])for n in range(17)};all_members={**program[region],**others[region]};stream=io.BytesIO()
        with zipfile.ZipFile(stream,'w')as z:
            for n,b in sorted(all_members.items()):
                info=zipfile.ZipInfo(n,(1980,1,1,0,0,0));info.create_system=3;info.external_attr=0o600<<16;z.writestr(info,b,compress_type=zipfile.ZIP_STORED)
        contracts[region]={'members':{n:archive.identity(b)for n,b in all_members.items()},'compression':0,'archive':archive.identity(stream.getvalue())}
    result,_=construct(program,others,contracts);require(len(result)==2,'Complete fixture archives')
    rejected=[]
    for label in ('changed-program','missing-nonprogram','wrong-container'):
        p=copy.deepcopy(program);o=copy.deepcopy(others);c=copy.deepcopy(contracts)
        if label=='changed-program':p['jp']['upper.prg']=b'\1'+p['jp']['upper.prg'][1:]
        elif label=='missing-nonprogram':o['us'].pop('other00.bin')
        else:c['jp']['archive']['sha256']='0'*64
        try:construct(p,o,c)
        except ValueError:rejected.append(label)
        else:raise ValueError('Invalid delivery accepted: '+label)
    return {'passed':True,'synthetic_members':52,'negative_controls':rejected,'media_read':False}


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--self-test',action='store_true')
    for n in ('program','nonprogram','contracts','out'):p.add_argument('--'+n,type=Path)
    a=p.parse_args()
    if a.self_test:print(json.dumps(self_test()));return
    require(all((a.program,a.nonprogram,a.contracts,a.out)),'All finalization paths required')
    r=finalize(a.program,a.nonprogram,json.loads(a.contracts.read_text()),a.out,{'us':'sfa3u.zip','jp':'sfz3j.zip'})
    print(json.dumps({'exact_archives':r['exact_archives'],'exact_members':r['exact_members']}))

if __name__=='__main__':main()
