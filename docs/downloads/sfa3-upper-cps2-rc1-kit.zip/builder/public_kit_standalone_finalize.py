"""Apply the pinned physical residual and seal both complete release-baseline archives.

Contains no game bytes. Residual admission is separate from resource provenance;
this finalizer certifies exact member/container identities only.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import tempfile
import public_kit_archive as archive
import public_kit_residual_patch as residual


def require(ok,message):
    if not ok:raise ValueError(message)


def sha(blob):return hashlib.sha256(blob).hexdigest()


def members(folder,names):
    require(folder.is_dir() and not folder.is_symlink(),'Real component member directory required')
    actual={p.name for p in folder.iterdir()}
    require(actual==set(names),'Exact component member inventory differs: '+str(folder))
    result={}
    for name in names:
        require(type(name)is str and Path(name).name==name and '\\'not in name and name not in ('.','..'),'Local physical member basename required')
        p=folder/name;require(p.is_file()and not p.is_symlink(),'Regular physical member required')
        result[name]=p.read_bytes()
    return result


def construct(program,nonprogram,contracts,plan,payloads):
    residual.validate_plan(plan)
    require(set(program)==set(nonprogram)==set(contracts)=={'us','jp'},'Both complete regions required')
    patched=residual.replay(plan,program,payloads);outputs={};report={}
    for region in ('us','jp'):
        wanted=set(contracts[region]['members']);require(len(wanted)==26,'Exact26-member contract')
        require(set(nonprogram[region])==wanted-set(residual.MEMBERS[region]),'Exact17 nonprogram members required')
        all_members={**nonprogram[region],**patched[region]}
        outputs[region]=archive.encode(all_members,contracts[region])
        report[region]={'members':{n:archive.identity(b)for n,b in sorted(all_members.items())},'archive':archive.identity(outputs[region]),'residual_changed_bytes':sum(r['changed_bytes']for r in plan['regions'][region].values())}
    return outputs,report


def finalize(program,nonprogram,contracts,plan_path,patches,out,expected_plan_sha256,archive_names):
    require(not out.exists()and out.parent.is_dir(),'Fresh final output with existing parent required')
    require(set(archive_names)=={'us','jp'}and len(set(archive_names.values()))==2,'Unique regional archive names')
    require(all(Path(n).name==n and n.endswith('.zip')and '\\'not in n for n in archive_names.values()),'Archive names must be local ZIP basenames')
    raw=plan_path.read_bytes();require(sha(raw)==expected_plan_sha256,'Pinned residual plan differs')
    plan=json.loads(raw);residual.validate_plan(plan)
    require(sha(Path(residual.__file__).read_bytes())==plan['context']['applicator_sha256'],'Pinned residual applicator differs')
    names={r['patch']['file']for rows in plan['regions'].values()for r in rows.values()}
    payloads=members(patches,names)
    programs={r:members(program/r,residual.MEMBERS[r])for r in ('us','jp')}
    others={r:members(nonprogram/r,set(contracts[r]['members'])-set(residual.MEMBERS[r]))for r in ('us','jp')}
    outputs,regions=construct(programs,others,contracts,plan,payloads)
    report={'schema':1,'exact_batch34_members':52,'exact_archives':2,'regions':regions,'residual_plan_sha256':sha(raw),'resource_provenance_extended':False,'publication_approved':False}
    stage=Path(tempfile.mkdtemp(prefix='.upper-delivery-',dir=out.parent))
    try:
        for region,blob in outputs.items():(stage/archive_names[region]).write_bytes(blob)
        (stage/'rebuild.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
        require(not out.exists(),'Output appeared during rebuild')
        os.rename(stage,out)
    finally:
        if stage.exists():shutil.rmtree(stage)
    return report


def self_test():
    # Independent full-size nine-member physical fixture and17 tiny other files.
    import copy,io,zipfile
    program={};target={};others={};contracts={};payloads={};regions={}
    for region,names in residual.MEMBERS.items():
        program[region]={n:b'\0'*(0x400000 if n=='upper.prg'else 0x80000)for n in names}
        target[region]=dict(program[region]);changed=bytearray(target[region][names[0]]);changed[3]=7;target[region][names[0]]=bytes(changed)
        regions[region]={}
        for n in names:
            patch,runs,count=residual.encode(program[region][n],target[region][n]);filename=sha(patch)+'.xor';payloads[filename]=patch
            regions[region][n]={'bytes':len(target[region][n]),'base_sha256':sha(program[region][n]),'target_sha256':sha(target[region][n]),'patch':{'file':filename,'bytes':len(patch),'sha256':sha(patch)},'runs':runs,'changed_bytes':count}
        others[region]={f'other{n:02}.bin':bytes([n])for n in range(17)};all_members={**target[region],**others[region]};stream=io.BytesIO()
        with zipfile.ZipFile(stream,'w')as z:
            for n,b in sorted(all_members.items()):
                info=zipfile.ZipInfo(n,(1980,1,1,0,0,0));info.create_system=3;info.external_attr=0o600<<16;z.writestr(info,b,compress_type=zipfile.ZIP_STORED)
        contracts[region]={'members':{n:archive.identity(b)for n,b in all_members.items()},'compression':0,'archive':archive.identity(stream.getvalue())}
    plan={'schema':1,'view':'physical-member','encoding':'xor-maximal-runs-be32-v1','diagnostic_only':True,'context':{n:'0'*64 for n in ('baseline_authority_sha256','foundation_qualification_sha256','physical_provider_qualification_sha256','applicator_sha256')},'regions':regions}
    result,_=construct(program,others,contracts,plan,payloads);require(len(result)==2,'Complete fixture archives')
    rejected=[]
    for label in ('changed-base','missing-nonprogram','changed-patch','wrong-container'):
        p=copy.deepcopy(program);o=copy.deepcopy(others);c=copy.deepcopy(contracts);d=dict(payloads)
        if label=='changed-base':p['jp']['upper.prg']=b'\1'+p['jp']['upper.prg'][1:]
        elif label=='missing-nonprogram':o['us'].pop('other00.bin')
        elif label=='changed-patch':n=next(k for k,v in d.items()if v);d[n]=d[n][:-1]+b'\2'
        else:c['jp']['archive']['sha256']='0'*64
        try:construct(p,o,c,plan,d)
        except ValueError:rejected.append(label)
        else:raise ValueError('Invalid delivery accepted: '+label)
    return {'passed':True,'synthetic_members':52,'negative_controls':rejected,'media_read':False}


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--self-test',action='store_true')
    for n in ('program','nonprogram','contracts','plan','patches','out'):p.add_argument('--'+n,type=Path)
    p.add_argument('--plan-sha256');a=p.parse_args()
    if a.self_test:print(json.dumps(self_test()));return
    require(all((a.program,a.nonprogram,a.contracts,a.plan,a.patches,a.out,a.plan_sha256)),'All finalization paths and plan digest required')
    r=finalize(a.program,a.nonprogram,json.loads(a.contracts.read_text()),a.plan,a.patches,a.out,a.plan_sha256,{'us':'sfa3u.zip','jp':'sfz3j.zip'})
    print(json.dumps({'exact_archives':r['exact_archives'],'exact_members':r['exact_batch34_members']}))

if __name__=='__main__':main()
