"""Seal complete reconstructed members into the exact approved ZIP container.

This serializer supplies no game content. Every input member and the resulting
container must match the public identity contract before a file is delivered.
"""
import argparse
import copy
import hashlib
import io
import json
from pathlib import Path
import zipfile


def require(ok,message):
    if not ok:raise ValueError(message)


def identity(blob):
    return {'bytes':len(blob),'sha256':hashlib.sha256(blob).hexdigest()}


def encode(members,contract):
    expected=contract['members'];compression=contract['compression']
    require(compression in (zipfile.ZIP_STORED,zipfile.ZIP_DEFLATED),'Unknown archive compression')
    require(len(expected)==26 and set(members)==set(expected),'Complete 26-member inventory required')
    for name,data in members.items():
        require(name and Path(name).name==name and '/' not in name and '\\' not in name,
                'Invalid archive member name')
        require(identity(data)==expected[name],'Reconstructed member identity differs: '+name)
    output=io.BytesIO()
    with zipfile.ZipFile(output,'w') as archive:
        for name in sorted(members):
            info=zipfile.ZipInfo(name,(1980,1,1,0,0,0))
            info.create_system=3;info.external_attr=0o600<<16
            archive.writestr(info,members[name],compress_type=compression,compresslevel=9)
    result=output.getvalue()
    require(identity(result)==contract['archive'],'Complete ZIP identity differs')
    return result


def self_test():
    members={f'part{n:02d}.bin':bytes([n])*13 for n in range(26)}
    # Independent ZIP fixture uses the original producer's declared layout.
    output=io.BytesIO()
    with zipfile.ZipFile(output,'w') as archive:
        for name,blob in sorted(members.items()):
            info=zipfile.ZipInfo(name,(1980,1,1,0,0,0));info.create_system=3
            info.external_attr=0o600<<16
            archive.writestr(info,blob,compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
    contract={'compression':zipfile.ZIP_DEFLATED,'members':{n:identity(b) for n,b in members.items()},'archive':identity(output.getvalue())}
    require(encode(dict(reversed(list(members.items()))),contract)==output.getvalue(),'Member ordering differs')
    rejected=[]
    for name in ('missing-member','extra-member','changed-member','changed-container'):
        changed=dict(members);pin=copy.deepcopy(contract)
        if name=='missing-member':changed.pop('part00.bin')
        elif name=='extra-member':changed['extra.bin']=b'unknown'
        elif name=='changed-member':changed['part00.bin']=b'changed'
        else:pin['archive']['sha256']='0'*64
        try:encode(changed,pin)
        except ValueError:rejected.append(name)
        else:raise ValueError('Accepted invalid reconstruction: '+name)
    return {'rejected':rejected,'deterministic_member_order':True}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--self-test',action='store_true')
    for name in ('members','contract','out'):parser.add_argument('--'+name,type=Path)
    args=parser.parse_args()
    if args.self_test:print(json.dumps(self_test()));return
    require(args.members and args.contract and args.out,'Members, identity contract and output required')
    contract=json.loads(args.contract.read_text())
    require({p.name for p in args.members.iterdir()}==set(contract['members']),'Input directory inventory differs')
    result=encode({name:(args.members/name).read_bytes() for name in contract['members']},contract)
    require(not args.out.exists(),'Archive destination already exists')
    with args.out.open('xb') as stream:stream.write(result)
    print(json.dumps({'archive':identity(result),'members':len(contract['members'])}))


if __name__=='__main__':main()
