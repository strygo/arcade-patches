"""Replay a hash-pinned diagnostic residual patch in physical ROM member order.

This proves binary replay only. It makes no source-ownership or public-payload
admission claim and does not contain a development build chain or ROM data.
Publication assumes a single writer to the selected fresh output path.
"""
import hashlib
import struct

MEMBERS={
    'us':('sz3u.03c','sz3u.04c','sz3.05c','sz3.06c','sz3.07c','sz3.08c','sz3.09c','sz3.10b','upper.prg'),
    'jp':('sz3j.03c','sz3j.04c','sz3.05c','sz3.06c','sz3.07c','sz3.08c','sz3.09c','sz3.10b','upper.prg')}


def require(ok,message):
    if not ok:raise ValueError(message)


def digest(blob):return hashlib.sha256(blob).hexdigest()


def hash_value(value):
    return type(value)is str and len(value)==64 and all(c in '0123456789abcdef'for c in value)


def encode(base,target):
    require(type(base)is bytes and type(target)is bytes and len(base)==len(target),'Equal immutable complete members required')
    result=bytearray();runs=0;changed=0;at=0
    while at<len(base):
        if base[at]==target[at]:at+=1;continue
        start=at;values=bytearray()
        while at<len(base)and base[at]!=target[at]:
            values.append(base[at]^target[at]);at+=1
        result.extend(struct.pack('>II',start,len(values)));result.extend(values)
        runs+=1;changed+=len(values)
    return bytes(result),runs,changed


def validate_spec(spec):
    require(set(spec)=={'bytes','base_sha256','target_sha256','patch','runs','changed_bytes'},'Member recipe schema')
    require(type(spec['bytes'])is int and spec['bytes']>0,'Complete member extent')
    require(all(hash_value(spec[n])for n in ('base_sha256','target_sha256')),'Complete member hash syntax')
    pin=spec['patch'];require(set(pin)=={'file','bytes','sha256'}and hash_value(pin['sha256']),'Patch identity schema')
    require(pin['file']==pin['sha256']+'.xor','Content-addressed patch basename')
    require(type(spec['runs'])is int and type(spec['changed_bytes'])is int and 0<=spec['runs']<=spec['changed_bytes']<=spec['bytes'],'Declared patch counts')
    require(type(pin['bytes'])is int and pin['bytes']==8*spec['runs']+spec['changed_bytes'],'Exact encoded patch extent')


def apply_member(base,patch,spec):
    validate_spec(spec)
    require(type(base)is bytes and len(base)==spec['bytes'],'Complete base extent')
    require(digest(base)==spec['base_sha256'],'Complete base identity differs')
    pin=spec['patch']
    require(type(patch)is bytes and len(patch)==pin['bytes']and digest(patch)==pin['sha256'],'Patch payload identity differs')
    result=bytearray(base);cursor=0;previous=-1;runs=0;changed=0
    while cursor<len(patch):
        require(cursor+8<=len(patch),'Truncated run header')
        at,size=struct.unpack_from('>II',patch,cursor);cursor+=8
        require(size>0 and previous<at and at+size<=len(base),'Canonical nonadjacent disjoint run extent')
        require(cursor+size<=len(patch),'Truncated run payload')
        values=patch[cursor:cursor+size];require(all(values),'Zero XOR byte in maximal run')
        for i,value in enumerate(values):result[at+i]^=value
        cursor+=size;previous=at+size;runs+=1;changed+=size
    require((runs,changed)==(spec['runs'],spec['changed_bytes']),'Patch count or trailing payload differs')
    result=bytes(result);require(digest(result)==spec['target_sha256'],'Complete final member identity differs')
    return result


def validate_plan(plan):
    require(set(plan)=={'schema','view','encoding','diagnostic_only','context','regions'},'Patch envelope schema')
    require(type(plan['schema'])is int and plan['schema']==1 and plan['view']=='physical-member'and plan['encoding']=='xor-maximal-runs-be32-v1'and plan['diagnostic_only']is True,'Patch envelope contract')
    require(set(plan['context'])=={'baseline_authority_sha256','foundation_qualification_sha256','physical_provider_qualification_sha256','applicator_sha256'}and all(hash_value(v)for v in plan['context'].values()),'Pinned patch context')
    require(set(plan['regions'])==set(MEMBERS),'Complete display inventory')
    for region,names in MEMBERS.items():
        require(set(plan['regions'][region])==set(names),'Complete nine-member inventory: '+region)
        for name,row in plan['regions'][region].items():
            validate_spec(row)
            require(row['bytes']==(0x400000 if name=='upper.prg'else 0x80000),'Physical member layout')


def replay(plan,bases,payloads):
    validate_plan(plan)
    require(set(bases)==set(MEMBERS),'Base display inventory')
    wanted={row['patch']['file']for rows in plan['regions'].values()for row in rows.values()}
    require(set(payloads)==wanted,'Exact patch payload inventory')
    result={}
    for region,names in MEMBERS.items():
        require(set(bases[region])==set(names),'Exact base member inventory')
        result[region]={name:apply_member(bases[region][name],payloads[plan['regions'][region][name]['patch']['file']],plan['regions'][region][name])for name in names}
    return result


def main():
    import argparse
    import json
    import os
    from pathlib import Path
    import shutil
    import tempfile
    p=argparse.ArgumentParser(description=__doc__)
    for name in ('plan','base','patches','out'):p.add_argument('--'+name,type=Path,required=True)
    p.add_argument('--expected-plan-sha256',required=True)
    a=p.parse_args();raw=a.plan.read_bytes()
    require(hash_value(a.expected_plan_sha256)and digest(raw)==a.expected_plan_sha256,'Externally pinned patch plan identity differs')
    plan=json.loads(raw);validate_plan(plan)
    require(digest(Path(__file__).read_bytes())==plan['context']['applicator_sha256'],'Pinned applicator differs')
    require(not a.out.exists()and a.out.parent.is_dir(),'Fresh output with existing parent required')
    require({q.name for q in a.base.iterdir()}==set(MEMBERS),'Exact base display directory inventory')
    bases={}
    for region,names in MEMBERS.items():
        require({q.name for q in (a.base/region).iterdir()}==set(names),'Exact base member directory inventory')
        bases[region]={n:(a.base/region/n).read_bytes()for n in names}
    wanted={row['patch']['file']:row['patch']['bytes']for rows in plan['regions'].values()for row in rows.values()}
    require({q.name for q in a.patches.iterdir()}==set(wanted),'Exact patch directory inventory')
    require(all((a.patches/name).is_file()and(a.patches/name).stat().st_size==size for name,size in wanted.items()),'Bounded patch file extents')
    payloads={name:(a.patches/name).read_bytes()for name in wanted}
    result=replay(plan,bases,payloads)
    # The target is never opened by this applicator. Nothing becomes visible
    # until all complete identities pass and the private staging tree is ready.
    stage=Path(tempfile.mkdtemp(prefix='.residual-',dir=a.out.parent))
    try:
        for region,members in result.items():
            (stage/region).mkdir()
            for name,blob in members.items():(stage/region/name).write_bytes(blob)
        require(not a.out.exists(),'Fresh single-writer output path changed')
        os.rename(stage,a.out)
    finally:
        if stage.exists():shutil.rmtree(stage)
    print(json.dumps({'diagnostic_only':True,'complete_member_hashes_passed':18,'source_ownership_granted':False}))


if __name__=='__main__':main()
