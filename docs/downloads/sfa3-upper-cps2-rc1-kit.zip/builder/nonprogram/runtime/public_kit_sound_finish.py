"""Assemble the three native sound members from original media and typed resources."""
import argparse
import json
from pathlib import Path

import public_kit_voices as voices
import public_kit_sound_stock as stock
import public_kit_recipe as codec
from public_kit_media import require


def image(writes):
    data=bytearray(0x80000);mask=bytearray(len(data))
    for at,blob in writes:
        require(0<=at<=len(data)-len(blob),'Sound resource exceeds image')
        for i,value in enumerate(blob):
            require(not mask[at+i] or data[at+i]==value,'Conflicting sound resources')
            data[at+i]=value;mask[at+i]=1
    return bytes(data)


def construct(canonical,scores,read,catalog,voice_recipe,stock_recipe,recipe):
    sources={'canonical':canonical,'scores':scores,
        'voices':image(voices.construct(canonical,read,voice_recipe,catalog)),
        'stock':image(stock.construct(canonical,stock_recipe))}
    flat=codec.apply(recipe,sources)
    require(len(flat)==0x80000,'Expanded sound image extent')
    return {'sz3.01':flat[:0x20000],'sz3.02':flat[0x20000:0x40000],'upper.z80':flat[0x40000:]}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    for n in ('canonical','scores','root','catalog','voice-recipe','stock-recipe','recipe','out'):
        parser.add_argument('--'+n,type=Path,required=True)
    args=parser.parse_args()
    read_json=lambda p:json.loads(p.read_text())
    result=construct(args.canonical.read_bytes(),args.scores.read_bytes(),lambda n:(args.root/n).read_bytes(),
        read_json(args.catalog),read_json(args.voice_recipe),read_json(args.stock_recipe),read_json(args.recipe))
    args.out.mkdir()
    for name,blob in result.items():(args.out/name).write_bytes(blob)


if __name__=='__main__':main()
