"""Construct a native sound byte pool with an explicit ownership mask."""
import argparse
import json
from pathlib import Path
import struct
from score_support import digest,require


def construct(root,recipe,out):
    import public_kit_scores as guile
    import public_kit_cohort_layout as cohort
    canonical = (root/'canonical.bin').read_bytes()
    require(digest(canonical) == recipe['canonical_sha256'], 'Original sound input differs')
    data = bytearray(0x80000); mask = bytearray(len(data)); families = {}
    def put(at,blob):
        require(0 <= at <= len(data)-len(blob), 'Sound allocation exceeds native memory')
        for i,value in enumerate(blob):
            require(not mask[at+i] or data[at+i] == value, 'Conflicting sound owners')
            data[at+i] = value; mask[at+i] = 1
    for song,pins in recipe['resources'].items():
        outputs = {name:(root/song/name).read_bytes() for name in pins}
        guile.verify_outputs(outputs,pins)
        if song == 'Guile':
            channels = [outputs[f'channel_{n:02d}.bin'] for n in range(16)]
            level = recipe['guile_placement']
            writes,_,report = guile.placement(channels,canonical,level['gain_db'],level['volume_sites'])
            writes += [(0x3d10,outputs['source/instruments.bin'],'instruments'),
                (0x527c,outputs['source/instruments.bin'],'retained_original_instrument_allocation'),
                (0x6000+883*8,outputs['source/descriptors.bin'],'descriptors'),
                (0x8000+133*8,outputs['source/articulations.bin'],'articulations'),
                (0x8c06+0x2e*4,(0x40000).to_bytes(3,'big'),'command'),
                (0x3c05+23*2,struct.pack('<H',0x3d10),'instrument_bank')]
        else:
            writes,report = cohort.placement(outputs,canonical,recipe['placements'][song])
        before = sum(mask)
        for at,blob,_ in writes:put(at,blob)
        families[song] = {'distinct_new_bytes':sum(mask)-before,'generated_write_bytes':sum(len(b) for _,b,_ in writes)}
    out.mkdir()
    (out/'sound.bin').write_bytes(data); (out/'sound.mask').write_bytes(mask)
    report = {'schema':1,'verified_converter_bytes':sum(mask),'families':families,
        'outputs':{name:{'bytes':len(value),'sha256':digest(value)} for name,value in (('sound.bin',data),('sound.mask',mask))},
        'unknown_bytes_are_masked':True,'whole_sound_members_complete':False}
    (out/'pool.json').write_text(json.dumps(report,indent=2)+'\n')
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('inputs','recipe','out'):parser.add_argument('--'+name,type=Path,required=True)
    args = parser.parse_args();construct(args.inputs,json.loads(args.recipe.read_text()),args.out)


if __name__ == '__main__':main()
