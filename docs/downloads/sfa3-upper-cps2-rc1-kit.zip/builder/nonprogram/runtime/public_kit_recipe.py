"""Bounded copy/fill reconstruction for Upper's public source pools.

There is deliberately no implicit literal fallback. A converted resource must
have a reproducible pool; an unresolved range prevents export. Authored patch
code will need its own explicit provenance contract before adding literal ops.
This module is standalone and contains no game bytes or checkout dependencies.
"""
from __future__ import annotations

import hashlib

MAX_MEMBER = 64 * 1024 * 1024


def digest(data):
    return hashlib.sha256(data).hexdigest()


def require(ok, message):
    if not ok:
        raise ValueError(message)


def integer(value, lower, upper):
    return type(value) is int and lower <= value <= upper


def apply(recipe, pools):
    require(set(recipe) == {'bytes', 'sha256', 'sources', 'ops'}, 'Unknown recipe fields')
    size = recipe['bytes']
    require(integer(size, 1, MAX_MEMBER), 'Invalid member extent')
    require(isinstance(recipe['sources'], dict) and isinstance(recipe['ops'], list),
            'Invalid recipe tables')
    require(0 < len(recipe['ops']) <= size, 'Invalid operation count')
    require(set(pools) == set(recipe['sources']), 'Source pool inventory differs')
    for name, pin in recipe['sources'].items():
        require(isinstance(name, str) and isinstance(pin, dict) and
                set(pin) == {'bytes', 'sha256'}, 'Invalid source identity')
        data = pools[name]
        require(isinstance(data, bytes) and len(data) == pin['bytes'] and
                digest(data) == pin['sha256'], 'Source identity differs: '+name)
    output = bytearray()
    used = set()
    for op in recipe['ops']:
        require(isinstance(op, list) and op, 'Invalid operation')
        if op[0] == 'copy':
            require(len(op) == 4 and isinstance(op[1], str) and op[1] in pools,
                    'Unknown copy source')
            _, name, offset, length = op
            source = pools[name]
            require(integer(offset, 0, len(source)) and
                    integer(length, 1, min(size-len(output), len(source)-offset)),
                    'Copy exceeds source or output extent')
            output.extend(source[offset:offset+length])
            used.add(name)
        elif op[0] == 'fill':
            require(len(op) == 3 and op[1] in (0, 255) and type(op[1]) is int and
                    integer(op[2], 1, size-len(output)), 'Invalid padding operation')
            output.extend(bytes([op[1]]) * op[2])
        else:
            raise ValueError('Unresolved or unsupported operation: '+str(op[0]))
    require(used == set(pools), 'Unused declared source')
    result = bytes(output)
    require(len(result) == size and digest(result) == recipe['sha256'],
            'Reconstructed member differs')
    return result


def exact_copy(target, pools):
    """Return a whole-member recipe, or None. Never infer patch ownership."""
    for name, data in sorted(pools.items()):
        if data == target:
            return {'bytes': len(target), 'sha256': digest(target),
                    'sources': {name: {'bytes': len(data), 'sha256': digest(data)}},
                    'ops': [['copy', name, 0, len(data)]]}
    return None


def verify_complete(recipes, pools, expected):
    """Reject incomplete inventories before reconstructing any member."""
    require(set(recipes) == set(expected), 'Incomplete member recipe inventory')
    result = {}
    for name in sorted(expected):
        recipe = recipes[name]
        require(recipe.get('sha256') == expected[name], 'Wrong target identity')
        names = recipe.get('sources', {})
        require(set(names) <= set(pools), 'Missing source pool')
        result[name] = apply(recipe, {key: pools[key] for key in names})
    return result


def self_test():
    import copy
    source = bytes(range(32))
    target = source[3:15] + bytes(8) + bytes([255])*4
    pool = {'source': source}
    recipe = {'bytes': len(target), 'sha256': digest(target),
              'sources': {'source': {'bytes': len(source), 'sha256': digest(source)}},
              'ops': [['copy', 'source', 3, 12], ['fill', 0, 8], ['fill', 255, 4]]}
    require(apply(recipe, pool) == target, 'Positive reconstruction failed')
    require(exact_copy(target, pool) is None, 'Unmatched target gained a recipe')
    require(apply(exact_copy(source, pool), pool) == source, 'Whole-source copy failed')
    mutations = (
        lambda r: r['ops'][0].__setitem__(2, -1),
        lambda r: r['ops'][0].__setitem__(3, 100),
        lambda r: r['ops'][0].__setitem__(2, True),
        lambda r: r['ops'][0].__setitem__(1, 'absent'),
        lambda r: r['ops'][0].__setitem__(0, 'literal'),
        lambda r: r['ops'][1].__setitem__(1, 17),
        lambda r: r['ops'][1].__setitem__(2, 100),
        lambda r: r['sources']['source'].__setitem__('sha256', 'wrong'),
        lambda r: r.__setitem__('sha256', 'wrong'),
        lambda r: r.__setitem__('bytes', 0),
        lambda r: r.__setitem__('bytes', MAX_MEMBER+1),
        lambda r: r.__setitem__('literal_fallback', True),
        lambda r: r['ops'].pop(),
    )
    for mutate in mutations:
        bad = copy.deepcopy(recipe)
        mutate(bad)
        try:
            apply(bad, pool)
        except ValueError:
            pass
        else:
            raise AssertionError('Corrupt recipe was accepted')
    expected = {'member': digest(target)}
    require(verify_complete({'member': recipe}, pool, expected) == {'member': target},
            'Complete reconstruction failed')
    for recipes in ({}, {'member': recipe, 'extra': recipe}):
        try:
            verify_complete(recipes, pool, expected)
        except ValueError:
            pass
        else:
            raise AssertionError('Incomplete/extra inventory was accepted')
    print('Public copy/fill codec: positive reconstruction and 15 negative controls PASS')


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--self-test', action='store_true', required=True)
    parser.parse_args()
    self_test()
