"""Rebuild the frozen Guile score from explicit original-media buffers."""
import argparse
import json
from pathlib import Path
import re
import struct

from score_support import require, digest


def verify_outputs(outputs, pins):
    require(set(outputs) == set(pins), 'Score resource inventory differs')
    for name, data in outputs.items():
        require({'bytes':len(data), 'sha256':digest(data)} == pins[name], 'Score resource differs: '+name)


def read_inputs(inputs, pins):
    names = {'sz3.01','sz3.02','dl-1425.bin','BGM30.MPB','BGM30.MSB','MANATEE.DRV','aica.cpp'}
    require(set(pins) == names, 'Original score input inventory differs')
    blobs = {}
    for name, pin in pins.items():
        require(not (inputs/name).is_symlink(), 'Aliased score input: '+name)
        data = (inputs/name).read_bytes()
        require(len(data) == pin['bytes'] and digest(data) == pin['sha256'], 'Score input differs: '+name)
        blobs[name] = data
    return blobs


def placement(channels, canonical, gain_db, expected_sites):
    import upper_music_loop_layout as layout
    require(digest(canonical) == '50df03344cf604262fd98f8157b4bb96de5806ef0be5d3cf9f9140b30b5c5b35',
            'Canonical gain table source differs')
    require(type(gain_db) in (int,float) and 0 < gain_db < 12, 'Invalid qualified song gain')
    writes, resources, _, _, _, report = layout.layout(channels)
    lut = struct.unpack_from('<128H',canonical,0x2e92)
    gain = 10**(gain_db/20); sites = changed = 0; result = []
    for at,data,name in writes:
        if name == 'music_instruction_group' and data[0] == 7:
            require(len(data) == 2 and data[1] < 128, 'Native volume instruction differs')
            sites += 1; old = data[1]
            new = min(range(128),key=lambda k:(abs(lut[k]-lut[old]*gain),k)) if old else 0
            changed += new != old; data = bytes([7,new])
        result.append((at,data,name))
    require(sites == expected_sites, 'Qualified volume site count differs')
    return result, resources, {'logical_sha256':report['logical_score_sha256'],
        'populated_write_bytes':report['populated_write_bytes'],'score_start':report['score_start'],
        'score_end':report['score_end'],'volume_sites':sites,'changed_volume_operands':changed,
        'gain_db':gain_db,'native_graph_verified':True}


def construct(inputs, recipe, out):
    import numpy, scipy
    require((numpy.__version__,scipy.__version__) == ('2.2.6','1.15.3'), 'Pinned score numeric dependencies required')
    require(not out.exists(), 'Fresh score output required')
    import upper_music_sources as music
    import upper_music_performance as performance
    import upper_music_samples as samples
    import upper_music_articulations as articulation
    import audit_upper_loop_source as source
    import compile_upper_packed_prefix as prefix
    import upper_music_duration_packing as packed
    import upper_music_loop_layout as layout
    import upper_music_loop_model as loop
    blobs = read_inputs(inputs, recipe['inputs'])
    flat = blobs['sz3.01']+blobs['sz3.02']
    require(digest(flat) == recipe['flat_sha256'], 'Canonical sound payload differs')
    body = blobs['MANATEE.DRV'][32:]
    tables = {}
    for name in ('AR', 'DR'):
        match = re.search(r'constexpr double '+name+r'Times\[64\]\s*=\s*\{([^}]+)\}', blobs['aica.cpp'].decode())
        require(match is not None, 'Missing AICA scalar table')
        tables[name] = [float(f.strip()) for f in re.sub(r'/\*.*?\*/', '', match[1]).split(',') if f.strip()]
        require(len(tables[name]) == 64, 'AICA table extent differs')
    fit = recipe['fit_receipt']
    arts_blob = b''.join(bytes(p['articulation']) for p in sorted(fit['fit']['profiles'], key=lambda p:p['profile_id']))
    seq = music.sequence_bank(blobs['BGM30.MSB'])['sequences'][0]
    score = blobs['BGM30.MSB'][seq['offset']:seq['offset']+seq['bytes']]
    qualified = performance.perform(score, loop_passes=3)
    require(qualified['summary'] == fit['performed_summary'] and digest(score) == fit['source_score_sha256'], 'Original score differs')
    pcm, sample_report = samples.build(body, blobs['BGM30.MPB'], qualified, flat)
    require(digest(pcm) == fit['source_pcm8_conversion_sha256'], 'Source PCM conversion differs')
    performed = performance.perform(score, loop_passes=4)
    require(performed['notes'][:len(qualified['notes'])] == qualified['notes'], 'Source note projection differs')
    print('Original score and samples verified', flush=True)
    rows, profiles, observations = articulation.source_schedule(body, blobs['BGM30.MPB'], performed,
        tables, flat, sample_report, blobs['dl-1425.bin'])
    resources, _, _ = source.bind_four_pass_resources(flat, pcm, sample_report, profiles, rows,
        len(qualified['notes']), fit, arts_blob)
    events, _, _ = prefix.source_events([dict(r) for r in rows], profiles, observations, max(r['end_tick'] for r in rows)+1)
    parts, result = source.analyze(performed, rows, observations)
    boundary = result['boundaries'][1]['native_tick']
    require(boundary == 5651 and result['steady_native_template_interval_check']['measured_intervals_fit_without_extra_tail_cut'], 'Source ownership differs')
    arts = resources['articulation_map']; outputs = {}
    for name in ('sample_banks', 'instruments', 'descriptors', 'articulations'):
        outputs['source/'+name+'.bin'] = resources[name]
    def section(own, end):
        data, report = packed.compile_channel(flat, own, end_tick=end, instrument_bank=23, articulations=arts)
        require(data[-3:] == bytes([7,0,23]), 'Compiler terminal differs')
        return data[:-3], report
    rotated = source.rotated_steady_events(parts[1]); models = []
    for row in rotated:
        slot = row['slot']; cut = boundary+row['cut_relative_to_source_global_boundary_tick']
        require(not row['unmodified_events_outside_body'] and not row['measured_tails_crossing_next_genuine_onset'], 'Unqualified seam repair')
        first, fr = section([e for e in events[slot] if e['tick'] < cut], cut)
        steady, sr = section(row['events'], 4776)
        closed = layout.join(first, bytes([4,0,11,0,12,0])+steady)
        model = loop.decode(flat, closed, iterations=3, end_tick=cut+3*4776, articulations=arts)
        require(loop.closure(model, cut, 4776)['entry_is_genuine_onset'], 'Synthetic loop onset')
        expected = [r['tick'] for r in fr['timeline'] if r.get('retrigger')]
        expected += [cut+n*4776+r['tick'] for n in range(3) for r in sr['timeline'] if r.get('retrigger')]
        require([r['tick'] for r in model['events'] if r['kind']=='note' and r['reset']] == expected, 'Decoded onset mismatch')
        gates = fr['gate_expiry_ticks']+[cut+n*4776+r for n in range(3) for r in sr['gate_expiry_ticks']]
        require([r['tick'] for r in model['events'] if r['kind']=='gate_expiry'] == gates, 'Decoded gate mismatch')
        outputs[f'channel_{slot:02d}.bin'] = closed
        models.append(model)
        print('Closed channel', slot, len(closed), flush=True)
    verify_outputs(outputs, recipe['outputs'])
    logical = bytes(33)+b''.join(outputs[f'channel_{n:02d}.bin'] for n in range(16))
    require(len(logical) == 75859 and digest(logical) == recipe['logical_sha256'], 'Logical score differs')
    baseline_sha256 = digest(logical)
    if 'quality' in recipe:
        import numpy as np
        import compile_guile_music_quality as quality
        import upper_music_native as native
        context = dict(rows=rows, parts=parts, rotated=rotated, observations=observations)
        selected = {p['profile_id'] for p in fit['fit']['profiles'] if not p['limits_met']}
        require(len(selected) == 5, 'Frozen quality profile count differs')
        words = np.array([native.u16(flat,0x2e92+2*i) for i in range(128)],dtype=float)
        for slot in range(16):
            cut = boundary+rotated[slot]['cut_relative_to_source_global_boundary_tick']; sections = []
            for steady, end in ((False,cut),(True,4776)):
                own = rotated[slot]['events'] if steady else [e for e in events[slot] if e['tick'] < cut]
                voices = quality.spans(context,slot,end,steady)
                base,_ = packed.compile_channel(flat,own,end_tick=end,instrument_bank=23,articulations=arts)
                base_model = packed.decode_channel(flat,base,end_tick=end,articulations=arts)
                data,_,_,_ = quality.residual_section(flat,own,voices,selected,words,base_model,end,arts,packed,True)
                require(data[-3:] == bytes([7,0,23]), 'Quality compiler terminal differs')
                sections.append(data[:-3])
            closed = layout.join(sections[0],bytes([4,0,11,0,12,0])+sections[1])
            model = loop.decode(flat,closed,iterations=2,end_tick=cut+2*4776,articulations=arts)
            fields = ('pitch_fixed','instrument','pan','reset'); original = models[slot]
            require([[s[k] for k in fields] for s in model['states']] ==
                    [[s[k] for k in fields] for s in original['states'][:len(model['states'])]], 'Quality chronology differs')
            require([e['tick'] for e in model['events'] if e['kind']=='gate_expiry'] ==
                    [e['tick'] for e in original['events'] if e['kind']=='gate_expiry' and e['tick'] < cut+2*4776], 'Quality gates differ')
            outputs[f'channel_{slot:02d}.bin'] = closed
            print('Quality channel', slot, len(closed), flush=True)
        verify_outputs(outputs, recipe['quality']['outputs'])
        logical = bytes(33)+b''.join(outputs[f'channel_{n:02d}.bin'] for n in range(16))
        require(digest(logical) == recipe['quality']['logical_sha256'], 'Final quality logical score differs')
    out.mkdir()
    for name, data in outputs.items():
        path = out/name; path.parent.mkdir(exist_ok=True); path.write_bytes(data)
    report = {'passed': True, 'resources': recipe.get('quality',recipe)['outputs'], 'logical_bytes':len(logical),
              'logical_sha256':digest(logical), 'baseline_logical_sha256':baseline_sha256,
              'frozen_gain_adjustments_replayed':'quality' in recipe, 'articulation_optimizer_invoked':False, 'hardware_reviewed':False}
    (out/'reconstruction.json').write_text(json.dumps(report, indent=2)+'\n')
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('inputs', 'recipe', 'out'):
        parser.add_argument('--'+name, type=Path, required=True)
    args = parser.parse_args()
    construct(args.inputs, json.loads(args.recipe.read_text()), args.out)


if __name__ == '__main__':
    main()
