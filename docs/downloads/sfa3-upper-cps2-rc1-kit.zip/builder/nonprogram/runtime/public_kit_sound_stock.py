"""Rebind original effect headers to identical complete bodies and relocate records."""
import struct
from public_kit_media import require,digest
from public_kit_voices import pointer


def construct(canonical,recipe):
    require(digest(canonical)==recipe['canonical_sha256'],'Original sound identity differs')
    writes=[]
    count=int.from_bytes(canonical[0x8c00:0x8c02],'big')
    require(count==3072,'Original command catalog extent')
    heads=sorted({pointer(canonical,n) for n in range(count) if pointer(canonical,n)})
    require(canonical[0x3ff3f:]==bytes(193),'Original empty program tail differs')
    ends=dict(zip(heads,heads[1:]+[0x3ff3f]))
    for at,replacement in recipe['aliases']:
        require(at in ends and replacement in ends,'Unknown original effect header')
        body=canonical[at+33:ends[at]]
        require(body and body==canonical[replacement+33:ends[replacement]],'Complete effect bodies differ')
        header=bytearray(canonical[at:at+33]);require(header[0]!=0,'Music header cannot be shared')
        for channel in range(16):
            offset=int.from_bytes(header[1+channel*2:3+channel*2],'big')
            if offset:
                value=replacement+offset-at
                require(0<value<=65535,'Shared effect seed outside forward range')
                struct.pack_into('>H',header,1+channel*2,value)
        writes.append((at,bytes(header)))
    for row in recipe['relocations']:
        at,destination,size=row['from'],row['to'],row['bytes']
        require(at in ends and ends[at]-at==size,'Complete original effect extent differs')
        blob=canonical[at:at+size]
        require(digest(blob)==row['complete_header_body_sha256'],'Original effect body identity differs')
        writes.append((destination,blob))
        for command in row['commands']:
            require(pointer(canonical,command)==at,'Original catalog relocation binding differs')
            writes.append((0x8c06+command*4,destination.to_bytes(3,'big')))
    return writes


def plan(canonical,target,relocations):
    count=int.from_bytes(canonical[0x8c00:0x8c02],'big')
    require(count==3072,'Original command catalog extent')
    heads=sorted({pointer(canonical,n) for n in range(count) if pointer(canonical,n)})
    aliases=[];moved={r['from'] for r in relocations}
    for at in heads:
        if canonical[at:at+33]==target[at:at+33] or at in moved:continue
        old=[int.from_bytes(canonical[at+1+i*2:at+3+i*2],'big') for i in range(16)]
        new=[int.from_bytes(target[at+1+i*2:at+3+i*2],'big') for i in range(16)]
        shifts={b-a for a,b in zip(old,new) if a}
        require(len(shifts)==1 and all(bool(a)==bool(b) for a,b in zip(old,new)),'Unknown header transformation')
        aliases.append([at,at+next(iter(shifts))])
    recipe={'canonical_sha256':digest(canonical),'aliases':aliases,'relocations':relocations}
    for at,blob in construct(canonical,recipe):require(target[at:at+len(blob)]==blob,'Original effect reconstruction differs')
    return recipe
