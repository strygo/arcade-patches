"""Original MOMO events and native one-shot voice resource reconstruction.

The MOMO parser is retained from upper_playtest_fixes20 at 684dbc06b6055d23bb6df3fd3dbb91a3f690abaf.
Allocation recipes contain addresses and source selectors, never voice bytes.
"""
import math
import struct
from public_kit_media import require, digest

def momo(blob):
    """Events (sequences) and cue rows of a MOMO bank, with the frozen HSFA grammar."""
    require(blob[:8] == b'MOMO\x04\0\0\0', 'Voice container')
    spans = [struct.unpack_from('<II', blob, 8+8*i) for i in range(4)]
    require(all(a+n <= len(blob) for a, n in spans), 'Voice block bounds')
    h = blob[spans[0][0]:sum(spans[0])]; m = blob[spans[2][0]:sum(spans[2])]; c = blob[spans[3][0]:sum(spans[3])]
    require(m[:8] == b'RDSTqesT' and len(c) == 48*16, 'Sequence/cue shape')
    base = h.index(b'IECSgorP'); programs = []
    for i in range(struct.unpack_from('<I', h, base+12)[0]+1):
        at = base+struct.unpack_from('<I', h, base+16+4*i)[0]; size = struct.unpack_from('<I', h, at)[0]
        require(size == 36, 'Voice program header')
        rows = {}
        for j in range(h[at+4]):
            r = h[at+size+20*j:at+size+20*(j+1)]
            require(len(r) == 20 and r[2] == r[3] == r[4], 'Voice transposition/range not qualified')
            rows[r[2]] = struct.unpack_from('<H', r)[0]
        programs.append(rows)
    base = h.index(b'IECStesS')
    sounds = [struct.unpack_from('<H', h, base+struct.unpack_from('<I', h, base+16+4*i)[0]+4)[0]
              for i in range(struct.unpack_from('<I', h, base+12)[0]+1)]
    count = ((struct.unpack_from('<I', m, 16)[0] & 65535)-16)//4
    require(0 < count <= 64, 'Event table bounds')
    events = {}
    for event in range(count):
        at = struct.unpack_from('<I', m, 16+event*4)[0] & 65535; seq = m[at:at+20]
        if seq[:5] != bytes.fromhex('e07fe140e2'): continue
        require(0x80 <= seq[6] < 0xe0, 'Voice note sequence')
        note = (seq[6] & 127)+12; program = seq[5]
        require(program < len(programs) and note in programs[program], 'Voice note outside source program')
        events[event] = sounds[programs[program][note]]
    rows = {n: c[16*n+9] for n in range(48) if c[16*n] == 1 and c[16*n+8] == 0}
    return events, rows


def timing(row):
    rate = 1624 if math.ceil(row['decoded_samples']*12019/row['sample_rate'])+2 >= 32768 else 2048
    frames = math.ceil(row['decoded_samples']/row['sample_rate']*58.637)+3
    return rate, max(1,min(255,3600//frames)), 0xb5 if rate == 1624 else 0xb9


def pointer(data,command):
    return int.from_bytes(data[0x8c06+command*4:0x8c09+command*4],'big')


def sequence(data,at):
    b = data[at+33:at+47]
    require(len(b)==14 and data[at]==16 and b[0]==5 and b[2:7]==bytes([6,255,7,125,31])
        and b[8]==8 and b[10:12]==bytes([9,3]) and b[12] in (0xb5,0xb9) and b[13]==23,
        'Native one-shot grammar differs')
    return {'tempo':b[1],'bank':b[7],'tone':b[9],'note':b[12]}


def construct(canonical,read,recipe,catalog):
    require(digest(canonical)==recipe['canonical_sha256'],'Original sound program identity')
    writes=[]; sources={}; events={}; records={}
    for name,pin in recipe['sources'].items():
        blob=read(name);require(len(blob)==pin['bytes'] and digest(blob)==pin['sha256'],'Original voice pool identity')
        sources[name]=blob
        if 'voicebank' in name:events[int(name.split('voicebank')[1].split('.')[0])]=momo(blob)[0]
    for row in recipe['samples']:
        source=sources[row['source']];metadata=catalog['voices'][row['source']]
        require(metadata['bank_sha256']==digest(sources[row['bank_source']]),'Voice metadata source binding')
        rate,tempo,note=timing(metadata)
        require(row['source'].endswith('-r'+str(rate)+'.bin'),'Voice playback rate differs')
        address=row['address'];start=address&65535;size=len(source)
        require(0<size+2<32768 and start+size+2<65536,'Voice allocation boundary')
        writes.append((0x6000+row['descriptor']*8,struct.pack('<BHHHB',address>>16,start,start+size,start+size+2,0x48)))
        records[row['descriptor']]=(tempo,note,row)
    banks={int(k):v for k,v in recipe['banks'].items()}
    for bank,at in banks.items():writes.append((0x3c05+bank*2,struct.pack('<H',at)))
    instruments={}
    for row in recipe['instruments']:
        bank,tone,descriptor=row
        require(descriptor in records and bank in banks,'Unbound voice instrument')
        writes.append((banks[bank]+tone*4,struct.pack('<HBB',descriptor,0,0x40)))
        instruments[bank,tone]=descriptor
    sequences={}
    for row in recipe['sequences']:
        at,player,bank,tone=row
        descriptor=instruments[bank,tone];tempo,note,_=records[descriptor]
        original=pointer(canonical,0x309+(player-1)*0x500);header=canonical[original:original+33]
        require(player in (1,2) and len(header)==33 and header[0]==16,'Original player header')
        writes.append((at,header+bytes([5,tempo,6,255,7,125,31,bank,8,tone,9,3,note,23])))
        sequences[at]=descriptor
    for row in recipe['commands']:
        command,at,entry,event=row
        require(at in sequences,'Voice command target is not constructed')
        sample=records[sequences[at]][2]
        require(events[entry][event]==sample['sample'] and sample['entry']==entry,'Original event-to-sample route differs')
        writes.append((0x8c06+command*4,at.to_bytes(3,'big')))
    for command in recipe['absent_commands']:writes.append((0x8c06+command*4,bytes(3)))
    return writes



def main():
    import argparse,json
    from pathlib import Path
    parser=argparse.ArgumentParser(description=__doc__)
    for n in ('canonical','root','recipe','catalog','out'):parser.add_argument('--'+n,type=Path,required=True)
    args=parser.parse_args()
    writes=construct(args.canonical.read_bytes(),lambda n:(args.root/n).read_bytes(),
        json.loads(args.recipe.read_text()),json.loads(args.catalog.read_text()))
    data=bytearray(0x80000);mask=bytearray(len(data))
    for at,blob in writes:
        require(0<=at<=len(data)-len(blob),'Voice allocation exceeds sound memory')
        for i,value in enumerate(blob):
            require(not mask[at+i] or data[at+i]==value,'Conflicting voice allocations')
            data[at+i]=value;mask[at+i]=1
    args.out.mkdir()
    (args.out/'sound.bin').write_bytes(data);(args.out/'sound.mask').write_bytes(mask)


if __name__=='__main__':main()
