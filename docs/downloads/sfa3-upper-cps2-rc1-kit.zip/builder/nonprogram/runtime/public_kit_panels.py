"""Recreate the existing English stage panels from native art and glyphs."""
import hashlib
import struct
import public_kit_graphics as gfx

FONT_WORDS = {5: 0x013, 6: 0xbef, 7: 0x9df, 8: 0x7ce, 9: 0x5ac, 10: 0x38b}
FONT_PENS = {0: 5, 12: 6, 2: 7, 10: 8, 6: 9, 14: 10}


def country_canvas(comp2, coords, tiles, owner, selector, region='us'):
    """Original Upper foreground frame, decoded from its typed resources."""
    gfx.require(owner in (33, 34, 35) and 0 <= selector < 6, 'Country foreground domain')
    gfx.require(region in ('us', 'jp'), 'Country source region')
    base, table = (0x60ad00, 0x648bc8) if region == 'us' else (0x60b080, 0x649d38)
    def read(at, count):
        gfx.require(base <= at <= base+len(comp2)-count, 'Foreground component extent')
        return comp2[at-base:at-base+count]
    offset = struct.unpack('<h', read(table+selector*2, 2))[0]
    cel = struct.unpack('<I', read(table+offset+owner*8+4, 4))[0]
    return cel_canvas(comp2,coords,tiles,cel,region)


def cel_canvas(comp2,coords,tiles,cel,region):
    """Decode a complete original cel, including retained unreferenced art."""
    gfx.require(region in ('us','jp'),'Original cel region')
    base=0x60ad00 if region=='us' else 0x60b080
    def read(at,count):
        gfx.require(base<=at<=base+len(comp2)-count,'Original cel component extent')
        return comp2[at-base:at-base+count]
    kind, total, last = struct.unpack('<3H', read(cel, 6))
    gfx.require(kind == 2 and 0 <= last < 1024, 'Foreground cel grammar')
    pointer = (cel+9) & ~3
    gfx.require(not any(read(cel+6, pointer-cel-6)), 'Foreground alignment padding')
    xy = struct.unpack('<I', read(pointer, 4))[0]-0xb04000
    count = last+1
    gfx.require(xy % 4 == 0 and 0 <= xy <= len(coords)-count*4, 'Foreground coordinate extent')
    points = list(struct.iter_unpack('<2h', coords[xy:xy+count*4]))
    words = struct.unpack('<'+str(count)+'I', read(pointer+4, count*4))
    commands = [(x, y, w & 65535, w >> 16) for (x, y), w in zip(points, words)]
    gfx.require(sum(((a >> 8 & 15)+1)*((a >> 12 & 15)+1) for _, _, _, a in commands) == total,
                'Foreground cell area')
    left, top = min(x for x, _, _, _ in commands), min(y for _, y, _, _ in commands)
    right = max(x+16*((a >> 8 & 15)+1) for x, _, _, a in commands)
    bottom = max(y+16*((a >> 12 & 15)+1) for _, y, _, a in commands)
    gfx.require(0 < right-left <= 512 and 0 < bottom-top <= 256, 'Foreground canvas extent')
    image = [bytearray([15])*(right-left) for _ in range(bottom-top)]
    for x, y, code, attr in commands:
        width, height = (attr >> 8 & 15)+1, (attr >> 12 & 15)+1
        for dy in range(height):
            for dx in range(width):
                n = (code & ~15)+((code+dx) & 15)+dy*16
                tile = tiles[n*128:(n+1)*128]
                gfx.require(len(tile) == 128, 'Foreground tile extent')
                tile = gfx.tile_variants(tile)[(attr >> 5) & 3]
                pens = [p for b in tile for p in (b & 15, b >> 4)]
                px = x-left+16*(width-1-dx if attr & 32 else dx)
                py = y-top+16*(height-1-dy if attr & 64 else dy)
                for yy in range(16):
                    for xx in range(16):
                        pen = pens[yy*16+xx]
                        if pen != 15:
                            image[py+yy][px+xx] = pen
    return image, {'cel': hex(cel), 'origin': [left, top], 'region':region}


def from_pools(root, catalog, recipe):
    """Use canonical SFZ3J descriptors and shared arcade glyphs, never a candidate."""
    names = sorted((name for name, pin in catalog['pools'].items()
                    if pin['region'] == 'jp' and pin['kind'] == 'rom' and pin['bytes'] == 0x80000),
                   key=lambda name: name.rsplit('.', 1)[1])
    gfx.require(len(names) == 8, 'Eight canonical Japanese program members required')
    def read(name):
        data = (root/name).read_bytes(); pin = catalog['pools'][name]
        gfx.require(len(data) == pin['bytes'] and hashlib.sha256(data).hexdigest() == pin['sha256'],
                    'Changed caption input: '+name)
        return data
    encoded = b''.join(read(name) for name in names)
    raw = bytearray(len(encoded));raw[::2], raw[1::2] = encoded[1::2], encoded[::2]
    pixels = read('arcade-jp-pixels.bin')
    strips = {}
    for name, pin in recipe.get('countries', {}).items():
        source=pin['source'];gfx.require(source['region']=='us','Country source must come from the USA disc')
        comp2=read('ps2-us-comp2.bin');cel=int(source['address'],16);offset=cel-0x60ad00
        gfx.require(0<=offset<=len(comp2)-source['bytes'] and
                    hashlib.sha256(comp2[offset:offset+source['bytes']]).hexdigest()==source['sha256'],
                    'Original retained country cel identity')
        image, _ = cel_canvas(comp2,read('ps2-us-coords390.bin'),read('ps2-us-entry351-s0.bin'),cel,'us')
        rows = [b''.join(image[y][x:x+width] for x, width in pin['columns'])
                for y in range(35, 48)]
        gfx.require(hashlib.sha256(b''.join(rows)).hexdigest() == pin['sha256'],
                    'Original country artwork identity')
        strips[name] = rows
    return construct(raw, pixels, recipe, strips)


def construct(raw, pixels, recipe, strips=None):
    gfx.require(recipe['schema'] == 1, 'Panel recipe schema')
    palette = [v & 4095 for v in struct.unpack_from('>16H', raw, 0x35e3d4)]
    updated = palette.copy()
    for pen, word in FONT_WORDS.items():
        updated[pen] = word
    colors = {v: i for i, v in enumerate(updated) if i != 15}
    colors[0] = 15

    def cell(code):
        tile = pixels[code*128:(code+1)*128]
        gfx.require(len(tile) == 128, 'Native panel source extent')
        return [n for b in tile for n in (b & 15, b >> 4)]

    blank, lower = (cell(0x30000+n) for n in (56672, 56680))
    font = {}
    for ch in set(''.join(r['text'] for r in recipe['panels'])):
        gfx.require(32 <= ord(ch) <= 126, 'Unsupported native caption character')
        # The native ASCII reader reverses plane significance relative to the
        # panel renderer; reproduce its existing glyph interpretation.
        font[ch] = [int(f'{p:04b}'[::-1], 2) for p in cell(0x16c00+0x280+ord(ch))]
    result = []
    for item in recipe['panels']:
        pin = item['source']; at = int(pin['address'], 16)
        gfx.require(hashlib.sha256(raw[at:at+pin['bytes']]).hexdigest() == pin['sha256'],
                    'Original caption descriptor identity')
        kind, total, last, hx, hy = struct.unpack_from('>3H2h', raw, at)
        gfx.require(kind == 6 and 0 <= last < 256, 'Caption cel grammar')
        commands = []
        for i in range(last+1):
            coord, code, attr = struct.unpack_from('>3H', raw, at+10+i*6)
            gfx.require(coord % 4 == 0 and coord < 1024, 'Caption coordinate')
            x, y = struct.unpack_from('>2h', raw, 0x229ae+coord)
            commands.append((code, attr, hx+x, hy+y))
        gfx.require(sum(((a >> 8 & 15)+1)*((a >> 12 & 15)+1) for _, a, _, _ in commands) == total,
                    'Caption tile area')
        heading = [x for code, _, x, y in commands if code == 57296 and y == 0]
        gfx.require(heading in ([-120], [-24]), 'Caption placement')
        left = -104 if heading == [-120] else -120
        image = [[0]*224 for _ in range(32)]
        for code, attr, x, y in commands:
            width, height = (attr >> 8 & 15)+1, (attr >> 12 & 15)+1
            for dy in range(height):
                for dx in range(width):
                    n = code+dx+16*dy if attr & 0x60 else (code & ~15)+((code+dx) & 15)+16*dy
                    pens = cell(0x30000+n)
                    px = x+16*(width-1-dx if attr & 32 else dx)-left
                    py = y+16*(height-1-dy if attr & 64 else dy)-16
                    for yy in range(16):
                        for xx in range(16):
                            pen = pens[(15-yy if attr & 64 else yy)*16+(15-xx if attr & 32 else xx)]
                            if pen != 15 and 0 <= px+xx < 224 and 0 <= py+yy < 32:
                                image[py+yy][px+xx] = palette[pen]
        ink = [(x, y) for y in range(32) for x in range(224)
               if image[y][x] and image[y][x] >> 8 != 15]
        gfx.require(ink and min(y for _, y in ink) >= 2 and max(y for _, y in ink) < 19,
                    'Original caption ink bounds')
        for x, y in ink:
            pen = (blank if y < 16 else lower)[(y % 16)*16+x % 16]
            image[y][x] = 0 if pen == 15 else palette[pen]
        text = item['text']
        def layout(space):
            advance, points, positions = 0, [], []
            for ch in text:
                positions.append(advance)
                points.extend((advance+i % 16, i//16) for i, p in enumerate(font[ch]) if p != 15)
                advance += space if ch == ' ' else 8
            return positions, points
        positions, points = layout(8)
        if max(x for x, _ in points)+1-min(x for x, _ in points) > 216:
            positions, points = layout(4)
        x0, y0 = min(x for x, _ in points), min(y for _, y in points)
        width = max(x for x, _ in points)+1-x0
        height = max(y for _, y in points)+1-y0
        gfx.require(width <= 216 and height <= 14, 'Caption glyph layout')
        dx = (224-width)//2-x0
        dy = (min(y for _, y in ink)+max(y for _, y in ink)+1-height)//2-y0
        for ch, cursor in zip(text, positions):
            for i, pen in enumerate(font[ch]):
                if pen == 15:
                    continue
                x, y = dx+cursor+i % 16, dy+i//16
                gfx.require(pen in FONT_PENS and 4 <= x < 220 and 0 <= y < 19, 'Caption ink extent')
                image[y][x] = FONT_WORDS[FONT_PENS[pen]]
        if 'country' in item:
            gfx.require(strips is not None and item['country'] in strips, 'Country source required')
            rows = strips[item['country']]
            x0 = 224-len(rows[0])
            for y, row in enumerate(rows):
                for x, pen in enumerate(row):
                    image[y+19][x+x0] = 0 if pen == 15 else palette[pen]
        output = bytearray([255])*(32*128)
        for ty in range(2):
            for tx in range(14):
                pens = [colors[image[ty*16+y][tx*16+x]] for y in range(16) for x in range(16)]
                tile = bytes(pens[i] | pens[i+1] << 4 for i in range(0, 256, 2))
                start = (ty*16+tx)*128
                output[start:start+128] = tile
        gfx.require(hashlib.sha256(gfx.pixels_to_planar(output)).hexdigest() == item['planar_sha256'],
                    'Recreated panel differs from the pinned restoration')
        result.append(bytes(output))
    return b''.join(dict.fromkeys(result))
