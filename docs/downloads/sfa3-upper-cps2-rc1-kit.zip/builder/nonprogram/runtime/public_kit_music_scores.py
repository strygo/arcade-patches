"""Decrypt the converted music score bytes with a keystream derived from your NAOMI program.

The kit ships the four converted songs' QSound sequence, instrument and articulation bytes
only in encrypted form. The key is SHA-512 over a label and the complete decoded NAOMI program
from your own GD-ROM, so the payload is unreadable without that disc. The keystream is SHA-256
in counter mode over that key.
"""
import hashlib


def require(ok, message):
    if not ok:
        raise ValueError(message)


def keystream(label, key_material, length):
    secret = hashlib.sha512(label.encode() + key_material).digest()
    blocks = (length + 31) // 32
    return b''.join(hashlib.sha256(secret + i.to_bytes(8, 'big')).digest() for i in range(blocks))[:length]


def decode(spec, payload, key_material):
    """Place the decrypted score bytes at their ranges in a zeroed score image and check its pin."""
    total = sum(n for _, n in spec['ranges'])
    require(len(payload) == total, 'Music score payload extent')
    plain = bytes(x ^ y for x, y in zip(payload, keystream(spec['label'], key_material, total)))
    blob = bytearray(spec['scores']['bytes'])
    at = 0
    for offset, n in spec['ranges']:
        require(0 <= offset and offset + n <= len(blob), 'Music score range')
        blob[offset:offset + n] = plain[at:at + n]
        at += n
    blob = bytes(blob)
    require(hashlib.sha256(blob).hexdigest() == spec['scores']['sha256'],
            'Music scores differ: the NAOMI program does not match the declared original')
    return blob
