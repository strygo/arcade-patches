"""Strict source-only graphics recipe interpreter for the Upper kit."""
from __future__ import annotations
import hashlib
import public_kit_graphics as gfx


def digest(data):
    return hashlib.sha256(data).hexdigest()


def apply(recipe, pools):
    gfx.require(recipe.get('schema') == 1 and recipe.get('complete') is True,
                'Incomplete or unsupported graphics recipe')
    size = recipe.get('pixel_bytes')
    gfx.require(type(size) is int and 0 < size <= 64*1024**2 and size % 128 == 0,
                'Invalid graphics extent')
    pins = recipe['pools']
    gfx.require(set(pins) == set(pools), 'Missing or unexpected graphics pools')
    for name, pin in pins.items():
        data = pools[name]
        gfx.require(len(data) == pin['bytes'] and digest(data) == pin['sha256'],
                    'Graphics source identity mismatch: '+name)
    result, used = bytearray(), set()
    for op in recipe['operations']:
        gfx.require(isinstance(op, list) and bool(op), 'Invalid graphics operation')
        if op[0] == 'fill':
            gfx.require(len(op) == 3 and type(op[1]) is int and op[1] in (0, 255),
                        'Unsupported graphics fill')
            length = op[2]
            gfx.require(type(length) is int and 0 < length <= size-len(result), 'Fill extent')
            block = bytes([op[1]])*length
        elif op[0] in ('copy', 'tile', 'scroll1', 'rows'):
            gfx.require(len(op) == {'copy': 4, 'tile': 5, 'scroll1': 3, 'rows': 5}[op[0]], 'Graphics operation arity')
            name, offset = op[1:3]
            gfx.require(name in pools and type(offset) is int and offset >= 0,
                        'Invalid graphics source')
            length = op[3] if op[0] == 'copy' else (32 if op[0] == 'scroll1' else 128)
            gfx.require(type(length) is int and 0 < length <= size-len(result) and
                        offset <= len(pools[name])-length, 'Graphics source extent')
            block = pools[name][offset:offset+length]
            used.add(name)
            if op[0] == 'scroll1':
                gfx.require(64 <= size-len(result), 'Scroll1 output extent')
                block = b''.join(block[y*4:y*4+4]*2 for y in range(8))
            if op[0] == 'rows':
                flip, rows = op[3:]
                gfx.require(type(flip) is int and flip in (0, 1) and isinstance(rows, list)
                            and len(rows) == 16 and all(type(y) is int and 0 <= y < 16 for y in rows),
                            'Invalid native row projection')
                block = gfx.tile_variants(block)[flip]
                block = b''.join(block[y*8:y*8+8] for y in rows)
            if op[0] == 'tile':
                flip, mapping = op[3:5]
                gfx.require(type(flip) is int and 0 <= flip < 4, 'Invalid tile orientation')
                block = gfx.tile_variants(block)[flip]
                if mapping is not None:
                    block = gfx.remap(block, mapping)
        else:
            raise ValueError('Unknown graphics operation: '+str(op[0]))
        result.extend(block)
    gfx.require(used == set(pins), 'Unused graphics source')
    gfx.require(len(result) == size and digest(result) == recipe['pixel_sha256'],
                'Reconstructed graphics identity mismatch')
    return bytes(result)


def reconstruct(recipe, pools):
    pixels = apply(recipe, pools)
    gfx.require(len(pixels) == 64*1024**2, 'Complete Upper graphics extent required')
    bus = gfx.shuffle_bus(gfx.pixels_to_planar(pixels), inverse=True)
    gfx.require(digest(bus) == recipe['bus_sha256'], 'Reconstructed graphics bus mismatch')
    result = gfx.split_graphics(bus[:32*1024**2])
    result['upper.gfx'] = bus[32*1024**2:]
    return result


def self_test():
    import copy
    source = bytes(range(128))
    target = source+gfx.tile_variants(source)[1]+bytes([255])*128
    pools = {'source': source}
    recipe = {'schema': 1, 'complete': True, 'pixel_bytes': len(target),
              'pixel_sha256': digest(target),
              'pools': {'source': {'bytes': 128, 'sha256': digest(source)}},
              'operations': [['copy', 'source', 0, 128], ['tile', 'source', 0, 1, None],
                             ['fill', 255, 128]]}
    gfx.require(apply(recipe, pools) == target, 'Graphics recipe witness')
    packed = b''.join(source[y*4:y*4+4]*2 for y in range(8))
    scroll = dict(recipe, pixel_bytes=128, pixel_sha256=digest(packed*2),
                  operations=[['scroll1', 'source', 0], ['scroll1', 'source', 0]])
    gfx.require(apply(scroll, pools) == packed*2, 'Scroll1 repeated-row packing witness')
    rows = [7, 6, 5, 4]+list(range(4, 16))
    projected = b''.join(source[y*8:y*8+8] for y in rows)
    row_recipe = dict(recipe, pixel_bytes=128, pixel_sha256=digest(projected),
                      operations=[['rows', 'source', 0, 0, rows]])
    gfx.require(apply(row_recipe, pools) == projected, 'Native roof row projection witness')
    for bad_rows in ([16]*16, [0]*15):
        bad = dict(row_recipe, operations=[['rows', 'source', 0, 0, bad_rows]])
        try:
            apply(bad, pools)
        except ValueError:
            pass
        else:
            raise AssertionError('Invalid row projection accepted')
    mutations = [lambda r: r.update(complete=False),
                 lambda r: r.update(pixel_sha256='0'*64),
                 lambda r: r['operations'][0].__setitem__(2, -1),
                 lambda r: r['operations'][0].__setitem__(3, 129),
                 lambda r: r['operations'][1].__setitem__(3, 4),
                 lambda r: r['operations'][2].__setitem__(1, 1),
                 lambda r: r['operations'][0].__setitem__(0, 'literal'),
                 lambda r: r['operations'][0].__setitem__(0, 'unresolved')]
    for mutate in mutations:
        bad = copy.deepcopy(recipe)
        mutate(bad)
        try:
            apply(bad, pools)
        except ValueError:
            pass
        else:
            raise AssertionError('Invalid graphics recipe accepted')
    try:
        apply(recipe, {'source': bytes(128)})
    except ValueError:
        pass
    else:
        raise AssertionError('Changed source accepted')
    print('Graphics recipe: copy, Scroll1 and row witnesses; eleven negative controls PASS')


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--self-test', action='store_true', required=True)
    parser.parse_args()
    self_test()
