"""Place qualified native score objects and project the accepted volume operands."""
import struct
from score_support import require,digest


def placement(outputs,canonical,plan):
    import upper_music_loop_layout as logical
    require(digest(canonical) == '50df03344cf604262fd98f8157b4bb96de5806ef0be5d3cf9f9140b30b5c5b35', 'Original volume table differs')
    channels = [outputs[f'channel_{n:02d}.bin'] for n in range(16)]
    if plan['instrument_bank'] == 24:
        import thawk_music_scatter as scatter
        _,translation,_,_ = logical.logical_score(channels)
        starts = translation['commands'][0]['channel_offsets']; changed = [bytearray(v) for v in channels]
        for row in translation['instruction_map']:
            if row['source_opcode'] == 31:
                channel = row['channel']; at = row['source']-starts[channel]
                require(changed[channel][at+1] == 23, 'Provisional native instrument bank differs')
                changed[channel][at+1] = 24
        channels = [bytes(v) for v in changed]
        writes,graph,_,_ = scatter.layout(channels,plan['free_runs'],relay_runs=plan['relay_runs'])
        header = graph['header']
    else:
        writes,_,_,_,_,graph = logical.layout(channels,score_base=plan['score_start'],relay_bytes=32)
        header = graph['header']
        require(graph['score_end'] == plan['score_end'], 'Accepted native score extent differs')
    lut = struct.unpack_from('<128H',canonical,0x2e92); gain = 10**(plan['gain_db']/20)
    require(0 < plan['gain_db'] < 12, 'Unqualified native music gain')
    result = []; sites = changed_count = 0
    for at,data,name in writes:
        if name == 'music_instruction_group' and data[0] == 7:
            require(len(data) == 2 and data[1] < 128, 'Invalid native gain instruction')
            sites += 1; old = data[1]
            new = min(range(128),key=lambda k:(abs(lut[k]-lut[old]*gain),k)) if old else 0
            changed_count += old != new; data = bytes([7,new])
        result.append((at,data,name))
    require(sites == plan['volume_sites'], 'Accepted source volume sites differ')
    score_bytes = sum(len(data) for _,data,_ in result)
    result.append((0x8c06+plan['command']*4,header.to_bytes(3,'big'),'score_catalog'))
    descriptors = bytearray(outputs['descriptors.bin']); instruments = bytearray(outputs['instruments.bin'])
    arts = outputs['articulations.bin']; count = len(plan['art_rows'])
    require(len(arts) == len(descriptors) == count*8 and len(instruments) == count*4, 'Complete music resources required')
    for index,art in enumerate(plan['art_rows']):
        row,fine,prior_art = struct.unpack_from('<HBB',instruments,index*4)
        require((row,fine,prior_art) == (plan['source_first_descriptor']+index,0,plan['source_art_rows'][index]), 'Source resource selector differs')
        struct.pack_into('<HBB',instruments,index*4,plan['first_descriptor']+index,0,art)
        descriptors[index*8] += plan['sample_bank_add']
        result.append((0x8000+art*8,arts[index*8:index*8+8],'articulation'))
    result += [(plan['instrument_base'],bytes(instruments),'instruments'),
               (0x6000+plan['first_descriptor']*8,bytes(descriptors),'descriptors')]
    if plan['instrument_bank'] == 24:
        result += [(0x3c35,struct.pack('<H',0x3ebc),'instrument_bank'),
                   (0x3492+108*2,struct.pack('<H',512),'native_tempo')]
    return result,{'score_bytes':score_bytes,'volume_sites':sites,'changed_volume_operands':changed_count,
                   'resource_bytes':sum(len(b) for _,b,_ in result)-score_bytes,'native_graph_verified':True}
