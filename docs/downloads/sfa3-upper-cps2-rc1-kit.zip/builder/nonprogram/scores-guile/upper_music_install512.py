"""Pinned original score conversion functions; no checkout dependency."""
from __future__ import annotations


LINEAR_BYTES=0x80000


