"""Pinned original score conversion functions; no checkout dependency."""
from __future__ import annotations
from score_support import require
import numpy as np
import struct
import upper_music_envelopes as envelope
import upper_music_sources as music

RATE = 44100


def aeg_curve(fields, pitch, frames, gate, tables):
    """Vectorize the pinned scalar AEG for an unlinked, constant-rate voice."""
    require(not fields['loop_start_link'], 'Linked AEG not supported by preview')
    base = envelope.key_rate(pitch, fields['key_rate_scaling'])
    require(base == 0, 'Preview only qualifies KRS-disabled instruments')
    ar = envelope.rate_increment(envelope.rate_index(base, fields['attack']), tables['AR'], True)
    d1 = envelope.rate_increment(envelope.rate_index(base, fields['decay_one']), tables['DR'])
    d2 = envelope.rate_increment(envelope.rate_index(base, fields['decay_two']), tables['DR']) if fields['decay_two'] else 0
    ticks = np.arange(1, frames+1, dtype=np.int64)
    initial = 0x17f << envelope.EG_SHIFT
    attack = max(1, (envelope.EG_MAX-initial+ar-1)//ar) if ar else frames+1
    attack_mask = ticks <= attack if d1 else np.ones(frames, dtype=bool)
    volume = np.minimum(envelope.EG_MAX, initial+ticks*ar)
    if d1:
        threshold = ((32-fields['decay_level']) << (envelope.EG_SHIFT+5))-1
        decay = max(1, (max(0, envelope.EG_MAX-threshold)+d1-1)//d1)
        elapsed = np.maximum(0, ticks-attack)
        volume[ticks >= attack] = np.maximum(0, envelope.EG_MAX-np.minimum(elapsed, decay)*d1-np.maximum(0, elapsed-decay)*d2)[ticks >= attack]
    if gate < frames:
        at_gate, _ = envelope.gate_envelope_volume(fields, gate, pitch, tables)
        rr = envelope.rate_increment(envelope.rate_index(base, max(1, fields['release'])), tables['DR'])
        volume[gate:] = np.maximum(0, at_gate-(ticks[gate:]-gate)*rr)
        attack_mask[gate:] = False
    # Attack has linear gain; decay/release use the original logarithmic table.
    steps = volume >> envelope.EG_SHIFT
    gain = np.power(10., (3.*(steps-1023)/32.)/20.)
    gain[attack_mask] = steps[attack_mask]/1024.
    gain[volume == 0] = 0
    return gain


def source_controls(body, record, curve, controls):
    """Original velocity/TL/pan tables with approximate channel dynamics."""
    volume = controls.get('7', 100); expression = controls.get('11', 127)
    raw = (((curve+1)*(volume+1)*(256-record[21])-1) >> 14) & 255
    raw = min(255, max(0, raw+2*expression-256))
    tl_table = music.u32(body, 0x1890)
    tl = body[tl_table+raw]
    bits = (.4, .8, 1.5, 3., 6., 12., 24., 48.)
    gain = 10**(-sum(db for bit, db in enumerate(bits) if tl & (1 << bit))/20)
    default_table = music.u32(body, 0x1894)
    pan_table = music.u32(body, 0x1898)
    instrument_pan = body[default_table+(struct.unpack_from('<H', record, 18)[0] & 31)]
    pan = body[pan_table+min(127, max(0, instrument_pan+controls.get('10', 64)-64))]
    atten = 0. if pan & 15 == 15 else 10**(-3.*(pan & 15)/20)
    return gain, (atten, 1.) if pan < 16 else (1., atten)


