"""Pinned original score conversion functions; no checkout dependency."""
from __future__ import annotations
from collections import defaultdict
from fractions import Fraction
from scipy.signal import resample
from scipy.signal import resample_poly
from score_support import digest
from score_support import require
import math
import numpy as np
import scipy
import struct
import upper_music_envelopes as envelope
import upper_music_performance as performance
import upper_music_sources as music

SOURCE_RATE = 44100


DSP_CLOCK = 60000000


DSP_SAMPLE_RATE = Fraction(DSP_CLOCK, 2496)


DESCRIPTOR_ROOT = 0x48


BANK_BYTES = 65536


HALF_BYTES = 32768


NATIVE_SHA256 = '50df03344cf604262fd98f8157b4bb96de5806ef0be5d3cf9f9140b30b5c5b35'


NATIVE_SPANS = (
    ('descriptor_consumer', 0x1466, 0x155e, '34e7c354838e3695b04f079cb2a322f1e1b7defce1d74d5d20425534d1f41332'),
    ('pitch_consumer', 0x20e5, 0x2140, 'b7d1e468e8d6b2028ee4f9310679c2181776b433233c0a8c317625ddd4ac4fa8'),
    ('pitch_tables', 0x2145, 0x2e92, '09eca6cbbd5a0f7d1337a2770ed819675881a57fe1003d8d48f9e350f647fe1e'),
)


def native_contract(data):
    require(digest(data) == NATIVE_SHA256, 'Canonical native QSound1.71 payload identity')
    for role, first, last, sha in NATIVE_SPANS:
        require(digest(data[first:last]) == sha, 'Native sample/pitch consumer differs: '+role)
    require(data[0x146d:0x1470] == b'\x29\x29\x29' and
            data[0x1504:0x1507] == b'\x3e\x05\x81' and
            data[0x1525:0x1528] == b'\xb7\xed\x52' and
            data[0x1545:0x154a] == bytes.fromhex('e678268068'), 'Native descriptor field/register interpretation')
    return {'payload_sha256': NATIVE_SHA256, 'version': 'QSound1.71',
        'spans': [{'role': n, 'z80_address': a, 'bytes': b-a, 'sha256': sha} for n,a,b,sha in NATIVE_SPANS],
        'descriptor_format': '<BHHHB: bank,start,absolute loop start,end exclusive,root',
        'hardware_loop_length': 'end-absolute_loop_start', 'ordinary_bank_bits': 8,
        'pitch': 'Root-corrected 8.8 semitone state, clamped0..107, converted through the resident octave/frequency/interpolation tables.',
        'descriptor_root': DESCRIPTOR_ROOT, 'rate_word_fraction_bits': 12,
        'dsp_sample_rate_fraction': [DSP_SAMPLE_RATE.numerator, DSP_SAMPLE_RATE.denominator],
        'actual_native_playback_accepted': False}


def desired_rate_word(record, source_step):
    require(type(source_step) is int and source_step > 0, 'Positive original AICA sample increment required')
    return Fraction(record['base_rate_word']*source_step, 4096)


def desired_voice_rate(body, voice, record, bend_raw=None):
    if bend_raw is None: bend_raw = 64 if voice['pitch_raw'] is None else voice['pitch_raw']
    pitch = envelope.manatee_pitch(body, voice['key'], voice['base_key'], bend_raw=bend_raw,
        bend_high=voice['bend_range_high'], bend_low=voice['bend_range_low'])
    return desired_rate_word(record, envelope.sample_step(pitch))


def sample_map(report):
    rows = {r['source_pcm16_sha256']: r for r in report['samples']}
    require(len(rows) == len(report['samples']), 'Ambiguous source sample identity')
    return rows


def decoded_pcm8(record, payload):
    first, count = record['relative_offset'], record['pcm8_frames']
    require(0 <= first <= len(payload)-count, 'Converted sample outside payload')
    return np.frombuffer(payload[first:first+count], dtype=np.int8)


def plans(body, program_blob, performed):
    voices, demand = performance.voice_demand(performed, program_blob)
    groups = defaultdict(list)
    for voice in voices: groups[voice['sample_offset']].append(voice)
    bends = {ch: {r['argument'] for r in performed['timeline'] if r['kind'] == 'pitch' and r['channel'] == ch}
             for ch in performed['summary']['channels']}
    result = []
    for offset, own in sorted(groups.items()):
        voice = own[0]
        require(all((v['sample_frames'], v['loop_enabled'], v['loop_start'], v['sample_sha256']) ==
                    (voice['sample_frames'], voice['loop_enabled'], voice['loop_start'], voice['sample_sha256'])
                    for v in own), 'Aliased sample has incompatible loop/length interpretation')
        states = sorted({(v['channel'], v['key'], v['base_key'], v['bend_range_high'], v['bend_range_low'],
                          64 if v['pitch_raw'] is None else v['pitch_raw']) for v in own})
        steps = []
        for channel, key, root, high, low, onset_bend in states:
            for bend in sorted(bends[channel] | {onset_bend}):
                pitch = envelope.manatee_pitch(body, key, root, bend_raw=bend, bend_high=high, bend_low=low)
                steps.append(envelope.sample_step(pitch))
        minimum, maximum = min(steps), max(steps)
        # Highest base up to one sample/output that also covers all declared
        # score bends conservatively, including bends outside each note's gate.
        word = min(4096, (4096*4096)//maximum)
        require(word > 0, 'Written pitch range cannot fit a nonzero base rate')
        effective = DSP_SAMPLE_RATE*Fraction(word,4096); target = round(effective)
        intro_source = voice['loop_start'] if voice['loop_enabled'] else voice['sample_frames']
        intro = round(intro_source*target/SOURCE_RATE)
        loop_source = voice['sample_frames']-intro_source if voice['loop_enabled'] else 0
        loop = round(loop_source*target/SOURCE_RATE)
        require(intro >= 0 and (not voice['loop_enabled'] or loop >= 2) and 0 < intro+loop+2 < HALF_BYTES,
                'Converted sample/loop does not fit one signed half-bank')
        row = {'sample_id': len(result), 'source_offset': offset, 'source_frames': voice['sample_frames'],
            'source_pcm16_sha256': voice['sample_sha256'], 'sample_sha256': voice['sample_sha256'],
            'programs': sorted({v['program'] for v in own}),
            'split_record_offsets': sorted({v['split_record_offset'] for v in own}),
            'source_base_keys': sorted({v['base_key'] for v in own}),
            'source_key_bounds': [min(v['key'] for v in own), max(v['key'] for v in own)],
            'source_pitch_step_bounds': [minimum, maximum], 'source_pitch_state_tuples': [list(s) for s in states],
            'source_channel_bend_values': {str(ch): sorted(bends[ch]) for ch in sorted({v['channel'] for v in own})},
            'base_rate_word': word, 'effective_rate_fraction': [effective.numerator, effective.denominator],
            'resample_rate_hz': target, 'integer_resample_rate_error_ppm': float(effective/target-1)*1e6,
            'qualified_desired_rate_word_bounds': [[word*minimum,4096],[word*maximum,4096]],
            'source_loop_enabled': voice['loop_enabled'], 'source_loop_start': voice['loop_start'],
            'source_loop_frames': loop_source, 'intro_frames': intro, 'loop_frames': loop,
            'pcm8_frames': intro+loop, 'descriptor_root': DESCRIPTOR_ROOT}
        if loop:
            ratio = effective*loop_source/(loop*SOURCE_RATE)
            row['loop_period_frequency_error_cents'] = 1200*math.log2(float(ratio))
            row['source_loop_seconds'] = loop_source/SOURCE_RATE
            row['converted_loop_seconds_at_base_rate'] = float(loop/effective)
        result.append(row)
    return result, demand


def convert(pcm16, plan):
    require(np.__version__ == '2.2.6' and scipy.__version__ == '1.15.3', 'Pinned sample resampler versions required')
    pcm = np.asarray(pcm16, dtype=np.float64)
    require(pcm.ndim == 1 and len(pcm) == plan['source_frames'], 'Source PCM16 dimensions')
    ratio = Fraction(plan['resample_rate_hz'], SOURCE_RATE)
    intro = plan['intro_frames']
    if plan['source_loop_enabled']:
        first = plan['source_loop_start']; loop = pcm[first:]
        require(len(loop) == plan['source_loop_frames'] and len(loop) > 0, 'Source loop extent')
        # Actual loop context avoids treating the intro's end as zero-padding.
        context = np.r_[pcm, np.tile(loop, max(1, math.ceil(64/len(loop))))]
        lead = resample_poly(context, ratio.numerator, ratio.denominator,
            window=('kaiser',8.6), padtype='constant')[:intro]
        # A periodic FFT resampler preserves the integer converted loop cycle,
        # instead of cutting an arbitrary resampling phase and padding its seam.
        cycle = resample(loop, plan['loop_frames'])
        filtered = np.r_[lead, cycle]
    else:
        filtered = resample_poly(pcm, ratio.numerator, ratio.denominator,
            window=('kaiser',8.6), padtype='constant')[:intro]
    require(len(filtered) == plan['pcm8_frames'], 'Converted PCM extent differs from plan')
    rounded = np.rint(filtered/256)
    clipped = int(np.count_nonzero((rounded < -128) | (rounded > 127)))
    quantized = np.clip(rounded,-128,127).astype(np.int8)
    residual = filtered-quantized.astype(np.float64)*256
    error = float(np.sqrt(np.mean(residual**2))); signal = float(np.sqrt(np.mean(filtered**2)))
    metrics = {'pcm8_sha256': digest(quantized.tobytes()), 'saturated_quantized_frames': clipped,
        'filtered_pcm16_rms': signal, 'quantization_error_pcm16_rms': error,
        'quantization_snr_db': 20*math.log10(signal/error) if signal and error else None,
        'peak_abs_pcm8': int(np.max(np.abs(quantized.astype(np.int16)))),
        'quantization': 'nearest ties to even, saturate signed PCM8; no gain normalization',
        'intro_resampling': 'polyphase Kaiser8.6 with source loop future context or one-shot zero padding',
        'loop_resampling': 'periodic FFT bandlimited to the converted integer cycle; no seam fade'}
    if plan['source_loop_enabled']:
        metrics['converted_loop_wrap_step_pcm8'] = int(quantized[intro])-int(quantized[-1])
        metrics['converted_intro_join_step_pcm8'] = int(quantized[intro])-int(quantized[intro-1]) if intro else None
        metrics['source_loop_wrap_step_pcm16'] = int(pcm[plan['source_loop_start']])-int(pcm[-1])
    return quantized.tobytes(), metrics


def place(converted, sample_bank_base=0x8d):
    require(type(sample_bank_base) is int and 0 <= sample_bank_base <= 255, 'Ordinary PCM bank base outside0..255')
    cursor = 0; rows = []; spans = []
    for plan, pcm in converted:
        n = len(pcm); require(n == plan['pcm8_frames'] and 0 < n+2 < HALF_BYTES, 'Signed sample allocation length')
        cursor = (cursor+15)//16*16
        if cursor%HALF_BYTES+n+2 >= HALF_BYTES: cursor = (cursor//HALF_BYTES+1)*HALF_BYTES
        address = sample_bank_base*BANK_BYTES+cursor
        bank, start = address>>16, address&65535
        end = start+n if plan['source_loop_enabled'] else start+n+2
        loop = start+plan['intro_frames'] if plan['source_loop_enabled'] else end-2
        require(bank <= 255 and 0 <= start <= loop < end <= 65535 and
                start//HALF_BYTES == (end-1)//HALF_BYTES and end-loop < HALF_BYTES,
                'Descriptor crosses signed endpoints or ordinary bank limit')
        descriptor = struct.pack('<BHHHB',bank,start,loop,end,plan['descriptor_root'])
        rows.append(plan | {'relative_offset': cursor, 'absolute_address': address,
            'allocation_bytes_including_guard': n+2, 'bank': bank, 'start': start, 'loop': loop, 'end': end,
            'hardware_loop_length': end-loop, 'descriptor_hex': descriptor.hex(),
            'descriptor_sha256': digest(descriptor), 'nonloop_native_idle_loop_is_two_zero_bytes': not plan['source_loop_enabled']})
        spans.append((cursor,pcm+bytes(2))); cursor += n+2
    banks = (cursor+BANK_BYTES-1)//BANK_BYTES
    require(sample_bank_base+banks <= 256, 'Relocatable sample block exceeds ordinary8-bit banks')
    output = bytearray(b'\xff'*(banks*BANK_BYTES))
    for first, data in spans: output[first:first+len(data)] = data
    return bytes(output), rows, cursor


def build(body, program_blob, performed, native_payload, sample_bank_base=0x8d):
    contract = native_contract(native_payload); selected, demand = plans(body, program_blob, performed)
    converted = []
    for plan in selected:
        source = music.bounded(program_blob, plan['source_offset'], plan['source_frames']*2, 'Canonical Upper PCM16')
        require(digest(source) == plan['source_pcm16_sha256'], 'Source sample identity differs')
        pcm, metrics = convert(np.frombuffer(source,'<i2'),plan)
        converted.append((plan | metrics,pcm))
    payload, rows, span = place(converted,sample_bank_base)
    report = {'schema': 1, 'component': 'upper_music_pcm8_samples', 'native_contract': contract,
        'source_program_bank_sha256': digest(program_blob),
        'source_performed_notes_sha256': performance.json_digest(performed['notes']),
        'source_performed_timeline_sha256': performance.json_digest(performed['timeline']),
        'source_performed_score': performed['summary'], 'samples': rows,
        'sample_bank_base': sample_bank_base, 'sample_bank_count': len(payload)//BANK_BYTES,
        'sample_payload_sha256': digest(payload), 'sample_payload_bytes': len(payload),
        'sample_address_span_bytes': span, 'used_pcm8_frames': sum(r['pcm8_frames'] for r in rows),
        'used_source_pcm16_bytes': sum(r['source_frames']*2 for r in rows),
        'descriptor_bytes': len(rows)*8, 'numpy_version': np.__version__, 'scipy_version': scipy.__version__,
        'pitch_bound_scope': 'All performed keys combined conservatively with all written bend values of each owning source channel, including onset and release states; neutral global tuning, no pitch LFO.',
        'desired_pitch_interface': 'Fraction(base_rate_word*original_AICA_sample_step,4096); native inverse LUT quantization is a separate compiler proof.',
        'conversion_is_native_playback_or_loop_quality_acceptance': False}
    sample_map(report)
    return payload, report


