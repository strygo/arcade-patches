"""Pinned original score conversion functions; no checkout dependency."""
from __future__ import annotations
from audit_qsound_frontend import instruction_size
from hsf2_music_adapter import successors
from hsf2_music_install import prove_installed_graph
from score_support import digest
from score_support import require
import struct
import upper_music_install512 as finite

DEFAULT_SHARD_BYTES = 3072


DEFAULT_RELAY_BYTES = 256


def join(prefix, steady):
    """Append native22 backedge to a nonempty, instruction-aligned steady body.

    Input sections exclude a terminal or closing jump. Internal branches keep
    their displacement bytes. The complete graph is validated by layout().
    """
    require(isinstance(prefix, bytes) and isinstance(steady, bytes) and steady,
            'Pass byte strings with a nonempty steady body')
    for body in (prefix, steady):
        cursor = 0
        while cursor < len(body):
            cursor += instruction_size(body, cursor, True)
        require(cursor == len(body), 'Partial native instruction in loop section')
    displacement = -len(steady)-3
    require(-32768 <= displacement <= 32767,
            'Steady body backedge exceeds source signed16 format')
    return prefix+steady+bytes([22])+struct.pack('>h', displacement)


def logical_score(channels):
    """Construct a virtual logical graph; actual header seeds are set at layout.

    Logical channel offsets can exceed BE16. No virtual header is played or
    installed. The frozen installed proof uses those offsets only to locate
    logical first instructions, then checks real BE16 header seeds separately.
    """
    require(len(channels) == 16 and all(isinstance(c, bytes) for c in channels),
            'Pass sixteen closed native channel byte strings')
    body = bytearray(33); rows = []; offsets = []; ends = {}; by_channel = []
    for channel, data in enumerate(channels):
        if not data:
            offsets.append(0); by_channel.append([]); continue
        start = len(body); offsets.append(start); cursor = 0; own = []
        while cursor < len(data):
            size = instruction_size(data, cursor, True); op = data[cursor]
            require(op <= 24 or op in (27, 31) or op >= 32,
                    'Unqualified loop score opcode')
            row = dict(source=start+cursor, output=start+cursor,
                       output_bytes=size, source_opcode=op, channel=channel)
            rows.append(row); own.append(row); cursor += size
        require(cursor == len(data), 'Partial loop score instruction')
        ends[channel] = start+len(data); by_channel.append(own); body.extend(data)
    require(rows, 'Loop score has no active channels')
    starts = {r['output']: r for r in rows}; visited = set(); edges = 0
    for channel, offset in enumerate(offsets):
        if not offset: continue
        own = {r['output'] for r in by_channel[channel]}; seen = set()
        pending = [(offset, 0, None)]
        while pending:
            pc, bank, instrument = pending.pop()
            if (pc, bank, instrument) in seen: continue
            seen.add((pc, bank, instrument))
            require(pc in own, 'Loop branch/fallthrough escapes its own channel')
            op = body[pc]
            if op == 31: bank = body[pc+1]
            if op == 8: instrument = (bank, body[pc+1]&127)
            if op >= 32 and op&31:
                require(instrument is not None, 'Sounding loop path has no initialized instrument')
            nexts = successors(body, pc, True)
            require(all(p in own for p in nexts),
                    'Loop branch/fallthrough targets an operand or another channel')
            visited.add(pc); edges += len(nexts)
            pending.extend((p, bank, instrument) for p in nexts)
        require(own <= visited, 'Loop score has unreachable channel instructions')
    require(visited == set(starts), 'Loop score contains an unowned instruction')
    translation = dict(relocation=dict(sequence_base=0), instruction_map=rows,
        commands=[dict(output_header=0, channel_offsets=offsets)])
    resources = {'scores.bin': bytes(body)}
    return resources, translation, by_channel, dict(instructions=len(rows),
        successor_edges=edges, all_logical_operands_and_both_arms_in_own_channel=True,
        all_sounding_paths_initialize_instrument=True, virtual_header_not_played=True)


def layout(channels, *, score_base=0x40000, shard_bytes=DEFAULT_SHARD_BYTES,
           relay_bytes=DEFAULT_RELAY_BYTES):
    """Return (writes, resources, translation, mapping, bridges, report).

    All first shards precede continuation shards, keeping BE16 header seeds
    valid even when total source bytes exceed64KiB. Reserved cells hold native
    opcode22 chains. Only two-byte branch displacements can change in an
    original instruction. Inability to route inside populated ROM rejects.
    """
    require(type(score_base) is int and 0x40000 <= score_base < finite.LINEAR_BYTES,
            'Loop score base must be in added sound ROM')
    require(type(shard_bytes) is int and 4 <= shard_bytes <= DEFAULT_SHARD_BYTES and
            type(relay_bytes) is int and 6 <= relay_bytes <= DEFAULT_RELAY_BYTES,
            'Unqualified first-shard/header or relay budget')
    resources, translation, groups, logical = logical_score(channels)
    source = resources['scores.bin']; shards = []; per_channel = []
    for channel, rows in enumerate(groups):
        pieces = []; current = [] ; used = 0
        for row in rows:
            if used+row['output_bytes'] > shard_bytes:
                pieces.append(current); current = []; used = 0
            current.append(row); used += row['output_bytes']
        if current: pieces.append(current)
        per_channel.append(pieces)
    ordered = [(c, p[0]) for c, p in enumerate(per_channel) if p]
    ordered += [(c, part) for c, pieces in enumerate(per_channel) for part in pieces[1:]]
    mapping = {}; cursor = score_base+33; cells = set(); bridges = []
    for channel, rows in ordered:
        start = cursor
        for row in rows:
            mapping[row['output']] = cursor; cursor += row['output_bytes']
        pool = cursor; cells.update(range(pool, pool+relay_bytes-2, 3))
        cursor += relay_bytes
        shards.append(dict(channel=channel, start=start, instruction_end=pool,
            end=cursor, pool=pool, rows=rows))
    require(cursor <= finite.LINEAR_BYTES, 'Loop shards/relay pools exceed populated512KiB ROM')
    offsets = translation['commands'][0]['channel_offsets']; header = bytearray(33)
    for channel, offset in enumerate(offsets):
        if offset:
            value = mapping[offset]-score_base
            require(0 < value <= 65535, 'Loop installed header seed exceeds BE16')
            struct.pack_into('>H', header, 1+2*channel, value)
    # A broken fallthrough must land on an adjacent bridge, before its pool.
    for shard in shards:
        last = shard['rows'][-1]; pc = last['output']; op = source[pc]
        if op in (22, 23): continue
        target = pc+last['output_bytes']; at = shard['instruction_end']
        require(target in mapping, 'Loop shard has an open logical fallthrough')
        require(at in cells, 'Loop shard lacks its fallthrough cell')
        cells.remove(at)
        bridges.append(dict(address=at, target=mapping[target], kind='fallthrough_bridge',
                            source_group=last['source'], channel=shard['channel']))

    def route(origin_end, target, channel, source_group):
        """Monotone, bounded jump chains; each cell is consumed exactly once."""
        if -32768 <= target-origin_end <= 32767: return target
        forward = target > origin_end
        candidates = [c for c in cells if -32768 <= c-origin_end <= 32767 and
                      (origin_end < c < target if forward else target < c+3 < origin_end)]
        require(candidates, 'No populated native jump cell for loop branch')
        cell = max(candidates) if forward else min(candidates); cells.remove(cell)
        next_pc = route(cell+3, target, channel, source_group)
        bridges.append(dict(address=cell, target=next_pc, kind='long_branch_relay',
                            source_group=source_group, channel=channel))
        return cell

    # Resolve predeclared fallthroughs before branch edges, retaining adjacency.
    for bridge in list(bridges):
        bridge['target'] = route(bridge['address']+3, bridge['target'],
                                 bridge['channel'], bridge['source_group'])
    writes = [(score_base, bytes(header), 'music_header')]
    for row in translation['instruction_map']:
        pc = row['output']; physical = mapping[pc]; size = row['output_bytes']
        blob = bytearray(source[pc:pc+size]); op = blob[0]
        if 14 <= op <= 22:
            index = 1 if op == 22 else 2
            target = pc+size+struct.unpack_from('>h', blob, index)[0]
            landing = route(physical+size, mapping[target], row['channel'], row['source'])
            struct.pack_into('>h', blob, index, landing-(physical+size))
        writes.append((physical, bytes(blob), 'music_instruction_group'))
    for bridge in bridges:
        displacement = bridge['target']-bridge['address']-3
        require(-32768 <= displacement <= 32767, 'Loop jump cell displacement overflow')
        writes.append((bridge['address'], bytes([22])+struct.pack('>h', displacement), bridge['kind']))
    occupied = []
    for at, blob, name in sorted(writes):
        require(score_base <= at < at+len(blob) <= cursor, 'Loop write outside reserved extent')
        require(not occupied or occupied[-1][1] <= at, 'Loop writes or operands overlap')
        occupied.append((at, at+len(blob)))
    payload = bytearray(b'\xff'*finite.LINEAR_BYTES)
    for at, blob, name in writes: payload[at:at+len(blob)] = blob
    proof = prove_installed_graph(payload, resources, translation, {0:score_base}, mapping, bridges)
    # Every installed successor is an owned instruction or a declared jump.
    physical_starts = set(mapping.values()); jump_starts = {b['address'] for b in bridges}
    require(not physical_starts&jump_starts, 'Loop jump overlaps original instruction')
    for at in physical_starts|jump_starts:
        size = instruction_size(payload, at, True)
        require(score_base <= at < at+size <= cursor, 'Loop operand outside populated extent')
        require(all(p in physical_starts|jump_starts for p in successors(payload, at, True)),
                'Loop installed successor points at padding or operand')
    report = dict(schema=1, header=score_base, score_start=score_base, score_end=cursor,
        logical_score_sha256=digest(source), logical_bytes=len(source),
        logical_channel_offsets=offsets,
        physical_extent_bytes=cursor-score_base, populated_write_bytes=sum(len(b) for a,b,n in writes),
        bridge_bytes=3*len(bridges), remaining_bytes=finite.LINEAR_BYTES-cursor,
        channel_offsets=[int.from_bytes(header[1+2*i:3+2*i], 'big') for i in range(16)],
        instruction_map=[dict(logical=r['output'], physical=mapping[r['output']],
            bytes=r['output_bytes'], opcode=r['source_opcode'], channel=r['channel'])
            for r in translation['instruction_map']],
        bridges=bridges, extra_opcode_addresses=sorted(jump_starts),
        shards=[{k:v for k,v in s.items() if k != 'rows'} for s in shards],
        logical_graph=logical, installed_graph=proof,
        all_operands_both_branch_arms_fallthroughs_and_headers_populated=True,
        scalar_bytes_unchanged_except_branch_displacements=True,
        stock_body_redirects=[], new_driver_code=0, new_persistent_ram=0,
        native_playback_accepted=False, source_quality_policy_changed=False)
    return writes, resources, translation, mapping, bridges, report


