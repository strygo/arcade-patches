"""Pinned original score conversion functions; no checkout dependency."""
from __future__ import annotations
from collections import Counter
import upper_music_native as native

require = native.require


KEYOFF_KIND = 'keyoff'


def instrument_parameters(flat, articulations, index):
    require(index in articulations, f'Native articulation missing for instrument {index}')
    value = articulations[index]
    if isinstance(value, dict):
        articulation = bytes(value['articulation'])
        root = value.get('descriptor_root', 0x48)
        fine = value.get('fine', 0)
    else:
        articulation, root, fine = bytes(value), 0x48, 0
    require(fine == 0, 'Compact pitch policy requires zero instrument fine byte')
    return dict(articulation=list(articulation), descriptor_root=root, fine=fine,
                **native.articulation_parameters(flat, articulation))


def _compact_pitch(state, fixed):
    """Retain coarse/fine state; use any native key1..31 within its window."""
    require(isinstance(fixed, int) and 0 < fixed < 0x6c00, 'Native compact pitch bounds')
    high, low = divmod(fixed, 256)
    base = high+int(low >= 128)
    bend = low if low < 128 else low-256
    transpose = state['transpose']
    key = (base-transpose) & 255
    if not 1 <= key <= 31:
        transpose = max(0, base-16)
        key = base-transpose
    require(0 <= transpose <= 255 and 1 <= key <= 31, 'Native compact note window')
    out = bytearray()
    if transpose != state['transpose']:
        out.extend([11, transpose]); state['transpose'] = transpose
    if bend != state['bend']:
        out.extend([12, bend & 255]); state['bend'] = bend
    state['key'] = key; state['pitch_fixed'] = fixed
    return bytes(out), key


def _wait(state, ticks):
    out = native.wait_ticks(ticks)
    if ticks:
        # All compiler-produced sounding events leave bit7 clear. The wait
        # encoder ends in triplet mode unless it has a one-update remainder.
        state['flags'] = 0 if ticks & 1 else 32
    return out


def _note(state, *, retrigger, release_arm=False, release_onset=False, release_multiplier=128):
    require(state['key'] is not None, 'Native note emitted without a known pitch')
    out = bytearray()
    if release_arm or release_onset:
        if state['duration'] != release_multiplier:
            out.extend([6, release_multiplier]); state['duration'] = release_multiplier
        out.extend([4, 32 if release_onset else 160, 0x20 | state['key']])
        state['flags'] = 32
    else:
        if state['duration'] != 0:
            out.extend([6, 0]); state['duration'] = 0
        if not retrigger:
            out.extend([4, 128])
        elif state['flags'] & 0x60:
            out.extend([4, 0])
        # Dotted shortest sounding event has zero duration but occupies one
        # update. Bit6 is clear, so it leaves bit7 clear after the event.
        out.extend([2, 0x20 | state['key']]); state['flags'] = 0
    return bytes(out)


def compile_channel(flat, events, *, end_tick, instrument_bank, articulations,
                    instrument_map=None):
    """Encode absolute native tick events and exact release arming.

    Ordinary row fields match upper_music_native.compile_channel. Additionally
    kind='keyoff' denotes the exact native gate-expiry update, not a mute.
    Normally arms tick-1 with gate256, occupying tick-1 and tick. If controls
    occur at keyoff, arms tick-2 with gate510, which expires as sequence timer
    reaches zero; controls can then execute at the exact keyoff tick. This
    alternative rejects events at tick-1. A one-update gate uses the true
    onset itself. Bind short gates with onset_tick on the keyoff row.
    kind='note_off' remains an explicit gain-zero.
    Articulations map local instrument indices to8B records or metadata dicts.
    """
    native.resident_contract(flat)
    require(isinstance(end_tick, int) and end_tick >= 0, 'Native channel end tick')
    groups = {}; keyoffs = {}; release_owners = {}; plans = []
    for source in events:
        row = dict(source); tick = row.pop('tick')
        require(isinstance(tick, int) and 0 <= tick < end_tick, 'Score event outside native tick span')
        kind = row.pop('kind', None)
        if kind == KEYOFF_KIND:
            owner = row.pop('onset_tick', None)
            require(not row and tick > 0, 'Keyoff row must contain only tick, kind and optional onset_tick')
            if owner is not None:
                require(isinstance(owner, int) and 0 <= owner < tick, 'Zero/negative native gate span')
            require(tick not in keyoffs, 'Duplicate native keyoff update')
            keyoffs[tick] = owner; continue
        target = groups.setdefault(tick, {})
        require(not ('pitch_fixed' in target and 'pitch_fixed' in row), 'Two native pitch events in one update')
        if kind == 'note_off':
            target['volume'] = 0
        target.update(row)
    onset_ticks = sorted(t for t, row in groups.items() if 'pitch_fixed' in row and row.get('retrigger', True))
    for keyoff, owner in sorted(keyoffs.items()):
        expiry = groups.get(keyoff)
        require(not expiry or not ('pitch_fixed' in expiry and expiry.get('retrigger', True)),
                f'Native gate-release collision: new onset at gate-expiry update {keyoff}')
        offset, multiplier = (2, 255) if expiry is not None else (1, 128)
        arm_tick = keyoff-offset
        require(arm_tick >= 0, f'Native gate-release collision: no earlier arm for expiry control at {keyoff}')
        if offset == 2:
            require(keyoff-1 not in groups,
                    f'Native gate-release collision: score event at blocked update {keyoff-1}')
        arm = groups.setdefault(arm_tick, {})
        require(not arm.get('release_arm') and not arm.get('release_onset'), 'Overlapping native release arms')
        is_onset = 'pitch_fixed' in arm and arm.get('retrigger', True)
        if is_onset:
            require(owner == arm_tick or owner is None and onset_ticks and onset_ticks[0] == arm_tick,
                    f'Native gate-release collision: new onset at arm tick {arm_tick}; bind onset_tick for short gate')
            arm['release_onset'] = keyoff
        else:
            require(owner is None or owner in onset_ticks and owner < arm_tick,
                    'Native release owner has no earlier onset')
            arm['release_arm'] = keyoff
        arm['release_multiplier'] = multiplier
        release_owners[keyoff] = owner
        plans.append({'keyoff_tick': keyoff, 'onset_tick': owner, 'arm_tick': arm_tick,
                      'duration_multiplier': multiplier, 'timer_units': 512,
                      'gate_units': 512*multiplier//256,
                      'strategy': 'expiry_at_parse' if offset == 2 else 'expiry_inside_wait',
                      'timed_onset': is_onset,
                      'expiry_has_controls': expiry is not None})
    out = bytearray(native.channel_start(instrument_bank))
    state = dict(instrument=None, volume=0, pan=None, pitch_fixed=None,
                 transpose=0, bend=0, key=None, flags=0, duration=0, onset_tick=None)
    cursor = 0; counts = Counter(); timeline = []
    for tick, row in sorted(groups.items()):
        require(tick >= cursor, f'Native timed-note occupancy collision at tick {tick}')
        row = dict(row)
        if 'gain' in row:
            require('volume' not in row, 'Specify native volume or relative gain')
            row['volume'] = native.choose_volume(flat, row.pop('gain'))
        if 'instrument' in row and instrument_map is not None:
            row['instrument'] = instrument_map[row['instrument']]
        changes = {k: row[k] for k in ('instrument', 'volume', 'pan')
                   if k in row and row[k] != state[k]}
        sounding = ('pitch_fixed' in row and (row.get('retrigger', True) or
                                              row['pitch_fixed'] != state['pitch_fixed']))
        arm = row.get('release_arm'); timed_onset = row.get('release_onset')
        gain_flush = 'volume' in changes and not sounding and state['pitch_fixed'] is not None
        if not changes and not sounding and arm is None and timed_onset is None:
            continue
        if 'instrument' in changes:
            index = changes['instrument']
            require(0 <= index <= 127, 'Native instrument selector bounds')
            instrument_parameters(flat, articulations, index)
            require(sounding and row.get('retrigger', True) and arm is None,
                    'Native instrument change must coincide with an onset')
        if arm is not None:
            require(state['pitch_fixed'] is not None and state['instrument'] is not None and
                    state['onset_tick'] < tick,
                    'Native release arm requires an earlier sounding onset')
        out.extend(_wait(state, tick-cursor)); commands = bytearray()
        for key, value in changes.items():
            if key == 'instrument': commands.extend([8, value])
            elif key == 'volume': commands.extend(native.volume(value))
            else: commands.extend(native.pan(value))
            state[key] = value; counts[key] += 1
        note = sounding or gain_flush or arm is not None or timed_onset is not None
        reset = False
        if note:
            fixed = row['pitch_fixed'] if sounding else state['pitch_fixed']
            require(state['instrument'] is not None, 'Native sounding event lacks an instrument')
            native.resident_pitch_word(flat, fixed,
                instrument_parameters(flat, articulations, state['instrument'])['descriptor_root'])
            pitch, _ = _compact_pitch(state, fixed); commands.extend(pitch)
            reset = sounding and row.get('retrigger', True) and arm is None
            commands.extend(_note(state, retrigger=reset, release_arm=arm is not None,
                                  release_onset=timed_onset is not None,
                                  release_multiplier=row.get('release_multiplier', 128)))
            if reset:
                state['onset_tick'] = tick; counts['note_on'] += 1
                if timed_onset is not None: counts['one_update_gate_onset'] += 1
            elif arm is not None: counts['release_arm'] += 1
            elif gain_flush: counts['gain_flush'] += 1
            else: counts['held_pitch'] += 1
        else:
            commands.extend(_wait(state, 1))
        out.extend(commands); cursor = tick+(2 if arm is not None or timed_onset is not None else 1)
        timeline.append(dict(tick=tick, **changes, **(
            {'pitch_fixed': state['pitch_fixed'], 'retrigger': reset} if note else {}),
            **({'keyoff_tick': arm if arm is not None else timed_onset}
               if arm is not None or timed_onset is not None else {})))
    out.extend(_wait(state, end_tick-cursor)); out.extend([7, 0, 23])
    encoded = bytes(out)
    proof = decode_channel(flat, encoded, end_tick=end_tick, articulations=articulations)
    require(proof['terminal_tick'] == end_tick, 'Independent native terminal differs')
    for row in timeline:
        if 'pitch_fixed' not in row: continue
        observed = [r for r in proof['events'] if r['kind'] == 'note' and r['tick'] == row['tick']]
        require(len(observed) == 1 and observed[0]['pitch_fixed'] == row['pitch_fixed'] and
                observed[0]['reset'] == row['retrigger'], 'Independent compact native note differs')
    observed_releases = [r['tick'] for r in proof['events'] if r['kind'] == 'gate_expiry']
    require(observed_releases == sorted(keyoffs), 'Independent native gate-expiry timeline differs')
    for keyoff, owner in release_owners.items():
        if owner is None: continue
        previous = [r['tick'] for r in proof['events'] if r['kind'] == 'note' and r['reset'] and r['tick'] < keyoff]
        require(previous and previous[-1] == owner, 'Native keyoff owner was superseded by a later onset')
    return encoded, {'bytes': len(encoded), 'sha256': native.digest(encoded), 'end_tick': end_tick,
                     'emitted_events': dict(counts), 'timeline': timeline,
                     'gate_expiry_ticks': observed_releases,
                     'release_plans': plans,
                     'envelope_skip_ticks': proof['envelope_skip_ticks'],
                     'envelope_update_ticks': proof['envelope_update_ticks'],
                     'scheduler_update_ticks': proof['scheduler_update_ticks'],
                     'envelope_advance_ticks': proof['envelope_advance_ticks'],
                     'expected_gain_writer_ticks': proof['expected_gain_writer_ticks'],
                     'independent_proof': {'note_events': sum(r['kind'] == 'note' for r in proof['events']),
                                           'gate_expiry_ticks_equal': True, 'terminal_tick': end_tick}}


def _phase_step(level, phase, p):
    # This independently expresses the decoded1aa2..1b1c consumer branches,
    # rather than calling the frozen idealized native_envelope helper.
    if phase == 0:
        total = level+p['attack']
        return (65535, 1) if total > 65535 else (total, 0)
    if phase == 1:
        remaining = level-p['decay']
        if remaining < 0 or remaining <= p['sustain']:
            return p['sustain'], 3 if p['sustain'] else 5
        return remaining, 1
    if phase in (3, 4):
        remaining = level-p['sustain_rate' if phase == 3 else 'release']
        return (0, 5) if remaining <= 0 else (remaining, phase)
    require(phase in (2, 5), 'Native envelope phase outside resident table')
    return level, phase


def decode_channel(flat, score, *, end_tick, articulations):
    """Independent straight-line byte/timer/gate/envelope interpreter.

    Reads emitted opcodes, not compiler timeline/state. Models physical update
    versus note/rest early-return paths, including native gate-expiry ordering.
    Global/channel volume master and QSound FIR/DSP mixing are outside this
    scalar contract; amplitude_product is the volume*envelope high-word.
    """
    native.resident_contract(flat)
    pc = timer = gate = flags = transpose = fine_bend = duration = tempo = 0
    volume_index = dsp_product = level = 0; phase = 5; active = False
    index = None; parameters = None; fixed = None; pan = 16
    events = []; states = []; skipped = []; advanced = []; phase_advanced = []; instructions = []
    gain_writes = []
    stopped = False
    for tick in range(end_tick+1):
        path = 'parsed_rest'; reset = False; envelope_advanced = False
        if timer:
            require(tempo == 256, 'Native gate decoder requires exact tempo increment256')
            if gate:
                gate -= tempo
                if gate <= 0:
                    gate = 0
                    if phase != 5: phase = 4
                    events.append({'tick': tick, 'kind': 'gate_expiry', 'phase': phase})
            timer -= tempo
            require(timer >= 0, 'Unqualified negative native timer residual')
            if timer:
                if active:
                    advanced.append(tick)
                    # Phase2/5 dispatches jump directly2140, bypassing level
                    # arithmetic and DSP gain writer. A transition TO phase5
                    # via zero release still falls through1b19/1fcc that tick.
                    if phase not in (2, 5):
                        level, phase = _phase_step(level, phase, parameters)
                        envelope_advanced = True; phase_advanced.append(tick)
                        dsp_product = (native.u16(flat, 0x2e92+2*volume_index)*level) >> 16
                        gain_writes.append({'tick': tick, 'pc': 0x1fcc, 'path': 'timed_envelope',
                                            'amplitude_product': dsp_product})
                path = 'timed_envelope'
        if path != 'timed_envelope':
            for _ in range(10000):
                require(pc < len(score), 'Native gate score lacks terminal')
                at = pc; op = score[pc]; pc += 1
                if op >= 32:
                    table = 0x1230+(flags & 0x30)
                    timer += native.u16(flat, table+2*((op >> 5) & 7))
                    flags &= ~16
                    key = op & 31
                    instructions.append({'pc': at, 'opcode': op, 'bytes': 1})
                    if key:
                        require(parameters is not None, 'Decoded note lacks instrument parameters')
                        old = flags
                        fine = ((fine_bend+parameters['fine']+128) & 255)-128
                        fixed = (((key+flat[0x1260+(flags & 15)]+transpose) & 255)*256+fine) & 65535
                        if fixed >> 8 >= 108: fixed = 0x6b00+(fixed & 255)
                        word = native.resident_pitch_word(flat, fixed, parameters['descriptor_root'])
                        flags = (old & 127) | ((old & 64) << 1)
                        if not old & 64: gate = (timer*duration) >> 8
                        reset = not bool(old & 128)
                        if reset:
                            level, phase, active = parameters['attack'], 0, True
                        dsp_product = (native.u16(flat, 0x2e92+2*volume_index)*level) >> 16
                        path = 'sample_reset' if reset else 'held_note'
                        gain_writes.append({'tick': tick, 'pc': 0x1fcc, 'path': path,
                                            'amplitude_product': dsp_product})
                        events.append(dict(tick=tick, kind='note', pitch_fixed=fixed, native_word=word,
                            reset=reset, instrument=index, volume=volume_index, pan=pan,
                            timer=timer, gate=gate, phase=phase, level=level, flags_after=flags,
                            amplitude_product=dsp_product))
                    else:
                        path = 'parsed_rest'
                    if active: skipped.append(tick)
                    break
                require(op in (2, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 23, 24, 27, 31),
                        f'Unsupported independent gate opcode {op:02x}')
                if op == 2:
                    flags |= 16; instructions.append({'pc': at, 'opcode': op, 'bytes': 1}); continue
                if op == 23:
                    active = False; dsp_product = 0; stopped = True; path = 'terminal'
                    gain_writes.append({'tick': tick, 'pc': 0x0e9a, 'path': 'terminal',
                                        'amplitude_product': 0})
                    instructions.append({'pc': at, 'opcode': op, 'bytes': 1})
                    events.append({'tick': tick, 'kind': 'end'}); break
                require(pc < len(score), 'Truncated native gate opcode')
                arg = score[pc]; pc += 1
                size = 2
                if op == 4: flags = (flags & 0x97) | arg
                elif op == 5: tempo = native.u16(flat, 0x3492+arg*2)
                elif op == 6: duration = arg
                elif op == 7:
                    require(arg < 128, 'Native master-volume control is not qualified')
                    volume_index = arg
                    events.append({'tick': tick, 'kind': 'volume', 'volume': arg})
                elif op == 8:
                    index = arg; parameters = instrument_parameters(flat, articulations, index)
                    events.append({'tick': tick, 'kind': 'instrument', 'instrument': arg})
                elif op == 9: flags = (flags & 0xf0) | (arg & 15)
                elif op == 10: require(arg == 0, 'Gate decoder global transpose must be zero')
                elif op == 11: transpose = arg
                elif op == 12: fine_bend = arg
                elif op == 13: require(arg == 0, 'Gate decoder portamento must be zero')
                elif op == 24:
                    pan = arg; events.append({'tick': tick, 'kind': 'pan', 'pan': arg})
                elif op == 27:
                    require(pc < len(score) and arg < 3 and score[pc] == 0, 'Gate decoder LFO must be zero')
                    pc += 1; size = 3
                instructions.append({'pc': at, 'opcode': op, 'bytes': size})
            else:
                raise ValueError('Native gate controls did not yield an event')
        states.append(dict(tick=tick, path=path, timer=timer, gate=gate, flags=flags,
            level=level, phase=phase, instrument=index, pitch_fixed=fixed, volume=volume_index,
            pan=pan, amplitude_product=dsp_product, reset=reset, envelope_advanced=envelope_advanced))
        if stopped: break
    require(stopped and events[-1]['tick'] == end_tick, 'Native gate terminal bound differs')
    require(pc == len(score), 'Bytes remain after native gate terminal')
    return {'events': events, 'states': states, 'terminal_tick': events[-1]['tick'],
            'envelope_skip_ticks': skipped, 'envelope_update_ticks': advanced,
            'scheduler_update_ticks': advanced, 'envelope_advance_ticks': phase_advanced,
            'expected_gain_writer_ticks': gain_writes,
            'instructions': instructions, 'consumed_bytes': pc}


