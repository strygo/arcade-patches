"""Pinned original score conversion functions; no checkout dependency."""
from __future__ import annotations
from collections import Counter
from score_support import digest
from score_support import require
import struct

def bounded(data, at, size, role):
    require(0 <= at <= len(data)-size, role+' outside file bounds')
    return data[at:at+size]


def u32(data, at):
    return struct.unpack('<I', bounded(data, at, 4, '32-bit field'))[0]


def bank_header(data, magic):
    require(len(data) >= 20 and data[:4] == magic, 'Unexpected '+magic.decode()+' bank header')
    version, size = struct.unpack_from('<II', data, 4)
    require(version in (1, 2) and 20 <= size <= len(data), 'Upper bank version/declared length')
    require(all(v == 0xff for v in data[size:]), 'Unexpected padding beyond declared Upper bank length')
    trailer = 8 if version == 2 else 4
    require(data[size-4:size] == b'ENDB', 'Upper bank trailer marker')
    checksum = None
    if version == 2:
        checksum = u32(data, size-8)
        require(checksum == sum(data[4:size-8]) & 0xffffffff, 'Upper bank checksum differs')
    return {'magic': magic.decode(), 'version': version, 'declared_bytes': size,
            'file_bytes': len(data), 'sha256': digest(data), 'checksum': checksum,
            'payload_end': size-trailer}


def sequence_bank(data):
    header = bank_header(data, b'SMSB')
    count = u32(data, 12)
    require(0 < count <= 256 and 16+count*4 <= header['payload_end'], 'SMSB sequence directory')
    pointers = [u32(data, 16+n*4) for n in range(count)]
    present = sorted(set(p for p in pointers if p))
    require(all(16+count*4 <= p < header['payload_end'] for p in present), 'SMSB sequence pointer bounds')
    rows = []
    for index, pointer in enumerate(pointers):
        if not pointer:
            rows.append({'sequence_index': index, 'present': False})
            continue
        end = next((p for p in present if p > pointer), header['payload_end'])
        blob = bounded(data, pointer, end-pointer, 'SMSD sequence')
        require(len(blob) >= 13 and blob[:4] == b'SMSD', 'SMSD sequence header')
        # SMSD timing header is little endian in the canonical Upper files;
        # multi-byte event payloads below use big endian.
        tpqn, tempo = struct.unpack_from('<II', blob, 4)
        require(tpqn > 0 and tempo > 0, 'SMSD timing fields')
        rows.append({'sequence_index': index, 'present': True, 'offset': pointer,
                     'bytes': len(blob), 'sha256': digest(blob),
                     'tick_fraction': tpqn, 'initial_milliseconds_per_quarter': tempo})
    return header | {'sequence_count': count, 'sequences': rows}


def program_bank(data):
    """Measure program/layer/split/sample extents without decoding AICA audio."""
    header = bank_header(data, b'SMPB')
    require(header['version'] == 2, 'Only measured Upper SMPB version two is supported')
    limit = header['payload_end']
    table, count, velocity_at, velocity_count = struct.unpack('<4I', bounded(data, 16, 16, 'SMPB directory'))
    require(0 < count <= 128 and 48 <= table <= limit-count*4, 'SMPB program directory bounds')
    require(0 < velocity_count <= 128 and 48 <= velocity_at <= limit-velocity_count*128,
            'SMPB velocity directory bounds')
    rows = []
    samples = {}
    for program in range(count):
        at = u32(data, table+program*4)
        require(48 <= at <= limit-16, 'SMPB program pointer bounds')
        layers = []
        for layer in range(4):
            layer_at = u32(data, at+layer*4)
            if not layer_at:
                continue
            require(48 <= layer_at <= limit-16, 'SMPB layer pointer bounds')
            splits, split_at = struct.unpack_from('<II', data, layer_at)
            require(0 < splits <= 128 and 48 <= split_at <= limit-splits*48,
                    'SMPB split array bounds')
            split_rows = []
            for split in range(splits):
                record = bounded(data, split_at+split*48, 48, 'SMPB split record')
                jump, flags = record[:2]
                low, loop_start, loop_end = struct.unpack_from('<3H', record, 2)
                sample_at = ((jump & 127) << 16)+low
                fmt = 'aica_adpcm4' if flags & 1 else 'pcm8' if jump & 128 else 'pcm16'
                bits = 4 if flags & 1 else 8 if jump & 128 else 16
                sample_bytes = (loop_end*bits+7)//8
                require(loop_start <= loop_end and 0 < sample_at <= limit-sample_bytes,
                        'SMPB sample pointer/loop extent bounds')
                require(record[36] <= record[37] <= 127 and record[38] <= 127,
                        'SMPB note split bounds')
                require(record[42] < velocity_count and record[43] <= record[44] <= 127,
                        'SMPB velocity split bounds')
                pitch = struct.unpack_from('<H', record, 12)[0]
                row = {'split_index': split, 'record_offset': split_at+split*48,
                    'sample_offset': sample_at, 'sample_bytes': sample_bytes,
                    'sample_frames': loop_end, 'format': fmt, 'loop_enabled': bool(flags & 2),
                    'loop_start': loop_start, 'loop_end': loop_end,
                    'key_low': record[36], 'key_high': record[37], 'base_key': record[38],
                    'fine_tune_raw': struct.unpack_from('<b', record, 39)[0],
                    'pitch_register': pitch, 'envelope_register': u32(record, 8),
                    'lfo_register': struct.unpack_from('<H', record, 14)[0],
                    'filter_enabled': not bool(record[20] & 32),
                    'record_sha256': digest(record)}
                split_rows.append(row)
                if sample_at in samples:
                    require(samples[sample_at]['format'] == fmt, 'Aliased Upper sample uses different formats')
                    samples[sample_at]['bytes'] = max(sample_bytes, samples[sample_at]['bytes'])
                else:
                    samples[sample_at] = {'offset': sample_at, 'bytes': sample_bytes, 'format': fmt}
            layers.append({'layer_index': layer, 'offset': layer_at,
                           'delay_ticks': struct.unpack_from('<H', data, layer_at+8)[0],
                           'bend_range_high': data[layer_at+12], 'bend_range_low': data[layer_at+13],
                           'splits': split_rows})
        rows.append({'program_index': program, 'offset': at, 'layers': layers})
    for sample in samples.values():
        sample['sha256'] = digest(bounded(data, sample['offset'], sample['bytes'], 'SMPB sample'))
    formats = Counter(r['format'] for r in samples.values())
    return header | {'program_count': count, 'nonempty_program_count': sum(bool(r['layers']) for r in rows),
        'velocity_curve_count': velocity_count, 'programs': rows,
        'unique_samples': sorted(samples.values(), key=lambda r: r['offset']),
        'sample_format_counts': dict(sorted(formats.items())),
        'unique_sample_bytes': sum(s['bytes'] for s in samples.values())}


def sequence_events(data):
    """Bound the physical SMSD event stream, retaining references and loops.

    Reference expansion and loop execution are deliberately separate: a linear
    event inventory must not masquerade as a complete performed score.
    """
    require(data[:4] == b'SMSD' and len(data) >= 13, 'SMSD event source header')
    at = 12
    rows = []
    while at < len(data):
        if data[at:at+4] == b'ENDD':
            require(not any(data[at+4:]), 'Unexpected data after SMSD footer')
            return {'events': rows, 'termination': 'ENDD', 'performed_score_expanded': False}
        opcode = data[at]; row = {'offset': at, 'opcode': opcode}; step = 0
        if opcode < 128:
            gate_bytes = (opcode >> 5)+1
            step_bytes = 2 if opcode & 16 else 1
            size = 3+gate_bytes+step_bytes
            record = bounded(data, at, size, 'SMSD note')
            require(record[1] <= 127 and record[2] <= 127, 'SMSD note key/velocity')
            row |= {'kind': 'note', 'channel': opcode & 15, 'key': record[1], 'velocity': record[2],
                    'gate_ticks': int.from_bytes(record[3:3+gate_bytes], 'big')}
            step = int.from_bytes(record[3+gate_bytes:], 'big')
        elif opcode == 0x81:
            record = bounded(data, at, 4, 'SMSD reference'); size = 4
            target = int.from_bytes(record[1:3], 'big')
            row |= {'kind': 'reference', 'target_offset': target, 'event_count': record[3]}
            require(12 <= target < len(data), 'SMSD reference target bounds')
        elif opcode == 0x82:
            mode = bounded(data, at+1, 1, 'SMSD loop mode')[0]
            size = 4 if mode & 128 else 3
            record = bounded(data, at, size, 'SMSD loop')
            row |= {'kind': 'loop', 'mode': mode & 127}; step = int.from_bytes(record[2:], 'big')
        elif opcode == 0x83:
            size = 1; row |= {'kind': 'end'}
        elif opcode == 0x84:
            record = bounded(data, at, 4, 'SMSD tempo'); size = 4
            row |= {'kind': 'tempo', 'milliseconds_per_quarter': int.from_bytes(record[1:3], 'big')}
            step = record[3]
        elif 0x88 <= opcode <= 0x8f:
            size = 1; row |= {'kind': 'gate_extend' if opcode < 0x8c else 'step_extend'}
        elif 0xa0 <= opcode <= 0xef:
            arg = bounded(data, at+1, 1, 'SMSD control argument')[0]
            step_bytes = 2 if arg & 128 else 1
            family = opcode >> 4
            size = (3 if family in (0xa, 0xb) else 2)+step_bytes
            record = bounded(data, at, size, 'SMSD channel event')
            row |= {'kind': {10: 'poly_pressure', 11: 'control', 12: 'program',
                            13: 'pressure', 14: 'pitch'}[family],
                    'channel': opcode & 15, 'argument': arg & 127}
            if family in (10, 11): row['value'] = record[2]
            step = int.from_bytes(record[-step_bytes:], 'big')
        else:
            raise ValueError(f'Unqualified SMSD opcode {opcode:02x} at {at:x}')
        row |= {'bytes': size, 'step_ticks': step}
        rows.append(row); at += size
        if opcode == 0x83:
            require(data[-4:] == b'ENDD' and len(data)-4-at <= 3 and
                    not any(data[at:-4]), 'SMSD end marker/padding/footer')
            return {'events': rows, 'termination': '83_then_ENDD',
                    'performed_score_expanded': False}
    raise ValueError('SMSD stream lacks ENDD footer')


