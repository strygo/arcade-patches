"""Pinned original score conversion functions; no checkout dependency."""
from __future__ import annotations
from score_support import require

def instruction_size(data, pc, newer):
    """Instruction extent from the pinned reader, including its exceptions."""
    op = data[pc]
    if op >= 0x20 or op <= 3 or op == 0x17:
        size = 1
    elif 0x0e <= op <= 0x15:
        size = 4
    elif op == 0x16 or (op == 5 and not newer) or (op == 0x1c and newer):
        size = 3
    elif op == 0x1b and newer:
        require(pc + 3 <= len(data) and data[pc+1] <= 3,
                'Unknown extended sequence instruction')
        size = 3
    else:
        size = 2
    require(pc + size <= len(data), 'Truncated sequence instruction')
    return size


