"""Pinned original score conversion functions; no checkout dependency."""
from __future__ import annotations
from collections import Counter
import upper_music_gate_encoding as gate
import upper_music_native as native

require = native.require


MODES = (0, 32)


def source_contract(flat):
    contract = native.resident_contract(flat)
    require(flat[0x12dc:0x12e7] == bytes.fromhex('3e20ddae04dd7704c37612'),
            'Native opcode00 flag-toggle consumer changed')
    return {'resident_contract': contract, 'toggle_instruction_range': [0x12dc, 0x12e7],
            'toggle_consumer_sha256': native.digest(flat[0x12dc:0x12e7]),
            'toggle_effect': 'opcode00 XORs flag bit5; all other flag bits preserved',
            'new_driver_bytes': 0, 'new_persistent_ram_bytes': 0}


def duration_catalog(flat):
    out = [{'ticks': 1, 'mode': 0, 'dotted': True, 'index': 1}]
    for mode, dotted, at in ((0, False, 0x1230), (0, True, 0x1240), (32, False, 0x1250)):
        for index in range(1, 8):
            value = native.u16(flat, at+2*index)
            if not value: continue
            require(value % 256 == 0, 'Native duration has noninteger exact-clock units')
            out.append({'ticks': value//256, 'mode': mode, 'dotted': dotted, 'index': index})
    return sorted(out, key=lambda r: (-r['ticks'], r['mode'], r['dotted'], r['index']))


def add_cost(*values):
    return tuple(sum(v[i] for v in values) for i in range(3))


class WaitPlanner:
    """Exact shortest-byte waits; ties prefer fewer rests and toggles."""
    def __init__(self, flat):
        source_contract(flat); self.catalog = duration_catalog(flat)
        self.costs = {}; self.choices = {}; self.maximum = 0
        for start in MODES:
            for finish in MODES:
                self.costs[start, finish] = [(int(start != finish), 0, int(start != finish))]
                self.choices[start, finish] = [None]

    def grow(self, maximum):
        for ticks in range(self.maximum+1, maximum+1):
            for start in MODES:
                for finish in MODES:
                    best = choice = None
                    for record in self.catalog:
                        if record['ticks'] > ticks: continue
                        toggle = int(start != record['mode'])
                        size = 1+int(record['dotted'])+toggle
                        suffix = self.costs[record['mode'], finish][ticks-record['ticks']]
                        total = add_cost((size, 1, toggle), suffix)
                        if best is None or total < best:
                            best, choice = total, record
                    require(best is not None, 'Native wait has no exact representation')
                    self.costs[start, finish].append(best)
                    self.choices[start, finish].append(choice)
        self.maximum = max(self.maximum, maximum)

    def cost(self, ticks, start, finish):
        require(isinstance(ticks, int) and ticks >= 0 and start in MODES and finish in MODES,
                'Native wait planner operands')
        self.grow(ticks)
        return self.costs[start, finish][ticks]

    def encode(self, ticks, start, finish=None):
        self.grow(ticks)
        if finish is None:
            finish = min(MODES, key=lambda mode: (self.costs[start, mode][ticks], mode))
        expected = self.cost(ticks, start, finish); out = bytearray()
        remaining, mode = ticks, start
        while remaining:
            record = self.choices[mode, finish][remaining]
            if mode != record['mode']: out.append(0)
            if record['dotted']: out.append(2)
            out.append(record['index'] << 5)
            mode = record['mode']; remaining -= record['ticks']
        if mode != finish: out.append(0)
        require(len(out) == expected[0], 'Native shortest-wait byte accounting')
        return bytes(out), finish, expected


def _sounding(record, key, reset, start_mode):
    mode = record['mode']; out = bytearray()
    if not reset:
        out.extend([4, 128 | mode])
    elif mode != start_mode:
        out.append(0)
    if record['dotted']: out.append(2)
    out.append((record['index'] << 5) | key)
    return bytes(out), mode


def _meaningful_events(proof):
    result = []
    for row in proof['events']:
        kind = row['kind']
        if kind == 'note':
            result.append((row['tick'], kind, row['pitch_fixed'], row['reset'], row['instrument'], row['volume'], row['pan']))
        elif kind in ('volume', 'instrument', 'pan'):
            result.append((row['tick'], kind, row[kind]))
        elif kind == 'gate_expiry': result.append((row['tick'], kind))
        elif kind == 'end': result.append((row['tick'], kind))
    return result


def compile_channel(flat, events, *, end_tick, instrument_bank, articulations,
                    instrument_map=None):
    """Strict-gate validation followed by minimum-size event/delay packing."""
    source_contract(flat)
    baseline, original = gate.compile_channel(flat, events, end_tick=end_tick,
        instrument_bank=instrument_bank, articulations=articulations, instrument_map=instrument_map)
    before = gate.decode_channel(flat, baseline, end_tick=end_tick, articulations=articulations)
    planner = WaitPlanner(flat); timeline = original['timeline']
    plans = {r['arm_tick']: r for r in original['release_plans']}
    state = dict(transpose=0, bend=0, key=None, pitch_fixed=None)
    duration = 0; infos = []
    for index, row in enumerate(timeline):
        prefix = bytearray()
        for field in ('instrument', 'volume', 'pan'):
            if field not in row: continue
            value = row[field]
            if field == 'instrument': prefix.extend([8, value])
            elif field == 'volume': prefix.extend(native.volume(value))
            else: prefix.extend(native.pan(value))
        sounding = 'pitch_fixed' in row
        if sounding:
            pitch, key = gate._compact_pitch(state, row['pitch_fixed']); prefix.extend(pitch)
        else: key = None
        plan = plans.get(row['tick'])
        desired_duration = plan['duration_multiplier'] if plan is not None else 0
        if sounding and desired_duration != duration:
            prefix.extend([6, desired_duration]); duration = desired_duration
        following = timeline[index+1]['tick'] if index+1 < len(timeline) else end_tick
        gap = following-row['tick']
        require(gap >= (2 if plan is not None else 1), 'Native packed event occupancy')
        infos.append(dict(row=row, prefix=bytes(prefix), key=key, plan=plan, gap=gap))
    # Backward two-state DP includes the successor's flag cost. Pitch and gate
    # multiplier states are fixed by requested events; only normal/triplet mode
    # and the chosen existing note duration vary.
    costs = [{mode: (0, 0, 0) for mode in MODES} for _ in range(len(infos)+1)]
    choices = [{} for _ in infos]
    for index in range(len(infos)-1, -1, -1):
        info = infos[index]; row, plan, gap = info['row'], info['plan'], info['gap']
        for start_mode in MODES:
            best = chosen = None
            if info['key'] is None:
                variants = [(None, b'', start_mode, 0)]
            elif plan is not None:
                raw = bytes([4, 32 if row['retrigger'] else 160, 0x20 | info['key']])
                variants = [(None, raw, 32, 2)]
            else:
                variants = []
                for record in planner.catalog:
                    if record['ticks'] > gap: continue
                    raw, mode = _sounding(record, info['key'], row['retrigger'], start_mode)
                    variants.append((record, raw, mode, record['ticks']))
            for record, raw, mode, elapsed in variants:
                for finish_mode in MODES:
                    wait_cost = planner.cost(gap-elapsed, mode, finish_mode)
                    event_cost = (len(info['prefix'])+len(raw), 0,
                                  int(bool(raw) and raw[0] == 0))
                    total = add_cost(event_cost, wait_cost, costs[index+1][finish_mode])
                    if best is None or total < best:
                        best = total
                        chosen = dict(record=record, event=raw, event_mode=mode, elapsed=elapsed,
                                      finish_mode=finish_mode)
            costs[index][start_mode] = best; choices[index][start_mode] = chosen
    first_tick = timeline[0]['tick'] if timeline else end_tick
    start_mode = min(MODES, key=lambda m: (add_cost(planner.cost(first_tick, 0, m), costs[0][m]), m))
    prefix_wait, _, _ = planner.encode(first_tick, 0, start_mode)
    out = bytearray(native.channel_start(instrument_bank)); out.extend(prefix_wait)
    selected = []; counts = Counter(); mode = start_mode
    for index, info in enumerate(infos):
        choice = choices[index][mode]
        wait, finish, _ = planner.encode(info['gap']-choice['elapsed'], choice['event_mode'], choice['finish_mode'])
        out.extend(info['prefix']); out.extend(choice['event']); out.extend(wait)
        mode = finish
        selected.append({'tick': info['row']['tick'], 'event_duration_ticks': choice['elapsed'],
                         'following_gap_ticks': info['gap'], 'release_arm': info['plan'] is not None,
                         'sounding': info['key'] is not None})
        if info['key'] is not None and info['plan'] is None:
            counts['packed_timed_note' if choice['elapsed'] > 1 else 'one_update_note'] += 1
    out.extend([7, 0, 23]); encoded = bytes(out)
    after = decode_channel(flat, encoded, end_tick=end_tick, articulations=articulations)
    require(_meaningful_events(before) == _meaningful_events(after),
            'Packed native event/reset/control/gate timestamps differ')
    actual_counts = Counter(r['opcode'] for r in after['instructions'])
    return encoded, {'bytes': len(encoded), 'sha256': native.digest(encoded), 'end_tick': end_tick,
        'unpacked_bytes': len(baseline), 'saved_bytes': len(baseline)-len(encoded),
        'unpacked_sha256': native.digest(baseline), 'event_timelines_equal': True,
        'meaningful_event_count': len(_meaningful_events(after)),
        'release_plans': original['release_plans'], 'gate_expiry_ticks': original['gate_expiry_ticks'],
        'selected_event_durations': selected, 'packing_counts': dict(counts),
        'emitted_events': original['emitted_events'],
        'opcode_counts': {str(k): v for k, v in sorted(actual_counts.items())},
        'scheduler_update_ticks': after['scheduler_update_ticks'],
        'envelope_update_ticks': after['scheduler_update_ticks'],
        'envelope_skip_ticks': after['envelope_skip_ticks'],
        'envelope_advance_ticks': after['envelope_advance_ticks'],
        'expected_gain_writer_ticks': after['expected_gain_writer_ticks'],
        'envelope_trajectory_inherited': False,
        'timeline': original['timeline'],
        'independent_proof': {'note_events': sum(r['kind'] == 'note' for r in after['events']),
                              'gate_expiry_ticks_equal': True, 'terminal_tick': end_tick,
                              'meaningful_events_equal': True}}


def _expanded_toggles(score):
    """Independent literal grammar and exact00-to04 flag transformation."""
    pc = 0; flags = 0; expanded = bytearray(); mapping = {}; originals = {}
    while pc < len(score):
        at = pc; op = score[pc]; pc += 1
        size = 1 if op >= 32 or op in (0, 2, 23) else 3 if op == 27 else 2
        require(op >= 32 or op in (0, 2, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 23, 24, 27, 31),
                f'Unqualified packed native opcode {op:02x}')
        require(at+size <= len(score), 'Truncated packed native instruction')
        raw = score[at:at+size]; pc = at+size
        mapping[len(expanded)] = at; originals[at] = dict(pc=at, opcode=op, bytes=size)
        if op == 0:
            flags ^= 32
            #04 preserves bits0..2,4,7 and accepts replacement bits3,5,6.
            expanded.extend([4, flags & 0x68])
        else:
            expanded.extend(raw)
            if op == 2: flags |= 16
            elif op == 4: flags = (flags & 0x97) | raw[1]
            elif op == 9: flags = (flags & 0xf0) | (raw[1] & 15)
            elif op >= 32:
                flags &= ~16
                if op & 31: flags = (flags & 127) | ((flags & 64) << 1)
    return bytes(expanded), mapping, originals


def decode_channel(flat, score, *, end_tick, articulations):
    source_contract(flat)
    expanded, mapping, originals = _expanded_toggles(score)
    proof = gate.decode_channel(flat, expanded, end_tick=end_tick, articulations=articulations)
    proof['instructions'] = [originals[mapping[row['pc']]] for row in proof['instructions']]
    proof['consumed_bytes'] = len(score)
    proof['toggle_expansion_bytes'] = len(expanded)-len(score)
    return proof


