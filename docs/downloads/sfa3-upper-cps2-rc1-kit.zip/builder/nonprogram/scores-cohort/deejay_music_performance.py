"""Pinned original score conversion functions; no checkout dependency."""
from __future__ import annotations
from score_support import digest
from score_support import require
from types import FunctionType
import struct

def reset_contract(driver):
    require(digest(driver)=='509589f6b96de2103dc4ba1c6196f636b37450f961d92dcdd947af04f87e4c56',
        'Original Dee Manatee driver changed')
    body=driver[32:]
    # Controller dispatch: add pc+4 (2188), then controller*4. CC121's
    # branch reaches32b0; the initial stores fall through3350's voice loop.
    require(body[0x236c:0x2370]==bytes.fromhex('cf0300ea'),'Original CC121 branch changed')
    require(digest(body[0x32b0:0x3350])=='3eb4b748c096f873bb68df5de314ff67b192a1bb2bca2a605ff017b9aa93215d',
        'Original reset defaults changed')
    # Execute the complete straight-line store prefix, rejecting every other
    # instruction. This is not an ARM emulator or a replacement driver.
    registers={};writes={}
    for at in range(0x32b0,0x3350,4):
        op=struct.unpack_from('<I',body,at)[0]
        if op&0xfffff000==0xe3a01000:registers[1]=op&255
        elif op&0xfffff000 in(0xe5c51000,0xe5851000):
            size=1 if op&0x400000 else 4;offset=op&4095
            for n,value in enumerate(registers[1].to_bytes(size,'little')):writes[offset+n]=value
        else:raise ValueError('Unknown instruction in pinned reset prefix: '+hex(at))
    require([writes[n]for n in(8,9,10,11)]==[100,127,100,64]and
        all(writes[n]==0 for n in range(4,8)), 'Original volume/expression/pan/centered bend defaults differ')
    # This continuation clears deferred sustain flags. Released voices get a
    # key-off, not a new onset; held voices take the skip branch at339c. The
    # score-specific check below proves that no held note crosses a reset.
    expected={0x3390:0xe3c99060,0x3398:0xe3190080,0x339c:0x1a000008,
        0x33a4:0xe586903c,0x33a8:0xe5869038,0x33b8:0xe3c99901,
        0x33bc:0xe3899902,0x33c0:0xe5889000,0x33d4:0xe1a0f00e}
    require(all(struct.unpack_from('<I',body,at)[0]==op for at,op in expected.items()),
        'Original reset release/held-voice continuation changed')
    return {'driver_sha256':digest(driver),'dispatch':0x236c,'handler':0x32b0,
        'defaults_sha256':digest(body[0x32b0:0x3350]),'release_handler_sha256':digest(body[0x3350:0x33d8]),
        'defaults':{'volume':100,'expression':127,'pan':64,'centered_bend':0},
        'new_note_onsets':0,'new_driver_or_runtime_bytes':0}


def perform(score,driver,performance,loop_passes=3):
    contract=reset_contract(driver);resets=[]
    def bounded_require(condition,message):
        if not condition and message=='Unqualified non-initial controller reset':
            resets.append(message)
        else:require(condition,message)
    expanded=FunctionType(performance.perform.__code__,
        dict(performance.perform.__globals__,require=bounded_require),
        argdefs=performance.perform.__defaults__)(score,loop_passes=loop_passes)
    events=expanded['timeline'];notes=expanded['notes'];cases=[]
    for row in events:
        if row['kind']!='control'or row['argument']!=121:continue
        now=row['time_fixed'];channel=row['channel'];index=row['performed_index']
        prior=[n for n in notes if n['channel']==channel and n['performed_index']<index]
        held=[n for n in prior if n['time_fixed']+n['gate_fixed']>now]
        require(not held,'Reset intersects a held source note')
        following=[e for e in events if e.get('channel')==channel and e['performed_index']>index]
        first=next((n for n,e in enumerate(following)if e['kind']=='note'),None)
        require(first is not None,'Reset has no subsequent note within the bounded song')
        setup=following[:first];next_note=following[first]
        controls={e['argument']:e['value']for e in setup if e['kind']=='control'}
        require(all(k in controls for k in(1,7,10,11,32))and controls[1]==0 and controls[32]==1 and
            any(e['kind']=='program'for e in setup),'Reset default would reach a note without explicit source setup')
        cases.append({'channel':channel,'time_fixed':now,'loop_iteration':row['loop_iteration'],
            'held_notes':0,'next_note_time_fixed':next_note['time_fixed'],
            'explicit_onset_controls':controls,'explicit_program':True,
            'explicit_bend':any(e['kind']=='pitch'for e in setup),
            'last_prior_gate_end_fixed':max((n['time_fixed']+n['gate_fixed']for n in prior),default=0)})
    require(len(resets)==11*(loop_passes-1)and len(cases)==17+11*(loop_passes-1),
        'Dee reset domain changed')
    require(expanded['summary']['loop_nominal_seconds']==78.2202041015625 and
        expanded['summary']['performed_notes']==2403*loop_passes,'Dee score/reset chronology changed')
    return expanded,{'passed':True,'scope':'Dee BGM32 only; explicit setup and no held notes at every reset',
        'driver':contract,'score_sha256':digest(score),'initial_resets':17,'repeated_resets':len(resets),
        'cases':cases,'held_voice_cuts':0,'live_gain_or_pitch_reset_invented':False,
        'source_scheduler_or_AICA_hardware_accepted':False}


