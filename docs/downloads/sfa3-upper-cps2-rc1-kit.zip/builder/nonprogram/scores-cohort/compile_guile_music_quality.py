"""Pinned original score conversion functions; no checkout dependency."""
from __future__ import annotations
from score_support import require
import numpy as np

RESIDUAL_PASSES = 4


RESIDUAL_MAX_GAIN_ERROR = 0.04


def spans(resources, slot, cut, steady):
    """Bind each section to original same-run voice observations."""
    output = []
    if steady:
        offset = resources['rotated'][slot]['cut_relative_to_source_global_boundary_tick']
        rows = [r for r in resources['parts'][1] if r['slot'] == slot]
        records = [(r, r['onset_tick']-offset, r['end_tick']-offset) for r in rows]
    else:
        rows = [r for r in resources['rows'] if r['slot'] == slot and r['onset_tick'] < cut]
        records = [(r, r['onset_tick'], min(r['end_tick'], cut)) for r in rows]
    for row, first, last in records:
        require(0 <= first < last <= cut, 'Source voice crosses its qualified section')
        observation = resources['observations'][row['voice_index']]
        nominal = []; value = None; controls = iter(observation['controls'])
        pending = next(controls, None)
        origin = observation['first_tick']
        for tick in range(origin, origin+last-first):
            while pending is not None and pending['tick'] <= tick:
                value = pending.get('volume', value)
                pending = next(controls, None)
            require(value is not None, 'Original onset has no channel gain')
            nominal.append(value)
        output.append({'first':first, 'last':last, 'profile':row['profile_id'],
                       'voice':row['voice_index'], 'nominal':np.array(nominal),
                       'observation':observation})
    return output


def eligible(events):
    """Leave enough native parser occupancy for exact positive gate expiry."""
    controls = {e['tick'] for e in events if e.get('kind') != 'keyoff'}
    blocked = set()
    for event in events:
        if event.get('kind') != 'keyoff':
            continue
        gate, onset = event['tick'], event['onset_tick']
        # A control at expiry uses the existing two-update arm. Otherwise the
        # original one-update arm remains; never displace the actual keyoff.
        if gate-onset >= 2 and gate-1 not in controls:
            blocked.add(gate-1)
        else:
            require(gate not in controls, 'Unqualified short-gate expiry control')
            blocked.add(gate)
    return blocked


def residual_controls_for(events, voices, selected, words, current, baseline, before):
    """Correct fitted native envelopes through ordinary held-note gain writes.

    Inserting a native gain flush suppresses that update's envelope advance.
    Use the preceding decoded level at that insertion, then compile/decode
    the whole section again. Original onset and positive gate owners remain
    with the existing compiler; the correction never adds a sample reset.
    """
    result = [dict(e) for e in events]
    groups = {e['tick']:e for e in result if e.get('kind') != 'keyoff'}
    blocked = eligible(events); count = skipped = infeasible = 0
    for voice in voices:
        if voice['profile'] not in selected:
            continue
        first, last = voice['first'], voice['last']; n = last-first
        own = voice['observation']; nominal = words[voice['nominal']]
        desired = np.divide(own['target_first_moment'][:n], own['weight'][:n],
            out=own['y'][:n].copy(), where=own['weight'][:n] != 0)
        source = own['y'][:n]
        base = np.array([s['amplitude_product'] for s in baseline['states'][first:last]])
        base = np.divide(base, nominal, out=np.zeros(n), where=nominal != 0)
        peak = float(np.max(np.abs(base-source)))
        tolerance = min(RESIDUAL_MAX_GAIN_ERROR,
                        before[str(voice['profile'])]['weighted_relative_rms']/2)
        previous = None
        for i in range(n):
            tick = first+i
            if tick in blocked:
                skipped += 1
                continue
            row = groups.get(tick); state = current['states'][tick]
            held_level = state['level']
            onset = row is not None and 'pitch_fixed' in row and row.get('retrigger', True)
            if not onset and state['envelope_advanced'] and tick:
                held_level = current['states'][tick-1]['level']
            candidates = (words.astype(np.int64)*held_level) >> 16
            candidates = candidates/nominal[i] if nominal[i] else np.zeros(128)
            allowed = np.abs(candidates-source[i]) <= peak+1e-12
            if not np.any(allowed):
                infeasible += 1
                chosen = int(np.abs(candidates-source[i]).argmin())
            else:
                losses = np.abs(candidates-desired[i])
                chosen = int(np.where(allowed, losses, np.inf).argmin())
            held = ((int(words[previous])*state['level']) >> 16)/nominal[i] \
                if previous is not None and nominal[i] else 0.
            original_gain = row is not None and 'volume' in row
            needs_change = previous is None or original_gain or \
                abs(held-desired[i]) > tolerance or abs(held-source[i]) > peak+1e-12
            if needs_change:
                if row is None:
                    row = {'tick':tick}; result.append(row); groups[tick] = row
                    count += 1
                row['volume'] = chosen
                previous = chosen
    return sorted(result, key=lambda r:r['tick']), count, skipped, infeasible


def refine_encoded_gain(flat, data, model, voices, selected, words, before, end, arts, packed,
                        fit_all_profiles=False):
    """Fit actual native gain-write hold intervals without changing chronology.

    Volume07 operands affect the following actual DSP writes. Bypassed writes
    retain their preceding product and owner. Bind every source observation
    to that decoded ownership before choosing a selector; never pretend that
    a control alone publishes a new DSP gain or advances the envelope.
    """
    controls = [e for e in model['events'] if e['kind'] == 'volume']
    instructions = [r for r in model['instructions'] if r['opcode'] == 7]
    require(len(controls) == len(instructions), 'Decoded volume instruction/event owners differ')
    demands = {}
    for voice in voices:
        own = voice['observation']; n = voice['last']-voice['first']
        for i in range(n):
            tick = voice['first']+i
            require(tick not in demands, 'Source gain ownership overlaps a channel voice')
            demands[tick] = (voice['profile'], int(words[voice['nominal'][i]]), own['y'][i],
                            own['weight'][i], own['target_first_moment'][i],
                            own['target_second_moment'][i])
    writers = {r['tick'] for r in model['expected_gain_writer_ticks']}; groups = {}
    next_control = 0; owner = dsp_owner = None; level = 0
    for state in model['states']:
        tick = state['tick']
        while next_control < len(controls) and controls[next_control]['tick'] <= tick:
            owner = next_control; next_control += 1
        if tick in writers:
            dsp_owner = owner; level = state['level']
        if tick not in demands:
            continue
        require(dsp_owner is not None, 'Source observation has no actual native gain writer')
        old = controls[dsp_owner]['volume']
        require((int(words[old])*level) >> 16 == state['amplitude_product'],
                'Decoded DSP gain hold ownership differs')
        groups.setdefault(dsp_owner, []).append((level, *demands[tick]))
    encoded = bytearray(data); changed = infeasible = 0; selectors = words.astype(np.int64)
    for owner, rows in groups.items():
        if not fit_all_profiles and any(r[1] not in selected for r in rows):
            continue
        matrix = np.array(rows, dtype=float)
        products = (matrix[:,0].astype(np.int64)[:,None]*selectors[None,:]) >> 16
        nominal = matrix[:,2,None]
        levels = np.divide(products, nominal, out=np.zeros(products.shape), where=nominal != 0)
        peaks = np.array([before[str(int(r[1]))]['maximum_sampled_error'] for r in rows])
        excess = np.abs(levels-matrix[:,3,None])-peaks[:,None]
        allowed = np.all(excess <= 1e-12, axis=0)
        row_errors = matrix[:,4,None]*levels**2-2*matrix[:,5,None]*levels+matrix[:,6,None]
        error = np.sum(row_errors, axis=0)
        if fit_all_profiles:
            # A writer can remain live across a source instrument boundary.
            # Protect each profile's own error across a shared writer.
            # The all-profile pass starts from the existing targeted fit.
            old = controls[owner]['volume']
            for profile in set(int(r[1]) for r in rows):
                own_error = row_errors[matrix[:,1] == profile].sum(axis=0)
                allowed &= own_error <= own_error[old]+1e-12
        if np.any(allowed):
            chosen = int(np.where(allowed, error, np.inf).argmin())
        else:
            infeasible += 1
            regression = np.maximum(0., excess).max(axis=0)
            chosen = min(range(128), key=lambda i:(regression[i], error[i]))
        at = instructions[owner]['pc']
        require(encoded[at] == 7 and encoded[at+1] == controls[owner]['volume'],
                'Actual gain operand owner differs')
        changed += encoded[at+1] != chosen; encoded[at+1] = chosen
    refined = packed.decode_channel(flat, bytes(encoded), end_tick=end, articulations=arts)
    fields = ('tick','path','timer','gate','flags','level','phase','instrument','pitch_fixed',
              'pan','reset','envelope_advanced')
    require([tuple(s[k] for k in fields) for s in model['states']] ==
            [tuple(s[k] for k in fields) for s in refined['states']],
            'Gain operand refinement changes native envelope/note/gate chronology')
    return bytes(encoded), refined, {'refined_native_volume_operands':changed,
        'infeasible_native_gain_hold_intervals':infeasible,
        'all_non_gain_native_state_and_chronology_equal':True}


def residual_section(flat, events, voices, selected, words, base_model, end, arts, packed,
                     fit_all_profiles=False):
    """Bounded data optimization against actual independently decoded bytes."""
    before = {}; accumulate(base_model, voices, words, before); before = metrics(before)
    current = base_model; choices = []; reports = []
    for iteration in range(RESIDUAL_PASSES):
        corrected, added, skipped, infeasible = residual_controls_for(
            events, voices, selected, words, current, base_model, before)
        data, proof = packed.compile_channel(flat, corrected, end_tick=end,
            instrument_bank=23, articulations=arts)
        current = packed.decode_channel(flat, data, end_tick=end, articulations=arts)
        data, current, refinement = refine_encoded_gain(flat, data, current, voices,
            selected, words, before, end, arts, packed)
        proof = {**proof, 'event_timelines_equal':False,
                 'encoded_gain_values_refined_after_packing':True,
                 'all_non_gain_native_state_and_chronology_equal':True}
        totals = {}; accumulate(current, voices, words, totals); fit = metrics(totals)
        keys = [str(profile) for profile in selected if str(profile) in fit]
        regression = max([max(0., fit[k]['maximum_sampled_error']-
                             before[k]['maximum_sampled_error']) for k in keys], default=0.)
        error = sum(fit[k]['weighted_relative_rms']**2 for k in keys)
        summary = {'pass':iteration+1, 'bytes':len(data), 'added_volume_control_rows':added,
            'gate_occupancy_updates_skipped':skipped, 'infeasible_peak_bound_updates':infeasible,
            'largest_peak_regression':regression, 'weighted_error_sum':error, **refinement}
        choices.append(((regression, error, len(data)), data, proof, current, summary))
        reports.append(summary)
    _, data, proof, model, chosen = min(choices, key=lambda x:x[0])
    if fit_all_profiles:
        # Keep the existing pass and its complete native chronology. Refine
        # its already-emitted operands, including writers shared by profiles.
        prior = {}; accumulate(model, voices, words, prior); prior = metrics(prior)
        data, model, refinement = refine_encoded_gain(flat, data, model, voices,
            selected, words, prior, end, arts, packed, fit_all_profiles=True)
        totals = {}; accumulate(model, voices, words, totals); fit = metrics(totals)
        require(all(fit[k]['weighted_relative_rms'] <= prior[k]['weighted_relative_rms']+1e-12
                    and fit[k]['maximum_sampled_error'] <= prior[k]['maximum_sampled_error']+1e-12
                    for k in prior), 'All-profile operand fitting regresses the existing targeted fit')
        chosen = {**chosen, 'all_profile_operand_refinement':refinement,
                  'existing_targeted_fit_weighted_and_peak_errors_not_regressed':True}
    return data, proof, model, {**chosen, 'passes':reports}


def accumulate(model, voices, words, totals):
    for voice in voices:
        n = voice['last']-voice['first']; own = voice['observation']
        states = model['states'][voice['first']:voice['last']]
        require(len(states) == n, 'Decoded native curve ends before its source voice')
        nominal = words[voice['nominal']]
        actual = np.array([s['amplitude_product'] for s in states], dtype=float)
        level = np.divide(actual, nominal, out=np.zeros(n), where=nominal != 0)
        error = level-own['y'][:n]
        weighted = np.sum(own['weight'][:n]*level**2-
                          2*own['target_first_moment'][:n]*level+
                          own['target_second_moment'][:n])
        row = totals.setdefault(voice['profile'], {'updates':0, 'error':0., 'weighted':0.,
            'source_energy':0., 'maximum':0., 'voices':0})
        row['updates'] += n; row['error'] += float(np.sum(error*error))
        row['weighted'] += max(0., float(weighted))
        row['source_energy'] += float(np.sum(own['target_second_moment'][:n]))
        row['maximum'] = max(row['maximum'], float(np.max(np.abs(error))))
        row['voices'] += 1


def metrics(totals):
    return {str(key): {'updates':row['updates'], 'voices':row['voices'],
        'amplitude_rms':float(np.sqrt(row['error']/row['updates'])),
        'weighted_relative_rms':float(np.sqrt(row['weighted']/row['source_energy'])),
        'maximum_sampled_error':row['maximum']} for key,row in sorted(totals.items())}


