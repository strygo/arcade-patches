"""Pinned original score conversion functions; no checkout dependency."""
from __future__ import annotations
from collections import Counter
from score_support import digest
from score_support import require
import json
import struct
import upper_music_sources as source

FIXED_UNITS_PER_SECOND = 4096000


GATE_EXTENSIONS = (0x200, 0x800, 0x1000, 0x2000)


STEP_EXTENSIONS = (0x100, 0x200, 0x800, 0x1000)


def json_digest(value):
    return digest(json.dumps(value, sort_keys=True, separators=(',', ':')).encode())


def perform(data, loop_passes=2, max_events=100000):
    """Expand actual single-slot references and bounded infinite loop passes.

    Extension opcodes do not consume a reference's packet count. Durations use
    the tempo at the event, as the driver does; later tempo changes do not
    rescale a gate that was already scheduled. Controllers are preserved raw.
    """
    require(1 <= loop_passes <= 8, 'Bounded loop pass count')
    physical = source.sequence_events(data)['events']; lookup = {r['offset']: r for r in physical}
    require(len(lookup) == len(physical), 'Duplicate physical score offsets')
    for row in physical:
        if row['kind'] == 'reference':
            require(row['target_offset'] in lookup and row['event_count'] > 0,
                    'Reference target boundary/count')
    fraction, tempo = struct.unpack_from('<II', data, 4)
    require(0 < fraction <= 65536 and 0 < tempo <= 65535, 'Unqualified timing header range')
    factor = (fraction*tempo) >> 4
    pc = 12; now = 0; tick = 0; gate_extra = 0; step_extra = 0; step_extra_ticks = 0
    remaining = 0; return_pc = None; bypass_counter = True
    first_loop = None; loop_ends = []; iteration = 0
    timeline = []; notes = []; reference_calls = 0
    channels = [{'bank': None, 'program': None, 'pitch_raw': None, 'controls': {}} for _ in range(16)]
    for executed in range(max_events):
        if not bypass_counter and remaining:
            if remaining == 1:
                pc = return_pc
            remaining -= 1
        bypass_counter = False
        require(pc in lookup, 'Execution pointer is not a decoded event boundary')
        row = dict(lookup[pc]); next_pc = pc+row['bytes']; kind = row['kind']
        row |= {'performed_index': executed, 'time_fixed': now, 'nominal_tick': tick,
                'loop_iteration': iteration, 'tempo_ms_per_quarter': tempo}
        timeline.append(row)
        if kind == 'reference':
            require(remaining == 0, 'Nested reference would overwrite the single original return slot')
            require(return_pc is None or remaining == 0, 'Reference slot state')
            remaining = row['event_count']; return_pc = next_pc; pc = row['target_offset']
            bypass_counter = True; reference_calls += 1; continue
        if kind in ('gate_extend', 'step_extend'):
            extension = (GATE_EXTENSIONS if kind == 'gate_extend' else STEP_EXTENSIONS)[row['opcode'] & 3]
            if kind == 'gate_extend': gate_extra += extension*factor
            else:
                step_extra += extension*factor; step_extra_ticks += extension
            pc = next_pc; bypass_counter = True; continue
        if kind == 'end':
            require(remaining == 0 and first_loop is None, 'Unexpected end during active reference/loop')
            termination = 'finite_end'; break
        if kind == 'tempo':
            tempo = row['milliseconds_per_quarter']; require(tempo > 0, 'Zero performed tempo')
            factor = (fraction*tempo) >> 4
        if kind in ('control', 'program', 'pitch', 'note'):
            state = channels[row['channel']]
            if kind == 'control':
                require(row['argument'] in (1, 7, 10, 11, 32, 121), 'Unqualified performed controller')
                if row['argument'] == 121:
                    # All canonical reset packets precede complete explicit setup.
                    # Unknown default controls are not invented by this reader.
                    require(now == 0, 'Unqualified non-initial controller reset')
                    state['controls'] = {}; state['pitch_raw'] = None
                state['controls'][str(row['argument'])] = row['value']
                if row['argument'] == 32: state['bank'] = row['value'] & 15
            elif kind == 'program': state['program'] = row['argument']
            elif kind == 'pitch': state['pitch_raw'] = row['argument']
            else:
                require(row['velocity'] > 0, 'Zero-velocity note/key-off semantics unqualified')
                require(state['bank'] is not None and state['program'] is not None,
                        'Note without explicit program bank/program setup')
                note = row | {'note_index': len(notes), 'bank': state['bank'], 'program': state['program'],
                    'pitch_raw': state['pitch_raw'], 'controls_at_onset': dict(state['controls']),
                    'gate_fixed': row['gate_ticks']*factor+gate_extra}
                require(note['gate_fixed'] < 0x80000000, 'Unqualified overflowing note gate')
                notes.append(note); gate_extra = 0
        elif kind in ('pressure', 'poly_pressure'):
            raise ValueError('Unqualified pressure semantics in performed source')
        if kind == 'loop':
            require(row['mode'] == 0 and remaining == 0, 'Only original infinite non-reference loops qualified')
            if first_loop is None:
                first_loop = {'event_offset': pc, 'resume_offset': next_pc,
                              'time_fixed': now, 'nominal_tick': tick, 'step_ticks': row['step_ticks']}
            else:
                require(now > first_loop['time_fixed'], 'Loop makes no temporal progress')
                loop_ends.append({'event_offset': pc, 'time_fixed': now, 'nominal_tick': tick})
                if len(loop_ends) == loop_passes:
                    termination = 'bounded_infinite_loop'; break
                next_pc = first_loop['resume_offset']; row['step_ticks'] = first_loop['step_ticks']
                iteration += 1
        step_fixed = row['step_ticks']*factor+step_extra
        # The original step accumulator is invoked only for a positive step.
        require(not (row['step_ticks'] == 0 and step_extra), 'Pending step extension with zero step is unqualified')
        now += step_fixed; tick += row['step_ticks']+step_extra_ticks
        step_extra = 0; step_extra_ticks = 0; pc = next_pc
        require(now < 600*FIXED_UNITS_PER_SECOND, 'Performed duration budget exceeded')
    else:
        raise ValueError('Performed event budget exhausted (possible reference/zero-time cycle)')
    require(not gate_extra and not step_extra, 'Unconsumed terminal duration extension')
    durations = [r['time_fixed']-(first_loop['time_fixed'] if n == 0 else loop_ends[n-1]['time_fixed'])
                 for n, r in enumerate(loop_ends)] if first_loop else []
    require(not durations or len(set(durations)) == 1, 'Loop duration differs between performed passes')
    return {'timeline': timeline, 'notes': notes, 'summary': {
        'physical_events': len(physical), 'performed_events': len(timeline), 'performed_notes': len(notes),
        'reference_calls': reference_calls, 'nested_references': 0, 'reference_stack_depth': 1,
        'kind_counts': dict(sorted(Counter(e['kind'] for e in timeline).items())),
        'channels': sorted({n['channel'] for n in notes}),
        'banks': sorted({n['bank'] for n in notes}), 'programs': sorted({n['program'] for n in notes}),
        'tick_fraction': fraction, 'initial_tempo_ms_per_quarter': struct.unpack_from('<I', data, 8)[0],
        'tempo_values_ms_per_quarter': sorted({e['milliseconds_per_quarter'] for e in timeline if e['kind'] == 'tempo'}),
        'first_loop': first_loop, 'loop_ends': loop_ends, 'loop_passes': len(loop_ends),
        'intro_nominal_seconds': first_loop['time_fixed']/FIXED_UNITS_PER_SECOND if first_loop else None,
        'loop_nominal_seconds': durations[0]/FIXED_UNITS_PER_SECOND if durations else None,
        'performed_nominal_seconds': now/FIXED_UNITS_PER_SECOND,
        'termination': termination, 'timeline_sha256': json_digest(timeline), 'notes_sha256': json_digest(notes),
        'gate_semantics': 'Fixed duration at note onset; later tempo changes do not rescale existing gates.',
        'controller_semantics': 'Raw MIDI-like events retained; explicit bank/program and onset controller state recorded.',
        'live_scheduler_quantization_and_voice_stealing_accepted': False}}


def choose_splits(program, key, velocity, bank_data):
    """Original driver takes the first eligible split in each of four layers."""
    selected = []
    for layer in program['layers']:
        # Nonzero delays need their own original runtime qualification.
        require(layer['delay_ticks'] == 0, 'Nonzero program-layer delay not qualified')
        for split in layer['splits']:
            record = source.bounded(bank_data, split['record_offset'], 48, 'Performed split')
            if split['key_low'] <= key <= split['key_high'] and record[43] <= velocity <= record[44]:
                require(record[45] == 0 and record[46] == 0, 'Program alternate/voice-link fields not qualified')
                selected.append(split | {'layer': layer['layer_index'], 'velocity_curve': record[42],
                    'velocity_low': record[43], 'velocity_high': record[44],
                    'bend_range_high': layer['bend_range_high'], 'bend_range_low': layer['bend_range_low']})
                break
    return selected


def interval_peak(voices, end_field='end_fixed', start=0, finish=None):
    changes = []
    for index, voice in enumerate(voices):
        a = max(start, voice['time_fixed']); z = voice[end_field]
        if finish is not None: z = min(z, finish)
        if a < z: changes.extend(((a, 1, index), (z, -1, index)))
    active = set(); peak = 0; witness = None; over16 = 0; previous = start
    for at, delta, index in sorted(changes):
        if len(active) > 16: over16 += at-previous
        if delta < 0: active.remove(index)
        else: active.add(index)
        if len(active) > peak:
            peak = len(active); witness = {'time_fixed': at, 'voice_indices': sorted(active)}
        previous = at
    return {'peak': peak, 'witness': witness, 'over_16_nominal_seconds': over16/FIXED_UNITS_PER_SECOND}


def voice_demand(performance, data):
    bank = source.program_bank(data)
    programs = {r['program_index']: r for r in bank['programs']}
    velocity_at = source.u32(data, 24)
    voices = []; empty = []; per_note = Counter(); used_splits = set()
    for note in performance['notes']:
        require(note['bank'] == 1 and note['program'] in programs, 'Unqualified performed program bank/program')
        require(all(source.u32(data, l['offset']+8) == 0 for l in programs[note['program']]['layers']),
                'Nonzero original 32-bit layer delay/control word unqualified')
        selected = choose_splits(programs[note['program']], note['key'], note['velocity'], data)
        per_note[len(selected)] += 1
        if not selected: empty.append(note['note_index'])
        for split in selected:
            require(split['format'] == 'pcm16' and split['fine_tune_raw'] == 0 and split['pitch_register'] == 0,
                    'Sample demand/profile outside qualified PCM16 pitch baseline')
            curve = data[velocity_at+split['velocity_curve']*128+note['velocity']]
            # A nominal sample duration is supplementary: dynamic bends and AICA
            # release/envelope semantics are not silently simulated here.
            ratio = 2**((note['key']-split['base_key'])/12)
            full_sample_fixed = round(split['sample_frames']/44100/ratio*FIXED_UNITS_PER_SECOND)
            voice = {'voice_index': len(voices), 'note_index': note['note_index'],
                'channel': note['channel'], 'program': note['program'], 'key': note['key'],
                'velocity': note['velocity'], 'pitch_raw': note['pitch_raw'], 'layer': split['layer'],
                'split_record_offset': split['record_offset'], 'sample_offset': split['sample_offset'],
                'sample_sha256': digest(source.bounded(data, split['sample_offset'], split['sample_bytes'], 'Performed sample')),
                'sample_frames': split['sample_frames'], 'loop_enabled': split['loop_enabled'],
                'loop_start': split['loop_start'], 'base_key': split['base_key'],
                'velocity_curve': split['velocity_curve'], 'curve_value_at_velocity': curve,
                'envelope_register': split['envelope_register'], 'filter_enabled': split['filter_enabled'],
                'time_fixed': note['time_fixed'], 'gate_fixed': note['gate_fixed'],
                'end_fixed': note['time_fixed']+note['gate_fixed'],
                'nominal_full_sample_fixed': full_sample_fixed,
                'sample_limited_gate_end_fixed': note['time_fixed']+min(note['gate_fixed'], full_sample_fixed)
                    if not split['loop_enabled'] else note['time_fixed']+note['gate_fixed'],
                'bend_range_high': split['bend_range_high'], 'bend_range_low': split['bend_range_low']}
            voices.append(voice); used_splits.add(split['record_offset'])
    require(not empty, 'Performed notes with no eligible program split')
    peak = interval_peak(voices)
    loop = performance['summary']['first_loop']; finish = performance['summary']['loop_ends'][0]['time_fixed']
    loop_peak = interval_peak(voices, start=loop['time_fixed'], finish=finish)
    samples = sorted({v['sample_offset'] for v in voices})
    summary = {'performed_sample_activations': len(voices), 'layers_per_note_histogram': dict(sorted(per_note.items())),
        'unmatched_notes': empty, 'used_split_count': len(used_splits), 'used_sample_offsets': samples,
        'used_unique_sample_count': len(samples), 'used_unique_sample_bytes': sum(
            s['bytes'] for s in bank['unique_samples'] if s['offset'] in samples),
        'gated_sample_voice_demand': peak, 'first_loop_gated_sample_voice_demand': loop_peak,
        'per_channel_gated_peaks': {str(ch): interval_peak([v for v in voices if v['channel'] == ch])['peak']
                                  for ch in performance['summary']['channels']},
        'nominal_sample_limited_gate_demand': interval_peak(voices, 'sample_limited_gate_end_fixed'),
        'voices_sha256': json_digest(voices),
        'gated_demand_is_actual_aica_occupancy': False,
        'qualification': 'Exact performed note/gate and eligible program-layer demand; not release-tail/voice-allocator emulation.',
        'sample_limited_demand_qualification': 'Supplementary baseline at 44100 Hz and key-base pitch; ignores bends, filter/envelope and release tails.',
        'release_tail_and_dynamic_pitch_occupancy_open': True}
    # These are capacity sensitivity scenarios, not measurements of original
    # AICA release envelopes. They make an unresolved tail assumption visible.
    summary['hypothetical_uniform_release_tail_sensitivity'] = []
    for milliseconds in (40, 100, 250, 500):
        tail = milliseconds*4096
        extended = [v | {'end_fixed': v['end_fixed']+tail} for v in voices]
        summary['hypothetical_uniform_release_tail_sensitivity'].append(
            {'tail_milliseconds': milliseconds, 'peak': interval_peak(extended)['peak'],
             'native_release_envelope_measured': False})
    return voices, summary


