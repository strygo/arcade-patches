"""Pinned original score conversion functions; no checkout dependency."""
from __future__ import annotations
from audit_qsound_frontend import instruction_size
from hsf2_music_adapter import successors
from score_support import require

def prove_installed_graph(payload, resources, translation, headers, mapping, bridges):
    """Independently decode all installed operands and both control-flow arms.

    Translation proves source semantics before placement. This separate gate
    proves placement retained every emitted scalar and selector byte and that
    inserted 16 jumps lead to exactly the original translated successors.
    It inspects every instruction, including runtime-unvisited counter arms.
    """
    base = translation['relocation']['sequence_base']
    logical_data = bytes(base)+resources['scores.bin']
    by_bridge = {b['address']:b for b in bridges}
    require(len(by_bridge) == len(bridges), 'Repeated installed bridge address')
    used_bridges = set()
    def through_bridges(pc):
        visited = set()
        while pc in by_bridge:
            require(pc not in visited, 'Inserted bridge loop changes score control flow')
            visited.add(pc); used_bridges.add(pc)
            require(payload[pc] == 22 and instruction_size(payload,pc,True) == 3,
                    'Installed bridge opcode changed')
            actual = successors(payload,pc,True)
            require(actual == [by_bridge[pc]['target']], 'Installed bridge displacement changed')
            pc = actual[0]
        return pc
    edges = 0; scalars = 0; native_instructions = 0
    for group in translation['instruction_map']:
        logical = group['output']; physical = mapping[logical]; length = group['output_bytes']
        expected = bytearray(logical_data[logical:logical+length])
        actual = bytearray(payload[physical:physical+length])
        cursor = logical; native_pcs = []
        while cursor < logical+length:
            native_pcs.append(cursor)
            cursor += instruction_size(logical_data,cursor,True)
        require(cursor == logical+length, 'Translated group has a partial native instruction')
        native_instructions += len(native_pcs)
        last = native_pcs[-1]; native_op = logical_data[last]
        if 14 <= native_op <= 22:
            displacement = last-logical+(1 if native_op == 22 else 2)
            expected[displacement:displacement+2] = bytes(2)
            actual[displacement:displacement+2] = bytes(2)
        require(actual == expected, 'Installed instruction scalar/selector payload differs')
        scalars += len(expected)-(2 if 14 <= native_op <= 22 else 0)
        last_physical = physical+(last-logical)
        # Re-decode actual lengths too: a changed opcode cannot disguise an
        # operand as a branch relocation or shift a group boundary.
        cursor = physical
        for pc in native_pcs:
            require(cursor-physical == pc-logical, 'Installed native instruction boundary differs')
            cursor += instruction_size(payload,cursor,True)
        require(cursor == physical+length, 'Installed native group end differs')
        logical_next = successors(logical_data,last,True)
        require(all(p in mapping for p in logical_next), 'Translated graph has an unmapped successor')
        expected_next = [mapping[p] for p in logical_next]
        actual_next = [through_bridges(p) for p in successors(payload,last_physical,True)]
        require(actual_next == expected_next, 'Installed branch/fallthrough seam differs')
        edges += len(expected_next)
    for command in translation['commands']:
        logical = command['output_header']; physical = headers[logical]
        require(payload[physical] == logical_data[logical], 'Installed header mode differs')
        for channel,offset in enumerate(command['channel_offsets']):
            actual = int.from_bytes(payload[physical+1+2*channel:physical+3+2*channel],'big')
            require((actual == 0 if offset == 0 else physical+actual == mapping[logical+offset]),
                    'Installed channel header seed differs')
    require(used_bridges == set(by_bridge), 'An inserted bridge is not a declared graph seam')
    return {'instruction_groups':len(mapping),'native_instructions':native_instructions,
            'successor_edges':edges,'scalar_selector_bytes':scalars,
            'fallthrough_bridges':sum(b['kind'] == 'fallthrough_bridge'for b in bridges),
            'long_branch_relays':sum(b['kind'] == 'long_branch_relay'for b in bridges),
            'all_counter_arms_and_unvisited_payloads_equal':True}


