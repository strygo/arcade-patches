"""Pure source-schedule and closing arithmetic from the pinned accepted producer."""
from fractions import Fraction
import json
import numpy as np
from score_support import require, digest
import native_music_sampling as sampling
import upper_music_articulations as articulation
import upper_music_samples as samples
import upper_music_native as native
import upper_music_envelopes as envelope
import upper_music_performance as performance
import render_upper_budget_audition as audition
import render_upper_guile_preview as preview
import audit_upper_loop_source as source
import upper_music_duration_packing as packed
import upper_music_loop_layout as layout
import upper_music_loop_model as loop
import compile_guile_music_quality as quality
PARSER_ENTRY=bytes([4,0,11,0,12,0])

def prepare(body,program,performed,tables,flat,dsp,sample_report,first_instrument):
    rows,controls,sampling_report=sampling.schedule(body,program,performed,tables,(audition,preview,envelope,performance))
    profiles={}
    for row in rows:
        key=articulation.profile_key(row);row['profile_key']=key
        p=profiles.setdefault(key,{'profile_key':key,'source_sample_sha256':row['sample_sha256'],
            'source_offset':row['sample_offset'],'envelope_register':row['envelope_register'],
            'source_fields':envelope.envelope_fields(row['envelope_register']),'programs':set(),'split_records':set()})
        p['programs'].add(row['program']);p['split_records'].add(row['split_record_offset'])
    for n,key in enumerate(sorted(profiles,key=lambda k:(profiles[k]['source_offset'],k)),first_instrument):
        p=profiles[key];p.update(profile_id=n,programs=sorted(p['programs']),split_records=sorted(p['split_records']))
    require(max(p['profile_id']for p in profiles.values())<128,'Shared native instrument-bank width exceeded')
    samples_by_hash=samples.sample_map(sample_report);volumes=np.array([float(native.volume_gain(flat,n))for n in range(128)])
    pitch_cache={};pan_cache={};observations={};count=round(performed['summary']['performed_nominal_seconds']*44100)
    for voice,onset,release,wave,aeg in audition.voice_waves(body,program,performed,count,tables):
        row=rows[voice['voice_index']];first,last=row['onset_tick'],row['end_tick'];n=last-first
        require(row['sample_sha256']==voice['sample_sha256']and n>0,'Source envelope ownership differs')
        bounds=np.clip(np.array([round(Fraction(t,sampling.HZ)*44100)-onset for t in range(first,last+1)]),0,len(aeg))
        power=np.divide(np.sum(wave*wave,axis=1),aeg*aeg,out=np.zeros(len(aeg)),where=aeg>0)/(32768.**2)
        sums=[np.r_[0.,np.cumsum(a)]for a in(power,power*aeg,power*aeg*aeg)]
        moments=[a[bounds[1:]]-a[bounds[:-1]]for a in sums]
        if n==1 and not np.sum(moments[0]) and np.sum(power):
            # A complete sub-update one-shot can precede its rounded onset.
            # Keep its physical waveform moments in the reserved single tick,
            # just as the shared sampler keeps its nonzero envelope scalar.
            moments=[np.array([a[-1]])for a in sums]
        own=controls[row['voice_index']];require(len(own)==n,'Native source envelope sampling interval differs')
        sparse=[];previous=None;sample=samples_by_hash[row['sample_sha256']]
        for control in own:
            pkey=(sample['sample_id'],control['source_step'])
            if pkey not in pitch_cache:pitch_cache[pkey]=native.choose_pitch(flat,samples.desired_rate_word(sample,control['source_step']))
            pan=tuple(control['pan'])
            if pan not in pan_cache:pan_cache[pan]=native.choose_pan(dsp,*pan)
            current=(int(np.abs(volumes-control['base_gain']).argmin()),pitch_cache[pkey]['pitch_fixed'],pan_cache[pan]['pan'])
            event={'tick':control['tick']}
            if previous is None:event.update(profile_key=row['profile_key'],pitch_fixed=current[1],retrigger=True)
            elif current[1]!=previous[1]:event.update(pitch_fixed=current[1],retrigger=False)
            if previous is None or current[0]!=previous[0]:event['volume']=current[0]
            if previous is None or current[2]!=previous[2]:event['pan']=current[2]
            if len(event)>1:sparse.append(event)
            previous=current
        row['profile_id']=profiles[row['profile_key']]['profile_id']
        observations[row['voice_index']]={'first_tick':first,'y':np.array([v['envelope_scalar']for v in own]),
            'weight':moments[0],'target_first_moment':moments[1],'target_second_moment':moments[2],'controls':sparse}
    end=max(v['end_tick']for v in rows)+1
    return rows,profiles,observations,end

def close(r,period,template_pass=0,trim_replaced_tail_controls=True):
    boundaries=source.boundaries(r['performed']);boundary=boundaries[template_pass]['native_tick']
    if template_pass==0:
        notes=[source.normalized_packets(r['performed']['notes'],a,b)for a,b in zip(boundaries,boundaries[1:])]
        require(len(notes)>=3 and all(n==notes[0]for n in notes),'Source first pass has distinct notes/controllers')
    template=source.segment(r['rows'],r['observations'],boundaries[template_pass],boundaries[template_pass+1])
    retired_controls=[]
    if trim_replaced_tail_controls:
        # A context's next genuine onset replaces the already-released tail.
        # Later live controls of that retired activation cannot own the new
        # note. Preserve every control before the replacement and every held
        # gate; never truncate solely at a global song boundary.
        for slot in range(16):
            own=[v for v in template if v['slot']==slot];cut=min(v['onset_tick']for v in own)+period
            for v in own:
                late=[e for e in v['controls']if e['tick']>=cut]
                if late:
                    require(v['gate_tick']<=cut and v['end_tick']>cut,'Would retire a held voice control')
                    retired_controls.append({'slot':slot,'ordinal':v['ordinal'],'replacement_tick':cut,
                        'gate_tick':v['gate_tick'],'controls':late})
                    v['controls']=[e for e in v['controls']if e['tick']<cut]
    rotated=source.rotated_steady_events(template,period=period)
    tails=[dict(slot=c['slot'],**v)for c in rotated for v in c['measured_tails_crossing_next_genuine_onset']]
    require(all(v['released_before_next_onset']for v in tails),'Loop would replace a held native voice: '+
        json.dumps([v for v in tails if not v['released_before_next_onset']][:4],sort_keys=True))
    outside=[dict(slot=c['slot'],**e)for c in rotated for e in c['unmodified_events_outside_body']]
    require(all(e.get('kind')=='keyoff'and e['tick']==period for e in outside),
        'Loop would discard a source control or an early positive keyoff')
    for c in rotated:
        cut=c['cut_relative_to_source_global_boundary_tick']
        for row in template:
            if row['slot']==c['slot']:row['end_tick']=min(row['end_tick'],cut+period)
    context={**r,'parts':[None,template],'rotated':rotated}
    flat=r['flat'];arts=r['articulation_map'];words=np.array([native.u16(flat,0x2e92+2*n)for n in range(128)],dtype=float)
    channels=[];reports=[];before_totals={};after_totals={}
    for row in rotated:
        slot=row['slot'];cut=boundary+row['cut_relative_to_source_global_boundary_tick'];sections=[];proofs=[]
        for steady,events,end in ((False,[e for e in r['events'][slot]if e['tick']<cut],cut),
                                  (True,row['events'],period)):
            data,proof=packed.compile_channel(flat,events,end_tick=end,instrument_bank=23,articulations=arts)
            model=packed.decode_channel(flat,data,end_tick=end,articulations=arts)
            voices=quality.spans(context,slot,end,steady)
            totals={};quality.accumulate(model,voices,words,totals);before=quality.metrics(totals)
            refined,model,fit=quality.refine_encoded_gain(flat,data,model,voices,set(),words,before,end,arts,packed,fit_all_profiles=True)
            quality.accumulate(packed.decode_channel(flat,data,end_tick=end,articulations=arts),voices,words,before_totals)
            quality.accumulate(model,voices,words,after_totals)
            require(refined[-3:]==bytes([7,0,23])and len(refined)==len(data),'Native finite terminal or score size changed')
            sections.append(refined[:-3]);proofs.append({'bytes':len(refined)-3,'gain_fit':fit,
                'genuine_onsets':[e['tick']for e in proof['timeline']if e.get('retrigger')],
                'gate_expiry_ticks':proof['gate_expiry_ticks']})
        closed=layout.join(sections[0],PARSER_ENTRY+sections[1])
        model=loop.decode(flat,closed,iterations=3,end_tick=cut+3*period,articulations=arts)
        closure=loop.closure(model,cut,period)
        expected=proofs[0]['genuine_onsets']+[cut+n*period+t for n in range(3)for t in proofs[1]['genuine_onsets']]
        require([e['tick']for e in model['events']if e['kind']=='note'and e['reset']]==expected,
            'Closed score omitted or invented genuine source onset')
        gates=proofs[0]['gate_expiry_ticks']+[cut+n*period+t for n in range(3)for t in proofs[1]['gate_expiry_ticks']]
        require([e['tick']for e in model['events']if e['kind']=='gate_expiry']==gates,'Closed score changed positive gate chronology')
        require(closure['entry_is_genuine_onset'],'Native loop reset is not a source onset')
        channels.append(closed)
        reports.append({'slot':slot,'cut_tick':cut,'bytes':len(closed),'sha256':digest(closed),
            'sections':[{k:v for k,v in p.items()if k not in('genuine_onsets','gate_expiry_ticks')}for p in proofs],
            'genuine_onsets':len(expected),'positive_gate_expiries':len(gates),'closure':closure})
    return channels,reports
