"""Pinned original score conversion functions; no checkout dependency."""
from __future__ import annotations
from fractions import Fraction
from score_support import require
import numpy as np
import render_upper_budget_audition as audition
import render_upper_guile_preview as preview
import upper_music_envelopes as envelope
import upper_music_native as native
import upper_music_performance as performance
import upper_music_samples as samples
import upper_music_sources as music

MUSIC_HZ = Fraction(125, 2)


BUDGET = 16


def native_tick(frame):
    return round(Fraction(frame, 44100)*MUSIC_HZ)


def profile_key(voice):
    return voice['sample_sha256']+':'+format(voice['envelope_register'], '08x')


def source_schedule(body, mpb, performed, tables, flat, sample_report, dsp_raw):
    """Same release-only policy, with envelope-independent controller events.

    Sufficient weighted moments preserve the original waveform energy in each
    native update interval. No source wave or output from another run is read.
    """
    require(np.__version__ == '2.2.6', 'Qualified NumPy version required')
    count = round(performed['summary']['performed_nominal_seconds']*44100)
    active = {}; rows = []; observations = {}; profiles = {}
    records = samples.sample_map(sample_report)
    events = {ch: [r for r in performed['timeline'] if r.get('channel') == ch and
        r['kind'] in ('pitch', 'control')] for ch in performed['summary']['channels']}
    volume_values = np.array([float(native.volume_gain(flat, i)) for i in range(128)])
    pitch_cache = {}; pan_cache = {}
    for voice, onset, gate, wave, aeg in audition.voice_waves(body, mpb, performed, count, tables):
        slot, old = audition.select_slot(active, onset, BUDGET)
        require(slot is not None, 'Approved release-only policy rejected a held voice')
        if old is not None:
            require(onset-old['onset'] >= old['gate'], 'Fit schedule interrupted held voice')
            old['record'].update(actual_end_frame=onset, action='release_tail_trimmed')
        key = profile_key(voice); fields = envelope.envelope_fields(voice['envelope_register'])
        require(fields['key_rate_scaling'] == 15 and not fields['loop_start_link'],
                'Only original unlinked KRS-disabled profiles qualify')
        profiles.setdefault(key, dict(source_sample_sha256=voice['sample_sha256'],
            envelope_register=voice['envelope_register'], source_fields=fields,
            source_offset=voice['sample_offset'], programs=set(), split_records=set()))
        if 'source_rates' not in profiles[key]:
            profiles[key]['source_rates'] = {name: envelope.rate_increment(
                envelope.rate_index(0, fields[field]), tables[table], name == 'attack')
                for name, field, table in (('attack', 'attack', 'AR'),
                    ('decay_one', 'decay_one', 'DR'), ('decay_two', 'decay_two', 'DR'),
                    ('release', 'release', 'DR'))}
        profiles[key]['programs'].add(voice['program'])
        profiles[key]['split_records'].add(voice['split_record_offset'])
        n = len(aeg); first, last = native_tick(onset), native_tick(onset+n)
        require(last > first, 'Source activation collapsed on music clock')
        row = dict(voice, onset_frame=onset, gate_end_frame=onset+gate,
            natural_end_frame=onset+n, actual_end_frame=onset+n, slot=slot,
            profile_key=key, action='retained')
        rows.append(row)
        active[slot] = {'onset': onset, 'gate': gate, 'wave': aeg, 'aeg': aeg, 'record': row}
        # Remove AEG only from the source waveform-energy proxy. Source channel
        # gain and stereo attenuation remain in the weighting; native DSP
        # filtering, PCM8 loss and inter-voice cancellation are not modeled.
        base_power = np.divide(np.sum(wave*wave, axis=1), aeg*aeg,
            out=np.zeros(n), where=aeg > 0)/(32768.**2)
        bounds = np.clip(np.array([round(Fraction(t, MUSIC_HZ)*44100)-onset
                                   for t in range(first, last+1)]), 0, n)
        prefixes = [np.r_[0., np.cumsum(a)] for a in
                    (base_power, base_power*aeg, base_power*aeg*aeg)]
        moments = [p[bounds[1:]]-p[bounds[:-1]] for p in prefixes]
        y = aeg[np.minimum(bounds[:-1], n-1)]
        note = performed['notes'][voice['note_index']]
        record = music.bounded(mpb, voice['split_record_offset'], 48, 'Articulation split')
        state = dict(note['controls_at_onset'])
        bend = 64 if voice['pitch_raw'] is None else voice['pitch_raw']
        changes = [r for r in events[voice['channel']] if
            r['time_fixed'] > note['time_fixed'] or
            r['time_fixed'] == note['time_fixed'] and r['performed_index'] > note['performed_index']]
        at = 0; controls = []; previous = None
        sample = records[voice['sample_sha256']]
        for tick in range(first, last):
            source_time = max(note['time_fixed'], round(Fraction(tick, MUSIC_HZ)*performance.FIXED_UNITS_PER_SECOND))
            while at < len(changes) and changes[at]['time_fixed'] <= source_time:
                change = changes[at]; at += 1
                if change['kind'] == 'pitch': bend = change['argument']
                else: state[str(change['argument'])] = change['value']
            gain, pan = preview.source_controls(body, record, voice['curve_value_at_velocity'], state)
            desired = samples.desired_voice_rate(body, voice, sample, bend_raw=bend)
            if desired not in pitch_cache: pitch_cache[desired] = native.choose_pitch(flat, desired)
            if pan not in pan_cache: pan_cache[pan] = native.choose_pan(dsp_raw, *pan)
            current = (int(np.abs(volume_values-gain).argmin()),
                       pitch_cache[desired]['pitch_fixed'], pan_cache[pan]['pan'])
            event = {'tick': tick}
            if previous is None or current[0] != previous[0]: event['volume'] = current[0]
            if previous is None or current[1] != previous[1]:
                event.update(pitch_fixed=current[1], retrigger=previous is None)
            if previous is None or current[2] != previous[2]: event['pan'] = current[2]
            if previous is None: event['profile_key'] = key
            if len(event) > 1: controls.append(event)
            previous = current
        observations[voice['voice_index']] = {'first_tick': first, 'y': y,
            'weight': moments[0], 'target_first_moment': moments[1],
            'target_second_moment': moments[2], 'controls': controls}
    ordered = sorted(profiles, key=lambda k: (profiles[k]['source_offset'], k))
    for index, key in enumerate(ordered):
        p = profiles[key]; p['profile_id'] = index
        p['programs'] = sorted(p['programs']); p['split_records'] = sorted(p['split_records'])
        own = [r for r in rows if r['profile_key'] == key]; gate_profiles = []
        for gate_frames in sorted({r['gate_end_frame']-r['onset_frame'] for r in own}):
            volume, phase = envelope.gate_envelope_volume(p['source_fields'], gate_frames, 0, tables)
            steps = volume >> envelope.EG_SHIFT
            log_gain = 10**((3*(steps-1023)/32)/20) if volume else 0.
            gate_profiles.append(dict(gate_frames=gate_frames, gate_seconds=gate_frames/44100,
                activations=sum(r['gate_end_frame']-r['onset_frame'] == gate_frames for r in own),
                scalar_phase_at_keyoff=phase, scalar_volume_at_keyoff=volume,
                held_gain_at_keyoff=steps/1024 if phase == 'attack' else log_gain,
                release_gain_at_keyoff=log_gain,
                source_release_bound=envelope.release_bound(0, p['source_fields'], tables['DR'], volume)))
        p['source_gate_profiles'] = gate_profiles
    for row in rows:
        first, last = native_tick(row['onset_frame']), native_tick(row['actual_end_frame'])
        row.update(onset_tick=first, end_tick=last, gate_end_tick=native_tick(row['gate_end_frame']),
                   profile_id=profiles[row['profile_key']]['profile_id'])
        obs = observations[row['voice_index']]; length = last-first
        for key in ('y', 'weight', 'target_first_moment', 'target_second_moment'):
            obs[key] = obs[key][:length]
        obs['controls'] = [r for r in obs['controls'] if r['tick'] < last]
        require(length > 0, 'Trimmed activation collapsed on music clock')
    return rows, profiles, observations


def articulation_map(report):
    return {r['profile_id']: bytes(r['articulation']) for r in report['profiles']}


