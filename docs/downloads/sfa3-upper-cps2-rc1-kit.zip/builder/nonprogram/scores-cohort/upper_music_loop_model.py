"""Pinned original score conversion functions; no checkout dependency."""
from __future__ import annotations
from score_support import require
import struct
import upper_music_duration_packing as packed
import upper_music_native as native

def selector_contract(flat):
    # The resident consumer compares the descriptor pointer cached at IX+2e
    # before reloading it. All callers bind distinct descriptor rows to local
    # instruments in the one qualified bank23 table. A repeated local index
    # therefore fetches its opcode but causes no descriptor cursor write.
    raw=bytes.fromhex('dd662fdd6e2eb7ed52280ddd722fdd732e3a30f0b7cc6614')
    require(flat[0x1442:0x1442+len(raw)]==raw,'Native descriptor equality/reload consumer changed')
    return dict(start=0x1442,bytes=len(raw),sha256=native.digest(raw),
        same_descriptor_pointer_skips_reload=True,distinct_local_descriptor_rows_required=True,
        single_instrument_bank=23)


def grammar(channel):
    pc=0;instructions={}
    while pc<len(channel):
        op=channel[pc]
        size=1 if op>=32 or op in (0,2,23) else 3 if op in (22,27) else 2
        require(op>=32 or op in (0,2,4,5,6,7,8,9,10,11,12,13,22,24,27,31),
                'Unsupported closed native opcode: '+hex(op))
        require(pc+size<=len(channel),'Truncated closed instruction')
        instructions[pc]=dict(pc=pc,opcode=op,bytes=size);pc+=size
    branches=[r for r in instructions.values() if r['opcode']==22]
    require(len(branches)==1 and branches[0]['pc']==len(channel)-3,
            'Closed channel needs one final native22 backedge')
    branch=branches[0];target=branch['pc']+3+struct.unpack_from('>h',channel,branch['pc']+1)[0]
    require(target in instructions and target<branch['pc'],'Backedge target is not an earlier instruction')
    require(any(r['opcode']>=32 for pc,r in instructions.items() if target<=pc<branch['pc']),
            'Closed body has no timed progress')
    return instructions,target


def unroll(channel,iterations):
    """Expose complete bodies, leaving the last branch unexecuted at the bound."""
    require(type(iterations)is int and 1<=iterations<=8,'Bounded loop iteration count')
    instructions,target=grammar(channel);terminal=len(channel)-3
    out=bytearray();mapping={};fetches=[];branches=[];pc=0;completed=0
    while True:
        row=instructions[pc]
        if pc==terminal:
            completed+=1
            if completed==iterations:break
            fetches.append(dict(row,iteration=completed-1))
            branches.append(dict(linear_pc=len(out),pc=pc,target=target,iteration=completed-1))
            pc=target;continue
        mapping[len(out)]=dict(row,iteration=completed)
        fetches.append(dict(row,iteration=completed));out.extend(channel[pc:pc+row['bytes']]);pc+=row['bytes']
    # This finite observation boundary is never installed in the closed ROM.
    out.extend([7,0,23])
    return bytes(out),mapping,fetches,branches


def decode(flat,channel,*,iterations,end_tick,articulations):
    linear,mapping,fetches,branches=unroll(channel,iterations)
    proof=packed.decode_channel(flat,linear,end_tick=end_tick,articulations=articulations)
    selector_contract(flat)
    require(all(linear[r['pc']+1]==23 for r in proof['instructions'] if r['opcode']==31),
        'Closed model only qualifies one instrument bank23 table')
    selected=None;reselects=[]
    for event in proof['events']:
        if event['kind']!='instrument':continue
        index=event['instrument']
        if index==selected:
            event['kind']='instrument_reselect';event['sample_cursor_reset']=False
            reselects.append(dict(event))
        selected=index
    proof['descriptor_selector_contract']=selector_contract(flat)
    proof['same_descriptor_reselections']=reselects
    observed=[r for r in proof['instructions'] if r['pc'] in mapping]
    require([r['pc'] for r in observed]==list(mapping),'Independent closed decode did not consume its complete unroll')
    proof['source_fetches']=fetches;proof['backedges']=branches
    proof['linear_unroll_sha256']=native.digest(linear)
    proof['closed_channel_sha256']=native.digest(channel)
    proof['iterations']=iterations
    # Only real closed-ROM observations precede the synthetic finite boundary.
    proof['states']=proof['states'][:-1]
    proof['events']=[r for r in proof['events'] if r['tick']<end_tick]
    proof['expected_gain_writer_ticks']=[r for r in proof['expected_gain_writer_ticks'] if r['tick']<end_tick]
    proof['terminal_tick']=end_tick-1
    proof['observation_end_tick']=end_tick
    return proof


def closure(model,entry_tick,period):
    require(model['observation_end_tick']>=entry_tick+2*period,'Two whole steady bodies required')
    states=model['states'];keys=('timer','gate','flags','level','phase','instrument',
                                 'pitch_fixed','volume','pan','amplitude_product','reset','envelope_advanced','path')
    first=[tuple(r[k] for k in keys) for r in states[entry_tick:entry_tick+period]]
    second=[tuple(r[k] for k in keys) for r in states[entry_tick+period:entry_tick+2*period]]
    require(first==second,'Native steady body state does not close')
    return dict(period_updates=period,compared_updates=len(first),equal_fields=list(keys),
        complete_body_scalar_equal=True,entry_is_genuine_onset=any(r['kind']=='note' and r['reset'] and
            r['tick']==entry_tick for r in model['events']))


