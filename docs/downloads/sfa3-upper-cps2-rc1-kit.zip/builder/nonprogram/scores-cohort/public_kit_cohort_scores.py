"""Construct added-fighter music from explicit original sources and frozen fits."""
import argparse
import json
from pathlib import Path
import re
import struct

from score_support import digest, require


def construct(inputs,recipe,out):
    import numpy,scipy
    import upper_music_sources as music
    import upper_music_performance as performance
    import upper_music_samples as samples
    import upper_music_native as native
    import compile_upper_packed_prefix as prefix
    import cohort_arithmetic as arithmetic
    from public_kit_scores import verify_outputs
    require((numpy.__version__,scipy.__version__) == ('2.2.6','1.15.3'), 'Pinned score dependencies required')
    require(not out.exists(), 'Fresh cohort score output required')
    song = recipe['song']
    require(song in ('BGM31','BGM32','BGM33'), 'Unknown cohort score')
    names = {'MANATEE.DRV','aica.cpp','dl-1425.bin','sz3.01','sz3.02',song+'.MSB',song+'.MPB'}
    require(set(recipe['inputs']) == names, 'Cohort source inventory differs')
    blobs = {}
    for name,pin in recipe['inputs'].items():
        require(not (inputs/name).is_symlink(), 'Aliased cohort source')
        data = (inputs/name).read_bytes()
        require({'bytes':len(data),'sha256':digest(data)} == pin, 'Cohort source differs: '+name)
        blobs[name] = data
    flat = blobs['sz3.01']+blobs['sz3.02']; driver = blobs['MANATEE.DRV']; body = driver[32:]
    tables = {}
    for name in ('AR','DR'):
        match = re.search(r'constexpr double '+name+r'Times\[64\]\s*=\s*\{([^}]+)\}',blobs['aica.cpp'].decode())
        require(match is not None, 'Missing original scalar table')
        tables[name] = [float(f.strip()) for f in re.sub(r'/\*.*?\*/','',match[1]).split(',') if f.strip()]
        require(len(tables[name]) == 64, 'Scalar table extent differs')
    sequence = blobs[song+'.MSB']; record = music.sequence_bank(sequence)['sequences'][0]
    score = sequence[record['offset']:record['offset']+record['bytes']]
    if song == 'BGM31':
        performed = performance.perform(score,loop_passes=3)
    elif song == 'BGM32':
        import deejay_music_performance as resets
        performed,_ = resets.perform(score,driver,performance)
    else:
        import thawk_music_performance as original
        performed,_ = original.perform(score,driver,performance)
    program = blobs[song+'.MPB']
    pcm,sample_report = samples.build(body,program,performed,flat,sample_bank_base=recipe['sample_bank'])
    if song == 'BGM33':
        import thawk_music_clock as clock
        import thawk_music_gates as gates
        import upper_music_gate_encoding as encoding
        clock.setup()
        adjusted = bytearray(flat); struct.pack_into('<H',adjusted,clock.ADDRESS,clock.INCREMENT); flat = bytes(adjusted)
        original_compile = encoding.compile_channel
        def compile_channel(flat,events,**kwargs):
            return original_compile(flat,gates.normalize(events),**kwargs)
        encoding.compile_channel = compile_channel
    rows,profiles,observations,end = arithmetic.prepare(body,program,performed,tables,flat,
        blobs['dl-1425.bin'],sample_report,recipe['first_instrument'])
    fitted = {p['profile_key']:p for p in recipe['profiles']}
    require(set(profiles) == set(fitted), 'Cohort profile inventory differs')
    arts = {}
    for key,p in profiles.items():
        expected = fitted[key]
        require(all(p[k] == expected[k] for k in p), 'Original cohort profile differs: '+key)
        art = bytes(expected['articulation'])
        require(native.articulation_parameters(flat,art) == expected['parameter_values'], 'Frozen articulation parameters differ')
        arts[p['profile_id']] = art
    events,_,_ = prefix.source_events(rows,profiles,observations,end)
    context = dict(flat=flat,rows=rows,profiles=profiles,observations=observations,events=events,
                   articulation_map=arts,performed=performed)
    print(song,'source profiles verified',len(rows),len(profiles),flush=True)
    channels,reports = arithmetic.close(context,recipe['period'])
    outputs = {f'channel_{n:02d}.bin':data for n,data in enumerate(channels)}
    outputs['articulations.bin'] = b''.join(arts[n] for n in sorted(arts))
    records = samples.sample_map(sample_report); instruments = bytearray(); descriptors = bytearray()
    for p in sorted(recipe['profiles'],key=lambda p:p['profile_id']):
        index = p['profile_id']-recipe['first_instrument']; row = records[p['source_sample_sha256']]
        raw = bytes.fromhex(row['descriptor_hex'])
        require(digest(raw) == row['descriptor_sha256'], 'Original sample descriptor differs')
        instruments.extend(struct.pack('<HBB',recipe['first_descriptor']+index,0,recipe['art_rows'][index]))
        descriptors.extend(raw)
    outputs['instruments.bin'] = bytes(instruments); outputs['descriptors.bin'] = bytes(descriptors)
    verify_outputs(outputs,recipe['outputs'])
    out.mkdir()
    for name,data in outputs.items():
        (out/name).write_bytes(data)
    report = {'passed':True,'song':song,'logical_bytes':33+sum(map(len,channels)),
              'resources':recipe['outputs'],'profiles':len(profiles),'articulation_optimizer_invoked':False,
              'native_onset_and_gate_checks':True,'hardware_reviewed':False}
    (out/'reconstruction.json').write_text(json.dumps(report,indent=2)+'\n')
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('inputs','recipe','out'):
        parser.add_argument('--'+name,type=Path,required=True)
    args = parser.parse_args()
    construct(args.inputs,json.loads(args.recipe.read_text()),args.out)


if __name__ == '__main__':
    main()
