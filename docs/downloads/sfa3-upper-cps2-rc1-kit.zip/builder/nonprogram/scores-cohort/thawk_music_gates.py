"""Pinned original score conversion functions; no checkout dependency."""
from __future__ import annotations
from score_support import require

def normalize(events):
    groups={};keyoffs=[]
    for original in events:
        row=dict(original);tick=row.pop('tick');kind=row.pop('kind',None)
        if kind=='keyoff':keyoffs.append(dict(original));continue
        target=groups.setdefault(tick,{})
        require(not('pitch_fixed'in target and 'pitch_fixed'in row),'Two source pitch events in one update')
        if kind=='note_off':row['volume']=0
        require(kind in(None,'note_off'),'Unknown native source event kind')
        target.update(row)
    state={};result=[]
    for tick,row in sorted(groups.items()):
        require(set(row)<={'instrument','volume','pan','pitch_fixed','retrigger'},'Unknown native state field')
        output={k:v for k,v in row.items()if k in('instrument','volume','pan')and state.get(k)!=v}
        sounding='pitch_fixed'in row and(row.get('retrigger',True)or state.get('pitch_fixed')!=row['pitch_fixed'])
        if sounding:output.update(pitch_fixed=row['pitch_fixed'],retrigger=row.get('retrigger',True))
        for k in('instrument','volume','pan','pitch_fixed'):
            if k in row:state[k]=row[k]
        if output:result.append(dict(tick=tick,**output))
    return sorted(result+keyoffs,key=lambda r:r['tick'])


