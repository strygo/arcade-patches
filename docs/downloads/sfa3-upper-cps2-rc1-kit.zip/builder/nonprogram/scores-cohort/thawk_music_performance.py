"""Pinned original score conversion functions; no checkout dependency."""
from __future__ import annotations
from deejay_music_performance import reset_contract
from score_support import digest
from score_support import require
from types import FunctionType
import struct

SCORE='fe70e2fc8beae4ee31911daf15ef1e381bc16dad40a8b9fccaa53d3c31184cca'


def zero_controls(events,notes):
    cases=[]
    for row in events:
        if row['kind']!='control'or row['argument']!=91:continue
        channel=row['channel'];index=row['performed_index']
        require(row['value']==0,'CC91 is not a zero/default packet')
        require(not any(n['channel']==channel and n['performed_index']<index for n in notes),
            'CC91 default packet reaches existing source voices')
        resets=[r for r in events if r['kind']=='control'and r['argument']==121 and
            r['channel']==channel and r['performed_index']<index]
        require(resets and resets[-1]['time_fixed']<=row['time_fixed'],'CC91 has no preceding reset/default send')
        cases.append({'channel':channel,'performed_index':index,'value':0,'time_fixed':row['time_fixed'],
            'prior_reset_index':resets[-1]['performed_index'],'prior_source_notes':0})
    require(len(cases)==16 and {r['channel']for r in cases}==set(range(16)),
        'T. Hawk pre-note CC91 channel domain differs')
    return cases


def perform(score,driver,original):
    require(digest(score)==SCORE,'Different score needs its own controller qualification')
    reset=reset_contract(driver);body=driver[32:]
    expected={0x22f4:0xea000346,0x3014:0xe21110ff,0x3018:0x0a000026,
        0x30b8:0xe5c51036,0x3348:0xe5c51036}
    require(all(struct.unpack_from('<I',body,at)[0]==word for at,word in expected.items()),
        'Original CC91 zero/default and reset field36 contract changed')
    rejected=[]
    def bounded_require(condition,message):
        if not condition and message in('Unqualified performed controller','Unqualified non-initial controller reset'):
            rejected.append(message)
        else:require(condition,message)
    value=FunctionType(original.perform.__code__,dict(original.perform.__globals__,require=bounded_require),
        argdefs=original.perform.__defaults__)(score,loop_passes=3)
    events,notes=value['timeline'],value['notes']
    require({r['argument']for r in events if r['kind']=='control'}=={1,7,10,11,32,91,121},
        'Unknown controller entered T. Hawk source expansion')
    zero=zero_controls(events,notes);resets=[]
    for row in events:
        if row['kind']!='control'or row['argument']!=121 or row['time_fixed']==0:continue
        channel,index,now=row['channel'],row['performed_index'],row['time_fixed']
        prior=[n for n in notes if n['channel']==channel and n['performed_index']<index]
        require(not any(n['time_fixed']+n['gate_fixed']>now for n in prior),'T. Hawk reset intersects a held note')
        following=[r for r in events if r.get('channel')==channel and r['performed_index']>index]
        first=next((n for n,r in enumerate(following)if r['kind']=='note'),None)
        if first is not None:
            setup=following[:first];controls={r['argument']:r['value']for r in setup if r['kind']=='control'}
            require(all(k in controls for k in(1,7,10,11,32))and any(r['kind']=='program'for r in setup),
                'T. Hawk reset reaches a note without explicit setup')
        resets.append({'channel':channel,'time_fixed':now,'performed_index':index,'held_notes':0,
            'subsequent_note_has_explicit_setup':first is not None})
    require(len(rejected)==len(zero)+len(resets),'Unhandled source-controller refusal was suppressed')
    return value,{'passed':True,'scope':'T. Hawk BGM33 only; per-channel pre-note default-send packets and bounded resets',
        'score_sha256':SCORE,'driver':reset,'zero_CC91_packets':zero,'noninitial_resets':resets,
        'original_CC91_zero_branch_sha256':digest(body[0x3014:0x3160]),
        'reset_clears_channel_field_36':True,'all_zero_packets_follow_reset_before_notes':True,
        'source_packets_retained_in_timeline':True,'new_native_effects_engine':False,'held_voice_cuts':0,
        'nonzero_or_live_CC91_and_AICA_effects_quality_accepted':False}


