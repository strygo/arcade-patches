"""Pinned original score conversion functions; no checkout dependency."""
from __future__ import annotations
from score_support import require
import numpy as np
import render_upper_guile_preview as preview
import struct
import upper_music_envelopes as envelope
import upper_music_performance as performance
import upper_music_sources as music

RATE = preview.RATE


def voice_waves(body, program_blob, performed, count, tables):
    """Match the frozen renderer's wave per activation; generate each once."""
    voices, demand = performance.voice_demand(performed, program_blob)
    events = {ch: [r for r in performed['timeline'] if r.get('channel') == ch and
                  r['kind'] in ('pitch', 'control')] for ch in performed['summary']['channels']}
    previous = -1
    for voice in voices:
        onset = round(voice['time_fixed']/performance.FIXED_UNITS_PER_SECOND*RATE)
        require(onset >= previous, 'Performed onsets are not ordered'); previous = onset
        if onset >= count: continue
        note = performed['notes'][voice['note_index']]
        record = music.bounded(program_blob, voice['split_record_offset'], 48, 'Audition split')
        fields = envelope.envelope_fields(voice['envelope_register'])
        require(fields['key_rate_scaling'] == 15 and not fields['loop_start_link'] and
                record[45:47] == b'\0\0', 'Only unlinked KRS-disabled ordinary key-off qualified')
        require(voice['loop_enabled'] or struct.unpack_from('<H', record, 14)[0] & 0xe0 == 0,
                'Nonloop pitch-LFO completion is not qualified')
        fields['release'] = max(1, fields['release'])
        bend = 64 if voice['pitch_raw'] is None else voice['pitch_raw']
        pitch = envelope.manatee_pitch(body, voice['key'], voice['base_key'], bend_raw=bend,
            bend_high=voice['bend_range_high'], bend_low=voice['bend_range_low'])
        gate = round(voice['gate_fixed']/performance.FIXED_UNITS_PER_SECOND*RATE)
        at_gate, _ = envelope.gate_envelope_volume(fields, gate, pitch, tables)
        tail = envelope.release_bound(pitch, fields, tables['DR'], at_gate)['bound_frames_at_44100']
        require(tail is not None, 'Infinite diagnostic release')
        n = min(count-onset, gate+tail)
        changes = []; controls = dict(note['controls_at_onset'])
        for event in events[voice['channel']]:
            at = round((event['time_fixed']-voice['time_fixed'])/performance.FIXED_UNITS_PER_SECOND*RATE)
            if (0 < at < n or at == 0 and event['time_fixed'] == note['time_fixed'] and
                    event['performed_index'] > note['performed_index']): changes.append((at, event))
        boundaries = sorted({0, n, *[at for at, _ in changes]})
        steps = np.empty(n); gains = np.empty(n); pans = np.empty((n, 2))
        for first, last in zip(boundaries, boundaries[1:]):
            for at, event in changes:
                if at != first: continue
                if event['kind'] == 'pitch': bend = event['argument']
                else: controls[str(event['argument'])] = event['value']
            current = envelope.manatee_pitch(body, voice['key'], voice['base_key'], bend_raw=bend,
                bend_high=voice['bend_range_high'], bend_low=voice['bend_range_low'])
            steps[first:last] = envelope.sample_step(current)/4096.
            gain, pan = preview.source_controls(body, record, voice['curve_value_at_velocity'], controls)
            gains[first:last] = gain; pans[first:last] = pan
        position = np.r_[0., np.cumsum(steps[:-1])]
        pcm = np.frombuffer(music.bounded(program_blob, voice['sample_offset'],
            voice['sample_frames']*2, 'Audition PCM16'), '<i2').astype(np.float64)
        if voice['loop_enabled']:
            require(0 <= voice['loop_start'] < len(pcm), 'Audition loop bounds')
            position = np.where(position < len(pcm), position,
                voice['loop_start']+np.mod(position-len(pcm), len(pcm)-voice['loop_start']))
            next_pos = np.floor(position).astype(int)+1
            next_pos[next_pos >= len(pcm)] = voice['loop_start']
        else:
            n = min(n, int(np.searchsorted(position, len(pcm)-1, side='left'))+1)
            position = position[:n]; next_pos = np.minimum(np.floor(position).astype(int)+1, len(pcm)-1)
        require(n > 0, 'Empty audition voice')
        base_pos = np.minimum(np.floor(position).astype(int), len(pcm)-1)
        fraction = position-base_pos
        aeg = preview.aeg_curve(fields, pitch, n, gate, tables)
        wave = (pcm[base_pos]*(1-fraction)+pcm[next_pos]*fraction)*aeg*gains[:n]
        yield voice, onset, gate, wave[:, None]*pans[:n], aeg


def select_slot(active, onset, budget):
    """Release-only adaptation: never replace a currently held activation."""
    require(type(budget) is int and 1 <= budget <= 16, 'Music budget outside native PCM count')
    for slot in [s for s, row in active.items() if row['onset']+len(row['wave']) <= onset]: del active[slot]
    free = next((s for s in range(budget) if s not in active), None)
    if free is not None: return free, None
    eligible = [(s, r) for s, r in active.items() if r['onset']+r['gate'] <= onset]
    if not eligible: return None, None
    slot, row = min(eligible, key=lambda pair: (float(pair[1]['aeg'][onset-pair[1]['onset']]),
        pair[1]['onset']+len(pair[1]['wave']), pair[1]['record']['voice_index']))
    return slot, row


