"""Pinned original score conversion functions; no checkout dependency."""
from __future__ import annotations
from hsf2_music_install import prove_installed_graph

LINEAR_BYTES=0x80000


