"""Pinned original score conversion functions; no checkout dependency."""
from __future__ import annotations
from score_support import require

def payload_region(region):
    require(len(region) == 0x50000 and not any(region[0x8000:0x10000])
            and not any(region[0x48000:]), 'Unexpected mapped Z80 topology')
    return region[:0x8000] + region[0x10000:0x48000]


