"""Pinned original score conversion functions; no checkout dependency."""
from __future__ import annotations
from bisect import bisect_left
from fractions import Fraction
from functools import lru_cache
import hashlib
import math
import struct

SOURCE_SHA256 = '50df03344cf604262fd98f8157b4bb96de5806ef0be5d3cf9f9140b30b5c5b35'


DSP_RAW_SHA256 = '524a25bcd153be24594d37c0dbd334fe4f384f77da73c2058dc60fc1f581cf18'


TEMPO_INDEX = 78


TEMPO_INCREMENT = 256


FLAT_ARTICULATION = bytes([63, 0, 127, 0, 63, 0, 0, 0])


CONSUMER_SPANS = (
    (0xf6c, 0x1270, 'f5cff084f2621017b73da73d1dc37184655844071c35688772f0fd604cbf86f3'),
    (0x1270, 0x193b, '02d2cfaf021deb4e6a03a5c94f66594c379a06878112a7974fadfa4658ea34e7'),
    (0x1a2b, 0x2140, '902534b2ee8fac5b0121a70b23a2a3da7f54c078f871bd339ff00bf0fe4e4282'),
)


def require(ok, message):
    if not ok:
        raise ValueError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def u16(data, at):
    return struct.unpack_from('<H', data, at)[0]


def resident_contract(flat):
    require(len(flat) == 0x40000 and digest(flat) == SOURCE_SHA256,
            'Canonical retained SFA3 QSound 1.71 payload required')
    require(u16(flat, 0x3492+TEMPO_INDEX*2) == TEMPO_INCREMENT,
            'Native exact music tempo changed')
    expected = ([0, 768, 1536, 3072, 6144, 12288, 24576, 49152],
                [0, 0, 2304, 4608, 9216, 18432, 36864, 0],
                [0, 512, 1024, 2048, 4096, 8192, 16384, 32768])
    require(tuple(list(struct.unpack_from('<8H', flat, at)) for at in
                  (0x1230, 0x1240, 0x1250)) == expected,
            'Native duration lookup changed')
    for first, last, pin in CONSUMER_SPANS:
        require(digest(flat[first:last]) == pin, 'Native score consumer changed')
    return {'resident_sha256': SOURCE_SHA256, 'tempo_index': TEMPO_INDEX,
            'tempo_increment': TEMPO_INCREMENT, 'tempo_offset_required': 0,
            'music_hz_fraction': [125, 2], 'duration_values': expected,
            'consumer_spans': [{'first': a, 'last': b, 'sha256': p}
                               for a, b, p in CONSUMER_SPANS],
            'flat_articulation': list(FLAT_ARTICULATION),
            'gain_policy': 'flat native envelope; explicit relative amplitude at music updates',
            'qualification': 'encoded byte semantics/model only; live runtime acceptance is separate'}


def volume(index):
    require(0 <= index <= 127, 'Native amplitude lookup selector range')
    return bytes([7, index])


def pan(value):
    require(0 <= value <= 32, 'Native pan coordinate range')
    return bytes([24, value])


def choose_volume(flat, gain):
    """Nearest native relative channel amplitude, maximum selector = unity.

    This represents amplitude before global/channel-master multiplications and
    QSound stereo/filter processing, which remain independent runtime state.
    """
    gain = Fraction(gain)
    require(0 <= gain <= 1, 'Relative amplitude must be in [0,1]')
    values = struct.unpack_from('<128H', flat, 0x2e92)
    target = gain*values[-1]
    return min(range(128), key=lambda i: (abs(values[i]-target), i))


def volume_gain(flat, index):
    require(0 <= index <= 127, 'Native volume selector range')
    return Fraction(u16(flat, 0x2e92+2*index), u16(flat, 0x2e92+254))


def native_pan_tables(dsp_raw):
    """Pinned DSP-ROM direct/filtered gain coefficients, before delay/FIR.

    The canonical dl-1425.bin member is LE16 on disk. Runtime word swapping
    installs the same values in its big-endian ROM region. QSound HLE consumes
    dry at pan+0, wet at pan+98; the right channel adds196 words.
    """
    require(len(dsp_raw) == 24576 and digest(dsp_raw) == DSP_RAW_SHA256,
            'Canonical dl-1425.bin DSP member required')
    return tuple(tuple(Fraction(-v, 16384) for v in
                       struct.unpack_from('<33h', dsp_raw, (0x110+offset)*2))
                 for offset in (0, 98, 196, 294))


def choose_pan(dsp_raw, left, right):
    """Nearest native direct-path stereo gains; filtered path is reported.

    Source AICA attenuation has no QSound spatial-filter equivalent. This
    makes the direct-path mapping reproducible without claiming full stereo
    waveform/pan equivalence. No gain normalization is hidden here.
    """
    left, right = Fraction(left), Fraction(right)
    require(0 <= left <= 1 and 0 <= right <= 1, 'Source stereo amplitude bounds')
    ld, lw, rd, rw = native_pan_tables(dsp_raw)
    coordinate = min(range(33), key=lambda p: ((ld[p]-left)**2+(rd[p]-right)**2,
                                              abs(p-16), p))
    def pair(a, b):
        return [[a.numerator, a.denominator], [b.numerator, b.denominator]]
    return {'pan': coordinate, 'source_direct_fraction': pair(left, right),
            'native_direct_fraction': pair(ld[coordinate], rd[coordinate]),
            'direct_error_fraction': pair(ld[coordinate]-left, rd[coordinate]-right),
            'native_filtered_fraction': pair(lw[coordinate], rw[coordinate]),
            'policy': 'nearest direct-path amplitude only; spatial FIR/delay/effects equality unqualified'}


def articulation_parameters(flat, articulation):
    require(len(articulation) == 8 and articulation[0] < 64 and
            articulation[1] < 64 and articulation[2] < 128 and
            articulation[3] < 64 and articulation[4] < 64,
            'Native articulation selectors')
    return dict(attack=u16(flat, 0x3092+articulation[0]*2),
                decay=u16(flat, 0x3112+articulation[1]*2),
                sustain=u16(flat, 0x2f92+articulation[2]*2),
                sustain_rate=u16(flat, 0x3112+articulation[3]*2),
                release=u16(flat, 0x3112+articulation[4]*2))


def resident_pitch_word(flat, pitch_fixed, descriptor_root=0x48):
    """Driver integer LUT result, restricted to its ordinary in-range branch.

    pitch_fixed is the native note accumulator (unsigned 8.8); descriptor root
    is the last descriptor byte. No sample-selector global-pitch bit or LFO is
    allowed by this compiler's instrument contract.
    """
    require(0 < pitch_fixed < 0x6c00 and 0 <= descriptor_root <= 255,
            'Native pitch accumulator/root bounds')
    coarse = (pitch_fixed >> 8)-1+0x3c-descriptor_root
    require(0 <= coarse < 108, 'Pitch requires unqualified native clipping branch')
    shift = flat[0x2145+coarse]
    relative = coarse-flat[0x21b1+shift]
    require(0 <= relative < 12, 'Native pitch interpolation index')
    interpolation = flat[0x2292+relative*256+(pitch_fixed & 255)] << shift
    return (u16(flat, 0x21ba+coarse*2)+interpolation) & 65535


@lru_cache(maxsize=4)
def _pitch_candidates(flat, descriptor_root):
    require(digest(flat) == SOURCE_SHA256, 'Native pitch table identity')
    rows = {}
    for high in range(1, 108):
        if not 0 <= high-1+0x3c-descriptor_root < 108:
            continue
        for low in range(256):
            fixed = high*256+low
            word = resident_pitch_word(flat, fixed, descriptor_root)
            rows.setdefault(word, fixed)
    return tuple(sorted(rows)), rows


def choose_pitch(flat, desired_word, descriptor_root=0x48):
    """Nearest integer DSP pitch word, with exact rational error reporting."""
    desired_word = Fraction(desired_word)
    require(desired_word > 0, 'Desired native sample step must be positive')
    words, pitches = _pitch_candidates(flat, descriptor_root)
    require(words[0] <= desired_word <= words[-1], 'Desired sample step exceeds qualified native pitch range')
    at = bisect_left(words, desired_word)
    candidates = words[max(0, at-1):min(len(words), at+1)]
    word = min(candidates, key=lambda w: (abs(w-desired_word), w))
    error = Fraction(word)-desired_word
    return {'pitch_fixed': pitches[word], 'native_word': word,
            'desired_word_fraction': [desired_word.numerator, desired_word.denominator],
            'word_error_fraction': [error.numerator, error.denominator],
            'error_cents': 1200*math.log2(float(Fraction(word)/desired_word)),
            'descriptor_root': descriptor_root}


def wait_ticks(ticks):
    """Exact integer music updates; rests preserve a sounding native voice."""
    require(isinstance(ticks, int) and ticks >= 0, 'Nonnegative integer native wait required')
    out = bytearray()
    # Triplet durations with increment 256 provide exact powers of two. Once
    # set, their flag persists across rests, so a run needs one setter only.
    large, remaining = divmod(ticks, 128)
    durations = [7]*large + [i for i in range(6, 0, -1) if remaining & (1 << i)]
    if durations:
        out.extend([4, 32]); out.extend(i << 5 for i in durations)
    if remaining & 1:
        out.extend([4, 0, 2, 0x20])
    return bytes(out)


def channel_start(instrument_bank):
    require(0 <= instrument_bank <= 255, 'Native instrument bank range')
    # Disable retained LFO and portamento state explicitly. Global transpose
    # and music tempo are identical for all sixteen slots. F022 must be zero.
    return bytes([5, TEMPO_INDEX, 6, 0, 7, 0, 9, 0, 10, 0, 13, 0,
                  27, 0, 0, 27, 1, 0, 27, 2, 0, 31, instrument_bank])


