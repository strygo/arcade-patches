"""Pinned original score conversion functions; no checkout dependency."""
from __future__ import annotations
from score_support import digest
from score_support import require
from types import FunctionType
import inspect
import struct

INDEX,INCREMENT,PRIOR=108,512,354


ADDRESS=0x3492+INDEX*2


def setup():
    import upper_music_native as native,upper_music_gate_encoding as gate
    import upper_music_duration_packing as packed,enhanced_qsound as qsound
    original_contract=native.resident_contract;source_sha=native.SOURCE_SHA256
    original_payload=qsound.payload_region;changes=[]
    def view(flat):
        require(digest(flat)==source_sha,'Clock projection requires the canonical SFA3 sound input')
        result=bytearray(flat);struct.pack_into('<H',result,ADDRESS,INCREMENT);return bytes(result)
    def contract(flat):
        original=bytearray(flat);struct.pack_into('<H',original,ADDRESS,PRIOR)
        r=original_contract(bytes(original))
        require(native.u16(flat,ADDRESS)==INCREMENT,'Planned native tempo cell differs')
        return {**r,'tempo_index':INDEX,'tempo_increment':INCREMENT,
            'canonical_sound_sha256':source_sha,'planned_sound_sha256':digest(flat),
            'changed_lookup_word':ADDRESS,'new_driver_instructions':0}
    native.resident_contract=contract
    original_candidates=native._pitch_candidates
    def candidates(flat,descriptor_root):
        contract(flat)
        canonical=bytearray(flat);struct.pack_into('<H',canonical,ADDRESS,PRIOR)
        return original_candidates(bytes(canonical),descriptor_root)
    native._pitch_candidates=candidates
    native.channel_start=FunctionType(native.channel_start.__code__,dict(native.channel_start.__globals__,TEMPO_INDEX=INDEX))
    qsound.payload_region=lambda region:view(original_payload(region))
    def project(function,replacements,scope=None):
        text=inspect.getsource(function);original=text
        for before,after in replacements:
            require(text.count(before)==1,'Frozen native clock projection changed: '+before)
            text=text.replace(before,after)
        namespace=dict(function.__globals__,**(scope or {}));exec(compile(text,'<native tempo512 byte compiler>','exec'),namespace)
        changes.append({'function':function.__name__,'source_sha256':digest(original.encode()),
            'projection_sha256':digest(text.encode()),'replacements':[list(v)for v in replacements]})
        return namespace[function.__name__]
    gate.decode_channel=project(gate.decode_channel,[('tempo == 256','tempo == 512')])
    # A native triplet event has timer512. Multiplier255 gives gate510:
    # the next512-unit update expires the gate and reaches the parser together.
    def wait(state,ticks):
        require(type(ticks)is int and ticks>=0,'Native tempo512 wait bounds')
        result=native.wait_ticks(ticks*2)
        if ticks:state['flags']=32
        return result
    gate._wait=wait
    gate.compile_channel=project(gate.compile_channel,[
        ('(2, 255) if expiry is not None else (1, 128)','(1, 255)'),
        ('tick+(2 if arm is not None or timed_onset is not None else 1)','tick+1')])
    packed.duration_catalog=project(packed.duration_catalog,[
        ("require(value % 256 == 0, 'Native duration has noninteger exact-clock units')",
         'if value % 512: continue'),('value//256','value//512')])
    packed.compile_channel=project(packed.compile_channel,[
        ('gap >= (2 if plan is not None else 1)','gap >= 1'),
        ('variants = [(None, raw, 32, 2)]','variants = [(None, raw, 32, 1)]')])
    return {'lookup_index':INDEX,'lookup_address':ADDRESS,'lookup_word':INCREMENT,
        'prior_word':PRIOR,'native_updates_per_second':[125,2],'projections':changes,
        'default_and_final_tempo_indices_preserved':[0,255],
        'new_driver_instructions':0,'new_persistent_RAM':0,
        'current_image_lookup_ownership_and_live_playback_qualified':False}


