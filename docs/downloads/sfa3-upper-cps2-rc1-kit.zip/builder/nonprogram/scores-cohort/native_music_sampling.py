"""Pinned original score conversion functions; no checkout dependency."""
from __future__ import annotations
from fractions import Fraction
from score_support import require
import numpy as np

HZ=Fraction(125,2)


RATE=44100


def schedule(body,program,performed,tables,helpers):
    audition,preview,envelope,performance=helpers
    tick=lambda frame:round(Fraction(frame,RATE)*HZ)
    count=round(performed['summary']['performed_nominal_seconds']*RATE)
    active={};rows=[];controls={};short=[]
    changes={ch:[v for v in performed['timeline']if v.get('channel')==ch and v['kind']in('pitch','control')]
        for ch in performed['summary']['channels']}
    for voice,onset,gate,wave,aeg in audition.voice_waves(body,program,performed,count,tables):
        require(len(aeg)>0,'Empty source activation')
        first=tick(onset);natural_last=tick(onset+len(aeg));last=max(first+1,natural_last)
        boundaries=np.clip(np.array([round(Fraction(t,HZ)*RATE)-onset for t in range(first,last)]),0,len(aeg)-1)
        scalar=aeg[boundaries].copy()
        if natural_last==first:
            require(not voice['loop_enabled'],'Sub-update looping activation needs separate qualification')
            # Preserve a sounding event even when the entire source one-shot
            # falls between two music-clock updates. Use its source wave-energy
            # weighted envelope, rather than a possibly silent final sample.
            power=np.sum(wave*wave,axis=1)
            scalar[0]=float(np.dot(power,aeg)/power.sum())if power.sum()else 0.
            short.append({'voice_index':voice['voice_index'],'program':voice['program'],
                'source_frames':len(aeg),'onset_tick':first,'reserved_updates':1,
                'envelope_scalar':float(scalar[0]),'PCM_natural_end_preserved':True})
        slot,old=audition.select_slot(active,first,16)
        require(slot is not None,'Native music contexts would interrupt a held activation')
        if old is not None:
            require(first>=old['onset']+old['gate'],'Native source held note cut')
            old['record'].update(end_tick=first,action='release_tail_trimmed')
        row=dict(voice,onset_frame=onset,gate_end_frame=onset+gate,natural_end_frame=onset+len(aeg),
            actual_end_frame=onset+len(aeg),onset_tick=first,end_tick=last,gate_end_tick=tick(onset+gate),
            slot=slot,action='retained')
        rows.append(row);active[slot]={'onset':first,'gate':max(1,min(last-first,max(0,tick(onset+gate)-first))),
            'wave':scalar,'aeg':scalar,'record':row}
        note=performed['notes'][voice['note_index']];state=dict(note['controls_at_onset'])
        record=program[voice['split_record_offset']:voice['split_record_offset']+48]
        bend=64 if voice['pitch_raw']is None else voice['pitch_raw']
        own=[v for v in changes[voice['channel']]if(v['time_fixed'],v['performed_index'])>
            (note['time_fixed'],note['performed_index'])];at=0;output=[]
        for i,t in enumerate(range(first,last)):
            source_time=max(note['time_fixed'],round(Fraction(t,HZ)*performance.FIXED_UNITS_PER_SECOND))
            while at<len(own)and own[at]['time_fixed']<=source_time:
                change=own[at];at+=1
                if change['kind']=='pitch':bend=change['argument']
                else:state[str(change['argument'])]=change['value']
            gain,pan=preview.source_controls(body,record,voice['curve_value_at_velocity'],state)
            pitch=envelope.manatee_pitch(body,voice['key'],voice['base_key'],bend_raw=bend,
                bend_high=voice['bend_range_high'],bend_low=voice['bend_range_low'])
            output.append({'tick':t,'gain':float(gain*scalar[i]),'base_gain':float(gain),
                'envelope_scalar':float(scalar[i]),'pan':list(pan),'source_step':envelope.sample_step(pitch)})
        controls[voice['voice_index']]=output
    for row in rows:controls[row['voice_index']]=[v for v in controls[row['voice_index']]if v['tick']<row['end_tick']]
    for slot in range(16):
        own=[v for v in rows if v['slot']==slot]
        require(all(a['end_tick']<=b['onset_tick']for a,b in zip(own,own[1:])),'Native context ownership overlap')
    return rows,controls,{'sub_update_one_shots':short,'source_activations':len(rows),
        'release_tail_cuts':sum(v['action']=='release_tail_trimmed'for v in rows),'held_voice_cuts':0,
        'minimum_one_update_reservation_extends_PCM':False,'listening_accepted':False}


