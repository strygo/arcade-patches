"""Pinned original score conversion functions; no checkout dependency."""
from __future__ import annotations
from collections import Counter
from collections import defaultdict
from fractions import Fraction
from score_support import digest
from score_support import require
import compile_upper_packed_prefix as prefix
import upper_music_articulations as articulation
import upper_music_performance as performance

SOURCE_PERIOD_FIXED = 312982494


NATIVE_PERIOD_PROPOSAL = 4776


IGNORE = {'performed_index', 'loop_iteration', 'note_index', 'time_fixed', 'nominal_tick'}


def boundaries(performed):
    start = performed['summary']['first_loop']
    source = [start, *performed['summary']['loop_ends']]
    return [dict(boundary=n, time_fixed=r['time_fixed'], source_nominal_tick=r['nominal_tick'],
        native_tick=round(Fraction(r['time_fixed'], performance.FIXED_UNITS_PER_SECOND)*articulation.MUSIC_HZ),
        source_frame=round(Fraction(r['time_fixed'], performance.FIXED_UNITS_PER_SECOND)*44100))
        for n, r in enumerate(source)]


def normalized_packets(rows, first, last):
    return [{k: v for k, v in r.items() if k not in IGNORE} |
        {'relative_time_fixed': r['time_fixed']-first['time_fixed'],
         'relative_nominal_tick': r['nominal_tick']-first['source_nominal_tick']}
        for r in rows if first['time_fixed'] <= r['time_fixed'] < last['time_fixed'] and r['kind'] != 'loop']


def controller_state(timeline, fixed):
    state = [dict(bank=None, program=None, pitch_raw=None, controls={}) for _ in range(16)]
    for r in timeline:
        if r['time_fixed'] >= fixed: break
        if r['kind'] not in ('control', 'program', 'pitch'): continue
        s = state[r['channel']]
        if r['kind'] == 'pitch': s['pitch_raw'] = r['argument']
        elif r['kind'] == 'program': s['program'] = r['argument']
        else:
            if r['argument'] == 121: s['controls'] = {}; s['pitch_raw'] = None
            s['controls'][str(r['argument'])] = r['value']
            if r['argument'] == 32: s['bank'] = r['value'] & 15
    return state


def segment(rows, observations, first, last):
    output = []
    for r in rows:
        if not first['time_fixed'] <= r['time_fixed'] < last['time_fixed']: continue
        controls = []
        for own in observations[r['voice_index']]['controls']:
            event = dict(own, tick=own['tick']-first['native_tick'])
            if 'profile_key' in event: event.pop('profile_key'); event['instrument'] = r['profile_id']
            controls.append(event)
        output.append(dict(ordinal=len(output), voice_index=r['voice_index'], note_index=r['note_index'],
            channel=r['channel'], program=r['program'], key=r['key'], velocity=r['velocity'], layer=r['layer'],
            profile_key=r['profile_key'], profile_id=r['profile_id'], slot=r['slot'], action=r['action'],
            source_relative_onset_fixed=r['time_fixed']-first['time_fixed'], gate_fixed=r['gate_fixed'],
            onset_frame=r['onset_frame']-first['source_frame'], gate_frame=r['gate_end_frame']-first['source_frame'],
            natural_end_frame=r['natural_end_frame']-first['source_frame'],
            actual_end_frame=r['actual_end_frame']-first['source_frame'],
            onset_tick=r['onset_tick']-first['native_tick'], gate_tick=r['gate_end_tick']-first['native_tick'],
            end_tick=r['end_tick']-first['native_tick'], controls=controls))
    return output


def compare_segments(left, right):
    require(len(left) == len(right), 'Loop activation count changed')
    fields = ('channel', 'program', 'key', 'velocity', 'layer', 'profile_key', 'source_relative_onset_fixed',
              'gate_fixed', 'slot', 'action', 'onset_frame', 'gate_frame', 'natural_end_frame',
              'actual_end_frame', 'onset_tick', 'gate_tick', 'end_tick', 'controls')
    changes = {k: [] for k in fields}; destinations = defaultdict(set)
    for a, b in zip(left, right):
        destinations[a['slot']].add(b['slot'])
        for field in fields:
            if a[field] != b[field]:
                changes[field].append(dict(ordinal=a['ordinal'], left=a[field], right=b[field]))
    fixed_source_equal = all(not changes[k] for k in fields[:8])
    consistent = all(len(v) == 1 for v in destinations.values())
    mapping = {str(k): next(iter(v)) for k, v in sorted(destinations.items())} if consistent else None
    bijective = mapping is not None and len(set(mapping.values())) == len(mapping)
    return dict(activations=len(left), fixed_source_identity_and_gate_equal=fixed_source_equal,
        differences={k: {'count': len(v), 'examples': v[:8]} for k, v in changes.items()},
        slot_destinations={str(k): sorted(v) for k, v in sorted(destinations.items())},
        single_slot_permutation_possible=bijective, slot_permutation=mapping if bijective else None)


def carry_snapshot(rows, boundary):
    result = []
    for r in rows:
        source_crossing = r['onset_frame'] < boundary['source_frame'] < r['actual_end_frame']
        native_crossing = r['onset_tick'] < boundary['native_tick'] < r['end_tick']
        if not (source_crossing or native_crossing): continue
        result.append(dict(slot=r['slot'], voice_index=r['voice_index'], profile_id=r['profile_id'],
            profile_key=r['profile_key'], channel=r['channel'], program=r['program'], key=r['key'],
            source_crossing=source_crossing, native_crossing=native_crossing,
            source_held=r['gate_end_frame'] > boundary['source_frame'],
            native_held=r['gate_end_tick'] > boundary['native_tick'],
            source_onset_age_fixed=boundary['time_fixed']-r['time_fixed'],
            source_age_frames=boundary['source_frame']-r['onset_frame'],
            source_gate_remaining_frames=r['gate_end_frame']-boundary['source_frame'],
            source_tail_remaining_frames=r['actual_end_frame']-boundary['source_frame'],
            native_age_ticks=boundary['native_tick']-r['onset_tick'],
            native_gate_remaining_ticks=r['gate_end_tick']-boundary['native_tick'],
            native_tail_remaining_ticks=r['end_tick']-boundary['native_tick']))
    return sorted(result, key=lambda r: r['slot'])


def cyclic_intervals(template, period):
    """Check duplicating measured intervals; never trim or reassign a voice."""
    slots = defaultdict(list)
    for r in template: slots[r['slot']].append(r)
    collisions = []
    for slot, own in sorted(slots.items()):
        own.sort(key=lambda r: r['onset_tick'])
        for n, row in enumerate(own):
            following = own[(n+1) % len(own)]
            birth = following['onset_tick']+(period if n == len(own)-1 else 0)
            if row['end_tick'] > birth:
                collisions.append(dict(slot=slot, previous_ordinal=row['ordinal'],
                    next_ordinal=following['ordinal'], seam=n == len(own)-1,
                    overlap_ticks=row['end_tick']-birth,
                    held_overlap=row['gate_tick'] > birth))
    return dict(period_updates=period, slots_used=sorted(slots), collisions=collisions,
                measured_intervals_fit_without_extra_tail_cut=not collisions,
                source_absolute_timing_preserved=False, native_runtime_proven=False)


def rotated_steady_events(template, period=NATIVE_PERIOD_PROPOSAL):
    """Candidate event API cut at each slot's first genuine steady onset.

    This merely exposes the measured events and conflicts. It neither chooses
    a timing policy nor cuts a tail that extends past the next genuine onset.
    """
    channels = []
    for slot in range(16):
        own = sorted((r for r in template if r['slot'] == slot), key=lambda r: r['onset_tick'])
        require(own, 'Steady template leaves an unqualified empty slot')
        cut = own[0]['onset_tick']; events = []; omitted = []; outside = []; conflicts = []
        for row in own:
            for control in row['controls']:
                event = dict(control, tick=control['tick']-cut)
                (events if 0 <= event['tick'] < period else outside).append(event)
            end = row['end_tick']-cut
            if 0 <= end < period: events.append(dict(tick=end, kind='note_off'))
            elif end > period:
                conflicts.append(dict(ordinal=row['ordinal'], end_tick=end,
                    gate_tick=row['gate_tick']-cut, released_before_next_onset=row['gate_tick']-cut <= period,
                    required_extra_tail_cut_ticks=end-period))
            if row['gate_tick'] >= row['end_tick']: continue
            gate = row['gate_tick']-cut; onset = row['onset_tick']-cut
            if gate <= onset:
                omitted.append(dict(ordinal=row['ordinal'], onset_tick=onset, gate_tick=gate,
                                    reason='collapsed_gate'))
            elif gate < period: events.append(dict(tick=gate, kind='keyoff', onset_tick=onset))
            else: outside.append(dict(tick=gate, kind='keyoff', onset_tick=onset))
        channels.append(dict(slot=slot, cut_relative_to_source_global_boundary_tick=cut,
            first_genuine_onset_ordinal=own[0]['ordinal'], activations=len(own), period_updates=period,
            events=sorted(events, key=lambda r: r['tick']), omitted_collapsed_gate_requests=omitted,
            unmodified_events_outside_body=outside, measured_tails_crossing_next_genuine_onset=conflicts,
            candidate_only=True, timing_or_tail_policy_adopted=False))
    return channels


def analyze(performed, rows, observations):
    marks = boundaries(performed)
    require(len(marks) == 5 and all(b['time_fixed']-a['time_fixed'] == SOURCE_PERIOD_FIXED
        for a, b in zip(marks, marks[1:])), 'Four exact original periods required')
    parts = [segment(rows, observations, a, b) for a, b in zip(marks, marks[1:])]
    packets = [normalized_packets(performed['timeline'], a, b) for a, b in zip(marks, marks[1:])]
    notes = [normalized_packets(performed['notes'], a, b) for a, b in zip(marks, marks[1:])]
    snapshots = [dict(boundary=m, controllers_before=controller_state(performed['timeline'], m['time_fixed']),
                      continuing_voices=carry_snapshot(rows, m)) for m in marks]
    original = Fraction(SOURCE_PERIOD_FIXED, performance.FIXED_UNITS_PER_SECOND)
    proposed = Fraction(NATIVE_PERIOD_PROPOSAL, articulation.MUSIC_HZ)
    report = dict(boundaries=marks, source_period_fixed=SOURCE_PERIOD_FIXED,
        source_period_seconds_fraction=[original.numerator, original.denominator],
        source_period_native_updates_fraction=[(original*articulation.MUSIC_HZ).numerator,
                                               (original*articulation.MUSIC_HZ).denominator],
        constant_period_proposal_updates=NATIVE_PERIOD_PROPOSAL,
        constant_period_minus_source_seconds_fraction=[(proposed-original).numerator, (proposed-original).denominator],
        constant_period_minus_source_milliseconds=float(proposed-original)*1000,
        timing_policy_adopted=False,
        raw_packets_equal=[packets[0] == p for p in packets],
        note_state_equal=[notes[0] == n for n in notes],
        raw_packet_counts=[len(p) for p in packets], activation_counts=[len(p) for p in parts],
        raw_packet_sha256=[performance.json_digest(p) for p in packets],
        note_state_sha256=[performance.json_digest(n) for n in notes],
        source_first_to_second=compare_segments(parts[0], parts[1]),
        source_second_to_third=compare_segments(parts[1], parts[2]),
        terminal_fourth_pass_excluded_from_tail_comparison=True,
        seam_snapshots=snapshots,
        steady_native_template_interval_check=cyclic_intervals(parts[1], NATIVE_PERIOD_PROPOSAL),
        collapsed_gates_by_pass=[sum(r['gate_tick'] <= r['onset_tick'] for r in p) for p in parts],
        native_loop_constraints=[
            'Choose and declare a timing policy: a constant4776-update loop is4.25830078125ms longer than the original period every cycle.',
            'Preserve any continuing activation across the branch: sample cursor, pitch/rate, phase/level, gate remainder and controller state cannot be reset merely to close the loop.',
            'A fixed-slot template must satisfy cyclic interval ownership; any permutation or seam tail cut is a separate measured scheduling change.',
            'Retain actual parser mode, coarse/fine pitch state, instrument/root/fine, tempo/duration state and timer residue at each channel entry; a musical-state match alone does not prove byte-level branch closure.',
            'Packed wait/held/parser changes alter AEG update opportunities; final repeating bytes need their own decoded chronology and live native gate.'])
    return parts, report


def bind_four_pass_resources(flat, pcm, sample_report, profiles, rows, qualified_note_count,
                             fit_receipt, art_payload):
    """Project actual four-pass gate populations onto the original three passes.

    Copies preserve every source field. Counts are recomputed from actual
    selected rows; the full four-pass profiles/rows/observations stay intact.
    """
    pinned = {p['profile_key']: p for p in fit_receipt['fit']['profiles']}
    require(set(profiles) == set(pinned), 'Original fitted profile inventory differs')
    ready = {}; scoped = [r for r in rows if r['note_index'] < qualified_note_count]
    require(len(scoped) == sum(p['activations'] for p in pinned.values()) == 5399,
            'Original three-pass activation projection differs')
    for key, p in profiles.items():
        expected = pinned[key]
        for field in ('profile_id', 'source_sample_sha256', 'envelope_register', 'source_offset',
                      'source_fields', 'source_rates', 'programs', 'split_records'):
            require(p[field] == expected[field], 'Original fitted profile field differs: '+field)
        counts = Counter(r['gate_end_frame']-r['onset_frame'] for r in scoped if r['profile_key'] == key)
        projected = [g | {'activations': counts[g['gate_frames']]} for g in p['source_gate_profiles']]
        require(projected == expected['source_gate_profiles'],
                'Actual projected three-pass source gate fields/counts differ')
        ready[key] = p | {'source_gate_profiles': projected}
    instruments, descriptors, arts, bindings = prefix.bind_resources(flat, pcm, sample_report,
        ready, fit_receipt['fit'])
    require(digest(art_payload) == prefix.ARTICULATION_SHA256, 'Frozen fit payload differs')
    return dict(sample_banks=pcm, instruments=instruments, descriptors=descriptors,
                articulations=art_payload, articulation_map=arts), bindings, ready


