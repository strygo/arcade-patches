"""Pinned original score conversion functions; no checkout dependency."""
from __future__ import annotations
from audit_qsound_frontend import instruction_size
import struct

def s16be(data, at):
    return struct.unpack_from('>h', data, at)[0]


def successors(data, pc, newer):
    op = data[pc]; size = instruction_size(data, pc, newer)
    if op == 23:
        return []
    if op == 22:
        return [pc+size+s16be(data, pc+1)]
    if 14 <= op <= 21:
        return [pc+size, pc+size+s16be(data, pc+2)]
    return [pc+size]


