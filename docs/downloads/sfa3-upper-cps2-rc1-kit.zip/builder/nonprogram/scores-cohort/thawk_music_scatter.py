"""Pinned original score conversion functions; no checkout dependency."""
from __future__ import annotations
from score_support import require
import struct

def layout(channels,holes,*,size=0x80000,relay_runs=()):
    import upper_music_loop_layout as logical
    import upper_music_install512 as native
    resources,translation,by_channel,source_proof=logical.logical_score(channels)
    source=resources['scores.bin'];free=[[r['start'],r['start']+r['bytes']]for r in holes]
    require(free==sorted(free)and all(0<=a<z<=size for a,z in free),'Owned sound span bounds/order differ')
    require(all(z<=b for(a,z),(b,end)in zip(free,free[1:])),'Owned sound spans overlap')
    cells=set()
    for relay in relay_runs:
        a=relay['start'];z=a+relay['bytes']
        part=next((p for p in free if p[0]<=a and z<=p[1]),None)
        require(part is not None,'Relay pool escapes proven free spans')
        free.remove(part)
        if part[0]<a:free.append([part[0],a])
        if z<part[1]:free.append([z,part[1]])
        cells.update(range(a,z-2,3))
    free.sort()
    # Tiny spans cannot carry a useful fragment plus its fallthrough. Use
    # those as relay cells, with spare cells in larger spans across banks.
    for part in free:
        length=part[1]-part[0]
        reserved=12 if length>=128 else 3 if length>=24 or 3<=length<=6 else 0
        cells.update(range(part[0],part[0]+reserved,3));part[0]+=reserved
    def take(length,lo=0,hi=size):
        for part in free:
            if lo<=part[0]and part[0]+length<=min(hi,part[1]):
                at=part[0];part[0]+=length;return at
        raise ValueError('Proven free sound spans cannot fit the requested header/prefix')
    header=take(33);mapping={};bridges=[];writes=[]
    starts=translation['commands'][0]['channel_offsets'];prefixes=set()
    for rows in by_channel:
        if not rows:continue
        row=rows[0];length=row['output_bytes'];at=take(length+3,header+33,header+65536)
        mapping[row['output']]=at;prefixes.add(row['output'])
        bridges.append(dict(address=at+length,target_logical=row['output']+length,
            kind='seed_fallthrough',source_group=row['source']))
    active=0;fragment=[];cursor=0;limit=0
    def close():
        nonlocal fragment,cursor
        if fragment:
            last=fragment[-1]
            if last['source_opcode']not in(22,23):
                bridges.append(dict(address=cursor,target_logical=last['output']+last['output_bytes'],
                    kind='fallthrough_bridge',source_group=last['source']))
                cursor+=3
            free[active][0]=cursor;fragment=[]
    for row in translation['instruction_map']:
        if row['output']in prefixes:continue
        if fragment and fragment[-1]['output']+fragment[-1]['output_bytes']!=row['output']:close()
        if not fragment:
            while active<len(free)and free[active][1]-free[active][0]<row['output_bytes']+3:active+=1
            require(active<len(free),'Complete native music exceeds the proven fragmented capacity')
            cursor,limit=free[active]
        if cursor+row['output_bytes']+3>limit:
            close();active+=1
            while active<len(free)and free[active][1]-free[active][0]<row['output_bytes']+3:active+=1
            require(active<len(free),'Complete native music exhausts fragmented sound spans')
            cursor,limit=free[active]
        mapping[row['output']]=cursor;cursor+=row['output_bytes'];fragment.append(row)
    close()
    for a,z in free:
        cells.update(range(a,z-2,3))
    def route(origin_end,target,depth=0):
        require(depth<64,'Unbounded native sound relay chain')
        if -32768<=target-origin_end<=32767:return target
        candidates=[at for at in cells if -32768<=at-origin_end<=32767 and
            (origin_end<at<target if target>origin_end else target<at+3<origin_end)]
        require(candidates,'No proven free native relay connects '+hex(origin_end)+' to '+hex(target))
        cell=max(candidates)if target>origin_end else min(candidates);cells.remove(cell)
        destination=route(cell+3,target,depth+1)
        bridges.append(dict(address=cell,target=destination,kind='long_branch_relay'))
        return cell
    for row in list(bridges):
        row['target']=route(row['address']+3,mapping[row.pop('target_logical')])
    for row in translation['instruction_map']:
        pc=row['output'];at=mapping[pc];length=row['output_bytes'];blob=bytearray(source[pc:pc+length])
        if 14<=blob[0]<=22:
            field=1 if blob[0]==22 else 2;target=pc+length+struct.unpack_from('>h',blob,field)[0]
            landing=route(at+length,mapping[target]);struct.pack_into('>h',blob,field,landing-at-length)
        writes.append((at,bytes(blob),'music_instruction_group'))
    for row in bridges:
        writes.append((row['address'],b'\x16'+struct.pack('>h',row['target']-row['address']-3),row['kind']))
    head=bytearray(33)
    for n,start in enumerate(starts):
        if start:struct.pack_into('>H',head,1+2*n,mapping[start]-header)
    writes.append((header,bytes(head),'music_header'))
    occupied=[];payload=bytearray(b'\xff'*size)
    for at,blob,role in sorted(writes):
        require(any(r['start']<=at and at+len(blob)<=r['start']+r['bytes']for r in holes),
            'Native score write escapes its proven free span')
        require(not occupied or occupied[-1][1]<=at,'Native score instructions/relays overlap')
        occupied.append((at,at+len(blob)));payload[at:at+len(blob)]=blob
    proof=native.prove_installed_graph(payload,resources,translation,{0:header},mapping,bridges)
    return writes,{'header':header,'logical_bytes':len(source),'physical_write_bytes':sum(len(v)for a,v,n in writes),
        'native_bridge_bytes':len(bridges)*3,'bridges':len(bridges),'source_graph':source_proof,
        'installed_graph':proof,'all_instruction_operands_and_both_branch_arms_preserved':True},mapping,bridges


