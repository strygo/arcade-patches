"""Pinned original score conversion functions; no checkout dependency."""
from __future__ import annotations
from score_support import digest
from score_support import require
import struct
import upper_music_articulations as articulation
import upper_music_native as native
import upper_music_samples as samples

ARTICULATION_SHA256 = 'f914e1c05db74dc0a2962221ccb94055864521b2e8dfe4b86afeab1d260e78ec'


ALLOCATION = {'instrument_bank': 23, 'descriptor_first': 883,
              'articulation_first': 133, 'sample_bank_first': 0x8d}


def bind_resources(flat, pcm, sample_report, profiles, fitted):
    """Bind local source IDs to fixed installer rows, with root 0x48/fine 0."""
    require(digest(pcm) == sample_report['sample_payload_sha256'] and
            sample_report['sample_bank_base'] == ALLOCATION['sample_bank_first'] and
            sample_report['sample_bank_count'] == 3 and len(pcm) == 3*65536,
            'Pinned ordinary-bank sample placement differs')
    records = samples.sample_map(sample_report)
    ordered = sorted(fitted['profiles'], key=lambda p: p['profile_id'])
    require(set(profiles) == {p['profile_key'] for p in ordered}, 'Source profile key inventory differs')
    descriptors = bytearray(); instruments = bytearray(); bindings = []
    model_arts = articulation.articulation_map(fitted)
    for p in ordered:
        origin = profiles[p['profile_key']]; i = p['profile_id']
        for field in ('profile_id', 'source_sample_sha256', 'envelope_register', 'source_offset',
                      'source_fields', 'source_rates', 'programs', 'split_records', 'source_gate_profiles'):
            require(origin[field] == p[field], 'Original profile field differs: '+field)
        row = records[p['source_sample_sha256']]
        require(row['sample_id'] == i and row['source_offset'] == p['source_offset'] and
                row['programs'] == p['programs'] and row['descriptor_root'] == 0x48,
                'Source sample/profile/native instrument identity differs')
        require(native.articulation_parameters(flat, model_arts[i]) == p['parameter_values'],
                'Fitted selectors differ from canonical native tables')
        raw = bytes.fromhex(row['descriptor_hex'])
        require(struct.unpack('<BHHHB', raw) ==
                (row['bank'], row['start'], row['loop'], row['end'], 0x48) and
                digest(raw) == row['descriptor_sha256'], 'Native descriptor fields or identity differ')
        offset = row['relative_offset']; n = row['pcm8_frames']
        require(digest(samples.decoded_pcm8(row, pcm).tobytes()) == row['pcm8_sha256'] and
                pcm[offset+n:offset+n+2] == bytes(2), 'Native PCM8 content or guard differs')
        require(0x8d <= row['bank'] <= 0x8f and row['start'] <= row['loop'] < row['end'] <= 65535 and
                row['start']//32768 == (row['end']-1)//32768,
                'Native descriptor crosses qualified signed endpoints')
        descriptor = ALLOCATION['descriptor_first']+i
        art = ALLOCATION['articulation_first']+i
        instruments.extend(struct.pack('<HBB', descriptor, 0, art)); descriptors.extend(raw)
        bindings.append(dict(instrument_local_id=i, instrument_bank=23, descriptor_index=descriptor,
            articulation_index=art, fine=0, descriptor_root=0x48, profile_key=p['profile_key'],
            source_pcm16_sha256=p['source_sample_sha256'], pcm8_sha256=row['pcm8_sha256'],
            sample_bank=row['bank'], source_programs=p['programs'], articulation=p['articulation']))
    require(len(instruments) == 60 and len(descriptors) == 120, 'Native resource row extent differs')
    return bytes(instruments), bytes(descriptors), model_arts, bindings


def source_events(rows, profiles, observations, end_tick):
    """Retain the measured controls/gates; collapsed gates are never repaired."""
    events = [[] for _ in range(16)]; omitted = []; requested = 0
    for row in rows:
        own = events[row['slot']]
        for control in observations[row['voice_index']]['controls']:
            event = dict(control)
            if 'profile_key' in event:
                event['instrument'] = profiles[event.pop('profile_key')]['profile_id']
            own.append(event)
        if row['end_tick'] < end_tick: own.append(dict(tick=row['end_tick'], kind='note_off'))
        if row['gate_end_tick'] >= row['end_tick']:
            row.setdefault('native_gate_armed', False); continue
        requested += 1; tick = row['gate_end_tick']
        if tick <= row['onset_tick']:
            row['native_gate_armed'] = False
            omitted.append(dict(voice_index=row['voice_index'], slot=row['slot'], gate_tick=tick,
                                onset_tick=row['onset_tick'], reason='collapsed_gate'))
        else:
            row['native_gate_armed'] = True
            own.append(dict(tick=tick, kind='keyoff', onset_tick=row['onset_tick']))
    return events, omitted, requested


