"""Pinned original score conversion functions; no checkout dependency."""
from __future__ import annotations
from score_support import require
import upper_music_sources as source

EG_SHIFT = 16


EG_MAX = 1023 << EG_SHIFT


def envelope_fields(word):
    require(isinstance(word, int) and 0 <= word <= 0xffffffff, 'Envelope register word bounds')
    return {'attack': word & 31, 'decay_one': (word >> 6) & 31, 'decay_two': (word >> 11) & 31,
            'release': (word >> 16) & 31, 'decay_level': (word >> 21) & 31,
            'key_rate_scaling': (word >> 26) & 15, 'loop_start_link': bool(word & (1 << 30))}


def octave(pitch):
    require(isinstance(pitch, int) and 0 <= pitch <= 0xffff, 'AICA pitch register bounds')
    return (((pitch >> 11) & 15) ^ 8)-8


def sample_step(pitch):
    """Pinned AICA integer sample increment, in 1/4096 sample units."""
    shift = octave(pitch)+2; fraction = (pitch & 1023)+1024
    return fraction << shift if shift >= 0 else fraction >> -shift


def key_rate(pitch, scaling):
    require(isinstance(scaling, int) and 0 <= scaling <= 15, 'Key-rate scaling bounds')
    return 0 if scaling == 15 else octave(pitch)+2*scaling+((pitch >> 9) & 1)


def rate_index(base, field):
    require(isinstance(field, int) and 0 <= field <= 31, 'Envelope rate field bounds')
    return max(0, min(63, base+2*field))


def rate_increment(index, table, attack=False):
    require(isinstance(index, int) and 0 <= index < 64 and len(table) == 64, 'Envelope table index/length')
    if index < 2: return 0
    if attack and table[index] == 0: return 1024 << EG_SHIFT
    require(table[index] > 0, 'Nonpositive decay/release timing')
    return int((1023*1000)/(44100*table[index])*(1 << EG_SHIFT))


def release_bound(pitch, fields, decay_table, volume=EG_MAX):
    """Full-scale scalar release bound; ADSR can make the actual tail shorter."""
    require(isinstance(volume, int) and 0 <= volume <= EG_MAX, 'Envelope volume bounds')
    base = key_rate(pitch, fields['key_rate_scaling'])
    index = rate_index(base, fields['release']); increment = rate_increment(index, decay_table)
    if volume == 0: frames = 1
    elif increment == 0: frames = None
    else: frames = (volume+increment-1)//increment
    return {'key_rate_base': base, 'release_rate_index': index, 'release_increment': increment,
            'bound_frames_at_44100': frames,
            'bound_milliseconds_at_44100': frames/44.1 if frames is not None else None,
            'finite': frames is not None, 'qualification': 'Pinned-source full-scale bound; not native hardware timing.'}


def manatee_pitch(body, key, base_key, fine=0, bend_raw=64, bend_high=2, bend_low=2):
    """Original pitch-table arithmetic, under zero global/channel transpose."""
    require(0 <= key <= 127 and 0 <= base_key <= 127 and -128 <= fine <= 127 and
            0 <= bend_raw <= 127 and 0 <= bend_high <= 127 and 0 <= bend_low <= 127,
            'Original note/pitch input bounds')
    bend = ((bend_raw << 7)-0x2000)
    units = ((bend*(bend_low if bend < 0 else bend_high)) >> 5) & 0xffff
    units = (units+fine) & 0xffffffff
    table_index = ((units >> 8)+key+96-base_key) & 255
    encoded = source.bounded(body, 0x4238+table_index, 1, 'Original octave table entry')[0] << 7
    index = (((encoded << 1) & 0xf00) | (units & 0xfe)) >> 1
    fraction = source.bounded(body, 0x4338+index, 1, 'Original fraction table entry')[0]
    for threshold in (0x4d9, 0x383, 0x1ef):
        if index >= threshold: fraction += 256
    return (encoded & 0x7800) | fraction


def gate_envelope_volume(fields, frames, pitch, tables):
    """Piecewise-exact scalar AEG at gate, for the pinned source's unlinked case."""
    require(frames >= 0 and not fields['loop_start_link'], 'Unqualified linked envelope/time range')
    base = key_rate(pitch, fields['key_rate_scaling'])
    ar = rate_increment(rate_index(base, fields['attack']), tables['AR'], True)
    d1 = rate_increment(rate_index(base, fields['decay_one']), tables['DR'])
    d2 = rate_increment(rate_index(base, fields['decay_two']), tables['DR']) if fields['decay_two'] else 0
    volume = 0x17f << EG_SHIFT
    if ar == 0: return volume, 'attack'
    attack_frames = max(1, (EG_MAX-volume+ar-1)//ar)
    if frames < attack_frames: return volume+frames*ar, 'attack'
    frames -= attack_frames; volume = EG_MAX
    if d1 == 0: return volume, 'attack'
    threshold = ((32-fields['decay_level']) << (EG_SHIFT+5))-1
    decay_frames = max(1, (max(0, volume-threshold)+d1-1)//d1)
    if frames < decay_frames: return max(0, volume-frames*d1), 'decay_one'
    frames -= decay_frames; volume = max(0, volume-decay_frames*d1)
    return max(0, volume-frames*d2), 'decay_two'


