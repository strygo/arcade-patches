"""Build the seventeen nonprogram members from explicit original-media pools."""
import argparse,hashlib,json,shutil,subprocess,sys,urllib.request,zlib
from pathlib import Path

def require(ok,msg):
    if not ok:raise ValueError(msg)
def digest(b):return hashlib.sha256(b).hexdigest()
def read_json(p):return json.loads(p.read_text())
def pin(b):return {'bytes':len(b),'sha256':digest(b)}
def safe(root,name):
    p=root/name;require(not p.is_symlink() and p.resolve().is_relative_to(root.resolve()),'Escaping input: '+name);return p

def run_score(root,namespace,worker,inputs,recipe,out):
    subprocess.run([sys.executable,'-I','-B','-c','import runpy,sys;from pathlib import Path;p=Path(sys.argv.pop(1));sys.path.insert(0,str(p.parent));runpy.run_path(str(p),run_name="__main__")',str(root/namespace/worker),'--inputs',str(inputs),'--recipe',str(recipe),'--out',str(out)],check=True)

def copied_tiles(graphics,recipe,sources,rows):
    """Reconstruct the checked graphics base, then copy whole tiles within it (addresses only, no pixels)."""
    import public_kit_graphics as gfx
    pixels=graphics.apply(recipe,sources);require(len(pixels)==64*1024**2,'Complete Upper graphics extent required')
    require(digest(gfx.shuffle_bus(gfx.pixels_to_planar(pixels),inverse=True))==recipe['bus_sha256'],'Reconstructed graphics base mismatch')
    pixels=bytearray(pixels);blank=bytes([255])*128;targets=set()
    for dst,src in rows:
        require(type(dst) is int and type(src) is int and 0<=dst<0x80000 and 0<=src<0x80000 and dst not in targets,'Tile copy row')
        old=bytes(pixels[dst*128:dst*128+128]);art=bytes(pixels[src*128:src*128+128])
        require(old==blank and art!=blank and src not in targets,'Tile copy preimage');pixels[dst*128:dst*128+128]=art;targets.add(dst)
    bus=gfx.shuffle_bus(gfx.pixels_to_planar(bytes(pixels)),inverse=True)
    result=gfx.split_graphics(bus[:32*1024**2]);result['upper.gfx']=bus[32*1024**2:]
    return result

def finish(a,root,config,scorebytes):
    """Complete members from source-rebuilt score bytes; checks every output hash."""
    sys.path.insert(0,str(root/'runtime'));sys.path.append(str(root/'scores-cohort'))
    import public_kit_graphics_recipe as graphics,public_kit_panels as panels,public_kit_recipe as codec
    import public_kit_music as music,public_kit_sound_finish as finish
    import numpy as np
    catalog=read_json(a.pools/'pools.json');audio=read_json(a.audio/'pools.json')
    def source(folder,name):return safe(folder,name).read_bytes()
    shared={}
    for bank,info in config['music']['banks'].items():
        data=source(a.audio,'naomi-BGM'+bank+'.MPB');require(digest(data)==info['source_sha256'],'Original music bank')
        for i,plan in enumerate(info['samples']):
            b=data[plan['source_offset']:plan['source_offset']+plan['source_frames']*2]
            require(digest(b)==plan['source_pcm16_sha256'],'Original music sample');pcm,_=music.convert(np.frombuffer(b,'<i2'),plan)
            require(digest(pcm)==plan['pcm8_sha256'],'Converted music sample');shared[f'music-{bank}-{i:02d}.bin']=pcm
    reports={}
    for region in ('us','jp'):
        recipe=read_json(root/'recipes'/(region+'-graphics.json'));sources={}
        for n in recipe['pools']:
            sources[n]=panels.from_pools(a.pools,catalog,config['panels']) if n=='derived-us-stage-panels.bin' else source(a.pools,n)
        members=graphics.reconstruct(recipe,sources) if not config.get('tile_copies') else copied_tiles(graphics,recipe,sources,config['tile_copies'])
        del sources
        pcmrecipe=read_json(root/'recipes'/(region+'-pcm.json'))
        members['upper.snd']=codec.apply(pcmrecipe,{n:shared[n] if n in shared else source(a.audio,n) for n in pcmrecipe['sources']})
        original_sound=source(a.pools,'arcade-'+region+'-sz3.01')+source(a.pools,'arcade-'+region+'-sz3.02')
        members.update(finish.construct(original_sound,scorebytes,lambda n:source(a.audio,n),audio,config['voices'][region],config['stock_sound'],config['sound']))
        for name,route in config['direct'][region].items():members[name]=source(a.pools,route)
        require(set(members)==set(config['members'][region]) and len(members)==17,'Exact17-member inventory')
        out=a.out/region;out.mkdir();reports[region]={}
        for n,b in members.items():
            require(pin(b)==config['members'][region][n],'Nonprogram member differs: '+region+'/'+n);(out/n).write_bytes(b);reports[region][n]=pin(b)
    return reports

def main():
    p=argparse.ArgumentParser(description=__doc__)
    for n in ('pools','audio','out'):p.add_argument('--'+n,type=Path,required=True)
    for n in ('score-inputs','naomi-chd','naomi-pic','scratch'):p.add_argument('--'+n,type=Path)
    p.add_argument('--chdman');a=p.parse_args();root=Path(__file__).resolve().parent;config=read_json(root/'nonprogram.json')
    for name,expected in config['files'].items():require(pin(safe(root,name).read_bytes())==expected,'Capsule changed: '+name)
    require(not a.out.exists(),'Fresh nonprogram output required');a.out.mkdir(parents=True);work=a.out/'work';work.mkdir()
    sys.path.insert(0,str(root/'runtime'))
    # Sound placement consumes the same exported score graph readers.
    sys.path.append(str(root/'scores-cohort'))
    import public_kit_graphics_recipe as graphics,public_kit_panels as panels,public_kit_recipe as codec
    import public_kit_sound as sound
    import numpy as np
    catalog=read_json(a.pools/'pools.json');audio=read_json(a.audio/'pools.json')
    def source(folder,name):return safe(folder,name).read_bytes()
    original=work/'score-original';original.mkdir()
    if a.score_inputs:
        for n in ('MANATEE.DRV','aica.cpp'):(original/n).write_bytes(source(a.score_inputs,n))
    else:
        require(a.naomi_chd and a.naomi_pic and a.scratch and a.chdman,'Score source inputs or original Naomi media required')
        from public_kit_media import naomi
        a.scratch.mkdir(parents=True,exist_ok=True)
        with naomi(a.naomi_chd,a.naomi_pic,config['naomi'],a.scratch,a.chdman) as (data,files):
            at,size=files['MANATEE.DRV'];(original/'MANATEE.DRV').write_bytes(data[at:at+size])
        (original/'aica.cpp').write_bytes((root/'aica.cpp').read_bytes())
    for n in ('MANATEE.DRV','aica.cpp'):require(pin((original/n).read_bytes())==config['scores']['Guile']['inputs'][n],'Original score input '+n)
    assembled=work/'score-assembly';assembled.mkdir()
    canonical=source(a.pools,'arcade-us-sz3.01')+source(a.pools,'arcade-us-sz3.02');(assembled/'canonical.bin').write_bytes(canonical)
    for song,recipe in config['scores'].items():
        inputs=work/('inputs-'+song);inputs.mkdir()
        for n,expected in recipe['inputs'].items():
            if n in ('MANATEE.DRV','aica.cpp'):b=(original/n).read_bytes()
            elif n.startswith('BGM'):b=source(a.audio,'naomi-'+n)
            else:b=source(a.pools,'arcade-us-'+n)
            require(pin(b)==expected,'Original score resource '+n);(inputs/n).write_bytes(b)
        rp=work/(song+'.json');rp.write_text(json.dumps(recipe));namespace='scores-guile' if song=='Guile' else 'scores-cohort'
        run_score(root,namespace,'public_kit_scores.py' if song=='Guile' else 'public_kit_cohort_scores.py',inputs,rp,assembled/song)
        shutil.rmtree(inputs)
    sound.construct(assembled,config['score_layout'],work/'scores')
    reports=finish(a,root,config,(work/'scores/sound.bin').read_bytes())
    shutil.rmtree(work);(a.out/'nonprogram-receipt.json').write_text(json.dumps({'passed':True,'regions':reports,'capsule_sha256':digest((root/'nonprogram.json').read_bytes())},sort_keys=True,indent=2)+'\n')
if __name__=='__main__':main()
