"""Pinned NAOMI indexed-graphics decoder functions."""
from __future__ import annotations
import struct
def read_pac_sections(data: bytes) -> list[tuple[int, bytes]]:
    if len(data) < 0x800:
        raise SystemExit("PAC data is shorter than one header sector")
    count, _total = struct.unpack_from("<II", data, 0)
    if not 0 < count < 64:
        raise SystemExit(f"implausible PAC section count {count}")
    if 8 + count * 8 > 0x800:
        raise SystemExit(f"PAC section table does not fit in header sector: {count}")
    sections: list[tuple[int, bytes]] = []
    cursor = 0x800
    for i in range(count):
        kind, size = struct.unpack_from("<II", data, 8 + i * 8)
        end = cursor + size
        if end > len(data):
            raise SystemExit(f"PAC section {i} extends past end of file")
        sections.append((kind, data[cursor:end]))
        cursor = align_up(end, 0x800)
    return sections


def unpack_clut4(data: bytes) -> list[int]:
    return [nibble for value in data for nibble in (value & 0x0F, value >> 4)]


def pack_clut4(pixels: list[int]) -> bytes:
    if len(pixels) % 2:
        raise ValueError("CLUT4 pixel count must be even")
    return bytes(pixels[index] | (pixels[index + 1] << 4) for index in range(0, len(pixels), 2))


def untwiddle_clut4_texture(data: bytes, width: int, height: int) -> bytes:
    """Convert one square, power-of-two CLUT4 texture from Morton to linear order."""
    if width != height or width < 1 or width & (width - 1):
        raise ValueError("CLUT4 Morton conversion requires a square power-of-two texture")
    if len(data) * 2 != width * height:
        raise ValueError(
            f"CLUT4 texture is 0x{len(data):x} bytes, expected 0x{width * height // 2:x}"
        )

    twiddled = unpack_clut4(data)
    linear = [0] * len(twiddled)
    bits = width.bit_length() - 1
    for y in range(height):
        for x in range(width):
            morton = 0
            for bit in range(bits):
                morton |= ((y >> bit) & 1) << (bit * 2)
                morton |= ((x >> bit) & 1) << (bit * 2 + 1)
            linear[y * width + x] = twiddled[morton]
    return pack_clut4(linear)


PL_RUNTIME_BACKREF_TABLE = bytes.fromhex(
    "00191a1b1c1d1e1f20393a3b3c3d3e3f"
    "00011a1b1c1d1e1f20213a3b3c3d3e3f"
    "0001021b1c1d1e1f2021223b3c3d3e3f"
    "000102031c1d1e1f202122233c3d3e3f"
    "00010203041d1e1f20212223243d3e3f"
    "0001020304051e1f2021222324253e3f"
    "000102030405061f202122232425263f"
    "00010203040506072021222324252627"
)


PL_RUNTIME_STRIDE_TABLE = (1, 1, 1, 1, 1, 1, 1, 0x19)


PL_DECODED_RECORD_SIZE = 0x80


def parse_pl_record_stream(data: bytes) -> list[bytes]:
    if len(data) < 4:
        raise SystemExit("PL section 1 is too short for a record offset table")
    first = struct.unpack_from("<I", data, 0)[0]
    if first == 0 or first % 4:
        raise SystemExit(f"PL section 1 first offset is not a u32 table size: 0x{first:x}")
    count = first // 4
    if first > len(data):
        raise SystemExit(f"PL section 1 offset table exceeds section size: 0x{first:x} > 0x{len(data):x}")
    offsets = [struct.unpack_from("<I", data, i * 4)[0] for i in range(count)]
    if offsets[0] != first:
        raise SystemExit(f"PL section 1 first table entry mismatch: 0x{offsets[0]:x} != 0x{first:x}")
    for index, offset in enumerate(offsets):
        if offset < first or offset > len(data):
            raise SystemExit(f"PL section 1 offset {index} out of range: 0x{offset:x}")

    # The runtime addresses records independently through this table. Multiple
    # entries may therefore alias one encoded record, and an alias can point
    # backward. Slice at the next unique payload address rather than assuming
    # table order is also storage order.
    unique_offsets = sorted(set(offsets))
    records_by_offset = {
        offset: data[
            offset : unique_offsets[index + 1]
            if index + 1 < len(unique_offsets)
            else len(data)
        ]
        for index, offset in enumerate(unique_offsets)
    }
    return [records_by_offset[offset] for offset in offsets]


def decode_pl_runtime_record(record: bytes) -> bytes:
    """Decode the CFC2 z3uu PL record bytecode used by the PC runtime."""
    memory: dict[int, int] = {}
    out = bytearray()
    pos = 0
    flags = 0
    bits_left = 0
    dest = 0

    while len(out) < PL_DECODED_RECORD_SIZE:
        if bits_left == 0:
            if pos >= len(record):
                raise ValueError("short PL record while reading flag byte")
            flags = record[pos]
            pos += 1
            bits_left = 8

        if pos >= len(record):
            raise ValueError("short PL record while reading command byte")
        command = record[pos]
        pos += 1

        if flags & 1:
            count = command & 0x0F
            mode = command >> 4
            if mode == 0:
                if pos >= len(record):
                    raise ValueError("short PL record while reading repeated byte")
                value = record[pos]
                pos += 1
                count += 1
                for _ in range(count):
                    memory[dest] = value
                    out.append(value)
                    dest += PL_RUNTIME_STRIDE_TABLE[dest & 7]
                    if len(out) >= PL_DECODED_RECORD_SIZE:
                        break
            else:
                source = dest - PL_RUNTIME_BACKREF_TABLE[(dest & 7) * 16 + mode]
                for _ in range(count):
                    value = memory.get(source, 0)
                    memory[dest] = value
                    out.append(value)
                    dest += PL_RUNTIME_STRIDE_TABLE[dest & 7]
                    source += PL_RUNTIME_STRIDE_TABLE[source & 7]
                    if len(out) >= PL_DECODED_RECORD_SIZE:
                        break
        else:
            value = command
            memory[dest] = value
            out.append(value)
            dest += PL_RUNTIME_STRIDE_TABLE[dest & 7]

        flags >>= 1
        bits_left -= 1

    if pos != len(record):
        raise ValueError(f"PL record decoded after 0x{pos:x} bytes, but record is 0x{len(record):x} bytes")
    return bytes(out)


def align_up(value: int, alignment: int) -> int:
    return (value + alignment - 1) // alignment * alignment
