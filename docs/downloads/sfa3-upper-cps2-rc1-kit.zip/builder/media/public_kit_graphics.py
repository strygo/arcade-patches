"""Portable indexed graphics transforms for the Upper reconstruction kit.

Pixels always come from supplied game resources. Tile routes may change
orientation and bijectively rename pens while retaining transparency; they
cannot synthesize new pictures or carry a literal-pixel fallback.
"""
from __future__ import annotations
import array
from functools import lru_cache
import hashlib
import struct

BANK = 0x200000
GROUPS = (('sz3.13m', 'sz3.15m', 'sz3.17m', 'sz3.19m'),
          ('sz3.14m', 'sz3.16m', 'sz3.18m', 'sz3.20m'))
SWAP = bytes((b >> 4) | (b << 4 & 255) for b in range(256))


def require(ok, message):
    if not ok:
        raise ValueError(message)


@lru_cache(maxsize=2)
def permutation(inverse=False):
    order = array.array('I', range(BANK//8))
    def shuffle(start, count):
        if count == 2:
            return
        count //= 2
        for i in range(0, count, 2):
            a, b = start+i+1, start+count+i
            order[a], order[b] = order[b], order[a]
        shuffle(start, count)
        shuffle(start+count, count)
    shuffle(0, len(order))
    if inverse:
        undo = array.array('I', [0])*len(order)
        for i, value in enumerate(order):
            undo[value] = i
        return undo
    return order


def shuffle_bus(data, inverse=False):
    require(len(data) % BANK == 0, 'Graphics bus is not bank aligned')
    order = permutation(inverse)
    result = bytearray()
    for start in range(0, len(data), BANK):
        words = array.array('Q')
        words.frombytes(data[start:start+BANK])
        result.extend(array.array('Q', (words[i] for i in order)).tobytes())
    return bytes(result)


@lru_cache(maxsize=1)
def plane_tables():
    return tuple(tuple(sum(((value >> (7-pixel)) & 1) << (pixel*4+plane)
                           for pixel in range(8)) for value in range(256)) for plane in range(4))


def planar_to_pixels(data):
    require(len(data) % 4 == 0, 'Planar group extent')
    a, b, c, d = plane_tables()
    out = bytearray(len(data))
    for i in range(0, len(data), 4):
        value = a[data[i]] | b[data[i+1]] | c[data[i+2]] | d[data[i+3]]
        struct.pack_into('<I', out, i, value)
    return bytes(out)


@lru_cache(maxsize=1)
def pixel_tables():
    return tuple(tuple(sum(((value >> (nibble*4+plane)) & 1) << (plane*8+7-(pair*2+nibble))
                           for plane in range(4) for nibble in range(2))
                       for value in range(256)) for pair in range(4))


def pixels_to_planar(data):
    require(len(data) % 4 == 0, 'Indexed pixel group extent')
    a, b, c, d = pixel_tables()
    out = bytearray(len(data))
    for i in range(0, len(data), 4):
        value = a[data[i]] | b[data[i+1]] | c[data[i+2]] | d[data[i+3]]
        struct.pack_into('<I', out, i, value)
    return bytes(out)


def graphics_bus(members):
    out = bytearray()
    for group in GROUPS:
        values = [members[n] for n in group]
        require(len({len(v) for v in values}) == 1, 'Unequal graphics lane extents')
        bus = bytearray(len(values[0])*4)
        for lane, value in enumerate(values):
            bus[lane*2::8], bus[lane*2+1::8] = value[0::2], value[1::2]
        out.extend(bus)
    return bytes(out)


def split_graphics(bus):
    require(len(bus) == 32*1024**2, 'Stock graphics bus extent')
    result = {}
    for index, group in enumerate(GROUPS):
        part = bus[index*16*1024**2:(index+1)*16*1024**2]
        for lane, name in enumerate(group):
            value = bytearray(len(part)//4)
            value[0::2], value[1::2] = part[lane*2::8], part[lane*2+1::8]
            result[name] = bytes(value)
    return result


def tile_variants(tile):
    width = {32: 8, 128: 16, 512: 32}.get(len(tile))
    require(width is not None, 'Unsupported tile extent')
    rows = [tile[i:i+width//2] for i in range(0, len(tile), width//2)]
    horizontal = [row[::-1].translate(SWAP) for row in rows]
    return tile, b''.join(horizontal), b''.join(rows[::-1]), b''.join(horizontal[::-1])


def shape(tile):
    # Pen 15 remains transparent, including when it is absent from a tile.
    mapping = {15: 15}
    out = bytearray()
    for value in tile:
        lo, hi = value & 15, value >> 4
        for pen in (lo, hi):
            if pen not in mapping:
                mapping[pen] = len(mapping)-1
        out.append(mapping[lo] | mapping[hi] << 4)
    return hashlib.sha256(out).digest()


def pen_map(source, target):
    require(len(source) == len(target), 'Tile extent differs')
    mapping, reverse = {15: 15}, {15: 15}
    for left, right in zip(source, target):
        for a, b in ((left & 15, right & 15), (left >> 4, right >> 4)):
            require(mapping.get(a, b) == b and reverse.get(b, a) == a,
                    'Nonbijective or transparency-changing pen map')
            mapping[a], reverse[b] = b, a
    unused = iter(sorted(set(range(16))-set(reverse)))
    for pen in range(16):
        if pen not in mapping:
            mapping[pen] = next(unused)
    result = list(mapping[i] for i in range(16))
    require(remap(source, result) == target, 'Reconstructed tile differs')
    return result


def remap(tile, mapping):
    require(isinstance(mapping, list) and len(mapping) == 16 and
            all(type(i) is int for i in mapping) and sorted(mapping) == list(range(16)) and
            mapping[15] == 15, 'Invalid pen permutation')
    return tile.translate(bytes(mapping[i & 15] | mapping[i >> 4] << 4 for i in range(256)))


def decode_tiles(blob, count, table, size):
    import tilelz
    require(size in (32, 128, 512) and 0 < count <= 0x100000 and
            0 <= table <= len(blob)-count*4, 'Invalid typed tile table')
    pointers = struct.unpack_from('<'+str(count)+'I', blob, table)
    offsets = sorted({p & 0x7fffffff for p in pointers if p})
    ends = dict(zip(offsets, offsets[1:]+[len(blob)]))
    decoded = {0: bytes(size)}
    for pointer in sorted(set(pointers)-{0}):
        offset = pointer & 0x7fffffff
        require(table+count*4 <= offset < len(blob), 'Tile points outside its payload')
        block = blob[offset:ends[offset]]
        if pointer >> 31:
            tile, used = tilelz.decompress_verbose(block, out_len=size)
            require(used <= len(block), 'Compressed tile exceeds its payload')
        else:
            tile = block[:size]
        require(len(tile) == size, 'Truncated source tile')
        decoded[pointer] = tile
    return b''.join(decoded[p] for p in pointers), bytes(bool(p) for p in pointers)


def self_test():
    sample = bytes(range(256))*16
    require(planar_to_pixels(pixels_to_planar(sample)) == sample, 'Pixel conversion inverse')
    for plane in range(4):
        for bit in range(8):
            source = bytearray(4)
            source[plane] = 1 << bit
            expected = bytearray(4)
            pixel = 7-bit
            expected[pixel//2] = (1 << plane) << (4*(pixel % 2))
            require(planar_to_pixels(source) == bytes(expected), 'Independent bit-position witness')
    source = bytes(range(128))
    mapping = list(range(16))
    mapping[2], mapping[7] = mapping[7], mapping[2]
    target = remap(tile_variants(source)[3], mapping)
    require(shape(tile_variants(source)[3]) == shape(target), 'Pen shape invariant')
    require(remap(tile_variants(source)[3], pen_map(tile_variants(source)[3], target)) == target,
            'Tile route failed')
    for bad in (list(range(15))+[0], [15]+list(range(1,15))+[0]):
        try:
            remap(source, bad)
        except ValueError:
            pass
        else:
            raise AssertionError('Invalid pen map accepted')
    bank = bytes(range(256))*(BANK//256)
    require(shuffle_bus(shuffle_bus(bank), True) == bank, 'Bus shuffle inverse')
    print('Public graphics: bit-position witnesses, pixel/bus inverses and pen-map controls PASS')


def cloud_continuation(pixels):
    """Reproduce the restoration's inward continuation of the native sky strip."""
    refs = ([(0xcf00+x, 1) for x in range(9)] + [(0x6c1e, 0)]*2 +
            [(0xcf09, 0), (0xcf09, 0x20)] + [(0x6c1e, 0)]*2 +
            [(0xcf08-x, 0x21) for x in range(9)])
    cells = []
    for code, attr in refs:
        tile = pixels[(0x10000+code)*128:(0x10001+code)*128]
        require(len(tile) == 128, 'Native sky source extent')
        tile = tile_variants(tile)[(attr >> 5) & 3]
        cells.append([n for b in tile for n in (b & 15, b >> 4)])
    strip = [[p for cell in cells for p in cell[y*16:y*16+16]] for y in range(16)]
    rows = []
    for y in range(16):
        depth = 15-y
        row = []
        for x in range(384):
            shift = 2*(depth+1)
            xx = x-shift if x < 144 else x+shift if x >= 240 else x
            xx = -xx-1 if xx < 0 else 767-xx if xx >= 384 else xx
            require((refs[x//16][1] & 31) == (refs[xx//16][1] & 31), 'Sky palette boundary')
            row.append(strip[depth][xx])
        rows.append(row)
    return b''.join(bytes(row[x+i] | row[x+i+1] << 4 for row in rows for i in range(0, 16, 2))
                    for x in range(0, 384, 16))


def naomi_quote_glyph(sections, token):
    """Decode one original ARGB1555 winner-font cell with its native pen mapping."""
    colors = {0xfbde: 9, 0xe318: 10, 0xd294: 11, 0xb9ce: 12,
              0xa108: 13, 0x9084: 14, 0x01d0: 15}
    index = token & 0x7fff
    data = dict(sections)[0x10000900+index//256]
    require(data[:4] == b'GBIX' and data[16:20] == b'PVRT' and data[24:28] == b'\0\1\0\0'
            and struct.unpack_from('<HH', data, 28) == (256, 256) and len(data) == 131104,
            'Winner font PVR format differs')
    spread = [sum(((v >> bit) & 1) << (bit*2) for bit in range(8)) for v in range(256)]
    cell, pixels = index % 256, []
    for y in range(16):
        for x in range(16):
            gx, gy = (cell % 16)*16+x, (cell//16)*16+y
            value = struct.unpack_from('<H', data, 32+2*(spread[gy] | spread[gx] << 1))[0]
            require(value in colors, 'Unknown winner font color')
            pixels.append(colors[value])
    return bytes(pixels[i] | pixels[i+1] << 4 for i in range(0, 256, 2))


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--self-test', action='store_true', required=True)
    parser.parse_args()
    self_test()
