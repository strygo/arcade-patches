"""Bounded original ending metadata extraction, independent of graphics pools."""
import json
import struct
import subprocess
import tempfile
from pathlib import Path
import bizlz
import iso9660
from public_kit_media import Disc,file_identity,digest,require


def recover(path,pin,entries,scratch,chdman):
    path=Path(path)
    with tempfile.TemporaryDirectory(prefix='ending-',dir=scratch) as folder:
        folder=Path(folder);ranges=[]
        if path.suffix.lower()=='.chd':
            require(file_identity(path)==pin['chd'],'Selected regional ending CHD differs')
            def extract(at,size):
                require(0<=at<=pin['iso']['bytes']-size and 0<size<=1<<20,'Bounded original ending range')
                output=folder/'range.bin'
                output.unlink(missing_ok=True)
                subprocess.run([str(chdman),'extractdvd','-i',str(path),'-o',str(output),'-isb',str(at),'-ib',str(size)],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
                blob=output.read_bytes();require(len(blob)==size,'Short original ending range');ranges.append([at,size]);return blob
            header=extract(0,1<<20);head=folder/'head.iso';head.write_bytes(header)
            with head.open('rb') as stream:
                files={name:(lba*2048,size) for name,lba,size,directory in iso9660.walk(stream,*iso9660.root(stream)) if not directory}
            base,length=files['/X_DATA.BIN'];header=extract(base,65536)
            require(header[:4]==b'AFS\0','Original ending AFS header')
            count=struct.unpack_from('<I',header,4)[0]
            require(max(map(int,entries))<count and 8+count*8<=len(header),'Complete original AFS directory')
            blobs={}
            for number in entries:
                offset,size=struct.unpack_from('<2I',header,8+int(number)*8)
                require(offset+size<=length,'Original ending entry bounds')
                blobs[number]=extract(base+offset,size)
        else:
            reader=Disc(path,pin)
            try:blobs={number:reader.entry(int(number)) for number in entries}
            finally:reader.stream.close()
        result={}
        for number,stored in blobs.items():
            require({'bytes':len(stored),'sha256':digest(stored)}==entries[number],'Stored original ending identity: '+number)
            decoded,used=bizlz.decompress(stored,max_out=1<<20)
            require(decoded is not None and used==len(stored),'Complete ending metadata compressed extent')
            result[number]=decoded
        return result,{'source':file_identity(path),'ranges':ranges,'stored_entries_verified':entries}


def main():
    import argparse
    parser=argparse.ArgumentParser(description=__doc__)
    for name in ('contract','ps2-us','ps2-jp','scratch','chdman','out'):parser.add_argument('--'+name,type=Path,required=True)
    args=parser.parse_args();contract=json.loads(args.contract.read_text())
    require(not args.out.exists(),'Ending metadata output must be fresh');args.out.mkdir()
    report={'regions':{}}
    for region in ('us','jp'):
        outputs,proof=recover(getattr(args,'ps2_'+region),contract['regions'][region],contract['entries'],args.scratch,args.chdman)
        proof['outputs']={}
        for number,blob in outputs.items():
            name=f'ps2-{region}-entry{number}-metadata.bin';(args.out/name).write_bytes(blob)
            proof['outputs'][name]={'bytes':len(blob),'sha256':digest(blob)}
        report['regions'][region]=proof
    (args.out/'source.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
    print(json.dumps(report))

if __name__=='__main__':main()
