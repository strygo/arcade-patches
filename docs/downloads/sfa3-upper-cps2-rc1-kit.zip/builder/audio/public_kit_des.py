"""DES-ECB for the NAOMI GD-ROM payload, built in so the kit needs no OpenSSL.

FIPS 46-3 DES, vectorized with NumPy over every 8-byte block. Each
permutation is a set of per-byte lookup tables, and each S-box is merged
with the P permutation into one table.

The byte order matches MAME's naomigd DES and the previous OpenSSL path
(`naomi_gdrom_des.run_openssl_des`):
- MAME builds the key as a u64 and swaps its endianness, so the 8 PIC key
  bytes are reversed;
- it reads and writes each payload block as a little-endian u64, so each
  8-byte block is also reversed.
`decrypt()` therefore equals `reverse_blocks(DES_dec(reverse_blocks(data), key[::-1]))`.
"""
from __future__ import annotations

import numpy as np

PC1 = (57, 49, 41, 33, 25, 17, 9, 1, 58, 50, 42, 34, 26, 18, 10, 2, 59, 51, 43, 35, 27, 19, 11, 3, 60, 52, 44, 36,
       63, 55, 47, 39, 31, 23, 15, 7, 62, 54, 46, 38, 30, 22, 14, 6, 61, 53, 45, 37, 29, 21, 13, 5, 28, 20, 12, 4)
PC2 = (14, 17, 11, 24, 1, 5, 3, 28, 15, 6, 21, 10, 23, 19, 12, 4, 26, 8, 16, 7, 27, 20, 13, 2,
       41, 52, 31, 37, 47, 55, 30, 40, 51, 45, 33, 48, 44, 49, 39, 56, 34, 53, 46, 42, 50, 36, 29, 32)
SHIFTS = (1, 1, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 1)
IP = (58, 50, 42, 34, 26, 18, 10, 2, 60, 52, 44, 36, 28, 20, 12, 4, 62, 54, 46, 38, 30, 22, 14, 6, 64, 56, 48, 40, 32, 24, 16, 8,
      57, 49, 41, 33, 25, 17, 9, 1, 59, 51, 43, 35, 27, 19, 11, 3, 61, 53, 45, 37, 29, 21, 13, 5, 63, 55, 47, 39, 31, 23, 15, 7)
FP = tuple(IP.index(n) + 1 for n in range(1, 65))
E = (32, 1, 2, 3, 4, 5, 4, 5, 6, 7, 8, 9, 8, 9, 10, 11, 12, 13, 12, 13, 14, 15, 16, 17,
     16, 17, 18, 19, 20, 21, 20, 21, 22, 23, 24, 25, 24, 25, 26, 27, 28, 29, 28, 29, 30, 31, 32, 1)
P = (16, 7, 20, 21, 29, 12, 28, 17, 1, 15, 23, 26, 5, 18, 31, 10, 2, 8, 24, 14, 32, 27, 3, 9, 19, 13, 30, 6, 22, 11, 4, 25)
SBOX = (
    (14, 4, 13, 1, 2, 15, 11, 8, 3, 10, 6, 12, 5, 9, 0, 7, 0, 15, 7, 4, 14, 2, 13, 1, 10, 6, 12, 11, 9, 5, 3, 8,
     4, 1, 14, 8, 13, 6, 2, 11, 15, 12, 9, 7, 3, 10, 5, 0, 15, 12, 8, 2, 4, 9, 1, 7, 5, 11, 3, 14, 10, 0, 6, 13),
    (15, 1, 8, 14, 6, 11, 3, 4, 9, 7, 2, 13, 12, 0, 5, 10, 3, 13, 4, 7, 15, 2, 8, 14, 12, 0, 1, 10, 6, 9, 11, 5,
     0, 14, 7, 11, 10, 4, 13, 1, 5, 8, 12, 6, 9, 3, 2, 15, 13, 8, 10, 1, 3, 15, 4, 2, 11, 6, 7, 12, 0, 5, 14, 9),
    (10, 0, 9, 14, 6, 3, 15, 5, 1, 13, 12, 7, 11, 4, 2, 8, 13, 7, 0, 9, 3, 4, 6, 10, 2, 8, 5, 14, 12, 11, 15, 1,
     13, 6, 4, 9, 8, 15, 3, 0, 11, 1, 2, 12, 5, 10, 14, 7, 1, 10, 13, 0, 6, 9, 8, 7, 4, 15, 14, 3, 11, 5, 2, 12),
    (7, 13, 14, 3, 0, 6, 9, 10, 1, 2, 8, 5, 11, 12, 4, 15, 13, 8, 11, 5, 6, 15, 0, 3, 4, 7, 2, 12, 1, 10, 14, 9,
     10, 6, 9, 0, 12, 11, 7, 13, 15, 1, 3, 14, 5, 2, 8, 4, 3, 15, 0, 6, 10, 1, 13, 8, 9, 4, 5, 11, 12, 7, 2, 14),
    (2, 12, 4, 1, 7, 10, 11, 6, 8, 5, 3, 15, 13, 0, 14, 9, 14, 11, 2, 12, 4, 7, 13, 1, 5, 0, 15, 10, 3, 9, 8, 6,
     4, 2, 1, 11, 10, 13, 7, 8, 15, 9, 12, 5, 6, 3, 0, 14, 11, 8, 12, 7, 1, 14, 2, 13, 6, 15, 0, 9, 10, 4, 5, 3),
    (12, 1, 10, 15, 9, 2, 6, 8, 0, 13, 3, 4, 14, 7, 5, 11, 10, 15, 4, 2, 7, 12, 9, 5, 6, 1, 13, 14, 0, 11, 3, 8,
     9, 14, 15, 5, 2, 8, 12, 3, 7, 0, 4, 10, 1, 13, 11, 6, 4, 3, 2, 12, 9, 5, 15, 10, 11, 14, 1, 7, 6, 0, 8, 13),
    (4, 11, 2, 14, 15, 0, 8, 13, 3, 12, 9, 7, 5, 10, 6, 1, 13, 0, 11, 7, 4, 9, 1, 10, 14, 3, 5, 12, 2, 15, 8, 6,
     1, 4, 11, 13, 12, 3, 7, 14, 10, 15, 6, 8, 0, 5, 9, 2, 6, 11, 13, 8, 1, 4, 10, 7, 9, 5, 0, 15, 14, 2, 3, 12),
    (13, 2, 8, 4, 6, 15, 11, 1, 10, 9, 3, 14, 5, 0, 12, 7, 1, 15, 13, 8, 10, 3, 7, 4, 12, 5, 6, 11, 0, 14, 9, 2,
     7, 11, 4, 1, 9, 12, 14, 2, 0, 6, 10, 13, 15, 3, 5, 8, 2, 1, 14, 7, 4, 10, 8, 13, 15, 12, 9, 0, 3, 5, 6, 11),
)
CHUNK = 1 << 21  # blocks per pass; bounds memory to a few hundred MB


def permute(value, table, width):
    """Scalar FIPS permutation: bit 1 is the most significant of `width` input bits."""
    out = 0
    for source in table:
        out = (out << 1) | ((value >> (width - source)) & 1)
    return out


def subkeys(key):
    k = permute(int.from_bytes(key, 'big'), PC1, 64)
    c, d, keys = k >> 28, k & 0xFFFFFFF, []
    for shift in SHIFTS:
        c = ((c << shift) | (c >> (28 - shift))) & 0xFFFFFFF
        d = ((d << shift) | (d >> (28 - shift))) & 0xFFFFFFF
        keys.append(permute((c << 28) | d, PC2, 56))
    return keys


def byte_tables(table, width_in, width_out):
    """Per input byte, the output bits it contributes: out = OR of tables[i][byte i]."""
    tables = np.zeros((width_in // 8, 256), dtype=np.uint64)
    for position, source in enumerate(table):
        index, bit = divmod(source - 1, 8)
        mask = np.uint64(1) << np.uint64(width_out - 1 - position)
        values = np.arange(256)
        tables[index][(values >> (7 - bit)) & 1 == 1] |= mask
    return tables


IP_T, FP_T, E_T = byte_tables(IP, 64, 64), byte_tables(FP, 64, 64), byte_tables(E, 32, 48)
SP_T = np.array([[permute(SBOX[box][((x & 0x20) | ((x & 1) << 4)) | ((x >> 1) & 0xF)] << (28 - 4 * box), P, 32)
                  for x in range(64)] for box in range(8)], dtype=np.uint64)


def apply_tables(values, tables):
    nbytes = len(tables)
    out = np.zeros_like(values)
    for i in range(nbytes):
        out |= tables[i][(values >> np.uint64(8 * (nbytes - 1 - i))) & np.uint64(0xFF)]
    return out


def des_blocks(blocks, keys):
    """FIPS DES over big-endian uint64 blocks with the given round subkeys."""
    x = apply_tables(blocks, IP_T)
    left, right = x >> np.uint64(32), x & np.uint64(0xFFFFFFFF)
    for k in keys:
        mixed = apply_tables(right, E_T) ^ np.uint64(k)
        f = np.zeros_like(right)
        for box in range(8):
            f |= SP_T[box][(mixed >> np.uint64(42 - 6 * box)) & np.uint64(0x3F)]
        left, right = right, left ^ f
    return apply_tables((right << np.uint64(32)) | left, FP_T)


def decrypt(data, key, *, encrypt=False):
    """MAME naomigd order: block-reversed payload, reversed key (see module docstring)."""
    if len(data) % 8:
        raise ValueError('DES payload length must be divisible by 8')
    keys = subkeys(bytes(key)[::-1])
    keys = keys if encrypt else keys[::-1]
    # A block reversed then read big-endian is the block read little-endian.
    blocks = np.frombuffer(data, dtype='<u8')
    out = np.empty(len(blocks), dtype='<u8')
    for start in range(0, len(blocks), CHUNK):
        out[start:start + CHUNK] = des_blocks(blocks[start:start + CHUNK].astype(np.uint64), keys)
    return out.tobytes()


def self_test():
    assert all(len(b) == 64 and all(sorted(b[r*16:r*16+16]) == list(range(16)) for r in range(4)) for b in SBOX), 'S-box rows'
    # FIPS worked example: key 133457799BBCDFF1, plaintext 0123456789ABCDEF -> 85E813540F0AB405.
    k = subkeys(bytes.fromhex('133457799BBCDFF1'))
    block = np.array([0x0123456789ABCDEF], dtype=np.uint64)
    assert int(des_blocks(block, k)[0]) == 0x85E813540F0AB405, 'DES known answer'
    assert int(des_blocks(des_blocks(block, k), k[::-1])[0]) == 0x0123456789ABCDEF, 'DES round trip'
    # MAME order: reversed key and blocks map onto the same known answer.
    payload = bytes.fromhex('85E813540F0AB405')[::-1]
    assert decrypt(payload, bytes.fromhex('133457799BBCDFF1')[::-1]) == bytes.fromhex('0123456789ABCDEF')[::-1], 'MAME order'
    return {'passed': True}


if __name__ == '__main__':
    import json
    print(json.dumps(self_test()))
