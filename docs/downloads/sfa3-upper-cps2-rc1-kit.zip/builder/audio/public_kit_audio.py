"""Recreate private audio inputs from the recipient's original discs."""
import argparse
import json
from pathlib import Path

import public_kit_media as media
import audio_dsp as dsp


def produce(args):
    import numpy
    import scipy
    media.require((numpy.__version__, scipy.__version__) == ('2.2.6', '1.15.3'),
                  'Audio requires NumPy 2.2.6 and SciPy 1.15.3')
    config = json.loads(args.contract.read_text())
    media.require(not args.out.exists(), 'Audio pool output must be fresh')
    args.out.mkdir()
    catalog = {'schema': 1, 'pools': {}, 'voices': {}}

    def save(name, data, **metadata):
        media.require(name not in catalog['pools'] and Path(name).name == name, 'Audio pool name')
        (args.out/name).write_bytes(data)
        catalog['pools'][name] = {'bytes': len(data), 'sha256': media.digest(data), **metadata}

    census = {(row['entry'], row['sample']): row for row in config['voice_census']}
    for region in ('us', 'jp'):
        with media.ps2(getattr(args, 'ps2_'+region), config['inputs']['ps2'][region],
                       args.scratch, args.chdman) as disc:
            for entry in range(340, 344):
                source = disc.entry(entry)
                media.require(config['retain_voice_banks'] is True, 'Original command-bank contract required')
                save(f'ps2-{region}-voicebank{entry}.bin',source,region=region,kind='voice-source',entry=entry)
                rows = dsp.voice_bank(source, entry, census)
                for row in rows:
                    for rate in (1624, 2048):
                        pcm, conversion = dsp.resample(row['pcm'], row['sample_rate'], rate)
                        name = f'ps2-{region}-voice{entry}-{row["sample"]:02d}-r{rate}.bin'
                        save(name, pcm, region=region, kind='pcm8')
                        catalog['voices'][name] = {k: v for k, v in row.items() if k != 'pcm'}
                        catalog['voices'][name].update(conversion=conversion,
                                                       bank_sha256=media.digest(source))
                print(f'{region} voice bank {entry}: {len(rows)} original samples', flush=True)
    with media.naomi(args.naomi_chd, args.naomi_pic, config['inputs']['naomi'],
                     args.scratch, args.chdman) as (data, files):
        for name in config['music_files']:
            offset, size = files[name]
            save('naomi-'+name, data[offset:offset+size], region='shared', kind='music-source')
    (args.out/'pools.json').write_text(json.dumps(catalog, indent=2, sort_keys=True)+'\n')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('contract', 'out', 'scratch', 'ps2-us', 'ps2-jp', 'naomi-chd', 'naomi-pic'):
        parser.add_argument('--'+name, type=Path, required=True)
    parser.add_argument('--chdman', required=True)
    produce(parser.parse_args())
