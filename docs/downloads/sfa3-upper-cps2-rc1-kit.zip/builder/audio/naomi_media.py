"""Pinned GD-ROM sector and DES helpers for Upper media."""
from __future__ import annotations
import math
import struct
import subprocess
from pathlib import Path

def embedded_iso_root_files(
    rom: bytes,
    base: int = 0x1000000,
    track_start_lba: int = 45000,
) -> dict[str, tuple[int, int]]:
    sector_size = 2048
    pvd = rom[base + 16 * sector_size : base + 17 * sector_size]
    if pvd[1:6] != b"CD001":
        raise SystemExit(f"embedded ISO PVD not found at 0x{base + 16 * sector_size:x}")
    root = parse_iso_dir_record_at(pvd, 156)
    if root is None:
        raise SystemExit("embedded ISO root directory record not found")
    _length, root_extent, root_size, _flags, _name = root
    root_offset = base + (root_extent - track_start_lba) * sector_size
    root_bytes = rom[root_offset : root_offset + root_size]

    files: dict[str, tuple[int, int]] = {}
    pos = 0
    while pos < len(root_bytes):
        length = root_bytes[pos]
        if length == 0:
            pos = ((pos // sector_size) + 1) * sector_size
            continue
        record = parse_iso_dir_record_at(root_bytes, pos)
        if record is not None:
            _length, extent, size, flags, name = record
            normalized = normalize_iso_name(name)
            if normalized not in ("\x00", "\x01") and not (flags & 2):
                offset = base + (extent - track_start_lba) * sector_size
                files[normalized] = (offset, size)
        pos += length
    return files


def find_gdi_root_file(gdi: Path, target: str) -> tuple[dict[str, object], int, int]:
    data_tracks = [track for track in parse_gdi(gdi) if int(track["control"]) & 4]
    if not data_tracks:
        raise SystemExit(f"{gdi}: no data track found")
    track = max(data_tracks, key=lambda item: int(item["start"]))

    pvd = read_user_sector(track, 16)
    if pvd[1:6] != b"CD001":
        raise SystemExit(f"{gdi}: primary volume descriptor not found")
    root = parse_dir_record(pvd[156 : 156 + pvd[156]])
    if root is None:
        raise SystemExit(f"{gdi}: root directory record not found")
    root_extent, root_size, _root_name = root
    root_rel = lba_to_relative(track, root_extent)
    root_bytes = bytearray()
    for i in range(math.ceil(root_size / 2048)):
        root_bytes.extend(read_user_sector(track, root_rel + i))
    root_bytes = root_bytes[:root_size]

    wanted = target.upper()
    pos = 0
    while pos < len(root_bytes):
        length = root_bytes[pos]
        if length == 0:
            pos = ((pos // 2048) + 1) * 2048
            continue
        record = bytes(root_bytes[pos : pos + length])
        parsed = parse_dir_record(record)
        if parsed is not None:
            extent, size, name = parsed
            if normalize_iso_name(name) == wanted:
                return track, extent, size
        pos += length
    raise SystemExit(f"{target}: not found in {gdi}")


def lba_to_relative(track: dict[str, object], lba: int) -> int:
    start = int(track["start"])
    return lba - start if lba >= start else lba


def normalize_iso_name(name: str) -> str:
    if name in ("\x00", "\x01"):
        return name
    return name.split(";", 1)[0].upper()


def parse_dir_record(record: bytes) -> tuple[int, int, str] | None:
    if len(record) < 34 or record[0] < 34:
        return None
    extent = int.from_bytes(record[2:6], "little")
    size = int.from_bytes(record[10:14], "little")
    name_len = record[32]
    name = record[33 : 33 + name_len].decode("ascii", "replace")
    return extent, size, name


def parse_gdi(path: Path) -> list[dict[str, object]]:
    lines = [line.strip() for line in path.read_text().splitlines() if line.strip()]
    if not lines:
        raise SystemExit(f"{path}: empty GDI")
    count = int(lines[0])
    tracks = []
    for line in lines[1 : 1 + count]:
        parts = line.split()
        if len(parts) < 6:
            raise SystemExit(f"{path}: malformed GDI track line: {line}")
        tracks.append(
            {
                "number": int(parts[0]),
                "start": int(parts[1]),
                "control": int(parts[2]),
                "sector_size": int(parts[3]),
                "path": path.parent / parts[4],
                "offset": int(parts[5]),
            }
        )
    return tracks


def parse_iso_dir_record_at(data: bytes, pos: int) -> tuple[int, int, int, int, str] | None:
    if pos >= len(data) or data[pos] < 34:
        return None
    length = data[pos]
    record = data[pos : pos + length]
    extent = int.from_bytes(record[2:6], "little")
    size = int.from_bytes(record[10:14], "little")
    flags = record[25]
    name_len = record[32]
    name = record[33 : 33 + name_len].decode("ascii", "replace")
    return length, extent, size, flags, name


def pic_boot_file_and_key(pic: bytes) -> tuple[str, bytes]:
    if len(pic) < 0x4000:
        raise SystemExit("expected a full 0x4000-byte PIC binary")

    name = bytearray(14)
    for i in range(7):
        name[i] = pic[0x7C0 + i * 2]
        name[i + 7] = pic[0x7E0 + i * 2]

    key = bytearray(8)
    for i in range(7):
        key[i] = pic[0x780 + i * 2]
    key[7] = pic[0x7A0]

    return name.rstrip(b"\0").decode("ascii", "replace"), bytes(key)


def read_user_sector(track: dict[str, object], rel_sector: int) -> bytes:
    sector_size = int(track["sector_size"])
    path = Path(track["path"])
    if sector_size == 2352:
        off = rel_sector * sector_size + 16
        size = 2048
    elif sector_size == 2048:
        off = rel_sector * sector_size
        size = 2048
    else:
        raise SystemExit(f"unsupported sector size {sector_size}")
    with path.open("rb") as f:
        f.seek(off)
        data = f.read(size)
    if len(data) != size:
        raise SystemExit(f"{path}: short read at sector {rel_sector}")
    return data
