"""Read hash-pinned PS2 and NAOMI source media using bundled helpers.

Only the supplied media, contract and scratch directory are read. Extracted
discs are temporary and are removed when the reader closes. No checkout or
previous run is required. The reader supplies source bytes, not game ROMs.
"""
from __future__ import annotations

from contextlib import contextmanager
import hashlib
import json
import math
from pathlib import Path
import re
import shutil
import struct
import subprocess
import tempfile
import zipfile


def require(ok, message):
    if not ok:
        raise ValueError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def file_identity(path):
    with Path(path).open('rb') as stream:
        return {'bytes': Path(path).stat().st_size,
                'sha256': hashlib.file_digest(stream, 'sha256').hexdigest()}


class Disc:
    def __init__(self, path, pin):
        import iso9660
        require(file_identity(path) == pin['iso'], 'Selected PS2 disc identity differs')
        self.pin = pin
        self.stream = Path(path).open('rb')
        try:
            files = {n: (lba*2048, size) for n, lba, size, directory in
                     iso9660.walk(self.stream, *iso9660.root(self.stream)) if not directory}
            self.base, length = files['/X_DATA.BIN']
            header = self.read(self.base, 8)
            require(header[:4] == b'AFS\0', 'Missing X_DATA AFS header')
            count = struct.unpack_from('<I', header, 4)[0]
            require(351 <= count <= 4096 and 8+count*8 <= length, 'Invalid AFS entry count')
            table = self.read(self.base+8, count*8)
            self.entries = [struct.unpack_from('<II', table, i*8) for i in range(count)]
            require(all(o+s <= length for o, s in self.entries), 'AFS entry exceeds container')
        except BaseException:
            self.stream.close()
            raise

    def read(self, offset, length):
        self.stream.seek(offset)
        data = self.stream.read(length)
        require(len(data) == length, 'Truncated source disc')
        return data

    def entry(self, number):
        require(type(number) is int and 0 <= number < len(self.entries), 'Unknown AFS entry')
        offset, size = self.entries[number]
        return self.read(self.base+offset, size)

    def components(self):
        import bizlz
        decoded, _ = bizlz.decompress(self.entry(350), max_out=32*1024*1024)
        require(decoded is not None and decoded[:4] == b'MWo3' and
                self.pin['package_name'].encode() in decoded[:64], 'Wrong Upper package')
        n1, n2 = struct.unpack_from('<II', decoded, 12)
        require(n1 > 0 and n2 > 0 and 64+n1+n2 <= len(decoded), 'Invalid package extent')
        result = (decoded[64:64+n1], decoded[64+n1:64+n1+n2])
        require(all(digest(data) == self.pin['comp'+str(i+1)+'_sha256']
                    for i, data in enumerate(result)), 'Decoded Upper component differs')
        return result


@contextmanager
def ps2(path, pin, scratch, chdman):
    with tempfile.TemporaryDirectory(prefix='ps2-', dir=scratch) as directory:
        source = Path(path)
        if source.suffix.lower() == '.chd':
            require(shutil.disk_usage(scratch).free >= pin['iso']['bytes']+1024**3,
                    'Insufficient scratch space for PS2 disc')
            source = Path(directory)/'source.iso'
            subprocess.run([str(chdman), 'extractdvd', '-i', str(path), '-o', str(source)],
                           check=True, stdout=subprocess.DEVNULL)
        reader = Disc(source, pin)
        try:
            yield reader
        finally:
            reader.stream.close()


@contextmanager
def naomi(chd, archive, pin, scratch, chdman):
    import naomi_media
    import public_kit_des
    info = subprocess.check_output([str(chdman), 'info', '-i', str(chd)], text=True)
    hashes = re.findall(r'^\s*SHA1:\s*([0-9a-f]{40})\s*$', info, re.MULTILINE | re.IGNORECASE)
    require(hashes == [pin['chd_sha1']], 'Selected NAOMI CHD identity differs')
    with zipfile.ZipFile(archive) as source:
        require(source.namelist().count(pin['pic_member']) == 1, 'Missing or duplicate PIC')
        pic = source.read(pin['pic_member'])
    require(digest(pic) == pin['pic_sha256'], 'Selected NAOMI PIC identity differs')
    require(shutil.disk_usage(scratch).free >= 3*1024**3, 'Insufficient scratch space for GD-ROM')
    with tempfile.TemporaryDirectory(prefix='naomi-', dir=scratch) as directory:
        gdi = Path(directory)/'source.gdi'
        subprocess.run([str(chdman), 'extractcd', '-i', str(chd), '-o', str(gdi)],
                       check=True, stdout=subprocess.DEVNULL)
        _, key = naomi_media.pic_boot_file_and_key(pic)
        track, extent, size = naomi_media.find_gdi_root_file(gdi, 'ZERO3ROM.BIN')
        require(size == pin['decrypted_bytes'], 'NAOMI payload extent differs')
        relative = naomi_media.lba_to_relative(track, extent)
        sector_size = int(track['sector_size'])
        require(sector_size in (2048, 2352), 'Unsupported GD-ROM sector format')
        skip = 16 if sector_size == 2352 else 0
        payload = bytearray()
        with Path(track['path']).open('rb') as stream:
            stream.seek(relative*sector_size)
            for _ in range(math.ceil(size/2048)):
                sector = stream.read(sector_size)
                require(len(sector) == sector_size, 'Truncated GD-ROM track')
                payload.extend(sector[skip:skip+2048])
        decoded = public_kit_des.decrypt(bytes(payload[:size]), key)
        require(len(decoded) == pin['decrypted_bytes'] and
                hashlib.md5(decoded).hexdigest() == pin['decrypted_md5'],
                'Decoded NAOMI payload identity differs')
        files = naomi_media.embedded_iso_root_files(decoded)
        require(all(0 <= off <= len(decoded) and 0 <= size <= len(decoded)-off
                    for off, size in files.values()), 'NAOMI resource exceeds payload')
        yield decoded, files


def main():
    import argparse
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--self-test', action='store_true')
    parser.add_argument('--contract', type=Path)
    parser.add_argument('--ps2-us', type=Path)
    parser.add_argument('--ps2-jp', type=Path)
    parser.add_argument('--naomi-chd', type=Path)
    parser.add_argument('--naomi-pic', type=Path)
    parser.add_argument('--chdman', type=Path)
    parser.add_argument('--scratch', type=Path)
    parser.add_argument('--receipt', type=Path)
    args = parser.parse_args()
    if args.self_test:
        self_test()
        return
    require(all(getattr(args, name) is not None for name in
                ('contract', 'ps2_us', 'ps2_jp', 'naomi_chd', 'naomi_pic', 'chdman', 'scratch', 'receipt')),
            'Contract, original media, chdman, scratch and receipt arguments are required')
    require(args.scratch.is_dir(), 'Existing scratch directory required')
    require(not args.receipt.exists(), 'Receipt already exists')
    contract = json.loads(args.contract.read_text())
    pins = contract['inputs']
    report = {'schema': 1, 'contract_sha256': digest(args.contract.read_bytes()),
              'scope': 'Original media readers only; no converted pools or game reconstruction.',
              'ps2': {}, 'chdman': file_identity(args.chdman)}
    for region in ('us', 'jp'):
        with ps2(getattr(args, 'ps2_'+region), pins['ps2'][region], args.scratch, args.chdman) as disc:
            components = disc.components()
            report['ps2'][region] = {
                'iso': pins['ps2'][region]['iso'],
                'components': [{'bytes': len(data), 'sha256': digest(data)} for data in components],
                'afs_entries': len(disc.entries), 'full_disc_identity_checked': True}
            print('PS2 '+region+': original disc and Upper components verified', flush=True)
    with naomi(args.naomi_chd, args.naomi_pic, pins['naomi'], args.scratch, args.chdman) as (data, files):
        report['naomi'] = {'payload': {'bytes': len(data), 'sha256': digest(data)},
                           'resources': {name: {'bytes': size, 'sha256': digest(data[off:off+size])}
                                         for name, (off, size) in sorted(files.items())}}
        print('NAOMI: original GD-ROM, PIC and decrypted payload verified', flush=True)
    report['passed'] = True
    args.receipt.write_text(json.dumps(report, indent=2, sort_keys=True)+'\n')


def self_test():
    import io
    # Original synthetic MWo3 package, encoded with literal BIZ words. Neither
    # fixture nor expected components contain source-game bytes.
    raw = bytearray(72)
    raw[:4] = b'MWo3'
    raw[32:44] = b'fixture.bin\0'
    struct.pack_into('<II', raw, 12, 4, 4)
    raw[64:] = b'ABCDwxyz'

    def encoded(data):
        return b''.join(b'\0\0'+data[i:i+32] for i in range(0, len(data), 32))

    disc = Disc.__new__(Disc)
    disc.pin = {'package_name': 'fixture.bin', 'comp1_sha256': digest(b'ABCD'),
                'comp2_sha256': digest(b'wxyz')}
    disc.entry = lambda number: encoded(raw)
    require(disc.components() == (b'ABCD', b'wxyz'), 'Synthetic package did not decode')
    saved = bytes(raw)
    for mutation in ('component', 'package', 'extent', 'magic'):
        raw[:] = saved
        if mutation == 'component':
            raw[-1] ^= 1
        elif mutation == 'package':
            raw[32] ^= 1
        elif mutation == 'extent':
            struct.pack_into('<I', raw, 12, 128)
        else:
            raw[0] ^= 1
        try:
            disc.components()
        except ValueError:
            pass
        else:
            raise AssertionError('Media reader accepted '+mutation)
    reader = Disc.__new__(Disc)
    reader.stream = io.BytesIO(b'abcdefgh')
    reader.base = 0
    reader.entries = [(4, 4)]
    require(reader.entry(0) == b'efgh', 'AFS extent read failed')
    for operation in (lambda: reader.entry(-1), lambda: reader.entry(1),
                      lambda: reader.entry(True), lambda: reader.read(4, 8)):
        try:
            operation()
        except ValueError:
            pass
        else:
            raise AssertionError('Invalid AFS read was accepted')
    print('Public media reader: synthetic package and 8 corruption/extent controls PASS')


if __name__ == '__main__':
    main()
