"""Pinned original voice decoder and resampler functions."""
from __future__ import annotations
import struct
from fractions import Fraction
import numpy as np
from public_kit_media import require, digest
def resample(pcm,source_rate,rate_word):
    import scipy
    from scipy.signal import resample_poly
    require(np.__version__=='2.2.6' and scipy.__version__=='1.15.3','Pinned voice resampler versions required')
    rate=Fraction(60000000*rate_word,2496*4096);target=round(rate)
    ratio=Fraction(target,source_rate)
    converted=resample_poly(np.asarray(pcm,dtype=np.float64),ratio.numerator,ratio.denominator,
                            window=('kaiser',8.6),padtype='constant')
    converted=np.clip(np.rint(converted/256),-128,127).astype(np.int8).tobytes()
    return converted,{'rate_word':rate_word,'effective_rate_fraction':[rate.numerator,rate.denominator],
                      'resample_rate_hz':target,'scipy_version':scipy.__version__,
                      'numpy_version':np.__version__,'window':['kaiser',8.6],
                      'rounding':'nearest ties to even; signed PCM8 without gain normalization'}

def voice_bank(blob, entry, census):
    require(blob[:4] == b'MOMO', 'Hyper sample container magic')
    count = struct.unpack_from('<I', blob, 4)[0]
    spans = [struct.unpack_from('<II', blob, 8+i*8) for i in range(count)]
    require(count == 4 and all(a+n <= len(blob) for a,n in spans), 'MOMO bounds')
    (ho,hs),(so,ss) = spans[:2]
    header = blob[ho:ho+hs]; at = header.find(b'IECSigaV')
    require(at >= 0, 'Original VAG metadata missing')
    count = struct.unpack_from('<I', header, at+12)[0]+1
    starts = [struct.unpack_from('<II', header, at+struct.unpack_from('<I',header,at+16+i*4)[0])
              for i in range(count)]
    rows=[]
    for index,(start,meta) in enumerate(starts):
        end=starts[index+1][0] if index+1<count else ss
        require(0 <= start < end <= ss and (end-start)%16 == 0, 'VAG sample bounds')
        data=blob[so+start:so+end]
        stop=next((a+16 for a in range(0,len(data),16) if data[a+1]&1),len(data))
        data=data[:stop];pin=census[(entry,index)]
        require(digest(data)==pin['adpcm_sha256'] and len(data)==pin['adpcm_bytes'],
                'Declared source sample identity changed')
        require(all(data[a]>>4 < 5 and data[a]&15 <= 12 for a in range(0,len(data),16)),
                'Unsupported PSX ADPCM predictor/shift')
        pcm=np.asarray(decode_psx_adpcm(data),dtype=np.int16)
        rows.append({'entry':entry,'sample':index,'sample_rate':meta&65535,
                     'adpcm_sha256':digest(data),'decoded_samples':len(pcm),
                     'decoded_pcm16_sha256':digest(pcm.astype('<i2').tobytes()),
                     'terminal_flags':data[-15],'pcm':pcm})
    return rows

COEFFICIENTS = (
    (0, 0),
    (60, 0),
    (115, -52),
    (98, -55),
    (122, -60),
)


def sign_extend_nibble(value: int) -> int:
    return value - 16 if value & 8 else value


def clamp_s16(value: int) -> int:
    return max(-32768, min(32767, value))


def decode_psx_adpcm(data: bytes) -> list[int]:
    require(len(data) % 16 == 0, "PSX ADPCM input is not frame aligned")
    samples: list[int] = []
    history_1 = 0
    history_2 = 0
    for offset in range(0, len(data), 16):
        frame = data[offset:offset + 16]
        predictor = frame[0] >> 4
        shift = frame[0] & 0x0F
        coefficient_1, coefficient_2 = COEFFICIENTS[predictor]
        for packed in frame[2:]:
            for nibble in (packed & 0x0F, packed >> 4):
                sample = (sign_extend_nibble(nibble) << 12) >> shift
                sample += (
                    history_1 * coefficient_1
                    + history_2 * coefficient_2
                    + 32
                ) >> 6
                sample = clamp_s16(sample)
                samples.append(sample)
                history_2 = history_1
                history_1 = sample
    return samples

