#!/usr/bin/env python3
"""Minimal ISO9660 walker for 2048-byte/sector images (PS2 DVD).
Usage: iso9660.py <iso> list
       iso9660.py <iso> extract <PATH> <out>
"""
import sys, struct

S = 2048

def rd(f, lba, size):
    f.seek(lba * S)
    return f.read(size)

def parse_dir(f, lba, size):
    data = rd(f, lba, size)
    out = []
    pos = 0
    while pos < size:
        ln = data[pos]
        if ln == 0:
            # skip to next sector boundary
            pos = (pos // S + 1) * S
            continue
        rec = data[pos:pos+ln]
        ext_lba = struct.unpack_from('<I', rec, 2)[0]
        ext_size = struct.unpack_from('<I', rec, 10)[0]
        flags = rec[25]
        name_len = rec[32]
        name = rec[33:33+name_len].decode('ascii', 'replace')
        if name not in ('\x00', '\x01'):
            out.append((name.split(';')[0], ext_lba, ext_size, bool(flags & 2)))
        pos += ln
    return out

def walk(f, lba, size, prefix=''):
    for name, elba, esize, isdir in parse_dir(f, lba, size):
        full = prefix + '/' + name
        if isdir:
            yield (full + '/', elba, esize, True)
            yield from walk(f, elba, esize, full)
        else:
            yield (full, elba, esize, False)

def root(f):
    pvd = rd(f, 16, 2048)
    assert pvd[1:6] == b'CD001'
    rec = pvd[156:156+34]
    rlba = struct.unpack_from('<I', rec, 2)[0]
    rsize = struct.unpack_from('<I', rec, 10)[0]
    return rlba, rsize

if __name__ == '__main__':
    iso, cmd = sys.argv[1], sys.argv[2]
    f = open(iso, 'rb')
    rlba, rsize = root(f)
    if cmd == 'list':
        for full, elba, esize, isdir in walk(f, rlba, rsize):
            t = 'd' if isdir else 'f'
            print(f"{t} lba={elba:>9} off=0x{elba*S:010x} size={esize:>11} ({esize/1048576:8.2f} MB)  {full}")
    elif cmd == 'extract':
        want, out = sys.argv[3], sys.argv[4]
        for full, elba, esize, isdir in walk(f, rlba, rsize):
            if full == want and not isdir:
                f.seek(elba * S)
                with open(out, 'wb') as o:
                    left = esize
                    while left:
                        chunk = f.read(min(left, 1 << 20))
                        o.write(chunk)
                        left -= len(chunk)
                print(f"extracted {full} ({esize} bytes) -> {out}")
                break
        else:
            print("not found", want)
