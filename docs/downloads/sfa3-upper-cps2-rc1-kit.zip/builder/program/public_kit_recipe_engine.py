"""Rebuild the SFZ3 Upper program ROMs by replaying a recipe over your decoded media.

The recipe is a list of operations per program image. Each operation writes bytes at
one image address:

  [addr, "c", source, offset, length]   copy bytes from a source view
  [addr, "e", source, offset, length]   copy decrypted 68000 code from a source program
                                         and encrypt it for its new address
  [addr, "f", value, length]            fill with one byte value
  [addr, "l", hex]                      literal bytes (our own code, addresses and data)
  [addr, "k", hex]                      literal plaintext code, encrypted at its address

A source view is one of your decoded pool files, or the stock arcade program image, read
raw or with its 16/32-bit words byte-swapped. Every source view, and every rebuilt member,
is checked against its SHA-256 before anything is written.

    python3 public_kit_recipe_engine.py --pools <pools> --ending-pools <ending pools> \
        --recipes <recipe dir> --out <new directory>
"""
import argparse
import hashlib
import json
import sys
import zlib
from pathlib import Path

from cps2_crypt import decode_key, _feistel, _mkboxes, _FN2, FN2_GA, FN2_GB
from cps2_encrypt import _feistel_dec, _key2_schedule

IMAGE_BYTES = 0x400000
MEMBER_BYTES = 0x80000


def require(ok, message):
    if not ok:
        raise ValueError(message)


def digest(blob):
    return hashlib.sha256(blob).hexdigest()


def swap16(blob):
    out = bytearray(blob)
    out[0::2], out[1::2] = blob[1::2], blob[0::2]
    return bytes(out)


def swap32(blob):
    require(len(blob) % 4 == 0, 'swap32 view needs whole 32-bit words')
    out = bytearray(len(blob))
    for k in range(4):
        out[k::4] = blob[3 - k::4]
    return bytes(out)


TRANSFORMS = {'raw': lambda b: b, 'swap16': swap16, 'swap32': swap32}


class Cipher:
    """CPS-2 opcode cipher for one key, with its 64K-entry schedule built once."""
    def __init__(self, key_bytes):
        self.master, self.lower, self.upper, _ = decode_key(key_bytes)
        self.boxes = _mkboxes(_FN2)
        self.schedule = None

    def _key(self, word_address):
        if self.schedule is None:
            self.schedule = _key2_schedule(self.master)
        return self.schedule[word_address & 0xffff]

    def decrypt(self, word, word_address):
        if not self.lower <= word_address <= self.upper:
            return word
        return _feistel(word, FN2_GA, FN2_GB, self.boxes, self._key(word_address))

    def encrypt(self, word, word_address):
        if not self.lower <= word_address <= self.upper:
            return word
        return _feistel_dec(word, FN2_GA, FN2_GB, self.boxes, self._key(word_address))


def load_sources(spec, pools, ending_pools):
    def pool(name):
        for root in (pools, ending_pools):
            path = root / name
            if path.is_file():
                return path.read_bytes()
        raise ValueError('Missing decoded pool: ' + name)
    sources, ciphers = {}, {}
    for sid, row in spec.items():
        blob = b''.join(pool(name) for name in row['pools'])
        blob = TRANSFORMS[row['view']](blob)
        require(len(blob) == row['bytes'] and digest(blob) == row['sha256'], 'Source view identity: ' + sid)
        sources[sid] = blob
        if row.get('key'):
            ciphers[sid] = Cipher(pool(row['key']))
    return sources, ciphers


def apply_image(image, ops, sources, ciphers, cipher):
    plain = {}  # word address -> plaintext word, encrypted at the end
    for op in ops:
        address, kind = op[0], op[1]
        if kind == 'c':
            _, _, sid, offset, length = op
            image[address:address + length] = sources[sid][offset:offset + length]
        elif kind == 'f':
            _, _, value, length = op
            image[address:address + length] = bytes([value]) * length
        elif kind == 'l':
            blob = bytes.fromhex(op[2])
            image[address:address + len(blob)] = blob
        elif kind in ('e', 'k'):
            if kind == 'e':
                _, _, sid, offset, length = op
                require(offset % 2 == 0 and length % 2 == 0, 'Code copies are whole words')
                src, source_cipher = sources[sid], ciphers[sid]
                words = [source_cipher.decrypt((src[offset + i] << 8) | src[offset + i + 1], (offset + i) >> 1)
                         for i in range(0, length, 2)]
            else:
                blob = bytes.fromhex(op[2])
                words = [(blob[i] << 8) | blob[i + 1] for i in range(0, len(blob), 2)]
            require(address % 2 == 0, 'Code writes are word aligned')
            for i, word in enumerate(words):
                plain[(address >> 1) + i] = word
        else:
            raise ValueError('Unknown recipe operation: ' + repr(kind))
    for word_address, word in plain.items():
        value = cipher.encrypt(word, word_address)
        image[2 * word_address] = value >> 8
        image[2 * word_address + 1] = value & 0xff


def rebuild(recipe, sources, ciphers, pools):
    key = (pools / recipe['key']).read_bytes()
    cipher = Cipher(key)
    members = {}
    for name, row in recipe['images'].items():
        if row['base'] == 'fill':
            image = bytearray([row['fill']]) * IMAGE_BYTES
        else:
            image = bytearray(sources[row['base']])
            require(len(image) == IMAGE_BYTES, 'Base image size')
        apply_image(image, row['ops'], sources, ciphers, cipher)
        blob = swap16(bytes(image))
        names = row['members']
        size = len(blob) // len(names)
        for i, member in enumerate(names):
            members[member] = blob[i * size:(i + 1) * size]
    for member, pin in recipe['members'].items():
        blob = members.get(member)
        require(blob is not None and len(blob) == pin['bytes'] and digest(blob) == pin['sha256'],
                'Rebuilt member differs: ' + member)
    return members


def load_recipe(path):
    raw = path.read_bytes()
    return json.loads(zlib.decompress(raw) if path.suffix == '.zlib' else raw)


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('--pools', type=Path, required=True)
    p.add_argument('--ending-pools', type=Path, required=True)
    p.add_argument('--recipes', type=Path, default=Path(__file__).resolve().parent)
    p.add_argument('--out', type=Path, required=True)
    p.add_argument('--region', action='append', choices=('us', 'jp'))
    a = p.parse_args()
    require(not a.out.exists(), 'Fresh output directory required')
    a.out.mkdir(parents=True)
    report = {}
    for region in a.region or ('us', 'jp'):
        recipe = load_recipe(a.recipes / (region + '-program.json.zlib'))
        sources, ciphers = load_sources(recipe['sources'], a.pools, a.ending_pools)
        members = rebuild(recipe, sources, ciphers, a.pools)
        (a.out / region).mkdir()
        for name, blob in members.items():
            (a.out / region / name).write_bytes(blob)
        report[region] = {name: {'bytes': len(b), 'sha256': digest(b)} for name, b in sorted(members.items())}
        print('rebuilt program', region, len(members), 'members', flush=True)
    (a.out / 'program-report.json').write_text(json.dumps(report, indent=1, sort_keys=True) + '\n')


if __name__ == '__main__':
    sys.exit(main())
