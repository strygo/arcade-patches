"""Install reviewed authored assembly objects retained as inert upper-ROM data.

The small payload is compiled from the project's assembly source by the
maintainer. The public applicator needs neither an assembler nor game assets.
"""
import argparse,hashlib,json
from pathlib import Path

ADDRESSES={'masks':0xa77d00,'programs':0xa77d40,'delay':0xa77dc0,'predicates':0xa77e00,'defense':0xa77e80,'crouch':0xa77ec0,'predicate_abi':0xa77f40}


def require(ok,message):
    if not ok:raise ValueError(message)


def construct(recipe):
    require(recipe['schema']==1 and recipe['origin']=='authored-assembly' and recipe['access_view']=='retained-inert-data','Authored residual contract')
    require(set(recipe['objects'])==set(ADDRESSES),'Complete authored object inventory')
    writes=[]
    for name,address in ADDRESSES.items():
        row=recipe['objects'][name];blob=bytes.fromhex(row['payload_hex'])
        require(row['address']==address and len(blob)==row['bytes'] and hashlib.sha256(blob).hexdigest()==row['sha256'],'Complete authored object identity')
        require(row['source']==f'asm/guile_cpu_{name}.asm' and len(row['source_sha256'])==64,'Authored source identity')
        require(blob and len(blob)%2==0 and address+len(blob)<=0xa78000,'Authored retained extent')
        writes.append((address,blob))
    spans=sorted((a,a+len(b))for a,b in writes)
    require(all(a[1]<=b[0]for a,b in zip(spans,spans[1:])),'Authored object overlap')
    return writes


def main():
    p=argparse.ArgumentParser(description=__doc__)
    for n in ('recipe','out'):p.add_argument('--'+n,type=Path,required=True)
    a=p.parse_args();writes=construct(json.loads(a.recipe.read_text()));data=bytearray(0x400000);mask=bytearray(len(data))
    for at,blob in writes:
        at-=0xa00000;data[at:at+len(blob)]=blob;mask[at:at+len(blob)]=b'\1'*len(blob)
    a.out.mkdir();(a.out/'upper.bin').write_bytes(data);(a.out/'upper.mask').write_bytes(mask)


if __name__=='__main__':main()
