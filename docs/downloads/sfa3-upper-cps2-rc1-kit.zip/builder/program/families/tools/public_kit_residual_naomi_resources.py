"""Original Naomi fighter descriptor and action records, bound to native readers.

Owner initializers copy their descriptor to actor+0x190. Animation selectors
read the first four pointer tables. The updater at 0x8c04e39c multiplies the
record's final word by12 for the scalar row; the successor reader multiplies
the signed word at+6 by10. This parser admits the measured initializer form
used by Sagat and rejects unknown forms and flow.
"""
import struct
from public_kit_graphics import require

BASE=0x8c020000
DISPATCH=BASE+0x10419c


def read(blob,address,size):
    at=address-BASE
    require(0<=at<=len(blob)-size,'Original Naomi resource bounds')
    return blob[at:at+size]


def u32(blob,address):return struct.unpack('<I',read(blob,address,4))[0]
def word(blob,address):return struct.unpack('<H',read(blob,address,2))[0]


def literal_word(blob,pc,register):
    instruction=word(blob,pc)
    require(instruction>>8==0x90+register,'Original Naomi PC-relative word load')
    return word(blob,pc+4+(instruction&255)*2)


def descriptor(blob,owner):
    require(owner==11,'Unqualified Naomi owner initializer')
    entry=u32(blob,DISPATCH+owner*4)
    require(literal_word(blob,entry,0)==0x190,'Original actor descriptor field')
    require(tuple(word(blob,entry+n*2) for n in (1,2,3))==(0x2fe6,0x6e43,0x4f22),'Original initializer actor/prologue binding')
    require(literal_word(blob,entry+8,6)==0x9c,'Complete original descriptor copy extent')
    load=word(blob,entry+10);require(load>>8==0xd7,'Original descriptor pointer load')
    address=u32(blob,((entry+14)&~3)+(load&255)*4)
    require(tuple(word(blob,entry+n*2) for n in range(6,13))==(0x04ee,0xe000,0x037e,0x0436,0x7004,0x3062,0x8bfa),
            'Complete original descriptor-copy loop')
    # Bind the actual animation-family lookup and scalar-row/index readers.
    require(read(blob,0x8c04e2f2,18).hex()=='44e055045d65379008454e0002605e0342a0','Original primary animation reader')
    require(read(blob,0x8c04e39c,18).hex()=='e48534530d60036200402c3008403c300221','Original12-byte scalar-row reader')
    require(read(blob,0x8c04e46a,12).hex()=='5385036308403c3000405c30','Original10-byte relative successor reader')
    values=struct.unpack('<39I',read(blob,address,0x9c))
    roots=values[:4];boundaries=sorted((*roots,values[4]));counts={root:(boundaries[boundaries.index(root)+1]-root)//4 for root in roots}
    require(len(set(roots))==4 and all(0<n<256 for n in counts.values()),'Original complete animation table bounds')
    require(all((boundaries[i+1]-boundaries[i])%4==0 for i in range(4)),'Original animation table alignment')
    targets=[u32(blob,root+i*4) for root in roots for i in range(counts[root])]
    return values,counts,(min(targets),min(roots))


def graph(blob,owner,family,action):
    values,counts,frame_bounds=descriptor(blob,owner);root=values[(0,2,1,3)[family]]
    require(0<=action<counts[root],'Original Naomi action extent')
    at=u32(blob,root+action*4);rows=[];seen=[]
    while at is not None and at not in seen:
        require(frame_bounds[0]<=at<=frame_bounds[1]-10 and at%2==0,'Original Naomi complete frame bounds')
        raw=read(blob,at,10);flags=raw[1]
        require(flags&63==0,'Unknown original Naomi frame flags')
        index=struct.unpack_from('<H',raw,8)[0];scalar=values[4]+index*12
        scalar_end=min(pointer for pointer in values[5:16] if pointer>values[4])
        require(values[4]<=scalar<=scalar_end-12,'Original Naomi scalar row extent')
        delta=struct.unpack_from('<h',raw,6)[0]
        nxt=None if flags&64 else at+delta*10
        seen.append(at);rows.append({'address':at,'prefix':raw[:4],'cel':struct.unpack_from('<H',raw,4)[0],
                                     'scalar':read(blob,scalar,12),'scalar_address':scalar,'next':nxt})
        at=nxt;require(len(rows)<2048,'Bounded original Naomi action graph')
    return rows,None if at is None else seen.index(at)


SAGAT_TEMPLATES=(0,0,1,2,3,2,5,2,3,2,9,10,11,12,13,14,15)


def construct(inputs,recipe):
    import hashlib
    from public_kit_copied_frames import root,graph as native_graph
    require(set(inputs)==set(recipe['inputs'])=={'arcade-jp','naomi'},'Complete original Naomi/native source inventory')
    for name,value in inputs.items():
        pin=recipe['inputs'][name]
        require(len(value)==pin['bytes']and hashlib.sha256(value).hexdigest()==pin['sha256'],'Original source identity '+name)
    native=inputs['arcade-jp'];program=inputs['naomi']
    long=lambda at:struct.unpack_from('>I',native,at)[0]
    bank=long(0xde6a0+11*4);targets=root(native,long(bank),0,'>')
    original,loop=native_graph(native,targets[34],0,'>')
    require(len(original)==16 and loop==15 and original[0]==0x1df200,'Complete original Sagat intro graph')
    rows,nloop=graph(program,11,0,34)
    require(len(rows)==17 and nloop==16,'Complete original Naomi intro graph')
    payload=bytearray();cel_bindings={}
    for ordinal,(index,row)in enumerate(zip(SAGAT_TEMPLATES,rows)):
        before=native[original[index]:original[index]+20];value=bytearray(before)
        value[:4]=row['prefix']
        if ordinal==0:
            require(before[10]==21 and row['scalar'][2]==3,'Original intro event projection preimage')
            value[10]=row['scalar'][2]
        normalized=row['scalar'][:8]+row['scalar'][8:10][::-1]+row['scalar'][10:]
        require(value[11:20]==normalized[3:12],'Original complete non-index scalar projection')
        cel=long(original[index]+4)
        if row['cel']in cel_bindings:require(cel_bindings[row['cel']]==cel,'Original cel alias projection')
        cel_bindings[row['cel']]=cel
        require(not value[1]&64 and bool(value[1]&128)==(ordinal==16),'Complete appended intro successor grammar')
        payload.extend(value)
    payload.extend(struct.pack('>I',0xac0110+16*20))
    require(len(payload)==344 and len(cel_bindings)==9,'Complete original intro extent and cel domain')
    return [(0xac0110,bytes(payload))],{'bytes':344,'frames':17,'original_native_frames':16,'loop':16,'cel_bindings':{str(k):v for k,v in sorted(cel_bindings.items())},'excluded':'Dee loss geometry requires original PL22 descriptor source and native reader binding'}


def load(pools):
    names=('sz3j.03c','sz3j.04c','sz3.05c','sz3.06c','sz3.07c','sz3.08c','sz3.09c','sz3.10b')
    packed=b''.join((pools/('arcade-jp-'+name)).read_bytes()for name in names)
    native=bytearray(packed);native[::2]=packed[1::2];native[1::2]=packed[::2]
    return {'arcade-jp':bytes(native),'naomi':(pools/'naomi-program.bin').read_bytes()}

def main():
    import argparse,json
    from pathlib import Path
    parser=argparse.ArgumentParser(description=__doc__)
    for name in ('recipe','pools','out'):parser.add_argument('--'+name,type=Path,required=True)
    args=parser.parse_args();writes,report=construct(load(args.pools),json.loads(args.recipe.read_text()))
    data=bytearray(0x400000);mask=bytearray(len(data))
    for at,value in writes:
        at-=0xa00000;require(0<=at<at+len(value)<=len(data)and not any(mask[at:at+len(value)]),'Expanded graph extent/overlap')
        data[at:at+len(value)]=value;mask[at:at+len(value)]=b'\1'*len(value)
    args.out.mkdir();(args.out/'upper.bin').write_bytes(data);(args.out/'upper.mask').write_bytes(mask)
    (args.out/'compiled.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')


if __name__=='__main__':main()
