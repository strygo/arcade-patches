"""Complete retained dispatch, reviewed Dhalsim graphs and Mika cancel packet."""
import hashlib,struct
from functools import lru_cache
from cps2_crypt import decrypt_rom
from public_kit_residual_appended_graphs import PRECURSORS,models


def require(ok,message):
    if not ok:raise ValueError(message)


def digest(b):return hashlib.sha256(b).hexdigest()


def swap(b):
    require(len(b)%2==0,'Whole source words');out=bytearray(b);out[::2]=b[1::2];out[1::2]=b[::2];return bytes(out)


@lru_cache(maxsize=1)
def opcodes(raw,key):return decrypt_rom(raw[:0x100000],key)[0]


def project(inputs,recipe):
    require(set(inputs)==set(recipe['inputs'])=={'arcade','key','comp1','comp2'},'Complete original retained packet inputs')
    require(recipe['region']in ('us','jp')and recipe['source_region']=='jp','Explicit canonical Japanese predecessor source')
    for n,b in inputs.items():require(len(b)==recipe['inputs'][n]['bytes'] and digest(b)==recipe['inputs'][n]['sha256'],'Whole retained packet source '+n)
    raw=inputs['arcade'];ops=opcodes(raw,inputs['key']);writes=[]
    require(len(recipe['dispatch'])==3,'Complete command/human/CPU dispatch family')
    for row,operand,address in zip(recipe['dispatch'],(0x2b15e,0x28ae8,0x28af4),(0xa79e00,0xa79e84,0xa79f08)):
        root=struct.unpack_from('>I',ops,operand)[0]
        require(ops[operand-2:operand]==b'\x20\x7c' and root==row['root'] and digest(ops[operand-2:operand+8])==row['reader_sha256'],'Actual original callback reader')
        prefix=raw[root:root+128];require(digest(prefix)==row['native_sha256'],'All32 original callback rows')
        pair=(0xa2c026,0xa2c038) if operand==0x2b15e else (0xa2c050,0xa2c058)
        require((row['old_entry'],row['relocation']['before'])==pair and row['relocation']['address']==address+128,'Reviewed own-entry redirect then complete Guile relocation')
        payload=prefix+struct.pack('>I',row['old_entry'])
        require(digest(payload)==row['initial_sha256'],'Original complete33-owner dispatch construction')
        writes.append((address,prefix+struct.pack('>I',row['relocation']['after'])))
    require(digest(repr(PRECURSORS).encode())==recipe['precursors_sha256'],'Complete reviewed precursor source inventory')
    source,native=models(raw,inputs['comp2'],15)
    native_frames={at for family in native.families for frames,_ in family for at in frames}
    native_cels={struct.unpack_from('>I',raw,at+4)[0]for at in native_frames}
    graph_reports=[]
    for spec,action in zip(PRECURSORS,(9,51,10,11,48,49,50)):
        payload=bytearray();original_objects=[]
        for row in spec['segments']:
            if 'link'in row:
                require(spec['target']<=row['link']<spec['target']+len(payload) and (row['link']-spec['target'])%20==0,'Whole reviewed graph bounded loop')
                payload.extend(struct.pack('>I',row['link']));continue
            at=row['source'];require(row['bytes']==20 and at in native_frames,'Complete original native source frame membership')
            value=bytearray(native.read(at,20));original_objects.append(at)
            for field,before,after in row['fields']:
                require(field in (0,6,8,9,10,14) and value[field]==before,'Reviewed frame-field whole preimage')
                value[field]=after
            payload.extend(value)
        count=len(payload)//20;require(len(payload)%20==4 and all(not payload[i*20+1]&0xc0 for i in range(count-1)) and payload[(count-1)*20+1]&128,'Complete precursor frame topology')
        frames,loop=source.families[7][action]
        require(len(frames)==count and loop is not None and struct.unpack('>I',payload[-4:])[0]==spec['target']+loop*20,'Original complete X-action topology')
        require([source.read(at,1)[0]for at in frames]==[payload[n*20]for n in range(count)],'All original action clocks')
        # Reviewed pose switches may change the cel field. Every resulting
        # cel must already belong to a complete canonical Dhalsim frame graph.
        require(all(struct.unpack_from('>I',payload,n*20+4)[0]in native_cels for n in range(count)),'Every reviewed pose binds an existing whole canonical native cel')
        require(all(payload[n*20+16:n*20+20]==native.read(at+16,4)for n,at in enumerate(original_objects)),'Original frame placement fields retained')
        writes.append((spec['target'],bytes(payload)));graph_reports.append({'action':action,'frames':count,'bytes':len(payload),'source_frames':original_objects})
    require(sum(len(b)for at,b in writes if 0xa7a600<=at<0xa7aa00)==848,'Complete seven precursor reservations')
    c2=inputs['comp2'];base=0x60b080
    u32=lambda at:struct.unpack_from('<I',c2,at-base)[0]
    callback=u32(0x74e498+26*4)
    require(callback==0x58c640 and struct.unpack_from('<4I',c2,0x623920-base)==(0x58ce90,0x58d530,0x58d560,0x58d680),'Actual original Mika normal callback/whole phase directory')
    for row in recipe['mika']['readers']:
        data=inputs['comp1'] if row['view']=='source'else ops
        at=row['address']-(0x1f0040 if row['view']=='source'else 0)
        require(digest(data[at:at+row['bytes']])==row['sha256'],'Complete original Mika owning initializer/reader')
    bank=u32(0x74e3f8+26*4);offsets=struct.unpack_from('<3h',c2,bank-base)
    require(offsets==(78,78,8),'Complete35-action original Mika cancel offsets')
    rows=[c2[bank+a-base:bank+a-base+70]for a in offsets]
    require(all(len(v)==70 for v in rows) and rows[0]==rows[1] and [v[68:70]for v in rows]==[b'\x08\x0a',b'\x08\x0a',b'\x09\x0b'],'All original Mika cancel banks and added action34')
    previous=struct.pack('>3h',74,74,6)+rows[2][:68]+rows[0][:68]
    require(raw[0x64ddc:0x64ddc+142]==previous,'Complete original native34-action cancel predecessor')
    packet=struct.pack('>3h',76,76,6)+rows[2]+rows[0]+b'\xff'*14
    require(len(packet)==160,'Whole original declared cancel reservation')
    packet=bytearray(packet)
    require([row['address']for row in recipe['mika']['edits']]==[0xa8810e,0xa8814a],'Complete reviewed Mika V-cancel amendment family')
    for row in recipe['mika']['edits']:
        at=row['address']-0xa88100;before=bytes.fromhex(row['before']);after=bytes.fromhex(row['after'])
        require(len(before)==len(after)in (2,4) and packet[at:at+len(before)]==before,'Reviewed original Mika full cancel-pair preimage')
        packet[at:at+len(after)]=after
    writes.append((0xa88100,bytes(packet)))
    require(sum(len(b)for _,b in writes)==1404,'Whole retained resource tranche')
    return writes,{'bytes':1404,'dispatch_directories':3,'native_rows_each':32,'reviewed_precursor_graphs':graph_reports,'mika_styles':3,'mika_actions':35,'mika_used_bytes':146,'declared_reservation_fill':14,'artwork':'All reviewed cel references bind canonical Dhalsim frame objects; no art emitted or altered'}


def construct(inputs,recipe):
    writes,report=project(inputs,recipe);require({str(at):digest(b)for at,b in writes}==recipe['outputs'],'Complete retained packet identities');return writes,report


def load_inputs(pools):
    names=('sz3j.03c','sz3j.04c','sz3.05c','sz3.06c','sz3.07c','sz3.08c','sz3.09c','sz3.10b');packed=b''.join((pools/('arcade-jp-'+n)).read_bytes()for n in names)
    raw=bytearray(packed);raw[::2]=packed[1::2];raw[1::2]=packed[::2]
    return {'arcade':bytes(raw),**{n:(pools/f).read_bytes()for n,f in {'key':'arcade-jp-sfz3j.key','comp1':'ps2-jp-comp1.bin','comp2':'ps2-jp-comp2.bin'}.items()}}


def main():
    import argparse,json
    from pathlib import Path
    p=argparse.ArgumentParser(description=__doc__)
    for n in ('pools','recipe','out'):p.add_argument('--'+n,type=Path,required=True)
    a=p.parse_args();writes,report=construct(load_inputs(a.pools),json.loads(a.recipe.read_text()));data=bytearray(0x400000);mask=bytearray(len(data))
    for at,b in writes:at-=0xa00000;require(0<=at<=len(data)-len(b) and not any(mask[at:at+len(b)]),'Complete packet nonoverlap');data[at:at+len(b)]=b;mask[at:at+len(b)]=b'\1'*len(b)
    a.out.mkdir();(a.out/'upper.bin').write_bytes(data);(a.out/'upper.mask').write_bytes(mask);(a.out/'resources.json').write_text(json.dumps(report))


if __name__=='__main__':main()
