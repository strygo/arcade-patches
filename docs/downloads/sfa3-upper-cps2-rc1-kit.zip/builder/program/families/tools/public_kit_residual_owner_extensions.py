"""Original Shin portrait/routes and complete Hawk shadow/voice policy resources."""
import hashlib,struct
from functools import lru_cache
from cps2_crypt import decrypt_rom
from public_kit_hover_objects import cel,tiles_for
from public_kit_graphics import graphics_bus,shuffle_bus,planar_to_pixels,GROUPS


def require(ok,message):
    if not ok:raise ValueError(message)


def digest(b):return hashlib.sha256(b).hexdigest()


def swap(b):
    require(len(b)%2==0,'Whole source words');out=bytearray(b);out[::2]=b[1::2];out[1::2]=b[::2];return bytes(out)


@lru_cache(maxsize=1)
def opcodes(raw,key):return decrypt_rom(raw[:0x100000],key)[0]


def project(inputs,recipe):
    require(set(inputs)==set(recipe['inputs'])=={'arcade','key','comp1','comp2','font','pixels'},'Complete extension original inventory')
    require(recipe['source_region']=='jp' and recipe['region']in ('us','jp'),'Explicit inherited Japanese source contract')
    for n,b in inputs.items():require(type(b)is bytes and len(b)==recipe['inputs'][n]['bytes'] and digest(b)==recipe['inputs'][n]['sha256'],'Complete original extension input '+n)
    raw=inputs['arcade'];ops=opcodes(raw,inputs['key']);c1=inputs['comp1'];c2=inputs['comp2'];base=0x60b080
    def read(at,size):
        require(base<=at<=base+len(c2)-size,'Original component field extent');return c2[at-base:at-base+size]
    def u32(at):return struct.unpack('<I',read(at,4))[0]
    def literal(at):
        a,z=struct.unpack_from('<2I',c1,at-0x1f0040)
        require(a>>26==15 and z>>26==9 and a>>16&31==z>>21&31==z>>16&31,'Actual original table-address producer')
        lo=z&65535;return ((a&65535)*65536+(lo-65536 if lo&32768 else lo))&0xffffffff
    voice=literal(0x437d9c);shadow=literal(0x437d4c)
    require((voice,shadow)==(0x751c38,0x751cd8),'Original Hawk voice/shadow reader roots')
    bank=literal(0x601ab0);require(bank==0x6294e0 and struct.unpack('<H',read(bank+70,2))[0]==343,'Original Hawk voice bank reader')
    policy=read(u32(voice+140),240);rows=list(struct.iter_unpack('<4H',policy))
    require(rows==[(v,v,0,0)for v in (0,0x220,0x221,0x222,0x223,0x22e,0x231,*range(0x580,0x597))],'Complete original thirty-cue policy')
    hawk=recipe['hawk'];frames=hawk['frames'];require(frames==sorted(set(frames)) and len(frames)>100,'Complete installed Hawk frame census')
    events=u32(0x74eb78+140);demand=[]
    for at in frames:
        cue=read(events+read(at+10,1)[0]*4,4)[2];require(cue<30,'Original frame cue bounds');demand.append([at,cue])
    maximum=max(read(at+14,1)[0]for at in frames);require(maximum==27,'Complete original shadow row demand')
    shadows=read(u32(shadow+140),112)
    require(digest(policy)==hawk['policy_sha256'] and digest(shadows)==hawk['shadow_sha256'],'Complete original Hawk policy/shadow witnesses')
    for owner in range(32):
        dst=struct.unpack_from('>I',raw,0xe0aa0+owner*4)[0]
        require(raw[dst:dst+40]==swap(read(u32(voice+owner*4),40)),'All32 native original cue-prefix controls')
    for owner,count in ((0,20),(16,24)):
        dst=struct.unpack_from('>I',raw,0xe0b20+owner*4)[0]
        require(raw[dst:dst+count*4]==swap(read(u32(shadow+owner*4),count*4)),'Complete native original shadow controls')
    shapes=sorted({a for a,_ in struct.iter_unpack('<2h',shadows)})
    require(shapes==[0,69,70,71,72,73,74,75,79],'Original shadow shape domain')
    for row in hawk['native_shapes']:
        at=0x2e514c;off=struct.unpack_from('>h',raw,at+row['index']*2)[0];ptr=struct.unpack_from('>I',raw,at+off+4)[0]
        count=row['blocks'];kind=row['kind'];size=10+count*(6 if kind==6 else 4)
        require(ptr==int(row['cel'],16) and struct.unpack_from('>H',raw,ptr)[0]==kind and digest(raw[ptr:ptr+size])==row['sha256'],'Complete retained native shadow object')
    writes=[(0xc6c000,swap(shadows)),(0xc6c070,swap(policy)),(0xc6c160,struct.pack('>4H',0x6c0,0x6e0,0x5e0,0x580))]
    # All32 Shin controls are projected from source; each complete native Akuma
    # object and original indexed tile is checked, not merely its pointer.
    portraits=bytearray();tiles=set()
    def frame(data,table,selector,owner,endian):
        off=struct.unpack_from(endian+'H',data,table+selector*2)[0];at=table+off+owner*8
        return data[at:at+4],struct.unpack_from(endian+'I',data,at+4)[0]
    for selector in range(32):
        header,source=frame(c2,0x6ae30,selector,36,'<');akuma,z=frame(c2,0x6ae30,selector,2,'<');native,n=frame(raw,0x301fa2,selector,2,'>')
        obj=cel(c2,source-base,'<',base)
        require(obj==cel(c2,z-base,'<',base)==cel(raw,n,'>') and akuma==native,'Complete source/native Shin portrait object/control')
        for code,_,_,_ in tiles_for(obj['commands']):
            image=inputs['font'][(code+0x1c00)*128:(code+0x1c01)*128];physical=(code+0x16c00)*128
            require(len(image)==128 and inputs['pixels'][physical:physical+128]==image,'Independent original graphics Shin portrait pixels');tiles.add(code)
        portraits.extend(header+struct.pack('>I',n))
    writes.append((0xc5a600,bytes(portraits)))
    route_table=0x37338c;directory=c2[route_table:route_table+80]
    require(digest(directory)=='eefb765d2e38078a8f7a82d29ea2074555f140e7529e92461d78dee4f5c70f5e','Original whole forty-owner route directory')
    def route(owner):
        at=route_table+struct.unpack_from('<H',directory,owner*2)[0];return c2[at:at+160]
    source=route(36);require(source==route(2) and len(source)==160 and max(source)<38,'Complete original Shin/Akuma route alias')
    choices=[source[n:n+10]for n in range(0,160,10)];eligible=[n for n,r in enumerate(choices)if not set(r)&{35,37}]
    require(eligible,'Original supported route inventory');mapping=[next((n+s)%16 for s in range(16)if(n+s)%16 in eligible)for n in range(16)]
    require(mapping==recipe['shin']['route_map'] and digest(source)==recipe['shin']['route_sha256'],'Original source-bound complete route policy')
    writes.append((0xc5a8b0,struct.pack('>H',74)+b''.join(choices[n]for n in mapping)))
    opponents=c2[0xae90:0xae90+40];require(len(opponents)==40 and opponents[36]==opponents[2]==10,'Original Shin/Akuma opponent map')
    writes.append((0xc5a888,opponents))
    require(sum(len(v)for _,v in writes)==818,'Whole extension family extent')
    return writes,{'bytes':818,'shadow_rows':28,'voice_rows':30,'command_bases':4,'portrait_frames':32,'original_graphics_tiles':len(tiles),'first_original_tile':min(tiles),'route_choices':16,'opponent_rows':40,'candidate_canvas_used':False}


def construct(inputs,recipe):
    writes,report=project(inputs,recipe);require({str(at):digest(b)for at,b in writes}==recipe['outputs'],'Whole source-derived extension outputs');return writes,report


def load_inputs(pools):
    names=('sz3j.03c','sz3j.04c','sz3.05c','sz3.06c','sz3.07c','sz3.08c','sz3.09c','sz3.10b')
    values={'arcade':swap(b''.join((pools/('arcade-jp-'+n)).read_bytes()for n in names))}
    values.update({n:(pools/f).read_bytes()for n,f in {'key':'arcade-jp-sfz3j.key','comp1':'ps2-jp-comp1.bin','comp2':'ps2-jp-comp2.bin','font':'ps2-jp-font353.bin'}.items()})
    members={n:(pools/('arcade-jp-'+n)).read_bytes()for group in GROUPS for n in group}
    values['pixels']=planar_to_pixels(shuffle_bus(graphics_bus(members)))
    return values


def main():
    import argparse,json
    from pathlib import Path
    p=argparse.ArgumentParser(description=__doc__)
    for n in ('pools','recipe','out'):p.add_argument('--'+n,type=Path,required=True)
    a=p.parse_args();writes,report=construct(load_inputs(a.pools),json.loads(a.recipe.read_text()));data=bytearray(0x400000);mask=bytearray(len(data))
    for at,b in writes:at-=0xa00000;data[at:at+len(b)]=b;mask[at:at+len(b)]=b'\1'*len(b)
    a.out.mkdir();(a.out/'upper.bin').write_bytes(data);(a.out/'upper.mask').write_bytes(mask);(a.out/'resources.json').write_text(json.dumps(report))


if __name__=='__main__':main()
