"""Pure original-media CPU packet projection; no development imports or compiler.

Regional PS2 data supplies programs and masks. Both displays inherit the
canonical Japanese arcade CPU directory/control view explicitly.
"""
import argparse
import hashlib
import json
from pathlib import Path
import struct

HEADERS = (4, 4, 3, 8)
READERS = (0x274648, 0x2747a4, 0x274a04, 0x274cec)
NATIVE_TABLES = tuple(p + 0x128e for p in (0xdf492, 0xdf512, 0xdf592, 0xdf612))
NATIVE_MASK = 0xc845a
CANONICAL = '600f686a6ef90225c48231c0fbad86c7ca2b4eeddc93691b479a5b8a3f3b3cd5'


def require(ok, message):
    if not ok: raise ValueError(message)


def digest(blob): return hashlib.sha256(blob).hexdigest()


def swap(blob):
    require(len(blob) % 2 == 0, 'Complete source words required')
    result = bytearray(len(blob)); result[::2] = blob[1::2]; result[1::2] = blob[::2]
    return bytes(result)


def read(blob, at, size):
    require(type(at) is int and type(size) is int and 0 <= at <= len(blob) - size and size >= 0, 'Original resource extent')
    return blob[at:at + size]


def literal(c1, at):
    hi, lo = struct.unpack('<2I', read(c1, at - 0x1f0040, 8))
    require(hi >> 26 == 15 and lo >> 26 == 9 and hi >> 16 & 31 == lo >> 21 & 31 == lo >> 16 & 31, 'Original CPU LUI/ADDIU root reader')
    immediate = lo & 65535
    return ((hi & 65535) * 65536 + (immediate - 65536 if immediate & 32768 else immediate)) & 0xffffffff


def convert(blob, family):
    require(type(family) is int and 0 <= family < 4 and len(blob) % 2 == 0 and len(blob) >= HEADERS[family] * 2, 'Complete typed CPU root extent')
    phases = struct.unpack_from('<' + str(HEADERS[family]) + 'h', blob)
    require(all(HEADERS[family] * 2 <= p < len(blob) and p % 2 == 0 for p in phases), 'CPU phase offsets')
    converted = bytearray(swap(blob))
    if family in (1, 2):
        for phase in sorted(set(phases)):
            weights = read(blob, phase, 96)
            require(max(weights) < 128, 'CPU signed probability selector')
            count = max(weights) + 1
            pointers = struct.unpack('<' + str(count) + 'h', read(blob, phase + 96, count * 2))
            require(all(0 <= phase + p <= len(blob) - 2 and (phase + p) % 2 == 0 for p in pointers), 'CPU weighted program pointer extent')
            converted[phase:phase + 96] = weights
    return bytes(converted), phases


def project(inputs, recipe):
    require(recipe['schema'] == 1 and recipe['region'] in ('us', 'jp') and recipe['native_region'] == 'jp', 'Explicit regional source and inherited JP native contract')
    require(set(inputs) == set(recipe['inputs']) == {'comp1', 'comp2', 'arcade'}, 'Complete original CPU source inventory')
    for name, blob in inputs.items():
        require(type(blob) is bytes and len(blob) == recipe['inputs'][name]['bytes'] and digest(blob) == recipe['inputs'][name]['sha256'], 'Complete original CPU input ' + name)
    c1, c2, native = inputs['comp1'], inputs['comp2'], inputs['arcade']
    require(len(native) == 0x400000 and digest(native) == CANONICAL, 'Canonical Japanese raw CPU view')
    region = recipe['region']; base = 0x60b080 if region == 'jp' else 0x60ad00
    delta = 0x70 if region == 'jp' else 0; data_delta = 0x12b0 if region == 'jp' else 0
    links = recipe['links']
    require(links['region'] == region and all(links[n + '_sha256'] == digest(inputs[n]) for n in ('comp1', 'comp2')), 'Original accepted CPU link recipe source identity')
    require(len(links['fei_programs']) == 4 and len(links['program_tables']) == 12 and len(links['mask_tables']) == 3, 'Complete CPU link object census')
    tables = [literal(c1, p + delta) for p in READERS]
    directories = [struct.unpack('<40I', read(c2, p - base, 160)) for p in tables]
    require(all(base <= at < base + len(c2) and at % 2 == 0 for row in directories for at in row), 'All forty-owner CPU source roots')
    boundaries = sorted({at for row in directories for at in row})
    source_objects = []
    def original(start, end, role):
        blob = read(c2, start - base, end - start)
        source_objects.append({'role': role, 'address': start, 'bytes': len(blob), 'sha256': digest(blob)})
        return blob
    roots = [row[23] for row in directories]
    foreign = {at for row in directories for owner, at in enumerate(row) if owner != 23}
    begin = min(roots); end = min(at for at in foreign if at > begin)
    require(base <= begin < max(roots) < end <= base + len(c2) and 0 < end - begin < 0x4000 and not any(begin <= at < end for at in foreign), 'Complete Evil CPU allocation')
    packet = bytearray(swap(original(begin, end, 'evil_programs')))
    for family, root in enumerate(roots):
        phases = struct.unpack('<' + str(HEADERS[family]) + 'h', read(c2, root - base, HEADERS[family] * 2))
        require(all(p >= HEADERS[family] * 2 and p % 2 == 0 and root + p < end for p in phases), 'Evil complete CPU phase header')
        if family in (1, 2):
            for offset in sorted(set(phases)):
                at = root + offset; weights = read(c2, at - base, 96)
                require(max(weights) < 128, 'Evil probability selector')
                count = max(weights) + 1
                require(at + 96 + count * 2 <= end, 'Evil weighted table extent')
                refs = struct.unpack('<' + str(count) + 'h', read(c2, at - base + 96, count * 2))
                require(all(begin <= at + n < end - 2 and (at + n) % 2 == 0 for n in refs), 'Evil shared tail bounds')
                packet[at - begin:at - begin + 96] = weights
    writes = {'evil_programs': (0xbc2000, bytes(packet))}
    owner_roots = {23: [0xbc2000 + root - begin for root in roots]}
    guile_cursor = 0xb00000; guile = []; fei = []
    for family, row in enumerate(directories):
        for owner in (32, 33):
            start = row[owner]; finish = next(at for at in boundaries if at > start)
            converted, _ = convert(original(start, finish, ('guile' if owner == 32 else 'fei') + '_' + str(family)), family)
            if owner == 32:
                guile.append(guile_cursor); guile_cursor += len(converted)
            else:
                address = links['fei_programs'][family]; fei.append(address)
                writes['fei_program_' + str(family)] = (address, converted)
    owner_roots[32] = guile; owner_roots[33] = fei
    controls = []
    # Guile's complete resident-prefix census is observational: Upper variants
    # are intentionally not substituted for canonical native common rows.
    for family, pointers in enumerate(directories):
        for owner in range(32):
            prefix = read(c2, pointers[owner] - base, 16); projected = bytearray(swap(prefix))
            if family in (1, 2):
                first = struct.unpack_from('<h', prefix)[0]
                require(first >= 0, 'Resident CPU header offset')
                if first < 16: projected[first:] = prefix[first:]
            native_root = struct.unpack('>I', read(native, NATIVE_TABLES[family] + owner * 4, 4))[0]
            same = bytes(projected) == read(native, native_root, 16)
            controls.append({'family': family, 'owner': owner, 'equal': same})
            if owner in (0, 1, 3, 4, 29):
                require(same == ((family, owner) != (3, 4)), 'Resident source/native CPU prefix correspondence')
    for owner, allocation in ((34, 0xbea000), (35, 0xc6e000), (36, 0xc56000)):
        roots = [row[owner] for row in directories]
        foreign = {at for row in directories for i, at in enumerate(row) if i != owner}
        if owner == 34:
            begin = min(roots); end = min(at for at in foreign if at > begin)
            require(max(roots) < end and end - begin < 0x4000, 'Dee complete CPU bounds')
        else:
            expected, finish, phases, terminators = (
                ((0x671f60,0x67203c,0x6724d0,0x6729ae),0x672b38,(16,164,268,298,16,16,16,16),(162,266,296,392)) if owner == 35 else
                ((0x672b80,0x672c3a,0x673fd0,0x6749a4),0x674bb4,(16,174,358,456,16,16,16,16),(172,356,454,526)))
            begin = expected[0] + data_delta; end = finish + data_delta
            require(roots == [at + data_delta for at in expected], 'Complete Hawk/Shin CPU root addresses')
            require(struct.unpack('<8h', read(c2, roots[3] - base, 16)) == phases and end == roots[3] + terminators[-1] + 2, 'Original final CPU interrupt catalogue')
            require(all(read(c2, roots[3] + n - base, 2) == b'\x02\xff' for n in terminators), 'All complete interrupt terminators')
        require(not any(begin <= at < end for at in foreign), 'CPU owner allocation interleaves foreign resources')
        original(begin, end, 'owner_' + str(owner))
        for family, root in enumerate(roots): convert(read(c2, root - base, end - root), family)
        owner_roots[owner] = [allocation + root - begin for root in roots]
    for index, row in enumerate(links['program_tables']):
        family = index % 4; count = (34, 35, 37)[index // 4]
        require(row['family'] == family and row['rows'] == count, 'Complete chronological CPU directory census')
        prefix = bytearray(read(native, NATIVE_TABLES[family], 128))
        struct.pack_into('>I', prefix, 23 * 4, owner_roots[23][family])
        payload = prefix + b''.join(struct.pack('>I', owner_roots[owner][family]) for owner in range(32, count))
        writes['program_table_' + str(index)] = (row['address'], bytes(payload))
    mask = literal(c1, 0x26c944 + delta)
    require(mask == literal(c1, 0x275910 + delta), 'Both original mask root readers')
    control = struct.pack('>1024I', *struct.unpack('<1024I', read(c2, mask - base, 4096)))
    require(control == read(native, NATIVE_MASK, 4096), 'Complete resident CPU mask control')
    for index, row in enumerate(links['mask_tables']):
        count = (34, 35, 37)[index]; require(row['rows'] == count, 'Chronological mask table extent')
        payload = struct.pack('>' + str(count * 32) + 'I', *struct.unpack('<' + str(count * 32) + 'I', read(c2, mask - base, count * 128)))
        writes['mask_table_' + str(index)] = (row['address'], payload)
    require(len(writes) == 20 and sum(len(blob) for _, blob in writes.values()) == 29488, 'Complete CPU table family extent')
    spans = sorted((at, at + len(blob)) for at, blob in writes.values())
    require(all(0xa00000 <= at < end <= 0xe00000 for at, end in spans) and all(a[1] <= b[0] for a, b in zip(spans, spans[1:])), 'CPU resource allocation boundaries/overlap')
    return writes, {'objects': len(writes), 'bytes': 29488, 'source_objects': source_objects,
                    'original_root_readers': [p + delta for p in READERS], 'resident_prefix_controls': controls,
                    'complete_native_mask_bytes': 4096, 'native_source_region': 'jp', 'regional_ps2_source': region}


def construct(inputs, recipe):
    writes, report = project(inputs, recipe)
    require(set(writes) == set(recipe['outputs']), 'Whole CPU output census')
    for name, (at, blob) in writes.items():
        require(recipe['outputs'][name] == {'address': at, 'bytes': len(blob), 'sha256': digest(blob)}, 'Complete CPU resource identity: ' + name)
    return writes, report


def load_inputs(pools, region):
    names = ['sz3j.03c', 'sz3j.04c'] + [f'sz3.{n:02d}c' for n in range(5,10)] + ['sz3.10b']
    return {'arcade': swap(b''.join((pools / ('arcade-jp-' + n)).read_bytes() for n in names)),
            **{n: (pools / ('ps2-' + region + '-' + n + '.bin')).read_bytes() for n in ('comp1', 'comp2')}}


def self_test():
    weights = bytes(n % 4 for n in range(96))
    source = struct.pack('<4h',8,8,8,8) + weights + struct.pack('<4h',104,106,108,110) + bytes(8)
    wanted = struct.pack('>4h',8,8,8,8) + weights + struct.pack('>4h',104,106,108,110) + bytes(8)
    require(convert(source,1)[0] == wanted, 'Independent typed CPU weights and pointers')
    controls = []
    for name, at, value in (('negative-weight',8,128),('escaped-phase',0,255),('escaped-tail',104,255)):
        changed = bytearray(source); changed[at] = value
        try: convert(bytes(changed),1)
        except ValueError: controls.append(name)
        else: raise ValueError('Typed CPU mutation accepted: ' + name)
    reader = bytearray(8); struct.pack_into('<2I',reader,0,0x3c026123,0x2442fffc)
    require(literal(reader,0x1f0040) == 0x6122fffc, 'Signed MIPS root reader')
    reader[3] = 0
    try: literal(reader,0x1f0040)
    except ValueError: controls.append('wrong-reader-opcode')
    else: raise ValueError('Unknown MIPS root reader accepted')
    return {'passed': True, 'negative_controls': controls}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('recipe','pools','out'): parser.add_argument('--'+name,type=Path)
    parser.add_argument('--self-test',action='store_true'); args=parser.parse_args()
    if args.self_test: print(json.dumps(self_test())); return
    require(args.recipe and args.pools and args.out, 'Recipe, originals and fresh output required')
    recipe=json.loads(args.recipe.read_text()); writes,report=construct(load_inputs(args.pools,recipe['region']),recipe)
    require(not args.out.exists(), 'CPU output already exists'); args.out.mkdir()
    data=bytearray(0x400000); mask=bytearray(len(data))
    for at,blob in writes.values():
        offset=at-0xa00000;data[offset:offset+len(blob)]=blob;mask[offset:offset+len(blob)]=b'\1'*len(blob)
    (args.out/'upper.bin').write_bytes(data);(args.out/'upper.mask').write_bytes(mask)
    (args.out/'resources.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')


if __name__=='__main__':main()
