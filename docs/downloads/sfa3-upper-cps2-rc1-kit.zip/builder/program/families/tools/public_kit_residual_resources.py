"""Complete Dee original frame packet with reviewed typed graph transformations.

The worker reconstructs original geometry, every pointed-to pixel and all
938 predecessor frames before applying existing scalar/graph edit recipes.
No original or final resource payload is stored in the recipe.
"""
import hashlib
import struct
from public_kit_actor import Data
from public_kit_frame_resources import cel
from public_kit_graphics import require

FAMILIES={0:tuple(range(40))+(43,47,48,49,50,51,52,53),1:tuple(range(48)),2:tuple(range(44)),3:tuple(range(31))}
# Whole source-frame templates from the original reviewed fixes11 graph recipes.
GRAPHS=((0xbda754,20,((0xbda5dc,()),(0xbda5f0,()),(0xbda604,((9,33,116),)),(0xbda548,()))),
 (0xbdf45c,21,((0xbda630,()),(0xbda644,((10,5,0),)),(0xbda658,((0,4,10),(9,34,117))),(0xbda424,()))),
 (0xbdf4b0,23,((0xbda698,()),(0xbda6ac,()),(0xbda6c0,((8,66,60),)),(0xbda6d4,((9,36,118),)),(0xbda6e8,((8,66,60),)),(0xbda424,()))),
 (0xbdf52c,28,((0xbda490,()),(0xbda4a4,()),(0xbda4b8,((0,6,2),(9,29,115))),(0xbda4b8,((0,6,4),(9,29,119))),(0xbda4cc,()),(0xbda4e0,()),(0xbda4f4,()),(0xbda548,()))))


def graph(inputs):
    data=Data(inputs['comp2-jp'],0x60b080,inputs['coords-jp'],0xb04000)
    roots=struct.unpack('<12I',data.read(data.u32(0x74ef38+34*4),48))
    require(roots[:4]==roots[4:8]==roots[8:],'Original Dee three-ISM root aliases')
    require(set(data.read(0x610430,16))=={35,36,37,38,39,52,53},'Complete original victory demand')
    records={};targets={};cels={};contexts={}
    def walk(start):
        chain=[];at=start
        while at is not None and at not in chain:
            require(len(chain)<512,'Bounded whole original action graph')
            chain.append(at);raw=data.read(at,20);sc=data.u32(at+4);_,_,nxt=data.frame(at)
            records[at]=(sc,nxt,24 if raw[1]&128 else 20);cels[sc]=data.cel(sc);at=nxt
        return chain
    for family,actions in FAMILIES.items():
        targets[family]=data.root(roots[family])[1]
        for action in actions:contexts[family,action]=walk(targets[family][action])
    projectile=data.root(data.u32(0x6142c0+37*4))[1];require(len(projectile)==4,'Whole Air Slasher root')
    for action,start in enumerate(projectile):contexts[4,action]=walk(start)
    require(len(records)==938 and len(cels)==326,'Complete original body/projectile domain')
    return data,records,cels,contexts,roots


def construct(inputs,recipe,pixels):
    sha=lambda b:hashlib.sha256(b).hexdigest()
    require(set(inputs)==set(recipe['inputs'])=={'comp2-jp','coords-jp','pixels34-jp','mask34-jp'},'Complete original Dee source inventory')
    require(recipe['source_region']=='jp' and recipe['region']in ('us','jp'),'Explicit original JP mechanical inheritance')
    for name,blob in inputs.items():
        p=recipe['inputs'][name];require(len(blob)==p['bytes']and sha(blob)==p['sha256'],'Original Dee source identity '+name)
    require(sha(pixels)==recipe['graphics_pixels_sha256'],'Qualified expanded graphics canvas identity')
    data,records,cels,contexts,roots=graph(inputs);packet=bytearray();mapping={};canvas_pixels=0
    require({r[0]for r in recipe['cels']}==set(cels) and len(recipe['cels'])==len(cels),'Complete original cel inventory')
    for source,dest,xy,bank,tiles in recipe['cels']:
        kind,blocks=cels[source]
        expected_xy=None if kind==18 else 0xbd2000+len(packet)
        expected_dest=0xbd2000+len(packet)+(0 if kind==18 else len(blocks)*4)
        require(xy==expected_xy and dest==expected_dest,'Complete sorted original cel allocator')
        coords,blob=cel(data,source,xy,tiles,inputs['pixels34-jp'],inputs['mask34-jp'],pixels,bank)
        packet.extend(coords or b'');packet.extend(blob);mapping[source]=dest
        canvas_pixels+=sum((((w>>24)&15)+1)*(((w>>28)&15)+1)*256 for _,_,w in blocks)
    require(0xbd2000+len(packet)==0xbd824c,'Complete326-cel original geometry extent')
    positions={};cursor=0xbd824c
    for source,(_,_,size)in sorted(records.items()):positions[source]=cursor;cursor+=size
    require(cursor==0xbdccf8,'Complete938-frame allocation extent')
    frames={}
    for source,(sc,nxt,size)in sorted(records.items()):
        raw=data.read(source,20);at=positions[source]
        blob=raw[:4]+struct.pack('>I',mapping[sc])+raw[8:16]+raw[16:18][::-1]+raw[18:20]
        if size==24:blob+=struct.pack('>I',positions[nxt])
        elif nxt is not None:require(positions[nxt]==at+20,'Complete original frame fallthrough')
        frames[at]=blob;packet.extend(blob)
    # Existing reviewed fixes7 field relocations, with original full-frame preimages.
    for at,field,before,after in ((0xbda450,9,0,26),(0xbda464,9,26,0),(0xbda464,10,0,1)):
        require(at in {positions[v]for v in contexts[3,19]},'Original action19 amendment context')
        row=bytearray(frames[at]);require(row[field]==before,'Original typed action19 preimage');row[field]=after;frames[at]=bytes(row)
        packet[at-0xbd2000:at-0xbd2000+len(row)]=row
    require(recipe['graph_recipe_sha256']==sha(repr(GRAPHS).encode()),'Complete reviewed graph transformation inventory')
    writes=[]
    for target,action,rows in GRAPHS:
        require(contexts[3,action],'Original replaced action domain')
        payload=bytearray()
        for index,(template,changes)in enumerate(rows):
            require(template in frames,'Graph template must be an original reconstructed whole frame')
            row=bytearray(frames[template][:20])
            for field,before,after in changes:
                require(field in (0,8,9,10)and row[field]==before,'Original typed graph-field preimage')
                row[field]=after
            require(bool(row[1]&128)==(index==len(rows)-1) and not row[1]&64,'Complete reviewed graph terminal-link grammar')
            payload.extend(row)
        payload.extend(struct.pack('>I',target+(len(rows)-1)*20))
        if target==0xbda754:packet[target-0xbd2000:target-0xbd2000+len(payload)]=payload
        else:writes.append((target,bytes(payload)))
    # PS2 and Naomi agree on the complete two-frame time-over draw pose.
    at=data.root(roots[0])[1][41];draw=[]
    while at is not None and at not in draw:
        draw.append(at);require(len(draw)<=2,'Complete original draw pose');_,_,at=data.frame(at)
    require(len(draw)==2 and at is None,'Original draw pose terminal graph')
    pose=bytearray()
    for at in draw:
        raw=data.read(at,20);sc=data.u32(at+4);require(sc in mapping,'Draw pose uses source-qualified existing cel')
        require(not raw[1]&128,'Draw pose has no absolute links')
        pose.extend(raw[:4]+struct.pack('>I',mapping[sc])+raw[8:16]+raw[16:18][::-1]+raw[18:20])
    writes.append((0xbdf5e0,bytes(pose)));writes.insert(0,(0xbd2000,bytes(packet)))
    return writes,{'bytes':sum(len(v)for _,v in writes),'original_frames':938,'original_cels':326,'source_pixel_instances_checked':canvas_pixels,'whole_reviewed_graphs':4,'draw_pose_frames':2,'unclaimed':'fixes14 loss-pose Naomi artwork and other fighter copied families'}


def main():
    import argparse
    import json
    from pathlib import Path
    parser=argparse.ArgumentParser(description=__doc__)
    for name in ('recipe','pools','canvas','out'):
        parser.add_argument('--'+name,type=Path,required=True)
    args=parser.parse_args();recipe=json.loads(args.recipe.read_text())
    names={'comp2-jp':'comp2.bin','coords-jp':'coords390.bin','pixels34-jp':'entry385-s0.bin','mask34-jp':'entry385-s0.mask'}
    inputs={name:(args.pools/('ps2-jp-'+filename)).read_bytes()for name,filename in names.items()}
    writes,report=construct(inputs,recipe,args.canvas.read_bytes())
    data=bytearray(0x400000);mask=bytearray(len(data))
    for address,blob in writes:
        offset=address-0xa00000
        require(0<=offset<offset+len(blob)<=len(data),'Complete expanded packet bounds')
        require(not any(mask[offset:offset+len(blob)]),'Complete expanded packet overlap')
        data[offset:offset+len(blob)]=blob;mask[offset:offset+len(blob)]=b'\1'*len(blob)
    args.out.mkdir();(args.out/'upper.bin').write_bytes(data);(args.out/'upper.mask').write_bytes(mask)
    (args.out/'compiled.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')


if __name__=='__main__':main()
