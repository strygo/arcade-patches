"""Whole reviewed appended move graphs from original native and PS2 sources.

Numeric templates are independently reviewed fixes11/fixes13 source recipes;
original rows are read from media, never embedded in this worker.
"""
import hashlib
import struct
from public_kit_graphics import require
from public_kit_dhalsim_tables import Owner,direct_projection,repoint_existing
from public_kit_copied_directories import u32
from public_kit_sakura_copied_resources import remap_events,relocate_missing

PACKETS=[{'target': 11247796, 'owner': 13, 'family': 2, 'action': 19, 'segments': [{'source': 2052330, 'bytes': 20, 'fields': []}, {'source': 2052106, 'bytes': 20, 'fields': []}, {'source': 2052126, 'bytes': 20, 'fields': []}, {'source': 2052146, 'bytes': 20, 'fields': []}, {'source': 2052166, 'bytes': 20, 'fields': []}, {'source': 2052186, 'bytes': 20, 'fields': []}, {'source': 2052146, 'bytes': 20, 'fields': []}, {'source': 2052166, 'bytes': 20, 'fields': []}, {'source': 2052246, 'bytes': 20, 'fields': []}, {'source': 2052266, 'bytes': 20, 'fields': []}, {'source': 2052286, 'bytes': 20, 'fields': []}, {'source': 2052306, 'bytes': 20, 'fields': []}, {'link': 11248016}]}, {'target': 11248040, 'owner': 13, 'family': 2, 'action': 20, 'segments': [{'source': 2052554, 'bytes': 20, 'fields': []}, {'source': 2052106, 'bytes': 20, 'fields': []}, {'source': 2052126, 'bytes': 20, 'fields': []}, {'source': 2052146, 'bytes': 20, 'fields': []}, {'source': 2052166, 'bytes': 20, 'fields': []}, {'source': 2052186, 'bytes': 20, 'fields': []}, {'source': 2052146, 'bytes': 20, 'fields': []}, {'source': 2052166, 'bytes': 20, 'fields': []}, {'source': 2052246, 'bytes': 20, 'fields': []}, {'source': 2052266, 'bytes': 20, 'fields': []}, {'source': 2052286, 'bytes': 20, 'fields': []}, {'source': 2052306, 'bytes': 20, 'fields': []}, {'link': 11248260}]}, {'target': 11252880, 'owner': 13, 'family': 3, 'action': 4, 'segments': [{'source': 2045194, 'bytes': 20, 'fields': []}, {'source': 2045214, 'bytes': 20, 'fields': []}, {'source': 2045234, 'bytes': 20, 'fields': [[0, 3, 1], [9, 9, 0]]}, {'source': 2045234, 'bytes': 20, 'fields': [[0, 3, 2]]}, {'source': 2045254, 'bytes': 20, 'fields': [[0, 3, 2]]}, {'source': 2045274, 'bytes': 20, 'fields': [[0, 1, 2]]}, {'source': 2045294, 'bytes': 20, 'fields': []}, {'source': 2045314, 'bytes': 20, 'fields': []}, {'source': 2045334, 'bytes': 20, 'fields': []}, {'source': 2045354, 'bytes': 20, 'fields': []}, {'source': 2045374, 'bytes': 20, 'fields': []}, {'source': 2045026, 'bytes': 20, 'fields': []}, {'link': 11253100}]}, {'target': 11262420, 'owner': 15, 'family': 3, 'action': 9, 'segments': [{'source': 10987176, 'bytes': 20, 'fields': []}, {'source': 2166714, 'bytes': 20, 'fields': []}, {'source': 10987216, 'bytes': 20, 'fields': []}, {'source': 10987236, 'bytes': 20, 'fields': []}, {'source': 10987256, 'bytes': 20, 'fields': []}, {'link': 11262480}]}, {'target': 11262524, 'owner': 15, 'family': 3, 'action': 10, 'segments': [{'source': 2166674, 'bytes': 20, 'fields': []}, {'source': 2166694, 'bytes': 20, 'fields': []}, {'source': 2166714, 'bytes': 20, 'fields': []}, {'source': 10987216, 'bytes': 20, 'fields': []}, {'source': 10987216, 'bytes': 20, 'fields': [[9, 0, 94]]}, {'source': 10987256, 'bytes': 20, 'fields': [[9, 20, 94]]}, {'link': 11262604}]}, {'target': 11262648, 'owner': 15, 'family': 3, 'action': 11, 'segments': [{'source': 10987528, 'bytes': 20, 'fields': []}, {'source': 2166882, 'bytes': 20, 'fields': []}, {'source': 2166714, 'bytes': 20, 'fields': []}, {'source': 10987216, 'bytes': 20, 'fields': []}, {'source': 10987484, 'bytes': 20, 'fields': []}, {'source': 10987504, 'bytes': 20, 'fields': []}, {'link': 11262728}]}, {'target': 11262772, 'owner': 15, 'family': 3, 'action': 48, 'segments': [{'source': 2167174, 'bytes': 20, 'fields': []}, {'source': 10987672, 'bytes': 20, 'fields': [[8, 96, 100]]}, {'source': 2167194, 'bytes': 20, 'fields': [[8, 70, 100]]}, {'source': 2167214, 'bytes': 20, 'fields': [[8, 70, 100]]}, {'source': 2167234, 'bytes': 20, 'fields': [[8, 70, 100]]}, {'source': 2167254, 'bytes': 20, 'fields': [[8, 70, 100]]}, {'link': 11262812}]}, {'target': 11262896, 'owner': 15, 'family': 3, 'action': 49, 'segments': [{'source': 2167278, 'bytes': 20, 'fields': []}, {'source': 10987796, 'bytes': 20, 'fields': [[8, 97, 101]]}, {'source': 2167298, 'bytes': 20, 'fields': [[8, 71, 101]]}, {'source': 2167318, 'bytes': 20, 'fields': [[8, 71, 101]]}, {'source': 2167338, 'bytes': 20, 'fields': [[8, 71, 101]]}, {'source': 2167358, 'bytes': 20, 'fields': [[8, 71, 101]]}, {'link': 11262936}]}, {'target': 11263020, 'owner': 15, 'family': 3, 'action': 50, 'segments': [{'source': 2167278, 'bytes': 20, 'fields': []}, {'source': 10987920, 'bytes': 20, 'fields': []}, {'source': 10987940, 'bytes': 20, 'fields': []}, {'source': 10987960, 'bytes': 20, 'fields': []}, {'source': 10987980, 'bytes': 20, 'fields': []}, {'source': 10988000, 'bytes': 20, 'fields': []}, {'link': 11263060}]}, {'target': 11263144, 'owner': 15, 'family': 3, 'action': 51, 'segments': [{'source': 2167486, 'bytes': 20, 'fields': []}, {'source': 10987300, 'bytes': 20, 'fields': []}, {'source': 2167506, 'bytes': 20, 'fields': []}, {'source': 2167526, 'bytes': 20, 'fields': []}, {'source': 2167546, 'bytes': 20, 'fields': []}, {'source': 2167566, 'bytes': 20, 'fields': []}, {'link': 11263184}]}, {'target': 11267420, 'owner': 16, 'family': 3, 'action': 12, 'segments': [{'source': 2220556, 'bytes': 20, 'fields': []}, {'source': 2220576, 'bytes': 20, 'fields': [[0, 4, 2], [3, 255, 0]]}, {'source': 2220576, 'bytes': 20, 'fields': [[0, 4, 2]]}, {'source': 2220596, 'bytes': 20, 'fields': []}, {'source': 2220616, 'bytes': 20, 'fields': []}, {'source': 2220636, 'bytes': 20, 'fields': []}, {'source': 2220656, 'bytes': 20, 'fields': []}]}]
PRECURSORS=[{'target': 10987176, 'segments': [{'source': 2166506, 'bytes': 20, 'fields': [[0, 2, 3]]}, {'source': 2166714, 'bytes': 20, 'fields': []}, {'source': 2166546, 'bytes': 20, 'fields': [[8, 69, 94], [9, 20, 0]]}, {'source': 2166546, 'bytes': 20, 'fields': [[8, 69, 94]]}, {'source': 2166566, 'bytes': 20, 'fields': [[8, 69, 94]]}, {'link': 10987236}]}, {'target': 10987280, 'segments': [{'source': 2167486, 'bytes': 20, 'fields': []}, {'source': 2161162, 'bytes': 20, 'fields': [[6, 133, 145], [8, 86, 73]]}, {'source': 2167506, 'bytes': 20, 'fields': []}, {'source': 2167526, 'bytes': 20, 'fields': []}, {'source': 2167546, 'bytes': 20, 'fields': []}, {'source': 2167566, 'bytes': 20, 'fields': []}, {'link': 10987320}]}, {'target': 10987404, 'segments': [{'source': 2166674, 'bytes': 20, 'fields': []}, {'source': 2166694, 'bytes': 20, 'fields': []}, {'source': 2166714, 'bytes': 20, 'fields': []}, {'source': 2166546, 'bytes': 20, 'fields': [[8, 69, 94], [9, 20, 0]]}, {'source': 2166546, 'bytes': 20, 'fields': [[8, 69, 94], [9, 20, 95]]}, {'source': 2166566, 'bytes': 20, 'fields': [[8, 69, 94], [9, 20, 95]]}, {'link': 10987484}]}, {'target': 10987528, 'segments': [{'source': 2160130, 'bytes': 20, 'fields': [[10, 0, 7]]}, {'source': 2166882, 'bytes': 20, 'fields': []}, {'source': 2166714, 'bytes': 20, 'fields': []}, {'source': 2166546, 'bytes': 20, 'fields': [[8, 69, 94], [9, 20, 0]]}, {'source': 2166546, 'bytes': 20, 'fields': [[8, 69, 94], [9, 20, 96]]}, {'source': 2166566, 'bytes': 20, 'fields': [[8, 69, 94], [9, 20, 96]]}, {'link': 10987608}]}, {'target': 10987652, 'segments': [{'source': 2167174, 'bytes': 20, 'fields': []}, {'source': 2167194, 'bytes': 20, 'fields': [[0, 4, 2], [8, 70, 96], [9, 62, 0]]}, {'source': 2167194, 'bytes': 20, 'fields': [[8, 70, 96]]}, {'source': 2167214, 'bytes': 20, 'fields': [[8, 70, 96]]}, {'source': 2167234, 'bytes': 20, 'fields': [[8, 70, 96]]}, {'source': 2167254, 'bytes': 20, 'fields': [[8, 70, 96]]}, {'link': 10987692}]}, {'target': 10987776, 'segments': [{'source': 2167278, 'bytes': 20, 'fields': []}, {'source': 2167298, 'bytes': 20, 'fields': [[0, 4, 2], [8, 71, 97], [9, 63, 0]]}, {'source': 2167298, 'bytes': 20, 'fields': [[8, 71, 97]]}, {'source': 2167318, 'bytes': 20, 'fields': [[8, 71, 97]]}, {'source': 2167338, 'bytes': 20, 'fields': [[8, 71, 97]]}, {'source': 2167358, 'bytes': 20, 'fields': [[8, 71, 97]]}, {'link': 10987816}]}, {'target': 10987900, 'segments': [{'source': 2167278, 'bytes': 20, 'fields': []}, {'source': 2161202, 'bytes': 20, 'fields': [[6, 134, 146], [8, 30, 98], [14, 4, 2]]}, {'source': 2167402, 'bytes': 20, 'fields': [[8, 72, 98]]}, {'source': 2167422, 'bytes': 20, 'fields': [[8, 72, 98]]}, {'source': 2167442, 'bytes': 20, 'fields': [[8, 72, 98]]}, {'source': 2167462, 'bytes': 20, 'fields': [[8, 72, 98]]}, {'link': 10987940}]}]


def models(arcade,comp2,owner):
    base=0x60b080
    slong=lambda at:struct.unpack_from('<I',comp2,at-base)[0]
    sv=slong(0x74ea38+owner*4)
    source=Owner(comp2,base,slong(0x74ef38+owner*4),slong(0x74ead8+owner*4),slong(0x74eb78+owner*4),[slong(sv+i*4)for i in range(3)],'<')
    variants=u32(arcade,0xde2a0+owner*4)
    native=Owner(bytearray(arcade),0,u32(arcade,0xde6a0+owner*4),u32(arcade,0xde320+owner*4),u32(arcade,0xde3a0+owner*4),[u32(arcade,variants+i*4)for i in range(3)],'>')
    direct_projection(source,native);repoint_existing(source,native)
    if owner==13:remap_events(source,native);relocate_missing(source,native)
    return source,native


def construct(inputs,recipe):
    require(set(inputs)==set(recipe['inputs'])=={'arcade-jp','comp2-jp'},'Complete appended-graph source inventory')
    for name,value in inputs.items():
        p=recipe['inputs'][name]
        require(len(value)==p['bytes']and hashlib.sha256(value).hexdigest()==p['sha256'],'Original source identity '+name)
    require(recipe['inventory_sha256']==hashlib.sha256(repr((PACKETS,PRECURSORS)).encode()).hexdigest(),'Complete reviewed graph inventory')
    models_by_owner={owner:models(inputs['arcade-jp'],inputs['comp2-jp'],owner)for owner in (13,15,16)}
    installed={};reports=[];writes=[]
    def emit(spec,owner):
        source,native=models_by_owner[owner]
        native_frames={at for family in native.families for frames,_ in family for at in frames}
        payload=bytearray()
        for row in spec['segments']:
            if 'link'in row:
                require(spec['target']<=row['link']<spec['target']+len(payload)and (row['link']-spec['target'])%20==0,'Whole graph link stays in frame domain')
                payload.extend(struct.pack('>I',row['link']));continue
            at=row['source'];require(row['bytes']==20,'Whole source frame template extent')
            if at in installed:value=bytearray(installed[at])
            else:
                require(at in native_frames,'Source template belongs to complete original owner graphs')
                value=bytearray(native.read(at,20))
            for field,before,after in row['fields']:
                require(field in (0,3,6,8,9,10,14)and value[field]==before,'Reviewed typed source-field preimage '+hex(at)+'/'+str(field))
                value[field]=after
            installed[spec['target']+len(payload)]=bytes(value);payload.extend(value)
        frames=len(payload)//20
        has_link=len(payload)%20==4
        require(len(payload)%20 in (0,4),'Whole appended graph record extent')
        require(all(not payload[i*20+1]&0xc0 for i in range(frames-1)),'Whole graph interior fallthrough')
        require(bool(payload[(frames-1)*20+1]&128)==has_link,'Whole graph terminal link flag')
        if not has_link:require(payload[(frames-1)*20+1]&64,'Whole graph terminal stop')
        return bytes(payload),frames,has_link
    for spec in PRECURSORS:emit(spec,15)
    for spec in PACKETS:
        value,count,linked=emit(spec,spec['owner'])
        source,_=models_by_owner[spec['owner']]
        slots=(spec['family'],spec['family']+4,spec['family']+8)
        # The historical X-specific graph is a distinct graph, while this copied
        # Dhalsim packet serves A/V. Validate every actual caller, not X aliases.
        if spec['owner']==15:slots=(3,11)
        for slot in slots:
            frames,loop=source.families[slot][spec['action']]
            require(len(frames)==count and (loop is not None)==linked,'Original PS2 complete action topology')
            if linked:require(struct.unpack('>I',value[-4:])[0]==spec['target']+loop*20,'Original PS2 loop ordinal')
            require([source.read(at,1)[0]for at in frames]==[value[i*20]for i in range(count)],'Complete original PS2 clock projection')
        writes.append((spec['target'],value));reports.append({'owner':spec['owner'],'family':spec['family'],'action':spec['action'],'frames':count,'bytes':len(value),'styles':list(slots)})
    require(len(writes)==11 and sum(len(v)for _,v in writes)==1720,'Complete appended graph inventory extent')
    return writes,{'graphs':reports,'bytes':1720,'excluded':'Naomi-only Sagat intro and retained Dhalsim action56'}


def load(pools):
    names=('sz3j.03c','sz3j.04c','sz3.05c','sz3.06c','sz3.07c','sz3.08c','sz3.09c','sz3.10b')
    packed=b''.join((pools/('arcade-jp-'+name)).read_bytes()for name in names)
    native=bytearray(packed);native[::2]=packed[1::2];native[1::2]=packed[::2]
    return {'arcade-jp':bytes(native),'comp2-jp':(pools/'ps2-jp-comp2.bin').read_bytes()}


def main():
    import argparse,json
    from pathlib import Path
    parser=argparse.ArgumentParser(description=__doc__)
    for name in ('recipe','pools','out'):parser.add_argument('--'+name,type=Path,required=True)
    args=parser.parse_args();writes,report=construct(load(args.pools),json.loads(args.recipe.read_text()))
    data=bytearray(0x400000);mask=bytearray(len(data))
    for at,value in writes:
        at-=0xa00000;require(0<=at<at+len(value)<=len(data)and not any(mask[at:at+len(value)]),'Expanded graph extent/overlap')
        data[at:at+len(value)]=value;mask[at:at+len(value)]=b'\1'*len(value)
    args.out.mkdir();(args.out/'upper.bin').write_bytes(data);(args.out/'upper.mask').write_bytes(mask)
    (args.out/'compiled.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')


if __name__=='__main__':main()
