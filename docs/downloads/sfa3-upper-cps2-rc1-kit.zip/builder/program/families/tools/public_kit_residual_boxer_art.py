"""Reconstruct the complete source Boxer compact action4 cel/frame allocation."""
import argparse,hashlib,json,struct
from pathlib import Path
from public_kit_actor import Data
from public_kit_blocks import grid_code
from public_kit_graphics import require


def construct(inputs,recipe):
    require(set(inputs)==set(recipe['inputs'])=={'comp2','coords','pixels','mask'},'Complete original compact source inventory')
    for name,blob in inputs.items():
        pin=recipe['inputs'][name]
        require(len(blob)==pin['bytes'] and hashlib.sha256(blob).hexdigest()==pin['sha256'],'Original compact source identity '+name)
    region=recipe['region'];require(region in ('us','jp'),'Compact source region')
    source=Data(inputs['comp2'],0x60b080 if region=='jp'else 0x60ad00,inputs['coords'],0xb04000)
    root=0x8834d0+(0x5700 if region=='jp'else 0)
    _,targets=source.root(root);require(len(targets)==5,'Complete compact action directory')
    frames={};cels={};tiles={};packed=bytearray();writes=[];cursor=0xc75400;at=targets[4]
    def add(blob):
        nonlocal cursor
        cursor+=-cursor%4;start=cursor;cursor+=len(blob);writes.append((start,blob));return start
    while at not in frames:
        require(len(frames)<8 and at%4==0,'Bounded complete compact action4 graph')
        h=source.read(at,8);flags=h[1]
        link=source.u32(at+8)if flags&128 else None if flags&64 else at+8
        pointer=source.u32(at+4)
        if pointer not in cels:
            kind,blocks=source.cel(pointer);require(kind==2,'Compact source indexed cel format')
            converted=[]
            for x,y,word in blocks:
                tile=word&65535;attribute=word>>16;w,hsize=(attribute>>8&15)+1,(attribute>>12&15)+1
                require(not attribute&0x60,'Unqualified internal compact block flip')
                for dy in range(hsize):
                    for dx in range(w):
                        code=grid_code(tile,dx,dy)
                        require(code<len(inputs['mask']) and inputs['mask'][code] and (code+1)*128<=len(inputs['pixels']),'Missing original compact tile')
                        px=inputs['pixels'][code*128:(code+1)*128]
                        if px not in tiles:tiles[px]=len(packed)//128;packed.extend(px)
                        converted.append((x+dx*16,y+dy*16,0x4000+tiles[px],attribute&255))
            xy=add(b''.join(struct.pack('>2h',x,y)for x,y,_,_ in converted))
            cels[pointer]=add(struct.pack('>3HI',2,len(converted),len(converted)-1,xy)+b''.join(struct.pack('>2H',t,a)for _,_,t,a in converted))
        frames[at]=(source.read(at,4),cels[pointer],link)
        if link is None:break
        at=link
    require(len(frames)==len(cels)==8 and len(packed)==10240 and cursor==0xc756de,'Complete compact cels and original artwork census')
    mapping={};cursor=(cursor+3)&~3;start=cursor
    for at,(header,_,_)in sorted(frames.items()):mapping[at]=cursor;cursor+=12 if header[1]&128 else 8
    require(start==0xc756e0 and cursor==0xc75724,'Complete compact frame allocation')
    packet=bytearray(cursor-start)
    for at,(header,cel,link)in frames.items():
        value=header+struct.pack('>I',cel)
        if header[1]&128:require(link in mapping,'Unknown compact frame link');value+=struct.pack('>I',mapping[link])
        elif link is not None:require(mapping.get(link)==mapping[at]+8,'Compact linear frame successor')
        packet[mapping[at]-start:mapping[at]-start+len(value)]=value
    writes.extend(((start,bytes(packet)),(cursor,struct.pack('>hH',mapping[targets[4]]-cursor,0))))
    return writes,{'source_action':4,'native_action':0,'source_frames':8,'source_cels':8,'original_art_bytes':len(packed),'original_art_sha256':hashlib.sha256(packed).hexdigest(),'source_root':root,'allocation_start':0xc75400,'allocation_end':0xc75728}


def main():
    p=argparse.ArgumentParser(description=__doc__)
    for n in ('recipe','pools','out'):p.add_argument('--'+n,type=Path,required=True)
    a=p.parse_args();recipe=json.loads(a.recipe.read_text());region=recipe['region']
    names={'comp2':'comp2.bin','coords':'coords390.bin','pixels':'entry373-s0.bin','mask':'entry373-s0.mask'}
    writes,details=construct({n:(a.pools/('ps2-'+region+'-'+v)).read_bytes()for n,v in names.items()},recipe)
    data=bytearray(0x400000);mask=bytearray(len(data))
    for at,blob in writes:
        at-=0xa00000;require(not any(mask[at:at+len(blob)]),'Compact allocation overlap')
        data[at:at+len(blob)]=blob;mask[at:at+len(blob)]=b'\1'*len(blob)
    a.out.mkdir();(a.out/'upper.bin').write_bytes(data);(a.out/'upper.mask').write_bytes(mask)
    (a.out/'compiled.json').write_text(json.dumps(details,sort_keys=True,indent=2)+'\n')


if __name__=='__main__':main()
