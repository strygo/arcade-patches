"""Source-only complete residual selection, motion and Shin palette resources."""
import hashlib,struct
from public_kit_graphics import require


def sha(b):return hashlib.sha256(b).hexdigest()
def swap(b):
    require(len(b)%2==0,'Whole source words');return b''.join(b[i:i+2][::-1]for i in range(0,len(b),2))


def construct(inputs,recipe):
    require(set(inputs)==set(recipe['inputs'])=={'arcade','key','comp2'},'Complete presentation input domain')
    for name,b in inputs.items():
        require(recipe['inputs'][name]=={'bytes':len(b),'sha256':sha(b)},'Original presentation input '+name)
    require(recipe['schema']==1 and recipe['source_region']=='jp','Inherited canonical JP source contract')
    from cps2_crypt import decrypt_rom
    raw=inputs['arcade'];ops=decrypt_rom(raw[:0x100000],inputs['key'])[0];c2=inputs['comp2'];base=0x60b080
    def read(a,n):
        require(0<=a-base<=len(c2)-n,'Original presentation source bounds');return c2[a-base:a-base+n]
    def u32(a):return struct.unpack('<I',read(a,4))[0]
    main=[];upper=[]
    require(raw[0x880a4:0x880ae]==struct.pack('>3HI',16,100,24,0x8ac56),'Original compact descriptor caller')
    coords=raw[0x8ac56:0x8ac56+100]+b''.join(struct.pack('>2h',24*x-88,24*y-88)for x,y in ((5,5),(0,4),(6,4)))
    main.append((0x3c8800,coords))
    mask=bytearray(ops[0x85d52:0x85d72])
    for owner,value in ((21,25),(30,26),(31,27)):
        require(mask[owner]==value,'Original hidden mask preimage');mask[owner]=255
    main.append((0x3c9140,bytes(mask)))
    require(recipe['random_pool_offset']>=0 and recipe['random_pool_offset']+64<=len(c2),'Original random pool bound')
    pool=c2[recipe['random_pool_offset']:recipe['random_pool_offset']+64];require(len(pool)==64 and max(pool)==37,'Original forty-owner random pool')
    main.append((0x3c9606,pool))
    motion=bytearray(b'\xff'*96)
    specs=((0,0x751d80,1),(2,0x751da8,1),(4,0x751e20,1),(6,0x74e3a8,2),(8,0x74efd8,8),(16,0x74f118,8),(24,0x74f258,8),(32,0x74f398,64))
    for dest,table,size in specs:
        b=read(table+32*size,size)
        if size==2:b=swap(b)
        elif size>2:b=b''.join(b[i:i+4][::-1]for i in range(0,size,4))
        motion[dest:dest+size]=b
    require(read(0x74f398+32*64,64)==read(0x74fd98+32*64,64)==read(0x750798+32*64,64),'Guile ISM jump aliases')
    main.append((0x3fa400,bytes(motion)))
    table=0x950ce0+0x5700;at=table+struct.unpack('<h',read(table+36*2,2))[0];rows=[]
    for i in range(4):
        b=read(at+i*16,16)
        if struct.unpack('<h',b[:2])[0]<0:break
        rows.append(b[:2][::-1]+swap(b[2:6])+b[6:8][::-1]+b[8:10][::-1]+swap(b[10:16]))
    require(len(rows)==3 and i==3,'Whole Shin stage placement domain')
    placements=bytearray(b''.join(rows)+b'\xff\xff')
    for offset in (26,42):
        require(placements[offset:offset+2]==b'\0\0','Reviewed stage bank-word preimage');placements[offset:offset+2]=struct.pack('>H',0x6000)
    upper.append((0xc5ecc0,bytes(placements)))
    root=0x916e70+0x5700;directory=0x60ff70+0x10f0;start=root+struct.unpack('<h',read(root+46,2))[0]
    todo=[start];frames={};payloads={};colors={}
    while todo:
        at=todo.pop()
        if at in frames:continue
        require(len(frames)<256,'Bounded Shin cycle graph');scalar=read(at,4)
        require(scalar[0] and scalar[2:]==b'\0\0' and scalar[1]in(0,128),'Shin cycle scalar grammar')
        ptr=u32(at+4);body=[]
        for n in range(128):
            dest,bank,offset=struct.unpack('<3H',read(ptr+n*6,6));require(dest%32==0 and dest+32<=4096 and bank in(0,4,8),'Shin cycle copy domain')
            table=u32(directory+bank);table+=struct.unpack('<h',read(table+72,2))[0];color=swap(read(table+(offset&0xffe0),32))
            if color not in colors:colors[color]=len(colors)*32
            body.append(struct.pack('>3H',dest,0x8004,colors[color]|(offset&1)))
            if offset&1:break
        else:raise ValueError('Unterminated Shin palette list')
        payloads[ptr]=b''.join(body);nxt=u32(at+8)if scalar[1]&128 else at+8
        frames[at]=(scalar,ptr,nxt,12 if scalar[1]&128 else 8);todo.append(nxt)
    require(len(colors)==10 and len(frames)==2 and len(payloads)==2,'Complete Shin cycle extent')
    cursor=0xc5ecf4
    def add(b):
        nonlocal cursor
        cursor+=-cursor%4;a=cursor;cursor+=len(b);upper.append((a,b));return a
    directory_at=add(bytes(48));color_at=add(b''.join(colors));fm={a:add(bytes(v[3]))for a,v in sorted(frames.items())};pm={a:add(b)for a,b in sorted(payloads.items())}
    upper=[(a,b'\0'*46+struct.pack('>h',fm[start]-directory_at)if a==directory_at else b)for a,b in upper]
    for source,(scalar,ptr,nxt,size)in frames.items():
        b=scalar+struct.pack('>I',pm[ptr])+(struct.pack('>I',fm[nxt])if size==12 else b'')
        if size==8:require(fm[nxt]==fm[source]+8,'Native cycle fallthrough')
        upper=[(a,b if a==fm[source]else old)for a,old in upper]
    require(recipe['palette_bases']==[0xa77000,0xba1fc4,0xc38000,0xd80000,0xc5e000],'Original palette allocation lineage')
    payload=b''.join(struct.pack('>5I',*(v+role*1024 if v else 0 for v in recipe['palette_bases']))for role in range(4))
    require(add(payload)==0xc5eeb8 and cursor==0xc5ef08,'Complete Shin stage directory extent')
    portrait=bytearray(raw[0x352b94:0x352b94+512])
    for bank in range(3):portrait[bank*32:bank*32+30]=raw[0x352d94+bank*32:0x352d94+bank*32+30]
    upper.append((0xd88f74,bytes(portrait)))
    require(recipe['display']in('us','jp'),'Presentation display binding')
    if recipe['display']=='us':
        for address in range(0x35e3d4,0x35e8d4,0x100):
            words=list(struct.unpack_from('>16H',raw,address));primary=words[6];words[5]=words[10]
            for pen,tint in zip(range(6,11),(4,3,2,1,0)):
                words[pen]=sum((((primary>>shift&15)*(8-tint)+15*tint+4)//8)<<shift for shift in (8,4,0))
            main.append((address,struct.pack('>16H',*words)))
    require(len(recipe['ending_visual_edits'])==13,'Complete high-data ending visual patch domain')
    for address,before,after in recipe['ending_visual_edits']:
        require(0x100000<=address<0x400000 and address%2==0 and struct.unpack_from('>H',raw,address)[0]==before,'Original ending visual word preimage')
        if address in (0x318386,0x324ade):
            require(after==24 and recipe['ending_palette_directory_rows']==43,'Original extended ending palette request binding');after=(recipe['ending_palette_directory_rows']-1)*4
        main.append((address,struct.pack('>H',after)))
    return {'main':main,'upper':upper},{'main_bytes':sum(len(b)for _,b in main),'upper_bytes':sum(len(b)for _,b in upper),'cycle_frames':2,'color_rows':10}


def main():
    import argparse,json
    from pathlib import Path
    p=argparse.ArgumentParser(description=__doc__)
    for n in ('inputs','recipe','out'):p.add_argument('--'+n,type=Path,required=True)
    a=p.parse_args();require(not a.out.exists(),'Fresh presentation output');r=json.loads(a.recipe.read_text());writes,report=construct({n:(a.inputs/(n+'.bin')).read_bytes()for n in r['inputs']},r);a.out.mkdir()
    for view,rows in writes.items():
        b=bytearray(0x400000);m=bytearray(len(b))
        for at,blob in rows:
            at-=0xa00000 if view=='upper'else 0;require(not any(m[at:at+len(blob)]),'Presentation write overlap');b[at:at+len(blob)]=blob;m[at:at+len(blob)]=b'\1'*len(blob)
        (a.out/(view+'.bin')).write_bytes(b);(a.out/(view+'.mask')).write_bytes(m)
    (a.out/'report.json').write_text(json.dumps(report,sort_keys=True)+'\n')
if __name__=='__main__':main()
