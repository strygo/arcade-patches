"""Complete inherited Shin quote directory with independently rebuilt records."""
import hashlib,struct
from public_kit_original_quotes import source_pools,construct as original_quotes,packed_record,pack
from public_kit_residual_owner_extensions import load_inputs


def require(ok,message):
    if not ok:raise ValueError(message)


def digest(b):return hashlib.sha256(b).hexdigest()


def project(inputs,recipe):
    require(set(inputs)==set(recipe['inputs'])=={'arcade','key','comp1','comp2','font','pixels'},'Whole original quote source inventory')
    require(recipe['source_region']=='jp' and recipe['region']in ('us','jp'),'Explicit retained Japanese source layout')
    for n,b in inputs.items():require(len(b)==recipe['inputs'][n]['bytes'] and digest(b)==recipe['inputs'][n]['sha256'],'Original quote source '+n)
    pools,source_map=source_pools(inputs['comp2']);records=pools[2]
    require(records==pools[36] and len(records)==41,'Complete original Shin/Akuma corpus alias')
    earlier,proof=original_quotes({'arcade':inputs['arcade'],'comp2':inputs['comp2']},recipe['earlier_quote_recipe'])
    raw=inputs['arcade']
    # Replay the complete resident-roster quote allocator, including all183
    # records, before checking Shin's three references into that prior packet.
    common=tuple(n for n in range(32)if n not in (18,19,20,21,23,30,31));promoted=(21,30,31)
    offsets=struct.unpack_from('>32H',raw,0xc985a);mapping=list(raw[0xd194:0xd1b4])
    for owner,slot in zip(promoted,(33,34,35)):mapping[owner]=slot
    resident=bytearray(128);addresses={};count=0
    for owner in (*common,*promoted):
        if owner in common:chosen=[(opponent,source_map[opponent])for opponent in promoted]
        else:
            chosen=[(None,slot)for slot in range(8)]+[(opponent,source_map[opponent])for opponent in (*common,*promoted)]
            chosen.sort(key=lambda row:row[1]if row[0]is None else mapping[row[0]])
            require([slot if opponent is None else mapping[opponent]for opponent,slot in chosen]==list(range(36)),'Complete original promoted resident quote routing')
        records_for_owner=[pools[owner][slot]for _,slot in chosen]
        addresses[owner]=0x3f4000+len(resident);resident.extend(pack(records_for_owner));count+=len(chosen)
    for owner in range(32):
        actual=owner if owner in promoted else next((n for n in common if offsets[n]==offsets[owner]),None)
        require(actual is not None,'Original resident quote alias domain');struct.pack_into('>I',resident,owner*4,addresses[actual])
    require(count==183 and len(resident)==7214,'Complete prior resident quote packet')
    earlier.append((0x3f4000,bytes(resident)))
    def read(at,size):
        found=[b[at-start:at-start+size]for start,b in earlier if start<=at<=start+len(b)-size]
        if not found and 0<=at<=len(raw)-size:return raw[at:at+size]
        require(found and len(set(found))==1,'Prior complete source quote allocation binding '+hex(at));return found[0]
    rows=recipe['records'];require([r['slot']for r in rows]==list(range(41)),'Complete41-record directory inventory')
    pointers=[];unique=[];glyphs=set()
    for record,row in zip(records,rows):
        require(packed_record(record)==record and len(record)==row['bytes'] and digest(record)==row['sha256'],'Original complete quote record grammar/identity')
        at=row['address'];pointers.append(at)
        if row['reused']:
            require(read(at,len(record))==record,'Whole independently reconstructed prior quote record slot='+str(row['slot'])+' at='+hex(at)+' source='+digest(record)+' prior='+digest(read(at,len(record))))
        else:
            require(row['slot']==40 and at==0xc5a7d0 and len(record)==19,'Complete unique Shin quote allocation')
            cursor=0
            for _ in range(2):
                position=record[cursor];cursor+=1
                if position==0x70:break
                for _ in range(64):
                    require(cursor+2<=len(record),'Complete Japanese glyph terminator')
                    hi=(record[cursor]<<4)|(record[cursor+1]>>4)
                    if not hi:cursor+=2;break
                    require(cursor+3<=len(record),'Complete Japanese packed glyph pair')
                    lo=((record[cursor+1]&15)<<8)|record[cursor+2];cursor+=3;glyphs.add(hi)
                    if not lo:break
                    glyphs.add(lo)
                else:raise ValueError('Unterminated original quote line')
            require(cursor==len(record),'Complete quote line extent')
            for glyph in glyphs:
                signed=glyph if glyph<0x800 else glyph-0x1000
                source=(0x4780+signed)*128;native=(0x19760+signed)*128
                require(inputs['font'][source:source+128]==inputs['pixels'][native:native+128] and len(inputs['font'][source:source+128])==128,'Original native Japanese glyph pixel binding')
            unique.append((at,record))
    require(len(unique)==1,'Whole unique Shin quote family')
    table=struct.pack('>41I',*pointers);writes=unique+[(0xc5a7e4,table)]
    if recipe['region']=='us':
        require(recipe['erase']=={'address':0xc5a7d0,'bytes':19},'Reviewed full inherited Japanese quote erasure')
        writes[0]=(0xc5a7d0,b'\xff'*19)
    else:require(recipe['erase']is None,'Japanese unique source record retained')
    return writes,{'bytes':183,'directory_records':41,'prior_records_verified':40,'independent_prior_pools':len(proof),'unique_record_bytes':19,'original_native_glyphs':len(glyphs),'first_native_glyph_tile':min(0x19760+(g if g<0x800 else g-0x1000)for g in glyphs),'source_region':'jp','candidate_canvas_used':False,'usa_view':'retained inert Japanese directory; unique text erased by reviewed fixes21'}


def construct(inputs,recipe):
    writes,report=project(inputs,recipe);require({str(at):digest(b)for at,b in writes}==recipe['outputs'],'Whole source quote packet identities');return writes,report


def swap(b):
    require(len(b)%2==0,'Whole source words');out=bytearray(b);out[::2]=b[1::2];out[1::2]=b[::2];return bytes(out)


def main():
    import argparse,json
    from pathlib import Path
    p=argparse.ArgumentParser(description=__doc__)
    for n in ('pools','recipe','out'):p.add_argument('--'+n,type=Path,required=True)
    a=p.parse_args();writes,report=construct(load_inputs(a.pools),json.loads(a.recipe.read_text()));data=bytearray(0x400000);mask=bytearray(len(data))
    for at,b in writes:at-=0xa00000;require(0<=at<=len(data)-len(b) and not any(mask[at:at+len(b)]),'Whole quote allocation nonoverlap');data[at:at+len(b)]=b;mask[at:at+len(b)]=b'\1'*len(b)
    a.out.mkdir();(a.out/'upper.bin').write_bytes(data);(a.out/'upper.mask').write_bytes(mask);(a.out/'resources.json').write_text(json.dumps(report))


if __name__=='__main__':main()
