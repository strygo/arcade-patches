"""Complete historical Shin and Boxer owner directories from original resources."""
import struct
from public_kit_residual_owners import require,digest,swap,opcodes,construct as owner_resources
from public_kit_evil_palette_directories import construct as early_palettes
from public_kit_color_arena import resources as color_arena
from public_kit_palettes import catalog

PALETTES=('primary','effects','prefix','special','bank_words','color_deltas')
ADDRESSES=(0xc2240c,0xc227a0,0xc228f4,0xc23128,0xc231bc,0xc23208)

def project(inputs,recipe):
    require(set(inputs)==set(recipe['inputs'])=={'arcade','key','comp1','comp2','naomi'},'Complete original directory inputs')
    for n,v in inputs.items():require(len(v)==recipe['inputs'][n]['bytes'] and digest(v)==recipe['inputs'][n]['sha256'],'Original input '+n)
    require(recipe['source_region']=='jp','Explicit inherited JP generation')
    raw=inputs['arcade'];c2=inputs['comp2'];ops=opcodes(raw,inputs['key']);writes=[];context={};proof=[]
    def emit(address,blob):
        require(address not in context,'Duplicate complete directory');context[address]=blob;writes.append((address,blob))
    require([r['role']for r in recipe['parameters']]==['guard_parameter','knockdown_parameter'],'Both scalar siblings')
    for row in recipe['parameters']:
        loader=row['loader'];require(digest(inputs['comp1'][loader['offset']:loader['offset']+loader['bytes']])==loader['sha256'],'Original scalar parameter loader')
        src=row['source_table']-0x60b080;original=c2[src:src+40];native=row['native']
        require(len(original)==40 and original[:23]==raw[native:native+23],'Native/source scalar controls')
        prefix=raw[native:native+32]+original[32:35]
        if row['role']=='guard_parameter':
            require(prefix[23]==2 and original[23]==3,'Original Evil guard amendment preimage/source')
            prefix=prefix[:23]+original[23:24]+prefix[24:]
        require(digest(prefix)==row['previous35'],'Whole pre-Shin35 scalar prefix')
        require(original[36]==original[2],'Shin scalar alias source')
        body=prefix+b'\0'+original[36:37]
        require(digest(body)==row['shin_sha256'],'Whole held-Hawk Shin scalar table')
        body=body[:35]+original[35:36]+body[36:]
        emit(row['address'],body)
    pi={'arcade':raw,'comp2':c2};pr={'inputs':{k:{'bytes':len(v),'sha256':digest(v)}for k,v in pi.items()},'region':'jp','owners':34}
    earlier,_=early_palettes(pi,pr);arena=color_arena(c2,raw,'jp')[0][0][1];arrays=catalog(c2,'jp')
    prefixes=[v+struct.pack('>I',p)for (a,v),p in zip(earlier,(0xbdea0c,0xbdee58,0xbdf1e4))]
    prefixes += [arena[-128:]+struct.pack('>3I',0xbbc088,0xbbc088,0xbbc088),ops[0x2fc94:0x2fcd4]+bytes(6),raw[0x32c094:0x32c0d4]+bytes(6)]
    require([r['role']for r in recipe['palettes']]==list(PALETTES),'Complete six palette directory siblings')
    for role,address,prefix,row in zip(PALETTES,ADDRESSES,prefixes,recipe['palettes']):
        stride=4 if role in PALETTES[:4]else 2
        require(len(prefix)==35*stride and digest(prefix)==row['previous35'],'Whole palette35 predecessor '+role)
        if stride==4:
            tails=[]
            for owner in (36,35):
                source,blob=arrays[role+':'+str(owner)];binding=row['supplies'][str(owner)]
                require(source==binding['source_comp2_offset'] and len(blob)==binding['bytes'] and digest(blob)==binding['sha256'],'Complete original palette supply '+role)
                tails.append(struct.pack('>I',binding['address']))
            shin,hawk=tails
        else:
            shin=prefix[4:6]if role=='bank_words'else bytes(2)
            hawk=struct.pack('>H',(0x1000000//0x800000)*0x2000)if role=='bank_words'else bytes(2)
        body=prefix+bytes(stride)+shin
        require(digest(body)==row['shin_sha256'],'Whole held-Hawk palette directory '+role)
        body=prefix+hawk+shin;emit(address,body)
    prior,_=owner_resources(inputs,recipe['owners']);previous=dict(prior)
    require([r['role']for r in recipe['boxer']]==['guard_parameter','knockdown_parameter','throw','entrance','placement_normal','placement_parity'],'Complete six Boxer directory siblings')
    for row in recipe['boxer']:
        old=row['old'];stride=row['stride'];body=context.get(old,previous.get(old));require(body is not None,'Source-bound complete predecessor')
        # Original Boxer construction follows Hawk installation; copied placement
        # directories still use the held-Hawk Shin table, as its original reader does.
        require(len(body)==37*stride and digest(body)==row['previous37'],'Whole original Boxer37 prefix '+row['role'])
        emit(row['address'],body+body[21*stride:22*stride])
    counter=previous[0xc552c8];require(len(counter)==37 and digest(counter)==recipe['counter_prefix'],'Whole original counter predecessor')
    emit(0xc752c4,counter+counter[21:22])
    require(sum(len(v)for a,v in writes)==1536,'Complete fifteen-table packet')
    return writes,{'bytes':1536,'complete_tables':15,'source_region':'jp','original_owner_generations':[32,34,35,37,38]}


def construct(inputs,recipe):
    writes,report=project(inputs,recipe)
    require({str(a):digest(v)for a,v in writes}==recipe['outputs'],'Complete source-generated packet identity')
    return writes,report


def main():
    import argparse,json
    from pathlib import Path
    p=argparse.ArgumentParser(description=__doc__)
    for name in ('pools','recipe','out'):p.add_argument('--'+name,type=Path,required=True)
    a=p.parse_args();recipe=json.loads(a.recipe.read_text());inputs={name:(a.pools/pin['file']).read_bytes()for name,pin in recipe['inputs'].items()if name!='arcade'}
    names=('sz3j.03c','sz3j.04c','sz3.05c','sz3.06c','sz3.07c','sz3.08c','sz3.09c','sz3.10b')
    inputs['arcade']=swap(b''.join((a.pools/('arcade-jp-'+n)).read_bytes()for n in names))
    writes,report=construct(inputs,recipe);out=bytearray(0x400000);mask=bytearray(len(out))
    for at,blob in writes:at-=0xa00000;out[at:at+len(blob)]=blob;mask[at:at+len(blob)]=b'\1'*len(blob)
    a.out.mkdir();(a.out/'upper.bin').write_bytes(out);(a.out/'upper.mask').write_bytes(mask);(a.out/'resources.json').write_text(json.dumps(report))


if __name__=='__main__':main()
