"""Complete source-bound early owner and ranking tables; no target payloads."""
import hashlib,struct
from public_kit_graphics import require

def sha(b):return hashlib.sha256(b).hexdigest()
def swap(b):
    require(len(b)%2==0,'Whole original words');return b''.join(b[i:i+2][::-1]for i in range(0,len(b),2))

def construct(inputs,recipe):
    require(recipe['schema']==1 and recipe['display']in('us','jp'),'Early table recipe domain')
    require(set(inputs)==set(recipe['inputs'])=={'arcade','key'},'Complete original input domain')
    for n,b in inputs.items():require(recipe['inputs'][n]=={'bytes':len(b),'sha256':sha(b)},'Original input '+n)
    from cps2_crypt import decrypt_rom
    raw=inputs['arcade'];ops=decrypt_rom(raw[:0x100000],inputs['key'])[0]
    require(sha(ops[0x25a60:0x25aa2])==recipe['loader_sha256'],'Original complete ranking default consumer')
    rows=bytearray(raw[0x25bec:0x25dbc]);require(len(rows)==29*16,'Complete native default rows')
    if recipe['display']=='us':
        for row,old,new,owner in recipe['regional_initials']:
            at=row*16;require(rows[at+4:at+8]==old.encode()+b'-'and rows[at+8]==owner,'Original regional initials preimage')
            rows[at+4:at+7]=new.encode()
    for at in range(0,len(rows),16):
        for i in range(at+4,at+7):
            require(rows[i]>=65,'Native ASCII initial');rows[i]-=65
    labels=['FEI','D.J','HWK','GIL','RYU','AKM'if recipe['display']=='us'else'GOK']
    added=[]
    for owner,label in zip((33,34,35,32,23,36),labels):
        glyphs=bytes(38 if c=='.'else ord(c)-65 for c in label)
        added.append(struct.pack('>I',0x3000)+glyphs+bytes((45,owner,0))+struct.pack('>HI',2,0))
    blob=bytes(rows[:448])+b''.join(added)+bytes(rows[448:])
    require(len(blob)==560 and sha(blob)==recipe['ranking_sha256'],'Original full ranking recipe digest')
    return {'upper':[(0xaa7dd0,blob)]},{'ranking_rows':35,'verified_bytes':len(blob),'unresolved':['Naomi ranking palette source/order','early owner frame and offset packet lineage']}

def main():
    import argparse,json
    from pathlib import Path
    p=argparse.ArgumentParser(description=__doc__)
    for n in ('inputs','recipe','out'):p.add_argument('--'+n,type=Path,required=True)
    a=p.parse_args();require(not a.out.exists(),'Fresh early table output');r=json.loads(a.recipe.read_text());writes,report=construct({n:(a.inputs/(n+'.bin')).read_bytes()for n in r['inputs']},r);a.out.mkdir()
    for view,rows in writes.items():
        b=bytearray(0x400000);m=bytearray(len(b))
        for at,blob in rows:
            at-=0xa00000;require(0<=at<=len(b)-len(blob)and not any(m[at:at+len(blob)]),'Early table write bounds');b[at:at+len(blob)]=blob;m[at:at+len(blob)]=b'\1'*len(blob)
        (a.out/(view+'.bin')).write_bytes(b);(a.out/(view+'.mask')).write_bytes(m)
    (a.out/'report.json').write_text(json.dumps(report,sort_keys=True)+'\n')
if __name__=='__main__':main()
