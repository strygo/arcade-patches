"""Original Naomi fighter descriptor and action records, bound to native readers.

Owner initializers copy their descriptor to actor+0x190. Animation selectors
read the first four pointer tables. The updater at 0x8c04e39c multiplies the
record's final word by12 for the scalar row; the successor reader multiplies
the signed word at+6 by10. This parser admits the measured initializer form
used by Dee Jay and rejects unknown forms and flow.
"""
import struct
from public_kit_graphics import require

BASE=0x8c020000
DISPATCH=BASE+0x10419c


def read(blob,address,size):
    at=address-BASE
    require(0<=at<=len(blob)-size,'Original Naomi resource bounds')
    return blob[at:at+size]


def u32(blob,address):return struct.unpack('<I',read(blob,address,4))[0]
def word(blob,address):return struct.unpack('<H',read(blob,address,2))[0]


def literal_word(blob,pc,register):
    instruction=word(blob,pc)
    require(instruction>>8==0x90+register,'Original Naomi PC-relative word load')
    return word(blob,pc+4+(instruction&255)*2)


def descriptor(blob,owner):
    require(owner==34,'Unqualified Naomi owner initializer')
    entry=u32(blob,DISPATCH+owner*4)
    require(literal_word(blob,entry,0)==0x190,'Original Dee actor descriptor field')
    require(literal_word(blob,entry+2,7)==0x9c,'Original Dee complete descriptor copy extent')
    load=word(blob,entry+4);require(load>>8==0xd1,'Original Dee descriptor pointer load')
    address=u32(blob,((entry+8)&~3)+(load&255)*4)
    require(tuple(word(blob,entry+n*2)for n in range(3,10))==(0x054e,0xe000,0x031e,0x0536,0x7004,0x3072,0x8bfa),'Complete original Dee descriptor-copy loop')
    # Bind the actual animation-family lookup and scalar-row/index readers.
    require(read(blob,0x8c04e2f2,18).hex()=='44e055045d65379008454e0002605e0342a0','Original primary animation reader')
    require(read(blob,0x8c04e39c,18).hex()=='e48534530d60036200402c3008403c300221','Original12-byte scalar-row reader')
    require(read(blob,0x8c04e46a,12).hex()=='5385036308403c3000405c30','Original10-byte relative successor reader')
    values=struct.unpack('<39I',read(blob,address,0x9c))
    roots=values[:4];boundaries=sorted((*roots,values[4]));counts={root:(boundaries[boundaries.index(root)+1]-root)//4 for root in roots}
    require(len(set(roots))==4 and all(0<n<256 for n in counts.values()),'Original complete animation table bounds')
    require(all((boundaries[i+1]-boundaries[i])%4==0 for i in range(4)),'Original animation table alignment')
    targets=[u32(blob,root+i*4) for root in roots for i in range(counts[root])]
    return values,counts,(min(targets),min(roots))


def graph(blob,owner,family,action):
    values,counts,frame_bounds=descriptor(blob,owner);root=values[(0,2,1,3)[family]]
    require(0<=action<counts[root],'Original Naomi action extent')
    at=u32(blob,root+action*4);rows=[];seen=[]
    while at is not None and at not in seen:
        require(frame_bounds[0]<=at<=frame_bounds[1]-10 and at%2==0,'Original Naomi complete frame bounds')
        raw=read(blob,at,10);flags=raw[1]
        require(flags&63==0,'Unknown original Naomi frame flags')
        index=struct.unpack_from('<H',raw,8)[0];scalar=values[4]+index*12
        scalar_end=min(pointer for pointer in values[5:16] if pointer>values[4])
        require(values[4]<=scalar<=scalar_end-12,'Original Naomi scalar row extent')
        delta=struct.unpack_from('<h',raw,6)[0]
        nxt=None if flags&64 else at+delta*10
        seen.append(at);rows.append({'address':at,'prefix':raw[:4],'cel':struct.unpack_from('<H',raw,4)[0],
                                     'scalar':read(blob,scalar,12),'scalar_address':scalar,'next':nxt})
        at=nxt;require(len(rows)<2048,'Bounded original Naomi action graph')
    return rows,None if at is None else seen.index(at)


def construct(inputs,recipe,pixels):
    import hashlib
    from public_kit_actor import Data
    from public_kit_frame_resources import cel
    from public_kit_graphics import tile_variants
    sha=lambda b:hashlib.sha256(b).hexdigest()
    require(set(inputs)==set(recipe['inputs'])=={'comp2-jp','coords-jp','pixels34-jp','mask34-jp','naomi','naomi-pixels','descriptors'},'Complete original loss-resource inputs')
    for name,value in inputs.items():
        pin=recipe['inputs'][name];require(len(value)==pin['bytes']and sha(value)==pin['sha256'],'Original loss-resource identity '+name)
    require(sha(pixels)==recipe['graphics_pixels_sha256'],'Qualified complete expanded canvas')
    data=Data(inputs['comp2-jp'],0x60b080,inputs['coords-jp'],0xb04000)
    bank=data.u32(0x74ef38+34*4);root=data.u32(bank);at=data.root(root)[1][40];frames=[];cels={}
    while at is not None and at not in frames:
        frames.append(at);pointer=data.u32(at+4);cels[pointer]=data.cel(pointer);_,_,at=data.frame(at)
    rows,loop=graph(inputs['naomi'],34,0,40)
    require(len(frames)==len(rows)==12 and len(cels)==11 and at is None and loop is None,'Complete PS2/Naomi loss action topology')
    require(sum(len(b)for k,b in cels.values())==247,'Complete original loss geometry block domain')
    descriptors=inputs['descriptors'];first=struct.unpack_from('<I',descriptors)[0]
    require(first==389*12,'Complete original PL22 descriptor directory')
    aliases={}
    for at,row in zip(frames,rows):
        pointer=data.u32(at+4);prior=aliases.setdefault(row['cel'],pointer)
        require(prior==pointer and 0<=row['cel']<389,'Original action cel-ID aliases')
        raw=data.read(at,20)
        require(raw[:4]==row['prefix']and raw[8:]==row['scalar'],'Complete PS2/Naomi frame scalar correspondence')
    require(len(aliases)==11,'Complete original loss cel-ID domain')
    tile_source={code:b'\xff'*128 for code in range(0xa4c0,0xa550)}
    require(len(recipe['tile_sources'])==123,'Complete original loss artwork source recipe')
    for code,index,flip,pens in recipe['tile_sources']:
        require(0xa4c0<=code<0xa550 and 0<=index<len(inputs['naomi-pixels'])//128 and flip in range(4),'Original tile source bounds')
        require(len(pens)==16 and all(type(v)is int and 0<=v<16 for v in pens)and pens[15]==15,'Original transparent pen projection')
        tile_source[code]=tile_variants(inputs['naomi-pixels'][index*128:(index+1)*128])[flip].translate(bytes(pens[v&15]|pens[v>>4]<<4 for v in range(256)))
    for code,value in tile_source.items():require(pixels[code*128:(code+1)*128]==value,'Complete original Naomi tile/padding canvas control')
    packet=bytearray();mapping={}
    require([r[0]for r in recipe['cels']]==sorted(cels),'Complete sorted original loss cel inventory')
    for pointer,native,xy,tiles in recipe['cels']:
        kind,blocks=cels[pointer];require(kind==2,'Original loss cel grammar')
        require(xy==0xbdf620+len(packet)and native==xy+len(blocks)*4,'Original loss complete cel allocator')
        coordinates,body=cel(data,pointer,xy,tiles,inputs['pixels34-jp'],inputs['mask34-jp'],pixels,0)
        packet.extend(coordinates);packet.extend(body);mapping[pointer]=native
    require(len(packet)==2086,'Complete original loss coordinate/descriptor extent')
    # The original upper arena starts erased; alignment does not write it.
    packet.extend(b'\xff'*((-len(packet))%4))
    require(len(packet)==2088,'Original frame allocation four-byte alignment')
    body=bytearray()
    for at in frames:
        raw=data.read(at,20);require(not raw[1]&128,'Original terminal loss graph has no absolute links')
        body.extend(raw[:4]+struct.pack('>I',mapping[data.u32(at+4)])+raw[8:16]+raw[16:18][::-1]+raw[18:20])
    require(len(body)==240,'Complete twelve original loss frames')
    return [(0xbdf620,bytes(packet)),(0xbdfe48,bytes(body))],{'bytes':2328,'source_frames':12,'source_cels':11,'native_blocks':247,'naomi_tile_sources':123,'complete_atlas_tiles_checked':144,'cel_id_bindings':{str(k):v for k,v in sorted(aliases.items())},'geometry_authority':'Complete original PS2 cel coordinate/block resources; independent original Naomi action scalars and tile pixels','descriptor_grid_renderer':'Not used as geometry producer; separate original cel-ID source witness only'}


def load(pools,descriptor_pool):
    names={'comp2-jp':'ps2-jp-comp2.bin','coords-jp':'ps2-jp-coords390.bin','pixels34-jp':'ps2-jp-entry385-s0.bin','mask34-jp':'ps2-jp-entry385-s0.mask','naomi':'naomi-program.bin','naomi-pixels':'naomi-PL22.PAC.bin'}
    result={n:(pools/v).read_bytes()for n,v in names.items()};result['descriptors']=(descriptor_pool/'naomi-PL22-descriptors.bin').read_bytes();return result


def main():
    import argparse,json
    from pathlib import Path
    p=argparse.ArgumentParser(description=__doc__)
    for n in ('recipe','pools','descriptors','canvas','out'):p.add_argument('--'+n,type=Path,required=True)
    a=p.parse_args();writes,report=construct(load(a.pools,a.descriptors),json.loads(a.recipe.read_text()),a.canvas.read_bytes())
    data=bytearray(0x400000);mask=bytearray(len(data))
    for at,blob in writes:
        at-=0xa00000;require(0<=at<at+len(blob)<=len(data)and not any(mask[at:at+len(blob)]),'Complete loss resource output extent/overlap')
        data[at:at+len(blob)]=blob;mask[at:at+len(blob)]=b'\1'*len(blob)
    a.out.mkdir();(a.out/'upper.bin').write_bytes(data);(a.out/'upper.mask').write_bytes(mask);(a.out/'compiled.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')


if __name__=='__main__':main()
