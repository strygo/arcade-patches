"""Whole original fighter and attached-actor offset tables with typed relocation."""
import hashlib,struct
from public_kit_graphics import require

def sha(b):return hashlib.sha256(b).hexdigest()
def swap(b):
    require(len(b)%2==0,'Whole offset words');return b''.join(b[i:i+2][::-1]for i in range(0,len(b),2))

def construct(inputs,recipe):
    require(recipe['schema']==1 and recipe['source_region']=='jp','Canonical original owner table profile')
    require(set(inputs)==set(recipe['inputs'])=={'arcade','key','comp1','comp2'},'Complete early owner input domain')
    for n,b in inputs.items():require(recipe['inputs'][n]=={'bytes':len(b),'sha256':sha(b)},'Original early owner input '+n)
    from cps2_crypt import decrypt_rom
    raw=inputs['arcade'];ops=decrypt_rom(raw[:0x100000],inputs['key'])[0];c1=inputs['comp1'];c2=inputs['comp2'];base=0x60b080
    def read(address,size):
        off=address-base;require(0<=off<=len(c2)-size,'Original owner resource bounds');return c2[off:off+size]
    require(len(recipe['readers'])==3,'Complete three source consumers')
    for binding,address,source in zip(recipe['readers'],(0x438640,0x438668,0x3611b8),(0x61bbc0,0x61bbc0,0x751a58)):
        require(binding['address']==address and binding['source']==source,'Original source reader identity')
        off=address-0x1f0040;body=c1[off:off+128];require(sha(body)==binding['sha256'],'Original complete source reader')
        hi,lo=struct.unpack_from('<2I',body);reg=hi>>16&31;imm=lo&65535
        require(hi>>26==15 and lo>>26 in(9,13)and lo>>21&31==reg,'Original owner pointer constructor')
        value=((hi&65535)<<16)+(imm-65536 if imm&32768 else imm)if lo>>26==9 else ((hi&65535)<<16)|imm
        require(value==source,'Original owner resource pointer')
        words=struct.unpack('<32I',body)
        if address==0x438640:
            require(struct.unpack_from('<I',c1,off-28)[0]==0x00032080 and words[2:4]==(0x00831821,0x84640000),'Source scale4 and first signed offset word')
        elif address==0x438668:
            require(words[2:5]==(0x00831821,0x24630002,0x84640000),'Source second signed offset word at+2')
        else:
            require((words[8],words[13],words[23],words[30])==(0x80430102,0x00021880,0x8c430000,0xac430040),'Source owner byte,scale4,pointer read and actor+40 binding')
    require([(b['address'],b['bytes'])for b in recipe['native_readers']]==[(0x2c166,32),(0x80960,96)],'Complete native consumer extents')
    require(ops[0x80970:0x80976]==struct.pack('>HI',0x207c,0xe0920),'Native attached-offset table operand')
    require(ops[0x2c166:0x2c174]==struct.pack('>7H',0x102e,0x0102,0xe548,0x323b,0x0018,0x343b,0x0016),'Native owner byte, scale4 and paired PC-relative words')
    for b in recipe['native_readers']:
        require(sha(ops[b['address']:b['address']+b['bytes']])==b['sha256'],'Original native owner consumer')
    binding=recipe['attached_consumer'];require(binding['address']==0x361cd0 and binding['bytes']==512,'Whole original attached-coordinate consumer extent')
    at=0x361cd0-0x1f0040;body=c1[at:at+512];require(sha(body)==binding['sha256'],'Original attached-coordinate consumer identity')
    for address,word in ((0x361d6c,0x80640011),(0x361d9c,0x00832021),(0x361db0,0x8c640040),(0x361d7c,0x84631128),(0x361d80,0x3064000f),(0x361dd4,0x00831821),(0x361dd8,0x80640000),(0x361e00,0x24630001),(0x361e04,0x80640000)):
        require(struct.unpack_from('<I',c1,address-0x1f0040)[0]==word,'Original low-nibble16-pair signed-byte projection')
    pairs=swap(read(0x61bbc0,160));require(pairs[:128]==ops[0x2c186:0x2c206],'Complete original32-owner offset prefix')
    native=list(struct.unpack_from('>32I',raw,0xe0920));source=list(struct.unpack('<40I',read(0x751a58,160)))
    # Original owner aliases are preserved; original native pointers own the32 stock resources.
    require(all(0x100000<=p<0x400000 for p in native),'Original native attached-offset pointers')
    retained=[]
    for owner in range(32):
        original=raw[native[owner]:native[owner]+32];ps2=read(source[owner],32)
        retained.append({'owner':owner,'native_pointer':native[owner],'native_sha256':sha(original),'ps2_sha256':sha(ps2),'cross_port_different_bytes':sum(a!=b for a,b in zip(original,ps2))})
    require(native[:3]==[native[0]]*3 and source[:3]==[source[0]]*3,'Original native/source initial owner alias domain')
    # The historical32-byte copies straddle coordinate bytes and the following
    # independently indexed word-based common effect-placement resource.
    placements=list(struct.unpack('<40I',read(0x751af8,160)))
    require(ops[0x83a6e:0x83a74]==struct.pack('>HI',0x207c,0xe09a0),'Original native word-placement reader')
    for owner in (0,1,23):
        address=struct.unpack_from('>I',raw,0xe09a0+owner*4)[0]
        require(swap(read(placements[owner],384))==raw[address:address+384],'Whole original shared-placement ABI control')
    projected=native+[0]*8;writes=[(0xaa0800,pairs)];boundaries=[]
    for owner,target_owner in ((36,0),(37,21),(38,0)):
        require(source[owner]==source[target_owner],'Original extended owner alias');projected[owner]=native[target_owner]
    require(source.index(source[39])==22,'Original placeholder39 coordinate alias remains bound')
    projected[39]=0xaa0b20
    for index,owner in enumerate((32,33,34,35)):
        address=0xaa0aa0+index*32
        canonical=source.index(source[owner]);require(canonical==owner,'Original whole coordinate object owner alias')
        boundary=placements[canonical]-source[owner]
        require(0<boundary<=32 and boundary%2==0,'Original adjacent coordinate/placement resource boundary')
        blob=read(source[owner],boundary)+swap(read(placements[canonical],32-boundary))
        boundaries.append({'owner':owner,'canonical_source_owner':canonical,'coordinate_bytes':boundary,'following_placement_bytes':32-boundary,'coordinate_source':source[owner],'placement_source':placements[canonical]})
        projected[owner]=address;writes.append((address,blob))
    directory=struct.pack('>40I',*projected);require(sha(directory)==recipe['pointer_directory_declaration_sha256'],'Reviewed complete original native-prefix/added-list directory declaration')
    writes.append((0xaa0a00,directory))
    require(sum(len(b)for _,b in writes)==448,'Complete admitted early owner resource extents')
    return {'upper':writes},{'owners':40,'original_native_owners':32,'added_complete_lists':4,'verified_bytes':448,'open_dependencies':[{'owner':39,'address':0xaa0b20,'bytes':32,'declaration_sha256':recipe['placeholder_declaration_sha256'],'status':'Unqualified complete pointed object; no payload emitted','failed_source_models':['whole native22 clone','same-owner PS2 placement boundary','canonical-owner22 PS2 placement boundary']}],'retained_native_resources':retained,'original_resource_boundaries':boundaries,'retention_policy':'First32 original native pointers retained; original PS2 values are diagnostic and never replace native resources.'}


def main():
    import argparse,json
    from pathlib import Path
    p=argparse.ArgumentParser(description=__doc__)
    for n in ('inputs','recipe','out'):p.add_argument('--'+n,type=Path,required=True)
    a=p.parse_args();require(not a.out.exists(),'Fresh early owner output');r=json.loads(a.recipe.read_text());writes,report=construct({n:(a.inputs/(n+'.bin')).read_bytes()for n in r['inputs']},r);a.out.mkdir()
    for view,rows in writes.items():
        data=bytearray(0x400000);mask=bytearray(len(data))
        for address,b in rows:
            off=address-0xa00000;require(0<=off<=len(data)-len(b)and not any(mask[off:off+len(b)]),'Early owner packet overlap');data[off:off+len(b)]=b;mask[off:off+len(b)]=b'\1'*len(b)
        (a.out/(view+'.bin')).write_bytes(data);(a.out/(view+'.mask')).write_bytes(mask)
    (a.out/'report.json').write_text(json.dumps(report,sort_keys=True)+'\n')
if __name__=='__main__':main()
