"""Rebuild expanded-ROM data packets by copying from the player's original media.

A recipe names whole original files by identity and lists, per packet, typed
segments that cover every packet byte exactly once:

* ``["swap", source, offset, length]``: bytes of the 16-bit byte-swapped view
  of ``source`` starting at ``offset`` (PS2 little-endian words to 68K order).
* ``["raw", source, offset, length]``: unswapped bytes (byte-typed fields).
* ``["self32", [packet offsets...]]``: big-endian 32-bit pointers to the
  packet's own native address plus each offset (authored relocations).

A packet targets the expanded data view (``0xa00000``-based addresses) unless
it declares ``"view": "main"`` (logical main-program addresses).

No packet byte is stored in the recipe. Every source, segment extent and
complete packet digest is checked; any difference fails.
"""
import hashlib
import json
import struct

SIZE = 0x400000
UPPER = 0xa00000


def require(ok, message):
    if not ok:
        raise ValueError(message)


def digest(blob):
    return hashlib.sha256(blob).hexdigest()


def swap(blob):
    require(len(blob) % 2 == 0, 'Whole 16-bit source words required')
    out = bytearray(blob)
    out[::2] = blob[1::2]
    out[1::2] = blob[::2]
    return bytes(out)


def packet(row, views):
    require(set(row) - {'view'} == {'name', 'address', 'bytes', 'sha256', 'segments'} and row.get('view', 'upper') in ('main', 'upper'), 'Packet schema')
    size = row['bytes']
    require(type(size) is int and 0 < size and type(row['address']) is int, 'Packet extent')
    out = bytearray(size)
    owned = bytearray(size)
    cursor = 0
    for segment in row['segments']:
        kind = segment[0]
        if kind in ('swap', 'raw'):
            require(len(segment) == 4, 'Copy segment schema')
            _, source, offset, length = segment
            require(source in views and type(offset) is int and type(length) is int and length > 0, 'Declared copy source')
            view = views[source][kind]
            require(0 <= offset and offset + length <= len(view), 'Copy segment inside original source')
            require(cursor + length <= size and not any(owned[cursor:cursor + length]), 'Contiguous nonoverlapping copy')
            out[cursor:cursor + length] = view[offset:offset + length]
            owned[cursor:cursor + length] = b'\1' * length
            cursor += length
        elif kind == 'self32':
            require(len(segment) == 2 and type(segment[1]) is list and segment[1], 'Relocation segment schema')
            for value in segment[1]:
                require(type(value) is int and 0 <= value < size, 'Relocation targets this packet')
                require(cursor + 4 <= size and not any(owned[cursor:cursor + 4]), 'Contiguous nonoverlapping relocation')
                out[cursor:cursor + 4] = struct.pack('>I', row['address'] + value)
                owned[cursor:cursor + 4] = b'\1\1\1\1'
                cursor += 4
        else:
            raise ValueError('Unknown segment kind')
    require(cursor == size and all(owned), 'Segments cover the complete packet exactly once')
    require(digest(out) == row['sha256'], 'Complete copied packet identity: ' + row['name'])
    return bytes(out)


def construct(inputs, recipe):
    require(set(recipe) == {'schema', 'region', 'inputs', 'packets'} and recipe['schema'] == 1, 'Copy recipe schema')
    require(set(inputs) == set(recipe['inputs']), 'Complete declared original inputs')
    views = {}
    for name, blob in inputs.items():
        pin = recipe['inputs'][name]
        require(type(blob) is bytes and len(blob) == pin['bytes'] and digest(blob) == pin['sha256'], 'Original input identity: ' + name)
        views[name] = {'raw': blob, 'swap': swap(blob)}
    writes = {'upper': [], 'main': []}
    for row in recipe['packets']:
        writes[row.get('view', 'upper')].append((row['address'], packet(row, views)))
    return writes['upper'] if not writes['main'] else writes


def image(writes, base=UPPER):
    data = bytearray(SIZE)
    mask = bytearray(SIZE)
    for address, blob in writes:
        at = address - base
        require(0 <= at and at + len(blob) <= SIZE and not any(mask[at:at + len(blob)]), 'Expanded packet bounds/overlap')
        data[at:at + len(blob)] = blob
        mask[at:at + len(blob)] = b'\1' * len(blob)
    return bytes(data), bytes(mask)


def self_test():
    source = bytes(range(64))
    body = swap(source)[8:24] + source[3:7] + struct.pack('>I', 0xb00004)
    recipe = {'schema': 1, 'region': 'jp', 'inputs': {'s': {'file': 'x', 'bytes': 64, 'sha256': digest(source)}},
              'packets': [{'name': 'p', 'address': 0xb00000, 'bytes': len(body), 'sha256': digest(body),
                           'segments': [['swap', 's', 8, 16], ['raw', 's', 3, 4], ['self32', [4]]]}]}
    require(construct({'s': source}, recipe) == [(0xb00000, body)], 'Independent copy fixture')
    rejected = []
    for label in ('source-byte', 'short-cover', 'bad-kind', 'outside-source', 'wrong-relocation'):
        bad = json.loads(json.dumps(recipe))
        blob = source
        if label == 'source-byte':
            changed = bytearray(source)
            changed[9] ^= 1
            blob = bytes(changed)
            bad['inputs']['s']['sha256'] = digest(blob)
        elif label == 'short-cover':
            bad['packets'][0]['segments'][0][3] = 14
        elif label == 'bad-kind':
            bad['packets'][0]['segments'][1][0] = 'literal'
        elif label == 'outside-source':
            bad['packets'][0]['segments'][0][2] = 60
        else:
            bad['packets'][0]['segments'][2][1] = [8]
        try:
            construct({'s': blob}, bad)
        except ValueError:
            rejected.append(label)
        else:
            raise ValueError('Mutation accepted: ' + label)
    return {'passed': True, 'rejected': rejected}


def main():
    import argparse
    from pathlib import Path
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--self-test', action='store_true')
    for name in ('pools', 'recipe', 'out'):
        p.add_argument('--' + name, type=Path)
    a = p.parse_args()
    if a.self_test:
        print(json.dumps(self_test()))
        return
    require(a.pools and a.recipe and a.out and not a.out.exists(), 'Pools, recipe and fresh output required')
    recipe = json.loads(a.recipe.read_text())
    inputs = {name: (a.pools / pin['file']).read_bytes() for name, pin in recipe['inputs'].items()}
    writes = construct(inputs, recipe)
    if isinstance(writes, list):
        writes = {'upper': writes, 'main': []}
    a.out.mkdir()
    for view, base in (('upper', UPPER), ('main', 0)):
        if view == 'upper' or writes['main']:
            data, mask = image(writes[view], base)
            (a.out / (view + '.bin')).write_bytes(data)
            (a.out / (view + '.mask')).write_bytes(mask)


if __name__ == '__main__':
    main()
