"""Install twelve source-reviewed retained Guile assembly objects as raw data.

Implementation is project-authored assembly that adapts original game behavior.
This does not claim authorship of that behavior or of referenced game resources.
Only maintainer qualification compiles assembly; this runtime is stdlib-only.
"""
import argparse
import hashlib
import json
from pathlib import Path

OBJECTS = {'throws':(0xa26000,874), 'voices':(0xa34000,64),
           'body':(0xa78f00,370), 'effect':(0xa79300,510),
           'palettes':(0xa76a00,338), 'resources':(0xa79200,226),
           'scene':(0xa76e00,398), 'caption':(0xa78d00,42),
           'effect_bank':(0xa79600,190), 'scene_bank':(0xa78e00,208),
           'type4':(0xa79700,192), 'type4e':(0xa79800,124)}
OVERLAYS = {'body':[(0x9c,'122e007fd241d241','426e001a06410080')],
            'scene_bank':[(0x78,'9fff','1fff'),(0xa6,'9fff','1fff')],
            'effect_bank':[(0x86,'9fff','1fff')]}


def require(ok,message):
    if not ok: raise ValueError(message)


def digest(blob): return hashlib.sha256(blob).hexdigest()


def source_name(name):
    return 'asm/' + ('guile_native_' if name in ('throws','voices') else 'guile_stage_' if name in ('scene','palettes') else 'guile_ending_') + name + '.asm'


def apply_overlays(name, assembled, overlays):
    require(overlays == [{'offset':at,'before_hex':before,'after_hex':after} for at,before,after in OVERLAYS.get(name,[])], 'Exact authored metadata overlay census')
    result=bytearray(assembled)
    if name=='body':
        require(assembled[0x62:0x6a]==bytes.fromhex('0c2e0020007f6730') and
                assembled[0x9a:0xaa]==bytes.fromhex('7200122e007fd241d24141f900a0d334'), 'Whole scoped body metadata preimage')
    for row in overlays:
        at=row['offset'];before=bytes.fromhex(row['before_hex']);after=bytes.fromhex(row['after_hex'])
        require(len(before)==len(after) and assembled[at:at+len(before)]==before, 'Authored metadata preimage')
        if name in ('scene_bank','effect_bank'):
            require(assembled[at-2:at+4]==bytes.fromhex('026e9fff001a'), 'Whole bank-mask instruction preimage')
        result[at:at+len(after)]=after
    return bytes(result)


def construct(recipe):
    require(set(recipe)=={'schema','origin','access_view','source_region','objects','source_producers','source_policy'}, 'Authored retained recipe schema')
    require(type(recipe['schema'])is int and recipe['schema']==1 and recipe['origin']=='project-authored-assembly' and
            recipe['access_view']=='retained-inert-data' and recipe['source_region']=='jp', 'Retained authored source contract')
    require(set(recipe['objects'])==set(OBJECTS), 'Complete twelve-object inventory')
    writes=[]
    for name,(at,size)in OBJECTS.items():
        row=recipe['objects'][name]
        require(set(row)=={'address','bytes','source','source_sha256','constructed_source_sha256','symbols',
                           'assembled_sha256','assembled_hex','overlays','sha256'}, 'Authored object schema')
        require(type(row['address'])is int and type(row['bytes'])is int and (row['address'],row['bytes'])==(at,size), 'Whole authored object address/extent')
        require(row['source']==source_name(name) and recipe['source_producers'].get('backports/sfz3upper/'+row['source'])==row['source_sha256'], 'Pinned original project assembly source')
        require(all(isinstance(row[k],str) and len(row[k])==64 for k in ('source_sha256','constructed_source_sha256','assembled_sha256','sha256')), 'Source and object hash identities')
        require(type(row['symbols'])is dict and row['symbols'] and all(type(v)is int for v in row['symbols'].values()), 'Numeric source linker bindings')
        assembled=bytes.fromhex(row['assembled_hex'])
        require(len(assembled)==size and digest(assembled)==row['assembled_sha256'], 'Complete fresh authored assembly identity')
        blob=apply_overlays(name,assembled,row['overlays'])
        require(digest(blob)==row['sha256'], 'Complete authored final object identity')
        writes.append((at,blob))
    spans=sorted((at,at+len(blob))for at,blob in writes)
    require(sum(len(blob)for _,blob in writes)==3536 and all(0xa00000<=a<b<=0xe00000 for a,b in spans)and all(a[1]<=b[0]for a,b in zip(spans,spans[1:])), 'Complete nonoverlapping retained family')
    return writes


def self_test():
    controls=[];base=bytearray(208)
    for at in (0x78,0xa6):base[at-2:at+4]=bytes.fromhex('026e9fff001a')
    edits=[{'offset':at,'before_hex':'9fff','after_hex':'1fff'}for at in (0x78,0xa6)]
    result=apply_overlays('scene_bank',bytes(base),edits)
    require(result[0x76:0x7c]==bytes.fromhex('026e1fff001a') and sum(a!=b for a,b in zip(base,result))==2,'Independent typed metadata operand fixture')
    for name,blob,changes in (('wrong-preimage',bytes(208),edits),('missing-site',bytes(base),edits[:1]),
                              ('extra-site',bytes(base),edits+edits[:1])):
        try:apply_overlays('scene_bank',blob,changes)
        except ValueError:controls.append(name)
        else:raise ValueError('Invalid authored overlay accepted: '+name)
    return {'passed':True,'negative_controls':controls}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    for name in ('recipe','out'):parser.add_argument('--'+name,type=Path)
    parser.add_argument('--self-test',action='store_true');args=parser.parse_args()
    if args.self_test:print(json.dumps(self_test()));return
    require(args.recipe and args.out,'Recipe and fresh output required')
    writes=construct(json.loads(args.recipe.read_text()));require(not args.out.exists(),'Output exists')
    data=bytearray(0x400000);mask=bytearray(len(data))
    for at,blob in writes:
        at-=0xa00000;data[at:at+len(blob)]=blob;mask[at:at+len(blob)]=b'\1'*len(blob)
    args.out.mkdir();(args.out/'upper.bin').write_bytes(data);(args.out/'upper.mask').write_bytes(mask)


if __name__=='__main__':main()
