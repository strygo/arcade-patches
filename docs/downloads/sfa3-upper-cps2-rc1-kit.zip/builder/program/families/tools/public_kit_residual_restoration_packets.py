"""Rebuild complete private ending roots and approved native panel descriptors."""
import struct
import public_kit_panels as panel_renderer
from public_kit_residual_owners import require,digest,swap

ROOTS=((22,0x325944),(24,0x326724),(26,0xf72de),(29,0x32b1ec))


def roots(native,recipe):
    # Complete Mika predecessor from ending_explosion_installation, already
    # separately qualified with the restored foreground-page resource family.
    old=native[0x328b18:0x328b18+108]
    require(old[:8]==struct.pack('>4H',8,12,28,92),'Native Mika full root grammar')
    payload=bytearray(old[8:]);require(payload[92-8+8:92-8+10]==bytes((116,117)),'Mika original sky pages')
    payload[92-8+8:92-8+10]=bytes((146,147));foreground=bytearray(old[28:92])
    require(foreground[8:10]==bytes((78,78)),'Mika original foreground');foreground[8:10]=bytes((142,143))
    mika=struct.pack('>5H',10,14,30,94,110)+payload+foreground
    arena=bytearray(b'\xff'*1024);cursor=0;proof=[]
    require([r['owner']for r in recipe]==[22,24,26,29],'Complete private-root owner domain')
    for (owner,address),pin in zip(ROOTS,recipe):
        source=mika if owner==26 else native[address:address+1024]
        n=struct.unpack_from('>H',source)[0]//2;require(0<n<32,'Native root directory bound')
        offsets=struct.unpack_from('>'+str(n)+'H',source);length=offsets[-1]+(16 if owner==22 else 64)
        require(offsets==tuple(sorted(offsets))and length<=len(source),'Native complete root directory/extent')
        blob=bytearray(source[:length]);require(length==pin['bytes']and digest(blob)==pin['sha256'],'Whole original root identity')
        slot=3 if owner==22 else 1
        changes={22:{0:148,1:149},24:{8:148,9:149,10:152,11:153},26:{14:150,15:151},29:{6:148,7:149}}[owner]
        for pos,page in changes.items():
            at=offsets[slot]+pos;require(blob[at]=={148:111,149:112,150:125,151:126,152:119,153:120}[page],'Private page replacement source preimage');blob[at]=page
        if owner in (22,29):
            for pos,page,oldpage in ((33,144,124),(34,147,125))if owner==22 else((16,144,124),(17,147,125)):
                at=offsets[2]+pos;require(blob[at]==oldpage,'Private ceiling page source preimage');blob[at]=page
        require(cursor+length<=1024,'Complete private root arena bound');arena[cursor:cursor+length]=blob;proof.append({'owner':owner,'offset':cursor,'bytes':length});cursor+=length+(length&1)
    # P022 ending_room_margins: Honda selects the existing clean roof pair.
    require(arena[0x9e:0xa0]==bytes((124,125)),'Original Honda roof-followup preimage')
    arena[0x9e:0xa0]=bytes((144,147))
    return bytes(arena),proof


def panels(native,pixels,rows,font,rendered,route_pixels,render_recipe):
    require(len(rows)==48,'Complete48 approved stage panels')
    require(struct.unpack_from('>7H',native,0x2f357a)==(14,270,526,526,782,1038,0),'Complete original caption root grammar')
    for ch,pin in font.items():
        tile=0x16c00+0x280+ord(ch);packed=pixels[tile*128:(tile+1)*128]
        # P008 sprite_tile explicitly reverses the four native plane bits.
        reverse=lambda v:((v&1)<<3)|((v&2)<<1)|((v&4)>>1)|((v&8)>>3)
        decoded=bytes(reverse(v) for byte in packed for v in (byte&15,byte>>4))
        require(len(decoded)==256 and digest(decoded)==pin,'Original complete native font glyph '+ch)
    coords={struct.unpack_from('>2h',native,0x229ae+n*4):n*4 for n in range(256)};body=bytearray();seen=set()
    for row in rows:
        owner,root=row['owner'],row['root'];require((owner,root)not in seen and 0<=owner<32 and root in(0,1),'Unique original caption owner/root');seen.add((owner,root))
        frame=0x2f357a+(14 if root==0 else 270)+owner*8;control,address=struct.unpack_from('>2I',native,frame)
        require(frame==row['frame']and address==row['source']and control==0x08000000,'Actual original caption frame/cel binding')
        kind,total,last,hx,hy=struct.unpack_from('>3H2h',native,address);require(kind==6 and total==37 and last<256,'Native complete caption geometry')
        source=native[address:address+10+(last+1)*6];require(digest(source)==row['source_sha256'],'Complete original caption cel')
        commands=[struct.unpack_from('>3H',source,10+n*6)for n in range(last+1)]
        require(sum(((a>>8&15)+1)*((a>>12&15)+1)for _,_,a in commands)==37,'Original full caption area')
        heading=[v for v in commands if v[1]==57296];require(len(heading)==1 and heading[0][2]==0x080e,'Original heading command')
        x,y=struct.unpack_from('>2h',native,0x229ae+heading[0][0]);require(hy+y==0 and hx+x in(-120,-24),'Original caption placement branch')
        left=-104 if hx+x==-120 else-120;require(left==row['approved_left'],'Reviewed original panel anchor')
        position=(left-hx,16-hy);require(position in coords,'Original coordinate directory contains complete panel anchor')
        tile=row['tile'];require(0x3f8c0<=tile<=0x40000-32 and tile%16==0,'Reviewed complete32-tile panel allocation')
        require(all(ch in font for ch in row['text']),'Complete original font source for panel')
        matches=[v for v in render_recipe['panels'] if int(v['source']['address'],16)==address and v['root']==root and v['text']==row['text']]
        require(len(matches)==1,'Complete panel renderer source binding')
        block=panel_renderer.construct(native,pixels,dict(render_recipe,panels=matches,countries={}))
        require(len(block)==4096,'Whole rendered32-tile panel')
        routed=bytearray()
        for op in row['routes']:
            if op[0]=='fill':routed.extend(bytes([op[1]])*op[2])
            else:
                require(op[0]=='copy' and op[1] in ('native','rendered'),'Original panel route grammar')
                src=route_pixels if op[1]=='native' else rendered
                routed.extend(src[op[2]:op[2]+op[3]])
        require(bytes(routed)==block,'Complete final relocated panel artwork route')
        require(row['route_destination']==(tile-0x3f8c0+0x7e000)*128,'Final physical panel bank binding')
        body.extend(struct.pack('>3H2h',6,37,1,hx,hy)+struct.pack('>3H',coords[position],(tile-0x3f8c0+0x7e000)&65535,0x1d0e)+struct.pack('>3H',*heading[0]))
    require(len(body)==1056,'Complete panel descriptor extent');return bytes(body)


def project(inputs,recipe):
    require(set(inputs)==set(recipe['inputs'])=={'arcade','pixels','rendered','route_pixels'},'Complete restoration packet inputs')
    for k,v in inputs.items():require(len(v)==recipe['inputs'][k]['bytes']and digest(v)==recipe['inputs'][k]['sha256'],'Original input '+k)
    require(recipe['region']in('us','jp'),'Explicit output region');blob,proof=roots(inputs['arcade'],recipe['roots']);writes=[(0xd6d000,blob)]
    if recipe['region']=='us':writes.append((0xdbef52,panels(inputs['arcade'],inputs['pixels'],recipe['panels'],recipe['font'],inputs['rendered'],inputs['route_pixels'],recipe['render_recipe'])))
    return writes,{'bytes':sum(len(v)for a,v in writes),'roots':proof,'panel_descriptors':48 if recipe['region']=='us'else 0,'source_region':'jp','geometry_source':'Original native complete cels, frame-table pointers, coordinates and heading commands; original reviewed panel layout branch'}


def construct(inputs,recipe):
    writes,proof=project(inputs,recipe);require({str(a):digest(v)for a,v in writes}==recipe['outputs'],'Complete source-generated packet identity');return writes,proof


def main():
    import argparse,json
    from pathlib import Path
    p=argparse.ArgumentParser(description=__doc__)
    for n in ('pools','recipe','out'):p.add_argument('--'+n,type=Path,required=True)
    a=p.parse_args();recipe=json.loads(a.recipe.read_text());names=('sz3j.03c','sz3j.04c','sz3.05c','sz3.06c','sz3.07c','sz3.08c','sz3.09c','sz3.10b')
    inputs={'arcade':swap(b''.join((a.pools/('arcade-jp-'+n)).read_bytes()for n in names)),'pixels':(a.pools/'arcade-jp-pixels.bin').read_bytes()}
    inputs['rendered']=panel_renderer.from_pools(a.pools,__import__('json').loads((a.pools/'pools.json').read_text()),recipe['render_recipe']);inputs['route_pixels']=(a.pools/'arcade-us-pixels.bin').read_bytes()
    writes,report=construct(inputs,recipe);data=bytearray(0x400000);mask=bytearray(len(data))
    for at,blob in writes:at-=0xa00000;data[at:at+len(blob)]=blob;mask[at:at+len(blob)]=b'\1'*len(blob)
    a.out.mkdir();(a.out/'upper.bin').write_bytes(data);(a.out/'upper.mask').write_bytes(mask);(a.out/'resources.json').write_text(json.dumps(report))


if __name__=='__main__':main()
