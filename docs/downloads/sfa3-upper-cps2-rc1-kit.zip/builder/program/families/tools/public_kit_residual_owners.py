"""Complete retained Shin/Hawk callback and shared-effect owner resources."""
import hashlib
import struct
from functools import lru_cache
from cps2_crypt import decrypt_rom

ROLES=('throw','entrance','command','special_human','special_CPU','availability')
OPERANDS=(0x29c28,0x2a0a6,0x2b15e,0x28ae8,0x28af4,0x328a6)
ADDRESSES=(0xc502e4,0xc50378,0xc54214,0xc542a8,0xc5433c,0xc543d0)


def require(ok,message):
    if not ok:raise ValueError(message)


def digest(blob):return hashlib.sha256(blob).hexdigest()


@lru_cache(maxsize=1)
def opcodes(raw,key):return decrypt_rom(raw[:0x100000],key)[0]


def swap(blob):
    require(len(blob)%2==0,'Complete original word array')
    out=bytearray(blob);out[::2]=blob[1::2];out[1::2]=blob[::2];return bytes(out)


def project(inputs,recipe):
    require(set(inputs)==set(recipe['inputs'])=={'arcade','key','comp1','comp2','naomi'},'Complete original owner resource inputs')
    require(recipe['source_region']=='jp' and recipe['region']in ('us','jp'),'Explicit inherited JP construction sources')
    for name,blob in inputs.items():
        pin=recipe['inputs'][name];require(type(blob)is bytes and len(blob)==pin['bytes'] and digest(blob)==pin['sha256'],'Original owner input '+name)
    raw=inputs['arcade'];ops=opcodes(raw,inputs['key']);writes=[];proof=[]
    require(tuple(r['role']for r in recipe['callbacks'])==ROLES,'Complete six callback directories')
    for row,operand,address in zip(recipe['callbacks'],OPERANDS,ADDRESSES):
        role=row['role'];require(row['operand']==operand and row['address']==address,'Declared owner callback location')
        require(ops[operand-2:operand] in (b'\x20\x7c',b'\x22\x7c') and digest(ops[operand-2:operand+8])==row['reader_sha256'],'Original whole callback reader')
        root=struct.unpack_from('>I',ops,operand)[0];prefix=bytearray(raw[root:root+128])
        require(digest(prefix)==row['native_sha256'],'Complete native32 callback prefix')
        require(len(row['added32_33'])==2,'Complete Guile/Fei callback additions')
        prefix.extend(struct.pack('>2I',*row['added32_33']))
        for edit in row['early_edits']:
            at=edit['owner']*4;require(edit['owner']in (23,32,33) and prefix[at:at+4].hex()==edit['before'],'Reviewed early whole callback preimage')
            prefix[at:at+4]=struct.pack('>I',edit['value'])
        prefix.extend(struct.pack('>I',row['dee']))
        require(len(prefix)==140 and digest(prefix)==row['previous35_sha256'],'Complete original35-owner predecessor '+role)
        body=prefix+bytes(4)+struct.pack('>I',row['shin'])
        require(digest(body)==row['original_shin_sha256'],'Whole original held-Hawk Shin directory '+role)
        require(digest(prefix)==row['hawk_retained35_sha256'],'Hawk retained prefix witness')
        body[140:144]=struct.pack('>I',row['hawk'])
        for edit in row['relocations']:
            require(edit['address']==address+128 and int.from_bytes(body[128:132],'big')==edit['before'],'Reviewed retained Guile callback relocation')
            body[128:132]=struct.pack('>I',edit['after'])
        writes.append((address,bytes(body)));proof.append({'role':role,'bytes':148,'sha256':digest(body)})
    c2=inputs['comp2'];base=0x60b080;table=0x751af8
    def read(at,size):
        require(base<=at<=base+len(c2)-size,'Complete PS2 shared placement bounds')
        return c2[at-base:at-base+size]
    pointer=lambda owner,parity:struct.unpack('<I',read(table+owner*4+160*parity,4))[0]
    effect=recipe['effects'];banks={}
    for owner in (32,33,34,35):
        frames=effect['source_frames'][str(owner)]
        require(frames==sorted(set(frames)) and len(frames)>1,'Complete installed shared-effect frame census')
        require(max(read(at+17,1)[0]&31 for at in frames)==13,'Complete fourteen-pose placement demand')
        source=pointer(owner,False);require(pointer(owner,True)==source+224,'Complete contiguous placement normal/parity groups')
        banks[owner]=swap(read(source,256))
    for parity,native_root,operand in ((False,0xe09a0,0x83a70),(True,0xe0a20,0x83ac2)):
        require(ops[operand-2:operand+4]==b'\x20\x7c'+struct.pack('>I',native_root),'Original placement reader ABI')
        for owner in (0,1,2,23):
            target=struct.unpack_from('>I',raw,native_root+owner*4)[0];size=32 if parity else 384
            require(raw[target:target+size]==swap(read(pointer(owner,parity),size)),'Complete original/native shared-placement controls')
        require(pointer(36,parity)==pointer(2,parity),'Original Shin shared Akuma placement alias')
        prefix=raw[native_root:native_root+128]+struct.pack('>2I',0xbc5110+224*parity,0xbc5210+224*parity)
        row=effect['directories'][int(parity)]
        require(digest(prefix)==row['previous34_sha256'],'Complete retained34 placement directory')
        body=prefix+struct.pack('>I',0xc550a0+224*parity)+bytes(4)+prefix[8:12]
        require(len(body)==148 and digest(body)==row['shin_sha256'],'Complete Shin shared-effect directory')
        writes.append((0xc551a0+148*parity,body))
        hawk=bytearray(body);hawk[140:144]=struct.pack('>I',0xdd6f98+224*parity)
        require(digest(hawk)==row['hawk_sha256'],'Complete Hawk shared-effect directory')
        writes.append((0xdd7098+148*parity,bytes(hawk)))
    for owner,address in ((34,0xc550a0),(35,0xdd6f98)):
        require(digest(banks[owner])==effect['bank_sha256'][str(owner)],'Whole original added placement bank')
        writes.append((address,banks[owner]))
    c1=inputs['comp1'];pc=0x369b98-0x1f0040
    hi,lo=struct.unpack_from('<2I',c1,pc)
    require(hi>>26==15 and lo>>26==9 and (hi>>16)&31==(lo>>21)&31==(lo>>16)&31,'Actual original counter-table address producer')
    immediate=lo&65535;immediate-=65536 if immediate&32768 else 0
    source=((hi&65535)*65536+immediate)&0xffffffff;require(source==0x616d90,'Original counter table address')
    rows=read(source,40);counter=effect['counter']
    require(digest(c1[0x369b50-0x1f0040:0x369bf0-0x1f0040])==counter['source_function_excerpt_sha256'],'Complete original counter reader witness')
    require(digest(rows)==counter['source40_sha256'] and rows[:32]==ops[0x839ac:0x839cc] and rows[36]==rows[2],'Complete original/native counter selector correspondence')
    require(rows[:32]in inputs['naomi'],'Independent Naomi counter selector prefix')
    writes.append((0xc552c8,rows[:35]+b'\0'+rows[36:37]))
    require(sum(len(v)for _,v in writes)==2029,'Complete residual-owner family extent')
    return writes,{'bytes':2029,'callbacks':proof,'shared_effect_directories':4,'placement_banks':2,'counter_rows':37,'source_region':'jp'}


def construct(inputs,recipe):
    writes,report=project(inputs,recipe)
    require({str(at):digest(blob)for at,blob in writes}==recipe['outputs'],'Complete source-derived owner outputs')
    return writes,report


def main():
    import argparse,json
    from pathlib import Path
    p=argparse.ArgumentParser(description=__doc__)
    for name in ('pools','recipe','out'):p.add_argument('--'+name,type=Path,required=True)
    a=p.parse_args();recipe=json.loads(a.recipe.read_text());inputs={name:(a.pools/pin['file']).read_bytes()for name,pin in recipe['inputs'].items()if name!='arcade'}
    names=('sz3j.03c','sz3j.04c','sz3.05c','sz3.06c','sz3.07c','sz3.08c','sz3.09c','sz3.10b')
    inputs['arcade']=swap(b''.join((a.pools/('arcade-jp-'+n)).read_bytes()for n in names))
    writes,report=construct(inputs,recipe);out=bytearray(0x400000);mask=bytearray(len(out))
    for at,blob in writes:at-=0xa00000;out[at:at+len(blob)]=blob;mask[at:at+len(blob)]=b'\1'*len(blob)
    a.out.mkdir();(a.out/'upper.bin').write_bytes(out);(a.out/'upper.mask').write_bytes(mask);(a.out/'resources.json').write_text(json.dumps(report))


if __name__=='__main__':main()
