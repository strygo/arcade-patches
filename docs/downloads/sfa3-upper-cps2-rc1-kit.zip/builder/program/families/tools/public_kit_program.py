"""Encode complete authored helpers using the original key at final byte addresses.

The recipe contains reviewed authored program source, never candidate ROM bytes.
A zero mask is unresolved, not padding. This is a partial main-program producer.
"""
import argparse
import copy
import hashlib
import json
from pathlib import Path
from cps2_crypt import decode_key
from cps2_encrypt import encrypt_word
from cps2_code_guard import require_code_spans


def require(ok,message):
    if not ok:raise ValueError(message)


def construct(key,recipe):
    require(hashlib.sha256(key).hexdigest()==recipe['key_sha256'],'Original key identity differs')
    rows=recipe['allocations'];require(rows,'No complete authored allocations')
    require_code_spans([{'name':r['name'],'start':r['address'],'size':len(bytes.fromhex(r['opcodes']))} for r in rows],key=key)
    master,low,high,_=decode_key(key)
    output=bytearray(0x400000);mask=bytearray(len(output))
    for row in rows:
        at=row['address'];body=bytes.fromhex(row['opcodes'])
        require(at%2==0 and len(body)%2==0 and len(body)>0,'Complete opcode allocation alignment')
        require(hashlib.sha256(body).hexdigest()==row['opcode_sha256'],'Authored source output differs')
        for offset in range(0,len(body),2):
            word=int.from_bytes(body[offset:offset+2],'big')
            encoded=encrypt_word(word,(at+offset)//2,master,low,high).to_bytes(2,'big')
            for i,value in enumerate(encoded):
                pos=at+offset+i
                require(not mask[pos] or output[pos]==value,'Conflicting complete code allocations')
                output[pos]=value;mask[pos]=1
    return bytes(output),bytes(mask)


def self_test(key,recipe):
    rejected=[]
    for name,change in (
        ('wrong-original-key',lambda r:r.update(key_sha256='0'*64)),
        ('unsafe-complete-allocation',lambda r:r['allocations'][0].update(address=0x400000)),
        ('changed-authored-body',lambda r:r['allocations'][0].update(opcode_sha256='0'*64))):
        bad=copy.deepcopy(recipe);change(bad)
        try:construct(key,bad)
        except ValueError:rejected.append(name)
        else:raise ValueError('Invalid program recipe accepted: '+name)
    # Source-bound mutation, re-pinned to reach the cipher rather than merely
    # failing an identity check. A changed opcode must change its actual bytes.
    seed=copy.deepcopy(recipe);seed['allocations']=seed['allocations'][:1]
    original,_=construct(key,seed);body=bytearray.fromhex(seed['allocations'][0]['opcodes']);body[1]^=1
    seed['allocations'][0].update(opcodes=body.hex(),opcode_sha256=hashlib.sha256(body).hexdigest())
    mutated,_=construct(key,seed)
    at=seed['allocations'][0]['address']
    require(original[at:at+2]!=mutated[at:at+2] and original[:at]==mutated[:at] and original[at+2:]==mutated[at+2:],
            'Source-bound opcode mutation did not remain address-local')
    return {'rejected':rejected,'source_opcode_mutation_changes_only_its_encrypted_word':True}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    for name in ('key','recipe'):parser.add_argument('--'+name,type=Path,required=True)
    parser.add_argument('--out',type=Path);parser.add_argument('--self-test',action='store_true')
    args=parser.parse_args();key=args.key.read_bytes();recipe=json.loads(args.recipe.read_text())
    if args.self_test:
        print(json.dumps(self_test(key,recipe)));return
    require(args.out is not None,'Output directory required')
    data,mask=construct(key,recipe)
    args.out.mkdir();(args.out/'main.bin').write_bytes(data);(args.out/'main.mask').write_bytes(mask)


if __name__=='__main__':main()
