"""Install bounded source-declared native transfer families, never opcode payloads."""
import argparse,hashlib,json,struct
from functools import lru_cache
from pathlib import Path
from cps2_crypt import decrypt_rom,decode_key
from cps2_encrypt import encrypt_word
from cps2_code_guard import require_code_spans

def require(ok,message):
    if not ok:raise ValueError(message)
def sha(data):return hashlib.sha256(data).hexdigest()
def swap(data):return b''.join(data[n:n+2][::-1]for n in range(0,len(data),2))
@lru_cache(maxsize=1)
def original_opcodes(raw,key):
    """Reuse only identical immutable source bytes within this process."""
    return decrypt_rom(raw,key)[0]

# Complete native write extents from the original installers. Destination
# identities are source-compiled allocations, not operands read from a build.
SELECTION=(('picker',0x1e8ac,24),('questions',0x21b3c,6),('names',0x8733e,6),
 ('heads',0x8731e,8),('cpu_set',0x4b88,8),('reset',0x7f6c,8),
 ('initialize',0x8eb4,8),('cpu',0x923c,6),('choose',0x1e76e,8),
 ('auto',0x1e7f6,6),('ism',0x1eac6,6),('head_color',0x1f75c,6))
PALETTES=(0x1fc38,0x1fc54,0x1fc70,0x1fbe4,0x1fe50,0x1febc,0x1fef8,0x1fde0)
TINTS=(0x1f9ec,0x1fa08,0x1fa24,0x1f998)
ENDING=(0x25e9a,0x2752c,0x2643e,0x26a6e,0x26a94,0xd160,0xaa630,
 0xa75c6,0xa62bc,0xa63f2,0xa7158,0xaaa42,0xaab0c,0xac2d2)
POSES=(0x2f9dc,0x2fa54,0x2face,0x2fb42,0x2fbb6,0x2fc18)

def inventory(region="jp"):
    require(region in ("us","jp"),"Regional hook profile")
    rows=[('selection',n,a,z,'jmp')for n,a,z in SELECTION]
    rows += [('stage_palette','palette_'+str(n),a,10,'jmp')for n,a in enumerate(PALETTES)]
    rows += [('stage_palette','tint_'+str(n),a,6,'jmp')for n,a in enumerate(TINTS)]
    rows += [('ending','bind_'+hex(a),a,10 if a==0xac2d2 else 6,
              'jsr'if a in(0x26a6e,0x26a94,0xd160)else'jmp')for a in ENDING]
    rows += [('throw','pose_table',a,6,'jsr')for a in POSES]
    rows += [('throw','pose_victim',a+12,6,'jsr')for a in POSES]
    rows += [('throw','admission',0x2b24a,8,'jmp'),('throw','pose_frame',0x2fc36,6,'jmp')]
    if region=="us":rows=[(f,n,0xd156,24,"jmp") if f=="ending" and a==0xd160 else (f,n,a,z,k) for f,n,a,z,k in rows]
    return rows

def construct(inputs,recipe):
    require(recipe['schema']==1 and recipe['source_region']=='jp','Canonical native hook profile')
    require(set(inputs)==set(recipe['inputs'])=={'arcade','key'},'Original hook input inventory')
    for n,b in inputs.items():require(recipe['inputs'][n]=={'bytes':len(b),'sha256':sha(b)},'Original hook input '+n)
    raw=inputs['arcade'];key=inputs['key']
    require(sha(raw)=='600f686a6ef90225c48231c0fbad86c7ca2b4eeddc93691b479a5b8a3f3b3cd5','Complete canonical native image')
    ops=original_opcodes(raw[:0x100000],key);master,low,high,_=decode_key(key)
    expected=inventory(recipe["region"]);require(len(recipe['hooks'])==len(expected),'Complete native hook sibling domain')
    require_code_spans([{'name':f+'/'+n,'start':a,'size':z}for f,n,a,z,k in expected],key=key)
    output=[];proof=[]
    for row,(family,name,at,size,kind)in zip(recipe['hooks'],expected):
        require((row['family'],row['name'],row['address'],row['bytes'],row['operation'],row['view'])==
                (family,name,at,size,kind,'opcode'),'Typed native hook declaration differs')
        require(sha(ops[at:at+size])==row['original_sha256'],'Complete original native hook preimage')
        target=row['target'];contract=recipe['targets'][row['target_contract']]
        require(type(target)is int and target in contract['entries'] and target%2==0,
                'Source-compiled target entry differs')
        require(contract['address']<=target<contract['address']+contract['bytes'],'Target outside complete source object')
        require_code_spans([{'name':row['target_contract'],'start':contract['address'],'size':contract['bytes']}],key=key)
        body=struct.pack('>HI',{'jmp':0x4ef9,'jsr':0x4eb9}[kind],target)+b'\x4e\x71'*((size-6)//2)
        encoded=b''.join(encrypt_word(int.from_bytes(body[n:n+2],'big'),(at+n)//2,master,low,high).to_bytes(2,'big')for n in range(0,size,2))
        output.append((at,encoded));proof.append({'family':family,'name':name,'address':at,'bytes':size,
            'operation':kind,'target':target,'opcode_sha256':sha(body),'cipher_sha256':sha(encoded)})
    require(sum(len(b)for _,b in output)==(396 if recipe['region']=='us' else 378),'Complete admitted native hook extents')
    # The original reader accesses signed byte coordinates through PC-relative
    # opcodes; relocated arrays are plain data read by the authored helper.
    require(ops[0x1e5d6:0x1e5e0]==bytes.fromhex('d241103b1030123b102d'),'Original complete cursor pair reader')
    original=ops[0x1e60a:0x1e652];require(len(original)==72 and sha(original)==recipe['cursor']['original_sha256'],'Complete original36-token cursor array')
    # Hidden-player placement precedes the pending-player and random-token
    # additions. Preserve this authored chronology over the original32 rows.
    pairs=bytearray(original[:64]);slots=((21,5,5),(30,0,4),(31,6,4),(23,6,2),(32,1,1),(33,5,1),(34,0,2),(35,1,5))
    require(recipe['cursor']['authored_slots']==[list(x)for x in slots],'Reviewed authored select grid slots')
    grid=bytearray(ops[0x1e724:0x1e764])
    for token,(x,y),(ox,oy)in ((160,(2,0),(1,1)),(98,(4,0),(5,1)),(99,(2,6),(1,5)),(161,(4,6),(5,5))):
        require(grid[oy*8+ox]==token and grid[y*8+x]==255,'Original random relocation cell preimages')
        grid[oy*8+ox]=255;grid[y*8+x]=token
    for owner,x,y in slots:
        require(grid[y*8+x]==255,'Authored hidden/pending slot preimage');grid[y*8+x]=owner
        if owner<32:pairs[owner*2:owner*2+2]=bytes((x,y))
        else:require(len(pairs)==owner*2,'Contiguous new select owners');pairs.extend((x,y))
    pairs.extend(pairs[4:6]);pairs.extend(pairs[42:44])
    random=bytearray(original[64:72])
    for x,y,token in ((2,0,0xa0),(4,0,0x61),(4,6,0xa2),(2,6,0x63)):
        random[(token&3)*2:(token&3)*2+2]=bytes((x,y))
    for at,body in ((0xf0490,bytes(pairs)),(0xf04e0,bytes(random))):
        require(raw[at:at+len(body)]==b'\xff'*len(body),'Original cursor raw reservation preimage')
        require(sha(body)==recipe['cursor']['declarations'][str(at)],'Complete reviewed cursor object declaration')
        output.append((at,body))
    return {'main':output},{'hooks':proof,'verified_bytes':480 if recipe['region']=='us' else 462,'cursor_raw_bytes':84,'access_view':'Typed hooks encrypted; cursor arrays raw',
        'excluded':recipe['excluded'],'source_contracts':recipe['source_contracts']}

def main():
    p=argparse.ArgumentParser(description=__doc__)
    for n in('inputs','recipe','out'):p.add_argument('--'+n,type=Path,required=True)
    a=p.parse_args();r=json.loads(a.recipe.read_text());writes,report=construct({n:(a.inputs/(n+'.bin')).read_bytes()for n in r['inputs']},r)
    require(not a.out.exists(),'Fresh hook output required');a.out.mkdir()
    for view,rows in writes.items():
        data=bytearray(0x400000);mask=bytearray(len(data))
        for at,body in rows:
            require(not any(mask[at:at+len(body)]),'Overlapping native hook families')
            data[at:at+len(body)]=body;mask[at:at+len(body)]=b'\1'*len(body)
        (a.out/(view+'.bin')).write_bytes(data);(a.out/(view+'.mask')).write_bytes(mask)
    (a.out/'report.json').write_text(json.dumps(report,sort_keys=True)+'\n')
if __name__=='__main__':main()
