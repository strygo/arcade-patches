"""Extract complete original PL22 descriptor section from declared GD-ROM/PIC."""
import argparse,json,struct
from pathlib import Path
import public_kit_media as media

PAC_SHA256='881f9b1a3152377dbf40bab3e5637b3c4c246449b2a11505a88ee9155de6036e'


def extract(blob):
    media.require(media.digest(blob)==PAC_SHA256,'Complete original PL22 identity')
    count,total=struct.unpack_from('<II',blob)
    media.require(0<count<64,'Complete original PAC section count')
    sections=[];at=0x800
    for i in range(count):
        kind,size=struct.unpack_from('<II',blob,8+i*8)
        media.require(at+size<=len(blob),'Original descriptor section extent')
        sections.append((kind,blob[at:at+size]));at=(at+size+0x7ff)&~0x7ff
    media.require(sections[1][0]==0x200000,'Original fighter tile loader section')
    descriptor=sections[0][1];offset=struct.unpack_from('<I',descriptor)[0]
    media.require(offset and offset%12==0 and offset<=len(descriptor),'Whole original descriptor directory')
    return descriptor,{'pac_sha256':PAC_SHA256,'pac_bytes':len(blob),'section_types':[k for k,v in sections],'section_bytes':[len(v)for k,v in sections],'descriptor_count':offset//12,'descriptor_bytes':len(descriptor),'descriptor_sha256':media.digest(descriptor)}


def main():
    p=argparse.ArgumentParser(description=__doc__)
    for name in ('contract','naomi-chd','naomi-pic','scratch','chdman','out'):p.add_argument('--'+name,type=Path,required=True)
    a=p.parse_args();pin=json.loads(a.contract.read_text())
    media.require(not a.out.exists(),'Original descriptor output must be fresh')
    with media.naomi(a.naomi_chd,a.naomi_pic,pin,a.scratch,a.chdman)as(data,files):
        offset,size=files['PL22.PAC'];descriptor,report=extract(data[offset:offset+size])
    a.out.mkdir();(a.out/'naomi-PL22-descriptors.bin').write_bytes(descriptor)
    (a.out/'source.json').write_text(json.dumps({'schema':1,'input':pin,'resource':report},sort_keys=True,indent=2)+'\n')


if __name__=='__main__':main()
