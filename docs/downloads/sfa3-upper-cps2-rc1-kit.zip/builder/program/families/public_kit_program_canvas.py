"""Write the expanded graphics pixel canvas from the player's original pools.

The canvas is rebuilt from the region's numeric graphics recipe, the same
construction the data job uses. Resource families verify its exact identity
before using it.
"""
import argparse
import json
from pathlib import Path
import zlib

EXPANDED = 0x2000000  # upper.gfx pixel bytes (32 MiB of 4-bit pixels, one per byte)


def require(ok, message):
    if not ok:
        raise ValueError(message)


def canvas(pools, recipes, region):
    import public_kit_graphics_recipe as graphics
    import public_kit_panels as panels
    load = lambda name: json.loads((recipes/name).read_text())
    catalog = json.loads((pools/'pools.json').read_text())
    recipe = json.loads(zlib.decompress((recipes/(region+'.graphics.json.zlib')).read_bytes()))
    sources = {}
    for name in recipe['pools']:
        if name == 'derived-us-stage-panels.bin':
            require(region == 'us', 'English panels in another region')
            sources[name] = panels.from_pools(pools, catalog, load('panels.json'))
        else:
            actual = {'arcade-us-pixels.bin': 'arcade-jp-pixels.bin',
                      'arcade-us-cloud-continuation.bin': 'arcade-jp-cloud-continuation.bin'}.get(name, name)
            sources[name] = (pools/actual).read_bytes()
    pixels = bytes(graphics.apply(recipe, sources))
    # The recipe spans the original and expanded graphics address space; the
    # families bind the expanded member's half (upper.gfx pixels).
    require(len(pixels) == 2*EXPANDED, 'Complete original-plus-expanded graphics canvas')
    return pixels[EXPANDED:]


def main():
    p = argparse.ArgumentParser(description=__doc__)
    for name in ('pools', 'recipes', 'out'):
        p.add_argument('--'+name, type=Path, required=True)
    p.add_argument('--region', choices=('us', 'jp'), required=True)
    a = p.parse_args()
    require(not a.out.exists(), 'Fresh canvas output required')
    a.out.mkdir()
    (a.out/'canvas.bin').write_bytes(canvas(a.pools, a.recipes, a.region))


if __name__ == '__main__':
    main()
