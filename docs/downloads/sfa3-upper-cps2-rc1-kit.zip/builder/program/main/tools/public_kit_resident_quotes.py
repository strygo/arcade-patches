"""Original current-roster Japanese quote pools and complete font directory."""
import hashlib
import struct
from public_kit_graphics import require
from public_kit_original_quotes import source_pools,pack
from public_kit_quote_fonts import glyphs

COMMON=tuple(n for n in range(32)if n not in (18,19,20,21,23,30,31))
PROMOTED=(21,30,31)


def construct(inputs,recipe,pixels):
    require(recipe['region']=='jp','Original resident Japanese quote region')
    for name,pin in recipe['inputs'].items():
        blob=inputs[name];require(len(blob)==pin['bytes'] and hashlib.sha256(blob).hexdigest()==pin['sha256'],'Original resident quote input: '+name)
    require(hashlib.sha256(pixels).hexdigest()==recipe['pixels_sha256'],'Resident quote native graphics identity')
    source,source_map=source_pools(inputs['comp2']);raw=inputs['arcade'];font=inputs['font']
    native_offsets=struct.unpack_from('>32H',raw,0xc985a)
    native_map=list(raw[0xd194:0xd1b4]);require(len(native_map)==32,'Original native opponent map extent')
    for owner,slot in zip(PROMOTED,(33,34,35)):native_map[owner]=slot
    data=bytearray(128);addresses={};used=set();count=0
    for owner in (*COMMON,*PROMOTED):
        if owner in COMMON:rows=[(opponent,source_map[opponent])for opponent in PROMOTED]
        else:
            rows=[(None,slot)for slot in range(8)]+[(opponent,source_map[opponent])for opponent in (*COMMON,*PROMOTED)]
            rows.sort(key=lambda row:row[1]if row[0]is None else native_map[row[0]])
            require([slot if opponent is None else native_map[opponent]for opponent,slot in rows]==list(range(36)),'Complete promoted quote slot routing')
        records=[source[owner][slot]for _,slot in rows]
        addresses[owner]=0x3f4000+len(data);data.extend(pack(records));count+=len(records)
        used.update(set().union(*(glyphs(record)for record in records)))
    require(count==183 and len(data)<0x2000,'Original current roster quote family extent')
    for owner in range(32):
        actual=owner if owner in PROMOTED else next((n for n in COMMON if native_offsets[n]==native_offsets[owner]),None)
        require(actual is not None,'Unknown native quote owner alias')
        struct.pack_into('>I',data,owner*4,addresses[actual])
    allocations=dict(recipe['font_allocations']);require(len(allocations)==len(recipe['font_allocations']) and set(allocations)<={g for g in used if 0x7a0<=g<0x7ec},'Resident font allocation domain')
    mapping=[];checked=0
    for glyph in range(0x7a0,0x7ec):
        target=allocations.get(glyph,0x19760+glyph)
        require(0x16c00<=target<0x20000,'Resident quote font tile bounds')
        if glyph in used:
            original=font[(0x4780+glyph)*128:(0x4781+glyph)*128]
            require(len(original)==128 and pixels[target*128:(target+1)*128]==original,'Complete resident original glyph differs')
            checked+=1
        mapping.append(target-0x16c00)
    return [(0x3f4000,bytes(data)),(0x3f8000,struct.pack('>76H',*mapping))],{'records':count,'pools':len(addresses),'owner_directory_entries':32,'font_entries':76,'used_font_tiles_checked':checked,'quote_bytes':len(data)}
