"""Pinned original program conversion functions; no checkout dependency."""
from __future__ import annotations
from audit_select_random_portraits import SOURCE_RECORDS

FIRST=0x3f90a


CELLS=((2,0,0xa0,166),(4,0,0x61,103),(4,6,0xa2,168),(2,6,0x63,105))


