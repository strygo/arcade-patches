"""Reconstruct complete reviewed ranking labels and eye-palette slot tables."""
import hashlib
import struct


def require(value, message):
    if not value:
        raise ValueError(message)


def construct(inputs, recipe):
    require(set(inputs) == set(recipe['inputs']) == {'arcade'}, 'Whole native ranking source inventory')
    raw = inputs['arcade'];pin = recipe['inputs']['arcade']
    digest = lambda blob: hashlib.sha256(blob).hexdigest()
    require(len(raw) == pin['bytes'] == 0x400000 and digest(raw) == pin['sha256'], 'Whole original native program identity')
    require(recipe['region'] in ('us', 'jp'), 'Ranking display region')
    require([(r['address'], r['bytes']) for r in recipe['tables']] == [(0xf9e80, 272), (0xf9f90, 36)], 'Complete ranking table family census')
    require([r['rank'] for r in recipe['ordinal_corrections']] == ([21,22,23] if recipe['region']=='us' else []), 'Complete original ordinal correction family')
    original = raw;raw = bytearray(raw)
    for row in recipe['ordinal_corrections']:
        rank = row['rank'];at = 0xb4a22+(rank-1)*8+4;donor = 0xb4a22+(rank%10-1)*8+4
        suffix = {1:'st',2:'nd',3:'rd'}[rank%10];text = str(rank)+suffix
        require(row['decision']=={'before':str(rank)+'th','after':text,'text_sha256':digest(text.encode())}, 'Original approved ordinal wording differs')
        require(struct.unpack_from('>H',raw,at)[0]==0x33a and struct.unpack_from('>H',raw,donor)[0]==row['new'], 'Original ordinal preimage or donor differs')
        raw[at:at+2]=raw[donor:donor+2]
    writes = [];proof = []
    for table in recipe['tables']:
        result = bytearray();copied = 0
        require(digest(b'\xff' * table['bytes']) == table['before_sha256'], 'Original blank ranking reservation identity')
        for segment in table['segments']:
            if 'copy' in segment:
                at, size = segment['copy'], segment['bytes']
                require(type(at) is int and type(size) is int and 0 <= at < at+size <= len(raw), 'Complete ranking source slice bounds')
                source = raw[at:at+size]
                require(digest(original[at:at+size]) == segment['sha256'], 'Complete ranking source table identity')
                result.extend(source);copied += size
            else:
                require(set(segment) == {'authored_hex'}, 'Unknown ranking segment operation')
                result.extend(bytes.fromhex(segment['authored_hex']))
        require(len(result) == table['bytes'] and digest(result) == table['after_sha256'], 'Whole reviewed ranking table identity')
        writes.append((table['address'], bytes(result)))
        proof.append({'address':table['address'], 'bytes':len(result), 'original_source_bytes':copied,
                      'authored_appendage_bytes':len(result)-copied, 'sha256':digest(result)})
    return writes, {'bytes':sum(len(blob) for _,blob in writes), 'access_view':'raw-main-data', 'complete_tables':proof}
