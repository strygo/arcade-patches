"""Pinned original program conversion functions; no checkout dependency."""
from __future__ import annotations


REGIONS = {
    "us": {"index": 1, "name": "STREET FIGHTER ALPHA3 UPPER",
           "date": "060613", "country": "U S A", "country_x": 0x15},
    "jp": {"index": 0, "name": "STREET FIGHTER ZERO3 UPPER",
           "date": "060525", "country": "J A P A N", "country_x": 0x13},
}


def text_stream(region):
    spec = REGIONS[region]
    return (bytes([11, 0x24, 1]) + spec["name"].encode("ascii")
            + bytes([0x7f, 0x12, 0x30, 1]) + " ".join(spec["date"]).encode("ascii")
            + bytes([0x7f, spec["country_x"], 0x3c, 1])
            + spec["country"].encode("ascii") + b"\0")


