"""Pinned original program conversion functions; no checkout dependency."""
from __future__ import annotations


SLOTS = (
    {'id':23, 'name':'Evil Ryu', 'cell':[6,2], 'source_record':28, 'source_code':0x3470},
    {'id':32, 'name':'Guile', 'cell':[1,1], 'source_record':29, 'source_code':0x3472},
    {'id':33, 'name':'Fei Long', 'cell':[5,1], 'source_record':30, 'source_code':0x3474},
    {'id':34, 'name':'Dee Jay', 'cell':[0,2], 'source_record':31, 'source_code':0x3476},
    {'id':35, 'name':'T. Hawk', 'cell':[1,5], 'source_record':32, 'source_code':0x3490},
)


TILE_FIRST, TILE_COUNT = 0x3f900, 64


def require(ok, message):
    if not ok: raise ValueError(message)


