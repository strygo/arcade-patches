"""Complete USA resident quote structural tables after text payload erasure."""
import struct
from public_kit_graphics import require

COMMON=tuple(n for n in range(32)if n not in (18,19,20,21,23,30,31))
PROMOTED=(21,30,31)


def construct(recipe):
    require(recipe['region']=='us','Retained resident directory region')
    require([r['owner']for r in recipe['pools']]==list((*COMMON,*PROMOTED)),'Complete resident owner domain')
    writes=[];addresses={};cursor=0x3f4080;count=0
    for row in recipe['pools']:
        owner=row['owner'];sizes=row['record_bytes'];expected=3 if owner in COMMON else 36
        require(len(sizes)==expected and all(isinstance(n,int)and 2<=n<=512 for n in sizes),'Complete resident allocated record domain')
        offsets=[];offset=2*(len(sizes)+1)
        for size in sizes:offsets.append(offset);offset+=(size+1)&~1
        addresses[owner]=cursor;writes.append((cursor,struct.pack('>'+str(len(offsets)+1)+'H',*offsets,0)))
        cursor+=offset;count+=len(sizes)
    aliases=recipe['owner_aliases'];require(len(aliases)==32 and all(a in addresses for a in aliases),'Complete resident owner aliases')
    require(all(aliases[n]==n for n in addresses),'Resident primary owner identity')
    require(count==183 and cursor<0x3f6000,'Resident original allocation extent')
    writes.append((0x3f4000,struct.pack('>32I',*(addresses[a]for a in aliases))))
    output=[]
    for at,blob in sorted(writes):
        value=bytearray(blob)
        for start,size in recipe['erase_spans']:
            require(size>0,'Authored text erase extent')
            lo=max(at,start);hi=min(at+len(value),start+size)
            if lo<hi:value[lo-at:hi-at]=b'\xff'*(hi-lo)
        output.append((at,bytes(value)))
    return output,{'pools':len(addresses),'records':count,'owner_directory_entries':32,'allocated_end':hex(cursor),'bytes':sum(len(v)for _,v in output)}
