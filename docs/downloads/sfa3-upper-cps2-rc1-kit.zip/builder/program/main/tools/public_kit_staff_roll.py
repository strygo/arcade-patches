"""Serialize the complete approved staff streams and their opcode-view roots."""
import hashlib
import struct
from functools import lru_cache
from cps2_crypt import decrypt_rom, decode_key
from cps2_encrypt import encrypt_word
from cps2_code_guard import require_code_spans

START, SPLIT, END, ROOT = 0xb30b4, 0xb3671, 0xb382e, 0xb3004
ORIGINAL_ROOTS = (START+4, SPLIT+4, START, SPLIT)


def require(ok, message):
    if not ok: raise ValueError(message)


def sha(blob):
    return hashlib.sha256(blob).hexdigest()


@lru_cache(maxsize=1)
def original_opcodes(prefix, key):
    return decrypt_rom(prefix,key)[0]


def rows(blob):
    end=blob.find(b'\0')
    require(end>0 and blob[end-1]==127 and not any(blob[end:]), 'Complete staff terminator/padding')
    require(all(32<=b<=127 or b==0xa6 for b in blob[:end]), 'Original staff byte grammar')
    result=blob[:end].split(b'\x7f')
    require(len(result)==208 and result[-1]==b'', 'Complete staff row domain')
    return result


def pack(values, size):
    blob=b'\x7f'.join(values)+b'\0'
    require(len(blob)<=size, 'Complete staff allocation overflow')
    return blob+bytes(size-len(blob))


def streams(raw, recipe):
    names, roles=rows(raw[START:SPLIT]), rows(raw[SPLIT:END])
    require(all(not r for r in names[:16]+roles[:16]) and roles[16]==b'Producer', 'Original staff insertion budget')
    require([sum(bool(r.strip()) for r in a) for a in (names,roles)]==[110,17], 'Original full staff content domain')
    require(roles[40]==b'Programer', 'Original approved spelling preimage')
    for name,blob in (('names',raw[START:SPLIT]),('roles',raw[SPLIT:END])):
        require(sha(blob)==recipe['original_streams'][name], 'Whole original staff stream '+name)
    if recipe['region']=='us':
        # P004 staff-only identity, then the approved P011 role corrections.
        names[13]=b'STEVE GORDON';roles[12]=b'RESTORATION'  # Backport by: Steve Gordon
        roles[12]=b'Restoration';roles[40]=b'Programmer'
        before=pack(names,SPLIT-START)+pack(roles,END-SPLIT)
        require(sha(before)==recipe['restoration_staff_sha256'], 'Complete P011 staff predecessor')
        names[13]=b'';names[14]=b'STEVE GORDON';roles[13]=b'CPS-2 Backport'  # Backport by: Steve Gordon
        first=b'\x7f'.join(names[4:])+b'\0';second=b'\x7f'.join(roles[4:])+b'\0'
        require(len(first+second)<=END-START, 'Joint USA staff allocation')
        result=first+second+bytes(END-START-len(first+second))
        root=(START,START+len(first),START,START+len(first))
    else:
        names[13]=b'STEVE GORDON';roles[12]=b'CPS-2 Backport'  # Backport by: Steve Gordon
        require(sha(pack(roles,END-SPLIT))==recipe['jp_before_spelling_sha256'], 'Complete Upper JP roles predecessor')
        roles[40]=b'Programmer'
        result=pack(names,SPLIT-START)+pack(roles,END-SPLIT);root=ORIGINAL_ROOTS
    return result,root


def project(inputs, recipe):
    require(set(inputs)==set(recipe['inputs'])=={'arcade','key'}, 'Complete staff original inputs')
    require(recipe['region'] in ('us','jp') and recipe['source_region']=='jp', 'Explicit inherited canonical JP staff source')
    require(recipe['views']=={'streams':'raw-data','roots':'opcode-pc-relative-table'}, 'Staff access views')
    for name,blob in inputs.items():
        pin=recipe['inputs'][name]
        require(len(blob)==pin['bytes'] and sha(blob)==pin['sha256'], 'Original staff input '+name)
    raw,key=inputs['arcade'],inputs['key']
    require(len(raw)==0x400000 and len(key)==20, 'Original staff source extents')
    result,root=streams(raw,recipe)
    ops=original_opcodes(raw[:START],key)
    require(struct.unpack_from('>4I',ops,ROOT)==ORIGINAL_ROOTS, 'Original four PC-relative staff roots')
    require(set(recipe['readers'])=={'credits_actor','credits_horizontal_create','credits_vertical_create','credit_byte_reader'}, 'Complete staff reader inventory')
    for name,row in recipe['readers'].items():
        at=int(row['start'],0);size=row['bytes']
        require(sha(ops[at:at+size])==row['opcode_sha256'], 'Original complete staff reader '+name)
    require(sha(ops[ROOT-32:ROOT])==recipe['root_reader_sha256'], 'Original whole32-byte PC-relative root witness')
    require_code_spans([{'name':'staff_pc_relative_roots','start':ROOT,'size':16}],key=key)
    master,lo,hi,_=decode_key(key);plain=struct.pack('>4I',*root)
    cipher=b''.join(encrypt_word(int.from_bytes(plain[i:i+2],'big'),(ROOT+i)//2,master,lo,hi).to_bytes(2,'big') for i in range(0,16,2))
    return [(START,result),(ROOT,cipher)],{'bytes':len(result)+len(cipher),'stream_bytes':len(result),'encrypted_root_bytes':len(cipher),'stream_sha256':sha(result),'root_cipher_sha256':sha(cipher),'source_region':'jp','views':recipe['views'],'original_rows':207,'final_rows':203 if recipe['region']=='us' else 207}


def construct(inputs, recipe):
    writes,report=project(inputs,recipe)
    require(report['stream_sha256']==recipe['stream_sha256'], 'Complete final authored staff streams')
    require(report['root_cipher_sha256']==recipe['root_cipher_sha256'], 'Whole final encrypted staff root table')
    return writes,report


def main():
    import argparse,json
    from pathlib import Path
    p=argparse.ArgumentParser(description=__doc__)
    for name in ('pools','recipe','out'):p.add_argument('--'+name,type=Path,required=True)
    a=p.parse_args();recipe=json.loads(a.recipe.read_text())
    packed=b''.join((a.pools/('arcade-jp-'+n)).read_bytes() for n in ('sz3j.03c','sz3j.04c','sz3.05c','sz3.06c','sz3.07c','sz3.08c','sz3.09c','sz3.10b'))
    raw=bytearray(packed);raw[::2]=packed[1::2];raw[1::2]=packed[::2]
    writes,report=construct({'arcade':bytes(raw),'key':(a.pools/'arcade-jp-sfz3j.key').read_bytes()},recipe)
    a.out.mkdir();result=bytearray(0x400000);mask=bytearray(len(result))
    for at,blob in writes:result[at:at+len(blob)]=blob;mask[at:at+len(blob)]=b'\1'*len(blob)
    (a.out/'main.bin').write_bytes(result);(a.out/'main.mask').write_bytes(mask)
    (a.out/'report.json').write_text(json.dumps(report,indent=2)+'\n')


if __name__=='__main__':main()
