"""Pinned original program conversion functions; no checkout dependency."""
from __future__ import annotations
from build_select_pending import require
from datetime import datetime
import build_boot_identity as boot
import re

EDITION = (0x14, 0x54, 'BACKPORT')


DATE = (0x12, 0x60)


def date_value(value):
    require(isinstance(value, str) and re.fullmatch('[0-9]{6}', value),
        'Explicit YYMMDD game-build date required')
    datetime.strptime('20'+value, '%Y%m%d')
    return value


def stream(display, date):
    date_value(date)
    return (boot.text_stream(display)[:-1] + bytes((0x7f, *EDITION[:2], 1)) +
        EDITION[2].encode('ascii') + bytes((0x7f, *DATE, 1)) +
        ' '.join(date).encode('ascii') + b'\0')


