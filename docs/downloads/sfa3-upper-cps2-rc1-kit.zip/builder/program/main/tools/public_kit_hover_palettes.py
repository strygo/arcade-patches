"""Complete original PS2 character-select head palette family and native directory."""
import hashlib,struct
from public_kit_graphics import require

OWNERS=(21,23,30,31,32,33,34,35,36,37)
ROOT=0x3d6010


def construct(native,recipe):
    require(recipe['schema']==1 and recipe['region'] in ('us','jp'),'Hover palette recipe')
    require(hashlib.sha256(native).hexdigest()==recipe['native_sha256'],'Original regional PS2 comp2 identity')
    source=0x11a4a0 if recipe['region']=='us' else 0x11f820
    require(set(recipe['allocations'])==set(map(str,OWNERS)),'Complete hover palette owner domain')
    directory=bytearray(76);writes=[];ranges=[]
    for owner in OWNERS:
        at=source+struct.unpack_from('<H',native,source+owner*2)[0]
        require(0<=at<=len(native)-768,'Original full hover palette bounds')
        dest=recipe['allocations'][str(owner)]
        require(ROOT+76<=dest<=0x3e0000-768 and 0<dest-ROOT<32768 and dest%2==0,'Native hover palette allocation')
        require(all(dest+768<=a or dest>=b for a,b in ranges),'Hover palette allocations overlap');ranges.append((dest,dest+768))
        struct.pack_into('>H',directory,owner*2,dest-ROOT)
        writes.append((dest,struct.pack('>384H',*struct.unpack_from('<384H',native,at))))
    return [(ROOT,bytes(directory)),*writes],{'directory_slots':38,'original_complete_arrays':10,'colors_per_array':384,'bytes':7756}


def main():
    import argparse,json
    from pathlib import Path
    p=argparse.ArgumentParser(description=__doc__)
    for n in ('recipe','native','outdir'):p.add_argument('--'+n,type=Path,required=True)
    a=p.parse_args();writes,report=construct(a.native.read_bytes(),json.loads(a.recipe.read_text()));data=bytearray(0x400000);mask=bytearray(len(data))
    for at,blob in writes:data[at:at+len(blob)]=blob;mask[at:at+len(blob)]=b'\1'*len(blob)
    (a.outdir/'result.bin').write_bytes(data);(a.outdir/'result.mask').write_bytes(mask);print(json.dumps(report))


if __name__=='__main__':main()
