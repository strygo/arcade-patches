"""Complete retained Japanese hover-name cel arena in the English display."""
import hashlib
from public_kit_graphics import require
import public_kit_hover_objects as hover

START=0x3d605c
END=0x3d81d8


def construct(inputs,recipe,jp_pixels):
    require(recipe['region']=='us' and recipe['source_region']=='jp','Explicit inherited Japanese hover producer')
    require(recipe['start']==START and recipe['bytes']==END-START==8572,'Complete original retained hover arena')
    source=recipe['original_recipe']
    require(source['region']=='jp' and source['groups']==['names','heads'],'Frozen complete Japanese hover recipe')
    # This deliberately validates the Japanese producer canvas. The retained
    # objects are not a claim about the later English display's live font.
    writes,proof=hover.construct(inputs,source,jp_pixels)
    result=bytearray(END-START);mask=bytearray(len(result));objects=0
    for at,blob in writes:
        if at>=END or at+len(blob)<=START:continue
        require(START<=at<at+len(blob)<=END,'Whole original object crosses retained arena')
        offset=at-START
        require(all(not mask[offset+i] or result[offset+i]==v for i,v in enumerate(blob)),'Original hover aliases disagree')
        result[offset:offset+len(blob)]=blob;mask[offset:offset+len(blob)]=b'\1'*len(blob);objects+=1
    require(all(mask),'Incomplete retained arena source coverage')
    blob=bytes(result)
    require(hashlib.sha256(blob).hexdigest()==recipe['arena_sha256'],'Whole inherited arena identity')
    return [(START,blob)],{'bytes':len(blob),'source_region':'jp','destination_region':'us','source_objects_checked':proof,'serialized_objects':objects,'sha256':hashlib.sha256(blob).hexdigest(),'artwork_view':'Original Japanese producer canvas; no English live-font equivalence asserted'}
