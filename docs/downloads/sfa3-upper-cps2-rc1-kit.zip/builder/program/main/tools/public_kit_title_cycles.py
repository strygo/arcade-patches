"""Clone complete original title palette scripts with reviewed Naomi routing."""
import hashlib,struct
from public_kit_graphics import require

ROOTS=(0xa239c,0xa23c0,0xa24c4)
START=0x3cc618


def construct(native,recipe):
    require(recipe['schema']==1 and hashlib.sha256(native).hexdigest()==recipe['native_sha256'],'Original title script identity')
    def read(at,n):
        require(0<=at<=len(native)-n,'Original title script bounds');return native[at:at+n]
    source_roots=tuple(0xa22e4+v for v in struct.unpack('>4h',read(0xa22e4+4*8,8)))
    require(source_roots==(*ROOTS,ROOTS[-1]),'Original complete title set4 directory')
    frames={};pending=list(source_roots);lists={}
    while pending:
        at=pending.pop()
        if at in frames:continue
        require(len(frames)<64,'Unbounded original title graph')
        h=read(at,8);require(h[0]>0 and h[1] in (0,64,128) and h[2:4]==b'\0\0','Unknown original title frame')
        pointer=struct.unpack_from('>I',h,4)[0];rows=[]
        for index in range(32):
            dst,family,offset=struct.unpack('>3H',read(pointer+index*6,6))
            require(dst%32==0 and dst<0x1000 and family in (40,44,48,52),'Unknown original title palette row')
            terminal=offset&1
            if dst in (0x800,0x820):
                require(family==48,'Title scroll2 palette family');offset=0x960|terminal
            if dst==0xc00 and offset!=1:
                require(family==52 and offset in (0x221,0x241,0x261),'Original title backdrop ramp row')
                family=0x8000;offset=0xc00+offset-0x220
            rows.append((dst,family,offset))
            if terminal:break
        else:raise ValueError('Unterminated original title palette list')
        successor=int.from_bytes(read(at+8,4),'big') if h[1]&128 else None if h[1]&64 else at+8
        frames[at]=(h,successor);lists[at]=b''.join(struct.pack('>3H',*r) for r in rows)
        if successor is not None:pending.append(successor)
    require(len(frames)==22,'Complete original title frame count')
    cursor=START+8;mapping={}
    for at,(h,_) in sorted(frames.items()):mapping[at]=cursor;cursor+=12 if h[1]&128 else 8
    recipes={};pointers={};payload=bytearray()
    for at in sorted(frames):
        value=lists[at]
        if value not in recipes:recipes[value]=cursor+len(payload);payload.extend(value)
        pointers[at]=recipes[value]
    require(len(recipes)==9,'Complete projected title palette list census')
    output=bytearray(struct.pack('>4h',*[mapping[s]-START for s in (*ROOTS,ROOTS[-1])]))
    for at,(h,successor) in sorted(frames.items()):
        require(START+len(output)==mapping[at],'Title script contiguous allocation')
        output.extend(h[:4]+struct.pack('>I',pointers[at]))
        if h[1]&128:output.extend(struct.pack('>I',mapping[successor]))
        elif successor is not None:require(mapping[successor]==mapping[at]+8,'Implicit title successor placement')
    output.extend(payload);require(len(output)==592,'Complete title script extent')
    return [(START,bytes(output))],{'complete_frames':22,'complete_palette_lists':9,'root_entries':4,'bytes':592,'external_palette_bindings':{'black_scroll2':[48,0x960],'red_backdrop':[0x8000,0xc00,0xc20,0xc40]},'original_raw_data_view':True}


def main():
    import argparse,json
    from pathlib import Path
    p=argparse.ArgumentParser(description=__doc__)
    for n in ('recipe','native','outdir'):p.add_argument('--'+n,type=Path,required=True)
    a=p.parse_args();writes,report=construct(a.native.read_bytes(),json.loads(a.recipe.read_text()));data=bytearray(0x400000);mask=bytearray(len(data))
    for at,blob in writes:data[at:at+len(blob)]=blob;mask[at:at+len(blob)]=b'\1'*len(blob)
    (a.outdir/'result.bin').write_bytes(data);(a.outdir/'result.mask').write_bytes(mask);print(json.dumps(report))


if __name__=='__main__':main()
