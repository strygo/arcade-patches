"""Complete original story faces and four VS/story head directories."""
import hashlib,struct
from public_kit_graphics import require
from public_kit_hover_objects import cel,tiles_for

DIRECTORIES={23:0x3e4000,21:0x3e4100,30:0x3e4200,31:0x3e4300}

def original(comp2,region):
    base,root=(0x60ad00,0x69f00) if region=='us' else (0x60b080,0x6ae30)
    result={}
    for owner in sorted(DIRECTORIES):
        rows=[]
        for selector in range(32):
            at=root+struct.unpack_from('<H',comp2,root+selector*2)[0]+owner*8
            pointer=struct.unpack_from('<I',comp2,at+4)[0]-base
            require(0<=pointer<len(comp2)-6,'Original head cel bounds')
            rows.append((comp2[at:at+4],pointer,at))
        pointers={rows[s][1]for s in range(18,24)};require(len(pointers)==1,'Single original story face per owner')
        value=cel(comp2,pointers.pop(),'<',base);require(value['kind']==8 and value['total']>0,'Original story face grammar')
        result[owner]=(rows,list(tiles_for(value['commands'])))
    return result

def construct(inputs,recipe,pixels):
    require(recipe['schema']==1 and recipe['region'] in ('jp','us'),'Story face schema/region')
    for n,pin in recipe['inputs'].items():require(hashlib.sha256(inputs[n]).hexdigest()==pin,'Original story face identity '+n)
    require(hashlib.sha256(pixels).hexdigest()==recipe['pixels_sha256'],'Story face final graphics identity')
    sources=original(inputs['comp2'],recipe['region']);require(set(recipe['faces'])==set(map(str,DIRECTORIES)),'Complete story face binding census')
    data=bytearray();writes=[]
    for owner,(rows,commands) in sources.items():
        codes=recipe['faces'][str(owner)];require(len(codes)==len(commands),'Whole source story face tile census')
        xy=0x3e5000+len(data);data+=b''.join(struct.pack('>2h',x,y) for _,_,x,y in commands)
        pointer=0x3e5000+len(data);data+=struct.pack('>3HI',2,len(commands),len(commands)-1,xy)
        data+=b''.join(struct.pack('>2H',target,attr)for target,(_,attr,_,_)in zip(codes,commands))
        for target,(source,_,_,_)in zip(codes,commands):
            source+=0x1c00;target+=0x30000
            require(inputs['font'][source*128:(source+1)*128]==pixels[target*128:(target+1)*128] and (source+1)*128<=len(inputs['font']) and (target+1)*128<=len(pixels),'Complete original story face tile differs')
        directory=bytearray()
        for selector,(header,_,_)in enumerate(rows):
            dest=pointer if 18<=selector<24 else recipe['hover'][str(owner)][int(6<=selector<12)]
            directory+=header+struct.pack('>I',dest)
        require(len(directory)==256,'Whole head directory extent');writes.append((DIRECTORIES[owner],bytes(directory)))
    require(len(data)<=0x1000,'Story face allocation limit');writes.append((0x3e5000,bytes(data)))
    return writes,{'complete_directories':4,'directory_records':128,'complete_faces':4,'face_bytes':len(data),'bytes':1024+len(data)}

def main():
    import argparse,json
    from pathlib import Path
    p=argparse.ArgumentParser(description=__doc__)
    for n in ('recipe','inputs','pixels','outdir'):p.add_argument('--'+n,type=Path,required=True)
    a=p.parse_args();inputs={n:Path(v).read_bytes()for n,v in json.loads(a.inputs.read_text()).items()};writes,report=construct(inputs,json.loads(a.recipe.read_text()),a.pixels.read_bytes());data=bytearray(0x400000);mask=bytearray(len(data))
    for at,blob in writes:data[at:at+len(blob)]=blob;mask[at:at+len(blob)]=b'\1'*len(blob)
    (a.outdir/'result.bin').write_bytes(data);(a.outdir/'result.mask').write_bytes(mask);print(json.dumps(report))
if __name__=='__main__':main()
