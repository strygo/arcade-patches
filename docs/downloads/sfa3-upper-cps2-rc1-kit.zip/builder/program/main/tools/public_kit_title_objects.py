"""Complete PS2/Naomi title arrow resources from original media."""
import hashlib,struct
from public_kit_graphics import require


def construct(inputs,recipe,pixels):
    require(recipe['schema']==1 and recipe['region'] in ('us','jp'),'Unknown title object recipe')
    for name,sha in recipe['sources'].items():require(hashlib.sha256(inputs[name]).hexdigest()==sha,'Original title input differs: '+name)
    c2,coords,art,mask=(inputs[n] for n in ('comp2','coords','art','mask'))
    base=0x60b080 if recipe['region']=='jp' else 0x60ad00
    cel,palette=(6617878,7419424) if recipe['region']=='jp' else (6613094,7397152)
    off=cel-base
    require(struct.unpack_from('<3H',c2,off)==(2,48,15),'Complete title cel grammar differs')
    pointer=(off+9)&~3;xy=struct.unpack_from('<I',c2,pointer)[0]-0xb04000
    require(0<=xy<=len(coords)-64,'Title coordinate extent')
    objects=[];sources=[]
    for i in range(16):
        x,y=struct.unpack_from('<2h',coords,xy+i*4);code,attr=struct.unpack_from('<2H',c2,pointer+4+i*4)
        require(attr&255==15,'Title source attribute')
        for dy in range(((attr>>12)&15)+1):
            for dx in range(((attr>>8)&15)+1):
                source=(code&~15)+((code+dx)&15)+16*dy;native=0x3f8c0+len(objects)
                require(source<len(mask) and mask[source] and len(art[source*128:(source+1)*128])==128,'Missing complete title tile')
                require(art[source*128:(source+1)*128]==pixels[native*128:(native+1)*128],'Complete title artwork differs')
                objects.append((0xe000|((280+x+16*dx)&1023),0x6000|((54+y+16*dy)&1023),native&65535,15));sources.append(source)
    require(len(objects)==48,'Complete title object extent')
    ps2_palette=struct.pack('>16H',*[v|0xf000 for v in struct.unpack_from('<16H',c2,palette-base)])
    naomi=inputs['naomi'];colors=struct.unpack_from('<16H',naomi,0x11e424)
    npal=struct.pack('>16H',*[(0xf000|((v>>11)&15)<<8|((v>>6)&15)<<4|((v>>1)&15)) for v in colors[1:]],0xf000)
    shifted=[(x,0x6000|((y-6)&1023),tile,attr) for x,y,tile,attr in objects]
    shifted.append((0xe000|400,0x6000|160,0xff7f,15))
    expected=inputs['title'][282*128:283*128]
    require(len(expected)==128,'Original complete title registration tile extent')
    require(expected==pixels[0x3ff7f*128:0x3ff80*128],'Complete Naomi registered-mark artwork differs')
    pack=lambda rows:b''.join(struct.pack('>4H',*row) for row in rows)
    writes=[(0x3cc200,pack(objects)+ps2_palette),(0x3cc400,npal+pack(shifted))]
    return writes,{'objects':{'ps2':48,'naomi':49},'complete_palettes':2,'source_tiles_checked':49,'source_codes':sources,'coordinates_address':xy,'source_palette':palette}


def main():
    import argparse,json
    from pathlib import Path
    p=argparse.ArgumentParser(description=__doc__)
    for n in ('recipe','inputs','pixels','outdir'):p.add_argument('--'+n,type=Path,required=True)
    a=p.parse_args();recipe=json.loads(a.recipe.read_text());paths=json.loads(a.inputs.read_text())
    writes,report=construct({n:Path(path).read_bytes() for n,path in paths.items()},recipe,a.pixels.read_bytes())
    data=bytearray(0x400000);mask=bytearray(len(data))
    for at,blob in writes:data[at:at+len(blob)]=blob;mask[at:at+len(blob)]=b'\1'*len(blob)
    (a.outdir/'result.bin').write_bytes(data);(a.outdir/'result.mask').write_bytes(mask)
    print(json.dumps(report))


if __name__=='__main__':main()
