"""Pinned original program conversion functions; no checkout dependency."""
from __future__ import annotations
from program_support import TRACK
import json

US_LAYOUT = {'base':0x60ad00, 'grid':0x112b0, 'pool':0x111d0,
             'random_ism':0x112f0, 'compact_records':0x357e3c,
             'compact_palette':0x1035a0, 'names':0x356df0,
             'heads':0x69f00, 'head_palettes':0x11a4a0}


def profile(region):
    if region not in ('us', 'jp'):
        raise ValueError('Unknown selection donor region')
    suffix = '' if region == 'us' else '_jp'
    pins = json.loads((TRACK/f'manifests/select_pending_sources{suffix}.json').read_text())
    title = json.loads((TRACK/'manifests/title_sources.json').read_text())['regions'][region]
    if pins['region'] != region or pins['iso'] != title['iso']:
        raise ValueError('Regional media pin disagreement')
    return {**pins, 'layout':pins.get('layout', US_LAYOUT),
            'disc_name':title['disc_name'], 'package_name':title['package_name'],
            'comp1_sha256':title['comp1_sha256'], 'comp2_sha256':title['comp2_sha256']}


