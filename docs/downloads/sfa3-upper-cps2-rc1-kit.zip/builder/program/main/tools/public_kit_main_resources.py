"""Reconstruct raw main-ROM frontend resources from original selected media."""
import argparse
import hashlib
import json
from pathlib import Path
import struct
import zlib
import public_kit_graphics_recipe as graphics
import public_kit_panels as panels
import public_kit_resident_palettes as resident_palettes
import public_kit_color_arena as color_arena
import public_kit_retained_font as retained_font
import public_kit_resident_quotes as resident_quotes
import public_kit_title_objects as title_objects
import public_kit_title_cycles as title_cycles
import public_kit_primary_palette_banks as primary_palette_banks
import public_kit_ranking_tables as ranking_tables
import public_kit_hover_palettes as hover_palettes
import public_kit_hover_objects as hover_objects
import public_kit_inherited_hover_arena as inherited_hover_arena
import public_kit_staff_roll as staff_roll
import public_kit_victory_objects as victory_objects
import public_kit_story_faces as story_faces
import public_kit_private_ending_pages as private_ending_pages
import public_kit_title_text as title_text
import public_kit_retained_resident_directories as retained_resident_directories
from public_kit_graphics import require


def construct(region,root,recipes):
    from select_regional_sources import profile
    import build_select_pending as select
    import build_select_random as random
    import upper_final_surfaces as boot
    catalog=json.loads((root/'pools.json').read_text())
    used=set()
    def read(name):
        require(not name.startswith('ps2-') or name.startswith('ps2-'+region+'-'),'Other regional disc requested')
        blob=(root/name).read_bytes();pin=catalog['pools'][name]
        require(len(blob)==pin['bytes'] and hashlib.sha256(blob).hexdigest()==pin['sha256'],'Original main resource identity differs: '+name)
        used.add(name)
        return blob
    recipe=json.loads(zlib.decompress((recipes/(region+'.graphics.json.zlib')).read_bytes()));sources={}
    for name in recipe['pools']:
        if name=='derived-us-stage-panels.bin':
            require(region=='us','English panels in another region')
            sources[name]=panels.from_pools(root,catalog,json.loads((recipes/'panels.json').read_text()))
        else:
            actual={'arcade-us-pixels.bin':'arcade-jp-pixels.bin','arcade-us-cloud-continuation.bin':'arcade-jp-cloud-continuation.bin'}.get(name,name)
            sources[name]=read(actual)
    pixels=graphics.apply(recipe,sources)
    c2=read('ps2-'+region+'-comp2.bin');font=read('ps2-'+region+'-font353.bin');layout=profile(region)['layout']
    coordinates=struct.unpack_from('<I',c2,layout['compact_records']-4)[0]-layout['base']
    require(0<=coordinates<len(c2)-37*4,'Original complete compact coordinate directory')
    def cell(record,native,canvas=None):
        canvas=pixels if canvas is None else canvas
        code,attr=struct.unpack_from('<2H',c2,layout['compact_records']+record*4)
        xy=struct.unpack_from('<2h',c2,coordinates+record*4)
        for dy in range(2):
            for dx in range(2):
                source=(code&~15)+((code+dx)&15)+16*dy;at=(source+0x1c00)*128
                expected=font[at:at+128];target=(native+dx+16*dy)*128
                require(len(expected)==128 and canvas[target:target+128]==expected,'Complete original compact sprite pixels differ')
        return code,attr,xy,(0xe000|((256+xy[0])&1023),0x6000|((128+xy[1])&1023),native&65535,attr)
    selected=[]
    for n,row in enumerate(select.SLOTS):
        code,attr,xy,record=cell(row['source_record'],select.TILE_FIRST+n*2);x,y=row['cell']
        require(code==row['source_code'] and attr>>8==0x11 and xy==(24*x-88,24*y-88),'Original added select record fields differ')
        selected.append(record)
    questions={}
    for index,expected_code,expected_attr,expected_xy in random.SOURCE_RECORDS:
        code,attr,xy,record=cell(index,random.FIRST+expected_code-0x34d0)
        require((code,attr,xy)==(expected_code,expected_attr,expected_xy),'Original question record fields differ')
        questions[((xy[0]+88)//24,(xy[1]+88)//24)]=record
    ordered=[questions[(x,y)] for x,y,_,_ in random.CELLS]
    changed=bytearray(pixels);changed[select.TILE_FIRST*128]^=1
    try:cell(select.SLOTS[0]['source_record'],select.TILE_FIRST,changed)
    except ValueError:pass
    else:raise ValueError('Changed complete select artwork accepted')
    del changed
    pack=lambda rows:b''.join(struct.pack('>4H',*row) for row in rows)
    writes=[(0x3c8580,boot.stream(region,'261027')),(0x3c9100,pack(selected)),(0x3c9700,pack(ordered))]
    names=['sz3j.03c','sz3j.04c']+[f'sz3.{n:02d}c' for n in range(5,10)]+['sz3.10b']
    packed=b''.join(read('arcade-jp-'+name) for name in names)
    native=bytearray(len(packed));native[::2]=packed[1::2];native[1::2]=packed[::2]
    load=lambda name:json.loads((recipes/(name+'.json')).read_text())
    output,palette_report=resident_palettes.construct(c2,native,load('resident_palettes')[region]);writes.extend(output)
    output,_=color_arena.construct(c2,native,load('color_arena')[region]);writes.extend(output)
    output,_=retained_font.construct(font,load('retained_font')[region],pixels[:32*1024**2],space='main');writes.extend(output)
    title_inputs={'comp2':c2,**{name:read('ps2-'+region+'-'+path) for name,path in
        [('coords','coords390.bin'),('art','entry351-s0.bin'),('mask','entry351-s0.mask')]},
        'naomi':read('naomi-program.bin'),'title':read('naomi-TITLE.PAC.bin')}
    output,_=title_objects.construct(title_inputs,load('title_objects')[region],pixels);writes.extend(output)
    output,_=title_cycles.construct(native,load('title_cycles')[region]);writes.extend(output)
    output,_=title_text.construct({'naomi':title_inputs['naomi']},load('title_text')[region]);writes.extend(output)
    output,_=primary_palette_banks.construct(c2,load('primary_palette_banks')[region]);writes.extend(output)
    output,ranking_report=ranking_tables.construct({'arcade':native},load('ranking_tables')[region]);writes.extend(output)
    lower_raw_ranking={(at,len(blob))for at,blob in output}
    require(lower_raw_ranking=={(0xf9e80,272),(0xf9f90,36)} and ranking_report['access_view']=='raw-main-data','Two complete declared raw ranking tables')
    output,_=hover_palettes.construct(c2,load('hover_palettes')[region]);writes.extend(output)
    output,_=hover_objects.construct({'comp2':c2,'font':font},load('hover_objects')[region],pixels);writes.extend(output)
    lower_raw_cels={(at,len(blob)) for at,blob in output if at<0x100000}
    inherited_sources=[]
    if region=='us':
        jp_recipe=json.loads(zlib.decompress((recipes/'jp.graphics.json.zlib').read_bytes()))
        allowed=set(jp_recipe['pools'])|{'ps2-jp-comp2.bin','ps2-jp-font353.bin'}
        def inherited_read(name):
            require(name in allowed and (not name.startswith('ps2-') or name.startswith('ps2-jp-')),'Undeclared inherited Japanese source')
            blob=(root/name).read_bytes();pin=catalog['pools'][name]
            require(len(blob)==pin['bytes'] and hashlib.sha256(blob).hexdigest()==pin['sha256'],'Inherited source identity differs: '+name)
            used.add(name);inherited_sources.append(name)
            return blob
        jp_pixels=graphics.apply(jp_recipe,{name:inherited_read(name) for name in jp_recipe['pools']})
        output,_=inherited_hover_arena.construct({'comp2':inherited_read('ps2-jp-comp2.bin'),'font':inherited_read('ps2-jp-font353.bin')},load('inherited_hover_arena')['us'],jp_pixels);writes.extend(output)
        del jp_pixels
    output,_=story_faces.construct({'comp2':c2,'font':font},load('story_faces')[region],pixels);writes.extend(output)
    output,_=private_ending_pages.construct(native,load('private_ending_pages')[region],read('arcade-jp-pixels.bin'),pixels);writes.extend(output)
    output,_=victory_objects.construct({'comp2':c2,'font':font,'native':native},load('victory_objects')[region],pixels);writes.extend(output)
    if region=='us':
        output,_=retained_resident_directories.construct(load('retained_resident_directories')[region]);writes.extend(output)
    if region=='jp':
        output,_=resident_quotes.construct({'comp2':c2,'font':font,'arcade':native},load('resident_quotes')[region],pixels[:32*1024**2]);writes.extend(output)
    staff_output,staff_report=staff_roll.construct({'arcade':bytes(native),'key':read('arcade-jp-sfz3j.key')},load('staff_roll')[region])
    staff_intervals={(at,len(blob))for at,blob in staff_output}
    require(staff_intervals=={(0xb30b4,1914),(0xb3004,16)} and staff_report['views']=={'streams':'raw-data','roots':'opcode-pc-relative-table'},'Exact dual-view staff resource intervals')
    require(all(at>=0x100000 or (at,len(blob))in(lower_raw_cels|lower_raw_ranking) for at,blob in writes),'Existing raw resource lower-address guard')
    writes.extend(staff_output)
    data=bytearray(0x400000);mask=bytearray(len(data))
    for at,blob in writes:
        require((at>=0x100000 or (at,len(blob)) in (lower_raw_cels|lower_raw_ranking|staff_intervals)) and at>=0 and at+len(blob)<=len(data),'Raw frontend resource extent')
        require(all(not mask[at+i] or data[at+i]==value for i,value in enumerate(blob)),'Conflicting main resource outputs')
        data[at:at+len(blob)]=blob;mask[at:at+len(blob)]=b'\1'*len(blob)
    return bytes(data),bytes(mask),{'staff_roll':staff_report,'complete_added_select_records':len(selected),'complete_random_records':len(ordered),'source_tiles_checked':4*(len(selected)+len(random.SOURCE_RECORDS)),'preserved_game_date':'261027','negative_controls':{'rejected':['changed-complete-select-artwork']},'resident_palette_arrays':len(palette_report),'lower_raw_hover_cels':[{'address':at,'bytes':size} for at,size in sorted(lower_raw_cels)],'lower_raw_ranking_tables':[{'address':at,'bytes':size}for at,size in sorted(lower_raw_ranking)],'direct_source_files':sorted(used),'other_ps2_region_reads':any(name.startswith('ps2-')for name in inherited_sources),'inherited_hover_source_files':sorted(set(inherited_sources))}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--region',choices=('us','jp'),required=True)
    for n in ('pools','recipes','out'):parser.add_argument('--'+n,type=Path,required=True)
    args=parser.parse_args();data,mask,proof=construct(args.region,args.pools,args.recipes)
    args.out.mkdir();(args.out/'main.bin').write_bytes(data);(args.out/'main.mask').write_bytes(mask)
    report={**proof,'bytes':sum(mask),'main_sha256':hashlib.sha256(data).hexdigest(),'mask_sha256':hashlib.sha256(mask).hexdigest()}
    (args.out/'compiled.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')


if __name__=='__main__':main()
