"""Original title wording with reviewed native layout and copyright glyph token."""
import hashlib,struct
from public_kit_graphics import require

START=0x3cc5a8
LAYOUT=((0xe0c8,0x20ce),(0xe0b8,0x20ce),(0xe0d8,0x20da),(0xe044,0x20e6))


def construct(inputs,recipe):
    require(recipe['schema']==1 and len(recipe['records'])==4,'Complete title text family')
    for name,pin in recipe['inputs'].items():require(hashlib.sha256(inputs[name]).hexdigest()==pin,'Original title wording identity')
    data=bytearray()
    for index,row in enumerate(recipe['records']):
        source=inputs[row['input']];at=row['offset'];size=row['bytes']
        require(0<=at<len(source)-size and source[at+size]==0 and 0<size<=64,'Original title string bounds')
        text=source[at:at+size];require(all(32<=n<=126 for n in text),'Original title ASCII wording')
        require(row['copyright_token']==(index==3),'Title copyright layout domain')
        if index==3:text=b'@'+text
        data.extend(struct.pack('>2H',*LAYOUT[index])+text+b'\0')
        if len(data)%2:data.append(0)
    require(len(data)==112,'Complete title text extent')
    return [(START,bytes(data))],{'complete_strings':4,'bytes':112,'wording_from_original_media':True}


def main():
    import argparse,json
    from pathlib import Path
    p=argparse.ArgumentParser(description=__doc__)
    for n in ('recipe','inputs','outdir'):p.add_argument('--'+n,type=Path,required=True)
    a=p.parse_args();inputs={n:Path(v).read_bytes() for n,v in json.loads(a.inputs.read_text()).items()};writes,report=construct(inputs,json.loads(a.recipe.read_text()));data=bytearray(0x400000);mask=bytearray(len(data))
    for at,blob in writes:data[at:at+len(blob)]=blob;mask[at:at+len(blob)]=b'\1'*len(blob)
    (a.outdir/'result.bin').write_bytes(data);(a.outdir/'result.mask').write_bytes(mask);print(json.dumps(report))


if __name__=='__main__':main()
