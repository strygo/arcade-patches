import hashlib

def digest(data):
    return hashlib.sha256(data).hexdigest()

def require(ok, message):
    if not ok:
        raise ValueError(message)

from pathlib import Path
TRACK=Path(__file__).resolve().parent
REPO=TRACK/"native"
