"""Complete original alternate-costume and Guile primary six-color banks."""
import hashlib
from public_kit_graphics import require
from public_kit_palettes import catalog

ALLOCATIONS={'18':0x3df000,'20':0x3df3c0,'32':0x3fa000}


def construct(native,recipe):
    require(recipe['schema']==1 and recipe['region']in ('us','jp'),'Primary palette recipe')
    require(hashlib.sha256(native).hexdigest()==recipe['native_sha256'],'Primary palette original source identity')
    require(recipe['allocations']==ALLOCATIONS,'Complete original primary-bank family layout')
    arrays=catalog(native,recipe['region']);writes=[]
    for owner,at in ALLOCATIONS.items():
        blob=arrays['primary:'+owner][1]
        require(len(blob)==960,'Six complete five-bank primary color choices')
        writes.append((at,blob))
    return writes,{'bytes':2880,'owners':[18,20,32],'choices_per_owner':6,'banks_per_choice':5,'colors_per_bank':16}


def main():
    import argparse,json
    from pathlib import Path
    p=argparse.ArgumentParser(description=__doc__)
    for n in ('recipe','native','outdir'):p.add_argument('--'+n,type=Path,required=True)
    a=p.parse_args();writes,report=construct(a.native.read_bytes(),json.loads(a.recipe.read_text()));data=bytearray(0x400000);mask=bytearray(len(data))
    for at,blob in writes:data[at:at+len(blob)]=blob;mask[at:at+len(blob)]=b'\1'*len(blob)
    (a.outdir/'result.bin').write_bytes(data);(a.outdir/'result.mask').write_bytes(mask);print(json.dumps(report))


if __name__=='__main__':main()
