"""Complete inherited private ending pages from original arcade page resources."""
import hashlib,struct
from public_kit_graphics import require

S2=0x391014
PAGES=((146,116,16),(147,117,8),(148,111,16),(149,112,8),(150,125,16),(151,126,8),(152,119,16),(153,120,8))


def unpack(blob):
    require(len(blob)==128,'Guard tile extent')
    return [[(blob[y*8+x//2]>>(4*(x%2)))&15 for x in range(16)] for y in range(16)]


def pack(rows):
    return bytes(row[x]|row[x+1]<<4 for row in rows for x in range(0,16,2))


def reflected(blob,flip):
    rows=unpack(blob)
    if flip&32:rows=[r[::-1] for r in rows]
    if flip&64:rows=rows[::-1]
    return pack(rows)


def reviewed_packed(blob):
    # Original review uses FBNeo pens (inverted), most-significant nibble
    # first in each little-endian eight-pixel word.
    out=bytearray()
    for row in unpack(blob):
        for start in (0,8):
            word=0
            for pen in row[start:start+8]:word=(word<<4)|(15^pen)
            out.extend(struct.pack('<I',word))
    return bytes(out)


def guards(native,pixels):
    sky=[(0xcf00+x,1) for x in range(9)]+[(0x6c1e,0)]*2+[(0xcf09,0),(0xcf09,32)]+[(0x6c1e,0)]*2+[(0xcf08-x,33) for x in range(9)]
    source=[pixels[(0x10000+tile)*128:(0x10001+tile)*128] for tile,attr in sky]
    require(hashlib.sha256(b''.join(reviewed_packed(b) for b in source)).hexdigest()=='e59f9ee4d98b87c7e75d3a8aec8a0c0a56d8be7aa06bb7619a49915b149df1db','Reviewed original sky strip differs')
    cells=[unpack(reflected(blob,attr&96)) for blob,(_,attr) in zip(source,sky)]
    strip=[[v for cell in cells for v in cell[y]] for y in range(16)]
    rows=[]
    for y in range(16):
        depth=15-y;row=[]
        for x in range(384):
            shift=2*(depth+1);xx=x-shift if x<144 else x+shift if x>=240 else x
            xx=-xx-1 if xx<0 else 767-xx if xx>=384 else xx
            require(sky[x//16][1]&31==sky[xx//16][1]&31,'Guard palette boundary')
            row.append(strip[depth][xx])
        rows.append(row)
    result={str(0x1fe80+x//16):pack([row[x:x+16] for row in rows]) for x in range(0,384,16)}
    require(hashlib.sha256(b''.join(reviewed_packed(b) for b in result.values())).hexdigest()=='b716a890ded2b5c7df89047b30ce9fd72039f62e7d34e68a8751e0cc659a39a7','Reviewed complete inward cloud contours differ')
    for x in range(24):
        page,local=(119,x) if x<16 else (120,x-16);at=S2+page*768;cell=local*16+7
        physical=0x10000+((struct.unpack_from('>H',native,at+cell*2)[0]+0x6c00)&0xffff)
        result[str(0x1fea0+x)]=reflected(pixels[physical*128:(physical+1)*128],64)
    return result


def construct(native,recipe,original_pixels,pixels):
    require(len(native)==0x400000 and hashlib.sha256(native).hexdigest()==recipe['native_sha256'],'Original ending page identity')
    require(hashlib.sha256(original_pixels).hexdigest()==recipe['original_pixels_sha256'],'Original guard graphics identity')
    require(hashlib.sha256(pixels).hexdigest()==recipe['pixels_sha256'],'Final guard graphics identity')
    generated=guards(native,original_pixels)
    require(set(generated)==set(recipe['bindings']),'Complete private guard domain')
    for key,blob in generated.items():
        target,flip=recipe['bindings'][key];require(0x10000<=target<0x20000,'Private guard physical tile domain');require(flip in (0,32,64,96),'Guard flip grammar')
        require(reflected(pixels[target*128:(target+1)*128],flip)==blob,'Original authored guard tile differs '+key+' target='+hex(target)+' flip='+str(flip))
    writes=[]
    for new,old,width in PAGES:
        page=bytearray(native[S2+old*768:S2+(old+1)*768])
        for x in range(width):
            cell=x*16+(8 if new>=152 else 7)
            if new<148:
                column=x+(16 if new==147 else 0)
                tile=0xfe80+column
                # Original reviewed sky guard row: nine left-bank colors,
                # six transparent/interior colors, nine right-bank colors.
                attr=1 if column<9 or column>=15 else 0
            elif new>=152:
                tile=0xfea0+x+(16 if new==153 else 0);attr=page[512+x*16+7]
            else:tile=0x6c20;attr=0
            if str(0x10000+tile) in generated:
                physical,flip=recipe['bindings'][str(0x10000+tile)];tile=physical-0x10000;attr^=flip
            struct.pack_into('>H',page,2*cell,(tile-0x6c00)&0xffff);page[512+cell]=attr
        writes.append((S2+new*768,bytes(page)))
    return writes,{'complete_pages':8,'bytes':6144,'original_page_ids':[p[1] for p in PAGES]}


def main():
    import argparse,json
    from pathlib import Path
    p=argparse.ArgumentParser(description=__doc__)
    for n in ('native','recipe','original_pixels','pixels','outdir'):p.add_argument('--'+n,type=Path,required=True)
    a=p.parse_args();writes,report=construct(a.native.read_bytes(),json.loads(a.recipe.read_text()),a.original_pixels.read_bytes(),a.pixels.read_bytes());data=bytearray(0x400000);mask=bytearray(len(data))
    for at,blob in writes:data[at:at+len(blob)]=blob;mask[at:at+len(blob)]=b'\1'*len(blob)
    (a.outdir/'result.bin').write_bytes(data);(a.outdir/'result.mask').write_bytes(mask);print(json.dumps(report))


if __name__=='__main__':main()
