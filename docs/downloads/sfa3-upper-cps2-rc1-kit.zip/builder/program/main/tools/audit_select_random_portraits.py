"""Pinned original program conversion functions; no checkout dependency."""
from __future__ import annotations


SOURCE_RECORDS = ((33,0x34d0,0x110c,(-40,-88)),(34,0x34d0,0x110c,(8,56)),
                  (35,0x34d2,0x110a,(8,-88)),(36,0x34d2,0x110a,(-40,56)))


