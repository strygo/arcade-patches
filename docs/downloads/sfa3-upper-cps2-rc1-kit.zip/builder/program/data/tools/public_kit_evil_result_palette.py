"""Complete original six-choice Evil Ryu result palette and native controls."""
import hashlib,struct
from public_kit_graphics import require


def construct(inputs,recipe):
    require(set(inputs)==set(recipe['inputs'])=={'arcade','comp2'},'Complete result palette inputs')
    for name,pin in recipe['inputs'].items():
        require(len(inputs[name])==pin['bytes'] and hashlib.sha256(inputs[name]).hexdigest()==pin['sha256'],'Original result palette '+name)
    region=recipe['region'];require(region in ('us','jp'),'Result palette region')
    base=0x60b080 if region=='jp'else 0x60ad00;directory=0x126470 if region=='jp'else 0x1210f0
    source=inputs['comp2'];raw=inputs['arcade']
    def colors(owner):
        at=struct.unpack_from('<I',source,directory+owner*4)[0]-base
        require(0<=at<=len(source)-1536 and at%2==0,'Whole six-choice color array extent')
        return b''.join(source[n:n+2][::-1]for n in range(at,at+1536,2))
    for owner in (0,1):
        at=struct.unpack_from('>I',raw,0x351f14+owner*4)[0]
        require(colors(owner)==raw[at:at+1536],'Original common six-choice palette control')
    return [(0xbca000,colors(23))],{'owner':23,'choices':6,'words_per_choice':128,'native_control_owners':[0,1],'bytes':1536}
