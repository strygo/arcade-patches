"""Original eight-strip, six-choice PS2 ranking palette family projection.

The reviewed source pointer identifies the complete 1,536-byte family. Each
strip has three ISM pairs; the ranking conversion selects color zero from each
pair. The original forty-owner strip map binds all eight source slots.
"""
import hashlib,struct
from public_kit_graphics import require

OWNERS=[21,23,30,31,32,33,34,35]


def construct(inputs,recipe):
    require(set(inputs)==set(recipe['inputs'])=={'comp2'},'Ranking palette bank source inventory')
    data=inputs['comp2'];pin=recipe['inputs']['comp2']
    require(len(data)==pin['bytes']and hashlib.sha256(data).hexdigest()==pin['sha256'],'Original complete ranking palette source identity')
    region=recipe['region'];require(region in ('us','jp'),'Ranking palette source region')
    require(recipe['source_address']==0x73b5f0 and recipe['owners']==OWNERS,'Reviewed ranking palette source family binding')
    base=0x60ad00 if region=='us'else 0x60b080
    table=(0x617770 if region=='us'else 0x618860)-base
    mapping=data[table:table+40]
    require(len(mapping)==40 and [mapping.index(selector)for selector in range(0x39,0x41)]==OWNERS,'Original imported ranking strip owner domain')
    source=recipe['source_address']+(0x5700 if region=='jp'else 0)-base
    family=data[source:source+1536]
    require(len(family)==1536,'Complete eight-strip six-choice source extent')
    result=bytearray()
    for strip in range(8):
        for style in range(3):
            at=strip*192+style*64
            pair=family[at:at+64]
            require(len(pair)==64,'Complete two-color ranking source pair')
            result.extend(struct.pack('>16H',*struct.unpack('<16H',pair[:32])))
    return [(0xaa7a10,bytes(result))],{'bytes':768,'original_family_bytes':1536,'original_family_sha256':hashlib.sha256(family).hexdigest(),'strips':8,'choices_per_strip':6,'selected_choices':[0,2,4]}
