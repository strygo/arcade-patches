"""Reconstruct complete early 34/35-owner child-initializer directories."""
import hashlib
import struct


def require(value,message):
    if not value:raise ValueError(message)


def construct(inputs,recipe):
    digest=lambda b:hashlib.sha256(b).hexdigest()
    require(set(inputs)==set(recipe['inputs'])=={'arcade'},'Original source inventory')
    raw=inputs['arcade'];pin=recipe['inputs']['arcade']
    require(len(raw)==pin['bytes']==0x400000 and digest(raw)==pin['sha256'],'Whole original JP program')
    root=recipe['native_root'];require(type(root)is int and 0xd0000<=root<0xe4000-128,'Original initializer root')
    prefix=raw[root:root+128]
    require(digest(prefix)==recipe['native_sha256'],'Whole original 32-owner directory')
    values=list(struct.unpack('>32I',prefix))
    require(values[23]==0x277dc,'Original variant initializer preimage')
    values[23]=values[0]
    require(digest(struct.pack('>I',values[23]))==recipe['evil_write_sha256'],'Original guarded Evil initializer copy')
    added=recipe['added']
    require(set(added)=={'32','33','34'} and all(type(x)is int and 0<x<0x100000 and x%2==0 for x in added.values()),'Original complete added entrypoints')
    body=struct.pack('>34I',*(values+[added['32'],added['33']]))
    require(digest(body)==recipe['previous_34_rows_sha256'],'Complete unchanged Dee predecessor witness')
    require(recipe['tables']=={'34':0xb770a8,'35':0xbe24d0},'Complete early generations')
    writes=[(recipe['tables']['34'],body),(recipe['tables']['35'],body+struct.pack('>I',added['34']))]
    require([digest(b) for _,b in writes]==recipe['sha256'],'Complete emitted initializer hashes')
    return writes,{'bytes':276,'access_view':'expanded-data-big-endian-pointer32','generations':[34,35],'Evil_original_row0_copy':True}
