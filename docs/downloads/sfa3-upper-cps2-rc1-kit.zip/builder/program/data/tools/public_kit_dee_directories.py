"""Complete retained Dee family1, family2 and projectile directories.

Primary and normal directories have later Naomi amendments and remain outside
this source projection. Referenced frames and artwork require separate proof.
"""
import hashlib
import struct
from public_kit_actor import Data
from public_kit_graphics import require

GROUPS=(('family1',1,48,0xbdcd7a),('family2',2,64,0xbdcddc),('projectile',None,4,0xbdce9e))
ROOTS=(0xbdccf8,0xbdcd7a,0xbdcddc,0xbdce5e)


def source(data,recipe):
    roots=struct.unpack('<12I',data.read(data.u32(recipe['owner_table']+34*4),48))
    require(roots[:4]*3==roots and len(set(roots))==4,'Original Dee ISM aliases')
    projectile=data.u32((0x6131d0+(0x10f0 if recipe['region']=='jp' else 0))+37*4)
    targets=[data.root(projectile if index is None else roots[index])[1] for _,index,_,_ in GROUPS]
    require(tuple(map(len,targets))==(48,64,4),'Complete original Dee directory extents')
    return roots,targets


def construct(comp2,recipe):
    pin=recipe['input']
    require(len(comp2)==pin['bytes'] and hashlib.sha256(comp2).hexdigest()==pin['sha256'],'Original Dee source identity')
    data=Data(comp2,recipe['base'],b'',0xb04000);roots,targets=source(data,recipe)
    require([g['name'] for g in recipe['groups']]==[g[0] for g in GROUPS],'Complete retained Dee directory inventory')
    writes=[]
    for group,rows,(name,index,count,destination) in zip(recipe['groups'],targets,GROUPS):
        mapping=dict(group['frames'])
        admitted=rows[:44] if index==2 else rows
        require(len(mapping)==len(group['frames']) and set(mapping)==set(admitted),'Complete '+name+' source target inventory')
        require(all(0xbd0000<=at<ROOTS[0] for at in mapping.values()),'Dee frame allocation bounds')
        offsets=[mapping[t]-destination if i<len(admitted) else 0 for i,t in enumerate(rows)]
        require(all(-32768<=v<0 for v in offsets[:len(admitted)]),'Dee signed directory reach')
        writes.append((destination,struct.pack('>'+str(count+1)+'h',*offsets,0)))
    aliases=dict(zip(roots[:4],ROOTS))
    writes.extend([(0xbdcf28,struct.pack('>12I',*(aliases[root] for root in roots))),(0xbdcea8,bytes(128))])
    return writes,{'directories':[n for n,_,_,_ in GROUPS],'entries':[48,64,4],'admitted_entries':[48,44,4],'ISM_variants':3,
                   'closed_secondary_bytes':128,'bytes':sum(len(v) for _,v in writes),
                   'excluded_complete_directories':['primary','normal'],
                   'qualification':'Complete retained tables only; amended primary/normal, frame fields and artwork separate'}
