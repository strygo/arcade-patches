"""Complete original stage compact actors, cels, coordinates and root directories."""
import hashlib,struct
from public_kit_graphics import require
from public_kit_actor import Data
from public_kit_frame_resources import cel as emit_cel

FAMILIES={34:(0xc33f00,6,6,4),35:(0xdd3f00,27,15,10),37:(0xde3f00,46,45,21)}


def graph(comp1,data,region,owner):
    pc=0x2edc2c+(0x70 if region=='jp' else 0)-0x1f0040
    high,low=struct.unpack_from('<2I',comp1,pc)
    require(high>>26==15 and low>>26==9 and (high>>16)&31==(low>>21)&31==(low>>16)&31,'Original stage owner directory literal')
    value=low&65535;table=((high&65535)*65536+(value-65536 if value&32768 else value))&0xffffffff
    root=table+struct.unpack('<h',data.read(table+owner*2,2))[0];_,targets=data.root(root)
    frames={};pending=list(targets)
    while pending:
        at=pending.pop()
        if at in frames:continue
        require(at%4==0 and len(frames)<4096,'Original stage compact frame bounds')
        h=data.read(at,8);require(h[1] in (0,64,128),'Original compact stage flow flags')
        successor=data.u32(at+8) if h[1]&128 else None if h[1]&64 else at+8
        frames[at]=(h,data.u32(at+4),successor)
        if successor is not None:pending.append(successor)
    _,nf,nc,ns=FAMILIES[owner]
    require((len(frames),len({v[1] for v in frames.values()}),len(targets))==(nf,nc,ns),'Complete original stage family census')
    return root,targets,frames


def construct(inputs,recipe,pixels):
    require(recipe['schema']==1 and set(recipe['families'])==set(map(str,FAMILIES)),'Stage actor complete family inventory')
    for n,pin in recipe['inputs'].items():require(hashlib.sha256(inputs[n]).hexdigest()==pin,'Original stage actor input: '+n)
    require(hashlib.sha256(pixels).hexdigest()==recipe['pixels_sha256'],'Final stage artwork identity')
    region=recipe['region'];data=Data(inputs['comp2'],0x60b080 if region=='jp' else 0x60ad00,inputs['coords'],0xb04000);writes=[];reports={}
    for owner,(destination,nf,nc,ns) in FAMILIES.items():
        root,targets,frames=graph(inputs['comp1'],data,region,owner);row=recipe['families'][str(owner)]
        mapping={int(k):v for k,v in row['frames'].items()};cels={int(k):v for k,v in row['cels'].items()}
        require(set(mapping)==set(frames) and set(cels)=={v[1] for v in frames.values()},'Complete stage allocation bindings')
        for source,(native,xy,tiles) in sorted(cels.items()):
            coords,body=emit_cel(data,source,xy,tiles,inputs['art'],inputs['valid'],pixels[40*1024**2:],0)
            require(coords is not None and body[:2]==b'\0\2','Stage complete compact cel grammar')
            writes.extend(((xy,coords),(native,body)))
        for source,(header,cel,successor) in sorted(frames.items()):
            body=header[:4]+struct.pack('>I',cels[cel][0])
            if header[1]&128:body+=struct.pack('>I',mapping[successor])
            elif successor is not None:require(mapping[successor]==mapping[source]+8,'Stage implicit successor placement')
            writes.append((mapping[source],body))
        writes.append((destination,b''.join(struct.pack('>h',mapping[p]-destination) for p in targets)))
        reports[str(owner)]={'source_root':root,'frames':nf,'cels':nc,'root_slots':ns}
    return writes,reports


def main():
    import argparse,json
    from pathlib import Path
    p=argparse.ArgumentParser(description=__doc__)
    for n in ('recipe','inputs','pixels','outdir'):p.add_argument('--'+n,type=Path,required=True)
    a=p.parse_args();recipe=json.loads(a.recipe.read_text());paths=json.loads(a.inputs.read_text());writes,report=construct({n:Path(v).read_bytes() for n,v in paths.items()},recipe,a.pixels.read_bytes());data=bytearray(0x400000);mask=bytearray(len(data))
    for at,blob in writes:
        at-=0xa00000;require(0<=at<=len(data)-len(blob),'Stage actor expanded bounds');require(all(not mask[at+i] or data[at+i]==v for i,v in enumerate(blob)),'Stage alias conflict');data[at:at+len(blob)]=blob;mask[at:at+len(blob)]=b'\1'*len(blob)
    (a.outdir/'result.bin').write_bytes(data);(a.outdir/'result.mask').write_bytes(mask);print(json.dumps(report))


if __name__=='__main__':main()
