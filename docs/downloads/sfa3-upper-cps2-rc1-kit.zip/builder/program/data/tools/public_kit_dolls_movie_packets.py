"""Reconstruct both complete original Dolls movie flow packets."""
import hashlib
import struct
import public_kit_ending_command_groups as commands
import public_kit_ending_actor_groups as actors
from public_kit_graphics import require

FAMILIES=((30,0xca0000,50,504,4,[20,0],646),(31,0xca0488,83,840,28,[17,12,11,0],1294))


def digest(blob):return hashlib.sha256(blob).hexdigest()


def construct(inputs,recipe):
    require(set(inputs)==set(recipe['inputs'])=={'comp2'},'Complete Dolls original source inventory')
    require(set(recipe)=={'schema','region','inputs','families','juli_pose'}and recipe['schema']==1,'Dolls flow recipe schema')
    data=inputs['comp2'];pin=recipe['inputs']['comp2']
    require(len(data)==pin['bytes']and digest(data)==pin['sha256'],'Original regional Dolls component')
    region=recipe['region'];require(region in ('us','jp'),'Dolls source region')
    base=0x60ad00 if region=='us'else 0x60b080;shift=0x10f0 if region=='jp'else 0
    def read(at,n):
        require(0<=at-base<=len(data)-n,'Original Dolls resource bounds');return data[at-base:at-base+n]
    def root(owner,tables):
        roots=[struct.unpack('<I',read(t+shift+owner*4,4))[0]for t in tables]
        require(roots[0]==roots[1],'Complete original Dolls mode aliases');return roots[0]
    require(set(recipe['families'])=={'30','31'},'Complete Dolls sibling domain')
    writes=[];reports=[];amended=[]
    for owner,dest,count,size,prefetch,counts,actor_size in FAMILIES:
        source=recipe['families'][str(owner)]
        command_root=root(owner,(0x60b860,0x60b910));actor_root=root(owner,(0x60b220,0x60b2d0))
        require(source['command_root']==command_root and source['actor_root']==actor_root,'Original Dolls root bindings')
        rows,end=commands.parse(read,command_root,'<');footer,stop=commands.command(read,end,'<')
        require(len(rows)==count and end-command_root==size and stop-end==prefetch,'Complete Dolls command and held-prefetch extent')
        require(digest(read(command_root,size))==source['commands_sha256']and digest(read(end,prefetch))==source['prefetch_sha256'],'Original complete command identities')
        require([(i,r[2])for i,r in enumerate(rows)if r[1]==0x401]==[(count-3,(20,))],'Original Dolls stage20 handoff')
        command_blob=commands.pack(rows+[footer]);require(len(command_blob)==size+prefetch,'Complete emitted Dolls commands')
        parsed,parsed_end=commands.parse(lambda at,n:command_blob[at:at+n],0,'>')
        require(parsed==rows and parsed_end==size and commands.command(lambda at,n:command_blob[at:at+n],size,'>')[0]==footer,'Whole Dolls command grammar roundtrip')
        groups=actors.groups(read,actor_root,'<')
        require([len(g)if g is not None else 0 for g in groups]==counts and groups[-1]is None,'Complete Dolls actor selector domain')
        header=bytearray(len(groups)*2);body=bytearray();expected=[];actor_dest=dest+len(command_blob)
        for index,group in enumerate(groups):
            if group is None:expected.append(None);continue
            converted=actors.encode(group,'<')
            for j,row in enumerate(converted):
                if owner==30 and (row[0],row[1],row[3],row[31])==(0x4b,3,65,30):
                    address=actor_dest+len(header)+len(body)+j*32;patch=recipe['juli_pose']
                    require(set(patch)=={'address','before_sha256','after_sha256','type','selector'}and
                            patch['address']==address==0xca03e0 and patch['type']==0x83 and patch['selector']==5,'Reviewed Juli whole actor projection')
                    require(digest(row)==patch['before_sha256'],'Complete original Juli ordinary actor preimage')
                    value=bytearray(row);value[1]=patch['type'];value[3]=patch['selector'];converted[j]=bytes(value)
                    require(digest(value)==patch['after_sha256'],'Complete reviewed Juli actor projection');amended.append(address)
            expected.append(converted);struct.pack_into('>H',header,index*2,len(header)+len(body));body.extend(b''.join(converted)+b'\xff\xff')
        actor_blob=bytes(header+body);require(len(actor_blob)==actor_size,'Complete Dolls mixed actor allocation')
        require(actors.groups(lambda at,n:actor_blob[at:at+n],0,'>')==expected,'Whole Dolls actor grammar roundtrip')
        parameters=struct.pack('>3H',*struct.unpack('<3H',read(0x60b9c0+shift+owner*6,6)))
        writes.extend(((dest,command_blob),(actor_dest,actor_blob),(actor_dest+actor_size,parameters)))
        reports.append({'owner':owner,'commands':count,'command_bytes':len(command_blob),'actor_groups':counts,'actor_bytes':actor_size,'parameter_bytes':6})
    require(amended==[0xca03e0]and sum(len(b)for _,b in writes)==3328,'Complete two-movie packet and unique Juli binding')
    return writes,{'bytes':3328,'families':reports,'reviewed_actor_projections':amended,'scope':'Complete movie control resources; image/cel packets separately reconstructed.'}


def main():
    import argparse,json
    from pathlib import Path
    p=argparse.ArgumentParser(description=__doc__)
    for name in ('comp2','recipe','out'):p.add_argument('--'+name,type=Path,required=True)
    a=p.parse_args();require(not a.out.exists(),'Fresh Dolls packet output required')
    writes,report=construct({'comp2':a.comp2.read_bytes()},json.loads(a.recipe.read_text()));data=bytearray(0x400000);mask=bytearray(len(data))
    for address,blob in writes:
        at=address-0xa00000;require(not any(mask[at:at+len(blob)]),'Dolls packet overlap');data[at:at+len(blob)]=blob;mask[at:at+len(blob)]=b'\1'*len(blob)
    a.out.mkdir();(a.out/'data.bin').write_bytes(data);(a.out/'mask.bin').write_bytes(mask);(a.out/'report.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')


if __name__=='__main__':main()
