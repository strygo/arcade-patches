"""Complete original T. Hawk portrait frame banks and all their owned cel resources."""
import hashlib,struct
from public_kit_graphics import require
from public_kit_hover_objects import cel,tiles_for

START,END=0xc78000,0xc7986c


def original(comp2,region):
    base=0x60ad00 if region=='us'else 0x60b080
    tables={'heads':0x69f00 if region=='us'else 0x6ae30,'names':0x356df0 if region=='us'else 0x35c170}
    rows={}
    for group,selectors in (('heads',range(32)),('names',(1,2))):
        table=tables[group]
        for selector in selectors:
            at=table+struct.unpack_from('<H',comp2,table+selector*2)[0]+35*8
            address=struct.unpack_from('<I',comp2,at+4)[0]
            rows[f'{group}:{selector}']=(comp2[at:at+4],cel(comp2,address-base,'<',base))
    return rows


def construct(inputs,recipe,pixels):
    for name,pin in recipe['inputs'].items():require(len(inputs[name])==pin['bytes']and hashlib.sha256(inputs[name]).hexdigest()==pin['sha256'],'T. Hawk portrait source '+name)
    require(set(recipe['inputs'])=={'comp2','font'}and recipe['region']in ('us','jp'),'Complete portrait source domain')
    sources=original(inputs['comp2'],recipe['region']);require(set(sources)==set(recipe['records']),'Complete32 heads/two names portrait family')
    writes=[(0xc79854,bytes(8))];checked=0;owned=set()
    def add(at,blob):
        require(START<=at<=END-len(blob),'Owned T. Hawk portrait resource allocation');writes.append((at,blob))
    for key,(header,value)in sources.items():
        group,selector=key.split(':');selector=int(selector);dest,kind,xy,codes=recipe['records'][key]
        require(0<=dest<0xe00000 and dest%2==0,'T. Hawk portrait cel binding')
        add((0xc79754 if group=='heads'else 0xc79854)+selector*8,header+struct.pack('>I',dest))
        if kind==18:
            require(value['kind']==18 and not codes and xy is None,'Blank T. Hawk portrait cel')
            if START<=dest<END:add(dest,struct.pack('>H',18))
            continue
        expanded=kind==2 or (kind==8 and dest>=0x3d4000)
        commands=list(tiles_for(value['commands']))if expanded else value['commands']
        require(len(codes)==len(commands)>0,'Complete T. Hawk portrait cel allocation '+key+' kind='+str(kind)+' native='+str(len(codes))+' original='+str(len(commands)))
        require(expanded or kind==value['kind'],'Retained T. Hawk portrait cel grammar')
        total=len(commands)if expanded else value['total'];body=bytearray(struct.pack('>3H',kind,total,len(commands)-1))
        coords=b''.join(struct.pack('>2h',x,y)for _,_,x,y in commands)
        if kind==8:
            require(xy is None,'Inline T. Hawk portrait coordinates')
            body.extend(b''.join(struct.pack('>2H2h',code,attr,x,y)for code,(_,attr,x,y)in zip(codes,commands)))
        else:
            require(kind in (2,10,12)and isinstance(xy,int),'T. Hawk portrait coordinate allocation')
            if kind==10:body.extend(struct.pack('>H',value['common']))
            body.extend(struct.pack('>I',xy));body.extend(b''.join(struct.pack('>H',code)if kind==10 else struct.pack('>2H',code,attr)for code,(_,attr,_,_)in zip(codes,commands)))
            if START<=dest<END:add(xy,coords)
        if START<=dest<END:add(dest,bytes(body));owned.add(dest)
        source_tiles=list(tiles_for(value['commands']));native_tiles=list(tiles_for([(code,attr,x,y)for code,(_,attr,x,y)in zip(codes,commands)]))
        require(len(source_tiles)==len(native_tiles),'Complete T. Hawk portrait canvas')
        for (source,sa,sx,sy),(target,ta,tx,ty)in zip(source_tiles,native_tiles):
            require((sa,sx,sy)==(ta,tx,ty),'T. Hawk portrait tile geometry/attributes')
            image=inputs['font'][(source+0x1c00)*128:(source+0x1c01)*128];tile=target+((0x60000 if START<=dest<END else 0x30000) if kind==2 else 0x16c00)
            require(len(image)==128 and pixels[tile*128:(tile+1)*128]==image,'Complete original T. Hawk portrait tile differs '+key+' kind='+str(kind)+' source='+hex(source)+' target='+hex(target)+' physical='+hex(tile));checked+=1
    comp2=inputs['comp2'];base=0x60ad00 if recipe['region']=='us'else 0x60b080
    directory=0x1210f0+(0 if recipe['region']=='us'else 0x5380)
    source=struct.unpack_from('<I',comp2,directory+35*4)[0]-base
    colors=comp2[source:source+1536];require(len(colors)==1536,'Complete original six-choice portrait palette')
    add(0xc790f2,b''.join(colors[n:n+2][::-1]for n in range(0,len(colors),2)))
    return writes,{'head_records':32,'name_slots':3,'owned_cels':len(owned),'checked_tiles':checked,'palette_bytes':1536}
