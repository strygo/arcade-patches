"""Complete original six-choice Shin Akuma result and stage palettes and native controls."""
import hashlib,struct
from public_kit_graphics import require


def construct(inputs,recipe):
    require(set(inputs)==set(recipe['inputs'])=={'arcade','comp2'},'Complete result palette inputs')
    for name,pin in recipe['inputs'].items():
        require(len(inputs[name])==pin['bytes'] and hashlib.sha256(inputs[name]).hexdigest()==pin['sha256'],'Original result palette '+name)
    region=recipe['region'];require(region in ('us','jp'),'Result palette region')
    base=0x60b080 if region=='jp'else 0x60ad00;directory=0x126470 if region=='jp'else 0x1210f0
    source=inputs['comp2'];raw=inputs['arcade']
    def colors(owner):
        at=struct.unpack_from('<I',source,directory+owner*4)[0]-base
        require(0<=at<=len(source)-1536 and at%2==0,'Whole six-choice color array extent')
        return b''.join(source[n:n+2][::-1]for n in range(at,at+1536,2))
    for owner in (0,1):
        at=struct.unpack_from('>I',raw,0x351f14+owner*4)[0]
        require(colors(owner)==raw[at:at+1536],'Original common six-choice palette control')
    writes=[(0xc5a000,colors(36))]
    for role,(table,size,destination)in enumerate(zip((0x70e560,0x7147e0,0x71d420,0x707d10),(1024,1024,1024,192),(0xc5e000,0xc5e400,0xc5e800,0xc5ec00))):
        table+=0x5700 if region=='jp'else 0
        root=table+struct.unpack_from('<h',source,table-base+36*2)[0]-base
        require(0<=root<=len(source)-size and root%2==0,'Complete original Shin stage palette extent')
        writes.append((destination,b''.join(source[n:n+2][::-1]for n in range(root,root+size,2))))
    return writes,{'owner':36,'victory_choices':6,'stage_banks':4,'native_control_owners':[0,1],'bytes':4800}
