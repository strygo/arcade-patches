"""Project seven whole original owner tables into the reviewed Upper allocations.

Only original media supplies table values. The recipe contains identities,
reader bindings, extents and placement; no reconstructed resource payload.
"""
import hashlib
import struct


def require(ok,message):
    if not ok:raise ValueError(message)


def digest(blob):return hashlib.sha256(blob).hexdigest()


# Destination, byte extent, original native operand, original native table,
# representation. These are the seven reviewed owner_tables7b declarations.
TABLES=(
    (0xaa1530,40,0x23b40,0xc5f7a,'bytes'),
    (0xaa1558,40,0x23a8c,0xc5f9a,'bytes'),
    (0xaa1580,40,0x23ac0,0xc5fba,'bytes'),
    (0xaa15a8,160,0x64d9e,0x64e6a,'word-pairs'),
    (0xaa1648,160,0x64daa,0x64eea,'word-pairs'),
    (0xaa16e8,160,0x82cb8,0x832a6,'word-pairs'),
    (0xaa1788,6992,0xa466e,0x1200d4,'offset-lists'),
)


SOURCE_READERS=(2272184,2270988,2271480,5888740,5888808,3563492,3977596)
NATIVE_READERS=((0x23b3c,14),(0x23a88,52),(0x23abc,46),(0x64d98,50),
                (0x64d98,50),(0x82c9e,72),(0xa466a,76))

def source_reader(comp1,reader,address):
    require(set(reader)=={'address','low_address','span_bytes','sha256'},'Original reader binding schema')
    at=reader['address']-0x1f0040;low=reader['low_address']-0x1f0040;n=reader['span_bytes']
    require(at%4==low%4==0 and 0<=at<low<at+n<=len(comp1) and n<=256,'Original reader extent')
    require(digest(comp1[at:at+n])==reader['sha256'],'Original complete reader identity')
    upper=struct.unpack_from('<I',comp1,at)[0];lower=struct.unpack_from('<I',comp1,low)[0]
    register=(upper>>16)&31;op=lower>>26;imm=lower&65535
    require(upper>>26==15 and register!=0 and (lower>>21)&31==register and (lower>>16)&31==register and op in (9,13),'Original table address constructor')
    value=(((upper&65535)<<16)+(imm-65536 if imm&32768 else imm))&0xffffffff if op==9 else ((upper&65535)<<16)|imm
    require(value==address,'Original consumer points to another table')


def construct(inputs,recipe):
    require(set(recipe)=={'schema','region','source_region','inputs','tables'} and recipe['schema']==1,'Owner packet recipe schema')
    require(recipe['region'] in ('us','jp') and recipe['source_region'] in ('us','jp'),'Original regional table domain')
    require(set(inputs)==set(recipe['inputs'])=={'arcade','key','comp1','comp2'},'Complete original owner packet input domain')
    for name,value in inputs.items():
        pin=recipe['inputs'][name]
        require(set(pin)=={'bytes','sha256'} and len(value)==pin['bytes'] and digest(value)==pin['sha256'],'Original owner packet input '+name)
    from cps2_crypt import decrypt_rom
    opcode=decrypt_rom(inputs['arcade'][:0x100000],inputs['key'])[0]
    base=0x60ad00 if recipe['source_region']=='us'else 0x60b080
    require(len(recipe['tables'])==len(TABLES),'Complete seven-table inventory')
    writes=[];reports=[]
    for index,(spec,row) in enumerate(zip(TABLES,recipe['tables'])):
        dest,size,operand,native,kind=spec
        require(set(row)=={'destination','bytes','format','source','source_sha256','reader','native_reader','output_sha256'},'Whole table binding schema')
        require((row['destination'],row['bytes'],row['format'])==(dest,size,kind),'Whole owner table extent or placement differs')
        require(opcode[operand:operand+6]==b'\x20\x7c'+struct.pack('>I',native),'Original native owner-table operand')
        bound=row['native_reader'];require(set(bound)=={'address','bytes','sha256'},'Native reader identity schema')
        at=bound['address'];n=bound['bytes']
        require((at,n)==NATIVE_READERS[index],'Declared native consumer extent differs')
        require(at<=operand<operand+6<=at+n<=len(opcode) and n<=256,'Complete native reader extent')
        require(digest(opcode[at:at+n])==bound['sha256'],'Original native reader changed')
        pc=SOURCE_READERS[index]+(112 if recipe['source_region']=='jp'else 0)
        require(row['reader']['address']==pc and row['reader']['low_address']==pc+4 and row['reader']['span_bytes']==256,'Original regional source reader binding')
        source_reader(inputs['comp1'],row['reader'],row['source'])
        at=row['source']-base;raw=inputs['comp2'][at:at+size]
        require(0<=at and len(raw)==size and digest(raw)==row['source_sha256'],'Complete original owner table resource')
        blob=raw if kind=='bytes'else b''.join(raw[i:i+2][::-1]for i in range(0,size,2))
        if kind=='offset-lists':
            offsets=struct.unpack_from('>40H',blob)
            require(set(offsets)==set(range(80,6992,256)),'Complete40-owner offset/27-list grammar')
            require(max(offsets)+256==len(blob),'Complete last256-byte list extent')
        require(digest(blob)==row['output_sha256'],'Whole original owner table projection differs')
        writes.append((dest,blob));reports.append({'destination':dest,'bytes':size,'format':kind,'source':row['source'],'sha256':digest(blob)})
    return writes,{'bytes':sum(len(b)for _,b in writes),'owners':40,'tables':reports,'source_region':recipe['source_region']}


def main():
    import argparse,json
    from pathlib import Path
    p=argparse.ArgumentParser(description=__doc__)
    for name in ('inputs','recipe','out'):p.add_argument('--'+name,type=Path,required=True)
    a=p.parse_args();require(not a.out.exists(),'Fresh owner-table output required')
    recipe=json.loads(a.recipe.read_text());inputs={n:(a.inputs/(n+'.bin')).read_bytes()for n in recipe['inputs']}
    writes,report=construct(inputs,recipe);data=bytearray(0x400000);mask=bytearray(len(data))
    for address,blob in writes:
        at=address-0xa00000;require(not any(mask[at:at+len(blob)]),'Owner packet destinations overlap')
        data[at:at+len(blob)]=blob;mask[at:at+len(blob)]=b'\1'*len(blob)
    a.out.mkdir();(a.out/'data.bin').write_bytes(data);(a.out/'mask.bin').write_bytes(mask)
    (a.out/'report.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')


if __name__=='__main__':main()
