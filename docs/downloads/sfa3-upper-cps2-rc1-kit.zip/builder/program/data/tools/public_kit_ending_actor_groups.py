"""Complete original ending actor groups in the retained native mixed-field ABI.

Eight prefix bytes and eight suffix bytes preserve their original byte lanes;
only the eight intervening words change byte order. Every selector, record and
negative sentinel is parsed, then the entire emitted family is parsed again.
"""
import hashlib,struct
from public_kit_graphics import require

FAMILIES={'32':(0xa99000,[19,11,23,13]),'33':(0xbf9480,[23,23,17,11]),
          '34':(0xc602a4,[24,20]),'35':(0xd8124c,[11]),'37':(0xc823b6,[20,24,11])}


def groups(read,root,endian):
    first=struct.unpack(endian+'H',read(root,2))[0]
    require(2<=first<=128 and first%2==0,'Complete ending actor selector header')
    offsets=struct.unpack(endian+str(first//2)+'H',read(root,first));result=[]
    for offset in offsets:
        if offset==0:result.append(None);continue
        require(offset>=first and offset%2==0,'Ending actor group header overlap')
        rows=[];at=root+offset
        for _ in range(256):
            if read(at,1)[0]&128:break
            rows.append(read(at,32));at+=32
        else:raise ValueError('Unbounded original ending actor group')
        require(read(at,2)==b'\xff\xff','Original ending actor sentinel')
        result.append(rows)
    return result


def encode(rows,endian):
    return [row[:8]+struct.pack('>8H',*struct.unpack(endian+'8H',row[8:24]))+row[24:]for row in rows]


def construct(inputs,recipe):
    require(set(inputs)==set(recipe['inputs'])=={'comp2'},'Ending actor source inventory')
    data=inputs['comp2'];pin=recipe['inputs']['comp2']
    require(len(data)==pin['bytes']and hashlib.sha256(data).hexdigest()==pin['sha256'],'Ending actor original source identity')
    region=recipe['region'];require(region in ('us','jp'),'Ending actor source region')
    require(recipe['owners']==list(FAMILIES),'Complete declared ending actor sibling domain')
    base=0x60ad00 if region=='us'else 0x60b080;shift=0x10f0 if region=='jp'else 0
    def read(at,size):
        require(0<=at-base<=len(data)-size,'Original ending actor read bounds')
        return data[at-base:at-base+size]
    writes=[];reports=[]
    for owner,(destination,counts)in FAMILIES.items():
        roots=[struct.unpack('<I',read(table+shift+int(owner)*4,4))[0]for table in (0x60b220,0x60b2d0)]
        require(roots[0]==roots[1],'Original ending mode actor-root aliases')
        original=groups(read,roots[0],'<')
        require([len(v)if v is not None else 0 for v in original]==counts,'Complete original ending actor census '+owner)
        header=bytearray(2*len(original));body=bytearray();expected=[]
        for index,rows in enumerate(original):
            converted=encode(rows,'<');expected.append(converted)
            struct.pack_into('>H',header,index*2,len(header)+len(body));body.extend(b''.join(converted)+b'\xff\xff')
        blob=bytes(header+body)
        def emitted(at,size):
            require(0<=at-destination<=len(blob)-size,'Converted actor read bounds')
            return blob[at-destination:at-destination+size]
        require(groups(emitted,destination,'>')==expected,'Complete converted actor grammar round trip')
        writes.append((destination,blob));reports.append({'owner':int(owner),'groups':counts,'actors':sum(counts),'bytes':len(blob),'source_root':roots[0]})
    return writes,{'bytes':sum(len(b)for _,b in writes),'families':reports}
