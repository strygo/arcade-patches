"""Original ending palette recipes and complete native selector directories."""
import hashlib,struct
from public_kit_graphics import require
from public_kit_ending_colors import graph,OWNERS
from public_kit_palettes import catalog
from public_kit_resident_palettes import resources as resident_resources
from public_kit_color_arena import resources as arena_resources


def native_read(raw,at,n):
    require(n>0 and 0<=at<=len(raw)-n,'Native palette bounds')
    return raw[at:at+n]


def palette(raw,at,budget):
    out=bytearray()
    for _ in range(64):
        family,slot,offset,count=struct.unpack('>4H',native_read(raw,at,8));at+=8
        require(family%4==0 and family<=72 and slot%(4 if family<=8 else 2)==0 and 0<count<=32,'Native palette row grammar')
        table=struct.unpack('>I',native_read(raw,0x26b70+family,4))[0]
        ptr=struct.unpack('>I' if family<=8 else '>h',native_read(raw,table+slot,4 if family<=8 else 2))[0]
        start=(ptr if family<=8 else table+ptr)+(offset-65536 if offset&32768 else offset)
        copied=min(count,budget);out.extend(native_read(raw,start,copied*32));budget-=copied
        if not budget:return bytes(out)
    raise ValueError('Unbounded native palette recipe')


def inventory(raw):
    records=[]
    for owner in range(33):
        root=struct.unpack('>I',native_read(raw,0x26bbc+owner*4,4))[0]
        at=struct.unpack('>I',native_read(raw,0x26dcc+owner*4,4))[0];demands=set()
        for _ in range(2048):
            timer,tag=struct.unpack('>2H',native_read(raw,at,4));arity=tag&15
            values=struct.unpack('>'+str(arity)+'H',native_read(raw,at+4,arity*2)) if arity else ()
            group,opcode,kind=(tag>>4)&7,(tag>>8)&15,tag>>12
            if group==0 and opcode in (1,5) and not(opcode==5 and kind==15):
                selectors=values[4:8] if opcode==1 else values[1:5]
                require(len(selectors)==4,'Native four-group palette request')
                demands.update(zip(selectors,(30,32,32,32)))
            at+=4+arity*2
            if tag>>8==0 and tag&0x70==0:
                require(arity==0,'Native ending terminal operands');break
        else:raise ValueError('Unbounded native ending commands')
        for selector,budget in sorted(demands):
            address=struct.unpack('>I',native_read(raw,root+selector*4,4))[0]
            records.append((owner,selector,budget,address,palette(raw,address,budget)))
    require(len(records)==434,'Complete native palette request census')
    return records


def construct(comp2,native,recipe):
    require(recipe['schema']==1 and hashlib.sha256(comp2).hexdigest()==recipe['source_sha256'] and hashlib.sha256(native).hexdigest()==recipe['native_sha256'],'Ending palette source identities')
    require(set(recipe['families'])==set(map(str,OWNERS)),'Ending palette family inventory')
    base=0x60b080 if recipe['region']=='jp' else 0x60ad00;ds=0x10f0 if recipe['region']=='jp' else 0
    def read(at,n):
        require(n>0 and 0<=at-base<=len(comp2)-n,'Original palette bounds')
        return comp2[at-base:at-base+n]
    typed=inventory(native);writes=[];reports={}
    context=bytearray(native);arrays=catalog(comp2,recipe['region'])
    for provider in (resident_resources,arena_resources):
        for address,blob in provider(comp2,native,recipe['region'])[0]:context[address:address+len(blob)]=blob
    # These complete installed supplies precede the ending palette compiler.
    for name,address in (('primary:32',0x3fa000),('head:32',0x3daf00),('head:4',0x34da14)):
        blob=arrays[name][1];context[address:address+len(blob)]=blob
    for owner in OWNERS:
        resource=graph(comp2,recipe['region'],owner);info=recipe['families'][str(owner)]
        private={}
        for index,(selector,budget,row,address,size) in enumerate(info['colors']):
            blob=resource[selector,budget][row][1]
            require(len(blob)==size and blob not in private,'Complete unique private color allocation')
            private[blob]=info['retained_bytes']+index*4
        root=struct.unpack('<I',read(0x60b5a0+ds+owner*4,4))[0]
        directory=bytearray((max(s for s,_ in resource)+1)*4);emitted=0
        for selector in sorted({s for s,_ in resource}):
            budget=max(b for s,b in resource if s==selector);colors=b''.join(blob for _,blob in resource[selector,budget])
            if str(selector) not in info['recipes']:
                candidates=[(address,blob) for _,_,b,address,blob in typed if (b>=budget if owner==37 else b==budget) and blob[:budget*32]==colors]
                require(candidates,'No complete original native palette reuse')
                address=next((a for a,_ in candidates if all(palette(context,a,b)==b''.join(v for _,v in resource[selector,b]) for s,b in resource if s==selector)),None)
                require(address is not None,'Native reuse differs for original budget prefixes')
            else:
                address,size=info['recipes'][str(selector)];at=struct.unpack('<I',read(root+selector*4,4))[0];rows=[]
                for index,(_,blob) in enumerate(resource[selector,budget]):
                    fields=struct.unpack('<4H',read(at+index*8,8))
                    if blob in private:fields=(4,private[blob],0,fields[3])
                    else:
                        family,slot,offset,count=fields
                        table=struct.unpack('>I',native_read(context,0x26b70+family,4))[0]
                        ptr=struct.unpack('>I' if family<=8 else '>h',native_read(context,table+slot,4 if family<=8 else 2))[0]
                        start=(ptr if family<=8 else table+ptr)+(offset-65536 if offset&32768 else offset)
                        require(native_read(context,start,len(blob))==blob,f'Retained native palette row differs: owner={owner}, selector={selector}, row={index}, fields={fields}, native={start:x}, bytes={len(blob)}')
                    rows.append(struct.pack('>4H',*fields))
                output=b''.join(rows);require(len(output)==size,'Complete emitted palette recipe extent')
                writes.append((address,output));emitted+=1
            struct.pack_into('>I',directory,selector*4,address)
        writes.append((info['directory'],bytes(directory)))
        reports[str(owner)]={'emitted_recipes':emitted,'directory_bytes':len(directory),'source_requests':len(resource)}
    return writes,reports


def main():
    import argparse,json
    from pathlib import Path
    p=argparse.ArgumentParser(description=__doc__)
    for n in ('comp2','native','recipe','outdir'):p.add_argument('--'+n,type=Path,required=True)
    a=p.parse_args();writes,_=construct(a.comp2.read_bytes(),a.native.read_bytes(),json.loads(a.recipe.read_text()));data=bytearray(0x400000);mask=bytearray(len(data))
    for at,blob in writes:
        at-=0xa00000;require(0<=at<=len(data)-len(blob) and not any(mask[at:at+len(blob)]),'Palette allocation overlap/bounds')
        data[at:at+len(blob)]=blob;mask[at:at+len(blob)]=b'\1'*len(blob)
    a.outdir.mkdir(exist_ok=True);(a.outdir/'result.bin').write_bytes(data);(a.outdir/'result.mask').write_bytes(mask)


if __name__=='__main__':main()
