"""Native receiving-pose tables reconstructed from original Upper data."""
import hashlib
from math import gcd
import struct
from public_kit_graphics import require


def construct(comp2,recipe):
    require(recipe['schema']==1 and recipe['region'] in ('us','jp'),'Unknown receiving-pose recipe')
    require(hashlib.sha256(comp2).hexdigest()==recipe['source_sha256'],'Original pose source changed')
    base=0x60ad00 if recipe['region']=='us' else 0x60b080
    directory=0x7495b8 if recipe['region']=='us' else 0x74ecb8
    def read(at,size):
        require(0<=at-base<=len(comp2)-size and size>0,'Original pose source bounds')
        return comp2[at-base:at-base+size]
    def packet(fighter,count,victims,content_aliases=False):
        table=struct.unpack('<I',read(directory+fighter*4,4))[0]
        offsets=struct.unpack('<40h',read(table,80));unique=sorted(set(offsets))
        require(len(unique)>1 and min(unique)==80,'Original 40-victim header changed')
        extent=gcd(*(b-a for a,b in zip(unique,unique[1:])))
        require(extent>0 and extent%8==0,'Original receiving-pose group extent')
        header=bytearray(count*2);groups=bytearray();aliases={};rows=0
        for victim in victims:
            at=table+offsets[victim]
            projected=bytearray()
            for offset in range(0,extent,8):
                raw=read(at+offset,8);x,y,frame=struct.unpack('<hhH',raw[:4]+raw[6:])
                require(frame%20==0 and (victim not in (32,34,35) or frame<=560),'Receiving frame offset outside native family')
                projected.extend(struct.pack('>hh',x,y)+raw[4:6][::-1]+struct.pack('>H',frame))
            key=bytes(projected) if content_aliases else at
            if key not in aliases:
                aliases[key]=len(header)+len(groups);groups.extend(projected);rows+=extent//8
            require(aliases[key]<32768,'Native relative pose header reach')
            struct.pack_into('>h',header,victim*2,aliases[key])
        return bytes(header+groups),len(aliases),rows
    require([r['owners'] for r in recipe['allocations']]==[33,34] and
            [r['owner'] for r in recipe['columns']]==[34,35],'Incomplete receiving-pose recipe domain')
    result=[];reports=[]
    for allocation in recipe['allocations']:
        count=allocation['owners'];native=allocation['address']
        require(count in (33,34) and 0xa00000<=native<0xe00000,'Unqualified receiving-pose allocation')
        blob=bytearray(count*4);groups_count=rows_count=0
        for fighter in range(count):
            struct.pack_into('>I',blob,fighter*4,native+len(blob))
            body,groups,rows=packet(fighter,count,range(count) if fighter==32 else range(32,count))
            blob.extend(body);groups_count+=groups;rows_count+=rows
        if count==34:
            # Fei's later throw admission redirects only his directory cell;
            # the original two-victim packet remains physically installed.
            at=recipe['fei_all_victims']
            require(0xa00000<=at<0xe00000,'Fei receiving allocation bounds')
            body,groups,rows=packet(33,34,range(34))
            struct.pack_into('>I',blob,33*4,at);result.append((at,body))
            reports.append({'owner':33,'victims':34,'groups':groups,'rows':rows,'bytes':len(body),
                            'sha256':hashlib.sha256(body).hexdigest()})
        require(native+len(blob)<=0xe00000,'Pose allocation exceeds expanded data')
        result.append((native,bytes(blob)))
        reports.append({'owners':count,'groups':groups_count,'rows':rows_count,'bytes':len(blob),'sha256':hashlib.sha256(blob).hexdigest()})
    for column in recipe['columns']:
        who=column['owner'];count=column['owners'];addresses=column['tables']
        require((who,count) in ((34,35),(35,37)) and len(addresses)==count,'Unknown receiving-pose column domain')
        groups_count=rows_count=0;unique={}
        for fighter,address in enumerate(addresses):
            body,groups,rows=packet(fighter,count,range(count) if fighter==who else (who,),True)
            require(0xa00000<=address<=0xe00000-len(body),'Recipient table bounds')
            require(address not in unique or unique[address]==body,'Conflicting recipient table alias')
            if address not in unique:
                result.append((address,body));unique[address]=body;groups_count+=groups;rows_count+=rows
        native_directory=column['directory'];blob=struct.pack('>'+str(count)+'I',*addresses)
        require(0xa00000<=native_directory<=0xe00000-len(blob),'Recipient directory bounds')
        result.append((native_directory,blob))
        reports.append({'owner':who,'owners':count,'groups':groups_count,'rows':rows_count,
                        'bytes':len(blob)+sum(map(len,unique.values()))})
    return result,reports
