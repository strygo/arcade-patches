"""Original opponent-label names and width flags projected to complete owner strips.

The PS2 reader at 38CCF8 (JP +70) loads owner words at resource+48,
width flags at +208, and the two filler pairs at +288. Native label objects
consume one four-tile name and two single-tile fillers. The authored extension
routes owners 23 and 32..37; resident owners retain the original reader.
"""
import struct
import hashlib
from public_kit_graphics import require

def sha256(blob):return hashlib.sha256(blob).hexdigest()

OWNERS=(23,32,33,34,35,36,37)
READERS={'us':'e400d1a5982a0e39b2ad54fdf4a641c0382c841cfec70c88cdf8c97fe719babd',
         'jp':'a74829ce8a18a46e46b2a4ee45fe1954156f7f3fd5966e001f71a6a359ca5797'}
TABLE_SHA='377402958d291505044cd391b21eabde09d01cd658d32517488aeaca04659b87'
IMPORTS={0x33d0:0x1ff8c,0x33d4:0x1ff88,0x33d8:0x1ff84,0x33dc:0x1ff7c,0x33e0:0x1ff78,0x33e4:0x1ff74}


def construct(inputs,recipe,pixels):
    region=recipe['region'];require(region in READERS,'Original label region')
    for name,pin in recipe['inputs'].items():
        require(name in inputs and len(inputs[name])==pin['bytes'] and sha256(inputs[name])==pin['sha256'],'Original label input '+name)
    require(set(recipe['inputs'])=={'comp1','comp2','font'},'Complete label source inventory')
    shift=0x70 if region=='jp'else 0
    reader=inputs['comp1'][0x38ccf8+shift-0x1f0040:0x38d004+shift-0x1f0040]
    require(sha256(reader)==READERS[region],'Actual original label reader')
    base=0x60ad00 if region=='us'else 0x60b080
    at=(0x967bf0 if region=='us'else 0x96d2f0)-base
    table=inputs['comp2'][at:at+296]
    require(sha256(table)==TABLE_SHA,'Complete original label name/width/filler resource')
    require(set(table[208:288])<={0,1},'Original forty-owner width domain')
    require(len(pixels)==64*1024*1024,'Complete native graphics canvas')
    rows=[];checked=set()
    for language in range(2):
        source_language=1 if region=='us'else language
        for owner in range(38):
            if owner not in OWNERS:rows.append(bytes(6));continue
            code=struct.unpack_from('<H',table,48+source_language*80+owner*2)[0]
            wide=table[208+source_language*40+owner]
            fillers=struct.unpack_from('<2H',table,288+4*wide)
            target=IMPORTS.get(code,code+0x16c00)
            for source,destination,width in ((code,target,4),*( (f,f+0x16c00,1) for f in fillers)):
                for n in range(width):
                    glyph=source+n;tile=destination+n
                    original=inputs['font'][(glyph+0x1c00)*128:(glyph+0x1c01)*128]
                    require(len(original)==128 and pixels[tile*128:(tile+1)*128]==original,'Complete label tile artwork differs: '+hex(glyph)+' -> '+hex(tile))
                    checked.add((glyph,tile))
            rows.append(struct.pack('>3H',target-0x16c00,*fillers))
    blob=b''.join(rows);require(len(blob)==456,'Complete two38-row label strip extents')
    return [(0xaa0c00,blob)],{'bytes':456,'source_owners_per_language':40,'native_owners_per_language':38,
        'languages':2,'routed_owners':list(OWNERS),'checked_tiles':len(checked),'original_reader_and_full_metadata_bound':True}
