"""Complete retained Dolls collision bank and thirteen original native attack clones."""
import hashlib
import struct
import public_kit_dolls_collision_base as original
import public_kit_resource_delta as delta
from public_kit_dhalsim_tables import Owner
from public_kit_graphics import require

INDICES=(61,62,63,68,69,70,76,77,78,79,40,42,44)
CONTEXTS=((30,37,(61,62,63)),(30,38,(68,69,70)),(30,39,(76,77,78,79)),
          (31,37,(61,62,63)),(31,38,(68,69,70)),(31,39,(76,77,78,79)),
          (31,13,(40,)),(31,14,(42,)),(31,15,(44,)),(31,49,(44,)))


def construct(inputs,recipe):
    require(set(inputs)==set(recipe['inputs'])=={'arcade','comp2'},'Complete original Dolls inputs')
    for name,pin in recipe['inputs'].items():
        require(len(inputs[name])==pin['bytes']and hashlib.sha256(inputs[name]).hexdigest()==pin['sha256'],'Original Dolls identity: '+name)
    require(tuple(recipe['source_indices'])==INDICES,'Thirteen reviewed original attack clone identities')
    base,source=original.construct(inputs['arcade'],inputs['comp2'],recipe['region'])
    require(len(base)==8130 and recipe['retained_delta']['bytes']==8130,'Whole retained Dolls bank extent')
    retained=delta.apply(base,recipe['retained_delta'])
    raw=inputs['arcade'];u=lambda at:struct.unpack_from('>I',raw,at)[0]
    bank=0x12ed1a;attack=bank+struct.unpack_from('>5h',raw,bank)[4]
    witnesses=[]
    for owner,action,expected in CONTEXTS:
        choices=[u(u(0xde2a0+owner*4)+s*4)for s in range(3)]
        require(set(choices)=={bank},'Original clone context shares complete199-row bank')
        model=Owner(raw,0,u(0xde6a0+owner*4),u(0xde320+owner*4),u(0xde3a0+owner*4),choices,'>')
        for style in range(3):
            frames,loop=model.families[style*4+2][action]
            used={raw[at+9]for at in frames}
            require(set(expected)<=used and max(used)<199,'Whole original action binds every requested existing attack row')
            witnesses.append({'owner':owner,'style':style,'family':2,'action':action,'frames':len(frames),'loop':loop,'attack_indices':sorted(used)})
    records=[raw[attack+i*32:attack+(i+1)*32]for i in INDICES]
    require(all(len(row)==32 for row in records),'Complete original32-byte clone records')
    require([r[21]for r in records]==[0]*10+[4]*3,'Original native contact classes match reviewed Naomi restoration policy')
    blob=retained+b''.join(records)
    require(len(blob)==8546,'Whole retained and appended Dolls collision resource')
    return [(0xab0000,blob)],{'bytes':8546,'retained_bytes':8130,'appended_bytes':416,'appended_rows':13,
        'source_indices':list(INDICES),'source':source,'contexts':witnesses,
        'appended_sha256':hashlib.sha256(b''.join(records)).hexdigest(),
        'qualification':'Whole original native attack clones; no manifest append payload or new corrections.'}
