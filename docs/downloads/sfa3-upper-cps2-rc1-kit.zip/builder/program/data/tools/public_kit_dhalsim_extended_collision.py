"""Complete retained Dhalsim A/V collision bank with original Upper rows."""
import struct
import public_kit_dhalsim_tables as prior
from public_kit_graphics import require


def construct(inputs,recipe):
    tables,_=prior.construct(inputs,recipe)
    source,_=prior.original_model(inputs['arcade'],inputs['comp2'],recipe['region'])
    old=dict(tables)[0xaa5450];offsets=struct.unpack_from('>5h',old)
    lanes=[[old[i:i+8]for i in range(offsets[n],offsets[n+1],8)]for n in range(4)]
    attacks=[old[i:i+32]for i in range(offsets[4],len(old),32)]
    require([len(row)for row in lanes]==[51,46,25,9]and len(attacks)==94,'Complete previous AV bank extent')
    def values(action,ordinal):
        rows=[]
        for slot in (3,11):
            frames,loop=source.families[slot][action]
            require(len(frames)==6 and loop==(2 if action>=48 else 4),'Original Upper complete action topology')
            rows.append(source.values(frames[ordinal],slot//4))
        require(rows[0]['geometry']==rows[1]['geometry']and rows[0]['attack']==rows[1]['attack'],'Complete AV source row agreement')
        return rows[0]
    for lane,action in ((0,48),(1,48),(1,49),(2,50)):
        lanes[lane].append(values(action,1)['geometry'][lane])
    for action in (10,11):attacks.append(values(action,4)['attack'])
    new=[10]
    for rows in lanes:new.append(new[-1]+len(rows)*8)
    blob=struct.pack('>5h',*new)+b''.join(b''.join(rows)for rows in lanes)+b''.join(attacks)
    require(len(blob)==4162,'Complete expanded AV bank extent')
    return [(0xab6910,blob)],{'owner':15,'styles':[0,2],'geometry_rows':list(map(len,lanes)),'attack_rows':len(attacks),'bytes':len(blob),'complete_source_actions':[10,11,48,49,50]}
