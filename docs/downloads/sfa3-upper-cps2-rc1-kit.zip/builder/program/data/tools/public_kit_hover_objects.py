"""Complete original hover name/head tables, cels, coordinates and tile identity."""
import hashlib,struct
from public_kit_graphics import require

PENDING=(23,32,33,34,35,36,37)
HEADS=(21,23,30,31,32,33,34,35,36,37)
TABLES={'names':(0x3d4000,19,PENDING,(1,2,*range(9,17))),'heads':(0x3d5690,8,HEADS,tuple(range(8)))}

def cel(data,address,endian,base=0):
    kind,total,last=struct.unpack_from(endian+'3H',data,address)
    if kind==18:return {'kind':18,'total':0,'common':None,'commands':[]}
    count=last+1;require(kind in (8,10,12) and 1<=count<=1024,'Hover cel grammar changed at '+hex(address))
    if kind==8:
        commands=list(struct.iter_unpack(endian+'2H2h',data[address+6:address+6+8*count]))
        common=None
    else:
        if kind==12:
            common=0;at=address+6
        else:common=struct.unpack_from(endian+'H',data,address+6)[0];at=address+8
        # The PS2 compiler aligns pointers to four bytes. Native cels are
        # packed to words; source records beginning at+2 need different padding.
        if endian=='<':at=(at+3)&~3
        xy=struct.unpack_from(endian+'I',data,at)[0];payload=at+4
        xy-=base;require(0<=xy<=len(data)-4*count,'Hover coordinates outside component')
        points=list(struct.iter_unpack(endian+'2h',data[xy:xy+4*count]))
        if kind==10:
            codes=struct.unpack_from(endian+str(count)+'H',data,payload)
            commands=[(code,common,x,y)for code,(x,y)in zip(codes,points)]
        else:
            fields=list(struct.iter_unpack(endian+'2H',data[payload:payload+4*count]))
            commands=[(code,attr,x,y)for (code,attr),(x,y)in zip(fields,points)]
    require(sum(((a>>8&15)+1)*((a>>12&15)+1) for _,a,_,_ in commands)==total,'Hover cel tile budget differs')
    return {'kind':kind,'total':total,'common':common,'commands':commands}


def tiles_for(commands):
    for code,attr,x,y in commands:
        width,height=(attr>>8&15)+1,(attr>>12&15)+1
        for dy in range(height):
            for dx in range(width):
                # MAME's blocked tile wrap applies to unflipped objects.
                tile=code+dx+16*dy if attr&0x60 else (code&~15)+((code+dx)&15)+16*dy
                yield tile,(attr&0xff),x+16*(width-1-dx if attr&0x20 else dx),y+16*(height-1-dy if attr&0x40 else dy)



def original(comp2,region):
    require(region in ('us','jp'),'Hover source region')
    base=0x60ad00 if region=='us' else 0x60b080
    roots={'names':0x356df0 if region=='us' else 0x35c170,'heads':0x69f00 if region=='us' else 0x6ae30}
    result={}
    for name,(_,_,owners,selectors) in TABLES.items():
        table=roots[name]
        for selector in selectors:
            at=table+struct.unpack_from('<H',comp2,table+selector*2)[0]
            for owner in owners:
                position=at+owner*8;control=struct.unpack_from('<2H',comp2,position);source=struct.unpack_from('<I',comp2,position+4)[0]-base
                require(0<=source<len(comp2)-6,'Original hover cel bounds')
                result[f'{name}:{selector}:{owner}']=(control,cel(comp2,source,'<',base),position)
    require(len(result)==150,'Complete original hover record census')
    return result


def construct(inputs,recipe,pixels):
    for n,pin in recipe['inputs'].items():require(hashlib.sha256(inputs[n]).hexdigest()==pin,'Hover original identity '+n)
    require(hashlib.sha256(pixels).hexdigest()==recipe['pixels_sha256'],'Hover composed graphics identity')
    groups=['heads'] if recipe['region']=='us' else ['names','heads']
    require(recipe['groups']==groups,'Declared regional hover family domain')
    sources={k:v for k,v in original(inputs['comp2'],recipe['region']).items() if k.split(':')[0] in groups};require(set(sources)==set(recipe['records']),'Complete hover binding domain')
    tables={n:bytearray(count*38*8) for n,(_,count,_,_) in TABLES.items() if n in groups};writes=[]
    for key,(control,value,_) in sources.items():
        name,selector,owner=key.split(':');selector=int(selector);owner=int(owner)
        dest,kind,xy,codes=recipe['records'][key];require(0<=dest<0x400000,'Hover native cel allocation')
        struct.pack_into('>2HI',tables[name],(selector*38+owner)*8,*control,dest)
        if kind==18:
            require(value['kind']==18 and not codes and xy is None,'Blank hover binding');writes.append((dest,struct.pack('>H',18)));continue
        expanded=kind==2 or (kind==8 and dest>=0x3d4000)
        commands=list(tiles_for(value['commands'])) if expanded else value['commands']
        require(len(codes)==len(commands)>0,'Whole hover cel allocation '+key+' kind='+str(kind)+' codes='+str(len(codes))+' source='+str(len(commands)))
        if not expanded:require(kind==value['kind'] and codes==[c[0] for c in commands],'Retained original hover cel grammar/codes')
        total=len(commands) if expanded else value['total'];header=struct.pack('>3H',kind,total,len(commands)-1)
        coords=b''.join(struct.pack('>2h',x,y) for _,_,x,y in commands)
        if kind==8:body=header+b''.join(struct.pack('>2H2h',code,attr,x,y) for code,(_,attr,x,y) in zip(codes,commands));require(xy is None,'Inline hover coordinates')
        else:
            require(kind in (2,10,12) and isinstance(xy,int) and 0<=xy<=0x400000-len(coords),'Hover coordinate allocation');writes.append((xy,coords))
            body=header+(struct.pack('>H',value['common']) if kind==10 else b'')+struct.pack('>I',xy)
            body+=b''.join(struct.pack('>H',code) if kind==10 else struct.pack('>2H',code,attr) for code,(_,attr,_,_) in zip(codes,commands))
        writes.append((dest,body))
        # Expand both source and emitted native cels through the same block geometry.
        emitted=[(code,attr,x,y) for code,(_,attr,x,y) in zip(codes,commands)]
        original_tiles=list(tiles_for(value['commands']));native_tiles=list(tiles_for(emitted))
        require(len(original_tiles)==len(native_tiles),'Complete hover tile census')
        for (source,sa,sx,sy),(target,ta,tx,ty) in zip(original_tiles,native_tiles):
            require((sa,sx,sy)==(ta,tx,ty),'Hover tile geometry/attribute differs')
            source+=0x1c00;target+=0x30000 if kind==2 else 0x16c00
            require((source+1)*128<=len(inputs['font']) and (target+1)*128<=len(pixels),'Hover tile source bounds')
            require(inputs['font'][source*128:(source+1)*128]==pixels[target*128:(target+1)*128],'Whole original hover artwork differs')
    writes.extend((TABLES[n][0],bytes(blob)) for n,blob in tables.items())
    return writes,{'records':len(sources),'groups':groups,'table_slots':sum(TABLES[n][1]*38 for n in groups),'unique_cels':len({r[0] for r in recipe['records'].values()})}


def main():
    import argparse,json
    from pathlib import Path
    p=argparse.ArgumentParser(description=__doc__)
    for n in ('recipe','inputs','pixels','outdir'):p.add_argument('--'+n,type=Path,required=True)
    a=p.parse_args();inputs={n:Path(v).read_bytes() for n,v in json.loads(a.inputs.read_text()).items()};writes,report=construct(inputs,json.loads(a.recipe.read_text()),a.pixels.read_bytes());data=bytearray(0x400000);mask=bytearray(len(data))
    for at,blob in writes:
        require(all(not mask[at+i] or data[at+i]==v for i,v in enumerate(blob)),'Hover aliases disagree');data[at:at+len(blob)]=blob;mask[at:at+len(blob)]=b'\1'*len(blob)
    (a.outdir/'result.bin').write_bytes(data);(a.outdir/'result.mask').write_bytes(mask);print(json.dumps(report))


if __name__=='__main__':main()
