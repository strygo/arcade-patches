"""Complete original Dolls ending maps with native Scroll1/3 resource reuse."""
import hashlib,struct
from public_kit_graphics import require
from public_kit_stage_maps import CHUNKS,STRIDES

ALLOCATIONS={30:(0xca1420,3072,0xca2020),31:(0xca2794,8192,0xca4794)}

def project(inputs,region,owner,bindings,pixels):
    base=0x60ad00 if region=='us' else 0x60b080;shift=0x5700 if region=='jp' else 0;ds=0x10f0 if region=='jp' else 0
    def read(at,size):
        require(0<=at-base<=len(inputs['comp2'])-size,'Original Dolls map bounds')
        return inputs['comp2'][at-base:at-base+size]
    def native(at,size):
        require(0<=at<=len(inputs['arcade'])-size,'Native Dolls map bounds')
        return inputs['arcade'][at:at+size]
    roots=[struct.unpack('<I',read(t+ds+owner*4,4))[0]for t in (0x60b700,0x60b7b0)]
    require(roots[0]==roots[1],'Original Dolls map mode roots')
    root=roots[0];controls=bytearray(8);out=bytearray();used={n:set()for n in (1,2,3)};checked=0
    tables={n:{int(k):v for k,v in bindings[str(n)].items()}for n in (1,2,3)}
    def check(layer,code,ncode,attr,nattr):
        nonlocal checked
        stride={1:32,2:128,3:512}[layer];supply=inputs['scroll3']if layer==3 else inputs['font']
        require(0<=code<len(supply)//stride,'Original complete map tile bounds')
        if layer==3 and not inputs['scroll3_mask'][code]:
            require(code==0,'Original null Scroll3 code');tile=b'\xff'*512
        else:tile=supply[code*stride:(code+1)*stride]
        if layer==1:tile=b''.join(tile[y*4:y*4+4]*2 for y in range(8))
        require(nattr==attr and 0<=ncode<65536,'Complete Dolls map attributes')
        ncode=ncode&0x3fff if layer==3 else ncode
        at=(8<<20)+ncode*STRIDES[layer]
        require(pixels[at:at+len(tile)]==tile,'Complete Dolls map artwork');checked+=1
        used[layer].add(code)
    for layer,count in ((1,4),(2,16),(3,64)):
        offset=struct.unpack('<h',read(root+(layer-1)*2,2))[0];require(offset>=6,'Original Dolls map controls header')
        original=read(root+offset,count);chunks=sorted(set(original));indices={old:n for n,old in enumerate(chunks)}
        selected=bytes(indices[c]for c in original)if layer<3 else original
        if layer==1:require(selected==original,'Native Scroll1 control identity')
        struct.pack_into('>H',controls,(layer-1)*2,len(controls));controls.extend(selected)
        for identity in chunks:
            if layer==1:
                sm=struct.unpack('<64H',read(CHUNKS[1]+shift+identity*128,128))
                nm=struct.unpack('>64H',native(0x367494+identity*128,128))
                for source_macro,native_macro in zip(sm,nm):
                    cells=list(struct.iter_unpack('<2H',read(0x69f3b0+shift+source_macro*64,64)))
                    ncells=list(struct.iter_unpack('>2H',native(0x36a394+native_macro*64,64)))
                    for (attr,code),(ncode,nattr)in zip(cells,ncells):check(1,code,ncode,attr,nattr)
            else:
                size=256 if layer==2 else 64;raw=read(CHUNKS[layer]+shift+identity*size*3,size*3)
                codes=struct.unpack('<'+str(size)+'H',raw[:size*2]);attrs=raw[size*2:]
                if layer==3:
                    row=native(0x3ac614+identity*192,192);native_codes=struct.unpack('>64H',row[:128]);native_attrs=row[128:]
                for i,(code,attr)in enumerate(zip(codes,attrs)):
                    code=(code+(0x1c00 if layer==2 else 0))&65535
                    require(code in tables[layer],'Complete Dolls source tile bindings')
                    target,bank=tables[layer][code];require(bank==0,'Original native Dolls tile bank')
                    if layer==2:
                        check(layer,code,target,attr&127,attr&127);out.extend(struct.pack('>2H',target,attr&127))
                    else:check(layer,code,(native_codes[i]+0xb00)&65535,attr,native_attrs[i])
    # The S1 dictionary also belongs to the original complete resource domain.
    require(all(used[n]==set(tables[n])for n in (1,2,3)),'Complete Dolls layer tile domains')
    chunks,size,control=ALLOCATIONS[owner]
    require(len(out)==size and len(controls)==92,'Complete Dolls chunk/control extents')
    return [(chunks,bytes(out)),(control,bytes(controls))],{'owner':owner,'bytes':size+92,'source_tiles':{str(n):len(used[n])for n in (1,2,3)},'tile_checks':checked,'native_scroll1_scroll3_complete':True}

def construct(inputs,recipe,pixels):
    require(set(inputs)==set(recipe['inputs'])=={'arcade','comp2','font','scroll3','scroll3_mask'},'Complete Dolls background input set')
    for name,pin in recipe['inputs'].items():
        require(len(inputs[name])==pin['bytes']and hashlib.sha256(inputs[name]).hexdigest()==pin['sha256'],'Original Dolls map source '+name)
    require(recipe['region']in ('us','jp')and set(recipe['owners'])=={'30','31'},'Complete Dolls map owners')
    writes=[];reports=[]
    for owner in (30,31):
        rows,report=project(inputs,recipe['region'],owner,recipe['owners'][str(owner)],pixels);writes+=rows;reports.append(report)
    return writes,reports
