"""Standalone original-resource reconstruction with reviewed scalar-field deltas.

Unknown bytes retain a zero mask. This component cannot assemble a ROM by
silently treating its unknown bytes as padding.
"""
import argparse
import hashlib
import json
import os
import sys
from pathlib import Path
import zlib
import public_kit_extended_motion_tables as extended_motion_tables
import public_kit_boxer_cpu_masks as boxer_cpu_masks
import public_kit_dhalsim_extended_collision as dhalsim_extended_collision
import public_kit_dhalsim_extended_selectors as dhalsim_extended_selectors
import public_kit_dhalsim_x_collision as dhalsim_x_collision
import public_kit_ranking_palette_directory as ranking_palette_directory
import public_kit_ranking_palette_banks as ranking_palette_banks
import public_kit_victory_callback_directories as victory_callback_directories
import public_kit_ending_actor_groups as ending_actor_groups
import public_kit_shadow_voice_directories as shadow_voice_directories
import public_kit_ending_command_groups as ending_command_groups
import public_kit_effect_placements as effect_placements
import public_kit_ism_parameter_directories as ism_parameter_directories
import public_kit_collision_deltas as collision_deltas
import public_kit_dolls_complete_collision as dolls_complete_collision
import public_kit_route_resources as route_resources
import public_kit_outer_metadata as outer_metadata
import public_kit_fei_voice_policy as fei_voice_policy
import public_kit_attract_cycles as attract_cycles
import public_kit_owner_table_packets as owner_table_packets
import public_kit_collision_clones as collision_clones
import public_kit_shin_collision_packet as shin_collision_packet
import public_kit_dolls_movie_packets as dolls_movie_packets
import public_kit_cody_combat_packet as cody_combat_packet
import public_kit_dhalsim_retained_tables as dhalsim_retained_tables
import public_kit_boxer_collision as boxer_collision
import public_kit_fei_action62 as fei_action62
import public_kit_hawk_body_packet as hawk_body_packet
import public_kit_dee_runtime_tables as dee_runtime_tables
import public_kit_loop_metadata as loop_metadata
import public_kit_attract_position_tables as attract_position_tables
import public_kit_fei_body_metadata as fei_body_metadata
import public_kit_boxer_metadata as boxer_metadata
import public_kit_dolls_palette_packets as dolls_palette_packets
import public_kit_early_initializers as early_initializers
import public_kit_cpu_predicate_arrays as cpu_predicate_arrays
import public_kit_loop_cancel_banks as loop_cancel_banks
import public_kit_boxer_control_directories as boxer_control_directories
import public_kit_fei_loop_tables as fei_loop_tables
import public_kit_evil_dolls_routes as evil_dolls_routes
import public_kit_evil_ending_captions as evil_ending_captions
import public_kit_retained_callbacks as retained_callbacks
import public_kit_guile_round_data as guile_round_data
import public_kit_evil_ending_flow as evil_ending_flow
import public_kit_bison_predecessor as bison_predecessor
import public_kit_initializer_directories as initializer_directories
import public_kit_cancel_directories as cancel_directories
import public_kit_shared_ryu_attacks as shared_ryu_attacks
import public_kit_guile_ending_palette_family as guile_ending_palette_family
import public_kit_result_directories as result_directories
import public_kit_owner_callback_directories as owner_callback_directories
import public_kit_evil_palette_directories as evil_palette_directories
import public_kit_ranking_portraits as ranking_portraits
import public_kit_ryu_primary75 as ryu_primary75
import public_kit_actor as actor
import public_kit_boxer_ordinary_frames as boxer_ordinary_frames
import public_kit_retained_cancel_banks as retained_cancel_banks
import public_kit_shin_palette_resources as shin_palette_resources
import public_kit_shared_ryu_tables as shared_ryu_tables
import public_kit_fei_body_directories as fei_body_directories
import public_kit_evil_result_palette as evil_result_palette
import public_kit_motion_tables as motion_tables
import public_kit_combat as combat
import public_kit_actions as actions
import public_kit_action_banks as action_banks
import public_kit_primary_graph as primary_graph
import public_kit_shin_directories as shin_directories
import public_kit_fei_directories as fei_directories
import public_kit_shin_frames as shin_frames
import public_kit_shin_naomi as shin_naomi
import public_kit_dee_tiles as dee_tiles
import public_kit_result_labels as result_labels
import public_kit_stage_actors as stage_actors
import public_kit_extra_foreground as extra_foreground
import public_kit_stage_foreground as stage_foreground
import public_kit_bison_ending_bodies as bison_ending_bodies
import public_kit_fei_portrait_family as fei_portrait_family
import public_kit_dee_portrait_family as dee_portrait_family
import public_kit_hawk_portrait_family as hawk_portrait_family
import public_kit_evil_ending_portrait as evil_ending_portrait
import public_kit_akuma_ending_pose as akuma_ending_pose
import public_kit_shared_ryu_frames as shared_ryu_frames
import public_kit_cody_added_frames as cody_added_frames
import public_kit_boxer_ordinary_cels as boxer_ordinary_cels
import public_kit_guile_v_palette_family as guile_v_palette_family
import public_kit_shared_special_palette as shared_special_palette
import public_kit_dolls_ending_maps as dolls_ending_maps
import public_kit_guile_portrait_family as guile_portrait_family
import public_kit_early_stage_actors as early_stage_actors
import public_kit_dhalsim_directory as dhalsim_directory
import public_kit_dhalsim_tables as dhalsim_tables
import public_kit_copied_frames as copied_frames
import public_kit_sagat_copied_frames as sagat_copied_frames
import public_kit_dhalsim_copied_frames as dhalsim_copied_frames
import public_kit_sakura_copied_resources as sakura_copied_resources
import public_kit_dhalsim_x_frames as dhalsim_x_frames
import public_kit_auxiliary_children as auxiliary_children
import public_kit_opponent_labels as opponent_labels
import public_kit_ranking_eyes as ranking_eyes
import public_kit_frontend_owner_roots as frontend_owner_roots
import public_kit_controller_headers as controller_headers
import public_kit_configuration_text as configuration_text
import public_kit_hawk_child_resources as hawk_child_resources
import public_kit_fei_flames as fei_flames
import public_kit_restored_page_table as restored_page_table
import public_kit_restored_page_clones as restored_page_clones
import public_kit_dee_primary_directories as dee_primary_directories
import public_kit_copied_directories as copied_directories
import public_kit_shin_labels as shin_labels
import public_kit_retained_quote_directories as retained_quote_directories
import public_kit_sparse_quote_fonts as sparse_quote_fonts
import public_kit_native_palette_tables as native_palette_tables
import public_kit_frame_resources as frames
import public_kit_stage_maps as stages
import public_kit_ending_maps as ending_maps
import public_kit_native_ending_maps as native_ending_maps
import public_kit_poses as poses
import public_kit_english_text as english_text
import public_kit_english_supply as english_supply
import public_kit_compact_resources as compact
import public_kit_palettes as palettes
import public_kit_palette_cycles as palette_cycles
import public_kit_ending_resources as endings
import public_kit_ending_frames as ending_frames
import public_kit_boxer_ending as boxer_ending
import public_kit_boxer_tiles as boxer_tiles
import public_kit_boxer_maps as boxer_maps
import public_kit_attract_portraits as attract_portraits
import public_kit_attract_banners as attract_banners
import public_kit_ending_palette_tables as ending_palette_tables
import public_kit_ending_family_tables as ending_family_tables
import public_kit_fighter_directories as fighter_directories
import public_kit_dee_directories as dee_directories
import public_kit_cody_retained as cody_retained
import public_kit_ending_palette_cycles as ending_palette_cycles
import public_kit_dee_ending_palette_tables as dee_ending_palette_tables
import public_kit_dee_ending_maps as dee_ending_maps
import public_kit_dee_ending_colors as dee_ending_colors
import public_kit_retained_font as retained_font
import public_kit_boxer_ending_maps as boxer_ending_maps
import public_kit_ending_colors as ending_colors
import public_kit_cohort_combat as cohort_combat
import public_kit_restoration_quotes as restoration_quotes
import public_kit_restoration_story as restoration_story
import public_kit_original_quotes as original_quotes
import public_kit_quote_fonts as quote_fonts
import public_kit_original_paragraphs as original_paragraphs
import public_kit_restoration_retain as restoration_retain
import public_kit_graphics_recipe as graphics
import public_kit_panels as panels
from public_kit_graphics import require


def merge(writes):
    result=bytearray(0x400000);mask=bytearray(len(result))
    for address,blob in writes:
        at=address-0xa00000
        require(0<=at<=len(result)-len(blob),'Typed allocation outside upper data')
        for i,value in enumerate(blob):
            require(not mask[at+i] or result[at+i]==value,'Conflicting typed resource allocations')
            result[at+i]=value;mask[at+i]=1
    return bytes(result),bytes(mask)


def construct(region,root,recipes,ending_root):
    require(region in ('us','jp'),'Unknown public data region')
    load=lambda name:json.loads((recipes/name).read_text())
    catalog=json.loads((root/'pools.json').read_text())
    gfx_recipe=json.loads(zlib.decompress((recipes/(region+'.graphics.json.zlib')).read_bytes()))
    sources={}
    for name,pin in gfx_recipe['pools'].items():
        if name=='derived-us-stage-panels.bin':
            require(region=='us','English panels in another region')
            sources[name]=panels.from_pools(root,catalog,load('panels.json'))
        else:
            # These shared arcade resources have identical source identities.
            # Keep old recipe labels while reading only the canonical JP set.
            actual={'arcade-us-pixels.bin':'arcade-jp-pixels.bin',
                    'arcade-us-cloud-continuation.bin':'arcade-jp-cloud-continuation.bin'}.get(name,name)
            sources[name]=(root/actual).read_bytes()
    pixels=graphics.apply(gfx_recipe,sources)
    read=lambda suffix:(root/f'ps2-{region}-{suffix}').read_bytes()
    names=['sz3j.03c','sz3j.04c']+[f'sz3.{n:02d}c' for n in range(5,10)]+['sz3.10b']
    raw=b''.join((root/('arcade-jp-'+n)).read_bytes() for n in names)
    arcade=bytearray(len(raw));arcade[::2]=raw[1::2];arcade[1::2]=raw[::2]
    inputs={'comp2':read('comp2.bin'),'coords':read('coords390.bin')}
    for who in range(32,36):
        inputs['pixels'+str(who)]=read(f'entry{who+351}-s0.bin')
        inputs['mask'+str(who)]=read(f'entry{who+351}-s0.mask')
    ar=load('actor.json')['region'][region]
    original=(inputs['comp2'],inputs['coords'],inputs['pixels32'],inputs['mask32'])
    blob,graph=actor.construct(*original,ar);writes=[(0xa03000,blob)]
    output,_=motion_tables.construct({'arcade':arcade,'comp1':read('comp1.bin'),'comp2':inputs['comp2']},load('motion_tables.json')[region]);writes.extend(output)
    output,_=evil_result_palette.construct({'arcade':arcade,'comp2':inputs['comp2']},load('evil_result_palette.json')[region]);writes.extend(output)
    output,_=fei_body_directories.construct({'arcade':arcade},load('fei_body_directories.json')[region]);writes.extend(output)
    output,_=shared_ryu_tables.construct({'arcade':arcade,'comp2':inputs['comp2']},load('shared_ryu_tables.json')[region]);writes.extend(output)
    output,_=boxer_ordinary_frames.construct({'arcade':arcade,'comp2':inputs['comp2'],'coords':inputs['coords']},load('boxer_ordinary_frames.json')[region]);writes.extend(output)
    output,_=retained_cancel_banks.construct({'arcade':arcade,'comp2':inputs['comp2']},load('retained_cancel_banks.json')[region]);writes.extend(output)
    output,_=shin_palette_resources.construct({'arcade':arcade,'comp2':inputs['comp2']},load('shin_palette_resources.json')[region]);writes.extend(output)
    output,_=extended_motion_tables.construct({'arcade':arcade,'comp1':read('comp1.bin'),'comp2':inputs['comp2']},load('extended_motion_tables.json')[region]);writes.extend(output)
    output,_=boxer_cpu_masks.construct({'arcade':arcade,'comp1':read('comp1.bin'),'comp2':inputs['comp2']},load('boxer_cpu_masks.json')[region]);writes.extend(output)
    output,_=dhalsim_extended_collision.construct({'arcade':arcade,'comp2':inputs['comp2']},load('dhalsim_extended_collision.json')[region]);writes.extend(output)
    output,_=dhalsim_x_collision.construct({'arcade':arcade,'comp2':inputs['comp2']},load('dhalsim_x_collision.json')[region]);writes.extend(output)
    output,_=ranking_portraits.construct({'arcade':arcade,'comp2':inputs['comp2']},load('ranking_portraits.json')[region]);writes.extend(output)
    output,_=dhalsim_extended_selectors.construct({'arcade':arcade,'comp2':inputs['comp2']},load('dhalsim_extended_selectors.json')[region]);writes.extend(output)
    output,_=ranking_palette_directory.construct({'arcade':arcade,'comp2':inputs['comp2'],'key':(root/'arcade-jp-sfz3j.key').read_bytes()},load('ranking_palette_directory.json')[region]);writes.extend(output)
    output,_=evil_palette_directories.construct({'arcade':arcade,'comp2':inputs['comp2']},load('evil_palette_directories.json')[region]);writes.extend(output)
    output,_=result_directories.construct({'comp2':inputs['comp2'],'comp2-jp':(root/'ps2-jp-comp2.bin').read_bytes()},load('result_directories.json')[region]);writes.extend(output)
    output,_=owner_callback_directories.construct({'arcade':arcade},load('owner_callback_directories.json')[region]);writes.extend(output)
    output,_=ranking_palette_banks.construct({'comp2':inputs['comp2']},load('ranking_palette_banks.json')[region]);writes.extend(output)
    output,_=victory_callback_directories.construct({'arcade':arcade},load('victory_callback_directories.json')[region]);writes.extend(output)
    output,_=ending_actor_groups.construct({'comp2':inputs['comp2']},load('ending_actor_groups.json')[region]);writes.extend(output)
    output,_=shadow_voice_directories.construct({'arcade':arcade},load('shadow_voice_directories.json')[region]);writes.extend(output)
    output,_=ending_command_groups.construct({'comp2':inputs['comp2']},load('ending_command_groups.json')[region]);writes.extend(output)
    output,_=effect_placements.construct({'arcade':arcade,'key':(root/'arcade-jp-sfz3j.key').read_bytes(),'comp2':inputs['comp2'],'comp2-jp':(root/'ps2-jp-comp2.bin').read_bytes()},load('effect_placements.json')[region]);writes.extend(output)
    output,_=ism_parameter_directories.construct({'comp1':(root/'ps2-jp-comp1.bin').read_bytes(),'comp2':(root/'ps2-jp-comp2.bin').read_bytes()},load('ism_parameter_directories.json')[region]);writes.extend(output)
    output,_=collision_deltas.construct({'arcade':arcade,'comp2':inputs['comp2'],'coords':inputs['coords']},load('collision_deltas.json')[region]);writes.extend(output)
    output,_=dolls_complete_collision.construct({'arcade':arcade,'comp2':inputs['comp2']},load('dolls_complete_collision.json')[region]);writes.extend(output)
    output,_=route_resources.construct({'comp2':inputs['comp2']},load('route_resources.json')[region]);writes.extend(output)
    output,_=guile_round_data.construct({'arcade':arcade,'comp2':inputs['comp2']},load('guile_round_data.json')[region]);writes.extend(output)
    output,_=evil_ending_flow.construct({'comp2':inputs['comp2'],'metadataevil':(ending_root/f'ps2-{region}-entry473-metadata.bin').read_bytes()},load('evil_ending_flow.json')[region]);writes.extend(output)
    bison_inputs={'arcade':arcade,'comp2':inputs['comp2'],'coords':inputs['coords'],'pixels':read('entry365-s0.bin'),'mask':read('entry365-s0.mask'),**{n:(root/('arcade-jp-'+n)).read_bytes()for n in bison_predecessor.GFX}}
    output,_=bison_predecessor.construct(bison_inputs,load('bison_predecessor.json')[region]);writes.extend(output)
    output,_=initializer_directories.construct({'arcade':arcade},load('initializer_directories.json')[region]);writes.extend(output)
    output,_=cancel_directories.construct({'arcade':arcade},load('cancel_directories.json')[region]);writes.extend(output)
    output,_=fei_loop_tables.construct({'comp2':inputs['comp2']},load('fei_loop_tables.json')[region]);writes.extend(output)
    output,_=evil_dolls_routes.construct({'comp2':inputs['comp2']},load('evil_dolls_routes.json')[region]);writes.extend(output)
    output,_=evil_ending_captions.construct({'comp2-jp':(root/'ps2-jp-comp2.bin').read_bytes()},load('evil_ending_captions.json')[region]);writes.extend(output)
    output,_=retained_callbacks.construct({'arcade':arcade},load('retained_callbacks.json')[region]);writes.extend(output)
    output,_=early_initializers.construct({'arcade':arcade},load('early_initializers.json')[region]);writes.extend(output)
    output,_=cpu_predicate_arrays.construct({'arcade':arcade},load('cpu_predicate_arrays.json')[region]);writes.extend(output)
    output,_=loop_cancel_banks.construct({'arcade':arcade,'comp2':inputs['comp2']},load('loop_cancel_banks.json')[region]);writes.extend(output)
    output,_=boxer_control_directories.construct({'arcade':arcade,'key':(root/'arcade-jp-sfz3j.key').read_bytes()},load('boxer_control_directories.json')[region]);writes.extend(output)
    output,_=boxer_metadata.construct({'arcade':arcade,'key':(root/'arcade-jp-sfz3j.key').read_bytes(),'comp2':inputs['comp2']},load('boxer_metadata.json')[region]);writes.extend(output)
    output,_=dolls_palette_packets.construct({'arcade':arcade,'comp2':inputs['comp2']},load('dolls_palette_packets.json')[region]);writes.extend(output)
    output,_=fei_body_metadata.construct({'arcade':arcade,'key':(root/'arcade-jp-sfz3j.key').read_bytes(),'comp2':inputs['comp2']},load('fei_body_metadata.json')[region]);writes.extend(output)
    output,_=loop_metadata.construct({'arcade':arcade,'key':(root/'arcade-jp-sfz3j.key').read_bytes(),'comp1':(root/'ps2-jp-comp1.bin').read_bytes(),'comp2':(root/'ps2-jp-comp2.bin').read_bytes()},load('loop_metadata.json')[region]);writes.extend(output)
    output,_=attract_position_tables.construct({'comp1':read('comp1.bin'),'comp2':inputs['comp2']},load('attract_position_tables.json')[region]);writes.extend(output)
    output,_=outer_metadata.construct({'arcade':arcade,'key':(root/'arcade-jp-sfz3j.key').read_bytes(),'comp2':(root/'ps2-jp-comp2.bin').read_bytes()},load('outer_metadata.json')[region]);writes.extend(output)
    output,_=fei_voice_policy.construct({'comp2':(root/'ps2-jp-comp2.bin').read_bytes()},load('fei_voice_policy.json')[region]);writes.extend(output)
    output,_=attract_cycles.construct({'arcade':arcade,'key':(root/'arcade-jp-sfz3j.key').read_bytes(),'comp1':read('comp1.bin'),'comp2':inputs['comp2']},load('attract_cycles.json')[region]);writes.extend(output)
    output,_=owner_table_packets.construct({'arcade':arcade,'key':(root/'arcade-jp-sfz3j.key').read_bytes(),'comp1':read('comp1.bin'),'comp2':inputs['comp2']},load('owner_table_packets.json')[region]);writes.extend(output)
    output,_=collision_clones.construct({'comp2':inputs['comp2'],'coords':inputs['coords']},load('collision_clones.json')[region]);writes.extend(output)
    output,_=shin_collision_packet.construct({'arcade':arcade,'comp1':(root/'ps2-jp-comp1.bin').read_bytes(),'comp2':(root/'ps2-jp-comp2.bin').read_bytes(),'coords':(root/'ps2-jp-coords390.bin').read_bytes(),'naomi':(root/'naomi-program.bin').read_bytes()},load('shin_collision_packet.json')[region]);writes.extend(output)
    output,_=dolls_movie_packets.construct({'comp2':inputs['comp2']},load('dolls_movie_packets.json')[region]);writes.extend(output)
    output,_=cody_combat_packet.construct({'arcade':arcade,'key':(root/'arcade-jp-sfz3j.key').read_bytes(),'comp2':inputs['comp2']},load('cody_combat_packet.json')[region]);writes.extend(output)
    output,_=dhalsim_retained_tables.construct({'arcade':arcade,'comp2':inputs['comp2']},load('dhalsim_retained_tables.json')[region]);writes.extend(output)
    output,_=boxer_collision.construct({'arcade':arcade,'comp2-jp':(root/'ps2-jp-comp2.bin').read_bytes(),'coords-jp':(root/'ps2-jp-coords390.bin').read_bytes()},load('boxer_collision.json')[region]);writes.extend(output)
    output,_=fei_action62.construct({'comp2':inputs['comp2'],'coords':inputs['coords'],'pixels33':read('entry384-s0.bin'),'mask33':read('entry384-s0.mask')},load('fei_action62.json')[region],pixels[32*1024**2:]);writes.extend(output)
    output,_=hawk_body_packet.construct({'comp1':read('comp1.bin'),'comp2':inputs['comp2'],'coords':inputs['coords'],'pixels':read('entry386-s0.bin'),'mask':read('entry386-s0.mask')},load('hawk_body_packet.json')[region],pixels[48*1024**2:50*1024**2]);writes.extend(output)
    output,_=dee_runtime_tables.construct({'arcade':arcade,'key':(root/'arcade-jp-sfz3j.key').read_bytes(),'comp2-jp':(root/'ps2-jp-comp2.bin').read_bytes(),'coords-jp':(root/'ps2-jp-coords390.bin').read_bytes()},load('dee_runtime_tables.json')[region]);writes.extend(output)
    output,_=shared_ryu_attacks.construct({'arcade':arcade,'comp2':inputs['comp2'],'naomi':(root/'naomi-program.bin').read_bytes()},load('shared_ryu_attacks.json')[region]);writes.extend(output)
    output,_=guile_ending_palette_family.construct({'arcade':arcade,'comp2':inputs['comp2']},load('guile_ending_palette_family.json')[region]);writes.extend(output)
    cr=load('combat.json')['regions'][region];xr=load('action.json')['regions'][region]
    cb,_=combat.construct(inputs['comp2'],ar,graph['frame_bindings'],cr)
    xb,_=actions.construct(*original,ar,blob,graph,xr)
    for recipe,outputs in ((cr,cb),(xr,xb)):
        writes.extend((recipe['outputs'][name]['address'],data) for name,data in outputs.items())
    output,_=action_banks.construct(inputs['comp2'],load('action_banks.json')[region]);writes.extend(output)
    output,_=shin_directories.construct(inputs['comp2'],load('shin_directories.json')[region]);writes.extend(output)
    output,_=fei_directories.construct(inputs['comp2'],load('fei_directories.json')[region]);writes.extend(output)
    writes.extend(frames.construct(inputs,load('frames.json')[region],pixels[32*1024**2:]))
    writes.extend(primary_graph.construct(inputs,load('primary_graph.json')[region],pixels[32*1024**2:]))
    shin_inputs={'comp2':inputs['comp2'],'coords':inputs['coords'],'pixels':read('entry357-s0.bin'),
        'valid':read('entry357-s0.mask'),'arcade':arcade,'native_pixels':(root/'arcade-jp-pixels.bin').read_bytes()}
    output,_=shin_frames.construct(shin_inputs,load('shin_frames.json')[region],pixels);writes.extend(output)
    output,_=shin_naomi.construct({**shin_inputs,'naomi':(root/'naomi-program.bin').read_bytes()},load('shin_frames.json')[region],load('shin_naomi.json')[region],pixels);writes.extend(output)
    output,_=native_palette_tables.construct(arcade,(root/'arcade-jp-sfz3j.key').read_bytes(),load('native_palette_tables.json')[region]);writes.extend(output)
    stage_inputs={'comp2':inputs['comp2'],'font':read('font353.bin'),
                  'scroll3':read('entry525-s0.bin'),'scroll3_mask':read('entry525-s0.mask')}
    output,_=stages.construct(stage_inputs,load('stages.json')[region],pixels);writes.extend(output)
    output,_=result_labels.construct({'comp2':inputs['comp2'],'font':stage_inputs['font']},load('result_labels.json')[region],pixels);writes.extend(output)
    output,_=guile_portrait_family.construct({'comp2':inputs['comp2'],'font':stage_inputs['font']},load('guile_portrait_family.json')[region],pixels);writes.extend(output)
    output,_=guile_v_palette_family.construct(inputs['comp2'],arcade,load('guile_v_palette_family.json')[region]);writes.extend(output)
    output,_=shared_special_palette.construct(inputs['comp2'],arcade,load('shared_special_palette.json')[region]);writes.extend(output)
    output,_=dolls_ending_maps.construct({'arcade':arcade,**stage_inputs},load('dolls_ending_maps.json')[region],pixels);writes.extend(output)
    output,_=evil_ending_portrait.construct({'comp2':inputs['comp2'],'font':stage_inputs['font']},load('evil_ending_portrait.json')[region],pixels);writes.extend(output)
    output,_=akuma_ending_pose.construct({'comp1':read('comp1.bin'),'comp2':inputs['comp2'],'coords':inputs['coords'],'pixels':read('entry357-s0.bin'),'mask':read('entry357-s0.mask')},load('akuma_ending_pose.json')[region],pixels);writes.extend(output)
    output,_=shared_ryu_frames.construct({'comp2':inputs['comp2'],'coords':inputs['coords'],'pixels':read('entry355-s0.bin'),'mask':read('entry355-s0.mask')},load('shared_ryu_frames.json')[region],pixels);writes.extend(output)
    output,_=ryu_primary75.construct({'comp2':inputs['comp2'],'coords':inputs['coords'],'pixels':read('entry355-s0.bin'),'mask':read('entry355-s0.mask')},load('ryu_primary75.json')[region],pixels);writes.extend(output)
    output,_=boxer_ordinary_cels.construct({'arcade':arcade,'comp2':inputs['comp2'],'coords':inputs['coords'],'pixels':read('entry373-s0.bin'),'mask':read('entry373-s0.mask')},load('boxer_ordinary_cels.json')[region],pixels);writes.extend(output)
    output,_=cody_added_frames.construct({'comp2':inputs['comp2'],'coords':inputs['coords'],'pixels':read('entry378-s0.bin'),'mask':read('entry378-s0.mask')},load('cody_added_frames.json')[region],pixels);writes.extend(output)
    output,_=fei_portrait_family.construct({'comp2':inputs['comp2'],'font':stage_inputs['font']},load('fei_portrait_family.json')[region],pixels);writes.extend(output)
    output,_=dee_portrait_family.construct({'comp2':inputs['comp2'],'font':stage_inputs['font']},load('dee_portrait_family.json')[region],pixels);writes.extend(output)
    output,_=hawk_portrait_family.construct({'comp2':inputs['comp2'],'font':stage_inputs['font']},load('hawk_portrait_family.json')[region],pixels);writes.extend(output)
    output,_=bison_ending_bodies.construct({'arcade':arcade,'comp2':inputs['comp2'],'coords':inputs['coords'],'pixels':read('entry365-s0.bin'),'mask':read('entry365-s0.mask')},load('bison_ending_bodies.json')[region],pixels);writes.extend(output)
    output,_=stage_foreground.construct({'comp1':read('comp1.bin'),'comp2':inputs['comp2'],'coords':inputs['coords'],'art':read('entry351-s0.bin'),'valid':read('entry351-s0.mask'),'native':arcade},load('stage_foreground.json')[region],pixels);writes.extend(output)
    output,_=extra_foreground.construct({'comp1':read('comp1.bin'),'comp2':inputs['comp2'],'coords':inputs['coords'],'art':read('entry351-s0.bin'),'valid':read('entry351-s0.mask'),'native':arcade},load('extra_foreground.json')[region],pixels);writes.extend(output)
    output,_=stage_actors.construct({'comp1':read('comp1.bin'),'comp2':inputs['comp2'],'coords':inputs['coords'],'art':read('entry351-s0.bin'),'valid':read('entry351-s0.mask')},load('stage_actors.json')[region],pixels);writes.extend(output)
    output,_=early_stage_actors.construct({'comp1':read('comp1.bin'),'comp2':inputs['comp2'],'coords':inputs['coords'],'art':read('entry351-s0.bin'),'valid':read('entry351-s0.mask')},load('early_stage_actors.json')[region],pixels);writes.extend(output)
    output,_=dhalsim_directory.construct(arcade,load('dhalsim_directory.json')[region]);writes.extend(output)
    output,_=dhalsim_tables.construct({'arcade':arcade,'comp2':inputs['comp2']},load('dhalsim_tables.json')[region]);writes.extend(output)
    output,_=copied_frames.construct({'arcade':arcade,'comp2':inputs['comp2']},load('copied_frames.json')[region]);writes.extend(output)
    output,_=sagat_copied_frames.construct({'arcade':arcade,'comp2':inputs['comp2']},load('sagat_copied_frames.json')[region]);writes.extend(output)
    output,_=dhalsim_copied_frames.construct({'arcade':arcade,'comp2':inputs['comp2']},load('dhalsim_copied_frames.json')[region]);writes.extend(output)
    output,_=sakura_copied_resources.construct({'arcade':arcade,'comp2':inputs['comp2']},load('sakura_copied_resources.json')[region]);writes.extend(output)
    output,_=restored_page_clones.construct(arcade,load('restored_page_clones.json')[region],pixels);writes.extend(output)
    output,_=restored_page_table.construct(arcade,load('restored_page_table.json')[region],pixels);writes.extend(output)
    output,_=fei_flames.construct(inputs,load('fei_flames.json')[region],pixels[32*1024**2:]);writes.extend(output)
    output,_=hawk_child_resources.construct(inputs,load('hawk_child_resources.json')[region],pixels[32*1024**2:]);writes.extend(output)
    output,_=controller_headers.construct(load('controller_headers.json')[region]);writes.extend(output)
    output,_=configuration_text.construct(load('configuration_text.json')[region]);writes.extend(output)
    output,_=frontend_owner_roots.construct(load('frontend_owner_roots.json')[region]);writes.extend(output)
    output,_=ranking_eyes.construct({'arcade':arcade,'comp2':inputs['comp2'],'font':stage_inputs['font']},load('ranking_eyes.json')[region],pixels);writes.extend(output)
    output,_=opponent_labels.construct({'comp1':read('comp1.bin'),'comp2':inputs['comp2'],'font':stage_inputs['font']},load('opponent_labels.json')[region],pixels);writes.extend(output)
    output,_=auxiliary_children.construct(inputs,load('auxiliary_children.json')[region],pixels[32*1024**2:]);writes.extend(output)
    output,_=dhalsim_x_frames.construct({'arcade':arcade,'comp2':inputs['comp2']},load('dhalsim_x_frames.json')[region]);writes.extend(output)
    output,_=dee_primary_directories.construct(inputs['comp2'],load('dee_primary_directories.json')[region]);writes.extend(output)
    output,_=copied_directories.construct(arcade,load('copied_directories.json')[region]);writes.extend(output)
    output,_=shin_labels.construct({'comp2':inputs['comp2'],'font':stage_inputs['font']},load('shin_labels.json')[region],pixels);writes.extend(output)
    output,_=sparse_quote_fonts.construct(stage_inputs['font'],load('sparse_quote_fonts.json')[region],pixels);writes.extend(output)
    if region=='us':
        output,_=retained_quote_directories.construct(load('retained_quote_directories.json')[region]);writes.extend(output)
    output,_=ending_maps.construct(stage_inputs,load('ending_maps.json')[region],pixels);writes.extend(output)
    output,_=native_ending_maps.construct(stage_inputs,load('native_ending_maps.json')[region],pixels);writes.extend(output)
    writes.extend(boxer_tiles.construct({'comp2':inputs['comp2'],'font':stage_inputs['font']},load('boxer_tiles.json')[region],pixels))
    writes.extend(dee_tiles.construct({'comp2':inputs['comp2'],'font':stage_inputs['font']},load('dee_tiles.json')[region],pixels))
    output,_=boxer_maps.construct(stage_inputs,load('boxer_maps.json')[region],pixels);writes.extend(output)
    output,_=attract_portraits.construct({'comp2':inputs['comp2'],'font':stage_inputs['font']},load('attract_portraits.json')[region],pixels);writes.extend(output)
    output,_=attract_banners.construct({'comp2':inputs['comp2'],'font':stage_inputs['font']},load('attract_banners.json')[region],pixels);writes.extend(output)
    output,_=ending_palette_tables.construct(inputs['comp2'],arcade,load('ending_palette_tables.json')[region]);writes.extend(output)
    output,_=ending_family_tables.construct(inputs['comp2'],arcade,load('ending_family_tables.json')[region]);writes.extend(output)
    output,_=fighter_directories.construct(inputs['comp2'],load('fighter_directories.json')[region]);writes.extend(output)
    output,_=dee_directories.construct(inputs['comp2'],load('dee_directories.json')[region]);writes.extend(output)
    output,_=cody_retained.construct({'arcade':arcade,'comp2':inputs['comp2']},load('cody_retained.json')[region]);writes.extend(output)
    output,_=ending_palette_cycles.construct(read('comp1.bin'),inputs['comp2'],load('ending_palette_cycles.json')[region]);writes.extend(output)
    output,_=dee_ending_palette_tables.construct(inputs['comp2'],arcade,load('dee_ending_palette_tables.json')[region]);writes.extend(output)
    output,_=dee_ending_maps.construct(stage_inputs,load('dee_ending_maps.json')[region],pixels);writes.extend(output)
    output,_=dee_ending_colors.construct(inputs['comp2'],load('dee_ending_colors.json')[region]);writes.extend(output)
    output,_=retained_font.construct(stage_inputs['font'],load('retained_font.json')[region],pixels[:32*1024**2],space='upper');writes.extend(output)
    output,_=boxer_ending_maps.construct(stage_inputs,load('boxer_ending_maps.json')[region],pixels);writes.extend(output)
    output,_=ending_colors.construct(inputs['comp2'],load('ending_colors.json')[region]);writes.extend(output)
    output,_=poses.construct(inputs['comp2'],load('poses.json')[region]);writes.extend(output)
    output,_=compact.construct({'comp1':read('comp1.bin'),'comp2':inputs['comp2'],'coords':inputs['coords'],
        'pixels':read('entry351-s0.bin'),'mask':read('entry351-s0.mask')},load('compact.json')[region],pixels);writes.extend(output)
    output,_=palettes.construct(inputs['comp2'],load('palettes.json')[region]);writes.extend(output)
    output,_=palette_cycles.construct(inputs['comp2'],load('palette_cycles.json')[region]);writes.extend(output)
    output,_=cohort_combat.construct(inputs['comp2'],inputs['coords'],load('cohort_combat.json')[region]);writes.extend(output)
    ending_inputs={}
    for owner in endings.SELECTORS:
        ending_inputs['metadata'+str(owner)]=(ending_root/f'ps2-{region}-entry{owner+450}-metadata.bin').read_bytes()
        ending_inputs['pixels'+str(owner)]=read(f'entry{owner+383}-s0.bin')
        ending_inputs['mask'+str(owner)]=read(f'entry{owner+383}-s0.mask')
    output,_=endings.construct(ending_inputs,load('endings.json')[region],pixels);writes.extend(output)
    ending_inputs={}
    for family,(metadata,sprites) in ending_frames.FAMILIES.items():
        ending_inputs['metadata'+family]=(ending_root/f'ps2-{region}-entry{metadata}-metadata.bin').read_bytes()
        ending_inputs['pixels'+family]=read(f'entry{sprites}-s0.bin')
        ending_inputs['mask'+family]=read(f'entry{sprites}-s0.mask')
    output,_=ending_frames.construct(ending_inputs,load('ending_frames.json')[region],pixels);writes.extend(output)
    boxer_inputs={'metadataboxer':(ending_root/f'ps2-{region}-entry471-metadata.bin').read_bytes(),
                  'pixelsboxer':read('entry404-s0.bin'),'maskboxer':read('entry404-s0.mask')}
    output,_=boxer_ending.construct(boxer_inputs,load('boxer_ending.json')[region],pixels);writes.extend(output)
    if region=='us':
        font=(root/'arcade-jp-pixels.bin').read_bytes()
        writes.extend(english_text.construct(font,load('english_text.json')))
        writes.extend(english_supply.construct(read('comp1.bin'),inputs['comp2'],font,load('english_supply.json')))
        writes.extend(english_text.construct(font,load('restoration_text.json')))
        writes.extend(restoration_quotes.construct(inputs['comp2'],font,load('restoration_quotes.json')))
        writes.extend(restoration_story.construct(font,load('restoration_story.json')))
        writes.extend(restoration_retain.construct(read('comp1.bin'),inputs['comp2'],font,load('restoration_retain.json')))
    else:
        output,_=original_quotes.construct({'comp2':inputs['comp2'],'arcade':arcade},load('original_quotes.json')[region]);writes.extend(output)
        output,_=quote_fonts.construct({'comp2':inputs['comp2'],'font':stage_inputs['font']},load('quote_fonts.json')[region],pixels[:32*1024**2]);writes.extend(output)
        output,_=original_paragraphs.construct({'comp2':inputs['comp2']},load('original_paragraphs.json')[region]);writes.extend(output)
    result,mask=merge(writes)
    return result,mask,{'verified_bytes':sum(mask),'output_sha256':hashlib.sha256(result).hexdigest(),
                        'mask_sha256':hashlib.sha256(mask).hexdigest(),'graphics_pixels_sha256':hashlib.sha256(pixels).hexdigest()}


def self_test():
    data,mask=merge([(0xa00003,b'abc'),(0xa00004,b'bc')])
    require(sum(mask)==3 and data[3:6]==b'abc' and not mask[6], 'Typed overlap or unknown mask differs')
    for writes in ([(0xa00003,b'a'),(0xa00003,b'b')],[(0x9fffff,b'a')],[(0xdfffff,b'ab')]):
        try:merge(writes)
        except ValueError:pass
        else:raise ValueError('Accepted conflicting or out-of-bounds allocation')
    print('Typed data merge: exact overlap, unknown mask and three negative controls PASS')


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--region',choices=('us','jp'))
    parser.add_argument('--self-test',action='store_true')
    for name in ('pools','recipes','out','ending-pools'):parser.add_argument('--'+name,type=Path)
    args=parser.parse_args()
    if args.self_test:self_test();return
    require(args.region and args.pools and args.recipes and args.out and args.ending_pools,'Region, original pools, ending pools, recipes and output required')
    pool_roots=[str(p.resolve())+os.sep for p in (args.pools,args.ending_pools)];accessed=set()
    forbidden='ps2-'+('jp' if args.region=='us' else 'us')+'-'
    inherited_sources={'ps2-jp-comp1.bin','ps2-jp-comp2.bin','ps2-jp-coords390.bin'} if args.region=='us' else set()
    def watch(event,values):
        if event!='open' or not isinstance(values[0],(str,bytes,os.PathLike)):return
        path=os.fsdecode(values[0]);absolute=os.path.abspath(path)
        for pool_root in pool_roots:
            if absolute.startswith(pool_root):
                name=absolute[len(pool_root):]
                require(not name.startswith('arcade-us-') and
                        (not name.startswith(forbidden) or name in inherited_sources),
                        'Undeclared regional source dependency: '+name)
                accessed.add(name)
    sys.addaudithook(watch)
    result,mask,report=construct(args.region,args.pools,args.recipes,args.ending_pools)
    report['source_files_read']=sorted(accessed)
    report['other_ps2_region_reads']=any(n.startswith(forbidden) for n in accessed)
    report['inherited_original_source_files']=sorted(accessed & inherited_sources)
    report['usa_arcade_reads']=False
    args.out.mkdir(parents=True,exist_ok=True)
    (args.out/(args.region+'.bin')).write_bytes(result);(args.out/(args.region+'.mask')).write_bytes(mask)
    (args.out/(args.region+'.json')).write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')


if __name__=='__main__':main()
