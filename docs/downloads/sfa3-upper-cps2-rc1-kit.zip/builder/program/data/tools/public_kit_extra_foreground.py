"""Complete six-selector Hawk and Boxer foreground resource families."""
import hashlib,struct
from public_kit_graphics import require
from public_kit_stage_foreground import source as original_source,ROOT
from public_kit_frame_resources import cel as emit_cel
from public_kit_shin_frames import native_cel,compare_canvas

HAWK_CAPTIONS={0:(0xa84084,0x3ffd84),1:(0xa84084,0x3ffd9a),2:(0xa84084,0x3ffd84),3:(0xa84084,0x3ffd84)}

def source(inputs,region):
    data,_=original_source(inputs,region);table={'us':0x648bc8,'jp':0x649d38}[region];rows={}
    for selector in range(6):
        offset=struct.unpack('<h',data.read(table+selector*2,2))[0]
        for owner in (35,37):
            at=table+offset+owner*8;header=data.read(at,4);pointer=data.u32(at+4);kind,commands=data.cel(pointer)
            require(kind==2 and header==bytes.fromhex('08400000'),'Original extra foreground frame grammar')
            rows[selector,owner]=(at,pointer,header,tuple((x,y,w&65535,w>>16)for x,y,w in commands))
    return data,rows

def construct(inputs,recipe,pixels):
    for name,pin in recipe['inputs'].items():require(hashlib.sha256(inputs[name]).hexdigest()==pin,'Original extra foreground identity: '+name)
    require(hashlib.sha256(pixels).hexdigest()==recipe['pixels_sha256'],'Final extra foreground art identity')
    require(set(recipe['families'])=={'35','37'},'Complete extra foreground owner domain')
    data,rows=source(inputs,recipe['region']);native=inputs['native'];resident=set();writes=[];report={}
    for selector in range(6):
        offset=struct.unpack_from('>h',native,ROOT+selector*2)[0]
        for owner in range(32):resident.add(struct.unpack_from('>I',native,ROOT+offset+owner*8+4)[0])
    for owner in (35,37):
        family=recipe['families'][str(owner)];root=family['root'];end=family['end'];frames=family['frames'];own=[];cels={};checked=0
        require(root=={35:0xa84000,37:0xde8500}[owner] and root+60<=end<=root+0x4000 and len(frames)==6,'Extra foreground complete allocation')
        directory=bytearray(b''.join(struct.pack('>h',12+8*n)for n in range(6)))
        for selector,(target,xy,tiles) in enumerate(frames):
            address,pointer,header,blocks=rows[selector,owner];directory.extend(header+struct.pack('>I',target))
            if target<0x400000:
                require(target in resident and xy is None and not tiles,'Extra foreground canonical resident reuse')
                native_blocks,_=native_cel(native,target);checked+=compare_canvas(blocks,native_blocks,inputs['art'],pixels[0x30000*128:0x40000*128],inputs['valid'])
            else:
                require(root+60<=xy<target<end,'Extra foreground coordinate/cel bounds')
                coords,body=emit_cel(data,pointer,xy,tiles,inputs['art'],inputs['valid'],pixels[recipe['graphics_bank']*128:(recipe['graphics_bank']+65536)*128],0)
                require(coords is not None and target==xy+len(coords),'Extra foreground complete cel extent')
                require(pointer not in cels or cels[pointer]==(target,xy,tiles),'Extra foreground source cel alias')
                cels[pointer]=(target,xy,tiles);own.extend(((xy,coords),(target,body)))
        overlays=HAWK_CAPTIONS if owner==35 and recipe['region']=='us' else {}
        require(family['caption_overlays']=={str(k):list(v)for k,v in overlays.items()},'Extra foreground caption redirect domain')
        for selector,(before,after) in overlays.items():
            at=12+selector*8+4;require(struct.unpack_from('>I',directory,at)[0]==before,'Extra foreground authored caption preimage');struct.pack_into('>I',directory,at,after)
        own.append((root,bytes(directory)));covered={at+i for at,blob in own for i in range(len(blob))};used=max(covered)+1
        require(covered==set(range(root,used)) and used<=end,'Extra foreground unexplained allocation gap')
        if used<end:own.append((used,b'\xff'*(end-used)))
        writes.extend(own);report[str(owner)]={'frames':6,'new_cels':len(cels),'bytes':end-root,'resident_canvas_pixels_checked':checked,'authored_caption_overlays':len(overlays)}
    return writes,report

def main():
    import argparse,json
    from pathlib import Path
    p=argparse.ArgumentParser(description=__doc__)
    for n in ('recipe','inputs','pixels','outdir'):p.add_argument('--'+n,type=Path,required=True)
    a=p.parse_args();r=json.loads(a.recipe.read_text());paths=json.loads(a.inputs.read_text());writes,report=construct({n:Path(v).read_bytes()for n,v in paths.items()},r,a.pixels.read_bytes());data=bytearray(0x400000);mask=bytearray(len(data))
    for at,blob in writes:
        at-=0xa00000;require(all(not mask[at+i] or data[at+i]==v for i,v in enumerate(blob)),'Extra foreground aliases disagree');data[at:at+len(blob)]=blob;mask[at:at+len(blob)]=b'\1'*len(blob)
    (a.outdir/'result.bin').write_bytes(data);(a.outdir/'result.mask').write_bytes(mask);print(json.dumps(report))
if __name__=='__main__':main()
