"""Reconstruct original English records and their complete native directories.

The recipe contains placements and layout lengths, never original wording or
encoded records. All retained text is read through original PS2 directories.
"""
import hashlib
import struct
from public_kit_graphics import require
from public_kit_english_text import encode


def lines(data, notes=False):
    at=0;result=[]
    for _ in range(2):
        require(at<len(data),'Truncated original English cursor')
        cursor=data[at];at+=1
        if cursor==0x70:break
        end=data.find(b'\0',at)
        require(end>=at and all(32<=v<=126 or notes and v in (13,14) for v in data[at:end]),
                'Original English glyph domain differs')
        result.append((cursor,data[at:end]));at=end+1
    require(result and not any(data[at:]),'Original English trailing payload')
    return result


def consumed(data):
    at=0
    for _ in range(2):
        require(at<len(data),'Truncated original text')
        cursor=data[at];at+=1
        if cursor==0x70:break
        end=data.find(b'\0',at)
        require(end>=at,'Unterminated original text')
        at=end+1
    blob=data[:at];lines(blob)
    return blob


def construct(c1,c2,pixels,recipe):
    require(recipe['schema']==1 and [hashlib.sha256(b).hexdigest() for b in (c1,c2)]==recipe['source_sha256'],
            'Original English source identity differs')
    base=0x60ad00;writes=[];cursor=0xdc0000;records={};tables={}
    def add(blob):
        nonlocal cursor
        cursor+=-cursor%4;at=cursor;cursor+=len(blob)
        require(0xd00000<=at<cursor<=0xe00000,'Original English allocation bounds')
        writes.append((at,blob));return at
    hi,lo=struct.unpack_from('<2I',c1,0x44d220-0x1f0040)
    require(hi>>26==15 and lo>>26==9 and (hi>>16)&31==(lo>>21)&31==(lo>>16)&31,
            'Opening directory literal differs')
    opening=((hi&65535)*65536+struct.unpack('<h',struct.pack('<H',lo&65535))[0])&0xffffffff
    for family,language,first,count in (('BIO',opening,91,116),('DLG',0x61b570,598,754),('END',0x614e10,611,789)):
        root=struct.unpack_from('<I',c2,language-base+4)[0]-base
        header=struct.unpack_from('<H',c2,root)[0]
        require(header==2*(count+(family=='DLG')),'Original paragraph directory extent')
        pointers=[]
        for index in range(first,count):
            offset=struct.unpack_from('<H',c2,root+index*2)[0];start=root+offset
            require(offset>=header,'Original paragraph overlaps directory')
            if index==count-1 and family in ('BIO','END'):
                blob=consumed(c2[start:start+512]);require(len(lines(blob))==2,'Final paragraph termination')
            else:
                end=root+struct.unpack_from('<H',c2,root+(index+1)*2)[0]
                require(start<end<=len(c2),'Original paragraph extent')
                blob=c2[start:end]
            lines(blob,family=='END' and 748<=index<=766)
            rid=f'{family}_{index}';records[rid]=blob;pointers.append(add(blob))
        tables[family]=(add(struct.pack('>'+str(len(pointers))+'I',*pointers)),first,pointers)
    cursor=0xd50000
    root=struct.unpack_from('<I',c2,0xa104)[0]-base
    offsets=struct.unpack_from('<40H',c2,root)
    require(min(offsets)>=80,'Original quote directory extent')
    owners=(21,23,32,33,34,35);quote_rows={};owner_groups={}
    for owner in range(40):owner_groups[owner]=[i for i in range(40) if offsets[i]==offsets[owner]]
    for owner in (*owners,30,31):
        start=root+offsets[owner];header=struct.unpack_from('<9H',c2,start)
        require(header[0]==18 and header[-1]==0 and list(header[:8])==sorted(set(header[:8])),
                'Original eight-quote directory differs')
        native=bytearray(18);body=bytearray();relative=[];blobs=[]
        for slot,offset in enumerate(header[:8]):
            source=c2[start+offset:start+(header[slot+1] if slot<7 else offset+512)]
            # The retained Dolls directory has a single-line record bounded by
            # its next offset, without a separate 0x70 cursor terminator.
            if owner in (30,31) and slot<7:
                end=source.find(b'\0')
                if end>=0 and not any(source[end+1:]):source=source[:end+1]+b'\x70'
            blob=consumed(source);blobs.append(blob)
            relative.append(18+len(body));body.extend(blob);body.extend(bytes(len(body)%2))
            quote_rows[(owner,slot)]=blob
        if owner not in owners:continue
        struct.pack_into('>9H',native,0,*relative,0);at=add(bytes(native+body));pairs=[]
        for blob,offset in zip(blobs,relative):
            xy=[((x if x<128 else x-256)+(i+1)*8,row*16)
                for row,(x,text) in enumerate(lines(blob)) for i in range(len(text))]
            coordinates=add(b''.join(struct.pack('>hh',*v) for v in xy));pairs.extend((at+offset,coordinates))
        add(struct.pack('>66I',*(pairs+[0]*(66-len(pairs)))))
    require(cursor==recipe['official_quote_end'],'Original quote allocation ordering differs')
    # Later authored paragraphs replace pointers, leaving the complete original
    # records physically retained. Rebuild each final table as one resource.
    for family,(at,first,pointers) in tables.items():
        for index,target in recipe['paragraph_redirects'][family]:
            require(first<=index<first+len(pointers),'Paragraph selector outside directory')
            pointers[index-first]=target
        writes=[(a,b) for a,b in writes if a!=at]
        writes.append((at,struct.pack('>'+str(len(pointers))+'I',*pointers)))
    require([r['index'] for r in recipe['hawk']['records']]==[113,114,115],'Complete Hawk opening selector domain')
    hawk_base=recipe['hawk']['base'];offsets=[]
    for row in recipe['hawk']['records']:
        writes.append((row['address'],records['BIO_'+str(row['index'])]))
        offset=row['address']-hawk_base
        require(-32768<=offset<0,'Hawk original English signed reach')
        offsets.append(offset)
    writes.append((hawk_base+113*2,struct.pack('>3h',*offsets)))
    for row in recipe['retained']:
        owner,slot=row['owner'],row['slot'];source=quote_rows[(21 if owner==37 else owner,slot)]
        text=' '.join(line.decode('ascii').strip() for _,line in lines(source))
        shown=[];pos=0
        for length in row['row_lengths']:
            shown.append(text[pos:pos+length]);pos+=length+1
        require(' '.join(shown)==text,'Retained quote layout changes source wording: '+str((owner,slot,row['row_lengths'],len(text))))
        blob,coords=encode(shown,'quote',row['advance'],pixels)
        writes.extend(((row['address'],blob),(row['coordinates'],coords)))
    placed={row['id']:row['address'] for row in recipe['quotes']}
    require(len(placed)==len(recipe['quotes']),'Duplicate selected quote')
    mapping=c2[0xa120:0xa120+40];directed=[0]*1600;generic=[0]*320
    for winner in range(40):
        primary=[owner for owner in owner_groups[winner] if any(rid.startswith(f'Z3U-Q-{owner:02d}-') for rid in placed)]
        if not primary:continue
        require(len(primary)==1,'Ambiguous original quote owner')
        owner=primary[0]
        for opponent,slot in enumerate(mapping):directed[winner*40+opponent]=placed.get(f'Z3U-Q-{owner:02d}-S{slot:02d}',0)
        for slot in range(8):generic[winner*8+slot]=placed.get(f'Z3U-Q-{owner:02d}-S{slot:02d}',0)
    require({v for v in directed+generic if v}==set(placed.values()),'Quote selection does not reach complete installed corpus')
    writes.append((recipe['selection'],struct.pack('>1920I',*(directed+generic))))
    for chunk in recipe['chunks']:
        rows=recipe['quotes'][chunk['first']:chunk['first']+chunk['count']]
        require(len(rows)==chunk['count'] and 1<=len(rows)<=128,'Quote coordinate lookup extent')
        writes.append((chunk['address'],b''.join(struct.pack('>II',r['address'],r['coordinates']) for r in rows)))
    return writes


def self_test():
    require(lines(b'\x01ABC\0\x70\0')==[(1,b'ABC')],'Original one-line record grammar')
    require(consumed(b'\x01ABC\0\x02DEF\0unused')==b'\x01ABC\0\x02DEF\0','Original two-line extent')
    require(lines(b'\x01\x0d\x0e\0\x70',True)==[(1,b'\x0d\x0e')],'Source music glyphs')
    for blob in (b'',b'\x01ABC',b'\x01ABC\0\x70x',b'\x01\x0f\0\x70'):
        try:lines(blob)
        except ValueError:pass
        else:raise ValueError('Accepted invalid original English record')
    print('Original English record extents and four rejection controls PASS')


if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--self-test',action='store_true',required=True)
    parser.parse_args();self_test()
