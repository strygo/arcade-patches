"""Original Guile collision, attack and frame-event data in native layouts."""
import hashlib
import struct

from public_kit_actor import Data
from public_kit_graphics import require


def construct(comp2, actor_recipe, frame_bindings, recipe):
    data = Data(comp2, actor_recipe['base'], b'', 0)
    indices_table, events_table, variants_table = recipe['tables']
    indices = data.u32(indices_table+32*4)
    variants = data.u32(variants_table+32*4)
    banks = [data.u32(variants+i*4) for i in range(3)]
    require(len(set(banks)) == 1, 'Guile collision ISM banks differ')
    bank = banks[0]
    offsets = struct.unpack('<5h', data.read(bank, 10))
    require(offsets[0] == 10 and all(a < b for a, b in zip(offsets, offsets[1:])),
            'Collision lane header differs')
    counts = [(b-a)//8 for a, b in zip(offsets, offsets[1:])]
    require(counts == [80, 64, 64, 8] and all((b-a)%8 == 0 for a,b in zip(offsets,offsets[1:])),
            'Collision lane extents differ')
    lanes = data.read(bank+10, offsets[-1]-10)
    lanes = struct.pack('>'+str(len(lanes)//2)+'h', *struct.unpack('<'+str(len(lanes)//2)+'h', lanes))
    frames = [data.read(row['source'], 20) for row in frame_bindings]
    require(len(frames) == actor_recipe['frames'], 'Combat frame inventory differs')
    selectors = {}
    for frame in frames:
        row = data.read(indices+frame[8]*4, 4)
        require(all(value < count for value,count in zip(row, counts)), 'Collision selector outside lane')
        require(frame[9] < 88, 'Frame attack selector outside bank')
        selectors[frame[8]] = row
    selected = bytearray((max(selectors)+1)*4)
    for index,row in selectors.items():
        selected[index*4:index*4+4] = row
    attacks = data.read(bank+offsets[-1], 88*32)
    attacks = b''.join(struct.pack('>4h', *struct.unpack('<4h', attacks[n:n+8]))+attacks[n+8:n+32]
                       for n in range(0, len(attacks), 32))
    packet = bytes(selected)+struct.pack('>5h', *offsets)+lanes+attacks
    require(len(packet) == 4990, 'Collision/attack allocation extent differs')
    events_at = data.u32(events_table+32*4)
    event_ids = sorted({frame[10] for frame in frames})
    events = data.read(events_at, (max(event_ids)+1)*4)
    require(len(events) == 132 and all(events[i*4:i*4+2] == bytes(2) for i in event_ids),
            'Unqualified event extent or callback')
    voice_at = data.u32(recipe['voice_directory']+32*4)
    voice = data.read(voice_at, 29*8)
    cues = list(struct.iter_unpack('<4H', voice))
    require(cues[0] == (0, 0, 0, 0) and all(row[2:] == (0, 0) for row in cues) and
            max(events[2::4]) < len(cues), 'Unqualified frame voice cue or record fields')
    voice = struct.pack('>116H', *struct.unpack('<116H', voice))+bytes(2048-len(voice))
    outputs = {'collision_attacks': packet, 'events': events, 'voice_cues': voice}
    for name, blob in outputs.items():
        require(hashlib.sha256(blob).hexdigest() == recipe['outputs'][name]['sha256'] and
                len(blob) == recipe['outputs'][name]['bytes'], 'Final combat allocation differs: '+name)
    return outputs, {
        'lane_rows': counts, 'attack_rows': 88, 'index_rows': len(selected)//4,
        'used_indices': sorted(selectors), 'event_ids': event_ids,
        'source_index_bank': indices, 'source_collision_bank': bank, 'source_events': events_at,
        'source_voice_cues': voice_at, 'voice_cue_rows': len(cues),
        'outputs': {name: {'bytes':len(blob), 'sha256':hashlib.sha256(blob).hexdigest()}
                    for name,blob in outputs.items()}}
