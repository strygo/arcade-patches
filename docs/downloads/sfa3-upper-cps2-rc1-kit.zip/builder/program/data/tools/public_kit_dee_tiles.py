"""Original Dee Scroll2 cyclic frames and complete typed rectangles."""
import hashlib
import struct
from public_kit_graphics import require


def graph(comp2,region):
    require(region in ('us','jp'),'Dee original region')
    base=0x60b080 if region=='jp' else 0x60ad00
    def read(at,size):
        require(size>0 and 0<=at-base<=len(comp2)-size,'Dee source bounds')
        return comp2[at-base:at-base+size]
    root=struct.unpack('<I',read(0x6131d4 if region=='jp' else 0x6120e4,4))[0]
    require(root==(0x98ad90 if region=='jp' else 0x9856a0),'Original Dee root identity')
    starts={n:root+struct.unpack('<h',read(root+n*2,2))[0] for n in (9,10)}
    frames={};payloads={};codes=set()
    for start in starts.values():
        at=start;seen=set()
        while at not in seen:
            require(len(seen)<128,'Unbounded Dee cycle');seen.add(at)
            raw=read(at,8);scalar=raw[:4];ptr=struct.unpack('<I',raw[4:])[0]
            require(scalar[0]>0 and scalar[1] in (0,128) and scalar[2:]==b'\0\0','Unknown Dee frame command')
            header=struct.unpack('<3H',read(ptr,6))
            require(header==(18,4,2),'Unknown Dee rectangle')
            count=(header[1]+1)*(header[2]+1)
            cells=[((code+0x1c00)&65535,attr) for attr,code in struct.iter_unpack('<HH',read(ptr+8,count*4))]
            require(all(attr&~127==0 for _,attr in cells),'Unknown Dee tile attributes')
            payloads[ptr]=(header,cells);codes.update(c for c,_ in cells)
            nxt=struct.unpack('<I',read(at+8,4))[0] if scalar[1]&128 else at+8
            frames[at]=(scalar,ptr,nxt,12 if scalar[1]&128 else 8);at=nxt
        require(at==start,'Dee cycle topology differs')
    require(len(frames)==42 and len(payloads)==8,'Dee full resource census differs')
    return starts,frames,payloads,codes


def construct(inputs,recipe,pixels):
    require(recipe['schema']==1,'Unknown Dee recipe')
    for name,pin in recipe['inputs'].items():
        require(hashlib.sha256(inputs[name]).hexdigest()==pin,'Original Dee input identity: '+name)
    require(hashlib.sha256(pixels).hexdigest()==recipe['pixels_sha256'],'Dee emitted artwork identity')
    starts,frames,payloads,codes=graph(inputs['comp2'],recipe['region'])
    bindings={int(k):v for k,v in recipe['bindings'].items()}
    require(set(bindings)==codes,'Complete Dee tile-binding census')
    for code,(native,bank) in bindings.items():
        require(bank in (0,512) and 0<=native<65536,'Dee native tile bound')
        tile=inputs['font'][code*128:(code+1)*128];require(len(tile)==128,'Dee source font bound')
        at=(40 if bank else 8)*1024**2+native*128
        require(pixels[at:at+128]==tile,'Dee complete original tile artwork differs')
    cursor=0xc30c16;fmap={};pmap={};writes=[]
    for at,(_,_,_,size) in sorted(frames.items()):fmap[at]=cursor;cursor+=size
    for at,(header,cells) in sorted(payloads.items()):
        blob=struct.pack('>3H',*header)+b''.join(struct.pack('>HH',(bindings[c][0]-0x6c00)&65535,attr|bindings[c][1]) for c,attr in cells)
        pmap[at]=cursor;writes.append((cursor,blob));cursor+=len(blob)
    for at,(scalar,ptr,nxt,size) in sorted(frames.items()):
        require(size==12 or fmap[nxt]==fmap[at]+8,'Dee successor allocation differs')
        writes.append((fmap[at],scalar+struct.pack('>I',pmap[ptr])+(struct.pack('>I',fmap[nxt]) if size==12 else b'')))
    writes.append((0xc30c00,b''.join(struct.pack('>h',fmap[starts[n]]-0xc30c00 if n in starts else 0) for n in range(11))))
    require(cursor==0xc30f7e,'Dee complete allocation extent differs')
    return writes


def main():
    import argparse,json
    from pathlib import Path
    p=argparse.ArgumentParser(description=__doc__)
    for n in ('comp2','font','pixels','recipe','outdir'):p.add_argument('--'+n,type=Path,required=True)
    a=p.parse_args();inputs={n:getattr(a,n).read_bytes() for n in ('comp2','font')}
    writes=construct(inputs,json.loads(a.recipe.read_text()),a.pixels.read_bytes());data=bytearray(0x400000);mask=bytearray(len(data))
    for at,blob in writes:
        at-=0xa00000;require(not any(mask[at:at+len(blob)]),'Overlapping Dee resources')
        data[at:at+len(blob)]=blob;mask[at:at+len(blob)]=b'\1'*len(blob)
    a.outdir.mkdir(exist_ok=True);(a.outdir/'result.bin').write_bytes(data);(a.outdir/'result.mask').write_bytes(mask)


if __name__=='__main__':main()
