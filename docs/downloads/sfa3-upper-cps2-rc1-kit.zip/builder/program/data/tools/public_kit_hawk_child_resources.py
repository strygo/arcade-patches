"""Complete original T. Hawk compact child roots, frames, cels and tile checks."""
import hashlib
import struct
from public_kit_actor import Data
from public_kit_frame_resources import cel
from public_kit_graphics import require

OWNERS={35:(0x911178,17)}


def graph(inputs,region,owner):
    require(region in ('us','jp')and owner in OWNERS,'Original auxiliary owner/region')
    data=Data(inputs['comp2'],0x60ad00 if region=='us'else 0x60b080,inputs['coords'],0xb04000)
    root,count=OWNERS[owner];root+=0x5700 if region=='jp'else 0
    _,targets=data.root(root);require(len(targets)==count,'Complete original child root extent')
    frames={};pending=list(targets)
    while pending:
        at=pending.pop()
        if at in frames:continue
        require(at%4==0 and len(frames)<512,'Bounded aligned original child graph')
        raw=data.read(at,8);nxt=data.u32(at+8)if raw[1]&128 else None if raw[1]&64 else at+8
        frames[at]=(raw[:4],data.u32(at+4),nxt,12 if raw[1]&128 else 8)
        if nxt is not None:pending.append(nxt)
    return data,targets,frames


def construct(inputs,recipe,pixels):
    for name,pin in recipe['inputs'].items():
        value=inputs[name];require(len(value)==pin['bytes']and hashlib.sha256(value).hexdigest()==pin['sha256'],'Original auxiliary '+name+' identity')
    require(hashlib.sha256(pixels).hexdigest()==recipe['graphics_pixels_sha256'],'Complete reconstructed auxiliary artwork identity')
    require([r['owner']for r in recipe['owners']]==[35],'Complete auxiliary owner domain')
    writes=[];reports=[]
    for row in recipe['owners']:
        owner=row['owner'];data,targets,frames=graph(inputs,recipe['region'],owner)
        mapping={r[0]:r for r in row['frames']};require(len(mapping)==len(row['frames'])and set(mapping)==set(frames),'Complete child frame inventory')
        cels={r[0]:r for r in row['cels']};require(len(cels)==len(row['cels'])and set(cels)=={r[1]for r in frames.values()},'Complete child cel inventory')
        for source,native,xy,tiles in row['cels']:
            coords,body=cel(data,source,xy,tiles,inputs['pixels'+str(owner)],inputs['mask'+str(owner)],pixels,2)
            if coords is not None:writes.append((xy,coords))
            writes.append((native,body))
        for source,(prefix,source_cel,nxt,size)in frames.items():
            _,native=mapping[source];value=prefix+struct.pack('>I',cels[source_cel][1])
            if size==12:value+=struct.pack('>I',mapping[nxt][1])
            elif nxt is not None:require(mapping[nxt][1]==native+8,'Complete native child fallthrough')
            writes.append((native,value))
        root=row['root'];offsets=[mapping[at][1]-root for at in targets]+[0]
        require(all(-32768<=v<=32767 for v in offsets),'Native child relative root reach')
        writes.append((root,struct.pack('>'+str(len(offsets))+'h',*offsets)))
        reports.append({'owner':owner,'frames':len(frames),'cels':len(cels),'root_words':len(offsets),'artwork':'every tile in every original cel checked'})
    return writes,reports
