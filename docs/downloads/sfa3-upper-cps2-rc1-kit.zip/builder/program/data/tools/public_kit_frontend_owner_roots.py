"""Complete authored continue/VS owner routing directories.

The native owner readers consume pointer,u16 bank flag,u16 reserved rows.
The original fixes2 extension policy installs the four added fighter roots;
fixes25.RECORD_OWNERS supplies the five later VS aliases and Hawk bank flag.
Pointed-to frame/cel resources are qualified separately.
"""
import struct
from public_kit_graphics import require

NAMES=('continue23','added32','added33','added34','added35','vs21','vs23','vs30','vs31')


def construct(recipe):
    bindings=recipe['bindings'];require(set(bindings)==set(NAMES),'Complete frontend allocation binding inventory')
    require(all(isinstance(v,int)and v%2==0 and (0x300000<=v<0x400000 or 0xa00000<=v<0xe00000)for v in bindings.values()),'Frontend allocation address/ABI domain')
    continuation={23:(bindings['continue23'],0),**{owner:(bindings['added'+str(owner)],int(owner!=35))for owner in range(32,36)}}
    versus={owner:(bindings['added'+str(owner)],1)for owner in range(32,36)}
    versus.update({owner:(bindings['vs'+str(owner)],1)for owner in (21,23,30,31)})
    versus[37]=versus[21]
    writes=[]
    for address,routes in ((0xaa0dd0,continuation),(0xaa0f00,versus)):
        blob=b''.join(struct.pack('>IHH',*routes.get(owner,(0,0)),0)for owner in range(38))
        require(len(blob)==304,'Complete 38-row frontend owner directory')
        writes.append((address,blob))
    return writes,{'tables':2,'rows_per_table':38,'bytes':608,'pointer_and_bank_flags_only':True,'pointed_resources':'separately qualified'}
