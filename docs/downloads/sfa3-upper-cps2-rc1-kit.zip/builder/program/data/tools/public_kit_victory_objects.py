"""Reconstruct complete promoted victory portraits from original regional media."""
import hashlib,struct
from public_kit_graphics import require
from public_kit_hover_objects import cel,tiles_for

OWNERS=(21,30,31)
NATIVE_HEADS=0x301fa2


def frame(data,table,selector,owner,endian):
    return table+struct.unpack_from(endian+'H',data,table+selector*2)[0]+owner*8


def sources(comp2,region):
    require(region in ('us','jp'),'Victory source region')
    base=0x60ad00 if region=='us' else 0x60b080
    table=0x69f00 if region=='us' else 0x6ae30
    result={}
    for owner,count in zip(OWNERS,(171,105,121)):
        records=[];value=None
        for selector in range(12,18):
            at=frame(comp2,table,selector,owner,'<')
            current=cel(comp2,struct.unpack_from('<I',comp2,at+4)[0]-base,'<',base)
            if value is None:value=current
            require(value==current,'Complete victory pose aliases differ')
            records.append((selector,at))
        expanded=list(tiles_for(value['commands']))
        require(len(expanded)==count,'Complete victory tile census')
        result[str(owner)]=(expanded,records)
    return result


def construct(inputs,recipe,pixels):
    for name,pin in recipe['inputs'].items():require(hashlib.sha256(inputs[name]).hexdigest()==pin,'Victory original identity '+name)
    require(hashlib.sha256(pixels).hexdigest()==recipe['pixels_sha256'],'Victory composed graphics identity')
    records=sources(inputs['comp2'],recipe['region'])
    require(set(recipe['codes'])==set(records),'Complete victory owner domain')
    writes=[];cursor=0x3f9000;patches={}
    for owner,(commands,aliases) in records.items():
        codes=recipe['codes'][owner];require(len(codes)==len(commands),'Victory tile binding extent')
        coords=b''.join(struct.pack('>2h',x,y) for _,_,x,y in commands)
        xy=cursor;writes.append((cursor,coords));cursor+=len(coords)
        body=struct.pack('>3HI',2,len(commands),len(commands)-1,xy)
        body+=b''.join(struct.pack('>2H',code,attr) for code,(_,attr,_,_) in zip(codes,commands))
        dest=cursor;writes.append((cursor,body));cursor+=len(body)
        for selector,at in aliases:
            native=frame(inputs['native'],NATIVE_HEADS,selector,int(owner),'>')
            require(inputs['comp2'][at:at+4]==inputs['native'][native:native+4],'Original victory frame header differs')
            require(struct.unpack_from('>I',inputs['native'],native+4)[0]==0x3075ec,'Original victory fallback differs')
            output=inputs['comp2'][at:at+4]+struct.pack('>I',dest)
            require(native not in patches or patches[native]==output,'Victory frame aliases disagree');patches[native]=output
        for code,(source,_,_,_) in zip(codes,commands):
            source+=0x1c00;target=code+0x30000
            require((source+1)*128<=len(inputs['font']) and (target+1)*128<=len(pixels),'Victory tile bounds')
            require(inputs['font'][source*128:(source+1)*128]==pixels[target*128:(target+1)*128],'Complete original victory tile differs')
    require(len(patches)==12 and cursor<0x3fc000,'Whole victory arena and alias census')
    writes.extend(sorted(patches.items()))
    return writes,{'portraits':3,'tiles':397,'unique_frames':12,'arena_bytes':cursor-0x3f9000}


def main():
    import argparse,json
    from pathlib import Path
    p=argparse.ArgumentParser(description=__doc__)
    for n in ('recipe','inputs','pixels','outdir'):p.add_argument('--'+n,type=Path,required=True)
    a=p.parse_args();inputs={n:Path(v).read_bytes() for n,v in json.loads(a.inputs.read_text()).items()}
    writes,report=construct(inputs,json.loads(a.recipe.read_text()),a.pixels.read_bytes());data=bytearray(0x400000);mask=bytearray(len(data))
    for at,blob in writes:
        require(all(not mask[at+i] or data[at+i]==v for i,v in enumerate(blob)),'Victory write aliases disagree');data[at:at+len(blob)]=blob;mask[at:at+len(blob)]=b'\1'*len(blob)
    (a.outdir/'result.bin').write_bytes(data);(a.outdir/'result.mask').write_bytes(mask);print(json.dumps(report))


if __name__=='__main__':main()
