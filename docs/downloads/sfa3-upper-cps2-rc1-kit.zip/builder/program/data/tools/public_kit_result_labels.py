"""Whole original result-label frames, type12 cels, coordinates and font pixels."""
import hashlib
import struct
from public_kit_graphics import require

FAMILIES=((34,0xc11a32),(35,0xc79722),(23,0xbcb1c2),(32,0xb7b74c),(33,0xb7b7a6))
FRAMES={32:0xb7b714,33:0xb7b71c}


def source(comp2,region,owner):
    base=0x60ad00 if region=='us' else 0x60b080
    table=0x35ba40 if region=='us' else 0x360dc0
    mapping=0xbb50 if region=='us' else 0xc8c0
    selector=comp2[mapping+owner]
    if owner!=23: require(selector==comp2[mapping+owner+40],'Original label regional alias')
    # Evil uses its explicit original Upper word instead of the default Ryu alias.
    if owner==23:
        require(comp2[mapping+23]==0 and comp2[mapping+63]==45,'Original Evil alternate label modes')
        selector=comp2[mapping+63]
    at=table+struct.unpack_from('<H',comp2,table+selector*2)[0]
    ptr=struct.unpack_from('<I',comp2,at+4)[0]-base
    kind,total,last,pad,xy=struct.unpack_from('<4HI',comp2,ptr)
    require(kind==12 and last==9 and pad==0,'Original result-label type12 grammar')
    require(0<=xy-base<=len(comp2)-40,'Complete result-label coordinate bounds')
    points=list(struct.iter_unpack('<hh',comp2[xy-base:xy-base+40]))
    commands=list(struct.iter_unpack('<HH',comp2[ptr+12:ptr+52]))
    require(len(commands)==10,'Complete result-label command extent')
    measured=sum(((a>>8&15)+1)*((a>>12&15)+1)for _,a in commands)
    require(0<=measured-total<=5,'Original result-label budget conversion')
    return at,points,commands,measured


def construct(inputs,recipe,pixels):
    for name,pin in recipe['inputs'].items():
        value=inputs[name];require(len(value)==pin['bytes'] and hashlib.sha256(value).hexdigest()==pin['sha256'],'Original label input identity: '+name)
    require(hashlib.sha256(pixels).hexdigest()==recipe['pixels_sha256'],'Qualified label graphics identity')
    require(len(recipe['families'])==len(FAMILIES),'Complete result-label family inventory')
    writes=[];reports=[]
    for (owner,target),row in zip(FAMILIES,recipe['families']):
        at,points,commands,total=source(inputs['comp2'],recipe['region'],owner)
        require(len(row['tiles'])==10,'Complete result-label block allocation')
        converted=[];checked=0
        for (code,attr),native in zip(commands,row['tiles']):
            require(0<=native<65536,'Result-label tile allocation range')
            for y in range((attr>>12&15)+1):
                for x in range((attr>>8&15)+1):
                    old=(code&~15)+((code+x)&15)+16*y
                    new=(native&~15)+((native+x)&15)+16*y
                    tile=inputs['font'][(old+0x1c00)*128:(old+0x1c01)*128]
                    physical=(new+0x16c00)*128
                    require(len(tile)==128 and pixels[physical:physical+128]==tile,'Complete original result-label block pixels')
                    checked+=1
            converted.append((native,attr))
        require(checked==total,'Complete label tile accounting')
        frame=inputs['comp2'][at:at+4]+struct.pack('>I',target)
        coords=b''.join(struct.pack('>hh',*point)for point in points)
        cel=struct.pack('>3HI',12,total,9,target-40)+b''.join(struct.pack('>HH',*command)for command in converted)
        frame_at=FRAMES.get(owner,target-48)
        writes.extend(((frame_at,frame),(target-40,coords+cel)))
        reports.append({'owner':owner,'bytes':98,'tiles_checked':checked,'source_frame_offset':at,'frame':hex(frame_at),'coordinates':hex(target-40),'cel':hex(target)})
    return writes,reports
