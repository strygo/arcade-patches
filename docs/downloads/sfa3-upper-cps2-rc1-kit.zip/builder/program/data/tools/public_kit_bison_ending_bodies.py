"""Complete original Bison ending graphs and native canvas-backed cel packing."""
import hashlib,struct
from public_kit_actor import Data
from public_kit_blocks import BlockPacker,grid_code
from public_kit_graphics import require,tile_variants
from public_kit_shin_frames import native_cel,compare_canvas

DEMAND=(3,66,68,70,71,92,93,95)
PRIVATE=(92,93,95)


def graph(data,targets):
    frames={};cels={};todo=list(targets)
    while todo:
        at=todo.pop()
        if at in frames:continue
        raw=data.read(at,20);_,value,nxt=data.frame(at);address=data.u32(at+4)
        frames[at]=(raw,address,nxt,24 if raw[1]&128 else 20)
        cels[address]=(value[0],tuple((x,y,w&65535,w>>16)for x,y,w in value[1]))
        require(len(frames)<4096,'Bounded complete Bison ending graph')
        if nxt is not None:todo.append(nxt)
    return frames,cels


def construct(inputs,recipe,pixels):
    for name,pin in recipe['inputs'].items():require(len(inputs[name])==pin['bytes']and hashlib.sha256(inputs[name]).hexdigest()==pin['sha256'],'Original Bison ending input '+name)
    require(set(recipe['inputs'])=={'arcade','comp2','coords','pixels','mask'}and recipe['region']in ('us','jp'),'Complete Bison ending input domain')
    region=recipe['region'];base=0x60ad00 if region=='us'else 0x60b080
    data=Data(inputs['comp2'],base,inputs['coords'],0xb04000)
    root=data.u32((0x619b50 if region=='us'else 0x61ac40)+10*4);_,targets=data.root(root)
    require(len(targets)==96,'Complete original Bison ending action directory')
    frames,cels=graph(data,[targets[n]for n in DEMAND]);bindings={int(k):v for k,v in recipe['cels'].items()}
    require(set(bindings)==set(cels)and len(cels)==43,'Complete Bison ending cel binding family')
    native_pixels=pixels[:8<<20];pool=inputs['pixels'];valid=inputs['mask'];packer=BlockPacker(native_pixels)
    native_tiles={}
    for at in range(0,len(native_pixels),128):native_tiles.setdefault(native_pixels[at:at+128],at//128)
    converted={};cache={};checked=0;whole=0;split=0;flipped=0
    for address,(kind,blocks)in cels.items():
        target=bindings[address]
        if target<0xa00000:
            observed,_=native_cel(inputs['arcade'],target)
            checked+=compare_canvas(blocks,observed,pool,native_pixels,valid);continue
        require(0xbe0000<=target<0xbe05ce and kind in (0,2),'Owned Bison cel allocation')
        result=[]
        for x,y,code,attr in blocks:
            width,height=(attr>>8&15)+1,(attr>>12&15)+1
            codes=[grid_code(code,dx,dy)for dy in range(height)for dx in range(width)]
            require(all(n<len(valid)and valid[n]for n in codes),'Original Bison packed tile domain')
            images=[pool[n*128:(n+1)*128]for n in codes];native=packer.add(width,height,images,attr)
            if native<65536:
                packer.check(native,width,height,images,attr);result.append((x,y,native,attr));whole+=1;continue
            split+=1
            for dy in range(height):
                for dx in range(width):
                    sx=width-1-dx if attr&32 else dx;sy=height-1-dy if attr&64 else dy
                    source=grid_code(code,sx,sy)
                    if source not in cache:
                        variants=tile_variants(pool[source*128:(source+1)*128]);match=next(((native_tiles[v],flip)for flip,v in enumerate(variants)if v in native_tiles),None)
                        require(match is not None,'No original native tile for complete Bison cel');cache[source]=match;flipped+=bool(match[1])
                    tile,flip=cache[source];result.append((x+16*dx,y+16*dy,tile,(attr&255)^(flip<<5)))
        checked+=compare_canvas(blocks,result,pool,native_pixels,valid);converted[address]=result
    require(len(converted)==7,'Complete seven recomposed Bison cels')
    payload=bytearray();celmap=dict(bindings)
    for address,blocks in sorted(converted.items()):
        xy=0xbe0000+len(payload);payload.extend(b''.join(struct.pack('>hh',x,y)for x,y,_,_ in blocks))
        require(celmap[address]==0xbe0000+len(payload),'Original complete Bison cel placement')
        total=sum(((a>>8&15)+1)*((a>>12&15)+1)for _,_,_,a in blocks)
        payload.extend(struct.pack('>3HI',2,total,len(blocks)-1,xy));payload.extend(b''.join(struct.pack('>2H',tile,attr)for _,_,tile,attr in blocks))
    require(len(payload)==1486,'Complete Bison cel allocation extent')
    private,_=graph(data,[targets[n]for n in PRIVATE]);mapping={};body=bytearray()
    for at,row in sorted(private.items()):mapping[at]=0xa98200+len(body);body.extend(bytes(row[3]))
    for at,(raw,cel,nxt,size)in sorted(private.items()):
        frame=bytearray(raw);struct.pack_into('>I',frame,4,celmap[cel])
        if size==24:frame.extend(struct.pack('>I',mapping[nxt]))
        elif nxt is not None:require(mapping[nxt]==mapping[at]+20,'Complete Bison ending fallthrough')
        off=mapping[at]-0xa98200;body[off:off+size]=frame
    roots=bytearray(8)
    for selector in PRIVATE:struct.pack_into('>h',roots,(selector-92)*2,mapping[targets[selector]]-0xa980c8)
    require(len(private)==35 and len(body)==716,'Complete three private Bison action graphs')
    return [(0xbe0000,bytes(payload)),(0xa98180,bytes(roots)),(0xa98200,bytes(body))],{'bytes':2210,'cels':43,'recomposed_cels':7,'private_frames':35,'whole_blocks':whole,'split_blocks':split,'flipped_tiles':flipped,'canvas_pixels_checked':checked}
