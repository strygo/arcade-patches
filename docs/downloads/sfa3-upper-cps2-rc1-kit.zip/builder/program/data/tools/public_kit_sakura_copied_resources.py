"""Complete retained Sakura primary frames with original collision-row remapping."""
import hashlib
import struct
from public_kit_graphics import require
from public_kit_copied_directories import domain,u32
from public_kit_dhalsim_tables import Owner,direct_projection,repoint_existing,deficiencies,eligible


def construct(inputs,recipe):
    for name,pin in recipe['inputs'].items():
        value=inputs[name];require(len(value)==pin['bytes']and hashlib.sha256(value).hexdigest()==pin['sha256'],'Original Sakura frame '+name+' identity')
    arcade=inputs['arcade'];comp2=inputs['comp2'];region=recipe['region'];owner=13
    base=0x60ad00 if region=='us'else 0x60b080;delta=0 if region=='us'else 0x5700
    slong=lambda at:struct.unpack_from('<I',comp2,at-base)[0]
    sbank=slong(0x749838+delta+owner*4);sv=slong(0x749338+delta+owner*4)
    source=Owner(comp2,base,sbank,slong(0x7493d8+delta+owner*4),slong(0x749478+delta+owner*4),[slong(sv+i*4)for i in range(3)],'<')
    bank=u32(arcade,0xde6a0+owner*4);indices=u32(arcade,0xde320+owner*4);events=u32(arcade,0xde3a0+owner*4);variants=u32(arcade,0xde2a0+owner*4)
    native=Owner(bytearray(arcade),0,bank,indices,events,[u32(arcade,variants+i*4)for i in range(3)],'>')
    direct=direct_projection(source,native);remapped=repoint_existing(source,native)
    event_remaps=remap_events(source,native)
    tables,table_report=relocate_missing(source,native)
    _,targets,records=domain(arcade,13,2,49,{19:0xaba0b4,20:0xaba1a8})
    cursor=0xab7b50;mapping={}
    for at,size in records.items():mapping[at]=cursor;cursor+=size
    require(cursor==0xaba0b4 and len(records)==470,'Complete retained primary allocation extent')
    writes=list(tables)
    for at,size in records.items():
        value=bytearray(native.read(at,size))
        if value[1]&128:
            nxt=u32(value,20);require(nxt in mapping,'Retained primary successor closure');struct.pack_into('>I',value,20,mapping[nxt])
        elif not value[1]&64:require(mapping[at+20]==mapping[at]+20,'Retained primary fallthrough allocation')
        writes.append((mapping[at],bytes(value)))
    return writes,{'frames':len(records),'bytes':sum(len(v)for _,v in writes),'source_direct_bytes':direct,'source_remapped_frames':remapped,'tables':table_report,'event_remaps':event_remaps,'artwork':'separate qualification'}


def relocate_missing(source,native):
    users,unmatched,want,by_frame=deficiencies(source,native);banks=sorted(set(native.variants))
    offsets={b:struct.unpack('>5h',native.read(b,10))for b in banks}
    rows={b:[[native.read(b+offsets[b][lane]+i*8,8)for i in range((offsets[b][lane+1]-offsets[b][lane])//8)]for lane in range(4)]for b in banks}
    allframes=[at for family in native.families for frames,_ in family for at in frames]
    count=max(native.blob[at+8]for at in allframes)+1
    selectors=[native.read(native.indices+i*4,4)for i in range(count)];updates=[];held=0
    for at,contexts in sorted(by_frame.items()):
        desired=eligible(at,contexts,users,unmatched,want)
        if desired is None:held+=1;continue
        through=sorted({native.variants[u[0]]for u in users[at]});frame=bytearray(native.read(at,20));frame[0]=desired[0]
        if not all(native.read(b+offsets[b][4]+frame[9]*32,32)==desired[1]for b in through):
            hits=[i for i in sorted({native.blob[a+9]for a in allframes})if all(native.read(b+offsets[b][4]+i*32,32)==desired[1]for b in through)]
            if not hits:held+=1;continue
            frame[9]=hits[0]
        selected=[]
        for lane in range(4):
            n=max(len(rows[b][lane])for b in banks)
            hits=[i for i in range(n)if all(i<len(rows[b][lane])and rows[b][lane][i]==desired[2][lane]for b in through)]
            if not hits:
                for b in banks:
                    while len(rows[b][lane])<n:rows[b][lane].append(rows[b][lane][0])
                    rows[b][lane].append(desired[2][lane])
                hits=[n]
            selected.append(hits[0])
        require(max(selected)<256,'Native collision row index reach')
        if bytes(selected)not in selectors:selectors.append(bytes(selected))
        frame[8]=selectors.index(bytes(selected));updates.append((at,frame))
    writes=[];sizes=[]
    for b,target in zip(banks,(0xaa4000,)):
        offsets_new=[10]
        for lane in rows[b]:offsets_new.append(offsets_new[-1]+len(lane)*8)
        attacks=max(native.blob[at+9]for slot,family in enumerate(native.families)if native.variants[slot//4]==b for frames,_ in family for at in frames)+1
        blob=struct.pack('>5h',*offsets_new)+b''.join(b''.join(lane)for lane in rows[b])+native.read(b+offsets[b][4],attacks*32)
        writes.append((target,blob));sizes.append(len(blob))
    writes.append((0xaa52d0,b''.join(selectors)));sizes.append(len(selectors)*4)
    require(sizes==[4802,380],'Complete batch8 Sakura table allocation extents: '+str(sizes))
    for at,value in updates:native.blob[at:at+20]=value
    return writes,{'initial_selectors':count,'selectors':len(selectors),'remapped_frames':len(updates),'held_contexts':held,'table_bytes':sizes}



def remap_events(source,native):
    demands={};tainted=set();used=set()
    for slot,family in enumerate(native.families):
        for action,(frames,loop)in enumerate(family):
            sf,sl=source.families[slot][action]
            used.update(native.blob[a+10]for a in frames)
            if len(sf)!=len(frames)or sl!=loop:tainted.update(frames);continue
            for at,src in zip(frames,sf):
                value=source.read(source.events+source.read(src,20)[10]*4,4)
                demands.setdefault(at,set()).add(value)
    changes=0
    for at,values in demands.items():
        if at in tainted or len(values)!=1:continue
        wanted=next(iter(values));current=native.read(native.events+native.blob[at+10]*4,4)
        if wanted==current:continue
        indices=[i for i in sorted(used)if native.read(native.events+i*4,4)==wanted]
        if indices:native.blob[at+10]=indices[0];changes+=1
    return changes
