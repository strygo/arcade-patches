"""Complete original shared special bank and extended34-owner directory."""
import hashlib,struct
from public_kit_graphics import require
from public_kit_palettes import catalog
from public_kit_color_arena import resources

def construct(comp2,native,recipe):
    require(recipe['schema']==1 and hashlib.sha256(comp2).hexdigest()==recipe['source_sha256'] and hashlib.sha256(native).hexdigest()==recipe['native_sha256'],'Shared special source identities')
    arrays=catalog(comp2,recipe['region']);bank=arrays['special:32'][1][:32]
    require(bank==arrays['special:33'][1][:32] and hashlib.sha256(bank).hexdigest()=='afc048f33360a0a5cda966dc57b2d420d306c90a76c0fc8b4ce8dd80dcd79640','Original shared special bank identity')
    writes,_=resources(comp2,native,recipe['region']);start,arena=writes[0]
    require(start==0x3e0000 and len(arena)>384,'Original complete special arena')
    expected=start+len(arena)-128
    require(recipe['original_directory']==expected,'Complete original special directory location')
    data=arena[-128:]+struct.pack('>2I',0xbbc088,0xbbc088)+bank
    require(len(data)==168,'Complete shared special family extent')
    return [(0xbbc000,data)],{'bytes':168,'original_palette_bytes':32,'complete_owner_directories':1,'directory_entries':34}


def main():
    import argparse,json
    from pathlib import Path
    p=argparse.ArgumentParser(description=__doc__)
    for n in ('comp2','native','recipe','outdir'):p.add_argument('--'+n,type=Path,required=True)
    a=p.parse_args();writes,report=construct(a.comp2.read_bytes(),a.native.read_bytes(),json.loads(a.recipe.read_text()));data=bytearray(0x400000);mask=bytearray(len(data))
    for at,blob in writes:at-=0xa00000;data[at:at+len(blob)]=blob;mask[at:at+len(blob)]=b'\1'*len(blob)
    (a.outdir/'result.bin').write_bytes(data);(a.outdir/'result.mask').write_bytes(mask);print(json.dumps(report))
if __name__=='__main__':main()
