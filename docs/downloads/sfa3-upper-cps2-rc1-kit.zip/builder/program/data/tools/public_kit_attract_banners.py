"""Complete original attract banner cels with all native font-block pixels."""
import hashlib
import struct
from public_kit_graphics import require

SOURCES=(0x96c26c,0x96cbcc,0x96cf56,0x96cfcc,0x96d042,0x96d0c0,0x96d13e,0x96d1bc)
TARGETS=(0xac95aa,0xac9620,0xac96c6,0xac973c,0xac97b2,0xac9830,0xac98ae,0xac992c)


def construct(inputs,recipe,pixels):
    region=recipe['region'];require(region in ('us','jp'),'Original banner region')
    for name,pin in recipe['inputs'].items():
        blob=inputs[name];require(len(blob)==pin['bytes'] and hashlib.sha256(blob).hexdigest()==pin['sha256'],'Original banner input identity: '+name)
    require(hashlib.sha256(pixels).hexdigest()==recipe['pixels_sha256'],'Qualified banner graphics identity')
    base=0x60ad00 if region=='us'else 0x60b080;shift=0 if region=='us'else 0x56f0
    comp2=inputs['comp2'];font=inputs['font'];writes=[];reports=[]
    require(len(recipe['cels'])==len(SOURCES),'Complete banner cel inventory')
    for row,source,target in zip(recipe['cels'],SOURCES,TARGETS):
        at=source+shift-base;require(0<=at<len(comp2)-6,'Original banner header bounds')
        kind,total,last=struct.unpack_from('<3H',comp2,at)
        require(kind==8 and 0<=last<32,'Original inline banner cel grammar')
        count=last+1;require(at+6+count*8<=len(comp2),'Original banner command extent')
        commands=list(struct.iter_unpack('<HHhh',comp2[at+6:at+6+count*8]))
        require(len(row['tiles'])==count,'Complete banner block allocation domain')
        require(sum(((attr>>8&15)+1)*((attr>>12&15)+1)for _,attr,_,_ in commands)==total,'Original banner tile budget')
        out=bytearray(struct.pack('>3H',kind,total,last));checked=0
        for (code,attr,x,y),native in zip(commands,row['tiles']):
            require(0<=native<65536,'Native banner block tile allocation')
            width,height=(attr>>8&15)+1,(attr>>12&15)+1
            for dy in range(height):
                for dx in range(width):
                    old=code+dx+16*dy if attr&96 else (code&~15)+((code+dx)&15)+16*dy
                    new=native+dx+16*dy if attr&96 else (native&~15)+((native+dx)&15)+16*dy
                    original=font[(old+0x1c00)*128:(old+0x1c01)*128]
                    physical=(0x56c00+new)*128
                    require(len(original)==128 and pixels[physical:physical+128]==original,'Complete original banner block pixels differ')
                    checked+=1
            out.extend(struct.pack('>HHhh',native,attr,x,y))
        require(checked==total,'Complete banner canvas tile domain')
        writes.append((target,bytes(out)));reports.append({'source':hex(source+shift),'blocks':count,'tiles':total,'bytes':len(out)})
    return writes,reports
