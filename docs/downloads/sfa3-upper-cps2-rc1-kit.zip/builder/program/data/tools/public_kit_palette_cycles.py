"""Complete original Dee and Boxer stage palette-cycle resource conversion."""
import hashlib
import struct
from public_kit_graphics import require

FAMILIES={'dee':(34,7,11,0xc30400,0xc33d00,0x8000,(0,4,8)),
          'boxer':(37,11,22,0xde7500,0xde8400,0x8006,(0,4,8,12))}


def wordswap(raw):
    require(len(raw)%2==0,'Palette word extent');out=bytearray(len(raw));out[::2]=raw[1::2];out[1::2]=raw[::2];return bytes(out)


def project(comp2,region,family):
    require(region in ('us','jp') and family in FAMILIES,'Unknown palette cycle domain')
    owner,first,last,DATA,LIMIT,TAG,banks=FAMILIES[family]
    base=0x60b080 if region=='jp' else 0x60ad00
    root=0x916e70+(0x5700 if region=='jp' else 0)
    directory=0x60ff70+(0x10f0 if region=='jp' else 0)
    def read(at,size):
        require(size>0 and 0<=at-base<=len(comp2)-size,'Palette source bounds')
        return comp2[at-base:at-base+size]
    def u32(at):return struct.unpack('<I',read(at,4))[0]
    starts={n:root+struct.unpack('<h',read(root+n*2,2))[0]for n in range(first,last)}
    frames={};payloads={};colors={}
    for selector,start in starts.items():
        todo=[start];seen=set()
        while todo:
            at=todo.pop()
            if at in seen:continue
            require(len(seen)<256,'Unbounded palette frame graph');seen.add(at);scalar=read(at,4);require(len(scalar)==4 and scalar[0]and scalar[2:]==b'\0\0','Original color-cycle scalar grammar changed')
            ptr=u32(at+4);rows=[]
            for j in range(64):
                dest,bank,offset=struct.unpack('<3H',read(ptr+j*6,6))
                require(dest%32==0 and dest+32<=4096 and bank in banks,'Demanded palette source/domain changed')
                bank_root=u32(directory+bank)
                bank_root+=struct.unpack('<h',read(bank_root+owner*2,2))[0]
                address=bank_root+(offset&0xffe0);color=wordswap(read(address,32))
                require(len(color)==32,'Incomplete original palette row')
                if color not in colors:colors[color]=len(colors)*32
                rows.append((dest,TAG,colors[color]|(offset&1)))
                if offset&1:break
            else:raise ValueError('Unterminated original palette copy list')
            payload=b''.join(struct.pack('>3H',*row)for row in rows)
            payloads[ptr]=payload
            next_=u32(at+8)if scalar[1]&128 else None if scalar[1]&64 else at+8
            require(scalar[1] in (0,128),'Unknown palette flow flags')
            frames[at]=(scalar,ptr,next_,12 if scalar[1]&128 else 8)
            if next_ is not None:todo.append(next_)
    cursor=DATA;modules=[]
    def add(blob):
        nonlocal cursor
        at=cursor;cursor+=len(blob);modules.append((at,blob));return at
    native_root=add(bytes(last*2));color_bank=add(b''.join(colors));frame_map={};payload_map={}
    for at,(_,_,_,size)in sorted(frames.items()):frame_map[at]=add(bytes(size))
    for ptr,blob in sorted(payloads.items()):payload_map[ptr]=add(blob)
    modules[0]=(native_root,b''.join(struct.pack('>h',frame_map[starts[n]]-native_root if n in starts else 0)for n in range(last)))
    for n,(at,blob)in enumerate(modules):
        original=next((p for p,v in frame_map.items()if v==at),None)
        if original is not None:
            scalar,ptr,next_,size=frames[original]
            require(size==12 or frame_map[next_]==at+8,'Palette successor allocation differs')
            modules[n]=(at,scalar+struct.pack('>I',payload_map[ptr])+(struct.pack('>I',frame_map[next_])if size==12 else b''))
    require(cursor<=LIMIT,'Dee palette program reservation exceeded')
    return modules,{'frames':len(frames),'payloads':len(payloads),'color_rows':len(colors),'bytes':cursor-DATA}


def construct(comp2,recipe):
    require(recipe['schema']==1 and hashlib.sha256(comp2).hexdigest()==recipe['source_sha256'],'Original palette-cycle source identity')
    require(set(recipe['families'])==set(FAMILIES),'Complete palette cycle family census')
    writes=[];reports={}
    for family in FAMILIES:
        modules,report=project(comp2,recipe['region'],family)
        require(report==recipe['families'][family],'Complete palette-cycle resource inventory differs')
        writes.extend(modules);reports[family]=report
    return writes,reports


def main():
    import argparse,json
    from pathlib import Path
    p=argparse.ArgumentParser(description=__doc__)
    for n in ('comp2','recipe','outdir'):p.add_argument('--'+n,type=Path,required=True)
    a=p.parse_args();writes,_=construct(a.comp2.read_bytes(),json.loads(a.recipe.read_text()));data=bytearray(0x400000);mask=bytearray(len(data))
    for at,blob in writes:
        at-=0xa00000;require(not any(mask[at:at+len(blob)]),'Overlapping palette cycles')
        data[at:at+len(blob)]=blob;mask[at:at+len(blob)]=b'\1'*len(blob)
    a.outdir.mkdir(exist_ok=True);(a.outdir/'result.bin').write_bytes(data);(a.outdir/'result.mask').write_bytes(mask)


if __name__=='__main__':main()
