"""Complete retained Japanese quote glyph directories with original pixel proof."""
import hashlib
import struct
from public_kit_graphics import require
from public_kit_original_quotes import source_pools,packed_record

FAMILIES=((32,0xa46c64,76),(33,0xb7aa80,76),(23,0xbcb0f8,77))


def glyphs(record):
    require(packed_record(record)==record,'Complete original font consumer record')
    at=0;result=set()
    for _ in range(2):
        cursor=record[at];at+=1
        if cursor==0x70:break
        while True:
            hi=record[at]<<4|record[at+1]>>4
            if hi==0:at+=2;break
            lo=(record[at+1]&15)<<8|record[at+2];at+=3;result.add(hi)
            if lo==0:break
            result.add(lo)
    return result


def construct(inputs,recipe,native_pixels):
    require(recipe['region']=='jp','Retained Japanese font directory region')
    for name,pin in recipe['inputs'].items():
        blob=inputs[name]
        require(len(blob)==pin['bytes'] and hashlib.sha256(blob).hexdigest()==pin['sha256'],'Original font source identity: '+name)
    require(hashlib.sha256(native_pixels).hexdigest()==recipe['native_pixels_sha256'],'Qualified native font pixel identity')
    pools,opponents=source_pools(inputs['comp2']);font=inputs['font']
    require([r['owner']for r in recipe['families']]==[r[0]for r in FAMILIES],'Complete retained font family inventory')
    writes=[];reports=[]
    for row,(owner,address,count)in zip(recipe['families'],FAMILIES):
        records=list(pools[owner])+[pools[n][opponents[owner]]for n in range(32)if n not in (18,19,20,23)]
        used=set().union(*(glyphs(record)for record in records))
        allocations=dict(row['allocations'])
        require(len(allocations)==len(row['allocations']),'Repeated quote glyph allocation')
        require(set(allocations)<=set(range(0x7a0,0x7a0+count)),'Quote glyph allocation domain')
        values=[];checked=0
        for glyph in range(0x7a0,0x7a0+count):
            physical=allocations.get(glyph,0x19760+glyph)
            require(0x16c00<=physical<0x20000,'Native font tile extent')
            if glyph in used or glyph in allocations:
                source=font[(0x4780+glyph)*128:(0x4781+glyph)*128]
                require(len(source)==128 and native_pixels[physical*128:(physical+1)*128]==source,'Complete original quote glyph pixel mismatch: '+str((owner,hex(glyph),hex(physical))))
                checked+=1
            values.append(physical-0x16c00)
        writes.append((address,struct.pack('>'+str(count)+'H',*values)))
        reports.append({'owner':owner,'entries':count,'original_glyphs_checked':checked,'unused_slots':'Native default glyph projection; no original consumer uses these entries'})
    return writes,reports
