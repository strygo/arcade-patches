"""Original native copied action graphs with unanimous PS2 Upper clock projection.

Complete Sakura and Zangief retained normal-family graphs. Other copied
families require selector/Naomi source closure and remain explicitly excluded.
"""
import hashlib
import struct
from public_kit_graphics import require
from public_kit_copied_directories import FAMILIES,domain,u32


def root(blob,at,base,endian):
    offsets=[]
    for i in range(256):
        pos=at-base+i*2;require(0<=pos<=len(blob)-2,'Original action directory bounds')
        value=struct.unpack_from(endian+'h',blob,pos)[0]
        if value==0:return [at+n for n in offsets]
        offsets.append(value)
    raise ValueError('Unbounded original action directory')


def graph(blob,at,base,endian):
    frames=[]
    while at is not None and at not in frames:
        require(0<=at-base<=len(blob)-20,'Original action frame bounds')
        frames.append(at);flags=blob[at-base+1]
        if flags&128:
            require(at-base+24<=len(blob),'Original action successor bounds')
            at=struct.unpack_from(endian+'I',blob,at-base+20)[0]
        else:at=None if flags&64 else at+20
        require(len(frames)<2048,'Bounded original action graph')
    return frames,frames.index(at)if at is not None else None


def construct(inputs,recipe):
    for name,pin in recipe['inputs'].items():
        value=inputs[name];require(len(value)==pin['bytes'] and hashlib.sha256(value).hexdigest()==pin['sha256'],'Original copied-frame '+name+' identity')
    arcade=inputs['arcade'];comp2=inputs['comp2'];base=0x60ad00 if recipe['region']=='us'else 0x60b080
    table=0x749838 if recipe['region']=='us'else 0x74ef38
    writes=[];reports=[]
    for owner,family,count,target,expected,end,replacements in FAMILIES:
        if (owner,family)not in ((13,3),(16,3)):continue
        source_root,targets,records=domain(arcade,owner,family,count,replacements)
        cursor=(target+(count+1)*2+3)&~3;mapping={}
        for at,size in records.items():mapping[at]=cursor;cursor+=size
        require(len(records)==expected and cursor==end,'Copied complete frame allocation extent')
        source_bank=struct.unpack_from('<I',comp2,table-base+owner*4)[0]
        slots=tuple(n for n in range(12)if owner!=15 or n!=7)
        native_bank=u32(arcade,0xde6a0+owner*4)
        demands={};tainted=set();shapes=[]
        for slot in slots:
            source_dir=struct.unpack_from('<I',comp2,source_bank-base+slot*4)[0]
            originals=root(comp2,source_dir,base,'<')
            native_targets=root(arcade,u32(arcade,native_bank+slot*4),0,'>')
            for action,native_at in enumerate(native_targets):
                if slot%4==family and action in replacements:continue
                native,nloop=graph(arcade,native_at,0,'>')
                if action>=len(originals):
                    tainted.update(native);shapes.append([slot,action]);continue
                original,oloop=graph(comp2,originals[action],base,'<')
                if len(native)!=len(original)or nloop!=oloop:
                    tainted.update(native);shapes.append([slot,action]);continue
                for nat,src in zip(native,original):demands.setdefault(nat,set()).add(comp2[src-base])
        changes=0;payload=bytearray()
        for at,size in records.items():
            value=bytearray(arcade[at:at+size]);want=demands.get(at,set())
            if at not in tainted and len(want)==1:
                timer=next(iter(want));changes+=int(value[0]!=timer);value[0]=timer
            if value[1]&128:
                nxt=u32(value,20);require(nxt in mapping,'Complete copied-family successor closure')
                struct.pack_into('>I',value,20,mapping[nxt])
            elif not value[1]&64:require(mapping[at+20]==mapping[at]+20,'Copied-family fallthrough allocation')
            payload.extend(value)
        begin=(target+(count+1)*2+3)&~3;writes.append((begin,bytes(payload)))
        reports.append({'owner':owner,'family':family,'frames':len(records),'clock_projections':changes,'unmatched_source_shapes':shapes,'bytes':len(payload)})
    return writes,reports
