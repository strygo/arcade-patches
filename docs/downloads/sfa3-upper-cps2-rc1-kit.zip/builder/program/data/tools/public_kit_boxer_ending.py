"""Complete original Boxer ending frame graph, cels and root selectors."""
import hashlib
import struct
from public_kit_ending_resources import Library as EndingLibrary
from public_kit_frame_resources import cel
from public_kit_graphics import require

FAMILIES={'boxer':(471,404)}

class Library(EndingLibrary):
    def cel(self,at):
        if self.read(at,2)==b'\x12\0':return 18,()
        return super().cel(at)

def graph(inputs,row):
    data=Library(inputs['metadata'+row['family']]);_,targets=data.root(data.base)
    frames={};cels={}
    for step,selectors in ((20,row['full']),(8,row['compact'])):
        todo=[targets[s] for s in selectors]
        while todo:
            at=todo.pop()
            if at in frames:
                require(frames[at][3] in (step,step+4),'Mixed ending frame parser overlap');continue
            require(at%4==0 and len(frames)<4096,'Ending frame graph bounds/alignment')
            raw=data.read(at,step);pointer=data.u32(at+4)
            nxt=data.u32(at+step) if raw[1]&128 else None if raw[1]&64 else at+step
            frames[at]=(raw,pointer,nxt,step+4 if raw[1]&128 else step);cels[pointer]=data.cel(pointer)
            if nxt is not None:todo.append(nxt)
    return data,targets,frames,cels

def construct(inputs,recipe,pixels):
    for name,pin in recipe['inputs'].items():
        require(len(inputs[name])==pin['bytes'] and hashlib.sha256(inputs[name]).hexdigest()==pin['sha256'],'Original ending frame source identity: '+name)
    require(hashlib.sha256(pixels).hexdigest()==recipe['graphics_pixels_sha256'],'Reconstructed ending frame artwork identity')
    require([r['family'] for r in recipe['families']]==list(FAMILIES),'Complete ending family inventory')
    upper=pixels[32<<20:];writes=[];reports=[]
    for row in recipe['families']:
        family=row['family'];data,targets,frames,cels=graph(inputs,row)
        placements={source:(destination,xy,bank,tiles) for source,destination,xy,bank,tiles in row['cels']}
        mapping=dict(row['frames'])
        require(set(placements)==set(cels) and set(mapping)==set(frames),'Complete ending graph allocation inventory')
        for source,(destination,xy,bank,tiles) in placements.items():
            require(bank in (0,5),'Unknown ending graphics bank')
            coords,body=cel(data,source,xy,tiles,inputs['pixels'+family],inputs['mask'+family],pixels if bank==0 else upper,0 if bank==0 else 1)
            if coords is not None:writes.append((xy,coords))
            writes.append((destination,body))
        for source,(raw,pointer,nxt,size) in sorted(frames.items()):
            wide=size in (20,24);step=20 if wide else 8;destination=mapping[source]
            blob=bytearray(struct.pack('>10H',*struct.unpack('<10H',raw)) if wide else raw)
            blob[:4]=raw[:4];struct.pack_into('>I',blob,4,placements[pointer][0])
            if size==step+4:blob.extend(struct.pack('>I',mapping[nxt]))
            elif nxt is not None:require(mapping[nxt]==destination+step,'Ending successor fallthrough differs')
            writes.append((destination,bytes(blob)))
        root=row['root'];selectors=row['full']+row['compact']
        # Reconstruct only this family's owned selectors. Later producers may
        # populate other slots in the same physical root directory.
        for selector in selectors:writes.append((root+selector*2,struct.pack('>h',mapping[targets[selector]]-root)))
        reports.append({'family':family,'frames':len(frames),'cels':len(cels),'selectors':len(selectors)})
    return writes,reports
