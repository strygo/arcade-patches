"""Materialize the original PC-relative palette table and reviewed title ramp rows."""
import hashlib,struct
from public_kit_graphics import require


def construct(native,key,recipe):
    require(recipe['schema']==1 and hashlib.sha256(native).hexdigest()==recipe['native_sha256'] and hashlib.sha256(key).hexdigest()==recipe['key_sha256'],'Original native palette identities')
    from cps2_crypt import decrypt_rom
    opcodes=decrypt_rom(native[:0x100000],key)[0]
    table=opcodes[0xa5c90:0xa5cc8];pointers=struct.unpack('>14I',table)
    require(all(0<=p<len(native) and p%2==0 for p in pointers),'Original inline palette family pointer bounds')
    rows=bytearray()
    for i,colors in enumerate(((0x500,0x300,0x200),(0xa00,0x700,0x300),(0xf00,0xa00,0x500))):
        at=pointers[13]+(17+i)*32;require(0<=at<=len(native)-32,'Original whole backdrop palette extent')
        row=bytearray(native[at:at+32]);row[:6]=struct.pack('>3H',*colors);rows.extend(row)
    return [(recipe['family_table'],table),(0xc31016,bytes(rows))],{'complete_family_pointers':14,'complete_backdrop_rows':3,'bytes':152,'source_backdrop_base':pointers[13],'table_view':'original decrypted opcode PC-relative data','palette_view':'original raw ROM data'}


def main():
    import argparse,json
    from pathlib import Path
    p=argparse.ArgumentParser(description=__doc__)
    for n in ('recipe','native','key','outdir'):p.add_argument('--'+n,type=Path,required=True)
    a=p.parse_args();writes,report=construct(a.native.read_bytes(),a.key.read_bytes(),json.loads(a.recipe.read_text()));data=bytearray(0x400000);mask=bytearray(len(data))
    for at,blob in writes:
        at-=0xa00000;require(0<=at<=len(data)-len(blob),'Expanded palette table destination');data[at:at+len(blob)]=blob;mask[at:at+len(blob)]=b'\1'*len(blob)
    (a.outdir/'result.bin').write_bytes(data);(a.outdir/'result.mask').write_bytes(mask);print(json.dumps(report))


if __name__=='__main__':main()
