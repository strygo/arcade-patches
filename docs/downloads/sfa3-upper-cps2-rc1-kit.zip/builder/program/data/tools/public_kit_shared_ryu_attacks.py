"""Complete shared Ryu attack allocation from native, original PS2 and Naomi resources."""
import hashlib,struct
from public_kit_dhalsim_tables import Owner
import public_kit_ryu_naomi as naomi
from public_kit_graphics import require


def construct(inputs,recipe):
    require(set(inputs)==set(recipe['inputs'])=={'arcade','comp2','naomi'},'Complete original attack inputs')
    for k,pin in recipe['inputs'].items():
        require(len(inputs[k])==pin['bytes']and hashlib.sha256(inputs[k]).hexdigest()==pin['sha256'],'Original attack identity: '+k)
    data,c2,program=(inputs[k]for k in ('arcade','comp2','naomi'))
    base=0x60b080 if recipe['region']=='jp'else 0x60ad00;delta=0x5700 if recipe['region']=='jp'else 0
    u=lambda at:struct.unpack_from('>I',data,at)[0]
    su=lambda at:struct.unpack_from('<I',c2,at-base)[0]
    bank=u(u(0xde2a0));offsets=struct.unpack_from('>5h',data,bank);attack=bank+offsets[4]
    aliases={o for o in range(32)if any(u(u(0xde2a0+o*4)+s*4)==bank for s in range(3))}
    require(aliases=={0,18,20,23},'Complete original shared attack owner domain')
    demands={};tainted=set();sources={};uses=0
    for owner in sorted(aliases):
        choices=[u(u(0xde2a0+owner*4)+s*4)for s in range(3)]
        model=Owner(data,0,u(0xde6a0+owner*4),u(0xde320+owner*4),u(0xde3a0+owner*4),choices,'>')
        sv=su(0x749338+delta+owner*4)
        source=Owner(c2,base,su(0x749838+delta+owner*4),su(0x7493d8+delta+owner*4),su(0x749478+delta+owner*4),[su(sv+s*4)for s in range(3)],'<')
        sources[owner]=source
        for slot,family in enumerate(model.families):
            for action,(records,loop) in enumerate(family):
                sf=source.families[slot];matched=action<len(sf)and len(sf[action][0])==len(records)and sf[action][1]==loop
                for ordinal,at in enumerate(records):
                    uses+=1;address=model.values(at,slot//4)['attack_at']
                    if not matched:tainted.update(range(address,address+32));continue
                    wanted=source.values(sf[action][0][ordinal],slot//4)['attack']
                    for i,v in enumerate(wanted):demands.setdefault(address+i,set()).add(v)
    result=bytearray(data[attack:attack+96*32])
    for at,values in demands.items():
        if attack<=at<attack+len(result)and at not in tainted and len(values)==1:result[at-attack]=next(iter(values))
    sb=su(su(0x749338+delta+23*4));so=struct.unpack_from('<5h',c2,sb-base)
    for row in range(96,114):
        raw=c2[sb+so[4]+row*32-base:][:32]
        require(len(raw)==32,'Original complete appended attack row')
        result.extend(struct.pack('>4h',*struct.unpack('<4h',raw[:8]))+raw[8:])
    # Complete row replacements in the original Evil gameplay producer.
    for row in (29,*range(37,49),57,*range(91,96)):
        raw=c2[sb+so[4]+row*32-base:][:32]
        result[row*32:(row+1)*32]=struct.pack('>4h',*struct.unpack('<4h',raw[:8]))+raw[8:]
    values,counts,_=naomi.descriptor(program,23);banks=[naomi.u32(program,values[5]+s*4)for s in range(3)]
    require(len(set(banks))==1,'Original Evil three-ISM collision alias')
    pointers=struct.unpack('<7I',naomi.read(program,banks[0],28));changes=[]
    require(pointers[0]-pointers[5]==116*4 and pointers[5]-pointers[6]==34*4,'Original complete selector/event directory extents')
    for pointer,table,size in ((pointers[5],0x7493d8,464),(pointers[6],0x749478,136)):
        src=su(table+delta+23*4)
        require(naomi.read(program,pointer,size)==c2[src-base:src-base+size],'Complete original PS2/Naomi selector/event control')
    max_attack=-1
    for family in range(4):
        for action in range(counts[values[(0,2,1,3)[family]]]):
            graph,_=naomi.graph(program,23,family,action)
            max_attack=max(max_attack,*(r['scalar'][1]for r in graph))
    require(max_attack==113,'All original Naomi callers bind the complete114-row attack domain')
    for family,action,ordinals in ((2,23,(1,2,3)),(2,24,(1,))):
        rows,loop=naomi.graph(program,23,family,action);ps,pl=sources[23].families[family][action]
        require(len(rows)==len(ps)and loop==pl,'Whole original PS2/Naomi corrected action topology')
        require(all(c2[at-base+9]==r['scalar'][1]for at,r in zip(ps,rows)),'Whole corrected graph attack-index projection')
        for ordinal in ordinals:
            index=rows[ordinal]['scalar'][1];record=naomi.read(program,pointers[4]+index*32,32)
            result[index*32+22]=record[22];changes.append(index)
    require(changes==[54,55,63,76],'Complete original corrected attack semantic domain')
    require(len(result)==3648,'Whole114-row shared attack allocation')
    return [(0xba87c0,bytes(result))],{'bytes':3648,'rows':114,'native_rows':96,'added_rows':18,'native_owners':sorted(aliases),'source_frame_uses':uses,'Naomi_corrected_rows':changes}
