"""Complete original JP opening, rival and ending paragraph families."""
import hashlib
import struct
from public_kit_original_quotes import packed_record
from public_kit_graphics import require

TABLES={'opening':(0x61d1b0,116),'rival':(0x61c660,755),'ending':(0x615f00,789)}
GROUPS={'guile_opening':('opening',103,106),'cohort_opening':('opening',103,109),
        'evil_opening':('opening',94,96),'dee_opening':('opening',110,112),'hawk_opening':('opening',113,115),
        'guile_rival':('rival',668,691),'guile_ending':('ending',690,726),'fei_ending':('ending',727,747),
        'evil_ending':('ending',639,648),'dee_ending':('ending',748,766),'hawk_ending':('ending',767,788),
        'boxer_ending':('ending',611,638),'juli_ending':('ending',649,667),'juni_ending':('ending',668,689)}

def records(comp2,kind,first,last):
    require(kind in TABLES,'Unknown original paragraph reader')
    language,count=TABLES[kind];table=struct.unpack_from('<I',comp2,language-0x60b080)[0]-0x60b080
    require(0<=table<=len(comp2)-count*2,'Original paragraph directory bounds')
    offsets=struct.unpack_from('<'+str(count)+'H',comp2,table)
    require(offsets[0]==count*2 and list(offsets)==sorted(set(offsets)) and table+offsets[-1]<len(comp2),'Complete original paragraph directory extent/order')
    require(0<=first<=last<count,'Original paragraph selection outside directory')
    output=[]
    for index in range(first,last+1):
        at=table+offsets[index]
        if index+1<count:blob=comp2[at:table+offsets[index+1]]
        else:
            require((kind,index) in (('opening',115),('ending',788)),'Unknown final paragraph boundary')
            blob=packed_record(comp2[at:at+512])
        logical=packed_record(blob)
        require(len(blob)-len(logical)<=3 and not any(blob[len(logical):]),'Original paragraph trailing payload')
        output.append(blob)
    return output

def construct(inputs,recipe):
    require(recipe['region']=='jp','Original Japanese paragraph recipe region')
    comp2=inputs['comp2'];pin=recipe['input']
    require(len(comp2)==pin['bytes'] and hashlib.sha256(comp2).hexdigest()==pin['sha256'],'Original Japanese paragraph source identity')
    require([r['name'] for r in recipe['groups']]==list(GROUPS),'Complete original paragraph family inventory')
    writes=[];reports=[]
    for row in recipe['groups']:
        kind,first,last=GROUPS[row['name']];blobs=records(comp2,kind,first,last)
        require(len(row['records'])==len(blobs),'Complete native paragraph directory extent')
        require(0xa00000<=row['directory']<=0xe00000-2*len(blobs),'Native paragraph directory allocation bounds')
        require(row['records'][0]>=row['directory']+2*len(blobs) and all(a+len(blob)<=z for a,blob,z in zip(row['records'],blobs,row['records'][1:])),'Native paragraph record allocation order/overlap')
        base=row['directory']-first*2;offsets=[]
        for at,blob in zip(row['records'],blobs):
            require(0xa00000<=at<=0xe00000-len(blob),'Native paragraph record allocation bounds')
            offset=at-base;require(0<offset<32768,'Native paragraph signed offset reach')
            offsets.append(offset);writes.append((at,blob))
        writes.append((row['directory'],struct.pack('>'+str(len(offsets))+'H',*offsets)))
        reports.append({'name':row['name'],'records':len(blobs),'source_indices':[first,last],'record_bytes':sum(map(len,blobs))})
    return writes,reports
