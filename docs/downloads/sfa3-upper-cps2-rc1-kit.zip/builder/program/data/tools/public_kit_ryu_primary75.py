"""Complete original shared Ryu/ID23 terminal primary75 resource."""
import hashlib,struct
from public_kit_actor import Data
from public_kit_blocks import grid_code
from public_kit_graphics import require,tile_variants
from public_kit_shin_frames import compare_canvas

def graph(data,target):
    rows={}
    while target is not None and target not in rows:
        header=data.read(target,20);_,value,nxt=data.frame(target)
        rows[target]=(header,data.u32(target+4),tuple((x,y,w&65535,w>>16)for x,y,w in value[1]),nxt)
        require(len(rows)<1024,'Bounded original shared action graph');target=nxt
    return rows

def original(inputs,region):
    data=Data(inputs['comp2'],0x60ad00 if region=='us' else 0x60b080,inputs['coords'],0xb04000)
    table=0x749838 if region=='us' else 0x74ef38;bank=data.u32(table)
    require(data.u32(table+23*4)==bank,'Original Ryu/ID23 shared owner binding')
    roots=struct.unpack('<12I',data.read(bank,48))
    require(len(set(roots[0::4]))==len(set(roots[2::4]))==1,'Original shared ISM roots')
    _,primary=data.root(roots[0]);rows=graph(data,primary[75])
    require(len(rows)==1 and next(iter(rows.values()))[0][:2]==bytes((1,64)), 'Complete terminal primary75 frame')
    return rows

def construct(inputs,recipe,pixels):
    require(set(inputs)==set(recipe['inputs'])=={'comp2','coords','pixels','mask'},'Complete shared Ryu original source domain')
    for name,pin in recipe['inputs'].items():
        require(len(inputs[name])==pin['bytes'] and hashlib.sha256(inputs[name]).hexdigest()==pin['sha256'],'Original shared Ryu input '+name)
    require(recipe['region'] in ('us','jp'),'Original shared Ryu region')
    rows=original(inputs,recipe['region']);native=pixels[:8<<20];lookup={}
    for n in range(0,len(native),128):lookup.setdefault(native[n:n+128],n//128)
    mapping={};converted=[]
    header,pointer,blocks,nxt=next(iter(rows.values()))
    require(nxt is None,'Terminal original primary75')
    for x,y,t,a in blocks:
        width,height=(a>>8&15)+1,(a>>12&15)+1
        for dy in range(height):
            for dx in range(width):
                code=grid_code(t,width-1-dx if a&32 else dx,height-1-dy if a&64 else dy)
                require(code<len(inputs['mask']) and inputs['mask'][code],'Original primary75 tile presence')
                if code not in mapping:
                    variants=tile_variants(inputs['pixels'][code*128:(code+1)*128])
                    match=next(((lookup[v],flip*32)for flip,v in enumerate(variants)if v in lookup),None)
                    require(match is not None,'Original primary75 native artwork');mapping[code]=match
                tile,flip=mapping[code];converted.append((x+dx*16,y+dy*16,tile,(a&255)^flip))
    checked=compare_canvas(blocks,converted,inputs['pixels'],native,inputs['mask'])
    frame=0xbc5600;xy=frame+20;cel=xy+len(converted)*4
    payload=bytearray(header);struct.pack_into('>I',payload,4,cel)
    payload[16:20]=struct.pack('>2H',*struct.unpack('<2H',header[16:20]))
    payload.extend(b''.join(struct.pack('>2h',x,y)for x,y,t,a in converted))
    payload.extend(struct.pack('>3HI',2,len(converted),len(converted)-1,xy))
    payload.extend(b''.join(struct.pack('>2H',t,a)for x,y,t,a in converted))
    root_cell=frame+len(payload);biased=root_cell-75*2
    payload.extend(struct.pack('>h',frame-biased))
    require(len(payload)==240 and frame+len(payload)<0xbc5800,'Whole original primary75 allocation')
    return [(frame,bytes(payload))],{'frames':1,'cels':1,'coordinates':len(converted),'bytes':len(payload),'mirrored_canvas_checks':checked,'original_source_frame':next(iter(rows))}
