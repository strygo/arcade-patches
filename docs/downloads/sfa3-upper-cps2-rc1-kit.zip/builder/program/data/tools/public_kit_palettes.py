"""Complete original Upper palette arrays, projected to native word order.

Recipes contain family/owner selectors and allocations, never color literals.
Absent arrays remain explicit: this component covers expanded data only.
"""
import hashlib
import struct
from public_kit_graphics import require

STAGE_TABLES=(0x70e560,0x7147e0,0x71d420,0x707d10)
STAGE_SIZES=(1024,1024,1024,192)


def catalog(comp2,region):
    require(region in ('us','jp'),'Unknown palette region')
    base=0x60ad00 if region=='us' else 0x60b080
    def read(at,size):
        require(size>0 and 0<=at<=len(comp2)-size,'Palette source bounds')
        return comp2[at:at+size]
    def signed(table,owner):return table+struct.unpack('<h',read(table+owner*2,2))[0]
    def words(raw):return b''.join(raw[n:n+2][::-1] for n in range(0,len(raw),2))
    primary=0xec5b0 if region=='us' else 0xf1930
    effect=0xf5840 if region=='us' else 0xfabc0
    special=0x117380 if region=='us' else 0x11c700
    heads=0x11a4a0 if region=='us' else 0x11f820
    require(hashlib.sha256(read(primary,80)).hexdigest()=='ad48339b6720703409d6cfb4df28fc3c921acf7a9e356ceaf899508f6685a38e','Primary owner directory changed')
    require(hashlib.sha256(read(effect,80)).hexdigest()=='79c7749ca35501802c661463b35600f6088f98c85dff3b66a83ae09ebe89d280','Signed effect owner directory changed')
    offsets=struct.unpack('<40H',read(special,80));result={}
    def add(name,at,size):
        require(size%2==0,'Odd palette extent')
        result[name]=(at,words(read(at,size)))
    for owner in range(40):
        add(f'primary:{owner}',signed(primary,owner),960)
        add(f'effects:{owner}',signed(effect,owner),768)
        add(f'prefix:{owner}',signed(effect,owner)-192,192)
        offset=offsets[owner];size=min([v-offset for v in offsets if v>offset]or[1952])
        require(size%32==0,'Special palette row extent')
        add(f'special:{owner}',special+offset,size)
        add(f'head:{owner}',heads+struct.unpack('<H',read(heads+owner*2,2))[0],768)
    for owner in range(32,36):
        for role,(table,size) in enumerate(zip(STAGE_TABLES,STAGE_SIZES)):
            table+= (0x5700 if region=='jp' else 0)-base
            add(f'stage:{owner}:{role}',signed(table,owner),size)
    # Exact original missing interval, including the consumer's following-word bus read.
    add('ending:32:private',0x70ba80+(0x5700 if region=='jp' else 0)-base,1794)
    return result


def construct(comp2,recipe):
    require(recipe['schema']==1,'Unknown palette recipe')
    require(hashlib.sha256(comp2).hexdigest()==recipe['source_sha256'],'Original palette source changed')
    arrays=catalog(comp2,recipe['region'])
    require(set(recipe['placements'])==set(arrays),'Incomplete palette owner/family domain')
    writes=[];report=[]
    for name,(source,blob) in arrays.items():
        targets=recipe['placements'][name]
        require(len(targets)==len(set(targets)),'Duplicate palette allocation')
        for at in targets:
            require(at%2==0 and 0xa00000<=at<=0xe00000-len(blob),'Palette allocation bounds')
            writes.append((at,blob))
        report.append({'family':name,'source_comp2_offset':source,'bytes':len(blob),'allocations':targets,
                       'sha256':hashlib.sha256(blob).hexdigest()})
    return writes,report


def main():
    import argparse
    import json
    from pathlib import Path
    parser=argparse.ArgumentParser(description=__doc__)
    for name in ('pools','recipes','outdir'):parser.add_argument('--'+name,type=Path,required=True)
    args=parser.parse_args();recipes=json.loads(args.recipes.read_text());args.outdir.mkdir(exist_ok=True)
    require(set(recipes)=={'us','jp'},'Incomplete regional palette recipe')
    for region,recipe in recipes.items():
        writes,_=construct((args.pools/f'ps2-{region}-comp2.bin').read_bytes(),recipe)
        data=bytearray(0x400000);mask=bytearray(len(data))
        for at,blob in writes:
            at-=0xa00000
            require(all(not mask[at+i] or data[at+i]==v for i,v in enumerate(blob)),'Conflicting palette allocation alias')
            data[at:at+len(blob)]=blob;mask[at:at+len(blob)]=b'\1'*len(blob)
        (args.outdir/(region+'.bin')).write_bytes(data);(args.outdir/(region+'.mask')).write_bytes(mask)


if __name__=='__main__':main()
