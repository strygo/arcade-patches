"""Complete Guile/Fei result owner, auxiliary and copied-child directories."""
import hashlib
import struct
from public_kit_graphics import require


def construct(inputs,recipe):
    require(set(inputs)==set(recipe['inputs'])=={'comp2','comp2-jp'},'Result directory original inventory')
    for name,blob in inputs.items():
        pin=recipe['inputs'][name]
        require(len(blob)==pin['bytes'] and hashlib.sha256(blob).hexdigest()==pin['sha256'],'Result directory original identity '+name)
    region=recipe['region'];require(region in ('us','jp'),'Result directory region')
    base=0x60ad00 if region=='us' else 0x60b080
    hud=(0x95c700 if region=='us' else 0x961e00)-base
    c2=inputs['comp2'];canonical=inputs['comp2-jp'];bindings=recipe['owners']
    require(set(bindings)=={'32','33'},'Complete added result owner domain')
    records=[]
    for owner in (32,33):
        values=bindings[str(owner)]
        require(set(values)=={'quote','name','heads','portraits','names','palette'},'Complete result owner fields')
        positions=[]
        for offset in (0xa0,0x140):
            first=struct.unpack_from('<h',c2,hud+offset+owner*2)[0]
            require(first==struct.unpack_from('<h',c2,hud+offset+80+owner*2)[0],'Original HUD mode alias')
            positions.append(first&65535)
        records.append(struct.pack('>I4H5I',values['quote'],values['name'],*positions,0,values['heads'],values['heads']+8,values['portraits'],values['names'],values['palette']))
    root=recipe['fei_source_root']-0x60b080
    require(struct.unpack_from('<h',canonical,root)[0]==struct.unpack_from('<h',canonical,root+84)[0],'Original Fei action42 idle alias')
    actions=canonical[0x6188c0-0x60b080+32:0x6188c0-0x60b080+34]
    require(actions==bytes((35,36)),'Original copied victory action pair')
    require(set(recipe['auxiliary_frames'])=={'32','33'} and set(recipe['normal_roots'])=={'32','33'},'Complete added auxiliary/normal domain')
    palettes=(0x3fa000,0xb08000)
    auxiliary=struct.pack('>4I',recipe['auxiliary_frames']['32'],palettes[0],recipe['auxiliary_frames']['33'],palettes[1])
    children=b''.join(struct.pack('>2IBBH',recipe['normal_roots'][str(owner)],palette,action,0,0)for owner,palette,action in zip((32,33),palettes,actions))
    return [(0xb7a000,b''.join(records)),(recipe['auxiliary_address'],auxiliary),(recipe['children_address'],children)],{'bytes':104,'owner_records':2,'auxiliary_records':2,'copied_child_records':2}
