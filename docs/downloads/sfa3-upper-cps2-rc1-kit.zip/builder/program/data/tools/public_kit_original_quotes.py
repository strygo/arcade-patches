"""Original Japanese packed quote directories and complete logical records."""
import hashlib
import struct
from public_kit_graphics import require

OWNERS=(32,33,34,35,23)

def packed_record(data):
    at=0;lines=[]
    for _ in range(2):
        require(at<len(data),'Missing original quote cursor')
        cursor=data[at];at+=1
        if cursor==0x70:break
        glyphs=[]
        for _ in range(64):
            require(at+2<=len(data),'Truncated packed quote terminator')
            hi=(data[at]<<4)|(data[at+1]>>4)
            if hi==0:at+=2;break
            require(at+3<=len(data),'Truncated packed quote glyph pair')
            lo=((data[at+1]&15)<<8)|data[at+2];glyphs.append(hi);at+=3
            if lo==0:break
            glyphs.append(lo)
        else:raise ValueError('Unterminated packed quote')
        lines.append((cursor,glyphs))
    require(lines,'Empty original quote record')
    return data[:at]

def source_pools(comp2):
    pointers=struct.unpack_from('<2I',comp2,0xae70)
    require(pointers[0]==pointers[1],'Original Japanese language pointers differ')
    table=pointers[0]-0x60b080
    require(0<=table<=len(comp2)-80,'Original quote owner table bounds')
    offsets=struct.unpack_from('<40H',comp2,table);starts=sorted({table+n for n in offsets})
    require(starts[0]>=table+80,'Original quote pools overlap owner directory')
    pools={}
    for n,start in enumerate(starts):
        limit=starts[n+1] if n+1<len(starts) else len(comp2)
        first=struct.unpack_from('<H',comp2,start)[0];count=first//2-1
        require(first%2==0 and 0<count<=64 and start+first<limit,'Original quote pool count/extent')
        rows=struct.unpack_from('<'+str(count)+'H',comp2,start)
        require(rows[0]==first and list(rows)==sorted(set(rows)) and rows[-1]<limit-start,'Original quote offset order/extent')
        require(comp2[start+count*2:start+first]==b'\0\0','Original quote header delimiter')
        records=[]
        for index,offset in enumerate(rows):
            at=start+offset;end=start+rows[index+1] if index+1<count else limit
            blob=packed_record(comp2[at:min(end,at+512)])
            if index+1<count or n+1<len(starts):
                padding=comp2[at+len(blob):end]
                require(len(padding)<=3 and not any(padding),'Original quote alignment payload')
            records.append(blob)
        pools[start]=records
    return [pools[table+n] for n in offsets],comp2[0xae90:0xae90+40]

def pack(records):
    first=2*(len(records)+1);body=bytearray();offsets=[]
    for record in records:
        require(packed_record(record)==record,'Quote record contains trailing bytes')
        offsets.append(first+len(body));body.extend(record)
        if len(body)%2:body.append(0)
    require(first+len(body)<32768,'Native quote signed pool extent')
    return struct.pack('>'+str(len(records)+1)+'H',*offsets,0)+body

def construct(inputs,recipe):
    require(recipe['region']=='jp','Original Japanese quote recipe region')
    comp2=inputs['comp2'];pin=recipe['input']
    require(len(comp2)==pin['bytes'] and hashlib.sha256(comp2).hexdigest()==pin['sha256'],'Original Japanese quote source identity')
    source,opponents=source_pools(comp2)
    raw=inputs['arcade'];pin=recipe['arcade_input']
    require(len(raw)==pin['bytes'] and hashlib.sha256(raw).hexdigest()==pin['sha256'],'Original resident quote owner identity')
    native_offsets=struct.unpack_from('>32H',raw,0xc985a)
    admitted=[n for n in range(32) if n not in (18,19,20,23)]
    aliases=[n if n in admitted else next(k for k in admitted if native_offsets[k]==native_offsets[n]) for n in range(32)]
    require([r['owner'] for r in recipe['families']]==list(OWNERS),'Complete quote winner family inventory')
    writes={};reports=[]
    def put(at,blob):
        require(at not in writes or writes[at]==blob,'Conflicting aliased quote allocation')
        writes[at]=blob
    for row in recipe['families']:
        owner=row['owner'];records=list(source[owner]);require(len(records)==41,'Added winner quote count')
        if owner==32:
            for old,new,before,after in recipe['guile_slot_swaps']:
                require(hashlib.sha256(source[owner][old]).hexdigest()==before and hashlib.sha256(source[owner][new]).hexdigest()==after,'Approved Guile source slot swap identity')
                records[old]=source[owner][new]
        put(row['pool'],pack(records));slot=opponents[owner]
        require(len(row['directed_pools'])==32,'Complete directed quote winner directory')
        for winner,destination in enumerate(row['directed_pools']):
            if destination==0:
                require(owner==winner==23,'Unknown absent directed quote slot')
                continue
            require(slot<len(source[winner]),'Directed quote original slot extent')
            put(destination,pack([source[aliases[winner]][slot]]))
        put(row['directed'],struct.pack('>32I',*row['directed_pools']))
        reports.append({'owner':owner,'own_records':len(records),'directed_winners':32,'opponent_slot':slot})
    return sorted(writes.items()),reports


def self_test():
    odd=bytes.fromhex('0412300070');even=bytes.fromhex('04123456000070')
    require(packed_record(odd+b'\0')==odd and packed_record(even)==even,'Packed quote odd/even termination')
    require(pack([odd,even])==bytes.fromhex('0006000c00000412300070000412345600007000'),'Native quote offsets/alignment')
    for bad in (b'\x04\x12',even[:-1]):
        try:packed_record(bad)
        except ValueError:pass
        else:raise ValueError('Truncated original quote accepted')
    return {'passed':True,'rejected_truncations':2}

if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser();parser.add_argument('--self-test',action='store_true',required=True);parser.parse_args()
    print(self_test())
