"""Complete Dee primary and normal directories including later action relocations.

Five later whole-action pointers bind declared allocations. Referenced frames
and artwork require separate proof.
"""
import hashlib
import struct
from public_kit_actor import Data
from public_kit_graphics import require

GROUPS=(('primary',0,64,0xbdccf8),('normal',3,31,0xbdce5e))
ADMISSIONS=(tuple(range(40))+(43,47,48,49,50,51,52,53),tuple(range(31)))
REDIRECTS=({40:0xbdfe48,41:0xbdf5e0},{21:0xbdf45c,23:0xbdf4b0,28:0xbdf52c})


def source(data,recipe):
    roots=struct.unpack('<12I',data.read(data.u32(recipe['owner_table']+34*4),48))
    require(roots[:4]*3==roots and len(set(roots))==4,'Original Dee ISM aliases')
    targets=[data.root(roots[index])[1]for _,index,_,_ in GROUPS]
    require(tuple(map(len,targets))==(64,31),'Complete original Dee complementary directory extents')
    require(targets[0][42]==targets[0][0],'Original result idle alias')
    return roots,targets


def construct(comp2,recipe):
    pin=recipe['input']
    require(len(comp2)==pin['bytes'] and hashlib.sha256(comp2).hexdigest()==pin['sha256'],'Original Dee source identity')
    data=Data(comp2,recipe['base'],b'',0xb04000);roots,targets=source(data,recipe)
    require([g['name']for g in recipe['groups']]==[g[0]for g in GROUPS],'Complete Dee complementary directory inventory')
    writes=[]
    for group,rows,(name,index,count,destination),admitted,redirects in zip(recipe['groups'],targets,GROUPS,ADMISSIONS,REDIRECTS):
        mapping=dict(group['frames'])
        require(len(mapping)==len(group['frames']) and set(mapping)=={rows[i]for i in admitted},'Complete '+name+' source target inventory')
        require(all(0xbd0000<=at<0xbdccf8 for at in mapping.values()),'Dee frame allocation bounds')
        values=[mapping[t] if i in admitted else None for i,t in enumerate(rows)]
        if index==0:values[42]=mapping[rows[0]]
        for action,target in redirects.items():values[action]=target
        offsets=[v-destination if v is not None else 0 for v in values]
        require(all(-32768<=v<=32767 for v in offsets),'Dee signed directory reach')
        writes.append((destination,struct.pack('>'+str(count+1)+'h',*offsets,0)))
    return writes,{'directories':['primary','normal'],'entries':[64,31],'bytes':194,
                   'qualification':'Complete directories with original idle alias and five typed whole-action allocation redirects; frame scalars/artwork separately qualified'}
