"""Complete original Guile round choices, shadows and inherited callback tables."""
import hashlib
import struct
from public_kit_graphics import require


def construct(inputs,recipe):
    require(set(inputs)==set(recipe['inputs'])=={'comp2','arcade'},'Guile round original inventory')
    for name,blob in inputs.items():
        pin=recipe['inputs'][name]
        require(len(blob)==pin['bytes'] and hashlib.sha256(blob).hexdigest()==pin['sha256'],'Guile round original identity')
    region=recipe['region'];require(region in ('us','jp'),'Guile round source region')
    c2=inputs['comp2'];native=inputs['arcade'];base=0x60ad00 if region=='us' else 0x60b080
    choices=0x60eef0 if region=='us' else 0x60ffe0
    shadow_table=0x74c5d8 if region=='us' else 0x751cd8
    def read(at,n):
        require(base<=at<=base+len(c2)-n,'Guile round original bounds');return c2[at-base:at-base+n]
    def u32(at):return struct.unpack('<I',read(at,4))[0]
    def swap(blob):return b''.join(blob[n:n+2][::-1]for n in range(0,len(blob),2))
    handlers=struct.unpack('<7I',read(choices-32,28))
    require(len(set(handlers[1:]))==1 and handlers[0]!=handlers[1],'Original Guile random and common phase handlers')
    rng=read(choices,16);actions=read(choices+32,14)
    require(all(n%2==0 and 2<=n<=12 for n in rng),'Original six-choice victory index schema')
    require(len(set(struct.unpack('<4I',read(choices+16,16))))==4,'Original four victory phase directory')
    require(all(0<=n<64 for n in struct.unpack('<7h',actions)),'Original victory action schema')
    shadow=read(u32(shadow_table+128),56)
    require(all(0<=shape<=16 and -128<=offset<=128 for shape,offset in struct.iter_unpack('<2h',shadow)),'Complete original fourteen shadow rows')
    native_ryu=struct.unpack_from('>I',native,0xe0b20)[0]
    require(native[native_ryu:native_ryu+80]==swap(read(u32(shadow_table),80)),'Whole original Ryu shadow projection control')
    result=bytearray(rng+swap(actions)+swap(shadow));result.extend(b'\xff'*((-len(result))%4))
    require(len(result)==88,'Declared round-data alignment')
    require(recipe['callbacks']=={'victory':0xea56c,'generic_victory':0xea5f6},'Source-authored complete round relocation exports')
    for root,role in ((0xde0a0,'victory'),(0xde120,'generic_victory')):
        prefix=native[root:root+128];require(len(prefix)==128,'Complete original32-owner callback prefix')
        result.extend(prefix+struct.pack('>I',recipe['callbacks'][role]))
    require(len(result)==352,'Complete Guile round data allocation')
    return [(0xa3a000,bytes(result))],{'bytes':352,'choices':16,'actions':7,'shadow_rows':14,'callback_tables':2,'owners_per_table':33,'padding_bytes':2}
