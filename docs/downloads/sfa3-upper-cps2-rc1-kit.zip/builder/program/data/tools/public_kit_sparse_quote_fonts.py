"""Complete retained Dee/Hawk signed-glyph map tables with original pixel proof."""
import hashlib
import struct
from public_kit_graphics import require

FAMILIES=((34,0xc10d7a,(1954,1985,2002,2013,2014,2015,2029,65472,65473,65474,65475,65476,65478,65479,65480,65481,65482,65483,65484,65485,65486,65487,65489,65490,65491,65492,65493,65494,65495,65496,65497,65498,65499)),
          (35,0xc78b96,(1955,1968,1971,1976,1980,1983,1988,1991,1992,1993,1995,2016,2017,2018,2019,2021)))


def construct(font,recipe,pixels):
    pin=recipe['font'];require(len(font)==pin['bytes'] and hashlib.sha256(font).hexdigest()==pin['sha256'],'Own regional original font identity')
    require(hashlib.sha256(pixels).hexdigest()==recipe['pixels_sha256'],'Qualified font graphics identity')
    require(len(recipe['families'])==len(FAMILIES),'Complete sparse quote map family domain')
    writes=[];reports=[]
    for row,(owner,address,glyphs)in zip(recipe['families'],FAMILIES):
        pairs=row['pairs'];require(tuple(g for g,_ in pairs)==glyphs,'Complete original signed-glyph directory domain')
        for glyph,code in pairs:
            signed=glyph if glyph<32768 else glyph-65536
            require(-2048<=signed<=2047 and 0<=code<0x9400,'Native signed-glyph mapping extent')
            original=font[(0x4780+signed)*128:(0x4781+signed)*128]
            physical=(0x16c00+code)*128
            require(len(original)==128 and pixels[physical:physical+128]==original,'Complete own-regional signed-glyph pixels')
        blob=b''.join(struct.pack('>HH',*pair)for pair in pairs);writes.append((address,blob))
        reports.append({'owner':owner,'glyphs':len(pairs),'bytes':len(blob),'opposite_region_disc_required':False})
    return writes,reports
