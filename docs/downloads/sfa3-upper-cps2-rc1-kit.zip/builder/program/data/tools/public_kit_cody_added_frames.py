"""Complete original Cody47/48 private cels and full-frame graphs."""
import hashlib,struct
from public_kit_actor import Data
from public_kit_blocks import BlockPacker,grid_code
from public_kit_graphics import require
from public_kit_shin_frames import compare_canvas

def original(inputs,region):
    data=Data(inputs['comp2'],0x60ad00 if region=='us' else 0x60b080,inputs['coords'],0xb04000)
    bank=data.u32((0x749838 if region=='us' else 0x74ef38)+27*4);roots=struct.unpack('<12I',data.read(bank,48))
    require(roots[3]==roots[7]==roots[11],'Original Cody normal ISM aliases')
    _,targets=data.root(roots[3]);require(len(targets)==49,'Complete original Cody normal49 directory')
    rows={}
    for action in (47,48):
        at=targets[action];seen=set()
        while at is not None and at not in seen:
            seen.add(at);header=data.read(at,20);_,value,nxt=data.frame(at)
            require(header[1] in (0,64),'Original Cody47/48 no explicit links')
            rows[at]=(header,data.u32(at+4),tuple((x,y,w&65535,w>>16)for x,y,w in value[1]),nxt);at=nxt
            require(len(seen)<64,'Bounded original Cody47/48 graph')
    require(len(rows)==20,'Complete original Cody20-frame extension');return dict(sorted(rows.items()))

def construct(inputs,recipe,pixels):
    require(recipe['source_region'] in ('us','jp') and set(inputs)==set(recipe['inputs'])=={'comp2','coords','pixels','mask'},'Regional original Cody domain')
    for name,pin in recipe['inputs'].items():
        require(len(inputs[name])==pin['bytes']and hashlib.sha256(inputs[name]).hexdigest()==pin['sha256'],'Original Cody input '+name)
    rows=original(inputs,recipe['source_region']);originals={p:b for _,p,b,_ in rows.values()};packer=BlockPacker(b'');converted={};native=pixels[56<<20:58<<20];checked=0
    for pointer,blocks in sorted(originals.items()):
        out=[]
        for x,y,t,a in blocks:
            w,h=(a>>8&15)+1,(a>>12&15)+1;codes=[grid_code(t,dx,dy)for dy in range(h)for dx in range(w)]
            require(all(c<len(inputs['mask'])and inputs['mask'][c]for c in codes),'Original Cody private tiles')
            tiles=[inputs['pixels'][c*128:(c+1)*128]for c in codes];target=packer.add(w,h,tiles,a);packer.check(target,w,h,tiles,a)
            out.append((x,y,target,a))
        checked+=compare_canvas(blocks,out,inputs['pixels'],native,inputs['mask']);converted[pointer]=out
    packed=b''.join(packer.tiles);require(native[:len(packed)]==packed and len(packed)==73728,'Complete Cody private packed pixels')
    payload=bytearray();mapping={}
    for pointer,blocks in converted.items():
        xy=0xad8100+len(payload);payload.extend(b''.join(struct.pack('>2h',x,y)for x,y,_,_ in blocks))
        mapping[pointer]=0xad8100+len(payload);area=sum(((a>>8&15)+1)*((a>>12&15)+1)for _,_,_,a in blocks)
        payload.extend(struct.pack('>3HI',2,area,len(blocks)-1,xy));payload.extend(b''.join(struct.pack('>2H',t,a)for _,_,t,a in blocks))
    require(len(payload)==1314 and len(mapping)==17,'Complete Cody17-cel descriptor allocation')
    frame=bytearray();bindings={at:0xad97fa+i*20 for i,at in enumerate(rows)}
    for at,(header,pointer,_,nxt)in rows.items():
        blob=bytearray(header);struct.pack_into('>I',blob,4,mapping[pointer]);blob[16:18]=header[16:18][::-1]
        if nxt is not None:require(bindings[nxt]==bindings[at]+20,'Original Cody frame fallthrough')
        frame.extend(blob)
    return [(0xad8100,bytes(payload)),(0xad97fa,bytes(frame))],{'frames':20,'cels':17,'bytes':1714,'canvas_pixels_checked':checked,'private_art_bytes':len(packed)}
