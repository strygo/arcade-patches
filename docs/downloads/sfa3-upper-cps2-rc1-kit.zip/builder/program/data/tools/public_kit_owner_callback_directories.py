"""Complete retained normal/air owner directories through original emitter generations."""
import hashlib,struct
from public_kit_graphics import require


def construct(inputs,recipe):
    require(set(inputs)=={'arcade'},'Canonical native callback source only')
    data=inputs['arcade'];pin=recipe['inputs']['arcade']
    require(len(data)==pin['bytes']and hashlib.sha256(data).hexdigest()==pin['sha256'],'Original callback source identity')
    require(set(recipe['roles'])=={'normal','air'},'Complete normal and air reader domains')
    writes=[]
    for role,row in recipe['roles'].items():
        root=row['native_root'];require(0xd0000<=root<0xe4000,'Original callback directory allocation')
        prefix=data[root:root+128];require(hashlib.sha256(prefix).hexdigest()==row['native_sha256'],'Whole original32-owner prefix')
        values=list(struct.unpack('>32I',prefix))
        added=row['added'];require(set(added)=={'32','33','34','35'},'Explicit four added-owner callback allocations')
        require(all(type(n)is int and 0<n<0x100000 for n in added.values()),'Added callback allocation key range')
        values.extend([added['32'],added['33'],added['34'],added['35'],values[2],values[21]])
        require(set(row['tables'])=={'34','35','37','38'},'Complete retained callback generations')
        for count in (34,35,37,38):
            target=row['tables'][str(count)];require(0xb70000<=target<0xc74000,'Callback table destination allocation')
            actual=list(values[:count])
            if count==38 and role=='air':actual[31]=0xe1f50
            writes.append((target,struct.pack('>'+str(count)+'I',*actual)))
    return writes,{'roles':['normal','air'],'generations':[34,35,37,38],'tables':8,'bytes':sum(len(b)for _,b in writes),'native_control_owners':32,'final_juni_cpu_air':0xe1f50}
