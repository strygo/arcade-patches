"""Complete retained shadow/voice owner directories through original emitter generations."""
import hashlib,struct
from public_kit_graphics import require


def construct(inputs,recipe):
    require(set(inputs)=={'arcade'},'Canonical native callback source only')
    data=inputs['arcade'];pin=recipe['inputs']['arcade']
    require(len(data)==pin['bytes']and hashlib.sha256(data).hexdigest()==pin['sha256'],'Original callback source identity')
    require(set(recipe['roles'])=={'shadow','voice'},'Complete shadow and voice reader domains')
    writes=[]
    for role,row in recipe['roles'].items():
        root=row['native_root'];require(0xd0000<=root<0xe4000,'Original callback directory allocation')
        prefix=data[root:root+128];require(hashlib.sha256(prefix).hexdigest()==row['native_sha256'],'Whole original32-owner prefix')
        values=list(struct.unpack('>32I',prefix))
        added=row['added'];require(set(added)=={'32','33','34','35'},'Explicit four added-owner callback allocations')
        require(all(type(n)is int and 0<n<0xe00000 for n in added.values()),'Added callback allocation key range')
        values.extend([added['32'],added['33'],added['34'],added['35'],row['shin'],values[21]])
        require(set(row['tables'])=={'34','35','37','38'},'Complete retained callback generations')
        for count in (34,35,37,38):
            target=row['tables'][str(count)];require(0xb70000<=target<0xc74000,'Callback table destination allocation')
            actual=list(values[:count])
            if role=='voice' and count>34:
                for n in (0,23):actual[n]=recipe['ryu_voice']
                if count==38:actual[0]=struct.unpack_from('>I',prefix)[0]
            writes.append((target,struct.pack('>'+str(count)+'I',*actual)))
    values=list(struct.unpack('>32I',data[recipe['roles']['voice']['native_root']:][:128]))
    values.extend([recipe['roles']['voice']['added']['32'],recipe['roles']['voice']['added']['33']])
    for n in (0,23):values[n]=recipe['ryu_voice']
    writes.append((recipe['ryu_directory'],struct.pack('>34I',*values)))
    return writes,{'roles':['shadow','voice'],'generations':[34,35,37,38],'tables':9,'bytes':sum(len(b)for _,b in writes),'native_control_owners':32}
