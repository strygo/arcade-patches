"""Original ordinary/Upper attract cycles with complete source palette rows."""
import hashlib,struct
from public_kit_graphics import require


def construct(inputs,recipe):
    require(set(inputs)==set(recipe['inputs'])=={'arcade','key','comp1','comp2'},'Complete cycle source inventory')
    for name,blob in inputs.items():
        pin=recipe['inputs'][name]
        require(len(blob)==pin['bytes']and hashlib.sha256(blob).hexdigest()==pin['sha256'],'Original cycle source identity')
    require(recipe['frames_per_mode']==44 and recipe['private_palette_rows']==15,'Complete cycle/source palette domains')
    region=recipe['region'];require(region in ('us','jp'),'Cycle original region')
    raw,key,c1,c2=(inputs[n]for n in ('arcade','key','comp1','comp2'))
    from cps2_crypt import decrypt_rom
    ops=decrypt_rom(raw[:0x7a98],key)[0]
    require(ops[0x79c4:0x79d8]==bytes.fromhex('3b7b00228ed6303b001e41f900364d1441f00000'),'Original opcode-view cycle/offset reader')
    native_base=struct.unpack_from('>I',ops,0x79d0)[0];native_root=0x79c6+(ops[0x79c7])
    require(native_root==0x79e8 and native_base==0x364d14,'Native PC-relative source table/palette base')
    dc=0x70 if region=='jp'else 0;ds=0x10f0 if region=='jp'else 0;gs=0x5700 if region=='jp'else 0;base=0x60b080 if region=='jp'else 0x60ad00
    def code(at,n):
        off=at-0x1f0040;require(0<=off<=len(c1)-4*n,'Original cycle reader bounds');return struct.unpack_from('<'+str(n)+'I',c1,off)
    def literal(at):
        hi,lo=code(at,2);require(hi>>26==15 and lo>>26==9 and hi>>16&31==lo>>21&31==lo>>16&31,'Original cycle pointer producer')
        n=lo&65535;return((hi&65535)*65536+(n-65536 if n&32768 else n))&0xffffffff
    def read(at,n):
        require(n>0 and 0<=at-base<=len(c2)-n,'Original cycle resource bounds');return c2[at-base:at-base+n]
    ordinary,upper,pal=0x24fba8+dc,0x24fbec+dc,0x24fc54+dc
    roots=(literal(ordinary),literal(upper));palette=literal(pal)
    require(roots==(0x60ce50+ds,0x60cf00+ds)and roots[1]-roots[0]==44*4 and palette==0x745560+gs,'Complete source mode/table/palette allocation')
    require(code(upper-16,4)==(0x3c027000,0x8c421150,0x10400005,0),'Original Upper mode branch')
    require(code(ordinary-16,4)==(0x94421124,0x00021880,0x3c027000,0xa4431124),'Original cycle index scaled by four')
    require(code(ordinary+8,2)==code(upper+8,2)==(0x3c027000,0xac431120),'Shared mode root store')
    require(code(pal-32,8)==(0x84421124,0x0002143c,0x0002143f,0x00621021,0x24420002,0x84430000,0x3c027000,0xa4431124),'Actual signed halfword palette offset reader')
    require(code(pal+16,11)==(0x3c027000,0x8c431100,0x3c027000,0x84421124,0x0002143c,0x0002143f,0x00621821,0x3c027000,0xac431100,0x3c0200a3,0x3443cfe0),'Actual palette base plus signed offset and destination')
    private=bytearray();writes=[];resident=0
    for mode,root in enumerate(roots):
        blob=read(root,176);output=bytearray()
        for i in range(44):
            control=blob[i*4:i*4+2];offset=struct.unpack_from('<h',blob,i*4+2)[0]
            require(control==(b'\xff\xff'if i==43 else bytes((2,0 if i==27 else i+1))),'Complete source cycle successor/control grammar')
            if mode==0:
                require(ops[native_root+i*4:native_root+i*4+2]==control and struct.unpack_from('>h',ops,native_root+i*4+2)[0]==offset,'Complete original native/PS2 ordinary cycle correspondence')
            target=native_base+offset
            if i<43:
                original=read(palette+offset,32);colors=b''.join(original[j:j+2][::-1]for j in range(0,32,2))
                if raw[target:target+32]!=colors:
                    require(mode==1 and i>=28 and offset==0x2180+(i-28)*32,'Declared Upper extra palette domain')
                    target=0xac81c2+len(private);private.extend(colors)
                else:resident+=1
            output.extend(control+b'\0\0'+struct.pack('>I',target))
        require(len(output)==352,'Complete expanded cycle record extent');writes.append(((0xac83a2,0xac8502)[mode],bytes(output)))
    require(len(private)==480 and resident==71,'Complete fifteen private and seventy-one resident palette demands')
    writes.append((0xac81c2,bytes(private)))
    return writes,{'bytes':1184,'modes':2,'records_per_mode':44,'resident_full_palette_rows':resident,'private_full_palette_rows':15,'terminal_records':2,'source_cycle_roots':[hex(v)for v in roots],'source_palette_base':hex(palette),'native_opcode_root':hex(native_root),'unclaimed':'Attract script and scene-owner controls remain separate.'}
