"""Complete original Guile/Fei three-ISM cancel-window resources."""
import hashlib,struct
from public_kit_graphics import require


def construct(inputs,recipe):
    require(set(inputs)==set(recipe['inputs'])=={'arcade','comp2'},'Complete cancel-bank inputs')
    for name,pin in recipe['inputs'].items():
        require(len(inputs[name])==pin['bytes']and hashlib.sha256(inputs[name]).hexdigest()==pin['sha256'],'Original cancel-bank source '+name)
    region=recipe['region'];require(region in ('us','jp'),'Cancel-bank region')
    base=0x60b080 if region=='jp'else 0x60ad00;table=0x74e3f8 if region=='jp'else 0x748cf8
    c2=inputs['comp2'];raw=inputs['arcade']
    def read(at,n):
        at-=base;require(0<=at<=len(c2)-n,'Original cancel-bank bounds');return c2[at:at+n]
    def windows(owner,count):
        bank=struct.unpack('<I',read(table+owner*4,4))[0];offsets=struct.unpack('<3h',read(bank,6))
        require(all(o>=6 and o%2==0 for o in offsets),'Original cancel-bank three-ISM offsets')
        return [read(bank+offset,count*2)for offset in offsets]
    control=struct.unpack_from('>I',raw,0xddda0)[0];offsets=struct.unpack_from('>3h',raw,control)
    require(all(row==raw[control+offset:control+offset+68]for row,offset in zip(windows(0,34),offsets)),'Complete native Ryu three-ISM cancel control')
    guile=b''.join(windows(32,36))
    return [(0xa191c6,guile)],{'source_owners':[32],'guile_rows_per_ism':36,'native_control_rows':102,'excluded_later_banks':[0xb71810,0xb71744],'bytes':216}
