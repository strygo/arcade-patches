"""Complete original34-owner parameter, walk and jump resource tables."""
import hashlib,struct
from public_kit_graphics import require

ROWS = (
    ('parameter_2cd', 0x2bdf8, 0xdf912, 1, 0x74c680, 0x751d80, 0x4376d8, 0x437748),
    ('parameter_24c', 0x2be14, 0xdf932, 1, 0x74c6a8, 0x751da8, 0x437784, 0x4377f4),
    ('parameter_158', 0x2be50, 0xdf992, 1, 0x74c720, 0x751e20, 0x437a5c, 0x437acc),
    ('arena_a6', 0x2be5c, 0xdcad2, 2, 0x748ca8, 0x74e3a8, 0x437a98, 0x437b08),
    ('walk_a', 0x2be6a, 0xdd492, 8, 0x7498d8, 0x74efd8, 0x437af0, 0x437b60),
    ('walk_v', 0x2be92, 0xdd592, 8, 0x749a18, 0x74f118, 0x437c40, 0x437cb0),
    ('walk_x', 0x2be7e, 0xdd692, 8, 0x749b58, 0x74f258, 0x437b44, 0x437bb4),
    ('jump_a', 0x2be70, 0xdd792, 64, 0x749c98, 0x74f398, 0x437b00, 0x437b70),
    ('jump_v', 0x2be98, 0xddf92, 64, 0x74a698, 0x74fd98, 0x437c50, 0x437cc0),
    ('jump_x', 0x2be84, 0xde792, 64, 0x74b098, 0x750798, 0x437b54, 0x437bc4),
)

FUNCTIONS = (
    ('parameters', (0x4376d8, 0x437748), 1456,
     ('e8a1dc853dce57d7b7051ae20cc55b51638090b16a427f826e1b0a203f052c19',
      'b8d6f8db39cdd34287a7636cbf3fda93ed1a12341a18788680712f5f1e1cd49a')),
    ('owner_ism_roots', (0x35bca4, 0x35bd14), 428,
     ('06c434a83dd5a1cc29397addc22a99f1992f6a291b2aef985c6f626fda8f3b9b',
      '27909a3f5720db36b6aef807e63501efd1a3a8b162bdf149324e139b1b8cb8b6')),
    ('walking_entry', (0x417bcc, 0x417c3c), 468,
     ('0b64b28cb96ec9604b9d067b505d65d871edab2349d20a7e367c0cba70c0479d',
      '9daeba3f8fcce37f132421ac1027fc2b5cacb4e28c80568e23d1ae2202a9debd')),
    ('walk_velocity', (0x42a9b0, 0x42aa20), 376,
     ('08f42dc71c1c15405f81a5bb010daa3655d748f1971cfb3dc52588610ceebeb9',)*2),
    ('jump_velocity', (0x42b1c4, 0x42b234), 776,
     ('6627d832080f44d43d4730d0f42defa7d95a0a1db09a1604d575f6dce7a83311',)*2),
)

NATIVE_PINS = {
    'parameter_2cd': '09e9a5a63370747f6902923caba537a94ac0a1c40c7cde1a38ff99a40a57a88e',
    'parameter_24c': 'c8d24cf0dd96cc8e8d7c3db4a53af351f30bc9952499ef420d68f8b8264b65d0',
    'parameter_158': '8f32742b8343305ecec325ce8c89b9d1a44a5ef7a8f54c4f3b001805a0d3e337',
    'arena_a6': '36963cc6a77beb1d6d3a58bed53f068ec7e831bb8a2a399f73002fcae2c1801d',
    'walk_a': '3af79126b00565363f95d4090aedff5b3b46f0233622e3d40bb340f85d122d88',
    'walk_v': 'f51526fada38e529e8669e06a59c81669baa2a04ae13a9e3f63488ef2d452301',
    'walk_x': '98e63c95ccee3d597326d09c234818ed8dc4333d85c2e051d7e328ace365545a',
    'jump_a': 'ad9249ed2c16cafc4b19b3dfee0779f2576eb8eb19bd3400cd4cce922728e54a',
    'jump_v': 'ad9249ed2c16cafc4b19b3dfee0779f2576eb8eb19bd3400cd4cce922728e54a',
    'jump_x': 'ce48292a65209a292ebad1db65b3d4ef1068eecc3a5e53900ba6704c698207c9',
}

def construct(inputs,recipe):
    require(set(inputs)==set(recipe['inputs'])=={'arcade','comp1','comp2'},'Complete motion input domain')
    for name,pin in recipe['inputs'].items():
        require(len(inputs[name])==pin['bytes'] and hashlib.sha256(inputs[name]).hexdigest()==pin['sha256'],'Original motion input '+name)
    region=recipe['region'];require(region in ('us','jp'),'Motion region')
    index=int(region=='jp');base=0x60b080 if index else 0x60ad00
    for name,addresses,size,hashes in FUNCTIONS:
        at=addresses[index]-0x1f0040
        require(hashlib.sha256(inputs['comp1'][at:at+size]).hexdigest()==hashes[index],'Complete original motion reader '+name)
    blob=bytearray();tables=[];controls=0
    for role,hook,native,stride,usa,jp,*_ in ROWS:
        blob.extend(b'\xff'*((-len(blob))%(4 if stride>=8 else 2)))
        native+=0x128e;resident=inputs['arcade'][native:native+32*stride]
        require(hashlib.sha256(resident).hexdigest()==NATIVE_PINS[role],'Complete native motion prefix '+role)
        at=(jp if index else usa)-base;original=inputs['comp2'][at:at+34*stride]
        require(len(original)==34*stride,'Complete original motion owner rows')
        unit=1 if stride==1 else 2 if stride==2 else 4
        projected=b''.join(original[n:n+unit][::-1]for n in range(0,len(original),unit))
        for owner in (0,1,3,4,29):
            require(resident[owner*stride:(owner+1)*stride]==projected[owner*stride:(owner+1)*stride],'Original motion resident control '+role)
            controls+=1
        tables.append({'role':role,'address':0xb02000+len(blob),'rows':34,'stride':stride})
        blob.extend(resident+projected[32*stride:])
    require(len(blob)==7516,'Complete ten-table motion allocation extent')
    return [(0xb02000,bytes(blob))],{'tables':tables,'original_reader_functions':len(FUNCTIONS),'native_control_rows':controls,'bytes':len(blob)}
