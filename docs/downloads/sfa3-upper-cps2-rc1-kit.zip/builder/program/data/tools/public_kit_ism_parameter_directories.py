"""Complete original per-ISM scalar owner tables through four emitter generations."""
import hashlib
import struct
from public_kit_graphics import require


def construct(inputs,recipe):
    require(set(inputs)==set(recipe['inputs'])=={'comp1','comp2'},'Original parameter component domain')
    for name,blob in inputs.items():
        pin=recipe['inputs'][name]
        require(len(blob)==pin['bytes'] and hashlib.sha256(blob).hexdigest()==pin['sha256'],'Original parameter input identity')
    require(recipe['source_region']=='jp','Inherited original Japanese mechanical table source')
    base=0x60b080
    require(recipe['region'] in ('us','jp'),'Original parameter region')
    source=recipe['source'];offset=source-base
    require(0<=offset<=len(inputs['comp2'])-152,'Complete original38-owner parameter extent')
    records=inputs['comp2'][offset:offset+152]
    require(hashlib.sha256(records[:128]).hexdigest()==recipe['native_prefix_sha256'],'Complete original32-owner scalar control')
    witnesses=[]
    for register in range(1,32):
        pair=struct.pack('<2I',0x3c000000|(register<<16)|((source+0x8000)>>16),
                         0x24000000|(register<<21)|(register<<16)|(source&65535))
        witnesses.extend(at for at in range(0,len(inputs['comp1'])-7,4) if inputs['comp1'][at:at+8]==pair)
    require(witnesses==[recipe['loader']-0x1f0040],'Unique original signed-immediate scalar-table loader')
    require(records[140:144]==bytes(4),'Original Hawk row equals held zero row')
    require(records[144:148]==records[8:12],'Original Shin row equals native Akuma control')
    require(records[148:152]==records[84:88],'Original Boxer row equals native21 control')
    require(set(recipe['tables'])=={'34','35','37','38'},'Complete retained scalar table generations')
    writes=[]
    for count in (34,35,37,38):
        target=recipe['tables'][str(count)]
        require(type(target)is int and target%4==0 and 0xb70000<=target<=0xc74000-count*4,'Original scalar table allocation')
        # The original emitter temporarily held35 with zero. The source-bound
        # equality above proves that supplying Hawk preserves the whole row.
        writes.append((target,records[:count*4]))
    return writes,{'scalar_bytes_per_owner':4,'native_control_owners':32,
                   'generations':[34,35,37,38],'complete_source_owners':38,
                   'bytes':sum(len(blob) for _,blob in writes)}


def self_test():
    source=0x60b180;records=bytearray(range(152));records[140:144]=bytes(4)
    records[144:148]=records[8:12];records[148:152]=records[84:88]
    register=5
    pair=struct.pack('<2I',0x3c000000|(register<<16)|((source+0x8000)>>16),
                     0x24000000|(register<<21)|(register<<16)|(source&65535))
    inputs={'comp1':bytes(4)+pair+bytes(4),'comp2':bytes(256)+bytes(records)}
    recipe={'region':'us','source_region':'jp','source':source,'loader':0x1f0044,
            'native_prefix_sha256':hashlib.sha256(records[:128]).hexdigest(),
            'inputs':{n:{'bytes':len(v),'sha256':hashlib.sha256(v).hexdigest()}for n,v in inputs.items()},
            'tables':{str(n):0xb70000+i*0x100 for i,n in enumerate((34,35,37,38))}}
    writes,report=construct(inputs,recipe)
    require(report['bytes']==576 and [b for _,b in writes]==[bytes(records[:n*4])for n in (34,35,37,38)],'Complete scalar generation fixture')
    import copy
    for kind in ('missing-generation','changed-prefix','changed-loader','held-row'):
        bad=dict(inputs);changed=copy.deepcopy(recipe)
        if kind=='missing-generation':changed['tables'].pop('35')
        else:
            name='comp1' if kind=='changed-loader' else 'comp2'
            at=4 if name=='comp1' else 256+(140 if kind=='held-row' else 0)
            raw=bytearray(bad[name]);raw[at]^=1;bad[name]=bytes(raw)
            changed['inputs'][name]['sha256']=hashlib.sha256(raw).hexdigest()
        try:construct(bad,changed)
        except ValueError:continue
        raise ValueError('Invalid scalar fixture accepted: '+kind)
    return {'passed':True,'rejected_mutations':4,'bytes':576}


if __name__=='__main__':
    import argparse,json
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--self-test',action='store_true')
    args=parser.parse_args();require(args.self_test,'Use construct() with declared inputs and recipe')
    print(json.dumps(self_test(),sort_keys=True))
