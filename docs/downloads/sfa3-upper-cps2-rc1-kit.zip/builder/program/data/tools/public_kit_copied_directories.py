"""Whole retained move-family directories bound to original native action graphs.

Only typed root offsets are emitted. Copied/amended frames and all artwork
remain separately qualified; numeric allocation coordinates are not payloads.
"""
import hashlib
import struct
from public_kit_graphics import require

# Owner, family, original count excluding terminator, new table, copied frame
# count, first appended graph, and declared whole-action allocation redirects.
FAMILIES=(
 (13,2,49,0xab7aec,470,0xaba0b4,{19:0xaba0b4,20:0xaba1a8}),
 (13,3,31,0xaba29c,221,0xabb490,{4:0xabb490}),
 (15,3,58,0xabb584,453,0xabd9d4,{9:0xabd9d4,10:0xabda3c,11:0xabdab8,48:0xabdb34,49:0xabdbb0,50:0xabdc2c,51:0xabdca8}),
 (16,3,34,0xabdd24,204,0xabed5c,{12:0xabed5c}),
 (11,0,68,0xabede8,231,0xac0110,{34:0xac0110}),
)


def u32(blob,at):
    require(0<=at<=len(blob)-4,'Original native pointer extent')
    return struct.unpack_from('>I',blob,at)[0]


def domain(arcade,owner,family,count,replacements):
    bank=u32(arcade,0xde6a0+owner*4);root=u32(arcade,bank+family*4)
    require(0<=root<=len(arcade)-(count+1)*2,'Original native root bounds')
    offsets=struct.unpack_from('>'+str(count+1)+'h',arcade,root)
    require(offsets[-1]==0 and all(offsets[:-1]),'Complete original root extent')
    targets=[root+n for n in offsets[:-1]];records={}
    for action,target in enumerate(targets):
        if action in replacements:continue
        at=target;seen=set()
        while at is not None and at not in seen:
            require(0<=at<=len(arcade)-20,'Original copied-family frame bounds')
            seen.add(at);flags=arcade[at+1];size=24 if flags&128 else 20
            require(at+size<=len(arcade),'Original copied-family record extent')
            records[at]=size
            at=u32(arcade,at+20) if flags&128 else None if flags&64 else at+20
            require(len(seen)<2048,'Bounded original copied-family graph')
    return root,targets,dict(sorted(records.items()))


def construct(arcade,recipe):
    pin=recipe['input'];require(len(arcade)==pin['bytes'] and hashlib.sha256(arcade).hexdigest()==pin['sha256'],'Canonical original arcade identity')
    writes=[];reports=[]
    for owner,family,count,target,frames,end,replacements in FAMILIES:
        root,targets,records=domain(arcade,owner,family,count,replacements)
        require(len(records)==frames,'Complete original copied-family frame allocation count')
        cursor=(target+(count+1)*2+3)&~3;mapping={}
        for at,size in records.items():mapping[at]=cursor;cursor+=size
        require(cursor==end,'Complete original copied-family allocation extent')
        destinations=[replacements[i] if i in replacements else mapping[at]for i,at in enumerate(targets)]
        offsets=[at-target for at in destinations]
        require(all(0<v<32768 for v in offsets),'Complete copied-family signed root reach')
        blob=struct.pack('>'+str(count+1)+'h',*offsets,0);writes.append((target,blob))
        reports.append({'owner':owner,'family':family,'original_root':hex(root),'entries':count,'bytes':len(blob),'target':hex(target),'original_frames_traversed':frames,'replacement_actions':sorted(replacements)})
    return writes,reports
