"""Complete Evil ending commands, actor groups, parameters and library directory."""
import hashlib,struct
import public_kit_ending_command_groups as commands
import public_kit_ending_actor_groups as actors
import public_kit_ending_frames as frames
from public_kit_graphics import require


def construct(inputs,recipe):
    require(set(inputs)==set(recipe['inputs'])=={'comp2','metadataevil'},'Complete Evil ending original source inventory')
    for name,pin in recipe['inputs'].items():
        require(len(inputs[name])==pin['bytes']and hashlib.sha256(inputs[name]).hexdigest()==pin['sha256'],'Original Evil ending identity: '+name)
    region=recipe['region'];require(region in ('us','jp'),'Original ending region')
    base=0x60ad00 if region=='us'else 0x60b080;shift=0x10f0 if region=='jp'else 0;data=inputs['comp2']
    def read(at,n):
        require(0<=at-base<=len(data)-n,'Original Evil ending resource bounds');return data[at-base:at-base+n]
    def root(tables):
        roots=[struct.unpack('<I',read(t+shift+23*4,4))[0]for t in tables]
        require(roots[0]==roots[1],'Original Evil ending mode aliases');return roots[0]
    source=root((0x60b860,0x60b910));rows,end=commands.parse(read,source,'<')
    require(len(rows)==50 and end-source==460,'Complete50-record Evil ending command stream')
    footer,stop=commands.command(read,end,'<');require(stop-end==4 and footer[0]==8,'Complete Evil held terminal prefetch')
    cursor=0xbc6000;changes={0xbc6016:(0,2),0xbc603a:(64,63)};seen=set()
    for row in rows:
        if cursor in changes:
            before,after=changes[cursor];require(row[0]==before,'Reviewed Evil timer preimage');row[0]=after;seen.add(cursor)
        cursor+=4+2*len(row[2])
    require(seen==set(changes),'Both original reviewed timer changes bind command boundaries')
    command_blob=commands.pack(rows+[footer]);require(len(command_blob)==464,'Complete Evil command allocation')
    groups=actors.groups(read,root((0x60b220,0x60b2d0)),'<')
    require([len(g)if g is not None else 0 for g in groups]==[12,9,11,0]and groups[-1]is None,'Complete Evil actor domain and disabled selector')
    header=bytearray(8);body=bytearray();expected=[]
    for index,group in enumerate(groups):
        if group is None:expected.append(None);continue
        converted=actors.encode(group,'<');expected.append(converted)
        struct.pack_into('>H',header,index*2,8+len(body));body.extend(b''.join(converted)+b'\xff\xff')
    actor_blob=bytes(header+body);require(len(actor_blob)==1038,'Complete Evil actor allocation')
    require(actors.groups(lambda at,n:actor_blob[at:at+n],0,'>')==expected,'Complete emitted mixed-field actor roundtrip')
    parameters=struct.pack('>3H',*struct.unpack('<3H',read(0x60b9c0+shift+23*6,6)))
    row=recipe['library'];require(row['family']=='evil'and row['root']==0xbc816c,'Original Evil library allocation')
    library,targets,graph,_=frames.graph(inputs,row);mapping=dict(row['frames'])
    require(set(mapping)==set(graph)and len(graph)==14 and all(v[2]is None for v in graph.values()),'Complete14-static-frame Evil source library')
    require(row['full']==[3,4,5,6,7,8,10]and row['compact']==[11,12,13,16,17,18,19],'Complete original Evil selector domain')
    directory=bytearray(40)
    for selector in row['full']+row['compact']:struct.pack_into('>h',directory,selector*2,mapping[targets[selector]]-row['root'])
    writes=[(0xbc6000,command_blob),(0xbc61d0,actor_blob),(0xbc65de,parameters),(row['root'],bytes(directory))]
    return writes,{'bytes':sum(len(b)for _,b in writes),'commands':50,'prefetch_bytes':4,'actor_groups':[12,9,11,0],
        'disabled_actor_selectors':[4],'reviewed_timer_changes':2,'library_slots':20,'active_library_selectors':14,
        'scope':'Complete flow resources and root directory; frame/cel artwork qualified separately.'}
