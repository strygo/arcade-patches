"""Complete Dhalsim X-normal directory from original graph order and typed relocations.

This proves the directory only. Scalar amendments and artwork of the pointed
frames remain separately qualified resources.
"""
import hashlib
import struct
from public_kit_graphics import require

ROOT_TABLE=0xde6a0
START=0xa80078
ROOT=0xa82688


def u32(data,at):
    require(0<=at<=len(data)-4,'Native source pointer bounds')
    return struct.unpack_from('>I',data,at)[0]


def domain(data):
    bank=u32(data,ROOT_TABLE+15*4);roots=[u32(data,bank+i*4) for i in range(12)]
    require(roots[3]==roots[7]==roots[11],'Original Dhalsim normal ISM aliases')
    root=roots[7];targets=[]
    for i in range(59):
        require(0<=root+i*2<=len(data)-2,'Original Dhalsim directory bounds')
        offset=struct.unpack_from('>h',data,root+i*2)[0]
        if not offset:break
        targets.append(root+offset)
    require(len(targets)==58 and not offset,'Complete original Dhalsim normal directory extent')
    families=[];records={}
    for target in targets:
        addresses=[];at=target
        while at is not None and at not in addresses:
            require(0<=at<=len(data)-20,'Original Dhalsim frame bounds')
            addresses.append(at);flags=data[at+1];length=24 if flags&128 else 20
            require(at+length<=len(data),'Original Dhalsim successor bounds')
            records[at]=data[at:at+length]
            at=u32(data,at+20) if flags&128 else None if flags&64 else at+20
            require(len(addresses)<=2048,'Bounded original Dhalsim frame graph')
        families.append(addresses)
    require(len(families[27])==7,'Original replaced Dhalsim X27 extent')
    retained=set().union(*(set(rows) for i,rows in enumerate(families) if i!=27))
    return root,targets,{at:records[at] for at in sorted(retained)},families


# Whole-action replacements allocated by dhalsim_x27.packet and batch20's
# upper_playtest_fixes11 move-shape converter; these are numeric locations,
# never literal frame payloads. Original ordering and table extent are parsed.
REPLACEMENTS={27:0xa80000,9:0xa7a6a8,51:0xa7a710,10:0xa7a78c,
              11:0xa7a808,48:0xa7a884,49:0xa7a900,50:0xa7a97c}


def construct(arcade,recipe):
    pin=recipe['input']
    require(len(arcade)==pin['bytes'] and hashlib.sha256(arcade).hexdigest()==pin['sha256'],'Canonical original arcade source identity')
    source_root,targets,records,families=domain(arcade)
    mapping={};cursor=START
    for at,value in records.items():mapping[at]=cursor;cursor+=len(value)
    require(cursor==ROOT,'Complete retained Dhalsim graph allocation extent')
    offsets=[]
    for action,target in enumerate(targets):
        destination=REPLACEMENTS[action] if action in REPLACEMENTS else mapping[target]
        delta=destination-ROOT
        require(-32768<=delta<=32767 and delta!=0,'Native complete directory signed offset reach')
        offsets.append(delta)
    value=struct.pack('>59h',*offsets,0)
    return [(ROOT,value)],{'source_root':source_root,'actions':58,'bytes':len(value),
                          'relocated_original_frames':len(records),'replacement_actions':sorted(REPLACEMENTS),
                          'pointed_frame_scalars_and_artwork':'separate qualification'}
