"""Complete original collision resources with reviewed, source-relative deltas."""
import argparse
import hashlib
import json
from pathlib import Path

import public_kit_cohort_combat as combat
import public_kit_dolls_collision_base as dolls
import public_kit_resource_delta as delta

FAMILIES={'fei-loop':(0xb70214,4794,8),'dee':(0xbdd198,5426,4),'dolls-retained':(0xab0000,8130,8)}


def require(ok,message):
    if not ok:raise ValueError(message)


def digest(blob):return hashlib.sha256(blob).hexdigest()


def bases(inputs,region):
    require(region in ('us','jp') and set(inputs)=={'arcade','comp2','coords'},'Complete original collision delta source domain')
    arrays,graphs=combat.catalog(inputs['comp2'],region,inputs['coords'])
    fei=arrays['collision:33:0'][1][:4794];dee=arrays['collision:34:0'][1][:5426]
    retained,report=dolls.construct(inputs['arcade'],inputs['comp2'],region)
    result={'fei-loop':fei,'dee':dee,'dolls-retained':retained}
    require(all(len(result[name])==size for name,(_,size,_)in FAMILIES.items()),'Complete original emitted collision resource extents')
    return result,{'cohort_source_graphs':graphs,'retained_dolls_source':report}


def construct(inputs,recipe):
    require(set(recipe)=={'schema','region','inputs','resources'} and recipe['schema']==1,'Reviewed collision delta recipe schema')
    require(set(inputs)==set(recipe['inputs'])=={'arcade','comp2','coords'},'Declared collision original inputs')
    for name,blob in inputs.items():
        pin=recipe['inputs'][name]
        require(set(pin)=={'bytes','sha256'} and len(blob)==pin['bytes'] and digest(blob)==pin['sha256'],'Original collision input identity: '+name)
    original,source=bases(inputs,recipe['region'])
    require(set(recipe['resources'])==set(FAMILIES),'Complete reviewed collision delta inventory')
    writes=[];reports={}
    for name,(address,size,count)in FAMILIES.items():
        patch=recipe['resources'][name]
        require(patch['bytes']==size and len(patch['changes'])==count,'Reviewed complete resource extent and correction count')
        blob=delta.apply(original[name],patch);writes.append((address,blob))
        reports[name]={'address':hex(address),'bytes':size,'correction_bytes':count,
                       'base_sha256':digest(original[name]),'output_sha256':digest(blob)}
    return writes,{'resources':reports,'source':source,'verified_bytes':sum(len(b)for _,b in writes),
                   'correction_bytes':sum(r['correction_bytes']for r in reports.values()),
                   'qualification':'Whole source resources plus reviewed field deltas; no arbitrary output ranges or missing-art fallback.'}


def main():
    p=argparse.ArgumentParser(description=__doc__)
    for name in ('inputs','recipe','out'):p.add_argument('--'+name,type=Path,required=True)
    a=p.parse_args();require(not a.out.exists(),'Fresh collision delta output required')
    recipe=json.loads(a.recipe.read_text());inputs={n:(a.inputs/(n+'.bin')).read_bytes()for n in ('arcade','comp2','coords')}
    writes,report=construct(inputs,recipe);data=bytearray(0x400000);mask=bytearray(len(data))
    for address,blob in writes:
        at=address-0xa00000;require(0<=at<=len(data)-len(blob),'Whole upper resource allocation')
        require(not any(mask[at:at+len(blob)]),'Collision delta resource allocations overlap')
        data[at:at+len(blob)]=blob;mask[at:at+len(blob)]=b'\1'*len(blob)
    a.out.mkdir();(a.out/'data.bin').write_bytes(data);(a.out/'mask.bin').write_bytes(mask)
    (a.out/'report.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')


if __name__=='__main__':main()
