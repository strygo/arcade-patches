"""Complete source-owned Fei, Dee Jay and T. Hawk collision/attack resources."""
import hashlib
import struct
from public_kit_actor import Data
from public_kit_frame_resources import owner_graph
from public_kit_graphics import require


def catalog(comp2,region,coords):
    require(region in ('us','jp'),'Unknown cohort combat region')
    delta=0x5700 if region=='jp' else 0
    data=Data(comp2,0x60b080 if region=='jp' else 0x60ad00,coords,0xb04000)
    arrays={};summary={}
    def words(raw):return b''.join(raw[n:n+2][::-1] for n in range(0,len(raw),2))
    for owner in (33,34,35):
        frames,_=owner_graph(data,0x749838+delta,owner)
        raw=[data.read(at,20) for at in frames]
        maxima={n:max(v[n] for v in raw) for n in (8,9,10)}
        require(maxima[8]<128 and maxima[10]<128,'Signed native selector extent')
        hp,ep,vp=[data.u32(table+delta+owner*4) for table in (0x7493d8,0x749478,0x749338)]
        indices=data.read(hp,(maxima[8]+1)*4);events=data.read(ep,(maxima[10]+1)*4)
        require(all(events[n]==0 and events[n+1] in (0,1,255) for n in range(0,len(events),4)),'Unknown event callback grammar')
        arrays[f'indices:{owner}']=(hp,indices)
        arrays[f'events:{owner}']=(ep,events)
        banks=[]
        for ism in range(3):
            source=data.u32(vp+ism*4);offsets=struct.unpack('<5h',data.read(source,10))
            require(offsets[0]==10 and all(a<z and (z-a)%8==0 for a,z in zip(offsets,offsets[1:])),'Collision lane header/stride')
            counts=[(z-a)//8 for a,z in zip(offsets,offsets[1:])]
            for frame in raw:
                selected=indices[frame[8]*4:frame[8]*4+4]
                require(all(v<count for v,count in zip(selected,counts)),'Original frame collision index outside lane')
            lanes=words(data.read(source+10,offsets[4]-10))
            attacks=data.read(source+offsets[4],(maxima[9]+1)*32)
            attacks=b''.join(words(attacks[n:n+8])+attacks[n+8:n+32] for n in range(0,len(attacks),32))
            blob=struct.pack('>5h',*offsets)+lanes+attacks
            arrays[f'collision:{owner}:{ism}']=(source,blob)
            arrays[f'lanes:{owner}:{ism}']=(source,blob[:offsets[4]])
            for row in range(maxima[9]+1):
                arrays[f'attack:{owner}:{ism}:{row}']=(source+offsets[4]+row*32,attacks[row*32:row*32+32])
            banks.append({'ism':ism,'lane_rows':counts,'attack_rows':maxima[9]+1})
        summary[str(owner)]={'frames':len(frames),'maxima':maxima,'banks':banks}
    return arrays,summary


def construct(comp2,coords,recipe):
    require(recipe['schema']==1,'Unknown cohort combat recipe')
    require(hashlib.sha256(comp2).hexdigest()==recipe['source_sha256'] and
            hashlib.sha256(coords).hexdigest()==recipe['coords_sha256'],'Original combat inputs changed')
    arrays,summary=catalog(comp2,recipe['region'],coords)
    require(set(arrays)==set(recipe['placements']),'Incomplete collision/selector owner domain')
    writes=[]
    for name,(source,blob) in arrays.items():
        targets=recipe['placements'][name]
        require(len(targets)==len(set(targets)),'Duplicate combat placement')
        if name.startswith(('attack:','lanes:','collision:')):
            fields=name.split(':');kind,who,ism=fields[:3];lane='lanes:'+who+':'+ism
            allowed=set()
            for owner,bank,address,count in recipe['banks']:
                require(owner in (33,34,35) and bank in range(3) and 0<count<=summary[str(owner)]['banks'][bank]['attack_rows'],
                        'Unknown collision allocation source domain')
                require(address%2==0 and 0xa00000<=address<=0xe00000-len(arrays[f'lanes:{owner}:{bank}'][1])-count*32,
                        'Collision allocation extent')
                if (owner,bank)!=(int(who),int(ism)):continue
                offset=int(fields[3])*32+len(arrays[lane][1]) if kind=='attack' else 0
                if offset+len(blob)<=len(arrays[lane][1])+count*32:allowed.add(address+offset)
            require(set(targets)<=allowed,'Combat row detached from declared complete allocation')
        for at in targets:
            require(at%2==0 and 0xa00000<=at<=0xe00000-len(blob),'Combat allocation bounds')
            writes.append((at,blob))
    return writes,summary


def main():
    import argparse
    import json
    from pathlib import Path
    parser=argparse.ArgumentParser(description=__doc__)
    for name in ('pools','recipes','outdir'):parser.add_argument('--'+name,type=Path,required=True)
    args=parser.parse_args();recipes=json.loads(args.recipes.read_text());args.outdir.mkdir(exist_ok=True)
    require(set(recipes)=={'us','jp'},'Incomplete regional combat recipe')
    for region,recipe in recipes.items():
        writes,_=construct((args.pools/f'ps2-{region}-comp2.bin').read_bytes(),
                          (args.pools/f'ps2-{region}-coords390.bin').read_bytes(),recipe)
        data=bytearray(0x400000);mask=bytearray(len(data))
        for at,blob in writes:
            at-=0xa00000
            require(all(not mask[at+i] or data[at+i]==v for i,v in enumerate(blob)),'Conflicting combat alias')
            data[at:at+len(blob)]=blob;mask[at:at+len(blob)]=b'\1'*len(blob)
        (args.outdir/(region+'.bin')).write_bytes(data);(args.outdir/(region+'.mask')).write_bytes(mask)


if __name__=='__main__':main()
