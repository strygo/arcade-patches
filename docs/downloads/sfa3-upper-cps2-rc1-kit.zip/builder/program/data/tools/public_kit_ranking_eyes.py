"""Complete original ranking eye-strip owner directory and eight compact cels.

The source reader selects its animation through the forty-byte owner map;
existing native animations retain their original roots, and selectors39..40
(hex) expand to six individual tiles in bank3. All imported pixels are checked.
"""
import hashlib,struct
from public_kit_graphics import require
from public_kit_hover_objects import cel,tiles_for


def construct(inputs,recipe,pixels):
    for name,pin in recipe['inputs'].items():require(len(inputs[name])==pin['bytes']and hashlib.sha256(inputs[name]).hexdigest()==pin['sha256'],'Ranking eye input '+name)
    require(set(recipe['inputs'])=={'arcade','comp2','font'},'Complete ranking eye source inventory')
    region=recipe['region'];require(region in ('us','jp'),'Ranking eye region')
    base=0x60ad00 if region=='us'else 0x60b080
    table=0x674c00 if region=='us'else 0x675eb0
    at=(0x617770 if region=='us'else 0x618860)-base
    owners=inputs['comp2'][at:at+40]
    require(len(owners)==40 and set(owners)==set(range(0x20,0x41)),'Complete original forty-owner eye animation domain')
    comp2=inputs['comp2'];arcade=inputs['arcade'];font=inputs['font'];writes=[];directory=[]
    require(len(recipe['tiles'])==8 and all(len(row)==6 for row in recipe['tiles']),'Complete eight six-tile eye allocation')
    for index in owners:
        if index>=0x39:directory.append(0xaa7800+(index-0x39)*8)
        else:
            root=0x301fa2+struct.unpack_from('>H',arcade,0x301fa2+index*2)[0]
            require(0x300000<=root<len(arcade)-8,'Original native eye animation root')
            directory.append(root)
    writes.append((0xaa76c0,struct.pack('>40I',*directory)))
    count=0
    for n,index in enumerate(range(0x39,0x41)):
        position=table-base+struct.unpack_from('<H',comp2,table-base+index*2)[0]
        timer,flags,word,source=struct.unpack_from('<BBHI',comp2,position)
        require(flags==0x40 and word==0,'Original complete held eye frame')
        original=cel(comp2,source-base,'<',base);commands=list(tiles_for(original['commands']))
        require(original['kind']==8 and original['total']==len(commands)==6,'Complete original eye strip canvas')
        target=0xaa7840+n*58;xy=target+34
        writes.append((0xaa7800+n*8,struct.pack('>BBHI',timer,flags,word,target)))
        body=bytearray(struct.pack('>3HI',2,6,5,xy));points=bytearray()
        for (code,attr,x,y),native in zip(commands,recipe['tiles'][n]):
            require(type(native)is int and 0<=native<65536,'Eye tile allocation')
            image=font[(code+0x1c00)*128:(code+0x1c01)*128]
            require(len(image)==128 and pixels[(native+0x30000)*128:(native+0x30001)*128]==image,'Whole original eye-strip tile differs')
            body.extend(struct.pack('>2H',native,attr));points.extend(struct.pack('>2h',x,y));count+=1
        writes.append((target,bytes(body+points)))
    return writes,{'bytes':688,'owner_roots':40,'frames':8,'cels':8,'checked_tiles':count}
