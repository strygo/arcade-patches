"""Complete original Hawk and Boxer action directory projections.

Only directory tables and root banks are claimed; frame records, artwork and
runtime behavior remain separate resource qualifications.
"""
import hashlib
import struct
from public_kit_actor import Data
from public_kit_graphics import require

FAMILIES=(('hawk',35,(64,48,64,31),(0xd7a680,0xd7a702,0xd7a764,0xd7a7e6),0xd7a828,0xd70000),
          ('boxer',21,(70,48,56,30,56),(0xc7feb6,0xc7ff44,0xc7ffa6,0xc80018,0xc80056),0xc800c8,0xc70000))


def source_families(data,table,owner):
    roots=struct.unpack('<12I',data.read(data.u32(table+owner*4),48))
    unique=list(dict.fromkeys(roots));targets=[data.root(root)[1] for root in unique]
    return roots,unique,targets


def construct(comp2,recipe):
    pin=recipe['input']
    require(len(comp2)==pin['bytes'] and hashlib.sha256(comp2).hexdigest()==pin['sha256'],'Original fighter directory source identity')
    data=Data(comp2,recipe['base'],b'',0xb04000)
    require([g['name'] for g in recipe['groups']]==[f[0] for f in FAMILIES],'Complete fighter directory inventory')
    writes=[];reports=[]
    for group,(name,owner,counts,destinations,bank,lower) in zip(recipe['groups'],FAMILIES):
        roots,unique,targets=source_families(data,recipe['owner_table'],owner)
        require(tuple(map(len,targets))==counts,'Original '+name+' complete family extents')
        expected_aliases=(0,1,2,3)*3 if name!='boxer' else (0,1,2,3,0,1,4,3,0,1,2,3)
        require(tuple(unique.index(r) for r in roots)==expected_aliases,'Original '+name+' ISM aliases')
        aliases=dict(zip(unique,destinations))
        admitted=[set(range(n)) for n in counts]
        wanted={t for rows,actions in zip(targets,admitted) for i,t in enumerate(rows) if i in actions}
        mapping=dict(group['frames'])
        require(len(mapping)==len(group['frames']) and set(mapping)==wanted,'Complete '+name+' admitted root target inventory')
        require(all(lower<=at<destinations[0] for at in mapping.values()),name+' frame allocation outside owned range')
        begin=len(writes)
        for destination,rows,actions in zip(destinations,targets,admitted):
            offsets=[mapping[target]-destination if i in actions else 0 for i,target in enumerate(rows)]
            require(all(-32768<=offset<0 for i,offset in enumerate(offsets) if i in actions),name+' signed root reach')
            writes.append((destination,struct.pack('>'+str(len(rows)+1)+'h',*offsets,0)))
        writes.append((bank,struct.pack('>12I',*(aliases[root] for root in roots))))
        reports.append({'family':name,'directory_entries':list(counts),'admitted_entries':[len(a) for a in admitted],
                        'bytes':sum(len(blob) for _,blob in writes[begin:]),'qualification':'Complete directories and banks only; frames and artwork separate'})
    return writes,reports
