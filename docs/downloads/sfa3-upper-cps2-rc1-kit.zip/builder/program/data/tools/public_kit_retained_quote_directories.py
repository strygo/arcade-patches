"""USA retained quote layout structures after Japanese payload erasure.

Numeric allocation extents describe historical reader ABI, not text payload.
This resource emits complete offset/pointer tables and never reads a JP disc.
"""
import struct
from public_kit_graphics import require

OWNERS=(32,33,34,35,23)
PARAGRAPHS={'guile_opening':(103,106),'cohort_opening':(103,109),'evil_opening':(94,96),
 'dee_opening':(110,112),'guile_rival':(668,691),
 'guile_ending':(690,726),'fei_ending':(727,747),'evil_ending':(639,648),
 'dee_ending':(748,766),'hawk_ending':(767,788),'boxer_ending':(611,638),
 'juli_ending':(649,667),'juni_ending':(668,689)}


def construct(recipe):
    require(recipe['region']=='us','Retained erased-text directory region')
    require([r['owner']for r in recipe['families']]==list(OWNERS),'Complete retained quote owner inventory')
    writes={};reports=[]
    def put(at,blob):
        require(0xa00000<=at<=0xe00000-len(blob),'Retained quote directory bounds')
        require(at not in writes or writes[at]==blob,'Conflicting aliased retained quote structure')
        writes[at]=blob
    for row in recipe['families']:
        owner=row['owner'];sizes=row['record_bytes']
        require(len(sizes)==41 and all(isinstance(n,int)and 2<=n<=512 for n in sizes),'Complete allocated41-record quote domain')
        offset=84;offsets=[]
        for size in sizes:offsets.append(offset);offset+=(size+1)&~1
        require(offset<32768,'Retained packed quote extent')
        put(row['pool'],struct.pack('>42H',*offsets,0))
        pointers=row['directed_pools'];require(len(pointers)==32,'Complete retained directed32 domain')
        for winner,pointer in enumerate(pointers):
            if pointer==0:
                require(owner==winner==23,'Unknown retained null directed owner')
            else:put(pointer,struct.pack('>2H',4,0))
        put(row['directed'],struct.pack('>32I',*pointers))
        reports.append({'owner':owner,'own_offsets':41,'directed_entries':32,'pool':hex(row['pool']),'record_extent':offset})
    require([r['name']for r in recipe['paragraphs']]==list(PARAGRAPHS),'Complete retained paragraph family inventory')
    for row in recipe['paragraphs']:
        first,last=PARAGRAPHS[row['name']];records=row['records'];directory=row['directory']
        require(len(records)==last-first+1,'Complete retained paragraph record domain')
        require(records==sorted(set(records)) and records[0]>=directory+len(records)*2,'Retained paragraph allocation order')
        offsets=[at-(directory-first*2)for at in records]
        require(all(0<n<32768 for n in offsets),'Retained paragraph signed reader reach')
        put(directory,struct.pack('>'+str(len(offsets))+'H',*offsets))
        reports.append({'paragraph_family':row['name'],'records':len(records),'directory':hex(directory)})
    output=[]
    for at,blob in sorted(writes.items()):
        value=bytearray(blob)
        for start,size in recipe['erase_spans']:
            require(size>0,'Authored text erase extent')
            lo=max(at,start);hi=min(at+len(value),start+size)
            if lo<hi:value[lo-at:hi-at]=b'\xff'*(hi-lo)
        output.append((at,bytes(value)))
    return output,reports
