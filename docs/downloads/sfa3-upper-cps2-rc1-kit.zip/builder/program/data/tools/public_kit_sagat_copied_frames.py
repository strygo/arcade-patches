"""Complete retained Sagat primary frames with original collision-row remapping."""
import hashlib
import struct
from public_kit_graphics import require
from public_kit_copied_directories import domain,u32
from public_kit_dhalsim_tables import Owner,direct_projection,repoint_existing


def construct(inputs,recipe):
    for name,pin in recipe['inputs'].items():
        value=inputs[name];require(len(value)==pin['bytes']and hashlib.sha256(value).hexdigest()==pin['sha256'],'Original Sagat frame '+name+' identity')
    arcade=inputs['arcade'];comp2=inputs['comp2'];region=recipe['region'];owner=11
    base=0x60ad00 if region=='us'else 0x60b080;delta=0 if region=='us'else 0x5700
    slong=lambda at:struct.unpack_from('<I',comp2,at-base)[0]
    sbank=slong(0x749838+delta+owner*4);sv=slong(0x749338+delta+owner*4)
    source=Owner(comp2,base,sbank,slong(0x7493d8+delta+owner*4),slong(0x749478+delta+owner*4),[slong(sv+i*4)for i in range(3)],'<')
    bank=u32(arcade,0xde6a0+owner*4);indices=u32(arcade,0xde320+owner*4);events=u32(arcade,0xde3a0+owner*4);variants=u32(arcade,0xde2a0+owner*4)
    native=Owner(bytearray(arcade),0,bank,indices,events,[u32(arcade,variants+i*4)for i in range(3)],'>')
    direct=direct_projection(source,native);remapped=repoint_existing(source,native)
    _,targets,records=domain(arcade,11,0,68,{34:0xac0110})
    cursor=0xabee74;mapping={}
    for at,size in records.items():mapping[at]=cursor;cursor+=size
    require(cursor==0xac0110 and len(records)==231,'Complete retained primary allocation extent')
    writes=[]
    for at,size in records.items():
        value=bytearray(native.read(at,size))
        if value[1]&128:
            nxt=u32(value,20);require(nxt in mapping,'Retained primary successor closure');struct.pack_into('>I',value,20,mapping[nxt])
        elif not value[1]&64:require(mapping[at+20]==mapping[at]+20,'Retained primary fallthrough allocation')
        writes.append((mapping[at],bytes(value)))
    return writes,{'frames':len(writes),'bytes':sum(len(v)for _,v in writes),'source_direct_bytes':direct,'source_remapped_frames':remapped,'artwork':'separate qualification'}
