"""Portable complete original stage compact graphs, cels and root tables."""
import hashlib
import struct
from public_kit_actor import Data
from public_kit_frame_resources import cel
from public_kit_graphics import require

ALLOCATIONS={32:(0xa72000,0xa73f00),33:(0xbf4000,0xbf7f00),34:(0xc30000,0xc33f00),35:(0xdd0000,0xdd3f00)}

def graph(inputs,region,owner):
    require(region in ('us','jp') and owner in ALLOCATIONS,'Unknown compact owner/region')
    data=Data(inputs['comp2'],0x60ad00 if region=='us' else 0x60b080,inputs['coords'],0xb04000)
    pc=0x2edc2c+(0x70 if region=='jp' else 0)
    hi,lo=struct.unpack_from('<2I',inputs['comp1'],pc-0x1f0040)
    require(hi>>26==15 and lo>>26==9 and (hi>>16)&31==(lo>>21)&31==(lo>>16)&31,'Original compact root literal producer')
    immediate=lo&65535;immediate-=65536 if immediate&32768 else 0
    table=((hi&65535)*65536+immediate)&0xffffffff
    root=table+struct.unpack('<h',data.read(table+owner*2,2))[0]
    _,targets=data.root(root);frames={};cels={};todo=list(targets)
    while todo:
        at=todo.pop()
        if at in frames:continue
        require(at%4==0 and len(frames)<4096,'Original compact frame alignment/bound')
        raw=data.read(at,8);source_cel=data.u32(at+4)
        nxt=data.u32(at+8) if raw[1]&128 else None if raw[1]&64 else at+8
        frames[at]=(raw[:4],source_cel,nxt,12 if raw[1]&128 else 8)
        cels[source_cel]=data.cel(source_cel)
        if nxt is not None:todo.append(nxt)
    return data,targets,frames,cels

def layout(inputs,region,owner):
    data,targets,frames,cels=graph(inputs,region,owner)
    at,root=ALLOCATIONS[owner];placements={};mapping={}
    for source,(kind,blocks) in sorted(cels.items()):
        require(kind in (0,2) and blocks,'Unexpected blank compact stage cel')
        xy=at;at+=len(blocks)*4;placements[source]=(at,xy);at+=10+len(blocks)*4
    for source,(_,_,_,size) in sorted(frames.items()):mapping[source]=at;at+=size
    require(at<root,'Compact stage allocation exceeds root reservation')
    return data,targets,frames,cels,placements,mapping

def construct(inputs,recipe,native_pixels):
    for name,pin in recipe['inputs'].items():
        require(len(inputs[name])==pin['bytes'] and hashlib.sha256(inputs[name]).hexdigest()==pin['sha256'],'Original compact source identity: '+name)
    require(hashlib.sha256(native_pixels).hexdigest()==recipe['graphics_pixels_sha256'],'Reconstructed compact artwork identity')
    require([r['owner'] for r in recipe['stages']]==list(ALLOCATIONS),'Complete compact owner inventory')
    writes=[];reports=[];upper_pixels=native_pixels[32<<20:]
    for row in recipe['stages']:
        owner=row['owner'];data,targets,frames,cels,placements,mapping=layout(inputs,recipe['region'],owner)
        require(set(row['tiles'])=={str(s) for s in cels},'Complete compact cel inventory')
        for source,(destination,xy) in placements.items():
            coords,body=cel(data,source,xy,row['tiles'][str(source)],inputs['pixels'],inputs['mask'],upper_pixels,1)
            writes.extend(((xy,coords),(destination,body)))
        for source,(header,source_cel,nxt,size) in sorted(frames.items()):
            destination=mapping[source];blob=header+struct.pack('>I',placements[source_cel][0])
            if size==12:blob+=struct.pack('>I',mapping[nxt])
            elif nxt is not None:require(mapping[nxt]==destination+8,'Compact successor fallthrough differs')
            writes.append((destination,blob))
        root=ALLOCATIONS[owner][1];offsets=[mapping[p]-root for p in targets]
        require(all(-32768<=n<=32767 for n in offsets),'Compact root signed reach')
        writes.append((root,struct.pack('>'+str(len(offsets))+'h',*offsets)))
        reports.append({'owner':owner,'cels':len(cels),'frames':len(frames),'selectors':len(targets)})
    return writes,reports
