"""Pinned native rectangle packing; no embedded artwork."""
from collections import Counter, defaultdict
from public_kit_graphics import require
MIB = 1024*1024

def grid_code(base, dx, dy):
    """PS2 compressed renderer and unflipped CPS-2 blocks wrap horizontally."""
    return (base & ~15)+((base+dx) & 15)+dy*16


def native_grid_code(base, dx, dy, flags):
    # MAME's CPS-2 flip paths use addition; its unflipped path wraps the nibble.
    # Do not preserve a wrapped block using the wrong path's addressing rule.
    return base+dx+dy*16 if flags & 0x60 else grid_code(base, dx, dy)


class BlockPacker:
    def __init__(self, native_pixels):
        require(len(native_pixels) % 128 == 0, 'Native tile alignment')
        self.native = [native_pixels[i:i+128] for i in range(0, len(native_pixels), 128)]
        self.tiles = list(self.native)
        self.by_tile = defaultdict(list)
        for i, tile in enumerate(self.native):
            self.by_tile[tile].append(i)
        self.memo = {}
        self.reuse = Counter()
        self.allocated = set(range(len(self.native)))
        self.heights = [0]*16
        self.extension_base = (len(self.native)+15) & ~15

    def add(self, width, height, tiles, flags):
        require(len(tiles) == width*height and all(len(t) == 128 for t in tiles), 'Block geometry')
        key = width, height, tuple(tiles), bool(flags & 0x60)
        if key in self.memo:
            return self.memo[key]
        # Anchor on the rarest tile, avoiding exhaustive scans of transparent art.
        anchor = min(range(len(tiles)), key=lambda i: len(self.by_tile.get(tiles[i], ())))
        ax, ay = anchor % width, anchor // width
        for code in self.by_tile.get(tiles[anchor], ()):
            if flags & 0x60:
                base = code-ax-ay*16
            else:
                row = code-ay*16
                base = (row & ~15) | ((row-ax) & 15)
            if base < 0:
                continue
            codes = [native_grid_code(base, x, y, flags) for y in range(height) for x in range(width)]
            # Original descriptor bank selects 64K tiles. Never rely on a carry
            # into another bank during a block expansion.
            if all(c in self.allocated and c >> 16 == base >> 16 and
                   self.tiles[c] == tile for c, tile in zip(codes, tiles)):
                self.memo[key] = base
                self.reuse['native_blocks' if base < len(self.native) else 'shared_appended_blocks'] += 1
                return base
        # A 16-column skyline lets independent rectangles share rows without
        # changing CPS block geometry. Never overwrite holes used by a mapping.
        candidates = []
        for x in range(17-width):
            y = max(self.heights[x:x+width])
            # The one-high-bit scroll proposal duplicates the native 8..16
            # MiB window at 40..48 MiB. Objects must leave that window free.
            absolute = self.extension_base+y*16
            if absolute < 48*MIB//128 and absolute+height*16 > 40*MIB//128:
                y = (48*MIB//128-self.extension_base)//16
            if ((self.extension_base+y*16) & 65535)+height*16 > 65536:
                y += 4096-((self.extension_base//16+y) % 4096)
            candidates.append((y, x))
        top, left = min(candidates)
        base = self.extension_base+top*16+left
        end = self.extension_base+(top+height)*16
        if end > len(self.tiles):
            self.tiles.extend([bytes([255])*128]*(end-len(self.tiles)))
        for y in range(height):
            for x in range(width):
                code = base+y*16+x; tile = tiles[y*width+x]
                require(code not in self.allocated, 'Graphics rectangle overlap')
                self.tiles[code] = tile
                self.allocated.add(code)
                self.by_tile[tile].append(code)
        for x in range(left, left+width):
            self.heights[x] = top+height
        self.memo[key] = base
        self.memo[width, height, tuple(tiles), not bool(flags & 0x60)] = base
        self.reuse['appended_blocks'] += 1
        return base

    def check(self, base, width, height, expected, flags):
        require(all(self.tiles[native_grid_code(base, x, y, flags)] == expected[y*width+x]
                    for y in range(height) for x in range(width)), 'Emitted block pixel/geometry mismatch')

