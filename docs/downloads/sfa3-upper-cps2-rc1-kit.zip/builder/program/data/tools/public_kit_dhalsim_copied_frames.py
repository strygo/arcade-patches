"""Retained Dhalsim AV frames through original Upper collision projection.

The complete action56 graph has a separate Naomi amendment and is excluded.
"""
import hashlib
import struct
from public_kit_graphics import require
from public_kit_copied_directories import domain,u32
from public_kit_dhalsim_tables import original_model,direct_projection,repoint_existing,relocate_missing


def construct(inputs,recipe):
    for name,pin in recipe['inputs'].items():
        value=inputs[name];require(len(value)==pin['bytes']and hashlib.sha256(value).hexdigest()==pin['sha256'],'Original Dhalsim frame '+name+' identity')
    source,native=original_model(inputs['arcade'],inputs['comp2'],recipe['region'])
    direct_projection(source,native);repoint_existing(source,native);relocate_missing(source,native)
    replacements={9:0xabd9d4,10:0xabda3c,11:0xabdab8,48:0xabdb34,49:0xabdbb0,50:0xabdc2c,51:0xabdca8}
    _,targets,records=domain(inputs['arcade'],15,3,58,replacements)
    cursor=0xabb5fc;mapping={}
    for at,size in records.items():mapping[at]=cursor;cursor+=size
    require(cursor==0xabd9d4 and len(records)==453,'Complete retained AV allocation extent')
    excluded=set(native.families[3][56][0]);writes=[]
    require(excluded and excluded<=set(records),'Whole Naomi-amended action belongs to retained allocation')
    for at,size in records.items():
        if at in excluded:continue
        value=bytearray(native.read(at,size))
        if value[1]&128:
            nxt=u32(value,20);require(nxt in mapping,'Retained AV successor closure');struct.pack_into('>I',value,20,mapping[nxt])
        elif not value[1]&64:require(mapping[at+20]==mapping[at]+20,'Retained AV fallthrough allocation')
        writes.append((mapping[at],bytes(value)))
    return writes,{'frames':len(writes),'excluded_whole_actions':[56],'excluded_whole_graph_frames':len(excluded),'bytes':sum(len(v)for _,v in writes),'artwork':'separate qualification'}
