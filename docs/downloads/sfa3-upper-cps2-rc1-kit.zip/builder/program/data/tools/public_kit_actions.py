"""Original Guile landing and projectile resources in the established native layout."""
import hashlib
import struct

from public_kit_actor import Data
from public_kit_blocks import BlockPacker, grid_code
from public_kit_graphics import require


def relative(targets, base):
    values = [target-base for target in targets]
    require(all(-32768 <= value < 32768 for value in values), 'Action root exceeds signed reach')
    return struct.pack('>'+str(len(values))+'h', *values)


def pack(data, addresses, pixels, valid, packer):
    converted = {}
    for address in sorted(addresses):
        kind, records = data.cel(address)
        blocks = []
        for x, y, word in records:
            tile, attr = word & 65535, word >> 16
            width, height = (attr >> 8 & 15)+1, (attr >> 12 & 15)+1
            codes = [grid_code(tile, dx, dy) for dy in range(height) for dx in range(width)]
            require(all(0 <= c < len(valid) and valid[c] and (c+1)*128 <= len(pixels) for c in codes),
                    'Missing original action artwork')
            tiles = [pixels[c*128:(c+1)*128] for c in codes]
            native = packer.add(width, height, tiles, attr)
            packer.check(native, width, height, tiles, attr)
            require(native < 65536 and attr & 31 <= 4, 'Action cel bank/palette extent')
            blocks.append((x, y, native, attr))
        require(blocks or kind == 18, 'Empty nonblank action cel')
        converted[address] = blocks
    return converted


def emit(data, frames, converted, base):
    payload, cel_map, frame_map = bytearray(), {}, {}
    for address, blocks in sorted(converted.items()):
        if not blocks:
            cel_map[address] = base+len(payload); payload.extend(struct.pack('>H', 18)); continue
        xy = base+len(payload)
        payload.extend(b''.join(struct.pack('>hh', x, y) for x, y, _, _ in blocks))
        cel_map[address] = base+len(payload)
        total = sum(((a >> 8 & 15)+1)*((a >> 12 & 15)+1) for _, _, _, a in blocks)
        payload.extend(struct.pack('>HHHI', 2, total, len(blocks)-1, xy))
        payload.extend(b''.join(struct.pack('>HH', t, a) for _, _, t, a in blocks))
    for address, row in sorted(frames.items()):
        frame_map[address] = base+len(payload); payload.extend(bytes(row['bytes']))
    for address, row in frames.items():
        at = frame_map[address]-base; raw = data.read(address, 20)
        payload[at:at+20] = raw[:4]+struct.pack('>I', cel_map[row['cel']])+raw[8:16]+\
                           struct.pack('>H', struct.unpack('<H', raw[16:18])[0])+raw[18:20]
        if row['bytes'] == 24:
            require(row['next'] in frame_map, 'Unknown action successor')
            struct.pack_into('>I', payload, at+20, frame_map[row['next']])
        elif row['next'] is not None:
            require(frame_map[row['next']] == frame_map[address]+20, 'Action fallthrough layout')
    return bytes(payload), cel_map, frame_map


def construct(comp2, coords, pixels, valid, actor_recipe, actor_blob, actor_report, recipe):
    data = Data(comp2, actor_recipe['base'], coords, 0xb04000)
    require(hashlib.sha256(actor_blob).hexdigest() == actor_recipe['batch34_sha256'],
            'Action construction needs the reproduced actor allocation')
    bindings = actor_report['frame_bindings']
    require(len(bindings) == actor_recipe['frames'], 'Action frame inventory')
    mappings = {row['source']: 0xa03000+row['offset'] for row in bindings}
    celmap = {}
    for row in bindings:
        cel = data.u32(row['source']+4)
        target = struct.unpack_from('>I', actor_blob, row['offset']+4)[0]
        require(cel not in celmap or celmap[cel] == target, 'Actor cel alias disagreement')
        celmap[cel] = target
    secondary = data.u32(actor_recipe['bank']+8)
    targets = data.root(secondary)[1]
    chain, address = [], targets[33]
    while address is not None and address not in chain:
        require(len(chain) < 2, 'Unbounded landing chain')
        chain.append(address); address = data.frame(address)[2]
    require(len(chain) == 2 and address is None and data.read(chain[-1]+1, 1) == b'\x40',
            'Landing terminal grammar differs')
    landing = bytearray()
    for address in chain:
        require(address not in mappings, 'Landing frame unexpectedly already admitted')
        mappings[address] = 0xa12800+len(landing)
        raw = data.read(address, 20)
        require(not raw[1] & 128 and data.u32(address+4) in celmap, 'Landing layout/art differs')
        landing.extend(raw[:4]+struct.pack('>I', celmap[data.u32(address+4)])+raw[8:16]+
                       struct.pack('>H', struct.unpack('<H', raw[16:18])[0])+raw[18:20])
    require(all(t in mappings for t in targets[:34]), 'Unknown secondary action target')
    secondary_blob = relative([mappings[t] for t in targets[:34]], 0xa12740)

    child = recipe['child']
    require(hashlib.sha256(data.read(child['root'], 18)).hexdigest() == child['root_sha256'],
            'Original projectile root identity')
    child_targets = data.root(child['root'])[1]
    require(child_targets == child['targets'], 'Projectile root target inventory')
    frames, cels = {}, set()
    for target in child_targets:
        address = target
        while address is not None and address not in frames:
            require(len(frames) < child['frames'], 'Unbounded projectile graph')
            raw = data.read(address, 20); _, _, nxt = data.frame(address)
            frames[address] = {'bytes': 24 if raw[1] & 128 else 20, 'next': nxt,
                               'cel': data.u32(address+4)}
            require(raw[8] < 2 and raw[9] < 13, 'Projectile selector outside original bank')
            cels.add(data.u32(address+4)); address = nxt
    require(len(frames) == child['frames'] and len(cels) == child['cels'], 'Projectile graph inventory')
    # Replay the already qualified body packing to supply the child's reuse dictionary.
    body = BlockPacker(b''); body.add(1, 1, [b'\xff'*128], 0)
    pack(data, celmap, pixels, valid, body)
    body_pixels = b''.join(body.tiles)
    require(len(body_pixels) <= 0x200000, 'Body artwork exceeds original reservation')
    child_packer = BlockPacker(body_pixels+b'\xff'*(0x200000-len(body_pixels)))
    converted = pack(data, cels, pixels, valid, child_packer)
    payload, child_cels, child_frames = emit(data, frames, converted, 0xa1c000)
    roots = relative([child_frames[t] for t in child_targets], 0xa1d000)
    source_bank = data.read(child['collision_bank'], 444)
    selectors = data.read(child['selectors'], 8)
    require(hashlib.sha256(source_bank).hexdigest() == child['collision_sha256'] and
            hashlib.sha256(selectors).hexdigest() == child['selectors_sha256'], 'Projectile collision identity')
    bank = struct.pack('>14h', *struct.unpack('<14h', source_bank[:28]))
    bank += b''.join(struct.pack('>4h', *struct.unpack('<4h', source_bank[n:n+8]))+source_bank[n+8:n+32]
                     for n in range(28, 444, 32))+selectors
    outputs = {'secondary_root': secondary_blob, 'landing_frames': bytes(landing),
               'projectile_data': bytes(payload), 'projectile_roots': roots, 'projectile_collision': bank}
    reaction = recipe['reaction']
    raw_root, targets = data.root(reaction['root'])
    require(hashlib.sha256(raw_root).hexdigest() == reaction['root_sha256'], 'Receiving root identity')
    require(targets[:48] == reaction['targets'], 'Receiving target inventory')
    receiving, receiving_cels = {}, set()
    for target in targets[:48]:
        address = target
        while address is not None and address not in receiving:
            require(len(receiving) < 145, 'Unbounded receiving graph')
            raw = data.read(address, 20); _, _, nxt = data.frame(address)
            receiving[address] = {'bytes': 24 if raw[1] & 128 else 20, 'next': nxt,
                                  'cel': data.u32(address+4)}
            receiving_cels.add(data.u32(address+4)); address = nxt
    require(len(receiving) == 145 and len(receiving_cels) == 75, 'Receiving graph extent')
    previous = b''.join(child_packer.tiles)
    require(len(previous) <= 0x400000, 'Projectile artwork reservation')
    reaction_packer = BlockPacker(previous+b'\xff'*(0x400000-len(previous)))
    converted = pack(data, receiving_cels, pixels, valid, reaction_packer)
    reaction_data, _, reaction_frames = emit(data, receiving, converted, 0xa22000)
    reaction_roots = relative([reaction_frames[t] for t in targets[:48]], 0xa25000)
    outputs.update(receiving_data=reaction_data, receiving_roots=reaction_roots)
    require(set(outputs) == set(recipe['outputs']), 'Action allocation inventory differs')
    for name, blob in outputs.items():
        require(len(blob) == recipe['outputs'][name]['bytes'] and
                hashlib.sha256(blob).hexdigest() == recipe['outputs'][name]['sha256'],
                'Final action allocation differs: '+name)
    return outputs, {'projectile_frames': len(frames), 'projectile_cels': len(cels),
                     'projectile_actions': len(child_targets), 'landing_frames': len(chain),
                     'receiving_frames': len(receiving), 'receiving_cels': len(receiving_cels),
                     'outputs': {n: {'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()}
                                 for n, b in outputs.items()}}
