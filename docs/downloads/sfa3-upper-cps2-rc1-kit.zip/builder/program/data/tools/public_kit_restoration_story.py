"""Approved authored P033 story/endings and original-font coordinate layout."""
import hashlib
from public_kit_graphics import require
from public_kit_english_text import encode


def construct(pixels,recipe):
    require(recipe['schema']==1 and hashlib.sha256(pixels).hexdigest()==recipe['font_pixels_sha256'],'Original restoration font changed')
    writes=[];seen=set()
    def place(address,blob):
        require(0xa00000<=address<=0xe00000-len(blob),'Restoration text allocation bounds')
        writes.append((address,blob))
    for row in recipe['records']:
        require(row['id'] not in seen and row['decision']=='revise','Duplicate or non-authored restoration record')
        seen.add(row['id']);rows=row['approved_rows']
        require(hashlib.sha256('\n'.join(rows).encode()).hexdigest()==row['wording_sha256'],'Restoration approval wording changed')
        require(1<=len(rows)<=2 and all(0<len(s)<=32 and all(32<=ord(c)<127 for c in s) for s in rows),'Restoration ASCII extent')
        if row['family'] in ('BIO','DLG'):
            blob,_=encode(rows,'DLG',8,pixels)
            require(row['coordinates'] is None,'Story unexpectedly owns stored coordinates')
        else:
            require(row['family']=='END','Unknown restoration text family')
            blob=bytearray()
            tiles={ch:[p for byte in pixels[(0x16c00+0x280+ord(ch))*128:(0x16c00+0x280+ord(ch)+1)*128]
                       for p in (byte&15,byte>>4)] for ch in set(''.join(rows))}
            require(all(len(v)==256 for v in tiles.values()),'Original ending font missing')
            for n,text in enumerate(rows):
                cursor=(240-7*len(text))//2-57+row['row_shifts'].get(str(n),0)
                require(-128<=cursor<=127,'Ending cursor exceeds signed byte')
                points=[cursor+57+8+k*8+i%16 for k,ch in enumerate(text) for i,p in enumerate(tiles[ch]) if p!=15]
                require(points and 0<=min(points)<=max(points)<272,'Ending text ink exceeds native column')
                blob.extend(bytes([cursor&255])+text.encode('ascii')+b'\0')
            if len(rows)==1:blob.append(0x70)
            blob=bytes(blob)
            if row['coordinates'] is not None:
                layout=row['render_rows']
                require(2<=len(layout)<=3 and ' '.join(rows)==' '.join(layout),'Ending layout changes approved wording')
                require(' ' not in tiles or all(p==15 for p in tiles[' ']),'SPACE glyph must be transparent')
                target=[]
                for n,text in enumerate(layout):
                    points=[8+k*8+i%16 for k,ch in enumerate(text) for i,p in enumerate(tiles[ch]) if p!=15]
                    require(points,'Empty ending display row');lo=min(points);hi=max(points)+1
                    require(hi-lo<=224,'Credit-safe row exceeds native width')
                    cursor=(224-(hi-lo))//2-57-lo
                    target.extend((ch,cursor+(k+1)*8,n*16) for k,ch in enumerate(text) if ch!=' ')
                chars=[c for text in rows for c in text]
                require([c for c in chars if c!=' ']==[c for c,x,y in target],'Ending layout changes visible glyph sequence')
                iterator=iter(target);points=[(0,0) if c==' ' else next(iterator)[1:] for c in chars]
                require(len(points)<=64 and all(-64<=x<=191 and 0<=y<=255 for x,y in points),'Packed ending coordinate bounds')
                coords=bytes(v for x,y in points for v in (x+64,y))
                require(hashlib.sha256(coords).hexdigest()==row['coordinate_sha256'],'Regenerated ending coordinate identity differs')
                place(row['coordinates'],coords)
        require(hashlib.sha256(blob).hexdigest()==row['record_sha256'],'Complete restoration text identity differs: '+row['id'])
        place(row['address'],blob)
    return writes


def self_test():
    pixels=bytearray(b'\xff'*((0x16c00+0x280+ord('A')+1)*128))
    pixels[(0x16c00+0x280+ord('A'))*128]=0xf1
    row={'id':'synthetic','decision':'revise','family':'END','approved_rows':['A A'],
         'wording_sha256':hashlib.sha256(b'A A').hexdigest(),'row_shifts':{},'render_rows':['A','A'],
         'address':0xd80000,'coordinates':0xd90000,
         'record_sha256':hashlib.sha256(b'\x34A A\0\x70').hexdigest(),
         'coordinate_sha256':hashlib.sha256(bytes([118,0,64,0,118,16])).hexdigest()}
    recipe={'schema':1,'font_pixels_sha256':hashlib.sha256(pixels).hexdigest(),'records':[row]}
    result=construct(pixels,recipe)
    require(result==[(0xd90000,bytes([118,0,64,0,118,16])),(0xd80000,b'\x34A A\0\x70')],
            'Ending actor compensation, ink centering, transparent spaces or packed coordinates differ')
    row['render_rows']=['A','AA']
    try:construct(pixels,recipe)
    except ValueError:pass
    else:raise ValueError('Synthetic custom layout accepted changed wording')
    print('Restoration story encoding self-test: PASS')


def main():
    import argparse,json
    from pathlib import Path
    parser=argparse.ArgumentParser(description=__doc__)
    for n in ('pixels','recipe','outdir'):parser.add_argument('--'+n,type=Path)
    parser.add_argument('--self-test',action='store_true');args=parser.parse_args()
    if args.self_test:self_test();return
    require(args.pixels and args.recipe and args.outdir,'Original font, recipe and output required')
    recipe=json.loads(args.recipe.read_text())
    data=bytearray(0x400000);mask=bytearray(len(data))
    for address,blob in construct(args.pixels.read_bytes(),recipe):
        at=address-0xa00000
        require(all(not mask[at+n] or data[at+n]==v for n,v in enumerate(blob)),'Conflicting authored text allocation')
        data[at:at+len(blob)]=blob;mask[at:at+len(blob)]=b'\1'*len(blob)
    args.outdir.mkdir(exist_ok=True)
    (args.outdir/'us.bin').write_bytes(data);(args.outdir/'us.mask').write_bytes(mask)


if __name__=='__main__':main()
