"""Complete original Fei loop variants, parameters and retained callback tables."""
import hashlib
import struct
from public_kit_graphics import require


def construct(inputs,recipe):
    from cps2_crypt import decrypt_rom
    digest=lambda b:hashlib.sha256(b).hexdigest()
    require(set(inputs)==set(recipe['inputs'])=={'arcade','comp1','comp2','key'},'Complete loop input domain')
    for name,blob in inputs.items():
        pin=recipe['inputs'][name];require(len(blob)==pin['bytes'] and digest(blob)==pin['sha256'],'Whole original source '+name)
    require(recipe['source_region']=='jp','Original batch34 construction source region')
    raw=inputs['arcade'];ops=decrypt_rom(raw[:0x100000],inputs['key'])[0];writes=[]
    require(len(recipe['variant_banks'])==3,'Three complete ISM banks')
    variants=struct.pack('>3I',*recipe['variant_banks']);change=recipe['variant_edit']
    require(change['address']=='0xb714d0' and variants.hex()==change['before'] and len(bytes.fromhex(change['after']))==12,'Original full three-bank correction preimage')
    writes.append((0xb714d0,bytes.fromhex(change['after'])))
    require([r['role']for r in recipe['parameters']]==['guard_parameter','knockdown_parameter'],'Complete scalar parameter pair')
    for row in recipe['parameters']:
        native=row['native'];source=row['source_offset'];loader=row['loader_offset']
        require(0<=source<=len(inputs['comp2'])-34 and 0<=loader<=len(inputs['comp1'])-row['loader_bytes'],'Original parameter source bounds')
        require(digest(inputs['comp1'][loader:loader+row['loader_bytes']])==row['loader_sha256'],'Original parameter loader identity')
        table=inputs['comp2'][source:source+34];prefix=raw[native:native+32]
        require(digest(prefix)==row['native_sha256'] and table[:23]==prefix[:23] and table[32]==row['guile_value'],'Original source parameter positive controls')
        blob=prefix+table[32:34]
        require(digest(blob)==row['sha256'],'Whole scalar parameter array')
        writes.append((row['address'],blob))
    require([r['role']for r in recipe['callbacks']]==['command','throw'],'Complete retained callback pair')
    for row in recipe['callbacks']:
        operand=row['operand'];require(ops[operand-2:operand]==bytes.fromhex('207c'),'Original native callback reader')
        root=struct.unpack_from('>I',ops,operand)[0];blob=bytearray(raw[root:root+128])
        require(digest(blob)==row['native_sha256'],'Whole native callback prefix')
        blob.extend(struct.pack('>2I',*row['original_added']))
        for change in row['changes']:
            at=change['owner']*4;after=struct.pack('>I',change['value'])
            require(blob[at:at+4].hex()==change['before'] and digest(after)==change['sha256'],'Original whole callback field update')
            blob[at:at+4]=after
        require(digest(blob)==row['dee_prefix_sha256'],'Original complete34 copied prefix')
        if row['role']=='command':
            change=row['guile_relocation'];at=128
            require(int.from_bytes(blob[at:at+4],'big')==change['before'],'Original Guile complete callback preimage')
            blob[at:at+4]=struct.pack('>I',change['after'])
        writes.append((row['address'],bytes(blob)))
    require(sum(len(blob)for _,blob in writes)==352,'Complete loop metadata extent')
    return writes,{'bytes':352,'arrays':len(writes),'access_view':'expanded-data','sha256':[digest(blob)for _,blob in writes]}
