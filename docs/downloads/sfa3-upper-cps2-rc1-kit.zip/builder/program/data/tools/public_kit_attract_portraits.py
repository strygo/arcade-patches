"""Complete original attract portrait maps and their native extension directory."""
import hashlib
import struct
from public_kit_graphics import require

OWNERS=(21,23,30,31,32,33,34,35)
START=0xac8662


def construct(inputs,recipe,pixels):
    region=recipe['region'];require(region in ('jp','us'),'Attract portrait source region')
    for name,pin in recipe['inputs'].items():
        blob=inputs[name];require(len(blob)==pin['bytes'] and hashlib.sha256(blob).hexdigest()==pin['sha256'],'Original portrait source identity: '+name)
    require(hashlib.sha256(pixels).hexdigest()==recipe['pixels_sha256'],'Qualified portrait graphics identity')
    base=0x60b080 if region=='jp' else 0x60ad00;shift=0 if region=='jp' else -0x56f0
    comp2=inputs['comp2'];font=inputs['font']
    def read(at,size):
        offset=at-base;require(0<=offset<=len(comp2)-size,'Original attract portrait resource bounds')
        return comp2[offset:offset+size]
    tables=(0x98b19c+shift,0x98b2c4+shift)
    require(tables[1]-tables[0]==37*8,'Original portrait owner bank extent')
    banks=[]
    for table in tables:
        bank=[]
        for owner in range(37):
            clock,flags,pointer=struct.unpack('<HHI',read(table+owner*8,8))
            require(clock in (8,0x4008) and flags==0,'Unknown original portrait frame grammar')
            require(struct.unpack('<4H',read(pointer,8))==(18,14,7,0),'Original full portrait map dimensions')
            bank.append(pointer)
        banks.append(bank)
    require([r['owner']for r in recipe['maps']]==list(OWNERS),'Complete attract portrait owner inventory')
    writes=[];reports=[]
    for ordinal,row in enumerate(recipe['maps']):
        owner=row['owner'];source=banks[0][owner];require(source==banks[1][owner],'Attract mode portrait resources differ')
        original=list(struct.iter_unpack('<HH',read(source+8,120*4)))
        allocations={code:(native,bank)for code,native,bank in row['tiles']}
        require(len(allocations)==len(row['tiles']) and set(allocations)=={code for _,code in original},'Complete source portrait tile domain')
        out=bytearray(struct.pack('>3H',18,14,7))
        for attr,code in original:
            require(attr&~127==0,'Unknown original portrait cell attributes')
            native,bank=allocations[code];require(0<=native<65536 and bank in (0,512),'Native portrait tile allocation')
            tile=font[(code+0x1c00)*128:(code+0x1c01)*128]
            # The attract font consumer keeps its 0x6c00 tile-code bias in both banks.
            at=((0x56c00 if bank else 0x16c00)+native)*128
            require(len(tile)==128 and pixels[at:at+128]==tile,'Complete original portrait tile pixels differ '+str((owner,hex(code),hex(native),bank,hex(at))))
            out.extend(struct.pack('>2H',native,attr|bank))
        writes.append((START+ordinal*486,bytes(out)))
        reports.append({'owner':owner,'source':hex(source),'cells':120,'distinct_tiles':len(allocations),'bytes':len(out)})
    writes.append((0xac9592,struct.pack('>6I',*(START+OWNERS.index(owner)*486 for owner in range(30,36)))))
    return writes,reports
