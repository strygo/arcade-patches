"""Complete forty-owner, six-choice ranking eye palette pointer directory.

Native owner and ranking-group offsets come from the original consumer tables.
Imported strip slots follow the regional original forty-owner eye selector map.
Reviewed palette arenas carry three color choices per original strip; the six
ranking choices select the same X/A/V triplet twice.
"""
import hashlib
import struct
from public_kit_graphics import require


def construct(inputs, recipe):
    require(set(inputs) == set(recipe['inputs']) == {'arcade', 'comp2', 'key'}, 'Ranking palette source inventory')
    for name, blob in inputs.items():
        pin = recipe['inputs'][name]
        require(len(blob) == pin['bytes'] and hashlib.sha256(blob).hexdigest() == pin['sha256'], 'Ranking palette source identity '+name)
    region = recipe['region']
    require(region in ('us', 'jp'), 'Ranking palette region')
    native = inputs['arcade']
    from cps2_crypt import decrypt_rom
    opcodes = decrypt_rom(native[:0x100000], inputs['key'])[0]
    require(opcodes[0x94812:0x94834] == bytes.fromhex('7000206da3b81028000fd000207c0035bb94d0fb003c102e00314880d040d0fb003c'), 'Original complete ranking palette address consumer')
    groups = struct.unpack_from('>6h', opcodes, 0x94862)
    offsets = struct.unpack_from('>32h', opcodes, 0x9486e)
    require(groups[:3] == groups[3:], 'Original six ranking palette choices')
    base = 0x60ad00 if region == 'us' else 0x60b080
    at = (0x617770 if region == 'us' else 0x618860) - base
    owners = inputs['comp2'][at:at+40]
    require(len(owners) == 40 and set(owners) == set(range(0x20, 0x41)), 'Original forty-owner eye strip map')
    require(recipe['palette_bases'] == {'imported': 0xaa7a10, 'naomi_overrides': 0xaa7d10}, 'Reviewed complete palette arena bindings')
    values = []
    for owner, selector in enumerate(owners):
        if selector >= 0x39:
            root = recipe['palette_bases']['imported'] + (selector - 0x39) * 96
            row = [root + (index % 3) * 32 for index in range(6)]
        elif owner in (4, 18, 6, 20):
            root = recipe['palette_bases']['naomi_overrides'] + (96 if owner in (6, 20) else 0)
            row = [root + (index % 3) * 32 for index in range(6)]
        else:
            original_owner = {36: 2, 38: 0}.get(owner, owner)
            require(original_owner < 32, 'Unbound original ranking palette owner')
            row = [0x35bb94 + group + offsets[original_owner] for group in groups]
            require(all(0x350000 <= p <= len(native)-32 for p in row), 'Complete original palette pointer bounds')
        values.extend(row)
    require(len(values) == 240, 'Complete forty by six palette directory')
    return [(0xaa9288, struct.pack('>240I', *values))], {'bytes': 960, 'owners': 40, 'ranking_choices': 6}
