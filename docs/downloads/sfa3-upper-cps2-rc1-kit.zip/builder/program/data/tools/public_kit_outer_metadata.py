"""Complete retained route, stage palette and camera binding arrays."""
import hashlib
import struct
from public_kit_graphics import require


def construct(inputs,recipe):
    from cps2_crypt import decrypt_rom
    digest=lambda b:hashlib.sha256(b).hexdigest()
    require(set(inputs)==set(recipe['inputs'])=={'arcade','comp2','key'} and recipe['source_region']=='jp','Original inherited outer source inventory')
    for name,blob in inputs.items():
        pin=recipe['inputs'][name];require(len(blob)==pin['bytes'] and digest(blob)==pin['sha256'],'Whole outer original source '+name)
    raw=inputs['arcade'];source=inputs['comp2'];ops=decrypt_rom(raw[:0x100000],inputs['key'])[0]
    table=0x37338c;offsets=struct.unpack_from('<40H',source,table);routes={n:source[table+offsets[n]:table+offsets[n]+160]for n in (32,33)}
    def view(owner,policy):
        rows=routes[owner];require(len(rows)==160 and max(rows)<40 and digest(rows)==policy['source_sha256'],'Original complete route source')
        choices=[rows[n:n+10]for n in range(0,160,10)];held=set(policy['held']);eligible=[n for n,r in enumerate(choices)if not set(r)&held]
        require(eligible,'No eligible original whole route')
        mapping=[next((n+k)%16 for k in range(16)if (n+k)%16 in eligible)for n in range(16)]
        out=b''.join(choices[n]for n in mapping)
        require(digest(out)==policy['view_sha256'] and mapping==policy['mapping'],'Original historical route policy projection')
        return out
    require(recipe['routes']['32']['held']==[23,33,34,35] and recipe['routes']['33']['held']==[23,33,34,35,36,37],'Original historical held-owner policies')
    paired=struct.pack('>2H',68,228)+view(32,recipe['routes']['32'])+view(33,recipe['routes']['33'])
    writes=[(0xba1de0,routes[33]),(0xba1e80,paired)]
    require(len(recipe['palettes'])==4,'Complete four stage palette pairs')
    pointers=[]
    for index,row in enumerate(recipe['palettes']):
        require(row['guile']==0xa77000+(0,1024,2048,3072)[index] and row['fei']==0xba1fc4+(0,1024,2048,3072)[index],'Original stage palette allocation order')
        at=row['source']-0x60b080;blob=source[at:at+row['bytes']];native=bytearray(blob);native[::2]=blob[1::2];native[1::2]=blob[::2]
        require(len(blob)==row['bytes'] and digest(native)==row['sha256'],'Complete source palette allocation witness')
        pointers.extend((row['guile'],row['fei']))
    writes.append((0xba2c84,struct.pack('>8I',*pointers)))
    require(len(recipe['camera'])==3,'Complete three camera bindings');callbacks=[]
    for row in recipe['camera']:
        at=row['source_table']-0x60b080;original=source[at:at+160]
        require(len(original)==160 and digest(original)==row['source_sha256'],'Complete source camera owner directory')
        values=struct.unpack('<40I',original);aliases=[n for n in range(32)if values[n]==values[33]]
        require(aliases==row['aliases'] and aliases,'Original camera resident aliases')
        native=row['native_table'];require(0<=native<=len(ops)-64,'Native camera table bounds')
        require(digest(ops[native:native+64])==row['native_sha256'],'Complete native camera offset table')
        callback=native+struct.unpack_from('>h',ops,native+aliases[0]*2)[0]
        require(callback==row['callback'] and 0<=callback<len(ops),'Original camera export binding')
        callbacks.append(callback)
    writes.append((0xba2ca4,struct.pack('>3I',*callbacks)))
    require(sum(len(v)for _,v in writes)==528,'Complete outer metadata extent')
    return writes,{'bytes':528,'arrays':4,'sha256':[digest(v)for _,v in writes]}
