"""Close Shin's three complete Naomi-amended frames with original action graphs."""
import hashlib
import struct
import public_kit_shin_frames as original
import public_kit_naomi_actions as naomi
from public_kit_graphics import require

CONTEXTS=((0,47),(2,6))


def construct(inputs,shin_recipe,recipe,pixels):
    program=inputs['naomi'];pin=recipe['input']
    require(len(program)==pin['bytes'] and hashlib.sha256(program).hexdigest()==pin['sha256'],'Original Naomi program identity')
    data=original.Data(inputs['comp2'],shin_recipe['base'],inputs['coords'],0xb04000)
    bank=data.u32(shin_recipe['owner_table']+36*4);roots=struct.unpack('<12I',data.read(bank,48))
    frames,byte_frames=original.graph(data,shin_recipe['owner_table']);mapping={r[0]:r for r in shin_recipe['frames']}
    writes=[];contexts=[]
    for family,action in CONTEXTS:
        at=data.root(roots[family])[1][action];chain=[]
        while at is not None and at not in chain:
            chain.append(at);at=frames[at][1]
        loop=None if at is None else chain.index(at)
        rows,naomi_loop=naomi.graph(program,36,family,action)
        require(len(chain)==len(rows) and loop==naomi_loop,'Complete PS2/Naomi amended action topology')
        changed=[]
        for source,row in zip(chain,rows):
            _,native,cel_pointer,native_next=mapping[source];size=frames[source][2]
            raw=data.read(source,20);scalar=row['scalar'];tail=scalar[8:10] if source in byte_frames else scalar[8:10][::-1]
            blob=row['prefix']+struct.pack('>I',cel_pointer)+scalar[:8]+tail+scalar[10:12]
            prior=raw[:4]+struct.pack('>I',cel_pointer)+raw[8:16]+(raw[16:18] if source in byte_frames else raw[16:18][::-1])+raw[18:20]
            if size==24:blob+=struct.pack('>I',native_next);prior+=struct.pack('>I',native_next)
            if native in original.NAOMI_FRONTIER:
                require(blob!=prior,'Declared Naomi amendment disappeared');writes.append((native,blob));changed.append(native)
            else:require(blob==prior,'Unknown source difference in complete amended Shin graph')
        contexts.append({'family':family,'action':action,'frames':len(rows),'loop':loop,'amended_complete_frames':changed})
    require({at for at,_ in writes}==original.NAOMI_FRONTIER,'Complete three-frame Naomi frontier closure')
    # Revalidate every pointed-to original/native canvas and the complete parent
    # frame allocation graph before extending its previously excluded resources.
    _,parent=original.construct(inputs,shin_recipe,pixels)
    return writes,{'complete_action_graphs':contexts,'verified_bytes':sum(len(v) for _,v in writes),
                   'parent_canvas_pixels_checked':parent['decoded_canvas_pixels_both_facings'],
                   'qualification':'Complete original Naomi action graphs, all scalar rows, preserved PS2 cel bindings and complete parent canvas proof'}
