"""Complete original CPU availability and predicate arrays with Evil redirect."""
import hashlib,struct
from public_kit_graphics import require

GUILE=(0x4d9f4,0x4da32,0x4d9f4,0x4d9f4,0x4d9f4,0x4d9ec,0x4da0e,0x4d9f8)

def construct(inputs,recipe):
    require(set(inputs)==set(recipe['inputs'])=={'arcade'},'Canonical original arcade input only')
    data=inputs['arcade'];pin=recipe['inputs']['arcade']
    require(len(data)==pin['bytes']==0x400000 and hashlib.sha256(data).hexdigest()==pin['sha256'],'Original complete arcade identity')
    prefix=data[0xe06a0:0xe0720]
    require(hashlib.sha256(prefix).hexdigest()==recipe['native_sha256'],'Complete original32-owner predicate prefix')
    entries=recipe['entries']
    require(set(entries)=={'guile','fei','nonzero_ism','nibble','evil'},'Complete predicate symbol binding inventory')
    require(all(type(v)is int and v%2==0 and 0xe0000<=v<0x100000 for v in entries.values()),'Compiled predicate callback allocation domain')
    require(struct.unpack_from('>I',prefix,23*4)[0]==0x34aae,'Original Evil availability preimage')
    blob=bytearray(prefix+struct.pack('>2I',entries['guile'],entries['fei'])+struct.pack('>8I',*GUILE))
    fei=(0x4d9f4,0x4da32,0x4d9f4,0x4d9f4,0x4d9f4,entries['nonzero_ism'],entries['nibble'],0x4da0e,0x4d9f8,0x34b28)
    blob.extend(struct.pack('>10I',*fei))
    struct.pack_into('>I',blob,23*4,entries['evil'])
    require(len(blob)==208,'Complete original consumer array extent')
    return [(0xbc0000,bytes(blob))],{'bytes':208,'native_owners':32,'added_owners':2,'guile_predicates':8,'fei_predicates':10,'reviewed_redirect_owner':23}
