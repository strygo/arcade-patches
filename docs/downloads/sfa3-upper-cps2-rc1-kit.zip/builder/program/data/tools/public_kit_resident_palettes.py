"""Complete original resident fighter palettes in existing native directories."""
import hashlib,struct
from public_kit_graphics import require

COMMON=tuple(range(18))+(21,22)+tuple(range(24,32))


def resources(comp2,native,region):
    require(region in ('us','jp') and len(native)==0x400000,'Resident palette source domain')
    base=0x60b080 if region=='jp' else 0x60ad00;delta=0x5380 if region=='jp' else 0
    def read(at,n):
        require(n>0 and 0<=at<=len(comp2)-n,'Original resident palette bounds')
        return comp2[at:at+n]
    def source16(at):return struct.unpack('<H',read(at,2))[0]
    def target16(at):return struct.unpack_from('>H',native,at)[0]
    writes=[];reports=[]
    def add(group,owner,source,target,size):
        require(size%32==0 and 0<=target<=len(native)-size,'Complete resident palette allocation')
        raw=read(source,size);blob=b''.join(raw[n:n+2][::-1] for n in range(0,len(raw),2))
        writes.append((target,blob));reports.append({'family':group,'owner':owner,'source':source,'native':target,'bytes':size})
    primary=0xec5b0+delta;effects=0xf5840+delta;special=0x117380+delta;head=0x11a4a0+delta;secondary=0x1210f0+delta
    for owner in COMMON:add('primary',owner,primary+source16(primary+owner*2),0x32c094+target16(0x32c094+owner*2),960)
    for owner in tuple(range(18))+(18,20,22)+tuple(range(24,30)):
        add('head',owner,head+source16(head+owner*2),0x34cdd4+target16(0x34cdd4+owner*2),768)
    for owner in COMMON:
        add('shared_effect',owner,effects+source16(effects+owner*2),0x3329d4+target16(0x3329d4+owner*2),1184 if owner==28 else 768)
    sp=struct.unpack('<40H',read(special,80));np=struct.unpack_from('>32H',native,0x34a7b4)
    for owner in COMMON:
        size=min([v-sp[owner] for v in set(sp) if v>sp[owner]]or[1952]);oldsize=min([v-np[owner] for v in set(np) if v>np[owner]]or[1952])
        if size==oldsize:add('character_effect',owner,special+sp[owner],0x34a7b4+np[owner],size)
    for owner in (*COMMON,18):
        if owner in (20,21,30,31):continue
        source=struct.unpack('<I',read(secondary+owner*4,4))[0]-base;target=struct.unpack_from('>I',native,0x351f14+owner*4)[0]
        add('secondary',owner,source,target,1536)
    return writes,reports


def construct(comp2,native,recipe):
    require(recipe['schema']==1 and hashlib.sha256(comp2).hexdigest()==recipe['source_sha256'] and hashlib.sha256(native).hexdigest()==recipe['native_sha256'],'Resident palette input identities')
    return resources(comp2,native,recipe['region'])


def main():
    import argparse,json
    from pathlib import Path
    p=argparse.ArgumentParser(description=__doc__)
    for n in ('comp2','native','recipe','outdir'):p.add_argument('--'+n,type=Path,required=True)
    a=p.parse_args();writes,_=construct(a.comp2.read_bytes(),a.native.read_bytes(),json.loads(a.recipe.read_text()));data=bytearray(0x400000);mask=bytearray(len(data))
    for at,blob in writes:
        require(all(not mask[at+i] or data[at+i]==v for i,v in enumerate(blob)),'Conflicting complete native palette aliases')
        data[at:at+len(blob)]=blob;mask[at:at+len(blob)]=b'\1'*len(blob)
    a.outdir.mkdir(exist_ok=True);(a.outdir/'result.bin').write_bytes(data);(a.outdir/'result.mask').write_bytes(mask)


if __name__=='__main__':main()
