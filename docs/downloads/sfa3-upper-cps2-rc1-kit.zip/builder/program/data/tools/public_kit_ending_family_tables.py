"""Complete historical ending family4 pointer tables from original resource graphs."""
import hashlib,struct
from public_kit_graphics import require
from public_kit_ending_colors import construct as colors
from public_kit_dee_ending_colors import construct as dee_colors
from public_kit_palettes import catalog


def construct(comp2,native,recipe):
    require(recipe['schema']==1 and hashlib.sha256(comp2).hexdigest()==recipe['source_sha256'] and hashlib.sha256(native).hexdigest()==recipe['native_sha256'],'Ending family source identities')
    require(set(recipe['roots'])=={'32','33','23','34','35','37'},'Complete ending family chain')
    require(struct.unpack_from('>I',native,0x26b74)[0]==0x26ba4,'Original native family4 root changed')
    require(recipe['roots']['32']==0xa90000,'Original Guile family allocation')
    original=catalog(comp2,recipe['region']);private=original['ending:32:private'][1]
    require(len(private)==1794 and 0xa90000<=recipe['guile_private']<0xa91000,'Guile complete private palette binding')
    cells=bytearray(native[0x26ba4:0x26bbc]);cells.extend(struct.pack('>3I',recipe['guile_private'],0x3fa140,0x3db000))
    writes=[(recipe['roots']['32'],bytes(cells))];reports={'32':{'cells':len(cells)//4,'added':3}}
    ordinary,_=colors(comp2,recipe['colors']);dee,_=dee_colors(comp2,recipe['dee_colors']);allocations={at:blob for at,blob in ordinary+dee}
    for owner in (33,23,34,35,37):
        source=recipe['dee_colors'] if owner==34 else recipe['colors'];arrays=source['families'][str(owner)]['arrays']
        addresses=[r[3] for r in arrays];require(addresses==sorted(set(addresses)),'Original private palette allocation order')
        require(all(len(allocations[r[3]])==r[4] for r in arrays),'Complete bound private palettes')
        cells.extend(struct.pack('>'+str(len(addresses))+'I',*addresses));root=recipe['roots'][str(owner)]
        require(0xa00000<=root<=0xe00000-len(cells),'Complete ending family allocation')
        writes.append((root,bytes(cells)));reports[str(owner)]={'cells':len(cells)//4,'added':len(addresses)}
    return writes,reports


def main():
    import argparse,json
    from pathlib import Path
    p=argparse.ArgumentParser(description=__doc__)
    for n in ('comp2','native','recipe','outdir'):p.add_argument('--'+n,type=Path,required=True)
    a=p.parse_args();writes,_=construct(a.comp2.read_bytes(),a.native.read_bytes(),json.loads(a.recipe.read_text()));data=bytearray(0x400000);mask=bytearray(len(data))
    for at,blob in writes:
        at-=0xa00000;require(not any(mask[at:at+len(blob)]),'Ending family table overlap');data[at:at+len(blob)]=blob;mask[at:at+len(blob)]=b'\1'*len(blob)
    a.outdir.mkdir(exist_ok=True);(a.outdir/'result.bin').write_bytes(data);(a.outdir/'result.mask').write_bytes(mask)


if __name__=='__main__':main()
