"""Original Fei basic-loop event and shadow arrays at their emitted boundaries."""
import hashlib
import struct
from public_kit_graphics import require


def construct(inputs,recipe):
    require(set(inputs)==set(recipe['inputs'])=={'comp2'},'Original Fei loop source inventory')
    raw=inputs['comp2'];pin=recipe['inputs']['comp2']
    require(len(raw)==pin['bytes'] and hashlib.sha256(raw).hexdigest()==pin['sha256'],'Original Fei loop source identity')
    region=recipe['region'];require(region in ('us','jp'),'Original Fei loop region')
    delta=0x5700 if region=='jp' else 0;base=0x60b080 if region=='jp' else 0x60ad00
    def read(at,n):
        require(base<=at<=base+len(raw)-n,'Original Fei loop read bounds');return raw[at-base:at-base+n]
    def u32(at):return struct.unpack('<I',read(at,4))[0]
    require(recipe['extents']=={'events':132,'shadows':56},'Original emitted array extents')
    events=read(u32(0x749478+delta+33*4),132)
    require(all(events[n]==0 and events[n+1] in (0,1)for n in range(0,132,4)),'Original Fei event clock grammar')
    shadows=read(u32(0x74c5d8+delta+33*4),56)
    require(all(0<=shape<=16 and -128<=offset<=128 for shape,offset in struct.iter_unpack('<2h',shadows)),'Original fourteen Fei shadow rows')
    require(recipe['source_arrays_sha256']=={'events':hashlib.sha256(events).hexdigest(),'shadows':hashlib.sha256(shadows).hexdigest()},'Complete original Fei loop arrays')
    return [(0xb70190,events),(0xb7170c,b''.join(shadows[n:n+2][::-1]for n in range(0,56,2)))],{'bytes':188,'event_rows':33,'shadow_rows':14,'next_allocations':{'events':0xb70214,'shadows':0xb71744},'later_full_graph_event_bytes_excluded':8}
