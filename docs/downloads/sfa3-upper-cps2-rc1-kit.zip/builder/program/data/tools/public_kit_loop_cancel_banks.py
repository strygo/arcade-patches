"""Complete original three-ISM cancel banks emitted by the basic-loop compiler."""
import hashlib
import struct
from public_kit_graphics import require
from public_kit_resource_delta import apply


def bases(inputs,recipe):
    require(set(inputs)==set(recipe['inputs'])=={'arcade','comp2'},'Original loop cancel inventory')
    for name,blob in inputs.items():
        pin=recipe['inputs'][name]
        require(len(blob)==pin['bytes']and hashlib.sha256(blob).hexdigest()==pin['sha256'],'Original loop cancel identity '+name)
    region=recipe['region'];require(region in ('us','jp'),'Loop cancel region')
    raw=inputs['arcade'];c2=inputs['comp2'];base=0x60b080 if region=='jp'else 0x60ad00
    table=0x74e3f8 if region=='jp'else 0x748cf8
    def read(at,n):
        require(base<=at<=base+len(c2)-n,'Original loop cancel bounds');return c2[at-base:at-base+n]
    def windows(owner,count):
        bank=struct.unpack('<I',read(table+owner*4,4))[0];offsets=struct.unpack('<3h',read(bank,6))
        require(all(o>=6 and o%2==0 for o in offsets),'Three original ISM cancel offsets')
        return [read(bank+o,count*2)for o in offsets]
    native=struct.unpack_from('>I',raw,0xddda0)[0];offsets=struct.unpack_from('>3h',raw,native)
    require(all(row==raw[native+at:native+at+68]for row,at in zip(windows(0,34),offsets)),'Whole native Ryu cancel control')
    fei=struct.pack('>3h',6,72,138)+b''.join(windows(33,33))
    guile=struct.pack('>3h',6,78,150)+b''.join(windows(32,36))
    require(len(fei)==204 and len(guile)==222,'Whole original loop cancel extents')
    require(recipe['source_windows_sha256']=={'fei':hashlib.sha256(fei[6:]).hexdigest(),'guile':hashlib.sha256(guile[6:]).hexdigest()},'Whole original loop windows')
    return [(0xb71744,fei),(0xb71810,guile)],{'bytes':426,'fei_rows_per_ism':33,'guile_rows_per_ism':36,'systems':3,'native_control_rows':102,'authored_headers_bytes':12}


def construct(inputs,recipe):
    writes,report=bases(inputs,recipe)
    require(set(recipe['deltas'])=={'fei','guile'},'Two reviewed complete loop cancel resources')
    corrected=[];counts={}
    for name,(at,blob)in zip(('fei','guile'),writes):
        patch=recipe['deltas'][name]
        require(patch['bytes']==len(blob),'Complete loop cancel delta extent')
        corrected.append((at,apply(blob,patch)));counts[name]=len(patch['changes'])
    report['reviewed_correction_bytes']=counts
    return corrected,report
