"""Retained resident glyph directory from each display's original font asset."""
import hashlib
import struct
from public_kit_graphics import require

# Original current-roster importer glyph domain, in its allocation order.
GLYPHS=(1952,1971,1973,1974,1996,1997,1999,2000,2001,2004,2006,2008,2009,2024,2025,2027)


MAPS=(('main',0x3f8000,76,GLYPHS),
      ('upper',0xa46c64,76,(0x7bb,0x7be,0x7c0,0x7d3,0x7da,0x7db,0x7e4)),
      ('upper',0xb7aa80,76,(0x7a2,0x7a5,0x7ce,0x7dc,0x7ea)),
      ('upper',0xbcb0f8,77,(0x7b4,0x7b7,0x7b9,0x7d5,0x7d7,0x7e6,0x7e7,0x7ec)))


def construct(font,recipe,pixels,space='main'):
    require(recipe['region'] in ('us','jp') and space in ('main','upper'),'Retained font region/address space')
    pin=recipe['font'];require(len(font)==pin['bytes'] and hashlib.sha256(font).hexdigest()==pin['sha256'],'Own regional original font identity')
    require(hashlib.sha256(pixels).hexdigest()==recipe['pixels_sha256'],'Qualified retained font graphics identity')
    require([r['address']for r in recipe['maps']]==[r[1]for r in MAPS],'Complete retained font directory inventory')
    writes=[];reports=[]
    for row,(kind,address,count,glyphs)in zip(recipe['maps'],MAPS):
        require(tuple(g for g,_ in row['allocations'])==glyphs,'Complete retained source glyph domain')
        if kind!=space:continue
        allocations=dict(row['allocations'])
        for glyph,physical in allocations.items():
            require(0x16c00<=physical<0x20000,'Retained glyph allocation bounds')
            original=font[(0x4780+glyph)*128:(0x4781+glyph)*128]
            require(len(original)==128 and pixels[physical*128:(physical+1)*128]==original,'Complete retained original glyph pixels differ')
        words=[allocations.get(g,0x19760+g)-0x16c00 for g in range(0x7a0,0x7a0+count)]
        writes.append((address,struct.pack('>'+str(count)+'H',*words)))
        reports.append({'address':hex(address),'entries':count,'private_glyphs':len(allocations),'pixels_checked':len(allocations)*256,'opposite_region_disc_required':False})
    return writes,reports
