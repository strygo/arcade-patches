"""Complete collision-bank clones with typed, reviewed source-row amendments."""
import hashlib
import struct
import public_kit_cohort_combat as combat
import public_kit_resource_delta as delta
from public_kit_actor import Data
from public_kit_graphics import require

FIELDS={'x':(0,'>h'),'y':(2,'>h'),'width':(4,'>h'),'height':(6,'>h'),
        'attack_byte8':(8,'B'),'attack_byte22':(22,'B')}
# Source row, original action family/action, and reviewed scalar pre/post values.
CLONES={
 'fei-loop':((94,2,62,(('attack_byte22',12,1),)),(95,2,62,(('attack_byte22',12,1),))),
 'dee':((27,3,20,(('x',-41,-49),('y',54,58),('width',20,28))),
        (34,3,27,(('y',101,97),('height',14,13))),
        (36,3,29,(('y',61,59),('attack_byte8',15,16))),
        (29,3,22,(('attack_byte8',11,10),)))}
TARGET_ACTIONS={'fei-loop':((2,62),(2,62)),'dee':((3,20),(3,21),(3,23),(3,28))}
FAMILIES={'fei-loop':(33,4794,100,0xab2170,4858),'dee':(34,5426,116,0xab509c,5554)}


def clone_bank(base,rows):
    """Append whole attack records; typed amendments cannot supply record payloads."""
    require(type(base)is bytes and len(base)>=10,'Complete collision bank')
    offsets=struct.unpack_from('>5h',base)
    require(offsets[0]==10 and all(a<z and (z-a)%8==0 for a,z in zip(offsets,offsets[1:])),
            'Collision lane header and whole-row grammar')
    require((len(base)-offsets[4])%32==0,'Complete attack record extent')
    count=(len(base)-offsets[4])//32;out=bytearray(base)
    for index,changes in rows:
        require(type(index)is int and 0<=index<count,'Source clone index outside original bank')
        row=bytearray(base[offsets[4]+index*32:offsets[4]+(index+1)*32]);seen=set()
        require(changes,'Reviewed clone requires declared amendments')
        for field,before,after in changes:
            require(field in FIELDS and field not in seen and before!=after,'Unique typed clone field')
            seen.add(field);at,fmt=FIELDS[field]
            require(struct.unpack_from(fmt,row,at)[0]==before,'Original typed field preimage differs')
            struct.pack_into(fmt,row,at,after)
        out.extend(row)
    return bytes(out)


def construct(inputs,recipe):
    require(recipe['schema']==1 and set(inputs)==set(recipe['inputs'])=={'comp2','coords'},'Complete collision clone source inventory')
    for name,blob in inputs.items():
        pin=recipe['inputs'][name]
        require(len(blob)==pin['bytes'] and hashlib.sha256(blob).hexdigest()==pin['sha256'],'Original collision source identity')
    require(set(recipe['families'])==set(FAMILIES),'Complete two-bank inventory')
    region=recipe['region'];arrays,graphs=combat.catalog(inputs['comp2'],region,inputs['coords'])
    data=Data(inputs['comp2'],0x60b080 if region=='jp'else 0x60ad00,inputs['coords'],0xb04000)
    shift=0x5700 if region=='jp'else 0;writes=[];reports={}
    for name,(owner,size,count,target,total)in FAMILIES.items():
        rule=recipe['families'][name]
        expected=[[i,f,a,[list(c)for c in changes]]for i,f,a,changes in CLONES[name]]
        require(rule['clones']==expected and rule['target_actions']==[list(v)for v in TARGET_ACTIONS[name]],'Reviewed complete clone/context inventory differs')
        source=arrays[f'collision:{owner}:0'][1][:size]
        require(len(source)==size and struct.unpack_from('>h',source,8)[0]+count*32==size,'Original full bank attack extent')
        base=delta.apply(source,rule['predecessor_delta'])
        roots=struct.unpack('<12I',data.read(data.u32(0x749838+shift+owner*4),48));witnesses=[]
        for index,family,action,changes in CLONES[name]:
            for style in range(3):
                _,actions=data.root(roots[style*4+family]);require(action<len(actions),'Original clone action extent')
                at=actions[action];seen=set();used=set()
                while at is not None and at not in seen:
                    seen.add(at);used.add(data.read(at,20)[9]);_,_,at=data.frame(at)
                    require(len(seen)<8192,'Bounded source clone action graph')
                require(index in used,f'Clone source context differs: {name} style{style} family{family} action{action} expects row{index}, actual rows{sorted(used)}')
                witnesses.append({'style':style,'family':family,'action':action,'source_index':index,'frames':len(seen)})
        blob=clone_bank(base,[(i,changes)for i,_,_,changes in CLONES[name]])
        require(len(blob)==total,'Whole cloned bank extent')
        writes.append((target,blob));reports[name]={'bytes':total,'base_bytes':size,'original_rows':count,
          'appended_rows':len(CLONES[name]),'original_contexts':witnesses,'reviewed_target_actions':rule['target_actions'],'sha256':hashlib.sha256(blob).hexdigest(),
          'source_version':'Original complete PS2 bank, accepted fixes7 predecessor corrections, then reviewed clone amendments.'}
    return writes,{'bytes':sum(len(b)for _,b in writes),'banks':reports,'source_graphs':graphs}
