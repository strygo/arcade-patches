"""Source model for Dhalsim's retained selector/collision relocation pipeline.

Development converter; no resources are admitted until whole-table equality
and the independent source mutation checks pass.
"""
import struct
from public_kit_graphics import require
from public_kit_copied_frames import root,graph
from public_kit_dhalsim_directory import domain,START,ROOT,u32


def swap(blob):return bytes(v for pair in zip(blob[1::2],blob[::2])for v in pair)


class Owner:
    def __init__(self,blob,base,bank,indices,events,variants,endian):
        self.blob=blob;self.base=base;self.endian=endian
        self.indices=indices;self.events=events;self.variants=variants
        self.families=[[(graph(blob,at,base,endian))for at in root(blob,self.long(bank+i*4),base,endian)]for i in range(12)]
    def read(self,at,size):
        offset=at-self.base;require(0<=offset<=len(self.blob)-size,'Complete owner source resource bounds')
        return bytes(self.blob[offset:offset+size])
    def long(self,at):return struct.unpack(self.endian+'I',self.read(at,4))[0]
    def values(self,at,style):
        value=self.read(at,20);bank=self.variants[style]
        offsets=struct.unpack(self.endian+'5h',self.read(bank,10))
        require(offsets[0]==10 and list(offsets)==sorted(offsets),'Complete owner collision lane directory')
        selector=self.read(self.indices+value[8]*4,4)
        addresses=[bank+offsets[lane]+index*8 for lane,index in enumerate(selector)]
        geometry=[self.read(address,8)for address in addresses]
        attack_at=bank+offsets[4]+value[9]*32;attack=self.read(attack_at,32)
        if self.endian=='<':geometry=[swap(v)for v in geometry];attack=swap(attack[:8])+attack[8:]
        return {'frame':value,'geometry':tuple(geometry),'attack':attack,'lane_at':addresses,'attack_at':attack_at,'event_at':self.events+value[10]*4}


def original_model(arcade,comp2,region):
    base=0x60ad00 if region=='us'else 0x60b080;delta=0 if region=='us'else 0x5700
    slong=lambda at:struct.unpack_from('<I',comp2,at-base)[0]
    sbank=slong(0x749838+delta+15*4);sv=slong(0x749338+delta+15*4)
    source=Owner(comp2,base,sbank,slong(0x7493d8+delta+15*4),slong(0x749478+delta+15*4),[slong(sv+i*4)for i in range(3)],'<')
    bank=u32(arcade,0xde6a0+15*4);indices=u32(arcade,0xde320+15*4);events=u32(arcade,0xde3a0+15*4);variants=u32(arcade,0xde2a0+15*4)
    banks=[u32(arcade,variants+i*4)for i in range(3)]
    require(banks==[0x121cd8]*3,'Complete original Dhalsim collision ISM aliases')
    native=Owner(arcade,0,bank,indices,events,banks,'>')
    allframes={a for family in native.families for frames,_ in family for a in frames}
    require(max(arcade[a+8]for a in allframes)==88 and max(arcade[a+9]for a in allframes)==93,'Original Dhalsim selector/attack extent')
    # The retained X bank was copied after the complete native attack correction.
    # Bind every original alias, including the one different-topology X27 action.
    corrected=bytearray(arcade)
    for attack_at in (0x12253a,0x1225da):
        desired=set();aliases=0
        for slot,family in enumerate(native.families):
            style=slot//4
            for action,(addresses,loop)in enumerate(family):
                sf,sl=source.families[slot][action]
                for ordinal,at in enumerate(addresses):
                    current=native.values(at,style)
                    if current['attack_at']!=attack_at:continue
                    aliases+=1
                    if len(sf)==len(addresses)and sl==loop:
                        desired.add(source.values(sf[ordinal],style)['attack'])
                    else:
                        require(slot==7 and action==27 and attack_at==0x1225da,'Unknown original attack alias topology')
                        active=[source.values(a,style)['attack']for a in sf if any(source.values(a,style)['attack'][:8])]
                        require(active and len({v[8]for v in active})==1,'Original X27 uniform active damage class')
                        value=bytearray(current['attack']);value[8]=active[0][8];desired.add(bytes(value))
        require(aliases and len(desired)==1,'Complete original shared attack demands disagree')
        value=desired.pop();before=arcade[attack_at:attack_at+32]
        require([i for i in range(32)if value[i]!=before[i]]==[8],'Original shared attack correction field extent')
        corrected[attack_at:attack_at+32]=value
    bus=corrected+bytearray(b'\xff'*(0xa84000-len(arcade)))
    _,targets,records,_=domain(arcade);mapping={};cursor=START
    for at,value in records.items():mapping[at]=cursor;cursor+=len(value)
    require(cursor==ROOT,'Original retained X-normal frame allocation')
    for at,value in records.items():
        value=bytearray(value)
        if value[1]&128:struct.pack_into('>I',value,20,mapping[u32(value,20)])
        bus[mapping[at]:mapping[at]+len(value)]=value
    frames,loop=source.families[7][27];require(len(frames)==6 and loop is None,'Original PS2 X27 complete graph')
    offsets=struct.unpack_from('>5h',arcade,banks[0]);lanes=[[arcade[banks[0]+offsets[i]+j:banks[0]+offsets[i]+j+8]for j in range(0,offsets[i+1]-offsets[i],8)]for i in range(4)]
    selectors=[arcade[indices+i*4:indices+i*4+4]for i in range(89)];projection={1:1}
    rows=[source.values(at,1)for at in frames]
    require([r['frame'][8]for r in rows]==[93,93,94,94,93,1] and [r['frame'][9]for r in rows]==[0,0,96,0,0,0],'Original X27 complete scalar/selector bindings')
    for index in (93,94):
        row=next(r for r in rows if r['frame'][8]==index);selected=[]
        for lane,value in zip(lanes,row['geometry']):
            if value not in lane:lane.append(value)
            selected.append(lane.index(value))
        projection[index]=len(selectors);selectors.append(bytes(selected))
    selector_data=b''.join(selectors);bus[0xa82700:0xa82700+len(selector_data)]=selector_data
    new_offsets=[10]
    for lane in lanes:new_offsets.append(new_offsets[-1]+8*len(lane))
    attacks=corrected[banks[0]+offsets[4]:banks[0]+offsets[4]+94*32]
    collision=struct.pack('>5h',*new_offsets)+b''.join(b''.join(lane)for lane in lanes)+attacks+rows[2]['attack']
    bus[0xa8286c:0xa8286c+len(collision)]=collision
    for i,row in enumerate(rows):
        value=bytearray(swap(row['frame']));value[:4]=row['frame'][:4];value[8:16]=row['frame'][8:16];value[18:20]=row['frame'][18:20]
        value[8]=projection[row['frame'][8]];value[9]=94 if row['frame'][9]==96 else 0
        bus[0xa80000+i*20:0xa80014+i*20]=value
    native.blob=bus;native.indices=0xa82700;native.variants=[banks[0],0xa8286c,banks[0]]
    native.families[7]=[([0xa80000+i*20 for i in range(6)],None)if action==27 else ([mapping[a]for a in addresses],loop)for action,(addresses,loop)in enumerate(native.families[7])]
    return source,native


def study(source,native):
    users={};unmatched=set();want={}
    for style in range(3):
        for family in range(4):
            slot=style*4+family;original=source.families[slot]
            for action,(frames,loop)in enumerate(native.families[slot]):
                matched=action<len(original)and len(original[action][0])==len(frames)and original[action][1]==loop
                for ordinal,at in enumerate(frames):
                    user=(style,family,action,ordinal);users.setdefault(at,set()).add(user)
                    if not matched:unmatched.add(at);continue
                    sv=source.values(original[action][0][ordinal],style);nv=native.values(at,style)
                    desired=(sv['frame'][0],sv['attack'],sv['geometry']);current=(nv['frame'][0],nv['attack'],nv['geometry'])
                    want[user]=(at,desired,current)
    return users,unmatched,want


def direct_projection(source,native):
    users,unmatched,want=study(source,native);demand={};taint=set()
    for user,(at,w,_)in want.items():
        cv=native.values(at,user[0]);demand.setdefault(at,set()).add(w[0])
        for start,value in ((cv['attack_at'],w[1]),*zip(cv['lane_at'],w[2])):
            for offset,byte in enumerate(value):demand.setdefault(start+offset,set()).add(byte)
    for style in range(3):
        for family in range(4):
            for frames,_ in native.families[style*4+family]:
                for at in frames:
                    if at not in unmatched:continue
                    cv=native.values(at,style)
                    for start,size in ((at,20),(cv['attack_at'],32),(cv['event_at'],4),*((a,8)for a in cv['lane_at'])):taint.update(range(start,start+size))
    changes=0
    for at,values in demand.items():
        if at not in taint and len(values)==1:
            value=next(iter(values));changes+=int(native.blob[at]!=value);native.blob[at]=value
    return changes


def eligible(at,contexts,users,unmatched,want):
    desired={want[u][1]for u in contexts}
    if len(desired)!=1 or at in unmatched:return None
    value=next(iter(desired))
    if any(want.get(user,(None,None))[1]!=value for user in users[at]-set(contexts)):return None
    return value


def deficiencies(source,native):
    users,unmatched,want=study(source,native);by_frame={}
    for user,(at,desired,current)in want.items():
        if desired!=current:by_frame.setdefault(at,[]).append(user)
    return users,unmatched,want,by_frame


def repoint_existing(source,native):
    users,unmatched,want,by_frame=deficiencies(source,native);used_attacks={};used_selectors=set()
    for slot,family in enumerate(native.families):
        bank=native.variants[slot//4]
        for frames,_ in family:
            for at in frames:
                used_attacks.setdefault(bank,set()).add(native.blob[at+9]);used_selectors.add(native.blob[at+8])
    changed=0
    for at,contexts in sorted(by_frame.items()):
        desired=eligible(at,contexts,users,unmatched,want)
        banks={native.variants[u[0]]for u in users[at]}
        if desired is None or len(banks)!=1:continue
        bank=next(iter(banks));offsets=struct.unpack('>5h',native.read(bank,10));frame=bytearray(native.read(at,20));frame[0]=desired[0]
        attack=native.read(bank+offsets[4]+frame[9]*32,32)
        if attack!=desired[1]:
            hits=[i for i in sorted(used_attacks[bank])if native.read(bank+offsets[4]+i*32,32)==desired[1]]
            if not hits:continue
            frame[9]=hits[0]
        sel=native.read(native.indices+frame[8]*4,4)
        if tuple(native.read(bank+offsets[l]+sel[l]*8,8)for l in range(4))!=desired[2]:
            rows=[]
            for lane in range(4):
                hits=[i for i in sorted({native.blob[native.indices+s*4+lane]for s in used_selectors})if native.read(bank+offsets[lane]+i*8,8)==desired[2][lane]]
                rows.append(hits[0]if hits else None)
            hits=[]if None in rows else [i for i in sorted(used_selectors)if native.read(native.indices+i*4,4)==bytes(rows)]
            if not hits:continue
            frame[8]=hits[0]
        native.blob[at:at+20]=frame;changed+=1
    return changed


def relocate_missing(source,native):
    users,unmatched,want,by_frame=deficiencies(source,native);banks=sorted(set(native.variants))
    offsets={b:struct.unpack('>5h',native.read(b,10))for b in banks}
    rows={b:[[native.read(b+offsets[b][lane]+i*8,8)for i in range((offsets[b][lane+1]-offsets[b][lane])//8)]for lane in range(4)]for b in banks}
    allframes=[at for family in native.families for frames,_ in family for at in frames]
    count=max(native.blob[at+8]for at in allframes)+1
    selectors=[native.read(native.indices+i*4,4)for i in range(count)];updates=[];held=0
    for at,contexts in sorted(by_frame.items()):
        desired=eligible(at,contexts,users,unmatched,want)
        if desired is None:held+=1;continue
        through=sorted({native.variants[u[0]]for u in users[at]});frame=bytearray(native.read(at,20));frame[0]=desired[0]
        if not all(native.read(b+offsets[b][4]+frame[9]*32,32)==desired[1]for b in through):
            hits=[i for i in sorted({native.blob[a+9]for a in allframes})if all(native.read(b+offsets[b][4]+i*32,32)==desired[1]for b in through)]
            if not hits:held+=1;continue
            frame[9]=hits[0]
        selected=[]
        for lane in range(4):
            n=max(len(rows[b][lane])for b in banks)
            hits=[i for i in range(n)if all(i<len(rows[b][lane])and rows[b][lane][i]==desired[2][lane]for b in through)]
            if not hits:
                for b in banks:
                    while len(rows[b][lane])<n:rows[b][lane].append(rows[b][lane][0])
                    rows[b][lane].append(desired[2][lane])
                hits=[n]
            selected.append(hits[0])
        require(max(selected)<256,'Native collision row index reach')
        if bytes(selected)not in selectors:selectors.append(bytes(selected))
        frame[8]=selectors.index(bytes(selected));updates.append((at,frame))
    writes=[];sizes=[]
    for b,target in zip(banks,(0xaa5450,0xaa6440)):
        offsets_new=[10]
        for lane in rows[b]:offsets_new.append(offsets_new[-1]+len(lane)*8)
        attacks=max(native.blob[at+9]for slot,family in enumerate(native.families)if native.variants[slot//4]==b for frames,_ in family for at in frames)+1
        blob=struct.pack('>5h',*offsets_new)+b''.join(b''.join(lane)for lane in rows[b])+native.read(b+offsets[b][4],attacks*32)
        writes.append((target,blob));sizes.append(len(blob))
    writes.append((0xaa7460,b''.join(selectors)));sizes.append(len(selectors)*4)
    require(sizes==[4066,4114,384],'Complete batch8 Dhalsim table allocation extents: '+str(sizes))
    for at,value in updates:native.blob[at:at+20]=value
    return writes,{'initial_selectors':count,'selectors':len(selectors),'remapped_frames':len(updates),'held_contexts':held,'table_bytes':sizes}


def construct(inputs,recipe):
    import hashlib
    for name,pin in recipe['inputs'].items():
        value=inputs[name];require(len(value)==pin['bytes']and hashlib.sha256(value).hexdigest()==pin['sha256'],'Original Dhalsim '+name+' identity')
    source,native=original_model(inputs['arcade'],inputs['comp2'],recipe['region'])
    direct=direct_projection(source,native);existing=repoint_existing(source,native)
    writes,report=relocate_missing(source,native);report['direct_source_bytes']=direct;report['existing_row_frames']=existing
    return writes,report
