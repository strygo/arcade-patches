"""Media-sourced retained restoration quotes and complete native pool lookups."""
import hashlib
import struct
from public_kit_english_supply import consumed,lines
from public_kit_english_text import encode
from public_kit_graphics import require


def source_record(comp2,owner,slot):
    require(0<=owner<40 and 0<=slot<8,'Original generic quote selector domain')
    root=struct.unpack_from('<I',comp2,0xa104)[0]-0x60ad00
    relative=struct.unpack_from('<40H',comp2,root)
    require(min(relative)>=80,'Original generic owner directory extent')
    at=root+relative[owner];header=struct.unpack_from('<9H',comp2,at)
    require(header[0]==18 and header[-1]==0 and list(header[:8])==sorted(set(header[:8])),
            'Original generic quote directory shape')
    start=at+header[slot];end=at+header[slot+1] if slot<7 else start+512
    raw=comp2[start:end];zero=raw.find(b'\0')
    if slot<7 and zero>=0 and not any(raw[zero+1:]):raw=raw[:zero+1]+b'\x70'
    return consumed(raw)


def construct(comp2,pixels,recipe):
    require(recipe['schema']==1 and hashlib.sha256(comp2).hexdigest()==recipe['source_sha256'] and
            hashlib.sha256(pixels).hexdigest()==recipe['font_pixels_sha256'],'Original retained quote inputs differ')
    require(len(recipe['retained'])==76 and len(recipe['pools'])==25,'Complete retained quote/pool inventory')
    writes=[]
    for row in recipe['retained']:
        raw=source_record(comp2,row['owner'],row['slot'])
        text=' '.join(' '.join(line.decode('ascii') for _,line in lines(raw)).split())
        shown=[];cursor=0
        for length in row['row_lengths']:
            shown.append(text[cursor:cursor+length]);cursor+=length+1
        require(' '.join(shown)==text,'Original quote layout changes source wording')
        blob,xy=encode(shown,'quote',row['advance'],pixels)
        writes.extend(((row['address'],blob),(row['coordinates'],xy)))
    for pool in recipe['pools']:
        rows=pool['records'];at=pool['address']
        require(len(rows)==33 and [r['slot'] for r in rows]==list(range(33)),'Complete native quote slot domain')
        offsets=[r['address']-at for r in rows]
        require(offsets[0]==68 and list(offsets)==sorted(set(offsets)) and max(offsets)<65536,
                'Native quote relative directory extent')
        writes.append((at,struct.pack('>34H',*offsets,0)))
        writes.append((pool['position_table'],b''.join(struct.pack('>II',r['address'],r['coordinates']) for r in rows)))
    return writes
