"""Complete original command-selected ending color arrays, with no color literals."""
import hashlib
import struct
from public_kit_graphics import require

OWNERS=(34,)


def graph(comp2,region,owner):
    require(region in ('us','jp') and owner in OWNERS,'Unknown ending color domain')
    base=0x60b080 if region=='jp' else 0x60ad00;ds=0x10f0 if region=='jp' else 0
    def read(at,size):
        require(size>0 and 0<=at-base<=len(comp2)-size,'Ending color source bounds')
        return comp2[at-base:at-base+size]
    def u32(at):return struct.unpack('<I',read(at,4))[0]
    directory=u32(0x60b5a0+ds+owner*4);at=u32(0x60b860+ds+owner*4);demands=set()
    require(at==u32(0x60b910+ds+owner*4),'Original ending command mode alias differs')
    for count in range(2048):
        timer,tag=struct.unpack('<HH',read(at,4));arity=tag&15
        values=struct.unpack('<'+str(arity)+'H',read(at+4,arity*2)) if arity else ()
        group,opcode,kind=(tag>>4)&7,(tag>>8)&15,tag>>12
        if group==0 and opcode in (1,5) and not(opcode==5 and kind==15):
            selectors=values[4:8] if opcode==1 else values[1:5]
            require(len(selectors)==4,'Unknown four-group palette command')
            demands.update(zip(selectors,(30,32,32,32)))
        if group==0 and opcode==9:
            require(len(values)==4,'Unknown single-range palette command')
            dest,selector,offset,budget=values
            require(dest in (0,2,4,6) and 1<=budget<=32 and 0<=offset<=4096-budget*32,'Single-range palette extent')
            demands.add((selector,budget))
        at+=4+arity*2
        if tag>>8==0 and tag&0x70==0:
            require(arity==0,'Original ending terminal has operands');break
    else:raise ValueError('Unbounded original ending commands')
    resources={}
    for selector,budget in sorted(demands):
        at=u32(directory+selector*4);remaining=budget;rows=[]
        for _ in range(64):
            family,slot,offset,declared=struct.unpack('<4H',read(at,8))
            require(family%4==0 and 0<=family<=72 and slot%(4 if family<=8 else 2)==0 and 1<=declared<=32,'Unknown original ending color recipe')
            table=u32(0x60b560+ds+family)
            ptr=u32(table+slot) if family<=8 else table+struct.unpack('<h',read(table+slot,2))[0]
            source=ptr+(offset-65536 if offset&32768 else offset);copied=min(declared,remaining)
            raw=read(source,copied*32);colors=b''.join(raw[n:n+2][::-1] for n in range(0,len(raw),2))
            rows.append((source,colors));at+=8;remaining-=copied
            if remaining==0:break
        else:raise ValueError('Unbounded original ending color recipe')
        resources[selector,budget]=rows
    require(resources,'Absent original ending palette graph')
    return resources


def construct(comp2,recipe):
    require(recipe['schema']==1 and hashlib.sha256(comp2).hexdigest()==recipe['source_sha256'],'Original Dee ending color input identity')
    require(set(recipe['families'])==set(map(str,OWNERS)),'Complete ending color family inventory')
    writes=[];reports={}
    for owner in OWNERS:
        resources=graph(comp2,recipe['region'],owner);row=recipe['families'][str(owner)]
        require(len(resources)==row['graphs'],'Complete original ending palette graph census')
        for selector,budget,index,address,size in row['arrays']:
            require((selector,budget) in resources and 0<=index<len(resources[selector,budget]),'Unknown original color array selector')
            source,blob=resources[selector,budget][index]
            require(len(blob)==size and 0xa00000<=address<=0xe00000-size,'Complete ending color allocation extent')
            writes.append((address,blob))
        reports[str(owner)]={'graphs':len(resources),'arrays':len(row['arrays']),'bytes':sum(r[4] for r in row['arrays'])}
    return writes,reports


def main():
    import argparse,json
    from pathlib import Path
    p=argparse.ArgumentParser(description=__doc__)
    for n in ('comp2','recipe','outdir'):p.add_argument('--'+n,type=Path,required=True)
    a=p.parse_args();writes,_=construct(a.comp2.read_bytes(),json.loads(a.recipe.read_text()));data=bytearray(0x400000);mask=bytearray(len(data))
    for at,blob in writes:
        at-=0xa00000;require(not any(mask[at:at+len(blob)]),'Ending color overlap')
        data[at:at+len(blob)]=blob;mask[at:at+len(blob)]=b'\1'*len(blob)
    a.outdir.mkdir(exist_ok=True);(a.outdir/'result.bin').write_bytes(data);(a.outdir/'result.mask').write_bytes(mask)


if __name__=='__main__':main()
