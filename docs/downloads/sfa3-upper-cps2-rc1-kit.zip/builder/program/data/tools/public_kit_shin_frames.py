"""Typed Shin frame and complete original/native indexed canvas reconstruction."""
import hashlib
import struct
from public_kit_actor import Data
from public_kit_blocks import grid_code,native_grid_code
from public_kit_graphics import require


def native_cel(raw,address):
    def read(at,size):
        require(at%2==0 and 0<=at<=len(raw)-size,'Original native cel descriptor bounds')
        return raw[at:at+size]
    kind=struct.unpack('>H',read(address,2))[0]
    if kind==18:return (),[(address,read(address,2))]
    require(kind in (0,2,6),'Unknown original native cel format')
    total,last=struct.unpack('>2H',read(address+2,4));count=total if kind==0 else last+1
    require(0<count<=1024,'Original native cel descriptor count')
    blocks=[];spans=[]
    if kind==6:
        x,y=struct.unpack('>2h',read(address+6,4))
        for i in range(count):
            pos,tile,attr=struct.unpack('>3H',read(address+10+i*6,6))
            require(pos%4==0 and pos<1024,'Original compact coordinate index')
            point=read(0x229ae+pos,4);dx,dy=struct.unpack('>2h',point)
            blocks.append((x+dx,y+dy,tile,attr));spans.append((0x229ae+pos,point))
        size=10+6*count
    else:
        xy=struct.unpack('>I',read(address+6,4))[0];points=read(xy,count*4);spans.append((xy,points))
        for i,(x,y) in enumerate(struct.iter_unpack('>2h',points)):
            tile,attr=(struct.unpack('>H',read(address+10+i*2,2))[0],last) if kind==0 else struct.unpack('>2H',read(address+10+i*4,4))
            blocks.append((x,y,tile,attr))
        size=10+count*(2 if kind==0 else 4)
    require(sum(((attr>>8&15)+1)*((attr>>12&15)+1)for _,_,_,attr in blocks)==total,'Complete native cel tile area')
    spans.append((address,read(address,size)))
    return tuple(blocks),spans


def canvas(blocks,pixels,*,native=False,valid=None,mirror=False):
    # Every pixel in every selected tile is decoded, including transparent15.
    # A sparse canvas represents the entire signed object plane, transparent
    # by default; transparent source pixels preserve prior object overdraw.
    result={};decoded=0
    for x,y,base,attr in blocks:
        width,height=(attr>>8&15)+1,(attr>>12&15)+1
        require(attr&0x80==0,'Unknown object attribute bit7')
        if mirror:x=-x-16*width;attr^=0x20
        require(-512<=x<=512-width*16 and -512<=y<=512-height*16,'Bounded object-relative canvas')
        for dy in range(height):
            for dx in range(width):
                sx=width-1-dx if attr&32 else dx;sy=height-1-dy if attr&64 else dy
                tile=native_grid_code(base,sx,sy,attr) if native else grid_code(base,sx,sy)
                require(0<=tile<len(pixels)//128 and (valid is None or tile<len(valid) and valid[tile]),'Complete original canvas tile supply')
                packed=pixels[tile*128:(tile+1)*128]
                for py in range(16):
                    yy=15-py if attr&64 else py
                    for px in range(16):
                        xx=15-px if attr&32 else px;v=packed[yy*8+xx//2];pen=(v>>(4*(xx%2)))&15;decoded+=1
                        if pen!=15:result[x+dx*16+px,y+dy*16+py]=pen|((attr&31)<<4)
    return result,decoded


def compare_canvas(source,native,source_pixels,native_pixels,valid):
    total=0
    for mirror in (False,True):
        expected,count=canvas(source,source_pixels,valid=valid,mirror=mirror)
        observed,other=canvas(native,native_pixels,native=True,mirror=mirror)
        require(expected==observed,'Complete original/native indexed canvas differs')
        total+=count+other
    return total

BYTE_CONTEXTS={1:(1,2,3,4,5,6,7,8,9,19,22,27,28,34),2:(4,5,6,42,47,48,54,60,61,62)}
NAOMI_FRONTIER={0xc42892,0xc4531a,0xc4532e}


def graph(data,table):
    bank=data.u32(table+36*4);roots=struct.unpack('<12I',data.read(bank,48))
    require(roots==roots[:4]*3,'Original Shin ISM family aliases')
    frames={};byte_frames=set()
    for family,root in enumerate(roots[:4]):
        for action,start in enumerate(data.root(root)[1]):
            at=start;seen=set()
            while at is not None and at not in seen:
                seen.add(at);raw=data.read(at,20);nxt=data.frame(at)[2]
                frames[at]=(data.u32(at+4),nxt,24 if raw[1]&128 else 20)
                if action in BYTE_CONTEXTS.get(family,()):byte_frames.add(at)
                at=nxt;require(len(frames)<=1024,'Original Shin graph exceeds complete family')
    require(len(frames)==1024,'Original Shin complete family frame census')
    return frames,byte_frames


def construct(inputs,recipe,native_pixels):
    from public_kit_frame_resources import cel as emit_cel
    for name,pin in recipe['inputs'].items():
        require(len(inputs[name])==pin['bytes'] and hashlib.sha256(inputs[name]).hexdigest()==pin['sha256'],'Original Shin input identity: '+name)
    require(hashlib.sha256(native_pixels).hexdigest()==recipe['graphics_pixels_sha256'],'Reconstructed Shin graphics identity')
    data=Data(inputs['comp2'],recipe['base'],inputs['coords'],0xb04000)
    frames,byte_frames=graph(data,recipe['owner_table'])
    mapping={row[0]:row for row in recipe['frames']}
    require(len(mapping)==len(recipe['frames']) and set(mapping)==set(frames),'Complete Shin frame allocation inventory')
    cels={row[0]:row for row in recipe['cels']}
    require(len(cels)==len(recipe['cels']) and set(cels)=={row[0]for row in frames.values()},'Complete Shin cel allocation inventory')
    writes=[];canvas_pixels=0;reused=0
    for source,row in cels.items():
        _,native,bank,xy,tiles=row
        kind,source_blocks=data.cel(source);source_blocks=tuple((x,y,w&65535,w>>16)for x,y,w in source_blocks)
        if native<0xa00000:
            require(xy is None and tiles is None and bank in range(4),'Original native cel alias metadata')
            blocks,_=native_cel(inputs['arcade'],native)
            canvas_pixels+=compare_canvas(source_blocks,blocks,inputs['pixels'],inputs['native_pixels'][bank*0x800000:(bank+1)*0x800000],inputs['valid'])
            compare_canvas(source_blocks,blocks,inputs['pixels'],native_pixels[bank*0x800000:(bank+1)*0x800000],inputs['valid']);reused+=1
        else:
            require(0xc40000<=native<0xc400ea and bank==0,'Shin newly packed cel allocation')
            coords,blob=emit_cel(data,source,xy,tiles,inputs['pixels'],inputs['valid'],native_pixels[0x2000000:],bank)
            if coords is not None:writes.append((xy,coords))
            writes.append((native,blob))
    skipped=[]
    for source,row in mapping.items():
        _,native,cel_pointer,native_next=row;source_cel,nxt,size=frames[source]
        require(cels[source_cel][1]==cel_pointer,'Shin frame selected cel ownership')
        require(0xc400ea<=native<0xc4535a and native%2==0,'Shin native full-frame allocation')
        require(native_next==(mapping[nxt][1] if nxt is not None else None),'Complete Shin successor allocation')
        if size==20 and nxt is not None:require(native_next==native+20,'Shin native frame fallthrough')
        if native in NAOMI_FRONTIER:skipped.append(native);continue
        raw=data.read(source,20)
        tail=raw[16:18] if source in byte_frames else raw[16:18][::-1]
        blob=raw[:4]+struct.pack('>I',cel_pointer)+raw[8:16]+tail+raw[18:20]
        if size==24:blob+=struct.pack('>I',native_next)
        writes.append((native,blob))
    require(set(skipped)==NAOMI_FRONTIER,'Shin Naomi-corrected complete-frame frontier changed')
    return writes,{'source_frames':len(frames),'reconstructed_frames':len(frames)-len(skipped),'reused_native_cels':reused,
                   'converted_cels':len(cels)-reused,'decoded_canvas_pixels_both_facings':canvas_pixels,
                   'excluded_complete_frames':sorted(skipped),'frontier':'Three original-Naomi clock/collision corrections; no partial frame payload emitted'}
