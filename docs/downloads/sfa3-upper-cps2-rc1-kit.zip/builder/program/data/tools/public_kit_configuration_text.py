"""Encode the approved Upper service-menu text in its native printer formats.

The words are authored test-font glyph references, not font pixels. Both
language pages and their fixed-width choice fields form one complete object.
"""
import hashlib
import struct
from public_kit_graphics import require


def construct(recipe):
    require(recipe['schema']==1,'Configuration recipe schema')
    result=bytearray()
    for name,count,size in (('jp_menu',7,158),('jp_page',4,82)):
        rows=recipe[name];require(len(rows)==count,'Complete Japanese menu rows')
        start=len(result)
        for index,row in enumerate(rows):
            require(set(row)=={'position','attribute','glyphs'} and row['attribute'] in (27,31),'Japanese printer header')
            require(0<=row['position']<0x1000 and row['glyphs'] and all(0x2b00<=n<0x2d00 for n in row['glyphs']),'Japanese printer glyph domain')
            words=[row['position'],row['attribute'],*row['glyphs'],0 if index==count-1 else 0xffff]
            result.extend(struct.pack('>'+str(len(words))+'H',*words))
        require(len(result)-start==size,'Japanese printer object extent')
    require(len(recipe['jp_values'])==2,'Complete Japanese title choices')
    for words in recipe['jp_values']:
        require(len(words)==10 and all(0x2b00<=n<0x2d00 for n in words),'Japanese title choice glyphs')
        result.extend(struct.pack('>10H',*words)+bytes(12))
    for name,count,size in (('en_menu',7,138),('en_page',4,104)):
        rows=recipe[name];require(len(rows)==count,'Complete English menu rows')
        start=len(result)
        for index,row in enumerate(rows):
            require(set(row)=={'x','y','attribute','text'} and row['attribute'] in (27,31),'English printer header')
            text=row['text'].encode('ascii')
            require(0<=row['x']<64 and 0<=row['y']<128 and text and all(32<=n<127 for n in text),'English printer text domain')
            result.extend(bytes((row['x'],row['y'],row['attribute']))+text+bytes((0 if index==count-1 else 255,)))
        if name=='en_menu':result.append(255) # Original authored alignment byte.
        require(len(result)-start==size,'English printer object extent')
    require(recipe['en_values']==['PLAYSTATION 2','NAOMI        '],'Approved title choices')
    result.extend(b''.join(s.encode('ascii')+bytes(3) for s in recipe['en_values']))
    require(len(result)==578 and hashlib.sha256(result).hexdigest()==recipe['authored_sha256'],'Complete authored service-menu identity')
    return [(0xaaa000,bytes(result))],{'bytes':578,'japanese_rows':11,'english_rows':11,'choice_fields':4,'authored_text_only':True}
