"""Complete ordinary Boxer21 scalar frame graphs and five native root directories."""
import hashlib,struct
from public_kit_actor import Data
from public_kit_graphics import require

BYTE_CONTEXTS={1:{1,2,3,4,5,6,7,8,9,19,22,27,28,34},2:{1,2,5}}

def chain(read,at,endian):
    rows={}
    while at is not None and at not in rows:
        header=read(at,20);nxt=struct.unpack(endian+'I',read(at+20,4))[0]if header[1]&128 else None if header[1]&64 else at+20
        rows[at]=(header,nxt);at=nxt;require(len(rows)<2048,'Bounded original ordinary Boxer graph')
    return rows

def construct(inputs,recipe):
    require(set(inputs)==set(recipe['inputs'])=={'arcade','comp2','coords'},'Complete ordinary Boxer frame inputs')
    for name,pin in recipe['inputs'].items():
        require(len(inputs[name])==pin['bytes'] and hashlib.sha256(inputs[name]).hexdigest()==pin['sha256'],'Original ordinary Boxer frame input '+name)
    region=recipe['region'];require(region in ('us','jp'),'Original ordinary Boxer region')
    data=Data(inputs['comp2'],0x60ad00 if region=='us' else 0x60b080,inputs['coords'],0xb04000)
    table=0x749838 if region=='us' else 0x74ef38;roots=struct.unpack('<12I',data.read(data.u32(table+21*4),48));hidden=struct.unpack('<12I',data.read(data.u32(table+37*4),48))
    def read(at,size):
        require(0<=at<=len(inputs['arcade'])-size,'Canonical ordinary Boxer control bounds');return inputs['arcade'][at:at+size]
    nbank=struct.unpack('>I',read(0xde6a0+21*4,4))[0];native_roots=struct.unpack('>12I',read(nbank,48))
    frames={};typed=set();worded=set();families={};controls=0
    for family,root in enumerate(roots):
        _,targets=data.root(root);require(len(targets)==(70,48,56,30)[family%4],'Complete ordinary Boxer action directory');families[family]=targets
        for action,target in enumerate(targets):
            rows=chain(data.read,target,'<');frames.update(rows)
            if action not in BYTE_CONTEXTS.get(family%4,set()):worded.update(rows);continue
            typed.update(rows);ht=data.root(hidden[family])[1][action]
            nr=native_roots[family]+struct.unpack('>h',read(native_roots[family]+action*2,2))[0]
            hidden_rows=chain(data.read,ht,'<');native_rows=chain(read,nr,'>')
            require(len(rows)==len(hidden_rows)==len(native_rows),'Complete byte-field action control extent')
            for (source,_),(other,_),(native,_)in zip(rows.values(),hidden_rows.values(),native_rows.values()):
                require(source[:9]+source[10:]==other[:9]+other[10:] and source[16:18]==native[16:18],'Original ordinary Boxer typed16/17 control')
            controls+=1
    require(len(frames)==972 and len(set(roots))==5,'Complete972-frame five-root domain')
    require(all(frames[at][0][16:18]==frames[at][0][16:18][::-1]for at in typed&worded),'Shared frame byte/word ambiguity')
    require(recipe['excluded_components']==[{'family':0,'action':35,'frames':13}], 'Declared complete excluded Boxer component')
    graphs=[set(chain(data.read,target,'<')) for targets in families.values()for target in targets]
    excluded=set(chain(data.read,families[0][35],'<'))
    while True:
        previous=set(excluded)
        for graph in graphs:
            if graph & excluded:excluded.update(graph)
        if excluded==previous:break
    require(len(excluded)==13,'Whole connected primary35 component extent')
    require(all(not graph&excluded or graph<=excluded for graph in graphs),'No partial original graph admitted')
    cels={int(k):v for k,v in recipe['cels'].items()};source_cels={struct.unpack_from('<I',h,4)[0]for h,_ in frames.values()}
    require(set(cels)==source_cels and len(cels)==228,'Verified complete cel pointer allocation domain')
    mapping={};cursor=0xc7b18e
    for at,(header,_)in sorted(frames.items()):mapping[at]=cursor;cursor+=24 if header[1]&128 else 20
    require(cursor==0xc7feb6,'Complete ordinary Boxer frame allocation extent')
    writes=[]
    for at,(header,nxt)in sorted(frames.items()):
        blob=bytearray(header)
        pointer=struct.unpack_from('<I',header,4)[0];struct.pack_into('>I',blob,4,cels[pointer])
        if at not in typed:blob[16:18]=header[16:18][::-1]
        if header[1]&128:blob.extend(struct.pack('>I',mapping[nxt]))
        elif nxt is not None:require(mapping[nxt]==mapping[at]+20,'Complete ordinary Boxer fallthrough')
        if at not in excluded:writes.append((mapping[at],bytes(blob)))
    rootmap={}
    for family,root in enumerate(roots):
        if root in rootmap:continue
        targets=families[family];rootmap[root]=cursor;offsets=[mapping[t]-cursor for t in targets]
        require(all(-32768<=o<32768 and o for o in offsets),'Signed ordinary Boxer root reach')
        blob=struct.pack('>'+str(len(offsets)+1)+'h',*offsets,0);writes.append((cursor,blob));cursor+=len(blob)
    require(cursor==0xc800c8,'Complete ordinary Boxer five-root extent')
    writes.append((cursor,struct.pack('>12I',*(rootmap[r]for r in roots))))
    return writes,{'frames':972,'roots':5,'bank_words':12,'typed_frames':len(typed),'byte_context_controls':controls,'verified_frames':len(frames)-len(excluded),'excluded_connected_components':[{'family':0,'action':35,'frames':len(excluded),'reason':'batch7 timer source projection remains unresolved'}],'bytes':sum(len(blob)for _,blob in writes)}
