"""Complete original-derived restoration foreground clones and Mika map root."""
import hashlib,struct
from public_kit_graphics import require

S3=0x3ac614
DEST=0xd60000


def construct(native,recipe,pixels):
    require(hashlib.sha256(native).hexdigest()==recipe['native_sha256'],'Original foreground identity')
    require(hashlib.sha256(pixels).hexdigest()==recipe['pixels_sha256'],'Composed foreground graphics identity')
    blank=recipe['blank_physical'];require(blank%4==0 and 0x12c00<=blank<0x20000,'Foreground blank allocation')
    require(pixels[blank*128:(blank+4)*128]==b'\xff'*512,'Complete foreground transparent tile differs')
    code=(blank-0x10000)//4-0xb00;writes=[]
    for new,old,width in ((139,70,8),(140,71,4),(142,78,8),(143,78,4)):
        page=bytearray(native[S3+old*192:S3+(old+1)*192])
        for x in range(width):cell=x*8+7;struct.pack_into('>H',page,cell*2,code);page[128+cell]=0
        writes.append((DEST+new*192,bytes(page)))
    for new,old,columns in ((144,124,range(4,8)),(147,125,range(8))):
        page=bytearray(native[S3+old*192:S3+(old+1)*192])
        for x in columns:
            dst=x*8+3;src=x*8+4;page[dst*2:dst*2+2]=page[src*2:src*2+2];page[128+dst]=page[128+src]^64
        writes.append((DEST+new*192,bytes(page)))
    old=native[0x328b18:0x328b18+108]
    require(old[:8]==struct.pack('>4H',8,12,28,92),'Complete original Mika root grammar')
    payload=bytearray(old[8:]);require(payload[92-8+8:92-8+10]==bytes((116,117)),'Original Mika background pages')
    payload[92-8+8:92-8+10]=bytes((146,147));foreground=bytearray(old[28:92])
    require(foreground[8:10]==bytes((78,78)),'Original Mika foreground pages');foreground[8:10]=bytes((142,143))
    root=struct.pack('>5H',10,14,30,94,110)+payload+foreground;require(len(root)==174,'Whole Mika private root extent')
    writes.append((DEST+256*192,root))
    return writes,{'complete_pages':6,'complete_roots':1,'bytes':1326}


def main():
    import argparse,json
    from pathlib import Path
    p=argparse.ArgumentParser(description=__doc__)
    for n in ('native','recipe','pixels','outdir'):p.add_argument('--'+n,type=Path,required=True)
    a=p.parse_args();writes,report=construct(a.native.read_bytes(),json.loads(a.recipe.read_text()),a.pixels.read_bytes());data=bytearray(0x400000);mask=bytearray(len(data))
    for at,blob in writes:
        at-=0xa00000;data[at:at+len(blob)]=blob;mask[at:at+len(blob)]=b'\1'*len(blob)
    (a.outdir/'result.bin').write_bytes(data);(a.outdir/'result.mask').write_bytes(mask);print(json.dumps(report))


if __name__=='__main__':main()
