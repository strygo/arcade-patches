"""Original Upper actor records converted to native CPS2 data."""
import struct
import hashlib
from public_kit_graphics import require
from public_kit_blocks import BlockPacker, grid_code

class Data:
    def __init__(self, blob, base, coords, coord_base):
        self.blob, self.base, self.coords, self.coord_base = blob, base, coords, coord_base

    def read(self, address, size):
        offset = address-self.base
        require(0 <= offset <= len(self.blob)-size, 'Source address outside declared component')
        return self.blob[offset:offset+size]

    def u32(self, at): return struct.unpack('<I', self.read(at, 4))[0]

    def root(self, at):
        for n in range(256):
            if self.read(at+2*n, 2) == b'\0\0':
                raw = self.read(at, (n+1)*2)
                return raw, [at+v for v in struct.unpack('<'+str(n)+'h', raw[:-2])]
        raise ValueError('Unbounded source action root')

    def cel(self, at):
        kind = struct.unpack('<H', self.read(at, 2))[0]
        if kind == 18: return (kind, ())
        require(kind in (0, 2), 'Unqualified cel format '+hex(kind))
        total, last = struct.unpack('<2H', self.read(at+2, 4))
        count = last+1 if kind == 2 else total
        require(1 <= count <= 1024, 'Source cel count')
        pointer_at = (at+9)&~3
        require(not any(self.read(at+6, pointer_at-at-6)), 'Nonzero cel alignment padding')
        xy = self.u32(pointer_at)-self.coord_base
        require(xy%4 == 0 and 0 <= xy <= len(self.coords)-count*4, 'Source coordinate bounds')
        points = list(struct.iter_unpack('<2h', self.coords[xy:xy+count*4]))
        if kind == 2:
            words = struct.unpack('<'+str(count)+'I', self.read(pointer_at+4, count*4))
        else:
            words = [v|(last<<16) for v in struct.unpack('<'+str(count)+'H', self.read(pointer_at+4, count*2))]
        blocks = tuple((x,y,w) for (x,y),w in zip(points, words))
        require(sum((((w>>24)&15)+1)*(((w>>28)&15)+1) for _,_,w in blocks) == total,
                'Cel expanded tile count differs')
        return kind, blocks

    def frame(self, at):
        require(at%4 == 0, 'Unaligned frame')
        raw = self.read(at, 20); cel = self.cel(self.u32(at+4))
        nxt = self.u32(at+20) if raw[1]&128 else None if raw[1]&64 else at+20
        return raw[:4]+raw[8:], cel, nxt


def construct(comp2, coords, pixels, valid, recipe):
    data = Data(comp2, recipe['base'], coords, 0xb04000)
    roots = struct.unpack('<12I', data.read(recipe['bank'], 48))
    require(roots[:4] == roots[4:8] == roots[8:], 'Original actor root banks differ')
    admissions = {r['address']: r['actions'] for r in recipe['roots']}
    require(set(roots) == set(admissions), 'Original actor root inventory')
    frames, cels, targets = {}, {}, {}
    for root in roots[:4]:
        targets[root] = data.root(root)[1]
        for action in admissions[root]:
            require(0 <= action < len(targets[root]), 'Actor action extent')
            address = targets[root][action]
            while address is not None and address not in frames:
                require(len(frames) < recipe['frames'], 'Unexpected actor graph extent')
                raw = data.read(address, 20)
                _, cel, nxt = data.frame(address)
                cel_at = data.u32(address+4)
                frames[address] = {'bytes': 24 if raw[1] & 128 else 20, 'cel': cel_at, 'next': nxt}
                cels[cel_at] = cel
                address = nxt
    require(len(frames) == recipe['frames'], 'Actor graph frame count')
    packer = BlockPacker(b'')
    packer.add(1, 1, [b'\xff'*128], 0)
    converted = {}
    for address, (kind, records) in sorted(cels.items()):
        blocks = []
        for x, y, word in records:
            code, attr = word & 65535, word >> 16
            width, height = (attr >> 8 & 15)+1, (attr >> 12 & 15)+1
            codes = [grid_code(code, dx, dy) for dy in range(height) for dx in range(width)]
            require(all(0 <= c < len(valid) and valid[c] and (c+1)*128 <= len(pixels) for c in codes),
                    'Actor demanded absent original artwork')
            tiles = [pixels[c*128:(c+1)*128] for c in codes]
            tile = packer.add(width, height, tiles, attr)
            packer.check(tile, width, height, tiles, attr)
            require(tile < 65536 and attr & 31 <= 4, 'Actor cel bank/palette extent')
            blocks.append((x, y, tile, attr))
        converted[address] = blocks
    base = 0xa03000
    blob, cel_map, frame_map = bytearray(), {}, {}
    for address, blocks in sorted(converted.items()):
        if not blocks:
            require(cels[address][0] == 18, 'Empty nonblank actor cel')
            cel_map[address] = base+len(blob)
            blob.extend(struct.pack('>H', 18))
            continue
        xy = base+len(blob)
        blob.extend(b''.join(struct.pack('>hh', x, y) for x, y, _, _ in blocks))
        cel_map[address] = base+len(blob)
        total = sum(((a >> 8 & 15)+1)*((a >> 12 & 15)+1) for _, _, _, a in blocks)
        blob.extend(struct.pack('>HHHI', 2, total, len(blocks)-1, xy))
        blob.extend(b''.join(struct.pack('>HH', t, a) for _, _, t, a in blocks))
    cel_bytes = len(blob)
    for address, row in sorted(frames.items()):
        frame_map[address] = base+len(blob)
        blob.extend(bytes(row['bytes']))
    poses = set()
    for action in (0, 1, 2, 3, 4, 18, 19):
        address = targets[roots[2]][action]
        seen = set()
        while address is not None and address not in seen:
            require(address in frames, 'Pose leaves admitted actor graph')
            seen.add(address); poses.add(address); address = frames[address]['next']
    for address, row in sorted(frames.items()):
        at = frame_map[address]-base
        source = data.read(address, 20)
        blob[at:at+20] = struct.pack('>10H', *struct.unpack('<10H', source))
        blob[at:at+4] = source[:4]
        blob[at+8:at+16] = source[8:16]
        if address in poses:
            require(source[16] <= 20 and source[17] == 0, 'Actor pose field grammar')
            blob[at+16:at+18] = source[16:18]
        struct.pack_into('>I', blob, at+4, cel_map[row['cel']])
        if source[1] & 128:
            require(row['next'] in frame_map, 'Unknown actor successor')
            struct.pack_into('>I', blob, at+20, frame_map[row['next']])
        elif not source[1] & 64:
            require(frame_map[row['next']] == frame_map[address]+20, 'Actor fallthrough layout')
    for root in roots[:4]:
        address = base+len(blob)
        admitted = set(admissions[root])
        values = [frame_map[targets[root][n]]-address if n in admitted else 0
                  for n in range(max(admitted)+1)]
        require(all(-32768 <= n < 32768 for n in values), 'Actor signed root reach')
        blob.extend(struct.pack('>'+str(len(values))+'h', *values))
    require(hashlib.sha256(blob).hexdigest() == recipe['payload_sha256'],
            'Original actor conversion differs from pinned producer')
    # cohort_basics_resources.auxiliary_selectors: these are two byte fields,
    # not a little-endian word. Apply the established correction to all frames.
    selectors = 0
    for address in sorted(frames):
        at = frame_map[address]-base+18
        source = data.read(address+18, 2)
        selectors += blob[at:at+2] != source
        blob[at:at+2] = source
    require(selectors == recipe['selector_corrections'] and
            hashlib.sha256(blob).hexdigest() == recipe['batch34_sha256'],
            'Final actor allocation differs from batch 34')
    return bytes(blob), {'frames': len(frames), 'cels': len(cels), 'cel_bytes': cel_bytes,
                         'selector_corrections': selectors,
                         'bytes': len(blob), 'sha256': hashlib.sha256(blob).hexdigest(),
                         'frame_bindings': [{'source': address, 'offset': frame_map[address]-base,
                                             'bytes': row['bytes']} for address, row in sorted(frames.items())]}

