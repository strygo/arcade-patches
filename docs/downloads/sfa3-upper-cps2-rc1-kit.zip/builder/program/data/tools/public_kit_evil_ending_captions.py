"""Complete original Evil caption allocation and reviewed USA text erasure."""
import hashlib,struct
from public_kit_original_quotes import packed_record
from public_kit_graphics import require


def construct(inputs,recipe):
    require(set(inputs)==set(recipe['inputs'])=={'comp2-jp'},'Original inherited Japanese caption component only')
    data=inputs['comp2-jp'];pin=recipe['inputs']['comp2-jp']
    require(len(data)==pin['bytes']and hashlib.sha256(data).hexdigest()==pin['sha256'],'Original caption component identity')
    region=recipe['region'];require(region in ('us','jp'),'Caption display region')
    base=0x60b080;language=0x615f00
    # The English composition inherits the native Japanese upper allocation.
    # The inherited allocation predates the separate authored English tables.
    root=struct.unpack_from('<I',data,language-base)[0]-base
    require(0<=root<=len(data)-789*2,'Original complete Japanese ending directory extent')
    offsets=struct.unpack_from('<789H',data,root)
    require(offsets[0]==789*2 and list(offsets)==sorted(set(offsets))and root+offsets[-1]<len(data),'Original ending directory grammar')
    blob=bytearray(20);sizes=[]
    for i,index in enumerate(range(639,649)):
        record=data[root+offsets[index]:root+offsets[index+1]];logical=packed_record(record)
        require(len(record)-len(logical)<=3 and not any(record[len(logical):]),'Complete original packed caption trailing bytes')
        struct.pack_into('>H',blob,i*2,639*2+len(blob));blob.extend(record);sizes.append(len(record))
    padding=len(blob)%2;blob.extend(bytes(padding))
    require(len(blob)==288 and padding==1,'Complete Evil caption allocation and original alignment')
    if region=='us':
        erase=recipe['erase'];require(erase['runs']==[[0xbc8060,138],[0xbc80fa,113]],'Reviewed complete Evil caption erasure scope')
        prior=b''.join(blob[at-0xbc804c:at-0xbc804c+n]for at,n in erase['runs'])
        require(len(prior)==251 and hashlib.sha256(prior).hexdigest()==erase['before_sha256'],'Whole authored erased-payload preimage')
        for at,n in erase['runs']:blob[at-0xbc804c:at-0xbc804c+n]=b'\xff'*n
    else:require(recipe['erase']is None,'JP caption records are retained')
    return [(0xbc804c,bytes(blob))],{'bytes':288,'records':10,'source_indices':[639,648],'source_language':'Canonical Japanese directory inherited by both displays',
        'record_bytes':sizes,'alignment_zero_bytes':padding,'authored_erased_bytes':251 if region=='us'else 0}
