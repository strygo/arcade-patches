"""Complete retained Guile primary directory, frames and independently checked cel art."""
import struct
from public_kit_actor import Data
from public_kit_graphics import require
import public_kit_frame_resources as frames

ROOT=0xbad0bc
HELD=set(range(10,15))


def targets(data,bank):
    original=data.root(data.u32(bank))[1]
    require(len(original)>=66,'Original primary action extent')
    result=list(original[:66])
    # Batch23 preserves the reviewed action15 fallback: skip its uninstalled
    # opening cel and enter that action's own loop frame.
    start=result[15];loop=data.frame(start)[2]
    require(loop==start+20 and data.frame(loop)[2]==loop,'Original action15 opening/loop grammar')
    result[15]=loop
    return result


def construct(inputs,recipe,native_pixels):
    data=Data(inputs['comp2'],recipe['base'],inputs['coords'],0xb04000)
    bank=data.u32(recipe['owner_table']+32*4);original=targets(data,bank)
    require(len(recipe['native_targets'])==66,'Complete native primary directory extent')
    mapping={(source,destination) for owner,source,destination,_,_ in recipe['frames'] if owner==32}
    offsets=[]
    for index,native in enumerate(recipe['native_targets']):
        if index in HELD:
            require(native is None,'Held remapped primary action unexpectedly populated');offsets.append(0)
        else:
            require(native is not None and (original[index],native) in mapping,'Primary action lacks complete original frame graph')
            require(-32768<=native-ROOT<32768,'Primary root signed reach');offsets.append(native-ROOT)
    writes=frames.construct(inputs,recipe,native_pixels)
    writes.append((ROOT,struct.pack('>66h',*offsets)))
    return writes
