"""Complete retained Cody normal frames, extended directory and ISM bank.

Original arcade frame fields/cel pointers are retained and explicit successors
relocated. Added PS2 actions bind only their allocated entry pointers here;
their frames and all artwork remain separately qualified resources.
"""
import hashlib
import struct
from public_kit_actor import Data
from public_kit_graphics import require

START,END,ROOT,BANK=0xad8622,0xad97fa,0xad998a,0xad99ee


def u32(blob,at):
    require(0<=at<=len(blob)-4,'Original native pointer bounds')
    return struct.unpack_from('>I',blob,at)[0]


def domain(arcade):
    bank=u32(arcade,0xde6a0+27*4);roots=[u32(arcade,bank+i*4) for i in range(12)]
    require(roots[3]==roots[7]==roots[11],'Original Cody normal ISM aliases')
    source=roots[3];targets=[]
    for i in range(48):
        require(0<=source+i*2<=len(arcade)-2,'Original Cody directory bounds')
        delta=struct.unpack_from('>h',arcade,source+i*2)[0]
        if not delta:break
        targets.append(source+delta)
    require(len(targets)==47 and not delta,'Complete original Cody47 normal directory extent')
    records={};families=[]
    for target in targets:
        at=target;seen=[]
        while at is not None and at not in seen:
            require(0<=at<=len(arcade)-20,'Original Cody frame bounds')
            seen.append(at);flags=arcade[at+1];length=24 if flags&128 else 20
            require(at+length<=len(arcade),'Original Cody successor extent')
            records[at]=arcade[at:at+length]
            at=u32(arcade,at+20) if flags&128 else None if flags&64 else at+20
            require(len(seen)<2048,'Bounded original Cody graph')
        families.append(seen)
    require(len(records)==227,'Complete original Cody frame count')
    return source,targets,dict(sorted(records.items())),roots


def construct(inputs,recipe):
    for name,pin in recipe['inputs'].items():
        value=inputs[name]
        require(len(value)==pin['bytes'] and hashlib.sha256(value).hexdigest()==pin['sha256'],'Original Cody '+name+' identity')
    source,targets,records,roots=domain(inputs['arcade'])
    mapping={};cursor=START
    for at,value in records.items():mapping[at]=cursor;cursor+=len(value)
    require(cursor==END,'Complete retained Cody graph allocation extent')
    payload=bytearray();links=0
    for at,record in records.items():
        value=bytearray(record)
        if value[1]&128:
            target=u32(value,20);require(target in mapping,'Original Cody link leaves complete graph')
            struct.pack_into('>I',value,20,mapping[target]);links+=1
        elif not value[1]&64:require(mapping[at+20]==mapping[at]+20,'Cody fallthrough relocation')
        payload.extend(value)
    data=Data(inputs['comp2'],recipe['base'],b'',0xb04000)
    sbank=data.u32(recipe['owner_table']+27*4);sroots=struct.unpack('<12I',data.read(sbank,48))
    require(sroots[3]==sroots[7]==sroots[11],'PS2 Cody normal ISM aliases')
    extra=data.root(sroots[3])[1];require(len(extra)==49,'Complete PS2 Cody49 directory extent')
    additions=dict(recipe['added_entries'])
    require(len(additions)==2 and set(additions)==set(extra[47:]),'Cody added original action entries')
    require(all(END<=at<ROOT and (at-END)%20==0 for at in additions.values()),'Added Cody frame allocation bounds')
    destinations=[mapping[t] for t in targets]+[additions[t] for t in extra[47:]]
    offsets=[at-ROOT for at in destinations];require(all(-32768<=v<0 for v in offsets),'Cody signed root reach')
    for index in (3,7,11):roots[index]=ROOT
    return [(START,bytes(payload)),(ROOT,struct.pack('>50h',*offsets,0)),(BANK,struct.pack('>12I',*roots))],{
        'retained_actions':47,'added_action_entries':2,'complete_frames':len(records),
        'relocated_successors':links,'frame_bytes':len(payload),'directory_bytes':148,
        'qualification':'Complete retained frames and full directory/bank; added47/48 frame fields and artwork separate'}
