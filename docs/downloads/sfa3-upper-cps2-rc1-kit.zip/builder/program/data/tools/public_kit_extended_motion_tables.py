"""Complete retained35/37/38-owner native movement-table generations."""
import struct
import public_kit_motion_tables as initial
from public_kit_graphics import require


def construct(inputs,recipe):
    _,controls=initial.construct(inputs,recipe)
    region=recipe['region'];base=0x60b080 if region=='jp'else 0x60ad00
    expected={row[0] for row in initial.ROWS};writes=[]
    require(set(recipe['tables'])=={'35','37','38'},'Complete movement-table generation census')
    for count in (35,37,38):
        bindings=recipe['tables'][str(count)];require(set(bindings)==expected,'All ten original movement tables')
        lower={35:0xbd0000,37:0xc20000,38:0xc70000}[count]
        for role,_,native,stride,usa,jp,*_ in initial.ROWS:
            address=bindings[role];require(lower<=address<=lower+0x3000-count*stride,'Original movement allocation binding')
            native+=0x128e;prefix=inputs['arcade'][native:native+32*stride]
            at=(jp if region=='jp'else usa)-base
            if role in ('parameter_2cd','parameter_24c'):
                prefix=bytearray(prefix);prefix[23]=inputs['comp2'][at+23];prefix=bytes(prefix)
            source=inputs['comp2'][at+32*stride:at+count*stride]
            require(len(source)==(count-32)*stride,'Original extended-owner movement rows')
            unit=1 if stride==1 else 2 if stride==2 else 4
            converted=b''.join(source[n:n+unit][::-1]for n in range(0,len(source),unit))
            writes.append((address,prefix+converted))
    require(len(writes)==30,'Complete thirty movement arrays')
    return writes,{'table_generations':[35,37,38],'tables':30,'native_control_rows':controls['native_control_rows'],'original_reader_functions':controls['original_reader_functions'],'bytes':sum(len(blob)for _,blob in writes)}
