"""Complete original Evil Ryu ending portrait and its native frame/cel geometry."""
import hashlib,struct
from public_kit_graphics import require
from public_kit_hover_objects import cel,tiles_for

def original(comp2,region):
    base=0x60ad00 if region=='us' else 0x60b080
    heads=0x69f00 if region=='us' else 0x6ae30
    at=heads+struct.unpack_from('<H',comp2,heads+28)[0]+23*8
    pointer=struct.unpack_from('<I',comp2,at+4)[0]
    return comp2[at:at+4],cel(comp2,pointer-base,'<',base)

def construct(inputs,recipe,pixels):
    require(set(inputs)==set(recipe['inputs'])=={'comp2','font'},'Complete Evil portrait input set')
    for name,pin in recipe['inputs'].items():
        require(len(inputs[name])==pin['bytes'] and hashlib.sha256(inputs[name]).hexdigest()==pin['sha256'],'Original Evil portrait source '+name)
    require(recipe['region'] in ('us','jp'),'Original regional portrait')
    header,value=original(inputs['comp2'],recipe['region']);commands=list(tiles_for(value['commands']))
    require(value['total']==len(commands)==140 and len(recipe['tiles'])==140,'Complete140-tile original Evil portrait')
    coords=bytearray();body=bytearray(struct.pack('>3HI',2,140,139,0xbc8618))
    for target,(source,attr,x,y) in zip(recipe['tiles'],commands):
        require(0<=target<65536,'Evil portrait tile bank extent')
        image=inputs['font'][(source+0x1c00)*128:(source+0x1c01)*128]
        physical=target+0x50000
        require(len(image)==128 and pixels[physical*128:(physical+1)*128]==image,'Complete original Evil portrait artwork')
        coords.extend(struct.pack('>2h',x,y));body.extend(struct.pack('>2H',target,attr))
    require(len(coords)==560 and len(body)==570,'Whole Evil portrait descriptor extents')
    return [(0xbc8618,bytes(coords)),(0xbc8848,bytes(body)),(0xbc8b46,header+struct.pack('>I',0xbc8848))],{'frames':1,'cels':1,'checked_tiles':140,'bytes':1138}
