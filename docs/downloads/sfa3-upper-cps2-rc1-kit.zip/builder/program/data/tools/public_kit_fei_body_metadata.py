"""Retained Fei body prefixes, closed root and complete 34-owner word tables."""
import hashlib
import struct
from public_kit_graphics import require


def construct(inputs, recipe):
    require(set(inputs)==set(recipe['inputs'])=={'arcade','key','comp2'}, 'Fei metadata original input domain')
    for name,blob in inputs.items():
        pin=recipe['inputs'][name]
        require(len(blob)==pin['bytes'] and hashlib.sha256(blob).hexdigest()==pin['sha256'], 'Original Fei metadata identity '+name)
    require(recipe['closed_root']=={'address':0xb09920,'bytes':512,'consumer_bank':0xb09b20,'slots':[1,2,3,5,6,7,9,10,11]}, 'Exact original closed-root allocation and twelve-slot producer')
    c2=inputs['comp2'];jp=recipe['region']=='jp';base=0x60b080 if jp else 0x60ad00
    def read(at,n):
        offset=at-base
        require(0<=offset<=len(c2)-n,'Original Fei metadata source bounds')
        return c2[offset:offset+n]
    def u32(at):return struct.unpack('<I',read(at,4))[0]
    bank=u32((0x74ef38 if jp else 0x749838)+33*4)
    roots=struct.unpack('<12I',read(bank,48))
    require(roots[0]==roots[4]==roots[8], 'Original shared Fei normal root')
    root=roots[0];targets=[]
    for i in range(256):
        relative=struct.unpack('<h',read(root+i*2,2))[0]
        if relative==0:break
        targets.append(root+relative)
    else:raise ValueError('Unbounded original Fei normal root')
    require(len(targets)>20,'Complete original first21 body actions')
    frames={}
    for at in targets[:21]:
        while at is not None and at not in frames:
            require(len(frames)<2048 and at%4==0,'Original Fei frame graph bounds')
            raw=read(at,20);require(raw[1]&63==0,'Unknown original Fei frame flags')
            frames[at]=raw
            at=u32(at+20) if raw[1]&128 else None if raw[1]&64 else at+20
    require(len(frames)==75,'Complete original Fei first21 graph extent')
    count_index=max(raw[8] for raw in frames.values())+1
    count_event=max(raw[10] for raw in frames.values())+1
    require((count_index,count_event)==(4,2),'Original body selector/event prefix extent')
    selectors=read(u32((0x74ead8 if jp else 0x7493d8)+33*4),count_index*4)
    events=read(u32((0x74eb78 if jp else 0x749478)+33*4),count_event*4)
    require(all(events[i:i+2]==b'\0\0' for i in range(0,len(events),4)), 'Original body event callback grammar')
    native=inputs['arcade']
    from cps2_crypt import decrypt_rom
    ops=decrypt_rom(native[:0x100000],inputs['key'])[0]
    require(ops[0x2fc88:0x2fc8e]==bytes.fromhex('4880d0403d7b'), 'Original native sprite-bank PC-relative consumer')
    writes=[(0xb08448,selectors),(0xb08458,events),(0xb09920,bytes(512)),
            (0xb09bd8,native[0x32c094:0x32c0d4]+bytes(4)),
            (0xb09c1c,ops[0x2fc94:0x2fcd4]+bytes(4))]
    require(sum(len(b) for _,b in writes)==672,'Complete retained metadata family extent')
    return writes,{'bytes':672,'frames':len(frames),'actions':21,'selector_rows':count_index,'event_rows':count_event,
                   'closed_action_bytes':512,'word_tables':2,'owners_per_word_table':34,'source_bank':bank}
