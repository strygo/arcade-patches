"""Complete retained Fei body owner directories and initial ISM root banks."""
import hashlib,struct
from public_kit_graphics import require


def construct(inputs,recipe):
    require(set(inputs)==set(recipe['inputs'])=={'arcade'},'Complete original Fei directory input domain')
    pin=recipe['inputs']['arcade'];raw=inputs['arcade']
    require(len(raw)==pin['bytes']==0x400000 and hashlib.sha256(raw).hexdigest()==pin['sha256'],'Canonical original Fei directory source')
    def read(at,size):
        require(0<=at<=len(raw)-size,'Original native directory extent');return raw[at:at+size]
    primary=[]
    for owner in range(32):
        pointer=0x32c094+struct.unpack('>H',read(0x32c094+owner*2,2))[0]
        require(pointer%2==0 and pointer<=len(raw)-960,'Original six-color palette domain')
        if owner in (18,20):pointer=0x3df000+(960 if owner==20 else 0)
        primary.append(pointer)
    primary.extend((0x3fa000,0xb08000))
    writes=[(0xb083c0,struct.pack('>34I',*primary)),
            (0xb09770,struct.pack('>3I',0xb08460,0xb08aba,0xb09114)),
            (0xb0977c,struct.pack('>3I',*([0xa111b4]*3)))]
    for source,destination,guile,fei in ((0xde320,0xb09788,0xa11000,0xb70000),(0xde3a0,0xb09810,0xa12400,0xb9b000),
                                      (0xde2a0,0xb09898,0xb0977c,0xb714d0),(0xde6a0,0xb09b50,0xa12600,0xb714dc)):
        original=read(source,128);pointers=struct.unpack('>32I',original)
        require(all(0<p<len(raw) and p%2==0 for p in pointers),'Complete native32-owner pointer directory')
        # The original loop producer replaces owner33's four pointers; Shien
        # extends Fei's event table at B9B000. Batch8
        # redirects Sakura's selector pointer to its complete copied table.
        if source==0xde320:
            original=bytearray(original);struct.pack_into('>I',original,13*4,0xaa52d0)
        writes.append((destination,bytes(original)+struct.pack('>2I',guile,fei)))
    writes.append((0xb09b20,struct.pack('>12I',*(0xa0ebee if slot%4==0 else 0xb09920 for slot in range(12)))))
    return writes,{'owner_tables':5,'owners_per_table':34,'variant_banks':2,'ism_root_bank_words':12,'bytes':752}
