"""Project complete original action-bank variants onto final native root allocations."""
import hashlib
import struct
from public_kit_graphics import require

# Final allocator identities: primary redirect, receiving, secondary, normals.
GUILE_ROOTS=(0xbad0bc,0xa25000,0xa12740,0xa0d426)


def construct(comp2,recipe):
    pin=recipe['input']
    require(len(comp2)==pin['bytes'] and hashlib.sha256(comp2).hexdigest()==pin['sha256'],
            'Action bank original input identity')
    base,bank=recipe['base'],recipe['source_bank']
    require(0<=bank-base<=len(comp2)-48,'Original three-ISM action bank bounds')
    source=struct.unpack_from('<12I',comp2,bank-base)
    require(len(set(source[:4]))==4 and source==source[:4]*3,'Complete original three-ISM four-root bank')
    require(list(source[:4])==recipe['source_roots'],'Original action role ordering differs')
    for root in source[:4]:
        require(0<=root-base<=len(comp2)-2,'Original action root outside source')
        terminated=False
        for index in range(256):
            at=root-base+index*2
            require(at+2<=len(comp2),'Truncated original action root directory')
            offset=struct.unpack_from('<h',comp2,at)[0]
            if not offset:
                require(index>0,'Empty original action root directory')
                terminated=True;break
            require(0<=root+offset-base<=len(comp2)-20,'Original action target outside source')
        require(terminated,'Unbounded original action root directory')
    mapping=dict(zip(source[:4],GUILE_ROOTS))
    # The native original-action adapter reserves a full 256-byte silent voice view.
    bank_blob=struct.pack('>12I',*(mapping[root] for root in source))+bytes(256)
    return [(0xa12600,bank_blob)],{'variants':3,'roots_per_variant':4,'zero_voice_bytes':256,'verified_bytes':len(bank_blob)}
