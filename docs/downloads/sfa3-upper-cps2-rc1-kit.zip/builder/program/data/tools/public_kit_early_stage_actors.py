"""Original Guile and Fei stage actor siblings through the same typed projection."""
from types import FunctionType
import public_kit_stage_actors as shared

FAMILIES={32:(0xa73f00,34,18,9),33:(0xbf7f00,133,32,9)}
Data=shared.Data
_scope=dict(vars(shared),FAMILIES=FAMILIES)
graph=FunctionType(shared.graph.__code__,_scope)
_scope['graph']=graph
construct=FunctionType(shared.construct.__code__,_scope)
_scope['construct']=construct
main=FunctionType(shared.main.__code__,_scope)

if __name__=='__main__':main()
