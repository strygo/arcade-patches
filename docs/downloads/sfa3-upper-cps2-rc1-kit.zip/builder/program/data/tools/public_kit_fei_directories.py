"""Complete retained Fei action directories through every native allocation stage."""
import hashlib
import struct
from public_kit_actor import Data
from public_kit_graphics import require

INITIAL=(('primary',0,0xa0ffa8,70),('normal_shared_ism',7,0xa10036,33),('normal_first_ism',3,0xa1007a,33),('receiving',1,0xa100be,48))
STAGES=(('throws',0xa105c8,tuple(range(48,54))),('specials',0xa10f38,tuple(range(9,24))),
        ('shien',0xb97088,tuple(range(9))),('rekka',0xb97a3c,tuple(range(24,36))),
        ('remaining',0xb98558,tuple(range(36,48))+tuple(range(60,66))),('basic',0xb98a00,tuple(range(54,60))))


def construct(comp2,recipe):
    pin=recipe['input'];require(len(comp2)==pin['bytes'] and hashlib.sha256(comp2).hexdigest()==pin['sha256'],'Original Fei source identity')
    data=Data(comp2,recipe['base'],b'',0xb04000)
    banks=struct.unpack('<12I',data.read(data.u32(recipe['owner_table']+33*4),48))
    require([r['name']for r in recipe['groups']]==[r[0]for r in INITIAL]+['remaining','basic'],'Complete retained Fei directory inventory')
    writes=[];admitted=set();summary=[]
    specs=[]
    for name,index,address,count in INITIAL:specs.append((name,index,address,set(range(count)),count,True))
    for name,address,actions in STAGES:
        admitted.update(actions)
        if name in ('remaining','basic'):specs.append((name,2,address,set(admitted),68,False))
    for row,(name,index,address,allowed,count,terminal)in zip(recipe['groups'],specs):
        targets=data.root(banks[index])[1];require(len(targets)==count,'Complete original Fei action extent')
        allocations={s:n for s,n in row['frames']}
        require(len(allocations)==len(row['frames']) and set(allocations)=={targets[n]for n in allowed},'Fei root complete admitted source target inventory')
        offsets=[]
        for index,source in enumerate(targets):
            if index not in allowed:offsets.append(0);continue
            native=allocations[source]
            require(0xa00000<=native<0xc00000 and native%2==0,'Fei frame allocation bounds')
            offset=native-address;require(-32768<=offset<=32767 and offset,'Fei directory signed relative reach')
            offsets.append(offset)
        if terminal:offsets.append(0)
        writes.append((address,struct.pack('>'+str(len(offsets))+'h',*offsets)))
        summary.append({'name':name,'entries':count,'admitted':len(allowed),'terminator':terminal})
    # The last stage redirects family2 while retaining the original ISM roots.
    roots={banks[index]:address for _,index,address,_ in INITIAL};roots[banks[2]]=STAGES[-1][1]
    require(set(banks)==set(roots),'Fei final root bank family inventory')
    writes.append((0xb714dc,struct.pack('>12I',*(roots[root]for root in banks))))
    # Explicit original closed-action and silent-voice reservations are retained.
    writes.extend(((0xa10120,bytes(512)),(0xb7150c,bytes(512))))
    return writes,{'complete_directories':summary,'root_bank_bytes':48,'closed_reservation_bytes':1024,
                   'qualification':'Complete tables; referenced frames and artwork remain separately qualified'}
