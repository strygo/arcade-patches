"""Complete original six-color palette arena and native secondary relocations."""
import hashlib,struct
from public_kit_graphics import require


def resources(comp2,native,region):
    require(region in ('us','jp') and len(native)==0x400000,'Color arena source domain')
    base=0x60b080 if region=='jp' else 0x60ad00;delta=0x5380 if region=='jp' else 0
    def read(at,n):
        require(n>0 and 0<=at<=len(comp2)-n,'Original color arena bounds')
        return comp2[at:at+n]
    def u16(at):return struct.unpack('<H',read(at,2))[0]
    def n16(at):return struct.unpack_from('>H',native,at)[0]
    data=bytearray();seen={};reports=[];writes=[]
    def add(blob):
        if blob not in seen:seen[blob]=0x3e0000+len(data);data.extend(blob)
        return seen[blob]
    def colors(group,owner,source,size):
        raw=read(source,size);blob=b''.join(raw[n:n+2][::-1] for n in range(0,len(raw),2));at=add(blob)
        reports.append({'family':group,'owner':owner,'source':source,'native':at,'bytes':size});return at
    effects=0xf5840+delta;special=0x117380+delta;secondary=0x1210f0+delta;ep=[];pp=[]
    for owner in range(32):
        source=effects+u16(effects+owner*2);target=0x3329d4+n16(0x3329d4+owner*2)
        pp.append(colors('prefix',owner,source-192,192))
        if owner in (18,20):target=colors('shared_effect',owner,source,1184 if owner==20 else 768)
        ep.append(target)
    sp=struct.unpack('<40H',read(special,80));np=struct.unpack_from('>32H',native,0x34a7b4);special_ptr=[]
    for owner in range(32):
        size=min([v-sp[owner] for v in set(sp) if v>sp[owner]]or[1952]);oldsize=min([v-np[owner] for v in set(np) if v>np[owner]]or[1952]);target=0x34a7b4+np[owner]
        if size!=oldsize:target=colors('character_effect',owner,special+sp[owner],size)
        special_ptr.append(target)
    for owner in (20,21,30,31):
        source=struct.unpack('<I',read(secondary+owner*4,4))[0]-base;at=colors('secondary',owner,source,1536)
        writes.append((0x351f14+owner*4,struct.pack('>I',at)))
    for group,values in (('effects_directory',ep),('prefix_directory',pp),('special_directory',special_ptr)):
        add(struct.pack('>32I',*values))
    require(0<len(data)<=0x10000,'Complete color arena reservation')
    writes.insert(0,(0x3e0000,bytes(data)))
    return writes,reports


def construct(comp2,native,recipe):
    require(recipe['schema']==1 and hashlib.sha256(comp2).hexdigest()==recipe['source_sha256'] and hashlib.sha256(native).hexdigest()==recipe['native_sha256'],'Color arena input identities')
    return resources(comp2,native,recipe['region'])


def main():
    import argparse,json
    from pathlib import Path
    p=argparse.ArgumentParser(description=__doc__)
    for n in ('comp2','native','recipe','outdir'):p.add_argument('--'+n,type=Path,required=True)
    a=p.parse_args();writes,_=construct(a.comp2.read_bytes(),a.native.read_bytes(),json.loads(a.recipe.read_text()));data=bytearray(0x400000);mask=bytearray(len(data))
    for at,blob in writes:
        require(not any(mask[at:at+len(blob)]),'Color arena overlap');data[at:at+len(blob)]=blob;mask[at:at+len(blob)]=b'\1'*len(blob)
    a.outdir.mkdir(exist_ok=True);(a.outdir/'result.bin').write_bytes(data);(a.outdir/'result.mask').write_bytes(mask)


if __name__=='__main__':main()
