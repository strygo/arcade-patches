"""Complete retained cancel-window directories through four original owner generations."""
import hashlib
import struct
from public_kit_graphics import require


def construct(inputs,recipe):
    require(set(inputs)=={'arcade'},'Canonical original cancel source only')
    raw=inputs['arcade'];pin=recipe['inputs']['arcade']
    require(len(raw)==pin['bytes']==0x400000 and hashlib.sha256(raw).hexdigest()==pin['sha256'],'Original cancel image identity')
    root=recipe['native_root'];require(type(root)is int and 0xd0000<=root<=0xe4000-128,'Native cancel directory extent')
    prefix=raw[root:root+128]
    require(hashlib.sha256(prefix).hexdigest()==recipe['native_sha256'],'Whole native32-owner cancel prefix')
    values=list(struct.unpack('>32I',prefix));added=recipe['added']
    require(set(added)=={'32','33','34','35'} and all(type(v)is int and v%2==0 and 0xa00000<=v<0xe00000 for v in added.values()),'Four source-bound complete cancel entrypoints')
    require(set(recipe['tables'])=={'34','35','37','38'},'Complete current cancel generations')
    final=recipe['final_allocations']
    require(set(final)=={'21','26','27'} and final['21']==0xc75c80 and final['26']==0xa88100 and type(final['27'])is int and final['27']%2==0 and 0xad8100<=final['27']<=0xadb100-202,'Three original resident cancel relocations')
    writes=[]
    for count in (34,35,37,38):
        target=recipe['tables'][str(count)]
        require(type(target)is int and target%4==0 and 0xb70000<=target<=0xc74000-count*4,'Whole cancel directory allocation')
        selected=values+[added['32'],added['33'],added['34'],added['35'],values[2],values[21]]
        if count==38:
            for owner,pointer in final.items():selected[int(owner)]=pointer
        writes.append((target,struct.pack('>'+str(count)+'I',*selected[:count])))
    return writes,{'native_owners':32,'generations':[34,35,37,38],'bytes':576,'window_resources_separately_qualified':True}
