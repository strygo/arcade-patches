"""Original Akuma ending action66 complete self-loop frame, cel and root cell."""
import hashlib,struct
from public_kit_actor import Data
from public_kit_blocks import grid_code
from public_kit_graphics import require,tile_variants
from public_kit_shin_frames import compare_canvas

def source(inputs,region):
    at=0x3fe4ec+(0x70 if region=='jp' else 0)-0x1f0040
    hi,lo=struct.unpack_from('<2I',inputs['comp1'],at)
    require(hi>>26==15 and lo>>26==9 and (hi>>16)&31==(lo>>21)&31==(lo>>16)&31,'Original ending owner root reader')
    immediate=lo&65535;immediate-=65536 if immediate&32768 else 0
    table=((hi&65535)*65536+immediate)&0xffffffff
    data=Data(inputs['comp2'],0x60ad00 if region=='us' else 0x60b080,inputs['coords'],0xb04000)
    root=data.u32(table+8);at=root+struct.unpack('<h',data.read(root+132,2))[0]
    header=data.read(at,24)
    require(header[:4]==bytes.fromhex('ff800000') and data.u32(at+20)==at,'Complete original Akuma66 self-loop')
    _,blocks=data.cel(data.u32(at+4))
    return header,tuple((x,y,w&65535,w>>16)for x,y,w in blocks)

def construct(inputs,recipe,pixels):
    require(set(inputs)==set(recipe['inputs'])=={'comp1','comp2','coords','pixels','mask'},'Complete original Akuma ending inputs')
    for name,pin in recipe['inputs'].items():
        require(len(inputs[name])==pin['bytes'] and hashlib.sha256(inputs[name]).hexdigest()==pin['sha256'],'Original Akuma input '+name)
    require(recipe['region'] in ('us','jp'),'Original regional Akuma pose')
    header,blocks=source(inputs,recipe['region']);native=pixels[:8<<20]
    lookup={native[n:n+128]:n//128 for n in range(0,len(native),128)};mapping={};converted=[]
    for x,y,t,a in blocks:
        width,height=(a>>8&15)+1,(a>>12&15)+1
        for dy in range(height):
            for dx in range(width):
                code=grid_code(t,width-1-dx if a&32 else dx,height-1-dy if a&64 else dy)
                require(code<len(inputs['mask']) and inputs['mask'][code],'Original Akuma tile presence')
                if code not in mapping:
                    variants=tile_variants(inputs['pixels'][code*128:(code+1)*128])
                    match=next(((lookup[v],flip*32)for flip,v in enumerate(variants)if v in lookup),None)
                    require(match is not None,'Native artwork for whole original Akuma pose');mapping[code]=match
                tile,flip=mapping[code];converted.append((x+dx*16,y+dy*16,tile,(a&255)^flip))
    require(len(converted)==len(mapping)==16,'Whole original Akuma ending cel extent')
    checked=compare_canvas(blocks,converted,inputs['pixels'],native,inputs['mask'])
    frame=bytearray(header);struct.pack_into('>I',frame,4,0xbc8ba6);struct.pack_into('>I',frame,20,0xbc8b4e)
    coords=b''.join(struct.pack('>2h',x,y)for x,y,_,_ in converted)
    cel=struct.pack('>3HI',2,16,15,0xbc8b66)+b''.join(struct.pack('>2H',t,a)for _,_,t,a in converted)
    return [(0xbc8b4e,bytes(frame)),(0xbc8b66,coords),(0xbc8ba6,cel),(0xbc8bf0,struct.pack('>h',0xbc8b4e-0xbc8b6c))],{'frames':1,'cels':1,'tiles':16,'canvas_pixels_checked':checked,'bytes':164}
