"""Complete original Cammy/Dolls collision base before separately qualified corrections.

The original static sweep projects only unanimous PS2 attack-field demands.
An unmatched action taints its complete native attack row. All three owners,
three ISMs and four action families participate in the complete source census.
No final-game bytes, XOR corrections or appended attack records are read here.
"""
import hashlib
import struct
from public_kit_dhalsim_tables import Owner
from public_kit_graphics import require


def project(native,start,demands,tainted):
    """Keep conflicted, unobserved and unmatched-row fields at native values."""
    result=bytearray(native)
    for address,values in demands.items():
        if start<=address<start+len(result) and address not in tainted and len(values)==1:
            result[address-start]=next(iter(values))
    return bytes(result)


def construct(arcade,comp2,region):
    """Bind the complete native shared bank and original unanimous sweep."""
    require(region in ('us','jp'),'Original PS2 region required')
    require(len(arcade)==4*1024*1024,'Complete canonical native main region required')
    c2=comp2
    base=0x60b080 if region=='jp'else 0x60ad00;shift=0x5700 if region=='jp'else 0
    u=lambda at:struct.unpack_from('>I',arcade,at)[0]
    s=lambda at:struct.unpack_from('<I',c2,at-base)[0]
    demands={};tainted=set();banks=[];maximum=-1;uses=0
    for owner in (22,30,31):
        choices=[u(u(0xde2a0+owner*4)+i*4)for i in range(3)];banks.extend(choices)
        native=Owner(arcade,0,u(0xde6a0+owner*4),u(0xde320+owner*4),u(0xde3a0+owner*4),choices,'>')
        source=Owner(c2,base,s(0x749838+shift+owner*4),s(0x7493d8+shift+owner*4),s(0x749478+shift+owner*4),[s(s(0x749338+shift+owner*4)+i*4)for i in range(3)],'<')
        for slot,family in enumerate(native.families):
            for action,(frames,loop)in enumerate(family):
                sf=source.families[slot];matched=action<len(sf)and len(sf[action][0])==len(frames)and sf[action][1]==loop
                for ordinal,at in enumerate(frames):
                    uses+=1;maximum=max(maximum,arcade[at+9]);address=native.values(at,slot//4)['attack_at']
                    if not matched:tainted.update(range(address,address+32));continue
                    wanted=source.values(sf[action][0][ordinal],slot//4)['attack']
                    for i,value in enumerate(wanted):demands.setdefault(address+i,set()).add(value)
    require(set(banks)=={0x12ed1a}and maximum==198,'Complete native Dolls bank and attack domain')
    aliases={o for o in range(32)if any(u(u(0xde2a0+o*4)+i*4)==banks[0]for i in range(3))}
    require(aliases=={22,30,31},'Every shared native owner is modeled')
    at=banks[0];size=struct.unpack_from('>5h',arcade,at)[4]+(maximum+1)*32
    require(size==8130 and uses==13659,'Complete original199-row bank and13659 frame-use domain')
    offsets=struct.unpack_from('>5h',arcade,at)
    require(offsets[0]==10 and all(a<=b and (b-a)%8==0 for a,b in zip(offsets,offsets[1:])),'Complete native collision lane grammar')
    native=arcade[at:at+size]
    projected=project(native,at,demands,tainted)
    return projected,{'bytes':size,'native_owners':[22,30,31],'attack_rows':maximum+1,
                      'frame_uses':uses,'native_sha256':hashlib.sha256(native).hexdigest(),
                      'projected_sha256':hashlib.sha256(projected).hexdigest(),
                      'projected_fields':sum(a!=b for a,b in zip(native,projected)),
                      'corrections_applied':False,'appended_attack_rows_included':False}


def self_test():
    original=bytes((10,20,30,40))
    demands={99:{0},100:{11},101:{21,22},102:{31},104:{0}}
    require(project(original,100,demands,{102})==bytes((11,20,30,40)),
            'Unanimous projection must retain conflicts, taints, absent demands and bounds')
    require(project(original,100,demands,{100,102})==original,
            'A newly unmatched shared context must prevent an otherwise unanimous edit')
    return {'passed':True,'controls':['unanimous','conflicting','tainted','unobserved','outside-resource']}


if __name__=='__main__':
    import argparse,json
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--self-test',action='store_true',required=True)
    parser.parse_args();print(json.dumps(self_test()))
