"""Rebuild five complete retained human/CPU callback directory pairs."""
import hashlib
import struct


def require(value, message):
    if not value:
        raise ValueError(message)


def construct(inputs, recipe):
    digest = lambda b: hashlib.sha256(b).hexdigest()
    require(set(inputs) == set(recipe['inputs']) == {'arcade'}, 'Original source inventory')
    raw = inputs['arcade']; pin = recipe['inputs']['arcade']
    require(len(raw) == pin['bytes'] == 0x400000 and digest(raw) == pin['sha256'], 'Whole original JP program identity')
    addresses = (0xb950a0,0xb95128,0xb9c0f0,0xb9c178,0xb9c248,0xb9c2d0,0xb9e058,0xb9e0e0,0xbab08c,0xbab114)
    require(tuple(r['address'] for r in recipe['tables']) == addresses, 'Complete ten-table census')
    writes = []; proof = []
    for index, row in enumerate(recipe['tables']):
        at = (0xddea0,0xddf20)[index % 2]
        require(row['source'] == at and row['rows'] == 34 and row['bytes'] == 136, 'Original directory extent/view')
        body = bytearray(raw[at:at+128])
        require(digest(body) == row['source_sha256'], 'Whole original 32-owner directory')
        require(set(row['replacements']) == ({'23'} if index >= 8 else set()), 'Original variant replacement census')
        for owner, target in row['replacements'].items():
            require(body[23*4:24*4] == body[:4], 'Original variant callback baseline')
            require(type(target) is int and 0 <= target < 0x100000, 'Variant callback address')
            body[23*4:24*4] = struct.pack('>I',target)
        require(digest(body) == row['retained_prefix_sha256'], 'Relocation witness complete retained prefix')
        for target in (row['guile'],row['fei']):
            require(type(target) is int and 0 <= target < 0x100000, 'Authored callback address')
            body.extend(struct.pack('>I',target))
        require(len(body) == 136 and digest(body) == row['sha256'], 'Complete final callback directory')
        writes.append((row['address'],bytes(body)))
        proof.append({'address':row['address'],'bytes':136,'sha256':digest(body)})
    return writes, {'bytes':1360,'access_view':'expanded-data-big-endian-pointer32','complete_tables':proof}
