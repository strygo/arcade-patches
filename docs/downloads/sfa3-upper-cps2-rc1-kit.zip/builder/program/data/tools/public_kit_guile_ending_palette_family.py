"""Whole original Guile ending palette recipes, directories and color supplies."""
import hashlib
import struct
from public_kit_graphics import require
from public_kit_ending_palette_tables import inventory
from public_kit_palettes import catalog
from public_kit_resident_palettes import resources as residents
from public_kit_color_arena import resources as arena


def construct(inputs,recipe):
    require(set(inputs)==set(recipe['inputs'])=={'arcade','comp2'},'Guile ending palette source inventory')
    for name,blob in inputs.items():
        pin=recipe['inputs'][name]
        require(len(blob)==pin['bytes'] and hashlib.sha256(blob).hexdigest()==pin['sha256'],'Guile ending palette source identity')
    region=recipe['region'];require(region in ('us','jp'),'Guile palette region')
    native=inputs['arcade'];comp2=inputs['comp2'];base=0x60ad00 if region=='us' else 0x60b080
    ds=0 if region=='us' else 0x10f0;shift=0 if region=='us' else 0x5700
    def read(at,n):
        require(n>0 and base<=at<=base+len(comp2)-n,'Original Guile palette bounds')
        return comp2[at-base:at-base+n]
    def u32(at):return struct.unpack('<I',read(at,4))[0]
    def swap(b):return b''.join(b[i:i+2][::-1]for i in range(0,len(b),2))
    def graph(reader,address,budget,endian,families):
        rows=[];remain=budget
        for _ in range(64):
            fields=struct.unpack(endian+'4H',reader(address,8));family,slot,offset,count=fields
            require(family%4==0 and family<=72 and slot%(4 if family<=8 else 2)==0 and 0<count<=32,'Complete palette row grammar')
            table=struct.unpack(endian+'I',reader(families+family,4))[0]
            ptr=struct.unpack(endian+('I' if family<=8 else 'h'),reader(table+slot,4 if family<=8 else 2))[0]
            start=(ptr if family<=8 else table+ptr)+(offset-65536 if offset&32768 else offset)
            copied=min(count,remain);colors=reader(start,copied*32)
            rows.append((fields,start,swap(colors) if endian=='<' else colors));remain-=copied;address+=8
            if not remain:return rows
        raise ValueError('Unbounded complete Guile palette graph')
    root=u32(0x60b5a0+ds+128);at=u32(0x60b860+ds+128);demands=set();singles=[]
    require(at==u32(0x60b910+ds+128),'Original Guile ending modes')
    for _ in range(2048):
        timer,tag=struct.unpack('<2H',read(at,4));arity=tag&15
        vals=struct.unpack('<'+str(arity)+'H',read(at+4,arity*2)) if arity else ()
        group,opcode,kind=tag>>4&7,tag>>8&15,tag>>12
        if group==0 and opcode in (1,5) and not(opcode==5 and kind==15):
            selectors=vals[4:8] if opcode==1 else vals[1:5]
            require(len(selectors)==4,'Guile four-group request');demands.update(zip(selectors,(30,32,32,32)))
        if group==0 and opcode==9:
            require(len(vals)==4,'Guile single request');singles.append((vals[1],vals[3]))
        at+=4+arity*2
        if tag>>8==0 and tag&0x70==0:break
    else:raise ValueError('Unbounded Guile command demand')
    require(len(demands)==11 and singles==[(2,25),(2,25),(4,29),(5,8)],'Complete Guile original palette demand')
    context=bytearray(native)
    for provider in (residents,arena):
        for at,blob in provider(comp2,native,region)[0]:context[at:at+len(blob)]=blob
    colors=catalog(comp2,region)
    for name,at in (('primary:32',0x3fa000),('head:32',0x3daf00),('head:4',0x34da14)):
        blob=colors[name][1];context[at:at+len(blob)]=blob
    def native_read(at,n):
        require(0<=at<=len(context)-n,'Native Guile palette bounds');return bytes(context[at:at+n])
    typed=inventory(native);graphs={k:graph(read,u32(root+k[0]*4),k[1],'<',0x60b560+ds)for k in demands}
    result=bytearray(native[0x26ba4:0x26bbc]+bytes(12)+bytes(48));converted={}
    emitted=[];reused=[]
    for selector in sorted({s for s,_ in demands}):
        budget=max(b for s,b in demands if s==selector);rows=graphs[selector,budget]
        matches=[]
        for _,_,b,address,blob in typed:
            if b!=budget or blob!=b''.join(r[2]for r in rows):continue
            candidate=graph(lambda a,n:native[a:a+n],address,b,'>',0x26b70)
            if [r[0]for r in candidate]==[r[0]for r in rows]:matches.append(address)
        if matches:address=matches[0];reused.append(selector)
        else:
            address=0xa90000+len(result);emitted.append(selector)
            for fields,source,blob in rows:
                family,slot,offset,count=fields
                table=struct.unpack('>I',native_read(0x26b70+family,4))[0]
                ptr=struct.unpack('>I' if family<=8 else '>h',native_read(table+slot,4 if family<=8 else 2))[0]
                start=(ptr if family<=8 else table+ptr)+(offset-65536 if offset&32768 else offset)
                if not (0<=start<=len(context)-len(blob) and native_read(start,len(blob))==blob):
                    intervals=((0x70ba80+shift,1792,24),(0x6fe880+shift,64,28),(0x72aff0+shift,160,32))
                    choices=[(origin,slot2)for origin,n,slot2 in intervals if origin<=source and source+len(blob)<=origin+n]
                    require(len(choices)==1,'Bound original Guile color projection');origin,slot2=choices[0];fields=(4,slot2,source-origin,count)
                result.extend(struct.pack('>4H',*fields))
        converted[selector]=address;struct.pack_into('>I',result,36+selector*4,address)
    require(emitted==[0,1,3,4,6] and reused==[7,8,9,10,11] and len(result)==220,'Complete minimal Guile palette recipes')
    private=0xa90000+len(result);struct.pack_into('>3I',result,24,private,0x3fa140,0x3db000)
    result.extend(swap(read(0x70ba80+shift,1794)))
    extra=[(s,graph(read,u32(root+s*4),b,'<',0x60b560+ds))for s,b in ((2,25),(5,8))]
    missing_at=0xa90000+len(result)+sum(len(rows)*8 for _,rows in extra)
    for selector,rows in extra:
        struct.pack_into('>I',result,36+selector*4,0xa90000+len(result))
        for fields,source,blob in rows:
            family,slot,offset,count=fields
            table=struct.unpack('>I',native_read(0x26b70+family,4))[0]
            ptr=struct.unpack('>I' if family<=8 else '>h',native_read(table+slot,4 if family<=8 else 2))[0]
            start=(ptr if family<=8 else table+ptr)+(offset-65536 if offset&32768 else offset)
            if not (0<=start<=len(context)-len(blob) and native_read(start,len(blob))==blob):
                if 0x6fe880+shift<=source and source+len(blob)<=0x6fe9a0+shift:fields=(4,28,source-(0x6fe880+shift),count)
                elif 0x70ba80+shift<=source and source+len(blob)<=0x70c180+shift:fields=(4,24,source-(0x70ba80+shift),count)
                else:
                    require(selector==5 and source==0x737a90+shift and len(blob)==256,'Original Guile single private bank')
                    fields=(4,24,missing_at-private,count)
            result.extend(struct.pack('>4H',*fields))
    require(len(result)==2070,'Complete appended single palette recipes')
    result.extend(swap(read(0x737a90+shift,258)));require(len(result)==2328,'Complete Guile palette allocation')
    struct.pack_into('>I',context,0x26b74,0xa90000)
    def composed(at,n):return bytes(result[at-0xa90000:at-0xa90000+n]) if 0xa90000<=at<0xa90000+len(result) else native_read(at,n)
    for selector,budget in demands|set(singles):
        ptr=struct.unpack_from('>I',result,36+selector*4)[0]
        expected=graph(read,u32(root+selector*4),budget,'<',0x60b560+ds)
        actual=graph(composed,ptr,budget,'>',0x26b70)
        require(b''.join(r[2]for r in expected)==b''.join(r[2]for r in actual),'Complete original/composed Guile palette demand')
    return [(0xa90000,bytes(result))],{'bytes':2328,'four_group_requests':len(demands),'single_requests':len(singles),'emitted_selectors':emitted+[2,5],'reused_selectors':reused}
