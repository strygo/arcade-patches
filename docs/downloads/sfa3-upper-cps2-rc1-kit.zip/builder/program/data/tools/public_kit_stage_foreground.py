"""Complete original six-family added stage foreground frames and compact cels."""
import hashlib,struct
from public_kit_graphics import require
from public_kit_actor import Data
from public_kit_frame_resources import cel as emit_cel
from public_kit_shin_frames import native_cel,compare_canvas

ROOT=0x2f357a
# Reviewed numeric descriptor bindings from upper_english_stage_captions and
# upper_english_stage_captions2. Caption artwork belongs to its own producer.
CAPTION_OVERLAYS={0:(0x2fca96,0x3ffd00),3:(0x2fca96,0x3ffd16),6:(0x2fca96,0x3ffd00),9:(0x2fca96,0x3ffd00),
 2:(0xc63850,0x3ffd2c),5:(0xc63850,0x3ffd42),8:(0xc63850,0x3ffd2c),11:(0xc63850,0x3ffd2c),
 1:(0x2fcf62,0x3ffd58),4:(0x2fcf62,0x3ffd6e),7:(0x2fcf62,0x3ffd58),10:(0x2fcf62,0x3ffd58)}

def source(inputs,region):
    data=Data(inputs['comp2'],0x60b080 if region=='jp' else 0x60ad00,inputs['coords'],0xb04000)
    at=0x38dbc4+(0x70 if region=='jp' else 0)-0x1f0040
    hi,lo=struct.unpack_from('<2I',inputs['comp1'],at)
    require(hi>>26==15 and lo>>26==9 and (hi>>16)&31==(lo>>21)&31==(lo>>16)&31,'Original foreground table producer')
    immediate=lo&65535;table=((hi&65535)*65536+(immediate-65536 if immediate&32768 else immediate))&0xffffffff
    require(table=={'us':0x648bc8,'jp':0x649d38}[region],'Original foreground root identity')
    rows={}
    for selector in range(6):
        offset=struct.unpack('<h',data.read(table+selector*2,2))[0]
        for owner in range(35):
            address=table+offset+owner*8;head=data.read(address,4);pointer=data.u32(address+4);kind,commands=data.cel(pointer)
            require(kind in (0,2,18) and (owner<32 or kind==2 and head==bytes.fromhex('08400000')),'Original complete foreground grammar')
            rows[selector,owner]=(address,pointer,head,tuple((x,y,w&65535,w>>16)for x,y,w in commands))
    return data,rows

def construct(inputs,recipe,pixels):
    for name,pin in recipe['inputs'].items():require(hashlib.sha256(inputs[name]).hexdigest()==pin,'Original foreground input identity: '+name)
    require(hashlib.sha256(pixels).hexdigest()==recipe['pixels_sha256'],'Final foreground pixels identity')
    data,rows=source(inputs,recipe['region']);native=inputs['native'];root=recipe['root'];end=recipe['end'];writes=[];cels={}
    require(0xa00000<=root<root+156<=end<=0xe00000 and len(recipe['frames'])==18,'Complete foreground allocation')
    resident=set()
    for selector in range(6):
        offset=struct.unpack_from('>h',native,ROOT+selector*2)[0]
        for owner in range(32):resident.add(struct.unpack_from('>I',native,ROOT+offset+owner*8+4)[0])
    directory=bytearray(b''.join(struct.pack('>h',12+24*n)for n in range(6)));checked=0
    for index,(selector,owner) in enumerate((s,o)for s in range(6)for o in (32,33,34)):
        address,pointer,head,blocks=rows[selector,owner];target,xy,tiles=recipe['frames'][index]
        directory.extend(head+struct.pack('>I',target))
        if target<0x400000:
            require(target in resident and xy is None and not tiles,'Foreground reuse is outside original resident family: selector='+str(selector)+' owner='+str(owner)+' target='+hex(target))
            native_blocks,_=native_cel(native,target)
            checked+=compare_canvas(blocks,native_blocks,inputs['art'],pixels[0x30000*128:0x40000*128],inputs['valid'])
        else:
            require(root+156<=xy<target<end,'Foreground new cel allocation bounds')
            coordinates,body=emit_cel(data,pointer,xy,tiles,inputs['art'],inputs['valid'],pixels[recipe['graphics_bank']*128:(recipe['graphics_bank']+65536)*128],0)
            require(coordinates is not None and target==xy+len(coordinates),'Foreground complete coordinate/cel allocation')
            require(pointer not in cels or cels[pointer]==(target,xy,tiles),'Original foreground cel alias differs')
            cels[pointer]=(target,xy,tiles);writes.extend(((xy,coordinates),(target,body)))
    overlays=CAPTION_OVERLAYS if recipe['region']=='us' else {}
    require(recipe['caption_overlays']=={str(k):list(v) for k,v in overlays.items()},'Authored caption pointer domain differs')
    for index,(before,after) in overlays.items():
        at=12+index*8+4;require(struct.unpack_from('>I',directory,at)[0]==before,'Authored caption original frame preimage differs');struct.pack_into('>I',directory,at,after)
    writes.append((root,bytes(directory)))
    covered=set()
    for at,blob in writes:covered.update(range(at,at+len(blob)))
    if covered:
        used=max(covered)+1;require(covered==set(range(root,used)),'Foreground allocation has an unexplained interior gap')
        require(used<=end,'Foreground allocation exceeds reservation')
        if used<end:writes.append((used,b'\xff'*(end-used)))
    return writes,{'selectors':6,'owners':[32,33,34],'frames':18,'new_cels':len(cels),'bytes':end-root,'resident_canvas_pixels_checked':checked,'authored_caption_pointer_overlays':len(overlays),'scope':'Original retained foreground allocation plus reviewed caption pointer redirects; replacement caption art is qualified separately'}

def main():
    import argparse,json
    from pathlib import Path
    p=argparse.ArgumentParser(description=__doc__)
    for n in ('recipe','inputs','pixels','outdir'):p.add_argument('--'+n,type=Path,required=True)
    a=p.parse_args();recipe=json.loads(a.recipe.read_text());paths=json.loads(a.inputs.read_text());writes,report=construct({n:Path(v).read_bytes()for n,v in paths.items()},recipe,a.pixels.read_bytes());data=bytearray(0x400000);mask=bytearray(len(data))
    for at,blob in writes:
        at-=0xa00000;require(all(not mask[at+i] or data[at+i]==v for i,v in enumerate(blob)),'Foreground aliases disagree');data[at:at+len(blob)]=blob;mask[at:at+len(blob)]=b'\1'*len(blob)
    (a.outdir/'result.bin').write_bytes(data);(a.outdir/'result.mask').write_bytes(mask);print(json.dumps(report))
if __name__=='__main__':main()
