"""Complete original shared Ryu selector, event, collision-lane and voice tables."""
import hashlib,struct
from public_kit_graphics import require


def construct(inputs,recipe):
    require(set(inputs)==set(recipe['inputs'])=={'arcade','comp2'},'Complete shared Ryu table inputs')
    for name,pin in recipe['inputs'].items():
        require(len(inputs[name])==pin['bytes']and hashlib.sha256(inputs[name]).hexdigest()==pin['sha256'],'Original shared Ryu tables '+name)
    region=recipe['region'];require(region in ('us','jp'),'Shared Ryu region')
    base=0x60b080 if region=='jp'else 0x60ad00;delta=0x5700 if region=='jp'else 0
    raw=inputs['arcade'];c2=inputs['comp2']
    def read(at,n):
        at-=base;require(0<=at<=len(c2)-n,'Original shared Ryu resource extent');return c2[at:at+n]
    def u(at):return struct.unpack('<I',read(at,4))[0]
    def native(at):return struct.unpack_from('>I',raw,at)[0]
    indices=u(0x7493d8+delta);events=u(0x749478+delta)
    ni=native(0xde320);ne=native(0xde3a0)
    require(read(indices,460)==raw[ni:ni+460] and read(events,116)==raw[ne:ne+116],'Whole shared native selector/event prefixes')
    writes=[(0xba8568,read(indices,464)),(0xba8738,read(events,136))]
    reference=None
    for style in range(3):
        bank=u(u(0x749338+delta)+style*4);other=u(u(0x749338+delta+23*4)+style*4)
        require(bank==other,'Shared Ryu/Evil original collision owner alias')
        offsets=struct.unpack('<5h',read(bank,10));require(offsets[1]-offsets[0]==520 and offsets[2]-offsets[1]==512,'Complete original Ryu head/mid lane extents')
        lanes=[b''.join(read(bank+offsets[i]+n,2)[::-1]for n in range(0,offsets[i+1]-offsets[i],2))for i in (0,1)]
        if reference is None:reference=lanes
        require(reference==lanes,'Shared collision lanes agree across three ISMs')
    writes.extend(zip((0xba9738,0xba9940),reference))
    voice=u(0x74c538+delta);nv=native(0xe0aa0)
    for cue in (11,12,15):
        row=b''.join(read(voice+cue*8+n,2)[::-1]for n in range(0,8,2))
        require(row==raw[nv+cue*8:nv+(cue+1)*8],'Complete shared voice cue control')
    cue=b''.join(read(voice+18*8+n,2)[::-1]for n in range(0,8,2));require(struct.unpack('>4H',cue)==(0x253,0x253,0,0),'Original added Ryu voice command')
    writes.append((0xba9600,raw[nv:nv+144]+cue))
    return writes,{'selector_rows':116,'event_rows':34,'head_rows':65,'mid_rows':64,'voice_rows':19,'ism_controls':3,'bytes':1784}
