"""Complete original Upper X-ISM collision bank and shared selector extension."""
import struct
import public_kit_dhalsim_tables as prior
from public_kit_graphics import require


def construct(inputs,recipe):
    tables,_=prior.construct(inputs,recipe);tables=dict(tables)
    source,_=prior.original_model(inputs['arcade'],inputs['comp2'],recipe['region'])
    old=tables[0xaa6440];offsets=struct.unpack_from('>5h',old)
    lanes=[[old[i:i+8]for i in range(offsets[n],offsets[n+1],8)]for n in range(4)]
    attacks=[old[i:i+32]for i in range(offsets[4],len(old),32)]
    require([len(row)for row in lanes]==[51,48,25,9]and len(attacks)==95,'Complete previous X bank extent')
    def values(action,ordinal):
        frames,loop=source.families[7][action]
        expected=(5,None)if action==33 else (6,2 if action>=48 else 4)
        require((len(frames),loop)==expected,'Original Upper complete X action topology')
        return source.values(frames[ordinal],1)
    for lane,action in ((0,48),(1,48),(1,49),(2,50),(2,33)):
        lanes[lane].append(values(action,1)['geometry'][lane])
    for action,ordinal in ((10,4),(11,4),(33,1)):attacks.append(values(action,ordinal)['attack'])
    new=[10]
    for rows in lanes:new.append(new[-1]+len(rows)*8)
    blob=struct.pack('>5h',*new)+b''.join(b''.join(rows)for rows in lanes)+b''.join(attacks)
    require(len(blob)==4250,'Complete expanded X bank extent')
    previous=tables[0xaa7460];require(len(previous)==384,'Complete previous shared selector table')
    selectors=[previous[i:i+4]for i in range(0,len(previous),4)]
    for action in (48,49,50,33):
        geometry=values(action,1)['geometry'];selected=[]
        for rows,wanted in zip(lanes,geometry):
            require(wanted in rows,'Original X geometry must exist in complete extended bank')
            selected.append(rows.index(wanted))
        require(bytes(selected)not in selectors,'Source extension must allocate a new selector')
        selectors.append(bytes(selected))
    return [(0xab4000,blob),(0xab6650,b''.join(selectors))],{'owner':15,'style':1,'geometry_rows':list(map(len,lanes)),'attack_rows':len(attacks),'selectors':len(selectors),'bytes':len(blob)+len(selectors)*4,'complete_source_actions':[10,11,33,48,49,50]}
