"""Complete ordinary Boxer21 cel family from original root graphs and artwork."""
import hashlib,struct
from public_kit_actor import Data
from public_kit_blocks import BlockPacker,grid_code
from public_kit_graphics import require
from public_kit_shin_frames import native_cel,compare_canvas

def original(inputs,region):
    data=Data(inputs['comp2'],0x60ad00 if region=='us' else 0x60b080,inputs['coords'],0xb04000)
    bank=data.u32((0x749838 if region=='us' else 0x74ef38)+21*4);roots=struct.unpack('<12I',data.read(bank,48));frames={};cels={}
    require(len(set(roots))==5,'Complete ordinary21 root aliases')
    ending=data.u32((0x619b50 if region=='us' else 0x61ac40)+21*4);require(ending==roots[0],'Ordinary21 ending/combat root alias')
    for family,root in enumerate(roots):
        _,targets=data.root(root);require(len(targets)==(70,48,56,30)[family%4],'Complete ordinary21 root extents')
        todo=list(targets)
        while todo:
            at=todo.pop()
            if at in frames:continue
            header=data.read(at,20);_,value,nxt=data.frame(at);pointer=data.u32(at+4)
            frames[at]=(header,nxt);cels[pointer]=(value[0],tuple((x,y,w&65535,w>>16)for x,y,w in value[1]))
            if nxt is not None:todo.append(nxt)
            require(len(frames)<=972,'Bounded complete ordinary21 graph')
    require(len(frames)==972 and len(cels)==228,'Complete ordinary21 frame/cel domain')
    return cels

def construct(inputs,recipe,pixels):
    require(set(inputs)==set(recipe['inputs'])=={'arcade','comp2','coords','pixels','mask'},'Complete ordinary21 source input set')
    for name,pin in recipe['inputs'].items():
        require(len(inputs[name])==pin['bytes'] and hashlib.sha256(inputs[name]).hexdigest()==pin['sha256'],'Original ordinary21 source '+name)
    require(recipe['region']in ('us','jp'),'Original ordinary21 region')
    cels=original(inputs,recipe['region']);bindings={int(k):v for k,v in recipe['cels'].items()}
    require(set(bindings)==set(cels),'Complete ordinary21 cel allocation bindings')
    packer=BlockPacker(b'');payload=bytearray();checked=0;private=0;reused=0
    for source,(kind,blocks)in sorted(cels.items()):
        destination=bindings[source]
        if destination<0xa00000:
            native,_=native_cel(inputs['arcade'],destination)
            checked+=compare_canvas(blocks,native,inputs['pixels'],pixels[16<<20:24<<20],inputs['mask']);reused+=1;continue
        require(kind==2 and 0xc7a000<=destination<0xc7b18e,'Owned ordinary21 private cel range');converted=[]
        for x,y,t,a in blocks:
            w,h=(a>>8&15)+1,(a>>12&15)+1;codes=[grid_code(t,dx,dy)for dy in range(h)for dx in range(w)]
            require(all(c<len(inputs['mask'])and inputs['mask'][c]for c in codes),'Original ordinary21 tile presence')
            tiles=[inputs['pixels'][c*128:(c+1)*128]for c in codes];target=packer.add(w,h,tiles,a);packer.check(target,w,h,tiles,a)
            converted.append((x,y,target+0x8000,a))
        checked+=compare_canvas(blocks,converted,inputs['pixels'],pixels[48<<20:56<<20],inputs['mask'])
        xy=0xc7a000+len(payload);payload.extend(b''.join(struct.pack('>2h',x,y)for x,y,_,_ in converted))
        require(destination==0xc7a000+len(payload),'Complete ordinary21 private cel placement')
        area=sum(((a>>8&15)+1)*((a>>12&15)+1)for _,_,_,a in converted)
        payload.extend(struct.pack('>3HI',2,area,len(converted)-1,xy));payload.extend(b''.join(struct.pack('>2H',t,a)for _,_,t,a in converted));private+=1
    packed=b''.join(packer.tiles)
    require(len(payload)==4494 and private==51 and reused==177,'Complete ordinary21 cel family census')
    require(len(packed)==200704 and pixels[52<<20:(52<<20)+len(packed)]==packed,'Complete ordinary21 private packed artwork')
    return [(0xc7a000,bytes(payload))],{'frames_traversed':972,'source_cels':228,'private_cels':51,'reused_cels':177,'bytes':4494,'private_art_bytes':len(packed),'canvas_pixels_checked':checked}
