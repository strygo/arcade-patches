"""Complete original Juli, Juni and Evil Ryu route packet."""
import hashlib
import struct
from public_kit_graphics import require


def construct(inputs,recipe):
    require(set(inputs)==set(recipe['inputs'])=={'comp2'},'Original Evil/Dolls route inventory')
    data=inputs['comp2'];pin=recipe['inputs']['comp2']
    require(len(data)==pin['bytes'] and hashlib.sha256(data).hexdigest()==pin['sha256'],'Original Evil/Dolls source identity')
    region=recipe['region'];require(region in ('us','jp'),'Original route region')
    table=0x36e01c if region=='us' else 0x37338c;directory=data[table:table+80]
    require(hashlib.sha256(directory).hexdigest()=='eefb765d2e38078a8f7a82d29ea2074555f140e7529e92461d78dee4f5c70f5e','Complete original forty-owner route directory')
    offsets=struct.unpack('<40H',directory);result=bytearray(64)
    require(recipe['owners']==[30,31,23],'Complete source-authored route append order')
    for owner in recipe['owners']:
        source=table+offsets[owner];row=data[source:source+160]
        require(len(row)==160 and max(row)<40,'Complete original sixteen ten-opponent choices')
        struct.pack_into('>h',result,owner*2,len(result));result.extend(row)
    require(len(result)==544 and all(result[n*2:n*2+2]==bytes(2)for n in range(32)if n not in recipe['owners']),'Complete guarded owner directory and route extent')
    return [(0xc75d00,bytes(result))],{'bytes':544,'directory_rows':32,'original_owners':[30,31,23],'complete_route_rows':3,'choices_per_row':16,'opponents_per_choice':10}
