"""Complete Cody selector, collision, ISM and cancel resources from originals."""
import hashlib
import struct
from public_kit_actor import Data
from public_kit_copied_frames import root, graph
from public_kit_graphics import require

START=0xad9a1e
END=0xadafba
TABLES={'roots':0xde6a0,'indices':0xde320,'events':0xde3a0,'variants':0xde2a0,'cancel':0xddda0}
OPERANDS={'roots':0x2fc54,'indices':0x2ad30,'events':0x2ad3c,'variants':0x2ad48,'cancel':0x2a724}


def project(inputs,recipe):
    from cps2_crypt import decrypt_rom
    digest=lambda b:hashlib.sha256(b).hexdigest()
    require(set(inputs)==set(recipe['inputs'])=={'arcade','key','comp2'},'Complete original Cody packet inputs')
    for name,blob in inputs.items():
        pin=recipe['inputs'][name]
        require(len(blob)==pin['bytes'] and digest(blob)==pin['sha256'],'Original Cody packet source '+name)
    region=recipe['source_region'];require(region in ('us','jp') and recipe['region'] in ('us','jp'),'Cody packet source/display region')
    raw=inputs['arcade'];ops=decrypt_rom(raw[:0x30000],inputs['key'])[0]
    require(set(recipe['readers'])==set(TABLES),'Complete Cody native reader inventory')
    for name,table in TABLES.items():
        at=OPERANDS[name]
        require(struct.unpack_from('>I',ops,at)[0]==table,'Original Cody native reader table '+name)
        require(digest(ops[at-2:at+8])==recipe['readers'][name],'Complete original Cody native reader '+name)
    u32=lambda at:struct.unpack_from('>I',raw,at)[0]
    base=0x60b080 if region=='jp'else 0x60ad00;shift=0x5700 if region=='jp'else 0
    data=Data(inputs['comp2'],base,b'',0xb04000)
    native_roots=[u32(u32(TABLES['roots']+27*4)+i*4)for i in range(12)]
    source_roots=struct.unpack('<12I',data.read(data.u32(0x749838+shift+27*4),48))
    require(native_roots[3]==native_roots[7]==native_roots[11] and source_roots[3]==source_roots[7]==source_roots[11],'Complete Cody normal ISM aliases')
    native_families=[[graph(raw,at,0,'>')[0]for at in root(raw,r,0,'>')]for r in native_roots]
    source_families=[[graph(inputs['comp2'],at,base,'<')[0]for at in root(inputs['comp2'],r,base,'<')]for r in source_roots]
    require([len(f)for f in native_families]==[73,48,59,47]*3 and [len(f)for f in source_families]==[73,48,59,49]*3,'Complete original Cody action domains')
    native_frames={at for f in native_families for a in f for at in a}
    require(max(raw[at+8]for at in native_frames)==101 and max(raw[at+9]for at in native_frames)==100,'Complete retained Cody selector/attack demand')
    indices=data.read(data.u32(0x7493d8+shift+27*4),107*4)
    native_indices=u32(TABLES['indices']+27*4)
    require(indices[:102*4]==raw[native_indices:native_indices+102*4],'Complete native Cody selector prefix')
    require(all(raw[native_indices+raw[at+8]*4+2]!=24 for at in native_frames),'No retained Cody consumer demands changed low24')
    variants=data.u32(0x749338+shift+27*4)
    banks=[data.u32(variants+i*4)for i in range(3)]
    native_variants=u32(TABLES['variants']+27*4)
    native_banks=[u32(native_variants+i*4)for i in range(3)]
    require(len(set(banks))==len(set(native_banks))==1,'Complete Cody collision ISM aliases')
    bank,native_bank=banks[0],native_banks[0]
    aliases=[[owner,style]for owner in range(32)for style in range(3)if u32(u32(TABLES['variants']+owner*4)+style*4)==native_bank]
    require(aliases==[[27,n]for n in range(3)],'Complete original native collision owner domain')
    offsets=struct.unpack('<5h',data.read(bank,10));prior=struct.unpack_from('>5h',raw,native_bank)
    require(offsets==(10,674,1178,1434,1562) and prior==(10,642,1130,1386,1514),'Complete Cody collision lane extents')
    words=lambda b:b''.join(b[i:i+2][::-1]for i in range(0,len(b),2))
    lanes=[words(data.read(bank+offsets[n],offsets[n+1]-offsets[n]))for n in range(4)]
    differences=[]
    for lane in range(4):
        previous=raw[native_bank+prior[lane]:native_bank+prior[lane+1]]
        differences.extend([lane,i,a,z]for i,(a,z)in enumerate(zip(previous,lanes[lane]))if a!=z)
    require(differences==[[2,192,0,255],[2,193,0,253],[2,195,0,18],[2,197,0,35],[2,199,0,18]],'Complete original Cody low24 lane projection')
    attacks=b''.join(words(data.read(bank+offsets[4]+n*32,8))+data.read(bank+offsets[4]+n*32+8,24)for n in range(104))
    require(attacks[:101*32]==raw[native_bank+prior[4]:native_bank+prior[4]+101*32],'Complete original Cody attack prefix')
    collision=struct.pack('>5h',*offsets)+b''.join(lanes)+attacks
    events=data.read(data.u32(0x749478+shift+27*4),37*4);native_events=u32(TABLES['events']+27*4)
    require(events==raw[native_events:native_events+148],'Complete original Cody event prefix')
    added={at for n in (47,48)for at in source_families[3][n]}
    require(len(added)==20,'Complete original Cody added frame domain')
    for at in added:
        row=data.read(at,20)
        require(row[8]<107 and row[9]<104 and row[10]<37,'Actual added Cody field domains')
        require(all(index<len(lanes[n])//8 for n,index in enumerate(indices[row[8]*4:row[8]*4+4])),'Actual added Cody geometry demand')
    source_cancel=data.u32(0x748cf8+shift+27*4)
    cancel_offsets=struct.unpack('<3h',data.read(source_cancel,6))
    require(cancel_offsets==(106,106,8),'Complete Cody original cancel layout')
    rows=[data.read(source_cancel+offset,98)for offset in cancel_offsets]
    require(rows[0]==rows[1],'Complete Cody X/A cancel aliases')
    native_cancel=u32(TABLES['cancel']+27*4);native_offsets=struct.unpack_from('>3h',raw,native_cancel)
    require(native_offsets==(100,100,6) and all(raw[native_cancel+offset:native_cancel+offset+94]==row[:94]for offset,row in zip(native_offsets,rows)),'Complete native47-action cancel prefix')
    cancel=struct.pack('>3h',104,104,6)+rows[2]+rows[0]
    collision_at=START+len(indices)
    packet=indices+collision+struct.pack('>3I',*([collision_at]*3))+cancel
    require(len(indices)==428 and len(collision)==4890 and len(cancel)==202 and len(packet)==END-START==5532,'Complete Cody combat packet extent')
    original_sha=digest(packet);packet=bytearray(packet)
    require([r['address']for r in recipe['edits']]==['0xada264','0xadab24'],'Complete reviewed Cody attack-row inventory')
    for row in recipe['edits']:
        at=int(row['address'],0)-START;before=bytes.fromhex(row['before']);after=bytes.fromhex(row['after'])
        require(len(before)==len(after)==32 and packet[at:at+32]==before,'Reviewed original whole Cody attack-row preimage')
        packet[at:at+32]=after
    packet=bytes(packet)
    return [(START,packet)],{'original_packet_sha256':original_sha,'reviewed_attack_rows':2,'bytes':len(packet),'selector_rows':107,'attacks':104,'cancel_actions':49,'added_frames':len(added),'native_owner_aliases':aliases,'sha256':digest(packet)}


def construct(inputs,recipe):
    writes,report=project(inputs,recipe)
    require(report['sha256']==recipe['packet_sha256'],'Whole source-derived Cody combat packet identity')
    return writes,report


def main():
    import argparse,json
    from pathlib import Path
    p=argparse.ArgumentParser(description=__doc__)
    for name in ('pools','recipe','out'):p.add_argument('--'+name,type=Path,required=True)
    a=p.parse_args();recipe=json.loads(a.recipe.read_text())
    packed=b''.join((a.pools/('arcade-jp-'+n)).read_bytes()for n in ('sz3j.03c','sz3j.04c','sz3.05c','sz3.06c','sz3.07c','sz3.08c','sz3.09c','sz3.10b'))
    raw=bytearray(packed);raw[::2]=packed[1::2];raw[1::2]=packed[::2]
    inputs={'arcade':bytes(raw),'key':(a.pools/'arcade-jp-sfz3j.key').read_bytes(),'comp2':(a.pools/('ps2-'+recipe['source_region']+'-comp2.bin')).read_bytes()}
    writes,report=construct(inputs,recipe);a.out.mkdir()
    (a.out/'packet.bin').write_bytes(writes[0][1]);(a.out/'report.json').write_text(json.dumps(report,sort_keys=True)+'\n')


if __name__=='__main__':main()
