"""Typed native frame/cel serialization from complete original fighter resources."""
import hashlib
import struct
from public_kit_actor import Data
from public_kit_blocks import grid_code,native_grid_code
from public_kit_graphics import require


def owner_graph(data,table,owner):
    bank=data.u32(table+owner*4)
    roots=struct.unpack('<12I',data.read(bank,48))
    frames={};actions=[]
    for root in sorted(set(roots)):
        _,targets=data.root(root)
        for action,start in enumerate(targets):
            actions.append((root,action,start));at=start;chain=set()
            while at is not None and at not in chain:
                chain.add(at)
                if at in frames:break
                require(len(frames)<8192,'Unbounded original fighter frame graph')
                raw=data.read(at,20);_,_,nxt=data.frame(at)
                frames[at]=(data.u32(at+4),nxt,24 if raw[1]&128 else 20)
                at=nxt
    return frames,actions


def cel(data,source,native_xy,tiles,pixels,valid,native_pixels,bank):
    kind,blocks=data.cel(source)
    if kind==18:
        require(not tiles and native_xy is None,'Blank cel has block allocations')
        return None,struct.pack('>H',18)
    require(len(tiles)==len(blocks) and blocks,'Complete cel block inventory differs')
    coords=bytearray();body=bytearray();total=0
    for (x,y,word),code in zip(blocks,tiles):
        original,attr=word&65535,word>>16
        width,height=(attr>>8&15)+1,(attr>>12&15)+1;total+=width*height
        require(0<=code<65536 and bank in range(4),'Native object bank/code extent')
        for dy in range(height):
            for dx in range(width):
                src=grid_code(original,dx,dy);dst=bank*65536+native_grid_code(code,dx,dy,attr)
                require(0<=src<len(valid) and valid[src] and (src+1)*128<=len(pixels),'Absent original cel tile')
                require(dst//65536==bank and (dst+1)*128<=len(native_pixels),'Native cel crosses its object bank')
                require(pixels[src*128:(src+1)*128]==native_pixels[dst*128:(dst+1)*128],
                    'Complete cel artwork differs from original source')
        coords.extend(struct.pack('>hh',x,y));body.extend(struct.pack('>HH',code,attr))
    return bytes(coords),struct.pack('>HHHI',2,total,len(blocks)-1,native_xy)+body


def construct(inputs,recipe,native_pixels):
    for name,pin in recipe['inputs'].items():
        require(len(inputs[name])==pin['bytes'] and hashlib.sha256(inputs[name]).hexdigest()==pin['sha256'],
            'Original frame resource identity differs: '+name)
    require(hashlib.sha256(native_pixels).hexdigest()==recipe['graphics_pixels_sha256'],'Reconstructed graphics identity differs')
    data=Data(inputs['comp2'],recipe['base'],inputs['coords'],0xb04000)
    graphs={owner:owner_graph(data,recipe['owner_table'],owner)[0] for owner in recipe['owners']}
    writes=[];cels={}
    for row in recipe['cels']:
        owner,source,destination,xy,bank,tiles=row
        require(source in {v[0] for v in graphs[owner].values()},'Cel has no original fighter owner')
        coords,body=cel(data,source,xy,tiles,inputs['pixels'+str(owner)],inputs['mask'+str(owner)],native_pixels,bank)
        if coords is not None:writes.append((xy,coords))
        writes.append((destination,body));cels[owner,source,destination]=True
    mapping={(owner,source,destination) for owner,source,destination,_,_ in recipe['frames']}
    for owner,source,destination,native_cel,native_next in recipe['frames']:
        require(source in graphs[owner],'Frame has no original fighter owner')
        source_cel,nxt,size=graphs[owner][source]
        require((owner,source_cel,native_cel) in cels,'Frame cel has not been reconstructed')
        raw=data.read(source,20)
        blob=raw[:4]+struct.pack('>I',native_cel)+raw[8:16]+raw[16:18][::-1]+raw[18:20]
        if nxt is not None:
            require((owner,nxt,native_next) in mapping,'Frame successor is not in the reconstructed graph')
        else:require(native_next is None,'Terminal frame has a successor')
        if size==24:blob+=struct.pack('>I',native_next)
        elif nxt is not None:require(native_next==destination+20,'Native frame fallthrough differs')
        writes.append((destination,blob))
    return writes
