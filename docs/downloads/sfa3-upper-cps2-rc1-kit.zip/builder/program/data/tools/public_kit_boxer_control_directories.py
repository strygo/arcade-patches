"""Complete38-owner command, special and availability callback directories."""
import hashlib
import struct
from public_kit_graphics import require

ROLES={'command':(0x2b15e,0xc739d4,0x207c),'special_human':(0x28ae8,0xc73a6c,0x207c),
       'special_CPU':(0x28af4,0xc73b04,0x207c),'availability':(0x328a6,0xc73b9c,0x227c)}


def construct(inputs,recipe):
    require(set(inputs)==set(recipe['inputs'])=={'arcade','key'},'Original Boxer callback inventory')
    for n,b in inputs.items():
        p=recipe['inputs'][n];require(len(b)==p['bytes'] and hashlib.sha256(b).hexdigest()==p['sha256'],'Original Boxer callback identity')
    from cps2_crypt import decrypt_rom
    raw=inputs['arcade'];ops=decrypt_rom(raw[:0x100000],inputs['key'])[0]
    require(set(recipe['exports'])==set(ROLES),'Complete Boxer callback role domain')
    writes=[]
    for role,(operand,destination,instruction)in ROLES.items():
        require(struct.unpack_from('>H',ops,operand-2)[0]==instruction,'Complete original callback reader opcode')
        root=struct.unpack_from('>I',ops,operand)[0];require(0xd0000<=root<=len(raw)-128,'Original callback pointer directory')
        values=list(struct.unpack_from('>32I',raw,root));exports=recipe['exports'][role]
        require(set(exports)=={'23','32','33','34','35','36'} and all(type(v)is int and 0<v<0x100000 and v%2==0 for v in exports.values()),'Complete typed controller export inventory')
        values[23]=exports['23'];values.extend(exports[str(n)]for n in range(32,37));values.append(values[21])
        require(len(values)==38,'Complete Boxer callback owner domain')
        writes.append((destination,struct.pack('>38I',*values)))
    return writes,{'bytes':608,'tables':4,'owners':38,'original_prefix_rows':32,'source_export_owners':[23,32,33,34,35,36],'boxer_alias':21}
