"""Complete original Boxer stage maps, placements and full palette arrays."""
import hashlib
import struct
from public_kit_graphics import require,permutation
from public_kit_stage_maps import TABLES,CHUNKS,STRIDES
from public_kit_palettes import STAGE_TABLES,STAGE_SIZES


def project(inputs,region,owner,bindings,pixels,overlays):
    require(region in ('us','jp') and owner==37,'Unknown stage source domain')
    base=0x60ad00 if region=='us' else 0x60b080
    shift=0x5700 if region=='jp' else 0
    def read(at,size):
        offset=at-base
        require(size>0 and 0<=offset<=len(inputs['comp2'])-size,'Stage source bounds')
        return inputs['comp2'][offset:offset+size]
    kind=read(0x747ee0+shift+owner*2,1)[0]
    require(kind in (0,2,4),'Unknown stage coordinate grammar')
    allowed=set();undo=permutation(True)
    domains={}
    for name,offset,size,ranges in overlays:
        require(name in ('foreground','boxer_ending','dolls_ending','juli_pose') and offset%0x200000==0 and size%0x200000==0 and offset+size<=0x2000000,'Unknown downstream blank-only graphics domain')
        for at,count in ranges:
            require(at%8==count%8==0 and count>0 and 0<=at<=size-count,'Foreground write group bounds')
            for pos in range(at,at+count,8):
                raw=offset+pos;physical=0x2000000+(raw//0x200000)*0x200000+undo[(raw%0x200000)//8]*8
                allowed.update(range(physical,physical+8))
                for byte in range(physical,physical+8):domains.setdefault(byte,[]).append(name)
    divergences={}
    files={};summary={};used_bindings={n:set() for n in (1,2,3)}
    tables={}
    for layer in (1,2,3):
        rows=bindings[str(layer)]
        tables[layer]={r[0]:r[1:] for r in rows}
        require(len(tables[layer])==len(rows),'Duplicate original tile binding')
    def cell(layer,code,attr):
        require(code in tables[layer],f'Missing original stage tile binding: owner={owner} layer={layer} code={code}')
        native,bank,pin=tables[layer][code];used_bindings[layer].add(code)
        require(bank in (0,512) and 0<=native<(16384 if layer==3 else 65536),'Native stage tile extent')
        stride={1:32,2:128,3:512}[layer]
        supply=inputs['scroll3'] if layer==3 else inputs['font']
        if layer==3:
            require(code<len(inputs['scroll3_mask']),'Original stage tile mask bounds')
            valid=inputs['scroll3_mask'][code]
            require(valid or code==0,'Missing non-null original stage tile')
        else:valid=True
        if valid:
            require((code+1)*stride<=len(supply),'Original stage artwork bounds')
            tile=supply[code*stride:(code+1)*stride]
        else:tile=b'\xff'*512
        require(hashlib.sha256(tile).hexdigest()==pin,'Original complete stage tile differs from bound producer source identity')
        if layer==1:tile=b''.join(tile[y*4:y*4+4]*2 for y in range(8))
        physical=(40 if bank else 8)*1024**2+native*STRIDES[layer]
        require(physical+len(tile)<=len(pixels),'Stage tile physical bounds')
        emitted=pixels[physical:physical+len(tile)]
        changed=[n for n,(original,final) in enumerate(zip(tile,emitted)) if original!=final]
        if changed:
            require(all(physical+n in allowed and tile[n]==255 for n in changed),f'Stage tile differs outside declared downstream blank-group writes: layer={layer}, source={code}, unbound={sum(physical+n not in allowed for n in changed)}, nonblank={sum(tile[n]!=255 for n in changed)}')
            divergences[(layer,code)]={'layer':layer,'source':code,'physical':physical,'bytes_changed':len(changed),
                'original_sha256':hashlib.sha256(tile).hexdigest(),'final_sha256':hashlib.sha256(emitted).hexdigest(),
                'changed_physical_bytes':[physical+n for n in changed],
                'downstream_writers':sorted({name for n in changed for name in domains[physical+n]})}
        return struct.pack('>HH',native,(attr&127)|bank)
    for layer in (1,2,3):
        table=TABLES[layer]+shift
        address=table+struct.unpack('<h',read(table+owner*2,2))[0]
        controls=read(address,128)
        used={0:4,2:8,4:128}[kind] if layer==1 else {2:16,3:64}[layer]
        chunks=sorted(set(controls[:used]));indices={v:i for i,v in enumerate(chunks)}
        files[f's{layer}_controls']=bytes(indices[v] for v in controls[:used])+controls[used:]
        if layer==1:
            originals=[struct.unpack('<64H',read(CHUNKS[1]+shift+c*128,128)) for c in chunks]
            macros=sorted({v for row in originals for v in row});mids={v:i for i,v in enumerate(macros)}
            files['s1_chunks']=b''.join(struct.pack('>64H',*(mids[v] for v in row)) for row in originals)
            files['s1_macros']=b''.join(cell(1,code,attr) for macro in macros
                for attr,code in struct.iter_unpack('<HH',read(0x69f3b0+shift+macro*64,64)))
        else:
            count={2:256,3:64}[layer];out=bytearray()
            for chunk in chunks:
                raw=read(CHUNKS[layer]+shift+chunk*count*3,count*3)
                codes=struct.unpack('<'+str(count)+'H',raw[:count*2])
                for code,attr in zip(codes,raw[count*2:]):
                    out.extend(cell(layer,(code+(0x1c00 if layer==2 else 0))&65535,attr))
            files[f's{layer}_chunks']=bytes(out)
        summary[str(layer)]={'chunks':len(chunks),'tiles':len(used_bindings[layer]),'consumed_controls':used,'source_codes':sorted(used_bindings[layer])}
        if layer==1:summary['1']['macros']=len(macros)
    summary['coordinate_type']=kind
    summary['downstream_composed_art_changes']=list(divergences.values())
    return files,summary


def extras(comp2,region):
    base=0x60b080 if region=='jp' else 0x60ad00;shift=0x5700 if region=='jp' else 0
    def read(at,size):
        require(size>0 and 0<=at-base<=len(comp2)-size,'Boxer stage source bounds')
        return comp2[at-base:at-base+size]
    palette=bytearray()
    for table,size in zip(STAGE_TABLES,STAGE_SIZES):
        table+=shift;at=table+struct.unpack('<h',read(table+37*2,2))[0];raw=read(at,size)
        palette.extend(b''.join(raw[n:n+2][::-1] for n in range(0,size,2)))
    table=0x950ce0+shift;at=table+struct.unpack('<h',read(table+37*2,2))[0];rows=bytearray()
    for n in range(128):
        raw=read(at+n*16,2)
        if struct.unpack('<h',raw)[0]<0:break
        raw=read(at+n*16,16)
        rows.extend(raw[:2][::-1]+struct.pack('>2h',*struct.unpack('<2h',raw[2:6]))+raw[6:8][::-1]+raw[8:10][::-1]+struct.pack('>3H',*struct.unpack('<3H',raw[10:])))
    else:raise ValueError('Unbounded stage placement list')
    require(n==8 and len(palette)==3264,'Boxer complete placement/palette census differs')
    return {'placements':bytes(rows)+b'\xff\xff','palettes':bytes(palette)}


def construct(inputs,recipe,pixels):
    require(recipe['schema']==1,'Unknown Boxer stage recipe')
    for name,pin in recipe['inputs'].items():require(hashlib.sha256(inputs[name]).hexdigest()==pin,'Original stage input identity: '+name)
    require(hashlib.sha256(pixels).hexdigest()==recipe['pixels_sha256'],'Stage emitted graphics identity')
    files,summary=project(inputs,recipe['region'],37,recipe['bindings'],pixels,recipe['foreground_overlays'])
    require(all(set(summary[str(n)]['source_codes'])=={r[0] for r in recipe['bindings'][str(n)]} for n in (1,2,3)),'Boxer complete tile domain')
    for n in (1,2,3):del summary[str(n)]['source_codes']
    files.update(extras(inputs['comp2'],recipe['region']))
    require(set(files)==set(recipe['allocations']),'Complete stage allocation domain')
    return [(recipe['allocations'][name],blob) for name,blob in files.items()],summary


def main():
    import argparse,json
    from pathlib import Path
    p=argparse.ArgumentParser(description=__doc__)
    for n in ('comp2','font','scroll3','scroll3_mask','pixels','recipe','outdir'):p.add_argument('--'+n,type=Path,required=True)
    a=p.parse_args();inputs={n:getattr(a,n).read_bytes() for n in ('comp2','font','scroll3','scroll3_mask')}
    writes,_=construct(inputs,json.loads(a.recipe.read_text()),a.pixels.read_bytes());data=bytearray(0x400000);mask=bytearray(len(data))
    for at,blob in writes:
        at-=0xa00000;require(not any(mask[at:at+len(blob)]),'Stage map overlap')
        data[at:at+len(blob)]=blob;mask[at:at+len(blob)]=b'\1'*len(blob)
    a.outdir.mkdir(exist_ok=True);(a.outdir/'result.bin').write_bytes(data);(a.outdir/'result.mask').write_bytes(mask)


if __name__=='__main__':main()
