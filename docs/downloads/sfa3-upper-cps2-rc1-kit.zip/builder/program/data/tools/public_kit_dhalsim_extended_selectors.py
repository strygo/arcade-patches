"""Whole shared Dhalsim selector table after the original A/V shape extension."""
import struct
import public_kit_dhalsim_x_collision as xbank
import public_kit_dhalsim_extended_collision as avbank
from public_kit_graphics import require


def construct(inputs,recipe):
    xwrites,_=xbank.construct(inputs,recipe);avwrites,_=avbank.construct(inputs,recipe)
    prior=dict(xwrites)[0xab6650];bank=dict(avwrites)[0xab6910]
    require(len(prior)==400 and len(bank)==4162,'Complete preceding X selectors and AV bank')
    offsets=struct.unpack_from('>5h',bank)
    lanes=[[bank[i:i+8]for i in range(offsets[n],offsets[n+1],8)]for n in range(4)]
    source,_=xbank.prior.original_model(inputs['arcade'],inputs['comp2'],recipe['region'])
    selectors=[prior[i:i+4]for i in range(0,len(prior),4)]
    for action in (48,49):
        demand=[]
        for slot in (3,11):
            frames,loop=source.families[slot][action]
            require(len(frames)==6 and loop==2,'Complete original A/V drill shape')
            geometry=source.values(frames[1],slot//4)['geometry'];selected=[]
            for rows,wanted in zip(lanes,geometry):
                require(wanted in rows,'Original extended geometry row exists')
                selected.append(rows.index(wanted))
            demand.append(bytes(selected))
        require(demand[0]==demand[1]and demand[0]not in selectors,'Unanimous new AV selector')
        selectors.append(demand[0])
    return [(0xab7954,b''.join(selectors))],{'owner':15,'selectors':102,'bytes':408,'source_actions':[48,49],'styles':[0,2]}
