"""Reconstruct nine complete Boxer metadata directories through original generations."""
import hashlib
import struct
import public_kit_evil_palette_directories as evil
import public_kit_fei_body_directories as fei
from public_kit_color_arena import resources
from public_kit_graphics import require

ROLES=('primary','effects','prefix','special','bank_words','color_deltas','roots','indices','events')


def construct(inputs,recipe):
    from cps2_crypt import decrypt_rom
    digest=lambda b:hashlib.sha256(b).hexdigest()
    require(set(inputs)==set(recipe['inputs'])=={'arcade','comp2','key'},'Complete metadata source inventory')
    for name,blob in inputs.items():
        pin=recipe['inputs'][name]
        require(len(blob)==pin['bytes'] and digest(blob)==pin['sha256'],'Original metadata input '+name)
    raw=inputs['arcade'];ops=decrypt_rom(raw[:0x100000],inputs['key'])[0]
    selected={k:inputs[k]for k in ('arcade','comp2')}
    colors=dict(evil.construct(selected,recipe['evil_recipe'])[0])
    body=dict(fei.construct({'arcade':raw},recipe['fei_recipe'])[0])
    _,arena=resources(inputs['comp2'],raw,recipe['region'])[0][0]
    bases={'primary':colors[0xba6000],'effects':colors[0xba6b00],'prefix':colors[0xba6c48],
           'special':arena[-128:]+struct.pack('>2I',0xbbc088,0xbbc088),
           'bank_words':ops[0x2fc94:0x2fcd4]+bytes(4),'color_deltas':raw[0x32c094:0x32c0d4]+bytes(4),
           'roots':body[0xb09b50],'indices':body[0xb09788],'events':body[0xb09810]}
    # The standalone Fei helper also emits a later batch8 edit to its retained
    # directory. These generations were copied before that specific write.
    selectors=bytearray(bases['indices']);selectors[52:56]=raw[0xde320+52:0xde320+56];bases['indices']=bytes(selectors)
    require(tuple(r['role']for r in recipe['tables'])==ROLES,'Complete nine metadata arrays')
    writes=[];proof=[]
    for row in recipe['tables']:
        role=row['role'];stride=row['stride'];payload=bases[role]
        require(len(payload)==34*stride and digest(payload)==row['dee']['previous_34_rows_sha256'],'Complete original34 prefix '+role)
        payload+=row['dee_value'].to_bytes(stride,'big')
        require(digest(payload)==row['shin']['previous_35_rows_sha256'],'Complete original35 prefix '+role)
        payload+=bytes(stride)+row['shin_value'].to_bytes(stride,'big')
        require(payload[35*stride:36*stride]==bytes(stride),'Original Hawk held row '+role)
        require(digest(payload[:35*stride])==row['hawk']['retained_0_through_34_sha256'] and payload[36*stride:].hex()==row['hawk']['retained_Shin_row_hex'],'Complete Hawk retained projections '+role)
        payload=payload[:35*stride]+row['hawk_value'].to_bytes(stride,'big')+payload[36*stride:]
        require(digest(payload)==row['boxer']['previous37_sha256'],'Complete original37 prefix '+role)
        payload+=payload[21*stride:22*stride]
        require(len(payload)==38*stride and digest(payload)==row['sha256'],'Complete Boxer metadata array '+role)
        payload=bytearray(payload)
        require([r['owner']for r in row['overlays']]==([21,27,15]if role=='indices'else[21,27]if role=='roots'else[21]if role=='events'else[]),'Complete original post-Boxer overlay domain')
        for change in row['overlays']:
            at=change['owner']*4;value=struct.pack('>I',change['value'])
            require(payload[at:at+4].hex()==change['before_hex'] and digest(value)==change['sha256'],'Original whole pointer overlay preimage/value')
            payload[at:at+4]=value
        for change in row['reviewed_pointer_edits']:
            at=change['offset'];before=bytes.fromhex(change['before']);after=bytes.fromhex(change['after'])
            require(role=='indices' and at//4 in (13,15) and len(before)==len(after) and at%4+len(before)==4,'Reviewed complete pointer suffix domain')
            require(payload[at:at+len(before)]==before,'Reviewed pointer preimage')
            payload[at:at+len(after)]=after
        payload=bytes(payload)
        writes.append((row['address'],payload));proof.append({'role':role,'bytes':len(payload),'sha256':digest(payload)})
    require(sum(len(v)for _,v in writes)==1216,'Complete metadata family extent')
    return writes,{'bytes':1216,'arrays':proof,'owner_generations':[34,35,37,38]}
