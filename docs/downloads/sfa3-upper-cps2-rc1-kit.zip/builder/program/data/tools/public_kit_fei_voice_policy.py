"""Reconstruct the complete original Fei cue policy and two command bases."""
import hashlib
import struct
from public_kit_graphics import require


def construct(inputs,recipe):
    digest=lambda b:hashlib.sha256(b).hexdigest()
    require(set(inputs)==set(recipe['inputs'])=={'comp2'} and recipe['source_region']=='jp','Original inherited voice policy source')
    source=inputs['comp2'];pin=recipe['inputs']['comp2']
    require(len(source)==pin['bytes'] and digest(source)==pin['sha256'],'Whole original voice component')
    base=0x60b080;directory=0x751c38
    require(recipe['directory']==directory,'Original voice-owner reader directory')
    owners=source[directory-base:directory-base+160]
    require(len(owners)==160 and digest(owners)==recipe['directory_sha256'],'Complete original40-owner voice directory')
    root=struct.unpack_from('<I',owners,33*4)[0];require(root==recipe['root'] and 0<=root-base<=len(source)-176,'Original Fei policy root/extent')
    original=source[root-base:root-base+176]
    require(digest(original)==recipe['source_policy_sha256'],'Complete original22-record policy')
    rows=struct.unpack('<88H',original)
    require(all(rows[i+2:i+4]==(0,0)for i in range(0,88,4)) and rows[:20]==(0,0,0,0,0x220,0x220,0,0,0x221,0x221,0,0,0x222,0x222,0,0,0x223,0x223,0,0),'Original policy record grammar/common controls')
    require(all(v==0 or v in (0x220,0x221,0x222,0x223,0x242,0x252)or 0x6e0<=v<0x6f4 for i,v in enumerate(rows)if i%4<2),'Original cue command domain')
    require(recipe['command_bases']==[0x6c0,0x6e0],'Original authored Guile/Fei command bases')
    blob=struct.pack('>88H',*rows)+struct.pack('>2H',*recipe['command_bases'])
    require(len(blob)==180 and digest(blob)==recipe['sha256'],'Complete original policy/base allocation')
    return [(0xb92000,blob)],{'bytes':180,'records':22,'command_bases':2,'sha256':digest(blob)}
