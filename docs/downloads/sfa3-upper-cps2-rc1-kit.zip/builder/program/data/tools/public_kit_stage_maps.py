"""Original Upper stage maps projected into native controls/chunks/macros.

Recipes contain source owners and tile/allocation bindings, never map cells.
All consumed source domains and complete native tile pixels are checked.
"""
import hashlib
import struct
from public_kit_graphics import require

TABLES = {1:0x747f30,2:0x7480d4,3:0x748344}
CHUNKS = {1:0x69b830,2:0x6cf5f0,3:0x6ef3f0}
STRIDES = {1:64,2:128,3:512}


def project(inputs,region,owner,bindings,pixels):
    require(region in ('us','jp') and owner in (32,33,34,35),'Unknown stage source domain')
    base=0x60ad00 if region=='us' else 0x60b080
    shift=0x5700 if region=='jp' else 0
    def read(at,size):
        offset=at-base
        require(size>0 and 0<=offset<=len(inputs['comp2'])-size,'Stage source bounds')
        return inputs['comp2'][offset:offset+size]
    kind=read(0x747ee0+shift+owner*2,1)[0]
    require(kind in (0,2,4),'Unknown stage coordinate grammar')
    files={};summary={};used_bindings={n:set() for n in (1,2,3)}
    tables={}
    for layer in (1,2,3):
        rows=bindings[str(layer)]
        tables[layer]={r[0]:r[1:] for r in rows}
        require(len(tables[layer])==len(rows),'Duplicate original tile binding')
    def cell(layer,code,attr):
        require(code in tables[layer],f'Missing original stage tile binding: owner={owner} layer={layer} code={code}')
        native,bank=tables[layer][code];used_bindings[layer].add(code)
        require(bank in (0,512) and 0<=native<(16384 if layer==3 else 65536),'Native stage tile extent')
        stride={1:32,2:128,3:512}[layer]
        supply=inputs['scroll3'] if layer==3 else inputs['font']
        if layer==3:
            require(code<len(inputs['scroll3_mask']),'Original stage tile mask bounds')
            valid=inputs['scroll3_mask'][code]
            require(valid or code==0,'Missing non-null original stage tile')
        else:valid=True
        if valid:
            require((code+1)*stride<=len(supply),'Original stage artwork bounds')
            tile=supply[code*stride:(code+1)*stride]
        else:tile=b'\xff'*512
        if layer==1:tile=b''.join(tile[y*4:y*4+4]*2 for y in range(8))
        physical=(40 if bank else 8)*1024**2+native*STRIDES[layer]
        require(physical+len(tile)<=len(pixels) and pixels[physical:physical+len(tile)]==tile,
                'Complete stage tile differs from original artwork')
        return struct.pack('>HH',native,(attr&127)|bank)
    for layer in (1,2,3):
        table=TABLES[layer]+shift
        address=table+struct.unpack('<h',read(table+owner*2,2))[0]
        controls=read(address,128)
        used={0:4,2:8,4:128}[kind] if layer==1 else {2:16,3:64}[layer]
        chunks=sorted(set(controls[:used]));indices={v:i for i,v in enumerate(chunks)}
        files[f's{layer}_controls']=bytes(indices[v] for v in controls[:used])+controls[used:]
        if layer==1:
            originals=[struct.unpack('<64H',read(CHUNKS[1]+shift+c*128,128)) for c in chunks]
            macros=sorted({v for row in originals for v in row});mids={v:i for i,v in enumerate(macros)}
            files['s1_chunks']=b''.join(struct.pack('>64H',*(mids[v] for v in row)) for row in originals)
            files['s1_macros']=b''.join(cell(1,code,attr) for macro in macros
                for attr,code in struct.iter_unpack('<HH',read(0x69f3b0+shift+macro*64,64)))
        else:
            count={2:256,3:64}[layer];out=bytearray()
            for chunk in chunks:
                raw=read(CHUNKS[layer]+shift+chunk*count*3,count*3)
                codes=struct.unpack('<'+str(count)+'H',raw[:count*2])
                for code,attr in zip(codes,raw[count*2:]):
                    out.extend(cell(layer,(code+(0x1c00 if layer==2 else 0))&65535,attr))
            files[f's{layer}_chunks']=bytes(out)
        summary[str(layer)]={'chunks':len(chunks),'tiles':len(used_bindings[layer]),'consumed_controls':used,'source_codes':sorted(used_bindings[layer])}
        if layer==1:summary['1']['macros']=len(macros)
    summary['coordinate_type']=kind
    return files,summary


def construct(inputs,recipe,pixels):
    require(recipe['schema']==1,'Unknown stage recipe')
    for name,pin in recipe['inputs'].items():
        require(len(inputs[name])==pin['bytes'] and hashlib.sha256(inputs[name]).hexdigest()==pin['sha256'],
                'Original stage input identity differs: '+name)
    require(hashlib.sha256(pixels).hexdigest()==recipe['graphics_pixels_sha256'],'Reconstructed stage graphics identity differs')
    writes=[];reports={}
    require(sorted(row['owner'] for row in recipe['stages'])==[32,33,34,35],'Incomplete stage owner domain')
    for stage in recipe['stages']:
        files,report=project(inputs,recipe['region'],stage['owner'],stage['bindings'],pixels)
        require(all(set(report[str(n)]['source_codes'])=={r[0] for r in stage['bindings'][str(n)]} for n in (1,2,3)),
                'Stage recipe includes unrelated tile bindings')
        require(set(files)==set(stage['allocations']),'Incomplete native map allocation domain')
        for name,blob in files.items():
            address=stage['allocations'][name]
            require(0xa00000<=address<=0xe00000-len(blob),'Stage allocation outside upper program data')
            writes.append((address,blob))
        for n in (1,2,3):del report[str(n)]['source_codes']
        reports[str(stage['owner'])]=report
    return writes,reports
