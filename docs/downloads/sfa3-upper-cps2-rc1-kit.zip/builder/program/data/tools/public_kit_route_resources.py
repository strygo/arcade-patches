"""Complete original and historical filtered Guile/Fei/Dee route resource family."""
import hashlib
import struct
from public_kit_graphics import require


def construct(inputs,recipe):
    require(set(inputs)==set(recipe['inputs'])=={'comp2'},'Route original inventory')
    data=inputs['comp2'];pin=recipe['inputs']['comp2']
    require(len(data)==pin['bytes'] and hashlib.sha256(data).hexdigest()==pin['sha256'],'Route original identity')
    region=recipe['region'];require(region in ('us','jp'),'Route original region')
    table=0x36e01c if region=='us' else 0x37338c
    directory=data[table:table+80]
    require(hashlib.sha256(directory).hexdigest()=='eefb765d2e38078a8f7a82d29ea2074555f140e7529e92461d78dee4f5c70f5e','Complete original forty-owner route directory')
    offsets=struct.unpack('<40H',directory);sources={}
    for owner in (32,33,34):
        at=table+offsets[owner];row=data[at:at+160]
        require(len(row)==160 and max(row)<38 and len({row[i:i+10]for i in range(0,160,10)})==16,'Complete sixteen ten-opponent source choices')
        sources[owner]=row
    require(recipe['held']=={'guile':[23,33,34,35],'paired':[23,34,35,36,37]},'Reviewed historical route policies')
    def filtered(row,held):
        choices=[row[n:n+10]for n in range(0,160,10)]
        eligible=[n for n,r in enumerate(choices)if not set(r)&set(held)]
        require(eligible,'No complete eligible original route')
        mapping=[next((n+s)%16 for s in range(16)if (n+s)%16 in eligible)for n in range(16)]
        result=b''.join(choices[n]for n in mapping)
        require(not set(result)&set(held) and all(mapping[n]==n for n in eligible),'Whole-choice historical route projection')
        return result,mapping
    old,old_map=filtered(sources[32],recipe['held']['guile'])
    paired=[filtered(sources[n],recipe['held']['paired'])for n in (32,33)]
    # Reader indexes owner*2 against a directory biased by the first owner64.
    prefix=struct.pack('>2H',4+64,4+160+64)
    writes=[(0xa52000,struct.pack('>H',2)+sources[32]),(0xa55000,struct.pack('>H',2)+old),
        (0xbf8200,prefix+sources[32]+sources[33]),
        (0xbec1dc,struct.pack('>H',2+68)+sources[34])]
    return writes,{'bytes':810,'source_owners':[32,33,34],'active_policy':'complete original rows restored','choices_per_owner':16,'opponents_per_choice':10,
        'historical_guile_map':old_map,'paired_maps':{str(n):r[1]for n,r in zip((32,33),paired)}}
