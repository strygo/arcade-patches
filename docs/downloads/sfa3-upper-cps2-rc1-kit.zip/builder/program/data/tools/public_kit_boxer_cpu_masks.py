"""Complete original38-owner CPU mask table at the final Boxer extension."""
import hashlib,struct
from public_kit_graphics import require


def construct(inputs,recipe):
    require(set(inputs)==set(recipe['inputs'])=={'arcade','comp1','comp2'},'Complete original CPU mask inputs')
    for name,pin in recipe['inputs'].items():
        require(len(inputs[name])==pin['bytes']and hashlib.sha256(inputs[name]).hexdigest()==pin['sha256'],'Original CPU mask input '+name)
    region=recipe['region'];require(region in ('us','jp'),'CPU mask region')
    base=0x60b080 if region=='jp'else 0x60ad00;delta=0x70 if region=='jp'else 0
    def literal(pc):
        at=pc+delta-0x1f0040;require(0<=at<=len(inputs['comp1'])-8,'Original CPU mask reader bounds')
        hi,lo=struct.unpack_from('<2I',inputs['comp1'],at)
        require(hi>>26==15 and lo>>26==9 and (hi>>16)&31==(lo>>21)&31==(lo>>16)&31,'Actual CPU mask root producer')
        low=lo&65535;low-=65536 if low&32768 else 0
        return ((hi&65535)*65536+low)&0xffffffff
    table=literal(0x26c944);require(table==literal(0x275910),'Both CPU mask reader roots agree')
    offset=table-base;require(0<=offset<=len(inputs['comp2'])-38*128,'Complete38-owner mask directory extent')
    values=struct.unpack_from('<1216I',inputs['comp2'],offset);blob=struct.pack('>1216I',*values)
    require(blob[:4096]==inputs['arcade'][0xc845a:0xc845a+4096],'Complete32 native CPU mask row control')
    require(blob[37*128:38*128]==blob[21*128:22*128],'Original hidden Boxer mask native reuse')
    return [(0xc73e94,blob)],{'owners':38,'words_per_owner':32,'native_control_owners':32,'original_reader_roots':2,'hidden_boxer_reuses_owner21':True,'bytes':4864}
