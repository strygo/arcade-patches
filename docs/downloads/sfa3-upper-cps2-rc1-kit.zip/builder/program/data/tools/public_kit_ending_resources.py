"""Complete original compact ending libraries projected to native resources."""
import hashlib
import struct
from public_kit_actor import Data
from public_kit_frame_resources import cel
from public_kit_graphics import require

SELECTORS={32:(17,18,22,23,24,25,26,27,28,29,31,32,33),33:(2,3,4),34:(*range(14),15),35:(0,1)}
ALLOCATIONS={32:(0xa9a000,0xa96f00),33:(0xba3620,0xba3600),34:(0xc628ae,0xc6288e),35:(0xd83946,0xd83942)}

class Library(Data):
    def __init__(self,blob):super().__init__(blob,0xb83800,blob,0xb83800)
    def cel(self,at):
        kind,area,last=struct.unpack('<3H',self.read(at,6));pointer=(at+9)&~3
        require(kind==2 and last<1024 and self.read(at+6,pointer-at-6) in (b'',b'\x09\0'),'Original compact ending F2 header')
        xy=self.u32(pointer);points=struct.iter_unpack('<2h',self.read(xy,(last+1)*4))
        words=struct.unpack('<'+str(last+1)+'I',self.read(pointer+4,(last+1)*4))
        blocks=tuple((x,y,w) for (x,y),w in zip(points,words))
        require(sum(((w>>24&15)+1)*((w>>28&15)+1) for _,_,w in blocks)==area,'Original compact ending area')
        return kind,blocks

def layout(inputs,owner):
    require(owner in SELECTORS,'Unknown compact ending owner')
    data=Library(inputs['metadata'+str(owner)]);_,targets=data.root(data.base)
    todo=[targets[n] for n in SELECTORS[owner]];frames={};cels={}
    while todo:
        at=todo.pop()
        if at in frames:continue
        require(at%4==0 and len(frames)<4096,'Compact ending graph bounds/alignment')
        header=data.read(at,8);pointer=data.u32(at+4)
        nxt=data.u32(at+8) if header[1]&128 else None if header[1]&64 else at+8
        frames[at]=(header[:4],pointer,nxt,12 if header[1]&128 else 8);cels[pointer]=data.cel(pointer)
        if nxt is not None:todo.append(nxt)
    at,root=ALLOCATIONS[owner];placements={};mapping={}
    for source,(_,blocks) in sorted(cels.items()):
        xy=at;at+=len(blocks)*4;placements[source]=(at,xy);at+=10+len(blocks)*4
    for source,(_,_,_,size) in sorted(frames.items()):mapping[source]=at;at+=size
    require(at-ALLOCATIONS[owner][0]<0x3000,'Compact ending allocation bound')
    return data,targets,frames,cels,placements,mapping

def construct(inputs,recipe,pixels):
    for name,pin in recipe['inputs'].items():
        require(len(inputs[name])==pin['bytes'] and hashlib.sha256(inputs[name]).hexdigest()==pin['sha256'],'Original ending source identity: '+name)
    require(hashlib.sha256(pixels).hexdigest()==recipe['graphics_pixels_sha256'],'Reconstructed ending graphics identity')
    require([r['owner'] for r in recipe['libraries']]==list(SELECTORS),'Complete compact ending owner inventory')
    upper=pixels[32<<20:];writes=[];reports=[]
    for row in recipe['libraries']:
        owner=row['owner'];data,targets,frames,cels,placements,mapping=layout(inputs,owner)
        require(set(row['tiles'])=={str(s) for s in cels},'Complete ending cel inventory')
        for source,(destination,xy) in placements.items():
            coords,body=cel(data,source,xy,row['tiles'][str(source)],inputs['pixels'+str(owner)],inputs['mask'+str(owner)],upper,1)
            writes.extend(((xy,coords),(destination,body)))
        for source,(header,pointer,nxt,size) in sorted(frames.items()):
            destination=mapping[source];blob=header+struct.pack('>I',placements[pointer][0])
            if size==12:blob+=struct.pack('>I',mapping[nxt])
            elif nxt is not None:require(mapping[nxt]==destination+8,'Compact ending fallthrough differs')
            writes.append((destination,blob))
        root=ALLOCATIONS[owner][1]
        if owner==32:
            # Earlier full-frame selectors share this directory and have a separate producer.
            for selector in SELECTORS[owner]:writes.append((root+selector*2,struct.pack('>h',mapping[targets[selector]]-root)))
        else:
            roots=bytearray(len(targets)*2)
            for selector in SELECTORS[owner]:struct.pack_into('>h',roots,selector*2,mapping[targets[selector]]-root)
            writes.append((root,bytes(roots)))
        reports.append({'owner':owner,'frames':len(frames),'cels':len(cels),'selectors':len(SELECTORS[owner])})
    return writes,reports
