"""Complete retained Dee runtime resources, reconstructed at their original generations."""
import hashlib
import struct
from public_kit_actor import Data
from public_kit_graphics import require
from public_kit_frame_resources import owner_graph
from public_kit_color_arena import resources as color_arena
from public_kit_evil_palette_directories import construct as evil_directories

# Allocation identities exported by the original body/loop/special constructors.
BODY=(( 'indices',0xde320,0xbde7dc,0xa11000,0xb70000,0xbdcf58),
      ('events',0xde3a0,0xbde868,0xa12400,0xb9b000,0xbdd0ec),
      ('variants',0xde2a0,0xbde8f4,0xb0977c,0xb714d0,0xbde6cc),
      ('roots',0xde6a0,0xbde980,0xa12600,0xb714dc,0xbdcf28))
CALLBACKS=(('command',0x2b15e,0xbe255c,0xa2c038,0xec014,0xee414),
           ('special_human',0x28ae8,0xbe25e8,0xa2c058,0xec050,0xee484),
           ('special_cpu',0x28af4,0xbe2674,0xa2c058,0xec07a,0xee484),
           ('throw',0x29c28,0xbe29bc,0xe80c2,0xe9408,0xe6222),
           ('entrance',0x2a0a6,0xbe2a48,0xe840c,0xe8480,0xe59f8))

# Original batch8 copied-selector redirect and key-safe Guile controller relocation.
REDIRECTS=(('indices',13,0x11d6a8,0xaa52d0),('command',32,0xa2c038,0xe9c9e),
           ('special_human',32,0xa2c058,0xe9cc4),('special_cpu',32,0xa2c058,0xe9cc4))

def construct(inputs,recipe):
    from cps2_crypt import decrypt_rom
    sha=lambda b:hashlib.sha256(b).hexdigest()
    require(set(inputs)==set(recipe['inputs'])=={'arcade','key','comp2-jp','coords-jp'},'Complete inherited Dee runtime inputs')
    require(recipe['source_region']=='jp' and recipe['region'] in ('us','jp'),'Explicit original JP mechanics inheritance')
    for name,blob in inputs.items():
        pin=recipe['inputs'][name];require(len(blob)==pin['bytes'] and sha(blob)==pin['sha256'],'Original Dee input '+name)
    require(recipe['redirects']==[list(v)for v in REDIRECTS],'Complete reviewed directory relocation inventory')
    raw=inputs['arcade'];c2=inputs['comp2-jp'];data=Data(c2,0x60b080,inputs['coords-jp'],0xb04000)
    ops=decrypt_rom(raw[:0x100000],inputs['key'])[0];writes=[];controls={}
    def emit(role,at,prefix,tail):
        require(sha(prefix)==recipe['prefixes'][role],'Complete original predecessor directory '+role)
        writes.append((at,prefix+tail));controls[role]=len(prefix)
    for role,source,dest,guile,fei,dee in BODY:
        prefix=raw[source:source+128]+struct.pack('>2I',guile,fei)
        emit(role,dest,prefix,struct.pack('>I',dee))
    palette_inputs={'arcade':raw,'comp2':c2}
    palette_recipe={'inputs':{k:{'bytes':len(v),'sha256':sha(v)}for k,v in palette_inputs.items()},'region':'jp','owners':34}
    palette_writes,_=evil_directories(palette_inputs,palette_recipe)
    for role,(old,prefix),dest,dee in zip(('primary','effects','prefix'),palette_writes,(0xbdedcc,0xbdf158,0xbdf2a4),(0xbdea0c,0xbdee58,0xbdf1e4)):
        emit(role,dest,prefix,struct.pack('>I',dee))
    arena_writes,_=color_arena(c2,raw,'jp');arena=arena_writes[0][1]
    emit('special',0xbdf330,arena[-128:]+struct.pack('>2I',0xbbc088,0xbbc088),struct.pack('>I',0xbbc088))
    emit('bank_words',0xbdf3bc,ops[0x2fc94:0x2fcd4]+bytes(4),struct.pack('>H',(0x420000//0x800000)*0x2000))
    emit('color_deltas',0xbdf404,raw[0x32c094:0x32c0d4]+bytes(4),bytes(2))
    require(recipe['callbacks']==[list(v)for v in CALLBACKS],'Complete original callback allocation inventory')
    for role,operand,dest,guile,fei,dee in CALLBACKS:
        require(ops[operand-2:operand]==bytes.fromhex('207c'),'Original callback consumer opcode')
        root=struct.unpack_from('>I',ops,operand)[0];require(0<=root<=len(raw)-128,'Native whole callback directory extent')
        values=list(struct.unpack_from('>32I',raw,root))
        if role in ('command','special_human','special_cpu','entrance'):
            values[23]={'command':0xe3814,'special_human':0xe3816,'special_cpu':0xe383a,'entrance':0xe4818}[role]
        prefix=struct.pack('>34I',*(values+[guile,fei]))
        emit(role,dest,prefix,struct.pack('>I',dee))
    # Whole Air Slasher graph determines the two selector rows and seven attack rows.
    root=data.u32(0x6142c0+37*4);_,targets=data.root(root);frames=set()
    for start in targets:
        at=start;chain=set()
        while at is not None and at not in chain:
            chain.add(at);frames.add(at);require(len(frames)<=256,'Bounded original projectile graph')
            _,_,at=data.frame(at)
    require(len(targets)==4 and len(frames)==43,'Complete original Air Slasher action graph')
    require(max(data.read(a,20)[9]for a in frames)==6 and max(data.read(a,20)[8]for a in frames)==1,'Original projectile demand extents')
    bank=0x95d178;header=struct.unpack('<14h',data.read(bank,28))
    require(header[:5]==(12,12,12,12,28),'Original projectile collision grammar')
    attacks=[]
    for n in range(7):
        row=data.read(bank+28+n*32,32);attacks.append(struct.pack('>4h',*struct.unpack('<4h',row[:8]))+row[8:])
    collision=struct.pack('>14h',*header)+b''.join(attacks)
    require(sha(collision)==recipe['projectile_collision_sha256'],'Whole original projectile collision')
    writes.extend(((0xbde6d8,collision),(0xbde7d4,data.read(bank-8,8)),(0xbde6cc,struct.pack('>3I',*([0xab509c]*3)))))
    # Full shadow and cancel resources, including independent stock Ryu windows.
    body_frames,_=owner_graph(data,0x74ef38,34)
    require(max(data.read(a,20)[14]for a in body_frames)==12,'Complete body graph shadow demand')
    shadow=data.u32(0x751cd8+34*4);blob=data.read(shadow,52)
    writes.append((0xbe20c4,b''.join(blob[i:i+2][::-1]for i in range(0,52,2))))
    def windows(owner,count):
        bank=data.u32(0x74e3f8+owner*4);offsets=struct.unpack('<3h',data.read(bank,6))
        require(all(o>=6 and o%2==0 for o in offsets),'Original three-ISM cancel grammar')
        return [data.read(bank+o,count*2)for o in offsets]
    native=struct.unpack_from('>I',raw,0xddda0)[0];offsets=struct.unpack_from('>3h',raw,native)
    require(all(b==raw[native+o:native+o+68]for b,o in zip(windows(0,34),offsets)),'Complete native Ryu cancel control')
    writes.append((0xbe22f8,struct.pack('>3h',6,68,130)+b''.join(windows(34,31))))
    # Original36-row sound policy: remap only authenticated own commands; reserve tail is authored zero.
    for owner in (0,1,2,3,4,21,22,24,25,29,30,31):
        source=data.u32(0x751c38+owner*4);native=struct.unpack_from('>I',raw,0xe0aa0+owner*4)[0]
        projected=struct.pack('>20H',*struct.unpack('<20H',data.read(source,40)))
        require(projected==raw[native:native+40],'Complete five-cue native voice control')
    policy_root=data.u32(0x751c38+34*4);policy=data.read(policy_root,288)
    require(policy_root==0x639f04 and sha(policy)==recipe['voice_policy_sha256'],'Complete original Dee voice policy')
    events=data.u32(0x74eb78+34*4)
    for at in body_frames:
        event=data.read(events+data.read(at,20)[10]*4,4)
        require(event[2]<36,'Complete body event voice demand')
    require(all(data.read(at,20)[10]==0 for at in frames),'Projectile voice event domain')
    rows=list(struct.iter_unpack('<4H',policy));require(all(a==b and c==d==0 for a,b,c,d in rows),'Complete voice cue grammar')
    own={a for a,_,_,_ in rows if 0x560<=a<0x580};require(own==set(range(0x560,0x57c))|{0x57d},'Complete own voice command domain')
    values=struct.unpack('<144H',policy);values=[v-0x560+0x5e0 if v in own else v for v in values]
    writes.append((0xbe20f8,struct.pack('>144H',*values)+bytes(224)))
    require(set(controls)==set(recipe['prefixes']),'Complete predecessor witness inventory')
    require(sum(len(b)for _,b in writes)==2988,'Complete runtime packet extent')
    destinations={row[0]:row[2]for row in BODY+CALLBACKS}
    corrected=[]
    for at,payload in writes:
        blob=bytearray(payload)
        for role,owner,before,after in REDIRECTS:
            if at==destinations[role]:
                require(struct.unpack_from('>I',blob,owner*4)[0]==before,'Typed original directory relocation preimage')
                struct.pack_into('>I',blob,owner*4,after)
        corrected.append((at,bytes(blob)))
    writes=corrected
    return writes,{'bytes':2988,'owner_directories':15,'owners':35,'projectile_actions':4,'projectile_frames':43,'projectile_attacks':7,'cancel_rows_per_ism':31,'voice_rows':36,'voice_reserved_bytes':224,'predecessor_extents':controls}
