"""Original attract position arrays and six scene12 palettes, reader-bound."""
import hashlib,struct
from public_kit_graphics import require

# Original US literal producers, paired source domains and next dispatch tables.
POSITIONS=((0x3bb848,0x3bb88c,0x3bbc90,0x618390,0xac8102),
           (0x3bbed4,0x3bbf18,0x3bc220,0x6183e0,0xac8142),
           (0x3bcd28,0x3bcd6c,0x3bcfb0,0x618470,0xac8182))


def construct(inputs,recipe):
    require(set(inputs)==set(recipe['inputs'])=={'comp1','comp2'},'Complete original attract code/data inventory')
    for name,blob in inputs.items():
        pin=recipe['inputs'][name]
        require(len(blob)==pin['bytes']and hashlib.sha256(blob).hexdigest()==pin['sha256'],'Original attract component identity')
    region=recipe['region'];require(region in ('us','jp'),'Original attract region')
    require(recipe['position_rows']==[list(v)for v in POSITIONS]and recipe['band_palettes']==6,'Complete source reader/allocation inventory')
    c1,c2=inputs['comp1'],inputs['comp2'];dc=0x70 if region=='jp'else 0;ds=0x10f0 if region=='jp'else 0;base=0x60b080 if region=='jp'else 0x60ad00
    def code(at,n):
        off=at-0x1f0040;require(0<=off<=len(c1)-n*4,'Original code extent');return struct.unpack_from('<'+str(n)+'I',c1,off)
    def literal(at):
        hi,lo=code(at,2);require(hi>>26==15 and lo>>26==9 and hi>>16&31==lo>>21&31==lo>>16&31,'Original LUI/ADDIU pointer producer')
        low=lo&65535;return((hi&65535)*65536+(low-65536 if low&32768 else low))&0xffffffff
    def read(at,n):
        require(n>0 and 0<=at-base<=len(c2)-n,'Original whole attract array extent');return c2[at-base:at-base+n]
    def swapped(blob):return b''.join(blob[i:i+2][::-1]for i in range(0,len(blob),2))
    writes=[];witness=[]
    for ordinary,upper,next_dispatch,source,target in POSITIONS:
        ordinary+=dc;upper+=dc;next_dispatch+=dc;source+=ds
        require(literal(ordinary)==source and literal(upper)==source+32,'Original paired ordinary/Upper table roots')
        require(literal(next_dispatch)==source+64,'Complete paired position extent at next dispatch table')
        require(code(upper-16,4)==(0x3c027000,0x8c421150,0x10400005,0),'Actual Upper-mode branch and delay slot')
        require(code(ordinary+8,2)==code(upper+8,2)==(0x3c027000,0xac431120),'Both branches install same position reader root')
        for ordinal in (0,1):writes.append((target+ordinal*32,swapped(read(source+ordinal*32,32))))
        witness.append({'ordinary_reader':hex(ordinary),'upper_reader':hex(upper),'source':hex(source),'rows_per_mode':8,'row_bytes':4})
    pc=0x2488dc+dc;source=0x73a0f0+(0x5700 if region=='jp'else 0)
    require(code(pc-16,4)==(0x3c027000,0x8c421150,0x10400005,0),'Scene12 original Upper-mode branch')
    require(literal(pc)==source and code(pc+8,2)==(0x3c027000,0xac431100),'Scene12 original palette source installation')
    require(code(pc+32,1)==(0x24030005,),'Original six-palette inclusive copy count')
    writes.append((0xac8042,swapped(read(source,6*32))))
    return writes,{'bytes':384,'position_tables':6,'position_rows':48,'position_reader_witnesses':witness,'scene12_palettes':6,'scene12_reader':hex(pc),'unclaimed':'Script/scene owner tables and palette cycle tables remain separate.'}
