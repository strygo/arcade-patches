"""Complete retained Dhalsim X selector and collision resources from originals."""
import hashlib
import struct
import public_kit_dhalsim_tables as tables
from public_kit_graphics import require


def project(inputs,recipe):
    require(set(inputs)==set(recipe['inputs'])=={'arcade','comp2'},'Complete retained Dhalsim source inventory')
    for name,value in inputs.items():
        pin=recipe['inputs'][name]
        require(len(value)==pin['bytes'] and hashlib.sha256(value).hexdigest()==pin['sha256'],'Original retained Dhalsim source '+name)
    require(recipe['region']in ('us','jp'),'Original retained Dhalsim region')
    source,native=tables.original_model(inputs['arcade'],inputs['comp2'],recipe['region'])
    direct=tables.direct_projection(source,native)
    require(native.indices==0xa82700 and native.variants==[0x121cd8,0xa8286c,0x121cd8],'Complete original retained Dhalsim table bindings')
    selector=native.read(native.indices,91*4)
    bank=native.variants[1];offsets=struct.unpack('>5h',native.read(bank,10))
    require(offsets[0]==10 and all(a<b and (b-a)%8==0 for a,b in zip(offsets,offsets[1:])),'Complete retained collision lane grammar')
    collision=native.read(bank,offsets[4]+95*32)
    frames=[at for family in native.families[4:8]for rows,_ in family for at in rows]
    require(frames and max(native.blob[at+8]for at in frames)==90 and max(native.blob[at+9]for at in frames)==94,'Complete retained X selector/attack domains')
    for at in frames:
        index=native.blob[at+8]
        require(all(row<(offsets[lane+1]-offsets[lane])//8 for lane,row in enumerate(selector[index*4:index*4+4])),'Actual retained X collision lane demand')
    writes=[(0xa82700,selector),(bank,collision)]
    return writes,{'bytes':sum(len(b)for _,b in writes),'selector_rows':91,'attack_rows':95,'source_projection_bytes':direct,'frame_contexts':len(frames),'resources':[{'address':at,'bytes':len(blob),'sha256':hashlib.sha256(blob).hexdigest()}for at,blob in writes]}


def construct(inputs,recipe):
    writes,report=project(inputs,recipe)
    require(report['resources']==recipe['resources'],'Whole retained Dhalsim resource identities')
    return writes,report


def main():
    import argparse
    import json
    from pathlib import Path
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--region',choices=('us','jp'),required=True)
    for name in ('pools','recipe','out'):p.add_argument('--'+name,type=Path,required=True)
    a=p.parse_args()
    members=('sz3j.03c','sz3j.04c','sz3.05c','sz3.06c','sz3.07c','sz3.08c','sz3.09c','sz3.10b')
    packed=b''.join((a.pools/('arcade-jp-'+n)).read_bytes()for n in members)
    native=bytearray(len(packed));native[::2]=packed[1::2];native[1::2]=packed[::2]
    inputs={'arcade':bytes(native),'comp2':(a.pools/f'ps2-{a.region}-comp2.bin').read_bytes()}
    writes,report=construct(inputs,json.loads(a.recipe.read_text())[a.region])
    data=bytearray(0x400000);mask=bytearray(len(data))
    for at,blob in writes:
        offset=at-0xa00000;require(0<=offset<=len(data)-len(blob),'Whole retained upper resource extent')
        data[offset:offset+len(blob)]=blob;mask[offset:offset+len(blob)]=b'\1'*len(blob)
    a.out.mkdir();(a.out/'data.bin').write_bytes(data);(a.out/'data.mask').write_bytes(mask)
    (a.out/'compiled.json').write_text(json.dumps(report,sort_keys=True)+'\n')


if __name__=='__main__':main()
