"""Both original Shin result labels, complete type12 commands and font blocks."""
import hashlib
import struct
from public_kit_graphics import require

FAMILIES=((0,2,10,0xc5a740,0xc5a774),(1,46,8,0xc5a79c,0xc5a7c8))


def source(comp2,region,mode,selector,count):
    base=0x60ad00 if region=='us'else 0x60b080
    table=0x35ba40 if region=='us'else 0x360dc0
    mapping=0xbb50 if region=='us'else 0xc8c0
    require(comp2[mapping+mode*40+36]==selector,'Original Shin result mode mapping')
    at=table+struct.unpack_from('<H',comp2,table+selector*2)[0]
    ptr=struct.unpack_from('<I',comp2,at+4)[0]-base
    kind,total,last,pad,xy=struct.unpack_from('<4HI',comp2,ptr)
    require(kind==12 and last==count-1 and pad==0,'Original Shin complete type12 grammar')
    require(0<=xy-base<=len(comp2)-count*4,'Original Shin coordinate extent')
    points=list(struct.iter_unpack('<hh',comp2[xy-base:xy-base+count*4]))
    commands=list(struct.iter_unpack('<HH',comp2[ptr+12:ptr+12+count*4]))
    measured=sum(((a>>8&15)+1)*((a>>12&15)+1)for _,a in commands)
    require(len(commands)==count and 0<=measured-total<=5,'Original Shin command extent and budget')
    return at,points,commands,measured


def construct(inputs,recipe,pixels):
    for name,pin in recipe['inputs'].items():
        value=inputs[name];require(len(value)==pin['bytes'] and hashlib.sha256(value).hexdigest()==pin['sha256'],'Original Shin label input identity: '+name)
    require(hashlib.sha256(pixels).hexdigest()==recipe['pixels_sha256'],'Qualified Shin label graphics identity')
    require(len(recipe['families'])==len(FAMILIES),'Complete two-mode label inventory')
    writes=[];reports=[]
    for (mode,selector,count,target,frame_at),row in zip(FAMILIES,recipe['families']):
        at,points,commands,total=source(inputs['comp2'],recipe['region'],mode,selector,count)
        require(len(row['tiles'])==count,'Complete Shin label block allocations')
        converted=[];checked=0
        for (code,attr),native in zip(commands,row['tiles']):
            require(0<=native<65536,'Shin label tile allocation extent')
            for y in range((attr>>12&15)+1):
                for x in range((attr>>8&15)+1):
                    old=(code&~15)+((code+x)&15)+16*y
                    new=(native&~15)+((native+x)&15)+16*y
                    tile=inputs['font'][(old+0x1c00)*128:(old+0x1c01)*128]
                    physical=(new+0x16c00)*128
                    require(len(tile)==128 and pixels[physical:physical+128]==tile,'Complete original Shin label block pixels')
                    checked+=1
            converted.append((native,attr))
        require(checked==total,'Complete Shin label tile accounting')
        coords=b''.join(struct.pack('>hh',*point)for point in points)
        cel=struct.pack('>3HI',12,total,count-1,target-count*4)+b''.join(struct.pack('>HH',*command)for command in converted)
        frame=inputs['comp2'][at:at+4]+struct.pack('>I',target)
        writes.extend(((target-count*4,coords+cel),(frame_at,frame)))
        reports.append({'mode':mode,'commands':count,'tiles':total,'bytes':len(coords)+len(cel)+8})
    return writes,reports
