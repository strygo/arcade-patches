"""Complete original Shin action directories and three-ISM root bank.

This qualifies table projections only; pointed-to frame and artwork allocations
remain separately qualified resources.
"""
import hashlib
import struct
from public_kit_actor import Data
from public_kit_graphics import require

COUNTS=(67,48,73,35)
ROOTS=(0xc4535a,0xc453e2,0xc45444,0xc454d8)
BANK=0xc45520


def construct(comp2,recipe):
    pin=recipe['input']
    require(len(comp2)==pin['bytes'] and hashlib.sha256(comp2).hexdigest()==pin['sha256'],'Original Shin source identity')
    data=Data(comp2,recipe['base'],b'',0xb04000)
    roots=struct.unpack('<12I',data.read(data.u32(recipe['owner_table']+36*4),48))
    require(roots[:4]*3==roots and len(set(roots))==4,'Original Shin complete ISM root aliases')
    targets=[data.root(root)[1]for root in roots[:4]]
    require(tuple(map(len,targets))==COUNTS,'Complete original Shin family extents')
    mapping=dict(recipe['frames'])
    require(len(mapping)==len(recipe['frames']) and set(mapping)==set().union(*map(set,targets)),
            'Complete Shin root target allocation inventory')
    require(all(0xc40000<=at<ROOTS[0] for at in mapping.values()),'Shin frame allocation outside owned range')
    writes=[]
    for root,rows in zip(ROOTS,targets):
        offsets=[mapping[target]-root for target in rows]
        require(all(-32768<=offset<0 for offset in offsets),'Shin signed root reach')
        writes.append((root,struct.pack('>'+str(len(rows)+1)+'h',*offsets,0)))
    aliases=dict(zip(roots[:4],ROOTS));writes.append((BANK,struct.pack('>12I',*(aliases[root]for root in roots))))
    return writes,{'family_entries':list(COUNTS),'root_terminators':4,'ISM_variants':3,'table_bytes':502,
                  'qualification':'Complete directories only; frame/artwork closure separate'}
