"""Complete source-derived Dolls ending palette packets and parameter triples."""
import hashlib,struct
from public_kit_graphics import require
from public_kit_ending_palette_tables import inventory
from public_kit_ending_family_tables import construct as families
from public_kit_ending_colors import construct as colors
from public_kit_dee_ending_colors import construct as dee_colors
from public_kit_resident_palettes import resources as residents
from public_kit_color_arena import resources as arena
from public_kit_palettes import catalog


def construct(inputs,recipe):
    require(set(inputs)==set(recipe['inputs'])=={'arcade','comp2'},'Complete Dolls palette source inventory')
    for name,blob in inputs.items():
        pin=recipe['inputs'][name]
        require(len(blob)==pin['bytes'] and hashlib.sha256(blob).hexdigest()==pin['sha256'],'Original Dolls palette input identity')
    region=recipe['region'];require(region in ('us','jp'),'Original display region')
    raw=inputs['arcade'];c2=inputs['comp2'];base=0x60b080 if region=='jp'else 0x60ad00;ds=0x10f0 if region=='jp'else 0
    def read(at,n):
        require(n>0 and 0<=at-base<=len(c2)-n,'Original Dolls palette bounds');return c2[at-base:at-base+n]
    def u32(at):return struct.unpack('<I',read(at,4))[0]
    context=bytearray(0xe00000);context[:len(raw)]=raw
    covered=bytearray(len(context));covered[:len(raw)]=b'\1'*len(raw)
    def install(writes):
        for at,blob in writes:
            require(0<=at<=len(context)-len(blob),'Source palette installation extent')
            context[at:at+len(blob)]=blob;covered[at:at+len(blob)]=b'\1'*len(blob)
    for fn in (residents,arena):install(fn(c2,raw,region)[0])
    arrays=catalog(c2,region)
    for name,at in (('primary:32',0x3fa000),('head:32',0x3daf00),('head:4',0x34da14)):
        install([(at,arrays[name][1])])
    chain=recipe['family_chain'];fw,_=families(c2,raw,chain)
    install(fw);install(colors(c2,chain['colors'])[0]);install(dee_colors(c2,chain['dee_colors'])[0])
    # The Guile private prefix is a complete source-owned array.
    install([(chain['guile_private'],arrays['ending:32:private'][1])])
    prefix=dict(fw)[0xc82f1a];require(len(prefix)==148,'Complete original Boxer family4 predecessor')
    struct.pack_into('>I',context,0x26b74,0xc82f1a)
    def native(at,n):
        require(n>0 and 0<=at<=len(context)-n,'Native palette context bounds')
        require(all(covered[at:at+n]),f'Uninstalled palette context range {at:x}+{n}')
        return bytes(context[at:at+n])
    def graph(reader,at,budget,endian,roots):
        result=[];remaining=budget
        for _ in range(64):
            fields=struct.unpack(endian+'4H',reader(at,8));family,slot,offset,count=fields
            require(family%4==0 and family<=72 and slot%(4 if family<=8 else 2)==0 and 0<count<=32,'Complete palette row grammar')
            table=struct.unpack(endian+'I',reader(roots+family,4))[0]
            ptr=struct.unpack(endian+('I'if family<=8 else'h'),reader(table+slot,4 if family<=8 else 2))[0]
            source=(ptr if family<=8 else table+ptr)+(offset-65536 if offset&32768 else offset)
            n=min(count,remaining);blob=reader(source,n*32)
            if endian=='<':blob=b''.join(blob[i:i+2][::-1]for i in range(0,len(blob),2))
            result.append((fields,blob));remaining-=n;at+=8
            if not remaining:return result
        raise ValueError('Unbounded source palette graph')
    typed=inventory(raw);writes=[];reports={}
    for owner,start,extent,parameter in ((30,0xca0d00,1824,0xca0482),(31,0xca207c,1816,0xca0cfa)):
        root=u32(0x60b5a0+ds+owner*4);at=u32(0x60b860+ds+owner*4)
        require(at==u32(0x60b910+ds+owner*4),'Dolls ending command modes')
        demands=set()
        for _ in range(2048):
            timer,tag=struct.unpack('<2H',read(at,4));arity=tag&15;vals=struct.unpack('<'+str(arity)+'H',read(at+4,arity*2))if arity else()
            group,opcode,kind=tag>>4&7,tag>>8&15,tag>>12
            if group==0 and opcode in (1,5) and not(opcode==5 and kind==15):
                selectors=vals[4:8]if opcode==1 else vals[1:5];require(len(selectors)==4,'Four-group palette request');demands.update(zip(selectors,(30,32,32,32)))
            if group==0 and opcode==2:
                if kind in (0,5):require(not vals,'Cached palette request')
                else:require(kind in (1,3) and len(vals)==4,'Palette-only command');demands.update(zip(vals,(30,32,32,32)))
            if group==0 and opcode==9:
                require(len(vals)==4 and 0<vals[3]<=32,'Single palette command');demands.add((vals[1],vals[3]))
            at+=4+arity*2
            if tag>>8==0 and tag&0x70==0:break
        else:raise ValueError('Unbounded source command stream')
        require(len(demands)==(10 if owner==30 else 19),f'Complete original palette demand census owner={owner}: {sorted(demands)}')
        graphs={(s,b):graph(read,u32(root+s*4),b,'<',0x60b560+ds)for s,b in demands}
        directory=bytearray((max(s for s,_ in demands)+1)*4);packet=bytearray(directory);cells=bytearray(prefix);private={};emitted=[]
        def add(blob):
            at=start+len(packet);packet.extend(blob);return at
        for selector in sorted({s for s,_ in demands}):
            budgets=sorted(b for s,b in demands if s==selector);budget=budgets[-1];rows=graphs[selector,budget];wanted=b''.join(b for _,b in rows);matches=[]
            for _,_,b,address,blob in typed:
                if b<budget or blob[:budget*32]!=wanted:continue
                if all(b''.join(v for _,v in graph(native,address,n,'>',0x26b70))==b''.join(v for _,v in graphs[selector,n])for n in budgets):matches.append(address)
            if matches:address=matches[0]
            else:
                converted=[]
                for fields,blob in rows:
                    f,s,o,n=fields
                    try:
                        table=struct.unpack('>I',native(0x26b70+f,4))[0];ptr=struct.unpack('>I'if f<=8 else'>h',native(table+s,4 if f<=8 else 2))[0]
                        same=native((ptr if f<=8 else table+ptr)+(o-65536 if o&32768 else o),len(blob))==blob
                    except struct.error:same=False
                    if not same:
                        if blob not in private:
                            color=add(blob);private[blob]=len(cells);cells.extend(struct.pack('>I',color))
                        fields=(4,private[blob],0,n)
                    converted.append(struct.pack('>4H',*fields))
                address=add(b''.join(converted));emitted.append(selector)
            struct.pack_into('>I',directory,selector*4,address)
        packet[:len(directory)]=directory;family=add(cells)
        require(len(packet)==extent and len(private)==(2 if owner==30 else 3),'Complete original palette allocation extent')
        require(emitted==([0,1,2,3,6]if owner==30 else[0,1,2,3,4,15]),'Complete emitted palette selector domain')
        install([(start,packet)]);struct.pack_into('>I',context,0x26b74,family)
        for (s,b),rows in graphs.items():
            target=struct.unpack_from('>I',directory,s*4)[0]
            require(b''.join(v for _,v in graph(native,target,b,'>',0x26b70))==b''.join(v for _,v in rows),'Complete requested palette budget reproduction')
        if owner==31:require([struct.unpack_from('>I',directory,s*4)[0]for s in (12,13,14)]==[0x31cadc,0x31cae4,0x31caec],'Source-restored Juni palette-only selectors')
        parameters=struct.unpack('<3H',read(0x60b9c0+ds+owner*6,6));writes.extend([(parameter,struct.pack('>3H',*parameters)),(start,bytes(packet))]);prefix=bytes(cells)
        reports[str(owner)]={'packet_bytes':extent,'parameters':3,'source_requests':len(demands),'private_color_spans':len(private),'all_budget_prefixes_verified':True}
    return writes,reports
