"""Encode approved authored English text using the original arcade font.

Unchanged Capcom text is excluded from this recipe and remains media-sourced.
No rendered glyphs, encoded game records or coordinate arrays are embedded.
"""
import hashlib
import struct
from public_kit_graphics import require


def encode(rows,mode,advance,pixels):
    require(1<=len(rows)<=2 and all(row and row==row.strip() and all(32<=ord(c)<127 for c in row) for row in rows),
            'Invalid approved ASCII rows')
    require(mode in ('quote','BIO','DLG','END') and 4<=advance<=8,'Unqualified text layout')
    require(sum(map(len,rows))<=(90 if mode=='quote' else 64),'Native text capacity')
    tiles={ch:[p for byte in pixels[(0x16c00+0x280+ord(ch))*128:(0x16c00+0x280+ord(ch)+1)*128]
               for p in (byte&15,byte>>4)] for ch in set(''.join(rows))}
    require(all(len(v)==256 and (ch==' ' or any(p!=15 for p in v)) for ch,v in tiles.items()),'Original ASCII font missing')
    record=bytearray();coordinates=[]
    for row,text in enumerate(rows):
        x=0;points=[]
        for ch in text:
            x+=advance if ch==' ' and mode=='quote' else 8
            points.extend((x+i%16,i//16) for i,pen in enumerate(tiles[ch]) if pen!=15)
        require(points,'Empty original glyph ink')
        low,high=min(x for x,y in points),max(x for x,y in points)+1
        if mode=='quote':
            require(high-low<=316,'Quote exceeds blue panel')
            cursor=34+(316-(high-low))//2-57-low
        elif mode=='BIO':
            require(len(text)<=32,'Opening exceeds native columns')
            cursor=9+(32-len(text))*4
        else:
            require(len(text)<=32,'Paragraph exceeds native columns')
            cursor=(240-7*len(text))//2
            if cursor+high>272:cursor+=(272-(high-low))//2-(cursor+low)
            require(0<=cursor+low<cursor+high<=272,'Paragraph ink exceeds native column')
        require(-128<=cursor<=127 or mode=='BIO' and 0<=cursor<=255,'Native cursor range')
        record.extend(bytes([cursor&255])+text.encode('ascii')+b'\0')
        x=cursor if cursor<128 else cursor-256
        for ch in text:
            x+=advance if ch==' ' and mode=='quote' else 8
            coordinates.append((x,row*16))
    if len(rows)==1:record.append(0x70)
    return bytes(record),b''.join(struct.pack('>hh',*xy) for xy in coordinates)


def construct(pixels,recipe):
    require(recipe['schema']==1 and hashlib.sha256(pixels).hexdigest()==recipe['font_pixels_sha256'],'Original font identity differs')
    writes=[];seen=set()
    for row in recipe['records']:
        require(row['id'] not in seen and row['action'] in ('translate','retranslate'),'Duplicate or non-authored text recipe')
        seen.add(row['id'])
        require(hashlib.sha256('\n'.join(row['approved_rows']).encode()).hexdigest()==row['approved_sha256'],'Approved English text changed')
        require(' '.join(' '.join(row['rows']).split())==' '.join(' '.join(row['approved_rows']).split()),'Layout changes approved wording')
        blob,coords=encode(row['rows'],row['mode'],row['advance'],pixels)
        address=row['address'];require(0xa00000<=address<=0xe00000-len(blob),'English text allocation bounds')
        writes.append((address,blob))
        if row['coordinates'] is not None:
            require(row['mode']=='quote' and 0xa00000<=row['coordinates']<=0xe00000-len(coords),'Quote coordinate allocation bounds')
            writes.append((row['coordinates'],coords))
    return writes
