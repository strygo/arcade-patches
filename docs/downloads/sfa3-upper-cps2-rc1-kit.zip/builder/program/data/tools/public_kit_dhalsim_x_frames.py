"""Retained Dhalsim X frames through original Upper collision projection.

Complete actions33/56 have separate graph/Naomi amendments and are excluded.
"""
import hashlib
import struct
from public_kit_graphics import require
from public_kit_copied_directories import domain,u32
from public_kit_dhalsim_tables import original_model,direct_projection,repoint_existing,relocate_missing


def construct(inputs,recipe):
    for name,pin in recipe['inputs'].items():
        value=inputs[name];require(len(value)==pin['bytes']and hashlib.sha256(value).hexdigest()==pin['sha256'],'Original Dhalsim frame '+name+' identity')
    source,native=original_model(inputs['arcade'],inputs['comp2'],recipe['region'])
    direct_projection(source,native);repoint_existing(source,native);relocate_missing(source,native)
    event_changes=remap_events(source,native);scalar_changes=project_draw_fields(source,native)
    from public_kit_dhalsim_directory import domain as xdomain,START,ROOT
    _,targets,records,_=xdomain(inputs['arcade'])
    cursor=START;mapping={}
    for at,blob in records.items():mapping[at]=cursor;cursor+=len(blob)
    require(cursor==ROOT and len(records)==480,'Complete retained X allocation extent')
    excluded={a for action in (33,56)for a in native.families[7][action][0]};writes=[]
    require(excluded and excluded<=set(mapping.values()),'Whole amended actions belong to retained allocation')
    for at,blob in records.items():
        target=mapping[at]
        if target in excluded:continue
        value=native.read(target,len(blob))
        if value[1]&128:require(u32(value,20)in mapping.values(),'Retained X successor closure')
        writes.append((target,value))
    return writes,{'frames':len(writes),'excluded_whole_actions':[33,56],'excluded_whole_graph_frames':len(excluded),'bytes':sum(len(v)for _,v in writes),'event_remaps':event_changes,'draw_field_projections':scalar_changes,'artwork':'separate qualification'}


def remap_events(source,native):
    demands={};tainted=set();used=set()
    for slot,family in enumerate(native.families):
        for action,(frames,loop)in enumerate(family):
            sf,sl=source.families[slot][action]
            used.update(native.blob[a+10]for a in frames)
            if len(sf)!=len(frames)or sl!=loop:tainted.update(frames);continue
            for at,src in zip(frames,sf):
                value=source.read(source.events+source.read(src,20)[10]*4,4)
                demands.setdefault(at,set()).add(value)
    changes=0
    for at,values in demands.items():
        if at in tainted or len(values)!=1:continue
        wanted=next(iter(values));current=native.read(native.events+native.blob[at+10]*4,4)
        if wanted==current:continue
        indices=[i for i in sorted(used)if native.read(native.events+i*4,4)==wanted]
        if indices:native.blob[at+10]=indices[0];changes+=1
    return changes


def project_draw_fields(source,native):
    # Native frame bytes14/15 feed shadow-row and draw-priority consumers.
    demands={};tainted=set()
    for slot,family in enumerate(native.families):
        for action,(frames,loop)in enumerate(family):
            sf,sl=source.families[slot][action]
            if len(sf)!=len(frames)or sl!=loop:tainted.update(frames);continue
            for at,src in zip(frames,sf):
                demands.setdefault(at,set()).add(source.read(src,20)[14:16])
    changed=0
    for at,values in demands.items():
        if at in tainted or len(values)!=1:continue
        value=next(iter(values))
        if native.read(at+14,2)!=value:native.blob[at+14:at+16]=value;changed+=1
    return changed
