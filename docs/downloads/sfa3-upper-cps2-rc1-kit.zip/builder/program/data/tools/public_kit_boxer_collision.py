"""Complete hidden Boxer collision packet from original source records and typed repairs."""
import hashlib
import struct
from public_kit_actor import Data
from public_kit_frame_resources import owner_graph
from public_kit_graphics import require

BANK=0xc725e4
STYLES=0xc732a8
DIRECTORY=0xc732b4
# Original fixes7 reviewed Naomi projection; field20 is doubled impact subtype; field18 is the chip gate.
AMENDMENTS=((6,2,'>h',35,50),(6,20,'B',2,0),(7,20,'B',4,0),
            (8,20,'B',4,0),(10,0,'>h',-52,-61),(10,2,'>h',44,75),
            (10,4,'>h',23,32),(28,18,'B',6,0))
CONTEXTS=((3,13,6),(3,14,7),(3,14,8),(3,16,6),(3,19,10),(3,22,10),(2,30,28))
ORDINARY_AMENDMENTS=((13,15,5,1),(14,15,6,2),(15,15,6,2),(16,15,7,3),(17,15,7,3),
    (22,15,5,1),(23,15,6,2),(24,15,7,3),(28,15,5,1),(29,15,6,2),(30,15,7,3),
    (34,15,5,1),(35,15,6,2),(36,15,7,3),(37,15,8,4),(67,18,6,0))
ORDINARY_CONTEXTS=(((13,14,15,16,17),((3,6),(3,7),(3,8),(3,9),(3,10),(3,11))),
    ((22,23,24),((3,15),(3,16),(3,17))),((28,29,30),((3,21),(3,22),(3,23))),
    ((34,35,36,37),((3,27),(3,28),(3,29),(2,4))),((67,),((2,30),)))
ADDED=(0xb0977c,0xb714d0,0xbde6cc,0xd7bc58,0xc3c5a4,STYLES)


def construct(inputs,recipe):
    require(recipe['schema']==1 and set(inputs)==set(recipe['inputs'])=={'arcade','comp2-jp','coords-jp'},'Complete Boxer source inventory')
    for name,blob in inputs.items():
        pin=recipe['inputs'][name]
        require(len(blob)==pin['bytes'] and hashlib.sha256(blob).hexdigest()==pin['sha256'],'Original Boxer source identity')
    require(recipe['amendments']==[list(v)for v in AMENDMENTS] and recipe['added_variants']==list(ADDED) and recipe['ordinary_amendments']==[list(v)for v in ORDINARY_AMENDMENTS], 'Complete reviewed Boxer amendment and directory inventory')
    r=recipe['region'];require(r in ('us','jp') and recipe['source_region']=='jp','Inherited canonical JP Boxer mechanics');shift=0x5700
    data=Data(inputs['comp2-jp'],0x60b080,inputs['coords-jp'],0xb04000)
    raw=inputs['arcade'];long=lambda at:struct.unpack_from('>I',raw,at)[0]
    frames,_=owner_graph(data,0x749838+shift,37)
    maximum=max(data.read(at,20)[9]for at in frames)
    require(maximum==82,'Whole hidden Boxer83-row attack domain')
    variants=data.u32(0x749338+shift+37*4);native_variant=long(0xde2a0+21*4)
    banks=[]
    for style in range(3):
        source=data.u32(variants+style*4);offsets=struct.unpack('<5h',data.read(source,10))
        require(offsets==(12,268,396,524,612) and data.read(source+10,2)==bytes(2),'Original padded collision lane grammar')
        native=long(native_variant+style*4);native_offsets=struct.unpack_from('>5h',raw,native)
        lanes=data.read(source+12,600);lanes=b''.join(lanes[i:i+2][::-1]for i in range(0,len(lanes),2))
        require(lanes==raw[native+native_offsets[0]:native+native_offsets[4]],'Complete original native21 lane control')
        rows=[]
        for index in range(83):
            row=data.read(source+612+index*32,32)
            rows.append(b''.join(row[i:i+2][::-1]for i in range(0,8,2))+row[8:])
        banks.append(struct.pack('>5h',*offsets)+bytes(2)+lanes+b''.join(rows))
    require(len(set(banks))==1 and len(banks[0])==3268,'Complete Boxer style-bank identity and extent')
    roots=struct.unpack('<12I',data.read(data.u32(0x749838+shift+37*4),48));witness=[]
    for style in range(3):
        for family,action,index in CONTEXTS:
            _,actions=data.root(roots[style*4+family]);at=actions[action];seen=set();used=set()
            while at is not None and at not in seen:
                seen.add(at);used.add(data.read(at,20)[9]);_,_,at=data.frame(at)
            require(index in used,'Reviewed Boxer repair lacks original full-action context')
            witness.append([style,family,action,index,len(seen)])
    require({v[0]for v in AMENDMENTS}<={v[2]for v in CONTEXTS},'Every amended row has an original action witness')
    corrected=bytearray(banks[0])
    for index,field,fmt,before,after in AMENDMENTS:
        at=612+index*32+field
        require(struct.unpack_from(fmt,corrected,at)[0]==before,f'Original typed Boxer repair preimage row{index} field{field}: {struct.unpack_from(fmt,corrected,at)[0]} expected{before}')
        struct.pack_into(fmt,corrected,at,after)
    values=list(struct.unpack_from('>32I',raw,0xde2a0));values.extend(ADDED)
    require(values[21]==0x12d506,'Original ordinary21 variant directory source')
    values[21]=0xc8114a
    require(values[27]==0x13be4a,'Original Cody variant directory source')
    values[27]=0xadaee4
    writes=[(BANK,bytes(corrected)),(STYLES,struct.pack('>3I',*([BANK]*3))),
            (DIRECTORY,struct.pack('>38I',*values))]
    ordinary_frames,_=owner_graph(data,0x749838+shift,21)
    maxima={i:max(data.read(at,20)[i]for at in ordinary_frames)for i in (8,9,10)}
    require(maxima=={8:74,9:91,10:16},'Complete ordinary Boxer selector/attack/event domains')
    hp,ep,vp=[data.u32(t+shift+21*4)for t in (0x7493d8,0x749478,0x749338)]
    indices=data.read(hp,300);events=data.read(ep,68)
    require(all(events[i]==0 and events[i+1]in(0,1,255)for i in range(0,68,4)), 'Original ordinary event grammar')
    ordinary_banks=[]
    for style in range(3):
        source=data.u32(vp+style*4);offsets=struct.unpack('<5h',data.read(source,10))
        require(offsets[0]==10 and offsets[4]==866 and all(a<z and (z-a)%8==0 for a,z in zip(offsets,offsets[1:])), 'Complete ordinary collision lanes')
        for frame in ordinary_frames:
            selector=data.read(frame,20)[8];selected=indices[selector*4:selector*4+4]
            require(all(v<(offsets[i+1]-offsets[i])//8 for i,v in enumerate(selected)), 'Original frame selector outside whole collision lane')
        lanes=data.read(source+10,856);lanes=b''.join(lanes[i:i+2][::-1]for i in range(0,856,2))
        attacks=[]
        for i in range(92):
            row=data.read(source+866+i*32,32)
            attacks.append(b''.join(row[n:n+2][::-1]for n in range(0,8,2))+row[8:])
        ordinary_banks.append(struct.pack('>5h',*offsets)+lanes+b''.join(attacks))
    require(len(set(ordinary_banks))==1 and len(ordinary_banks[0])==3810,'Original ordinary Boxer style aliases')
    ordinary_roots=struct.unpack('<12I',data.read(data.u32(0x749838+shift+21*4),48))
    ordinary_witness=[]
    for style in range(3):
        for wanted,actions in ORDINARY_CONTEXTS:
            used=set()
            for family,action in actions:
                _,starts=data.root(ordinary_roots[style*4+family]);at=starts[action];seen=set()
                while at is not None and at not in seen:
                    seen.add(at);used.add(data.read(at,20)[9]);_,_,at=data.frame(at)
            require(set(wanted)<=used,'Every ordinary repaired row binds original reviewed action group')
            ordinary_witness.append({'style':style,'rows':list(wanted),'actions':[list(v)for v in actions]})
    ordinary_corrected=bytearray(ordinary_banks[0])
    for index,field,before,after in ORDINARY_AMENDMENTS:
        at=866+index*32+field
        require(ordinary_corrected[at]==before,'Original ordinary Boxer typed field preimage')
        ordinary_corrected[at]=after
    writes.extend([(0xc800f8,indices),(0xc80224,events),(0xc80268,bytes(ordinary_corrected)),
                   (0xc8114a,struct.pack('>3I',*([0xc80268]*3)))])
    return writes,{'bytes':7622,'ordinary_packet_bytes':4190,'ordinary_attack_rows':92,'ordinary_typed_scalar_changes':16,'ordinary_action_contexts':ordinary_witness,'ordinary_source_frames':len(ordinary_frames),'bank_bytes':3268,'attack_rows':83,'style_aliases':3,
        'source_frames':len(frames),'original_action_contexts':witness,'typed_scalar_changes':len(AMENDMENTS),
        'directory_rows':38,'ordinary21_relocated_variants':hex(values[21]),
        'source_bank_sha256':hashlib.sha256(banks[0]).hexdigest(),
        'final_bank_sha256':hashlib.sha256(corrected).hexdigest()}
