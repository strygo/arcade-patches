"""Original retained P033 paragraphs and complete pointer/coordinate directories.

All wording comes through original USA PS2 language directories. Recipes hold
only identities, selectors, lengths and native allocations.
"""
import hashlib
import struct
from public_kit_graphics import require
from public_kit_english_text import encode
from public_kit_english_supply import consumed,lines


def sources(c1,c2,requested):
    base=0x60ad00
    hi,lo=struct.unpack_from('<2I',c1,0x44d220-0x1f0040)
    require(hi>>26==15 and lo>>26==9 and (hi>>16)&31==(lo>>21)&31==(lo>>16)&31,'Opening directory literal differs')
    opening=((hi&65535)*65536+struct.unpack('<h',struct.pack('<H',lo&65535))[0])&0xffffffff
    result={}
    for family,language,count,selected in (('BIO',opening,116,91),('DLG',0x61b570,754,598),('END',0x614e10,789,611)):
        root=struct.unpack_from('<I',c2,language-base+4)[0]-base
        require(0<=root<len(c2)-count*2,'Original paragraph root bounds')
        offsets=struct.unpack_from('<'+str(count)+'H',c2,root)
        header=2*(count+(family=='DLG'));require(offsets[0]==header,'Original paragraph directory extent')
        for index in range(selected):
            if (family,index) not in requested:continue
            offset=offsets[index];require(offset>=header,'Original paragraph overlaps directory')
            at=root+offset;require(at<len(c2),'Original paragraph bounds')
            blob=consumed(c2[at:at+512]);result[family,index]=(at,blob)
    require(set(result)==requested,'Retained original selector domain differs')
    return result


def split(text,lengths):
    rows=[];cursor=0
    for length in lengths:
        require(0<length<=64,'Retained native row extent')
        row=text[cursor:cursor+length];require(len(row)==length,'Truncated retained layout row')
        rows.append(row);cursor+=length+1
    require(' '.join(rows)==text,'Retained layout changes source wording')
    return rows


def story(rows,pixels):
    require(1<=len(rows)<=2 and 0<sum(map(len,rows))<=64,'Retained story coordinate capacity')
    blob=bytearray()
    for text in rows:
        cursor=(240-7*len(text))//2
        ink=[]
        for k,ch in enumerate(text):
            tile=pixels[(0x16c00+0x280+ord(ch))*128:(0x16c00+0x280+ord(ch)+1)*128]
            require(len(tile)==128,'Retained story font missing')
            pens=[p for byte in tile for p in (byte&15,byte>>4)]
            ink.extend(cursor+8+k*8+i%16 for i,p in enumerate(pens) if p!=15)
        require(ink,'Blank retained story row');lo=min(ink);hi=max(ink)+1
        shift=(272-(hi-lo))//2-lo if hi>272 else 0;cursor+=shift
        require(0<=lo+shift<hi+shift<=272,'Retained story ink escapes column')
        require(-128<=cursor<=127,'Retained story cursor overflow')
        blob.extend(bytes([cursor&255])+text.encode('ascii')+b'\0')
    if len(rows)==1:blob.append(0x70)
    return bytes(blob)


def ending(rows,spec,pixels):
    require(1<=len(rows)<=2 and 0<sum(map(len,rows))<=64,'Retained ending coordinate capacity')
    chars=set(''.join(rows));tiles={ch:[p for byte in pixels[(0x16c00+0x280+ord(ch))*128:(0x16c00+0x280+ord(ch)+1)*128] for p in (byte&15,byte>>4)] for ch in chars}
    require(all(len(v)==256 for v in tiles.values()),'Original ending font missing')
    blob=bytearray()
    for n,text in enumerate(rows):
        cursor=(240-7*len(text))//2-57+spec['row_shifts'].get(str(n),0)
        require(-128<=cursor<=127,'Retained ending cursor overflow')
        ink=[57+cursor+8+k*8+i%16 for k,ch in enumerate(text) for i,p in enumerate(tiles[ch]) if p!=15]
        require(ink and 0<=min(ink)<=max(ink)<272,'Retained ending ink escapes column')
        blob.extend(bytes([cursor&255])+text.encode('ascii')+b'\0')
    if len(rows)==1:blob.append(0x70)
    coords=None
    if spec['coordinates'] is not None:
        layout=split(' '.join(rows),spec['render_lengths']);require(2<=len(layout)<=3,'Retained credit row count')
        require(' ' not in tiles or all(p==15 for p in tiles[' ']),'Original SPACE glyph is visible')
        targets=[]
        for n,text in enumerate(layout):
            ink=[8+k*8+i%16 for k,ch in enumerate(text) for i,p in enumerate(tiles[ch]) if p!=15]
            require(ink,'Empty retained ending row');lo=min(ink);hi=max(ink)+1
            require(hi-lo<=224,'Retained ending credit width')
            cursor=(224-(hi-lo))//2-57-lo
            targets.extend((ch,cursor+(k+1)*8,n*16) for k,ch in enumerate(text) if ch!=' ')
        source=[c for row in rows for c in row]
        require([c for c in source if c!=' ']==[c for c,x,y in targets],'Retained visible glyph sequence differs')
        iterator=iter(targets);xy=[(0,0) if c==' ' else next(iterator)[1:] for c in source]
        require(len(xy)<=64 and all(-64<=x<=191 and 0<=y<=255 for x,y in xy),'Retained ending coordinate extent')
        coords=bytes(v for x,y in xy for v in (x+64,y))
    return bytes(blob),coords


def construct(c1,c2,pixels,recipe):
    require(recipe['schema']==1 and [hashlib.sha256(v).hexdigest() for v in (c1,c2,pixels)]==recipe['source_sha256'],'Original retained input identity differs')
    original=sources(c1,c2,{(r['family'],r['index']) for r in recipe['records']});writes=[];seen=set()
    def place(at,blob):
        require(0xa00000<=at<=0xe00000-len(blob),'Retained allocation bounds');writes.append((at,blob))
    for row in recipe['records']:
        key=(row['family'],row['index']);require(key not in seen and row['decision']=='retain','Duplicate or non-retained paragraph')
        seen.add(key);_,source=original[key]
        text=' '.join(line.decode('ascii').strip() for _,line in lines(source));shown=split(text,row['row_lengths'])
        require(hashlib.sha256('\n'.join(shown).encode()).hexdigest()==row['wording_sha256'],'Original PS2 wording differs from retained P033 authority: '+str(key))
        if row['family']=='END':blob,coords=ending(shown,row,pixels)
        else:blob=story(shown,pixels);coords=None
        require(hashlib.sha256(blob).hexdigest()==row['record_sha256'],'Retained native record identity differs: '+str(key))
        place(row['address'],blob)
        if coords is not None:
            require(hashlib.sha256(coords).hexdigest()==row['coordinate_sha256'],'Retained packed coordinates differ')
            place(row['coordinates'],coords)
    require(len(seen)==1039,'Complete retained story/ending domain differs')
    require([len(v['pointers']) for v in recipe['tables']]==[91,598,611],'Complete paragraph pointer domain differs')
    for table in recipe['tables']:place(table['address'],struct.pack('>'+str(len(table['pointers']))+'I',*table['pointers']))
    lookup=recipe['lookup'];pages={};pairs=[(0,0)]
    for identity,row in enumerate(lookup['records'],1):
        address,coords=row['address'],row['coordinates'];page=address>>8;page=(page^(page>>lookup['fold_shift']))&lookup['mask'];cell=(address&255)//2
        require(address%2==0 and 1<=identity<=255,'Ending coordinate lookup identity')
        data=pages.setdefault(page,bytearray(128));require(data[cell]==0,'Ending coordinate lookup collision')
        data[cell]=identity;pairs.append((address,coords))
    require(set(pages)=={p for p,a in lookup['pages']},'Ending coordinate lookup page domain')
    directory=[0]*128
    for page,address in lookup['pages']:place(address,bytes(pages[page]));directory[page]=address
    place(lookup['directory'],struct.pack('>128I',*directory));place(lookup['vector'],b''.join(struct.pack('>II',*pair) for pair in pairs))
    old=lookup['retained_vector'];place(old['address'],struct.pack('>'+str(len(old['pointers']))+'I',*old['pointers']))
    for at,size in lookup['zero_tails']:
        require(0<size<=256,'Retained coordinate padding extent');place(at,bytes(size))
    return writes


def self_test():
    require(split('ABC DEF',[3,3])==['ABC','DEF'],'Retained wrapping differs')
    for lengths in ([2,3],[3,4],[0,7]):
        try:split('ABC DEF',lengths)
        except ValueError:pass
        else:raise ValueError('Invalid retained layout accepted')
    print('Retained paragraph layout self-test: PASS')


def main():
    import argparse,json
    from pathlib import Path
    parser=argparse.ArgumentParser(description=__doc__)
    for name in ('c1','c2','pixels','recipe','outdir'):parser.add_argument('--'+name,type=Path)
    parser.add_argument('--self-test',action='store_true');args=parser.parse_args()
    if args.self_test:self_test();return
    require(all(getattr(args,n) for n in ('c1','c2','pixels','recipe','outdir')),'Original inputs, recipe and output required')
    writes=construct(args.c1.read_bytes(),args.c2.read_bytes(),args.pixels.read_bytes(),json.loads(args.recipe.read_text()))
    data=bytearray(0x400000);mask=bytearray(len(data))
    for address,blob in writes:
        at=address-0xa00000
        require(all(not mask[at+n] or data[at+n]==v for n,v in enumerate(blob)),'Conflicting retained output')
        data[at:at+len(blob)]=blob;mask[at:at+len(blob)]=b'\1'*len(blob)
    args.outdir.mkdir(exist_ok=True);(args.outdir/'us.bin').write_bytes(data);(args.outdir/'us.mask').write_bytes(mask)


if __name__=='__main__':main()
