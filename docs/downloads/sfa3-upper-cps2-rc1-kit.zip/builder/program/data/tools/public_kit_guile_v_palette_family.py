"""Complete original Guile V palette array and extended owner directories."""
import hashlib,struct
from public_kit_graphics import require
from public_kit_palettes import catalog
from public_kit_color_arena import resources

def construct(comp2,native,recipe):
    require(recipe['schema']==1 and hashlib.sha256(comp2).hexdigest()==recipe['source_sha256'] and hashlib.sha256(native).hexdigest()==recipe['native_sha256'],'Guile V source identities')
    arrays=catalog(comp2,recipe['region']);palette=arrays['prefix:32'][1]+arrays['effects:32'][1]
    require(len(palette)==960,'Complete Guile V palette extent')
    writes,_=resources(comp2,native,recipe['region']);start,arena=writes[0]
    require(start==0x3e0000 and len(arena)>384,'Original complete color arena')
    expected={'effects':start+len(arena)-384,'prefix':start+len(arena)-256}
    require(recipe['original_directories']==expected,'Original32-owner directory locations differ')
    data=bytearray(palette)
    for name,pointer in (('effects',0xa2e0c0),('prefix',0xa2e000)):
        at=expected[name]-start;data+=arena[at:at+128]+struct.pack('>I',pointer)
    require(len(data)==1224,'Complete extended Guile V allocation extent')
    return [(0xa2e000,bytes(data))],{'bytes':1224,'original_palette_bytes':960,'complete_owner_directories':2,'directory_entries':33}

def main():
    import argparse,json
    from pathlib import Path
    p=argparse.ArgumentParser(description=__doc__)
    for n in ('comp2','native','recipe','outdir'):p.add_argument('--'+n,type=Path,required=True)
    a=p.parse_args();writes,report=construct(a.comp2.read_bytes(),a.native.read_bytes(),json.loads(a.recipe.read_text()));data=bytearray(0x400000);mask=bytearray(len(data))
    for at,blob in writes:at-=0xa00000;data[at:at+len(blob)]=blob;mask[at:at+len(blob)]=b'\1'*len(blob)
    (a.outdir/'result.bin').write_bytes(data);(a.outdir/'result.mask').write_bytes(mask);print(json.dumps(report))
if __name__=='__main__':main()
