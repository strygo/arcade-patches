"""Complete original Shin selector/event/collision packet and owner directories."""
import hashlib
import struct
from public_kit_actor import Data
from public_kit_frame_resources import owner_graph
from public_kit_graphics import require
import public_kit_fei_body_directories as body

START=0xc3b000
END=0xc3c76c


def construct(inputs,recipe):
    digest=lambda b:hashlib.sha256(b).hexdigest()
    require(set(inputs)==set(recipe['inputs'])=={'arcade','comp1','comp2','coords','naomi'} and recipe['source_region']=='jp','Complete inherited Japanese collision source contract')
    for name,blob in inputs.items():
        pin=recipe['inputs'][name];require(len(blob)==pin['bytes'] and digest(blob)==pin['sha256'],'Whole collision source '+name)
    for row in recipe['readers']:
        at=row['address']-0x1f0040
        require(digest(inputs['comp1'][at:at+row['bytes']])==row['sha256'],'Original collision reader '+row['role'])
    data=Data(inputs['comp2'],0x60b080,inputs['coords'],0xb04000)
    frames,_=owner_graph(data,0x74ef38,36);raw=[data.read(a,20)for a in frames]
    maxima={str(n):max(r[n]for r in raw)for n in (8,9,10)}
    require(maxima==recipe['maxima'] and len(frames)==recipe['frames'],'Complete original Shin frame demand domain')
    hp,ep,vp=[data.u32(t+36*4)for t in (0x74ead8,0x74eb78,0x74ea38)]
    indices=data.read(hp,(maxima['8']+1)*4);events=data.read(ep,(maxima['10']+1)*4)
    require(len(indices)==488 and len(events)==168,'Complete collision index/event extents')
    words=lambda b:b''.join(b[n:n+2][::-1]for n in range(0,len(b),2))
    banks=[]
    for style in range(3):
        row=recipe['banks'][style];root=data.u32(vp+style*4);offsets=struct.unpack('<5h',data.read(root,10))
        require(root==int(row['source'],0) and list(offsets)==row['offsets']==[10,586,1098,1338,1426],'Original full collision bank layout')
        lanes=[]
        for lane,witness in enumerate(row['Naomi_lane_byte_witnesses']):
            original=data.read(root+offsets[lane],offsets[lane+1]-offsets[lane]);at=int(witness['Naomi_first_exact_match'],0)
            require(len(original)==witness['original_bytes'] and digest(original)==witness['original_sha256'] and inputs['naomi'][at:at+len(original)]==original,'Independent original Naomi collision lane witness')
            lanes.append(words(original))
        for frame in raw:
            selected=indices[frame[8]*4:frame[8]*4+4]
            require(all(v<len(blob)//8 for v,blob in zip(selected,lanes)),'Complete source selector/lane ABI')
        attacks=data.read(root+offsets[4],(maxima['9']+1)*32)
        projected=b''.join(words(attacks[n:n+8])+attacks[n+8:n+32]for n in range(0,len(attacks),32))
        blob=struct.pack('>5h',*offsets)+b''.join(lanes)+projected
        require(len(blob)==4882 and digest(blob)==row['sha256'],'Whole original typed collision bank')
        banks.append(blob)
    require(banks[0]==banks[1]==banks[2],'Original three styles share one complete bank')
    payload=bytearray(b'\xff'*(END-START));mask=bytearray(len(payload))
    def put(at,blob):
        require(START<=at<at+len(blob)<=END,'Complete original packet extent')
        off=at-START;require(not any(mask[off:off+len(blob)]),'Collision packet allocations overlap')
        payload[off:off+len(blob)]=blob;mask[off:off+len(blob)]=b'\1'*len(blob)
    for role,at,blob in (('indices',START,indices),('events',0xc3b1e8,events),('bank_0',0xc3b290,banks[0]),('variants',0xc3c5a4,struct.pack('>3I',*([0xc3b290]*3)))):
        require(digest(blob)==recipe['allocations'][role]['sha256'],'Original allocated collision resource '+role);put(at,blob)
    original=dict(body.construct({'arcade':inputs['arcade']},{'inputs':{'arcade':recipe['inputs']['arcade']}})[0])
    for row in recipe['directories']:
        role=row['role'];prefix=bytearray(original[row['original34']])
        if role=='indices':prefix[52:56]=inputs['arcade'][0xde320+52:0xde320+56]
        require(digest(prefix)==row['dee']['previous_34_rows_sha256'],'Complete original34 collision prefix')
        prefix.extend(struct.pack('>I',row['dee_value']))
        require(digest(prefix)==row['shin']['previous_35_rows_sha256']==row['hawk']['retained_0_through_34_sha256'],'Complete original35 collision prefix')
        own=bytes.fromhex(row['shin']['owner36_row_hex']);blob=bytes(prefix)+bytes(4)+own
        require(digest(blob)==row['sha256'] and own.hex()==row['hawk']['retained_Shin_row_hex'],'Complete original37 collision directory')
        require(row['hawk']['all_other_rows_unchanged'],'Original Hawk typed extension contract')
        blob=blob[:140]+bytes.fromhex(row['hawk']['owner35_row_hex'])+blob[144:];put(int(row['shin']['address'],0),blob)
    require([START+n for n,v in enumerate(mask)if not v]==[0xc3c5a2,0xc3c5a3] and recipe['alignment']=={'address':0xc3c5a2,'bytes':2,'value':255},'Original four-byte allocator alignment over FF-initialized expanded region')
    for edit in recipe['edits']:
        at=int(edit['address'],0)-START;before=bytes.fromhex(edit['before']);after=bytes.fromhex(edit['after'])
        require(0<=at<=len(payload)-len(before) and len(before)==len(after) and payload[at:at+len(before)]==before,'Reviewed complete collision preimage')
        payload[at:at+len(after)]=after
    require([(r['address'],len(bytes.fromhex(r['before'])))for r in recipe['edits']]==[('0xc3bc02',32),('0xc3c5e5',3)],'Complete reviewed Shin packet edit domain')
    return [(START,bytes(payload))],{'bytes':len(payload),'source_frames':len(frames),'maxima':maxima,'complete_banks':1,'source_styles':3,'directories':3,'original_alignment_bytes':2,'reviewed_edits':2,'sha256':digest(payload)}
