"""Original Evil Ryu and T. Hawk ending maps using complete native artwork."""
import hashlib
import struct
from public_kit_graphics import require
from public_kit_stage_maps import CHUNKS,STRIDES


def project(inputs,region,owner,bindings,pixels):
    require(region in ('us','jp'),'Unknown ending source region')
    require(owner in (23,35),'Native-art ending owner');base=0x60ad00 if region=='us' else 0x60b080
    shift=0x5700 if region=='jp' else 0;ds=0x10f0 if region=='jp' else 0
    def read(at,size):
        require(size>0 and 0<=at-base<=len(inputs['comp2'])-size,'Ending map source bounds')
        return inputs['comp2'][at-base:at-base+size]
    roots=[struct.unpack('<I',read(t+ds+owner*4,4))[0] for t in (0x60b700,0x60b7b0)]
    require(roots[0]==roots[1],'Ending mode map roots differ');root=roots[0]
    used_bindings={n:set() for n in (1,2,3)};tables={}
    for layer in (2,3):
        rows=bindings[str(layer)];tables[layer]={r[0]:r[1:] for r in rows}
        require(len(tables[layer])==len(rows),'Duplicate ending tile binding')
    def cell(layer,code,attr):
        require(code in tables[layer],f'Missing original stage tile binding: owner={owner} layer={layer} code={code}')
        native,bank=tables[layer][code];used_bindings[layer].add(code)
        require(bank in (0,512) and 0<=native<(16384 if layer==3 else 65536),'Native stage tile extent')
        stride={1:32,2:128,3:512}[layer]
        supply=inputs['scroll3'] if layer==3 else inputs['font']
        if layer==3:
            require(code<len(inputs['scroll3_mask']),'Original stage tile mask bounds')
            valid=inputs['scroll3_mask'][code]
            require(valid or code==0,'Missing non-null original stage tile')
        else:valid=True
        if valid:
            require((code+1)*stride<=len(supply),'Original stage artwork bounds')
            tile=supply[code*stride:(code+1)*stride]
        else:tile=b'\xff'*512
        if layer==1:tile=b''.join(tile[y*4:y*4+4]*2 for y in range(8))
        physical=(40 if bank else 8)*1024**2+native*STRIDES[layer]
        require(physical+len(tile)<=len(pixels) and pixels[physical:physical+len(tile)]==tile,
                'Complete stage tile differs from original artwork')
        return struct.pack('>HH',native,(attr&127)|bank)
    controls=bytearray(8);files={};summary={}
    for layer,count in ((1,4),(2,16),(3,64)):
        offset=struct.unpack('<h',read(root+(layer-1)*2,2))[0]
        require(offset>=6,'Ending controls overlap root')
        original=read(root+offset,count);chunks=sorted(set(original));ids={old:n for n,old in enumerate(chunks)}
        selected=bytes(ids[c] for c in original)
        struct.pack_into('>H',controls,(layer-1)*2,len(controls));controls.extend(selected)
        if layer==1:
            require(original==selected,'Ending Scroll1 original controls require remapping');continue
        size=256 if layer==2 else 64;out=bytearray()
        for chunk in chunks:
            raw=read(CHUNKS[layer]+shift+chunk*size*3,size*3)
            codes=struct.unpack('<'+str(size)+'H',raw[:size*2])
            for code,attr in zip(codes,raw[size*2:]):out.extend(cell(layer,(code+(0x1c00 if layer==2 else 0))&65535,attr))
        files['s'+str(layer)+'_chunks']=bytes(out)
        require(used_bindings[layer]==set(tables[layer]),'Ending tile binding domain differs')
        summary[str(layer)]={'chunks':len(chunks),'tiles':len(used_bindings[layer]),'bytes':len(out)}
    files['maps']=bytes(controls)
    files['parameters']=struct.pack('>3H',*struct.unpack('<3H',read(0x60b9c0+ds+owner*6,6)))
    return files,summary


def bindings(inputs,region,owner,pixels):
    base=0x60b080 if region=='jp' else 0x60ad00;ds=0x10f0 if region=='jp' else 0;shift=0x5700 if region=='jp' else 0
    def read(at,size):
        require(size>0 and 0<=at-base<=len(inputs['comp2'])-size,'Native-art ending source bounds')
        return inputs['comp2'][at-base:at-base+size]
    root=struct.unpack('<I',read(0x60b700+ds+owner*4,4))[0];result={}
    for layer,count in ((2,16),(3,64)):
        offset=struct.unpack('<h',read(root+(layer-1)*2,2))[0];chunks=set(read(root+offset,count));size=256 if layer==2 else 64;codes=set()
        for chunk in chunks:
            raw=read(CHUNKS[layer]+shift+chunk*size*3,size*3)
            codes.update((code+(0x1c00 if layer==2 else 0))&65535 for code in struct.unpack('<'+str(size)+'H',raw[:size*2]))
        stride=STRIDES[layer];supply=inputs['font'] if layer==2 else inputs['scroll3'];tiles={}
        for code in codes:
            require((code+1)*stride<=len(supply),'Native-art ending tile source bound')
            valid=layer==2 or (code<len(inputs['scroll3_mask']) and inputs['scroll3_mask'][code])
            require(valid or code==0,'Absent original ending tile')
            tiles[code]=supply[code*stride:(code+1)*stride] if valid else b'\xff'*stride
        wanted=set(tiles.values());hits={};native=pixels[8<<20:16<<20]
        require(len(native)==8<<20,'Native-art ending window')
        for at in range(0,min(len(native),65536*stride),stride):
            tile=native[at:at+stride]
            if tile in wanted and tile not in hits:hits[tile]=at//stride
            if len(hits)==len(wanted):break
        require(set(hits)==wanted,'Ending map has artwork absent from native supply')
        result[str(layer)]=[[code,hits[tile],0] for code,tile in sorted(tiles.items())]
    return result


def construct(inputs,recipe,pixels):
    require(recipe['schema']==1,'Unknown native ending map recipe')
    for name,pin in recipe['inputs'].items():require(hashlib.sha256(inputs[name]).hexdigest()==pin,'Original ending map input identity: '+name)
    require(hashlib.sha256(pixels).hexdigest()==recipe['pixels_sha256'],'Ending map emitted graphics identity')
    require(set(recipe['allocations'])=={'23','35'},'Native ending owner census')
    writes=[];reports={}
    for owner in (23,35):
        mapping=bindings(inputs,recipe['region'],owner,pixels)
        files,summary=project(inputs,recipe['region'],owner,mapping,pixels)
        allocation=recipe['allocations'][str(owner)]
        require(set(files)==set(allocation),'Complete native ending-map allocation domain')
        writes.extend((allocation[name],blob) for name,blob in files.items());reports[str(owner)]=summary
    return writes,reports


def main():
    import argparse,json
    from pathlib import Path
    p=argparse.ArgumentParser(description=__doc__)
    for n in ('comp2','font','scroll3','scroll3_mask','pixels','recipe','outdir'):p.add_argument('--'+n,type=Path,required=True)
    a=p.parse_args();inputs={n:getattr(a,n).read_bytes() for n in ('comp2','font','scroll3','scroll3_mask')}
    writes,_=construct(inputs,json.loads(a.recipe.read_text()),a.pixels.read_bytes());data=bytearray(0x400000);mask=bytearray(len(data))
    for at,blob in writes:
        at-=0xa00000;require(not any(mask[at:at+len(blob)]),'Ending map overlap')
        data[at:at+len(blob)]=blob;mask[at:at+len(blob)]=b'\1'*len(blob)
    a.outdir.mkdir(exist_ok=True);(a.outdir/'result.bin').write_bytes(data);(a.outdir/'result.mask').write_bytes(mask)


if __name__=='__main__':main()
