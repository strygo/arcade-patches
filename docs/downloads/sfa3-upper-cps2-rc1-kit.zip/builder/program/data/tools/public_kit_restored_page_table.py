"""Complete relocated native Scroll3 table and source-authored ending overlays."""
import hashlib,struct
from public_kit_graphics import require
from public_kit_restored_page_clones import construct as clones,S3,DEST

REDIRECTS=((0x3b36a4,0xac8662),(0x3b36b4,0xac8848),(0x3b3794,0xac8662),(0x3b37a4,0xac8848))

def construct(native,recipe,pixels):
    require(recipe['schema']==1 and recipe['region'] in ('us','jp'),'Restored table region/schema')
    require(len(native)==0x400000 and hashlib.sha256(native).hexdigest()==recipe['native_sha256'],'Original complete page-table identity')
    require(recipe['clones']['native_sha256']==recipe['native_sha256'],'Clone/table source identity disagreement')
    data=bytearray(native[S3:S3+256*192]+b'\xff'*174)
    writes,report=clones(native,recipe['clones'],pixels)
    require(len(writes)==7,'Complete authored clone/root inventory')
    for at,blob in writes:
        offset=at-DEST;require(0<=offset<=len(data)-len(blob),'Clone outside complete table');data[offset:offset+len(blob)]=blob
    expected=[list(row)for row in REDIRECTS] if recipe['region']=='jp'else []
    require(recipe['redirects']==expected,'Declared late native page redirects differ')
    for source,target in expected:
        at=source-S3;require(struct.unpack_from('>I',data,at)[0]==0x3bd514,'Original attract directory pointer preimage')
        struct.pack_into('>I',data,at,target)
    return [(DEST,bytes(data))],{'complete_decoder_pages':256,'bytes':len(data),'private_cloned_pages':6,'complete_private_root':174,'late_typed_attract_redirects':len(expected)}

def main():
    import argparse,json
    from pathlib import Path
    p=argparse.ArgumentParser(description=__doc__)
    for n in ('native','recipe','pixels','outdir'):p.add_argument('--'+n,type=Path,required=True)
    a=p.parse_args();writes,report=construct(a.native.read_bytes(),json.loads(a.recipe.read_text()),a.pixels.read_bytes());data=bytearray(0x400000);mask=bytearray(len(data))
    for at,blob in writes:
        at-=0xa00000;data[at:at+len(blob)]=blob;mask[at:at+len(blob)]=b'\1'*len(blob)
    (a.outdir/'result.bin').write_bytes(data);(a.outdir/'result.mask').write_bytes(mask);print(json.dumps(report))
if __name__=='__main__':main()
