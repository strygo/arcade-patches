"""Complete retained Guile controller export headers from typed linker bindings.

Each row is the original assembly dc.l export sequence. The controller
relocation rewrites all typed exports, including module_end, to their new
native code allocations. Executable bodies are qualified separately.
"""
import struct
from public_kit_graphics import require

HEADERS={
 'flash':(0xa1b000,('command_hook','update_hook','module_end')),
 'boom':(0xa1e000,('command_hook','update_hook','child','child_selector','render','module_end')),
 'supers':(0xa20000,('command_hook','update_hook','super_child','render','module_end')),
 'systems':(0xa2c000,('command_hook','update_hook','initialize_allowance','module_end')),
 'v_boom':(0xa30000,('admission','emit','module_end'))}


def construct(recipe):
    require(set(recipe['exports'])==set(HEADERS),'Complete retained controller header family')
    writes=[]
    for name,(address,labels)in HEADERS.items():
        values=recipe['exports'][name]
        require(set(values)==set(labels),'Complete original assembly export domain '+name)
        require(all(type(v)is int and v%2==0 and 0xe0000<=v<=0x100000 for v in values.values()),'Controller export opcode allocation '+name)
        writes.append((address,struct.pack('>'+str(len(labels))+'I',*(values[label]for label in labels))))
    return writes,{'tables':len(HEADERS),'bytes':sum(len(blob)for _,blob in writes),'executable_bodies':'separately qualified'}
