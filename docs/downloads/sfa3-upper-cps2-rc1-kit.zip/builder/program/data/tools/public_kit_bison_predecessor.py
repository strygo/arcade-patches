"""Complete four original Bison ending graphs with verified native cel reuse."""
import hashlib
import struct
from public_kit_actor import Data
from public_kit_bison_ending_bodies import graph
from public_kit_graphics import require,shuffle_bus,planar_to_pixels
from public_kit_shin_frames import native_cel,compare_canvas

GFX=('sz3.13m','sz3.15m','sz3.17m','sz3.19m')


def construct(inputs,recipe):
    require(set(inputs)==set(recipe['inputs'])=={'arcade','comp2','coords','pixels','mask',*GFX},'Complete original Bison predecessor inventory')
    for name,blob in inputs.items():
        pin=recipe['inputs'][name]
        require(len(blob)==pin['bytes'] and hashlib.sha256(blob).hexdigest()==pin['sha256'],'Original Bison predecessor identity '+name)
    region=recipe['region'];require(region in ('us','jp'),'Original Bison region')
    data=Data(inputs['comp2'],0x60ad00 if region=='us' else 0x60b080,inputs['coords'],0xb04000)
    root=data.u32((0x619b50 if region=='us' else 0x61ac40)+40)
    root_blob,targets=data.root(root)
    require(len(targets)==96 and hashlib.sha256(root_blob).hexdigest()==recipe['root_sha256'],'Complete original96-action Bison root')
    frames,cels=graph(data,[targets[n]for n in (76,88,89,90,91)])
    require(len(frames)==35,'Complete original five Bison graph census')
    native=inputs['arcade'];bindings={int(k):v for k,v in recipe['cels'].items()}
    require(set(bindings)==set(cels),'Complete original Bison cel bindings')
    bus=bytearray(8<<20)
    for lane,name in enumerate(GFX):
        source=inputs[name][:2<<20];bus[lane*2::8]=source[::2];bus[lane*2+1::8]=source[1::2]
    pixels=planar_to_pixels(shuffle_bus(bytes(bus)));checked=0
    for address,(_,blocks)in cels.items():
        target,_=native_cel(native,bindings[address])
        checked+=compare_canvas(blocks,target,inputs['pixels'],pixels,inputs['mask'])
    existing={int(k):v for k,v in recipe['native_frames'].items()}
    retained,_=graph(data,[targets[76]])
    require(set(existing)==set(retained) and len(existing)==19,'Whole retained original Bison action76')
    mapping=dict(existing);result=bytearray()
    for at,(_,_,_,size)in sorted(frames.items()):
        if at not in existing:mapping[at]=0xa98000+len(result);result.extend(bytes(size))
    for at,(raw,cel,nxt,size)in sorted(frames.items()):
        converted=bytearray(struct.pack('>10H',*struct.unpack('<10H',raw)))
        converted[:4]=raw[:4];converted[8:10]=raw[8:10];struct.pack_into('>I',converted,4,bindings[cel])
        if size==24:converted.extend(struct.pack('>I',mapping[nxt]))
        elif nxt is not None:require(mapping[nxt]==mapping[at]+20,'Complete Bison graph fallthrough')
        if at in existing:require(native[mapping[at]:mapping[at]+size]==converted,'Complete retained Bison native frame equivalence')
        else:result[mapping[at]-0xa98000:mapping[at]-0xa98000+size]=converted
    roots=struct.pack('>4h',*(mapping[targets[n]]-0xa97e50 for n in (88,89,90,91)))
    require(len(result)==324,'Complete16-frame Bison allocation')
    return [(0xa97f00,roots),(0xa98000,bytes(result))],{'bytes':332,'new_frames':16,'retained_frames':19,'root_selectors':[88,89,90,91],'complete_cels':len(cels),'canvas_pixels_checked':checked}
