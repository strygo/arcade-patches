"""Complete original T. Hawk body graph, rectangle packing and native records."""
import hashlib,struct
from public_kit_actor import Data
from public_kit_blocks import BlockPacker,grid_code
from public_kit_frame_resources import owner_graph
from public_kit_shin_frames import compare_canvas
from public_kit_graphics import require

BYTE_CONTEXTS={1:(1,2,3,4,5,6,7,8,9,19,22,27,28,34),2:(2,3,4,5,6,19,20,21,22,23,32,33)}

START,CEL_END,END=0xd70000,0xd76d40,0xd7a680


def digest(blob):return hashlib.sha256(blob).hexdigest()


def construct(inputs,recipe,native_pixels):
    require(set(recipe)=={'schema','region','inputs','native_pixels_sha256','source_graph','amendments'}and recipe['schema']==1,'Complete Hawk body recipe schema')
    require(set(inputs)==set(recipe['inputs'])=={'comp1','comp2','coords','pixels','mask'},'Complete original Hawk body input domain')
    for name,blob in inputs.items():
        pin=recipe['inputs'][name];require(len(blob)==pin['bytes']and digest(blob)==pin['sha256'],'Original Hawk body input '+name)
    require(len(native_pixels)==2<<20 and digest(native_pixels)==recipe['native_pixels_sha256'],'Complete reconstructed Hawk object window')
    region=recipe['region'];require(region in ('us','jp'),'Original Hawk region');base=0x60ad00 if region=='us'else 0x60b080
    data=Data(inputs['comp2'],base,inputs['coords'],0xb04000);table=0x749838 if region=='us'else 0x74ef38
    bank=data.u32(table+35*4);roots=struct.unpack('<12I',data.read(bank,48))
    require(roots[:4]==roots[4:8]==roots[8:],'Complete original Hawk ISM root aliases')
    frames,_=owner_graph(data,table,35);cels=sorted({v[0]for v in frames.values()})
    require(len(frames)==719 and len(cels)==268,'Complete original Hawk719-frame/268-cel domain')
    require(recipe['source_graph']=={'owner':35,'frames':719,'cels':268,'bank':bank,'roots':list(roots)},'Original Hawk root graph bindings')
    amendment=recipe['amendments']
    require(set(amendment)=={'kind','readers','contexts'} and amendment['kind']=='original-recipient-byte-fields16-17','Original Hawk recipient projection contract')
    dc=0x70 if region=='jp'else 0
    require([r['entry']for r in amendment['readers']]==[0x35ad88+dc,0x35b178+dc,0x42fce0+dc],'Original complete recipient reader domain')
    for reader in amendment['readers']:
        at=reader['entry']-0x1f0040;size=reader['bytes']
        require(0<size<=65536 and digest(inputs['comp1'][at:at+size])==reader['sha256'],'Complete original recipient reader identity')
    typed=set();found={};contexts=[]
    for family in range(4):
        active=[]
        for action,first in enumerate(data.root(roots[family])[1]):
            chain=[];at=first;seen=set()
            while at is not None and at not in seen:
                require(at in frames,'Recipient context escaped complete source graph');seen.add(at);chain.append(at);at=frames[at][1]
            if any(data.read(at+16,1)!=data.read(at+17,1)for at in chain):active.append(action)
            if action in BYTE_CONTEXTS.get(family,()):
                typed.update(chain);contexts.append({'family':family,'action':action,'source':first,'frames':len(chain),'source_sha256':digest(b''.join(data.read(at,frames[at][2])for at in chain))})
        if active:found[family]=tuple(active)
    require(found==BYTE_CONTEXTS and contexts==amendment['contexts'],'Complete original recipient byte-field contexts differ')
    packer=BlockPacker(b'');packer.add(1,1,[b'\xff'*128],0);converted={};original={}
    for pointer in cels:
        kind,blocks=data.cel(pointer);original[pointer]=(kind,tuple((x,y,w&65535,w>>16)for x,y,w in blocks));result=[]
        for x,y,tile,attr in original[pointer][1]:
            w,h=(attr>>8&15)+1,(attr>>12&15)+1;codes=[grid_code(tile,dx,dy)for dy in range(h)for dx in range(w)]
            require(all(0<=c<len(inputs['mask'])and inputs['mask'][c]for c in codes),'Complete original Hawk rectangle supply')
            tiles=[inputs['pixels'][c*128:(c+1)*128]for c in codes];target=packer.add(w,h,tiles,attr);packer.check(target,w,h,tiles,attr)
            require(target<65536,'Native Hawk local object code');result.append((x,y,target,attr))
        converted[pointer]=tuple(result)
    pixels=b''.join(packer.tiles);require(len(pixels)<=len(native_pixels)and pixels==native_pixels[:len(pixels)],'Whole source-packed Hawk artwork differs')
    payload=bytearray();mapping={};canvas_pixels=0
    for pointer in cels:
        kind,source=original[pointer];blocks=converted[pointer]
        if kind==18:
            require(not blocks,'Original blank Hawk cel rectangle domain');mapping[pointer]=START+len(payload);payload.extend(struct.pack('>H',18));continue
        require(blocks,'Original Hawk nonblank cel')
        xy=START+len(payload);payload.extend(b''.join(struct.pack('>2h',x,y)for x,y,_,_ in blocks));mapping[pointer]=START+len(payload)
        area=sum(((a>>8&15)+1)*((a>>12&15)+1)for _,_,_,a in blocks)
        payload.extend(struct.pack('>3HI',2,area,len(blocks)-1,xy));payload.extend(b''.join(struct.pack('>2H',t,a)for _,_,t,a in blocks))
        canvas_pixels+=compare_canvas(source,blocks,inputs['pixels'],native_pixels,inputs['mask'])
    require(START+len(payload)==CEL_END,'Complete original268-cel allocation extent')
    destinations={};cursor=CEL_END
    for source in sorted(frames):destinations[source]=cursor;cursor+=frames[source][2]
    require(cursor==END,'Complete original719-frame allocation extent')
    for source in sorted(frames):
        cel,nxt,size=frames[source];raw=data.read(source,20)
        blob=raw[:4]+struct.pack('>I',mapping[cel])+raw[8:16]+raw[16:18][::-1]+raw[18:20]
        if source in typed:
            require(blob[16:18]==raw[16:18][::-1],'Recipient reversed-pair preimage');blob=blob[:16]+raw[16:18]+blob[18:]
        if size==24:require(nxt in destinations,'Original full successor closure');blob+=struct.pack('>I',destinations[nxt])
        elif nxt is not None:require(destinations[nxt]==destinations[source]+20,'Complete native Hawk fallthrough')
        payload.extend(blob)
    require(len(payload)==END-START,'Complete body packet extent')
    return [(START,bytes(payload))],{'bytes':len(payload),'cels':268,'frames':719,'packed_pixel_bytes':len(pixels),'canvas_pixels_checked_both_facings':canvas_pixels,'typed_recipient_frames':len(typed),'typed_contexts':len(contexts)}


def main():
    import argparse,json
    from pathlib import Path
    p=argparse.ArgumentParser(description=__doc__)
    for name in ('inputs','recipe','native_pixels','out'):p.add_argument('--'+name.replace('_','-'),type=Path,required=True)
    a=p.parse_args();require(not a.out.exists(),'Fresh Hawk body output required');recipe=json.loads(a.recipe.read_text())
    inputs={n:(a.inputs/(n+'.bin')).read_bytes()for n in recipe['inputs']};writes,report=construct(inputs,recipe,a.native_pixels.read_bytes())
    data=bytearray(0x400000);mask=bytearray(len(data))
    for address,blob in writes:
        at=address-0xa00000;data[at:at+len(blob)]=blob;mask[at:at+len(blob)]=b'\1'*len(blob)
    a.out.mkdir();(a.out/'data.bin').write_bytes(data);(a.out/'mask.bin').write_bytes(mask);(a.out/'report.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')


if __name__=='__main__':main()
