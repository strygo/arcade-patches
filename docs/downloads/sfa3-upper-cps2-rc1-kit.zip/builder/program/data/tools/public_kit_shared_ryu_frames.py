"""Complete original shared Ryu/ID23 primary51 and secondary49..54 resources."""
import hashlib,struct
from public_kit_actor import Data
from public_kit_blocks import grid_code
from public_kit_graphics import require,tile_variants
from public_kit_shin_frames import compare_canvas

def graph(data,target):
    rows={}
    while target is not None and target not in rows:
        header=data.read(target,20);_,value,nxt=data.frame(target)
        rows[target]=(header,data.u32(target+4),tuple((x,y,w&65535,w>>16)for x,y,w in value[1]),nxt)
        require(len(rows)<1024,'Bounded original shared action graph');target=nxt
    return rows

def original(inputs,region):
    data=Data(inputs['comp2'],0x60ad00 if region=='us' else 0x60b080,inputs['coords'],0xb04000)
    table=0x749838 if region=='us' else 0x74ef38;bank=data.u32(table)
    require(data.u32(table+23*4)==bank,'Original Ryu/ID23 shared owner binding')
    roots=struct.unpack('<12I',data.read(bank,48))
    require(len(set(roots[0::4]))==len(set(roots[2::4]))==1,'Original shared ISM roots')
    _,primary=data.root(roots[0]);_,secondary=data.root(roots[2]);rows=graph(data,primary[51]);extra={}
    require(len(rows)==6 and [v[0][0]for v in rows.values()]==[28,2,2,4,8,8],'Complete six-frame primary51')
    for action in range(49,55):extra.update(graph(data,secondary[action]))
    require(len(extra)==100 and not set(rows)&set(extra),'Complete100-frame secondary family')
    rows.update(sorted(extra.items()));return rows

def construct(inputs,recipe,pixels):
    require(set(inputs)==set(recipe['inputs'])=={'comp2','coords','pixels','mask'},'Complete shared Ryu original source domain')
    for name,pin in recipe['inputs'].items():
        require(len(inputs[name])==pin['bytes'] and hashlib.sha256(inputs[name]).hexdigest()==pin['sha256'],'Original shared Ryu input '+name)
    require(recipe['region'] in ('us','jp'),'Original shared Ryu region')
    rows=original(inputs,recipe['region']);native=pixels[:8<<20];lookup={}
    for n in range(0,len(native),128):lookup.setdefault(native[n:n+128],n//128)
    mapping={};cels={};writes=[];position=0xba7000;checked=0
    def add(blob):
        nonlocal position
        position+=-position%4;at=position;position+=len(blob);writes.append((at,blob));return at
    for header,pointer,blocks,nxt in rows.values():
        if pointer in cels:continue
        converted=[]
        for x,y,t,a in blocks:
            width,height=(a>>8&15)+1,(a>>12&15)+1
            for dy in range(height):
                for dx in range(width):
                    code=grid_code(t,width-1-dx if a&32 else dx,height-1-dy if a&64 else dy)
                    require(code<len(inputs['mask']) and inputs['mask'][code],'Original shared Ryu tile presence')
                    if code not in mapping:
                        variants=tile_variants(inputs['pixels'][code*128:(code+1)*128])
                        match=next(((lookup[v],flip*32)for flip,v in enumerate(variants)if v in lookup),None)
                        require(match is not None,'Original shared Ryu native artwork');mapping[code]=match
                    tile,flip=mapping[code];converted.append((x+dx*16,y+dy*16,tile,(a&255)^flip))
        checked+=compare_canvas(blocks,converted,inputs['pixels'],native,inputs['mask'])
        xy=add(b''.join(struct.pack('>2h',x,y)for x,y,_,_ in converted))
        cels[pointer]=add(struct.pack('>3HI',2,len(converted),len(converted)-1,xy)+b''.join(struct.pack('>2H',t,a)for _,_,t,a in converted))
    require((position+3)&~3==0xba7d08,'Complete original shared cel allocation extent')
    bindings={};cursor=0xba7d08
    for source,(header,_,_,_) in rows.items():bindings[source]=cursor;cursor+=24 if header[1]&128 else 20
    frames=bytearray()
    for source,(header,pointer,_,nxt) in rows.items():
        blob=bytearray(header);struct.pack_into('>I',blob,4,cels[pointer]);blob[16:20]=struct.pack('>2H',*struct.unpack('<2H',header[16:20]))
        if header[1]&128:blob.extend(struct.pack('>I',bindings[nxt]))
        elif nxt is not None:require(bindings[nxt]==bindings[source]+20,'Original shared frame fallthrough')
        frames.extend(blob)
    require(len(frames)==2144,'Complete shared106-frame resource extent');add(bytes(frames))
    return writes,{'frames':106,'cels':len(cels),'native_tiles':len(mapping),'canvas_pixels_checked':checked,'bytes':sum(len(blob)for _,blob in writes)}
