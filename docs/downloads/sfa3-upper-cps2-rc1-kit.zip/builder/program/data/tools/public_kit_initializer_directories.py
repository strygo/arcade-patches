"""Complete retained child-initializer directories for the complete37/38-owner generations."""
import hashlib
import struct
from public_kit_graphics import require


def construct(inputs,recipe):
    require(set(inputs)=={'arcade'},'Canonical original initializer source only')
    raw=inputs['arcade'];pin=recipe['inputs']['arcade']
    require(len(raw)==pin['bytes']==0x400000 and hashlib.sha256(raw).hexdigest()==pin['sha256'],'Original initializer image identity')
    root=recipe['native_root'];require(type(root)is int and 0xd0000<=root<=0xe4000-128,'Native initializer directory extent')
    prefix=raw[root:root+128]
    require(hashlib.sha256(prefix).hexdigest()==recipe['native_sha256'],'Whole native32-owner initializer prefix')
    values=list(struct.unpack('>32I',prefix));added=recipe['added']
    require(set(added)=={'32','33','34','35'} and all(type(v)is int and v%2==0 and 0<v<0x100000 for v in added.values()),'Four source-bound complete initializer entrypoints')
    require(set(recipe['tables'])=={'37','38'},'Complete current initializer generations')
    writes=[]
    for count in (37,38):
        target=recipe['tables'][str(count)]
        require(type(target)is int and target%4==0 and 0xb70000<=target<=0xc74000-count*4,'Whole initializer directory allocation')
        selected=values+[added['32'],added['33'],added['34'],added['35'],values[2],values[21]]
        if count>=37:
            # The original Evil producer restores native Ryu's constructor.
            # Hawk fills the held35 slot in this same37-owner generation.
            selected[23]=values[0]
        writes.append((target,struct.pack('>'+str(count)+'I',*selected[:count])))
    return writes,{'native_owners':32,'generations':[37,38],'bytes':300,'Evil_native_Ryu_initializer_restored':True}
