"""Original shared effect placement directories and complete added pose banks."""
import hashlib
import struct
from public_kit_graphics import require


def construct(inputs, recipe):
    require(set(inputs)==set(recipe['inputs'])=={'arcade','comp2','comp2-jp','key'},'Effect placement original inventory')
    for name,blob in inputs.items():
        pin=recipe['inputs'][name]
        require(len(blob)==pin['bytes'] and hashlib.sha256(blob).hexdigest()==pin['sha256'],'Effect placement original identity '+name)
    region=recipe['region'];require(region in ('us','jp'),'Effect placement region')
    from cps2_crypt import decrypt_rom
    raw=inputs['arcade'];ops=decrypt_rom(raw[:0x100000],inputs['key'])[0]
    roots=(0xe09a0,0xe0a20)
    for at,root in zip((0x83a6e,0x83ac0),roots):
        require(ops[at:at+6]==b'\x20\x7c'+struct.pack('>I',root),'Original effect placement consumer binding')
    base=0x60ad00 if region=='us' else 0x60b080
    table=0x74c3f8+(0x5700 if region=='jp' else 0);c2=inputs['comp2']
    def source(at,size):
        require(base<=at<=base+len(c2)-size,'Effect placement source bounds')
        return c2[at-base:at-base+size]
    def pointer(owner,parity=False):
        return struct.unpack('<I',source(table+owner*4+(160 if parity else 0),4))[0]
    def swap(blob):
        out=bytearray(blob);out[::2]=blob[1::2];out[1::2]=blob[::2];return bytes(out)
    for owner in (0,1,23):
        for parity,size in ((False,384),(True,32)):
            native=struct.unpack_from('>I',raw,roots[int(parity)]+owner*4)[0]
            require(raw[native:native+size]==swap(source(pointer(owner,parity),size)),'Complete original native/source placement control')
    require(set(recipe['source_frames'])=={'32','33'},'Complete effect placement added owner domain')
    result=bytearray(raw[roots[0]:roots[0]+128]+bytes(8)+raw[roots[1]:roots[1]+128]+bytes(8))
    counts={}
    for owner in (32,33):
        frames=recipe['source_frames'][str(owner)]
        require(frames==sorted(set(frames)) and len(frames)>1,'Complete source frame inventory')
        require(max(inputs['comp2-jp'][at-0x60b080+17]&31 for at in frames)==13,'Original installed fourteen-pose demand')
        root=pointer(owner);require(pointer(owner,True)==root+224,'Original contiguous normal/parity placement groups')
        destination=0xbc5000+len(result)
        struct.pack_into('>I',result,owner*4,destination)
        struct.pack_into('>I',result,136+owner*4,destination+224)
        result.extend(swap(source(root,256)));counts[str(owner)]=len(frames)
    require(len(result)==784,'Complete shared placement allocation')
    return [(0xbc5000,bytes(result))],{'bytes':784,'directories':2,'owners_per_directory':34,'added_banks':2,'source_frames':counts,'original_control_owners':[0,1,23]}
