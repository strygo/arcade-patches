"""Complete original Evil and Dee ending palette animation resources."""
import hashlib,struct
from public_kit_graphics import require

FAMILIES={'evil':(6,25),'dee':(5,23)}


def project(comp1,comp2,region,family,start):
    require(region in ('us','jp') and family in FAMILIES,'Ending palette cycle domain')
    selector,expected=FAMILIES[family];base=0x60b080 if region=='jp' else 0x60ad00
    def read(at,n):
        require(n>0 and 0<=at-base<=len(comp2)-n,'Original ending palette cycle bounds')
        return comp2[at-base:at-base+n]
    def literal(pc):
        offset=pc+(0x70 if region=='jp' else 0)-0x1f0040
        require(0<=offset<=len(comp1)-8,'Original palette reader instruction bounds')
        high,low=struct.unpack_from('<2I',comp1,offset)
        require(high>>26==15 and low>>26==9 and (high>>16)&31==(low>>21)&31==(low>>16)&31,'Original palette pointer producer instructions')
        value=low&65535;return ((high&65535)*65536+(value-65536 if value&32768 else value))&0xffffffff
    directory=literal(0x3d3c94);families=literal(0x3d4bf0)
    root=directory+struct.unpack('<h',read(directory+selector*2,2))[0]
    frames={};recipes={};colors=bytearray();todo=[root];writes=[];cursor=start;first_color=None
    def add(blob):
        nonlocal cursor
        at=cursor;cursor+=len(blob);writes.append((at,blob));return at
    while todo:
        at=todo.pop()
        if at in frames:continue
        require(len(frames)<128,'Unbounded original ending palette frames')
        header=read(at,8);require(header[0]>0 and header[1] in (0,64,128),'Unknown original palette frame flow')
        pointer=struct.unpack_from('<I',header,4)[0];rows=[]
        for index in range(128):
            destination,bank,offset=struct.unpack('<3H',read(pointer+index*6,6))
            require(bank==24 and destination%32==0 and destination+32<=4096,'Original palette row destination/family')
            source=struct.unpack('<I',read(families+bank,4))[0]+(offset&0xffe0)
            if first_color is None:first_color=source
            raw=read(source,32);position=len(colors);require(position<=0xffe0,'Ending palette color extent')
            colors.extend(b''.join(raw[n:n+2][::-1] for n in range(0,32,2)));rows.append((destination,56,position|(offset&31)))
            if offset&1:break
        else:raise ValueError('Unterminated original ending palette recipe')
        recipes[at]=add(b''.join(struct.pack('>3H',*row) for row in rows))
        successor=struct.unpack('<I',read(at+8,4))[0] if header[1]&128 else None if header[1]&64 else at+8
        frames[at]=(header,successor)
        if successor is not None:todo.append(successor)
    require(len(frames)==expected and len(colors)==expected*32,'Complete original ending palette graph census')
    mapping={}
    for at,(header,_) in sorted(frames.items()):mapping[at]=cursor;cursor+=12 if header[1]&128 else 8
    for at,(header,successor) in sorted(frames.items()):
        blob=header[:4]+struct.pack('>I',recipes[at])
        if header[1]&128:blob+=struct.pack('>I',mapping[successor])
        elif successor is not None:require(mapping[successor]==mapping[at]+8,'Implicit native palette frame successor')
        writes.append((mapping[at],blob))
    biased=cursor-selector*2;add(struct.pack('>h',mapping[root]-biased));add(bytes(colors))
    require(0xa00000<=start<cursor<=0xe00000,'Complete ending palette allocation')
    return writes,{'frames':len(frames),'color_bytes':len(colors),'bytes':cursor-start,'source_root':root,'first_source_color':first_color}


def construct(comp1,comp2,recipe):
    require(recipe['schema']==1 and hashlib.sha256(comp1).hexdigest()==recipe['comp1_sha256'] and hashlib.sha256(comp2).hexdigest()==recipe['comp2_sha256'],'Ending palette original identities')
    require(set(recipe['families'])==set(FAMILIES),'Complete ending palette animation family set')
    writes=[];reports={}
    for family,record in recipe['families'].items():
        output,summary=project(comp1,comp2,recipe['region'],family,record['start'])
        require(summary==record['summary'],'Original ending palette graph inventory differs')
        writes.extend(output);reports[family]=summary
    return writes,reports


def main():
    import argparse,json
    from pathlib import Path
    p=argparse.ArgumentParser(description=__doc__)
    for n in ('comp1','comp2','recipe','outdir'):p.add_argument('--'+n,type=Path,required=True)
    a=p.parse_args();writes,_=construct(a.comp1.read_bytes(),a.comp2.read_bytes(),json.loads(a.recipe.read_text()));data=bytearray(0x400000);mask=bytearray(len(data))
    for at,blob in writes:
        at-=0xa00000;require(not any(mask[at:at+len(blob)]),'Ending palette cycles overlap');data[at:at+len(blob)]=blob;mask[at:at+len(blob)]=b'\1'*len(blob)
    a.outdir.mkdir(exist_ok=True);(a.outdir/'result.bin').write_bytes(data);(a.outdir/'result.mask').write_bytes(mask)


if __name__=='__main__':main()
