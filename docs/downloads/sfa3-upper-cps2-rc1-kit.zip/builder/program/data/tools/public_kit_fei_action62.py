"""Reconstruct complete Fei action62 with source-validated cels and reviewed fields."""
import hashlib
import struct
import public_kit_frame_resources as frames
from public_kit_actor import Data
from public_kit_graphics import require


def graph(inputs,region):
    base=0x60b080 if region=='jp'else 0x60ad00
    table=0x74ef38 if region=='jp'else 0x749838
    data=Data(inputs['comp2'],base,inputs['coords'],0xb04000)
    roots=struct.unpack('<12I',data.read(data.u32(table+33*4),48));targets=data.root(roots[2])[1]
    require(len(targets)==68,'Original complete Fei secondary family')
    allframes,_=frames.owner_graph(data,table,33);chain=[];at=targets[62]
    while at is not None and at not in chain:
        require(at in allframes and len(chain)<100,'Bounded original action62 graph')
        chain.append(at);at=allframes[at][1]
    require(len(chain)==27 and at is None,'Complete original action62 terminal graph')
    return data,allframes,chain


def construct(inputs,recipe,pixels):
    digest=lambda b:hashlib.sha256(b).hexdigest()
    for name,pin in recipe['inputs'].items():
        require(name in inputs and len(inputs[name])==pin['bytes'] and digest(inputs[name])==pin['sha256'],'Original action62 source '+name)
    require(digest(pixels)==recipe['graphics_pixels_sha256'],'Reconstructed artwork identity')
    data,source,chain=graph(inputs,recipe['region']);rows=recipe['frames'];cels={}
    require([r[1]for r in rows]==chain and len(rows)==27,'Complete action62 frame inventory/order')
    for owner,src,native,xy,bank,tiles in recipe['cels']:
        require(owner==33 and src in {source[a][0]for a in chain},'Actual action62 cel owner')
        coords,blob=frames.cel(data,src,xy,tiles,inputs['pixels33'],inputs['mask33'],pixels,bank)
        witness=recipe['cel_witnesses'][str(native)]
        require(digest(blob)==witness['sha256'] and digest(coords or b'')==witness['coordinates_sha256'],'Complete emitted cel and geometry witness')
        cels[src,native]=True
    writes=[];mapping={r[1]:r[2]for r in rows}
    for owner,src,native,cel,nxt in rows:
        original=data.read(src,20);sc,sn,size=source[src]
        require(owner==33 and size==20 and native==0xb9816c+len(writes)*20,'Complete contiguous original action62 allocation')
        require((sc,cel)in cels and nxt==(mapping[sn]if sn is not None else None),'Complete cel/successor projection')
        blob=original[:4]+struct.pack('>I',cel)+original[8:16]+original[16:18][::-1]+original[18:20]
        writes.append((native,bytearray(blob)))
    require([(r['address'],r['before'],r['after'])for r in recipe['edits']]==[('0xb98189','5e','64'),('0xb981ed','5e','64'),('0xb9823d','5f','65')],'Complete reviewed action62 attack-field edits')
    for row in recipe['edits']:
        at=int(row['address'],0);index,offset=divmod(at-0xb9816c,20)
        require(offset==9 and writes[index][1][offset:offset+1]==bytes.fromhex(row['before']),'Original attack-field preimage')
        writes[index][1][offset:offset+1]=bytes.fromhex(row['after'])
    result=[(a,bytes(b))for a,b in writes]
    return result,{'bytes':540,'frames':27,'source_cels':len(cels),'reviewed_attack_edits':3,'sha256':digest(b''.join(b for a,b in result))}
