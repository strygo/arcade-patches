"""Reconstruct complete ranking portrait frame arrays from original native roots.

The original group aliases select four complete 32-owner arrays. The reviewed
ranking expansion preserves those records and extends the owner domain to forty.
Only typed cel bindings and owner aliases are supplied by the portable recipe.
"""
import hashlib
import struct
from public_kit_graphics import require
from public_kit_victory_objects import sources as victory_sources


def construct(inputs, recipe):
    require(set(inputs) == set(recipe['inputs']) == {'arcade', 'comp2'}, 'Ranking portrait source inventory')
    for name, blob in inputs.items():
        pin = recipe['inputs'][name]
        require(len(blob) == pin['bytes'] and hashlib.sha256(blob).hexdigest() == pin['sha256'], 'Ranking source identity '+name)
    original = inputs['arcade']
    pin = recipe['inputs']['arcade']
    require(len(original) == pin['bytes'] and hashlib.sha256(original).hexdigest() == pin['sha256'], 'Ranking portrait original identity')
    require(recipe['source_groups'] == list(range(12, 18)), 'Complete ranking portrait group domain')
    root = 0x301fa2
    starts = [root + struct.unpack_from('>H', original, root + group * 2)[0] for group in recipe['source_groups']]
    unique = list(dict.fromkeys(starts))
    require(len(unique) == 4, 'Four complete original portrait arrays')
    require(all(0x300000 <= start <= len(original) - 256 for start in unique), 'Original portrait array bounds')
    replacements = dict(recipe['replacement_cels'])
    require(set(replacements) == {'23', '32', '33', '34', '35'}, 'Complete imported portrait owner domain')
    require(all(type(v) is int and 0x300000 <= v < 0x1000000 for v in replacements.values()), 'Typed portrait cel pointers')
    cursor = 0x3f9000
    for owner, (commands, _) in victory_sources(inputs['comp2'], recipe['region']).items():
        cursor += len(commands) * 4
        replacements[owner] = cursor
        cursor += 10 + len(commands) * 4
    arrays = []
    for start in unique:
        rows = [original[start + owner * 8:start + (owner + 1) * 8] for owner in range(32)]
        require(all(len(row) == 8 and row[0] == 8 for row in rows), 'Complete original held portrait frames')
        for owner in (21, 23, 30, 31):
            rows[owner] = rows[owner][:4] + struct.pack('>I', replacements[str(owner)])
        # The reviewed new slots use the ordinary owner-zero held-frame header.
        for owner in range(32, 36):
            rows.append(rows[0][:4] + struct.pack('>I', replacements[str(owner)]))
        rows.extend((rows[2], rows[21], rows[0], rows[0]))
        require(len(rows) == 40, 'Expanded forty-owner portrait array')
        arrays.append(b''.join(rows))
    offsets = [40] * 12 + [40 + unique.index(start) * 320 for start in starts] + [0xffff, 0xffff]
    require(len(offsets) == 20, 'Complete portrait group header')
    writes = [(0xaa8d60, struct.pack('>20H', *offsets)), (0xaa8d88, b''.join(arrays))]
    return writes, {'bytes': 1320, 'source_groups': 6, 'unique_original_arrays': 4, 'original_owners': 32, 'expanded_owners': 40}
