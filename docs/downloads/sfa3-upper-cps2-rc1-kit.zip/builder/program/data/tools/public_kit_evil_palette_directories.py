"""Complete original 34-owner primary, effect and prefix palette directories."""
import hashlib
import struct
from public_kit_graphics import require
from public_kit_palettes import catalog
from public_kit_color_arena import resources


def construct(inputs, recipe):
    require(set(inputs) == set(recipe['inputs']) == {'arcade', 'comp2'}, 'Evil palette source inventory')
    for name, blob in inputs.items():
        pin = recipe['inputs'][name]
        require(len(blob) == pin['bytes'] and hashlib.sha256(blob).hexdigest() == pin['sha256'], 'Evil palette original identity '+name)
    require(recipe['owners']==34, 'Complete Evil palette owner domain')
    native = inputs['arcade']; comp2 = inputs['comp2']; region = recipe['region']
    arrays = catalog(comp2, region)
    writes, _ = resources(comp2, native, region)
    arena_at, arena = writes[0]
    require(arena_at == 0x3e0000 and len(arena) >= 384, 'Complete original retained color arena')
    resident = bytearray(native)
    for at, blob in writes: resident[at:at+len(blob)] = blob
    guile = arrays['prefix:32'][1] + arrays['effects:32'][1]
    require(len(guile) == 960, 'Complete Guile effect palette family')
    original_rows = {'effects': list(struct.unpack('>32I', arena[-384:-256])) + [0xa2e0c0],
                     'prefix': list(struct.unpack('>32I', arena[-256:-128])) + [0xa2e000]}
    additions = []; cursor = 0xba6500
    def read(at, size):
        if 0 <= at <= len(resident)-size: return resident[at:at+size]
        if 0xa2e000 <= at <= 0xa2e000+len(guile)-size: return guile[at-0xa2e000:at-0xa2e000+size]
        for base, blob in additions:
            if base <= at <= base+len(blob)-size: return blob[at-base:at-base+size]
        raise ValueError('Unbound original palette read '+hex(at))
    def add(blob):
        nonlocal cursor
        at=cursor; cursor+=len(blob); additions.append((at,blob)); return at
    primary = [0x3df000+(960 if owner==20 else 0) if owner in (18,20) else
        0x32c094+struct.unpack_from('>H',native,0x32c094+owner*2)[0] for owner in range(32)]
    primary += [0x3fa000, 0xb08000]
    primary[23] = 0xba6090
    result = [(0xba6000, struct.pack('>34I', *primary))]
    reuse=[]
    for role in ('effects', 'prefix'):
        rows=original_rows[role][:]
        if role=='prefix': require(read(rows[23],192)==arrays['prefix:23'][1], 'Original retained Evil prefix')
        for owner in ((23,33) if role=='effects' else (33,)):
            blob=arrays[role+':'+str(owner)][1]
            target=next((at for at in rows if read(at,len(blob))==blob),None)
            reused=target is not None
            if target is None: target=add(blob)
            if owner==len(rows): rows.append(target)
            else: rows[owner]=target
            reuse.append({'role':role,'owner':owner,'reused':reused,'target':target})
        require(len(rows)==34, 'Complete extended palette owner domain')
        blob=struct.pack('>34I',*rows);at=add(blob);result.append((at,blob))
    require([at for at,_ in result]==[0xba6000,0xba6b00,0xba6c48], 'Complete original palette allocation order')
    return result, {'bytes':408,'directories':3,'owners':34,'source_reuse':reuse}
