"""Complete original ending command streams, lookahead and parameter siblings."""
import hashlib,struct
from public_kit_graphics import require

# destination, original semantic records/bytes, terminal prefetch bytes,
# exact original selector aliases, optional source/native stage handoff.
FAMILIES={'32':(0xa99a00,117,1080,28,[73],None),
 '33':(0xbf9000,123,1124,28,[72,105],None),
 '34':(0xc60000,67,656,20,[37],(64,68,132)),
 '35':(0xd81000,54,566,22,[],(50,70,134)),
 '37':(0xc82000,108,926,24,[],(105,74,138))}
PARAMETERS={32:0xa99f60,33:0xbf9dd0,34:0xc6082c,35:0xd813b0,21:0xc82aa2,37:0xc82aa8}


def command(read,at,endian):
    timer,tag=struct.unpack(endian+'2H',read(at,4));count=tag&15
    values=struct.unpack(endian+str(count)+'H',read(at+4,count*2))if count else ()
    return [timer,tag,values],at+4+count*2


def parse(read,root,endian):
    rows=[];at=root
    for _ in range(2048):
        row,at=command(read,at,endian);rows.append(row)
        if row[1]>>8==0 and row[1]&0x70==0:
            require(row[1]&15==0,'Original terminal command has parameters');return rows,at
    raise ValueError('Unbounded original ending command stream')


def pack(rows):return b''.join(struct.pack('>'+str(2+len(v))+'H',t,tag,*v)for t,tag,v in rows)


def construct(inputs,recipe):
    require(set(inputs)==set(recipe['inputs'])=={'comp2'},'Ending command source inventory')
    data=inputs['comp2'];pin=recipe['inputs']['comp2']
    require(len(data)==pin['bytes']and hashlib.sha256(data).hexdigest()==pin['sha256'],'Original ending command identity')
    region=recipe['region'];require(region in ('us','jp'),'Ending command source region')
    require(recipe['owners']==list(FAMILIES),'Complete ending command sibling domain')
    base=0x60ad00 if region=='us'else 0x60b080;shift=0x10f0 if region=='jp'else 0
    def read(at,size):
        require(0<=at-base<=len(data)-size,'Original ending command read bounds')
        return data[at-base:at-base+size]
    writes=[];reports=[];applied=[]
    for owner,(dest,count,size,prefetch,aliases,stage)in FAMILIES.items():
        roots=[struct.unpack('<I',read(table+shift+int(owner)*4,4))[0]for table in (0x60b860,0x60b910)]
        require(roots[0]==roots[1],'Original ending command mode aliases')
        rows,end=parse(read,roots[0],'<')
        require(len(rows)==count and end-roots[0]==size,'Complete original ending command census '+owner)
        require([n for n,row in enumerate(rows)if row[1]==0xa200]==aliases,'Exact original aliased selector demand')
        for index in aliases:
            require(rows[index][0]==0 and rows[index][2]==(),'Original aliased selector has no timer/arguments')
            rows[index][1]=0x4200
        if stage:
            index,old,new=stage
            require(rows[index][1:]==[0x401,(old,)],'Original ending stage handoff preimage')
            rows[index][2]=(new,)
        footer,stop=command(read,end,'<')
        require(stop-end==prefetch and 2<=footer[0]<32768,'Complete original held terminal prefetch')
        blob=bytearray(pack(rows+[footer]))
        for amendment in recipe['timer_amendments']:
            at,before,after=amendment
            if dest<=at<dest+size:
                offset=at-dest
                require(struct.unpack_from('>H',blob,offset)[0]==before,'Reviewed whole-command timer preimage')
                # Timer edits must address the first word of an actual command.
                starts=[];cursor=dest
                for t,tag,values in rows:starts.append(cursor);cursor+=4+2*len(values)
                require(at in starts,'Reviewed timer edit is not a command boundary')
                struct.pack_into('>H',blob,offset,after);rows[starts.index(at)][0]=after;applied.append(amendment)
        require(len(blob)==size+prefetch,'Complete emitted ending command allocation')
        def emitted(at,n):
            require(0<=at-dest<=len(blob)-n,'Emitted ending command read bounds')
            return blob[at-dest:at-dest+n]
        parsed,parsed_end=parse(emitted,dest,'>')
        require(parsed==rows and parsed_end==dest+size and command(emitted,parsed_end,'>')[0]==footer,'Complete emitted command and prefetch grammar roundtrip')
        writes.append((dest,bytes(blob)));reports.append({'owner':int(owner),'records':count,'semantic_bytes':size,'lookahead_bytes':prefetch})
    require(len(applied)==len(recipe['timer_amendments'])==6,'Complete reviewed timer amendment inventory')
    for owner,dest in PARAMETERS.items():
        values=struct.unpack('<3H',read(0x60b9c0+shift+owner*6,6));writes.append((dest,struct.pack('>3H',*values)))
    return writes,{'bytes':sum(len(b)for _,b in writes),'families':reports,'parameter_records':6,'reviewed_timer_amendments':6}
