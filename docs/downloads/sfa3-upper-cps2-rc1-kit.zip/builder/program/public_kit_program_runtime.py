"""Rebuild compact program foundations from originals and admitted pure workers.

This output is a residual-patch base, not a completed game. No development
compiler or candidate ROM is a runtime input. All sparse providers must match
qualified complete image and ownership identities before physical projection.
"""
import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import shutil
import subprocess
import sys
import tempfile

sys.dont_write_bytecode=True

PROVIDERS=('authored_native_objects','authored_native_adapters','authored_retained_guile','authored_residuals','compact_cpu_tables')
MEMBERS={'jp':('sz3j.03c','sz3j.04c','sz3.05c','sz3.06c','sz3.07c','sz3.08c','sz3.09c','sz3.10b'),
         'us':('sz3u.03c','sz3u.04c','sz3.05c','sz3.06c','sz3.07c','sz3.08c','sz3.09c','sz3.10b')}
CANONICAL='600f686a6ef90225c48231c0fbad86c7ca2b4eeddc93691b479a5b8a3f3b3cd5'
SIZE=0x400000
FAMILY_MODES=('pools','pools-canvas','pools-descriptors-canvas','inputs','program-key')
CANVAS='families/public_kit_program_canvas.py'
GEOMETRY='families/geometry/public_kit_residual_naomi_geometry_sources.py'
NAOMI_CONTRACT='families/naomi-contract.json'

def require(ok,message):
    if not ok:raise ValueError(message)
def digest(blob):return hashlib.sha256(blob).hexdigest()
def swap(blob):
    require(len(blob)%2==0,'Whole source words');out=bytearray(len(blob));out[::2]=blob[1::2];out[1::2]=blob[::2];return bytes(out)
def relative(name):
    require(type(name)is str and name and '\\'not in name,'Portable resource path')
    p=PurePosixPath(name);require(not p.is_absolute() and all(s not in ('','.','..')for s in name.split('/')),'Contained resource path');return p

def verify_files(root,plan):
    require(plan['schema']==1 and type(plan['schema'])is int,'Program plan version')
    require(set(plan)=={'schema','files','providers','jobs','families','originals','exclusions'},'Program plan schema')
    require({p.relative_to(root).as_posix()for p in root.rglob('*')if p.is_file()}==set(plan['files'])|{'program-plan.json'},'Exact runtime file inventory')
    for name,pin in plan['files'].items():
        p=root/relative(name);require(p.resolve().is_relative_to(root.resolve()) and not any(v.is_symlink()for v in (p,*p.parents)if v!=root.parent) and p.is_file() and not p.is_symlink(),'Missing regular runtime file: '+name)
        b=p.read_bytes();require(set(pin)=={'bytes','sha256'} and type(pin['bytes'])is int and len(b)==pin['bytes'] and digest(b)==pin['sha256'],'Runtime file identity: '+name)
    require(set(plan['providers'])==set(PROVIDERS),'Complete admitted provider census')
    for name,row in plan['providers'].items():
        require(set(row)=={'recipe','regions'} and row['recipe']==name+'.json' and row['recipe']in plan['files'] and set(row['regions'])=={'us','jp'},'Provider recipe and regional binding')
    require({j['id']for j in plan['jobs']}=={f'{kind}-{r}'for kind in ('main','data')for r in MEMBERS} and len(plan['jobs'])==4,'Complete pure resource job census')
    for j in plan['jobs']:
        require(set(j)=={'id','kind','region','entry','recipes','image'},'Resource job schema')
        require(j['kind']in ('main','data') and j['region']in MEMBERS and j['id']==j['kind']+'-'+j['region'],'Resource job binding')
        require(j['entry']==j['kind']+'/tools/public_kit_'+('main_resources'if j['kind']=='main'else'data')+'.py','Admitted pure entrypoint')
        require(j['entry']in plan['files'] and j['recipes']==j['kind']+'/recipes','Declared resource namespace')
    require(CANVAS in plan['files'] and GEOMETRY in plan['files'] and NAOMI_CONTRACT in plan['files'] and type(plan['families'])is list and len({f['id']for f in plan['families']})==len(plan['families']),'Resource family census')
    for f in plan['families']:
        require(set(f)=={'id','entry','mode','recipe','regions'} and f['mode']in FAMILY_MODES,'Resource family schema')
        require(f['entry'].startswith('families/tools/') and f['entry']in plan['files'] and f['recipe']==f'families/recipes/{f["id"]}.json' and f['recipe']in plan['files'],'Admitted family worker and recipe')
        require(set(f['regions'])=={'us','jp'} and all(r and set(r)<={'main','upper'}for r in f['regions'].values()),'Family regional image binding')
    return True

def image_check(data,mask,pin):
    require(len(data)==len(mask)==SIZE and set(mask)<={0,1},'Complete sparse image geometry')
    require(set(pin)=={'bytes','sha256','mask_sha256','verified_bytes'} and pin['bytes']==SIZE and digest(data)==pin['sha256'] and digest(mask)==pin['mask_sha256'] and sum(mask)==pin['verified_bytes'],'Qualified image and mask identity')

def merge(data,owned,blob,mask):
    require(len(data)==len(owned)==len(blob)==len(mask) and set(mask)<={0,1},'Merge geometry')
    for i,flag in enumerate(mask):
        if flag:
            require(not owned[i] or data[i]==blob[i],'Conflicting admitted resource at '+hex(i))
            data[i]=blob[i];owned[i]=1

def sparse(writes):
    result={n:(bytearray(SIZE),bytearray(SIZE))for n in ('main','upper')}
    for row in writes:
        address,blob=row[:2];require(type(address)is int and isinstance(blob,bytes) and blob,'Typed nonempty write')
        view='main'if address<0x400000 else'upper';offset=address if view=='main'else address-0xa00000
        require(0<=offset<offset+len(blob)<=SIZE,'Complete allocation bounds')
        data,mask=result[view];require(not any(mask[offset:offset+len(blob)]),'Overlapping provider objects')
        data[offset:offset+len(blob)]=blob;mask[offset:offset+len(blob)]=b'\1'*len(blob)
    return result

def provider(name,recipe,key,pools):
    if name=='authored_native_objects':
        import public_kit_authored_native_objects as module
        return module.images(module.construct(recipe,key))
    if name=='authored_native_adapters':
        import public_kit_authored_native_adapters as module
        return module.images(module.construct(recipe,key,{n:(pools/n).read_bytes()for n in module.ORIGINAL_INPUTS}))
    if name=='authored_retained_guile':
        import public_kit_authored_retained_guile as module
        return sparse(module.construct(recipe))
    if name=='authored_residuals':
        import public_kit_authored_residuals as module
        return sparse(module.construct(recipe))
    if name=='compact_cpu_tables':
        import public_kit_compact_cpu_tables as module
        writes,_=module.construct(module.load_inputs(pools,recipe['region']),recipe)
        return sparse(writes.values())
    raise ValueError('Unadmitted runtime provider')

LAUNCHER='import runpy,sys;from pathlib import Path;p=Path(sys.argv.pop(1));extra=[v for v in sys.argv.pop(1).split("|")if v];sys.path[:0]=[str(p.parent),*extra];runpy.run_path(str(p),run_name="__main__")'

def isolated(entry,paths,args,work,log):
    command=[sys.executable,'-I','-B','-c',LAUNCHER,str(entry.resolve()),'|'.join(map(str,paths)),*map(str,args)]
    with log.open('w')as stream:
        status=subprocess.run(command,cwd=work,stdout=stream,stderr=subprocess.STDOUT,timeout=1800)
    require(status.returncode==0,'Isolated program step failed: '+log.name+'\n'+log.read_text()[-12000:])

def canvas(root,region,pools,work,canvases):
    if region not in canvases:
        folder=work/('canvas-'+region)
        isolated(root/CANVAS,[(root/'data/tools').resolve()],['--pools',pools.resolve(),'--recipes',(root/'data/recipes').resolve(),'--region',region,'--out',folder],work,work/('canvas-'+region+'.log'))
        canvases[region]=folder
    return canvases[region]

def descriptors(root,work,canvases,naomi):
    if 'descriptors' not in canvases:
        require(naomi is not None,'Original Naomi GD-ROM, PIC and chdman required for descriptor families')
        folder=work/'descriptors';scratch=work/'naomi-scratch';scratch.mkdir()
        isolated(root/GEOMETRY,[],['--contract',(root/NAOMI_CONTRACT).resolve(),'--naomi-chd',naomi['chd'],'--naomi-pic',naomi['pic'],
                 '--chdman',naomi['chdman'],'--scratch',scratch.resolve(),'--out',folder],work,work/'descriptors.log')
        shutil.rmtree(scratch);canvases['descriptors']=folder
    return canvases['descriptors']

def family_run(root,family,region,pools,work,shared,canvases,naomi=None):
    recipe=json.loads((root/relative(family['recipe'])).read_text())
    require(set(recipe)=={'us','jp'},'Family recipe regions')
    path=work/(family['id']+'-'+region+'.json');path.write_text(json.dumps(recipe[region],sort_keys=True,indent=2)+'\n')
    folder=work/(family['id']+'-'+region);mode=family['mode']
    args=['--recipe',path,'--out',folder]
    if mode=='inputs':args+=['--inputs',shared.resolve()]
    elif mode=='program-key':args+=['--key',(shared/'key.bin').resolve()]
    else:args+=['--pools',pools.resolve()]
    if mode in ('pools-canvas','pools-descriptors-canvas'):
        source=canvas(root,region,pools,work,canvases);args+=['--canvas',source/'canvas.bin']
        if mode=='pools-descriptors-canvas':args+=['--descriptors',descriptors(root,work,canvases,naomi)]
    isolated(root/relative(family['entry']),[],args,work,work/(family['id']+'-'+region+'.log'))
    return folder

def run(root,plan,pools,ending_pools,out,naomi=None):
    verify_files(root,plan);require(not out.exists(),'Fresh program output required')
    require(all(not out.resolve().is_relative_to(p.resolve())for p in (root,pools,ending_pools)),'Output overlaps immutable runtime or originals')
    require(pools.is_dir()and ending_pools.is_dir(),'Original extracted pools required')
    def originals():
        for name,pin in plan['originals'].items():
            b=(pools/relative(name)).read_bytes();require(len(b)==pin['bytes']and digest(b)==pin['sha256'],'Original input identity: '+name)
        pieces=[(pools/('arcade-jp-'+n)).read_bytes()for n in MEMBERS['jp']]
        require(all(len(b)==0x80000 for b in pieces),'Eight complete canonical members')
        canonical=swap(b''.join(pieces));require(digest(canonical)==CANONICAL,'Canonical original foundation identity')
        return canonical,(pools/'arcade-jp-sfz3j.key').read_bytes()
    canonical,key=originals();out.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='program-runtime-',dir=out.parent)as scratch:
        work=Path(scratch);published=work/'publish';published.mkdir();reports={}
        # Shared original inputs for families that take an explicit input
        # directory: the canonical JP arcade program/key and JP PS2 components.
        shared=work/'family-inputs';shared.mkdir()
        (shared/'arcade.bin').write_bytes(canonical);(shared/'key.bin').write_bytes(key)
        for name in ('comp1','comp2'):(shared/(name+'.bin')).write_bytes((pools/('ps2-jp-'+name+'.bin')).read_bytes())
        canvases={}
        for region in MEMBERS:
            data={'main':bytearray(canonical),'upper':bytearray(b'\xff'*SIZE)};owned={n:bytearray(SIZE)for n in data};proof=[]
            for job in (j for j in plan['jobs']if j['region']==region):
                folder=work/job['id'];entry=root/job['entry'];args=['--region',region,'--pools',str(pools.resolve()),'--recipes',str((root/job['recipes']).resolve()),'--out',str(folder)]
                if job['kind']=='data':args+=['--ending-pools',str(ending_pools.resolve())]
                launcher='import runpy,sys;from pathlib import Path;p=Path(sys.argv.pop(1));sys.path.insert(0,str(p.parent));runpy.run_path(str(p),run_name="__main__")'
                log=work/(job['id']+'.log')
                print('Original resource job:',job['id'],flush=True)
                with log.open('w')as stream:
                    status=subprocess.run([sys.executable,'-I','-B','-c',launcher,str(entry.resolve()),*args],cwd=work,stdout=stream,stderr=subprocess.STDOUT,timeout=1800)
                require(status.returncode==0,'Pure resource job failed: '+job['id']+'\n'+log.read_text()[-12000:])
                image='main'if job['kind']=='main'else'upper';stem='main'if image=='main'else region
                blob=(folder/(stem+'.bin')).read_bytes();mask=(folder/(stem+'.mask')).read_bytes();image_check(blob,mask,job['image'])
                merge(data[image],owned[image],blob,mask);proof.append({'provider':job['id'],'images':{image:job['image']}})
            for name in PROVIDERS:
                print('Admitted program provider:',region,name,flush=True)
                contract=plan['providers'][name];recipe=json.loads((root/contract['recipe']).read_text())[region]
                images=provider(name,recipe,key,pools)
                for view,pin in contract['regions'][region].items():
                    blob,mask=map(bytes,images[view]);image_check(blob,mask,pin);merge(data[view],owned[view],blob,mask)
                for view,(_,mask)in images.items():require(view in contract['regions'][region]or not any(mask),'Undeclared provider view')
                proof.append({'provider':name,'images':contract['regions'][region]})
            for family in plan['families']:
                print('Original resource family:',region,family['id'],flush=True)
                folder=family_run(root,family,region,pools,work,shared,canvases,naomi)
                for view,pin in family['regions'][region].items():
                    blob=(folder/(view+'.bin')).read_bytes();mask=(folder/(view+'.mask')).read_bytes()
                    image_check(blob,mask,pin);merge(data[view],owned[view],blob,mask)
                for view in ('main','upper'):
                    extra=folder/(view+'.mask')
                    require(view in family['regions'][region] or not extra.exists() or not any(extra.read_bytes()),'Undeclared family view')
                proof.append({'provider':family['id'],'images':family['regions'][region]})
            destination=published/region;destination.mkdir();members={}
            for i,name in enumerate(MEMBERS[region]):
                blob=swap(data['main'][i*0x80000:(i+1)*0x80000]);(destination/name).write_bytes(blob);members[name]={'bytes':len(blob),'sha256':digest(blob)}
            blob=swap(data['upper']);(destination/'upper.prg').write_bytes(blob);members['upper.prg']={'bytes':len(blob),'sha256':digest(blob)}
            reports[region]={'members':members,'explicit_provider_bytes':{n:sum(v)for n,v in owned.items()},'providers':proof,'complete_game':False,'requires_exact_residual_patch':True}
        originals();verify_files(root,plan)
        (published/'runtime-report.json').write_text(json.dumps({'regions':reports,'development_build_chain':False,'candidate_rom_read':False,'excluded':plan['exclusions']},sort_keys=True,indent=2)+'\n')
        published.rename(out)
    return reports

def self_test():
    data=bytearray(b'abcdefgh');owned=bytearray(8);merge(data,owned,b'00XY0000',bytes([0,0,1,1,0,0,0,0]));require(data==b'abXYefgh','Independent overlay fixture')
    rejected=[]
    for name,blob,mask in [('conflict',b'00ZZ0000',bytes(owned)),('mask',b'12345678',bytes([2])*8),('length',b'0',b'\1')]:
        try:merge(data,owned,blob,mask)
        except ValueError:rejected.append(name)
        else:raise ValueError('Mutation accepted: '+name)
    for value in ('../escape','/absolute','a/../b'):
        try:relative(value)
        except ValueError:rejected.append(value)
        else:raise ValueError('Unsafe path accepted')
    require(swap(b'abcd')==b'badc','Physical projection fixture')
    return {'passed':True,'rejected':rejected}

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--plan',type=Path,default=Path(__file__).with_name('program-plan.json'))
    for n in ('pools','ending-pools','out','naomi-chd','naomi-pic','chdman'):p.add_argument('--'+n,type=Path)
    p.add_argument('--self-test',action='store_true');a=p.parse_args()
    if a.self_test:print(json.dumps(self_test()));return
    require(a.pools and a.ending_pools and a.out,'Original pools, ending pools and fresh output required')
    naomi={'chd':a.naomi_chd.resolve(),'pic':a.naomi_pic.resolve(),'chdman':a.chdman.resolve()}if a.naomi_chd and a.naomi_pic and a.chdman else None
    run(Path(__file__).resolve().parent,json.loads(a.plan.read_text()),a.pools,a.ending_pools,a.out,naomi)
if __name__=='__main__':main()
