Ultra Street Fighter II — reconstruction kit



Version: rc8 (2026-11-18)

Backport by: Steve Gordon (https://x.com/strygo)



Ultra Street Fighter II: The Final Challengers is the 2017 Nintendo Switch edition of Super Street Fighter II Turbo, and it never had an arcade release. This backport rebuilds it as a CPS-2 game.

Akuma has his own select cell, and Evil Ryu and Violent Ken join the original sixteen fighters with their Ultra moves, colors and endings. Shin Akuma stays hidden, for twenty fighters in all.

Ultra's presentation comes with them: the Ultra title and intro, "The Final Challengers" lettering, a color select for the new fighters, and a choice of sixteen stages or Random once you have picked a fighter.

The Switch edition's sound effects play in every build, and on MiSTer its arranged music plays too. Choose ORIGINAL, CLASSIC or MODERN sound in ULTRA CONFIGURATION; MODERN is the default. CLASSIC adds the Switch edition's classic announcer, while ORIGINAL keeps the earlier arcade sound. On MiSTer you can choose the music there too. MODERN controls are the default; choose CLASSIC controls to retain the earlier command inputs.

The USA build is in English; the Japan build keeps the Japanese.

This is a release candidate.



Changes:

- Akuma on his own select cell, with Evil Ryu and Violent Ken: twenty fighters with the hidden Shin Akuma

- Ultra's classic colors for the new fighters, chosen on a color select screen

- Sixteen stages and Random to choose from after you pick a fighter

- The Ultra title and intro, and ULTRA on the VS, Continue and Game Over screens

- ORIGINAL, CLASSIC and MODERN sound options, with the Switch edition's classic announcer in CLASSIC and arranged music on MiSTer

- MODERN command inputs with more forgiving motions, or CLASSIC inputs, selected in ULTRA CONFIGURATION

- Configurable game speed, an optional player speed choice and a shared match-length setting for Arcade and Versus

- USA (English) and Japan builds

INPUTS
  - Canonical MAME-format ssf2xj and its parent/shared members (ssf2t).
    Complete, merged, split ZIP/7z and loose layouts are supported by hash.
    7z needs installed 7-Zip. Supply canonical QSound dl-1425.bin as well.
  - USA base USF2 NSP or supported US card XCI for USA output; Japanese base
    NSP or supported JP card XCI for Japanese output. XCI needs no conversion.
    Both are required when you explicitly select --region all. Supported identities are in kit.json.
    Container packaging may differ: the complete Program NCA and decrypted
    regional resource must match the supported hashes in kit.json. Filenames
    and the outer NSP/XCI hash are not acceptance criteria. Only declared
    Program variants are supported. Update-only images do not supply the base
    game; separately bundled updates are ignored, never applied.
  - Your own prod.keys. Keys are never bundled or downloaded.
  - Python 3.10+. No Git, CMake, C/C++ compiler or NumPy is required.
    The installer downloads the current host's pinned extraction helpers,
    verifies their archive and member SHA-256 hashes, and caches them.
  - MiSTer music generation fetches the pinned FFmpeg/ffprobe pair on demand.
    No separate FFmpeg installation is required. It uses fixed-point Opus
    decoding and the required ADX conversion. Any differing final music
    bytes fail the published CPK hash check.
    Advanced users can set CPSPLUS_FFMPEG to their own executable.

CHOOSE YOUR OUTPUT FIRST
  Target       Switches               Result
  MiSTer       --platform mister      Core, MRA, ROMs and music
  Stock MAME   --platform mame        hsf2/hsf2j ROM ZIP
  Darksoft     --platform darksoft    Native-audio flash files
  HBMAME       --platform hbmame      Custom ROM ZIP
  FBNeo        --platform fbneo       ZIP using established FBNeo member names
  Everything   --platform all         All supported outputs

  --platform is optional and defaults to all. There is one game configuration
  per region, with selectable ORIGINAL/CLASSIC/MODERN sound effects.
  The region follows the supplied game files: USA only, Japan only, or both.
  Use --region us, jp or all to override this; explicit all requires both.
  --source-us and --source-jp accept supported NSP/XCI inputs. --nsp-us/--nsp-jp
  remain aliases for existing commands; --xci-us/--xci-jp are also accepted.
  Supported USA and Japan card inputs are listed in kit.json. Other Program
  NCA content requires a separately verified identity.

  Darksoft includes ORIGINAL/CLASSIC/MODERN sound effects with native music.
  Copy darksoft/games/usf2_us or usf2_jp to the card games folder. The menu
  identifies USF2 separately from HSF2. CPS+ streamed arrangements are
  unavailable on this target. Keep receipts and
  the verification folder on your computer; only the game folder goes on the card.

WINDOWS QUICK START (COMMAND PROMPT OR POWERSHELL)
  Extract the kit into a short local folder, for example C:\USF2. Open a
  terminal in that folder, containing apply.py. Put your arcade ZIPs in roms/,
  your USA base NSP in inputs/usf2-us.nsp and your keys in inputs/prod.keys.
  Keep complete paths in quotes if they contain spaces. Use the actual NSP
  filename, or rename your owned file to match these examples.

  Check dependencies:
    py -3 --version
  No compiler or Python package installation is required.

  MiSTer USA (paste this entire command on one line):
    py -3 apply.py --rompath roms --nsp-us inputs/usf2-us.nsp --keys inputs/prod.keys --region us --platform mister --work scratch-mister --out-dir output-mister

  Stock MAME USA (one line; does not require FFmpeg):
    py -3 apply.py --rompath roms --nsp-us inputs/usf2-us.nsp --keys inputs/prod.keys --region us --platform mame --work scratch-mame --out-dir output-mame

  Stock MAME USA from an XCI (one line):
    py -3 apply.py --rompath roms --source-us "inputs/USF2 USA.xci" --keys inputs/prod.keys --region us --platform mame --work scratch-xci --out-dir output-xci

  HBMAME USA (one line; see HBMAME below):
    py -3 apply.py --rompath roms --nsp-us inputs/usf2-us.nsp --keys inputs/prod.keys --region us --platform hbmame --work scratch-hbmame --out-dir output-hbmame

  If your Python command is python or python3, substitute it for py -3,
  --work and --out-dir are optional. Without --work, the installer uses a
  temporary scratch folder and removes it when the command finishes or fails.
  Without --out-dir, it chooses output-usf2 in your current folder, then
  output-usf2-2, output-usf2-3, etc. if needed. An explicit output folder must
  not already exist; existing results are never overwritten.
  Setup errors print a short explanation. Add --debug to your command if
  you need the full Python traceback when reporting a problem.
  A MiSTer build checks for FFmpeg before extracting game resources.

  Paths may be relative to the terminal's current folder or absolute. For
  example, --nsp-us "D:\Switch dumps\USF2 USA.nsp" is one argument. Do not
  paste the Unix backslash line continuations below into a Windows shell.
  Use the layout and commands above with a fresh --work directory. Keep the
  full failing command and console output when reporting an error.
  Prefer a short local --work path over network/mapped drives
  or cloud-synced folders for extraction and reconstruction.

BUILD ALL OUTPUTS
  macOS/Linux shell (both regional NSPs):
  python3 apply.py --rompath ROM_DIRECTORY --nsp-us USA_BASE.nsp \
    --nsp-jp JAPAN_BASE.nsp --keys prod.keys --work scratch --out-dir output \
    --platform all

  --region us|jp|all      Optional override; otherwise inferred from game files.
  --out-dir PATH         Optional fresh destination (default: unused output-usf2).
  --work PATH            Optional scratch folder to retain instead of a temporary one.
  --platform mame|hbmame|fbneo|mister|darksoft|all (default: all).
  --check                Verify arcade inputs and decrypt NSP/XCI resources only.

  The installer checks input paths and arcade ROMs before preparing helpers
  or extracting game resources. Missing-file errors show the supplied path,
  resolved path and current folder. On Windows, inputs/game.nsp is relative
  to the current folder; /inputs/game.nsp starts at the current drive root.
  Valid absolute paths are supported and are never silently rewritten.
  It prints each major stage, then lists the finished ZIPs and the launch or
  copy instructions for your selected target.

  Output must be fresh. Inputs are never modified. The build stages privately
  and publishes the completed tree only after exact ROM/MRA/music checks pass.
  Source tools are fetched as pinned verified binaries; no game data is downloaded.

OFFLINE TOOLS AND CACHE
  --tools-bundle PATH    Use the offline tools ZIP or directory of per-host ZIPs.
                        No helper downloads are attempted when this is supplied.
  --tools-cache PATH     Choose the shared verified helper cache location.
  --offline              Never download helpers; require a cache or tools bundle.

  Download the matching offline tools bundle on a connected computer, copy it
  alongside this kit, then add --tools-bundle cpsplus-tools-v2-offline.zip
  --offline to the normal apply.py command. Tools are selected for the current
  Python architecture. A missing host archive, changed helper or unsupported
  host fails before any helper is executed. Cached tools are rechecked on use.
  The toolkit never substitutes a different decoder or compiles a fallback.
  The combined bundle includes FFmpeg/ffprobe and their corresponding source.
  Shared tools and offline bundle:
  https://github.com/strygo/arcade-patches/releases/tag/ffmpeg-helpers-v1

OUTPUTS
  mame/hsf2.zip               USA, stock MAME (ORIGINAL/CLASSIC/MODERN audio).
  mame/hsf2j.zip              Japan, stock MAME (ORIGINAL/CLASSIC/MODERN audio).
  mame/RUN-MAME.txt           Launch commands for stock MAME.
  fbneo/usf2u.zip             USA, FBNeo with matching game definitions.
  fbneo/usf2j.zip             Japan, FBNeo with matching game definitions.

  hbmame/usf2u.zip            USA, HBMAME (ORIGINAL/CLASSIC/MODERN audio).
  hbmame/usf2j.zip            Japan, HBMAME (ORIGINAL/CLASSIC/MODERN audio).
  mister/games/mame/          The same usf2u.zip / usf2j.zip names as HBMAME.
                             Complete native archives (firmware included).
  mister/games/CPS+/          The generated usf2_arrange.zip / CPK.
  mister/_Arcade/             USA/Japan CPS+ MRAs and the CPS2+ core.
  verification.json          Exact selected profile and assembled-image hashes.

  Copy the contents of mister/ to the MiSTer card. Both MRAs use the included
  CPS2+ core and require 128 MiB SDRAM. Demo sounds, MODERN sound effects and
  MODERN music are enabled by default.

  In Test Mode > ULTRA CONFIGURATION:
  - SOUND EFFECTS: ORIGINAL / CLASSIC / MODERN. MODERN is the default.
    ORIGINAL retains the previous Classic sound and saved preference.
    CLASSIC adds the Switch edition's classic announcer. Both retain the
    imported Evil Ryu and Violent Ken voices.
  - CONTROLS: MODERN / CLASSIC. MODERN is the default; CLASSIC keeps the
    earlier command inputs. Both players use the choice from the next new game.
  - MAX ROUND: 2 ROUND / 4 ROUND / 6 ROUND. The default is 4 ROUND, shared
    by Arcade and Versus.
  - MUSIC: MODERN / CLASSIC, visible when the MRA enables streamed music.

  Test Mode > SYSTEM CONFIGURATION has GAME SPEED (NORMAL, MODERN, TURBO 1-4)
  and a separate SPEED SELECT (OFF / ON). The defaults are MODERN and OFF.
  SPEED SELECT enables the original player speed choice; turning it off
  restores the configured GAME SPEED.

  Existing saved settings take precedence. Change choices with left/right
  and exit normally to save. Clear that launcher's NVRAM to reload the
  supplied MRA EEPROM defaults. MAME and HBMAME retain sequenced QSound music
  and offer the same three SOUND EFFECTS choices in ULTRA CONFIGURATION.

MAME
  The MAME ZIPs run in unmodified MAME using its existing Hyper Street
  Fighter II loader. Keep them in a separate folder from original HSF2 ROMs.
  From your MAME folder, launch USA or Japan:
    mame hsf2 -rompath "FULL_PATH_TO_OUTPUT/mame" -nvram_directory nvram-usf2
    mame hsf2j -rompath "FULL_PATH_TO_OUTPUT/mame" -nvram_directory nvram-usf2
  MAME displays the Hyper Street Fighter II description and checksum warnings.
  Accept the warnings to play Ultra Street Fighter II. A frontend may hide
  sets that fail its ROM audit; use the command above in that case.
  The MAME layout preserves the reconstructed game's program, graphics, key
  and sound data.

HBMAME
  Use an HBMAME build that includes the usf2u (USA) and usf2j (Japan) sets.
  Both HBMAME and MiSTer use these names. They replace the former usf2t8
  and usf2j8 names; use the newly generated MiSTer MRAs too.
  Launch by usf2u/usf2j.
  Emulators use native QSound music; CPK playback is a MiSTer CPS+ feature.

MUSIC ONLY
  python3 music.py --nsp USA_BASE.nsp --keys prod.keys \
    --work music-scratch --out usf2_arrange.cpk
  Use --source "USA_BASE.xci" for a supported card dump. --nsp and --xci are
  aliases for --source; both require the same content and final music checks.
  The normal MiSTer/all build does this automatically. No existing CPK is an
  input shortcut. Tracks, conversion, loop points and trigger mapping must
  reproduce the required arrangement exactly.

VERIFY AFTER MOVING THE OUTPUT
  python3 output/verify_output.py --root output

RECONSTRUCTION FORMAT
  Unchanged bytes come from canonical arcade inputs. Changed/added bytes are
  source-relative XOR deltas, compressed and masked using actual decrypted
  Switch resource bytes with separate payload identities. This includes authored
  and embedded donor art and the frozen converted game resources. The public
  download contains no usable artwork masters. A published input checksum is
  not a decryption key. This is an input dependency, not redistribution control
  over the files someone has already reconstructed.

  This frozen installer does not rerun the development artwork pipeline or
  artistic tools. The CPK is freshly generated from NSP/XCI music. Every result
  is checked against the required game hashes before the output is written.

SOURCE AND LICENSES
  core/SOURCE_AND_LICENSE.txt and cps2_core_release.json identify the approved
  CPS+ binary, corresponding source revision and licenses. The bundled source
  tools carry their original notices. Do not distribute this kit together
  with reconstructed game archives, NSP/XCI files, keys or generated copyrighted audio.

OPTIONAL MAME HIGH SCORES

In the generated mame folder, run:
  python3 hiscore.py --mame FULL_PATH_TO_MAME --set hsf2
Use --set hsf2j for Japan. MAME's standard hiscore plugin must be installed.
The launcher checks the generated USF2 ZIP and stores scores/configuration
under saved-scores/usf2, separately for each loader. --state selects another
storage root. It never reads original HSF2 high-score files. Exit normally.
The standard plugin waits five seconds after reset before loading the table,
so the ROM's initial table setup cannot overwrite the restored scores.
The generated hbmame folder has the same opt-in launcher with its native set
name.

CREDITS
  Akuma's imported artwork is Tyrone's, from Super Street Fighter II Turbo: New Legacy.
