Cyberbots: Fullmetal Madness · English restoration
==================================================

Version:  rc1 (2026-11-23)
Target:   MAME set 'cybotsj' (Cyberbots: Fullmetal Madness (Japan 950420))
Hardware: Capcom CPS-2
Patch by: Steve Gordon (https://x.com/strygo)
Website:  https://arcadepatches.com/cybots-restoration/

ABOUT THIS PROJECT

Cyberbots’ English release rewrote much of its story and left parts of it out.
This restoration plays the Japanese arcade game in English that follows the
Japanese script: every campaign and ending, the chapter titles shown before
each stage, and the full set of victory quotes.

Devilotte’s servants keep their Japanese names. Story text is paced and spaced
for English, and the VA logos and name plates appear in English. The Japanese
release’s gameplay, victory voices and stage signs stay intact.

It runs on Darksoft CPS-2 hardware, on MiSTer, and in MAME. HBMAME and FBNeo
outputs use the same game data.

This is a release candidate.

WHAT'S CHANGED

  - Every story scene in all six campaigns and endings, in English that
    follows the Japanese script.
  - Chapter titles before each stage, which the English release never showed.
  - Every victory quote in English, including the distinct lines the English
    release merged into one per grade.
  - Devilotte’s servants keep their names, Jigoku Daishi and Dr. Stein.
  - Story text paced for reading, with page breaks, roomier line spacing and
    proper quotes and apostrophes.
  - English VA logos and name plates, English service menus and USA attract
    and copyright screens.
  - Japanese arcade gameplay, victory voices and stage signs.

BUILD THE GAME

Run python3 apply.py in a terminal for guided setup.
On Windows use py -3.13 apply.py.
Choose your media folder, platform, region and output folder.
Run python3 apply.py --help for command-line options.

HOW TO APPLY (recommended)

    python3 apply.py /path/to/cybotsj.zip --out-dir out

This checks every file against the original, applies the patches, checks
the result, and writes everything you need for each platform:

  MAME:                     out/mame/cybotsj.zip
  HBMAME:                   out/hbmame/cybotsru.zip
  FBNeo:                    out/fbneo/cybotsru.zip
  MiSTer:                   out/mister/_Arcade/_Arcade Patches/_Restorations/Cyberbots Fullmetal Madness (USA) [Restoration].mra

FBNeo: use --platform fbneo --out-dir out for complete game ZIPs.
Keep their ZIP and member names. Use an FBNeo version with definitions
matching this game release; older versions may reject its checksums.


DARKSOFT

Use --platform darksoft --out-dir out to build only Darksoft files.
The default all-platform build includes them too. Copy the selected
folder from out/darksoft/games to your card games folder.
Expanded hardware and streamed audio are not supported.

Merged, split and complete sets work, including nested or renamed ROMs.
Use --rompath DIR (repeatable) to search a collection instead of naming the
zip, and --check to check inputs before building. ZIPs and extracted folders
need no extra software; 7z archives need 7-Zip.
QSound can stay in your emulator's ROM path; valid firmware already
in a source set is kept in complete outputs.

MAME: put cybotsj.zip from out/mame/ ahead of the stock set in your MAME
rompath.
MAME's game menu won't start a set with patched ROMs, so start it from the
command line: mame cybotsj. MAME shows checksum warnings for the patched
ROMs; that's expected and the game runs normally.
To start it from a menu, use the HBMAME build.

HBMAME: use a build containing the cybotsru set definitions.
Upstream HBMAME support is pending.
Put cybotsru.zip and qsound.zip in HBMAME's roms/ folder;
it holds the complete set.

MiSTer: copy the _Arcade folder from out/mister/ to the root of your SD card
and keep the stock, unmodified romset at games/mame/cybotsj.zip (split MAME
sets also need qsound.zip). The MRA applies the restoration in memory as the
game loads, so nothing on the card is modified. You need Jotego's jtcps2
core, which update_all installs. The MRAs are also a separate download.

HOW TO APPLY (any IPS patcher)

Extract cybotsj.zip, apply each file in ips/ to the ROM file of the
same name (Flips, Lunar IPS, or any IPS tool), then re-zip everything
as cybotsj.zip.

CHANGED FILES

    cyb.10  (512 KB)  CRC32 75f4003b -> 463c24d7
    cyb.13m  (4.0 MB)  CRC32 f0dce192 -> c0e53c31
    cyb.14m  (4.0 MB)  CRC32 c1537957 -> d34cf2ae
    cyb.15m  (4.0 MB)  CRC32 187aa39c -> 28437e3f
    cyb.16m  (4.0 MB)  CRC32 15349e86 -> edb473b0
    cyb.17m  (4.0 MB)  CRC32 8a0e4b12 -> b1c5db8c
    cyb.18m  (4.0 MB)  CRC32 d83e977d -> f8680b78
    cyb.19m  (4.0 MB)  CRC32 34b62612 -> afcac21f
    cyb.20m  (4.0 MB)  CRC32 77cdad5c -> 548f798f
    cybj.03  (512 KB)  CRC32 6096eada -> f3e24a5f
    cybj.04  (512 KB)  CRC32 7b0ffaa9 -> 58ffcf73

All other files in the set are unmodified.

LEGAL

This is a free, unofficial fan patch. It is not affiliated with or endorsed
by Capcom. All game titles, characters, and artwork remain the property of
their respective owners. You must own the game to use this patch. Do not
sell this patch or distribute it applied to a ROM image.
