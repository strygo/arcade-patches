Vampire Savior 2 · English translation
======================================

Version:  rc2 (2026-09-17)
Target:   MAME set 'vsav2' (Vampire Savior 2: The Lord of Vampire (Japan 970913))
Hardware: Capcom CPS-2
Patch by: Steve Gordon (https://x.com/strygo)
Website:  https://strygo.github.io/arcade-patches/

ABOUT THIS PROJECT

Vampire Savior 2 is a Japan-only update of Vampire Savior with a shuffled
roster. Donovan, Huitzil, and Pyron join the fight, while Gallon, Aulbath, and
Sasquatch sit this one out, and it carries its own set of endings. It never
came out in English. This patch translates the entire game.

Where Capcom's own English exists, in the Western Vampire Savior and the
PlayStation Darkstalkers 3, the patch uses it, as long as it says what the
Japanese says, so it reads like the official localization. The lines unique to
this version get a fresh translation, written to read naturally while staying
true to the original: the quotes for Huitzil, Pyron, and Donovan, plus every
ending and the final confrontation with Jedah.

The title screen keeps the Vampire Savior 2 name, which is how the game
appeared in arcades. 'Darkstalkers 3' was a later name used only for the home
versions.

WHAT'S CHANGED

  - USA region presentation
  - Western character names on character select, route map, and fight HUD:
    Bulleta → Baby Bonnie Hood, Zabel → L.Raptor, Lei-Lei → Hsien-Ko, Phobos →
    Huitzil
  - All 241 post-fight quotes in English, using Capcom's own wording where it
    matches the Japanese
  - Both endings and both four-page Jedah final-boss dialogs translated
  - Route stage names and option labels match the official U.S. arcade wording
  - Capcom's misspelled "L.Rapter" name art corrected to L.Raptor
  - Oboro Bishamon's win plays his own victory music, as intended

HOW TO APPLY (recommended)

    python3 apply.py /path/to/vsav2.zip --out-dir out

This checks every file against the original, applies the patches, checks
the result, and writes everything you need for each platform:

  MAME / original hardware: out/mame/vsav2.zip
  HBMAME:                   out/hbmame/vsav2s04.zip
  MiSTer:                   out/mister/_Arcade/_Arcade Patches/_Translations/Vampire Savior 2 (USA) [English Translation].mra

MAME: put vsav2.zip from out/mame/ ahead of the stock set in your MAME
rompath.
MAME reports checksum warnings for the patched ROMs; that's expected and
the game runs normally. The same files can be burned for an original board.

HBMAME: this translation is an official HBMAME set (vsav2s04),
so full HBMAME collections may already carry it.
Put the zip in HBMAME's roms/ folder next to your stock vsav2.zip.
It loads with no checksum warnings.

MiSTer: copy the _Arcade folder from out/mister/ to the root of your SD card
and keep the stock, unmodified romset at games/mame/vsav2.zip (split MAME
sets also need qsound.zip). The MRA applies the translation in memory as the
game loads, so nothing on the card is modified. You need Jotego's jtcps2
core, which update_all installs. The MRAs are also a separate download.

HOW TO APPLY (any IPS patcher)

Extract vsav2.zip, apply each file in ips/ to the ROM file of the
same name (Flips, Lunar IPS, or any IPS tool), then re-zip everything
as vsav2.zip.

CHANGED FILES

    vs2.13m  (4.0 MB)  CRC32 5c852f52 -> 5dd1100c
    vs2.15m  (4.0 MB)  CRC32 a20f58af -> 462e62a8
    vs2.17m  (4.0 MB)  CRC32 39db59ad -> 4614aea0
    vs2.19m  (4.0 MB)  CRC32 00c763a7 -> 49af9cfa
    vs2j.03  (512 KB)  CRC32 89fd86b4 -> 5c7b4f47
    vs2j.04  (512 KB)  CRC32 107c091b -> a1192efc
    vs2j.08  (512 KB)  CRC32 2018c120 -> cb8b85c6

All other files in the set are unmodified.

LEGAL

This is a free, unofficial fan patch. It is not affiliated with or endorsed
by Capcom. All game titles, characters, and artwork remain the property of
their respective owners. You must own the game to use this patch. Do not
sell this patch or distribute it applied to a ROM image.
