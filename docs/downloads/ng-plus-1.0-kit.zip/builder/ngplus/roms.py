"""Read a Neo Geo cartridge game from whatever the user has, verified.

Accepted layouts (detected, not declared):
  MAME-named zip      <set>.zip with MAME ROM names
  Darksoft folder     prom [prom1] [p2rom] srom m1rom vroma0 [vromb0] crom0
  Darksoft zip        the same names inside a zip
  .neo container      NEO header + P S M V1 V2 C regions (C byte-swapped)
plus a BIOS source: neogeo.zip (MAME) or a folder / zip holding
sp-u2.sp1 (or another MVS BIOS), uni-bios*.rom, sfix.sfix, 000-lo.lo.

Every game region is split into the set's ROMs (romset) and CRC-checked,
so the result is the same regardless of the input layout: `GameRoms` holds
the raw regions exactly as the MiSTer Neo Geo loader reads them from a
Darksoft set (P in file order, S, M1, V1, V2, crom0 = c1/c2 word
interleave).  The core-ready conversions happen in `convert` and `card`.
"""
from __future__ import annotations

import io
import struct
import zipfile
import zlib
from dataclasses import dataclass, field
from pathlib import Path

from . import convert
from .romset import SetInfo, Rom

DARKSOFT_NAMES = ("prom", "prom1", "p2rom", "p1rom", "srom", "m1rom", "vroma0", "vromb0", "crom0")


@dataclass
class GameRoms:
    setname: str
    ngh: int
    p: bytes
    s: bytes
    m1: bytes
    v1: bytes
    v2: bytes | None
    crom0: bytes                # c1/c2 word-interleaved (Darksoft form)
    source: str
    checks: list[str] = field(default_factory=list)


@dataclass
class BiosRoms:
    sprom_orig: bytes | None    # the "Original" BIOS: sp-u2.sp1 when present (128 KiB)
    sprom_uni: bytes | None     # uni-bios*.rom (128 KiB)
    sfix: bytes                 # 128 KiB, raw
    lo: bytes                   # 64 KiB (000-lo.lo)
    source: str
    checks: list[str] = field(default_factory=list)


class Source:
    """Uniform byte access to a folder, a zip, or a single file."""

    def __init__(self, path: Path):
        self.path = Path(path)
        self.zip = zipfile.ZipFile(self.path) if self.path.is_file() and self.path.suffix.lower() == ".zip" else None

    def names(self) -> list[str]:
        if self.zip:
            return [n.split("/")[-1] for n in self.zip.namelist() if not n.endswith("/")]
        if self.path.is_dir():
            return [p.name for p in self.path.iterdir() if p.is_file()]
        return [self.path.name]

    def read(self, name: str) -> bytes:
        if self.zip:
            for n in self.zip.namelist():
                if n.split("/")[-1].lower() == name.lower():
                    return self.zip.read(n)
            raise FileNotFoundError(f"{name} not in {self.path}")
        if self.path.is_dir():
            for p in self.path.iterdir():
                if p.name.lower() == name.lower():
                    return p.read_bytes()
            raise FileNotFoundError(f"{name} not in {self.path}")
        return self.path.read_bytes()

    def has(self, name: str) -> bool:
        return any(n.lower() == name.lower() for n in self.names())


def crc(b: bytes) -> str:
    return f"{zlib.crc32(b) & 0xFFFFFFFF:08x}"


def region_size(roms: list[Rom]) -> int:
    """The address space a set's ROMs occupy: past the last one, holes and all."""
    return max(r.offset + r.size for r in roms)


def c_region_size(info: SetInfo) -> int:
    """The sprite space the board addresses: each pair holds two bytes of
    every word, so it occupies twice one ROM's length from its own address."""
    return max((e.offset & ~1) + 2 * e.size for e, _ in info.c_pairs())


def place(roms: list[Rom], files: list[bytes]) -> bytes:
    """Lay a set's ROMs out at their own addresses.

    Not every board populates every socket.  KOF \'95 leaves 4 MB of sprite
    space and 2 MB of ADPCM space empty and addresses the chips that follow
    past the hole, so a region packed end to end puts them at the wrong
    addresses -- wrong tiles everywhere, wrong samples.
    """
    out = bytearray(region_size(roms))
    for r, data in zip(roms, files):
        if len(data) != r.size:
            raise ValueError(f"{r.name}: {len(data)} bytes, expected {r.size}")
        out[r.offset:r.offset + r.size] = data
    return bytes(out)


def _check_placed(region: bytes, placed: list[tuple[int, Rom]], size: int,
                  label: str, checks: list[str]) -> None:
    """Check every ROM against its CRC where the board puts it, and that the
    space between them is empty.

    Reading the region back at the addresses the set declares is what makes
    this able to fail: walking it end to end would pass a region assembled
    with the holes left out, which is how KOF \'95 shipped corrupt.
    """
    if len(region) != size:
        raise ValueError(f"{label}: region is {len(region)} bytes, the set spans {size}")
    for at, r in placed:
        got = crc(region[at:at + r.size])
        if got != r.crc.lower():
            raise ValueError(f"{label}: {r.name} CRC {got} at 0x{at:x}, expected {r.crc}")
        checks.append(f"{label} {r.name} crc ok")
    pos = 0
    for at, r in sorted(placed):
        if pos < at and region[pos:at].strip(b"\0"):
            raise ValueError(f"{label}: data in unpopulated space 0x{pos:x}-0x{at:x}")
        pos = max(pos, at + r.size)


def _check_split(region: bytes, roms: list[Rom], label: str, checks: list[str]) -> None:
    _check_placed(region, [(r.offset, r) for r in roms], region_size(roms), label, checks)


def p_region_size(info: SetInfo) -> int:
    # Neo Geo P regions have no gaps: every byte is covered exactly once, so
    # the region size is the sum of the ROMs.
    return sum(r.size for r in info.p)


def be_view(b: bytes) -> bytes:
    """P data is stored as little-endian 16-bit words (the order the 16-bit
    ioctl stream and the core want); the 68K's byte order is the pair swap."""
    out = bytearray(len(b))
    out[0::2] = b[1::2]
    out[1::2] = b[0::2]
    return bytes(out)


def mame_p_to_logical(info: SetInfo, files: list[bytes]) -> bytes:
    """Each P ROM sits at its offset and wraps at the region end
    (ROM_CONTINUE for the 2 MB chips loaded at 0x100000: the file's second
    half is the cartridge's first megabyte).  Byte i of a ROM lands at
    (offset + i) mod region size; the result is the cartridge's logical
    P image, which is what Darksoft `prom`, `.neo` and the core use."""
    size = p_region_size(info)
    out = bytearray(size)
    for r, data in zip(info.p, files):
        if len(data) != r.size:
            raise ValueError(f"{r.name}: {len(data)} bytes, expected {r.size}")
        if r.offset + r.size <= size:
            out[r.offset:r.offset + r.size] = data
        else:
            first = size - r.offset
            out[r.offset:size] = data[:first]
            out[0:r.size - first] = data[first:]
    return bytes(out)


def logical_to_mame_p(info: SetInfo, logical: bytes) -> list[bytes]:
    size = p_region_size(info)
    files = []
    for r in info.p:
        if r.offset + r.size <= size:
            files.append(logical[r.offset:r.offset + r.size])
        else:
            first = size - r.offset
            files.append(logical[r.offset:size] + logical[0:r.size - first])
    return files


def _verify(g: GameRoms, info: SetInfo) -> None:
    tag = be_view(g.p[0x100:0x108])
    if tag[:7] != b"NEO-GEO":
        raise ValueError(f"P ROM has no NEO-GEO header tag at 0x100 (got {tag!r}): not a logical P image")
    if len(g.p) != p_region_size(info):
        raise ValueError(f"P size {len(g.p)}, expected {p_region_size(info)}")
    for r, data in zip(info.p, logical_to_mame_p(info, g.p)):
        got = crc(data)
        if got != r.crc.lower():
            raise ValueError(f"P: {r.name} CRC {got}, expected {r.crc}")
        g.checks.append(f"P {r.name} crc ok")
    _check_split(g.s, info.s, "S", g.checks)
    _check_split(g.m1, info.m1, "M1", g.checks)
    _check_split(g.v1, info.v1, "V1", g.checks)
    if info.v2:
        if g.v2 is None:
            raise ValueError("the set has ADPCM-B ROMs but the input has no V2")
        _check_split(g.v2, info.v2, "V2", g.checks)
    elif g.v2:
        raise ValueError("the input has a V2 region but the set has no ADPCM-B ROMs")
    # C: de-interleave crom0 back into the pairs
    want = c_region_size(info)
    if len(g.crom0) != want:
        raise ValueError(f"C: crom0 is {len(g.crom0)} bytes, the set spans {want}"
                         + (" (a crom0 packed without the board's unpopulated space?)"
                            if len(g.crom0) < want else ""))
    half = len(g.crom0) // 2
    a = bytearray(half); b = bytearray(half)
    a[0::2] = g.crom0[0::4]; a[1::2] = g.crom0[1::4]
    b[0::2] = g.crom0[2::4]; b[1::2] = g.crom0[3::4]
    pairs = info.c_pairs()
    # crom0 interleaves the pair word by word, so a ROM at cartridge address
    # B holds its own bytes from B/2 of either half
    evens = [((e.offset & ~1) // 2, e) for e, _ in pairs]
    odds = [((e.offset & ~1) // 2, o) for e, o in pairs]
    _check_placed(bytes(a), evens, half, "C even", g.checks)
    _check_placed(bytes(b), odds, half, "C odd", g.checks)


def _ngh(p: bytes) -> int:
    # cartridge header: NGH number at 0x108 (68K word; the file holds LE words)
    return struct.unpack_from("<H", p, 0x108)[0]


def read_mame(src: Source, info: SetInfo) -> GameRoms:
    def region(roms: list[Rom]) -> bytes:
        return place(roms, [src.read(r.name) for r in roms])
    p = mame_p_to_logical(info, [src.read(r.name) for r in info.p])
    crom0 = convert.consolidate_c([(src.read(a.name), src.read(b.name)) for a, b in info.c_pairs()],
                                  [a.offset & ~1 for a, _ in info.c_pairs()])
    g = GameRoms(info.name, _ngh(p), p, region(info.s), region(info.m1), region(info.v1),
                 region(info.v2) if info.v2 else None, crom0, f"mame:{src.path}")
    _verify(g, info)
    return g


def read_darksoft(src: Source, info: SetInfo) -> GameRoms:
    p = src.read("prom") if src.has("prom") else src.read("p1rom")
    if src.has("prom1"):
        p += src.read("prom1")
    if src.has("p2rom"):
        p += src.read("p2rom")
    v1 = src.read("vroma0")
    v2 = src.read("vromb0") if src.has("vromb0") else None
    g = GameRoms(info.name, _ngh(p), p, src.read("srom"), src.read("m1rom"), v1, v2,
                 src.read("crom0"), f"darksoft:{src.path}")
    _verify(g, info)
    return g


NEO_HDR = struct.Struct("<4sIIIIIIIIII33s17s")   # header1..3+version, sizes, year, genre, screenshot, NGH, name, manu


def read_neo(src: Source, info: SetInfo) -> GameRoms:
    blob = src.read(src.path.name) if not src.zip else src.read(next(n for n in src.names() if n.lower().endswith(".neo")))
    magic = blob[0:3]
    if magic != b"NEO":
        raise ValueError(f"{src.path}: not a .neo container ({magic!r})")
    psz, ssz, msz, v1sz, v2sz, csz = struct.unpack_from("<6I", blob, 4)
    ngh = struct.unpack_from("<I", blob, 4 + 6 * 4 + 12)[0]
    off = 4096
    p = blob[off:off + psz]; off += psz
    s = blob[off:off + ssz]; off += ssz
    m1 = blob[off:off + msz]; off += msz
    v1 = blob[off:off + v1sz]; off += v1sz
    v2 = blob[off:off + v2sz] if v2sz else None; off += v2sz
    cneo = blob[off:off + csz]
    g = GameRoms(info.name, _ngh(p), p, s, m1, v1, v2, convert.spr_bswap(cneo), f"neo:{src.path}")
    if ngh and ngh != g.ngh:
        g.checks.append(f"warning: .neo header NGH 0x{ngh:x} != P ROM NGH 0x{g.ngh:x}")
    _verify(g, info)
    return g


def read_game(path: Path, info: SetInfo) -> GameRoms:
    src = Source(path)
    names = [n.lower() for n in src.names()]
    if any(n.endswith(".neo") for n in names):
        return read_neo(src, info)
    if "crom0" in names and ("prom" in names or "p1rom" in names):
        return read_darksoft(src, info)
    if all(r.name.lower() in names for r in info.p + info.s + info.m1 + info.v1 + info.c):
        return read_mame(src, info)
    raise ValueError(f"{path}: not a MAME-named set, a Darksoft set or a .neo (found {sorted(names)[:8]}...)")


UNI_PREFERENCE = ("uni-bios_4_0.rom", "uni-bios_3_3.rom", "uni-bios_3_2.rom", "uni-bios_3_1.rom",
                  "uni-bios_3_0.rom", "uni-bios.rom")
# The "Original" BIOS the image carries.  NG+ starts in arcade mode with it, so
# it decides the region a game runs in: the US MVS BIOS first, then the other
# MVS BIOSes a set may hold (Europe, Japan), the AES one last -- an AES BIOS in
# arcade mode is the wrong machine, and is only used when nothing else is there.
ORIG_PREFERENCE = ("sp-u2.sp1", "sp-e.sp1", "sp-s2.sp1", "sp-s.sp1", "vs-bios.rom", "sp-j2.sp1",
                   "neo-epo.sp1")
ORIG_REGION = {"sp-u2.sp1": "USA", "sp-e.sp1": "USA", "sp-s2.sp1": "Europe", "sp-s.sp1": "Europe",
               "vs-bios.rom": "Japan", "sp-j2.sp1": "Japan", "neo-epo.sp1": "Europe (AES)"}


def read_bios(path: Path, info: SetInfo, prefer_orig: str | None = None) -> BiosRoms:
    src = Source(path)
    names = {n.lower(): n for n in src.names()}
    checks: list[str] = []

    def pick(prefs):
        for p in prefs:
            if p.lower() in names:
                return names[p.lower()]
        return None

    orig_name = prefer_orig or pick(ORIG_PREFERENCE)
    uni_name = pick(UNI_PREFERENCE)
    if not orig_name and not uni_name:
        raise ValueError(f"{path}: no system ROM (sp-u2.sp1 or another MVS BIOS, or uni-bios*.rom)")

    def rom(name: str | None, size: int) -> bytes | None:
        if not name:
            return None
        b = src.read(name)
        if len(b) < size:
            raise ValueError(f"{name}: {len(b)} bytes, need {size}")
        b = b[:size]
        known = info.bios.get(name)
        if known and known.crc.lower() != crc(b):
            raise ValueError(f"{name}: CRC {crc(b)}, expected {known.crc}")
        checks.append(f"bios {name} {'crc ok' if known else 'unverified (not a known BIOS file name)'}")
        return b

    sfix = rom("sfix.sfix", 0x20000)
    lo = rom("000-lo.lo", 0x10000)
    if sfix is None or lo is None:
        raise ValueError(f"{path}: needs sfix.sfix and 000-lo.lo")
    if info.sfix and info.sfix.crc.lower() != crc(sfix):
        raise ValueError(f"sfix.sfix CRC {crc(sfix)}, expected {info.sfix.crc}")
    if orig_name and ORIG_REGION.get(orig_name.lower()) != "USA":
        checks.append(f"note: no US BIOS (sp-u2.sp1) in {path.name}; \"Original\" is {orig_name} "
                      f"({ORIG_REGION.get(orig_name.lower(), 'unknown region')})")
    return BiosRoms(rom(orig_name, 0x20000), rom(uni_name, 0x20000), sfix, lo, f"bios:{path}", checks)
