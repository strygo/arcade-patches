"""ROM set definitions: what a title's ROM data must be.

Each title ships `titles/<set>/romset.json`, the MAME set definition reduced
to what the builder checks: every ROM's name, size, CRC32 and load offset,
grouped by board region.  Every input layout (MAME zip, Darksoft folder or
zip, .neo) is split back into these ROMs and CRC-checked, so an image is never
built from bytes that could not be verified.

Regions:
  p    68000 program, ROMs in offset order
  s    fix layer
  m1   Z80 sound program
  v1   ADPCM-A sample ROMs in offset order
  v2   ADPCM-B sample ROMs in offset order (empty: shared ADPCM space)
  c    sprite ROMs, (even, odd) pairs by offset parity
BIOS: `bios` (system ROMs by name), `sfix` (fix layer), `lo` (zoom table).
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field, asdict
from pathlib import Path


@dataclass
class Rom:
    name: str
    size: int
    crc: str
    offset: int


@dataclass
class SetInfo:
    name: str
    description: str
    cloneof: str | None
    romof: str | None
    p: list[Rom] = field(default_factory=list)
    s: list[Rom] = field(default_factory=list)
    m1: list[Rom] = field(default_factory=list)
    v1: list[Rom] = field(default_factory=list)
    v2: list[Rom] = field(default_factory=list)
    c: list[Rom] = field(default_factory=list)
    bios: dict = field(default_factory=dict)
    sfix: Rom | None = None
    lo: Rom | None = None

    def c_pairs(self) -> list[tuple[Rom, Rom]]:
        even = sorted((r for r in self.c if r.offset % 2 == 0), key=lambda r: r.offset)
        odd = sorted((r for r in self.c if r.offset % 2 == 1), key=lambda r: r.offset)
        if len(even) != len(odd):
            raise ValueError(f"{self.name}: unpaired sprite ROMs")
        return list(zip(even, odd))

    def to_json(self) -> str:
        return json.dumps(asdict(self), indent=1)

    @classmethod
    def from_json(cls, text: str) -> "SetInfo":
        d = json.loads(text)
        for k in ("p", "s", "m1", "v1", "v2", "c"):
            d[k] = [Rom(**r) for r in d[k]]
        d["bios"] = {k: Rom(**v) for k, v in d["bios"].items()}
        d["sfix"] = Rom(**d["sfix"]) if d["sfix"] else None
        d["lo"] = Rom(**d["lo"]) if d["lo"] else None
        return cls(**d)


def load(title_dir: Path) -> SetInfo:
    return SetInfo.from_json((Path(title_dir) / "romset.json").read_text(encoding="utf-8"))
