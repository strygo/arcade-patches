"""Voices the arranged tracks already carry: per-title ADPCM sample mutes.

Some Neo Geo CD discs record a voice into the Red Book track itself
(Samurai Shodown II: the narrator's line at "TIME HAS PASSED..." is part of
the track that cue plays), and the CD version leaves the cartridge's ADPCM
copy of that voice out of the scene's sample bank so it is heard once.  NG+
runs the cartridge program with the cartridge's sample ROMs, so without a
mute the voice would play from ADPCM and again from the arranged track.

The SNK sound driver decides per (start command, sample) whether a sample
may play: each ADPCM start class ($18 ADPCM-B, $1A/$1C/$1E ADPCM-A) has a
256-bit enable bitmap it tests before allocating a channel
(`ld hl,TABLE / call BITTEST / ret z`).  Clearing a sample's bit makes the
driver ignore that start command, exactly as the CD version's missing data
does, without touching the sample data or the channel logic.

A title lists its mutes in title.json:
    "sound_mutes": [{"cmd": "0x1e", "sample": "0x44", "note": "..."}]
"""
from __future__ import annotations

import re

# class 1..3 start handlers: call POP / cp $10 / jp c,ERR / ld hl,TABLE /
# call BITTEST / ret z / ld a,$18 / ld ($FE3E),a / ld a,CLASS / ld ($FEB2),a
_PROLOGUE_A = re.compile(rb"\xcd..\xfe\x10\xda..\x21(..)\xcd..\xc8\x3e\x18\x32\x3e\xfe\x3e(.)\x32\xb2\xfe", re.S)
# class 0 ($18): the same without the class store
_PROLOGUE_B = re.compile(rb"\xcd..\xfe\x10\xda..\x21(..)\xcd..\xc8\x3e\x18\x32\x3e\xfe\x3a\x3d\xfe\xf3", re.S)
# later build (KOF '95): each start handler is `ld c,CLASS / call CHECK /
# ret z`, and CHECK pops the sample, then indexes a table of bitmap addresses
# by class: push bc / call POP / pop bc / cp $10 / jp nc,.. / pop bc / jp .. /
# ld b,0 / ld hl,PTRS / add hl,bc x2 / ld b,(hl) / inc hl / ld h,(hl) / ld l,b
_START_C = re.compile(rb"\x0e([\x00-\x03])\xcd(..)\xc8", re.S)
_CHECK_C = re.compile(rb"\xc5\xcd..\xc1\xfe\x10\xd2..\xc1\xc3..\x06\x00\x21(..)\x09\x09\x46\x23\x66\x68", re.S)
CMD_CLASS = {0x18: 0, 0x1A: 1, 0x1C: 2, 0x1E: 3}


def class_tables(m1: bytes) -> dict[int, int]:
    """{start class: enable-bitmap address}, found from the handler prologues."""
    tables: dict[int, int] = {}
    for m in _PROLOGUE_A.finditer(m1):
        tables[m.group(2)[0]] = int.from_bytes(m.group(1), "little")
    for m in _PROLOGUE_B.finditer(m1):
        tables.setdefault(0, int.from_bytes(m.group(1), "little"))
    if tables:
        return tables
    for m in _START_C.finditer(m1):
        check = _CHECK_C.match(m1, int.from_bytes(m.group(2), "little"))
        if check:
            ptrs, cls = int.from_bytes(check.group(1), "little"), m.group(1)[0]
            tables.setdefault(cls, int.from_bytes(m1[ptrs + 2 * cls:ptrs + 2 * cls + 2], "little"))
    return tables


def sample_enabled(m1: bytes, table: int, sample: int) -> bool:
    return bool(m1[table + (sample >> 3)] & (0x80 >> (sample & 7)))


def apply(m1: bytes, mutes: list[dict]) -> tuple[bytes, list[str]]:
    """Return the sound ROM with the listed samples disabled, and notes."""
    if not mutes:
        return m1, []
    tables = class_tables(m1)
    out = bytearray(m1)
    notes = []
    for mu in mutes:
        cmd, sample = int(mu["cmd"], 16), int(mu["sample"], 16)
        cls = CMD_CLASS[cmd]
        if cls not in tables:
            raise ValueError(f"no enable table for ADPCM start ${cmd:02X} in the sound ROM")
        table = tables[cls]
        if not sample_enabled(bytes(out), table, sample):
            raise ValueError(f"sample ${sample:02X} of ${cmd:02X} is already disabled")
        out[table + (sample >> 3)] &= ~(0x80 >> (sample & 7)) & 0xFF
        notes.append(f"sample mute ${cmd:02X} ${sample:02X} (enable bit at 0x{table + (sample >> 3):04X})")
    return bytes(out), notes
