NG+ — arranged Neo Geo CD soundtracks for Neo Geo cartridge games on MiSTer
==========================================================================

Version:     1.0
Hardware:    MiSTer FPGA — the NG+ core (included), a build of the Neo Geo core
Project by:  Steve Gordon (https://x.com/strygo)

NG+ plays the arranged soundtracks SNK recorded for its Neo Geo CD releases
under the original cartridge games (MVS/AES), with no load times and nothing
cut.  The game's own program stays in charge: the core watches the sound
commands the game sends and streams the matching CD track, while the sound
board keeps playing every sound effect and voice.  No game code is changed.

  core source:   https://github.com/strygo/NeoGeo_MiSTer/tree/ngplus

WHAT'S IN THIS KIT — AND WHAT ISN'T
-----------------------------------
This kit contains no copyrighted material: no ROMs, no audio.

  builder/          the image builder (Python), each title's published data
                    and checksums, and the NG+ core
  out/mister/       built by the builder, laid out like your SD card.  This is
                    the only folder you copy across.

You supply, per title:
  * the cartridge ROM set: a MAME-named zip, a Darksoft set or a .neo file
  * the Neo Geo CD disc rip: its .cue sheet and images, a .zip holding them,
    or a .chd (a CHD also needs chdman, which comes with MAME)
and once: the Neo Geo BIOS set (neogeo.zip).

Titles in this version:
  aof2       Art of Fighting 2  (disc: Ryuuko no Ken 2 ~ Art of Fighting 2 (World) (En,Ja,Es))
  fatfursp   Fatal Fury Special  (disc: Garou Densetsu Special ~ Fatal Fury Special (World) (En,Ja) (Rev 1))
  kof94      The King of Fighters '94  (disc: King of Fighters '94, The (World) (En,Ja) (Rev 1))
  kof95      The King of Fighters '95  (disc: King of Fighters '95, The (World) (En,Ja))
  samsho2    Samurai Shodown II  (disc: Shin Samurai Spirits - Haoumaru Jigokuhen ~ Samurai Shodown II (World) (En,Ja))

QUICK START
-----------
  1. Edit builder/titles.toml and point it at your BIOS set, ROM sets and
     disc rips.  Or pass them on the command line:
       python3 builder/make_ngplus.py --bios neogeo.zip --rom samsho2=samsho2.zip --disc samsho2=ssii.cue
     Run make_ngplus.py --list to see every title and the disc it wants.
  2. python3 builder/make_ngplus.py
       (needs Python 3.11+ and ffmpeg on PATH; on Windows that is python.org's
        installer and a release ffmpeg build, run as py builder\make_ngplus.py)
     Every ROM, every disc track and every finished pack is checked against
     its published checksum, so your build is exactly the tested build.
  3. Copy the contents of out/mister/ onto your MiSTer SD card (/media/fat/),
     merging with what's already there.  See INSTALL.md.

Each title then appears in the MiSTer menu under
Arcade > Arcade Patches > Arrangements > NG+, and starts as the US arcade
release (arcade mode, US MVS BIOS).  The core's menu has an Arranged Volume
for the CD music and the usual System Type and BIOS choices (console mode,
UniBIOS).
