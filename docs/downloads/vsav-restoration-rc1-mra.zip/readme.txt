Vampire Savior · English restoration · The Japanese board, in English
=====================================================================

Version:  rc1 (2026-09-22)
Target:   MAME set 'vsavj' (Vampire Savior: The Lord of Vampire (Japan 970519))
Hardware: Capcom CPS-2
Patch by: Steve Gordon (https://x.com/strygo)
Website:  https://strygo.github.io/arcade-patches/

ABOUT THIS PROJECT

Vampire Savior wasn't the same game everywhere. The export boards recolored
Jedah's blood purple and Forever Torment's green, cut a few gory touches
entirely, and defaulted to sweat instead of blood. Their English script
dropped fourteen win quotes and 47 ending pages. Even the damage values
differ: in places the export boards hit a little harder.

The English Restoration is the Japanese board, in English. The blood is red
again, everywhere it was in Japan. All 241 win quotes and every ending page
are here, translated from the Japanese: where Capcom's English said the same
thing it's kept, and everything else is newly translated, including the pages
the export dropped. The fights run on Japan's damage values and Japan's
computer difficulty.

Out of the box it's set up like a Japanese cabinet: blood on, Auto guard
selectable at the select screen, one coin one credit. The operator menu and
the Western character names stay as the US board has them, and Lord Raptor's
name finally reads L.Raptor instead of L.Rapter.

It's a USA build that runs in MAME, HBMAME and on MiSTer. The Japanese board
already has everything above, so there's no Japan build for now.

This is a release candidate.

WHAT'S CHANGED

  - All 241 win quotes from the Japanese game, in English, including the
    fourteen the US board dropped
  - Every ending page from the Japanese game, in English, including the 47 the
    US board dropped, with Japan's page timing
  - The dialogue before the final battle with Jedah, checked line by line
    against the Japanese and revised where Capcom's English strayed
  - Red blood: Jedah's attacks (purple on the US board), Forever Torment's
    guillotine and well (green), and hit blood on by default
  - Lord Raptor's blood spray in his bite throw, and the paper notice in
    Bishamon's Togakubi Sarashi finish, both cut from the export boards
  - Japan's damage values and computer difficulty
  - Set up like a Japanese cabinet: blood on, Auto guard selectable, one coin
    one credit
  - Lord Raptor's name spelled right

MISTER SETUP

1. Copy the _Arcade/ folder from this download to the root of your
   MiSTer SD card (the MRA lands in _Arcade/_Arcade Patches/_Restorations/), or copy
   "Vampire Savior The Lord of Vampire (USA) [English Restoration].mra" anywhere under _Arcade/.
2. Have the stock, unmodified romset at games/mame/vsavj.zip
   (split MAME sets also need qsound.zip next to it).
3. You need Jotego's jtcps2 core; the standard MiSTer downloader /
   update_all installs it automatically.

The MRA references your original romset and applies the restoration in
memory while the game loads. Nothing on your SD card is modified. The
restoration keeps its own settings and saves under the name
'vsavru'.

LEGAL

This is a free, unofficial fan patch. It is not affiliated with or endorsed
by Capcom. All game titles, characters, and artwork remain the property of
their respective owners. You must own the game to use this patch. Do not
sell this patch or distribute it applied to a ROM image.
