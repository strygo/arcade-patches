Night Warriors 2 · Vampire Hunter 2, translated to English
==========================================================

Version:  rc1 (2026-07-10)
Target:   MAME set 'vhunt2' (Vampire Hunter 2: Darkstalkers Revenge (Japan 970929))
Hardware: Capcom CPS-2
Patch by: Steve Gordon (https://x.com/strygo)
Website:  https://strygo.github.io/arcade-patches/

ABOUT THIS PROJECT

Vampire Hunter 2 is a 1997 Capcom fighter that only ever reached Japanese
arcades. Its predecessor came to the West as Night Warriors: Darkstalkers'
Revenge, but this sequel never made the trip. The patch translates the whole
game into English and gives it the Western name it should have had, Night
Warriors 2.

That title screen isn't a fan mock-up. An unused Western title was already
sitting inside the original game, and the patch finishes it and switches it
on. Nothing about the gameplay changes.

Where Capcom's own English wording exists in the Western Darkstalkers games,
the patch reuses it, so the writing matches the official localization.
Everything else gets a fresh translation, checked in the actual game: the
victory taunts, the boss exchanges, and every character's ending.

WHAT'S CHANGED

  - Arcade-native Night Warriors 2 title screen, built from the ROM's unused
    Western title path
  - USA region presentation (warning screen and region byte)
  - Western character names on character select, route map labels, and the
    fight HUD: Zabel → L.Raptor, Gallon → J.Talbain, Lei-Lei → Hsien-Ko,
    Phobos → Huitzil, Aulbath → Rikuo
  - English route/stage titles
  - All 225 post-fight quotes in English
  - All boss dialog and every character ending translated
  - English staff roll under the Night Warriors 2 name

MISTER SETUP

1. Copy "Night Warriors 2 (English Translation).mra" anywhere under _Arcade/ on your MiSTer.
2. Have the stock, unmodified romset at games/mame/vhunt2.zip
   (split MAME sets also need qsound.zip next to it).
3. You need Jotego's jtcps2 core; the standard MiSTer downloader /
   update_all installs it automatically.

The MRA references your original romset and applies the translation in
memory while the game loads. Nothing on your SD card is modified. The
translation keeps its own settings and saves under the name
'nwarr2en'.

LEGAL

This is a free, unofficial fan patch. It is not affiliated with or endorsed
by Capcom. All game titles, characters, and artwork remain the property of
their respective owners. You must own the game to use this patch. Do not
sell this patch or distribute it applied to a ROM image.
