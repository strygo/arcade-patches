Vampire Savior 2 · English translation
======================================

Version:  rc1 (2026-07-10)
Target:   MAME set 'vsav2' (Vampire Savior 2: The Lord of Vampire (Japan 970913))
Hardware: Capcom CPS-2
Patch by: Steve Gordon (https://x.com/strygo)
Website:  https://strygo.github.io/arcade-patches/

ABOUT THIS PROJECT

Vampire Savior 2 is a Japan-only update of Vampire Savior with a shuffled
roster. Donovan, Huitzil, and Pyron join the fight, while Gallon, Aulbath, and
Sasquatch sit this one out, and it carries its own set of endings. It never
came out in English. This patch translates the entire game.

Where the dialogue matches the Western release of Vampire Savior, the patch
reuses Capcom's own English so it reads like the official localization. The
lines unique to this version get a fresh translation, written to read
naturally while staying true to the original: the quotes for Huitzil, Pyron,
and Donovan, plus every ending and the final confrontation with Jedah.

The title screen keeps the Vampire Savior 2 name, which is how the game
appeared in arcades. 'Darkstalkers 3' was a later name used only for the home
versions.

WHAT'S CHANGED

  - USA region presentation
  - Western character names on character select, route map, and fight HUD:
    Bulleta → Baby Bonnie Hood, Zabel → L.Raptor, Lei-Lei → Hsien-Ko, Phobos →
    Huitzil
  - All 241 post-fight quotes in English, reusing Capcom's own wording where
    it exists
  - All 29 ending pages and both four-page Jedah final-boss dialogs translated
  - Route stage names and option labels match the official U.S. arcade wording

MISTER SETUP

1. Copy the _Arcade/ folder from this download to the root of your
   MiSTer SD card (the MRA lands in _Arcade/_Translations/), or copy
   "Vampire Savior 2 (English Translation).mra" anywhere under _Arcade/.
2. Have the stock, unmodified romset at games/mame/vsav2.zip
   (split MAME sets also need qsound.zip next to it).
3. You need Jotego's jtcps2 core; the standard MiSTer downloader /
   update_all installs it automatically.

The MRA references your original romset and applies the translation in
memory while the game loads. Nothing on your SD card is modified. The
translation keeps its own settings and saves under the name
'vsav2en'.

LEGAL

This is a free, unofficial fan patch. It is not affiliated with or endorsed
by Capcom. All game titles, characters, and artwork remain the property of
their respective owners. You must own the game to use this patch. Do not
sell this patch or distribute it applied to a ROM image.
