Marvel Super Heroes vs. Street Fighter · English restoration · Everything the Japanese board has
================================================================================================

Version:  rc1 (2026-09-17)
Target:   MAME set 'mshvsfj' (Marvel Super Heroes vs. Street Fighter (Japan 970707))
Hardware: Capcom CPS-2
Patch by: Steve Gordon (https://x.com/strygo)
Website:  https://strygo.github.io/arcade-patches/

ABOUT THIS PROJECT

Marvel Super Heroes vs. Street Fighter wasn't the same game everywhere. The
Japanese board has Norimaro on the select screen with his own ending, real
endings for Mech-Zangief, Shadow and Dark Sakura, and sixteen win quotes per
fighter. The US board dropped Norimaro entirely, gave the secret fighters a
generic ending, and cut the win quotes to eight.

The English Restoration is the Japanese game, in English. Norimaro is back,
with his ending. The secret fighters get their own endings and art. All
sixteen win quotes per fighter and all seventeen standard endings are
translated fresh from the Japanese.

Nothing else changes. The title, the secret-character codes, the team rules
and the bosses are exactly as they were, and the fighting is untouched. If you
want more, like playable bosses, any team you like, extra colors and eight
speeds, that's EX, which includes everything here.

There are two builds. The USA build is the English one. The Japan build keeps
its Japanese text and gets the few fixes that apply to it. Both run in MAME,
HBMAME and on MiSTer.

This is a release candidate. Both builds boot and have been checked in MAME;
longer play testing and a MiSTer hardware pass are still to come.

WHAT'S CHANGED

  - Norimaro is back, on the select screen and as a computer opponent
  - Norimaro's own ending, in English
  - Mech-Zangief, Shadow and Dark Sakura get their own endings and art,
    instead of the generic one
  - Sixteen win quotes per fighter, translated from the Japanese (the US board
    has eight)
  - All seventeen standard endings, translated from the Japanese
  - Pick a secret fighter and the select screen shows their name (Mech-
    Zangief, not Zangief)
  - Japan build: the same fixes, with the Japanese text kept
  - Title, codes, team rules, bosses and gameplay untouched

MISTER SETUP

1. Copy the _Arcade/ folder from this download to the root of your MiSTer SD
   card (the MRAs land in _Arcade/_Arcade Patches/_Restorations/), or just the MRAs you want:
       "Marvel Super Heroes Vs. Street Fighter (USA) [English Restoration].mra"
       "_Japan/Marvel Super Heroes Vs. Street Fighter (Japan) [Restoration].mra"
2. Have the stock, unmodified romset at games/mame/mshvsfj.zip
   (split MAME sets also need qsound.zip next to it).
3. You need Jotego's jtcps2 core; the standard MiSTer downloader /
   update_all installs it automatically.

Each MRA references your original romset and applies the restoration in
memory while the game loads. Nothing on your SD card is modified. Each
build keeps its own settings and saves under its own setname:
    USA (English)    mshvsfru
    Japan (Japanese) mshvsfrj

LEGAL

This is a free, unofficial fan patch. It is not affiliated with or endorsed
by Capcom. All game titles, characters, and artwork remain the property of
their respective owners. You must own the game to use this patch. Do not
sell this patch or distribute it applied to a ROM image.
