Hyper Street Fighter II: The Anniversary Edition · English restoration
======================================================================

Version:  rc1 (2026-11-05)
Target:   MAME set 'hsf2j' (Hyper Street Fighter II: The Anniversary Edition (Japan 040202))
Hardware: Capcom CPS-2
Patch by: Steve Gordon (https://x.com/strygo)
Website:  https://arcadepatches.com/hsf2-restoration/

ABOUT THIS PROJECT

Play the Japanese version of Hyper Street Fighter II in English, with its
original balance and the classic versions of each fighter. Western fighter
names and the official US regional move voices accompany English win quotes,
full endings, illustrated Continue tips and all 28 Start messages.

Stage and portrait artwork repairs, black backgrounds in affected ending and
Ryu intro scenes, and a clearer ending-choice menu complete the restoration.
Japan's factory speed and coin settings are retained, with native Free Play
available in the operator menu.

It runs on MiSTer and in HBMAME or FBNeo builds that include hsf2re. Apply the
patch to your stock Japanese set.

This is a release candidate.

WHAT'S CHANGED

  - Japanese 040202 gameplay and classic fighter versions
  - Western fighter names and official US regional move voices
  - English win quotes, full endings and illustrated Continue tips
  - All 28 Start-message choices in English
  - Stage and portrait artwork repairs, black backgrounds in affected ending
    and Ryu intro scenes, and a clearer ending-choice menu
  - Native operator Free Play with saved settings and no-coin starts

MISTER SETUP

1. Copy the _Arcade/ folder from this download to the root of your
   MiSTer SD card (the MRA lands in _Arcade/_Arcade Patches/_Restorations/), or copy
   "Hyper Street Fighter II The Anniversary Edition (USA) [English Restoration].mra" anywhere under _Arcade/.
2. Have the stock, unmodified romset at games/mame/hsf2j.zip
   (split sets also need the parent and QSound ZIPs named in the MRA).
3. You need Jotego's jtcps2 core; the standard MiSTer downloader /
   update_all installs it automatically.

The MRA references your original romset and applies the restoration in
memory while the game loads. Nothing on your SD card is modified. The
restoration keeps its own settings and saves under the name
'hsf2re'.

START MESSAGES

Solo: use Free Play, or start with exactly one credit so no spare credits
remain. Spare credits keep PRESS START above the vacant seat and suppress the
message, as in the Japanese game.

Hold the active player's Start while the VS screen is showing, keep it held
until the fight begins, then release. With no attack held, Challenger /
wanted! alternates with the normal join prompt. Hold LP, MP, HP, LK, MK or HK
with Start for the other six choices. Pressing Start again during the fight
cancels the stored notice.

Two-player HUD messages require a completed round: hold Start through the
transition into the next round. The two sets belong to the previous round
winner and loser. For the result-screen set, hold the match winner's Start
through the result transition. Longer messages appear in two consecutive
parts.


LEGAL

This is a free, unofficial fan patch. It is not affiliated with or endorsed
by Capcom. All game titles, characters, and artwork remain the property of
their respective owners. You must own the game to use this patch. Do not
sell this patch or distribute it applied to a ROM image.
