ROM INPUT UPDATE

Merged, split, complete ZIP/7z archives and extracted ROM folders are accepted.
Use --rompath DIR (repeatable) to search a collection, or keep the existing archive argument.
Names may differ; required source contents are verified by size and strong hashes.
Use --check to verify arcade build inputs before reconstruction.
QSound is optional for game builds. Valid embedded firmware is preserved in complete game outputs.
Use --include-devices on CPS-2 kits to require and include firmware from separate archives.
Compact HBMAME outputs retain their stock-game and device dependencies.
7z input requires an installed 7-Zip executable; ZIP needs no extra archive software.
Original archives are never modified by collection discovery.

Vampire Savior · English restoration
====================================

Version:  rc2 (2026-10-11)
Target:   MAME set 'vsavj' (Vampire Savior: The Lord of Vampire (Japan 970519))
Hardware: Capcom CPS-2
Patch by: Steve Gordon (https://x.com/strygo)
Website:  https://arcadepatches.com/vsav-restoration/

ABOUT THIS PROJECT

Vampire Savior wasn't the same game everywhere. The export versions recolored
Jedah's blood purple and Forever Torment's green, cut a few gory touches
entirely, and defaulted to sweat instead of blood. Their English script
dropped fourteen win quotes and 47 ending pages. Even the damage values
differ: in places the export versions hit a little harder.

The English Restoration is the Japanese game, in English. The blood is red
again, everywhere it was in Japan. All 241 win quotes and every ending page
are here, translated from the Japanese: where Capcom's English said the same
thing it's kept, and everything else is newly translated, including the pages
the export dropped. The fights run on Japan's damage values and Japan's
computer difficulty.

Out of the box it's set up like a Japanese cabinet: blood on, Auto guard
selectable at the select screen, one coin one credit. The operator menu and
the Western character names stay as the US version has them, and Lord Raptor's
name finally reads L.Raptor instead of L.Rapter.

It's a USA build that runs in MAME, HBMAME and on MiSTer. The Japanese version
already has everything above, so there's no Japan build for now.

This is a release candidate.

WHAT'S CHANGED

  - All 241 win quotes from the Japanese game, in English, including the
    fourteen the US version dropped
  - Every ending page from the Japanese game, in English, including the 47 the
    US version dropped, with Japan's page timing
  - The dialogue before the final battle with Jedah, checked line by line
    against the Japanese and revised where Capcom's English strayed
  - Red blood: Jedah's attacks (purple in the US version), Forever Torment's
    guillotine and well (green), and hit blood on by default
  - Lord Raptor's blood spray in his bite throw, and the paper notice in
    Bishamon's Togakubi Sarashi finish, both cut from the export versions
  - Japan's damage values and computer difficulty
  - Set up like a Japanese cabinet: blood on, Auto guard selectable, one coin
    one credit
  - Lord Raptor's name spelled right

HOW TO APPLY (recommended)

    python3 apply.py /path/to/vsavj.zip --out-dir out

This checks every file against the original, applies the patches, checks
the result, and writes everything you need for each platform:

  MAME:                     out/mame/vsavj.zip
  HBMAME:                   out/hbmame/vsavru.zip
  MiSTer:                   out/mister/_Arcade/_Arcade Patches/_Restorations/Vampire Savior The Lord of Vampire (USA) [English Restoration].mra

Merged, split and complete sets work, including nested or renamed ROMs.
Use --rompath DIR (repeatable) to search a collection instead of naming the
zip, and --check to check inputs before building. ZIPs and extracted folders
need no extra software; 7z archives use installed 7-Zip or a verified download.
QSound can stay in your emulator's ROM path; valid firmware already
in a source set is kept in complete outputs.

MAME: put vsavj.zip from out/mame/ ahead of the stock set in your MAME
rompath.
MAME's game menu won't start a set with patched ROMs, so start it from the
command line: mame vsavj. MAME shows checksum warnings for the patched
ROMs; that's expected and the game runs normally.
To start it from a menu, use the HBMAME build.

HBMAME: this restoration is an official HBMAME set (vsavru),
so full HBMAME collections may already carry it.
Put the zip in HBMAME's roms/ folder next to your stock vsavj.zip.

MiSTer: copy the _Arcade folder from out/mister/ to the root of your SD card
and keep the stock, unmodified romset at games/mame/vsavj.zip (split MAME
sets also need qsound.zip). The MRA applies the restoration in memory as the
game loads, so nothing on the card is modified. You need Jotego's jtcps2
core, which update_all installs. The MRAs are also a separate download.

HOW TO APPLY (any IPS patcher)

Extract vsavj.zip, apply each file in ips/ to the ROM file of the
same name (Flips, Lunar IPS, or any IPS tool), then re-zip everything
as vsavj.zip.

CHANGED FILES

    vm3.13m  (4.0 MB)  CRC32 fd8a11eb -> 25b89bee
    vm3.15m  (4.0 MB)  CRC32 dd1e7d4e -> 7c4ed97c
    vm3.17m  (4.0 MB)  CRC32 6b89445e -> 05295327
    vm3.19m  (4.0 MB)  CRC32 3830fdc7 -> e90b3fee
    vm3j.03d  (512 KB)  CRC32 2a2e74a4 -> 87184d16
    vm3j.04d  (512 KB)  CRC32 1c2427bc -> c623f797
    vm3j.07b  (512 KB)  CRC32 a38aaae7 -> b3cbf9a8

All other files in the set are unmodified.

LEGAL

This is a free, unofficial fan patch. It is not affiliated with or endorsed
by Capcom. All game titles, characters, and artwork remain the property of
their respective owners. You must own the game to use this patch. Do not
sell this patch or distribute it applied to a ROM image.

DARKSOFT OUTPUT

Use --platform darksoft --out-dir out, or --platform all.
Copy the game folder from out/darksoft/games to the card games folder.
Expanded hardware and streamed audio are not supported.

PYTHON PACKAGES

When a build needs NumPy or Pillow and it is not already installed, the kit
downloads its pinned prebuilt package from PyPI into your user cache. No pip,
compiler, administrator rights or changes to system Python are needed.
Patch-only builds and --help do not download Python packages.

Automatic package installation is qualified for CPython 3.12 on Apple Silicon
Macs and CPython 3.13 x64 on Windows (including x64 Python on Windows ARM).
Other interpreters can still use manually installed NumPy/Pillow. There is
no automatic source compilation or selection of an unqualified package.

Cache: ~/Library/Caches/ArcadePatches/python on Mac, or
%LOCALAPPDATA%/ArcadePatches/python on Windows. You can choose another location
with --python-cache PATH (or ARCADE_PYTHON_CACHE). --tools-cache PATH places
the Python cache under PATH/python unless --python-cache is also supplied.
You may delete this cache when no installer is running; it is recreated later.

Offline: add --python-wheels PATH --offline. PATH may name the matching
python-wheels-v1-*.zip, a folder of unzipped wheels, or a folder containing
the wheel ZIPs. The existing wheel bundles work without modification.
You can also supply --tools-bundle for the other helpers in the same command.
ARCADE_PYTHON_WHEELS is the equivalent environment variable. A warm cache
works offline without a bundle. --offline prohibits package downloads too.
Every wheel is checked against the kit's hash; cached extracted files are
verified before use. Existing manually installed packages remain supported.

The installer and its Python subprocesses share the cache. Your shell profile,
global site-packages and unrelated Python applications are not changed.

FBNEO OUTPUT

Use --platform fbneo --out-dir out, or --platform all.
The default all-platform build also includes these complete game sets:
  default: out/fbneo/vsavre.zip
The ZIPs preserve the existing FBNeo ROM member names and contain complete game sets.
Copy the ZIPs to your FBNeo ROM folder without renaming their members.
Use an FBNeo version with definitions matching this game release.
Older definitions may reject these checksums.
