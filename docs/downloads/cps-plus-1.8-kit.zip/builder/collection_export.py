"""CPS+ kit definitions and exact-bound exports using the standalone pack builder.

The group table, shipped MRAs, golden pack hashes and owned-media declarations
are the inputs. No catalog, source parser or separately versioned adapter is used.
"""
import argparse
import hashlib
import json
import itertools
import os
import runpy
from pathlib import Path, PurePosixPath
import shutil
import subprocess
import sys
import tempfile
import xml.etree.ElementTree as ET
import zipfile


def require(value, message):
    if not value:raise ValueError(message)


def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 ** 2), b''):h.update(block)
    return h.hexdigest()


def safe(name):
    require(isinstance(name, str), 'Invalid kit path')
    path = PurePosixPath(name)
    require(isinstance(name, str) and name and path.as_posix() == name and not path.is_absolute()
            and not any(c in name for c in '\\:<>"|?*') and not any(ord(c) < 32 for c in name)
            and '..' not in path.parts and all(not p.endswith((' ', '.')) and p.split('.')[0].upper() not in
                {'CON', 'PRN', 'AUX', 'NUL', *[f'COM{i}' for i in range(1, 10)], *[f'LPT{i}' for i in range(1, 10)]}
                for p in path.parts), 'Unsafe kit path')
    return path


def json_bytes(value):
    return (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()


def pin(path):return {'sha256': digest(path)}


def group_identity(group, bindings, accepted):
    # Verified finished CPKs remain valid when a readme, MRA or core changes.
    # A changed source/firmware binding or accepted pack set selects a new entry.
    return hashlib.sha256(json_bytes({'schema': 2, 'group': group,
        'inputs': {key: row['sha256'] for key, row in bindings.items()},
        'accepted_packs': accepted})).hexdigest()


def prepare_dos_source(root, archive, cache):
    if not archive.is_file() or archive.suffix.lower() not in ('.zip', '.7z'):
        return
    from source_cache import prepared_tree, private_view
    import make_dos_flac
    data = prepared_tree(cache, archive, digest(root/'builder/make_dos_flac.py'),
                         lambda destination: make_dos_flac.unpack(archive, destination))
    target = root/'builder/work/dos/game'
    target.parent.mkdir(parents=True, exist_ok=True)
    private_view(data, target)


def stage_source(source, staged, folder):
    """Bind content-discovered members and any producer-owned descriptor."""
    if source.get('descriptor'):
        require(set(source['files']) == {source['entry']}, 'Invalid descriptor source')
        return staged[source['files'][source['entry']]]
    folder.mkdir()
    if 'zip_members' in source:
        safe(source['zip_members'])
        with zipfile.ZipFile(folder / source['zip_members'], 'w', zipfile.ZIP_STORED) as archive:
            for member, key in source['files'].items():
                safe(member);archive.write(staged[key], member)
    else:
        for member, key in source['files'].items():
            safe(member);dest = folder / member;dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(staged[key], dest)
    for member, content in source.get('generated_files', {}).items():
        safe(member);dest = folder / member
        require(not dest.exists(), 'Generated descriptor overlaps source media')
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_text(content, encoding='utf-8', newline='\n')
    entry = source['entry'];require(entry == '.' or safe(entry), 'Invalid source entry')
    return folder if entry == '.' else folder / entry


def source_choices(group, choices):
    """Match the DOS renderer's admission rule for installed-game carriers."""
    if group in ('ssf2-dos-fm', 'ssf2-dos-sc55', 'ssf2-dos-mt32'):
        choices = dict(choices)
        choices['ssf2t_dos_disc'] = [v for v in choices['ssf2t_dos_disc']
                                   if Path(v['entry']).suffix.lower() not in ('.cue', '.chd')]
        require(choices['ssf2t_dos_disc'], 'DOS MIDI carriers require an installed-game source')
    return choices


def definitions(root, version, revision):
    root = Path(root);builder = root / 'builder'
    groups = runpy.run_path(str(builder / 'pack_groups.py'))['describe'](builder)
    sources = json.loads((builder / 'manifests/collection_sources.json').read_text())
    golden = groups['accepted_packs']
    require(set(sources['packs']) == set(golden), 'Declared accepted packs differ from native groups')
    prerequisites = {};bound = {}
    def prereq(title, kind, spec):
        # Equal carrier bytes can have different admission rules. In particular,
        # a content-matched CUE must use its descriptor route, which preserves
        # the adjacent filenames, rather than an exact canonical file layout.
        key = kind + '-' + hashlib.sha256(json.dumps(spec, sort_keys=True).encode()).hexdigest()[:20]
        prerequisites[key] = {'title': title, 'kind': kind, 'formats': ['loose file', 'ZIP member', '7z member'],
            'action': 'Add your matching owned media or accepted pack to a scanned folder.',
            'alternatives': [{k: v for k, v in spec.items() if k in ('sha256', 'size', 'crc32')}]}
        if spec.get('content'):
            prerequisites[key]['content'] = spec['content']
        return key
    for name, source in sources['sources'].items():
        variants = [{k: v for k, v in source.items() if k != 'representations'}, *source.get('representations', [])]
        bound[name] = [{**variant, 'files': {n: prereq(name + ': ' + n, 'source', spec)
                       for n, spec in variant['files'].items()}} for variant in variants]
    key = 'switch-production-keys'
    prerequisites[key] = {'title': 'Your own Switch prod.keys', 'kind': 'keyfile', 'formats': ['UTF-8 private key map'],
        'text_keys': {'header_key': 64}, 'action': 'Add your private production key map. Its values are never reported.'}
    bound['switch_prod_keys'] = [{'entry': 'private.keys', 'files': {'private.keys': key}}]
    # These two game launchers belong to the complete Final Fight EX game kit.
    # Its current ROM layout supersedes the soundtrack kit's original launchers.
    delegated = {'Final Fight EX (USA) [Arrange].mra', '_Japan/Final Fight EX (Japan) [Arrange].mra'}
    mras = {pack: {} for pack in golden};raw = {};assets = {}
    for path in sorted((builder / 'mras').rglob('*.mra')):
        relative = path.relative_to(builder / 'mras').as_posix()
        destination = '_Arcade/_Arcade Patches/_Arrangements/_CPS+/' + relative
        raw[destination] = pin(path)
        if relative in delegated:continue
        xml = ET.fromstring(path.read_bytes())
        refs = {p for p in golden if any('/CPS+/' + p + '.zip' in node.get('zip', '').split('|') for node in xml.iter())}
        require(len(refs) == 1, 'MRA must bind one accepted native pack: ' + relative)
        region = (xml.findtext('region') or '').strip().lower()
        region = {'usa': 'us', 'japan': 'jp', 'europe': 'eu', 'asia': 'asia', 'world': 'world'}.get(region, region)
        require(region in ('us', 'jp', 'eu', 'asia', 'world'), 'Unknown native MRA region')
        mras[next(iter(refs))].setdefault(region, {})['builder/mras/' + relative] = destination
    for path in sorted((builder / 'cores').iterdir()):
        if not path.is_file():continue
        original = 'builder/cores/' + path.name
        old = '_Arcade/cores/' + path.name;raw[old] = pin(path)
        assets[original] = old if path.suffix == '.rbf' else '_Arcade/cores/licenses/cps-plus/' + path.name
    support = {'README.txt': 'support/cps-plus/README-original.txt', 'INSTALL.md': 'support/cps-plus/INSTALL-original.md',
               'builder/games_readme.txt': 'games/CPS+/README.txt'}
    targets = {};layouts = {}
    for group in groups['groups']:
        for pack in group['packs']:
            hashes = golden[pack];hashes = [hashes] if isinstance(hashes, str) else hashes
            require(sources['packs'][pack]['sha256'] in hashes, 'Accepted pack size pin differs from golden hashes')
            pack_key = prereq('Accepted CPS+ ' + pack + '.cpk', 'pack', sources['packs'][pack])
            needed = group['source_keys']
            if group['id'] == 'ffight':needed = ['ffight_jp_disc' if pack.endswith('_jp') else 'ffight_us_disc']
            require(set(needed) <= set(bound), 'Native group needs declared source identities')
            choices = source_choices(group['id'], {name: bound[name] for name in needed})
            if pack in ('ffight_di', 'msword_di', 'ssf2_hdremix'):
                recipe = json.loads((builder / 'manifests' / (pack + '_audio.json')).read_text())
                consumed = {Path(row['source']).name for row in recipe['tracks']}
                for name in needed:
                    choices[name] = [{**variant, 'files': {member: key for member, key in variant['files'].items()
                                                         if Path(member).name in consumed}} for variant in bound[name]]
                    require(all(v['files'] for v in choices[name]), 'Album source extent is empty')
            methods = {}
            for i, variants in enumerate(itertools.product(*(choices[name] for name in needed))):
                method = 'source-media' if i == 0 else 'source-media-' + str(i)
                methods[method] = dict(zip(needed, variants))
            input_options = [{'id': method, 'title': 'Reconstruct from owned source media' + ('' if i == 0 else ' (' +
                              ', '.join(source.get('label', 'alternative layout') for source in variants.values()) + ')'),
                              'inputs': sorted({key for source in variants.values() for key in source['files'].values()})}
                             for i, (method, variants) in enumerate(methods.items())]
            require(mras[pack], 'Accepted pack has no native launcher')
            for region, launchers in sorted(mras[pack].items()):
                name = pack.replace('_', '-') + '-' + region
                mapping = {**assets, **launchers, **support}
                outputs = {new: pin(root / old) for old, new in mapping.items()}
                variants = [{'members': {pack + '.cpk': h}} for h in hashes]
                output = 'games/CPS+/' + pack + '.zip'
                outputs[output] = variants[0] if len(variants) == 1 else {'any_of': variants}
                targets[name] = {'platform': 'mister', 'variant': pack.replace('_', '-'), 'native_variant': name,
                    'region': region, 'inputs': [], 'input_options': [
                        {'id': 'existing-pack', 'title': 'Reuse the publicly accepted ' + pack + ' pack', 'inputs': [pack_key]},
                        *input_options],
                    'outputs': outputs, 'timeout_seconds': 14400, 'minimum_free_bytes': 20 * 1024 ** 3,
                    'external_tools': [{'id': 'mame', 'title': 'MAME for native soundtrack recording',
                        'commands': ['mame', 'mame64'], 'args': ['-version'], 'version_pattern': r'^0\.[0-9]+(?:\s|$)',
                        'methods': list(methods), 'action': 'Install MAME with the required PlayStation/X68000 driver and Lua support on PATH.'}]
                        if group['id'] in ('strider-psx', 'ssf2-x68k-fm') else [],
                    'destination_requirements': 'Soundtrack overlay: install the arcade ROM sets named by each MRA and the matching patched game kits. Arcade ROMs are not supplied.'}
                layouts[name] = {'pack': pack, 'group': group['id'], 'sources': needed, 'mapping': mapping, 'pack_key': pack_key,
                                 'pack_output': output, 'source_methods': methods}
    definition = {'api': 1, 'project': 'cps-plus', 'game_version': version, 'kit_revision': revision,
        'requires': ['native-context-v1', 'native-bindings-v1', 'input-options-v1', 'output-options-v1',
                     'text-keys-v1', 'external-tools-v1', 'worker-timeout-v1'],
        'prerequisites': prerequisites, 'targets': targets, 'native_outputs': raw}
    dependencies = json.loads((builder / 'collection_dependencies.json').read_text())
    definition.update(dependencies)
    if definition.get('environments'):definition['requires'] += ['locked-wheels-v1', 'native-dependencies-v1']
    return definition, layouts, bound


def seal(root, version, revision):
    root = Path(root)
    definition, _, _ = definitions(root, version, revision)
    manifest = {'api': 1, 'project': 'cps-plus', 'version': version, 'kit_revision': revision,
        'files': {p.relative_to(root).as_posix(): digest(p) for p in sorted(root.rglob('*'))
                  if p.is_file() and p.relative_to(root).as_posix() not in ('manifest.json', 'collection.json')
                  and '__pycache__' not in p.parts}}
    (root / 'manifest.json').write_bytes(json_bytes(manifest))
    definition['manifest_sha256'] = digest(root / 'manifest.json')
    (root / 'collection.json').write_bytes(json_bytes(definition))
    return definition


def describe(root):
    root = Path(root);definition = json.loads((root / 'collection.json').read_text())
    require(definition['api'] == 1 and definition['project'] == 'cps-plus' and
            definition['manifest_sha256'] == digest(root / 'manifest.json'), 'CPS+ definition manifest differs')
    manifest = json.loads((root / 'manifest.json').read_text())
    for name, expected in manifest['files'].items():
        safe(name);require(digest(root / name) == expected, 'CPS+ producer changed: ' + name)
    actual, _, _ = definitions(root, manifest['version'], manifest['kit_revision'])
    require({k: v for k, v in definition.items() if k != 'manifest_sha256'} == actual, 'CPS+ definition differs from producer')
    return definition


def run(root, args):
    from kit_collection import bound_file
    root = Path(root);definition = describe(root)
    require(args.platform == 'mister' and args.variant in definition['targets'], 'Unknown CPS+ export target')
    target = definition['targets'][args.variant];operation = 'check' if args.check else 'build'
    value = json.loads(Path(args.inputs_json).read_text());context = value['context'];bindings = value['bindings']
    require(value['schema'] == 1, 'Unknown bound input schema')
    require(Path(context['run_cache']).is_absolute() and Path(context['tools_cache']).is_absolute(), 'Native cache paths must be absolute')
    method = context['input_option'];options = {m['id']: m for m in target['input_options']}
    require(method in options and set(bindings) == set(options[method]['inputs']), 'Incomplete or unexpected bound CPS+ inputs')
    _, layouts, sources = definitions(root, definition['game_version'], definition['kit_revision'])
    layout = layouts[args.variant];pack = layout['pack']
    # No fallback to discs.toml: only these verified sources reach the native builder.
    with tempfile.TemporaryDirectory(prefix='cps-inputs-', dir=context['run_cache']) as temporary:
        temporary = Path(temporary);staged = {}
        for key, binding in bindings.items():
            requirement = definition['prerequisites'][key]
            staged[key] = bound_file(binding, temporary / key)
            if 'alternatives' in requirement and (any(v['identity']['type'] == 'cue' for v in requirement.get('content', []))
                    or not any(binding['sha256'] == p['sha256'] and binding['size'] == p['size'] for p in requirement['alternatives'])):
                import media_identity
                sys.path.insert(0, str(root / 'builder'))
                def tool(name):
                    from pack.media_tools import disc_tool, ffmpeg_exe
                    return ffmpeg_exe() if name == 'ffmpeg' else disc_tool(name)
                accepted = False
                for variant in requirement.get('content', []):
                    try:
                        media_identity.verify(staged[key], variant['identity'], tool)
                        accepted = True;break
                    except (ValueError, subprocess.CalledProcessError):
                        continue
                require(accepted, 'Undeclared CPS+ source content')
        if method == 'existing-pack':
            cp = staged[layout['pack_key']]
        else:
            if args.check:
                return {'api': 1, 'target': args.variant, 'operation': operation, 'status': 'ok'}
            hashes = json.loads((root / 'builder/pack_hashes.json').read_text())
            group = next(g for g in runpy.run_path(str(root/'builder/pack_groups.py'))['describe'](root/'builder')['groups']
                         if g['id'] == layout['group'])
            identity = group_identity(layout['group'], bindings, {name: hashes[name] for name in group['packs']})
            cached = Path(context['run_cache']) / ('cps-group-' + identity)
            marker = cached / 'complete.json'
            if marker.exists():
                metadata = json.loads(marker.read_text())
                require(metadata['identity'] == identity and pack in metadata['packs'], 'Native group cache identity differs')
                require({p.name for p in cached.iterdir()} == {'complete.json', *[n + '.cpk' for n in metadata['packs']]}, 'Native group cache extent differs')
                hashes = json.loads((root / 'builder/pack_hashes.json').read_text())
                for name in metadata['packs']:
                    accepted = hashes[name];accepted = [accepted] if isinstance(accepted, str) else accepted
                    require(digest(cached / (name + '.cpk')) in accepted, 'Native group cache changed')
            else:
                cached.mkdir(parents=True, exist_ok=True)
                discs = {}
                for name in layout['sources']:
                    discs[name] = stage_source(layout['source_methods'][method][name], staged, temporary / name)
                os.environ.update(SDL_VIDEODRIVER='dummy', SDL_AUDIODRIVER='dummy',
                    CPSPLUS_SWITCH_TOOLS_CACHE=context['tools_cache'], ARCADE_PYTHON_CACHE=str(Path(context['tools_cache']) / 'python'))
                os.environ.pop('CAPCOM_ARCADE_ROM_PATH', None);os.environ.pop('CPSPLUS_PYTHON', None)
                sys.path.insert(0, str(root / 'builder'))
                import make_packs
                argv = ['--only', layout['group'], '--jobs', '2', '--tools-cache', context['tools_cache']]
                if context['offline']:argv.append('--offline')
                require(not (root / 'builder/work').exists() and not (root / 'out').exists(),
                        'Native CPS+ execution needs a fresh kit workspace')
                if layout['group'].startswith('ssf2-dos-'):
                    prepare_dos_source(root, discs['ssf2t_dos_disc'], context['run_cache'])
                require(make_packs.main(argv, bound_discs=discs) == 0, 'Native CPS+ reconstruction failed')
                produced = []
                hashes = json.loads((root / 'builder/pack_hashes.json').read_text())
                for archive in sorted((root / 'out/mister/games/CPS+').glob('*.zip')):
                    name = archive.stem;require(name in hashes, 'Unknown native CPS+ output')
                    with zipfile.ZipFile(archive) as z:
                        require(z.namelist() == [name + '.cpk'], 'Native CPS+ pack extent differs')
                        destination = cached / (name + '.cpk')
                        with z.open(name + '.cpk') as stream, destination.open('wb') as output:shutil.copyfileobj(stream, output, 1024 ** 2)
                    accepted = hashes[name];accepted = [accepted] if isinstance(accepted, str) else accepted
                    require(digest(destination) in accepted, 'Native pack differs from accepted golden hash')
                    produced.append(name)
                require(pack in produced, 'Native group did not produce requested pack')
                marker.write_bytes(json_bytes({'identity': identity, 'packs': produced,
                    'producer_manifest_sha256': definition['manifest_sha256']}))
                shutil.rmtree(root / 'builder/work', ignore_errors=True)
                shutil.rmtree(root / 'out', ignore_errors=True)
            cp = cached / (pack + '.cpk')
        golden = json.loads((root / 'builder/pack_hashes.json').read_text())[pack]
        require(digest(cp) in ([golden] if isinstance(golden, str) else golden), 'Pack differs from accepted native hash')
        if not args.check:
            output = Path(args.out_dir);output.mkdir(parents=True, exist_ok=True)
            require(not any(output.iterdir()), 'Collection export must be empty')
            for old, new in layout['mapping'].items():
                safe(old);safe(new);path = output / new;path.parent.mkdir(parents=True, exist_ok=True);shutil.copyfile(root / old, path)
            dest = output / layout['pack_output'];dest.parent.mkdir(parents=True, exist_ok=True)
            with zipfile.ZipFile(dest, 'w', zipfile.ZIP_STORED) as z:z.write(cp, pack + '.cpk')
        return {'api': 1, 'target': args.variant, 'operation': operation, 'status': 'ok',
                **({'outputs': target['outputs']} if not args.check else {})}


def main(root):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--describe-json', action='store_true')
    parser.add_argument('--inputs-json', type=Path);parser.add_argument('--collection-layout', action='store_true')
    parser.add_argument('--variant');parser.add_argument('--platform');parser.add_argument('--out-dir', type=Path)
    parser.add_argument('--report-json', type=Path);parser.add_argument('--check', action='store_true')
    args = parser.parse_args()
    if args.describe_json:print(json.dumps(describe(root), sort_keys=True));return 0
    require(args.collection_layout and args.inputs_json and args.report_json and args.out_dir, 'Use the collection interface with exact bound inputs')
    try:
        result = run(root, args)
    except (ValueError, OSError, KeyError, zipfile.BadZipFile) as exc:
        result = {'api': 1, 'target': args.variant, 'operation': 'check' if args.check else 'build',
                  'status': 'error', 'message': str(exc)}
        args.report_json.write_bytes(json_bytes(result));return 2
    args.report_json.write_bytes(json_bytes(result));return 0
