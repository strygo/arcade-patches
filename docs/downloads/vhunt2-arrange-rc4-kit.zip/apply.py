#!/usr/bin/env python3
"""Build an Arrange edition from your own copies.

This tool ships no game data.  It rebuilds the CPS-2 sets from files you
already own:
  * your arcade romsets: Vampire Hunter 2 (vhunt2), Vampire Savior 2 (vsav2)
    and Vampire Savior (vsavj), all Japanese, and
  * your PS2 Vampire: Darkstalkers Collection (Japan) disc image.

Every member is checksum-verified against the known build.  See README.txt.
"""
# BEGIN ARCADE KIT ENTRY
if __name__ == "__main__":
    import sys as _kit_sys
    if len(_kit_sys.argv) == 1 and _kit_sys.stdin.isatty() and _kit_sys.stdout.isatty():
        import importlib.util as _kit_import
        from pathlib import Path as _KitPath
        _kit_root = _KitPath(__file__).resolve().parent
        _kit_spec = _kit_import.spec_from_file_location("_kit_frontend", _kit_root / "_kit_runtime/frontend.py")
        _kit_frontend = _kit_import.module_from_spec(_kit_spec)
        _kit_spec.loader.exec_module(_kit_frontend)
        raise SystemExit(_kit_frontend.guided(_kit_root))
# END ARCADE KIT ENTRY

# BEGIN ARCADE PYTHON BOOTSTRAP
import sys as _arcade_sys
from pathlib import Path as _ArcadePath
_arcade_sys.path.insert(0, str(_ArcadePath(__file__).resolve().parents[0]))
from kit_python import bootstrap as _arcade_bootstrap
_arcade_bootstrap()
# END ARCADE PYTHON BOOTSTRAP

import sys as _native_sys
from pathlib import Path as _NativePath
if __name__ == '__main__' and ('--collection-layout' in _native_sys.argv or '--describe-json' in _native_sys.argv):
    _native_sys.path.insert(0, str(_NativePath(__file__).resolve().parent))
    from arrange_collection import main as _native_main
    raise SystemExit(_native_main(_NativePath(__file__).resolve().parent))
import argparse
import json
import re
import shutil
import sys
import tempfile
from pathlib import Path

import arrange
import collection
import music
from rom_sources import Resolver, RomError, QSOUND, search_paths, publish_tree, write_zip

from rom_sources import require_path, default_output, check_output, print_completion

HERE = Path(__file__).resolve().parent
KIT = json.loads((HERE / "kit.json").read_text())


def fail(msg):
    print(f"ERROR: {msg}", file=sys.stderr)
    sys.exit(1)


def main():
    ap = argparse.ArgumentParser(description=KIT["description"],
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--iso", "--disc", dest="iso", help="your Vampire: Darkstalkers Collection (Japan) DVD ISO or CHD")
    ap.add_argument("--chdman", help="optional chdman executable or containing folder for DVD CHDs")
    ap.add_argument("--romset", action="append", default=[], help="an arcade ZIP, 7z or ROM folder (repeatable)")
    ap.add_argument("--rompath", action="append", default=[], help="a folder to search for romsets (repeatable)")
    ap.add_argument("--region", choices=(*KIT["regions"], "all"), default="all")
    ap.add_argument('--platform', choices=('all','hbmame','mister','fbneo'), default='all')
    ap.add_argument("--include-devices", action="store_true")
    ap.add_argument("--check", action="store_true", help="verify the arcade inputs only")
    ap.add_argument("--out-dir", help="build into this folder")
    ap.add_argument("--debug", action="store_true", help="show a traceback for troubleshooting")
    from tool_controls import add_arguments,configure
    add_arguments(ap)
    args = ap.parse_args()
    configure(sys.argv[1:])
    if args.iso:
        args.iso = require_path(args.iso, "--iso", file=True)
    if not args.check and not args.iso:
        fail("--iso is required to build " + KIT["title"])
    if not args.check and not args.out_dir:
        args.out_dir = str(default_output("output-" + HERE.name))
    if not args.check:
        check_output(args.out_dir, [p for p in [args.iso] if p] + args.romset + args.rompath)

    if not args.check and not args.out_dir:
        fail("give --out-dir")
    catalog = json.loads((HERE / "rom_inputs.json").read_text())["sets"]
    print("Reading your arcade romsets...")
    paths = []
    for r in args.romset:
        paths += search_paths(r, args.rompath, HERE)
    resolver = Resolver(dict.fromkeys(paths or search_paths(None, args.rompath, HERE)),
                        hints=[*KIT["romsets"], "qsound", "qsound_hle"],
                        exclude=[Path(args.out_dir or "out"), HERE / "work"], progress=print)
    roms = {}
    for name, members in KIT["romsets"].items():
        roms[name] = resolver.resolve([catalog[name][m] for m in members])
    firmware = resolver.devices(include=args.include_devices)
    if args.check:
        print(f"{KIT['title']} arcade inputs verified")
        return
    if not args.iso:
        fail(f"--iso is required to build {KIT['title']}")
    try:
        from disc_sources import dvd_iso
        with dvd_iso(args.iso,chdman=args.chdman) as iso:
            collection.Disc(iso)
            files = build_native_outputs(iso, roms, firmware.get(QSOUND['name']), args.region)
    except (OSError, ValueError) as exc:
        fail(f"{exc}\n       looked for: {Path(args.iso).absolute()}")
    from arrange_fbneo import projection
    files = projection(HERE, files, args.platform)
    publish_tree(Path(args.out_dir), files)
    print_completion(args.out_dir, files)


def check_native_disc(iso):
    return collection.Disc(str(iso))


def build_native_outputs(iso, roms, firmware, region):
    disc = check_native_disc(iso)
    roms = {name: dict(members) for name, members in roms.items()}
    base = KIT["base"]
    if firmware is not None:
        roms[base][QSOUND["name"]] = firmware
    regions = list(KIT["regions"]) if region == "all" else [region]
    stage_context = tempfile.TemporaryDirectory(prefix=".arrange-", )
    stage = Path(stage_context.name)
    for region in regions:
        meta = KIT["regions"][region]
        recipes = json.loads((HERE / "recipes" / f"{region}.json").read_text())
        if QSOUND["name"] not in roms[base]:
            recipes["units"] = [u for u in recipes["units"] if u["members"] != [QSOUND["name"]]]
            recipes["md5"].pop(QSOUND["name"], None)
        print(f"Building {meta['mra']} (this takes a few minutes)...")
        try:
            members = arrange.reconstruct(arrange.Inputs(roms, disc, recipes["spec"]), recipes)
        except ValueError as exc:
            fail(str(exc))
        zip_name = f"{meta['set']}.zip"
        write_zip(stage / "hbmame" / zip_name, members)
        write_zip(stage / "mister" / "games" / "hbmame" / zip_name, members)
        mra = (HERE / "mras" / f"{meta['mra']}.mra").read_text()
        mra = re.sub(r'zip="(/hbmame/[^"|]+\.zip)"', r'zip="\1|qsound.zip|qsound_hle.zip"', mra)
        folder = stage.joinpath("mister", *KIT["mra_root"], KIT["mra_dir"][region])
        folder.mkdir(parents=True, exist_ok=True)
        (folder / f"{meta['mra']}.mra").write_bytes(mra.encode())
    print("Building the shared Collection music pack...")
    pack = stage / "vampire_arrange.cpk"
    music.build(disc, json.loads((HERE / "music.json").read_text()), pack)
    write_zip(stage / "mister/games/CPS+/vampire_arrange.zip", {pack.name: pack.read_bytes()})
    pack.unlink()
    cores = stage / "mister" / "_Arcade" / "cores"
    cores.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(HERE / "core" / KIT["core"], cores / KIT["core"])
    from arrange_collection import tree_outputs
    files = tree_outputs(stage)
    stage_context.cleanup()
    return files



if __name__ == "__main__":
    try:
        main()
    except (OSError, ValueError) as exc:
        if "--debug" in sys.argv:
            raise
        fail(str(exc))
