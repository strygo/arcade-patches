Super Street Fighter II EX: The Ultimate Championship · Enhanced version
========================================================================

Version:  rc4 (2026-10-01)
Target:   MAME set 'ssf2xj' (Super Street Fighter II X: Grand Master Challenge (Japan 940311))
Hardware: Capcom CPS-2
Patch by: Steve Gordon (https://x.com/strygo)
Website:  https://strygo.github.io/arcade-patches/

ABOUT THIS PROJECT

Super Turbo is the version competitive players swear by, but it left things
behind. The bonus stages from Super Street Fighter II were gone. Shin Akuma
was a hidden boss you had to earn, and Ten Akuma only turned up years later at
home. Tournament Battle, the eight-player linked-cabinet mode, stayed with the
earlier Super Street Fighter II.

EX puts it together on the arcade game. Akuma has his own select-screen cell,
with Shin and Ten available through codes there; the original Ryu codes still
work. A random-select cell sits opposite him. The car, the falling barrels and
the oil drums are back between fights. Link cabinets with the adapter and it
runs Tournament Battle; without it, it plays as normal. Every fighter gets two
more colors, Akuma and Shin Akuma get their colors from Ultra Street Fighter
II, the move names are the modern ones, and the new title reads The Ultimate
Championship.

Nothing about the existing fighters changes: this is Japan's Super Turbo
underneath. The USA build carries all of Grand Master Challenge's English
text; the Japan build keeps the Japanese.

EX uses the same ROM files as the Japanese set. It runs in MAME and HBMAME and
on MiSTer.

This is a release candidate.

WHAT'S CHANGED

  - Akuma and random-select cells on the player-select screen. On Akuma or
    Ryu, hold Start and press three kicks for Shin, or MP, HP, MK and HK
    together for Ten (hold Start and three punches gives Akuma)
  - Ten Akuma has his Super gauge and the Raging Demon, with the 天 pose
  - Akuma in eleven classic colors from Ultra Street Fighter II, picked on his
    own cell: three punches or three kicks, any single button, or LP+LK, MP+MK
    or HP+HK (LP+HK keeps the EX blue). His portraits follow the color, even
    in a mirror match
  - Shin Akuma in eleven colors from Ultra Street Fighter II: pick Shin on
    Akuma's cell, let go of every button, then press one of the same buttons
    before the select screen moves on
  - Akuma's own defeated face on the Continue screen, in the color you picked
  - The three bonus stages from Super Street Fighter II, back in one-player
    games: the car after three fights, the barrels after six, the oil drums
    after nine. They run at the selected Turbo speed, and a BONUS STAGE
    setting in the operator menu can turn them off
  - Tournament Battle: with the link adapter, eight players and three matches
    across linked cabinets, with the Akuma and random-select cells on its
    select screen; without it, the game plays normally
  - A new title screen: The Ultimate Championship, with an EX mark
  - Two more colors for every fighter: pick with two punches or two kicks, or
    hold Start as well for the Old version in those colors. The VS screen and
    the fight portrait show the color you picked
  - Free Play in the Japanese build too
  - Modern move names: Cammy's Spiral Arrow, Cannon Spike and Quick Spin
    Knuckle, and Dee Jay's Air Slasher, with the Japanese voice callouts in
    the USA build
  - USA build: all of Grand Master Challenge's English. Japan build: the
    original Japanese text, with Grand Master Challenge's backdrop fixes
  - The existing fighters play exactly as in Japan's Super Turbo

BUILDS IN THIS DOWNLOAD

    usa        USA (English)
    japan      Japan (Japanese)

HOW TO APPLY (recommended)

    python3 apply.py /path/to/ssf2xj.zip --out-dir out

This checks every file against the original, applies the patches, checks
the result, and writes everything you need for every build (add
--variant <build> to make just one):

  USA (English):
    MAME / original hardware: out/mame/usa/ssf2xj.zip
    HBMAME:                   out/hbmame/ssf2tuc.zip
    MiSTer:                   out/mister/_Arcade/_Arcade Patches/_Enhanced Versions/Super Street Fighter II EX (USA).mra
                              out/mister/games/hbmame/ssf2tuc.zip
  Japan (Japanese):
    MAME / original hardware: out/mame/japan/ssf2xj.zip
    HBMAME:                   out/hbmame/ssf2xuc.zip
    MiSTer:                   out/mister/_Arcade/_Arcade Patches/_Enhanced Versions/_Japan/Super Street Fighter II EX (Japan).mra
                              out/mister/games/hbmame/ssf2xuc.zip

MAME: put ssf2xj.zip from out/mame/ ahead of the stock set in your MAME
rompath (one build at a time: they share the set name).
MAME reports checksum warnings for the patched ROMs; that's expected and
the game runs normally. The same files can be burned for an original board.

HBMAME: the set definition (ssf2tuc, ssf2xuc) ships with the project;
an upstream HBMAME submission is pending.
Put the zip in HBMAME's roms/ folder next to your stock ssf2xj.zip.
It loads with no checksum warnings.

MiSTer: copy the _Arcade folder from out/mister/ to the root of your SD card
and keep the stock, unmodified romset at games/mame/ssf2xj.zip (split MAME
sets also need qsound.zip). The MRA applies the edition in memory as the
game loads, so nothing on the card is modified. You need Jotego's jtcps2
core, which update_all installs. The MRAs are also a separate download.

out/mister/ also holds the HBMAME set in games/hbmame/. This MRA doesn't use
it, but the CPS+ Arrange and HD Remix MRAs load it: if you use CPS+, copy
the games folder from out/mister/ to the card as well.

HOW TO APPLY (any IPS patcher)

Extract ssf2xj.zip, apply each file in ips/<build>/ to the ROM file of the
same name (Flips, Lunar IPS, or any IPS tool), then re-zip everything
as ssf2xj.zip.

CHANGED FILES

  USA (English) (--variant usa):
    sfx.13m  (2.0 MB)  CRC32 cf94d275 -> 438dbbdf
    sfx.14m  (1.0 MB)  CRC32 b7cc32e7 -> 1a6e6aa9
    sfx.15m  (2.0 MB)  CRC32 5eb703af -> 38b5b44c
    sfx.16m  (1.0 MB)  CRC32 8376ad18 -> 0f6251bd
    sfx.17m  (2.0 MB)  CRC32 ffa60e0f -> 6812d6a5
    sfx.18m  (1.0 MB)  CRC32 f5b1b336 -> 8b1eccaf
    sfx.19m  (2.0 MB)  CRC32 34e825c5 -> 784795aa
    sfx.20m  (1.0 MB)  CRC32 459d5c6b -> 26eb0233
    sfx.21m  (1.0 MB)  CRC32 e32854af -> 94b141da
    sfx.23m  (1.0 MB)  CRC32 760f2927 -> 359e2c32
    sfx.25m  (1.0 MB)  CRC32 1ee90208 -> 99008d5f
    sfx.27m  (1.0 MB)  CRC32 f814400f -> 164bbf8b
    sfxj.03d  (512 KB)  CRC32 50b52b37 -> a2d97153
    sfxj.04a  (512 KB)  CRC32 af7767b4 -> 45b204e6
    sfxj.05  (512 KB)  CRC32 f4ff18f5 -> 477b0a5e
    sfxj.06b  (512 KB)  CRC32 413477c2 -> f4d71289
    sfxj.07a  (512 KB)  CRC32 a18b3d83 -> 890e641d
    sfxj.08  (512 KB)  CRC32 2de76f10 -> ea0d1d90

  Japan (Japanese) (--variant japan):
    sfx.13m  (2.0 MB)  CRC32 cf94d275 -> f9c3a941
    sfx.14m  (1.0 MB)  CRC32 b7cc32e7 -> 1a6e6aa9
    sfx.15m  (2.0 MB)  CRC32 5eb703af -> e2de77da
    sfx.16m  (1.0 MB)  CRC32 8376ad18 -> 0f6251bd
    sfx.17m  (2.0 MB)  CRC32 ffa60e0f -> 287e2aac
    sfx.18m  (1.0 MB)  CRC32 f5b1b336 -> 8b1eccaf
    sfx.19m  (2.0 MB)  CRC32 34e825c5 -> 5f0aefbc
    sfx.20m  (1.0 MB)  CRC32 459d5c6b -> 26eb0233
    sfx.21m  (1.0 MB)  CRC32 e32854af -> 94b141da
    sfx.23m  (1.0 MB)  CRC32 760f2927 -> 359e2c32
    sfx.25m  (1.0 MB)  CRC32 1ee90208 -> 99008d5f
    sfx.27m  (1.0 MB)  CRC32 f814400f -> 164bbf8b
    sfxj.03d  (512 KB)  CRC32 50b52b37 -> 27c7261d
    sfxj.04a  (512 KB)  CRC32 af7767b4 -> 6cd52f68
    sfxj.05  (512 KB)  CRC32 f4ff18f5 -> 477b0a5e
    sfxj.06b  (512 KB)  CRC32 413477c2 -> c1066cb1
    sfxj.07a  (512 KB)  CRC32 a18b3d83 -> 890e641d
    sfxj.08  (512 KB)  CRC32 2de76f10 -> ea0d1d90

All other files in the set are unmodified.

LEGAL

This is a free, unofficial fan patch. It is not affiliated with or endorsed
by Capcom. All game titles, characters, and artwork remain the property of
their respective owners. You must own the game to use this patch. Do not
sell this patch or distribute it applied to a ROM image.
