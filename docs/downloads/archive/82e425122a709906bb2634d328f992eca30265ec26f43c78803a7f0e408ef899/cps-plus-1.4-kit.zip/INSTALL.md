# CPS+ — MiSTer installation

Run the pack builder first (see `README.txt`; the X68000 MIDI packs need
the extra toolchain described in `X68000.md`), then copy everything inside
`out/mister/` to the root of your MiSTer SD card (`/media/fat/`), merging
with what is already there.

```
out/mister/
  _Arcade/
    _Arcade Patches/
      _Arrangements/
        _CPS+/           MRAs: USA editions at the root, regional
                         variants under _Japan/ _Asia/ _Europe/.  The
                         LEADING UNDERSCORE is required for MiSTer to show
                         each folder as an arcade group.  Every project from
                         this site lives under _Arcade Patches, so you can
                         find (or remove) all of it in one place.
    cores/
      jtcps1-cpsplus.rbf       CPS-1.0 core
      jtcps15-cpsplus.rbf      CPS-1.5 core
      jtcps2-cpsplus.rbf       CPS-2 core
  games/
    CPS+/                the audio packs you built (`<pack>.zip`)
```

Earlier CPS+ releases put the MRAs in `_Arcade/_CPS+`; delete that folder
when you copy the new ones over.

Only the MRAs whose packs you built are placed here, so everything in the
folder will load. The rest stay in `builder/mras/` and appear the next time
you run the builder with their pack built.

Keep the RBF filenames as they are. The MRAs name their core, and a renamed
core stops resolving.

Your arcade ROM zips go where they always do (`games/mame/`,
`games/hbmame/`). The MRAs reference them by standard MAME names.

## Verifying a pack is active

Load a CPS+ MRA and check the core's OSD. The CPS+ audio section shows the
loaded pack.
