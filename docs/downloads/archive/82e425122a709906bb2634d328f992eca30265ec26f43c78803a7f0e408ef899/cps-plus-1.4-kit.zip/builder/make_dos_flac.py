#!/usr/bin/env python3
"""Render one MS-DOS Super Street Fighter II Turbo soundtrack to FLAC, from a
copy of the game you own.

The DOS release (GameTek/Eurocom 1995) shipped its score on FOUR carriers, and
they sound nothing alike, so each one is its own pack.  This is the kit-side
driver for all four; make_packs.py calls it before build_pack.py, and you can
also run it by hand.  It chains the tools in tools/:

  fm    the game's own OPL3 chiptune.  bnk2wopl.py converts the disc's own
        DRV/MELODIC.BNK and DRV/DRUM.BNK -- so the timbres are the game's,
        not a generic substitute -- and render_dos_opl.py plays the `_F`
        sequences through Nuked OPL3 at the chip's own 49716 Hz.
        Needs git, cmake and a C/C++ compiler; the renderer builds itself.
  sc55  render_dos_midi.py plays the `_G` sequences through the Nuked-SC55
        emulation.  Needs your own SC-55 ROM dump (--sc55-rom-dir).
  mt32  render_dos_mt32.py plays the `_M` sequences through Munt.  Needs your
        own MT-32 ROM dump (--mt32-rom-dir).
  cd    the disc's Red Book audio, extracted with extract_cdda.py and cut
        into pieces by slice_dos_cd.py.  No renderer, no ROMs, and by far the
        fastest of the four.

Nothing is downloaded except the pinned open-source renderer repositories.
Game data and synthesizer firmware are never fetched, and the renders stay
under work/ on your machine.

Usage:
  python3 make_dos_flac.py --device sc55 --archive /dos/ssf2t_cd.zip \\
      --sc55-rom-dir /roms/sc55 [--work DIR] [--keep-wav]

The last line printed is the directory holding the finished FLACs.
"""
from __future__ import annotations

import argparse
import os
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path

# abspath, not resolve(): on Windows resolve() turns a mapped drive into \\server\share
HERE = Path(os.path.abspath(__file__)).parent
TOOLS = HERE / "tools"
sys.path.insert(0, str(TOOLS))

from setup_x68k_music_tools import find_binary  # noqa: E402

MANIFESTS = HERE / "manifests"
MAP_TSV = MANIFESTS / "ssf2t_dos_map.tsv"
CD_TRACKS_TSV = MANIFESTS / "ssf2t_dos_cd_tracks.tsv"

# libADLMIDI is a shared library rather than an executable, so find_binary
# does not apply and the extension is per-platform.
ADLMIDI_NAMES = ("libADLMIDI.dylib", "libADLMIDI.so", "ADLMIDI.dll",
                 "libADLMIDI.dll")


def find_adlmidi(root: Path) -> Path | None:
    build = root / "libADLMIDI" / "build"
    for name in ADLMIDI_NAMES:
        for cand in (build / name, build / "bin" / name, build / "lib" / name):
            if cand.is_file():
                return cand
    for name in ADLMIDI_NAMES:
        hit = next(iter(sorted(build.rglob(name))), None) if build.is_dir() else None
        if hit:
            return hit
    return None

# device: (title, sequence letter, ROM option it needs)
DEVICES = {
    "fm": ("OPL3 chiptune", "F", None),
    "sc55": ("Roland Sound Canvas", "G", "sc55_rom_dir"),
    "mt32": ("Roland MT-32", "M", "mt32_rom_dir"),
    "cd": ("Red Book CD audio", "", None),
}


def run(argv: list) -> None:
    print("+ " + " ".join(str(a) for a in argv), flush=True)
    r = subprocess.run([str(a) for a in argv])
    if r.returncode:
        sys.exit(f"step failed ({r.returncode}); see the message above")


def need(binary: str, why: str) -> None:
    if shutil.which(binary) is None:
        sys.exit(f"{binary} is not on PATH; it is needed to {why}")


def source_name(stem: str, letter: str) -> str:
    """The rendered file's stem for a map entry on a given device.

    The disc infixes KO for a critical variant rather than suffixing it:
    base CHUN is CHUN_G, its critical variant CHUN_KOG.  Kept identical to
    pack/build_ssf2t_dos.py, which reads what this writes.
    """
    if not letter:
        return stem
    return f"{stem}{letter}" if stem.endswith("_KO") else f"{stem}_{letter}"


def _rows(path: Path) -> list[list[str]]:
    if not path.is_file():
        sys.exit(f"missing {path}")
    out = []
    for line in path.read_text(encoding="utf-8").splitlines():
        if line and not line.startswith("#"):
            out.append(line.split("\t"))
    return out[1:] if out else []            # drop the header


def wanted_songs(device: str, letter: str) -> list[str]:
    """Every file the pack builder will look for on this device.

    The command map is the authority for the three SYNTH devices: each maps
    one stem per command.  It is NOT the authority for the CD, which carries
    less than the sequences do -- HI_SCO and VERS have no CD source at all
    and fail open by design, which is why that pack has 54 tracks where the
    others have 56.  So the CD's expectation comes from its own cut list,
    where a `base+critical` track yields two pieces.
    """
    if device == "cd":
        want = set()
        for cols in _rows(CD_TRACKS_TSV):
            if len(cols) < 4:
                continue
            stem, half = cols[2].strip(), cols[3].strip()
            if not stem or stem == "-":
                continue
            want.add(stem)
            if half == "base+critical":
                want.add(f"{stem}_KO")
        return sorted(want)
    stems = [cols[2].strip() for cols in _rows(MAP_TSV)
             if len(cols) >= 3 and cols[2].strip() and cols[2].strip() != "-"]
    return sorted({source_name(s, letter) for s in stems})


def flac_ready(flac_dir: Path, songs: list[str]) -> bool:
    return flac_dir.is_dir() and all((flac_dir / f"{s}.flac").is_file()
                                     for s in songs)


def unpack(archive: Path, dest: Path) -> Path:
    """Unpack the game archive once; returns the folder it landed in."""
    if archive.is_dir():
        return archive
    stamp = dest / ".unpacked"
    if stamp.is_file() and stamp.read_text(encoding="utf-8").strip() == archive.name:
        return dest
    if dest.exists():
        shutil.rmtree(dest, ignore_errors=True)
    dest.mkdir(parents=True, exist_ok=True)
    suffix = archive.suffix.lower()
    print(f"unpacking {archive.name}", flush=True)
    if suffix == ".zip":
        with zipfile.ZipFile(archive) as z:
            z.extractall(dest)
    elif suffix == ".7z":
        exe = shutil.which("7zz") or shutil.which("7z")
        if exe is None:
            sys.exit(f"{archive.name} is a .7z; install 7-Zip (7zz/7z on "
                     "PATH) or repack it as a .zip")
        run([exe, "x", "-y", f"-o{dest}", archive])
    else:
        sys.exit(f"{archive.name}: expected a folder, a .zip or a .7z")
    stamp.write_text(archive.name, encoding="utf-8")
    return dest


def find_dir(root: Path, name: str, holding: str) -> Path | None:
    """The disc keeps the game's folders under GAMETEK/SSF2T/, but a rip may
    be rooted anywhere, so look rather than assume.  A name alone is not
    enough: the disc also carries ULTRASND/MIDI/, the Gravis config folder,
    which holds no sequences and sits shallower than the real one -- so the
    folder must actually contain what we came for."""
    cands = [root] if root.name.upper() == name else []
    cands += [p for p in root.rglob("*") if p.is_dir() and p.name.upper() == name]
    hits = sorted((p for p in cands if any(p.glob(holding))),
                  key=lambda p: len(p.parts))
    return hits[0] if hits else None


def find_cue(root: Path) -> Path | None:
    hits = sorted(root.rglob("*.cue"), key=lambda p: len(p.parts))
    return hits[0] if hits else None


def main() -> int:
    ap = argparse.ArgumentParser(
        description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--device", required=True, choices=sorted(DEVICES))
    ap.add_argument("--archive", required=True, type=Path,
                    help="the game as a folder, .zip or .7z")
    ap.add_argument("--sc55-rom-dir", type=Path,
                    help="directory holding your SC-55 v1.21 ROM dump")
    ap.add_argument("--mt32-rom-dir", type=Path,
                    help="directory holding your MT-32 ROM dump")
    ap.add_argument("--work", type=Path, default=HERE / "work" / "dos",
                    help="work directory (default: builder/work/dos)")
    ap.add_argument("--keep-wav", action="store_true",
                    help="keep the raw CD extraction after the FLAC export")
    a = ap.parse_args()

    title, letter, rom_opt = DEVICES[a.device]
    songs = wanted_songs(a.device, letter)
    work = Path(os.path.abspath(a.work.expanduser()))
    upstream = work / "upstream"
    flac_dir = work / "flac" / a.device

    if flac_ready(flac_dir, songs):
        print(f"{title}: {len(songs)} FLACs already rendered, reusing {flac_dir}")
        print(flac_dir)
        return 0

    archive = Path(os.path.abspath(a.archive.expanduser()))
    if not archive.exists():
        sys.exit(f"not found: {archive}")
    need("ffmpeg", "write the FLAC files")
    need("ffprobe", "verify the FLAC files")

    root = unpack(archive, work / "game")
    midi_dir = find_dir(root, "MIDI", "*.HMP")
    if midi_dir is None:
        sys.exit(f"{archive.name} has no MIDI/ folder of .HMP sequences -- is this the MS-DOS "
                 f"Super Street Fighter II Turbo release?")

    if rom_opt:
        given = a.sc55_rom_dir if a.device == "sc55" else a.mt32_rom_dir
        if given is None:
            sys.exit(f"--{rom_opt.replace('_', '-')} is required for {a.device}")
        rom_dir = Path(os.path.abspath(given.expanduser()))
        if not rom_dir.is_dir():
            sys.exit(f"ROM directory not found: {rom_dir}")
    else:
        rom_dir = None

    flac_dir.mkdir(parents=True, exist_ok=True)

    if a.device == "cd":
        cue = find_cue(root)
        if cue is None:
            sys.exit(f"{archive.name} has no .cue holding the Red Book audio")
        cdda = work / "cdda"
        print(f"\n== {title}: extracting the Red Book audio from {cue.name}")
        run([sys.executable, TOOLS / "extract_cdda.py", cue, cdda])
        print(f"\n== {title}: cutting the tracks into their pieces")
        run([sys.executable, TOOLS / "slice_dos_cd.py", cdda,
             "--out-dir", flac_dir, "--map", MANIFESTS / "ssf2t_dos_cd_tracks.tsv"])
        if not a.keep_wav:
            freed = sum(w.stat().st_size for w in cdda.glob("*.wav"))
            shutil.rmtree(cdda, ignore_errors=True)
            if freed:
                print(f"removed the raw extraction ({freed / 1e9:.1f} GB)")
    else:
        need("git", "fetch the pinned open-source renderer")
        need("cmake", "build the pinned open-source renderer")
        if a.device == "fm":
            lib = find_adlmidi(upstream)
            if lib is None:
                print(f"\n== {title}: building the OPL3 renderer (one-time)")
                run([sys.executable, TOOLS / "setup_dos_opl_tools.py",
                     "--root", upstream])
                lib = find_adlmidi(upstream)
            if lib is None:
                sys.exit("libADLMIDI was not found after the build")
            drv = find_dir(root, "DRV", "*.BNK")
            if drv is None:
                sys.exit("no DRV/ folder holding MELODIC.BNK and DRUM.BNK")
            bank = work / "ssf2t_dos.wopl"
            print(f"\n== {title}: converting the disc's own OPL banks")
            run([sys.executable, TOOLS / "bnk2wopl.py",
                 "--melodic", drv / "MELODIC.BNK", "--drum", drv / "DRUM.BNK",
                 "--out", bank])
            print(f"\n== {title}: rendering {len(songs)} songs through Nuked OPL3")
            run([sys.executable, TOOLS / "render_dos_opl.py", midi_dir,
                 "--bank", bank, "--out-dir", flac_dir, "--library", lib])
        elif a.device == "sc55":
            build = upstream / "Nuked-SC55-GUI-Float" / "build"
            renderer = find_binary(build, "nuked-sc55-render")
            if renderer is None:
                print(f"\n== {title}: building the SC-55 renderer (one-time)")
                run([sys.executable, TOOLS / "setup_x68k_capture_tools.py",
                     "--root", upstream])
                renderer = find_binary(build, "nuked-sc55-render")
            if renderer is None:
                sys.exit("nuked-sc55-render was not found after the build")
            print(f"\n== {title}: rendering {len(songs)} songs through the SC-55 "
                  f"(this is the slow part)")
            run([sys.executable, TOOLS / "render_dos_midi.py", midi_dir,
                 "--out-dir", flac_dir, "--renderer", renderer, "--roms", rom_dir])
        else:
            build = upstream / "munt" / "build"
            renderer = find_binary(build, "mt32emu-smf2wav")
            if renderer is None:
                print(f"\n== {title}: building the MT-32 renderer (one-time)")
                run([sys.executable, TOOLS / "setup_x68k_mt32_tools.py",
                     "--root", upstream])
                renderer = find_binary(build, "mt32emu-smf2wav")
            if renderer is None:
                sys.exit("mt32emu-smf2wav was not found after the build")
            print(f"\n== {title}: rendering {len(songs)} songs through Munt "
                  f"(this is the slow part)")
            run([sys.executable, TOOLS / "render_dos_mt32.py", midi_dir,
                 "--out-dir", flac_dir, "--renderer", renderer, "--roms", rom_dir])

    missing = [s for s in songs if not (flac_dir / f"{s}.flac").is_file()]
    if missing:
        sys.exit(f"{title}: {len(missing)} of {len(songs)} renders are missing, "
                 f"first: {missing[0]}.flac in {flac_dir}")
    print(f"\n{title}: {len(songs)} FLACs ready")
    print(flac_dir)
    return 0


if __name__ == "__main__":
    sys.exit(main())
