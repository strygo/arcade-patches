#!/usr/bin/env python3
"""Fetch and build the pinned headless Munt MT-32 renderer.

Third-party source and binaries are kept below
``work/x68000/upstream`` and remain untracked.  MT-32 firmware is not
downloaded by this command; put a legally obtained ROM set in ``roms/mt32``.
"""
from __future__ import annotations

import argparse
import shutil
import subprocess
import sys
from pathlib import Path


class SetupError(RuntimeError):
    pass


MUNT_REPOSITORY = "https://github.com/munt/munt.git"
MUNT_COMMIT = "3b05ec276f9e605af86b0eaef7f5eda43477a31f"
MUNT_RELEASE = "munt_2_8_2"


def _run(command: list[str], cwd: Path | None = None) -> str:
    result = subprocess.run(command, cwd=cwd, text=True, capture_output=True)
    if result.returncode:
        details = "\n".join(part for part in (result.stdout, result.stderr) if part)
        raise SetupError(
            f"command failed ({result.returncode}): {' '.join(command)}\n{details}"
        )
    return result.stdout.strip()


def _checkout(path: Path) -> None:
    if not path.exists():
        _run(["git", "clone", "--no-checkout", MUNT_REPOSITORY, str(path)])
        _run(["git", "checkout", "--detach", MUNT_COMMIT], path)
    elif not (path / ".git").is_dir():
        raise SetupError(f"existing path is not a Git checkout: {path}")
    head = _run(["git", "rev-parse", "HEAD"], path)
    if head != MUNT_COMMIT:
        raise SetupError(
            f"{path} is at {head}, expected {MUNT_COMMIT}; move it aside rather "
            "than having this setup command overwrite it"
        )
    dirty = _run(["git", "status", "--porcelain", "--untracked-files=no"], path)
    if dirty:
        raise SetupError(f"tracked files are modified in {path}; move it aside")


def _generator(build: Path) -> list[str]:
    if (build / "CMakeCache.txt").is_file():
        return []
    return ["-G", "Ninja"] if shutil.which("ninja") else []


def setup(root: Path) -> Path:
    root.mkdir(parents=True, exist_ok=True)
    munt = root / "munt"
    _checkout(munt)
    build = munt / "build"
    _run([
        "cmake", "-S", str(munt), "-B", str(build),
        *_generator(build),
        "-DCMAKE_BUILD_TYPE=Release",
        "-DBUILD_SHARED_LIBS=OFF",
        "-Dmunt_WITH_MT32EMU_SMF2WAV=ON",
        "-Dmunt_WITH_MT32EMU_QT=OFF",
    ])
    _run([
        "cmake", "--build", str(build), "--target", "mt32emu-smf2wav"
    ])
    renderer = build / "mt32emu_smf2wav" / "mt32emu-smf2wav"
    if not renderer.is_file():
        raise SetupError(f"build succeeded but {renderer} is missing")
    help_text = _run([str(renderer), "--help"])
    identity = [
        line for line in help_text.splitlines()
        if line.startswith("Munt MT32Emu") or line.startswith("Using Munt ")
    ]
    print(f"ready: {renderer}\n" + "\n".join(identity))
    return renderer


def self_test() -> None:
    assert len(MUNT_COMMIT) == 40
    assert MUNT_REPOSITORY.startswith("https://github.com/")
    assert MUNT_RELEASE.startswith("munt_")
    print("setup_x68k_mt32_tools self-test: OK")


def main(argv: list[str] | None = None) -> int:
    repo = Path(__file__).resolve().parents[2]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--self-test", action="store_true")
    parser.add_argument(
        "--root", type=Path,
        default=repo / "cpsplus" / "work" / "x68000" / "upstream",
    )
    args = parser.parse_args(argv)
    if args.self_test:
        self_test()
        return 0
    setup(args.root)
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (OSError, SetupError) as exc:
        print(f"setup_x68k_mt32_tools: error: {exc}", file=sys.stderr)
        raise SystemExit(1)
