#!/usr/bin/env python3
"""Render the MS-DOS SSF2T `_M` sequences on a pinned Munt MT-32 as FLAC.

The `_M` set is genuinely MT-32 material, not a relabelled GM one: its program
changes are MT-32 patch numbers.  CHUN's channels 0/1/2 ask for 97/72/59 where
the `_G` variant asks for 11/73/25, so playing `_M` on a Sound Canvas picks
entirely different instruments, the same failure the X68000 MIDI work already
ran into for Final Fight.  Nuked-SC55 has no MT-32 romset at all, so Munt it is.

Chain:

  hmp2smf (MT-32 reset + 6 s settle, loop unrolled one pass)
    -> mt32emu-smf2wav, ROMs pinned by sha256
    -> drop the settle window
    -> truncate at LOOPEND
    -> FLAC + LOOPSTART / LOOPEND / LOOPLENGTH

Nothing is resampled: Munt is asked for 48 kHz directly and the pack takes
48 kHz tracks.  The emulator settings are `render_x68k_mt32.py`'s, reused
verbatim rather than re-chosen -- same machine (mt32_1_07), same analog output
mode, DAC input mode, renderer type and partial limit -- so the two MT-32 packs
in this repo come off the same configuration.

usage:
  render_dos_mt32.py MIDI_DIR --out-dir DIR [--songs CHUN_M ...]
"""
from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
import sys
import tempfile
import wave
from pathlib import Path

import numpy as np

TOOLS = Path(__file__).resolve().parent
REPO = TOOLS.parent.parent
sys.path.insert(0, str(TOOLS))

import hmp as hmp_mod                                   # noqa: E402
from hmp2smf import device_for                          # noqa: E402

OUTPUT_RATE = 48_000
CHANNELS = 2
UNROLL_PASSES = 1
STEADY_PASS = 1
ONESHOT_TAIL_SECONDS = 3.0

# render_x68k_mt32.py's default machine and its DAC input mode.  1.xx firmware
# is the early MT-32 hardware; 2.xx routes LA32 to the DAC differently.
MACHINE_ID = "mt32_1_07"
CONTROL_ROM = "mt32_ctrl_1_07.rom"
PCM_ROM = "mt32_pcm.rom"
DAC_INPUT_MODE = "2"

DEFAULT_RENDERER = (REPO / "cpsplus" / "work" / "x68000" / "upstream" / "munt"
                    / "build" / "mt32emu_smf2wav" / "mt32emu-smf2wav")
DEFAULT_ROMS = REPO / "roms" / "mt32" / "versions"


class RenderError(RuntimeError):
    pass


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def check_roms(roms: Path) -> dict[str, str]:
    """The firmware this render used, by digest.

    The digests are recorded rather than pinned to constants: unlike the
    Nuked-SC55 set, whose hashes ship with the renderer's own integration
    tests, these come from the user's own dump.  Recording them still makes a
    later render's drift visible.
    """
    digests = {}
    for name in (CONTROL_ROM, PCM_ROM):
        path = roms / name
        if not path.is_file():
            raise RenderError(f"missing MT-32 firmware: {path}")
        digests[name] = _sha256(path)
    return digests


def render_wav(renderer: Path, roms: Path, midi: Path) -> np.ndarray:
    with tempfile.TemporaryDirectory() as tmp:
        out = Path(tmp) / "out.wav"
        proc = subprocess.run(
            [str(renderer), "--force", "--quiet",
             f"--rom-dir={roms.resolve()}",
             f"--machine-id={MACHINE_ID}",
             f"--sample-rate={OUTPUT_RATE}",
             "--src-quality=3",
             "--max-partials=32",
             "--analog-output-mode=2",
             "--renderer-type=0",
             "--output-sample-format=0",
             f"--dac-input-mode={DAC_INPUT_MODE}",
             "--no-nice-amp-ramp",
             "--record-max-start-silence=-1",
             "--no-wait-for-la32",
             f"--output={out}", str(midi.resolve())],
            capture_output=True, check=False)
        if proc.returncode != 0 or not out.is_file():
            raise RenderError(
                f"{midi.name}: mt32emu-smf2wav exited {proc.returncode}: "
                f"{proc.stderr.decode(errors='replace')[-400:]}")
        with wave.open(str(out)) as handle:
            if (handle.getframerate(), handle.getnchannels(),
                    handle.getsampwidth()) != (OUTPUT_RATE, CHANNELS, 2):
                raise RenderError(
                    f"{midi.name}: unexpected output format "
                    f"{handle.getframerate()} Hz / {handle.getnchannels()}ch / "
                    f"{handle.getsampwidth() * 8}-bit")
            frames = handle.readframes(handle.getnframes())
    return np.frombuffer(frames, dtype="<i2").reshape(-1, CHANNELS)


def write_flac(pcm: np.ndarray, dest: Path, tags: dict[str, int]) -> None:
    args = ["ffmpeg", "-hide_banner", "-loglevel", "error", "-y",
            "-f", "s16le", "-ar", str(OUTPUT_RATE), "-ac", str(CHANNELS),
            "-i", "pipe:0", "-c:a", "flac"]
    for key, value in tags.items():
        args += ["-metadata", f"{key}={value}"]
    args.append(str(dest))
    proc = subprocess.run(args, input=pcm.tobytes(), capture_output=True)
    if proc.returncode != 0:
        raise RenderError(f"{dest.name}: ffmpeg exited {proc.returncode}: "
                          f"{proc.stderr.decode(errors='replace')[-400:]}")


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("midi_dir", help="directory of .HMP files")
    ap.add_argument("--out-dir", required=True)
    ap.add_argument("--songs", nargs="*", help="stems to render (default: all _M)")
    ap.add_argument("--renderer", type=Path, default=DEFAULT_RENDERER)
    ap.add_argument("--roms", type=Path, default=DEFAULT_ROMS)
    a = ap.parse_args(argv)

    if not a.renderer.is_file():
        raise SystemExit(f"renderer not built: {a.renderer}\n"
                         "build it with tools/setup_x68k_mt32_tools.py")
    firmware = check_roms(a.roms)

    midi_dir = Path(a.midi_dir)
    out_dir = Path(a.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    smf_dir = out_dir / "smf"
    smf_dir.mkdir(exist_ok=True)

    stems = a.songs or sorted(p.stem for p in midi_dir.iterdir()
                              if p.suffix.upper() == ".HMP"
                              and device_for(p.stem) == "mt32")
    report = []
    for stem in stems:
        song = hmp_mod.parse(midi_dir / f"{stem}.HMP")
        if device_for(stem) != "mt32":
            raise SystemExit(f"{stem}: not an MT-32 sequence")
        loop = hmp_mod.loop_samples(song, OUTPUT_RATE, reset="mt32",
                                    pass_index=STEADY_PASS)
        smf = smf_dir / f"{stem}.mid"
        smf.write_bytes(hmp_mod.to_smf(
            song, reset="mt32", unroll_passes=UNROLL_PASSES,
            tail_seconds=0.0 if loop is not None else ONESHOT_TAIL_SECONDS))

        pcm = render_wav(a.renderer, a.roms, smf)
        trim = round(hmp_mod.SETTLE_SECONDS["mt32"] * OUTPUT_RATE)
        if len(pcm) <= trim:
            raise RenderError(f"{stem}: render is shorter than the settle window")
        pcm = pcm[trim:]

        tags: dict[str, int] = {}
        if loop is not None:
            start, end = loop[0] - trim, loop[1] - trim
            if start <= OUTPUT_RATE:
                raise RenderError(
                    f"{stem}: loop starts {start} samples in, too early to "
                    "leave a one-second crossfade tail before it")
            if end > len(pcm):
                raise RenderError(
                    f"{stem}: loop ends at {end} but the render is only "
                    f"{len(pcm)} frames")
            pcm = pcm[:end]
            tags = {"LOOPSTART": start, "LOOPEND": end,
                    "LOOPLENGTH": end - start}

        dest = out_dir / f"{stem}.flac"
        write_flac(pcm, dest, tags)
        kind = (f"loop {tags['LOOPSTART']}..{tags['LOOPEND']}"
                if tags else "one-shot")
        print(f"{stem:12s} {len(pcm) / OUTPUT_RATE:7.2f}s  "
              f"{dest.stat().st_size / 1e6:6.2f} MB  {kind}")
        report.append({"song": stem, "frames": int(len(pcm)), "tags": tags,
                       "sha256": _sha256(dest)})

    (out_dir / "render_report.json").write_text(
        json.dumps({"renderer_sha256": _sha256(a.renderer),
                    "machine_id": MACHINE_ID, "firmware": firmware,
                    "rate": OUTPUT_RATE, "songs": report}, indent=2),
        encoding="utf-8")
    print(f"\n{len(report)} songs -> {out_dir}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
