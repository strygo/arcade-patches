#!/usr/bin/env python3
"""Render the MS-DOS SSF2T `_F` sequences on Nuked OPL3 as loop-tagged FLAC.

The `_F` set is the disc's AdLib path (`sb16/HMISET.CFG`, MIDI at port 0x388),
and it is NOT the `_G` set with different patches: six songs carry different
loop ticks in the OPL variant and their program changes differ throughout, so
this is a separately authored arrangement and gets its own pack.

Chain:

  hmp2smf (no device reset -- OPL needs none, loop unrolled one pass)
    -> libADLMIDI through ctypes, at the chip's OWN 49716 Hz
       * Nuked OPL3, the accurate core
       * ONE chip: a Sound Blaster 16 has one OPL3, and libADLMIDI would
         otherwise extend polyphony past what the hardware could do
       * volume model "HMI Sound Operating System" -- this disc's own driver
       * the disc's own MELODIC.BNK + DRUM.BNK, via tools/bnk2wopl.py
    -> truncate at LOOPEND
    -> FLAC + LOOPSTART / LOOPEND / LOOPLENGTH

Nothing is resampled anywhere, which is the point of the odd rate (see
OUTPUT_RATE).  Rendering at 44.1 kHz instead -- the demo player's hardcoded
default, and what this tool did first -- puts libADLMIDI's fallback linear
interpolator in the path and measurably costs the top end: on CHUN_F the
spectral centroid drops from 3504 to 2859 Hz and energy above 15 kHz from
7.19% to 4.35%, and the loop seam falls from 0.94 to 0.90.

Loop tags name the SECOND pass, as in `render_dos_midi.py`; see
`hmp.loop_samples` for why.  Measured on CHUN_F: the second before LOOPSTART
and the second before LOOPEND correlate 0.941 spectrally against a 0.183
control.  An earlier offset sweep, run when this tool still shelled out to the
demo player, confirmed the loop positions land where the sequence says -- that
player appended about a second of tail past the last event but added no
lead-in.  Driving the library directly, the render ends on the last event.

usage:
  render_dos_opl.py MIDI_DIR --bank ssf2t_dos.wopl --out-dir DIR [--songs ...]
"""
from __future__ import annotations

import argparse
import ctypes
import hashlib
import json
import subprocess
import sys
from pathlib import Path

import numpy as np

TOOLS = Path(__file__).resolve().parent
REPO = TOOLS.parent.parent
sys.path.insert(0, str(TOOLS))

import hmp as hmp_mod                                   # noqa: E402
from hmp2smf import device_for                          # noqa: E402

# The OPL3's OWN rate.  libADLMIDI generates at 49716 Hz and resamples to
# whatever is asked for; ask for 49716 and rateratio is exactly 1.0, so its
# interpolation weights are 0 and 1 and every native sample passes through
# untouched.  Any other rate goes through plain linear interpolation (the HQ
# VResampler needs zita-resampler, which we do not depend on), which aliases
# audibly on bright FM -- so this rate is not a preference, it is the only one
# that costs nothing.  The pack format carries the rate per track and the
# core's frac-cen follows it; spf2t already ships at 37800 Hz.
OUTPUT_RATE = 49_716
CHANNELS = 2
UNROLL_PASSES = 1
STEADY_PASS = 1
ONESHOT_TAIL_SECONDS = 3.0
CHIPS = 1                     # a real SB16 has one OPL3
FOUR_OPS = 0                  # the disc's banks are two-operator throughout

DEFAULT_LIBRARY = (REPO / "cpsplus" / "work" / "dos" / "upstream"
                   / "libADLMIDI" / "build" / "libADLMIDI.dylib")
ADLMIDI_VOLUME_MODEL_HMI = 10      # ADLMIDI_VolumeModel_HMI
ADLMIDI_EMU_NUKED = 0              # ADLMIDI_EMU_NUKED (OPL3 v1.8)


class RenderError(RuntimeError):
    pass


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def render_native(library: Path, bank: Path, midi: Path) -> np.ndarray:
    """libADLMIDI's output at the chip's own rate, shape (frames, 2).

    Driven through ctypes rather than the demo player, which hardcodes
    44.1 kHz with no way to change it.  Same pattern as `spc_render.py`.
    """
    adl = ctypes.CDLL(str(library))
    adl.adl_init.restype = ctypes.c_void_p
    adl.adl_init.argtypes = [ctypes.c_long]
    adl.adl_errorInfo.restype = ctypes.c_char_p
    adl.adl_errorInfo.argtypes = [ctypes.c_void_p]
    for name, args in (("adl_openBankFile", [ctypes.c_void_p, ctypes.c_char_p]),
                       ("adl_openFile", [ctypes.c_void_p, ctypes.c_char_p]),
                       ("adl_setNumChips", [ctypes.c_void_p, ctypes.c_int]),
                       ("adl_setVolumeRangeModel", [ctypes.c_void_p, ctypes.c_int]),
                       ("adl_switchEmulator", [ctypes.c_void_p, ctypes.c_int]),
                       ("adl_setNumFourOpsChn", [ctypes.c_void_p, ctypes.c_int]),
                       ("adl_setLoopEnabled", [ctypes.c_void_p, ctypes.c_int])):
        getattr(adl, name).argtypes = args
        getattr(adl, name).restype = ctypes.c_int
    adl.adl_play.argtypes = [ctypes.c_void_p, ctypes.c_int,
                             ctypes.POINTER(ctypes.c_short)]
    adl.adl_play.restype = ctypes.c_int
    adl.adl_close.argtypes = [ctypes.c_void_p]

    device = adl.adl_init(OUTPUT_RATE)
    if not device:
        raise RenderError("adl_init failed")
    try:
        def check(result: int, what: str) -> None:
            if result < 0:
                info = adl.adl_errorInfo(device)
                raise RenderError(
                    f"{midi.name}: {what}: "
                    f"{info.decode(errors='replace') if info else 'failed'}")

        check(adl.adl_switchEmulator(device, ADLMIDI_EMU_NUKED), "select Nuked OPL3")
        check(adl.adl_setNumChips(device, CHIPS), "set chip count")
        check(adl.adl_setNumFourOpsChn(device, FOUR_OPS), "set four-op channels")
        adl.adl_setVolumeRangeModel(device, ADLMIDI_VOLUME_MODEL_HMI)
        adl.adl_setLoopEnabled(device, 0)      # we unroll ourselves
        check(adl.adl_openBankFile(device, str(bank).encode()), "load the WOPL bank")
        check(adl.adl_openFile(device, str(midi).encode()), "load the MIDI")

        block = 4096                            # sample slots, i.e. 2048 frames
        buffer = (ctypes.c_short * block)()
        chunks: list[bytes] = []
        while True:
            got = adl.adl_play(device, block, buffer)
            if got <= 0:
                break
            chunks.append(bytes(buffer)[:got * 2])
    finally:
        adl.adl_close(device)

    audio = np.frombuffer(b"".join(chunks), dtype="<i2")
    if audio.size % CHANNELS:
        raise RenderError(f"{midi.name}: output ends mid-frame")
    if not audio.size:
        raise RenderError(f"{midi.name}: renderer produced no audio")
    return audio.reshape(-1, CHANNELS)


def write_flac(pcm: np.ndarray, dest: Path, tags: dict[str, int]) -> None:
    args = ["ffmpeg", "-hide_banner", "-loglevel", "error", "-y",
            "-f", "s16le", "-ar", str(OUTPUT_RATE), "-ac", str(CHANNELS),
            "-i", "pipe:0", "-c:a", "flac"]
    for key, value in tags.items():
        args += ["-metadata", f"{key}={value}"]
    args.append(str(dest))
    proc = subprocess.run(args, input=pcm.tobytes(), capture_output=True)
    if proc.returncode != 0:
        raise RenderError(f"{dest.name}: ffmpeg exited {proc.returncode}: "
                          f"{proc.stderr.decode(errors='replace')[-400:]}")


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("midi_dir", help="directory of .HMP files")
    ap.add_argument("--bank", required=True, type=Path,
                    help="WOPL bank from tools/bnk2wopl.py")
    ap.add_argument("--out-dir", required=True)
    ap.add_argument("--songs", nargs="*", help="stems to render (default: all _F)")
    ap.add_argument("--library", type=Path, default=DEFAULT_LIBRARY)
    a = ap.parse_args(argv)

    if not a.library.is_file():
        raise SystemExit(f"library not built: {a.library}\n"
                         "build it with tools/setup_dos_opl_tools.py")
    if not a.bank.is_file():
        raise SystemExit(f"missing WOPL bank: {a.bank}\n"
                         "make it with tools/bnk2wopl.py from the disc's "
                         "DRV/MELODIC.BNK and DRV/DRUM.BNK")

    midi_dir = Path(a.midi_dir)
    out_dir = Path(a.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    smf_dir = out_dir / "smf"
    smf_dir.mkdir(exist_ok=True)

    stems = a.songs or sorted(p.stem for p in midi_dir.iterdir()
                              if p.suffix.upper() == ".HMP"
                              and device_for(p.stem) == "none")
    report = []
    for stem in stems:
        song = hmp_mod.parse(midi_dir / f"{stem}.HMP")
        if device_for(stem) != "none":
            raise SystemExit(f"{stem}: not an OPL sequence")
        loop = hmp_mod.loop_samples(song, OUTPUT_RATE, reset="none",
                                    pass_index=STEADY_PASS)
        smf = smf_dir / f"{stem}.mid"
        smf.write_bytes(hmp_mod.to_smf(
            song, reset="none", unroll_passes=UNROLL_PASSES,
            tail_seconds=0.0 if loop is not None else ONESHOT_TAIL_SECONDS))

        pcm = render_native(a.library, a.bank, smf)
        tags: dict[str, int] = {}
        if loop is not None:
            start, end = loop
            if start <= OUTPUT_RATE:
                raise RenderError(
                    f"{stem}: loop starts {start} samples in, too early to "
                    "leave a one-second crossfade tail before it")
            if end > len(pcm):
                raise RenderError(
                    f"{stem}: loop ends at {end} but the render is only "
                    f"{len(pcm)} frames")
            pcm = pcm[:end]
            tags = {"LOOPSTART": start, "LOOPEND": end,
                    "LOOPLENGTH": end - start}

        dest = out_dir / f"{stem}.flac"
        write_flac(pcm, dest, tags)
        kind = (f"loop {tags['LOOPSTART']}..{tags['LOOPEND']}"
                if tags else "one-shot")
        print(f"{stem:12s} {len(pcm) / OUTPUT_RATE:7.2f}s  "
              f"{dest.stat().st_size / 1e6:6.2f} MB  {kind}")
        report.append({"song": stem, "frames": int(len(pcm)), "tags": tags,
                       "sha256": _sha256(dest)})

    (out_dir / "render_report.json").write_text(
        json.dumps({"library_sha256": _sha256(a.library),
                    "bank_sha256": _sha256(a.bank),
                    "emulator": "Nuked OPL3", "chips": CHIPS,
                    "volume_model": "HMI Sound Operating System",
                    # no gain is applied here: the pack builder sets the
                    # trigger gain, so the render is the chip's own level
                    "rate": OUTPUT_RATE, "songs": report},
                   indent=2), encoding="utf-8")
    print(f"\n{len(report)} songs -> {out_dir}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
