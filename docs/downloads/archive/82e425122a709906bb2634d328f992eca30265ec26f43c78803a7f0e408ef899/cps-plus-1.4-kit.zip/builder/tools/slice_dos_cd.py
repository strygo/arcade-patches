#!/usr/bin/env python3
"""Cut the MS-DOS SSF2T CD into one FLAC per musical piece.

The disc does not store one piece per track.  Each of the sixteen stage tracks
holds the base theme AND its critical variant back to back, separated by a
fade 25-35 dB down at around a minute in (measured; see
`manifests/ssf2t_dos_cd_tracks.tsv`).  Everything else -- endings, openers,
jingles -- is one piece per track.

So this splits the stage tracks in two and copies the rest through, naming
each output for the sequence stem it was identified as, which is what joins it
to an arcade command through `manifests/ssf2t_dos_map.tsv`.

The join is a FADE, not a gap, so both halves end with the level already
falling.  That matters downstream: a loop whose end sits inside a fade plays
its last second quieter than its first and the wrap dips.  Nothing here
trims it -- the loop authoring has to see where the fade starts.

usage:
  slice_dos_cd.py CDDA_DIR --out-dir DIR [--map manifests/ssf2t_dos_cd_tracks.tsv]
"""
from __future__ import annotations

import argparse
import csv
import subprocess
import sys
from pathlib import Path

REPO = Path(__file__).resolve().parents[2]
DEFAULT_MAP = REPO / "cpsplus" / "manifests" / "ssf2t_dos_cd_tracks.tsv"


def rows(path: Path):
    with path.open(newline="", encoding="utf-8") as handle:
        for row in csv.DictReader(
                (line for line in handle
                 if line.strip() and not line.startswith("#")), delimiter="\t"):
            yield row


def join_seconds(note: str) -> float | None:
    """The measured fade position, parsed out of the manifest's note."""
    if "join " not in note:
        return None
    return float(note.split("join ", 1)[1].split(" s", 1)[0])


def cut(src: Path, dest: Path, start: float | None, end: float | None) -> None:
    cmd = ["ffmpeg", "-hide_banner", "-loglevel", "error", "-y"]
    if start:
        cmd += ["-ss", f"{start:.3f}"]
    if end is not None:
        cmd += ["-t", f"{end - (start or 0):.3f}"]
    cmd += ["-i", str(src), "-c:a", "flac", str(dest)]
    proc = subprocess.run(cmd, capture_output=True)
    if proc.returncode != 0:
        raise RuntimeError(f"{dest.name}: ffmpeg exited {proc.returncode}: "
                           f"{proc.stderr.decode(errors='replace')[-300:]}")


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("cdda_dir", type=Path)
    ap.add_argument("--out-dir", required=True, type=Path)
    ap.add_argument("--map", type=Path, default=DEFAULT_MAP)
    a = ap.parse_args(argv)
    a.out_dir.mkdir(parents=True, exist_ok=True)

    made = skipped = 0
    for row in rows(a.map):
        track, stem = row["cd_track"], row["dos_song"] if "dos_song" in row else row["stem"]
        if stem == "-":
            print(f"{track}: unidentified, skipped")
            skipped += 1
            continue
        # extract_cdda.py writes WAV; an already-compressed cache holds FLAC.
        # ffmpeg reads either, so take whichever is there rather than making
        # the caller convert a extraction it just made.
        for ext in (".flac", ".wav"):
            src = a.cdda_dir / f"{track}{ext}"
            if src.is_file():
                break
        else:
            raise SystemExit(
                f"missing {a.cdda_dir / track}.flac or .wav")
        if row["role_half"] == "base+critical":
            join = join_seconds(row["note"])
            if join is None:
                raise SystemExit(f"{track}: no measured join in the manifest note")
            cut(src, a.out_dir / f"{stem}.flac", None, join)
            cut(src, a.out_dir / f"{stem}_KO.flac", join, None)
            print(f"{track}: {stem} [0..{join:.2f}]  +  {stem}_KO [{join:.2f}..end]")
            made += 2
        else:
            cut(src, a.out_dir / f"{stem}.flac", None, None)
            print(f"{track}: {stem}")
            made += 1
    print(f"\n{made} pieces -> {a.out_dir}  ({skipped} unidentified track(s) skipped)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
