#!/usr/bin/env python3
"""Fetch and build the pinned Nuked-OPL3 renderer (libADLMIDI, WAVE-only).

The MS-DOS SSF2T disc's `_F` sequences are the AdLib/OPL path -- its
`sb16/HMISET.CFG` points MIDI at port 0x388 -- and the disc ships the OPL
instrument banks the driver loads (`DRV/MELODIC.BNK`, `DRV/DRUM.BNK`, both
plain AdLib "ADLIB-" banks).  libADLMIDI supplies the sequencer and the Nuked
OPL3 core; the banks come from the disc, converted by `tools/bnk2wopl.py`, so
the timbres are the game's own rather than a generic substitute.

Both the shared library and the WAVE-only demo player are built.  The shared
library is what `render_dos_opl.py` drives through ctypes -- the same pattern
`spc_render.py` uses for libgme -- because the demo player hardcodes 44.1 kHz
(`dev_setup.cpp`, no CLI flag) and this pipeline wants the chip's own rate.

Third-party source and binaries live under `work/dos/upstream` and
stay untracked; `work/` is disposable, so re-run this command to recreate
them.  Nothing here downloads ROMs or game data.
"""
from __future__ import annotations

import argparse
import shutil
import subprocess
import sys
from pathlib import Path


class SetupError(RuntimeError):
    pass


ADLMIDI_REPOSITORY = "https://github.com/Wohlstand/libADLMIDI.git"
ADLMIDI_COMMIT = "99c5e03a5cf9b4fdf35b53efddb853c96320d50f"
ADLMIDI_RELEASE = "v1.6.2.1"


def _run(command: list[str], cwd: Path | None = None) -> str:
    result = subprocess.run(command, cwd=cwd, text=True, capture_output=True)
    if result.returncode:
        details = "\n".join(part for part in (result.stdout, result.stderr) if part)
        raise SetupError(
            f"command failed ({result.returncode}): {' '.join(command)}\n{details}"
        )
    return result.stdout.strip()


def _checkout(path: Path) -> None:
    if not path.exists():
        _run(["git", "clone", "--no-checkout", ADLMIDI_REPOSITORY, str(path)])
        _run(["git", "checkout", "--detach", ADLMIDI_COMMIT], path)
    elif not (path / ".git").is_dir():
        raise SetupError(f"existing path is not a Git checkout: {path}")
    head = _run(["git", "rev-parse", "HEAD"], path)
    if head != ADLMIDI_COMMIT:
        raise SetupError(
            f"{path} is at {head}, expected {ADLMIDI_COMMIT}; move it aside "
            "rather than having this setup command overwrite it"
        )
    dirty = _run(["git", "status", "--porcelain", "--untracked-files=no"], path)
    if dirty:
        raise SetupError(f"tracked files are modified in {path}; move it aside")


def _generator(build: Path) -> list[str]:
    if (build / "CMakeCache.txt").is_file():
        return []
    return ["-G", "Ninja"] if shutil.which("ninja") else []


def setup(root: Path) -> Path:
    root.mkdir(parents=True, exist_ok=True)
    adlmidi = root / "libADLMIDI"
    _checkout(adlmidi)
    build = adlmidi / "build"
    _run([
        "cmake", "-S", str(adlmidi), "-B", str(build),
        *_generator(build),
        "-DCMAKE_BUILD_TYPE=Release",
        "-DlibADLMIDI_STATIC=ON",
        "-DlibADLMIDI_SHARED=ON",
        # Nuked OPL3 is the accurate core and the only one this pack uses; the
        # rest are built out so a stray default cannot change the sound.
        "-DUSE_NUKED_EMULATOR=ON",
        "-DUSE_DOSBOX_EMULATOR=OFF",
        "-DUSE_OPAL_EMULATOR=OFF",
        "-DUSE_JAVA_EMULATOR=OFF",
        "-DUSE_ESFMU_EMULATOR=OFF",
        "-DUSE_MAME_EMULATOR=OFF",
        "-DUSE_YMFM_EMULATOR=OFF",
        "-DWITH_MIDIPLAY=ON",
        "-DMIDIPLAY_WAVE_ONLY=ON",
        # OFF on purpose, and it costs nothing: the renderer asks for the
        # chip's OWN rate (49716 Hz), where libADLMIDI's fallback resampler
        # has rateratio exactly 1.0 and its interpolation weights are 0 and 1
        # -- every native sample passes through untouched.  Turning it ON
        # would pull in zita-resampler as a system dependency to do work this
        # pipeline does not ask for.  Never render this set at 44.1 or 48 kHz
        # through it: at any other ratio that same fallback is plain linear
        # interpolation, which aliases audibly on bright FM.
        "-DWITH_HQ_RESAMPLER=OFF",
    ])
    _run(["cmake", "--build", str(build), "--target", "adlmidiplay"])
    _run(["cmake", "--build", str(build), "--target", "ADLMIDI_shared"])

    renderer = None
    for candidate in (build / "adlmidiplay", build / "utils" / "midiplay" / "adlmidiplay"):
        if candidate.is_file():
            renderer = candidate
            break
    if renderer is None:
        found = sorted(p for p in build.rglob("adlmidiplay") if p.is_file())
        if not found:
            raise SetupError(f"build succeeded but no adlmidiplay under {build}")
        renderer = found[0]
    print(f"ready: {renderer}\nlibADLMIDI {ADLMIDI_RELEASE} ({ADLMIDI_COMMIT[:12]}), "
          "Nuked OPL3, WAVE-only")
    return renderer


def self_test() -> None:
    assert len(ADLMIDI_COMMIT) == 40
    assert ADLMIDI_REPOSITORY.startswith("https://github.com/")
    assert ADLMIDI_RELEASE.startswith("v")
    print("setup_dos_opl_tools self-test: OK")


def main(argv: list[str] | None = None) -> int:
    repo = Path(__file__).resolve().parents[2]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--self-test", action="store_true")
    parser.add_argument(
        "--root", type=Path,
        default=repo / "cpsplus" / "work" / "dos" / "upstream",
    )
    args = parser.parse_args(argv)
    if args.self_test:
        self_test()
        return 0
    setup(args.root)
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (OSError, SetupError) as exc:
        print(f"setup_dos_opl_tools: error: {exc}", file=sys.stderr)
        raise SystemExit(1)
