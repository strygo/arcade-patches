#!/usr/bin/env python3
"""Render the MS-DOS SSF2T `_G` sequences on an SC-55 as loop-tagged FLAC.

The disc ships an `sc55/HMISET.CFG` naming "Roland Sound Canvas", so this is
the device the `_G` set was authored for, not a substitution.  The chain is the
one the shipped X68000 MIDI packs use, reused rather than re-invented:

  hmp2smf (GS reset + 0.5 s settle, loop unrolled one pass)
    -> Nuked-SC55, f32, 64 kHz, ROMs pinned by sha256
    -> drop the settle window
    -> pack/resample.py 64 -> 48 kHz (swresample redone bit-exactly in-repo,
       so the audio does not depend on the CPU)
    -> llrint to s32, top 24 bits kept
    -> FLAC + LOOPSTART / LOOPEND / LOOPLENGTH Vorbis comments

Loop tags name the SECOND pass, so the pack's wrap crossfade has real
repeating audio on both sides -- see `hmp.loop_samples`.  The render is
truncated at LOOPEND for looped songs; one-shots keep their release tail.

The renderer writes to a pipe and the resampled result goes straight to FLAC,
so a song never costs more than its own final file on disk.

usage:
  render_dos_midi.py MIDI_DIR --out-dir DIR [--songs CHUN_G ...]
      [--renderer PATH] [--roms DIR]
"""
from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
import sys
from pathlib import Path

import numpy as np

TOOLS = Path(__file__).resolve().parent
REPO = TOOLS.parent.parent
sys.path.insert(0, str(TOOLS))
# pack/ sits beside tools/ in BOTH layouts -- the source tree and the built
# kit -- so reach it from tools' own parent rather than from a source-tree
# root that does not exist in a download.  Same idiom as
# export_x68k_midi_flac.py, which ships for the same reason.
sys.path.insert(0, str(TOOLS.parent))

import hmp as hmp_mod                                   # noqa: E402
from hmp2smf import device_for                          # noqa: E402
from pack import resample                               # noqa: E402

RENDER_RATE = 64_000
OUTPUT_RATE = 48_000
CHANNELS = 2
FILTER_SIZE = 64            # the size the X68000 SC-55 exports were made with
UNROLL_PASSES = 1
STEADY_PASS = 1
ONESHOT_TAIL_SECONDS = 3.0

# Nuked-SC55's own mk1 set, as `render_x68k_sc55.py` pins it.
SC55_MK1 = {
    "sc55_rom1.bin": "7e1bacd1d7c62ed66e465ba05597dcd60dfc13fc23de0287fdbce6cf906c6544",
    "sc55_rom2.bin": "effc6132d68f7e300aaef915ccdd08aba93606c22d23e580daf9ea6617913af1",
    "sc55_waverom1.bin": "5655509a531804f97ea2d7ef05b8fec20ebf46216b389a84c44169257a4d2007",
    "sc55_waverom2.bin": "c655b159792d999b90df9e4fa782cf56411ba1eaa0bb3ac2bdaf09e1391006b1",
    "sc55_waverom3.bin": "334b2d16be3c2362210fdbec1c866ad58badeb0f84fd9bf5d0ac599baf077cc2",
}
DEFAULT_RENDERER = (REPO / "cpsplus" / "work" / "x68000" / "upstream"
                    / "Nuked-SC55-GUI-Float" / "build" / "nuked-sc55-render")
DEFAULT_ROMS = REPO / "roms" / "sc55"


class RenderError(RuntimeError):
    pass


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def check_roms(roms: Path) -> None:
    for name, want in SC55_MK1.items():
        path = roms / name
        if not path.is_file():
            raise RenderError(f"missing SC-55 ROM: {path}")
        got = _sha256(path)
        if got != want:
            raise RenderError(f"{name}: sha256 {got}, expected {want}")


def render_f32(renderer: Path, roms: Path, midi: Path) -> np.ndarray:
    """Nuked-SC55's raw float output, shape (frames, 2).

    Always "--end cut".  The renderer's "release" mode runs on until the
    output goes silent, and a float reverb tail does not: it failed to
    terminate on a ten-second one-shot.  A one-shot's tail is bought instead
    with ``to_smf(tail_seconds=...)``, which is bounded and deterministic.
    """
    proc = subprocess.run(
        [str(renderer), "-d", str(roms), "--romset", "mk1", "-f", "f32",
         "--end", "cut", "--stdout", str(midi)],
        capture_output=True, check=False)
    if proc.returncode != 0:
        raise RenderError(f"{midi.name}: renderer exited {proc.returncode}: "
                          f"{proc.stderr.decode(errors='replace')[-400:]}")
    samples = np.frombuffer(proc.stdout, dtype="<f4")
    if samples.size % CHANNELS:
        raise RenderError(f"{midi.name}: raw output ends mid-frame")
    audio = samples.reshape(-1, CHANNELS)
    if not audio.size:
        raise RenderError(f"{midi.name}: renderer produced no audio")
    if not np.all(np.isfinite(audio)):
        raise RenderError(f"{midi.name}: render holds non-finite samples")
    return audio


def to_s32(v: np.ndarray) -> np.ndarray:
    """Float to s32 as ffmpeg does it, then the FLAC encoder's 24-bit keep."""
    q31 = np.clip(np.rint(v.astype(np.float64) * 2.0 ** 31),
                  -2.0 ** 31, 2.0 ** 31 - 1).astype(np.int64)
    return ((q31 >> 8) << 8).astype("<i4")


def convert(audio: np.ndarray, *, trim: int, limit: int | None) -> np.ndarray:
    body = audio[trim:]
    pcm = resample.convolve_f32(
        lambda k: np.ascontiguousarray(body[:, k]), len(body), CHANNELS,
        RENDER_RATE, OUTPUT_RATE, to_s32, "<i4", FILTER_SIZE, limit=limit)
    if limit is not None and len(pcm) < limit:
        pcm = np.concatenate((pcm, np.zeros((limit - len(pcm), CHANNELS), "<i4")))
    return pcm


def write_flac(pcm: np.ndarray, dest: Path, tags: dict[str, int]) -> None:
    args = ["ffmpeg", "-hide_banner", "-loglevel", "error", "-y",
            "-f", "s32le", "-ar", str(OUTPUT_RATE), "-ac", str(CHANNELS),
            "-i", "pipe:0", "-c:a", "flac", "-sample_fmt", "s32",
            "-bits_per_raw_sample", "24"]
    for key, value in tags.items():
        args += ["-metadata", f"{key}={value}"]
    args.append(str(dest))
    proc = subprocess.run(args, input=pcm.tobytes(), capture_output=True)
    if proc.returncode != 0:
        raise RenderError(f"{dest.name}: ffmpeg exited {proc.returncode}: "
                          f"{proc.stderr.decode(errors='replace')[-400:]}")


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("midi_dir", help="directory of .HMP files")
    ap.add_argument("--out-dir", required=True)
    ap.add_argument("--songs", nargs="*", help="stems to render (default: all _G)")
    ap.add_argument("--renderer", type=Path, default=DEFAULT_RENDERER)
    ap.add_argument("--roms", type=Path, default=DEFAULT_ROMS)
    a = ap.parse_args(argv)

    if not a.renderer.is_file():
        raise SystemExit(f"renderer not built: {a.renderer}\n"
                         "build it with tools/setup_x68k_capture_tools.py")
    check_roms(a.roms)

    midi_dir = Path(a.midi_dir)
    out_dir = Path(a.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    smf_dir = out_dir / "smf"
    smf_dir.mkdir(exist_ok=True)

    stems = a.songs or sorted(p.stem for p in midi_dir.iterdir()
                              if p.suffix.upper() == ".HMP"
                              and device_for(p.stem) == "gs")
    report = []
    for stem in stems:
        source = midi_dir / f"{stem}.HMP"
        song = hmp_mod.parse(source)
        reset = device_for(stem)
        if reset != "gs":
            raise SystemExit(f"{stem}: not a Sound Canvas sequence")
        loop = hmp_mod.loop_samples(song, OUTPUT_RATE, reset=reset,
                                    pass_index=STEADY_PASS)
        smf = smf_dir / f"{stem}.mid"
        smf.write_bytes(hmp_mod.to_smf(
            song, reset=reset, unroll_passes=UNROLL_PASSES,
            tail_seconds=0.0 if loop is not None else ONESHOT_TAIL_SECONDS))
        audio = render_f32(a.renderer, a.roms, smf)
        trim = round(hmp_mod.SETTLE_SECONDS[reset] * RENDER_RATE)
        tags: dict[str, int] = {}
        limit = None
        if loop is not None:
            settle = round(hmp_mod.SETTLE_SECONDS[reset] * OUTPUT_RATE)
            start, end = loop[0] - settle, loop[1] - settle
            if start <= OUTPUT_RATE:
                raise RenderError(
                    f"{stem}: loop starts {start} samples in, too early to "
                    "leave a one-second crossfade tail before it")
            tags = {"LOOPSTART": start, "LOOPEND": end,
                    "LOOPLENGTH": end - start}
            limit = end

        pcm = convert(audio, trim=trim, limit=limit)
        dest = out_dir / f"{stem}.flac"
        write_flac(pcm, dest, tags)
        kind = (f"loop {tags['LOOPSTART']}..{tags['LOOPEND']}"
                if tags else "one-shot")
        size = dest.stat().st_size
        print(f"{stem:12s} {len(pcm) / OUTPUT_RATE:7.2f}s  {size / 1e6:6.2f} MB  {kind}")
        report.append({"song": stem, "frames": int(len(pcm)),
                       "render_frames": int(len(audio)), "tags": tags,
                       "sha256": _sha256(dest)})

    (out_dir / "render_report.json").write_text(
        json.dumps({"renderer_sha256": _sha256(a.renderer),
                    "romset": "SC-55 v1.21 (mk1)",
                    "rate": OUTPUT_RATE, "songs": report}, indent=2),
        encoding="utf-8")
    print(f"\n{len(report)} songs -> {out_dir}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
