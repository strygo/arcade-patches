#!/usr/bin/env python3
"""Convert HMI `.HMP` sequences to Standard MIDI Files, with a loop sidecar.

The HMP files of the MS-DOS Super Street Fighter II Turbo disc carry no device
setup at all -- no SysEx, no tempo meta, nothing but notes, controllers and
program changes; the game's own driver initialises the device from
`HMISET.CFG`.  So the reset belongs here, chosen per device family, and the
shipped presets name exactly three:

    sb16/HMISET.CFG   Sound Blaster 16, MIDI port 0x388   -> `_F`  OPL, no reset
    sc55/HMISET.CFG   Roland Sound Canvas                 -> `_G`  GS reset
    mt32/HMISET.CFG   MT-32                               -> `_M`  MT-32 reset

The emitted SMF plays at exactly the HMP's own tick rate (see `hmp.py`
TIMING), so the loop ticks in the sidecar are directly comparable to the
rendered audio: sample = tick * rate / tick_rate.

usage:
  hmp2smf.py SRC [SRC...] --out-dir DIR [--reset gs|mt32|none] [--tsv out.tsv]

SRC may be a file or a directory of `.HMP` files.  With `--reset auto` the
device is taken from the `_F` / `_G` / `_M` / `_KOF` / `_KOG` / `_KOM` suffix.
"""
from __future__ import annotations

import argparse
import csv
import sys
from pathlib import Path

if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parent))

import hmp as hmp_mod

SUFFIX_DEVICE = {"F": "none", "G": "gs", "M": "mt32"}


def device_for(stem: str) -> str | None:
    """`CHUN_G` -> gs, `CHUN_KOM` -> mt32, `BALR_KOF` -> none (OPL).

    None for a stem with no device suffix.  The SSF2T corpus has exactly one:
    `TEST.HMP`, a driver diagnostic (its own tick rate and division, no game
    role) rather than a song.
    """
    tail = stem.rsplit("_", 1)[-1].upper()
    if tail.startswith("KO"):
        tail = tail[2:]
    return SUFFIX_DEVICE.get(tail)


def gather(sources: list[str]) -> list[Path]:
    out: list[Path] = []
    for raw in sources:
        path = Path(raw)
        if path.is_dir():
            out.extend(sorted(p for p in path.iterdir()
                              if p.suffix.upper() == ".HMP"))
        else:
            out.append(path)
    if not out:
        raise SystemExit("no .HMP inputs found")
    return out


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("sources", nargs="+", help="HMP files or directories")
    ap.add_argument("--out-dir", required=True)
    ap.add_argument("--reset", default="auto",
                    choices=["auto", "gs", "mt32", "none"],
                    help="device reset to prepend (default: from the filename)")
    ap.add_argument("--keep-loop-cc", action="store_true",
                    help="keep the HMI loop controllers in the SMF")
    ap.add_argument("--unroll", type=int, default=1, metavar="N",
                    help="repeat the loop body N extra times so the audio "
                         "past the loop end is the real second pass "
                         "(default 1; a pack needs at least 1)")
    ap.add_argument("--tsv", help="write the loop/duration manifest here")
    ap.add_argument("--rate", type=int, default=48_000,
                    help="sample rate the loop columns are expressed in")
    a = ap.parse_args(argv)

    out_dir = Path(a.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    rows = []
    for path in gather(a.sources):
        song = hmp_mod.parse(path)
        if a.reset == "auto":
            reset = device_for(path.stem)
            if reset is None:
                print(f"{path.name:16s} -- skipped: no device suffix")
                continue
        else:
            reset = a.reset
        smf = hmp_mod.to_smf(song, reset=reset,
                             keep_loop_cc=a.keep_loop_cc,
                             unroll_passes=a.unroll)
        dest = out_dir / (path.stem + ".mid")
        dest.write_bytes(smf)

        loop = song.loop
        samples = hmp_mod.loop_samples(song, a.rate, reset=reset)
        hanging = hmp_mod.hanging_notes(song)
        if hanging:
            print(f"  ! {path.name}: notes still sounding at the loop end "
                  f"(channel: count) {hanging}")
        rows.append({
            "file": path.stem,
            "device": reset,
            "tracks": len(song.tracks),
            "tick_rate": song.tick_rate,
            "ticks": song.ticks,
            "seconds": f"{song.seconds:.3f}",
            "stored_seconds": song.stored_seconds,
            "loops": "yes" if loop else "no",
            "loop_start_tick": loop.start_tick if loop else "-",
            "loop_end_tick": loop.end_tick if loop else "-",
            "loop_count": loop.count if loop else "-",
            "loop_start_sample": samples[0] if samples else "-",
            "loop_end_sample": samples[1] if samples else "-",
            "hanging_at_loop_end": ",".join(f"ch{c}:{n}" for c, n in
                                            sorted(hanging.items())) or "-",
        })
        flag = (f"loop {loop.start_tick}->{loop.end_tick}"
                if loop else "one-shot")
        print(f"{path.name:16s} -> {dest.name:16s} {reset:5s} "
              f"{len(song.tracks)}trk {song.seconds:7.2f}s  {flag}")

    if a.tsv:
        tsv = Path(a.tsv)
        tsv.parent.mkdir(parents=True, exist_ok=True)
        with tsv.open("w", newline="", encoding="utf-8") as f:
            f.write(f"# HMP -> SMF conversion manifest; loop samples at "
                    f"{a.rate} Hz\n")
            w = csv.DictWriter(f, fieldnames=list(rows[0]), delimiter="\t",
                               lineterminator="\n")
            w.writeheader()
            w.writerows(rows)
        print(f"\nwrote {tsv} ({len(rows)} rows)")

    looped = sum(r["loops"] == "yes" for r in rows)
    print(f"\n{len(rows)} files: {looped} looped, {len(rows) - looped} one-shot")
    return 0


if __name__ == "__main__":
    sys.exit(main())
