#!/usr/bin/env python3
"""Read HMI `.HMP` sequences (Human Machine Interfaces Sound Operating System).

Reversed 2026-09-18 against the 178 files of the MS-DOS Super Street Fighter II
Turbo (GameTek/Eurocom 1995, `SSF2T/GAMETEK/SSF2T/MIDI/`).  All 178 parse with
zero leftover bytes in every track, which is the check that licenses the layout
below -- nothing here is inferred from documentation.

LAYOUT
------
    0x00  8   b"HMIMIDIP" followed by an ASCII build stamp ("013195")
    0x30  u32 track count
    0x34  u32 constant 0x180 in 177/178 files (0x1e0 in TEST.HMP); NOT the
          playback division -- see TIMING
    0x38  u32 tick rate, ticks per second (80; 120 in TEST.HMP)
    0x3c  u32 stored duration in whole seconds -- STALE in 12 of 178 files,
          never rely on it (see TIMING)
    0x40  u32[] per-track device word (9 = "any"), sparse
    0x388     first track chunk; chunks are contiguous from here

Each track chunk is

    u32 track index (0-based, always sequential)
    u32 chunk length INCLUDING these 12 header bytes
    u32 MIDI channel
    (length - 12) bytes of events

Events are ``[delta][message]``.  The delta is a little-endian 7-bit varint
whose LAST byte has the high bit SET -- the opposite convention to a Standard
MIDI File's big-endian varint, whose CONTINUING bytes carry the high bit.  The
message is always a full MIDI message: **running status is never used**, which
is what makes a strict "leftover must be zero" parse a real check.  The only
meta event present in the corpus is 0x2F (end of track); there is no SysEx and
there are no tempo meta events.

TIMING
------
Playback is a fixed ``tick_rate`` ticks per second (the 0x38 word); there is no
tempo map to follow.  Evidence, three independent ways:

  * ``0x3c == total_ticks // tick_rate`` in 166 of 178 files.  The 12
    exceptions (the E_RYU / E_VEGA / E_WEDD / GUIL families) disagree in both
    directions and by non-constant factors, so 0x3c is a stale authoring field,
    not a second clock.
  * The drum grid lands on musical tempi: CHUN_G's modal onset gap is 17-18
    ticks, an eighth at ~138 BPM; RYU_G's is 9-10 ticks, a sixteenth at
    ~126 BPM.  Reading 0x34 as a division instead puts a quarter note at 4.8 s.
  * Rendered length matches ``total_ticks / tick_rate``.

``to_smf`` therefore emits division = ``tick_rate`` with a single 1 000 000
us/quarter tempo, which reproduces exactly ``tick_rate`` ticks per second and
makes every tick a whole millisecond multiple of 1/rate.  A loop tick converts
to seconds as ``tick / tick_rate``.

LOOPS
-----
Looping songs carry an explicit, exact loop on the FIRST sounding track:

    CC 110 (0x6e), value 255   loop start   (value is the repeat count;
                                             255 = forever)
    CC 111 (0x6f), value 128   loop end
    CC 109 (0x6d), value 128   emitted alongside the loop start

and every other track carries CC 108 (0x6c) value 0 at the same tick, a
per-track sync marker.  One loop per song, always.  Of the 177 SSF2T songs
(the 178th file, TEST.HMP, is a driver diagnostic with its own tick rate and
no game role) 144 loop and 33 are one-shots; the one-shots carry none of these
controllers at all, so presence is also a reliable looping/one-shot classifier.

The loop boundary is INCLUSIVE of the loop-end tick: 190 events across the
corpus sit exactly on one, none of them a note-on, and 21 files close a note
there.  See ``_unrolled``.

Known corpus quirk: ``GUIL_KOF.HMP`` writes loop count 127 where its ``_KOG``
and ``_KOM`` siblings write 255, at identical loop ticks.  Treat any CC 110 as
a loop start and keep the count for the record.
"""
from __future__ import annotations

import struct
from dataclasses import dataclass
from pathlib import Path

MAGIC = b"HMIMIDIP"
FIRST_TRACK = 0x388
TRACK_HEADER = 12

CC_TRACK_SYNC = 108
CC_LOOP_MARK = 109
CC_LOOP_START = 110
CC_LOOP_END = 111
LOOP_CCS = frozenset((CC_TRACK_SYNC, CC_LOOP_MARK, CC_LOOP_START, CC_LOOP_END))

META = 0xFF
META_END_OF_TRACK = 0x2F


class HmpError(ValueError):
    pass


@dataclass(frozen=True)
class Event:
    tick: int
    status: int
    data: bytes

    @property
    def is_end_of_track(self) -> bool:
        return self.status == META and self.data[:1] == bytes([META_END_OF_TRACK])

    @property
    def controller(self) -> int | None:
        if 0xB0 <= self.status <= 0xBF:
            return self.data[0]
        return None


@dataclass(frozen=True)
class Track:
    index: int
    channel: int
    events: tuple[Event, ...]

    @property
    def ticks(self) -> int:
        return self.events[-1].tick if self.events else 0


@dataclass(frozen=True)
class Loop:
    start_tick: int
    end_tick: int
    count: int

    @property
    def forever(self) -> bool:
        return self.count >= 127


@dataclass(frozen=True)
class HmpFile:
    name: str
    tick_rate: int
    header_division: int
    stored_seconds: int
    tracks: tuple[Track, ...]
    trailer: bytes

    @property
    def ticks(self) -> int:
        return max((t.ticks for t in self.tracks), default=0)

    @property
    def seconds(self) -> float:
        return self.ticks / self.tick_rate

    def tick_to_seconds(self, tick: int) -> float:
        return tick / self.tick_rate

    @property
    def loop(self) -> Loop | None:
        """The song's loop, or None for a one-shot.

        The loop END is unique across the whole SSF2T corpus, so it anchors the
        pair: the loop is the CC 110 / CC 111 pair on the track that carries
        the end marker.  A CC 110 on any OTHER track is authoring noise and is
        ignored -- the BLAN_KO family (all three device variants) puts a second
        CC 110 on track 4 at the loop-end tick, where a CC 108 sync marker
        belongs.
        """
        ends = [(track, ev) for track in self.tracks for ev in track.events
                if ev.controller == CC_LOOP_END]
        if not ends:
            if any(ev.controller == CC_LOOP_START
                   for track in self.tracks for ev in track.events):
                raise HmpError(f"{self.name}: loop start with no loop end")
            return None
        if len(ends) > 1:
            raise HmpError(f"{self.name}: {len(ends)} loop ends, expected one")
        loop_track, end_ev = ends[0]
        end = end_ev.tick
        starts = [ev for ev in loop_track.events
                  if ev.controller == CC_LOOP_START]
        if len(starts) != 1:
            raise HmpError(f"{self.name}: {len(starts)} loop starts on the "
                           "track carrying the loop end, expected one")
        start, count = starts[0].tick, starts[0].data[1]
        if end <= start:
            raise HmpError(f"{self.name}: loop end {end} precedes start {start}")
        if end > self.ticks:
            raise HmpError(f"{self.name}: loop end {end} past the song's "
                           f"{self.ticks} ticks")
        assert count is not None
        return Loop(start, end, count)


def _read_delta(body: bytes, pos: int) -> tuple[int, int]:
    """HMI varint: little-endian 7-bit groups, high bit SET on the last byte."""
    value = shift = 0
    while True:
        if pos >= len(body):
            raise HmpError("delta runs past the end of the track")
        byte = body[pos]
        pos += 1
        value |= (byte & 0x7F) << shift
        shift += 7
        if byte & 0x80:
            return value, pos
        if shift > 28:
            raise HmpError("unterminated delta")


def _parse_events(body: bytes, where: str) -> tuple[Event, ...]:
    events: list[Event] = []
    pos = tick = 0
    while pos < len(body):
        delta, pos = _read_delta(body, pos)
        tick += delta
        if pos >= len(body):
            raise HmpError(f"{where}: delta with no message")
        status = body[pos]
        if status == META:
            kind = body[pos + 1]
            if kind == META_END_OF_TRACK:
                events.append(Event(tick, META, bytes([kind, 0])))
                pos += 3
                break
            length = body[pos + 2]
            events.append(Event(tick, META, body[pos + 1:pos + 3 + length]))
            pos += 3 + length
        elif status in (0xF0, 0xF7):
            length = body[pos + 1]
            events.append(Event(tick, status, body[pos + 2:pos + 2 + length]))
            pos += 2 + length
        elif status < 0x80:
            raise HmpError(f"{where}: running status at offset {pos} "
                           "(the format does not use it)")
        else:
            size = 1 if (status & 0xF0) in (0xC0, 0xD0) else 2
            events.append(Event(tick, status, body[pos + 1:pos + 1 + size]))
            pos += 1 + size
    if pos != len(body):
        raise HmpError(f"{where}: {len(body) - pos} bytes left after the end "
                       "of track")
    if not events or not events[-1].is_end_of_track:
        raise HmpError(f"{where}: track does not end with an end-of-track meta")
    return tuple(events)


def parse(source: Path | str | bytes, name: str | None = None) -> HmpFile:
    if isinstance(source, (Path, str)):
        path = Path(source)
        raw = path.read_bytes()
        name = name or path.name
    else:
        raw = bytes(source)
        name = name or "<bytes>"
    if raw[:len(MAGIC)] != MAGIC:
        raise HmpError(f"{name}: not an HMP file")
    if len(raw) < FIRST_TRACK:
        raise HmpError(f"{name}: truncated header")
    count, division, tick_rate, stored = struct.unpack_from("<IIII", raw, 0x30)
    if not 0 < count <= 64:
        raise HmpError(f"{name}: implausible track count {count}")
    if tick_rate <= 0:
        raise HmpError(f"{name}: invalid tick rate {tick_rate}")

    tracks: list[Track] = []
    offset = FIRST_TRACK
    for expected in range(count):
        if offset + TRACK_HEADER > len(raw):
            raise HmpError(f"{name}: track {expected} header past end of file")
        index, length, channel = struct.unpack_from("<III", raw, offset)
        if index != expected:
            raise HmpError(f"{name}: track {expected} is labelled {index}")
        if length < TRACK_HEADER or offset + length > len(raw):
            raise HmpError(f"{name}: track {expected} length {length} "
                           "does not fit the file")
        if not 0 <= channel <= 15:
            raise HmpError(f"{name}: track {expected} channel {channel}")
        body = raw[offset + TRACK_HEADER:offset + length]
        tracks.append(Track(index, channel,
                            _parse_events(body, f"{name} track {expected}")))
        offset += length
    return HmpFile(name=name, tick_rate=tick_rate, header_division=division,
                   stored_seconds=stored, tracks=tuple(tracks),
                   trailer=raw[offset:])


# --------------------------------------------------------------------------
# Standard MIDI File output
# --------------------------------------------------------------------------

GS_RESET = bytes([0x41, 0x10, 0x42, 0x12, 0x40, 0x00, 0x7F, 0x00, 0x41])
MT32_RESET = bytes([0x41, 0x10, 0x16, 0x12, 0x7F, 0x00, 0x00, 0x00, 0x01])
RESETS = {"gs": GS_RESET, "mt32": MT32_RESET, "none": None}

# The device's own reset needs time to settle before the first note.  The
# X68000 pipeline measured 500 ms for a native GS sequence and six seconds for
# an MT-32 initialisation; reuse those numbers rather than inventing new ones.
SETTLE_SECONDS = {"gs": 0.5, "mt32": 6.0, "none": 0.0}


def hanging_notes(song: HmpFile) -> dict[int, int]:
    """Notes still sounding at the loop end, per channel.

    The driver loops by jumping back to the loop-start position; it does not
    silence anything first.  A note started before the loop end whose note-off
    lies after it therefore hangs.  Composers avoid that by putting the loop on
    a clean boundary, so a non-empty result means the song needs a look.
    """
    loop = song.loop
    if loop is None:
        return {}
    live: dict[int, int] = {}
    for track in song.tracks:
        for ev in track.events:
            if ev.tick > loop.end_tick:
                break
            family = ev.status & 0xF0
            if family == 0x90 and ev.data[1] > 0:
                live[track.channel] = live.get(track.channel, 0) + 1
            elif family == 0x80 or (family == 0x90 and ev.data[1] == 0):
                live[track.channel] = live.get(track.channel, 0) - 1
    return {ch: n for ch, n in live.items() if n > 0}


def _unrolled(track: Track, loop: Loop, passes: int) -> list[Event]:
    """``track``'s events with the loop body repeated ``passes`` extra times.

    Pass one ends exactly at ``loop.end_tick``, so the loop points stay valid
    in the unrolled timeline and everything after them is the genuine musical
    continuation -- which is what the pack's wrap crossfade needs.  The
    original material after the loop end is dropped: for a forever-looping song
    the driver never reaches it, and in this corpus it is only note-offs and
    trailing silence anyway.

    The boundary is INCLUSIVE of the loop-end tick.  The driver plays the
    events at that tick and jumps when it reaches the CC 111 marker, and the
    corpus bears that out: 190 events sit exactly on a loop-end tick and NONE
    of them is a note-on, while 21 files close a note there.  Cutting the tick
    open leaves those notes hanging forever in the unrolled render.
    """
    def body_events(events):
        return [ev for ev in events
                if not ev.is_end_of_track and ev.controller not in LOOP_CCS]

    body = loop.end_tick - loop.start_tick
    out = body_events(ev for ev in track.events if ev.tick <= loop.end_tick)
    for extra in range(1, passes + 1):
        shift = extra * body
        out.extend(Event(ev.tick + shift, ev.status, ev.data)
                   for ev in body_events(
                       ev for ev in track.events
                       if loop.start_tick <= ev.tick <= loop.end_tick))
    end = loop.end_tick + passes * body
    out.append(Event(end, META, bytes([META_END_OF_TRACK, 0])))
    return out


def _vlq(value: int) -> bytes:
    """Standard MIDI File varint: big-endian, high bit set on CONTINUING bytes."""
    if value < 0:
        raise ValueError("negative delta")
    out = bytearray([value & 0x7F])
    value >>= 7
    while value:
        out.append((value & 0x7F) | 0x80)
        value >>= 7
    return bytes(reversed(out))


def _chunk(tag: bytes, body: bytes) -> bytes:
    return tag + struct.pack(">I", len(body)) + body


def to_smf(hmp: HmpFile, *, reset: str = "none", keep_loop_cc: bool = False,
           unroll_passes: int = 0, tail_seconds: float = 0.0) -> bytes:
    """A format-1 SMF that plays at exactly ``hmp.tick_rate`` ticks/second.

    Division is the tick rate and the single tempo is one second per quarter,
    so an HMP tick and an SMF tick are the same unit and ``tick / tick_rate``
    is the time in seconds.  The HMI loop controllers are dropped unless
    ``keep_loop_cc``; they are undefined in GM/GS and the loop travels in the
    sidecar instead.

    ``unroll_passes`` repeats the loop body that many extra times (see
    ``_unrolled``).  One pass is what a pack needs: the material after the loop
    end is then the real second pass, so the wrap crossfade blends musically
    identical audio.  One-shots ignore it.

    ``tail_seconds`` pushes the conductor track's end-of-track that much later,
    which is how a one-shot gets its release tail rendered.  Do that rather
    than asking the renderer to run on until silence: Nuked-SC55's "release"
    mode chases a reverb that in float never quite reaches zero, and it failed
    to terminate even on a ten-second cue.
    """
    if reset not in RESETS:
        raise ValueError(f"unknown reset {reset!r}")
    if unroll_passes < 0:
        raise ValueError("unroll_passes must not be negative")
    settle = round(SETTLE_SECONDS[reset] * hmp.tick_rate)
    loop = hmp.loop
    per_track = [
        _unrolled(track, loop, unroll_passes)
        if loop is not None and unroll_passes else list(track.events)
        for track in hmp.tracks]
    total = max((evs[-1].tick for evs in per_track if evs), default=0)

    conductor = bytearray()
    conductor += _vlq(0) + bytes([META, 0x51, 0x03]) + (1_000_000).to_bytes(3, "big")
    payload = RESETS[reset]
    if payload is not None:
        conductor += _vlq(0) + bytes([0xF0]) + _vlq(len(payload) + 1) + payload + b"\xf7"
    tail = round(tail_seconds * hmp.tick_rate)
    conductor += (_vlq(max(total + settle + tail, 0))
                  + bytes([META, META_END_OF_TRACK, 0]))

    chunks = [_chunk(b"MTrk", bytes(conductor))]
    for events in per_track:
        body = bytearray()
        previous = 0
        for ev in events:
            if not keep_loop_cc and ev.controller in LOOP_CCS:
                continue
            tick = ev.tick + settle
            if ev.is_end_of_track:
                body += _vlq(tick - previous) + bytes([META, META_END_OF_TRACK, 0])
            elif ev.status == META:
                body += (_vlq(tick - previous) + bytes([META, ev.data[0],
                                                        len(ev.data) - 1])
                         + ev.data[1:])
            elif ev.status in (0xF0, 0xF7):
                body += (_vlq(tick - previous) + bytes([ev.status])
                         + _vlq(len(ev.data)) + ev.data)
            else:
                body += _vlq(tick - previous) + bytes([ev.status]) + ev.data
            previous = tick
        chunks.append(_chunk(b"MTrk", bytes(body)))

    header = struct.pack(">HHH", 1, len(chunks), hmp.tick_rate)
    return _chunk(b"MThd", header) + b"".join(chunks)


def loop_samples(hmp: HmpFile, rate: int, *, reset: str = "none",
                 pass_index: int = 0) -> tuple[int, int] | None:
    """The song's loop in output samples at ``rate``, including reset settle.

    ``pass_index`` picks which rendered pass the loop points name.  Pass 0 is
    the first time through the body; pass 1 is the repeat that
    ``to_smf(unroll_passes=1)`` appends.

    Packs want pass 1, not pass 0.  A pack's wrap crossfade blends the second
    before the loop end into the second before the loop start, so both points
    have to sit in the STEADY STATE -- inside audio that is already repeating.
    A second before pass 0's start is still the intro, which never comes round
    again; a second before pass 1's start is the tail of pass 0, which is the
    same music.  This is the convention the shipped X68000 MIDI packs use
    (``render_x68k_sc55.py`` renders ``SETTLE_LOOP_PASSES = 1`` for the same
    reason), and it is why the render must be unrolled at all.
    """
    loop = hmp.loop
    if loop is None:
        return None
    if pass_index < 0:
        raise ValueError("pass_index must not be negative")
    settle = round(SETTLE_SECONDS[reset] * hmp.tick_rate)
    shift = pass_index * (loop.end_tick - loop.start_tick)
    return (round((loop.start_tick + shift + settle) * rate / hmp.tick_rate),
            round((loop.end_tick + shift + settle) * rate / hmp.tick_rate))
