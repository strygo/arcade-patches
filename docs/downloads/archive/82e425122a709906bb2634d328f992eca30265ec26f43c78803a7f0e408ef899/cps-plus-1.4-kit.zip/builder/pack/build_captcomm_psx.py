"""Build the Captain Commando (PSX Soundtrack) pack from the PlayStation disc.

Source: Captain Commando (Japan, 1998, SLPS-01567).  Its music is XA-ADPCM;
the game's own table in CAP.EXE plays channel + arrange flag, and the arcade
music commands 0x80-0x9e are the same numbers as the PSX music ids.
The streams are decoded straight from the
disc (pack/psx_xa.py) and kept at their native 37,800 Hz -- no resampling --
and each is checked against the recipe's PCM hash before use.

The recipe (manifests/captcomm_psx_audio.json, frozen from the approved
listening review by tools/captcomm_psx_recipe.py) gives every track a mode:

  one_shot  the stream as stored (from `start`), no loop
  xfade     loop [loop_start, loop_end) through the player's equal-power
            crossfade; stores the 44,096-sample tail past loop_end
  baked     loop [loop_start, loop_end) with the 27 ms equal-gain join baked
            into the stored samples (pack/loop_bake.py); crossfade off

Triggers: each mapped music command plays its track with native music
substituted by 0xf7; Credits (0x9e, preceded by the game's 0xf0 stop) plays the
arranged Ending from 25.86 s, so the Ending runs on into the credits.  0xf0,
0xf2 and 0xf7 stop the arrangement and still reach the Z80.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import zipfile
from pathlib import Path

import numpy as np

from . import adxcodec, loop_bake, protocols, psx_xa
from .build_common import MANIFESTS, PACKS_DIR
from .format import CODEC_ADX, PackReader, PackWriter, TrackMeta, TriggerRow, VERB_PLAY

RECIPE = MANIFESTS / "captcomm_psx_audio.json"
TITLE = "Captain Commando (PSX Soundtrack)"
RATE = 37800


def digest(path: Path) -> str:
    with Path(path).open("rb") as f:
        return hashlib.file_digest(f, "sha256").hexdigest()


def stream_source(name: str) -> tuple[str, int]:
    """'STAGE1_ch1.wav' -> ('/XA/STAGE1.XA', 1)"""
    stem, ch = name.removesuffix(".wav").rsplit("_ch", 1)
    return f"/XA/{stem}.XA", int(ch)


def track_pcm(t: dict, pcm: np.ndarray, xfade: int) -> tuple[np.ndarray, int, int, int]:
    """(stored pcm, loop_start, loop_end, crossfade flag); loop_end 0 = one-shot."""
    mode = t["mode"]
    if mode == "one_shot":
        return pcm[t.get("start", 0):], 0, 0, 0
    ls, le = t["loop_start"], t["loop_end"]
    if ls % 32 or le % 32 or not 0 <= ls < le:
        raise ValueError(f"{t['id']}: loop points must be 32-aligned, ls < le")
    if mode == "baked":
        n = t["blend_samples"]
        if ls < n:
            raise ValueError(f"{t['id']}: loop start inside the blend")
        return loop_bake.bake(pcm, ls, le, n), ls, le, 0
    if mode == "xfade":
        if le + xfade > len(pcm) or le - ls <= xfade:
            raise ValueError(f"{t['id']}: no room for the crossfade tail")
        return pcm[:le + xfade], ls, le, 1
    raise ValueError(f"{t['id']}: unknown mode {mode}")


def stored_zip(path: Path, files: dict[str, bytes]) -> None:
    with zipfile.ZipFile(path, "w", compression=zipfile.ZIP_STORED) as z:
        for name, data in sorted(files.items()):
            info = zipfile.ZipInfo(name, date_time=(2026, 9, 23, 0, 0, 0))
            info.external_attr = 0o100644 << 16
            z.writestr(info, data)


def build(disc: Path, recipe_path: Path = RECIPE, outdir: Path = PACKS_DIR) -> dict:
    recipe = json.loads(Path(recipe_path).read_text())
    if recipe["review_status"] != "approved":
        raise SystemExit(f"{recipe_path}: not approved")
    img = psx_xa.disc_image(disc)
    if psx_xa.sha256_file(img) != recipe["source"]["image_sha256"]:
        raise SystemExit(f"{disc}: not the pinned Captain Commando (Japan) disc image")
    xa = psx_xa.XaDisc(img)
    xfade = recipe["xfade_samples"]
    w = PackWriter(protocols.PROTOCOLS["captcomm"], title=TITLE,
                   trigger_rows=protocols.SF2_TRIGGER_ROWS, default_rate=RATE,
                   xfade_samples=xfade)
    files, decoded, index, audit = {}, {}, {}, []
    for t in recipe["tracks"]:
        name = t["stream"]
        if name not in decoded:
            path, ch = stream_source(name)
            files.setdefault(path, xa.xa_file(path))
            pcm = files[path].stream(ch).decode()
            if psx_xa.pcm_sha256(pcm) != t["pcm_sha256"] or len(pcm) != t["frames"]:
                raise SystemExit(f"{name}: decoded PCM does not match the recipe")
            decoded[name] = pcm
        stored, ls, le, xf = track_pcm(t, decoded[name], xfade)
        raw = np.ascontiguousarray(stored, "<i2").tobytes()
        stream = adxcodec.encode(raw, 2, RATE)
        if len(stream) != adxcodec.stream_bytes_for_samples(len(stored), 2):
            raise ValueError(f"{t['id']}: ADX length mismatch")
        c1, c2 = adxcodec.calc_coeffs(adxcodec.DEFAULT_CUTOFF, RATE)
        meta = TrackMeta(sample_rate=RATE, channels=2, codec=CODEC_ADX, gain=0x7f,
                         loop_start_sample=ls,
                         loop_start_byte=adxcodec.samples_to_stream_byte(ls, 2) if le else 0,
                         loop_end_sample=le,
                         loop_end_byte=adxcodec.samples_to_stream_byte(le, 2) if le else 0,
                         coef1=c1, coef2=c2, xfade_enable=xf,
                         name=f"{t['id']} {t['role']} ({t['mode']})", source=name)
        index[t["id"]] = w.add_track(stream, meta)
        audit.append({"id": t["id"], "mode": t["mode"], "frames": len(stored),
                      "pcm_sha256": hashlib.sha256(raw).hexdigest(),
                      "adx_sha256": hashlib.sha256(stream).hexdigest()})
        print(f"[cc] {t['id']:13} {t['mode']:8} {len(stored) / RATE:7.1f} s  "
              f"{len(stream) / 1e6:5.2f} MB  {t['role']}", flush=True)
    gain = recipe["trigger_gain"]
    for r in recipe["triggers"]:
        w.set_trigger(int(r["command"], 16),
                      TriggerRow(verb=VERB_PLAY, track=index[r["track"]], gain=gain, suppress=1))
    outdir = Path(outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    pack = outdir / "captcomm_psx.cpk"
    w.write(pack)
    rd = PackReader(pack)
    for r in recipe["triggers"]:
        row = rd.triggers[int(r["command"], 16)]
        if row.verb != VERB_PLAY or row.suppress != 1 or row.track != index[r["track"]]:
            raise ValueError(f"readback: {r['command']} is not mapped as built")
    for c in (0x00, 0x2d, 0x52, 0x6a, 0x90, 0x91, 0x92, 0x9f):
        if rd.triggers[c].verb or rd.triggers[c].suppress:
            raise ValueError(f"readback: 0x{c:02x} must pass through")
    stored_zip(outdir / "captcomm_psx.zip", {pack.name: pack.read_bytes()})
    report = {"pack": pack.name, "sha256": digest(pack), "bytes": pack.stat().st_size,
              "recipe_sha256": digest(recipe_path), "trigger_gain": gain, "tracks": audit}
    (outdir / "captcomm_psx.build.json").write_text(json.dumps(report, indent=2) + "\n")
    print(f"[cc] {pack.name}: {len(audit)} tracks, {len(recipe['triggers'])} triggers, "
          f"{report['bytes'] / 1e6:.1f} MB, sha256 {report['sha256'][:12]}")
    return report


def self_test() -> int:
    pcm = (np.arange(4000 * 2) % 300 - 150).astype("<i2").reshape(-1, 2) * 50
    one, *_ = track_pcm({"id": "t", "mode": "one_shot", "start": 64}, pcm, 256)
    assert len(one) == len(pcm) - 64
    xf, ls, le, flag = track_pcm({"id": "t", "mode": "xfade", "loop_start": 320,
                                  "loop_end": 2560}, pcm, 256)
    assert (ls, le, flag) == (320, 2560, 1) and len(xf) == 2560 + 256
    bk, ls, le, flag = track_pcm({"id": "t", "mode": "baked", "loop_start": 1024,
                                  "loop_end": 3072, "blend_samples": 512}, pcm, 256)
    # the blend's last weight is (n - 0.5) / n: within 1/n of the audio before ls
    step = np.abs(pcm[3071].astype(int) - pcm[1023]).max()
    assert flag == 0 and len(bk) == 3072
    assert np.abs(bk[-1].astype(int) - pcm[1023]).max() <= step / 512 + 1
    assert np.array_equal(bk[:3072 - 512], pcm[:3072 - 512])
    for bad in ({"mode": "xfade", "loop_start": 320, "loop_end": 3990},
                {"mode": "xfade", "loop_start": 33, "loop_end": 2560},
                {"mode": "baked", "loop_start": 256, "loop_end": 3072, "blend_samples": 512}):
        try:
            track_pcm({"id": "t", **bad}, pcm, 256)
        except ValueError:
            continue
        raise AssertionError(bad)
    assert stream_source("STAGE56_ch7.wav") == ("/XA/STAGE56.XA", 7)
    print("captcomm_psx builder self-test passed")
    return 0


def main(argv=None) -> int:
    p = argparse.ArgumentParser(description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--disc", type=Path, help=".chd, .cue or raw .bin of SLPS-01567")
    p.add_argument("--recipe", type=Path, default=RECIPE)
    p.add_argument("--out-dir", type=Path, default=PACKS_DIR)
    p.add_argument("--self-test", action="store_true")
    a = p.parse_args(argv)
    if a.self_test:
        return self_test()
    if not a.disc:
        p.error("--disc is required")
    build(a.disc, a.recipe, a.out_dir)
    return 0
