"""The SSF2 family's shared packs.

Every soundtrack for Super Street Fighter II, Super SF2 Turbo (with SSF2X,
EX and GMC) and Hyper SF2 is ONE pack that serves all three games, named
`ssf2_<source>`.  That works because:

  * all three number their music commands the same way -- the HSF2 AE
    dispatch table is the unified layout, and the standalone games were
    proven against it command by command
    (manifests/ssf2t_arrange_trigger_map.tsv);
  * all three share one control map: stop 0xff00 and the match-end fade
    0xff07 (protocols.CONTROL_SSF2 == CONTROL_HSF2);
  * each game sends only its own select/opening pair (attract and credit
    traces, 2026-09-24): SSF2 and HSF2 send 0x33/0x34, Turbo sends 0xd4/0xd3.

The builders import the rules below so every pack applies the same policy.
"""
from __future__ import annotations

from . import protocols
from .format import VERB_FADE_KEEP, VERB_STOP

PROTOCOL = protocols.PROTOCOLS["ssf2"]
GAME_ID = "ssf2"

# Turbo's own select (0xd3) and opening (0xd4).  A source with its own
# versions plays them; a source without plays its SSF2 select/opening there
# rather than falling back to the board -- Capcom's HSF2 makes the same
# choice, playing SSF2's pair itself.
TURBO_STAND_INS = {0xd3: 0x34, 0xd4: 0x33}

# Left to the board by every pack.  Akuma (0xd5/0xd6), CONGRATULATIONS
# (0xc1) and HSF2's READY TO FIGHT (0xe0) fail open only where a source has
# no cue of its own; no source substitutes for another's.
FAIL_OPEN = {
    0x38: "HERE COMES A NEW CHALLENGER plays over the BGM and hands it back",
    0x3d: "the native QSound logo",
}


def check_protocol(proto) -> None:
    """Raise unless `proto` is the family's shared contract."""
    if proto.control_verbs != {0xff00: VERB_STOP, 0xff07: VERB_FADE_KEEP}:
        raise ValueError(f"not the SSF2 family control map: {proto.control_verbs}")
    if (proto.latch_page, proto.off_arg_byte, proto.fade_law,
            proto.fade_const1, proto.fade_const2) != (0x618000, 0, 2, 0x444, 60):
        raise ValueError("not the SSF2 family latch/fade contract")
