"""`build_pack.py hsf2` — fully automatic packs from the HSF2 AE PS2 disc.

The Arrange and CPS1 banks become the SSF2 family's shared packs,
`ssf2_arrange` and `ssf2_cps1`: one pack each serving Super SF2, Super SF2
Turbo (with SSF2X, EX and GMC) and Hyper SF2 (pack/ssf2_family.py).
The disc's dispatch table IS the family's
unified command layout, so it keys both packs directly; the Arrange bank is
also checked row by row against the standalone games' own identification
(manifests/ssf2t_arrange_trigger_map.tsv).  Capcom's per-cue volume becomes
each track's gain, under one measured trigger gain per bank.  The CPS2 bank
still builds as `hsf2_cps2` on the HSF2 protocol, for research only.

Recipe (internal research notes):
  * boot ELF (from SYSTEM.CNF) carries the dispatch table at file offset
    0x63a0f0: 8-byte rows {u32 type; u8 afs_entry; u8 vol; u16 param},
    indexed by the arcade QSound command, cmd < 0x500.  Type 1 = BGM; the
    soundtrack bank adds +0x000 (Arrange) / +0x300 (CPS2) / +0x400 (CPS1)
    to the row index and re-reads entry/vol from the banked row.
  * HSF2.AFS holds all music as CRI ADX v4 stereo 48 kHz with sample-exact
    header loop points.  Blank entries ("___blank___.adx", 1 s silence) are
    the family's stop-to-silence idiom -> emitted as `stop` trigger rows.
  * cmd 0x00 is a no-op (never a music start in-game) -> left verb=none.

Generated map is cross-checked against manifests/hsf2_bgm_command_map.tsv.
"""
from __future__ import annotations

import hashlib
import re
import struct
from pathlib import Path

from . import protocols, ssf2_family
from .afs import AfsArchive
from .build_common import (adx_entry_to_track, crosscheck_pack, MANIFESTS,
                           PACKS_DIR)
from .format import PackWriter, TriggerRow, VERB_NONE, VERB_PLAY, VERB_STOP
from .isofs import IsoFS
from .sources import resolve_image

# Measured loudness match (EBU R128 vs the native chip music): one cold boot
# per command, tools/qsound_isolate.py, then tools/loudness_match.py.  The
# ssf2u and ssf2tu boards measure identically (Arrange 0x1d, CPS1 0x18) and
# hsf2 about 1 dB quieter (0x1a, 0x15), so each family pack takes the
# SSF2/Turbo value.  The old HSF2-only packs shipped 0x2d / 0x25, about 5 dB
# above the match.
TRIG_GAIN = {"arrange": 0x1d, "cps1": 0x18}
# The family packs each bank builds; any other bank is research-only.
PACK_NAMES = {"arrange": "ssf2_arrange", "cps1": "ssf2_cps1"}
TITLES = {"arrange": "SSF2 family arranged soundtrack (HSF2 AE PS2)",
          "cps1": "SSF2 family CPS-1 soundtrack (HSF2 AE PS2)"}
# the standalone games' own command identification (sound-test sweeps +
# in-game anchors); the disc table must agree with both, row for row
STANDALONE_ARRANGE_MAPS = (MANIFESTS / "ssf2_arrange_trigger_map.tsv",
                           MANIFESTS / "ssf2t_arrange_trigger_map.tsv")

# "HERE COMES A NEW CHALLENGER".  The PS2 dispatch table types 0x38 as BGM, so
# the generated table would claim it -- but on the ARCADE board (1.06b as well
# as the standalone 1.04 driver) the Z80 plays this cue OVER the running BGM
# and then hands the channels back, which no pack verb can express.  Claiming
# it replaced the music with a 2.35 s one-shot and left the game silent until
# the next command (28.6 s on the measured P2-joins-at-select route).  It
# therefore fails open to the board, like the native QSound logo at 0x3d.
# Evidence and method: manifests/ssf2_arrange_trigger_map.tsv.
NATIVE_RESTORE_CMDS = frozenset({0x38})


def _boot_elf_name(iso: IsoFS) -> str:
    cnf = iso.read_file("/SYSTEM.CNF").decode("ascii", "replace")
    m = re.search(r"BOOT2\s*=\s*cdrom0:\\([^;\s]+)", cnf)
    if not m:
        raise ValueError("cannot parse SYSTEM.CNF BOOT2")
    return m.group(1)


def _standalone_arrange_entries(path: Path) -> dict[int, int]:
    """cmd -> arrange entry from a standalone game's own identification."""
    rows = [line for line in path.read_text(encoding="utf-8").splitlines()
            if line.strip() and not line.startswith("#")]
    hdr = rows[0].split("\t")
    out = {}
    for line in rows[1:]:
        f = dict(zip(hdr, line.split("\t")))
        out[int(f["cmd"], 16)] = int(f["arrange_entry"])
    return out


def _load_manifest_map(bank: str) -> dict[int, tuple[int, int, str]]:
    """cmd -> (afs_entry, vol, in_game) for the chosen bank, from the TSV."""
    path = MANIFESTS / "hsf2_bgm_command_map.tsv"
    if not path.exists():
        return {}
    want_set = {"arrange": "ARRANGE", "cps2": "CPS2", "cps1": "CPS1"}[bank]
    out = {}
    rows = path.read_text(encoding="utf-8").splitlines()
    hdr = rows[0].split("\t")
    for line in rows[1:]:
        f = dict(zip(hdr, line.split("\t")))
        if f["set"] != want_set:
            continue
        out[int(f["cmd"], 16)] = (int(f["afs_entry"]), int(f["vol"], 16),
                                  f["in_game"])
    return out


def build(iso_path: str, out: str | None = None, bank: str = "arrange",
          table_offset: int | None = None, crosscheck: bool = True) -> Path:
    if bank not in protocols.HSF2_BANKS:
        raise ValueError(f"bank must be one of {list(protocols.HSF2_BANKS)}")
    bank_off = protocols.HSF2_BANKS[bank]
    table_offset = table_offset or protocols.HSF2_TABLE_OFFSET

    img = resolve_image(iso_path, member_hint=".iso")
    iso = IsoFS(img)
    elf_name = _boot_elf_name(iso)
    elf = iso.read_file("/" + elf_name)
    md5 = hashlib.md5(elf).hexdigest()
    if md5 != protocols.HSF2_ELF_MD5:
        # non-JP disc: region ELFs relocate the (byte-identical) table, so
        # locate it by signature; the manifest cross-check below still
        # hard-gates the result.  EU verified (+0x1200).
        first = elf.find(protocols.HSF2_TABLE_NEEDLE)
        hits = ([] if first < 0 else
                [first] if elf.find(protocols.HSF2_TABLE_NEEDLE,
                                    first + 1) < 0 else [first, -1])
        if len(hits) == 1 and table_offset == protocols.HSF2_TABLE_OFFSET:
            table_offset = hits[0]
            print(f"[hsf2] boot ELF {elf_name} (md5 {md5}) is not the "
                  f"verified JP disc; dispatch table located by signature "
                  f"at 0x{table_offset:x}")
        elif not hits:
            raise SystemExit(
                f"{elf_name}: dispatch-table signature not found in this "
                f"region's ELF -- pass --table-offset (see the docstring)")
    table = elf[table_offset:table_offset + protocols.HSF2_TABLE_ROWS * 8]

    from .build_common import iso_find_basename
    afs_path, afs_lba, afs_size = iso_find_basename(iso, protocols.HSF2_AFS_NAME)
    afs = AfsArchive(iso.f, iso.byte_offset(afs_lba))

    family = bank in PACK_NAMES
    if family:
        proto = ssf2_family.PROTOCOL
        ssf2_family.check_protocol(proto)
        title = TITLES[bank]
    else:
        proto = protocols.get_protocol("hsf2")
        title = f"HSF2 AE {bank} soundtrack (PS2 SLPM-65496)"
    w = PackWriter(proto, title=title)

    def row(idx: int) -> tuple[int, int, int, int]:
        t, = struct.unpack_from("<I", table, idx * 8)
        entry = table[idx * 8 + 4]
        vol = table[idx * 8 + 5]
        param, = struct.unpack_from("<H", table, idx * 8 + 6)
        return t & 0x7f, entry, vol, param

    track_of_entry: dict[int, int] = {}
    track_sources: dict[int, int] = {}
    generated: dict[int, tuple[int, int]] = {}   # cmd -> (entry, vol)
    vol_of_entry: dict[int, int] = {}
    stand_ins: dict[int, int] = {}               # cmd -> the command it borrows
    n_play = n_stop = 0
    # Command space is < 0x300: rows 0x300..0x4ff are the CPS2/CPS1 BANK ROW
    # area the dispatcher indexes at cmd+0x300/cmd+0x400, not commands
    # (music commands top out at 0xe4; 0x1xx/0x2xx are SE/voice types 3-6).
    for cmd in range(1, min(0x300, protocols.HSF2_TABLE_ROWS - bank_off)):
        typ, _, _, _ = row(cmd)
        if typ != protocols.HSF2_TYPE_BGM:
            continue
        if cmd in NATIVE_RESTORE_CMDS:
            continue
        _, entry, vol, _ = row(cmd + bank_off)
        generated[cmd] = (entry, vol)
        if (family and cmd in ssf2_family.TURBO_STAND_INS
                and afs.name(entry).startswith("___blank")):
            # This bank has no Turbo select/opening of its own (Capcom left
            # the rows blank because HSF2 never sends them); Turbo does, so
            # the family pack plays the bank's SSF2 one there.
            src = ssf2_family.TURBO_STAND_INS[cmd]
            _, entry, vol, _ = row(src + bank_off)
            stand_ins[cmd] = src
        name = afs.name(entry)
        if name.startswith("___blank"):
            w.set_trigger(cmd, TriggerRow(
                verb=VERB_STOP, gain=TRIG_GAIN.get(bank, 0x7f), suppress=1))
            n_stop += 1
            continue
        if family:
            # Capcom's per-cue volume is the track's gain; the measured
            # loudness match is the trigger's
            track_gain, trig_gain = min(vol, 0x7f), TRIG_GAIN[bank]
            if vol_of_entry.setdefault(entry, vol) != vol:
                raise ValueError(f"AFS entry {entry} carries two volumes "
                                 f"(0x{vol_of_entry[entry]:02x}, 0x{vol:02x})")
        else:
            track_gain, trig_gain = 0x7f, min(vol, 0x7f)
        if entry not in track_of_entry:
            raw = afs.read(entry)
            stream, meta, _ = adx_entry_to_track(
                raw, name=name, source=f"HSF2.AFS#{entry}", gain=track_gain)
            ti = w.add_track(stream, meta)
            track_of_entry[entry] = ti
            track_sources[ti] = entry
        w.set_trigger(cmd, TriggerRow(
            verb=VERB_PLAY, track=track_of_entry[entry],
            gain=trig_gain, suppress=1))
        n_play += 1

    # cross-check the generated map against the tracked manifest
    manifest = _load_manifest_map(bank)
    mismatches = []
    unexpected = [c for c in generated if manifest and c not in manifest]
    if unexpected:
        raise AssertionError(
            f"ELF table yields commands absent from the verified manifest: "
            + " ".join(f"0x{c:03x}" for c in unexpected[:10]))
    for cmd, (entry, vol) in generated.items():
        if cmd in manifest and manifest[cmd][:2] != (entry, vol):
            mismatches.append((cmd, (entry, vol), manifest[cmd][:2]))
    # cmd 0x00 is deliberately skipped (no-op guard); manifest rows the ELF
    # types as non-BGM (e.g. native QSound-logo command 0x3d) are expected to
    # be absent and therefore fail open to the arcade sound hardware.
    missing_ingame = [c for c, (_, _, ig) in manifest.items()
                      if c not in generated and c != 0 and ig == "yes"
                      and c not in NATIVE_RESTORE_CMDS]
    missing_other = [c for c, (_, _, ig) in manifest.items()
                     if c not in generated and c != 0
                     and (ig != "yes" or c in NATIVE_RESTORE_CMDS)]
    if mismatches or missing_ingame:
        raise AssertionError(
            f"ELF table does not match hsf2_bgm_command_map.tsv: "
            f"mismatches={mismatches[:5]} missing={missing_ingame[:5]}")
    if bank == "arrange":
        # the standalone games' own identification must agree row for row
        for path in STANDALONE_ARRANGE_MAPS:
            standalone = _standalone_arrange_entries(path)
            disagree = {c: (generated.get(c, (None,))[0], e)
                        for c, e in standalone.items()
                        if generated.get(c, (None,))[0] != e}
            if disagree:
                raise AssertionError(
                    f"disc table and {path.name} disagree (cmd: disc, "
                    "standalone): " + " ".join(
                        f"0x{c:02x}:{d}" for c, d in sorted(disagree.items())[:8]))
    if missing_other:
        print(f"[hsf2:{bank}] note: manifest rows not typed BGM by the ELF "
              f"(native/sound-test-only slots), skipped: "
              + " ".join(f"0x{c:02x}" for c in missing_other))

    out_path = Path(out) if out else PACKS_DIR / (
        f"{PACK_NAMES[bank]}.cpk" if family else f"hsf2_{bank}.cpk")
    w.write(out_path)
    from .format import PackReader
    rd = PackReader(out_path)
    try:
        for cmd in sorted(NATIVE_RESTORE_CMDS
                          | (set(ssf2_family.FAIL_OPEN) if family else set())):
            trg = rd.triggers[cmd]
            if trg.verb != VERB_NONE or trg.suppress:
                raise ValueError(f"readback: command 0x{cmd:02x} must pass "
                                 "through to native QSound")
        if family:
            ssf2_family.check_protocol(rd.header.proto)
            for cmd, src in ssf2_family.TURBO_STAND_INS.items():
                got = rd.triggers[cmd]
                if got.verb != VERB_PLAY:
                    raise ValueError(f"readback: Turbo command 0x{cmd:02x} "
                                     "does not play")
                if cmd in stand_ins and got.track != rd.triggers[src].track:
                    raise ValueError(f"readback: 0x{cmd:02x} does not play "
                                     f"0x{src:02x}'s track")
    finally:
        rd.close()
    size = out_path.stat().st_size
    if stand_ins:
        print(f"[hsf2:{bank}] Turbo stand-ins: " + ", ".join(
            f"0x{c:02x} plays 0x{s:02x}'s track" for c, s in sorted(stand_ins.items())))
    print(f"[hsf2:{bank}] {out_path}  {size / 1e6:.1f} MB, "
          f"{len(w.tracks)} tracks, {n_play} play + {n_stop} stop triggers "
          f"(manifest cross-check OK: {len(manifest)} rows)")

    if crosscheck:
        res = crosscheck_pack(out_path, afs, track_sources)
        print(f"[hsf2:{bank}] byte-exact vs HSF2.AFS: "
              f"{res['byte_exact_tracks']}/{len(track_sources)} tracks; "
              f"decode-exact: {res['decode_exact_tracks']} tracks")
    iso.close()
    return out_path
