"""PlayStation XA-ADPCM streams read straight from a disc image.

A PlayStation XA file interleaves several audio streams, one per subheader
channel, in Mode 2 Form 2 sectors.  The ISO directory's size counts 2,048
bytes a sector, but a Form 2 sector carries 2,324, so the audio can only be
recovered from the raw 2,352-byte sectors.  Nothing here reads the 2,048-byte
view of an XA file.

Inputs are what a user owns: a .cue with its single MODE2/2352 bin, the bin
itself, or a MAME .chd (extracted once with chdman into work/cache/, a cache
that is rebuilt whenever it is missing or no longer describes its source).
The catalog that consumes this pins the bin's SHA-256 and every stream's
sectors and PCM, so a wrong or damaged image fails there, not silently.

Decoding goes through FFmpeg's psxstr demuxer (adpcm_xa, integer
arithmetic).  `decode_reference` is an independent pure-Python decoder that
the self-test holds FFmpeg to, sample for sample.
"""
from __future__ import annotations

import hashlib
import json
import shutil
import subprocess
from pathlib import Path

import numpy as np

from .isofs import IsoFS, S2352
from .sources import CACHE_DIR, resolve_image

SYNC = b"\x00" + b"\xff" * 10 + b"\x00"
SM_AUDIO, SM_FORM2, SM_EOF = 0x04, 0x20, 0x80
XA_RATE = {0: 37800, 1: 18900}
FRAMES_PER_SECTOR = {1: 2016, 0: 4032}   # stereo / mono, 4-bit
STAMP = ".cpsplus_source.json"


# ------------------------------------------------------------ disc image ---
def _stamp(source: Path) -> dict:
    st = source.stat()
    return {"source": str(source.resolve()), "size": st.st_size,
            "mtime_ns": st.st_mtime_ns, "tool": "chdman extractcd"}


def disc_image(source: Path | str, cache_dir: Path | None = None) -> Path:
    """Path to the raw 2,352-byte data track of the user's rip."""
    source = Path(source)
    if not source.exists():
        raise FileNotFoundError(f"{source}: does not exist")
    if source.suffix.lower() != ".chd":
        return resolve_image(source)
    exe = shutil.which("chdman")
    if not exe:
        raise FileNotFoundError(
            f"{source.name}: need MAME's chdman to read a .chd "
            f"(it ships with MAME), or pass the rip's .cue instead")
    dest = (Path(cache_dir) if cache_dir else CACHE_DIR) / source.stem
    stamp = _stamp(source)
    img = dest / "track.bin"
    try:
        if json.loads((dest / STAMP).read_text()) == stamp and img.exists():
            return img
    except (OSError, ValueError):
        pass
    if dest.exists():
        shutil.rmtree(dest)
    tmp = dest.with_name(dest.name + ".partial")
    if tmp.exists():
        shutil.rmtree(tmp)
    tmp.mkdir(parents=True)
    print(f"[psx_xa] extracting {source.name} with chdman ...", flush=True)
    r = subprocess.run([exe, "extractcd", "-i", str(source),
                        "-o", str(tmp / "track.cue"), "-ob", str(tmp / "track.bin")],
                       capture_output=True, text=True)
    if r.returncode:
        shutil.rmtree(tmp, ignore_errors=True)
        raise ValueError(f"{source.name}: chdman failed: {(r.stderr or r.stdout)[-400:]}")
    cue = (tmp / "track.cue").read_text()
    if cue.count("TRACK") != 1 or "MODE2/2352" not in cue:
        shutil.rmtree(tmp, ignore_errors=True)
        raise ValueError(f"{source.name}: expected one MODE2/2352 track, got:\n{cue}")
    (tmp / STAMP).write_text(json.dumps(stamp, indent=1))
    tmp.rename(dest)
    return img


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(1 << 22), b""):
            h.update(block)
    return h.hexdigest()


# ------------------------------------------------------------ XA streams ---
class XaDisc:
    """The XA files of one PlayStation data track, read as raw sectors."""

    def __init__(self, image: Path):
        self.image = Path(image)
        self.iso = IsoFS(self.image)
        if self.iso.sector_size != S2352:
            raise ValueError(f"{image}: XA audio needs a raw 2,352-byte image")

    def raw_sectors(self, lba: int, count: int) -> list[bytes]:
        self.iso.f.seek(lba * S2352)
        data = self.iso.f.read(count * S2352)
        if len(data) != count * S2352:
            raise ValueError(f"{self.image}: image ends inside LBA {lba}+{count}")
        return [data[i:i + S2352] for i in range(0, len(data), S2352)]

    def xa_file(self, path: str) -> "XaFile":
        full, lba, size, isdir = self.iso.find(path)
        if isdir:
            raise IsADirectoryError(path)
        return XaFile(full, lba, self.raw_sectors(lba, (size + 2047) // 2048))


class XaFile:
    def __init__(self, path: str, lba: int, sectors: list[bytes]):
        self.path, self.lba, self.sectors = path, lba, sectors
        for i, s in enumerate(sectors):
            if s[:12] != SYNC or s[15] != 2 or s[16:20] != s[20:24]:
                raise ValueError(f"{path}: sector {i} is not Mode 2 with a "
                                 f"doubled subheader")

    def channels(self) -> list[int]:
        return sorted({s[17] for s in self.sectors if s[18] & SM_AUDIO})

    def stream(self, channel: int) -> "XaStream":
        idx = [i for i, s in enumerate(self.sectors)
               if s[17] == channel and s[18] & SM_AUDIO]
        if not idx:
            raise ValueError(f"{self.path}: no audio on channel {channel}")
        return XaStream(self.path, channel, idx, [self.sectors[i] for i in idx])


class XaStream:
    """One channel's audio sectors, in disc order."""

    def __init__(self, path: str, channel: int, positions: list[int],
                 sectors: list[bytes]):
        self.path, self.channel = path, channel
        self.positions = positions      # file-relative interleaved sector index
        self.sectors = sectors
        codings = {s[19] for s in sectors}
        forms = {bool(s[18] & SM_FORM2) for s in sectors}
        if len(codings) != 1 or forms != {True}:
            raise ValueError(f"{path} ch{channel}: mixed codings {codings} / "
                             f"forms {forms}")
        self.coding = codings.pop()
        if self.coding & 0x30:
            raise ValueError(f"{path} ch{channel}: 8-bit XA is not supported")
        self.stereo = bool(self.coding & 1)
        self.rate = XA_RATE[(self.coding >> 2) & 3]
        self.eof = [p for p, s in zip(positions, sectors) if s[18] & SM_EOF]

    @property
    def frames(self) -> int:
        return len(self.sectors) * FRAMES_PER_SECTOR[int(self.stereo)]

    def raw(self) -> bytes:
        return b"".join(self.sectors)

    def decode(self) -> np.ndarray:
        """int16 PCM, shape (frames, channels), via FFmpeg's adpcm_xa."""
        exe = shutil.which("ffmpeg")
        if not exe:
            raise FileNotFoundError("need ffmpeg on PATH to decode XA audio")
        r = subprocess.run([exe, "-v", "error", "-f", "psxstr", "-i", "pipe:0",
                            "-f", "s16le", "-acodec", "pcm_s16le", "pipe:1"],
                           input=self.raw(), capture_output=True, check=True)
        pcm = np.frombuffer(r.stdout, "<i2").reshape(-1, 2 if self.stereo else 1)
        if len(pcm) != self.frames:
            raise ValueError(f"{self.path} ch{self.channel}: FFmpeg decoded "
                             f"{len(pcm)} frames, expected {self.frames}")
        return pcm


# ------------------------------------------------- reference XA decoder ---
_K = ((0, 0), (60, 0), (115, -52), (98, -55))


def decode_reference(raw: bytes, stereo: bool = True) -> np.ndarray:
    """Pure-Python 4-bit XA decode (psx-spx 'XA-ADPCM'); slow, for tests."""
    hist = [[0, 0], [0, 0]]
    out: list[list[int]] = [[], []]
    for so in range(0, len(raw), S2352):
        sec = raw[so + 24:so + 24 + 2304]
        for g in range(18):
            grp = sec[g * 128:(g + 1) * 128]
            for u in range(8):
                hdr = grp[4 + u]
                shift, (k0, k1) = hdr & 15, _K[(hdr >> 4) & 3]
                if shift > 12:
                    shift = 9
                c = u & 1 if stereo else 0
                s1, s2 = hist[c]
                for j in range(28):
                    n = (grp[16 + j * 4 + (u >> 1)] >> ((u & 1) * 4)) & 15
                    n = n - 16 if n >= 8 else n
                    v = ((n << 12) >> shift) + ((s1 * k0 + s2 * k1 + 32) >> 6)
                    v = -32768 if v < -32768 else 32767 if v > 32767 else v
                    s2, s1 = s1, v
                    out[c].append(v)
                hist[c] = [s1, s2]
    if stereo:
        return np.stack([np.array(out[0], "<i2"), np.array(out[1], "<i2")], 1)
    return np.array(out[0], "<i2").reshape(-1, 1)


def pcm_sha256(pcm: np.ndarray) -> str:
    return hashlib.sha256(np.ascontiguousarray(pcm, "<i2").tobytes()).hexdigest()
