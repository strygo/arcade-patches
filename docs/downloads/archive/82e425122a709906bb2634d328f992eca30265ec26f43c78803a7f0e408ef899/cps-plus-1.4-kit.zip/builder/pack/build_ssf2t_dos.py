#!/usr/bin/env python3
"""Build the MS-DOS Super Street Fighter II Turbo packs (OPL / GS / MT-32 / CD).

They are SSF2 family packs (pack/ssf2_family.py), `ssf2_dos_{fm,sc55,mt32,cd}`:
each file serves Super SF2, Super SF2 Turbo (with SSF2X, EX and GMC) and
Hyper SF2.  The DOS port has one select and one opening, so they answer both
SSF2's commands (0x33/0x34) and Turbo's (0xd4/0xd3); it has no Akuma theme.

One arrangement, three device renderings -- the disc's own `sb16/`, `sc55/`
and `mt32/` HMISET.CFG presets -- so one builder and one trigger map serve all
three.  They are separate packs rather than one with a switch because they
sound nothing alike and, in six songs, are not even the same edit.

Sources are the loop-tagged FLACs from `tools/render_dos_opl.py`,
`render_dos_midi.py` and `render_dos_mt32.py`.  Each carries the SOURCE loop
in Vorbis comments and ends exactly on LOOPEND; the pack's loop is that loop
shifted back by one crossfade second, so the last stored second is the tail
the player blends and the wrap joins audio that is already repeating.

Roles come from `manifests/ssf2t_dos_map.tsv`, which joins DOS stems onto the
closed 67-row `ssf2t_arrange_trigger_map.tsv`.  Commands with no DOS
counterpart are simply left unmapped and fail open to the board's own QSound,
the `build_ffight_ost.py` precedent.

0x38 (HERE COMES ...) must never be mapped: it is restore-class -- the Z80
plays it over the running BGM and hands the channels back -- so a PLAY row
costs the player its music.  See the note in the arrange map.

Run through the uniform entry point:
  build_pack.py ssf2t-dos --device fm --flac-dir <dir>
"""
from __future__ import annotations

import argparse
import csv
import json
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path

import numpy as np

from . import adxcodec, ssf2_family
from .adxencode import encode_adx_track
from .build_common import MANIFESTS, PACKS_DIR
from .format import (CODEC_ADX, VERB_NONE, VERB_PLAY, PackReader,
                     PackWriter, TrackMeta, TriggerRow)

MAP_TSV = MANIFESTS / "ssf2t_dos_map.tsv"
TRIGGER_ROWS = 0x1200
CHANNELS = 2

# Restore-class: played OVER the running BGM, channels handed back.  A PLAY row
# here replaces the arranged track with a one-shot nothing restarts (28.6 s of
# measured silence).  A board poke sweep over 0x11-0x40 found this to be the
# only such command on the 1.04 driver.
NATIVE_RESTORE_CMDS = frozenset({0x38})


# The bar-grid placement (tools/cd_bar_loops.py): the period from the
# sequence scaled by the measured tempo ratio, the grid and phase from the
# CD's own onset envelope.  An earlier table carried the sequence's loop
# across unchanged and failed its ear gate -- the CD is a separately edited
# production and does not sit at the sequences' phase -- so it is not used.
CD_LOOPS_TSV = MANIFESTS / "ssf2t_dos_cd_bargrid.tsv"


@dataclass(frozen=True)
class Device:
    key: str
    letter: str          # the HMP device letter: F (OPL), G (GS), M (MT-32);
                         # "" for the CD, whose pieces are named by stem alone
    rate: int
    trigger_gain: int
    pack_name: str
    title: str
    note: str


# Trigger gains are EBU R128 matches against the native QSound level, anchored
# on the shipped ssf2t_arrange pack: its 66 rows all play at 0x1d, which was
# measured on the board, so the native level is that pack's own loudness minus
# 12.83 dB.  Each device set was then measured over the sixteen stage themes
# and given the gain that lands it there.  Re-measure against a real service
# sweep when one exists; this is an anchor, not a board measurement.
DEVICES = {
    "fm": Device(
        "fm", "F", 49_716, 0x59, "ssf2_dos_fm.cpk",
        "Super Street Fighter II Turbo (MS-DOS FM Soundtrack)",
        "Nuked OPL3 at its own 49716 Hz, one chip, the disc's own banks"),
    "sc55": Device(
        "sc55", "G", 48_000, 0x15, "ssf2_dos_sc55.cpk",
        "Super Street Fighter II Turbo (MS-DOS Sound Canvas Soundtrack)",
        "Nuked-SC55, the disc's sc55 preset device"),
    "mt32": Device(
        "mt32", "M", 48_000, 0x22, "ssf2_dos_mt32.cpk",
        "Super Street Fighter II Turbo (MS-DOS MT-32 Soundtrack)",
        "Munt mt32_1_07, the disc's mt32 preset device"),
    # The Red Book audio.  Its pieces come from tools/slice_dos_cd.py and its
    # loops from CD_LOOPS_TSV above, placed on the recording's own metrical
    # grid.  A piece whose loop would not place is left OUT, so its command
    # fails open to the board instead of playing something that stops.
    "cd": Device(
        "cd", "", 44_100, 0x27, "ssf2_dos_cd.cpk",
        "Super Street Fighter II Turbo (MS-DOS CD Soundtrack)",
        "the disc's own Red Book audio"),
}


def load_cd_loops(path: Path = CD_LOOPS_TSV) -> dict[str, tuple[float, float] | None]:
    """piece -> (loop_start, loop_end) in seconds, None for a one-shot.

    Pieces marked `open` are absent from the result: their loop could not be
    derived, and a stage theme that stops after a minute is worse than one the
    board plays itself.
    """
    out: dict[str, tuple[float, float] | None] = {}
    with path.open(newline="", encoding="utf-8") as handle:
        for row in csv.DictReader(
                (line for line in handle
                 if line.strip() and not line.startswith("#")), delimiter="\t"):
            if row["confidence"] == "one-shot":
                out[row["piece"]] = None
            elif row["confidence"] in ("high", "medium"):
                out[row["piece"]] = (float(row["loop_start"]),
                                     float(row["loop_end"]))
    return out


@dataclass(frozen=True)
class Row:
    command: int
    role: str
    song: str
    confidence: str


def load_map(path: Path = MAP_TSV) -> list[Row]:
    rows: list[Row] = []
    seen: set[int] = set()
    with path.open(newline="", encoding="utf-8") as handle:
        for raw in csv.DictReader(
                (line for line in handle
                 if line.strip() and not line.startswith("#")),
                delimiter="\t"):
            command = int(raw["cmd"], 0)
            if command in seen:
                raise ValueError(f"duplicate command 0x{command:02x}")
            if command in NATIVE_RESTORE_CMDS:
                raise ValueError(
                    f"0x{command:02x} is restore-class and must stay unmapped")
            seen.add(command)
            rows.append(Row(command, raw["role"], raw["dos_song"],
                            raw["confidence"]))
    if not rows:
        raise ValueError(f"{path}: no rows")
    return rows


def probe(path: Path) -> tuple[int, int, dict[str, int]]:
    out = subprocess.run(
        ["ffprobe", "-v", "error", "-select_streams", "a:0", "-show_entries",
         "stream=sample_rate,channels:format_tags", "-of", "json", str(path)],
        capture_output=True, text=True, check=True).stdout
    info = json.loads(out)
    stream = info["streams"][0]
    tags = {key.upper(): int(value) for key, value in
            info.get("format", {}).get("tags", {}).items()
            if key.upper().startswith("LOOP") and value.lstrip("-").isdigit()}
    return int(stream["sample_rate"]), int(stream["channels"]), tags


def decode(path: Path) -> np.ndarray:
    """The FLAC's samples as s16 frames.

    Decoded to s32 and shifted, exactly as `build_ssf2_x68k_midi.py` does it:
    an arithmetic shift is a floor with no dither, so the result cannot depend
    on the CPU.  A 16-bit source round-trips through this untouched.
    """
    raw = subprocess.run(
        [adxcodec.FFMPEG, "-v", "error", "-i", str(path), "-map", "0:a:0",
         "-f", "s32le", "-acodec", "pcm_s32le", "-"],
        capture_output=True, check=True).stdout
    s32 = np.frombuffer(raw, dtype="<i4")
    if s32.size % CHANNELS:
        raise ValueError(f"{path.name}: decoded PCM ends mid-frame")
    return (s32 >> 16).astype("<i2").reshape(-1, CHANNELS)


def source_name(stem: str, letter: str) -> str:
    """The rendered file's stem for a map entry on a given device.

    The disc names a critical variant by infixing KO rather than adding a
    suffix: base CHUN is CHUN_G, its critical variant is CHUN_KOG.  The map
    carries the device-independent stem (CHUN, CHUN_KO), so the device letter
    joins directly onto a _KO stem and with an underscore otherwise.
    """
    if not letter:
        return stem                      # CD pieces are named by stem alone
    return f"{stem}{letter}" if stem.endswith("_KO") else f"{stem}_{letter}"


def _align32(value: int) -> int:
    return value // 32 * 32


def xfade_samples(rate: int) -> int:
    """One second of crossfade, rounded down to the ADX frame grid.

    ADX codes 32 samples per frame, so every stored offset -- the loop points
    AND the end of the kept audio -- has to sit on a multiple of 32.  At 48 kHz
    a one-second crossfade already does (48000 = 1500 frames); at the OPL
    pack's 49716 Hz it does not, and an unaligned tail leaves the encoder
    padding past the length the player expects.  49696 samples is 0.99960 s.
    """
    return _align32(rate)


def build(*, device: str, flac_dir: Path, out: Path | None = None,
          map_path: Path = MAP_TSV, measure_snr: bool = False) -> dict:
    spec = DEVICES[device]
    rows = load_map(map_path)
    proto = ssf2_family.PROTOCOL
    ssf2_family.check_protocol(proto)

    cd_loops = load_cd_loops() if device == "cd" else None
    writer = PackWriter(proto, title=spec.title, trigger_rows=TRIGGER_ROWS,
                        default_rate=spec.rate,
                        xfade_samples=xfade_samples(spec.rate))
    track_of: dict[str, int] = {}
    unbuilt: list[str] = []
    snrs: list[tuple[str, float]] = []
    loops = 0

    print(f"[ssf2t-dos:{device}] === {spec.title} ===")
    print(f"[ssf2t-dos:{device}] {spec.note}; trigger gain 0x{spec.trigger_gain:02x}")
    for song in sorted({row.song for row in rows}):
        if cd_loops is not None and song not in cd_loops:
            unbuilt.append(song)
            continue
        source = flac_dir / f"{source_name(song, spec.letter)}.flac"
        if not source.is_file():
            if cd_loops is not None:
                unbuilt.append(song)
                continue
            raise FileNotFoundError(f"missing rendered source: {source}")
        rate, channels, tags = probe(source)
        if (rate, channels) != (spec.rate, CHANNELS):
            raise ValueError(f"{source.name}: {rate} Hz/{channels}ch, expected "
                             f"{spec.rate} Hz stereo")
        pcm = decode(source)

        if cd_loops is not None:
            # The CD's loop is the MUSICAL loop, derived from the sequence, and
            # the recording continues past it into the closing fade.  So the
            # pack's loop IS that loop and the stored tail is the second after
            # it -- measured to sit at body level, which is what the player's
            # equal-power blend needs.  That is the opposite of the rendered
            # packs, whose loop had to be shifted back because their audio was
            # truncated at the loop end.
            span = cd_loops[song]
            if span is not None and song.endswith("_KO"):
                # The CD's critical variants do not loop (ear-verified 2026-09-19).
                # Each is ~62 s of through-composed music with no repeat in it
                # -- measured: no exact copy at the sequence's period, best
                # waveform NCC 0.045-0.227 -- so any loop here is a join we
                # invented rather than one the recording offers, and at
                # periods from 6 s to 50 s it would be heard constantly.  A
                # danger cue that runs 62 s and stops is the better trade.
                # The RENDERED packs keep their loops: those come from the
                # sequence and are real.
                span = None
            if span is None:
                keep, ls, le, xfade_enable, kind = len(pcm), 0, 0, 0, "one-shot"
            else:
                xfade = xfade_samples(spec.rate)
                ls = _align32(round(span[0] * spec.rate))
                le = _align32(round(span[1] * spec.rate))
                if le - ls <= xfade:
                    raise ValueError(f"{source.name}: loop shorter than the crossfade")
                keep = le + xfade
                if keep > len(pcm):
                    raise ValueError(
                        f"{source.name}: needs {keep} frames for the crossfade "
                        f"tail but the piece holds {len(pcm)}")
                pcm = pcm[:keep]
                xfade_enable, kind = 1, "xfade loop"
                loops += 1
        elif "LOOPSTART" in tags:
            source_ls, source_le = tags["LOOPSTART"], tags["LOOPEND"]
            if source_le != len(pcm):
                raise ValueError(
                    f"{source.name}: LOOPEND {source_le} but the file holds "
                    f"{len(pcm)} frames; the render must end on its loop")
            xfade = xfade_samples(spec.rate)
            pack_ls, pack_le = _align32(source_ls - xfade), _align32(source_le - xfade)
            if pack_ls < 0:
                raise ValueError(f"{source.name}: loop starts inside the crossfade")
            if pack_le - pack_ls <= xfade:
                raise ValueError(f"{source.name}: loop body shorter than the crossfade")
            keep = pack_le + xfade
            if keep > len(pcm):
                raise ValueError(f"{source.name}: crossfade tail runs past the file")
            pcm = pcm[:keep]
            ls, le, xfade_enable, kind = pack_ls, pack_le, 1, "xfade loop"
            loops += 1
        else:
            keep, ls, le, xfade_enable, kind = len(pcm), 0, 0, 0, "one-shot"

        data, coef1, coef2, snr = encode_adx_track(
            pcm.tobytes(), spec.rate, CHANNELS, keep, song, measure_snr)
        if snr is not None:
            snrs.append((song, snr))
        meta = TrackMeta(
            sample_rate=spec.rate, channels=CHANNELS, codec=CODEC_ADX,
            gain=0x7F,
            loop_start_sample=ls,
            loop_start_byte=(adxcodec.samples_to_stream_byte(ls, CHANNELS)
                             if xfade_enable else 0),
            loop_end_sample=le,
            loop_end_byte=(adxcodec.samples_to_stream_byte(le, CHANNELS)
                           if xfade_enable else 0),
            coef1=coef1, coef2=coef2, xfade_enable=xfade_enable,
            name=f"{song} ({kind})",
            source=f"dos/{device}/{source.name}")
        index = writer.add_track(data, meta)
        track_of[song] = index
        print(f"[ssf2t-dos:{device}] t{index:02d} {song:10s} "
              f"{keep / spec.rate:7.2f}s  {kind:<11} {len(data) / 1e6:6.2f} MB")

    for row in rows:
        if row.song not in track_of:
            continue
        writer.set_trigger(
            row.command,
            TriggerRow(verb=VERB_PLAY, track=track_of[row.song],
                       gain=spec.trigger_gain, suppress=1))

    out_path = out or (PACKS_DIR / spec.pack_name)
    writer.write(out_path)

    reader = PackReader(str(out_path))
    try:
        if reader.header.game_id != ssf2_family.GAME_ID:
            raise ValueError("readback: wrong game id")
        if reader.header.trigger_rows != TRIGGER_ROWS:
            raise ValueError("readback: wrong trigger table size")
        ssf2_family.check_protocol(reader.header.proto)
        mapped = {row.command for row in rows if row.song in track_of}
        for row in rows:
            if row.song not in track_of:
                continue
            got = reader.triggers[row.command]
            if (got.verb, got.track, got.gain, got.suppress) != (
                    VERB_PLAY, track_of[row.song], spec.trigger_gain, 1):
                raise ValueError(
                    f"readback: 0x{row.command:02x} does not map to {row.song}")
        for command, got in enumerate(reader.triggers):
            if command in mapped:
                continue
            if got.verb != VERB_NONE or got.suppress:
                raise ValueError(
                    f"readback: unmapped 0x{command:04x} does not fail open")
        for command in NATIVE_RESTORE_CMDS:
            got = reader.triggers[command]
            if got.verb != VERB_NONE or got.suppress:
                raise ValueError(
                    f"readback: restore-class 0x{command:02x} must fail open")
    finally:
        reader.close()

    size = out_path.stat().st_size
    if snrs:
        mean = sum(value for _, value in snrs) / len(snrs)
        worst = min(snrs, key=lambda item: item[1])
        print(f"[ssf2t-dos:{device}] ADX SNR mean {mean:.2f} dB, worst "
              f"{worst[0]} {worst[1]:.2f} dB")
    played = sum(1 for row in rows if row.song in track_of)
    if unbuilt:
        print(f"[ssf2t-dos:{device}] {len(set(unbuilt))} piece(s) left out (no "
              f"derivable loop); their commands fail open: "
              f"{', '.join(sorted(set(unbuilt)))}")
    print(f"[ssf2t-dos:{device}] {out_path}: {len(track_of)} tracks, "
          f"{played} play commands, {loops} loops, {size / 1e6:.1f} MB")
    return {"path": out_path, "size": size, "tracks": len(track_of),
            "commands": played, "loops": loops, "snrs": snrs}


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--device", required=True, choices=sorted(DEVICES))
    ap.add_argument("--flac-dir", required=True, type=Path)
    ap.add_argument("--out", type=Path)
    ap.add_argument("--map", type=Path, default=MAP_TSV)
    ap.add_argument("--measure-snr", action="store_true")
    args = ap.parse_args(argv)
    build(device=args.device, flac_dir=args.flac_dir, out=args.out,
          map_path=args.map, measure_snr=args.measure_snr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
