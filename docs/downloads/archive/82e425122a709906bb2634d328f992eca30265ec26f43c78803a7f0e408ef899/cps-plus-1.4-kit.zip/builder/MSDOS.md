# CPS+ — the MS-DOS Super Street Fighter II Turbo soundtracks

Four packs, one disc. The 1995 MS-DOS port (GameTek/Eurocom) shipped its score
on four carriers, and they sound nothing alike, so each one is its own pack
rather than a setting inside one:

| pack | MRA tier | the carrier |
|---|---|---|
| `ssf2_dos_fm` | (MS-DOS FM Soundtrack) | the OPL3 chiptune, played on the disc's own instrument banks |
| `ssf2_dos_sc55` | (MS-DOS Sound Canvas Soundtrack) | the General MIDI score on a Roland Sound Canvas |
| `ssf2_dos_mt32` | (MS-DOS MT-32 Soundtrack) | the same score on a Roland MT-32 |
| `ssf2_dos_cd` | (MS-DOS CD Soundtrack) | the disc's Red Book audio |

Each pack plays in all three games of the family: Super Street Fighter II,
Super Street Fighter II Turbo (Super Street Fighter II X in Japan) and Hyper
Street Fighter II, each in its USA, Japan and Asia versions. The tier
names are the game's own. Its 1995 setup utility offers "Roland Sound Canvas" and "MT-32" by
those names, so the MRAs use them.

Three of the four have no recording to copy: the game ships MIDI sequences and
the sound came from whatever device you had. So the kit renders them on your
machine, the way the published packs were rendered — same sequences, same
firmware, same emulator at the same pinned revision — and then checks the
result against the published pack hash, like every other pack. The CD pack is
the exception: that audio *is* on the disc.

## What you supply

**The game.** Point `ssf2t_dos_disc` at your copy — a folder, or a `.zip`/`.7z`
of one. The CD release; it holds the MIDI sets for all three synthesizers plus
the Red Book audio.

**Synthesizer ROMs, for two of the four.** These are never downloaded.

| for | key | files |
|---|---|---|
| `ssf2_dos_sc55` | `sc55_rom_dir` | your SC-55 v1.21 dump — the same set the X68000 packs use |
| `ssf2_dos_mt32` | `mt32_rom_dir` | `mt32_ctrl_1_07.rom`, `mt32_pcm.rom` |

Both are checked by hash before anything renders.

**A compiler, for three of the four.** `ssf2_dos_fm`, `_sc55` and `_mt32` each
build a small open-source renderer once, from a pinned revision: git, cmake and
a C/C++ compiler. `ssf2_dos_cd` needs none of that. You also need `ffmpeg` and
`ffprobe` on PATH, as the other packs do.

Give it the disc and nothing else and you get the CD and FM packs; add each ROM
set to unlock its Roland pack. Jobs you cannot satisfy say so and skip.

## What gets built, and from where

`make_packs.py` calls `make_dos_flac.py` before the pack builder. You can run
it by hand:

```
python3 make_dos_flac.py --device sc55 --archive /dos/ssf2t.zip \
    --sc55-rom-dir /roms/sc55
```

It prints the finished FLAC directory as its last line, and chains:

- **fm** — `bnk2wopl.py` converts the disc's own `DRV/MELODIC.BNK` and
  `DRV/DRUM.BNK`, so the timbres are the game's rather than a generic
  substitute, then `render_dos_opl.py` plays the `_F` sequences through
  Nuked OPL3 at the chip's own 49716 Hz. One OPL3, as a Sound Blaster 16 has.
- **sc55** — `render_dos_midi.py` plays the `_G` sequences through Nuked-SC55.
- **mt32** — `render_dos_mt32.py` plays the `_M` sequences through Munt.
- **cd** — `extract_cdda.py` pulls the Red Book tracks, then `slice_dos_cd.py`
  cuts each one into its pieces: a stage track holds both the base theme and
  its critical variant, with a fade between them, so one track feeds two
  commands.

Loop points for the three rendered packs are read from the sequences
themselves — the HMI files carry loop controllers — rather than estimated from
the audio. The CD pack's are placed on the recording's own metrical grid,
because the CD is a separately performed, edited production that does not run
at the sequences' tempo.

## Time and space

The CD pack is quick: an extraction and some cutting. The three rendered packs
synthesize every song in emulated time; measured on an Apple Silicon laptop,
the Sound Canvas takes about 15 minutes, the MT-32 and FM about 3 minutes each,
plus a one-time renderer build of a few minutes apiece. Renders land under
`builder/work/dos/` and are reused, so a second run of the same device is
nearly instant. The raw CD extraction is deleted after the FLACs are written
unless you pass `--keep-wav`.

## Reproducibility, honestly

Everything is pinned — the renderer revisions, the ROM hashes, the sequences
off your disc — and the built packs are hash-checked like the rest. What that
buys is that a matching build is provably the reviewed audio.

What it does not buy is a guarantee that *your* build matches on any machine.
These renderers are floating-point and their output can differ across
compilers and CPUs. If a pack's hash does not match, `make_packs.py` tells you
and refuses to stage it rather than shipping audio nobody reviewed. That is the
intended behavior, not a failure of your setup.

## By hand

The pack builder takes the FLAC directory directly:

```
python3 build_pack.py ssf2t-dos --device fm --flac-dir work/dos/flac/fm
```

`--device` is one of `fm`, `sc55`, `mt32`, `cd`, and each writes the matching
`ssf2_dos_*.cpk`.
