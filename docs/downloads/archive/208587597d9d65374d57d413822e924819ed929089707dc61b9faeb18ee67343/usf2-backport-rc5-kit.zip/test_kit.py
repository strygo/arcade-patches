#!/usr/bin/env python3
"""Focused corrupt/wrong-source, bounded decoder and driver collision tests."""
import hashlib
import contextlib
import io
from pathlib import Path
import random
import tempfile
import unittest
from unittest.mock import patch
import subprocess
import struct
import zipfile
import warnings
import apply
import verify
import payload
import install_driver
import nsp
import policy
import stock_mame


class KitTests(unittest.TestCase):
    def test_cli_setup_errors_are_concise_and_fail(self):
        for error in (ValueError('Required base NSP/XCI is missing'),
                      FileNotFoundError('Input file is missing'),
                      zipfile.BadZipFile('Invalid ZIP archive')):
            stderr = io.StringIO()
            with patch.object(apply, 'build', side_effect=error), contextlib.redirect_stderr(stderr):
                self.assertEqual(apply.main([]), 1)
            self.assertIn('Error: ' + str(error), stderr.getvalue())
            self.assertNotIn('Traceback (most recent call last)', stderr.getvalue())

    def test_cli_debug_and_unexpected_errors_keep_tracebacks(self):
        with patch.object(apply, 'build', side_effect=ValueError('missing source')):
            with self.assertRaisesRegex(ValueError, 'missing source'):
                apply.main(['--debug'])
        with patch.object(apply, 'build', side_effect=TypeError('unexpected defect')):
            with self.assertRaisesRegex(TypeError, 'unexpected defect'):
                apply.main([])
        with patch.object(apply, 'build'):
            self.assertEqual(apply.main([]), 0)

    def local_args(self, root, extra=()):
        source = root/'Game with spaces.nsp'
        keys = root/'prod.keys'
        source.write_bytes(b'fixture source'); keys.write_bytes(b'fixture keys')
        return apply.argument_parser().parse_args([
            '--source-us', str(source), '--keys', str(keys), *extra])

    def test_region_inference_and_explicit_region_requirements(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            for options, expected in (([], 'us'),
                    (['--source-jp', str(root/'Game with spaces.nsp')], 'all'),
                    (['--region', 'us'], 'us')):
                args = self.local_args(root, options)
                apply.prepare_arguments(args)
                self.assertEqual(args.region, expected)
            args = self.local_args(root)
            args.nsp_jp, args.nsp_us = args.nsp_us, None
            apply.prepare_arguments(args)
            self.assertEqual(args.region, 'jp')
            args = self.local_args(root, ['--region', 'all'])
            with self.assertRaisesRegex(ValueError, '--source-jp'):
                apply.prepare_arguments(args)
            with self.assertRaisesRegex(ValueError, '--source-us'):
                apply.prepare_arguments(apply.argument_parser().parse_args([]))

    def test_default_output_never_reuses_existing_folder_or_symlink(self):
        with tempfile.TemporaryDirectory() as temp, patch.object(apply.Path, 'cwd', return_value=Path(temp)):
            root = Path(temp)
            (root/'output-usf2').mkdir()
            (root/'output-usf2-2').symlink_to(root/'missing-target', target_is_directory=True)
            args = self.local_args(root)
            apply.prepare_arguments(args)
            self.assertEqual(args.out_dir, (root/'output-usf2-3').resolve())
            self.assertFalse(args.out_dir.exists())
            self.assertIsNone(args.work)
            args = self.local_args(root, ['--out-dir', str(root/'output-usf2-2')])
            with self.assertRaisesRegex(ValueError, 'Output already exists'):
                apply.prepare_arguments(args)

    def test_bad_paths_and_existing_output_fail_before_external_work(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            for bad in ('source', 'keys', 'rompath', 'output', 'work'):
                args = self.local_args(root)
                if bad == 'source': args.nsp_us = root/'not found.nsp'
                if bad == 'keys': args.keys = root/'not found.keys'
                if bad == 'rompath': args.rompath = [root/'missing roms']
                if bad == 'output': args.out_dir = root
                if bad == 'work': args.work = args.keys
                with patch.object(apply, 'read_manifest', return_value={}), patch.object(
                        apply, 'prepare_ffmpeg') as tools, patch.object(
                        apply, 'unlock') as unlock, patch.object(apply.rom_sources, 'Resolver') as resolver:
                    with self.assertRaises(ValueError): apply.build(args)
                    tools.assert_not_called(); unlock.assert_not_called(); resolver.assert_not_called()
            args = self.local_args(root); args.nsp_us = root/'missing game.nsp'
            with self.assertRaises(ValueError) as error: apply.prepare_arguments(args)
            self.assertIn(str(args.nsp_us.resolve()), str(error.exception))
            self.assertIn('Current folder:', str(error.exception))
            self.assertIn('leading /', str(error.exception))

    def test_automatic_scratch_is_private_and_removed_on_success_or_failure(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            for fail in (False, True):
                args = self.local_args(root, ['--platform', 'mame'])
                observed = []
                def run(args, *rest):
                    observed.append(args.work)
                    self.assertTrue(args.work.is_dir())
                    (args.work/'probe').write_text('disposable')
                    if fail: raise ValueError('controlled failure')
                kit = {'profiles': {'usf2t8': {'region': 'us', 'members': {}}}, 'arcade_inputs': []}
                with patch.object(apply, 'read_manifest', return_value=kit), patch.object(
                        apply.rom_sources, 'Resolver') as resolver, patch.object(
                        apply, 'check_music_dependencies'), patch.object(apply, 'build_outputs', side_effect=run):
                    resolver.return_value.resolve.return_value = {}
                    if fail:
                        with self.assertRaisesRegex(ValueError, 'controlled failure'): apply.build(args)
                    else: apply.build(args)
                self.assertEqual(len(observed), 1)
                self.assertFalse(observed[0].exists())

    def test_completion_uses_actual_output_paths_and_only_selected_region(self):
        with tempfile.TemporaryDirectory(prefix='USF2 output ') as temp:
            args = apply.argument_parser().parse_args([]); args.out_dir = Path(temp)
            for relative in ('mame/hsf2j.zip', 'hbmame/usf2j8.zip',
                             'mister/games/mame/usf2j8.zip', 'mister/games/CPS+/usf2_arrange.zip'):
                path = args.out_dir/relative; path.parent.mkdir(parents=True, exist_ok=True); path.touch()
            stdout = io.StringIO()
            with contextlib.redirect_stdout(stdout):
                apply.print_completion(args, {'usf2j8': {'region': 'jp'}}, ('mame', 'hbmame', 'mister', 'darksoft'))
            text = stdout.getvalue()
            self.assertIn(str(args.out_dir/'mame/hsf2j.zip'), text)
            self.assertIn('mame hsf2j -rompath "'+str(args.out_dir/'mame')+'"', text)
            self.assertIn('hbmame usf2j8', text)
            self.assertNotIn('hbmame usf2t8', text)
            self.assertIn('CONTENTS', text)
            mame, hbmame, mister, darksoft = [text.index(label+'\n') for label in
                                          ('MAME:', 'HBMAME:', 'MiSTer:', 'Darksoft:')]
            self.assertLess(mame, text.index(str(args.out_dir/'mame/hsf2j.zip')))
            self.assertLess(text.index(str(args.out_dir/'mame/hsf2j.zip')), hbmame)
            self.assertLess(hbmame, text.index(str(args.out_dir/'hbmame/usf2j8.zip')))
            self.assertLess(text.index(str(args.out_dir/'hbmame/usf2j8.zip')), mister)
            self.assertLess(mister, text.index(str(args.out_dir/'mister/games/CPS+/usf2_arrange.zip')))
            self.assertLess(text.index(str(args.out_dir/'mister/games/CPS+/usf2_arrange.zip')), darksoft)

    def test_source_and_xci_aliases_keep_legacy_nsp_commands(self):
        for region in ('us','jp'):
            for option in ('source','nsp','xci'):
                args=apply.argument_parser().parse_args(['--'+option+'-'+region,'/inputs/Game with spaces.xci'])
                self.assertEqual(getattr(args,'nsp_'+region),Path('/inputs/Game with spaces.xci'))

    def test_music_prerequisites_follow_selected_output(self):
        with patch.object(apply, 'prepare_ffmpeg', return_value='/tools/ffmpeg') as prepare:
            for profiles, platforms, check in (({'usf2t4':{}}, ('mame',), False),
                    ({'usf2t8':{}}, ('hbmame',), False),
                    ({'usf2t8':{}}, ('mister',), True)):
                apply.check_music_dependencies(profiles, platforms, check)
            prepare.assert_not_called()
            apply.check_music_dependencies({'usf2t8':{}}, ('mame','mister'))
            prepare.assert_called_once_with()

    def test_documented_targets_and_absolute_input_paths(self):
        parser = apply.argument_parser()
        defaults = parser.parse_args([])
        self.assertEqual((defaults.platform, defaults.audio), ('all', 'all'))
        with tempfile.TemporaryDirectory(prefix='usf2 path with spaces ') as temporary:
            root = Path(temporary).resolve()
            for target, size in (('mame','8'), ('hbmame','8'), ('mister','8')):
                args = parser.parse_args(['--rompath', str(root/'arcade roms'),
                    '--nsp-us', str(root/'Switch dumps'/'USF2 USA.nsp'),
                    '--keys', str(root/'prod.keys'), '--work', str(root/'scratch'),
                    '--out-dir', str(root/'output'), '--region','us',
                    '--platform',target,'--audio',size])
                self.assertEqual(args.nsp_us, root/'Switch dumps'/'USF2 USA.nsp')
                self.assertEqual(policy.platforms_for('usf2t'+size, (target,)), (target,))
            for target in ('mame','hbmame','mister','darksoft','all'):
                for audio in ([], ['--audio','4'], ['--audio','8'], ['--audio','all']):
                    args = parser.parse_args(['--platform',target,'--region','us',*audio])
                    with patch.object(apply, 'read_manifest', return_value={
                            'profiles':{'usf2t4':{'region':'us','members':{}},'usf2t8':{'region':'us','members':{}},
                                        'usf2j8':{'region':'jp','members':{}}},'arcade_inputs':[]}), patch.object(
                            apply, 'check_music_dependencies', side_effect=RuntimeError('stop before IO')) as prepare, patch.object(
                            apply, 'prepare_arguments'):
                        with self.assertRaisesRegex(RuntimeError, 'stop before IO'):
                            apply.build(args)
                        self.assertEqual(set(prepare.call_args.args[0]), {'usf2t8'})
            self.assertNotIn('--audio', parser.format_help())

    def test_program_patch_rejects_wrong_preimages_and_overlaps(self):
        original=b'0123456789';after=b'01AB456789'
        edit=dict(offset=2,after_hex=b'AB'.hex(),before_sha256=payload.sha(b'23'))
        self.assertEqual(payload.post_patch(original,[edit]),after)
        for bad in ([dict(edit,before_sha256=payload.sha(b'XX'))],
                    [edit,edit],[dict(edit,offset=9)],[dict(edit,offset=-1)]):
            with self.assertRaises(ValueError):payload.post_patch(original,bad)

    def test_stock_mame_verifies_native_hashes_and_PCM_mirror(self):
        files={n:bytes([i])*0x80000 for i,n in enumerate(stock_mame.PROGRAM)}
        files.update({'sfx.01':b'A'*0x20000,'sfx.02':b'B'*0x20000,
                      'sfx.11m':b'C'*0x200000,'sfx.12m':b'D'*0x200000,
                      'ssf2xj.key':b'K'*20,'dl-1425.bin':b'F'*24576})
        for lane in range(4):
            for prefix,index,size in (('sfx',13,0x200000),('sfx',14,0x100000),
                                      ('sfx',21,0x100000),('usf2',29,0x400000)):
                files[f'{prefix}.{index+lane*2}m']=bytes([index+lane])*size
        with tempfile.TemporaryDirectory() as temporary:
            for region,profile,expected in (('us','usf2t4','hsf2'),('jp','usf2j4','hsf2j')):
                record=dict(region=region,members={n:dict(size=len(b),sha256=payload.sha(b))for n,b in files.items()})
                name,packed=stock_mame.repack(files,region)
                self.assertEqual(name,expected)
                path=Path(temporary)/(name+'.zip')
                stock_mame.write_zip(path,packed)
                self.assertEqual(verify.verify_stock_archive(path,profile,record),files)
                for member,offset,diagnostic in (('hs2.11m',0x400000,'mirror differs'),
                                                 (name+'.key',0,'native member differs')):
                    original=packed[member]
                    packed[member]=original[:offset]+b'X'+original[offset+1:]
                    stock_mame.write_zip(path,packed)
                    with self.assertRaisesRegex(ValueError,diagnostic):
                        verify.verify_stock_archive(path,profile,record)
                    packed[member]=original

    def test_zip_compression_independent_ROM_identity(self):
        files={'test.03':b'program data'*1000,'test.04':b'graphics data'*800}
        record={'members':{name:dict(size=len(data),sha256=payload.sha(data)) for name,data in files.items()}}
        with tempfile.TemporaryDirectory() as temporary:
            root=Path(temporary);digests=[]
            for compression in (zipfile.ZIP_STORED,zipfile.ZIP_DEFLATED):
                path=root/(str(compression)+'.zip')
                with zipfile.ZipFile(path,'w',compression=compression) as archive:
                    for name,data in files.items():archive.writestr(name,data)
                self.assertEqual(verify.verify_archive(path,record),files)
                digests.append(nsp.file_sha(path))
            self.assertNotEqual(*digests)
            for case in ('changed','extra','missing','duplicate'):
                path=root/(case+'.zip')
                with warnings.catch_warnings():
                    warnings.simplefilter('ignore',UserWarning)
                    with zipfile.ZipFile(path,'w') as archive:
                        for name,data in files.items():
                            if case=='missing' and name=='test.04':continue
                            archive.writestr(name,b'X'+data[1:] if case=='changed' else data)
                        if case=='extra':archive.writestr('extra',b'bad')
                        if case=='duplicate':archive.writestr('test.03',files['test.03'])
                with self.assertRaises(ValueError):verify.verify_archive(path,record)

    def test_nsp_folder_extraction_and_failure_diagnostics(self):
        with tempfile.TemporaryDirectory(prefix='usf2 source path with spaces ') as temporary:
            root=Path(temporary);package=root/'test.nsp'
            names=b'program.nca\0ticket.tik\0'
            table=struct.pack('<QQII',0,7,0,0)+struct.pack('<QQII',7,6,12,0)
            package.write_bytes(struct.pack('<4sIII',b'PFS0',2,len(names),0)+table+names+b'programticket')
            keys=root/'prod.keys';keys.write_text('# synthetic test fixture\n')
            resource=b'authenticated resource fixture'*2
            for region in ('us','jp'):
                pin=dict(program_name='program.nca',ticket_name='ticket.tik',
                    program_sha256=hashlib.sha256(b'program').hexdigest(),
                    resource_path=f'/1/nativeNXx64/app/arc_{region}/mess/mess_resident.arc',
                    resource_sha256=hashlib.sha256(resource).hexdigest())
                def extract(command,**options):
                    requested=command[command.index('-x')+1]
                    if requested.endswith('.arc'):
                        return subprocess.CompletedProcess(command,1,'','Access is denied')
                    self.assertEqual(requested,f'/1/nativeNXx64/app/arc_{region}/mess')
                    self.assertNotIn('--showkeys',command);self.assertNotIn('--verbose',command)
                    destination=Path(command[command.index('-x')+2])
                    (destination/'mess_resident.arc').write_bytes(resource)
                    return subprocess.CompletedProcess(command,0,'','')
                with patch.object(nsp,'toolset',return_value={'nstool':root/'nstool'}), \
                     patch.object(nsp.subprocess,'run',side_effect=extract):
                    self.assertEqual(nsp.unlock(package,keys,pin,root/'work'),payload.source_key(resource))
                    with self.assertRaisesRegex(ValueError,'resource identity differs'):
                        nsp.unlock(package,keys,dict(pin,resource_sha256='0'*64),root/'work')
                with patch.object(nsp,'toolset',return_value={'nstool':root/'nstool'}), \
                     patch.object(nsp.subprocess,'run',return_value=subprocess.CompletedProcess(
                         [],1,'AES-CTR Key: '+'ab'*16,'Access is denied')):
                    with self.assertRaises(ValueError) as caught:
                        nsp.unlock(package,keys,pin,root/'work')
                    diagnostic=str(caught.exception)
                    self.assertIn('Access is denied',diagnostic)
                    self.assertIn('0x00000001',diagnostic)
                    self.assertNotIn('ab'*16,diagnostic)
                    self.assertNotIn('check your keys',diagnostic)

    def test_shipping_platform_and_MRA_matrix(self):
        for name in ('usf2t4','usf2j4'):
            self.assertEqual(policy.platforms_for(name,('darksoft',)),())
        for name in ('usf2t8','usf2j8'):
            self.assertEqual(policy.platforms_for(name,('darksoft',)),('darksoft',))
        for name in ('usf2t4','usf2j4'):
            policy.check_mras(name,[])
            self.assertEqual(policy.platforms_for(name,('mame','hbmame','mister')),())
            with self.assertRaises(ValueError):
                policy.check_mras(name,[dict(arrange=False),dict(arrange=True)])
        for name in ('usf2t8','usf2j8'):
            policy.check_mras(name,[dict(arrange=True)])
            self.assertEqual(policy.platforms_for(name,('mame','hbmame','mister')),('mame','hbmame','mister'))
            with self.assertRaises(ValueError):policy.check_mras(name,[dict(arrange=False)])

    def test_missing_media_and_bad_container(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp);bad=root/'source.nsp';bad.write_bytes(b'not an NSP')
            with self.assertRaises(ValueError):nsp.entries(bad)
            with self.assertRaises(ValueError):nsp.authenticate(root/'missing.nsp',{'region':'us','nsp_sha256':'0'*64})
            with self.assertRaises(ValueError):nsp.unlock(bad,root/'missing.keys',{},root/'work')
    def test_exact_and_wrong_source(self):
        rng=random.Random(103)
        source=rng.randbytes(4096); target=source[:100]+rng.randbytes(200)+source[300:]+b'custom art'
        key=payload.source_key(b'owned resource'*20)
        wrapped,record=payload.encode(target,source,key,'us')
        self.assertEqual(payload.decode(wrapped,record,source,key),target)
        for bad_key,bad_source in ((b'X'*32,source),(key,b'X'*4096)):
            with self.assertRaises(ValueError):payload.decode(wrapped,record,bad_source,bad_key)
        with self.assertRaises(ValueError):payload.decode(wrapped[:-1],record,source,key)
        with self.assertRaises(ValueError):payload.decode(wrapped,dict(record,output_bytes=2),source,key)

    def test_no_public_digest_key_and_no_stream_reuse(self):
        resource=b'private actual source content'*20
        key=payload.source_key(resource)
        self.assertNotEqual(key,hashlib.sha256(resource).digest())
        self.assertNotEqual(payload.mask(b'A'*256,key,'us:asset1'),payload.mask(b'A'*256,key,'us:asset2'))

    def test_driver_collision(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp);defs=root/'definitions';defs.mkdir();driver=root/'cps2.cpp'
            for i in range(4):(defs/(str(i)+'.cpp.inc')).write_text('ROM_START( usf2test'+str(i)+' )\nROM_END\n')
            driver.write_text('// cps2 clean\n');listing=root/'mame.lst'
            listing.write_text('@source:capcom/cps2.cpp\nssf2t\n@source:next.cpp\nnextgame\n')
            install_driver.install(driver,defs,list_path=listing)
            install_driver.install(driver,defs,True,listing)
            self.assertLess(listing.read_text().index('usf2test0'),listing.read_text().index('@source:next.cpp'))
            original=driver.read_text();driver.write_text(original.replace('usf2test0','usf2wrong'))
            with self.assertRaises(ValueError):install_driver.install(driver,defs)


if __name__=='__main__':unittest.main()
