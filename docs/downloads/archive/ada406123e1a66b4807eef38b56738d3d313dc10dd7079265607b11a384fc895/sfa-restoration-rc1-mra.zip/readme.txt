Street Fighter Alpha: Warriors' Dreams · English restoration
============================================================

Version:  rc1 (2026-10-13)
Target:   MAME set 'sfzj' (Street Fighter Zero (Japan 950727))
Hardware: Capcom CPS-2
Patch by: Steve Gordon (https://x.com/strygo)
Website:  https://arcadepatches.com/sfa-restoration/

ABOUT THIS PROJECT

Street Fighter Alpha's English versions have a smaller win-quote pool than
Street Fighter Zero in Japan. The English Restoration brings the Japanese pool
and its quote choices to the USA and Asia games, along with English rival
dialogue, endings and continue advice based on the Japanese script.

Win quotes are centered in a wider box. The Manual guard panel explains the
difference between Manual and Auto. Red blood, the Japanese Auto guard
default, Japanese move selection for computer opponents and Dramatic Battle
music return, along with Capcom's later fixes for guard behavior and Rose's
crouching heavy kick.

The USA build keeps Street Fighter Alpha's title and character names. Asia
keeps Street Fighter Zero's title with English text and export character
names. Japan keeps its Japanese text and names and receives the shared fixes.

This is a release candidate.

WHAT'S CHANGED

  - The Japanese win quotes in English, with Japan's quote selection and
    button choices
  - Rival dialogue, endings and continue advice translated from the Japanese
    game
  - A wider win-quote box with centered English text
  - The Manual guard panel explains itself
  - Red blood and Japan's Auto guard default
  - Japanese move selection for computer opponents and Dramatic Battle music
  - Capcom's November fixes for guard behavior and Rose's crouching heavy kick
  - USA, Asia and Japan builds

MISTER SETUP

1. Copy the _Arcade/ folder from this download to the root of your MiSTer SD
   card (the MRAs land in _Arcade/_Arcade Patches/_Restorations/), or just the MRAs you want:
       "Street Fighter Alpha (USA) [English Restoration].mra"
       "_Asia/Street Fighter Zero (Asia) [English Restoration].mra"
       "_Japan/Street Fighter Zero (Japan) [Restoration].mra"
2. Have the stock, unmodified romset at games/mame/sfzj.zip
   (split sets also need the parent and QSound ZIPs named in the MRA).
3. You need Jotego's jtcps2 core; the standard MiSTer downloader /
   update_all installs it automatically.

Each MRA references your original romset and applies the restoration in
memory while the game loads. Nothing on your SD card is modified. Each
build keeps its own settings and saves under its own setname:
    USA (English)    sfaru
    Asia (English)   sfzra
    Japan (Japanese) sfzrj

LEGAL

This is a free, unofficial fan patch. It is not affiliated with or endorsed
by Capcom. All game titles, characters, and artwork remain the property of
their respective owners. You must own the game to use this patch. Do not
sell this patch or distribute it applied to a ROM image.
