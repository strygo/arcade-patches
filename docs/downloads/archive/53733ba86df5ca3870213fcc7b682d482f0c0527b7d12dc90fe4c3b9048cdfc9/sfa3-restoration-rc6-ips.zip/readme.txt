Street Fighter Alpha 3 · English restoration
============================================

Version:  rc6 (2026-11-14)
Target:   MAME set 'sfz3j' (Street Fighter Zero 3 (Japan 980904))
Hardware: Capcom CPS-2
Patch by: Steve Gordon (https://x.com/strygo)
Website:  https://arcadepatches.com/sfa3-restoration/

ABOUT THIS PROJECT

Street Fighter Alpha 3's US arcade version cut each character's win quotes
down to eight generic lines. The Japanese game also has a quote for each
opponent. This restoration brings back all 625 opponent-specific quotes, with
all 825 of the Japanese game's win quotes in English.

Detailed stage locations return in English, in the original stage panels.
Biographies, rival dialogue and endings follow the Japanese script in natural
English that fits each character. Capcom's English stays where it was
accurate, and Alpha 3 MAX's official wording is used where it fits.

The game uses the Japanese 980904 revision's gameplay and secret-character
access, with its original difficulty and Turbo 1 defaults. Regulation starts
OFF, restoring red hit blood and the full defeat and ending effects; the
operator can still switch it ON. The arcade ending sequences are retained,
with corrected backgrounds and colors.

Alpha branding in the animated intro, character selection, player
introductions and win screens, English A/X/V-ISM labels, descriptions and
score rankings, Western names in the intro and fights, title and entry
announcements, and English operator menus retain the USA presentation. It runs
in MAME and HBMAME and on MiSTer with the jtcps2 core. Supply your own
original Japanese sfz3j romset; split sets also need their sfa3 parent and
QSound firmware.

The optional Japanese edition keeps the original Japanese text and names, Zero
branding and Z-ISM, with the same ending and portrait color corrections.

This is a release candidate.

WHAT'S CHANGED

  - All 825 Japanese win quotes in English, including 625 opponent-specific
    quotes the US arcade version left out
  - All 24 detailed stage locations in English, centered in the original
    panels with Capcom’s per-panel text colors
  - Biographies, rival and boss dialogue, and endings that follow the Japanese
    script, keeping Capcom's wording where it was accurate
  - Japanese Regulation OFF by default, with its operator switch and
    uncensored effects
  - Japanese 980904 gameplay, difficulty, Turbo 1 defaults and secret-
    character access
  - Alpha branding in the intro, selection, player introductions and win
    screens; English A/X/V-ISM descriptions and score rankings with Capcom’s
    USA default initials, Western names, title and entry announcements, and
    operator menus
  - Corrected ending backgrounds, framing and colors, including cleaner
    picture edges and character placement in E. Honda’s ending
  - Corrected Sodom portrait colors, including black eyes on his small select
    portrait, a blue X-ISM mask and the original gray V-ISM mask in the
    rankings
  - An optional Japanese edition with original Japanese text and names, Zero
    branding and Z-ISM, and the same ending corrections

BUILD THE GAME

Run python3 apply.py in a terminal for guided setup.
On Windows use py -3.13 apply.py.
Choose your media folder, platform, region and output folder.
Run python3 apply.py --help for command-line options.

BUILDS IN THIS DOWNLOAD

    english    English restoration
    japanese   Japanese restoration

HOW TO APPLY (recommended)

    python3 apply.py /path/to/sfz3j.zip --out-dir out

This checks every file against the original, applies the patches, checks
the result, and writes everything you need for every build (add
--variant <build> to make just one):

  English restoration:
    MAME:                     out/mame/english/sfz3j.zip
    HBMAME:                   out/hbmame/sfa3ru.zip
    FBNeo:                    out/fbneo/sfa3re.zip
    MiSTer:                   out/mister/_Arcade/_Arcade Patches/_Restorations/Street Fighter Alpha 3 (USA) [Restoration].mra
  Japanese restoration:
    MAME:                     out/mame/japanese/sfz3j.zip
    HBMAME:                   out/hbmame/sfz3rj.zip
    FBNeo:                    out/fbneo/sfz3rej.zip
    MiSTer:                   out/mister/_Arcade/_Arcade Patches/_Restorations/Street Fighter Zero 3 (Japan) [Restoration].mra

FBNeo: use --platform fbneo --out-dir out for complete game ZIPs.
Keep their ZIP and member names. Use an FBNeo version with definitions
matching this game release; older versions may reject its checksums.


DARKSOFT

Use --platform darksoft --out-dir out to build only Darksoft files.
The default all-platform build includes them too. Copy the selected
folder from out/darksoft/games to your card games folder.
Expanded hardware and streamed audio are not supported.

Merged, split and complete sets work, including nested or renamed ROMs.
Use --rompath DIR (repeatable) to search a collection instead of naming the
zip, and --check to check inputs before building. ZIPs and extracted folders
need no extra software; 7z archives need 7-Zip.
Keep your unmodified qsound.zip in the emulator's ROM path.
Device firmware is not copied into the game archives.

MAME: put sfz3j.zip from out/mame/ ahead of the stock set in your MAME
rompath (one build at a time: they share the set name).
MAME's game menu won't start a set with patched ROMs, so start it from the
command line: mame sfz3j. MAME shows checksum warnings for the patched
ROMs; that's expected and the game runs normally.
To start it from a menu, use the HBMAME build.
Keep your unmodified qsound.zip in MAME's ROM path.

HBMAME: use a build containing the sfa3ru, sfz3rj set definitions.
Upstream HBMAME support is pending.
Put sfa3ru.zip, sfz3rj.zip and qsound.zip in HBMAME's roms/ folder;
it holds the complete set.

MiSTer: copy the _Arcade folder from out/mister/ to the root of your SD card
and keep the stock, unmodified romset at games/mame/sfz3j.zip (split MAME
sets also need qsound.zip). The MRA applies the restoration in memory as the
game loads, so nothing on the card is modified. You need Jotego's jtcps2
core, which update_all installs. The MRAs are also a separate download.

HOW TO APPLY (any IPS patcher)

Extract sfz3j.zip, apply each file in ips/<build>/ to the ROM file of the
same name (Flips, Lunar IPS, or any IPS tool), then re-zip everything
as sfz3j.zip.

CHANGED FILES

  English restoration (--variant english):
    sz3.08c  (512 KB)  CRC32 910c4a3b -> 743184e5
    sz3.09c  (512 KB)  CRC32 b29e5199 -> 781d244e
    sz3.10b  (512 KB)  CRC32 deb2ff52 -> 6c9c3741
    sz3.13m  (4.0 MB)  CRC32 0f7a60d9 -> 1cef39bc
    sz3.14m  (4.0 MB)  CRC32 5ff98297 -> 31bfae76
    sz3.15m  (4.0 MB)  CRC32 8e933741 -> 1efafa96
    sz3.16m  (4.0 MB)  CRC32 52b5bdee -> c366c0ab
    sz3.17m  (4.0 MB)  CRC32 d6e98147 -> 794a20f7
    sz3.18m  (4.0 MB)  CRC32 40631ed5 -> be20b9bb
    sz3.19m  (4.0 MB)  CRC32 f31a728a -> 8617f745
    sz3.20m  (4.0 MB)  CRC32 763409b4 -> 682eada9
    sz3j.03c  (512 KB)  CRC32 cadf4a51 -> 67ffd763
    sz3j.04c  (512 KB)  CRC32 fcb31228 -> 400cc57a

  Japanese restoration (--variant japanese):
    sz3.09c  (512 KB)  CRC32 b29e5199 -> cf880cee
    sz3.10b  (512 KB)  CRC32 deb2ff52 -> 8ef31512
    sz3.13m  (4.0 MB)  CRC32 0f7a60d9 -> dd13c9d1
    sz3.15m  (4.0 MB)  CRC32 8e933741 -> 998afbfd
    sz3.17m  (4.0 MB)  CRC32 d6e98147 -> 3bef3687
    sz3.19m  (4.0 MB)  CRC32 f31a728a -> 7f968eed
    sz3j.03c  (512 KB)  CRC32 cadf4a51 -> afc5b63b
    sz3j.04c  (512 KB)  CRC32 fcb31228 -> 44c06332

All other files in the set are unmodified.

LEGAL

This is a free, unofficial fan patch. It is not affiliated with or endorsed
by Capcom. All game titles, characters, and artwork remain the property of
their respective owners. You must own the game to use this patch. Do not
sell this patch or distribute it applied to a ROM image.
