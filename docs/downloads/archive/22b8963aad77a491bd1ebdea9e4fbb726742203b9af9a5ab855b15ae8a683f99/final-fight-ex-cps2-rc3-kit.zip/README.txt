BUILD OR UPDATE

Run python apply.py in a terminal (Windows: py -3.13 apply.py).
Choose Build or update, then select your media and available outputs.
Settings are remembered; intact outputs can be reused safely.
Check requirements is optional. Change settings saves without building.
Enter q at any prompt to quit. Run apply.py --help for the existing
command-line options and specialized workflows described below.

Final Fight EX (CPS-2) — reconstruction kit



Version: rc3 (2026-11-03)




This kit brings Final Fight EX to Capcom's CPS-2 with every enhancement from the CPS-1 version. It includes a restored English version with added scenes, an improved translation and uncensored content. The test menu switches between the arcade and Sega CD cutscenes, and on MiSTer between the arranged and arcade soundtracks.

The 1993 Sega CD port of Final Fight opened with a fully animated cutscene and closed with new ending scenes, over a soundtrack with spoken dialogue. Final Fight EX brings them to the arcade game. On the CPS-2 the arcade's music and sound effects play through QSound.

The opening shows the Metro City map, the Mad Gear line-up, Damnd's sketch and the knife, Haggar's phone call and Cody and Guy. The ending adds Haggar and Jessica's reunion and Cody's farewell, and the builds made from the Japanese disc add Cody and Guy's talk in the mansion hall. CUT SCENES in the test menu switches back to the arcade's own story and ending.

On MiSTer the Sega CD's arranged soundtrack plays and the cutscenes are voiced: the USA build with the US disc's voices, the Japan build with the Japanese disc's, and the English restoration with a new English voice track. MUSIC switches back to the arcade music. In HBMAME the game plays the arcade music, and the cutscenes keep their captions.

The English restoration is the Japanese version in English: the Japanese disc's cutscenes, translated from the Japanese, with captions that follow the English voices and mouths that move with the lines.

The test menu's EX page can also turn the bonus stages off and switch the artwork to Capcom Arcade Stadium's revised soda can and Uptown sign. REGULATION chooses Jessica's outfit on Haggar's TV in the opening. A hidden stage select on the title screen can jump to any round or straight to the ending.

Console mode adds a title menu with Arcade, Time Attack and Options, play without coins, and a pause menu. Time Attack is the Sega CD's own mode: one fight against the clock in your character's arena from the Sega CD, scoring a point for every enemy defeated. On MiSTer it plays the Sega CD's Time Attack music. MiSTer starts in Console mode; GAME MODE in the test menu's EX page switches between Console and Arcade.

This is a release candidate.



Changes:

- The Sega CD opening cutscene as native CPS-2 graphics: the Metro City map, the Mad Gear line-up, Damnd's sketch and the knife, Haggar's phone call, and Cody and Guy

- The Sega CD ending scenes: Haggar and Jessica's reunion and Cody's farewell, and Cody and Guy in the mansion hall in the Japan and English restoration builds

- The Final Fight EX title screen

- The arcade's music and sound effects on the CPS-2's QSound

- On MiSTer, the Sega CD arranged soundtrack and voiced cutscenes, with MUSIC to switch back to the arcade music

- The English restoration: the Japanese version in English, with a new English voice track on MiSTer

- EX settings in the test menu: BONUS STAGE on or off, CUT SCENES SEGA CD or ARCADE, ARTWORK ORIGINAL or ARCADE STADIUM

- REGULATION: Jessica on Haggar's TV in the US disc's red dress or the Japanese disc's lingerie; in the Japan and English restoration builds it also turns blood white

- A hidden stage select with an ENDING option: hold attack and jump and press Start on the title screen

- Console mode: a title menu with Arcade, Time Attack and Options (difficulty, lives and extra lives), play without coins, and a pause menu on Coin with Continue and Quit; MiSTer starts in Console mode, and GAME MODE in the test menu's EX page switches it

- Time Attack from the Sega CD: 99 counts in your character's Sega CD arena, with its enemy waves, results screen and record; a second player can join on the select screen

- On MiSTer, the Sega CD's Time Attack music, and the pause menu holds the arranged music

- A CPS-2 test menu in place of the DIP switches: coins, continues, difficulty, lives and extends

- GRENADE spelled right on the HUD, and the USA story's typos fixed

- USA (ffex2u), Japan (ffex2j) and English restoration (ffex2r) builds

WHAT YOU NEED
-------------

  1. Your Final Fight CD disc, for the builds you want, as its .cue sheet
     (with its .bin or .img files beside it), a CD .chd, or a .zip or .7z
     holding one:
       - USA   : Final Fight CD (USA)   -> the USA build
       - Japan : Final Fight CD (JP)    -> the Japan build and the English
                                           restoration
     Supply both to build all three. The MiSTer music packs are made from
     the disc's CD audio, so give the whole disc, not only its first track.

  2. Your arcade romsets, MAME 0.260-era, as .zip or .7z, split or merged:
       - Final Fight: ffight (World), ffightu (USA) and ffightj (Japan)
       - Street Fighter Alpha 3: sfa3u (USA), for the CPS-2 sound

  3. Python 3.12 or newer. MiSTer soundtrack builds also need NumPy. FFmpeg for the MiSTer
     music packs, 7-Zip for .7z archives and chdman for .chd discs are
     fetched as verified packages when needed. Installed 7-Zip and chdman
     can also be used. No emulator or assembler is needed.

     Install the Python packages using the same Python as the build:

       Windows:       py -m pip install numpy
       macOS / Linux: python3 -m pip install numpy

     If NumPy is missing, the kit stops before reading romsets
     and shows an install command for the Python you are running.


USAGE
-----

(On Windows, run it as "py apply.py ..." on one line, or end each line with ^
in Command Prompt or ` in PowerShell instead of \.)

    python3 apply.py --disc-jp "Final Fight CD (JP).cue" \
                     --disc-us "Final Fight CD (USA).cue" \
                     --rompath <romset folder> --out-dir out

This builds every set your discs allow and writes:

    out/mame/<edition>/sfa3ud.zip for stock MAME (english, usa, japan)
    out/hbmame/<set>.zip         for HBMAME
    out/mister/                  laid out like the MiSTer SD card
    out/darksoft/games/          one game folder per build, for Darksoft

Add --platform mister, mame, hbmame or darksoft to build for one target only. The
kit verifies every finished file automatically. It stops with an error if a
disc or a romset does not match.


SETS
----

    English restoration   ffex2r   Final Fight EX CPS2 (English Restoration)
    USA                   ffex2u   Final Fight EX CPS2 (USA)
    Japan                 ffex2j   Final Fight EX CPS2 (Japan)

The English restoration is the Japanese version in English: the Japanese
disc's cutscenes, translated from the Japanese.


ON MISTER
---------

Copy the contents of out/mister/ to the root of the MiSTer SD card:

    _Arcade/_Arcade Patches/_Enhanced Versions/         English restoration MRA
    _Arcade/_Arcade Patches/_Enhanced Versions/_USA/    USA MRA
    _Arcade/_Arcade Patches/_Enhanced Versions/_Japan/  Japan MRA
    _Arcade/cores/jtcps2-cpsplus_20261101.rbf           the CPS+ core
    games/hbmame/<set>.zip                              the sets
    games/CPS+/<pack>.zip                               the music packs

These sets need the CPS+ core included here, not the standard jtCPS2 core,
and 128 MB of SDRAM. MiSTer runs the newest dated jtcps2-cpsplus core on
the card, so this core also runs your other CPS+ games. If the QSound
firmware was absent from your input, keep qsound.zip or qsound_hle.zip in
games/mame.

The MiSTer builds play the Sega CD's arranged soundtrack and voice the
cutscenes: the USA build with the US disc's voices, the Japan build with the
Japanese disc's, and the English restoration with a new English voice track.
Time Attack plays the Sega CD's Time Attack music, and the pause menu holds
the music until you continue. The music packs are built from your discs.
MUSIC on the test menu's EX page switches back to the arcade music.

The MiSTer builds start in Console mode (see IN THE GAME).


ON STOCK MAME
-------------

Build with --platform mame to produce only the stock MAME sets. No custom
MAME build or driver definitions are needed. Each edition is named
sfa3ud.zip and lives in its own folder; keep the folders separate and use
the ROM path for the edition you want:

    mame sfa3ud -rompath out/mame/english -window -nomaximize -nvram_directory out/mame/english/nvram -cfg_directory out/mame/english/cfg
    mame sfa3ud -rompath out/mame/usa -window -nomaximize -nvram_directory out/mame/usa/nvram -cfg_directory out/mame/usa/cfg
    mame sfa3ud -rompath out/mame/japan -window -nomaximize -nvram_directory out/mame/japan/nvram -cfg_directory out/mame/japan/cfg

Run these commands from the folder containing out/ (on Windows, use
mame.exe). The separate NVRAM and configuration folders keep each edition's
settings independent. MAME identifies the game as Street Fighter Alpha 3
(USA 980904 Phoenix Edition), because that is the set used to load it.
Warnings about incorrect checksums are expected for the replaced ROMs;
missing files are errors. If MAME requests QSound firmware, add your device
ROM folder to -rompath, for example "out/mame/usa;/path/to/device-roms".
Stock MAME plays the arcade music; cutscenes retain their captions. The
Sega CD arranged soundtrack and voiced playback require the MiSTer output.


ON HBMAME
---------

Use an HBMAME build that includes the Final Fight EX sets. Start the games
by set name. HBMAME plays the arcade music, and the cutscenes keep their
captions.


ON DARKSOFT
-----------

Copy a game's folder from out/darksoft/games/ to the games folder of your
Darksoft CPS2 multi card. Its flash files, key and NAME stay together. The
game runs unencrypted, as Phoenix sets do, so its key file is blank. Darksoft
plays the arcade music. The receipts in out/darksoft/receipts/ stay off the
card.


IN THE GAME
-----------

GAME MODE, the first row of the test menu's EX page, chooses CONSOLE or
ARCADE. The MiSTer builds start in Console mode; the HBMAME, stock MAME and
Darksoft builds start in Arcade mode, which plays as the arcade game does.

In Console mode no coins are needed: press Start to play or to join. The
title screen offers ARCADE, TIME ATTACK and OPTIONS (Up and Down choose,
Start selects). OPTIONS sets DIFFICULTY, LIVES and EXTRA LIFE (Left and
Right change a setting; Start or attack saves and returns). During play,
Coin pauses the game: CONTINUE resumes and QUIT returns to the title.

TIME ATTACK is the Sega CD's own mode: one fight in your character's arena
from the Sega CD, against a clock of 99, with a point for every enemy you
defeat. A second player can join on the select screen. RESULT shows your
time and defeats beside the record, which is kept until the game is switched
off. CONTINUE plays again from the select screen; EXIT returns to the title.

The test menu's EX page also turns the bonus stages on or off, switches CUT SCENES
between the Sega CD's and the arcade's own, and switches ARTWORK to Capcom
Arcade Stadium's revised soda can and Uptown sign. REGULATION chooses
Jessica's outfit on Haggar's TV in the opening.

Stage select: hold attack and jump and press Start on the title screen. Pick
any round, or the ending.


LEGAL
-----

Unofficial fan project. Not affiliated with or endorsed by Capcom or Sega.
All game titles, characters and artwork remain the property of their owners.
The cutscene art and audio derive from Capcom's Final Fight CD. You must own
the discs and romsets used as inputs. The kit carries only our own code, the
English voice track, three small Capcom Arcade Stadium tiles, and the CPS+
core with its source and licenses (core/). Data that depends on another disc
or on Capcom Arcade Stadium is stored so that it rebuilds only from your own
disc and romset. Do not sell this kit or distribute it applied to game
images.

ROM COLLECTIONS
---------------
Merged, split and complete ZIP/7z sets and extracted folders are accepted.
Use --rompath DIR (repeatable) or --romset FILE (repeatable). Names may
differ; required contents are verified by strong hashes. 7z uses installed
7-Zip or a verified package fetched on demand. Use --check to preflight
arcade inputs without supplying the discs.
--include-devices puts the QSound firmware into the sets. Source archives are
never modified.

MEDIA TOOLS

FFmpeg/ffprobe are fetched as pinned verified binaries. No separate FFmpeg
installation is needed. To work offline, add --tools-bundle
cpsplus-tools-v3-offline.zip --offline. Use --tools-cache to choose the cache.
The same controls cover the optional 7-Zip and chdman packages.
NumPy is required only for MiSTer soundtrack builds; Pillow is not required.
