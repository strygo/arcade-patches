import wave
from resource_recipe import require, sha

def read_pcm(path):
    with wave.open(str(path), 'rb') as w:
        require((w.getframerate(), w.getnchannels(), w.getsampwidth()) == (44100, 2, 2), 'Expected original 44.1 kHz stereo CD audio')
        data = w.readframes(w.getnframes())
        require(len(data) == w.getnframes() * 4, 'Truncated CD audio')
    return data

def pcm(row, source):
    require(sha(source) == row['source_sha256'], 'Original CD audio track differs')
    data = source
    if row['cut'] is not None:
        data, _ = arcade_cut(data, 2, 44100, *row['cut'])
    elif row['lead']:
        data = bytes(row['lead'] * 4) + data
    require(sha(data) == row['pcm_sha256'], 'Prepared audio PCM differs')
    return data

def arcade_cut(pcm, ch, rate, lead_samples, cut_at, bars, bpm, xfade):
    import numpy as np
    a = np.frombuffer(pcm, dtype='<i2').astype(np.float64).reshape(-1, ch)
    if lead_samples:
        a = np.concatenate([np.zeros((lead_samples, ch), np.float64), a])
    drop = 60.0 / bpm * 4 * bars
    t0 = int(cut_at * rate)
    t1 = t0 + int(drop * rate)
    xf = int(xfade * rate)
    if t1 + xf > len(a):
        raise ValueError('arcade cut runs past the end of the track')
    head, tail = (a[:t0], a[t1:])
    n = min(xf, len(head), len(tail))
    if n:
        f = np.linspace(0, np.pi / 2, n)[:, None]
        joined = head[-n:] * np.cos(f) ** 2 + tail[:n] * np.sin(f) ** 2
        out = np.concatenate([head[:-n], joined, tail[n:]])
    else:
        out = np.concatenate([head, tail])
    return (np.clip(out, -32768, 32767).astype('<i2').tobytes(), len(out))
