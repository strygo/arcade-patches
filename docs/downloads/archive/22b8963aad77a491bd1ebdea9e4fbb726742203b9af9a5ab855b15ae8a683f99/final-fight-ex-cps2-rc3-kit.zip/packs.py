"""Direct final CPS2 CPK writes, sharing authenticated encoded track products."""
import hashlib
import json
import os
from pathlib import Path
import shutil
from keyed import unseal
from resource_recipe import require, sha
from recipe_pcm import read_pcm, pcm
from cpsplus.pack import adxcodec, discsrc
from cpsplus.pack.format import PackWriter, Protocol, TrackMeta, TriggerRow
HERE = Path(__file__).resolve().parent
DISC_REGION = {'usa': 'us', 'japan': 'jp', 'english': 'jp'}

def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def original_identity(disc):
    if disc.suffix.lower() != '.cue':
        return digest(disc)
    tracks, _ = discsrc.extract_cdda.parse_cue(disc)
    files = sorted({Path(row[2]).resolve() for row in tracks})
    return sha(disc.read_bytes() + b''.join((digest(path).encode() for path in files)))

def build(disc_jp, disc_us, edition, out_path, *, work, keyed=None, expect_sha256=None):
    from ffex_kit import disc_workspace
    region = DISC_REGION[edition]
    disc = disc_us if region == 'us' else disc_jp
    require(disc is not None, 'Supply the original regional disc')
    work, disc, out_path = (Path(work), Path(disc), Path(out_path))
    work.mkdir(parents=True, exist_ok=True)
    document = json.loads((HERE / 'music-recipes.json').read_text(encoding='utf-8'))
    plan = document['editions'][edition]
    bases = document['sources'][region]
    marker = work / (region + '-source.json')
    identity = original_identity(disc)
    if marker.exists() and json.loads(marker.read_text(encoding='utf-8')) != identity:
        for path in (work / 'audio' / region, work / 'disc-cache' / disc.stem):
            if path.is_dir():
                shutil.rmtree(path)
    with disc_workspace(work):
        audio = work / 'audio' / region
        discsrc.ensure_audio_cache(audio, {row['track'] for row in bases.values()}, disc, '--disc-' + region)
        encoded, counterparts = ({}, {})
        cache = work / 'encoded'
        cache.mkdir(exist_ok=True)
        for name, row in bases.items():
            prepared = pcm(row, read_pcm(audio / (row['track'] + '.wav')))
            target = cache / (row['sha256'] + '.adx')
            if target.is_file() and digest(target) == row['sha256']:
                stream = target.read_bytes()
            else:
                stream = adxcodec.encode(prepared, 2, 44100)[:row['stream_bytes']]
                require(sha(stream) == row['sha256'], 'Direct source soundtrack stream differs')
                target.write_bytes(stream)
            encoded[name] = stream
            if region == 'jp':
                counterparts['pack:ffight_arrange_jp:' + name] = stream
        marker.write_text(json.dumps(identity), encoding='utf-8')
        english = {}
        if edition == 'english':
            doc = document['english']
            decoded = unseal(doc, (HERE / 'resources.bin').read_bytes(), counterparts.__getitem__)
            for item in doc['items']:
                name, _ = item['name'].split('/')
                stream = english.setdefault(name, bytearray())
                require(len(stream) == item['counterpart']['offset'], 'English audio blocks are out of order')
                stream.extend(decoded[item['name']])
        protocol = dict(plan['protocol'])
        protocol['control_verbs'] = {int(k): v for k, v in protocol['control_verbs'].items()}
        protocol['arg_commands'] = set(protocol['arg_commands'])
        writer = PackWriter(Protocol(**protocol), title=plan['title'], trigger_rows=len(plan['triggers']), default_rate=plan['default_rate'], xfade_samples=plan['xfade_samples'])
        for row in plan['tracks']:
            if row['kind'] == 'source':
                stream = encoded[row['source']]
            elif row['kind'] == 'english':
                stream = bytes(english[row['source']])
            else:
                raise ValueError('Unknown soundtrack recipe')
            require(sha(stream) == row['sha256'], 'Final soundtrack stream differs')
            writer.add_track(stream, TrackMeta(**row['meta']))
        writer.triggers = [TriggerRow(**row) for row in plan['triggers']]
        out_path.parent.mkdir(parents=True, exist_ok=True)
        writer.write(out_path, sidecar=False)
        require(digest(out_path) == plan['sha256'] and (expect_sha256 is None or digest(out_path) == expect_sha256), 'Complete final CPS2 soundtrack differs')
    return out_path
