"""Reconstruct the unchanged Strider EX release from authenticated owned media."""
# BEGIN ARCADE KIT ENTRY
if __name__ == "__main__":
    import sys as _kit_sys
    if len(_kit_sys.argv) == 1 and _kit_sys.stdin.isatty() and _kit_sys.stdout.isatty():
        import importlib.util as _kit_import
        from pathlib import Path as _KitPath
        _kit_root = _KitPath(__file__).resolve().parent
        _kit_spec = _kit_import.spec_from_file_location("_kit_frontend", _kit_root / "_kit_runtime/frontend.py")
        _kit_frontend = _kit_import.module_from_spec(_kit_spec)
        _kit_spec.loader.exec_module(_kit_frontend)
        raise SystemExit(_kit_frontend.guided(_kit_root))
# END ARCADE KIT ENTRY

import sys as _native_sys
from pathlib import Path as _NativePath
if __name__ == '__main__':
    _native_sys.path.insert(0, str(_NativePath(__file__).resolve().parent))
    from kit_cli import install as _native_errors
    _native_errors()
if __name__ == '__main__' and ('--collection-layout' in _native_sys.argv or '--describe-json' in _native_sys.argv or '--emit-definition' in _native_sys.argv):
    _native_sys.path.insert(0, str(_NativePath(__file__).resolve().parent))
    from native_collection import main as _native_main
    raise SystemExit(_native_main(_NativePath(__file__).resolve().parent))
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys
import tempfile
import zipfile
KIT = Path(__file__).resolve().parent
if __name__ == '__main__':
    from kit_cli import install
    install()
sys.path[:0] = [str(KIT), str(KIT / 'builder'), str(KIT / 'builder/release')]
from recipe_engine import Resources, require, sha
import recipe_inputs as inputs
from tool_controls import verify_required_files

def wanted(name, region, audio, platform):
    if platform == 'mister' and name.startswith('hbmame/'):
        return False
    if platform == 'hbmame' and name.startswith('mister/'):
        return False
    if name.startswith('mister/'):
        if audio == 'arcade' and ('/_Arrangements/' in name or name.endswith('/strider_ex.zip')):
            return False
        if audio == 'cpsplus' and '/_Enhanced Versions/' in name:
            return False
    if region == 'us' and ('striderjs01' in name or '/_Japan/' in name):
        return False
    if region == 'jp' and ('striderus01' in name or (name.endswith('.mra') and '/_Japan/' not in name)):
        return False
    return True

def main():
    from kit_runtime import enable_utf8
    enable_utf8()
    p = argparse.ArgumentParser(description=__doc__)
    for name in ('disc', 'romset', 'x68k', 'out-dir'):
        p.add_argument('--' + name, type=Path, required=True)
    p.add_argument('--region', choices=('both', 'us', 'jp'), default='both')
    p.add_argument('--audio', choices=('both', 'arcade', 'cpsplus'), default='both')
    p.add_argument('--platform', choices=('both', 'hbmame', 'mister'), default='both')
    p.add_argument('--work', type=Path)
    p.add_argument('--check', action='store_true')
    import ffmpeg_runtime
    a = p.parse_args(ffmpeg_runtime.configure(sys.argv[1:]))
    pins = json.loads((KIT / 'kit.json').read_text())['files']
    verify_required_files(KIT, pins)
    inputs.KIT = KIT
    a.out_dir = inputs.output_path(a.out_dir, [a.disc, a.x68k, *inputs.rom_sources(a.romset)])
    from output_checks import check_file
    contracts = json.loads((KIT / 'outputs.json').read_text())
    for name in contracts['files']:
        if not wanted(name, a.region, a.audio, a.platform):
            continue
        dest = a.out_dir / name
        require(not any((parent.is_symlink() or (parent.exists() and (not parent.is_dir())) for parent in (dest.parent, *dest.parents))), 'invalid output parent')
        if dest.exists() or dest.is_symlink():
            check_file(dest, name, contracts)
    if a.work:
        a.work = inputs.output_path(a.work, [a.disc, a.x68k, *inputs.rom_sources(a.romset)])
        require(not a.work.is_relative_to(a.out_dir) and (not a.out_dir.is_relative_to(a.work)), 'work and output directories overlap')
        a.work.mkdir(parents=True, exist_ok=True)
    plan = json.loads((KIT / 'recipes.json').read_text())
    with tempfile.TemporaryDirectory(prefix='striderex-', dir=a.work) as temp:
        work = Path(temp)
        _, tracks = inputs.owned_disc(a.disc.resolve(), work)
        inputs.stock_inputs(a.romset.resolve(), work / 'roms', work)
        sources = {'disc/%02d' % n: path.read_bytes() for n, path in tracks.items()}
        for machine, members in json.loads((KIT / 'rom_inputs.json').read_text())['sets'].items():
            for name in members:
                sources['rom/' + machine + '/' + name] = (work / 'roms' / machine / name).read_bytes()
        expected = plan['sources']['x68k']
        if zipfile.is_zipfile(a.x68k):
            with zipfile.ZipFile(a.x68k) as z:
                hits = [z.read(i) for i in z.infolist() if i.file_size == expected['bytes']]
        else:
            hits = [a.x68k.read_bytes()]
        hits = [data for data in hits if sha(data) == expected['sha256']]
        require(bool(hits), 'missing matching X68000 System disk')
        sources['x68k'] = hits[0]
        resources = Resources(plan, (KIT / 'resources.sxr').read_bytes(), sources)
        if a.check:
            print('All selected source inputs verified')
            return
        final = work / 'outputs'
        final.mkdir()
        for name, row in plan['outputs'].items():
            if not wanted(name, a.region, a.audio, a.platform):
                continue
            dest = final / name
            dest.parent.mkdir(parents=True, exist_ok=True)
            if row['kind'] == 'zip':
                inputs.zip_members(dest, {n: resources.emit(spec) for n, spec in row['members'].items()})
            elif row['kind'] == 'file':
                shutil.copyfile(KIT / row['path'], dest)
            elif row['kind'] == 'pack':
                import recipe_music
                pack = work / 'strider_ex.cpk'
                recipe_music.build(plan['music'], resources, pack)
                inputs.zip_members(dest, {'strider_ex.cpk': pack.read_bytes()})
            else:
                raise ValueError('unknown output recipe')
        import verify
        verify.verify(final, a.region, a.audio, a.platform)
        for src in final.rglob('*'):
            dest = a.out_dir / src.relative_to(final)
            require(not any((parent.is_symlink() or (parent.exists() and (not parent.is_dir())) for parent in (dest.parent, *dest.parents))), 'invalid output parent')
            if src.is_file() and dest.exists():
                require(not dest.is_symlink() and dest.is_file() and (sha(dest.read_bytes()) == sha(src.read_bytes())), 'output conflict: ' + str(dest))
        shutil.copytree(final, a.out_dir, dirs_exist_ok=True)
        print('Strider EX reconstructed:', a.out_dir)
if __name__ == '__main__':
    main()
