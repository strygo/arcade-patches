#!/usr/bin/env python3
"""Build Final Fight EX and its regional CPS+ soundtrack from owned ROMs and discs."""
from __future__ import annotations

import sys as _native_sys
from pathlib import Path as _NativePath
if __name__ == '__main__':
    _native_sys.path.insert(0, str(_NativePath(__file__).resolve().parent))
    from kit_cli import install as _native_errors
    _native_errors()
if __name__ == '__main__' and ('--collection-layout' in _native_sys.argv or '--describe-json' in _native_sys.argv or '--emit-definition' in _native_sys.argv):
    _native_sys.path.insert(0, str(_NativePath(__file__).resolve().parent))
    from native_collection import main as _native_main
    raise SystemExit(_native_main(_NativePath(__file__).resolve().parent))

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile
import zipfile
import zlib

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from ffcd import romset as reader  # noqa: E402
from rom_sources import publish_tree, RomError  # noqa: E402

SETS = {"us": "ffightus01", "jp": "ffightjs01"}
from ffight_sources import WORLD
J_GFX = [f"ffj_{n}" for n in ("09.4b", "01.4a", "13.9b", "05.9a", "24.5e", "17.5c", "38.8h", "32.8f",
                              "10.5b", "02.5a", "14.10b", "06.10a", "25.7e", "18.7c", "39.9h", "33.9f")]
NEEDS = {
    "us": [(('ffight',), WORLD), (('ffightu', 'ffight'), ['ffu_43.12h']),
           (('ffightj', 'ffight'), ['ffj_30.bin', 'ffj_31.bin'])],
    "jp": [(('ffight',), WORLD), (('ffightj', 'ffight'),
           ['ff36.bin', 'ff42.bin', 'ff43.bin', 'ffj_30.bin', 'ffj_31.bin'] + J_GFX)],
}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def require(ok, message):
    if not ok:
        raise ValueError(message)


def manifest():
    doc = json.loads((HERE / "kit.json").read_text())
    require(doc['schema'] == 1, "Unsupported kit")
    for name, digest in doc['files'].items():
        p = HERE / name
        require(p.resolve().is_relative_to(HERE) and p.is_file() and sha(p.read_bytes()) == digest,
                "Kit file missing or changed: " + name)
    return json.loads((HERE / "outputs.json").read_text())


def write_zip(path, files):
    path.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(path, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, data in sorted(files.items()):
            entry = zipfile.ZipInfo(name, (1980, 1, 1, 0, 0, 0))
            entry.compress_type = zipfile.ZIP_DEFLATED
            entry.create_system = 3
            entry.external_attr = 0o100644 << 16
            archive.writestr(entry, data, compresslevel=9)


def write_mra(region, members, out):
    text = (HERE / 'mras' / (SETS[region] + '.mra')).read_text()
    def crc(match):
        name = match[1]
        require(name in members, "MRA names missing member " + name)
        return f'name="{name}" crc="{zlib.crc32(members[name]) & 0xffffffff:08x}"'
    text = re.sub(r'name="([^"]+)"\s+crc="[0-9a-fA-F]+"', crc, text)
    name = 'Final Fight EX (' + ('USA' if region == 'us' else 'Japan') + ')'
    text = re.sub(r'<name>[^<]*</name>', '<name>' + name + '</name>', text, count=1)
    path = out / '_Arcade/_Arcade Patches/_Enhanced Versions' / ('_Japan' if region == 'jp' else '') / (name + '.mra')
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text)


def build(args):
    outputs = manifest()
    platforms = ('hbmame', 'mister') if args.platform == 'all' else (args.platform,)
    audio = 'mister' in platforms and args.audio in ('both', 'cpsplus')
    discs = {r: p.resolve() for r, p in (('us', args.disc_us), ('jp', args.disc_jp)) if p}
    regions = tuple(r for r in SETS if r in discs) if args.region in (None, 'both') else (args.region,)
    if args.check and not discs:
        regions = ('us', 'jp') if args.region in (None, 'both') else (args.region,)
    else:
        require(regions and all(r in discs for r in regions), 'Supply the disc for each selected region')
        require(args.region != 'both' or len(regions) == 2, '--region both requires both discs')
    romset = (args.romset or (args.rompath[0] if args.rompath else Path('roms'))).resolve()
    if args.rompath:
        os.environ['CAPCOM_ARCADE_ROM_PATH'] = os.pathsep.join(map(str, args.rompath))
    for region in regions:
        for stems, names in NEEDS[region]:
            reader.read(romset, stems, names)
    if args.check and not discs:
        print('PASS selected arcade inputs'); return
    for module, package in (('numpy', 'numpy'), ('PIL', 'Pillow')):
        try:
            __import__(module)
        except ImportError:
            raise ValueError(f'Install {package} for this Python: {sys.executable} -m pip install {package}')
    import cpsplus_audio
    cpsplus_audio.configure(args)
    if audio:
        cpsplus_audio.verify_core(outputs['core'])
    work = (args.work or HERE / 'work').resolve()
    work.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='ffex-', dir=work) as temp:
        run = Path(temp)
        images = {r: cpsplus_audio.data_track(discs[r], run, require_audio=audio) for r in regions}
        if args.check:
            print('PASS selected arcade and disc inputs'); return
        if audio:
            cpsplus_audio.prepare()       # pinned helper, before rendering anything slow
        for region in regions:
            cfg_path = HERE / 'paths.json'
            saved = cfg_path.read_bytes() if cfg_path.exists() else None
            try:
                cfg_path.write_text(json.dumps({region: str(images[region]), 'romset': str(romset)}))
                subprocess.run([sys.executable, str(HERE / 'build/pipeline.py'), region, '--from-inputs',
                                '--no-gate', '--root', str(run / region)], cwd=HERE, check=True)
            finally:
                if saved is None:
                    cfg_path.unlink(missing_ok=True)
                else:
                    cfg_path.write_bytes(saved)
        stage = run / 'output'
        archives = {}
        for region in regions:
            source = run / region / (region + '_set') / (SETS[region] + '.zip')
            with zipfile.ZipFile(source) as z:
                members = {n: z.read(n) for n in z.namelist()}
            require({n: sha(b) for n, b in members.items()} == outputs['sets'][SETS[region]],
                    SETS[region] + ': reconstructed ROMs differ; no outputs installed')
            archives[region] = members
            write_zip(stage / 'hbmame' / (SETS[region] + '.zip'), members)
            if 'mister' in platforms:
                write_zip(stage / 'mister/games/hbmame' / (SETS[region] + '.zip'), members)
                if args.audio != 'cpsplus':
                    write_mra(region, members, stage / 'mister')
        if audio:
            cpsplus_audio.stage(stage, archives, discs, run, outputs, write_zip)
        if 'hbmame' not in platforms:
            shutil.rmtree(stage / 'hbmame')
        files = {p.relative_to(stage).as_posix(): p.read_bytes() for p in stage.rglob('*') if p.is_file()}
        publish_tree(args.out_dir, files)
        print('PASS Final Fight EX: ' + ', '.join(SETS[r] for r in regions))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--region', choices=('us', 'jp', 'both'))
    parser.add_argument('--disc-us', type=Path)
    parser.add_argument('--disc-jp', type=Path)
    parser.add_argument('--romset', type=Path)
    parser.add_argument('--rompath', type=Path, action='append', default=[])
    parser.add_argument('--platform', choices=('all', 'hbmame', 'mister'), default='all')
    parser.add_argument('--audio', choices=('both', 'arcade', 'cpsplus'), default='both')
    parser.add_argument('--work', type=Path)
    parser.add_argument('--out-dir', type=Path, default=Path('out'))
    parser.add_argument('--check', action='store_true')
    parser.add_argument('--debug', action='store_true', help='show diagnostic tracebacks')
    parser.add_argument('--tools-cache', type=Path)
    parser.add_argument('--tools-bundle', type=Path)
    parser.add_argument('--offline', action='store_true')
    build(parser.parse_args())


if __name__ == '__main__':
    try:
        main()
    except (RomError, ValueError, OSError, subprocess.CalledProcessError) as exc:
        raise SystemExit(str(exc))
