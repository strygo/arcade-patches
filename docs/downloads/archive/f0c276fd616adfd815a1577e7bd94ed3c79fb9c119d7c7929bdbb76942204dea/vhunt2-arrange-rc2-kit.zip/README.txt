Night Warriors 2 Arrange — reconstruction kit



Version: rc2 (2026-10-13)

Backport by: Steve Gordon (https://x.com/strygo)



Night Warriors 2 Arrange (Vampire Hunter 2 Arrange in Japan) is one of the arranged editions in Capcom's 2005 PlayStation 2 Vampire: Darkstalkers Collection, and it never had an arcade release. This backport rebuilds it as a CPS-2 game.

It keeps Vampire Hunter 2's presentation, with Pyron as the final boss, and adds the four Vampire Savior fighters it lacked: Jedah, Lilith, Q-Bee and B.B. Hood (Bulleta in Japan). Dee, the fighter Capcom made for the Arrange, joins them on his own select cell.

The game system follows the Arrange: rounds without recoverable health, revised damage and Dark Force, counter hits that flash white and can force a knockdown, equal hits that trade, timed blocks that stop chip damage, and slow-motion KOs. Every CPU route ends with Huitzil and Pyron.

The four added fighters bring their themes from Vampire Savior 2's arcade music, two each.

Hidden fighters are picked from the bottom cell: press Down to spin the roulette, Start five times for Shadow, or Start seven times for Marionette. Hold Start while confirming Bishamon for Oboro Bishamon, or Jon Talbain for his dark form.

The operator menu adds a ninth difficulty, NIGHTMARE. At NIGHTMARE, a player who wins the secret Oboro Bishamon fight then faces Dee.

B.B. Hood's spoken intro against Jon Talbain is back, from the original Vampire Savior.

The USA build, Night Warriors 2 Arrange, is in English, with our translation; the Japan build keeps the Japanese.

This is a release candidate.



Changes:

- Jedah, Lilith, Q-Bee and B.B. Hood (Bulleta in Japan), with their Vampire Savior 2 themes

- Dee on his own select cell

- The Arrange's game system: rounds without recoverable health, revised damage and Dark Force, counter hits, trades, timed blocks, slow-motion KOs

- CPU routes that end with Huitzil and Pyron

- Roulette, Shadow and Marionette from the bottom cell; Oboro Bishamon and Jon Talbain's dark form with Start

- NIGHTMARE difficulty, and a secret fight with Dee

- B.B. Hood's spoken intro against Jon Talbain

- USA (Night Warriors 2 Arrange, English) and Japan (Vampire Hunter 2 Arrange) builds

WHAT YOU NEED
-------------

  1. Your PlayStation 2 disc image:
     "Vampire: Darkstalkers Collection" (Japan).
  2. Your arcade romsets, all Japanese:
       - vhunt2.zip  Vampire Hunter 2
       - vsav2.zip   Vampire Savior 2
       - vsavj.zip   Vampire Savior (its sound ROMs; a merged or split set
                     with vsav.zip works too)
  3. Python 3.10 or newer. Nothing else — no emulator, no assembler.

USAGE
-----

    python3 apply.py --iso <collection.iso> --rompath <romset folder> \
                     --out-dir out

This builds both regions (add --region us or --region jp for one) and creates:

    out/hbmame/<set>.zip    HBMAME
    out/mister/             ready to copy to a MiSTer SD card

The kit verifies every finished file automatically. It stops with an error if
the disc or a romset does not match.

SETS
----

    us    vhunt2s02  Night Warriors 2 Arrange (USA)
    jp    vhunt2s03  Vampire Hunter 2 Arrange (Japan)

ON MISTER
---------

Copy the contents of out/mister/ to the root of the MiSTer SD card:

    _Arcade/_Arcade Patches/_Restorations/<name>.mra          USA
    _Arcade/_Arcade Patches/_Restorations/_Japan/<name>.mra   Japan
    _Arcade/cores/jtcps2-cpsplus_20261006.rbf                  the CPS+ core
    games/hbmame/<set>.zip                                     the sets

These sets need the CPS+ core included here, not the standard jtCPS2 core,
and 128 MB of SDRAM. MiSTer uses the newest dated CPS+ core it finds.
If QSound was absent from your input, keep qsound.zip or qsound_hle.zip in
games/mame.

ON HBMAME
---------

The sets need HBMAME's CPS+ machine driver. Start them by set name.

LEGAL
-----

Unofficial fan backport. Not affiliated with or endorsed by Capcom. All game
titles, characters, and artwork remain the property of their owners. You must
own the disc and romsets used as inputs. The recipes carry only our own work:
code, translated text and layout. Do not sell this kit or distribute it
applied to game images. The CPS+ core's source and licenses are in core/.

ROM COLLECTIONS
---------------
Merged, split and complete ZIP/7z sets and extracted folders are accepted.
Use --rompath DIR (repeatable) or --romset FILE (repeatable). Names may
differ; required contents are verified by strong hashes. 7z needs installed
7-Zip. Use --check to preflight arcade inputs without supplying the disc.
Source archives are never modified.
