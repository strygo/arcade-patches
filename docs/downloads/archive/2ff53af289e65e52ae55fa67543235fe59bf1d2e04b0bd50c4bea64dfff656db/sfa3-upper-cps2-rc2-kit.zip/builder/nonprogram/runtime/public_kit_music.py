"""Pinned PCM16 to PCM8 music conversion, with no embedded sound samples.

Extracted from upper_music_samples.py at a7cebea0b972a1af39dda42ca1a88c6830f9d919.
Original function identity is recorded in upper_public_music_recipes.json.
"""
from fractions import Fraction
import math
import numpy as np
import scipy
from scipy.signal import resample, resample_poly
from public_kit_media import require, digest

SOURCE_RATE = 44100


def convert(pcm16, plan):
    require(np.__version__ == '2.2.6' and scipy.__version__ == '1.18.0', 'Pinned sample resampler versions required')
    pcm = np.asarray(pcm16, dtype=np.float64)
    require(pcm.ndim == 1 and len(pcm) == plan['source_frames'], 'Source PCM16 dimensions')
    ratio = Fraction(plan['resample_rate_hz'], SOURCE_RATE)
    intro = plan['intro_frames']
    if plan['source_loop_enabled']:
        first = plan['source_loop_start']; loop = pcm[first:]
        require(len(loop) == plan['source_loop_frames'] and len(loop) > 0, 'Source loop extent')
        # Actual loop context avoids treating the intro's end as zero-padding.
        context = np.r_[pcm, np.tile(loop, max(1, math.ceil(64/len(loop))))]
        lead = resample_poly(context, ratio.numerator, ratio.denominator,
            window=('kaiser',8.6), padtype='constant')[:intro]
        # A periodic FFT resampler preserves the integer converted loop cycle,
        # instead of cutting an arbitrary resampling phase and padding its seam.
        cycle = resample(loop, plan['loop_frames'])
        filtered = np.r_[lead, cycle]
    else:
        filtered = resample_poly(pcm, ratio.numerator, ratio.denominator,
            window=('kaiser',8.6), padtype='constant')[:intro]
    require(len(filtered) == plan['pcm8_frames'], 'Converted PCM extent differs from plan')
    rounded = np.rint(filtered/256)
    clipped = int(np.count_nonzero((rounded < -128) | (rounded > 127)))
    quantized = np.clip(rounded,-128,127).astype(np.int8)
    residual = filtered-quantized.astype(np.float64)*256
    error = float(np.sqrt(np.mean(residual**2))); signal = float(np.sqrt(np.mean(filtered**2)))
    metrics = {'pcm8_sha256': digest(quantized.tobytes()), 'saturated_quantized_frames': clipped,
        'filtered_pcm16_rms': signal, 'quantization_error_pcm16_rms': error,
        'quantization_snr_db': 20*math.log10(signal/error) if signal and error else None,
        'peak_abs_pcm8': int(np.max(np.abs(quantized.astype(np.int16)))),
        'quantization': 'nearest ties to even, saturate signed PCM8; no gain normalization',
        'intro_resampling': 'polyphase Kaiser8.6 with source loop future context or one-shot zero padding',
        'loop_resampling': 'periodic FFT bandlimited to the converted integer cycle; no seam fade'}
    if plan['source_loop_enabled']:
        metrics['converted_loop_wrap_step_pcm8'] = int(quantized[intro])-int(quantized[-1])
        metrics['converted_intro_join_step_pcm8'] = int(quantized[intro])-int(quantized[intro-1]) if intro else None
        metrics['source_loop_wrap_step_pcm16'] = int(pcm[plan['source_loop_start']])-int(pcm[-1])
    return quantized.tobytes(), metrics

