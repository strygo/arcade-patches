SFZ3 Upper — standalone reconstruction kit

This kit reconstructs the USA and Japanese games.
It extracts the original resources from your media, then replays recipes:
program/ rebuilds the program ROMs from copies of your media, fills and our own
code and data; nonprogram/ rebuilds graphics, samples and sound the same way. The
converted music scores ship encrypted with a key derived from your Naomi program.
It does not contain the development build chain or original game media.

Requirements: Python 3.12 or newer, NumPy 2.2.6, SciPy 1.18.0 and chdman.
Use the original MAME-format USA and
Japanese arcade ZIPs, the declared PS2 US/JP discs and Naomi CHD/PIC archive. Exact input
identities are in the included media/audio/ending contracts; other revisions
fail explicitly. A compiler or source checkout is not required.

Install the pinned Python dependencies into your chosen Python environment:
  python3 -m pip install -r /path/to/kit/requirements.txt

Run from any directory (quote paths containing spaces):
  python3 /path/to/kit/build.py --rompath /path/to/mame-roms \
    --ps2-us /path/to/us-disc.chd --ps2-jp /path/to/jp-disc.chd \
    --naomi-chd /path/to/naomi.chd --naomi-pic /path/to/sfz3ugd.zip \
    --chdman /path/to/chdman --work /external/fresh-build \
    --out /external/fresh-result

--rompath may be repeated. --work and --out must not already exist. Use external
storage with at least 8 GiB free; additional room is needed for original disc
extraction and output. Work files/logs can be deleted after a successful rebuild;
they are not dependencies for a future rebuild. No network download is needed.

Output: sfa3u.zip, sfz3j.zip and rebuild.json. Each archive must match all 26
physical member identities and the complete release ZIP hash before either
archive is published into the output directory. On failure no final output is
published; inspect the named stage log in --work/logs. This command does not
install, deploy or upload anything, and does not grant public-release approval.
