"""Build both exact release regions from original media with the standalone kit."""
import argparse
import hashlib
import json
import os
from pathlib import Path,PurePosixPath
import shutil
import subprocess
import sys
import time
sys.dont_write_bytecode=True
from public_kit_standalone_finalize import finalize,require

LAUNCHER="import json,runpy,sys;sys.path[:0]=json.loads(sys.argv.pop(1));runpy.run_path(sys.argv.pop(1),run_name='__main__')"

README='''SFZ3 Upper — standalone reconstruction kit

This kit reconstructs the USA and Japanese games.
It extracts the original resources from your media, then replays recipes:
program/ rebuilds the program ROMs from copies of your media, fills and our own
code and data; nonprogram/ rebuilds graphics, samples and sound the same way. The
converted music scores ship encrypted with a key derived from your Naomi program.
It does not contain the development build chain or original game media.

Requirements: Python 3.12 or newer, NumPy 2.2.6, SciPy 1.18.0 and chdman.
Use the original MAME-format USA and
Japanese arcade ZIPs, the declared PS2 US/JP discs and Naomi CHD/PIC archive. Exact input
identities are in the included media/audio/ending contracts; other revisions
fail explicitly. A compiler or source checkout is not required.

Install the pinned Python dependencies into your chosen Python environment:
  python3 -m pip install -r /path/to/kit/requirements.txt

Run from any directory (quote paths containing spaces):
  python3 /path/to/kit/build.py --rompath /path/to/mame-roms \\
    --ps2-us /path/to/us-disc.chd --ps2-jp /path/to/jp-disc.chd \\
    --naomi-chd /path/to/naomi.chd --naomi-pic /path/to/sfz3ugd.zip \\
    --chdman /path/to/chdman --work /external/fresh-build \\
    --out /external/fresh-result

--rompath may be repeated. --work and --out must not already exist. Use external
storage with at least 8 GiB free; additional room is needed for original disc
extraction and output. Work files/logs can be deleted after a successful rebuild;
they are not dependencies for a future rebuild. No network download is needed.

Output: sfa3u.zip, sfz3j.zip and rebuild.json. Each archive must match all 26
physical member identities and the complete release ZIP hash before either
archive is published into the output directory. On failure no final output is
published; inspect the named stage log in --work/logs. This command does not
install, deploy or upload anything, and does not grant public-release approval.
'''


def readme():
    return README


def file_pin(p):
    with p.open('rb')as stream:hashed=hashlib.file_digest(stream,'sha256').hexdigest()
    return {'bytes':p.stat().st_size,'sha256':hashed}


def relative(name):
    require(type(name)is str and name and '\\'not in name,'Portable kit path required')
    value=PurePosixPath(name)
    require(not value.is_absolute()and all(p not in ('','.','..')for p in name.split('/'))and str(value)==name,'Nonportable kit path: '+name)
    return value


def local(root,name):
    result=root
    for part in relative(name).parts:
        result=result/part;require(not result.is_symlink(),'Kit symlink forbidden')
    require(result.resolve().is_relative_to(root.resolve()),'Kit path escapes root')
    return result


def validate(root,manifest):
    require(root.is_dir()and not root.is_symlink(),'Real kit root required')
    require(set(manifest)=={'schema','files','namespaces','archive_contracts','archive_names'}and manifest['schema']==2,'Standalone kit manifest schema')
    actual={}
    for p in root.rglob('*'):
        require(not p.is_symlink(),'Kit symlink forbidden')
        if p.is_file()and p!=root/'kit.json':actual[p.relative_to(root).as_posix()]=p
        else:require(p.is_dir()or p==root/'kit.json','Unsupported kit file type')
    require(set(actual)==set(manifest['files']),'Exact kit file inventory differs')
    for name,pin in manifest['files'].items():
        require(set(pin)=={'bytes','sha256'}and type(pin['bytes'])is int and pin['bytes']>=0,'Kit file identity schema')
        require(file_pin(local(root,name))==pin,'Changed kit file: '+name)
    require(set(manifest['namespaces'])=={'media','audio','ending','program','nonprogram'},'All five standalone namespaces required')
    for name,row in manifest['namespaces'].items():
        require(set(row)=={'entrypoint','python_paths','config','config_flag'},'Namespace schema: '+name)
        require(row['entrypoint']in actual and row['entrypoint'].endswith('.py'),'Inventoried entrypoint required')
        require(type(row['python_paths'])is list and row['python_paths'],'Explicit local Python paths')
        for path in row['python_paths']:require(local(root,path).is_dir(),'Missing namespace Python directory')
        if row['config']is None:require(row['config_flag']is None,'Config flag without config')
        else:require(row['config']in actual and row['config_flag']in ('--plan','--contract'),'Pinned namespace config')
    require(manifest['archive_contracts']in actual,'Pinned archive contracts required')
    return manifest


def run(args):
    root=args.kit.resolve();manifest_blob=(root/'kit.json').read_bytes();manifest=validate(root,json.loads(manifest_blob))
    require(not args.work.exists()and args.work.parent.is_dir(),'Fresh work directory with existing parent required')
    require(not args.out.exists()and args.out.parent.is_dir(),'Fresh output directory with existing parent required')
    require(not args.work.resolve().is_relative_to(root)and not args.out.resolve().is_relative_to(root),'Generated files must be outside the kit')
    require(args.work.resolve()!=args.out.resolve(),'Work and final output must differ')
    require(shutil.disk_usage(args.work.parent).free>=8*1024**3,'At least 8 GiB free scratch space required')
    for path in (args.ps2_us,args.ps2_jp,args.naomi_chd,args.naomi_pic,args.chdman):require(path.is_file(),'Required original input or tool missing: '+str(path))
    require(args.rompath and all(p.is_dir()for p in args.rompath),'At least one existing ROM directory required')
    args.work.mkdir();scratch=args.work/'scratch';scratch.mkdir();logs=args.work/'logs';logs.mkdir();temporary=args.work/'tmp';temporary.mkdir()
    env={k:v for k,v in os.environ.items()if k not in ('PYTHONPATH','PYTHONHOME','TEMPLATES')}
    env.update(TMPDIR=str(temporary.resolve()),TMP=str(temporary.resolve()),TEMP=str(temporary.resolve()))
    def unchanged():
        require((root/'kit.json').read_bytes()==manifest_blob,'Kit manifest changed during execution');validate(root,manifest)
    def stage(name,extra):
        unchanged();require(shutil.disk_usage(args.work).free>=1024**3,'Less than 1 GiB scratch reserve remaining')
        row=manifest['namespaces'][name];paths=[str(local(root,p).resolve())for p in row['python_paths']]
        command=[sys.executable,'-I','-B','-c',LAUNCHER,json.dumps(paths),str(local(root,row['entrypoint']))]
        if row['config']is not None:command += [row['config_flag'],str(local(root,row['config']))]
        command += [str(v)for v in extra];log=logs/(name+'.log');print('Building '+name+'; log: '+str(log),flush=True);start=time.monotonic()
        with log.open('xb')as stream:
            child=subprocess.Popen(command,cwd=args.work,env=env,stdout=stream,stderr=subprocess.STDOUT)
            try:
                while child.poll()is None:
                    require(time.monotonic()-start<7200,'Stage exceeded two-hour limit: '+name)
                    require(log.stat().st_size<=8*1024**2,'Stage log exceeded 8 MiB: '+name)
                    require(shutil.disk_usage(args.work).free>=1024**3,'Scratch reserve exhausted: '+name)
                    time.sleep(.5)
            finally:
                if child.poll()is None:child.kill()
                child.wait()
        require(child.returncode==0,'Stage failed: '+name+'; inspect '+str(log));unchanged()
    originals=['--ps2-us',args.ps2_us.resolve(),'--ps2-jp',args.ps2_jp.resolve(),'--chdman',args.chdman.resolve(),'--scratch',scratch.resolve()]
    naomi=['--naomi-chd',args.naomi_chd.resolve(),'--naomi-pic',args.naomi_pic.resolve()]
    pools=args.work/'pools';audio=args.work/'audio';ending=args.work/'ending-pools';program=args.work/'program';other=args.work/'nonprogram'
    stage('media',originals+naomi+[v for p in args.rompath for v in ('--rompath',p.resolve())]+['--out',pools.resolve()])
    stage('audio',originals+naomi+['--out',audio.resolve()])
    stage('ending',originals+['--out',ending.resolve()])
    stage('program',['--pools',pools.resolve(),'--ending-pools',ending.resolve(),'--out',program.resolve()])
    stage('nonprogram',['--pools',pools.resolve(),'--audio',audio.resolve(),'--out',other.resolve()]);unchanged()
    report=finalize(program,other,json.loads(local(root,manifest['archive_contracts']).read_text()),args.out.resolve(),manifest['archive_names'])
    print('Complete: both exact 26-member release-baseline ZIPs written to '+str(args.out),flush=True)
    return report


def self_test():
    import copy
    import tempfile
    with tempfile.TemporaryDirectory(prefix='upper-wrapper-test-')as tmp:
        root=Path(tmp);(root/'code').mkdir();(root/'patches').mkdir()
        (root/'code'/'dependency.py').write_text('VALUE=731\n')
        (root/'code'/'entry.py').write_text("import dependency,sys\nassert dependency.VALUE==731 and sys.flags.isolated and sys.flags.dont_write_bytecode\n")
        (root/'plan.json').write_text('{}\n');(root/'contracts.json').write_text('{}\n')
        files={p.relative_to(root).as_posix():file_pin(p)for p in root.rglob('*')if p.is_file()}
        row={'entrypoint':'code/entry.py','python_paths':['code'],'config':None,'config_flag':None}
        manifest={'schema':2,'files':files,'namespaces':{n:dict(row)for n in ('media','audio','ending','program','nonprogram')},'archive_contracts':'contracts.json','archive_names':{'us':'sfa3u.zip','jp':'sfz3j.zip'}}
        (root/'kit.json').write_text(json.dumps(manifest));validate(root,manifest)
        subprocess.run([sys.executable,'-I','-B','-c',LAUNCHER,json.dumps([str(root/'code')]),str(root/'code'/'entry.py')],cwd=root,check=True)
        rejected=[]
        for label in ('changed-file','extra-file','escaping-path','symlink'):
            m=copy.deepcopy(manifest)
            if label=='changed-file':(root/'plan.json').write_text('changed')
            elif label=='extra-file':(root/'extra').write_text('x')
            elif label=='escaping-path':m['namespaces']['program']['python_paths']=['../outside']
            else:(root/'alias').symlink_to(root/'plan.json')
            try:validate(root,m)
            except ValueError:rejected.append(label)
            else:raise ValueError('Invalid kit accepted: '+label)
            if label=='changed-file':(root/'plan.json').write_text('{}\n')
            elif label=='extra-file':(root/'extra').unlink()
            elif label=='symlink':(root/'alias').unlink()
        validate(root,manifest)
    return {'passed':True,'isolated_local_dependency':True,'negative_controls':rejected,'media_read':False}


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--kit',type=Path,default=Path(__file__).resolve().parent)
    p.add_argument('--self-test',action='store_true')
    p.add_argument('--rompath',type=Path,action='append')
    for name in ('ps2-us','ps2-jp','naomi-chd','naomi-pic','chdman','work','out'):p.add_argument('--'+name,type=Path)
    args=p.parse_args()
    if args.self_test:print(json.dumps(self_test()));return
    require(args.rompath and all(getattr(args,n)for n in ('ps2_us','ps2_jp','naomi_chd','naomi_pic','chdman','work','out')),'All original input, work and output arguments required')
    run(args)

if __name__=='__main__':main()
