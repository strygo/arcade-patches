Street Fighter Alpha 3 Upper (CPS-2) — reconstruction kit

Version: rc2 (2026-11-10)
Backport by: Steve Gordon (https://x.com/strygo)

Street Fighter Alpha 3 Upper comes to CPS-2 with Guile, Fei Long, Dee Jay, T. Hawk, Evil Ryu and Shin Akuma. The boxer, Juli and Juni have their own cells on the select screen.
Guile, Fei Long, Dee Jay and T. Hawk bring their stages, music and arcade endings. The USA build includes the Street Fighter Alpha 3 English restoration; the Japan build keeps Japanese text and names.
This version includes Arcade mode and its two-player challenge. World Tour, Dramatic Battle and the other console modes are not included.
On MiSTer, it requires the included CPS+ core and 128 MB SDRAM. Computer play requires an HBMAME or FBNeo build that includes the Upper sets. This is a release candidate.

Changes in RC2:
- Fixed a freeze when the computer-controlled Shin Akuma throws you.
- Fixed Shin Akuma’s Raging Demon grabbing the opponent but never finishing, leaving them stuck.
- Fixed Shin Akuma’s air super spending meter without firing, and his recovery when he lands from it.
- Fixed T. Hawk’s throw holding a knocked-out opponent too long, and his missed Condor Dive landing late.
- Fixed Evil Ryu’s and Shin Akuma’s teleports, which moved the wrong distance and ran punch teleports at kick speed.
- Restored the label card and arrows on the ISM selection screen, and the FIGHTING STYLE SELECT side bands in the USA version.
- The USA select screen reads SELECT PLAYER again, and the added fighters’ portraits have their grey boxes with the cursor glow showing.
- Fixed Balrog’s Gigaton Blow and Shin M. Bison’s Final Psycho Crusher drawing broken graphics.
- Balrog, Juli and Juni play their own opening stories instead of Bison’s.
- Fixed M. Bison lingering beside Juni during the Ryu scene, and restored Juni’s victory pose.
- Fixed Evil Ryu’s match portrait showing Ryu’s face.
- Restored the added fighters’ rival and boss encounters and special intros, including Guile versus Charlie and Dee Jay versus Sakura.
- Dizzy stars appear above fighters’ heads again, including Shin Akuma’s.
- Evil Ryu fights in his cave and Karin on her ship, with their location names, and Balrog’s map reads LAS VEGAS in the USA version.
- Guile’s ending close-up shows his face instead of Ryu’s, Fei Long’s final ending background has its correct colors, and Balrog’s laboratory ending scene is layered correctly.
- Fixed the victory backgrounds for Balrog, Juli and Juni, which used Bison’s, and Sakura’s bow colors on the versus screen.
- The small fighters on the select screen show the color of the button you pressed, and Vega has his mask and claw.
- Fixed ranking colors for every ISM, including Shin Akuma’s eyes and Sodom’s X-ISM mask, and the colors on the character biography buttons.
- Attract mode shows the original fighter poses, Vega’s mask and claw, Blanka’s electric shock and Sodom’s black face ink.
- Fixed garbled characters in T. Hawk’s Japanese opening.
- Free Play now works on the NAOMI title, and title copyrights, registered marks and fades match each region.
- Updated nine USA win quotes, restored forest stage shading and the English attract website address.

INPUTS AND BUILD

The Arcade Patches builder app prepares everything it needs. To build by
hand, use Python 3.12 or 3.13 with NumPy 2.2.6, SciPy 1.18.0 and chdman.
On Windows, Python 3.13 can be installed alongside newer Python versions:
  py -3.13 -m pip install numpy==2.2.6 scipy==1.18.0
  py -3.13 apply.py <the arguments shown below>
Supply the original arcade ROM sets, USA Alpha
Anthology and Japanese Zero Fighter’s Generation PS2 discs, and the
Zero 3 Upper NAOMI GD-ROM CHD and sfz3ugd.zip security PIC archive.
The exact accepted input identities are listed in builder/media/inputs.json.

The manual command accepts the original PS2 ISOs or their matching CHDs.
python3 apply.py --rompath /path/to/roms --ps2-us /path/to/us.chd \
  --ps2-jp /path/to/jp.chd --naomi-chd /path/to/gdl-0002.chd \
  --naomi-pic /path/to/sfz3ugd.zip --chdman /path/to/chdman \
  --work /external/fresh-work --out-dir /external/fresh-output

Both output directories must be new. Allow at least 8 GiB of free storage.
Inputs and tools may be kept inside the extracted kit, and --work and
--out-dir may point to new folders there. Their parent folders must exist.
Keep work and output separate; choose new paths when retrying a failed run.
--chdman accepts the executable, its containing folder, or a command on PATH.
Required kit files are checked for missing files and changes; extra files
and folders are allowed. Restore damaged kit files from the original ZIP.
--rompath may be repeated; --platform selects hbmame, fbneo or mister.
The default builds all three layouts. No network download is needed.

OUTPUTS

hbmame/ and fbneo/ contain the regional game ZIPs. Use an HBMAME or FBNeo
build that includes the Upper sets. The mister/ tree contains
the regional launchers, game ZIPs and CPS+ core; copy its contents to the
root of your MiSTer SD card. MiSTer requires 128 MB SDRAM.
The builder never uploads or installs files automatically.
