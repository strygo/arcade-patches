#!/usr/bin/env python3
"""Rebuild Vampire Savior Arrange from your own arcade ROMs and Collection disc."""
import argparse,json,shutil,tempfile
from pathlib import Path
from rom_sources import Resolver,search_paths,write_zip,publish_tree
from vsa_codec import Inputs,reconstruct,scene_pack
from cps2_code_guard import check_archive,require_code_spans
HERE=Path(__file__).resolve().parent


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--iso',required=True);p.add_argument('--chdman')
    p.add_argument('--romset',action='append',default=[]);p.add_argument('--rompath',action='append',default=[])
    p.add_argument('--region',choices=('us','jp','all'),default='all');p.add_argument('--out-dir',required=True)
    a=p.parse_args();out=Path(a.out_dir).resolve();out.parent.mkdir(parents=True,exist_ok=True)
    value=json.loads((HERE/'reconstruction.json').read_text());catalog=json.loads((HERE/'rom_inputs.json').read_text())['sets']
    paths=[]
    for path in a.romset:paths+=search_paths(path,a.rompath,HERE)
    resolver=Resolver(dict.fromkeys(paths or search_paths(None,a.rompath,HERE)),hints=[*catalog,'qsound','qsound_hle'],exclude=[out],progress=print)
    with tempfile.TemporaryDirectory(prefix='.vsa-',dir=out.parent)as directory:
        work=Path(directory);roms=work/'roms';roms.mkdir();stage=work/'stage'
        for name,pins in catalog.items():write_zip(roms/(name+'.zip'),resolver.resolve(list(pins.values())))
        inputs=Inputs(roms,a.iso,value['spec'],work,a.chdman)
        regions=('us','jp')if a.region=='all'else(a.region,)
        for region in regions:
            q=value['regions'][region];native=reconstruct(inputs,q)
            require_code_spans(value['spec']['code_spans'],key=native['vsavj.key'])
            members={q['names'][n]:b for n,b in native.items()}
            game=stage/'hbmame'/(q['set']+'.zip');write_zip(game,members)
            if check_archive(game)['status']!='passed':raise ValueError('complete executable range audit failed')
            write_zip(stage/'mister/games/hbmame'/game.name,members)
            folder=stage/'mister/_Arcade/_Arcade Patches/_Restorations'/('_Japan'if region=='jp'else'');folder.mkdir(parents=True)
            for title in q['mras']:shutil.copyfile(HERE/'mras'/(title+'.mra'),folder/(title+'.mra'))
        cpk=work/'vampire_arrange.cpk';scene_pack(inputs,value,cpk)
        write_zip(stage/'mister/games/CPS+/vampire_arrange.zip',{'vampire_arrange.cpk':cpk.read_bytes()})
        core=json.loads((HERE/'kit.json').read_text())['core'];dst=stage/'mister/_Arcade/cores'/core;dst.parent.mkdir(parents=True)
        shutil.copyfile(HERE/'core'/core,dst)
        publish_tree(out,{str(f.relative_to(stage)):f.read_bytes()for f in stage.rglob('*')if f.is_file()})
    print('Built '+', '.join(regions)+'; all ROM members and the music pack verified.')
if __name__=='__main__':main()
