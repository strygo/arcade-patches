#!/usr/bin/env python3
"""Rebuild the USF2 CPS+ arrangement from owned NSP/XCI music; no pack-input shortcut."""
import argparse
import json
from pathlib import Path
import sys
from nsp import file_sha, select, toolset
from payload import require
from ffmpeg_tools import prepare as prepare_ffmpeg

HERE = Path(__file__).resolve().parent


def encode_track(source, path, relative, command, decoder, scratch, ending=None):
    """Keep the accepted base/ending conversion and loop rules in one pass."""
    opus = source.read_switch_opus(path)
    pcm = source.decode_pcm(decoder, opus, scratch)
    meta = source.TrackMeta(sample_rate=48000, channels=opus.channels, codec=source.CODEC_ADX,
        coef1=source.adxcodec.calc_coeffs(source.adxcodec.DEFAULT_CUTOFF,48000)[0],
        coef2=source.adxcodec.calc_coeffs(source.adxcodec.DEFAULT_CUTOFF,48000)[1],
        name=path.stem, source='USF2:'+relative)
    bake = command in source.BAKE_COMMANDS if ending is None else ending['identity'] in (16,18)
    if opus.loop_end:
        start,end = source.align_loop(opus.loop_start,opus.loop_end,opus.total)
        if bake:
            if ending is None:start=max(start,source.BAKE_SAMPLES)
            pcm=source.bake_join(pcm,start,end,source.BAKE_SAMPLES)
        meta.loop_start_sample,meta.loop_end_sample=start,end
        meta.loop_start_byte=source.adxcodec.samples_to_stream_byte(start,opus.channels)
        meta.loop_end_byte=source.adxcodec.samples_to_stream_byte(end,opus.channels)
    elif bake:
        raise ValueError('Expected source loop for command '+hex(command))
    stream=source.adxcodec.encode(pcm,opus.channels,48000)
    if opus.loop_end:stream=stream[:meta.loop_end_byte]
    return stream,meta


def validate_routes(required, commands, config):
    expected={17:(216,'remix/new/e_satsui.opus'),18:(217,'remix/new/e_kyoki.opus'),16:(215,'remix/rem_e_gou_d7.opus')}
    require(config['schema']==1 and len(config['tracks'])==3 and
            [(r['identity'],r['command'],r['source']) for r in config['tracks']]==
            [(identity,*values) for identity,values in expected.items()] and
            config['tracks'][2]['shared_identities']==[16,19], 'Unknown ending track recipe')
    require(commands==sorted(set(commands)) and set(commands)==(set(required)-{0x38,0xe0})|{0x3d,0xd2},
            'Native music alias domain differs')


def pack_writer(source):
    """One current header policy for direct source encoding and qualification."""
    return source.PackWriter(source.current_backport_protocol(),
        title='Ultra SFII backport with variant endings')


def build(nsp, keys, pin, out, work, tools_work=None):
    prepare_ffmpeg()
    require(Path(keys).is_file(), 'Supply your own Switch prod.keys')
    require(not Path(out).exists(), 'Choose a fresh music output')
    sys.path.insert(0, str(HERE/'sound'))
    from pack import build_usf2_remix as source
    from pack.format import PackWriter,PackReader,TriggerRow,VERB_PLAY,VERB_STOP
    from switch_source import open_program,resource,extract
    import tempfile
    manifest=json.loads((HERE/'kit.json').read_text())
    config=json.loads((HERE/'sound/variant_ending_sources.json').read_text())
    commands=json.loads((HERE/'sound/music_commands.json').read_text())
    required=source.commands();validate_routes(required,commands,config)
    work=Path(work);work.mkdir(parents=True,exist_ok=True)
    tools=toolset(tools_work or work/'source')
    writer=pack_writer(source)
    audit=[]
    with tempfile.TemporaryDirectory(prefix='music-source-',dir=work) as folder:
        scratch=Path(folder);bgm=scratch/'bgm';bgm.mkdir()
        # open_program verifies the complete Program while copying it. Both
        # base and ending tracks share this single authenticated extraction.
        with open_program(Path(nsp),pin,scratch) as (program,ticket,selected):
            resource(tools['nstool'],keys,program,ticket,pin,scratch/'resource')
            extract(tools['nstool'],keys,program,ticket,source.BGM_PATH,bgm)
        sources=source.match_sources(bgm,required)
        endings=[]
        for row in config['tracks']:
            path=bgm/row['source']
            require(path.is_file() and file_sha(path)==row['sha256'],'Ending source stream changed')
            endings.append((row['command'],path,row))
        tracks=[(cmd,path,None)for cmd,path in sorted(sources.items())]+endings
        require(len(tracks)==68,'Complete 68-track source family required')
        for index,(command,path,ending) in enumerate(tracks):
            relative=path.relative_to(bgm).as_posix()
            with tempfile.TemporaryDirectory(prefix='decode-',dir=scratch) as decoded:
                stream,meta=encode_track(source,path,relative,command,tools['decoder'],Path(decoded),ending)
            require(writer.triggers[command].verb==0,'Music command already has an owner')
            track=writer.add_track(stream,meta)
            writer.set_trigger(command,TriggerRow(verb=VERB_PLAY,track=track,gain=source.DEFAULT_GAIN,suppress=1))
            audit.append(dict(command=command,source=relative,source_sha256=file_sha(path),bytes=len(stream)))
            print(f'[{index+1:02}/68] {path.name}',flush=True)
        select=writer.triggers[0x34]
        require(writer.triggers[0xd3].verb==0,'Select alias already has an owner')
        writer.set_trigger(0xd3,TriggerRow(verb=VERB_PLAY,track=select.track,gain=source.DEFAULT_GAIN,suppress=1))
        for command in commands:
            alias=command+511
            require(writer.triggers[alias].verb==0,'Native-only alias already has an owner')
            writer.set_trigger(alias,TriggerRow(verb=VERB_STOP,suppress=0))
        for command in (0x38,0x3d,0xe0):
            require(writer.triggers[command].verb==0,'Native fallback command was captured')
        writer.write(out,sidecar=False)
    reader=PackReader(out)
    try:
        require(reader.crc_check()==(True,True) and len(reader.tracks)==68 and
                sum(r.verb==VERB_PLAY for r in reader.triggers)==69,'Incomplete final music pack')
    finally:reader.close()
    require(file_sha(out)==manifest['cpk_sha256'],'Rebuilt CPK differs from the selected arrangement')
    Path(str(out)+'.json').write_text(json.dumps(dict(schema=1,status='verified_direct_68_track_pack',
        sha256=file_sha(out),source_program_sha256=selected['program_sha256'],resource_sha256=pin['resource_sha256'],
        intermediate_pack_files=0,final_pack_writes=1,source_music_extractions=1,tracks=audit),indent=2,sort_keys=True)+'\n')
    return Path(out)


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--source', '--nsp', '--xci', dest='nsp', type=Path, required=True); p.add_argument('--keys', type=Path, required=True)
    p.add_argument('--out', type=Path, required=True); p.add_argument('--work', type=Path, required=True)
    a = p.parse_args(); pins = json.loads((HERE/'kit.json').read_text())['nsp']
    found = []
    for pin in pins.values():
        try: select(a.nsp, pin)
        except ValueError: continue
        found.append(pin)
    require(len(found) == 1, 'Unsupported or ambiguous regional base NSP/XCI')
    require(not a.out.exists(), 'Choose a fresh CPK output')
    build(a.nsp, a.keys, found[0], a.out, a.work)
    print('PASS exact NSP/XCI-derived CPS+ arrangement')
