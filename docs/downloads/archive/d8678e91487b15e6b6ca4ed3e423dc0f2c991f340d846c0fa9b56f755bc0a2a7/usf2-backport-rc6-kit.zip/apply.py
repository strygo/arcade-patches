#!/usr/bin/env python3
"""Reconstruct the selected USF2 adaptation from arcade inputs and owned NSP/XCI files."""
# BEGIN ARCADE KIT ENTRY
if __name__ == "__main__":
    import sys as _kit_sys
    if len(_kit_sys.argv) == 1 and _kit_sys.stdin.isatty() and _kit_sys.stdout.isatty():
        import importlib.util as _kit_import
        from pathlib import Path as _KitPath
        _kit_root = _KitPath(__file__).resolve().parent
        _kit_spec = _kit_import.spec_from_file_location("_kit_frontend", _kit_root / "_kit_runtime/frontend.py")
        _kit_frontend = _kit_import.module_from_spec(_kit_spec)
        _kit_spec.loader.exec_module(_kit_frontend)
        raise SystemExit(_kit_frontend.guided(_kit_root))
# END ARCADE KIT ENTRY

import sys as _native_sys
from pathlib import Path as _NativePath
if __name__ == '__main__':
    _native_sys.path.insert(0, str(_NativePath(__file__).resolve().parent))
    from kit_cli import install as _native_errors
    _native_errors()
if __name__ == '__main__' and ('--collection-layout' in _native_sys.argv or '--describe-json' in _native_sys.argv or '--emit-definition' in _native_sys.argv):
    _native_sys.path.insert(0, str(_NativePath(__file__).resolve().parent))
    from native_collection import main as _native_main
    raise SystemExit(_native_main(_NativePath(__file__).resolve().parent))
import argparse
import contextlib
import json
import os
from pathlib import Path
import shutil
import sys
import tempfile
import zipfile
from nsp import file_sha, unlock
from payload import decode, post_patch, require, sha, read_payload, validate_bundle
import rom_sources
from policy import native_name, platforms_for
import stock_mame
import fbneo_names
from ffmpeg_tools import prepare as prepare_ffmpeg

HERE = Path(__file__).resolve().parent


def check_music_dependencies(selected, platforms, check=False):
    if check or 'mister' not in platforms or not selected:
        return
    prepare_ffmpeg()


def read_manifest():
    manifest = json.loads((HERE/'kit.json').read_text())
    require(manifest['schema'] == 2, 'Unsupported reconstruction kit')
    for relative, expected in manifest['files'].items():
        path = HERE/relative
        require(path.resolve().is_relative_to(HERE) and path.is_file() and file_sha(path) == expected,
                'Kit file missing or changed: ' + relative)
    validate_bundle(HERE, manifest)
    return manifest


def write_zip(path, files):
    path.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(path, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, data in sorted(files.items()):
            entry = zipfile.ZipInfo(name, (1980, 1, 1, 0, 0, 0))
            entry.compress_type = zipfile.ZIP_DEFLATED; entry.create_system = 3
            entry.external_attr = 0o100644 << 16
            archive.writestr(entry, data, compresslevel=9)


def reconstruct(record, inputs, key, bundle):
    result = {}
    for name, row in record['members'].items():
        require(Path(name).name == name and '\\' not in name, 'Invalid output member')
        source = inputs[row['source']] if row['source'] else b''
        data = decode(read_payload(HERE, row['payload'], bundle), row['payload'], source, key) if row.get('payload') else source
        data = post_patch(data, row.get('post_patch', []))
        require(len(data) == row['size'] and sha(data) == row['sha256'], 'Incorrect reconstructed member: ' + name)
        result[name] = data
    return result



def require_file(path, option):
    require(path is not None, 'Supply ' + option + ' with the path to your file.')
    supplied = str(path)
    path = path.expanduser().resolve()
    if not path.is_file():
        hint = (' On Windows, a leading / or \\ starts at the drive root; '
                'use inputs/game.nsp for a file inside the current folder.')
        raise ValueError(f'{option}: file not found: {supplied}\n'
                         f'Looked for: {path}\nCurrent folder: {Path.cwd()}\n'
                         'Use the actual filename and quote paths containing spaces.' + hint)
    return path


def unused_output():
    path = Path.cwd() / 'output-usf2'
    number = 2
    while path.exists() or path.is_symlink():
        path = Path.cwd() / f'output-usf2-{number}'
        number += 1
    return path


def prepare_arguments(args):
    supplied = {'us': args.nsp_us, 'jp': args.nsp_jp}
    if args.region is None:
        regions = [r for r, path in supplied.items() if path is not None]
        require(regions, 'Supply --source-us USA_GAME.nsp or --source-jp JAPAN_GAME.nsp '
                '(supported USA and Japanese XCI files also work).')
        args.region = regions[0] if len(regions) == 1 else 'all'
    regions = ('us', 'jp') if args.region == 'all' else (args.region,)
    for region in regions:
        path = require_file(supplied[region], '--source-' + region)
        setattr(args, 'nsp_' + region, path)
    args.keys = require_file(args.keys, '--keys')
    for path in args.rompath:
        require(path.expanduser().exists(),
                f'--rompath does not exist: {path.expanduser().resolve()}\n'
                f'Current folder: {Path.cwd()}\n'
                'Use roms for a subfolder here; /roms starts at the drive root on Windows.')
    if args.tools_bundle is not None:
        require(args.tools_bundle.expanduser().exists(),
                '--tools-bundle does not exist: ' + str(args.tools_bundle.expanduser().resolve()))
    if args.out_dir is None and not args.check:
        args.out_dir = unused_output()
    if args.out_dir is not None:
        supplied_output = args.out_dir.expanduser()
        require(not supplied_output.exists() and not supplied_output.is_symlink(),
                'Output already exists: ' + str(supplied_output.absolute()) +
                '\nChoose a new --out-dir, or omit it to select an unused folder automatically.')
        args.out_dir = supplied_output.resolve()
        parent = args.out_dir.parent
        while not parent.exists():
            parent = parent.parent
        require(parent.is_dir(), 'Output parent is not a folder: ' + str(parent))
    if args.work is not None:
        args.work = args.work.expanduser().resolve()
        require(not args.work.exists() or args.work.is_dir(),
                '--work must name a folder: ' + str(args.work))
        require(args.out_dir is None or not args.work.is_relative_to(args.out_dir),
                '--work must be outside the output folder.')
        if args.platform in ('all', 'mister') and not args.check:
            require(not (args.work/'usf2_arrange.cpk').exists(),
                    'Previous generated music exists in --work; choose a fresh --work folder.')


def print_completion(args, selected, platforms):
    root = args.out_dir
    print('PASS verified USF2 outputs:', root, flush=True)
    print('Finished. Your files are ready:')
    def list_files(label, folder):
        print(label + ':')
        for path in sorted((root/folder).rglob('*.zip')):
            print('  ' + str(path))

    if 'mame' in platforms:
        list_files('MAME', 'mame')
        print('  From your MAME folder, launch:')
        for region in sorted({r['region'] for r in selected.values()}):
            name, _ = stock_mame.destination(region)
            print(f'  mame {name} -rompath "{root / "mame"}" -nvram_directory nvram-usf2')
        print('  MAME checksum warnings are expected for these patched sets.')
    if 'hbmame' in platforms:
        list_files('HBMAME', 'hbmame')
        print('  With an HBMAME build that includes the USF2 sets, launch:')
        for name in sorted(selected):
            print(f'  hbmame {native_name(name)} -rompath "{root / "hbmame"}"')
    if 'mister' in platforms:
        list_files('MiSTer', 'mister')
        print('  Copy the CONTENTS of this folder to your MiSTer card: ' + str(root/'mister'))
        print('  Use the included CPS+ core; 128 MB SDRAM is required.')
    if 'darksoft' in platforms:
        list_files('Darksoft', 'darksoft')
        print('  Copy the game folders inside ' + str(root/'darksoft/games') +
              ' to the card games folder.')


def build(args):
    print("[1/5] Checking kit and input paths...", flush=True)
    kit = read_manifest()
    prepare_arguments(args)
    for option, variable in (("tools_cache","CPSPLUS_SWITCH_TOOLS_CACHE"),
                             ("tools_bundle","CPSPLUS_SWITCH_TOOLS_BUNDLE")):
        value = getattr(args, option, None)
        if value is not None:
            os.environ[variable] = str(value.expanduser().resolve())
    if getattr(args,"offline",False):
        os.environ["CPSPLUS_SWITCH_TOOLS_OFFLINE"] = "1"
    platforms = ('mame','hbmame','fbneo','mister','darksoft') if args.platform == 'all' else (args.platform,)
    selected = {n:r for n,r in kit['profiles'].items() if
                (args.region == 'all' or r['region'] == args.region) and
                platforms_for(n,platforms)}
    require(selected, 'No compatible outputs for the selected region and platform')
    print('Regions: ' + ', '.join(sorted({r['region'] for r in selected.values()})))
    print('Targets: ' + ', '.join(platforms))
    if args.out_dir is not None:
        print('Output: ' + str(args.out_dir))
    print('[2/5] Checking arcade ROMs...', flush=True)
    paths = rom_sources.search_paths(rompaths=args.rompath, kit=HERE)
    resolver = rom_sources.Resolver(paths, hints=('ssf2xj','ssf2t','qsound'),
                                   exclude=[args.out_dir] if args.out_dir else [], progress=print)
    names = {row['source'] for record in selected.values() for row in record['members'].values() if row['source']}
    inputs = resolver.resolve([r for r in kit['arcade_inputs'] if r['name'] in names])
    print('[3/5] Preparing verified helpers and Switch resources...', flush=True)
    check_music_dependencies(selected, platforms, args.check)
    with contextlib.ExitStack() as cleanup:
        if args.work is None:
            args.work = Path(cleanup.enter_context(tempfile.TemporaryDirectory(prefix='usf2-')))
        print('Scratch: ' + str(args.work), flush=True)
        build_outputs(args, kit, selected, platforms, inputs)


def build_outputs(args, kit, selected, platforms, inputs):
    supplied = dict(us=args.nsp_us, jp=args.nsp_jp)
    regions = {r['region'] for r in selected.values()}
    work = args.work
    work.mkdir(parents=True, exist_ok=True)
    keys = {r:unlock(supplied[r], args.keys, kit['nsp'][r], work/'source') for r in sorted(regions)}
    if args.check:
        print('PASS complete arcade and decrypted NSP/XCI preflight'); return
    print('[4/5] Reconstructing and verifying game files...', flush=True)
    require(args.out_dir and not args.out_dir.exists() and not args.out_dir.is_symlink(), 'Choose a fresh --out-dir')
    args.out_dir.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='.usf2-', dir=args.out_dir.parent) as temp:
        stage = Path(temp)/'output'; stage.mkdir()
        archives = {}
        for name, record in sorted(selected.items()):
            members = reconstruct(record, inputs, keys[record['region']], kit['payload_bundle'])
            native = stage/'native'/(name+'.zip'); write_zip(native, members)
            from verify import verify_archive
            verify_archive(native, record)
            archives[name] = members
            for platform in platforms_for(name,platforms):
                if platform == 'fbneo':
                    write_zip(stage/'fbneo'/(native_name(name)+'.zip'),
                              fbneo_names.project(native_name(name), members))
                    firmware = stage/'fbneo/verification/dl-1425.bin'
                    firmware.parent.mkdir(parents=True, exist_ok=True)
                    firmware.write_bytes(members['dl-1425.bin'])
                    continue
                if platform == 'darksoft':
                    from darksoft import tree, native_menu
                    stock_name, packed = stock_mame.repack(members, record['region'])
                    rom_sources.publish_tree(stage, tree(packed, stock_name,
                        folder='usf2_' + record['region'], menu=native_menu('usf2-backport', record['region'])))
                    # DSP firmware is not flashed; retain it only for portable
                    # reconstruction verification outside the card's games tree.
                    firmware = stage/'darksoft/verification/dl-1425.bin'
                    firmware.parent.mkdir(parents=True, exist_ok=True)
                    firmware.write_bytes(members['dl-1425.bin'])
                    continue
                if platform == 'mister':
                    dest = stage/'mister/games/mame'/(native_name(name)+'.zip')
                elif platform == 'mame' and kit.get('mame_layout') == 'stock-hsf2-v1':
                    stock_name, packed = stock_mame.repack(members, record['region'])
                    dest = stage/'mame'/(stock_name+'.zip')
                    write_zip(dest, packed)
                    continue
                else:
                    dest = stage/platform/(native_name(name)+'.zip' if platform == 'hbmame' else name+'.zip')
                dest.parent.mkdir(parents=True, exist_ok=True); shutil.copyfile(native, dest)
            print('PASS exact reconstruction', name, flush=True)
        if 'hbmame' in platforms:
            import hiscore
            hiscore.install(stage/'hbmame', [native_name(n) for n in selected if 'hbmame' in platforms_for(n,platforms)])
        if 'mame' in platforms and kit.get('mame_layout') == 'stock-hsf2-v1':
            stock_mame.write_instructions(stage/'mame/RUN-MAME.txt',
                [r['region'] for n,r in selected.items() if 'mame' in platforms_for(n,platforms)])
        shutil.rmtree(stage/'native')
        shutil.copyfile(HERE/'payload.py', stage/'payload.py')
        shutil.copyfile(HERE/'kit.json', stage/'source-kit.json')
        if 'mister' in platforms:
            import music
            region = 'us' if 'us' in regions else 'jp'
            cpk = work/'usf2_arrange.cpk'
            require(not cpk.exists(), 'Remove the previous generated CPK from --work before rebuilding')
            print('Building MiSTer arranged music; this can take several minutes...', flush=True)
            music.build(supplied[region], args.keys, kit['nsp'][region], cpk, work/'music', work/'source')
            write_zip(stage/'mister/games/CPS+/usf2_arrange.zip', {'usf2_arrange.cpk':cpk.read_bytes()})
            cpk.unlink(); Path(str(cpk)+'.json').unlink()
            shutil.copytree(HERE/'core', stage/'mister/_Arcade/cores')
        if 'mister' in platforms:
            from policy import check_mras
            for name in selected:
                if 'mister' not in platforms_for(name,platforms):continue
                check_mras(name,kit['profiles'][name]['mras'])
                for row in kit['profiles'][name]['mras']:
                    target = stage/'mister'/row['destination']; target.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copyfile(HERE/row['file'], target)
        from verify import verify_output
        print('[5/5] Verifying completed output...', flush=True)
        report = verify_output(stage, kit, selected, platforms)
        (stage/'verification.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
        for filename in ('verify.py','mra_assembly.py','verify_output.py','nsp.py','switch_source.py','policy.py','stock_mame.py','hiscore.py','cps2_code_guard.py','cps2_crypt.py','darksoft.py','darksoft_profiles.json','fbneo_names.py','fbneo_names.json'):
            shutil.copyfile(HERE/filename, stage/filename)
        shutil.copyfile(HERE/'README.txt', stage/'README.txt')
        (stage/'files.json').write_text(json.dumps({str(p.relative_to(stage)):file_sha(p) for p in
            sorted(stage.rglob('*')) if p.is_file() and '__pycache__' not in p.parts},indent=2,sort_keys=True)+'\n')
        require(not args.out_dir.exists() and not args.out_dir.is_symlink(), 'Output appeared during reconstruction')
        stage.rename(args.out_dir)
    print_completion(args, selected, platforms)


def argument_parser():
    p = argparse.ArgumentParser(description=__doc__)
    for r in ('us','jp'):
        p.add_argument('--source-'+r, '--nsp-'+r, '--xci-'+r, dest='nsp_'+r, type=Path,
                       help='owned regional base NSP or supported XCI; content hashes must match')
    p.add_argument('--keys', type=Path, help='your own prod.keys file')
    p.add_argument('--out-dir', type=Path, help='fresh output folder (default: unused output-usf2 folder)')
    p.add_argument('--work', type=Path, help='scratch folder (default: temporary folder, removed on exit)')
    p.add_argument('--rompath',type=Path,action='append',default=[])
    p.add_argument('--region',choices=('us','jp','all'),default=None,
                   help='default: infer from supplied USA/Japan game files')
    p.add_argument('--platform',choices=('mame','hbmame','fbneo','mister','darksoft','all'),default='all',
                   help='output target (default: all)')
    p.add_argument('--tools-cache',type=Path,help='verified helper cache directory')
    p.add_argument('--tools-bundle',type=Path,help='offline tools ZIP or directory; never downloads tools')
    p.add_argument('--offline',action='store_true',help='use cached helpers or --tools-bundle; no helper downloads')
    p.add_argument('--check',action='store_true',help='check arcade/NSP/XCI inputs without generating outputs or music')
    p.add_argument('--debug',action='store_true',help='show a Python traceback when setup fails')
    return p


def main(argv=None):
    args = argument_parser().parse_args(argv)
    try:
        build(args)
    except (ValueError, OSError, zipfile.BadZipFile) as exc:
        if args.debug:
            raise
        print('Error: ' + str(exc), file=sys.stderr)
        print('Run with --debug to show the full traceback.', file=sys.stderr)
        return 1
    return 0


if __name__ == '__main__':
    sys.exit(main())
