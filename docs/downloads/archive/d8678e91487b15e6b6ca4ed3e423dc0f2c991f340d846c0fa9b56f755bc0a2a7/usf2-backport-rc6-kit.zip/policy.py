"""One USF2 game configuration per region, with selectable Modern/Classic effects.

Source profile IDs are stable internal identities, not recipient editions.
"""

def platforms_for(name, requested):
    mra_variants(name)  # Validate the complete set identity.
    supported = ('mame','hbmame','fbneo','mister','darksoft')
    return tuple(p for p in requested if p in supported)

def mra_variants(name):
    if name not in ('usf2t8','usf2j8'):
        raise ValueError('Unknown USF2 profile: '+name)
    return (True,)


def check_mras(name,rows):
    if sorted(bool(r['arrange'])for r in rows)!=list(mra_variants(name)):
        raise ValueError('Unsupported or incomplete MiSTer launcher matrix: '+name)


HBMAME_NAMES = {'usf2t8': 'usf2u', 'usf2j8': 'usf2j'}


def native_name(profile):
    """Shared HBMAME/MiSTer identity; reconstruction profile IDs stay stable."""
    mra_variants(profile)
    return HBMAME_NAMES.get(profile, profile)


hbmame_name = native_name  # Compatibility for existing qualification callers.


def native_definition(profile, text):
    """Rename registrations only, preserving every ROM declaration byte."""
    import re
    name=hbmame_name(profile)
    if name==profile:return text
    for pattern in (r'(ROM_START\(\s*)', r'(GAME\(\s*[^,]+,\s*)'):
        text, count = re.subn(pattern + re.escape(profile) + r'(?=\s*[,\)])',
                              lambda m: m.group(1)+name, text)
        if count == 0:
            if len(re.findall(pattern + re.escape(name) + r'(?=\s*[,\)])', text)) != 1:
                raise ValueError('Missing or duplicate HBMAME registration: '+profile)
        elif count != 1:
            raise ValueError('Duplicate HBMAME registration: '+profile)
    return text


def export_hbmame_definitions(stage, manifest):
    """Export private companion definitions with the shared native names."""
    import hashlib
    for profile, record in manifest['profiles'].items():
        name = hbmame_name(profile)
        old = stage/'definitions'/(profile+'.cpp.inc')
        target = stage/'definitions'/(name+'.cpp.inc')
        if name == profile:
            continue
        source = old if old.exists() else target
        text = native_definition(profile,source.read_text())
        target.write_text(text)
        if old != target and old.exists():
            old.unlink()
        record['definition_sha256'] = hashlib.sha256(target.read_bytes()).hexdigest()


def export_native_names(stage, manifest):
    """Use the same identities in definitions, native ZIPs and MRA bindings."""
    export_hbmame_definitions(stage, manifest)
    export_mra_names(stage,manifest)


def export_mra_names(stage,manifest):
    """Bind launchers without putting emulator definitions into a public kit."""
    for profile, record in manifest['profiles'].items():
        name = native_name(profile)
        for row in record['mras']:
            source = stage/row['file']
            text = source.read_text()
            old, new = '/mame/'+profile+'.zip', '/mame/'+name+'.zip'
            if text.count(old) == 1:
                text = text.replace(old, new)
            elif text.count(new) != 1:
                raise ValueError('Unexpected MiSTer ZIP binding: '+profile)
            target = stage/'mras'/(name+'.mra')
            target.write_text(text)
            if source != target:
                source.unlink()
            row['file'] = target.relative_to(stage).as_posix()
