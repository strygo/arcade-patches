"""Prepare FFmpeg only when the recipient requests music generation."""
def prepare():
    import ffmpeg_runtime
    return ffmpeg_runtime.resolve('ffmpeg')
