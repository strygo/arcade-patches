#!/usr/bin/env python3
"""Launch verified USF2 with MAME's standard hiscore plugin in private storage."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

SETS = {'hsf2', 'hsf2j', 'usf2u', 'usf2j', 'usf2t4', 'usf2j4', 'usf2t8', 'usf2j8'}
# ROM reset initializes the same sentinel bytes. Delay reload until that
# initialization finishes, including resets that retain old work RAM.
RANGES = '@delay=5\n@:maincpu,program,ffd6a2,30,00,20\n@:maincpu,program,ffd71a,4,00,00\n'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def install(folder, names):
    """Call only after the producer authenticates complete USF2 archives."""
    folder = Path(folder)
    pins = {}
    for name in names:
        if name not in SETS:
            raise ValueError('Unsupported USF2 loader')
        pins[name] = digest(folder / (name + '.zip'))
    (folder / 'usf2-hiscore.json').write_bytes(
        (json.dumps(dict(schema=1, archives=pins), indent=2)+'\n').encode('utf-8'))
    target = folder / 'hiscore.py'
    if target.resolve() != Path(__file__).resolve():
        # Export identity is byte-exact on every host, including Windows.
        source = globals().get('__source__')
        target.write_bytes(source.encode('utf-8') if source else Path(__file__).read_bytes())


def prepare(folder, state, machine):
    folder, state = Path(folder).resolve(), Path(state).resolve()
    pins = json.loads((folder / 'usf2-hiscore.json').read_text())
    if pins.get('schema') != 1 or machine not in SETS or machine not in pins['archives']:
        raise ValueError('No verified USF2 archive for this loader')
    if digest(folder / (machine + '.zip')) != pins['archives'][machine]:
        raise ValueError('USF2 ROM archive changed; refusing incompatible score storage')
    # Each loader has a separate home. Stock HSF2 data is never consulted.
    home = state / 'usf2' / machine
    home.mkdir(parents=True, exist_ok=True)
    dat = machine + ':\n' + RANGES
    path = home / 'hiscore.dat'
    if path.exists() and path.read_text() != dat:
        raise ValueError('Conflicting private hiscore.dat')
    path.write_text(dat)
    return home, ['-noreadconfig', '-rompath', str(folder), '-homepath', str(home),
                  '-cfg_directory', str(home / 'cfg'), '-nvram_directory', str(home / 'nvram'),
                  '-plugin', 'hiscore']


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--mame', type=Path, required=True)
    p.add_argument('--set', choices=sorted(SETS), required=True)
    p.add_argument('--state', type=Path, help='score/configuration storage root (default: beside this script)')
    a = p.parse_args()
    folder = Path(__file__).resolve().parent
    home, args = prepare(folder, a.state or folder / 'saved-scores', a.set)
    raise SystemExit(subprocess.call([str(a.mame.resolve()), a.set, *args, '-window', '-nomaximize'], cwd=home))


if __name__ == '__main__':
    main()
