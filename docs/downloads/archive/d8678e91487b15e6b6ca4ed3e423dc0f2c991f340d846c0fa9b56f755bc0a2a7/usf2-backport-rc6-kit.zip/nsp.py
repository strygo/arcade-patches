"""Read content-pinned NSP/XCI sources with your keys and pinned NSTool."""
from pathlib import Path
import importlib.util
import subprocess
import sys
from payload import require, source_key

HERE = Path(__file__).resolve().parent
# Both the kit and standalone output verifiers bundle this standard-library
# helper beside nsp.py. The checkout imports the same canonical tracked file.
if not (HERE/'switch_source.py').is_file():
    sys.path.insert(0, str(HERE.parents[2]/'cpsplus/pack'))
from switch_source import (authenticate, copy_entry, entries, file_sha,
                           open_program, resource, select)


def toolset(work, tools_source=None):
    # One self-contained helper at the declared kit root. Maintainer callers
    # may supply another explicit exported helper directory, never a checkout fallback.
    path = (Path(tools_source) if tools_source else HERE) / 'fetch_switch_tools.py'
    require(path.is_file() and not path.is_symlink(), 'Missing bundled Switch helper: ' + str(path))
    loaded = sys.modules.get('fetch_switch_tools')
    if loaded is None or Path(loaded.__file__).resolve() != path.resolve():
        spec = importlib.util.spec_from_file_location('usf2_switch_helpers', path)
        loaded = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(loaded)
    return loaded.setup(Path(work) / 'switch-tools')


def unlock(path, keys, pin, work, tools_source=None):
    require(Path(keys).is_file(), 'Supply your own Switch prod.keys')
    # Reject unsupported containers/regions before preparing the toolchain.
    select(path, pin)
    work = Path(work); work.mkdir(parents=True, exist_ok=True)
    tools = toolset(work, tools_source)
    with open_program(path, pin, work) as (program, ticket, _):
        verified = resource(tools['nstool'], keys, program, ticket, pin, program.parent/'resource')
        return source_key(verified.read_bytes())
