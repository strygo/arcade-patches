"""NSP-bound XOR reconstruction deltas. No source bytes or keys are constants."""
import hashlib
import zlib

BUNDLE_FILE = 'payloads.uxb'
MAX_BUNDLE_BYTES = 64 * 1024 * 1024


def sha(data):
    return hashlib.sha256(data).hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def bundle_path(root, descriptor):
    require(descriptor.get('schema') == 1 and descriptor.get('file') == BUNDLE_FILE and
            type(descriptor.get('bytes')) is int and 0 < descriptor['bytes'] <= MAX_BUNDLE_BYTES,
            'Invalid masked payload bundle')
    path = root / BUNDLE_FILE
    require(not path.is_symlink() and path.is_file() and path.stat().st_size == descriptor['bytes'],
            'Masked payload bundle size or path differs')
    return path


def extent(record, limit):
    start, size = record.get('offset'), record.get('bytes')
    require(type(start) is int and type(size) is int and start >= 0 and
            0 < size <= 0x1000000 + 0x10000 and start + size <= limit and 'file' not in record,
            'Invalid masked payload bundle extent')
    return start, size


def validate_bundle(root, manifest):
    """Authenticate the complete container and all unique, tightly packed spans."""
    descriptor = manifest['payload_bundle']
    with bundle_path(root, descriptor).open('rb') as stream:
        data = stream.read(MAX_BUNDLE_BYTES + 1)
    require(len(data) == descriptor['bytes'] and sha(data) == descriptor['sha256'],
            'Masked payload bundle identity differs')
    slots, identities = {}, {}
    for profile in manifest['profiles'].values():
        for member in profile['members'].values():
            record = member.get('payload')
            if record is None:
                continue
            start, size = extent(record, len(data))
            require(sha(data[start:start + size]) == record['sha256'], 'Masked payload fragment differs')
            require(start not in slots or slots[start] == record, 'Conflicting payload bundle references')
            identity = record['sha256']
            require(identity not in identities or identities[identity] == start,
                    'Duplicate payload bundle identity')
            slots[start] = record
            identities[identity] = start
    end = 0
    for start, record in sorted(slots.items()):
        require(start == end, 'Masked payload bundle has a gap or overlap')
        end += record['bytes']
    require(end == len(data), 'Masked payload bundle has unreferenced bytes')
    return len(slots)


def read_payload(root, record, descriptor):
    path = bundle_path(root, descriptor)
    start, size = extent(record, descriptor['bytes'])
    with path.open('rb') as stream:
        stream.seek(start)
        data = stream.read(size)
    require(len(data) == size and sha(data) == record['sha256'], 'Masked payload fragment differs')
    return data


def source_key(resource):
    # This digest is private working state, never an identity in the manifest.
    # A published SHA-256 of the input is deliberately NOT the key material.
    require(len(resource) >= 32, 'Source resource is truncated')
    return hashlib.shake_256(b'USF2 source key v1\0' + resource).digest(32)


def xor(a, b):
    require(len(a) == len(b), 'XOR extents differ')
    return bytes(x ^ y for x, y in zip(a, b))


def mask(data, key, identity):
    require(len(key) == 32 and identity, 'Missing private source key or payload identity')
    stream = hashlib.shake_256(b'USF2 payload v1\0' + key + identity.encode()).digest(len(data))
    return xor(data, stream)


def baseline(source, size):
    require(0 <= len(source) <= size <= 0x1000000, 'Invalid reconstruction extent')
    return source + b'\xff' * (size - len(source))


def encode(target, source, key, region):
    delta = xor(target, baseline(source, len(target)))
    compressed = zlib.compress(delta, 9)
    identity = region + ':' + sha(compressed)
    wrapped = mask(compressed, key, identity)
    return wrapped, dict(identity=identity, bytes=len(wrapped), sha256=sha(wrapped),
                         decoded_sha256=sha(compressed), output_bytes=len(target),
                         output_sha256=sha(target), changed_bytes=sum(x != 0 for x in delta))


def decode(wrapped, record, source, key):
    require(len(wrapped) == record['bytes'] and sha(wrapped) == record['sha256'],
            'Masked payload identity differs')
    compressed = mask(wrapped, key, record['identity'])
    require(sha(compressed) == record['decoded_sha256'], 'NSP source does not unlock this payload')
    size = record['output_bytes']
    require(0 <= size <= 0x1000000, 'Unbounded payload output')
    reader = zlib.decompressobj()
    delta = reader.decompress(compressed, size + 1)
    require(len(delta) == size and reader.eof and not reader.unused_data and
            not reader.unconsumed_tail, 'Reconstruction delta extent differs')
    result = xor(delta, baseline(source, size))
    require(sha(result) == record['output_sha256'], 'Reconstructed member identity differs')
    return result


def post_patch(data, edits):
    """Apply explicit equal-size program edits after authenticated reconstruction."""
    result = bytearray(data)
    end = 0
    for edit in edits:
        at = edit['offset'];after = bytes.fromhex(edit['after_hex'])
        require(isinstance(at,int) and at >= end and after and at+len(after) <= len(data),
                'Invalid or overlapping program patch extent')
        require(sha(data[at:at+len(after)]) == edit['before_sha256'], 'Program patch preimage differs')
        result[at:at+len(after)] = after
        end = at+len(after)
    return bytes(result)
