"""Read a kit's TOML config the way the people who fill it in actually write it.

`discs.toml` (CPS+) and `titles.toml` (NG+) hold one thing: paths to the
discs and ROM sets the user owns.  They are pasted from Explorer or Finder,
by people who are not writing TOML, so this module repairs what a paste does
to a TOML string -- backslashes above all -- and reads the file whatever a
Windows editor saved it as, rather than making the user learn the quoting.

CPS+ is the master copy; NG+ vendors it (integration/sync_cpk.py).
"""
from __future__ import annotations

import locale
import re
import sys
import tomllib
from pathlib import Path


_ASSIGN = re.compile(r"^(\s*[A-Za-z0-9_-]+\s*=\s*)(\S.*?)\s*$")
_ALL_DOUBLED = re.compile(r"(?:[^\\]|\\\\)*")


def path_line(line: str) -> str:
    r"""One `key = value` line of a kit's config, made safe for tomllib.

    A path pasted from Windows is not valid TOML as it stands: inside "..."
    a backslash starts an escape, so C:\Users is an error, D:\roms\new
    silently turns into a carriage return and a newline, and a trailing
    backslash swallows the closing quote.  No disc path holds a TOML escape,
    so a quoted value with a backslash is taken literally -- unless every
    backslash in it is already doubled (C:\\Users, the proper TOML
    spelling), which is collapsed first.  Explorer's "Copy as path" quotes
    pasted inside the template's own, and a bare unquoted path, are accepted
    too.  Anything else is left for tomllib to judge."""
    m = _ASSIGN.match(line)
    if not m or line.lstrip().startswith("#"):
        return line
    head, rest = m.groups()
    if rest.startswith(("'", "[", "{", '"""')):
        return line
    if rest.startswith('"'):
        inner = rest.lstrip('"')
        end = inner.find('"')
        if end < 0:
            return line
        value, comment = inner[:end], inner[end:].lstrip('"').strip()
        if comment and not comment.startswith("#"):
            return line
        if "\\" not in value and len(rest) - len(inner) == 1:
            return line                  # ordinary TOML, nothing to repair
    else:
        cut = re.search(r"\s#", rest)
        value = (rest[:cut.start()] if cut else rest).strip()
        comment = rest[cut.start():].strip() if cut else ""
        if not re.search(r"[\\/:]", value):
            return line                  # not a path; let tomllib say so
    if _ALL_DOUBLED.fullmatch(value) and "\\\\" in value:
        value = value.replace("\\\\", "\\")
    fixed = head + '"' + value.replace("\\", "\\\\") + '"'
    return fixed + ("  " + comment if comment else "")


def read_text(path: Path) -> str:
    raw = path.read_bytes()
    if raw[:2] in (b"\xff\xfe", b"\xfe\xff"):
        return raw.decode("utf-16")      # Notepad's "Unicode"
    try:
        return raw.decode("utf-8-sig")   # a BOM is what Notepad adds
    except UnicodeDecodeError:
        enc = locale.getpreferredencoding(False)
        if enc.lower().replace("-", "") == "utf8":
            enc = "cp1252"               # Notepad's "ANSI" on a Western system
        print(f"{path.name}: not UTF-8, reading it as {enc}")
        return raw.decode(enc, errors="replace")


def unquote(v: str) -> str:
    v = v.strip()
    while len(v) >= 2 and v[0] == v[-1] and v[0] in "\"'":
        v = v[1:-1].strip()
    return v


def load(path: Path) -> dict:
    lines = read_text(path).splitlines()
    try:
        return tomllib.loads("\n".join(path_line(l) for l in lines) + "\n")
    except tomllib.TOMLDecodeError as e:
        n = getattr(e, "lineno", None)
        if n is None:
            m = re.search(r"line (\d+)", str(e))
            n = int(m.group(1)) if m else None
        where = f"{path}:{n}" if n else str(path)
        shown = f"\n    {lines[n - 1].strip()}" if n and 0 < n <= len(lines) else ""
        sys.exit(f"{where}: cannot read this line ({getattr(e, 'msg', e)}){shown}\n"
                 f"Each entry is one line:  key = \"path\"   -- a path copied "
                 f"from Explorer or Finder can be pasted between the quotes "
                 f"as it is.  Lines starting with # are ignored.")
