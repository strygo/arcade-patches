#!/usr/bin/env python3
"""CPS+ pack generator — builds the audio packs from YOUR disc images.

This kit ships no game audio.  Every pack is generated on your machine from
CD/DVD rips you own, and verified byte-for-byte against the published pack
hashes, so what you hear is exactly what was authored and tested.

Quick start:
  1. Edit discs.toml (next to this script) and fill in paths for the discs
     you own, or pass them with --disc KEY=PATH.  Every entry is optional:
     a pack whose disc you do not have is skipped, by name.
  2. Run:   python3 make_packs.py
  3. Copy the contents of out/mister/ to your MiSTer SD card root.

out/mister/ is built for you, laid out like the card: the three cores, the
packs you built, and only the MRAs those packs can actually load.

Requirements: Python 3.11+, numpy, ffmpeg on PATH (ADX packs), and a 7-Zip
binary (7zz/7z/7za, or 7-Zip installed on Windows) only if your rips are .7z
archives.  The three X68000 MIDI
packs additionally need git, cmake and a C/C++ compiler (they build two
pinned open-source tools once) and your SC-55 ROM set -- see X68000.md.
The Strider (PSX Soundtrack) pack needs MAME and your PlayStation BIOS set:
it records the game's own sound test -- see PSX.md.

Disk: a full run needs roughly 15 GB free.  About 1.8 GB of that is the packs
themselves; the rest is work/ -- extracted discs, decode cache and
intermediates -- which a successful build deletes for you.  Pass --cache to
keep it instead, which makes a re-run much faster.

Verification happens twice.  Before the album and CD-audio packs (Final
Fight OST, UN Squadron SNES, Mega Twins, Forgotten Worlds, Muscle Bomber)
are encoded, every input track of your rip is checked against the verified
rip -- one row per track: frames, CRC32, MATCH / ALIGNED / DIFFERENT /
MISSING, and what a difference points at (read offset, gap handling, a
different release, a lossy copy).  A pack with a differing input is not
built.  Then every finished pack is checked against its published sha256;
for the packs above a mismatch names the first stage that differed (input,
loop/fade processing, ffmpeg's ADX encoder), recorded per track in
work/packs/<pack>.audit.json.

Options:
  --list          show every pack, its required disc entries, and status
  --only NAME     build just one pack group (repeatable)
  --check-inputs  only check your rips against the verified input tracks
                  (the per-track table above) and exit; builds nothing
  --no-verify     skip both checks: build packs even from differing inputs
                  and stage them even if their hash differs (not
                  recommended -- the result is not the tested pack)
  --disc KEY=PATH point at one disc without editing discs.toml, e.g.
                  --disc mtwins_pce_disc=/discs/chiki.7z (repeatable)
  --cache         keep work/ after a successful build, so a re-run can reuse
                  the extracted discs and decode cache
  --clean-only    delete work/ and exit, without building anything
  --jobs N        X68000 packs: render N songs at once (default: half your
                  cores); the SC-55 render is the slow part of those builds
"""
from __future__ import annotations

import sys

if sys.version_info < (3, 11):
    sys.exit(f"make_packs.py needs Python 3.11 or newer (it reads discs.toml "
             f"with tomllib); this is Python {sys.version.split()[0]}.\n"
             f"Install a current Python from python.org and run it with that, "
             f"e.g.  py -3.12 make_packs.py  on Windows.")

import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
import zipfile
from pathlib import Path

from pack import tomlpaths      # the config reader both kits share

# A console or log in a legacy code page must not turn a progress line into
# a UnicodeEncodeError halfway through an hour-long build.
for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(errors="replace")
    except (AttributeError, ValueError):
        pass

# abspath, not resolve(): on Windows resolve() turns a mapped drive into
# \\server\share
HERE = Path(os.path.abspath(__file__)).parent   # kit/builder/
KIT = HERE.parent                               # kit root
OUT = KIT / "out" / "mister"                    # laid out like the SD card
GAMES = OUT / "games" / "CPS+"
PACKS_DIR = HERE / "work" / "packs"             # build_pack.py output
MANIFESTS = HERE / "manifests"
MRA_SRC = HERE / "mras"                         # master set, never modified
CORE_SRC = HERE / "cores"
MRA_OUT = OUT / "_Arcade" / "_Arcade Patches" / "_Arrangements" / "_CPS+"
CORE_OUT = OUT / "_Arcade" / "cores"
HASHES = json.loads((HERE / "pack_hashes.json").read_text(encoding="utf-8"))

# Pack groups: one build command each, in the same order as pack/README.md.
# (group, required disc keys, build argv (relative to builder/), produced cpks)
# argv None = special-cased in build_group(); an X68K(...) marker means the
# FLAC set is rendered first by make_x68k_flac.py, then built like any other.
def X68K(slug: str, mode: str) -> dict:
    return {"x68k": slug, "mode": mode}


def PSX(pack: str) -> dict:
    return {"psx": pack}


# An album download may be handed over as the archive itself; it is unpacked
# once into work/albums/ and the folder is what the builder sees.
ARCHIVE_KEYS = {"double_impact_album", "hd_remix_album"}
OPTIONAL_KEYS = {"mame_bin"}          # a tool, not a source; no group needs it

# Groups whose builder checks every input track against pinned hashes first
# (build_pack.py <mode> --check-inputs / --allow-input-mismatch), and the
# pins each one reads.
INPUT_PINS = {
    "ffight-ost": MANIFESTS / "ffight_ost_inputs.json",
    "unsquad-snes": MANIFESTS / "unsquad_snes_inputs.json",
    "mtwins": MANIFESTS / "mtwins_arrange_inputs.json",
    "forgottn": MANIFESTS / "forgottn_arrange_inputs.json",
    "mbomber": MANIFESTS / "mbomber_arrange_inputs.json",
}
# Child Pythons report in UTF-8 whatever the console's code page.
CHILD_ENV = os.environ | {"PYTHONIOENCODING": "utf-8:replace"}


GROUPS = [
    ("ffight",     ["ffight_us_disc", "ffight_jp_disc"], None,  # special-cased
     ["ffight_arrange", "ffight_arrange_jp"]),
    ("ffightae-cps2", ["ffight_us_disc"],
     ["ffightae-cps2", "--us-disc", "{ffight_us_disc}"],
     ["ffightae_cps2_arrange"]),
    ("ffight-ost", ["ffight_ost_dir"],
     ["ffight-ost", "--ost", "{ffight_ost_dir}"],
     ["ffight_snes", "ffight_x68k_fm", "ffight_x68k_midi"]),
    ("hsf2",       ["hsf2_ae_iso"],
     ["hsf2", "--iso", "{hsf2_ae_iso}"],
     ["hsf2_arrange"]),
    ("hsf2-cps1",  ["hsf2_ae_iso"],
     ["hsf2", "--iso", "{hsf2_ae_iso}", "--bank", "cps1"],
     ["hsf2_cps1"]),
    ("sf2",        ["hsf2_ae_iso"],
     ["sf2-arrange", "--iso", "{hsf2_ae_iso}"],
     ["sf2_arrange"]),
    ("ssf2",       ["hsf2_ae_iso"],
     ["ssf2-arrange", "--game", "ssf2", "--iso", "{hsf2_ae_iso}"],
     ["ssf2_arrange"]),
    ("ssf2t",      ["hsf2_ae_iso"],
     ["ssf2-arrange", "--game", "ssf2t", "--iso", "{hsf2_ae_iso}"],
     ["ssf2t_arrange"]),
    ("sfa1",       ["sfa1_saturn_disc"],
     ["sfa1-arrange", "--disc", "{sfa1_saturn_disc}"],
     ["sfa1_arrange"]),
    ("sfa2-snes",  ["anthology_iso"],
     # this builder writes next to its module unless told otherwise
     ["sfa2-snes", "--iso", "{anthology_iso}",
      "--out", "work/packs/sfa2_snes.cpk"],
     ["sfa2_snes"]),
    ("sfa2",       ["sfz2_saturn"],
     ["sfa2-arrange", "--game", "sfa2", "--iso", "{sfz2_saturn}"],
     ["sfa2_arrange"]),
    ("sfz2al",     ["sfz2dash_saturn"],
     ["sfa2-arrange", "--iso", "{sfz2dash_saturn}"],
     ["sfz2al_arrange"]),
    ("spf2t",      ["spf2t_saturn"],
     ["spf2t", "--disc", "{spf2t_saturn}"],
     ["spf2t_arrange"]),
    ("mtwins",     ["mtwins_pce_disc"],
     ["mtwins", "--disc", "{mtwins_pce_disc}"],
     ["mtwins_arrange"]),
    ("forgottn",   ["forgottn_pce_disc"],
     ["forgottn", "--disc", "{forgottn_pce_disc}"],
     ["forgottn_arrange"]),
    ("mbomber",    ["mbomber_fmt_disc"],
     ["mbomber", "--disc", "{mbomber_fmt_disc}"],
     ["mbomber_arrange"]),
    ("unsquad-snes", ["unsquad_ost_dir"],
     ["unsquad-snes", "--ost", "{unsquad_ost_dir}"],
     ["unsquad_snes"]),
    ("ffight-di",   ["double_impact_album"],
     ["remix", "--pack", "ffight_di", "--source-root", "{double_impact_album}"],
     ["ffight_di"]),
    ("msword-di",   ["double_impact_album"],
     ["remix", "--pack", "msword_di", "--source-root", "{double_impact_album}"],
     ["msword_di"]),
    ("ssf2t-hdremix", ["hd_remix_album"],
     ["remix", "--pack", "ssf2t_hdremix", "--source-root", "{hd_remix_album}"],
     ["ssf2t_hdremix"]),
    ("strider-psx", ["strider_psx_disc", "psx_bios_dir"],
     PSX("strider_psx"), ["strider_psx"]),
    ("ghouls-x68k-midi", ["x68k_daimakaimura_disk", "sc55_rom_dir"],
     X68K("daimakaimura", "ghouls-x68k-midi"), ["ghouls_x68k_midi"]),
    ("sf2ce-x68k-midi",  ["x68k_sf2ce_disk", "sc55_rom_dir"],
     X68K("sf2ce", "sf2ce-x68k-midi"), ["sf2ce_x68k_midi"]),
    ("ssf2-x68k-midi",   ["x68k_ssf2_disk", "sc55_rom_dir"],
     X68K("ssf2", "ssf2-x68k-midi"), ["ssf2_x68k_midi"]),
]


def assemble_out() -> None:
    """Build out/mister/ into the shape of a MiSTer SD card.

    The cores always go out. An MRA only goes out once the one pack it names
    is in games/CPS+/, because MiSTer lists every MRA it finds and one whose
    pack is missing is a menu entry that fails on load. builder/mras/ stays
    untouched, so this is a copy rather than a shuffle, and re-running after
    building more packs simply emits more.
    """
    ref = re.compile(r'zip="/CPS\+/([A-Za-z0-9_]+)\.zip"')

    CORE_OUT.mkdir(parents=True, exist_ok=True)
    for f in sorted(CORE_SRC.iterdir()) if CORE_SRC.is_dir() else []:
        if f.is_file():
            shutil.copy2(f, CORE_OUT / f.name)

    GAMES.mkdir(parents=True, exist_ok=True)
    readme = HERE / "games_readme.txt"
    if readme.exists():
        shutil.copy2(readme, GAMES / "README.txt")

    emitted = held = 0
    for mra in sorted(MRA_SRC.rglob("*.mra")) if MRA_SRC.is_dir() else []:
        m = ref.search(mra.read_text(encoding="utf-8", errors="replace"))
        dst = MRA_OUT / mra.relative_to(MRA_SRC)
        if m and (GAMES / f"{m.group(1)}.zip").exists():
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(mra, dst)
            emitted += 1
        else:
            dst.unlink(missing_ok=True)          # a pack removed since last run
            held += 1
    for d in sorted(MRA_OUT.rglob("*"), reverse=True) if MRA_OUT.is_dir() else []:
        if d.is_dir() and not any(d.iterdir()):
            d.rmdir()

    print(f"\nout/mister/ holds {emitted} MRA(s) and the three cores.")
    if held:
        print(f"{held} MRA(s) are not in it, because the pack each one needs has "
              f"not been built.\nThey are still in builder/mras/, and appear here "
              f"once their pack exists.")


def load_discs() -> dict:
    path = HERE / "discs.toml"
    if not path.exists():
        sys.exit("discs.toml not found — copy/edit the template next to this script")
    raw = tomlpaths.load(path)
    out, bad = {}, []
    for k, v in raw.items():
        if not isinstance(v, str) or not tomlpaths.unquote(v):
            continue
        p = Path(tomlpaths.unquote(v)).expanduser()
        if not p.is_absolute():
            p = (HERE / p).resolve()
        if not p.exists():
            bad.append((k, p))
            continue
        out[k] = p
    for k, p in bad:
        print(f"discs.toml: {k} points at {p}\n"
              f"            which does not exist, so it is being ignored")
    return out


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for blk in iter(lambda: fh.read(1 << 20), b""):
            h.update(blk)
    return h.hexdigest()


def stage_zip(cpk: Path, dest: Path) -> None:
    """STORED (-X -0) zip holding exactly the .cpk — the on-SD pack format."""
    dest.parent.mkdir(parents=True, exist_ok=True)
    tmp = dest.with_suffix(".zip.tmp")
    tmp.unlink(missing_ok=True)
    if shutil.which("zip"):
        r = subprocess.run(["zip", "-q", "-X", "-0", str(tmp.resolve()), cpk.name],
                           cwd=cpk.parent, capture_output=True)
        if r.returncode:
            sys.exit(f"zip failed for {cpk.name}: {r.stderr.decode(errors='replace')}")
    else:
        with zipfile.ZipFile(tmp, "w", zipfile.ZIP_STORED) as z:
            z.write(cpk, cpk.name)
    tmp.replace(dest)


def render_x68k(slug: str, archive: Path, rom_dir: Path, jobs: int) -> Path | None:
    """Run make_x68k_flac.py for one game; returns the FLAC dir, or None."""
    cmd = [sys.executable, str(HERE / "make_x68k_flac.py"), "--game", slug,
           "--archive", str(archive), "--sc55-rom-dir", str(rom_dir),
           "--work", str(HERE / "work" / "x68000"), "--jobs", str(jobs)]
    print(f"\n=== {slug}: python3 make_x68k_flac.py --game {slug} ...", flush=True)
    # Stream the driver's progress (a render can run for an hour) while
    # remembering its last line, which names the finished FLAC directory.
    proc = subprocess.Popen(cmd, cwd=HERE, stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT, text=True,
                            encoding="utf-8", errors="replace", env=CHILD_ENV)
    last = ""
    assert proc.stdout is not None
    for line in proc.stdout:
        sys.stdout.write(line)
        sys.stdout.flush()
        if line.strip():
            last = line.strip()
    if proc.wait():
        return None
    flac_dir = Path(last) if last else None
    return flac_dir if flac_dir and flac_dir.is_dir() else None


def find_7z() -> str | None:
    """A 7-Zip command-line binary: PATH first, then a Windows install."""
    for exe in ("7zz", "7z", "7za", "7zr"):
        hit = shutil.which(exe)
        if hit:
            return hit
    if os.name == "nt":
        roots = [os.environ.get(v) for v in ("ProgramW6432", "ProgramFiles", "ProgramFiles(x86)")]
        for root in filter(None, roots):
            cand = Path(root) / "7-Zip" / "7z.exe"
            if cand.is_file():
                return str(cand)
        try:
            import winreg
            for view in (winreg.KEY_WOW64_64KEY, winreg.KEY_WOW64_32KEY):
                try:
                    with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\7-Zip",
                                        0, winreg.KEY_READ | view) as k:
                        for name in ("Path64", "Path"):
                            try:
                                cand = Path(winreg.QueryValueEx(k, name)[0]) / "7z.exe"
                            except OSError:
                                continue
                            if cand.is_file():
                                return str(cand)
                except OSError:
                    continue
        except ImportError:
            pass
    return None


def find_mame(configured: Path | None) -> str | None:
    """mame_bin (a file or the folder holding it), PATH, then C:\\MAME."""
    names = ("mame", "mame.exe", "mame64", "mame64.exe")
    if configured:
        if configured.is_dir():
            hit = next((configured / n for n in names if (configured / n).is_file()), None)
            return str(hit) if hit else None
        return str(configured)
    for n in names:
        if shutil.which(n):
            return shutil.which(n)
    if os.name == "nt":
        for n in names[1::2]:
            if (Path("C:/MAME") / n).is_file():
                return str(Path("C:/MAME") / n)
    return None


def album_dir(path: Path) -> Path:
    """An album handed over as .zip/.7z is unpacked once into work/albums/.

    The unpacked copy remembers which archive it came from (path, size,
    modification time) and is reused only for that archive; it is unpacked
    into a .partial folder and renamed into place when complete, so an
    interrupted unpack is never mistaken for a finished one."""
    if path.is_dir():
        return path
    dest = HERE / "work" / "albums" / path.stem
    st = path.stat()
    stamp = {"path": str(path.resolve()), "size": st.st_size, "mtime_ns": st.st_mtime_ns}
    marker = dest / ".cpsplus_source.json"
    try:
        if json.loads(marker.read_text(encoding="utf-8")) == stamp:
            return dest
    except (OSError, ValueError):
        pass
    if path.suffix.lower() not in (".zip", ".7z"):
        sys.exit(f"{path}: pass the album as a folder, .zip or .7z")
    tmp = dest.with_name(dest.name + ".partial")
    shutil.rmtree(tmp, ignore_errors=True)
    tmp.mkdir(parents=True)
    if path.suffix.lower() == ".zip":
        with zipfile.ZipFile(path) as z:
            z.extractall(tmp)
    else:
        exe = find_7z()
        if not exe:
            sys.exit(f"{path.name}: need a 7-Zip binary to unpack it (brew "
                     f"install sevenzip, or 7-Zip from 7-zip.org on Windows), "
                     f"or unpack it yourself and point at the folder")
        r = subprocess.run([exe, "x", "-y", f"-o{tmp}", str(path)],
                           capture_output=True)
        if r.returncode:
            sys.exit(f"{path.name}: 7-Zip could not unpack it: "
                     f"{(r.stderr or r.stdout).decode(errors='replace').strip()[:400]}")
    marker = tmp / ".cpsplus_source.json"
    marker.write_text(json.dumps(stamp), encoding="utf-8")
    shutil.rmtree(dest, ignore_errors=True)
    tmp.rename(dest)
    return dest


def capture_psx(disc: Path, bios_dir: Path, mame: Path | None) -> Path | None:
    """Record the Strider sound test with MAME; returns the WAV, or None."""
    out = HERE / "work" / "strider_psx" / "audio.wav"
    cmd = [sys.executable, str(HERE / "tools" / "capture_strider_psx.py"),
           "--disc", str(disc), "--bios-dir", str(bios_dir), "--out", str(out)]
    if mame:
        cmd += ["--mame", str(mame)]
    print(f"\n=== strider-psx: python3 tools/capture_strider_psx.py ... "
          f"(about five minutes)", flush=True)
    r = subprocess.run(cmd, cwd=HERE, env=CHILD_ENV)
    return out if r.returncode == 0 and out.exists() else None


def read_audit(pack: str) -> dict:
    try:
        return json.loads((PACKS_DIR / f"{pack}.audit.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def check_group_inputs(name, keys, argv, discs) -> str:
    """Run one pinned group's builder in --check-inputs mode."""
    absent = [k for k in keys if k not in discs]
    if absent:
        return "skipped: needs " + ", ".join(absent)
    subs = {k: str(v) for k, v in discs.items()}
    args = [a.format(**subs) for a in argv] + ["--check-inputs"]
    print(f"\n=== {name}: python3 build_pack.py {' '.join(args)}", flush=True)
    r = subprocess.run([sys.executable, str(HERE / "build_pack.py")] + args,
                       cwd=HERE, env=CHILD_ENV)
    return {0: "ok: every input track matches the verified rip",
            3: "INPUTS DIFFER: see the table above"}.get(
        r.returncode, "FAILED (error above)")


def build_group(name, keys, argv, cpks, discs, verify, jobs=1) -> str:
    if isinstance(argv, dict) and "psx" in argv:
        absent = [k for k in keys if k not in discs]
        if absent:
            return "skipped: needs " + ", ".join(absent)
        wav = capture_psx(discs["strider_psx_disc"], discs["psx_bios_dir"],
                          discs.get("mame_bin"))
        if wav is None:
            return "FAILED (sound-test recording error above)"
        args = ["strider-psx", "--capture", str(wav)]
        produced = cpks
    elif isinstance(argv, dict):
        absent = [k for k in keys if k not in discs]
        if absent:
            return "skipped: needs " + ", ".join(absent)
        disk_key = next(k for k in keys if k.startswith("x68k_"))
        flac_dir = render_x68k(argv["x68k"], discs[disk_key],
                               discs["sc55_rom_dir"], jobs)
        if flac_dir is None:
            return "FAILED (X68000 render error above)"
        args = [argv["mode"], "--flac-dir", str(flac_dir)]
        produced = cpks
    elif name == "ffight":
        # region adapts to which discs you have
        have = [k for k in keys if k in discs]
        if not have:
            return "skipped: needs " + " or ".join(keys)
        if len(have) == 2:
            args = ["ffight", "--variant", "adx", "--region", "both",
                    "--us-disc", str(discs["ffight_us_disc"]),
                    "--jp-disc", str(discs["ffight_jp_disc"])]
            produced = cpks
        elif "ffight_us_disc" in discs:
            args = ["ffight", "--variant", "adx", "--region", "us",
                    "--us-disc", str(discs["ffight_us_disc"])]
            produced = ["ffight_arrange"]
        else:
            args = ["ffight", "--variant", "adx", "--region", "jp",
                    "--jp-disc", str(discs["ffight_jp_disc"])]
            produced = ["ffight_arrange_jp"]
    else:
        absent = [k for k in keys if k not in discs]
        if absent:
            return "skipped: needs " + ", ".join(absent)
        subs = {k: str(v) for k, v in discs.items()}
        for k in keys:
            if k in ARCHIVE_KEYS:
                subs[k] = str(album_dir(discs[k]))
        args = [a.format(**subs) for a in argv]
        produced = cpks
    pinned = name in INPUT_PINS
    if pinned and not verify:
        args.append("--allow-input-mismatch")

    print(f"\n=== {name}: python3 build_pack.py {' '.join(args)}", flush=True)
    PACKS_DIR.mkdir(parents=True, exist_ok=True)
    # a pack left over from an earlier run must never be staged as this one
    for pack in produced:
        (PACKS_DIR / f"{pack}.cpk").unlink(missing_ok=True)
        (PACKS_DIR / f"{pack}.audit.json").unlink(missing_ok=True)
    r = subprocess.run([sys.executable, str(HERE / "build_pack.py")] + args,
                       cwd=HERE, env=CHILD_ENV)
    # 3 = the builder refused a pack whose inputs differ (said so above)
    if r.returncode and not (pinned and r.returncode == 3):
        return "FAILED (build error above)"

    # sf2/sf2ce/sf2hf share one pack: all six MRAs name sf2_arrange, so
    # building a separate clone per MRA would put 217 MB of byte-identical
    # duplicate audio on the card.

    results = []
    for pack in produced:
        cpk = PACKS_DIR / f"{pack}.cpk"
        audit = read_audit(pack)
        if not cpk.exists():
            if audit.get("status") == "refused":
                results.append(f"{pack}: INPUT MISMATCH -- not built; the input "
                               f"table above shows which tracks differ and why")
            else:
                results.append(f"{pack}: FAILED (no output)")
            continue
        digest = sha256(cpk)
        # a list when more than one verified build exists (Strider PSX: MAME's
        # macOS and Windows builds record it a few samples apart)
        want = HASHES.get(pack)
        wants = [want] if isinstance(want, str) else (want or [])
        if verify and wants and digest not in wants:
            stage = audit.get("first_difference")
            if audit.get("diagnosis") and stage:
                print(f"\n{pack}: HASH MISMATCH -- {audit['diagnosis']}\n"
                      f"  (per-track record: work/packs/{pack}.audit.json)")
                why = f"first difference: {stage.replace('_', '-')}, see above"
            elif audit:
                why = ("its tracks match the verified build, but the published "
                       "hash differs -- is pack_hashes.json from this kit?")
            else:
                why = ("the rip differs from the verified one, or a tool on "
                       "this machine (ffmpeg, numpy) produced different bytes")
            results.append(
                f"{pack}: HASH MISMATCH (built {digest[:12]}, published "
                f"{' or '.join(w[:12] for w in wants)}) — {why}; pack NOT staged (rerun with "
                f"--no-verify to stage anyway)")
            continue
        stage_zip(cpk, GAMES / f"{pack}.zip")
        tag = "ok, verified" if (verify and wants) else "ok (unverified)"
        results.append(f"{pack}: {tag} -> games/CPS+/{pack}.zip")
    return "; ".join(results)


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--list", action="store_true")
    ap.add_argument("--only", action="append", default=[])
    ap.add_argument("--no-verify", action="store_true")
    ap.add_argument("--check-inputs", action="store_true",
                    help="only check your album and CD rips against the "
                         "verified input tracks, one row per track, and exit")
    ap.add_argument("--disc", action="append", default=[], metavar="KEY=PATH",
                    help="supply one disc on the command line instead of "
                         "editing discs.toml, e.g. --disc "
                         "mtwins_pce_disc=/discs/chiki.7z (repeatable; wins "
                         "over discs.toml)")
    ap.add_argument("--cache", action="store_true",
                    help="keep work/ after a successful build; the extraction "
                         "and decode cache makes a re-run much faster")
    # A successful build has removed work/ by default since the flag below was
    # the way to ask for it; accept it so older instructions still work.
    ap.add_argument("--clean", action="store_true", help=argparse.SUPPRESS)
    ap.add_argument("--clean-only", action="store_true",
                    help="delete work/ and exit -- reclaim the disk without "
                         "rebuilding anything; your packs are not touched")
    ap.add_argument("--jobs", type=int, default=max(1, (os.cpu_count() or 2) // 2),
                    help="X68000 packs: songs to render at once (default: "
                         "half your cores)")
    args = ap.parse_args()

    # Before load_discs(): reclaiming disk must not need a filled-in discs.toml.
    if args.clean_only:
        work = HERE / "work"
        if not work.is_dir():
            print("nothing to clean -- work/ does not exist")
            return 0
        mb = sum(f.stat().st_size for f in work.rglob("*") if f.is_file()) / 1e6
        try:
            shutil.rmtree(work)
        except OSError as e:
            sys.exit(f"could not remove all of work/: {e}\nA file in it is "
                     f"probably open in another program; close it and retry.")
        print(f"removed work/ ({mb/1000:.1f} GB); the packs in "
              f"{GAMES} are untouched.")
        return 0

    discs = load_discs()
    known = {k for _, keys, _, _ in GROUPS for k in keys} | OPTIONAL_KEYS
    for item in args.disc:
        key, _, val = item.partition("=")
        key, val = key.strip(), tomlpaths.unquote(val)
        if not val:
            sys.exit(f"--disc wants KEY=PATH, got {item!r}")
        if key not in known:
            sys.exit(f"--disc: no such disc {key!r}.\nKnown discs: "
                     + ", ".join(sorted(known)))
        path = Path(tomlpaths.unquote(val)).expanduser()
        if not path.is_absolute():
            path = (Path.cwd() / path).resolve()
        if not path.exists():
            sys.exit(f"--disc {key}: {path} does not exist")
        discs[key] = path
    if args.list:
        for name, keys, _, cpks in GROUPS:
            have = all(k in discs for k in keys) or (
                name == "ffight" and any(k in discs for k in keys))
            print(f"{name:16} needs: {', '.join(keys)}  "
                  f"[{'ready' if have else 'missing'}]  -> {', '.join(cpks)}")
        return 0

    if args.check_inputs:
        summary = []
        for name, keys, argv, _ in GROUPS:
            if (args.only and name not in args.only) or name not in INPUT_PINS:
                continue
            summary.append((name, check_group_inputs(name, keys, argv, discs)))
        print("\n================ input check ================")
        for name, outcome in summary:
            print(f"{name:14} {outcome}")
        others = [n for n, *_ in GROUPS if n not in INPUT_PINS
                  and (not args.only or n in args.only)]
        if others:
            print(f"\nNot input-checked (their build verifies the finished "
                  f"pack only): {', '.join(others)}")
        if (HERE / "work").is_dir():
            print("\nwork/ holds the extracted discs for the build; run "
                  "--clean-only to remove it.")
        return 1 if any(not o.startswith(("ok", "skipped")) for _, o in summary) else 0

    # Preflight, before any disc is touched: both of these surface deep inside
    # a build otherwise, as a raw traceback, after the packs that do not need
    # them have already spent an hour encoding.
    if shutil.which("ffmpeg") is None:
        print("WARNING: ffmpeg not on PATH — ADX packs will fail to build.")
    try:
        import numpy  # noqa: F401
    except ImportError:
        print("WARNING: numpy not installed — packs whose audio is ADX-encoded "
              "here (rather than copied from the disc) will fail to build.\n"
              "         install it with:  python3 -m pip install numpy")
    if any(k.startswith("x68k_") for k in discs):
        for tool in ("git", "cmake"):
            if shutil.which(tool) is None:
                print(f"WARNING: {tool} not on PATH — the X68000 MIDI packs "
                      f"build two pinned open-source tools and will fail "
                      f"without it (see X68000.md).")
        if "sc55_rom_dir" not in discs:
            print("WARNING: X68000 disk images are listed but sc55_rom_dir is "
                  "not — the X68000 MIDI packs also need your SC-55 ROM set.")
    if "strider_psx_disc" in discs:
        if "psx_bios_dir" not in discs:
            print("WARNING: strider_psx_disc is listed but psx_bios_dir is not — "
                  "recording the sound test also needs your PlayStation BIOS "
                  "set (psu.zip and psx_cd.zip, MAME naming; see PSX.md).")
        if not find_mame(discs.get("mame_bin")):
            print("WARNING: MAME not found — the Strider (PSX Soundtrack) pack "
                  "records the game's sound test with it (see PSX.md). Install "
                  "MAME, or set mame_bin in discs.toml to mame.exe or the "
                  "folder holding it.")

    summary = []
    for name, keys, argv, cpks in GROUPS:
        if args.only and name not in args.only:
            continue
        outcome = build_group(name, keys, argv, cpks, discs,
                              verify=not args.no_verify, jobs=args.jobs)
        summary.append((name, outcome))

    print("\n================ summary ================")
    built = skipped = failed = 0
    for name, outcome in summary:
        print(f"{name:12} {outcome}")
        if outcome.startswith("skipped"):
            skipped += 1
        elif "FAILED" in outcome or "MISMATCH" in outcome:
            failed += 1
        else:
            built += 1
    print(f"\n{built} group(s) built, {skipped} skipped, {failed} failed")
    if skipped:
        print("Skipped groups are waiting on a discs.toml entry, named above. "
              "Fill it in and re-run to add those packs.")
    assemble_out()
    print(f"\nCopy the contents of {OUT} to your MiSTer SD card root.")

    # The finished packs live in games/CPS+/; work/ is only extraction cache and
    # intermediates, and it dwarfs them -- so a build that got everything clears
    # it.  Never remove it when anything failed: that is exactly when the cache
    # saves the re-run.
    work = HERE / "work"
    if work.is_dir():
        mb = sum(f.stat().st_size for f in work.rglob("*") if f.is_file()) / 1e6
        if failed:
            print(f"\nwork/ kept ({mb/1000:.1f} GB) because {failed} group(s) "
                  f"failed -- the cache makes the re-run much faster. Delete it, "
                  f"or run --clean-only, once you are done.")
        elif not built:
            print(f"\nwork/ kept ({mb/1000:.1f} GB): this run built nothing, so "
                  f"there is nothing to tidy up after. Run --clean-only to "
                  f"reclaim it.")
        elif args.only:
            print(f"\nwork/ kept ({mb/1000:.1f} GB): --only builds part of the "
                  f"set, and the cache belongs to the rest of it. Run "
                  f"--clean-only when you are done.")
        elif args.cache:
            print(f"\n--cache: work/ kept ({mb/1000:.1f} GB of extraction cache "
                  f"and intermediates). Run --clean-only to reclaim it.")
        else:
            try:
                shutil.rmtree(work)
                print(f"\nremoved work/ ({mb/1000:.1f} GB of cache and "
                      f"intermediates); your packs are untouched. Pass --cache "
                      f"to keep it and speed up a re-run.")
            except OSError as e:
                print(f"\ncould not remove all of work/ ({e}); a file in it is "
                      f"probably open in another program. Your packs are "
                      f"fine; delete work/ by hand, or run --clean-only later.")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
