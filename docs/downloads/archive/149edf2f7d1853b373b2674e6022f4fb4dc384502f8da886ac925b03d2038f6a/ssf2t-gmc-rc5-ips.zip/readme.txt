Super Street Fighter II Turbo: Grand Master Challenge · English restoration
===========================================================================

Version:  rc5 (2026-11-14)
Target:   MAME set 'ssf2xj' (Super Street Fighter II X: Grand Master Challenge (Japan 940311))
Hardware: Capcom CPS-2
Patch by: Steve Gordon (https://x.com/strygo)
Website:  https://arcadepatches.com/ssf2t-gmc/

ABOUT THIS PROJECT

Super Turbo came in two versions. Japan got Super Street Fighter II X, the one
competitive players swear by. The rest of the world got a slightly different
game: it plays differently, the continue screen is bare, most of the win
quotes are gone, the endings are shorter, and Akuma's story is missing.
Japan's version, of course, was in Japanese.

Grand Master Challenge is Japan's game in English. The fighting is untouched.
Everything you read is new: all 136 win quotes, the strategy tips on the
continue screen, the full endings, and Akuma's dialogue, translated fresh from
the Japanese with Capcom's own English as the style guide.

It runs in MAME and HBMAME and on MiSTer. The patch keeps the original ROM
sizes and key and applies to the stock Japanese set.

WHAT'S CHANGED

  - Japan's game, exactly as it plays in Japan
  - The Grand Master Challenge title, and a US region
  - Balrog, Vega, M. Bison and Akuma, the names you know
  - All 136 win quotes in English
  - The continue screen's strategy tips in English
  - Every ending in full, in English, including Akuma's
  - Akuma's intro dialogue, cut from the export game

BUILD THE GAME

Run python3 apply.py in a terminal for guided setup.
On Windows use py -3.13 apply.py.
Choose your media folder, platform, region and output folder.
Run python3 apply.py --help for command-line options.

HOW TO APPLY (recommended)

    python3 apply.py /path/to/ssf2xj.zip --out-dir out

This checks every file against the original, applies the patches, checks
the result, and writes everything you need for each platform:

  MAME:                     out/mame/ssf2xj.zip
  HBMAME:                   out/hbmame/ssf2tgmc.zip
  FBNeo:                    out/fbneo/ssf2tgmc.zip
  MiSTer:                   out/mister/_Arcade/_Arcade Patches/_Restorations/Super Street Fighter II Turbo Grand Master Challenge (USA) [English Restoration].mra
                            out/mister/games/hbmame/ssf2tgmc.zip

FBNeo: use --platform fbneo --out-dir out for complete game ZIPs.
Keep their ZIP and member names. Use an FBNeo version with definitions
matching this game release; older versions may reject its checksums.


DARKSOFT

Use --platform darksoft --out-dir out to build only Darksoft files.
The default all-platform build includes them too. Copy the selected
folder from out/darksoft/games to your card games folder.
Expanded hardware and streamed audio are not supported.

Merged, split and complete sets work, including nested or renamed ROMs.
Use --rompath DIR (repeatable) to search a collection instead of naming the
zip, and --check to check inputs before building. ZIPs and extracted folders
need no extra software; 7z archives need 7-Zip.
QSound can stay in your emulator's ROM path; valid firmware already
in a source set is kept in complete outputs.

MAME: put ssf2xj.zip from out/mame/ ahead of the stock set in your MAME
rompath.
MAME's game menu won't start a set with patched ROMs, so start it from the
command line: mame ssf2xj. MAME shows checksum warnings for the patched
ROMs; that's expected and the game runs normally.
To start it from a menu, use the HBMAME build.

HBMAME: this restoration is an official HBMAME set (ssf2tgmc),
so full HBMAME collections may already carry it.
Put ssf2tgmc.zip and qsound.zip in HBMAME's roms/ folder;
it holds the complete set.

MiSTer: copy the _Arcade folder from out/mister/ to the root of your SD card
and keep the stock, unmodified romset at games/mame/ssf2xj.zip (split MAME
sets also need qsound.zip). The MRA applies the restoration in memory as the
game loads, so nothing on the card is modified. You need Jotego's jtcps2
core, which update_all installs. The MRAs are also a separate download.

out/mister/ also holds the HBMAME set in games/hbmame/. This MRA doesn't use
it, but the CPS+ Arrange and HD Remix MRAs load it: if you use CPS+, copy
the games folder from out/mister/ to the card as well.

HOW TO APPLY (any IPS patcher)

Extract ssf2xj.zip, apply each file in ips/ to the ROM file of the
same name (Flips, Lunar IPS, or any IPS tool), then re-zip everything
as ssf2xj.zip.

CHANGED FILES

    sfx.09  (512 KB)  CRC32 642fae3f -> 60c09f48
    sfx.13m  (2.0 MB)  CRC32 cf94d275 -> 75dac0eb
    sfx.14m  (1.0 MB)  CRC32 b7cc32e7 -> fd547b71
    sfx.15m  (2.0 MB)  CRC32 5eb703af -> 84dcc039
    sfx.16m  (1.0 MB)  CRC32 8376ad18 -> 62ea61e6
    sfx.17m  (2.0 MB)  CRC32 ffa60e0f -> bfcaf206
    sfx.18m  (1.0 MB)  CRC32 f5b1b336 -> 3fb57659
    sfx.19m  (2.0 MB)  CRC32 34e825c5 -> 13a55fd3
    sfx.20m  (1.0 MB)  CRC32 459d5c6b -> af7561cd
    sfx.21m  (1.0 MB)  CRC32 e32854af -> 34f361da
    sfx.23m  (1.0 MB)  CRC32 760f2927 -> 279f2671
    sfx.25m  (1.0 MB)  CRC32 1ee90208 -> 1fbd5b9e
    sfx.27m  (1.0 MB)  CRC32 f814400f -> 11725784
    sfxj.03d  (512 KB)  CRC32 50b52b37 -> 20ad48df
    sfxj.04a  (512 KB)  CRC32 af7767b4 -> 65f36502
    sfxj.08  (512 KB)  CRC32 2de76f10 -> ea0d1d90

All other files in the set are unmodified.

LEGAL

This is a free, unofficial fan patch. It is not affiliated with or endorsed
by Capcom. All game titles, characters, and artwork remain the property of
their respective owners. You must own the game to use this patch. Do not
sell this patch or distribute it applied to a ROM image.
