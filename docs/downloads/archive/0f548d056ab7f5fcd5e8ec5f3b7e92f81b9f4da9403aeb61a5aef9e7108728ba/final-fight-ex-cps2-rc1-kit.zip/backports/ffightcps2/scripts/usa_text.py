#!/usr/bin/env python3
"""The USA edition's story text with stock Final Fight USA's typos fixed.

The misspellings of the USA game are fixed (15 October): in its
typewriter records (group 1 of the table at 0x68566), "Mr.Haggar",
"can not", "course,you'll", "sweet heart since child hood", "Ninjitsu",
"martialarts", "girl friend" and "half way". Each fix is made in place.
A record's lines are typed glyph by glyph, spaces included, and a scene
moves on when its record has typed, so every fixed record keeps its stock
glyph count: its last line ends in typed spaces, and one fewer or more of
them takes up the difference. The record's bytes, its typing frames and
the timeline stay stock; only the letters change. (The HUD's GRANADE is a
fix of every edition, build_m1_spike.TEXT_FIXES.)

``patches(program)`` returns stock-checked entries for
build_m1_spike.apply_patches. ``oracle(rompaths, directory)`` writes stock
``ffightu`` with the same bytes and build_m1_spike.TEXT_FIXES, the CPS1 reference the USA edition's gates
compare with (run_m1_spike.py, run_tick_compare.py).

    python3 usa_text.py --self-test
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import struct
import sys
import zipfile

import build_m1_spike as spike
import english_layout as layout
import text_catalog as tc

TRACK = Path(__file__).resolve().parents[1]
# group 1 record: [(stock line, fixed line), ...]
TYPOS = {
    0x07: [("Hee hee hee, Mr.Haggar. So pleased", "Hee hee hee, Mr. Haggar. So pleased")],
    0x10: [("your daughter's life can not be", "your daughter's life cannot be")],
    0x11: [("Now of course,you'll need a couple", "Now of course, you'll need a couple")],
    0x14: [("My sweet heart since child hood.", "My sweetheart since childhood.")],
    0x2E: [("of Ninjitsu and attacks", "of Ninjutsu and attacks")],
    0x2F: [("He is a martialarts expert.", "He is a martial arts expert."),
           ("His girl friend, Jessica,", "His girlfriend, Jessica,")],
    0x36: [("we're only half way there.", "we're only halfway there.")],
}
SPACE = layout.LARGE_SPACE
STOCK_HYPHEN = 0x2D                     # the 8x8 '-', typed single-height


def parse(image, at):
    """A group 1 record as stored: delay, mode, and each segment's 4-byte
    header (cell, attributes), glyphs and closing word ($FFFF between
    segments, 0 at the end)."""
    out, end = {"delay": image[at], "mode": image[at + 1], "segments": []}, at + 2
    while True:
        head = bytes(image[end:end + 4])
        end += 4
        glyphs = []
        while (g := tc.word(image, end)) and not g & 0x8000:
            glyphs.append(g)
            end += 2
        end += 2
        out["segments"].append({"head": head, "glyphs": glyphs, "close": g})
        if not g:
            out["end"] = end
            return out


def encode(rec):
    return bytes([rec["delay"], rec["mode"]]) + b"".join(
        s["head"] + b"".join(struct.pack(">H", g) for g in s["glyphs"]) + struct.pack(">H", s["close"])
        for s in rec["segments"])


def text(glyphs):
    return tc.english_text({"segments": [{"glyphs": glyphs}]})


def fixed(rec, fixes, index):
    """The record with its lines fixed and its glyph count kept: the last
    segment's trailing spaces absorb the difference."""
    segs = [dict(s, glyphs=list(s["glyphs"])) for s in rec["segments"]]
    count = sum(len(s["glyphs"]) for s in segs)
    for old, new in fixes:
        hits = [s for s in segs if text(s["glyphs"]) == [old]]
        if len(hits) != 1:
            raise ValueError(f"record {index:#04x}: no single line {old!r}")
        seg = hits[0]
        if layout.large(old) != seg["glyphs"][:len(old)]:
            raise ValueError(f"record {index:#04x}: {old!r} is not in the large font")
        seg["glyphs"] = layout.large(new) + seg["glyphs"][len(old):]
    last = segs[-1]["glyphs"]
    excess = sum(len(s["glyphs"]) for s in segs) - count
    if excess > 0:
        if len(last) < excess or any(g != SPACE for g in last[len(last) - excess:]):
            raise ValueError(f"record {index:#04x}: no trailing spaces to absorb {excess} glyphs")
        del last[len(last) - excess:]
    else:
        last.extend([SPACE] * -excess)
    return {**rec, "segments": segs}


def lowered(rec):
    """The record with every '-' it types (the 8x8 single-height 0x2D) as the
    lowered caption hyphen (build_m1_spike.CAPTION_HYPHEN), as CPS1 Final
    Fight EX lowers that tile's bar for all of them (backports/ffightcd
    build/rom.py patch_dash_tile); here a glyph of its own does it, so the
    8x8 '-' elsewhere (the test menu's titles) stays as it is."""
    return {**rec, "segments": [dict(s, glyphs=[spike.CAPTION_HYPHEN if g == STOCK_HYPHEN else g
                                                for g in s["glyphs"]]) for s in rec["segments"]]}


def lowered_block(block, group1):
    """EX's text (its copy of the text block, SEGA CD's; EX_BUILD.md) with
    every record's '-' lowered: block = the block's bytes, group1 = group
    1's offset table within it. Returns (bytes, records changed)."""
    out, changed = bytearray(block), 0
    for index in range(tc.word(out, group1) // 2):
        start = group1 + tc.word(out, group1 + 2 * index)
        rec = parse(out, start)
        new = encode(lowered(rec))
        if new != bytes(out[start:start + len(new)]):
            out[start:start + len(new)] = new
            changed += 1
    return bytes(out), changed


def patches(program):
    """(patch entries, receipt) for the USA program."""
    image = bytes(program)
    entries, rows = [], []
    for index, fixes in sorted(TYPOS.items()):
        start = tc.GROUP1 + tc.word(image, tc.GROUP1 + 2 * index)
        rec = parse(image, start)
        old = image[start:rec["end"]]
        if encode(rec) != old:
            raise ValueError(f"record {index:#04x} does not re-encode to its stock bytes")
        new = encode(fixed(rec, fixes, index))
        if len(new) != len(old):
            raise ValueError(f"record {index:#04x} changes length")
        entries.append((start, old.hex(), new.hex(),
                        f"USA story text: {'; '.join(f'{o!r} -> {n!r}' for o, n in fixes)} (usa_text.py)"))
        rows.append({"record": f"{0x100 + index:#05x}", "address": f"{start:#x}", "bytes": len(old),
                     "fixes": [{"stock": o, "fixed": n} for o, n in fixes]})
    return entries, {"records": rows, "approved": "15 October: the USA version's typos fixed"}


def oracle(rompaths, directory):
    """Stock ffightu with the fixes, as ffightu.zip in ``directory``."""
    import english_oracle                   # here: it imports build_m1_spike
    ffightu = spike.find_archive(rompaths, "ffightu")
    program = spike.usa_program(ffightu)
    entries, receipt = patches(program)
    applied = spike.apply_patches(program, {}, entries)
    applied += spike.apply_patches(program, {}, spike.TEXT_FIXES)
    out = {name: spike.upstream.member(ffightu, name) for name in english_oracle.member_names(ffightu)}
    for name, offset, _ in spike.FFIGHTU_PROGRAM:
        out[name] = bytes(program[offset:offset + 0x40000:2])
    directory.mkdir(parents=True, exist_ok=True)
    archive = directory / "ffightu.zip"
    with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED) as z:
        for name in sorted(out):
            info = zipfile.ZipInfo(name, date_time=(1990, 1, 12, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            z.writestr(info, out[name])
    receipt = {**receipt, "source": ffightu.name, "program_patches": applied,
               "program_sha256": spike.sha256(bytes(program))}
    (directory / "usa_oracle.json").write_text(json.dumps(receipt, indent=2) + "\n")
    return archive, receipt


def self_test():
    head1, head2 = struct.pack(">HH", 17 * 0x80 + 20 * 4, 0x2F), struct.pack(">HH", 17 * 0x80 + 23 * 4, 0x0F)
    rec = {"delay": 2, "mode": 2, "segments": [
        {"head": head1, "glyphs": layout.large("Mr.Haggar so"), "close": 0xFFFF},
        {"head": head2, "glyphs": layout.large("end.") + [SPACE] * 3, "close": 0}]}
    blob = encode(rec)
    image = bytearray(0x100) + blob
    assert encode(parse(image, 0x100)) == blob and parse(image, 0x100)["end"] == 0x100 + len(blob)
    longer = fixed(parse(image, 0x100), [("Mr.Haggar so", "Mr. Haggar so")], 0)
    assert [len(s["glyphs"]) for s in longer["segments"]] == [13, 6] and len(encode(longer)) == len(blob)
    assert encode(longer)[2:6] == head1          # the attributes' flag bits stay
    shorter = fixed(parse(image, 0x100), [("Mr.Haggar so", "Haggar so")], 0)
    assert [len(s["glyphs"]) for s in shorter["segments"]] == [9, 10]
    try:
        fixed(parse(image, 0x100), [("Mr.Haggar so", "Mr. Haggar so, Mike Haggar!")], 0)
    except ValueError:
        pass
    else:
        raise AssertionError("a fix longer than the trailing spaces was accepted")
    print("self-test passed")


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--self-test", action="store_true")
    parser.add_argument("--rompath", action="append", type=Path, default=[])
    args = parser.parse_args(argv)
    if args.self_test:
        self_test()
        return 0
    program = spike.usa_program(spike.find_archive(args.rompath + spike.default_rompaths(), "ffightu"))
    entries, receipt = patches(program)
    for e in entries:
        print(f"{e[0]:#x} {len(e[1]) // 2} bytes: {e[3]}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
