"""Kit-owned strider native input/export implementation."""
import argparse
import hashlib
import importlib
import json
import os
from pathlib import Path
import runpy
import shutil
import subprocess
import sys
import tempfile
import zipfile
from native_support import (check, execute, require, sha, source, write_zip,
    file_sha, inventory, verify_raw, canonicalize_mras, stage_disc, stage_components)

def file_sha(path):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            value.update(block)
    return value.hexdigest()

def desktop_mame():
    if sys.platform not in ('darwin', 'win32'):
        return None
    value = shutil.which('mame') or shutil.which('mame64')
    require(value, 'Install MAME 0.288 on PATH before reconstructing Strider EX')
    return Path(value).resolve()

def run(request, layout, kit, workspace):
    import scipy.signal
    resource_recipe = layout.get('resource_recipe', False)
    if resource_recipe:
        mame = None
        runtime = {'source': 'authenticated resource recipes'}
    else:
        mame = desktop_mame()
        runtime = {'sha256': file_sha(mame), 'version': subprocess.check_output([str(mame), '-version'], text=True, timeout=30).strip()} if mame else {'source': 'public pinned Linux helper manifest'}
    target = layout['targets'][request['target']]
    shared = Path(request['run_cache'])
    identity = hashlib.sha256(json.dumps({'kit': layout['manifest_sha256'], 'inputs': {k: b['sha256'] for k, b in request['bindings'].items()}}, sort_keys=True).encode()).hexdigest()
    root = shared / ('strider-' + identity)
    inputs = root / 'inputs'
    raw = root / 'outputs'
    marker = root / 'complete.json'
    os.environ.update(SDL_VIDEODRIVER='dummy', SDL_AUDIODRIVER='dummy', CPSPLUS_SWITCH_TOOLS_CACHE=request['tools_cache'], ARCADE_PYTHON_CACHE=str(Path(request['tools_cache']) / 'python'))
    os.environ.pop('CAPCOM_ARCADE_ROM_PATH', None)
    os.environ.pop('CPSPLUS_PYTHON', None)
    if request.get('offline'):
        os.environ['CPSPLUS_SWITCH_TOOLS_OFFLINE'] = '1'
    if not inputs.exists():
        cue = stage_disc(request['bindings'], layout['files'], layout['cue'], inputs / 'disc')
        components = {'system.dim': layout['x68k']}
        if not resource_recipe:
            components['system-card.pce'] = layout['bios']
        stage_components(request['bindings'], components, inputs)
        for machine, rows in layout['sets'].items():
            write_zip(inputs / 'roms' / (machine + '.zip'), {n: source(request['bindings'][key]) for n, key in rows.items()})
    else:
        for binding in request['bindings'].values():
            original = Path(binding['path'])
            before = original.stat()
            if 'member' in binding:
                source(binding)
            else:
                digest = hashlib.sha256()
                with original.open('rb') as stream:
                    for block in iter(lambda: stream.read(1024 * 1024), b''):
                        digest.update(block)
                require(before.st_size == binding['size'] and digest.hexdigest() == binding['sha256'], 'Strider source changed')
            after = original.stat()
            require((before.st_ino, before.st_size, before.st_mtime_ns) == (after.st_ino, after.st_size, after.st_mtime_ns), 'Strider source changed while reading')
    argv = ['--disc', inputs / 'disc/disc.cue', '--x68k', inputs / 'system.dim', '--romset', inputs / 'roms', '--out-dir', raw, '--work', root / 'work']
    if not resource_recipe:
        argv += ['--bios', inputs / 'system-card.pce']
    if mame:
        argv += ['--mame', mame]
    if marker.exists():
        meta = json.loads(marker.read_text())
        require(meta == {'identity': identity, 'runtime': runtime}, 'Strider native cache identity or runtime changed')
        for name, spec in layout['original_outputs'].items():
            check(raw / name, spec)
        require({p.relative_to(raw).as_posix() for p in raw.rglob('*') if p.is_file()} == set(layout['original_outputs']), 'Strider native cache extent changed')
    elif request['operation'] == 'preflight':
        execute(kit, [*argv, '--check'])
    else:
        execute(kit, argv)
        for name, spec in layout['original_outputs'].items():
            check(raw / name, spec)
        require({p.relative_to(raw).as_posix() for p in raw.rglob('*') if p.is_file()} == set(layout['original_outputs']), 'Strider native output extent differs')
        if mame:
            require(file_sha(mame) == runtime['sha256'], 'MAME changed during source reconstruction')
        marker.write_text(json.dumps({'identity': identity, 'runtime': runtime}))
    response = {'status': 'ok', 'dependencies': {'source_runtime': runtime, 'scipy': scipy.__version__}}
    if request['operation'] == 'build':
        staging = Path(request['staging'])
        for origin, mapping in ((raw, target['mapping']), (kit, target['kit_mapping'])):
            for old, new in mapping.items():
                dest = staging / new
                dest.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(origin / old, dest)
        for name, spec in target['outputs'].items():
            check(staging / name, spec)
        response['outputs'] = target['outputs']
    return response


import re
import xml.etree.ElementTree as ET
import native_support as contracts

def define(root, slug, version, revision, native, registry):
    archive = contracts.Directory(root)
    kit_identity = json.loads(archive.read('kit.json'))
    resource_recipe = kit_identity.get('schema') == 2 and kit_identity.get('recipe') == 'striderex-resource-recipes/1'
    qualified = dict(native)
    published = json.loads(archive.read('outputs.json'))
    contracts.require(set(qualified) == set(published['files']), 'Incomplete Strider public output extent')
    for name, spec in qualified.items():
        expected = {'members': published['inventory'][name]['members']} if 'members' in spec else {'sha256': published['files'][name]}
        contracts.require(spec == expected, 'Independent Strider output differs from public verifier')
    release = {'game_version': version, 'kit_revision': revision, 'requires': ['file-inputs-v1', 'zip-outputs-v1', 'run-cache-v1', 'locked-wheels-v1', 'external-tools-v1', 'worker-timeout-v1'], 'prerequisites': {}, 'targets': {}}

    def prerequisite(title, kind, pin):
        contracts.file_contract(pin)
        key = kind + '-' + pin['sha256'][:20]
        release['prerequisites'][key] = {'title': title, 'kind': kind, 'formats': ['loose file', 'ZIP member'], 'alternatives': [pin], 'action': 'Add the matching owned source to a scanned folder. Files are identified by content; loose files, ZIP members and 7z members are supported.'}
        return key
    tracks = json.loads(archive.read('disc_inputs.json'))['files']
    contracts.require(registry['disc']['files'] == {n: {'size': s['bytes'], 'sha256': s['sha256']} for n, s in tracks.items()}, 'Strider track registry differs')
    files = {n: prerequisite('Strider Hiryuu (Japan), PC Engine CD: ' + n, 'disc', s) for n, s in registry['disc']['files'].items()}
    material = json.loads(archive.read('release-material.json'))
    contracts.require(registry['x68k']['sha256'] == material['x68k']['system_dim_sha256'], 'Strider X68000 source differs')
    bios = None if resource_recipe else prerequisite('Japanese Super CD-ROM System Card v3.0 BIOS', 'firmware', registry['bios'])
    x68k = prerequisite('Strider Hiryuu X68000 System disk', 'game', registry['x68k'])
    stock = json.loads(archive.read('rom_inputs.json'))
    sets = {}
    for machine, rows in stock['sets'].items():
        sets[machine] = {}
        for name, s in (rows | stock['mame_aux'][machine]).items():
            pin = {'size': s['bytes'], 'sha256': s['sha256']}
            if 'crc32' in s:
                pin['crc32'] = s['crc32']
            sets[machine][name] = prerequisite(machine + ': ' + name, 'rom', pin)
    recipe = {'manifest_sha256': 'native-manifest', 'files': files, 'cue': registry['disc']['cue'], 'bios': bios, 'x68k': x68k, 'sets': sets, 'original_outputs': qualified, 'targets': {}}
    if resource_recipe:
        recipe['resource_recipe'] = True
    inputs = sorted({*files.values(), *([bios] if bios else []), x68k, *[k for rows in sets.values() for k in rows.values()]})
    covered = {'BUILD-RECEIPT.json'}
    for region, setname in (('us', 'striderus01'), ('jp', 'striderjs01')):
        for platform in ('hbmame', 'mister'):
            mapping = {}
            for name in qualified:
                if not name.startswith(platform + '/'):
                    continue
                if name.endswith('.mra') and ('/_Japan/' in name) != (region == 'jp'):
                    continue
                if any((other in name for other in ('striderus01', 'striderjs01') if other != setname)):
                    continue
                new = name[len(platform + '/'):]
                if platform == 'hbmame':
                    new = ('roms/' if new.endswith('.zip') else 'support/' + slug + '/definitions/') + Path(new).name
                mapping[name] = new
            contracts.require(mapping, 'Missing Strider regional/platform outputs')
            covered.update(mapping)
            support = {n: 'support/' + slug + '/' + n for n in ('README.txt', 'TOOLS.md', 'LICENSES.txt')}
            outputs = {new: qualified[old] for old, new in mapping.items()}
            outputs.update({new: {'sha256': hashlib.sha256(archive.read(old)).hexdigest()} for old, new in support.items()})
            target = region + '-' + platform
            release['targets'][target] = {'platform': platform, 'variant': region, 'region': region, 'inputs': inputs, 'outputs': outputs, 'timeout_seconds': 14400, 'external_tools': [{'id': 'mame', 'title': 'MAME 0.288 with Lua and the source drivers', 'commands': ['mame', 'mame64'], 'args': ['-version'], 'version_pattern': '^0\\.288(?:\\s|$)', 'hosts': ['darwin-arm64', 'windows-x86_64'], 'action': 'Install MAME 0.288 on PATH. Its Lua and source drivers are checked again before reconstruction.'}], 'minimum_free_bytes': 12 * 1024 ** 3, 'software_notes': ['Requires complete owned PC Engine CD tracks, X68000 System disk, Japanese System Card v3.0 BIOS and canonical Strider arcade ROMs.', 'Requires exactly MAME 0.288 with Lua and pce/striderua/striderjr drivers. Install it on PATH on macOS/Windows; the public kit supplies Linux helpers.', 'Pinned NumPy, Pillow, SciPy and soundtrack helpers are prepared privately. Reconstruction runs MAME without a window or sound.'], 'destination_requirements': 'An HBMAME build that includes the Strider EX sets.' if platform == 'hbmame' else 'Arcade-audio launchers also require the stock jtcps1 core on the destination.'}
            recipe['targets'][target] = {'mapping': mapping, 'kit_mapping': support, 'outputs': outputs}
            if resource_recipe:
                release['targets'][target].update(external_tools=[], minimum_free_bytes=4 * 1024**3,
                    software_notes=['Requires complete owned PC Engine CD tracks, X68000 System disk and canonical Strider arcade ROMs.',
                                    'Source-bound resource recipes replace recipient emulation and conversion.',
                                    'Pinned NumPy, SciPy and authenticated FFmpeg helpers reproduce the unchanged arrangement.'],
                    destination_requirements='An HBMAME build that includes the Strider EX sets.' if platform=='hbmame' else
                        'Includes the required unchanged Strider EX CPS+ core and regional audio/language launchers.')
    contracts.require(covered == set(qualified), 'Unaccounted Strider output role')
    for requirement in release['prerequisites'].values():
        if '7z member' not in requirement['formats']:requirement['formats'].append('7z member')
    release['api'] = 1
    release['project'] = slug
    release['native_outputs'] = qualified
    release['requires'] = sorted(set(release['requires']) | {'native-context-v1', 'native-bindings-v1'})
    return (release, recipe)
