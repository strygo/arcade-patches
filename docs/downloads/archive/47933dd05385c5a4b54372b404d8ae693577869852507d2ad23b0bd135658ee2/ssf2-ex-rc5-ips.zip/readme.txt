Super Street Fighter II EX · Enhanced version
=============================================

Version:  rc5 (2026-10-06)
Target:   MAME set 'ssf2xj' (Super Street Fighter II X: Grand Master Challenge (Japan 940311))
Hardware: Capcom CPS-2
Patch by: Steve Gordon (https://x.com/strygo)
Website:  https://strygo.github.io/arcade-patches/

ABOUT THIS PROJECT

Super Turbo is the version competitive players swear by, but it left things
behind. The bonus stages from Super Street Fighter II were gone. Shin Akuma
was a hidden boss you had to earn, and Ten Akuma only turned up years later at
home. Tournament Battle, the eight-player linked-cabinet mode, stayed with the
earlier Super Street Fighter II.

EX puts it together on the arcade game. Akuma has his own select-screen cell,
with Shin and Ten available through codes there; the original Ryu codes still
work. A random-select cell sits opposite him. The car, the falling barrels and
the oil drums are back between fights. Link cabinets with the adapter and it
runs Tournament Battle; without it, it plays as normal. Every fighter gets two
more colors, Akuma and Shin Akuma get their colors from Ultra Street Fighter
II, the move names are the modern ones, and the title screen carries an EX
mark.

Nothing about the existing fighters changes: this is Japan's Super Turbo
underneath. The USA build carries all of Grand Master Challenge's English
text; the Japan build keeps the Japanese.

An EX CONFIGURATION page in the operator menu covers names, artwork and the
bonus stages. The 30th Anniversary Collection's artwork is the default.

EX uses the same ROM files as the Japanese set. It runs in MAME and HBMAME and
on MiSTer.

This is a release candidate.

WHAT'S CHANGED

  - Akuma and random-select cells on the player-select screen. On Akuma or
    Ryu, hold Start and press three kicks for Shin, or MP, HP, MK and HK
    together for Ten (hold Start and three punches gives Akuma)
  - Ten Akuma has his Super gauge and the Raging Demon, with the 天 pose
  - Akuma in eleven classic colors from Ultra Street Fighter II, picked on his
    own cell: three punches or three kicks, any single button, or LP+LK, MP+MK
    or HP+HK (LP+HK keeps the EX blue). His portraits follow the color, even
    in a mirror match
  - Shin Akuma in eleven colors from Ultra Street Fighter II: pick Shin on
    Akuma's cell, let go of every button, then press one of the same buttons
    before the select screen moves on
  - Akuma's own defeated face on the Continue screen, in the color you picked
  - The three bonus stages from Super Street Fighter II, back in one-player
    games: the car after three fights, the barrels after six, the oil drums
    after nine. They run at the selected Turbo speed; BONUS STAGE in EX
    CONFIGURATION turns them on or off
  - EX CONFIGURATION in the operator menu: Japanese or international names,
    ORIGINAL or 30TH ANNIVERSARY art for the Hong Kong flag, Chun-Li's
    storefront signs and Guile's stage (30th Anniversary by default), and
    BONUS STAGE on or off. Settings are saved between sessions
  - Tournament Battle: with the link adapter, eight players and three matches
    across linked cabinets, with the Akuma and random-select cells on its
    select screen; without it, the game plays normally
  - A new title screen with an EX mark
  - Two more colors for every fighter: pick with two punches or two kicks, or
    hold Start as well for the Old version in those colors. The VS screen and
    the fight portrait show the color you picked
  - Free Play in the Japanese build too
  - Modern move names: Cammy's Spiral Arrow, Cannon Spike and Quick Spin
    Knuckle, and Dee Jay's Air Slasher, with the Japanese voice callouts in
    the USA build
  - USA build: all of Grand Master Challenge's English. Japan build: the
    original Japanese text, with Grand Master Challenge's backdrop fixes
  - The existing fighters play exactly as in Japan's Super Turbo

BUILDS IN THIS DOWNLOAD

    usa        USA (English)
    japan      Japan (Japanese)

HOW TO APPLY (recommended)

    python3 apply.py /path/to/ssf2xj.zip --out-dir out

This checks every file against the original, applies the patches, checks
the result, and writes everything you need for every build (add
--variant <build> to make just one):

  USA (English):
    MAME / original hardware: out/mame/usa/ssf2xj.zip
    HBMAME:                   out/hbmame/ssf2tuc.zip
    MiSTer:                   out/mister/_Arcade/_Arcade Patches/_Enhanced Versions/Super Street Fighter II EX (USA).mra
                              out/mister/games/hbmame/ssf2tuc.zip
  Japan (Japanese):
    MAME / original hardware: out/mame/japan/ssf2xj.zip
    HBMAME:                   out/hbmame/ssf2xuc.zip
    MiSTer:                   out/mister/_Arcade/_Arcade Patches/_Enhanced Versions/_Japan/Super Street Fighter II EX (Japan).mra
                              out/mister/games/hbmame/ssf2xuc.zip

MAME: put ssf2xj.zip from out/mame/ ahead of the stock set in your MAME
rompath (one build at a time: they share the set name).
MAME's game menu won't start a set with patched ROMs, so start it from the
command line: mame ssf2xj. MAME shows checksum warnings for the patched
ROMs; that's expected and the game runs normally.
To start it from a menu, use the HBMAME build.

HBMAME: the set definition (ssf2tuc, ssf2xuc) ships with the project;
an upstream HBMAME submission is pending.
Put the zip in HBMAME's roms/ folder next to your stock ssf2xj.zip.
It loads with no checksum warnings.

MiSTer: copy the _Arcade folder from out/mister/ to the root of your SD card
and keep the stock, unmodified romset at games/mame/ssf2xj.zip (split MAME
sets also need qsound.zip). The MRA applies the edition in memory as the
game loads, so nothing on the card is modified. You need Jotego's jtcps2
core, which update_all installs. The MRAs are also a separate download.

out/mister/ also holds the HBMAME set in games/hbmame/. This MRA doesn't use
it, but the CPS+ Arrange and HD Remix MRAs load it: if you use CPS+, copy
the games folder from out/mister/ to the card as well.

HOW TO APPLY (any IPS patcher)

Extract ssf2xj.zip, apply each file in ips/<build>/ to the ROM file of the
same name (Flips, Lunar IPS, or any IPS tool), then re-zip everything
as ssf2xj.zip.

CHANGED FILES

  USA (English) (--variant usa):
    sfx.13m  (2.0 MB)  CRC32 cf94d275 -> 63f1301e
    sfx.14m  (1.0 MB)  CRC32 b7cc32e7 -> 92735f0d
    sfx.15m  (2.0 MB)  CRC32 5eb703af -> 0d64a671
    sfx.16m  (1.0 MB)  CRC32 8376ad18 -> 1717ef2d
    sfx.17m  (2.0 MB)  CRC32 ffa60e0f -> fd13753a
    sfx.18m  (1.0 MB)  CRC32 f5b1b336 -> c62f240b
    sfx.19m  (2.0 MB)  CRC32 34e825c5 -> 50082000
    sfx.20m  (1.0 MB)  CRC32 459d5c6b -> d662a657
    sfx.21m  (1.0 MB)  CRC32 e32854af -> 94b141da
    sfx.23m  (1.0 MB)  CRC32 760f2927 -> 359e2c32
    sfx.25m  (1.0 MB)  CRC32 1ee90208 -> 99008d5f
    sfx.27m  (1.0 MB)  CRC32 f814400f -> 164bbf8b
    sfxj.03d  (512 KB)  CRC32 50b52b37 -> 8b3a2dc4
    sfxj.04a  (512 KB)  CRC32 af7767b4 -> 164d1dc0
    sfxj.05  (512 KB)  CRC32 f4ff18f5 -> 477b0a5e
    sfxj.06b  (512 KB)  CRC32 413477c2 -> 69985c28
    sfxj.07a  (512 KB)  CRC32 a18b3d83 -> 11d390a0
    sfxj.08  (512 KB)  CRC32 2de76f10 -> ea0d1d90

  Japan (Japanese) (--variant japan):
    sfx.13m  (2.0 MB)  CRC32 cf94d275 -> d9bf2280
    sfx.14m  (1.0 MB)  CRC32 b7cc32e7 -> 92735f0d
    sfx.15m  (2.0 MB)  CRC32 5eb703af -> d70f65e7
    sfx.16m  (1.0 MB)  CRC32 8376ad18 -> 1717ef2d
    sfx.17m  (2.0 MB)  CRC32 ffa60e0f -> bd7f8933
    sfx.18m  (1.0 MB)  CRC32 f5b1b336 -> c62f240b
    sfx.19m  (2.0 MB)  CRC32 34e825c5 -> 77455a16
    sfx.20m  (1.0 MB)  CRC32 459d5c6b -> d662a657
    sfx.21m  (1.0 MB)  CRC32 e32854af -> 94b141da
    sfx.23m  (1.0 MB)  CRC32 760f2927 -> 359e2c32
    sfx.25m  (1.0 MB)  CRC32 1ee90208 -> 99008d5f
    sfx.27m  (1.0 MB)  CRC32 f814400f -> 164bbf8b
    sfxj.03d  (512 KB)  CRC32 50b52b37 -> 0c93760f
    sfxj.04a  (512 KB)  CRC32 af7767b4 -> 3f2a364e
    sfxj.05  (512 KB)  CRC32 f4ff18f5 -> 477b0a5e
    sfxj.06b  (512 KB)  CRC32 413477c2 -> 5c492210
    sfxj.07a  (512 KB)  CRC32 a18b3d83 -> f2f87e14
    sfxj.08  (512 KB)  CRC32 2de76f10 -> ea0d1d90

All other files in the set are unmodified.

LEGAL

This is a free, unofficial fan patch. It is not affiliated with or endorsed
by Capcom. All game titles, characters, and artwork remain the property of
their respective owners. You must own the game to use this patch. Do not
sell this patch or distribute it applied to a ROM image.
