"""Verified immutable source preparation shared by native CPS+ workers."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import tempfile


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def members(root):
    result = {}
    for path in sorted(root.rglob('*')):
        if path.is_symlink():
            raise ValueError('Prepared source contains a symlink')
        if path.is_file():
            result[path.relative_to(root).as_posix()] = digest(path)
        elif not path.is_dir():
            raise ValueError('Prepared source contains an unsupported file type')
    return result


def prepared_tree(cache_root, source, recipe, extract):
    """Publish a complete tree atomically; missing caches rebuild, drift fails.

    extract receives a private empty destination. It must only write there.
    Concurrent cold workers may extract twice, but never read a partial tree.
    """
    source = Path(source)
    identity = {'source_sha256': digest(source), 'recipe_sha256': recipe, 'schema': 1}
    token = hashlib.sha256(json.dumps(identity, sort_keys=True).encode()).hexdigest()
    root = Path(cache_root);root.mkdir(parents=True, exist_ok=True)
    ready = root / ('cps-source-' + token)

    def verify():
        if {p.name for p in ready.iterdir()} != {'complete.json', 'data'}:
            raise ValueError('Prepared source cache extent changed')
        marker = json.loads((ready/'complete.json').read_text())
        if marker['identity'] != identity or not marker['files'] or members(ready/'data') != marker['files']:
            raise ValueError('Prepared source cache changed; remove this cache entry and retry: ' + str(ready))
        return ready/'data'

    if ready.exists():
        return verify()
    with tempfile.TemporaryDirectory(prefix='cps-source-build-', dir=root) as temporary:
        stage = Path(temporary)/'entry';stage.mkdir()
        data = stage/'data';data.mkdir()
        extract(data)
        if digest(source) != identity['source_sha256']:
            raise ValueError('Source changed during preparation')
        contents = members(data)
        if not contents:
            raise ValueError('Prepared source is empty')
        (stage/'complete.json').write_text(json.dumps({'identity': identity, 'files': contents}, sort_keys=True)+'\n')
        try:
            stage.rename(ready)
        except OSError:
            if not ready.exists():raise
        return verify()


def private_view(source, destination):
    """A worker owns its directory; readers share immutable data blocks."""
    def link(a, b):
        try:return os.link(a, b)
        except OSError:return shutil.copy2(a, b)
    shutil.copytree(source, destination, copy_function=link)
