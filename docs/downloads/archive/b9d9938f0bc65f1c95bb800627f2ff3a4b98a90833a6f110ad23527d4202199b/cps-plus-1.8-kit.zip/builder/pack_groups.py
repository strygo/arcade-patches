"""Pack groups shared by the standalone builder and its machine description.

Keep this module standard-library only; listing must not load media helpers.
"""
import json
from pathlib import Path


def describe(root):
    """List the same groups the builder dispatches, without importing it."""
    hashes = json.loads((Path(root) / 'pack_hashes.json').read_text())
    names = [name for name, *_ in GROUPS]
    packs = [pack for _, _, _, outputs in GROUPS for pack in outputs]
    if len(names) != len(set(names)) or len(packs) != len(set(packs)):
        raise ValueError('Duplicate pack group or output')
    if set(packs) != set(hashes):
        raise ValueError('Pack group outputs differ from accepted pack hashes')
    return {'schema': 1, 'kind': 'cps-plus-group-description', 'id': 'cps-plus',
            'groups': [{'id': name, 'source_keys': keys, 'packs': outputs}
                       for name, keys, _, outputs in GROUPS],
            'accepted_packs': hashes,
            'capabilities': {'collection_export': False}}


def X68K(slug: str, mode: str) -> dict:
    return {"x68k": slug, "mode": mode}

def X68K_FM(slug: str) -> dict:
    return {"x68k_fm": slug}

def PSX(pack: str) -> dict:
    return {"psx": pack}

def DOS(device: str) -> dict:
    return {"dos": device}


# (group, required source keys, build arguments or renderer marker, output packs)
# One declaration drives both build dispatch and metadata listing.
GROUPS = [
    ("ffight",     ["ffight_us_disc", "ffight_jp_disc"], None,  # special-cased
     ["ffight_arrange", "ffight_arrange_jp"]),
    ('ffightcps2-usa', ['ffight_us_disc'], ['ffightcps2-ex', '--region', 'us', '--time-attack', '--us-disc', '{ffight_us_disc}', '--source-disc', '{ffight_us_disc}'], ['ffightcps2_ex_arrange']),
    ('ffightcps2-japan', ['ffight_jp_disc'], ['ffightcps2-ex', '--region', 'jp', '--time-attack', '--jp-disc', '{ffight_jp_disc}', '--source-disc', '{ffight_jp_disc}'], ['ffightcps2_ex_arrange_jp']),
    ('ffightcps2-english', ['ffight_jp_disc'], ['ffightcps2-ex', '--region', 'en', '--time-attack', '--jp-disc', '{ffight_jp_disc}', '--source-disc', '{ffight_jp_disc}', '--keyed', 'manifests/ffightcps2-keyed'], ['ffightcps2_ex_arrange_en']),
    ("ffightae-cps2", ["ffight_us_disc"],
     ["ffightae-cps2", "--us-disc", "{ffight_us_disc}"],
     ["ffightae_cps2_arrange"]),
    ("ffight-ost", ["ffight_ost_dir"],
     ["ffight-ost", "--ost", "{ffight_ost_dir}"],
     ["ffight_snes", "ffight_x68k_fm", "ffight_x68k_midi"]),
    # The SSF2 family: one pack per soundtrack, serving Super SF2, Super SF2
    # Turbo (with SSF2X, EX and GMC) and Hyper SF2 alike.
    ("ssf2-arrange", ["hsf2_ae_iso"],
     ["hsf2", "--iso", "{hsf2_ae_iso}", "--bank", "arrange"],
     ["ssf2_arrange"]),
    ("ssf2-cps1",  ["hsf2_ae_iso"],
     ["hsf2", "--iso", "{hsf2_ae_iso}", "--bank", "cps1"],
     ["ssf2_cps1"]),
    ("sf2",        ["hsf2_ae_iso"],
     ["sf2-arrange", "--iso", "{hsf2_ae_iso}"],
     ["sf2_arrange"]),
    ("sfa1",       ["sfa1_saturn_disc"],
     ["sfa1-arrange", "--disc", "{sfa1_saturn_disc}"],
     ["sfa1_arrange"]),
    ("sfa2-snes",  ["anthology_iso"],
     # this builder writes next to its module unless told otherwise
     ["sfa2-snes", "--iso", "{anthology_iso}",
      "--out", "work/packs/sfa2_snes.cpk"],
     ["sfa2_snes"]),
    ("sfa2",       ["sfz2_saturn"],
     ["sfa2-arrange", "--game", "sfa2", "--iso", "{sfz2_saturn}"],
     ["sfa2_arrange"]),
    ("sfz2al",     ["sfz2dash_saturn"],
     ["sfa2-arrange", "--iso", "{sfz2dash_saturn}"],
     ["sfz2al_arrange"]),
    ("spf2t",      ["spf2t_saturn"],
     ["spf2t", "--disc", "{spf2t_saturn}"],
     ["spf2t_arrange"]),
    ("mtwins",     ["mtwins_pce_disc"],
     ["mtwins", "--disc", "{mtwins_pce_disc}"],
     ["mtwins_arrange"]),
    ("forgottn",   ["forgottn_pce_disc"],
     ["forgottn", "--disc", "{forgottn_pce_disc}"],
     ["forgottn_arrange"]),
    ("mbomber",    ["mbomber_fmt_disc"],
     ["mbomber", "--disc", "{mbomber_fmt_disc}"],
     ["mbomber_arrange"]),
    ("unsquad-snes", ["unsquad_ost_dir"],
     ["unsquad-snes", "--ost", "{unsquad_ost_dir}"],
     ["unsquad_snes"]),
    ("ffight-di",   ["double_impact_album"],
     ["remix", "--pack", "ffight_di", "--source-root", "{double_impact_album}"],
     ["ffight_di"]),
    ("msword-di",   ["double_impact_album"],
     ["remix", "--pack", "msword_di", "--source-root", "{double_impact_album}"],
     ["msword_di"]),
    ("ssf2-hdremix", ["hd_remix_album"],
     ["remix", "--pack", "ssf2_hdremix", "--source-root", "{hd_remix_album}"],
     ["ssf2_hdremix"]),
    ("strider-pce", ["strider_pce_disc"],
     ["strider-pce", "--disc", "{strider_pce_disc}"], ["strider_pce"]),
    ("ssf2-3do", ["ssf2t_3do_disc"],
     ["ssf2-console", "--source", "3do", "--disc", "{ssf2t_3do_disc}"], ["ssf2_3do"]),
    ("ssf2-fmtowns", ["ssf2_fmtowns_disc"],
     ["ssf2-console", "--source", "fmtowns", "--disc", "{ssf2_fmtowns_disc}"], ["ssf2_fmtowns"]),
    ("strider-psx", ["strider_psx_disc", "psx_bios_dir"],
     PSX("strider_psx"), ["strider_psx"]),
    ("captcomm-psx", ["captcomm_psx_disc"],
     ["captcomm-psx", "--disc", "{captcomm_psx_disc}"],
     ["captcomm_psx"]),
    # Ultra Street Fighter II's remixed score, for the whole SSF2 family.
    ("usf2-remix", ["usf2_source", "switch_prod_keys"],
     ["usf2-remix", "--source", "{usf2_source}", "--keys", "{switch_prod_keys}"],
     ["ssf2_usf2_remix"]),
    ("ghouls-x68k-midi", ["x68k_daimakaimura_disk", "sc55_rom_dir"],
     X68K("daimakaimura", "ghouls-x68k-midi"), ["ghouls_x68k_midi"]),
    ("sf2ce-x68k-midi",  ["x68k_sf2ce_disk", "sc55_rom_dir"],
     X68K("sf2ce", "sf2ce-x68k-midi"), ["sf2ce_x68k_midi"]),
    ("ssf2-x68k-midi",   ["x68k_ssf2_disk", "sc55_rom_dir"],
     X68K("ssf2", "ssf2-x68k-midi"), ["ssf2_x68k_midi"]),
    # The same game's FM music, recorded from the X68000 port in MAME.
    ("ssf2-x68k-fm",     ["x68k_ssf2_disk", "x68000_bios_dir"],
     X68K_FM("ssf2"), ["ssf2_x68k_fm"]),
    # One MS-DOS disc, four carriers that sound nothing alike, four packs.
    # Each is its own job so the ones your machine can render are built and
    # the rest simply skip: the CD needs no renderer at all, the OPL one
    # builds its own, and the two Roland ones need your ROM dumps.
    ("ssf2-dos-cd",   ["ssf2t_dos_disc"],
     DOS("cd"),   ["ssf2_dos_cd"]),
    ("ssf2-dos-fm",   ["ssf2t_dos_disc"],
     DOS("fm"),   ["ssf2_dos_fm"]),
    ("ssf2-dos-sc55", ["ssf2t_dos_disc", "sc55_rom_dir"],
     DOS("sc55"), ["ssf2_dos_sc55"]),
    ("ssf2-dos-mt32", ["ssf2t_dos_disc", "mt32_rom_dir"],
     DOS("mt32"), ["ssf2_dos_mt32"]),
]
