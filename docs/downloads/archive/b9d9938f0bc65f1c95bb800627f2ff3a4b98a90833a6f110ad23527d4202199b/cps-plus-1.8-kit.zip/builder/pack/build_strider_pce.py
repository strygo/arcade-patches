"""Build the Strider (PC Engine Soundtrack) pack from the PC Engine CD.

The recipe (manifests/strider_pce_audio.json, written by
tools/strider_pce_recipe.py from the approved listening review) pins the disc,
each track's trim, the 44.1 -> 48 kHz resampling, and the reviewed loop and
blend coordinates. Every track is rebuilt from the disc and must equal the
approved recording, byte for byte, or the build stops.

Loops keep the reviewed linear blend baked before loop_end (hardware
crossfade off). One-shots (Stage Clear, Continue, Game Over, Ending) play
once. The stage intros start their stage's opening track, and the stage's
first cue continues it (the CPS-1 player ignores a PLAY of the track already
playing). Native-fallback commands, Time Over 0x23 included, stop the
arranged track and leave the arcade music audible.
"""
from __future__ import annotations

import argparse
import hashlib
import io
import json
from pathlib import Path
import wave
import zipfile

import numpy as np
from scipy import signal

from . import adxcodec, protocols
from .build_common import MANIFESTS, PACKS_DIR, PKG_ROOT
from .format import PackWriter, TrackMeta, TriggerRow, VERB_PLAY, VERB_STOP
from .strider_disc import disc_bins

RECIPE = MANIFESTS / "strider_pce_audio.json"
DISC = PKG_ROOT.parent / "roms" / "pce" / "Strider Hiryuu (Japan).7z"
RATE = 48000


def digest(path):
    with Path(path).open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()


def wav_bytes(y):
    if not (np.isfinite(y).all() and np.max(np.abs(y)) < 1):
        raise ValueError('PCM out of range')
    pcm = np.rint(y * 32768).clip(-32768, 32767).astype('<i2').tobytes()
    buf = io.BytesIO()
    with wave.open(buf, 'wb') as f:
        f.setnchannels(2)
        f.setsampwidth(2)
        f.setframerate(RATE)
        f.writeframes(pcm)
    return buf.getvalue(), pcm


def track_pcm(row, bin_bytes):
    """The reviewed recording of one track, rebuilt from its disc bin."""
    x = np.frombuffer(bin_bytes, '<i2').reshape(-1, 2).astype(np.float64) / 32768
    x = signal.resample_poly(x[row['source_trim_frames']:], 160, 147, axis=0, window=('kaiser', 8.6))
    if row['loop_start'] is None:
        y = np.pad(x, ((0, (-len(x)) % 32), (0, 0)))
    else:
        a, b, n = row['loop_start'], row['loop_end'], row['crossfade_frames']
        if not (0 < n <= a < b <= len(x) and all(v % 32 == 0 for v in (a, b, n))):
            raise ValueError(f"{row['id']}: invalid loop coordinates")
        y = x[:b].copy()
        w = np.linspace(0., 1., n)[:, None]
        y[b - n:b] = x[b - n:b] * (1 - w) + x[a - n:a] * w
    wav, pcm = wav_bytes(y)
    if hashlib.sha256(wav).hexdigest() != row['reviewed_wav_sha256']:
        raise ValueError(f"{row['id']}: rebuilt PCM differs from the approved recording")
    return pcm


def stored_zip(path, files):
    with zipfile.ZipFile(path, 'w', compression=zipfile.ZIP_STORED) as z:
        for name, data in sorted(files.items()):
            info = zipfile.ZipInfo(name, date_time=(2026, 10, 9, 0, 0, 0))
            info.external_attr = 0o100644 << 16
            z.writestr(info, data)


def build(recipe_path=RECIPE, disc=DISC, outdir=PACKS_DIR):
    recipe = json.loads(Path(recipe_path).read_text(encoding='utf-8'))
    disc = Path(disc)
    if not disc.exists():
        raise SystemExit(f'{disc}: the PC Engine disc is missing (pass --disc)')
    outdir = Path(outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    bins = disc_bins(disc, sorted({t['disc_track'] for t in recipe['tracks']}))
    w = PackWriter(protocols.PROTOCOLS['strider'], title='Strider (PC Engine Soundtrack)',
                   trigger_rows=256, default_rate=RATE, xfade_samples=0)
    tracks, audit = {}, []
    for row in recipe['tracks']:
        pcm = track_pcm(row, bins[row['disc_track']])
        stream = adxcodec.encode(pcm, 2, RATE)
        c1, c2 = adxcodec.calc_coeffs(adxcodec.DEFAULT_CUTOFF, RATE)
        loop = row['loop_start'] is not None
        meta = TrackMeta(sample_rate=RATE, channels=2, gain=127, coef1=c1, coef2=c2,
                         loop_start_sample=row['loop_start'] if loop else 0,
                         loop_end_sample=row['loop_end'] if loop else 0,
                         loop_start_byte=adxcodec.samples_to_stream_byte(row['loop_start'], 2) if loop else 0,
                         loop_end_byte=adxcodec.samples_to_stream_byte(row['loop_end'], 2) if loop else 0,
                         xfade_enable=False, name=row['title'], source=recipe['source']['disc'])
        tracks[row['id']] = w.add_track(stream, meta)
        audit.append(dict(id=row['id'], pcm_sha256=hashlib.sha256(pcm).hexdigest(),
                          adx_sha256=hashlib.sha256(stream).hexdigest()))
        print(row['id'], row['title'], flush=True)
    for row in recipe['triggers']:
        cmd = int(row['command'], 16)
        if row['track']:
            w.set_trigger(cmd, TriggerRow(verb=VERB_PLAY, track=tracks[row['track']],
                                          gain=recipe['trigger_gain'], suppress=1))
        elif row['stop_arranged']:
            w.set_trigger(cmd, TriggerRow(verb=VERB_STOP, suppress=0))
    pack = outdir / 'strider_pce.cpk'
    w.write(pack)
    stored_zip(outdir / 'strider_pce.zip', {pack.name: pack.read_bytes()})
    report = dict(pack=pack.name, sha256=digest(pack), bytes=pack.stat().st_size,
                  review_status=recipe['review_status'], recipe_sha256=digest(recipe_path), tracks=audit)
    (outdir / 'strider_pce.build.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8',
                                                   newline='\n')
    return report


def self_test():
    rng = np.random.default_rng(3)
    x = rng.normal(0, .05, (44100 * 2, 2))
    raw = np.rint(x * 32768).astype('<i2').tobytes()
    y = signal.resample_poly(np.frombuffer(raw, '<i2').reshape(-1, 2) / 32768, 160, 147, axis=0,
                             window=('kaiser', 8.6))
    row = dict(id='t', source_trim_frames=0, loop_start=32 * 600, loop_end=32 * 2400, crossfade_frames=32 * 10)
    want = y[:row['loop_end']].copy()
    wgt = np.linspace(0., 1., 320)[:, None]
    want[row['loop_end'] - 320:row['loop_end']] = (y[row['loop_end'] - 320:row['loop_end']] * (1 - wgt)
                                                   + y[row['loop_start'] - 320:row['loop_start']] * wgt)
    row['reviewed_wav_sha256'] = hashlib.sha256(wav_bytes(want)[0]).hexdigest()
    track_pcm(row, raw)
    try:
        track_pcm(row | dict(crossfade_frames=32 * 11), raw)
    except ValueError:
        pass
    else:
        raise AssertionError('a changed blend must not match the approved recording')
    print('Strider PCE rebuild checks passed')


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--recipe', type=Path, default=RECIPE)
    p.add_argument('--disc', type=Path, default=DISC, help='Strider Hiryuu (Japan) PC Engine CD: CUE/BIN, ZIP or 7z')
    p.add_argument('--out-dir', type=Path, default=PACKS_DIR)
    p.add_argument('--self-test', action='store_true')
    a = p.parse_args(argv)
    if a.self_test:
        self_test()
        return 0
    print(json.dumps(build(a.recipe, a.disc, a.out_dir), indent=2))
    return 0
