"""Verify Strider's logical disc tracks independently of archive packaging."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import subprocess
import tempfile
import zipfile

from .build_common import MANIFESTS
from .discsrc import extract_cdda

PINS = MANIFESTS / 'strider_pce_disc.json'


def read_tracks(cue, wanted, pins):
    entries, _ = extract_cdda.parse_cue(cue)
    if [e[0] for e in entries] != [p['track'] for p in pins]:
        raise ValueError('Strider disc: track table differs from the pinned disc')
    if not set(wanted) <= {p['track'] for p in pins}:
        raise ValueError('Strider disc: unknown requested track')
    result = {}
    for entry, pin in zip(entries, pins):
        n, mode, path, i0, i1, pregap = entry
        if mode.upper() != pin['mode']:
            raise ValueError(f'Strider disc track {n:02}: unexpected mode {mode}')
        start = i0 if i0 is not None else i1
        following = [e for e in entries if e[0] > n and e[2] == path]
        end = ((following[0][3] if following[0][3] is not None else following[0][4]) * 2352
               if following else path.stat().st_size)
        if not 0 <= start * 2352 <= end <= path.stat().st_size or end % 2352:
            raise ValueError(f'Strider disc track {n:02}: invalid sector boundaries')
        with path.open('rb') as stream:
            stream.seek(start * 2352)
            data = bytes(pregap * 2352) + stream.read(end - start * 2352)
        if len(data) != pin['bytes'] or hashlib.sha256(data).hexdigest() != pin['sha256']:
            raise ValueError(f'Strider disc track {n:02}: content differs from the pinned disc')
        if n in wanted:
            result[n] = data
    return result


def disc_bins(disc, tracks):
    """Read CUE/BIN, ZIP or 7z; authenticate all 30 complete logical tracks.

    INDEX 00 pregaps belong to their own track, as in the reviewed split
    dump. Shared-image tracks are cut by the same convention. No persistent
    extraction cache can substitute for the supplied media.
    """
    disc = Path(disc)
    pins = json.loads(PINS.read_text(encoding='utf-8'))['tracks']
    if disc.suffix.lower() == '.cue':
        return read_tracks(disc, set(tracks), pins)
    if disc.suffix.lower() not in ('.zip', '.7z'):
        raise ValueError(f'{disc}: pass a CUE with its BIN files, or a ZIP/7z containing one CUE')
    with tempfile.TemporaryDirectory(prefix='strider-disc-') as temporary:
        root = Path(temporary)
        if disc.suffix.lower() == '.zip':
            with zipfile.ZipFile(disc) as archive:
                archive.extractall(root)
        else:
            from .media_tools import disc_tool
            subprocess.run([disc_tool('sevenzip'), 'x', '-y', f'-o{root}', str(disc)],
                           check=True, stdout=subprocess.DEVNULL)
        cues = [p for p in root.rglob('*') if p.suffix.lower() == '.cue']
        if len(cues) != 1:
            raise ValueError(f'{disc}: expected exactly one CUE; pass the intended CUE directly')
        return read_tracks(cues[0], set(tracks), pins)
