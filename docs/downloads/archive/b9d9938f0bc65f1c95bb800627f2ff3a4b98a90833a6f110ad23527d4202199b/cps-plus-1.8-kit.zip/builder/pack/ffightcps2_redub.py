"""Reconstruct the released English scenes from matching Japanese scene blocks."""
import hashlib
import json
from pathlib import Path
from .format import PackReader
from .build_ffightcps2_ex_arrange import track_name
BLOCK_FRAMES = 1378

def sha256(data):
    return hashlib.sha256(data).hexdigest()

def keystream(name, counterpart, length):
    return hashlib.shake_256(b"ffex2 keyed\0" + name.encode() + b"\0" + counterpart).digest(length)

def xor(a, b):
    return (int.from_bytes(a, 'big') ^ int.from_bytes(b, 'big')).to_bytes(len(a), 'big')

def source_tracks(path):
    reader = PackReader(path)
    try:
        if reader.crc_check() != (True, True):raise ValueError('source pack CRC differs')
        return {track_name(meta): reader.read_track(i) for i, meta in enumerate(reader.tracks)}
    finally:
        reader.close()

def rebuild_keyed(manifest: dict, payload: bytes, jp_source_pack: Path) -> dict[str, tuple[bytes, str]]:
    """{own track: (stream, its WAV's SHA-256)}: every block XORed with its counterpart's key and checked."""
    if manifest.get("schema") != 1 or manifest.get("block_frames") != BLOCK_FRAMES:
        raise ValueError("keyed manifest: unsupported schema or block size")
    jp = source_tracks(jp_source_pack)
    parts: dict[str, bytearray] = {}
    for item in manifest["items"]:
        track, k = item["name"].split("/")
        kind, source, base = item["counterpart"]["source"].split(":")
        if kind != "pack" or source != Path(jp_source_pack).stem:
            raise ValueError(f"{item['name']}: counterpart {item['counterpart']['source']} is not this pack's")
        off, length = item["counterpart"]["offset"], item["counterpart"]["length"]
        counterpart = jp[base][off:off + length]
        if len(counterpart) != length or item["length"] != length:
            raise ValueError(f"{item['name']}: the counterpart is shorter than the item")
        data = xor(payload[item["offset"]:item["offset"] + length], keystream(item["name"], counterpart, length))
        if sha256(data) != item["sha256"]:
            raise ValueError(f"{item['name']}: differs (second {int(k)} of {base}): wrong or damaged Japanese disc?")
        stream = parts.setdefault(track, bytearray())
        if len(stream) != off:
            raise ValueError(f"{item['name']}: blocks out of order")
        stream += data
    return {name: (bytes(stream), manifest["tracks"][name]) for name, stream in parts.items()}


def rebuild(folder, source):
    folder = Path(folder)
    return rebuild_keyed(json.loads((folder / 'english_pack.json').read_text()),
                         (folder / 'english_pack.bin').read_bytes(), Path(source))
