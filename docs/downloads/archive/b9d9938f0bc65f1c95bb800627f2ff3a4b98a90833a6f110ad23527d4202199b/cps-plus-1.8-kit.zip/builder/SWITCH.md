# The USF2 Remix pack: from the Switch game

Ultra Street Fighter II: The Final Challengers on Nintendo Switch carries
two scores: the arcade originals and a complete remixed soundtrack. This
pack is the remix, mapped onto the arcade music commands, so it plays in
Super Street Fighter II, Super Street Fighter II Turbo (with SSF2X), the
EX and Grand Master Challenge builds, and Hyper Street Fighter II. It holds
65 tracks. The select screen of Turbo, which USF2 does not score separately,
uses the remix's SSF2 select theme. The "Here comes a new challenger" sting
and HSF2's READY TO FIGHT cue stay as the arcade plays them.

## What you need

- **The game's .nsp or .xci**: a supported USA base game, title
  01007330027EE000. Extract ZIP/RAR wrappers first; the NSP/XCI itself is read
  directly. File order, padding and extra metadata may differ. The complete
  Program NCA must match a declared download/card identity, and the decrypted
  resource must match too. Update-only or modified Program images are not
  accepted. A separately bundled update is ignored, never applied.
- **Your prod.keys**. The builder hands its path to NSTool, which decrypts
  the game's files with it. The keys are read where they are, and never
  copied into the kit, the output or the packs.
- **Verified prebuilt helpers**, fetched on demand or supplied with
  `--tools-bundle` and `--offline` (see TOOLS.md). No Git, CMake or compiler
  is needed for this pack. NSTool and the fixed-point Opus decoder are pinned
  together; the kit never compiles or substitutes a fallback decoder.
- **About 4 GB of free space** while it runs. NSTool writes a temporary copy
  of the game's 2.9 GB program archive to extract the music, and the build
  deletes it afterwards.

Fill in `usf2_source` and `switch_prod_keys` in `discs.toml` and run
`make_packs.py` as usual, or build just this pack with
`python3 make_packs.py --only usf2-remix`.
Existing `usf2_nsp` configurations remain valid; `usf2_xci` is also an alias.
Specify one source. Both file types use the same recipe and produce the same
verified pack. The standalone command is:

```sh
python3 build_pack.py usf2-remix --source "USF2 USA.xci" --keys prod.keys
```

`--nsp` and `--xci` are aliases for `--source`.

## What "verified" means here

The game stores its music as Opus. The decoder is libopus built in fixed
point, with its processor-specific code turned off, so decoding is integer
arithmetic and every computer produces the same samples. That is what lets
the kit check your pack against one published hash, the same on a Mac, on
Windows and on Linux. A floating-point Opus decoder would not do this:
ffmpeg's, for one, rounds differently depending on the processor's vector
instructions.

Before decoding, the builder checks the Program archive and extracted regional
resource hashes. The outer NSP/XCI hash is recorded for provenance, so a
differently packaged copy with the same accepted contents works. A Program
identity failure means the contents differ; extraction failures preserve
NSTool's diagnostics, with long hexadecimal values redacted. The card variant
does not require a ticket, while the download copy uses its own ticket.
