# CPS+ — MiSTer installation

Run `python3 apply.py --list`, then build the soundtracks you want (see
`README.txt`; input-specific guides are under `builder/`). Copy everything inside
`out/mister/` to the root of your MiSTer SD card (`/media/fat/`), merging
with what is already there.

```
out/mister/
  _Arcade/
    _Arcade Patches/
      _Arrangements/
        _CPS+/           MRAs: USA editions at the root, regional
                         variants under _Japan/ _Asia/ _Europe/.  The
                         LEADING UNDERSCORE is required for MiSTer to show
                         each folder as an arcade group.  Every project from
                         this site lives under _Arcade Patches, so you can
                         find (or remove) all of it in one place.
    cores/
      jtcps1-cpsplus_20261009.rbf       CPS-1.0 core
      jtcps15-cpsplus.rbf      CPS-1.5 core
      jtcps2-cpsplus_20261101.rbf       CPS-2 core
  games/
    CPS+/                the audio packs you built (`<pack>.zip`)
```

Earlier CPS+ releases put the MRAs in `_Arcade/_CPS+`; delete that folder
when you copy the new ones over.

When updating, copy the generated cores, packs and launchers together.
Keep your arcade ROMs and saved settings. The builder verifies each pack
against the accepted hashes; an older pack needing a music-control correction
must be rebuilt. The shared builder can reuse packs that already match.

Only the MRAs whose packs you built are placed here, so everything in the
folder will load. The rest stay in `builder/mras/` and appear the next time
you run the builder with their pack built.

Keep the RBF filenames as they are. The MRAs name their core, and a renamed
core stops resolving. The stable CPS-2 MRA binding is `jtcps2-cpsplus`;
MiSTer selects its dated core automatically. This single CPS-2 core supports
both replacement music and the native expanded-memory games. Enhanced games
require 128 MiB SDRAM.

Your arcade ROM zips go where they always do (`games/mame/`,
`games/hbmame/`). The MRAs reference them by standard MAME names.

## Verifying a pack is active

Load a CPS+ MRA and check the core's OSD. The CPS+ audio section shows the
loaded pack.
