Night Warriors 2 · English translation
======================================

Version:  rc2 (2026-09-17)
Target:   MAME set 'vhunt2' (Vampire Hunter 2: Darkstalkers Revenge (Japan 970929))
Hardware: Capcom CPS-2
Patch by: Steve Gordon (https://x.com/strygo)
Website:  https://strygo.github.io/arcade-patches/

ABOUT THIS PROJECT

Vampire Hunter 2 is a Japan-only follow-up to the game the West knew as Night
Warriors: Darkstalkers' Revenge. It never came out in English. This patch
translates the entire game and gives it the name it should have had, Night
Warriors 2.

Where Capcom's own English exists, in the Western Night Warriors and Vampire
Savior and the PlayStation Darkstalkers 3, the patch uses it, as long as it
says what the Japanese says, so it reads like the official localization. The
rest gets a fresh translation, written to read naturally while staying true to
the original: the victory quotes, the boss exchanges, and every ending.

The Night Warriors 2 title screen isn't a fan mock-up. An unused Western title
was already sitting inside the original game, and the patch finishes it and
switches it on.

WHAT'S CHANGED

  - Night Warriors 2 title screen, finished from the unused Western title
    inside the original game
  - USA region presentation
  - Western character names on character select, route map, and fight HUD:
    Zabel → L.Raptor, Gallon → J.Talbain, Lei-Lei → Hsien-Ko, Phobos →
    Huitzil, Aulbath → Rikuo
  - All 225 post-fight quotes in English, using Capcom's own wording where it
    matches the Japanese
  - All boss dialogs and every ending translated
  - Route stage names and the staff roll in English
  - Capcom's misspelled "L.Rapter" name art corrected to L.Raptor
  - Oboro Bishamon's win plays his own victory music, as intended

MISTER SETUP

1. Copy the _Arcade/ folder from this download to the root of your
   MiSTer SD card (the MRA lands in _Arcade/_Arcade Patches/_Translations/), or copy
   "Night Warriors 2 (USA) [English Translation].mra" anywhere under _Arcade/.
2. Have the stock, unmodified romset at games/mame/vhunt2.zip
   (split MAME sets also need qsound.zip next to it).
3. You need Jotego's jtcps2 core; the standard MiSTer downloader /
   update_all installs it automatically.

The MRA references your original romset and applies the translation in
memory while the game loads. Nothing on your SD card is modified. The
translation keeps its own settings and saves under the name
'nwarr2en'.

LEGAL

This is a free, unofficial fan patch. It is not affiliated with or endorsed
by Capcom. All game titles, characters, and artwork remain the property of
their respective owners. You must own the game to use this patch. Do not
sell this patch or distribute it applied to a ROM image.
