Super Street Fighter II Turbo: Grand Master Challenge · Japan's Super Turbo, in English
=======================================================================================

Version:  rc1 (2026-09-10)
Target:   MAME set 'ssf2xj' (Super Street Fighter II X: Grand Master Challenge (Japan 940311))
Hardware: Capcom CPS-2
Patch by: Steve Gordon (https://x.com/strygo)
Website:  https://strygo.github.io/arcade-patches/

ABOUT THIS PROJECT

Super Turbo came in two versions. Japan got Super Street Fighter II X, the one
competitive players swear by. The rest of the world got a slightly different
game: it plays differently, the continue screen is bare, most of the win
quotes are gone, the endings are shorter, and Akuma's story is missing.
Japan's version, of course, was in Japanese.

Grand Master Challenge is Japan's game in English. The fighting is untouched.
Everything you read is new: all 136 win quotes, the strategy tips on the
continue screen, the full endings, and Akuma's dialogue, translated fresh from
the Japanese with Capcom's own English as the style guide.

It runs anywhere Super Turbo does: MAME, HBMAME, MiSTer, or a real CPS-2
board. The patch keeps the ROM's original sizes and key, so it drops in over
the stock Japanese set.

WHAT'S CHANGED

  - Japan's game, exactly as it plays in Japan
  - The Grand Master Challenge title, and a US region
  - Balrog, Vega, M. Bison and Akuma, the names you know
  - All 136 win quotes in English
  - The continue screen's strategy tips in English
  - Every ending in full, in English, including Akuma's
  - Akuma's intro dialogue, cut from the export game

HOW TO APPLY (recommended)

    python3 apply.py /path/to/ssf2xj.zip

This verifies every file, applies the IPS patches, and writes
ssf2xj_patched.zip. Rename it to ssf2xj.zip and place it ahead of
the stock set in your MAME rompath. MAME reports checksum warnings for
the patched program ROMs; that is expected and the game runs normally.

HOW TO APPLY (any IPS patcher)

Extract ssf2xj.zip, apply each file in ips/ to the ROM file of the
same name (Flips, Lunar IPS, or any IPS tool), then re-zip everything
as ssf2xj.zip.

CHANGED FILES

    sfx.13m  (2.0 MB)  CRC32 cf94d275 -> 75dac0eb
    sfx.15m  (2.0 MB)  CRC32 5eb703af -> 84dcc039
    sfx.17m  (2.0 MB)  CRC32 ffa60e0f -> bfcaf206
    sfx.19m  (2.0 MB)  CRC32 34e825c5 -> 13a55fd3
    sfxj.03d  (512 KB)  CRC32 50b52b37 -> deacc6a6
    sfxj.04a  (512 KB)  CRC32 af7767b4 -> 86104c3a
    sfxj.08  (512 KB)  CRC32 2de76f10 -> ea0d1d90

All other files in the set are unmodified.

HBMAME

This restoration also has an HBMAME set definition, 'ssf2tgmc'
(the definition ships with the project; an upstream HBMAME
submission is pending). To build the set zip from your own dump:

    python3 apply.py /path/to/ssf2xj.zip --hbmame

This writes ssf2tgmc.zip (the patched ROMs under their HBMAME
names). Put it in HBMAME's roms/ folder next to your stock
ssf2xj.zip. Unlike the MAME route above, the set loads with no
checksum warnings: HBMAME's set definition carries the patched
checksums.

LEGAL

This is a free, unofficial fan patch. It is not affiliated with or endorsed
by Capcom. All game titles, characters, and artwork remain the property of
their respective owners. You must own the game to use this patch. Do not
sell this patch or distribute it applied to a ROM image.
