"""Install the prepared English boss voices into the existing native ROM layout."""
import argparse
from copy import deepcopy
import hashlib
import itertools
import json
from pathlib import Path
import struct
import subprocess
import boss_scene_binary as BB
import pce_sfx as PS
ASM = Path(__file__).resolve().parents[1] / 'asm/boss_voice_select.s'
RANGES = ((38656, 125952), (135168, 203776))
ENTRY = 2094080

def sha(b):
    return hashlib.sha256(b).hexdigest()

def allocate(sizes):
    for bits in itertools.product((0, 1), repeat=len(sizes)):
        used = [sum((n for n, b in zip(sizes, bits) if b == k)) for k in range(2)]
        if all((n <= hi - lo for n, (lo, hi) in zip(used, RANGES))):
            cursor = [lo for lo, hi in RANGES]
            out = []
            for size, k in zip(sizes, bits):
                out.append(cursor[k])
                cursor[k] += size
            return out
    raise ValueError('native voices do not fit without replacing a protected phrase')

def install(a):
    meta = json.loads((a.build / 'build.json').read_text())
    assets = json.loads((a.voices / 'voices.json').read_text())
    voices = assets['voices']
    if [r['id'] for r in voices] != list(BB.IDS):
        raise ValueError('need the eight ordered boss assets')
    encoded = []
    for r in voices:
        data = (a.voices / r['native_file']).read_bytes()
        if len(data) != r['native_bytes'] or sha(data) != r['native_sha256']:
            raise ValueError('voice bytes changed')
        encoded.append(data)
    starts = allocate([len(b) for b in encoded])
    a.out.mkdir(parents=True, exist_ok=False)
    rep = deepcopy(meta)
    for machine, spec in meta['sets'].items():
        files = {n: (a.build / machine / n).read_bytes() for n in spec['files']}
        if any((sha(b) != spec['files'][n] for n, b in files.items())):
            raise ValueError('input ROM changed')
        sound_name = '09.12b' if machine == 'striderua' else 'sth_09.12a'
        z = bytearray(files[sound_name])
        sample_names = PS.SAMPLE_MEMBERS[machine]
        o = bytearray(b''.join((files[n] for n in sample_names)))
        original = bytes(o)
        if z[PS.Z80_COUNT] != 127 or int.from_bytes(z[PS.Z80_TABLE_OP:PS.Z80_TABLE_OP + 2], 'little') != PS.Z80_TABLE:
            raise ValueError('native extended-phrase driver is missing')
        patches = []
        for index, (row, data, start) in enumerate(zip(voices, encoded, starts)):
            phrase = 64 + index
            stop = start + len(data) - 1
            if not any((lo <= start <= stop < hi for lo, hi in RANGES)):
                raise ValueError('allocation escapes the former intro data')
            alias = phrase % PS.STOCK_PHRASES
            if o[phrase * 8:phrase * 8 + 8] != original[alias * 8:alias * 8 + 8] or z[PS.Z80_TABLE + phrase] != z[PS.Z80_TABLE + alias]:
                raise ValueError('English cue was already assigned')
            o[start:stop + 1] = data
            o[phrase * 8:phrase * 8 + 8] = start.to_bytes(3, 'big') + stop.to_bytes(3, 'big') + b'\x00\x00'
            before = z[PS.Z80_TABLE + phrase]
            z[PS.Z80_TABLE + phrase] = 16
            patches.append(dict(id=row['id'], command=hex(192 + index), phrase=phrase, start=start, stop=stop, adpcm_sha256=row['native_sha256'], seconds=row['native_seconds'], old_header=original[phrase * 8:phrase * 8 + 8].hex(), old_voice_byte=before, new_voice_byte=16))
        for p in list(range(12)) + [19, 20, 21, 26, 27, 28] + list(range(48, 52)):
            header = original[p * 8:p * 8 + 8]
            if header != o[p * 8:p * 8 + 8]:
                raise ValueError('protected sample header changed')
            lo = int.from_bytes(header[:3], 'big')
            hi = int.from_bytes(header[3:6], 'big')
            if original[lo:hi + 1] != o[lo:hi + 1]:
                raise ValueError('protected stock/effect sample changed')
        source_p6 = files['strex_p6.bin']
        raw = bytearray((source_p6[i ^ 1] for i in range(len(source_p6))))
        BB.scenes(raw)
        needle = bytes.fromhex('08390000001fffff670833ea000200fff9e0')
        hits = [n for n in range(0, len(raw) - len(needle), 2) if raw[n:n + len(needle)] == needle]
        if len(hits) != 1:
            raise ValueError('unknown boss-voice selector')
        code = a.out / (machine + '-voice-select.bin')
        subprocess.run([str(a.vasm), '-Fbin', '-m68000', '-quiet', '-DREGION_EN=' + str(int(machine == 'striderua')), '-o', str(code), str(ASM)], check=True)
        helper = code.read_bytes()
        off = ENTRY - 1048576
        if len(helper) > 128 or raw[off:off + len(helper)] != b'\xff' * len(helper):
            raise ValueError('voice helper allocation occupied')
        raw[off:off + len(helper)] = helper
        at = hits[0]
        raw[at:at + len(needle)] = bytes.fromhex('4eb9') + ENTRY.to_bytes(4, 'big') + bytes.fromhex('4e71') * 6
        files['strex_p6.bin'] = bytes((raw[i ^ 1] for i in range(len(raw))))
        files[sound_name] = bytes(z)
        for name, b in zip(sample_names, PS.split_oki(o)):
            files[name] = b
        target = a.out / machine
        target.mkdir()
        for n, b in files.items():
            (target / n).write_bytes(b)
        rep['sets'][machine]['files'] = {n: sha(b) for n, b in files.items()}
        rep['sets'][machine]['boss_voice'] = dict(native_phrases=patches, selector_at=1048576 + at, selector_before=needle.hex(), helper_at=ENTRY, helper_bytes=len(helper), helper_sha256=sha(helper), asset_receipt_sha256=sha((a.voices / 'voices.json').read_bytes()), original_samples_sha256=sha(original), reclaimed_ranges=[list(r) for r in RANGES])
        print(machine, 'native English voices installed; protected samples intact', flush=True)
    (a.out / 'build.json').write_text(json.dumps(rep, indent=2) + '\n')

def main():
    import sys
    if sys.argv[1:] == ['--self-test']:
        sizes = [18184, 16017, 22432, 15156, 26195, 16064, 11601, 27907]
        starts = allocate(sizes)
        spans = sorted(((s, s + n) for s, n in zip(starts, sizes)))
        assert all((any((lo <= s < e <= hi for lo, hi in RANGES)) for s, e in spans))
        assert all((a[1] <= b[0] for a, b in zip(spans, spans[1:])))
        try:
            allocate([sum((hi - lo for lo, hi in RANGES)) + 1])
        except ValueError:
            pass
        else:
            raise AssertionError('protected phrases could be overwritten')
        print('Native boss allocation self-test PASS: bounded, disjoint; overflow rejected')
        return
    p = argparse.ArgumentParser(description=__doc__)
    for n in ('build', 'voices', 'vasm', 'out'):
        p.add_argument('--' + n, type=Path, required=True)
    install(p.parse_args())
if __name__ == '__main__':
    main()
