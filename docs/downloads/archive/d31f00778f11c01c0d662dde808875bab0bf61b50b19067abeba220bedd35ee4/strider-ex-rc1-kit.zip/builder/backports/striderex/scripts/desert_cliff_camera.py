"""Use the existing fractional follow only for desert wall descents."""
import argparse
from copy import deepcopy
import json
from pathlib import Path
import subprocess
import sys
from boss_voice_gate import inventory, sha
BASE = 2050048
HOOK = 2048224
SMOOTH = 2048132
ASM = Path(__file__).resolve().parents[1] / 'asm/desert_cliff_camera.s'
DOWN_BODY = bytes.fromhex('3228003892403001615e4480d0a8000c4840b06800306f4248402140000c7a00')
NATIVE_SHAPE = bytes.fromhex('4ef9')

def model(bank):
    at = HOOK - 1048576
    if bank[SMOOTH - 1048576:SMOOTH - 1048576 + len(DOWN_BODY)] != DOWN_BODY:
        raise ValueError('supported fractional downward-follow body required')
    if bank[at:at + 2] != NATIVE_SHAPE or bank[at + 6:at + 8] != NATIVE_SHAPE:
        raise ValueError('supported desert native-down fallback required')
    target = int.from_bytes(bank[at + 2:at + 6], 'big')
    if target not in (123488, 122792):
        raise ValueError('native downward scroll destination differs')
    return target

def patch(raw, helper):
    bank = bytearray((raw[i ^ 1] for i in range(len(raw))))
    target = model(bank)
    off = BASE - 1048576
    if not helper or len(helper) > 2048 or bank[off:off + len(helper)] != b'\xff' * len(helper):
        raise ValueError('cliff camera allocation occupied or oversized')
    at = HOOK - 1048576
    before = bytes(bank[at:at + 6])
    after = b'N\xf9' + BASE.to_bytes(4, 'big')
    bank[at:at + 6] = after
    bank[off:off + len(helper)] = helper
    return (bytes((bank[i ^ 1] for i in range(len(bank)))), dict(address=HOOK, before=before.hex(), after=after.hex(), helper_at=BASE, helper_bytes=len(helper), helper_sha256=sha(helper), native_down=target, smooth_down=SMOOTH, only_wall_state=4, up_keeps_native_follow=True, idle_wall_settle_uses_fractional_follow=True, slope_path_instructions_unchanged=True))

def audit(control, build):
    cm, old = inventory(control)
    meta, new = inventory(build)
    if old.keys() != new.keys():
        raise ValueError('regional set inventory differs')
    for machine, files in old.items():
        spec = meta['sets'][machine]['desert_cliff_camera']
        raw = new[machine]['strex_p6.bin']
        bank = bytes((raw[i ^ 1] for i in range(len(raw))))
        change = spec['change']
        helper = bank[BASE - 1048576:BASE - 1048576 + change['helper_bytes']]
        result, report = patch(files['strex_p6.bin'], helper)
        if new[machine] != dict(files, **{'strex_p6.bin': result}) or report != change:
            raise ValueError('unexpected cliff camera ROM change')
        if spec['source_files'] != cm['sets'][machine]['files']:
            raise ValueError('cliff camera source inventory differs')
    return meta

def main():
    if sys.argv[1:] == ['--self-test']:
        try:
            model(bytes(1048576))
        except ValueError:
            pass
        else:
            raise AssertionError('foreign camera accepted')
        print('Cliff camera guards PASS: exact existing smooth body and fallback required')
        return
    p = argparse.ArgumentParser(description=__doc__)
    for name in ('build', 'vasm', 'out'):
        p.add_argument('--' + name, type=Path, required=True)
    a = p.parse_args()
    meta, old = inventory(a.build)
    rep = deepcopy(meta)
    a.out.mkdir(parents=True, exist_ok=False)
    for machine, files in old.items():
        raw = files['strex_p6.bin']
        bank = bytes((raw[i ^ 1] for i in range(len(raw))))
        target = model(bank)
        src = a.out / (machine + '.s')
        src.write_text(f'SMOOTH_DOWN equ ${SMOOTH:X}\nNATIVE_DOWN equ ${target:X}\n' + ASM.read_text())
        binary = src.with_suffix('.bin')
        subprocess.run([str(a.vasm), '-Fbin', '-m68000', '-quiet', '-o', str(binary), str(src)], check=True)
        data, change = patch(raw, binary.read_bytes())
        result = dict(files, **{'strex_p6.bin': data})
        dest = a.out / machine
        dest.mkdir()
        for name, data in result.items():
            (dest / name).write_bytes(data)
        rep['sets'][machine]['desert_cliff_camera'] = dict(change=change, source_files=meta['sets'][machine]['files'], producer_sha256=sha(Path(__file__).read_bytes()), assembly_sha256=sha(ASM.read_bytes()))
        rep['sets'][machine]['files'] = {n: sha(b) for n, b in result.items()}
    (a.out / 'build.json').write_text(json.dumps(rep, indent=2) + '\n')
    audit(a.build, a.out)
    print('Desert downward wall camera uses existing fractional follow; slope instructions retained')
if __name__ == '__main__':
    main()
