"""Make flat desert handholds climbable and keep low pole releases above ground."""
import argparse
from copy import deepcopy
import json
from pathlib import Path
import struct
import subprocess
import sys
import desert_ex as D
import desert_slopes as S
import respawn_fix as R
import desert_grip_fix as F
from boss_voice_gate import inventory, sha
ENTRY = 2052096
ASM = Path(__file__).resolve().parents[1] / 'asm/desert_climb.s'
BEAMS = ((840, 936, 1232), (1248, 1344, 1232), (1632, 1728, 1232), (1896, 1992, 1232), (2520, 2616, 1232), (2277, 2472, 1328), (2664, 2859, 1328))

def player_table(image):
    pattern = bytes.fromhex('700010280003227b00084e916000')
    hits = [a for a in range(65536, 73728, 2) if image[a:a + len(pattern)] == pattern]
    if len(hits) != 1:
        raise ValueError('native player state dispatch differs')
    table = hits[0] + 16
    wall, ceiling = struct.unpack_from('>II', image, table + 4)
    if image[wall:wall + 4] != bytes.fromhex('4a2d0e76') or image[ceiling:ceiling + 4] != bytes.fromhex('4a2d0e76'):
        raise ValueError('native wall/ceiling handlers differ')
    return (table, wall, ceiling)

def corners(image, bank):
    """Extend just the existing end walls eight pixels above the beam."""
    rd = S.reader(image, bank)
    sets = D.collision_sets(image)
    lr = S.layer_record(image, 5, 0)
    grid = int.from_bytes(rd(lr + 2, 4), 'big')
    secs = int.from_bytes(rd(lr + 6, 4), 'big')
    result = {}
    for left, right, top in BEAMS:
        for x, key in ((left, 'D'), (right - 1, 'C')):
            cx = x // 32
            wr = top // 32
            g = rd(grid + wr // 8 * 32 + cx // 12)[0]
            ent = rd(secs + 384 * g + 4 * (wr % 8 * 12 + cx % 12), 4)
            code = int.from_bytes(ent[:2], 'big') & 16383
            flip = ent[3] >> 5 & 3
            if code >> 8 != 5 or flip != 3:
                raise ValueError('flat beam is outside reserved collision page')
            pg, ty, _, _, recs = sets[key]
            pages = rd(pg, 32)
            page = pages[D.DZ_SLOT]
            value = rd(ty + (page - 1) * 256 + (code & 255))[0]
            if value < 32:
                raise ValueError('beam end has no sparse wall record')
            for slot, p in enumerate(pages):
                if slot != D.DZ_SLOT and p and (value in rd(ty + (p - 1) * 256, 256)):
                    raise ValueError('beam end shares an original arcade collision record')
            at = recs + (value - 32) * 33
            old = rd(at, 33)
            nz = [i for i, v in enumerate(old[1:]) if v]
            if not nz or old[0] != 0:
                raise ValueError('flat beam end profile differs')
            if nz[0] != 15:
                continue
            new = bytearray(old)
            new[0] = 1 if key == 'D' else 2
            for y in range(16, 24):
                new[1 + y] = max(new[1 + y], old[16])
            result[at] = (old, bytes(new))
    return result

def patch(image, bank, helper):
    image = bytearray(image)
    bank = bytearray(bank)
    changes = []
    table, wall, ceiling = player_table(image)

    def write(a, old, new):
        target, offset = (bank, a - 1048576) if a >= 1048576 else (image, a)
        if target[offset:offset + len(old)] != old:
            raise ValueError('climb source bytes differ')
        target[offset:offset + len(new)] = new
        changes.append(dict(address=a, before=old.hex(), after=new.hex()))
    for at, (old, new) in corners(image, bank).items():
        write(at, old, new)
    write(table + 8, struct.pack('>I', ceiling), struct.pack('>I', ENTRY))
    write(table + 4, struct.pack('>I', wall), struct.pack('>I', ENTRY + 6))
    off = ENTRY - 1048576
    if not helper or len(helper) > 4096 or bank[off:off + len(helper)] != b'\xff' * len(helper):
        raise ValueError('desert climb allocation occupied or oversized')
    if any((helper[a:a + 2] != b'N\xf9' for a in (0, 6))):
        raise ValueError('climb entry offsets differ')
    bank[off:off + len(helper)] = helper
    return (image, bank, dict(changes=changes, helper_at=ENTRY, helper_bytes=len(helper), helper_sha256=sha(helper), beams=BEAMS, corner_depth=8, pole_release_floor=1599, up_uses_native_corner_transition=True))

def audit(control, build):
    cm, old = inventory(control)
    meta, new = inventory(build)
    for m, f in old.items():
        spec = meta['sets'][m]['desert_climb']
        p = new[m]['strex_p6.bin']
        b = bytes((p[i ^ 1] for i in range(len(p))))
        h = b[ENTRY - 1048576:ENTRY - 1048576 + spec['helper_bytes']]
        ob = f['strex_p6.bin']
        ob = bytes((ob[i ^ 1] for i in range(len(ob))))
        im, expected, report = patch(R.compose(f, R.SETS[m]), ob, h)
        nf = dict(f, **R.decompose(im, R.SETS[m], {n: len(f[n]) for n, _, _ in R.SETS[m]}))
        nf['strex_p6.bin'] = bytes((expected[i ^ 1] for i in range(len(expected))))
        if nf != new[m] or report['changes'] != spec['changes'] or sha(h) != spec['helper_sha256'] or (spec['source_files'] != cm['sets'][m]['files']):
            raise ValueError('unexpected climb ROM changes')
    return meta

def main():
    if sys.argv[1:] == ['--self-test']:
        try:
            player_table(bytes(131072))
        except ValueError:
            pass
        else:
            raise AssertionError('foreign player handler accepted')
        print('Desert climb source guards PASS')
        return
    p = argparse.ArgumentParser(description=__doc__)
    for n in ('build', 'vasm', 'out'):
        p.add_argument('--' + n, type=Path, required=True)
    a = p.parse_args()
    meta, files = inventory(a.build)
    rep = deepcopy(meta)
    a.out.mkdir(parents=True, exist_ok=False)
    for m, f in files.items():
        im = R.compose(f, R.SETS[m])
        table, wall, ceiling = player_table(im)
        src = a.out / (m + '.s')
        data = ' dc.w ' + ','.join((str(v) for left, right, top in BEAMS for v in (left, right, top - 34))) + '\n'
        src.write_text(f'WALL equ ${wall:X}\nCEILING equ ${ceiling:X}\nBEAM_COUNT equ {len(BEAMS)}\n' + ASM.read_text() + data)
        binary = src.with_suffix('.bin')
        subprocess.run([str(a.vasm), '-Fbin', '-m68000', '-quiet', '-o', str(binary), str(src)], check=True)
        p6 = f['strex_p6.bin']
        b = bytes((p6[i ^ 1] for i in range(len(p6))))
        im, b, spec = patch(im, b, binary.read_bytes())
        f = dict(f, **R.decompose(im, R.SETS[m], {n: len(f[n]) for n, _, _ in R.SETS[m]}))
        f['strex_p6.bin'] = bytes((b[i ^ 1] for i in range(len(b))))
        d = a.out / m
        d.mkdir()
        for n, data in f.items():
            (d / n).write_bytes(data)
        spec['source_files'] = meta['sets'][m]['files']
        rep['sets'][m]['desert_climb'] = spec
        rep['sets'][m]['files'] = {n: sha(data) for n, data in f.items()}
    (a.out / 'build.json').write_text(json.dumps(rep, indent=2) + '\n')
    audit(a.build, a.out)
if __name__ == '__main__':
    main()
