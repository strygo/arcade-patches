"""Strider respawn layer fix: build patched program ROMs and gate them in MAME."""
import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from PIL import Image
ROOT = Path(__file__).resolve().parents[3]
ASM = ROOT / 'backports/striderex/asm/respawn_layers.s'
DEBUG_START = ROOT / 'backports/striderex/lua/arcade_debug_start.lua'
ROUTINE = bytes.fromhex('3b7c00008c74303c00014eb807de303c02004eb80e10303c03004eb80e10303c04004eb80e104eb9')
WAIT = bytes.fromhex('303c00014eb807de')
NOP = bytes.fromhex('4e71')
TASK_API = {1880: bytes.fromhex('48e7fffe4e404cdf7fff4e75'), 1942: bytes.fromhex('4e41'), 2014: bytes.fromhex('48e7fffe4e434cdf7fff4e75')}
SLOT = 192
REVEAL = 4
SETS = {'striderua': [('30.11f', 0, 'byte_even'), ('35.11h', 0, 'byte_odd'), ('31.12f', 262144, 'byte_even'), ('36.12h', 262144, 'byte_odd'), ('st-14.8h', 524288, 'word_swap')], 'striderjr': [('sthj_23.8f', 0, 'word_swap'), ('sthj_22.7f', 524288, 'word_swap')]}

def compose(files, layout):
    img = bytearray(1048576)
    for name, base, kind in layout:
        d = files[name]
        if kind == 'word_swap':
            img[base:base + len(d)] = bytes((b for i in range(0, len(d), 2) for b in (d[i + 1], d[i])))
        else:
            off = 0 if kind == 'byte_even' else 1
            img[base + off:base + off + 2 * len(d):2] = d
    return img

def decompose(img, layout, sizes):
    out = {}
    for name, base, kind in layout:
        n = sizes[name]
        if kind == 'word_swap':
            seg = img[base:base + n]
            out[name] = bytes((b for i in range(0, n, 2) for b in (seg[i + 1], seg[i])))
        else:
            off = 0 if kind == 'byte_even' else 1
            out[name] = bytes(img[base + off:base + off + 2 * n:2])
    return out

def jsr(addr):
    return bytes.fromhex('4eb9') + addr.to_bytes(4, 'big')

def sites(img):
    """The five respawn routines: (routine, SCROLL1-rebuild call, wait) offsets."""
    out, i = ([], img.find(ROUTINE))
    while i >= 0:
        call, wait = (i + 60, i + 78)
        if img[i + 56:i + 58] != bytes.fromhex('6100') or img[call:call + 2] != bytes.fromhex('4eb9') or img[wait:wait + 8] != WAIT:
            sys.exit(f'respawn routine at {i:#x} has an unexpected shape')
        out.append((i, call, wait))
        i = img.find(ROUTINE, i + 1)
    if len(out) != 5:
        sys.exit(f'{len(out)} respawn routines found, 5 expected (unsupported revision)')
    targets = {int.from_bytes(img[c + 2:c + 6], 'big') for _, c, _ in out}
    if len(targets) != 1:
        sys.exit('the respawn routines call different SCROLL1 rebuilds')
    return (out, targets.pop())

def assemble(vasm, work, scroll1):
    out, lst = (work / f'respawn_layers_{scroll1:x}.bin', work / f'respawn_layers_{scroll1:x}.lst')
    subprocess.run([str(vasm), '-Fbin', '-m68000', '-quiet', f'-DSCROLL1=${scroll1:X}', f'-DREVEAL={REVEAL}', f'-DSLOT=${SLOT:X}', '-L', str(lst), '-o', str(out), str(ASM)], check=True)
    syms = {}
    for line in lst.read_text().splitlines():
        f = line.split()
        if len(f) == 2 and f[1][:2] in ('A:', 'E:'):
            syms[f[0]] = int(f[1][2:], 16)
    return (out.read_bytes(), syms)

def patch_image(img, vasm, work):
    routines, scroll1 = sites(img)
    for addr, want in TASK_API.items():
        if img[addr:addr + len(want)] != want:
            sys.exit(f'task routine at {addr:#x} has an unexpected shape')
    code, syms = assemble(vasm, work, scroll1)
    base = syms['respawn_hold']
    if img[base:base + len(code)] != bytes([255]) * len(code):
        sys.exit(f'hook space at {base:#x} is not free')
    img[base:base + len(code)] = code
    for _, call, wait in routines:
        img[call:call + 6] = jsr(syms['respawn_hold'])
        img[wait:wait + 8] = jsr(syms['respawn_show']) + NOP
    return dict(hooks=f'{base:#x}', scroll1_rebuild=f'{scroll1:#x}', routines=[f'{r:#x}' for r, _, _ in routines])

def build(rom_dir, vasm, work):
    out = {}
    for name, layout in SETS.items():
        src = rom_dir / name
        files = {p.name: p.read_bytes() for p in src.iterdir() if p.is_file()}
        img = compose(files, layout)
        sizes = {n: len(files[n]) for n, _, _ in layout}
        assert decompose(img, layout, sizes) == {n: files[n] for n in sizes}
        for variant in ('stock', 'fixed'):
            d = work / variant / name
            d.mkdir(parents=True)
            for n, b in files.items():
                (d / n).write_bytes(b)
        out[name] = patch_image(img, vasm, work)
        for n, b in decompose(img, layout, sizes).items():
            (work / 'fixed' / name / n).write_bytes(b)
        out[name]['patched_files'] = {n: hashlib.sha256(b).hexdigest() for n, b in decompose(img, layout, sizes).items() if b != files[n]}
    return out
LUA = "\nlocal m=manager.machine\nlocal sp=m.devices[':maincpu'].spaces['program']\nlocal f=0\nlocal fh=io.open(os.getenv('REGLOG'),'w')\nlocal cur={}\nlocal screen=m.screens[':screen']\nlocal was_blank, window = false, 0\n_G.strex_regs=sp:install_write_tap(0x800100,0x800171,'regs',function(off,data,mask) cur[off]=data end)\nemu.register_frame_done(function()\n  f=f+1\n  -- every frame from each blackout's start for 48 frames, for the pixel checks\n  local blank=((cur[0x800166] or 0)&0x3e)==0\n  if blank and not was_blank and f>600 then window=48 end\n  was_blank=blank\n  if window>0 then window=window-1 screen:snapshot(string.format('%s/w_%05d.png',os.getenv('SHOTDIR'),f)) end\n  fh:write(string.format('%d\\t%04x\\t%04x\\t%04x\\t%04x\\t%d\\t%02x\\n',f,cur[0x800166] or 0,cur[0x80010c] or 0,\n    cur[0x800110] or 0,cur[0x800114] or 0,sp:read_u8(0xff0ca8),sp:read_u8(0xff0000+SLOT)))\nend)\ndofile(os.getenv('STREX_DEBUG_START'))\n"

def run(mame, roms, machine, stage, outdir, frames):
    outdir.mkdir(parents=True)
    (outdir / 'gate.lua').write_text(f'local SLOT={SLOT}\n' + LUA)
    env = dict(os.environ, SDL_VIDEODRIVER='dummy', SDL_AUDIODRIVER='dummy', REGLOG=str(outdir / 'regs.tsv'), SHOTDIR=str(outdir), STREX_DEBUG_START=str(DEBUG_START), STREX_STAGE=str(stage), STREX_AREA='0', STREX_END=str(frames), STREX_INPUTS=f'450-{frames}:P1_JOYSTICK_RIGHT', STREX_PREFIX=str(outdir / 'run'), STREX_SHOTS=os.environ.get('GATE_SHOTS', ''))
    cmd = [mame, machine, '-rompath', str(roms), '-nothrottle', '-video', 'none', '-sound', 'none', '-skip_gameinfo', '-noautosave', '-cfg_directory', str(outdir / 'cfg'), '-nvram_directory', str(outdir / 'nv'), '-snapshot_directory', str(outdir), '-autoboot_script', str(outdir / 'gate.lua')]
    p = subprocess.run(cmd, env=env, cwd=outdir, capture_output=True, text=True, timeout=900)
    (outdir / 'mame.log').write_text(p.stdout + p.stderr)
    if p.returncode:
        raise RuntimeError(f'{outdir}: MAME exit {p.returncode}')
    rows = []
    for line in (outdir / 'regs.tsv').read_text().splitlines():
        f = line.split('\t')
        rows.append(dict(frame=int(f[0]), layer=int(f[1], 16), s1=int(f[2], 16), s2=int(f[3], 16), s3=int(f[4], 16), lives=int(f[5]), slot=int(f[6], 16)))
    return rows

def enables(rows):
    """Each frame the layers come back on after a blackout, with the number of"""
    out = []
    for i in range(1, len(rows)):
        a, b = (rows[i - 1], rows[i])
        if blank(a['layer']) and (not blank(b['layer'])) and (b['frame'] > 600):
            seq = rows[i:i + 14]
            jumps = sum((1 for x, y in zip(seq, seq[1:]) for k in ('s1', 's2', 's3') if abs((y[k] - x[k] + 32768) % 65536 - 32768) >= 48))
            out.append(dict(frame=b['frame'], scroll_jumps_after=jumps))
    return out

def hidden(layer):
    """Nothing shows: no scroll layer enabled and no order slot selects the sprites."""
    return layer & 62 == 0 and all((layer >> b & 3 for b in (6, 8, 10, 12)))

def blank(layer):
    """No scroll layer shows (stock blackouts write 0, the fix's hold writes HIDE)."""
    return layer & 62 == 0

def pixels(path):
    return Image.open(path).convert('RGB').tobytes()

def pixel_check(stock_dir, fixed_dir, held):
    """Over every captured blackout window: a held frame shows one flat color"""
    held, bad, n = (set(held), [], 0)
    for fp in sorted(fixed_dir.glob('w_*.png')):
        frame = int(fp.stem[2:])
        sp = stock_dir / fp.name
        img = pixels(fp)
        n += 1
        if frame in held:
            if len(set((img[i:i + 3] for i in range(0, len(img), 3)))) != 1:
                bad.append(dict(frame=frame, problem='held frame shows something'))
        elif not sp.exists() or pixels(sp) != img:
            bad.append(dict(frame=frame, problem='differs from stock'))
    return (n, bad)

def res_layer(rows, frame):
    return next((r['layer'] for r in rows if r['frame'] == frame))

def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('--rom-dir', type=Path, required=True, help='directory with striderua/ and striderjr/ file dirs')
    p.add_argument('--vasm', type=Path, required=True)
    p.add_argument('--workdir', type=Path, required=True)
    p.add_argument('--mame', default='mame')
    p.add_argument('--frames', type=int, default=4200)
    p.add_argument('--stages', default='0,1,2,3,4')
    p.add_argument('--reveal', type=int, default=REVEAL, help='frames the reveal task waits')
    a = p.parse_args()
    globals()['REVEAL'] = a.reveal
    work = a.workdir.resolve()
    work.mkdir(parents=True, exist_ok=False)
    sites = build(a.rom_dir.resolve(), a.vasm, work)
    jobs = [(m, s, v) for m in SETS for s in map(int, a.stages.split(',')) for v in ('stock', 'fixed')]
    with ThreadPoolExecutor(8) as ex:
        res = dict(zip(jobs, ex.map(lambda j: run(a.mame, work / j[2], j[0], j[1], work / 'runs' / f'{j[0]}_s{j[1]}_{j[2]}', a.frames), jobs)))
    report, ok = (dict(sites=sites, cases=[]), True)
    for m in SETS:
        for s in map(int, a.stages.split(',')):
            st, fx = (enables(res[m, s, 'stock']), enables(res[m, s, 'fixed']))
            stock_bad = [e for e in st if e['scroll_jumps_after']]
            fixed_bad = [e for e in fx if e['scroll_jumps_after']]
            case = dict(machine=m, stage=s, stock=st, fixed=fx, stock_defects=len(stock_bad), fixed_defects=len(fixed_bad))
            sr, fr = (res[m, s, 'stock'], res[m, s, 'fixed'])
            other = [x['frame'] for x, y in zip(sr, fr) if (x['s1'], x['s2'], x['s3'], x['lives']) != (y['s1'], y['s2'], y['s3'], y['lives'])]
            held = [x['frame'] for x, y in zip(sr, fr) if x['layer'] != y['layer']]
            bad_held = [f for f in held if not hidden(res_layer(fr, f))]
            slot_used = [x['frame'] for x in sr if x['slot']]
            shots, pix_bad = pixel_check(work / 'runs' / f'{m}_s{s}_stock', work / 'runs' / f'{m}_s{s}_fixed', held)
            case.update(diverged_at=other[0] if other else None, held_frames=len(held), held_while_not_off=bad_held[:5], stock_slot_used=slot_used[:5], pixel_frames=shots, pixel_failures=pix_bad[:5])
            case['passed'] = bool(stock_bad) and (not fixed_bad) and (len(fx) == len(st)) and (not other) and (not bad_held) and shots and (not pix_bad) and (not slot_used)
            ok &= case['passed']
            report['cases'].append(case)
            print(m, s, 'stock defects', len(stock_bad), 'fixed defects', len(fixed_bad), 'enables', len(st), len(fx), 'held', len(held), 'diverged', case['diverged_at'], 'pixel frames', shots, 'pixel failures', len(pix_bad), 'PASS' if case['passed'] else 'FAIL')
    report['passed'] = ok
    (work / 'report.json').write_text(json.dumps(report, indent=1) + '\n')
    print('PASS' if ok else 'FAIL')
    return 0 if ok else 1
if __name__ == '__main__':
    sys.exit(main())
