"""Let the CPS+ clear fanfare finish before the regular bonus screen fades."""
import argparse
from copy import deepcopy
import json
from pathlib import Path
import subprocess
import sys
import respawn_fix as R
from boss_voice_gate import inventory, sha
BASE = 2051072
NATIVE_FRAMES = 200
PACK_FRAMES = 580
STORE = bytes.fromhex('3b7c00c88c1a')
HELPER = bytes.fromhex('3b7c00c88c1a08390000001fffff67063b7c02448c1a4e75')
ASM = Path(__file__).resolve().parents[1] / 'asm/clear_music_timing.s'

def model(image):
    entries = [a for a in range(47104, 49920, 2) if image[a:a + 10] == bytes.fromhex('4e714e714eb9001f0000')]
    if len(entries) != 5:
        raise ValueError('five installed native clear entries required')
    shift = entries[0] - 48630
    sites = [a + shift for a in (48816, 49044, 49272, 49500)]
    tail = bytes.fromhex('303c00014eb807de536d8c1a66ee')
    for a in sites:
        if image[a:a + 6] != STORE or image[a + 6:a + 8] != b'a\x00' or image[a + 10:a + 24] != tail:
            raise ValueError('regular clear timer loop differs')
        target = a + 8 + int.from_bytes(image[a + 8:a + 10], 'big', signed=True)
        if target != 49902 + shift:
            raise ValueError('regular clear render target differs')
    moon = 49792 + shift
    if image[moon:moon + 6] != bytes.fromhex('3b7c01808c1a'):
        raise ValueError('native Third Moon timer differs')
    return sites

def patch(image, bank, helper):
    sites = model(image)
    if helper != HELPER:
        raise ValueError('CPS+ flag/timer helper differs')
    off = BASE - 1048576
    if bank[off:off + len(helper)] != b'\xff' * len(helper):
        raise ValueError('clear music allocation occupied')
    image, bank = (bytearray(image), bytearray(bank))
    hooks = []
    for a in sites:
        after = R.jsr(BASE)
        hooks.append(dict(address=a, before=STORE.hex(), after=after.hex()))
        image[a:a + 6] = after
    bank[off:off + len(helper)] = helper
    return (bytes(image), bytes(bank), dict(hooks=hooks, helper_at=BASE, helper_bytes=len(helper), helper_sha256=sha(helper), native_frames=NATIVE_FRAMES, cpsplus_frames=PACK_FRAMES, third_moon_frames=384, option_address=2097151, option_mask=1, no_new_ram=True))

def audit(control, build):
    cm, old = inventory(control)
    meta, new = inventory(build)
    if old.keys() != new.keys():
        raise ValueError('regional set inventory differs')
    for machine, files in old.items():
        spec = meta['sets'][machine]['clear_music_timing']
        raw = new[machine]['strex_p6.bin']
        bank = bytes((raw[i ^ 1] for i in range(len(raw))))
        image = R.compose(files, R.SETS[machine])
        ob = files['strex_p6.bin']
        ob = bytes((ob[i ^ 1] for i in range(len(ob))))
        helper = bank[BASE - 1048576:BASE - 1048576 + len(HELPER)]
        im, expected, report = patch(image, ob, helper)
        nf = dict(files, **R.decompose(im, R.SETS[machine], {n: len(files[n]) for n, _, _ in R.SETS[machine]}))
        nf['strex_p6.bin'] = bytes((expected[i ^ 1] for i in range(len(expected))))
        if nf != new[machine] or report != spec['change']:
            raise ValueError('unexpected clear music ROM change')
        if spec['source_files'] != cm['sets'][machine]['files']:
            raise ValueError('clear music source inventory differs')
    return meta

def main():
    if sys.argv[1:] == ['--self-test']:
        try:
            model(bytes(1048576))
        except ValueError:
            pass
        else:
            raise AssertionError('foreign clear code accepted')
        print('Clear music guards PASS')
        return
    p = argparse.ArgumentParser(description=__doc__)
    for n in ('build', 'vasm', 'out'):
        p.add_argument('--' + n, type=Path, required=True)
    a = p.parse_args()
    meta, old = inventory(a.build)
    rep = deepcopy(meta)
    a.out.mkdir(parents=True, exist_ok=False)
    binary = a.out / 'clear_music.bin'
    subprocess.run([str(a.vasm), '-Fbin', '-m68000', '-quiet', '-o', str(binary), str(ASM)], check=True)
    helper = binary.read_bytes()
    for machine, files in old.items():
        image = R.compose(files, R.SETS[machine])
        raw = files['strex_p6.bin']
        bank = bytes((raw[i ^ 1] for i in range(len(raw))))
        image, bank, change = patch(image, bank, helper)
        result = dict(files, **R.decompose(image, R.SETS[machine], {n: len(files[n]) for n, _, _ in R.SETS[machine]}))
        result['strex_p6.bin'] = bytes((bank[i ^ 1] for i in range(len(bank))))
        dest = a.out / machine
        dest.mkdir()
        for n, data in result.items():
            (dest / n).write_bytes(data)
        rep['sets'][machine]['clear_music_timing'] = dict(change=change, source_files=meta['sets'][machine]['files'], producer_sha256=sha(Path(__file__).read_bytes()), assembly_sha256=sha(ASM.read_bytes()))
        rep['sets'][machine]['files'] = {n: sha(b) for n, b in result.items()}
    (a.out / 'build.json').write_text(json.dumps(rep, indent=2) + '\n')
    audit(a.build, a.out)
    print('CPS+ regular clear hold 580 frames; native 200 and Third Moon 384 retained')
if __name__ == '__main__':
    main()
