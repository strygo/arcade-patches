"""Preserve the live Moon caption fade across the first gameplay palette load."""
import argparse
from copy import deepcopy
import json
from pathlib import Path
import subprocess
import sys
import respawn_fix as R
from boss_voice_gate import inventory, sha
BASE = 2051584
ASM = Path(__file__).resolve().parents[1] / 'asm/moon_caption.s'
CAMERA = bytes.fromhex('3b7c00b890203b7c00c8901e3b7c006490223b7c006090243b7c000090183b7c05e090163b7c0700901a3b7c0000901c')
DISPATCH = bytes.fromhex('7000102d8cb2d040303b00064efb0002')
AREA_SETUP = bytes.fromhex('2f084eb82d324eb82d404eb82d4e4eb82d5c4eb9')

def model(image):
    if image.count(CAMERA) != 1:
        raise ValueError('unique native Moon first-frame setup required')
    sites = [a + 18 for a in range(61440, 69632, 2) if image[a:a + len(AREA_SETUP)] == AREA_SETUP and image[a + 24:a + 28] == bytes.fromhex('205f4e75')]
    if len(sites) != 5:
        raise ValueError('five native regional area/palette setups required')
    at = sites[4]
    target = int.from_bytes(image[at + 2:at + 6], 'big')
    if image[target:target + 10] != bytes.fromhex('7000102d8cb2d040d040'):
        raise ValueError('native object palette loader differs')
    if image[51200:57344].count(DISPATCH) != 1:
        raise ValueError('native caption dispatcher differs')
    tab = image.index(DISPATCH, 51200, 57344) + len(DISPATCH)
    load = tab + int.from_bytes(image[tab + 8:tab + 10], 'big', signed=True)
    if image[load:load + 2] != b'!|' or image[load + 6:load + 8] != b'\x00\x1a':
        raise ValueError('Moon caption pointer load differs')
    record = int.from_bytes(image[load + 2:load + 6], 'big')
    if image[record:record + 8] != bytes.fromhex('000c000500010016'):
        raise ValueError('Moon caption grid/palette differs')
    return dict(hook=at, palette=target, caption=record)

def patch(image, bank, m, helper):
    off = BASE - 1048576
    if not helper or len(helper) > 512 or bank[off:off + len(helper)] != b'\xff' * len(helper):
        raise ValueError('Moon caption allocation occupied or oversized')
    image, bank = (bytearray(image), bytearray(bank))
    at = m['hook']
    before = bytes(image[at:at + 6])
    after = R.jsr(BASE)
    image[at:at + 6] = after
    bank[off:off + len(helper)] = helper
    return (bytes(image), bytes(bank), dict(address=at, before=before.hex(), after=after.hex(), helper_at=BASE, helper_bytes=len(helper), helper_sha256=sha(helper), native_palette=m['palette'], caption_record=m['caption'], live_palette=9519808, preserved_palette_bytes=32, no_new_ram=True))

def audit(control, build):
    cm, old = inventory(control)
    meta, new = inventory(build)
    if old.keys() != new.keys():
        raise ValueError('regional inventory differs')
    for machine, f in old.items():
        image = R.compose(f, R.SETS[machine])
        m = model(image)
        spec = meta['sets'][machine]['moon_caption']
        raw = new[machine]['strex_p6.bin']
        bank = bytes((raw[i ^ 1] for i in range(len(raw))))
        helper = bank[BASE - 1048576:BASE - 1048576 + spec['change']['helper_bytes']]
        ob = f['strex_p6.bin']
        ob = bytes((ob[i ^ 1] for i in range(len(ob))))
        im, expected, report = patch(image, ob, m, helper)
        nf = dict(f, **R.decompose(im, R.SETS[machine], {n: len(f[n]) for n, _, _ in R.SETS[machine]}))
        nf['strex_p6.bin'] = bytes((expected[i ^ 1] for i in range(len(expected))))
        if nf != new[machine] or report != spec['change']:
            raise ValueError('unexpected Moon caption ROM change')
        if spec['source_files'] != cm['sets'][machine]['files']:
            raise ValueError('Moon caption source inventory differs')
    return meta

def main():
    if sys.argv[1:] == ['--self-test']:
        for bad in (b'', CAMERA * 2):
            try:
                model(bad)
            except ValueError:
                pass
            else:
                raise AssertionError('foreign Moon setup accepted')
        print('Moon caption guards PASS')
        return
    p = argparse.ArgumentParser(description=__doc__)
    for name in ('build', 'vasm', 'out'):
        p.add_argument('--' + name, type=Path, required=True)
    a = p.parse_args()
    meta, old = inventory(a.build)
    rep = deepcopy(meta)
    a.out.mkdir(parents=True, exist_ok=False)
    for machine, f in old.items():
        image = R.compose(f, R.SETS[machine])
        m = model(image)
        src = a.out / (machine + '.s')
        src.write_text(f"PAL equ ${m['palette']:X}\nCAPTION equ ${m['caption']:X}\n" + ASM.read_text())
        binary = src.with_suffix('.bin')
        subprocess.run([str(a.vasm), '-Fbin', '-m68000', '-quiet', '-o', str(binary), str(src)], check=True)
        raw = f['strex_p6.bin']
        bank = bytes((raw[i ^ 1] for i in range(len(raw))))
        image, bank, change = patch(image, bank, m, binary.read_bytes())
        result = dict(f, **R.decompose(image, R.SETS[machine], {n: len(f[n]) for n, _, _ in R.SETS[machine]}))
        result['strex_p6.bin'] = bytes((bank[i ^ 1] for i in range(len(bank))))
        dest = a.out / machine
        dest.mkdir()
        for n, data in result.items():
            (dest / n).write_bytes(data)
        rep['sets'][machine]['moon_caption'] = dict(change=change, source_files=meta['sets'][machine]['files'], producer_sha256=sha(Path(__file__).read_bytes()), assembly_sha256=sha(ASM.read_bytes()))
        rep['sets'][machine]['files'] = {n: sha(b) for n, b in result.items()}
    (a.out / 'build.json').write_text(json.dumps(rep, indent=2) + '\n')
    audit(a.build, a.out)
    print('Live Moon caption palette preserved across native gameplay setup')
if __name__ == '__main__':
    main()
