"""Install the approved native stage-clear presentation and numbered labels."""
import argparse
from copy import deepcopy
import json
from pathlib import Path
import struct
import subprocess
import sys
import respawn_fix as R
from boss_voice_gate import inventory, sha
BASE = 2031616
DIRECTORY = 2033664
ASM = Path(__file__).resolve().parents[1] / 'asm/stage_clear.s'

def model(image):
    first = bytes.fromhex('4eb80b3a4eb9')
    entries = [a for a in range(47104, 49920, 2) if image[a:a + 6] == first and image[a + 10:a + 16] == bytes.fromhex('1b7c00010a42')]
    if len(entries) != 5:
        raise ValueError('five stock clear entries required')
    shift = entries[0] - 48630

    def at(a):
        return a + shift

    def target(a):
        a = at(a)
        if image[a:a + 2] != b'N\xb9':
            raise ValueError('clear call shape differs')
        return int.from_bytes(image[a + 2:a + 6], 'big')
    if image[14282:14288] != bytes.fromhex('207c00003906'):
        raise ValueError('native text directory operand differs')
    records = []
    for label in (b'1STAGE', b'2STAGE', b'3STAGE', b'4STAGE', b'LAST STAGE'):
        positions = [i for i in range(len(image)) if image.startswith(label, i)]
        if len(positions) != 1:
            raise ValueError('bonus label not unique')
        start = positions[0] - 3
        end = image.index(0, start + 3) + 1
        records.append((start, bytes(image[start:end])))
    return dict(shift=shift, entries=entries, records=records, text_region=bytes(image[14598:18016]), constants=dict(AUX=target(48634), FILL=target(49926), SPRITES=target(49804), BONUS_RETURN=at(49966), SCROLL1=target(49884)))

def assembly(m):
    s = ''.join((f'{k} equ ${v:X}\n' for k, v in m['constants'].items())) + ASM.read_text()
    region = m['text_region']
    offsets = list(struct.unpack_from('>61H', region))
    if min(offsets) != 122 or max(offsets) >= len(region):
        raise ValueError('native text directory bounds differ')
    data = bytearray(128) + bytearray(region[122:])
    for i, off in enumerate(offsets):
        struct.pack_into('>H', data, 2 * i, off + 6)
    for i in (62, 63):
        struct.pack_into('>H', data, 2 * i, len(data))
    data += b'\x00\x00\x00\x00'
    for original, number, index in ((0, 1, 35), (1, 3, 36), (2, 4, 37), (3, 5, 49), (4, 6, 50), (0, 2, 61)):
        record = m['records'][original][1]
        text = record[3:].split(b'/', 1)[0]
        changed = bytes((14, record[1], record[2])) + f'STAGE {number} CLEAR BONUS'.encode() + record[3 + len(text):]
        struct.pack_into('>H', data, 2 * index, len(data))
        data += changed
    s += f'\n org ${DIRECTORY:X}\n dc.b ' + ','.join((str(v) for v in data)) + '\n'
    return s + '\n even\n'

def patch(image, bank, m, helper):
    image = bytearray(image)
    bank = bytearray(bank)
    changes = []
    if any((helper[a:a + 2] != b'N\xf9' for a in range(0, 42, 6))):
        raise ValueError('stage-clear entry offsets differ')

    def change(a, b):
        before = bytes(image[a:a + len(b)])
        changes.append(dict(address=a, before=before.hex(), after=b.hex()))
        image[a:a + len(b)] = b
    for a in m['entries']:
        change(a, b'Nq' * 2)
        change(a + 4, R.jsr(BASE))
    for a, slot in ((49926, 1), (49804, 3), (49884, 4), (50284, 5)):
        if a == 50284 and image[a + m['shift']:a + m['shift'] + 6] != bytes.fromhex('3b7c00008c74'):
            raise ValueError('credit layer-hide instruction differs')
        change(a + m['shift'], R.jsr(BASE + 6 * slot))
    a = 49958 + m['shift']
    if image[a:a + 8] != bytes.fromhex('302d90d204400050'):
        raise ValueError('bonus relocation differs')
    change(a, b'N\xf9' + (BASE + 12).to_bytes(4, 'big') + b'Nq')
    change(14284, DIRECTORY.to_bytes(4, 'big'))
    a = 48808 + m['shift']
    if image[a:a + 8] != bytes.fromhex('303c00234eb80e10'):
        raise ValueError('St. Petersburg bonus command differs')
    change(a, R.jsr(BASE + 36) + R.NOP)
    off = BASE - 1048576
    if not helper or len(helper) > 12288 or bank[off:off + len(helper)] != b'\xff' * len(helper):
        raise ValueError('stage-clear helper allocation occupied or oversized')
    bank[off:off + len(helper)] = helper
    return (bytes(image), bytes(bank), dict(helper_at=BASE, helper_bytes=len(helper), helper_sha256=sha(helper), hooks=changes, numbering=[1, 3, 5, 4, 6, 2], native_art_selected=True))

def audit(control, build):
    cm, old = inventory(control)
    meta, new = inventory(build)
    for machine, f in old.items():
        spec = meta['sets'][machine]['stage_clear']
        p = new[machine]['strex_p6.bin']
        bank = bytes((p[i ^ 1] for i in range(len(p))))
        off = BASE - 1048576
        helper = bank[off:off + spec['helper_bytes']]
        image = R.compose(f, R.SETS[machine])
        ob = f['strex_p6.bin']
        ob = bytes((ob[i ^ 1] for i in range(len(ob))))
        image, expected, report = patch(image, ob, model(image), helper)
        nf = dict(f, **R.decompose(image, R.SETS[machine], {n: len(f[n]) for n, _, _ in R.SETS[machine]}))
        nf['strex_p6.bin'] = bytes((expected[i ^ 1] for i in range(len(expected))))
        if nf != new[machine] or spec['hooks'] != report['hooks'] or sha(helper) != spec['helper_sha256']:
            raise ValueError('unexpected stage-clear ROM change')
        if spec['source_files'] != cm['sets'][machine]['files']:
            raise ValueError('clear source inventory differs')
    return meta

def main():
    if sys.argv[1:] == ['--self-test']:
        assert [1, 3, 5, 4, 6, 2][5] == 2
        try:
            patch(bytes(1048576), bytes(1048576), dict(entries=[], shift=0), b'x')
        except ValueError:
            pass
        else:
            raise AssertionError('foreign code accepted')
        print('Stage-clear guards PASS')
        return
    p = argparse.ArgumentParser(description=__doc__)
    for n in ('build', 'vasm', 'out'):
        p.add_argument('--' + n, type=Path, required=True)
    a = p.parse_args()
    meta, files = inventory(a.build)
    rep = deepcopy(meta)
    a.out.mkdir(parents=True, exist_ok=False)
    for machine, f in files.items():
        image = R.compose(f, R.SETS[machine])
        m = model(image)
        src = a.out / (machine + '.s')
        src.write_text(assembly(m))
        binary = src.with_suffix('.bin')
        subprocess.run([str(a.vasm), '-Fbin', '-m68000', '-quiet', '-o', str(binary), str(src)], check=True)
        p6 = f['strex_p6.bin']
        bank = bytes((p6[i ^ 1] for i in range(len(p6))))
        image, bank, report = patch(image, bank, m, binary.read_bytes())
        f = dict(f, **R.decompose(image, R.SETS[machine], {n: len(f[n]) for n, _, _ in R.SETS[machine]}))
        f['strex_p6.bin'] = bytes((bank[i ^ 1] for i in range(len(bank))))
        d = a.out / machine
        d.mkdir()
        for n, data in f.items():
            (d / n).write_bytes(data)
        report['source_files'] = meta['sets'][machine]['files']
        rep['sets'][machine]['stage_clear'] = report
        rep['sets'][machine]['files'] = {n: sha(data) for n, data in f.items()}
        print(machine, len(binary.read_bytes()), 'bytes; native clear presentation and six numbered labels')
    (a.out / 'build.json').write_text(json.dumps(rep, indent=2) + '\n')
    audit(a.build, a.out)
if __name__ == '__main__':
    main()
