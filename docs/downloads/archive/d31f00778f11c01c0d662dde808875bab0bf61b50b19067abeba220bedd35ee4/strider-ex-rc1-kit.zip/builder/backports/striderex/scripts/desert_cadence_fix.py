"""Smooth Hiryu's desert sprite Y in the existing post-game drawing task."""
import argparse
from copy import deepcopy
import json
from pathlib import Path
import struct
import subprocess
import sys
import respawn_fix as RF
from boss_voice_gate import inventory, sha
ENTRY = 2088960
DATA = 2091008
PREFIX = bytes.fromhex('4bf88000303c00014eb807de0c79d5e700fff92e660e4a6d8c7467066100')
ASM = Path(__file__).resolve().parents[1] / 'asm/desert_cadence.s'
TABLES = {'striderua': (101164, 108178, 459226), 'striderjr': (100464, 107478, 458534)}

def watcher(bank):
    hits = [i for i in range(0, len(bank) - 36, 2) if bank[i:i + len(PREFIX)] == PREFIX]
    if len(hits) != 1:
        raise ValueError('desert watcher prefix differs')
    p = hits[0]
    at = p + 28
    if bank[at:at + 2] != b'a\x00' or bank[at + 4] != 96:
        raise ValueError('desert watcher tail differs')
    loop = at + 6 + struct.unpack_from('>b', bank, at + 5)[0]
    hull = at + 2 + struct.unpack_from('>h', bank, at + 2)[0]
    if loop != p + 4 or not 0 <= hull < len(bank):
        raise ValueError('desert watcher targets differ')
    return dict(watcher_at=1048576 + at, watch_loop=1048576 + loop, hull_scroll=1048576 + hull, original=bank[at:at + 6].hex())

def body_bits(program, machine):
    start, end, shapes = TABLES[machine]
    at = start
    bits = bytearray(1024)
    count = 0
    word = lambda a: int.from_bytes(program[a:a + 2], 'big')
    while at < end:
        n, shape = program[at:at + 2]
        sh = program[shapes + shape * 8:shapes + shape * 8 + 8]
        cells = (sh[4] + 1) * (sh[5] + 1)
        codes = [word(at + 2 + 2 * k) for k in range(cells)]
        if n != sum((c != 65535 for c in codes)):
            raise ValueError('Hiryu matrix contract differs')
        for c in codes:
            if c != 65535:
                if c >= 8192:
                    raise ValueError('Hiryu body code outside bounded bitset')
                bits[c // 8] |= 1 << c % 8
        at += 2 + 2 * cells
        count += 1
    if at != end or count != 249:
        raise ValueError('Hiryu matrix inventory incomplete')
    return bytes(bits)

def patch(bank, helper, bits):
    spec = watcher(bank)
    b = bytearray(bank)
    if not helper or len(helper) > DATA - ENTRY or len(bits) != 1024:
        raise ValueError('invalid drawing allocation size')
    for at, data in ((ENTRY, helper), (DATA, bits)):
        off = at - 1048576
        if b[off:off + len(data)] != b'\xff' * len(data):
            raise ValueError('drawing allocation occupied')
        b[off:off + len(data)] = data
    at = spec['watcher_at'] - 1048576
    b[at:at + 6] = b'N\xf9' + ENTRY.to_bytes(4, 'big')
    return (bytes(b), dict(spec, helper_at=ENTRY, helper_bytes=len(helper), helper_sha256=sha(helper), data_at=DATA, data_bytes=len(bits), data_sha256=sha(bits), native_program_unchanged=True))

def audit(control, build):
    cm, old = inventory(control)
    meta, new = inventory(build)
    for m, s in meta['sets'].items():
        spec = s['desert_cadence']
        if spec['source_files'] != cm['sets'][m]['files']:
            raise ValueError('cadence source inventory differs')
        p6 = old[m]['strex_p6.bin']
        bank = bytes((p6[k ^ 1] for k in range(len(p6))))
        p = new[m]['strex_p6.bin']
        actual = bytes((p[k ^ 1] for k in range(len(p))))
        helper = actual[ENTRY - 1048576:ENTRY - 1048576 + spec['helper_bytes']]
        bits = body_bits(RF.compose(old[m], RF.SETS[m]), m)
        if sha(helper) != spec['helper_sha256'] or sha(bits) != spec['data_sha256']:
            raise ValueError('drawing helper/table differs')
        expected, _ = patch(bank, helper, bits)
        f = dict(old[m], **{'strex_p6.bin': bytes((expected[k ^ 1] for k in range(len(expected))))})
        if f != new[m]:
            raise ValueError('candidate differs outside the desert watcher hook, helper and table')
    return meta

def main():
    if sys.argv[1:2] == ['verify-fresh']:
        import boss_paging as P
        p = argparse.ArgumentParser(description='Verify both follow-up producers against a fresh sealed-kit replay')
        for n in ('control', 'paging', 'build', 'fresh-paging', 'fresh-build', 'receipt'):
            p.add_argument('--' + n, type=Path, required=True)
        a = p.parse_args(sys.argv[2:])
        source, _ = inventory(a.control)
        if source.get('reconstructed_from_verified_export') != '261025-14':
            raise ValueError('need a verified sealed Kit z reconstruction')
        P.audit(a.control, a.paging)
        audit(a.paging, a.build)
        checks = {}
        for label, original, replay in (('paging', a.paging, a.fresh_paging), ('drawing', a.build, a.fresh_build)):
            old, _ = inventory(original)
            new, _ = inventory(replay)
            if {m: s['files'] for m, s in old['sets'].items()} != {m: s['files'] for m, s in new['sets'].items()}:
                raise ValueError('fresh replay ROMs differ')
            for m in old['sets']:
                for field in ('boss_paging', 'desert_cadence'):
                    if old['sets'][m].get(field) != new['sets'][m].get(field):
                        raise ValueError('fresh replay metadata differs')
            checks[label] = {m: s['files'] for m, s in old['sets'].items()}
        root = Path(__file__).resolve().parents[1]
        paths = ('scripts/boss_paging.py', 'scripts/boss_scene.py', 'asm/boss_scene.s', 'scripts/desert_cadence_fix.py', 'asm/desert_cadence.s', 'lua/desert_gate.lua')
        report = dict(schema='striderex-boss-cadence-fresh-replay/1', passed=True, source_private_test_id='261025-14', source_files={m: s['files'] for m, s in source['sets'].items()}, builds=checks, source_sha256={name: sha((root / name).read_bytes()) for name in paths}, all_original_program_graphics_and_audio_roms_preserved=True, hardware_review_granted=False)
        a.receipt.write_text(json.dumps(report, indent=2) + '\n')
        print('PASS fresh replay: both regions, both producer stages, all ROMs and owned metadata')
        return
    if sys.argv[1:] == ['--self-test']:
        b = bytearray(b'\xff' * 1048576)
        p = 256
        b[p:p + len(PREFIX)] = PREFIX
        struct.pack_into('>h', b, p + 30, 100)
        b[p + 32:p + 34] = bytes.fromhex('60e2')
        assert watcher(b)['watch_loop'] == 1048836
        result, spec = patch(b, b'Nu', b'\x00' * 1024)
        assert result[p + 28:p + 30] == b'N\xf9'
        for offset in (p, ENTRY - 1048576, DATA - 1048576):
            bad = bytearray(b)
            bad[offset] ^= 1
            try:
                patch(bad, b'Nu', b'\x00' * 1024)
            except ValueError:
                pass
            else:
                raise AssertionError('foreign watcher/allocation accepted')
        print('Drawing guards PASS: exact watcher and two free allocations required')
        return
    p = argparse.ArgumentParser(description=__doc__)
    for n in ('build', 'vasm', 'out'):
        p.add_argument('--' + n, type=Path, required=True)
    a = p.parse_args()
    a.out = a.out.resolve()
    meta, files = inventory(a.build)
    rep = deepcopy(meta)
    a.out.mkdir(parents=True, exist_ok=False)
    for m, f in files.items():
        p6 = f['strex_p6.bin']
        bank = bytes((p6[k ^ 1] for k in range(len(p6))))
        s = watcher(bank)
        src = a.out / (m + '.s')
        src.write_text(f"HULL_SCROLL equ ${s['hull_scroll']:X}\nWATCH_LOOP equ ${s['watch_loop']:X}\n" + ASM.read_text())
        binary = src.with_suffix('.bin')
        subprocess.run([str(a.vasm), '-Fbin', '-m68000', '-quiet', '-o', str(binary), str(src)], check=True)
        bits = body_bits(RF.compose(f, RF.SETS[m]), m)
        bank, spec = patch(bank, binary.read_bytes(), bits)
        f = dict(f, **{'strex_p6.bin': bytes((bank[k ^ 1] for k in range(len(bank))))})
        d = a.out / m
        d.mkdir()
        for n, data in f.items():
            (d / n).write_bytes(data)
        rep['sets'][m]['files'] = {n: sha(b) for n, b in f.items()}
        rep['sets'][m]['desert_cadence'] = dict(spec, source_files=meta['sets'][m]['files'])
    (a.out / 'build.json').write_text(json.dumps(rep, indent=2) + '\n')
    audit(a.build, a.out)
    print('Desert sprite interpolation:', spec['helper_bytes'], 'native 68000 bytes; all original program ROMs unchanged')
if __name__ == '__main__':
    main()
