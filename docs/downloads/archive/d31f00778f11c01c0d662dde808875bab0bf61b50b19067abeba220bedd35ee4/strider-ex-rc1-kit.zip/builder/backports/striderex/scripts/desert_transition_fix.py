"""Slow the desert's settle and keep its mid-boss map seam off screen."""
import argparse
from copy import deepcopy
import json
from pathlib import Path
import struct
import subprocess
import sys
from boss_voice_gate import inventory, sha
PAN = bytes.fromhex('48e7406041ed8fec7600342d8ff4d47c000cb46d9018')
CONTEXT = struct.pack('>24H', 2, 4104, 6672, 848, 1808, 0, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0, 5, 1, 0, 0, 0, 0, 0, 0)
ENTRY = 2049024
ASM = Path(__file__).resolve().parents[1] / 'asm/desert_transition.s'

def sites(b):
    hits = [a for a in range(0, len(b) - len(PAN), 2) if b[a:a + len(PAN)] == PAN]
    if len(hits) != 1:
        raise ValueError('native desert pan differs')
    at = hits[0]
    hits = [a for a in range(at, at + 140, 2) if b[a:a + 4] in (bytes.fromhex('d07c0018'), bytes.fromhex('907c0018')) and b[a + 4:a + 6] == b'N\xb9']
    if len(hits) != 4:
        raise ValueError('four native pan distances required')
    return hits

def patch(raw, helper):
    b = bytearray((raw[i ^ 1] for i in range(len(raw))))
    changes = []
    for i, a in enumerate(sites(b)):
        new = b'N\xb9' + (ENTRY + 6 * i).to_bytes(4, 'big') + b'Nq' * 2
        changes.append(dict(address=1048576 + a, before=b[a:a + 10].hex(), after=new.hex()))
        b[a:a + 10] = new
    if b.count(CONTEXT) != 1:
        raise ValueError('mid-boss map transition differs')
    a = b.index(CONTEXT) + 2
    changes.append(dict(address=1048576 + a, before='1008', after='1014'))
    struct.pack_into('>H', b, a, 4116)
    off = ENTRY - 1048576
    if not helper or len(helper) > 2048 or b[off:off + len(helper)] != b'\xff' * len(helper):
        raise ValueError('transition allocation occupied or oversized')
    if any((helper[a:a + 2] != b'N\xf9' for a in (0, 6, 12, 18))):
        raise ValueError('transition entry offsets differ')
    b[off:off + len(helper)] = helper
    return (bytes((b[i ^ 1] for i in range(len(b)))), dict(changes=changes, pan_step_input=1, map1_temporary_minimum=4116, following_section_minimum=4104, helper_at=ENTRY, helper_bytes=len(helper), helper_sha256=sha(helper), only_section=1, only_step=25))

def audit(control, build):
    cm, old = inventory(control)
    meta, new = inventory(build)
    for m, f in old.items():
        spec = meta['sets'][m]['desert_transition']
        p = new[m]['strex_p6.bin']
        p = bytes((p[i ^ 1] for i in range(len(p))))
        helper = p[ENTRY - 1048576:ENTRY - 1048576 + spec['helper_bytes']]
        b, s = patch(f['strex_p6.bin'], helper)
        expected = dict(f, **{'strex_p6.bin': b})
        if new[m] != expected or s['changes'] != spec['changes'] or s['helper_sha256'] != spec['helper_sha256'] or (spec['source_files'] != cm['sets'][m]['files']):
            raise ValueError('unexpected transition ROM changes')
    return meta

def main():
    if sys.argv[1:] == ['--self-test']:
        try:
            patch(b'\xff' * 512, b'x')
        except ValueError:
            pass
        else:
            raise AssertionError('foreign map/pan accepted')
        print('Desert transition guards PASS')
        return
    p = argparse.ArgumentParser(description=__doc__)
    for n in ('build', 'out', 'vasm'):
        p.add_argument('--' + n, type=Path, required=True)
    a = p.parse_args()
    meta, files = inventory(a.build)
    rep = deepcopy(meta)
    a.out.mkdir(parents=True, exist_ok=False)
    for m, f in files.items():
        p6 = f['strex_p6.bin']
        bank = bytes((p6[i ^ 1] for i in range(len(p6))))
        bindings = {k: int.from_bytes(bank[at + 6:at + 10], 'big') for k, at in zip(('SCR_R', 'SCR_L', 'SCR_U', 'SCR_D'), sites(bank))}
        src = a.out / (m + '.s')
        src.write_text(''.join((f'{k} equ ${v:X}\n' for k, v in bindings.items())) + ASM.read_text())
        binary = src.with_suffix('.bin')
        subprocess.run([str(a.vasm), '-Fbin', '-m68000', '-quiet', '-o', str(binary), str(src)], check=True)
        b, spec = patch(p6, binary.read_bytes())
        f = dict(f, **{'strex_p6.bin': b})
        d = a.out / m
        d.mkdir()
        for n, data in f.items():
            (d / n).write_bytes(data)
        spec['source_files'] = meta['sets'][m]['files']
        rep['sets'][m]['desert_transition'] = spec
        rep['sets'][m]['files'] = {n: sha(data) for n, data in f.items()}
    (a.out / 'build.json').write_text(json.dumps(rep, indent=2) + '\n')
    audit(a.build, a.out)
if __name__ == '__main__':
    main()
