# Strider EX reconstruction tools

The public kit contains reconstruction source and the FPGA core. It never
contains MAME, HBMAME, the System Card BIOS, the source games, extracted
pictures or built music packs.

- **Source replay:** MAME 0.288 with Lua, from https://www.mamedev.org/ or
  https://github.com/mamedev/mame/tree/mame0288 . The minimal Arcade Card Pro
  software-list entry is from `hash/pce.xml`, licensed CC0-1.0. Supply the
  BIOS yourself. The enhanced arcade output requires HBMAME; stock MAME is
  used to replay the PC Engine source and the original arcade openings.
- **HBMAME registrations:** the two original CPS-1 ROM declarations are
  reproduced as metadata from
  https://github.com/Robbbert/hbmame/tree/7ca9344f867e7536c99cc97dedbafa3a07bb78c7 .
  The source declarations are BSD-3-Clause. The kit regenerates the EX
  graphics configuration and matching ROM_START/GAME fragments.
- **68000 assembler:** vasm 2.0f, source mirror
  https://github.com/siemens-mobile-hacks/vasm/tree/2516daa63ddd61744dfaae72b829002fb22c2cfe .
  `bootstrap_vasm.py` checks out that exact revision, builds the m68k/Motorola
  target, and checks a machine-code fixture. Git, make and a C compiler
  are required unless supplying an existing assembler with `--vasm`.
  Vasm has its own upstream license; no assembler executable is bundled.
- **FFmpeg/ffprobe:** the CPS+ helper resolver uses the bundled
  `builder/cpsplus/tools/ffmpeg_helpers.json` content lock and verifies the
  downloaded archive and executables. The helper records identify their
  license and corresponding source. No global installation is changed.
  `--tools-cache`, `--tools-bundle` and `--offline` configure that resolver.
- **7-Zip:** ZIP inputs use the Python standard library. 7z inputs use an
  installed `7zz` or `7z`; https://www.7-zip.org/ .
- **Python packages:** Python 3.11+, NumPy, Pillow and SciPy. Strong output
  hashes detect a numerical or encoder difference instead of shipping it.
- **FPGA core:** see `core/SOURCE_AND_LICENSE.txt` and `core/LICENSE` for
  the exact Strider EX mapper/CPS+ source revision, build and GPL-3.0 terms.

The English boss recordings were generated for this project. The cinematic
dub is distributed as a disc-dependent integer delta; decoding checks the English PCM identities and
requires the matching complete disc tracks. No cloud service or account is
used by the public reconstruction program.
