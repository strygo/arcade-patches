"""NSP-bound XOR reconstruction deltas. No source bytes or keys are constants."""
import hashlib
import zlib


def sha(data):
    return hashlib.sha256(data).hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def source_key(resource):
    # This digest is private working state, never an identity in the manifest.
    # A published SHA-256 of the input is deliberately NOT the key material.
    require(len(resource) >= 32, 'Source resource is truncated')
    return hashlib.shake_256(b'USF2 source key v1\0' + resource).digest(32)


def xor(a, b):
    require(len(a) == len(b), 'XOR extents differ')
    return bytes(x ^ y for x, y in zip(a, b))


def mask(data, key, identity):
    require(len(key) == 32 and identity, 'Missing private source key or payload identity')
    stream = hashlib.shake_256(b'USF2 payload v1\0' + key + identity.encode()).digest(len(data))
    return xor(data, stream)


def baseline(source, size):
    require(0 <= len(source) <= size <= 0x1000000, 'Invalid reconstruction extent')
    return source + b'\xff' * (size - len(source))


def encode(target, source, key, region):
    delta = xor(target, baseline(source, len(target)))
    compressed = zlib.compress(delta, 9)
    identity = region + ':' + sha(compressed)
    wrapped = mask(compressed, key, identity)
    return wrapped, dict(identity=identity, bytes=len(wrapped), sha256=sha(wrapped),
                         decoded_sha256=sha(compressed), output_bytes=len(target),
                         output_sha256=sha(target), changed_bytes=sum(x != 0 for x in delta))


def decode(wrapped, record, source, key):
    require(len(wrapped) == record['bytes'] and sha(wrapped) == record['sha256'],
            'Masked payload identity differs')
    compressed = mask(wrapped, key, record['identity'])
    require(sha(compressed) == record['decoded_sha256'], 'NSP source does not unlock this payload')
    size = record['output_bytes']
    require(0 <= size <= 0x1000000, 'Unbounded payload output')
    reader = zlib.decompressobj()
    delta = reader.decompress(compressed, size + 1)
    require(len(delta) == size and reader.eof and not reader.unused_data and
            not reader.unconsumed_tail, 'Reconstruction delta extent differs')
    result = xor(delta, baseline(source, size))
    require(sha(result) == record['output_sha256'], 'Reconstructed member identity differs')
    return result
