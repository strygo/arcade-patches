Ultra Street Fighter II — reconstruction kit



Version: rc1 (2026-10-16)

Backport by: Steve Gordon (https://x.com/strygo)



Ultra Street Fighter II: The Final Challengers is the 2017 Nintendo Switch edition of Super Street Fighter II Turbo, and it never had an arcade release. This backport rebuilds it as a CPS-2 game.

Akuma has his own select cell, and Evil Ryu and Violent Ken join the original sixteen fighters with their Ultra moves, colors and endings. Shin Akuma stays hidden, for twenty fighters in all.

Ultra's presentation comes with them: the Ultra title and intro, "The Final Challengers" lettering, a color select for the new fighters, and a choice of sixteen stages or Random once you have picked a fighter.

The Switch edition's sound effects play in every build, and on MiSTer its arranged music plays too. The ULTRA CONFIGURATION page in Test Mode switches the sound effects and, on MiSTer, the music between MODERN and CLASSIC.

The USA build is in English; the Japan build keeps the Japanese.

This is a release candidate.



Changes:

- Akuma on his own select cell, with Evil Ryu and Violent Ken: twenty fighters with the hidden Shin Akuma

- Ultra's classic colors for the new fighters, chosen on a color select screen

- Sixteen stages and Random to choose from after you pick a fighter

- The Ultra title and intro, and ULTRA on the VS, Continue and Game Over screens

- The Switch edition's sound effects, and its arranged music on MiSTer; MODERN or CLASSIC for each in ULTRA CONFIGURATION

- USA (English) and Japan builds

INPUTS
  - Canonical MAME-format ssf2xj and its parent/shared members (ssf2t).
    Complete, merged, split ZIP/7z and loose layouts are supported by hash.
    7z needs installed 7-Zip. Supply canonical QSound dl-1425.bin as well.
  - USA base USF2 NSP for USA output; Japanese base NSP for Japanese output.
    Both are required for --region all. Supported identities are in kit.json.
    Update NSPs are not required. Filenames are not identities.
  - Your own prod.keys. Keys are never bundled or downloaded.
  - Python 3.10+, git, CMake and a C/C++ compiler for pinned NSTool/libopus.
  - MiSTer music generation additionally needs NumPy and FFmpeg.
    It uses fixed-point Opus decoding and the qualified ADX conversion. Any
    differing final music bytes fail the published CPK hash check.

BUILD ALL OUTPUTS
  python3 apply.py --rompath ROM_DIRECTORY --nsp-us USA_BASE.nsp \
    --nsp-jp JAPAN_BASE.nsp --keys prod.keys --work scratch --out-dir output

  --region us|jp|all      Select regional output (default: all).
  --audio 4|8|all         Restrict sample capacity (default: all).
  --platform mame|hbmame|mister|all (default: all).
  --check                Verify arcade inputs and decrypt NSP resources only.

  Output must be fresh. Inputs are never modified. The build stages privately
  and publishes the completed tree only after exact ROM/MRA/music checks pass.
  Source tools are fetched from pinned revisions; no game data is downloaded.

OUTPUTS
  mame/<set>.zip              USA/Japan 4 MiB MODERN game archives.
  hbmame/<set>.zip            USA/Japan 8 MiB CLASSIC/MODERN game archives.
  definitions/*.cpp.inc       Exact ROM and GAME registrations for all four.
  mister/games/mame/          Complete native archives (firmware included).
  mister/games/CPS+/          The generated usf2_arrange.zip / CPK.
  mister/_Arcade/             Two 8 MiB CPS+ MRAs and the CPS2+ core.
  verification.json          Exact selected profile and assembled-image hashes.

  Copy the contents of mister/ to the MiSTer card. Both MRAs use the included
  CPS2+ core and require 128 MiB SDRAM. Demo sounds, MODERN sound effects and
  MODERN music are enabled by default. In Test Mode, ULTRA CONFIGURATION has
  SOUND EFFECTS and MUSIC, each using MODERN / CLASSIC. MUSIC appears only
  when the MRA enables it. The unmodified ROM hides it on emulators/hardware.
  Existing saved settings take precedence. Clear that launcher's NVRAM to
  reload the supplied MRA EEPROM defaults. MAME and HBMAME retain sequenced
  QSound music. The 4 MiB version always uses MODERN effects, with reduced
  rates for less-used speech to fit its smaller sample space.

MAME / HBMAME
  Custom sets require their matching compiled CPS-2 definitions. An unchanged
  upstream emulator does not automatically recognize these set names.
  In a clean source checkout, install the definitions before compiling:
    python3 install_driver.py --driver PATH_TO_CPS2_CPP --list PATH_TO_GAME_LIST
  Use src/mame/capcom/cps2.cpp and src/mame/mame.lst for MAME, or
  src/hbmame/drivers/cps2.cpp and src/hbmame/hbmame.lst for HBMAME. Both the
  C++ definitions and game-list registration are installed together. Existing
  conflicting USF2 definitions fail instead of being overwritten.
  Then build that emulator and launch by usf2t4/usf2t8/usf2j4/usf2j8.
  Emulators use native QSound music; CPK playback is a MiSTer CPS+ feature.

MUSIC ONLY
  python3 music.py --nsp USA_BASE.nsp --keys prod.keys \
    --work music-scratch --out usf2_arrange.cpk
  The normal MiSTer/all build does this automatically. No existing CPK is an
  input shortcut. Tracks, conversion, loop points and trigger mapping must
  reproduce the qualified arrangement exactly.

VERIFY AFTER MOVING THE OUTPUT
  python3 output/verify_output.py --root output

RECONSTRUCTION FORMAT
  Unchanged bytes come from canonical arcade inputs. Changed/added bytes are
  source-relative XOR deltas, compressed and masked using actual decrypted
  NSP resource bytes with separate payload identities. This includes authored
  and embedded donor art and the frozen converted game resources. The public
  download contains no usable artwork masters. A published input checksum is
  not a decryption key. This is an input dependency, not redistribution control
  over the files someone has already reconstructed.

  This frozen installer does not rerun the development artwork pipeline or
  artistic tools. The CPK is freshly generated from NSP music. Every result
  is checked against the selected native candidate before publication.

SOURCE AND LICENSES
  core/SOURCE_AND_LICENSE.txt and cps2_core_release.json identify the approved
  CPS+ binary, corresponding source revision and licenses. The bundled source
  tools carry their original notices. Do not distribute this kit together
  with reconstructed game archives, NSPs, keys or generated copyrighted audio.

CREDITS
  Akuma's imported artwork is Tyrone's, from Super Street Fighter II Turbo: New Legacy.
