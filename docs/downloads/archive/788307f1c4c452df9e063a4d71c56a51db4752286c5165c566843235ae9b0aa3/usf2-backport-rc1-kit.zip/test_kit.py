#!/usr/bin/env python3
"""Focused corrupt/wrong-source, bounded decoder and driver collision tests."""
import hashlib
from pathlib import Path
import random
import tempfile
import unittest
import payload
import install_driver
import nsp
import policy


class KitTests(unittest.TestCase):
    def test_shipping_platform_and_MRA_matrix(self):
        for name in ('usf2t4','usf2j4'):
            policy.check_mras(name,[])
            self.assertEqual(policy.platforms_for(name,('mame','hbmame','mister')),('mame',))
            with self.assertRaises(ValueError):
                policy.check_mras(name,[dict(arrange=False),dict(arrange=True)])
        for name in ('usf2t8','usf2j8'):
            policy.check_mras(name,[dict(arrange=True)])
            self.assertEqual(policy.platforms_for(name,('mame','hbmame','mister')),('hbmame','mister'))
            with self.assertRaises(ValueError):policy.check_mras(name,[dict(arrange=False)])

    def test_missing_media_and_bad_container(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp);bad=root/'source.nsp';bad.write_bytes(b'not an NSP')
            with self.assertRaises(ValueError):nsp.entries(bad)
            with self.assertRaises(ValueError):nsp.authenticate(root/'missing.nsp',{'region':'us','nsp_sha256':'0'*64})
            with self.assertRaises(ValueError):nsp.unlock(bad,root/'missing.keys',{},root/'work')
    def test_exact_and_wrong_source(self):
        rng=random.Random(103)
        source=rng.randbytes(4096); target=source[:100]+rng.randbytes(200)+source[300:]+b'custom art'
        key=payload.source_key(b'owned resource'*20)
        wrapped,record=payload.encode(target,source,key,'us')
        self.assertEqual(payload.decode(wrapped,record,source,key),target)
        for bad_key,bad_source in ((b'X'*32,source),(key,b'X'*4096)):
            with self.assertRaises(ValueError):payload.decode(wrapped,record,bad_source,bad_key)
        with self.assertRaises(ValueError):payload.decode(wrapped[:-1],record,source,key)
        with self.assertRaises(ValueError):payload.decode(wrapped,dict(record,output_bytes=2),source,key)

    def test_no_public_digest_key_and_no_stream_reuse(self):
        resource=b'private actual source content'*20
        key=payload.source_key(resource)
        self.assertNotEqual(key,hashlib.sha256(resource).digest())
        self.assertNotEqual(payload.mask(b'A'*256,key,'us:asset1'),payload.mask(b'A'*256,key,'us:asset2'))

    def test_driver_collision(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp);defs=root/'definitions';defs.mkdir();driver=root/'cps2.cpp'
            for i in range(4):(defs/(str(i)+'.cpp.inc')).write_text('ROM_START( usf2test'+str(i)+' )\nROM_END\n')
            driver.write_text('// cps2 clean\n');listing=root/'mame.lst'
            listing.write_text('@source:capcom/cps2.cpp\nssf2t\n@source:next.cpp\nnextgame\n')
            install_driver.install(driver,defs,list_path=listing)
            install_driver.install(driver,defs,True,listing)
            self.assertLess(listing.read_text().index('usf2test0'),listing.read_text().index('@source:next.cpp'))
            original=driver.read_text();driver.write_text(original.replace('usf2test0','usf2wrong'))
            with self.assertRaises(ValueError):install_driver.install(driver,defs)


if __name__=='__main__':unittest.main()
