BUILD OR UPDATE

Run python apply.py in a terminal (Windows: py -3.13 apply.py).
Choose Build or update, then select your media and available outputs.
Settings are remembered; intact outputs can be reused safely.
Check requirements is optional. Change settings saves without building.
Enter q at any prompt to quit. Run apply.py --help for the existing
command-line options and specialized workflows described below.

Final Fight EX — Enhanced version
Version: rc4 (2026-10-24)
Game: Final Fight (arcade, Capcom CPS-1)
Hardware: Capcom CPS-1


The 1993 Sega CD port gave Final Fight an animated opening and an extended ending. Final Fight EX brings those scenes to the arcade game as native CPS-1 graphics, with an EX title and a hidden stage select. The original combat and timing stay intact.

There are two regional builds, USA (ffightus01) and Japan (ffightjs01), each matched to its own disc's dialogue and artwork. It runs in HBMAME and on MiSTer; stock MAME is not supported.

On MiSTer, choose the arcade game's music and effects or the CPS+ Arrange version with the Sega CD soundtrack and regional spoken dialogue. Both options are included in this kit.

Supply your arcade Final Fight ROMs and the matching Final Fight CD disc for each region you build. This is a release candidate.

FEATURES

- The Sega CD opening, including the Metro City map, Mad Gear line-up, Haggar's phone call, and the Cody and Guy montage
- The extended ending, including Haggar and Jessica's reunion and Cody's farewell
- A Final Fight EX title screen
- A hidden stage select: hold attack and jump and press Start on the title screen to choose a round or the ending
- USA (ffightus01) and Japan (ffightjs01) builds, each with its regional dialogue and artwork
- Arcade audio or the Sega CD soundtrack and regional voices through CPS+ on MiSTer
- Corrections to English spelling and the Japanese ending artwork


RECONSTRUCTION

Python 3.12+, NumPy, original Final Fight arcade ROMs and your regional Final Fight CD discs.
Pillow and scene rendering are no longer required. Authenticated FFmpeg, CHD and 7z helper controls are retained.
python3 apply.py --region both --disc-us USA.7z --disc-jp Japan.7z --romset ROMS --out-dir out
Use --platform hbmame|mister|all and --audio arcade|cpsplus|both. Raw first-track images support arcade-only output.
