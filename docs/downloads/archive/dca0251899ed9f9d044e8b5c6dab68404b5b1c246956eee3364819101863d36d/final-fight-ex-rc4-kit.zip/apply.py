#!/usr/bin/env python3
"""Build unchanged Final Fight EX from original media and bounded recipes."""
# BEGIN ARCADE KIT ENTRY
if __name__ == "__main__":
    import sys as _kit_sys
    if len(_kit_sys.argv) == 1 and _kit_sys.stdin.isatty() and _kit_sys.stdout.isatty():
        import importlib.util as _kit_import
        from pathlib import Path as _KitPath
        _kit_root = _KitPath(__file__).resolve().parent
        _kit_spec = _kit_import.spec_from_file_location("_kit_frontend", _kit_root / "_kit_runtime/frontend.py")
        _kit_frontend = _kit_import.module_from_spec(_kit_spec)
        _kit_spec.loader.exec_module(_kit_frontend)
        raise SystemExit(_kit_frontend.guided(_kit_root))
# END ARCADE KIT ENTRY

import sys as _native_sys
from pathlib import Path as _NativePath
if __name__ == '__main__':
    _native_sys.path.insert(0, str(_NativePath(__file__).resolve().parent))
    from kit_cli import install as _native_errors
    _native_errors()
if __name__ == '__main__' and ('--collection-layout' in _native_sys.argv or '--describe-json' in _native_sys.argv or '--emit-definition' in _native_sys.argv):
    _native_sys.path.insert(0, str(_NativePath(__file__).resolve().parent))
    from native_collection import main as _native_main
    raise SystemExit(_native_main(_NativePath(__file__).resolve().parent))
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys
import tempfile
import zipfile

HERE = Path(__file__).resolve().parent
sys.path[:0] = [str(HERE), str(HERE / 'sound'), str(HERE / 'sound/tools')]
from resource_recipe import Resources, require, sha
from rom_sources import Resolver, publish_tree


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def write_zip(path, files):
    path.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(path, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for name, data in sorted(files.items()):
            info = zipfile.ZipInfo(name, (1980, 1, 1, 0, 0, 0))
            info.compress_type, info.create_system = zipfile.ZIP_DEFLATED, 3
            info.external_attr = 0o100644 << 16
            z.writestr(info, data, compresslevel=9)


def scene_bytes(image, spec):
    result = bytearray()
    with Path(image).open('rb') as stream:
        for lba, count in spec:
            data = bytearray()
            for sector in range((count + 2047) // 2048):
                stream.seek((lba + sector) * 2352 + 16)
                block = stream.read(2048)
                require(len(block) == 2048, 'Truncated scene source')
                data.extend(block)
            result.extend(data[:count])
    return bytes(result)


def selected(name, regions, platform, audio):
    if platform == 'hbmame' and name.startswith('mister/'):
        return False
    if platform == 'mister' and name.startswith('hbmame/'):
        return False
    if regions == ['us'] and ('ffightjs01' in name or '/_Japan/' in name or 'arrange_jp.' in name):
        return False
    if regions == ['jp'] and ('ffightus01' in name or name.endswith('.mra') and '/_Japan/' not in name
                             or name.endswith('/ffight_arrange.zip')):
        return False
    if audio == 'arcade' and ('/_Arrangements/' in name or '/games/CPS+/' in name or '/cores/' in name):
        return False
    if audio == 'cpsplus' and '/_Enhanced Versions/' in name:
        return False
    return True


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--region', choices=('us', 'jp', 'both'))
    for name in ('disc-us', 'disc-jp', 'romset', 'work'):
        p.add_argument('--' + name, type=Path)
    p.add_argument('--rompath', type=Path, action='append', default=[])
    p.add_argument('--platform', choices=('all', 'hbmame', 'mister'), default='all')
    p.add_argument('--audio', choices=('both', 'arcade', 'cpsplus'), default='both')
    p.add_argument('--out-dir', type=Path, default=Path('out'))
    p.add_argument('--check', action='store_true')
    import ffmpeg_runtime
    a = p.parse_args(ffmpeg_runtime.configure(sys.argv[1:]))
    seal = json.loads((HERE / 'kit.json').read_text())
    require(seal['schema'] == 2, 'Unknown recipe kit')
    for name, pin in seal['files'].items():
        path = HERE / name
        require(path.resolve().is_relative_to(HERE) and not path.is_symlink() and digest(path) == pin,
                'Kit file missing or changed: ' + name)
    discs = dict(us=a.disc_us, jp=a.disc_jp)
    regions = ['us', 'jp'] if a.region == 'both' else [a.region] if a.region else [r for r in discs if discs[r]]
    require(regions and all(discs[r] for r in regions), 'Supply the selected original regional discs')
    paths = [*([a.romset] if a.romset else []), *a.rompath]
    require(paths, 'Supply original arcade ROMs with --romset or --rompath')
    output = a.out_dir.resolve()
    require(not output.is_relative_to(HERE) and not HERE.is_relative_to(output), 'Output overlaps the software tree')
    plan = json.loads((HERE / 'recipes.json').read_text())
    pins = json.loads((HERE / 'outputs.json').read_text())
    wanted = {n: pin for n, pin in pins['inventory'].items() if selected(n, regions, a.platform, a.audio)}
    # Existing output conflicts are refused before reading disc images or encoding audio.
    for name, pin in wanted.items():
        dest = output / name
        require(not any(parent.is_symlink() or parent.exists() and not parent.is_dir()
                        for parent in (dest.parent, *dest.parents)), 'Invalid output parent')
        if dest.exists() or dest.is_symlink():
            require(dest.is_file() and not dest.is_symlink() and digest(dest) == pins['whole_files'][name],
                    'Output conflict: ' + name)
    if a.work:
        a.work.mkdir(parents=True, exist_ok=True)
        require(not a.work.resolve().is_relative_to(output) and not output.is_relative_to(a.work.resolve()),
                'Work overlaps output')
    import cpsplus_audio
    from pack import discsrc
    reader = Resolver(paths, hints=('ffight', 'ffightu', 'ffightj'))
    with tempfile.TemporaryDirectory(prefix='ffex-', dir=a.work) as temporary:
        work = Path(temporary)
        stage = work / 'outputs'
        stage.mkdir()
        audio = a.platform != 'hbmame' and a.audio != 'arcade'
        for region in regions:
            row = plan['regions'][region]
            image = cpsplus_audio.data_track(discs[region], work, require_audio=audio)
            sources = {'scene': scene_bytes(image, row['scene_extents'])}
            for key, spec in row['roms'].items():
                sources[key] = reader.resolve([spec])[spec['name']]
            resources = Resources(row['resources'], (HERE / ('resources-' + region + '.bin')).read_bytes(), sources)
            if a.check:
                continue
            members = {n: resources.emit(spec) for n, spec in row['members'].items()}
            for prefix in ('hbmame/', 'mister/games/hbmame/'):
                name = prefix + row['set'] + '.zip'
                if name in wanted:
                    write_zip(stage / name, members)
            if audio:
                from recipe_music import build
                track_dir = work / 'audio' / region
                discsrc.ensure_audio_cache(track_dir, {r['track'] for r in row['music']['tracks']},
                                           discs[region], '--disc-' + region)
                pack = work / (row['pack'] + '.cpk')
                build(row['music'], track_dir, pack)
                write_zip(stage / ('mister/games/CPS+/' + row['pack'] + '.zip'), {pack.name: pack.read_bytes()})
        if a.check:
            print('PASS selected original ROM and scene inputs')
            return
        for name in wanted:
            src = HERE / 'files' / name
            if src.is_file():
                dest = stage / name
                dest.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(src, dest)
        actual = {p.relative_to(stage).as_posix(): digest(p) for p in stage.rglob('*') if p.is_file()}
        require(actual == {n: pins['whole_files'][n] for n in wanted}, 'Complete selected output bytes differ')
        publish_tree(output, {n: (stage / n).read_bytes() for n in actual})
    print('PASS unchanged Final Fight EX: ' + ', '.join(regions))


if __name__ == '__main__':
    main()
