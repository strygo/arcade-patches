ROM INPUT UPDATE

Merged, split, complete ZIP/7z archives and extracted ROM folders are accepted.
Use --rompath DIR (repeatable) to search a collection, or keep the existing archive argument.
Names may differ; required source contents are verified by size and strong hashes.
Use --check to verify arcade build inputs before reconstruction.
QSound is optional for game builds. Valid embedded firmware is preserved in complete game outputs.
Use --include-devices on CPS-2 kits to require and include firmware from separate archives.
Compact HBMAME outputs retain their stock-game and device dependencies.
7z input requires an installed 7-Zip executable; ZIP needs no extra archive software.
Original archives are never modified by collection discovery.

Street Fighter Alpha EX · Enhanced version
==========================================

Version:  rc3 (2026-11-03)
Target:   MAME set 'sfzj' (Street Fighter Zero (Japan 950727))
Hardware: Capcom CPS-2
Patch by: Steve Gordon (https://x.com/strygo)
Website:  https://arcadepatches.com/sfa-ex/

ABOUT THIS PROJECT

Street Fighter Alpha EX aims to be the definitive version of the first Alpha,
bringing together features from its console releases and the CPS-1 Changer
version. It builds on the regional restoration, with Akuma, Dan and M. Bison
on the visible select screen and six colors per fighter: the original two plus
four from Alpha 2.

CONSOLE mode adds a green title and a cycling mode menu: Arcade, Versus,
Training, Dramatic Battle, Survival, Akuma and Options. Versus returns to
fighter selection after each match. Training has recording and replay,
computer behavior, stage and gauge controls, and health that refills after a
combo while stopping at 1 HP.

Dramatic Battle offers the original Ryu and Ken encounter and an EX route
against Adon, Sagat, M. Bison and Akuma. Play with a computer teammate or a
second player, and choose your team in EX. Survival follows Alpha Anthology's
opponent order and health recovery. Akuma mode goes straight to the original
boss challenge.

OPTIONS covers difficulty, timer, rounds, damage, speed and sound. The
operator menu adds CONSOLE or ARCADE game mode, six or original colors,
extended Turbo and slow speeds, and optional CPS Changer route choices in
Arcade. ARCADE mode retains the arcade title and coin handling.

The USA build is Street Fighter Alpha EX, with the regional restoration's
English story, quotes and endings. Japan is Street Fighter Zero EX, in
Japanese; Asia retains the Zero title with English text. The MiSTer MRAs start
in CONSOLE mode; MAME and HBMAME start in ARCADE mode. It runs in MAME and
HBMAME and on MiSTer.

This is a release candidate.

WHAT'S CHANGED

  - Akuma, Dan, M. Bison and Random on the expanded character-select screen
  - Six colors per fighter, selected with the six attack buttons; the four
    extra colors come from Alpha 2
  - CONSOLE mode with a green title and Arcade, Versus, Training, Dramatic
    Battle, Survival, Akuma and Options
  - Training with recording and replay, computer behavior, stage and gauge
    controls, delayed health refill and a 1 HP minimum
  - Classic Dramatic Battle and a four-opponent EX route, with a computer
    teammate or two human players
  - Survival with Alpha Anthology's opponent order and health recovery,
    animated during FIGHT
  - Direct access to the original Akuma challenge, named Gouki in Japan
  - Versus rematches return to character selection, with shared win counters
    in Versus and Survival
  - Coin or a START hold opens pause in Console fights; Quit returns directly
    to the title
  - OPTIONS for difficulty, timer, rounds, damage, speed and sound; extended
    Turbo and slow speeds in operator configuration
  - Optional CPS Changer route choices after character and speed selection in
    Arcade
  - USA, Japan and Asia builds, with the regional restoration underneath

BUILDS IN THIS DOWNLOAD

    usa        USA (English)
    japan      Japan (Japanese)
    asia       Asia (English)

HOW TO APPLY (recommended)

    python3 apply.py /path/to/sfzj.zip --out-dir out

This checks every file against the original, applies the patches, checks
the result, and writes everything you need for every build (add
--variant <build> to make just one):

  USA (English):
    MAME:                     out/mame/usa/sfzj.zip
    HBMAME:                   out/hbmame/sfaexu.zip
    FBNeo:                    out/fbneo/sfaex.zip
    MiSTer:                   out/mister/_Arcade/_Arcade Patches/_Enhanced Versions/Street Fighter Alpha EX (USA).mra
  Japan (Japanese):
    MAME:                     out/mame/japan/sfzj.zip
    HBMAME:                   out/hbmame/sfzexj.zip
    FBNeo:                    out/fbneo/sfzexj.zip
    MiSTer:                   out/mister/_Arcade/_Arcade Patches/_Enhanced Versions/_Japan/Street Fighter Zero EX (Japan).mra
  Asia (English):
    MAME:                     out/mame/asia/sfzj.zip
    HBMAME:                   out/hbmame/sfzexa.zip
    FBNeo:                    out/fbneo/sfzexa.zip
    MiSTer:                   out/mister/_Arcade/_Arcade Patches/_Enhanced Versions/_Asia/Street Fighter Zero EX (Asia).mra

FBNeo: use --platform fbneo --out-dir out for complete game ZIPs.
Keep their ZIP and member names. Use an FBNeo version with definitions
matching this game release; older versions may reject its checksums.


Merged, split and complete sets work, including nested or renamed ROMs.
Use --rompath DIR (repeatable) to search a collection instead of naming the
zip, and --check to check inputs before building. ZIPs and extracted folders
need no extra software; 7z archives need 7-Zip.
Keep your unmodified qsound.zip in the emulator's ROM path.
Device firmware is not copied into the game archives.

MAME: put sfzj.zip from out/mame/ ahead of the stock set in your MAME
rompath (one build at a time: they share the set name).
MAME's game menu won't start a set with patched ROMs, so start it from the
command line: mame sfzj. MAME shows checksum warnings for the patched
ROMs; that's expected and the game runs normally.
To start it from a menu, use the HBMAME build.
Keep your unmodified qsound.zip in MAME's ROM path.

HBMAME: use a build containing the sfaexu, sfzexj, sfzexa set definitions.
Upstream HBMAME support is pending.
Put sfaexu.zip, sfzexj.zip, sfzexa.zip and qsound.zip in HBMAME's roms/ folder;
it holds the complete set.

MiSTer: copy the _Arcade folder from out/mister/ to the root of your SD card
and keep the stock, unmodified romset at games/mame/sfzj.zip (split MAME
sets also need qsound.zip). The MRA applies the edition in memory as the
game loads, so nothing on the card is modified. You need Jotego's jtcps2
core, which update_all installs. The MRAs are also a separate download.

HOW TO APPLY (any IPS patcher)

Extract sfzj.zip, apply each file in ips/<build>/ to the ROM file of the
same name (Flips, Lunar IPS, or any IPS tool), then re-zip everything
as sfzj.zip.

CHANGED FILES

  USA (English) (--variant usa):
    sfz.01  (128 KB)  CRC32 ffffec7d -> 01af54e8
    sfz.04b  (512 KB)  CRC32 8b73b0e5 -> 8d9b2480
    sfz.05a  (512 KB)  CRC32 0810544d -> 8cf0a98f
    sfz.06  (512 KB)  CRC32 806e8f38 -> fe2560d3
    sfz.14m  (2.0 MB)  CRC32 90fefdb3 -> 64daf202
    sfz.16m  (2.0 MB)  CRC32 5354c948 -> b2271b64
    sfz.18m  (2.0 MB)  CRC32 41a1e790 -> 640b3fc1
    sfz.20m  (2.0 MB)  CRC32 a549df98 -> d71c6dac
    sfzj.03c  (512 KB)  CRC32 f5444120 -> c5af217d

  Japan (Japanese) (--variant japan):
    sfz.01  (128 KB)  CRC32 ffffec7d -> 01af54e8
    sfz.04b  (512 KB)  CRC32 8b73b0e5 -> 8d9b2480
    sfz.05a  (512 KB)  CRC32 0810544d -> fa9ceda6
    sfz.06  (512 KB)  CRC32 806e8f38 -> 734c626f
    sfz.14m  (2.0 MB)  CRC32 90fefdb3 -> a539aa8c
    sfz.16m  (2.0 MB)  CRC32 5354c948 -> e55eaadc
    sfz.18m  (2.0 MB)  CRC32 41a1e790 -> 44a07ddd
    sfz.20m  (2.0 MB)  CRC32 a549df98 -> a9891558
    sfzj.03c  (512 KB)  CRC32 f5444120 -> 57e23cad

  Asia (English) (--variant asia):
    sfz.01  (128 KB)  CRC32 ffffec7d -> 01af54e8
    sfz.04b  (512 KB)  CRC32 8b73b0e5 -> 8d9b2480
    sfz.05a  (512 KB)  CRC32 0810544d -> 8cf0a98f
    sfz.06  (512 KB)  CRC32 806e8f38 -> 24ff7ad1
    sfz.14m  (2.0 MB)  CRC32 90fefdb3 -> d2fa804e
    sfz.16m  (2.0 MB)  CRC32 5354c948 -> 265039b7
    sfz.18m  (2.0 MB)  CRC32 41a1e790 -> ed1f7b1f
    sfz.20m  (2.0 MB)  CRC32 a549df98 -> f7da68fe
    sfzj.03c  (512 KB)  CRC32 f5444120 -> 71acb7f6

All other files in the set are unmodified.

LEGAL

This is a free, unofficial fan patch. It is not affiliated with or endorsed
by Capcom. All game titles, characters, and artwork remain the property of
their respective owners. You must own the game to use this patch. Do not
sell this patch or distribute it applied to a ROM image.

DARKSOFT OUTPUT

Use --platform darksoft --out-dir out, or --platform all.
Copy the game folder from out/darksoft/games to the card games folder.
Expanded hardware and streamed audio are not supported.
