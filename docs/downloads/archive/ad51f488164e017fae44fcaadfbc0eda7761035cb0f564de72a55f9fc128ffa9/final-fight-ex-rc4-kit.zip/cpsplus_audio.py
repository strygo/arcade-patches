from pathlib import Path
def data_track(disc, work, *, require_audio=False):
    """Use the same explicitly supplied rip for scene data and its CD audio."""
    from pack import discsrc
    discsrc.DISC_CACHE = Path(work) / "discs"
    disc = Path(disc).resolve()
    if disc.suffix.lower() in (".bin", ".img"):
        if require_audio:
            raise ValueError("CPS+ needs the complete disc: pass its .cue or a ZIP/7z containing it, "
                             "or use --audio arcade with a raw track image")
        image = disc
    else:
        # Optional CHD support uses the existing CPS+ reader and chdman.
        # Put any extraction in this invocation's own disposable tree.
        from pack import sources
        sources.CACHE_DIR = Path(work) / "disc-cache"
        cue = discsrc.descriptor(disc)
        if cue.suffix.lower() != ".cue":
            raise ValueError("Final Fight CD needs a .cue descriptor")
        tracks, _ = discsrc.extract_cdda.parse_cue(cue)
        number, mode, image, _, start, _ = tracks[0]
        if number != 1 or mode.upper() != "MODE1/2352" or start != 0:
            raise ValueError("Track 1 must be MODE1/2352 at the start of its image")
        if require_audio and any(not image.is_file() for _, _, image, *_ in tracks):
            raise ValueError("Keep every audio image beside the disc descriptor")
        if require_audio and not any(mode.upper() == "AUDIO" for _, mode, *_ in tracks):
            raise ValueError("The supplied disc has no CD audio tracks")
    with image.open("rb") as stream:
        head = stream.read(12)
    if head != b"\0" + b"\xff" * 10 + b"\0" or image.stat().st_size % 2352:
        raise ValueError("The disc data track is not a raw 2352-byte MODE1 image")
    return image.resolve()
