# Media tools

The MiSTer soundtrack build needs NumPy and the pinned FFmpeg/ffprobe pair.
Arcade-only reconstruction uses Python's standard library. Pillow and scene
rendering are not required. ZIP input uses Python directly; 7z and CHD inputs
also need 7-Zip and chdman respectively.

The builder downloads a missing helper only when needed, verifies its archive
and installed files against the included SHA-256 manifest, and reuses the
verified cache. No recipient compiler, Git or CMake is required.

Use `--tools-cache DIRECTORY` to select the cache. For offline use, supply
`--tools-bundle cpsplus-tools-v3-offline.zip --offline` on the build command.
The equivalent environment variables are `CPSPLUS_SWITCH_TOOLS_CACHE`,
`CPSPLUS_SWITCH_TOOLS_BUNDLE` and `CPSPLUS_SWITCH_TOOLS_OFFLINE=1`.

Helpers are available for macOS 11+ (Apple Silicon and Intel), Ubuntu 24.04+
(ARM64 and x86-64), Windows x64, and Windows 11 ARM through x64 emulation.
The collection interface declares its supported Python environments and
installs their pinned NumPy wheel privately. For the standalone command,
install NumPy into your Python environment before building a soundtrack.

The FFmpeg build disables optional external libraries, networking, GPL and
nonfree features. FFmpeg and ffprobe are LGPL 2.1 or later. Each helper archive
includes licenses, source identity, configuration and a standalone build
recipe. Corresponding source and binary assets are available at:
https://github.com/strygo/arcade-patches/releases/tag/ffmpeg-helpers-v1

Optional archive and CHD helpers retain their separate GPL/LGPL licenses.
Their source companion is `optional-helpers-v1-sources.zip`; source, binaries
and the offline bundle are available at:
https://github.com/strygo/arcade-patches/releases/tag/optional-helpers-v1

Advanced users can select executables with `CPSPLUS_FFMPEG`, `CPSPLUS_FFPROBE`,
`CPSPLUS_CHDMAN` or `CPSPLUS_SEVENZIP`. Explicit overrides must work and are
outside the pinned helper qualification. Complete output hashes still apply.

Python, NumPy when building audio, and your original arcade ROMs and matching
regional Final Fight CD media remain required. No game media are downloaded.
