"""Bounded reconstruction from authenticated source copies and keyed resources."""
import hashlib
import lzma
import zlib

SCHEMA = 'arcade-resource-recipes/1'
LIMIT = 32 * 1024**2


def require(ok, message):
    if not ok:
        raise ValueError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def mask(data, counterpart, label):
    key = hashlib.shake_256(b'arcade resource recipes\0' + label.encode() + b'\0' + counterpart).digest(len(data))
    return (int.from_bytes(data, 'big') ^ int.from_bytes(key, 'big')).to_bytes(len(data), 'big')


class Resources:
    def __init__(self, plan, payload, sources):
        require(plan.get('schema') == SCHEMA, 'Unknown resource schema')
        require(set(sources) == set(plan['sources']), 'Source view extent differs')
        for name, spec in plan['sources'].items():
            require(len(sources[name]) == spec['bytes'] and sha(sources[name]) == spec['sha256'],
                    'Source view differs: ' + name)
        require(len(payload) == plan['payload']['bytes'] and sha(payload) == plan['payload']['sha256'],
                'Resource payload differs')
        self.plan, self.payload, self.sources = plan, payload, sources
        spans = sorted((s['offset'], s['bytes']) for s in plan['blobs'].values())
        end = 0
        for at, count in spans:
            require(type(at) is int and type(count) is int and at == end and count > 0,
                    'Resource container has a gap, overlap or invalid extent')
            end += count
        require(end == len(payload), 'Resource container has trailing or missing data')

    def source(self, name, at, count):
        require(name in self.sources and type(at) is int and type(count) is int and at >= 0
                and count > 0 and at + count <= len(self.sources[name]), 'Invalid source-copy extent')
        return self.sources[name][at:at + count]

    def blob(self, name):
        require(name in self.plan['blobs'], 'Unknown resource')
        row = self.plan['blobs'][name]
        n = row['decoded_bytes']
        require(type(n) is int and 0 < n <= LIMIT, 'Invalid decoded resource size')
        cp = row['counterpart']
        source = self.source(cp['source'], cp['offset'], cp['bytes'])
        raw = mask(self.payload[row['offset']:row['offset'] + row['bytes']], source, row['sha256'])
        try:
            if row['compression'] == 'xz':
                decoder = lzma.LZMADecompressor(memlimit=64 * 1024**2)
                data = decoder.decompress(raw, max_length=n + 1)
            elif row['compression'] == 'zlib':
                decoder = zlib.decompressobj()
                data = decoder.decompress(raw, max_length=n + 1)
            else:
                raise ValueError('Unknown resource compression')
        except (lzma.LZMAError, zlib.error) as exc:
            raise ValueError('Resource counterpart or compressed data differs') from exc
        require(len(data) == n and decoder.eof and not decoder.unused_data and sha(data) == row['sha256'],
                'Decoded resource differs')
        return data

    def emit(self, row):
        require(type(row['bytes']) is int and 0 < row['bytes'] <= LIMIT, 'Invalid output size')
        out = bytearray()
        for op in row['ops']:
            require(isinstance(op, dict) and len(op) == 1, 'Ambiguous resource operation')
            if 'copy' in op:
                data = self.source(*op['copy'])
            elif 'fill' in op:
                value, n = op['fill']
                require(type(value) is int and 0 <= value <= 255 and type(n) is int
                        and 0 < n <= row['bytes'] - len(out), 'Invalid fill extent')
                data = bytes([value]) * n
            elif 'blob' in op:
                data = self.blob(op['blob'])
            elif 'xor' in op:
                source, at, count, blob = op['xor']
                base, delta = self.source(source, at, count), self.blob(blob)
                require(len(base) == len(delta), 'XOR extents differ')
                data = (int.from_bytes(base, 'big') ^ int.from_bytes(delta, 'big')).to_bytes(count, 'big')
            else:
                raise ValueError('Unknown resource operation')
            require(len(out) + len(data) <= row['bytes'], 'Resource output overrun')
            out.extend(data)
        require(len(out) == row['bytes'] and sha(out) == row['sha256'], 'Complete resource output differs')
        return bytes(out)
