WORLD = ['ff_36.11f', 'ff_42.11h', 'ff-32m.8h', 'ff_37.12f', 'ff_09.12b', 'ff-5m.7a', 'ff-7m.9a', 'ff-1m.3a', 'ff-3m.5a']
