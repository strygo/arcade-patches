"""Reconstruct Strider EX from owned arcade sets and the PC Engine CD."""

import sys as _native_sys
from pathlib import Path as _NativePath
if __name__ == '__main__' and ('--collection-layout' in _native_sys.argv or '--describe-json' in _native_sys.argv or '--emit-definition' in _native_sys.argv):
    _native_sys.path.insert(0, str(_NativePath(__file__).resolve().parent))
    from native_collection import main as _native_main
    raise SystemExit(_native_main(_NativePath(__file__).resolve().parent))
import argparse
import hashlib
import json
import os
from pathlib import Path, PureWindowsPath
import re
import shutil
import subprocess
import sys
import tempfile
import xml.etree.ElementTree as ET
import zipfile
KIT = Path(__file__).resolve().parent
ROOT = KIT / 'builder'
sys.path[:0] = [str(ROOT), str(ROOT / 'backports/striderex/scripts'), str(ROOT / 'backports/striderex/ship'), str(ROOT / 'cpsplus/tools'), str(ROOT / 'cpsplus/integration'), str(ROOT / 'release')]
CORE = 'jtcps1-cpsplus'
CORE_FILE = 'jtcps1-cpsplus_20261009.rbf'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def verify_outputs(out, a):
    from output_checks import check_outputs
    return check_outputs(out, json.loads((KIT / 'outputs.json').read_text()), a.region, a.audio, a.platform)

def verify_kit():
    pins = json.loads((KIT / 'kit.json').read_text())['files']
    for directory in ('builder', 'core', 'data', 'hash', 'tools'):
        actual = {p.relative_to(KIT).as_posix() for p in (KIT / directory).rglob('*') if p.is_file() and '__pycache__' not in p.parts and (p.name != '.DS_Store')}
        if actual != {n for n in pins if n.startswith(directory + '/')}:
            raise ValueError('kit dependency contents differ: ' + directory)
    for n, h in pins.items():
        if sha((KIT / n).read_bytes()) != h:
            raise ValueError('kit file changed: ' + n)

def check_x68k(source):
    from restore_tunes import load_bank
    _, identity = load_bank(source)
    if identity != json.loads((KIT / 'release-material.json').read_text())['x68k']:
        raise ValueError('X68000 System disk music identity differs')

def output_path(path, inputs):
    path = path.resolve()
    if path == KIT or KIT.is_relative_to(path):
        raise ValueError('output overlaps the reconstruction kit')
    if path.is_relative_to(KIT):
        first = path.relative_to(KIT).parts[0]
        if first in ('builder', 'core', 'data', 'hash', 'tools') or (KIT / first).is_file():
            raise ValueError('output overlaps kit dependencies')
    for value in inputs:
        value = value.resolve()
        if value == path or value.is_relative_to(path) or (value.is_dir() and path.is_relative_to(value)):
            raise ValueError('output overlaps owned inputs')
    return path

def rom_sources(path):
    if not path.is_dir():
        return [path]
    return [path / (name + suffix) for name in ('strider', 'striderua', 'striderjr') for suffix in ('', '.zip', '.7z')]

def unzip(path, out):
    with zipfile.ZipFile(path) as z:
        names = z.namelist()
        if len(names) != len(set(names)):
            raise ValueError('duplicate archive members')
        for i in z.infolist():
            p = out / i.filename
            if not p.resolve().is_relative_to(out.resolve()) or i.external_attr >> 16 & 61440 == 40960:
                raise ValueError('unsafe archive member')
            if i.is_dir():
                p.mkdir(parents=True, exist_ok=True)
            else:
                p.parent.mkdir(parents=True, exist_ok=True)
                p.write_bytes(z.read(i))

def sevenzip():
    for n in ('7zz', '7z', '7za'):
        found = shutil.which(n)
        if found:
            return found
    raise ValueError('7z input requires 7-Zip (7zz or 7z)')

def extract(path, out):
    if path.suffix.lower() == '.zip':
        unzip(path, out)
    elif path.suffix.lower() == '.7z':
        out.mkdir(parents=True, exist_ok=False)
        tool = sevenzip()
        listing = subprocess.check_output([tool, 'l', '-slt', '-ba', '-sccUTF-8', str(path)], text=True)
        for block in listing.split('\n\n'):
            row = dict((line.split(' = ', 1) for line in block.splitlines() if ' = ' in line))
            if 'Path' not in row:
                continue
            name = row['Path'].replace('\\', '/')
            target = (out / name).resolve()
            if PureWindowsPath(name).drive or not target.is_relative_to(out.resolve()) or any((k in row for k in ('Symbolic Link', 'Hard Link'))) or (row.get('Encrypted') == '+'):
                raise ValueError('unsafe or encrypted archive member')
        subprocess.run([tool, 'x', '-y', f'-o{out}', str(path)], check=True, stdout=subprocess.DEVNULL)
        if any((p.is_symlink() for p in out.rglob('*'))):
            raise ValueError('archive symlink')
    else:
        raise ValueError('expected ZIP or 7z archive')

def stock_inputs(source, out, work):
    manifest = json.loads((KIT / 'rom_inputs.json').read_text())
    pins = manifest['sets']
    auxiliary = manifest['mame_aux']
    needed = {r['sha256'] for group in (pins, auxiliary) for rows in group.values() for r in rows.values()}
    candidates = []
    if source.is_dir():
        for n in ('strider', 'striderua', 'striderjr'):
            d = source / n
            if d.is_dir():
                candidates.extend((p for p in d.iterdir() if p.is_file()))
            for ext in ('.zip', '.7z'):
                if (source / (n + ext)).is_file():
                    candidates.append(source / (n + ext))
    else:
        candidates = [source]
    pool = {}
    for i, p in enumerate(candidates):
        if p.suffix.lower() in ('.zip', '.7z'):
            dest = work / f'rom-archive-{i}'
            extract(p, dest)
            files = list(dest.rglob('*'))
        else:
            files = [p]
        for q in files:
            if q.is_file():
                data = q.read_bytes()
                h = sha(data)
                if h in needed:
                    pool[h] = data
    for machine, rows in pins.items():
        dest = out / machine
        dest.mkdir(parents=True)
        for n, s in (rows | auxiliary[machine]).items():
            data = pool.get(s['sha256'])
            if data is None or len(data) != s['bytes']:
                raise ValueError('missing canonical ROM: ' + machine + '/' + n)
            (dest / n).write_bytes(data)
    (out / 'strider').mkdir()

def check_stock(mame, roms):
    for machine in ('striderua', 'striderjr'):
        run = subprocess.run([str(mame), machine, '-noreadconfig', '-rompath', str(roms), '-verifyroms'], capture_output=True, text=True, env=dict(os.environ, SDL_VIDEODRIVER='dummy', SDL_AUDIODRIVER='dummy'))
        if run.returncode:
            raise ValueError('Incomplete stock inputs for ' + machine + ':\n' + run.stdout + run.stderr)

def owned_disc(source, work):
    if source.suffix.lower() in ('.zip', '.7z'):
        dest = work / 'disc'
        extract(source, dest)
        cues = list(dest.rglob('*.cue'))
        if len(cues) != 1:
            raise ValueError('disc archive needs one CUE sheet and all tracks')
        cue = cues[0]
    else:
        cue = source
    if cue.suffix.lower() != '.cue':
        raise ValueError('supply the complete split-bin disc or its archive')
    pins = json.loads((KIT / 'disc_inputs.json').read_text())['files']
    tracks = {}
    for n, spec in pins.items():
        p = cue.parent / n
        if not p.is_file() or p.stat().st_size != spec['bytes'] or sha(p.read_bytes()) != spec['sha256']:
            raise ValueError('disc track missing or incorrect: ' + n)
        m = re.search('\\(Track (\\d+)\\)', n)
        if m:
            tracks[int(m[1])] = p
    return (cue, tracks)

def zip_members(path, members):
    path.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(path, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for n, b in sorted(members.items()):
            info = zipfile.ZipInfo(n, (2026, 10, 26, 0, 0, 0))
            info.external_attr = 33188 << 16
            info.create_system = 3
            info.compress_type = zipfile.ZIP_DEFLATED
            z.writestr(info, b, compresslevel=6)

def make_pack(cue, tracks, captures, work):
    from cpsplus.pack import build_strider_ex as B
    import boss_voice_overlay as V
    import gameplay_music as M
    from types import SimpleNamespace as N
    recipe = json.loads((ROOT / 'cpsplus/manifests/strider_pce_audio.json').read_text())
    recipe['source']['disc_sha256'] = B.digest(cue)
    p = work / 'audio-recipe.json'
    p.write_text(json.dumps(recipe))
    B.disc_bins = lambda disc, ns: {n: tracks[n].read_bytes() for n in ns}
    B.build(recipe_path=p, disc=cue, outdir=work / 'pack-base', english=KIT / 'data/strider_ex_english.dub', portraits=captures / 'portraits')
    V.overlay(N(pack=work / 'pack-base/strider_ex.cpk', voices=KIT / 'data/voices', out=work / 'boss-english.cpk'))
    M.produce(N(pack=work / 'boss-english.cpk', disc_dir=cue.parent, recipe=M.RECIPE, out=work / 'pack-final'))
    path = work / 'pack-final/strider_ex.cpk'
    expected = json.loads((KIT / 'release-material.json').read_text())['pack_sha256']
    if sha(path.read_bytes()) != expected:
        raise ValueError('arranged pack differs from approved content')
    return path

def outputs(a, build, roms, pack, out):
    import ex_kit as E
    import ex_release as R
    import hbmame_set as H
    from embed_pack_mra import embed
    parents = json.loads((KIT / 'hbmame_parents.json').read_text())['blocks']
    man = H.manifest()
    meta = json.loads((build / 'build.json').read_text())
    from public_receipt import portable, check
    receipt = dict(schema='striderex-reconstructed-build/1', build=portable(meta))
    for name in ('captions', 'stills', 'frames'):
        receipt[name] = portable(json.loads((build / (name + '.json')).read_text()))
    check(receipt, json.loads((KIT / 'receipt-contract.json').read_text()))
    (out / 'BUILD-RECEIPT.json').write_text(json.dumps(receipt, indent=2, sort_keys=True) + '\n', encoding='utf-8', newline='\n')
    for spec in man['sets']:
        machine = spec['parent_set']
        jp = machine == 'striderjr'
        region = 'jp' if jp else 'us'
        if a.region not in ('both', region):
            continue
        stock = H.set_files(roms, machine)
        ex = {n: (build / machine / n).read_bytes() for n in meta['sets'][machine]['files']}
        members, driver = H.compose(spec, man['ex_members'], parents[machine], stock, ex)
        name = spec['name']
        zipname = name + '.zip'
        if a.platform in ('both', 'hbmame'):
            zip_members(out / 'hbmame' / zipname, members)
            date = json.loads((KIT / 'release-material.json').read_text())['date']
            (out / 'hbmame' / (name + '.cpp')).write_text(driver + '\n\n' + H.game_line(spec, date) + '\n', encoding='utf-8', newline='\n')
        if a.platform == 'hbmame':
            continue
        zip_members(out / 'mister/games/hbmame' / zipname, members)
        base, source_members = R.members_for(argparse.Namespace(build=build, rom_dir=roms), machine)
        by_sha = {sha(b): n for n, b in members.items()}
        binding = {n: by_sha[sha(b)] for n, b in source_members.items()}
        title = 'Strider Hiryu EX (Japan)' if jp else 'Strider EX (USA)'
        root = out / 'mister/_Arcade/_Arcade Patches'
        variants = []
        if a.audio in ('both', 'arcade'):
            variants.append((root / '_Enhanced Versions', title, 0, False))
        if a.audio in ('both', 'cpsplus'):
            folder = root / '_Arrangements/_CPS+'
            variants.append((folder, title + ' [Arrange]', 1, True))
            label = 'English voices' if jp else 'Japanese voices'
            variants.append((folder, title + f' [Arrange, {label}]', 5 if jp else 3, True))
        for folder, label, flag, arranged in variants:
            if jp:
                folder = folder / '_Japan'
            folder.mkdir(parents=True, exist_ok=True)
            text = E.make_mra(base, machine, label, CORE, '/hbmame/' + zipname, source_members)
            rootxml = ET.fromstring(text)
            for part in rootxml.findall('.//part'):
                n = part.get('name')
                if n in binding:
                    part.set('name', binding[n])
            if arranged:
                text = ET.tostring(rootxml, encoding='unicode')
                with tempfile.TemporaryDirectory() as temp:
                    basepath = Path(temp) / 'base.mra'
                    basepath.write_text(text)
                    tree, _ = embed(str(basepath), pack.stat().st_size, 'strider_ex.cpk', R.ROM_TOTAL, pack_zip='/CPS+/strider_ex.zip', display_name=label, rbf=CORE, extra_patches=[(R.FLAG_ADDR, flag)])
                    rootxml = tree.getroot()
            for field, value in dict(setname=name, platform='CPS-1', category='Platform', catver='Platform / Fighter Scrolling', mraauthor='jotego,strygo').items():
                element = rootxml.find(field)
                if element is None:
                    element = ET.SubElement(rootxml, field)
                element.text = value
            legal = base.split('<misterromdescription>', 1)[0]
            (folder / (label + '.mra')).write_text(legal + ET.tostring(rootxml, encoding='unicode') + '\n', encoding='utf-8', newline='\n')
    if a.platform in ('both', 'mister'):
        core = out / 'mister/_Arcade/cores' / CORE_FILE
        core.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(KIT / 'core' / CORE_FILE, core)
        if pack:
            zip_members(out / 'mister/games/CPS+/strider_ex.zip', {'strider_ex.cpk': pack.read_bytes()})

def main():
    from kit_runtime import enable_utf8
    enable_utf8()
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--debug', action='store_true', help='show diagnostic tracebacks')
    for n in ('disc', 'romset', 'bios', 'out-dir'):
        p.add_argument('--' + n, type=Path, required=True)
    p.add_argument('--x68k', type=Path, required=True, help='loose X68000 System disk DIM, or any ZIP containing that disk')
    p.add_argument('--region', choices=('both', 'us', 'jp'), default='both')
    p.add_argument('--audio', choices=('both', 'arcade', 'cpsplus'), default='both')
    p.add_argument('--platform', choices=('both', 'mister', 'hbmame'), default='both')
    p.add_argument('--mame', type=Path, help='MAME 0.288 override; Linux uses the included pinned helper by default')
    p.add_argument('--vasm', type=Path, help='optional developer assembler override; default uses included code payloads')
    p.add_argument('--work', type=Path)
    p.add_argument('--jobs', type=int, default=3)
    p.add_argument('--check', action='store_true')
    import ffmpeg_runtime
    a = p.parse_args(ffmpeg_runtime.configure(sys.argv[1:]))
    verify_kit()
    import mame_runtime
    try:
        a.mame = mame_runtime.resolve(a.mame)
    except mame_runtime.MameError as exc:
        p.error(str(exc))
    a.out_dir = output_path(a.out_dir, [a.disc, a.bios, a.x68k, *rom_sources(a.romset)])
    if a.work:
        a.work.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='striderex-', dir=a.work) as temp:
        work = Path(temp)
        cue, tracks = owned_disc(a.disc.resolve(), work)
        stock_inputs(a.romset.resolve(), work / 'roms', work)
        check_stock(a.mame, work / 'roms')
        bios = a.bios.read_bytes()
        if hashlib.sha1(bios).hexdigest() != '79f5ff55dd10187c7fd7b8daab0b3ffbd1f56a2c':
            raise ValueError('expected unheadered Japanese Super CD-ROM System v3.0 BIOS')
        b = work / 'bios/pce/acardpro'
        b.mkdir(parents=True)
        (b / '[cd] super cd-rom system (japan) (v3.0).pce').write_bytes(bios)
        check_x68k(a.x68k.resolve())
        if a.check:
            print('All selected source inputs verified')
            return
        from capture_inputs import capture
        from source_build import build
        from types import SimpleNamespace as N
        os.environ.update(STREX_MAME=str(a.mame), STREX_MAME_HASH=str(KIT / 'hash'))
        assembler = a.vasm.resolve() if a.vasm else KIT / 'preassembled.json'
        capture(cue, work / 'bios', work / 'roms', a.mame, work / 'captures', a.jobs)
        built = build(N(out=work / 'build', captures=work / 'captures', rom_dir=work / 'roms', vasm=assembler, voices=KIT / 'data/voices', x68k=a.x68k.resolve()))
        pack = make_pack(cue, tracks, work / 'captures', work) if a.audio != 'arcade' and a.platform != 'hbmame' else None
        final = work / 'outputs'
        final.mkdir()
        outputs(a, built, work / 'roms', pack, final)
        verify_outputs(final, a)
        for q in final.rglob('*'):
            dest = a.out_dir / q.relative_to(final)
            for parent in (dest.parent, *dest.parents):
                if parent.exists() and (not parent.is_dir()):
                    raise ValueError('output parent is not a directory: ' + str(parent))
            if q.is_file() and dest.exists() and (not dest.is_file() or sha(dest.read_bytes()) != sha(q.read_bytes())):
                raise ValueError('output conflict: ' + str(dest))
        shutil.copytree(final, a.out_dir, dirs_exist_ok=True)
        print('Strider EX reconstructed:', a.out_dir, flush=True)
# BEGIN STANDALONE ERROR HANDLER
if __name__ == '__main__':
    try:
        main()
    except (OSError, ValueError, zipfile.BadZipFile, subprocess.SubprocessError) as exc:
        if '--debug' in sys.argv:
            raise
        raise SystemExit(f'ERROR: {exc}')
