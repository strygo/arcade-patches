Marvel Super Heroes vs. Street Fighter · English restoration
============================================================

Version:  rc1 (2026-09-17)
Target:   MAME set 'mshvsfj' (Marvel Super Heroes vs. Street Fighter (Japan 970707))
Hardware: Capcom CPS-2
Patch by: Steve Gordon (https://x.com/strygo)
Website:  https://arcadepatches.com/mshvsf-restoration/

ABOUT THIS PROJECT

Marvel Super Heroes vs. Street Fighter wasn't the same game everywhere. The
Japanese version has Norimaro on the select screen with his own ending, real
endings for Mech-Zangief, Shadow and Dark Sakura, and sixteen win quotes per
fighter. The US version dropped Norimaro entirely, gave the secret fighters a
generic ending, and cut the win quotes to eight.

The English Restoration is the Japanese game, in English. Norimaro is back,
with his ending. The secret fighters get their own endings and art. All
sixteen win quotes per fighter and all seventeen standard endings are
translated fresh from the Japanese.

Nothing else changes. The title, the secret-character codes, the team rules
and the bosses are exactly as they were, and the fighting is untouched. If you
want more, like playable bosses, any team you like, extra colors and eight
speeds, that's EX, which includes everything here.

There are two builds. The USA build is the English one. The Japan build keeps
its Japanese text and gets the few fixes that apply to it. Both run in MAME,
HBMAME and on MiSTer.

This is a release candidate. Both builds boot and have been checked in MAME;
longer play testing and a MiSTer hardware pass are still to come.

WHAT'S CHANGED

  - Norimaro is back, on the select screen and as a computer opponent
  - Norimaro's own ending, in English
  - Mech-Zangief, Shadow and Dark Sakura get their own endings and art,
    instead of the generic one
  - Sixteen win quotes per fighter, translated from the Japanese (the US
    version has eight)
  - All seventeen standard endings, translated from the Japanese
  - Japan build: the same fixes, with the Japanese text kept
  - Title, codes, team rules, bosses and gameplay untouched

BUILDS IN THIS DOWNLOAD

    usa        USA (English)
    japan      Japan (Japanese)

HOW TO APPLY (recommended)

    python3 apply.py /path/to/mshvsfj.zip --out-dir out

This checks every file against the original, applies the patches, checks
the result, and writes everything you need for every build (add
--variant <build> to make just one):

  USA (English):
    MAME / original hardware: out/mame/usa/mshvsfj.zip
    HBMAME:                   out/hbmame/mshvsfru.zip
    MiSTer:                   out/mister/_Arcade/_Arcade Patches/_Restorations/Marvel Super Heroes Vs. Street Fighter (USA) [English Restoration].mra
  Japan (Japanese):
    MAME / original hardware: out/mame/japan/mshvsfj.zip
    HBMAME:                   out/hbmame/mshvsfrj.zip
    MiSTer:                   out/mister/_Arcade/_Arcade Patches/_Restorations/_Japan/Marvel Super Heroes Vs. Street Fighter (Japan) [Restoration].mra

Merged, split and complete sets work, including nested or renamed ROMs.
Use --rompath DIR (repeatable) to search a collection instead of naming the
zip, and --check to check inputs before building. ZIPs and extracted folders
need no extra software; 7z archives need 7-Zip. QSound can stay in your
emulator's ROM path; valid firmware already in a source set is kept in
complete outputs.

MAME: put mshvsfj.zip from out/mame/ ahead of the stock set in your MAME
rompath (one build at a time: they share the set name).
MAME's game menu won't start a set with patched ROMs, so start it from the
command line: mame mshvsfj. MAME shows checksum warnings for the patched
ROMs; that's expected and the game runs normally.
To start it from a menu, use the HBMAME build.

HBMAME: this restoration's builds are official HBMAME sets
(mshvsfru and mshvsfrj), so full HBMAME collections may already carry them.
Put the zip in HBMAME's roms/ folder next to your stock mshvsfj.zip.
It loads with no checksum warnings.

MiSTer: copy the _Arcade folder from out/mister/ to the root of your SD card
and keep the stock, unmodified romset at games/mame/mshvsfj.zip (split MAME
sets also need qsound.zip). The MRA applies the restoration in memory as the
game loads, so nothing on the card is modified. You need Jotego's jtcps2
core, which update_all installs. The MRAs are also a separate download.

HOW TO APPLY (any IPS patcher)

Extract mshvsfj.zip, apply each file in ips/<build>/ to the ROM file of the
same name (Flips, Lunar IPS, or any IPS tool), then re-zip everything
as mshvsfj.zip.

CHANGED FILES

  USA (English) (--variant usa):
    mvs.05h  (512 KB)  CRC32 77870dc3 -> ee5c165e
    mvs.07b  (512 KB)  CRC32 7f915bdb -> fa820660
    mvsj.03i  (512 KB)  CRC32 d8cbb691 -> 4de13b47
    mvsj.04i  (512 KB)  CRC32 32741ace -> 0908cb52

  Japan (Japanese) (--variant japan):
    mvs.05h  (512 KB)  CRC32 77870dc3 -> ee5c165e
    mvs.07b  (512 KB)  CRC32 7f915bdb -> fa820660
    mvsj.03i  (512 KB)  CRC32 d8cbb691 -> fa080b10
    mvsj.04i  (512 KB)  CRC32 32741ace -> 0908cb52

All other files in the set are unmodified.

LEGAL

This is a free, unofficial fan patch. It is not affiliated with or endorsed
by Capcom. All game titles, characters, and artwork remain the property of
their respective owners. You must own the game to use this patch. Do not
sell this patch or distribute it applied to a ROM image.
