Street Fighter Zero 2 Alpha · English restoration
=================================================

Version:  rc1 (2026-09-17)
Target:   MAME set 'sfz2al' (Street Fighter Zero 2 Alpha (Asia 960826))
Hardware: Capcom CPS-2
Patch by: Steve Gordon (https://x.com/strygo)
Website:  https://arcadepatches.com/sfz2al-restoration/

ABOUT THIS PROJECT

Street Fighter Zero 2 Alpha is the updated Alpha 2, and its Asian version
plays in English. But that English script was a shortened one. Story scenes
lost pages, Evil Ryu borrowed Ryu's ending, and each fighter picked from four
random win quotes instead of the hundreds the Japanese game has.

The English Restoration is the Japanese script, in English. Every story and
ending page is back, in the Japanese order. Evil Ryu has his own ending again,
and his scene with Akuma. All 452 win quotes are here, picked by who you beat
and how much health you had left, just like in Japan. Where Capcom's English
said the same thing as the Japanese it's kept; everything else is newly
translated.

A few smaller things come along: red blood on hits, as in Japan; Birdie's
third victory pose, which the export version swapped out; and the Manual guard
panel on the select screen now explains itself.

The fighting is untouched, and the ROM sizes and key stay stock, so it drops
in over the Asian set in MAME, HBMAME, on MiSTer or on original CPS-2
hardware. The same restoration is in the English builds of Street Fighter
Alpha 2 Gold.

This is a release candidate. It has been checked in MAME, route by route; a
MiSTer hardware pass is still to come.

WHAT'S CHANGED

  - Every story page from the Japanese game, in the Japanese order, including
    the scenes the English script cut short
  - Evil Ryu's own ending, with his narration, instead of Ryu's
  - Evil Ryu's scene with Akuma, back in
  - All 452 win quotes from the Japanese game, in English, picked by opponent
    and remaining health, and centered on screen
  - Every ending in full, in English
  - Story, ending and quote text translated from the Japanese, keeping
    Capcom's English wherever it matched
  - Red blood on hits, as in Japan
  - Birdie's third victory pose, back
  - The Manual guard panel explains itself (it appears when the operator turns
    on Auto Guard)
  - Gameplay untouched

HOW TO APPLY (recommended)

    python3 apply.py /path/to/sfz2al.zip --out-dir out

This checks every file against the original, applies the patches, checks
the result, and writes everything you need for each platform:

  MAME / original hardware: out/mame/sfz2al.zip
  HBMAME:                   out/hbmame/sfz2alr.zip
  MiSTer:                   out/mister/_Arcade/_Arcade Patches/_Restorations/_Asia/Street Fighter Zero 2 Alpha (Asia) [English Restoration].mra

Merged, split and complete sets work, including nested or renamed ROMs.
Use --rompath DIR (repeatable) to search a collection instead of naming the
zip, and --check to check inputs before building. ZIPs and extracted folders
need no extra software; 7z archives need 7-Zip. QSound can stay in your
emulator's ROM path; valid firmware already in a source set is kept in
complete outputs.

MAME: put sfz2al.zip from out/mame/ ahead of the stock set in your MAME
rompath.
MAME's game menu won't start a set with patched ROMs, so start it from the
command line: mame sfz2al. MAME shows checksum warnings for the patched
ROMs; that's expected and the game runs normally.
To start it from a menu, use the HBMAME build.

HBMAME: this restoration is an official HBMAME set (sfz2alr),
so full HBMAME collections may already carry it.
Put the zip in HBMAME's roms/ folder next to your stock sfz2al.zip.
It loads with no checksum warnings.

MiSTer: copy the _Arcade folder from out/mister/ to the root of your SD card
and keep the stock, unmodified romset at games/mame/sfz2al.zip (split MAME
sets also need qsound.zip). The MRA applies the restoration in memory as the
game loads, so nothing on the card is modified. You need Jotego's jtcps2
core, which update_all installs. The MRAs are also a separate download.

HOW TO APPLY (any IPS patcher)

Extract sfz2al.zip, apply each file in ips/ to the ROM file of the
same name (Flips, Lunar IPS, or any IPS tool), then re-zip everything
as sfz2al.zip.

CHANGED FILES

    sza.13m  (4.0 MB)  CRC32 4d1f1f22 -> a669111c
    sza.15m  (4.0 MB)  CRC32 19cea680 -> 5136f828
    sza.17m  (4.0 MB)  CRC32 e01b4588 -> f52aadd7
    sza.19m  (4.0 MB)  CRC32 0feeda64 -> 619cf4b2
    szaa.03  (512 KB)  CRC32 88e7023e -> 48891fd5
    szaa.04  (512 KB)  CRC32 ae8ec36e -> 45807976
    szaa.05  (512 KB)  CRC32 f053a55e -> f132bb74
    szaa.07  (512 KB)  CRC32 5feb8b20 -> 13733b2b

All other files in the set are unmodified.

LEGAL

This is a free, unofficial fan patch. It is not affiliated with or endorsed
by Capcom. All game titles, characters, and artwork remain the property of
their respective owners. You must own the game to use this patch. Do not
sell this patch or distribute it applied to a ROM image.
