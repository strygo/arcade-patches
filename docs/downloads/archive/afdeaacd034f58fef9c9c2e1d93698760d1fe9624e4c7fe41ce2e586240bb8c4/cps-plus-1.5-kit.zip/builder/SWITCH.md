# The USF2 Remix pack: from the Switch game

Ultra Street Fighter II: The Final Challengers on Nintendo Switch carries
two scores: the arcade originals and a complete remixed soundtrack. This
pack is the remix, mapped onto the arcade music commands, so it plays in
Super Street Fighter II, Super Street Fighter II Turbo (with SSF2X), the
EX and Grand Master Challenge builds, and Hyper Street Fighter II. It holds
65 tracks. The select screen of Turbo, which USF2 does not score separately,
uses the remix's SSF2 select theme. The "Here comes a new challenger" sting
and HSF2's READY TO FIGHT cue stay as the arcade plays them.

## What you need

- **The game's .nsp**: the USA base game, title 01007330027EE000, version 0.
  Not an update or DLC package, and not inside a .zip or .rar: extract it
  first. The builder checks the file against the verified one and refuses
  any other.
- **Your prod.keys**. The builder hands its path to NSTool, which decrypts
  the game's files with it. The keys are read where they are, and never
  copied into the kit, the output or the packs.
- **git, cmake and a C/C++ compiler**, as for the X68000 packs: clang or gcc
  on a Mac or Linux; on Windows, Visual Studio 2019 or newer (Build Tools
  with "Desktop development with C++" is enough) or MinGW-w64. NSTool does
  not compile with Visual Studio 2017. The first run builds two pinned
  open-source programs under `work/`: NSTool, which reads Switch packages,
  and a decoder built on libopus, the Opus reference library. If CMake
  picks an older Visual Studio you also have installed, set
  `CMAKE_GENERATOR`, for example to `Visual Studio 17 2022`. Both programs
  must be 64-bit (x64 or arm64): 32-bit libopus rounds differently, so the
  decoder refuses to build for a 32-bit target.
- **About 4 GB of free space** while it runs. NSTool writes a temporary copy
  of the game's 2.9 GB program archive to extract the music, and the build
  deletes it afterwards.

Fill in `usf2_nsp` and `switch_prod_keys` in `discs.toml` and run
`make_packs.py` as usual, or build just this pack with
`python3 make_packs.py --only usf2-remix`.

## What "verified" means here

The game stores its music as Opus. The decoder is libopus built in fixed
point, with its processor-specific code turned off, so decoding is integer
arithmetic and every computer produces the same samples. That is what lets
the kit check your pack against one published hash, the same on a Mac, on
Windows and on Linux. A floating-point Opus decoder would not do this:
ffmpeg's, for one, rounds differently depending on the processor's vector
instructions.

If the build stops before decoding, it names the file that differed: the
.nsp (a different region, version or dump), or the program archive NSTool
extracted from it (usually a keys file without the keys this game needs).
