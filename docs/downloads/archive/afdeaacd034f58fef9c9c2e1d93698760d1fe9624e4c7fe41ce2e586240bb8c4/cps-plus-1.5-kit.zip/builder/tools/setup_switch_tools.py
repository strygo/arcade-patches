#!/usr/bin/env python3
"""Fetch and build the pinned tools the USF2 Remix pack reads its source with.

NSTool takes the music out of your Switch package with your own keys.  libopus, the Opus reference decoder, turns that music into PCM
through switch_opus_decode.c (beside this script).  libopus is built in fixed
point with its CPU-specific code disabled, so the decode is integer
arithmetic throughout and every machine produces the same samples -- which
is what lets the pack be checked against one published hash.  A floating-
point decoder, ffmpeg's included, rounds differently with the CPU's vector
instructions.

Both build through the same CMake helpers as setup_x68k_music_tools.py, so
they need git, cmake and a C/C++ compiler (clang, gcc, MinGW-w64, or Visual
Studio 2019 or newer: NSTool's sources need the v142 toolset or later).
CMAKE_GENERATOR and CMAKE_GENERATOR_PLATFORM in the environment choose among
several installed Visual Studios.  NSTool ships only makefiles and Visual Studio solutions; the CMake
project written here compiles what its makefiles compile.  Third-party source
and binaries stay below ``--root`` and are never part of any download.
Nothing here downloads keys or game data.
"""
from __future__ import annotations

import argparse
import os
import sys
import tempfile
from pathlib import Path

HERE = Path(os.path.abspath(__file__)).parent
sys.path.insert(0, str(HERE))
from setup_x68k_music_tools import (  # noqa: E402
    EXE, GIT, SetupError, _run, absolute, cmake_build, require_binary,
)


NSTOOL_REPOSITORY = "https://github.com/jakcron/nstool.git"
NSTOOL_COMMIT = "cfb826ca6c165fbcd816fd7949df88ef3d72a948"      # 2024-10-14
OPUS_REPOSITORY = "https://github.com/xiph/opus.git"
OPUS_COMMIT = "ddbe48383984d56acd9e1ab6a090c54ca6b735a6"        # v1.5.2
DECODER = "switch_opus_decode"

# NSTool's libraries, each an include/ and a src/ tree its makefile compiles
# whole, in link order.  libtoolchain supplies wmain() on Windows, which
# MinGW links only with -municode; -static is what NSTool's own makefile
# uses there, so the program needs no MinGW runtime DLLs.
NSTOOL_LIBRARIES = ("libpietendo", "libtoolchain", "libfmt", "liblz4", "libmbedtls")
NSTOOL_PROJECT = """\
cmake_minimum_required(VERSION 3.10)
project(nstool C CXX)
set(CMAKE_C_STANDARD 11)
set(CMAKE_CXX_STANDARD 11)
set(SRC "{source}")
if(MSVC)
  # libtoolchain calls std::isprint without including <cctype>; clang and
  # gcc headers pull it in transitively, MSVC's need not.
  add_compile_options($<$<COMPILE_LANGUAGE:CXX>:/FIcctype>)
endif()
foreach(lib {libraries})
  file(GLOB_RECURSE files "${{SRC}}/deps/${{lib}}/src/*.c"
       "${{SRC}}/deps/${{lib}}/src/*.cc" "${{SRC}}/deps/${{lib}}/src/*.cpp")
  add_library(${{lib}} STATIC ${{files}})
  target_include_directories(${{lib}} PUBLIC "${{SRC}}/deps/${{lib}}/include")
endforeach()
target_link_libraries(libtoolchain PUBLIC libmbedtls libfmt)
target_link_libraries(libpietendo PUBLIC libtoolchain libmbedtls libfmt)
file(GLOB program "${{SRC}}/src/*.c" "${{SRC}}/src/*.cpp")
add_executable(nstool ${{program}})
target_link_libraries(nstool PRIVATE {libraries})
if(MINGW)
  target_link_options(nstool PRIVATE -municode -static)
endif()
"""

# Fixed point, no intrinsics, no optional neural-network features; static,
# so the decoder is one self-contained program.
DECODER_PROJECT = """\
cmake_minimum_required(VERSION 3.16)
project({target} C)
set(OPUS_FIXED_POINT ON CACHE BOOL "" FORCE)
set(OPUS_DISABLE_INTRINSICS ON CACHE BOOL "" FORCE)
set(OPUS_BUILD_SHARED_LIBRARY OFF CACHE BOOL "" FORCE)
set(OPUS_BUILD_TESTING OFF CACHE BOOL "" FORCE)
set(OPUS_BUILD_PROGRAMS OFF CACHE BOOL "" FORCE)
set(OPUS_INSTALL_PKG_CONFIG_MODULE OFF CACHE BOOL "" FORCE)
set(OPUS_INSTALL_CMAKE_CONFIG_MODULE OFF CACHE BOOL "" FORCE)
set(BUILD_SHARED_LIBS OFF CACHE BOOL "" FORCE)
add_subdirectory("{opus}" opus)
add_executable({target} "{decoder}")
target_link_libraries({target} PRIVATE opus)
if(MINGW)
  target_link_options({target} PRIVATE -static)
endif()
"""


def _checkout(path: Path, repository: str, commit: str, submodules: bool = False) -> None:
    if not path.exists():
        _run([*GIT, "clone", "--no-checkout", repository, str(path)])
        _run([*GIT, "checkout", "--detach", commit], path)
    elif not (path / ".git").exists():
        raise SetupError(f"existing path is not a Git checkout: {path}")
    head = _run([*GIT, "rev-parse", "HEAD"], path)
    if head != commit:
        raise SetupError(
            f"{path} is at {head}, expected {commit}; move it aside rather "
            "than having this setup command overwrite it"
        )
    if submodules:
        # The superproject commit pins every submodule revision.
        _run([*GIT, "submodule", "update", "--init", "--recursive"], path)
    dirty = _run([*GIT, "status", "--porcelain", "--untracked-files=no",
                  "--ignore-submodules=none"], path)
    if dirty:
        raise SetupError(f"tracked files are modified in {path}; move it aside")


def _project(directory: Path, text: str) -> Path:
    directory.mkdir(parents=True, exist_ok=True)
    cmake_lists = directory / "CMakeLists.txt"
    if not cmake_lists.is_file() or cmake_lists.read_text() != text:
        cmake_lists.write_text(text)
    return directory


def setup(root: Path) -> dict[str, Path]:
    """Build both tools under ``root``; return {"nstool": path, "decoder": path}."""
    root = absolute(root)
    root.mkdir(parents=True, exist_ok=True)
    nstool = root / "nstool"
    _checkout(nstool, NSTOOL_REPOSITORY, NSTOOL_COMMIT, submodules=True)
    build = root / "nstool-build"
    project = _project(build / "project", NSTOOL_PROJECT.format(
        source=nstool.as_posix(), libraries=" ".join(NSTOOL_LIBRARIES)))
    if require_or_none(build / "bin", "nstool") is None:
        cmake_build(project, build / "cmake", "nstool", output=build / "bin")
    tools = {"nstool": require_binary(build / "bin", "nstool")}

    opus = root / "opus"
    _checkout(opus, OPUS_REPOSITORY, OPUS_COMMIT)
    build = root / "opus-build"
    project = _project(build / "project", DECODER_PROJECT.format(
        target=DECODER, opus=opus.as_posix(),
        decoder=(HERE / f"{DECODER}.c").as_posix()))
    # The decoder source ships with this script, so rebuild it whenever the
    # program is older than its source.
    built = require_or_none(build / "bin", DECODER)
    if built is None or built.stat().st_mtime < (HERE / f"{DECODER}.c").stat().st_mtime:
        cmake_build(project, build / "cmake", DECODER, output=build / "bin")
    tools["decoder"] = require_binary(build / "bin", DECODER)
    for name, path in tools.items():
        print(f"ready: {path}", flush=True)
    return tools


def require_or_none(directory: Path, name: str) -> Path | None:
    try:
        return require_binary(directory, name)
    except SetupError:
        return None


def self_test() -> None:
    assert len(NSTOOL_COMMIT) == len(OPUS_COMMIT) == 40
    text = NSTOOL_PROJECT.format(source="/s", libraries=" ".join(NSTOOL_LIBRARIES))
    assert 'set(SRC "/s")' in text and "${SRC}/deps/${lib}/src/*.cpp" in text
    assert "-municode" in text
    text = DECODER_PROJECT.format(target=DECODER, opus="/o", decoder="/d.c")
    assert "OPUS_FIXED_POINT ON" in text and "OPUS_DISABLE_INTRINSICS ON" in text
    assert (HERE / f"{DECODER}.c").is_file()
    with tempfile.TemporaryDirectory() as temporary:
        directory = Path(temporary)
        _project(directory, "a")
        stamp = (directory / "CMakeLists.txt").stat().st_mtime_ns
        _project(directory, "a")               # unchanged text is not rewritten
        assert (directory / "CMakeLists.txt").stat().st_mtime_ns == stamp
        assert require_or_none(directory, "nothing") is None
    assert EXE in ("", ".exe")
    print("setup_switch_tools self-test: OK")


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--self-test", action="store_true")
    parser.add_argument("--root", type=Path,
                        default=HERE.parent / "work" / "switch" / "upstream")
    args = parser.parse_args(argv)
    if args.self_test:
        self_test()
        return 0
    setup(args.root)
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (OSError, SetupError) as exc:
        print(f"setup_switch_tools: error: {exc}", file=sys.stderr)
        raise SystemExit(1)
