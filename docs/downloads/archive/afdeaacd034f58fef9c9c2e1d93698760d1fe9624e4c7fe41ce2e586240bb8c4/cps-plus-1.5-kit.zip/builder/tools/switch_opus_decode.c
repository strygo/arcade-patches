/* Decode a list of Opus packets to 16-bit PCM with libopus.
 *
 * Built by setup_switch_tools.py against a fixed-point libopus with its
 * CPU-specific code disabled, so the decode is integer arithmetic throughout
 * and every machine produces the same samples.
 *
 * Input, all little-endian: "CPOP", u32 channels, u32 pre-skip, u32 frames,
 * then per packet a u32 size and that many bytes.  Output: exactly `frames`
 * interleaved s16le frames, after discarding the first `pre-skip` decoded.
 * Some streams end a few samples short of the length their header declares;
 * like vgmstream, the remainder is silence, up to one maximum Opus frame.
 */
#include <opus.h>
#include <stdint.h>

/* libopus's fixed-point multiplies are exact 64-bit products where it sets
 * OPUS_FAST_INT64 (celt/arch.h, this same test) and split approximations
 * elsewhere, which decode different samples.  Only the 64-bit form is the
 * published pack's, so a 32-bit build is refused rather than mismatched. */
#if !(defined(__x86_64__) || defined(__LP64__) || defined(_WIN64))
#error "switch_opus_decode must be built for a 64-bit target (x64, arm64)"
#endif
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define RATE 48000
#define MAX_FRAME 5760            /* 120 ms at 48 kHz, the Opus maximum */
#define MAX_PACKET 65536

static int read_u32(FILE *f, uint32_t *value)
{
    unsigned char b[4];
    if (fread(b, 1, 4, f) != 4)
        return 0;
    *value = (uint32_t)b[0] | (uint32_t)b[1] << 8 | (uint32_t)b[2] << 16
             | (uint32_t)b[3] << 24;
    return 1;
}

static int fail(const char *message)
{
    fprintf(stderr, "switch_opus_decode: %s\n", message);
    return 1;
}

int main(int argc, char **argv)
{
    FILE *in, *out;
    char magic[4];
    uint32_t channels, skip, frames, size;
    uint64_t skipped = 0, written = 0, packets = 0, padded = 0;
    unsigned char *packet;
    opus_int16 pcm[MAX_FRAME * 2];
    unsigned char bytes[MAX_FRAME * 2 * 2];
    OpusDecoder *decoder;
    int error;

    if (argc != 3) {
        fprintf(stderr, "usage: %s packets.bin out.raw\n", argv[0]);
        return 2;
    }
    in = fopen(argv[1], "rb");
    if (!in)
        return fail("cannot open the packet list");
    if (fread(magic, 1, 4, in) != 4 || memcmp(magic, "CPOP", 4) != 0
        || !read_u32(in, &channels) || !read_u32(in, &skip)
        || !read_u32(in, &frames))
        return fail("not a packet list");
    if (channels < 1 || channels > 2)
        return fail("only mono and stereo streams are supported");
    decoder = opus_decoder_create(RATE, (int)channels, &error);
    if (error != OPUS_OK)
        return fail(opus_strerror(error));
    packet = malloc(MAX_PACKET);
    out = fopen(argv[2], "wb");
    if (!packet || !out)
        return fail("cannot open the output");

    while (written < frames && read_u32(in, &size)) {
        int decoded, i;
        uint64_t start = 0, count;
        if (size == 0 || size > MAX_PACKET)
            return fail("bad packet size");
        if (fread(packet, 1, size, in) != size)
            return fail("truncated packet");
        decoded = opus_decode(decoder, packet, (opus_int32)size, pcm, MAX_FRAME, 0);
        if (decoded < 0)
            return fail(opus_strerror(decoded));
        packets++;
        if (skipped < skip) {
            start = skip - skipped < (uint64_t)decoded ? skip - skipped : (uint64_t)decoded;
            skipped += start;
        }
        count = (uint64_t)decoded - start;
        if (count > frames - written)
            count = frames - written;
        for (i = 0; i < (int)(count * channels); i++) {
            uint16_t v = (uint16_t)pcm[start * channels + (uint64_t)i];
            bytes[2 * i] = (unsigned char)(v & 0xff);
            bytes[2 * i + 1] = (unsigned char)(v >> 8);
        }
        if (fwrite(bytes, 2 * channels, (size_t)count, out) != count)
            return fail("write failed");
        written += count;
    }
    if (written < frames && frames - written <= MAX_FRAME) {
        padded = frames - written;
        memset(bytes, 0, sizeof bytes);
        if (fwrite(bytes, 2 * channels, (size_t)padded, out) != padded)
            return fail("write failed");
        written += padded;
    }
    opus_decoder_destroy(decoder);
    free(packet);
    fclose(in);
    if (fclose(out) != 0)
        return fail("write failed");
    if (written != frames) {
        fprintf(stderr, "switch_opus_decode: decoded %llu of %lu frames\n",
                (unsigned long long)written, (unsigned long)frames);
        return 1;
    }
    printf("%llu packets, %lu frames (%llu silent at the end)\n",
           (unsigned long long)packets, (unsigned long)frames,
           (unsigned long long)padded);
    return 0;
}
