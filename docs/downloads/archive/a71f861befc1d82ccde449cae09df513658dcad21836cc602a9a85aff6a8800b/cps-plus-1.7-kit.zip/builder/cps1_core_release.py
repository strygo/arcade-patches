#!/usr/bin/env python3
"""The approved CPS-1 core dependency shared by game and audio deliveries.

Verification and copying are standard-library-only, including when exported
beside this module's JSON lock. Collecting the pinned build requires gh.
"""
from __future__ import annotations

# BEGIN ARCADE PYTHON BOOTSTRAP
import sys as _arcade_sys
from pathlib import Path as _ArcadePath
_arcade_sys.path.insert(0, str(_ArcadePath(__file__).resolve().parents[1]))
from kit_python import bootstrap as _arcade_bootstrap
_arcade_bootstrap()
# END ARCADE PYTHON BOOTSTRAP

import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import zipfile

LOCK_PATH = Path(__file__).with_name('cps1_core_release.json')
LOCK = json.loads(LOCK_PATH.read_text())
LOCK_SHA256 = hashlib.sha256(LOCK_PATH.read_bytes()).hexdigest()
BINDING = LOCK['binding']
FILENAME = LOCK['filename']
FILE = '_Arcade/cores/' + FILENAME
SHA256 = LOCK['sha256']
REVISION = LOCK['source_revision']
RUN_ID = LOCK['workflow_run_id']


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def verify_core(path):
    if sha(LOCK_PATH) != LOCK_SHA256:
        raise ValueError('core release lock changed during this run')
    path = Path(path)
    if not path.is_file() or path.stat().st_size != LOCK['bytes'] or sha(path) != SHA256:
        raise ValueError('CPS-1 core differs from the approved build ' + str(RUN_ID))
    return path


def copy_core(source, destination):
    source = verify_core(source)
    destination = Path(destination)
    if destination.name != FILENAME:
        raise ValueError('approved CPS-1 core must use its dated public filename')
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, destination)
    return verify_core(destination)


def export_lock(destination):
    """Export both files together so delivered verifiers need no checkout."""
    destination = Path(destination)
    if sha(LOCK_PATH) != LOCK_SHA256:
        raise ValueError('core release lock changed during this run')
    destination.mkdir(parents=True, exist_ok=True)
    for source in (Path(__file__), LOCK_PATH):
        shutil.copy2(source, destination / source.name)


def collect(work):
    """Fetch the exact accepted artifact into new scratch, never a moving run."""
    work = Path(work)
    if work.exists():
        raise ValueError('core collection requires a fresh directory')
    work.mkdir(parents=True)
    archive_path = work / 'artifact.zip'
    with archive_path.open('wb') as stream:
        subprocess.run(['gh', 'api', f"repos/{LOCK['repository']}/actions/artifacts/{LOCK['artifact_id']}/zip"],
                       stdout=stream, check=True)
    if sha(archive_path) != LOCK['artifact_zip_sha256']:
        raise ValueError('approved FPGA artifact ZIP identity differs')
    with zipfile.ZipFile(archive_path) as archive:
        if archive.namelist().count(LOCK['artifact_member']) != 1:
            raise ValueError('approved FPGA artifact has an ambiguous core member')
        raw = archive.read(LOCK['artifact_member'])
    target = work / FILENAME
    target.write_bytes(raw)
    return verify_core(target)


def self_test():
    if BINDING != 'jtcps1-cpsplus' or FILENAME != BINDING + '_' + LOCK['date'].replace('-', '') + '.rbf':
        raise AssertionError('public filename/binding/date contract differs')
    if LOCK['hardware_acceptance']['status'] != 'approved':
        raise AssertionError('core lacks hardware acceptance')
    if LOCK['capabilities']['strider_ex_mapper'] != 63 or not LOCK['capabilities']['cpk_playback']:
        raise AssertionError('approved core must support the EX mapper and packs')
    print('PASS approved CPS-1 release identity, dated name and mapper/audio contract')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--verify', type=Path)
    parser.add_argument('--collect', type=Path)
    parser.add_argument('--self-test', action='store_true')
    args = parser.parse_args()
    if args.self_test:
        self_test()
    elif args.verify:
        verify_core(args.verify)
        print('PASS approved CPS-1 FPGA binary')
    elif args.collect:
        print(collect(args.collect))
    else:
        parser.error('choose --verify, --collect or --self-test')
