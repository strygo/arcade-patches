"""CPS+ kit definitions and exact-bound exports using the standalone pack builder.

The group table, shipped MRAs, golden pack hashes and owned-media declarations
are the inputs. No catalog, source parser or separately versioned adapter is used.
"""
import argparse
import hashlib
import json
import os
import runpy
from pathlib import Path, PurePosixPath
import shutil
import sys
import tempfile
import xml.etree.ElementTree as ET
import zipfile


def require(value, message):
    if not value:raise ValueError(message)


def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 ** 2), b''):h.update(block)
    return h.hexdigest()


def safe(name):
    require(isinstance(name, str), 'Invalid kit path')
    path = PurePosixPath(name)
    require(isinstance(name, str) and name and path.as_posix() == name and not path.is_absolute()
            and not any(c in name for c in '\\:<>"|?*') and not any(ord(c) < 32 for c in name)
            and '..' not in path.parts and all(not p.endswith((' ', '.')) and p.split('.')[0].upper() not in
                {'CON', 'PRN', 'AUX', 'NUL', *[f'COM{i}' for i in range(1, 10)], *[f'LPT{i}' for i in range(1, 10)]}
                for p in path.parts), 'Unsafe kit path')
    return path


def json_bytes(value):
    return (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()


def pin(path):return {'sha256': digest(path)}


def definitions(root, version, revision):
    root = Path(root);builder = root / 'builder'
    groups = runpy.run_path(str(builder / 'pack_groups.py'))['describe'](builder)
    sources = json.loads((builder / 'manifests/collection_sources.json').read_text())
    golden = groups['accepted_packs']
    require(set(sources['packs']) == set(golden), 'Declared accepted packs differ from native groups')
    prerequisites = {};bound = {}
    def prereq(title, kind, spec):
        key = kind + '-' + spec['sha256'][:20]
        prerequisites[key] = {'title': title, 'kind': kind, 'formats': ['loose file', 'ZIP member', '7z member'],
            'action': 'Add your matching owned media or accepted pack to a scanned folder.', 'alternatives': [spec]}
        return key
    for name, source in sources['sources'].items():
        bound[name] = {**source, 'files': {n: prereq(name + ': ' + n, 'source', spec) for n, spec in source['files'].items()}}
    key = 'switch-production-keys'
    prerequisites[key] = {'title': 'Your own Switch prod.keys', 'kind': 'keyfile', 'formats': ['UTF-8 private key map'],
        'text_keys': {'header_key': 64}, 'action': 'Add your private production key map. Its values are never reported.'}
    bound['switch_prod_keys'] = {'entry': 'private.keys', 'files': {'private.keys': key}}
    # These two game launchers belong to the complete Final Fight EX game kit.
    # Its current ROM layout supersedes the soundtrack kit's original launchers.
    delegated = {'Final Fight EX (USA) [Arrange].mra', '_Japan/Final Fight EX (Japan) [Arrange].mra'}
    mras = {pack: {} for pack in golden};raw = {};assets = {}
    for path in sorted((builder / 'mras').rglob('*.mra')):
        relative = path.relative_to(builder / 'mras').as_posix()
        destination = '_Arcade/_Arcade Patches/_Arrangements/_CPS+/' + relative
        raw[destination] = pin(path)
        if relative in delegated:continue
        xml = ET.fromstring(path.read_bytes())
        refs = {p for p in golden if any('/CPS+/' + p + '.zip' in node.get('zip', '').split('|') for node in xml.iter())}
        require(len(refs) == 1, 'MRA must bind one accepted native pack: ' + relative)
        region = (xml.findtext('region') or '').strip().lower()
        region = {'usa': 'us', 'japan': 'jp', 'europe': 'eu', 'asia': 'asia', 'world': 'world'}.get(region, region)
        require(region in ('us', 'jp', 'eu', 'asia', 'world'), 'Unknown native MRA region')
        mras[next(iter(refs))].setdefault(region, {})['builder/mras/' + relative] = destination
    for path in sorted((builder / 'cores').iterdir()):
        if not path.is_file():continue
        original = 'builder/cores/' + path.name
        old = '_Arcade/cores/' + path.name;raw[old] = pin(path)
        assets[original] = old if path.suffix == '.rbf' else '_Arcade/cores/licenses/cps-plus/' + path.name
    support = {'README.txt': 'support/cps-plus/README-original.txt', 'INSTALL.md': 'support/cps-plus/INSTALL-original.md',
               'builder/games_readme.txt': 'games/CPS+/README.txt'}
    targets = {};layouts = {}
    for group in groups['groups']:
        for pack in group['packs']:
            hashes = golden[pack];hashes = [hashes] if isinstance(hashes, str) else hashes
            require(sources['packs'][pack]['sha256'] in hashes, 'Accepted pack size pin differs from golden hashes')
            pack_key = prereq('Accepted CPS+ ' + pack + '.cpk', 'pack', sources['packs'][pack])
            needed = group['source_keys']
            if group['id'] == 'ffight':needed = ['ffight_jp_disc' if pack.endswith('_jp') else 'ffight_us_disc']
            require(set(needed) <= set(bound), 'Native group needs declared source identities')
            inputs = sorted({key for name in needed for key in bound[name]['files'].values()})
            require(mras[pack], 'Accepted pack has no native launcher')
            for region, launchers in sorted(mras[pack].items()):
                name = pack.replace('_', '-') + '-' + region
                mapping = {**assets, **launchers, **support}
                outputs = {new: pin(root / old) for old, new in mapping.items()}
                variants = [{'members': {pack + '.cpk': h}} for h in hashes]
                output = 'games/CPS+/' + pack + '.zip'
                outputs[output] = variants[0] if len(variants) == 1 else {'any_of': variants}
                targets[name] = {'platform': 'mister', 'variant': pack.replace('_', '-'), 'native_variant': name,
                    'region': region, 'inputs': [], 'input_options': [
                        {'id': 'existing-pack', 'title': 'Reuse the publicly accepted ' + pack + ' pack', 'inputs': [pack_key]},
                        {'id': 'source-media', 'title': 'Reconstruct from owned source media and required firmware', 'inputs': inputs}],
                    'outputs': outputs, 'timeout_seconds': 14400, 'minimum_free_bytes': 20 * 1024 ** 3,
                    'external_tools': [{'id': 'mame', 'title': 'MAME for native soundtrack recording',
                        'commands': ['mame', 'mame64'], 'args': ['-version'], 'version_pattern': r'^0\.[0-9]+(?:\s|$)',
                        'methods': ['source-media'], 'action': 'Install MAME with the required PlayStation/X68000 driver and Lua support on PATH.'}]
                        if group['id'] in ('strider-psx', 'ssf2-x68k-fm') else [],
                    'destination_requirements': 'Soundtrack overlay: install the arcade ROM sets named by each MRA and the matching patched game kits. Arcade ROMs are not supplied.'}
                layouts[name] = {'pack': pack, 'group': group['id'], 'sources': needed, 'mapping': mapping, 'pack_key': pack_key,
                                 'pack_output': output}
    definition = {'api': 1, 'project': 'cps-plus', 'game_version': version, 'kit_revision': revision,
        'requires': ['native-context-v1', 'native-bindings-v1', 'input-options-v1', 'output-options-v1',
                     'text-keys-v1', 'external-tools-v1', 'worker-timeout-v1'],
        'prerequisites': prerequisites, 'targets': targets, 'native_outputs': raw}
    dependencies = json.loads((builder / 'collection_dependencies.json').read_text())
    definition.update(dependencies)
    if definition.get('environments'):definition['requires'] += ['locked-wheels-v1', 'native-dependencies-v1']
    return definition, layouts, bound


def seal(root, version, revision):
    root = Path(root)
    definition, _, _ = definitions(root, version, revision)
    manifest = {'api': 1, 'project': 'cps-plus', 'version': version, 'kit_revision': revision,
        'files': {p.relative_to(root).as_posix(): digest(p) for p in sorted(root.rglob('*'))
                  if p.is_file() and p.relative_to(root).as_posix() not in ('manifest.json', 'collection.json')
                  and '__pycache__' not in p.parts}}
    (root / 'manifest.json').write_bytes(json_bytes(manifest))
    definition['manifest_sha256'] = digest(root / 'manifest.json')
    (root / 'collection.json').write_bytes(json_bytes(definition))
    return definition


def describe(root):
    root = Path(root);definition = json.loads((root / 'collection.json').read_text())
    require(definition['api'] == 1 and definition['project'] == 'cps-plus' and
            definition['manifest_sha256'] == digest(root / 'manifest.json'), 'CPS+ definition manifest differs')
    manifest = json.loads((root / 'manifest.json').read_text())
    for name, expected in manifest['files'].items():
        safe(name);require(digest(root / name) == expected, 'CPS+ producer changed: ' + name)
    actual, _, _ = definitions(root, manifest['version'], manifest['kit_revision'])
    require({k: v for k, v in definition.items() if k != 'manifest_sha256'} == actual, 'CPS+ definition differs from producer')
    return definition


def run(root, args):
    from kit_collection import bound_file
    root = Path(root);definition = describe(root)
    require(args.platform == 'mister' and args.variant in definition['targets'], 'Unknown CPS+ export target')
    target = definition['targets'][args.variant];operation = 'check' if args.check else 'build'
    value = json.loads(Path(args.inputs_json).read_text());context = value['context'];bindings = value['bindings']
    require(value['schema'] == 1, 'Unknown bound input schema')
    require(Path(context['run_cache']).is_absolute() and Path(context['tools_cache']).is_absolute(), 'Native cache paths must be absolute')
    method = context['input_option'];options = {m['id']: m for m in target['input_options']}
    require(method in options and set(bindings) == set(options[method]['inputs']), 'Incomplete or unexpected bound CPS+ inputs')
    _, layouts, sources = definitions(root, definition['game_version'], definition['kit_revision'])
    layout = layouts[args.variant];pack = layout['pack']
    # No fallback to discs.toml: only these verified sources reach the native builder.
    with tempfile.TemporaryDirectory(prefix='cps-inputs-', dir=context['run_cache']) as temporary:
        temporary = Path(temporary);staged = {}
        for key, binding in bindings.items():
            requirement = definition['prerequisites'][key]
            if 'alternatives' in requirement:
                require(any(binding['sha256'] == p['sha256'] and binding['size'] == p['size']
                            for p in requirement['alternatives']), 'Undeclared CPS+ source identity')
            staged[key] = bound_file(binding, temporary / key)
        if method == 'existing-pack':
            cp = staged[layout['pack_key']]
        else:
            if args.check:
                return {'api': 1, 'target': args.variant, 'operation': operation, 'status': 'ok'}
            identity = hashlib.sha256(json_bytes({'manifest': definition['manifest_sha256'], 'group': layout['group'],
                'inputs': {key: row['sha256'] for key, row in bindings.items()}})).hexdigest()
            cached = Path(context['run_cache']) / ('cps-group-' + identity)
            marker = cached / 'complete.json'
            if marker.exists():
                metadata = json.loads(marker.read_text())
                require(metadata['identity'] == identity and pack in metadata['packs'], 'Native group cache identity differs')
                require({p.name for p in cached.iterdir()} == {'complete.json', *[n + '.cpk' for n in metadata['packs']]}, 'Native group cache extent differs')
                hashes = json.loads((root / 'builder/pack_hashes.json').read_text())
                for name in metadata['packs']:
                    accepted = hashes[name];accepted = [accepted] if isinstance(accepted, str) else accepted
                    require(digest(cached / (name + '.cpk')) in accepted, 'Native group cache changed')
            else:
                cached.mkdir(parents=True, exist_ok=True)
                discs = {}
                for name in layout['sources']:
                    source = sources[name];folder = temporary / name;folder.mkdir()
                    if 'zip_members' in source:
                        safe(source['zip_members'])
                        with zipfile.ZipFile(folder / source['zip_members'], 'w', zipfile.ZIP_STORED) as archive:
                            for member, key in source['files'].items():safe(member);archive.write(staged[key], member)
                    else:
                        for member, key in source['files'].items():
                            safe(member);dest = folder / member;dest.parent.mkdir(parents=True, exist_ok=True);shutil.copyfile(staged[key], dest)
                    entry = source['entry'];require(entry == '.' or safe(entry), 'Invalid source entry')
                    discs[name] = folder if entry == '.' else folder / entry
                os.environ.update(SDL_VIDEODRIVER='dummy', SDL_AUDIODRIVER='dummy',
                    CPSPLUS_SWITCH_TOOLS_CACHE=context['tools_cache'], ARCADE_PYTHON_CACHE=str(Path(context['tools_cache']) / 'python'))
                os.environ.pop('CAPCOM_ARCADE_ROM_PATH', None);os.environ.pop('CPSPLUS_PYTHON', None)
                sys.path.insert(0, str(root / 'builder'))
                import make_packs
                argv = ['--only', layout['group'], '--jobs', '2', '--tools-cache', context['tools_cache']]
                if context['offline']:argv.append('--offline')
                require(not (root / 'builder/work').exists() and not (root / 'out').exists(),
                        'Native CPS+ execution needs a fresh kit workspace')
                require(make_packs.main(argv, bound_discs=discs) == 0, 'Native CPS+ reconstruction failed')
                produced = []
                hashes = json.loads((root / 'builder/pack_hashes.json').read_text())
                for archive in sorted((root / 'out/mister/games/CPS+').glob('*.zip')):
                    name = archive.stem;require(name in hashes, 'Unknown native CPS+ output')
                    with zipfile.ZipFile(archive) as z:
                        require(z.namelist() == [name + '.cpk'], 'Native CPS+ pack extent differs')
                        destination = cached / (name + '.cpk')
                        with z.open(name + '.cpk') as stream, destination.open('wb') as output:shutil.copyfileobj(stream, output, 1024 ** 2)
                    accepted = hashes[name];accepted = [accepted] if isinstance(accepted, str) else accepted
                    require(digest(destination) in accepted, 'Native pack differs from accepted golden hash')
                    produced.append(name)
                require(pack in produced, 'Native group did not produce requested pack')
                marker.write_bytes(json_bytes({'identity': identity, 'packs': produced}))
                shutil.rmtree(root / 'builder/work', ignore_errors=True)
                shutil.rmtree(root / 'out', ignore_errors=True)
            cp = cached / (pack + '.cpk')
        golden = json.loads((root / 'builder/pack_hashes.json').read_text())[pack]
        require(digest(cp) in ([golden] if isinstance(golden, str) else golden), 'Pack differs from accepted native hash')
        if not args.check:
            output = Path(args.out_dir);output.mkdir(parents=True, exist_ok=True)
            require(not any(output.iterdir()), 'Collection export must be empty')
            for old, new in layout['mapping'].items():
                safe(old);safe(new);path = output / new;path.parent.mkdir(parents=True, exist_ok=True);shutil.copyfile(root / old, path)
            dest = output / layout['pack_output'];dest.parent.mkdir(parents=True, exist_ok=True)
            with zipfile.ZipFile(dest, 'w', zipfile.ZIP_STORED) as z:z.write(cp, pack + '.cpk')
        return {'api': 1, 'target': args.variant, 'operation': operation, 'status': 'ok',
                **({'outputs': target['outputs']} if not args.check else {})}


def main(root):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--describe-json', action='store_true')
    parser.add_argument('--inputs-json', type=Path);parser.add_argument('--collection-layout', action='store_true')
    parser.add_argument('--variant');parser.add_argument('--platform');parser.add_argument('--out-dir', type=Path)
    parser.add_argument('--report-json', type=Path);parser.add_argument('--check', action='store_true')
    args = parser.parse_args()
    if args.describe_json:print(json.dumps(describe(root), sort_keys=True));return 0
    require(args.collection_layout and args.inputs_json and args.report_json and args.out_dir, 'Use the collection interface with exact bound inputs')
    try:
        result = run(root, args)
    except (ValueError, OSError, KeyError, zipfile.BadZipFile) as exc:
        result = {'api': 1, 'target': args.variant, 'operation': 'check' if args.check else 'build',
                  'status': 'error', 'message': str(exc)}
        args.report_json.write_bytes(json_bytes(result));return 2
    args.report_json.write_bytes(json_bytes(result));return 0
