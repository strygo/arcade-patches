"""Exact approved native prompt converter functions."""
from __future__ import annotations
import hashlib

def sha(data):
    return hashlib.sha256(data).hexdigest()

def decode_sprite(source):
    """CPS-2 sprite layout, with the same pen numbering as the review decoder."""
    data = bytearray()
    for y in range(16):
        row = source[y*8:(y+1)*8]
        for pair in range(8):
            pens = []
            for x in (pair*2, pair*2+1):
                group, bit = (0 if x < 8 else 4), 7-(x&7)
                pens.append(sum(((row[group+3-plane] >> bit)&1) << plane for plane in range(4)))
            data.append((pens[0] << 4) | pens[1])
    return bytes(data)

def encode_sprite(data):
    result = bytearray(128)
    for y in range(16):
        for x in range(16):
            pen = (data[y*8+x//2] >> (4 if x%2 == 0 else 0)) & 15
            group, bit = (0 if x < 8 else 4), 7-(x&7)
            for plane in range(4):
                result[y*8+group+3-plane] |= ((pen >> plane)&1) << bit
    return bytes(result)

def derive(planar, profile, recipe):
    def offset(word):
        return ((profile["glyph_base"] + int(word, 16)) % 0x4000) * 128
    source, destination = map(offset, (recipe["source_word"], recipe["english_word"]))
    tile = decode_sprite(planar[source:source+128])
    old = decode_sprite(planar[destination:destination+128])
    if sha(tile) != recipe["source_chunky_sha256"]:
        raise ValueError("prompt source or English destination tile differs from pinned recipe")
    if source == destination:
        raise ValueError("English prompt destination must be separate from Japanese")
    pens = {int(k):v for k,v in recipe["pen_remap"].items()}
    if 15 in pens or 15 in pens.values():
        raise ValueError("prompt remap must preserve transparent pixels")
    new = bytes((pens.get(v>>4, v>>4)<<4) | pens.get(v&15, v&15) for v in tile)
    if sha(new) != recipe["english_chunky_sha256"]:
        raise ValueError("English prompt result differs from pinned recipe")
    blank = old == b"\xff"*128 and sha(old) == recipe["destination_chunky_sha256"]
    if not blank and old != new:
        raise ValueError("English prompt destination is neither pinned blank nor approved glyph")
    result = bytearray(planar)
    result[destination:destination+128] = encode_sprite(new)
    if result[:destination] != planar[:destination] or result[destination+128:] != planar[destination+128:]:
        raise ValueError("prompt patch changed graphics outside its allocation")
    if decode_sprite(result[destination:destination+128]) != new:
        raise ValueError("prompt sprite encoding failed round trip")
    return bytes(result), {"source_chunky_sha256":sha(tile), "english_chunky_sha256":sha(new),
        "font_bank_before_sha256":sha(planar), "font_bank_after_sha256":sha(result),
        "changed_planar_span":[destination,128], "remapped_pixels":sum((v>>4) in pens for v in tile)+sum((v&15) in pens for v in tile),
        "original_Japanese_tile_unchanged":True, "maincpu_unchanged":True}
