"""Exact pure functions from the included-source-pinned CPS+ ADX codec."""
from __future__ import annotations
import math, struct
from dataclasses import dataclass

FRAME_BYTES = 18

FRAME_SAMPLES = 32

COEFF_BITS = 12

DEFAULT_CUTOFF = 500

@dataclass
class AdxInfo:
    data_offset: int          # absolute file offset of the first audio frame
    encoding: int
    frame_size: int
    channels: int
    sample_rate: int
    total_samples: int
    cutoff: int
    version: int              # 3 or 4
    flags: int
    loop_flag: int = 0
    loop_start_sample: int = 0
    loop_start_byte: int = 0  # absolute file offsets, per CRI convention
    loop_end_sample: int = 0
    loop_end_byte: int = 0

def parse_header(buf: bytes) -> AdxInfo:
    """Parse a CRI ADX container header (v3 or v4 loop block)."""
    if len(buf) < 0x18 or buf[0] != 0x80 or buf[1] != 0x00:
        raise ValueError("not an ADX header")
    (copyright_off,) = struct.unpack_from(">H", buf, 2)
    info = AdxInfo(
        data_offset=copyright_off + 4,
        encoding=buf[4], frame_size=buf[5], channels=buf[7],
        sample_rate=struct.unpack_from(">I", buf, 8)[0],
        total_samples=struct.unpack_from(">I", buf, 0xc)[0],
        cutoff=struct.unpack_from(">H", buf, 0x10)[0],
        version=buf[0x12], flags=buf[0x13])
    if info.encoding != 3 or info.frame_size != FRAME_BYTES:
        raise ValueError(f"unsupported ADX encoding {info.encoding}/"
                         f"frame {info.frame_size}")
    if info.version == 3 and copyright_off + 4 >= 0x2c and len(buf) >= 0x2c:
        (info.loop_flag, info.loop_start_sample, info.loop_start_byte,
         info.loop_end_sample, info.loop_end_byte) = struct.unpack_from(
            ">5I", buf, 0x18)
    elif info.version == 4 and copyright_off + 4 >= 0x38 and len(buf) >= 0x38:
        (info.loop_flag, info.loop_start_sample, info.loop_start_byte,
         info.loop_end_sample, info.loop_end_byte) = struct.unpack_from(
            ">5I", buf, 0x24)
    return info

def calc_coeffs(cutoff: int, sample_rate: int) -> tuple[int, int]:
    """ffmpeg's ff_adx_calculate_coeffs (lrint variant), COEFF_BITS=12."""
    a = math.sqrt(2.0) - math.cos(2.0 * math.pi * cutoff / sample_rate)
    b = math.sqrt(2.0) - 1.0
    c = (a - math.sqrt((a + b) * (a - b))) / b
    # lrint = round half away from zero on typical libc; the values here are
    # far from .5 boundaries for every rate we use, so round() is equivalent.
    return int(round(c * 2.0 * (1 << COEFF_BITS))), \
        int(round(-(c * c) * (1 << COEFF_BITS)))

def py_decode(stream: bytes, channels: int, coef1: int, coef2: int,
              scale_plus_one: bool = False) -> list[list[int]]:
    """Reference pure-Python ADX decoder (per cri_adx_adpcm.wiki; the
    scale_plus_one=False default matches ffmpeg).  Slow — selftest use only.
    Returns one int list per channel."""
    out = [[] for _ in range(channels)]
    hist = [[0, 0] for _ in range(channels)]
    fb = FRAME_BYTES
    pos = 0
    while pos + fb * channels <= len(stream):
        for ch in range(channels):
            frame = stream[pos:pos + fb]
            pos += fb
            scale = (frame[0] << 8) | frame[1]
            if scale & 0x8000:
                return out
            if scale_plus_one:
                scale += 1
            s1, s2 = hist[ch]
            o = out[ch]
            for i in range(FRAME_SAMPLES):
                b = frame[2 + (i >> 1)]
                nib = (b >> 4) if (i & 1) == 0 else (b & 0x0f)
                if nib & 8:
                    nib -= 16
                s0 = nib * scale + ((coef1 * s1 + coef2 * s2) >> COEFF_BITS)
                s0 = max(-32768, min(32767, s0))
                s2, s1 = s1, s0
                o.append(s0)
            hist[ch] = [s1, s2]
    return out
