Strider EX dependencies

Python 3.12+ and authenticated FFmpeg helpers rebuild the soundtrack.
No NumPy, SciPy, emulator or compiler is required. 7-Zip is needed for 7z inputs.
Use --tools-cache, --tools-bundle and --offline for cached or offline helpers.
The standard-library resampler reduces dependencies and memory but takes longer to run.
