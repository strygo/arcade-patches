"""Independently check reconstructed Strider EX files and every MRA binding."""
import argparse
import hashlib
import json
from pathlib import Path
import sys
import tempfile
import xml.etree.ElementTree as ET
import zipfile
import zlib
HERE = Path(__file__).resolve().parent
ROOT = HERE / 'builder'
sys.path[:0] = [str(HERE), str(ROOT), str(ROOT / 'release')]
import mra_assembly as M
from output_checks import check_outputs, check_bindings, selected_outputs

def sha(b):
    return hashlib.sha256(b).hexdigest()

def verify(out, region='both', audio='both', platform='both', *, files=None):
    pins = json.loads((HERE / 'outputs.json').read_text())
    if files is None:
        count = check_outputs(out, pins, region, audio, platform)
        files = {name: out / name for name in selected_outputs(pins, region, audio, platform)}
    else:
        count = check_bindings(files, pins, region, audio, platform)
    with tempfile.TemporaryDirectory(prefix='strider-verify-') as temp:
        pack = None
        pp = files.get('mister/games/CPS+/strider_ex.zip')
        if pp is not None:
            pack = Path(temp) / 'pack.cpk'
            with zipfile.ZipFile(pp) as archive, archive.open('strider_ex.cpk') as stream, pack.open('wb') as dest:
                for block in iter(lambda: stream.read(1024 ** 2), b''):
                    dest.write(block)
        return verify_files(files, count, platform, pack)

def assembled_prefix(text, source, pack):
    """Assemble game/header bytes normally, then hash the terminal CPK in blocks."""
    root = ET.fromstring(text)
    rom = next((x for x in root.findall('rom') if x.get('index') == '0'))
    parts = [p for p in rom.findall('part') if p.get('name', '').endswith('.cpk')]
    if pack is None:
        if parts:
            raise ValueError('missing soundtrack dependency')
        image = M.assemble(text, source)
        return (image, sha(image))
    if len(parts) != 1 or parts[0].get('zip') != '/CPS+/strider_ex.zip' or parts[0].get('name') != 'strider_ex.cpk':
        raise ValueError('unbound soundtrack')
    part = parts[0]
    size = pack.stat().st_size
    if int(part.get('offset', '0'), 0) != 0 or int(part.get('length', str(size)), 0) != size:
        raise ValueError('MRA pack pointer or tail differs')
    children = list(rom)
    at = children.index(part)
    if any((node.tag in ('part', 'interleave') for node in children[at + 1:])):
        raise ValueError('soundtrack is not the final MRA data')
    rom.remove(part)
    image = M.assemble(ET.tostring(root, encoding='unicode'), source)
    if int.from_bytes(image[8:10], 'little') * 1024 != len(image):
        raise ValueError('MRA pack pointer or tail differs')
    digest = hashlib.sha256(image)
    crc = 0
    with pack.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 ** 2), b''):
            digest.update(block)
            crc = zlib.crc32(block, crc)
    if part.get('crc') and crc != int(part.get('crc'), 16):
        raise ValueError('soundtrack part CRC differs')
    return (image, digest.hexdigest())

def verify_files(files, count, platform, pack):
    zips = sorted((path for name, path in files.items() if name.startswith('mister/games/') and name.endswith('.zip') and (name != 'mister/games/CPS+/strider_ex.zip')))
    source = M.ZipSource(zips)
    native = {}
    arranged = []
    checks = []
    material = json.loads((HERE / 'release-material.json').read_text())
    pack_sha = None
    if pack is not None:
        from output_checks import stream_sha
        with pack.open('rb') as stream:
            pack_sha = stream_sha(stream)
        if pack_sha != material['pack_sha256']:
            raise ValueError('wrong soundtrack pack')
        from cpsplus.pack.format import PackReader
        rd = PackReader(pack)
        try:
            if not all(rd.crc_check()):
                raise ValueError('pack CRCs failed')
            for cue in (3, 121, 122, *range(160, 172), *range(184, 200)):
                row = rd.triggers[cue]
                if row.verb == 1 and (not row.suppress):
                    raise ValueError('arranged cue leaks native audio')
        finally:
            rd.f.close()
    for relative, path in sorted(files.items()):
        if not relative.startswith('mister/_Arcade/') or not relative.endswith('.mra'):
            continue
        text = path.read_text()
        r = ET.fromstring(text)
        name = r.findtext('setname')
        if name not in ('striderus01', 'striderjs01') or r.findtext('rbf') != material['core_binding']:
            raise ValueError('MRA set/core binding differs')
        rom = next((x for x in r.findall('rom') if x.get('index') == '0'))
        if rom.get('zip') != '/hbmame/' + name + '.zip':
            raise ValueError('MRA can resolve an installed or older ROM')
        is_arranged = '[Arrange' in path.name
        if is_arranged and pack is None:
            raise ValueError('missing soundtrack dependency')
        image, assembled_sha = assembled_prefix(text, source, pack if is_arranged else None)
        if image[34:39] != bytes.fromhex('3f408873ff'):
            raise ValueError('incorrect EX mapper or sprite mask')
        magic = bytes((image[64 + (a ^ 1)] for a in range(2097136, 2097146)))
        if magic != b'STRIDER-EX':
            raise ValueError('EX flag block missing')
        flag = image[64 + (2097151 ^ 1)]
        expected = (5 if 'English voices' in path.name else 3 if 'Japanese voices' in path.name else 1) if is_arranged else 0
        if flag != expected:
            raise ValueError('incorrect regional voice/audio flag')
        body = bytearray(image[:64 + 10813440])
        body[8:12] = b'\x00' * 4
        body[64 + (2097151 ^ 1)] = 0
        if is_arranged:
            arranged.append((name, sha(body)))
        else:
            if len(image) != 64 + 10813440:
                raise ValueError('native launcher appends audio')
            native[name] = sha(body)
        checks.append(dict(mra=relative, flag=flag, assembled_sha256=assembled_sha))
    for name, h in arranged:
        if name in native and native[name] != h:
            raise ValueError('audio variant changes game bytes')
    if platform != 'hbmame':
        core = files['mister/_Arcade/cores/' + material['core_filename']]
        if sha(core.read_bytes()) != material['core_sha256']:
            raise ValueError('wrong core binary')
        import cps1_core_release
        cps1_core_release.verify_core(core)
    return dict(schema='striderex-public-output-check/1', passed=True, files=count, mras=checks, pack_sha256=pack_sha, hardware_review_granted=False)
if __name__ == '__main__':
    from kit_runtime import enable_utf8
    enable_utf8()
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--out-dir', type=Path, required=True)
    p.add_argument('--region', choices=('both', 'us', 'jp'), default='both')
    p.add_argument('--audio', choices=('both', 'arcade', 'cpsplus'), default='both')
    p.add_argument('--platform', choices=('both', 'mister', 'hbmame'), default='both')
    p.add_argument('--receipt', type=Path)
    a = p.parse_args()
    r = verify(a.out_dir, a.region, a.audio, a.platform)
    if a.receipt:
        a.receipt.write_text(json.dumps(r, indent=2) + '\n')
    print('PASS:', r['files'], 'files and', len(r['mras']), 'MRA assemblies')
