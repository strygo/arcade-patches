BUILD OR UPDATE

Run python apply.py in a terminal (Windows: py -3.13 apply.py).
Choose Build or update, then select your media and available outputs.
Settings are remembered; intact outputs can be reused safely.
Check requirements is optional. Change settings saves without building.
Enter q at any prompt to quit. Run apply.py --help for the existing
command-line options and specialized workflows described below.

Strider EX — Enhanced version
Version: rc1 (2026-10-27)
Game: Strider (arcade, Capcom CPS-1)
Hardware: Capcom CPS-1


Strider EX brings the PC Engine CD version’s opening, mission briefings, boss dialogue and extended ending to the arcade game, alongside its additional desert stage. Cutscenes and boss portraits retain their original pixel width.

USA and Japanese builds include a hidden stage select, revised stage transitions and corrections to desert ledges, poles and camera movement. The USA build includes English boss voices through the original arcade sound hardware, with a new native FM score during the cinematics.

On MiSTer, the CPS+ Arrange launchers add the PC Engine soundtrack and voiced cinematics, with English and Japanese voice options and new full-quality English boss recordings. The required Strider EX CPS+ core is included.

Supply your own arcade ROMs, PC Engine CD and X68000 System disk. It runs in HBMAME and on MiSTer. This is a release candidate.

FEATURES

- PC Engine CD opening, mission briefings and extended ending, with English or Japanese captions
- The extra Kyzylkum Desert stage, including its enemies and bosses
- Boss dialogue scenes with native-size portraits and English or Japanese text
- A Strider EX title and hidden stage select: hold attack and jump while pressing Start on the credited title screen
- USA and Japanese arcade builds
- A new native FM cinematic score and embedded English boss voices in the USA build
- CPS+ arranged soundtrack and voiced cinematics on MiSTer, with English and Japanese voice options
- Revised stage-clear transitions, desert ledge and pole contacts, and camera movement
- Longer reading time for cinematic captions and a pause after high-score initials

STRIDER EX — RECONSTRUCTION KIT

Game: RC1, October 27, 2026 (unchanged).

Install Python 3.12 or later, and 7-Zip for 7z inputs.

python3 apply.py --disc "Strider Hiryuu (Japan).7z" --romset <canonical-ROM-folder> --x68k <System.dim-or-ZIP> --out-dir out

Both original regional arcade sets and the complete owned PC Engine CD are required. The X68000 System disk is identified by contents, including inside a ZIP.
MAME, the System Card BIOS, Pillow, and an assembler are no longer needed.
Choose --region us|jp|both, --audio arcade|cpsplus|both, --platform hbmame|mister|both. Defaults build all outputs.
Use --check to verify inputs; --work selects temporary storage. --tools-cache, --tools-bundle and --offline retain authenticated FFmpeg helper controls.
Run python3 verify.py --out-dir out for the independent full output/MRA verifier.
