"""Emit the accepted soundtrack once from final ordered track recipes."""
import hashlib
import math
from array import array
import sys
from recipe_resample import resample_blocks
from cpsplus.pack import adxcodec
from cpsplus.pack.format import PackWriter, Protocol, TrackMeta, TriggerRow
from recipe_engine import require, sha

def pcm(row, source):
    loop = row['blend']
    stop = None
    if loop is not None:
        require(isinstance(loop, (list, tuple)) and len(loop) == 3 and all((type(v) is int and v % 32 == 0 for v in loop)), 'invalid music loop')
        a, b, n = loop
        require(0 < n <= a < b, 'invalid music loop')
        stop = b
        right = array('d')
        step = 1.0 / (n - 1)
    clip_float = False
    quantized = array('h')
    for start, block in resample_blocks(source, row['trim'], stop):
        end = start + len(block) // 2
        if loop is not None:
            first, last = (max(start, a - n), min(end, a))
            if first < last:
                right.extend(block[(first - start) * 2:(last - start) * 2])
            for frame in range(max(start, b - n), min(end, b)):
                i = frame - (b - n)
                weight = 1.0 if i == n - 1 else i * step
                for channel in range(2):
                    k = (frame - start) * 2 + channel
                    block[k] = block[k] * (1 - weight) + right[i * 2 + channel] * weight
        for value in block:
            require(math.isfinite(value), 'non-finite resampled PCM')
            if row['clip_float'] and abs(value) >= 1:
                clip_float = True
            quantized.append(max(-32768, min(32767, round(value * 32768))))
    if clip_float:
        for index, value in enumerate(quantized):
            if value == -32768:
                quantized[index] = -32767
    quantized.extend([0] * (-(len(quantized) // 2) % 32 * 2))
    if sys.byteorder != 'little':
        quantized.byteswap()
    raw = quantized.tobytes()
    require(sha(raw) == row['pcm_sha256'], 'music PCM differs')
    return raw

def build(plan, resources, out):
    spec = dict(plan['protocol'])
    spec['control_verbs'] = {int(k): v for k, v in spec['control_verbs'].items()}
    spec['arg_commands'] = set(spec['arg_commands'])
    out.parent.mkdir(parents=True, exist_ok=True)
    with PackWriter(Protocol(**spec), title=plan['title'], trigger_rows=len(plan['triggers']), default_rate=plan['default_rate'], xfade_samples=plan['xfade_samples'], spool_dir=out.parent) as w:
        write_tracks(plan, resources, out, w)

def write_tracks(plan, resources, out, w):
    for index, row in enumerate(plan['tracks']):
        if row['kind'] == 'disc':
            stream = adxcodec.encode(pcm(row, resources.read_source(row['source'])), 2, 48000)
        elif row['kind'] == 'resource':
            stream = resources.emit(row['resource'])
        elif row['kind'] == 'xor_track':
            base = row['base_track']
            require(type(base) is int and 0 <= base < index, 'invalid audio stream reference')
            require(plan['tracks'][base]['kind'] == 'disc' and plan['tracks'][base]['source'] == row['source'], 'wrong audio source family')
            original = w.read_track(base)
            require(sha(original) == row['base_sha256'], 'audio reference identity differs')
            delta = resources.emit(row['resource'])
            require(len(original) == len(delta), 'audio reference extent differs')
            stream = bytes((a ^ b for a, b in zip(original, delta)))
        else:
            raise ValueError('unknown music recipe')
        require(sha(stream) == row['sha256'], 'music stream differs: ' + str(index))
        w.add_track(stream, TrackMeta(**row['meta']))
    w.triggers = [TriggerRow(**row) for row in plan['triggers']]
    w.write(out, sidecar=False)
    digest = hashlib.sha256()
    with out.open('rb') as source:
        for block in iter(lambda: source.read(1024 ** 2), b''):
            digest.update(block)
    require(digest.hexdigest() == plan['sha256'], 'complete soundtrack differs')
