"""Authenticated file-backed recipe inputs; no retained full-disc byte pool."""
import hashlib
import os
from pathlib import Path

def identity(info):
    return (info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns, info.st_ctime_ns)

class SourceFile:

    def __init__(self, path):
        self.path = Path(path)
        self.identity = identity(self.path.stat())
        self.expected = None

    def __len__(self):
        return self.identity[2]

    def check(self, stream=None):
        if identity(self.path.stat()) != self.identity or (stream is not None and identity(os.fstat(stream.fileno())) != self.identity):
            raise ValueError('source file changed: ' + str(self.path))

    def chunks(self):
        self.check()
        with self.path.open('rb') as stream:
            self.check(stream)
            for block in iter(lambda: stream.read(1024 ** 2), b''):
                yield block
            self.check(stream)

    def verify(self, spec):
        digest = hashlib.sha256()
        for block in self.chunks():
            digest.update(block)
        if len(self) != spec['bytes'] or digest.hexdigest() != spec['sha256']:
            raise ValueError('source identity differs: ' + str(self.path))
        self.expected = spec['sha256']

    def read(self, at=0, count=None):
        if count is None:
            count = len(self) - at
        if type(at) is not int or type(count) is not int or (not 0 <= at <= at + count <= len(self)):
            raise ValueError('invalid file source extent')
        if self.expected is None:
            raise ValueError('unverified file source')
        self.check()
        with self.path.open('rb') as stream:
            self.check(stream)
            stream.seek(at)
            data = stream.read(count)
            self.check(stream)
        if len(data) != count:
            raise ValueError('short file source read')
        if at == 0 and count == len(self) and (hashlib.sha256(data).hexdigest() != self.expected):
            raise ValueError('source identity differs: ' + str(self.path))
        return data
