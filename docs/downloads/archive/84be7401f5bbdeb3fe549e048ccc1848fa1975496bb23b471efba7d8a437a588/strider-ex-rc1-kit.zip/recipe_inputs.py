import hashlib, json, os, re, shutil, subprocess, zipfile
from pathlib import Path, PureWindowsPath
from extract_cdda import parse_cue
KIT = Path(__file__).resolve().parent

def sha(data):
    return hashlib.sha256(data).hexdigest()

def output_path(path, inputs):
    path = path.resolve()
    if path == KIT or KIT.is_relative_to(path):
        raise ValueError('output overlaps the reconstruction kit')
    if path.is_relative_to(KIT):
        first = path.relative_to(KIT).parts[0]
        if first in ('builder', 'core', 'data', 'hash', 'tools', 'files') or (KIT / first).is_file():
            raise ValueError('output overlaps kit dependencies')
    for value in inputs:
        value = value.resolve()
        if value == path or value.is_relative_to(path) or (value.is_dir() and path.is_relative_to(value)):
            raise ValueError('output overlaps owned inputs')
    return path

def rom_sources(path):
    if not path.is_dir():
        return [path]
    return [path / (name + suffix) for name in ('strider', 'striderua', 'striderjr') for suffix in ('', '.zip', '.7z')]

def unzip(path, out):
    with zipfile.ZipFile(path) as z:
        names = z.namelist()
        if len(names) != len(set(names)):
            raise ValueError('duplicate archive members')
        for i in z.infolist():
            p = out / i.filename
            if not p.resolve().is_relative_to(out.resolve()) or i.external_attr >> 16 & 61440 == 40960:
                raise ValueError('unsafe archive member')
            if i.is_dir():
                p.mkdir(parents=True, exist_ok=True)
            else:
                p.parent.mkdir(parents=True, exist_ok=True)
                p.write_bytes(z.read(i))

def sevenzip():
    for n in ('7zz', '7z', '7za'):
        found = shutil.which(n)
        if found:
            return found
    raise ValueError('7z input requires 7-Zip (7zz or 7z)')

def extract(path, out):
    if path.suffix.lower() == '.zip':
        unzip(path, out)
    elif path.suffix.lower() == '.7z':
        out.mkdir(parents=True, exist_ok=False)
        tool = sevenzip()
        listing = subprocess.check_output([tool, 'l', '-slt', '-ba', '-sccUTF-8', str(path)], text=True)
        for block in listing.split('\n\n'):
            row = dict((line.split(' = ', 1) for line in block.splitlines() if ' = ' in line))
            if 'Path' not in row:
                continue
            name = row['Path'].replace('\\', '/')
            target = (out / name).resolve()
            if PureWindowsPath(name).drive or not target.is_relative_to(out.resolve()) or any((k in row for k in ('Symbolic Link', 'Hard Link'))) or (row.get('Encrypted') == '+'):
                raise ValueError('unsafe or encrypted archive member')
        subprocess.run([tool, 'x', '-y', f'-o{out}', str(path)], check=True, stdout=subprocess.DEVNULL)
        if any((p.is_symlink() for p in out.rglob('*'))):
            raise ValueError('archive symlink')
    else:
        raise ValueError('expected ZIP or 7z archive')

def stock_inputs(source, out, work):
    manifest = json.loads((KIT / 'rom_inputs.json').read_text())
    pins = manifest['sets']
    auxiliary = manifest['mame_aux']
    needed = {r['sha256'] for group in (pins, auxiliary) for rows in group.values() for r in rows.values()}
    candidates = []
    if source.is_dir():
        for n in ('strider', 'striderua', 'striderjr'):
            d = source / n
            if d.is_dir():
                candidates.extend((p for p in d.iterdir() if p.is_file()))
            for ext in ('.zip', '.7z'):
                if (source / (n + ext)).is_file():
                    candidates.append(source / (n + ext))
    else:
        candidates = [source]
    pool = {}
    for i, p in enumerate(candidates):
        if p.suffix.lower() in ('.zip', '.7z'):
            dest = work / f'rom-archive-{i}'
            extract(p, dest)
            files = list(dest.rglob('*'))
        else:
            files = [p]
        for q in files:
            if q.is_file():
                data = q.read_bytes()
                h = sha(data)
                if h in needed:
                    pool[h] = data
    for machine, rows in pins.items():
        dest = out / machine
        dest.mkdir(parents=True)
        for n, s in (rows | auxiliary[machine]).items():
            data = pool.get(s['sha256'])
            if data is None or len(data) != s['bytes']:
                raise ValueError('missing canonical ROM: ' + machine + '/' + n)
            (dest / n).write_bytes(data)
    (out / 'strider').mkdir()

def owned_disc(source, work, *, reuse=False):
    if source.suffix.lower() in ('.zip', '.7z'):
        dest = work / 'disc'
        extract(source, dest)
        cues = list(dest.rglob('*.cue'))
        if len(cues) != 1:
            raise ValueError('disc archive needs one CUE sheet and all tracks')
        cue = cues[0]
    else:
        cue = source
    if cue.suffix.lower() != '.cue':
        raise ValueError('supply the complete CUE/BIN disc or its archive')
    pins = json.loads((KIT / 'disc_inputs.json').read_text())['files']
    by_number = {int(re.search('\\(Track (\\d+)\\)', name)[1]): (name, spec) for name, spec in pins.items() if re.search('\\(Track (\\d+)\\)', name)}
    entries, _ = parse_cue(cue)
    if [e[0] for e in entries] != sorted(by_number):
        raise ValueError('disc track table differs')
    canonical = work / 'disc-canonical'
    tracks = {}
    lines = []
    reused = 0
    for n, mode, path, i0, i1, pregap in entries:
        name, spec = by_number[n]
        start = i0 if i0 is not None else i1
        following = [e for e in entries if e[0] > n and e[2] == path]
        end = (following[0][3] if following[0][3] is not None else following[0][4]) * 2352 if following else path.stat().st_size
        if not 0 <= start <= i1 or not start * 2352 <= end <= path.stat().st_size or end % 2352:
            raise ValueError('invalid disc boundaries: ' + name)
        if len(by_number) == 30 and mode.upper() != ('MODE1/2352' if n in (2, 30) else 'AUDIO'):
            raise ValueError('incorrect disc track mode: ' + name)
        direct = reuse and start == 0 and (pregap == 0) and (end == path.stat().st_size)
        output = path if direct else canonical / name
        if not direct:
            canonical.mkdir(exist_ok=True)
        digest = hashlib.sha256()
        size = 0
        with path.open('rb') as stream:
            before = os.fstat(stream.fileno())
            stream.seek(start * 2352)
            dest = None if direct else output.open('wb')
            try:
                for remaining, zero in ((pregap * 2352, True), (end - start * 2352, False)):
                    while remaining:
                        block = bytes(min(remaining, 1024 ** 2)) if zero else stream.read(min(remaining, 1024 ** 2))
                        if not block:
                            raise ValueError('short disc track: ' + name)
                        digest.update(block)
                        size += len(block)
                        remaining -= len(block)
                        if dest is not None:
                            dest.write(block)
                after = os.fstat(stream.fileno())
                current = path.stat()
                fields = ('st_dev', 'st_ino', 'st_size', 'st_mtime_ns', 'st_ctime_ns')
                if any((getattr(before, k) != getattr(after, k) or getattr(after, k) != getattr(current, k) for k in fields)):
                    raise ValueError('disc input changed: ' + name)
            finally:
                if dest is not None:
                    dest.close()
        if size != spec['bytes'] or digest.hexdigest() != spec['sha256']:
            raise ValueError('disc track missing or incorrect: ' + name)
        tracks[n] = output
        if direct:
            reused += 1
        frames = i1 - start + pregap
        m, s = divmod(frames // 75, 60)
        f = frames % 75
        filename = str(output.resolve()) if reuse else name
        lines += ['FILE "' + filename + '" BINARY', f'  TRACK {n:02} {mode}']
        if frames:
            lines.append('    INDEX 00 00:00:00')
        lines.append(f'    INDEX 01 {m:02}:{s:02}:{f:02}')
    if reused == len(tracks):
        return (cue, tracks)
    canonical.mkdir(exist_ok=True)
    result = canonical / 'disc.cue'
    result.write_text('\n'.join(lines) + '\n')
    return (result, tracks)

def zip_members(path, members):
    path.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(path, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for n, b in sorted(members.items()):
            info = zipfile.ZipInfo(n, (2026, 10, 26, 0, 0, 0))
            info.external_attr = 33188 << 16
            info.create_system = 3
            info.compress_type = zipfile.ZIP_DEFLATED
            z.writestr(info, b, compresslevel=6)
