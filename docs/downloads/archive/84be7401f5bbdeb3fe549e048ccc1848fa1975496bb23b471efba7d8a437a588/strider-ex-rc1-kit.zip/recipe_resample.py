"""Fixed stereo 44.1-to-48 kHz FIR; standard-library recipient runtime."""
from array import array
import hashlib
import json
import math
from pathlib import Path
import struct
import sys

def coefficients():
    doc = json.loads(Path(__file__).with_name('resampler.json').read_text())
    phases = [[float.fromhex(v) for v in row] for row in doc['phases']]
    if doc.get('schema') != 1 or len(phases) != 160 or any((len(p) != 21 for p in phases)) or any((not math.isfinite(v) for p in phases for v in p)):
        raise ValueError('Invalid Strider FIR')
    raw = b''.join((struct.pack('<21d', *p) for p in phases))
    if hashlib.sha256(raw).hexdigest() != doc['sha256']:
        raise ValueError('Strider FIR differs')
    return phases

def resample_blocks(source, trim, stop=None):
    if len(source) % 4 or type(trim) is not int or (not 0 <= trim < len(source) // 4):
        raise ValueError('Invalid stereo PCM extent')
    if sys.byteorder == 'little':
        samples = memoryview(source).cast('h')
    else:
        samples = array('h', source)
        samples.byteswap()
    frames = len(source) // 4 - trim
    count = (frames * 160 + 146) // 147
    if stop is not None:
        if type(stop) is not int or not 0 < stop <= count:
            raise ValueError('Invalid resampling extent')
        count = stop
    phases = coefficients()
    for start in range(0, count, 32768):
        end = min(count, start + 32768)
        first = (start + 11) * 147 // 160 - 20
        last = (end - 1 + 11) * 147 // 160 + 1
        x = array('d', [0.0] * (max(0, -first) * 2))
        x.extend((v / 32768 for v in samples[(trim + max(0, first)) * 2:(trim + min(frames, last)) * 2]))
        x.extend([0.0] * (max(0, last - frames) * 2))
        y = array('d')
        for output in range(start, end):
            position, phase = divmod((output + 11) * 147, 160)
            position -= first + 20
            left = right = 0.0
            for tap, weight in enumerate(phases[phase]):
                i = (position + tap) * 2
                left += x[i] * weight
                right += x[i + 1] * weight
            y.append(left)
            y.append(right)
        yield (start, y)

def resample(source, trim, stop=None):
    """Materialize small oracle fixtures; recipient music consumes blocks."""
    result = array('d')
    for _, block in resample_blocks(source, trim, stop):
        result.extend(block)
    return result
