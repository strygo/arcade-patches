ROM INPUT UPDATE

Merged, split, complete ZIP/7z archives and extracted ROM folders are accepted.
Use --rompath DIR (repeatable) to search a collection, or keep the existing archive argument.
Names may differ; required source contents are verified by size and strong hashes.
Use --check to verify arcade build inputs before reconstruction.
QSound is optional for game builds. Valid embedded firmware is preserved in complete game outputs.
Use --include-devices on CPS-2 kits to require and include firmware from separate archives.
Compact HBMAME outputs retain their stock-game and device dependencies.
7z input requires an installed 7-Zip executable; ZIP needs no extra archive software.
Original archives are never modified by collection discovery.

Marvel Super Heroes vs. Street Fighter EX · Norimaro, the bosses and more, in every region
==========================================================================================

Version:  rc1 (2026-09-17)
Target:   MAME set 'mshvsfj' (Marvel Super Heroes vs. Street Fighter (Japan 970707))
Hardware: Capcom CPS-2
Patch by: Steve Gordon (https://x.com/strygo)
Website:  https://strygo.github.io/arcade-patches/

ABOUT THIS PROJECT

Marvel Super Heroes vs. Street Fighter kept a lot from you. Outside Japan
there was no Norimaro. Nowhere could you play as Cyber-Akuma or Apocalypse, or
put the same fighter on a team twice. The console ports later added extra
colors and more speeds, but only at home.

EX gives the arcade game all of it. Norimaro is on the select screen in both
builds, with his own ending. Hold Start on any fighter for two seconds and
their hidden version appears, no codes needed, though the old codes still
work. Any two fighters make a team. Cyber-Akuma and Apocalypse are playable
too: hold Start on Akuma for one, on Norimaro for the other. Every fighter
gets the Saturn version's two extra colors, on the HP and HK buttons, and the
service menu goes from three speeds to eight.

The fighting itself is untouched: no changes to moves, damage, hitboxes or the
computer. The USA build also gets a new translation, straight from the
Japanese: sixteen win quotes per fighter instead of eight, and every ending
retold. It comes in two builds, USA and Japan, both with Free Play, and runs
in MAME, HBMAME and on MiSTer.

This is a release candidate. Everything builds and boots; longer play testing
and a MiSTer hardware pass are still to come.

WHAT'S CHANGED

  - Norimaro in both builds, with his own ending
  - Cyber-Akuma and Apocalypse playable: hold Start on Akuma, or on Norimaro.
    Their special moves work on the Easy control setting too
  - Hidden characters with a two-second Start hold; the old codes still work
  - Any team, including the same fighter twice, in a different color (one
    Apocalypse per match, so his stage stays intact)
  - Every ending in both languages, including Mech-Zangief's, Shadow's and
    Dark Sakura's
  - A new English translation from the Japanese: sixteen win quotes per
    fighter instead of eight, and all seventeen standard endings
  - U.S. Agent, Mephisto and Shadow get their names in the fight HUD, which
    the boards leave blank
  - M. Bison's Hyper Combo is Knee Press Nightmare in every region, the name
    Capcom has used since Alpha 3
  - Two extra colors per fighter from the Saturn version: pick your fighter
    with HP or HK
  - Eight game speeds instead of three
  - USA and Japan builds, both with Free Play
  - Gameplay untouched

BUILDS IN THIS DOWNLOAD

    usa        USA
    japan      Japan

HOW TO APPLY (recommended)

    python3 apply.py /path/to/mshvsfj.zip --out-dir out

This checks every file against the original, applies the patches, checks
the result, and writes everything you need for every build (add
--variant <build> to make just one):

  USA:
    MAME / original hardware: out/mame/usa/mshvsfj.zip
    HBMAME:                   out/hbmame/mshvsfex.zip
    MiSTer:                   out/mister/_Arcade/_Arcade Patches/_Enhanced Versions/Marvel Super Heroes Vs. Street Fighter EX (USA).mra
  Japan:
    MAME / original hardware: out/mame/japan/mshvsfj.zip
    HBMAME:                   out/hbmame/mshvsfej.zip
    MiSTer:                   out/mister/_Arcade/_Arcade Patches/_Enhanced Versions/_Japan/Marvel Super Heroes Vs. Street Fighter EX (Japan).mra

MAME: put mshvsfj.zip from out/mame/ ahead of the stock set in your MAME
rompath (one build at a time: they share the set name).
MAME reports checksum warnings for the patched ROMs; that's expected and
the game runs normally. The same files can be burned for an original board.

HBMAME: the set definition (mshvsfex, mshvsfej) ships with the project;
an upstream HBMAME submission is pending.
Put the zip in HBMAME's roms/ folder next to your stock mshvsfj.zip.
It loads with no checksum warnings.

MiSTer: copy the _Arcade folder from out/mister/ to the root of your SD card
and keep the stock, unmodified romset at games/mame/mshvsfj.zip (split MAME
sets also need qsound.zip). The MRA applies the patch in memory as the
game loads, so nothing on the card is modified. You need Jotego's jtcps2
core, which update_all installs. The MRAs are also a separate download.

HOW TO APPLY (any IPS patcher)

Extract mshvsfj.zip, apply each file in ips/<build>/ to the ROM file of the
same name (Flips, Lunar IPS, or any IPS tool), then re-zip everything
as mshvsfj.zip.

CHANGED FILES

  USA (--variant usa):
    mvs.05h  (512 KB)  CRC32 77870dc3 -> 5a83d5cc
    mvs.06a  (512 KB)  CRC32 959f3030 -> 444fb179
    mvs.07b  (512 KB)  CRC32 7f915bdb -> e9cbc426
    mvs.10b  (512 KB)  CRC32 cf0dba98 -> c4faa1f9
    mvs.13m  (4.0 MB)  CRC32 29b05fd9 -> 5aec3072
    mvs.15m  (4.0 MB)  CRC32 faddccf1 -> b3b37f0c
    mvs.17m  (4.0 MB)  CRC32 97aaf4c7 -> 763798a3
    mvs.19m  (4.0 MB)  CRC32 cb70e915 -> 6fc69f7e
    mvsj.03i  (512 KB)  CRC32 d8cbb691 -> c514a97e
    mvsj.04i  (512 KB)  CRC32 32741ace -> ba4c053c

  Japan (--variant japan):
    mvs.05h  (512 KB)  CRC32 77870dc3 -> 5a83d5cc
    mvs.06a  (512 KB)  CRC32 959f3030 -> 444fb179
    mvs.07b  (512 KB)  CRC32 7f915bdb -> e9cbc426
    mvs.10b  (512 KB)  CRC32 cf0dba98 -> c4faa1f9
    mvs.13m  (4.0 MB)  CRC32 29b05fd9 -> 5aec3072
    mvs.15m  (4.0 MB)  CRC32 faddccf1 -> b3b37f0c
    mvs.17m  (4.0 MB)  CRC32 97aaf4c7 -> 763798a3
    mvs.19m  (4.0 MB)  CRC32 cb70e915 -> 6fc69f7e
    mvsj.03i  (512 KB)  CRC32 d8cbb691 -> 72fd9929
    mvsj.04i  (512 KB)  CRC32 32741ace -> ba4c053c

All other files in the set are unmodified.

LEGAL

This is a free, unofficial fan patch. It is not affiliated with or endorsed
by Capcom. All game titles, characters, and artwork remain the property of
their respective owners. You must own the game to use this patch. Do not
sell this patch or distribute it applied to a ROM image.
