"""One direct CPK writer over authenticated original CD audio tracks."""
import hashlib
from pathlib import Path
import re
import wave
from pack import adxcodec
from pack.format import PackWriter, Protocol, TrackMeta, TriggerRow
from resource_recipe import require, sha


def read_pcm(path):
    with wave.open(str(path), 'rb') as w:
        require((w.getframerate(), w.getnchannels(), w.getsampwidth()) == (44100, 2, 2),
                'Expected original 44.1 kHz stereo CD audio')
        data = w.readframes(w.getnframes())
        require(len(data) == w.getnframes() * 4, 'Truncated CD audio')
    return data


def pcm(row, source):
    require(sha(source) == row['source_sha256'], 'Original CD audio track differs')
    data = source
    if row['cut'] is not None:
        data, _ = arcade_cut(data, 2, 44100, *row['cut'], weights=row.get('splice_weights'))
    elif row['lead']:
        data = bytes(row['lead'] * 4) + data
    require(sha(data) == row['pcm_sha256'], 'Prepared audio PCM differs')
    return data


def build(plan, audio, out):
    protocol = dict(plan['protocol'])
    protocol['control_verbs'] = {int(k): v for k, v in protocol['control_verbs'].items()}
    protocol['arg_commands'] = set(protocol['arg_commands'])
    Path(out).parent.mkdir(parents=True, exist_ok=True)
    with PackWriter(Protocol(**protocol), title=plan['title'], trigger_rows=len(plan['triggers']),
                    default_rate=plan['default_rate'], xfade_samples=plan['xfade_samples'], spool_dir=Path(out).parent) as writer:
        for row in plan['tracks']:
            require(row['kind'] == 'disc', 'Unknown soundtrack track recipe')
            stream = adxcodec.encode(pcm(row, read_pcm(Path(audio) / (row['track'] + '.wav'))), 2, 44100)
            require(len(stream) >= row['stream_bytes'], 'Encoded audio is too short')
            stream = stream[:row['stream_bytes']]
            require(sha(stream) == row['sha256'], 'Encoded audio stream differs')
            writer.add_track(stream, TrackMeta(**row['meta']))
        writer.triggers = [TriggerRow(**row) for row in plan['triggers']]
        writer.write(out, sidecar=False)
    digest = hashlib.sha256()
    with Path(out).open('rb') as source:
        for block in iter(lambda: source.read(1024 ** 2), b''):digest.update(block)
    require(digest.hexdigest() == plan['sha256'], 'Complete soundtrack differs')


def arcade_cut(pcm, ch, rate, lead_samples, cut_at, bars, bpm, xfade, *, weights=None):
    from pcm_splice import arcade_cut as splice
    return splice(pcm, ch, rate, lead_samples, cut_at, bars, bpm, xfade, weights=weights)
