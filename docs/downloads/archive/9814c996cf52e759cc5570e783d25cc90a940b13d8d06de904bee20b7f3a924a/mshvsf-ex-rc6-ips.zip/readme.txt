BUILD OR UPDATE

Run python apply.py in a terminal (Windows: py -3.13 apply.py).
Choose Build or update, then select your media and available outputs.
Settings are remembered; intact outputs can be reused safely.
Check requirements is optional. Change settings saves without building.
Enter q at any prompt to quit. Run apply.py --help for the existing
command-line options and specialized workflows described below.

Marvel Super Heroes vs. Street Fighter EX · Enhanced version
============================================================

Version:  rc6 (2026-11-07)
Target:   MAME set 'mshvsfj' (Marvel Super Heroes vs. Street Fighter (Japan 970707))
Hardware: Capcom CPS-2
Patch by: Steve Gordon (https://x.com/strygo)
Website:  https://arcadepatches.com/mshvsf-ex/

ABOUT THIS PROJECT

Marvel Super Heroes vs. Street Fighter kept a lot from you. Outside Japan
there was no Norimaro. Nowhere could you play as Cyber-Akuma or Apocalypse, or
put the same fighter on a team twice. The console ports later added extra
colors and more speeds, but only at home.

EX gives the arcade game all of it. Norimaro is on the select screen in both
builds, with his own ending and restored nosebleed attack and victory
animation. Hold Start on any fighter for two seconds and their hidden version
appears, no codes needed, though the old codes still work. Any two fighters
make a team. Cyber-Akuma and Apocalypse are playable too, each with a spot on
the select screen. Every fighter gets the Saturn version's two extra colors,
on the HP and HK buttons, and the service menu goes from three speeds to
eight.

Console mode gives the game a home-style title menu: Arcade, Versus against a
friend or the computer, Training, and Options with a time limit setting. The
MiSTer MRAs start in Console mode; MAME and HBMAME start in Arcade mode, and
GAME MODE in the service menu's EX page switches between them.

The other fighters retain their original moves, damage, hitboxes and computer
behavior. The USA build also gets a new translation, straight from the
Japanese: sixteen win quotes per fighter instead of eight, and every ending
retold. It comes in two builds, USA and Japan, both with Free Play, and runs
in MAME, HBMAME and on MiSTer.

This is a release candidate.

WHAT'S CHANGED

  - Norimaro in both builds, with his own ending, his restored nosebleed
    attack (back, down, down-back plus an attack button or Start) and his
    unused victory animation against Chun-Li, Sakura and Dark Sakura
  - Cyber-Akuma and Apocalypse playable, each with a spot on the select
    screen. Their special moves work on the Easy control setting too
  - Hidden characters with a two-second Start hold; the old codes still work
  - Any team, including the same fighter twice, in a different color (one
    Apocalypse per match, so his stage stays intact)
  - Every ending in both languages, including Mech-Zangief's, Shadow's and
    Dark Sakura's
  - Apocalypse and Cyber-Akuma have character-specific ending artwork, layered
    over the animated arcade burst
  - A new English translation from the Japanese: sixteen win quotes per
    fighter instead of eight, and all seventeen standard endings
  - U.S. Agent, Mephisto and Shadow get their names in the fight HUD, which
    the original game leaves blank
  - M. Bison's Hyper Combo is Knee Press Nightmare in every region, the name
    Capcom has used since Alpha 3
  - Two extra colors per fighter from the Saturn version: pick your fighter
    with HP or HK; the selected color appears in portraits, intros, special
    moves and hypers
  - Versus names in the arcade lettering, centered, with two lines when long
    names would crowd the middle; selected names stay visible above the
    fighters
  - Eight game speeds instead of three
  - Console mode with Arcade, Versus, Training and Options on the title
    screen; MiSTer starts in Console mode, and GAME MODE in the service menu's
    EX page selects Console or Arcade
  - Versus: against a friend or the computer, with a stage choice, then
    Rematch or Change Characters with the wins kept
  - Training: set the computer's action and guard, both gauges, speed and
    stage; restart or change characters from the pause menu
  - Options: difficulty, speed, damage, sound, and a time limit of 25, 50, 75
    or 99 seconds, or none
  - Pause any Console fight with Coin, or by holding Start
  - USA and Japan builds, both with Free Play
  - The other fighters retain their original moves, damage, hitboxes and
    computer behavior

BUILDS IN THIS DOWNLOAD

    usa        USA
    japan      Japan

HOW TO APPLY (recommended)

    python3 apply.py /path/to/mshvsfj.zip --out-dir out

This checks every file against the original, applies the patches, checks
the result, and writes everything you need for every build (add
--variant <build> to make just one):

  USA:
    MAME:                     out/mame/usa/mshvsfj.zip
    HBMAME:                   out/hbmame/mshvsfex.zip
    FBNeo:                    out/fbneo/mshvsfex.zip
    MiSTer:                   out/mister/_Arcade/_Arcade Patches/_Enhanced Versions/Marvel Super Heroes Vs. Street Fighter EX (USA).mra
  Japan:
    MAME:                     out/mame/japan/mshvsfj.zip
    HBMAME:                   out/hbmame/mshvsfej.zip
    FBNeo:                    out/fbneo/mshvsfexj.zip
    MiSTer:                   out/mister/_Arcade/_Arcade Patches/_Enhanced Versions/_Japan/Marvel Super Heroes Vs. Street Fighter EX (Japan).mra

FBNeo: use --platform fbneo --out-dir out for complete game ZIPs.
Keep their ZIP and member names. Use an FBNeo version with definitions
matching this game release; older versions may reject its checksums.


DARKSOFT

Use --platform darksoft --out-dir out to build only Darksoft files.
The default all-platform build includes them too. Copy the selected
folder from out/darksoft/games to your card games folder.
Expanded hardware and streamed audio are not supported.

Merged, split and complete sets work, including nested or renamed ROMs.
Use --rompath DIR (repeatable) to search a collection instead of naming the
zip, and --check to check inputs before building. ZIPs and extracted folders
need no extra software; 7z archives need 7-Zip.
QSound can stay in your emulator's ROM path; valid firmware already
in a source set is kept in complete outputs.

MAME: put mshvsfj.zip from out/mame/ ahead of the stock set in your MAME
rompath (one build at a time: they share the set name).
MAME's game menu won't start a set with patched ROMs, so start it from the
command line: mame mshvsfj. MAME shows checksum warnings for the patched
ROMs; that's expected and the game runs normally.
To start it from a menu, use the HBMAME build.

HBMAME: this patch's builds are official HBMAME sets
(mshvsfex and mshvsfej), so full HBMAME collections may already carry them.
Put the zip in HBMAME's roms/ folder next to your stock mshvsfj.zip.

MiSTer: copy the _Arcade folder from out/mister/ to the root of your SD card
and keep the stock, unmodified romset at games/mame/mshvsfj.zip (split MAME
sets also need qsound.zip). The MRA applies the patch in memory as the
game loads, so nothing on the card is modified. You need Jotego's jtcps2
core, which update_all installs. The MRAs are also a separate download.

HOW TO APPLY (any IPS patcher)

Extract mshvsfj.zip, apply each file in ips/<build>/ to the ROM file of the
same name (Flips, Lunar IPS, or any IPS tool), then re-zip everything
as mshvsfj.zip.

CHANGED FILES

  USA (--variant usa):
    mvs.01  (128 KB)  CRC32 68252324 -> 4712c830
    mvs.05h  (512 KB)  CRC32 77870dc3 -> 5334b038
    mvs.06a  (512 KB)  CRC32 959f3030 -> 444fb179
    mvs.07b  (512 KB)  CRC32 7f915bdb -> e9cbc426
    mvs.09b  (512 KB)  CRC32 3ba08818 -> 2be6f5e0
    mvs.10b  (512 KB)  CRC32 cf0dba98 -> bad46d8a
    mvs.13m  (4.0 MB)  CRC32 29b05fd9 -> 5a0765f2
    mvs.15m  (4.0 MB)  CRC32 faddccf1 -> ca4700c6
    mvs.17m  (4.0 MB)  CRC32 97aaf4c7 -> 20979aee
    mvs.19m  (4.0 MB)  CRC32 cb70e915 -> a4e6969f
    mvsj.03i  (512 KB)  CRC32 d8cbb691 -> 943102b0
    mvsj.04i  (512 KB)  CRC32 32741ace -> d9196f9c

  Japan (--variant japan):
    mvs.01  (128 KB)  CRC32 68252324 -> 4712c830
    mvs.05h  (512 KB)  CRC32 77870dc3 -> ef82fbee
    mvs.06a  (512 KB)  CRC32 959f3030 -> 444fb179
    mvs.07b  (512 KB)  CRC32 7f915bdb -> e9cbc426
    mvs.09b  (512 KB)  CRC32 3ba08818 -> 2be6f5e0
    mvs.10b  (512 KB)  CRC32 cf0dba98 -> bad46d8a
    mvs.13m  (4.0 MB)  CRC32 29b05fd9 -> 2d9e887e
    mvs.15m  (4.0 MB)  CRC32 faddccf1 -> d65f6ecb
    mvs.17m  (4.0 MB)  CRC32 97aaf4c7 -> b2cbd772
    mvs.19m  (4.0 MB)  CRC32 cb70e915 -> 690674ec
    mvsj.03i  (512 KB)  CRC32 d8cbb691 -> 8e50ee75
    mvsj.04i  (512 KB)  CRC32 32741ace -> d9196f9c

All other files in the set are unmodified.

LEGAL

This is a free, unofficial fan patch. It is not affiliated with or endorsed
by Capcom. All game titles, characters, and artwork remain the property of
their respective owners. You must own the game to use this patch. Do not
sell this patch or distribute it applied to a ROM image.
