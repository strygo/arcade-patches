Night Warriors 2 · English translation
======================================

Version:  rc2 (2026-09-17)
Target:   MAME set 'vhunt2' (Vampire Hunter 2: Darkstalkers Revenge (Japan 970929))
Hardware: Capcom CPS-2
Patch by: Steve Gordon (https://x.com/strygo)
Website:  https://arcadepatches.com/vhunt2-english/

ABOUT THIS PROJECT

Vampire Hunter 2 is a Japan-only follow-up to the game the West knew as Night
Warriors: Darkstalkers' Revenge. It never came out in English. This patch
translates the entire game and gives it the name it should have had, Night
Warriors 2.

Where Capcom's own English exists, in the Western Night Warriors and Vampire
Savior and the PlayStation Darkstalkers 3, the patch uses it, as long as it
says what the Japanese says, so it reads like the official localization. The
rest gets a fresh translation, written to read naturally while staying true to
the original: the victory quotes, the boss exchanges, and every ending.

The Night Warriors 2 title screen isn't a fan mock-up. An unused Western title
was already sitting inside the original game, and the patch finishes it and
switches it on.

WHAT'S CHANGED

  - Night Warriors 2 title screen, finished from the unused Western title
    inside the original game
  - USA region presentation
  - Western character names on character select, route map, and fight HUD:
    Zabel → L.Raptor, Gallon → J.Talbain, Lei-Lei → Hsien-Ko, Phobos →
    Huitzil, Aulbath → Rikuo
  - All 225 post-fight quotes in English, using Capcom's own wording where it
    matches the Japanese
  - All boss dialogs and every ending translated
  - Route stage names and the staff roll in English
  - Capcom's misspelled "L.Rapter" name art corrected to L.Raptor
  - Oboro Bishamon's win plays his own victory music, as intended

HOW TO APPLY (recommended)

    python3 apply.py /path/to/vhunt2.zip --out-dir out

This checks every file against the original, applies the patches, checks
the result, and writes everything you need for each platform:

  MAME / original hardware: out/mame/vhunt2.zip
  HBMAME:                   out/hbmame/vhunt2s01.zip
  MiSTer:                   out/mister/_Arcade/_Arcade Patches/_Restorations/Night Warriors 2 (USA) [English Translation].mra

Merged, split and complete sets work, including nested or renamed ROMs.
Use --rompath DIR (repeatable) to search a collection instead of naming the
zip, and --check to check inputs before building. ZIPs and extracted folders
need no extra software; 7z archives need 7-Zip. QSound can stay in your
emulator's ROM path; valid firmware already in a source set is kept in
complete outputs.

MAME: put vhunt2.zip from out/mame/ ahead of the stock set in your MAME
rompath.
MAME's game menu won't start a set with patched ROMs, so start it from the
command line: mame vhunt2. MAME shows checksum warnings for the patched
ROMs; that's expected and the game runs normally.
To start it from a menu, use the HBMAME build.

HBMAME: this translation is an official HBMAME set (vhunt2s01),
so full HBMAME collections may already carry it.
Put the zip in HBMAME's roms/ folder next to your stock vhunt2.zip.
It loads with no checksum warnings.

MiSTer: copy the _Arcade folder from out/mister/ to the root of your SD card
and keep the stock, unmodified romset at games/mame/vhunt2.zip (split MAME
sets also need qsound.zip). The MRA applies the translation in memory as the
game loads, so nothing on the card is modified. You need Jotego's jtcps2
core, which update_all installs. The MRAs are also a separate download.

HOW TO APPLY (any IPS patcher)

Extract vhunt2.zip, apply each file in ips/ to the ROM file of the
same name (Flips, Lunar IPS, or any IPS tool), then re-zip everything
as vhunt2.zip.

CHANGED FILES

    vh2.13m  (4.0 MB)  CRC32 3b02ddaa -> 3a56e2f4
    vh2.15m  (4.0 MB)  CRC32 4e40de66 -> aa61e461
    vh2.17m  (4.0 MB)  CRC32 b31d00c9 -> ccd2f7c4
    vh2.19m  (4.0 MB)  CRC32 149be3ab -> 5df31cf6
    vh2j.03a  (512 KB)  CRC32 9ae8f186 -> 10da5708
    vh2j.04a  (512 KB)  CRC32 e2fabf53 -> 60cf3a23
    vh2j.08  (512 KB)  CRC32 ac873dff -> be9d8a6c

All other files in the set are unmodified.

LEGAL

This is a free, unofficial fan patch. It is not affiliated with or endorsed
by Capcom. All game titles, characters, and artwork remain the property of
their respective owners. You must own the game to use this patch. Do not
sell this patch or distribute it applied to a ROM image.
