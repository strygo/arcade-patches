"""Scene registry + entry points.

  render_scene('jp'|'us', name, dump)    -> PIL RGB 320x224
  gallery(region, out_png, dump)         -> contact sheet of all scenes
  sweep(region, outdir, dump, ...)       -> compose every dumped frame to PNGs

This renders from a MAME VDP DUMP, not from the disc -- it is the
reverse-engineering oracle that produced the proof galleries, not part of
the build (the build runs the VM and never reaches here).  The dump
directory used to be a module constant pointing at one machine; it is an
argument now, so the tool says which capture it means.

CLI:  python -m ffcd.scenes gallery jp out.png <dump-dir>
      python -m ffcd.scenes sweep jp sweep_jp/ <dump-dir> [--mame-ramp]
"""

# BEGIN ARCADE PYTHON BOOTSTRAP
import sys as _arcade_sys
from pathlib import Path as _ArcadePath
_arcade_sys.path.insert(0, str(_ArcadePath(__file__).resolve().parents[3]))
from kit_python import bootstrap as _arcade_bootstrap
_arcade_bootstrap()
# END ARCADE PYTHON BOOTSTRAP
import glob, os, sys
from PIL import Image, ImageDraw
from . import megadrive, usmap

SCENES = {
    "guycody": 310, "reunion": 1310, "cody_pan": 3010, "credits_walk": 7810,
    "cody_jessica": 8110, "map": 11230, "mad_gear_frontal": 11700,
    "mad_gear_bar": 12010, "sketch": 13010, "haggar_phone": 13510,
    "jessica_tv": 15410, "villain_call": 16210, "guy_cody_ring": 17410,
    "title": 18410,
}
# per-plane vertical scroll (VSRAM wasn't dumped; derived vs ground truth)
SCENE_VSCROLL = {15410: (32, 32), 15810: (32, 32), 16010: (32, 32), 16210: (32, 32)}

def render_frame(region, F, dump):
    vs = SCENE_VSCROLL.get(F, (0, 0))
    if region == "jp":
        return megadrive.render(F, vscroll=vs, dump=dump)
    vram, cram, regs, hs = megadrive.load_state(F, dump)
    usv, usc = usmap.synth_us(vram, cram, regs)
    return megadrive.render(F, vscroll=vs, state=(usv, usc, regs, hs))

def render_scene(region, name, dump):
    return render_frame(region, SCENES[name], dump)

def gallery(region, out_png, dump):
    rows = [(nm, render_scene(region, nm, dump)) for nm in SCENES]
    cols = 3; rr = (len(rows) + cols - 1) // cols
    sheet = Image.new("RGB", (cols * 320, rr * (224 + 16)), (15, 15, 15))
    d = ImageDraw.Draw(sheet)
    for i, (nm, im) in enumerate(rows):
        x = (i % cols) * 320; y = (i // cols) * (224 + 16)
        sheet.paste(im, (x, y + 16)); d.text((x + 3, y + 3), f"{region} {nm}", fill=(0, 255, 255))
    sheet.save(out_png)
    return out_png

def sweep(region, outdir, dump, start=None, end=None):
    """Compose every dumped frame (resumable; skips existing PNGs)."""
    os.makedirs(outdir, exist_ok=True)
    frames = sorted(int(os.path.basename(f)[5:-4])
                    for f in glob.glob(f"{dump}/vram_*.bin"))
    for F in frames:
        if start is not None and F < start: continue
        if end is not None and F > end: continue
        p = f"{outdir}/f{F:06d}.png"
        if os.path.exists(p): continue
        try:
            render_frame(region, F, dump).save(p)
        except Exception as e:
            print(f"f{F}: {e}", flush=True)
    print("sweep done", flush=True)

if __name__ == "__main__":
    args = sys.argv[1:]
    if args and args[0] == "--mame-ramp":
        megadrive.RAMP = megadrive.MAME_RAMP; args = args[1:]
    cmd = args[0]
    if cmd == "gallery": print(gallery(args[1], args[2], args[3]))
    elif cmd == "sweep":
        s = int(args[4]) if len(args) > 4 else None
        e = int(args[5]) if len(args) > 5 else None
        sweep(args[1], args[2], args[3], s, e)
