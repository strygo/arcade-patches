"""Piecewise-aligned JP->US tile + palette mapping.

Tiles unique in BOTH regions' chunk pair anchor (jp_local -> us_local); any
local maps via its nearest anchor's delta. Handles identical art (delta 0),
redrawn art (the censored dress), and mid-chunk cel removals (Damnd's laugh,
Oc7 deltas -136/0/-33). Palettes swap only at detected-palette offsets,
alignment-corrected. See FINDINGS.md for the failed simpler rules.
"""
import struct, bisect, collections
from . import disc

_state = None
def _build():
    global _state
    if _state: return _state
    JP = disc.region_chunks("jp"); USr = disc.region_chunks("us")
    anch = {}
    for bd in ("E", "O"):
        for k, jc in JP[bd].items():
            uc = USr[bd].get(k)
            if uc is None: continue
            jpos = collections.defaultdict(list); upos = collections.defaultdict(list)
            for t in range(len(jc) // 32): jpos[jc[t*32:t*32+32]].append(t)
            for t in range(len(uc) // 32): upos[uc[t*32:t*32+32]].append(t)
            a = sorted((jl[0], upos[jb][0]) for jb, jl in jpos.items()
                       if len(jl) == 1 and len(upos.get(jb, [])) == 1)
            anch[(bd, k)] = a
    jpall = collections.defaultdict(list)
    for bd in ("E", "O"):
        for k, buf in JP[bd].items():
            for t in range(len(buf) // 32): jpall[buf[t*32:t*32+32]].append((bd, k, t))
    pal2loc = {}
    for bd in ("E", "O"):
        for k, buf in JP[bd].items():
            for off, w in disc.detect_palettes(buf):
                pal2loc.setdefault(tuple(w), (bd, k, off))
    _state = (JP, USr, anch, jpall, pal2loc)
    return _state

def us_local(anch, bd, k, jl):
    a = anch.get((bd, k))
    if not a: return jl
    i = bisect.bisect_left(a, (jl, -1)); best = None
    for j in (i - 1, i):
        if 0 <= j < len(a):
            d = abs(a[j][0] - jl)
            if best is None or d < best[0]: best = (d, a[j][1] - a[j][0])
    return jl + (best[1] if best else 0)

def _jp_bytes(vram, idx):
    o = bytearray()
    for y in range(8):
        w0 = vram[idx*16+y*2]; w1 = vram[idx*16+y*2+1]
        o += bytes([(w0>>8)&0xFF, w0&0xFF, (w1>>8)&0xFF, w1&0xFF])
    return bytes(o)

def synth_us(vram, cram, regs):
    """Return (us_vram, us_cram): the JP VDP state with US art + palettes."""
    JP, USr, anch, jpall, pal2loc = _build()
    a=(regs[2]&0x38)*0x400; b=(regs[4]&0x07)*0x2000
    sat=(regs[5]&0x7F)*0x200; winbase=(regs[3]&0x3F)*0x400
    used=set()
    for base in (a, b, winbase):
        used.update(vram[base//2+i]&0x7FF for i in range(2048))
    i=0
    for _ in range(80):
        w=sat//2+i*4; size=(vram[w+1]>>8)&0xFF; link=vram[w+1]&0x7F; attr=vram[w+2]
        hs=((size>>2)&3)+1; vs=(size&3)+1; t=attr&0x7FF
        used.update((t+c)&0x7FF for c in range(hs*vs))
        if link==0: break
        i=link
    cand=collections.Counter()
    for idx in used:
        if not idx: continue
        for (bd,k,t) in jpall.get(_jp_bytes(vram,idx), []): cand[(bd,k,idx-t)]+=1
    cands=[c for c,_ in cand.most_common(8)]
    out=list(vram)
    for idx in used:
        if not idx: continue
        jb=_jp_bytes(vram,idx)
        if jb==b"\x00"*32: continue
        for (bd,k,base) in cands:
            jl=idx-base; jc=JP[bd].get(k); uc=USr[bd].get(k)
            if jc is None or uc is None or jl<0 or jl*32+32>len(jc): continue
            if jc[jl*32:jl*32+32]!=jb: continue
            ul=us_local(anch,bd,k,jl)
            if 0<=ul and ul*32+32<=len(uc):
                ub=uc[ul*32:ul*32+32]
                for y in range(8):
                    b0,b1,b2,b3=ub[y*4:y*4+4]
                    out[idx*16+y*2]=(b0<<8)|b1; out[idx*16+y*2+1]=(b2<<8)|b3
                break
    uscram=list(cram)
    for line in range(4):
        loc=pal2loc.get(tuple(cram[line*16:line*16+16]))
        if not loc: continue
        bd,k,off=loc; uc=USr[bd].get(k)
        if uc is None: continue
        ul=us_local(anch,bd,k,off//32); uoff=ul*32+(off%32)
        if uoff+32<=len(uc):
            uw=[struct.unpack_from(">H",uc,uoff+2*i)[0] for i in range(16)]
            if all((w & ~0x0EEE)==0 for w in uw):
                uscram[line*16:line*16+16]=uw
    return out, uscram
