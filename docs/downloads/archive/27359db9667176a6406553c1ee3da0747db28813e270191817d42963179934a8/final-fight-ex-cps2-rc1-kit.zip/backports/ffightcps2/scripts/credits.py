#!/usr/bin/env python3
"""The port's credit in the ending's staff roll: "cps-2 port" and its author.

Final Fight EX on CPS1 credits its backport in the roll (``ffightcd``
``build/text.py`` build_credits, header "cd cutscenes"); the CPS2 port does
the same, with the same rule:

- the stock stream at CREDITS_SRC is copied row for row, except that each
  run of dot and blank rows holding a blank row becomes one dot (a blank
  row reads as a hole in the roll's dotted spine); the stock roll has seven
  such rows;
- the credit, written in the roll's idiom (a two-row magenta header, three
  dots, the name in the orange single-height font, one dot), goes before
  the last header, "special thanks".

Seven rows out, seven in: the roll keeps its 87 rows, one row per 16
frames, so the ending's timing after it does not move.

EX builds (EX_BUILD.md) credit both, CPS1 EX's "cd cutscenes" and this
port's "cps-2 port", over the one name: the two headers stacked, then three
dots, the name and a dot, nine rows, so the roll has 89 (21 October,
on kit 261021-14: "Credit sequence near our addition needs more dots before
my name"; until then the block had one dot, to stay seven rows). Two more
rows would move the farewell 32 frames later, and the Arrange and redub
ending audio is one track from the reunion's start through the farewell. So
the drawer's tail is shortened by the same 16 pixels (ROLL_TAIL, tail_patch):
after the terminator the stock roll scrolls on 272 pixels (0x110, its
"cmpi.w #$110,d0" at 0x18EF2) before the ending moves on; with the two rows
it scrolls 256. The roll then covers the same distance in the same frames
(87 x 8 + 272 = 89 x 8 + 256), so the farewell starts on the same frame.
The stream grows by 160 bytes (224 for EX) and moves to CREDITS_HOME in the
upper program ROM; the drawer's one pointer to it (``move.l
#$18F94,$70(a6)``, its long at 0x18E5E) is repointed.

The header font is the lowercase alphabet the stock headers use, two cells
tall (glyph g on top, g + 0x10 below). It has no '-' and no digits, so the
two this header needs are drawn here in its style (the vertical pen ramp
e d c b a 9 9 a b c d e, pen 8 shadowing each stroke's right and the bar
below, pen 0 lighting a top) and placed at scroll 1 codes only CPS2 has,
past the caption hyphen's (build_m1_spike.CAPTION_HYPHEN). The drawer adds
0x4400 to each cell ($18F52), so a cell reaches any code.

    python3 credits.py --self-test
    python3 credits.py --preview OUT.png      # the new rows over the stock font
"""
from __future__ import annotations

# BEGIN ARCADE PYTHON BOOTSTRAP
import sys as _arcade_sys
from pathlib import Path as _ArcadePath
_arcade_sys.path.insert(0, str(_ArcadePath(__file__).resolve().parents[3]))
from kit_python import bootstrap as _arcade_bootstrap
_arcade_bootstrap()
# END ARCADE PYTHON BOOTSTRAP

import argparse
import struct
import sys

CREDITS_SRC = 0x018F94                  # the stock stream (both regions)
CREDITS_POINTER = 0x018E5E              # the long in "move.l #$18F94,$70(a6)"
CREDITS_HOME = 0x300500                 # upper program ROM, after REGULATION's tables
STOCK_ROWS, STOCK_BYTES = 87, 1946
FIELD = 16                              # the roll's column; rows are centered in it
DOT = 0x60                              # the dotted spine
HEADER_ATTR, NAME_ATTR = 0x0006, 0x0000
HEADER = "cps-2 port"
EX_HEADERS = ("cd cutscenes", HEADER)   # CPS1 EX's credit, then the port's
NAME = "STEVE GORDON"                  # Backport by: the roll's credit for the port
DOTS = 3                                # after the headers, as the stock sections have
BLOCK_ROWS = 7                          # one header: the stock rows the merged blanks freed
ROW_PIXELS, FRAMES_PER_PIXEL = 8, 2     # the roll moves half a pixel a frame ($18E72)
# The drawer's tail: once it meets the terminator, it waits until the roll
# has scrolled this many pixels more, then the ending moves on.
ROLL_TAIL = (0x018EF2, 0x0110)          # cmpi.w #$110,d0 (0x0c40 0110)

# The stock header glyphs (top cell; the bottom is + 0x10). 'm' is two cells.
LOWER = {'a': 0x0E4, 'b': 0x0E5, 'c': 0x0E6, 'd': 0x0E7, 'e': 0x0E8, 'f': 0x0E9, 'h': 0x0EA,
         'i': 0x0EB, 'k': 0x0EC, 'l': 0x0ED, 'n': 0x100, 'o': 0x101, 'r': 0x102, 's': 0x103,
         't': 0x104, 'u': 0x105, 'g': 0x10B, 'j': 0x10C, 'p': 0x10D, ' ': 0x020}
PAIRS = {'m': (0x0EE, 0x0EF)}
# New glyphs at CPS2-only cells: tile 0x4400 + cell, 0x8041 and 0x8042 (graphics
# 0xA01040 and 0xA01080), bottoms 0x8051 and 0x8052.
NEW_CELLS = {'-': 0x3C41, '2': 0x3C42}

# Pen rows, top cell then bottom cell ('.' = pen 15, transparent).
NEW_ART = {
    '-': ("........", "........", "........", "........",
          "........", "........", "........", "........",
          ".99999..", ".999998.", "..88888.", "........",
          "........", "........", "........", "........"),
    '2': ("........", ".0000...", ".eeee8..", "dd88dd8.",
          "dd8.dd8.", ".8..cc8.", "...bb88.", "..aa88..",
          "..998...", ".998....", ".aa8....", "bb8.....",
          "cc8.....", "dddddd8.", "eeeeeee8", ".8888888"),
}


def be16(value):
    return struct.pack(">H", value)


def row(attr, cells):
    return be16(attr) + b"".join(be16(c) for c in cells) + be16(0)


def dot_row():
    return row(NAME_ATTR, [0x20] * ((FIELD - 1) // 2) + [DOT])


def header_rows(text):
    cells = []
    for ch in text:
        cells.extend(PAIRS.get(ch) or (NEW_CELLS.get(ch) or LOWER[ch],))
    if len(cells) > FIELD:
        raise ValueError(f"header {text!r} is {len(cells)} cells, wider than the roll's {FIELD}")
    lead = [0x20] * ((FIELD - len(cells)) // 2)
    return (row(HEADER_ATTR, lead + cells)
            + row(HEADER_ATTR, lead + [c if c == 0x20 else c + 0x10 for c in cells]))


def name_row(text):
    if len(text) > FIELD or not all(0x20 <= ord(c) < 0x7F for c in text):
        raise ValueError(f"name {text!r} does not fit the roll's ASCII field")
    return row(NAME_ATTR, [0x20] * ((FIELD - len(text)) // 2) + [ord(c) for c in text])


def parse(stream):
    """The stream's rows, each with its attribute word, the terminator last."""
    rows, at = [], 0
    while True:
        attr = struct.unpack_from(">H", stream, at)[0]
        start = at
        at += 2
        if attr & 0x8000:
            rows.append((attr, bytes(stream[start:at])))
            return rows
        while struct.unpack_from(">H", stream, at)[0]:
            at += 2
        at += 2
        rows.append((attr, bytes(stream[start:at])))


def glyphs(raw):
    return [struct.unpack_from(">H", raw, k)[0] for k in range(2, len(raw) - 2, 2)]


def collapse(rows):
    """Each run of dot and blank rows holding a blank row becomes one dot."""
    out, i, saved = [], 0, 0
    kind = lambda attr, raw: (None if attr & 0x8000 else "blank" if not glyphs(raw)
                              else "dot" if all(g in (0x20, DOT) for g in glyphs(raw)) else None)
    while i < len(rows):
        j = i
        while j < len(rows) and kind(*rows[j]):
            j += 1
        if j > i and any(kind(*r) == "blank" for r in rows[i:j]):
            out.append((NAME_ATTR, dot_row()))
            saved += j - i - 1
            i = j
        elif j > i:
            out.extend(rows[i:j])
            i = j
        else:
            out.append(rows[i])
            i += 1
    return out, saved


def build(stream, headers=(HEADER,), name=NAME):
    """The roll with the credit, and a receipt of its rows: the headers
    stacked, then three dots (as the stock sections have), the name and a
    dot.  One header makes BLOCK_ROWS rows, the rows the merged blanks
    freed; each more adds two, which tail_patch gives back."""
    rows = parse(stream)
    collapsed, saved = collapse(rows)
    tops = [k for k, (attr, raw) in enumerate(collapsed)    # a header's top row: no bottom glyph
            if attr == HEADER_ATTR and not any(g >= 0x110 for g in glyphs(raw))]
    at = tops[-1]                       # "special thanks"
    block = b"".join(header_rows(h) for h in headers) + dot_row() * DOTS + name_row(name) + dot_row()
    out = b"".join(r for _, r in collapsed[:at]) + block + b"".join(r for _, r in collapsed[at:])
    added = len(parse(block + be16(0x8000))) - 1
    return out, {"stock_rows": len(rows), "blank_rows_merged": saved, "credit_rows": added,
                 "rows": len(rows) - saved + added, "headers": list(headers), "name": name}


def tail_patch(rows):
    """The patch (address, stock hex, new hex, reason) that shortens the
    drawer's tail by the pixels rows past STOCK_ROWS add, so the roll ends on
    the stock frame; None for a roll of STOCK_ROWS."""
    extra = rows - STOCK_ROWS
    if not extra:
        return None
    address, stock = ROLL_TAIL
    tail = stock - extra * ROW_PIXELS
    if extra < 0 or tail < 0:
        raise ValueError(f"a roll of {rows} rows has no tail to give back")
    return (address, f"0c40{stock:04x}", f"0c40{tail:04x}",
            f"the staff roll's tail {tail} pixels, not {stock}: its {extra} more rows end on the stock frame "
            f"(credits.py)")


def roll_frames(rows, tail):
    """Frames from the roll's first row to the ending's next phase."""
    return (rows * ROW_PIXELS + tail) * FRAMES_PER_PIXEL


def tile(art):
    """Scroll 1 tile bytes for 8 pen rows, the same 8x8 in both halves
    (even and odd columns), as the font's own tiles are."""
    out = bytearray()
    for line in art:
        planes = [0, 0, 0, 0]
        for x, ch in enumerate(line):
            pen = 15 if ch == "." else int(ch, 16)
            for k in range(4):
                planes[k] |= (pen >> k & 1) << (7 - x)
        out += bytes(planes) * 2
    return bytes(out)


def pieces():
    """The new glyphs' tiles as (CPS2 graphics offset, bytes), top and bottom."""
    out = []
    for ch, cell in NEW_CELLS.items():
        top = 0x800000 + (0x4400 + cell) * 64
        out += [(top, tile(NEW_ART[ch][:8])), (top + 0x10 * 64, tile(NEW_ART[ch][8:]))]
    return out


def region_with_glyphs(region):
    """A copy of a scroll 1 region (code * 64) holding the new glyphs too."""
    end = max(off - 0x800000 + 64 for off, _ in pieces())
    out = bytearray(region) + b"\xff" * max(0, end - len(region))
    for off, data in pieces():
        out[off - 0x800000:off - 0x800000 + 64] = data
    return out


def preview(region, program, rows_out, path, scale=3):
    """The credit's rows as the roll draws them, in the game's scroll 1 palettes."""
    from PIL import Image
    import text_catalog as tc
    region = region_with_glyphs(region)
    lines = parse(rows_out)
    out = Image.new("RGB", (FIELD * 8, 8 * len(lines)))
    px = out.load()
    for y0, (attr, raw) in enumerate(lines):
        if attr & 0x8000:
            break
        colors = [tc.cps_rgb(struct.unpack_from(">H", program, tc.PALETTES + (attr & 0x1F) * 32 + 2 * p)[0])
                  for p in range(16)]
        for col, g in enumerate(glyphs(raw)):
            code = (g + 0x4400) & 0xFFFF
            for y in range(8):
                at = code * 64 + y * 8 + 4 * (col & 1)
                planes = region[at:at + 4]
                for x in range(8):
                    pen = sum((planes[k] >> (7 - x) & 1) << k for k in range(4))
                    if pen != 15:
                        px[col * 8 + x, y0 * 8 + y] = colors[pen]
    out.resize((out.width * scale, out.height * scale), Image.NEAREST).save(path)


def self_test():
    stream = (header_rows("planner") + dot_row() * 3 + name_row("A") + row(0, []) + row(0, [])
              + dot_row() + header_rows("special thanks") + dot_row() * 3 + name_row("B") + be16(0x8000))
    rows = parse(stream)
    assert len(rows) == 16 and rows[-1][0] == 0x8000
    collapsed, saved = collapse(rows)
    assert saved == 2 and len(collapsed) == 14          # "blank, blank, dot" became one dot
    assert collapse(parse(dot_row() * 3 + be16(0x8000)))[1] == 0     # dots alone stay
    out, receipt = build(stream)
    assert receipt == {"stock_rows": 16, "blank_rows_merged": 2, "credit_rows": 7, "rows": 21,
                       "headers": [HEADER], "name": NAME}
    ex_out, ex_receipt = build(stream, EX_HEADERS)
    assert ex_receipt["credit_rows"] == 9 and ex_receipt["rows"] == 23
    assert ex_out.index(header_rows(EX_HEADERS[0])) < ex_out.index(header_rows(HEADER))
    # three dots between the headers and the name, as after a stock header
    both = header_rows(EX_HEADERS[0]) + header_rows(HEADER)
    assert ex_out[ex_out.index(both) + len(both):].startswith(dot_row() * 3 + name_row(NAME) + dot_row())
    assert out[out.index(header_rows(HEADER)) + len(header_rows(HEADER)):].startswith(dot_row() * 3 + name_row(NAME))
    # the tail gives back exactly the two rows' frames
    assert tail_patch(STOCK_ROWS) is None
    address, stock_hex, new_hex, _ = tail_patch(STOCK_ROWS + 2)
    assert (address, stock_hex, new_hex) == (0x18EF2, "0c400110", "0c400100")
    assert roll_frames(STOCK_ROWS + 2, 0x100) == roll_frames(STOCK_ROWS, 0x110)
    names = [bytes(glyphs(raw)).decode().strip() for _, raw in parse(out)
             if raw[:2] == be16(NAME_ATTR) and glyphs(raw) and max(glyphs(raw)) < 0x60]
    assert names == ["A", NAME, "B"], names             # the credit sits before "special thanks"
    top = glyphs(parse(header_rows(HEADER) + be16(0x8000))[0][1])
    assert len([g for g in top if g != 0x20]) == 9 and 0x3C41 in top and 0x3C42 in top
    for ch, art in NEW_ART.items():
        assert len(art) == 16 and all(len(line) == 8 for line in art)
        assert all(c in ".089abcde" for line in art for c in line)
    t = tile(NEW_ART['-'][:8])
    assert len(t) == 64 and t[:4] == t[4:8] == b"\xff\xff\xff\xff"
    assert [off for off, _ in pieces()] == [0xA01040, 0xA01440, 0xA01080, 0xA01480]
    try:
        header_rows("final fight cps-2 port")
    except ValueError:
        pass
    else:
        raise AssertionError("a header wider than the field was accepted")
    print("self-test passed")


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--self-test", action="store_true")
    parser.add_argument("--preview", metavar="PNG")
    parser.add_argument("--rompath", action="append", default=[])
    parser.add_argument("--ex", action="store_true", help="the EX builds' roll (both credits)")
    args = parser.parse_args(argv)
    if args.self_test:
        self_test()
        return 0
    if args.preview:
        from pathlib import Path
        import build_m1_spike as spike
        rompaths = [Path(p) for p in args.rompath] + spike.default_rompaths()
        archive = spike.find_archive(rompaths, "ffightj")
        program = spike.stock_program(archive)
        headers = EX_HEADERS if args.ex else (HEADER,)
        out, receipt = build(program[CREDITS_SRC:CREDITS_SRC + STOCK_BYTES], headers)
        print(receipt)
        start = out.index(header_rows(headers[0])) - 12 * len(dot_row())
        preview(spike.stock_graphics(archive), program, out[start:], args.preview)
        return 0
    parser.print_help()
    return 0


if __name__ == "__main__":
    sys.exit(main())
