#!/usr/bin/env python3
"""Final Fight's story, profile, ending and staff text, both regions.

For the English edition's translation review (ENGLISH_EDITION.md). The
Japanese and export programs are the same program, so one image holds both
languages; the record formats are backports/ffightcd's findings
(ffcd/captions.py, docs/FINDINGS.md), re-read here on the stock program:

- group 1, the typewriter (``$1380``): offsets at 0x68566; a record is a
  per-glyph delay byte (frames the task sleeps after each glyph word), a
  mode byte (0 single height; 2 double height, the glyph + 0x10 below,
  except 0x5E6, 0x5E7 and 0x02D; 4 double height), then segments: cell
  (column * 0x80 + row * 4 in the scroll 1 map), attribute (palette in the
  low 5 bits), glyph words (tile 0x4400 + glyph); 0 ends the record, a word
  with bit 15 starts the next segment;
- group A, drawn at once (``$1308``): offsets at 0x67082, segments only;
- the byte printer (``$1258``): offsets at 0x65E7E; column, row (bit 7 adds
  0x800 to the cell), attribute, then glyph bytes (tile 0x4400 + byte); 0x5C
  starts a new position, 0 ends.

Story lines are fired by line number through 0x17986 (export) or 0x179A1
(Japan), id 0x100 + the table's byte. Each record is rendered with the scroll
1 tiles its region shows (Japan: ffightj's; English: the edition's, with the
World set's text tiles) in the scroll 1 palettes at 0xC2800, and its typing
cost (delay times glyph words) is recorded for fitting the English text to
the Japanese timeline.

    CAPCOM_WORK_ROOT=/Volumes/CapcomScratch python3 text_catalog.py
"""
from __future__ import annotations

# BEGIN ARCADE PYTHON BOOTSTRAP
import sys as _arcade_sys
from pathlib import Path as _ArcadePath
_arcade_sys.path.insert(0, str(_ArcadePath(__file__).resolve().parents[3]))
from kit_python import bootstrap as _arcade_bootstrap
_arcade_bootstrap()
# END ARCADE PYTHON BOOTSTRAP

import argparse
import hashlib
import json
from pathlib import Path
import struct
import sys

from PIL import Image

import build_m1_spike as spike

TRACK = Path(__file__).resolve().parents[1]
GROUP1, GROUPA, BYTES = 0x68566, 0x67082, 0x65E7E
LINES = {"english": 0x17986, "japan": 0x179A1}
PALETTES = 0xC2800                       # scroll 1 palettes, 32 bytes each
SINGLE = {0x5E6, 0x5E7, 0x02D}           # mode 2 glyphs drawn single height ($141C)
SCENES = ([("map", d) for d in range(4)] + [("phone", d) for d in range(4, 10)]
          + [("tv", d) for d in range(10, 16)] + [("guy_cody", d) for d in range(16, 20)]
          + [("profile", d) for d in range(20, 23)] + [("interlude", d) for d in range(23, 27)])
# Records fired directly, per region (the region gates in ENGLISH_EDITION.md).
DIRECT = {
    "english": [("ending", "g1", 0x3A), ("ending", "g1", 0x3C), ("ending", "g1", 0x3E), ("ending", "g1", 0x38),
                ("year_card", "gA", 0x08), ("title", "gA", 0x07), ("staff", "gA", 0x0C), ("staff", "gA", 0x0B),
                ("staff", "bytes", 0x3A), ("staff", "bytes", 0x3B), ("staff", "bytes", 0xBA),
                ("unused", "g1", 0x0F), ("unused", "g1", 0x10), ("unused", "g1", 0x11)],
    "japan": [("ending", "g1", 0x39), ("ending", "g1", 0x3B), ("ending", "g1", 0x3D), ("ending", "g1", 0x38),
              ("year_card", "gA", 0x09), ("title", "gA", 0x05), ("staff", "gA", 0x0A), ("staff", "gA", 0x0B),
              ("staff", "gA", 0x0D), ("staff", "gA", 0x0E), ("staff", "gA", 0x8D)],
}


def word(image, at):
    return struct.unpack_from(">H", image, at)[0]


def segments(image, at):
    out = []
    while True:
        cell, attr = word(image, at), word(image, at + 2)
        at += 4
        glyphs = []
        while True:
            g = word(image, at)
            at += 2
            if g == 0 or g & 0x8000:
                break
            glyphs.append(g)
            if len(glyphs) > 200:
                raise ValueError(f"runaway record near {at:#x}")
        out.append({"col": cell // 0x80, "row": (cell % 0x80) // 4, "pal": attr & 0x1F, "glyphs": glyphs})
        if g == 0:
            return out


def byte_record(image, at):
    out, col, row, attr = [], image[at], image[at + 1], image[at + 2]
    at += 3
    while True:
        glyphs = []
        while image[at] not in (0, 0x5C):
            glyphs.append(image[at])
            at += 1
        out.append({"col": col, "row": row & 0x7F, "page2": bool(row & 0x80), "pal": attr & 0x1F,
                    "glyphs": glyphs})
        if image[at] == 0:
            return out
        col, row, attr = image[at + 1], image[at + 2], image[at + 3]
        at += 4


def record(image, kind, index):
    if kind == "g1":
        at = GROUP1 + word(image, GROUP1 + 2 * index)
        return {"delay": image[at], "mode": image[at + 1], "segments": segments(image, at + 2), "address": at}
    if kind == "gA":
        at = GROUPA + word(image, GROUPA + 2 * index)
        return {"delay": None, "mode": 0, "segments": segments(image, at), "address": at}
    at = BYTES + word(image, BYTES + 2 * index)
    return {"delay": None, "mode": 0, "segments": byte_record(image, at), "address": at}


def cps_rgb(value):
    level = 0x0F + ((value >> 12) << 1)
    return tuple((value >> s & 0xF) * 0x11 * level // 0x2D for s in (8, 4, 0))


def render(region, image, rec):
    """The record's cells on black, 8 pixels a cell, cropped to its extent."""
    cells = {}
    for seg in rec["segments"]:
        for k, g in enumerate(seg["glyphs"]):
            cells[(seg["col"] + k, seg["row"])] = (0x4400 + g, seg["pal"])
            if rec["mode"] == 4 or (rec["mode"] == 2 and g not in SINGLE):
                cells[(seg["col"] + k, seg["row"] + 1)] = (0x4400 + g + 0x10, seg["pal"])
    if not cells:
        return Image.new("RGB", (8, 8))
    c0, c1 = min(c for c, _ in cells), max(c for c, _ in cells)
    r0, r1 = min(r for _, r in cells), max(r for _, r in cells)
    out = Image.new("RGB", ((c1 - c0 + 1) * 8, (r1 - r0 + 1) * 8))
    px = out.load()
    for (col, row), (code, pal) in cells.items():
        colors = [cps_rgb(word(image, PALETTES + pal * 32 + 2 * p)) for p in range(16)]
        if code * 64 + 64 > len(region):        # not a text tile: mark the cell
            for y in range(8):
                for x in range(8):
                    px[(col - c0) * 8 + x, (row - r0) * 8 + y] = (96, 0, 96)
            continue
        for y in range(8):
            at = code * 64 + y * 8 + 4 * (col & 1)        # MAME: left half in even columns
            planes = region[at:at + 4]
            for x in range(8):
                pen = sum((planes[k] >> (7 - x) & 1) << k for k in range(4))
                if pen != 15:
                    px[(col - c0) * 8 + x, (row - r0) * 8 + y] = colors[pen]
    return out


# English glyphs (the story records' double-height font; backports/ffightcd
# gen_caption_repos.py, with O and P at 0x58E/0x58F as the profiles spell
# them); the byte printer and group A's titles draw ASCII codes.
ENGLISH = {0x010: " ", 0x5AA: ".", 0x5E8: ",", 0x5E5: "'", 0x5EC: "?", 0x5ED: "!", 0x02D: "-",
           0x5E6: '"', 0x5E7: '"', 0x5E9: ":", 0x5EA: "(", 0x5EB: ")"}
ENGLISH.update({0x5AB + i: c for i, c in enumerate("abcde")})
ENGLISH.update({0x5C0 + i: c for i, c in enumerate("fghijklmnopqrstu")})
ENGLISH.update({0x5E0 + i: c for i, c in enumerate("vwxyz")})
ENGLISH.update({0x580 + i: c for i, c in enumerate("ABCDEFGHIJKLMNOP")})
ENGLISH.update({0x5A0 + i: c for i, c in enumerate("QRSTUVWXYZ")})
ENGLISH.update({0x628 + i: c for i, c in enumerate("12345678")})
ENGLISH.update({0x64C: "9", 0x64D: "0"})


def english_text(rec):
    lines = []
    for seg in rec["segments"]:
        lines.append("".join(ENGLISH.get(g, chr(g) if 0x20 <= g < 0x7F else f"[{g:03x}]")
                             for g in seg["glyphs"]).rstrip())
    return [line for line in lines if line]


def glyph_words(rec):
    return sum(len(s["glyphs"]) for s in rec["segments"])


def catalog(rompaths, out):
    image = bytes(spike.stock_program(spike.find_archive(rompaths, "ffightj")))
    japan = spike.stock_graphics(spike.find_archive(rompaths, "ffightj"))
    english = bytearray(japan)
    spike.english_text(english, spike.world_graphics(spike.find_archive(rompaths, "ffight")))
    regions = {"japan": japan, "english": english}
    out.mkdir(parents=True, exist_ok=True)
    rows = []
    for edition in ("japan", "english"):
        jobs = [(scene, d1, "g1", image[LINES[edition] + d1]) for scene, d1 in SCENES]
        jobs += [(scene, None, kind, index) for scene, kind, index in DIRECT[edition]]
        for scene, d1, kind, index in jobs:
            ident = {"g1": 0x100, "gA": 0xA00, "bytes": 0}[kind] + index
            name = f"{edition}_{kind}_{index:02x}"
            rec = record(image, kind, index)
            picture = render(regions[edition], image, rec)
            picture.resize((picture.width * 2, picture.height * 2), Image.NEAREST).save(out / f"{name}.png")
            rows.append({"edition": edition, "scene": scene, "line": d1, "kind": kind, "id": f"{ident:#05x}",
                         "address": f"{rec['address']:#x}", "delay": rec["delay"], "mode": rec["mode"],
                         "glyph_words": glyph_words(rec),
                         "text": english_text(rec) if edition == "english" else None,
                         "typing_frames": None if rec["delay"] is None else rec["delay"] * glyph_words(rec),
                         "segments": [{**s, "glyphs": [f"{g:03x}" for g in s["glyphs"]]} for s in rec["segments"]],
                         "glyph_sha256": hashlib.sha256(json.dumps(rec["segments"], sort_keys=True).encode()).hexdigest(),
                         "image": f"{name}.png"})
    (out / "catalog.json").write_text(json.dumps(rows, indent=1) + "\n")
    return rows


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--rompath", action="append", type=Path, default=[])
    parser.add_argument("--out", type=Path, default=TRACK / "work" / "text-catalog")
    args = parser.parse_args(argv)
    rows = catalog(args.rompath + spike.default_rompaths(), args.out)
    for edition in ("japan", "english"):
        story = [r for r in rows if r["edition"] == edition and r["line"] is not None]
        print(edition, len([r for r in rows if r["edition"] == edition]), "records;",
              sum(r["typing_frames"] or 0 for r in story), "typing frames in the story lines")
    return 0


if __name__ == "__main__":
    sys.exit(main())
