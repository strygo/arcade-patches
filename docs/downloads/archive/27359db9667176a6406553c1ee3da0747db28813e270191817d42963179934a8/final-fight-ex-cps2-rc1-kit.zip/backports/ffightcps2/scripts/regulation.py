#!/usr/bin/env python3
"""REGULATION: Jessica in a red strapless top on the intro's TV, and white blood.

Final Fight's arcade intro shows Jessica on a TV in lingerie, one picture
the game flickers by rewriting its palette. With REGULATION ON (13
October 2026) the CPS2 build shows its own edit of that picture: a
red gathered strapless top, the straps and the tops of the cups repainted
as skin. ``DRESS_ROWS`` is that edit as pens on ``ffightj``'s picture,
read from his screenshot pixel for pixel (aligned at 8.76 x 8.74 and snapped
to the screenshot's own colors for the arcade pens, plus five new colors);
only the changed pixels are recorded, so nothing of the arcade art is
committed, and the build checks the stock pixels it applies to by SHA-256.

The changed cells become new scroll 2 tiles in free graphics space. The
layer swaps them in while REGULATION is ON and the TV shows the picture (it
is in the scroll 2 map and the scroll is the shot's: Final Fight leaves it
in the map through Damnd's shot after it), and builds their palette (``REG_PALETTE``) every frame from the
picture's (18) with the five new colors as offsets from the pens they
replace, so the top fades and flickers with the rest of the picture.

Blood (14 October 2026: white with REGULATION ON, as other CPS games
show it). A knife or sword hit starts Final Fight's hit effect with blood
(entry 3 of its animation table, ``BLOOD_SCRIPTS``), three frames of one
splash tile and two droplet blocks drawn in palette 12's pen 9, its pure red;
another blood object starts the same bytes from its own copy. Pen 9 of
palette 12 also colors enemies, so the palette stays: ``white_blood`` copies
the animation with the frames in palette 7, Final Fight's whites and grays
in every stage (pen 9 is its near white), and with REGULATION ON the layer
starts blood from that copy (``REG_BLOOD``).
"""
from __future__ import annotations

# BEGIN ARCADE PYTHON BOOTSTRAP
import sys as _arcade_sys
from pathlib import Path as _ArcadePath
_arcade_sys.path.insert(0, str(_ArcadePath(__file__).resolve().parents[3]))
from kit_python import bootstrap as _arcade_bootstrap
_arcade_bootstrap()
# END ARCADE PYTHON BOOTSTRAP

import argparse
import hashlib
import struct
import sys

import build_m1_spike as spike

# The picture's scroll 2 cells (ffightj, palette 18): rows from screen y 48,
# columns from x 160. The intro draws them at map columns 10-14, rows 36-40,
# of the scroll 2 map at 0x90C000.
CELLS = ((0x3955, 0x395D, 0x395E, 0x395F, 0x333E),
         (0x3963, 0x3956, 0x3957, 0x3966, 0x3967),
         (0x396B, 0x396C, 0x396D, 0x396E, 0x396F),
         (0x3973, 0x3974, 0x3975, 0x3976, 0x3977),
         (0x397B, 0x397C, 0x397D, 0x397E, 0x397F))
MAP_BASE, MAP_COLUMN, MAP_ROW = 0x90C000, 10, 36
SCROLL = (0x0000, 0x0100)               # Final Fight's scroll 2 X and Y ($2e/$30 of its
                                        #   RAM at $ff8000) while the TV shows it
DRESS_FIRST_ROW = 2                     # cell rows from screen line 80 hold the edit
PALETTE_ROM = 0x01DE7C                  # palette 18, stored at brightness 0
PALETTE_WORDS = (0x0433, 0x0EB9, 0x0DA8, 0x0C97, 0x0B86, 0x0A75, 0x0864, 0x0754, 0x0644, 0x0EEE,
                 0x0CDD, 0x0ABD, 0x089C, 0x067B, 0x0A08, 0x0000)
PICTURE_PALETTE, REG_PALETTE = 18, 31   # scroll 2 palettes: the picture's and the top's
DRESS_PENS = range(9, 14)               # the bra's pens (white to blue) become the top's
DRESS_WORDS = (0x0E33, 0x0B23, 0x0823, 0x0633, 0x0313)   # four reds and the dark outline
STOCK_SHA256 = "6316ae8bd1e358d6370f53bbf5d911fc80c29778b0b98a96e560231e45605f93"
DRESSED_SHA256 = "cd5dd2e419f096347b8aea161b2d845adfd991f72960b2b9d9fefec6712096e2"
REG_TABLE = 0x300400                    # upper program ROM, after the QSound screen's table
REG_CODES = 0x0200                      # free scroll 2 codes (CPS2 graphics 0x810000 on)
BLOOD_SCRIPTS = (0x055652, 0x0218E2)    # the hit effect's blood and the other blood object's
BLOOD_BYTES = 0x3E                      # the script (5 steps) and its three frames
BLOOD_ATTRIBUTES = ((0x1E, 0x002C), (0x2C, 0x112C), (0x3A, 0x112C))   # offset, stock word
BLOOD_PALETTE, WHITE_PALETTE = 12, 7
BLOOD_PEN, GRAY_PEN = 9, 10                # palette 7: pen 9 0xEEE, pen 10 0xCCC
GRAY_CODES = 0x5000                        # object codes past CPS1's graphics (CPS2 0x280000 on)
REG_BLOOD = 0x3004A0                    # after REG_TABLE: an index table, then the copy
# The edit, screen lines 80-127 by x 160-239: "." keeps ffightj's pen,
# a hex digit is the edit's pen (9-12 reds, 13 the outline, else palette 18).
DRESS_ROWS = (
    "..................5.............................................................",
    "................................................................................",
    "..........................................................6....4................",
    ".............4.5566...................................0400088..00808............",
    "................54.....788............................5.5...5.556.66............",
    ".............3344............................................44444..............",
    "..............222.445...................................3..322244.....5678......",
    "..........2..11121.3...4...................................2..4431.....45.......",
    ".........32111111.1...........................................3222......45......",
    ".........2211.12...11........................................32211..............",
    "........22.11122....11.....................................211112...............",
    ".......322..122222222211.................................111112222..............",
    ".......22..2222222222222....................................223332..............",
    ".......22..222222..2...2................................12.3333322..............",
    ".......22.22222.........................................33333333222.............",
    "........2.22222...............................................33222222..........",
    "..........22224...............................................3332.2222.........",
    "...........2344...............................................333332222.........",
    "...........3.44...............................................333333342.........",
    "...........44445..............................................333333453.........",
    "...........44455.....................................44444..3.3433.4.73.........",
    "...........54.45....44................................444......443446745........",
    ".............45.......3333........................55.....444.555445586..........",
    "..........8.555..4..33333333......................3333333..44454.45.86..........",
    "........346.55454..3333223333...................33323222222323454.576...........",
    "..........586554.333.222222222................3332222.22.222223455676...........",
    "........734675456.cbbbaa522111223............3.221122.bbbbbbb.555577............",
    "..........46b5c.c..bbbbbbab2212222..............11.1abbbb.bbb.bbbb77............",
    "...........7b.cc..b.ccbbbbbabb12222.......5......4abbbbb.bccc.cbbbb7............",
    "...........7..c.bcccc.ccccbaaabb2222.3..........aabbb...ccc..c.c.bbc............",
    ".............c.ccccc.cbbbbccba9abb22.3...5.2..2bbbbaab.bbbbbc.c...cc............",
    "...........4..ccccc..bbbbbbbbbb9abb2.335.5.3.3bba.ab.bbbbb.b..cc..cc............",
    "...........5cccccc.bbb.b...bbbbb99bb.43555.42bb9.bbb.bb.b.b.....c..c............",
    "...........7cccccbbb.a.aaa..abbbb99cb4555543bb99bbbbbbaaaa...bb..c.c............",
    "...........cccccbb....a..aaaaaabbb99cbc5c5bbb.ab.aabbaa........bbc.c............",
    "...........dccc.b...99999999....abc99cccccbbaabb.a.aaa.999999...bc.c............",
    "............cccbb..99.......99.aabbc9acccbbabcba9aa..999....999..c.d............",
    "............d.cbb..........9.99.aa9bcabcccbbca9aaa..99.........9.c..............",
    ".............0cb.a.............9.aabbcbbbcc.ba..a.999..........abc..............",
    "................b..................a..ccc.c...aa.999.........aab................",
    ".......................aaaaa.........c.cccc..aa9999.......aaaaabc...............",
    "................b...aaaaaaaaaaa..a..cb..ccccc.a99..aaaaaaaaaaabcd...............",
    "................c..a.aaaaaaaaaa...bbb9bcbb.c.c..9aaaaaaaaaaaabcd................",
    "...............0dccb.a..aaaaaa..abca9accaabcb.ccbaaaaaaaaa.b....................",
    "...............0cdccbbbaa..a.bbaaaa99ccba9abc9ab..b......b..ccd.................",
    "................ccccccbbbbbbbbaaa999abba999aaba9bbb.....bccccd..................",
    "................8bbccbcbbbbaaaa9999aaba999999aba9aabbbbbbbbccd..................",
    "................dcbbccbbaaaaa99999aaba99999999aba9aabbbbbbcccd..................",
)


def tile_pens(tile):
    """A 16x16 tile's pens, rows of 16 (two 8-pixel groups of four planes)."""
    rows = []
    for y in range(16):
        row = []
        for half in range(2):
            planes = tile[y * 8 + half * 4:y * 8 + half * 4 + 4]
            row += [sum((planes[k] >> (7 - x) & 1) << k for k in range(4)) for x in range(8)]
        rows.append(row)
    return rows


def tile_bytes(rows):
    out = bytearray(128)
    for y, row in enumerate(rows):
        for half in range(2):
            for x in range(8):
                pen = row[half * 8 + x]
                for k in range(4):
                    if pen >> k & 1:
                        out[y * 8 + half * 4 + k] |= 0x80 >> x
    return bytes(out)


def picture_pens(region):
    pens = [[0] * 80 for _ in range(80)]
    for r, codes in enumerate(CELLS):
        for c, code in enumerate(codes):
            for y, row in enumerate(tile_pens(region[code * 128:(code + 1) * 128])):
                pens[r * 16 + y][c * 16:c * 16 + 16] = row
    return pens


def dressed(pens):
    top = DRESS_FIRST_ROW * 16
    if hashlib.sha256(bytes(p for row in pens[top:] for p in row)).hexdigest() != STOCK_SHA256:
        raise ValueError("ffightj's TV picture is not the one the REGULATION edit applies to")
    new = [row[:] for row in pens]
    for y, line in enumerate(DRESS_ROWS):
        for x, ch in enumerate(line):
            if ch != ".":
                new[top + y][x] = int(ch, 16)
    if hashlib.sha256(bytes(p for row in new[top:] for p in row)).hexdigest() != DRESSED_SHA256:
        raise ValueError("the REGULATION edit did not reproduce its pinned picture")
    return new


def build(region, rompaths=(), gray_blood=True):
    """(table bytes, white blood bytes for REG_BLOOD, graphics pieces for
    cps2_graphics, receipt). Table: the
    shot's scroll 2 X and Y, the cell count, per cell its map address, stock
    code and new code, then the picture's palette, the top's palette and 16
    offset words (each added to the picture's pen to make the top's; nonzero
    for the top's pens). gray_blood: the blood in 0xCCC (gray_tiles), the chosen
    gray (15 October); False keeps palette 7's pen 9, 0xEEE."""
    stock = bytes(spike.stock_program(spike.find_archive(list(rompaths) + spike.default_rompaths(), "ffightj")))
    if struct.unpack_from(">16H", stock, PALETTE_ROM) != PALETTE_WORDS:
        raise ValueError(f"palette 18 at {PALETTE_ROM:#x} is not the picture's")
    pens = picture_pens(region)
    new = dressed(pens)
    cells, pieces, code = [], [], REG_CODES
    for r in range(DRESS_FIRST_ROW, len(CELLS)):
        for c, stock_code in enumerate(CELLS[r]):
            rows = [new[r * 16 + y][c * 16:c * 16 + 16] for y in range(16)]
            changed = rows != [pens[r * 16 + y][c * 16:c * 16 + 16] for y in range(16)]
            if not changed and not any(p in DRESS_PENS for row in rows for p in row):
                continue                # neither repainted nor holding a pen that turns red
            new_code = stock_code
            if changed:
                new_code, code = code, code + 1
                pieces.append((0x800000 + new_code * 128, tile_bytes(rows)))
            column, row = MAP_COLUMN + c, MAP_ROW + r
            index = (row & 0x0F) + ((column & 0x3F) << 4) + ((row & 0x30) << 6)
            cells.append((MAP_BASE + 4 * index, stock_code, new_code))
    table = struct.pack(">3H", *SCROLL, len(cells))
    for address, stock_code, new_code in cells:
        table += struct.pack(">LHH", address, stock_code, new_code)
    offsets = [(DRESS_WORDS[p - DRESS_PENS[0]] - PALETTE_WORDS[p]) & 0xFFFF if p in DRESS_PENS else 0
               for p in range(16)]
    table += struct.pack(">HH16H", PICTURE_PALETTE, REG_PALETTE, *offsets)
    blood, blood_pieces, blood_receipt = blood_data(stock, region, gray_blood)
    pieces += blood_pieces
    receipt = {"home": f"{REG_TABLE:#x}", **spike.identity(table), "scroll": [f"{v:04x}" for v in SCROLL],
               "cells": len(cells),
               "new_tiles": len(pieces), "codes": [f"{REG_CODES:04x}", f"{code - 1:04x}"],
               "pixels_changed": sum(a != b for ra, rb in zip(pens, new) for a, b in zip(ra, rb)),
               "dress_words": [f"{w:03x}" for w in DRESS_WORDS], "dressed_sha256": DRESSED_SHA256,
               "white_blood": blood_receipt}
    return table, blood, pieces, receipt


def blood_data(stock, region, gray_blood=True):
    """(REG_BLOOD bytes, graphics pieces, receipt): white blood alone, from
    the edition's stock program and graphics. USA EX takes only this (the
    USA program cuts the TV shot); build() includes it."""
    blood = white_blood(stock, GRAY_CODES if gray_blood else None)
    pieces = gray_tiles(stock, region) if gray_blood else []
    receipt = {"home": f"{REG_BLOOD:#x}", **spike.identity(blood),
               "from": [f"{a:#x}" for a in BLOOD_SCRIPTS],
               "palette": [BLOOD_PALETTE, WHITE_PALETTE],
               "pen": GRAY_PEN if gray_blood else BLOOD_PEN}
    return blood, pieces, receipt


def blood_frames(stock):
    """Final Fight's blood animation block (both copies identical)."""
    blocks = {bytes(stock[a:a + BLOOD_BYTES]) for a in BLOOD_SCRIPTS}
    if len(blocks) != 1:
        raise ValueError("Final Fight's two blood animations differ")
    return bytearray(blocks.pop())


def gray_tiles(stock, region):
    """(CPS2 layout offset, tile) pieces: each blood frame's tiles with pen
    BLOOD_PEN drawn as GRAY_PEN, at GRAY_CODES in the frame's block layout
    (column + 1, row + 16)."""
    block, pieces = blood_frames(stock), []
    for k, (at, _) in enumerate(BLOOD_ATTRIBUTES):
        attr, code = struct.unpack_from(">HH", block, at)
        for r in range(((attr >> 12) & 15) + 1):
            for c in range(((attr >> 8) & 15) + 1):
                tile = bytearray(region[(code + c + 16 * r) * 128:(code + c + 16 * r + 1) * 128])
                for i in range(0, 128, 4):
                    planes = tile[i:i + 4]
                    for x in range(8):
                        bit = 0x80 >> x
                        pen = sum(((planes[q] & bit) != 0) << q for q in range(4))
                        if pen == BLOOD_PEN:
                            for q in range(4):
                                planes[q] = (planes[q] | bit) if GRAY_PEN >> q & 1 else (planes[q] & ~bit)
                    tile[i:i + 4] = planes
                pieces.append(((GRAY_CODES + 2 * k + c + 16 * r) * 128, bytes(tile)))
    return pieces


def white_blood(stock, gray_codes=None):
    """REG_BLOOD: an animation index table whose entry 3 (the hit effect's
    blood) points 8 bytes on, to Final Fight's blood animation with its three
    frames in WHITE_PALETTE instead of BLOOD_PALETTE. Offsets in the script
    are relative, so the copy runs from its own address. gray_codes: the
    frames draw gray_tiles' copies instead."""
    block = blood_frames(stock)
    for k, (at, word) in enumerate(BLOOD_ATTRIBUTES):
        if struct.unpack_from(">H", block, at)[0] != word or word & 0x1F != BLOOD_PALETTE:
            raise ValueError(f"blood frame attribute at +{at:#x} is not {word:04x}")
        struct.pack_into(">H", block, at, (word & ~0x1F) | WHITE_PALETTE)
        if gray_codes is not None:
            struct.pack_into(">H", block, at + 2, gray_codes + 2 * k)
    return struct.pack(">4H", 0, 0, 0, 8) + bytes(block)


def self_test():
    tile = bytes(range(128))
    assert tile_bytes(tile_pens(tile)) == tile
    assert len(DRESS_ROWS) == 48 and all(len(line) == 80 for line in DRESS_ROWS)
    assert all(ch in ".0123456789abcd" for line in DRESS_ROWS for ch in line)
    for p in DRESS_PENS:                # each offset leaves every nibble in range
        stock, dress = PALETTE_WORDS[p], DRESS_WORDS[p - DRESS_PENS[0]]
        assert all(0 <= (stock >> s & 15) + ((dress >> s & 15) - (stock >> s & 15)) <= 15 for s in (0, 4, 8))
    stock = bytearray(0x60000)              # a stand-in program holding the blood block twice
    block = bytearray(range(BLOOD_BYTES))
    for at, word in BLOOD_ATTRIBUTES:
        struct.pack_into(">H", block, at, word)
    for a in BLOOD_SCRIPTS:
        stock[a:a + BLOOD_BYTES] = block
    white = white_blood(stock)
    assert struct.unpack_from(">4H", white) == (0, 0, 0, 8) and len(white) == 8 + BLOOD_BYTES
    assert [struct.unpack_from(">H", white, 8 + at)[0] for at, _ in BLOOD_ATTRIBUTES] == [0x0027, 0x1127, 0x1127]
    assert REG_TABLE + 154 <= REG_BLOOD and REG_BLOOD % 2 == 0
    print("self-test passed")


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args(argv)
    if args.self_test:
        self_test()
    return 0


if __name__ == "__main__":
    sys.exit(main())
