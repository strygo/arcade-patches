#!/usr/bin/env python3
"""Build the milestone 1 spike: stock Japanese Final Fight on our CPS2 layer.

Reads the user's canonical ``ffightj`` (``--edition usa``: ``ffightu``) and
``sfa3u`` sets, assembles
``asm/hw_layer.asm`` with the pinned assembler, applies the stock-checked
patch table and converts the graphics to the CPS2 layout. The output is a
development archive laid out as ``sfa3u`` for stock MAME's normal-map CPS2
machine. It is plaintext with a dead key (twenty ``0xFF`` bytes) so the spike
can iterate before code/data classification; it is never a release artifact.

Everything is written below ``--work`` on the configured scratch filesystem.
"""
from __future__ import annotations

# BEGIN ARCADE PYTHON BOOTSTRAP
import sys as _arcade_sys
from pathlib import Path as _ArcadePath
_arcade_sys.path.insert(0, str(_ArcadePath(__file__).resolve().parents[3]))
from kit_python import bootstrap as _arcade_bootstrap
_arcade_bootstrap()
# END ARCADE PYTHON BOOTSTRAP

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import struct
import subprocess
import sys
import zipfile
import zlib

import audit_upstream as upstream
import bootstrap_assembler as bootstrap
import credits

TRACK = Path(__file__).resolve().parents[1]
ROOT = TRACK.parents[1]
LAYER_SOURCE = TRACK / "asm" / "hw_layer.asm"
LAYER_HOME = 0xF0000
LAYER_MAGIC = b"FFC2"
DEAD_KEY = b"\xff" * 20             # MAME's phoenix.key (CRC 2cf772b0)
OUT_BASE_LINE = "OUT_BASE        equ $400000"

FFIGHTJ_PROGRAM = (  # MAME ffightj ROM_LOAD16_BYTE layout
    ("ff36.bin", 0x00000, 0xF9A5CE83), ("ff42.bin", 0x00001, 0x65F11215),
    ("ff37.bin", 0x40000, 0xE1033784), ("ff43.bin", 0x40001, 0xB6DEE1C3),
    ("ffj_34.10f", 0x80000, 0x0C8DC3FC), ("ffj_40.10h", 0x80001, 0x8075BAB9),
    ("ffj_35.11f", 0xC0000, 0x4A934121), ("ffj_41.11h", 0xC0001, 0x2AF68154),
)
FFIGHTJ_GFX = (  # MAME ffightj ROM_LOAD64_BYTE layout
    ("ffj_09.4b", 0x000000, 0x5B116D0D), ("ffj_01.4a", 0x000001, 0x815B1797),
    ("ffj_13.9b", 0x000002, 0x8721A7DA), ("ffj_05.9a", 0x000003, 0xD0FCD4B5),
    ("ffj_24.5e", 0x000004, 0xA1AB607A), ("ffj_17.5c", 0x000005, 0x2DC18CF4),
    ("ffj_38.8h", 0x000006, 0x6535A57F), ("ffj_32.8f", 0x000007, 0xC8BC4A57),
    ("ffj_10.5b", 0x100000, 0x624A924A), ("ffj_02.5a", 0x100001, 0x5D91F694),
    ("ffj_14.10b", 0x100002, 0x0A2E9101), ("ffj_06.10a", 0x100003, 0x1C18F042),
    ("ffj_25.7e", 0x100004, 0x6E8181EA), ("ffj_18.7c", 0x100005, 0xB19EDE59),
    ("ffj_39.9h", 0x100006, 0x9416B477), ("ffj_33.9f", 0x100007, 0x7369FA07),
)
SFA3U_SOUND = (
    ("sz3.01", 0xDE810084), ("sz3.02", 0x72445DC4),
    ("sz3.11m", 0x1C89EED1), ("sz3.12m", 0xF392B13A), ("dl-1425.bin", 0xD6CF5EF5),
)
# Editions (ENGLISH_EDITION.md). The Japanese, World and USA programs are
# identical apart from the region byte at 0x72601; their graphics differ only
# in 77 scroll 1 text tiles.
# - japan: stock ffightj;
# - english, the English restoration: the Japanese program with its region
#   word left at Japan, the language gates turned to their English branches,
#   and the World set's 77 text tiles in scroll 1;
# - usa: stock ffightu (14 October: Jessica off the TV, her cries),
#   which has the World graphics. It has no REGULATION, whose only picture is
#   the TV shot that the USA program cuts; its EX build has REGULATION for the
#   CD intro's TV alone, factory ON (ex_regulation.py), its blood always the
#   stock red (22 October).
EDITIONS = ("japan", "english", "usa")
FFIGHTU_PROGRAM = (  # MAME ffightu ROM_LOAD16_BYTE layout; then the mask ROM
    ("ff_36.11f", 0x00000, 0xF9A5CE83), ("ff_42.11h", 0x00001, 0x65F11215),
    ("ff_37.12f", 0x40000, 0xE1033784), ("ffu_43.12h", 0x40001, 0x4CA65947),
)
FFIGHTU_MASK = ("ff-32m.8h", 0x80000, 0xC747696E)   # ROM_LOAD16_WORD_SWAP
EDITION_LINE = "EDITION         equ 0"
DIAG_LINE = "DIAG            equ 0"
EX_LINE = "EX              equ 0"
EX_ENTRIES = ("ex_next_round", "ex_capability", "ex_item_anim", "ex_s3_block",
              "ex_story", "ex_story_arm", "ex_blk2", "ex_blk3", "ex_arm2", "ex_close2", "ex_arm3",
              "ex_cue_tail", "ex_cue_call", "ex_text_a", "ex_text_1")
# The opening engine's vblank override ends in "lea $ff8000,a5; jmp $984"
# just before its INIT entry; EX builds send it to ex_reg_tail (REGULATION
# in the CD intro's TV, ex_regulation.py), which ends the same way.
OVERRIDE_TAIL = bytes.fromhex("4bf900ff80004ef900000984")
# CUT SCENES (EX_BUILD.md): each site CPS1 EX hooks calls the layer's switch,
# which runs EX's code (SEGA CD) or the stock instructions (ARCADE). The
# story's arm is completed from the stock program (its value).
CUT_PATCHES = (
    (0x017092, "302d9288323b00344ebb1030", (("jsr", "ex_story"), "4e714e714e71"),
     "CUT SCENES: the story's dispatcher sends scenes 1-4 to EX's engine (SEGA CD) or every scene stock"),
    (0x018650, "3b7c138e006e", (("jsr", "ex_blk2"),), "CUT SCENES: the reunion's pre-roll blackout"),
    (0x0186BA, "1b7c0001008d4eb8283a", (("jsr", "ex_arm2"), "4e714e71"),
     "CUT SCENES: the reunion's arm and first lines"),
    (0x0186CC, "303c00544ef809e4", (("jsr", "ex_cue_tail"), "4e71"), "CUT SCENES: the ending's music (Japan)"),
    (0x018632, "303c00544eb809e4", (("jsr", "ex_cue_call"), "4e71"), "CUT SCENES: the ending's music (export)"),
    (0x018714, "1b7c0001008d4ef8283a", (("jsr", "ex_close2"), "4e714e71"),
     "CUT SCENES: the reunion's closing lines"),
    (0x018A6A, "3b7c138e006e", (("jsr", "ex_blk3"),), "CUT SCENES: the farewell's pre-roll blackout"),
    (0x018AD2, "1b7c0001008d4ef8283a", (("jsr", "ex_arm3"), "4e714e71"),
     "CUT SCENES: the farewell's arm and lines"),
    (0x00130E, "43f900067082", (("jsr", "ex_text_a"),), "CUT SCENES: group A's text table (EX's copy for SEGA CD)"),
    (0x001350, "43f900067082", (("jsr", "ex_text_a"),), "CUT SCENES: group A's text table (EX's copy for SEGA CD)"),
    (0x00139E, "43f900068566", (("jsr", "ex_text_1"),), "CUT SCENES: group 1's text table (EX's copy for SEGA CD)"),
)
# The restoration EX (english_ex.py): the three text lookups, which CUT SCENES
# and the restoration (english_records.py) both replace, go whole to the
# layer's switch between their tables.
TEXT_SITES = (0x00130E, 0x001350, 0x00139E)
ENGLISH_EX_TEXT = (
    (0x00130E, "43f9000670823031000043f10000", (("jsr", "ex_text_ae"), "4e714e714e714e71"),
     "restoration EX: group A's records, the restoration's or its CD captions' (english_ex.py)"),
    (0x001350, "43f9000670823031000043f10000", (("jsr", "ex_text_ae"), "4e714e714e714e71"),
     "restoration EX: group A's records, the restoration's or its CD captions' (english_ex.py)"),
    (0x00139E, "43f9000685663031000043f10000", (("jsr", "ex_text_1e"), "4e714e714e714e71"),
     "restoration EX: group 1's records, the restoration's or its CD captions' (english_ex.py)"),
)
STORY_ARM = 0x0170F6                    # "move.w #n,$92b0(a5)": n from the stock program
EX_TEXT_HOME = 0x302000                 # EX's copy of the text block (group A, then group 1)
# The EX name screen's date, in place of Final Fight's date code 900112: the build's release date
# (release/CANDIDATES.md's EX exception, one date; 22 October: "FINAL FIGHT EX (with spaces),
# the day's build, then region - no extra lines"). A release candidate sets it to its plan's date.
EX_BOOT_DATE = "2026-10-23"
TEXT_STOCK = ((0x068537, 0x068540),)    # the "CODY !" card stays stock in both texts, without CPS1 EX's
                                        #   "CODY!" (22 October: "let's put back the space in between CODY!")
FFIGHT_GFX = (("ff-5m.7a", 0, 0x9C284108), ("ff-7m.9a", 2, 0xA7584DFB),
              ("ff-1m.3a", 4, 0x0B605E44), ("ff-3m.5a", 6, 0x52291CD2))   # ROM_LOAD64_WORD
ENGLISH_TILES = 77                      # 128-byte units, all in scroll 1's text
ENGLISH_TILE_SPAN = (0x111680, 0x124E00)
# The intro and ending music keep Japan's cues (13 October: Japanese
# timing). The story, profiles, ending and the staff messages after END keep
# the Japanese script, ids and sequence, whose records english_records.py
# replaces with the English typed on the Japanese timeline; so no gate
# selects the export text there.
ENGLISH_PATCHES = (
    (0x000EA4, "001a", "0039",
     "boot warning: the USA warning (draw request 0x39) in the Japanese entry of the table the region "
     "word indexes (0x1A Japan, 0x39 USA, 0x1B World)"),
    (0x0172CE, "6704", "4e71", "intro: the English \"Sometime in the 1990's...\" screen (0xA08, Japan 0xA09)"),
    (0x017A10, "670e", "600e", "title: the USA copyright lines (0xA07, Japan 0xA05, World 0xA06)"),
    (0x017A74, "670a", "600a",
     "attract: the USA \"Winners Don't Use Drugs\" FBI screen after the title (13 October)"),
)
# Typos in Final Fight's own text that every edition fixes (15
# October). The CPS1 references the gates compare with carry them too
# (english_oracle.py), so each comparison stays exact.
TEXT_FIXES = (
    (0x05bcce, "4441", "4445", "HUD name table: GRANADE spelled GRENADE"),
)
# Effect levels the editions change, in dB, by OKI trigger cue (15
# October): the Industrial Area's fire jets (0x3B, along its burning
# floor every 28 and 20 frames) covered the music.
EFFECT_GAINS = {0x3B: -9.0}
# Test kits only: every new game starts at a chosen level. The new game's
# clear of the stage index, level and area ($C1, $BE, $BF, at 0x4C48)
# becomes the level and area 0 as one word, then the game's own stage
# select (0x54D4), which sets the stage index and bonus flag from the list
# at 0x54FC (level 6: the first bonus round; 3: the Industrial Area).
START_PATCH = (0x004C48, "422d00c1422d00be422d00bf", "3b7c{:02x}0000be4eb854d44e71",
               "test kit: every new game starts at the chosen level (the game's stage select, 0x54D4)")
# Diagnostic kits only (the layer's DIAG readouts): the scheduler's end of a
# pass over its 16 task slots counts the pass.
DIAG_PATCH = (0x000786, "422d91014a2d0084", (("jsr", "diag_idle"), "4e71"),
              "diagnostic kit: the scheduler counts each pass (diag_idle) before its idle checks")
# EX builds only (EX_PHASE0.md): BONUS STAGE OFF steps the round advance
# past the progression's bonus rounds (the layer's ex_next_round).
EX_PATCHES = (
    (0x0054BA, "522d00c17000", ("4ef9", ("long", "ex_next_round")),
     "EX: the round advance runs through ex_next_round, which skips the bonus rounds with BONUS STAGE OFF"),
    (0x05A546, "43fa003422710000", (("jsr", "ex_item_anim"), "4e71"),
     "EX: the item spawn takes its animation through ex_item_anim (ARTWORK ARCADE STADIUM's can)"),
    (0x062FE8, "227c00080000d3c0", (("jsr", "ex_s3_block"), "4e71"),
     "EX: scroll 3's writer takes its block through ex_s3_block (ARTWORK ARCADE STADIUM's sign)"),
)
# US EX only: the ending music with the reunion, as Japan's (21 October, on US EX: "Ending - music
# started way late"). The US/World ending arms a countdown of its own, (a5)-$6d30, read nowhere else, at
# 900 frames (0x1864A, move.w #$384) and posts the ending music (0x54, CPS1 EX's alias 0x78) when it runs
# out (0x18632); Japan's posts it two frames after INIT. With the CD reunion in place of the arcade's,
# that left 15 s of silence in a plain kit (the Arrange MRA gates the alias; the voiced track carries the
# music).
USA_EX_PATCHES = (
    (0x01864A, "3b7c038492d0", "3b7c000292d0",
     "US EX: the ending music's countdown 2 frames, not 900: the music starts with the reunion, as Japan's"),
)
# CPS1 EX's stage select (backports/ffightcd/build/stage_select.py, its CPS2
# backend at 0xD9000): the title's Start handling checks for the code, the
# game task runs the STAGE SELECT screen after character select, and a run
# started with the code reports "not ranked". As on CPS1, the title site's
# first six bytes become the jmp and the code carries all eighteen.
STAGE_SELECT_PATCHES = (
    (0x001168, "4a6d92a2670c", ("4ef9", ("long", "stage_select_title")),
     "EX: stage select's code check on the title's Start (its code runs the displaced 18 bytes)"),
    (0x004CC8, "303c00004eb8087e", (("jsr", "stage_select_charsel"), "4e71"),
     "EX: STAGE SELECT after character select, when the code was entered"),
    (0x015468, "303c0004323c0002", ("4ef9", ("long", "stage_select_rank"), "4e71"),
     "EX: a stage-select run reports not ranked"),
)
SFA3U_KEY = ("sfa3u.key", 0x4A8F98C1)
# The key's watchdog instruction, decoded key words 6, 5, 4 (HBMAME
# cps2crypt.cpp; DONOR_BOARDS.md): cmpi.l #$1C62F5A8,d0, which sets only
# the flags. Every build runs it, so plaintext and encrypted programs keep
# the same cycles.
WATCHDOG = bytes.fromhex("0c801c62f5a8")
WATCHDOG_SLOTS = ("watchdog_reset", "watchdog_frame")
NOPS3 = bytes.fromhex("4e714e714e71")
SFA3U_PROGRAM = ("sz3u.03c", "sz3u.04c", "sz3.05c", "sz3.06c",
                 "sz3.07c", "sz3.08c", "sz3.09c", "sz3.10b")
PHOENIX_PROGRAM = ("sz3ud.03c", "sz3ud.04c") + SFA3U_PROGRAM[2:]  # MAME sfa3ud
SFA3U_GFX = (("sz3.13m", "sz3.15m", "sz3.17m", "sz3.19m"),
             ("sz3.14m", "sz3.16m", "sz3.18m", "sz3.20m"))

# S224B/S222B tile ranges in bytes of the 2 MiB CPS1 region: objects first,
# then SCROLL1, SCROLL3 and SCROLL2. CPS2 maps scroll tiles at +0x800000.
OBJECT_BYTES = 0x110000
SCROLL_BYTES = (0x110000, 0x200000)

# Priority-mask overlay. CPS1 draws a scroll 2 pen over sprites when its
# tile's group mask lists that pen; CPS2 has no such pass. The layer instead
# draws those pens as objects on top of the sprites. For every scroll 2 code
# and every mask value the census saw, the table below names the object to
# draw: the scroll 2 tile itself (object code 0x10000 + code) when the mask
# lists every opaque pen it uses, or a copy with the other pens made
# transparent, stored from object code 0x20000 in the otherwise empty second
# half of the graphics. Upper program ROM holds the table; it is data only.
CENSUS = TRACK / "manifests" / "priority_census.json"
OVERLAY_TABLE = 0x100800
CONVERSION_TABLES = 0x180000       # 64 KiB each, X, Y, then Y with the HUD band
                                   #   flag: indexed by any word
S1_BAND = 40                       # screen lines of the HUD band (hw_layer.asm's S1_BAND)
SCROLL2_CODES = (0x3000, 0x4000)
SCROLL3_CODES = (0x980, 0xC00)     # 32x32 tiles, 512 bytes each in the CPS1 region
OVERLAY_MASK_SLOTS = 16
FILTERED_BASE = 0x20000            # object code of the first filtered scroll 2 copy
SCROLL3_BASE = 0x30000             # object code of the first scroll 3 block
SCROLL1_CODES = (0x4400, 0x4C00)   # 8x8 tiles, 64 bytes each in the CPS1 region
SCROLL1_BASE = 0x38000             # object code of the first scroll 1 object
SCROLL1_TABLE = 0x200000           # upper ROM home of the scroll 1 table
SAFE1_TABLE = 0x1B0000             # upper ROM home of the scroll 1 safe table
WIDE_TABLE = 0x1D0000              # Y with every word flagged but raw 0 (CONV_Y2)
# SFA3's QSound screen (QSOUND_LOGO.md), extracted from the user's sfa3u and
# checked by SHA-256: two scroll 3 map records (64 codes less 0xB00, then 64
# attribute bytes), the scroll 1 CAPCOM logo, their palettes (stored with
# brightness 0) and tiles. The layer draws it from a table at QSCREEN_TABLE:
# scroll 3 cells and scroll 1 cells as (map offset, code, attribute) words,
# each list after its count, then scroll 1 palette 1 and scroll 3 palettes 1-3.
QSCREEN_TABLE = 0x300000
QSOUND_JINGLE = 0x5C                    # the layer's own record (hw_layer QS_JINGLE, ff_audio.JINGLE)
SFA3U_UPPER = (("sz3.09c", 0xB29E5199), ("sz3.10b", 0xDEB2FF52))   # program 0x300000-0x3FFFFF
SFA3U_GFX_LOW = (("sz3.13m", 0x0F7A60D9), ("sz3.15m", 0x8E933741),
                 ("sz3.17m", 0xD6E98147), ("sz3.19m", 0xF31A728A))  # the first 16 MiB
QSCREEN_RECORDS = (0x3B0154, 0x3B0214)  # scroll 3 cells 0-63 and 64-127 (columns 0-7, 8-15)
QSCREEN_COLUMNS = 12                    # scroll 3 columns on screen (SFA3's scroll X is 0xFFC0)
QSCREEN_PALETTES = ((0x340174, 16), (0x349FD4, 48))   # scroll 1 palette 1, scroll 3 palettes 1-3
QSCREEN_LOGO = (0x150, 25, 16, 3, 16)   # first code, row, column, rows, columns (attribute 1)
QSCREEN_FILL = (0x0B0F, 0x1342)         # SFA3's fill tile; Final Fight's scroll 3 uses 0xB0F
QSCREEN_SHA256 = {"records": "58c81c021029161a00f6040cd986d68d5256aa84a7ad4362ce828d3499a6fe2e",
                  "palettes": "b5be280c374fdc11bac8e51d88c6247f3fab6423a718a96b07f2ee6e9997d1d4",
                  "tiles": "861542bc39668cb10333456cdfceaedb863f23d0192c6121febe9d8eacac9adc"}
# 13 October 2026: the CAPCOM logo's edge in the classic CAPCOM blue
# (variant C of three he was shown) instead of SFA3's violet. Scroll 1
# palette 1 pens as stored (brightness 0): SFA3's word, ours. The yellow fill
# (pen 4) and the shadow (pen 9) keep SFA3's colors; the blends (pens 1-3)
# run from the new edge to the fill as SFA3's run from its own.
QSCREEN_LOGO_EDGE = {0: (0x063F, 0x000C), 1: (0x086D, 0x043B), 2: (0x0B9B, 0x0879), 3: (0x0DB9, 0x0CA8),
                     5: (0x052B, 0x0009), 6: (0x052B, 0x0009), 7: (0x0328, 0x0006), 8: (0x0214, 0x0003)}
TILE_BYTES = 128
TILE3_BYTES = 512

# Each patch names the stock bytes it replaces. Entry names resolve to the
# assembled layer's header. Address-only patches retarget an absolute operand.
NOP = "4e71"


def jsr(entry):
    return ("jsr", entry)


PATCHES = (
    (0x000004, "0005e7ac", ("long", "reset"), "reset vector to layer initialization"),
    (0x000070, "00000400", ("long", "raster"), "level 4: CPS2 raster interrupt runs the late build"),
    (0x000078, "00000400", ("long", "level6"), "level 6: raster and vblank together"),
    (0x000494, "3b7c12ce006e", "3b7c12c0006e",
     "warm init: scroll layers off until the name screen has cleared the RAM test's text (on CPS2 "
     "the vblank shows them before the boot task's clear runs: two frames of shifted text)"),
    (0x000558, "00800166", "00800168", "vblank: B-04 priority mask 1 -> B-21 mask 1"),
    (0x000560, "00800170", "0080016a", "vblank: B-04 priority mask 2 -> B-21 mask 2"),
    (0x000568, "00800168", "0080016c", "vblank: B-04 priority mask 3 -> B-21 mask 3"),
    (0x000570, "00800172", "0080016e", "vblank: B-04 priority mask 4 -> B-21 mask 4"),
    (0x000580, "0080016e", "00800166", "vblank: layer control B-04 -> B-21"),
    (0x000584, "33ed009e00800100", (jsr("vblank"), NOP), "vblank: object conversion and publication"),
    (0x00058E, "003f", "000f",
     "vblank: copy palette pages 0-3 only; Final Fight draws no star layers, and on CPS2 hardware each "
     "page the CPS-A copies stops the 68000 for about 130 us a frame (jtcps1_dma.v's measurements)"),
    (0x000590, "0080016a", "00800170", "vblank: palette control B-04 -> B-21"),
    (0x0005e2, "4cdf7fff4e73", ("4ef9", ("long", "vblank_end")),
     "vblank exit: return the overlay's borrowed palette slots"),
    (0x0006de, "13ed006a00800030", (jsr("coin"), NOP), "coin counters/locks to the CPS2 output port"),
    (0x0006e6, "13ed006b00800031", NOP * 4, "CPS1 coin-control low byte has no CPS2 meaning"),
    (0x0006f4, "103900800018", (jsr("system_d0"),), "system inputs from CPS2 IN2"),
    (0x000700, "103900800018", (jsr("system_d0"),), "system inputs from CPS2 IN2"),
    (0x00071e, "123900800018", (jsr("system_d1"),), "system inputs from CPS2 IN2"),
    (0x00072a, "10390080001a", (jsr("dswa"),), "DIP switch A default"),
    (0x000736, "10390080001c", (jsr("dswb"),), "DIP switch B default"),
    (0x000742, "10390080001e", (jsr("dswc"),), "DIP switch C default"),
    (0x0009ae, "00800188", "00ffffe8", "$f9's parameter latch: no QSound counterpart"),
    (0x0009b2, "33c200800180", (jsr("sound_d2"),), "sound command to the QSound driver"),
    (0x0009c4, "33fc00ff00800180", (jsr("sound_idle"), NOP), "sound idle frame: post anything queued"),
    (0x000c36, "103900800018", (jsr("system_d0"),), "test switch from CPS2 IN2"),
    (0x000c68, "610001fa303c0080", (jsr("qsound"), NOP),
     "boot: Final Fight's warning, then SFA3's QSound screen and jingle"),
    (0x000c8e, "00800001", "00804001", "player 1 input byte: CPS2 IN0"),
    (0x000cca, "0005ebae", ("long", "menu"), "test switch starts the CPS2-style TEST MENU"),
    (0x00262a, "41f90090c000", ("4ef9", ("long", "map2_clear")),
     "scroll 2 clear also empties the overlay's column cache"),
    (0x002b30, "00800000", "00804000", "player inputs: CPS2 IN0"),
    (0x002b5e, "00800000", "00804000", "player inputs: CPS2 IN0"),
    (0x002d3e, "00800000", "00804000", "player inputs: CPS2 IN0"),
    (0x004762, "207c0090c000", ("4ef9", ("long", "map2_block")),
     "scroll 2 block address step also marks the block's columns for the overlay"),
    (credits.CREDITS_POINTER, "00018f94", f"{credits.CREDITS_HOME:08x}",
     "the staff roll, with the port's credit (credits.py), from the upper ROM"),
    (0x0218be, "227c000218e2", (jsr("reg_cut"),),
     "a blood object's animation: white with REGULATION ON"),
    (0x05552e, "102e00144ef83ad6", ("4ef9", ("long", "reg_effect"), NOP),
     "the hit effect's animation: blood white with REGULATION ON"),
    (0x05e7b8, "13fc008000800030", NOP * 4, "CPS1 coin-control reset pulse"),
    (0x05e7c8, "13fc000000800030", NOP * 4, "CPS1 coin-control reset pulse"),
    (0x05e7dc, "0080016e", "00800166", "init: layer control B-04 -> B-21"),
    (0x05e84e, "6702", "6002", "init: skip the CPS-B-04 ID check"),
    (0x05eb7e, "003f", "000f", "init: copy palette pages 0-3 only (as the vblank's)"),
    (0x05eb80, "0080016a", "00800170", "init: palette control B-04 -> B-21"),
    (0x05ec78, "61001586610015cc4e75", ("207c", ("long", "menu_resume"), "4eb80924"),
     "a finished stock test returns to the CPS2-style TEST MENU"),
    (0x05f602, "00800180", "00ffffea", "OUTPUT test idle byte: no QSound counterpart"),
    (0x05f60e, "33c400800180", (jsr("sound_d4"),), "OUTPUT test sound code to the QSound driver"),
    (0x05f616, "33fc00f000800180", (jsr("sound_stop"), NOP), "OUTPUT test stop to the QSound driver"),
    (0x05f622, "00800188", "00ffffe8", "OUTPUT test parameter latch: no QSound counterpart"),
    (0x062b00, "3a2e00063b45002a", (jsr("stream_begin"), NOP),
     "scroll 2 screen stream: note it runs, so the vblank keeps the view on screen until it ends"),
    (0x062b32, "51ccffea4e75", ("4ef9", ("long", "stream_end")),
     "scroll 2 screen stream: its column loop's end clears the note"),
    (0x062f04, "30910658300030e9", ("4ef9", ("long", "map2_column"), "4e71"),
     "scroll 2 column streaming also marks the column for the overlay"),
    (0x063092, "309106503000316900020002", ("4ef9", ("long", "map2_row"), "4e714e714e71"),
     "scroll 2 row streaming also marks its columns for the overlay"),
    (0x0719dc, "00800000", "00804000", "player inputs: CPS2 IN0"),
    (0x072128, "00800000", "00804000", "player inputs: CPS2 IN0"),
    (0x0721e6, "00800000", "00804000", "player inputs: CPS2 IN0"),
)
# Final Fight's control commands as the layer's snd_controls posts them to
# QSound driver 1.71, records of ($ffxx, channel); $f8-$ff post nothing.
# $f1 and $f2 stop the scored effects' and the OKI phrases' effect channels
# one by one, so a scored effect plays on through $f2 as on CPS1. Other
# commands post 00xx, wrapped at 96 as both drivers wrap them.
SOUND_CONTROLS = {0xF0: ((0xFF00, 0),), 0xF1: tuple((0xFF02, c) for c in (6, 7)),
                  0xF2: tuple((0xFF02, c) for c in range(8, 12)), 0xF3: ((0xFF02, 8),),
                  0xF4: ((0xFF02, 9),), 0xF5: ((0xFF02, 10),), 0xF6: ((0xFF02, 11),),
                  0xF7: ((0xFF05, 0),)}


def qsound_commands(byte):
    """The QSound command words the layer posts for a CPS1 sound byte."""
    if byte >= 0xF0:
        return tuple(command for command, _ in SOUND_CONTROLS.get(byte, ()))
    return (byte % 96,)


ENTRY_ORDER = ("reset", "vblank", "system_d0", "system_d1", "dswa", "dswb", "dswc", "coin",
               "menu", "menu_resume", "vblank_end", "raster", "level6",
               "map2_column", "map2_row", "map2_block", "map2_clear",
               "sound_d2", "sound_d4", "sound_stop", "sound_idle", "qsound",
               "watchdog_reset", "watchdog_frame", "stream_begin", "stream_end",
               "reg_effect", "reg_cut")


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def identity(data):
    return {"bytes": len(data), "sha256": sha256(data), "crc32": f"{zlib.crc32(data):08x}"}


def default_rompaths():
    paths = [ROOT / "roms", ROOT / "roms" / "mame0260"]
    paths += [Path(p) for p in os.environ.get("CAPCOM_ARCADE_ROM_PATH", "").split(os.pathsep) if p]
    return paths


def find_archive(rompaths, stem):
    for base in rompaths:
        try:
            return upstream.archive(Path(base), stem)
        except ValueError:
            continue
    raise ValueError(f"missing canonical {stem}.zip or {stem}.7z in the ROM paths")


def read_checked(archive, name, crc):
    data = upstream.member(archive, name)
    if zlib.crc32(data) != crc:
        raise ValueError(f"{archive.name}:{name} CRC {zlib.crc32(data):08x}, expected {crc:08x}")
    return data


def watchdog_words(key):
    """The key's watchdog instruction words: decoded words 6, 5 and 4."""
    sys.path.insert(0, str(Path(__file__).resolve().parents[3] / "extraction"))
    from cps2_crypt import decode_key
    decoded = decode_key(key)[3]
    return struct.pack(">3H", decoded[6], decoded[5], decoded[4])


def install_watchdog(program, entries, key):
    words = watchdog_words(key)
    if words != WATCHDOG:
        raise ValueError(f"the key's watchdog is {words.hex()}, not the pinned {WATCHDOG.hex()}")
    for name in WATCHDOG_SLOTS:
        at = entries[name]
        if program[at:at + 6] != NOPS3:
            raise ValueError(f"watchdog slot {name} at {at:#x} is not three no-ops")
        program[at:at + 6] = words
    return {"words": words.hex(), "slots": {name: f"{entries[name]:#x}" for name in WATCHDOG_SLOTS}}


def stock_program(ffightj):
    program = bytearray(0x100000)
    for name, offset, crc in FFIGHTJ_PROGRAM:
        data = read_checked(ffightj, name, crc)
        program[offset:offset + 0x40000:2] = data
    return program


def usa_program(ffightu):
    program = bytearray(0x100000)
    for name, offset, crc in FFIGHTU_PROGRAM:
        program[offset:offset + 0x40000:2] = read_checked(ffightu, name, crc)
    name, offset, crc = FFIGHTU_MASK
    data = read_checked(ffightu, name, crc)
    program[offset:offset + 0x80000:2] = data[1::2]
    program[offset + 1:offset + 0x80000:2] = data[0::2]
    return program


def unshuffle(data, bank_size=0x200000):
    """The inverse of upstream.reshuffle: a graphics image in the linear layout."""
    result = bytearray(len(data))
    half = bank_size // 2
    for start in range(0, len(data), bank_size):
        end = start + bank_size
        for lane in range(8):
            result[start + lane:start + half:8] = data[start + lane:end:16]
            result[start + half + lane:end:8] = data[start + 8 + lane:end:16]
    return bytes(result)


def scan1(row, col):
    """Scroll 1 map index of a cell (MAME's tilemap0_scan)."""
    return (row & 0x1F) + ((col & 0x3F) << 5) + ((row & 0x20) << 6)


def qsound_screen(rompaths):
    """(table, graphics pieces, receipt) for SFA3's QSound screen."""
    sfa3u = find_archive(rompaths, "sfa3u")
    upper = b"".join(upstream.swap_words(read_checked(sfa3u, n, c)) for n, c in SFA3U_UPPER)

    def prog(address, size):
        return upper[address - 0x300000:address - 0x300000 + size]
    records = b"".join(prog(r, 192) for r in QSCREEN_RECORDS)
    palettes = b"".join(prog(a, 2 * n) for a, n in QSCREEN_PALETTES)
    cells3 = []
    for r in range(len(QSCREEN_RECORDS)):
        codes = struct.unpack_from(">64H", records, 192 * r)
        for i, (code, attr) in enumerate(zip(codes, records[192 * r + 128:192 * r + 192])):
            if 64 * r + i >= 8 * QSCREEN_COLUMNS:
                break
            code = (code + 0xB00) & 0xFFFF
            cells3.append((4 * (64 * r + i), QSCREEN_FILL[1] if code == QSCREEN_FILL[0] else code, attr))
    first, row0, col0, rows, cols = QSCREEN_LOGO
    cells1 = [(4 * scan1(row0 + r, col0 + c), first + cols * r + c, 1) for r in range(rows) for c in range(cols)]
    part = bytearray(0x1000000)
    for lane, (name, crc) in enumerate(SFA3U_GFX_LOW):
        data = read_checked(sfa3u, name, crc)
        part[lane * 2::8] = data[0::2]
        part[lane * 2 + 1::8] = data[1::2]
    layout = unshuffle(bytes(part))
    codes3 = sorted({code for _, code, _ in cells3} - {QSCREEN_FILL[1]})
    pieces = [(0x800000 + 512 * c, layout[0x800000 + 512 * c:0x800000 + 512 * (c + 1)]) for c in codes3]
    pieces.append((0x800000 + 512 * QSCREEN_FILL[1],
                   layout[0x800000 + 512 * QSCREEN_FILL[0]:0x800000 + 512 * (QSCREEN_FILL[0] + 1)]))
    logo = range(first, first + rows * cols)
    pieces.append((0x800000 + 64 * first, layout[0x800000 + 64 * first:0x800000 + 64 * logo.stop]))
    found = {"records": sha256(records), "palettes": sha256(palettes),
             "tiles": sha256(b"".join(data for _, data in pieces))}
    if QSCREEN_SHA256 and found != QSCREEN_SHA256:
        raise ValueError(f"sfa3u's QSound screen does not match its pinned hashes: {found}")
    palettes = bytearray(palettes)
    for pen, (theirs, ours) in QSCREEN_LOGO_EDGE.items():
        if struct.unpack_from(">H", palettes, 2 * pen)[0] != theirs:
            raise ValueError(f"the CAPCOM logo's pen {pen} is not SFA3's {theirs:04x}")
        struct.pack_into(">H", palettes, 2 * pen, ours)
    table = bytearray()
    for cells in (cells3, cells1):
        table += struct.pack(">H", len(cells))
        for offset, code, attr in cells:
            table += struct.pack(">HHH", offset, code, attr)
    table += palettes
    return bytes(table), pieces, {"home": f"{QSCREEN_TABLE:#x}", **identity(bytes(table)), "sources": found,
                                   "scroll3_tiles": [f"{codes3[0]:04x}", f"{codes3[-1]:04x}", len(codes3)],
                                   "fill_tile": f"{QSCREEN_FILL[1]:04x}",
                                   "logo_edge": {str(pen): [f"{a:04x}", f"{b:04x}"]
                                                 for pen, (a, b) in QSCREEN_LOGO_EDGE.items()}}


def world_graphics(ffight):
    region = bytearray(0x200000)
    for name, base, crc in FFIGHT_GFX:
        data = read_checked(ffight, name, crc)
        for i in range(0, len(data), 2):
            at = base + (i // 2) * 8
            region[at:at + 2] = data[i:i + 2]
    return region


# The English restoration's caption hyphen (14 October 2026). Stock
# captions draw the 8x8 '-' (tile 0x442D) as a top tile alone (the
# typewriter's single-height exception), so its bar sits at cap height in the
# double-height line; CPS1 EX moved that tile's bar from rows 3-4 to rows
# 6-7 (backports/ffightcd build/rom.py patch_dash_tile). Here the moved bar
# is a glyph of its own, 0x3C40: scroll 1 code 0x8040 above a blank 0x8050,
# past CPS1's tiles, so no stock screen draws them (english_records.py puts
# its staff portraits at 0x8000 the same way), and the 8x8 '-' stays
# centered for the small font and the test menu's "7-1". A story-font glyph
# inside CPS1's range shares its tiles with pictures: 0x64E, used first, is
# a blank cell of the title's "Final", so its bar showed above the logo
# (the MiSTer photo, 14 October). The CPS1 oracle draws the glyph blank.
CAPTION_HYPHEN = 0x3C40


def caption_hyphen(region):
    """The caption hyphen's two tiles as (CPS2 layout offset, bytes) pieces:
    the 8x8 '-' with its bar moved to rows 6-7, and a blank tile under it."""
    dash = 0x442D * 64
    if region[dash + 24:dash + 40] == b"\xff" * 16 or any(
            b != 0xFF for b in region[dash:dash + 24] + region[dash + 40:dash + 64]):
        raise ValueError("the 8x8 hyphen is not a bar on rows 3-4")
    tile = bytearray(b"\xff" * 64)
    tile[48:64] = region[dash + 24:dash + 40]
    top = 0x800000 + (0x4400 + CAPTION_HYPHEN) * 64
    return [(top, bytes(tile)), (top + 0x10 * 64, b"\xff" * 64)]


def hyphen_region(region):
    """A copy of a CPS1 graphics region extended to hold the caption
    hyphen's tiles, for renderers (english_layout.screen)."""
    (top, tile), (bottom, blank) = caption_hyphen(region)
    out = bytearray(region) + b"\xff" * ((0x4410 + CAPTION_HYPHEN + 1) * 64 - len(region))
    out[top - 0x800000:top - 0x800000 + 64] = tile
    return out


def english_text(region, world):
    """Copy the World set's scroll 1 text tiles over the Japanese ones. The
    two sets must differ in exactly those tiles."""
    units = [a for a in range(0, len(region), 128) if region[a:a + 128] != world[a:a + 128]]
    if len(units) != ENGLISH_TILES or not all(ENGLISH_TILE_SPAN[0] <= a < ENGLISH_TILE_SPAN[1] for a in units):
        raise ValueError(f"the Japanese and World graphics differ in {len(units)} units, "
                         f"not the {ENGLISH_TILES} scroll 1 text tiles")
    for a in units:
        region[a:a + 128] = world[a:a + 128]
    return {"units": len(units), "span": [f"{units[0]:#x}", f"{units[-1] + 128:#x}"],
            "sha256": sha256(b"".join(bytes(world[a:a + 128]) for a in units))}


def stock_graphics(ffightj):
    region = bytearray(0x200000)
    for name, offset, crc in FFIGHTJ_GFX:
        region[offset:offset + 0x100000:8] = read_checked(ffightj, name, crc)
    return region


# The player select screen's window frames have four transparent source pixels
# in scroll 3 tiles 0x9D0 and 0x9D1, two border holes and a two-pixel hole in
# the glass, which show as nine black pixels across the three fighter windows:
# (56,46), (200,46), (328,46) and rows 40-41 at x 72, 200 and 328. Final Fight
# EX on CPS1 paints them with the adjacent gray, pen 9
# (backports/ffightcd/build/select_window.py); so does this build.
SELECT_WINDOW_PIXELS = ((0x09D0, 24, 30), (0x09D1, 8, 30), (0x09D1, 8, 24), (0x09D1, 8, 25))
SELECT_WINDOW_SCREEN = ((56, 46), (200, 46), (328, 46), (72, 40), (72, 41), (200, 40), (200, 41),
                        (328, 40), (328, 41))


def scroll3_pen(region, code, x, y):
    at = code * TILE3_BYTES + y * 16 + (x // 8) * 4
    return sum((region[at + k] >> (7 - x % 8) & 1) << k for k in range(4))


def repair_select_windows(region):
    for code, x, y in SELECT_WINDOW_PIXELS:
        if scroll3_pen(region, code, x, y) != 15:
            raise ValueError(f"select window hole moved: tile {code:04x} ({x},{y})")
        # the glass hole's right neighbor is a reflection edge (pen 10)
        neighbors = (x - 2, x - 1, x + 1, x + 2) if y == 30 else (x - 2, x - 1)
        if any(scroll3_pen(region, code, n, y) != 9 for n in neighbors):
            raise ValueError(f"select window neighbors changed: tile {code:04x} ({x},{y})")
        at = code * TILE3_BYTES + y * 16 + (x // 8) * 4
        bit = 1 << (7 - x % 8)
        for k in range(4):
            region[at + k] = region[at + k] & ~bit | (bit if 9 >> k & 1 else 0)


def cps2_graphics(region, filtered=b"", blocks=b"", scroll1=b"", extra=()):
    """sfa3u graphics members: objects, scroll tiles at +0x800000, and the
    overlay's scroll 2 copies, scroll 3 blocks and scroll 1 objects in the
    second 16 MiB; extra: (layout offset, bytes) pieces placed where nothing
    else is (the QSound screen's tiles)."""
    first2 = (FILTERED_BASE - 0x10000) * TILE_BYTES + 0x800000
    first3 = (SCROLL3_BASE - 0x10000) * TILE_BYTES + 0x800000
    first1 = (SCROLL1_BASE - 0x10000) * TILE_BYTES + 0x800000
    if (first2 + len(filtered) > first3 or first3 + len(blocks) > first1
            or first1 + len(scroll1) > 0x2000000):
        raise ValueError("overlay tiles exceed their graphics areas")
    layout = bytearray(b"\xff" * 0x2000000)
    layout[:OBJECT_BYTES] = region[:OBJECT_BYTES]
    start, end = SCROLL_BYTES
    layout[0x800000 + start:0x800000 + end] = region[start:end]
    layout[first2:first2 + len(filtered)] = filtered
    layout[first3:first3 + len(blocks)] = blocks
    layout[first1:first1 + len(scroll1)] = scroll1
    for at, data in extra:
        if any(b != 0xFF for b in layout[at:at + len(data)]):
            raise ValueError(f"graphics at {at:#x} are not free")
        layout[at:at + len(data)] = data
    shuffled = upstream.reshuffle(bytes(layout))
    members = {}
    for half, names in enumerate(SFA3U_GFX):
        part = shuffled[half * 0x1000000:(half + 1) * 0x1000000]
        for lane, name in enumerate(names):
            data = bytearray(0x400000)
            data[0::2] = part[lane * 2::8]
            data[1::2] = part[lane * 2 + 1::8]
            members[name] = bytes(data)
    return members


# A 16x16 tile row is eight bytes: four for the left eight pixels, then four
# for the right, byte k holding bit k of each pixel's pen, leftmost pixel in
# the most significant bit (MAME's cps1_layout16x16). As one integer, the
# bytes holding pen bit k line up with those holding bit 0 after a shift of
# 8*k bits, so pen tests run on all 256 pixels at once.
# A 32x32 scroll 3 tile has 16-byte rows of four such 8-pixel groups.
def _lane0(size):
    return int.from_bytes(bytes([0xFF, 0, 0, 0]) * (size // 4), "big")


def tile_planes(tile):
    whole = int.from_bytes(tile, "big")
    lane = _lane0(len(tile))
    return [(whole << (8 * k)) & lane for k in range(4)]


def pen_pixels(planes, size=TILE_BYTES):
    """Per pen 0-15, the pixels drawn with it, in plane-0 lanes."""
    lane = _lane0(size)
    result = []
    for pen in range(16):
        pixels = lane
        for k, plane in enumerate(planes):
            pixels &= plane if pen >> k & 1 else ~plane
        result.append(pixels & lane)
    return result


def filtered_tile(planes, keep, size=TILE_BYTES):
    """The tile with every pixel outside ``keep`` set to pen 15 (transparent)."""
    lane = _lane0(size)
    whole = 0
    for k, plane in enumerate(planes):
        whole |= ((plane & keep) | (lane & ~keep)) >> (8 * k)
    return whole.to_bytes(size, "big")


def quadrants(tile3):
    """A 32x32 tile as four 16x16 object tiles: top left, top right, bottom
    left, bottom right."""
    result = []
    for qy in range(2):
        for qx in range(2):
            result.append(b"".join(tile3[(qy * 16 + r) * 16 + qx * 8:(qy * 16 + r) * 16 + qx * 8 + 8]
                                   for r in range(16)))
    return result


def block_code(index):
    """Object code of 2x2 block ``index``: CPS2 draws a block from codes
    c, c+1, c+0x10 and c+0x11, so eight blocks share each 32-code span."""
    return SCROLL3_BASE + (index // 8) * 32 + (index % 8) * 2


def conversion_tables():
    """CPS2 X and Y words for CPS1 object positions. CPS1 uses 9 bits and
    wraps X from 0x1C0 and Y from 0x100 to the far side; CPS2 positions are
    10-bit, so those values get bit 9. The object offset registers are zero,
    so the hardware adds 64 to X and 16 to Y for every object, whatever its
    attribute bit 7; the words take that back. X also carries sprite
    priority 1. Each table holds 32768 words, the 9-bit value repeating: the
    layer indexes its middle with the doubled raw word, signed, so no mask
    is needed. The third table repeats Y with bit 15 set where a sprite may
    reach the HUD band: a top inside it, or above the screen (screen Y 768
    to 1023, at most a 16-tile block's height above). The raw word 0 itself
    stays unflagged: Final Fight parks unused entries as all-zero words, up
    to 256 of them, and one there cannot reach the screen unless it is a
    block of two or more rows."""
    xs = [((x | (0x200 if x >= 0x1C0 else 0)) - 64) & 0x3FF | 0x2000 for x in range(512)]
    ys = [((y | (0x200 if y >= 0x100 else 0)) - 16) & 0x3FF for y in range(512)]
    bands = [y | 0x8000 if y < S1_BAND or y >= 768 else y for y in ys]
    tables = [bytearray(struct.pack(">512H", *values) * 64) for values in (xs, ys, bands)]
    struct.pack_into(">H", tables[2], 0x8000, ys[0])     # raw word 0, at the middle
    return b"".join(tables)


def wide_table():
    """Y words with bit 15 set for every raw word but 0 (hw_layer.asm's
    CONV_Y2): while scroll 1 holds grouped tiles below the HUD band, every
    sprite is checked, except the parked all-zero entries."""
    ys = [((y | (0x200 if y >= 0x100 else 0)) - 16) & 0x3FF for y in range(512)]
    table = bytearray(struct.pack(">512H", *(y | 0x8000 for y in ys)) * 64)
    struct.pack_into(">H", table, 0x8000, ys[0])
    return bytes(table)


def scroll1_object(region, code, parity):
    """A 16x16 object tile holding scroll 1 tile ``code`` in its top-left
    quarter, the rest transparent. Each 8-byte row of the tile data holds two
    8x8 tiles; MAME's get_tile0_info takes the left half in even map columns
    and the right half in odd ones (``parity``)."""
    rows = []
    for r in range(8):
        at = code * 64 + r * 8 + 4 * parity
        rows.append(bytes(region[at:at + 4]) + b"\xff" * 4)
    return b"".join(rows) + b"\xff" * 64


def safe_tables1(region, masks):
    """Where a sprite may sit under scroll 1 (hw_layer.asm's s1_safe): per
    group mask, then per column parity and code, 1 when that half-tile is
    transparent or every pen it draws is in the mask (CPS1 draws it whole
    over sprites), else 0. The first 4 KiB are for group 0 (no mask: only
    transparent halves); then one 4 KiB part per overlay mask slot."""
    first, last = SCROLL1_CODES
    opaque = []
    for parity in (0, 1):
        for code in range(first, last):
            pixels = pen_pixels(tile_planes(scroll1_object(region, code, parity)))
            opaque.append(sum(1 << pen for pen in range(15) if pixels[pen]))
    parts = [0] + list(masks) + [0] * (OVERLAY_MASK_SLOTS - len(masks))
    return b"".join(bytes(1 if not pens & ~mask else 0 for pens in opaque) for mask in parts)


def overlay_tables1(region, masks, layer_masks):
    """The scroll 1 part: per mask slot, per column parity, a long per code
    naming the object to draw (0: none), in the scroll 2 entry format. Only
    masks the census saw on scroll 1 get objects; identical images share
    one object."""
    first, last = SCROLL1_CODES
    count = last - first
    entries = [[0] * (2 * count) for _ in range(OVERLAY_MASK_SLOTS)]
    images = bytearray()
    index = {}
    counts = {"objects": 0, "entries": 0}
    for code in range(first, last):
        for parity in (0, 1):
            tile = scroll1_object(region, code, parity)
            planes = tile_planes(tile)
            pixels = pen_pixels(planes)
            opaque = sum(1 << pen for pen in range(15) if pixels[pen])
            for slot, mask in enumerate(masks):
                if mask not in layer_masks or not opaque & mask:
                    continue
                if not opaque & ~mask:
                    image = tile
                else:
                    keep = 0
                    for pen in range(15):
                        if mask >> pen & 1:
                            keep |= pixels[pen]
                    image = filtered_tile(planes, keep)
                number = index.get(image)
                if number is None:
                    number = SCROLL1_BASE + len(images) // TILE_BYTES
                    index[image] = number
                    images += image
                    counts["objects"] += 1
                entries[slot][parity * count + code - first] = ((number >> 16) << 13) << 16 | (number & 0xFFFF)
                counts["entries"] += 1
    table = b"".join(struct.pack(f">{2 * count}I", *entries[slot]) for slot in range(OVERLAY_MASK_SLOTS))
    return table, bytes(images), counts


def layer_masks(census, layer):
    return {int(p["mask"], 16) for p in census["tile_mask_pairs"] if p["layer"] == layer}


def census_masks(census):
    masks = sorted({int(pair["mask"], 16) for pair in census["tile_mask_pairs"]})
    if not 0 < len(masks) <= OVERLAY_MASK_SLOTS or any(m & 0x8000 or not m for m in masks):
        raise ValueError("census mask values do not fit the overlay table")
    return masks


def overlay_tables(region, masks):
    """Returns the upper-ROM table, the filtered tile bytes and counts.

    Table: 16 mask words; per scroll 2 code the pens it uses (bit p for pen
    p); then per mask slot a long per code: 0 when that mask lists no pen the
    tile uses, else (Y bits << 16) | object code low word, the Y word bits
    13-14 carrying object code bits 16-17. Slot-major order lets the layer
    reach an entry with one indexed read."""
    first, last = SCROLL2_CODES
    pens_table = bytearray()
    objects = []
    filtered = bytearray()
    counts = {"direct": 0, "filtered": 0, "nothing_high": 0}
    for code in range(first, last):
        planes = tile_planes(region[code * TILE_BYTES:(code + 1) * TILE_BYTES])
        pixels = pen_pixels(planes)
        used = sum(1 << pen for pen in range(16) if pixels[pen])
        pens_table += struct.pack(">H", used)
        slots = []
        for mask in masks:
            opaque = used & 0x7FFF
            if not opaque & mask:
                slots.append(0)
                counts["nothing_high"] += 1
            elif not opaque & ~mask:
                slots.append(0x2000 << 16 | code)
                counts["direct"] += 1
            else:
                keep = 0
                for pen in range(15):
                    if mask >> pen & 1:
                        keep |= pixels[pen]
                index = len(filtered) // TILE_BYTES
                filtered += filtered_tile(planes, keep)
                number = FILTERED_BASE + index
                slots.append(((number >> 16) << 13) << 16 | (number & 0xFFFF))
                counts["filtered"] += 1
        slots += [0] * (OVERLAY_MASK_SLOTS - len(slots))
        objects.append(slots)
    by_slot = b"".join(struct.pack(f">{len(objects)}I", *(row[slot] for row in objects))
                       for slot in range(OVERLAY_MASK_SLOTS))
    head = struct.pack(f">{OVERLAY_MASK_SLOTS}H", *(masks + [0] * (OVERLAY_MASK_SLOTS - len(masks))))
    return bytes(head + pens_table + by_slot), bytes(filtered), counts


def overlay_tables3(region, masks):
    """The scroll 3 part: per code the pens it uses, then per code 16 longs
    naming the 2x2 object block to draw for each mask slot (0: none). Codes
    whose opaque pens a mask fully lists share one unfiltered block."""
    first, last = SCROLL3_CODES
    pens_table = bytearray()
    objects = bytearray()
    blocks = bytearray()
    counts = {"blocks": 0, "nothing_high": 0}

    def add(tile3):
        code = block_code(counts["blocks"])
        while len(blocks) < (code - SCROLL3_BASE + 0x12) * TILE_BYTES:
            blocks.extend(b"\xff" * TILE_BYTES)
        for q, data in zip((0, 1, 0x10, 0x11), quadrants(tile3)):
            at = (code - SCROLL3_BASE + q) * TILE_BYTES
            blocks[at:at + TILE_BYTES] = data
        counts["blocks"] += 1
        return ((code >> 16) << 13) << 16 | (code & 0xFFFF)

    for code in range(first, last):
        tile3 = bytes(region[code * TILE3_BYTES:(code + 1) * TILE3_BYTES])
        planes = tile_planes(tile3)
        pixels = pen_pixels(planes, TILE3_BYTES)
        used = sum(1 << pen for pen in range(16) if pixels[pen])
        pens_table += struct.pack(">H", used)
        opaque = used & 0x7FFF
        whole = None
        slots = []
        for mask in masks:
            if not opaque & mask:
                slots.append(0)
                counts["nothing_high"] += 1
            elif not opaque & ~mask:
                if whole is None:
                    whole = add(tile3)
                slots.append(whole)
            else:
                keep = 0
                for pen in range(15):
                    if mask >> pen & 1:
                        keep |= pixels[pen]
                slots.append(add(filtered_tile(planes, keep, TILE3_BYTES)))
        slots += [0] * (OVERLAY_MASK_SLOTS - len(slots))
        objects += struct.pack(f">{OVERLAY_MASK_SLOTS}I", *slots)
    return bytes(pens_table + objects), bytes(blocks), counts


def assembler(work):
    """Build once per work tree; reuse only while its stamp still matches."""
    tool = work / "tools" / "assembler" / "clownassembler_asm68k"
    stamp = work / "tools" / "assembler.json"
    if tool.is_file() and stamp.is_file():
        recorded = json.loads(stamp.read_text())
        if recorded.get("pins") == bootstrap.PINS and recorded.get("sha256") == sha256(tool.read_bytes()):
            return tool
    if (work / "tools").exists():
        shutil.rmtree(work / "tools")
    tool, receipt = bootstrap.build(work / "tools")
    stamp.write_text(json.dumps({"pins": bootstrap.PINS, "sha256": sha256(tool.read_bytes()),
                                 "receipt": receipt}, indent=2))
    return tool


def fs_cd_song():
    import ff_sound
    return ff_sound.CD_OPENING


def arcade_rounds():
    import english_records              # the restoration's longer intro (its captions' Japanese speed)
    return english_records.ARCADE_OPENING_ROUNDS


def fs_cd_rounds(edition):
    import ff_sound
    return ff_sound.CD_OPENING_ROUNDS[edition]


def fs_cd_ending(edition):
    import ff_sound
    return ff_sound.cd_ending(edition), ff_sound.CD_ENDING_PASSES[edition]


def boot_yymmdd():
    return EX_BOOT_DATE[2:4] + EX_BOOT_DATE[5:7] + EX_BOOT_DATE[8:10]


def boot_identity(program, edition):
    """The EX name screen's rows as the layer's menu_print records hold them, with the program address
    of the release date's first digit (the release plan's display_date check)."""
    region = "USA" if edition != "japan" else "JAPAN"
    date = bytes([18, 12, 1]) + " ".join(boot_yymmdd()).encode() + b"\0"
    at = program.find(date)
    if at < 0 or program.find(date, at + 1) >= 0:
        raise ValueError("the name screen's date record is not in the program exactly once")
    return {"rows": ["FINAL FIGHT EX", boot_yymmdd(), region], "release_date": EX_BOOT_DATE,
            "date_byte_address": f"{at + 3:#x}", "encoding": "spaced-yymmdd"}


def assemble_layer(tool, work, phoenix=False, edition="japan", diag=False, ex=False, ex_equates=None):
    out = work / "layer"
    if out.exists():
        shutil.rmtree(out)
    out.mkdir(parents=True)
    source = out / "hw_layer.asm"
    text = LAYER_SOURCE.read_text()
    if phoenix:
        # Development only: the dead-board map an all-0xFF key selects moves
        # the CPS2 output registers; nothing else in the layer changes.
        if text.count(OUT_BASE_LINE) != 1:
            raise ValueError("layer source lacks its OUT_BASE line")
        text = text.replace(OUT_BASE_LINE, OUT_BASE_LINE.replace("$400000", "$fffff0"))
    if edition != "japan":
        if text.count(EDITION_LINE) != 1:
            raise ValueError("layer source lacks its EDITION line")
        text = text.replace(EDITION_LINE, EDITION_LINE[:-1] + str(EDITIONS.index(edition)))
    if diag:
        if text.count(DIAG_LINE) != 1:
            raise ValueError("layer source lacks its DIAG line")
        text = text.replace(DIAG_LINE, DIAG_LINE[:-1] + "1")
    if ex:
        if text.count(EX_LINE) != 1:
            raise ValueError("layer source lacks its EX line")
        text = text.replace(EX_LINE, EX_LINE[:-1] + "1")
        for name, value in (ex_equates or {}).items():
            line = f"{name:<16}equ 0"
            if text.count(line) != 1:
                raise ValueError(f"layer source lacks its {name} line")
            text = text.replace(line, f"{name:<16}equ ${value:x}")
    source.write_text(text)
    result = subprocess.run([str(tool.resolve()), "/p", "hw_layer.asm,hw_layer.bin,hw_layer.sym,hw_layer.lst"],
                            cwd=out, capture_output=True, text=True)
    if result.returncode:
        raise ValueError("layer assembly failed:\n" + result.stdout + result.stderr)
    blob = (out / "hw_layer.bin").read_bytes()
    if blob[:4] != LAYER_MAGIC:
        raise ValueError("layer header magic missing")
    order = ENTRY_ORDER + (("diag_idle",) if diag else ()) + (EX_ENTRIES if ex else ())
    if ex and "REG_TV" in (ex_equates or {}):   # REGULATION in the CD intro's TV (ex_regulation.py)
        order += ("ex_reg_tail",)
    if ex and edition == "english":             # the restoration EX's text switch (english_ex.py)
        order += ("ex_text_1e", "ex_text_ae")
    count = len(order)
    header = 4 + 4 * count
    entries = dict(zip(order, struct.unpack(f">{count}I", blob[4:header])))
    code_end = struct.unpack(">I", blob[header:header + 4])[0]
    if code_end != LAYER_HOME + len(blob):
        raise ValueError("layer size disagrees with its code_end label")
    for name, address in entries.items():
        if not LAYER_HOME + header + 4 <= address < code_end or address % 2:
            raise ValueError(f"layer entry {name} outside its body: {address:#x}")
    return blob, entries


def encode(replacement, entries):
    if isinstance(replacement, str):
        return bytes.fromhex(replacement)
    if replacement[0] == "long":
        return struct.pack(">I", entries[replacement[1]])
    data = b""
    for part in replacement:
        if isinstance(part, str):
            data += bytes.fromhex(part)
        elif part[0] == "long":
            data += struct.pack(">I", entries[part[1]])
        else:
            data += bytes.fromhex("4eb9") + struct.pack(">I", entries[part[1]])
    return data


def apply_patches(program, entries, patches=PATCHES, covered=None):
    applied = []
    covered = set() if covered is None else covered
    for address, stock_hex, replacement, reason in patches:
        stock = bytes.fromhex(stock_hex)
        new = encode(replacement, entries)
        if len(new) != len(stock):
            raise ValueError(f"patch {address:#x} changes length")
        span = set(range(address, address + len(stock)))
        if span & covered:
            raise ValueError(f"patch {address:#x} overlaps another patch")
        covered |= span
        if program[address:address + len(stock)] != stock:
            raise ValueError(f"stock bytes differ at {address:#x}")
        program[address:address + len(stock)] = new
        applied.append({"address": f"{address:#08x}", "stock": stock_hex, "new": new.hex(), "reason": reason})
    return applied


def text_catalog_block(program):
    """(start, end) of the text block EX's captions edit: group A's offsets
    (0x67082) through group 1's last record (text_catalog.py's formats)."""
    import usa_text                         # here: it imports this module
    import text_catalog as tc
    image = bytes(program)
    end = 0
    for index in range(tc.word(image, tc.GROUP1) // 2):
        end = max(end, usa_text.parse(image, tc.GROUP1 + tc.word(image, tc.GROUP1 + 2 * index))["end"])
    return tc.GROUPA, (end + 1) & ~1


def build(rompaths, work, phoenix=False, encrypted=False, edition="japan", gray_blood=True, start_level=None,
          effect_gains=None, diag=False, ex=False, kit=None):
    """phoenix: development only. Assemble the layer for the dead-board
    (Phoenix) map and package the archive as MAME's sfa3ud, which jtCPS2
    runs unencrypted with the same all-0xFF key. encrypted: package the
    program encrypted with the user's sfa3u key from the reviewed word map
    (encrypt_program.py), with that key; otherwise plaintext with the
    all-0xFF development key. edition: one of EDITIONS (ENGLISH_EDITION.md).
    gray_blood: REGULATION's blood in 0xCCC (regulation.gray_tiles, the chosen
    gray), or with False in 0xEEE. start_level makes a test kit whose every
    new game starts at that level (START_PATCH); effect_gains sets OKI trigger
    cues' levels in dB (sound_members), EFFECT_GAINS when None. diag makes a
    diagnostic kit: the layer's DIAG readouts and DIAG_PATCH. ex makes the
    edition's EX build (EX_PHASE0.md): the layer's EX code and EX_PATCHES.
    kit: the public kit's kit mode (KIT.md), an object that supplies what
    cannot run on the user's machine in plain Python: layer() the assembled
    layer, pieces() the scene pieces from the user's disc, regulation_tv()
    and artwork_asset() the keyed pictures and tiles, sound() the sound
    members."""
    if phoenix and encrypted:
        raise ValueError("a Phoenix build is plaintext")
    if edition not in EDITIONS:
        raise ValueError(f"edition must be one of {EDITIONS}")
    if kit is not None and encrypted:
        raise ValueError("the kit builds plaintext")
    if kit is None:
        bootstrap.require_scratch(work)
    work.mkdir(parents=True, exist_ok=True)
    source = find_archive(rompaths, "ffightu" if edition == "usa" else "ffightj")
    sfa3u = find_archive(rompaths, "sfa3u")
    stock = usa_program(source) if edition == "usa" else stock_program(source)
    program = bytearray(b"\xff" * 0x400000)
    program[:0x100000] = stock
    if diag and encrypted:
        raise ValueError("a diagnostic build is plaintext")
    scenes = None
    if ex:
        import ex_scenes                    # here: optional, and slow the first time
        scenes = kit.pieces(edition) if kit else ex_scenes.pieces(edition)
    ex_equates = None
    if ex:
        scene = {k: int(v, 16) for k, v in scenes["manifest"]["entries"].items() if isinstance(v, str)}
        arm = bytes(stock[STORY_ARM:STORY_ARM + 6])
        if arm[:2] != b"\x3b\x7c" or arm[4:] != b"\x92\xb0":
            raise ValueError("the story's arm is not move.w #n,$92b0(a5)")
        ex_equates = {"EX_OBJHOOK": scene["objhook"], "SC_ENGINE": scene["ENGINE"], "SC_INIT": scene["init"],
                      "SC_INIT2": scene["init2"], "SC_BLK2": scene["blk2"], "SC_INIT3": scene["init3"],
                      "SC_BLK3": scene["blk3"], "SC_STORY_ARM": int.from_bytes(arm[2:4], "big"),
                      "SC_TEXT": EX_TEXT_HOME}
        import ex_arrange                   # the Arrange MRA's posting table (cpsplus's trigger map)
        ex_equates["EX_CLASSES"] = ex_arrange.HOME
        ex_equates["CD_SONG"] = fs_cd_song()           # the SEGA CD opening's song (ff_sound.CD_OPENING)
        ex_equates["CD_ENDING"] = fs_cd_ending(edition)[0]  # the SEGA CD ending's (ff_sound.cd_ending)
        ex_equates["BOOT_DATE"] = int(boot_yymmdd(), 16)    # the name screen's release date, as BCD
        if edition == "english":                        # the restoration's arranged opening row (ex_arrange.py)
            ex_equates["EX_OPEN_EN"] = ex_arrange.restoration_word()
        import ex_regulation                # here: it reads the other region's scenes too
        ex_equates["REG_TV"] = ex_regulation.HOME
        english_ex_block = None
        if edition == "english":            # the restoration EX's captions (english_ex.py)
            import english_ex
            import english_records
            english_story, _ = english_records.build(stock)
            data, caption_timing = english_ex.retime(scenes["data.bin"])    # the redub's caption schedule
            import english_mouths
            data, lips = english_mouths.apply(data, scenes["program.bin"])   # Haggar's lips for the redub's op12
            scenes = {**scenes, "data.bin": data}
            _, _, table_1, table_a = english_ex.english_tables(english_story, stock)
            english_ex_block, english_ex_receipt, (cd_1, cd_a) = english_ex.build(
                stock, scenes["program.bin"], scenes["data.bin"], english_story)
            ex_equates.update({"EN_TABLE_1": table_1, "EN_TABLE_A": table_a, "EN_CD_1": cd_1, "EN_CD_A": cd_a})
    if kit:
        blob, entries = kit.layer(work, phoenix, edition, diag, ex, ex_equates)
    else:
        blob, entries = assemble_layer(assembler(work), work, phoenix, edition, diag, ex, ex_equates)
    if any(b != 0xFF for b in stock[LAYER_HOME:LAYER_HOME + len(blob)]):
        raise ValueError("layer home is not free in the stock program")
    program[LAYER_HOME:LAYER_HOME + len(blob)] = blob
    covered = set()
    applied = apply_patches(program, entries, PATCHES, covered)
    applied += apply_patches(program, entries, TEXT_FIXES, covered)
    if start_level is not None:
        address, stock_hex, new_hex, reason = START_PATCH
        applied += apply_patches(program, entries, ((address, stock_hex, new_hex.format(start_level), reason),),
                                 covered)
    if diag:
        applied += apply_patches(program, entries, (DIAG_PATCH,), covered)
    stage_receipt = None
    if ex:
        classes = ex_arrange.classes(edition)
        if any(b != 0xFF for b in program[ex_arrange.HOME:ex_arrange.HOME + len(classes)]):
            raise ValueError(f"EX_CLASSES's home {ex_arrange.HOME:#x} is not free")
        program[ex_arrange.HOME:ex_arrange.HOME + len(classes)] = classes
        applied += apply_patches(program, entries, EX_PATCHES, covered)
        if edition == "usa":
            applied += apply_patches(program, entries, USA_EX_PATCHES, covered)
        arm_hex = bytes(stock[STORY_ARM:STORY_ARM + 6]).hex()
        cuts = CUT_PATCHES
        if edition == "english":
            cuts = tuple(p for p in CUT_PATCHES if p[0] not in TEXT_SITES) + ENGLISH_EX_TEXT
            if any(b != 0xFF for b in program[english_ex.HOME:english_ex.HOME + len(english_ex_block)]):
                raise ValueError(f"the restoration EX's caption home {english_ex.HOME:#x} is not free")
            program[english_ex.HOME:english_ex.HOME + len(english_ex_block)] = english_ex_block
        applied += apply_patches(program, entries, cuts + (
            (STORY_ARM, arm_hex, (("jsr", "ex_story_arm"),), "CUT SCENES: the story's arm"),), covered)
        sys.path.insert(0, str(ROOT / "backports" / "ffightcd" / "build"))
        import stage_select                 # CPS1 EX's, with its CPS2 backend
        title = stage_select.check(lambda address, length: bytes(program[address:address + length]), ending=True,
                                   hide_prompt=True)
        select, select_entries = stage_select.build(title, stage_select.CPS2_BASE,
                                                    stage_select.cps2_inputs(entries["system_d1"]), ending=True,
                                                    hide_prompt=True)
        home = stage_select.CPS2_BASE
        if any(b != 0xFF for b in program[home:home + len(select)]):
            raise ValueError(f"the stage select's home {home:#x} is not free")
        program[home:home + len(select)] = select
        applied += apply_patches(program, {**entries, **{f"stage_select_{k}": v for k, v in select_entries.items()}},
                                 STAGE_SELECT_PATCHES, covered)
        stage_receipt = {"home": f"{home:#x}", **identity(select),
                         "entries": {k: f"{v:#x}" for k, v in select_entries.items()}}
    if edition == "english":
        import english_records              # here: it imports text_catalog, which imports this module
        applied += apply_patches(program, entries, ENGLISH_PATCHES, covered)
        story, story_receipt = english_records.build(stock)
        if ex:                              # ex_text_1e/ex_text_ae own the lookups
            story = [p for p in story if p[0] not in TEXT_SITES]
            story_receipt["ex"] = {**english_ex_receipt, "caption_timing": caption_timing,
                                   "lips": {k: v for k, v in lips.items() if k != "plan"}}
        applied += apply_patches(program, entries, story, covered)
    usa_receipt, text_records = None, []
    if edition == "usa":
        import usa_text                     # here: it imports text_catalog, which imports this module
        typos, usa_receipt = usa_text.patches(stock)
        applied += apply_patches(program, entries, typos, covered)
        text_records = [(address, len(bytes.fromhex(old))) for address, old, _, _ in typos]
    if ex:                                  # after every other patch: collisions show
        cut_sites = {address: (len(bytes.fromhex(old)), reason) for address, old, _, reason in cuts}
        cut_sites[STORY_ARM] = (6, "CUT SCENES: the story's arm")
        cut_sites[0x0170CC] = (22, "CUT SCENES: the story's scene table stays stock (the dispatcher chooses)")
        cut_sites[0x017182] = (6, "CUT SCENES: scene 2's first step stays stock (CPS1 EX's stub)")
        block = (text_catalog_block(stock))
        scene_graphics, scene_receipt = ex_scenes.merge(
            program, stock, covered, scenes, text_records, cut_sites,
            {"block": block, "drop": "the restoration EX's SEGA CD text is english_ex.py's"} if edition == "english"
            else {"block": block, "home": EX_TEXT_HOME, "stock": TEXT_STOCK},
            ex_scenes.retime_addresses(ex_scenes.REGIONS[edition], stock))
        if edition == "usa":                # SEGA CD's text: CPS1 EX's lowered hyphen (usa_text.lowered)
            import usa_text
            import text_catalog as tc
            size = block[1] - block[0]
            lowered, count = usa_text.lowered_block(program[EX_TEXT_HOME:EX_TEXT_HOME + size],
                                                    tc.GROUP1 - tc.GROUPA)
            program[EX_TEXT_HOME:EX_TEXT_HOME + size] = lowered
            scene_receipt["text"]["lowered_hyphen_records"] = count
        if "REG_TV" in ex_equates:          # REGULATION in the CD intro's TV (ex_regulation.py)
            tail = scene["init"] - len(OVERRIDE_TAIL)
            if bytes(program[tail:tail + len(OVERRIDE_TAIL)]) != OVERRIDE_TAIL:
                raise ValueError(f"the opening override's epilogue is not at {tail:#x}")
            program[tail:tail + len(OVERRIDE_TAIL)] = (b"\x4e\xf9" + entries["ex_reg_tail"].to_bytes(4, "big")
                                                       + b"\x4e\x71" * 3)
            first = ex_scenes.BASE_CODE + scenes["manifest"]["art_tiles"]
            region_ex = ex_scenes.REGIONS[edition]
            if kit:
                tiles, table, reg_receipt = kit.regulation_tv(scenes, first, region_ex)
            else:
                other = ex_scenes.pieces(ex_regulation.PIECES[ex_regulation.OTHER[region_ex]])
                tiles, table, reg_receipt = ex_regulation.build(scenes, other, first, region_ex)
            home = ex_regulation.HOME
            if any(b != 0xFF for b in program[home:home + len(table)]):
                raise ValueError(f"REG_TV's home {home:#x} is not free")
            program[home:home + len(table)] = table
            if [code for code, _ in tiles] != list(range(first, first + len(tiles))):
                raise ValueError("REGULATION's tiles are not consecutive")
            scene_graphics = scene_graphics + [(ex_scenes.SCROLL_GFX + first * 128, b"".join(t for _, t in tiles))]
            scene_receipt["regulation"] = {"override_tail": f"{tail:#x}", **reg_receipt}
    watchdog = install_watchdog(program, entries, read_checked(sfa3u, *SFA3U_KEY))
    census_bytes = CENSUS.read_bytes()
    census = json.loads(census_bytes)
    masks = census_masks(census)
    region = world_graphics(source) if edition == "usa" else stock_graphics(source)
    art_program, art_graphics, art_receipt = [], [], None
    scene_graphics = scene_graphics if ex else []
    if ex:
        import artwork                      # here: it imports this module
        art_program, art_graphics, art_receipt = artwork.build(edition, stock, region,
                                                               kit.artwork_asset(region) if kit else None)
        for home, data in art_program:
            if any(b != 0xFF for b in program[home:home + len(data)]):
                raise ValueError(f"ARTWORK's data home {home:#x} is not free")
            program[home:home + len(data)] = data
    portraits = []
    if ex and edition == "usa":             # the lowered caption hyphen's tiles (usa_text.lowered_block)
        portraits += caption_hyphen(region)
    if edition == "english":                # english_records.py: two staff portraits at CPS2-only codes
        import english_records
        tiles = bytes(region[0x4900 * 64:(0x4900 + english_records.PORTRAIT_GLYPHS[1] - english_records.PORTRAIT_GLYPHS[0]) * 64])
        portraits = [(0x800000 + (0x4400 + english_records.PORTRAIT_BASE) * 64, tiles)]
    english = english_text(region, world_graphics(find_archive(rompaths, "ffight"))) \
        if edition == "english" else None
    if english:
        hyphen = caption_hyphen(region)
        portraits += hyphen
        english["caption_hyphen"] = {"glyph": f"{CAPTION_HYPHEN:#x}", "codes": [f"{0x4400 + CAPTION_HYPHEN:#x}",
                                     f"{0x4410 + CAPTION_HYPHEN:#x}"], "sha256": sha256(hyphen[0][1])}
    repair_select_windows(region)
    table, filtered, overlay_counts = overlay_tables(region, masks)
    table3, blocks, counts3 = overlay_tables3(region, masks)
    table += table3
    overlay_counts.update({f"scroll3_{k}": v for k, v in counts3.items()})
    table1, scroll1, counts1 = overlay_tables1(region, masks, layer_masks(census, 1))
    safe1 = safe_tables1(region, masks)
    wide = wide_table()
    overlay_counts.update({f"scroll1_{k}": v for k, v in counts1.items()})
    conversion = conversion_tables()
    if OVERLAY_TABLE + len(table) > CONVERSION_TABLES:
        raise ValueError("the overlay table runs into the conversion tables")
    if CONVERSION_TABLES + len(conversion) > SAFE1_TABLE or SAFE1_TABLE + len(safe1) > SCROLL1_TABLE:
        raise ValueError("the conversion and safe tables run into each other or the scroll 1 table")
    if SAFE1_TABLE + len(safe1) > WIDE_TABLE or WIDE_TABLE + len(wide) > SCROLL1_TABLE:
        raise ValueError("the wide Y table runs into the safe or scroll 1 table")
    for home, data in ((CONVERSION_TABLES, conversion), (OVERLAY_TABLE, table), (SCROLL1_TABLE, table1),
                       (SAFE1_TABLE, safe1), (WIDE_TABLE, wide)):
        if any(b != 0xFF for b in program[home:home + len(data)]):
            raise ValueError(f"upper ROM table home {home:#x} is not free")
        program[home:home + len(data)] = data

    qtable, qpieces, qreceipt = qsound_screen(rompaths)
    if any(b != 0xFF for b in program[QSCREEN_TABLE:QSCREEN_TABLE + len(qtable)]):
        raise ValueError("the QSound screen table's home is not free")
    program[QSCREEN_TABLE:QSCREEN_TABLE + len(qtable)] = qtable
    rpieces, rreceipt = [], None
    if edition != "usa":
        import regulation                   # here: it imports this module
        rtable, rblood, rpieces, rreceipt = regulation.build(region, rompaths, gray_blood)
        for home, data in ((regulation.REG_TABLE, rtable), (regulation.REG_BLOOD, rblood)):
            if any(b != 0xFF for b in program[home:home + len(data)]):
                raise ValueError(f"the REGULATION data's home {home:#x} is not free")
            program[home:home + len(data)] = data
    roll, creceipt = credits.build(program[credits.CREDITS_SRC:credits.CREDITS_SRC + credits.STOCK_BYTES],
                                   credits.EX_HEADERS if ex else (credits.HEADER,))
    if creceipt["stock_rows"] != credits.STOCK_ROWS or creceipt["rows"] != credits.STOCK_ROWS + (2 if ex else 0):
        raise ValueError(f"the staff roll is not {credits.STOCK_ROWS} rows (EX: 2 more): {creceipt}")
    tail = credits.tail_patch(creceipt["rows"])     # EX: its 2 more rows end on the stock frame
    if tail:
        applied += apply_patches(program, entries, (tail,), covered)
    if any(b != 0xFF for b in program[credits.CREDITS_HOME:credits.CREDITS_HOME + len(roll)]):
        raise ValueError("the staff roll's home is not free")
    program[credits.CREDITS_HOME:credits.CREDITS_HOME + len(roll)] = roll
    cpieces = credits.pieces()
    creceipt = {"home": f"{credits.CREDITS_HOME:#x}", **identity(roll), **creceipt,
                "glyphs": {ch: f"{0x4400 + cell:#x}" for ch, cell in credits.NEW_CELLS.items()},
                "glyph_tiles": identity(b"".join(data for _, data in cpieces))}

    stored, encryption, key = bytes(program), None, DEAD_KEY
    if encrypted:
        import encrypt_program              # here: it is optional
        key = read_checked(sfa3u, *SFA3U_KEY)
        patch_spans = [(address, len(bytes.fromhex(stock_hex))) for address, stock_hex, _, _ in PATCHES + TEXT_FIXES]
        opcode = encrypt_program.word_map(bytes(stock), work / "layer" / "hw_layer.lst", LAYER_HOME, patch_spans)
        spans = [{"name": "hw_layer", "start": LAYER_HOME, "size": len(blob)}]
        stored, encryption = encrypt_program.encrypt(stored, opcode, key, spans, cache_dir=str(work / "cache"))
    members = {}
    names = PHOENIX_PROGRAM if phoenix else SFA3U_PROGRAM
    for index, name in enumerate(names):
        members[name] = upstream.swap_words(stored[index * 0x80000:(index + 1) * 0x80000])
    members.update(cps2_graphics(region, filtered, blocks, scroll1,
                                 qpieces + rpieces + portraits + cpieces + art_graphics + scene_graphics))
    import sound_members                    # here: it imports this module
    test_gains, effect_gains = effect_gains, EFFECT_GAINS if effect_gains is None else effect_gains
    opening = {**({"arcade": arcade_rounds()} if edition == "english" else {}),
               **({"cd": fs_cd_rounds(edition)} if ex else {}),
               **({"ending": fs_cd_ending(edition)[1]} if ex and fs_cd_ending(edition)[1] else {})} or None
    if kit:
        sound, sound_receipt = kit.sound(rompaths, effect_gains, opening)
    else:
        sound, sound_receipt = sound_members.members(rompaths, effect_gains=effect_gains, opening=opening)
    members.update(sound)
    members["dl-1425.bin"] = read_checked(sfa3u, *SFA3U_SOUND[-1])
    members["phoenix.key" if phoenix else "sfa3u.key"] = key

    rom_dir = work / "rom"
    if rom_dir.exists():
        shutil.rmtree(rom_dir)
    rom_dir.mkdir()
    archive = rom_dir / ("sfa3ud.zip" if phoenix else "sfa3u.zip")
    with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED) as z:
        for name in sorted(members):
            info = zipfile.ZipInfo(name, date_time=(1998, 9, 4, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            z.writestr(info, members[name])
    receipt = {
        "purpose": "milestone 1 spike; development archive, not a release",
        "edition": edition,
        "ex": ({"capability": f"{entries['ex_capability']:#x}",
                "arrange": {"classes": f"{ex_arrange.HOME:#x}", "posts": ex_arrange.describe(classes)},
                "artwork": art_receipt,
                "stage_select": stage_receipt, "scenes": scene_receipt} if ex else None),
        "english_text_tiles": english,
        "english_records": story_receipt if edition == "english" else None,
        "usa_text": usa_receipt,
        "phoenix_map": phoenix,
        "encrypted": encryption,
        "inputs": {"ffightu" if edition == "usa" else "ffightj": source.name, "sfa3u": sfa3u.name},
        "stock_program": identity(bytes(stock)),
        "program": identity(bytes(program)),
        "layer": {"home": f"{LAYER_HOME:#x}", **identity(blob),
                  "entries": {k: f"{v:#x}" for k, v in entries.items()}},
        "patches": applied,
        "watchdog": watchdog,
        "overlay": {"census_sha256": sha256(census_bytes), "masks": [f"{m:04x}" for m in masks],
                    "table": {"home": f"{OVERLAY_TABLE:#x}", **identity(table)},
                    "filtered_tiles": identity(filtered), "scroll3_block_tiles": identity(blocks),
                    "scroll1_table": {"home": f"{SCROLL1_TABLE:#x}", **identity(table1)},
                    "scroll1_object_tiles": identity(scroll1),
                    "scroll1_safe_table": {"home": f"{SAFE1_TABLE:#x}", **identity(safe1)},
                    "wide_y_table": {"home": f"{WIDE_TABLE:#x}", **identity(wide)},
                    **overlay_counts},
        "qsound_screen": qreceipt,
        "regulation": rreceipt,
        **({"boot_identity": boot_identity(stored, edition)} if ex else {}),
        "credits": creceipt,
        "test_kit": ({"start_level": start_level, "diag": diag,
                      "effect_gains_db": {f"{c:02x}": g for c, g in (test_gains or {}).items()}}
                     if start_level is not None or test_gains is not None or diag else None),
        "select_window_pixels": [[f"{c:04x}", x, y] for c, x, y in SELECT_WINDOW_PIXELS],
        "sound": {"cache_key": sound_receipt["cache_key"], "music": sound_receipt["recipe"]["music"],
                  "effect_gains_db": {f"{c:02x}": g for c, g in sorted(effect_gains.items())},
                  "sample_bytes": sound_receipt["sample_bytes"]},
        "members": {name: identity(data) for name, data in sorted(members.items())},
    }
    (work / "build.json").write_text(json.dumps(receipt, indent=2) + "\n")
    return receipt


def self_test():
    entries = {name: 0xF0040 + 2 * i for i, name in enumerate(ENTRY_ORDER)}
    decoded = [0] * 10                  # a key whose words 6, 5, 4 are the watchdog
    decoded[6], decoded[5], decoded[4] = struct.unpack(">3H", WATCHDOG)
    key = bytearray(20)
    for b in range(160):                # decode_key: decoded bit b is key bit (317 - b) % 160
        if decoded[b // 16] & (0x8000 >> (b % 16)):
            bit = (317 - b) % 160
            key[bit // 8] |= 1 << ((bit ^ 7) % 8)
    program = bytearray(0x100)
    slots = {"watchdog_reset": 0x10, "watchdog_frame": 0x40}
    for at in slots.values():
        program[at:at + 6] = NOPS3
    install_watchdog(program, slots, bytes(key))
    assert program[0x10:0x16] == WATCHDOG and program[0x40:0x46] == WATCHDOG
    try:
        install_watchdog(program, slots, bytes(key))
    except ValueError:
        pass
    else:
        raise AssertionError("a slot already filled must fail")
    assert encode((jsr("vblank"), NOP), entries) == bytes.fromhex("4eb9000f00424e71")
    assert encode(("long", "reset"), entries) == bytes.fromhex("000f0040")
    for address, stock, replacement, _ in PATCHES:
        assert len(encode(replacement, entries)) == len(bytes.fromhex(stock)), hex(address)
    starts = sorted(p[0] for p in PATCHES)
    assert starts == [p[0] for p in PATCHES], "keep the patch table in address order"
    region = bytearray(0x200000)
    for code, x, y in SELECT_WINDOW_PIXELS:   # pen 9 rows with the stock holes
        row = code * TILE3_BYTES + y * 16
        region[row:row + 16] = bytes.fromhex("ff0000ff") * 4
        region[row + (x // 8) * 4 + 1] |= 1 << (7 - x % 8)
        region[row + (x // 8) * 4 + 2] |= 1 << (7 - x % 8)
    before = bytes(region)
    repair_select_windows(region)
    assert sum((a ^ b).bit_count() for a, b in zip(before, region)) == 8
    assert all(scroll3_pen(region, *p) == 9 for p in SELECT_WINDOW_PIXELS)
    try:
        repair_select_windows(region)
    except ValueError:
        pass
    else:
        raise AssertionError("a repaired or moved hole must fail the guard")
    region = bytearray(0x200000)
    region[0] = 1
    region[0x110000] = 2
    members = cps2_graphics(region, b"\x03" * TILE_BYTES, b"\x04" * TILE_BYTES)
    assert set(members) == set(SFA3U_GFX[0] + SFA3U_GFX[1])
    assert all(len(data) == 0x400000 for data in members.values())
    assert members[SFA3U_GFX[1][0]][0] == 3 and members[SFA3U_GFX[1][0]][2] == 0xFF
    # Pens: row 0 pixel 0 uses pen 5 (bits 0 and 2), pixel 9 pen 8 (bit 3);
    # every other pixel is pen 15.
    tile = bytearray(b"\xff" * TILE_BYTES)
    tile[1] &= 0x7F                     # pixel 0: clear bit 1
    tile[3] &= 0x7F                     # pixel 0: clear bit 3
    for k in (0, 1, 2):
        tile[4 + k] &= 0xBF             # pixel 9: clear bits 0-2
    planes = tile_planes(bytes(tile))
    pixels = pen_pixels(planes)
    assert [pen for pen in range(16) if pixels[pen]] == [5, 8, 15]
    assert filtered_tile(planes, pixels[5])[4:8] == b"\xff" * 4    # pen 8 dropped
    assert filtered_tile(planes, pixels[5] | pixels[8]) == bytes(tile)
    region = bytearray(b"\xff" * 0x200000)
    region[0x3001 * TILE_BYTES:0x3002 * TILE_BYTES] = tile
    table, filtered, counts = overlay_tables(region, [0x0020, 0x0120])
    head = OVERLAY_MASK_SLOTS * 2
    assert struct.unpack_from(">H", table, head + 2)[0] == 0x8120
    base = head + 2 * (SCROLL2_CODES[1] - SCROLL2_CODES[0]) + 4
    per_slot = 4 * (SCROLL2_CODES[1] - SCROLL2_CODES[0])
    assert struct.unpack_from(">I", table, base)[0] == 0x4000 << 16
    assert struct.unpack_from(">I", table, base + per_slot)[0] == 0x2000 << 16 | 0x3001
    assert counts == {"direct": 1, "filtered": 1, "nothing_high": 8190} and len(filtered) == TILE_BYTES
    tile3 = bytes(range(256)) * 2
    q = quadrants(tile3)
    assert q[0][:8] == tile3[0:8] and q[1][:8] == tile3[8:16] and q[2][:8] == tile3[256:264]
    assert block_code(0) == 0x30000 and block_code(7) == 0x3000E and block_code(8) == 0x30020
    region = bytearray(b"\xff" * 0x200000)
    t3 = bytearray(b"\xff" * TILE3_BYTES)
    t3[1] &= 0x7F                       # pixel 0: pen 13 (bit 1 clear)
    region[0x981 * TILE3_BYTES:0x982 * TILE3_BYTES] = t3
    table3, blocks, counts3 = overlay_tables3(region, [0x2000, 0x0001])
    assert struct.unpack_from(">H", table3, 2)[0] == 0xA000
    base3 = 2 * (SCROLL3_CODES[1] - SCROLL3_CODES[0]) + 4 * OVERLAY_MASK_SLOTS
    assert struct.unpack_from(">2I", table3, base3) == (0x6000 << 16, 0)
    assert counts3 == {"blocks": 1, "nothing_high": 2 * 640 - 1}
    assert blocks[:8] == bytes(t3[:8]) and blocks[TILE_BYTES:TILE_BYTES + 8] == b"\xff" * 8
    region = bytearray(b"\xff" * 0x200000)
    region[0x4401 * 64 + 4:0x4401 * 64 + 8] = bytes((0x7F, 0xFF, 0xFF, 0xFF))  # odd column: pixel 0 pen 14
    obj = scroll1_object(region, 0x4401, 1)
    assert obj[:4] == bytes((0x7F, 0xFF, 0xFF, 0xFF)) and obj[4:8] == b"\xff" * 4 and len(obj) == TILE_BYTES
    assert scroll1_object(region, 0x4401, 0) == b"\xff" * TILE_BYTES
    table1, images1, counts1 = overlay_tables1(region, [0x0001, 0x4000], {0x4000})
    count1 = SCROLL1_CODES[1] - SCROLL1_CODES[0]
    assert counts1 == {"objects": 1, "entries": 1} and images1 == obj
    assert struct.unpack_from(">I", table1, 4 * (2 * count1 + count1 + 1))[0] == 0x6000 << 16 | 0x8000
    safe1 = safe_tables1(region, [0x0001, 0x4000])
    assert len(safe1) == (OVERLAY_MASK_SLOTS + 1) * 2 * count1
    at = lambda part, parity, code: safe1[part * 2 * count1 + parity * count1 + code - SCROLL1_CODES[0]]
    assert (at(0, 1, 0x4401), at(1, 1, 0x4401), at(2, 1, 0x4401), at(3, 1, 0x4401)) == (0, 0, 1, 0)
    assert at(0, 0, 0x4401) == at(1, 0, 0x4401) == 1
    conversion = conversion_tables()
    assert len(conversion) == 0x30000
    assert re.search(rf"^S1_BAND\s+equ\s+{S1_BAND}\b", LAYER_SOURCE.read_text(), re.M)
    x_word = lambda raw: struct.unpack_from(">H", conversion, 0x8000 + (raw * 2 & 0xFFFF ^ 0x8000) - 0x8000)[0]
    y_word = lambda raw: struct.unpack_from(">H", conversion, 0x18000 + (raw * 2 & 0xFFFF ^ 0x8000) - 0x8000)[0]
    assert x_word(0x40) == 0x2000 and x_word(0x1BF) == 0x217F
    assert x_word(0x1C0) == 0x2380 and x_word(0xFFF0) == x_word(0x1F0) == 0x23B0
    assert y_word(0x10) == 0 and y_word(0xFF) == 0xEF and y_word(0x100) == 0x2F0
    assert y_word(0x7E10) == y_word(0x10)
    band_word = lambda raw: struct.unpack_from(">H", conversion, 0x28000 + (raw * 2 & 0xFFFF ^ 0x8000) - 0x8000)[0]
    assert band_word(0x10) == 0x8000 and band_word(0x10 + S1_BAND) == S1_BAND
    assert band_word(0x100) == 0x2F0 and band_word(0x110) == 0x8300 and band_word(0xFF) == 0xEF
    assert band_word(0) == 0x3F0 and band_word(0x200) == band_word(0x8200) == 0x83F0
    wide = wide_table()
    wide_word = lambda raw: struct.unpack_from(">H", wide, 0x8000 + (raw * 2 & 0xFFFF ^ 0x8000) - 0x8000)[0]
    assert wide_word(0) == 0x3F0 and wide_word(0x80) == 0x8070 and wide_word(0x110) == 0x8300
    print("self-test passed")


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--rompath", action="append", type=Path, default=[])
    parser.add_argument("--work", type=Path, default=TRACK / "work" / "m1-spike")
    parser.add_argument("--phoenix-map", action="store_true",
                        help="development only: build for the dead-board map as MAME's sfa3ud")
    parser.add_argument("--edition", choices=EDITIONS, default="japan")
    parser.add_argument("--encrypted", action="store_true",
                        help="encrypt the program with the user's sfa3u key (manifests/encryption_map.json)")
    parser.add_argument("--ex", action="store_true", help="the edition's EX build (EX_PHASE0.md)")
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args(argv)
    if args.self_test:
        self_test()
        return 0
    receipt = build(args.rompath + default_rompaths(), args.work, args.phoenix_map, args.encrypted, args.edition,
                    ex=args.ex)
    print(json.dumps({"program": receipt["program"], "layer": receipt["layer"],
                      "patches": len(receipt["patches"]), "encrypted": receipt["encrypted"]}, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
