#!/usr/bin/env python3
"""EX's ARTWORK ARCADE STADIUM: Capcom Arcade Stadium's Final Fight graphics.

Capcom Arcade Stadium's Final Fight, US and Japan alike, changes 412 graphics
bytes and nothing else (extraction/cas/README.md): sprite tile 0x183D, the
drink-can pickup, with its marking removed, and scroll 3 tiles 0xB52 and
0xB53, part of the sign in Uptown's far background. EX's ARTWORK row shows
them instead of the arcade tiles (EX_BUILD.md). The arcade tiles stay as
they are; the collection's go into free graphics (CAN_CODE, SIGN_CODES), and
two of the layer's selectors choose with ARTWORK ARCADE STADIUM:

- ex_item_anim (0x5A546): the item spawn takes its animation from a copy of
  the item animation block (ITEM_BLOCK, steps and frame records, every
  offset in it relative), whose can frame names CAN_CODE;
- ex_s3_block (0x62FE8): scroll 3's writer takes Uptown's sign block
  (SIGN_BLOCK) from a copy whose two sign cells name SIGN_CODES.

The three tiles are embedded (assets/arcade_stadium_tiles.json, 1,152 bytes,
17 October 2026: no one has to supply the collection). The builder
checks them by SHA-256, checks that the edition's stock tiles are the ones
they were taken against and that they differ from them by the audited 412
bytes. ``--extract`` regenerates the asset from the collection's ROM ZIPs
(FFC2_CAS_ROMS, roms/switch/cas_roms/, or extracted from the user's Final
Fight DLC NSP into this track's work/cache/cas with extraction/cas's reader,
the Switch keys and NSTool), pinned below; the US and Japanese sets give the
same tiles.

    python3 artwork.py --self-test
"""
from __future__ import annotations

# BEGIN ARCADE PYTHON BOOTSTRAP
import sys as _arcade_sys
from pathlib import Path as _ArcadePath
_arcade_sys.path.insert(0, str(_ArcadePath(__file__).resolve().parents[3]))
from kit_python import bootstrap as _arcade_bootstrap
_arcade_bootstrap()
# END ARCADE PYTHON BOOTSTRAP

import argparse
import hashlib
import io
import json
import os
from pathlib import Path
import shutil
import sys
import zipfile

import build_m1_spike as spike

TRACK = Path(__file__).resolve().parents[1]
ROOT = TRACK.parents[1]
CAS_DIR = ROOT / "extraction" / "cas"
# The collection's Final Fight ROM ZIPs (extraction/cas/manifests/dlc_audit.json).
CAS_ZIPS = {
    "ffightj": ("ffightj.mameac.2", 1496859, "e6781a82f6c5feca16214199dddc1360973c6033f86545a42b1acdc634b8102e"),
    "ffightu": ("ffightu.mameac.2", 1433790, "018ff13d63d6dfd5fe0ef6d134469fe9f1f17427a330857a89613644d2d001a4"),
}
CAS_NSP = "Capcom Arcade Stadium [FINAL FIGHT][01001E0013209019][US][v0].nsp"
CAS_NSP_SHA256 = "6eab18d4f07d1a6d9f701725256129c8dc3e3e9b239098e5d579b2522f0307c0"
CHANGED_BYTES = 412
TILES_ASSET = TRACK / "assets" / "arcade_stadium_tiles.json"
TILE_NAMES = ("can", "sign_left", "sign_right")

CAN_TILE = 0x183D                       # object code: the drink can pickup (item type 13)
SIGN_TILES = (0xB52, 0xB53)             # scroll 3 codes: Uptown's sign
CAN_CODE = 0x5800                       # free object code (CPS2 graphics 0x2C0000)
SIGN_CODES = (0x3700, 0x3701)           # free scroll 3 codes (0xEE0000), past EX's lettering
OBJ_BYTES, S3_BYTES = 128, 512

ITEM_TABLE = 0x5A57C                    # the spawn's animation per item type, 36 longs
ITEM_TYPES = 36
ITEM_BLOCK = (0x5A24A, 0x5A506)         # their steps (to 0x5A2DA, which loops) and frame records
CAN_FRAME_CODE = 0x5A3B2                # the can's frame record's code word
S3_WORD_BASE = 0x980                    # scroll 3's writer adds it to each block cell's word
SIGN_BLOCK = 0x82C00                    # Uptown's sign: block 0x2C of scroll 3's blocks at 0x80000
SIGN_CELLS = (0x82C64, 0x82C68)         # its two sign cells, words 0x1D2 and 0x1D3

EX_ART = 0x301000                       # upper program ROM, after the staff roll (hw_layer.asm EX_ART)
EX_ITEM_ANIMS = EX_ART                  # the item table copy, then the block copy
EX_ITEM_BLOCK = EX_ART + 0x100
EX_SIGN_BLOCK = EX_ART + 0x400


def cas_dirs():
    dirs = [Path(p) for p in os.environ.get("FFC2_CAS_ROMS", "").split(os.pathsep) if p]
    return dirs + [ROOT / "roms" / "switch" / "cas_roms", TRACK / "work" / "cache" / "cas"]


def checked(path, size, digest):
    data = path.read_bytes()
    if len(data) != size or hashlib.sha256(data).hexdigest() != digest:
        raise ValueError(f"{path} is not the pinned collection ZIP")
    return data


def cas_zip(set_name):
    """The collection's ZIP for ffightj or ffightu, extracting it into the
    track's cache from the user's DLC NSP when no copy is present."""
    asset, size, digest = CAS_ZIPS[set_name]
    for base in cas_dirs():
        path = base / f"{asset}.zip"
        if path.exists():
            return checked(path, size, digest), path
    export(TRACK / "work" / "cache" / "cas")
    path = TRACK / "work" / "cache" / "cas" / f"{asset}.zip"
    return checked(path, size, digest), path


def export(out, keys=None, media_root=None):
    """Extract the collection's Final Fight ROM ZIPs from the user's DLC NSP
    (pinned by extraction/cas/manifests/dlc_unpack.json) into out."""
    sys.path.insert(0, str(CAS_DIR))
    import audit_dlc                    # extraction/cas: its reader and NSTool recipe
    receipt = json.loads((CAS_DIR / "manifests" / "dlc_unpack.json").read_text())
    rows = [row for row in receipt["inputs"] if row["nsp"] == CAS_NSP]
    if len(rows) != 1:
        raise ValueError("the DLC receipt does not pin the Final Fight NSP")
    out.mkdir(parents=True, exist_ok=True)
    work = out / "extract"
    if work.exists():
        shutil.rmtree(work)
    inputs = out / "inputs.json"
    inputs.write_text(json.dumps({"inputs": rows}))
    args = argparse.Namespace(work=work, tool_cache=out / "tool", inputs=inputs,
                              media_root=media_root or ROOT / "roms" / "switch",
                              keys=keys or ROOT / "roms" / "switch" / "prod.keys")
    _, catalog = audit_dlc.prepare(args)
    for set_name, (asset, size, digest) in CAS_ZIPS.items():
        entries = [e for e in catalog if e.get("zip") and e["path"].endswith("/" + asset)]
        if len(entries) != 1:
            raise ValueError(f"the NSP has no single {asset}")
        source = work / (entries[0]["role"] + "-roms") / entries[0]["zip"]
        checked(source, size, digest)
        shutil.copyfile(source, out / f"{asset}.zip")
    shutil.rmtree(work)
    inputs.unlink()


def cas_region(set_name, data):
    """The collection's graphics region, in the layout the builder's stock
    region has for that set (stock_graphics, world_graphics)."""
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        names = {Path(n).name.lower(): n for n in z.namelist()}
        read = lambda name: z.read(names[name.lower()])
        region = bytearray(0x200000)
        if set_name == "ffightj":
            for name, offset, _ in spike.FFIGHTJ_GFX:
                region[offset:offset + 0x100000:8] = read(name)
        else:
            for name, base, _ in spike.FFIGHT_GFX:
                part = read(name)
                for i in range(0, len(part), 2):
                    at = base + (i // 2) * 8
                    region[at:at + 2] = part[i:i + 2]
    return region


def tile_spans():
    return [(CAN_TILE * OBJ_BYTES, OBJ_BYTES)] + [(code * S3_BYTES, S3_BYTES) for code in SIGN_TILES]


def changes(stock, collection):
    """The collection's three tiles, after checking that it differs from the
    stock region in those tiles only, by the audited 412 bytes."""
    changed = [i for i in range(len(stock)) if stock[i] != collection[i]]
    if len(changed) != CHANGED_BYTES:
        raise ValueError(f"the collection changes {len(changed)} graphics bytes, not {CHANGED_BYTES}")
    spans = tile_spans()
    if any(not any(at <= i < at + n for at, n in spans) for i in changed):
        raise ValueError("the collection changes graphics outside its can and sign tiles")
    return [bytes(collection[at:at + n]) for at, n in spans]


def item_copies(program):
    """(table copy, block copy): the item animations with the can frame
    naming CAN_CODE, relocated to EX_ITEM_BLOCK."""
    start, end = ITEM_BLOCK
    table = [int.from_bytes(program[ITEM_TABLE + 4 * i:ITEM_TABLE + 4 * i + 4], "big") for i in range(ITEM_TYPES)]
    if not all(start <= step < end for step in table):
        raise ValueError("an item animation starts outside the item block")
    block = bytearray(program[start:end])
    if int.from_bytes(block[CAN_FRAME_CODE - start:CAN_FRAME_CODE - start + 2], "big") != CAN_TILE:
        raise ValueError("the can frame's code word moved")
    block[CAN_FRAME_CODE - start:CAN_FRAME_CODE - start + 2] = CAN_CODE.to_bytes(2, "big")
    return b"".join((step - start + EX_ITEM_BLOCK).to_bytes(4, "big") for step in table), bytes(block)


def sign_copy(program):
    block = bytearray(program[SIGN_BLOCK:SIGN_BLOCK + 0x100])
    for cell, tile, code in zip(SIGN_CELLS, SIGN_TILES, SIGN_CODES):
        at = cell - SIGN_BLOCK
        if int.from_bytes(block[at:at + 2], "big") != tile - S3_WORD_BASE:
            raise ValueError(f"sign cell {cell:#x} moved")
        block[at:at + 2] = (code - S3_WORD_BASE).to_bytes(2, "big")
    return bytes(block)


def embedded_tiles(region, asset=None):
    """The asset's three tiles, after checking them, the edition's stock
    tiles they replace, and the 412-byte difference between the two; asset:
    the asset's text (the public kit rebuilds it from keyed tiles, KIT.md)."""
    doc = json.loads(TILES_ASSET.read_text() if asset is None else asset)
    tiles, differing = [], 0
    for row, name, (at, n) in zip(doc["tiles"], TILE_NAMES, tile_spans()):
        data = bytes.fromhex(row["hex"])
        stock = bytes(region[at:at + n])
        if row["name"] != name or len(data) != n or spike.sha256(data) != row["sha256"]:
            raise ValueError(f"{TILES_ASSET.name}: tile {name} is not as pinned")
        if spike.sha256(stock) != row["stock_sha256"]:
            raise ValueError(f"the edition's stock tile {row['tile']} is not the one {name} was taken against")
        differing += sum(1 for a, b in zip(data, stock) if a != b)
        tiles.append(data)
    if differing != CHANGED_BYTES or doc["changed_bytes"] != CHANGED_BYTES:
        raise ValueError(f"the embedded tiles differ from stock by {differing} bytes, not {CHANGED_BYTES}")
    return tiles


def extract(out):
    """Regenerate the tiles asset from the collection's ROM ZIPs: both sets
    must give the same tiles, against the same stock tiles."""
    rompaths = spike.default_rompaths()
    found = {}
    for set_name, stock in (("ffightj", spike.stock_graphics(spike.find_archive(rompaths, "ffightj"))),
                            ("ffightu", spike.world_graphics(spike.find_archive(rompaths, "ffightu")))):
        data, _ = cas_zip(set_name)
        found[set_name] = (changes(stock, cas_region(set_name, data)),
                           [bytes(stock[at:at + n]) for at, n in tile_spans()])
    if found["ffightj"] != found["ffightu"]:
        raise ValueError("the US and Japanese sets give different tiles")
    tiles, stock = found["ffightj"]
    kinds = (("object", CAN_TILE), ("scroll3", SIGN_TILES[0]), ("scroll3", SIGN_TILES[1]))
    doc = {
        "purpose": "EX's ARTWORK ARCADE STADIUM (EX_BUILD.md): Capcom Arcade Stadium's three edited Final Fight "
                   "tiles, embedded (17 October 2026) so no one needs to supply the collection",
        "provenance": {
            "collection": "Capcom Arcade Stadium (Nintendo Switch), FINAL FIGHT DLC",
            "nsp": CAS_NSP, "nsp_sha256": CAS_NSP_SHA256,
            "zips": {k: {"asset": v[0], "sha256": v[2]} for k, v in CAS_ZIPS.items()},
            "audit": "extraction/cas/manifests/dlc_audit.json (412 changed graphics bytes, the same in ffightj "
                     "and ffightu)",
            "regenerate": "python3 scripts/artwork.py --extract assets/arcade_stadium_tiles.json",
        },
        "changed_bytes": CHANGED_BYTES,
        "tiles": [{"name": name, "layer": layer, "tile": f"{tile:#x}", "bytes": len(data),
                   "sha256": spike.sha256(data), "stock_sha256": spike.sha256(old), "hex": data.hex()}
                  for name, (layer, tile), data, old in zip(TILE_NAMES, kinds, tiles, stock)],
    }
    out.write_text(json.dumps(doc, indent=2) + "\n")


def build(edition, stock_program, region, asset=None):
    """(program pieces, graphics pieces, receipt) for an EX build; asset: the
    tiles asset's text when not read from TILES_ASSET."""
    asset = TILES_ASSET.read_text() if asset is None else asset
    can, *sign = embedded_tiles(region, asset)
    table, block = item_copies(stock_program)
    program = [(EX_ITEM_ANIMS, table), (EX_ITEM_BLOCK, block), (EX_SIGN_BLOCK, sign_copy(stock_program))]
    if EX_ITEM_BLOCK + len(block) > EX_SIGN_BLOCK:
        raise ValueError("the item block copy runs into the sign block copy")
    graphics = [(CAN_CODE * OBJ_BYTES, can)] + [(0x800000 + code * S3_BYTES, tile)
                                                 for code, tile in zip(SIGN_CODES, sign)]
    receipt = {"tiles": {"asset": TILES_ASSET.name, "sha256": spike.sha256(asset.encode())},
               "can": {"tile": f"{CAN_TILE:#x}", "code": f"{CAN_CODE:#x}", "sha256": spike.sha256(can)},
               "sign": {"tiles": [f"{t:#x}" for t in SIGN_TILES], "codes": [f"{c:#x}" for c in SIGN_CODES],
                        "sha256": spike.sha256(b"".join(sign))},
               "program": {f"{at:#x}": spike.identity(piece) for at, piece in program}}
    return program, graphics, receipt


def self_test():
    stock = bytearray(0x200000)
    collection = bytearray(stock)
    spans = tile_spans()
    for (at, n), count in zip(spans, (100, 156, 156)):     # 412 distinct bytes
        for k in range(count):
            collection[at + k] ^= 0x5A
    tiles = changes(stock, collection)
    assert [len(t) for t in tiles] == [128, 512, 512] and tiles[0] == bytes(collection[spans[0][0]:][:128])
    collection[0] ^= 1
    try:
        changes(stock, collection)
        raise AssertionError("a change outside the tiles passed")
    except ValueError:
        pass
    program = bytearray(b"\xff" * 0x100000)
    start, end = ITEM_BLOCK
    for i in range(ITEM_TYPES):
        program[ITEM_TABLE + 4 * i:ITEM_TABLE + 4 * i + 4] = (start + 4 * i).to_bytes(4, "big")
    program[CAN_FRAME_CODE:CAN_FRAME_CODE + 2] = CAN_TILE.to_bytes(2, "big")
    table, block = item_copies(program)
    assert int.from_bytes(table[4:8], "big") == EX_ITEM_BLOCK + 4
    assert block[CAN_FRAME_CODE - start:CAN_FRAME_CODE - start + 2] == CAN_CODE.to_bytes(2, "big")
    for cell, tile in zip(SIGN_CELLS, SIGN_TILES):
        program[cell:cell + 2] = (tile - S3_WORD_BASE).to_bytes(2, "big")
    sign = sign_copy(program)
    assert sign[0x64:0x66] == (SIGN_CODES[0] - S3_WORD_BASE).to_bytes(2, "big")
    assert EX_ITEM_BLOCK + (end - start) <= EX_SIGN_BLOCK
    print("self-test passed")


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--self-test", action="store_true")
    parser.add_argument("--export", type=Path, help="extract the collection's ZIPs from the user's NSP into this folder")
    parser.add_argument("--extract", type=Path, help="regenerate the tiles asset from the collection's ZIPs")
    parser.add_argument("--keys", type=Path)
    parser.add_argument("--media-root", type=Path)
    args = parser.parse_args(argv)
    if args.self_test:
        self_test()
        return 0
    if args.extract:
        extract(args.extract.resolve())
        print(f"wrote {args.extract}")
        return 0
    if args.export:
        export(args.export.resolve(), args.keys, args.media_root)
        print(f"wrote {', '.join(asset + '.zip' for asset, _, _ in CAS_ZIPS.values())} to {args.export}")
        return 0
    parser.error("nothing to do")


if __name__ == "__main__":
    sys.exit(main())
