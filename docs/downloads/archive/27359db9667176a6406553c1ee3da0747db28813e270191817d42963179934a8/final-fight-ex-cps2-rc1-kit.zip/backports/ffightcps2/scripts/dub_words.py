#!/usr/bin/env python3
"""The redub's words on the game's clock: where each English line's words fall, as the mix places them.

21 October, on the restoration EX's Arrange kit (redub mix 15): "Captions don't line up to vocals in
some spots" and "Ending captions and mouth don't align with vocals". The captions followed Japanese EX's
caption times moved by each line's push, and Japanese EX's own captions sit up to 1.7 s off its voices
(the arcade's text schedule), while a caption that shows part of a line (op03's second record, en12's
three) followed the Japanese pacing. english_ex.py now starts each caption at the English word it begins
with; this records those words.

``measure`` renders the mix of the receipt's take set from the durable take store with its voice stem
(dub_mix.py mix --stems, into this run's scratch), then has faster-whisper (large-v3, word timestamps,
offline) hear each line's span of the voice stem: the voice exactly as mixed, runs, pace and placement
included. It writes manifests/dub_words.json: per line, its take's digest, its span and its words with
their times on the scene's clock (s), pinned to the receipt's digest; english_ex.py refuses a stale file.

    python3 dub_words.py measure [--work <scratch dir>]
    python3 dub_words.py --self-test
"""
from __future__ import annotations

# BEGIN ARCADE PYTHON BOOTSTRAP
import sys as _arcade_sys
from pathlib import Path as _ArcadePath
_arcade_sys.path.insert(0, str(_ArcadePath(__file__).resolve().parents[3]))
from kit_python import bootstrap as _arcade_bootstrap
_arcade_bootstrap()
# END ARCADE PYTHON BOOTSTRAP

import argparse
import hashlib
import json
import os
import re
import sys
from pathlib import Path

TRACK = Path(__file__).resolve().parents[1]
WORDS = TRACK / "manifests" / "dub_words.json"
DUB_MIX = TRACK / "manifests" / "dub_mix_receipt.json"
PAD_S = 0.25                # heard from this before a line's start to this after its end


def norm(word):
    """A word as compared: lowercase letters and digits, apostrophes dropped."""
    return re.sub(r"[^a-z0-9]", "", word.lower())


def receipt_digest():
    return hashlib.sha256(DUB_MIX.read_bytes()).hexdigest()


def load(scene=None):
    """{line: row} of dub_words.json, refusing one measured from another mix receipt."""
    doc = json.loads(WORDS.read_text())
    if doc["receipt_sha256"] != receipt_digest():
        raise ValueError("dub_words.json is not the mix receipt's: run dub_words.py measure")
    return {k: v for k, v in doc["lines"].items() if scene is None or v["scene"] == scene}


def find(words, text, after=0):
    """The index of the first word of text in words at or after index after: the first word that
    matches, else the word at the same share of the line's characters (None when words is empty)."""
    if not words:
        return None
    want = [norm(w) for w in text.split() if norm(w)]
    if not want:
        return after
    for k in range(after, len(words)):
        got = norm(words[k][0])
        if got and (got == want[0] or (len(want[0]) >= 3 and got.startswith(want[0][:3]))):
            return k
    return min(after, len(words) - 1)


def measure(work):
    import numpy as np
    from scipy.signal import resample_poly
    import build_redub_backing as B
    import dub_mix
    receipt = json.loads(DUB_MIX.read_text())
    out = work / "mix"
    if dub_mix.main(["mix", "--takes", receipt["takes_set"], "--out", str(out), "--stems"]) != 0:
        raise SystemExit("the mix failed its checks")
    rendered = json.loads((out / "mix_report.json").read_text())
    for scene in ("opening", "ending"):
        if rendered["scenes"][scene]["sha256"] != receipt["scenes"][scene]["sha256"]:
            raise SystemExit(f"{scene}: the render is not the receipt's mix")
    os.environ.setdefault("HF_HUB_OFFLINE", "1")
    from faster_whisper import WhisperModel
    model = WhisperModel("large-v3", device="cpu", compute_type="int8")
    lines = {}
    for scene in ("opening", "ending"):
        voice = B.read(out / f"{scene}_voices.wav").mean(1)
        for row in receipt["scenes"][scene]["lines"]:
            a = max(0, int((row["start"] - PAD_S) * B.SR))
            b = min(len(voice), int((row["end"] + PAD_S) * B.SR))
            x = resample_poly(voice[a:b] / 32768.0, 160, 441).astype(np.float32)
            segs, _ = model.transcribe(x, language="en", word_timestamps=True, condition_on_previous_text=False)
            words = [[w.word.strip(), round(a / B.SR + w.start, 3), round(a / B.SR + w.end, 3)]
                     for s in segs for w in (s.words or []) if w.word.strip()]
            lines[row["id"]] = {"scene": scene, "take_sha256": receipt["takes_sha256"].get(row["id"]),
                                "start": row["start"], "end": row["end"], "words": words}
            print(f"{row['id']}: {len(words)} words, " + " ".join(w for w, _, _ in words)[:90])
    doc = {"schema": 1, "what": "the redub's words on each scene's clock as the mix places them "
                                "(dub_words.py measure: faster-whisper large-v3 on the mix's voice stem)",
           "receipt_sha256": receipt_digest(), "takes_set": receipt["takes_set"], "lines": lines}
    text = json.dumps(doc, indent=1)
    for row in lines.values():                          # one line per word list
        text = text.replace(json.dumps(row["words"], indent=1).replace("\n", "\n   "), json.dumps(row["words"]))
    WORDS.write_text(text + "\n")
    print(f"{len(lines)} lines into {WORDS.name}")


def self_test():
    words = [["Not", 1.0, 1.2], ["so", 1.2, 1.4], ["fast,", 1.4, 1.7], ["Mike.", 1.8, 2.1], ["Turn", 2.6, 2.8]]
    assert find(words, "Not so fast, Mike.") == 0
    assert find(words, "Turn on your TV", after=1) == 4
    assert find(words, "Mike...", after=2) == 3
    assert find([], "x") is None
    assert norm("I'm") == "im" and norm("...Cody!") == "cody"
    print("self-test passed")


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    p.add_argument("--self-test", action="store_true")
    sub = p.add_subparsers(dest="cmd")
    s = sub.add_parser("measure")
    s.add_argument("--work", type=Path, default=TRACK / "work" / "dub-words")
    a = p.parse_args(argv)
    if a.self_test:
        self_test()
        return 0
    if a.cmd != "measure":
        p.error("name a command or --self-test")
    measure(a.work.resolve())
    return 0


if __name__ == "__main__":
    sys.exit(main())
