#!/usr/bin/env python3
"""Render Final Fight's YM2151 voices with ymfm, as driver 2.00 programs them.

A voice record (ff_sound.voice) is written to the chip the way the driver's
op 08 and note handlers do (0x093B, 0x05E2, 0x06E4): LFO block, feedback and
connection with both outputs on, per-operator registers in register order,
the note's key code from the driver's table at 0x0707, then key-on with the
voice's operator mask, a hold, key-off and a release tail.
"""
from __future__ import annotations

from array import array
from pathlib import Path
import subprocess
import tempfile

CLOCK = 3_579_545
KEY_CODES = 0x0707            # driver 2.00: key code for note n at [n - 1]
NOTE_CAP = 0x61


def key_code(z80, note):
    if not 1 <= note <= NOTE_CAP:
        raise ValueError(f"note {note:#x} outside the driver's range")
    return z80[KEY_CODES + note - 1]


def midi_note(z80, note):
    """The equal-tempered MIDI note a driver note sounds (A4 = key code 0x4A
    = 440 Hz at the 3.579545 MHz clock)."""
    kc = key_code(z80, note)
    octave, code = kc >> 4, kc & 15
    semitone = [1, 2, 3, None, 4, 5, 6, None, 7, 8, 9, None, 10, 11, 12, None][code]
    return 12 * (octave + 1) + semitone


def script(raw, kc, hold, release, channel=0, kf=0):
    """Register writes and render steps for one note of a voice record."""
    lines = []

    def w(reg, value):
        lines.append(f"w {reg:02x} {value & 0xFF:02x}")
    if raw[1]:
        w(0x1B, raw[2] & 0x7F)
        w(0x18, raw[3])
        w(0x19, raw[4] | 0x80)
        w(0x19, raw[5])
        w(0x38 + channel, raw[6])
    else:
        w(0x38 + channel, 0)
    w(0x20 + channel, 0xC0 | raw[7])
    for op in range(4):
        w(0x40 + channel + 8 * op, raw[8 + op])
        w(0x60 + channel + 8 * op, raw[12 + op])
    for block in range(4):
        for op in range(4):
            w(0x80 + 0x20 * block + channel + 8 * op, raw[16 + 4 * block + op])
    w(0x28 + channel, kc)
    w(0x30 + channel, kf)
    w(0x08, raw[0] | channel)
    lines.append(f"s {hold}")
    w(0x08, channel)
    lines.append(f"s {release}")
    return "\n".join(lines) + "\n"


def render(binary, text):
    """Run the renderer; returns (sample rate, left channel samples)."""
    with tempfile.TemporaryDirectory() as tmp:
        script_path, out_path = Path(tmp) / "script.txt", Path(tmp) / "out.pcm"
        script_path.write_text(text)
        result = subprocess.run([str(binary), str(CLOCK), str(script_path), str(out_path)],
                                capture_output=True, text=True, check=True)
        pcm = array("h", out_path.read_bytes())
    return int(result.stdout.strip()), list(pcm[0::2])
