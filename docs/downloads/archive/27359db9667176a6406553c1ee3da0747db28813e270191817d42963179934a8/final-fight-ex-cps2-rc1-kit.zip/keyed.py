#!/usr/bin/env python3
"""Keyed items: what the public kit ships only as tied to the user's own data (KIT.md).

22 October 2026: "For the keyed data, I want the mappings to be tied per datum to corresponding
data". An item is its bytes XORed with a keystream expanded from its counterpart (the piece of the
user's own data it corresponds to) and its own name, to its length; the kit checks each rebuilt item
against its SHA-256. A document lists the items, each with its counterpart's source, offset and length
and its span of the payload:

    {"schema": 1, "items": [{"name", "counterpart": {"source", "offset", "length"}, "offset",
                             "length", "sha256"}]}

The generator seals items (``Sealer``); the kit opens them (``unseal``) with a resolver that returns
the bytes a counterpart's source names. Both sides are this module.

    keyed.py --self-test
"""
from __future__ import annotations

# BEGIN ARCADE PYTHON BOOTSTRAP
import sys as _arcade_sys
from pathlib import Path as _ArcadePath
_arcade_sys.path.insert(0, str(_ArcadePath(__file__).resolve().parents[0]))
from kit_python import bootstrap as _arcade_bootstrap
_arcade_bootstrap()
# END ARCADE PYTHON BOOTSTRAP

import argparse
import hashlib

KEY_PREFIX = b"ffex2 keyed\0"


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def keystream(name: str, counterpart: bytes, length: int) -> bytes:
    """An item's key, expanded from its counterpart's bytes and its own name."""
    return hashlib.shake_256(KEY_PREFIX + name.encode() + b"\0" + counterpart).digest(length)


def xor(a: bytes, b: bytes) -> bytes:
    return (int.from_bytes(a, "big") ^ int.from_bytes(b, "big")).to_bytes(len(a), "big")


class Sealer:
    """Collects items and their counterparts into a document and its payload."""

    def __init__(self):
        self.items, self.payload, self.names = [], bytearray(), set()

    def add(self, name: str, data: bytes, source: str, offset: int, counterpart: bytes):
        if name in self.names:
            raise ValueError(f"keyed item {name} twice")
        if not counterpart:
            raise ValueError(f"keyed item {name} has an empty counterpart")
        self.names.add(name)
        self.items.append({"name": name, "counterpart": {"source": source, "offset": offset,
                                                         "length": len(counterpart)},
                           "offset": len(self.payload), "length": len(data), "sha256": sha256(data)})
        self.payload += xor(data, keystream(name, counterpart, len(data)))

    def document(self):
        return {"schema": 1, "items": self.items}, bytes(self.payload)


def unseal(doc: dict, payload: bytes, resolve) -> dict[str, bytes]:
    """{name: bytes} for every item; resolve(source) returns the bytes a counterpart's source names."""
    if doc.get("schema") != 1:
        raise ValueError("keyed data: unknown schema")
    sources, out = {}, {}
    for item in doc["items"]:
        cp = item["counterpart"]
        if cp["source"] not in sources:
            sources[cp["source"]] = resolve(cp["source"])
        whole = sources[cp["source"]]
        counterpart = bytes(whole[cp["offset"]:cp["offset"] + cp["length"]])
        if len(counterpart) != cp["length"]:
            raise ValueError(f"keyed item {item['name']}: {cp['source']} is shorter than its counterpart")
        data = xor(payload[item["offset"]:item["offset"] + item["length"]],
                   keystream(item["name"], counterpart, item["length"]))
        if sha256(data) != item["sha256"]:
            raise ValueError(f"keyed item {item['name']}: your {cp['source']} at {cp['offset']:#x} is not "
                             "the data it was keyed to")
        out[item["name"]] = data
    return out


def self_test():
    own = {"a": bytes(range(64)), "b": b"\x10" * 8}
    sealer = Sealer()
    sealer.add("one", b"hello", "a", 4, own["a"][4:12])
    sealer.add("two", b"\x00" * 20, "b", 0, own["b"])
    doc, payload = sealer.document()
    assert payload[:5] != b"hello" and len(payload) == 25
    assert unseal(doc, payload, own.__getitem__) == {"one": b"hello", "two": b"\x00" * 20}
    try:
        unseal(doc, payload, {"a": bytes(64), "b": own["b"]}.__getitem__)
        raise AssertionError("a wrong counterpart opened")
    except ValueError as error:
        assert "one" in str(error)
    try:
        sealer.add("one", b"x", "a", 0, b"y")
        raise AssertionError("a repeated name sealed")
    except ValueError:
        pass
    assert keystream("n", b"c", 4) == hashlib.shake_256(b"ffex2 keyed\0n\0c").digest(4)
    print("self-test passed")


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args(argv)
    if args.self_test:
        self_test()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
