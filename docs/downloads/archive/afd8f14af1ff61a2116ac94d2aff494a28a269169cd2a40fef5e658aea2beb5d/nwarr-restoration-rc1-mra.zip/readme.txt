Night Warriors: Darkstalkers' Revenge · English restoration
===========================================================

Version:  rc1 (2026-10-06)
Target:   MAME set 'vhuntj' (Vampire Hunter: Darkstalkers' Revenge (Japan 950316))
Hardware: Capcom CPS-2
Patch by: Steve Gordon (https://x.com/strygo)
Website:  https://arcadepatches.com/nwarr-restoration/

ABOUT THIS PROJECT

Night Warriors left a lot of Vampire Hunter behind. Every export version skips
the epilogue that follows each ending. The endings were rewritten, with
different page counts on most routes, and each fighter gets a handful of fixed
win quotes where the Japanese game picks from a much larger pool.

The English Restoration brings back all 14 epilogues, rebuilds the 112 ending
pages with the Japanese scenes and pacing, and restores the full pool of 323
win quotes, all translated from the Japanese.

Sasquatch’s Japanese victory poses and their sounds are back, along with
Morrigan’s and Donovan’s extra win sounds.

It keeps the Night Warriors title, the Western character names and the English
operator menu with the USA settings. It runs in MAME and HBMAME and on MiSTer.

This is a release candidate.

WHAT'S CHANGED

  - All 14 epilogues after the endings, in English; every export version
    skipped them
  - The 112 Japanese ending pages in English, with the Japanese scenes and
    pacing
  - The full pool of 323 Japanese win quotes in English, picked as in Japan
  - Sasquatch’s Japanese victory poses and sounds, and Morrigan’s and
    Donovan’s extra win sounds
  - The Night Warriors title, Western character names and the USA operator
    menu

MISTER SETUP

1. Copy the _Arcade/ folder from this download to the root of your
   MiSTer SD card (the MRA lands in _Arcade/_Arcade Patches/_Restorations/), or copy
   "Night Warriors Darkstalkers' Revenge (USA) [English Restoration].mra" anywhere under _Arcade/.
2. Have the stock, unmodified romset at games/mame/vhuntj.zip
   (split sets also need the parent and QSound ZIPs named in the MRA).
3. You need Jotego's jtcps2 core; the standard MiSTer downloader /
   update_all installs it automatically.

The MRA references your original romset and applies the restoration in
memory while the game loads. Nothing on your SD card is modified. The
restoration keeps its own settings and saves under the name
'nwarrru'.

LEGAL

This is a free, unofficial fan patch. It is not affiliated with or endorsed
by Capcom. All game titles, characters, and artwork remain the property of
their respective owners. You must own the game to use this patch. Do not
sell this patch or distribute it applied to a ROM image.
