Vampire Savior · English restoration
====================================

Version:  rc1 (2026-09-22)
Target:   MAME set 'vsavj' (Vampire Savior: The Lord of Vampire (Japan 970519))
Hardware: Capcom CPS-2
Patch by: Steve Gordon (https://x.com/strygo)
Website:  https://arcadepatches.com/vsav-restoration/

ABOUT THIS PROJECT

Vampire Savior wasn't the same game everywhere. The export versions recolored
Jedah's blood purple and Forever Torment's green, cut a few gory touches
entirely, and defaulted to sweat instead of blood. Their English script
dropped fourteen win quotes and 47 ending pages. Even the damage values
differ: in places the export versions hit a little harder.

The English Restoration is the Japanese game, in English. The blood is red
again, everywhere it was in Japan. All 241 win quotes and every ending page
are here, translated from the Japanese: where Capcom's English said the same
thing it's kept, and everything else is newly translated, including the pages
the export dropped. The fights run on Japan's damage values and Japan's
computer difficulty.

Out of the box it's set up like a Japanese cabinet: blood on, Auto guard
selectable at the select screen, one coin one credit. The operator menu and
the Western character names stay as the US version has them, and Lord Raptor's
name finally reads L.Raptor instead of L.Rapter.

It's a USA build that runs in MAME, HBMAME and on MiSTer. The Japanese version
already has everything above, so there's no Japan build for now.

This is a release candidate.

WHAT'S CHANGED

  - All 241 win quotes from the Japanese game, in English, including the
    fourteen the US version dropped
  - Every ending page from the Japanese game, in English, including the 47 the
    US version dropped, with Japan's page timing
  - The dialogue before the final battle with Jedah, checked line by line
    against the Japanese and revised where Capcom's English strayed
  - Red blood: Jedah's attacks (purple in the US version), Forever Torment's
    guillotine and well (green), and hit blood on by default
  - Lord Raptor's blood spray in his bite throw, and the paper notice in
    Bishamon's Togakubi Sarashi finish, both cut from the export versions
  - Japan's damage values and computer difficulty
  - Set up like a Japanese cabinet: blood on, Auto guard selectable, one coin
    one credit
  - Lord Raptor's name spelled right

HOW TO APPLY (recommended)

    python3 apply.py /path/to/vsavj.zip --out-dir out

This checks every file against the original, applies the patches, checks
the result, and writes everything you need for each platform:

  MAME / original hardware: out/mame/vsavj.zip
  HBMAME:                   out/hbmame/vsavru.zip
  MiSTer:                   out/mister/_Arcade/_Arcade Patches/_Restorations/Vampire Savior The Lord of Vampire (USA) [English Restoration].mra

Merged, split and complete sets work, including nested or renamed ROMs.
Use --rompath DIR (repeatable) to search a collection instead of naming the
zip, and --check to check inputs before building. ZIPs and extracted folders
need no extra software; 7z archives need 7-Zip. QSound can stay in your
emulator's ROM path; valid firmware already in a source set is kept in
complete outputs.

MAME: put vsavj.zip from out/mame/ ahead of the stock set in your MAME
rompath.
MAME's game menu won't start a set with patched ROMs, so start it from the
command line: mame vsavj. MAME shows checksum warnings for the patched
ROMs; that's expected and the game runs normally.
To start it from a menu, use the HBMAME build.

HBMAME: this restoration is an official HBMAME set (vsavru),
so full HBMAME collections may already carry it.
Put the zip in HBMAME's roms/ folder next to your stock vsavj.zip.
It loads with no checksum warnings.

MiSTer: copy the _Arcade folder from out/mister/ to the root of your SD card
and keep the stock, unmodified romset at games/mame/vsavj.zip (split MAME
sets also need qsound.zip). The MRA applies the restoration in memory as the
game loads, so nothing on the card is modified. You need Jotego's jtcps2
core, which update_all installs. The MRAs are also a separate download.

HOW TO APPLY (any IPS patcher)

Extract vsavj.zip, apply each file in ips/ to the ROM file of the
same name (Flips, Lunar IPS, or any IPS tool), then re-zip everything
as vsavj.zip.

CHANGED FILES

    vm3.13m  (4.0 MB)  CRC32 fd8a11eb -> 25b89bee
    vm3.15m  (4.0 MB)  CRC32 dd1e7d4e -> 7c4ed97c
    vm3.17m  (4.0 MB)  CRC32 6b89445e -> 05295327
    vm3.19m  (4.0 MB)  CRC32 3830fdc7 -> e90b3fee
    vm3j.03d  (512 KB)  CRC32 2a2e74a4 -> 87184d16
    vm3j.04d  (512 KB)  CRC32 1c2427bc -> fc2d5b8e
    vm3j.07b  (512 KB)  CRC32 a38aaae7 -> b3cbf9a8

All other files in the set are unmodified.

LEGAL

This is a free, unofficial fan patch. It is not affiliated with or endorsed
by Capcom. All game titles, characters, and artwork remain the property of
their respective owners. You must own the game to use this patch. Do not
sell this patch or distribute it applied to a ROM image.
