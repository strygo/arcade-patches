# CPS+ — MiSTer installation

Run the pack builder first (see `README.txt`), then copy everything inside
`out/mister/` to the root of your MiSTer SD card (`/media/fat/`), merging
with what is already there.

```
out/mister/
  _Arcade/
    _CPS+/               MRAs: US/World editions at the root, regional
                         variants under _Japan/ _Asia/ _Europe/.  The
                         LEADING UNDERSCORE is required for MiSTer to show
                         the folder as an arcade group.
    cores/
      jtcps1-cpsplus.rbf       CPS-1.0 core
      jtcps15-cpsplus.rbf      CPS-1.5 core
      jtcps2-cpsplus.rbf       CPS-2 core
  games/
    CPS+/                the audio packs you built (`<pack>.zip`)
```

Only the MRAs whose packs you built are placed here, so everything in the
folder will load. The rest stay in `builder/mras/` and appear the next time
you run the builder with their pack built.

Keep the RBF filenames as they are. The MRAs name their core, and a renamed
core stops resolving.

Your arcade ROM zips go where they always do (`games/mame/`,
`games/hbmame/`). The MRAs reference them by standard MAME names.

## Verifying a pack is active

Load a CPS+ MRA and check the core's OSD. The CPS+ audio section shows the
loaded pack.
