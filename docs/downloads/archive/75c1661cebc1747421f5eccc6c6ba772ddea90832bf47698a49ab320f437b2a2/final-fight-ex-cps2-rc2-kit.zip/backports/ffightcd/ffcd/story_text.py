"""Shared Final Fight USA spelling corrections, approved on 15 October 2026.

Used by CPS1 EX and the CPS2 USA edition. Records retain their byte lengths,
glyph counts, delay, mode and segment headers. Trailing typed spaces absorb
word-length changes, preserving the cutscene timeline and table offsets.
The HUD correction applies to both regions. No translation changes are made.
"""
from __future__ import annotations

# BEGIN ARCADE PYTHON BOOTSTRAP
import sys as _arcade_sys
from pathlib import Path as _ArcadePath
_arcade_sys.path.insert(0, str(_ArcadePath(__file__).resolve().parents[3]))
from kit_python import bootstrap as _arcade_bootstrap
_arcade_bootstrap()
# END ARCADE PYTHON BOOTSTRAP

import struct

GROUP1 = 0x68566
HUD_FIXES = ((0x05BCCE, "4441", "4445", "HUD name table: GRANADE spelled GRENADE"),)

ENGLISH = {0x010: " ", 0x5AA: ".", 0x5E8: ",", 0x5E5: "'", 0x5EC: "?", 0x5ED: "!", 0x02D: "-",
           0x5E6: '"', 0x5E7: '"', 0x5E9: ":", 0x5EA: "(", 0x5EB: ")"}
ENGLISH.update({0x5AB + i: c for i, c in enumerate("abcde")})
ENGLISH.update({0x5C0 + i: c for i, c in enumerate("fghijklmnopqrstu")})
ENGLISH.update({0x5E0 + i: c for i, c in enumerate("vwxyz")})
ENGLISH.update({0x580 + i: c for i, c in enumerate("ABCDEFGHIJKLMNOP")})
ENGLISH.update({0x5A0 + i: c for i, c in enumerate("QRSTUVWXYZ")})
ENGLISH.update({0x628 + i: c for i, c in enumerate("12345678")})
ENGLISH.update({0x64C: "9", 0x64D: "0"})


def english_text(rec):
    lines = []
    for seg in rec["segments"]:
        lines.append("".join(ENGLISH.get(g, chr(g) if 0x20 <= g < 0x7F else f"[{g:03x}]")
                             for g in seg["glyphs"]).rstrip())
    return [line for line in lines if line]


def word(image, at):
    return struct.unpack_from(">H", image, at)[0]


def large(text):
    glyphs = {c: g for g, c in ENGLISH.items() if c != '"'}
    return [glyphs[c] for c in text]


# group 1 record: [(stock line, fixed line), ...]
TYPOS = {
    0x07: [("Hee hee hee, Mr.Haggar. So pleased", "Hee hee hee, Mr. Haggar. So pleased")],
    0x10: [("your daughter's life can not be", "your daughter's life cannot be")],
    0x11: [("Now of course,you'll need a couple", "Now of course, you'll need a couple")],
    0x14: [("My sweet heart since child hood.", "My sweetheart since childhood.")],
    0x2E: [("of Ninjitsu and attacks", "of Ninjutsu and attacks")],
    0x2F: [("He is a martialarts expert.", "He is a martial arts expert."),
           ("His girl friend, Jessica,", "His girlfriend, Jessica,")],
    0x36: [("we're only half way there.", "we're only halfway there.")],
}
SPACE = 0x010


def parse(image, at):
    """A group 1 record as stored: delay, mode, and each segment's 4-byte
    header (cell, attributes), glyphs and closing word ($FFFF between
    segments, 0 at the end)."""
    out, end = {"delay": image[at], "mode": image[at + 1], "segments": []}, at + 2
    while True:
        head = bytes(image[end:end + 4])
        end += 4
        glyphs = []
        while (g := word(image, end)) and not g & 0x8000:
            glyphs.append(g)
            end += 2
        end += 2
        out["segments"].append({"head": head, "glyphs": glyphs, "close": g})
        if not g:
            out["end"] = end
            return out


def encode(rec):
    return bytes([rec["delay"], rec["mode"]]) + b"".join(
        s["head"] + b"".join(struct.pack(">H", g) for g in s["glyphs"]) + struct.pack(">H", s["close"])
        for s in rec["segments"])


def text(glyphs):
    return english_text({"segments": [{"glyphs": glyphs}]})


def fixed(rec, fixes, index, allow_fixed=False):
    """The record with its lines fixed and its glyph count kept: the last
    segment's trailing spaces absorb the difference."""
    segs = [dict(s, glyphs=list(s["glyphs"])) for s in rec["segments"]]
    count = sum(len(s["glyphs"]) for s in segs)
    for old, new in fixes:
        hits = [s for s in segs if text(s["glyphs"]) == [old]]
        if not hits and allow_fixed and sum(text(s["glyphs"]) == [new] for s in segs) == 1:
            continue                        # CPS1 already corrected sweetheart/childhood
        if len(hits) != 1:
            raise ValueError(f"record {index:#04x}: no single line {old!r}")
        seg = hits[0]
        if large(old) != seg["glyphs"][:len(old)]:
            raise ValueError(f"record {index:#04x}: {old!r} is not in the large font")
        seg["glyphs"] = large(new) + seg["glyphs"][len(old):]
    last = segs[-1]["glyphs"]
    excess = sum(len(s["glyphs"]) for s in segs) - count
    if excess > 0:
        if len(last) < excess or any(g != SPACE for g in last[len(last) - excess:]):
            raise ValueError(f"record {index:#04x}: no trailing spaces to absorb {excess} glyphs")
        del last[len(last) - excess:]
    else:
        last.extend([SPACE] * -excess)
    return {**rec, "segments": segs}


def patches(program, allow_fixed=False):
    """(patch entries, receipt) for the USA program."""
    image = bytes(program)
    entries, rows = [], []
    for index, fixes in sorted(TYPOS.items()):
        start = GROUP1 + word(image, GROUP1 + 2 * index)
        rec = parse(image, start)
        old = image[start:rec["end"]]
        if encode(rec) != old:
            raise ValueError(f"record {index:#04x} does not re-encode to its stock bytes")
        new = encode(fixed(rec, fixes, index, allow_fixed=allow_fixed))
        if len(new) != len(old):
            raise ValueError(f"record {index:#04x} changes length")
        entries.append((start, old.hex(), new.hex(),
                        f"USA story text: {'; '.join(f'{o!r} -> {n!r}' for o, n in fixes)} (usa_text.py)"))
        rows.append({"record": f"{0x100 + index:#05x}", "address": f"{start:#x}", "bytes": len(old),
                     "fixes": [{"stock": o, "fixed": n} for o, n in fixes]})
    return entries, {"records": rows, "approved": "15 October: the USA version's typos fixed"}


def self_test():
    head1, head2 = struct.pack(">HH", 17 * 0x80 + 20 * 4, 0x2F), struct.pack(">HH", 17 * 0x80 + 23 * 4, 0x0F)
    rec = {"delay": 2, "mode": 2, "segments": [
        {"head": head1, "glyphs": large("Mr.Haggar so"), "close": 0xFFFF},
        {"head": head2, "glyphs": large("end.") + [SPACE] * 3, "close": 0}]}
    blob = encode(rec)
    image = bytearray(0x100) + blob
    assert encode(parse(image, 0x100)) == blob and parse(image, 0x100)["end"] == 0x100 + len(blob)
    longer = fixed(parse(image, 0x100), [("Mr.Haggar so", "Mr. Haggar so")], 0)
    assert [len(s["glyphs"]) for s in longer["segments"]] == [13, 6] and len(encode(longer)) == len(blob)
    assert encode(longer)[2:6] == head1          # the attributes' flag bits stay
    assert encode(fixed(longer, [("Mr.Haggar so", "Mr. Haggar so")], 0, allow_fixed=True)) == encode(longer)
    try:
        fixed(longer, [("Mr.Haggar so", "Mr. Haggar so")], 0)
    except ValueError:
        pass
    else:
        raise AssertionError("stock-only mode accepted a previously changed record")
    shorter = fixed(parse(image, 0x100), [("Mr.Haggar so", "Haggar so")], 0)
    assert [len(s["glyphs"]) for s in shorter["segments"]] == [9, 10]
    try:
        fixed(parse(image, 0x100), [("Mr.Haggar so", "Mr. Haggar so, Mike Haggar!")], 0)
    except ValueError:
        pass
    else:
        raise AssertionError("a fix longer than the trailing spaces was accepted")
    print("self-test passed")


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--self-test", action="store_true", required=True)
    parser.parse_args()
    self_test()
