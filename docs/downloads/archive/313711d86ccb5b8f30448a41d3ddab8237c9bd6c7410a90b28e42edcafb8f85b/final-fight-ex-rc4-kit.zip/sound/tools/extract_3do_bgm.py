#!/usr/bin/env python3
"""Extract the /BGM/*.BGM music from a 3DO Capcom disc to 16-bit WAV.

Each BGM file is an AIFC container (COMM, SSND, and empty MARK/INST scaffolding)
holding 2:1 SDX2 audio.  The disc is read through its Opera file system from a
cue sheet / raw image / CHD, then every file is decoded with `sdx2.decode`.

    python3 tools/extract_3do_bgm.py <disc.chd|.cue|.bin> <outdir>
    python3 tools/extract_3do_bgm.py --self-test

Writes <outdir>/<NAME>.wav and <outdir>/catalog.json (name, frames, rate,
channels, sha256 of the decoded PCM, MARK/INST loop chunks as found).
"""
from __future__ import annotations

import hashlib
import json
import struct
import sys
import wave
from dataclasses import dataclass
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import sdx2                                    # noqa: E402
from opera_fs import OperaFS                    # noqa: E402


@dataclass
class Aifc:
    channels: int
    frames: int
    bits: int
    rate: float
    compression: bytes
    data: bytes
    markers: int
    sustain_loop: tuple[int, int, int] | None


def _extended(b: bytes) -> float:
    """IEEE 80-bit extended -> float (AIFF sample rate)."""
    exp = struct.unpack(">H", b[:2])[0]
    mant = int.from_bytes(b[2:10], "big")
    sign = -1.0 if exp & 0x8000 else 1.0
    exp &= 0x7FFF
    if exp == 0 and mant == 0:
        return 0.0
    return sign * mant * 2.0 ** (exp - 16383 - 63)


def parse_aifc(blob: bytes) -> Aifc:
    if blob[:4] != b"FORM" or blob[8:12] not in (b"AIFC", b"AIFF"):
        raise ValueError("not an AIFF/AIFC file")
    end = min(len(blob), 8 + struct.unpack(">I", blob[4:8])[0])
    pos, comm, ssnd, markers, loop = 12, None, None, 0, None
    while pos + 8 <= end:
        cid = blob[pos:pos + 4]
        size = struct.unpack(">I", blob[pos + 4:pos + 8])[0]
        body = blob[pos + 8:pos + 8 + size]
        if cid == b"COMM":
            ch, frames, bits = struct.unpack(">hIh", body[:8])
            comm = (ch, frames, bits, _extended(body[8:18]),
                    body[18:22] if len(body) >= 22 else b"NONE")
        elif cid == b"SSND":
            offset = struct.unpack(">I", body[:4])[0]
            ssnd = body[8 + offset:]
        elif cid == b"MARK":
            markers = struct.unpack(">H", body[:2])[0]
        elif cid == b"INST":
            # baseNote, detune, lowNote, highNote, lowVel, highVel, gain (8 B),
            # sustainLoop {playMode, beginMark, endMark}, releaseLoop {...}
            mode, begin, endm = struct.unpack(">hhh", body[8:14])
            loop = (mode, begin, endm) if mode else None
        pos += 8 + size + (size & 1)
    if comm is None or ssnd is None:
        raise ValueError("AIFC without COMM or SSND")
    return Aifc(comm[0], comm[1], comm[2], comm[3], comm[4], ssnd, markers, loop)


def decode_aifc(a: Aifc) -> np.ndarray:
    """int16 samples (frames, channels)."""
    if a.compression == b"SDX2":
        pcm = sdx2.decode(a.data, a.channels)
    elif a.compression in (b"NONE", b"twos"):
        pcm = np.frombuffer(a.data[:len(a.data) // 2 * 2], ">i2").astype("<i2")
        pcm = pcm.reshape(-1, a.channels)
    else:
        raise ValueError(f"unhandled AIFC compression {a.compression!r}")
    return pcm[:a.frames] if a.frames else pcm


def write_wav(path: Path, pcm: np.ndarray, rate: int) -> None:
    with wave.open(str(path), "wb") as w:
        w.setnchannels(pcm.shape[1])
        w.setsampwidth(2)
        w.setframerate(rate)
        w.writeframes(pcm.astype("<i2").tobytes())


def read_bgm(fs: OperaFS):
    """Yield (name, Aifc) for every /BGM/ file, in name order."""
    for e in sorted((e for e in fs.entries()
                     if not e.is_dir and e.path.upper().startswith("/BGM/")),
                    key=lambda e: e.path):
        yield e.path.rsplit("/", 1)[1], parse_aifc(fs.read(e))


def open_disc(path: Path | str) -> OperaFS:
    p = Path(path)
    if p.suffix.lower() == ".chd":
        from pack.sources import cd_chd_to_cue
        p = cd_chd_to_cue(p)
    return OperaFS(p)


def extract(disc: Path | str, outdir: Path | str) -> list[dict]:
    out = Path(outdir)
    out.mkdir(parents=True, exist_ok=True)
    fs = open_disc(disc)
    cat = []
    for name, a in read_bgm(fs):
        pcm = decode_aifc(a)
        stem = name.rsplit(".", 1)[0]
        write_wav(out / f"{stem}.wav", pcm, int(round(a.rate)))
        cat.append({"name": name, "channels": a.channels, "frames": int(len(pcm)),
                    "rate": int(round(a.rate)), "compression": a.compression.decode(),
                    "markers": a.markers, "sustain_loop": a.sustain_loop,
                    "pcm_sha256": hashlib.sha256(pcm.astype("<i2").tobytes()).hexdigest()})
    (out / "catalog.json").write_text(json.dumps(cat, indent=1) + "\n")
    return cat


def _self_test() -> None:
    import tempfile
    # a hand-built SDX2 AIFC: 2 channels, 4 frames
    raw = bytes(np.array([4, 6, 3, 5, 3, 5, 3, 5], dtype=np.int8))
    comm = (struct.pack(">hIh", 2, 4, 16) + b"\x40\x0e\xac\x44" + bytes(6)
            + b"SDX2" + b"\x00\x00")             # compression name: empty pstring
    body = (b"AIFC" + b"COMM" + struct.pack(">I", len(comm)) + comm
            + b"SSND" + struct.pack(">I", 8 + len(raw)) + bytes(8) + raw)
    blob = b"FORM" + struct.pack(">I", len(body)) + body
    a = parse_aifc(blob)
    assert (a.channels, a.frames, a.bits, a.rate, a.compression) == (2, 4, 16, 44100.0, b"SDX2")
    assert a.markers == 0 and a.sustain_loop is None
    pcm = decode_aifc(a)
    # L: 32, 50, 68, 86   R: 72, 122, 172, 222
    assert pcm.tolist() == [[32, 72], [50, 122], [68, 172], [86, 222]], pcm.tolist()
    with tempfile.TemporaryDirectory() as d:
        write_wav(Path(d) / "t.wav", pcm, 44100)
        with wave.open(str(Path(d) / "t.wav")) as w:
            assert (w.getnchannels(), w.getframerate(), w.getnframes()) == (2, 44100, 4)
    print("extract_3do_bgm self-test OK")


if __name__ == "__main__":
    if "--self-test" in sys.argv:
        _self_test()
    elif len(sys.argv) == 3:
        for row in extract(sys.argv[1], sys.argv[2]):
            print(f"{row['name']}  {row['frames'] / row['rate']:7.2f}s  {row['pcm_sha256'][:12]}")
    else:
        print(__doc__)
