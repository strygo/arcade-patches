"""Public pack-side interface to the bundled media-tool runtime."""
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]/'tools'))
from ffmpeg_runtime import Executable, add_arguments, configure, resolve


def ffmpeg_exe():
    return resolve('ffmpeg')


def ffprobe_exe():
    return resolve('ffprobe')
