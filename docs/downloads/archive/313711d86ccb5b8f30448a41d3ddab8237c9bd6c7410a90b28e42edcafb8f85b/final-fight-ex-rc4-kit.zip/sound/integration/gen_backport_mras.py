#!/usr/bin/env python3
"""Generate the Final Fight CD-cutscene backport MRAs (Stage 5 delivery).

The backport sets are hbmame-layout zips in games/hbmame (ffightus01 /
ffightjs01): 2 MB program (the +1 MB cutscene script/table ROM at 0x100000)
and a 6 MB gfx region (stock 2 MB + 4 MB of converted Sega CD cutscene art).
The vendored bases under mra/base_backport/ carry the grown layout:

  * region pointers for the 2 MB maincpu (audiocpu 0x200000, oki 0x210000,
    gfx 0x250000 -- header bytes 0-5);
  * bank 0's gfx mask widened 0x3 -> 0xF (header byte 37 F3 -> FF).  Read off
    the RTL: jtcps1's compiled ffight block (mappers.inc 6'h1e) routes every
    SCROLL2 code to bank 0 with no upper bound and hardwires banks 1-3 to
    zero, so the whole 6 MB rides bank 0 and only its mask nibble widens.
    The 4 MB-era recipe (F3 -> F7) would fold the 0x400000+ tiles -- exactly
    where the c17-c23 growth lives -- back onto stock art.  Only SCROLL2 can
    address the appended region on this core; the backport's validation
    suite asserts that closure on the ROM side.
  * each part row named and CRC'd from the deployed hbmame sets (re-pinned
    2026-08-04), so -verifyroms-style part matching works.

Each MRA embeds ITS OWN region's arrange pack -- ffight_arrange for the US
set, ffight_arrange_jp for the JP set.  The voiced cutscene rows are
region-split (0x70/0x71 live only in the US pack, 0x72/0x73 only in the JP
pack); pointing the JP set at the US pack would fail open to arcade audio on
every cutscene cue.

Usage:
  python3 cpsplus/integration/gen_backport_mras.py --hbmame <dir> [--dist]
"""
from __future__ import annotations

import argparse
from contextlib import contextmanager
import shutil
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ffight_screen_patch import screen_patches, verify_sites  # noqa: E402
from embed_pack_mra import (embed, measure_rom_len_files,  # noqa: E402
                            repin_crcs)
import mra_meta  # noqa: E402
import demo_sound  # noqa: E402

REPO = Path(__file__).resolve().parents[2]
BASE = REPO / "cpsplus" / "mra" / "base_backport"
OUT = REPO / "cpsplus" / "mra" / "CPS+"
PACKS = REPO / "cpsplus" / "packs"
DIST = REPO / "cpsplus" / "dist" / "mister_sd" / "_Arcade" / "_Arcade Patches" / "_Arrangements" / "_CPS+"

# The backport runs in two configurations. This shared generator owns the
# CPS+ flavor in both the CPS+ kit and the standalone Final Fight EX kit:
#   backport ROM + CPS+ core + pack  -> "Final Fight EX (Arrange)" <- here
#   backport ROM + stock core        -> "Final Fight EX"           <- ffightcd kit
# The stock-audio flavour carries no pack; the backport kit authors it from
# the same vendored bases.

# --- mapper guard -------------------------------------------------------------
# The backport draws OBJ sprites (letterbox bars, the Guy/Cody walker cels,
# the farewell sprite patches) with tile codes >= 0x8000, deep in the appended
# art.  jtcps1 selects a per-game bank-select block by MRA header byte 34;
# ffight's own block (0x1E) upper-bounds OBJ at code 0x21FF and the
# obj_line_table SKIPS an unmapped sprite outright -- so under 0x1E those
# sprites do not draw at all (no letterbox, vanishing walkers, the heel/hip
# patches missing), a defect HBMAME's flat control blob cannot show
# (VALIDATION.md, the SCROLL2-only closure row).  The header must therefore
# name the unrestricted block, 0x20 (bank 0, no bounds, offsets 0) -- the
# closure check the docs call for.
MAPPER_FLAT = (0x20, 0x00, 0x00)


@contextmanager
def _unz(zip_path: Path):
    """Temporary ROM view for stock-site verification, removed after use."""
    import tempfile
    import zipfile
    with tempfile.TemporaryDirectory(prefix="mraverify_") as tmp:
        with zipfile.ZipFile(zip_path) as z:
            z.extractall(tmp)
        yield Path(tmp)


def assert_flat_mapper(mra_text: str, name: str) -> None:
    import re as _re
    m = _re.search(r'<part>\s*((?:[0-9A-Fa-f]{2}\s+)+)</part>', mra_text)
    h = bytes.fromhex(_re.sub(r'\s+', '', m.group(1)))
    got = (h[34], h[35], h[36])
    if got != MAPPER_FLAT:
        raise SystemExit(
            f"{name}: header bytes 34-36 = {got[0]:02X} {got[1]:02X} {got[2]:02X}; "
            f"the backport needs jtcps1's unrestricted mapper 20 00 00 -- under "
            f"ffight's own block (1E) every OBJ code >= 0x2200 is unmapped and "
            f"the core skips the sprite (letterbox, walker cels, sprite patches)")

# (region subdir, base mra, pack stem, display name).  Region "" is the kit
# root (US/World); named regions go in their own group, matching how the
# regional and Gold generators lay out the tree -- canonical "Japan", dist
# "_Japan" (MiSTer wants the underscore).
JOBS = [
    ("", "ffightus01.mra", "ffight_arrange",
     "Final Fight EX (Arrange)"),
    ("Japan", "ffightjs01.mra", "ffight_arrange_jp",
     "Final Fight EX (Arrange, Japan)"),
]



CARD_ROOT = Path("_Arcade/_Arcade Patches/_Arrangements/_CPS+")


def generate(hbmame: Path, packs: Path, output: Path, *, base_dir: Path = BASE,
             regions=("us", "jp")) -> list[dict]:
    """The canonical launchers, also used by the standalone Final Fight EX kit.

    All inputs and outputs are explicit; no installed pack or ROM fallback.
    Returned destinations preserve the CPS+ kit's public menu layout.
    """
    if not regions or set(regions) - {"us", "jp"}:
        raise ValueError("select us and/or jp")
    hbmame, packs, output, base_dir = map(Path, (hbmame, packs, output, base_dir))
    results = []
    for group, base, pack, name in JOBS:
        short = "jp" if group else "us"
        if short not in regions:
            continue
        region = group or "USA"
        name = mra_meta.format_name(name, region)
        base_p = base_dir / base
        assert_flat_mapper(base_p.read_text(), base)
        pack_p = packs / f"{pack}.cpk"
        if not pack_p.exists():
            raise SystemExit(f"pack not built: {pack_p}")
        root = ET.parse(base_p).getroot()
        rom = next(r for r in root.findall("rom") if r.get("index") == "0")
        body, unresolved = measure_rom_len_files(rom, [hbmame])
        if unresolved:
            raise SystemExit(f"{base}: cannot measure {unresolved[:4]} -- "
                             f"is the set in {hbmame}?")
        setname = root.findtext("setname")
        # The CD-cutscene sets are where the round-6 overrun actually bites:
        # the voiced ending starts the instant the clear screen blacks out, so
        # an over-long fanfare is cut mid-note rather than merely hanging over.
        extra = screen_patches(pack_p) if pack.startswith("ffight") else []
        if extra:
            # the set zip is in hand here, so PROVE the patch offsets land on
            # the stock blink counts before shipping a ROM patch
            with _unz(hbmame / f"{setname}.zip") as extracted:
                verify_sites(str(base_p), extracted)
        tree, info = embed(str(base_p), pack_p.stat().st_size,
                           f"{pack}.cpk", body,
                           pack_zip=f"/CPS+/{pack}.zip",
                           rom_zip=f"/hbmame/{setname}.zip",
                           display_name=name, region=region,
                           rbf="jtcps1-cpsplus",
                           extra_patches=extra)
        # The base's CRCs describe whichever backport build it was captured
        # from; this set is rebuilt often.  Same guard the Gold tier carries.
        moved = repin_crcs(tree, hbmame / f"{setname}.zip")
        out = (output / group / f"{name}.mra") if group else output / f"{name}.mra"
        out.parent.mkdir(parents=True, exist_ok=True)
        demo_sound.enable(tree.getroot())
        tree.write(out, encoding="unicode", xml_declaration=False)
        print(f"  {out.relative_to(output)}: rom 0x{body:06x}, "
              f"pack {info['pack_len']} B, pack @0x{info['pack_off']:x} "
              f"= {info['units']} kB"
              + (f", {len(moved)} crc repinned: {moved}" if moved else ""))
        dest = CARD_ROOT / (f"_{group}" if group else "") / f"{name}.mra"
        results.append({"region": short, "path": out, "destination": dest})
    return results


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--hbmame", type=Path, required=True)
    ap.add_argument("--packs", type=Path, default=PACKS)
    ap.add_argument("--out", type=Path, default=OUT)
    ap.add_argument("--region", choices=("us", "jp"), action="append")
    ap.add_argument("--dist", action="store_true")
    args = ap.parse_args(argv)
    rows = generate(args.hbmame, args.packs, args.out, regions=args.region or ("us", "jp"))
    if args.dist:
        for row in rows:
            # DIST is the existing card's Arrangements/_CPS+ folder.
            target = DIST / row["destination"].relative_to(CARD_ROOT)
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(row["path"], target)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
