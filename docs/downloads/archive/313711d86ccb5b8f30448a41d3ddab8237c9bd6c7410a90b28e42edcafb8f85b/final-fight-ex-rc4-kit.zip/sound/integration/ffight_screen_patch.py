#!/usr/bin/env python3
"""Size Final Fight's ROUND CLEAR screens to the pack's own jingles.

THE PROBLEM.  The arcade's round-clear jingles are 4.20 s (0x57, rounds 1-5)
and 6.96 s (0x58, round 6), and the screens are cut to them: measured from
frame snapshots, the ROUND6 CLEAR screen is on for 6.79 s and the reunion
cutscene starts the instant it blacks out.  Every arranged pack's version of
those cues is LONGER, so the music is still playing when the screen is gone --
on the CD-cutscene backport the voiced ending then replaces it mid-note, which
cuts the fanfare off abruptly.

THE FIX.  Both screens dwell in a blink loop: an inner counter at $1f(a6)
holds each blink for 6 frames, and an outer counter at $1e(a6) counts the
blinks.  Raising the outer counter lengthens the screen at the SAME blink
rate (the user's call; slowing the blink instead would mean patching $1f in
three places).  One byte per screen:

    68K 0x5CDF9   rounds 1-5   stock 22 blinks (132 frames = 2.21 s)
    68K 0x5CFB3   round 6      stock 27 blinks (162 frames = 2.72 s)

MEASURE THE MUSIC, NOT THE FILE.  Size against where the audio actually STOPS,
not the stored track length: these one-shots carry 1.5-2.5 s of trailing
silence, which needs no screen time.  Sizing tr16 by its 8.40 s file rather
than its 6.00 s of music asked for +30 blinks when +7 was right.

The value is therefore PER PACK -- each MRA embeds its own pack, and the packs
disagree (round 6 wants 67 blinks for the CD arrange, ~32 for the SNES set).
"""
from __future__ import annotations

import array
import math
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from pack.format import PackReader, CODEC_ADX, VERB_PLAY   # noqa: E402
from pack import adxcodec                                   # noqa: E402

FPS = 59.637405
# MEASURED, not read off the code: replaying one captured round-1 clear with
# 22 vs 29 blinks moved everything downstream by 1.41 s = 12.01 frames/blink.
# $1f(a6) reloads with 6, which is what the source reads like, but $1e counts
# down on only ONE of the two alternating sub-states, so a blink is two
# 6-frame halves.  Taking the 6 at face value sized both patches 2x too long.
INNER_FRAMES = 12

# cue -> (68K address of the blink count, stock value, window the stock jingle
#         was cut to).  The 0x57 window is the measured 0x57 -> next-cue gap
#         (324 frames, seen twice in the recorded playthroughs); the 0x58
#         window is the screen itself, measured from snapshots.
# NOTE the two rounds differ STRUCTURALLY, measured from the state tables and
# confirmed on a captured clear:
#   rounds 1-5 wait for the fade at state 0x0A, AFTER the blink.  The fade-out
#     starts on its own schedule (3.29 s into the clear, unchanged by the blink
#     count), so extra blinks CANNOT lengthen the visible screen -- they only
#     lengthen the dark hold that follows it (0.74 s stock).  The window sized
#     here is the 0x57 -> next-cue gap, which IS extended, so the cue stops
#     being clipped; it just costs dark time, so ask for the minimum.
#   round 6 waits for the fade at state 0x00, BEFORE the display, so its
#     screen is already up when the blink runs and extra blinks do lengthen
#     what you see.  (Untested on hardware as of 2026-08-22.)
# 0x58 (round 6) IS NOT SIZED HERE.  Its blink count at 0x5CFB3 was shipped
# briefly and is INERT: replayed from a round-6 clear the screen darkens at
# 7.21 s with the count at 27, 34 and 200 alike, and the fade counter that
# works for rounds 1-5 does not move it either.  Dumping work RAM every 15
# frames across the clear finds no byte or word counting down to that moment,
# so the screen end comes from the script queue rather than a timer -- the same
# system that carries the fade (script 0x88E through the depth at 0xFF808C).
#
# The defect is real and still open: round 6's cue carries 8.15 s of music
# against a 6.79 s screen.  Finding its lever needs the queue traced, not
# another counter guessed at.  Nothing is emitted for it until then.
SITES: dict[int, tuple[int, int, float]] = {}

# ---- round 6: a WORD countdown, not the blink ------------------------------
# The round-6 clear screen is timed by a 16-bit countdown at 0xFF1290, loaded
# with 413 frames (6.93 s) by `move.w #$019D,-$6d70(a5)` at 68K 0x0185BE.  When
# it expires the script calls 0x2530, which enqueues script $89F -- the fade.
#
# This was found by TRACING, after the blink count and the rounds 1-5 fade
# counter were both shown inert here: MAME's tracer, windowed to the ten frames
# around the enqueue, shows `0185CC: subq.w #1,(-$6d70,A5)` running and calling
# through.  Dumping work RAM had missed it because the counter lives at
# 0xFF1290, below the 0xFF8000 object area that was being dumped.
#
# Verified twice.  On a captured clear with the counter forced in RAM: 413 ->
# screen darkens at 7.29 s, 486 -> 8.47 s.  Then END TO END through the real
# shipping path -- ROM byte patched at boot, played to the clear: the script
# loaded the patched value (RAM read back 487 of 488) and the screen darkened
# at 8.47 s against 7.29 s stock, covering tr15's 8.15 s of music.
# The round-6 clear uses the same sizing rule as the fade: extend by exactly how much
# longer this pack's cue is than the arcade's 6.90 s.
R6_SITE, R6_STOCK, ARCADE_0x58 = 0x0185C0, 413, 6.90

# ---- the FADE delay: the right lever for rounds 1-5 ------------------------
# The scene object's countdown at 68K 0x00E919 (stock 80 frames) schedules the
# fade-out.  Delaying it is frame-for-frame linear -- measured on a captured
# round-1 clear: counter 78 -> fade at 3.07 s, 160 -> 4.44 s, 240 -> 5.79 s --
# and unlike the blink it lengthens the VISIBLE screen instead of the dark
# hold that follows.
#
# The site was identified by patching all four `move.b #$50,$1e(a6)` sites to
# distinct values and reading back which one the clear loaded.  It is 0x00E916,
# NOT the 0x00F23E that sits in the same code region as the fade routine and
# that static reading pointed at.
#
# Sizing rule: the arcade lets its 4.20 s jingle run ~1.1 s past the fade, so
# delay by exactly the amount our cue is longer than the arcade's.  A pack
# whose cue is no longer than 4.20 s needs no patch.
FADE_SITE, FADE_STOCK, ARCADE_0x57 = 0x00E919, 80, 4.00
# Callers get 68K ADDRESSES; embed_pack_mra converts to an MRA byte offset
# using the base MRA's own measured header length.

# The instructions that hold the two values, as the stock program (ffightu and
# ffightj alike) has them: "move.w #413,-$6d70(a5)" (its word operand is
# R6_SITE) and "move.b #80,$1e(a6)" (its byte operand is FADE_SITE).  A port
# that keeps Final Fight's program in place (backports/ffightcps2, its EX
# builds) checks them in its own program before patching.  The move.b is one
# of four identical ones (also at 0xC82C, 0xF23E and 0x2172A); the code
# around it (FADE_CONTEXT, "bsr $f40a; bmi $e8c0" before it and "rts" after)
# is this one's alone.
R6_INSTRUCTION = (0x0185BE, bytes.fromhex("3b7c019d9290"))
FADE_INSTRUCTION = (0x00E916, bytes.fromhex("1d7c0050001e"))
FADE_CONTEXT = (0x00E910, bytes.fromhex("61000af86baa1d7c0050001e4e75"))
# The cues each screen's jingle is sized against, by the trigger row that
# plays them: CPS1's packs map Final Fight's command bytes as they are.  A
# pack that maps them elsewhere passes its rows (the CPS2 port's Arrange packs
# map 0x0157 and 0x0158, cpsplus/manifests/ffightcps2_ex_arrange_trigger_map.tsv).
CUE_ROWS = {0x57: 0x57, 0x58: 0x58}


def music_end(rd: PackReader, cmd: int, res: float = 0.05,
              floor_db: float = -12.0) -> float | None:
    """Seconds of MUSICAL CONTENT -- the last point still within 12 dB of peak.

    Not "the last sample above silence".  These cues end with a reverb decay
    that runs 2-4 s below the music, and counting it made tr16 look 6.00 s long
    when its last musical event is at 3.95 s, and tr15 look 10.68 s when it is
    8.15 s.  Sizing screen time against a decay tail asked for seconds of ROM
    timing change that nothing audible needed.  The arcade cues are the control:
    0x58 stops dead at 6.90 s with no decay at all.
    """
    t = rd.triggers[cmd]
    if t.verb != VERB_PLAY:
        return None
    m = rd.tracks[t.track]
    data = rd.read_track(t.track)
    if m.codec == CODEC_ADX:
        u = 18 * m.channels
        data = data[:len(data) // u * u]
        pcm = adxcodec.decode(data, m.channels, m.sample_rate,
                              total_samples=len(data) // u * 32)
    else:
        pcm = data
    a = array.array("h")
    a.frombytes(pcm)
    sr, ch = m.sample_rate, m.channels
    dur = len(a) / ch / sr

    def rms(t0: float, t1: float) -> float:
        i0, i1 = int(t0 * sr) * ch, int(t1 * sr) * ch
        seg = a[max(0, i0):i1]
        return math.sqrt(sum(float(v) * v for v in seg) / max(1, len(seg)))

    n = int(dur / res)
    peak = max(rms(k * 0.1, (k + 1) * 0.1) for k in range(int(dur * 10)))
    if peak <= 0:
        return None
    thr = peak * 10 ** (floor_db / 20)
    hits = [(k + 1) * res for k in range(n) if rms(k * res, (k + 1) * res) > thr]
    return max(hits) if hits else None


def screen_patches(pack: str | Path, rows: dict[int, int] = CUE_ROWS) -> list[tuple[int, int]]:
    """[(68K address, value)] for a Final Fight pack; [] if it already fits.
    rows: the pack's trigger row for each cue (CUE_ROWS for CPS1's packs)."""
    rd = PackReader(pack)
    try:
        out = []
        end58 = music_end(rd, rows[0x58])
        if end58 and end58 > ARCADE_0x58:
            val = R6_STOCK + math.ceil((end58 - ARCADE_0x58) * FPS)
            if val > 0xFFFF:
                raise SystemExit(f"{Path(pack).name}: round-6 counter {val} overflows a word")
            out.append((R6_SITE, val))
        end57 = music_end(rd, rows[0x57])
        if end57 and end57 > ARCADE_0x57:
            delay = math.ceil((end57 - ARCADE_0x57) * FPS)
            val = FADE_STOCK + delay
            if val > 255:
                raise SystemExit(f"{Path(pack).name}: 0x57 needs {val} frames of fade "
                                 f"delay, past the byte the counter lives in")
            out.append((FADE_SITE, val))
        for cmd, (addr, stock, window) in SITES.items():
            end = music_end(rd, rows.get(cmd, cmd))
            if end is None:
                continue
            over = end - window
            if over <= 0:                      # already fits: leave the ROM alone
                continue
            add = math.ceil(over * FPS / INNER_FRAMES)   # no margin: each blink
                                                        # costs 0.20 s, and on
                                                        # rounds 1-5 that is dark
            out.append((addr, stock + add))
        return out
    finally:
        rd.close()


if __name__ == "__main__":
    for p in sys.argv[1:]:
        rd = PackReader(p)
        print(f"{Path(p).name}:")
        for cmd, (addr, stock, window) in SITES.items():
            end = music_end(rd, cmd)
            if end is None:
                print(f"  0x{cmd:02x}: unmapped")
                continue
            pats = dict(screen_patches(p))
            v = pats.get(addr)
            state = (f"{stock} -> {v} blinks" if v else f"{stock} (fits, no patch)")
            print(f"  0x{cmd:02x}: music ends {end:5.2f}s, window {window:5.2f}s"
                  f"  -> {state}")


# --------------------------------------------------------------- verify ----
# A patch offset that misses lands somewhere else in the 68K program, so this
# check exists to FAIL: it assembles the base MRA exactly as the loader does
# and asserts the target byte still holds the stock blink count.
#
# MRA `map` is read LEFTMOST = LEAST-significant byte.  Getting that backwards
# makes the stock set verify and the backport set appear broken (their part
# ORDER differs), which is exactly the false alarm it caused once.  The byte
# for a 68K address is therefore  header + (addr ^ 1).
def assemble_mra(mra_path, rom_dir):
    import xml.etree.ElementTree as ET
    from embed_pack_mra import measure_header_len
    rom = ET.parse(mra_path).getroot().find("rom")
    R, img, missing = Path(rom_dir), bytearray(), []

    def rd(name):
        f = R / name
        if not f.exists():
            missing.append(name)
            return b""
        return f.read_bytes()

    for node in rom:
        if node.tag == "interleave":
            w = int(node.get("output", "16")) // 8
            parts = [(p.get("map", ""), rd(p.get("name")))
                     for p in node if p.tag == "part"]
            n = min((len(d) for _, d in parts), default=0)
            if w == 2 and all(m.count("0") == len(m) - 1 for m, _ in parts):
                out = bytearray(n * 2)
                for m, d in parts:
                    mm = m[::-1]                     # leftmost = LSB
                    out[mm.index(next(c for c in mm if c != "0"))::2] = d[:n]
                img.extend(out)
            else:
                img.extend(b"\x00" * (n * w))        # gfx: size only
        elif node.tag == "part":
            if node.get("name"):
                img.extend(rd(node.get("name")))
            elif node.text:
                img.extend(bytes(int(b, 16) for b in node.text.split()))
    return img, measure_header_len(rom), missing


def verify_sites(mra_path, rom_dir):
    """Raise unless every blink-count byte is where SITES says it is."""
    img, hdr, missing = assemble_mra(mra_path, rom_dir)
    if missing:
        raise SystemExit(f"{mra_path}: cannot verify, missing {missing[:4]}")
    checks = [(addr, stock, 1) for addr, stock, _w in SITES.values()]
    checks.append((FADE_SITE, FADE_STOCK, 1))
    checks.append((R6_SITE, R6_STOCK, 2))
    for addr, stock, width in checks:
        if width == 2:
            off = hdr + addr
            got = img[off] | (img[off + 1] << 8) if off + 1 < len(img) else None
        else:
            off = hdr + (addr ^ 1)
            got = img[off] if off < len(img) else None
        if got != stock:
            raise SystemExit(
                f"{Path(mra_path).name}: 68K 0x{addr:X} -> MRA byte {off} holds "
                f"{got}, expected the stock value {stock}. "
                f"The patch would corrupt the ROM -- do not ship.")
    return True
