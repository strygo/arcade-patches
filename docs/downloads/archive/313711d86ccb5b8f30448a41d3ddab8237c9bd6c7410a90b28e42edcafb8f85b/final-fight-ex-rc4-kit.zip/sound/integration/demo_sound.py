#!/usr/bin/env python3
"""Turn the game's own demo sound on in a CPS+ MRA's embedded EEPROM.

CPS+ exists to play arranged music, so its MRAs ship with attract audio on.
CPS-1 sets already default to Demo Sounds On in their DIP defaults; CPS-2 sets
keep the setting in the EEPROM, and the games reject an image they did not
write, so each offset in manifests/demo_sound.json was obtained by letting the
game set it through its own SYSTEM CONFIGURATION menu and reading the changed
bytes back (see that file's "how", and the recorded before/after attract peaks).
"""
from __future__ import annotations

import json
from pathlib import Path
import xml.etree.ElementTree as ET

CATALOG = json.loads((Path(__file__).resolve().parents[1] / "manifests" /
                      "demo_sound.json").read_text())["sets"]


def enable(root: ET.Element) -> list[int]:
    """Set the demo-sound bytes for this MRA's set. Returns the offsets written."""
    setname = root.findtext("setname")
    entry = CATALOG.get(setname)
    node = root.find("./rom[@index='2']/part")
    if node is None:                      # CPS-1: the DIP default already says On
        return []
    if entry is None:
        raise SystemExit(f"{setname}: not in manifests/demo_sound.json -- measure it "
                         f"before shipping an MRA for it")
    offsets = [int(o, 16) for o in entry["offsets"]]
    if not offsets:                       # attract already plays
        return []
    data = bytearray(bytes.fromhex("".join(node.text.split())))
    if len(data) != 128:
        raise SystemExit(f"{setname}: EEPROM is {len(data)} bytes, expected 128")
    for off in offsets:
        data[off] = 1
    node.text = "\n" + "\n".join(data[i:i + 16].hex(" ").upper()
                                 for i in range(0, 128, 16)) + "\n"
    return offsets
