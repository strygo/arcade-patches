# Media tools

The builder fetches the pinned FFmpeg and ffprobe pair when a conversion first
needs them. The archive and every installed file are checked against the kit's
trusted SHA-256 manifest. Subsequent runs reuse the verified cache.

Use `--tools-cache DIRECTORY` to choose the cache. To work without internet,
provide `--tools-bundle cpsplus-tools-v2-offline.zip --offline`. These options
are accepted by `build_pack.py`, `make_packs.py`, `make_x68k_flac.py` and
`make_dos_flac.py`. The equivalent environment variables are
`CPSPLUS_SWITCH_TOOLS_CACHE`, `CPSPLUS_SWITCH_TOOLS_BUNDLE` and
`CPSPLUS_SWITCH_TOOLS_OFFLINE=1`; the names are shared with Switch extraction
helpers so one cache and offline bundle work across kits.

Advanced users can select their own executables with `CPSPLUS_FFMPEG` and
`CPSPLUS_FFPROBE`. Explicit overrides must name working executables. They are
outside the pinned helper qualification; builds still enforce output hashes
where the pack declares them.

Helpers are available for macOS 11+ (Apple Silicon and Intel), Ubuntu 24.04+
(ARM64 and x86-64), Windows x64, and Windows 11 ARM through x64 emulation.
The FFmpeg build includes built-in codecs, formats and filters, with optional
external libraries, networking, GPL and nonfree features disabled. Both tools
are LGPL 2.1 or later. Each host archive includes licenses, the source identity,
configuration and a standalone producer recipe. Corresponding unmodified
source is included in the offline bundle and provided beside the binaries at:
https://github.com/strygo/arcade-patches/releases/tag/ffmpeg-helpers-v1

This supplies media tools only. CPS+ still needs Python and its declared Python
packages (including NumPy), owned game inputs, and any source-specific tools
listed by the selected builder. For example, MIDI rendering may require CMake,
a compiler and instrument firmware. Automatic FFmpeg fetching does not remove
those separate requirements.
