"""Regional CPS+ packs and the canonical launchers for the standalone EX kit."""
from __future__ import annotations

import hashlib
from pathlib import Path
import shutil
import sys

HERE = Path(__file__).resolve().parent
SOUND = HERE / "sound"
sys.path.insert(0, str(SOUND))
sys.path.insert(0, str(SOUND / "integration"))
sys.path.insert(0, str(SOUND / "tools"))


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def configure(args):
    import ffmpeg_runtime
    options = []
    for name in ("tools_cache", "tools_bundle"):
        value = getattr(args, name, None)
        if value is not None:
            options += ["--" + name.replace("_", "-"), str(value)]
    if args.offline:
        options.append("--offline")
    ffmpeg_runtime.configure(options)


def prepare():
    import ffmpeg_runtime
    return ffmpeg_runtime.resolve("ffmpeg")


def data_track(disc, work, *, require_audio=False):
    """Use the same explicitly supplied rip for scene data and its CD audio."""
    from pack import discsrc
    discsrc.DISC_CACHE = Path(work) / "discs"
    disc = Path(disc).resolve()
    if disc.suffix.lower() in (".bin", ".img"):
        if require_audio:
            raise ValueError("CPS+ needs the complete disc: pass its .cue or a ZIP/7z containing it, "
                             "or use --audio arcade with a raw track image")
        image = disc
    else:
        # Optional CHD support uses the existing CPS+ reader and chdman.
        # Put any extraction in this invocation's own disposable tree.
        from pack import sources
        sources.CACHE_DIR = Path(work) / "disc-cache"
        cue = discsrc.descriptor(disc)
        if cue.suffix.lower() != ".cue":
            raise ValueError("Final Fight CD needs a .cue descriptor")
        tracks, _ = discsrc.extract_cdda.parse_cue(cue)
        number, mode, image, _, start, _ = tracks[0]
        if number != 1 or mode.upper() != "MODE1/2352" or start != 0:
            raise ValueError("Track 1 must be MODE1/2352 at the start of its image")
        if require_audio and any(not image.is_file() for _, _, image, *_ in tracks):
            raise ValueError("Keep every audio image beside the disc descriptor")
        if require_audio and not any(mode.upper() == "AUDIO" for _, mode, *_ in tracks):
            raise ValueError("The supplied disc has no CD audio tracks")
    with image.open("rb") as stream:
        head = stream.read(12)
    if head != b"\0" + b"\xff" * 10 + b"\0" or image.stat().st_size % 2352:
        raise ValueError("The disc data track is not a raw 2352-byte MODE1 image")
    return image.resolve()


def verify_core(core):
    path = HERE / "core" / core["filename"]
    if not path.is_file() or path.stat().st_size != core["bytes"] or sha(path) != core["sha256"]:
        raise ValueError("The bundled CPS1 CPS+ core is missing or changed")


def build(region, disc, work, pins):
    from pack import build_ffight_arrange as builder
    spec = pins[region]
    pack = Path(work) / "packs" / (spec["name"] + ".cpk")
    pack.parent.mkdir(parents=True, exist_ok=True)
    builder.build("adx", out=str(pack), cd_dir=str(Path(work) / "audio" / region),
                  measure_snr=False, region=region, **{region + "_disc": str(disc)})
    if sha(pack) != spec["sha256"]:
        raise ValueError(f"{pack.name}: differs from the CPS+ pack; check the supplied regional disc")
    return pack


def stage(stage, archives, discs, work, outputs, write_zip):
    """Only the existing generator authors the CPS+ MRA names and layout."""
    from gen_backport_mras import generate
    packs = {}
    for region in archives:
        packs[region] = build(region, discs[region], work, outputs["packs"])
    rows = generate(stage / "hbmame", Path(work) / "packs", Path(work) / "mras",
                    base_dir=HERE / "mras", regions=tuple(archives))
    for row in rows:
        target = stage / "mister" / row["destination"]
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(row["path"], target)
    for region, pack in packs.items():
        write_zip(stage / "mister/games/CPS+" / (pack.stem + ".zip"), {pack.name: pack.read_bytes()})
    shutil.copytree(HERE / "core", stage / "mister/_Arcade/cores", dirs_exist_ok=True)
