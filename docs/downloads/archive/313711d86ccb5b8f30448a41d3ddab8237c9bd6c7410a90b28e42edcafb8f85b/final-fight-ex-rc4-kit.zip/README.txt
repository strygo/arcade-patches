Final Fight EX — Enhanced version
Version: rc4 (2026-10-24)
Game: Final Fight (arcade, Capcom CPS-1)
Hardware: Capcom CPS-1

The 1993 Sega CD port gave Final Fight an animated opening and an extended ending. Final Fight EX brings those scenes to the arcade game as native CPS-1 graphics, with an EX title and a hidden stage select. The original combat and timing stay intact.

There are two regional builds, USA (ffightus01) and Japan (ffightjs01), each matched to its own disc's dialogue and artwork. It runs in HBMAME and on MiSTer; stock MAME is not supported.

On MiSTer, choose the arcade game's music and effects or the CPS+ Arrange version with the Sega CD soundtrack and regional spoken dialogue. Both options are included in this kit.

Supply your arcade Final Fight ROMs and the matching Final Fight CD disc for each region you build. This is a release candidate.

FEATURES

- The Sega CD opening, including the Metro City map, Mad Gear line-up, Haggar's phone call, and the Cody and Guy montage
- The extended ending, including Haggar and Jessica's reunion and Cody's farewell
- A Final Fight EX title screen
- A hidden stage select: hold attack and jump and press Start on the title screen to choose a round or the ending
- USA (ffightus01) and Japan (ffightjs01) builds, each with its regional dialogue and artwork
- Arcade audio or the Sega CD soundtrack and regional voices through CPS+ on MiSTer
- Corrections to English spelling and the Japanese ending artwork

FINAL FIGHT EX — CPS-1
=====================

Build the USA or Japanese version from your own canonical MAME Final Fight
ROMs and the matching Final Fight CD disc. The kit reconstructs the opening
and ending scenes, and can build the CPS+ CD soundtrack and voices alongside
them. Each region needs only its own disc.

REQUIREMENTS
------------
Python 3.10 or later, NumPy and Pillow:

    python3 -m pip install numpy Pillow

FFmpeg and ffprobe are obtained automatically from the content-pinned helper
packages when CPS+ audio is requested. No compiler or system FFmpeg install
is needed. See TOOLS.md for the helper licenses, platforms and source.

ZIP archives and uncompressed cue/bin or cue/img discs need no archive tool.
7z inputs need 7-Zip; optional CD CHD inputs need MAME's chdman. The ROM reader
accepts ZIP, 7z and loose canonical files through --romset or --rompath.

BUILD
-----
For the complete MiSTer build, pass the full disc descriptor or an archive
containing it and all of its audio tracks:

    python3 apply.py --disc-us "Final Fight CD (USA).cue" --romset /path/to/roms --out-dir out
    python3 apply.py --disc-jp "Final Fight CD (JP).cue" --romset /path/to/roms --out-dir out

Supply both disc arguments to build both regions. --region us or --region jp
narrows the selection. --platform hbmame builds only the emulator ROMs and
does not prepare media tools. --platform mister builds only the MiSTer tree.

--audio both (the default) builds arcade-audio and CPS+ launchers.
--audio arcade skips the audio pack and uses the standard core.
--audio cpsplus builds only the CPS+ launchers.

Arcade-audio and HBMAME builds also accept the raw first-track .bin or .img.
CPS+ needs the full disc, including audio. --check verifies the selected
inputs without reconstructing the game or downloading FFmpeg.

Media tools use a verified shared cache. Optional controls:

    --tools-cache /path/to/cache
    --tools-bundle cpsplus-tools-v2-offline.zip --offline

--work selects disposable scratch space. Each build creates and removes its
own temporary directory there. The scene conversion can take several minutes.
The kit checks every reconstructed ROM and regional pack before installing
outputs; conflicting existing output files are preserved and reported.

OUTPUTS
-------
Copy the contents of out/mister to the MiSTer card root:

    _Arcade/_Arcade Patches/_Enhanced Versions/Final Fight EX (USA).mra
    _Arcade/_Arcade Patches/_Enhanced Versions/_Japan/Final Fight EX (Japan).mra
    _Arcade/_Arcade Patches/_Arrangements/_CPS+/Final Fight EX (USA) [Arrange].mra
    _Arcade/_Arcade Patches/_Arrangements/_CPS+/_Japan/Final Fight EX (Japan) [Arrange].mra
    _Arcade/cores/jtcps1-cpsplus.rbf
    games/hbmame/ffightus01.zip
    games/hbmame/ffightjs01.zip
    games/CPS+/ffight_arrange.zip
    games/CPS+/ffight_arrange_jp.zip

Only the selected regions and audio options are written. Both launchers for
a region share its ROM ZIP. The Arrange launchers, pack names, folder layout
and core are the same as the CPS+ kit; installing both produces no duplicate
launchers. The arcade-audio launchers require the standard Jotego jtcps1 core.

HBMAME outputs are under out/hbmame. Use a build with the ffightus01 and
ffightjs01 registrations. Modified ROMs produce expected checksum warnings.

STAGE SELECT
------------
On the credited title, hold attack and jump while pressing Start. Damnd's
laugh confirms the code. After character select, use the joystick to choose
a round or ENDING, then attack, jump or Start to confirm. These runs do not
enter the high-score table.

CONTENTS AND LICENSES
---------------------
The download contains reconstruction code, scene measurements, original EX
lettering, launcher templates and the CPS+ core with its license and source
information. Game ROMs, extracted scenes, disc audio and built audio packs
are reconstructed from your files and are not included in this download.
