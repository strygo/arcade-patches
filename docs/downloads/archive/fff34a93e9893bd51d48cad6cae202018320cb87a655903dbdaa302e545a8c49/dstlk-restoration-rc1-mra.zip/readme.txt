Darkstalkers: The Night Warriors · English restoration
======================================================

Version:  rc1 (2026-10-06)
Target:   MAME set 'vampj' (Vampire: The Night Warriors (Japan 940705))
Hardware: Capcom CPS-2
Patch by: Steve Gordon (https://x.com/strygo)
Website:  https://arcadepatches.com/dstlk-restoration/

ABOUT THIS PROJECT

The original Japanese Vampire gives each fighter a pool of win quotes, and
offers move advice after a loss. The USA version uses one English win quote
per fighter and removes the advice.

The English Restoration brings back the Japanese quote pools and bordered
result panel, the complete ending dialogue, and all 85 continue tips,
translated from the Japanese.

The voices the USA version muted are back: Morrigan’s alternate victory,
Vector Drain and throw, and Felicia’s Rolling Buckler, Dancing Flash and
special damage reaction. As in the USA release, Rikuo’s crouching heavy punch
can be blocked with a crouching guard.

It keeps the ten playable fighters and the Western character names, and adds
Free Play to the operator menu. It runs in MAME and HBMAME and on MiSTer.

This is a release candidate.

WHAT'S CHANGED

  - Japanese win-quote pools in English, with the Japanese result-panel border
  - Complete Japanese ending dialogue in English, with the original scene
    timing
  - All 85 Japanese continue tips in English, including their arcade move
    commands
  - Morrigan’s alternate victory, Vector Drain and throw voices, and Felicia’s
    Rolling Buckler, Dancing Flash and special damage voices
  - Rikuo’s crouching heavy punch can be blocked with a crouching guard, as in
    the USA release
  - Western character names, and Free Play in the operator menu

MISTER SETUP

1. Copy the _Arcade/ folder from this download to the root of your
   MiSTer SD card (the MRA lands in _Arcade/_Arcade Patches/_Restorations/), or copy
   "Darkstalkers The Night Warriors (USA) [English Restoration].mra" anywhere under _Arcade/.
2. Have the stock, unmodified romset at games/mame/vampj.zip
   (split sets also need the parent and QSound ZIPs named in the MRA).
3. You need Jotego's jtcps2 core; the standard MiSTer downloader /
   update_all installs it automatically.

The MRA references your original romset and applies the restoration in
memory while the game loads. Nothing on your SD card is modified. The
restoration keeps its own settings and saves under the name
'vamprest'.

LEGAL

This is a free, unofficial fan patch. It is not affiliated with or endorsed
by Capcom. All game titles, characters, and artwork remain the property of
their respective owners. You must own the game to use this patch. Do not
sell this patch or distribute it applied to a ROM image.
