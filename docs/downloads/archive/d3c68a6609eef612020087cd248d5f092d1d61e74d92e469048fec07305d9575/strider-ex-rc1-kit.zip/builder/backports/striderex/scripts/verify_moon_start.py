"""Bind Moon entrance checks to fresh reconstructed inputs and damage controls."""
import argparse
from copy import deepcopy
import json
from pathlib import Path
import tempfile
import moon_start as M
import moon_start_gate as GATE
import build_gameplay_followup as BUILD
from boss_voice_gate import inventory, sha

def main():
    p = argparse.ArgumentParser(description=__doc__)
    for n in ('control', 'build', 'fresh-root', 'fresh-build', 'gate', 'workdir', 'receipt'):
        p.add_argument('--' + n, type=Path, required=True)
    a = p.parse_args()
    a.workdir.mkdir(parents=True, exist_ok=True)
    cm, cf = inventory(a.control)
    bm, bf = inventory(a.build)
    fresh = json.loads((a.fresh_root / 'receipt.json').read_text())
    if not fresh['passed'] or fresh['baseline_export_manifest_sha256'] != BUILD.BASELINE_SHA:
        raise ValueError('fresh reconstruction is not the selected native Kit aa')
    if inventory(a.fresh_root / 'final') != (cm, cf) or inventory(a.fresh_build) != (bm, bf):
        raise ValueError('fresh reconstruction differs in bytes or metadata')
    M.audit(a.fresh_root / 'final', a.fresh_build)
    gate = json.loads(a.gate.read_text())
    expected = {label: {m: s['files'] for m, s in meta['sets'].items()} for label, meta in (('control', cm), ('candidate', bm))}
    if gate['inputs'] != expected or not gate['passed'] or len(gate['checks']) != 12:
        raise ValueError('runtime checks do not bind these exact ROMs')
    sources = {q.name: sha(q.read_bytes()) for q in (Path(GATE.__file__), Path(M.__file__), M.ASM, GATE.G.LUA)}
    if gate['source_sha256'] != sources:
        raise ValueError('runtime gate sources changed')
    rejected = []
    with tempfile.TemporaryDirectory(dir=a.workdir) as tmp:
        for m in bf:
            for kind in ('program', 'helper'):
                dest = Path(tmp) / (m + '_' + kind)
                dest.mkdir()
                meta = deepcopy(bm)
                target = 'strex_p6.bin' if kind == 'helper' else M.R.SETS[m][0][0]
                for machine, files in bf.items():
                    folder = dest / machine
                    folder.mkdir()
                    for name, data in files.items():
                        path = folder / name
                        if machine == m and name == target:
                            damaged = bytearray(data)
                            damaged[M.BASE - 1048576 ^ 1 if kind == 'helper' else 256] ^= 1
                            path.write_bytes(damaged)
                            meta['sets'][machine]['files'][name] = sha(damaged)
                        else:
                            path.symlink_to((a.build / machine / name).resolve())
                (dest / 'build.json').write_text(json.dumps(meta) + '\n')
                try:
                    M.audit(a.control, dest)
                except ValueError:
                    rejected.append(dict(machine=m, kind=kind, inventory_rehashed=True, rejected=True))
                else:
                    raise ValueError('internally rehashed damage was accepted')
    report = dict(schema='striderex-moon-start-fresh/1', passed=True, baseline_test_id=fresh['baseline_test_id'], baseline_export_manifest_sha256=BUILD.BASELINE_SHA, fresh_files_and_metadata_exact=True, fresh_gameplay_receipt_sha256=sha((a.fresh_root / 'receipt.json').read_bytes()), runtime_receipt_sha256=sha(a.gate.read_bytes()), inputs=expected, damage_controls=rejected, source_sha256=dict(sources, **{Path(__file__).name: sha(Path(__file__).read_bytes())}), hardware_review_granted=False)
    a.receipt.parent.mkdir(parents=True, exist_ok=True)
    a.receipt.write_text(json.dumps(report, indent=2) + '\n')
    print('Fresh native-kit reconstruction exact; four internally rehashed damage controls rejected')
if __name__ == '__main__':
    main()
