"""Prepare high-quality boss masters and native OKI derivatives from pinned takes."""
import argparse
import io
import json
from pathlib import Path
import subprocess
import wave
import numpy as np
from scipy.signal import resample_poly
import boss_scene_binary as BB
import boss_voice_pack as BV
import dub_store as DS
import oki_adpcm as OKI
import pce_sfx as PS
RATE = 48000
TEMPO = 1.1
BEAM = 32

def read_wav(data):
    with wave.open(io.BytesIO(data), 'rb') as w:
        if w.getframerate() != RATE or w.getnchannels() != 1 or w.getsampwidth() != 2:
            raise ValueError('expected 48 kHz mono signed 16-bit input')
        return np.frombuffer(w.readframes(w.getnframes()), '<i2').astype(float) / 32768

def wav_bytes(x, rate=RATE):
    b = io.BytesIO()
    with wave.open(b, 'wb') as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(rate)
        w.writeframes(np.rint(np.asarray(x) * 32768).clip(-32768, 32767).astype('<i2').tobytes())
    return b.getvalue()

def trim(x):
    block = 480
    rms = np.array([np.sqrt(np.mean(x[i:i + block] ** 2)) for i in range(0, len(x), block)])
    active = np.flatnonzero(rms > 10 ** (-55 / 20))
    if not len(active):
        raise ValueError('silent voice take')
    lo = max(0, int(active[0]) * block - 2880)
    hi = min(len(x), int(active[-1] + 1) * block + 3840)
    return (x[lo:hi], (lo, hi))

def compact_pauses(x):
    """Keep 160 ms of a pause only when at least 300 ms is below -50 dBFS."""
    block = 480
    quiet = np.array([np.max(np.abs(x[i:i + block])) < 10 ** (-50 / 20) for i in range(0, len(x), block)])
    edges = np.flatnonzero(np.diff(np.r_[False, quiet, False].astype(int)))
    cuts = []
    for lo, hi in zip(edges[::2], edges[1::2]):
        if hi - lo >= 30:
            cuts.append((int((lo + 8) * block), min(len(x), int((hi - 8) * block))))
    pieces = []
    start = 0
    for lo, hi in cuts:
        pieces.append(x[start:lo])
        start = hi
    pieces.append(x[start:])
    return (np.concatenate(pieces), cuts)

def prepare(a):
    take_dir = DS.dir_arg(a.takes)
    if not DS.in_store(take_dir):
        raise ValueError('takes must live in the durable store')
    source = json.loads((take_dir / 'boss-dub.json').read_text())
    takes = {r['id']: r for r in source['takes'] if r['language'] == 'en'}
    if set(takes) != set(BB.IDS):
        raise ValueError('all eight English boss takes required')
    a.out.mkdir(parents=True, exist_ok=False)
    target = BV.cinematic_reference()[0]
    result = dict(schema='striderex-boss-voice-assets/1', takes_store_set=take_dir.name, source_receipt_sha256=DS.sha(take_dir / 'boss-dub.json'), native_tempo=TEMPO, ffmpeg_sha256=DS.sha(a.ffmpeg), native_rate_hz=PS.OKI_RATE, encoder_beam=BEAM, reference_voice_lufs=target, voices=[])
    for lid in BB.IDS:
        take = takes[lid]
        p = take_dir / take['file']
        if DS.sha(p) != take['wav_sha256']:
            raise ValueError('take identity changed')
        x, span = trim(read_wav(p.read_bytes()))
        loud = BV.lufs(x, RATE)
        gain = min(target - loud, -1 - 20 * np.log10(max(np.abs(x))))
        x = x * 10 ** (gain / 20)
        master = a.out / (lid + '.wav')
        master.write_bytes(wav_bytes(x))
        compact, cuts = compact_pauses(x)
        compact_wav = a.out / (lid + '.native-input.wav')
        compact_wav.write_bytes(wav_bytes(compact))
        run = subprocess.run([str(a.ffmpeg), '-hide_banner', '-loglevel', 'error', '-i', str(compact_wav), '-af', 'atempo=' + str(TEMPO), '-f', 's16le', '-acodec', 'pcm_s16le', '-ac', '1', '-ar', str(RATE), 'pipe:1'], capture_output=True, check=True)
        accelerated = np.frombuffer(run.stdout, '<i2').astype(float) / 32768
        native = PS.to_oki_rate(accelerated)
        scale = min(2048, 1824 / max(np.max(np.abs(native)), 1e-12))
        wanted = np.concatenate((native * scale, np.zeros(32)))
        nibs = OKI.encode_trellis(wanted, BEAM)
        encoded = OKI.pack(nibs)
        decoded = OKI.round_trip(encoded, nibs)
        (a.out / (lid + '.oki')).write_bytes(encoded)
        preview = resample_poly(decoded.astype(float) / 2048, 792, 125, window=('kaiser', 8.6))
        (a.out / (lid + '.native.wav')).write_bytes(wav_bytes(preview))
        noise = float(np.mean((wanted - decoded[:len(wanted)]) ** 2))
        row = dict(id=lid, command=hex(192 + BB.IDS.index(lid)), take_sha256=take['wav_sha256'], approved_text=take['approved_text'], trim_samples=list(span), gain_db=round(float(gain), 6), master_file=master.name, master_sha256=DS.sha(master), master_samples=len(x), native_removed_quiet_spans=[list(r) for r in cuts], native_file=lid + '.oki', native_bytes=len(encoded), native_sha256=DS.sha(a.out / (lid + '.oki')), native_samples=len(decoded), native_seconds=len(decoded) / PS.OKI_RATE, native_snr_db=10 * np.log10(float(np.mean(wanted ** 2)) / max(noise, 1e-20)))
        result['voices'].append(row)
        (a.out / 'voices.json').write_text(json.dumps(result, indent=2) + '\n')
        print(lid, len(encoded), 'OKI bytes, SNR %.2f dB' % row['native_snr_db'], flush=True)
    result['total_native_bytes'] = sum((r['native_bytes'] for r in result['voices']))
    if result['total_native_bytes'] > 125952 - 38656 + 203776 - 135168:
        raise ValueError('native voices exceed the intro range while preserving short original phrases')
    (a.out / 'voices.json').write_text(json.dumps(result, indent=2) + '\n')

def main():
    import sys
    if sys.argv[1:] == ['--self-test']:
        assert 1 <= TEMPO <= 1.1
        x = np.r_[np.ones(4800) * 0.5, np.zeros(28800), np.ones(4800) * -0.5]
        short, cuts = compact_pauses(x)
        assert len(cuts) == 1 and all((np.all(x[lo:hi] == 0) for lo, hi in cuts))
        assert np.array_equal(short[short != 0], x[x != 0]) and len(short) < len(x)
        try:
            trim(np.zeros(48000))
        except ValueError:
            pass
        else:
            raise AssertionError('silent voice accepted')
        for n in (500, 1501):
            a = np.sin(np.arange(n) * 0.1) * 0.3
            assert len(read_wav(wav_bytes(a))) == n
        OKI.self_test()
        print('Boss voice preparation self-test PASS: speech preserved, silence rejected, OKI round trip')
        return
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--takes', required=True)
    p.add_argument('--out', type=Path, required=True)
    p.add_argument('--ffmpeg', type=Path, default=Path('/opt/homebrew/bin/ffmpeg'))
    prepare(p.parse_args())
if __name__ == '__main__':
    main()
