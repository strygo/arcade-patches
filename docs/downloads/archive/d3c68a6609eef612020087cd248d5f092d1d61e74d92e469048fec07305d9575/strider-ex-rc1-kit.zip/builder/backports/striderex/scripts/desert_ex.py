"""Strider EX Phase 3b: the PC Engine desert ("Oil Fields") as arcade stage 5."""
import argparse
import hashlib
import json
import re
import struct
import sys
from pathlib import Path
import numpy as np
sys.path.insert(0, str(Path(__file__).resolve().parent))
import cps1_gfx as G
ROOT = Path(__file__).resolve().parents[3]
MB = 1048576
DZ_STAGE = 5
HOOKS = {'next_stage': ('1b7c00018cb21b7c00008cce', 0, 6, 'dz_next_stage'), 'l_5260': ('7000102d8cb2d000303b00064efb0002000a????????????????2b6d8f74', 2, 6, 'dz_as_sib_b'), 'l_52a2': ('7000102d8cb2d000303b00064efb0002000a????????????????2b6d20028f74', 2, 6, 'dz_as_sib_b')}
TASK_HOOKS = {'pick_intro': ('DZ_INTRO', 'dz_task_intro'), 'pick_clear': ('DZ_CLEAR', 'dz_task_clear')}
TASK_COPY = '0c2d00058cb267104e714e7148e79ffe4e404cdf7ff94e75'
TRAP0 = '49ed8000024000ff4a340000670c2c6d810a2d34000c2b4e810a2c6d810a299e000c2b4e810a39bc0c000000298800044e73'
PAL_OBJ = '7000102d8cb2d040d040207c????????207000007000102d8cce'
LAYER_RECORD = {'S1': 18, 'S2': 18, 'S3': 14}
INTRO_TASK = '4bf88000303c00014eb9000007de487afff44a3900ff0c84'
CLEAR_TASK = '4bf880004eb8112a303c00014eb807de487afff6'
TASK_START = '303c0040207c0000????4eb900000758'
DISPATCH = '41edde9a7000102d8cb2d040d040227b00044ed1'
ROUTINES = {'DZ_SLEEP': '48e7fffe4e434cdf7fff4e75', 'DZ_QUEUE': '48e7010849ed8eaa3e2d8c24', 'DZ_CLRSPR': '41f9009000006100000841f90090400070002400383c00ff20c020c251ccfffa4e7541f9009000007000', 'DZ_S2': '41ed8fac102800024880227b00124e91', 'DZ_S3': '41ed8fec102800024880227b00164e91', 'DZ_S3INIT': '3c3c003f3168000800103168000c0012317c07e00012', 'DZ_CPLOAD': '3b5990d23b5990d63b598ff43b598ff8', 'DZ_PLAY': '3b7c00780e74303c09094eb80e10', 'DZ_TSTART': '48e7fffe4e404cdf7fff4e75', 'DZ_EXIT': '4e415c8f206d8106117c00000000', 'stars2': '207c000c601e227c00915400', 'DZ_SCR_R': '3a3c0020906800320c400040', 'DZ_SCR_L': '3a3c00203228003492400c410040', 'DZ_SCR_U': '3a3c0020906800360c400040', 'DZ_SCR_D': '3a3c00203228003892400c410040', 'DZ_PAL1': '207c00080000303c0000207000001 02d8cb24880d0403200e749d0412070000e227c00914400'.replace(' ', ''), 'DZ_PAL2': '207c00080000303c0004207000001 02d8cb24880d0403200e749d0412070000e227c00914800'.replace(' ', ''), 'DZ_PAL3': '207c00080000303c0008207000001 02d8cb24880d0403200d040d040d04090412070000a227c00914c00'.replace(' ', '')}
WATCH_SLOT = 128
SOUND_STUB = '303c00116000'
LAYER_TABLE_DIR = 524288
SET_ROUTINES = {'A': [6440], 'B': [6804, 7216, 7504], 'C': [7798, 9288], 'D': [8126, 8788]}
CLEAR_CODE = 32
TRANSPARENT_CODE = 14337
S3_FIRST, S3_LAST = (14338, 15615)
SKY_PEN = 3071
SEC_MUSIC = [121, 4, 122, 122, 5]

def sha(b):
    return hashlib.sha256(b).hexdigest()

def program_images(rom_dir):
    import respawn_fix as RF
    out = {}
    for m, layout in RF.SETS.items():
        files = {p.name: p.read_bytes() for p in (rom_dir / m).iterdir() if p.is_file()}
        out[m] = bytes(RF.compose(files, layout))
    return out

def find(img, pattern, lo=0, hi=524288):
    rx = re.compile(b''.join((b'.' if pattern[i:i + 2] == '??' else re.escape(bytes.fromhex(pattern[i:i + 2])) for i in range(0, len(pattern), 2))), re.S)
    return [m.start() for m in rx.finditer(img, lo, hi) if m.start() % 2 == 0]

def find1(img, pattern, what, lo=0, hi=524288):
    hits = find(img, pattern, lo, hi)
    if len(hits) != 1:
        sys.exit(f'desert_ex: {what}: {len(hits)} matches for {pattern[:24]}..., 1 expected (unsupported revision)')
    return hits[0]

def be16(img, a):
    return struct.unpack('>H', img[a:a + 2])[0]

def be32(img, a):
    return struct.unpack('>I', img[a:a + 4])[0]

def task_slots(img):
    """The slot of every stock task start (move.w #slot,d0 shortly before jsr 0x758)."""
    slots = set()
    for at in find(img, '4eb900000758') + find(img, '4eb80758'):
        back = [b for b in range(at - 2, at - 20, -2) if img[b:b + 2] == b'0<']
        if not back:
            sys.exit(f'desert_ex: the task start at {at:#x} has no immediate slot')
        slots.add(be16(img, back[0] + 2))
    return slots

def locate(img):
    """Every address desert.s and the patcher need, from the image (shape-checked)."""
    s = {}
    for name, pat in ROUTINES.items():
        s[name] = find1(img, pat, name)
    s['DZ_INTRO'] = find1(img, INTRO_TASK, 'intro task')
    s['DZ_CLEAR'] = find1(img, CLEAR_TASK, 'clear task')
    starts = find(img, TASK_START)
    picks = {}
    for at in starts:
        target = be32(img, at + 6)
        if target == s['DZ_INTRO']:
            picks['pick_intro'] = at + 10
        elif target == s['DZ_CLEAR']:
            picks['pick_clear'] = at + 10
    if sorted(picks) != ['pick_clear', 'pick_intro']:
        sys.exit(f'desert_ex: intro/clear task starts not found ({sorted(picks)})')
    for name, at in picks.items():
        if img[at:at + 6] != jsr(s['DZ_TSTART']):
            sys.exit(f'desert_ex: the {name} task start at {at:#x} does not call the stock task start')
    if img[be32(img, 128):be32(img, 128) + len(TRAP0) // 2] != bytes.fromhex(TRAP0):
        sys.exit('desert_ex: TRAP #0 (the task start) has an unexpected shape')
    s.update(picks)
    disp = find1(img, DISPATCH, 'stage dispatch')
    s['DZ_DISPATCH'] = disp
    calls = find(img, '4eb9' + f'{disp:08x}')
    if len(calls) != 1:
        sys.exit(f'desert_ex: {len(calls)} calls of the stage dispatch, 1 expected')
    s['dispatch_call'] = calls[0]
    for i in range(5):
        s[f'DZ_H{i}'] = be32(img, disp + len(DISPATCH) // 2 + 4 * i)
    intro = s['DZ_INTRO']
    at = intro + 24
    if img[at - 6:at] != bytes.fromhex('4a3900ff0c84') or img[at:at + 2] != b'g\x00':
        sys.exit('desert_ex: the intro task has an unexpected shape')
    s['DZ_NOTGAME'] = at + 2 + struct.unpack('>h', img[at + 2:at + 4])[0]
    clear = s['DZ_CLEAR']
    s['DZ_DEMOEND'] = be16(img, clear + 6)
    tab = clear + 36
    if img[clear + 20:clear + 36] != bytes.fromhex('7000102d8cb2d040303b00064efb0002'):
        sys.exit('desert_ex: the clear task dispatch has an unexpected shape')
    s['DZ_STPCLEAR'] = tab + be16(img, tab)
    snd = find1(img, SOUND_STUB, 'intro cue stub')
    s['DZ_SOUND'] = snd + 6 + struct.unpack('>h', img[snd + 6:snd + 8])[0]
    for name, (pat, off, n, sym) in HOOKS.items():
        s['site_' + name] = find1(img, pat, name) + off
    po = find1(img, PAL_OBJ, 'sprite palettes')
    s['pal_obj'] = po + 12
    s['DZ_PALOBJ_TABLE'] = tab = be32(img, po + 12)
    for i in range(5):
        s[f'DZ_POBJ{i}'] = be32(img, tab + 4 * i)
    if s['DZ_POBJ0'] != tab + 20:
        sys.exit('desert_ex: the sprite palette table has an unexpected shape')
    s['DZ_OBJPAL'] = be32(img, s['DZ_POBJ0'] + 4)
    for i, layer in enumerate(('s1', 's2', 's3')):
        s[f'DZ_TAB_{layer.upper()}'] = be32(img, LAYER_TABLE_DIR + 4 * i)
    s['DZ_STARS2'] = be32(img, s.pop('stars2') + 2)
    import respawn_fix as RF
    if WATCH_SLOT in task_slots(img) or WATCH_SLOT == RF.SLOT:
        sys.exit(f'desert_ex: task slot {WATCH_SLOT:#x} is in use')
    return s

def collision_sets(img):
    """{set: (page table, type table, flag-page table, flag table, records)} from the routines' operands."""
    return {k: v[0] for k, v in collision_refs(img).items()}

def collision_refs(img):
    """{set: ((page table, type table, flag-page table, flag table, records), [address of each"""
    out = {}
    for k, routines in SET_ROUTINES.items():
        found, imms = ([], [])
        for r in routines:
            if img[r:r + 4] != bytes.fromhex('0c4007f7'):
                sys.exit(f'desert_ex: collision routine at {r:#x} has an unexpected shape')
            refs, a = ([], r)
            while a < r + 272 and len(refs) < 5:
                op = img[a:a + 2]
                if op == b'G\xfa':
                    refs.append(('pc', a + 2 + struct.unpack('>h', img[a + 2:a + 4])[0], a))
                    a += 4
                elif op == b'&|':
                    refs.append(('abs', be32(img, a + 2), a + 2))
                    a += 6
                else:
                    a += 2
            found.append(refs)
            if len(refs) > 1 and refs[1][0] == 'abs':
                imms.append(refs[1][2])
        first = found[0]
        if [t for t, _, _ in first] != ['pc', 'abs', 'pc', 'abs', 'abs']:
            sys.exit(f'desert_ex: collision set {k}: unexpected table references {first}')
        for other in found[1:]:
            if [v for _, v, _ in other][:2] != [v for _, v, _ in first][:2]:
                sys.exit(f'desert_ex: collision set {k}: its routines disagree on the tables')
        if len(imms) != len(routines):
            sys.exit(f'desert_ex: collision set {k}: a routine without its type table operand')
        out[k] = (tuple((v for _, v, _ in first)), imms)
    return out

def collision_tables(img):
    """Stock collision state: per set, the page count and the record types no entry references."""
    out = {}
    for k, (pg, ty, fpg, fl, rec) in collision_sets(img).items():
        pages = max(img[pg:pg + 32])
        present = set(img[ty:ty + pages * 256])
        out[k] = dict(pages=pages, free=[t for t in range(32, 256) if t not in present])
    return out

def stock_scroll3_codes(img):
    """(code, flips) of every entry of the five stage SCROLL3 records. A section entry is"""
    used = set()
    tab = be32(img, LAYER_TABLE_DIR + 8)
    for st in range(5):
        rec = tab + 14 * st
        grid, secs = (be32(img, rec + 2), be32(img, rec + 6))
        for s in range(max(img[grid:grid + 256]) + 1):
            for e in range(96):
                a = secs + 384 * s + 4 * e
                used.add((be16(img, a) & 16383, img[a + 3] >> 5 & 3))
    return used

def depth_records(top, bottom, left, right):
    """A tile's exposed surfaces (32x32 masks, row 0 = top: solid pixels with open"""

    def first(m, axis):
        return np.argmax(m, axis)

    def last(m, axis):
        return m.shape[axis] - 1 - np.argmax(np.flip(m, axis), axis)
    B = np.where(top.any(0), np.minimum(32 - first(top, 0), 31), 0)
    A = np.where(bottom.any(0), np.minimum(last(bottom, 0) + 1, 31), 0)
    lu, ru = (left[::-1], right[::-1])
    D = np.where(lu.any(1), np.maximum(31 - first(lu, 1), 1), 0)
    C = np.where(ru.any(1), np.maximum(last(ru, 1), 1), 0)
    return dict(A=tuple((int(v) for v in A)), B=tuple((int(v) for v in B)), C=tuple((int(v) for v in C)), D=tuple((int(v) for v in D)))
STEP_MIN = 3
STEP_MAX = 16
STEP_RUN = 2
CLEAR = 64
GAP = 32

def fill_gaps(hs):
    """Fill each column's open runs shorter than GAP pixels that have solid above and below."""
    H, W = hs.shape
    n = 0
    for x in range(W):
        c = hs[:, x]
        edges = np.flatnonzero(np.diff(c.astype(np.int8)))
        opens = [e + 1 for e in edges if c[e] and (not c[e + 1])]
        for o in opens:
            below = np.flatnonzero(c[o:])
            if len(below) and below[0] < GAP:
                c[o:o + below[0]] = True
                n += int(below[0])
    return n

def ramp_steps(hs):
    """The real steps left in the PC Engine floor (pce_floor_masks: the dunes are"""
    H, W = hs.shape
    tops = [set(np.nonzero(hs[:, x] & ~np.concatenate(([False], hs[:-1, x])))[0].tolist()) for x in range(W)]
    jobs = []
    for x in range(W - 1):
        for r in tops[x]:
            for r2 in tops[x + 1]:
                h = r - r2
                if STEP_MIN <= h <= STEP_MAX and r2 not in tops[x] and (not hs[r2:r, x].any()):
                    jobs.append((x, r, h, -1))
                h = r2 - r
                if STEP_MIN <= h <= STEP_MAX and r not in tops[x + 1] and (not hs[r:r2, x + 1].any()):
                    jobs.append((x + 1, r2, h, 1))
    for x, r, h, d in jobs:
        w = 0
        while w < STEP_RUN * h and 0 <= x + d * w < W and (r in tops[x + d * w]) and (not hs[max(r - h - CLEAR, 0):r, x + d * w].any()):
            w += 1
        for k in range(w):
            s = r - int(round(h * (w - k) / (w + 1)))
            hs[s:r, x + d * k] = True
    return len(jobs)
SURFACE_STEP = 2

def smooth_slopes(hs):
    """Even the column steps of every floor surface (PHASE0_FINDINGS.md "The desert's camera"). The"""
    H, W = hs.shape
    tops = [np.flatnonzero(hs[:, x] & ~np.concatenate(([False], hs[:-1, x]))) for x in range(W)]
    nxt, has_prev = ({}, set())
    for x in range(W - 1):
        for r in tops[x]:
            near = [r2 for r2 in tops[x + 1] if abs(int(r2) - int(r)) <= SURFACE_STEP]
            if near:
                r2 = min(near, key=lambda v: abs(int(v) - int(r)))
                if (x + 1, r2) not in has_prev:
                    nxt[x, r] = r2
                    has_prev.add((x + 1, r2))
    new = []
    for x in range(W):
        for r in tops[x]:
            if (x, r) in has_prev:
                continue
            chain = [(x, int(r))]
            while (chain[-1][0], chain[-1][1]) in nxt:
                cx, cr = chain[-1]
                chain.append((cx + 1, int(nxt[cx, cr])))
            rows = [c[1] for c in chain]
            for i in range(1, len(chain) - 1):
                v = int(np.floor((rows[i - 1] + rows[i] + rows[i + 1]) / 3 + 0.5))
                if v != rows[i]:
                    new.append((chain[i][0], rows[i], v))
    for x, r, v in new:
        if v < r:
            hs[v:r, x] = True
        else:
            hs[r:v, x] = False
    return len(new)

def exposure(solid):
    """Solid pixels open above, below, left, right (outside the map counts as open)."""
    p = np.pad(solid, 1)
    return (solid & ~p[:-2, 1:-1], solid & ~p[2:, 1:-1], solid & ~p[1:-1, :-2], solid & ~p[1:-1, 2:])

def slope_kind(vals):
    """Stock surface kinds (record byte 0) by the slope of the heights (up = larger): rising"""
    xs = [i for i, v in enumerate(vals) if v]
    if len(xs) < 2:
        return 1
    s = (vals[xs[-1]] - vals[xs[0]]) / (xs[-1] - xs[0])
    if s >= 1.5:
        return 4
    if s <= -1.5:
        return 5
    if s > 0.75:
        return 3
    if s > 0:
        return 2
    if s < -0.75:
        return 6
    if s < 0:
        return 7
    return 1

def entry_of(setname, vals):
    """(type value or None for a record, record bytes)"""
    if not any(vals):
        return (0, None)
    if len(set(vals)) == 1:
        return (vals[0], None)
    kind = slope_kind(vals) if setname in 'AB' else 0
    return (None, bytes([kind]) + bytes(vals))
PCE_FLOOR_TABLE = 25752
PCE_FLOOR_TEST = (22373, '8d942d2016574c9161')
PCE_FLOOR_READ = (25018, 'bd9864')
PCE_HIRYU_SOLID = 128
PCE_ITEM_SOLID = 64

def pce_floor_masks(entries, census, mask=PCE_HIRYU_SOLID):
    """{map name: the solid mask (PC Engine pixels) of the floor test with `mask` (Hiryu's by"""
    import pce_desert_convert as PC
    import pce_desert_maps as M
    out = {}
    for (w, r0, c0), v in entries.items():
        if v is None:
            continue
        s = v[0]
        c = (Path(census) / f"pce_{s['tag']}_ram_0d0000.bin").read_bytes()
        for bank, (at, code) in ((104, PCE_FLOOR_TEST), (105, PCE_FLOOR_READ)):
            if M.bank(c, bank, at & 8191, len(code) // 2) != bytes.fromhex(code):
                sys.exit(f'desert_ex: the PC Engine floor test at {at:#x} has an unexpected shape')
        hiryu = M.bank(c, 112)
        if hiryu.count(bytes.fromhex('a980206557')) < 4:
            sys.exit('desert_ex: the PC Engine Hiryu floor tests (mask 0x80) not found in bank 0x70')
        shapes = M.bank(c, M.CODE_BANK, PC.SHAPES_AT - 24576, PC.SHAPES * 16)
        f = dict(s, class_table=M.bank(c, M.CODE_BANK, PCE_FLOOR_TABLE - 24576, 256))
        sol, fl = PC.solid_mask(f, shapes)
        out[M.name_of(s)] = sol & (fl & mask != 0)
    return out

def actor_floors(census, decoded, maps=None, entries=None):
    """The floor the map-list actors read at build time, from the census's floor table with the"""
    import desert_actors_ex as DA
    import pce_desert_convert as PC
    import pce_desert_maps as M
    if maps is None:
        maps, _ = PC.load_maps(census)
    if entries is None:
        _, entries = M.verified_maps(Path(census))
    h = decoded['handlers']
    if h['it_mask'] != PCE_ITEM_SOLID or h['sw_probe_a']['mask'] != PCE_ITEM_SOLID:
        sys.exit("desert_ex: the item container's or the sandworm's floor test changed its mask")
    names = [m[0] for m in maps]
    origins, secs = ({m[0]: (m[1], m[2]) for m in maps}, [names[k] for k in SEC_MAP])
    masks = pce_floor_masks(entries, census, PCE_ITEM_SOLID)
    import pce_desert_spawns as SP
    script = SP.decode(sorted(Path(census).glob('pce_*_checkpoint_01_ram_0d0000.bin'))[0].read_bytes())
    jeep = next((x for st in script[3]['states'] for x in st['steps'] if x['op'] == 'spawn_actor' and x['type'] == '0x48'))
    return dict(rests=DA.container_rests(decoded['map_lists'], origins, secs, masks, h), chains=DA.worm_chains(decoded['map_lists'], origins, secs, masks, h), robots=DA.robot_area(pce_collision(census, 2, maps, entries), decoded), walls=DA.jeep_walls(pce_collision(census, 3, maps, entries), h, decoded['step6'], (jeep['x'], jeep['y'])))
PCE_WALL_TESTS = {'right': (22391, '8d942d2016574c7162', 25242, 'bd9866', 26264), 'left': (22400, '8d942d2016574cdc62', 25359, 'bd9867', 26520)}
PCE_SHAPES = 25496

class PceCollision:
    """The PC Engine's floor and wall tests on one section's map, as the census holds it (MEASURED by a"""

    def __init__(self, s, code, origin):
        import pce_desert_maps as M
        self.origin = origin
        self.cls = np.frombuffer(s['collision'], np.uint8)[np.minimum(s['map'], 511)] & 127
        self.valid = s['map'] < len(s['defs'])
        self.tables = {'floor': M.bank(code, M.CODE_BANK, PCE_FLOOR_TABLE - 24576, 256)}
        for side, (entry, pat, read, rpat, table) in PCE_WALL_TESTS.items():
            if M.bank(code, 104, entry & 8191, len(pat) // 2) != bytes.fromhex(pat) or M.bank(code, 105, read & 8191, len(rpat) // 2) != bytes.fromhex(rpat):
                sys.exit(f'desert_ex: the PC Engine {side} wall test has an unexpected shape')
            self.tables[side] = M.bank(code, M.CODE_BANK, table - 24576, 256)
        self.shapes = M.bank(code, M.CODE_BANK, PCE_SHAPES - 24576, 256)
        self.seen = None

    def klass(self, x, y):
        """The class of the metatile at (x, y) (0 outside the map or past its definitions)."""
        r, c = (y - self.origin[1] >> 4, x - self.origin[0] >> 4)
        if self.seen is not None:
            self.seen.add((r, c))
        if 0 <= r < self.cls.shape[0] and 0 <= c < self.cls.shape[1] and self.valid[r, c]:
            return int(self.cls[r, c])
        return 0

    def _part(self, table, k, mask, at, t):
        """0x6351: (distance, found) in one tile of class k."""
        sh, fl = (self.tables[table][2 * k], self.tables[table][2 * k + 1])
        if mask & fl:
            v = self.shapes[16 * (sh & 15) + at]
            if v < 128 and v >= t:
                return (v - t, True)
        return (16 - t, False)

    def floor(self, x, y, mask):
        k = self.klass(x, y)
        d, found = self._part('floor', k, mask, x & 15, y & 15)
        if found:
            return (d, self.tables['floor'][2 * k + 1])
        k = self.klass(x, y + 16)
        d2, _ = self._part('floor', k, mask, x & 15, 0)
        return (d + d2, self.tables['floor'][2 * k + 1])

    def wall_right(self, x, y, mask):
        k = self.klass(x, y)
        d, found = self._part('right', k, mask, y & 15, x & 15)
        if found:
            return (d, self.tables['right'][2 * k + 1])
        k = self.klass(x + 16, y)
        d2, _ = self._part('right', k, mask, y & 15, 0)
        return (d + d2, self.tables['right'][2 * k + 1])

    def wall_left(self, x, y, mask):
        x0, t = (x - 16, 0) if x & 15 == 0 else (x, 16 - (x & 15))
        k = self.klass(x0, y)
        d, found = self._part('left', k, mask, y & 15, t)
        if found:
            return (d, self.tables['left'][2 * k + 1])
        k = self.klass(x0 - 16, y)
        d2, _ = self._part('left', k, mask, y & 15, 0)
        return (d + d2, self.tables['left'][2 * k + 1])

def pce_collision(census, sec, maps=None, entries=None):
    """PceCollision for section `sec`'s map, from the checkpoint dump that verifies it (pce_desert_maps);"""
    import pce_desert_convert as PC
    import pce_desert_maps as M
    if maps is None:
        maps, _ = PC.load_maps(Path(census))
    if entries is None:
        _, entries = M.verified_maps(Path(census))
    name, x0, y0 = maps[SEC_MAP[sec]][:3]
    s = next((v[0] for v in entries.values() if v and M.name_of(v[0]) == name))
    code = (Path(census) / f"pce_{s['tag']}_ram_0d0000.bin").read_bytes()
    for bank, (at, pat) in ((104, PCE_FLOOR_TEST), (105, PCE_FLOOR_READ)):
        if M.bank(code, bank, at & 8191, len(pat) // 2) != bytes.fromhex(pat):
            sys.exit(f'desert_ex: the PC Engine floor test at {at:#x} has an unexpected shape')
    return PceCollision(s, code, (x0, y0))

def tile_solids(maps, floors):
    """Per arcade tile (name, col, row): the four exposed-surface 32x32 masks of the"""
    import pce_desert_convert as PC
    out = {}
    for name, x0, y0, img, colors, sol, fl in maps:
        wsol = PC.widen_copy(floors[name])
        if floors[name].shape != sol.shape:
            sys.exit(f'desert_ex: {name}: the floor mask and the map differ in size')
        X0 = x0 * 3 // 2
        left, top = (X0 % 32, y0 % 32)
        H = top + wsol.shape[0] + -(top + wsol.shape[0]) % 32
        W = left + wsol.shape[1] + -(left + wsol.shape[1]) % 32
        hs = np.zeros((H, W), bool)
        hs[top:top + wsol.shape[0], left:left + wsol.shape[1]] = wsol
        fill_gaps(hs)
        ramp_steps(hs)
        smooth_slopes(hs)
        ex = exposure(hs)
        c0, r0 = ((X0 - left) // 32, (y0 - top) // 32)
        for ty in range(H // 32):
            for tx in range(W // 32):
                t = tuple((e[ty * 32:ty * 32 + 32, tx * 32:tx * 32 + 32] for e in ex))
                if any((m.any() for m in t)):
                    out[name, c0 + tx, r0 + ty] = t
    return out
CYCLE_ID0 = 10000
S1_WORLD = 3
S3_EXTRA = (15744, 16351)

def section1_worlds(census, maps, entries, decoded):
    """Section 1's 4 worlds for pce_desert_convert.convert (extra: (name, x0, y0, color ids, colors, solid, flags)),"""
    import pce_desert_convert as PC
    import pce_desert_maps as M
    import pce_vdc as pv
    import pce_desert_actors as PA
    census = Path(census)
    h, t7 = (decoded['handlers'], decoded['step7'])
    name0, x0, y0, img0, colors0, sol0, fl0 = maps[SEC_MAP[1]]
    s1 = next((v[0] for v in entries.values() if v and M.name_of(v[0]) == name0))
    cp2 = sorted(census.glob('pce_*_checkpoint_02_ram_0d0000.bin'))
    if len(cp2) != 1:
        sys.exit('desert_ex: no checkpoint 2 in the desert census')
    frame = int(cp2[0].name.split('_')[1])
    s2 = M.section(census, frame, f'{frame}_checkpoint_02')
    if (s2['width'], s2['row0'], s2['col0'], s2['section']) != (s1['width'], s1['row0'], s1['col0'], 1):
        sys.exit('desert_ex: checkpoint 2 is not section 1 on map 0')
    scene = sorted(census.glob('pce_*_scene.vdc'), key=lambda q: abs(int(q.name.split('_')[1]) - frame))[0]
    if abs(int(scene.name.split('_')[1]) - frame) > 8:
        sys.exit('desert_ex: no scene dump at checkpoint 2')
    d2 = pv.load(scene)
    code2 = cp2[0].read_bytes()
    for bank, (at, pat) in ((104, PCE_FLOOR_TEST), (105, PCE_FLOOR_READ)):
        if M.bank(code2, bank, at & 8191, len(pat) // 2) != bytes.fromhex(pat):
            sys.exit(f'desert_ex: the PC Engine floor test at {at:#x} has an unexpected shape')
    shapes = M.bank(code2, M.CODE_BANK, PC.SHAPES_AT - 24576, PC.SHAPES * 16)
    floor_table = M.bank(code2, M.CODE_BANK, PCE_FLOOR_TABLE - 24576, 256)
    cyc = tuple((CYCLE_ID0 + c for c in range(6)))
    first = 16 * PA.CYCLE_PALETTE + PA.CYCLE_FIRST
    if [int(v) for v in d2['pal'][first:first + 6]] != t7['pl_cycle'][0]:
        sys.exit("desert_ex: checkpoint 2's BG palette 9 is not the cycle's phase 0")
    colors = dict(colors0)
    colors.update({cid: t7['pl_cycle'][0][c] for c, cid in enumerate(cyc)})
    vce = {v: k for k, v in colors0.items()}
    split = h['pit_x'] - x0
    r0, c0 = ((h['pit_y'] - y0) // 16, (h['pit_x'] - x0) // 16)
    base_floor = pce_floor_masks(entries, census)[name0]
    out, floors = ([], {})
    for k, cells in enumerate(t7['pit']):
        m = s1['map'].copy()
        m[r0:r0 + h['pit_h'], c0:c0 + h['pit_w']] = np.array(cells, m.dtype).reshape(h['pit_h'], h['pit_w'])
        sk = dict(s2, map=m)
        _, _, _, idx = M.render(sk, d2)
        nz = idx & 15 != 0
        cyc_px = nz & (idx >> 4 == PA.CYCLE_PALETTE) & (idx & 15 >= PA.CYCLE_FIRST) & (idx & 15 < PA.CYCLE_FIRST + 6)
        if cyc_px[:, :split].any():
            sys.exit("desert_ex: the flowing sand's palette outside the pit")
        sel = nz & ~cyc_px
        for v in sorted({int(x) for x in np.unique(d2['pal'][idx[sel]])}):
            if v not in vce:
                vce[v] = max((c for c in colors if c < CYCLE_ID0)) + 1
                colors[vce[v]] = v
        lut = np.zeros(512, np.int64)
        for v, i in vce.items():
            lut[v] = i
        cid = np.zeros(idx.shape, np.int64)
        cid[sel] = lut[d2['pal'][idx[sel]]]
        cid[cyc_px] = CYCLE_ID0 + (idx[cyc_px] & 15) - PA.CYCLE_FIRST
        img = img0.astype(np.int64)
        img[:, split:] = cid[:, split:]
        sol, fl = PC.solid_mask(sk, shapes)
        sol = np.concatenate([sol0[:, :split], sol[:, split:]], 1)
        fl = np.concatenate([fl0[:, :split], fl[:, split:]], 1)
        fs, ff = PC.solid_mask(dict(sk, class_table=floor_table), shapes)
        floor = np.concatenate([base_floor[:, :split], (fs & (ff & PCE_HIRYU_SOLID != 0))[:, split:]], 1)
        name = f'{name0}_s1v{k}'
        out.append((name, x0, y0, img, colors, sol, fl))
        floors[name] = floor
    return (out, floors, cyc)
HULL_BOX = (5616, 1056, 5824, 1152)
HULL_CLEAR = (5560, 1000, 5880, 1152)
S4_WORLD = 7

def tank_hull(maps, entries, home):
    """The hull: (its PC Engine color index image (16 palette + pen) in HULL_BOX, its top-left from the tank's home, the"""
    import pce_desert_maps as M
    name, x0, y0, img = maps[SEC_MAP[4]][:4]
    s, d = next(((v[0], v[1]) for v in entries.values() if v and M.name_of(v[0]) == name))
    idx = M.render(s, d)[3]
    x_0, y_0, x_1, y_1 = HULL_BOX
    c0, r0, c1, r1 = HULL_CLEAR
    ring = idx[r0 - y0:r1 - y0, c0 - x0:c1 - x0] & 15 != 0
    ring[y_0 - r0:y_1 - r0, x_0 - c0:x_1 - c0] = False
    if ring.any():
        sys.exit("desert_ex: art beside the tank's hull in map 2")
    hull = np.where(idx[y_0 - y0:y_1 - y0, x_0 - x0:x_1 - x0] & 15 != 0, idx[y_0 - y0:y_1 - y0, x_0 - x0:x_1 - x0], 0)
    pal = sorted({int(v) >> 4 for v in np.unique(hull[hull != 0])})
    if len(pal) != 1:
        sys.exit(f'desert_ex: the hull uses BG palettes {pal}')
    out = img.copy()
    out[y_0 - y0:y_1 - y0, x_0 - x0:x_1 - x0] = 0
    if (img[y_0 - y0:y_1 - y0, x_0 - x0:x_1 - x0] != 0).sum() != (hull != 0).sum():
        sys.exit("desert_ex: the hull's pixels differ between the map's image and its color indices")
    return (hull, (x_0 - home[0], y_0 - home[1]), [int(v) for v in d['pal'][16 * pal[0]:16 * pal[0] + 16]], out)

def check_world_art(world, owner, region, pal_words, img, colors, x0, y0, col0=105):
    """The display grid of one of section 1's worlds (raw entries, as dz_column copies them; owner: the world whose"""
    import pce_desert_convert as PC
    wimg = PC.widen(img)
    lut = np.zeros(max(colors) + 1, np.uint32)
    for k, v in colors.items():
        lut[k] = G.cps_color(v)
    X0 = arc_x(x0)
    g, s = (world['disp_grid'], b''.join(owner['disp_secs']))
    bad = 0
    for col in range(col0, (X0 + wimg.shape[1] + 31) // 32):
        gx, sc = divmod(col, 12)
        for vr in range(64):
            gy, sr = divmod(63 - vr, 8)
            code, attr = struct.unpack('>HH', s[g[gy * 32 + gx] * 384 + (sr * 12 + sc) * 4:][:4])
            want = np.zeros((32, 32), np.uint32)
            ys, xs = (vr * 32 - y0, col * 32 - X0)
            a, b = (max(ys, 0), min(ys + 32, wimg.shape[0]))
            c, d = (max(xs, 0), min(xs + 32, wimg.shape[1]))
            if a < b and c < d:
                want[a - ys:b - ys, c - xs:d - xs] = lut[wimg[a:b, c:d]] * (wimg[a:b, c:d] != 0)
            if code == TRANSPARENT_CODE:
                got = np.zeros((32, 32), np.uint32)
            else:
                pens = G.get_tile(region, G.ex_offset('scr3', code), 32)
                if attr >> 5 & 1:
                    pens = pens[:, ::-1]
                if attr >> 6 & 1:
                    pens = pens[::-1]
                got = np.where(pens == 15, 0, pal_words[attr & 31][np.minimum(pens, 14)])
            bad += int((got != want).sum())
    if bad:
        sys.exit(f"desert_ex: {world['name']}: {bad} pixels differ from its image")

def pit_cells(worlds, k0):
    """dz_pit_tab: per variant 1-3 (worlds k0 + 1 ..), the cells it changes from the one before: (world column, offset"""

    def cells(w, key, secs):
        g, s = (w[key], b''.join(secs))
        out = {}
        for gy in range(8):
            for gx in range(32):
                body = s[g[gy * 32 + gx] * 384:][:384]
                for sr in range(8):
                    for sc in range(12):
                        out[gx * 12 + sc, 63 - (gy * 8 + sr)] = body[(sr * 12 + sc) * 4:][:4]
        return out
    lists, prev = ([], None)
    for k in range(4):
        w = worlds[k0 + k]
        owner = worlds[w.get('shares', k0 + k)]
        now = (cells(w, 'disp_grid', owner['disp_secs']), cells(w, 'coll_grid', owner['coll_secs']))
        if prev is not None:
            lists.append([(c, (c & 63) * 32 + (r >> 3) * 2048 + (r & 7) * 4, now[0][c, r], now[1][c, r]) for c, r in sorted(now[0]) if now[0][c, r] != prev[0][c, r] or now[1][c, r] != prev[1][c, r]])
        prev = now
    return lists
DZ_SLOT = 5 + 24
DZ_FLIPS = 3

def collision_codes(solids, img, classes=None):
    """A code of the desert slot for each distinct surface class (its entries in all four sets). classes: the classes"""
    sets = collision_sets(img)
    for k, (pg, ty, fpg, fl, rec) in sets.items():
        if img[pg + DZ_SLOT] or img[fpg + DZ_SLOT]:
            sys.exit(f'desert_ex: collision set {k}: the slot {DZ_SLOT} has a page (unsupported revision)')
    taken = {c for c, f in stock_scroll3_codes(img) if f == DZ_FLIPS and c >> 8 == DZ_SLOT - 24}
    pool = [c for c in range(1280, 1536) if c not in taken]
    classes, cell_class = (dict(classes or {}), {})
    for key, t in sorted(solids.items()):
        d = depth_records(*t)
        k = tuple((entry_of(s, d[s]) for s in 'ABCD'))
        if k not in classes:
            if len(classes) >= len(pool):
                sys.exit('desert_ex: more desert surface classes than codes in the desert slot')
            classes[k] = pool[len(classes)]
        cell_class[key] = classes[k]
    return (classes, cell_class)

def collision_patches(classes, img):
    """One region's collision data: per set the relocated type table (the stock pages,"""
    tabs, sets = (collision_tables(img), collision_sets(img))
    patches, rec_type, tables = ([], {k: {} for k in sets}, {})
    free = {k: list(tabs[k]['free']) for k in sets}
    page = {k: bytearray(256) for k in sets}
    for key, code in sorted(classes.items(), key=lambda kv: kv[1]):
        for si, sname in enumerate('ABCD'):
            pg, ty, fpg, fl, recs = sets[sname]
            value, rec = key[si]
            if rec is not None:
                if rec not in rec_type[sname]:
                    if not free[sname]:
                        sys.exit(f'desert_ex: set {sname}: no free collision type for a new record')
                    t = free[sname].pop(0)
                    rec_type[sname][rec] = t
                    patches.append((recs + (t - 32) * 33, rec))
                value = rec_type[sname][rec]
            page[sname][code & 255] = value
    for k, (pg, ty, fpg, fl, recs) in sets.items():
        n = tabs[k]['pages']
        tables[k] = dict(data=bytes(img[ty:ty + n * 256]) + bytes(page[k]), page=n + 1)
    return dict(tables=tables, records=patches, records_per_set={k: len(v) for k, v in rec_type.items()})

def emit_grid(cells, name, empty, share=None):
    """Grid and sections (pce_desert_convert.emit's format) from {(col, row_from_top): entry bytes};"""
    sections, grid = (share if share is not None else [empty * 96], bytearray(256))
    if sections[0] != empty * 96:
        sys.exit(f'desert_ex: {name}: the shared sections do not start with the empty one')
    index = {body: i for i, body in enumerate(sections) if i}
    for gx in range(32):
        for gy in range(8):
            body = bytearray()
            for sr in range(8):
                for sc in range(12):
                    wr = gy * 8 + sr
                    body += cells.get((gx * 12 + sc, 63 - wr), empty)
            body = bytes(body)
            if body == sections[0]:
                continue
            if body not in index:
                index[body] = len(sections)
                sections.append(body)
            grid[gy * 32 + gx] = index[body]
    if len(sections) > 256:
        sys.exit(f'desert_ex: {name}: {len(sections)} sections')
    return (bytes(grid), sections)
CAM_TOP = 1808
PCE_CAM_OFFSET = 0
FOLLOW = (192, 176, 144, 112)
LAYER_WORD = 5002
LAYER_FLAGS = (2, 0, 1)
LAYER_WORD_S4 = LAYER_WORD | 4
TIMER = 90
SEC_MAP = [0, 0, 1, 2, 2]
OPS = dict(end=0, trigger=1, limits=2, music=3, area=4, map=5, clear=6, settle=7, timer=8, actors=9, wait=10, portrait=11, waitpt=12, once=13, delay=14, pit=15)
OFFICER_PORTRAIT = 6
S1_AFTER_OFFICER = 22
S1_SKIP_FROM = 8
COMMANDER_PORTRAIT = 7
S4_FIGHT_FROM = 7
S4_AFTER_TANK = 14
RESTART_SIZE = 46

def arc_x(x):
    return x * 3 // 2

def arc_y(y_down):
    """PC Engine world Y (down) -> arcade world Y (up): collision row 63 - (y >> 5) (0x1858)."""
    return 2047 - y_down

def layer_y(pce_cam_y):
    return CAM_TOP - (pce_cam_y + PCE_CAM_OFFSET)

def bounds(step):
    """PC Engine camera bounds (picture top-left, Y down) -> (X min, X max, Y min, Y max) in layer terms."""
    (y0, y1), (x0, x1) = (step['y'], step['x'])
    return (arc_x(x0), arc_x(x1), layer_y(y1), layer_y(y0))

def box(step):
    """PC Engine Hiryu trigger box -> arcade world box (X min, X max, Y min, Y max)."""
    (y0, y1), (x0, x1) = (step['hiryu_y'], step['hiryu_x'])
    return (arc_x(x0), min(arc_x(x1), 32767), arc_y(min(y1, 2047)), arc_y(max(y0, 0)))

def flow(dec, h):
    """Per section: steps for asm/desert.s dz_sections, from the decoded PC Engine scripts."""

    def one(s, k, op, n=0):
        hits = [x for x in dec[s]['states'][k]['steps'] if x['op'] == op]
        if len(hits) <= n:
            sys.exit(f'desert_ex: section {s} state {k}: no {op} #{n} (script changed?)')
        return hits[n]

    def B(s, k):
        return ('limits',) + bounds(one(s, k, 'camera_bounds'))

    def T(s, k):
        return ('trigger',) + box(one(s, k, 'trigger'))
    t, settle = (('timer', TIMER), ('settle',))
    if one(3, 3, 'call')['target'] != '0x76AE' or not any((x['op'] == 'spawn_actor' and x['type'] == '0x48' and (x['once_id'] == h['s3_once']) for x in dec[3]['states'][0]['steps'])):
        sys.exit('desert_ex: section 3 no longer places the jeep and waits on its once status')
    pt = one(1, 2, 'spawn_actor')
    pt4 = one(4, 2, 'spawn_actor')
    if (pt['type'], pt['param'], pt['once_id']) != ('0x6B', OFFICER_PORTRAIT, h['s1_portrait_once']) or [x['type'] for x in dec[1]['states'][0]['steps'] if x['op'] == 'spawn_actor'] != ['0x45', '0x58'] or h['s1_wait_once'] != h['s1_go_a'] or (h['pit_n'] != 4):
        sys.exit('desert_ex: section 1 no longer places the officer, its portrait and the sand-pull')
    every = h['pit_period'] + 1
    opening = [('delay', 2 * (h['s1_open_wait'] + every))]
    for k in range(1, h['pit_n']):
        opening += [('pit', k)] + ([('delay', 2 * every)] if k < h['pit_n'] - 1 else [])
    opening += [('delay', 2 * (h['s1_open_t'] - every * (h['pit_n'] - 1)))]
    out = reachable([[t, ('music', SEC_MUSIC[0]), ('actors', 0), B(0, 0), T(0, 1), B(0, 1), settle, ('area', 1)], [t, ('music', SEC_MUSIC[1]), ('map', S1_WORLD), ('actors', 3), B(1, 0), T(1, 1), B(1, 1), ('delay', 2 * h['s1_delay']), settle, ('portrait', OFFICER_PORTRAIT), ('waitpt',), ('once', h['s1_go_a'], h['s1_go_status']), ('once', h['s1_go_b'], h['s1_go_status'])] + opening + [B(1, 4), ('wait', h['s1_wait_once']), B(1, 5), T(1, 6), B(1, 6), settle, ('map', SEC_MAP[2]), ('area', 2)], [t, ('music', SEC_MUSIC[2]), ('actors', 1), B(2, 0), T(2, 1), B(2, 1), settle, ('map', SEC_MAP[3]), ('area', 3)], [t, ('music', SEC_MUSIC[3]), B(3, 0), ('actors', 2), ('wait', h['s3_once']), B(3, 3), T(3, 4), B(3, 4), settle, ('area', 4)], [t, ('music', SEC_MUSIC[4]), ('map', S4_WORLD), ('actors', 4), B(4, 0), T(4, 1), B(4, 1), settle, ('portrait', COMMANDER_PORTRAIT), ('waitpt',), ('once', h['s4_go_a'], h['s4_go_status']), ('once', h['s4_go_b'], h['s4_go_status']), B(4, 3), ('wait', h['s4_wait_once']), ('delay', 2 * h['s4_delay']), ('clear',)]])
    if [x['type'] for x in dec[4]['states'][0]['steps'] if x['op'] == 'spawn_actor'] != ['0x4C', '0x4A', '0x6E'] or (pt4['type'], pt4['param'], pt4['once_id']) != ('0x6B', COMMANDER_PORTRAIT, h['s4_portrait_once']) or h['s4_wait_once'] != h['s4_go_b'] or (h['s4_wait_status'] != h['s3_status_a']) or (h['s4_clear'] != 1):
        sys.exit('desert_ex: section 4 no longer places the commander, the tank, the strip and portrait 7, or waits on the tank')
    if out[4][S4_FIGHT_FROM:S4_FIGHT_FROM + 2] != [settle, ('portrait', COMMANDER_PORTRAIT)] or out[4][S4_AFTER_TANK - 1][0] != 'wait' or out[4][S4_AFTER_TANK][0] != 'delay':
        sys.exit("desert_ex: section 4's fight steps moved (S4_FIGHT_FROM, S4_AFTER_TANK)")
    if out[1][S1_AFTER_OFFICER - 1][0] != 'wait' or out[1][S1_AFTER_OFFICER] != B(1, 5) or out[1][S1_SKIP_FROM:S1_SKIP_FROM + 2] != [settle, ('portrait', OFFICER_PORTRAIT)]:
        sys.exit("desert_ex: section 1's officer steps moved (S1_SKIP_FROM, S1_AFTER_OFFICER)")
    return out
REACH = 349
REACH_MARGIN = 16

def reachable(sections):
    """Each trigger that starts beyond Hiryu's reach under the camera limits before it moves to"""
    out = []
    for sec in sections:
        lim, steps = (None, [])
        for st in sec:
            if st[0] == 'limits':
                lim = st
            elif st[0] == 'trigger' and lim is not None and (st[1] > lim[2] + REACH - REACH_MARGIN):
                st = ('trigger', lim[2] + REACH - REACH_MARGIN) + st[2:]
            steps.append(st)
        out.append(steps)
    return out

def checkpoints(census):
    """{checkpoint 1-5: dict(cam_x, cam_y, x, y)} from the census RAM dumps (Hiryu: actor slot 0, 0xCE00)."""
    out = {}
    for ram in sorted(census.glob('pce_*_checkpoint_*_ram_1f0000.bin')):
        r = ram.read_bytes()
        a = (ram.parent / ram.name.replace('_1f0000', '_100000')).read_bytes()
        k = r[3205]
        o = 49152 + 3584
        out[k] = dict(cam_y=r[3468] | r[3469] << 8, cam_x=r[3470] | r[3471] << 8, y=a[o + 4] | a[o + 5] << 8, x=a[o + 6] | a[o + 7] << 8, section=r[3339])
    if sorted(out) != [1, 2, 3, 4, 5]:
        sys.exit(f'desert_ex: census checkpoints {sorted(out)}, 1-5 expected')
    return out

def stock_follow(img):
    """[(record address, limits, follow box)] of every stock restart record, both found the way the"""
    loader = find1(img, ROUTINES['DZ_CPLOAD'], 'the checkpoint loader')
    out, i = ([], 0)
    while True:
        i = img.find(bytes.fromhex('43fa00066000'), i + 2, 524288)
        if i < 0:
            return out
        if i + 6 + int.from_bytes(img[i + 6:i + 8], 'big', signed=True) == loader:
            r = img[i + 8:i + 8 + 44]
            out.append((i + 8, struct.unpack('>4H', r[20:28]), struct.unpack('>4H', r[28:36])))

def follow_ok(box):
    """A follow box with a dead zone in both axes (stock_follow)."""
    return box[0] > box[1] and box[2] > box[3]

def restart_records(cps, steps, worlds=None):
    """Area 0 (the start) = area 1; areas 1-5 = sections 0-4 at their PC Engine checkpoints. worlds: {area: the world"""
    recs = []
    for area in range(6):
        sec = max(area - 1, 0)
        cp = cps[sec + 1]
        px, py = (arc_x(cp['x']), arc_y(cp['y']))
        lim = next((s for s in steps[sec] if s[0] == 'limits'))[1:]
        cx = min(max(px - (FOLLOW[0] + FOLLOW[1]) // 2, lim[0]), lim[1])
        cy = min(max(py - (FOLLOW[2] + FOLLOW[3]) // 2, lim[2]), lim[3])
        b = struct.pack('>8H', px, py, cx, cy, 0, 0, 0, 0)
        b += bytes(LAYER_FLAGS) + b'\x00'
        b += struct.pack('>4H', lim[1], lim[0], lim[3], lim[2])
        b += struct.pack('>4H', *FOLLOW)
        b += bytes(4)
        b += struct.pack('>H', LAYER_WORD_S4 if area == 5 else LAYER_WORD) + bytes([0, sec + 1])
        b += struct.pack('>H', (worlds or {}).get(area, SEC_MAP[sec]))
        assert len(b) == RESTART_SIZE
        recs.append(b)
    return recs

def step_bytes(step):
    op = OPS[step[0]]
    args = [a & 65535 for a in step[1:]]
    return struct.pack(f'>H{len(args)}H', op, *args).ljust(16, b'\x00')

def prepare(census, rom_dir):
    """The desert stage data (all inputs checked); see the module docstring."""
    import pce_desert_convert as PC
    import pce_desert_maps as M
    import pce_desert_spawns as SP
    census, rom_dir = (Path(census), Path(rom_dir))
    imgs = program_images(rom_dir)
    ua = imgs['striderua']
    jr = imgs['striderjr']
    if ua[524288:] != jr[524288:]:
        sys.exit('desert_ex: the regional data ROMs differ (stage maps and records assumed shared)')
    sua, sjr = (collision_sets(ua), collision_sets(jr))
    for k, (pg, ty, fpg, fl, rec) in sua.items():
        p = ua[pg + (CLEAR_CODE >> 8)]
        if p and ua[ty + (p - 1) * 256 + (CLEAR_CODE & 255)]:
            sys.exit(f'desert_ex: the blank code {CLEAR_CODE:#x} has collision in set {k}')
    for k in sua:
        pages, fpages = (max(ua[sua[k][0]:sua[k][0] + 32]), max(ua[sua[k][2]:sua[k][2] + 32]))
        for i, n in ((0, 32), (1, pages * 256), (2, 32), (3, fpages * 256), (4, 224 * 33)):
            if ua[sua[k][i]:sua[k][i] + n] != jr[sjr[k][i]:sjr[k][i] + n]:
                sys.exit(f'desert_ex: collision set {k}: table {i} differs between regions')
    maps, shapes = PC.load_maps(census)
    rows, entries = M.verified_maps(census)
    import desert_actors_ex as DA
    actors = DA.prepare(census)
    s1_maps, s1_floors, cyc = section1_worlds(census, maps, entries, actors['decoded'])
    h8 = actors['decoded']['handlers']
    hull_idx, hull_org, hull_bg, s4_img = tank_hull(maps, entries, (h8['tk_home_x'], h8['tk_home_y']))
    name2, x2, y2, _, colors2, sol2, fl2 = maps[SEC_MAP[4]]
    s1_maps.append((f'{name2}_s4', x2, y2, s4_img, colors2, sol2, fl2))
    s1_floors[f'{name2}_s4'] = pce_floor_masks(entries, census)[name2]
    DA.hull_tiles(actors, hull_idx, hull_org, hull_bg)
    pals, codes, region, placed, cycled = PC.convert(maps, shapes, extra=s1_maps, cycle=cyc, extra_codes=S3_EXTRA)
    used = sorted(set(codes.values()))
    base = [c for c in used if c < S3_EXTRA[0]]
    if not base or base[0] < S3_FIRST or base[-1] > S3_LAST or (not all((S3_EXTRA[0] <= c <= S3_EXTRA[1] for c in used[len(base):]))):
        sys.exit(f'desert_ex: desert SCROLL3 codes outside {S3_FIRST:#x}-{S3_LAST:#x} and {S3_EXTRA[0]:#x}-{S3_EXTRA[1]:#x}')
    floors = pce_floor_masks(entries, census)
    if sorted(floors) != sorted((m[0] for m in maps)):
        sys.exit('desert_ex: the floor masks and the maps disagree')
    solids = tile_solids(maps, floors)
    classes, cell_class = collision_codes(solids, ua)
    classes, s1_class = collision_codes(tile_solids(s1_maps, s1_floors), ua, classes)
    cell_class.update(s1_class)
    coll_data = {m: collision_patches(classes, img) for m, img in imgs.items()}
    if any((coll_data[m]['tables'][k]['data'] != coll_data['striderua']['tables'][k]['data'] for m in coll_data for k in SET_ROUTINES)):
        sys.exit("desert_ex: the regions' relocated type tables differ")
    colors = s1_maps[0][4]
    pal_words = np.zeros((32, 16), np.uint32)
    for i, p in enumerate(pals):
        for j, c in enumerate(p):
            pal_words[i, j] = G.cps_color(colors[c])
    first = sorted((v for v in entries.values() if v), key=lambda v: v[0]['checkpoint'])[0]
    sky = G.cps_color(int(first[1]['pal'][0]))
    worlds = []
    for name, x0, y0, img, cols, sol, fl in maps:
        disp = {(c, r): raw_entry(v[0], v[1], v[2], v[3]) for (n, c, r), v in placed.items() if n == name}
        coll = {(c, r): raw_entry(code, 1, 1, 0) for (n, c, r), code in cell_class.items() if n == name}
        dg, ds = emit_grid(disp, name, raw_entry(TRANSPARENT_CODE, 0, 0, 0))
        cg, cs = emit_grid(coll, name, raw_entry(CLEAR_CODE, 0, 0, 0))
        worlds.append(dict(name=name, disp_grid=dg, disp_secs=ds, coll_grid=cg, coll_secs=cs, origin=[arc_x(x0), y0], size=[arc_x(img.shape[1]), img.shape[0]]))
    if len(worlds) != S1_WORLD:
        sys.exit("desert_ex: section 1's worlds do not follow the three maps")
    for k, (name, x0, y0, img, cols, sol, fl) in enumerate(s1_maps):
        sec = 4 if S1_WORLD + k == S4_WORLD else 1
        owner = worlds[SEC_MAP[sec]]
        disp = {(c, r): raw_entry(v[0], v[1], v[2], v[3]) for (n, c, r), v in placed.items() if n == name}
        coll = {(c, r): raw_entry(code, 1, 1, 0) for (n, c, r), code in cell_class.items() if n == name}
        dg, _ = emit_grid(disp, name, raw_entry(TRANSPARENT_CODE, 0, 0, 0), owner['disp_secs'])
        cg, _ = emit_grid(coll, name, raw_entry(CLEAR_CODE, 0, 0, 0), owner['coll_secs'])
        worlds.append(dict(name=name, disp_grid=dg, coll_grid=cg, shares=SEC_MAP[sec], origin=[arc_x(x0), y0], size=[arc_x(img.shape[1]), img.shape[0]]))
        check_world_art(worlds[-1], owner, region, pal_words, img, colors, x0, y0, col0=105 if sec == 1 else arc_x(HULL_CLEAR[0]) // 32)
    if len(worlds) != S4_WORLD + 1 or worlds[S4_WORLD]['name'] != f'{name2}_s4':
        sys.exit("desert_ex: section 4's world is not S4_WORLD")
    pits = pit_cells(worlds, S1_WORLD)
    dumps = sorted(census.glob('pce_*_checkpoint_01_ram_0d0000.bin'))
    dec = SP.decode(dumps[0].read_bytes())
    cps = checkpoints(census)
    syms = {m: locate(img) for m, img in imgs.items()}
    steps = flow(dec, actors['decoded']['handlers'])
    actor_syms, scores = ({}, {})
    for m, img in imgs.items():
        actor_syms[m] = DA.locate(img)
        DA.check_shapes(img, actor_syms[m])
        scores[m] = DA.score_commands(img, actor_syms[m])
    if scores['striderua'] != scores['striderjr']:
        sys.exit("desert_ex: the regions' score tables differ")
    blocks = {m: bytes(img[syms[m]['DZ_OBJPAL']:][:1024]) for m, img in imgs.items()}
    if blocks['striderua'] != blocks['striderjr']:
        sys.exit("desert_ex: the regions' stand-in sprite palette sets differ")
    obj_block = DA.obj_block(blocks['striderua'], actors['decoded']['palettes'])
    import desert_caption as DC
    caption = DC.convert()
    obj_block = DC.with_palette(obj_block, caption, set(DA.PAL_SLOTS.values()))
    caption_syms = {m: DC.locate(img) for m, img in imgs.items()}
    afloor = actor_floors(census, actors['decoded'], maps, entries)
    spawns = DA.spawn_data(actors, dec, afloor['rests'], afloor['chains'], afloor['robots'], afloor['walls'])
    spawns['cycle'] = [9522176 + 32 * i + 2 * pen for i, pen in cycled]
    spawns['mortar_floors'] = DA.mortar_floors(pce_collision(census, 4, maps, entries), actors['decoded']['handlers'], actors['decoded']['step8'])
    if not spawns['cycle']:
        sys.exit('desert_ex: no SCROLL3 palette holds the flowing sand')
    layer_tables = {k: bytes(ua[syms['striderua'][f'DZ_TAB_{k}']:][:5 * n]) for k, n in LAYER_RECORD.items()}
    for k, n in LAYER_RECORD.items():
        if bytes(jr[syms['striderjr'][f'DZ_TAB_{k}']:][:5 * n]) != layer_tables[k]:
            sys.exit(f'desert_ex: the {k} layer records differ between regions')
    return dict(region=region, codes=used, pal_words=pal_words, sky=sky, worlds=worlds, classes=classes, collision=coll_data, records_per_set=coll_data['striderua']['records_per_set'], steps=steps, restart=restart_records(cps, steps, {2: S1_WORLD, 5: S4_WORLD}), checkpoints=cps, syms=syms, layer_tables=layer_tables, cell_class=cell_class, placed=placed, actors=actors, actor_syms=actor_syms, obj_block=obj_block, obj_stock=blocks['striderua'], spawns=spawns, actor_scores=scores['striderua'], caption=caption, caption_syms=caption_syms, pits=pits, cycled=cycled)

def raw_entry(code, fx, fy, pal, group=0):
    """A SCROLL3 section entry as the stock column streamer copies it into VRAM (0x1E5D2,"""
    return struct.pack('>HH', code, pal | fx << 5 | fy << 6 | group << 7)

def install(ex_region, data, taken):
    """The desert art into the build's EX graphics region; the codes must be free there. taken: the"""
    import desert_actors_ex as DA
    for code in data['codes']:
        off = G.ex_offset('scr3', code)
        if any(ex_region[off:off + 512]):
            sys.exit(f'desert_ex: EX SCROLL3 code {code:#06x} is already used')
        ex_region[off:off + 512] = data['region'][off:off + 512]
    actors = DA.install(ex_region, data['actors'], taken)
    import desert_caption as DC
    caption = DC.install(ex_region, data['caption'], dict(taken, desert_actors=list(DA.CODES)))
    actors['frame_entries'] = DA.frame_entries(data['actors'])
    return dict(scroll3=[f"{data['codes'][0]:#06x}", f"{data['codes'][-1]:#06x}"], tiles=len(data['codes']), actors=actors, caption=caption)
SYM_NAMES = ['DZ_SLEEP', 'DZ_QUEUE', 'DZ_CLRSPR', 'DZ_S2', 'DZ_S3', 'DZ_S3INIT', 'DZ_CPLOAD', 'DZ_PLAY', 'DZ_TSTART', 'DZ_EXIT', 'DZ_INTRO', 'DZ_CLEAR', 'DZ_NOTGAME', 'DZ_DEMOEND', 'DZ_STPCLEAR', 'DZ_SOUND', 'DZ_STARS2', 'DZ_SCR_R', 'DZ_SCR_L', 'DZ_SCR_U', 'DZ_SCR_D', 'DZ_H0', 'DZ_H1', 'DZ_H2', 'DZ_H3', 'DZ_H4', 'DZ_POBJ0', 'DZ_POBJ1', 'DZ_POBJ2', 'DZ_POBJ3', 'DZ_POBJ4', 'DZ_OBJPAL', 'DZ_PAL1', 'DZ_PAL2', 'DZ_PAL3']

def respawn_syms(vasm, work, rom_dir):
    """respawn_fix's hook addresses per region (assembled as respawn_fix.patch_image does)."""
    import respawn_fix as RF
    out = {}
    for m, img in program_images(Path(rom_dir)).items():
        _, scroll1 = RF.sites(bytearray(img))
        _, syms = RF.assemble(vasm, Path(work), scroll1)
        out[m] = dict(syms, DZ_S1=scroll1)
    return out

def write_includes(work, data, rsyms):
    """desert_syms.inc (both regions, REGION_EN picks) and desert_data.inc, plus their binaries."""
    work = Path(work)
    lines = []
    for m, cond in (('striderua', 'ifne REGION_EN'), ('striderjr', 'else')):
        lines.append('    ' + cond)
        s = data['syms'][m]
        for k in SYM_NAMES:
            lines.append(f'{k:12s} equ ${s[k]:X}')
        lines.append(f"{'DZ_HOLD':12s} equ ${rsyms[m]['respawn_hold']:X}")
        lines.append(f"{'DZ_SHOW':12s} equ ${rsyms[m]['respawn_show']:X}")
        lines.append(f"{'DZ_S1':12s} equ ${rsyms[m]['DZ_S1']:X}")
        import desert_actors_ex as DA
        for k in DA.SYM_NAMES:
            lines.append(f"{k:12s} equ ${data['actor_syms'][m][k]:X}")
        import desert_caption as DC
        for k in DC.SYM_NAMES:
            lines.append(f"{k:12s} equ ${data['caption_syms'][m][k]:X}")
    lines.append('    endc')
    lines.append(f"{'DZ_WSLOT':12s} equ ${WATCH_SLOT:X}")
    (work / 'desert_syms.inc').write_text('; desert_ex.py: stock addresses for asm/desert.s\n' + '\n'.join(lines) + '\n')
    d = ['; desert_ex.py: the desert stage data for asm/desert.s', 'DZ_AREAS equ 6', f'DZ_RESTART_SIZE equ {RESTART_SIZE}', 'DZ_MAPREC equ 16', f"DZ_SKY equ ${data['sky']:04X}", f'DZ_TIMER equ {TIMER}', '']

    def stock_records(k, n):
        b = data['layer_tables'][k]
        for i in range(5):
            d.append('        dc.b    ' + ','.join((f'${v:02X}' for v in b[i * n:(i + 1) * n])) + f'   ; stage {i}')
    d.append('        even')
    d.append('dz_dir_s1:')
    stock_records('S1', 18)
    d.append('        dc.b    ' + ','.join((f'${v:02X}' for v in data['layer_tables']['S1'][18:36])) + "   ; the desert: Siberia's SCROLL1 record (the HUD layer)")
    d.append('dz_dir_s2:')
    stock_records('S2', 18)
    d.append('dz_s2_record: dc.b $78,$78')
    d.append('        dc.l    dz_s2_grid,dz_s2_secs,dz_s2_blocks,dz_pals')
    d.append('dz_dir_s3:')
    stock_records('S3', 14)
    d.append('dz_s3_records:                          ; the desert: map 0 (dz_select_map shows another)')
    for k, wd in enumerate(data['worlds']):
        s = wd.get('shares', k)
        d.append('        dc.b    $78,$78')
        d.append(f'        dc.l    dz_cg{k},dz_cs{s},dz_pals')
    d.append('dz_maps:')
    for k, wd in enumerate(data['worlds']):
        s = wd.get('shares', k)
        d.append(f'        dc.l    dz_cg{k},dz_cs{s},dz_dg{k},dz_ds{s}')
    d.append(f"DZ_PIT0 equ {S1_WORLD}                          ; section 1's worlds: the pit closed, then its variants 1-3")
    d.append(f"DZ_LAYER_S2 equ {LAYER_WORD_S4 ^ LAYER_WORD}                       ; the layer word's SCROLL2 bit (the hull)")
    d.append(f'DZ_CAM_TOP equ ${CAM_TOP:X}')
    d.append('dz_pit_tab:                             ; dz_sections op 15: per variant 1-3 the cells it changes (count; world column, map offset, display entry, collision entry)')
    d.append('        dc.l    ' + ','.join((f'dz_pit{k + 1}' for k in range(len(data['pits'])))))
    for k, cells in enumerate(data['pits']):
        d.append(f'dz_pit{k + 1}:')
        d.append(f'        dc.w    {len(cells)}')
        for col, off, de, ce in cells:
            d.append(f'        dc.w    {col},${off:04X}')
            d.append(f'        dc.l    ${de.hex().upper()},${ce.hex().upper()}')
    d.append("dz_palobj_tab:                          ; the sprite palette table (0x737BC) with the desert's list")
    d.append('        dc.l    DZ_POBJ0,DZ_POBJ1,DZ_POBJ2,DZ_POBJ3,DZ_POBJ4,dz_obj_pals')
    d.append("dz_obj_pals:                            ; per area: the desert's set (desert_actors_ex.obj_block)")
    d.append('        dc.l    ' + ','.join(['dz_obj_block'] * 6))
    import desert_caption as DC
    d += DC.inc_lines(data['caption'])
    d.append('dz_sec_music:')
    d.append('        dc.w    ' + ','.join((f'${v:02X}' for v in SEC_MUSIC)))
    d.append('dz_restart:')
    for r in data['restart']:
        d.append('        dc.b    ' + ','.join((f'${b:02X}' for b in r)))
    d.append('dz_sec_tab:')
    off = 2 * len(data['steps'])
    for sec in data['steps']:
        d.append(f'        dc.w    {off}')
        off += 16 * (len(sec) + 1)
    for sec in data['steps']:
        for st in sec + [('end',)]:
            d.append('        dc.b    ' + ','.join((f'${b:02X}' for b in step_bytes(st))) + f'   ; {st[0]} {list(st[1:])}')
    d.append('        even')
    d.append('dz_pals:')
    for row in data['pal_words']:
        d.append('        dc.w    ' + ','.join((f'${int(v):04X}' for v in row)))
    d.append("dz_obj_block:                           ; St. Petersburg area 1's set, the PC Engine enemy palettes in its enemy slots")
    for i in range(0, 1024, 32):
        d.append('        dc.w    ' + ','.join((f"${int.from_bytes(data['obj_block'][i + j:i + j + 2], 'big'):04X}" for j in range(0, 32, 2))) + f'   ; slot {i // 32}')
    d.append('dz_s2_grid: dcb.b 256,0')
    d.append('dz_s2_secs: dcb.b 96,0')
    d.append('dz_s2_blocks: dc.w 2')
    d.append("        dc.w    $2820,0,$2820,0,$2820,0,$2820,0   ; the game's blank SCROLL2 tile (map clear 0x4638)")
    for k, t in data['collision']['striderua']['tables'].items():
        (work / f'desert_types_{k}.bin').write_bytes(t['data'])
        d.append(f'dz_types_{k}: incbin "desert_types_{k}.bin"')
    for k, wd in enumerate(data['worlds']):
        for key, label in (('disp_grid', 'dg'), ('coll_grid', 'cg')):
            (work / f'desert_{label}{k}.bin').write_bytes(wd[key])
            d.append(f'dz_{label}{k}: incbin "desert_{label}{k}.bin"')
        if 'shares' in wd:
            continue
        for key, label in (('disp_secs', 'ds'), ('coll_secs', 'cs')):
            if len(wd[key]) > 256:
                sys.exit(f"desert_ex: {wd['name']}: {len(wd[key])} sections (a grid byte holds 255)")
            (work / f'desert_{label}{k}.bin').write_bytes(b''.join(wd[key]))
            d.append(f'dz_{label}{k}: incbin "desert_{label}{k}.bin"')
    d.append('        even')
    (work / 'desert_data.inc').write_text('\n'.join(d) + '\n')
    import desert_actors_ex as DA
    (work / 'desert_actors.inc').write_text(DA.inc_text(data['actors'], data['spawns'], DA.walk_speeds(data['actors']['decoded']['soldier']['sine']), data['actor_scores']))

def jsr(addr):
    return b'N\xb9' + addr.to_bytes(4, 'big')

def patch_program(img, machine, syms, data):
    """The hooks (desert.s) and the collision tables, into one region's program image."""
    s = data['syms'][machine]
    out = {}
    for name, (pat, off, n, sym) in HOOKS.items():
        at = s['site_' + name]
        if find(bytes(img), pat, at - off, at - off + len(pat) // 2) != [at - off]:
            sys.exit(f'desert_ex: {machine}: hook {name} at {at:#x} has an unexpected shape')
        img[at:at + n] = jsr(syms[sym]) + b'Nq' * ((n - 6) // 2)
        out[name] = f'{at:#x}'
    for name, (task, sym) in TASK_HOOKS.items():
        at = s[name]
        if img[at - 6:at] != b' |' + s[task].to_bytes(4, 'big') or img[at:at + 6] != jsr(s['DZ_TSTART']):
            sys.exit(f'desert_ex: {machine}: {name} at {at:#x} has an unexpected shape')
        img[at:at + 6] = jsr(syms[sym])
        out[name] = f'{at:#x}'
    at = s['dispatch_call']
    if img[at:at + 6] != jsr(s['DZ_DISPATCH']):
        sys.exit(f'desert_ex: {machine}: the stage dispatch call has an unexpected shape')
    img[at:at + 6] = jsr(syms['dz_stage_dispatch'])
    out['dispatch'] = f'{at:#x}'
    for i, k in enumerate(LAYER_RECORD):
        a = LAYER_TABLE_DIR + 4 * i
        if be32(img, a) != s[f'DZ_TAB_{k}']:
            sys.exit(f'desert_ex: {machine}: the layer record directory has an unexpected shape')
        img[a:a + 4] = syms[f'dz_dir_{k.lower()}'].to_bytes(4, 'big')
    at = s['pal_obj']
    if be32(img, at) != s['DZ_PALOBJ_TABLE']:
        sys.exit(f'desert_ex: {machine}: the sprite palette table operand has an unexpected shape')
    img[at:at + 4] = syms['dz_palobj_tab'].to_bytes(4, 'big')
    out['tables'] = dict(directory=f'{LAYER_TABLE_DIR:#x}', pal_obj=f'{at:#x}')
    a = data['actor_syms'][machine]
    at = a['site_pool5_type3']
    if be32(img, at) != a['DA_TYPE3_STOCK']:
        sys.exit(f'desert_ex: {machine}: the pool-5 type-3 dispatch long at {at:#x} moved')
    img[at:at + 4] = syms['da_dispatch'].to_bytes(4, 'big')
    out['pool5_type3'] = f'{at:#x}'
    coll = data['collision'][machine]
    for k, ((pg, ty, fpg, fl, recs), imms) in collision_refs(bytes(img)).items():
        if img[pg + DZ_SLOT] != 0:
            sys.exit(f'desert_ex: {machine}: set {k} slot {DZ_SLOT} is not free')
        img[pg + DZ_SLOT] = coll['tables'][k]['page']
        for a in imms:
            if be32(img, a) != ty:
                sys.exit(f'desert_ex: {machine}: set {k} type-table operand at {a:#x} moved')
            img[a:a + 4] = syms[f'dz_types_{k}'].to_bytes(4, 'big')
    for a, b in coll['records']:
        img[a:a + len(b)] = b
    out['collision'] = dict(records=len(coll['records']), pages={k: v['page'] for k, v in coll['tables'].items()})
    return out

def report(rom_dir, census, out):
    out.mkdir(parents=True, exist_ok=False)
    data = prepare(census, rom_dir)
    rep = dict(codes=[f"{data['codes'][0]:#06x}", f"{data['codes'][-1]:#06x}", len(data['codes'])], collision_classes=len(data['classes']), records_per_set=data['records_per_set'], class_codes=sorted((f'{c:#05x}' for c in data['classes'].values())), sky=f"{data['sky']:#06x}", checkpoints=data['checkpoints'], steps=[[[v if isinstance(v, str) else v for v in st] for st in sec] for sec in data['steps']], worlds=[dict(name=w['name'], origin=w['origin'], size=w['size'], disp_sections=len(data['worlds'][w.get('shares', i)]['disp_secs']) - 1, coll_sections=len(data['worlds'][w.get('shares', i)]['coll_secs']) - 1, shares=w.get('shares')) for i, w in enumerate(data['worlds'])], pit_cells=[len(c) for c in data['pits']], cycled=data['cycled'])
    (out / 'report.json').write_text(json.dumps(rep, indent=1) + '\n')
    print(json.dumps(rep, indent=1))
    return 0

def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('cmd', nargs='?', choices=['report'])
    p.add_argument('--self-test', action='store_true')
    p.add_argument('--rom-dir', type=Path)
    p.add_argument('--census', type=Path)
    p.add_argument('--out', type=Path)
    a = p.parse_args()
    if a.self_test:
        return self_test(a.rom_dir)
    if a.cmd == 'report':
        return report(a.rom_dir, a.census, a.out)
    p.error('give a command or --self-test')

def self_test(rom_dir):
    b40 = [31, 31] + list(range(30, 0, -1))
    world = np.zeros((128, 96), bool)
    for x, h in enumerate(b40):
        world[64 - h:, 32 + x] = True
    world[64:, :] = True
    world[33:64, :32] = True
    ex = exposure(world)
    d = depth_records(*(e[32:64, 32:64] for e in ex))
    assert d['B'] == tuple(b40), d['B']
    c40 = [31] + list(range(30, 0, -1)) + [1]
    assert sum((abs(a - b) for a, b in zip(d['C'], c40))) <= 2, d['C']
    assert not any(d['A']) and (not any(d['D'])), (d['A'], d['D'])
    inner = depth_records(*(e[64:96, 32:64] for e in ex))
    assert not any((any(v) for v in inner.values())), inner
    assert slope_kind(b40) == 6 and slope_kind([v // 2 + 1 for v in range(32)]) == 2
    steep = [min(2 * v + 1, 31) for v in range(16)] + [0] * 16
    assert slope_kind(steep) == 4 and slope_kind(steep[::-1]) == 5 and (slope_kind([20] * 32) == 1)
    col = np.zeros((200, 3), bool)
    col[40:60, :] = True
    col[78:120, :] = True
    col[160:, :] = True
    assert fill_gaps(col) == 3 * 18 and col[60:78].all() and (not col[120:160].any()) and (not col[:40].any())
    for roof, want in ((None, True), (20, False)):
        st = np.zeros((300, 120), bool)
        st[200:, :60] = True
        st[216:, 60:] = True
        if roof:
            st[200 - 16 - roof:200 - 16 - roof + 8, 60:] = True
        ramp_steps(st)
        assert st[200:216, 60:64].any() == want, (roof, want)
    import pce_desert_convert as PC
    pce = np.zeros((80, 60), bool)
    for x in range(60):
        pce[60 - 2 * min(max(x - 10, 0), 20) - (16 if x >= 50 else 0):, x] = True
    w = PC.widen_copy(pce)
    top = lambda m: [int(np.argmax(m[:, x])) for x in range(m.shape[1])]
    before = top(w)
    assert {abs(b - a) for a, b in zip(before, before[1:])} >= {0, 2}
    assert smooth_slopes(w) > 0
    after = top(w)
    st = [b - a for a, b in zip(after, after[1:])]
    slope = st[16:44]
    assert max((abs(b - a) for a, b in zip(slope, slope[1:]))) <= 1 and set(slope) <= {-1, -2}, slope
    assert max((abs(a - b) for a, b in zip(before, after))) <= 1 and after[:14] == before[:14] and (min(st) == -16)
    assert entry_of('B', (31,) * 32) == (31, None) and entry_of('A', (0,) * 32) == (0, None)
    assert arc_y(896) == 1151 and step_bytes(('limits', 1, 2, 3, 4))[:10] == struct.pack('>5H', 2, 1, 2, 3, 4)
    assert follow_ok(FOLLOW) and (not follow_ok((176, 192, 144, 112)))
    if rom_dir:
        imgs = program_images(rom_dir)
        for m, img in imgs.items():
            refs = collision_refs(img)
            relocated = bytearray(img)
            for key, (tables, operands) in refs.items():
                for at in operands:
                    struct.pack_into('>I', relocated, at, 1582716)
            relocated_tables = collision_sets(relocated)
            for key, (tables, operands) in refs.items():
                assert relocated_tables[key] == (tables[0], 1582716, *tables[2:]), m
            s = locate(img)
            assert s['DZ_SLEEP'] == 2014 and s['DZ_QUEUE'] == 3600, m
            recs = stock_follow(img)
            moving = [(a, box) for a, lim, box in recs if any(lim)]
            assert len(recs) >= 30 and len(moving) >= 25, (m, len(recs), len(moving))
            assert all((follow_ok(box) for a, box in moving)), [(hex(a), box) for a, box in moving if not follow_ok(box)]
            assert [box for a, lim, box in recs if not follow_ok(box) and any(box)] == [(176, 192, 144, 112)], m
            for k in ('l_5260', 'l_52a2'):
                at = s['site_' + k] + 14
                e = [be16(img, at + 2 * i) for i in range(5)]
                assert len(set(e[1:])) == 1 and img[at + e[1]:at + e[1] + 2] == b'Nu', (m, k, e)
        ua = imgs['striderua']
        used = stock_scroll3_codes(ua)
        assert {c for c, f in used if f == DZ_FLIPS and c >> 8 == DZ_SLOT - 24} == {1339, 1340}, 'stock codes in the desert collision slot changed'
        assert task_slots(ua) == {0, 16, 48, 64, 80, 144, 160, 176, 208, 224, 240}
        tabs = collision_tables(ua)
        assert all((len(v['free']) >= 100 for v in tabs.values())), tabs
    print('desert_ex self-test passed')
    return 0
if __name__ == '__main__':
    sys.exit(main())
