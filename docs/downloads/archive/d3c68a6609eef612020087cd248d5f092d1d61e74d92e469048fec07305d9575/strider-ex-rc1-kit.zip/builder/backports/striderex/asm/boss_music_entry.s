; A new desert boss tune belongs to the fight after its first dialogue.
; dz_cue has already recorded it in DZ_MUS; bs_play's native restart uses
; that word after the portrait. Leave the preceding stage tune available
; for the scene's existing fade. On a retry, BS_DONE skips the portrait and
; the music must start normally. This path runs only when a cue changes.
dz_boss_music:
        cmpi.w #1,DZ_SEC
        beq.s .officer
        cmpi.w #4,DZ_SEC
        bne.s .queue
        btst #7,BS_DONE
        beq.s .return
        bra.s .queue
.officer:
        btst #6,BS_DONE
        beq.s .return
.queue:
        jmp DZ_SOUND
.return:
        rts
