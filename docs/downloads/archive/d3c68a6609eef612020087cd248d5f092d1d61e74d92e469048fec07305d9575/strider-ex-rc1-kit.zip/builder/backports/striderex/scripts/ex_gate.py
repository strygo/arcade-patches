"""Phase 2 gate: the EX build's cinematics play in the game, exactly, and hand back."""
import argparse
import json
import os
import subprocess
import sys
from pathlib import Path
import numpy as np
from PIL import Image
sys.path.insert(0, str(Path(__file__).resolve().parent))
import build_ex as BX
import cinematic_convert as C
import scene_gate as SG
import subtitle_ex as SX
ROOT = Path(__file__).resolve().parents[3]
DEBUG_START = ROOT / 'backports/striderex/lua/arcade_debug_start.lua'
HBSET = ROOT / 'backports/striderex/scripts/hbmame_set.py'
PARENT = {'striderus01': 'striderua', 'striderjs01': 'striderjr'}
LANG = {'striderus01': 'en', 'striderjs01': 'ja'}
OFFSETS = (-3, -2, -1, 0, 1)
STEP = 37
NP_STOP = int(json.loads(BX.CUES.read_text())['nopack_intros']['stop'], 16)
LUA = "\nlocal m=manager.machine\nlocal sp=m.devices[':maincpu'].spaces['program']\nlocal screen=m.screens[':screen']\nlocal fields={}\nfor _,port in pairs(m.ioport.ports) do for name,field in pairs(port.fields) do\n fields[m.ioport:input_type_to_token(field.type,field.player)]=field end end\nlocal out=os.getenv('OUT')\nlocal log=assert(io.open(out..'/log.tsv','w'))\nlocal snd=assert(io.open(out..'/sound.tsv','w'))\nlocal f=0\nlocal last=tonumber(os.getenv('END'))\nlocal step=tonumber(os.getenv('STEP'))\nlocal debug=os.getenv('STREX_DEBUG_START')\n-- handler timing: machine time when cine_step finishes a record (FRAMES low word) and\n-- at each frame_done, so a record's finish can be placed within its frame\nlocal tim=assert(io.open(out..'/timing.tsv','w'))\n_G.strex_t2=sp:install_write_tap(0xfff902,0xfff903,'frm',function(off,data,mask)\n tim:write(string.format('r\\t%d\\t%.9f\\t%d\\n',f+1,m.time:as_double(),sp:read_u32(0xfff900))) end)\n_G.strex_snd=sp:install_write_tap(0x800180,0x800181,'snd',function(off,data,mask)\n snd:write(string.format('%d\\t%04x\\t%04x\\n',f+1,sp:read_u16(0xfff914),data&0xffff))\n tim:write(string.format('s\\t%d\\t%.9f\\n',f+1,m.time:as_double())) end)\nemu.register_frame_done(function()\n f=f+1\n if not debug then\n  if f>=200 and f<=208 then fields.COIN1:set_value(1) else fields.COIN1:clear_value() end\n  if f>=400 and f<=408 then fields.START1:set_value(1) else fields.START1:clear_value() end\n end\n local active=sp:read_u16(0xfff914)\n tim:write(string.format('f\\t%d\\t%.9f\\n',f,m.time:as_double()))\n log:write(string.format('%d\\t%d\\t%08x\\t%04x\\t%d\\t%d\\n',f,sp:read_u32(0xfff900),sp:read_u32(0xfff904),active,\n  sp:read_u8(0xff0cba),sp:read_u8(0xff0cb2)))\n if active==0xc1e5 and f%step==0 then screen:snapshot(string.format('%s/s_%05d.png',out,f)) end\n if active==0xc1e6 then screen:snapshot(string.format('%s/h_%05d.png',out,f)) end\n if active==0xc1e7 and f%8==0 then screen:snapshot(string.format('%s/k_%05d.png',out,f)) end\n if f>=last then log:close() snd:close() tim:close() m:exit() end\nend)\nif debug then dofile(debug) end\n"

def region_from(files):
    """The 4 MB EX graphics region from the four ROM_LOAD64_WORD files (cps1_gfx.split_region inverse)."""
    region = bytearray(4 * BX.MB)
    for j, name in enumerate(BX.EX_GFX):
        part = files[name]
        for i in range(0, BX.MB, 2):
            region[4 * i + 2 * j:4 * i + 2 * j + 2] = part[i:i + 2]
    return region

def run(binary, roms, set_name, out, frames, stage):
    out.mkdir(parents=True)
    (out / 'gate.lua').write_text(LUA)
    env = dict(os.environ, SDL_VIDEODRIVER='dummy', SDL_AUDIODRIVER='dummy', OUT=str(out), END=str(frames), STEP=str(STEP))
    if stage:
        env.update(STREX_DEBUG_START=str(DEBUG_START), STREX_STAGE=str(stage), STREX_AREA='0', STREX_END=str(frames + 100), STREX_PREFIX=str(out / 'dbg'), STREX_INPUTS='')
    cmd = [str(binary), set_name, '-rompath', str(roms), '-nothrottle', '-video', 'none', '-sound', 'none', '-seconds_to_run', str(frames // 50 + 30), '-skip_gameinfo', '-noautosave', '-cfg_directory', str(out / 'cfg'), '-nvram_directory', str(out / 'nv'), '-snapshot_directory', str(out), '-autoboot_script', str(out / 'gate.lua')]
    p = subprocess.run(cmd, env=env, cwd=out, capture_output=True, text=True, timeout=1200)
    (out / 'mame.log').write_text(p.stdout + p.stderr)
    if p.returncode:
        sys.exit(f'{out}: HBMAME exit {p.returncode}')
    log = [tuple((int(v, 16) if i in (2, 3) else int(v) for i, v in enumerate(l.split('\t')))) for l in (out / 'log.tsv').read_text().splitlines()]
    snd = [(int(a), int(b, 16), int(c, 16)) for a, b, c in (l.split('\t') for l in (out / 'sound.tsv').read_text().splitlines())]
    return (log, snd)

def scene_records(stream):
    """The record count of a scene stream (up to its 0xFFFF end mark)."""
    import struct
    pos, k = (0, 0)
    while struct.unpack_from('>H', stream, pos)[0] != 65535:
        pos += 2 + struct.unpack_from('>H', stream, pos)[0]
        k += 1
    return k
BLANK = 38 / 262

def timing(out, scene_at):
    """Each VBlank handler of a cinematic must end before the next VBlank (or that"""
    import bisect
    rows = [l.split('\t')[:3] for l in (out / 'timing.tsv').read_text().splitlines()]
    times = [float(t) for k, f, t in rows if k == 'f']
    period = (times[-1] - times[0]) / (len(times) - 1)
    over, worst = ([], 0.0)
    for k, f, t in rows:
        if k != 's' or scene_at.get(int(f)) is None:
            continue
        t = float(t)
        i = bisect.bisect_right(times, t) - 1
        share = (t - times[i]) / period
        if i > 0 and scene_at.get(int(f) - 1) is None:
            continue
        worst = max(worst, share)
    late = []
    ends = sorted((int(f) for k, f, t in rows if k == 's' and scene_at.get(int(f)) is not None))
    from collections import Counter
    doubled = [f for f, n in Counter(ends).items() if n > 1]
    return dict(worst_share=round(worst, 3), frames_with_two_handlers=len(doubled), first=sorted(doubled)[:5], late_records=len(doubled))

def check(log, snd, out, build_set, streams, models_of, pack, stage, streams_bytes=None, card_frames=0, lang=None):
    """lang: the voice the pack run plays (0 Japanese, 1 English; None: the region's, L1)."""
    streams_bytes = streams_bytes or {}
    order = sorted(streams, key=lambda k: streams[k])
    starts = [streams[k] for k in order]

    def scene_of(ptr):
        i = max((j for j, a in enumerate(starts) if a <= ptr), default=None)
        return order[i] if i is not None else None
    active = [r for r in log if r[3] == 49637]
    runs, seen, scene_at = ([], [], {})
    for r in active:
        if runs and r[0] == runs[-1][-1][0] + 1 and (r[1] >= runs[-1][-1][1]):
            runs[-1].append(r)
        else:
            runs.append([r])
    lengths = {}
    for rs in runs:
        s = scene_of(rs[len(rs) // 2][2])
        seen.append(s)
        lengths[s] = max((r[1] for r in rs))
        for r in rs:
            scene_at[r[0]] = s
    expect = [i for i in BX.STAGE_SCENES[stage] if i in streams]
    rows, shots = ({}, {})
    for q in sorted(out.glob('s_*.png')):
        f = int(q.stem[2:])
        shots.setdefault(scene_at[f], []).append((f, log[f - 1][1], q))
    for s, lst in shots.items():
        models = models_of(s, {r + dk for _, r, _ in lst for dk in OFFSETS if r + dk >= 1})
        for f, rec, q in lst:
            snap = np.asarray(Image.open(q).convert('RGB'))
            bad = {dk: int((models[rec + dk] != snap).any(-1).sum()) for dk in OFFSETS if rec + dk in models}
            rows.setdefault(s, []).append(dict(frame=f, records=rec, mismatched=bad))
    scenes = {}
    for s, rs in rows.items():
        fits = [dk for dk in OFFSETS if all((x['mismatched'].get(dk, 1) == 0 for x in rs))]
        lags = [x['frame'] - x['records'] for x in rs if x['records'] > 0]
        scenes[s] = dict(shots=len(rs), offsets=fits, lag=[min(lags), max(lags)] if lags else None, ok=bool(fits) and bool(lags) and (max(lags) == min(lags)))
    end_active = active[-1][0] if active else None
    intro_after = any((r[4] for r in log if end_active and r[0] > end_active))
    cine_snd = [v for f, a, v in snd if a == 49637]
    cues = [v for v in cine_snd if v & 255 != 255]
    nopack = build_set.get('nopack_cues', {})
    want_cues = [build_set['cues'][s][build_set['region_en'] if lang is None else lang] for s in expect] if pack else [nopack[s] for s in expect if s in nopack]
    stops = [v & 255 for f, a, v in snd if a == 49638 and v & 255 != 255 and end_active and (f <= end_active + 2)]
    want_stops = [] if pack or not want_cues else [NP_STOP]
    tm = timing(out, scene_at)
    held = sorted(out.glob('h_*.png'))
    lit = [int(q.stem[2:]) for q in held if np.asarray(Image.open(q).convert('RGB')).any()]
    want_card = card_frames if 'prologue' in expect and 'prologue' in BX.CARD_AFTER else 0
    card_n = sum((1 for r in log if r[3] == 49639))
    shots_k = [np.asarray(Image.open(q).convert('RGB')) for q in sorted(out.glob('k_*.png'))]
    import scene_gate as SG
    import subtitle_ex as SX
    cap_rgb = {tuple(SG.hb_rgb(w)) for w in SX.PALETTE}

    def same_card(k):
        diff = (k != shots_k[0]).any(-1)
        return {tuple(c) for c in k[diff]} <= cap_rgb
    card_ok = abs(card_n - want_card) <= 1 and (want_card == 0 or (len(shots_k) > 2 and shots_k[0].any() and all((same_card(k) for k in shots_k))))
    if want_card and card_ok:
        Image.fromarray(shots_k[0]).save(out / 'card.png')
    full = {}
    for sid, n in lengths.items():
        stream = streams_bytes.get(sid)
        if stream is not None:
            import struct
            pos, k = (0, 0)
            while struct.unpack_from('>H', stream, pos)[0] != 65535:
                pos += 2 + struct.unpack_from('>H', stream, pos)[0]
                k += 1
            full[sid] = dict(records_played=n, records=k, complete=n == k)
    ok = seen == expect and all((v['ok'] for v in scenes.values())) and (set(scenes) == set(expect)) and (tm['late_records'] == 0) and all((v['complete'] for v in full.values())) and (len(full) == len(expect)) and intro_after and (log[-1][0] > (end_active or 0)) and ([c & 255 for c in cues] == want_cues) and (stops == want_stops) and (len(held) > 0) and (not lit) and card_ok
    return dict(scenes_played=seen, expected=expect, scenes=scenes, active_frames=len(active), timing=tm, lengths=full, intro_started_after=intro_after, held_frames=len(held), held_frames_lit=lit[:10], card_frames=card_n, card_frames_expected=want_card, card_ok=card_ok, cues_sent=[f'{c:#06x}' for c in cues], cues_expected=[f'{c:#04x}' for c in want_cues], stops_sent=[f'{c:#04x}' for c in stops], stops_expected=[f'{c:#04x}' for c in want_stops], passed=ok)

def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('--build', type=Path, required=True)
    p.add_argument('--runtime', type=Path, required=True)
    p.add_argument('--hbmame', type=Path, required=True)
    p.add_argument('--rom-dir', type=Path, required=True)
    p.add_argument('--workdir', type=Path, required=True)
    p.add_argument('--set', default='striderus01', choices=sorted(PARENT))
    p.add_argument('--frames', type=int, default=7000)
    p.add_argument('--stage', type=int, default=0, help='0: a new game from coin and START; 1-4: the debug start')
    p.add_argument('--voices', choices=('region', 'all'), default='all', help="pack runs: the region's voice only (flag 0x01), or also the other (USA 0x03, Japan 0x05)")
    p.add_argument('--pack', type=Path, help="strider_ex.cpk: each pack run's cues must start their own rows on the core (pack_model.cue_starts)")
    a = p.parse_args()
    work = a.workdir.resolve()
    work.mkdir(parents=True, exist_ok=False)
    build = json.loads((a.build / 'build.json').read_text())
    bset = build['sets'][PARENT[a.set]]
    other = 1 if bset['region_en'] else 2
    variants = [('nopack', 0), ('pack', 1)] + ([(f'pack_voice{other}', 1 | other << 1)] if a.voices == 'all' else [])
    if a.pack:
        import pack_model as PM
        pmodel, names = (PM.Model(a.pack), PM.track_names())
    streams = bset['streams']
    binary = json.loads((a.runtime / 'runtime.json').read_text())['binary']
    report = dict(set=a.set, stage=a.stage, runs={})
    ex_dir = a.build.resolve()
    files = {q.name: q.read_bytes() for q in (ex_dir / PARENT[a.set]).iterdir()}
    region = region_from(files)
    caps = json.loads((ex_dir / 'captions.json').read_text())
    pages = [(q['lang'], [tuple(e) for e in q['entries']]) for q in caps['pages_detail']]
    pre = {s['id']: s.get('preroll') for s in build['scenes']}
    conts = {s['id']: s.get('continues') for s in build['scenes']}

    def voice_lang(flag):
        """The voice a flag byte plays (ex_bank.s play): 0 Japanese, 1 English; None without a pack."""
        if not flag & 1:
            return None
        voice = flag >> 1 & 3
        return bset['region_en'] if voice == 0 else voice - 1

    def models_of(sid, needed, variant=0):
        """{k: RGB picture after k records} for the record counts in needed (variant: the run's flag byte)."""
        if conts.get(sid) and any((k <= pre[sid] for k in needed)):
            prev = conts[sid]
            last = models_of(prev, {scene_records((ex_dir / 'work' / f'scene_{prev}.bin').read_bytes())}, variant)
            held = next(iter(last.values()))
            out = models_of_scene(sid, {k for k in needed if k > pre[sid]}, variant)
            out.update({k: held for k in needed if k <= pre[sid]})
            return out
        return models_of_scene(sid, needed, variant)

    def models_of_scene(sid, needed, variant):
        if not needed:
            return {}
        stream = (ex_dir / 'work' / f'scene_{sid}.bin').read_bytes()
        key = LANG[a.set]
        if voice_lang(variant) == 1 and 'en_dub' in caps['schedules'][sid]:
            key = 'en_dub'
        model = SX.CaptionModel(region, stream, caps['schedules'][sid][key], pages)
        k, out, rgb = (0, {}, {})
        top = max(needed)
        while k < top:
            if not model.step():
                break
            k += 1
            if k in needed:
                words = model.render()
                uniq, inv = np.unique(words, return_inverse=True)
                lut = np.array([rgb.setdefault(int(w), SG.hb_rgb(int(w))) for w in uniq], np.uint8)
                out[k] = lut[inv].reshape(words.shape + (3,))
        return out
    ok = True
    for variant, flag in variants:
        src = work / f'ex_{variant}'
        (src / PARENT[a.set]).mkdir(parents=True)
        for n, b in files.items():
            if n == 'strex_p6.bin' and flag:
                b = bytearray(b)
                b[1048574] |= flag
                b = bytes(b)
            (src / PARENT[a.set] / n).write_bytes(b)
        sets = work / f'set_{variant}'
        subprocess.run([sys.executable, str(HBSET), 'build', '--hbmame', str(a.hbmame), '--rom-dir', str(a.rom_dir.resolve()), '--ex-dir', str(src), '--set', a.set, '--date', '2026-10-10', '--out', str(sets)], check=True, stdout=subprocess.DEVNULL)
        log, snd = run(binary, sets, a.set, work / f'run_{variant}', a.frames, a.stage)
        sb = {sid: (ex_dir / 'work' / f'scene_{sid}.bin').read_bytes() for sid in streams}
        r = check(log, snd, work / f'run_{variant}', bset, streams, lambda sid, needed, v=flag: models_of(sid, needed, v), bool(flag), a.stage, sb, build.get('card_frames', 0), lang=voice_lang(flag))
        r['flag'] = f'{flag:#04x}'
        if a.pack and flag:
            lang = voice_lang(flag)
            cs = PM.cue_starts(pmodel, [(f, v & 255) for f, _, v in snd], [(bset['cues'][s][lang], names.get((s, lang))) for s in r['expected']])
            r['cue_starts'] = cs
            r['passed'] = r['passed'] and all((c['ok'] for c in cs))
        report['runs'][variant] = r
        ok &= r['passed']
        print(variant, json.dumps({k: v for k, v in r.items() if k != 'scenes'}), {s: (v['offsets'], v['lag'], v['shots']) for s, v in r['scenes'].items()}, flush=True)
    report['passed'] = ok
    (work / 'report.json').write_text(json.dumps(report, indent=1) + '\n')
    print('PASS' if ok else 'FAIL')
    return 0 if ok else 1
SKIP_POINTS = [(0, 'prologue', 300), (0, 'prologue', 1500), (0, 'prologue', 2400), (0, 'prologue', -1), (0, 'brief_st_petersburg', 10), (0, 'brief_st_petersburg', 900), (1, 'brief_siberia', 700), (2, 'brief_amazon', 700), (3, 'brief_aerial', 700), (4, 'flight', 700), (4, 'welcome_meio', 10), (4, 'welcome_meio', 1000), (5, 'intro_desert', 500)]
SKIP_FADE = json.loads(BX.CUES.read_text())['skip_fade']
FADE_CMD = int(SKIP_FADE['cue'], 16)
FADE_FRAMES = int(SKIP_FADE['frames'])
FADE_RANGE = (23, 36)
STOP_WITHIN = 2
SKIP_HOLD = 6
SKIP_TAIL = 60
SKIP_MAX = 3000
SKIP_LUA = "\nlocal m=manager.machine\nlocal sp=m.devices[':maincpu'].spaces['program']\nlocal fields={}\nfor _,port in pairs(m.ioport.ports) do for name,field in pairs(port.fields) do\n fields[m.ioport:input_type_to_token(field.type,field.player)]=field end end\nlocal out=os.getenv('OUT')\nlocal log=assert(io.open(out..'/log.tsv','w'))\nlocal snd=assert(io.open(out..'/sound.tsv','w'))\nlocal meta=assert(io.open(out..'/meta.tsv','w'))\nlocal f=0\nlocal last=tonumber(os.getenv('END'))\nlocal tail=tonumber(os.getenv('TAIL'))\nlocal most=tonumber(os.getenv('MOST'))\nlocal lo=tonumber(os.getenv('SKIP_LO') or '0')          -- the scene to skip: its stream [lo, hi)\nlocal hi=tonumber(os.getenv('SKIP_HI') or '0')\nlocal rec=tonumber(os.getenv('SKIP_REC') or '0')        -- press once it has played rec records (-1: at its end mark)\nlocal hold=tonumber(os.getenv('SKIP_HOLD') or '6')\nlocal debug=os.getenv('STREX_DEBUG_START')\n_G.strex_snd=sp:install_write_tap(0x800180,0x800181,'snd',function(off,data,mask)\n snd:write(string.format('%d\\t%04x\\t%04x\\n',f+1,sp:read_u16(0xfff914),data&0xffff)) end)\nif debug then dofile(debug) end                          -- (its frame callback first: the press below wins)\nlocal press,was_on,back,play=nil,false,nil,nil\nemu.register_frame_done(function()\n f=f+1\n if not debug then\n  if f>=200 and f<=208 then fields.COIN1:set_value(1) else fields.COIN1:clear_value() end\n  if f>=400 and f<=408 then fields.START1:set_value(1) else fields.START1:clear_value() end\n end\n local active=sp:read_u16(0xfff914)\n local records=sp:read_u32(0xfff900)\n local lz=sp:read_u32(0xfff904)\n local ended=sp:read_u16(0xfff910)\n if not press and hi>0 and active==0xc1e5 and lz>=lo and lz<hi and\n    ((rec>=0 and ended==0 and records>=rec) or (rec<0 and ended==1)) then\n  press=f\n  meta:write(string.format('press\\t%d\\t%d\\t%d\\n',f,records,ended))\n end\n if press and f>=press and f<press+hold then fields.START1:set_value(1)\n elseif press and f==press+hold then fields.START1:clear_value() end\n if active==0xc1e5 then was_on=true end\n if was_on and active==0 and not back then back=f meta:write(string.format('handback\\t%d\\n',f)) end\n log:write(string.format('%d\\t%d\\t%08x\\t%04x\\t%d\\t%d\\t%d\\t%d\\n',f,records,lz,active,ended,\n  sp:read_u16(0xff0c12),sp:read_u8(0xff0cba),sp:read_u8(0xff0cb2)))\n if back and not play and sp:read_u16(0xff0c12)==4 then play=f end\n if f>=last or (play and f>=play+tail) or (back and f>=back+most) then log:close() snd:close() meta:close() m:exit() end\nend)\n"

def skip_run(binary, roms, set_name, out, stage, point, streams, frames=9000):
    """One HBMAME run of a stage's cinematics: no input during them, or a START press at point"""
    out.mkdir(parents=True)
    (out / 'gate.lua').write_text(SKIP_LUA)
    env = dict(os.environ, SDL_VIDEODRIVER='dummy', SDL_AUDIODRIVER='dummy', OUT=str(out), END=str(frames), TAIL=str(SKIP_TAIL), MOST=str(SKIP_MAX), SKIP_HOLD=str(SKIP_HOLD))
    if point:
        sid, rec = point
        order = sorted(streams.values())
        lo = streams[sid]
        env.update(SKIP_LO=str(lo), SKIP_HI=str(next((a for a in order if a > lo), 2097152)), SKIP_REC=str(rec))
    if stage:
        env.update(STREX_DEBUG_START=str(DEBUG_START), STREX_STAGE=str(stage), STREX_AREA='0', STREX_END=str(frames + 100), STREX_PREFIX=str(out / 'dbg'), STREX_INPUTS='')
    cmd = [str(binary), set_name, '-rompath', str(roms), '-nothrottle', '-video', 'none', '-sound', 'none', '-seconds_to_run', str(frames // 50 + 30), '-skip_gameinfo', '-noautosave', '-cfg_directory', str(out / 'cfg'), '-nvram_directory', str(out / 'nv'), '-snapshot_directory', str(out), '-autoboot_script', str(out / 'gate.lua')]
    p = subprocess.run(cmd, env=env, cwd=out, capture_output=True, text=True, timeout=1200)
    (out / 'mame.log').write_text(p.stdout + p.stderr)
    if p.returncode:
        sys.exit(f'{out}: HBMAME exit {p.returncode}')
    log = [tuple((int(v, 16) if i in (2, 3) else int(v) for i, v in enumerate(l.split('\t')))) for l in (out / 'log.tsv').read_text().splitlines()]
    snd = [(int(a), int(b, 16), int(c, 16) & 255) for a, b, c in (l.split('\t') for l in (out / 'sound.tsv').read_text().splitlines())]
    meta = {l.split('\t')[0]: [int(v) for v in l.split('\t')[1:]] for l in (out / 'meta.tsv').read_text().splitlines()}
    return dict(log=log, snd=snd, press=meta.get('press', [None])[0], handback=meta.get('handback', [None])[0])

def skip_facts(r, model, cues_after):
    """What one run shows: the press, the stop, the commands to the hand-back, the commands and play"""
    H, p = (r['handback'], r['press'])
    log, snd = (r['log'], r['snd'])
    if H is None:
        return dict(handback=None)
    play = next((x[0] - H for x in log if x[0] > H and x[5] == 4), None)
    after = [(f - H, v) for f, a, v in snd if f > H and v != 255]
    facts = dict(handback=H, play_after_handback=play, after=after)
    if model:
        ev, segs = model.run([(f, v) for f, a, v in snd])
        facts['model_after'] = [(f - H, v, e) for f, v, _, _, e in ev if f > H and e]
        facts['ignored_cues'] = [f'{v:#04x}' for f, v, verb, t, e in ev if v in cues_after and e is None and model.classify(v)[2]]
        first = next((f for f, v, _, _, e in ev if f > H and e == 'start'), r['log'][-1][0])
        facts['handback_to_music'] = dict(level_db=model.level(segs, H, first)[0], frames=first - H)
    if p is None:
        return facts
    skip = next((x[0] for x in log if x[0] >= p and x[4] == 2), None)
    cmds = [(f, v) for f, a, v in snd if p < f <= H and v != 255]
    facts.update(press=p, skipped_at=skip, to_handback=cmds)
    fade = cmds[0][0] if cmds and cmds[0][1] == FADE_CMD else None
    facts['fade'] = fade
    if model:
        import math
        ev, segs = model.run([(f, v) for f, a, v in snd])
        track, start = model.state(segs, p)
        nxt = next((f for f, v, _, _, e in ev if f > p and e == 'start'), r['log'][-1][0])
        md = dict(at_press=model.tracks[track].name if track is not None else None, next_start=nxt - p)
        if fade is not None:
            n = model.fade_frames(0)
            land = fade + n - 1
            env = model.envelope(segs, fade - 1, min(nxt, land) + 1)
            md.update(fade_frames=n, landing=land - p, cut_by_next=nxt <= land, curve=[(f - fade, tq, d) for f, _, tq, d in env], after_landing_db=model.level(segs, land, nxt)[0] if land < nxt else -math.inf)
            if nxt <= land:
                tq = next((tq for f, _, tq, _ in env if f == nxt - 1), None)
                md['gain_at_cut_db'] = round(20 * math.log10(tq / 16384), 2) if tq else -math.inf
        else:
            lvl, secs = model.level(segs, p + STOP_WITHIN + 1, nxt)
            md.update(after_press_db=lvl, sounding_s=secs)
        facts['model'] = md
    return facts

def skip_main(argv):
    p = argparse.ArgumentParser(prog='ex_gate.py skip', description="A START press mid-scene fades the\ncinematic's sound out (with a pack, 23 frames: 0.386 s), and the game goes on as after the scene's normal end.\n\n    ex_gate.py skip --build <build_ex.py out> --control <a build without the fade (build 45)> \\\n        --pack <strider_ex.cpk> --runtime <build_hbmame_probe.py dir> --hbmame <HBMAME checkout> \\\n        --rom-dir <stock sets> --workdir <fresh dir> [--sets striderus01,striderjs01] [--points 0,3,..]\n\nFor each set, without a pack and with the PACK bit and each voice (the region's, the other), each\nstage's cinematics run once untouched (the reference) and once per skip point (SKIP_POINTS: a scene and\nits records played), START held SKIP_HOLD frames from there. Requires of the build, in every skip run:\n  - the press skips the scene (ENDED 2 within STOP_WITHIN frames);\n  - with a pack, the first command on the latch after the press is FADE_CMD (ex_pack_cues.json\n    skip_fade), within STOP_WITHIN frames; the pack maps it to fade_out, and the CPS+ model (pack_model.py:\n    the core's tap, verb service and player on the run's latch writes, with the pack's own tracks and\n    header) fades the scene's track out over FADE_FRAMES VBlank ticks (within FADE_RANGE), lands on\n    silence before the next track it starts (never cut by the next scene's cue: not_cut; a cut is reported\n    with the gain it cuts the fade at) and plays nothing from its landing until that track: silent;\n    without a pack, no command until the hand-back but the briefings' arcade intro tunes: the skipped\n    scene's stop NP_STOP within STOP_WITHIN frames if it has a tune (build.json nopack_cues), then each\n    later scene's tune and stop;\n  - to the hand-back, only the cues of the scenes the list still plays (a scene after the skipped one);\n  - from the hand-back, the same commands on the same frames as the reference run, the model starting\n    the same tracks there, and play starting on the same frame: the stage's music as after a normal end.\nRequires of the build's reference runs with a pack (every voice flag: USA 0x01 and 0x03, Japan 0x01 and\n0x05), every stage: each scene's cue starts its own pack row on the core (pack_model.cue_starts: sent,\nbelow the control region, a PLAY row, the model starting that row's track, the track the pack builder\nnamed for the scene and voice), and no cue the core ignores (cues_the_core_ignores empty).\nThe pack must map FADE_CMD to fade_out with FADE_FRAMES ticks (pack_fade). The control (the region's\nvoice) must fail every pack skip run (no fade: build 45 sends nothing, the model shows the scene's\ntrack playing on; a build with the STOP 0xF1 fails the fade check too). The cue control\n(--cue-control, default the control; a build with P0.7's Japanese cues 0xFC-0xFE) must fail the cue\ncheck with Japanese voices (USA 0x03, Japan 0x01): the core never plays the St. Petersburg briefing's,\nthe desert introduction's and the Siberia briefing's tracks.\nReported, not required: the reference's level from the hand-back to the stage's music (its track's\nsilent tail).", formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('--build', type=Path, required=True)
    p.add_argument('--control', type=Path, required=True)
    p.add_argument('--cue-control', type=Path, help='a build whose Japanese cues the core ignores (default: --control)')
    p.add_argument('--pack', type=Path, required=True)
    p.add_argument('--runtime', type=Path, required=True)
    p.add_argument('--hbmame', type=Path, required=True)
    p.add_argument('--rom-dir', type=Path, required=True)
    p.add_argument('--workdir', type=Path, required=True)
    p.add_argument('--sets', default='striderus01,striderjs01')
    p.add_argument('--points', help='indices into SKIP_POINTS (default: all)')
    a = p.parse_args(argv)
    import pack_model as PM
    work = a.workdir.resolve()
    work.mkdir(parents=True, exist_ok=False)
    binary = json.loads((a.runtime / 'runtime.json').read_text())['binary']
    model = PM.Model(a.pack)
    names = PM.track_names()
    points = [SKIP_POINTS[int(i)] for i in a.points.split(',')] if a.points else SKIP_POINTS
    stages = sorted({s for s, _, _ in points})
    report = dict(points=points, fade_cmd=FADE_CMD, fade_frames=FADE_FRAMES, stop_within=STOP_WITHIN, runs=[])
    pv, _, pctrl = model.classify(FADE_CMD)
    report['pack_fade'] = dict(verb=pv, control=pctrl, frames=model.fade_frames(0), law=model.fade_law, const1=model.fade_c1, const2=model.fade_c2)
    pack_fade_ok = pctrl and pv == PM.VERB_FADE_OUT and (model.fade_frames(0) == FADE_FRAMES) and (FADE_RANGE[0] <= FADE_FRAMES <= FADE_RANGE[1])
    print('pack fade', report['pack_fade'], 'OK' if pack_fade_ok else 'WRONG', flush=True)
    ok_build, ok_control = (True, True)
    cue_control_failed = {}
    builds = [('build', a.build.resolve()), ('control', a.control.resolve())]
    if a.cue_control and a.cue_control.resolve() != a.control.resolve():
        builds.append(('cue_control', a.cue_control.resolve()))
    for label, bdir in builds:
        build = json.loads((bdir / 'build.json').read_text())
        for set_name in a.sets.split(','):
            bset = build['sets'][PARENT[set_name]]
            streams, cues = (bset['streams'], bset['cues'])
            files = {q.name: q.read_bytes() for q in (bdir / PARENT[set_name]).iterdir()}
            other = 1 if bset['region_en'] else 2
            jvoice = ('pack_voice1', 1 | 1 << 1, False) if bset['region_en'] else ('pack_region', 1, False)
            if label == 'build':
                variants = [('nopack', 0, True), ('pack_region', 1, True), (f'pack_voice{other}', 1 | other << 1, True)]
            elif label == 'control':
                variants = [('pack_region', 1, True)]
                if len(builds) == 2 and jvoice[0] != 'pack_region':
                    variants.append(jvoice)
            else:
                variants = [jvoice]
            for vname, flag, with_points in variants:
                cue_control = label == 'cue_control' or (label == 'control' and len(builds) == 2)
                is_jvoice = flag and vname == jvoice[0]
                voice = flag >> 1 & 3
                lang = (bset['region_en'] if voice == 0 else voice - 1) if flag else None
                src = work / label / set_name / vname / 'ex'
                (src / PARENT[set_name]).mkdir(parents=True)
                for n, b in files.items():
                    if n == 'strex_p6.bin' and flag:
                        b = bytearray(b)
                        b[1048574] |= flag
                        b = bytes(b)
                    (src / PARENT[set_name] / n).write_bytes(b)
                sets = work / label / set_name / vname / 'sets'
                subprocess.run([sys.executable, str(HBSET), 'build', '--hbmame', str(a.hbmame), '--rom-dir', str(a.rom_dir.resolve()), '--ex-dir', str(src), '--set', set_name, '--date', '2026-10-10', '--out', str(sets)], check=True, stdout=subprocess.DEVNULL)
                m = model if flag else None
                if cue_control and is_jvoice:
                    cue_control_failed.setdefault((set_name, vname), False)
                refs = {}
                for stage in stages:
                    scenes = BX.STAGE_SCENES.get(stage) or BX.DESERT_SCENES.get(stage)
                    sc = [cues[s][lang] for s in scenes] if flag else []
                    r = skip_run(binary, sets, set_name, work / label / set_name / vname / f'ref_s{stage}', stage, None, streams)
                    refs[stage] = skip_facts(r, m, sc)
                    entry = dict(build=label, set=set_name, variant=vname, stage=stage, point=None, facts=refs[stage])
                    if flag:
                        cs = PM.cue_starts(m, [(f, v) for f, _, v in r['snd']], [(cues[s][lang], names.get((s, lang))) for s in scenes])
                        refs[stage]['cue_starts'] = cs
                        entry['checks'] = dict(cues_start=len(cs) == len(scenes) and all((c['ok'] for c in cs)))
                        entry['passed'] = all(entry['checks'].values())
                        if label == 'build':
                            ok_build &= entry['passed']
                        if cue_control and is_jvoice and (not entry['passed']):
                            cue_control_failed[set_name, vname] = True
                    report['runs'].append(entry)
                    print(label, set_name, vname, f'stage {stage} reference', {True: 'cues start their rows', False: 'CUES DO NOT START THEIR ROWS'}.get(entry.get('passed'), ''), json.dumps(refs[stage]), flush=True)
                if not with_points:
                    continue
                for stage, sid, rec in points:
                    scenes = BX.STAGE_SCENES.get(stage) or BX.DESERT_SCENES.get(stage)
                    sc = [cues[s][lang] for s in scenes] if flag else []
                    r = skip_run(binary, sets, set_name, work / label / set_name / vname / f'skip_{sid}_{rec}', stage, (sid, rec), streams)
                    fx = skip_facts(r, m, sc)
                    ref = refs[stage]
                    later = scenes[scenes.index(sid) + 1:] if rec >= 0 else []
                    want = [cues[s][lang] for s in later] if flag else []
                    np_cues = bset.get('nopack_cues', {})
                    i = scenes.index(sid)
                    skipped = sid if rec >= 0 else scenes[i + 1] if i + 1 < len(scenes) else None
                    tbh = fx.get('to_handback', [])
                    if not flag:
                        want = ([NP_STOP] if skipped in np_cues else []) + [v for s in later if s in np_cues for v in (np_cues[s], NP_STOP)]
                    checks = dict(pressed=fx.get('press') is not None and fx.get('skipped_at') is not None and (fx['skipped_at'] - fx['press'] <= STOP_WITHIN), fade=fx.get('fade') is not None and fx['fade'] - fx['press'] <= STOP_WITHIN if flag else skipped not in np_cues or (bool(tbh) and tbh[0][1] == NP_STOP and (tbh[0][0] - fx['press'] <= STOP_WITHIN)), to_handback=[v for f, v in tbh][1 if flag else 0:] == want, after=fx.get('after') == ref.get('after'), play=fx.get('play_after_handback') is not None and fx.get('play_after_handback') == ref.get('play_after_handback'))
                    if flag:
                        md = fx.get('model', {})
                        checks['fade_length'] = md.get('fade_frames') == FADE_FRAMES
                        checks['not_cut'] = md.get('cut_by_next') is False
                        checks['silent'] = md.get('after_landing_db', 0) < PM.SILENT_DB
                        checks['model_after'] = fx.get('model_after') == ref.get('model_after')
                    passed = all(checks.values())
                    report['runs'].append(dict(build=label, set=set_name, variant=vname, stage=stage, point=[sid, rec], facts=fx, checks=checks, passed=passed))
                    print(label, set_name, vname, sid, rec, 'PASS' if passed else 'FAIL', json.dumps({c: v for c, v in checks.items() if not v}), json.dumps({k2: fx.get(k2) for k2 in ('press', 'skipped_at', 'fade', 'to_handback', 'model')}), flush=True)
                    if label == 'build':
                        ok_build &= passed
                    elif flag:
                        ok_control &= not passed

    def ignored_by(labels):
        return sorted({(x['set'], x['variant'], c) for x in report['runs'] if x['build'] in labels for c in x['facts'].get('ignored_cues', [])})
    ignored = ignored_by(('build',))
    ok_cue_control = bool(cue_control_failed) and all(cue_control_failed.values())
    report['build_passed'] = ok_build and (not ignored) and pack_fade_ok
    report['control_failed_every_pack_skip'] = ok_control
    report['cue_control_failed_japanese_voices'] = [[s, v, f] for (s, v), f in sorted(cue_control_failed.items())]
    report['passed'] = report['build_passed'] and ok_control and ok_cue_control
    report['cues_the_core_ignores'] = ignored
    report['controls_cues_the_core_ignores'] = ignored_by(('control', 'cue_control'))
    (work / 'report.json').write_text(json.dumps(report, indent=1) + '\n')
    print('cues the core ignores: build', ignored or 'none', '| controls', report['controls_cues_the_core_ignores'])
    print('build', 'PASS' if report['build_passed'] else 'FAIL', '| control', 'fails as required' if ok_control else 'DID NOT FAIL', '| cue control (Japanese voices)', 'fails as required' if ok_cue_control else f'DID NOT FAIL {cue_control_failed}')
    print('PASS' if report['passed'] else 'FAIL')
    return 0 if report['passed'] else 1
if __name__ == '__main__':
    if sys.argv[1:2] == ['skip']:
        sys.exit(skip_main(sys.argv[2:]))
    sys.exit(main())
