"""W3b portraits gate (HBMAME): each portrait at its encounter, exact, and play unchanged."""
import argparse
import json
import os
import shutil
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import numpy as np
from PIL import Image
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import cps1_gfx as G
import portrait_ex as PX
import respawn_fix as RF
import scene_gate as SG
ROOT = HERE.parents[2]
LUA = ROOT / 'backports/striderex/lua/portrait_gate.lua'
DEBUG_START = ROOT / 'backports/striderex/lua/arcade_debug_start.lua'
HBSET = HERE / 'hbmame_set.py'
PARENT = {'striderus01': 'striderua', 'striderjs01': 'striderjr'}
MAGIC = 40570
EX_GFX = ['strex_gfx.c25', 'strex_gfx.c27', 'strex_gfx.c29', 'strex_gfx.c31']
COLS = ['f', 'on', 'id', 'left', 'tail', 'stage', 'area', 'lives', 'watch', 'sum', 'sprites']
LATENCY = 2
MARK = 65295
MIN_SHOWN = 0.9

def region_of(files):
    region = bytearray(4 * G.MB)
    for j, name in enumerate(EX_GFX):
        part = files[name]
        for i in range(0, G.MB, 2):
            region[4 * i + 2 * j:4 * i + 2 * j + 2] = part[i:i + 2]
    return region

def variants(build, machine, rom_dir, pt):
    """{'build': the build's files, variant: {MAME member name: bytes}} for the members the build changed."""
    import build_ex as BX
    built = {q.name: q.read_bytes() for q in (build / machine).iterdir() if q.is_file()}
    stock = {q.name: q.read_bytes() for q in (rom_dir / machine).iterdir() if q.is_file()}
    layout = RF.SETS[machine]
    files = dict(stock, **{k: v for k, v in built.items() if k in stock})
    sizes = {n: len(files[n]) for n, _, _ in layout}
    img = RF.compose(files, layout)
    at = BX.HOOKS[machine]
    if img[at:at + 2] != b'N\xb9':
        sys.exit(f'{machine}: the stage-intro hook at {at:#x} is not a jsr')
    img[at:at + 6] = BX.HOOK_BYTES
    ex = dict(built, **{n: b for n, b in RF.decompose(img, layout, sizes).items() if n in built})
    patches = json.loads((build / 'build.json').read_text())['sets'][machine]['portrait_patches']
    for name, p in patches.items():
        at, raw = (int(p['at'], 16), bytes.fromhex(p['stock']))
        img[at:at + len(raw)] = raw
    base = dict(built, **{n: b for n, b in RF.decompose(img, layout, sizes).items() if n in built})
    region = region_of(built)
    for it in pt.items:
        for p in it['pictures']:
            off = G.ex_offset('obj', p['code'])
            region[off:off + 128] = bytes((b ^ 255 for b in region[off:off + 128]))
    neg = dict(ex, **dict(zip(EX_GFX, G.split_region(region))))
    p6 = built['strex_p6.bin']
    bank = bytearray((b for i in range(0, len(p6), 2) for b in (p6[i + 1], p6[i])))
    hits = 0
    for it in pt.items:
        pat = b''.join((c.to_bytes(2, 'big') for c in it['colors']))
        new = MARK.to_bytes(2, 'big') * 15 + pat[30:]
        at = bank.find(pat)
        while at >= 0:
            bank[at:at + 32] = new
            hits += 1
            at = bank.find(pat, at + 32)
    if hits < len(pt.items) - 1:
        sys.exit(f'mark: found {hits} portrait color tables')
    mark = dict(ex, **{'strex_p6.bin': bytes((b for i in range(0, len(bank), 2) for b in (bank[i + 1], bank[i])))})
    return (dict(build=built, ex=ex, base=base, neg=neg, mark=mark), patches)

def stage_sets(a, work, machine, var):
    """hbmame_set.py for the build; each variant: that set with its bytes under the build's member names."""
    exdir = work / 'exdir'
    (exdir / machine).mkdir(parents=True)
    for n, b in var['build'].items():
        (exdir / machine / n).write_bytes(b)
    sets = {}
    out = work / 'set_build'
    subprocess.run([sys.executable, str(HBSET), 'build', '--hbmame', str(a.hbmame), '--rom-dir', str(a.rom_dir), '--ex-dir', str(exdir), '--set', a.set, '--date', '2026-10-10', '--out', str(out)], check=True, stdout=subprocess.DEVNULL)
    members = {q.name: q.read_bytes() for q in (out / a.set).iterdir()}
    for v in ('ex', 'base', 'neg', 'mark'):
        d = work / f'set_{v}'
        shutil.copytree(out, d)
        for n, b in var[v].items():
            if b == var['build'][n]:
                continue
            hits = [m for m, mb in members.items() if mb == var['build'][n]]
            if len(hits) != 1:
                sys.exit(f'{n}: {len(hits)} set members carry its bytes')
            (d / a.set / hits[0]).write_bytes(b)
        sets[v] = d
    return sets

def pokes_of(sc):
    """The scenario's research writes as frame:addr=value strings (pokes, ramps, holds)."""
    out = list(sc.get('pokes', []))
    for f0, addr, v0, v1, step in sc.get('ramps', []):
        v, f = (int(v0, 16), f0)
        while v <= int(v1, 16):
            out.append(f'{f}:{addr}={v:x}')
            v, f = (v + step, f + 1)
    for f0, f1, addr, val in sc.get('holds', []):
        out += [f'{f}:{addr}={val}' for f in range(f0, f1 + 1)]
    return out

def run(binary, roms, set_name, out, sc, shots='', dumps=''):
    out.mkdir(parents=True, exist_ok=True)
    env = dict(os.environ, SDL_VIDEODRIVER='dummy', SDL_AUDIODRIVER='dummy', STREX_GATE_OUT=str(out / 'g'), STREX_DEBUG_START=str(DEBUG_START), STREX_STAGE=str(sc['stage']), STREX_AREA=str(sc['area']), STREX_END=str(sc['frames']), STREX_INVINCIBLE='1', STREX_INPUTS=sc['inputs'], STREX_PREFIX=str(out / 'dbg'), STREX_GATE_WATCH=sc['watch'], STREX_GATE_SHOTS=shots, STREX_GATE_DUMPS=dumps, STREX_POKES=';'.join(pokes_of(sc)))
    cmd = [str(binary), set_name, '-rompath', str(roms), '-nothrottle', '-video', 'none', '-sound', 'none', '-skip_gameinfo', '-noautosave', '-cfg_directory', str(out / 'cfg'), '-nvram_directory', str(out / 'nv'), '-snapshot_directory', str(out), '-seconds_to_run', str(sc['frames'] // 50 + 60), '-autoboot_script', str(LUA)]
    p = subprocess.run(cmd, env=env, cwd=out, capture_output=True, text=True, timeout=1800)
    (out / 'mame.log').write_text(p.stdout + p.stderr)
    rows = [l.split('\t') for l in (out / 'g_gate.tsv').read_text().splitlines()]
    log = [dict(zip(COLS, [int(r[0]), int(r[1], 16), *map(int, r[2:8]), int(r[8], 16), r[9], int(r[10])])) for r in rows]
    if p.returncode or len(log) < sc['frames']:
        sys.exit(f'{out}: HBMAME exit {p.returncode}, {len(log)} frames (see mame.log)')
    sync = [tuple(l.split('\t')) for l in (out / 'g_sync.tsv').read_text().splitlines()]
    return dict(frames=log, sync=sync)

def shot(out, f):
    return np.asarray(Image.open(out / f'g_{f:05d}.png').convert('RGB'))

def expected(base_img, it, pic, screen):
    rgb, mask = PX.model_rgb(it, pic, SG.hb_rgb)
    img = base_img.copy()
    x, y = screen
    h, w = mask.shape
    sub, m = (img[y:y + h, x:x + w], mask[:img.shape[0] - y, :img.shape[1] - x])
    sub[m] = rgb[:sub.shape[0], :sub.shape[1]][m]
    return img

def identity(a, b):
    """Sync points that differ (frame or checksum), and a length mismatch; [] = identical."""
    bad = [(x[0], x[1], y[1]) for x, y in zip(a['sync'], b['sync']) if x[1:] != y[1:]][:10]
    if len(a['sync']) != len(b['sync']):
        bad.append(('count', len(a['sync']), len(b['sync'])))
    return bad

def check_pictures(it, sc_dir, base_dir, mark_dir, frames, arm):
    """Per frame: (frame, picture index or None, portrait pixels shown, mismatches against the"""
    magenta = np.array(SG.hb_rgb(MARK), np.uint8)
    x, y = it['screen']
    out = []
    for f in frames:
        t = f - arm - LATENCY
        pic = PX.sequence_at(it, t) if t >= 0 else None
        base, got = (shot(base_dir, f), shot(sc_dir, f))
        box = (shot(mark_dir, f)[y:y + 80, x:x + 128] == magenta).all(-1)
        want = base.copy()
        if pic is not None:
            rgb, _ = PX.model_rgb(it, pic, SG.hb_rgb)
            region = want[y:y + 80, x:x + 128]
            region[box] = rgb[:region.shape[0], :region.shape[1]][box]
        out.append((f, pic, int(box.sum()), int((got != want).any(-1).sum()), bool((base == base[0, 0]).all())))
    return out

def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('--build', type=Path, required=True)
    p.add_argument('--runtime', type=Path, required=True)
    p.add_argument('--timing-runtime', type=Path)
    p.add_argument('--hbmame', type=Path, required=True)
    p.add_argument('--rom-dir', type=Path, required=True)
    p.add_argument('--capture', type=Path, required=True)
    p.add_argument('--workdir', type=Path, required=True)
    p.add_argument('--set', default='striderus01', choices=sorted(PARENT))
    p.add_argument('--only', default='')
    p.add_argument('--jobs', type=int, default=6)
    a = p.parse_args()
    a.rom_dir, a.build = (a.rom_dir.resolve(), a.build.resolve())
    work = a.workdir.resolve()
    work.mkdir(parents=True, exist_ok=False)
    machine = PARENT[a.set]
    if json.loads((a.build / 'build.json').read_text()).get('boss_scene'):
        sys.exit('portrait_gate: not for a build with the boss scenes (boss_scene_gate.py covers them); build with --no-boss-scene to check the in-play portraits')

    class CV:
        region = bytearray(4 * G.MB)
    pt = PX.prepare_unchecked(CV(), a.capture.resolve())
    var, patches = variants(a.build, machine, a.rom_dir, pt)
    sets = stage_sets(a, work, machine, var)
    binary = json.loads((a.runtime / 'runtime.json').read_text())['binary']
    tbin = json.loads((a.timing_runtime / 'runtime.json').read_text())['binary'] if a.timing_runtime else None
    man = PX.manifest()['arcade']
    by_id = {it['id']: it for it in pt.items}
    scenarios = [s for s in man['gate'] if not a.only or s['id'] in a.only.split(',')]
    report = dict(set=a.set, patches=patches, scenarios={})

    def first(sc):
        d = work / sc['id']
        logs = {v: run(binary, sets[v], a.set, d / f'{v}_log', sc) for v in ('ex', 'base')}
        if tbin:
            for v in ('ex', 'base'):
                logs['t_' + v] = run(tbin, sets[v], a.set, d / f't_{v}_log', sc)
        return (sc['id'], logs)
    with ThreadPoolExecutor(a.jobs) as ex:
        logs = dict(ex.map(first, scenarios))
    plan = {}
    for sc in scenarios:
        lg = logs[sc['id']]
        it = by_id[sc['id']]
        arm = next((r['f'] for r in lg['ex']['frames'] if r['on'] == MAGIC and r['id'] == it['index']), None)
        effect = next((r['f'] for r in lg['base']['frames'] if r['watch'] == int(sc['value'], 16)), None)
        base_arm = next((r['f'] for r in lg['base']['frames'] if r['on'] == MAGIC), None)
        total = sum((n for n, _ in it['sequence']))
        plan[sc['id']] = dict(arm=arm, effect=effect, base_arm=base_arm, total=total)

    def second(sc):
        pl = plan[sc['id']]
        if pl['arm'] is None:
            return (sc['id'], None)
        lo, hi = (pl['arm'] - 2, pl['arm'] + pl['total'] + 8)
        d = work / sc['id']
        for v in ('ex', 'base', 'neg', 'mark'):
            run(binary, sets[v], a.set, d / f'{v}_shots', sc, shots=f'{lo}-{hi}')
        return (sc['id'], (lo, hi))
    with ThreadPoolExecutor(a.jobs) as ex:
        windows = dict(ex.map(second, scenarios))
    ok = True
    for sc in scenarios:
        sid, it, pl, lg = (sc['id'], by_id[sc['id']], plan[sc['id']], logs[sc['id']])
        r = dict(plan=pl)
        d = work / sid
        r['moment'] = pl['arm'] is not None and pl['arm'] == pl['effect'] and (pl['base_arm'] is None)
        r['identity'] = identity(lg['ex'], lg['base'])
        r['sync_points'] = len(lg['ex']['sync'])
        if tbin:
            r['identity_8mhz'] = identity(lg['t_ex'], lg['t_base'])
            r['armed_8mhz'] = next((x['f'] for x in lg['t_ex']['frames'] if x['on'] == MAGIC), None)
            r['identity_control'] = len(identity(lg['ex'], lg['t_ex']))
        if windows.get(sid):
            lo, hi = windows[sid]
            frames = range(lo, hi + 1)
            dirs = (d / 'base_shots', d / 'mark_shots', frames, pl['arm'])
            rows = check_pictures(it, d / 'ex_shots', *dirs)
            shown = [f for f, pic, vis, n, blank in rows if vis]
            r['visible'] = [shown[0], shown[-1]] if shown else None
            r['visible_frames'] = len(shown)
            r['missing'] = [f for f, pic, vis, n, blank in rows if pic is not None and (not vis) and (not blank)][:10]
            r['extra'] = [f for f, pic, vis, n, blank in rows if pic is None and vis][:10]
            r['blank_frames'] = sum((1 for f, pic, vis, n, blank in rows if pic is not None and blank))
            shares = [vis / 9600 for f, pic, vis, n, blank in rows if pic is not None and (not blank)]
            r['min_shown_share'] = round(min(shares, default=0), 3)
            r['mean_shown_share'] = round(sum(shares) / len(shares), 3) if shares else 0
            r['ex_mismatch'] = [(f, n) for f, pic, vis, n, blank in rows if n][:10]
            r['neg_mismatch_frames'] = sum((1 for row in check_pictures(it, d / 'neg_shots', *dirs) if row[3]))
            r['base_mismatch_frames'] = sum((1 for row in check_pictures(it, d / 'base_shots', *dirs) if row[3]))
        r['passed'] = bool(r['moment'] and (not r['identity']) and (r.get('visible_frames', 0) > 0) and (r.get('missing') == []) and (r.get('extra') == []) and (r['visible_frames'] + r['blank_frames'] == pl['total']) and (r['mean_shown_share'] >= MIN_SHOWN) and (r.get('ex_mismatch') == []) and (r.get('neg_mismatch_frames', 0) > 0) and (r.get('base_mismatch_frames', 0) > 0) and (not tbin or (not r['identity_8mhz'] and r['armed_8mhz'] is not None and (r['identity_control'] > 0))))
        ok &= r['passed']
        report['scenarios'][sid] = r
        print(sid, json.dumps(r), flush=True)
    report['passed'] = ok
    (work / 'report.json').write_text(json.dumps(report, indent=1) + '\n')
    print('PASS' if ok else 'FAIL')
    return 0 if ok else 1
if __name__ == '__main__':
    sys.exit(main())
