# Strider EX title lettering studies

for the supplied Japanese and English arcade logos, positioned at the lower
right, then asked to thicken the cyan mark's lower-right line and tuck both
marks closer to the primary logos.

## Deliverables

- `jp_ex.png`: 84×40, seven stock cream/rust colors; origin (275,113), on SCROLL3.
- `us_ex.png`: 84×39, eight stock cyan/purple colors; origin (294,122), on SCROLL3.
- `jp_ex.xcf` and `us_ex.xcf`: native-size editable GIMP documents. Letter
  faces and edge/shadow colors occupy separate layers.
- `jp_pixels.txt`, `us_pixels.txt`, and `layout.json`: editable per-pixel
  source, palette, placements and reference identities. A dot is transparent;
  a digit indexes the corresponding palette. These are the authoritative
  source for regeneration; update the grid when making a durable pixel edit.
- `jp_design.png`, `us_design.png`, and `prompts.json`: retained designs and
  exact prompts from the built-in image generation tool. These are guides,
  not sprites intended for direct hardware use.

Both final sprites use only fully opaque or fully transparent pixels. Their
colors are exact samples of their respective reference logos. The flame mark
keeps the Japanese kanji's flat cream face and restrained rust edge; the cyan
mark uses long tapered strokes, blue edge colors and a purple brush shadow.
No smooth alpha fringe is part of the native artwork.

## Process

1. Verify the references are exact 2× enlargements of 384×224 screens.
2. Generate independent transparent EX designs using each logo as its style
   reference, with explicit brush shapes and native-size intent.
3. Crop each design to its opaque lettering, reduce to 84 native pixels wide,
   and translate the face/edge colors to the stock palette. Use a binary
   silhouette, removing isolated pixels instead of keeping antialiased halos.
4. Store the native result as an editable pixel grid. Inspect full-screen and
   8× nearest-neighbor views; remove the cyan E's stray lower-arm edge pixel
   and widen the cyan X's lower-right face by one pixel along its taper.
5. Place each mark closer to its logo, retaining all existing title pixels.
6. Move both marks up and right, clear of the blade streak and the Japanese
   every streak pixel of the title sequence and no logo pixel under the mark.
   The Japanese mark sits above the slice line, beside the SCROLL3 flame it
   leaves with. `scripts/title_ex.py measure` regenerates
   `cells.json` for the positions in `layout.json`.
   Keep the editable mark XCFs separately from the stock title background.

The full-screen PNGs and title XCFs contain copyrighted stock artwork and
remain untracked review output. Only original EX artwork and its recipe are
committed. The two external reference PNG file hashes and normalized native
RGB hashes are recorded in `layout.json`; no machine-specific input path is
required by the builder.

## Regeneration and review

From the repository root, regenerate standalone marks without any screenshot:

```sh
python3 backports/striderex/scripts/build_title_ex_study.py \
  --out backports/striderex/out/title_ex --xcf --publish-assets
```

Supply the two user-provided stock reference PNGs to regenerate full screens:

```sh
python3 backports/striderex/scripts/build_title_ex_study.py \
  --jp-screen /path/to/japanese-reference.png \
  --us-screen /path/to/english-reference.png \
  --out backports/striderex/out/title_ex --xcf --publish-assets
```

References may be the supplied exact 768×448 images or their exact 384×224
nearest-neighbor reductions. The builder verifies their native RGB hashes,
checks palette membership, checks that no existing logo pixel is covered,
and verifies that all pixels outside EX are unchanged. It writes `index.html`,
native and 2× full screens, 8× mark views, transparent PNGs, layered ORA/XCF
documents and a compact verification receipt into the selected output folder.
`--xcf` requires the installed macOS GIMP 3 console. It saves and reopens each
document to check its dimensions and layer count.

Initial verified native PNG SHA-256:

- JP: `0f1f2476f7fa7dd921feeb9e7c6ceeaefb9e481e8a60a0711c85f6da5851d0ca`
- US: `fcc7a97608e1ad484779a18a599e18ef896d3bdf36c007b1113a6a9b735bb42b`

layer: native screen (295,178), (296,178), and (295,179) now use stock blue
`#55BBFF`. The edited full-screen XCF was exported without changing it; its
EX layers were transferred to `us_ex.xcf`, `us_ex.png`, and `us_pixels.txt`.
The regenerated full-screen composite matches the edited XCF pixel for pixel.
Current US PNG SHA-256:
`6e3a8895f027d49c1ea7f8ce654e855688ef32b11df83bf6303d56dcf37bdc42`.

ROM integration (2026-10-10): the marks are installed as SCROLL3 composite
tiles in SCROLL3 palette 0, the logo's own palette, by `scripts/title_ex.py`.
`cells.json` lists the measured cells; `scripts/build_ex.py` does the build.
`title_ex.py gate` passes in HBMAME (see PHASE0_FINDINGS.md, "EX title
marks").

Build 44 (2026-10-14) gave the USA mark's cells SCROLL3 palette 1 and faded
it in after the logo. Since D15's revision the same day, the USA mark is back
in palette 0 and drawn with the logo, so its blue fades in with the logo's
blue and its purple shadow with the logo's purple, frame for frame. The
pixels are unchanged. See PHASE0_FINDINGS.md, "D15 revised: the USA EX mark
fades in with the logo".
