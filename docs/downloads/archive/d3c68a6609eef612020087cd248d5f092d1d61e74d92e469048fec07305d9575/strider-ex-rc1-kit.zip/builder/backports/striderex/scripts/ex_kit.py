"""Reconstruction helper."""
import argparse
import json
import re
import sys
import zipfile
import zlib
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
import mapper_testkit as K
ROOT = Path(__file__).resolve().parents[3]
BASES = {'striderua': (ROOT / 'cpsplus/mra/base_us/striderua.mra', 'Strider EX (USA) [test]', 'us'), 'striderjr': (ROOT / 'cpsplus/mra/base_alt/Strider Hiryu (Japan Resale Ver.).mra', 'Strider Hiryu EX (Japan) [test]', 'jp')}
DATA_ROM = {'striderua': 'st-14.8h', 'striderjr': 'sthj_22.7f'}
EX_GFX = ['strex_gfx.c25', 'strex_gfx.c27', 'strex_gfx.c29', 'strex_gfx.c31']
sys.path.append(str(Path(__file__).resolve().parents[3] / 'release'))
import private_mister as private_test

def crc(b):
    return f'{zlib.crc32(b):08x}'

def make_mra(text, machine, name, rbf, zipname, members):
    rows = re.findall('^\\s+([0-9A-F]{2}(?: [0-9A-F]{2}){7})$', text, re.M)
    if len(rows) < 8:
        sys.exit(f'{machine}: MRA header block not found')
    r0, r4 = (rows[0], rows[4])
    if not r0.startswith('00 04 40 04 40 05') or r4[6:8] != '22' or r4[18:20] != 'FF':
        sys.exit(f'{machine}: MRA header rows changed: {r0} / {r4}')
    text = text.replace(r0, '00 08 40 08 40 09' + r0[17:], 1)
    hdr = K.check_obj_banks()
    if r4[6:18] != '22 40 88 73 ':
        sys.exit(f'{machine}: MRA mapper bytes changed: {r4}')
    text = text.replace(r4, r4[:6] + hdr + r4[20:], 1)
    text = re.sub('<name>[^<]*</name>', f'<name>{name}</name>', text, count=1)
    text = re.sub('<rbf>[^<]*</rbf>', f'<rbf>{rbf}</rbf>', text, count=1)
    text = re.sub('zip="[^"]*"', f'zip="{zipname}"', text, count=1)
    text = re.sub(' asm_md5="[0-9a-f]+"', '', text)
    data = DATA_ROM[machine]
    m = re.search(f'( *)<part name="{re.escape(data)}" crc="[0-9a-f]{{8}}"/>', text)
    if not m:
        sys.exit(f'{machine}: data ROM part {data} not found')
    text = text.replace(m.group(0), m.group(0) + f'\n{m.group(1)}<part name="strex_p6.bin" crc="00000000"/>', 1)
    for a, b in (('<!-- maincpu - starts at 0x0 - length 0x100000 (20 bits) -->', '<!-- maincpu - starts at 0x0 - length 0x200000 (21 bits) -->'), ('<!-- audiocpu - starts at 0x100000', '<!-- audiocpu - starts at 0x200000'), ('<!-- oki - starts at 0x110000', '<!-- oki - starts at 0x210000'), ('<!-- gfx - starts at 0x150000 - length 0x400000 (22 bits) -->', '<!-- gfx - starts at 0x250000 - length 0x800000 (23 bits) -->'), ('<!-- Total 0x550000 bytes - 5440 kBytes -->', '<!-- Total 0xa50000 bytes - 10560 kBytes -->')):
        if text.count(a) != 1:
            sys.exit(f'{machine}: MRA line changed: {a}')
        text = text.replace(a, b)
    ex = ''.join((f'            <part name="{n}" crc="00000000" map="{mp}"/>\n' for n, mp in zip(EX_GFX, ('00000021', '00002100', '00210000', '21000000'))))
    text = text.replace('        <!-- Total', '        <interleave output="64">\n' + ex + '        </interleave>\n        <!-- Total', 1)

    def fix(mt):
        n = mt.group(1)
        if n not in members:
            sys.exit(f'{machine}: part {n} has no file')
        return f'<part name="{n}" crc="{crc(members[n])}"'
    return re.sub('<part name="([^"]+)" crc="[0-9a-f]{8}"', fix, text)

def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('--build', type=Path, required=True)
    p.add_argument('--rom-dir', type=Path, required=True)
    p.add_argument('--core', type=Path, required=True)
    p.add_argument('--rbf', default='jtcps1-strex-test')
    p.add_argument('--date', default='20261009', help="the core file's date suffix")
    p.add_argument('--out', type=Path, required=True)
    a = p.parse_args()
    out = a.out.resolve()
    out.mkdir(parents=True, exist_ok=False)
    arcade, games = (out / '_Arcade', out / 'games/mame')
    (arcade / 'cores').mkdir(parents=True)
    games.mkdir(parents=True)
    (arcade / 'cores' / f'{a.rbf}_{a.date}.rbf').write_bytes(a.core.read_bytes())
    report = {}
    for machine, (base, name, key) in BASES.items():
        stock_by_crc = K.pool([a.rom_dir.resolve() / machine, a.rom_dir.resolve() / 'strider'])
        built = {q.name: q.read_bytes() for q in (a.build / machine).iterdir() if q.is_file()}
        text = base.read_text()
        names = re.findall('<part name="([^"]+)" crc="([0-9a-f]{8})"', text)
        members = {}
        for n, c in names:
            members[n] = built.get(n) or stock_by_crc.get(c)
            if members[n] is None:
                sys.exit(f'{machine}: stock part {n} (CRC {c}) not in the given sets')
        for n in ['strex_p6.bin'] + EX_GFX:
            members[n] = built[n]
        unused = set(built) - set(members)
        if unused:
            sys.exit(f'{machine}: build files the MRA does not load: {sorted(unused)}')
        zipname = f'striderex_{key}.zip'
        mra = make_mra(text, machine, name, a.rbf, zipname, members)
        for n, c in re.findall('<part name="([^"]+)" crc="([0-9a-f]{8})"', mra):
            if crc(members[n]) != c:
                sys.exit(f'{machine}: {n} CRC mismatch')
        (arcade / f'{name}.mra').write_text(mra)
        with zipfile.ZipFile(games / zipname, 'w', zipfile.ZIP_DEFLATED) as z:
            for n, b in sorted(members.items()):
                z.writestr(zipfile.ZipInfo(n, (1996, 1, 1, 0, 0, 0)), b)
        report[machine] = dict(mra=f'{name}.mra', zip=zipname, members=len(members), patched=sorted((n for n in members if n in built)))
        print(machine, report[machine])
    build = json.loads((a.build / 'build.json').read_text())
    (out / 'README.txt').write_text(f"""Strider EX - MiSTer test kit ({a.date} core)\n\nCopy _Arcade and games onto the SD card root (cp -RX on a Mac). Everything the\ntwo MRAs need is in games/mame/striderex_us.zip and striderex_jp.zip.\n\nCore: _Arcade/cores/{a.rbf}_{a.date}.rbf (the mapper test core; it does not\nreplace jtcps1).\n\nWhat to check (no CPS+ pack: cinematics play SILENTLY, with subtitles):\n1. Title (attract): the EX mark at the logo's lower right. Japan: it glows\n   with the logo, then slides away with the lower half in the slice. USA: it\n   comes in only once the logo's second color (magenta) has faded in.\n2. Insert a coin: the PUSH START screen shows the finished title logo, with\n   "1 PLAYER ONLY" / "PUSH START BUTTON!" below it.\n3. START: black, then the PC Engine prologue, the St. Petersburg briefing\n   and the arcade intro. The round-1 faults were the scrambled sprites\n   (the sprite table is now refreshed every frame) and the flash right\n   after START. Watch for any scrambled block, a stalled frame or a hitch.\n   START (a new press) skips a cinematic. Subtitles (DRAFT text; Japanese\n   glyphs still a draft) sit at the bottom of the picture: English on the\n   USA set, Japanese on the Japan set.\n4. Each stage's briefing plays before its arcade intro (Siberia, Amazon,\n   Aerial Battleship; the Third Moon flight and Meio's welcome).\n5. Music: the Aerial Battleship intro and the ending now have their own\n   tunes (restored from the X68000 port).\n6. Die and respawn: the screen stays black until the area is complete, then\n   the whole scene appears at once.\n\nBuild: {', '.join((s['id'] for s in build['scenes']))}; sound ROM sha256 {build.get('sound', {}).get('sha256', '?')[:16]}.\n""")
    (out / 'kit.json').write_text(json.dumps(report, indent=1) + '\n')
    private_test.finalize(out, 'strider-ex', rompaths=[a.rom_dir])
    return 0
if __name__ == '__main__':
    sys.exit(main())
