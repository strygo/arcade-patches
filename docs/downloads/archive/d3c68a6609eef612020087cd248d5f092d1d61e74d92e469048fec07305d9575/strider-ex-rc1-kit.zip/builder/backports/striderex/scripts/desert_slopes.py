"""Strider EX desert: the slopes gate (desert_gate.py slopes) and the floor decoders it uses."""
import json
import sys
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import numpy as np
sys.path.insert(0, str(Path(__file__).resolve().parent))
SLOPE_TOL = 2
SNAP = 13
LAUNCH_SPEED = 640
FOOT = 32
SETTLE = 20
STUCK = 120
BODY = (8, 56)
WALL_REACH = 24
LEDGE = 16
EDGE = 350
ST_GROUND, ST_WALL, ST_AIR, SUB_FALL, SUB_LAUNCH = (0, 4, 12, 12, 8)
KIND_SLOPE = range(2, 8)
SHAFT_HOPS = ';'.join((f'{x - 70}:{x},1152,12' for x in (2370, 2440, 2510, 2580, 2650)))
WALKS = [('s0_shaft', 1, 1760, '', [('fall', 2330, 2380)], True), ('s0', 1, 4400, SHAFT_HOPS + ';2730:2790,1220,12;2780:2870,1312,12;3018:3090,1300,12;3080:3160,1180,12', [], True), ('s1', 2, 1800, '', [('wall', 4380, 4420)], True), ('s2', 3, 3200, '', [('wall', 4380, 4420)], True), ('s3', 4, 1800, '', [], False), ('s4', 5, 1200, '', [], False)]
SCENE_ACTIVE = 'c1e6'

def reader(img, bank):

    def rd(a, n=1):
        if a >= 1048576:
            return bytes(bank[a - 1048576:a - 1048576 + n])
        return bytes(img[a:a + n])
    return rd

def be16(b, a=0):
    return int.from_bytes(b[a:a + 2], 'big')

def be32(b, a=0):
    return int.from_bytes(b[a:a + 4], 'big')

def layer_record(img, stage, map_index=0):
    """The SCROLL3 layer record of a stage (the data ROM directory at 0x80000; the desert's maps"""
    import desert_ex as DX
    tab = be32(img, DX.LAYER_TABLE_DIR + 8)
    return tab + 14 * (stage if stage < 5 else 5 + map_index)

class Floor:
    """The floor (collision set B) of one SCROLL3 layer record, from a build's ROM bytes."""

    def __init__(self, img, bank, record):
        import desert_ex as DX
        rd = reader(img, bank)
        grid, secs = (be32(rd(record + 2, 4)), be32(rd(record + 6, 4)))
        pg, ty, fpg, fl, rec = DX.collision_sets(bytes(img))['B']
        g = rd(grid, 256)
        self.cells = {}
        cache = {}
        for gy in range(8):
            for gx in range(32):
                sec = rd(secs + 384 * g[gy * 32 + gx], 384)
                for sr in range(8):
                    for sc in range(12):
                        e = sec[4 * (sr * 12 + sc):4 * (sr * 12 + sc) + 4]
                        key = (be16(e) & 16383, e[3] >> 5 & 3)
                        if key not in cache:
                            cache[key] = self.lookup(rd, pg, ty, rec, *key)
                        if cache[key]:
                            self.cells[gx * 12 + sc, gy * 8 + sr] = cache[key]

    @staticmethod
    def lookup(rd, pg, ty, rec, code, flips):
        """(kind, 32 heights) of a code drawn with flips, or None (the routine 0x1A72's path)."""
        if code > 2039:
            return None
        p = rd(pg + (code >> 8 & 15) + 8 * flips)[0]
        if not p:
            return None
        t = rd(ty + (p - 1) * 256 + (code & 255))[0]
        if not t:
            return None
        if t < 32:
            return (1, (t,) * 32)
        r = rd(rec + (t - 32) * 33, 33)
        return (r[0], tuple(r[1:]))

    def surfaces(self, x):
        """[(Y of the surface (up), kind)] in the column of world X, from the bottom."""
        out = []
        c = x >> 5
        for wr in range(64):
            v = self.cells.get((c, wr))
            if v and v[1][x & 31]:
                out.append((32 * wr + v[1][x & 31], v[0]))
        return out

    def near(self, x, foot):
        s = self.surfaces(x)
        return min(s, key=lambda v: abs(v[0] - foot)) if s else None

class Reference:
    """The PC Engine floor of one desert map (desert_ex.pce_floor_masks: the floor class table,"""

    def __init__(self, mask, x0, y0):
        import pce_desert_convert as PC
        self.solid = PC.widen_copy(mask)
        self.X0, self.y0 = (x0 * 3 // 2, y0)
        top = self.solid & ~np.vstack([np.zeros((1, self.solid.shape[1]), bool), self.solid[:-1]])
        self.tops = [np.nonzero(top[:, i])[0] for i in range(top.shape[1])]

    def surfaces(self, x):
        i = x - self.X0
        if not 0 <= i < len(self.tops):
            return []
        return [2048 - (self.y0 + int(r)) for r in self.tops[i]]

    def has_floor(self, x, foot):
        return any((abs(y - foot) <= SNAP for y in self.surfaces(x)))

    def near(self, x, foot):
        s = self.surfaces(x)
        return min(s, key=lambda y: abs(y - foot)) if s else None

    def ledge(self, x, foot, face=0):
        """The floor under the foot (the nearest surface within 2 * SNAP) ends within LEDGE px"""
        y = self.near(x, foot)
        if y is None or abs(y - foot) > 2 * SNAP:
            return False
        d = -1 if face else 1
        for dx in range(1, LEDGE + 1):
            n = self.near(x + d * dx, y)
            if n is None or abs(n - y) > SNAP:
                return True
            y = n
        return False

    def wall_ahead(self, x, foot, face=0):
        """Solid in front (WALL_REACH px, by the facing) between BODY px above the foot."""
        d = -1 if face else 1
        for dx in range(1, WALL_REACH + 1):
            i = x + d * dx - self.X0
            if not 0 <= i < self.solid.shape[1]:
                continue
            lo, hi = (2048 - (foot + BODY[1]) - self.y0, 2048 - (foot + BODY[0]) - self.y0)
            lo, hi = (max(lo, 0), min(hi, self.solid.shape[0]))
            if lo < hi and self.solid[lo:hi, i].any():
                return True
        return False

class StockReference:
    """A stock stage's floor as its own reference (the stock control)."""

    def __init__(self, floor):
        self.floor = floor

    def surfaces(self, x):
        return [y for y, k in self.floor.surfaces(x)]

    def has_floor(self, x, foot):
        return any((abs(y - foot) <= SNAP for y in self.surfaces(x)))

    def near(self, x, foot):
        s = self.surfaces(x)
        return min(s, key=lambda y: abs(y - foot)) if s else None
    ledge = Reference.ledge

    def wall_ahead(self, x, foot, face=0):
        return False

def references(census):
    """[Reference] per desert map, in desert_ex.prepare's order (pce_desert_convert.load_maps)."""
    import desert_ex as DX
    import pce_desert_convert as PC
    import pce_desert_maps as M
    maps, shapes = PC.load_maps(Path(census))
    rows, entries = M.verified_maps(Path(census))
    floors = DX.pce_floor_masks(entries, census)
    return [Reference(floors[name], x0, y0) for name, x0, y0, img, colors, sol, fl in maps]

def skyline(surfaces, x0, x1):
    """{x: the top surface's Y} for x0 <= x < x1 with a surface."""
    out = {}
    for x in range(x0, x1):
        s = surfaces(x)
        if len(s):
            out[x] = max(s)
    return out

def slope_columns(sky):
    """Skyline columns on a slope: the skyline changes by 2..12 px over the 7 columns around"""
    out = set()
    for x in sky:
        win = [sky.get(x + d) for d in range(-3, 4)]
        if None in win:
            continue
        steps = [b - a for a, b in zip(win, win[1:])]
        if all((abs(s) <= 2 for s in steps)) and (all((s >= 0 for s in steps)) or all((s <= 0 for s in steps))) and (2 <= abs(win[-1] - win[0]) <= 12):
            out.add(x)
    return out

def runs(cols):
    """Sorted columns -> [(first, last)] of consecutive runs (gaps under 8 px joined)."""
    out = []
    for x in sorted(cols):
        if out and x - out[-1][1] <= 8:
            out[-1][1] = x
        else:
            out.append([x, x])
    return [tuple(r) for r in out]

def static_check(floors, refs):
    """The arcade skyline on the PC Engine skyline's slope columns, per desert map."""
    rep, ok = ([], True)
    for k, (fl, ref) in enumerate(zip(floors, refs)):
        x0, x1 = (ref.X0, ref.X0 + ref.solid.shape[1])
        rs = skyline(ref.surfaces, x0, x1)
        gs = skyline(lambda x: [y for y, kd in fl.surfaces(x)], x0, x1)
        cols = sorted(slope_columns(rs))
        dev = [abs(gs[x] - rs[x]) if x in gs else 99 for x in cols]
        bad = [x for x, d in zip(cols, dev) if d > SLOPE_TOL]
        kinds = {}
        for x in cols:
            v = fl.cells.get((x >> 5, gs.get(x, 0) >> 5)) if x in gs else None
            kinds[str(v[0] if v else None)] = kinds.get(str(v[0] if v else None), 0) + 1
        good = not bad
        rep.append(dict(map=k, slope_columns=len(cols), slope_runs=[list(r) for r in runs(cols)], max_deviation=max(dev) if dev else None, over_tolerance=len(bad), first_over=bad[:8], arcade_kinds_on_slopes=kinds, passed=good))
        ok &= good
    return (rep, ok and any((r['slope_columns'] for r in rep)))

def read_hiryu(out):
    rows = []
    lines = (out / 'hiryu.tsv').read_text().splitlines()
    head = lines[0].split('\t')
    for line in lines[1:]:
        rows.append({k: int(v) for k, v in zip(head, line.split('\t'))})
    return rows

def warp_frames(out):
    return [int(line.split('\t')[2]) for line in (out / 'frames.tsv').read_text().splitlines() if line.startswith('#\twarp')]

def analyze(frames, hiryu, maps_at, floors, refs, warps, stage, slopes_of):
    """Per-frame checks of one walk (see the module docstring). slopes_of: per map, the"""
    events, slope, worst, walked = ([], 0, 0, [])
    bad_frames = []
    settle, prev, still, last_x = (0, None, 0, None)
    warps = set(warps)
    if len(frames) != len(hiryu):
        raise SystemExit(f'{len(frames)} frames, {len(hiryu)} Hiryu rows')
    for fr, h in zip(frames, hiryu):
        f = h['frame']
        if int(fr['frame']) != f:
            raise SystemExit(f'frame {f}: the logs disagree')
        play = fr['stage'] == str(stage) and fr['mode'] == '4'
        if fr.get('active') == SCENE_ACTIVE:
            play = False
        if not play or f in warps:
            settle, prev, still = (0, None, 0)
            continue
        x, foot, st = (h['x'], h['y'] - FOOT, h['st'])
        m = maps_at(f)
        fl, ref = (floors[m], refs[m])
        if settle < SETTLE:
            settle = settle + 1 if st == ST_GROUND else 0
            prev = h
            continue
        if st == ST_GROUND:
            g = fl.near(x, foot)
            pce = ref.near(x, foot) if slopes_of[m] is not None and x in slopes_of[m] else None
            on_pce = pce is not None and abs(pce - foot) <= 2 * SNAP
            if g and g[1] in KIND_SLOPE and (abs(g[0] - foot) <= SNAP) or on_pce:
                slope += 1
                d = foot - g[0] if g else 99
                e = foot - pce if on_pce else 0
                worst = max(worst, abs(d), abs(e))
                walked.append((m, x))
                if abs(d) > SLOPE_TOL or abs(e) > SLOPE_TOL:
                    bad_frames.append(dict(frame=f, x=x, foot=foot, floor=g and g[0], kind=g and g[1], pce_floor=foot - e if on_pce else None))
            still = still + 1 if last_x is not None and x <= last_x else 0
            if still == STUCK:
                if x - int(fr['camx']) >= EDGE:
                    events.append(dict(what='screen edge', frame=f, x=x, foot=foot, camera=int(fr['camx']), ok=True))
                else:
                    events.append(dict(what='stuck', frame=f, x=x, foot=foot, ok=ref.wall_ahead(x, foot, h['face'])))
        if prev is not None and prev['st'] == ST_GROUND and (st != ST_GROUND):
            pf, px = (prev['y'] - FOOT, prev['x'])
            if st == ST_AIR and h['sub'] == SUB_LAUNCH:
                ev = dict(what='launch', speed=prev['speed'], ok=prev['speed'] > LAUNCH_SPEED)
            elif st == ST_AIR:
                ev = dict(what='fall', ok=ref.ledge(px, pf, prev['face']), pce_floor=ref.near(px, pf))
            elif st == ST_WALL:
                ev = dict(what='wall', ok=ref.wall_ahead(px, pf, prev['face']))
            else:
                ev = dict(what=f'state {st:#x}', ok=False)
            ev.update(frame=f, x=px, foot=pf, map=m)
            events.append(ev)
        last_x = x
        prev = h
    return dict(slope_frames=slope, worst_slope_offset=worst, slope_offsets_over=bad_frames[:8], n_slope_offsets_over=len(bad_frames), events=events, walked=walked, passed=not bad_frames and all((e['ok'] for e in events)))

def maps_from(desert_rows):
    marks = [(r['frame'], r['map']) for r in desert_rows]

    def at(f):
        m = 0
        for fr, v in marks:
            if fr > f:
                break
            m = v
        return m
    return at

def walk_env(area, frames, warp_at, stage=5, s1skip=True):
    """A walk's environment. A desert walk that reaches section 1 goes on there after its officer (lua S1SKIP: since"""
    import desert_ex as DX
    import desert_gate as DG
    env = DG.debug_env(stage, area, frames, invincible=True, inputs=False)
    env.update(STREX_INPUTS=f'450-{frames}:P1_JOYSTICK_RIGHT', HIRYU='1', CLIMB='1')
    if warp_at:
        env['WARP_AT'] = warp_at
    if stage == 5 and s1skip:
        env['S1SKIP'] = f'{DX.S1_SKIP_FROM}:{DX.S1_AFTER_OFFICER}'
    return env
STOCK_WALKS = [('stpetersburg', 0, 1, 1300), ('amazon', 2, 1, 850)]
NOT_WALKED = [(1, 4103, 4172, "map 0's rise at X 4079-4148, which map 1 shows only after Hiryu has passed it")]

def coverage(walked, static_rep):
    """Every slope run of the PC Engine skyline (static_check), walked on or exempt (NOT_WALKED)."""
    out = []
    for s in static_rep:
        on = {x for m, x in walked if m == s['map']}
        for a, b in s['slope_runs']:
            why = next((w for m, x0, x1, w in NOT_WALKED if m == s['map'] and x0 == a and (x1 == b)), None)
            out.append(dict(map=s['map'], x=[a, b], walked=any((a <= x <= b for x in on)), exempt=why))
    return out

def check_build(a, build, work, refs, label):
    import desert_gate as DG
    binary = json.loads((a.runtime / 'runtime.json').read_text())['binary']
    machine = DG.PARENT[a.set]
    img, bank = DG.images(build.resolve(), a.rom_dir.resolve(), machine)
    floors = [Floor(img, bank, layer_record(img, 5, k)) for k in range(len(refs))]
    st_rep, st_ok = static_check(floors, refs)
    slopes_of = [set((x for a, b in s['slope_runs'] for x in range(a, b + 1))) for s in st_rep]
    roms = DG.stage_sets(build.resolve(), a.set, a.hbmame, a.rom_dir.resolve(), work / f'sets_{label}')
    jobs = {name: (walk_env(area, n, warp, s1skip=label == 'build'), n) for name, area, n, warp, want, sl in WALKS}
    if label == 'build':
        for name, stage, area, n in STOCK_WALKS:
            jobs['stock_' + name] = (walk_env(area, n, '', stage), n)
    with ThreadPoolExecutor(a.jobs) as ex:
        res = dict(zip(jobs, ex.map(lambda k: DG.run(binary, roms, a.set, work / f'runs_{label}' / k, *jobs[k]), jobs)))
    rep = dict(static=st_rep, walks={}, stock={})
    walked = []
    ok = st_ok
    import desert_ex as DX
    fl_by, ref_by, sl_by = (dict(enumerate(floors)), dict(enumerate(refs)), dict(enumerate(slopes_of)))
    for name, area, n, warp, want, sl in WALKS:
        for k in sorted({r['map'] for r in DG.read_desert(work / f'runs_{label}' / name)} - set(fl_by)):
            fl_by[k] = Floor(img, bank, layer_record(img, 5, k))
            ref_by[k], sl_by[k] = (refs[DX.SEC_MAP[1]], slopes_of[DX.SEC_MAP[1]])
    for name, area, n, warp, want, sl in WALKS:
        out = work / f'runs_{label}' / name
        at = maps_from(DG.read_desert(out))
        r = analyze(res[name], read_hiryu(out), at, fl_by, ref_by, warp_frames(out), 5, sl_by)
        r['expected'] = [dict(what=w, x=[x0, x1], seen=any((e['what'] == w and x0 <= e['x'] <= x1 for e in r['events']))) for w, x0, x1 in want]
        r['passed'] &= all((e['seen'] for e in r['expected'])) and (r['slope_frames'] > 0 or not sl)
        walked += [(m if m < len(refs) else DX.SEC_MAP[1], x) for m, x in r.pop('walked')]
        rep['walks'][name] = r
        ok &= r['passed']
    cov = coverage(walked, st_rep)
    rep['coverage'] = dict(slope_runs=len(cov), walked=sum((c['walked'] for c in cov)), not_walked=[c for c in cov if not c['walked']])
    ok &= bool(cov) and all((c['walked'] or c['exempt'] for c in cov))
    if label == 'build':
        for name, stage, area, n in STOCK_WALKS:
            out = work / f'runs_{label}' / ('stock_' + name)
            fl = Floor(img, bank, layer_record(img, stage))
            r = analyze(res['stock_' + name], read_hiryu(out), lambda f: 0, [fl], [StockReference(fl)], warp_frames(out), stage, [None])
            r.pop('walked')
            rep['stock'][name] = r
            ok &= r['passed']
    rep['passed'] = bool(ok)
    return rep

def cmd_slopes(a):
    work = a.workdir.resolve()
    work.mkdir(parents=True, exist_ok=False)
    refs = references(a.desert_census)
    rep = dict(build=check_build(a, a.build, work, refs, 'build'))
    ok = rep['build']['passed']
    if a.control:
        rep['control'] = check_build(a, a.control, work, refs, 'control')
        rep['control_fails'] = not rep['control']['passed']
        ok &= rep['control_fails']
    rep['passed'] = bool(ok)
    (work / 'report.json').write_text(json.dumps(rep, indent=1) + '\n')
    print(json.dumps(rep, indent=1))
    print('PASS' if ok else 'FAIL')
    return 0 if ok else 1

def self_test(rom_dir=None):
    assert runs([1, 2, 3, 10, 30, 31]) == [(1, 10), (30, 31)]
    sky = {x: 100 for x in range(20)}
    sky.update({x: 100 - (x - 20) // 2 for x in range(20, 60)})
    sky.update({x: 80 - 16 * (x >= 70) for x in range(60, 90)})
    cols = slope_columns(sky)
    assert set(range(24, 57)) <= cols and (not cols & set(range(62, 90))), sorted(cols)
    m = np.zeros((64, 120), bool)
    for x in range(80):
        m[32 + max(0, x - 40) // 4:, x] = True
    ref = Reference(m, 0, 2048 - 64)
    top = lambda x: max(ref.surfaces(x))
    assert not ref.ledge(60, top(60)) and (not ref.ledge(100, top(100))) and ref.ledge(110, top(110))
    if rom_dir:
        import desert_gate as DG
        img, bank = DG.images(None, Path(rom_dir), 'striderua')
        fl = Floor(img, bank, layer_record(img, 0))
        assert fl.surfaces(2368) == [(383, 7)] and fl.surfaces(2400) == [(368, 7)], fl.surfaces(2368)
    print('desert_slopes self-test passed')
    return 0
if __name__ == '__main__':
    import argparse
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('--self-test', action='store_true', required=True)
    p.add_argument('--rom-dir', type=Path, help="stock sets: also decode St. Petersburg's first descent")
    a = p.parse_args()
    sys.exit(self_test(a.rom_dir))
