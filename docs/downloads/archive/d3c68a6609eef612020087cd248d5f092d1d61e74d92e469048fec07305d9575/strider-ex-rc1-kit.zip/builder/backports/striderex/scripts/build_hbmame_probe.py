"""P0.6: build a private CPS-1 HBMAME runtime with the Strider EX mapper."""
import argparse
import hashlib
import json
import subprocess
import sys
import tarfile
from pathlib import Path
SOURCE_REVISION = '7ca9344f867e7536c99cc97dedbafa3a07bb78c7'
SOURCES = 'src/hbmame/drivers/cps1.cpp,src/hbmame/video/cps1.cpp,src/mame/capcom/kabuki.cpp'
EX_FILES = ['strex_gfx.c25', 'strex_gfx.c27', 'strex_gfx.c29', 'strex_gfx.c31']
DATA_ROM = 'ROM_LOAD16_WORD_SWAP( "c03.p5", 0x80000, 0x80000, CRC(9b3cfc08) SHA1(a7d7f270a097437affa845d80bed82a1fa874878) )'

def require(cond, what):
    if not cond:
        sys.exit('build_hbmame_probe: ' + what)

def patch(path, before, after, count=1):
    text = path.read_text()
    require(text.count(before) >= 1, f'{path.name}: anchor not found: {before[:60]!r}')
    path.write_text(text.replace(before, after, count))

def rom_block(tree):
    """striderex: striderua's block with an 8 MB gfx region and the EX files."""
    drv = (tree / 'src/hbmame/drivers/cps1.cpp').read_text()
    start = drv.index('ROM_START( striderua )')
    end = drv.index('ROM_END', start) + len('ROM_END')
    block = drv[start:end].replace('ROM_START( striderua )', 'ROM_START( striderex )')
    require('ROM_REGION( 0x400000, "gfx", 0 )' in block, 'striderua gfx region changed')
    block = block.replace('ROM_REGION( 0x400000, "gfx", 0 )', 'ROM_REGION( 0x800000, "gfx", 0 )')
    require(DATA_ROM in block, 'striderua data ROM line changed')
    block = block.replace(DATA_ROM, 'ROM_LOAD16_WORD_SWAP( "strex_14.8h", 0x080000, 0x080000, NO_DUMP )\n\tROM_LOAD16_WORD_SWAP( "strex_p6.bin", 0x100000, 0x100000, NO_DUMP )')
    key = 'ROM_LOAD( "strider.key", 0x00, 0x80, CRC(39065af5) SHA1(ffff84fd87e851718c564062564970677da923c9) )'
    require(key in block, 'strider.key line changed')
    block = block.replace(key, 'ROM_LOAD( "striderex.key", 0x00, 0x80, NO_DUMP )')
    anchor = '\tROM_REGION( 0x8000, "stars", 0 )'
    ex = ''.join((f'\tROM_LOAD64_WORD( "{name}", 0x{4194304 + 2 * i:06x}, 0x100000, NO_DUMP )\n' for i, name in enumerate(EX_FILES)))
    require(anchor in block, 'stars region anchor')
    return block.replace(anchor, ex + '\n' + anchor)

def subset_adapter(tree):
    """Route the fork's src/hbmame/drivers paths through MAME's SOURCES filter"""
    p = tree / 'scripts/build/makedep.py'
    edits = {"if source.startswith('src/mame/'):": "if source.startswith('src/mame/') or source in ('src/hbmame/drivers/cps1.cpp', 'src/hbmame/video/cps1.cpp'):", "default_roots = ((('src', 'devices'), 0),": "default_roots = ((('src', 'mame'), 0), (('src', 'hbmame'), 0), (('src', 'devices'), 0),", "s[2:] for s in (path_components(s) for s in sources) if s[:2] == ('src', 'mame')": "s[3:] if s[:3] == ('src', 'hbmame', 'drivers') else s[2:] for s in (path_components(s) for s in sources) if s[:2] == ('src', 'mame') or s[:3] == ('src', 'hbmame', 'drivers')", "(components[:2] == ('src', 'mame'))": "(components[:2] == ('src', 'mame') or components[:3] == ('src', 'hbmame', 'drivers'))", "'/'.join(components[2:])": "'/'.join(components[3:] if components[:3] == ('src', 'hbmame', 'drivers') else components[2:])", 'createProjects_mame_': 'createProjects_hbmame_', 'linkProjects_mame_': 'linkProjects_hbmame_', "basepath = os.path.join(root, 'src', 'mame')": "basepath = os.path.join(root, 'src', 'hbmame', 'drivers')", 'MAME_DIR .. "src/mame/shared",': 'MAME_DIR .. "src/hbmame", MAME_DIR .. "src/mame", MAME_DIR .. "src/mame/shared",'}
    text = p.read_text()
    for before, after in edits.items():
        require(before in text, 'pinned source-filter adapter changed: ' + before)
        text = text.replace(before, after)
    p.write_text(text)

def build(source, out, jobs, release_sets=(), board_wait=False, release_only=False):
    out = out.resolve()
    require(not out.exists(), 'use a fresh output directory')
    out.mkdir(parents=True)
    tree = out / 'source'
    tree.mkdir()
    archive = out / 'source.tar'
    with archive.open('wb') as f:
        subprocess.run(['git', '-C', str(source), 'archive', '--format=tar', SOURCE_REVISION], stdout=f, check=True)
    with tarfile.open(archive) as t:
        t.extractall(tree, filter='data')
    archive.unlink()
    video = tree / 'src/hbmame/video/cps1.cpp'
    drv = tree / 'src/hbmame/drivers/cps1.cpp'
    require(not release_only or release_sets, 'release-only needs final registration fragments')
    block = '' if release_only else rom_block(tree)
    if board_wait:
        patch(drv, "M68000(config, m_maincpu, XTAL(10'000'000));    /* verified on pcb */", "M68000(config, m_maincpu, XTAL(10'000'000) * 4 / 5);    /* probe: B-board ONE WAIT bound */")
    probe = '' if release_only else block + '\n\nGAME( 1989, striderex,   strider,  cps1_10MHz, stridrua, cps_state, init_cps1,     ROT0,   "Capcom", "Strider EX mapper probe (not a release)", MACHINE_SUPPORTS_SAVE )\n\n'
    patch(drv, '#include "cps1mis.cpp"', probe + ''.join((Path(f).read_text() + '\n' for f in release_sets)) + '#include "cps1mis.cpp"')
    names = ['striderua', 'striderjr'] + ([] if release_only else ['striderex']) + [Path(f).stem for f in release_sets]
    lst = tree / 'src/hbmame/hbmame.lst'
    text = lst.read_text().replace('@source:cps1mis.cpp\n', '')
    lines = text.split('\n')
    i = lines.index('@source:cps1.cpp')
    for name in names:
        if name not in lines:
            lines.insert(i + 1, name)
    lst.write_text('\n'.join(lines))
    subset_adapter(tree)
    command = ['make', 'TARGET=hbmame', 'SUBTARGET=strex', 'OSD=sdl3', f'SOURCES={SOURCES}', 'NOWERROR=1', 'SYMBOLS=0', 'NO_USE_QTDEBUG=1', f'-j{jobs}']
    (out / 'recipe.json').write_text(json.dumps(dict(source_revision=SOURCE_REVISION, command=command, board_wait=board_wait, video_sha256=hashlib.sha256(video.read_bytes()).hexdigest(), driver_sha256=hashlib.sha256(drv.read_bytes()).hexdigest(), **dict(release_only=True, release_sets={Path(f).name: hashlib.sha256(Path(f).read_bytes()).hexdigest() for f in release_sets}) if release_only else {}), indent=1) + '\n')
    with (out / 'build.log').open('w') as log:
        subprocess.run(command, cwd=tree, stdout=log, stderr=subprocess.STDOUT, check=True)
    binaries = [tree / n for n in ('strex', 'hbmamestrex') if (tree / n).is_file()]
    require(len(binaries) == 1, 'built runtime not found')
    result = dict(source_revision=SOURCE_REVISION, binary=str(binaries[0]), board_wait=board_wait, binary_sha256=hashlib.sha256(binaries[0].read_bytes()).hexdigest())
    (out / 'runtime.json').write_text(json.dumps(result, indent=1) + '\n')
    print(binaries[0])

def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('--source', type=Path, required=True, help='HBMAME git checkout holding SOURCE_REVISION')
    p.add_argument('--outdir', type=Path, required=True)
    p.add_argument('--jobs', type=int, default=8)
    p.add_argument('--release-set', action='append', default=[], metavar='SET.cpp', help="also compile a release set's block (hbmame_set.py build output)")
    p.add_argument('--board-wait', action='store_true', help='main CPU at 8 MHz: the B-board wait-state bound (timing gates)')
    p.add_argument('--release-only', action='store_true', help='compile final release registrations without the mapper probe set')
    a = p.parse_args()
    build(a.source.resolve(), a.outdir, a.jobs, a.release_set, a.board_wait, a.release_only)
    return 0
if __name__ == '__main__':
    sys.exit(main())
