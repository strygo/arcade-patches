"""Runtime checks for native scene continuity and the shortened title hold."""
import nopack_intros as N
import cinematic_music as CM
import original_cinematic as OC
import restore_tunes as RT
from cinematic_followup import SOUND, preceding_files

def sequence(run, sound):
    cues = [f for f, ac, v in run['latch'] if ac == N.ON and v == 36]
    if not cues:
        return (False, [])
    stop = next((f for f, ac, v in run['latch'] if f > cues[0] and v in (251, 241)))
    notes = CM.phrase_notes([(t, r, v) for f, t, r, v in run['ym']], (cues[0] - 1) / N.HZ + 2, (stop - 1) / N.HZ)
    checks = []
    for ch, part in enumerate(OC.score()):
        expected = [sound[RT.KC_ARCADE + n] for n, _ in part['events'] if n is not None]
        actual = [n for t, c, n in notes if c == ch]
        alignments = [offset for offset in range(len(expected)) if all((n == expected[(i + offset) % len(expected)] for i, n in enumerate(actual)))]
        checks.append(dict(channel=ch, notes=len(actual), initial_settle_seconds=2, score_phase=alignments[0] if alignments else None, passed=len(actual) > len(expected) and bool(alignments)))
    return (len(cues) == 1 and all((r['passed'] for r in checks)), checks)

def check(runs, bjs, builds, names, stages):
    reference = bjs['reference']
    if reference.get('reconstructed_from_verified_export') != '261024-16':
        raise ValueError('opening reference must be reconstructed from verified Kit s')
    files = {m: s['files'] for m, s in reference['sets'].items()}
    if files != preceding_files({'build_files': {m: s['files'] for m, s in bjs['build']['sets'].items()}}):
        raise ValueError('opening reference bytes differ from Kit s')
    pack, continuity, opening = ([], [], [])
    for sn in names:
        machine = N.PARENT[sn]
        spec = bjs['build']['sets'][machine]
        sound = (builds['build'] / machine / SOUND[machine]).read_bytes()
        for st in stages:
            for variant in ('pack', 'other_voice'):
                b, s = [runs[label, sn, variant, st, None] for label in ('build', 'reference')]
                facts = N.identical(b, s)
                facts['fade_latch_same'] = b['fade'] == s['fade']
                pack.append(dict(set=sn, stage=st, variant=variant, facts=facts, passed=all((facts[k] for k in ('latch_same', 'frames_same', 'ym_same', 'fade_latch_same')))))
        for st in (0, 4):
            if st not in stages:
                continue
            b, s = [runs[label, sn, 'nopack', st, None] for label in ('build', 'reference')]
            passed, channels = sequence(b, sound)
            rejected, oldchannels = sequence(s, sound)
            spans = N.scene_spans(b, spec['streams'])
            prev, nxt = N.STAGE_LIST[st]
            seam = (spans[prev][1], spans[nxt][0] + next((sc['preroll'] for sc in bjs['build']['scenes'] if sc['id'] == nxt)) + 2)
            commands = [(f, v) for f, ac, v in b['latch'] if seam[0] <= f <= seam[1] and v != 255]
            continuity.append(dict(set=sn, stage=st, channels=channels, seam=seam, seam_commands=commands, old_restart_rejected=not rejected, passed=passed and (not commands)))
        if 0 in stages:
            b, s = [runs[label, sn, 'nopack', 0, None] for label in ('build', 'reference')]
            bs = N.scene_spans(b, spec['streams'])
            ss = N.scene_spans(s, reference['sets'][machine]['streams'])
            bend, send = (bs['prologue'][1], ss['prologue'][1])
            trim = spec['native_opening']
            prefix = [row for row in b['frames'] if row[0] < bend] == [row for row in s['frames'] if row[0] < bend]
            fronts = {row[0]: row[1:] for row in b['video']}
            oldfronts = {row[0]: row[1:] for row in s['video']}
            images = b['pictures'] == s['pictures'] and len(b['pictures']) == 4
            endrec = next((row[1] for row in b['frames'] if row[0] == bend))
            saved = send - bend
            checks = dict(prefix_frames=prefix, final_front_buffers=fronts[bend] == oldfronts[send], cut_record=endrec == trim['cut_record'], saved_frames=abs(saved - trim['removed_records']) <= 2, continued_pictures=images, matching_title_cells=trim['final_cell_state_preserved'])
            opening.append(dict(set=sn, checks=checks, passed=all(checks.values()), original_end_frame=send, new_end_frame=bend, saved_seconds=round(saved / N.HZ, 3), stable_title_seconds=round(trim['hold_records'] / N.HZ, 3), continued_picture_sha256=b['pictures']))
    return dict(baseline_test_id='261024-16', reference_files=files, pack_parity=pack, continuity=continuity, opening=opening, passed=all((row['passed'] for row in pack + continuity + opening)) and all((row['old_restart_rejected'] for row in continuity)))
