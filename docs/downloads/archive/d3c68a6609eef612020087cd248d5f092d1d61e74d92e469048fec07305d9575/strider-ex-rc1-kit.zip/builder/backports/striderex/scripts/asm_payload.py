"""Replay source-bound assembled code, filling owned-media data at reconstruction."""
import argparse
import ast
import base64
from copy import deepcopy
import hashlib
import json
import operator
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile
import zlib
ASM = Path(__file__).resolve().parents[1] / 'asm'
SCHEMA = 'striderex-assembly-payload/1'
DIRECTIVE = re.compile('^\\s*(?:[\\w.]+:\\s*)?(incbin|dc\\.[bwl]|dcb\\.[bwl]|ds\\.[bwl]|even)\\b\\s*(.*)$', re.I)

def sha(data):
    return hashlib.sha256(data).hexdigest()

def identity(value):
    return sha(json.dumps(value, sort_keys=True, separators=(',', ':')).encode())

def lines(path):
    result = []
    for line in path.read_text(encoding='utf-8').splitlines():
        parts = re.split('("[^"\\n]*"|\\x27[^\\x27\\n]*\\x27)', line)
        text = ''
        for i, part in enumerate(parts):
            if i % 2:
                text += part
            else:
                text += re.sub('\\s+', ' ', part.split(';', 1)[0])
                if ';' in part:
                    break
        if text.strip():
            result.append((' ' if line[:1].isspace() else '') + text.strip())
    return result

def invocation(argv):
    flags, dirs, output, listing = ([], [Path.cwd()], None, None)
    source = Path(argv[-1]).resolve()
    i = 0
    while i < len(argv) - 1:
        arg = argv[i]
        if arg in ('-I', '-o', '-L'):
            value = argv[i + 1]
            i += 2
            if arg == '-I':
                dirs.append(Path(value).resolve())
            elif arg == '-o':
                output = Path(value).resolve()
            else:
                listing = Path(value).resolve()
        elif arg.startswith('-I'):
            dirs.append(Path(arg[2:]).resolve())
            i += 1
        else:
            flags.append(arg)
            i += 1
    if output is None or '-Fbin' not in flags or '-m68000' not in flags:
        raise ValueError('unsupported assembly invocation')
    sources, binaries, paths = ({}, {}, {})

    def locate(name, parent):
        found = next((p / name for p in [parent, *dirs, source.parent] if (p / name).is_file()), None)
        if found is None:
            raise ValueError('missing assembly input: ' + name)
        return found.resolve()

    def visit(path):
        name = path.name
        if name in paths:
            if paths[name] != path:
                raise ValueError('ambiguous assembly basename: ' + name)
            return
        paths[name] = path
        sources[name] = lines(path)
        for line in sources[name]:
            m = re.search('\\b(include|incbin)\\s+"([^"]+)"\\s*$', line, re.I)
            if not m:
                continue
            other = locate(m[2], path.parent)
            if other.name != m[2]:
                raise ValueError('assembly includes must use portable basenames')
            if m[1].lower() == 'include':
                visit(other)
            else:
                if other.name in paths and paths[other.name] != other:
                    raise ValueError('ambiguous binary basename')
                paths[other.name] = other
                binaries[other.name] = other.read_bytes()
    visit(source)
    spec = dict(source=source.name, flags=flags, sources={n: sha(('\n'.join(v) + '\n').encode()) for n, v in sources.items()}, binaries={n: dict(bytes=len(b), sha256=sha(b)) for n, b in binaries.items()})
    return dict(spec=spec, key=identity(spec), sources=sources, binaries=binaries, paths=paths, output=output, listing=listing, flags=flags, source=source)

def symbols(text):
    return {m[1]: int(m[2], 16) for m in re.finditer('^([^\\s]+)\\s+[AE]:([0-9A-Fa-f]+)\\s*$', text, re.M)}

def expression(text, syms, pc):
    text = re.sub('\\$([0-9a-fA-F]+)', '0x\\1', text.strip())
    text = re.sub('%([01]+)', '0b\\1', text)
    if text == '*':
        return pc
    text = re.sub('(?<=[-+(,])\\s*\\*(?!\\w)', str(pc), text)
    tree = ast.parse(text, mode='eval')
    binary = {ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul, ast.Div: operator.floordiv, ast.FloorDiv: operator.floordiv, ast.Mod: operator.mod, ast.BitAnd: operator.and_, ast.BitOr: operator.or_, ast.BitXor: operator.xor, ast.LShift: operator.lshift, ast.RShift: operator.rshift}
    unary = {ast.UAdd: operator.pos, ast.USub: operator.neg, ast.Invert: operator.invert}

    def value(node):
        if isinstance(node, ast.Constant) and isinstance(node.value, int):
            return node.value
        if isinstance(node, ast.Name) and node.id in syms:
            return syms[node.id]
        if isinstance(node, ast.BinOp) and type(node.op) in binary:
            return binary[type(node.op)](value(node.left), value(node.right))
        if isinstance(node, ast.UnaryOp) and type(node.op) in unary:
            return unary[type(node.op)](value(node.operand))
        raise ValueError('unsupported assembly data expression: ' + text)
    return value(tree.body)

def data(line, syms, pc, binaries):
    m = DIRECTIVE.fullmatch(line)
    if not m:
        raise ValueError('payload splice no longer names a data directive')
    op, args = (m[1].lower(), m[2])
    if op == 'incbin':
        name = re.fullmatch('"([^"]+)"', args)
        if not name:
            raise ValueError('unsupported binary slice')
        return binaries[name[1]]
    if op == 'even':
        return b'\x00' * (pc & 1)
    width = {'b': 1, 'w': 2, 'l': 4}[op[-1]]
    words = re.findall('(?:"[^"]*"|\\x27[^\\x27]*\\x27|[^,])+', args)

    def encode(word):
        if word.strip().startswith(('"', "'")):
            if width != 1:
                raise ValueError('wide assembly string')
            return ast.literal_eval(word.strip()).encode('ascii')
        return (expression(word, syms, pc) % (1 << 8 * width)).to_bytes(width, 'big')
    if op.startswith('dc.'):
        return b''.join((encode(v) for v in words))
    count = expression(words[0], syms, pc)
    if not 0 <= count <= 1048576:
        raise ValueError('assembly data count out of range')
    return (encode(words[1]) if op.startswith('dcb.') else bytes(width)) * count

def replay(entry, call):
    if entry['inputs'] != call['spec']:
        raise ValueError('preassembled source identity differs')
    raw = bytearray(zlib.decompress(base64.b64decode(entry['code_zlib'])))
    for row in entry['splices']:
        at, size = (row['offset'], row['bytes'])
        if raw[at:at + size] != bytes(size):
            raise ValueError('nonempty owned-media placeholder')
        blob = data(call['sources'][row['source']][row['line']], entry['symbols'], entry['origin'] + at, call['binaries'])
        if len(blob) != size:
            raise ValueError('owned-media splice size differs')
        raw[at:at + size] = blob
    if sha(raw) != entry['output_sha256']:
        raise ValueError('preassembled output differs')
    call['output'].write_bytes(raw)
    if call['listing']:
        call['listing'].write_text(entry['listing'])

def record(vasm, argv, folder):
    vasm = Path(vasm).resolve()
    call = invocation(argv)
    with tempfile.TemporaryDirectory(prefix='strider-assembly-') as temp:
        temp = Path(temp)
        original = temp / 'original.lst'
        original = call['listing'] or original
        subprocess.run([str(vasm), *argv, *([] if call['listing'] else ['-L', str(original)])], check=True)
        raw = call['output'].read_bytes()
        listing = original.read_text()
        if call['listing']:
            call['listing'].write_text(listing)
        section = re.findall('^\\w+: "[^"]+" \\(([0-9A-Fa-f]+)-([0-9A-Fa-f]+)\\)', listing, re.M)
        if not section:
            raise ValueError('payload needs absolute sections')
        spans = [(int(start, 16), int(stop, 16)) for start, stop in section]
        origin = min((start for start, stop in spans))
        end = max((stop for start, stop in spans))
        if end - origin != len(raw):
            raise ValueError('section does not cover complete output')
        markers = []
        for name, source in call['sources'].items():
            modified = []
            for index, line in enumerate(source):
                m = DIRECTIVE.fullmatch(line)
                derived = not call['paths'][name].is_relative_to(ASM)
                if m and (m[1].lower() == 'incbin' or derived):
                    tag = '__strex_payload_' + str(len(markers))
                    markers.append(dict(source=name, line=index, tag=tag))
                    modified += [tag + '_start equ *', line, tag + '_end equ *']
                else:
                    modified.append(line)
            (temp / name).write_text('\n'.join(modified) + '\n')
        for name, blob in call['binaries'].items():
            (temp / name).write_bytes(blob)
        probe, plist = (temp / 'instrumented.bin', temp / 'instrumented.lst')
        subprocess.run([str(vasm), *call['flags'], '-Lall', '-I', str(temp), '-L', str(plist), '-o', str(probe), str(temp / call['source'].name)], cwd=temp, check=True)
        if probe.read_bytes() != raw:
            raise ValueError('data markers altered machine code')
        syms = symbols(plist.read_text())
        template = bytearray(raw)
        splices = []
        for row in markers:
            if row['tag'] + '_start' not in syms:
                continue
            start, stop = (syms[row['tag'] + '_start'], syms[row['tag'] + '_end'])
            if start == stop:
                continue
            at, size = (start - origin, stop - start)
            if not 0 <= at <= at + size <= len(raw):
                raise ValueError('data splice outside section')
            blob = data(call['sources'][row['source']][row['line']], syms, start, call['binaries'])
            if blob != raw[at:at + size]:
                raise ValueError('data directive encoder differs: ' + str(row))
            template[at:at + size] = bytes(size)
            splices.append(dict(source=row['source'], line=row['line'], offset=at, bytes=size))
        splices.sort(key=lambda r: r['offset'])
        if any((a['offset'] + a['bytes'] > b['offset'] for a, b in zip(splices, splices[1:]))):
            raise ValueError('overlapping data splices')
        entry = dict(inputs=call['spec'], origin=origin, splices=splices, symbols={k: v for k, v in syms.items() if not k.startswith('__strex_payload_')}, listing='\n'.join((line for line in listing.splitlines() if re.fullmatch('[^\\s]+\\s+[AE]:[0-9A-Fa-f]+\\s*', line))) + '\n', code_zlib=base64.b64encode(zlib.compress(template, 9)).decode(), output_sha256=sha(raw))
        replay(entry, call)
        folder.mkdir(parents=True, exist_ok=True)
        path = folder / (call['key'] + '.json')
        content = json.dumps(entry, sort_keys=True, indent=2) + '\n'
        if path.exists() and path.read_text() != content:
            raise ValueError('assembly record collision')
        path.write_text(content)

def command(vasm):
    vasm = Path(vasm)
    if vasm.suffix == '.json':
        return [sys.executable, str(Path(__file__).resolve()), '--catalog', str(vasm), '--']
    folder = os.environ.get('STREX_RECORD_ASSEMBLY')
    if folder:
        return [sys.executable, str(Path(__file__).resolve()), '--record', folder, '--vasm', str(vasm), '--']
    return [str(vasm)]

def self_test(vasm):
    with tempfile.TemporaryDirectory(prefix='strider-payload-test-') as temp:
        root = Path(temp)
        source = root / 'source.s'
        inc = root / 'data.inc'
        owned = root / 'owned.bin'
        media = hashlib.sha256(b'fixture owned bytes').digest()
        owned.write_bytes(media)
        inc.write_text(' ifne REGION_EN\n dc.w $1234\n else\n dc.w $5678\n endc\n')
        source.write_text(' org $1000\nstart: moveq #0,d0\n include "data.inc"\n incbin "owned.bin"\n dcb.b $1040-*, $ff\n dc.l start\n rts\n org $1050\n dc.b 9,8\n')
        args = ['-Fbin', '-m68000', '-quiet', '-DREGION_EN=1', '-I', str(root), '-L', str(root / 'source.lst'), '-o', str(root / 'source.bin'), str(source)]
        record(vasm, args, root / 'records')
        entry = json.loads(next((root / 'records').glob('*.json')).read_text())
        expected = bytes.fromhex('70001234') + media + b'\xff' * 28 + bytes.fromhex('000010004e75') + bytes(10) + b'\t\x08'
        assert (root / 'source.bin').read_bytes() == expected
        assert media not in zlib.decompress(base64.b64decode(entry['code_zlib']))
        old = subprocess.run

        def refuse(*args, **kwargs):
            raise AssertionError('recipient invoked an external tool')
        subprocess.run = refuse
        try:
            replay(entry, invocation(args))
            assert (root / 'source.bin').read_bytes() == expected
            source.write_text(source.read_text() + '; private review comment removed by public export\n')
            replay(entry, invocation(args))
            for change in ('source', 'media', 'flags', 'payload'):
                damaged = deepcopy(entry)
                argv = list(args)
                before_source = source.read_bytes()
                before_media = owned.read_bytes()
                if change == 'source':
                    source.write_text(source.read_text().replace('moveq #0', 'moveq #1'))
                elif change == 'media':
                    owned.write_bytes(bytes(reversed(media)))
                elif change == 'flags':
                    argv[3] = '-DREGION_EN=0'
                else:
                    damaged['code_zlib'] = base64.b64encode(zlib.compress(bytes(len(expected)))).decode()
                try:
                    replay(damaged, invocation(argv))
                except ValueError:
                    pass
                else:
                    raise AssertionError('accepted damaged ' + change)
                source.write_bytes(before_source)
                owned.write_bytes(before_media)
        finally:
            subprocess.run = old
        print('PASS assembly payload: native bytes, data holes, comments, tool-free replay and four damaged controls')

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--catalog', type=Path)
    p.add_argument('--record', type=Path)
    p.add_argument('--vasm', type=Path)
    p.add_argument('--self-test', action='store_true')
    a, argv = p.parse_known_args()
    if argv and argv[0] == '--':
        argv = argv[1:]
    if a.self_test:
        if not a.vasm:
            p.error('self-test requires the producer assembler')
        self_test(a.vasm)
    elif a.record:
        if not a.vasm:
            p.error('recording requires the producer assembler')
        record(a.vasm, argv, a.record)
    else:
        catalog = json.loads(a.catalog.read_text())
        call = invocation(argv)
        if catalog['schema'] != SCHEMA:
            raise ValueError('unknown preassembly schema')
        entry = catalog['entries'].get(call['key'])
        if entry is None:
            raise ValueError('no verified preassembly for ' + call['source'].name)
        replay(entry, call)
if __name__ == '__main__':
    main()
