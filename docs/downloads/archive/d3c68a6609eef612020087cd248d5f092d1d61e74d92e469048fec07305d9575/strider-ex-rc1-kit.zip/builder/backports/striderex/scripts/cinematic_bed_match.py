"""P0.12 route 1: do the cinematic music beds exist elsewhere without voice?"""
import argparse
import json
import subprocess
import sys
from pathlib import Path
import numpy as np
ROOT = Path(__file__).resolve().parents[3]
TRANSCRIPTS = ROOT / 'backports/striderex/manifests/pce_cinematic_transcripts.json'
RATE = 11025
HOP = 256
NFFT = 2048
BANDS = 48

def decode(bin_path, index01):
    raw = subprocess.run(['ffmpeg', '-loglevel', 'error', '-f', 's16le', '-ar', '44100', '-ac', '2', '-i', str(bin_path), '-ss', f'{index01:.6f}', '-ac', '1', '-ar', str(RATE), '-f', 's16le', '-'], capture_output=True, check=True).stdout
    return np.frombuffer(raw, '<i2').astype(np.float32) / 32768

def features(x):
    """Per-frame normalised log band energies (frames x BANDS)."""
    if len(x) < NFFT:
        x = np.pad(x, (0, NFFT - len(x)))
    n = 1 + (len(x) - NFFT) // HOP
    idx = np.arange(NFFT)[None, :] + HOP * np.arange(n)[:, None]
    spec = np.abs(np.fft.rfft(x[idx] * np.hanning(NFFT), axis=1)) ** 2
    freqs = np.fft.rfftfreq(NFFT, 1 / RATE)
    edges = np.geomspace(60, RATE / 2, BANDS + 1)
    bands = np.stack([spec[:, (freqs >= lo) & (freqs < hi)].sum(1) for lo, hi in zip(edges[:-1], edges[1:])], 1)
    f = np.log(bands + 1e-09)
    f -= f.mean(1, keepdims=True)
    f /= f.std(1, keepdims=True) + 1e-09
    return f

def best_match(query, target):
    """Max over lags of mean per-frame correlation; returns (score, lag_frames)."""
    q, t = (query, target)
    if len(t) < len(q):
        return (0.0, 0)
    n = len(t) - len(q) + 1
    acc = np.zeros(n)
    for b in range(q.shape[1]):
        acc += np.correlate(t[:, b], q[:, b], mode='valid')
    acc /= q.size
    k = int(acc.argmax())
    return (float(acc[k]), k)

def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('--cue', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--min-gap', type=float, default=1.5, help='shortest music-only stretch to test (s)')
    a = p.parse_args()
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    from cinematic_transcripts import cue_tracks
    tracks = cue_tracks(a.cue)
    feats = {t: features(decode(*tracks[t])) for t in sorted(tracks) if t >= 3}
    data = json.loads(TRANSCRIPTS.read_text())
    sec = HOP / RATE
    report = []
    for tr in data['tracks']:
        t = tr['track']
        f = feats[t]
        total = len(f) * sec
        speech = [(s['start'], s['end']) for s in tr['segments']]
        gaps, cur = ([], 0.0)
        for s0, s1 in speech:
            if s0 - cur >= a.min_gap:
                gaps.append((cur, s0))
            cur = max(cur, s1)
        if total - cur >= a.min_gap:
            gaps.append((cur, total))
        for g0, g1 in gaps:
            q = f[int(g0 / sec):int(g1 / sec)]
            scores = []
            for other, of in feats.items():
                if other == t:
                    continue
                sc, lag = best_match(q, of)
                scores.append((sc, other, lag * sec))
            scores.sort(reverse=True)
            top = scores[:3]
            report.append(dict(track=t, gap=[round(g0, 2), round(g1, 2)], best=[dict(track=o, score=round(sc, 3), at=round(at, 2)) for sc, o, at in top]))
            print(f'tr{t} gap {g0:6.2f}-{g1:6.2f}s  best: ' + ', '.join((f'tr{o}@{at:.1f}s r={sc:.2f}' for sc, o, at in top)))
    a.output.write_text(json.dumps(report, indent=1) + '\n')
    return 0
if __name__ == '__main__':
    sys.exit(main())
