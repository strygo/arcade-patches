"""Full-scene native score checks; invoked by nopack_intros.py gate."""
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
from pathlib import Path
import numpy as np
import nopack_intros as N
import pce_sfx as PS
from cinematic_census import compare_ym

def coverage(r, wav, streams, scenes):
    pcm = PS.read_wav(wav).astype(float).mean(1) / 32768.0
    spans = N.scene_spans(r, streams)
    out = {}
    for sid, (first, end, skip) in spans.items():
        cue = first + scenes[sid]['preroll'] + 1
        finish = skip or end
        if finish is None or finish <= cue:
            continue
        fade = next((f for f, ac, v in r['latch'] if cue < f < finish and ac == N.ON and (v == 251)), None)
        x = pcm[round((cue - 1) / N.HZ * 48000):round(((fade or finish) - 1) / N.HZ * 48000)]
        width = 12000
        count = len(x) // width
        rms = np.sqrt((x[:count * width].reshape(count, width) ** 2).mean(1) + 1e-20)
        quiet = 20 * np.log10(rms) < -60
        run = longest = 0
        for value in quiet:
            run = run + 1 if value else 0
            longest = max(longest, run)
        out[sid] = dict(seconds=round((finish - cue) / N.HZ, 3), windows=count, longest_silence_s=longest * 0.25, passed=count > 0 and longest <= 4)
        if fade:
            tail = pcm[round((finish - 7) / N.HZ * 48000):round((finish - 1) / N.HZ * 48000)]
            db = float(20 * np.log10(np.sqrt((tail ** 2).mean()) + 1e-12))
            out[sid]['fade_tail_dbfs'] = round(db, 3)
            out[sid]['passed'] &= db < -90
    return out

def protocol(b, c, bj, cj, stage, pack_run=None):
    """Remove only validated cue/stop differences; all remaining writes must match."""
    scenes = {s['id']: s for s in bj['scenes']}
    spans = N.scene_spans(b, bj['streams'])
    removals = [set(), set()]
    checks, facts = ({}, {})
    ends = []
    for sid in N.STAGE_LIST[stage]:
        if sid not in spans:
            checks[sid + '_present'] = False
            continue
        first, end, skip = spans[sid]
        old_cue = cj['nopack_cues'].get(sid, 255)
        before = skip or end or N.END_FRAMES
        if old_cue != 255:
            candidates = [f for f, ac, v in c['latch'] if first <= f < before and ac == N.ON and (v == old_cue)]
        elif pack_run:
            pack_cue = bj['cues'][sid][bj['region_en']]
            candidates = [f for f, ac, v in pack_run['latch'] if ac == N.ON and v == pack_cue]
        else:
            candidates = []
        if len(candidates) != 1:
            checks[sid + '_cue_reference'] = False
            continue
        cue = candidates[0]
        facts[sid + '_cue_frame'] = cue
        if skip is None or cue < skip:
            predecessor = scenes[sid].get('continues')
            continuous = bool(bj.get('native_opening') and predecessor in spans and (spans[predecessor][2] is None))
            for k, (r, value) in enumerate(((b, 255 if continuous else 36), (c, cj['nopack_cues'].get(sid, 255)))):
                found = [i for i, (f, ac, v) in enumerate(r['latch']) if f == cue and ac == N.ON and (v == value)]
                checks[sid + ('_cue' if k == 0 else '_control_cue')] = len(found) == 1
                removals[k].update(found)
            keys = N.ym_keys(b, cue, (skip or end or cue) + 1)
            checks[sid + '_starts'] = continuous or (bool(keys) and (keys[0] - cue) / N.HZ <= N.FIRST_KEY)
        if skip is not None or sid == N.STAGE_LIST[stage][-1]:
            terminal = skip or end
            if terminal is None:
                checks[sid + '_end'] = False
            else:
                ends.append(terminal)
    for k, r in enumerate((b, c)):
        stops = [(i, f) for i, (f, ac, v) in enumerate(r['latch']) if ac == N.HOLD and v == 241]
        valid = [(i, f) for i, f in stops if any((0 <= f - end <= 1 for end in ends))]
        removals[k].update((i for i, _ in valid))
        if k == 0:
            checks['stops'] = len(valid) == len(ends) and all((sum((0 <= f - end <= 1 for _, f in valid)) == 1 for end in ends))
            for _, f in valid:
                next_command = N.next_command(r, f) or N.END_FRAMES

                def keys(run):
                    return [(ff / N.HZ, reg, value) for ff, t, reg, value in run['ym'] if f + 2 <= ff < next_command and reg == 8 and value & 120]
                checks['stopped_' + str(f)] = compare_ym(keys(r), keys(c))
        facts['stops_' + str(k)] = [f for _, f in valid]
    if bj.get('native_fade'):
        sid = N.STAGE_LIST[stage][-1]
        first, end, skip = spans.get(sid, (None, None, None))
        wanted = end is not None and skip is None
        fades = [(i, f) for i, (f, ac, v) in enumerate(b['latch']) if ac == N.ON and v == 251]
        lead = bj['native_fade'].get('frames', 100) if isinstance(bj['native_fade'], dict) else 100
        interval = bj['native_fade'].get('interval', 3) if isinstance(bj['native_fade'], dict) else 3
        checks['fade_command'] = len(fades) == 1 and lead - 1 <= end - fades[0][1] <= lead + 2 if wanted else not fades
        for i, f in fades:
            removals[0].add(i)
            idle = [j for j, row in enumerate(c['latch']) if row == (f, N.ON, 255)]
            checks['fade_replaces_idle'] = len(idle) == 1
            removals[1].update(idle)
            laugh = next((ff for ff, ac, v in b['latch'] if ff > f and v == 155), end)
            levels = [v for ff, v, interval in b['attenuation'] if f <= ff < laugh]
            checks['native_attenuation_ramp'] = bool(levels) and levels[0] <= 12 and (levels[-1] == 127) and (len(set(levels)) >= 60) and all((a <= z for a, z in zip(levels, levels[1:])))
            checks['fade_interval'] = [(ff, v) for ff, v in b['fade'] if first <= ff < end] == [(f, interval)] or [(ff, v) for ff, v in b['fade'] if first <= ff < end] == [(f - 1, interval)]
            facts['fade'] = dict(frame=f, before_end_frames=end - f, first_attenuation=levels[0] if levels else None, last_attenuation=levels[-1] if levels else None, distinct_levels=len(set(levels)), attenuation_at_stop=next((v for ff, v, interval in b['attenuation'] if ff == end - 1), None), ramp_measured_until='laugh', silence_frame=next((ff for ff, v, interval in b['attenuation'] if f <= ff < laugh and v == 127), None))
        laughs = [(f, v) for f, ac, v in b['latch'] if v == 155]
        checks['laugh_command'] = bool(laughs) and laughs == [(f, v) for f, ac, v in c['latch'] if v == 155]
        if wanted and 'fade' in facts:
            silent = facts['fade']['silence_frame']
            checks['fade_before_laugh'] = silent is not None and bool(laughs) and (silent < laughs[0][0])
            if bj.get('native_opening'):
                duration = (silent - facts['fade']['frame']) / N.HZ if silent is not None else 0
                facts['fade']['ramp_seconds'] = round(duration, 3)
                checks['long_fade'] = 2.8 <= duration <= 3.6
            facts['fade']['laugh_frame'] = laughs[0][0] if laughs else None
        bo, co = (b['oki'], c['oki'])
        checks['oki_samples'] = bool(bo) and len(bo) == len(co) and all((v == w and abs(f - g) <= 1 for (f, v), (g, w) in zip(bo, co)))
    stripped = [[x for i, x in enumerate(r['latch']) if i not in removals[k]] for k, r in enumerate((b, c))]
    checks['other_latch_writes'] = stripped[0] == stripped[1]
    checks['frames'] = N.identical(b, c)['frames_same']
    hb = b['meta'].get('handback')
    music = next((f for f, ac, v in b['latch'] if hb and f > hb and (v < 48 or v in (121, 122))), None)
    if music is not None:
        yb, yc = [[(f, reg, v) for f, t, reg, v in r['ym'] if f >= music and (not 16 <= reg <= 20)] for r in (b, c)]
        checks['gameplay_music'] = bool(yb) and compare_ym([(f / N.HZ, reg, v) for f, reg, v in yb], [(f / N.HZ, reg, v) for f, reg, v in yc])
    else:
        checks['gameplay_music'] = False
    return dict(checks=checks, facts=facts, passed=all(checks.values()))

def gate(a):
    work = a.workdir.resolve()
    work.mkdir(parents=True, exist_ok=False)
    builds = {'build': a.build.resolve(), 'control': a.control.resolve()}
    if getattr(a, 'reference_build', None):
        builds['reference'] = a.reference_build.resolve()
    bjs = {label: json.loads((path / 'build.json').read_text()) for label, path in builds.items()}
    runtime = json.loads((a.runtime / 'runtime.json').read_text())
    binary = runtime['binary']
    if hashlib.sha256(Path(binary).read_bytes()).hexdigest() != runtime['binary_sha256']:
        raise ValueError('cinematic gate runtime binary changed')
    stages = [int(s) for s in a.stages.split(',')]
    sets, jobs = ({}, [])
    for label, build in builds.items():
        for sn in a.sets.split(','):
            other = 1 if bjs['build']['sets'][N.PARENT[sn]]['region_en'] else 2
            for variant, flag in (('nopack', 0), ('pack', 1), ('other_voice', 1 | other << 1)):
                sets[label, sn, variant] = N.stage_set(a.hbmame, a.rom_dir.resolve(), build, sn, work / 'sets' / f'{label}_{sn}_{variant}', flag)
                for st in stages:
                    if label != 'reference' or variant != 'nopack' or st in (0, 4):
                        jobs.append((label, sn, variant, st, None))
            if label == 'reference':
                continue
            for st in stages:
                for sid in N.STAGE_LIST[st]:
                    jobs.append((label, sn, 'nopack', st, sid))

    def one(key):
        label, sn, variant, st, sid = key
        bj = bjs[label]
        streams = bj['sets'][N.PARENT[sn]]['streams']
        skip = None
        if sid:
            sc = next((s for s in bj['scenes'] if s['id'] == sid))
            lo = streams[sid]
            skip = (lo, min((v for v in streams.values() if v > lo), default=2097152), sc['preroll'] + int(sc['window']['frames'] * N.SKIP_AT))
        out = work / 'runs' / '_'.join((str(x) for x in key if x is not None))
        extra = ('-wavwrite', str(out / 'mix.wav')) if variant == 'nopack' and sid is None else ()
        transition = None
        if st == 0 and sid is None and (variant == 'nopack'):
            lo = streams['brief_st_petersburg']
            pre = next((s['preroll'] for s in bj['scenes'] if s['id'] == 'brief_st_petersburg'))
            transition = dict(SPLIT_LO=lo, SPLIT_HI=min((v for v in streams.values() if v > lo), default=2097152), SPLIT_PRE=pre)
        r = N.run(binary, sets[label, sn, variant], sn, out, st, skip, extra=extra, transition=transition)
        if extra:
            scenes = {s['id']: s for s in bj['scenes']}
            r['coverage'] = coverage(r, out / 'mix.wav', streams, scenes)
        print('ran', out.name, flush=True)
        return (key, r)
    with ThreadPoolExecutor(a.jobs) as pool:
        runs = dict(pool.map(one, jobs))
    rows, negatives = ([], [])
    for sn in a.sets.split(','):
        machine = N.PARENT[sn]
        bj = dict(bjs['build']['sets'][machine], scenes=bjs['build']['scenes'])
        cj = bjs['control']['sets'][machine]
        for st in stages:
            for variant in ('pack', 'other_voice'):
                d = N.identical(runs['build', sn, variant, st, None], runs['control', sn, variant, st, None])
                d['fade_latch_same'] = runs['build', sn, variant, st, None]['fade'] == runs['control', sn, variant, st, None]['fade']
                rows.append(dict(set=sn, stage=st, variant=variant, facts=d, passed=d['latch_same'] and d['frames_same'] and d['ym_same'] and d['fade_latch_same']))
            for sid in [None, *N.STAGE_LIST[st]]:
                b, c = (runs['build', sn, 'nopack', st, sid], runs['control', sn, 'nopack', st, sid])
                result = protocol(b, c, bj, cj, st, runs['build', sn, 'pack', st, None])
                if sid:
                    spans = N.scene_spans(b, bj['streams'])
                    result['checks']['skip_taken'] = spans[sid][2] is not None and 0 <= spans[sid][2] - b['meta']['press'] <= 2
                else:
                    result['coverage'] = b['coverage']
                    result['checks']['full_scene_music'] = set(b['coverage']) == set(N.STAGE_LIST[st]) and all((v['passed'] for v in b['coverage'].values()))
                    negatives.extend((dict(set=sn, scene=s, failed=not v['passed']) for s, v in c['coverage'].items()))
                result['passed'] = all(result['checks'].values())
                rows.append(dict(set=sn, stage=st, variant='skip' if sid else 'nopack', scene=sid, **result))
    if hashlib.sha256(Path(binary).read_bytes()).hexdigest() != runtime['binary_sha256']:
        raise ValueError('cinematic gate runtime changed during qualification')
    transition = None
    if 'reference' in builds:
        import opening_transition_gate as OT
        transition = OT.check(runs, bjs, builds, a.sets.split(','), stages)
    report = dict(schema='striderex-cinematic-runtime/1', runtime={k: runtime[k] for k in ('binary_sha256', 'board_wait', 'source_revision')}, build_files={m: s['files'] for m, s in bjs['build']['sets'].items()}, control_files={m: s['files'] for m, s in bjs['control']['sets'].items()}, results=rows, negative_control=negatives, full_matrix=set(stages) == set(range(6)) and set(a.sets.split(',')) == set(N.PARENT), passed=all((r['passed'] for r in rows)) and len(negatives) == len(set(a.sets.split(','))) * sum((len(N.STAGE_LIST[s]) for s in stages)) and all((n['failed'] for n in negatives)))
    if transition is not None:
        report['native_transition'] = transition
        report['passed'] &= transition['passed']
    (work / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
    for row in rows:
        print('PASS' if row['passed'] else 'FAIL', row['set'], row['stage'], row['variant'], row.get('scene'), row.get('checks', {}), flush=True)
    return 0 if report['passed'] else 1

def self_test():
    from copy import deepcopy
    sid = 'brief_siberia'
    frames = [(0, 0, 256, N.ON, 0, 3), (10, 10, 256, N.HOLD, 1, 3)]
    control = dict(frames=frames, latch=[(1, N.ON, 18), (10, N.HOLD, 241), (15, 0, 7)], ym=[(15, 0.25, 40, 64)], meta={'handback': 12})
    build = deepcopy(control)
    build['latch'][0] = (1, N.ON, 36)
    build['ym'].insert(0, (2, 0.03, 8, 120))
    bj = dict(streams={sid: 256}, scenes=[dict(id=sid, preroll=0)])
    cj = dict(nopack_cues={sid: 18})
    assert protocol(build, control, bj, cj, 1)['passed']
    for mutation in ('cue', 'stop', 'extra', 'gameplay'):
        bad = deepcopy(build)
        if mutation == 'cue':
            bad['latch'][0] = (2, N.ON, 36)
        elif mutation == 'stop':
            bad['latch'].pop(1)
        elif mutation == 'extra':
            bad['latch'].insert(1, (5, N.ON, 85))
        else:
            bad['ym'][-1] = (15, 0.25, 40, 65)
        assert not protocol(bad, control, bj, cj, 1)['passed'], mutation
    c = dict(frames=[(0, 0, 256, N.ON, 0, 3), (200, 200, 256, N.HOLD, 1, 3)], latch=[(1, N.ON, 18), (100, N.ON, 255), (200, N.HOLD, 241), (202, 0, 155), (205, 0, 7)], ym=[(205, 3.4, 40, 64)], meta={'handback': 201}, oki=[(202, 128), (202, 16)])
    b = deepcopy(c)
    b['latch'][0] = (1, N.ON, 36)
    b['latch'][1] = (100, N.ON, 251)
    b['ym'].insert(0, (2, 0.03, 8, 120))
    b['fade'] = [(100, 3)]
    b['attenuation'] = [(f, min(127, 8 + (f - 100) * 2), 3) for f in range(100, 200)]
    config = dict(bj, native_fade=True)
    assert protocol(b, c, config, cj, 1)['passed']
    longc = deepcopy(c)
    longc['frames'][1] = (310, 310, 256, N.HOLD, 1, 3)
    longc['latch'] = [(1, N.ON, 18), (100, N.ON, 255), (310, N.HOLD, 241), (312, 0, 155), (315, 0, 7)]
    longc['ym'] = [(315, 5.2, 40, 64)]
    longc['meta'] = {'handback': 311}
    longc['oki'] = [(312, 128), (312, 16)]
    longb = deepcopy(longc)
    longb['latch'][0] = (1, N.ON, 36)
    longb['latch'][1] = (100, N.ON, 251)
    longb['ym'].insert(0, (2, 0.03, 8, 120))
    longb['fade'] = [(100, 6)]
    longb['attenuation'] = [(f, min(127, 8 + (f - 100) * 119 // 190), 6) for f in range(100, 312)]
    longconfig = dict(bj, native_fade={'frames': 210, 'interval': 6}, native_opening=True)
    assert protocol(longb, longc, longconfig, cj, 1)['passed']
    short = deepcopy(longb)
    short['attenuation'] = [(f, min(127, 8 + (f - 100) * 2), 6) for f in range(100, 312)]
    assert not protocol(short, longc, longconfig, cj, 1)['passed']
    for mutation in ('missing', 'laugh', 'ramp', 'interval', 'extra'):
        bad = deepcopy(b)
        if mutation == 'missing':
            bad['latch'][1] = (100, N.ON, 255)
        elif mutation == 'laugh':
            bad['oki'][0] = (202, 129)
        elif mutation == 'ramp':
            bad['attenuation'] = [(f, 8, 3) for f in range(100, 200)]
        elif mutation == 'interval':
            bad['fade'] = [(100, 4)]
        else:
            bad['latch'].insert(2, (150, N.ON, 251))
        assert not protocol(bad, c, config, cj, 1)['passed'], mutation
