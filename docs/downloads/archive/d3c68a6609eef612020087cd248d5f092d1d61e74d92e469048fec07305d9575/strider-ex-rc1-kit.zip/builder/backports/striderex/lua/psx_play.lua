-- PSX Strider play logger: scheduled inputs, periodic/listed screenshots, lives/state log.
-- env: P_PREFIX, P_END, P_INPUTS "a-b:TOK+TOK;a-b@per/duty:TOK", P_SHOTS "f,f,a-b@n", P_WATCH "addr:len,..." (physical, bytes logged on change)
local m=manager.machine;local cpu=m.devices[':maincpu'];local sp=cpu.spaces['program']
local screen=m.screens[':screen']
local prefix=assert(os.getenv('P_PREFIX'));local last=tonumber(os.getenv('P_END') or '20000')
local log=assert(io.open(prefix..'_log.tsv','w'));log:write('frame\tkind\tvalue\n')
local fields={}
for _,port in pairs(m.ioport.ports) do for name,field in pairs(port.fields) do fields[m.ioport:input_type_to_token(field.type,field.player)]=field end end
local inputs={}
for item in string.gmatch(os.getenv('P_INPUTS') or '','[^;]+') do
 local a,b,per,duty,tok=string.match(item,'^%s*(%d+)-(%d+)@(%d+)/(%d+):([%w_+]+)%s*$')
 if not a then a,b,tok=string.match(item,'^%s*(%d+)-(%d+):([%w_+]+)%s*$') end
 assert(a,'bad item '..item)
 local toks={};for t in tok:gmatch('[^+]+') do assert(fields[t],t);toks[#toks+1]=t end
 inputs[#inputs+1]={a=tonumber(a),b=tonumber(b),per=tonumber(per),duty=tonumber(duty),toks=toks}
end
local shots={};local periodic={}
for item in string.gmatch(os.getenv('P_SHOTS') or '','[^,]+') do
 local a,b,n=string.match(item,'^(%d+)-(%d+)@(%d+)$')
 if a then periodic[#periodic+1]={tonumber(a),tonumber(b),tonumber(n)} else shots[tonumber(item)]=true end
end
local watches={}
for a,l in string.gmatch(os.getenv('P_WATCH') or '','(%w+):(%d+)') do watches[#watches+1]={tonumber(a),tonumber(l),''} end
local dumps={};for d in string.gmatch(os.getenv('P_DUMPS') or '','%d+') do dumps[tonumber(d)]=true end
local pokes={};for fr,a,v in string.gmatch(os.getenv('P_POKES') or '','(%d+):(%w+)=(%w+)') do pokes[#pokes+1]={tonumber(fr),tonumber(a),tonumber(v)} end
local holds={};for a,v in string.gmatch(os.getenv('P_HOLD') or '','(%w+)=(%w+)') do holds[#holds+1]={tonumber(a),tonumber(v)} end
local hold_from=tonumber(os.getenv('P_HOLD_FROM') or '0')
local f=0;local active={}
emu.register_frame_done(function()
 f=f+1
 local want={}
 for _,r in ipairs(inputs) do if f>=r.a and f<=r.b and (not r.per or (f-r.a)%r.per<r.duty) then for _,t in ipairs(r.toks) do want[t]=true end end end
 for t in pairs(want) do fields[t]:set_value(1);active[t]=true end
 for t in pairs(active) do if not want[t] then fields[t]:clear_value();active[t]=nil end end
 for _,w in ipairs(watches) do
  local s={};for i=0,w[2]-1 do s[#s+1]=string.format('%02x',sp:read_u8(w[1]+i)) end
  s=table.concat(s);if s~=w[3] then w[3]=s;log:write(string.format('%d\tw%x\t%s\n',f,w[1],s)) end
 end
 for _,p in ipairs(pokes) do if p[1]==f then sp:write_u8(p[2],p[3]);log:write(string.format('%d\tpoke\t%x=%x\n',f,p[2],p[3])) end end
 if dumps[f] then local o=assert(io.open(string.format('%s_ram_%06d.bin',prefix,f),'wb'));local t={}
  for a=0,0x1fffff,4 do t[#t+1]=string.pack('<I4',sp:read_u32(a));if #t==4096 then o:write(table.concat(t));t={} end end;o:write(table.concat(t));o:close() end
 if f>=hold_from then for _,h in ipairs(holds) do sp:write_u8(h[1],h[2]) end end
 local shot=shots[f]
 for _,p in ipairs(periodic) do if f>=p[1] and f<=p[2] and (f-p[1])%p[3]==0 then shot=true end end
 if shot then screen:snapshot(string.format('%s_%06d.png',prefix:match('[^/]+$'),f)) end
 log:flush()
 if f>=last then log:close();m:exit() end
end)
