-- Strider EX scene player gate, run by scripts/scene_gate.py.
--
-- The player boots straight into its stream (patched reset vector). At
-- emulated frames STREX_SHOT_FIRST + k * STREX_SHOT_EVERY (k < STREX_SHOT_COUNT)
-- this saves a snapshot <prefix>_<frame>.png and logs the player's record
-- counter (RAM 0xFF8000, records played so far) to <prefix>_shots.tsv,
-- then exits after the last one.
local m=manager.machine
local sp=m.devices[':maincpu'].spaces['program']
local screen=m.screens[':screen']
local prefix=assert(os.getenv('STREX_PREFIX'))
local first=tonumber(os.getenv('STREX_SHOT_FIRST') or '10')
local every=tonumber(os.getenv('STREX_SHOT_EVERY') or '50')
local count=tonumber(os.getenv('STREX_SHOT_COUNT') or '10')
local log=assert(io.open(prefix..'_shots.tsv','w'))
log:write('frame\trecords\n')
local f, taken = 0, 0
emu.register_frame_done(function()
 f=f+1
 if f>=first and (f-first)%every==0 and taken<count then
  screen:snapshot(string.format('%s_%05d.png',prefix,f))
  log:write(string.format('%d\t%d\n',f,sp:read_u32(0xff8000)))
  log:flush()
  taken=taken+1
  if taken==count then log:close(); m:exit() end
 end
end)
