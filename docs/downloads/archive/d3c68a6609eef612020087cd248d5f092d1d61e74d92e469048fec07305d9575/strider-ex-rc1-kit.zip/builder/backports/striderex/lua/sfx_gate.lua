-- Strider EX sound gate (scripts/sfx_gate.py): play sound commands one per slot on a parked 68000 and
-- log every Z80 write to the YM2151 (0xF000/0xF001) and the OKI MSM6295 (0xF002).
--
-- Env:
--   SFX_LOG    output TSV: "time<TAB>cmd<TAB>hex" at each slot's command, "time<TAB>ym<TAB>reg<TAB>data"
--              per YM2151 data write, "time<TAB>oki<TAB>data" per OKI write, "done" at the end
--   SFX_CMDS   comma-separated hex commands, one per slot
--   SFX_SLOT   slot length in emulated seconds
--   SFX_PARK   the frame at which the 68000 is parked (default 1000)
-- At the park frame the 68000 runs a bra-self loop in work RAM (0xFF0000) with its interrupts masked,
-- so only the injected latch bytes (0x800180) reach the Z80; the script sends the stop 0xF0 then, and
-- the slots start one second later. Each command is written to the latch for one frame, then the
-- idle byte 0xFF, as the game's own queue does (0x4936: a command, then 0xFF on the next frame), so
-- the same command twice in a row plays twice. -wavwrite records the mix.
-- Every tap handle is kept in a global table: Lua GC would otherwise remove it.
local m = manager.machine
local log = assert(io.open(assert(os.getenv('SFX_LOG')), 'w'))
local slot = tonumber(assert(os.getenv('SFX_SLOT')))
local park = tonumber(os.getenv('SFX_PARK') or '1000')
local cmds = {}
for h in string.gmatch(os.getenv('SFX_CMDS') or '', '[^,]+') do cmds[#cmds + 1] = tonumber(h, 16) end
local maincpu = m.devices[':maincpu']
local sp = maincpu.spaces['program']
local z = m.devices[':audiocpu'].spaces['program']
_G.sfx_taps = {}
local function now() return m.time:as_double() end
local reg = 0
_G.sfx_taps[1] = z:install_write_tap(0xf000, 0xf002, 'sfx_snd', function(a, d, mask)
  if a == 0xf000 then reg = d & 0xff
  elseif a == 0xf001 then log:write(string.format('%.9f\tym\t%02x\t%02x\n', now(), reg, d & 0xff))
  else log:write(string.format('%.9f\toki\t%02x\n', now(), d & 0xff)) end
end)
local function latch(c) sp:write_u16(0x800180, c * 0x101) end
local frame, t0, sent, idle = 0, nil, -1, false
emu.register_frame_done(function()
  frame = frame + 1
  assert(#_G.sfx_taps == 1)
  if frame == park then
    sp:write_u16(0xff0000, 0x60fe); maincpu.state['SR'].value = 0x2700; maincpu.state['PC'].value = 0xff0000
    log:write(string.format('%.9f\tcmd\tf0\n', now())); latch(0xf0); idle = true
    t0 = now() + 1.0
    return
  end
  if idle then latch(0xff); idle = false end
  if t0 == nil or now() < t0 then return end
  local k = math.floor((now() - t0) / slot)
  if k < #cmds then
    if sent ~= k then
      sent = k
      log:write(string.format('%.9f\tcmd\t%02x\n', now(), cmds[k + 1])); log:flush()
      latch(cmds[k + 1]); idle = true
    end
  else
    log:write('done\n'); log:close(); m:exit()
  end
end)
