"""Focused native stage-clear, credits, desert mantle/landing/camera checks."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import csv
import json
from pathlib import Path
import subprocess
import sys
from PIL import Image, ImageChops
import desert_gate as G
import desert_smooth as SM
import desert_cadence as CAD
import respawn_fix as R
from boss_voice_gate import inventory, sha
import stage_clear as CLEAR
import desert_motion_fix as CAMERA
import desert_transition_fix as TRANSITION
import desert_pole_floor as POLE
import desert_climb_fix as CLIMB
import desert_slopes as FLOOR
import desert_ex as DX

def rows(path):
    with path.open() as f:
        return list(csv.DictReader(f, delimiter='\t'))

def static_check(root):
    _, old = inventory(root / 'base')
    _, new = inventory(root / 'final')
    results = []
    for m in R.SETS:
        a, b = [R.compose(f[m], R.SETS[m]) for f in (old, new)]
        banks = [bytes((f[m]['strex_p6.bin'][i ^ 1] for i in range(len(f[m]['strex_p6.bin'])))) for f in (old, new)]
        rd1, rd2 = [FLOOR.reader(im, bank) for im, bank in zip((a, b), banks)]
        for stage in range(5):
            if FLOOR.Floor(a, banks[0], FLOOR.layer_record(a, stage)).cells != FLOOR.Floor(b, banks[1], FLOOR.layer_record(b, stage)).cells:
                raise ValueError('an original stage floor changed')

        def signature(rd, table, slot, code):
            pg, ty, fp, flags, recs = table
            p = rd(pg + slot)[0]
            v = rd(ty + (p - 1) * 256 + code)[0] if p else 0
            q = rd(fp + slot)[0]
            flag = rd(flags + (q - 1) * 256 + code)[0] if q else 0
            return (v, flag, rd(recs + (v - 32) * 33, 33) if v >= 32 else None)
        t1, t2 = (DX.collision_sets(a), DX.collision_sets(b))
        count = 0
        for k in 'ABCD':
            for slot in range(32):
                if slot == DX.DZ_SLOT:
                    continue
                for code in range(256):
                    if signature(rd1, t1[k], slot, code) != signature(rd2, t2[k], slot, code):
                        raise ValueError('an original collision type, wall or flag changed')
                    count += 1
        deck = FLOOR.Floor(b, banks[1], FLOOR.layer_record(b, 5, 1))
        landings = 0
        for left in (5616, 5808, 6000, 6192, 6384):
            for x in list(range(left, left + 18)) + list(range(left + 54, left + 72)):
                if (1599, 1) not in deck.surfaces(x):
                    raise ValueError('a pole landing corridor still has a floor hole')
                if (1648, 1) not in deck.surfaces(x):
                    raise ValueError('pole cap was changed by its landing repair')
                landings += 1
        if a[10072:10174] != b[10072:10174]:
            raise ValueError('Third Moon leap code changed')
        old_text = a[14720:18016]
        start = CLEAR.DIRECTORY - 1048576 + 128
        if banks[1][start:start + len(old_text)] != old_text:
            raise ValueError('original ASCII text changed during relocation')
        results.append(dict(machine=m, stock_collision_signatures_exact=count, original_stage_floors_exact=5, repaired_landing_columns=landings, pole_caps_preserved=True, original_text_payload_exact=True, leap_code_exact=True, passed=True))
    return results

def movement_plans():
    plans = {}
    for i, (stop, jump) in enumerate(((940, 960), (1170, 1190), (1350, 1370), (1490, 1510))):
        n = jump + 300
        plans['beam' + str(i)] = (1, n, dict(STREX_INPUTS=f'450-{stop}:P1_JOYSTICK_RIGHT;{jump}-{n}:P1_JOYSTICK_UP;{jump}-{jump + 14}:P1_BUTTON2'), i)
    plans['beam_right'] = (1, 1450, dict(STREX_INPUTS='450-940:P1_JOYSTICK_RIGHT;960-976:P1_JOYSTICK_UP;960-974:P1_BUTTON2;1100-1450:P1_JOYSTICK_UP;1100-1450:P1_JOYSTICK_RIGHT'), 0)
    for i, x, hy in ((4, 2530, 1198), (5, 2448, 1294), (6, 2688, 1294)):
        cx, cy = (x - 192, hy - 144)
        warp = ';'.join((f'{f}:{x},{hy}' for f in range(1200, 1261)))
        poke = f'1200:ff0ff4={cx:04x};1200:ff0ff8={cy:04x};1200:ff0fee=0000;1230:ff0fee=0800;1230:ff10cc=0208;1230:ff10ce=0000;1230:ff10ec=0001;1230:ff1116=0001'
        plans['beam' + str(i)] = (1, 1700, dict(WARP=warp, POKEW=poke, STREX_INPUTS='450-1190:P1_JOYSTICK_RIGHT;1261-1700:P1_JOYSTICK_UP'), i)
    for depth in (1599, 1615, 1630):
        plans['pole' + str(depth)] = (3, 2500, dict(CLIMB='1', CLIMB_END='2105', WARP=f'2100:6194,{depth}', STREX_INPUTS='450-2119:P1_JOYSTICK_RIGHT;1800-2099@100/14:P1_BUTTON2;2120-2133:P1_BUTTON2;2120-2140:P1_JOYSTICK_DOWN'), None)
    plans['exit'] = (2, 4400, dict(STREX_INPUTS=G.OFFICER_KILL_INPUTS + ';3050-4400:P1_JOYSTICK_RIGHT'), None)
    for name in ('s0', 's2_turn', 'stock_stpetersburg_turn', 'stock_amazon_turn', 'stock_siberia', 'stock_aerial', 'stock_moon'):
        stage, area, n, inputs, warp = CAD.plans()[name]
        plans[name] = (area, n, dict(SM.env_of(stage, area, n, inputs, warp)), None)
    return plans

def movement_check(name, old, new):
    before = SM.read_motion(old)
    after = SM.read_motion(new)
    if len(before) != len(after):
        raise ValueError(name + ': incomplete movement trace')
    result = dict(case=name, frames=len(after), control_motion_sha256=sha((old / 'motion.tsv').read_bytes()), candidate_motion_sha256=sha((new / 'motion.tsv').read_bytes()))
    if name.startswith('beam'):
        i = 0 if name == 'beam_right' else int(name[-1])
        left, right, surface = CLIMB.BEAMS[i]
        top = [r for r in after if r['st'] == 0 and r['hy'] == surface + 32 and (left <= r['hx'] < right)]
        minimum = 1 if name == 'beam_right' else 120
        if len(top) < minimum or not any((r['st'] == 8 for r in after)) or (not any((r['st'] == 4 for r in after))):
            raise ValueError(name + ': native hang, corner climb and stable top not all observed')
        if name == 'beam_right' and (not any((r['frame'] > 1200 and r['hx'] > right for r in after))):
            raise ValueError('right-hand corner did not allow continuing across the edge')
        if any((r['st'] == 0 and r['hy'] == CLIMB.BEAMS[i][2] + 32 and (left <= r['hx'] < right) for r in before)):
            raise ValueError(name + ': old-ROM control unexpectedly climbed')
        result.update(stable_top_frames=len(top), native_hang_and_wall_transition=True, old_rom_fails=True)
        result['natural_catch'] = i < 4
    elif name.startswith('pole'):
        stable = [r for r in after if 2200 <= r['frame'] <= 2500]
        if any((r['st'] != 0 or r['hy'] != 1631 for r in stable)):
            raise ValueError(name + ': pole release did not land and remain on the deck')
        if not any((r['frame'] > 2120 and r['hy'] < 1500 for r in before)):
            raise ValueError(name + ': old-ROM fall-through not reproduced')
        result.update(stable_landing_frames=len(stable), old_rom_falls_through=True)
    elif name == 'exit':
        a = G.read_desert(old)
        b = G.read_desert(new)
        death = lambda r: next((x['frame'] for x in r if x['sec'] == 1 and x['step'] == 23))
        if death(a) != death(b):
            raise ValueError('officer fight timing changed before its death')
        load = lambda r: next((x['frame'] for x in r if x['map'] == 1))
        frame = load(b)
        r = after[frame - 1]
        if r['camx'] < 4104:
            raise ValueError('map 1 still reveals its missing left-hand strip')
        if not any((x['sec'] == 2 for x in b)):
            raise ValueError('post-boss transition did not finish')
        steps = lambda rr: [abs(y['camx'] - x['camx']) for x, y in zip(rr, rr[1:]) if 3241 <= y['frame'] < frame]
        if max(steps(after)) > 3 or max(steps(before)) < 5:
            raise ValueError('post-boss pan did not become gentler')
        result.update(antlion_dead_frame=death(b), map1_frame=frame, camera_at_map1=[r['camx'], r['camy']], old_max_pan_step=max(steps(before)), new_max_pan_step=max(steps(after)), left_seam_hidden=True)
    elif name.startswith('stock_'):
        ignored = {'sleep', 'wake', 's3line', 'objline'}
        if any((any((a[k] != b[k] for k in a if k not in ignored)) for a, b in zip(before, after))):
            raise ValueError(name + ': original stage motion changed')
        old_sprites = [r['sprites'] for r in rows(old / 'motion.tsv')]
        new_sprites = [r['sprites'] for r in rows(new / 'motion.tsv')]
        if old_sprites != new_sprites:
            raise ValueError(name + ': original stage sprite list changed')
        pictures = 0
        for pic in old.glob('s_*.png'):
            other = new / pic.name
            if not other.exists() or ImageChops.difference(Image.open(pic).convert('RGB'), Image.open(other).convert('RGB')).getbbox():
                raise ValueError(name + ': original stage picture changed')
            pictures += 1
        result.update(stock_motion_and_sprites_exact=True, stock_pictures_exact=pictures)
    else:
        lo, hi, f0 = (3340, 3400, 0) if name == 's0' else (5050, 5150, 1700)

        def metric(rr):
            q = [x for x in rr if lo < x['hx'] < hi and x['frame'] > f0 and (x['st'] == 0)]
            if len(q) < 10:
                raise ValueError(name + ': slope not traversed')
            d = [b['camy'] - a['camy'] for a, b in zip(q, q[1:])]
            return dict(frames=len(q), step_change_square=sum(((b - a) ** 2 for a, b in zip(d, d[1:]))) / (len(d) - 1), held_camera_frames=d.count(0))
        a, b = (metric(before), metric(after))
        if b['step_change_square'] >= a['step_change_square'] * 0.8:
            raise ValueError(name + ': camera cadence did not improve')
        result.update(control_cadence=a, candidate_cadence=b)
        if name == 's2_turn':
            a = [r['camy'] for r in before if 4800 < r['hx'] < 4900 and r['frame'] > 1700 and (r['st'] == 0)]
            b = [r['camy'] for r in after if 4800 < r['hx'] < 4900 and r['frame'] > 1700 and (r['st'] == 0)]
            if a != b:
                raise ValueError('the already smooth faster slope changed its camera cadence')
            result['faster_slope_camera_exact'] = True
    if not name.startswith('stock_'):
        fr = G.read(new)
        maps = G.read_desert(new)
        changes = [b['frame'] for a, b in zip(maps, maps[1:]) if a['map'] != b['map']]
        late = [int(r['frame']) for r in fr if r['mode'] == '4' and r['gtask'] == '8' and (int(r['frame']) > 650) and (r['active'] not in ('c1e5', 'c1e6', 'c1e7', 'c1e8')) and (not (name in ('beam4', 'beam5', 'beam6') and 1200 <= int(r['frame']) <= 1240)) and (not any((0 <= int(r['frame']) - f <= 8 for f in changes)))]
        if late:
            raise ValueError(name + ': gameplay missed VBlank outside map loading: ' + str(late[:5]))
    result['passed'] = True
    return result

def clear_check(old, new, stage, machine):
    ar, br = [json.loads((p / 'report.json').read_text()) for p in (old, new)]
    if not ar['completed'] or not br['completed'] or ar['clear_frame'] != br['clear_frame']:
        raise ValueError('clear did not finish at the same clock')
    a, b = (rows(old / 'frames.tsv'), rows(new / 'frames.tsv'))
    keys = ('frame', 'mode', 'stage', 'state', 'sub', 'x', 'y', 'camx', 'camy', 'active')
    if len(a) != len(b) or any((any((x[k] != y[k] for k in keys)) for x, y in zip(a, b))):
        raise ValueError('clear changed game flow, player state or coordinates')
    if (old / 'debug_log.tsv').read_bytes() != (new / 'debug_log.tsv').read_bytes():
        raise ValueError('clear sound/timing log changed')
    detail = rows(new / 'sprites.tsv')
    bonus = next((int(r['frame']) for r in b if int(r['frame']) > br['clear_frame'] and r['x'] == '80' and (r['y'] == '128')))
    if not any((r['player_object'].split(',')[9] == '1662' for r in detail if int(r['frame']) >= bonus)):
        raise ValueError('standing bonus pose missing')
    number = (1, 3, 5, 4, 6, 2)[stage]
    text = f'STAGE {number} CLEAR BONUS'
    expected = [28672 + GLYPHS[ord(c)] for c in text]
    labels = [r for r in detail if bonus + 25 <= int(r['frame']) <= bonus + 40]
    if not labels or not any(([int(v, 16) for v in r['bonus_label'].split(',')] == expected for r in labels)):
        raise ValueError('numbered bonus label missing from live SCROLL1')
    result = dict(stage=stage, number=number, frames=len(a), game_flow_positions_and_sound_exact=True, label_verified_in_vram=True, standing_pose=True)
    if stage == 4:

        def events(p):
            return {k: int(f) for f, k, v in (line.split('\t') for line in (p / 'moon_events.tsv').read_text().splitlines())}
        ea, eb = (events(old), events(new))
        if any((ea[k] != eb[k] for k in ('clear-entry', 'bonus-position', 'roll-black'))):
            raise ValueError('Third Moon phase timing changed')
        counts = dict(leap=0, credits=0)
        for p in old.glob('s_*.png'):
            f = int(p.stem[2:])
            q = new / p.name
            key = 'leap' if br['clear_frame'] <= f < ea['clear-entry'] else 'credits' if f >= ea['roll-black'] + 5 else None
            if key and q.exists():
                if ImageChops.difference(Image.open(p).convert('RGB'), Image.open(q).convert('RGB')).getbbox():
                    raise ValueError('Third Moon ' + key + ' pixels changed')
                counts[key] += 1
        if counts['leap'] < 80 or counts['credits'] < 110:
            raise ValueError('insufficient ending pixel samples')
        result.update(exact_pixel_samples=counts)
        removal = ea['roll-black']
    else:
        f = br['clear_frame']
        if any((int(r['entries']) == 0 for r in b if f + 2 <= int(r['frame']) <= f + 6)):
            raise ValueError('initial sprite dropout remains')
        black = [r for r in detail if f + 50 <= int(r['frame']) < bonus and all((int(v, 16) == 0 for v in r['palette_words'].split(',')))]
        if not black:
            raise ValueError('Hiryu was not black before bonus relocation')
        removal = next((int(r['frame']) for r in b if int(r['frame']) > f and r['mode'] == '2'))
    dark = [p for p in new.glob('s_*.png') if removal - 5 <= int(p.stem[2:]) < removal and Image.open(p).convert('RGB').getbbox() is None]
    if not dark:
        raise ValueError('bonus picture, including its text, was not black before removal')
    result['bonus_picture_black_before_removal'] = True
    result['passed'] = True
    return result

def no_pack_checks(root, work, sets, a, binary):
    """The same real St. Petersburg and Third Moon clears with pack bit off."""
    prepared = {}
    inputs = {}
    for label, folder in (('control', 'base'), ('candidate', 'final')):
        meta, files = inventory(root / folder)
        for m, setname in (('striderua', 'striderus01'), ('striderjr', 'striderjs01')):
            variant = work / 'native_variants' / (label + '_' + m)
            if not variant.exists():
                variant.mkdir(parents=True)
                d = variant / m
                d.mkdir()
                f = dict(files[m])
                p = bytearray(f['strex_p6.bin'])
                p[-2] &= 254
                f['strex_p6.bin'] = bytes(p)
                vm = dict(meta, sets={m: dict(meta['sets'][m], files={n: sha(b) for n, b in f.items()})})
                for n, data in f.items():
                    (d / n).write_bytes(data)
                (variant / 'build.json').write_text(json.dumps(vm, indent=2) + '\n')
            vm, vf = inventory(variant)
            for name, data in files[m].items():
                expected = bytearray(data)
                if name == 'strex_p6.bin':
                    expected[-2] &= 254
                if bytes(expected) != vf[m][name]:
                    raise ValueError('no-pack variant differs outside its declared option bit')
            roms = G.stage_sets(variant, setname, a.hbmame, a.rom_dir.resolve(), work / 'native_sets' / (label + '_' + m))
            prepared[label, m] = (roms, setname)
            inputs[label, m] = vm['sets'][m]['files']
    jobs = [(label, m, stage) for label in ('control', 'candidate') for m in R.SETS for stage in (0, 4)]

    def run(job):
        label, m, stage = job
        roms, setname = prepared[label, m]
        out = work / f'native_{label}_{m}_{stage}'
        if not a.reuse or not (out / 'report.json').exists():
            cmd = [sys.executable, str(Path(__file__).with_name('stage_clear_study.py')), '--mame', str(binary), '--rompath', str(roms), '--machine', setname, '--stage', str(stage), '--area', str(7 if stage == 0 else 10), '--frames', '6000', '--after-clear', str(400 if stage == 0 else 1400), '--out', str(out)]
            if stage == 4:
                cmd += ['--third-moon', '--invincible-end', '1420', '--inputs', '450-1400@6/3:P1_BUTTON1']
            p = subprocess.run(cmd, capture_output=True, text=True)
            if p.returncode:
                raise ValueError('no-pack clear failed: ' + p.stdout[-500:] + p.stderr[-1000:])
        print('no-pack', label, m, stage, 'captured', flush=True)
        return out
    with ThreadPoolExecutor(2) as ex:
        outputs = dict(zip(jobs, ex.map(run, jobs)))
    checks = []
    for m in R.SETS:
        for stage in (0, 4):
            r = clear_check(outputs['control', m, stage], outputs['candidate', m, stage], stage, m)
            checks.append(dict(kind='no_pack_clear', machine=m, **r))
            print('PASS no-pack', m, stage, flush=True)
    return (checks, {label: {m: inputs[label, m] for m in R.SETS} for label in ('control', 'candidate')})
GLYPHS = None

def main():
    global GLYPHS
    p = argparse.ArgumentParser(description=__doc__)
    for n in ('build-root', 'runtime', 'hbmame', 'rom-dir', 'workdir', 'receipt'):
        p.add_argument('--' + n, type=Path, required=True)
    p.add_argument('--reuse', action='store_true')
    p.add_argument('--only', choices=('movement', 'clear'))
    a = p.parse_args()
    root = a.build_root.resolve()
    work = a.workdir.resolve()
    work.mkdir(parents=True, exist_ok=a.reuse)
    CLEAR.audit(root / 'base', root / 'stage_clear')
    CAMERA.audit(root / 'stage_clear', root / 'camera')
    TRANSITION.audit(root / 'camera', root / 'transition')
    POLE.audit(root / 'transition', root / 'pole_floor', a.rom_dir.resolve())
    CLIMB.audit(root / 'pole_floor', root / 'final')
    static = static_check(root)
    metas = {label: inventory(root / name)[0] for label, name in (('control', 'base'), ('candidate', 'final'))}
    _, files = inventory(root / 'base')
    program = R.compose(files['striderua'], R.SETS['striderua'])
    GLYPHS = program[14470:14598]
    rt = json.loads((a.runtime / 'runtime.json').read_text())
    binary = Path(rt['binary'])
    if sha(binary.read_bytes()) != rt['binary_sha256'] or not rt['board_wait']:
        raise ValueError('matching slower-board runtime required')
    sets = {}
    for label, folder in (('control', 'base'), ('candidate', 'final')):
        for machine, name in (('striderua', 'striderus01'), ('striderjr', 'striderjs01')):
            roms = G.stage_sets(root / folder, name, a.hbmame, a.rom_dir.resolve(), work / 'sets' / (label + '_' + machine))
            have = {sha(p.read_bytes()) for p in (roms / name).iterdir() if p.is_file()}
            if not set(metas[label]['sets'][machine]['files'].values()) <= have:
                raise ValueError('prepared set lost a final member')
            sets[label, machine] = (roms, name)
    plans = movement_plans()
    jobs = []
    if a.only != 'clear':
        jobs += [('movement', label, m, name) for label in metas for m in R.SETS for name in plans]
    clearplans = {0: (7, None, '450-5800@6/3:P1_BUTTON1'), 1: (1, 1800, '1790-1850:P1_BUTTON2'), 2: (1, 1800, ''), 3: (6, 1800, ''), 4: (10, None, '450-1400@6/3:P1_BUTTON1'), 5: (5, 1800, '')}
    if a.only != 'movement':
        jobs += [('clear', label, m, str(stage)) for label in metas for m in R.SETS for stage in clearplans]

    def run(job):
        kind, label, m, name = job
        roms, setname = sets[label, m]
        out = work / (kind + '_' + label + '_' + m + '_' + name)
        if not a.reuse or not (out / 'motion.tsv' if kind == 'movement' else out / 'report.json').exists():
            if kind == 'movement':
                area, n, extra, _ = plans[name]
                env = dict(G.debug_env(5, area, n, inputs=False), MOTION='128', SHOTS=f'{n - 160}-{n}@40')
                env.update(extra)
                env['MOTION'] = '128'
                if label == 'control' and name in ('beam4', 'beam5', 'beam6'):
                    env['POKEW'] = env['POKEW'].replace('1230:ff0fee=0800', '1230:ff0fee=0400')
                G.run(binary, roms, setname, out, env, n)
            else:
                stage = int(name)
                area, force, inputs = clearplans[stage]
                cmd = [sys.executable, str(Path(__file__).with_name('stage_clear_study.py')), '--mame', str(binary), '--rompath', str(roms), '--machine', setname, '--stage', name, '--area', str(area), '--frames', '6000', '--after-clear', str(1400 if stage == 4 else 400), '--inputs', inputs, '--out', str(out)]
                if force:
                    cmd += ['--clear-at', str(force)]
                if stage == 4:
                    cmd += ['--third-moon', '--invincible-end', '1420']
                p = subprocess.run(cmd, capture_output=True, text=True)
                if p.returncode:
                    raise ValueError(str(out) + ': clear run failed: ' + p.stdout[-500:] + p.stderr[-1000:])
        print(kind, label, m, name, 'captured', flush=True)
        return out
    with ThreadPoolExecutor(2) as ex:
        outputs = dict(zip(jobs, ex.map(run, jobs)))
    results = []
    for kind in ('movement', 'clear'):
        names = plans if kind == 'movement' else {str(k): v for k, v in clearplans.items()}
        for m in R.SETS:
            for name in names:
                keys = [(kind, label, m, name) for label in metas]
                if keys[0] not in outputs:
                    continue
                old, new = [outputs[k] for k in keys]
                result = movement_check(name, old, new) if kind == 'movement' else clear_check(old, new, int(name), m)
                results.append(dict(kind=kind, machine=m, **result))
                print('PASS', kind, m, name, flush=True)
    native_inputs = {}
    if a.only != 'movement':
        native, native_inputs = no_pack_checks(root, work, sets, a, binary)
        results += native
    report = dict(schema='striderex-gameplay-followup-gate/1', passed=True, scope='focused ROM qualification', inputs={label: {m: s['files'] for m, s in meta['sets'].items()} for label, meta in metas.items()}, runtime={k: rt[k] for k in ('binary_sha256', 'source_revision', 'board_wait')}, results=results, static=static, no_pack_inputs=native_inputs, source_sha256={p.name: sha(p.read_bytes()) for p in (Path(__file__), G.LUA, Path(__file__).parents[1] / 'lua/stage_clear_study.lua', Path(__file__).parents[1] / 'lua/third_moon_study.lua')}, hardware_review_granted=False)
    a.receipt.write_text(json.dumps(report, indent=2) + '\n')
if __name__ == '__main__':
    main()
