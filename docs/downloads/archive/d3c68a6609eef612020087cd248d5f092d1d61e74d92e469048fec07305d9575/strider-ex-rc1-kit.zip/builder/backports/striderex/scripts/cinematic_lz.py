"""LZSS for Strider EX scene streams (decoded by asm/scene_player.s)."""
import sys
WINDOW, MIN_LEN, MAX_LEN = (4096, 3, 18)
TAKE_MIN = 5

def encode(data, chain=64, take_min=TAKE_MIN):
    out = bytearray()
    heads, prev = ({}, [-1] * len(data))
    i, n = (0, len(data))
    flags_at, bit = (None, 8)
    while i < n:
        best = off = 0
        if i + MIN_LEN <= n:
            j, tries = (heads.get(data[i:i + 3], -1), 0)
            while j >= 0 and i - j <= WINDOW and (tries < chain):
                ln = 0
                while ln < MAX_LEN and i + ln < n and (data[j + ln] == data[i + ln]):
                    ln += 1
                if ln > best:
                    best, off = (ln, i - j)
                j, tries = (prev[j], tries + 1)
        if bit == 8:
            flags_at, bit = (len(out), 0)
            out.append(0)
        if best >= max(MIN_LEN, take_min):
            v = off - 1 << 4 | best - MIN_LEN
            out += bytes([v >> 8, v & 255])
            step = best
        else:
            out[flags_at] |= 1 << bit
            out.append(data[i])
            step = 1
        bit += 1
        for t in range(i, min(i + step, n - 2)):
            k = data[t:t + 3]
            prev[t], heads[k] = (heads.get(k, -1), t)
        i += step
    return bytes(out)

def decode(comp, size):
    out = bytearray()
    i = 0
    while len(out) < size:
        flags = comp[i]
        i += 1
        for bit in range(8):
            if len(out) >= size:
                break
            if flags >> bit & 1:
                out.append(comp[i])
                i += 1
            else:
                v = comp[i] << 8 | comp[i + 1]
                i += 2
                src = len(out) - ((v >> 4) + 1)
                if src < 0:
                    raise ValueError('match before the start')
                for k in range((v & 15) + MIN_LEN):
                    out.append(out[src + k])
    return bytes(out)

def self_test():
    import random
    rng = random.Random(7)
    cases = [b'', b'a', b'abcabcabcabcabcabcabcabc', bytes(5000), bytes((rng.randrange(4) for _ in range(20000))), bytes((rng.randrange(256) for _ in range(3000))) * 3]
    for c in cases:
        assert decode(encode(c), len(c)) == c
    assert len(encode(bytes(5000))) < 700
    print('cinematic_lz self-test passed')
    return 0
if __name__ == '__main__':
    sys.exit(self_test())
