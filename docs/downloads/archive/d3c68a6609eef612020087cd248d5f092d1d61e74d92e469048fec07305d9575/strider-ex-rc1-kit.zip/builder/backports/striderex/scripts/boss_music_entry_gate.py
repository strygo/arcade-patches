"""Trace every boss entrance and qualify deferred desert fight music."""
import argparse
from concurrent.futures import ThreadPoolExecutor
from copy import deepcopy
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import zipfile
from PIL import Image, ImageChops
import boss_music_entry as M
import boss_scene as S
import boss_scene_gate as B
import boss_scene_binary as BB
import desert_gate as G
import pack_model as PMODEL
from boss_voice_gate import inventory, sha
ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / 'release'))
import private_mister as PM

def compare(old, new, sid, pack, model, retry=False):
    a, n = old
    b, _ = new
    ea, eb = [B.entries_of(x, 'entry') for x in (a, b)]
    xa, xb = [B.entries_of(x, 'exit') for x in (a, b)]
    if retry == 'seen':
        if ea or eb:
            raise ValueError('already-seen Siberia fixture played a portrait')
        sa, sb = [B.sound_writes(log) for log in (a, b)]
        if sa != sb or not any((v == 8 for f, v, on in sb)):
            raise ValueError('already-seen Siberia lost native music')
        keep = ('f', 'on', 'n', 'active', 'px', 'py', 'cx', 'cy', 'music', 'counter', 'lives')
        if any((any((x[k] != y[k] for k in keep)) for x, y in zip(a['frames'], b['frames']))):
            raise ValueError('already-seen Siberia gameplay changed')
        pictures = 0
        for p in b['dir'].glob('g_*.png'):
            if ImageChops.difference(Image.open(p).convert('RGB'), Image.open(a['dir'] / p.name).convert('RGB')).getbbox():
                raise ValueError('already-seen Siberia picture changed')
            pictures += 1
        return dict(passed=True, already_seen_music_exact=True, pictures_exact=pictures, music_cues=[(f, v) for f, v, on in sb if v == 8])
    if len(ea) != 1 or ea != eb or len(xa) != 1 or (xa != xb):
        raise ValueError('encounter boundary changed')
    e, x = (ea[0], xa[0])
    if B.freeze_diff(b['dumps']['entry'], b['dumps']['exit']):
        raise ValueError('scene stopped freezing the game')
    va, vb = [B.scene_vblanks(log) for log in (a, b)]
    if va != vb or any((v['n'] != v['prep'] for v in vb)):
        raise ValueError('scene pictures, voice clock or preparation changed')
    for ar, br in zip(a['frames'], b['frames']):
        if any((ar[k] != br[k] for k in ('f', 'on', 'n', 'active', 'px', 'py', 'cx', 'cy', 'music', 'counter', 'lives'))):
            raise ValueError('gameplay, scene or retry clock changed')
    sa, sb = [[(f, v, on) for f, v, on in B.sound_writes(log) if v != 255] for log in (a, b)]
    removed = []
    cue = {'desert_officer': 4, 'desert_commander': 5, 'sib_solo': 8}.get(sid)
    if cue is not None:
        removed = [r for r in sa if r[1] == cue and r[0] < e]
        if len(removed) != 1:
            raise ValueError('early desert boss cue not reproduced')
        if [r for r in sa if r not in removed] != sb:
            raise ValueError('sound changed beyond the early fight cue')
        start = next((f for f, v, on in sb if v == cue))
        if start <= x:
            raise ValueError('boss tune still starts before gameplay returns')
        if not any((f < x and v == cue for f, v, on in sa)):
            raise ValueError('old cue control failed')
    elif sa != sb:
        raise ValueError('an original-stage boss sound changed')
    black = next((v['frame'] for v in vb if v['pl'] >> 8 & 15 == 3))
    during = [r for r in sb if r[2]]
    if (e + 2, 252 if pack else 241, True) not in during:
        raise ValueError('requested native/CPS+ fade path was not exercised')
    voices = [(f, v) for f, v, on in during if 184 <= v <= 199]
    if any((f <= black for f, v in voices)):
        raise ValueError('dialogue voice starts before black')
    facts = dict(entry=e, exit=x, black_frame=black, removed_early_cues=removed, voice_cues=voices, scene_vblanks_exact=len(vb), gameplay_and_retry_clocks_exact=True)
    facts['near_entry_music_cues'] = [(f, v) for f, v, on in sb if e - 12 <= f <= e + 1 and (v < 37 or v in (121, 122))]
    if cue is not None and pack:
        previous = {4: 121, 5: 122, 8: 7}[cue]

        def events(sound):
            return model.run([(e - 120, previous)] + [(f, v) for f, v, on in sound if f >= e - 30])
        (old_events, old_segments), (new_events, _) = [events(s) for s in (sa, sb)]
        old_starts = [r for r in old_events if r[1] == cue and r[-1] == 'start' and (r[0] < black)]
        new_starts = [r for r in new_events if r[1] == cue and r[-1] == 'start']
        if len(old_starts) != 1 or not new_starts or new_starts[0][0] <= x:
            raise ValueError('CPS+ early-start control failed')
        facts['cpsplus_old_start_before_black'] = old_starts[0][0]
        facts['cpsplus_new_first_start'] = new_starts[0][0]
        stop = next((f for f, track, start, fade in old_segments if track is None and f > old_starts[0][0]))
        facts['old_pack_track_active_frames'] = stop - old_starts[0][0]
    if retry:
        life = next((r['lives'] for r in b['frames'] if r['f'] == e))
        death = next((r['f'] for r in b['frames'] if r['f'] > x and r['lives'] < life))
        restarts = [f for f, v, on in sb if v == cue and f > death]
        if not restarts:
            raise ValueError('boss retry lost its music')
        facts.update(death_frame=death, retry_music_frames=restarts, only_one_scene_after_death=True)
    pictures = 0
    for p in b['dir'].glob('g_*.png'):
        q = a['dir'] / p.name
        if not q.exists() or ImageChops.difference(Image.open(p).convert('RGB'), Image.open(q).convert('RGB')).getbbox():
            raise ValueError('actual boss transition picture changed')
        pictures += 1
    if pictures < 6:
        raise ValueError('missing visual samples')
    facts.update(pictures_exact=pictures, passed=True, traces={label: {name: sha((log['dir'] / name).read_bytes()) for name in ('g_frames.tsv', 'g_regs.tsv', 'g_oki.tsv')} for label, log in (('control', a), ('candidate', b))})
    return facts

def main():
    p = argparse.ArgumentParser(description=__doc__)
    for name in ('control', 'build', 'kit', 'runtime', 'hbmame', 'rom-dir', 'vasm', 'workdir', 'receipt'):
        p.add_argument('--' + name, type=Path, required=True)
    p.add_argument('--reuse', action='store_true')
    a = p.parse_args()
    M.audit(a.control, a.build)
    work = a.workdir.resolve()
    work.mkdir(parents=True, exist_ok=a.reuse)
    metas = {}
    files = {}
    for label, path in (('control', a.control), ('candidate', a.build)):
        metas[label], files[label] = inventory(path)
    kit = PM.verify(a.kit)
    if kit['test_id'] != '261026-03':
        raise ValueError('need deployed Kit ac as the declared baseline')
    pack = work / 'pack.cpk'
    with PM.qualified_view(a.kit) as source:
        producer = json.loads((source / 'producer.json').read_text())
        if producer['build_files'] != {m: s['files'] for m, s in metas['control']['sets'].items()}:
            raise ValueError('control is not exact Kit ac')
        archives = [source / name for name in producer['archives'] if name.endswith('/strider_ex.zip')]
        if len(archives) != 1:
            raise ValueError('declared pack archive ambiguous')
        with zipfile.ZipFile(archives[0]) as z:
            names = [n for n in z.namelist() if n.endswith('.cpk')]
            if len(names) != 1:
                raise ValueError('pack dependency ambiguous')
            data = z.read(names[0])
            pack.write_bytes(data)
    model = PMODEL.Model(pack)
    rt = json.loads((a.runtime / 'runtime.json').read_text())
    binary = Path(rt['binary'])
    if sha(binary.read_bytes()) != rt['binary_sha256'] or not rt['board_wait']:
        raise ValueError('matching conservative runtime required')
    prepared = {}
    variant_files = {}
    for label in metas:
        for m, setname in (('striderua', 'striderus01'), ('striderjr', 'striderjs01')):
            for enabled in (False, True):
                key = f'{label}_{m}_{enabled}'
                variant = work / 'variants' / key
                f = dict(files[label][m])
                p6 = bytearray(f['strex_p6.bin'])
                p6[-2] = p6[-2] & ~7 | int(enabled)
                f['strex_p6.bin'] = bytes(p6)
                if not variant.exists():
                    d = variant / m
                    d.mkdir(parents=True)
                    for n, data in f.items():
                        (d / n).write_bytes(data)
                    vm = deepcopy(metas[label])
                    vm['sets'] = {m: dict(vm['sets'][m], files={n: sha(b) for n, b in f.items()})}
                    (variant / 'build.json').write_text(json.dumps(vm) + '\n')
                if inventory(variant)[1][m] != f:
                    raise ValueError('variant changed outside audio option bits')
                roms = G.stage_sets(variant, setname, a.hbmame, a.rom_dir.resolve(), work / 'sets' / key)
                have = {sha(q.read_bytes()) for q in (roms / setname).iterdir() if q.is_file()}
                if not {sha(b) for b in f.values()} <= have:
                    raise ValueError('staged ROM identity differs')
                prepared[label, m, enabled] = (roms, setname)
                variant_files[key] = {n: sha(b) for n, b in f.items()}
    prior = json.loads((Path(__file__).parents[1] / 'manifests/qualification/boss_english_routing.json').read_text())
    manifest = S.manifest()
    scenarios = {s['id']: s['gate'] for s in manifest['scenes']}
    plans = [(m, enabled, sid, False) for m in files['control'] for enabled in (False, True) for sid in BB.IDS]
    plans += [(m, enabled, 'desert_officer', True) for m in files['control'] for enabled in (False, True)]
    plans += [(m, enabled, 'sib_solo', 'seen') for m in files['control'] for enabled in (False, True)]
    outputs = {}
    entries = {}

    def run(job, label):
        m, enabled, sid, retry = job
        sc = manifest['gate_once'] if retry is True else scenarios[sid]
        bank = files[label][m]['strex_p6.bin']
        bank = bytes((bank[i ^ 1] for i in range(len(bank))))
        record = next((r for r in BB.scenes(bank) if r['id'] == sid))
        n = 0 if retry == 'seen' else record['total']
        frames = sc['frames'] + n + 300
        hint = entries.get(job, next((r['entry'] for r in prior['results'] if r['machine'] == m and r['pack'] == enabled and (r['scene'] == sid) and (not r['override']))))

        def capture(e, folder):
            shots = ','.join(map(str, (620, 636, 650, 750, 900, 1100))) if retry == 'seen' else ','.join((str(e + k) for k in (-1, 25, 41, 52, 72, n, n + 15)))
            if not a.reuse or not (folder / 'g_frames.tsv').exists():
                writes = B.research_writes(sc) + ([(590, 'fff9e8', '0400')] if retry == 'seen' else [])
                B.run(binary, *prepared[label, m, enabled], folder, sc, frames, B.shift_inputs(sc['inputs'], n, e), shift=(e, n), holds=B.holds_env(writes, (e, n)), shots=shots, audio=True)
            return B.load(folder, frames)
        folder = work / 'runs' / f'{label}_{m}_{enabled}_{sid}_{retry}'
        log = capture(hint, folder)
        actual = B.entries_of(log, 'entry')
        if retry == 'seen':
            if actual:
                raise ValueError('already-seen fixture still showed dialogue')
            return (log, frames)
        if len(actual) != 1:
            raise ValueError('need one real boss scene')
        if hint != actual[0]:
            log = capture(actual[0], folder / 'aligned')
        print('Captured', label, m, enabled, sid, 'retry' if retry else '', flush=True)
        return (log, frames)
    for label in ('control', 'candidate'):
        with ThreadPoolExecutor(2) as ex:
            captured = list(ex.map(lambda job: run(job, label), plans))
        for job, result in zip(plans, captured):
            outputs[label, job] = result
            if label == 'control' and job[-1] != 'seen':
                entries[job] = B.entries_of(result[0], 'entry')[0]
    checks = []
    for job in plans:
        m, enabled, sid, retry = job
        result = compare(outputs['control', job], outputs['candidate', job], sid, enabled, model, retry)
        checks.append(dict(machine=m, pack=enabled, scene=sid, retry=retry, **result))
        print('PASS', m, enabled, sid, retry, flush=True)
    with tempfile.TemporaryDirectory(prefix='fresh-', dir=work) as temporary:
        fresh = Path(temporary) / 'build'
        subprocess.run([sys.executable, str(Path(M.__file__)), '--build', str(a.control), '--vasm', str(a.vasm), '--out', str(fresh)], check=True)
        if inventory(fresh) != inventory(a.build):
            raise ValueError('fresh output differs')
    rejected = []
    with tempfile.TemporaryDirectory(prefix='damage-', dir=work) as temporary:
        for machine in files['candidate']:
            for kind in ('program', 'hook', 'helper'):
                root = Path(temporary) / (machine + '_' + kind)
                root.mkdir()
                meta = deepcopy(metas['candidate'])
                name = M.R.SETS[machine][0][0] if kind == 'program' else 'strex_p6.bin'
                spec = meta['sets'][machine]['boss_music_entry']
                offset = 256 if kind == 'program' else (spec['address'] if kind == 'hook' else M.BASE) - 1048576 ^ 1
                for m, fs in files['candidate'].items():
                    dest = root / m
                    dest.mkdir()
                    for n, data in fs.items():
                        if m == machine and n == name:
                            damaged = bytearray(data)
                            damaged[offset] ^= 1
                            (dest / n).write_bytes(damaged)
                            meta['sets'][m]['files'][n] = sha(damaged)
                        else:
                            (dest / n).symlink_to((a.build / m / n).resolve())
                (root / 'build.json').write_text(json.dumps(meta) + '\n')
                try:
                    M.audit(a.control, root)
                except ValueError:
                    rejected.append(dict(machine=machine, kind=kind, inventory_rehashed=True, rejected=True))
                else:
                    raise ValueError('internally rehashed music damage accepted')
    source = (Path(__file__).parents[1] / 'asm/desert.s').read_text()
    fragment = source[source.index('dz_music:\n'):source.index('; Map record DZ_MAP_I')]
    for scenes in (False, True):
        harness = work / f'linked-{scenes}.s'
        binary_out = harness.with_suffix('.bin')
        harness.write_text(('BOSS_SCENE equ 1\n' if scenes else '') + 'DZ_SEC equ $FFF932\nDZ_MUS equ $FFF936\nBS_DONE equ $FFF9E8\nDZ_SOUND equ $496E\ndz_sec_music equ $1F5F00\n org $1F5B00\n' + fragment)
        subprocess.run([str(a.vasm), '-Fbin', '-m68000', '-quiet', '-I', str(M.ASM.parent), '-o', str(binary_out), str(harness)], check=True)
        body = binary_out.read_bytes()
        if not scenes and body.count(M.PREFIX) != 1:
            raise ValueError('non-scene linked music path changed')
    result = dict(schema='striderex-boss-music-entry-gate/1', passed=True, baseline_test_id=kit['test_id'], baseline_manifest_sha256=sha((a.kit / 'private-mister.json').read_bytes()), pack_sha256=sha(pack.read_bytes()), inputs={label: {m: s['files'] for m, s in meta['sets'].items()} for label, meta in metas.items()}, runtime={k: rt[k] for k in ('binary_sha256', 'source_revision', 'board_wait')}, variant_files=variant_files, checks=checks, fresh_empty_output_files_and_metadata_exact=True, linked_source_boss_scene_modes_assemble=[False, True], rehashed_damage_controls=rejected, assembler_sha256=sha(a.vasm.read_bytes()), source_sha256={str(q.relative_to(Path(__file__).parents[1])): sha(q.read_bytes()) for q in (Path(__file__), Path(M.__file__), M.ASM, M.SIB_ASM, Path(__file__).parents[1] / 'asm/desert.s', B.LUA)}, hardware_review_granted=False)
    a.receipt.parent.mkdir(parents=True, exist_ok=True)
    a.receipt.write_text(json.dumps(result, indent=2) + '\n')
    print('All 40 regional audio/entrance/retry comparisons PASS; fresh output exact')
if __name__ == '__main__':
    main()
