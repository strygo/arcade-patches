"""Reassemble native opening timing from a verified or fresh asset build."""
import argparse
from copy import deepcopy
import json
from pathlib import Path
import subprocess
import sys
import build_ex as BX
import cinematic_followup as CF
from cinematic_transition import logo_trim, FADE_LEAD, FADE_INTERVAL
from reconstruct_private_build import decode_scene

def main():
    if sys.argv[1:] == ['--self-test']:
        return CF.self_test()
    p = argparse.ArgumentParser(description=__doc__)
    for name in ('build', 'vasm', 'out'):
        p.add_argument('--' + name, type=Path, required=True)
    a = p.parse_args()
    base = json.loads((a.build / 'build.json').read_text())
    first = next(iter(base['sets']))
    raw = (a.build / first / 'strex_p6.bin').read_bytes()
    raw = bytes((raw[i ^ 1] for i in range(len(raw))))
    stream, _ = decode_scene(raw[base['sets'][first]['streams']['prologue'] - 1048576:])
    trim = logo_trim(stream)
    result = deepcopy(base)
    out = a.out.resolve()
    out.mkdir(parents=True, exist_ok=False)
    work = out / 'work'
    work.mkdir()
    header = (BX.ASM / 'ex_bank.s').read_text().split('        org     $100000')
    if len(header) != 2:
        raise ValueError('bank header boundary changed')
    (work / 'native_fade_frames.inc').write_text(' dc.w ' + ','.join(map(str, BX.native_fade_frames(base['scenes']))) + '\nOPENING_CUT_RECORD equ ' + str(trim['cut_record']) + '\n')
    wrapper = work / 'fade.s'
    wrapper.write_text(header[0] + '\n org $1FF000\n include "native_fade.s"\n')
    binary = work / 'fade.bin'
    subprocess.run([str(a.vasm.resolve()), '-Fbin', '-m68000', '-quiet', '-DREGION_EN=1', '-I', str(BX.ASM), '-I', str(work), '-o', str(binary), str(wrapper)], check=True)
    code = binary.read_bytes()
    start, size, digest = CF.NATIVE_FLOW
    if len(code) != size or CF.sha(code) != digest:
        raise ValueError('assembled fade differs from the portable qualified allocation')
    for machine, spec in base['sets'].items():
        target = out / machine
        target.mkdir()
        for name, expected in spec['files'].items():
            data = (a.build / machine / name).read_bytes()
            if CF.sha(data) != expected:
                raise ValueError('full asset build member changed: ' + name)
            if name == 'strex_p6.bin':
                raw = bytearray((data[i ^ 1] for i in range(len(data))))
                call = CF.NATIVE_FADE_CALL[machine] - 1048576
                if raw[call:call + 6] not in (bytes.fromhex('527900fff918'), bytes.fromhex('4eb9001ff000')):
                    raise ValueError('unrecognized fade entry site')
                old = CF.sha(raw[start:start + size])
                legacy = CF.sha(raw[start:start + CF.NATIVE_FADE[1]]) == CF.NATIVE_FADE[2] and raw[start + CF.NATIVE_FADE[1]:start + size] == b'\xff' * (size - CF.NATIVE_FADE[1])
                if old not in (CF.sha(b'\xff' * size), digest) and (not legacy):
                    raise ValueError('unrecognized native fade allocation')
                raw[call:call + 6] = bytes.fromhex('4eb9001ff000')
                cue = CF.NATIVE_CUE_CALL[machine] - 1048576
                if raw[cue:cue + 12] not in (CF.NATIVE_CUE_ORIGINAL, CF.NATIVE_CUE_PATCH):
                    raise ValueError('unrecognized native cue entry')
                raw[cue:cue + 12] = CF.NATIVE_CUE_PATCH
                raw[start:start + size] = code
                changed = bytes((raw[i ^ 1] for i in range(len(raw))))
                allowed = {i ^ 1 for i in range(call, call + 6)} | {i ^ 1 for i in range(start, start + size)} | {i ^ 1 for i in range(cue, cue + 12)}
                if any((x != y and i not in allowed for i, (x, y) in enumerate(zip(data, changed)))):
                    raise ValueError('change outside native fade allocation')
                data = changed
                result['sets'][machine]['native_fade'] = dict(address=2093056, end=2093056 + size, call=call + 1048576, frames=FADE_LEAD, interval=FADE_INTERVAL)
                result['sets'][machine]['native_opening'] = trim
                result['sets'][machine]['ex_bank_bytes_used'] = max(spec['ex_bank_bytes_used'], start + size)
            (target / name).write_bytes(data)
            result['sets'][machine]['files'][name] = CF.sha(data)
    (out / 'build.json').write_text(json.dumps(result, indent=2) + '\n')
    receipt = dict(schema='striderex-native-fade-build/1', passed=True, command='native_fade.py --build <verified-or-fresh-asset-build> --vasm <pinned-assembler> --out <fresh-build>', input_files={m: s['files'] for m, s in base['sets'].items()}, build_files={m: s['files'] for m, s in result['sets'].items()}, helper_sha256=CF.sha(code), helper_size=len(code), source_sha256=CF.sha((BX.ASM / 'native_fade.s').read_bytes()), script_sha256=CF.sha(Path(__file__).read_bytes()), assembler_sha256=CF.sha(a.vasm.read_bytes()), opening=trim, unchanged_outside_native_opening=True)
    (out / 'native-fade-build.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print('PASS: rebuilt native fade from source; every other ROM byte preserved')
if __name__ == '__main__':
    main()
