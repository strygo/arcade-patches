"""Recover a verified private kit's build members and stream metadata."""
import argparse
import json
from pathlib import Path
import struct
import subprocess
import sys
import zipfile
import cinematic_timing as T
ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / 'release'))
import private_mister as PM

def decode_scene(comp):
    data = bytearray()
    pos = end = 0
    records = []

    def consume():
        nonlocal pos, end
        while len(data) >= end + 2:
            count = int.from_bytes(data[end:end + 2], 'big')
            if count == 65535:
                return (bytes(data[:end + 2]), records)
            if count < 2 or count > 4096 or count & 1:
                raise ValueError('invalid scene record')
            if len(data) < end + 2 + count:
                break
            body = bytes(data[end + 2:end + 2 + count])
            T.ops(body)
            records.append(body)
            end += 2 + count
        return None
    while pos < len(comp) and len(data) < 4000000:
        flags = comp[pos]
        pos += 1
        for bit in range(8):
            if flags >> bit & 1:
                if pos >= len(comp):
                    raise ValueError('truncated literal')
                data.append(comp[pos])
                pos += 1
            else:
                if pos + 2 > len(comp):
                    raise ValueError('truncated match')
                value = int.from_bytes(comp[pos:pos + 2], 'big')
                pos += 2
                distance = (value >> 4) + 1
                if distance > len(data):
                    raise ValueError('invalid scene match')
                for _ in range((value & 15) + 3):
                    data.append(data[-distance])
            result = consume()
            if result:
                return result
    raise ValueError('scene has no bounded terminator')

def reconstruct(kit, out):
    subprocess.run([sys.executable, '-B', str(kit / 'verify_kit.py'), '--root', str(kit)], check=True)
    out.mkdir(parents=True, exist_ok=False)
    with PM.qualified_view(kit) as view:
        producer = json.loads((view / 'producer.json').read_text())
        proof = producer['cinematic_music']['proof']
        result = dict(test_ending={'inherited_from_verified_kit': proof['baseline_test_id']}, sets={}, scenes=[])
        for machine, inventory in producer['build_files'].items():
            region = 'us' if machine == 'striderua' else 'jp'
            with zipfile.ZipFile(view / f'games/mame/striderex_{region}.zip') as z:
                files = {name: z.read(name) for name in inventory}
            target = out / machine
            target.mkdir()
            for name, data in files.items():
                if PM.sha(data) != inventory[name]:
                    raise ValueError('kit member identity changed')
                (target / name).write_bytes(data)
            raw = bytes((files['strex_p6.bin'][i ^ 1] for i in range(1048576)))
            spec = proof['regions'][machine]
            order = spec['scene_order']
            at = spec['table_offset']
            table = at - 8 * len(order)
            entries = [struct.unpack_from('>IHH', raw, table + 8 * i) for i in range(len(order))]
            scenes = []
            for sid, (start, ja, en) in zip(order, entries):
                stream, records = decode_scene(raw[start - 1048576:])
                cues = [i for i, body in enumerate(records) if any((op == 14 for op, slot, q in T.ops(body)))]
                if len(cues) != 1:
                    raise ValueError('scene has no unique cue record')
                last = max((i for i, body in enumerate(records) if T.ops(body)))
                scenes.append(dict(id=sid, preroll=cues[0], window={'frames': len(records) - cues[0]}, continues={'brief_st_petersburg': 'prologue', 'welcome_meio': 'flight'}.get(sid), stream_bytes=len(stream), stream_sha256=PM.sha(stream), last_nonempty_record=last + 1))
            if result['scenes'] and result['scenes'] != scenes:
                raise ValueError('regional scenes differ')
            result['scenes'] = scenes
            if region == 'us':
                from cinematic_transition import logo_trim
                prologue, _ = decode_scene(raw[entries[order.index('prologue')][0] - 1048576:])
                result['prologue_trim_contract'] = logo_trim(prologue)
            result['sets'][machine] = dict(files=inventory, region_en=int(region == 'us'), streams={sid: e[0] for sid, e in zip(order, entries)}, cues={sid: list(e[1:]) for sid, e in zip(order, entries)}, nopack_cues={sid: raw[at + i] for i, sid in enumerate(order)}, nopack_cues_at=hex(at + 1048576), ex_bank_bytes_used=spec.get('native_fade', {}).get('end', 1048576) - 1048576, native_fade=spec.get('native_fade'))
            if spec.get('native_opening'):
                result['sets'][machine]['native_opening'] = spec['native_opening']
            for field in ('earth_palette', 'earth_tile', 'native_reading', 'earth_tip'):
                if spec.get(field):
                    result['sets'][machine][field] = spec[field]
            if spec.get('native_reading'):
                result['sets'][machine]['ex_bank_bytes_used'] = spec['native_reading']['end'] - 1048576
            if proof['schema'] in ('striderex-cinematic-inheritance/5', 'striderex-cinematic-inheritance/6'):
                result['sets'][machine].setdefault('earth_palette', {'inherited_by_exact_reversal': True})
            if producer.get('boss_followup'):
                for field in ('boss_voice', 'desert_grip', 'boss_mouth', 'postgame_hold', 'arcade_copyedit'):
                    result['sets'][machine][field] = producer['boss_followup']['build_sets'][machine][field]
            if producer.get('desert_followup'):
                for field in ('desert_grip', 'commander_reading', 'pole_edges', 'hiryu_pixels', 'wall_edge'):
                    result['sets'][machine][field] = producer['desert_followup']['build_sets'][machine][field]
    result['reconstructed_from_verified_export'] = json.loads((kit / 'private-mister.json').read_text())['test_id']
    (out / 'build.json').write_text(json.dumps(result, indent=2) + '\n')
    print('Recovered', len(result['scenes']), 'scene streams from', result['reconstructed_from_verified_export'])
    return result

def main():
    if sys.argv[1:] == ['--self-test']:
        import cinematic_lz as LZ
        raw = bytes.fromhex('0004000e0000ffff')
        assert decode_scene(LZ.encode(raw)) == (raw, [bytes.fromhex('000e0000')])
        for bad in (b'\x00\x00\x00', b'\x01', LZ.encode(bytes.fromhex('000100ffff'))):
            try:
                decode_scene(bad)
            except ValueError:
                pass
            else:
                raise AssertionError('invalid scene accepted')
        print('scene reconstruction self-test PASS')
        return
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--kit', type=Path, required=True)
    p.add_argument('--out', type=Path, required=True)
    a = p.parse_args()
    reconstruct(a.kit.resolve(), a.out.resolve())
if __name__ == '__main__':
    main()
