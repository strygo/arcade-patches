"""D14 gate: the hidden stage select."""
import argparse
import json
import os
import struct
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import numpy as np
sys.path.insert(0, str(Path(__file__).resolve().parent))
import ex_gate as EG
import stage_openings as SO
LUA = '\nlocal m=manager.machine\nlocal sp=m.devices[\':maincpu\'].spaces[\'program\']\nlocal scr=m.screens[\':screen\']\nlocal fields={}\nfor _,port in pairs(m.ioport.ports) do for name,field in pairs(port.fields) do\n fields[m.ioport:input_type_to_token(field.type,field.player)]=field end end\nlocal out=os.getenv(\'OUT\')\nlocal plan={}\nfor a,b,tok in string.gmatch(os.getenv(\'PLAN\'),\'(%d+)-(%d+):([%w_]+)\') do plan[#plan+1]={tonumber(a),tonumber(b),tok} end\nlocal shots={} for v in string.gmatch(os.getenv(\'SHOTS\'),\'%d+\') do shots[tonumber(v)]=true end\nlocal last=tonumber(os.getenv(\'END\'))\nlocal layer_and=tonumber(os.getenv(\'LAYER_AND\') or \'ffff\',16)\nlocal lg=assert(io.open(out..\'/log.tsv\',\'w\'))\nlocal snd=assert(io.open(out..\'/sound.tsv\',\'w\'))\nlocal regs=assert(io.open(out..\'/regs.tsv\',\'w\'))\nlocal pal=assert(io.open(out..\'/pal.bin\',\'wb\'))\nlocal f=0\n-- the ENDING test entry\'s runs: screenshots (ev_<cue>_<offset>.png) and graphics RAM dumps (ed_<cue>_<offset>.bin:\n-- 0x908000-0x90BFFF, then the palette 0x914000-0x9157FF) at frames after a sound command\'s first send\n-- (EVSHOTS / EVDUMPS "cue:offset,offset;..."), the game mode writes with their PC (modes.tsv), and at Game\n-- Over\'s first send (0x0E) the score and the ten ranking entries (0xFF89AA: pointers to their scores)\nlocal function events(s)\n local t={}\n for cue,list in string.gmatch(s or \'\',\'(%x+):([%d,]+)\') do\n  local o={} for v in string.gmatch(list,\'%d+\') do o[tonumber(v)]=true end\n  t[tonumber(cue,16)]=o end\n return t end\nlocal evshots,evdumps=events(os.getenv(\'EVSHOTS\')),events(os.getenv(\'EVDUMPS\'))\nlocal title_addr=tonumber(os.getenv(\'TITLE_ADDR\') or \'0\',16)\nlocal ev={}\nlocal cpu=m.devices[\':maincpu\']\nlocal ranked_end=false\nlocal function rank_line(tag)   -- the score, then the ten entries (score, name) of the ranking table\n local rk=assert(io.open(out..\'/rank.tsv\',\'a\'))\n rk:write(string.format(\'%s\\t%d\\t%08x\',tag,f,sp:read_u32(0xff0cb6)))\n for i=0,9 do local p=sp:read_u32(0xff89aa+4*i)&0xffffff\n  rk:write(string.format(\'\\t%08x:%08x\',sp:read_u32(p),sp:read_u32(p+4))) end\n rk:write(\'\\n\') rk:close()\nend\n_G.ss_tap=sp:install_write_tap(0x800180,0x800181,\'snd\',function(off,data,mask)\n local v=data&0xff\n if v~=0xff then\n  snd:write(string.format(\'%d\\t%02x\\n\',f,v))\n  if not ev[v] then\n   ev[v]=f\n   if v==0x0e then rank_line(\'game_over\') end\n  end\n end end)\nlocal modes=assert(io.open(out..\'/modes.tsv\',\'w\'))\n_G.ss_mode=sp:install_write_tap(0xff0c12,0xff0c13,\'mode\',function(off,data,mask)\n modes:write(string.format(\'%d\\t%04x\\t%06x\\n\',f,data&0xffff,cpu.state[\'CURPC\'].value)) end)\n-- the CPS-A/B register writes, with the time to the next VBlank (ns: the gate turns it into lines), and at\n-- each palette base write the buffer it copies\nlocal function tu() return math.floor(scr:time_until_vblank_start():as_double()*1e9+0.5) end\nlocal regs_until=tonumber(os.getenv(\'REGS_UNTIL\') or \'1000000000\')   -- a long run: the screen\'s frames only\n_G.ss_regs=sp:install_write_tap(0x800100,0x80017f,\'regs\',function(off,data,mask)\n if f>=regs_until then return end\n regs:write(string.format(\'%d\\t%d\\t%06x\\t%04x\\n\',f+1,tu(),off,data&0xffff))\n if off==0x80010a then\n  local base=(data&0xffff)*256\n  local t={string.pack(\'>I4I4I4\',f+1,tu(),base)}\n  for a=base,base+0x17fe,2 do t[#t+1]=string.pack(\'>I2\',sp:read_u16(a)) end\n  pal:write(table.concat(t))\n end end)\nif layer_and~=0xffff then\n _G.ss_layer=sp:install_write_tap(0x800166,0x800167,\'layer\',function(off,data,mask) return data&layer_and end)\nend\nemu.register_frame_done(function() f=f+1\n local held={}\n for _,p in ipairs(plan) do if f>=p[1] and f<=p[2] then held[p[3]]=true end end\n for _,tok in ipairs({\'COIN1\',\'START1\',\'P1_BUTTON1\',\'P1_BUTTON2\',\'P1_JOYSTICK_UP\',\'P1_JOYSTICK_DOWN\',\'P1_JOYSTICK_LEFT\',\'P1_JOYSTICK_RIGHT\'}) do\n  if held[tok] then fields[tok]:set_value(1) else fields[tok]:clear_value() end end\n -- system objects of kind 2 (the location captions: 20 records of 0x40 bytes at 0xFF5EDA, the kind at +17)\n local k2=0\n for k=0,19 do local o=0xff5eda+0x40*k if sp:read_u8(o)~=0 and sp:read_u8(o+0x17)==2 then k2=k2+1 end end\n -- frame, stage, ACTIVE, LZ_SRC, mode, kind-2 objects, SS_SHOWN, SS_LEVEL, SS_LATE, SS_ROW (asm/stage_select.s),\n -- then area, the ending\'s phase byte and ending_frame\'s EF_FRAME and EF_CUT (asm/ending.s), the SCROLL1 Y and\n -- SCROLL3 X shadows, the in-game byte 0xFF0C84 and the title\'s map word at TITLE_ADDR\n lg:write(string.format(\'%d\\t%d\\t%04x\\t%08x\\t%d\\t%d\\t%04x\\t%d\\t%d\\t%d\\t%d\\t%d\\t%d\\t%d\\t%d\\t%d\\t%d\\t%04x\\n\',f,sp:read_u8(0xff0cb2),\n  sp:read_u16(0xfff914),sp:read_u32(0xfff904),sp:read_u16(0xff0c12),k2,sp:read_u16(0xfff990),sp:read_u16(0xfff992),\n  sp:read_u16(0xfff9ac),sp:read_u16(0xfff926),sp:read_u8(0xff0cce),sp:read_u8(0xff0cdc),sp:read_u16(0xfffa00),\n  sp:read_u16(0xfffa02),sp:read_u16(0xff0c2e),sp:read_i16(0xff0c3c),sp:read_u8(0xff0c84),\n  title_addr>0 and sp:read_u16(title_addr) or 0))\n if shots[f] then scr:snapshot(string.format(\'%s/s_%05d.png\',out,f)) end\n if ev[0x0e] and not ranked_end and sp:read_u8(0xff0c84)==0 then ranked_end=true rank_line(\'game_end\') end\n for cue,o in pairs(evshots) do\n  if ev[cue] and o[f-ev[cue]] then scr:snapshot(string.format(\'%s/ev_%02x_%05d.png\',out,cue,f-ev[cue])) end end\n for cue,o in pairs(evdumps) do\n  if ev[cue] and o[f-ev[cue]] then\n   local d=assert(io.open(string.format(\'%s/ed_%02x_%05d.bin\',out,cue,f-ev[cue]),\'wb\'))\n   local t={}\n   for a=0x908000,0x90bffe,2 do t[#t+1]=string.pack(\'>I2\',sp:read_u16(a)) end\n   for a=0x914000,0x9157fe,2 do t[#t+1]=string.pack(\'>I2\',sp:read_u16(a)) end\n   d:write(table.concat(t)) d:close()\n  end end\n if f>=last then lg:close() snd:close() regs:close() pal:close() modes:close() m:exit() end end)\n'
CODE = '200-208:COIN1;290-340:P1_BUTTON1;290-340:P1_BUTTON2;300-306:START1'
CODE_START = 300
ORDER = [(0, 'prologue'), (5, 'intro_desert'), (1, 'brief_siberia'), (3, 'brief_aerial'), (2, 'brief_amazon'), (4, 'flight')]
DESERT_ROW = 1
PRESS = 460
GAP = 30
PICK = 520
PICK_SHOTS = 80
SHOTS = list(range(CODE_START - 4, PICK + PICK_SHOTS + 1))
PICK_LAYER = 5440
PICK_BLACK_WITHIN = 2
SHOWN_WITHIN = 24
ENTRY_WITHIN = 40
SHOT = PICK - 4
END = 1400
DESERT_END = 2600
CINE = ('c1e5', 'c1e6', 'c1e7', 'c1e8')
ON = 'c1e5'
TOUR_FROM, TOUR_GAP = (360, 60)
TOUR_BACK = 2
REF = {0: ('steps', 7200), 1: ('fade', 3600), 2: ('fade', 3600), 3: ('fade', 3600), 4: ('fade', 6200), 5: ('fade', 2600)}
FRAME_NS = 1000000000.0 / 59.637405
LINE_NS = FRAME_NS / 262
BLANK_LINES = 38
BACKDROP_OFF = SO.BACKDROP
CAP_OFF = 31 * 32
LOG = dict(frame=0, stage=1, active=2, src=3, mode=4, k2=5, shown=6, level=7, late=8, row=9, area=10, phase=11, ef=12, cut=13, s1y=14, s3x=15, ingame=16, title=17)
ENDING = ('ending', None)
ENDING_END = 12000
POST_DEMO = {'striderua': 503, 'striderjr': 630}
POST_DEMO_TOL = 30
ENDING_UP_END = 1300
MEIO_FALL = {'striderua': 220004, 'striderjr': 219308}
GAME_CLEAR, ENDING_CUE, GAME_OVER, RANKING = (32, 33, 14, 34)
STRIP_EVERY = 30
CODE_CUE = '40'

def presses(k, n):
    """The stick presses that select entry k of n from entry 0: right k times, or left once for the last."""
    if k == n - 1 and k > 1:
        return f';{PRESS}-{PRESS + 4}:P1_JOYSTICK_LEFT'
    return ''.join((f';{PRESS - GAP * (k - 1 - i)}-{PRESS - GAP * (k - 1 - i) + 4}:P1_JOYSTICK_RIGHT' for i in range(k)))

def play_order(desert, ending=False):
    """The entries in play order: (internal stage or 'ending', first cinematic)."""
    return [e for i, e in enumerate(ORDER) if desert or i != DESERT_ROW] + ([ENDING] if ending else [])

def runs(desert, ending=False):
    """name -> (inputs, stage, first cinematic, entry, frames) for a build with or without the desert, and"""
    order = play_order(desert, ending)
    n = len(order)
    out = {}
    for k, (st, scene) in enumerate(order):
        name = 'code' if k == 2 else 'wrap' if k == n - 1 else 'desert' if st == 5 else f'pick{k}'
        out[name] = (CODE + presses(k, n) + f';{PICK}-{PICK + 4}:START1', st, scene, k, DESERT_END if st == 5 else ENDING_END if st == ENDING[0] else END)
    pick = f';{PICK}-{PICK + 4}:START1'
    out['up'] = (CODE + f';{PRESS}-{PRESS + 4}:P1_JOYSTICK_UP' + pick, order[-1][0], order[-1][1], n - 1, ENDING_UP_END if ending else END)
    out['down'] = (CODE + f';{PRESS - GAP}-{PRESS - GAP + 4}:P1_JOYSTICK_DOWN;{PRESS}-{PRESS + 4}:P1_JOYSTICK_DOWN' + pick, order[2][0], order[2][1], 2, END)
    out['rapid_down'] = (CODE + f';{PRESS}-{PRESS + 2}:P1_JOYSTICK_RIGHT;{PRESS + 5}-{PRESS + 7}:P1_JOYSTICK_RIGHT' + pick, order[2][0], order[2][1], 2, END)
    out['rapid_up'] = (CODE + f';{PRESS}-{PRESS + 2}:P1_JOYSTICK_RIGHT;{PRESS + 12}-{PRESS + 14}:P1_JOYSTICK_RIGHT' + pick, order[2][0], order[2][1], 2, END)
    out['back'] = (CODE + f';{PRESS}-{PRESS + 2}:P1_JOYSTICK_RIGHT;{PRESS + 5}-{PRESS + 7}:P1_JOYSTICK_LEFT' + pick, order[0][0], order[0][1], 0, END)
    out['plain'] = ('200-208:COIN1;300-306:START1', 0, 'prologue', None, END)
    return out

def layer_and(still_layer):
    """The reference and select runs' picture: the star layers off, and the tile layers the still does not show."""
    return 65535 & ~SO.STAR_BITS & ~(~still_layer & 14)

def run_hbmame(binary, sets, set_name, out, plan, shots, end, mask=65535, extra=None):
    out.mkdir(parents=True)
    (out / 'gate.lua').write_text(LUA)
    env = dict(os.environ, SDL_VIDEODRIVER='dummy', SDL_AUDIODRIVER='dummy', OUT=str(out), PLAN=plan, SHOTS=','.join(map(str, shots)), END=str(end), LAYER_AND=f'{mask:04x}', **extra or {})
    r = subprocess.run([binary, set_name, '-rompath', str(sets), '-nothrottle', '-video', 'none', '-sound', 'none', '-seconds_to_run', str(end // 50 + 30), '-skip_gameinfo', '-noautosave', '-cfg_directory', str(out / 'cfg'), '-nvram_directory', str(out / 'nv'), '-snapshot_directory', str(out), '-autoboot_script', str(out / 'gate.lua')], env=env, cwd=out, capture_output=True, text=True, timeout=1800)
    (out / 'mame.log').write_text(r.stdout + r.stderr)
    log = [l.split('\t') for l in (out / 'log.tsv').read_text().splitlines()]
    snd = [l.split('\t') for l in (out / 'sound.tsv').read_text().splitlines()]
    regs = [(int(a), since_vblank(int(b)), int(c, 16), int(d, 16)) for a, b, c, d in (l.split('\t') for l in (out / 'regs.tsv').read_text().splitlines())]
    if len(log) != end:
        raise SystemExit(f'{out}: {len(log)} frames logged, {end} expected')
    return dict(log=log, snd=snd, regs=regs, pal=read_pal(out / 'pal.bin'), dir=out)

def since_vblank(ns):
    """Lines from the last VBlank start, from the time to the next one."""
    return int((FRAME_NS - ns) // LINE_NS) % 262

def read_pal(path):
    """The palette base writes: [(frame, lines after its VBlank, buffer address, its 0xC00 words)]."""
    data, out, rec = (path.read_bytes(), [], 12 + SO.PAL_BYTES)
    for i in range(0, len(data) - rec + 1, rec):
        f, v, base = struct.unpack_from('>3I', data, i)
        out.append((f, since_vblank(v), base, np.frombuffer(data, '>u2', SO.PAL_BYTES // 2, i + 12).astype(np.int64)))
    return out

def build_sets(build, parent, set_name, hbmame, rom_dir, work):
    src = work / 'ex'
    (src / parent).mkdir(parents=True)
    for q in (build / parent).iterdir():
        (src / parent / q.name).write_bytes(q.read_bytes())
    sets = work / 'sets'
    subprocess.run([sys.executable, str(EG.HBSET), 'build', '--hbmame', str(hbmame), '--rom-dir', str(rom_dir), '--ex-dir', str(src), '--set', set_name, '--date', '2026-10-10', '--out', str(sets)], check=True, stdout=subprocess.DEVNULL)
    return sets

def ex_region(build, parent):
    """The build's 4 MB EX graphics region (the four strex_gfx files, cps1_gfx.split_region reversed)."""
    import build_ex as BX
    parts = [(build / parent / n).read_bytes() for n in BX.EX_GFX]
    ex = bytearray(4 * len(parts[0]))
    for j, part in enumerate(parts):
        for i in range(0, len(part), 2):
            ex[4 * i + 2 * j:4 * i + 2 * j + 2] = part[i:i + 2]
    return ex

def band_image(region, entries):
    """The band as the screen must show it: black, with a caption page's sprites (subtitle_ex page"""
    import cps1_gfx as G
    import scene_gate as SG
    import subtitle_ex as SX
    img = np.zeros((SO.BAND_LINES, SO.SCREEN[0], 3), np.uint8)
    colors = [SG.hb_rgb(w) for w in SX.PALETTE]
    for x, y, code, attr in reversed(entries or []):
        cell = G.get_tile(region, G.ex_offset('obj', code), 16)
        if attr & 32:
            cell = cell[:, ::-1]
        if attr & 64:
            cell = cell[::-1, :]
        sx, sy = ((x & 511) - SO.ORIGIN[0], (y & 511) - SO.ORIGIN[1] - SO.BAND_TOP)
        for j in range(16):
            for i in range(16):
                p = int(cell[j, i])
                if p != 15 and 0 <= sy + j < SO.BAND_LINES and (0 <= sx + i < SO.SCREEN[0]):
                    img[sy + j, sx + i] = colors[p]
    return img

def page_mask(page):
    """Screen pixels of a caption page (subtitle_ex.page_entries: x + 64, y + 16, 16x16 each)."""
    m = np.zeros((SO.SCREEN[1], SO.SCREEN[0]), bool)
    for x, y, _, _ in page:
        sx, sy = (x - SO.ORIGIN[0], y - SO.ORIGIN[1])
        m[max(sy, 0):max(sy + 16, 0), max(sx, 0):max(sx + 16, 0)] = True
    return m

def reference(binary, sets, set_name, stage, out, mask):
    """A reference run of this build from the debug start: the stage's opening frame by its palette rule"""
    rule, end = REF[stage]
    r = SO.run_opening(binary, sets, set_name, stage, rule, end, out, layer_and=mask)
    r['png'] = out / f"s_{r['shot']:05d}.png"
    return r

def select_frames(log):
    """The frames the screen is up: the first run of consecutive player frames (ACTIVE = ON) after the"""
    on = [int(x[0]) for x in log if x[LOG['active']] == ON and int(x[0]) > CODE_START]
    run = on[:1]
    for f in on[1:]:
        if f != run[-1] + 1:
            break
        run.append(f)
    return run

def screen_state(seq, frames):
    """{frame: (kind, still, step)}: what each frame of the screen shows by the palette copies (a copy"""
    out, cur, i = ({}, ('none', None, None), 0)
    for f in frames:
        while i < len(seq) and seq[i][0] <= f:
            x = seq[i]
            cur = (x[2], x[3], x[4] if x[2] == 'step' else None)
            i += 1
        out[f] = cur
    return out

class Screen:
    """The checks every run that opens the screen gets: the band on every frame, the fade's palette"""

    def __init__(self, stills, levels, band, band_imgs):
        self.stills, self.levels, self.band, self.imgs = (stills, levels, band, band_imgs)
        self.steps = len(levels)
        self.faded = []
        for x in stills:
            offs = np.array(sorted((int(o) for o in x['palette']))) // 2
            auth = np.array([x['palette'][str(2 * o)] for o in offs], np.int64)
            st = [np.where(auth >> 12 <= lv, auth, auth & 4095 | lv << 12) for lv in levels] + [auth]
            self.faded.append((offs, st))

    def classify(self, words, shown, layer):
        """A palette copy (layer: the layer word written in the same VBlank, if one was): ('step', still, s),"""
        if layer == PICK_LAYER and shown is not None:
            return ('pick', shown) if words[BACKDROP_OFF // 2] == 0 else ('other', shown)
        if shown is None:
            return ('black', None) if words[BACKDROP_OFF // 2] == 0 else ('other', None)
        if layer is not None and layer == self.stills[shown]['black']:
            return ('black', shown) if words[BACKDROP_OFF // 2] == 0 else ('other', shown)
        offs, st = self.faded[shown]
        got = words[offs]
        for k, want in enumerate(st):
            if (got == want).all():
                return ('step', shown, k)
        return ('other', shown)

    def fixed_ok(self, words):
        """The band's palettes black and the caption palette whole."""
        import subtitle_ex as SX
        for L, p in self.band.items():
            off = SO.PAGE[L] + 32 * p
            if any((words[(off >> 1) + i] != 61440 for i in range(16))):
                return False
        return all((words[(CAP_OFF >> 1) + i] == w for i, w in enumerate(SX.PALETTE)))

    def check(self, res, frames=None, expect=None):
        """The band, the fade and the timing of one run, over the frames its screen is up. frames: the"""
        from PIL import Image
        log, out = (res['log'], res['dir'])
        up = select_frames(log)
        if not up:
            return dict(opened=False, passed=False)
        first, last = (up[0], up[-1])

        def shown_at(f):
            v = int(log[f - 1][LOG['shown']], 16)
            return None if v == 65535 else v
        layer_at = {}
        for f, v, a, d in res['regs']:
            if a == 8388966:
                layer_at[f] = d
        seq, other, fixed_bad, lines_bad, black_frames = ([], [], [], [], [])
        for f, v, b, w in res['pal']:
            if not first < f <= last:
                continue
            sh = shown_at(f)
            c = self.classify(w, sh, layer_at.get(f))
            seq.append((f, v) + c + ((None,) if c[0] != 'step' else ()))
            if c[0] == 'other':
                other.append(f)
            if c[0] == 'black':
                black_frames.append(f)
            if sh is not None and c[0] != 'pick' and (not self.fixed_ok(w)):
                fixed_bad.append(f)
        lines = [v for f, v, a, d in res['regs'] if first < f <= last]
        pal_lines = [v for f, v, a, d in res['regs'] if first < f <= last and a == 8388874]
        for f, v, a, d in res['regs']:
            if first < f <= last and v >= BLANK_LINES:
                lines_bad.append((f, v, f'{a:#08x}'))
        walk_bad, prev = ([], None)
        picks = [x[0] for x in seq if x[2] == 'pick']
        pick_f = picks[0] if picks else None
        after_pick = [x[0] for x in seq if pick_f is not None and x[0] > pick_f]
        for x in seq:
            f, v, kind, k, s = x
            if kind == 'pick':
                continue
            sel = int(log[f - 2][LOG['row']])
            if kind == 'step':
                if prev is not None:
                    if prev[2] == 'step':
                        ok = prev[3] == k and abs(prev[4] - s) == 1 and ((s < prev[4]) == (sel != k)) and (f == prev[0] + 1 or prev[4] == self.steps)
                    else:
                        ok = prev[2] == 'black' and s == 0 and (f == prev[0] + 1) and (prev[3] != k)
                    if not ok:
                        walk_bad.append((x, prev))
            elif kind == 'black' and prev is not None and (not (prev[2] == 'step' and prev[4] == 0 and (f >= prev[0] + 1) and (prev[3] == k))):
                walk_bad.append((x, prev))
            prev = x
        band_bad, black_bad, checked = ([], [], 0)
        for f in frames or sorted((int(q.stem[2:]) for q in out.glob('s_*.png'))):
            q = out / f's_{f:05d}.png'
            if not first < f <= last or not q.exists() or (pick_f is not None and f >= pick_f):
                continue
            im = np.asarray(Image.open(q).convert('RGB'))
            want = self.imgs[expect if expect is not None else shown_at(f)]
            bad = int((im[SO.BAND_TOP:] != want).any(-1).sum())
            checked += 1
            if bad:
                band_bad.append((f, bad))
            if f in black_frames and im[:SO.BAND_TOP].any():
                black_bad.append(f)
        nxt = next((int(x[0]) for x in log if int(x[0]) > last and (x[LOG['active']] == ON or x[LOG['mode']] == '4')), None)
        pick_lit, pick_checked = ([], 0)
        if pick_f is not None:
            for f in range(pick_f, nxt or len(log) + 1):
                q = out / f's_{f:05d}.png'
                if not q.exists():
                    continue
                pick_checked += 1
                n_lit = int(np.asarray(Image.open(q).convert('RGB')).any(-1).sum())
                if n_lit:
                    pick_lit.append((f, n_lit))
        late = int(log[last - 1][LOG['late']])
        rep = dict(pick_black=pick_f, next_scene=nxt, pick_frames_checked=pick_checked, pick_lit=pick_lit[:10], copies_after_pick=after_pick[:10], opened=True, frames=[first, last], band_frames_checked=checked, band_frames_bad=len(band_bad), band_bad=band_bad[:10], palette_copies=len(seq), copies_other=other[:10], copies_fixed_bad=fixed_bad[:10], walk_bad=[str(w) for w in walk_bad[:10]], black_frames=black_frames, black_not_black=black_bad, writes_outside_blank=lines_bad[:10], write_lines_max=max(lines, default=None), palette_write_lines_max=max(pal_lines, default=None), late=late)
        rep['passed'] = checked > 0 and (not band_bad) and (not other) and (not fixed_bad) and (not walk_bad) and (not black_bad) and (not lines_bad) and (late == 0) and (not pick_lit) and (not after_pick) and (pick_f is None or pick_checked > 0)
        rep['seq'] = seq
        return rep

class EndingChecks:
    """The ENDING test entry (build_ex.py --test-ending). Its pick must start Meio's room (stage 4, area 10:"""
    CREDIT_AFTER = 640
    TITLE_SHOT = 150

    def __init__(self, rom_dir, census, parent):
        import ending_ex as EE
        self.EE, self.parent, self.rom_dir = (EE, parent, rom_dir)
        self.data = EE.build(rom_dir, census / 'ending')
        self.plan = self.data['regions'][parent]['plan']
        self.rows = self.data['regions'][parent]['rows']
        self.cuts = self.data['schedule']['cuts']
        self.names = ['s00', 's01', 's02', 's03']
        self.at = [f + EE.LOOP0 - 1 + EE.FADE + 8 for f, _ in self.cuts]
        sec = self.plan['sections'][0]
        self.cast = sec
        self.credit_at = sec['cut_frame'] + self.CREDIT_AFTER
        self.still_at = self.at[[self.names[si] for _, si in self.cuts].index(SO.ENDING_STILL)]
        self.total = self.plan['frames_from_0x21']
        self.shots = {GAME_CLEAR: [1] + list(range(60, 900, 60)), ENDING_CUE: sorted(set(self.at + [self.credit_at, 300, 1500])), GAME_OVER: list(range(0, 1500, 30)) + list(range(1500, 2400, 50))}

    def env(self, full, title_addr):
        sh = self.shots if full else {GAME_CLEAR: [1, 60]}
        return dict(EVSHOTS=';'.join((f'{c:x}:' + ','.join(map(str, v)) for c, v in sh.items())), EVDUMPS=f'{ENDING_CUE:x}:{self.credit_at}' if full else '', TITLE_ADDR=f'{title_addr:x}', REGS_UNTIL=str(PICK + 300))

    @staticmethod
    def strip_shots():
        return list(range(PICK, PICK + 900, STRIP_EVERY))

    @staticmethod
    def entry_stage(log, last_up):
        """(stage, area, frame) of the first play frame (game mode 4) after the screen."""
        x = next((x for x in log if int(x[0]) > last_up and x[LOG['mode']] == '4'), None)
        return (int(x[LOG['stage']]), int(x[LOG['area']]), int(x[0])) if x else (None, None, None)

    def compare_still(self, shot_png, wrap):
        """The select screen's ENDING still against the ending's frame of that picture (the 'wrap' run): equal in"""
        from PIL import Image
        EE = self.EE
        ref = wrap['dir'] / f'ev_{ENDING_CUE:02x}_{self.still_at:05d}.png'
        if not ref.exists():
            return dict(reference=str(ref), ok=False, why='no ending frame')
        A = np.asarray(Image.open(shot_png).convert('RGB')).astype(np.int32)
        B = np.asarray(Image.open(ref).convert('RGB')).astype(np.int32)
        win = (slice(EE.WIN_Y, EE.WIN_Y + EE.WIN_H), slice(EE.WIN_X, EE.WIN_X + EE.WIN_W))
        bad = int((A[win] != B[win]).any(-1).sum())
        lit = int(B[win].any(-1).sum())
        out = np.ones((SO.BAND_TOP, SO.SCREEN[0]), bool)
        out[EE.WIN_Y:EE.WIN_Y + EE.WIN_H, EE.WIN_X:EE.WIN_X + EE.WIN_W] = False
        stray = int((A[:SO.BAND_TOP].any(-1) & out).sum())
        return dict(reference=ref.name, window_pixels=EE.WIN_W * EE.WIN_H, window_lit=lit, window_mismatched=bad, lit_outside_window=stray, ok=bad == 0 and lit > 0.2 * EE.WIN_W * EE.WIN_H and (stray == 0))

    def check(self, res, full, last_up, title):
        """The clear after the pick (and with full, the whole ending to the title). title: (map byte, EX code)."""
        from PIL import Image
        EE = self.EE
        log, out = (res['log'], res['dir'])
        snd = [(int(f), int(v, 16)) for f, v in res['snd']]
        modes = [l.split('\t') for l in (out / 'modes.tsv').read_text().splitlines()]
        rep, req = ({}, {})
        st, ar, play = self.entry_stage(log, last_up)
        rep['entry'] = dict(stage=st, area=ar, first_play_frame=play)
        req['meio_room'] = (st, ar) == (4, 10)
        fall = next(((int(f), int(pc, 16)) for f, v, pc in modes if int(f) > last_up and int(v, 16) == 6), None)
        rep['mode6'] = None if fall is None else dict(frame=fall[0], pc=f'{fall[1]:#x}')
        req['meio_falls_by_stock_code'] = fall is not None and fall[1] == MEIO_FALL[self.parent]
        f20 = next((f for f, v in snd if v == GAME_CLEAR and f > last_up), None)
        rep['game_clear_0x20'] = f20
        req['game_clear_after_the_fall'] = f20 is not None and fall is not None and (0 <= f20 - fall[0] <= 10)
        if not full:
            rep['requirements'] = req
            rep['passed'] = all(req.values())
            return rep
        f21 = next((f for f, v in snd if v == ENDING_CUE and f20 is not None and (f > f20)), None)
        f0e = next((f for f, v in snd if v == GAME_OVER and f21 is not None and (f > f21)), None)
        rep.update(ending_0x21=f21, game_clear_to_ending=None if f21 is None or f20 is None else f21 - f20, game_over_0x0e=f0e)
        req['ending_cue_0x21'] = f21 is not None
        if f21 is None:
            rep['requirements'] = req
            rep['passed'] = False
            return rep
        rows = [x for x in log if int(x[0]) >= f21]

        def first(col, pred):
            return next((int(x[0]) - f21 for x in rows if pred(int(x[LOG[col]]))), None)
        hold, fade = (first('phase', lambda v: v == 2), first('phase', lambda v: v == 4))
        end = next((int(x[0]) - f21 for x in rows if fade is not None and int(x[0]) - f21 > fade and (int(x[LOG['phase']]) == 0)), None)
        ef1 = first('ef', lambda v: v == 1)
        lat = None if ef1 is None else EE.LOOP0 - ef1
        rel = lambda v: None if v is None or ef1 is None else v - ef1 + EE.LOOP0
        rep['roll'] = dict(hold_start=hold, fade_start=fade, roll_end=end, ending_frame_1=ef1, game_over=None if f0e is None else f0e - f21, planned_end=self.total, latch_lag=lat, from_the_roll=dict(hold_start=rel(hold), fade_start=rel(fade), roll_end=rel(end)))
        req['ending_frame_1_at_loop0'] = lat in (0, 1)
        req['hold_start'] = rel(hold) == EE.HOLD_START
        req['fade_start'] = rel(fade) == self.total - EE.FADE_OUT
        req['roll_end_frame'] = rel(end) == self.total
        req['game_over_follows'] = f0e is not None and end is not None and (f0e - f21 > end)
        seen = {}
        for x in rows:
            seen.setdefault(int(x[LOG['cut']]), int(x[0]) - f21)
        want_cut = {k + 1: f + EE.LOOP0 - 1 + EE.FADE for k, (f, _) in enumerate(self.cuts)}
        rep['cut_index_frames'], rep['cut_index_expected'] = (seen, want_cut)
        req['cuts_on_schedule'] = all((rel(seen.get(k)) == v for k, v in want_cut.items()))
        stills = {}
        for (f, si), at in zip(self.cuts, self.at):
            name = self.names[si]
            pan_v = 0
            if name == 's02':
                prev = [x for x in rows if int(x[0]) - f21 <= at - 2]
                pan_v = int(prev[-1][LOG['s3x']])
            q = out / f'ev_{ENDING_CUE:02x}_{at:05d}.png'
            if not q.exists():
                stills[name] = dict(frame=at, missing=True, drawn=1, differing=1)
                continue
            model = EE.window_model(self.data, name, pan_v)
            shot = np.asarray(Image.open(q).convert('RGB')).astype(np.int64)
            win = shot[EE.WIN_Y:EE.WIN_Y + EE.WIN_H, EE.WIN_X:EE.WIN_X + EE.WIN_W]
            drawn = model[..., 0] >= 0
            diff = (win != np.where(drawn[..., None], model, 0)).any(-1)
            stills[name] = dict(frame=at, pan=pan_v, drawn=int(drawn.sum()), differing=int(diff.sum()))
        rep['stills'] = stills
        req['stills_match_model'] = len(stills) == 4 and all((v['differing'] <= 0.01 * v['drawn'] for v in stills.values()))
        rep['cast_page'] = self.cast_page(out, rows, f21)
        req['cast_page_shown'] = rep['cast_page'].get('ok', False)
        rk = {}
        if (out / 'rank.tsv').exists():
            for line in (out / 'rank.tsv').read_text().splitlines():
                tag, fr, sc, *tab = line.split('\t')
                rk[tag] = dict(frame=int(fr), score=int(sc, 16), table=tab)
        go, ge = (rk.get('game_over'), rk.get('game_end'))
        beaten = sum((1 for e in go['table'] if int(e.split(':')[0], 16) < go['score'])) if go else None
        ranking = [f for f, v in snd if v == RANKING and f0e is not None and (f > f0e)]
        rep['ranking'] = dict(score=f"{go['score']:#010x}" if go else None, entries_beaten=beaten, table_at_game_over=go['table'] if go else None, table_at_game_end=ge['table'] if ge else None, game_end_frame=ge['frame'] if ge else None, name_entry_cue_0x22=ranking[:3])
        req['stock_rule_would_rank'] = bool(beaten)
        req['no_high_score_entry'] = go is not None and ge is not None and (ge['table'] == go['table'])
        addr, code = title
        t = next((int(x[0]) for x in log if f0e is not None and int(x[0]) > f0e and (int(x[LOG['title']], 16) == code)), None)
        ig = next((int(x[0]) for x in log if f0e is not None and int(x[0]) > f0e and (x[LOG['ingame']] == '0')), None)
        rep['title'] = dict(game_ended=ig, title_cell_frame=t, after_game_over=None if t is None else t - f0e, map_byte=f'{addr:#08x}', ex_code=f'{code:#06x}')
        req['returns_to_title'] = t is not None and ig is not None
        started = [int(x[0]) for x in log if ig is not None and int(x[0]) > ig and (x[LOG['ingame']] != '0')]
        demo_set = next((int(x[0]) for x in log if t is not None and int(x[0]) > t and (x[LOG['mode']] == '2')), None)
        demo = next((int(x[0]) for x in log if demo_set is not None and int(x[0]) > demo_set and (x[LOG['mode']] == '4') and (x[LOG['ingame']] == '0')), None)
        rep['after_the_ending'] = dict(game_started_without_input=started[:3], attract_demo_play=demo, demo_after_game_end=None if demo is None or ig is None else demo - ig, demo_stage=None if demo is None else int(log[demo - 1][LOG['stage']]), run_end=len(log))
        req['no_game_starts_without_input'] = ig is not None and (not started)
        req['attract_demo_follows'] = demo is not None and int(log[demo - 1][LOG['stage']]) == 1 and (abs(demo - ig - POST_DEMO[self.parent]) <= POST_DEMO_TOL)
        rep['requirements'] = req
        rep['passed'] = all(req.values())
        return rep

    def cast_page(self, out, rows, f21):
        """The cast rows in the SCROLL1 map dump at credit_at (ed_21_<f>.bin), and the rows on screen then rendered"""
        from PIL import Image
        import cps1_gfx as G
        q = out / f'ed_{ENDING_CUE:02x}_{self.credit_at:05d}.bin'
        png = out / f'ev_{ENDING_CUE:02x}_{self.credit_at:05d}.png'
        if not q.exists() or not png.exists():
            return dict(ok=False, why='no dump')
        dump = q.read_bytes()
        smap, pal = (dump[:SO.MAP_BYTES], dump[SO.MAP_BYTES:])
        sec = self.cast
        sy = {int(x[0]) - f21: int(x[LOG['s1y']]) for x in rows}
        shot = np.asarray(Image.open(png).convert('RGB')).astype(np.int64)
        stock = self.stock_font()
        best = None
        for lag in (0, 1, 2, 3):
            s = sy.get(self.credit_at - lag)
            if s is None:
                continue
            img = np.full(shot.shape, -1, np.int64)
            on, in_map = ([], 0)
            for r in range(sec['first_row'], sec['last_row'] + 1):
                y = (8 * r + self.EE.ROW_Y0 - (512 - s & 511)) % 512
                if not 0 <= y <= SO.SCREEN[1] - 8:
                    continue
                on.append(r)
                text = self.rows[r]
                want = [28672 + b for b in text.encode('latin1')] + [28704] * (32 - len(text))
                got = [struct.unpack_from('>H', smap, 4 * SO.scan(1, c, r % 64))[0] for c in range(32)]
                in_map += got == want
                for c, ch in enumerate(text.encode('latin1')):
                    attr = struct.unpack_from('>H', smap, 4 * SO.scan(1, c, r % 64) + 2)[0]
                    pens = stock.pens(1, 28672 + ch, c & 1)
                    base = SO.PAGE[1] + 32 * (attr & 31)
                    for yy in range(8):
                        for xx in range(8):
                            p = int(pens[yy, xx])
                            if p != 15:
                                img[y + yy, 8 * c + xx] = SO.rgb(struct.unpack_from('>H', pal, base + 2 * p)[0], 'hb')
            drawn = img[..., 0] >= 0
            bad = int(((shot != img).any(-1) & drawn).sum())
            cand = dict(lag=lag, rows_on_screen=len(on), text_rows=sum((1 for r in on if self.rows[r].strip())), rows_in_map=in_map, glyph_pixels=int(drawn.sum()), mismatched=bad, text=[self.rows[r].strip() for r in on if self.rows[r].strip()])
            if best is None or bad < best['mismatched']:
                best = cand
        ok = best is not None and best['mismatched'] == 0 and (best['rows_in_map'] == best['rows_on_screen']) and (best['text_rows'] >= 8)
        return dict(section=sec['still'], map_rows=[sec['first_row'], sec['last_row']], frame=self.credit_at, screen=best, ok=ok)

    def stock_font(self):
        if not hasattr(self, '_font'):
            import mapper_testkit as K
            import title_ex as TX
            self._font = SO.Tiles(TX.stock_gfx(K.pool([self.rom_dir / self.parent])))
        return self._font

    def strip(self, res, page_png, path, rep):
        """The review strip: the select screen's ENDING still, then the ending reached from it (rep: check()'s"""
        from PIL import Image, ImageDraw
        out = res['dir']
        picks = [(page_png, 'select: ENDING')]
        early = sorted(out.glob('s_*.png'))
        room = [q for q in early if int(q.stem[2:]) >= PICK + 120]
        if room:
            picks.append((room[0], f"Meio's room f{int(room[0].stem[2:])}"))
        fall = (rep.get('mode6') or {}).get('frame')
        falls = [q for q in early if fall is not None and int(q.stem[2:]) <= fall - 20]
        if falls:
            picks.append((falls[-1], f'Meio falls f{int(falls[-1].stem[2:])}'))
        for off, label in ((1, 'Game Clear 0x20'), (240, '+240'), (420, '+420 the leap'), (600, '+600'), (780, '+780 bonus')):
            q = out / f'ev_{GAME_CLEAR:02x}_{off:05d}.png'
            if q.exists():
                picks.append((q, label))
        for off, label in sorted([(300, '0x21 +300 roll'), (1500, '0x21 +1500'), (self.credit_at, 'cast page')] + [(at, f'{n} cut') for at, n in zip(self.at, [self.names[si] for _, si in self.cuts])]):
            q = out / f'ev_{ENDING_CUE:02x}_{off:05d}.png'
            if q.exists() and q not in [x for x, _ in picks]:
                picks.append((q, label))
        for off, label in ((30, 'Game Over'), (450, 'name entry (not ranked)')):
            q = out / f'ev_{GAME_OVER:02x}_{off:05d}.png'
            if q.exists():
                picks.append((q, label))
        t = (rep.get('title') or {}).get('after_game_over')
        go = [q for q in sorted(out.glob(f'ev_{GAME_OVER:02x}_*.png')) if t is not None and int(q.stem.split('_')[-1]) >= t + self.TITLE_SHOT]
        if go:
            picks.append((go[0], f"the title (Game Over +{int(go[0].stem.split('_')[-1])})"))
        W, H = SO.SCREEN
        cols = 4
        th = (W // 2, H // 2)
        img = Image.new('RGB', (cols * (th[0] + 4), (len(picks) + cols - 1) // cols * (th[1] + 16)), (40, 40, 40))
        for i, (q, label) in enumerate(picks):
            x, y = (i % cols * (th[0] + 4), i // cols * (th[1] + 16))
            img.paste(Image.open(q).convert('RGB').resize(th), (x, y + 14))
            ImageDraw.Draw(img).text((x + 2, y + 1), label, fill=(255, 255, 0))
        img.save(path)
        return [label for _, label in picks]

def switches(seq, presses):
    """Per press: its frames to the first copy, the old still's steps down, the black frames, the new"""
    out = []
    for i, p in enumerate(presses):
        end = presses[i + 1] if i + 1 < len(presses) else 10 ** 9
        win = [x for x in seq if p < x[0] <= end]
        if not win:
            out.append(dict(press=p, copies=0))
            continue
        old = win[0][3]
        down = [x for x in win if x[2] == 'step' and x[3] == old]
        black = [x for x in win if x[2] == 'black']
        up = [x for x in win if x[2] == 'step' and x[3] != old]
        full = next((x[0] for x in up if x[4] == max((y[4] for y in up))), None) if up else None
        out.append(dict(press=p, first_copy=win[0][0] - p, down=[x[4] for x in down], black=len(black), up=[x[4] for x in up], new=up[0][3] if up else None, new_from=up[0][0] - p if up else None, full_at=full - p if full else None))
    return out

def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('--build', type=Path, required=True)
    p.add_argument('--runtime', type=Path, required=True)
    p.add_argument('--hbmame', type=Path, required=True)
    p.add_argument('--rom-dir', type=Path, required=True)
    p.add_argument('--workdir', type=Path, required=True)
    p.add_argument('--set', default='striderus01', choices=sorted(EG.PARENT))
    p.add_argument('--control', type=Path, help='a build whose stills are not the stage openings (must fail)')
    p.add_argument('--band-control', type=Path, help='a build whose stills have no band (must fail)')
    p.add_argument('--jobs', type=int, default=2)
    p.add_argument('--census', type=Path, help="the P0.1 census (its ending/, as ending_ex.py gate takes it): required for a --test-ending build (the ENDING entry's checks)")
    a = p.parse_args()
    from PIL import Image
    import mapper_testkit as K
    import title_ex as TX
    work = a.workdir.resolve()
    work.mkdir(parents=True, exist_ok=False)
    binary = json.loads((a.runtime / 'runtime.json').read_text())['binary']
    build, rom_dir = (a.build.resolve(), a.rom_dir.resolve())
    bjs = json.loads((build / 'build.json').read_text())
    parent = EG.PARENT[a.set]
    streams = bjs['sets'][parent]['streams']
    order = sorted(streams, key=lambda k: streams[k])
    entries = bjs['stills']['entries']
    n = len(entries)
    te = bjs.get('test_ending')
    if n - bool(te) not in (5, 6):
        raise SystemExit(f'{n} stills in the build, 5 or 6 expected' + (' and the ENDING entry' if te else ''))
    desert = n - bool(te) == 6
    if te:
        if te['entry'] != n - 1 or entries[f'still{n - 1}']['stage'] != ENDING[0] or any((entries[f'still{k}']['stage'] == ENDING[0] for k in range(n - 1))):
            raise SystemExit('build.json: the ENDING entry is not the last')
        if not a.census:
            raise SystemExit("a --test-ending build needs --census (the ending's checks)")
        ending = EndingChecks(rom_dir, a.census.resolve(), parent)
    elif any((e['stage'] == ENDING[0] for e in entries.values())):
        raise SystemExit('build.json: an ENDING still without test_ending')
    caps = json.loads((build / 'captions.json').read_text())
    pages = caps['pages_detail']
    still_pages = [pages[i]['entries'] for i in caps['still_pages']]
    sdata = json.loads((build / 'stills.json').read_text())[parent]
    band = {int(k[6:]): v for k, v in bjs['stills']['band']['palettes'].items()}
    levels = [int(v, 16) for v in bjs['stills']['band']['fade_levels']]
    if levels != list(SO.FADE_LEVELS):
        raise SystemExit("the build's fade steps are not stage_openings.FADE_LEVELS")
    sets = build_sets(build, parent, a.set, a.hbmame, rom_dir, work)
    region = ex_region(build, parent)
    import subtitle_ex as SX
    src_ok, src_bad = SX.source_check(caps, region, SX.stock_gfx(rom_dir / 'striderua'))
    texts = [pages[i]['page'] for i in caps['still_pages']]
    want = [['Select Stage', f"{k + 1} {entries[f'still{k}']['name']}"] for k in range(n)]
    text_ok = texts == want and all((any((c.islower() for c in t[1])) for t in texts))
    if not (src_ok and text_ok):
        print('caption source check FAILED:', src_bad[:5], '' if text_ok else f'texts {texts}', flush=True)
    tiles = SO.Tiles(TX.stock_gfx(K.pool([rom_dir / parent])), region)
    imgs = {None: band_image(region, None)}
    imgs.update({k: band_image(region, still_pages[k]) for k in range(n)})
    screen = Screen(sdata, levels, band, imgs)
    plan = runs(desert, bool(te))
    if te:
        cell = bjs['title_cells'][parent][0]
        title = (int(cell['map_byte'], 16), int(cell['ex'], 16))
    jobs = {}
    for name, (inputs, st, scene, k, end) in plan.items():
        is_end = bool(te) and st == ENDING[0]
        jobs[name] = ('run', inputs, SHOTS + (ending.strip_shots() if is_end and name == 'wrap' else []), end, 65535 & ~SO.STAR_BITS, sets, ending.env(name == 'wrap', title[0]) if is_end else None)
    tour_press = [TOUR_FROM + TOUR_GAP * i for i in range(n - 1 + TOUR_BACK)]
    tour = CODE + ''.join((f";{q}-{q + 4}:P1_JOYSTICK_{('RIGHT' if i < n - 1 else 'LEFT')}" for i, q in enumerate(tour_press)))
    tour_end = tour_press[-1] + TOUR_GAP
    jobs['tour'] = ('run', tour, list(range(CODE_START - 4, tour_end + 1)), tour_end, 65535, sets, None)
    stage_of = {f'still{k}': entries[f'still{k}']['stage'] for k in range(n)}
    for k in range(n):
        st = stage_of[f'still{k}']
        if st == ENDING[0]:
            continue
        jobs[f'ref{k}'] = ('ref', st, layer_and(int(entries[f'still{k}'][parent]['layer'], 16)))
        jobs[f'view{k}'] = ('ref', st, 65535)
    for opt, name in ((a.control, 'control_code'), (a.band_control, 'band_control')):
        if opt:
            csets = build_sets(opt.resolve(), parent, a.set, a.hbmame, rom_dir, work / f'{name}_set')
            jobs[name] = ('run', plan['code'][0], SHOTS, END, 65535 & ~SO.STAR_BITS, csets, None)

    def do(name):
        j = jobs[name]
        if j[0] == 'run':
            return run_hbmame(binary, j[5], a.set, work / name, j[1], j[2], j[3], j[4], j[6])
        return reference(binary, sets, a.set, j[1], work / name, j[2])
    with ThreadPoolExecutor(a.jobs) as ex:
        res = dict(zip(jobs, ex.map(do, jobs)))

    def scene_of(ptr, strm=streams, ordr=order):
        return max((k for k in ordr if strm[k] <= ptr), key=lambda k: strm[k], default=None)

    def compare(shot_png, ref, page):
        """The select screen against the reference frame, above the band and outside both runs' sprites."""
        A = np.asarray(Image.open(shot_png).convert('RGB')).astype(np.int32)
        B = np.asarray(Image.open(ref['png']).convert('RGB')).astype(np.int32)
        mask = ~(page_mask(page) | SO.sprite_mask(ref['gfx'], (36864, 36928, ref['regs']['obj'])))
        mask[SO.BAND_TOP:] = False
        bad = int(((A != B).any(-1) & mask).sum())
        return dict(pixels=int(mask.sum()), mismatched=bad, ok=bad == 0 and mask.sum() > 0.6 * mask[:SO.BAND_TOP].size)

    def ref_digest(ref):
        return SO.digest(SO.still(SO.parse(ref['data'], ref['regs']), tiles))
    report = dict(entries=n, set=a.set, band=bjs['stills']['band'], text=caps['still_text'], source_check=dict(passed=src_ok, problems=src_bad[:20], still_texts=texts, mixed_case=text_ok))
    ok = src_ok and text_ok
    for name, (inputs, want_stage, want_scene, k, end) in plan.items():
        r = res[name]
        log, snd, out = (r['log'], r['snd'], r['dir'])
        is_end = bool(te) and want_stage == ENDING[0]
        stage = int(log[-1][LOG['stage']])
        voice = any((v == CODE_CUE and 300 <= int(f) <= 400 for f, v in snd))
        coded = name != 'plain'
        rep = dict(stage=stage, code_voice=voice, want=[want_stage, want_scene, k])
        good = (is_end or stage == want_stage) and voice == coded
        up = select_frames(log) if coded else []
        after = [scene_of(int(x[LOG['src']], 16)) for x in log if x[LOG['active']] == ON and (not up or int(x[0]) > up[-1])]
        rep['first_scene'] = next((s for s in after if s is not None), None)
        good &= rep['first_scene'] == want_scene
        if coded:
            sc = screen.check(r)
            rep['screen'] = {kk: v for kk, v in sc.items() if kk != 'seq'}
            good &= sc.get('passed', False)
            good &= sc.get('pick_black') is not None and 0 < sc['pick_black'] - PICK <= PICK_BLACK_WITHIN
            state = screen_state(sc.get('seq', []), range(CODE_START, SHOT + 1))
            last_press = max([int(x.split('-')[0]) for x in inputs.split(';') if 'JOYSTICK' in x] or [CODE_START])
            full = next((f - last_press for f in range(last_press, SHOT + 1) if state[f] == ('step', k, len(levels))), None)
            rep.update(at_shot=state[SHOT], full_frames_after_press=full)
            within = SHOWN_WITHIN if 'JOYSTICK' in inputs else ENTRY_WITHIN
            good &= state[SHOT] == ('step', k, len(levels)) and full is not None and (full <= within)
            if is_end:
                cmp = ending.compare_still(out / f's_{SHOT:05d}.png', res['wrap'])
                rep['opening'] = dict(ending_picture=SO.ENDING_STILL, pixels=cmp)
                good &= cmp['ok']
                ec = ending.check(r, name == 'wrap', up[-1] if up else PICK, title)
                rep['ending'] = ec
                good &= ec['passed']
            else:
                ref = res[f'ref{k}']
                cmp = compare(out / f's_{SHOT:05d}.png', ref, still_pages[k])
                dig = ref_digest(ref)
                want_dig = entries[f'still{k}'][parent]['sha256']
                rep['opening'] = dict(reference_frame=ref['shot'], reference_play=ref['play'], pixels=cmp, digest_match=dig == want_dig, reference_digest=dig[:16], still_digest=want_dig[:16])
                good &= cmp['ok'] and dig == want_dig
            presses_at = sorted((int(x.split('-')[0]) for x in inputs.split(';') if 'JOYSTICK' in x))
            rep['switches'] = switches(sc.get('seq', []), presses_at)
            seen = sorted({int(log[f - 1][LOG['shown']], 16) for f in up} - {65535})
            rep['stills_shown'] = seen
            if name == 'rapid_down':
                good &= 1 not in seen and seen == [0, 2]
            if name == 'rapid_up':
                sw = rep['switches']
                good &= bool(seen == [0, 1, 2] and len(sw) == 2 and (0 < len(sw[0].get('up', [])) < len(levels) + 1) and sw[1].get('down') and (sw[1]['down'][0] < len(levels) - 1))
            if name == 'back':
                good &= seen == [0] and (not sc['black_frames'][1:]) and (rep['switches'][0].get('black') == 0)
        else:
            good &= rep['first_scene'] == 'prologue' and (not any((int(x[LOG['shown']], 16) not in (0, 65535) for x in log)))
        if name == 'desert':
            cine = [int(x[0]) for x in log if x[LOG['active']] in CINE]
            intro_end = max(cine) if cine else None
            cap = next((int(x[0]) for x in log if intro_end and int(x[0]) > intro_end and (x[LOG['k2']] != '0')), None)
            early = [int(x[0]) for x in log if intro_end and PICK < int(x[0]) <= intro_end and (x[LOG['k2']] != '0')]
            play = next((int(x[0]) for x in log if cap and int(x[0]) > cap and (x[LOG['mode']] == '4') and (x[LOG['stage']] == '5')), None)
            rep.update(intro_end=intro_end, caption_at=cap, caption_before_intro_end=early[:5], play_at=play)
            good &= cap is not None and (not early) and (play is not None)
        rep['passed'] = bool(good)
        report[name] = rep
        ok &= good
        print(name, json.dumps({kk: v for kk, v in rep.items() if kk not in ('switches',)}, default=str), flush=True)
        if 'switches' in rep:
            print('  switches', rep['switches'], flush=True)
    tr = res['tour']
    sc = screen.check(tr)
    sw = switches(sc.get('seq', []), tour_press)
    full_steps = list(range(len(levels) - 1, -1, -1))
    clean = [s for s in sw if s.get('down') == full_steps and s.get('black') == 1 and (s.get('up') == list(range(len(levels) + 1)))]
    report['tour'] = dict(screen={kk: v for kk, v in sc.items() if kk != 'seq'}, switches=sw, clean_switches=len(clean), presses=tour_press)
    tour_ok = sc.get('passed', False) and len(clean) == len(sw)
    report['tour']['passed'] = tour_ok
    ok &= tour_ok
    print('tour', json.dumps(report['tour'], default=str), flush=True)
    for name, what in (('control_code', 'opening'), ('band_control', 'band')):
        if name not in res:
            continue
        cr = res[name]
        if what == 'opening':
            c = compare(cr['dir'] / f's_{SHOT:05d}.png', res['ref2'], still_pages[2])
            report[name] = dict(pixels=c, fails=not c['ok'])
        else:
            im = np.asarray(Image.open(cr['dir'] / f's_{SHOT:05d}.png').convert('RGB'))
            bad = int((im[SO.BAND_TOP:] != imgs[2]).any(-1).sum())
            report[name] = dict(frame=SHOT, band_pixels=int(SO.BAND_LINES * SO.SCREEN[0]), band_mismatched=bad, fails=bad > 0)
        ok &= report[name]['fails']
        print(name, report[name], flush=True)
    tdir = tr['dir']
    tstate = screen_state(sc.get('seq', []), range(CODE_START, tour_end + 1))
    steady = {}
    for f in range(CODE_START, tour_end + 1):
        kind, k, step = tstate[f]
        if kind == 'step' and step == len(levels) and (int(tr['log'][f - 1][LOG['row']]) == k) and (tdir / f's_{f:05d}.png').exists():
            steady[k] = f
    W, H = SO.SCREEN
    sheet = Image.new('RGB', (2 * W + 8, n * (H + 8)), (40, 40, 40))
    for k in range(n):
        if k in steady:
            sheet.paste(Image.open(tdir / f's_{steady[k]:05d}.png').convert('RGB'), (0, k * (H + 8)))
        view = res[f'view{k}']['png'] if f'view{k}' in res else res['wrap']['dir'] / f'ev_{ENDING_CUE:02x}_{ending.still_at:05d}.png'
        if Path(view).exists():
            sheet.paste(Image.open(view).convert('RGB'), (W + 8, k * (H + 8)))
    sheet.save(work / 'review.png')
    if te:
        report['ending_strip'] = dict(path=str(work / 'ending_strip.png'), frames=ending.strip(res['wrap'], res['wrap']['dir'] / f's_{SHOT:05d}.png', work / 'ending_strip.png', report['wrap'].get('ending', {})))
    from PIL import ImageDraw
    p2 = tour_press[1]
    strip_frames = list(range(p2 - 1, p2 + 21))
    cols = 6
    th = (W // 2, H // 2)
    strip = Image.new('RGB', (cols * (th[0] + 4), (len(strip_frames) + cols - 1) // cols * (th[1] + 16)), (40, 40, 40))
    for i, f in enumerate(strip_frames):
        im = Image.open(tdir / f's_{f:05d}.png').convert('RGB').resize(th)
        x, y = (i % cols * (th[0] + 4), i // cols * (th[1] + 16))
        strip.paste(im, (x, y + 14))
        kind, k, step = tstate[f]
        ImageDraw.Draw(strip).text((x + 2, y + 1), f'+{f - p2} still{k} ' + (f'step {step}' if kind == 'step' else kind), fill=(255, 255, 0))
    strip.save(work / 'fade_strip.png')
    clip = work / 'clip'
    clip.mkdir()
    for i, f in enumerate(range(CODE_START, tour_end + 1)):
        q = tdir / f's_{f:05d}.png'
        if q.exists():
            (clip / f'frame_{i:05d}.png').write_bytes(q.read_bytes())
    report['review'] = dict(review=str(work / 'review.png'), fade_strip=str(work / 'fade_strip.png'), strip_frames=[strip_frames[0], strip_frames[-1]], clip=str(clip), clip_frames=[CODE_START, tour_end], fps=59.637, stills=[dict(still=f'still{k}', stage=stage_of[f'still{k}'], select_frame=steady.get(k), opening_frame=res[f'view{k}']['shot'] if f'view{k}' in res else f'0x21 + {ending.still_at}') for k in range(n)])
    report['passed'] = bool(ok)
    (work / 'report.json').write_text(json.dumps(report, indent=1, default=str) + '\n')
    print('PASS' if ok else 'FAIL')
    return 0 if ok else 1
if __name__ == '__main__':
    sys.exit(main())
