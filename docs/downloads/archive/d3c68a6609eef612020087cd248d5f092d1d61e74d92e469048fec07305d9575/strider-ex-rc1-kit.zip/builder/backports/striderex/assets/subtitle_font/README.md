# Strider EX caption glyphs

glyphs and the three English marks; review sheet `glyphs.png`). The caption text
is approved too (`manifests/subtitles.json`, `manifests/text_review_decisions.json`).

The cinematic captions (D4a) are CPS-1 sprites. Each glyph is a 16x16 cell,
and `scripts/subtitle_ex.py` bakes a 1-pixel dark outline around it. Most
glyphs come from the arcade's own fonts, read from the stock graphics ROMs at
build time. This directory holds only the glyphs those fonts lack.

| File | What it holds |
|---|---|
| `en_marks.txt` | `'` `:` `"`, which the arcade 8x8 font (SCROLL1 0x7000 + ASCII) lacks. 8x8 grids in the font's pens: `1` face, `0` lower/right edge. Drawn by hand. |
| `en_lower.txt` | The 26 lower-case letters (approved 2026-10-21, section below). 8 wide x 10 tall, pens as `en_marks.txt`; rows 7-9 are the descenders' (g j p q y). |
| `ja_glyphs.txt` | The 152 characters of the draft Japanese text that the arcade 16x16 dialogue font (SCROLL2 0x3620-0x36AA, 137 glyphs) lacks. 16x16 grids, `.` transparent, pens as that font: `1` face, `2` horizontal strokes, `3`-`5` softer pixels. |

A header line gives each glyph's code point, the character and a status:
- `traced-draft`: a guide trace that nobody has cleaned up yet;
- `hand-edited`: cleaned up by hand.

The builder reads these grids as they are, so an edit to a grid ships with the
next build.

## How the Japanese glyphs were made (method, stated plainly)

**No glyph has been hand-cleaned yet.** All 152 are `traced-draft`. They were
made by a tool, `subtitle_ex.py draft-glyphs --guide-font <font>`, run with
Hiragino Kaku Gothic W3, a macOS system font, as the guide:

1. The guide font draws the character at 12 times the target size.
2. The drawing is reduced to a 1-pixel center line (Zhang-Suen thinning).
3. That line is gridded onto the arcade glyph area: columns 1-14 and rows 2-14
   of the 16x16 cell. This leaves room for the outline and matches the arcade
   font's line height.
4. Stair corners are removed, so each stroke is 1 pixel wide and 8-connected.
5. Pens follow the arcade convention: horizontal strokes pen 2, all else pen 1.

The result is a new 1-pixel stroke design at the arcade font's metrics, not a
bitmap the guide font renders at that size. It does follow the guide font's
them to ship (2026-10-10). The notes he decided on:

- **Whether the traced shapes may ship.** Hiragino's license does not allow
  redistributing the font. The output here is a skeleton redrawn on a grid,
  not font data, but it is derived from the font's outlines. The safe route is
  to redraw every glyph by hand, using the trace only as a reference.
- **Cleanup.** Dense kanji are crowded at this size and need hand cleanup.
  Examples: 爆 機 覆 篤 衛 態 影 様 標 極 歯 奥 闇 関 職 確. The arcade's own 艦
  and 戦 show how the original artist thinned such characters.

When a glyph is redrawn by hand, change its status to `hand-edited`. Do not
rerun `draft-glyphs --force`: it would overwrite every edit.

The review sheet shows every new glyph at 1x, 4x, and 4x with the baked
outline, next to the three most similar arcade glyphs by pixel overlap. Build
it with:

    subtitle_ex.py sheet --rom-dir <striderua ROMs> --label-font <a Japanese font> --out <dir>

## Palette

OBJ palette 0x1F. No cinematic uses OBJ palettes 0x10-0x1F: sprite attributes
carry the PC Engine palette, 0-15.

| Pens | Use | Colors |
|---|---|---|
| 1-5 | Japanese face and shading | The striderjr dialogue grays: 0xFEEE, 0xFCCC, 0xFAAA, 0xF888, 0xF666 (SCROLL2 palette 0x0E, read from a striderjr intro dump) |
| 6 | Baked outline | 0xF111 |
| 7 | The English font's own edge shade | 0xF333 |

## English lower case (2026-10-21)

lot better. Let's adopt it in all scripts." The EX's English text is set in mixed
case: the arcade 8x8 capitals, digits and marks, plus `en_lower.txt`, 26 lower
case letters drawn by hand in the font's style (1-pixel face, pen 0 shade to the
right and below, capitals' baseline at row 6). The grids are 8 wide and 10 tall:
of every boss page (upper case with apostrophes beside mixed case) before he
approved it. The approved text keeps its wording; only its case changes, from
each line's approved mixed-case `text` (subtitles) or the mock-up's pages (boss
scenes).

### How the builds use it (2026-10-21)

- **Reading the grids.** `subtitle_ex.read_grids(path, shape)` takes a fixed
  shape for this file (`EN_LOWER_SHAPE`, 10 rows x 8 columns) and refuses any
  other; the square files keep the square rule. `subtitle_ex.en_charset()` is
  the English character set everywhere: the arcade font's, `en_marks.txt`'s
  and these 26.
- **Captions** (`subtitle_ex.py`). Each glyph sits at (1, 1) in its 16x16
  cell with the baked outline, so a descender's face ends on cell row 9, its
  shade on row 10 and its outline on row 11; rows 12-15 stay empty (the build
  refuses a clipped glyph). A caption page leaves room for the descenders
  (`EN_DESCENT` = 2): the line pitch is 13 (was 11) and the last row's
  capitals' outline ends 2 lines higher, so a descender's outline ends on
  line 221, one line above `BOTTOM` (222). Between a descender and the next
  row's capitals there is then one transparent line between the two outlines,
  as between two rows of capitals before. A one-row page's text is 2 lines
  higher, a two-row page's upper row 4. The stage select's pages take the
  (STAGE_SELECT.md "Mixed case").
- **Boss pages** (`boss_scene.py`). The rows are 10 lines tall
  (`EN_ROW_H`), at the stock rows' places (32 lines apart, so nothing meets).
  Each row's stock strip (the black wipe that uncovers it) starts 2 lines
  lower, so it covers the descenders too; the build refuses a strip that does
  not cover its row. The text is in the captions' colors (`EN_COLORS`: the
  font's face pens 1-3 as 0xEEE, 0xCCC, 0xAAA and its edge pen 0 as 0x333)
  instead of the stock dialogue orange.
- **Codes.** A lower-case letter takes no more tiles than a capital: one
  caption cell each (16x16 holds the 10 lines), and the boss pages' rows are
  already 16-line blocks.

("1 mixed"); the ending's PC Engine credits stay in capitals ("2 all caps");
stock arcade text the EX moves or recolors (coin screen, PLAYER READY, GO, the
copyright rows, the boot test screen) stays as the arcade has it ("3 leave as
is").
