"""Reconstruction helper."""
import argparse
import hashlib
import json
from pathlib import Path
import desert_gate as G
import desert_slopes as DS
import respawn_fix as RF

def sha(data):
    return hashlib.sha256(data).hexdigest()
CASES = {'first_walk': (1750, dict(STREX_INPUTS='450-1750:P1_JOYSTICK_RIGHT', SHOTS='700-1700@100')), 'girder': (1820, dict(STREX_INPUTS='450-1800:P1_JOYSTICK_RIGHT;1500-1710:P1_JOYSTICK_UP;1500-1514:P1_BUTTON2', SHOTS='1500-1800@100')), 'rifles': (4000, dict(ACTORS='1', STREX_INPUTS='560-700:P1_JOYSTICK_RIGHT;720-4000@60/14:P1_BUTTON2')), 'tank_jump': (900, dict(WARP='650:2780,1200;651:2780,1200', POKEW='650:ff0ff4=0a1c;650:ff0ff8=043f;651:ff0ff4=0a1c;651:ff0ff8=043f', STREX_INPUTS='701-820:P1_JOYSTICK_RIGHT;701-715:P1_BUTTON2', SHOTS='680-850@10')), 'tank_vertical': (900, dict(WARP='650:2780,1200;651:2780,1200', POKEW='650:ff0ff4=0a1c;650:ff0ff8=043f;651:ff0ff4=0a1c;651:ff0ff8=043f', STREX_INPUTS='701-715:P1_BUTTON2', SHOTS='680-850@10')), 'tank_route': (1100, dict(WARP='650:2670,1151;651:2670,1151', POKEW='650:ff0ff4=09b8;650:ff0ff8=040f;651:ff0ff4=09b8;651:ff0ff8=040f', STREX_INPUTS='701-740:P1_JOYSTICK_RIGHT;701-715:P1_BUTTON2;820-950:P1_JOYSTICK_RIGHT;820-834:P1_BUTTON2', SHOTS='700-1000@20'))}

def probe(a):
    out = a.out.resolve()
    out.mkdir(parents=True, exist_ok=False)
    meta = json.loads((a.build / 'build.json').read_text())
    runtime = json.loads((a.runtime / 'runtime.json').read_text())
    binary = Path(runtime['binary'])
    if sha(binary.read_bytes()) != runtime['binary_sha256']:
        raise ValueError('prepared runtime identity changed')
    machine = G.PARENT[a.set]
    files = {n: (a.build / machine / n).read_bytes() for n in meta['sets'][machine]['files']}
    if any((sha(b) != meta['sets'][machine]['files'][n] for n, b in files.items())):
        raise ValueError('build inventory changed')
    image = RF.compose(files, RF.SETS[machine])
    bank = bytes((files['strex_p6.bin'][i ^ 1] for i in range(1048576)))
    floor = DS.Floor(image, bank, DS.layer_record(image, 5, 0))
    roms = G.stage_sets(a.build.resolve(), a.set, a.hbmame, a.rom_dir.resolve(), out / 'sets')
    rows = []
    for name in a.cases.split(','):
        frames, extra = CASES[name]
        env = dict(G.debug_env(5, 1, frames, inputs=False), MOTION='1', **extra)
        run = out / name
        data = G.run(binary, roms, a.set, run, env, frames)
        motion = []
        lines = (run / 'motion.tsv').read_text().splitlines()
        for line in lines[1:]:
            motion.append(dict(zip(lines[0].split('\t'), line.split('\t'))))
        rows.append(dict(case=name, frames=frames, frame_trace_sha256=sha((run / 'frames.tsv').read_bytes()), motion_sha256=sha((run / 'motion.tsv').read_bytes()), measurements=motion[680:850] if name.startswith('tank') else [], input=env, game_run_completed=len(data) == frames))
        print('captured', machine, name, flush=True)
    report = dict(schema='striderex-desert-feedback-probe/1', machine=machine, source_kit=meta.get('reconstructed_from_verified_export'), input_files=meta['sets'][machine]['files'], runtime={k: runtime[k] for k in ('binary_sha256', 'source_revision', 'board_wait')}, floor_columns={str(x): floor.surfaces(x) for x in range(2650, 3101, 16)}, results=rows, hardware_review_granted=False)
    for r in rows:
        r['input'].pop('STREX_DEBUG_START', None)
    (out / 'report.json').write_text(json.dumps(report, indent=2) + '\n')

def main():
    p = argparse.ArgumentParser(description=__doc__)
    for n in ('build', 'rom-dir', 'runtime', 'hbmame', 'out'):
        p.add_argument('--' + n, type=Path, required=True)
    p.add_argument('--set', choices=sorted(G.PARENT), default='striderus01')
    p.add_argument('--cases', default=','.join(CASES))
    a = p.parse_args()
    if not set(a.cases.split(',')) <= set(CASES):
        p.error('unknown case')
    probe(a)
if __name__ == '__main__':
    main()
