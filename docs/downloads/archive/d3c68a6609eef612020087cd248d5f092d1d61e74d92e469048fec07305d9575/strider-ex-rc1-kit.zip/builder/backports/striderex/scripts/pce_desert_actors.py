"""The PC Engine desert's actors, decoded from a desert checkpoint census"""
import argparse
import hashlib
import json
import sys
from pathlib import Path
import numpy as np
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import huc6280_dis as H
import pce_vdc as V
ROOT = HERE.parents[2]
DUMP_BASE = 851968
FRAMES_TAB, BOXES_TAB = (33650, 33904)
ACTOR_TYPES = 31881
MAP_LISTS = 39936
GEN_TIMERS, GEN_PARAMS, GEN_IDS = (32852, 32935, 33103)
SOLDIER_SINE, SOLDIER_WALK_ANIM = (44329, 44321)
CHECKPOINT_SECTION = {1: 0, 2: 1, 3: 2, 4: 3, 5: 4}

def s8(v):
    return v - 256 if v > 127 else v

def s16(v):
    return v - 65536 if v > 32767 else v

class Census:
    """One desert checkpoint census: the RAM dumps and scene dumps per checkpoint."""

    def __init__(self, path):
        self.path = Path(path)
        self.cps = {}
        for ram in sorted(self.path.glob('pce_*_checkpoint_*_ram_0d0000.bin')):
            k = int(ram.name.split('_checkpoint_')[1][:2])
            frame = int(ram.name.split('_')[1])
            self.cps[k] = dict(frame=frame, prefix=str(ram).replace('_ram_0d0000.bin', ''))
        if sorted(self.cps) != [1, 2, 3, 4, 5]:
            raise SystemExit(f'pce_desert_actors: {self.path}: checkpoints {sorted(self.cps)}, 1-5 expected')
        scenes = sorted(self.path.glob('pce_*_scene.vdc'))
        for k, cp in self.cps.items():
            best = max((s for s in scenes if int(s.name.split('_')[1]) <= cp['frame']), key=lambda s: int(s.name.split('_')[1]), default=None)
            if best is None:
                raise SystemExit(f'pce_desert_actors: no scene dump for checkpoint {k}')
            cp['scene'] = best
        self._ram = {}

    def ram(self, k=1):
        if k not in self._ram:
            self._ram[k] = Path(self.cps[k]['prefix'] + '_ram_0d0000.bin').read_bytes()
        return self._ram[k]

    def reader(self, code_bank, k=1):
        """Logical reads with the chapter's mapping and `code_bank` at 0x8000 (the next at 0xA000)."""
        return H.reader(self.ram(k), DUMP_BASE, {16384: 104, 24576: 105, 32768: code_bank, 40960: code_bank + 1})

    def scene(self, k=1):
        return V.load(self.cps[k]['scene'])

def word(read, a):
    return read(a) | read(a + 1) << 8

def pointer_list(read, table, limit=96):
    """Word pointers from `table` up to the lowest address they point at (the data follows the table)."""
    out, lo, a = ([], 65536, table)
    while a < lo and len(out) < limit:
        p = word(read, a)
        if not 32768 <= p < 49152 or p < table:
            break
        out.append(p)
        lo = min(lo, p)
        a += 2
    return out

def actor_code(census, t):
    """(bank, handler, animation table) of actor type t (pce_desert_spawns.handler, 4-byte entries)."""
    read = census.reader(106)
    off, idx = (read(ACTOR_TYPES + 2 * t), read(ACTOR_TYPES + 2 * t + 1))
    if off & 128:
        raise SystemExit(f'actor type {t:#x} has no handler')
    bank = 104 + 8 + off
    rb = census.reader(bank)
    e = 32768 + 4 * idx
    return (bank, word(rb, e), word(rb, e + 2))

def pieces(read, p):
    out = []
    for i in range(read(p)):
        q = p + 1 + 8 * i
        y, x, pat, attr = (s16(word(read, q)), s16(word(read, q + 2)), word(read, q + 4), word(read, q + 6))
        out.append(dict(dy=y, dx=x, cell=pat >> 1, w=32 if attr & 256 else 16, h=(16, 32, 64, 64)[attr >> 12 & 3], palette=attr & 15, xflip=bool(attr & 2048), yflip=bool(attr & 32768), attr=attr))
    return out

def boxes(read, p):
    return [dict(dy=s8(read(p + 1 + 4 * i)), hh=read(p + 2 + 4 * i), dx=s8(read(p + 3 + 4 * i)), hw=read(p + 4 + 4 * i)) for i in range(read(p))]
CMDS = {255: ('loop', 0), 254: ('back', 1), 253: ('goto_anim', 1), 252: ('set_substate', 1), 251: ('set_state', 1), 250: ('hold', 0), 249: ('psg_sfx', 1), 248: ('psg_sfx_if_near', 1), 247: ('adpcm_sfx', 1), 246: ('adpcm_sfx_if_near', 1)}

def script(read, p, limit=64):
    """An animation script: ticks per step and its steps; each step records its byte index"""
    steps, i = ([], 1)
    while i < limit:
        b = read(p + i)
        if b < 128:
            steps.append(dict(at=i, frame=b & 31, flip=b >> 5 & 3))
            i += 1
        elif b < 132:
            steps.append(dict(at=i, frame=read(p + i + 1), flip=b & 3))
            i += 2
        elif b in CMDS:
            name, n = CMDS[b]
            steps.append(dict(at=i, cmd=name, **{'arg': read(p + i + 1)} if n else {}))
            i += 1 + n
            if name in ('loop', 'back', 'goto_anim', 'hold'):
                break
        else:
            raise SystemExit(f'animation script at {p:#06x}: unknown byte {b:#04x}')
    return dict(ticks=read(p), steps=steps)

def sequence(anim):
    """[(frame, flip)] of a script and the index the sequence continues at after its end; 'back n'"""
    shown = [s for s in anim['steps'] if 'frame' in s]
    end = anim['steps'][-1]
    if end.get('cmd') == 'loop':
        again = 0
    elif end.get('cmd') == 'goto_anim':
        again = ('anim', end['arg'])
    elif end.get('cmd') == 'back':
        target = end['at'] - end['arg']
        again = next((k for k, s in enumerate(shown) if s['at'] == target), None)
        if again is None:
            raise SystemExit(f"animation: back {end['arg']} lands inside a step")
    elif end.get('cmd') == 'hold':
        again = len(shown) - 1
    else:
        raise SystemExit(f'animation: unsupported end {end}')
    return ([(s['frame'], s['flip']) for s in shown], again)

def piece_image(vram, c):
    pat = c['cell']
    if c['h'] == 32:
        pat &= ~2
    if c['h'] == 64:
        pat &= ~6
    if c['w'] == 32:
        pat &= ~1
    img = np.concatenate([np.concatenate([V.sprite_cell(vram, pat + r * 2 + k & 511) for k in range(c['w'] // 16)], 1) for r in range(c['h'] // 16)], 0)
    if c['yflip']:
        img = img[::-1]
    if c['xflip']:
        img = img[:, ::-1]
    return img

def render(vram, pcs):
    """A composition as VCE sprite color indices (16 * palette + pen, 0 transparent) and the"""
    if not pcs:
        return (np.zeros((0, 0), np.int32), (0, 0))
    x0, y0 = (min((c['dx'] for c in pcs)), min((c['dy'] for c in pcs)))
    x1, y1 = (max((c['dx'] + c['w'] for c in pcs)), max((c['dy'] + c['h'] for c in pcs)))
    out = np.zeros((y1 - y0, x1 - x0), np.int32)
    for c in reversed(pcs):
        img = piece_image(vram, c)
        m = img != 0
        out[c['dy'] - y0:c['dy'] - y0 + c['h'], c['dx'] - x0:c['dx'] - x0 + c['w']][m] = 16 * c['palette'] + img[m]
    return (out, (x0, y0))

def frame_key(img, origin):
    return hashlib.sha256(np.asarray(img, np.uint16).tobytes() + repr((img.shape, tuple(origin))).encode()).hexdigest()[:16]

def actor(census, t, k=1):
    """One actor type: code addresses, frames (pieces, image, origin, key), hitboxes, animations."""
    bank, handler, anims_at = actor_code(census, t)
    r6e = census.reader(110, k)
    ftab, btab = (word(r6e, FRAMES_TAB + 2 * (t - 1)), word(r6e, BOXES_TAB + 2 * (t - 1)))
    vram = census.scene(k)['vram']
    frames = []
    for i, p in enumerate(pointer_list(r6e, ftab)):
        pcs = pieces(r6e, p)
        img, org = render(vram, pcs)
        frames.append(dict(index=i, at=p, pieces=pcs, image=img, origin=org, key=frame_key(img, org)))
    bxs = [boxes(r6e, p) for p in pointer_list(r6e, btab)]
    rb = census.reader(bank, k)
    anims = [dict(index=i, at=p, **script(rb, p)) for i, p in enumerate(pointer_list(rb, anims_at))]
    return dict(type=t, bank=bank, handler=handler, anim_table=anims_at, frame_table=ftab, box_table=btab, frames=frames, boxes=bxs, anims=anims)

def sprite_palettes(census):
    """The 16 sprite palettes (VCE words), checked identical in every checkpoint's scene dump."""
    pals = {k: census.scene(k)['pal'][256:512].reshape(16, 16) for k in census.cps}
    first = pals[1]
    for k, p in pals.items():
        if not (p == first).all():
            raise SystemExit(f'pce_desert_actors: the sprite palettes of checkpoint {k} differ from checkpoint 1')
    return [[int(v) for v in row] for row in first]

def map_list(census, section):
    """The section's map-list spawn records (stop at the first 0x3FFF X sentinel)."""
    read = census.reader(111)
    a, out = (word(read, MAP_LISTS + 2 * section), [])
    for _ in range(64):
        b = [read(a + i) for i in range(8)]
        x, y = (b[0] | b[1] << 8, b[2] | (b[3] & 63) << 8)
        if x >= 16383 or (x, y) == (0, 0):
            break
        out.append(dict(x=x, y=y, flags=b[3] >> 6, slot=b[4], once_id=b[5], type=b[6], param=b[7]))
        a += 8
    return out
GEN_SHAPES = {33144: 'a944a00091', 32901: 'bda780', 32836: 'bd5480', 33087: 'bd4f8185', 32912: 'c906', 32926: 'c912'}

def generator(census):
    """Object 0x0F: its timer table (ticks), parameter cycle, and the two once-id lists (by the"""
    read = census.reader(108)
    for at, want in GEN_SHAPES.items():
        if bytes((read(at + i) for i in range(len(want) // 2))) != bytes.fromhex(want):
            raise SystemExit(f'pce_desert_actors: generator code at 0x6C:{at:#06x} has an unexpected shape')
    return dict(timers=[read(GEN_TIMERS + i) for i in range(16)], params=[read(GEN_PARAMS + i) for i in range(18)], ids=[[read(word(read, GEN_IDS + 2 * p) + i) for i in range(6)] for p in range(2)])

def soldier_tables(census):
    """The rifle soldier's walk tables (bank 0x72/0x73): the 16-direction velocity table (8.8,"""
    read = census.reader(114)
    return dict(sine=[s16(word(read, SOLDIER_SINE + 2 * i)) for i in range(16)], walk_anim=[read(SOLDIER_WALK_ANIM + i) for i in range(8)])
HANDLER_SHAPES = {'bz_colflags': (114, 42650, 'a9??a00b9134', 1), 'bz_aim': (114, 42701, 'a9??a01a9134', 1), 'bz_fire': (114, 42753, 'a9??a01a9134', 1), 'bz_child': (114, 42787, 'a9??a0009136', 1), 'bz_rocket_dy': (114, 42799, 'a9??20695a', -1), 'bz_rocket_dx': (114, 42804, 'a9??202456', 1), 'bz_knock': (114, 42991, 'a9??a01a9134', 1), 'bz_knock_vx': (114, 43036, '????', 1), 'bz_knock_vx_hi': (114, 43038, '????', 1), 'bz_score': (114, 43069, 'a9??a2??20a64e', 1), 'rk_colflags': (114, 43119, 'a9??a00b9134', 1), 'rk_vx_hi': (114, 43188, 'a9??c89134', 1), 'rk_right': (114, 43240, '38ad2f2de9??ad302de9??10', 2), 'rk_left': (114, 43255, '38ad2f2de9??ad302de9??30', 2), 'rk_hit': (114, 43279, 'add032d0', 0), 'mn_colflags': (114, 43507, 'a9??a00b9134', 1), 'mn_dy': (114, 43559, 'a9??20885ac9', -1), 'mn_tol_y': (114, 43564, 'c9??b00f', 1), 'mn_dx': (114, 43568, 'a9??20245620d35a', 1), 'mn_tol_x': (114, 43576, 'c9??b003', 1), 'mn_warn': (114, 43596, 'a9??a01a9134', 1), 'mn_blast': (114, 43624, 'a9??a01a9134', 1), 'mn_sfx': (114, 43630, 'a9??20886b', 1), 'mn_right': (114, 43671, '38ad2f2de9??ad302de9??10', 2), 'mn_left': (114, 43684, '38ad2f2de9??ad302de9??30', 2), 'scr_test': (104, 22754, '20ef58c9??b005202b59c9??60', 1), 'scr_cy': (104, 22768, 'ad712d69??', 1), 'scr_cx': (104, 22828, 'ad742d69??', 1), 'dr_colflags': (114, 38137, 'a9??a00b9134', 1), 'dr_entry_bit': (114, 38227, '89??d003', 1), 'dr_entry_speed': (114, 38262, 'a9??a01c9134', 1), 'dr_entry_anim': (114, 38268, 'a9??a00e9134', 1), 'dr_entry_exit_dx': (114, 38274, '20c957c9??b003', 1), 'dr_band_top': (114, 38292, 'e9??ad2e2de9??10', 2), 'dr_band_bottom': (114, 38313, 'e9??ad2e2de9??30', 2), 'dr_band_left': (114, 38334, 'e9??ad302de9??10', 2), 'dr_band_right': (114, 38355, 'e9??ad302de9??30', 2), 'dr_home_timer': (114, 38401, 'a9??a01a9134', 1), 'dr_home_anim': (114, 38407, 'a9??a00e9134', 1), 'dr_close_dx': (114, 38428, 'c9??b00a', 1), 'dr_close_dy': (114, 38435, 'c9??b003', 1), 'dr_turn_pos': (114, 38466, 'c9??300aa9??', 1), 'dr_turn_neg': (114, 38474, 'c9??1002a9??', -1), 'dr_home_speed': (114, 38485, 'a9??a01c9134', 1), 'dr_glide_speed': (114, 38498, 'a9??a01c9134', 1), 'dr_glide_anim': (114, 38504, 'a9??a00e9134', 1), 'dr_glide_timer': (114, 38510, 'a9??a01a9134', 1), 'dr_box_top': (114, 38585, 'e9??ad2e2de9??10', 2), 'dr_box_bottom': (114, 38600, 'e9??ad2e2de9??30', 2), 'dr_box_left': (114, 38615, 'e9??ad302de9??10', 2), 'dr_box_right': (114, 38630, 'e9??ad302de9??30', 2), 'dr_vy_phase': (114, 38648, '69??', 1), 'dr_death_timer': (114, 38924, 'a9??a01a9134', 1), 'dr_score': (114, 39164, 'a9??a2??20a64e', 1), 'dr_item_bits': (114, 39178, '29??f0', 1), 'dr_item_type': (114, 39188, 'a9??a0009136', 1), 'dr_item_dy': (114, 39215, 'a9??a02c9136', -1), 'dr_item_dx': (114, 39221, 'a9??a02d9136', -1), 'dr_item_open': (114, 39303, 'c9??f001', 1), 'it_fall': (114, 33007, 'a9??206557c9??9005a9??4cda56', 1), 'wm_spawn_dy': (108, 33730, '69??8d312dad722d69??', 2), 'wm_right_dx': (108, 33773, '69??8d332dad752d69??', 2), 'wm_left_dx': (108, 33791, '69??8d332dad752d69??', 2), 'wm_kind_at': (108, 33873, 'a0??9136', 1), 'wm_rank_mask': (108, 33696, '29??', 1), 'wm_type': (108, 33838, 'a9??a00091', 1), 'sw_colflags': (114, 41960, 'a9??a00b9134', 1), 'sw_surface': (114, 42051, 'a9??a01a9134', 1), 'sw_period': (114, 42127, 'a9??a0299134', 1), 'sw_stop_dx': (114, 42158, 'c9??1007', 1), 'sw_probe_a': (114, 42172, 'a9??202456a2??a8a9??206557c9??d0', 1), 'sw_probe_b': (114, 42189, 'a9??202456a2??a8a9??206557c9??d0', 1), 'sw_child_type': (114, 42255, 'a9??a0009136', 1), 'sw_child_dy': (114, 42267, 'a9??20695a', -1), 'sw_child_dx': (114, 42272, 'a9??202456', 1), 'sw_child_k': (114, 42291, 'a9??a0249136', 1), 'sw_follow': (114, 42225, 'c9??f001', 1), 'sw_hits': (114, 42354, 'c9??b001', 1), 'sw_death_timer': (114, 42513, 'a9??a01a9134', 1), 'sw_score': (114, 42585, 'a9??a2??20a64e', 1), 'rb_colflags': (114, 39375, 'a9??a00b9134', 1), 'rb_layer': (114, 39381, 'a9??a00a9134', 1), 'rb_wait0': (114, 39451, 'a9??a01a9134', 1), 'rb_fire_dy': (114, 39485, '20a557c9??b0', 1), 'rb_walk': (114, 39584, 'a9??a01a9134', 1), 'rb_fire_dy2': (114, 39610, 'c9??b0', 1), 'rb_wait1': (114, 39663, 'a9??a01a9134', 1), 'rb_wall_r': (114, 39699, 'a2??a0??a9??207757c9??90', 1), 'rb_drop_r': (114, 39712, 'a2??a0??a9??206557c9??b0', 1), 'rb_wall_l': (114, 39727, 'a2??a0??a9??208057c9??90', 1), 'rb_drop_l': (114, 39740, 'a2??a0??a9??206557c9??b0', 1), 'rb_speed': (114, 39771, 'a9??8002a9??', 1), 'rb_hold': (114, 39789, 'a9??a01a9134', 1), 'rb_rest': (114, 39826, 'a9??a01a9134', 1), 'rb_step_sfx': (114, 39869, 'a9??9134a9??20295c', 1), 'rb_spin_period': (114, 40130, 'a9??9134', 1), 'rb_aim_right': (114, 40171, 'c9??f001', 1), 'rb_aim_left': (114, 40191, 'c9??f001', 1), 'rb_snap': (114, 40210, 'a2??a0??a9??206557', 1), 'rb_snap_k': (114, 40219, '38e9??c9??1002a9??c9??3002a9??', 1), 'rb_vel_probe': (114, 40645, 'a2??a0??a9??206557', 1), 'lg_dx_a': (114, 40259, 'a9??202456', -1), 'lg_dy': (114, 40267, 'a9??20da56', 1), 'lg_dx_b': (114, 40463, 'a9??202456', -1), 'lg_probe': (114, 40272, 'a2??a0??a9??206557c9??90', 1), 'lg_probe2': (114, 40285, 'a2??a0??a9??206557', 1), 'lgb_probe': (114, 40476, 'a2??a0??a9??206557c9??90', 1), 'lgb_probe2': (114, 40489, 'a2??a0??a9??206557', 1), 'rb_beam': (114, 40904, 'a9??a0009136a9??a0249136', 1), 'rb_beam_dy': (114, 40950, '18a004b13669??9136c8b13669??', 1), 'rb_beam_dx_r': (114, 40974, '18a006b13669??', 1), 'rb_beam_dx_l': (114, 40992, '18a006b13669??', -1), 'rb_beam_sfx': (114, 41008, 'a9??20295c', 1), 'rb_step_gate': (114, 39851, 'a018b134c9??d013a01cb134f0043a913460', 1), 'sfx_near': (114, 23593, '4820a557c9??b00b20c957c9??b004684c886b', 1), 'anim_psg': (114, 21704, '1ad010b13020886ba010b1341a1a91344cf953', 0), 'rb_hits': (114, 41032, 'c9??b001', 1), 'rb_knock': (114, 41070, 'a9??a01a9134', 1), 'rb_debris': (114, 41098, 'a9??a0009136', 1), 'rb_score': (114, 41235, 'a9??a2??20a64e', 1), 'bm_life': (114, 41376, 'a9??a01a9134', 1), 'bm_period': (114, 41416, 'a9??9134', 1), 'bm_part': (114, 41739, 'a9??a0009136a9??a0019136a002b1569136a9??a00b9136', 1), 'fl_colflags': (116, 44643, 'a9??a00b9134', 1), 'fl_burst_anim': (116, 44703, 'a9??a00e9134', 1), 'fl_period': (116, 44709, 'a9??a01a9134', 1), 's3_wait': (106, 39382, 'a2??20ae76c9??f005c9??f001', 1), 'jp_colflags': (116, 35370, 'a9??a00b9134', 1), 'jp_layer': (116, 35376, 'a9??a00a9134', 1), 'jp_gunner': (116, 36242, 'a9??a0009136', 1), 'jp_wait': (116, 35456, 'a9??a01a9134', 1), 'jp_wait_anim': (116, 35462, 'a9??a00e9134', 1), 'jp_dy': (116, 35498, '20a557c9??90', 1), 'jp_charge_t': (116, 35523, 'a9??a01a9134', 1), 'jp_reverse_t': (116, 35756, 'a9??a01a9134', 1), 'jp_charge_acc_r': (116, 35548, 'b13469??9134c8b13469??9134', 2), 'jp_charge_max_r': (116, 35564, 'b134e9??c8b134e9??30', 2), 'jp_charge_acc_l': (116, 35591, 'b13469??9134c8b13469??9134', 2), 'jp_charge_max_l': (116, 35607, 'b134e9??c8b134e9??10', 2), 'jp_brake_t': (116, 35651, 'a9??a01a9134', 1), 'jp_brake_r': (116, 35676, 'b134e9??9134c8b134e9??9134', 2), 'jp_brake_l': (116, 35705, 'b134e9??9134c8b134e9??9134', 2), 'jp_rev_acc_l': (116, 35781, 'b13469??9134c8b13469??9134', 2), 'jp_rev_max_l': (116, 35797, 'b134e9??c8b134e9??30', 2), 'jp_rev_acc_r': (116, 35824, 'b13469??9134c8b13469??9134', 2), 'jp_rev_max_r': (116, 35840, 'b134e9??c8b134e9??10', 2), 'jp_bounce_t': (116, 35994, 'a9??a01a9134', 1), 'jp_bounce_anim': (116, 36000, 'a9??a00e9134', 1), 'jp_bounce_n': (116, 36039, 'c9??b0', 1), 'jp_turn_t': (116, 36087, 'a9??a01a9134', 1), 'jp_turn_anim': (116, 36093, 'a9??a00e9134', 1), 'jp_ahead_r': (116, 36132, '69??8d2f2dc8b13469??8d302d', 2), 'jp_ahead_l': (116, 36166, '69??8d2f2dc8b13469??8d302d', 2), 'jp_wall_r': (116, 36204, 'a2??a0??a9??207757c9??10', 1), 'jp_wall_l': (116, 36219, 'a2??a0??a9??208057c9??10', 1), 'jp_hits': (116, 36285, 'c9??b001', 1), 'jp_death_anim': (116, 36549, 'a9??a00e9134', 1), 'jp_death_t': (116, 36555, 'a9??a01a9134', 1), 'jp_death_v_r': (116, 36584, 'a9??a0149134a9??c89134', 2), 'jp_death_v_l': (116, 36597, 'a9??a0149134a9??c89134', 2), 'jp_debris': (116, 36318, 'a9??a0009136', 1), 'jp_final': (116, 36664, 'a9??20d58da9??20d58d', 1), 'jp_score': (116, 36680, 'a9??a2??20a64e', 1), 'jp_dead_once': (116, 36687, 'a9??209a76', 1), 'jp_wreck_anim': (116, 36723, 'a9??a00e9134', 1), 'gn_layer': (116, 36767, 'a9??a00a9134', 1), 'gn_parent_dead': (116, 36787, 'c9??f0', 1), 'gn_no_fire_frame': (116, 36835, 'c9??d0', 1), 'gn_shot_gap': (116, 36855, 'a9??9134', 1), 'gn_burst': (116, 36884, 'c9??90', 1), 'gn_pause': (116, 36891, 'a9??a02a9134', 1), 'gn_turn_frame': (116, 36908, 'c9??d00aa9??9134', 1), 'gn_aim_period': (116, 36932, 'a9??9134', 1), 'gn_bullet': (116, 37025, 'a9??a0009136', 1), 's1_delay': (106, 38820, 'a9??8d0c34', 1), 's1_portrait': (106, 38889, 'a2??20ae76c9??f001', 1), 's1_go': (106, 38910, 'a9??a2??20a176a9??a2??20a176', 1), 's1_open': (106, 38924, 'a9??8d0c34a9??8d0d34', 1), 's1_wait': (106, 38982, 'a2??20ae76c9??f001', 1), 'pit_n': (106, 39838, 'c9??9001', 1), 'pit_period': (106, 39852, 'a9??8d2134', 1), 'pit_y': (106, 39879, 'a9??8d8c2da9??8d8d2d', 2), 'pit_x': (106, 39891, 'a9??8d8e2da9??8d8f2d', 2), 'pit_w': (106, 39950, 'e0??90', 1), 'pit_h': (106, 39973, 'e0??90', 1), 'of_layer': (116, 32916, 'a9??a00a9134', 1), 'of_go': (116, 32978, '20a976c9??f001', 1), 'of_wait_anim': (116, 32992, 'a9??a00e9134', 1), 'of_wait_t': (116, 32998, 'a9??a01a9134', 1), 'of_point_anim': (116, 33020, 'a9??a00e9134', 1), 'of_point_t': (116, 33026, 'a9??a01a9134', 1), 'of_ring_anim': (116, 33050, 'a9??a00e9134', 1), 'of_ring_t': (116, 33056, 'a9??a01a9134', 1), 'of_sink_v': (116, 33083, 'a9??a0129134c8a9??9134', 2), 'of_floor': (116, 33102, 'e9??c8b134e9??10', 2), 'of_floor_set': (116, 33114, 'a9??a0049134a9??c89134', 2), 'of_morph_anim': (116, 33139, 'a9??a00e9134', 1), 'of_morph_t': (116, 33145, 'a9??a01a9134', 1), 'of_col': (116, 33163, 'a9??a00b9134', 1), 'of_idle_anim': (116, 33187, 'a9??a00e9134', 1), 'of_idle_t': (116, 33193, 'a9??a01a9134', 1), 'of_pat_end': (116, 33212, 'c9??d0', 1), 'of_clack_anim': (116, 33384, 'a9??a00e9134', 1), 'of_clack_t': (116, 33390, 'a9??a01a9134', 1), 'of_leap_anim': (116, 33415, 'a9??a00e9134', 1), 'of_leap_v': (116, 33421, 'a9??a0129134a9??c89134', 2), 'of_leap_col': (116, 33432, 'a9??a00b9134', 1), 'of_leap_g': (116, 33443, '69??9134c8b13469??', 2), 'of_leap_floor': (116, 33462, 'e9??c8b134e9??10', 2), 'of_land_col': (116, 33491, 'a9??a00b9134', 1), 'of_burst_n': (116, 33506, 'a9??a01b9134', 1), 'of_burst_anim': (116, 33512, 'a9??a00e9134', 1), 'of_burst_t': (116, 33518, 'a9??a01a9134', 1), 'of_arm': (116, 33527, 'a2??20ae7609??a2??20a176', 1), 'of_ball_anim': (116, 33569, 'a9??a00e9134', 1), 'of_ball_t': (116, 33575, 'a9??a01a9134', 1), 'of_grain': (116, 33638, 'a9??a0009136a9??a0249136', 1), 'of_ball': (116, 33714, 'a9??a0009136a9??a0249136a9??20695aa9??20645a', 1), 'of_hits': (116, 33764, 'c9??b001', 1), 'of_die_v': (116, 33835, 'a9??a0129134a9??c89134', 2), 'of_score': (116, 33892, 'a9??a2??20a64e', 1), 'of_flash': (116, 34178, 'a9??9dcb2be8a9??9dcb2b', 1), 'of_flash_n': (116, 34190, 'e0??d0', 1), 'of_blink': (116, 34199, 'ad0a2d89??f0', 1), 'gr_layer': (116, 34511, 'a9??a00a9134', 1), 'gr_life': (116, 34582, 'a9??a01a9134', 1), 'gr_anim': (116, 34588, 'a9??a00e9134', 1), 'gr_g': (116, 34643, '69??9134c8b13469??', 2), 'bl_col': (116, 34747, 'a9??a00b9134', 1), 'bl_anim': (116, 34826, 'a9??a00e9134', 1), 'bl_v': (116, 34832, 'a9??a0129134a9??c89134', 2), 'bl_g': (116, 34848, '69??9134c8b13469??', 2), 'bl_ring_t': (116, 34876, 'a9??a01a9134', 1), 'bl_ring_anim': (116, 34882, 'a9??a00e9134', 1), 'bl_needle': (116, 34941, 'a9??a0009136a9??a0249136', 1), 'nd_col': (116, 35038, 'a9??a00b9134', 1), 'nd_life': (116, 35115, 'a9??a01a9134', 1), 'nd_g': (116, 35177, '69??9134c8b13469??', 2), 'pl_go': (116, 42683, '20a976c9??f001', 1), 'pl_wait': (116, 42703, 'a9??a01a9134', 1), 'pl_phases': (116, 42789, 'c9??9001', 1), 'pl_left_x': (116, 42975, 'a9??8d2f2da9??8d302d', 2), 'pl_left_w': (116, 43010, 'c9??9001', 1), 'pl_line_y': (116, 43015, 'a9??8d2d2da9??8d2e2d', 2), 'pl_tol_lo': (116, 43083, 'c9??1001', -1), 'pl_tol_hi': (116, 43088, 'c9??3001', 1), 'pl_right_x': (116, 43115, 'a9??8d2f2da9??8d302d', 2), 'pl_right_w': (116, 43150, 'c9??9001', 1), 'pl_right_y': (116, 43247, '0a49ff1a1869??60', 1), 'pl_lim_l': (116, 43270, 'c9??90', 1), 'pl_lim_r': (116, 43278, 'c9??b0', 1), 'pl_arm_bit': (116, 43435, '89??f00f29??', 1), 'pl_decay': (116, 43458, 'f0043a3a9134', 0), 'cam_step': (104, 29551, 'e9??ad4233e9??30', 2), 'cam_step_neg': (104, 29528, 'e9??ad4233e9??10', 2), 's4_portrait': (106, 39731, 'a2??20ae76c9??f001', 1), 's4_go': (106, 39749, 'a9??a2??20a176a9??a2??20a176', 1), 's4_wait': (106, 39784, 'a2??20ae76c9??f001', 1), 's4_delay': (106, 39799, 'a9??8d0c34', 1), 's4_clear': (106, 39818, 'a9??8d8a2c', 1), 'tk_home_y': (116, 37484, 'a9??a0049134a9??c89134', 2), 'tk_home_x': (116, 37495, 'a9??a0069134a9??c89134', 2), 'tk_go': (116, 37583, '20a976c9??f001', 1), 'tk_wait2': (116, 37597, 'a9??a01a9134', 1), 'tk_wait3': (116, 37619, 'a9??a01a9134', 1), 'tk_rise_cmd': (116, 37625, 'a9??a02b9134a02c9134a02d9134', 1), 'tk_colflags': (116, 37649, 'a9??a00b9134', 1), 'tk_pause_r': (116, 37672, 'a9??a01a9134', 1), 'tk_left_lim': (116, 37720, '38ad2f2de9??ad302de9??10', 2), 'tk_left_acc': (116, 37736, '18a014b13469??9134c8b13469??9134', 2), 'tk_left_max': (116, 37752, '38a014b134e9??c8b134e9??30', 2), 'tk_pause_l': (116, 37793, 'a9??a01a9134', 1), 'tk_right_lim': (116, 37841, '38ad2f2de9??ad302de9??30', 2), 'tk_right_acc': (116, 37857, '18a014b13469??9134c8b13469??9134', 2), 'tk_right_max': (116, 37873, '38a014b134e9??c8b134e9??10', 2), 'tk_off_y': (116, 37900, '38a9??a004f1348d802da9??c8f1348d812d', 2), 'tk_off_x': (116, 37918, '38a9??a006f1348d822da9??c8f1348d832d', 2), 'cn_wait': (116, 37968, 'a9??a0119134', 1), 'cn_subs': (116, 37984, 'a018b134c9??d0034c7394c9??d0034c9294', 1), 'cn_fire': (116, 38003, 'a9??a02e9134a9??a0119134a9??a02c9134', 1), 'mt_fire': (116, 38034, 'a9??a02e913462a02a9134a9??a0119134a9??a02c9134', 1), 'mt_n': (116, 38074, 'c9??d0df', 1), 'tu_sub': (116, 38104, 'a018b134c9??f001', 1), 'tu_period': (116, 38119, 'a9??a01c9134', 1), 'tu_burst': (116, 38158, 'a9??a01c9134', 1), 'tu_cmd': (116, 38173, 'a9??a02d9134', 1), 'tu_screen': (116, 38203, '38ad2f2de9??ad302de9??10', 2), 'pt0_init': (116, 38462, 'a9??a0009134a9??a0019134a9??a0039134a9??a00a9134', 1), 'pt2_init': (116, 38493, 'a9??a0009134a9??a0019134a9??a0039134a9??a00a9134', 1), 'pt1_init': (116, 38524, 'a9??a0009134a9??a0019134a9??a0039134a9??a00a9134', 1), 'pt3_init': (116, 38555, 'a9??a0009134a9??a0019134a9??a0039134a9??a00a9134', 1), 'pt0_dy': (116, 38852, '18a004b15669??9134c8b15669??9134', 2), 'pt0_dx': (116, 38868, '18a006b15669??9134c8b15669??9134', 2), 'pt2_dy': (116, 38892, '18a004b15669??9134c8b15669??9134', 2), 'pt2_dx': (116, 38908, '18a006b15669??9134c8b15669??9134', 2), 'pt1_dy': (116, 38932, '18a004b15669??9134c8b15669??9134', 2), 'pt1_dx': (116, 38948, '18a006b15669??9134c8b15669??9134', 2), 'pt3_dy': (116, 38972, '18a004b13669??9134c8b13669??9134', 2), 'pt3_dx': (116, 38988, '18a006b13669??9134c8b13669??9134', 2), 'pt0_cmd': (116, 39048, 'a02bb156c9??f005c9??f007', 1), 'pt0_rise': (116, 39079, '18a012b13469??9134c8b13469??9134c9??3001', 1), 'pt0_lower': (116, 39113, '18a012b13469??9134c8b13469??9134', 2), 'pt2_cmd': (116, 39290, 'a02cb156c9??f005c9??f007', 1), 'pt2_rise': (116, 39321, '18a012b13469??9134c8b13469??9134c9??3001', 1), 'pt1_cmd': (116, 39586, 'a02db156c9??f005c9??f007', 1), 'pt1_rise': (116, 39617, '18a012b13469??9134c8b13469??9134c9??3001', 1), 'pt0_bit': (116, 39037, 'a029b15689??f003', 1), 'pt2_bit': (116, 39279, 'a029b15689??f003', 1), 'pt1_bit': (116, 39575, 'a029b15689??f003', 1), 'pt3_bit': (116, 39908, 'a029b15689??f009a9??a0039134', 1), 'cn_cmds': (116, 39426, 'a02cb156c9??f009c9??f00bc9??f00b', 1), 'cn_recoil': (116, 39465, 'a9??a0179134a9??a0039134', 1), 'cn_back': (116, 39489, 'c9??f001', 1), 'tu_cmds': (116, 39719, 'a02db156c9??f02fc9??f031', 1), 'tu_aim_t': (116, 39742, 'a9??a0179134207d58c9??b012', 1), 'tu_fire_t': (116, 39808, 'a9??a0179134', 1), 'pt3_rise': (116, 39974, '18a012b13469??9134c8b13469??9134c9??3001', 1), 'pt3_lower': (116, 40024, '18a012b13469??9134c8b13469??9134', 2), 'pt3_fire_t': (116, 40149, 'a9??a0179134', 1), 'pt3_raised': (116, 40665, 'a002b13489??f004a9??', 1), 'pu_far': (116, 38728, '20c957c9??9001', 1), 'pu_near': (116, 38736, 'c9??b001', 1), 'pu_screen': (116, 38835, '38ad2f2de9??ad302de9??10', 2), 'b3_shot': (116, 40477, 'a9??a0009136a9??20695aa9??20645aa9??a0149136a9??c89136a9??a0129136a9??c89136', 1), 'sh_shot': (116, 40205, 'a9??a0009136a9??a0249136a9??20695aa9??20645aa9??a0149136a9??c89136a9??a0129136a9??c89136', 1), 'cs_type': (116, 40334, 'a9??a0009136a9??a0249136', 1), 'tu_type': (116, 40256, 'a9??a0009136', 1), 'mt_shot': (116, 40418, 'a9??a0009136a9??a0249136a9??20695aa9??20645aa02ab156a01c9136a9??a0149136a9??c89136a9??a0129136a9??c89136', 1), 'tk_dead': (116, 40516, 'a029b13429??c9??f001', 1), 'hit_slash': (116, 40558, 'add03230', 0), 'tk_die_t': (116, 40723, 'a9??a01a9134', 1), 'tk_sink': (116, 40786, 'a9??a0129134a9??c89134', 2), 'tk_score': (116, 40849, 'a9??a2??20a64e', 1), 'tk_blink': (116, 41162, 'ad0a2d89??f011', 1), 'tk_restore': (116, 41123, 'bde730dd4b2bd006e8e0??d0f3', 1), 'tk_bob_y': (116, 41382, '18ad312d69??8d312dad322d69??8d322d', 2), 'rd_dx': (116, 41468, '18ad2f2d69??8d2f2dad302d69??', 2), 'rd_w': (116, 41491, 'c9??9001', 1), 'rd_dy': (116, 41534, '18ad2d2d69??8d2d2dad2e2d69??', 2), 'rd_h': (116, 41557, 'c9??9001', 1), 'rd_tol_lo': (116, 41572, 'c9??1001', -1), 'rd_tol_hi': (116, 41577, 'c9??3001', 1), 'rd_p1': (116, 41599, 'ad2f2dc9??b00aa9??38ed2f2da2??801c', 1), 'rd_p2': (116, 41616, 'c9??b006a9??a2??8012', 1), 'rd_p3': (116, 41626, 'c9??b00aa9??38ed2f2da2??8004', 1), 'rd_p4': (116, 41640, 'a9??a2??1869??', 1), 'sh_init': (116, 41733, 'a9??a00b9134a9??a00a9134', 1), 'sh_right': (116, 41817, '38ad2f2de9??ad302de9??10', 2), 'sh_left': (116, 41832, '38ad2f2de9??ad302de9??30', 2), 'cs_list': (116, 41889, 'a9??a00a9134', 1), 'cs_anim': (116, 41932, 'a9??a00e9134', 1), 'cs_g': (116, 41958, '18a012b13469??9134c8b13469??9134', 2), 'cs_free': (116, 41976, '38ad2d2de9??ad2e2de9??10', 2), 'mt_init': (116, 42035, 'a9??a00b9134a9??a00a9134', 1), 'mt_anim': (116, 42092, 'a9??a00e9134', 1), 'mt_top': (116, 42118, '38ad2d2de9??ad2e2de9??30', 2), 'mt_turn': (116, 42138, 'a9??a00b9134a002b13409??9134', 1), 'mt_floor': (116, 42170, 'a2??a0??a9??20535cc9??1007', 1), 'mt_g': (116, 42210, '18a012b13469??9134c8b13469??9134', 2), 'mt_max': (116, 42226, '38a012b134e9??c8b134e9??30', 2), 'mt_free': (116, 42251, '38ad2d2de9??ad2e2de9??10', 2), 'mt_hit': (116, 42283, 'add032d001', 0), 'cm_list': (116, 42501, 'a9??a00a9134', 1), 'cm_go': (116, 42540, '20a976c9??f001', 1), 'cm_t1': (116, 42560, 'a9??a01a9134', 1), 'cm_walk': (116, 42582, 'a9??a00e9134a9??a01a9134a9??a0149134a9??c89134', 1), 'st_list': (116, 44470, 'a9??a00a9134', 1), 'st_x': (116, 44511, 'ad742d29??8d332d', 1), 'st_x2': (116, 44529, '29??0d332d', 1)}
STEP5_TABLES = {'rb_frames': (40202, 8, 40113, 'bd0a9d'), 'lg_a': (40409, 32, 40319, 'bdd99d'), 'lg_b': (40613, 32, 40523, 'bda59e'), 'rb_vel': (40770, 128, 40741, 'bd429f'), 'rb_heading': (41014, 2, 40921, 'bd36a0'), 'rb_knock_v': (41085, 4, 41057, 'bd7da0'), 'bm_step': (41805, 16, 41801, 'bd4da3'), 'bm_frame': (41862, 16, 41830, 'bd86a3')}
DRONE_VELOCITY, DRONE_ENTRY_DIR, DRONE_KNOCK = (38764, 38379, 38935)
ATAN, ATAN_CODE = (20069, 20021)
RANK_START, RANK_FIRST, RANK_PERIOD, RANK_STRIP = (20804, 20807, 20813, 33702)

def handler_constants(census, k=1):
    """The handlers' constants (HANDLER_SHAPES), each read where the code's bytes match (in checkpoint k's"""
    out = {}
    for name, (bank, at, pat, size) in HANDLER_SHAPES.items():
        read = census.reader(bank, k)
        got = bytes((read(at + i) for i in range(len(pat) // 2)))
        ops = [i for i in range(len(pat) // 2) if pat[2 * i:2 * i + 2] == '??']
        if any((got[i] != int(pat[2 * i:2 * i + 2], 16) for i in range(len(pat) // 2) if i not in ops)):
            raise SystemExit(f'pce_desert_actors: {name} at {bank:#04x}:{at:#06x} has an unexpected shape ({got.hex()})')
        vals = [got[i] for i in ops]
        if size == 2:
            out[name] = s16(vals[0] | vals[1] << 8)
        elif size == -1:
            out[name] = [s8(v) for v in vals] if len(vals) > 1 else s8(vals[0])
        elif size == 0:
            out[name] = True
        else:
            out[name] = vals if len(vals) > 1 else vals[0]
    k = out
    bcd_lo, bcd_mid = k.pop('bz_score')
    k['bz_score_bcd'] = bcd_mid << 8 | bcd_lo
    lo, hi = (k.pop('bz_knock_vx'), k.pop('bz_knock_vx_hi'))
    k['bz_knock_vx'] = [s16(lo[i] | hi[i] << 8) for i in range(2)]
    k['scr_h'] = k.pop('scr_test')
    if k['scr_h'][0] != k['scr_h'][1]:
        raise SystemExit('pce_desert_actors: the on-screen test has two different extents')
    k['scr_h'] = k['scr_h'][0]
    k['rk_vx'] = k.pop('rk_vx_hi') << 8
    k['it_mask'], k['it_rest'], k['it_fall'] = k['it_fall']
    for name in ('sw_probe_a', 'sw_probe_b'):
        dx, dy, mask, want = k.pop(name)
        k[name] = dict(dx=dx, dy=s8(dy), mask=mask, want=want)
    lo, mid = k.pop('sw_score')
    k['sw_score_bcd'] = mid << 8 | lo
    bcd_lo, bcd_mid = k.pop('dr_score')
    k['dr_score_bcd'] = bcd_mid << 8 | bcd_lo
    for name in ('dr_turn_pos', 'dr_turn_neg'):
        if k[name][0] != k[name][1]:
            raise SystemExit(f'pce_desert_actors: {name} {k[name]}')
        k[name] = k[name][0]
    for name in ('rb_wall_r', 'rb_drop_r', 'rb_wall_l', 'rb_drop_l', 'lg_probe', 'lgb_probe', 'rb_snap', 'rb_vel_probe', 'lg_probe2', 'lgb_probe2'):
        v = k.pop(name)
        k[name] = dict(dy=s8(v[0]), dx=s8(v[1]), mask=v[2], **{'want': v[3]} if len(v) > 3 else {})
    k['rb_speed'] = [s8(v) for v in k['rb_speed']]
    k['rb_step_period'], k['rb_step_sfx'] = k.pop('rb_step_sfx')
    rest, lo, lo2, hi, hi2 = k.pop('rb_snap_k')
    if (lo, lo2, hi, hi2) != (-rest & 255, -rest & 255, rest, rest):
        raise SystemExit(f"pce_desert_actors: the robot's snap {(rest, lo, lo2, hi, hi2)}")
    k['rb_rest_dy'] = rest
    k['rb_beam_type'], k['rb_beam_parts'] = k.pop('rb_beam')
    lo, hi = k.pop('rb_beam_dy')
    k['rb_beam_dy'] = s16(lo | hi << 8)
    lo, mid = k.pop('rb_score')
    k['rb_score_bcd'] = mid << 8 | lo
    k['bm_part_type'], k['bm_part_attr'], k['bm_part_colflags'] = k.pop('bm_part')
    k['s3_once'], k['s3_status_a'], k['s3_status_b'] = k.pop('s3_wait')
    for name in ('jp_wall_r', 'jp_wall_l'):
        v = k.pop(name)
        k[name] = dict(dy=s8(v[0]), dx=s8(v[1]), mask=v[2], want=v[3])
    lo, mid = k.pop('jp_score')
    k['jp_score_bcd'] = mid << 8 | lo
    k['gn_turn_frame'], k['gn_turn_set'] = k.pop('gn_turn_frame')
    k['s1_portrait_once'], k['s1_portrait_done'] = k.pop('s1_portrait')
    k['s1_go_status'], k['s1_go_a'], go2, k['s1_go_b'] = k.pop('s1_go')
    if go2 != k['s1_go_status']:
        raise SystemExit("pce_desert_actors: section 1's go writes two different statuses")
    k['s1_open_t'], k['s1_open_wait'] = k.pop('s1_open')
    k['s1_wait_once'], k['s1_wait_status'] = k.pop('s1_wait')
    k['of_grain_type'], k['of_grain_param'] = k.pop('of_grain')
    t, p, dy, dx = k.pop('of_ball')
    k.update(of_ball_type=t, of_ball_param=p, of_ball_dy=s8(dy), of_ball_dx=s8(dx))
    k['of_arm_once'], k['of_arm_bit'], arm2 = k.pop('of_arm')
    if arm2 != k['of_arm_once']:
        raise SystemExit("pce_desert_actors: the officer's re-arm reads and writes different once ids")
    lo, mid = k.pop('of_score')
    k['of_score_bcd'] = mid << 8 | lo
    lo, hi = k.pop('of_flash')
    k['of_flash_color'] = hi << 8 | lo
    k['bl_needle_type'], k['bl_needle_param'] = k.pop('bl_needle')
    k['pl_arm_bit'], k['pl_arm_mask'] = k.pop('pl_arm_bit')
    k['s4_portrait_once'], k['s4_portrait_done'] = k.pop('s4_portrait')
    k['s4_go_status'], k['s4_go_a'], go2, k['s4_go_b'] = k.pop('s4_go')
    if go2 != k['s4_go_status']:
        raise SystemExit("pce_desert_actors: section 4's go writes two different statuses")
    k['s4_wait_once'], k['s4_wait_status'] = k.pop('s4_wait')
    k['cn_sub_fire'], k['cn_sub_mortar'] = k.pop('cn_subs')
    k['cn_state_fire'], k['cn_fire_t'], k['cn_cmd_fire'] = k.pop('cn_fire')
    k['cn_state_mortar'], k['mt_every'], k['cn_cmd_mortar'] = k.pop('mt_fire')
    for p in range(4):
        typ, k[f'pt{p}_attr'], k[f'pt{p}_frame'], k[f'pt{p}_list'] = k.pop(f'pt{p}_init')
        if typ != 74:
            raise SystemExit(f'pce_desert_actors: tank part {p} is not a 0x4A record')
    for p in (0, 1, 2):
        k[f'pt{p}_cmd_rise'], k[f'pt{p}_cmd_lower'] = k.pop(f'pt{p}_cmd')
        lo, hi, k[f'pt{p}_top'] = k.pop(f'pt{p}_rise')
        k[f'pt{p}_rise_v'] = s16(lo | hi << 8)
    k['pt3_bit'], k['pt3_dead_frame'] = k.pop('pt3_bit')
    k['cn_cmd_shell'], k['cn_cmd_none'], k['cn_cmd_mortar2'] = k.pop('cn_cmds')
    k['cn_recoil_t'], k['cn_recoil_frame'] = k.pop('cn_recoil')
    k['tu_cmd_shot'], k['tu_cmd_none'] = k.pop('tu_cmds')
    k['tu_aim_t'], k['tu_no_dir'] = k.pop('tu_aim_t')
    lo, hi, k['pt3_top'] = k.pop('pt3_rise')
    k['pt3_rise_v'] = s16(lo | hi << 8)
    k['pt3_raised_bit'], k['pt3_colflags'] = k.pop('pt3_raised')
    v = k.pop('b3_shot')
    k.update(b3_type=v[0], b3_dy=s8(v[1]), b3_dx=s8(v[2]), b3_vx=s16(v[3] | v[4] << 8), b3_vy=s16(v[5] | v[6] << 8))
    v = k.pop('sh_shot')
    k.update(sh_type=v[0], sh_param=v[1], sh_dy=s8(v[2]), sh_dx=s8(v[3]), sh_vx=s16(v[4] | v[5] << 8), sh_vy=s16(v[6] | v[7] << 8))
    k['cs_type'], k['cs_param'] = k.pop('cs_type')
    v = k.pop('mt_shot')
    k.update(mt_type=v[0], mt_param=v[1], mt_dy=s8(v[2]), mt_dx=s8(v[3]), mt_vx=s16(v[4] | v[5] << 8), mt_vy=s16(v[6] | v[7] << 8))
    k['tk_dead_mask'], k['tk_dead_bit'] = k.pop('tk_dead')
    lo, mid = k.pop('tk_score')
    k['tk_score_bcd'] = mid << 8 | lo
    k['rd_p1_d'], k['rd_p1_c'], k['rd_p1_kind'] = k.pop('rd_p1')
    k['rd_p2_d'], k['rd_p2_c'], k['rd_p2_kind'] = k.pop('rd_p2')
    k['rd_p3_d'], k['rd_p3_c'], k['rd_p3_kind'] = k.pop('rd_p3')
    k['rd_p4_c'], k['rd_p4_kind'], k['rd_add'] = k.pop('rd_p4')
    k['sh_colflags'], k['sh_list'] = k.pop('sh_init')
    k['mt_colflags'], k['mt_list'] = k.pop('mt_init')
    k['mt_colflags2'], k['mt_flip'] = k.pop('mt_turn')
    dy, dx, mask, want = k.pop('mt_floor')
    k['mt_floor'] = dict(dy=s8(dy), dx=s8(dx), mask=mask, want=want)
    k['cm_walk_anim'], k['cm_walk_t'], lo, hi = k.pop('cm_walk')
    k['cm_vx'] = s16(lo | hi << 8)
    return k

def step8_tables(census):
    """Step 8's tables (STEP8_TABLES, bank 0x74), each read where the instruction that reads it matches, from checkpoint"""
    read = census.reader(116, 5)
    out = {}
    for name, (at, n, code, want) in STEP8_TABLES.items():
        if bytes((read(code + i) for i in range(len(want) // 2))) != bytes.fromhex(want):
            raise SystemExit(f'pce_desert_actors: the read of {name} at 0x74:{code:#06x} has an unexpected shape')
        out[name] = [read(at + i) for i in range(n)]
    for at, want in TREAD_DEST:
        if bytes((read(at + i) for i in range(3))) != bytes.fromhex(want):
            raise SystemExit(f"pce_desert_actors: the treads' store at 0x74:{at:#06x} is not BG palette 8")
    w = lambda v, i: v[i] | v[i + 1] << 8
    for name in ('tk_subs', 'cn_states', 'tu_states', 'pt_handlers', 'col_parts', 'tr_pen9', 'tr_pen14', 'tu_vx', 'tu_vy', 'cs_vx', 'cs_vy'):
        out[name] = [w(out[name], 2 * i) for i in range(len(out[name]) // 2)]
    for name in ('tu_vx', 'tu_vy', 'cs_vx', 'cs_vy'):
        out[name] = [s16(v) for v in out[name]]
    for name in ('tu_dy', 'tu_dx', 'cs_dy', 'cs_dx', 'dbr_dy', 'dbr_dx', 'bob_dy'):
        out[name] = [s8(x) for x in out[name]]
    sc, pairs = (out.pop('dbr_script'), [])
    for i in range(0, len(sc), 2):
        if sc[i] == 255:
            break
        if sc[i] & 128:
            raise SystemExit("pce_desert_actors: the tank's debris script loops")
        pairs.append((sc[i], sc[i + 1]))
    else:
        raise SystemExit("pce_desert_actors: the tank's debris script has no end")
    out['dbr_script'] = pairs
    out['mt_x'] = [lo | hi << 8 for lo, hi in zip(out.pop('mt_x_lo'), out.pop('mt_x_hi'))]
    return out

def step3_tables(census):
    """Step 3's tables (DESERT_ENEMIES.md): the drone's velocity table (bank 0x72 0x976C: 7 rows by"""
    import pce_desert_spawns as SP
    r72, r68, r6c = (census.reader(114), census.reader(104), census.reader(108))
    if bytes((r68(ATAN_CODE + i) for i in range(10))) != bytes.fromhex('9829fcf004c9fcd0098a'):
        raise SystemExit('pce_desert_actors: the direction routine 0x68:0x4E35 has an unexpected shape')
    if bytes((r68(20640 + i) for i in range(5))) != bytes.fromhex('a6d6bd4451'):
        raise SystemExit('pce_desert_actors: the rank reset 0x68:0x50A0 has an unexpected shape')
    ram = Path(census.cps[1]['prefix'] + '_ram_1f0000.bin').read_bytes()
    return dict(velocity=[[s16(word(r72, DRONE_VELOCITY + 16 * row + 2 * i)) for i in range(8)] for row in range(7)], entry_dir=[r72(DRONE_ENTRY_DIR + i) for i in range(16)], knock_vx=[s16(word(r72, DRONE_KNOCK + 2 * i)) for i in range(2)], atan=[r68(ATAN + i) for i in range(64)], rank=dict(start=[r68(RANK_START + i) for i in range(3)], first=[r68(RANK_FIRST + i) | r68(RANK_FIRST + 3 + i) << 8 for i in range(3)], period=[r68(RANK_PERIOD + i) | r68(RANK_PERIOD + 3 + i) << 8 for i in range(3)], strip=[r6c(RANK_STRIP + i) for i in range(16)]), difficulty=ram[214], waves={p: w['script'] for p, w in SP.generators(census.ram(1))['wave_manager_0x13'].items()})

def rank_strip_tick(rank, difficulty):
    """The first tick after a rank reset (a stage start or a lost life) on which the drones' items are"""
    r, state, timer = (rank['start'][difficulty], 0, 0)
    for tick in range(1, 100000):
        if state == 0:
            state, r, timer = (1, rank['start'][difficulty], rank['first'][difficulty])
        if timer:
            timer -= 1
        else:
            r = min(r + 1, 15)
            timer = rank['period'][difficulty] - 1
        if rank['strip'][r]:
            return tick
    raise SystemExit('pce_desert_actors: the rank never strips the items')

def step5_tables(census):
    """Step 5's tables (STEP5_TABLES, bank 0x72), each read where the instruction that reads it matches: the"""
    read = census.reader(114)
    out = {}
    for name, (at, n, code, want) in STEP5_TABLES.items():
        if bytes((read(code + i) for i in range(len(want) // 2))) != bytes.fromhex(want):
            raise SystemExit(f'pce_desert_actors: the read of {name} at 0x72:{code:#06x} has an unexpected shape')
        out[name] = [read(at + i) for i in range(n)]
    out['rb_vel'] = [[s16(out['rb_vel'][16 * r + 2 * i] | out['rb_vel'][16 * r + 2 * i + 1] << 8) for i in range(8)] for r in range(8)]
    kv = out.pop('rb_knock_v')
    out['rb_knock_vx'] = [s16(kv[i] | kv[i + 2] << 8) for i in range(2)]
    out['bm_step'] = [s8(v) for v in out['bm_step']]
    return out
STEP6_TABLES = {'jp_bounce_dy': (36073, 8, 36047, 'bde98c'), 'jp_debris_dy': (36402, 18, 36334, 'bd328e'), 'jp_debris_dx': (36420, 18, 36340, 'bd448e'), 'jp_debris_kind': (36510, 18, 36327, 'bd9e8e'), 'gn_aim': (37003, 16, 36973, 'bd8b90'), 'gn_shot_dy': (37120, 2, 37036, 'bd0091'), 'gn_shot_dx': (37122, 2, 37042, 'bd0291'), 'gn_shot_vx': (37124, 4, 37064, 'bd0491'), 'gn_shot_vy': (37128, 4, 37093, 'bd0891'), 'gn_dy': (37230, 4, 37204, 'bd6e91'), 'gn_debris_dy': (37327, 3, 37259, 'bdcf91'), 'gn_debris_dx': (37343, 3, 37265, 'bddf91')}

def step6_tables(census):
    """Step 6's tables (STEP6_TABLES, bank 0x74), each read where the instruction that reads it matches: the jeep's"""
    read = census.reader(116)
    out = {}
    for name, (at, n, code, want) in STEP6_TABLES.items():
        if bytes((read(code + i) for i in range(len(want) // 2))) != bytes.fromhex(want):
            raise SystemExit(f'pce_desert_actors: the read of {name} at 0x74:{code:#06x} has an unexpected shape')
        out[name] = [read(at + i) for i in range(n)]
    for name in ('jp_bounce_dy', 'jp_debris_dy', 'jp_debris_dx', 'gn_shot_dy', 'gn_shot_dx', 'gn_dy', 'gn_debris_dy', 'gn_debris_dx'):
        out[name] = [s8(v) for v in out[name]]
    for name in ('gn_shot_vx', 'gn_shot_vy'):
        v = out[name]
        out[name] = [s16(v[2 * i] | v[2 * i + 1] << 8) for i in range(len(v) // 2)]
    return out
STEP7_TABLES = {'of_subs': (32958, 20, 32955, '7cbe80'), 'of_actions': (33250, 10, 33247, '7ce281'), 'of_rank_pat': (33287, 16, 33265, 'bd0782'), 'of_pat_lo': (33303, 7, 33269, 'bd1782'), 'of_pat_hi': (33310, 7, 33274, 'bd1e82'), 'of_die_vx': (33861, 4, 33846, 'bd4584'), 'dbr_script': (34055, 33, 33919, 'bd0785'), 'dbr_dy': (34039, 8, 33950, 'bdf784'), 'dbr_dx': (34047, 8, 33956, 'bdff84'), 'gr_dy': (33684, 8, 33653, 'bd9483'), 'gr_dx': (33692, 8, 33659, 'bd9c83'), 'gr_head': (33700, 8, 33665, 'bda483'), 'gr_face': (34671, 8, 34599, 'bd6f87'), 'gr_vy': (34695, 16, 34612, 'bd8787'), 'gr_vx': (34679, 16, 34625, 'bd7787'), 'nd_dy': (34987, 6, 34956, 'bdab88'), 'nd_dx': (34993, 6, 34962, 'bdb188'), 'nd_head': (34999, 6, 34968, 'bdb788'), 'nd_anim': (35205, 6, 35126, 'bd8589'), 'nd_face': (35211, 6, 35133, 'bd8b89'), 'nd_vy': (35229, 12, 35146, 'bd9d89'), 'nd_vx': (35217, 12, 35159, 'bd9189'), 'pl_period': (42876, 4, 42743, 'bd7ca7'), 'pl_cycle': (42880, 72, 42799, 'bd80a7'), 'pl_drag_yf': (43416, 4, 43294, 'bd98a9'), 'pl_drag_y': (43420, 4, 43300, 'bd9ca9'), 'pl_drag_xf': (43424, 4, 43313, 'bda0a9'), 'pl_drag_x': (43428, 4, 43319, 'bda4a9'), 'pl_arm': (43465, 16, 43447, 'bdc9a9')}
STEP8_TABLES = {'tk_subs': (37561, 16, 37558, '7cb992'), 'cn_states': (37946, 10, 37943, '7c3a94'), 'tu_states': (38090, 8, 38087, '7cca94'), 'pt_handlers': (38454, 8, 38451, '7c3696'), 'tu_aim': (39784, 16, 39756, 'bd689b'), 'tu_idle': (39800, 2, 39766, 'bd789b'), 'tu_firef': (39866, 2, 39821, 'bdba9b'), 'tu_dy': (40316, 2, 40269, 'bd7c9d'), 'tu_dx': (40318, 2, 40275, 'bd7e9d'), 'tu_vx': (40320, 4, 40289, 'bd809d'), 'tu_vy': (40324, 4, 40302, 'bd849d'), 'cs_dy': (40400, 2, 40353, 'bdd09d'), 'cs_dx': (40402, 2, 40359, 'bdd29d'), 'cs_vx': (40404, 4, 40373, 'bdd49d'), 'cs_vy': (40408, 4, 40386, 'bdd89d'), 'hit_lim': (40611, 4, 40584, 'dda39e'), 'hit_dead': (40615, 4, 40605, '1da79e'), 'hit_bit': (40619, 4, 40574, '1dab9e'), 'hit_clr': (40623, 4, 40546, '3daf9e'), 'col_parts': (40641, 8, 40638, '7cc19e'), 'dbr_script': (41015, 33, 40879, 'bd37a0'), 'dbr_par': (40991, 8, 40904, 'bd1fa0'), 'dbr_dy': (40999, 8, 40910, 'bd27a0'), 'dbr_dx': (41007, 8, 40916, 'bd2fa0'), 'tr_period': (41296, 8, 41217, 'bd50a1'), 'tr_pen9': (41304, 4, 41267, 'bd58a1'), 'tr_pen14': (41308, 4, 41279, 'bd5ca1'), 'bob_period': (41413, 16, 41324, 'bdc5a1'), 'bob_dy': (41429, 2, 41373, 'bdd5a1'), 'mt_x_lo': (42272, 4, 42157, 'bd20a5'), 'mt_x_hi': (42276, 4, 42164, 'bd24a5')}
TREAD_DEST = ((41270, '8d1b29'), (41282, '8d2529'))
PIT_TABLE = (39978, 8, 39869, 'bd2a9c')
CYCLE_PALETTE, CYCLE_FIRST = (9, 2)

def step7_tables(census, h):
    """Step 7's tables (STEP7_TABLES, bank 0x74; the pit's variants, bank 0x6A), each read where the instruction that"""
    read = census.reader(116, 2)
    out = {}
    for name, (at, n, code, want) in STEP7_TABLES.items():
        if bytes((read(code + i) for i in range(len(want) // 2))) != bytes.fromhex(want):
            raise SystemExit(f'pce_desert_actors: the read of {name} at 0x74:{code:#06x} has an unexpected shape')
        out[name] = [read(at + i) for i in range(n)]
    for c in range(6):
        for b in range(2):
            at, want = (42799 + 12 * c + 6 * b, f'bd{128 + 12 * c + b:02x}a7')
            if bytes((read(at + i) for i in range(3))) != bytes.fromhex(want):
                raise SystemExit(f"pce_desert_actors: the cycle's read at 0x74:{at:#06x} has an unexpected shape")
            dst = 10249 + 2 * (16 * CYCLE_PALETTE + CYCLE_FIRST + c) + b
            if bytes((read(at + 3 + i) for i in range(3))) != bytes([141, dst & 255, dst >> 8]):
                raise SystemExit(f"pce_desert_actors: the cycle's store at 0x74:{at + 3:#06x} is not BG palette 9")
    w = lambda v, i: v[i] | v[i + 1] << 8
    out['of_subs'] = [w(out['of_subs'], 2 * i) for i in range(10)]
    out['of_actions'] = [w(out['of_actions'], 2 * i) for i in range(5)]
    pats = []
    for lo, hi in zip(out.pop('of_pat_lo'), out.pop('of_pat_hi')):
        a, p = (lo | hi << 8, [])
        while read(a) != h['of_pat_end']:
            p.append(read(a))
            a += 1
            if len(p) > 64:
                raise SystemExit('pce_desert_actors: an officer pattern has no end')
        pats.append(p)
    out['of_patterns'] = pats
    v = out['of_die_vx']
    out['of_die_vx'] = [s16(v[i] | v[i + 2] << 8) for i in range(2)]
    sc, pairs = (out.pop('dbr_script'), [])
    for i in range(0, len(sc), 2):
        if sc[i] == 255:
            break
        if sc[i] & 128:
            raise SystemExit("pce_desert_actors: the officer's debris script loops")
        pairs.append((sc[i], sc[i + 1]))
    else:
        raise SystemExit("pce_desert_actors: the officer's debris script has no end")
    out['dbr_script'] = pairs
    for name in ('dbr_dy', 'dbr_dx', 'gr_dy', 'gr_dx', 'nd_dy', 'nd_dx'):
        out[name] = [s8(x) for x in out[name]]
    for name in ('gr_vy', 'gr_vx', 'nd_vy', 'nd_vx'):
        out[name] = [s16(w(out[name], 2 * i)) for i in range(len(out[name]) // 2)]
    cy = out['pl_cycle']
    out['pl_cycle'] = [[w(cy, 12 * c + 2 * p) for c in range(6)] for p in range(6)]
    for name in ('pl_drag_y', 'pl_drag_x'):
        out[name] = [s8(x) for x in out[name]]
    ram = Path(census.cps[2]['prefix'] + '_ram_1f0000.bin').read_bytes()
    out['cam_band_y'] = [s16(ram[a - 8192] | ram[a - 8192 + 1] << 8) for a in (13109, 13111)]
    r6a = census.reader(106, 2)
    at, n, code, want = PIT_TABLE
    if bytes((r6a(code + i) for i in range(len(want) // 2))) != bytes.fromhex(want):
        raise SystemExit("pce_desert_actors: the pit's variant table read has an unexpected shape")
    cells = h['pit_w'] * h['pit_h']
    out['pit'] = [[w([r6a(p + i) for i in range(2)], 0) for p in range(word(r6a, at + 2 * k), word(r6a, at + 2 * k) + 2 * cells, 2)] for k in range(n // 2)]
    return out
ART_CHECKPOINT = {25: 3, 26: 3, 118: 3, 72: 4, 73: 4, 69: 2, 71: 2, 74: 5, 75: 5, 76: 5, 110: 5}
NO_BOXES = (110,)

def extract(census_dir, types=(68, 7, 104, 65, 66, 67, 11, 64, 25, 26, 118, 72, 73, 69, 71, 74, 75, 76, 110)):
    c = Census(census_dir)
    h = handler_constants(c)
    actors = {t: actor(c, t, ART_CHECKPOINT.get(t, 1)) for t in types}
    for t in NO_BOXES:
        if t in actors:
            actors[t]['boxes'] = [[] for _ in actors[t]['frames']]
    return dict(census=str(c.path), actors=actors, palettes=sprite_palettes(c), map_lists={s: map_list(c, s) for s in range(5)}, generator=generator(c), soldier=soldier_tables(c), handlers=h, step3=step3_tables(c), step5=step5_tables(c), step6=step6_tables(c), step7=step7_tables(c, h), step8=step8_tables(c))

def summary(d):
    out = dict(palettes=[[f'{v:#05x}' for v in p] for p in d['palettes']], generator=d['generator'], soldier=d['soldier'], handlers=d['handlers'], map_lists={s: [dict(r, type=f"{r['type']:#04x}") for r in v] for s, v in d['map_lists'].items()}, actors={})
    for t, a in d['actors'].items():
        out['actors'][f'{t:#04x}'] = dict(bank=f"{a['bank']:#04x}", handler=f"{a['handler']:#06x}", anim_table=f"{a['anim_table']:#06x}", frame_table=f"{a['frame_table']:#06x}", box_table=f"{a['box_table']:#06x}", frames=[dict(index=f['index'], at=f"{f['at']:#06x}", size=list(f['image'].shape), origin=list(f['origin']), key=f['key'], palettes=sorted({p['palette'] for p in f['pieces']})) for f in a['frames']], boxes=a['boxes'], anims=[dict(index=x['index'], at=f"{x['at']:#06x}", ticks=x['ticks'], steps=x['steps']) for x in a['anims']])
    return out

def sheet(d, out):
    from PIL import Image
    pal = V.pal_rgb(np.array([v for p in d['palettes'] for v in p]))
    ims = []
    for t, a in d['actors'].items():
        for f in a['frames']:
            img = f['image']
            rgb = np.where((img > 0)[..., None], pal[np.clip(img, 0, 255)], 48).astype(np.uint8)
            ims.append(Image.fromarray(rgb).resize((img.shape[1] * 3, img.shape[0] * 3), Image.NEAREST))
    W, Hh = (sum((i.width + 6 for i in ims)), max((i.height for i in ims)))
    S = Image.new('RGB', (W, Hh), (24, 24, 24))
    x = 0
    for i in ims:
        S.paste(i, (x, 0))
        x += i.width + 6
    S.save(out)

def self_test(census_dir):
    d = extract(census_dir)
    s = d['actors'][68]
    assert (s['bank'], s['handler'], s['anim_table']) == (114, 43734, 43705), (s['bank'], hex(s['handler']))
    assert (s['frame_table'], s['box_table']) == (36608, 36802)
    assert len(s['frames']) == 6 and len(s['boxes']) == 6, (len(s['frames']), len(s['boxes']))
    assert all((b == [dict(dy=0, hh=32, dx=0, hw=8)] for b in s['boxes'])), s['boxes']
    assert {p['palette'] for f in s['frames'] for p in f['pieces']} == {13}
    assert [len(f['pieces']) for f in s['frames']] == [4, 6, 3, 3, 3, 3]
    assert [sequence(a) for a in s['anims']] == [([(4, 1)], 0), ([(0, 1), (1, 1)], 0), ([(5, 1)], 0), ([(2, 1), (3, 1)], 1), ([(0, 1), (1, 1)], 0)], [sequence(a) for a in s['anims']]
    b = d['actors'][7]
    assert (b['bank'], b['handler']) == (114, 36945) and len(b['frames']) == 1 and (b['boxes'][0] == [dict(dy=0, hh=2, dx=0, hw=2)])
    g = d['actors'][104]
    assert (g['bank'], g['handler']) == (116, 43503) and len(g['frames']) == 9
    assert sequence(g['anims'][0]) == ([(0, 1), (1, 1), (2, 1), (2, 3), (1, 3), (0, 3)], 5)
    sold = [(r['x'], r['y'], r['flags']) for r in d['map_lists'][0] if r['type'] == 68]
    assert sold == [(224, 896, 1), (288, 896, 1), (1536, 688, 1), (1568, 688, 1), (1600, 688, 1), (1840, 688, 1), (1872, 688, 1)], sold
    gen = d['generator']
    assert gen['timers'] == [64] * 16 and gen['ids'] == [list(range(66, 72)), list(range(74, 80))], gen
    assert d['soldier']['sine'][4] == 1024 and d['soldier']['sine'][0] == 0, d['soldier']
    z = d['actors'][65]
    assert (z['bank'], z['handler'], z['anim_table'], z['frame_table']) == (114, 42615, 42595, 36185)
    assert len(z['frames']) == 6 and all((b == [dict(dy=0, hh=32, dx=0, hw=8)] for b in z['boxes']))
    assert [sorted({p['palette'] for p in f['pieces']}) for f in z['frames'][:4]] == [[12], [1, 12], [1, 12], [1, 12]]
    assert [sequence(a) for a in z['anims'][:2]] == [([(0, 1)], 0), ([(1, 1), (2, 1), (3, 1)], ('anim', 0))]
    r = d['actors'][66]
    assert (r['handler'], len(r['frames']), r['boxes']) == (43084, 1, [[dict(dy=0, hh=8, dx=0, hw=8)]])
    mn = d['actors'][67]
    assert (mn['handler'], len(mn['frames'])) == (43474, 7) and mn['frames'][6]['pieces'] == []
    assert [len(b) for b in mn['boxes']] == [0, 0, 1, 1, 1, 1, 0] and mn['boxes'][2] == [dict(dy=0, hh=32, dx=0, hw=32)]
    assert [sequence(a) for a in mn['anims']] == [([(6, 1)], 0), ([(0, 1), (1, 1)], 1), ([(2, 1), (3, 1), (4, 1), (5, 1)], 3)]
    assert {p['palette'] for f in mn['frames'] for p in f['pieces']} == {1, 4}
    h = d['handlers']
    want = dict(bz_colflags=192, bz_aim=32, bz_fire=32, bz_child=66, bz_rocket_dy=-12, bz_rocket_dx=48, bz_knock=4, bz_knock_vx=[1536, -1536], bz_score_bcd=512, rk_colflags=192, rk_vx=2048, rk_right=272, rk_left=-16, rk_hit=True, mn_colflags=128, mn_dy=-32, mn_tol_y=16, mn_dx=16, mn_tol_x=16, mn_warn=16, mn_blast=8, mn_sfx=20, mn_right=384, mn_left=-128, scr_h=192, scr_cy=128, scr_cx=128)
    assert {k: h[k] for k in want} == want, {k: (h.get(k), v) for k, v in want.items() if h.get(k) != v}
    want3 = dict(dr_colflags=200, dr_entry_bit=4, dr_entry_speed=64, dr_entry_anim=2, dr_entry_exit_dx=64, dr_band_top=0, dr_band_bottom=224, dr_band_left=96, dr_band_right=160, dr_home_timer=32, dr_home_anim=0, dr_close_dx=64, dr_close_dy=64, dr_turn_pos=8, dr_turn_neg=-8, dr_home_speed=32, dr_glide_speed=16, dr_glide_anim=1, dr_glide_timer=32, dr_box_top=-64, dr_box_bottom=256, dr_box_left=-64, dr_box_right=320, dr_vy_phase=192, dr_death_timer=4, dr_score_bcd=768, dr_item_bits=240, dr_item_type=5, dr_item_dy=12, dr_item_dx=0, dr_item_open=3, wm_spawn_dy=96, wm_right_dx=288, wm_left_dx=-32, wm_kind_at=36, wm_rank_mask=15, wm_type=11, it_mask=64, it_rest=9, it_fall=1)
    assert {k: h[k] for k in want3} == want3, {k: (h.get(k), v) for k, v in want3.items() if h.get(k) != v}
    want4 = dict(sw_colflags=192, sw_surface=32, sw_period=12, sw_stop_dx=120, sw_child_type=64, sw_child_dy=0, sw_child_dx=80, sw_child_k=1, sw_follow=3, sw_hits=2, sw_death_timer=4, sw_score_bcd=1024, sw_probe_a=dict(dx=72, dy=-8, mask=64, want=8), sw_probe_b=dict(dx=88, dy=-8, mask=64, want=8))
    assert {k: h[k] for k in want4} == want4, {k: (h.get(k), v) for k, v in want4.items() if h.get(k) != v}
    floor = dict(dy=24, dx=0, mask=192)
    want5 = dict(rb_colflags=192, rb_layer=4, rb_wait0=60, rb_fire_dy=32, rb_walk=180, rb_fire_dy2=32, rb_wait1=60, rb_wall_r=dict(dy=0, dx=0, mask=128, want=4), rb_drop_r=dict(dy=22, dx=1, mask=192, want=16), rb_wall_l=dict(dy=0, dx=0, mask=128, want=4), rb_drop_l=dict(dy=22, dx=-2, mask=192, want=16), rb_speed=[16, -16], rb_hold=60, rb_rest=60, rb_step_period=7, rb_step_sfx=27, rb_spin_period=4, rb_aim_right=6, rb_aim_left=2, rb_snap=floor, rb_rest_dy=4, rb_vel_probe=floor, lg_dx_a=3, lg_dy=12, lg_dx_b=-3, lg_probe=dict(dy=-8, dx=0, mask=192, want=16), lg_probe2=dict(dy=8, dx=0, mask=192), lgb_probe=dict(dy=-8, dx=0, mask=192, want=16), lgb_probe2=dict(dy=8, dx=0, mask=192), rb_beam_type=26, rb_beam_parts=2, rb_beam_dy=-16, rb_beam_dx_r=16, rb_beam_dx_l=-16, rb_beam_sfx=22, rb_hits=4, rb_knock=6, rb_debris=3, rb_score_bcd=768, bm_life=200, bm_period=2, bm_part_type=26, bm_part_attr=12, bm_part_colflags=128, fl_colflags=128, fl_burst_anim=1, fl_period=32, rb_step_gate=2, sfx_near=[240, 240], anim_psg=True)
    assert {k: h[k] for k in want5} == want5, {k: (h.get(k), v) for k, v in want5.items() if h.get(k) != v}
    want6 = dict(s3_once=118, s3_status_a=2, s3_status_b=4, jp_colflags=192, jp_layer=4, jp_gunner=73, jp_wait=8, jp_wait_anim=1, jp_dy=48, jp_charge_t=32, jp_reverse_t=32, jp_charge_acc_r=64, jp_charge_max_r=2048, jp_charge_acc_l=-64, jp_charge_max_l=-2048, jp_brake_t=8, jp_brake_r=128, jp_brake_l=-128, jp_rev_acc_l=128, jp_rev_max_l=1024, jp_rev_acc_r=-128, jp_rev_max_r=-1024, jp_bounce_t=32, jp_bounce_anim=0, jp_bounce_n=8, jp_turn_t=16, jp_turn_anim=3, jp_ahead_r=128, jp_ahead_l=-128, jp_wall_r=dict(dy=0, dx=48, mask=128, want=8), jp_wall_l=dict(dy=0, dx=-48, mask=128, want=8), jp_hits=5, jp_death_anim=0, jp_death_t=64, jp_death_v_r=2048, jp_death_v_l=-2048, jp_debris=3, jp_final=[16, 17], jp_score_bcd=1280, jp_dead_once=4, jp_wreck_anim=2, gn_layer=5, gn_parent_dead=4, gn_no_fire_frame=2, gn_shot_gap=2, gn_burst=3, gn_pause=16, gn_turn_frame=3, gn_turn_set=2, gn_aim_period=16, gn_bullet=7)
    assert {k: h[k] for k in want6} == want6, {k: (h.get(k), v) for k, v in want6.items() if h.get(k) != v}
    want7 = dict(s1_delay=2, s1_portrait_once=114, s1_portrait_done=2, s1_go_status=3, s1_go_a=112, s1_go_b=113, s1_open_t=64, s1_open_wait=32, s1_wait_once=112, s1_wait_status=2, pit_n=4, pit_period=8, pit_y=1152, pit_x=2400, pit_w=26, pit_h=20, of_layer=3, of_go=3, of_wait_anim=0, of_wait_t=0, of_point_anim=1, of_point_t=4, of_ring_anim=2, of_ring_t=32, of_sink_v=2048, of_floor=1376, of_floor_set=1376, of_morph_anim=3, of_morph_t=32, of_col=128, of_idle_anim=4, of_idle_t=4, of_pat_end=255, of_clack_anim=5, of_clack_t=32, of_leap_anim=6, of_leap_v=-6144, of_leap_col=192, of_leap_g=256, of_leap_floor=1376, of_land_col=128, of_burst_n=16, of_burst_anim=7, of_burst_t=4, of_arm_once=113, of_arm_bit=64, of_ball_anim=8, of_ball_t=32, of_grain_type=71, of_grain_param=0, of_ball_type=71, of_ball_param=1, of_ball_dy=-32, of_ball_dx=0, of_hits=8, of_die_v=512, of_score_bcd=1792, of_flash_color=511, of_flash_n=30, of_blink=1, gr_layer=4, gr_life=32, gr_anim=0, gr_g=128, bl_col=128, bl_anim=1, bl_v=-8192, bl_g=512, bl_ring_t=8, bl_ring_anim=2, bl_needle_type=71, bl_needle_param=2, nd_col=128, nd_life=64, nd_g=16, pl_go=3, pl_wait=120, pl_phases=6, pl_left_x=2496, pl_left_w=112, pl_line_y=1184, pl_tol_lo=-12, pl_tol_hi=12, pl_right_x=2608, pl_right_w=112, pl_right_y=224, pl_lim_l=104, pl_lim_r=8, pl_arm_bit=64, pl_arm_mask=191, pl_decay=True, cam_step=16, cam_step_neg=-16)
    assert {k: h[k] for k in want7} == want7, {k: (h.get(k), v) for k, v in want7.items() if h.get(k) != v}
    assert handler_constants(Census(census_dir), 2) == h
    t7 = d['step7']
    assert t7['of_rank_pat'] == [0] * 5 + [1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6] and t7['of_patterns'][0] == [1, 3, 3, 2]
    assert t7['of_patterns'][1] == [3, 1, 3, 0, 2, 3, 0, 4] and t7['of_patterns'][3] == t7['of_patterns'][5]
    assert t7['dbr_script'] == [(4, 1), (4, 3), (4, 5), (4, 7), (1, 0), (1, 2), (1, 4), (1, 6)] + [(0, i) for i in range(8)]
    assert (t7['gr_vx'], t7['gr_vy'], t7['gr_face']) == ([-1536, 1536, -1152, 1152, -768, 768, -384, 384], [-3584] * 8, [0, 1] * 4)
    assert (t7['nd_anim'], t7['nd_face'], t7['nd_vx'], t7['nd_vy']) == ([3, 4, 5, 5, 4, 3], [0, 0, 0, 1, 1, 1], [-2048, -1536, -512, 512, 1536, 2048], [512, 1536, 2048, 2048, 1536, 512])
    assert t7['pl_period'] == [0, 4, 2, 1] and t7['pl_drag_x'] == [0, 1, 2, 4] and (t7['pl_drag_y'] == [0, 2, 4, 8])
    assert t7['pl_arm'] == [158] * 6 + [190] * 3 + [222] * 3 + [254] * 4
    assert t7['pl_cycle'][0] == [444, 435, 371, 363, 354, 291] and t7['pl_cycle'][1] == t7['pl_cycle'][0][1:] + t7['pl_cycle'][0][:1] and (t7['cam_band_y'] == [104, 136])
    assert [len(v) for v in t7['pit']] == [520] * 4 and t7['pit'][0][:4] == [4, 3, 4, 8]
    of, pj = (d['actors'][69], d['actors'][71])
    assert (of['bank'], of['handler'], of['anim_table'], of['frame_table']) == (116, 32881, 32820, 36819)
    assert all((b == [dict(dy=0, hh=32, dx=0, hw=8)] for b in of['boxes'])) and len(of['frames']) == 10
    assert [sorted({p['palette'] for p in f['pieces']}) for f in of['frames']] == [[7], [7], [1, 7, 8], [1, 7, 8], [1, 7], [1, 14], [1, 14], [1, 14], [14], [14]]
    assert [sequence(a) for a in of['anims']][3] == ([(5, 0), (6, 0), (7, 0)], ('anim', 4))
    assert (pj['handler'], pj['anim_table'], pj['frame_table'], len(pj['frames'])) == (34463, 34425, 38092, 10)
    assert all((b == [dict(dy=0, hh=8, dx=0, hw=8)] for b in pj['boxes']))
    assert [sequence(a) for a in pj['anims']][:3] == [([(0, 1), (1, 1), (2, 1), (3, 1)], 3), ([(4, 0), (5, 0)], 0), ([(6, 0), (6, 2), (6, 3), (6, 1)], 0)]
    assert d['map_lists'][1] == [] or all((r['type'] == 5 for r in d['map_lists'][1]))
    want8 = dict(s4_portrait_once=117, s4_portrait_done=2, s4_go_status=3, s4_go_a=115, s4_go_b=116, s4_wait_once=116, s4_wait_status=2, s4_delay=32, s4_clear=1, tk_home_y=1096, tk_home_x=5754, tk_go=3, tk_wait2=32, tk_wait3=80, tk_rise_cmd=1, tk_colflags=192, tk_pause_r=16, tk_left_lim=-96, tk_left_acc=-32, tk_left_max=-512, tk_pause_l=48, tk_right_lim=32, tk_right_acc=64, tk_right_max=768, tk_off_y=1096, tk_off_x=5754, cn_wait=32, cn_sub_fire=4, cn_sub_mortar=6, cn_state_fire=3, cn_fire_t=64, cn_cmd_fire=3, cn_state_mortar=4, mt_every=8, cn_cmd_mortar=5, mt_n=4, tu_sub=3, tu_period=80, tu_burst=8, tu_cmd=3, tu_screen=256, pt0_attr=12, pt0_frame=6, pt0_list=6, pt1_attr=12, pt1_frame=2, pt1_list=5, pt2_attr=12, pt2_frame=0, pt2_list=6, pt3_attr=12, pt3_frame=8, pt3_list=7, pt0_dy=8, pt0_dx=-32, pt2_dy=-4, pt2_dx=-24, pt1_dy=8, pt1_dx=0, pt3_dy=-16, pt3_dx=24, pt0_cmd_rise=1, pt0_cmd_lower=2, pt0_top=254, pt0_rise_v=-128, pt1_cmd_rise=1, pt1_cmd_lower=2, pt1_top=240, pt1_rise_v=-128, pt2_cmd_rise=1, pt2_cmd_lower=2, pt2_top=240, pt2_rise_v=-128, pt0_lower=128, pt0_bit=1, pt1_bit=2, pt2_bit=4, pt3_bit=8, pt3_dead_frame=9, cn_cmd_shell=3, cn_cmd_none=4, cn_cmd_mortar2=5, cn_recoil_t=4, cn_recoil_frame=1, cn_back=2, tu_cmd_shot=3, tu_cmd_none=4, tu_aim_t=32, tu_no_dir=16, tu_fire_t=2, pt3_top=224, pt3_rise_v=-1024, pt3_lower=512, pt3_fire_t=24, pt3_raised_bit=128, pt3_colflags=64, pu_far=80, pu_near=48, pu_screen=256, b3_type=7, b3_dy=8, b3_dx=-12, b3_vx=-3072, b3_vy=1536, sh_type=75, sh_param=0, sh_dy=-12, sh_dx=-34, sh_vx=-4096, sh_vy=0, cs_type=75, cs_param=1, tu_type=7, mt_type=75, mt_param=2, mt_dy=-32, mt_dx=48, mt_vx=0, mt_vy=-2048, tk_dead_mask=8, tk_dead_bit=8, hit_slash=True, tk_die_t=32, tk_sink=128, tk_score_bcd=5376, tk_blink=1, tk_restore=30, tk_bob_y=1096, rd_dx=136, rd_w=112, rd_dy=24, rd_h=96, rd_tol_lo=-12, rd_tol_hi=12, rd_p1_d=16, rd_p1_c=32, rd_p1_kind=2, rd_p2_d=48, rd_p2_c=16, rd_p2_kind=4, rd_p3_d=64, rd_p3_c=64, rd_p3_kind=2, rd_p4_c=0, rd_p4_kind=4, rd_add=32, sh_colflags=128, sh_list=7, sh_right=272, sh_left=-16, cs_list=4, cs_anim=1, cs_g=128, cs_free=256, mt_colflags=128, mt_list=4, mt_anim=2, mt_top=-32, mt_colflags2=192, mt_flip=2, mt_floor=dict(dy=0, dx=0, mask=240, want=16), mt_g=128, mt_max=3840, mt_free=256, mt_hit=True, cm_list=3, cm_go=3, cm_t1=4, cm_walk_anim=1, cm_walk_t=32, cm_vx=1536, st_list=1, st_x=224, st_x2=31)
    assert {k: h[k] for k in want8} == want8, {k: (h.get(k), v) for k, v in want8.items() if h.get(k) != v}
    assert handler_constants(Census(census_dir), 5) == h
    t8 = d['step8']
    assert t8['tu_aim'] == [0] * 8 + [129] * 5 + [128] * 3 and (t8['tu_idle'], t8['tu_firef']) == ([2, 4], [3, 5])
    assert (t8['tu_dy'], t8['tu_dx'], t8['tu_vx'], t8['tu_vy']) == ([-6, 18], [-54, -46], [-3584, -3072], [0, 1536])
    assert (t8['cs_dy'], t8['cs_dx'], t8['cs_vx'], t8['cs_vy']) == ([-8, -14], [20, 16], [1024, 512], [-2048, -2048])
    assert (t8['hit_lim'], t8['hit_dead'], t8['hit_bit']) == ([0, 0, 7, 7], [1, 2, 4, 8], [16, 32, 64, 128])
    assert t8['dbr_script'] == [(4, 1), (4, 3), (4, 5), (4, 7), (1, 0), (1, 2), (1, 4), (1, 6)] + [(0, i) for i in range(8)]
    assert (t8['tr_period'], t8['tr_pen9'], t8['tr_pen14']) == ([0, 4, 4, 2, 2, 2, 1, 1], [2121, 2193], [2193, 2121])
    assert t8['bob_period'] == [0, 2] + [1] * 14 and t8['bob_dy'] == [0, 1] and (t8['mt_x'] == [5504, 5552, 5600, 5648])
    tk, sh, cm, st = (d['actors'][t] for t in (74, 75, 76, 110))
    assert (tk['handler'], tk['frame_table'], len(tk['frames']), tk['anims']) == (37461, 38546, 10, [])
    assert [sorted({p['palette'] for p in f['pieces']}) for f in tk['frames']] == [[10]] * 7 + [[], [7], [7]]
    assert [len(b) for b in tk['boxes']] == [1, 1, 0, 0, 0, 0, 1, 0, 1, 1] and tk['boxes'][8] == [dict(dy=0, hh=16, dx=0, hw=16)]
    assert (sh['handler'], sh['frame_table'], len(sh['frames'])) == (41685, 38821, 7) and sh['boxes'][1] == []
    assert [sequence(a) for a in sh['anims']] == [([(0, 0)], 0), ([(1, 0), (1, 1), (1, 3), (1, 2)], 0), ([(2, 0), (2, 1)], 0)]
    assert (cm['handler'], len(cm['frames']), cm['boxes']) == (42468, 3, [[], [], []])
    assert [sequence(a) for a in cm['anims']] == [([(0, 0)], 0), ([(1, 0), (2, 0)], 0)] and cm['anims'][1]['ticks'] == 2
    assert (st['handler'], len(st['frames']), st['frames'][0]['image'].shape, st['boxes']) == (44427, 1, (64, 256), [[]])
    assert {p['palette'] for p in st['frames'][0]['pieces']} == {8}
    every = set(want) | set(want3) | set(want4) | set(want5) | set(want6) | set(want7) | set(want8)
    assert set(h) == every, sorted(set(h) ^ every)
    assert handler_constants(Census(census_dir), 3) == h
    assert handler_constants(Census(census_dir), 4) == h
    t6 = d['step6']
    assert t6['jp_bounce_dy'] == [-2, 2, -1, 1, -2, 2, -1, 1] and t6['gn_dy'] == [-63, -64, -64, -64], t6
    assert t6['gn_aim'] == [0, 0, 128, 128, 128, 129, 129, 129] + [0] * 8
    assert (t6['gn_shot_dy'], t6['gn_shot_dx'], t6['gn_shot_vx'], t6['gn_shot_vy']) == ([44, 56], [-32, -32], [3584, 3072], [0, 1280]), t6
    assert t6['jp_debris_kind'] == [1] * 16 + [0, 0] and t6['jp_debris_dx'][16:] == [-32, 32] and (t6['gn_debris_dy'][2] == 34)
    jp, gn = (d['actors'][72], d['actors'][73])
    assert (jp['bank'], jp['handler'], jp['anim_table'], jp['frame_table']) == (116, 35333, 35281, 38227)
    assert len(jp['frames']) == 4 and all((b == [dict(dy=0, hh=32, dx=0, hw=8)] for b in jp['boxes']))
    assert {p['palette'] for f in jp['frames'] for p in f['pieces']} == {12}
    assert [sequence(a) for a in jp['anims']][2:] == [([(2, 1)], 0), ([(3, 0), (3, 1), (0, 1), (1, 1)], 2)]
    assert [a['ticks'] for a in jp['anims']] == [8, 2, 8, 4] and sequence(jp['anims'][1])[1] == 26
    assert (gn['handler'], gn['frame_table'], len(gn['frames']), gn['anims']) == (36735, 38460, 3, [])
    assert [sorted({p['palette'] for p in f['pieces']}) for f in gn['frames']] == [[0, 13], [0, 13], [13]]
    assert all((b == [] for b in gn['boxes']))
    assert d['map_lists'][3] == []
    t5 = d['step5']
    assert t5['rb_frames'] == [0, 1, 2, 3, 3, 3, 4, 5] and t5['rb_heading'] == [64, 192]
    assert t5['rb_vel'][1] == [0, 98, 181, 237, 256, 237, 181, 98] and t5['rb_knock_vx'] == [1536, -1536]
    assert t5['lg_a'][:8] == [6, 205, 204, 205, 7, 6, 205, 6] and t5['lg_b'][28:] == [71, 70, 141, 70]
    assert [t5['bm_step'][i] for i in (0, 4, 8, 12)] == [0, 16, 0, -16] and t5['bm_frame'][4] == 0 and (t5['bm_frame'][12] == 64)
    rb, bm, fl = (d['actors'][25], d['actors'][26], d['actors'][118])
    assert (rb['bank'], rb['handler'], rb['frame_table']) == (114, 39346, 35707) and len(rb['frames']) == 14
    assert all((b == [dict(dy=0, hh=32, dx=0, hw=8)] for b in rb['boxes']))
    assert {p['palette'] for f in rb['frames'] for p in f['pieces']} == {0}
    assert (bm['handler'], len(bm['frames']), bm['boxes'][0]) == (41318, 4, [dict(dy=0, hh=16, dx=0, hw=16)])
    assert {p['palette'] for p in bm['frames'][0]['pieces']} == {1}
    assert (fl['bank'], fl['handler'], fl['anim_table']) == (116, 44610, 44568) and len(fl['frames']) == 10
    assert [len(b) for b in fl['boxes']] == [0, 1, 0, 0, 0, 0, 0, 0, 0, 0] and fl['boxes'][1] == [dict(dy=0, hh=8, dx=0, hw=8)]
    assert fl['frames'][5]['pieces'] == [] and {p['palette'] for f in fl['frames'] for p in f['pieces']} == {1}
    assert sequence(fl['anims'][0]) == ([(5, 0)], 0) and fl['anims'][1]['ticks'] == 1
    assert sequence(fl['anims'][1]) == ([(f, 0) for f in [6] * 3 + [7] * 3 + [8] * 3 + [9] * 11 + [4] * 3 + [0] * 3 + [1] * 2 + [2] * 2 + [3] * 2], ('anim', 0))
    s2 = [(r['type'], r['x'], r['y'], r['flags'], r['once_id']) for r in d['map_lists'][2] if r['type'] in (25, 118)]
    assert s2 == [(25, 3240, 456, 0, 26), (25, 3344, 288, 0, 27), (118, 3560, 192, 0, 28), (25, 3696, 216, 0, 29)] + [(118, x, 368, 0, i) for x, i in zip(range(3768, 4281, 128), range(30, 35))], s2
    sw = d['actors'][64]
    assert (sw['bank'], sw['handler'], sw['frame_table']) == (114, 41937, 36046) and len(sw['frames']) == 6
    assert all((b == [dict(dy=0, hh=32, dx=0, hw=8)] for b in sw['boxes']))
    assert sequence(sw['anims'][0]) == ([(0, 1), (1, 1), (2, 1), (1, 1), (2, 1), (3, 1), (4, 1), (5, 1)], 6)
    assert sw['anims'][0]['ticks'] == 4
    assert {p['palette'] for f in sw['frames'] for p in f['pieces']} == {6, 8}
    worms = [(r['x'], r['y'], r['flags'], r['once_id']) for r in d['map_lists'][0] if r['type'] == 64]
    assert worms == [(928, 928, 1, 9), (1280, 928, 1, 11)], worms
    t = d['step3']
    assert t['velocity'][1] == [0, 392, 724, 946, 1024, 946, 724, 392] and t['velocity'][3][4] == 2048
    assert t['entry_dir'] == [255, 8, 0, 255, 4, 6, 2, 255, 12, 10, 14, 255, 255, 255, 255, 255]
    assert t['knock_vx'] == [1536, -1536] and t['atan'][:4] == [16, 8, 8, 8] and (t['atan'][32] == 12)
    assert t['rank'] == dict(start=[3, 6, 9], first=[1800, 1800, 1350], period=[450, 450, 450], strip=[0] * 9 + [1] * 7)
    assert t['difficulty'] == 1 and rank_strip_tick(t['rank'], 1) == 2701
    assert [o['kind'] for o in t['waves'][0] if 'spawn' in o['op']] == [0, 0, 4]
    assert [o['kind'] for o in t['waves'][1] if 'spawn' in o['op']] == [4, 4, 4, 4, 4, 36, 4, 4, 68]
    dr = d['actors'][11]
    assert (dr['bank'], dr['handler']) == (114, 38102) and len(dr['frames']) == 9
    assert [sequence(a) for a in dr['anims']] == [([(2, 1), (1, 1), (0, 1), (1, 1)], 0), ([(2, 1), (3, 1), (4, 1), (5, 1)], 0), ([(2, 1), (1, 1), (0, 1), (1, 1)], 0)]
    assert [a['ticks'] for a in dr['anims']] == [2, 4, 1] and all((b == [dict(dy=-8, hh=8, dx=0, hw=12)] for b in dr['boxes']))
    cont = {s: [(r['x'], r['y'], r['once_id'], r['param']) for r in v if r['type'] == 5] for s, v in d['map_lists'].items()}
    assert cont == {0: [(864, 784, 8, 2), (1712, 784, 17, 3), (2040, 896, 20, 5)], 1: [], 2: [(2880, 832, 25, 4), (4462, 640, 35, 5)], 3: [], 4: []}, cont
    bz = [(r['x'], r['y'], r['flags'], r['once_id']) for r in d['map_lists'][0] if r['type'] == 65]
    mines = [(r['x'], r['y'], r['flags'], r['once_id']) for r in d['map_lists'][0] if r['type'] == 67]
    assert bz == [(384, 904, 1, 5)], bz
    assert mines == [(544, 960, 0, 6), (816, 928, 0, 7), (1072, 928, 0, 10), (1536, 928, 0, 13)], mines
    print('pce_desert_actors self-test passed:', {f'{t:#04x}': [f['key'] for f in a['frames']] for t, a in d['actors'].items()})
    return 0

def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('cmd', nargs='?', choices=['report'])
    p.add_argument('--self-test', action='store_true')
    p.add_argument('--census', type=Path, required=True)
    p.add_argument('--out', type=Path)
    a = p.parse_args()
    if a.self_test:
        return self_test(a.census)
    if a.cmd == 'report':
        a.out.mkdir(parents=True, exist_ok=False)
        d = extract(a.census)
        (a.out / 'actors.json').write_text(json.dumps(summary(d), indent=1) + '\n')
        sheet(d, a.out / 'frames.png')
        print('wrote', a.out)
        return 0
    p.error('give a command or --self-test')
if __name__ == '__main__':
    sys.exit(main())
