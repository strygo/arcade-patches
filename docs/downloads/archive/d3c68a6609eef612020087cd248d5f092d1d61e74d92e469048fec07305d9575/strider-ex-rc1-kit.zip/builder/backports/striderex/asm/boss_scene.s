; Strider EX: the boss scenes (manifests/boss_scenes.json, scripts/boss_scene.py, which writes
; boss_scene.inc: the timeline constants and the scene records). Built by build_ex.py with --portraits,
; the default since 2026-10-21 (BOSS_SCENE defined); --no-boss-scene builds none of this (a gate control).
;
; An encounter's hook stub (portraits.inc, portrait_ex.inc_text with the scene's portrait) calls
; bs_play_stage (d0 = scene, d1 = its internal stage) before it replays the encounter's own replaced
; instructions. bs_play runs in the caller's task and returns only when the scene is over:
;   - it sets ACTIVE to HOLD with BS_ON set, so from the next VBlank ex_vbl runs bs_vbl instead of the game's VBlank.
;     The game's tasks, timers, input reads and register shadows stand still (play pauses: Hiryu, the
;     enemies, the stage timer); its graphics RAM (sprite lists, maps, palettes 0x914000) is never
;     written;
;   - bs_vbl writes the frame the task prepared (palette base, layer word, OBJ base: one movem in the
;     task, so a VBlank never sees half a frame), keeps the sound protocol (a command on odd ticks,
;     0xFF on even ones; the first tick is even, so the game's last command keeps its frame) and
;     counts the scene's VBlanks (BS_N);
;   - the task prepares frame n + 1 after VBlank n (bs_prep): the timeline in boss_scene.py:
;       hold      n 1..BS_MUSIC_WAIT: the game's picture held (its palette base, layer word and
;                 sprite list); with the pack flag the fade_out control (BS_FADE_CMD 0xFC) on the
;                 first odd tick (n 2), its 23-tick fade landing at n 24;
;       fade-out  j = n - BS_MUSIC_WAIT: the game's palettes at levels 9..0 (the brightness nibble of
;                 every color, the stock kind-0xB fade) in the scene's palette buffers, the layers off
;                 from j BS_HIDE (black: the backdrop pen black);
;       pages     u = j - BS_NEXT: page after page (each drawn at the last one's 'next'), its own sprite
;                 list (the strips, the portrait, the panel, the plate with the text: the stock layer
;                 order). Text uses the page fades; the portrait stays visible between pages,
;                 fading only at scene entry and final exit. The portrait's mouth
;                 sequence and, with the pack flag, the voice cue from u BS_HOLD_FROM, across the pages;
;       return    r = u - the pages' nexts: black, then the game's layers and sprite list at levels 0, 0,
;                 1..9, its own palettes (0x9140) at r 12;
;     then the hook returns: the replaced instructions run (the strongman's queue the mid-boss cue
;     0x04) and the game's VBlank takes over at the next frame, writing its own shadows.
; Graphics RAM: the palette buffers 0x91C000 and 0x91D800 (0x1800 bytes each) and the sprite lists
; 0x91F000 and 0x91F800, all in 0x91C000-0x91FFFF, which the stock game never writes (boss_scene_gate
; checks it). Work RAM: BS_VARS 0xFFF9C0-0xFFF9E7 (free in the EX block, ACTIVE_HANDOFF.md map) and its stack
; BS_STACK, below 0xFFD800 (at most 0x100 bytes).

BS_VARS  equ $FFF9C0
                                        ; BS_ON (BS_VARS+$00): BS_MAGIC from the scene's start to its end; it and
                                        ; BS_MAGIC are ex_bank.s's (its VBlank's .hold tests them)
BS_N     equ BS_VARS+$02                ; word: scene VBlanks so far (bs_vbl)
BS_TICK  equ BS_VARS+$04                ; word: sound parity
BS_CUE   equ BS_VARS+$06                ; word: the command for the next odd tick, 0 = none
BS_PAL   equ BS_VARS+$08                ; word: the palette base the VBlank writes   } one movem (bs_prep .set)
BS_LAY   equ BS_VARS+$0A                ; word: the layer word                       }
BS_OBJ   equ BS_VARS+$0C                ; word: the OBJ base                         }
BS_PL    equ BS_VARS+$0E                ; word: phase << 8 | level (gates)           }
BS_T     equ BS_VARS+$10                ; word: page t or return r (gates)           }
BS_PREP  equ BS_VARS+$12                ; word: n of the frame above (gates)         }
BS_SCN   equ BS_VARS+$14                ; long: the scene record
BS_PIC   equ BS_VARS+$18                ; word: the portrait's code on the last page frame prepared (gates)
BS_GLAY  equ BS_VARS+$1A                ; word: the game's layer word (its shadow at the start)
BS_GOBJ  equ BS_VARS+$1C                ; word: the game's OBJ base (its shadow at the start)
BS_BUF   equ BS_VARS+$1E                ; word: the palette buffer prepared last (0, 1)
BS_VOICE equ BS_VARS+$20                ; word: the voice cue (0 without the pack flag)
BS_LBUF  equ BS_VARS+$22                ; word: the sprite list prepared last (0, 1)
BS_USP   equ BS_VARS+$24                ; long: the hook's task stack pointer while the scene runs on BS_STACK
                                        ; (BS_DONE, BS_VARS+$28, is ex_bank.s's: stage_hook clears it)
BS_STACK equ $FFD800                    ; the scene's own stack (grows down from here; 0xFFC800-0xFFF8FF is the
                                        ; cinematic player's ring and work, which the game never uses: ex_bank.s)
OBJ_SH   equ -$7366                     ; (a5) the game's OBJ base shadow (its VBlank writes it, 0x4FE)
PALS_END equ $1800
SC_TOTAL equ 0                          ; scene record (boss_scene.inc): scene VBlanks
SC_VJA   equ 2                          ; voice cues
SC_VEN   equ 4
SC_RESTART equ 6                        ; the music's restart: 0 the site's own cue, 1 the stage's music byte, 2 the
                                        ; desert's section cue (boss_scene.py RESTART)
SC_PT    equ 8                          ; the portrait slot's 16 colors
SC_PTX   equ 40                         ; the portrait entry: x, y, attribute, resting code
SC_REST  equ 46
SC_SEQ   equ 48                         ; long: its mouth sequence
SC_PAGES equ 52                         ; the first page record
MUSIC_B  equ -$6F3B                     ; (a5) 0xFF10C5: the stage's music cue as the stage handlers note it (0xFF: none)
PG_LINK  equ 0                          ; page record: long, the next page (0: the last)
PG_FADE  equ 4                          ; t of the fade-out, the hiding, the next page (or the return)
PG_HIDE  equ 6
PG_NEXT  equ 8
PG_UI    equ 10                         ; the UI slot's 16 colors
PG_STRIPS equ 42                        ; strips, then the entries before and after the portrait

; ------------------------------------------------------------ the VBlank (ACTIVE = HOLD, BS_ON set: ex_vbl .hold)
bs_vbl: movem.l d0/a0,-(sp)
        move.w  BS_PAL,CPSA+$0A         ; the palette copy first (the board holds the bus for it)
        move.w  BS_LAY,LAYER
        move.w  BS_OBJ,CPSA
        jsr     bs_nop                  ; gate control slot (boss_scene_gate.py freeze control: bs_ctl; vasm
                                        ; assembles it as a bsr.s, which the gate repoints)
        addq.w  #1,BS_TICK
        btst    #0,BS_TICK+1
        beq.s   .even
        move.w  BS_CUE,d0
        beq.s   .n
        move.w  d0,SOUND
        clr.w   BS_CUE
        bra.s   .n
.even:  move.w  #$FF,SOUND
.n:     addq.w  #1,BS_N
        movem.l (sp)+,d0/a0
        rte

bs_nop: rts
; bs_ctl: GATE CONTROL ONLY (boss_scene_gate.py patches bs_vbl's jsr to it): the game's own VBlank as
; well, so the game's timers and inputs run during the scene and the freeze check must fail.
bs_ctl: pea     .r(pc)
        move.w  sr,-(sp)
        jmp     STOCK_VBL.w
.r:     rts

; ------------------------------------------------------------ the scene
; d0 = scene (bs_table), d1 = the internal stage it belongs to. From a hook stub, in task context.
; The scene runs on its own stack (BS_STACK): a task's stack is small (Strider's tasks sit 0x60-0xA0 bytes
; apart in work RAM), and the scene's calls went 172 bytes deep below the hook's frame, into the next task's
; saved registers (MEASURED: that task resumed with a garbage A5 after the scene). The hook stub's own 20
; bytes stay on the task's stack, as the in-play portraits' stubs do.

; goes straight on. ex_bank.s stage_hook and desert.s dz_i0 clear it on a new stage's first intro step (a game start,
; a stage after a clear, the stage select, a continue); a respawn keeps it.
bs_play_stage:
        cmp.b   STAGE(a5),d1
        bne.s   .no
        cmp.w   #BS_SCENES,d0
        bcc.s   .no
        btst    d0,BS_DONE
        bne.s   .no                     ; played on this stage: straight on to the fight
        bset    d0,BS_DONE
        move.l  sp,BS_USP               ; the task's stack pointer (the game's tasks run in user mode)
        lea     BS_STACK,sp
        bsr.s   bs_play
        movea.l BS_USP,sp
.no:    rts

bs_play:
        movem.l d0-d7/a0-a6,-(sp)
        lea     bs_table,a0
        add.w   d0,d0
        add.w   d0,d0
        movea.l 0(a0,d0.w),a2
        move.l  a2,BS_SCN
        move.w  #1,BS_TICK              ; the first VBlank's tick is even (0xFF)
        clr.w   BS_CUE
        clr.w   BS_N
        clr.w   BS_BUF
        clr.w   BS_LBUF
        clr.w   BS_VOICE
        btst    #PACK,FLAGS+$F
        beq.s   .np
        move.w  SC_VJA(a2),BS_VOICE     ; the Japanese line for every voice flag (no dub yet: 0xC0-0xC7 have no row)
.np:    move.w  IC_LAYER(a5),BS_GLAY
        move.w  OBJ_SH(a5),BS_GOBJ
        move.w  #BS_MAGIC,BS_ON         ; (gates: the freeze starts)
        moveq   #1,d7
        bsr     bs_prep                 ; frame 1, before the first VBlank
        move.w  #HOLD,ACTIVE            ; from the next VBlank, bs_vbl (ex_vbl .hold, BS_ON): the game stands still
.loop:  cmp.w   BS_N,d7                 ; wait for VBlank n
        bhi.s   .loop
        movea.l BS_SCN,a2
        cmp.w   SC_TOTAL(a2),d7
        bcc.s   .end
        addq.w  #1,d7
        bsr     bs_prep
        bra.s   .loop
.end:   clr.w   ACTIVE                  ; the game's VBlank from the next frame
        clr.w   BS_ON                   ; (gates: the freeze ends)
        movea.l BS_SCN,a2               ; the music again (a 'site' scene: the encounter's own instructions, after
        move.w  SC_RESTART(a2),d1       ; the hook returns, queue its cue)
        cmp.w   #1,d1
        bne.s   .rd
        moveq   #0,d0
        move.b  MUSIC_B(a5),d0          ; the stage's music cue, queued as the stage handlers queue it
        cmp.b   #$FF,d0
        beq.s   .rx
        jsr     BS_QUEUE
        bra.s   .rx
.rd:
    ifd DESERT
        cmp.w   #2,d1
        bne.s   .rx
        move.w  DZ_MUS,d0               ; the desert section's cue (desert.s dz_cue's last)
        beq.s   .rx
        jsr     BS_QUEUE
    endc
.rx:    movem.l (sp)+,d0-d7/a0-a6
        rts

; bs_portrait: d0 = a portrait index (desert.s op 11, in place of pt_arm): that portrait's scene, if there is one.
bs_portrait:
        movem.l d0-d1/a0,-(sp)
        lea     bs_by_portrait,a0
        move.b  0(a0,d0.w),d0
        bmi.s   .x
        ext.w   d0
        move.b  STAGE(a5),d1
        bsr     bs_play_stage
.x:     movem.l (sp)+,d0-d1/a0
        rts

; bs_prep: d7 = n -> frame n prepared. Keeps d7.
bs_prep:
        movem.l d0-d6/a0-a4,-(sp)
        movea.l BS_SCN,a2
        moveq   #0,d6                   ; t
        move.w  BS_GLAY,d3
        move.w  BS_GOBJ,d4
        cmp.w   #BS_MUSIC_WAIT,d7
        bhi.s   .fade
        move.w  #$0110,d5               ; hold: phase 1, the palettes' own colors
        move.w  #$9140,d2
        cmp.w   #1,d7
        bne     .set
        move.w  #BS_FADE_CMD,BS_CUE     ; the music fades out first (the pack's fade_out)
        btst    #PACK,FLAGS+$F
        bne     .set
        move.w  #BS_STOP_CMD,BS_CUE     
        bra     .set
.fade:  move.w  d7,d0
        sub.w   #BS_MUSIC_WAIT,d0       ; j
        cmp.w   #BS_NEXT,d0
        bcc.s   .page
        cmp.w   #BS_HIDE,d0
        bcc.s   .black
        moveq   #BS_FADE_OUT,d1
        sub.w   d0,d1
        bpl.s   .f1
        moveq   #0,d1
.f1:    bsr     bs_gamepal              ; d1 = level -> d2
        move.w  #$0200,d5
        or.w    d1,d5
        bra     .set
.black: bsr     bs_blackpal
        move.w  #BS_LAYER_HIDE,d3
        move.w  #$0300,d5
        bra     .set
.page:  sub.w   #BS_NEXT,d0             ; u: frames since the first page's draw (the voice's clock: u - 19)
        move.w  d0,d6                   ; t within the page found below
        lea     SC_PAGES(a2),a4
        move.w  #$0400,d5               ; phase 4, page 0 (the page in bits 12-15)
.pg:    cmp.w   PG_NEXT(a4),d6
        bcs.s   .inpg
        sub.w   PG_NEXT(a4),d6
        add.w   #$1000,d5
        tst.l   PG_LINK(a4)
        beq     .ret                    ; past the last page: d6 = r
        movea.l PG_LINK(a4),a4
        bra.s   .pg
.inpg:  moveq   #0,d1                   ; the page's level: 0 to t 2, t - 2 to BS_FADE_IN - 1, its own colors
        cmp.w   #2,d6                   ; to the fade-out, then BS_FADE_OUT - (t - fade) down to 0
        ble.s   .lv
        move.w  d6,d1
        subq.w  #2,d1
        cmp.w   #BS_FADE_IN,d6
        blt.s   .lv
        moveq   #$10,d1
        move.w  d6,d3
        sub.w   PG_FADE(a4),d3
        ble.s   .lv
        moveq   #BS_FADE_OUT,d1
        sub.w   d3,d1
        bpl.s   .lv
        moveq   #0,d1
.lv:    bsr     bs_pagepal              ; d1 = level, a4 = page -> d2
        or.w    d1,d5
        cmp.w   #BS_HOLD_FROM,d0        ; the first page's t 19
        bne.s   .nv
        move.w  BS_VOICE,d3
        beq.s   .nv
        move.w  d3,BS_CUE               ; the voice line (a one-shot pack track), the music faded
.nv:    bsr     bs_picture              ; d0 = u
        move.w  #BS_LAYER_HIDE,d3
        moveq   #0,d0                   ; no entries
        cmp.w   #$1000,d5
        bcc.s   .shown                  ; later pages keep the portrait and frame on, including their t 0
        tst.w   d6
        beq.s   .hid                    ; only the first page's initial draw is hidden
.shown:
        tst.l   PG_LINK(a4)
        bne.s   .show                   ; between pages only the text fades
        cmp.w   PG_HIDE(a4),d6
        bcc.s   .hid
.show:
        move.w  #BS_LAYER_PAGE,d3
        moveq   #1,d0
.hid:   bsr     bs_list                 ; -> d4
        bra.s   .set
.ret:   tst.w   d6                      ; r
        bne.s   .r1
        bsr     bs_blackpal
        move.w  #BS_LAYER_HIDE,d3
        move.w  #$0500,d5
        bra.s   .set
.r1:    cmp.w   #12,d6
        bcs.s   .r2
        move.w  #$9140,d2               ; the game's own palettes
        move.w  #$0510,d5
        bra.s   .set
.r2:    moveq   #0,d1
        cmp.w   #2,d6
        bls.s   .r3
        move.w  d6,d1
        subq.w  #2,d1
.r3:    bsr     bs_gamepal
        move.w  #$0500,d5
        or.w    d1,d5
.set:   movem.w d2-d7,BS_PAL            ; BS_PAL, BS_LAY, BS_OBJ, BS_PL, BS_T, BS_PREP in one instruction
        movem.l (sp)+,d0-d6/a0-a4
        rts

; bs_nextbuf: the palette buffer not shown last -> a1, its base word -> d2. Clobbers d0.
bs_nextbuf:
        eori.w  #1,BS_BUF
        move.w  #BS_PAL0,d2
        tst.w   BS_BUF
        beq.s   .a
        move.w  #BS_PAL1,d2
.a:     moveq   #0,d0
        move.w  d2,d0
        lsl.l   #8,d0
        movea.l d0,a1
        rts

; bs_gamepal: d1 = level -> d2: the game's palettes (0x914000, untouched) with every color's brightness
; nibble at the level, in the next buffer. About 65,000 cycles.
bs_gamepal:
        movem.l d0-d1/d3-d5/a0-a1,-(sp)
        bsr     bs_nextbuf
        lea     PALS,a0
        move.w  d1,d4
        ror.w   #4,d4                   ; level << 12
        move.w  d4,d5
        swap    d4
        move.w  d5,d4
        move.l  #$0FFF0FFF,d3
        move.w  #PALS_END/16-1,d5
.l:     move.l  (a0)+,d0
        and.l   d3,d0
        or.l    d4,d0
        move.l  d0,(a1)+
        move.l  (a0)+,d0
        and.l   d3,d0
        or.l    d4,d0
        move.l  d0,(a1)+
        move.l  (a0)+,d0
        and.l   d3,d0
        or.l    d4,d0
        move.l  d0,(a1)+
        move.l  (a0)+,d0
        and.l   d3,d0
        or.l    d4,d0
        move.l  d0,(a1)+
        dbra    d5,.l
        movem.l (sp)+,d0-d1/d3-d5/a0-a1
        rts

; bs_blackpal -> d2: the next buffer with its backdrop pen black (the layers are off: the screen is that pen)
bs_blackpal:
        movem.l d0/a1,-(sp)
        bsr     bs_nextbuf
        clr.w   PALS_END-2(a1)
        movem.l (sp)+,d0/a1
        rts

; bs_pagepal: d1 = text level, d0 = u, d6 = t, a2 = scene, a4 = page -> d2: the next palette buffer.
; Portrait and red-frame brightness span the whole scene; the text has its own page fade and blank gap.
bs_pagepal:
        movem.l d0-d1/d3-d5/a0-a1,-(sp)
        move.w  d1,d3                   ; portrait/frame brightness: fade only at scene entry and final exit
        cmp.w   #BS_FADE_IN,d0          ; d0 = u, continuous across all text pages
        blt.s   .ptlevel
        tst.l   PG_LINK(a4)
        bne.s   .ptfull
        cmp.w   PG_FADE(a4),d6
        bhi.s   .ptlevel
.ptfull:
        moveq   #$10,d3
.ptlevel:
        move.w  d3,-(sp)
        bsr     bs_nextbuf
        clr.w   PALS_END-2(a1)
        move.l  a1,-(sp)
        lea     PG_UI(a4),a0
        lea     32*BS_UI_SLOT(a1),a1
        move.w  #BS_UI_FADE,d3
        bsr.s   .slot
        tst.w   d6
        beq.s   .blankui
        cmp.w   PG_HIDE(a4),d6
        bcs.s   .textshown
.blankui:
        lea     -32(a1),a0             ; brightness zero is still visible on CPS-1: blank the text during its gap
        moveq   #15,d5
.blankpen:
        clr.w   (a0)+
        dbra    d5,.blankpen
.textshown:
        move.l  (sp)+,a1
        move.w  (sp)+,d1
        move.w  PG_UI+2(a4),d0          ; reserved surround pen (now black), at the portrait's level
        cmp.w   #$10,d1
        beq.s   .frame
        move.w  d1,d4
        ror.w   #4,d4
        and.w   #$0FFF,d0
        or.w    d4,d0
.frame:
        move.w  d0,32*BS_UI_SLOT+2(a1)
        lea     SC_PT(a2),a0
        lea     32*BS_PT_SLOT(a1),a1
        move.w  #BS_PT_FADE,d3
        bsr.s   .slot
        movem.l (sp)+,d0-d1/d3-d5/a0-a1
        rts
.slot:  moveq   #0,d5                   ; pen
        move.w  d1,d4
        ror.w   #4,d4
.p:     move.w  (a0)+,d0
        cmp.w   #$10,d1
        beq.s   .w
        btst    d5,d3
        beq.s   .w
        and.w   #$0FFF,d0
        or.w    d4,d0
.w:     move.w  d0,(a1)+
        addq.w  #1,d5
        cmp.w   #16,d5
        blt.s   .p
        rts

; bs_picture: d0 = u (frames since the first page's draw), a2 = scene: the portrait's code (its mouth sequence
; from u = BS_HOLD_FROM on, across the pages; the resting picture otherwise) -> BS_PIC
bs_picture:
        movem.l d0-d2/d5/a0,-(sp)
        move.w  SC_REST(a2),d5
        sub.w   #BS_HOLD_FROM,d0
        bmi.s   .out
        movea.l SC_SEQ(a2),a0
.l:     move.w  (a0)+,d1                ; frames (0: the end)
        beq.s   .out
        move.w  (a0)+,d2                ; code
        cmp.w   d1,d0
        bcs.s   .hit
        sub.w   d1,d0
        bra.s   .l
.hit:   move.w  d2,d5
.out:   move.w  d5,BS_PIC
        movem.l (sp)+,d0-d2/d5/a0
        rts

; bs_list: d0 = 0 (no entries) or 1, d6 = t, a2 = scene, a4 = page -> d4: the next sprite list's base word, the
; page's entries at t (top first: the strips, the entries before the portrait (none in boss_scene.py's layout),
; the portrait, the panel and the plate with the text: the stock layer order), then the end mark
bs_list:
        movem.l d0-d3/d5-d7/a0-a1/a3,-(sp)
        eori.w  #1,BS_LBUF
        move.w  #BS_OBJ0,d4
        tst.w   BS_LBUF
        beq.s   .a
        move.w  #BS_OBJ1,d4
.a:     moveq   #0,d1
        move.w  d4,d1
        lsl.l   #8,d1
        movea.l d1,a3
        tst.w   d0
        beq     .end
        lea     PG_STRIPS(a4),a0
        move.w  (a0)+,d7                ; strips
        bra.s   .st
.sl:    move.w  8(a0),d0                ; life
        cmp.w   d0,d6
        bgt.s   .sn                     ; spent
        move.w  d6,d1
        subq.w  #1,d1                   ; t - 1 frames of motion
        move.w  4(a0),d0                ; vx (8.8)
        muls    d1,d0
        asr.l   #8,d0
        add.w   (a0),d0                 ; x
        move.w  6(a0),d2                ; vy (8.8)
        muls    d1,d2
        asr.l   #8,d2
        add.w   2(a0),d2                ; y
        move.w  10(a0),d3               ; cells
        bsr.s   bs_strip
.sn:    lea     12(a0),a0
.st:    dbra    d7,.sl
        bsr.s   .ents                   ; the entries before the portrait
        move.l  SC_PTX(a2),(a3)+        ; the portrait: x, y
        move.w  BS_PIC,(a3)+            ;   its picture
        move.w  SC_PTX+4(a2),(a3)+      ;   attribute
        bsr.s   .ents                   ; the panel, the plate
.end:   clr.l   (a3)                    ; the end mark (scene_core.s end_a3)
        clr.w   4(a3)
        move.w  #$FF00,6(a3)
        movem.l (sp)+,d0-d3/d5-d7/a0-a1/a3
        rts
.ents:  move.w  (a0)+,d7
        bra.s   .et
.el:    move.l  (a0)+,(a3)+
        move.l  (a0)+,(a3)+
.et:    dbra    d7,.el
        rts

; bs_strip: d0 = x, d2 = y, d3 = cells: its cells at sprite X 0 to BS_CLIP_X - 1, in blocks of at most 16
bs_strip:
        movem.l d4-d5,-(sp)
        moveq   #0,d4                   ; cells in the run
.c:     tst.w   d3
        beq.s   .flush
        cmp.w   #BS_CLIP_X,d0
        bcc.s   .off                    ; outside (unsigned: below 0 too)
        tst.w   d4
        bne.s   .add
        move.w  d0,d5                   ; a run starts here
.add:   addq.w  #1,d4
        cmp.w   #16,d4
        blt.s   .nx
        bsr.s   .emit
        bra.s   .nx
.off:   bsr.s   .emit
.nx:    add.w   #16,d0
        subq.w  #1,d3
        bra.s   .c
.flush: bsr.s   .emit
        movem.l (sp)+,d4-d5
        rts
.emit:  tst.w   d4
        beq.s   .e
        move.w  d5,(a3)+                ; x
        move.w  d2,(a3)+                ; y
        move.w  #BS_STRIP_CODE,(a3)+
        move.w  d4,d1
        subq.w  #1,d1
        lsl.w   #8,d1
        or.w    #BS_UI_SLOT,d1
        move.w  d1,(a3)+                ; attribute: the run's width, the UI slot
        moveq   #0,d4
.e:     rts
