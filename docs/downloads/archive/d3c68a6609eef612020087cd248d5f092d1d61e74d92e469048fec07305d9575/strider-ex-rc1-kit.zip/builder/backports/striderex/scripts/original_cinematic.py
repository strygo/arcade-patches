"""Original native cinematic music experiment; never changes a release build."""
from __future__ import annotations
import argparse
import json
import math
import re
import shutil
import subprocess
from pathlib import Path
import restore_tunes as RT
TITLE = 'Shadow Signal'
COMMAND = 37
BASE, LIMIT = (29440, 32512)
TEMPO = 10
BARS, UNITS_PER_BAR = (16, 16)
NOTE = {'C': 0, 'D': 2, 'E': 4, 'F': 5, 'G': 7, 'A': 9, 'B': 11}
INSTRUMENT_TRANSPOSE = {21: 0, 35: 0, 38: -12, 5: 0, 34: 0}
MELODY = ['E5:6 B4:2 F#5:4 G5:2 F#5:2', 'E5:4 D5:2 B4:2 -:2 G4:2 B4:4', 'E5:3 G5:1 B5:4 G5:4 E5:4', 'F#5:6 E5:2 D#5:4 B4:4', '-:2 B4:2 E5:4 F#5:2 G5:2 B5:4', 'A5:4 G5:4 F#5:2 D5:2 B4:4', 'C5:4 E5:2 F#5:2 A5:4 G5:4', 'F#5:4 E5:2 D#5:2 F#5:4 -:4', 'G5:6 E5:2 B5:4 A5:4', 'F#5:4 A5:2 E5:2 D5:6 -:2', 'B4:2 E5:2 G5:4 F#5:4 E5:4', 'D5:4 B4:2 D5:2 G5:4 A5:4', 'B5:4 A5:2 E5:2 C5:4 E5:4', 'F5:6 E5:2 C5:4 A4:4', 'B4:2 E5:2 F#5:4 A5:4 F#5:4', 'D#5:6 F#5:2 E5:2 D#5:2 B4:4']
HARMONY = [('E2', 'B3', 'G4', 'E4 B4 F#5 G4'), ('D2', 'B3', 'G4', 'E4 B4 D5 F#5'), ('C2', 'B3', 'E4', 'C4 G4 B4 E5'), ('B1', 'A3', 'D#4', 'B3 F#4 A4 D#5'), ('E2', 'B3', 'G4', 'E4 B4 F#5 G5'), ('D2', 'B3', 'F#4', 'D4 G4 B4 F#5'), ('A1', 'E3', 'C4', 'A3 E4 B4 C5'), ('B1', 'A3', 'D#4', 'B3 F#4 A4 D#5'), ('C2', 'G3', 'E4', 'C4 G4 B4 E5'), ('D2', 'A3', 'E4', 'D4 A4 E5 F#5'), ('E2', 'B3', 'G4', 'E4 B4 F#5 G5'), ('G1', 'D3', 'B3', 'G3 D4 F#4 B4'), ('A1', 'E3', 'C4', 'A3 E4 B4 C5'), ('F2', 'C4', 'A4', 'F4 A4 B4 E5'), ('B1', 'A3', 'E4', 'B3 E4 F#4 A4'), ('B1', 'A3', 'D#4', 'B3 F#4 A4 D#5')]

def pitch(note):
    if note == '-':
        return None
    m = re.fullmatch('([A-G])([#b]?)([0-7])', note)
    if not m:
        raise ValueError('Invalid score note: ' + note)
    name, accidental, octave = m.groups()
    return NOTE[name] + {'': 0, '#': 1, 'b': -1}[accidental] + 12 * int(octave) + 1

def parse_bar(text):
    events = [(pitch(n), int(d)) for n, d in (t.split(':') for t in text.split())]
    if sum((d for _, d in events)) != UNITS_PER_BAR:
        raise ValueError('Bar must contain exactly 16 sixteenths: ' + text)
    return events

def score():
    lead, echo, low, high, bass, arp = ([], [], [], [], [], [])
    for bar, (text, (root, lower, upper, figures)) in enumerate(zip(MELODY, HARMONY)):
        phrase = parse_bar(text)
        lead.extend(phrase)
        answer = next((n for n, _ in (phrase if bar % 2 else reversed(phrase)) if n is not None))
        echo.extend([(None, 6), (answer, 6), (None, 4)])
        low.append((pitch(lower), 16))
        high.append((pitch(upper), 16))
        r = pitch(root)
        bass.extend([(r, 3), (None, 1), (r + 12, 2), (r + 7, 2), (r, 4), (r + 12, 2), (None, 2)])
        notes = [pitch(n) for n in figures.split()]
        for n in notes + [notes[2], notes[1], notes[3], notes[1]]:
            arp.append((n, 2))
    return [dict(role='melody', instrument=21, gate=208, attenuation=0, events=lead), dict(role='distant answer', instrument=35, gate=192, attenuation=18, events=echo), dict(role='lower harmony', instrument=38, gate=255, attenuation=10, events=low), dict(role='upper harmony', instrument=38, gate=255, attenuation=15, events=high), dict(role='bass pulse', instrument=5, gate=168, attenuation=3, events=bass), dict(role='metallic arpeggio', instrument=34, gate=144, attenuation=12, events=arp)]

def duration(value):
    dotted = value in (3, 6, 12, 24)
    units = value * 2 // 3 if dotted else value
    if units not in (1, 2, 4, 8, 16):
        raise ValueError('Unsupported note duration: ' + str(value))
    return (dotted, 3 + int(math.log2(units)) << 5)

def compile_song(parts, base=BASE):
    if len(parts) != 6:
        raise ValueError('Use the six stock music channels, leaving effects channels free')
    data = bytearray([8] + [0] * 16)
    report = []
    for ch, part in enumerate(parts):
        if sum((d for _, d in part['events'])) != BARS * UNITS_PER_BAR:
            raise ValueError('Unequal track length: ' + part['role'])
        start = base + len(data)
        data[1 + 2 * ch:3 + 2 * ch] = start.to_bytes(2, 'little')
        if ch == 0:
            data.extend((0, TEMPO))
        data.extend((10, 192, 9, 240, 1, part['gate'], 13, -part['attenuation'] & 255, 8, 0, 12, part['instrument']))
        loop = base + len(data)
        octave = None
        for n, d in part['events']:
            dot, length = duration(d)
            if n is not None:
                if not 1 <= n < RT.KC_LEN:
                    raise ValueError('Pitch outside the driver key-code table')
                n -= INSTRUMENT_TRANSPOSE[part['instrument']]
                if not 1 <= n < RT.KC_LEN:
                    raise ValueError('Instrument-compensated pitch outside the driver table')
                shift = (n - 1) // 12 * 12
                if octave != shift:
                    data.extend((7, shift))
                    octave = shift
                key = n - shift
            else:
                key = 0
            if dot:
                data.append(6)
            data.append(length | key)
        data.extend((5, 0, *loop.to_bytes(2, 'little'), 15))
        report.append(dict(channel=ch, role=part['role'], instrument=hex(part['instrument']), attenuation=part['attenuation'], gate=part['gate'], events=len(part['events']), units=sum((d for _, d in part['events'])), start=hex(start), loop=hex(loop)))
    tracks, covered = RT.song_walk(bytes(data), base, base + len(data), base)
    if len(tracks) != 6 or covered != set(range(base, base + len(data))):
        raise ValueError('Compiled score does not walk cleanly')
    if base + len(data) > LIMIT:
        raise ValueError('Score overlaps the PC Engine effects table')
    return (bytes(data), report)

def install(sound, command=COMMAND):
    at, count = RT.arcade_table(sound)
    ptrs = RT.table_ptrs(sound, at, count)
    if command not in (36, COMMAND) or ptrs[command] != ptrs[0]:
        raise ValueError('Experiment command is not an unused stock alias')
    for instrument, transpose in INSTRUMENT_TRANSPOSE.items():
        actual = int.from_bytes(sound[RT.INSTR_ARCADE + RT.INSTR_SIZE * instrument:][:1], 'little', signed=True)
        if actual != transpose:
            raise ValueError('Instrument transposition differs from the declared stock voice')
    blob, tracks = compile_song(score())
    if any((v not in (0, 255) for v in sound[BASE:BASE + len(blob)])):
        raise ValueError('Experiment allocation is occupied')
    result = bytearray(sound)
    result[BASE:BASE + len(blob)] = blob
    result[at + 2 * command:at + 2 * command + 2] = BASE.to_bytes(2, 'little')
    allowed = set(range(BASE, BASE + len(blob))) | {at + 2 * command, at + 2 * command + 1}
    changed = {i for i in range(len(sound)) if sound[i] != result[i]}
    if not changed <= allowed or result[LIMIT:] != sound[LIMIT:]:
        raise ValueError('Experiment changed unrelated sound-ROM bytes')
    return (bytes(result), dict(title=TITLE, command=hex(command), address=hex(BASE), size=len(blob), sha256=RT.sha256(blob), tracks=tracks, changed_bytes=len(changed), instrument_definitions_unchanged=True, z80_executable_unchanged=True))

def audition(a):
    import numpy as np
    import cinematic_music as CM
    import nopack_intros as NI
    import sfx_gate as SG
    work, out = (a.workdir.resolve(), a.out.resolve())
    work.mkdir(parents=True, exist_ok=False)
    out.mkdir(parents=True, exist_ok=False)
    sound, identities = RT.load_sound(a.rom_dir.resolve())
    command = 36 if a.build else COMMAND
    if a.build:
        patched = (a.build / 'striderua/09.12b').read_bytes()
        if patched != (a.build / 'striderjr/sth_09.12a').read_bytes():
            raise ValueError('Final regions have different sound ROMs')
        blob, _ = compile_song(score())
        at, _ = RT.arcade_table(patched)
        if patched[BASE:BASE + len(blob)] != blob or patched[at + 2 * command:at + 2 * command + 2] != BASE.to_bytes(2, 'little'):
            raise ValueError('Final sound ROM does not contain the declared native score')
        _, patch = install(sound, command)
    else:
        patched, patch = install(sound, command)
    roms = work / 'roms'
    roms.mkdir()
    for set_name in ('strider', 'striderua'):
        target = roms / set_name
        target.mkdir()
        directory = a.rom_dir.resolve() / set_name
        if directory.is_dir():
            for path in directory.iterdir():
                if path.is_file():
                    shutil.copy2(path, target / path.name)
        else:
            source = next((a.rom_dir.resolve() / (set_name + ext) for ext in ('.zip', '.7z') if (a.rom_dir.resolve() / (set_name + ext)).is_file()), None)
            if source is None:
                raise ValueError('Missing canonical MAME input: ' + set_name)
            subprocess.run(['7zz', 'e', '-y', '-o' + str(target), str(source)], check=True, capture_output=True)
    (roms / 'striderua/09.12b').write_bytes(patched)
    r = SG.run(a.mame, roms, 'striderua', work / 'run', [command, 241], 120.0)
    t0 = r['slots'][0][1]
    notes = CM.phrase_notes(r['ym'], t0, t0 + 120)
    loops = []
    for ch in range(6):
        events = [(t, c, n) for t, c, n in notes if c == ch]
        period = NI.find_loop(events)
        loops.append(dict(channel=ch, notes=len(events), last_note_s=round(events[-1][0], 4), loop_start_s=round(period[0], 4) if period else None, period_s=round(period[1], 4) if period else None))
    period = loops[0]['period_s']
    score_checks = []
    for ch, part in enumerate(score()):
        expected = [sound[RT.KC_ARCADE + n] for n, _ in part['events'] if n is not None]
        actual = [n for _, c, n in notes if c == ch]
        exact = len(actual) >= 3 * len(expected) and all((n == expected[k % len(expected)] for k, n in enumerate(actual)))
        score_checks.append(dict(channel=ch, notes_per_loop=len(expected), complete_loops_checked=len(actual) // len(expected), pitches_match_score=exact))
    a0, b0 = SG.window(r, 0, 120)
    pcm = r['mix'][a0:b0] / 32768.0
    windows = pcm[:len(pcm) // 12000 * 12000].reshape(-1, 12000)
    rms_db = 20 * np.log10(np.sqrt((windows ** 2).mean(1)) + 1e-12)
    stop_at = r['slots'][1][1]
    after = r['mix'][int((stop_at + 3) * SG.SR):int((stop_at + 8) * SG.SR)] / 32768.0
    stop_db = float(20 * np.log10(np.sqrt((after ** 2).mean()) + 1e-12))
    passed = bool(period and 30 < period < 45 and all((row['last_note_s'] > 115 for row in loops)) and all((row['period_s'] and abs(row['period_s'] - period) < 0.01 for row in loops)) and all((row['pitches_match_score'] for row in score_checks)) and (float(rms_db.min()) > -60) and (stop_db < -60))
    peak_db = float(20 * np.log10(abs(pcm).max() + 1e-12))
    preview_gain_db = -2.0 - peak_db
    target = out / 'shadow-signal.mp3'
    subprocess.run(['ffmpeg', '-v', 'error', '-y', '-ss', str(t0), '-i', str(work / 'run/mix.wav'), '-t', '85', '-af', f'volume={preview_gain_db:.5f}dB', '-codec:a', 'libmp3lame', '-b:a', '192k', str(target)], check=True)
    report = dict(schema='striderex-original-cinematic/1', title=TITLE, experiment=True, qualified_game_change=False, inputs=identities, patch=patch, bars=BARS, tempo_byte=hex(TEMPO), passed=passed, playback=loops, score_checks=score_checks, quietest_quarter_second_dbfs=round(float(rms_db.min()), 3), peak_dbfs=round(peak_db, 3), preview_gain_db=round(preview_gain_db, 3), stop_tail_dbfs=round(stop_db, 3), native_sample_rate=SG.SR, mame_sha256=RT.sha256(Path(shutil.which(str(a.mame)) or a.mame).read_bytes()), script_sha256=RT.sha256(Path(__file__).read_bytes()), probe_sha256=RT.sha256(SG.LUA.read_bytes()), sound_rom_sha256=RT.sha256(patched), final_build=bool(a.build), file=target.name, mp3_sha256=RT.sha256(target.read_bytes()))
    (out / 'audition.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2), flush=True)
    return 0 if passed else 1

def self_test(rom_dir=None):
    parts = score()
    blob, tracks = compile_song(parts)
    assert len(tracks) == 6 and len(blob) < LIMIT - BASE
    assert all((t['units'] == 256 for t in tracks))
    assert pitch('C4') == 49 and pitch('F#3') == 43 and (pitch('-') is None)
    assert duration(6) == (True, 160) and duration(16) == (False, 224)
    bad = score()
    bad[0]['events'] = bad[0]['events'][:-1]
    try:
        compile_song(bad)
    except ValueError:
        pass
    else:
        raise AssertionError('Unequal channel lengths accepted')
    if rom_dir:
        sound, _ = RT.load_sound(rom_dir.resolve())
        for command in (36, 37):
            result, installed = install(sound, command)
            assert result[LIMIT:] == sound[LIMIT:] and installed['sha256'] == RT.sha256(blob)
        at, _ = RT.arcade_table(sound)
        for where in (BASE, at + 2 * 36, RT.INSTR_ARCADE + RT.INSTR_SIZE * 38):
            bad = bytearray(sound)
            bad[where] ^= 66
            try:
                install(bytes(bad), 36)
            except ValueError:
                pass
            else:
                raise AssertionError('Unsafe score placement or altered instrument accepted')
    print('self-test PASS:', TITLE, len(blob), 'sequence bytes')

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--self-test', action='store_true')
    p.add_argument('--rom-dir', type=Path)
    p.add_argument('--build', type=Path, help="measure both regions' exact final sound ROM on game command 0x24")
    p.add_argument('--workdir', type=Path)
    p.add_argument('--out', type=Path)
    p.add_argument('--mame', default='mame')
    a = p.parse_args()
    if a.self_test:
        self_test(a.rom_dir)
        return 0
    if any((value is None for value in (a.rom_dir, a.workdir, a.out))):
        p.error('--rom-dir, --workdir and --out are required')
    return audition(a)
if __name__ == '__main__':
    raise SystemExit(main())
