"""Portable inverse and qualification binding for the post-Kit-y desert fixes."""
import argparse
from copy import deepcopy
import json
from pathlib import Path
import struct
import sys
import zipfile
sys.path.insert(0, str(Path(__file__).resolve().parent))
import boss_followup_release as BF
STAGES = ('platforms', 'reading', 'poles', 'pixels', 'wall')
REPORTS = ('desert_platforms', 'commander_voice', 'commander_reading', 'desert_poles', 'hiryu_pixels', 'desert_wall_edge', 'gameplay_music_build', 'gameplay_music_gate', 'desert_followup_fresh', 'desert_visual_fresh')
PIXELS = {1845: ((8, 0), (9, 0), (10, 0)), 1974: ((0, 0), (0, 1), (0, 2), (0, 3)), 5173: ((0, 15),), 5315: ((0, 15),)}
GFX = {'striderua': ('st-2.8a', 'st-11.10a', 'st-5.4a', 'st-9.6a'), 'striderjr': ('sth_01.3a', 'sth_02.4a', 'sth_03.5a', 'sth_04.6a')}

def restore_graphics(bundle, machine, files):
    result = {n: bytearray(files[n]) for n in GFX[machine]}
    for code, points in PIXELS.items():
        for x, y in points:
            bit = y * 64 + (x if x < 8 else 32 + x - 8)
            for plane in (24, 16, 8, 0):
                pos = code * 128 + (bit + plane) // 8
                lane = pos % 8 // 2
                member = GFX[machine][lane]
                at = pos // 8 * 2 + pos % 2
                mask = 128 >> (bit + plane) % 8
                if not result[member][at] & mask:
                    raise ValueError('cleared Hiryu pixel is no longer transparent')
                result[member][at] &= ~mask
    if {n: BF.sha(b) for n, b in result.items()} != bundle['graphics_sources'][machine]:
        raise ValueError('native graphics do not restore to exact canonical Kit-y members')

def restore(bundle, members):
    if bundle.get('schema') != 'striderex-desert-followup/1' or BF.hashes(members) != bundle['build_files']:
        raise ValueError('wrong desert follow-up or final ROM identities')
    if [s['name'] for s in bundle['stages']] != list(STAGES):
        raise ValueError('missing desert follow-up stage')
    files = {m: dict(f) for m, f in members.items()}
    for stage in reversed(bundle['stages']):
        if BF.hashes(files) != stage['after']:
            raise ValueError('desert stage output differs')
        for m, f in files.items():
            added = stage['added'].get(m, [])
            if added:
                if stage['name'] != 'pixels' or set(added) != set(GFX[m]):
                    raise ValueError('unexpected added ROM member')
                restore_graphics(bundle, m, f)
            for n, rows in stage['reverse'].get(m, {}).items():
                f[n] = BF.reverse(f[n], rows)
            for n in added:
                del f[n]
        if BF.hashes(files) != stage['before']:
            raise ValueError('desert inverse changed unrelated bytes')
    if BF.hashes(files) != bundle['baseline_files']:
        raise ValueError('Kit y was not recovered exactly')
    return files

def restore_pack(bundle, data):
    p = bundle['pack']
    h, t, index, audio = BF.pack_sections(data)
    if BF.sha(data) != p['sha256']:
        raise ValueError('new pack identity differs')
    header = bytes.fromhex(p['original_header'])
    old = BF.HDR.unpack_from(header)
    if h[:10] != old[:10] or h[10] != old[10] + 2 or data[140:4096] != header[140:4096]:
        raise ValueError('pack protocol or track count changed')
    if t[3 * 4:4 * 4] != t[4:8]:
        raise ValueError('cue 03 must share the exact accepted 01 row')
    for cue, track in ((121, old[10]), (122, old[10] + 1)):
        if t[cue * 4:cue * 4 + 4] != bytes((1, track & 255, 127, 1 | track >> 8 << 4)):
            raise ValueError('desert cue is not a suppressed arranged loop')
        entry = index[track * 32:track * 32 + 32]
        if entry.hex() != p['added_tracks'][str(cue)]['index']:
            raise ValueError('loop metadata differs')
        off, size, *_ = struct.unpack('<IIIIIIHBBhh', entry)
        if BF.sha(audio[off:off + size]) != p['added_tracks'][str(cue)]['audio_sha256']:
            raise ValueError('arranged loop bytes differ')
    triggers = bytearray(t)
    for cue, row in p['original_rows'].items():
        at = int(cue) * 4
        triggers[at:at + 4] = bytes.fromhex(row)
    oldindex = index[:old[10] * 32]
    recovered = header + triggers + oldindex + bytes(old[11] - old[9] - len(oldindex)) + audio[:old[12]]
    BF.pack_sections(recovered)
    if BF.sha(recovered) != p['source_sha256']:
        raise ValueError('Kit-y pack did not recover exactly')
    return recovered

def validate(bundle, boss, music, qualifications, rtl, expected, core_sha):
    if expected != bundle['build_files'] or core_sha != bundle['core_sha256'] or BF.jsha(boss) != bundle['baseline_boss_sha256'] or (BF.jsha(music) != bundle['baseline_cinematic_sha256']) or (BF.jsha(qualifications) != bundle['baseline_qualification_sha256']) or (BF.jsha(rtl) != bundle['baseline_rtl_sha256']) or (bundle['baseline_files'] != boss['build_files']):
        raise ValueError('inherited qualification or core changed')
    q = bundle['reports']
    s = bundle['stages']
    base = bundle['baseline_files']
    if set(q) != set(REPORTS) or any((not r.get('passed') or r.get('hardware_review_granted') for r in q.values())):
        raise ValueError('desert focused qualification is missing or claims hardware approval')
    pairs = {'desert_platforms': (base, s[1]['after']), 'desert_poles': (s[1]['after'], s[2]['after']), 'hiryu_pixels': (s[2]['after'], s[3]['after']), 'desert_wall_edge': (s[3]['after'], s[4]['after'])}
    for name, (old, new) in pairs.items():
        if q[name]['input_files'] != {'control': old, 'candidate': new}:
            raise ValueError('focused inputs differ: ' + name)
    for name in ('commander_voice', 'commander_reading'):
        if q[name]['input_files'] != s[1]['after'] or len(q[name]['results']) != 8 or any((not r['passed'] for r in q[name]['results'])):
            raise ValueError('commander region/voice coverage differs')
    if q['commander_voice']['pack_sha256'] != bundle['pack']['sha256']:
        raise ValueError('voice check used another final pack')
    if q['commander_reading']['extra_vblanks'] != 72 or any((r['extra_full_brightness_ticks'] != 72 or r['scene_frames'] != 698 for r in q['commander_reading']['results'])):
        raise ValueError('commander reading extension differs')
    if len(q['desert_platforms']['checks']) != 18 or not all((r['passed'] for r in q['desert_platforms']['checks'])):
        raise ValueError('missing platform catches or landings')
    for name, count in (('desert_poles', 4), ('desert_wall_edge', 26)):
        if len(q[name]['results']) != count or any((not r['passed'] for r in q[name]['results'])):
            raise ValueError('missing contact checks')
    if q['desert_poles']['shift_toward_art_pixels'] != 18:
        raise ValueError('pole contact differs')
    if not q['desert_wall_edge']['all_twelve_pan_residues_checked']:
        raise ValueError('wall edge residue coverage missing')
    if len(q['hiryu_pixels']['static']) != 2 or len(q['hiryu_pixels']['runtime']) != 2:
        raise ValueError('pixel regional coverage missing')
    for row in q['hiryu_pixels']['static']:
        if row['matrices'] != 249 or row['detached_components_before'] != 4 or row['detached_components_after'] != 0 or (not row['exactly_nine_black_pixels_cleared']):
            raise ValueError('pixel census differs')
    gm, gate = (q['gameplay_music_build'], q['gameplay_music_gate'])
    if gm['source_pack_sha256'] != bundle['pack']['source_sha256'] or gm['pack_sha256'] != bundle['pack']['sha256'] or gate['pack_sha256'] != gm['pack_sha256'] or (len(gate['coverage']) != 29) or any((not r['passed'] for r in gate['coverage'])) or (gm['changed_cues'] != ['0x3', '0x79', '0x7a']):
        raise ValueError('arranged cue coverage differs')
    if q['desert_visual_fresh']['results'][-1]['files'] != expected:
        raise ValueError('fresh reproduction differs')
    smoke = bundle['smoke']
    if not smoke['passed'] or smoke['input_files'] != expected or smoke['pack_sha256'] != bundle['pack']['sha256']:
        raise ValueError('final combination smoke input differs')
    if {r['machine'] for r in smoke['results']} != {'striderua', 'striderjr'} or any((not r['passed'] for r in smoke['results'])):
        raise ValueError('final regional smoke missing')
    return True

def prepare(a):
    root = Path(__file__).resolve().parents[3]
    sys.path.insert(0, str(root / 'release'))
    import private_mister as PM
    PM.verify(a.previous_kit)
    with PM.qualified_view(a.previous_kit) as view:
        original = json.loads((view / 'producer.json').read_text())
        before = {}
        for m, inv in original['build_files'].items():
            reg = 'us' if m == 'striderua' else 'jp'
            with zipfile.ZipFile(view / f'games/mame/striderex_{reg}.zip') as z:
                before[m] = {n: z.read(n) for n in inv}
        with zipfile.ZipFile(view / 'games/CPS+/strider_ex.zip') as z:
            oldpack = z.read('strider_ex.cpk')
        core = (view / original['core']['file']).read_bytes()
    stages = []
    for name, path in zip(STAGES, a.stage):
        meta = json.loads((path / 'build.json').read_text())
        after = {m: {n: (path / m / n).read_bytes() for n in s['files']} for m, s in meta['sets'].items()}
        if BF.hashes(after) != {m: s['files'] for m, s in meta['sets'].items()}:
            raise ValueError('stage member changed')
        stages.append(dict(name=name, before=BF.hashes(before), after=BF.hashes(after), added={m: sorted(set(f) - set(before[m])) for m, f in after.items()}, reverse={m: {n: BF.delta(before[m][n], b) for n, b in f.items() if n in before[m] and b != before[m][n]} for m, f in after.items()}))
        before = after
    data = a.pack.read_bytes()
    _, t, index, audio = BF.pack_sections(data)
    old = BF.HDR.unpack_from(oldpack)
    tracks = {}
    for cue, track in ((121, old[10]), (122, old[10] + 1)):
        entry = index[track * 32:track * 32 + 32]
        off, size, *_ = struct.unpack('<IIIIIIHBBhh', entry)
        tracks[str(cue)] = dict(index=entry.hex(), audio_sha256=BF.sha(audio[off:off + size]))
    reports = {n: json.loads((a.reports / (n + '_20261025.json')).read_text()) for n in REPORTS}
    bundle = dict(schema='striderex-desert-followup/1', passed=True, previous_test_id=PM.verify(a.previous_kit)['test_id'], baseline_files=original['build_files'], build_files=BF.hashes(before), stages=stages, build_sets=meta['sets'], reports=reports, graphics_sources={m: {n: original['archives'][f"games/mame/striderex_{('us' if m == 'striderua' else 'jp')}.zip"][n] for n in names} for m, names in GFX.items()}, core_sha256=BF.sha(core), baseline_boss_sha256=BF.jsha(original['boss_followup']), baseline_cinematic_sha256=BF.jsha(original['cinematic_music']), baseline_qualification_sha256=BF.jsha(original['qualification']), baseline_rtl_sha256=BF.jsha(original['rtl']), smoke=json.loads(a.smoke.read_text()), pack=dict(sha256=BF.sha(data), source_sha256=BF.sha(oldpack), original_header=oldpack[:4096].hex(), original_rows={str(c): oldpack[4096 + c * 4:4096 + c * 4 + 4].hex() for c in (3, 121, 122)}, added_tracks=tracks), hardware_review_granted=False)
    restore(bundle, before)
    restore_pack(bundle, data)
    validate(bundle, original['boss_followup'], original['cinematic_music'], original['qualification'], original['rtl'], BF.hashes(before), BF.sha(core))
    a.out.mkdir(parents=True, exist_ok=False)
    for key, value in original['cinematic_music'].items():
        (a.out / (key + '.json')).write_text(json.dumps(value, indent=2) + '\n')
    for key, value in original['qualification'].items():
        (a.out / ('qualification-' + key + '.json')).write_text(json.dumps(value, indent=2) + '\n')
    for key, value in (('rtl', original['rtl']), ('boss-followup', original['boss_followup']), ('desert-followup', bundle)):
        (a.out / (key + '.json')).write_text(json.dumps(value, indent=2) + '\n')
    (a.out / 'core.rbf').write_bytes(core)
    p = a.out / 'pack'
    p.mkdir()
    (p / 'strider_ex.cpk').write_bytes(data)
    (p / 'strider_ex.build.json').write_text(json.dumps(dict(sha256=BF.sha(data), english_voices=True)) + '\n')
    print('PASS: exact Kit-y ROM/graphics/pack recovery; focused checks and final smoke bound')

def check(a):
    import cinematic_followup as CF
    b = json.loads(a.bundle.read_text())
    meta = json.loads((a.build / 'build.json').read_text())
    files = {m: {n: (a.build / m / n).read_bytes() for n in s['files']} for m, s in meta['sets'].items()}
    boss = json.loads((a.inputs / 'boss-followup.json').read_text())
    music = {n: json.loads((a.inputs / (n + '.json')).read_text()) for n in ('proof', 'runtime', 'census', 'loop', 'tip_runtime', 'tip_render')}
    quals = {n: json.loads((a.inputs / ('qualification-' + n + '.json')).read_text()) for n in ('fixes', 'audio', 'combined')}
    rtl = json.loads((a.inputs / 'rtl.json').read_text())
    core = BF.sha((a.inputs / 'core.rbf').read_bytes())
    pack = a.pack.read_bytes()

    def verify(bundle, members, data):
        validate(bundle, boss, music, quals, rtl, BF.hashes(members), core)
        previous = restore(bundle, members)
        oldpack = restore_pack(bundle, data)
        BF.validate(boss, music, quals, rtl, BF.hashes(previous), core)
        original = BF.restore(boss, previous)
        BF.restore_pack(boss, oldpack)
        CF.validate_qualification(music, quals, rtl, BF.hashes(original))
        CF.verify(music['proof'], original)
    verify(b, files, pack)
    tests = []
    for name in ('unrelated-program', 'native-gfx', 'bad-inverse', 'missing-platform', 'missing-voice', 'short-reading', 'wrong-pole', 'missing-pixel-region', 'missing-wall-case', 'missing-smoke', 'missing-fresh', 'changed-pack'):
        bad = deepcopy(b)
        members = {m: dict(f) for m, f in files.items()}
        data = pack
        if name in ('unrelated-program', 'native-gfx'):
            n = 'strex_p6.bin' if name == 'unrelated-program' else GFX['striderua'][0]
            v = bytearray(members['striderua'][n])
            v[7] ^= 1
            members['striderua'][n] = bytes(v)
        elif name == 'bad-inverse':
            next(iter(bad['stages'][0]['reverse']['striderua'].values()))[0]['after_sha256'] = '0' * 64
        elif name == 'missing-platform':
            bad['reports']['desert_platforms']['checks'].pop()
        elif name == 'missing-voice':
            bad['reports']['commander_voice']['results'].pop()
        elif name == 'short-reading':
            bad['reports']['commander_reading']['results'][0]['extra_full_brightness_ticks'] = 0
        elif name == 'wrong-pole':
            bad['reports']['desert_poles']['shift_toward_art_pixels'] = 0
        elif name == 'missing-pixel-region':
            bad['reports']['hiryu_pixels']['runtime'].pop()
        elif name == 'missing-wall-case':
            bad['reports']['desert_wall_edge']['results'].pop()
        elif name == 'missing-smoke':
            bad['smoke']['results'].pop()
        elif name == 'missing-fresh':
            bad['reports']['desert_visual_fresh']['results'][-1]['files'] = {}
        else:
            data = bytearray(pack)
            data[-1] ^= 1
            data = bytes(data)
        try:
            verify(bad, members, data)
        except (ValueError, KeyError) as e:
            tests.append(dict(name=name, rejected=True, reason=str(e)))
        else:
            raise ValueError('damaged control accepted: ' + name)
    report = dict(schema='striderex-desert-followup-acceptance/1', passed=True, previous_test_id=b['previous_test_id'], build_files=b['build_files'], pack_sha256=b['pack']['sha256'], exact_prior_rom_graphics_and_pack_recovery=True, negative_controls=tests, hardware_review_granted=False)
    a.receipt.write_text(json.dumps(report, indent=2) + '\n')
    print('PASS: exact inheritance and all twelve damaged controls rejected')

def self_test():
    m = 'striderua'
    fixed = {n: bytes([255]) * 524288 for n in GFX[m]}
    original = {n: bytearray(v) for n, v in fixed.items()}
    for code, points in PIXELS.items():
        for x, y in points:
            bit = y * 64 + (x if x < 8 else 32 + x - 8)
            for plane in (24, 16, 8, 0):
                pos = code * 128 + (bit + plane) // 8
                original[GFX[m][pos % 8 // 2]][pos // 8 * 2 + pos % 2] &= ~(128 >> (bit + plane) % 8)
    bundle = {'graphics_sources': {m: {n: BF.sha(v) for n, v in original.items()}}}
    restore_graphics(bundle, m, fixed)
    damaged = dict(fixed)
    v = bytearray(damaged[GFX[m][0]])
    v[7] ^= 1
    damaged[GFX[m][0]] = bytes(v)
    try:
        restore_graphics(bundle, m, damaged)
    except ValueError:
        pass
    else:
        raise AssertionError('unrelated graphics change accepted')
    print('PASS: exact nine-pixel physical ROM inverse; unrelated graphics change rejected')
if __name__ == '__main__':
    if sys.argv[1:] == ['--self-test']:
        self_test()
        sys.exit(0)
    if sys.argv[1:2] == ['check']:
        p = argparse.ArgumentParser(description='Check inherited qualification and damaged controls')
        for name in ('bundle', 'build', 'inputs', 'pack', 'receipt'):
            p.add_argument('--' + name, type=Path, required=True)
        check(p.parse_args(sys.argv[2:]))
        sys.exit(0)
    p = argparse.ArgumentParser(description=__doc__)
    for name in ('previous-kit', 'reports', 'pack', 'smoke', 'out'):
        p.add_argument('--' + name, type=Path, required=True)
    p.add_argument('--stage', type=Path, action='append', required=True)
    a = p.parse_args()
    if len(a.stage) != 5:
        p.error('five ordered stages required')
    prepare(a)
