"""Portable independent Strider EX kit ROM/MRA checks (standard library only)."""
import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import sys
import xml.etree.ElementTree as ET
import zipfile
sys.dont_write_bytecode = True

def digest(data):
    return hashlib.sha256(data).hexdigest()

def archive_paths(root, text, archives):
    """Resolve only this MRA's archives; regional sets share member names."""
    paths = []
    for node in ET.fromstring(text).iter():
        for reference in node.get('zip', '').split('|'):
            if not reference:
                continue
            matches = [root / relative for relative in archives if PurePosixPath(relative).name == PurePosixPath(reference).name]
            if len(matches) != 1:
                raise ValueError('Missing or ambiguous declared archive: ' + reference)
            if matches[0] not in paths:
                paths.append(matches[0])
    return paths

def verify(root):
    sys.path.insert(0, str(root))
    import mra_assembly
    receipt = json.loads((root / 'producer.json').read_text())
    for relative, expected in receipt['archives'].items():
        with zipfile.ZipFile(root / relative) as z:
            got = {n: digest(z.read(n)) for n in z.namelist()}
        if got != expected:
            raise ValueError('Archive members differ: ' + relative)
    for name, expected in receipt['mras'].items():
        path = root / '_Arcade' / (name + '.mra')
        text = path.read_text()
        image = mra_assembly.assemble(text, mra_assembly.ZipSource(archive_paths(root, text, receipt['archives'])))
        if digest(image) != expected['assembled_sha256']:
            raise ValueError('Assembled image differs: ' + name)
        flag = image[64 + (2097151 ^ 1)]
        magic = bytes((image[64 + (i ^ 1)] for i in range(2097136, 2097146)))
        if flag != expected['flag'] or magic != b'STRIDER-EX':
            raise ValueError('Flag/identity differs: ' + name)
        if ET.fromstring(text).findtext('rbf') != receipt['rbf']:
            raise ValueError('Core binding differs: ' + name)
        print('PASS', name, f'flag={flag:#04x}')
    core = root / receipt['core']['file']
    if digest(core.read_bytes()) != receipt['core']['sha256']:
        raise ValueError('Core bytes differ')
    for name, q in receipt['qualification'].items():
        if not q['passed'] or not q['results'] or any((not r['passed'] or r['exit_code'] for r in q['results'])):
            raise ValueError('Incomplete qualification: ' + name)
        if {r['name'] for r in q['results']} != set(receipt['required_jobs'][name]):
            raise ValueError('Missing qualification jobs: ' + name)
    if receipt.get('cinematic_music'):
        import cinematic_followup as CF
        members = {}
        for machine, files in receipt['build_files'].items():
            region = 'us' if machine == 'striderua' else 'jp'
            with zipfile.ZipFile(root / ('games/mame/striderex_' + region + '.zip')) as z:
                members[machine] = {n: z.read(n) for n in files}
        expected = receipt['build_files']
        with zipfile.ZipFile(root / 'games/CPS+/strider_ex.zip') as z:
            pack = z.read('strider_ex.cpk')
        if receipt.get('desert_followup'):
            import desert_followup_release as DF
            b = receipt['desert_followup']
            DF.validate(b, receipt['boss_followup'], receipt['cinematic_music'], receipt['qualification'], receipt['rtl'], expected, receipt['core']['sha256'])
            members = DF.restore(b, members)
            expected = b['baseline_files']
            pack = DF.restore_pack(b, pack)
            print('PASS desert follow-up: exact Kit-y graphics/ROM/pack recovery; all focused checks and final smoke')
        if receipt.get('boss_followup'):
            import boss_followup_release as BF
            b = receipt['boss_followup']
            BF.validate(b, receipt['cinematic_music'], receipt['qualification'], receipt['rtl'], expected, receipt['core']['sha256'])
            members = BF.restore(b, members)
            expected = b['baseline_files']
            BF.restore_pack(b, pack)
            print('PASS boss/desert follow-up: exact prior ROM/pack recovery, voices, girder, masks, text and held Start')
        CF.verify(receipt['cinematic_music']['proof'], members)
        CF.validate_qualification(receipt['cinematic_music'], receipt['qualification'], receipt['rtl'], expected)
        print('PASS cinematic follow-up: exact baseline reconstruction, full scenes, skips and sound census')
    print('PASS independent ROM, MRA, core and qualification checks')

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root', type=Path, default=Path(__file__).resolve().parent)
    a = p.parse_args()
    verify(a.root.resolve())
if __name__ == '__main__':
    main()
