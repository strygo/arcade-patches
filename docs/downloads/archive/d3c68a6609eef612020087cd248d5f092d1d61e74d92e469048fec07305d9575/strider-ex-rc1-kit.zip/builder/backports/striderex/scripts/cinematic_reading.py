"""Build the native final-page pause from fresh, verified Kit v reconstruction."""
import argparse
from copy import deepcopy
import json
from pathlib import Path
import struct
import subprocess
import sys
import cinematic_followup as CF
import cinematic_reading_audit as A
ROOT = Path(__file__).resolve().parents[3]
ASM = ROOT / 'backports/striderex/asm'
OFF = (1851, 1340, 1712, 1385, 0, 1193)
HOLD = (1851, 1340, 1712, 1385, 0, 1169)
FADE = (1698, 1177, 1619, 1218, 1957, 1009)
SCENES = ('brief_st_petersburg', 'brief_siberia', 'brief_amazon', 'brief_aerial', 'welcome_meio', 'intro_desert')

def contract(bank, spec, scenes):
    from reconstruct_private_build import decode_scene
    table = A.schedule_table(bank, bool(spec['region_en']))
    for index, scene in enumerate(scenes):
        if scene['id'] not in SCENES:
            continue
        stage = SCENES.index(scene['id'])
        for lang in (0, 1):
            pointer = struct.unpack_from('>I', bank, table + 8 * index + 4 * lang)[0]
            rows = A.schedule(bank, pointer)
            on, page = next((r for r in reversed(rows) if r[1]))
            off = next((r for r, p in rows if r > on and (not p)))
            if OFF[stage] and off != OFF[stage]:
                raise ValueError('final caption timing changed')
        _, records = decode_scene(bank[spec['streams'][scene['id']] - 1048576:])
        if len(records) - 210 != FADE[stage]:
            raise ValueError('native fade source timing changed')
        if HOLD[stage] and min(OFF[stage], A.terminal_fade(A.palette_energy(records), on) or OFF[stage]) != HOLD[stage]:
            raise ValueError('reading pause must precede caption clear and terminal dimming')

def build(a):
    base = json.loads((a.build / 'build.json').read_text())
    if base.get('reconstructed_from_verified_export') != '261025-08':
        raise ValueError('start with a fresh verified Kit v reconstruction')
    result = deepcopy(base)
    result.pop('reconstructed_from_verified_export')
    out = a.out.resolve()
    out.mkdir(parents=True, exist_ok=False)
    work = out / 'assembly'
    work.mkdir()
    header = (ASM / 'ex_bank.s').read_text().split('        org     $100000')[0]
    wrapper = work / 'reading.s'
    wrapper.write_text(header + '\nnp_fade_tick equ $1FF000\n org $1FF200\n include "native_reading.s"\n')
    for machine, spec in base['sets'].items():
        target = out / machine
        target.mkdir()
        binary = work / (machine + '.bin')
        subprocess.run([str(a.vasm.resolve()), '-Fbin', '-m68000', '-quiet', '-DREGION_EN=' + str(spec['region_en']), '-I', str(ASM), '-o', str(binary), str(wrapper)], check=True)
        code = binary.read_bytes()
        if len(code) != CF.READING_SIZE or CF.sha(code) != CF.READING_HELPER[machine]:
            raise ValueError('assembled reading helper differs from the portable byte contract')
        for name, digest in spec['files'].items():
            data = (a.build / machine / name).read_bytes()
            if CF.sha(data) != digest:
                raise ValueError('input member changed')
            if name == 'strex_p6.bin':
                if digest != CF.READING_PREVIOUS_BANK[machine]:
                    raise ValueError('not the qualified Kit v bank')
                raw = bytearray((data[i ^ 1] for i in range(len(data))))
                contract(raw, spec, base['scenes'])
                start = CF.READING_START
                step = CF.READING_STEP[machine]
                call = CF.NATIVE_FADE_CALL[machine] - 1048576
                if raw[start:start + len(code)] != b'\xff' * len(code):
                    raise ValueError('reading helper overlaps data')
                raw[start:start + len(code)] = code
                raw[step:step + 10] = bytes.fromhex('4ef9001ff2804e714e71')
                raw[call:call + 6] = bytes.fromhex('4eb9001ff200')
                data = bytes((raw[i ^ 1] for i in range(len(raw))))
                if CF.reverse_reading(data, machine, name) != (a.build / machine / name).read_bytes():
                    raise ValueError('not an exact reversible Kit v follow-up')
                result['sets'][machine]['native_reading'] = dict(address=2093568, end=2093824, hold_frames=120, pause_records=list(HOLD), caption_off_records=list(OFF), fade_elapsed_records=[f + 120 if o else f for f, o in zip(FADE, HOLD)])
                result['sets'][machine]['ex_bank_bytes_used'] = 1045248
            (target / name).write_bytes(data)
            result['sets'][machine]['files'][name] = CF.sha(data)
    (out / 'build.json').write_text(json.dumps(result, indent=2) + '\n')
    receipt = dict(schema='striderex-reading-build/1', passed=True, source_test_id='261025-08', input_files={m: s['files'] for m, s in base['sets'].items()}, build_files={m: s['files'] for m, s in result['sets'].items()}, source_sha256=CF.sha((ASM / 'native_reading.s').read_bytes()), assembler_sha256=CF.sha(a.vasm.read_bytes()), helper_sha256=CF.READING_HELPER, hold_frames=120, exact_kit_v_reversal=True, changes_only_bank_helper_and_two_entries=True, hardware_review_granted=False)
    (out / 'reading-build.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print('PASS: final-page pause compiled; every other byte preserved')

def proof(a):
    sys.path.insert(0, str(ROOT / 'release'))
    import private_mister as PM
    record = PM.verify(a.previous_kit.resolve())
    if record['test_id'] != '261025-08':
        raise ValueError('reading follow-up requires sealed Kit v')
    with PM.qualified_view(a.previous_kit.resolve()) as view:
        producer = json.loads((view / 'producer.json').read_text())
    previous = producer['cinematic_music']
    meta = json.loads((a.build / 'build.json').read_text())
    result = deepcopy(previous['proof'])
    result.update(schema='striderex-cinematic-inheritance/7', previous=previous, previous_test_id='261025-08', build_files={m: s['files'] for m, s in meta['sets'].items()}, passed=True)
    for machine, spec in meta['sets'].items():
        result['regions'][machine]['native_reading'] = spec['native_reading']
    members = {m: {n: (a.build / m / n).read_bytes() for n in s['files']} for m, s in meta['sets'].items()}
    CF.verify(result, members)
    a.receipt.write_text(json.dumps(result, indent=2) + '\n')
    print('PASS: exact Kit v recovery and all preceding cinematic/Earth proofs')

def delivery_inputs(a):
    import zipfile
    sys.path.insert(0, str(ROOT / 'release'))
    import private_mister as PM
    record = PM.verify(a.previous_kit.resolve())
    if record['test_id'] != '261025-08':
        raise ValueError('need the qualified Kit v delivery inputs')
    out = a.out.resolve()
    out.mkdir(parents=True, exist_ok=False)
    with PM.qualified_view(a.previous_kit.resolve()) as view:
        producer = json.loads((view / 'producer.json').read_text())
        for suite, receipt in producer['qualification'].items():
            (out / ('qualification-' + suite + '.json')).write_text(json.dumps(receipt, indent=2) + '\n')
        (out / 'rtl.json').write_text(json.dumps(producer['rtl'], indent=2) + '\n')
        for label in ('runtime', 'census', 'loop'):
            (out / (label + '.json')).write_text(json.dumps(producer['cinematic_music'][label], indent=2) + '\n')
        core = (view / producer['core']['file']).read_bytes()
        if CF.sha(core) != producer['core']['sha256']:
            raise ValueError('core changed')
        (out / 'core.rbf').write_bytes(core)
        with zipfile.ZipFile(view / 'games/CPS+/strider_ex.zip') as z:
            pack = z.read('strider_ex.cpk')
        expected = producer['qualification']['combined']['inputs']['pack_sha256']
        if CF.sha(pack) != expected or not any(('[English voices]' in n for n in producer['mras'])):
            raise ValueError('missing the exact qualified bilingual pack')
        folder = out / 'pack'
        folder.mkdir()
        (folder / 'strider_ex.cpk').write_bytes(pack)
        (folder / 'strider_ex.build.json').write_text(json.dumps(dict(sha256=expected, english_voices=True, reconstructed_from_verified_test='261025-08'), indent=2) + '\n')
    print('PASS: pack, core and unchanged qualification inputs recovered from sealed Kit v')

def check(a):
    sys.path.insert(0, str(ROOT / 'release'))
    import private_mister as PM
    proof = json.loads(a.proof.read_text())
    runtime = json.loads(a.runtime_report.read_text())
    meta = json.loads((a.build / 'build.json').read_text())
    members = {m: {n: (a.build / m / n).read_bytes() for n in s['files']} for m, s in meta['sets'].items()}
    with PM.qualified_view(a.previous_kit.resolve()) as view:
        producer = json.loads((view / 'producer.json').read_text())
    bundle = dict(proof['previous'], proof=proof, reading_runtime=runtime)

    def validate(b, files):
        CF.verify(b['proof'], files)
        CF.validate_qualification(b, producer['qualification'], producer['rtl'], proof['build_files'])
    validate(bundle, members)
    negatives = []
    for label, at in (('helper', CF.READING_START), ('step-entry', CF.READING_STEP['striderua']), ('sound-entry', CF.NATIVE_FADE_CALL['striderua'] - 1048576), ('unrelated-bank-byte', 1792)):
        files = {m: dict(f) for m, f in members.items()}
        data = bytearray(files['striderua']['strex_p6.bin'])
        data[at ^ 1] ^= 1
        files['striderua']['strex_p6.bin'] = bytes(data)
        damaged = deepcopy(bundle)
        damaged['proof']['build_files']['striderua']['strex_p6.bin'] = CF.sha(data)
        try:
            validate(damaged, files)
        except ValueError:
            negatives.append(dict(control=label, rejected=True))
        else:
            raise ValueError('damaged reading byte control passed: ' + label)
    for label in ('missing-case', 'wrong-runtime', 'defeated-pause-check', 'missing-caption-check', 'old-fade-accepted'):
        damaged = deepcopy(bundle)
        r = damaged['reading_runtime']
        row = next((row for row in r['results'] if row['variant'] == 'nopack' and row['stage'] == 0))
        if label == 'missing-case':
            r['results'].pop()
        if label == 'wrong-runtime':
            r['runtime']['binary_sha256'] = '0' * 64
        if label == 'defeated-pause-check':
            row['checks']['exact_120_frame_pause'] = False
        if label == 'missing-caption-check':
            del row['checks']['caption_stays_visible']
        if label == 'old-fade-accepted':
            r['negative_controls'][0]['rejected'] = False
        try:
            validate(damaged, members)
        except ValueError:
            negatives.append(dict(control=label, rejected=True))
        else:
            raise ValueError('damaged reading receipt control passed: ' + label)
    report = dict(schema='striderex-reading-acceptance/1', passed=True, build_files=proof['build_files'], previous_test_id='261025-08', proof_sha256=CF.sha(a.proof.read_bytes()), runtime_sha256=CF.sha(a.runtime_report.read_bytes()), runtime_cases=len(runtime['results']), old_timing_negative_controls=len(runtime['negative_controls']), damaged_controls=negatives, exact_kit_v_recovery=True, hardware_review_granted=False)
    a.receipt.write_text(json.dumps(report, indent=2) + '\n')
    print('PASS: exact ROM proof, full reading matrix and', len(negatives), 'damaged controls rejected')

def combine(a):
    base = json.loads(a.base_report.read_text())
    follow = json.loads(a.followup_report.read_text())
    if not follow['passed'] or any((base[k] != follow[k] for k in ('schema', 'build_files', 'control_files', 'runtime', 'hold_frames'))):
        raise ValueError('follow-up must pass on the identical build/control/runtime')
    key = lambda r: (r['set'], r['stage'], r['variant'])
    replacements = {key(r): r for r in follow['results'] if r['passed']}
    failed = [r for r in base['results'] if not r['passed']]
    if not failed or any((key(r) not in replacements for r in failed)):
        raise ValueError('failed case lacks a passing follow-up')
    base['results'] = [replacements[key(r)] if not r['passed'] else r for r in base['results']]
    base['superseded_failures'] = failed
    base['base_report_sha256'] = CF.sha(a.base_report.read_bytes())
    base['followup_report_sha256'] = CF.sha(a.followup_report.read_bytes())
    base['passed'] = all((r['passed'] for r in base['results'])) and all((r['rejected'] for r in base['negative_controls']))
    CF.validate_reading(base, base['control_files'], base['build_files'])
    a.receipt.write_text(json.dumps(base, indent=2) + '\n')
    print('PASS:', len(failed), 'diagnosed capture-boundary failure replaced by an identical-input follow-up')

def self_test():
    for off, fade in zip(HOLD, FADE):
        if not off:
            continue
        record = held = 0
        fired = []
        caption_off_tick = None
        for tick in range(1, fade + 400):
            if record == off and held < 120:
                held += 1
            else:
                if record == off:
                    caption_off_tick = tick
                record += 1
            if record + held == fade + 120:
                fired.append(tick)
        assert fired == [fade + 120] and caption_off_tick == off + 121
    CF.self_test()
    print('Reading pause clock self-test PASS')

def main():
    if sys.argv[1:] == ['--self-test']:
        return self_test()
    p = argparse.ArgumentParser(description=__doc__)
    sub = p.add_subparsers(dest='mode', required=True)
    b = sub.add_parser('build')
    for name in ('build', 'vasm', 'out'):
        b.add_argument('--' + name, type=Path, required=True)
    q = sub.add_parser('proof')
    for name in ('build', 'previous-kit', 'receipt'):
        q.add_argument('--' + name, type=Path, required=True)
    d = sub.add_parser('delivery-inputs')
    for name in ('previous-kit', 'out'):
        d.add_argument('--' + name, type=Path, required=True)
    c = sub.add_parser('check')
    for name in ('build', 'previous-kit', 'proof', 'runtime-report', 'receipt'):
        c.add_argument('--' + name, type=Path, required=True)
    f = sub.add_parser('combine')
    for name in ('base-report', 'followup-report', 'receipt'):
        f.add_argument('--' + name, type=Path, required=True)
    a = p.parse_args()
    {'build': build, 'proof': proof, 'delivery-inputs': delivery_inputs, 'check': check, 'combine': combine}[a.mode](a)
if __name__ == '__main__':
    main()
