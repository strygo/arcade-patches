"""Strider EX gate: PLAYER1/PLAYER2 READY (and GO) the same distance below the stage's name in every"""
import argparse
import json
import sys
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import numpy as np
from PIL import Image, ImageDraw
sys.path.insert(0, str(Path(__file__).resolve().parent))
import desert_gate as DG
import ready_ex as RX
import scene_gate as SG
STAGE_FRAMES = {0: 7300, 1: 3600, 2: 3600, 3: 3300, 4: 5300, 5: 4000}
STAGE_NAMES = dict(enumerate(RX.STAGE_NAMES))
TWO_FRAMES, TWO_CLEAR = (7500, 3300)
CONT_FRAMES = 5500
CONT_FROM = 2600
CONT_PRESS = f'{CONT_FROM}-{CONT_FRAMES}@40/6:START1'
SELECT_FRAMES = 2800
SPRITE_RANGES = '0ac0-0aff,1600-16ff,2000-21ff,be00-be3f'
SHOT_EVERY = 100
RAM_EVERY = 25
LAG = 4
TAGS = ('build', 'control', 'old')
CONTROL_TOPS = dict(control=RX.place_tops('uniform'), old=RX.place_tops('stock'))
SSP_TOP = 16714734
YIELD_RET = 2072
CURRENT = 16711942

def cases(only):
    out = {}
    for st, n in STAGE_FRAMES.items():
        out[f's{st}'] = (DG.debug_env(st, 0, n, invincible=False), n)
    out['two'] = (dict(NEWGAME='2', INPUTS=DG.PLAY.format(e=TWO_FRAMES) + f';500-{TWO_FRAMES}@100/4:START1', CLEAR_AT=str(TWO_CLEAR)), TWO_FRAMES)
    env = DG.debug_env(2, 0, CONT_FRAMES, invincible=False)
    env['STREX_INPUTS'] += f';200-360@40/8:COIN1;400-410:START1;{CONT_PRESS}'
    out['cont'] = (env, CONT_FRAMES)
    play = DG.PLAY.replace('450-', '700-').format(e=SELECT_FRAMES)
    out['select'] = (dict(NEWGAME='1', INPUTS=play + ';390-440:P1_BUTTON1;390-440:P1_BUTTON2;400-408:START1;560-564:P1_JOYSTICK_RIGHT;620-624:START1'), SELECT_FRAMES)
    return {k: v for k, v in out.items() if not only or k in only}

class Records:
    """One build's READY/GO records per stage (text cells, sprite entries, record addresses), its"""

    def __init__(self, build, machine, rom_dir):
        import stage_select_gate as SS
        self.img, self.bank = DG.images(build, rom_dir, machine)
        RX.locate(self.img, machine)
        self.tables = RX.stage_tables(self.img, self.bank, machine)
        self.stage = {}
        for s, (bt, bs) in self.tables.items():
            recs = RX.table_records(self.img, self.bank, machine, bt, bs)
            self.stage[s] = {k: dict(text=RX.record_cells(self.img, t), sprite=RX.record_entries(sp), text_at=ta, sprite_at=sa) for k, (t, sp, ta, sa) in recs.items()}
        self.art = RX.Art(rom_dir, SS.ex_region(build, machine))
        self._caps = {}

    def pens(self, cell):
        """A shown cell's pens: (box, (form, code, half or attribute))."""
        form, code, x = cell[1]
        return self.art.s1(code, x) if form == 'text' else self.art.cell(code, x)

    def of(self, stage):
        return self.stage.get(stage, self.stage['other'])

    def places(self):
        """The distinct READY places of this build: {key: (item records, [stages])}."""
        out = {}
        for s, v in self.stage.items():
            out.setdefault(self.place(s), (v, []))[1].append(s)
        return out

    def place(self, stage):
        v = self.of(stage)
        return tuple(((k, tuple(v[k]['text']), tuple(v[k]['sprite'])) for k in RX.ITEMS))

    def caption(self, rec):
        """A kind-2 record: (cols, rows, attribute, codes row-major)."""
        if rec not in self._caps:
            src, a = (self.img, rec) if rec < 1048576 else (self.bank, rec - 1048576)
            n, c1, r1, attr = (RX.be16(src, a + 2 * i) for i in range(4))
            if n != (c1 + 1) * (r1 + 1):
                raise SystemExit(f'ready_gate: caption record {rec:#x} is not a full grid')
            self._caps[rec] = (c1 + 1, r1 + 1, attr, [RX.be16(src, a + 8 + 2 * i) for i in range(n)])
        return self._caps[rec]

def watched(recs):
    """The text cells the Lua reads: every READY/GO cell of every place of every build."""
    out = []
    for r in recs:
        for v in r.stage.values():
            for k in RX.ITEMS:
                out += [a for a, _ in v[k]['text'] if a not in out]
    return out

def read_ready(run, cells):
    rows = {}
    lines = (run / 'ready.tsv').read_text().splitlines()
    for line in lines[1:]:
        f = line.split('\t')
        k0 = []
        for o in filter(None, f[6].split(';')):
            i, v = o.split(':')
            par, st, s3, s4, t32, t33 = (int(x) for x in v.split(','))
            k0.append(dict(index=int(i), param=par, state=st, sub3=s3, sub4=s4))
        k2 = []
        for o in filter(None, f[7].split(';')):
            i, v = o.split(':')
            kind, par, st, x, y, rec = v.split(',')
            k2.append(dict(index=int(i), kind=int(kind), param=int(par), state=int(st), x=int(x), y=int(y), record=int(rec, 16)))
        pal = {}
        for o in filter(None, f[10].split(';')):
            i, v = o.split(':')
            w = [int(x, 16) for x in v.split(',')]
            pal[int(i)] = (w[0], w[1:])
        for o in k2:
            o['level'], o['pal'] = pal.get(o['index'], (None, None))
        rp = [int(x, 16) for x in f[11].replace(';', ',').split(',')]
        cw = [int(x, 16) for x in f[8].split(',')]
        ents = [tuple((int(v) if j < 2 else int(v, 16) for j, v in enumerate(e.split(',')))) for e in f[9].split(';') if e]
        rows[int(f[0])] = dict(s1=(int(f[1], 16), int(f[2], 16), int(f[3], 16)), spr=int(f[4]), p2=int(f[5]), k0=k0, k2=k2, cells=dict(zip(cells, cw)), ents=ents, raw=f[1:8], kpal=f[10], rpal=dict(text=rp[:16], sprite=rp[16:]))
    return rows

def box_text(r, addr):
    p = RX.s1_screen(addr, *r['s1'])
    return None if p is None else (p[0], p[1], p[0] + 8, p[1] + 8)

def box_sprite(e):
    return (e[0] - 64, e[1] - 16, e[0] - 48, e[1])

def shown_at(items, r):
    """{item: [(box, (form, code, half or attribute))]} of the READY/GO records `items` as frame r holds"""
    out = {}
    ents = set(r['ents'])
    for k in RX.ITEMS:
        glyphs = [(a, c) for a, c in items[k]['text'] if c != RX.SPACE]
        if all((r['cells'].get(a) == c for a, c in glyphs)):
            got = []
            for a, c in glyphs:
                b = box_text(r, a)
                if b is None:
                    got = None
                    break
                got.append((b, ('text', c, RX.s1_column(a, r['s1'][0]) & 1)))
            if got:
                out[k] = got
        if all((e in ents for e in items[k]['sprite'])):
            out[k] = out.get(k, []) + [(box_sprite(e), ('sprite', e[2], e[3])) for e in items[k]['sprite']]
    return out

def caption_cells(rec, objs):
    """The list entries kind-2 objects draw (0x70110 [0x6FE5C] -> 0x70192: a cell whose x is above"""
    out = {}
    for o in objs:
        if o['kind'] != 2 or not o['record']:
            continue
        cols, rows, attr, codes = rec.caption(o['record'])
        for i, c in enumerate(codes):
            x = o['x'] + 16 * (i % cols) & 65535
            if x <= 448:
                out[x, o['y'] + 16 * (i // cols) & 65535, c, attr] = o['index']
    return out

def caption_boxes(rec, r, prev):
    """The names' sprite entries in frame r's shown list: each kind-2 object's record cells at its"""
    now = caption_cells(rec, r['k2'])
    want = {**caption_cells(rec, prev['k2'] if prev else []), **now}
    found = [e for e in r['ents'] if e in want]
    whole = not found or set(now) <= set(found)
    return ([(box_sprite(e), ('sprite', e[2], e[3]), want[e], e) for e in found], want, whole)

def meets(a, b):
    return a[0] < b[2] and b[0] < a[2] and (a[1] < b[3]) and (b[1] < a[3])

def in_ranges(code):
    return any((int(lo, 16) <= code <= int(hi, 16) for lo, hi in (x.split('-') for x in SPRITE_RANGES.split(','))))

def lit_top(rec, cells):
    """The highest screen line a pixel of the cells is lit on (a pen other than 15)."""
    tops = [c[0][1] + RX.drawn_rows(rec.pens(c))[0] for c in cells if RX.drawn_rows(rec.pens(c))]
    return min(tops) if tops else None

def lit_bottom(rec, cells):
    bots = [c[0][1] + RX.drawn_rows(rec.pens(c))[-1] for c in cells if RX.drawn_rows(rec.pens(c))]
    return max(bots) if bots else None

def analyze(rec, rows, frames):
    """Per frame: READY's cells (the stage's place) and at every other place of the build, the names'"""
    stage = {int(x['frame']): int(x['stage']) for x in frames}
    places = rec.places()
    out, overlap, both, missing, partial, elsewhere = ({}, [], [], [], [], [])
    for f in sorted(rows):
        r, p = (rows[f], rows.get(f - 1))
        st = stage[f]
        rd = shown_at(rec.of(st), r)
        if any((shown_at(items, r) for key, (items, _) in places.items() if key != rec.place(st))):
            elsewhere.append(f)
        cap, want, whole = caption_boxes(rec, r, p)
        missing += [f for c in want if not in_ranges(c[2])][:1]
        if rd and (not whole):
            partial.append(f)
        out[f] = dict(ready=rd, cap=cap, stage=st)
    gaps = {}
    for f in sorted(rows):
        rc = [c for g in (f - 1, f) if g in out for v in out[g]['ready'].values() for c in v]
        cc = [c for g in (f - 1, f) if g in out for c in out[g]['cap']]
        if out[f]['ready'] and out[f]['cap']:
            both.append(f)
            tops = {lit_top(rec, v) for g in (f - 1, f) if g in out for v in out[g]['ready'].values()} - {None}
            bots = {lit_bottom(rec, [c]) for c in cc} - {None}
            gaps[f] = dict(tops=sorted(tops), bottom=max(bots), gap=min(tops) - max(bots) - 1, stage=out[f]['stage'])
        if any((meets(b[0], c[0]) for b in rc for c in cc)):
            overlap.append(f)
    plays = [int(x['frame']) for x0, x in zip(frames, frames[1:]) if x['mode'] == '4' and x0['mode'] != '4']
    objs = sorted({(f, o['param']) for f, r in rows.items() for o in r['k0'] if o['param'] in (9, 10, 11)})
    name_bottom = {}
    for f in sorted(out):
        if out[f]['cap']:
            b = lit_bottom(rec, out[f]['cap'])
            name_bottom.setdefault(out[f]['stage'], set()).add(b)
    ready_top = {}
    for f in sorted(out):
        if out[f]['ready']:
            ready_top.setdefault(out[f]['stage'], set()).update((lit_top(rec, v) for v in out[f]['ready'].values()))
    return dict(frames=out, overlap=overlap, both=both, gaps=gaps, plays=plays, stage=stage, params=sorted({p for _, p in objs}), ready_frames=[f for f in sorted(out) if out[f]['ready']], object_frames=sorted({f for f, _ in objs}), caption_frames=[f for f in sorted(out) if out[f]['cap']], caption_cells=sorted({len(out[f]['cap']) for f in out if out[f]['cap']}), caption_partial_with_ready=partial[:10], caption_codes_outside_ranges=missing[:5], ready_elsewhere=elsewhere[:10], name_bottom={s: sorted(v) for s, v in name_bottom.items()}, ready_top={s: sorted(v) for s, v in ready_top.items()})

def runs_of(fs):
    out = []
    for f in fs:
        if out and f == out[-1][1] + 1:
            out[-1][1] = f
        else:
            out.append([f, f])
    return out

def steady(an, frames):
    """The frames whose READY was already shown, as now, the frame before (on screen: HBMAME shows"""
    return [f for f in frames if an['frames'][f]['ready'] and an['frames'].get(f - 1, {}).get('ready') == an['frames'][f]['ready']]

def shot(work, name, tag, f):
    q = work / 'runs' / f'{name}_{tag}' / f's_{f:05d}.png'
    return np.asarray(Image.open(q).convert('RGB')) if q.exists() else None

def full(words, pens):
    return all((words[p] >> 12 == 15 for p in pens))

def pixels(work, name, tag, an, rows, rec):
    """The lit pixels the model gives against the screenshots: the names on full-brightness frames"""
    rep = dict(name_frames=0, name_pixels=0, name_bad=[], ready_frames=0, ready_pixels=0, ready_bad=[])
    for f in sorted(an['frames']):
        a, prev = (an['frames'][f], an['frames'].get(f - 1))
        r, rp = (rows[f], rows.get(f - 1))
        if not prev or (not a['cap'] and (not a['ready'])):
            continue
        img = None
        objs = {o['index']: o for o in r['k2']}
        pobjs = {o['index']: o for o in (rp['k2'] if rp else [])}
        cands = [x for x in (a['cap'], prev['cap']) if x]
        steady_pal = bool(a['cap']) and all((objs.get(c[2]) and pobjs.get(c[2]) and (objs[c[2]]['pal'] is not None) and (objs[c[2]]['pal'] == pobjs[c[2]]['pal']) and full(objs[c[2]]['pal'], sorted(set(rec.pens(c)[rec.pens(c) != 15].tolist()))) for x in cands for c in x))
        if steady_pal:
            img = shot(work, name, tag, f)
        if steady_pal and img is not None:
            best = None
            for cells in cands:
                top = {}
                for c in reversed(cells):
                    b, pens, idx = (c[0], rec.pens(c), c[2])
                    want = [tuple(SG.hb_rgb(w)) for w in objs[idx]['pal']]
                    for y, x in zip(*np.nonzero(pens != 15)):
                        sx, sy = (b[0] + int(x), b[1] + int(y))
                        if 0 <= sx < img.shape[1] and 0 <= sy < img.shape[0]:
                            top[sx, sy] = want[pens[y, x]]
                bad = [[f, sx, sy] for (sx, sy), col in top.items() if tuple((int(v) for v in img[sy, sx])) != col]
                if best is None or len(bad) < len(best[1]):
                    best = (len(top), bad)
            rep['name_frames'] += 1
            rep['name_pixels'] += best[0]
            rep['name_bad'] += best[1]
        if a['ready'] and prev['ready'] == a['ready'] and rp and (rp['rpal'] == r['rpal']):
            if img is None:
                img = shot(work, name, tag, f)
            if img is None:
                continue
            top = min((lit_top(rec, v) for v in a['ready'].values()))
            rep['ready_frames'] += 1
            for v in a['ready'].values():
                for c in v:
                    b, pens, form = (c[0], rec.pens(c), c[1][0])
                    words = r['rpal']['text' if form == 'text' else 'sprite']
                    y = top - b[1]
                    if not 0 <= y < pens.shape[0]:
                        continue
                    for x in np.nonzero(pens[y] != 15)[0]:
                        sx = b[0] + x
                        if 0 <= sx < img.shape[1]:
                            rep['ready_pixels'] += 1
                            if tuple(img[top, sx]) != tuple(SG.hb_rgb(words[pens[y, x]])):
                                rep['ready_bad'].append([f, int(sx), int(top)])
    rep['n_name_bad'], rep['n_ready_bad'] = (len(rep['name_bad']), len(rep['ready_bad']))
    rep['name_bad'], rep['ready_bad'] = (rep['name_bad'][:10], rep['ready_bad'][:10])
    return rep

def pointer_pairs(rec_b, rec_c):
    """The (build, control) values of READY's record pointer that may differ: the init stores its"""
    return {(rec_b.of(s)[k]['sprite_at'], rec_c.of(s)[k]['sprite_at']) for s in rec_c.stage for k in RX.ITEMS if rec_b.of(s)[k]['sprite_at'] != rec_c.of(s)[k]['sprite_at']}

def working(d):
    """The task slots a dump caught at work: neither free (0) nor asleep (1), and not a task in its"""
    return [t for t in range(16) if d[16 * t] not in (0, 1) and (not (d[16 * t] in (4, 8) and RX.be32(d, 16 * t + 4) == YIELD_RET))]

def ram_compare(ra, rc, pairs):
    """Two runs' work RAM dumps (every RAM_EVERY frames), byte for byte. A byte may differ only as"""
    ia, ic = ((ra / 'ram.idx').read_text().split(), (rc / 'ram.idx').read_text().split())
    da, dc = ((ra / 'ram.bin').read_bytes(), (rc / 'ram.bin').read_bytes())
    bad, pointer, context, at_work, where, ctx_at = ([], 0, 0, 0, set(), set())
    for i in range(min(len(ia), len(ic))):
        A, C = (da[65536 * i:65536 * (i + 1)], dc[65536 * i:65536 * (i + 1)])
        if A == C:
            continue
        tops = {RX.be32(A, 16 * t + 12) for t in range(16)} | {RX.be32(C, 16 * t + 12) for t in range(16)}
        low = max([v for v in tops if 16711680 <= v < SSP_TOP] or [SSP_TOP]) - 16711680
        busy = working(A)
        live = []
        if busy and busy == working(C):
            for t in busy:
                lo = min(RX.be32(A, 16 * t + 8), RX.be32(C, 16 * t + 8)) - 16711680
                hi = RX.be32(A, 16 * t + 12) - 16711680
                if RX.be32(C, 16 * t + 12) - 16711680 == hi and 0 <= lo <= hi <= 65536:
                    live.append((lo, hi))
        a8, c8 = (np.frombuffer(A, np.uint8), np.frombuffer(C, np.uint8))
        left, ptr, ctx, wrk = ([], False, False, False)
        for j in (int(x) for x in np.nonzero(a8 != c8)[0]):
            if any((0 <= w <= 65532 and (RX.be32(A, w), RX.be32(C, w)) in pairs for w in (j & ~1, (j & ~1) - 2))):
                ptr = True
                where.add(16711680 + (j & ~3))
            elif low <= j < SSP_TOP - 16711680:
                ctx = True
                ctx_at.add(16711680 + j)
            elif j < 256 and j % 16 == 0 and ({A[j], C[j]} == {4, 8}) and (RX.be32(A, j + 4) == RX.be32(C, j + 4) == YIELD_RET):
                ctx = True
                ctx_at.add(16711680 + j)
            elif CURRENT <= 16711680 + j < CURRENT + 4 and {RX.be32(A, CURRENT - 16711680) & 65535, RX.be32(C, CURRENT - 16711680) & 65535} <= set(range(0, 256, 16)):
                ctx = True
                ctx_at.add(16711680 + j)
            elif any((lo <= j < hi for lo, hi in live)):
                wrk = True
            else:
                left.append(j)
        if left:
            bad.append(dict(frame=int(ia[i]), bytes=len(left), first=[f'{16711680 + j:#x}' for j in left[:8]]))
        pointer += ptr
        context += ctx
        at_work += wrk
    if ia != ic:
        bad.append('frames')
    return dict(ram_dumps=len(ia), ram_differ=bad[:10], n_ram_differ=len(bad), ram_dumps_with_record_pointer=pointer, record_pointer_at=sorted((f'{w:#x}' for w in where)), ram_dumps_with_cpu_context=context, cpu_context_at=[f'{min(ctx_at):#x}', f'{max(ctx_at):#x}'] if ctx_at else [], ram_dumps_with_job_in_progress=at_work)

def identity(work, name, rows_b, rows_c, fr_b, fr_c, an_b, an_c, rec_b, rec_c, cells):
    rep = {}
    cols = [k for k in fr_c[0] if k != 'frame']
    rep['frames_differ'] = [int(x['frame']) for x, y in zip(fr_b, fr_c) if any((x[k] != y[k] for k in cols))][:10]
    rep['frames'] = len(fr_c) if len(fr_b) == len(fr_c) else f'{len(fr_b)} != {len(fr_c)}'
    rep['objects_differ'] = [f for f in rows_c if rows_b.get(f, {}).get('raw') != rows_c[f]['raw']][:10]
    rep['palettes_differ'] = [f for f in rows_c if rows_b.get(f, {}).get('kpal') != rows_c[f]['kpal']][:10]
    back = {}
    for s in rec_c.stage:
        for k in RX.ITEMS:
            for eb, ec in zip(rec_b.of(s)[k]['sprite'], rec_c.of(s)[k]['sprite']):
                back.setdefault(s, {})[eb] = ec
    rep['sprites_differ'] = [f for f in rows_c if [back.get(an_b['stage'][f], {}).get(e, e) for e in rows_b[f]['ents']] != rows_c[f]['ents']][:10]
    live = {f for f, r in rows_c.items() for o in r['k0'] if o['param'] in (9, 10, 11)}
    live |= {f for f, r in rows_b.items() for o in r['k0'] if o['param'] in (9, 10, 11)}
    rep['cells_differ_outside_ready'] = [f for f in rows_c if f not in live and any((rows_b[f]['cells'][a] != rows_c[f]['cells'][a] for a in cells))][:10]
    ra, rb_ = (work / 'runs' / f'{name}_build', work / 'runs' / f'{name}_control')
    rep.update(ram_compare(ra, rb_, pointer_pairs(rec_b, rec_c)))
    shots_b = sorted((q.name for q in ra.glob('s_*.png')))
    shots_c = sorted((q.name for q in rb_.glob('s_*.png')))
    rep['shots'] = len(shots_c)
    rep['shot_sets_differ'] = shots_b != shots_c
    bad, moved, glyph_frames, glyph_cells, glyph_seen = ([], 0, 0, 0, 0)
    for nm in shots_c:
        if nm not in shots_b:
            continue
        f = int(nm[2:7])
        A = np.asarray(Image.open(ra / nm).convert('RGB'))
        C = np.asarray(Image.open(rb_ / nm).convert('RGB'))
        diff = (A != C).any(-1)
        if not diff.any():
            continue
        allow = np.zeros(diff.shape, bool)
        for an in (an_b, an_c):
            for g in (f - 1, f):
                for v in an['frames'].get(g, {}).get('ready', {}).values():
                    for (x0, y0, x1, y1), *_ in v:
                        allow[max(y0, 0):max(y1, 0), max(x0, 0):max(x1, 0)] = True
        if (diff & ~allow).any():
            ys, xs = np.nonzero(diff & ~allow)
            bad.append(dict(frame=f, pixels=int(len(ys)), box=[int(xs.min()), int(ys.min()), int(xs.max()), int(ys.max())]))
        moved += 1
        rd = an_b['frames'].get(f, {}).get('ready', {})
        if rd and an_b['frames'].get(f - 1, {}).get('ready') == rd:
            if rd != an_c['frames'].get(f, {}).get('ready'):
                glyph_frames += 1
                for v in rd.values():
                    for (x0, y0, x1, y1), *_ in v:
                        glyph_cells += 1
                        glyph_seen += bool(diff[max(y0, 0):y1, max(x0, 0):x1].any())
    rep.update(shots_differ_outside_ready=bad[:10], n_shots_differ_outside_ready=len(bad), shots_with_ready_moved=moved, moved_ready_frames=glyph_frames, ready_cells_checked=glyph_cells, ready_cells_showing=glyph_seen)
    rep['passed'] = not rep['frames_differ'] and isinstance(rep['frames'], int) and (not rep['objects_differ']) and (not rep['palettes_differ']) and (not rep['sprites_differ']) and (not rep['cells_differ_outside_ready']) and (not rep['n_ram_differ']) and (rep['ram_dumps'] > 0) and (not rep['shot_sets_differ']) and (not bad) and (glyph_seen >= 0.9 * glyph_cells)
    return rep
CROP_SCALE = 2

def label(d, xy, text, fill=(255, 255, 255)):
    x, y = xy
    d.rectangle((x - 2, y - 1, x + 6 * len(text) + 2, y + 11), fill=(0, 0, 0))
    d.text((x, y), text, fill=fill)

def marked(img, box, bottom, top, title):
    """A crop of a screenshot, scaled, with the name's lowest lit line (bottom), READY's highest (top)"""
    x0, y0, x1, y1 = box
    im = Image.fromarray(img[y0:y1, x0:x1]).resize(((x1 - x0) * CROP_SCALE, (y1 - y0) * CROP_SCALE), Image.NEAREST)
    im = im.convert('RGB')
    d = ImageDraw.Draw(im)
    W = im.size[0]
    if bottom is not None:
        yb = (bottom + 1 - y0) * CROP_SCALE
        d.line((0, yb, W, yb), fill=(0, 255, 255))
    if top is not None:
        yt = (top - y0) * CROP_SCALE
        d.line((0, yt, W, yt), fill=(255, 0, 255))
    if bottom is not None and top is not None:
        xm = W - 70
        yb, yt = ((bottom + 1 - y0) * CROP_SCALE, (top - y0) * CROP_SCALE)
        d.line((xm, yb, xm, yt), fill=(255, 255, 0), width=2)
        label(d, (xm + 6, (yb + yt) // 2 - 6), f'{top - bottom - 1} px', fill=(255, 255, 0))
    label(d, (4, 2), title)
    return im

def review_frames(an):
    """(frame, frame): the first frame READY (steady) and the name are both on screen (the name at its"""
    both = steady(an, an['both'])
    if both:
        return (both[0], both[0])
    first = next(iter(steady(an, an['ready_frames'])), None)
    caps = [f for f in an['caption_frames'] if first is None or f < first]
    return (caps[-1] if caps else first, first)

def review(work, res, set_name, rec):
    names = [n for n in (f's{st}' for st in STAGE_FRAMES) if n in res]
    rows_img, picks = ([], {})
    for n in names:
        st = int(n[1])
        views = []
        for tag, who in (('control', 'uniform control'), ('build', 'this build')):
            an = res[n]['an_' + tag]
            cap_f, rd_f = review_frames(an)
            picks.setdefault(n, {})[tag] = [cap_f, rd_f]
            ca = an['frames'].get(cap_f, {}).get('cap') or []
            rr = [c for v in an['frames'].get(rd_f, {}).get('ready', {}).values() for c in v]
            bottom = lit_bottom(rec[tag], ca) if ca else (an['name_bottom'].get(st) or [None])[-1]
            top = lit_top(rec[tag], rr) if rr else None
            views.append((tag, who, an, cap_f, rd_f, bottom, top, [c[0] for c in ca] + [c[0] for c in rr]))
        boxes = [b for v in views for b in v[7]]
        if not boxes:
            continue
        crop = (max(min((b[0] for b in boxes)) - 16, 0), max(min((b[1] for b in boxes)) - 12, 0), min(max((b[2] for b in boxes)) + 16, 384), min(max((b[3] for b in boxes)) + 12, 224))
        panels = []
        for tag, who, an, cap_f, rd_f, bottom, top, _ in views:
            play = an['plays'][0] if an['plays'] else 0
            two = []
            for f in [cap_f] if cap_f == rd_f else [cap_f, rd_f]:
                img = shot(work, n, tag, f)
                if img is None:
                    continue
                what = 'name + READY' if cap_f == rd_f else 'card, last frame' if f == cap_f else 'READY, first frame'
                two.append(marked(img, crop, bottom, top, f'{STAGE_NAMES[st]}, {who}: {what}, play{f - play:+d}'))
            if cap_f == rd_f:
                panels += two
            elif two:
                rows_img.append(two)
        if panels:
            rows_img.append(panels)
    W = max((sum((p.size[0] for p in r)) + 8 * (len(r) - 1) for r in rows_img))
    H = sum((max((p.size[1] for p in r)) + 8 for r in rows_img))
    sheet = Image.new('RGB', (W, H), (40, 40, 40))
    y = 0
    for r in rows_img:
        x = 0
        for p in r:
            sheet.paste(p, (x, y))
            x += p.size[0] + 8
        y += max((p.size[1] for p in r)) + 8
    sheet.save(work / 'review.png')
    return dict(review=str(work / 'review.png'), frames=picks)

def tops_of(r, machine):
    """{stage: READY's top line} of a build (Records), from every record its code takes in that stage:"""
    out = {}
    for s in range(len(RX.STAGE_NAMES)):
        recs = RX.table_records(r.img, r.bank, machine, *r.tables[s])
        got = {8 * t[1] for t, _, _, _ in recs.values()} | {RX.record_entries(sp)[0][1] - 16 for _, sp, _, _ in recs.values()}
        if len(got) != 1:
            raise SystemExit(f'ready_gate: stage {s} READY records disagree on its place ({sorted(got)})')
        out[s] = got.pop()
    return out

def same_tree(builds, rec, machine):
    """The controls are the build's tree with only READY's places changed (build_ex.py --ready-places):"""
    bad = []
    names = {tag: sorted((q.name for q in (b / machine).iterdir() if q.is_file())) for tag, b in builds.items()}
    tabs = {tag: RX.tabs_at(r.img, r.bank, machine) for tag, r in rec.items()}
    for tag in ('control', 'old'):
        if names[tag] != names['build']:
            bad.append(f"{tag}: members {names[tag]} != {names['build']}")
            continue
        for n in names['build']:
            if n != 'strex_p6.bin' and (builds[tag] / machine / n).read_bytes() != (builds['build'] / machine / n).read_bytes():
                bad.append(f'{tag}: {n} differs')
        if rec[tag].img != rec['build'].img:
            bad.append(f'{tag}: the program image differs')
        if tabs[tag] is None or tabs[tag] != tabs['build']:
            bad.append(f"{tag}: READY's sites or table lists differ ({tabs[tag]} != {tabs['build']})")
            continue
        cut = min(tabs['build'].values()) - 1048576
        if rec[tag].bank[:cut] != rec['build'].bank[:cut] or rec[tag].bank[-16:] != rec['build'].bank[-16:]:
            bad.append(f"{tag}: the EX bank differs before READY's tables ({cut + 1048576:#x}) or in its flag block")
    return bad

def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('--build', type=Path, required=True)
    p.add_argument('--control', type=Path, required=True, help="the build's tree with --ready-places uniform (identity; its gaps differ by stage)")
    p.add_argument('--overlap-control', type=Path, required=True, help="the build's tree with --ready-places stock (READY over the names)")
    p.add_argument('--runtime', type=Path, required=True)
    p.add_argument('--hbmame', type=Path, required=True)
    p.add_argument('--rom-dir', type=Path, required=True)
    p.add_argument('--workdir', type=Path, required=True)
    p.add_argument('--set', default='striderus01', choices=sorted(DG.PARENT))
    p.add_argument('--jobs', type=int, default=2)
    p.add_argument('--cases', default='')
    a = p.parse_args()
    work = a.workdir.resolve()
    work.mkdir(parents=True, exist_ok=False)
    machine = DG.PARENT[a.set]
    rom_dir = a.rom_dir.resolve()
    builds = dict(build=a.build.resolve(), control=a.control.resolve(), old=a.overlap_control.resolve())
    rec = {tag: Records(b, machine, rom_dir) for tag, b in builds.items()}
    tops = {tag: tops_of(r, machine) for tag, r in rec.items()}
    for tag, want in CONTROL_TOPS.items():
        if [tops[tag][s] for s in range(len(RX.STAGE_NAMES))] != want:
            raise SystemExit(f"ready_gate: the {('--control' if tag == 'control' else '--overlap-control')} READY tops {tops[tag]} are not {want} (build_ex.py --ready-places {('uniform' if tag == 'control' else 'stock')} of the build's tree)")
    if [tops['build'][s] for s in range(len(RX.STAGE_NAMES))] != RX.stage_tops():
        raise SystemExit(f"ready_gate: the build's READY places {tops['build']} are not ready_ex's")
    differ = same_tree(builds, rec, machine)
    if differ:
        raise SystemExit("ready_gate: the controls are not the build's tree with only READY's places changed: " + '; '.join(differ))
    cells = watched(rec.values())
    binary = json.loads((a.runtime / 'runtime.json').read_text())['binary']
    sets = {tag: DG.stage_sets(b, a.set, a.hbmame, rom_dir, work / f'sets_{tag}') for tag, b in builds.items()}
    todo = cases([c for c in a.cases.split(',') if c])
    extra = dict(READY=','.join((f'{x:x}' for x in cells)) + ';' + SPRITE_RANGES, READY_SHOTS='1', SHOTS=f'{SHOT_EVERY}-100000@{SHOT_EVERY}', RAM=str(RAM_EVERY))
    jobs = [(f'{n}_{tag}', tag, dict(env, **extra), frames) for n, (env, frames) in todo.items() for tag in TAGS]
    with ThreadPoolExecutor(a.jobs) as ex:
        out = dict(zip([j[0] for j in jobs], ex.map(lambda j: DG.run(binary, sets[j[1]], a.set, work / 'runs' / j[0], j[2], j[3]), jobs)))
    res, report, ok = ({}, dict(set=a.set, gap=RX.GAP, name_bottom=list(RX.NAME_BOTTOM), ready_top=RX.stage_tops(), cases={}), True)
    measured = {tag: {} for tag in TAGS}
    for n in todo:
        rows = {tag: read_ready(work / 'runs' / f'{n}_{tag}', cells) for tag in TAGS}
        an = {tag: analyze(rec[tag], rows[tag], out[f'{n}_{tag}']) for tag in TAGS}
        for tag in TAGS:
            for s, v in an[tag]['name_bottom'].items():
                measured[tag].setdefault(s, set()).update(v)
        res[n] = dict(rows=rows, **{f'an_{tag}': an[tag] for tag in TAGS})
    report['name_bottom_measured'] = {tag: {str(s): sorted(v) for s, v in sorted(m.items())} for tag, m in measured.items()}
    for n in todo:
        rows, an = (res[n]['rows'], {tag: res[n][f'an_{tag}'] for tag in TAGS})
        b, c, o = (an['build'], an['control'], an['old'])
        idn = identity(work, n, rows['build'], rows['control'], out[f'{n}_build'], out[f'{n}_control'], b, c, rec['build'], rec['control'], cells)
        pix = pixels(work, n, 'build', b, rows['build'], rec['build'])
        shift = []
        for f in c['ready_frames']:
            st = c['stage'][f]
            dy = RX.ready_top(st) - RX.MOVED_TOP if st < len(RX.STAGE_NAMES) else 0
            rb, rc = (b['frames'].get(f, {}).get('ready', {}), c['frames'][f]['ready'])
            if rb.keys() != rc.keys() or any(([(x0, y0 + dy, x1, y1 + dy) for (x0, y0, x1, y1), *_ in rc[k]] != [bx for bx, *_ in rb[k]] for k in rb)):
                shift.append(f)
        if c['ready_frames'] != b['ready_frames']:
            shift.append('frames')

        def gap_report(x, tag):
            """Every both-shown frame's gap, and every READY frame's top against its stage's measured name."""
            per = {}
            for f, g in x['gaps'].items():
                per.setdefault(g['stage'], set()).add(g['gap'])
            topgap = {}
            for s, tset in x['ready_top'].items():
                nb = measured[tag].get(s)
                if nb:
                    topgap[s] = sorted({t - max(nb) - 1 for t in tset})
            return dict(both=sorted({g for v in per.values() for g in v}), by_stage={str(s): sorted(v) for s, v in per.items()}, ready_vs_name={str(s): v for s, v in topgap.items()}, tops={str(s): v for s, v in x['ready_top'].items()})
        g_b, g_c = (gap_report(b, 'build'), gap_report(c, 'control'))
        need_both = n in ('s1', 's2', 's3', 's4', 's5', 'two', 'select')
        last = len(out[f'{n}_build'])
        objs = runs_of(b['object_frames'])
        own = [s for s in b['ready_top'] if s < len(RX.STAGE_NAMES)]
        checks = dict(gap=set(g_b['both']) <= {RX.GAP} and all((v == [RX.GAP] for v in g_b['ready_vs_name'].values())) and all((len(v) == 1 and v[0] == RX.ready_top(int(s)) for s, v in g_b['tops'].items())) and (set(own) <= set((int(s) for s in g_b['ready_vs_name']))), ready_only_at_its_place=not b['ready_elsewhere'], pixels=not pix['n_name_bad'] and (not pix['n_ready_bad']) and (pix['ready_frames'] > 0) and (pix['name_frames'] > 0 or not b['caption_frames']), no_overlap=not b['overlap'], ready_shown=bool(b['ready_frames']) and bool(b['object_frames']), complete=bool(objs) and objs[-1][1] < last - LAG and (len(objs) >= 2 or n == 'select'), both_shown=bool(b['both']) or not need_both, position=not shift and bool(b['ready_frames']), ranges=not any((x['caption_codes_outside_ranges'] for x in an.values())), captions_whole=not any((x['caption_partial_with_ready'] for x in an.values())), identity=idn['passed'])
        if n == 'two':
            checks['two_players'] = 10 in b['params'] and any((rows['build'][f]['spr'] == 0 and rows['build'][f]['p2'] for f in b['ready_frames']))
        cont = {}
        if n == 'cont':
            fr = out[f'{n}_build']
            lives = {int(x['frame']): x['lives'] for x in fr}
            over = next((int(x['frame']) for x in fr if x['mode'] == '4' and x['lives'] == '0'), None)
            again = [f for f in b['plays'] if over is not None and f > over]
            cont = dict(game_over=over, continued=again[:1], ready_after=[f for f in b['ready_frames'] if again and f > again[0]][:1])
            checks['continued'] = bool(again) and lives[again[0]] != '0' and (again[0] > CONT_FROM) and bool(cont['ready_after'])
        if n == 'select':
            checks['desert'] = any((x['stage'] == '5' and x['mode'] == '4' for x in out[f'{n}_build']))
        r = dict(checks=checks, passed=all(checks.values()), plays=b['plays'], params=b['params'], stages=sorted(set((b['stage'][f] for f in b['ready_frames']))), ready_shown=runs_of(b['ready_frames']), ready_objects=runs_of(b['object_frames']), captions=runs_of(b['caption_frames']), caption_cells=b['caption_cells'], both_shown=runs_of(b['both']), gaps_build=g_b, overlap_build=runs_of(b['overlap']), ready_elsewhere=b['ready_elsewhere'], position_differs=shift[:10], pixels=pix, control=dict(both_shown=runs_of(c['both']), gaps=g_c, overlap=runs_of(c['overlap'])), old=dict(both_shown=runs_of(o['both']), overlap=runs_of(o['overlap']), ram_vs_control=ram_compare(work / 'runs' / f'{n}_old', work / 'runs' / f'{n}_control', set())), identity=idn, **{'continue': cont} if cont else {})
        report['cases'][n] = r
        ok &= r['passed']
        print(n, json.dumps({k: v for k, v in r.items() if k not in ('identity', 'pixels')}), flush=True)
        print(n, 'pixels', json.dumps(pix), flush=True)
        print(n, 'identity', json.dumps(idn), flush=True)
    mb = {s: max(v) for s, v in measured['build'].items() if s < len(RX.STAGE_NAMES)}
    report['name_bottom_ok'] = all((mb[s] == RX.NAME_BOTTOM[s] for s in mb)) and (bool(a.cases) or set(mb) == set(range(len(RX.STAGE_NAMES))))
    ok &= report['name_bottom_ok']
    gaps42 = {}
    for n, v in report['cases'].items():
        for s, g in v['control']['gaps']['ready_vs_name'].items():
            gaps42.setdefault(s, set()).update(g)
    report['control_gaps'] = {s: sorted(v) for s, v in sorted(gaps42.items())}
    report['control_fails'] = len({g for v in gaps42.values() for g in v}) > 1
    report['overlap_control_cases'] = sorted((n for n, v in report['cases'].items() if v['old']['overlap']))
    report['overlap_control_fails'] = bool(report['overlap_control_cases'])
    report['ram_check_control_cases'] = sorted((n for n, v in report['cases'].items() if v['old']['ram_vs_control']['n_ram_differ']))
    report['ram_check_control_fails'] = bool(report['ram_check_control_cases'])
    ok &= report['control_fails'] and report['overlap_control_fails'] and report['ram_check_control_fails']
    report['review'] = review(work, res, a.set, rec)
    report['passed'] = ok
    (work / 'report.json').write_text(json.dumps(report, indent=1) + '\n')
    print('name bottoms measured', json.dumps(report['name_bottom_measured']))
    print('control (uniform) gaps', report['control_gaps'], 'fails' if report['control_fails'] else 'DOES NOT FAIL')
    print('overlap control (stock) cases', report['overlap_control_cases'])
    print('RAM check control (stock against uniform) cases', report['ram_check_control_cases'])
    print('PASS' if ok else 'FAIL')
    return 0 if ok else 1
if __name__ == '__main__':
    sys.exit(main())
