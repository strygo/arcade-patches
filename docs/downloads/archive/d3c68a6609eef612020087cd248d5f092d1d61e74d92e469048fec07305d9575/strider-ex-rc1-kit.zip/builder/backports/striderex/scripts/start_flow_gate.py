"""Strider EX: the start flow, from START to the first frame of play, frame by frame."""
import argparse
import json
import os
import subprocess
import sys
from pathlib import Path
import numpy as np
from PIL import Image, ImageDraw
sys.path.insert(0, str(Path(__file__).resolve().parent))
import build_ex as BX
ROOT = Path(__file__).resolve().parents[3]
LUA = ROOT / 'backports/striderex/lua/start_flow.lua'
PARENT = {'striderus01': 'striderua', 'striderjs01': 'striderjr'}
ON, HOLD, CARD, WAIT = (49637, 49638, 49639, 49640)
COIN, START = (200, 400)
SETUP_MAX = 5
HANDBACK_MAX = 2
PICTURE = (64, 320)

def stage(build, set_name, variant, hbmame, rom_dir, work):
    """The HBMAME set of a build, with the PACK bit set for the pack variant (as the MRAs patch it)."""
    import desert_gate as DG
    src = work / f'ex_{variant}'
    d = src / PARENT[set_name]
    d.mkdir(parents=True)
    for q in (build / PARENT[set_name]).iterdir():
        b = q.read_bytes()
        if q.name == 'strex_p6.bin' and variant == 'pack':
            b = bytearray(b)
            b[1048574] |= 1
            b = bytes(b)
        (d / q.name).write_bytes(b)
    return DG.stage_sets(src, set_name, hbmame, rom_dir, work / f'set_{variant}')

def run(binary, roms, set_name, out, frames=9000):
    out.mkdir(parents=True)
    env = dict(os.environ, SDL_VIDEODRIVER='dummy', SDL_AUDIODRIVER='dummy', OUT=str(out), END=str(frames), COIN=str(COIN), START=str(START), SHOT_FROM=str(START - 10))
    cmd = [str(binary), set_name, '-rompath', str(roms), '-nothrottle', '-video', 'none', '-sound', 'none', '-seconds_to_run', str(frames // 50 + 30), '-skip_gameinfo', '-noautosave', '-cfg_directory', str(out / 'cfg'), '-nvram_directory', str(out / 'nv'), '-snapshot_directory', str(out), '-autoboot_script', str(LUA)]
    p = subprocess.run(cmd, env=env, cwd=out, capture_output=True, text=True, timeout=3600)
    (out / 'mame.log').write_text(p.stdout + p.stderr)
    if p.returncode:
        sys.exit(f'{out}: MAME exit {p.returncode}')
    lines = (out / 'frames.tsv').read_text().splitlines()
    head = lines[0].split('\t')
    rows = []
    for line in lines[1:]:
        r = dict(zip(head, line.split('\t')))
        rows.append(dict(frame=int(r['frame']), active=int(r['active'], 16), records=int(r['records']), lz=int(r['lz'], 16), mode=int(r['mode']), flag=int(r['flag']), istate=int(r['istate']), sound=[] if r['sound'] == '-' else [int(v, 16) for v in r['sound'].split(',')]))
    return rows

def png(out, f):
    q = out / f'f_{f:05d}.png'
    return np.asarray(Image.open(q).convert('RGB')) if q.exists() else None

def scene_namer(streams):
    order = sorted(streams, key=lambda k: streams[k])

    def name(ptr):
        i = max((j for j, s in enumerate(order) if streams[s] <= ptr), default=None)
        return order[i] if i is not None else None
    return name

def segments(rows, streams, stock, start=START):
    """Per frame from START to the first frame of play: its source and whether it is lit. Returns"""
    name = scene_namer(streams) if streams else None
    by = {r['frame']: r for r in rows}
    play = next((r['frame'] for r in rows if r['frame'] > start and r['mode'] == 4), None)
    out = []
    end = play if play is not None else rows[-1]['frame']
    for f in range(start, end + 1):
        r = by.get(f)
        if r is None or 'lit' not in r:
            continue
        a = None if stock else r['active']
        if a == ON:
            src = name(r['lz'])
        elif a in (HOLD, WAIT, CARD):
            src = 'held'
        elif not r['flag']:
            src = 'coin'
        elif r['istate'] in (0, 2) and r['mode'] != 4:
            src = 'globe'
        else:
            src = 'stage intro'
        out.append((f, src, r['lit'], r))
    return (out, play)

def black_runs(frames):
    """Maximal runs of black frames: (first, last, sources in order, source of the last lit frame before,"""
    runs, i = ([], 0)
    while i < len(frames):
        if frames[i][2]:
            i += 1
            continue
        j = i
        while j + 1 < len(frames) and (not frames[j + 1][2]):
            j += 1
        srcs = []
        for f in frames[i:j + 1]:
            if not srcs or srcs[-1] != f[1]:
                srcs.append(f[1])
        before = next((frames[k][1] for k in range(i - 1, -1, -1) if frames[k][2]), None)
        after = next((frames[k][1] for k in range(j + 1, len(frames)) if frames[k][2]), None)
        runs.append(dict(first=frames[i][0], last=frames[j][0], frames=j - i + 1, sources=srcs, before=before, after=after, inside=before == after and srcs == [before]))
        i = j + 1
    return runs

def held_frames(run, frames):
    return sum((1 for f in frames if run['first'] <= f[0] <= run['last'] and f[1] == 'held'))

def scene_meta(build, census, scenes):
    """Per scene of a build: its pre-roll records, the cue's record (cue_record: the record of the cue's"""
    import cinematic_convert as C
    bj = json.loads((build / 'build.json').read_text())
    cj = json.loads((build / 'captions.json').read_text())
    fj = json.loads((build / 'frames.json').read_text()) if (build / 'frames.json').exists() else {}
    cat = {c['id']: c for c in json.loads((census / 'catalog/catalog.json').read_text())['cinematics']}
    meta = {}
    for s in bj['scenes']:
        sid = s['id']
        if sid not in scenes:
            continue
        if sid in fj:
            f = fj[sid]
            m = dict(preroll=f['preroll'], cue_record=f['cue_record'], lead_s=s['window']['window_s'][0], census=[x[0] for x in f['census']], times=[x[1] for x in f['census']])
        else:
            c = cat[sid]
            run = census / c['run']
            t0 = c['cd_request_time']
            idx = C.P.read_index(run)
            every = C.frames_for(run, t0, t0 + c['track_seconds'])
            m = dict(preroll=cj['preroll'][sid], cue_record=0.5, lead_s=0.0, census=every, times=[float(idx[x]['time']) - t0 for x in every])
        m.update(tail_frames=(s.get('window') or {}).get('tail_frames', 0), window=s.get('window'))
        meta[sid] = m
    return meta

def boundaries(frames):
    """Each change of the lit picture's source between START and play: (before, after, the last lit"""
    out, last = ([], None)
    for i, (f, src, lit, row) in enumerate(frames):
        if not lit or src == 'held':
            continue
        if last is not None and src != last[1]:
            black = sum((1 for g in frames[last[2] + 1:i] if not g[2]))
            out.append(dict(before=last[1], after=src, last_lit=last[0], first_lit=f, black=black))
        last = (f, src, i)
    return out

def pace(frames, sid):
    """A cinematic's frames from its first record on: frames whose record count did not advance by"""
    on = [(f[0], f[3]['records']) for f in frames if f[1] == sid]
    top = max((r for _, r in on), default=0)
    steps = [b[1] - a[1] for a, b in zip(on, on[1:]) if a[1] >= 1 and a[1] < top]
    return dict(frames=len(on), records=top, repeated=sum((1 for d in steps if d == 0)), skipped=sum((1 for d in steps if d > 1)))

def hold(frames, before, after, pre):
    """Frames the screen keeps the scene before's last picture while a continued scene is set up: from"""
    top = max((f[3]['records'] for f in frames if f[1] == before))
    a = sum((1 for f in frames if f[1] == before and f[3]['records'] == top)) - 1
    b = sum((1 for f in frames if f[1] == after and f[3]['records'] <= pre))
    return a + b

def judge(frames, play, meta, stock_ref, scenes_expected, continues):
    """The boundaries of a build run against their budgets, and each cinematic's pace."""
    seen = []
    for f in frames:
        if f[1] != 'held' and (not seen or seen[-1] != f[1]):
            seen.append(f[1])
    want = ['coin'] + list(scenes_expected) + ['globe', 'stage intro']
    rep, ok = ([], seen[:len(want)] == want and (play is not None or stock_ref is None))
    for b in boundaries(frames):
        before, after = (b['before'], b['after'])
        if after in meta and continues.get(after) == before:
            h = hold(frames, before, after, meta[after]['preroll'])
            budget = 0
            good = b['black'] == 0 and h <= SETUP_MAX + meta[after]['preroll']
            why = f"continued: no black; the last picture held {h} frames <= setup {SETUP_MAX} + pre-roll {meta[after]['preroll']}"
            b.update(hold=h)
        elif after in meta:
            budget = (1 if before == 'coin' else 0) + SETUP_MAX + meta[after]['preroll']
            good = b['black'] <= budget
            why = f"WAIT + setup <= {SETUP_MAX} + pre-roll {meta[after]['preroll']}"
        elif stock_ref is None:
            budget, good, why = (None, True, 'reported (no stock reference)')
        elif before in meta and after == 'globe':
            tail = meta[before].get('tail_frames', 0)
            budget = tail + HANDBACK_MAX + stock_ref['globe_dark']
            good = b['black'] <= budget
            why = f"sound tail {tail} + hand-back {HANDBACK_MAX} + the globe's dark start {stock_ref['globe_dark']} (stock)"
        else:
            budget = stock_ref['boundaries'].get(f'{before} -> {after}')
            good = budget is not None and b['black'] <= budget
            why = 'as stock'
        rep.append(dict(b, budget=budget, rule=why, passed=bool(good)))
        ok &= bool(good)
    paces = {sid: pace(frames, sid) for sid in meta}
    pace_ok = all((p['repeated'] == 0 and p['skipped'] == 0 for p in paces.values()))
    runs = black_runs(frames)
    globe = lit_runs(frames, 'globe')
    globe_ok = stock_ref is None or len(globe) == stock_ref['globe_runs']
    return dict(order=seen, expected=want, play_frame=play, boundaries=rep, pace=paces, globe_lit_runs=globe, inside=[r for r in runs if r['inside']], passed=bool(ok and pace_ok and globe_ok))

def lit_runs(frames, src):
    """[(first, last)] of the lit runs among a source's frames."""
    out = []
    for f in frames:
        if f[1] != src or not f[2]:
            continue
        if out and f[0] == out[-1][1] + 1:
            out[-1][1] = f[0]
        else:
            out.append([f[0], f[0]])
    return out

def stock_reference(frames, play):
    """The stock run's boundaries, and the globe's dark start (from the intro flag to its first lit frame)."""
    flag = next((f[0] for f in frames if f[3]['flag']))
    lit_globe = next((f[0] for f in frames if f[1] == 'globe' and f[2]))
    return dict(globe_dark=lit_globe - flag, play_frame=play, globe_runs=len(lit_runs(frames, 'globe')), boundaries={f"{b['before']} -> {b['after']}": b['black'] for b in boundaries(frames)})

def cue_check(rows, frames, meta, cues):
    """Pack runs: each scene's cue on the frame its stream's first frame shows (records = pre-roll + 1),"""
    out, ok = ([], True)
    sound = [(r['frame'], v) for r in rows for v in r['sound']]
    for sid, m in meta.items():
        on = [f for f in frames if f[1] == sid]
        if not on:
            out.append(dict(scene=sid, passed=False, why='not played'))
            ok = False
            continue
        f0 = next((f[0] for f in on if f[3]['records'] >= m['preroll'] + 1), None)
        sent = [f for f, v in sound if v & 255 == cues[sid] and on[0][0] - 1 <= f <= on[-1][0]]
        good = f0 is not None and len(sent) == 1 and (0 <= sent[0] - f0 <= 1)
        out.append(dict(scene=sid, first_frame_shown=f0, cue=f'{cues[sid]:#04x}', cue_frames=sent, passed=bool(good)))
        ok &= bool(good)
    return dict(scenes=out, passed=bool(ok))
AV_TOL = 1.5 / 59.637

def av_check(rows, frames, meta, cues, hz=59.637):
    """Pack runs: the picture against the voice, per scene. The pack's track starts at its window"""
    out, ok = ({}, True)
    sound = [(r['frame'], v) for r in rows for v in r['sound']]
    for sid, m in meta.items():
        on = [f for f in frames if f[1] == sid]
        if not on:
            out[sid], ok = (dict(passed=False, why='not played'), False)
            continue
        sent = [f for f, v in sound if v & 255 == cues[sid] and on[0][0] - 1 <= f <= on[-1][0]]
        if len(sent) != 1:
            out[sid], ok = (dict(passed=False, why=f'cue writes {sent}'), False)
            continue
        seen, offs = (set(), [])
        for f in on:
            r = f[3]['records']
            k = r - 1 - m['preroll']
            if r in seen or not 0 <= k < len(m['times']):
                continue
            seen.add(r)
            offs.append(m['times'][k] - (m['lead_s'] + (f[0] - sent[0]) / hz))
        good = bool(offs) and max((abs(o) for o in offs)) <= AV_TOL
        out[sid] = dict(records=len(offs), offset_ms=dict(first=round(1000 * offs[0], 1), last=round(1000 * offs[-1], 1), min=round(1000 * min(offs), 1), max=round(1000 * max(offs), 1)) if offs else None, passed=good)
        ok &= good
    return dict(scenes=out, tolerance_ms=round(1000 * AV_TOL, 1), passed=bool(ok))

def scene_rgb(word):
    import scene_gate as SG
    return tuple((int(v) for v in SG.hb_rgb(word)))

class Dots:
    """The census pixels the PC Engine drew from its map's own words (cinematic_convert.bat_tiles), per"""

    def __init__(self, census, scenes, source=None):
        """source: a build whose blanked.json and frames.json (build_ex.py) name the census frames the"""
        import cinematic_convert as C
        self.C = C
        cat = {c['id']: c for c in json.loads((census / 'catalog/catalog.json').read_text())['cinematics']}
        self.census, self.cat, self.pix = (census, cat, {})
        known = None
        if source is not None and (source / 'blanked.json').exists():
            bl = json.loads((source / 'blanked.json').read_text())
            fr = json.loads((source / 'frames.json').read_text())
            known = {sid: {fr[sid]['census'][int(k)][0] for k in bl[sid]['frames']} for sid in scenes if sid in bl}
        for sid in scenes:
            c = cat[sid]
            run = census / c['run']
            every = C.frames_for(run, c['cd_request_time'], c['cd_request_time'] + c['track_seconds'])
            writes = C.P.read_writes(run)
            idx = C.P.read_index(run)
            hide = ()
            if sid in BX.TITLE_SHOT:
                t_title = c['cd_request_time'] + next((x['start_t'] for x in c['shots'] if x['shot'] == BX.TITLE_SHOT[sid]))
                hide = frozenset((f for f in every if float(idx[f]['time']) >= t_title))
            pix = {}
            for f in sorted(known.get(sid, ())) if known is not None else every:
                d = C.load_frame(run, f, hide)
                g = C.P.geometry(d)
                bat = d['vram'][:g['map_w'] * g['map_h']] & 2047
                if not (bat < g['map_w'] * g['map_h'] // 16).any():
                    continue
                raw = C.reference(d, writes.get(f), 16, raw=True)
                want = C.reference(d, writes.get(f), 16, copyright=False)
                if (raw != want).any():
                    ys, xs = np.nonzero(raw != want)
                    pix[f] = (ys, xs, np.array([scene_rgb(int(w)) for w in raw[ys, xs]], np.int32))
            self.pix[sid] = pix

    def check(self, shots, meta):
        """shots: [(scene, records, image)] of a run's cinematic frames. A frame after r records shows"""
        hits, looked = ([], 0)
        for sid, rec, img in shots:
            if sid not in self.pix or img is None:
                continue
            k = rec - 1 - meta[sid]['preroll']
            frames = meta[sid]['census']
            if not 0 <= k < len(frames) or frames[k] not in self.pix[sid]:
                continue
            ys, xs, rgb = self.pix[sid][frames[k]]
            looked += 1
            lit = int((np.abs(img[ys, xs].astype(np.int32) - rgb) <= 4).all(-1).sum())
            if lit:
                hits.append(dict(scene=sid, records=rec, census_frame=frames[k], lit=lit, of=len(ys)))
        return dict(frames_checked=looked, frames_with_dots=len(hits), first=hits[:5], passed=looked > 0 and (not hits))

def bars_check(shots):
    bad = [dict(scene=s, records=r) for s, r, img in shots if img is not None and (img[:, :PICTURE[0]].any() or img[:, PICTURE[1]:].any())]
    return dict(frames=len(shots), lit_bars=len(bad), first=bad[:5], passed=not bad)

class Copyright:
    """The PC Engine title's copyright line (cinematic_convert.COPYRIGHT_GLYPHS), located without the"""

    def __init__(self, census, build):
        import cinematic_convert as C
        P = C.P
        cat = {c['id']: c for c in json.loads((census / 'catalog/catalog.json').read_text())['cinematics']}
        fj = json.loads((build / 'frames.json').read_text())
        self.pix, self.scanned = ({}, {})
        for sid, m in fj.items():
            c = cat[sid]
            run = census / c['run']
            writes, idx = (P.read_writes(run), P.read_index(run))
            hide = ()
            if sid in BX.TITLE_SHOT:
                t_title = c['cd_request_time'] + next((x['start_t'] for x in c['shots'] if x['shot'] == BX.TITLE_SHOT[sid]))
                hide = frozenset((f for f, _ in m['census'] if float(idx[f]['time']) >= t_title))
            frames = sorted({f for f, _ in m['census']})
            self.scanned[sid] = len(frames)
            for f in frames:
                d = C.load_frame(run, f, hide)
                glyph = sorted(C.copyright_tiles(d))
                if not glyph:
                    continue
                w = writes.get(f)
                tiles = P.all_bg_tiles(d['vram'])
                alone, without = (np.zeros_like(tiles), tiles.copy())
                alone[glyph], without[glyph] = (tiles[glyph], 0)
                bg = P.render_layers(d, writes=w, tiles=alone)[0][16:16 + 224]
                shown = P.render(d, writes=w)[16:16 + 224]
                other = P.render(d, writes=w, tiles=without)[16:16 + 224]
                word = np.array([C.G.cps_color(int(v)) for v in d['pal']], np.int32)
                ys, xs = np.nonzero((bg != 0) & (shown == bg) & (word[shown] != word[other]))
                if len(ys):
                    rgb = np.array([scene_rgb(int(v)) for v in word[shown[ys, xs]]], np.int32)
                    self.pix[sid, f] = (ys, xs + PICTURE[0], rgb)

    def scenes(self):
        out = {}
        for sid, f in self.pix:
            out.setdefault(sid, []).append(f)
        return {sid: dict(census_frames=len(v), first=min(v), last=max(v)) for sid, v in out.items()}

    def shows(self, key, img):
        """The line's pixels a screenshot shows in the line's color (within the core's brightness table, as"""
        if key not in self.pix or img is None:
            return None
        ys, xs, rgb = self.pix[key]
        return (np.abs(img[ys, xs].astype(np.int32) - rgb) <= 4).all(-1)

    def check(self, shots, played):
        """shots: [(census key or None, image)] of a run's frames. Passes when it looked at frames with the"""
        looked, hits = (0, [])
        for key, img in shots:
            m = self.shows(key, img)
            if m is None:
                continue
            looked += 1
            if m.any():
                hits.append(dict(scene=key[0], census_frame=key[1], shown=int(m.sum()), of=len(m)))
        uncovered = sorted(set(self.scenes()) - set(played))
        return dict(frames_checked=looked, frames_with_line=len(hits), pixels_shown=sum((h['shown'] for h in hits)), scenes=self.scenes(), census_frames_scanned=self.scanned, uncovered_scenes=uncovered, first=hits[:5], passed=looked > 0 and (not hits) and (not uncovered))

def shown_key(frame, meta, continues):
    """(scene, census frame) a run frame shows: its stream frame (records - 1 - pre-roll); during a continued"""
    _, sid, _, row = frame
    if sid not in meta:
        return None
    k = row['records'] - 1 - meta[sid]['preroll']
    if k < 0:
        prev = continues.get(sid)
        return (prev, meta[prev]['census'][-1]) if prev in meta else None
    return (sid, meta[sid]['census'][min(k, len(meta[sid]['census']) - 1)])

def place(frame, meta, seen):
    """Where a run frame stands, for pairing two runs: a cinematic's frame by its stream frame (records - 1 -"""
    _, sid, _, row = frame
    if sid in meta and row['records']:
        p = (sid, row['records'] - 1 - meta[sid]['preroll'])
    else:
        n = seen.get(('#', sid), 0)
        seen['#', sid] = n + 1
        p = ('setup' if sid in meta else 'n', sid, n)
    j = seen.get(p, 0)
    seen[p] = j + 1
    return (p, j)

def pairs(build_run, ctl_run):
    """(build frame, control frame) pairs from START to play that show the same thing (place), and what does not"""
    (_, bfr, bmeta, _), (_, cfr, cmeta, _) = (build_run, ctl_run)
    cs, by = ({}, {})
    for f in cfr:
        p, j = place(f, cmeta, cs)
        by.setdefault(p, []).append(f)
    seen, out, lone, counts = ({}, [], [], {})
    for f in bfr:
        p, j = place(f, bmeta, seen)
        counts[p] = j + 1
        if p in by:
            out.append((f, by[p][min(j, len(by[p]) - 1)]))
            continue
        sid, k = (p[0], p[1])
        pre = [q for q in by if len(q) == 2 and q[0] == sid and (q[1] < 0)]
        if len(p) == 2 and k < 0 and pre and (sid in cmeta) and (bmeta[sid]['preroll'] != cmeta[sid]['preroll']):
            out.append((f, by[min(pre, key=lambda q: q[1])][0]))
        else:
            lone.append(dict(frame=f[0], place=str(p)))

    def preroll(p):
        return len(p) == 2 and p[1] < 0 and (p[0] in bmeta) and (bmeta[p[0]]['preroll'] != cmeta[p[0]]['preroll'])
    gone = [str(p) for p in by if p not in counts and (not preroll(p))]
    differ = [dict(place=str(p), build=counts.get(p, 0), control=len(v)) for p, v in by.items() if counts.get(p, 0) != len(v) and (not preroll(p))]
    return (out, dict(build_frames=len(bfr), control_frames=len(cfr), unpaired_build=lone[:5], unpaired_count=len(lone), control_places_missing=gone[:5], missing_count=len(gone), count_differs=differ[:5], count_differs_count=len(differ), prerolls={s: [bmeta[s]['preroll'], cmeta[s]['preroll']] for s in cmeta if s in bmeta}))
STOCK = ('globe', 'stage intro')
EX_DIFF_LIST = 64
STAR_STEP = 16

def star_steps(phases, shifts):
    """Whether stock frames that differ (their frame numbers mod STAR_STEP: phases) are only those a star step"""
    if len(shifts) > 1:
        return False
    shift = next(iter(shifts), 0)
    if not phases:
        return True
    return 0 < shift < STAR_STEP and any((all(((q - p) % STAR_STEP < shift for q in phases)) for p in range(STAR_STEP)))

def same_check(line, build_run, ctl_run):
    """The build against the copyright control from START to play, each frame against the control's frame that"""
    (bout, bfr, bmeta, bcont), (cout, cfr, cmeta, ccont) = (build_run, ctl_run)
    same_meta = all((bmeta.get(s, {}).get(k) == cmeta[s].get(k) for s in cmeta for k in ('census', 'times')))
    pr, rep = pairs(build_run, ctl_run)
    frames = line_frames = line_pixels = missing = 0
    by, worst, ex_diff = ({}, [], [])
    for b, c in pr:
        ib, ic = (png(bout, b[0]), png(cout, c[0]))
        if ib is None or ic is None:
            missing += 1
            continue
        frames += 1
        want = ic.copy()
        key = shown_key(c, cmeta, ccont)
        m = line.shows(key, ic)
        if m is not None and m.any():
            ys, xs, _ = line.pix[key]
            want[ys[m], xs[m]] = 0
            line_frames += 1
            line_pixels += int(m.sum())
        diff = (ib != want).any(-1)
        src = b[1] if b[1] in STOCK else 'EX'
        st = by.setdefault(src, dict(frames=0, differing=0, pixels=0, phases=[], shifts=[]))
        st['frames'] += 1
        if src != 'EX':
            st['shifts'] = sorted(set(st['shifts']) | {b[0] - c[0]})
        if diff.any():
            st['differing'] += 1
            st['pixels'] += int(diff.sum())
            st['phases'] = sorted(set(st['phases']) | {b[0] % STAR_STEP})
            worst.append((int(diff.sum()), b[0], c[0], b[1], b[3]['records']))
            if src == 'EX':
                yy, xx = diff.nonzero()
                ex_diff.append(dict(frame=b[0], control_frame=c[0], scene=b[1], records=b[3]['records'], pixels=int(diff.sum()), y=[int(yy.min()), int(yy.max())], x=[int(xx.min()), int(xx.max())]))
    worst.sort(reverse=True)
    paired = not (rep['unpaired_count'] or rep['missing_count'] or rep['count_differs_count'])
    ex_same = by.get('EX', {}).get('differing', 1) == 0
    stock_star = star_steps({q for k, v in by.items() if k != 'EX' for q in v['phases']}, {q for k, v in by.items() if k != 'EX' for q in v['shifts']})
    return dict(frames_json_same=same_meta, pairing=rep, frames=frames, missing_screenshots=missing, frames_with_line_in_control=line_frames, line_pixels_in_control=line_pixels, by_source=by, frames_differing=sum((v['differing'] for v in by.values())), worst=[dict(pixels=w[0], frame=w[1], control_frame=w[2], source=w[3], records=w[4]) for w in worst[:5]], ex_differing=ex_diff[:EX_DIFF_LIST], ex_differing_count=len(ex_diff), passed=bool(same_meta and paired and (not missing) and frames and line_frames and ex_same and stock_star))

def copyright_png(path, line, build_run, ctl_run, keep=8):
    """Review: frames the copyright line was removed from, per scene its first, a full one, one from the"""
    (bout, bfr, _, _), (cout, cfr, cmeta, ccont) = (build_run, ctl_run)
    hit = []
    for b, c in pairs(build_run, ctl_run)[0]:
        key = shown_key(c, cmeta, ccont)
        ic = png(cout, c[0]) if key in line.pix else None
        m = line.shows(key, ic)
        if m is not None and m.any():
            hit.append((b, c, key, int(m.sum())))
    if not hit:
        return 0
    picks, seen = ([], set())
    by_scene = {}
    for h in hit:
        by_scene.setdefault(h[2][0], []).append(h)
    for sid, hs in by_scene.items():
        full = max((h[3] for h in hs))
        for h in (hs[0], next((h for h in hs if h[3] == full)), hs[len(hs) // 2], hs[-1]):
            if h[0][0] not in seen:
                seen.add(h[0][0])
                picks.append(h)
    picks = picks[:keep]
    w, h2 = (384 * 2, 224 * 2)
    img = Image.new('RGB', (2 * w + 30, (h2 + 30) * len(picks) + 10), (255, 255, 255))
    d = ImageDraw.Draw(img)
    for i, (b, c, key, n) in enumerate(picks):
        y = 10 + (h2 + 30) * i
        d.text((10, y), f"{key[0]} census frame {key[1]}: run frame {c[0]}, records {c[3]['records']}; the control shows {n} line pixels (left: control, right: this build)", fill=(0, 0, 0))
        for k, pic in enumerate((png(cout, c[0]), png(bout, b[0]))):
            if pic is not None:
                img.paste(Image.fromarray(pic).resize((w, h2), Image.NEAREST), (10 + k * (w + 10), y + 20))
    img.save(path)
    return len(picks)
COLORS = {'coin': (90, 90, 90), 'held': (200, 60, 60), 'globe': (60, 130, 200), 'stage intro': (60, 170, 90)}
SCENE_COLORS = [(230, 170, 40), (170, 90, 210), (40, 190, 190), (210, 110, 60)]

def timeline_png(path, runs):
    """One strip per run: a column per frame from START to play, lit frames full height, black ones a"""
    width = max((len(fr) for _, fr in runs)) + 220
    img = Image.new('RGB', (width, 34 * len(runs) + 10), (255, 255, 255))
    d = ImageDraw.Draw(img)
    for i, (label, fr) in enumerate(runs):
        y = 10 + 34 * i
        d.text((4, y + 8), label[:34], fill=(0, 0, 0))
        scenes = [s for s in dict.fromkeys((f[1] for f in fr)) if s not in COLORS]
        for k, f in enumerate(fr):
            c = COLORS.get(f[1]) or SCENE_COLORS[scenes.index(f[1]) % len(SCENE_COLORS)]
            if f[2]:
                d.line([(210 + k, y), (210 + k, y + 24)], fill=c)
            else:
                d.line([(210 + k, y + 22), (210 + k, y + 24)], fill=(0, 0, 0))
                d.point((210 + k, y + 12), fill=c)
    img.save(path)

def transitions_png(path, items):
    """items: [(label, last lit image, first lit image, black frames)]."""
    if not items:
        return
    w, h = (192, 112)
    img = Image.new('RGB', (2 * w + 230, (h + 6) * len(items) + 6), (255, 255, 255))
    d = ImageDraw.Draw(img)
    for i, (label, a, b, n) in enumerate(items):
        y = 6 + (h + 6) * i
        for k, pic in enumerate((a, b)):
            if pic is not None:
                img.paste(Image.fromarray(pic).resize((w, h)), (220 + k * (w + 4), y))
        d.text((4, y + 40), label[:36], fill=(0, 0, 0))
        d.text((4, y + 56), f'{n} black frames', fill=(160, 0, 0))
    img.save(path)

def measure(binary, roms, set_name, out, streams, stock=False):
    rows = run(binary, roms, set_name, out)
    for r in rows:
        img = png(out, r['frame'])
        if img is not None:
            r['lit'] = bool(img.any())
    frames, play = segments(rows, streams, stock)
    return (rows, frames, play)

def cmd_gate(a):
    work = a.workdir.resolve()
    work.mkdir(parents=True, exist_ok=False)
    binary = json.loads((a.runtime / 'runtime.json').read_text())['binary']
    expected = BX.STAGE_SCENES[0]
    dots = Dots(a.census.resolve(), expected, a.build.resolve())
    line = Copyright(a.census.resolve(), a.build.resolve())
    print('copyright line located:', json.dumps(line.scenes()), flush=True)
    report, ok, strips, tpics = (dict(runs={}, stock={}, copyright_line=line.scenes()), True, [], [])
    builds = (('build', a.build.resolve()), ('control', a.control.resolve()), ('copyright_control', a.copyright_control.resolve()))
    for set_name in a.sets.split(','):
        parent = PARENT[set_name]
        rows, frames, play = measure(a.mame, a.rom_dir.resolve(), parent, work / f'stock_{parent}', None, stock=True)
        ref = stock_reference(frames, play)
        report['stock'][parent] = dict(globe_dark=ref['globe_dark'], play_frame=play, boundaries=ref['boundaries'])
        strips.append((f'stock {parent}', frames))
        for variant in ('nopack', 'pack'):
            done = {}
            for which, build in builds:
                bj = json.loads((build / 'build.json').read_text())
                bset = bj['sets'][parent]
                meta = scene_meta(build, a.census.resolve(), expected)
                continues = {s['id']: s['continues'] for s in bj['scenes'] if s.get('continues')}
                tag = f'{which}_{set_name}_{variant}'
                sets = stage(build, set_name, variant, a.hbmame, a.rom_dir.resolve(), work / tag)
                out = work / tag / 'run'
                rows, frames, play = measure(binary, sets, set_name, out, bset['streams'])
                j = judge(frames, play, meta, ref, [s for s in expected if s in bset['streams']], continues)
                shots = [(f[1], f[3]['records'], png(out, f[0])) for f in frames if f[1] in meta]
                r = dict(timeline=j, dots=dots.check(shots, meta), bars=bars_check(shots))
                if variant == 'pack':
                    cues = {sid: bset['cues'][sid][bset['region_en']] for sid in meta}
                    r['cues'] = cue_check(rows, frames, meta, cues)
                    r['av'] = av_check(rows, frames, meta, cues)
                if which != 'control':
                    r['copyright'] = line.check([(shown_key(f, meta, continues), png(out, f[0])) for f in frames], [sid for sid in meta if any((f[1] == sid for f in frames))])
                done[which] = (out, frames, meta, continues, j)
                report['runs'][tag] = r
                strips.append((tag, frames))
                if variant == 'nopack' and set_name == 'striderus01' and (which != 'copyright_control'):
                    for t in j['boundaries']:
                        tpics.append((f"{which}: {t['before']} -> {t['after']}", png(out, t['last_lit']), png(out, t['first_lit']), t['black']))
                (out / 'frames.json').write_text(json.dumps([[f[0], f[1], f[2], f[3]['records']] for f in frames]))
            b, c = (done['build'][:4], done['copyright_control'][:4])
            rb = report['runs'][f'build_{set_name}_{variant}']
            rb['copyright_same'] = same_check(line, b, c)
            if variant == 'nopack':
                rb['copyright_review'] = copyright_png(work / f'copyright_{set_name}.png', line, b, c)
            for which, _ in builds:
                tag = f'{which}_{set_name}_{variant}'
                r = report['runs'][tag]
                r['passed'] = all((v['passed'] for k, v in r.items() if isinstance(v, dict)))
                if which == 'build':
                    ok &= r['passed']
                elif which == 'control':
                    ok &= not (r['timeline']['passed'] or r['dots']['passed'] or (variant == 'pack' and (r['cues']['passed'] or r['av']['passed'])))
                else:
                    ok &= not r['copyright']['passed']
                j = done[which][4]
                summary = {k: v.get('passed') for k, v in r.items() if isinstance(v, dict)}
                print(tag, json.dumps(dict(summary, boundaries=[(t['before'], t['after'], t['black'], t.get('hold'), t['budget']) for t in j['boundaries']], pace=j['pace'], copyright={f'{k}.{n}': r[k].get(n) for k, n in (('copyright', 'frames_checked'), ('copyright', 'frames_with_line'), ('copyright_same', 'frames'), ('copyright_same', 'frames_differing')) if k in r})), flush=True)
                out = done[which][0]
                keep = {g for t in j['boundaries'] for g in range(t['last_lit'] - 8, t['first_lit'] + 9)}
                for q in out.glob('f_*.png'):
                    if int(q.stem[2:]) not in keep:
                        q.unlink()
    timeline_png(work / 'timeline.png', strips)
    transitions_png(work / 'transitions.png', tpics)
    report['passed'] = ok
    (work / 'report.json').write_text(json.dumps(report, indent=1, default=str) + '\n')
    print('PASS' if ok else 'FAIL')
    return 0 if ok else 1
PNG_LAG = 11

def rtl_rows(run):
    """Per probe frame: ACTIVE, records, the stream pointer (probe.log M writes) and the sound latch writes."""
    sys.path.insert(0, str(ROOT / 'backports/striderex/rtl'))
    import jtcps1_sim as J
    _, ev = J.probe_events(run)
    state, act, hi, rec, lzh, lz = ({}, 0, 0, 0, 0, 0)
    snd = {}
    last = max((e[1] for e in ev), default=0)
    it = iter(ev)
    e = next(it, None)
    for f in range(last + 1):
        while e is not None and e[1] == f:
            kind, _, _, addr, v = e
            if kind == 'M':
                if addr == 16775444:
                    act = v
                elif addr == 16775424:
                    hi = v
                elif addr == 16775426:
                    rec = hi << 16 | v
                elif addr == 16775428:
                    lzh = v
                elif addr == 16775430:
                    lz = lzh << 16 | v
            elif kind == 'W' and addr == 8388992 and (v & 255 != 255):
                snd.setdefault(f, []).append(v)
            e = next(it, None)
        state[f] = (act, rec, lz)
    return (state, snd)

def cmd_rtl(a):
    run = a.run.resolve()
    bj = json.loads((a.build / 'build.json').read_text())
    bset = bj['sets']['striderua']
    expected = BX.STAGE_SCENES[0]
    meta = scene_meta(a.build.resolve(), a.census.resolve(), expected)
    state, snd = rtl_rows(run)
    name = scene_namer(bset['streams'])
    pngs = sorted((int(q.stem[2:]) for q in run.glob('f_*.png')))
    frames, rows = ([], [])
    flag_seen = False
    for f in pngs:
        if f < a.start:
            continue
        act, rec, lz = state.get(f - PNG_LAG, (0, 0, 0))
        img = png(run, f)
        if act == ON:
            src = name(lz)
        elif act in (HOLD, WAIT, CARD):
            src = 'held'
        else:
            flag_seen |= any((fr[1] in meta for fr in frames))
            src = 'stock' if flag_seen else 'coin'
        row = dict(frame=f, records=rec, flag=int(flag_seen), sound=snd.get(f - PNG_LAG, []))
        frames.append((f, src, bool(img.any()), row))
        rows.append(row)
    k = next((i for i, fr in enumerate(frames) if fr[1] == 'stock'), None)
    if k is not None:
        lit_run, phase = (0, 'globe')
        for i in range(k, len(frames)):
            f, src, lit, row = frames[i]
            if src != 'stock':
                continue
            if phase == 'globe' and lit_run >= 60 and (not lit):
                phase = 'stage intro'
            lit_run = lit_run + 1 if lit else 0
            frames[i] = (f, phase, lit, row)
    continues = {s['id']: s['continues'] for s in bj['scenes'] if s.get('continues')}
    j = judge(frames, None, meta, None, [s for s in expected if s in bset['streams']], continues)
    shots = [(f[1], f[3]['records'], png(run, f[0])) for f in frames if f[1] in meta]
    dots = Dots(a.census.resolve(), expected, (a.dots_from or a.build).resolve()).check(shots, meta)
    cues = {sid: bset['cues'][sid][bset['region_en']] for sid in meta}
    rep = dict(timeline=j, dots=dots, bars=bars_check(shots))
    if (a.build / 'frames.json').exists():
        rep['copyright'] = Copyright(a.census.resolve(), a.build.resolve()).check([(shown_key(f, meta, continues), png(run, f[0])) for f in frames], [sid for sid in meta if any((f[1] == sid for f in frames))])
    if any((v for fr in frames for v in fr[3]['sound'] if v & 255 in cues.values())):
        rep['cues'] = cue_check(rows, frames, meta, cues)
        rep['av'] = av_check(rows, frames, meta, cues)
    rep['passed'] = all((v['passed'] for v in rep.values() if isinstance(v, dict)))
    print(json.dumps(dict({k: v.get('passed') for k, v in rep.items() if isinstance(v, dict)}, boundaries=[(t['before'], t['after'], t['black'], t.get('hold'), t['budget']) for t in j['boundaries']], pace=j['pace'], dots=dots), default=str))
    if a.json:
        a.json.write_text(json.dumps(rep, indent=1, default=str) + '\n')
    timeline_png(run / 'start_flow_timeline.png', [(run.name, frames)])
    return 0 if rep['passed'] else 1

def self_test():
    fr = [(400 + i, s, lit, {}) for i, (s, lit) in enumerate([('coin', True), ('held', False), ('held', False), ('a', False), ('a', True), ('a', False), ('a', True), ('held', False), ('b', False), ('b', True), ('globe', False), ('globe', True)])]
    runs = black_runs(fr)
    assert [(r['first'], r['frames'], r['before'], r['after'], r['inside']) for r in runs] == [(401, 3, 'coin', 'a', False), (405, 1, 'a', 'a', True), (407, 2, 'a', 'b', False), (410, 1, 'b', 'globe', False)]
    assert held_frames(runs[0], fr) == 2
    assert [(b['before'], b['after'], b['black']) for b in boundaries(fr)] == [('coin', 'a', 3), ('a', 'b', 2), ('b', 'globe', 1)]
    rec = [(0, 'a', True, dict(records=r)) for r in (1, 2, 3, 3, 5, 6, 6)]
    assert pace(rec, 'a') == dict(frames=7, records=6, repeated=1, skipped=1)
    meta = {'a': dict(preroll=2, census=[10, 11, 12]), 'b': dict(preroll=3, census=[20, 21])}
    keys = [shown_key((0, s, True, dict(records=r)), meta, {'b': 'a'}) for s, r in (('a', 2), ('a', 3), ('a', 5), ('a', 7), ('b', 0), ('b', 3), ('b', 4), ('b', 9), ('held', 4))]
    assert keys == [None, ('a', 10), ('a', 12), ('a', 12), ('a', 12), ('a', 12), ('b', 20), ('b', 21), None], keys

    def run_of(pre_b):
        seq = [('coin', 0)] * 2 + [('a', r) for r in (0, 1, 2, 3, 4, 5, 5)] + [('b', r) for r in [0] + list(range(1, pre_b + 3))]
        seq += [('globe', 0)] * 2
        return [(400 + i, s, True, dict(records=r)) for i, (s, r) in enumerate(seq)]
    mb, mc = (dict(meta, b=dict(preroll=4, census=[20, 21])), meta)
    pr, rep = pairs((None, run_of(4), mb, {}), (None, run_of(3), mc, {}))
    assert rep['unpaired_count'] == rep['missing_count'] == rep['count_differs_count'] == 0, rep
    got = [(b[0], c[0]) for b, c in pr]
    assert len(got) == len(run_of(4)) and got[:9] == [(400 + i, 400 + i) for i in range(9)], got
    assert got[9:] == [(409, 409), (410, 410), (411, 410), (412, 411), (413, 412), (414, 413), (415, 414), (416, 415), (417, 416)], got[9:]
    assert star_steps({1}, {1}) and star_steps({1, 2, 3, 4}, {4}) and star_steps({15, 0}, {2}) and star_steps(set(), {0})
    assert not star_steps({1, 3}, {1}) and (not star_steps({1}, {0})) and (not star_steps({1}, {1, 2}))
    assert not star_steps({1, 2, 3, 4, 5}, {4})
    pr, rep = pairs((None, run_of(3)[:-1], mc, {}), (None, run_of(3), mc, {}))
    assert rep['count_differs_count'] == 1 and rep['missing_count'] == 1, rep
    print('self-test ok')
    return 0

def main():
    if len(sys.argv) > 1 and sys.argv[1] == '--self-test':
        return self_test()
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest='cmd', required=True)
    g = sub.add_parser('gate')
    for n in ('--build', '--control', '--copyright-control', '--census', '--runtime', '--hbmame', '--rom-dir', '--workdir'):
        g.add_argument(n, type=Path, required=True)
    g.add_argument('--mame', default='mame', help='stock MAME, for the stock reference runs')
    g.add_argument('--sets', default='striderus01,striderjs01')
    r = sub.add_parser('rtl')
    for n in ('--run', '--build', '--census'):
        r.add_argument(n, type=Path, required=True)
    r.add_argument('--start', type=int, default=START, help='the harness frame of the START press')
    r.add_argument('--dots-from', type=Path, help="a build whose blanked.json names the dots' census frames (default --build; a build before them scans every frame)")
    r.add_argument('--json', type=Path)
    a = p.parse_args()
    return cmd_gate(a) if a.cmd == 'gate' else cmd_rtl(a)
if __name__ == '__main__':
    sys.exit(main())
