"""Strider EX English dub: the durable take store, where every take is written as it is made."""
import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path
ROOT = Path(__file__).resolve().parents[3]
HERE = ROOT / 'backports/striderex'
TAKES = HERE / 'manifests/dub_takes.json'
STORE = Path('references/striderex/dub_takes')
ENV = 'STREX_TAKES_STORE'

def root():
    """The store's root; exits when it is not mounted, or is scratch."""
    if os.environ.get(ENV):
        r = Path(os.environ[ENV])
    else:
        roms = ROOT / 'roms'
        if not roms.exists():
            sys.exit(f'no durable take store: set {ENV} or mount the ROM library the roms/ link points at')
        r = roms.resolve().parent / STORE
    if not r.is_dir():
        sys.exit(f'the durable take store {r} is not there (mounted? create it deliberately)')
    work = (HERE / 'work').resolve()
    if r.resolve() == work or work in r.resolve().parents:
        sys.exit(f'{r} is scratch, not a durable store')
    return r

def check_name(name):
    if not name or name.startswith('.') or '/' in name or ('\\' in name):
        sys.exit(f'{name!r}: a set is a plain name in the store')
    return name

def new_set(name):
    """A fresh set in the store (created; an existing one is never written over)."""
    d = root() / check_name(name)
    d.mkdir(exist_ok=False)
    return d

def holding_set(name):
    """A set in the store that collects several renders (dub_runs.py render): created when missing."""
    d = root() / check_name(name)
    d.mkdir(exist_ok=True)
    return d

def dir_arg(value):
    """An argument naming a render or set: an existing path, else a path relative to the store."""
    p = Path(value)
    if p.exists():
        return p
    q = root() / value
    if q.exists():
        return q
    raise argparse.ArgumentTypeError(f'{value}: neither a path nor in the take store {root()}')

def in_store(path):
    """Is path inside the store?"""
    r = root().resolve()
    p = Path(path).resolve()
    return p == r or r in p.parents

def seal(d):
    """After writing into the store: AppleDouble files off the exFAT card (dot_clean -m)."""
    if shutil.which('dot_clean'):
        subprocess.run(['dot_clean', '-m', str(d)], check=False)

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def cmd_verify(a):
    m = json.loads(TAKES.read_text())
    d = root() / Path(m['store']['path']).relative_to(STORE)
    bad = [lid for lid, r in m['lines'].items() if not (d / f'{lid}.wav').exists() or sha(d / f'{lid}.wav') != r['wav_sha256']]
    print(f"{d}: {len(m['lines']) - len(bad)} of {len(m['lines'])} takes match their pins" + (f'; BAD: {bad}' if bad else ''))
    return 1 if bad else 0

def cmd_assemble(a):
    base = root() / check_name(a.base)
    if not base.is_dir():
        sys.exit(f'no set {a.base} in the store')
    picks = {}
    for spec in a.take or ():
        dest, src = spec.split('=', 1)
        s = Path(src) if Path(src).is_absolute() else root() / src
        if not s.is_file() or not in_store(s):
            sys.exit(f'{src}: a pick must be a file already in the take store (renders go there as they are made)')
        if Path(dest).is_absolute() or '..' in Path(dest).parts:
            sys.exit(f'{dest}: a path inside the new set')
        picks[dest] = s
    out = root() / check_name(a.set)
    if out.exists():
        sys.exit(f'{a.set} is already in the store')
    copied = {}
    tmp = root() / f'.{a.set}.partial'
    if tmp.exists():
        shutil.rmtree(tmp)
    for f in sorted((p for p in base.rglob('*') if p.is_file() and (not p.name.startswith('._')))):
        rel = f.relative_to(base)
        (tmp / rel).parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(f, tmp / rel)
        copied[str(rel)] = sha(f)
    record = dict(base=a.base, picks={}, at=time.strftime('%Y-%m-%d %H:%M:%S'))
    for dest, s in sorted(picks.items()):
        (tmp / dest).parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(s, tmp / dest)
        record['picks'][dest] = dict(source=str(s.relative_to(root())), wav_sha256=sha(s))
        copied[dest] = sha(s)
    for rel, want in copied.items():
        if sha(tmp / rel) != want:
            sys.exit(f'{rel}: the copy differs from its source')
    (tmp / 'assembly.json').write_text(json.dumps(record, indent=1) + '\n')
    tmp.rename(out)
    seal(out)
    print(f'{a.set}: {len(copied)} files from {a.base}, {len(picks)} picks; dub_takes.json store.path: {(STORE / a.set).as_posix()}')
    for dest, r in record['picks'].items():
        print(f"  {dest}: {r['source']} {r['wav_sha256'][:16]}")
    return 0

def self_test():
    import tempfile
    with tempfile.TemporaryDirectory() as t:
        os.environ[ENV] = t
        assert root() == Path(t)
        for bad in ('', '.x', 'a/b'):
            try:
                check_name(bad)
            except SystemExit:
                continue
            raise AssertionError(bad)
        d = new_set('s1')
        (d / 'a.wav').write_bytes(b'abc')
        (d / 'runs').mkdir()
        (d / 'runs' / 'r.wav').write_bytes(b'run')
        try:
            new_set('s1')
            raise AssertionError('a set was written over')
        except FileExistsError:
            pass
        h = holding_set('s2')
        (h / 'pick.wav').write_bytes(b'new')
        cmd_assemble(argparse.Namespace(set='s3', base='s1', take=['a.wav=s2/pick.wav']))
        s3 = Path(t) / 's3'
        assert (s3 / 'a.wav').read_bytes() == b'new' and (s3 / 'runs' / 'r.wav').read_bytes() == b'run'
        assert json.loads((s3 / 'assembly.json').read_text())['picks']['a.wav']['source'] == 's2/pick.wav'
        with tempfile.TemporaryDirectory() as outside:
            (Path(outside) / 'x.wav').write_bytes(b'x')
            try:
                cmd_assemble(argparse.Namespace(set='s4', base='s1', take=[f'a.wav={outside}/x.wav']))
                raise AssertionError('a pick from outside the store was taken')
            except SystemExit:
                pass
        assert dir_arg('s2') == Path(t) / 's2'
        del os.environ[ENV]
    print('self-test passed')
    return 0

def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('--self-test', action='store_true')
    sub = p.add_subparsers(dest='cmd')
    sub.add_parser('verify')
    s = sub.add_parser('assemble')
    s.add_argument('--set', required=True, help='the new set')
    s.add_argument('--base', required=True, help='the set it starts from (copied whole)')
    s.add_argument('--take', action='append', help='<file in the new set>=<a file in the store>, e.g. tr22.0.wav=hiryu_picks_20261017/tr22.0.wav')
    a = p.parse_args()
    if a.self_test:
        return self_test()
    if not a.cmd:
        p.error('a command or --self-test')
    return dict(verify=cmd_verify, assemble=cmd_assemble)[a.cmd](a)
if __name__ == '__main__':
    sys.exit(main())
