; A desert-only SCROLL3 state. Stock stages keep their original dispatcher,
; play handler and instruction timings. Native initialisation is relocated
; byte-for-byte to make room for the third dispatch pointer.
        org $1F4000
        dc.w $4EF9
        dc.l dm_setup
        dc.w $4EF9
        dc.l dm_frame

dm_setup:
        jsr S3
        move.b #8,-$7012(a5)
        rts

dm_frame:
        cmpi.b #2,1(a0)
        bne .stock
        move.w 8(a0),$10(a0)
        move.w 12(a0),$12(a0)
        move.w $12(a0),-(sp)
        jsr X_FOLLOW
        move.w (sp)+,$12(a0)
        move.w -$6F2A(a5),d0
        sub.w 12(a0),d0
        cmp.w $36(a0),d0
        bgt.s .up
        cmp.w $38(a0),d0
        blt.s .down
        rts
.up:    bsr dm_eligible
        bne.s .native_up
        sub.w $36(a0),d0
        bsr dm_step
        add.l 12(a0),d0
        swap d0
        cmp.w $2E(a0),d0
        bge .done
        swap d0
        move.l d0,12(a0)
        moveq #1,d5
        bra.s .stream
.native_up:
        jmp UP
.down:  bsr dm_eligible
        bne.s .native_down
        move.w $38(a0),d1
        sub.w d0,d1
        move.w d1,d0
        bsr dm_step
        neg.l d0
        add.l 12(a0),d0
        swap d0
        cmp.w $30(a0),d0
        ble.s .done
        swap d0
        move.l d0,12(a0)
        moveq #0,d5
.stream:
        move.w $12(a0),d0
        move.w 12(a0),d1
        eor.w d1,d0
        and.w #$FFE0,d0
        beq.s .done
        move.w 8(a0),$10(a0)
        move.w 12(a0),$12(a0)
        subi.w #$40,$10(a0)
        tst.w d5
        beq.s .row_down
        addi.w #$120,$12(a0)
        bra.s .row
.row_down:
        subi.w #$40,$12(a0)
.row:   jsr ROW
.done:  rts
.native_down:
        jmp DOWN
.stock: jmp PLAY

dm_step:
        ; Quarter-error follow retains 16.16 camera fractions, averaging
        ; the widened floor's integer sampling instead of taking 0/3px steps.
        and.l #$FFFF,d0
        swap d0
        lsr.l #2,d0
        cmp.l #$A0000,d0
        bls.s .done
        move.l #$A0000,d0
.done:  rts

dm_eligible:
        tst.b $FF10CD
        bne.s .done
        cmpi.b #2,$FF10EC
        beq.s .yes
        cmpi.b #7,$FF10EC
        bne.s .no
.yes:
        ori #4,ccr
.done:  rts
.no:    andi #$FB,ccr
        rts
