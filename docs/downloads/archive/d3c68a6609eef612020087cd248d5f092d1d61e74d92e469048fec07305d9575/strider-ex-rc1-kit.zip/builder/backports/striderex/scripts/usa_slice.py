"""D10a: the USA title logo sliced like the Japanese one."""
import sys
from pathlib import Path
import numpy as np
sys.path.insert(0, str(Path(__file__).resolve().parent))
import cps1_gfx as G
LINE = ((24, 29), (343, 188))
TABLE, MAP0, COLS, ROWS = (23604, 9517060, 12, 6)
S3_SCROLL = (65472, 1792)
S2_SCROLL = (65472, 768)
S2_BASE = 9486336
S3_BLANK, S2_BLANK = (32, 10272)
S2_FIRST, S2_LAST = (45056, 45311)

def above(x, y):
    (x0, y0), (x1, y1) = LINE
    return (x1 - x0) * (y - y0) - (y1 - y0) * (x - x0) < 0

def s3_screen(addr):
    idx = (addr - 9502720) // 4
    row = idx & 7 | idx >> 6 & 56
    col = idx >> 3 & 63
    return ((32 * col - 64 - S3_SCROLL[0]) % 2048, (32 * row - 16 - S3_SCROLL[1]) % 2048)

def s2_addr(sx, sy):
    mx, my = ((sx + 64 + S2_SCROLL[0]) % 1024, (sy + 16 + S2_SCROLL[1]) % 1024)
    col, row = (mx // 16, my // 16)
    return S2_BASE + 4 * ((row & 15) + ((col & 63) << 4) + ((row & 48) << 6))

def logo_cells(program):
    out = []
    for o in range(ROWS):
        for i in range(COLS):
            k = o * COLS + i
            out.append((MAP0 + 4 * o + 32 * i, int.from_bytes(program[TABLE + 2 * k:TABLE + 2 * k + 2], 'big')))
    return out

def split(program, gfx, stock_tile, next_s3, last_s3):
    """-> (s3 entries [(addr, stock code, new code, pens or None)], s2 entries [(addr, blank, code, pens)],"""
    s3, s2, code3, code2 = ([], [], next_s3, S2_FIRST)
    for addr, stock in logo_cells(program):
        x0, y0 = s3_screen(addr)
        pens = stock_tile(gfx, stock)
        up = np.array([[above(x0 + x, y0 + y) for x in range(32)] for y in range(32)])
        op = pens != 15
        if not (op & ~up).any():
            continue
        if (op & up).any():
            if code3 > last_s3:
                sys.exit('usa_slice: title SCROLL3 codes exhausted')
            top = np.where(up, pens, 15)
            s3.append((addr, stock, code3, top))
            code3 += 1
        else:
            s3.append((addr, stock, S3_BLANK, None))
        for qy in (0, 16):
            for qx in (0, 16):
                q = np.where(~up[qy:qy + 16, qx:qx + 16], pens[qy:qy + 16, qx:qx + 16], 15)
                if (q != 15).any():
                    if code2 > S2_LAST:
                        sys.exit('usa_slice: SCROLL2 codes exhausted')
                    s2.append((s2_addr(x0 + qx, y0 + qy), S2_BLANK, code2, q))
                    code2 += 1
    return (s3, s2, code3)

def check_halves(gfx, stock_tile, program, s3, s2):
    """The two halves together are the stock logo: every pixel of every logo cell comes back once."""
    new3 = {a: (c, p) for a, _, c, p in s3}
    s2_at = {a: p for a, _, _, p in s2}
    for addr, stock in logo_cells(program):
        x0, y0 = s3_screen(addr)
        want = stock_tile(gfx, stock)
        got = want if addr not in new3 else np.full((32, 32), 15) if new3[addr][1] is None else new3[addr][1]
        got = got.copy()
        for qy in (0, 16):
            for qx in (0, 16):
                a = s2_addr(x0 + qx, y0 + qy)
                if a in s2_at:
                    q = s2_at[a]
                    sub = got[qy:qy + 16, qx:qx + 16]
                    if ((q != 15) & (sub != 15)).any():
                        return f'cell {addr:#x}: a pixel in both halves'
                    sub[q != 15] = q[q != 15]
        if not (got == want).all():
            return f'cell {addr:#x}: the halves differ from the stock cell'
    return None

def install(region, s3, s2):
    for _, _, c, pens in s3:
        if pens is not None:
            at = G.ex_offset('scr3', c)
            if any(region[at:at + 512]):
                sys.exit(f'usa_slice: EX SCROLL3 code {c:#06x} is already in use')
            G.put_tile(region, at, pens)
    for _, _, c, pens in s2:
        at = G.ex_offset('scr2', c)
        if any(region[at:at + 128]):
            sys.exit(f'usa_slice: EX SCROLL2 code {c:#06x} is already in use')
        G.put_tile(region, at, pens)

def split_inc(s3, s2):
    """split_cells.inc: the split as title_patch entries (map address, expected code, new code), and the"""
    rows = [(a, s, c) for a, s, c, _ in s3] + [(a, s, c) for a, s, c, _ in s2]
    probe = next(((a, c, s) for a, s, c, p in s3 if p is not None))
    lines = [f'SPLIT_PROBE_ADDR equ ${probe[0]:06X}', f'SPLIT_PROBE_CODE equ ${probe[1]:04X}', f'SPLIT_PROBE_STOCK equ ${probe[2]:04X}', 'split_cells:', f'        dc.w    {len(rows)}']
    for a, s, c in rows:
        lines += [f'        dc.l    ${a:06X}', f'        dc.w    ${s:04X},${c:04X}']
    return '\n'.join(lines) + '\n'
