"""Focused Earth-palette acceptance in both regions, with and without CPS+."""
import argparse
from concurrent.futures import ThreadPoolExecutor
from copy import deepcopy
import json
from pathlib import Path
import subprocess
import sys
from types import SimpleNamespace
import earth_palette as EP
import respawn_fix as RF
ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / 'backports/striderex/rtl'))
import jtcps1_sim as J

def stage_symbols(files, machine):
    program = RF.compose(files, RF.SETS[machine])
    bank = files['strex_p6.bin']
    bank = bytes((bank[i ^ 1] for i in range(len(bank))))
    for at in (9552, 13698):
        if program[at:at + 2] != bytes.fromhex('4ef9'):
            raise ValueError('unknown stage-select hook')
    buttons = [i + 1048576 for i in range(0, len(bank), 2) if bank[i:i + 12] == bytes.fromhex('30390080000046403200e049')]
    if len(buttons) != 1:
        raise ValueError('ambiguous stage-select button routine')
    return dict(stage_sel=int.from_bytes(program[9554:9558], 'big'), ss_buttons=buttons[0], rank_check=int.from_bytes(program[13700:13704], 'big'))

def gate(a):
    work = a.workdir.resolve()
    work.mkdir(parents=True, exist_ok=False)
    roots = {'control': a.control.resolve(), 'build': a.build.resolve()}
    metadata = {}
    members = {}
    studies = {}
    for label, path in roots.items():
        metadata[label] = json.loads((path / 'build.json').read_text())
        members[label] = {}
        source = work / (label + '_source')
        source.mkdir()
        for machine, spec in metadata[label]['sets'].items():
            files = {n: (path / machine / n).read_bytes() for n in spec['files']}
            if any((EP.sha(data) != spec['files'][n] for n, data in files.items())):
                raise ValueError('input member changed')
            members[label][machine] = files
            spec['stage_select_syms'] = stage_symbols(files, machine)
            (source / machine).symlink_to(path / machine, target_is_directory=True)
        (source / 'build.json').write_text(json.dumps(metadata[label], indent=2) + '\n')
        studies[label] = work / (label + '_study')
        J.cmd_study(SimpleNamespace(build=source, rom_dir=a.rom_dir, out=studies[label], start_stage=None, stage_select_tour=False, stage_select_pick=6))
    for machine, files in members['control'].items():
        image = RF.compose(files, RF.SETS[machine])
        EP.patch_image(image, machine)
        changed = RF.decompose(image, RF.SETS[machine], {n: len(files[n]) for n, _, _ in RF.SETS[machine]})
        if {**files, **changed} != members['build'][machine]:
            raise ValueError('candidate differs outside exact Earth repair')
    runtime = json.loads((a.runtime / 'runtime.json').read_text())
    if EP.sha(Path(runtime['binary']).read_bytes()) != runtime['binary_sha256']:
        raise ValueError('runtime changed')
    names = {'striderus01': 'striderua', 'striderjs01': 'striderjr'}
    jobs = [(label, name, flag) for label in roots for name in names for flag in (0, 1)]

    def one(key):
        label, name, flag = key
        out = work / (label + '_' + name + '_' + str(flag))
        log = work / (out.name + '.log')
        cmd = [sys.executable, str(ROOT / 'backports/striderex/rtl/jtcps1_sim.py'), 'hbref', '--build', str(studies[label]), '--runtime', str(a.runtime), '--hbmame', str(a.hbmame), '--rom-dir', str(a.rom_dir), '--out', str(out), '--set', name, '--flag', str(flag), '--frames', '1500', '--shots', '1140-1470/30', '--memdump', '1300']
        with log.open('w') as f:
            r = subprocess.run(cmd, stdout=f, stderr=subprocess.STDOUT)
        if r.returncode:
            raise ValueError('capture failed: ' + out.name)
        print('captured', out.name, flush=True)
        return (key, out)
    with ThreadPoolExecutor(a.jobs) as pool:
        runs = dict(pool.map(one, jobs))
    from PIL import Image
    results = []
    for name, machine in names.items():
        for flag in (0, 1):
            old, new = [runs[label, name, flag] for label in roots]
            shots = []
            for f in range(1140, 1471, 30):
                file = f'f_{f:05d}.png'
                same = Image.open(old / file).convert('RGB').tobytes() == Image.open(new / file).convert('RGB').tobytes()
                shots.append(dict(frame=f, identical=same))
            before = (old / 'vram_01300.bin').read_bytes()
            after = (new / 'vram_01300.bin').read_bytes()
            positions = (84352, 84480)
            pens = all((before[p:p + 2] == bytes.fromhex('f111') and after[p:p + 2] == bytes.fromhex('f000') for p in positions))
            allowed = {p + i for p in positions for i in (0, 1)}
            diff = {i for i, (b, c) in enumerate(zip(before, after)) if b != c}
            checks = dict(pictures_identical=all((s['identical'] for s in shots)), frame_flow_identical=(old / 'frames.tsv').read_bytes() == (new / 'frames.tsv').read_bytes(), registers_and_sound_identical=(old / 'regs.tsv').read_bytes() == (new / 'regs.tsv').read_bytes(), both_background_pens_corrected=pens, only_these_vram_words_differ=diff == allowed)
            results.append(dict(set=name, flag=flag, checks=checks, pictures=shots, passed=all(checks.values()), control_capture_vram_sha256=EP.sha(before), capture_vram_sha256=EP.sha(after)))
    if EP.sha(Path(runtime['binary']).read_bytes()) != runtime['binary_sha256']:
        raise ValueError('runtime changed during gate')
    report = dict(schema='striderex-earth-runtime/1', passed=all((r['passed'] for r in results)), control_files={m: s['files'] for m, s in metadata['control']['sets'].items()}, build_files={m: s['files'] for m, s in metadata['build']['sets'].items()}, runtime={k: runtime[k] for k in ('binary_sha256', 'board_wait', 'source_revision')}, results=results)
    (work / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
    for r in results:
        print('PASS' if r['passed'] else 'FAIL', r['set'], r['flag'], r['checks'])
    return 0 if report['passed'] else 1

def main():
    if sys.argv[1:] == ['--self-test']:
        return EP.self_test()
    p = argparse.ArgumentParser(description=__doc__)
    for name in ('build', 'control', 'rom-dir', 'runtime', 'hbmame', 'workdir'):
        p.add_argument('--' + name, type=Path, required=True)
    p.add_argument('--jobs', type=int, default=3)
    a = p.parse_args()
    a.rom_dir = a.rom_dir.resolve()
    a.runtime = a.runtime.resolve()
    return gate(a)
if __name__ == '__main__':
    sys.exit(main())
