"""Japanese transcripts, a Google witness and the on-screen fit of the eight PC Engine boss"""
import argparse
import datetime
import hashlib
import json
import subprocess
import sys
from pathlib import Path
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
ROOT = HERE.parents[2]
M = ROOT / 'backports/striderex/manifests'
MEASURED = M / 'portraits_measured.json'
TRANSCRIPTS = M / 'portrait_transcripts.json'
WITNESS = M / 'portrait_google_witness.json'
REVIEW = M / 'portrait_text_review.json'
DIALOGUE_GLYPHS_REF = '992e3f113:backports/striderex/assets/dialogue_font/ja_glyphs.txt'
LOW_WORD_PROB = 0.6
PRIME = 'ストライダー、飛竜、ソロ、グランドマスター、サイファー、三姉妹、三位一体。'
ROWS_PER_PAGE = 2
FIT = {'en': dict(x=40, advance=8, target=37, limit=43), 'ja': dict(x=32, advance=16, target=19, limit=22)}

def measured():
    return {p['id']: p for p in json.loads(MEASURED.read_text())['portraits']}

def clip_of(capture, pid, want):
    """(playback index, playback, pcm, rate) of the portrait's voice clip in a portrait_pce.py capture: the playback"""
    import portrait_pce as PP
    run = Path(capture) / pid
    ram, plays, _ = PP.adpcm_events(run)
    for k, pl in enumerate(plays):
        data, pcm, _ = PP.clip(ram, pl)
        if hashlib.sha256(data).hexdigest() == want:
            return (k, pl, pcm, PP.ADPCM_RATE // (16 - pl['rate']))
    raise SystemExit(f'portrait_transcripts: {pid}: no playback in {run} matches adpcm_sha256 {want[:12]}')

def decode(a):
    import portrait_pce as PP
    a.out.mkdir(parents=True, exist_ok=True)
    rows = []
    for pid, p in measured().items():
        want = p['voice'][0]['adpcm_sha256']
        k, pl, pcm, rate = clip_of(a.capture, pid, want)
        wav = a.out / f'{pid}.wav'
        PP.write_wav(wav, pcm, rate)
        rows.append(dict(id=pid, playback=k, rate_hz=rate, seconds=round(len(pcm) / rate, 2), adpcm_sha256=want, wav_sha256=hashlib.sha256(wav.read_bytes()).hexdigest()))
        print(f'{pid}: playback {k}, {rate} Hz, {len(pcm) / rate:.2f} s -> {wav}')
    (a.out / 'clips.json').write_text(json.dumps(dict(clips=rows), indent=1) + '\n')
    return 0
VARIANTS = {'primary': dict(model='large-v3', input='clip', kw=dict(beam_size=5, temperature=0.0, vad_filter=True)), 'wide': dict(model='large-v3', input='clip', kw=dict(beam_size=10, patience=2.0, temperature=0.0, vad_filter=False)), 'clean': dict(model='large-v3', input='clean', kw=dict(beam_size=5, temperature=0.0, vad_filter=False)), 'primed': dict(model='large-v3', input='clip', kw=dict(beam_size=5, temperature=0.0, vad_filter=False, initial_prompt=PRIME)), 'small': dict(model='small', input='clip', kw=dict(beam_size=5, temperature=0.0, vad_filter=False))}

def clean_copy(wav, out):
    subprocess.run(['ffmpeg', '-loglevel', 'error', '-y', '-i', str(wav), '-af', 'highpass=f=120,lowpass=f=3600,loudnorm=I=-18:TP=-2', '-ar', '16000', '-ac', '1', str(out)], check=True)
    return out

def transcribe(a):
    import faster_whisper
    from faster_whisper import WhisperModel
    ids = list(measured())
    clips = {i: a.clips / f'{i}.wav' for i in ids}
    for i, w in clips.items():
        if not w.exists():
            raise SystemExit(f'portrait_transcripts: {w} missing (run decode)')
    work = a.clips / 'asr_work'
    work.mkdir(exist_ok=True)
    out = {i: dict(id=i, wav_sha256=hashlib.sha256(clips[i].read_bytes()).hexdigest(), variants={}) for i in ids}
    models = {}
    for name, v in VARIANTS.items():
        if v['model'] not in models:
            models[v['model']] = WhisperModel(v['model'], device='cpu', compute_type='int8')
        model = models[v['model']]
        for i in ids:
            src = clips[i] if v['input'] == 'clip' else clean_copy(clips[i], work / f'{i}_clean.wav')
            segs, _ = model.transcribe(str(src), language='ja', word_timestamps=True, condition_on_previous_text=False, **v['kw'])
            segments = []
            for s in segs:
                words = [dict(w=x.word, start=round(x.start, 2), end=round(x.end, 2), p=round(x.probability, 3)) for x in s.words or []]
                seg = dict(start=round(s.start, 2), end=round(s.end, 2), text=s.text.strip(), avg_logprob=round(s.avg_logprob, 3), no_speech_prob=round(s.no_speech_prob, 3), uncertain=[w['w'] for w in words if w['p'] < LOW_WORD_PROB])
                if name == 'primary':
                    seg['words'] = words
                segments.append(seg)
            out[i]['variants'][name] = dict(text=''.join((s['text'] for s in segments)), segments=segments)
            print(f"{name:8s} {i:17s} {out[i]['variants'][name]['text']}")
    snaps = {}
    for mdl in {v['model'] for v in VARIANTS.values()}:
        d = sorted((Path.home() / f'.cache/huggingface/hub/models--Systran--faster-whisper-{mdl}/snapshots').glob('*'))
        snaps[f'Systran/faster-whisper-{mdl}'] = d[-1].name if d else None
    TRANSCRIPTS.write_text(json.dumps(dict(status='ASR draft: Japanese source for review; not verified, not approved', source="scripts/portrait_transcripts.py decode (clips from a portrait_pce.py capture; each clip's ADPCM bytes equal manifests/portraits_measured.json adpcm_sha256), then transcribe", asr=dict(engine='faster-whisper', version=faster_whisper.__version__, models=snaps, compute_type='int8', language='ja', word_timestamps=True, condition_on_previous_text=False, low_word_probability=LOW_WORD_PROB, variants={k: dict(model=v['model'], input=v['input'], **v['kw']) for k, v in VARIANTS.items()}, clean_filter='ffmpeg highpass=f=120,lowpass=f=3600,loudnorm=I=-18:TP=-2, 16 kHz mono'), time_base='seconds from the clip start (the portrait voice playback)', lines=[out[i] for i in ids]), ensure_ascii=False, indent=1) + '\n')
    return 0

def witness(a):
    sys.path.insert(0, str(ROOT / 'translations/vhunt2/scripts'))
    import psx_google_witness as G
    asr = {r['id']: r['variants']['primary']['text'] for r in json.loads(TRANSCRIPTS.read_text())['lines']}
    review = json.loads(REVIEW.read_text())
    texts = []
    for ln in review['lines']:
        texts.append((ln['id'], 'asr', asr[ln['id']]))
        texts.append((ln['id'], 'reading', ln['ja_reading']))
    project, token = G.service_account_token(a.credentials)
    english = G.translate(project, token, [t[2] for t in texts])
    rows = [dict(id=i, input=kind, ja=ja, en=en) for (i, kind, ja), en in zip(texts, english)]
    WITNESS.write_text(json.dumps(dict(status='Google Cloud Translation v3 witness: independent literal reading, never release prose', provider='Google Cloud Translation v3 translateText (ja -> en, text/plain)', retrieved=datetime.date.today().isoformat(), inputs='per line: the primary ASR text (portrait_transcripts.json) and the proposed reading (portrait_text_review.json ja_reading)', transcripts_sha256=hashlib.sha256(TRANSCRIPTS.read_bytes()).hexdigest(), readings_sha256=hashlib.sha256('\n'.join((ln['ja_reading'] for ln in review['lines'])).encode()).hexdigest(), rows=rows), ensure_ascii=False, indent=1) + '\n')
    for r in rows:
        print(f"{r['id']:17s} {r['input']:7s} {r['en']}")
    return 0

def glyph_sources(dialogue_glyphs=None):
    """(stock {char: code}, equivalents, approved caption glyph chars, branch dialogue glyph chars)."""
    import subtitle_ex as SX
    caption, _ = SX.read_grids(SX.JA_GRIDS)
    if dialogue_glyphs is None:
        try:
            txt = subprocess.run(['git', '-C', str(ROOT), 'show', DIALOGUE_GLYPHS_REF], check=True, capture_output=True, text=True).stdout
            dialogue_glyphs = {ln.split()[1] for ln in txt.splitlines() if ln.startswith('U+')}
        except subprocess.CalledProcessError:
            dialogue_glyphs = set()
    return (SX.JA_ARCADE, SX.JA_EQUIV, set(caption), set(dialogue_glyphs), SX.en_charset())

def glyph_of(ch, src):
    stock, equiv, caption, dialogue, _ = src
    c = equiv.get(ch, ch)
    if c in stock:
        return 'stock'
    if ch in caption:
        return 'caption'
    if ch in dialogue:
        return 'dialogue_branch'
    return 'new'

def row_fit(text, region):
    f = FIT[region]
    n = len(text)
    end = f['x'] + n * f['advance']
    return dict(text=text, cells=n, end_x=end, verdict='fits' if n <= f['target'] else 'tight' if n <= f['limit'] and end <= 384 else 'too long')

def page_fit(pages, region, src):
    rows, bad = ([], [])
    for pg in pages:
        if len(pg) > ROWS_PER_PAGE:
            bad.append(f'a page of {len(pg)} rows')
        for r in pg:
            rows.append(row_fit(r, region))
            if region == 'en':
                bad += [f'"{c}" has no English glyph (arcade 8x8 font, drawn marks, lower case)' for c in r if c not in src[4]]
    worst = max((r['cells'] for r in rows), default=0)
    verdict = 'fits' if all((r['verdict'] == 'fits' for r in rows)) else 'too long' if any((r['verdict'] == 'too long' for r in rows)) else 'tight'
    return dict(pages=len(pages), longest=worst, verdict=verdict if not bad else 'invalid', problems=sorted(set(bad)), rows=rows)

def fit(a):
    src = glyph_sources()
    review = json.loads(REVIEW.read_text())
    need = {}
    for ln in review['lines']:
        ln['fit'] = dict(en=page_fit(ln['en_pages'], 'en', src), ja=page_fit(ln['ja_pages'], 'ja', src))
        chars = sorted({c for pg in ln['ja_pages'] for r in pg for c in r})
        ln['fit']['ja_glyphs'] = {k: ''.join((c for c in chars if glyph_of(c, src) == k)) for k in ('caption', 'dialogue_branch', 'new')}
        for c in chars:
            need.setdefault(c, []).append(ln['id'])
        print(f"{ln['id']:17s} EN {ln['fit']['en']['pages']}p longest {ln['fit']['en']['longest']:2d} {ln['fit']['en']['verdict']:8s} JA {ln['fit']['ja']['pages']}p longest {ln['fit']['ja']['longest']:2d} {ln['fit']['ja']['verdict']:8s} new {ln['fit']['ja_glyphs']['new']}")
    groups = {k: [c for c in sorted(need) if glyph_of(c, src) == k] for k in ('caption', 'dialogue_branch', 'new')}
    review['glyphs'] = dict(note=f'Every Japanese character of the proposed on-screen pages that the stock 16x16 dialogue font (subtitle_ex.JA_ROWS, SCROLL2 0x3620+) lacks. caption: in the approved caption glyph set (assets/subtitle_font/ja_glyphs.txt, approved 2026-10-10). dialogue_branch: drawn for the superseded desert text pages ({DIALOGUE_GLYPHS_REF}, not merged, pending review). new: no EX glyph yet.', caption=''.join(groups['caption']), dialogue_branch=''.join(groups['dialogue_branch']), new=''.join(groups['new']), new_count=len(groups['new']), used_by={c: need[c] for c in groups['new'] + groups['dialogue_branch'] + groups['caption']})
    review['fit_rules'] = dict(rows_per_page=ROWS_PER_PAGE, **{k: dict(v) for k, v in FIT.items()}, note="Siberia's stock page form, two rows. target: the row ends by x 336; limit: the desert dialogue build's refusal (44/22 characters or past x 384). A longer line takes a second page.")
    REVIEW.write_text(json.dumps(review, ensure_ascii=False, indent=1) + '\n')
    print('new glyphs:', review['glyphs']['new'], '| branch:', review['glyphs']['dialogue_branch'], '| caption:', review['glyphs']['caption'])
    return 0

def self_test():
    src = glyph_sources(dialogue_glyphs={'墓', '僧'})
    assert glyph_of('ス', src) == 'stock' and glyph_of('！', src) == 'stock' and (glyph_of('余', src) == 'stock')
    assert glyph_of('砂', src) == 'caption', 'the approved caption set has 砂'
    assert glyph_of('墓', src) == 'dialogue_branch'
    assert glyph_of('鬱', src) == 'new'
    f = page_fit([['YOU REALLY THINK YOU CAN WIN?', 'YOU WILL NEVER DEFEAT THE LORD!']], 'en', src)
    assert f['verdict'] == 'fits' and f['longest'] == 31, f
    assert row_fit('NO ONE CROSSES THESE SANDS AND LIVES.', 'en')['end_x'] == 40 + 37 * 8
    assert row_fit('X' * 40, 'en')['verdict'] == 'tight' and row_fit('X' * 44, 'en')['verdict'] == 'too long'
    assert page_fit([['It\'s me: "Hiryu"']], 'en', src)['verdict'] == 'fits', 'mixed case with the drawn marks'
    assert page_fit([['A@B']], 'en', src)['verdict'] == 'invalid', 'no @ in the English glyphs'
    assert page_fit([['A', 'B', 'C']], 'en', src)['verdict'] == 'invalid'
    assert row_fit('あ' * 19, 'ja')['end_x'] == 336 and row_fit('あ' * 20, 'ja')['verdict'] == 'tight'
    if REVIEW.exists():
        real = glyph_sources()
        review = json.loads(REVIEW.read_text())
        ids = [ln['id'] for ln in review['lines']]
        assert ids == list(measured()), ids
        for ln in review['lines']:
            assert ln.get('fit') == dict(en=page_fit(ln['en_pages'], 'en', real), ja=page_fit(ln['ja_pages'], 'ja', real), ja_glyphs=ln['fit']['ja_glyphs']), f"{ln['id']}: stale fit (run fit)"
            assert ln['fit']['en']['verdict'] != 'invalid', ln['id']
    print('portrait_transcripts self-test passed')
    return 0

def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('--self-test', action='store_true')
    sub = p.add_subparsers(dest='cmd')
    d = sub.add_parser('decode')
    d.add_argument('capture', type=Path, help='a portrait_pce.py capture directory (<id>/ram_writes.txt)')
    d.add_argument('--out', type=Path, required=True, help='clip directory (outside the repository)')
    t = sub.add_parser('transcribe')
    t.add_argument('clips', type=Path, help='a decode --out directory')
    w = sub.add_parser('witness')
    w.add_argument('--credentials', type=Path, required=True, help='Google service-account JSON outside the repo')
    sub.add_parser('fit')
    a = p.parse_args()
    if a.self_test:
        return self_test()
    if a.cmd == 'decode':
        return decode(a)
    if a.cmd == 'transcribe':
        return transcribe(a)
    if a.cmd == 'witness':
        return witness(a)
    if a.cmd == 'fit':
        return fit(a)
    p.print_help()
    return 2
if __name__ == '__main__':
    sys.exit(main())
