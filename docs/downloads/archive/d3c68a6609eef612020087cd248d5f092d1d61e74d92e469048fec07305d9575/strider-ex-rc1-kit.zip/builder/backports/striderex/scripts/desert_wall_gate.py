"""Exercise every short-pan residue and native wall climbing after the map load."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import json
from pathlib import Path
import numpy as np
from PIL import Image
import boss_voice_gate as V
import desert_gate as G
import desert_wall_edge as W

def schedule(deficit):
    return dict(MOTION='1', WARP='600:6735,1100;650:6740,1100', POKEW=f'600:ff0ff4={6672 - deficit:x};600:ff0ff6=0;600:ff0ff8=3c0;600:ff0ffa=0;600:fff932=2;600:fff934=5', STREX_INPUTS='650-1000:P1_JOYSTICK_LEFT;750-1000:P1_JOYSTICK_UP;1001-1250:P1_JOYSTICK_DOWN', SHOTS='1150-1150@1', VIDEO_DUMPS='1150' if deficit == 8 else '')

def gate(a):
    work = a.workdir.resolve()
    work.mkdir(parents=True, exist_ok=a.reuse)
    metas = {}
    files = {}
    sets = {}
    rt = json.loads((a.runtime / 'runtime.json').read_text())
    binary = Path(rt['binary'])
    if V.sha(binary.read_bytes()) != rt['binary_sha256']:
        raise ValueError('runtime changed')
    for label, path in (('control', a.control), ('candidate', a.build)):
        metas[label], files[label] = V.inventory(path)
        for machine in files[label]:
            name = 'striderus01' if machine == 'striderua' else 'striderjs01'
            sets[label, machine] = (G.stage_sets(path.resolve(), name, a.hbmame, a.rom_dir.resolve(), work / 'sets' / (label + machine)), name)
            staged = sets[label, machine][0] / name
            hashes = {V.sha(p.read_bytes()) for p in staged.iterdir() if p.is_file()}
            if not set(metas[label]['sets'][machine]['files'].values()) <= hashes:
                raise ValueError('staged set does not contain every exact input member')
    for machine, old in files['control'].items():
        expected = dict(old)
        expected['strex_p6.bin'] = W.patch(old['strex_p6.bin'])[0]
        if expected != files['candidate'][machine]:
            raise ValueError('unrelated candidate bytes changed')
    cases = [('striderua', d) for d in range(1, 13)] + [('striderjr', 8)]
    jobs = [(label, m, d) for m, d in cases for label in ('control', 'candidate')]

    def run(job):
        label, m, d = job
        out = work / f'{label}_{m}_{d}'
        roms, name = sets[label, m]
        if not a.reuse or not (out / 'motion.tsv').exists():
            env = dict(G.debug_env(5, 3, 1250, inputs=False), **schedule(d))
            G.run(binary, roms, name, out, env, 1250)
        rows = G.read_motion(out)
        stable = [r for r in rows if 750 <= int(r['frame']) <= 1200]
        camera = {int(r['camx']) for r in stable}
        if len(camera) != 1:
            raise ValueError('camera did not hold after the transition')
        cam = camera.pop()
        if label == 'control' and cam != 6672 - d or (label == 'candidate' and (not 6672 <= cam <= 6681)):
            raise ValueError('short-pan result differs')
        section = G.read_desert(out)[-1]
        if (section['sec'], section['map'], section['limits']) != (3, 2, '6672,7680,784,1808'):
            raise ValueError('normal map, area or following bounds not restored')
        climb = [r for r in stable if int(r['st']) == 4]
        if len(climb) < 440 or any((int(r['hx']) != 6735 for r in climb)):
            raise ValueError('native wall contact failed')
        asc = [r for r in rows if 850 <= int(r['frame']) <= 950]
        desc = [r for r in rows if 1050 <= int(r['frame']) <= 1150]
        if int(asc[-1]['hy']) - int(asc[0]['hy']) != 100 or int(desc[0]['hy']) - int(desc[-1]['hy']) != 100:
            raise ValueError('native up/down climb did not traverse the wall')
        im = np.array(Image.open(out / 's_01150.png').convert('RGB'))
        sky = np.all(im[50:150, :12] == [102, 102, 255], axis=2)
        if label == 'control' and (not np.all(sky[:, :d])) or (label == 'candidate' and sky.any()):
            raise ValueError('rendered left-edge strip differs')
        result = dict(label=label, machine=m, initial_deficit=d, camera_x=cam, left_gap_pixels=max(6672 - cam, 0), native_climb_frames=len(climb), up_pixels=100, down_pixels=100, following_bounds_restored=True, motion_sha256=V.sha((out / 'motion.tsv').read_bytes()), passed=True)
        print(label, m, d, 'camera', cam, 'gap', result['left_gap_pixels'], flush=True)
        return result
    with ThreadPoolExecutor(2) as ex:
        results = list(ex.map(run, jobs))
    for m, d in cases:
        old = G.read_motion(work / f'control_{m}_{d}')
        new = G.read_motion(work / f'candidate_{m}_{d}')
        keys = ('hx', 'hy', 'st', 'sub', 'kind', 'speed', 'face')
        if any((any((x[k] != y[k] for k in keys)) for x, y in zip(old[749:1200], new[749:1200]))):
            raise ValueError('transition correction changes the native climb')
    report = dict(schema='striderex-wall-edge-gate/1', passed=True, all_twelve_pan_residues_checked=True, exact_one_data_word_per_region=True, native_climb_integer_motion_unchanged=True, results=results, input_files={k: {m: s['files'] for m, s in meta['sets'].items()} for k, meta in metas.items()}, runtime_sha256=rt['binary_sha256'], hardware_review_granted=False)
    a.receipt.write_text(json.dumps(report, indent=2) + '\n')
    print('PASS: all twelve short-pan cases fill the left edge; both regions climb up/down identically')
if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    for name in ('control', 'build', 'rom-dir', 'runtime', 'hbmame', 'workdir', 'receipt'):
        p.add_argument('--' + name, type=Path, required=True)
    p.add_argument('--reuse', action='store_true')
    gate(p.parse_args())
