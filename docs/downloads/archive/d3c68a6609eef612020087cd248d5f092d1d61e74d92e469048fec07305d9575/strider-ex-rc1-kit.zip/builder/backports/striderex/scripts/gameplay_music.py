"""Complete the accepted EX gameplay mapping without changing existing audio."""
import argparse
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import sys
import wave
import numpy as np
from scipy import signal
import boss_voice_overlay as VO
ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT))
from cpsplus.pack import adxcodec as AD
from cpsplus.pack.format import PackReader, TrackMeta, TriggerRow, VERB_PLAY, VERB_NONE, VERB_STOP
RECIPE = Path(__file__).resolve().parents[1] / 'manifests/desert_music_loops.json'

def sha(b):
    return hashlib.sha256(b).hexdigest()

def pcm(row, raw):
    if sha(raw) != row['source_sha256']:
        raise ValueError('disc track identity changed')
    x = np.frombuffer(raw, '<i2').reshape(-1, 2)[row['trim_source_frames']:].astype(float) / 32768
    x = signal.resample_poly(x, 160, 147, axis=0, window=('kaiser', 8.6))
    a, b, n = (row[k] for k in ('loop_start', 'loop_end', 'crossfade_frames'))
    if not (0 < n < a < b < len(x) and a % 32 == b % 32 == n % 32 == 0):
        raise ValueError('invalid aligned loop')
    y = x[:b].copy()
    weight = np.linspace(0, 1, n)[:, None]
    y[b - n:b] = x[b - n:b] * (1 - weight) + x[a - n:a] * weight
    data = np.rint(y * 32768).clip(-32768, 32767).astype('<i2').tobytes()
    if sha(data) != row['pcm_sha256']:
        raise ValueError('rebuilt PCM identity changed')
    return data

def coverage(rd):
    man = json.loads((Path(__file__).resolve().parents[1] / 'manifests/audio_cue_overlay.json').read_text())
    expected = {int(k, 16): v['pce_pack'] for k, v in man['rows'].items() if v['pce_pack'] != 'native' and int(k, 16) not in (14, 15, 21, 33)}
    expected.update({121: '10 Sandy Battlefield', 122: '11 Desert Flames'})
    rows = []
    for cue, title in sorted(expected.items()):
        r = rd.triggers[cue]
        t = rd.tracks[r.track] if r.verb == VERB_PLAY else None
        ok = bool(t and r.suppress == 1 and (t.loop_end_byte > t.loop_start_byte) and (cue < rd.header.proto.control_region_start))
        rows.append(dict(cue=hex(cue), expected=title, track=r.track if t else None, suppress=r.suppress, looping=bool(t and t.loop_end_byte), passed=ok))
    return rows

def produce(a):
    recipe = json.loads(a.recipe.read_text())
    rd = PackReader(a.pack)
    if not all(rd.crc_check()):
        raise ValueError('source pack CRC mismatch')
    if sha(a.pack.read_bytes()) != recipe['source_pack_sha256']:
        raise ValueError('need exact Kit y English pack')
    a.out.mkdir(parents=True, exist_ok=False)
    w = VO.copy_writer(rd)
    replay = a.out / 'replay.cpk'
    w.write(replay, sidecar=False)
    if replay.read_bytes() != a.pack.read_bytes():
        raise ValueError('source pack cannot reconstruct exactly')
    replay.unlink()
    rows = []
    for row in recipe['tracks']:
        hits = list(a.disc_dir.glob(f"*Track {row['disc_track']:02}*.bin"))
        if len(hits) != 1:
            raise ValueError('need one canonical split-bin disc track')
        raw = pcm(row, hits[0].read_bytes())
        stream = AD.encode(raw, 2, 48000)
        c1, c2 = AD.calc_coeffs(AD.DEFAULT_CUTOFF, 48000)
        lo, hi = (row['loop_start'], row['loop_end'])
        meta = TrackMeta(sample_rate=48000, channels=2, gain=127, coef1=c1, coef2=c2, loop_start_sample=lo, loop_end_sample=hi, loop_start_byte=AD.samples_to_stream_byte(lo, 2), loop_end_byte=AD.samples_to_stream_byte(hi, 2), xfade_enable=False, name=row['title'], source='Strider Hiryuu (Japan) CD-DA')
        cue = int(row['cue'], 16)
        if rd.triggers[cue].verb != VERB_NONE:
            raise ValueError('desert cue already occupied')
        index = w.add_track(stream, meta)
        w.set_trigger(cue, TriggerRow(verb=VERB_PLAY, track=index, gain=127, suppress=1))
        rows.append(dict(cue=hex(cue), track=index, pcm_sha256=sha(raw), adx_sha256=sha(stream), loop_samples=[lo, hi]))
        x = np.frombuffer(raw, '<i2').reshape(-1, 2)
        aud = np.concatenate((x[hi - 96000:hi], x[lo:hi], x[lo:lo + 96000]))
        with wave.open(str(a.out / f"desert-{row['disc_track']}-loop.wav"), 'wb') as f:
            f.setnchannels(2)
            f.setsampwidth(2)
            f.setframerate(48000)
            f.writeframes(aud.astype('<i2').tobytes())
    if rd.triggers[3].verb != VERB_STOP or rd.triggers[1].verb != VERB_PLAY:
        raise ValueError('St. Petersburg source rows changed')
    w.set_trigger(3, deepcopy(rd.triggers[1]))
    path = a.out / 'strider_ex.cpk'
    w.write(path)
    new = PackReader(path)
    if not all(new.crc_check()):
        raise ValueError('output pack CRC mismatch')
    for i, t in enumerate(rd.tracks):
        if new.read_track(i) != rd.read_track(i) or t.pack() != new.tracks[i].pack():
            raise ValueError('existing track changed')
    changed = [i for i, (x, y) in enumerate(zip(rd.triggers, new.triggers)) if x.pack() != y.pack()]
    if changed != [3, 121, 122]:
        raise ValueError('unexpected trigger changes')
    checks = coverage(new)
    if not all((r['passed'] for r in checks)):
        raise ValueError('gameplay mapping remains incomplete')
    report = dict(schema='striderex-gameplay-music/1', passed=True, source_pack_sha256=sha(a.pack.read_bytes()), pack_sha256=sha(path.read_bytes()), recipe_sha256=sha(a.recipe.read_bytes()), original_tracks_preserved=len(rd.tracks), changed_cues=list(map(hex, changed)), tracks=rows, gameplay_coverage=checks, encoder=AD.ffmpeg_version(), hardware_review_granted=False)
    (a.out / 'music.json').write_text(json.dumps(report, indent=2) + '\n')
    print('PASS: all', len(checks), 'gameplay/intro cues have suppressed arranged loops; only 03/79/7A changed')

def self_test():
    from tempfile import TemporaryDirectory
    from cpsplus.pack.format import PackWriter, Protocol, CODEC_PCM, DIALECT_CPS1_BYTE
    with TemporaryDirectory(dir=Path(__file__).resolve().parents[1] / 'work') as t:
        p = Path(t) / 'fixture.cpk'
        w = PackWriter(Protocol(game_id='strider', dialect=DIALECT_CPS1_BYTE, control_region_start=240), trigger_rows=256)
        w.add_track(bytes(512), TrackMeta(codec=CODEC_PCM, sample_rate=48000, channels=2, loop_start_sample=32, loop_end_sample=128, loop_start_byte=128, loop_end_byte=512))
        for cue in range(240):
            w.set_trigger(cue, TriggerRow(verb=VERB_PLAY, track=0, suppress=1))
        w.write(p, sidecar=False)
        assert all((r['passed'] for r in coverage(PackReader(p))))
        w.set_trigger(121, TriggerRow())
        w.write(p, sidecar=False)
        bad = [r['cue'] for r in coverage(PackReader(p)) if not r['passed']]
        assert bad == ['0x79']
        w.set_trigger(121, TriggerRow(verb=VERB_PLAY, track=0, suppress=0))
        w.write(p, sidecar=False)
        assert not all((r['passed'] for r in coverage(PackReader(p))))
    print('PASS: missing rows and native music leakage rejected')

def main():
    if sys.argv[1:] == ['--self-test']:
        return self_test()
    p = argparse.ArgumentParser(description=__doc__)
    for n in ('pack', 'disc-dir', 'out'):
        p.add_argument('--' + n, type=Path, required=True)
    p.add_argument('--recipe', type=Path, default=RECIPE)
    produce(p.parse_args())
if __name__ == '__main__':
    main()
