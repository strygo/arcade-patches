-- Strider EX boss scene gate probe (scripts/boss_scene_gate.py; asm/boss_scene.s). The arcade debug start
-- (lua/arcade_debug_start.lua, loaded unchanged: DIPs, coin, START, STREX_INPUTS) plus:
--   <out>_frames.tsv  every frame: frame, BS_ON, BS_N, ACTIVE, player X, Y, camera X, Y, the music byte
--                     0xFF10C5, the game's frame counter 0xFF0C22, ramsum (lua/portrait_gate.lua's work RAM
--                     checksum, also without the scene's variables 0xFFF9C0-0xFFF9FF, its stack
--                     0xFFD700-0xFFD7FF and the stock sound queue), writes to the scene's graphics RAM
--                     0x91C000-0x91FFFF in that frame, the life count 0xFF0CA8;
--   <out>_regs.tsv    also 'seen' rows: the base variant's encounter mark (BS_SEEN, 0xFFF9EA);
--   <out>_regs.tsv    every write of the palette base (0x80010A), the OBJ base (0x800100), the layer word
--                     (0x800166) and the sound latch (0x800180): frame, register, value, and while a scene
--                     is up BS_N, BS_PREP, BS_PL, BS_T, BS_PIC, ACTIVE; a palette base write during a scene
--                     adds the checksum of the 0x1800 bytes it copies and the page's two OBJ slots (12, 24);
--                     an OBJ base write of a scene list adds its entries up to the end mark;
--   <out>_sync.tsv    each game write of its OBJ base shadow (0xFF0C9A): k, frame, ramsum (portrait_gate.lua);
--   <out>_entry.bin, <out>_exit.bin   work RAM 0xFF0000-0xFFFFFF then graphics RAM 0x900000-0x92FFFF when the
--                     scene starts (BS_ON written with 0xB055) and ends (BS_ON cleared);
--   screenshots on STREX_GATE_SHOTS frames ("a-b,c,...").
-- STREX_HOLDS "first,last,addr,value;...": research writes on every frame first..last (a byte at an odd
-- address, else a word), the same in every variant.
-- STREX_VIDEO_DUMPS "frame,...", STREX_GATE_VIDEO_DIR: optional full VRAM and
-- all video-register writes for the matching frozen-core render probe.
local m=manager.machine
local sp=m.devices[':maincpu'].spaces['program']
local screen=m.screens[':screen']
local out_prefix=assert(os.getenv('STREX_GATE_OUT'))
dofile(assert(os.getenv('STREX_DEBUG_START')))
local shots={}
for a,b in string.gmatch(os.getenv('STREX_GATE_SHOTS') or '','(%d+)%-?(%d*)') do
 local lo=tonumber(a);local hi=tonumber(b) or lo
 for k=lo,hi do shots[k]=true end
end
local holds={}
for lo,hi,a,v in string.gmatch(os.getenv('STREX_HOLDS') or '','(%d+),(%d+),(%x+),(%x+)') do
 holds[#holds+1]={tonumber(lo),tonumber(hi),tonumber(a,16),tonumber(v,16)}
end
-- STREX_SHIFT "E,N" (an ex run): after frame E the debug start's own button schedule (lua/arcade_debug_start.lua:
-- COIN1 200-360, SERVICE1 380-440, START1 400-410 and, without invincibility, the test switch 380-440, by absolute
-- frame) is applied N frames later, as the gate's
-- inputs are, so a scene that starts before frame 440 meets the same buttons afterwards as base does.
local shift_e,shift_n=string.match(os.getenv('STREX_SHIFT') or '','(%d+),(%d+)')
shift_e,shift_n=tonumber(shift_e),tonumber(shift_n)
local btn={}
for _,port in pairs(m.ioport.ports) do for _,field in pairs(port.fields) do
 btn[m.ioport:input_type_to_token(field.type,field.player)]=field
end end
local function hold(tok,on) if on then btn[tok]:set_value(1) else btn[tok]:clear_value() end end
local invincible=os.getenv('STREX_INVINCIBLE')=='1'
local test_sw
for _,field in pairs(m.ioport.ports[':IN0'].fields) do if field.mask==0x40 then test_sw=field end end
local BS=0xfff9c0
local MAGIC=0xb055
local f=0
local video_frames={}
for n in string.gmatch(os.getenv('STREX_VIDEO_DUMPS') or '','%d+') do video_frames[tonumber(n)]=true end
local video_dir=os.getenv('STREX_GATE_VIDEO_DIR')
local video_log
if next(video_frames) then
 assert(video_dir,'video output directory missing')
 video_log=assert(io.open(video_dir..'/regs.tsv','w'))
end
local frames=assert(io.open(out_prefix..'_frames.tsv','w'))
local regs=assert(io.open(out_prefix..'_regs.tsv','w'))
local sync=assert(io.open(out_prefix..'_sync.tsv','w'))
local oki
if os.getenv('STREX_GATE_AUDIO')=='1' then
 oki=assert(io.open(out_prefix..'_oki.tsv','w'))
 local z=m.devices[':audiocpu'].spaces['program']
 _G.strex_bs_oki=z:install_write_tap(0xf002,0xf002,'bs_oki',function(a,d,mask)
  oki:write(string.format('%d\t%02x\n',f+1,d&0xff));oki:flush()
 end)
end
-- (also without the stock sound queue, 0xFF0EEA-0xFF0F69, and its two indexes, 0xFF0C28-0xFF0C2B: a scene that
-- starts the music again queues one command more than a game without the scene)
local ranges={{0xff0bf0,0xff0c27},{0xff0c2c,0xff0c8b},{0xff0c98,0xff0ee9},{0xff0f6c,0xffd6ff},{0xffd800,0xfff93f},
 {0xfff980,0xfff9bf},{0xfffa00,0xffffff}}
local function ramsum()
 local h=0
 for a=0xff0000,0xff00ff,4 do
  local v=sp:read_u32(a)
  if a&15==0 then v=v&0x00ffffff end
  h=(h*31+v)&0xffffffff
 end
 for _,r in ipairs(ranges) do
  for a=r[1],r[2]-3,4 do h=(h*31+sp:read_u32(a))&0xffffffff end
 end
 return h
end
local function dump(name)
 local d=assert(io.open(out_prefix..'_'..name..'.bin','wb'))
 local t={}
 for a=0xff0000,0xffffff,4 do t[#t+1]=string.pack('>I4',sp:read_u32(a)) end
 for a=0x900000,0x92ffff,4 do t[#t+1]=string.pack('>I4',sp:read_u32(a)) end
 d:write(table.concat(t));d:close()
end
local function on() return sp:read_u16(BS)==MAGIC end
local function bsvars()
 return string.format('%d\t%d\t%04x\t%d\t%04x\t%04x',sp:read_u16(BS+2),sp:read_u16(BS+0x12),sp:read_u16(BS+0x0e),
  sp:read_u16(BS+0x10),sp:read_u16(BS+0x18),sp:read_u16(0xfff914))
end
local function word(offset,data,mask)
 if mask==0xffff then return data end
 if mask==0xff00 then return (data>>8)&0xff end
 return data&0xff
end
local taps={}
if video_log then
 taps[8]=sp:install_write_tap(0x800100,0x80017f,'bs_video_all',function(offset,data,mask)
  video_log:write(string.format('W\t%d\t0\t%x\t%x\t%x\n',f+1,offset,data,mask))
 end)
end
local gfxw=0
taps[1]=sp:install_write_tap(0x800100,0x80010b,'bs_cpsa',function(offset,data,mask)
 if offset~=0x800100 and offset~=0x80010a then return end
 local v=word(offset,data,mask)
 local kind=offset==0x800100 and 'obj' or 'pal'
 local extra=''
 if on() and kind=='pal' then
  local base=v<<8
  local h=0
  for a=base,base+0x17ff,4 do h=(h*31+sp:read_u32(a))&0xffffffff end
  local s={}
  for i=0,15 do s[#s+1]=string.format('%04x',sp:read_u16(base+32*12+2*i)) end
  for i=0,15 do s[#s+1]=string.format('%04x',sp:read_u16(base+32*24+2*i)) end
  extra=string.format('\t%08x\t%s',h,table.concat(s,','))
 elseif on() and kind=='obj' and v>=0x91f0 then
  local base=v<<8
  local s={}
  for k=0,255 do
   local a=base+8*k
   local e={sp:read_u16(a),sp:read_u16(a+2),sp:read_u16(a+4),sp:read_u16(a+6)}
   if e[4]==0xff00 then break end
   s[#s+1]=string.format('%04x:%04x:%04x:%04x',e[1],e[2],e[3],e[4])
  end
  extra='\t'..table.concat(s,',')
 end
 regs:write(string.format('%d\t%s\t%04x\t%s%s\n',f+1,kind,v,on() and bsvars() or '-',extra))
end)
taps[2]=sp:install_write_tap(0x800166,0x800167,'bs_layer',function(offset,data,mask)
 regs:write(string.format('%d\tlayer\t%04x\t%s\n',f+1,word(offset,data,mask),on() and bsvars() or '-'))
end)
taps[3]=sp:install_write_tap(0x800180,0x800181,'bs_snd',function(offset,data,mask)
 regs:write(string.format('%d\tsound\t%02x\t%s\n',f+1,data&0xff,on() and bsvars() or '-'))
end)
taps[4]=sp:install_write_tap(0x91c000,0x91ffff,'bs_gfx',function(offset,data,mask) gfxw=gfxw+1 end)
taps[5]=sp:install_write_tap(BS,BS+1,'bs_on',function(offset,data,mask)
 if data==MAGIC and not on() then regs:write(string.format('%d\tentry\n',f+1)); dump('entry')
 elseif data==0 and on() then regs:write(string.format('%d\texit\n',f+1)); dump('exit') end
end)
local k=0
-- the base variant's encounter mark (boss_scene_gate.py: bs_play_stage made a write of BS_SEEN and a return)
taps[7]=sp:install_write_tap(BS+0x2a,BS+0x2b,'bs_seen',function(offset,data,mask)
 regs:write(string.format('%d\tseen\t%04x\n',f+1,data))
end)
taps[6]=sp:install_write_tap(0xff0c9a,0xff0c9b,'bs_sync',function(offset,data,mask)
 k=k+1
 sync:write(string.format('%d\t%d\t%08x\n',k,f+1,ramsum()))
end)
_G.strex_bs_taps=taps
emu.register_frame_done(function()
 f=f+1
 if shift_e and f>shift_e then
  local g=f-shift_n
  hold('COIN1',(g>=200 and g<=360) and (g-200)%40<8)
  hold('SERVICE1',g>=380 and g<=440)
  hold('START1',g>=400 and g<=410)
  if not invincible then              -- the test switch (IN0 bit 6, active low) as the debug start holds it
   test_sw.user_value=(g>=380 and g<=440) and 0 or 0x40
  end
 end
 for _,h in ipairs(holds) do
  if f>=h[1] and f<=h[2] then if h[3]%2==1 then sp:write_u8(h[3],h[4]) else sp:write_u16(h[3],h[4]) end end
 end
 frames:write(string.format('%d\t%04x\t%d\t%04x\t%04x\t%04x\t%04x\t%04x\t%02x\t%04x\t%08x\t%d\t%d\n',f,sp:read_u16(BS),
  sp:read_u16(BS+2),sp:read_u16(0xfff914),sp:read_u16(0xff10d2),sp:read_u16(0xff10d6),sp:read_u16(0xff0ff4),
  sp:read_u16(0xff0ff8),sp:read_u8(0xff10c5),sp:read_u16(0xff0c22),ramsum(),gfxw,sp:read_u8(0xff0ca8)))
 gfxw=0
 if shots[f] then screen:snapshot(string.format('%s_%05d.png',out_prefix,f)) end
 if video_frames[f] then
  local file=assert(io.open(string.format('%s/vram_%05d.bin',video_dir,f),'wb'))
  local data={}
  for a=0x900000,0x92ffff,4 do data[#data+1]=string.pack('>I4',sp:read_u32(a)) end
  file:write(table.concat(data));file:close()
 end
 if video_log then video_log:flush() end
 frames:flush();regs:flush();sync:flush()
end)
