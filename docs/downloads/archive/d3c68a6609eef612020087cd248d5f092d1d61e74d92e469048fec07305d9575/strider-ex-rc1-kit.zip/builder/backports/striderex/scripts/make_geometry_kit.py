"""Finalize one qualified geometry comparison; preserve the verified Kit z inputs."""
import argparse
from copy import deepcopy
import json
from pathlib import Path
import shutil
import subprocess
import sys
import xml.etree.ElementTree as ET
import zipfile
import zlib
from boss_voice_gate import inventory, sha
ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / 'release'))
import private_mister as PM
import mra_assembly

def build(a):
    meta, members = inventory(a.build)
    common = json.loads((Path(__file__).resolve().parents[1] / 'manifests/qualification/boss_border_fresh_20261025.json').read_text())
    if not common['passed'] or {m: s['art_geometry']['source_files'] for m, s in meta['sets'].items()} != common['output_files']:
        raise ValueError('geometry build does not use the qualified common fixes')
    runtime = json.loads(a.runtime.read_text())
    pixels = json.loads(a.pixels.read_text())
    expected = {m: s['files'] for m, s in meta['sets'].items()}
    for receipt in (runtime, pixels):
        if not receipt.get('passed') or receipt.get('build_files') != expected:
            raise ValueError('qualification does not describe the selected build')
    a.out.mkdir(parents=True, exist_ok=False)
    with PM.qualified_view(a.baseline) as source:
        baseline = json.loads((source / 'producer.json').read_text())
        shutil.copytree(source, a.out, dirs_exist_ok=True)
        reverse = a.out / 'geometry-reverse.zip'
        with zipfile.ZipFile(reverse, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
            saved = {}
            for p in sorted(source.rglob('*')):
                if p.is_file() and (not p.relative_to(source).as_posix().startswith(('games/', '_Arcade/cores/'))):
                    name = p.relative_to(source).as_posix()
                    data = p.read_bytes()
                    z.writestr('files/' + name, data)
                    saved[name] = sha(data)
            for machine, inventory_ in baseline['build_files'].items():
                region = 'us' if machine == 'striderua' else 'jp'
                with zipfile.ZipFile(source / f'games/mame/striderex_{region}.zip') as old:
                    for name, digest in inventory_.items():
                        data = old.read(name)
                        if sha(data) != digest:
                            raise ValueError('baseline identity changed')
                        if data != members[machine][name]:
                            z.writestr(f'roms/{machine}/{name}', data)
            z.writestr('baseline.json', json.dumps(dict(files=saved, build_files=baseline['build_files'])))
        report = deepcopy(baseline)
        report['build_files'] = expected
        report['geometry'] = dict(scale=a.scale, reverse_sha256=sha(reverse.read_bytes()), baseline_test_id=json.loads((a.baseline / 'private-mister.json').read_text())['test_id'], qualification=dict(runtime=runtime, pixels=pixels), common_base=common, hardware_review_granted=False)
        for machine, files in members.items():
            region = 'us' if machine == 'striderua' else 'jp'
            path = a.out / f'games/mame/striderex_{region}.zip'
            with zipfile.ZipFile(path) as z:
                allfiles = {n: z.read(n) for n in z.namelist()}
            allfiles.update(files)
            with zipfile.ZipFile(path, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
                for name, data in sorted(allfiles.items()):
                    z.writestr(name, data)
            report['archives'][path.relative_to(a.out).as_posix()] = {n: sha(b) for n, b in allfiles.items()}
        mras = {}
        for old_title, old_spec in baseline['mras'].items():
            path = a.out / '_Arcade' / (old_title + '.mra')
            tree = ET.parse(path)
            root = tree.getroot()
            title = old_title.replace(' [Kit z]', '') + ' [' + a.label + ']'
            root.find('name').text = title
            machine = 'striderua' if '(USA)' in title else 'striderjr'
            for part in root.iter('part'):
                name = part.get('name')
                if name in members[machine]:
                    part.set('crc', f'{zlib.crc32(members[machine][name]):08x}')
            text = ET.tostring(root, encoding='unicode')
            new = path.with_name(title + '.mra')
            new.write_text(text)
            path.unlink()
            refs = {Path(ref).name for node in root.iter() for ref in node.get('zip', '').split('|') if ref}
            paths = [a.out / p for p in report['archives'] if Path(p).name in refs]
            image = mra_assembly.assemble(text, mra_assembly.ZipSource(paths))
            mras[title] = dict(old_spec, assembled_sha256=sha(image))
        report['mras'] = mras
        (a.out / 'producer.json').write_text(json.dumps(report, indent=2) + '\n')
    (a.out / 'README.txt').write_text('STRIDER EX PRIVATE GEOMETRY COMPARISON\n\n' + a.label + '\n' + ('Cutscenes: 256 pixels centered. Boss images: original 80x80 pixels.\n' if a.scale == 'native' else 'Cutscenes: 384 pixels. Boss images: 120x80. Horizontal Method E at 1.5x.\n') + 'Both variants include the latest boss-page continuity, text spacing, border removal and desert drawing fixes.\n' + 'Audio, voices, subtitles and gameplay use the same source build.\n' + 'Use Arcade -> Test. These are private hardware comparisons, not public release or hardware-approved builds.\n')
    shutil.copy2(Path(__file__).with_name('verify_geometry_kit.py'), a.out / 'verify_kit.py')
    subprocess.run([sys.executable, '-B', str(a.out / 'verify_kit.py'), '--root', str(a.out)], check=True)
    receipt = PM.finalize(a.out, 'strider-ex', ledger=ROOT / 'release/private_mister_builds.json')
    isolated = 'import sys,runpy; root=sys.argv[1]; sys.path.insert(0,root); sys.argv=[root+"/verify_kit.py","--root",root]; runpy.run_path(root+"/verify_kit.py",run_name="__main__")'
    subprocess.run([sys.executable, '-I', '-B', '-c', isolated, str(a.out)], check=True)
    print('Finalized', a.label, receipt['test_id'], a.out)

def main():
    if sys.argv[1:] == ['--self-test']:
        from verify_geometry_kit import self_test
        return self_test()
    p = argparse.ArgumentParser(description=__doc__)
    for n in ('build', 'baseline', 'runtime', 'pixels', 'out'):
        p.add_argument('--' + n, type=Path, required=True)
    p.add_argument('--scale', choices=('native', 'method-e'), required=True)
    p.add_argument('--label', required=True)
    a = p.parse_args()
    for n in ('build', 'baseline', 'runtime', 'pixels', 'out'):
        setattr(a, n, getattr(a, n).resolve())
    build(a)
if __name__ == '__main__':
    main()
