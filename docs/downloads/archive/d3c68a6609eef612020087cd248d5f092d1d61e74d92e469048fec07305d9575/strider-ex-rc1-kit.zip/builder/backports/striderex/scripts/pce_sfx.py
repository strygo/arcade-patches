"""Reconstruction helper."""
import argparse
import hashlib
import json
import os
import re
import shutil
import signal
import subprocess
import sys
import wave
from pathlib import Path
import numpy as np
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import oki_adpcm as OKI
ROOT = HERE.parents[2]
MANIFEST = ROOT / 'backports/striderex/manifests/pce_sfx.json'
LUA = ROOT / 'backports/striderex/lua/pce_sfx.lua'
BASE = ROOT / 'cpsplus/lua/strider_console_probe.lua'
RUNNER = ROOT / 'translations/vhunt2/scripts/run_surface_trace.py'
NEW_GAME = '300-310:P1_START;3700-3710:P1_START;4000-4010:P1_START'
SYSCARD = 'pce/acardpro/[cd] super cd-rom system (japan) (v3.0).pce'
DATA_TRACK = 2
GAP = 240
END = 7900
SR = 48000
OKI_RATE = 1000000.0 / 132
UP, DOWN = (125, 792)
BEAM = 2048
TAIL = 16
LOUD_WIN = 0.05
PEAK_DB = -1.0
STOCK_PHRASES = 29
Z80_COUNT, Z80_TABLE_OP, Z80_STOCK_TABLE = (3634, 982, 3635)
Z80_TABLE = 32512
OKI_SIZE = 262144
FREE = ((1024, 2047), (253696, 262144))
SAMPLE_MEMBERS = {'striderua': ('18.11c', '19.12c'), 'striderjr': ('sth_18.11c', 'sth_19.12c')}

def sha256(b):
    return hashlib.sha256(b).hexdigest()

def manifest():
    return json.loads(MANIFEST.read_text())

def file_sha256(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for chunk in iter(lambda: f.read(1 << 22), b''):
            h.update(chunk)
    return h.hexdigest()

def cue_files(cue):
    return [cue.parent / m for m in re.findall('^FILE "([^"]+)"', cue.read_text(), re.M)]

def effect_ids():
    m = manifest()
    return [int(e['pce_psg'], 16) for e in m['effects']] + [int(m['anchor']['pce_psg'], 16)]

def capture(a):
    out = a.out.resolve()
    if out.exists():
        sys.exit('pce_sfx: choose a fresh --out directory')
    out.mkdir(parents=True)
    cue = a.cue.resolve()
    card = a.rompath.resolve() / SYSCARD
    if not card.is_file():
        sys.exit(f'pce_sfx: no System Card at {card}')
    shutil.copyfile(LUA, out / LUA.name)
    shutil.copyfile(BASE, out / BASE.name)
    effects = effect_ids()
    env = os.environ | dict(SDL_VIDEODRIVER='dummy', SDL_AUDIODRIVER='dummy', STRIDEREX_BASE_PROBE=str(out / BASE.name), PCE_SFX_LOG=str(out / 'sfx_log.tsv'), PCE_SFX_LIST=','.join((f'{e:02x}' for e in effects)), PCE_SFX_GAP=str(GAP), STRIDER_PSX_POKES='', STRIDER_CONSOLE_RAM_DUMP='0', STRIDER_PCE_STATE='0', STRIDER_PCE_START_STAGE='1', STRIDER_PCE_CHECKPOINT_CENSUS='0', STRIDER_PCE_FIRST_CHECKPOINT='', STRIDER_PCE_PHASE='', STRIDER_PSX_SOUND_STATE='0')
    mame = ['-nothrottle', '-video', 'none', '-sound', 'none', '-hashpath', os.environ.get('STREX_MAME_HASH', '/opt/homebrew/share/mame/hash'), '-cfg_directory', str(out / 'cfg'), '-nvram_directory', str(out / 'nvram'), '-wavwrite', str(out / 'pce_audio.wav'), '-cdrom', str(cue), '-cart', 'acardpro']
    cmd = [sys.executable, str(RUNNER), '--machine', 'pce', '--outdir', str(out), '--script', str(out / LUA.name), '--schedule', NEW_GAME, '--captures', f'{END}=limit', '--rompath', str(a.rompath.resolve()), '--mame', a.mame] + ['--mame-arg=' + x for x in mame]
    version = subprocess.run([a.mame, '-version'], capture_output=True, text=True).stdout.strip()
    files = cue_files(cue)
    info = dict(command=cmd, effects=[f'{e:#04x}' for e in effects], gap=GAP, end=END, mame_version=version, cue=cue.name, cue_sha256=file_sha256(cue), data_track=files[DATA_TRACK - 1].name, data_track_sha256=file_sha256(files[DATA_TRACK - 1]), system_card_sha256=file_sha256(card), lua_sha256=file_sha256(out / LUA.name), base_probe_sha256=file_sha256(out / BASE.name))
    (out / 'capture.json').write_text(json.dumps(info, indent=1) + '\n')
    with (out / 'run.log').open('w') as log:
        proc = subprocess.Popen(cmd, env=env, cwd=out, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        try:
            code = proc.wait(timeout=a.timeout)
        except subprocess.TimeoutExpired:
            os.killpg(proc.pid, signal.SIGTERM)
            try:
                proc.wait(timeout=20)
            except subprocess.TimeoutExpired:
                os.killpg(proc.pid, signal.SIGKILL)
                proc.wait()
            code = 124
    info['exit_code'] = code
    (out / 'capture.json').write_text(json.dumps(info, indent=1) + '\n')
    if code:
        sys.exit(f"pce_sfx: MAME run exit {code} ({out / 'run.log'})")
    print(json.dumps(summary(out), indent=1))
    return 0

def read_wav(path):
    with wave.open(str(path)) as w:
        if w.getframerate() != SR or w.getsampwidth() != 2:
            raise SystemExit(f'pce_sfx: {path}: {w.getframerate()} Hz, {8 * w.getsampwidth()} bit; 48 kHz 16 bit expected')
        return np.frombuffer(w.readframes(w.getnframes()), dtype='<i2').reshape(-1, w.getnchannels())

def write_wav(path, y, sr=SR):
    y = np.asarray(y)
    if y.dtype != np.int16:
        y = np.clip(np.round(y), -32768, 32767).astype(np.int16)
    with wave.open(str(path), 'wb') as w:
        w.setnchannels(1 if y.ndim == 1 else y.shape[1])
        w.setsampwidth(2)
        w.setframerate(int(sr))
        w.writeframes(y.astype('<i2').tobytes())

def read_log(cap):
    """sfx_log.tsv: [(effect, injection time)], {effect: PSG channels it enables}."""
    injects, psg = ([], [])
    for line in (cap / 'sfx_log.tsv').read_text().splitlines():
        f = line.split('\t')
        if f[2].startswith('inject'):
            injects.append((int(f[2].split()[1][4:], 16), float(f[1]), int(f[0])))
        elif f[2].startswith('psg'):
            reg, val = (int(x.split('=')[1], 16) for x in f[2].split()[1:])
            psg.append((float(f[1]), reg, val))
    if [e for e, _, _ in injects] != effect_ids():
        raise SystemExit(f"pce_sfx: {cap}: injected {[hex(e) for e, _, _ in injects]}, not the manifest's effects")
    channels = {}
    for k, (e, t, _) in enumerate(injects):
        t1 = injects[k + 1][1] if k + 1 < len(injects) else float('inf')
        sel, used = (0, set())
        for tt, reg, val in psg:
            if t <= tt < t1:
                if reg == 0:
                    sel = val & 7
                elif reg == 4 and val & 128 and val & 31:
                    used.add(sel)
        channels[e] = sorted(used)
    return (injects, channels)

def clips(cap, check=True):
    """{effect: stereo int16 clip} from a capture, each checked against its manifest pin."""
    x = read_wav(cap / 'pce_audio.wav')
    injects, _ = read_log(cap)
    pins = {int(e['pce_psg'], 16): e.get('clip_sha256') for e in manifest()['effects']}
    m = manifest()
    pins[int(m['anchor']['pce_psg'], 16)] = m['anchor'].get('clip_sha256')
    out = {}
    for e, t, _ in injects:
        a = int(round(t * SR))
        seg = x[a:a + int(GAP / 60 * SR) - SR // 4]
        nz = np.flatnonzero(np.abs(seg).max(1))
        if not len(nz):
            raise SystemExit(f'pce_sfx: effect {e:#04x} is silent in the capture')
        if np.abs(x[a - SR // 2:a]).max():
            raise SystemExit(f'pce_sfx: the capture is not silent before effect {e:#04x}')
        c = np.ascontiguousarray(seg[nz[0]:nz[-1] + 1])
        if check and pins.get(e) and (sha256(c.tobytes()) != pins[e]):
            raise SystemExit(f'pce_sfx: effect {e:#04x}: the clip is {sha256(c.tobytes())[:16]}..., the manifest pins {pins[e][:16]}...')
        out[e] = c
    return out

def mono(clip):
    from scipy.signal import butter, sosfiltfilt
    m = clip.astype(float).mean(1)
    return sosfiltfilt(butter(2, 20, 'hp', fs=SR, output='sos'), m)

def loudness_db(y, sr, full=32768.0):
    """The largest RMS over a LOUD_WIN window (hop LOUD_WIN / 4), dBFS against `full`."""
    y = np.asarray(y, dtype=float)
    n = max(1, int(round(LOUD_WIN * sr)))
    hop = max(1, n // 4)
    if len(y) <= n:
        r = np.sqrt(np.mean(y ** 2))
    else:
        c = np.concatenate([[0.0], np.cumsum(y * y)])
        idx = np.arange(0, len(y) - n + 1, hop)
        r = np.sqrt((c[idx + n] - c[idx]).max() / n)
    return 20 * np.log10(max(r, 1e-12) / full)

def summary(cap):
    injects, channels = read_log(cap)
    cs = clips(cap, check=False)
    return {f'{e:#04x}': dict(frame=fr, time=t, samples=len(cs[e]), seconds=round(len(cs[e]) / SR, 4), clip_sha256=sha256(cs[e].tobytes()), psg_channels=channels[e], loudness_db=round(loudness_db(mono(cs[e]), SR), 3)) for e, t, fr in injects}

def check_inputs(cap):
    """The capture's inputs are the manifest's (the cue, the data track, the System Card, the scripts)."""
    info = json.loads((cap / 'capture.json').read_text())
    pin = manifest()['inputs']
    bad = [k for k, v in pin.items() if k != 'note' and info.get(k) != v]
    if info.get('exit_code') != 0 or bad:
        raise SystemExit(f"pce_sfx: {cap}: inputs differ from the manifest: {bad or 'the run failed'}")
    return info

def to_oki_rate(m):
    """48 kHz -> 7575.76 Hz: a 2047-tap Kaiser (beta 12) low-pass at 3.65 kHz, then resample_poly 125/792."""
    from scipy.signal import fftconvolve, firwin, resample_poly
    lp = firwin(2047, 3650, fs=SR, window=('kaiser', 12))
    return resample_poly(fftconvolve(m, lp, 'same'), UP, DOWN, window=('kaiser', 12))

def from_oki_rate(y, n=None):
    from scipy.signal import resample_poly
    out = resample_poly(np.asarray(y, dtype=float), DOWN, UP, window=('kaiser', 12))
    return out if n is None else out[:n]

def level_plan(m_db, anchor_db, lv, y):
    """The attenuation nibble and the encode's gain for one effect: the target loudness in the arcade's"""
    target = lv['bomb3_db'] + m_db - anchor_db
    need = target - lv['oki_full_scale_db']
    l_unit = loudness_db(y, OKI_RATE, 2048.0)
    g_max = 2048 * 10 ** (PEAK_DB / 20) / np.abs(y).max()
    l_max = l_unit + 20 * np.log10(g_max)
    fits = [n for n in range(9) if l_max + OKI.volume_db(n) >= need]
    n = max(fits) if fits else 0
    gain_db = min(need - OKI.volume_db(n) - l_unit, 20 * np.log10(g_max))
    return dict(target_db=round(target, 3), need_db=round(need, 3), volume=n, gain_db=float(gain_db), shortfall_db=round(max(0.0, need - l_max - OKI.volume_db(n)), 3))

def convert(cs):
    """{effect: dict(adpcm bytes, nibbles' decode, plan, ...)} from the clips; every encode round-trips and"""
    man = manifest()
    lv = man['levels']
    anchor = int(man['anchor']['pce_psg'], 16)
    anchor_db = loudness_db(mono(cs[anchor]), SR)
    out = {}
    for e in man['effects']:
        psg = int(e['pce_psg'], 16)
        m = mono(cs[psg])
        y = to_oki_rate(m)
        plan = level_plan(loudness_db(m, SR), anchor_db, lv, y)
        x = np.concatenate([y * 10 ** (plan['gain_db'] / 20), np.zeros(TAIL)])
        nibs = OKI.encode_trellis(x, BEAM)
        data = OKI.pack(nibs)
        dec = OKI.round_trip(data, nibs)
        if e.get('adpcm_sha256') and sha256(data) != e['adpcm_sha256']:
            raise SystemExit(f"pce_sfx: {e['id']}: the encode is {sha256(data)[:16]}..., the manifest pins {e['adpcm_sha256'][:16]}...")
        err = x - dec[:len(x)]
        out[psg] = dict(id=e['id'], command=int(e['command'], 16), voice=int(e['voice_mask'], 16) >> 4, data=data, decode=dec, plan=plan, adpcm_sha256=sha256(data), bytes=len(data), snr_db=round(10 * np.log10((x ** 2).sum() / (err ** 2).sum()), 2), decode_db=round(loudness_db(dec, OKI_RATE, 2048.0), 3), peak=int(np.abs(dec).max()))
    return out

def install(z80, oki, conv):
    """(sound program, 256 KB sample ROM, report) with the new phrases (module docstring)."""
    z, o = (bytearray(z80), bytearray(oki))
    if len(z) != 65536 or len(o) != OKI_SIZE:
        raise SystemExit('pce_sfx: the sound program must be 64 KB and the samples 256 KB')
    if z[Z80_TABLE_OP - 1:Z80_TABLE_OP + 2] != bytes([33, Z80_STOCK_TABLE & 255, Z80_STOCK_TABLE >> 8]) or z[Z80_COUNT] != STOCK_PHRASES - 1 or z[966:969] != bytes([58, Z80_COUNT & 255, Z80_COUNT >> 8]):
        raise SystemExit("pce_sfx: the sound program's sample path (0x3C2) is not the stock one")
    if set(z[Z80_TABLE:Z80_TABLE + 128]) != {255}:
        raise SystemExit(f'pce_sfx: the sound program at {Z80_TABLE:#x} is not free')
    hdr = [(int.from_bytes(o[8 * p:8 * p + 3], 'big'), int.from_bytes(o[8 * p + 3:8 * p + 6], 'big')) for p in range(128)]
    stock = hdr[:STOCK_PHRASES]
    if set(o[8 * STOCK_PHRASES:256]) != {0} or set(o[256:FREE[0][1]]) != {255}:
        raise SystemExit('pce_sfx: the phrase headers past the stock 29 and the first free run are not the stock fill')
    for lo, hi in FREE:
        if any((s < hi and e >= lo for s, e in stock if e > s)):
            raise SystemExit(f'pce_sfx: a stock phrase reaches the free run {lo:#x}-{hi:#x}')
    free = [list(r) for r in FREE]
    table = bytearray((z[Z80_STOCK_TABLE + n % STOCK_PHRASES] for n in range(128)))
    for p in range(STOCK_PHRASES, 128):
        o[8 * p:8 * p + 8] = o[8 * (p % STOCK_PHRASES):8 * (p % STOCK_PHRASES) + 8]
    report = dict(phrases={})
    for psg, c in conv.items():
        ph = c['command'] & 127
        if not STOCK_PHRASES <= ph < 128:
            raise SystemExit(f"pce_sfx: command {c['command']:#x} is not past the stock phrases")
        run = next((r for r in free if r[1] - r[0] >= len(c['data'])), None)
        if run is None:
            raise SystemExit(f"pce_sfx: no free run holds {c['id']} ({len(c['data'])} bytes)")
        s, e = (run[0], run[0] + len(c['data']) - 1)
        run[0] += len(c['data'])
        o[s:e + 1] = c['data']
        o[8 * ph:8 * ph + 8] = s.to_bytes(3, 'big') + e.to_bytes(3, 'big') + b'\x00\x00'
        table[ph] = c['voice'] << 4 | c['plan']['volume']
        report['phrases'][c['id']] = dict(command=f"{c['command']:#04x}", phrase=f'{ph:#04x}', start=f'{s:#07x}', stop=f'{e:#07x}', bytes=len(c['data']), voice_byte=f'{table[ph]:#04x}')
    z[Z80_TABLE:Z80_TABLE + 128] = table
    z[Z80_TABLE_OP:Z80_TABLE_OP + 2] = Z80_TABLE.to_bytes(2, 'little')
    z[Z80_COUNT] = 127
    report.update(free_left=sum((r[1] - r[0] for r in free)), z80_changes=sum((a != b for a, b in zip(z, z80))), oki_changes=sum((a != b for a, b in zip(o, oki))))
    return (bytes(z), bytes(o), report)

def driver_play(z, o, cmd):
    """What the sound program plays for a command 0x81-0xEF (0x3C2): (phrase header, voice byte); None for 0x80."""
    a = cmd & 127
    if not a:
        return None
    b = z[z[967] | z[968] << 8] + 1
    while a >= b:
        a -= b
    table = z[Z80_TABLE_OP] | z[Z80_TABLE_OP + 1] << 8
    return (bytes(o[8 * a:8 * a + 6]), z[table + a])

def split_oki(o):
    return (o[:131072], o[131072:])

def check(a):
    cap = a.capture.resolve()
    info = check_inputs(cap)
    conv = convert(clips(cap))
    rep = {c['id']: dict(command=f"{c['command']:#04x}", bytes=c['bytes'], adpcm_sha256=c['adpcm_sha256'], snr_db=c['snr_db'], decode_db=c['decode_db'], peak=c['peak'], **c['plan']) for c in conv.values()}
    print(json.dumps(dict(mame_version=info['mame_version'], effects=rep), indent=1))
    return 0

def self_test(a):
    OKI.self_test()
    man = manifest()
    cmds = [int(e['command'], 16) for e in man['effects']]
    if len(set(cmds)) != len(cmds) or any((not 128 + STOCK_PHRASES <= c < 240 for c in cmds)):
        raise SystemExit("pce_sfx: the effects' commands must be distinct sample commands past the stock phrases")
    lv = dict(bomb3_db=-13.5, oki_full_scale_db=-10.5)
    t = np.arange(4000)
    y = 3000 * np.sign(np.sin(2 * np.pi * 300 * t / OKI_RATE)) * np.exp(-t / 2000)
    for m_db in (-34.0, -27.0, -20.0):
        plan = level_plan(m_db, -24.8, lv, y)
        got = loudness_db(y * 10 ** (plan['gain_db'] / 20), OKI_RATE, 2048.0) + OKI.volume_db(plan['volume'])
        peak = np.abs(y).max() * 10 ** (plan['gain_db'] / 20)
        assert peak <= 2048 * 10 ** (PEAK_DB / 20) + 1e-06, plan
        assert plan['shortfall_db'] > 0 or abs(got - plan['need_db']) < 1e-06, (plan, got)
    if a.rom_dir:
        d = a.rom_dir / 'striderua'
        z = (d / '09.12b').read_bytes()
        o = b''.join(((d / n).read_bytes() for n in SAMPLE_MEMBERS['striderua']))
    else:
        z = bytearray(b'\xff' * 65536)
        z[962:984] = bytes.fromhex('e67fc8083a320e3c4708b838039018fa57cbfa21330e')
        z[Z80_COUNT] = STOCK_PHRASES - 1
        z[Z80_STOCK_TABLE:Z80_STOCK_TABLE + STOCK_PHRASES] = bytes([16 + k % 3 * 16 + k % 2 for k in range(STOCK_PHRASES)])
        o = bytearray(b'\xff' * OKI_SIZE)
        o[:256] = bytes(256)
        for p in range(1, STOCK_PHRASES):
            o[8 * p:8 * p + 6] = (2048 * p).to_bytes(3, 'big') + (2048 * p + 2047).to_bytes(3, 'big')
        o[2048:253696] = bytes(range(256)) * ((253696 - 2048) // 256) + bytes((253696 - 2048) % 256)
        z, o = (bytes(z), bytes(o))
    fake = {28 + k: dict(id=f'e{k}', command=c, voice=4 + k // 2 * 4, data=bytes([k + 1]) * (300 + 100 * k), plan=dict(volume=k)) for k, c in enumerate(cmds)}
    z2, o2, rep = install(z, o, fake)
    for cmd in range(128, 240):
        if cmd in cmds:
            hdr, vb = driver_play(z2, o2, cmd)
            c = next((v for v in fake.values() if v['command'] == cmd))
            s, e = (int.from_bytes(hdr[:3], 'big'), int.from_bytes(hdr[3:6], 'big'))
            assert o2[s:e + 1] == c['data'] and vb == c['voice'] << 4 | c['plan']['volume'], hex(cmd)
            assert any((lo <= s and e < hi for lo, hi in FREE)), hex(cmd)
        else:
            assert driver_play(z2, o2, cmd) == driver_play(z, o, cmd), hex(cmd)
    changed = [i for i in range(65536) if z2[i] != z[i]]
    assert all((i in (Z80_TABLE_OP, Z80_TABLE_OP + 1, Z80_COUNT) or Z80_TABLE <= i < Z80_TABLE + 128 for i in changed))
    try:
        bad = bytearray(z)
        bad[Z80_TABLE + 5] = 0
        install(bytes(bad), o, fake)
        raise AssertionError('install took a program with no free table space')
    except SystemExit:
        pass
    print('pce_sfx self-test ok:', rep['free_left'], 'bytes left in the free runs;', 'stock sets' if a.rom_dir else 'synthetic ROMs')
    return 0

def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('--self-test', action='store_true')
    p.add_argument('--rom-dir', type=Path)
    sub = p.add_subparsers(dest='cmd')
    c = sub.add_parser('capture')
    c.add_argument('--cue', type=Path, required=True)
    c.add_argument('--rompath', type=Path, required=True)
    c.add_argument('--out', type=Path, required=True)
    c.add_argument('--mame', default='mame')
    c.add_argument('--timeout', type=float, default=1200)
    k = sub.add_parser('check')
    k.add_argument('capture', type=Path)
    a = p.parse_args()
    if a.self_test:
        return self_test(a)
    if a.cmd == 'capture':
        return capture(a)
    if a.cmd == 'check':
        return check(a)
    p.print_help()
    return 2
if __name__ == '__main__':
    sys.exit(main())
