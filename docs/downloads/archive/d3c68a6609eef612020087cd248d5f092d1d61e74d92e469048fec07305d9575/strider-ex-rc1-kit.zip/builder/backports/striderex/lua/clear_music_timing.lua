-- Read-only extension for the regular clear observer. Never changes game RAM.
local m=manager.machine
local sp=m.devices[':maincpu'].spaces['program']
local out=assert(os.getenv('OUT'))
local moon=os.getenv('CLEAR_MUSIC_MOON_LUA') and dofile(os.getenv('CLEAR_MUSIC_MOON_LUA')) or nil
local log=assert(io.open(out..'/clear_music.tsv','w'))
log:write('frame\tmode\ttimer\tactive\tphase\tage\tlevel\ttail\tscore\tpack\n')
return {frame=function(f,clear,mode,regs)
 if moon then moon.frame(f,clear,mode,regs) end
 log:write(string.format('%d\t%d\t%d\t%d\t%d\t%d\t%x\t%d\t%08x\t%d\n',
  f,mode,sp:read_u16(0xff0c1a),sp:read_u16(0xffcf00),sp:read_u16(0xffcf02),
  sp:read_u16(0xffcf04),sp:read_u16(0xffcf06),sp:read_u16(0xffcf08),
  sp:read_u32(0xff0cb6),sp:read_u8(0x1fffff)&1))
 log:flush()
end,capture=function(f)
 return moon and moon.capture and moon.capture(f) or false
end}
