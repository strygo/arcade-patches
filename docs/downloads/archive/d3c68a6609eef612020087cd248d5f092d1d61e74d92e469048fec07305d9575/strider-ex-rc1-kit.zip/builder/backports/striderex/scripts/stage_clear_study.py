"""Bounded stage-clear research captures from declared stock or prepared EX sets."""
import argparse
import csv
import hashlib
import json
import os
import subprocess
import sys
import struct
import tempfile
from pathlib import Path
ROOT = Path(__file__).resolve().parents[3]
LUA = ROOT / 'backports/striderex/lua/stage_clear_study.lua'
DEBUG = ROOT / 'backports/striderex/lua/arcade_debug_start.lua'

def analyze(out):
    with (out / 'frames.tsv').open() as f:
        rows = list(csv.DictReader(f, delimiter='\t'))
    clear = next((int(r['frame']) for r in rows if r['mode'] == '6' and int(r['frame']) > 450), None)
    changes = []
    prev = None
    for r in rows:
        if clear is None or int(r['frame']) < clear - 2:
            continue
        key = tuple((r[k] for k in ('mode', 'stage', 'state', 'sub', 'layer', 'active')))
        if key != prev:
            changes.append({**r, 'relative_frame': int(r['frame']) - clear})
            prev = key
    return dict(clear_frame=clear, transitions=changes, frames=len(rows), captures=len(list(out.glob('s_*.png'))))

def compare(control, experiment, review):
    """Keep the captured clocks and actual emulator images; no image warping."""
    from PIL import Image, ImageDraw

    def rows(d):
        with (d / 'frames.tsv').open() as f:
            return list(csv.DictReader(f, delimiter='\t'))
    a, b = (rows(control), rows(experiment))
    ra = json.loads((control / 'report.json').read_text())
    rb = json.loads((experiment / 'report.json').read_text())
    assert ra['completed'] and rb['completed'] and rb['presentation_experiment']
    keys = ('frame', 'mode', 'stage', 'state', 'sub', 'x', 'y', 'camx', 'camy', 'layer', 'objbase', 'active')
    same = len(a) == len(b) and all((all((x[k] == y[k] for k in keys)) for x, y in zip(a, b)))
    sound_same = (control / 'debug_log.tsv').read_bytes() == (experiment / 'debug_log.tsv').read_bytes()
    if not same or not sound_same or ra['clear_frame'] != rb['clear_frame']:
        raise ValueError('presentation experiment changed the observed clock, position, flow or sound')
    review.mkdir(parents=True, exist_ok=False)
    clear = ra['clear_frame']
    paths = [{int(p.stem[2:]): p for p in d.glob('s_*.png')} for d in (control, experiment)]
    frames = sorted(set(paths[0]) & set(paths[1]))
    frames = [f for f in frames if clear - 10 <= f <= clear + 300]

    def picture(f):
        out = Image.new('RGB', (768, 244))
        draw = ImageDraw.Draw(out)
        for j, label in enumerate(('Current EX', 'Presentation experiment')):
            out.paste(Image.open(paths[j][f]).convert('RGB'), (384 * j, 20))
            draw.text((384 * j + 5, 4), f'{label} | clear {f - clear:+d}', fill='white')
        return out
    images = [picture(f) for f in frames]
    durations = [max(10, round((y - x) * 100 / 59.637) * 10) for x, y in zip(frames, frames[1:])] + [500]
    images[0].save(review / 'comparison.gif', save_all=True, append_images=images[1:], duration=durations, loop=0)
    poster = Image.new('RGB', (768, 244 * 4))
    for i, k in enumerate((3, 55, 100, 285)):
        poster.paste(picture(min(frames, key=lambda f: abs(f - clear - k))), (0, 244 * i))
    poster.save(review / 'comparison.png')
    result = dict(schema='striderex-stage-clear-presentation-study/1', presentation_experiment=True, release_qualification=False, observed_game_flow_positions_and_clocks_identical=same, sound_command_log_identical=sound_same, frames=len(a), clear_frame=clear, mode_2_relative_frame=next((int(r['frame']) - clear for r in a if int(r['frame']) > clear and r['mode'] == '2')), captures_compared=len(frames), control_report_sha256=hashlib.sha256((control / 'report.json').read_bytes()).hexdigest(), experiment_report_sha256=hashlib.sha256((experiment / 'report.json').read_bytes()).hexdigest(), preview_sha256={p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in review.iterdir()})
    (review / 'comparison.json').write_text(json.dumps(result, indent=2) + '\n')
    return result

def input_inventory(rompath, machine):
    result = {}
    for name in dict.fromkeys((machine, 'strider')):
        folder = rompath / name
        paths = sorted((p for p in folder.iterdir() if p.is_file())) if folder.is_dir() else [p for ext in ('.zip', '.7z') if (p := (rompath / (name + ext))).is_file()]
        for p in paths:
            result[str(p.relative_to(rompath))] = hashlib.sha256(p.read_bytes()).hexdigest()
    if not result:
        raise ValueError('no declared ROM set files found')
    return result

def code_study(rom_dir, build):
    import desert_ex as D
    import respawn_fix as R
    regions = {}
    for machine in R.SETS:
        stock = {p.name: p.read_bytes() for p in (rom_dir / machine).iterdir() if p.is_file()}
        image = R.compose(stock, R.SETS[machine])
        candidate = R.compose({**stock, **{p.name: p.read_bytes() for p in (build / machine).iterdir() if p.is_file()}}, R.SETS[machine])
        symbols = D.locate(image)
        table = symbols['DZ_CLEAR'] + 36
        handlers = [table + off for off in struct.unpack_from('>5h', image, table)]
        starts = [dict(stage=i, address=hex(at), entry_bytes=image[at:at + 14].hex(), calls_clear_both_sprite_lists=image[at:at + 4] == bytes.fromhex('4eb80b3a'), entry_preserved_in_ex=image[at:at + 14] == candidate[at:at + 14]) for i, at in enumerate(handlers)]
        tail = bytes.fromhex('303c02004eb80e10303c03004eb80e10303c04004eb80e10303c000a4eb807de4eb80b3a')
        matches = [i for i in range(handlers[-1], handlers[-1] + 768) if image[i:i + len(tail)] == tail]
        if len(matches) != 1 or not all((s['calls_clear_both_sprite_lists'] and s['entry_preserved_in_ex'] for s in starts)):
            raise ValueError('unexpected stage-clear code shape')
        at = matches[0]
        regions[machine] = dict(stock_program_sha256=hashlib.sha256(image).hexdigest(), ex_program_sha256=hashlib.sha256(candidate).hexdigest(), clear_task=hex(symbols['DZ_CLEAR']), handlers=starts, shared_final_clear=hex(at), shared_final_clear_bytes=tail.hex(), shared_final_clear_preserved_in_ex=image[at:at + len(tail)] == candidate[at:at + len(tail)])
    return dict(schema='striderex-stage-clear-code-study/1', regions=regions, release_qualification=False)

def main():
    if sys.argv[1:2] == ['code']:
        p = argparse.ArgumentParser(description='Check stock and EX clear-entry/tail instructions')
        for n in ('rom-dir', 'build', 'receipt'):
            p.add_argument('--' + n, type=Path, required=True)
        a = p.parse_args(sys.argv[2:])
        result = code_study(a.rom_dir, a.build)
        a.receipt.parent.mkdir(parents=True, exist_ok=True)
        a.receipt.write_text(json.dumps(result, indent=2) + '\n')
        print('Matched both regions: five clear entries and the shared final removal')
        return 0
    if sys.argv[1:2] == ['compare']:
        p = argparse.ArgumentParser(description='Compare current and experimental stage-clear captures')
        for n in ('control', 'experiment', 'review'):
            p.add_argument('--' + n, type=Path, required=True)
        a = p.parse_args(sys.argv[2:])
        print(json.dumps(compare(a.control, a.experiment, a.review), indent=2))
        return 0
    if '--self-test' in sys.argv:
        with tempfile.TemporaryDirectory() as tmp:
            out = Path(tmp)
            (out / 'frames.tsv').write_text('frame\tmode\tstage\tstate\tsub\tlayer\tactive\n500\t4\t0\t0\t0\t13be\t0\n501\t6\t0\t0\t0\t13be\t0\n502\t6\t1\t0\t0\t13be\t0\n')
            r = analyze(out)
            assert r['clear_frame'] == 501 and len(r['transitions']) == 3 and (r['frames'] == 3)
            assert r['transitions'][-1]['relative_frame'] == 1
        print('self-test ok')
        return 0
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--mame', type=Path, required=True)
    p.add_argument('--rompath', type=Path, required=True)
    p.add_argument('--machine', default='striderua')
    p.add_argument('--stage', type=int, default=0)
    p.add_argument('--area', type=int, default=7)
    p.add_argument('--frames', type=int, default=6000)
    p.add_argument('--after-clear', type=int, default=400)
    p.add_argument('--invincible-end', type=int, help='release the debug test switch before the ending')
    p.add_argument('--clear-at', type=int)
    p.add_argument('--presentation-experiment', action='store_true', help='draw-only research control; never release qualification')
    p.add_argument('--third-moon', action='store_true', help='log Third Moon clear and ending-specific phases')
    p.add_argument('--moon-experiment', action='store_true', help='Third Moon presentation experiment after the original leap')
    p.add_argument('--inputs', default='450-5800@6/3:P1_BUTTON1')
    p.add_argument('--out', type=Path, required=True)
    a = p.parse_args()
    if a.presentation_experiment and (a.stage != 0 or a.machine not in ('striderua', 'striderus01')):
        p.error('presentation experiment is scoped to USA St. Petersburg research')
    if (a.third_moon or a.moon_experiment) and (a.stage != 4 or a.presentation_experiment):
        p.error('Third Moon studies require stage 4 and exclude the regular-stage experiment')
    inventory = input_inventory(a.rompath, a.machine)
    a.out = a.out.resolve()
    a.out.mkdir(parents=True, exist_ok=False)
    env = dict(os.environ, SDL_VIDEODRIVER='dummy', SDL_AUDIODRIVER='dummy', OUT=str(a.out), END=str(a.frames), AFTER_CLEAR=str(a.after_clear), STREX_DEBUG_START=str(DEBUG), STREX_PREFIX=str(a.out / 'debug'), STREX_STAGE=str(a.stage), STREX_AREA=str(a.area), STREX_END=str(a.frames + 100), STREX_INVINCIBLE='1', STREX_INPUTS=a.inputs)
    if a.clear_at is not None:
        env['CLEAR_AT'] = str(a.clear_at)
    if a.invincible_end is not None:
        env['STREX_INVINCIBLE_END'] = str(a.invincible_end)
    if a.presentation_experiment:
        env['PRESENTATION_EXPERIMENT'] = '1'
    extension = LUA.with_name('third_moon_study.lua') if a.third_moon or a.moon_experiment else None
    if extension:
        env['STUDY_EXTENSION'] = str(extension)
        env['MOON_EXPERIMENT'] = str(int(a.moon_experiment))
    cmd = [str(a.mame.resolve()), a.machine, '-rompath', str(a.rompath.resolve()), '-nothrottle', '-video', 'none', '-sound', 'none', '-skip_gameinfo', '-noautosave', '-cfg_directory', str(a.out / 'cfg'), '-nvram_directory', str(a.out / 'nv'), '-snapshot_directory', str(a.out), '-autoboot_script', str(LUA), '-seconds_to_run', str(a.frames // 50 + 30)]
    result = subprocess.run(cmd, env=env, cwd=a.out, capture_output=True, text=True, timeout=900)
    (a.out / 'mame.log').write_text(result.stdout + result.stderr)
    report = dict(schema='striderex-stage-clear-study/1', machine=a.machine, stage=a.stage, area=a.area, forced_clear_at=a.clear_at, inputs=a.inputs, exit_code=result.returncode, invincible_end=a.invincible_end, presentation_experiment=a.presentation_experiment, third_moon=a.third_moon or a.moon_experiment, moon_experiment=a.moon_experiment, extension_sha256=hashlib.sha256(extension.read_bytes()).hexdigest() if extension else None, rom_inputs=inventory, runtime_sha256=hashlib.sha256(a.mame.read_bytes()).hexdigest(), lua_sha256=hashlib.sha256(LUA.read_bytes()).hexdigest(), **analyze(a.out))
    report['lua_errors'] = '[LUA ERROR]' in result.stdout + result.stderr
    report['completed'] = result.returncode == 0 and (not report['lua_errors']) and (report['clear_frame'] is not None) and (report['frames'] >= report['clear_frame'] + a.after_clear)
    (a.out / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({k: v for k, v in report.items() if k not in ('transitions', 'rom_inputs')}, indent=2))
    return 0 if report['completed'] else 1
if __name__ == '__main__':
    raise SystemExit(main())
