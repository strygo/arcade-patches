; Only the settle after the antlion uses the gentler speed. Retain every
; opening/fight pan's native speed and timing.
        org $1F4400
        dc.w $4EF9
        dc.l dt_r
        dc.w $4EF9
        dc.l dt_l
        dc.w $4EF9
        dc.l dt_u
        dc.w $4EF9
        dc.l dt_d
dt_r:   bsr dt_small
        bne.s .old
        addq.w #1,d0
        jmp SCR_R
.old:   add.w #24,d0
        jmp SCR_R
dt_l:   bsr dt_small
        bne.s .old
        subq.w #1,d0
        jmp SCR_L
.old:   sub.w #24,d0
        jmp SCR_L
dt_u:   bsr dt_small
        bne.s .old
        addq.w #1,d0
        jmp SCR_U
.old:   add.w #24,d0
        jmp SCR_U
dt_d:   bsr dt_small
        bne.s .old
        subq.w #1,d0
        jmp SCR_D
.old:   sub.w #24,d0
        jmp SCR_D
dt_small:
        cmpi.w #1,$FFF932
        bne.s .done
        cmpi.w #25,$FFF934
.done:  rts
