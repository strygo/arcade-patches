# Strider EX boss scene glyphs

fine"), including the full-width ？ ("keep the full-width ?").

The boss scenes show each boss's approved line (`manifests/portrait_text_review.json`
character comes from the arcade font (`subtitle_ex.JA_ARCADE`), then the approved
caption glyphs (`assets/subtitle_font/ja_glyphs.txt`), then `ja_glyphs.txt` here,
which holds only the 29 characters neither has.

`ja_glyphs.txt` has the caption set's format (`assets/subtitle_font/README.md`):
16x16 grids, `.` transparent, pens 1-5 as the arcade font, with a status per
glyph (`traced-draft` or `hand-edited`). All 29 were traced by
`scripts/boss_glyphs.py draft --guide-font <Hiragino Kaku Gothic W3>`, the
caption glyphs' method (`subtitle_ex.trace_guide`): a 1-pixel skeleton of the
guide font's outline, gridded to the arcade metrics. The caption README's notes
apply here too (the traced shapes, and hand cleanup of crowded kanji such as
撃 葬 誠 後 悔). The three drawn by hand for the superseded desert text pages
(今 ぞ 僧, branch `992e3f113`) are traced again here like the rest.

`draft` never overwrites a grid, so hand edits survive; mark an edited glyph
`hand-edited`. Review sheet:

    boss_glyphs.py sheet --rom-dir <striderua ROMs> --label-font <a Japanese font> --out <dir>
