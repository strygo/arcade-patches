; No-pack final-page reading pause. The source streams/caption schedules and
; CPS+ path retain their existing bytes. FRAMES freezes just before caption
; removal; OBJ DMA and the sound clock keep running for 120 extra VBlanks.
READ_HOLD equ $FFF9BE                   ; word, previously unused before boss state
    ifne REGION_EN
READ_OBJ_FLIP equ $100A36
READ_STEP_RESUME equ $100BE2
    else
READ_OBJ_FLIP equ $100996
READ_STEP_RESUME equ $100B42
    endc

        dcb.b   $1FF200-*, $FF
np_read_tick:
        btst    #PACK,FLAGS+$F
        bne.s   .legacy
        tst.b   CONT_NEXT
        bne.s   .legacy
        moveq   #0,d0
        move.b  CINE_STAGE,d0
        subq.w  #1,d0
        cmp.w   #5,d0
        bhi.s   .legacy
        add.w   d0,d0
        lea     np_read_off(pc),a0
        move.w  0(a0,d0.w),d1
        beq.s   .legacy                 ; Meio already has a longer closing interval
        addq.w  #1,TICK
        cmp.w   #$24,NP_CUE
        bne.s   .out
        moveq   #0,d1
        move.w  12(a0,d0.w),d1
        moveq   #0,d0
        move.w  READ_HOLD,d0
        add.l   FRAMES,d0               ; elapsed records plus the inserted real-time pause
        cmp.l   d1,d0
        bne.s   .out
        move.w  #6,SOUND+8
        move.w  #$FB,CUE
.out:   rts
.legacy:
        jmp     np_fade_tick            ; original logo trim, connected flow and other paths

        dcb.b   $1FF280-*, $FF
np_read_step:
        tst.l   FRAMES
        bne.s   .flip
        clr.w   READ_HOLD               ; fresh scene, including after START skips
.flip:  jsr     READ_OBJ_FLIP            ; keep copying both caption buffers while held
        btst    #PACK,FLAGS+$F
        bne.s   .resume
        tst.b   CONT_NEXT
        bne.s   .resume
        moveq   #0,d0
        move.b  CINE_STAGE,d0
        subq.w  #1,d0
        cmp.w   #5,d0
        bhi.s   .resume
        add.w   d0,d0
        moveq   #0,d1
        lea     np_read_off(pc),a0
        move.w  0(a0,d0.w),d1
        beq.s   .resume
        cmp.l   FRAMES,d1
        bne.s   .resume
        cmp.w   #120,READ_HOLD
        bcc.s   .resume
        addq.w  #1,READ_HOLD
        rts                             ; ex_vbl still polls START and advances sound
.resume:
        tst.w   ENDED                   ; replaced original test; JMP preserves its flags
        jmp     READ_STEP_RESUME

np_read_off:
        dc.w    1851,1340,1712,1385,0,1169 ; desert: pause before its earlier picture fade
np_read_fade:
        dc.w    1818,1297,1739,1338,0,1129 ; old fade record + 120 VBlanks
np_read_end:
