"""Phase 1: the Strider EX mapper test kit ("twin" build)."""
import argparse
import hashlib
import json
import re
import struct
import sys
import zipfile
import zlib
from pathlib import Path
ROOT = Path(__file__).resolve().parents[3]
STOCK_MRA = ROOT / 'cpsplus/mra/base_us/striderua.mra'
MB = 1048576
LAYER_TABLES = ((524300, 64, (28672, 32767), 16384), (565472, 16, (8192, 16383), 32768))
GFX_CRCS = {0: '4eee9aea', 2: '2d7f21e4', 4: '7705aa46', 6: '5b18b722', 2097152: '005f000b', 2097154: 'b9441519', 2097156: 'b7d04e8b', 2097158: '6b4713b4'}
DATA_ROM_CRC = '9b3cfc08'
EX_GFX = ['strex_gfx.c25', 'strex_gfx.c27', 'strex_gfx.c29', 'strex_gfx.c31']
sys.path.append(str(Path(__file__).resolve().parents[3] / 'release'))
import private_mister as private_test

def crc(b):
    return f'{zlib.crc32(b):08x}'

def pool(rom_dirs):
    out = {}
    for d in rom_dirs:
        paths = [d] if d.is_file() else sorted(d.rglob('*'))
        for p in paths:
            if p.suffix.lower() == '.zip':
                with zipfile.ZipFile(p) as z:
                    for i in z.infolist():
                        b = z.read(i)
                        out.setdefault(crc(b), b)
            elif p.is_file():
                b = p.read_bytes()
                out.setdefault(crc(b), b)
    return out

def swap16(b):
    a = bytearray(b)
    a[0::2], a[1::2] = (b[1::2], b[0::2])
    return bytes(a)

def twin_gfx(files):
    gfx = bytearray(4 * MB)
    for off, c in GFX_CRCS.items():
        data = files[c]
        for i in range(0, len(data), 2):
            gfx[off + 4 * i:off + 4 * i + 2] = data[i:i + 2]
    ex = bytearray(4 * MB)
    ex[0:2 * MB] = gfx[0:2 * MB]
    ex[int(2.75 * MB):3 * MB] = gfx[int(3.75 * MB):4 * MB]
    ex[3 * MB:4 * MB] = gfx[2 * MB:3 * MB]
    parts = []
    for j in range(4):
        part = bytearray(MB)
        for i in range(0, MB, 2):
            part[i:i + 2] = ex[4 * i + 2 * j:4 * i + 2 * j + 2]
        parts.append(bytes(part))
    return parts

def twin_program(data_rom_file):
    """Returns (patched data ROM file bytes, EX program file bytes, counts)."""
    data = bytearray(swap16(data_rom_file))
    ex = bytearray(b'\xff' * MB)
    cpu = lambda a: a - 524288
    L = lambda a: struct.unpack('>I', data[cpu(a):cpu(a) + 4])[0]
    W = lambda a: struct.unpack('>H', data[cpu(a):cpu(a) + 2])[0]
    put = 0
    counts = []
    for table, bsz, (lo, hi), shift in LAYER_TABLES:
        for stage in range(5):
            rec = table + 18 * stage
            grid, sec, blk = (L(rec + 2), L(rec + 6), L(rec + 10))
            nsec = W(blk) // 2
            offs = [W(blk + 2 * i) for i in range(nsec)]
            used = sorted(set(data[cpu(grid):cpu(grid) + 256]))
            spans = []
            for s in used:
                if s >= nsec:
                    sys.exit(f'table {table:#x} stage {stage}: grid names section {s} of {nsec}')
                nb = max(data[cpu(sec) + 96 * s:cpu(sec) + 96 * s + 96]) + 1
                spans.append((offs[s], nb))
            span = max((o + nb * bsz for o, nb in spans))
            copy = bytearray(data[cpu(blk):cpu(blk) + span])
            moved = 0
            positions = sorted({o + 4 * i for o, nb in spans for i in range(nb * bsz // 4)})
            for p in positions:
                c = struct.unpack('>H', copy[p:p + 2])[0]
                if lo <= c <= hi:
                    copy[p:p + 2] = struct.pack('>H', c + shift)
                    moved += 1
                elif c:
                    sys.exit(f'table {table:#x} stage {stage}: code {c:#x} outside the stock range')
            put = put + 3 & ~3
            ex[put:put + span] = copy
            data[cpu(rec + 10):cpu(rec + 14)] = struct.pack('>I', 1048576 + put)
            counts.append(dict(table=f'{table:#x}', stage=stage, block_base=f'{blk:#x}', copy_at=f'{1048576 + put:#x}', bytes=span, codes_moved=moved))
            put += span
    return (swap16(bytes(data)), swap16(bytes(ex)), counts)
EX_HEADER = '3F 40 88 73 FF'
OBJ_BANK_CODES = {2: range(8, 12)}

def check_obj_banks(header=EX_HEADER):
    """Refuse a header with which jtcps1 would skip EX sprites (see EX_HEADER)."""
    b = bytes.fromhex(header.replace(' ', ''))
    mask = b[3] | b[4] << 8
    for bank, nibbles in OBJ_BANK_CODES.items():
        m = mask >> 4 * bank & 15
        bad = [n for n in nibbles if n & ~m & 15]
        if bad:
            sys.exit(f'EX mapper header {header}: bank {bank} mask {m:X} makes jtcps1 skip sprite codes {bad[0]:X}000-{bad[-1]:X}FFF')
    return header

def mra(text, files):
    """striderua.mra -> the test MRA (2 MB program, id 0x3F, EX parts)."""
    head_old = ('00 04 40 04 40 05 FF FF', '08 30 22 40 88 73 FF 00')
    head_new = ('00 08 40 08 40 09 FF FF', '08 30 ' + check_obj_banks() + ' 00')
    for a, b in zip(head_old, head_new):
        if text.count(a) != 1:
            sys.exit(f'stock MRA header row changed: {a}')
        text = text.replace(a, b)
    rep = {'<name>Strider (USA, B-Board 89624B-3)</name>': '<name>Strider EX (mapper test)</name>', 'zip="striderua.zip|strider.zip"': 'zip="striderex_test.zip"', f'<part name="st-14.8h" crc="{DATA_ROM_CRC}"/>': f'''<part name="strex_14.8h" crc="{crc(files['strex_14.8h'])}"/>\n        <part name="strex_p6.bin" crc="{crc(files['strex_p6.bin'])}"/>''', '<!-- audiocpu - starts at 0x100000': '<!-- audiocpu - starts at 0x200000', '<!-- oki - starts at 0x110000': '<!-- oki - starts at 0x210000', '<!-- gfx - starts at 0x150000 - length 0x400000 (22 bits) -->': '<!-- gfx - starts at 0x250000 - length 0x800000 (23 bits) -->', '<!-- maincpu - starts at 0x0 - length 0x100000 (20 bits) -->': '<!-- maincpu - starts at 0x0 - length 0x200000 (21 bits) -->'}
    for a, b in rep.items():
        if text.count(a) != 1:
            sys.exit(f'stock MRA line changed: {a}')
        text = text.replace(a, b)
    ex_parts = ''.join((f'            <part name="{n}" crc="{crc(files[n])}" map="{m}"/>\n' for n, m in zip(EX_GFX, ('00000021', '00002100', '00210000', '21000000'))))
    anchor = '        <!-- Total'
    if text.count(anchor) != 1:
        sys.exit('stock MRA total line changed')
    text = text.replace(anchor, '        <interleave output="64">\n' + ex_parts + '        </interleave>\n' + anchor)
    text = re.sub(' asm_md5="[0-9a-f]+"', '', text)
    return text.replace('<!-- Total 0x550000 bytes - 5440 kBytes -->', '<!-- Total 0xa50000 bytes - 10560 kBytes -->')

def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('--rom', type=Path, action='append', required=True, help='stock striderua and strider sets (directories or zips; repeat)')
    p.add_argument('--out', type=Path, required=True)
    p.add_argument('--rbf', default='jtcps1-strex-test', help='core name the MRAs bind (never the production jtcps1)')
    p.add_argument('--core', type=Path, help='built RBF to place as _Arcade/cores/<rbf>_<date>.rbf')
    p.add_argument('--date', default='20261009', help='date suffix for the core file')
    a = p.parse_args()
    files = pool(a.rom)
    missing = [c for c in [DATA_ROM_CRC, *GFX_CRCS.values()] if c not in files]
    if missing:
        sys.exit(f'stock files missing (CRC): {missing}')
    out = {}
    out['strex_14.8h'], out['strex_p6.bin'], counts = twin_program(files[DATA_ROM_CRC])
    for n, b in zip(EX_GFX, twin_gfx(files)):
        out[n] = b
    arcade, games = (a.out / '_Arcade', a.out / 'games/mame')
    (arcade / 'cores').mkdir(parents=True, exist_ok=True)
    games.mkdir(parents=True, exist_ok=True)
    rbf = f'<rbf>{a.rbf}</rbf>'
    stock = STOCK_MRA.read_text()
    if stock.count('<rbf>jtcps1</rbf>') != 1:
        sys.exit('stock MRA rbf element changed')
    test_mra = mra(stock, out).replace('<rbf>jtcps1</rbf>', rbf)
    members = dict(out)
    for name, c in re.findall('<part name="([^"]+)" crc="([0-9a-f]{8})"', test_mra):
        if name not in members:
            if c not in files:
                sys.exit(f'stock member {name} (CRC {c}) not in the given sets')
            members[name] = files[c]
        if crc(members[name]) != c:
            sys.exit(f'{name}: CRC {crc(members[name])}, the MRA says {c}')
    with zipfile.ZipFile(games / 'striderex_test.zip', 'w', zipfile.ZIP_DEFLATED) as z:
        for n, b in sorted(members.items()):
            z.writestr(zipfile.ZipInfo(n, (1996, 1, 1, 0, 0, 0)), b)
    (arcade / 'Strider EX (mapper test).mra').write_text(test_mra)
    control = stock.replace('<rbf>jtcps1</rbf>', rbf).replace('<name>Strider (USA, B-Board 89624B-3)</name>', '<name>Strider (stock, mapper test core)</name>')
    (arcade / 'Strider (stock, mapper test core).mra').write_text(control)
    if a.core:
        (arcade / 'cores' / f'{a.rbf}_{a.date}.rbf').write_bytes(a.core.read_bytes())
    report = dict(files={n: dict(crc32=crc(b), sha256=hashlib.sha256(b).hexdigest(), bytes=len(b)) for n, b in out.items()}, blocks=counts, codes_moved=sum((c['codes_moved'] for c in counts)))
    (a.out / 'report.json').write_text(json.dumps(report, indent=1) + '\n')
    private_test.finalize(a.out, 'strider-mapper', rompaths=a.rom)
    for c in counts:
        print(c)
    print('codes moved to EX twins:', report['codes_moved'])
    return 0
if __name__ == '__main__':
    sys.exit(main())
