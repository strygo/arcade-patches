"""Settle Third Moon's opening camera before its native fade-in."""
import argparse
from copy import deepcopy
import json
from pathlib import Path
import subprocess
from asm_payload import command as assembly_command
import sys
import respawn_fix as R
from boss_voice_gate import inventory, sha
PREFIX = bytes.fromhex('3b7c004890d23b7c009f90d63b7c00008f743b7c00008f783b7c00008fb43b7c00408fb83b7c00008ff4')
SUFFIX = bytes.fromhex('8ff81b7c00018f6d1b7c00048fad1b7c00028fed')
OLD_Y = 29
BASE = 2054144
ASM = Path(__file__).resolve().parents[1] / 'asm/moon_start.s'

def model(image):
    signature = PREFIX + b';|' + OLD_Y.to_bytes(2, 'big') + SUFFIX
    if image.count(signature) != 1:
        raise ValueError('unique native Third Moon setup required')
    setup = image.index(signature)
    at = setup + 102
    if image[at:at + 6] != bytes.fromhex('3b7c00008c1a') or any((image[setup + off:setup + off + 2] != b'N\xb9' for off in (90, 96))):
        raise ValueError('native map draws and initial fade store differ')
    native = bytes.fromhex('3b7c00b890203b7c00c8901e3b7c006490223b7c006090243b7c000090183b7c05e090163b7c0700901a3b7c0000901c')
    if image.count(native) != 1:
        raise ValueError('native Moon first-frame camera setup differs')
    return dict(setup=setup, hook=at, constants=dict(X_LIMITS=98566144, Y_LIMITS=117440512, X_FOLLOW=13107384, Y_FOLLOW=6553696, **{name: int.from_bytes(image[setup + off + 2:setup + off + 6], 'big') for name, off in (('S2', 90), ('S3', 96))}))

def patch(image, bank, m, helper):
    at = m['hook']
    out = bytearray(image)
    b = bytearray(bank)
    off = BASE - 1048576
    if not helper or len(helper) > 2048 or bank[off:off + len(helper)] != b'\xff' * len(helper):
        raise ValueError('Moon opening helper allocation occupied or oversized')
    before = bytes(out[at:at + 6])
    out[at:at + 6] = R.jsr(BASE)
    b[off:off + len(helper)] = helper
    return (bytes(out), bytes(b), dict(setup=m['setup'], address=at, before=before.hex(), after=R.jsr(BASE).hex(), helper_at=BASE, helper_bytes=len(helper), helper_sha256=sha(helper)))

def audit(control, build):
    cm, old = inventory(control)
    meta, new = inventory(build)
    for machine, f in old.items():
        image = R.compose(f, R.SETS[machine])
        m = model(image)
        spec = meta['sets'][machine]['moon_start']
        p = new[machine]['strex_p6.bin']
        bank = bytes((p[i ^ 1] for i in range(len(p))))
        off = BASE - 1048576
        helper = bank[off:off + spec['change']['helper_bytes']]
        p = f['strex_p6.bin']
        oldbank = bytes((p[i ^ 1] for i in range(len(p))))
        changed, bank, report = patch(image, oldbank, m, helper)
        expected = dict(f, **R.decompose(changed, R.SETS[machine], {n: len(f[n]) for n, _, _ in R.SETS[machine]}))
        expected['strex_p6.bin'] = bytes((bank[i ^ 1] for i in range(len(bank))))
        if expected != new[machine] or spec['change'] != report:
            raise ValueError('unexpected Moon opening ROM change')
        if spec['source_files'] != cm['sets'][machine]['files']:
            raise ValueError('Moon opening source inventory differs')
    return meta

def main():
    if sys.argv[1:] == ['--self-test']:
        for invalid in (b'', PREFIX * 2):
            try:
                model(invalid)
            except ValueError:
                pass
            else:
                raise AssertionError('foreign setup accepted')
        for bank, helper in ((b'\x00' * 1048576, b'x'), (b'\xff' * 1048576, b'x' * 2049)):
            try:
                patch(b'\x00' * 100, bank, dict(hook=0, setup=0), helper)
            except ValueError:
                pass
            else:
                raise AssertionError('occupied or oversized allocation accepted')
        print('Moon opening guards PASS')
        return
    p = argparse.ArgumentParser(description=__doc__)
    for name in ('build', 'vasm', 'out'):
        p.add_argument('--' + name, type=Path, required=True)
    a = p.parse_args()
    meta, files = inventory(a.build)
    rep = deepcopy(meta)
    a.out.mkdir(parents=True, exist_ok=False)
    for machine, f in files.items():
        image = R.compose(f, R.SETS[machine])
        m = model(image)
        src = a.out / (machine + '.s')
        src.write_text(''.join((f'{k} equ ${v:X}\n' for k, v in m['constants'].items())) + ASM.read_text())
        binary = src.with_suffix('.bin')
        subprocess.run([*assembly_command(a.vasm), '-Fbin', '-m68000', '-quiet', '-o', str(binary), str(src)], check=True)
        p6 = f['strex_p6.bin']
        bank = bytes((p6[i ^ 1] for i in range(len(p6))))
        image, bank, report = patch(image, bank, m, binary.read_bytes())
        result = dict(f, **R.decompose(image, R.SETS[machine], {n: len(f[n]) for n, _, _ in R.SETS[machine]}))
        result['strex_p6.bin'] = bytes((bank[i ^ 1] for i in range(len(bank))))
        dest = a.out / machine
        dest.mkdir()
        for n, b in result.items():
            (dest / n).write_bytes(b)
        spec = rep['sets'][machine]
        spec['moon_start'] = dict(change=report, source_files=meta['sets'][machine]['files'], producer_sha256=sha(Path(__file__).read_bytes()), assembly_sha256=sha(ASM.read_bytes()))
        spec['files'] = {n: sha(b) for n, b in result.items()}
    (a.out / 'build.json').write_text(json.dumps(rep, indent=2) + '\n')
    audit(a.build, a.out)
    print('Third Moon opening camera settled; all other ROM bytes preserved')
if __name__ == '__main__':
    main()
