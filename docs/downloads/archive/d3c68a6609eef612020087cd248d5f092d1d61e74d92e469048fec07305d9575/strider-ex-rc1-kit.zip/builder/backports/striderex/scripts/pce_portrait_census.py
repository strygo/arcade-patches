"""P0.3 / W3b: find every PC Engine boss portrait."""
import argparse
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import numpy as np
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import pce_vdc as P
FINAL_CHECKPOINT = {0: 8, 1: 5, 2: 9, 3: 9, 4: 5, 6: 14}
GAMEPLAY_VPR = 5635

def schedule(end=8500):
    s = ['300-310:P1_START', '3700-3710:P1_START', '4000-4010:P1_START']
    s += [f'{f}-{f + 3}:P1_BUTTON2' for f in range(6250, end, 8)]
    s += [f'{f}-{f + 120}:P1_JOYSTICK_RIGHT' for f in range(6250, end, 480)]
    s += [f'{f}-{f + 60}:P1_JOYSTICK_LEFT' for f in range(6490, end, 480)]
    s += [f'{f}-{f + 12}:P1_BUTTON1' for f in range(6300, end, 90)]
    return ';'.join(s)

def capture(a):
    jobs = [(c, k) for c, n in FINAL_CHECKPOINT.items() for k in range(n + 1)]

    def one(job):
        c, k = job
        cmd = [sys.executable, str(HERE / 'run_pce_scene_capture.py'), '--outdir', str(a.workdir / f'c{c}_k{k}'), '--cdrom', str(a.cue), '--rompath', str(a.rompath), '--schedule', schedule(), '--window', '6000:8400:60', '--end', '8410', '--pce-start-stage', str(c), '--pce-first-checkpoint', str(k), '--pce-hold', 'timer', '--pce-hold', 'lives']
        return (job, subprocess.run(cmd, capture_output=True, text=True).returncode)
    with ThreadPoolExecutor(a.jobs) as ex:
        bad = [j for j, code in ex.map(one, jobs) if code]
    if bad:
        sys.exit(f'capture failed for {bad}')
    return 0

def candidates(path):
    d = P.load(path)
    if int(d['reg'][12]) != GAMEPLAY_VPR:
        return []
    groups = {}
    for i, top, left, img, attr in P.sprite_objects(d):
        groups.setdefault(attr & 15, []).append((i, top, left, img.shape))
    out = []
    for pal, g in groups.items():
        if min((i for i, *_ in g)) != 0 or len(g) < 6:
            continue
        y0, x0 = (min((t for _, t, _, _ in g)), min((l for _, _, l, _ in g)))
        y1, x1 = (max((t + s[0] for _, t, _, s in g)), max((l + s[1] for _, _, l, s in g)))
        w, h = (x1 - x0, y1 - y0)
        if w < 48 or h < 48 or y0 > 112:
            continue
        cov = np.zeros((h, w), bool)
        for _, t, l, s in g:
            cov[t - y0:t - y0 + s[0], l - x0:l - x0 + s[1]] = True
        if cov.mean() >= 0.85:
            out.append(dict(palette=pal, x=x0, y=y0, w=w, h=h, sprites=len(g)))
    return out

def scan(a):
    found = 0
    for run in sorted((p for d in a.capture for p in ([d] if (d / 'pce_scene_index.tsv').exists() else d.iterdir()) if (p / 'pce_scene_index.tsv').exists())):
        hits = {}
        for f in sorted(run.glob('pce_*_scene.vdc')):
            for c in candidates(f):
                key = (c['palette'], c['x'], c['y'], c['w'], c['h'])
                hits.setdefault(key, []).append(int(f.name.split('_')[1]))
        for (pal, x, y, w, h), frames in sorted(hits.items()):
            kind = 'portrait' if (w, h) == (80, 80) else 'large object'
            print(f'{run.name}\t{kind}\t{w}x{h} at ({x},{y}) palette {pal}\tframes {frames[0]}-{frames[-1]} ({len(frames)})')
            found += kind == 'portrait'
    print(f'{found} portrait sightings')
    return 0

def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest='cmd', required=True)
    c = sub.add_parser('capture')
    c.add_argument('--cue', type=Path, required=True)
    c.add_argument('--rompath', type=Path, required=True)
    c.add_argument('--workdir', type=Path, required=True)
    c.add_argument('--jobs', type=int, default=8)
    s = sub.add_parser('scan')
    s.add_argument('capture', type=Path, nargs='+', help='capture directories, or directories of them')
    a = p.parse_args()
    return capture(a) if a.cmd == 'capture' else scan(a)
if __name__ == '__main__':
    sys.exit(main())
