"""Strider EX HBMAME release sets: stage the members and write the driver block."""
import argparse
import hashlib
import json
import re
import subprocess
import sys
import zipfile
import zlib
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
import strider_mapper_probe as P
ROOT = Path(__file__).resolve().parents[3]
MANIFEST = ROOT / 'backports/striderex/manifests/hbmame_sets.json'
PARENT_DRIVER = 'src/hbmame/drivers/cps1.cpp'
EX_NAMES = {'strex_p6.bin': 'p6', 'strex_gfx.c25': 'c25', 'strex_gfx.c27': 'c27', 'strex_gfx.c29': 'c29', 'strex_gfx.c31': 'c31'}
LINE = re.compile('(?P<op>ROM_LOAD\\w*)\\(\\s*"(?P<name>[^"]+)",\\s*(?P<off>0x[0-9a-fA-F]+),\\s*(?P<size>0x[0-9a-fA-F]+),\\s*CRC\\((?P<crc>[0-9a-f]{8})\\)\\s*SHA1\\((?P<sha1>[0-9a-f]{40})\\)\\s*\\)')

def fail(msg):
    sys.exit('hbmame_set: ' + msg)

def manifest():
    return json.loads(MANIFEST.read_text())

def parent_block(hbmame, revision, name):
    if Path(hbmame).is_file():
        metadata = json.loads(Path(hbmame).read_text())
        if metadata.get('revision') != revision or metadata.get('license') != 'BSD-3-Clause':
            raise ValueError('HBMAME parent metadata revision/license differs')
        block = metadata['blocks'][name]
        if not block.startswith(f'ROM_START( {name} )') or not block.endswith('ROM_END'):
            raise ValueError('HBMAME parent declaration differs')
        return block
    text = subprocess.run(['git', '-C', str(hbmame), 'show', f'{revision}:{PARENT_DRIVER}'], capture_output=True, text=True, check=True).stdout
    start = text.index(f'ROM_START( {name} )')
    return text[start:text.index('ROM_END', start) + len('ROM_END')]

def set_files(rom_dir, name):
    """{MAME member name: bytes} of one stock set (directory or zip)."""
    d, z = (rom_dir / name, rom_dir / f'{name}.zip')
    if d.is_dir():
        return {p.name: p.read_bytes() for p in d.iterdir() if p.is_file()}
    if z.is_file():
        with zipfile.ZipFile(z) as f:
            return {i.filename: f.read(i) for i in f.infolist() if not i.is_dir()}
    fail(f'{name}: no stock set in {rom_dir}')

def crc(b):
    return f'{zlib.crc32(b):08x}'

def rom_line(op, name, off, size, data, note=''):
    return f'\t{op}( "{name}", {off}, {size}, CRC({crc(data)}) SHA1({hashlib.sha1(data).hexdigest()}) )' + (f' // {note}' if note else '')

def compose(spec, layout, block, stock, ex):
    """The set's members {HBMAME name: bytes} and its ROM_START block."""
    by_crc = {crc(b): (n, b) for n, b in stock.items()}
    replaced = {}
    for name, data in ex.items():
        if name in EX_NAMES:
            continue
        if name not in stock:
            fail(f"{name}: neither a {spec['parent_set']} member nor an EX file")
        if len(data) != len(stock[name]):
            fail(f'{name}: size changed')
        if data != stock[name]:
            replaced[crc(stock[name])] = data
    for name, suffix in EX_NAMES.items():
        if name not in ex:
            fail(f"{spec['parent_set']}: EX file {name} missing")
    members, out, prefix, used = ({}, [], spec['member_prefix'], set())
    for raw in block.splitlines():
        line = raw.rstrip()
        m = LINE.search(line)
        if line.startswith('ROM_START'):
            out.append(f"ROM_START( {spec['name']} ) // {spec['comment']}")
        elif 'ROM_REGION( 0x400000, "gfx", 0 )' in line:
            out.append(line.replace('0x400000', layout['gfx_region']))
        elif m and m['name'].endswith('.key'):
            key = P.cps1_key(P.STREX, spec['board'])
            members[spec['key']] = key
            out.append(f'''\tROM_LOAD( "{spec['key']}", 0x00, 0x80, CRC({crc(key)}) SHA1({hashlib.sha1(key).hexdigest()}) ) // {spec['board']} with the EX gfx bank''')
        elif m:
            if m['crc'] not in by_crc:
                fail(f"{m['name']}: no stock file with CRC {m['crc']}")
            data = replaced.get(m['crc'], by_crc[m['crc']][1])
            if m['crc'] in replaced:
                used.add(m['crc'])
            name = m['name'] if m['crc'] not in replaced else f"{prefix}.{m['name'].rsplit('.', 1)[1]}"
            if name in members and members[name] != data:
                fail(f'{name}: two different members')
            members[name] = data
            out.append(rom_line(m['op'], name, m['off'], m['size'], data, 'EX build' if m['crc'] in replaced else ''))
            if m['op'] == 'ROM_LOAD16_WORD_SWAP' and m['off'] == '0x80000':
                p6 = layout['program']
                name = f"{prefix}.{p6['suffix']}"
                members[name] = ex['strex_p6.bin']
                if len(members[name]) != int(p6['size'], 16):
                    fail('strex_p6.bin: wrong size')
                out.append(rom_line(p6['load'], name, p6['offset'], p6['size'], members[name], p6['role']))
        elif line.strip() == 'ROM_REGION( 0x8000, "stars", 0 )':
            for g in layout['gfx']:
                name = f"{prefix}.{g['suffix']}"
                members[name] = ex[f"strex_gfx.{g['suffix']}"]
                if len(members[name]) != int(g['size'], 16):
                    fail(f'{name}: wrong size')
                out.append(rom_line(layout['gfx_load'], name, g['offset'], g['size'], members[name], 'EX gfx bank'))
            out.extend(['', line])
        else:
            out.append(line)
    unused = set(replaced) - used
    if unused:
        fail(f'replaced members not in the parent block: {sorted(unused)}')
    return (members, '\n'.join(out))

def runtime_aliases(spec, block, members):
    """{parent name: bytes} for each member the build renamed: the set directory holds it under its parent's name"""
    out = {}
    for m in LINE.finditer(block):
        new = f"{spec['member_prefix']}.{m['name'].rsplit('.', 1)[1]}"
        if m['name'] not in members and (not m['name'].endswith('.key')) and (new in members):
            out[m['name']] = members[new]
    return out

def game_line(spec, date):
    desc = spec['description'].format(date=date)
    return f'''GAME( {date[:4]}, {spec['name']}, {spec['clone_of']}, {spec['machine']}, {spec['input']}, cps_state, init_cps1, ROT0, "strygo", "{desc}", MACHINE_SUPPORTS_SAVE )'''

def build(a):
    man = manifest()
    spec = next((s for s in man['sets'] if s['name'] == a.set), None) or fail(f'{a.set}: not in {MANIFEST.name}')
    if not re.fullmatch('\\d{4}-\\d{2}-\\d{2}', a.date):
        fail('--date is YYYY-MM-DD')
    out = a.out.resolve()
    if out.exists():
        fail('use a fresh output directory')
    stock = set_files(a.rom_dir, spec['parent_set'])
    ex_dir = a.ex_dir / spec['parent_set']
    ex = {p.name: p.read_bytes() for p in ex_dir.iterdir() if p.is_file()}
    block = parent_block(a.hbmame, man['hbmame_source_revision'], spec['parent_set'])
    members, text = compose(spec, man['ex_members'], block, stock, ex)
    d = out / spec['name']
    d.mkdir(parents=True)
    for name, data in members.items():
        (d / name).write_bytes(data)
    for name, data in runtime_aliases(spec, block, members).items():
        (d / name).write_bytes(data)
    (out / f"{spec['name']}.cpp").write_text(text + '\n\n' + game_line(spec, a.date) + '\n')
    print(text + '\n\n' + game_line(spec, a.date))
    return 0

def self_test(a):
    """Stock keys regenerate exactly; with stand-in EX files the stock members"""
    for board, want in (('CPS_B_01', '39065af5'), ('CPS_B_21_DEF', '8a7819d0')):
        got = crc(P.cps1_key(P.ST24M1, board))
        if got != want:
            fail(f'{board}: regenerated stock key CRC {got}, HBMAME has {want}')
    man = manifest()
    for spec in man['sets']:
        stock = set_files(a.rom_dir, spec['parent_set'])
        block = parent_block(a.hbmame, man['hbmame_source_revision'], spec['parent_set'])
        ex = {n: bytes([i]) * 1048576 for i, n in enumerate(EX_NAMES)}
        members, text = compose(spec, man['ex_members'], block, stock, ex)
        parent = {m['name']: m['crc'] for m in LINE.finditer(block) if not m['name'].endswith('.key')}
        for name, c in parent.items():
            if name not in members or crc(members[name]) != c:
                fail(f"{spec['name']}: stock member {name} not carried unchanged")
        if len(members) != len(parent) + 1 + 5 or '0x800000' not in text:
            fail(f"{spec['name']}: EX members or gfx region missing")
        victim = sorted((n for n in stock if len(stock[n]) >= 131072))[0]
        changed = dict(ex, **{victim: bytes([stock[victim][0] ^ 1]) + stock[victim][1:]})
        members2, text2 = compose(spec, man['ex_members'], block, stock, changed)
        renamed = [n for n in members2 if n not in members]
        if len(renamed) != 1 or not renamed[0].startswith(spec['member_prefix'] + '.') or 'EX build' not in text2:
            fail(f"{spec['name']}: a changed member ({victim}) was not renamed")
        for bad in ({k: v for k, v in ex.items() if k != 'strex_p6.bin'}, dict(ex, **{'unknown.bin': b'x'})):
            try:
                compose(spec, man['ex_members'], block, stock, bad)
            except SystemExit:
                continue
            fail(f"{spec['name']}: a bad EX input was accepted")
        print(spec['name'], 'ok:', len(members), 'members, renamed on change:', renamed[0])
    print('hbmame_set self-test passed')
    return 0

def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('command', nargs='?', choices=['build'])
    p.add_argument('--self-test', action='store_true')
    p.add_argument('--hbmame', type=Path, required=True, help='HBMAME git checkout (read at the pinned revision)')
    p.add_argument('--rom-dir', type=Path, required=True)
    p.add_argument('--ex-dir', type=Path)
    p.add_argument('--set')
    p.add_argument('--date')
    p.add_argument('--out', type=Path)
    a = p.parse_args()
    if a.self_test:
        return self_test(a)
    if a.command != 'build' or not (a.ex_dir and a.set and a.date and a.out):
        p.error('build needs --ex-dir, --set, --date and --out')
    return build(a)
if __name__ == '__main__':
    sys.exit(main())
