"""Read and guard the existing boss-scene records without a discarded listing."""
import struct
import argparse
from copy import deepcopy
import hashlib
import json
from pathlib import Path
IDS = ('stp_strongman', 'stp_chairman', 'sib_solo', 'sib_sisters', 'aerial_captain', 'moon_solo', 'desert_officer', 'desert_commander')
BASE = 1048576

def word(b, p):
    return struct.unpack_from('>H', b, p)[0]

def long(b, p):
    return struct.unpack_from('>I', b, p)[0]

def scenes(bank):
    result = []
    for index, lid in enumerate(IDS):
        needle = struct.pack('>HH', 184 + index, 192 + index)
        hits = [k - 2 for k in range(2, len(bank) - 60, 2) if bank[k:k + 4] == needle]
        if len(hits) != 1:
            raise ValueError('ambiguous boss record: ' + lid)
        at = hits[0]
        if not 100 <= word(bank, at) < 2000 or word(bank, at + 6) > 2:
            raise ValueError('invalid boss scene header')
        if not BASE <= long(bank, at + 48) < BASE + len(bank):
            raise ValueError('invalid mouth sequence')
        pages = []
        p = at + 52
        for _ in range(8):
            if p % 2 or not at < p < len(bank) - 44 or p in pages:
                raise ValueError('invalid linked boss page')
            pages.append(p)
            fade, hide, nxt = struct.unpack_from('>HHH', bank, p + 4)
            if not 20 <= fade < hide < nxt < 2000:
                raise ValueError('invalid boss page timing')
            if word(bank, p + 10) != 61440 or word(bank, p + 40) != 61440:
                raise ValueError('invalid boss UI palette')
            strips = word(bank, p + 42)
            if not 1 <= strips <= 2:
                raise ValueError('invalid reveal strip count')
            end = p + 44 + 12 * strips
            for _ in range(2):
                count = word(bank, end)
                if count > 256:
                    raise ValueError('invalid boss sprite count')
                end += 2 + 8 * count
            link = long(bank, p)
            if not link:
                break
            if link != end + BASE:
                raise ValueError('boss page link does not follow its entries')
            p = link - BASE
        else:
            raise ValueError('unbounded boss pages')
        result.append(dict(id=lid, at=at, pages=pages, total=word(bank, at)))
    table = b''.join((struct.pack('>I', BASE + r['at']) for r in result))
    if bank.count(table) != 1:
        raise ValueError('boss-scene table does not select every parsed record')
    return result

def black_strips(bank):
    b = bytearray(bank)
    changes = []
    for scene in scenes(bank):
        for page in scene['pages']:
            at = page + 10 + 14 * 2
            if word(b, at) != 61713:
                raise ValueError('reveal-strip black does not match the original contract')
            b[at:at + 2] = bytes.fromhex('f000')
            changes.append(dict(scene=scene['id'], page=BASE + page, address=BASE + at, before='f111', after='f000'))
    if sum((x != y for x, y in zip(bank, b))) != 2 * len(changes):
        raise ValueError('unexpected palette changes')
    return (bytes(b), changes)

def self_test():
    b = bytearray(b'\xff' * 2048)
    for k in range(8):
        at = 64 + k * 112
        struct.pack_into('>I', b, 4 * k, BASE + at)
        struct.pack_into('>4H', b, at, 200, 184 + k, 192 + k, 0)
        struct.pack_into('>I', b, at + 48, BASE + 32)
        p = at + 52
        struct.pack_into('>I3H', b, p, 0, 80, 97, 108)
        struct.pack_into('>16H', b, p + 10, *[61440] * 14 + [61713, 61440])
        struct.pack_into('>H', b, p + 42, 1)
        struct.pack_into('>HH', b, p + 56, 0, 0)
    out, changes = black_strips(b)
    assert len(changes) == 8 and len(scenes(out)) == 8
    for at in (0, 64 + 52 + 38):
        bad = bytearray(b)
        bad[at] ^= 1
        try:
            black_strips(bad)
        except ValueError:
            pass
        else:
            raise AssertionError('changed table or strip color accepted')
    print('Boss binary guards PASS: eight records; damaged table and palette rejected')

def build(a):
    meta = json.loads((a.build / 'build.json').read_text())
    rep = deepcopy(meta)
    a.out.mkdir(parents=True, exist_ok=False)
    changes = {}
    digest = lambda b: hashlib.sha256(b).hexdigest()
    for machine, spec in meta['sets'].items():
        target = a.out / machine
        target.mkdir()
        files = {n: (a.build / machine / n).read_bytes() for n in spec['files']}
        if any((digest(b) != spec['files'][n] for n, b in files.items())):
            raise ValueError('input member changed')
        p6 = files['strex_p6.bin']
        raw = bytes((p6[i ^ 1] for i in range(len(p6))))
        raw, changes[machine] = black_strips(raw)
        files['strex_p6.bin'] = bytes((raw[i ^ 1] for i in range(len(raw))))
        for name, data in files.items():
            (target / name).write_bytes(data)
        rep['sets'][machine]['files'] = {n: digest(b) for n, b in files.items()}
    rep['boss_reveal_black'] = dict(input_files={m: s['files'] for m, s in meta['sets'].items()}, changes=changes)
    (a.out / 'build.json').write_text(json.dumps(rep, indent=2) + '\n')
    print('Corrected boss reveal backgrounds:', {m: len(c) for m, c in changes.items()})

def main():
    import sys
    if sys.argv[1:] == ['--self-test']:
        return self_test()
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--build', type=Path, required=True)
    p.add_argument('--out', type=Path, required=True)
    build(p.parse_args())
if __name__ == '__main__':
    main()
