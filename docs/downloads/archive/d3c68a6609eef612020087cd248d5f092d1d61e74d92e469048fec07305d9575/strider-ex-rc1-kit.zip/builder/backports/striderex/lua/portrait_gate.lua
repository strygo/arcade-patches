-- Strider EX portrait gate probe (scripts/portrait_gate.py): the arcade debug
-- start (lua/arcade_debug_start.lua, loaded unchanged: DIPs, coin, START,
-- STREX_INPUTS) plus, every frame:
--   frame  pt_on pt_id pt_left pt_tail  stage area lives  watch  ramsum  sprites
-- and, each time the game writes its OBJ base shadow (0xFF0C9A: the end of
-- its frame's work, the same logical point in every variant whatever the
-- cycle count), a sync row "k frame syncsum" (<out>_sync.tsv).
-- ramsum/syncsum: a checksum of work RAM 0xFF0000-0xFFFFFF without the task and
-- supervisor stacks (0xFF0100-0xFF0BEF: dead stack bytes below a stack
-- pointer differ when a call goes through the EX bank), the sprite builder's
-- budget counters (0xFF0C8C-0xFF0C97: the portrait takes one entry), the
-- portrait's own variables (0xFFF940-0xFFF97F) and the 16 task-state bytes
-- (0xFF0000 + 16n: 4 = ready, 8 = being dispatched, which depends on where
-- the dispatcher loop is when the frame ends, not on game state; the rest of
-- each task entry, its saved PC, SR and stack, is compared). The frame_done
-- sum can catch a frame's work in flight (a heavy frame still running at
-- the VBlank), so the gate compares the sync sums: same frames, same sums.
-- sprites: entries the game's last list used (256 - 0xFF0C8C).
-- watch: the byte at STREX_GATE_WATCH (the encounter's own effect).
-- Screenshots on the frames listed in STREX_GATE_SHOTS ("a-b,c,..."); full
-- RAM dumps on STREX_GATE_DUMPS frames. STREX_POKES as portrait_arcade_probe.lua.
local m=manager.machine
local sp=m.devices[':maincpu'].spaces['program']
local screen=m.screens[':screen']
local out_prefix=assert(os.getenv('STREX_GATE_OUT'))
dofile(assert(os.getenv('STREX_DEBUG_START')))
local watch=tonumber(os.getenv('STREX_GATE_WATCH') or '0')
local shots,dumps={}, {}
for a,b in string.gmatch(os.getenv('STREX_GATE_SHOTS') or '','(%d+)%-?(%d*)') do
 local lo=tonumber(a);local hi=tonumber(b) or lo
 for k=lo,hi do shots[k]=true end
end
for a in string.gmatch(os.getenv('STREX_GATE_DUMPS') or '','%d+') do dumps[tonumber(a)]=true end
local pokes={}
for fr,addr,val in string.gmatch(os.getenv('STREX_POKES') or '','(%d+):([%x]+)=([%x]+)') do
 pokes[#pokes+1]={tonumber(fr),tonumber(addr,16),tonumber(val,16)}
end
local log=assert(io.open(out_prefix..'_gate.tsv','w'))
local ranges={{0xff0bf0,0xff0c8b},{0xff0c98,0xfff93f},{0xfff980,0xffffff}}
local f=0
local function ramsum()
 local h=0
 for a=0xff0000,0xff00ff,4 do
  local v=sp:read_u32(a)
  if a&15==0 then v=v&0x00ffffff end
  h=(h*31+v)&0xffffffff
 end
 for _,r in ipairs(ranges) do
  for a=r[1],r[2]-3,4 do h=(h*31+sp:read_u32(a))&0xffffffff end
 end
 return h
end
local sync=assert(io.open(out_prefix..'_sync.tsv','w'))
local k=0
_G.strex_gate_sync=sp:install_write_tap(0xff0c9a,0xff0c9b,'strex_gate_sync',function(off,data,mask)
 k=k+1
 sync:write(string.format('%d\t%d\t%08x\n',k,f+1,ramsum()))
end)
emu.register_frame_done(function()
 f=f+1
 for _,pk in ipairs(pokes) do if pk[1]==f then sp:write_u16(pk[2],pk[3]) end end
 local h=ramsum()
 log:write(string.format('%d\t%04x\t%d\t%d\t%d\t%d\t%d\t%d\t%02x\t%08x\t%d\n',f,sp:read_u16(0xfff940),
  sp:read_u16(0xfff942),sp:read_u16(0xfff94c),sp:read_u16(0xfff94e),sp:read_u8(0xff0cb2),sp:read_u8(0xff0cce),
  sp:read_u8(0xff0ca8),watch~=0 and sp:read_u8(watch) or 0,h,0x100-sp:read_u16(0xff0c8c)))
 if shots[f] then screen:snapshot(string.format('%s_%05d.png',out_prefix,f)) end
 if dumps[f] then
  local d=assert(io.open(string.format('%s_ram_%05d.bin',out_prefix,f),'wb'))
  local t={}
  for a=0xff0000,0xffffff,4 do t[#t+1]=string.pack('>I4',sp:read_u32(a)) end
  d:write(table.concat(t));d:close()
 end
 log:flush()
 sync:flush()
end)
