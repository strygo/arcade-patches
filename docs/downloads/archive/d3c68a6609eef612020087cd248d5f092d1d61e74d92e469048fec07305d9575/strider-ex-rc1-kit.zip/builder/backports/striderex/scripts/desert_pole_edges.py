"""Bring the five valve-pole contacts 18 arcade pixels in toward their stems."""
import argparse
from copy import deepcopy
import json
from pathlib import Path
import sys
import numpy as np
import desert_grip_fix as F
import desert_slopes as S
import desert_gate as G
import boss_voice_gate as V
POLES = [(166 + c) * 24 for c in (68, 76, 84, 92, 100)]
TOP, BOTTOM, INSET = (400, 496, 18)
BASE = 1818624

def overrides(img, bank):
    read = S.reader(img, bank)
    lr = S.layer_record(img, 5, 1)
    grid = read(S.be32(read(lr + 2, 4)), 256)
    sec = S.be32(read(lr + 6, 4))
    sets = F.DX.collision_sets(img)
    changed = {}

    def profile(cx, cy):
        key = (cx, cy)
        if key not in changed:
            wr = 63 - cy
            e = read(sec + grid[wr // 8 * 32 + cx // 12] * 384 + (wr % 8 * 12 + cx % 12) * 4, 4)
            co = S.be16(e) & 16383
            fl = e[3] >> 5 & 3
            rows = {}
            for k in 'CD':
                pg, ty, _, _, rec = sets[k]
                page = read(pg + (co >> 8) + 8 * fl)[0]
                v = read(ty + (page - 1) * 256 + (co & 255))[0] if page else 0
                rows[k] = list(read(rec + (v - 32) * 33 + 1, 32)) if v >= 32 else [v] * 32
            changed[key] = rows
        return changed[key]
    for left in POLES:
        right = left + 72
        for y in range(TOP, BOTTOM):
            cy, i = (y // 32, 31 - (y & 31))
            for cx in range(left // 32, (right - 1) // 32 + 1):
                p = profile(cx, cy)
                for k in 'CD':
                    v = p[k][i]
                    face = cx * 32 + (v if k == 'C' else 31 - v)
                    if v and left <= face < right:
                        p[k][i] = 0
            nl, nr = (left + INSET, right - INSET - 1)
            profile(nl // 32, cy)['D'][i] = max(31 - (nl & 31), 1)
            profile(nr // 32, cy)['C'][i] = max(nr & 31, 1)
    return changed

def main():
    if sys.argv[1:] == ['--self-test']:
        assert POLES == [5616, 5808, 6000, 6192, 6384]
        assert all((x + 18 < x + 72 - 18 for x in POLES))
        print('Pole contact self-test PASS: five source-aligned posts; 36-pixel stem width')
        return
    p = argparse.ArgumentParser(description=__doc__)
    for n in ('build', 'rom-dir', 'out'):
        p.add_argument('--' + n, type=Path, required=True)
    a = p.parse_args()
    meta, files = V.inventory(a.build)
    rep = deepcopy(meta)
    stock = F.DX.program_images(a.rom_dir)
    a.out.mkdir(parents=True, exist_ok=False)
    for m, f in files.items():
        img, bank = G.images(a.build.resolve(), a.rom_dir.resolve(), m)
        walls = overrides(img, bank)
        new, spec = F.patch(f, m, np.zeros((2048, 12288), bool), stock[m], map_index=1, allocation_base=BASE, merge=True, wall_overrides=walls)
        if spec['allocation_size'] > 40960:
            raise ValueError('pole allocation reaches its reservation end')
        d = a.out / m
        d.mkdir()
        for n, b in new.items():
            (d / n).write_bytes(b)
        rep['sets'][m]['files'] = {n: V.sha(b) for n, b in new.items()}
        rep['sets'][m]['pole_edges'] = dict(spec, source_files=meta['sets'][m]['files'], logical_left=POLES, contact_inset=INSET, y_down=[TOP, BOTTOM], only_wall_profiles=True)
        print(m, 'pole profiles', spec['tiles'], 'cells', spec['new_classes'], 'new classes', flush=True)
    (a.out / 'build.json').write_text(json.dumps(rep, indent=2) + '\n')
if __name__ == '__main__':
    main()
