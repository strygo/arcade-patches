"""Qualify valve-post contacts with unchanged native climbing in both regions."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import csv
import json
from pathlib import Path
import numpy as np
import desert_gate as G
import desert_grip_fix as F
import desert_pole_edges as P
import desert_slopes as S
from boss_voice_gate import inventory, sha

def gate(a):
    work = a.workdir.resolve()
    work.mkdir(parents=True, exist_ok=a.reuse)
    metas = {}
    sets = {}
    rt = json.loads((a.runtime / 'runtime.json').read_text())
    binary = Path(rt['binary'])
    if sha(binary.read_bytes()) != rt['binary_sha256']:
        raise ValueError('runtime changed')
    for label, path in (('control', a.control), ('candidate', a.build)):
        meta, files = inventory(path)
        metas[label] = meta
        for m, f in files.items():
            name = 'striderus01' if m == 'striderua' else 'striderjs01'
            sets[label, m] = (G.stage_sets(path.resolve(), name, a.hbmame, a.rom_dir.resolve(), work / 'sets' / (label + '_' + m)), name)
    for m in ('striderua', 'striderjr'):
        before, bb = G.images(a.control.resolve(), a.rom_dir.resolve(), m)
        after, ab = G.images(a.build.resolve(), a.rom_dir.resolve(), m)
        if before[:524288] != after[:524288]:
            raise ValueError('native executable changed')
        for k in range(7):
            if S.Floor(before, bb, S.layer_record(before, 5, k)).cells != S.Floor(after, ab, S.layer_record(after, 5, k)).cells:
                raise ValueError('pole repair changes a map floor')
        walls = P.overrides(before, bb)
        oldfiles = {n: (a.control / m / n).read_bytes() for n in metas['control']['sets'][m]['files']}
        expected, _ = F.patch(oldfiles, m, np.zeros((2048, 12288), bool), F.DX.program_images(a.rom_dir)[m], map_index=1, allocation_base=P.BASE, merge=True, wall_overrides=walls)
        if {n: sha(b) for n, b in expected.items()} != metas['candidate']['sets'][m]['files']:
            raise ValueError('candidate has unrelated changes')

    def run(job):
        label, m = job
        roms, name = sets[label, m]
        out = work / (label + '_' + m)
        n = 2350
        expected_x = 6176 if label == 'control' else 6194
        if not a.reuse or not (out / 'motion.tsv').exists():
            env = dict(G.debug_env(5, 3, n, inputs=False), MOTION='1', CLIMB='1', VIDEO_DUMPS='2300', WARP=f'2100:{expected_x},1600', STREX_INPUTS='450-2350:P1_JOYSTICK_RIGHT;1800-2099@100/14:P1_BUTTON2', SHOTS='2200-2300@100')
            G.run(binary, roms, name, out, env, n)
        rows = list(csv.DictReader((out / 'motion.tsv').open(), delimiter='\t'))
        hold = [r for r in rows if 2200 <= int(r['frame']) <= 2350]
        if (int(rows[2099]['hx']), int(rows[2099]['st'])) != (expected_x, 4):
            raise ValueError('native approach did not establish the expected contact')
        if any(((int(r['hx']), int(r['hy']), int(r['st'])) != (expected_x, 1631, 4) for r in hold)):
            raise ValueError('native contact or climb height differs')
        earlier = [r for r in rows if 2101 <= int(r['frame']) < 2200 and int(r['st']) == 4 and (int(r['hx']) == expected_x)]
        if len({r['hy'] for r in earlier}) < 24:
            raise ValueError('fixture did not actually climb the post')
        staged = roms / name
        if sha(next(staged.glob('*.p6')).read_bytes()) != metas[label]['sets'][m]['files']['strex_p6.bin']:
            raise ValueError('wrong staged bank')
        return dict(label=label, machine=m, contact_x=expected_x, top_y=1631, hold_frames=len(hold), actual_climb_positions=len({r['hy'] for r in earlier}), motion_sha256=sha((out / 'motion.tsv').read_bytes()), passed=True)
    with ThreadPoolExecutor(2) as ex:
        results = list(ex.map(run, [(l, m) for l in ('control', 'candidate') for m in ('striderua', 'striderjr')]))
    report = dict(schema='striderex-pole-contact-gate/1', passed=True, shift_toward_art_pixels=18, input_files={k: {m: s['files'] for m, s in v['sets'].items()} for k, v in metas.items()}, native_code_and_all_seven_floors_unchanged=True, results=results, runtime=rt['binary_sha256'], hardware_review_granted=False)
    a.receipt.write_text(json.dumps(report, indent=2) + '\n')
    print('PASS: both native climbs move 18 pixels toward the stem; same height and stable holds; old floating position reproduced')

def main():
    p = argparse.ArgumentParser(description=__doc__)
    for n in ('control', 'build', 'runtime', 'hbmame', 'rom-dir', 'workdir', 'receipt'):
        p.add_argument('--' + n, type=Path, required=True)
    p.add_argument('--reuse', action='store_true')
    gate(p.parse_args())
if __name__ == '__main__':
    main()
