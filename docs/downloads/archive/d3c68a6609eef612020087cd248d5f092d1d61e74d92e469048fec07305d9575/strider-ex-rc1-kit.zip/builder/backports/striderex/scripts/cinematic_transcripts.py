"""Japanese transcripts of the PC Engine Strider cinematics (P0.9), plus a"""
import argparse
import datetime
import hashlib
import json
import subprocess
import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[3]
TRANSCRIPTS = ROOT / 'backports/striderex/manifests/pce_cinematic_transcripts.json'
WITNESS = ROOT / 'backports/striderex/manifests/pce_cinematic_google_witness.json'
TRACKS = {21: 'Prologue', 22: 'St. Petersburg briefing', 23: 'Desert introduction', 24: 'Siberia briefing', 25: 'Aerial Battleship briefing', 26: 'Amazon briefing', 27: 'Flight to the Third Moon', 28: "Meio's welcome"}
MODEL = 'large-v3'
LOW_WORD_PROB = 0.6

def cue_tracks(cue):
    """{track: (bin path, INDEX 01 seconds)} for audio tracks."""
    out, cur, name = ({}, None, None)
    for line in Path(cue).read_text().splitlines():
        w = line.split()
        if not w:
            continue
        if w[0] == 'FILE':
            name = line.split('"')[1]
        elif w[0] == 'TRACK':
            cur = int(w[1])
            out[cur] = [Path(cue).parent / name, 0.0, w[2]]
        elif w[0] == 'INDEX' and w[1] == '01':
            mm, ss, ff = map(int, w[2].split(':'))
            out[cur][1] = mm * 60 + ss + ff / 75
    return {t: (p, i) for t, (p, i, kind) in out.items() if kind == 'AUDIO'}

def transcribe(a):
    from faster_whisper import WhisperModel
    import faster_whisper
    tracks = cue_tracks(a.cue)
    a.workdir.mkdir(parents=True, exist_ok=True)
    model = WhisperModel(MODEL, device='cpu', compute_type='int8')
    rows = []
    for t, title in TRACKS.items():
        bin_path, index01 = tracks[t]
        wav = a.workdir / f'tr{t:02d}.wav'
        subprocess.run(['ffmpeg', '-loglevel', 'error', '-y', '-f', 's16le', '-ar', '44100', '-ac', '2', '-i', str(bin_path), '-ss', f'{index01:.6f}', '-ac', '1', '-ar', '16000', str(wav)], check=True)
        segs, info = model.transcribe(str(wav), language='ja', beam_size=5, temperature=0.0, vad_filter=True, word_timestamps=True, condition_on_previous_text=False)
        segments = []
        for s in segs:
            words = [dict(w=x.word, start=round(x.start, 2), end=round(x.end, 2), p=round(x.probability, 3)) for x in s.words or []]
            segments.append(dict(start=round(s.start, 2), end=round(s.end, 2), text=s.text.strip(), avg_logprob=round(s.avg_logprob, 3), no_speech_prob=round(s.no_speech_prob, 3), uncertain=[w['w'] for w in words if w['p'] < LOW_WORD_PROB], words=words, speaker=None))
        rows.append(dict(track=t, title=title, index01_seconds=round(index01, 4), bin_sha256=hashlib.sha256(bin_path.read_bytes()).hexdigest(), segments=segments))
        print(f'tr{t:02d} {title}: {len(segments)} segments')
        for s in segments:
            print(f"   {s['start']:6.2f}-{s['end']:6.2f} {s['text']}  {('?' + ' '.join(s['uncertain']) if s['uncertain'] else '')}")
    snap = sorted((Path.home() / '.cache/huggingface/hub/models--Systran--faster-whisper-large-v3/snapshots').glob('*'))
    TRANSCRIPTS.write_text(json.dumps(dict(status='ASR draft: Japanese source for review; not verified, not approved', asr=dict(engine='faster-whisper', version=faster_whisper.__version__, model=f'Systran/faster-whisper-{MODEL}', snapshot=snap[-1].name if snap else None, compute_type='int8', beam_size=5, temperature=0.0, vad=True, low_word_probability=LOW_WORD_PROB), time_base='seconds from each track INDEX 01 (CD_PLAY start)', tracks=rows), ensure_ascii=False, indent=1) + '\n')
    return 0

def witness(a):
    sys.path.insert(0, str(ROOT / 'translations/vhunt2/scripts'))
    import psx_google_witness as G
    data = json.loads(TRANSCRIPTS.read_text())
    texts = [(t['track'], i, s['text']) for t in data['tracks'] for i, s in enumerate(t['segments'])]
    project, token = G.service_account_token(a.credentials)
    english = G.translate(project, token, [x[2] for x in texts])
    rows = [dict(track=t, segment=i, ja=ja, en=en) for (t, i, ja), en in zip(texts, english)]
    WITNESS.write_text(json.dumps(dict(status='Google Cloud Translation v3 witness: independent literal reading, never release prose', provider='Google Cloud Translation v3 translateText (ja -> en, text/plain)', retrieved=datetime.date.today().isoformat(), transcripts_sha256=hashlib.sha256(TRANSCRIPTS.read_bytes()).hexdigest(), rows=rows), ensure_ascii=False, indent=1) + '\n')
    for r in rows:
        print(f"tr{r['track']} #{r['segment']}: {r['en']}")
    return 0

def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('command', choices=['transcribe', 'witness'])
    p.add_argument('--cue', type=Path, help='restored PCE disc cue sheet (transcribe)')
    p.add_argument('--workdir', type=Path, help='scratch for decoded audio (transcribe)')
    p.add_argument('--credentials', type=Path, help='Google service-account JSON outside the repo (witness)')
    a = p.parse_args()
    if a.command == 'transcribe':
        if not (a.cue and a.workdir):
            p.error('transcribe needs --cue and --workdir')
        return transcribe(a)
    if not a.credentials:
        p.error('witness needs --credentials')
    return witness(a)
if __name__ == '__main__':
    sys.exit(main())
