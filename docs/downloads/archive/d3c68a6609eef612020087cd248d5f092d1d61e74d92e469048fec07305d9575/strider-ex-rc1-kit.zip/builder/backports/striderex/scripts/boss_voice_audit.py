"""Independently bound the native boss voice ROM changes against their control."""
import argparse
import hashlib
import json
from pathlib import Path
import boss_scene as BS
import boss_scene_binary as BB
from boss_voice_gate import inventory
import pce_sfx as PS

def sha(b):
    return hashlib.sha256(b).hexdigest()

def audit(a):
    old_meta, old = inventory(a.control)
    meta, new = inventory(a.build)
    BS.check_voice_cues()
    rows = []
    retired = set(range(140, 147)) | set(range(150, 154))
    for m, s in meta['sets'].items():
        spec = s['boss_voice']
        sound = '09.12b' if m == 'striderua' else 'sth_09.12a'
        allowed = {'strex_p6.bin', sound, *PS.SAMPLE_MEMBERS[m]}
        if set(old[m]) != set(new[m]) or any((old[m][n] != new[m][n] for n in old[m] if n not in allowed)):
            raise ValueError('ROM changes outside the voice allocation')
        raw = bytearray((new[m]['strex_p6.bin'][i ^ 1] for i in range(1048576)))
        at = spec['selector_at'] - 1048576
        start = spec['helper_at'] - 1048576
        n = spec['helper_bytes']
        before = bytes.fromhex(spec['selector_before'])
        expected = bytes.fromhex('4eb9') + spec['helper_at'].to_bytes(4, 'big') + bytes.fromhex('4e71') * 6
        if raw[at:at + len(before)] != expected or sha(raw[start:start + n]) != spec['helper_sha256']:
            raise ValueError('voice helper or selector has changed')
        raw[at:at + len(before)] = before
        raw[start:start + n] = b'\xff' * n
        if bytes((raw[i ^ 1] for i in range(len(raw)))) != old[m]['strex_p6.bin']:
            raise ValueError('extra bank changes outside the voice call and helper')
        z = bytearray(new[m][sound])
        o = b''.join((new[m][k] for k in PS.SAMPLE_MEMBERS[m]))
        old_oki = b''.join((old[m][k] for k in PS.SAMPLE_MEMBERS[m]))
        ranges = ((38656, 125952), (135168, 203776))
        sample_diffs = [i for i, (x, y) in enumerate(zip(old_oki, o)) if x != y]
        if any((not (512 <= i < 576 or any((lo <= i < hi for lo, hi in ranges))) for i in sample_diffs)):
            raise ValueError('sample changes outside old intro data and English headers')
        for row in spec['native_phrases']:
            z[PS.Z80_TABLE + row['phrase']] = row['old_voice_byte']
        if bytes(z) != old[m][sound]:
            raise ValueError('sound code or music changed')
        protected = []
        for cue in range(129, 157):
            if cue in retired:
                continue
            h1, v1 = PS.driver_play(old[m][sound], old_oki, cue)
            h2, v2 = PS.driver_play(new[m][sound], o, cue)
            lo = int.from_bytes(h1[:3], 'big')
            hi = int.from_bytes(h1[3:6], 'big')
            if (h1, v1) != (h2, v2) or old_oki[lo:hi + 1] != o[lo:hi + 1]:
                raise ValueError('live stock phrase changed')
            protected.append(hex(cue))
        for cue in range(176, 180):
            h1, v1 = PS.driver_play(old[m][sound], old_oki, cue)
            h2, v2 = PS.driver_play(new[m][sound], o, cue)
            lo = int.from_bytes(h1[:3], 'big')
            hi = int.from_bytes(h1[3:6], 'big')
            if (h1, v1) != (h2, v2) or old_oki[lo:hi + 1] != o[lo:hi + 1]:
                raise ValueError('PCE effect changed')
        if BB.scenes(raw) != BB.scenes(bytes((old[m]['strex_p6.bin'][i ^ 1] for i in range(1048576)))):
            raise ValueError('boss text/page timing changed')
        rows.append(dict(machine=m, passed=True, protected_stock_cues=protected, pce_effects_unchanged=True, original_scene_and_page_records_unchanged=True, all_graphics_and_other_program_roms_unchanged=True, original_sound_code_and_fm_music_unchanged=True, sample_changed_bytes=len(sample_diffs), reclaimed_intro_ranges=[list(x) for x in ranges], selector_at=spec['selector_at'], helper_at=spec['helper_at'], helper_bytes=n))
    receipt = dict(schema='striderex-native-boss-voice-audit/1', passed=True, results=rows, retired_intro_commands=[hex(x) for x in sorted(retired)], input_files={k: {m: s['files'] for m, s in v['sets'].items()} for k, v in (('control', old_meta), ('candidate', meta))}, hardware_review_granted=False)
    a.receipt.write_text(json.dumps(receipt, indent=2) + '\n')
    print('PASS: exact inverse of voice helper; native changes bounded; all live stock phrases, PCE effects and FM preserved')

def main():
    p = argparse.ArgumentParser(description=__doc__)
    for n in ('control', 'build', 'receipt'):
        p.add_argument('--' + n, type=Path, required=True)
    audit(p.parse_args())
if __name__ == '__main__':
    main()
