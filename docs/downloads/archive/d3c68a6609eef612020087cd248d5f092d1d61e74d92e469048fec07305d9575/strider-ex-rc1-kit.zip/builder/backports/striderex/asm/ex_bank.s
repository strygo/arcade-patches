; Strider EX bank (CPU 0x100000-0x1FFFFF): the in-game cinematic player.
;
; Two stock-ROM changes reach it (scripts/build_ex.py makes them):
;   - the level-2 (VBlank) autovector 0x68 -> ex_vbl. Outside a cinematic it
;     costs one test and a jump (about 30 cycles a frame) on the way to the
;     stock handler 0x4D2;
;   - the stage-intro flag store (move.b #1,-$7346(a5): USA 0x911A, Japan
;     0x9090, just before the intro setup) -> jsr cine_hook.
;
; cine_hook plays the stage's cinematics (stage_cines), then does the
; replaced store and returns into the stock intro. While one plays, ex_vbl
; runs the player instead of the game's VBlank, so the game's tasks, timers
; and register shadows stand still; the hook waits in its task for the end.
; Memory (MEASURED, PHASE0_FINDINGS.md "Cinematics in the game"): at the hook
; the game needs only the palettes 0x914000-0x9157FF from graphics RAM; the
; hook saves them to 0xFFA400 and restores them, and the player's ring and
; variables live in work RAM 0xFFC800-0xFFFFFF, which the game leaves alone.
; On exit the registers the game sets only at boot are put back (SCROLL1-3
; bases); the row-scroll base and the group-0 priority mask, which the game
; never writes, go back to 0. The game's VBlank restores the rest.
;
; Sound (the game's protocol, 0x4936): a command on odd frames, 0xFF on
; even frames. The cue is sent only when the EX flag word says a CPS+ pack
; is loaded (FLAGS_AND_LANGUAGE.md); START skips the cinematic and, with a
; pack, fades its track out (play .skip). Without a pack a briefing sends its
; native score instead (nopack_cues), faded (0xFB) over the final 100 frames
; of a stage's last scene and stopped (0xF1) at its end or a START skip.
;
; The flag word (L5): 'STRIDER-EX', version byte, padding, flag word in the
; last 16 bytes of the bank; bit 0 = PACK, bits 1-2 = VOICE (0 region).
; The bank is the same for both regions; build_ex.py writes the scene table
; and the stage lists (stage_lists.inc) and the flag block.

OBJ     equ $900000                     ; sprite list A
OBJ_B   equ $900800                     ; sprite list B (191 entries + end mark, below the rows)
BACKDROP equ $BFF                       ; the backdrop pen: what the screen shows with every layer off
ROWS    equ $900E00                     ; row scroll: block 0x900800, offset 0x300 words
SCR3    equ $910000
CPSA    equ $800100
CPSB    equ $800140
LAYER   equ CPSB+$26
SOUND   equ $800180
FADE_CMD equ $FC                        ; a START skip's fade (play .skip): the pack maps this control to
                                        ; fade_out (30 frames to silence, then the track stops; the header's
                                        ; fade law; manifests/ex_pack_cues.json skip_fade). The Z80 ignores it
                                        ; (its 0xF0 table sends 0xFC-0xFF to a bare ret, PHASE0_FINDINGS.md P0.7)
IN0     equ $800018                     ; system inputs, active low; bit 4 = START1 (the game reads it at 0x662)
STOCK_VBL equ $4D2
INTRO_FLAG equ -$7346                   ; (a5)
STAGE   equ -$734E                      ; (a5) internal stage number

PALS    equ $914000                     ; the palettes the game keeps across the hook
PALS_LONGS equ $1800/4
SAVE    equ $FFA400
RING    equ $FFC800                     ; RSIZE bytes + room for a wrapped record
RSIZE   equ $2000
RMASK   equ RSIZE-1
VARS    equ $FFF900
FRAMES  equ VARS+$00                    ; long: records played
NP_READING equ 1                        ; scene_core's fixed-size final-page pause entry
LZ_SRC  equ VARS+$04
LZ_W    equ VARS+$08
LZ_R    equ VARS+$0A
CUE_NEXT equ VARS+$0C                   ; word: the scene's cue, sent at its first frame (scene_core.s op_cue)
ENDED   equ VARS+$10
PALBASE equ VARS+$12
ACTIVE  equ VARS+$14                    ; word: ON while a cinematic plays (ex_vbl); any other value = off
ON      equ $C1E5                       ; (work RAM is not cleared before the first VBlank)
HOLD    equ $C1E6                       ; ACTIVE: between and before scenes, neither the player nor the game
CARD    equ $C1E7                       ; ACTIVE: the EX title card after the prologue (as HOLD for ex_vbl)
WAIT    equ $C1E8                       ; ACTIVE: hold_black, until the next VBlank turns the layers off
    ifd BOSS_SCENE
BS_ON   equ $FFF9C0                     ; word: BS_MAGIC while a boss scene plays (build_ex.py, the default;
BS_MAGIC equ $B055                      ; boss_scene.s); ACTIVE is HOLD then, and .hold runs its VBlank
BS_DONE equ $FFF9E8                     ; byte: the boss scenes played on this stage, a bit each (boss_scene.s)
    endc
CUE     equ VARS+$16                    ; word: command to send, 0 = none
TICK    equ VARS+$18                    ; word: frame parity for the sound protocol
HELD    equ VARS+$1A                    ; byte: START was down last frame (a skip needs a new press)
OBJ_BACK equ VARS+$1C                   ; long: the sprite list being built (scene_core.s obj_flip)
SPR_NEW equ VARS+$20                    ; word: the list changed since the last flip
HOLDTICK equ VARS+$22                   ; word: VBlanks while held (HOLD, CARD)
CARD_PTR equ VARS+$38                   ; long: the card's next caption schedule entry (0 = none)
CINE_STAGE equ VARS+$3C                 ; byte: 1 + the stage whose cinematics last played (stage_hook)
S1_FRONT equ $FFF9B0                   ; word: the SCROLL1 base shown (scene_core.s op_flip, cine_setup)
S2_FRONT equ $FFF9B2                   ; word: the SCROLL2 base shown
OLD_S1  equ $FFF9B4                    ; word: a continued scene's last SCROLL1 base, until cleared (0: none)
OLD_S2  equ $FFF9B6                    ; word: ... SCROLL2 base (play, clear_old)
OLD_PAL equ $FFF9B8                    ; word: ... palette base
CONT_NEXT equ $FFF9BA                  ; byte: the list's next scene continues this one (play)
NP_CUE  equ $FFF9BC                    ; word: without a pack, the arcade intro tune the scene started (nopack_cues),
                                       ; until its stop at the scene's end (play .end); 0 = none (cine_hook clears it)
NP_STOP equ $F1                        ; the stock music stop (the driver's music clear; FM and OKI effects run on),
                                       ; as the boss scenes send it without a pack
INTRO_STATE equ -$7324                  ; (a5) the intro task's state: 0 = a new stage (6: in play, a respawn)
LAYER_BASE equ $3188
IC_LAYER equ -$738C                     ; (a5) the layer-control shadow (the game's VBlank writes it)
IC_SLEEP equ $7DE                       ; the stock task sleep: d0 frames (both regions)
IC_QUEUE equ $E10                       ; the stock video command queue: d0 = command
IC_CLRSPR equ $B3A                      ; the stock clear of both sprite lists
; The stage intros (intro_cut; build_ex.py INTRO_CUT checks every address against the stock program):
; GLOBE, the stock intro setup, the wizard (the Grandmaster with the Earth, rising over the stars, his
; laugh); INTRO_SKIP, the stock dialogue's P1 button 1 path, shared by stages 1-4; SND_RESET and
; SND_STOP, the setters of the sound controls 0xF0 and 0xF7 that path sends.
    ifne REGION_EN
GLOBE   equ $552C
INTRO_SKIP equ $9626
SND_RESET equ $49A2
SND_STOP equ $49A8
    else
GLOBE   equ $553A
INTRO_SKIP equ $959C
SND_RESET equ $498E
SND_STOP equ $4994
    endc

FLAGS   equ $1FFFF0                     ; "STRIDER-EX" + version byte, then the flag word at +$E
PACK    equ 0                           ; flag word bit 0 (its low byte, +$F): a CPS+ pack is loaded

        org     $100000

; ------------------------------------------------------------------ VBlank
ex_vbl: cmp.w   #ON,(ACTIVE-$1000000).w ; absolute short: 0xFFF914
        beq.s   .cine
        cmp.w   #HOLD,(ACTIVE-$1000000).w
        beq.s   .hold
        cmp.w   #CARD,(ACTIVE-$1000000).w
        beq.s   .card
        cmp.w   #WAIT,(ACTIVE-$1000000).w
        beq.s   .wait
    ifne REGION_EN
        cmp.w   #SPLIT_PROBE_CODE,SPLIT_PROBE_ADDR
        bne.s   .stock
        bsr     split_palette           ; the USA title: its SCROLL2 half follows the fades
.stock:
    endc
        jmp     STOCK_VBL.w
.wait:  move.w  #$1540,LAYER            ; hold_black: black (respawn_layers.s HIDE) from the next line drawn
        move.w  #HOLD,(ACTIVE-$1000000).w
.hold:
    ifd BOSS_SCENE                      ; a boss scene holds the game's VBlank too, and runs its own (boss_scene.s);
        cmp.w   #BS_MAGIC,BS_ON         ; tested here, not before the stock path, so a frame without a scene costs
        bne.s   .nbs                    ; the same cycles as in the build without the scenes (MEASURED: a test there
        jmp     bs_vbl                  ; held Japan's desert section 4 map load a frame more, desert_gate jeep_kill)
.nbs:
    endc
        addq.w  #1,HOLDTICK             ; the game's VBlank would write its register shadows over the
        rte                             ; player's (a scene's setup spans several VBlanks)
.card:  addq.w  #1,HOLDTICK
        movem.l d0/a0-a1,-(sp)
        jsr     obj_flip                ; the card's caption list flips as a cinematic's (card_cap)
        movem.l (sp)+,d0/a0-a1
        rte
.cine:  movem.l d0-d7/a0-a6,-(sp)
        bsr     cine_step
        tst.w   SS_REQ                  ; the stage select's register and palette writes (stage_select.s)
        beq.s   .nreq
        bsr     ss_vbl
.nreq:  bsr.s   sound
        btst    #4,IN0                  ; START1, active low
        seq     d0                      ; d0 = down
        move.b  HELD,d1
        move.b  d0,HELD
        not.b   d1
        and.b   d1,d0                   ; down now and not before: skip
        beq.s   .out
        move.w  #2,ENDED                ; (2: a skip; the end mark sets 1, play)
.out:   movem.l (sp)+,d0-d7/a0-a6
        rte

sound:  jsr     np_read_tick            ; includes TICK, native fade and the final-page pause clock
        btst    #0,TICK+1
        beq.s   .idle
        move.w  CUE,d0
        beq.s   .idle
        move.w  d0,SOUND
        clr.w   CUE
        rts
.idle:  move.w  #$FF,SOUND
        rts

; ---------------------------------------------------------- the intro hook
cine_hook:
        movem.l d0-d7/a0-a6,-(sp)
        move.b  STAGE(a5),CINE_STAGE    ; this stage's cinematics play once per entry (stage_hook)
        addq.b  #1,CINE_STAGE
        clr.w   NP_CUE                  ; no intro tune playing yet (play .end reads it)
        bsr     hold_black              ; from here to the last scene's end, the game's VBlank waits
        moveq   #0,d0
        move.b  STAGE(a5),d0
        add.w   d0,d0
        lea     stage_cines(pc),a0
        add.w   0(a0,d0.w),a0           ; this stage's list of cinematic numbers
.next:  moveq   #0,d0
        move.b  (a0)+,d0
        cmp.b   #$FE,d0                 ; the EX title card (D17)
        beq.s   .card
        tst.b   d0
        bmi.s   .done
        move.l  a0,-(sp)
        bsr.s   play
        move.l  (sp)+,a0
        bra.s   .next
.card:  move.l  a0,-(sp)
        bsr     ex_card
        move.l  (sp)+,a0
        bra.s   .next
.done:  clr.w   ACTIVE                  ; the game's VBlank from the next frame
        movem.l (sp)+,d0-d7/a0-a6
        move.b  #1,INTRO_FLAG(a5)       ; the replaced store
        rts

; hold_black: from task time, the layers off at the next VBlank, then HOLD
; (ex_vbl .wait does both in the blanking). The hook is entered at any line
; of the picture and the board draws line by line: a layer word written there
; (cine_setup's, after the palette save) left the top of the last stock
; picture on the first held frame (MEASURED in the jtcps1 RTL: 85 lines of the
; coin screen). MAME draws a frame whole at its end, so it showed black. Now
; both show the last stock picture whole, then black. Clobbers d0.
hold_black:
        move.w  HOLDTICK,d0
        move.w  #WAIT,ACTIVE
.w:     cmp.w   HOLDTICK,d0
        beq.s   .w
        rts

; stage_hook: the intro task's per-stage step (STAGE_HOOKS, 0x9128 / 0x909E: moveq #0,d0 /
; move.b STAGE(a5),d0), which runs on every frame of a stage's intro once the game's opening has
; been shown (the first-entry flag at 0x911A / 0x9090 is set once per game, so cine_hook, which
; replaces that store, only plays the first stage's list: a game start, a debug start or the stage
; select). On a new stage's first step (intro state 0; a respawn is state 6) whose cinematics have
; not played (CINE_STAGE), it plays them: the stages after a clear (MEASURED: from St. Petersburg's
; clear, Siberia's intro task starts at state 0 and no briefing played). Then the replaced code.
;

; start like the others"; "In level three, we should show the wizard move up from the arcade intro and then
; cut out the rest of the arcade intro"; "in level 4 cut scene remove the arcade cut scene after the
; wizard. Same with level 5 and 6"): the wizard is the stock intro setup (GLOBE: the Grandmaster with the
; Earth rising over the stars, his laugh), which the stock game shows before a game's first stage only. On
; the first step of Siberia, the Aerial Battleship, the Amazon or Third Moon (internal 1-4; St. Petersburg,
; whose state 0 is its own card and glider, stays stock), the step runs intro_cut in place of the stage's
; state 0 and dialogue, after the briefing and the wizard when it is a stage reached by a clear (a game's
; first stage had both through the intro hook, cine_hook and the stock GLOBE call after it). The desert
; (asm/desert.s dz_i0) takes the same steps in its own task.
stage_hook:
    ifd BOSS_SCENE
        tst.b   INTRO_STATE(a5)
        bne.s   .bs
        clr.b   BS_DONE                 ; a new stage: each boss scene may play once on it (boss_scene.s)
.bs:
    endc

        tst.b   INTRO_STATE(a5)
        bne.s   .go                     ; a later step, or a respawn (6)
        move.b  STAGE(a5),d0
        beq.s   .go                     ; St. Petersburg: stock
        addq.b  #1,d0
        cmp.b   CINE_STAGE,d0
        beq.s   .cut                    ; a game's first stage: its cinematics and the wizard have played
        jsr     cine_hook               ; a stage after a clear: its briefing (sets CINE_STAGE),
        bsr     wizard                  ; the wizard,
        moveq   #1,d0                   ; and the frame the intro task's loop takes after the stock call
        jsr     IC_SLEEP.w              ; (0x9120: it returns to the loop, which sleeps one)
.cut:   addq.l  #4,sp                   ; the step's own return: intro_cut ends the step (to the task's loop)
        bra     intro_cut
.go:    moveq   #0,d0
        move.b  STAGE(a5),d0
        rts

; play: cinematic d0 from task context: bits 0-5 its number in scenes, bit 6 set when it continues
; the scene before it in the list (build_ex.CONTINUES); a0 = the list's next entry.
; A new scene: the game's palettes saved, graphics RAM cleared (cine_setup), its pre-roll over black.
; A continued scene, after the scene before reached its end mark: that scene's last picture stays up
; (ACTIVE stays ON; cine_step only flips the sprite lists while ENDED is set), every other buffer is
; cleared (cont_setup), and its pre-roll prefetches its first frame meanwhile into those buffers, its
; stream leaving the shown ones alone until RESERVE records after flipping away from them
; (cinematic_convert.encode_stream cont); the wait loop clears them in that time (clear_old).
; (MiSTer kit i): "there is a long break between intros in the beginning. There should be none": the
; prologue's PC Engine title and the briefing's logo, which flies toward the camera, were 145 frames
; of black apart (PHASE0_FINDINGS.md "The start flow"). After a START skip the scene before ended
; early (ENDED 2), so its buffers are not those the stream expects: it is set up anew.
play:   clr.b   CONT_NEXT
        move.b  (a0),d1
        bmi.s   .nn                     ; $FE (the card) or $FF (the end): nothing continues this scene
        btst    #6,d1
        sne     CONT_NEXT
.nn:    move.w  d0,d1
        and.w   #$3F,d0
        lsl.w   #3,d0
        lea     scenes(pc),a2
        add.w   d0,a2                   ; (stream long, Japanese cue, English cue)
        btst    #6,d1
        beq.s   .new
        cmp.w   #ON,ACTIVE              ; the scene before ended at its end mark and stayed up
        bne.s   .new
        bsr     cont_setup
        bra.s   .set
.new:   lea     PALS,a0                 ; keep the game's palettes
        lea     SAVE,a1
        move.w  #PALS_LONGS-1,d1
.sv:    move.l  (a0)+,(a1)+
        dbra    d1,.sv
        move.l  a2,-(sp)
        bsr     cine_setup
        move.l  (sp)+,a2
        clr.l   OLD_S1                  ; OLD_S1, OLD_S2: nothing to clear behind the stream
        clr.w   OLD_PAL
        clr.w   ENDED
.set:   bsr     cap_start               ; this scene's caption schedule
        clr.l   FRAMES
        move.l  (a2)+,LZ_SRC
        clr.l   LZ_W                    ; LZ_W, LZ_R
        clr.w   CUE
        clr.w   CUE_NEXT
        st      HELD                    ; the START that began the game is not a skip
        btst    #PACK,FLAGS+$F          ; no pack: subtitles, and a briefing's arcade intro tune
        beq.s   .nopack
        move.b  FLAGS+$F,d1             ; VOICE (bits 1-2): 0 region, 1 Japanese, 2 English
        lsr.b   #1,d1
        and.w   #3,d1
        bne.s   .v
        moveq   #1+REGION_EN,d1         ; region default (L1): USA English, Japan Japanese
.v:     cmp.w   #2,d1
        bne.s   .ja
        addq.l  #2,a2
.ja:    move.w  (a2),CUE_NEXT           ; sent with the stream's first frame (op_cue), on that or the next frame
        bra.s   .cued

; plays its native cue: nopack_cues (stage_lists.inc, build_ex.py nopack_cues) by scene, 0 = silent. It goes as the
; pack's cue does, with the stream's first frame (op_cue). native_fade.s fades the final scene's tail;
; play .end stops it at the scene's end or skip.
.nopack:
        move.l  a2,d1                   ; a2: the entry's cue words (scenes + index * 8 + 4)
        sub.l   #scenes+4,d1
        lsr.w   #3,d1
        lea     nopack_cues(pc),a1
        moveq   #0,d2
        move.b  0(a1,d1.w),d2
        beq.s   .cued                   ; a silent scene (a continued one keeps the tune before it)
        jsr     np_cue_start            ; keep an already-playing native cue across a continued scene
        nop                             ; same twelve-byte site: all existing code/data addresses stay fixed
        nop
        nop
.cued:
        bsr     ready                   ; decode the first record now, in task time, so the
                                        ; first VBlank only applies it (scene_core.s lookahead)
        cmp.w   #2,ENDED                ; a START while a continued scene was set up: skip it
        beq.s   .wait
        clr.w   ENDED
        move.w  #ON,ACTIVE              ; from the next VBlank on, the player runs
.wait:  bsr     clear_old
        tst.w   ENDED
        beq.s   .wait
        cmp.w   #1,ENDED                ; its end mark, and the next scene continues it: stay up
        bne.w   .skip                   ; (2: START skipped it)
        tst.b   CONT_NEXT
        bne.w   .out
.end:   move.w  #HOLD,ACTIVE            ; the next scene, or cine_hook hands back
        tst.w   NP_CUE                  ; without a pack, the scene's intro tune stops with it (at its end
        beq.s   .np                     ; mark, which comes at the pack track's end, or at a START skip): the
        clr.w   NP_CUE                  ; stock music stop. HOLD first, so no player VBlank writes the latch
        move.w  #NP_STOP,SOUND          ; after it; the next write is the next scene's or the game's own
.np:    moveq   #0,d1                   ; black: the backdrop pen 0xBFF of the shown palette buffer, copied, then
        move.w  PALBASE,d1              ; no layer. With every layer off the screen is that pen, which the player
        lsl.l   #8,d1                   ; gives the PC Engine's background color 0 (cinematic_convert.BACKDROP):
        move.l  d1,a0                   ; black at most scenes' ends, white at Meio's welcome's, the one white
        clr.w   BACKDROP*2(a0)          ; hand-back frame (MEASURED, HBMAME: PHASE0_FINDINGS.md "The white frame
        move.w  PALBASE,CPSA+$0A        ; after Meio's welcome"). The copy first: on the board it holds the bus
                                        ; for about 12 lines from the next, so the layers go off after it
        move.w  #$1540,LAYER            ; black before the game's palettes go back under the last picture
        lea     OBJ,a3                  ; and no sprite: a scene's last list stayed in both lists, and the
        bsr     end_a3                  ; game, which shows the list at 0x900000 from its first VBlank, drew
        lea     OBJ_B,a3                ; it in its own colors on its first frame (MEASURED, HBMAME: the
        bsr     end_a3                  ; St. Petersburg briefing's last sprite over the globe's dark start,
        move.w  #OBJ_B>>8,CPSA          ; once its black tail was cut). The base write copies the empty list B
                                        ; (jtcps1 shows a list from the base write after the one that copied
                                        ; it), so the game's first base write shows nothing. List B, not A:
                                        ; the game never draws into 0x900800, while it may draw its next
                                        ; list into 0x900000 in this same frame (the desert's caption), which
                                        ; MAME would then show from its VBlank, a frame before the board and
                                        ; the stock game do (PHASE0_FINDINGS.md "The hand-back's base write")
        lea     SAVE,a0
        lea     PALS,a1
        move.w  #PALS_LONGS-1,d1
.rs:    move.l  (a0)+,(a1)+
        dbra    d1,.rs
        lea     CPSA,a0
        move.w  #$9080,$02(a0)          ; as the game's boot (0x73A94-0x73AA4)
        move.w  #$90C0,$04(a0)
        move.w  #$9100,$06(a0)
        clr.w   $08(a0)                 ; never written by the game
        clr.w   $20(a0)                 ; row scroll offset (the player's 0x300; 0 before it)
        clr.w   CPSB+$28
.out:   rts
; .skip: START ended the scene before its end mark (ENDED 2), or skipped a continued scene in its
; setup.
; scene. It skipped, but the narration kept playing"; 2026-10-15: a short fade-out instead of the
; instant cut): CPS+ plays a cinematic's track to its end unless a command replaces, stops or fades
; it, and the stock intro's first music cue comes 290 frames after the hand-back (PHASE0_FINDINGS.md
; "MiSTer kit k: a START skip stops the cinematic's sound", "A START skip fades the cinematic's track
; out"). FADE_CMD is the pack's
; fade_out control: the core's CPS-1 tap gives it no argument, so its length is the header's (fade
; law 1, const1 30 frames), and it ends the track at silence. HOLD first, so no player VBlank (sound)
; follows it; the next write to the latch is the next scene's or the game's own. Without a pack,
; .end stops the scene's arcade intro tune, if it has one (NP_CUE).
.skip:  move.w  #HOLD,ACTIVE
        btst    #PACK,FLAGS+$F
        beq.w   .end
        move.w  #FADE_CMD,SOUND
        bra     .end

; cont_setup: every map and palette buffer but the three shown cleared (a continued scene starts from
; zero buffers, as a new one does), the shown ones remembered for clear_old. The pre-roll writes no
; layer word and no sprite list before its first frame's, so the picture stays up. Clobbers d0-d3,
; a0-a1.
cont_setup:
        move.w  S1_FRONT,OLD_S1
        move.w  S2_FRONT,OLD_S2
        move.w  PALBASE,OLD_PAL
        lea     s1_slots(pc),a1
        moveq   #7-1,d2
.s1:    move.l  (a1)+,a0
        move.l  a0,d0
        lsr.l   #8,d0
        cmp.w   S1_FRONT,d0
        beq.s   .s1n
        move.l  #$4000,d0
        moveq   #0,d1
        bsr     memfill
.s1n:   dbra    d2,.s1
        lea     s2_slots(pc),a1
        moveq   #3-1,d2
.s2:    move.l  (a1)+,a0
        move.l  a0,d0
        lsr.l   #8,d0
        cmp.w   S2_FRONT,d0
        beq.s   .s2n
        move.l  #$4000,d0
        moveq   #0,d1
        bsr     memfill
.s2n:   dbra    d2,.s2
        lea     pal_slots(pc),a1
        moveq   #2-1,d2
.p:     move.l  (a1)+,a0
        move.l  a0,d0
        lsr.l   #8,d0
        cmp.w   PALBASE,d0
        beq.s   .pn
        bsr     pal_clear
.pn:    dbra    d2,.p
        rts

; pal_clear: the palette buffer at a0 cleared, with the bar black and the caption palette cine_setup
; and cap_reset give every buffer. Clobbers d0-d1, a0.
pal_clear:
        move.l  a0,-(sp)
        move.l  #$1800,d0
        moveq   #0,d1
        bsr     memfill
        move.l  (sp)+,a0
        move.w  #$F000,$600*2(a0)       ; bar black (SCROLL3 palette 0x60, pen 0)
        movem.l a1,-(sp)
        add.w   #CAP_PALOFF,a0
        lea     cap_palette,a1
        moveq   #8-1,d0
.c:     move.l  (a1)+,(a0)+
        dbra    d0,.c
        movem.l (sp)+,a1
        rts

; clear_old: from the wait loop. A continued scene's stream flips away from the last scene's buffers,
; then leaves them alone for RESERVE records (cinematic_convert.encode_stream): each is cleared once it
; is no longer shown. Clobbers d0-d1, a0.
clear_old:
        move.w  OLD_S1,d0
        beq.s   .s2
        cmp.w   S1_FRONT,d0
        beq.s   .s2
        clr.w   OLD_S1
        moveq   #0,d1
        move.w  d0,d1
        lsl.l   #8,d1
        move.l  d1,a0
        move.l  #$4000,d0
        moveq   #0,d1
        bsr     memfill
.s2:    move.w  OLD_S2,d0
        beq.s   .p
        cmp.w   S2_FRONT,d0
        beq.s   .p
        clr.w   OLD_S2
        moveq   #0,d1
        move.w  d0,d1
        lsl.l   #8,d1
        move.l  d1,a0
        move.l  #$4000,d0
        moveq   #0,d1
        bsr     memfill
.p:     move.w  OLD_PAL,d0
        beq.s   .out
        cmp.w   PALBASE,d0
        beq.s   .out
        clr.w   OLD_PAL
        moveq   #0,d1
        move.w  d0,d1
        lsl.l   #8,d1
        move.l  d1,a0
        bsr     pal_clear
.out:   rts

; intro_cut: the stock stages' intro state 0 without its tune (intro_black), then, on the frame the
; dialogue's first step would take, the dialogue's P1 button 1 path (INTRO_SKIP: the fade level from
; SCROLL2 palette 1, state 4, the sound controls 0xF0 and 0xF7, the system objects and the sprite frame;
; it returns to the intro task's loop). State 4 is stock from there: the fade-out (0x96BE), which spawns
; the location caption, the stage's setup with its fade-in, then READY and play (0xA26A), where the stage's
; music starts. So a stage start after the wizard is, frame for frame, the stock game's when P1 button 1
; skips the dialogue on its first frame (scripts/intro_gate.py: its stock reference), without the intro
; tune that skip sends and stops at once (the dialogue's own music, 0x945A).
intro_cut:
        bsr.s   intro_black
        moveq   #1,d0
        jsr     IC_SLEEP.w
        jmp     INTRO_SKIP

; wizard: the stock intro setup (GLOBE) where the stock game never plays it, before a stage reached by a
; clear and before the desert. The star scroll shadows and the copies the VBlank writes the registers from
; (STAR_SH: 0xFF0C44-0xFF0C53) are zero, as at a game's first stage (the boot clears them): the setup sets
; the shadows only when its picture comes on, and the VBlank writes the copies a frame late, so the stars'
; first two frames there came from the last stage's or the last wizard's scroll (MEASURED: STAR1 Y 0x11,
; STAR2 Y 0xFF22 after the desert's). Afterwards they are put back, so the stage finds them as it would
; without the wizard (its play is the same, register for register: intro_gate.py play). Clobbers what the
; stock routine does.
STAR_SH equ -$73BC                      ; (a5) the star shadows and their VBlank copies, 8 words (set at 0x5592, read at 0x596-0x614)
wizard:
        movem.l STAR_SH(a5),d0-d3
        movem.l d0-d3,-(sp)
        moveq   #0,d0
        move.l  d0,STAR_SH(a5)
        move.l  d0,STAR_SH+4(a5)
        move.l  d0,STAR_SH+8(a5)
        move.l  d0,STAR_SH+12(a5)
        jsr     GLOBE
        movem.l (sp)+,d0-d3
        movem.l d0-d3,STAR_SH(a5)
        rts

; intro_black: the stock intro state 0 of stages 1-4 (USA 0x93D8, Japan 0x934E) up to its tune: black,
; one frame, the three maps cleared, ten frames, both sprite lists cleared, then the scroll shadows and the
; intro's words as it sets them for the dialogue. Its frames: the layers go off on the first, the work ends
; on the twelfth. Clobbers d0, d2, d4, a0.
intro_black:
        move.w  #0,IC_LAYER(a5)
        moveq   #1,d0
        jsr     IC_SLEEP.w
        move.w  #$200,d0
        jsr     IC_QUEUE.w
        move.w  #$300,d0
        jsr     IC_QUEUE.w
        move.w  #$400,d0
        jsr     IC_QUEUE.w
        moveq   #10,d0
        jsr     IC_SLEEP.w
        jsr     IC_CLRSPR.w
        clr.w   -$73D4(a5)              ; the scroll shadows (x, y): SCROLL1
        clr.w   -$73D2(a5)
        move.w  #$40,-$73CC(a5)         ; SCROLL2
        clr.w   -$73CA(a5)
        move.w  #$40,-$73C4(a5)         ; SCROLL3
        clr.w   -$73C2(a5)
        clr.w   -$73E6(a5)              ; the intro's line, wait and flag words
        clr.w   -$73E4(a5)
        clr.w   -$73E2(a5)
        rts

; ------------------------------------------------------- the EX title marks

; them (scripts/title_ex.py makes the composite tiles; title_cells.inc lists
; map byte address, stock code and EX code per cell). A cell is swapped only
; while it still holds its stock code. Nothing runs in the VBlank.
; Each mark's colors are pens of SCROLL3 palette 0, the logo's own: it fades
; in with the logo, on the same frames and steps, because its pixels read the
; same palette words (title_ex.mark_fades checks the USA pens).

; rate as the 'Strider', then its purple shadow to fade in at the same rate as
; the purple symbol"): the mark is drawn with the logo, by usa_draw at the
; logo draw's end (0x5C2C), while palette 0 is black (0x5BC0). Then the stock
; fades (0x5CE0) bring in its blue (pens 9-13, 0x5CC4) with the logo's blue
; and, 90 frames later, its purple shadow (pens 5, 7, 8 of 1-8, 0x5CD4) with
; the logo's purple. The title's waits are stock.
    ifeq REGION_EN
; Japan: replaces dbra d7,$5D0A / rts closing the logo draw (0x5D2E)
title_hook:
        subq.w  #1,d7
        cmp.w   #-1,d7
        beq.w   title_patch
        jmp     $5D0A
    endc

; ------------------------------------------------------- the slash voice (D10)
; The export sets lost Hiryu's slash voice: on each slash Japan queues the
; slash sound 0x3B and the voice 0x81 (jsr $4BB0, jsr $4DBE at 0x1A578);
; USA queues only 0x3B (jsr $4BC4 at 0x1A834). The USA program still has the
; voice stub (0x4DD2: move.w #$81,d0 / bra) and its sound program and OKI
; samples play 0x81 exactly as Japan's do (MEASURED: OKI writes 08, 81, 10).
; USA: replaces the 0x3B stub at 0x4BC4 (its only caller is the slash).
    ifne REGION_EN
slash_snd:
        move.w  #$3B,d0                 ; the stub's own body (move.w #$3B,d0 / bra $496E)
        jsr     $496E
        jmp     $4DD2                   ; the voice, as Japan
    endc

; ------------------------------------------------------- the EX title card

; card ("PUSH RUN BUTTON", NEC); the EX build ends the prologue before it and
; shows the arcade logo in its end state, with the EX mark, for the rest of
; the prologue track (CARD_FRAMES, from the census; stage_lists.inc), then the
; St. Petersburg briefing. START (a new press) skips it. Runs between scenes
; (ACTIVE = HOLD), so it writes the video registers itself: the title's bases
; and scrolls (MEASURED, stock title), no sprite slot in the layer word until
; a caption shows (cap_card, captions.inc: English "STRIDER HIRYU.", tr21.9). The
; game's palettes are saved and restored as play does. Clobbers nothing.
CARD_LAYER equ $3F8C                    ; SCROLL2 under SCROLL3, both on (both logos have two halves)
CARD_CAP_LAYER equ CARD_LAYER&$CFFF     ; the same with OBJ in the top slot: the caption over the card
ex_card:
        movem.l d0-d7/a0-a6,-(sp)
        move.w  #$1540,LAYER            ; black while the maps are drawn
        lea     PALS,a0
        lea     SAVE,a1
        move.w  #PALS_LONGS-1,d1
.sv:    move.l  (a0)+,(a1)+
        dbra    d1,.sv
        lea     SCR3,a0                 ; the cinematic maps go: SCROLL3 blank (code 0x20, the title's)
        move.w  #$4000/4-1,d0
.c3:    move.l  #$00200000,(a0)+
        dbra    d0,.c3
        lea     $90C000,a0              ; SCROLL2 blank (code 0x2820, the title's)
        move.w  #$4000/4-1,d0
.c2:    move.l  #$28200000,(a0)+
        dbra    d0,.c2
        bsr     logo_end
        bsr     card_cap_setup
        lea     CPSA,a0
        move.w  #$90C0,$04(a0)          ; SCROLL2 and SCROLL3 bases, as the game's boot
        move.w  #$9100,$06(a0)
        move.w  #$FFC0,$10(a0)          ; the title's scrolls (MEASURED, stock title frames)
        move.w  #$0300,$12(a0)
        move.w  #$FFC0,$14(a0)
        move.w  #$0700,$16(a0)
        move.w  #$000E,$22(a0)          ; row scroll off
        move.w  #$9140,$0A(a0)          ; the game's palette buffer: copies the logo palette
        move.w  #CARD_LAYER,LAYER
        move.w  #CARD,ACTIVE            ; the card's frames (ex_gate counts them)
        move.w  HOLDTICK,d2
        st      HELD                    ; a START already down is not a skip
.w:     move.w  HOLDTICK,d0
        sub.w   d2,d0
        cmp.w   #CARD_FRAMES,d0
        bcc.s   .end
        bsr     card_cap                ; d0 = the card's frame
        btst    #4,IN0                  ; START1, active low
        seq     d0
        move.b  HELD,d1
        move.b  d0,HELD
        not.b   d1
        and.b   d1,d0
        beq.s   .w
.end:   move.w  #HOLD,ACTIVE
        move.w  #$1540,LAYER
        lea     SAVE,a0
        lea     PALS,a1
        move.w  #PALS_LONGS-1,d1
.rs:    move.l  (a0)+,(a1)+
        dbra    d1,.rs
        movem.l (sp)+,d0-d7/a0-a6
        rts

; card_cap_setup: both sprite lists empty (the card's VBlank flips them), the
; card's caption schedule in the subtitle language (as cap_start), the caption
; colors in the game's buffer, OBJ palette 0x1F (ex_card restores the buffer).
; Clobbers d0-d1, a0-a1.
card_cap_setup:
        clr.l   OBJ                     ; empty lists first: a full end entry each (scene_core.s end_a3)
        clr.w   OBJ+4
        move.w  #$FF00,OBJ+6
        clr.l   OBJ_B
        clr.w   OBJ_B+4
        move.w  #$FF00,OBJ_B+6
        clr.w   SPR_NEW
        moveq   #REGION_EN,d1           ; region language: 1 English, 0 Japanese
        btst    #PACK,FLAGS+$F
        beq.s   .lang
        move.b  FLAGS+$F,d0             ; VOICE (bits 1-2): 2 = English dub
        lsr.b   #1,d0
        and.w   #3,d0
        cmp.w   #2,d0
        bne.s   .lang
        moveq   #1,d1
.lang:  add.w   d1,d1
        add.w   d1,d1
        lea     cap_card,a0
        move.l  0(a0,d1.w),CARD_PTR
        lea     PALS+CAP_PALOFF,a0
        lea     cap_palette,a1
        moveq   #8-1,d0
.p:     move.l  (a1)+,(a0)+
        dbra    d0,.p
        rts

; card_cap: d0 = the card's frame. At a schedule entry's frame, its page (or
; none) goes into the list being built; the next VBlank's flip starts copying
; it and the one after shows it (scene_core.s obj_flip). The first page turns
; the layer word's OBJ slot on; a clear leaves it, so the empty list ends the
; caption on its frame. Clobbers nothing.
card_cap:
        movem.l d0-d1/a1-a3,-(sp)
        move.l  CARD_PTR,d1
        beq.s   .out
        move.l  d1,a1
        cmp.w   (a1),d0                 ; its frame reached? ($FFFF never is)
        bcs.s   .out
        addq.l  #2,a1
        move.l  (a1)+,a2                ; the page, 0 = none
        move.l  a1,CARD_PTR
        move.l  OBJ_BACK,a3
        move.l  a2,d1
        beq.s   .em
        move.w  (a2)+,d1                ; entries
        bra.s   .ct
.c:     move.l  (a2)+,(a3)+             ; x, y, code, attr
        move.l  (a2)+,(a3)+
.ct:    dbra    d1,.c
        move.w  #CARD_CAP_LAYER,LAYER
.em:    bsr     end_a3                  ; the full end entry (scene_core.s)
        move.w  #1,SPR_NEW
.out:   movem.l (sp)+,d0-d1/a1-a3
        rts

; ------------------------------------------------------- the USA slice (D10a)
; The USA logo, split along the streak's line (scripts/usa_slice.py): the half
; above stays on SCROLL3, the half below goes to SCROLL2 (split_cells.inc),
; and after the streak the halves scroll apart as the Japanese logo's do.
    ifne REGION_EN
; usa_draw: replaces the logo draw's last store (move.w #0,-$73C4(a5), 0x5C2C)
; and, after the split, the EX mark (title_patch), whose cell 0x913934 is one
; of the split's composites (title_ex.composites builds on it)
usa_draw:
        move.w  #0,-$73C4(a5)
        clr.w   -$73CA(a5)              ; SCROLL2 y/x shadows: the title's (as the Japanese draw); the USA
        clr.w   -$73CC(a5)              ; title never sets them (MEASURED: left at 0xFE40/0x023F by attract)
        bsr.s   .split
        bra     title_patch
.split: movem.l d0-d1/a0-a1,-(sp)
        lea     split_cells,a0
        bra     cells_swap

; split_palette: SCROLL3 palette 0 -> SCROLL2 palette 0 (the USA fades write
; only the first). Clobbers nothing.
split_palette:
        movem.l d0/a0-a1,-(sp)
        lea     $914C00,a0
        lea     $914800,a1
        moveq   #8-1,d0
.c:     move.l  (a0)+,(a1)+
        dbra    d0,.c
        movem.l (sp)+,d0/a0-a1
        rts

; usa_slice: replaces the two fade-outs (bsr $5D3E; bsr $5DD0 at 0x508C).
; The Japanese motion (0x58C8, 0x58DE: SCROLL3 and SCROLL2 shadows), then
; the fade-outs' end state (pens 1-13 black), the shadows back to 0 and the
; probe cell back to its stock code, so the palette copy stops.
usa_slice:
        subq.w  #2,-$73C2(a5)           ; SCROLL3 y (MEASURED: the shadows are y, x pairs)
        addq.w  #1,-$73CA(a5)           ; SCROLL2 y
        moveq   #5,d0
        jsr     $7DE.w
        moveq   #$2F,d7
.l:     subq.w  #4,-$73C2(a5)
        addq.w  #8,-$73C4(a5)           ; SCROLL3 x
        addq.w  #4,-$73CA(a5)
        subq.w  #8,-$73CC(a5)           ; SCROLL2 x
        moveq   #1,d0
        jsr     $7DE.w
        dbra    d7,.l
        lea     $914C02,a1
        moveq   #13-1,d0
.c:     clr.w   (a1)+
        dbra    d0,.c
        bsr     split_palette
        clr.w   -$73C2(a5)
        clr.w   -$73C4(a5)
        clr.w   -$73CA(a5)
        clr.w   -$73CC(a5)
        move.w  #SPLIT_PROBE_STOCK,SPLIT_PROBE_ADDR
        rts
    endc

; ------------------------------------------------------- the coin screen
; After a coin, the PUSH START screen shows the finished title logo behind

; Replaces the bsr to the layer-control setter and the move.w #1,d0 after
; it at the end of the screen's setup (USA 0x4EBA, Japan 0x4EA6), when the
; screen has been cleared and the scroll shadows zeroed. The logo is drawn
; with the game's own title routines, in its end state: the mark in, the
; USA fades done (pens 1-8 at brightness C, 9-13 at F, as 0x5CC4/0x5CD4
; leave them), the Japanese glow on its last step (0xCD86E, as 0x5D34
; leaves it) and no slice (all scroll shadows 0).
coin_hook:
    ifne REGION_EN
        jsr     $5BA8                   ; the replaced call: layer control 0x138E
    else
        jsr     $5D64                   ; the replaced call: layer control 0x138E
    endc
        movem.l d0-d7/a0-a4,-(sp)
        bsr     logo_end
        movem.l (sp)+,d0-d7/a0-a4
        moveq   #1,d0                   ; the replaced move.w #1,d0 (the sleep's frame count)
        rts

logo_end:                               ; the finished title logo in the game's maps and palettes
    ifne REGION_EN
        jsr     $5BDC                   ; the logo (SCROLL3), its scroll shadows 0, the split and the mark (usa_draw)
        lea     $5D1E,a0                ; the logo's colors at brightness 0
        lea     $914C00,a1              ; SCROLL3 palette 0
        moveq   #16-1,d0
.c:     move.w  (a0)+,(a1)+
        dbra    d0,.c
        lea     $914C02,a1
        moveq   #8-1,d0
.b1:    add.w   #$C000,(a1)+            ; pens 1-8: 12 fade steps
        dbra    d0,.b1
        moveq   #5-1,d0
.b2:    add.w   #$F000,(a1)+            ; pens 9-13: 15 fade steps
        dbra    d0,.b2
        bsr     split_palette           ; the SCROLL2 half's palette
    else
        jsr     $5CB4                   ; the katakana half (SCROLL2)
        jsr     $5CF8                   ; the flame half (SCROLL3; title_hook adds the mark)
        jsr     $5C74                   ; the logo palette, SCROLL2 and SCROLL3 palette 0
        movem.l $CD86E,d0-d3            ; the glow's last step, pens 0-7
        movem.l d0-d3,$914800
        movem.l d0-d3,$914C00
        clr.w   -$73CA(a5)              ; SCROLL2 y/x: no slice
        clr.w   -$73CC(a5)
        clr.w   -$73C2(a5)              ; SCROLL3 y/x
        clr.w   -$73C4(a5)
    endc
        rts


; title_patch: the mark's cells (title_cells.inc; their attribute stays 0,
; palette 0), through cells_swap
title_patch:
        movem.l d0-d1/a0-a1,-(sp)
        lea     title_cells,a0          ; (after the scene streams: beyond pc-relative reach)
; cells_swap: a0 = count, then (map address.l, expected code.w, new code.w)
; entries; a cell is swapped only while it holds its expected code. Entered
; with d0-d1/a0-a1 saved (movem), returns through the restore.
cells_swap:
        move.w  (a0)+,d0
        bra.s   .t
.l:     move.l  (a0)+,a1
        move.w  (a0)+,d1                ; stock code
        cmp.w   (a1),d1
        bne.s   .skip
        move.w  (a0),(a1)               ; EX code (attribute unchanged: palette 0)
.skip:  addq.l  #2,a0
.t:     dbra    d0,.l
        movem.l (sp)+,d0-d1/a0-a1
        rts

        include "subtitles.s"           ; captions (D4a): before scene_core.s, which tests CAP_OFF
        include "scene_core.s"
        include "stage_select.s"        ; D14
        include "portraits.inc"         ; W3b portraits (portrait_ex.py): equates, hook stubs, tables
        include "portraits.s"           ; W3b portraits: the frame hook and arming

        even
; stage_cines: per internal stage (0 St. Petersburg, 1 Siberia, 2 Amazon,
; 3 Aerial Battleship, 4 Third Moon), offsets of 0xFF-terminated lists of
; scene numbers. Written by build_ex.py as stage_lists.inc.
        include "stage_lists.inc"
        even
        include "title_cells.inc"
        even
        include "split_cells.inc"       ; usa_slice.py (USA; written for both regions)
        even
        include "captions.inc"          ; subtitle_ex.py
        even
        include "stills.inc"            ; the stage select's stills (build_ex.py, stage_openings.py)
        even
        include "ending.s"
    ifd DESERT                          ; desert hook: the desert extra stage (desert_ex.py, build_ex.py --desert-census)
        even
        include "desert.s"
    endif
        even
        include "ready.s"               ; READY below each stage's name (ready_ex.py): last, so nothing else moves
    ifd BOSS_SCENE                      ; build_ex.py (the default; not --no-boss-scene): the boss scenes (boss_scene.py)
        even
        include "boss_scene.inc"
        include "boss_scene.s"
    endc

; Keep the existing player, scene streams and all hook destinations fixed. This
; small addition occupies erased bank space; its only entry replaces sound's
; six-byte TICK increment above. The builder rejects an overlapping allocation.
        dcb.b   $1FF000-*, $FF
        include "native_fade.s"
        include "native_reading.s"
