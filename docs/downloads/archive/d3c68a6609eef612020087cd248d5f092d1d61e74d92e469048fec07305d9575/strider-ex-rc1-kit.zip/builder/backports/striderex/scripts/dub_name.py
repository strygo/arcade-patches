"""Strider EX English dub: how each English take says "Hiryu" (DUB.md section 12)."""
import argparse
import difflib
import hashlib
import json
import os
import re
import sys
from fractions import Fraction
from pathlib import Path
import numpy as np
sys.path.insert(0, str(Path(__file__).resolve().parent))
ROOT = Path(__file__).resolve().parents[3]
HERE = ROOT / 'backports/striderex'
MANIFEST = HERE / 'manifests/dub_name_say.json'
TAKES = HERE / 'manifests/dub_takes.json'
VOICES = HERE / 'manifests/dub_voices.json'
SUBTITLES = HERE / 'manifests/subtitles.json'
FIT = HERE / 'manifests/dub_fit.json'
HOP = 0.005
WIN = 0.025
FORMANT_CEILING = {'female': 5500.0, 'male': 5000.0}
REFERENCE = 'tr21.9'
ASR_MODEL = 'large-v3'
HEAR_YOU = ('hear you', 'here you')
SCENES = {21: 'prologue', 22: 'St. Petersburg briefing', 23: 'desert introduction', 24: 'Siberia briefing', 25: 'Aerial Battleship briefing', 26: 'Amazon briefing', 27: 'flight', 28: "Meio's welcome"}

def load(p):
    return json.loads(Path(p).read_text())

def file_sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def takes_dir():
    return (ROOT / 'roms').resolve().parent / load(TAKES)['store']['path']

def approved_take(lid):
    pin = load(TAKES)['lines'][lid]['wav_sha256']
    f = takes_dir() / f'{lid}.wav'
    if not f.exists() or file_sha(f) != pin:
        sys.exit(f'{f}: missing or not the pinned {pin[:16]} (dub_takes.json store)')
    return f

def read_wav(path):
    from scipy.io import wavfile
    r, raw = wavfile.read(str(path))
    x = raw.astype(np.float64)
    if x.ndim == 2:
        x = x.mean(1)
    if raw.dtype == np.int16:
        x /= 32768.0
    elif raw.dtype == np.int32:
        x /= 2147483648.0
    return (x, r)

def resample(x, r, rate):
    from scipy.signal import resample_poly
    if r == rate:
        return x
    fr = Fraction(int(rate), int(r)).limit_denominator(1000)
    return resample_poly(x, fr.numerator, fr.denominator)

def frame_starts(n, rate, win=WIN, hop=HOP):
    W, H = (int(round(win * rate)), int(round(hop * rate)))
    st = np.arange(0, max(1, n - W), H)
    return (st, W, (st + W / 2) / rate)

def yin(x, rate, times, fmin=60.0, fmax=520.0, win=0.03, thr=0.2):
    """f0 (Hz, nan where aperiodic) at the given frame centers (YIN at 16 kHz)."""
    R = 16000
    y = resample(x, rate, R)
    W = int(win * R)
    tmax, tmin = (int(R / fmin), int(R / fmax))
    out = np.full(len(times), np.nan)
    lags = np.arange(1, tmax + 1)
    for k, tc in enumerate(times):
        s = int(tc * R - W / 2)
        if s < 0 or s + W + tmax > len(y):
            continue
        w = y[s:s + W + tmax]
        a = w[:W]
        c = np.correlate(w, a, 'valid')[:tmax + 1]
        e0 = np.dot(a, a)
        sq = np.cumsum(np.concatenate([[0.0], w * w]))
        et = sq[lags + W] - sq[lags]
        d = e0 + et - 2 * c[1:]
        cm = d * lags / np.maximum(np.cumsum(d), 1e-12)
        hit = np.nonzero(cm[tmin - 1:] < thr)[0]
        if not len(hit):
            continue
        t = hit[0] + tmin - 1
        while t + 1 < tmax and cm[t + 1] < cm[t]:
            t += 1
        if 1 <= t < tmax - 1:
            y0, y1, y2 = (cm[t - 1], cm[t], cm[t + 1])
            den = y0 - 2 * y1 + y2
            tf = t + (0.5 * (y0 - y2) / den if den else 0.0)
        else:
            tf = t
        out[k] = R / (tf + 1)
    return out

def cepstral_f0(x, rate, times, fmin=60.0, fmax=600.0, win=0.04):
    """f0 (Hz) at the frame centers from the real cepstrum's peak (40 ms Hann window)."""
    W = int(win * rate)
    w = np.hanning(W)
    q = np.arange(8192) / rate
    band = (q > 1 / fmax) & (q < 1 / fmin)
    out = np.full(len(times), np.nan)
    for k, tc in enumerate(times):
        s = int(tc * rate - W / 2)
        if s < 0 or s + W > len(x):
            continue
        ce = np.fft.irfft(np.log(np.abs(np.fft.rfft(x[s:s + W] * w, 8192)) + 1e-09))
        out[k] = 1 / q[band][int(np.argmax(ce[band]))]
    return out

def pitch(x, rate, times):
    """YIN, except where it disagrees with the cepstrum by more than a fifth of an octave (YIN can lock on"""
    y, c = (yin(x, rate, times), cepstral_f0(x, rate, times))
    with np.errstate(divide='ignore', invalid='ignore'):
        off = np.isfinite(y) & np.isfinite(c) & (np.abs(np.log2(np.where(np.isfinite(y), y, 1) / c)) > 0.3)
    return np.where(off, c, y)

def lpc(frame, order):
    from scipy.linalg import solve_toeplitz
    r = np.correlate(frame, frame, 'full')[len(frame) - 1:len(frame) + order]
    if r[0] <= 0:
        return None
    r = r.copy()
    r[0] *= 1.0 + 1e-09
    return np.concatenate([[1.0], solve_toeplitz(r[:-1], -r[1:])])

def formant_candidates(x, rate, times, ceiling):
    """Each frame's LPC resonances (frequency, bandwidth), as Praat's Burg settings: 5 formants under"""
    fs2 = int(2 * ceiling)
    y = resample(x, rate, fs2)
    y = np.append(y[0], y[1:] - np.exp(-2 * np.pi * 50 / fs2) * y[:-1])
    W = int(WIN * fs2)
    w = np.hamming(W)
    out = []
    for tc in times:
        s = int(tc * fs2 - W / 2)
        fr = y[max(0, s):max(0, s) + W]
        A = lpc(fr * w[:len(fr)], 10) if len(fr) == W and np.any(fr) else None
        if A is None:
            out.append(np.zeros((0, 2)))
            continue
        rts = np.roots(A)
        rts = rts[np.imag(rts) > 0]
        f = np.angle(rts) * fs2 / (2 * np.pi)
        bw = -fs2 / np.pi * np.log(np.abs(rts))
        ok = (f > 150) & (f < ceiling - 50) & (bw < 1200)
        c = np.stack([f[ok], bw[ok]], 1)
        out.append(c[np.argsort(c[:, 0])])
    return out

def track_formants(cands, ceiling, tcost=1.5):
    """F1 < F2 < F3 per frame (nan where a frame has no candidates): Viterbi over each frame's choices of"""
    from itertools import combinations
    ref = np.array([550.0, 1650.0, 2750.0]) * ceiling / 5500.0
    n = len(cands)
    states, costs = ([], [])
    for c in cands:
        cb = list(combinations(range(len(c)), 3))
        if not cb:
            states.append(None)
            costs.append(None)
            continue
        S = np.array([[c[i] for i in k] for k in cb])
        f, b = (S[:, :, 0], S[:, :, 1])
        states.append(f)
        costs.append(np.abs(f - ref).sum(1) / ref.mean() + (b / f).sum(1))
    F = np.full((n, 3), np.nan)
    i = 0
    while i < n:
        if costs[i] is None:
            i += 1
            continue
        j = i
        while j < n and costs[j] is not None:
            j += 1
        D, bp = ([costs[i]], [None])
        for k in range(i + 1, j):
            tr = tcost * np.abs(np.log(states[k][None, :, :] / states[k - 1][:, None, :])).sum(2)
            tot = D[-1][:, None] + tr
            arg = tot.argmin(0)
            D.append(tot[arg, np.arange(tot.shape[1])] + costs[k])
            bp.append(arg)
        s = int(np.argmin(D[-1]))
        for k in range(j - 1, i - 1, -1):
            F[k] = states[k][s]
            if bp[k - i] is not None:
                s = int(bp[k - i][s])
        i = j
    return F

def analyse(x, rate, ceiling):
    """Frame tracks every HOP: level (dB), low-band share (80-1000 Hz, dB: voicing), high-band share"""
    st, W, t = frame_starts(len(x), rate)
    win = np.hamming(W)
    nfft = 1
    while nfft < W:
        nfft *= 2
    fq = np.fft.rfftfreq(nfft, 1 / rate)
    lowb, hib = ((fq >= 80) & (fq <= 1000), fq > 2000)
    e, low, hi, cen = (np.zeros(len(st)) for _ in range(4))
    for k, s in enumerate(st):
        fr = x[s:s + W]
        sp = np.abs(np.fft.rfft(fr * win, nfft)) ** 2
        tot = sp.sum() + 1e-15
        e[k] = 10 * np.log10(np.mean(fr ** 2) + 1e-12)
        low[k] = 10 * np.log10(sp[lowb].sum() / tot + 1e-12)
        hi[k] = 10 * np.log10(sp[hib].sum() / tot + 1e-12)
        cen[k] = (sp * fq).sum() / tot
    f0 = pitch(x, rate, t)
    emax = e.max()
    son = (low > -9) & (e > emax - 35)
    f0[~son] = np.nan
    cands = formant_candidates(x, rate, t, ceiling)
    cands = [c if son[k] else np.zeros((0, 2)) for k, c in enumerate(cands)]
    return dict(t=t, e=e, low=low, hi=hi, cen=cen, f0=f0, son=son, cands=cands, F=track_formants(cands, ceiling))

def rnd(v, n=0):
    """round, or None for nan"""
    v = float(v)
    if not np.isfinite(v):
        return None
    return round(v, n) if n else int(round(v))

def smooth(v, k=2):
    ok = np.isfinite(v)
    if ok.sum() < 2:
        return v.copy()
    idx = np.arange(len(v))
    w = np.interp(idx, idx[ok], v[ok])
    w = np.convolve(np.pad(w, k, mode='edge'), np.ones(2 * k + 1) / (2 * k + 1), 'valid')
    w[~ok] = np.nan
    return w

def runs(mask, gap=2):
    """[(i, j)] runs of True, bridging gaps shorter than gap frames."""
    out, i, n = ([], 0, len(mask))
    while i < n:
        if not mask[i]:
            i += 1
            continue
        j = i
        while True:
            while j < n and mask[j]:
                j += 1
            k = j
            while k < n and (not mask[k]) and (k - j < gap):
                k += 1
            if k < n and mask[k]:
                j = k
                continue
            break
        out.append((i, j))
        i = j
    return out

def voice_space(paths, ceiling):
    """A voice's vowel space from its approved lines: F1/F2 over strongly voiced frames, and its /i/"""
    return voice_space_of((read_wav(p) for p in paths), ceiling)

def voice_space_of(signals, ceiling):
    """voice_space from (signal, rate) pairs (the Japanese speakers' lines cut from their vocal stems)."""
    F1, F2 = ([], [])
    for x, r in signals:
        T = analyse(x, r, ceiling)
        ok = np.isfinite(T['f0']) & (T['e'] > T['e'].max() - 20) & np.isfinite(T['F'][:, 1])
        F1 += list(T['F'][ok, 0])
        F2 += list(T['F'][ok, 1])
    F1, F2 = (np.array(F1), np.array(F2))
    low = F1 < np.percentile(F1, 30)
    i_f2 = float(np.percentile(F2[low], 90))
    return dict(frames=int(len(F1)), f1_median=round(float(np.median(F1))), f2_median=round(float(np.median(F2))), i_f2=round(i_f2), i_f1=round(float(np.median(F1[low & (F2 > 0.9 * i_f2)]))))

def norm_words(text):
    return [w for w in re.sub("[^a-z0-9' ]", ' ', text.lower().replace('-', ' ')).split() if w]

def name_window(words, text):
    """(start, end) s of the stretch the recognizer heard between the words around the name, from the"""
    exp = norm_words(text.replace("Hiryu's", ' NAMEMARK ').replace('Hiryu', ' NAMEMARK '))
    k = exp.index('namemark')
    rec = [re.sub("[^a-z0-9']", '', w['word'].lower()) for w in words]
    sm = difflib.SequenceMatcher(a=exp, b=rec, autojunk=False)
    amap = {}
    for blk in sm.get_matching_blocks():
        for d in range(blk.size):
            amap[blk.a + d] = blk.b + d
    before = [amap[i] for i in range(k) if i in amap]
    after = [amap[i] for i in range(k + 1, len(exp)) if i in amap]
    a = words[before[-1]]['end'] if before else 0.0
    b = words[after[0]]['start'] if after else words[-1]['end'] if words else 99.0
    if b <= a:
        b = a + 1.0
    heard = ' '.join((w['word'].strip() for w in words[before[-1] + 1 if before else 0:after[0] if after else len(words)]))
    return (a, b, heard)

def name_tracks(T, space):
    """F1, F2 and F3 picked for the name's sounds (i r j u, whose F1 is always under 750 Hz) from each"""
    n = len(T['t'])
    F = np.full((n, 3), np.nan)
    top = 1.1 * space['i_f2']
    floor = space.get('f2_floor', 750.0)
    for k, c in enumerate(T['cands']):
        if not len(c):
            continue
        c = c[c[:, 1] < 700]
        f1 = c[c[:, 0] < 750, 0]
        f2 = c[(c[:, 0] >= floor) & (c[:, 0] <= top), 0]
        if len(f1):
            F[k, 0] = f1[0]
        if len(f2):
            F[k, 1] = f2[0]
            f3 = c[c[:, 0] > f2[0] + 250, 0]
            if len(f3):
                F[k, 2] = f3[0]
    return (F, smooth(F[:, 1]), smooth(F[:, 2]))

def find_name(T, wa, wb, space):
    """The name's landmarks (frame indices) in a take's tracks, or None: the voiced run after an /h/ (or"""
    t, e, son = (T['t'], T['e'], T['son'])
    emax = e.max()
    hlike = ~son & (e > emax - 55) & (T['low'] < -10) & (T['cen'] > 800) & (T['cen'] < 7000)
    _, F2, _ = name_tracks(T, space)
    found = []
    for i, j in runs(son, gap=3):
        if j - i < 20 or t[j - 1] < wa - 0.4 or t[i] > wb + 0.3:
            continue
        k = i - 1
        while k >= 0 and i - k <= 4 and (not hlike[k]):
            k -= 1
        h_end = k
        while k >= 0 and hlike[k]:
            k -= 1
        h0 = k + 1
        initial = t[i] - t[int(np.argmax(e > emax - 40))] < 0.3
        if h_end - k < 3 and (not initial):
            continue
        head = F2[i:i + 12]
        if not np.isfinite(head).any() or np.nanmax(head) < 0.8 * space['i_f2']:
            continue
        p = i + int(np.nanargmax(head))
        r = jp = None
        for q in range(p + 2, j - 2):
            if not np.isfinite(F2[q]) or F2[q] > F2[p] - 400:
                continue
            w = F2[max(p, q - 6):q + 7]
            if F2[q] > np.nanmin(w):
                continue
            after = F2[q:min(j, q + 40)]
            if np.isfinite(after).any() and np.nanmax(after) - F2[q] >= 250:
                jp = q + int(np.nanargmax(after))
                r = p + int(np.nanargmin(F2[p:jp + 1]))
                break
        if r is None:
            continue
        found.append(dict(h0=h0, on=i, peak=p, r=r, j=jp, run_end=j, overlap=min(t[j - 1], wb) - max(t[i], wa)))
    if not found:
        return None
    m = max(found, key=lambda d: d['overlap'])
    j = m['j']
    end = min(m['run_end'], j + int(0.4 / HOP))
    lo = j + int(np.nanargmin(F2[j:end])) if np.isfinite(F2[j:end]).any() else end - 1
    v2peak = e[j:end].max()
    stop = end
    for q in range(j + 1, end):
        if e[q] < v2peak - 12 or (q > lo and np.isfinite(F2[q]) and (F2[q] > F2[lo] + 250)):
            stop = q
            break
    m['end'] = min(stop, j + int(0.45 / HOP))
    return m

def name_features(T, m, space):
    t, e = (T['t'], T['e'])
    f0 = T['f0'].copy()
    fm = np.nanmedian(f0) if np.isfinite(f0).any() else np.nan
    f0 = np.where(f0 > 1.9 * fm, f0 / 2, np.where(f0 < fm / 1.9, f0 * 2, f0))
    F, F2, F3 = name_tracks(T, space)
    on, p, r, j, end = (m['on'], m['peak'], m['r'], m['j'], m['end'])

    def med(a):
        a = a[np.isfinite(a)]
        return float(np.median(a)) if len(a) else float('nan')
    lvl = med(F2[on:on + 9])
    hold = on
    while hold < r and (not np.isfinite(F2[hold]) or F2[hold] >= 0.9 * lvl):
        hold += 1
    f3v = med(F3[on:max(hold, on + 3)])
    f3r = np.nanmin(F3[p:j + 1]) if np.isfinite(F3[p:j + 1]).any() else np.nan
    rho = next((k for k in range(on, j + 1) if np.isfinite(F3[k]) and F3[k] < f3v - 0.5 * (f3v - f3r)), r)
    seg = slice(max(p, r - 6), min(end, j + 6) + 1)
    dip = seg.start + int(np.argmin(e[seg]))
    e1, e2 = (e[on:r].max(), e[j:end].max())
    g1, g2 = (med(f0[on:r]), med(f0[j:end]))
    n = max(1, end - on)
    return dict(h_ms=round((on - m['h0']) * HOP * 1000), voiced_ms=round(n * HOP * 1000), ee_ms=round((hold - on) * HOP * 1000), ee_share=round((hold - on) / n, 3), v1_f1=rnd(med(F[on:on + 9, 0])), v1_f2=rnd(lvl), v1_f2_vs_i=rnd(lvl / space['i_f2'], 3), rhotic_ms=round((rho - on) * HOP * 1000), rhotic_share=round((rho - on) / n, 3), r_ms=round((j - r) * HOP * 1000), dip_pos=round(float(np.clip((dip - r) / max(1, j - r), -1, 2)), 2), r_db=round(float(e[r] - e2), 1), stress_db=round(float(e1 - e2), 1), stress_st=round(float(12 * np.log2(g1 / g2)), 1) if np.isfinite(g1) and np.isfinite(g2) else None, gap_ms=round(float((~T['son'][on:end]).sum()) * HOP * 1000), times=dict(h=round(float(t[m['h0']]), 3), on=round(float(t[on]), 3), hold=round(float(t[hold]), 3), r=round(float(t[r]), 3), j=round(float(t[j]), 3), end=round(float(t[end - 1]), 3)))

def picture(x, rate, T, row, path, ceiling, title, space):
    """A spectrogram of the name with its formant tracks, landmarks, level and f0 (PNG)."""
    from PIL import Image, ImageDraw
    tm = row['times']
    a, b = (max(0.0, tm['h'] - 0.2), min(len(x) / rate, tm['end'] + 0.2))
    pps, h = (1000, 400)
    seg = x[int(a * rate):int(b * rate)]
    W, H = (int(0.012 * rate), max(1, int(rate / pps)))
    nfft = 1024
    cols = [20 * np.log10(np.abs(np.fft.rfft(seg[s:s + W] * np.hanning(W), nfft)) + 1e-09) for s in range(0, len(seg) - W, H)]
    S = np.array(cols).T[np.fft.rfftfreq(nfft, 1 / rate) <= ceiling]
    S = np.clip((S - (S.max() - 70)) / 70, 0, 1)
    im = Image.fromarray((255 * (1 - S[::-1])).astype(np.uint8)).resize((S.shape[1], h)).convert('RGB')
    out = Image.new('RGB', (im.width, h + 150), 'white')
    out.paste(im, (0, 0))
    d = ImageDraw.Draw(out)
    t = T['t']
    F, _, _ = name_tracks(T, space)
    for k in range(len(t)):
        if not a <= t[k] <= b:
            continue
        X = (t[k] - a) * pps
        for c, col in zip(F[k], [(220, 0, 0), (0, 150, 0), (0, 0, 220)]):
            if np.isfinite(c):
                Y = h - c / ceiling * h
                d.ellipse([X - 1.5, Y - 1.5, X + 1.5, Y + 1.5], fill=col)
        d.point((X, h + 75 - (T['e'][k] - T['e'].max()) * 1.8), fill=(0, 0, 0))
        if np.isfinite(T['f0'][k]):
            d.point((X, h + 150 - T['f0'][k] / 3.5), fill=(230, 120, 0))
    for key in ('h', 'on', 'hold', 'r', 'j', 'end'):
        X = (tm[key] - a) * pps
        d.line([X, 0, X, h], fill=(255, 0, 255))
        d.text((X + 2, 2), key, fill=(255, 0, 255))
    for tt in np.arange(np.ceil(a * 10) / 10, b, 0.1):
        X = (tt - a) * pps
        d.line([X, h + 140, X, h + 150], fill=(0, 0, 0))
        d.text((X + 2, h + 136), f'{tt:.1f}', fill=(0, 0, 0))
    d.text((4, h + 4), title, fill=(0, 0, 0))
    out.save(path)

def mfcc(x, rate, warp=1.0, n_mels=40, n_ceps=13, fmin=80.0, fmax=7600.0):
    """MFCC every HOP (c1-c12, CMVN); warp > 1 scales a higher voice's frequency axis down onto the"""
    from scipy.fft import dct
    st, W, _ = frame_starts(len(x), rate)
    nfft = 1
    while nfft < W:
        nfft *= 2
    w = np.hamming(W)
    spec = np.array([np.abs(np.fft.rfft(x[s:s + W] * w, nfft)) ** 2 for s in st])
    mel = lambda h: 2595 * np.log10(1 + h / 700)
    hz = lambda m_: 700 * (10 ** (m_ / 2595) - 1)
    edges = hz(np.linspace(mel(fmin), mel(min(fmax, rate / 2 / warp)), n_mels + 2)) * warp
    bins = np.fft.rfftfreq(nfft, 1 / rate)
    fb = np.zeros((n_mels, len(bins)))
    for k in range(n_mels):
        lo_, c, hi_ = (edges[k], edges[k + 1], edges[k + 2])
        fb[k] = np.clip(np.minimum((bins - lo_) / (c - lo_), (hi_ - bins) / (hi_ - c)), 0, None)
    c = dct(np.log(spec @ fb.T + 1e-10), type=2, axis=1, norm='ortho')[:, 1:n_ceps]
    return (c - c.mean(0)) / (c.std(0) + 1e-09)

def dtw(a, b):
    """Mean frame distance along the best DTW path (symmetric steps)."""
    n, m = (len(a), len(b))
    C = np.sqrt(((a[:, None, :] - b[None, :, :]) ** 2).sum(-1))
    D = np.full((n + 1, m + 1), np.inf)
    L = np.zeros((n + 1, m + 1))
    D[0, 0] = 0
    for i in range(1, n + 1):
        for j in range(1, m + 1):
            o = (D[i - 1, j - 1], D[i - 1, j], D[i, j - 1])
            k = int(np.argmin(o))
            D[i, j] = C[i - 1, j - 1] + o[k]
            L[i, j] = 1 + (L[i - 1, j - 1], L[i - 1, j], L[i, j - 1])[k]
    return float(D[n, m] / L[n, m])
_ASR = {}
ASR_CACHE = None

def asr():
    if 'm' not in _ASR:
        os.environ.setdefault('HF_HUB_OFFLINE', '1')
        from faster_whisper import WhisperModel
        from faster_whisper.tokenizer import Tokenizer
        import faster_whisper
        m = WhisperModel(ASR_MODEL, device='cpu', compute_type='int8')
        _ASR.update(m=m, tok=Tokenizer(m.hf_tokenizer, m.model.is_multilingual, task='transcribe', language='en'), version=faster_whisper.__version__)
    return _ASR

def transcribe(x, rate):
    A = asr()
    y = resample(x, rate, 16000).astype(np.float32)
    segs, _ = A['m'].transcribe(y, language='en', beam_size=5, temperature=0.0, word_timestamps=True, condition_on_previous_text=False)
    return [dict(start=round(float(w.start), 3), end=round(float(w.end), 3), word=w.word.strip(), p=round(float(w.probability), 3)) for s in segs for w in s.words]

def forced_logp(x, rate, texts):
    """{text: log P(text | audio)}: whisper's teacher-forced token probabilities (its alignment pass)."""
    from faster_whisper.audio import pad_or_trim
    A = asr()
    y = resample(x, rate, 16000).astype(np.float32)
    feats = A['m'].feature_extractor(y)
    enc = A['m'].encode(pad_or_trim(feats))
    out = {}
    for text in texts:
        ids = A['tok'].encode(' ' + text.strip())
        res = A['m'].model.align(enc, A['tok'].sot_sequence, [ids], feats.shape[-1])
        out[text] = round(float(np.log(np.maximum(np.array(res[0].text_token_probs), 1e-12)).sum()), 2)
    return out
CUTS = ((0.04, 0.03), (0.06, 0.05), (0.09, 0.08))

def recognizer(x, rate, text, words, tm):
    """The recognizer's evidence for one take: the words it wrote for the name, and two forced choices,"""
    _, _, heard = name_window(words, text)
    ctx = {v: text.replace('Hiryu', v) for v in ('Hiryu',) + HEAR_YOU}
    lp = forced_logp(x, rate, list(ctx.values()))
    pad = np.zeros(int(0.3 * rate))
    alone = []
    for pre, post in CUTS:
        a, b = (int((tm['on'] - pre) * rate), int((tm['end'] + post) * rate))
        iso = forced_logp(np.concatenate([pad, x[max(0, a):b], pad]), rate, ['Hiryu.', 'Hear you.', 'Here you.'])
        alone.append(iso['Hiryu.'] - max(iso['Hear you.'], iso['Here you.']))
    return dict(heard=heard, heard_as_name=bool(re.search('hiryu|heeryu|hee-ryoo', heard, re.I)), llr_line=round(lp[ctx['Hiryu']] - max((lp[ctx[v]] for v in HEAR_YOU)), 2), llr_alone=round(float(np.median(alone)), 2), llr_alone_cuts=[round(v, 2) for v in alone], logp_line={v: lp[ctx[v]] for v in ctx})

def line_info():
    v, s, tk = (load(VOICES), {l['id']: l for l in load(SUBTITLES)['lines']}, load(TAKES)['lines'])
    out = {}
    for lid, l in v['lines'].items():
        sub = s.get(lid, {})
        text = (sub.get('en') or {}).get('text') or l.get('text') or ''
        if 'Hiryu' in text or 'Hee-ryoo' in (l.get('plain') or ''):
            out[lid] = dict(line=lid, track=int(lid[2:4]), scene=SCENES[int(lid[2:4])], speaker=l['speaker'], voice=tk[lid]['voice'], text=text, tts_text=tk[lid]['text'], tts_prompt=tk[lid]['prompt'], take=tk[lid]['take'], wav_sha256=tk[lid]['wav_sha256'])
    return out

def sex(voice):
    return 'female' if voice in FEMALE_VOICES else 'male'
FEMALE_VOICES = {'Gacrux', 'Kore', 'Despina', 'Callirrhoe', 'Erinome', 'Zephyr', 'Leda', 'Autonoe', 'Aoede', 'Laomedeia', 'Achernar', 'Pulcherrima', 'Vindemiatrix', 'Sulafat'}

def measure_take(path, info, space, words=None, recognize=True):
    x, rate = read_wav(path)
    ceiling = FORMANT_CEILING[sex(info['voice'])]
    T = analyse(x, rate, ceiling)
    if words is None:
        c = ASR_CACHE / f'{file_sha(path)}.json' if ASR_CACHE else None
        if c is not None and c.exists():
            words = load(c)
        else:
            words = transcribe(x, rate)
            if c is not None:
                c.write_text(json.dumps(words))
    wa, wb, heard = name_window(words, info['text'])
    m = find_name(T, wa, wb, space)
    row = dict(file_sha256=file_sha(path), seconds=round(len(x) / rate, 3), asr=' '.join((w['word'] for w in words)), heard=heard, window=[round(wa, 3), round(wb, 3)])
    if m is None:
        row['found'] = False
        if recognize:
            ctx = {v: info['text'].replace('Hiryu', v) for v in ('Hiryu',) + HEAR_YOU}
            lp = forced_logp(x, rate, list(ctx.values()))
            row['recognizer'] = dict(heard=heard, heard_as_name=bool(re.search('hiryu|heeryu', heard, re.I)), llr_line=round(lp[ctx['Hiryu']] - max((lp[ctx[v]] for v in HEAR_YOU)), 2), llr_alone=None, logp_line={v: lp[ctx[v]] for v in ctx})
        return (row, dict(x=x, rate=rate, T=T, m=None, seg=None, words=words))
    row['found'] = True
    row.update(name_features(T, m, space))
    tm = row['times']
    if recognize:
        row['recognizer'] = recognizer(x, rate, info['text'], words, tm)
    seg = x[int((tm['on'] - 0.03) * rate):int((tm['end'] + 0.01) * rate)]
    return (row, dict(x=x, rate=rate, T=T, m=m, seg=seg, words=words))

def classify(row):
    """match: the recognizer hears the name, not "hear you", both in the line and in the name alone (as it"""
    rec = row['recognizer']
    in_line, alone = (rec['llr_line'] > 0, rec['llr_alone'] > 0)
    return 'match' if in_line and alone else 'borderline' if in_line or alone else 'mismatch'
CLASS_RANK = {'match': 2, 'borderline': 1, 'mismatch': 0}
CLEAR = dict(llr=1.5, ee_ms=100)

def clear_fails(row):
    """What keeps a take from matching the reference clearly ([] = clear)."""
    if not row.get('found'):
        return ['name not found']
    rec, out = (row['recognizer'], [])
    if row.get('class') != 'match':
        out.append(f"class {row.get('class')}")
    for k in ('llr_line', 'llr_alone'):
        if rec.get(k) is None or rec[k] < CLEAR['llr']:
            out.append(f'{k} {rec.get(k)}')
    if not rec.get('heard_as_name'):
        out.append(f"written {rec.get('heard')!r}")
    if (row.get('ee_ms') or 0) < CLEAR['ee_ms']:
        out.append(f"/i/ held {row.get('ee_ms')} ms")
    if row.get('fit') and (not row['fit']['fits']):
        out.append('does not fit its slot')
    rad = row.get('radio')
    if rad is not None and (not (rad['llr_line'] > 0 and (rad['llr_alone'] or 0) > 0)):
        out.append(f"radio {rad['llr_line']} / {rad['llr_alone']}")
    return out

def line_slot(lid):
    """(slot, the next line's start or None, the mixer's gap) for a line, as dub_mix.py mix reads them."""
    import dub_mix as DM
    fit, subs = (DM.fit_plan(), DM.subtitle_index())
    rows = DM.slots_for(int(lid[2:4]), fit, subs)
    k = [r[0] for r in rows].index(lid)
    return (rows[k][1], rows[k + 1][1]['start'] if k + 1 < len(rows) else None, fit['defaults']['min_gap'])

def post_spec(speaker):
    """The speaker's post chain in the approved fit (Super Base's radio band-pass and drive), or None."""
    import dub_mix as DM
    return load(FIT)['speakers'].get(DM.speaker_key(speaker), {}).get('post')

def fit_check(lid, path):
    """The take placed in its line's approved slot as dub_mix.py mix places it (dub_mix.place_line: trim,"""
    import dub_mix as DM
    slot, nxt, gap = line_slot(lid)
    x = DM.read_any_wav(path)
    trimmed, _ = DM.trim(x)
    _, start, end, ratio, limit_end, notes = DM.place_line(x, slot, nxt, gap)
    ok = end <= limit_end + 1e-06 and ratio >= 1 - slot['max_compress'] - 1e-09
    d = len(trimmed) / DM.RATE
    need = min(1.0, (limit_end - slot['start']) / d)
    return dict(slot=[slot['start'], slot['end']], next_start=nxt, voice_s=round(d, 3), placed=[round(start, 3), round(end, 3)], ratio=round(ratio, 3), limit_end=round(limit_end, 3), fits_slot=bool(ok), ratio_needed=round(need, 3), fits=bool(need >= 1 - slot['max_compress'] - 1e-09))
JP_NAME = '飛竜'
JP_SEX = {'Super Base': 'female', 'Narrator': 'male'}
JP_F2_FLOOR = {'Super Base': 1300.0}
JP_PAD = 0.3
JP_PUNCT = re.compile('[、。!?！？「」\\s]')
JP_TOL = dict(v1_share=0.1, r_f2=0.15, r_f3_drop=0.1, pitch_v1_v2=3.0, pitch_fall_v2=3.0, level_v1_v2=3.0)
JP_ZCAP = 4.0
JP_DTW_TOL = 0.25

def transcribe_ja(x, rate, cache=None):
    """Japanese words with timestamps (faster-whisper, language ja; for Japanese a word is a character or"""
    y = resample(x, rate, 16000).astype(np.float32)
    c = Path(cache) / f'{hashlib.sha256(y.tobytes()).hexdigest()}_ja.json' if cache else None
    if c is not None and c.exists():
        return load(c)
    A = asr()
    segs, _ = A['m'].transcribe(y, language='ja', beam_size=5, temperature=0.0, word_timestamps=True, condition_on_previous_text=False)
    words = [dict(start=round(float(w.start), 3), end=round(float(w.end), 3), word=w.word.strip(), p=round(float(w.probability), 3)) for s in segs for w in s.words]
    if c is not None:
        c.write_text(json.dumps(words, ensure_ascii=False))
    return words

def jp_lines():
    """The lines whose Japanese text says the name (subtitles.json ja), with their times and speakers."""
    return {l['id']: dict(line=l['id'], track=l['track'], start=l['start'], end=l['end'], speaker=l['speaker'], ja=l['ja']['text']) for l in load(SUBTITLES)['lines'] if JP_NAME in ((l.get('ja') or {}).get('text') or '')}

def jp_stem(track):
    """The track's Japanese vocal stem (mono, 44.1 kHz) and its identity: the separation the beds use"""
    import dub_beds as B
    man = B.manifest()
    v = man['params']['variants'][0]
    spec = man['inputs']['external_separations'][v]
    vocals, _ = B.external_stems(v, spec, track)
    row = spec['tracks'][str(track)]['vocals']
    return (np.asarray(vocals, dtype=np.float64).mean(0), B.RATE, dict(variant=v, file=row['file'], sha256=row['sha256']))

def jp_name_window(words, ja):
    """(start, end, heard) of the name in a Japanese transcript: the expected text (the name replaced by a"""
    exp = JP_PUNCT.sub('', ja)
    k = exp.index(JP_NAME)
    exp = list(exp[:k]) + ['\x00'] + list(exp[k + len(JP_NAME):])
    chars, times = ([], [])
    for w in words:
        cs = [c for c in w['word'] if not JP_PUNCT.match(c)]
        for i, c in enumerate(cs):
            d = (w['end'] - w['start']) / len(cs)
            chars.append(c)
            times.append((w['start'] + i * d, w['start'] + (i + 1) * d))
    sm = difflib.SequenceMatcher(a=exp, b=chars, autojunk=False)
    amap = {}
    for blk in sm.get_matching_blocks():
        for d in range(blk.size):
            amap[blk.a + d] = blk.b + d
    before = [amap[i] for i in range(k) if i in amap]
    after = [amap[i] for i in range(k + 1, len(exp)) if i in amap]
    a = times[before[-1]][1] if before else times[0][0] if times else 0.0
    b = times[after[0]][0] if after else times[-1][1] if times else a + 1.0
    heard = ''.join(chars[before[-1] + 1 if before else 0:after[0] if after else len(chars)])
    return (a, max(b, a + 0.1), heard)

def robust_f0(x, rate, times):
    """f0 (Hz) at the frame centers: the cepstrum's, where YIN (a lenient threshold) agrees with it within a"""
    c = cepstral_f0(x, rate, times, fmin=70.0, fmax=600.0)
    y = yin(x, rate, times, fmin=70.0, fmax=520.0, thr=0.45)
    with np.errstate(divide='ignore', invalid='ignore'):
        d = np.log2(y / c)
        ok = np.isfinite(d) & (np.abs(d - np.round(d)) < 0.3) & (np.abs(np.round(d)) <= 1)
    return np.where(ok, c, np.nan)

def short_level(x, rate, lo=1000.0, hi=5000.0, win=0.01, hop=0.0025):
    """(times, dB): the 1-5 kHz level in 10 ms windows every 2.5 ms (fine enough for a tap's closure)."""
    W, H = (int(win * rate), int(hop * rate))
    nfft = 1
    while nfft < W:
        nfft *= 2
    fq = np.fft.rfftfreq(nfft, 1 / rate)
    band = (fq >= lo) & (fq < hi)
    st = np.arange(0, max(1, len(x) - W), H)
    w = np.hanning(W)
    L = np.array([10 * np.log10((np.abs(np.fft.rfft(x[s:s + W] * w, nfft)) ** 2)[band].sum() + 1e-12) for s in st])
    return ((st + W / 2) / rate, L)

def closure(t, L, a, b, side=0.06):
    """The deepest dip of the level L between a and b s: its depth under the lower of the two maxima"""
    k0, k1 = (int(np.searchsorted(t, a)), int(np.searchsorted(t, b)))
    S = int(round(side / (t[1] - t[0])))
    Ls = np.convolve(L, np.ones(3) / 3, 'same')
    best = None
    for k in range(max(k0, 1), min(k1, len(L) - 1)):
        if Ls[k] <= Ls[k - 1] and Ls[k] <= Ls[k + 1]:
            depth = min(Ls[max(0, k - S):k + 1].max(), Ls[k:k + S + 1].max()) - Ls[k]
            if best is None or depth > best[1]:
                best = (k, depth)
    if best is None:
        return dict(t=float((a + b) / 2), depth_db=0.0, width_ms=0, t0=float((a + b) / 2), t1=float((a + b) / 2))
    k, depth = best
    half = Ls[k] + depth / 2
    i, j = (k, k)
    while i > 0 and Ls[i - 1] < half:
        i -= 1
    while j < len(Ls) - 1 and Ls[j + 1] < half:
        j += 1
    return dict(t=float(t[k]), depth_db=round(float(depth), 1), width_ms=int(round((t[j] - t[i] + t[1] - t[0]) * 1000)), t0=float(t[i]), t1=float(t[j]))

def jp_find_name(x, rate, T, wa, wb, space):
    """The name's landmarks (s) in a Japanese line, or None: hi-ryū is [çiɾʲɯː]. The vowel /i/ starts at a"""
    t, e = (T['t'], T['e'])
    F, F2, _ = name_tracks(T, space)
    f0 = robust_f0(x, rate, t)
    tl, L = short_level(x, rate)
    best = None
    for k in range(int(np.searchsorted(t, wa - 0.12)), min(len(t) - 16, int(np.searchsorted(t, wb - 0.05)))):
        if e[k + 6] - e[k] < 6:
            continue
        head = F2[k + 4:k + 12]
        if not np.isfinite(head).any() or np.nanmedian(head) < 0.75 * space['i_f2']:
            continue
        vmax = e[k:k + 16].max()
        on = k
        while e[on] < vmax - 8:
            on += 1
        h0 = on - 1
        while h0 > 1 and on - h0 < 30 and (not np.isfinite(f0[h0 - 1]) or not np.isfinite(f0[h0 - 2])):
            h0 -= 1
        if (on - h0) * HOP < 0.04:
            continue
        c = closure(tl, L, t[on] + 0.025, t[on] + 0.18)
        q0 = int(np.searchsorted(t, c['t1'] + 0.01))
        if np.isfinite(f0[q0:q0 + 12]).mean() < 0.5:
            continue
        if best is None or (c['depth_db'], on) > (best[0]['depth_db'], best[1]):
            best = (c, on, h0)
    if best is None:
        return None
    c, on, h0 = best
    b = int(np.searchsorted(t, c['t']))
    jj = b + int(np.nanargmax(np.where(np.isfinite(F2[b:b + 30]), F2[b:b + 30], -1)))
    k2 = jj + 6
    v2peak = e[b:b + 16].max()
    f1u = np.nanmedian(F[k2:k2 + 12, 0]) if np.isfinite(F[k2:k2 + 12, 0]).any() else np.nan
    lo, lok, stop, why = (np.inf, k2, len(t) - 1, 'the end of the cut')
    f1, f2 = (np.nan_to_num(F[:, 0], nan=0.0), np.nan_to_num(F2, nan=1000000000.0))
    for q in range(k2, len(t) - 1):
        if np.isfinite(F2[q]) and F2[q] < lo:
            lo, lok = (F2[q], q)
        if e[q] < v2peak - 12:
            stop, why = (q, 'level')
            break
        if np.isfinite(f1u) and f1[q] > 1.35 * f1u and (f1[q + 1] > 1.35 * f1u):
            stop, why = (q, 'F1 rise')
            break
        if f2[q] < 0.4 * space['i_f2'] and f2[q + 1] < 0.4 * space['i_f2']:
            stop, why = (q, 'F2 low')
            break
        if np.isfinite(F2[q]) and F2[q] > lo + 250:
            stop, why = (lok, 'F2 rise')
            break
    return dict(h0=float(t[h0]), on=float(t[on]), b=c['t'], j=float(t[jj]), end=float(t[stop]), end_by=why, closure_db=c['depth_db'], closure_ms=c['width_ms'], r_kind='closure', f0=f0)

def en_landmarks(x, rate, T, m, space):
    """The English take's landmarks (s) for jp_measure, from find_name's: the vowel's onset, the r and its"""
    t = T['t']
    _, F2, _ = name_tracks(T, space)
    tl, L = short_level(x, rate)
    on, r, j, end = (t[m['on']], t[m['r']], t[m['j']], t[m['end'] - 1])
    kind = 'find_name'
    if j - r < 0.04 or r - on > 0.35:
        kind = 'fallback'
        c = closure(tl, L, on + 0.04, min(on + 0.3, t[m['run_end'] - 1]))
        if c['depth_db'] >= 8:
            r = c['t']
        else:
            k0, k1 = (int(np.searchsorted(t, on + 0.06)), int(np.searchsorted(t, min(on + 0.35, t[m['run_end'] - 1]))))
            seg = F2[k0:k1]
            r = t[k0 + int(np.nanargmin(seg))] if np.isfinite(seg).any() else r
        kr = int(np.searchsorted(t, r))
        seg = F2[kr:kr + 40]
        j = t[kr + int(np.nanargmax(seg))] if np.isfinite(seg).any() else r + 0.05
        end = max(end, j + 0.05)
    c = closure(tl, L, max(on + 0.025, r - 0.035), r + 0.035)
    b = c['t'] if c['depth_db'] >= 6 else float(r)
    return dict(h0=float(t[m['h0']]), on=float(on), b=b, j=float(j), end=float(end), closure_db=c['depth_db'], closure_ms=c['width_ms'], r_kind=kind)

def jp_measure(T, lm, space, f0):
    """The features jp_measure compares (landmarks lm: on, the r at b, end; f0 every frame):"""
    t = T['t']
    F, F2, F3 = name_tracks(T, space)
    ix = lambda s: int(np.clip(np.searchsorted(t, s), 0, len(t) - 1))
    on, b, end = (ix(lm['on']), ix(lm['b']), ix(lm['end']))
    b = min(max(b, on + 1), end - 2)
    fm = np.nanmedian(f0) if np.isfinite(f0).any() else np.nan
    f0 = np.where(f0 > 1.9 * fm, f0 / 2, np.where(f0 < fm / 1.9, f0 * 2, f0))

    def med(a):
        a = a[np.isfinite(a)]
        return float(np.median(a)) if len(a) else float('nan')

    def st(f):
        return 12 * np.log2(f / 100.0)
    n2 = max(3, end - b)
    g1, g2 = (med(f0[on:b]), med(f0[b:end]))
    g2a, g2z = (med(f0[b:b + n2 // 3]), med(f0[end - n2 // 3:end]))
    e1, e2 = (T['e'][on:b + 1].max(), T['e'][b:end + 1].max())
    v1 = med(F2[on:on + 8])
    f3v = med(F3[on:on + 8])
    w3, w2 = (slice(max(on, b - 6), b + 7), slice(max(on, b - 6), b + 7))
    f3r = np.nanmin(F3[w3]) if np.isfinite(F3[w3]).any() else np.nan
    f2r = np.nanmin(F2[w2]) if np.isfinite(F2[w2]).any() else np.nan
    v2 = med(F2[b + (end - b) // 2:end + 1])
    ok = lambda *v: all((np.isfinite(u) for u in v))
    return dict(h_ms=int(round((lm['on'] - lm['h0']) * 1000)), v1_ms=int(round((lm['b'] - lm['on']) * 1000)), v2_ms=int(round((lm['end'] - lm['b']) * 1000)), v1_share=round((lm['b'] - lm['on']) / max(0.001, lm['end'] - lm['on']), 3), closure_db=lm['closure_db'], closure_ms=lm['closure_ms'], r_f2=round(f2r / v1, 3) if ok(f2r, v1) else None, r_f3_drop=round(1 - f3r / f3v, 3) if ok(f3r, f3v) else None, pitch_v1_v2=round(st(g1) - st(g2), 1) if ok(g1, g2) else None, pitch_fall_v2=round(st(g2a) - st(g2z), 1) if ok(g2a, g2z) else None, level_v1_v2=round(float(e1 - e2), 1), v1_f2=round(v1 / space['i_f2'], 3) if ok(v1) else None, v2_f2=round(v2 / v1, 3) if ok(v2, v1) else None, f0_v1=rnd(g1), f0_v2=rnd(g2), times={k: round(float(lm[k]), 3) for k in ('h0', 'on', 'b', 'j', 'end')}, r_kind=lm.get('r_kind'))

def jp_score(f, target):
    """{z: each feature's signed distance from the target in JP_TOL units (dtw: above the target's dtw_ref in"""
    z = {k: round(float(np.clip((f[k] - target[k]) / tol, -JP_ZCAP, JP_ZCAP)), 2) for k, tol in JP_TOL.items() if f.get(k) is not None}
    if f.get('dtw') is not None and target.get('dtw_ref') is not None:
        z['dtw'] = round(min(JP_ZCAP, max(0.0, f['dtw'] - target['dtw_ref']) / JP_DTW_TOL), 2)
    return dict(z=z, score=round(float(np.sqrt(np.mean(np.square(list(z.values()))))), 3) if z else None)

def name_segment(x, rate, lm):
    """The name for DTW: from 30 ms before the vowel's onset to 10 ms after its end."""
    return x[max(0, int((lm['on'] - 0.03) * rate)):int((lm['end'] + 0.01) * rate)]

def jp_clips(work):
    """The Japanese target's clips for DTW, re-cut from the pinned stems at the target's landmarks:"""
    tg = load(Path(work) / 'target.json')
    out = []
    for lid, c in tg['clips'].items():
        x, rate, _ = jp_stem(c['track'])
        out.append((lid, c['sex'], c['space'], mfcc(name_segment(x, rate, c['times']), rate)))
    return out

def jp_take(x, rate, T, m, space, voice, target, clips, window=None):
    """jp_measure and jp_score for an English take (find_name's landmarks m), its DTW being the mean over"""
    if m is not None:
        lm = en_landmarks(x, rate, T, m, space)
    else:
        lm = jp_find_name(x, rate, T, window[0], window[1], space) if window else None
        if lm is None:
            return None
    f = jp_measure(T, lm, space, robust_f0(x, rate, T['t']))
    d = [dtw(mfcc(name_segment(x, rate, lm), rate, warp=space['i_f2'] / sp['i_f2']), mf) for _, s, sp, mf in clips if s == sex(voice)]
    f['dtw'] = round(float(np.mean(d)), 3) if d else None
    return dict(f, **jp_score(f, target))
NAME_LIKE = re.compile('\\b(hi|hee|he|hea|her|here|hear)[- ]?(r|ry|ri)(u|oo|yu|you)|\\b(hear|here) you\\b', re.I)

def name_lines_sweep(work, store_lines):
    """Transcripts of every approved take (cached in <work>/asr by the take's digest; rebuilt when missing)"""
    cache = Path(work) / 'asr'
    cache.mkdir(parents=True, exist_ok=True)
    out, hits = ({}, [])
    for lid in sorted(store_lines):
        f = approved_take(lid)
        c = cache / f'{file_sha(f)}.json'
        if c.exists():
            words = load(c)
        else:
            x, r = read_wav(f)
            words = transcribe(x, r)
            c.write_text(json.dumps(words))
        text = ' '.join((w['word'] for w in words))
        out[lid] = dict(words=words, text=text)
        if NAME_LIKE.search(text.replace("'", '')):
            hits.append(lid)
    return (out, hits)

def voice_spaces(voices):
    tk = load(TAKES)['lines']
    return {v: voice_space([approved_take(l) for l, r in tk.items() if r['voice'] == v], FORMANT_CEILING[sex(v)]) for v in sorted(voices)}

def reference_mfcc(audit_ref):
    x, r = read_wav(approved_take(REFERENCE))
    tm = audit_ref['times']
    return dict(voice=audit_ref['voice'], mfcc=mfcc(x[int((tm['on'] - 0.03) * r):int((tm['end'] + 0.01) * r)], r))

def dtw_to_ref(seg, rate, voice, spaces, ref):
    warp = spaces[voice]['i_f2'] / spaces[ref['voice']]['i_f2']
    return round(dtw(mfcc(seg, rate, warp=warp), ref['mfcc']), 3)

def inputs_record():
    import faster_whisper
    return dict(dub_takes_sha256=file_sha(TAKES), dub_voices_sha256=file_sha(VOICES), dub_fit_sha256=file_sha(FIT), store=load(TAKES)['store']['path'], reference=REFERENCE, recognizer=f'faster-whisper {faster_whisper.__version__}, Systran/faster-whisper-{ASR_MODEL} (int8, CPU, local cache only)')

def write_manifest(update):
    m = load(MANIFEST) if MANIFEST.exists() else dict(schema=1)
    m.update(update)
    MANIFEST.write_text(json.dumps(m, indent=1, ensure_ascii=False) + '\n')

def summary(tag, row):
    rec = row.get('recognizer') or {}
    if not row.get('found'):
        return f"{tag:30} NAME NOT FOUND ({row.get('asr')})"
    return f"{tag:30} {row['class']:10} heard {rec['heard']!r:14} line {rec['llr_line']:+6.2f} alone {rec['llr_alone']:+6.2f} /i/ {row['ee_ms']:3} ms F2/i {row['v1_f2_vs_i']} r-j {row['r_ms']} ms stress {row['stress_db']:+.1f} dB {row['stress_st']} st dtw {row.get('dtw_ref')}"

def jp_summary(row):
    j = row.get('jp')
    if not j:
        return ''
    return f" | JP {j['score']} (hi share {j['v1_share']}, r F2 {j['r_f2']}, F3 drop {j['r_f3_drop']}, pitch {j['pitch_v1_v2']}/{j['pitch_fall_v2']} st, level {j['level_v1_v2']} dB, dtw {j['dtw']}{(', r ' + j['r_kind'] if j.get('r_kind') == 'fallback' else '')})"

def mark_jp(rows):
    """jp_rank: each take's place by jp_measure's score (1 = nearest the Japanese) among the takes that fit;"""
    ok = sorted((r for r in rows if r.get('jp') and r['jp'].get('score') is not None and r['fit']['fits']), key=lambda r: r['jp']['score'])
    for k, r in enumerate(ok, 1):
        r['jp_rank'] = k
    if ok:
        ok[0]['jp_best'] = True

def jp_picture(x, rate, T, lm, path, ceiling, title, space):
    """picture() with jp_measure's landmarks (h0, on, the r at b, j, end)."""
    row = dict(times=dict(h=lm['h0'], on=lm['on'], hold=lm['on'], r=lm['b'], j=lm['j'], end=lm['end']))
    picture(x, rate, T, row, path, ceiling, title, space)

def load_target(work):
    """(target means, clips for DTW) when <work>/target.json exists (dub_name.py target), else (None, None)."""
    f = Path(work) / 'target.json'
    if not f.exists():
        return (None, None)
    return (load(f)['target'], jp_clips(work))
JP_FEATURES = ('v1_ms', 'v2_ms', 'h_ms', 'v1_share', 'closure_db', 'closure_ms', 'r_f2', 'r_f3_drop', 'pitch_v1_v2', 'pitch_fall_v2', 'level_v1_v2', 'v1_f2', 'v2_f2', 'f0_v1', 'f0_v2')

def cmd_target(a):
    """The Japanese target: every line whose Japanese text says 飛竜, cut from its pinned vocal stem (its"""
    work = Path(a.work)
    (work / 'pics_ja').mkdir(parents=True, exist_ok=True)
    (work / 'asr').mkdir(exist_ok=True)
    subs = load(SUBTITLES)['lines']
    stems = {}

    def stem(track):
        if track not in stems:
            stems[track] = jp_stem(track)
        return stems[track]
    spaces = {}
    for spk, sx in JP_SEX.items():
        own = [l for l in subs if l['speaker'] == spk and (l.get('ja') or {}).get('text')]
        sig = [(stem(l['track'])[0][int(l['start'] * stem(l['track'])[1]):int(l['end'] * stem(l['track'])[1])], stem(l['track'])[1]) for l in own]
        spaces[spk] = dict(voice_space_of(sig, FORMANT_CEILING[sx]), lines=len(own), **{'f2_floor': JP_F2_FLOOR[spk]} if spk in JP_F2_FLOOR else {})
        print(f'{spk} (Japanese): {spaces[spk]}', flush=True)
    clips = {}
    for lid, l in sorted(jp_lines().items()):
        x, rate, ident = stem(l['track'])
        sx = JP_SEX[l['speaker']]
        a0 = max(0.0, l['start'] - JP_PAD)
        seg = x[int(a0 * rate):int((l['end'] + JP_PAD) * rate)]
        words = transcribe_ja(seg, rate, work / 'asr')
        wa, wb, heard = jp_name_window(words, l['ja'])
        sp = spaces[l['speaker']]
        T = analyse(seg, rate, FORMANT_CEILING[sx])
        lm = jp_find_name(seg, rate, T, wa, wb, sp)
        if lm is None:
            sys.exit(f"{lid}: the name was not found in the Japanese line ({''.join((w['word'] for w in words))})")
        f = jp_measure(T, lm, sp, lm['f0'])
        jp_picture(seg, rate, T, lm, work / 'pics_ja' / f'ja_{lid}.png', FORMANT_CEILING[sx], f'Japanese {lid}', sp)
        f['times'] = {k: round(v + a0, 3) for k, v in f['times'].items()}
        clips[lid] = dict(line=lid, track=l['track'], speaker=l['speaker'], sex=sx, ja=l['ja'], stem=ident, cut=[round(a0, 3), round(l['end'] + JP_PAD, 3)], asr=''.join((w['word'] for w in words)), heard=heard, window=[round(wa + a0, 3), round(wb + a0, 3)], end_by=lm['end_by'], space=sp, **f)
        print(f"{lid} {l['speaker']:10} heard {heard!r} " + ' '.join((f'{k} {f[k]}' for k in JP_FEATURES)) + f" times {f['times']} end by {lm['end_by']}", flush=True)
    target = {k: round(float(np.mean([c[k] for c in clips.values() if c.get(k) is not None])), 3) for k in JP_FEATURES}
    spread = {k: [min((c[k] for c in clips.values() if c.get(k) is not None)), max((c[k] for c in clips.values() if c.get(k) is not None))] for k in JP_FEATURES}
    mf = {lid: mfcc(name_segment(stem(c['track'])[0], stem(c['track'])[1], c['times']), stem(c['track'])[1]) for lid, c in clips.items()}
    nar = [lid for lid, c in clips.items() if c['sex'] == 'male']
    within = [dtw(mf[p], mf[q]) for i, p in enumerate(nar) for q in nar[i + 1:]]
    target['dtw_ref'] = round(float(np.mean(within)), 3) if within else None
    res = dict(clips=clips, target=target, spread=spread, tolerances=dict(JP_TOL, dtw=JP_DTW_TOL), spaces=spaces)
    print('target (the mean of the clips):', target)
    print("the narrator clips' DTW to each other (dtw_ref):", target['dtw_ref'])
    (work / 'target.json').write_text(json.dumps(res, indent=1, ensure_ascii=False) + '\n')
    if a.clips:
        jp_listen(clips, Path(a.clips), stem)
    if a.write:
        write_manifest(dict(japanese_target=dict(status='', inputs=dict(subtitles_sha256=file_sha(SUBTITLES), recognizer=inputs_record()['recognizer'] + ', language ja', separation=next(iter(clips.values()))['stem']['variant']), **res)))
        print(f'wrote {MANIFEST.relative_to(ROOT)} (japanese_target)')
    return 0

def jp_listen(clips, out, stem):
    """The Japanese reference clips (disc audio: local listening only) as MP3s, each name alone (0.2 s"""
    import html
    out.mkdir(parents=True, exist_ok=True)
    rows, txt = ([], [])
    for lid, c in clips.items():
        x, rate, _ = stem(c['track'])
        tm = c['times']
        sub = next((l for l in load(SUBTITLES)['lines'] if l['id'] == lid))
        files = []
        for tag, a_, b_ in (('name', tm['h0'] - 0.2, tm['end'] + 0.2), ('line', sub['start'] - 0.1, sub['end'] + 0.2)):
            n = f'ja_{lid}_{tag}.mp3'
            mp3(x[int(a_ * rate):int(b_ * rate)], rate, out / n)
            files.append(n)
        vals = ' '.join((f'{k} {c[k]}' for k in ('v1_ms', 'v2_ms', 'v1_share', 'r_f2', 'r_f3_drop', 'pitch_v1_v2', 'pitch_fall_v2', 'level_v1_v2', 'f0_v1', 'f0_v2')))
        rows.append(f"<tr><td>{lid}<br>{html.escape(c['speaker'])}</td><td>{html.escape(c['ja'])}</td><td>{html.escape(vals)}</td><td>" + ''.join((f'<div>{t}<br><audio controls preload="none" src="{n}"></audio></div>' for t, n in zip(('the name', 'the line'), files))) + '</td></tr>')
        txt.append(f"{lid} {c['speaker']:10} {c['ja']}\n  {vals}\n  {'  '.join(files)}")
    warn = "DISC AUDIO (the PC Engine CD's Japanese cast, from the BS-RoFormer vocal stems): for local listening only. Never commit, publish, upload or share these files."
    (out / 'index.html').write_text(f"""<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Hiryu Japanese Reference</title><style>body{{font-family:system-ui,sans-serif;margin:16px;background:#fff;color:#111}}td{{border:1px solid #bbb;padding:4px;vertical-align:top;font-size:13px}}table{{border-collapse:collapse}}audio{{width:220px}}</style></head><body><h1>飛竜 as the Japanese cast says it</h1><p><b>{html.escape(warn)}</b></p><table>{''.join(rows)}</table></body></html>""")
    (out / 'index.txt').write_text(warn + '\n\n' + '\n'.join(txt) + '\n')
    print(f'{2 * len(clips)} MP3s (local only) and index files in {out}')

def cmd_audit(a):
    work = Path(a.work)
    (work / 'pics').mkdir(parents=True, exist_ok=True)
    info = line_info()
    store_lines = list(load(TAKES)['lines'])
    global ASR_CACHE
    sweep, hits = name_lines_sweep(work, store_lines)
    ASR_CACHE = work / 'asr'
    extra = sorted(set(hits) - set(info))
    print(f"{len(store_lines)} approved takes transcribed; the name lines: {sorted(info)}; other takes whose words sound like it: {extra or 'none'}", flush=True)
    spaces = voice_spaces({i['voice'] for i in info.values()})
    for v, sp in spaces.items():
        print(f'{v}: {sp}', flush=True)
    rows, segs = ({}, {})
    for lid in sorted(info):
        row, aux = measure_take(approved_take(lid), info[lid], spaces[info[lid]['voice']], words=sweep[lid]['words'])
        if not row['found'] and lid == REFERENCE:
            sys.exit(f"{lid}: the name was not found in the reference take ({row['asr']})")
        rows[lid], segs[lid] = (row, aux)
        if row['found']:
            picture(aux['x'], aux['rate'], aux['T'], row, work / 'pics' / f'approved_{lid}.png', FORMANT_CEILING[sex(info[lid]['voice'])], f"approved {lid} ({info[lid]['voice']})", spaces[info[lid]['voice']])
    ref = dict(voice=info[REFERENCE]['voice'], mfcc=mfcc(segs[REFERENCE]['seg'], segs[REFERENCE]['rate']))
    target, clips = load_target(work)
    for lid, row in rows.items():
        if row['found']:
            row['dtw_ref'] = dtw_to_ref(segs[lid]['seg'], segs[lid]['rate'], info[lid]['voice'], spaces, ref)
            row['class'] = classify(row)
        else:
            row['class'] = 'not found (no English r)'
        if target is not None:
            s_ = segs[lid]
            row['jp'] = jp_take(s_['x'], s_['rate'], s_['T'], s_['m'], spaces[info[lid]['voice']], info[lid]['voice'], target, clips, row['window'])
        print((summary(f"{lid} {info[lid]['voice']}", row) if row['found'] else f"{lid} {info[lid]['voice']}: English finder: no name ({row['asr']})") + jp_summary(row), flush=True)
    context = {}
    for spec in a.compare or ():
        label, d = spec.split('=', 1)
        context[label] = {}
        for lid in sorted(info):
            f = Path(d) / f'{lid}.wav'
            if not f.exists():
                continue
            row, aux = measure_take(f, info[lid], spaces[info[lid]['voice']])
            if row['found']:
                row['dtw_ref'] = dtw_to_ref(aux['seg'], aux['rate'], info[lid]['voice'], spaces, ref)
                row['class'] = classify(row)
                picture(aux['x'], aux['rate'], aux['T'], row, work / 'pics' / f'{label}_{lid}.png', FORMANT_CEILING[sex(info[lid]['voice'])], f'{label} {lid}', spaces[info[lid]['voice']])
            context[label][lid] = row
            print(summary(f'  {label}/{lid}', row), flush=True)
    result = dict(sweep=dict(takes=len(store_lines), name_lines=sorted(info), other_hits=extra, transcripts={l: v['text'] for l, v in sweep.items()}), voice_space=spaces, occurrences={l: dict(info[l], **rows[l]) for l in sorted(info)}, context=context)
    (work / 'audit.json').write_text(json.dumps(result, indent=1, ensure_ascii=False) + '\n')
    if a.write:
        write_manifest(dict(audit=dict(inputs=inputs_record(), **result)))
        print(f'wrote {MANIFEST.relative_to(ROOT)}')
    return 0

def candidate_spaces(renders, spaces):
    """The audit's voice spaces, plus one for each other voice in the render directories: from its approved"""
    tk = load(TAKES)['lines']
    files = {}
    for d in renders:
        for r in load(Path(d) / 'voices.json')['lines']:
            files.setdefault(r['voice'], []).append(Path(d) / f"{r['line']}.wav")
    for v, fs in sorted(files.items()):
        if v in spaces:
            continue
        if any((r['voice'] == v for r in tk.values())):
            spaces.update(voice_spaces({v}))
        else:
            spaces[v] = dict(voice_space(fs, FORMANT_CEILING[sex(v)]), source=f'its {len(fs)} candidate takes')
        print(f'{v}: {spaces[v]}', flush=True)
    return spaces

def mark_best(rows):
    """best: the take nearest a clear match among those that fit (clear first, then the class, then the"""

    def key(r):
        return (not r['clear_fails'], CLASS_RANK[r['class']], r['recognizer']['llr_alone'], r['recognizer']['llr_line'])
    ok = [r for r in rows if r.get('found') and r['fit']['fits']]
    if ok:
        max(ok, key=key)['best'] = True
    voices = sorted({r['voice'] for r in ok})
    if len(voices) > 1:
        for v in voices:
            max((r for r in ok if r['voice'] == v), key=key)['best_of_voice'] = True

def apply_picks(m):
    """Reconstruction helper."""
    picks = (m.get('picked') or {}).get('lines', {})
    for sec in m.values():
        if not isinstance(sec, dict) or not isinstance(sec.get('lines'), dict):
            continue
        for lid, v in sec['lines'].items():
            p = picks.get(lid) or {}
            for r in v.get('candidates', []) if isinstance(v, dict) else []:
                r.pop('picked', None)
                if p.get('render') and p.get('render') == r.get('render') and (p.get('wav_sha256') == r.get('wav_sha256')):
                    r['picked'] = dict(by=p['by'], date=p['date'], words=p['words'])
    return m

def cmd_candidates(a):
    """Every take in the render directories, measured as the audit measures the approved ones (the audit's"""
    global ASR_CACHE
    work = Path(a.work)
    (work / 'pics').mkdir(parents=True, exist_ok=True)
    (work / 'asr').mkdir(exist_ok=True)
    ASR_CACHE = work / 'asr'
    if not (work / 'audit.json').exists():
        sys.exit(f'run audit --work {work} first')
    audit = load(work / 'audit.json')
    info = line_info()
    spaces = candidate_spaces(a.renders, dict(audit['voice_space']))
    ref = reference_mfcc(audit['occurrences'][REFERENCE])
    target, clips = load_target(work)
    notes = load(a.notes_json) if a.notes_json else {}
    out = {}
    for d in a.renders:
        d = Path(d)
        vj = load(d / 'voices.json')
        for r in vj['lines']:
            lid = r['line']
            f = d / f'{lid}.wav'
            if file_sha(f) != r['wav_sha256']:
                sys.exit(f'{f}: not the digest its voices.json records')
            i = dict(info[lid], voice=r['voice'])
            row, aux = measure_take(f, i, spaces[r['voice']])
            tag = f'{d.name}/{lid}'
            if row['found']:
                row['dtw_ref'] = dtw_to_ref(aux['seg'], aux['rate'], r['voice'], spaces, ref)
                row['class'] = classify(row)
                picture(aux['x'], aux['rate'], aux['T'], row, work / 'pics' / f'cand_{d.name}_{lid}.png', FORMANT_CEILING[sex(r['voice'])], tag, spaces[r['voice']])
                if post_spec(i['speaker']):
                    row['radio'] = radio_recognizer(f, i['text'], row['times'], i['speaker'])
            if target is not None:
                row['jp'] = jp_take(aux['x'], aux['rate'], aux['T'], aux['m'], spaces[r['voice']], r['voice'], target, clips, row['window'])
            row['fit'] = fit_check(lid, f)
            row['clear_fails'] = clear_fails(row)
            row.update(render=d.name, voice=r['voice'], model=r['model'], prompt=r['prompt'], text=r['text'], usd_upper_bound=r.get('usd_upper_bound'), wav_sha256=r['wav_sha256'], **{'custom_pronunciations': r['custom_pronunciations']} if r.get('custom_pronunciations') else {}, **{'approach': notes[d.name]} if d.name in notes else {})
            out.setdefault(lid, []).append(row)
            rad = row.get('radio')
            print(summary(tag, row) + f" fit {('yes' if row['fit']['fits'] else 'NO')} x{row['fit']['ratio_needed']} voice {row['fit']['voice_s']} s" + (f" radio {rad['llr_line']:+.2f} / {rad['llr_alone']:+.2f} {rad['heard']!r}" if rad else '') + (' CLEAR' if not row['clear_fails'] else f" ({'; '.join(row['clear_fails'])})") + jp_summary(row), flush=True)
    res = {}
    for lid, rows in sorted(out.items()):
        mark_best(rows)
        if target is not None:
            mark_jp(rows)
        appr = audit['occurrences'][lid]
        res[lid] = dict(approved=dict(wav_sha256=appr['wav_sha256'], fit=fit_check(lid, approved_take(lid)), cls=appr['class'], llr_line=appr['recognizer']['llr_line'], llr_alone=appr['recognizer']['llr_alone'], **{'jp': appr['jp']} if appr.get('jp') else {}), candidates=rows)
    (work / 'candidates.json').write_text(json.dumps(res, indent=1, ensure_ascii=False) + '\n')
    if a.write:
        m = load(MANIFEST) if MANIFEST.exists() else dict(schema=1)
        earlier = {(r.get('render'), r.get('wav_sha256')) for k, sec in m.items() if k != a.section and isinstance(sec, dict) and isinstance(sec.get('lines'), dict) for v in sec['lines'].values() if isinstance(v, dict) for r in v.get('candidates', [])}
        spend = sum((r.get('usd_upper_bound') or 0 for v in res.values() for r in v['candidates'] if (r['render'], r['wav_sha256']) not in earlier))
        old = m.get(a.section, {})
        keep = {k: old[k] for k in ('status', 'request', 'approaches', 'result', 'billed_not_saved', 'refused', 'recast', 'validation', 'listening', 'target', 'other_lines', 'say', 'pace', 'text_sent', 'second_pass', 'renders') if k in old}
        lost = keep.get('billed_not_saved', {}).get('usd_upper_bound', 0)
        sec = dict(inputs=inputs_record(), usd_upper_bound=round(spend, 4), usd_upper_bound_all=round(spend + lost, 4))
        if a.section != 'candidates':
            sec['voice_space'] = {v: spaces[v] for v in sorted({r['voice'] for x in res.values() for r in x['candidates']})}
        m[a.section] = dict(sec, lines=res, **keep)
        MANIFEST.write_text(json.dumps(apply_picks(m), indent=1, ensure_ascii=False) + '\n')
        print(f'wrote {MANIFEST.relative_to(ROOT)} ({a.section})')
    return 0
JUDGED = {'tr22.0': dict(heard=['approved', 'r1a_reroll', 'r1b_ryu', 'r1c_ipa', 'r2a_approved_prompt', 'r2b_r_onset', 'r3b_name', 'r7d_heee_comma_2', 'r7d_heee_comma_1', 'r7c_long_ee_1', 'r7c_long_ee_3', 'r8_despina_1', 'r8_pulcherrima_1', 'r8_kore_1', 'r8_sulafat_1'], best='r8_kore_1', words='round 1: "Super Base, none of these sound good"; round 2: "how are you getting it to pronounce? most of them are wrong. The best of the choices is currently Kore" (2026-10-17)'), 'tr23.2': dict(heard=['approved', 'r2a_approved_prompt', 'r2b_r_onset', 'r3a_ryu_name', 'r3b_name', 'r4a_name', 'r4b_name', 'r4c_name'], best='r4b_name', words='"Narator, desert: re-take" (r4b_name picked, 2026-10-17)'), 'tr26.6': dict(heard=['approved', 'r2a_approved_prompt', 'r2b_r_onset', 'r3a_ryu_name', 'r3b_name', 'r4a_name', 'r4b_name', 'r4c_name', 'r6a_name', 'r6b_name', 'r6c_approved_prompt'], best='r4b_name', over='r6a_name', words='"Narrator, amazon briefing: I prefer B" (B = r4b_name, over A = r6a_name; 2026-10-17)')}

def cmd_validate(a):
    """Reconstruction helper."""
    global ASR_CACHE
    work = Path(a.work)
    ASR_CACHE = work / 'asr'
    ASR_CACHE.mkdir(parents=True, exist_ok=True)
    target, clips = load_target(work)
    if target is None:
        sys.exit(f'run target --work {work} first')
    audit = load(work / 'audit.json')
    m = load(MANIFEST)
    recorded = {}
    for sec in ('candidates', 'super_base_round2'):
        for lid, v in m[sec]['lines'].items():
            for r in v['candidates']:
                recorded[lid, r['render']] = r
    spaces = dict(m['audit']['voice_space'], **m['super_base_round2']['voice_space'])
    info = line_info()
    res = {}
    for lid, J in JUDGED.items():
        rows = []
        for render in J['heard']:
            if render == 'approved':
                occ = audit['occurrences'][lid]
                rows.append(dict(render='approved', voice=occ['voice'], wav_sha256=occ['wav_sha256'], jp=occ['jp']))
                continue
            rec = recorded[lid, render]
            f = next((Path(r_) / render / f'{lid}.wav' for r_ in a.renders_root if (Path(r_) / render / f'{lid}.wav').exists()), None)
            if f is None or file_sha(f) != rec['wav_sha256']:
                sys.exit(f"{lid} {render}: not found under {a.renders_root} with its digest {rec['wav_sha256'][:16]}")
            row, aux = measure_take(f, dict(info[lid], voice=rec['voice']), spaces[rec['voice']], recognize=False)
            jp = jp_take(aux['x'], aux['rate'], aux['T'], aux['m'], spaces[rec['voice']], rec['voice'], target, clips, row['window'])
            rows.append(dict(render=render, voice=rec['voice'], wav_sha256=rec['wav_sha256'], jp=jp))
        scored = sorted((r for r in rows if r['jp'] and r['jp']['score'] is not None), key=lambda r: r['jp']['score'])
        order = [r['render'] for r in scored]
        best = J['best']
        feat_rank = {}
        for k in list(JP_TOL) + ['dtw']:
            have = [r for r in scored if k in r['jp']['z']]
            srt = sorted(have, key=lambda r: abs(r['jp']['z'][k]))
            if any((r['render'] == best for r in srt)):
                feat_rank[k] = [r['render'] for r in srt].index(best) + 1
        out = dict(words=J['words'], heard=len(J['heard']), measured=len(scored), best=best, best_rank=order.index(best) + 1 if best in order else None, rank_by_feature=feat_rank, order=[dict(render=r['render'], voice=r['voice'], score=r['jp']['score'], z=r['jp']['z']) for r in scored], not_measured=[r['render'] for r in rows if not (r['jp'] and r['jp']['score'] is not None)])
        if J.get('over'):
            out['over'] = J['over']
            out['best_before_over'] = order.index(best) < order.index(J['over']) if J['over'] in order else None
        res[lid] = out
        print(f"{lid}{best} ranks {out['best_rank']} of {len(scored)} by the score; by each feature alone: {feat_rank}" + (f"; before {J['over']}: {out.get('best_before_over')}" if J.get('over') else ''))
        for k, r in enumerate(scored, 1):
            print(f"  {k:2} {r['render']:24} {r['voice']:12} {r['jp']['score']:.2f} {r['jp']['z']}")
    (work / 'validate.json').write_text(json.dumps(res, indent=1, ensure_ascii=False) + '\n')
    if a.write:
        mm = load(MANIFEST)
        mm.setdefault(a.section, {})['validation'] = dict(note='The tolerances were set before this comparison; ranking only, his ear decides.', lines=res)
        MANIFEST.write_text(json.dumps(mm, indent=1, ensure_ascii=False) + '\n')
        print(f'wrote {MANIFEST.relative_to(ROOT)} ({a.section}.validation)')
    return 0

def mp3(pcm, rate, dst):
    import subprocess
    import tempfile
    from scipy.io import wavfile
    with tempfile.TemporaryDirectory() as td:
        w = Path(td) / 'a.wav'
        wavfile.write(str(w), int(rate), (np.clip(pcm, -1, 1) * 32767).astype(np.int16))
        subprocess.run(['ffmpeg', '-loglevel', 'error', '-y', '-i', str(w), '-map_metadata', '-1', '-codec:a', 'libmp3lame', '-q:a', '2', str(dst)], check=True)
    return file_sha(dst)

def radio(x, rate, lid=None, speaker='Super Base'):
    """The speaker's post chain as dub_mix.py mix applies it (band-pass and drive) at the take's peak"""
    import dub_mix as DM
    y = resample(x, rate, DM.RATE)
    if lid is not None:
        slot, nxt, gap = line_slot(lid)
        y = DM.place_line(y, slot, nxt, gap)[0]
    y = DM.post_chain(y, post_spec(speaker))
    return (y / (np.abs(y).max() + 1e-09) * np.abs(x).max(), DM.RATE)

def radio_recognizer(path, text, tm, speaker):
    """The recognizer's evidence (as recognizer()) for a take through its speaker's post chain at the"""
    import dub_mix as DM
    spec = post_spec(speaker)
    x, rate = read_wav(path)
    y, r2 = radio(x, rate, speaker=speaker)
    key = hashlib.sha256(json.dumps(spec, sort_keys=True).encode()).hexdigest()[:12]
    c = ASR_CACHE / f'{file_sha(path)}_post_{key}.json' if ASR_CACHE else None
    if c is not None and c.exists():
        words = load(c)
    else:
        words = transcribe(y, r2)
        if c is not None:
            c.write_text(json.dumps(words))
    rec = recognizer(y, r2, text, words, tm)
    assert r2 == DM.RATE
    return dict(asr=' '.join((w['word'] for w in words)), chain=spec, **{k: rec[k] for k in ('heard', 'heard_as_name', 'llr_line', 'llr_alone', 'llr_alone_cuts')})
EXPLAIN12 = '<p>Our synthetic voices only (Google Gemini-TTS takes; no disc audio), so this set can be shared. The For every take: the name alone (0.2 s margins) and its whole line; Super Base\'s line also as the mix gives it (placed in its slot, sped up where the mix speeds it, through the radio chain; no music).</p> <p>LLR = log P("Hiryu") - log P("hear you" / "here you") from the local recognizer (faster-whisper large-v3, forced choice on the same audio), over the whole line and over the name alone; above 0 means it is heard as the name. Class: match (both above 0, as the reference), borderline (one), mismatch (neither). CLEAR: a match by at least {llr} both ways, written as the name, the first vowel held at least {ee} ms, fitting its slot, and (Super Base) heard as the name through the radio chain too. /i/ held: how long the first vowel stays on its "ee" before the r takes it.</p>'
EXPLAIN3 = "<p>Our synthetic voices only (Google Gemini-TTS takes; no disc audio), so this set can be shared. For\nevery take: the name alone (0.2 s margins) and its whole line; Super Base's line also as the mix gives it (placed in\nits slot, sped up where the mix speeds it, through the radio chain; no music).</p>"

def cmd_listen(a):
    """MP3s (our synthetic voices only), index.html and index.txt: the reference, each approved occurrence"""
    import html
    import shutil
    work, out = (Path(a.work), Path(a.out))
    out.mkdir(parents=True, exist_ok=True)
    audit = load(work / 'audit.json')
    cands = load(work / 'candidates.json') if (work / 'candidates.json').exists() else {}
    only = set(a.lines.split(',')) if a.lines else None
    keep = set(a.renders) if a.renders else None
    files, txt = ({}, [])
    marks = dict((m.split('=', 1) for m in a.mark or []))
    excluded = dict((m.split('=', 1) for m in a.exclude or []))
    r3 = bool(a.round3)
    target = load(work / 'target.json')['target'] if r3 else None

    def clips(tag, path, row, speaker, lid):
        x, rate = read_wav(path)
        got = []
        tm = row['times'] if row.get('found') else (row.get('jp') or {}).get('times')
        if tm:
            a_, b_ = (max(0.0, tm['on'] - 0.06 - 0.2), min(len(x) / rate, tm['end'] + 0.2))
            name = f'{tag}_name.mp3'
            files[name] = mp3(x[int(a_ * rate):int(b_ * rate)], rate, out / name)
            got.append(name)
        line = f'{tag}_line.mp3'
        files[line] = mp3(x, rate, out / line)
        got.append(line)
        if post_spec(speaker):
            y, r2 = radio(x, rate, lid, speaker)
            rl = f'{tag}_radio.mp3'
            files[rl] = mp3(y, r2, out / rl)
            got.append(rl)
        pic = work / 'pics' / f'{tag}.png'
        if pic.exists():
            shutil.copyfile(pic, out / pic.name)
            got.append(pic.name)
        return got

    def radio_cell(row):
        rad = row.get('radio')
        return f"{rad['llr_line']} / {rad['llr_alone']} ({rad['heard']})" if rad else ''

    def jvals(row):
        j, rec = (row.get('jp') or {}, row.get('recognizer') or {})
        rank = f" (#{row['jp_rank']})" if row.get('jp_rank') else ''
        return (f"{j.get('score')}{rank}", f"{j.get('v1_share')} ({j.get('v1_ms')} / {j.get('v2_ms')} ms)", j.get('r_f2'), j.get('r_f3_drop'), f"{j.get('pitch_v1_v2')} / {j.get('pitch_fall_v2')}", j.get('level_v1_v2'), j.get('dtw'), rec.get('heard', row.get('heard')))

    def cells(row):
        rec = row.get('recognizer') or {}
        if r3:
            return ''.join((f'<td>{html.escape(str(v))}</td>' for v in jvals(row)))
        return ''.join((f'<td>{html.escape(str(v))}</td>' for v in (row.get('class', 'not found'), rec.get('heard'), rec.get('llr_line'), rec.get('llr_alone'), radio_cell(row), row.get('ee_ms'), row.get('v1_f2_vs_i'), row.get('r_ms'), f"{row.get('stress_db')} / {row.get('stress_st')}", row.get('dtw_ref'))))

    def player(names):
        h = []
        for n in names:
            if n.endswith('.mp3'):
                label = {'name': 'the name', 'line': 'the line', 'radio': 'the line as mixed (radio chain)'}[n.rsplit('_', 1)[-1][:-4]]
                h.append(f'<div>{label}<br><audio controls preload="none" src="{n}"></audio></div>')
            else:
                h.append(f'<a href="{n}">spectrogram</a>')
        return ''.join(h)

    def text_row(tag, voice, row, flags, got):
        rec = row.get('recognizer') or {}
        if r3:
            v = jvals(row)
            txt.append(f"{tag:34} {voice:13} JP {v[0]:12} hi share {v[1]:24} r F2 {v[2]!s:6} F3 drop {v[3]!s:6} pitch {v[4]:12} level {v[5]!s:5} dtw {v[6]!s:6} wrote {v[7]!r}  {' '.join(flags)}\n{'':34} {'  '.join((n for n in got if n.endswith('.mp3')))}")
            return
        txt.append(f"{tag:34} {voice:13} {row.get('class', 'not found'):10} line {rec.get('llr_line')!s:>6} alone {rec.get('llr_alone')!s:>6} radio {radio_cell(row) or '-':28} /i/ {row.get('ee_ms')} ms  {' '.join(flags)}\n{'':34} {'  '.join((n for n in got if n.endswith('.mp3')))}")
    head = '<tr><th>take</th><th>speaker (voice)</th><th>text sent</th><th>class</th><th>recognizer wrote</th><th>LLR line</th><th>LLR alone</th><th>radio chain: LLR line / alone (wrote)</th><th>/i/ held (ms)</th><th>/i/ F2 / voice /i/</th><th>/r/ to /j/ (ms)</th><th>stress dB / st</th><th>DTW to ref</th><th>listen</th></tr>'
    if r3:
        head = '<tr><th>take</th><th>speaker (voice)</th><th>text sent</th><th>JP score (rank among fitting takes)</th><th>"hi" share of the name (hi / ryu ms)</th><th>F2 at the r / F2 of "hi"</th><th>F3 drop at the r</th><th>pitch: "hi" over "ryu" / fall through "ryu" (st)</th><th>level "hi" over "ryu" (dB)</th><th>DTW to the Japanese clips</th><th>English recognizer wrote</th><th>listen</th></tr>'
    rows_html = []
    txt.append('Approved takes (mix 9) and the reference')
    for lid, row in audit['occurrences'].items():
        if only and lid not in only and (lid != REFERENCE):
            continue
        got = clips(f'approved_{lid}', approved_take(lid), row, row['speaker'], lid)
        ref = '<br><b>REFERENCE</b>' if lid == REFERENCE else ''
        rows_html.append(f"<tr><td>{lid}{ref}<br>{html.escape(row['scene'])}</td><td>{html.escape(row['speaker'])} ({row['voice']})</td><td>{html.escape(row['tts_text'])}</td>{cells(row)}<td>{player(got)}</td></tr>")
        text_row(f'approved {lid}', row['voice'], row, ['REFERENCE'] if lid == REFERENCE else [], got)
    cand_html = []
    roots = [Path(r) for r in a.renders_root] if a.renders_root else [__import__('dub_store').root()]
    txt.append('\nCandidates')
    for lid, v in cands.items():
        if only and lid not in only:
            continue
        cast = audit['occurrences'][lid]['voice']
        rows = [r for r in v['candidates'] if keep is None or r['render'] in keep]
        rows.sort(key=lambda r: (r['voice'] != cast, r['voice'], not r.get('best'), not r.get('best_of_voice'), bool(r.get('clear_fails', [1])), -CLASS_RANK.get(r.get('class'), -1), -((r.get('recognizer') or {}).get('llr_alone') or -99)))
        if r3:
            rows.sort(key=lambda r: ((r.get('jp') or {}).get('score') is None, (r.get('jp') or {}).get('score') or 0))
        for row in rows:
            if row['render'] in excluded:
                cand_html.append(f"<tr><td>{lid} {html.escape(row['render'])}<br><b>NOT IN THE SET: {html.escape(excluded[row['render']])}</b></td><td>({row['voice']})</td><td>{html.escape(row['text'])}</td>{cells(row)}<td></td></tr>")
                txt.append(f"{lid + ' ' + row['render']:34} NOT IN THE SET: {excluded[row['render']]}")
                continue
            src = next((r / row['render'] / f'{lid}.wav' for r in roots if (r / row['render'] / f'{lid}.wav').exists()), roots[0] / row['render'] / f'{lid}.wav')
            if not src.exists() or file_sha(src) != row['wav_sha256']:
                sys.exit(f"{src}: missing or not the candidate {row['wav_sha256'][:16]}")
            got = clips(f"cand_{row['render']}_{lid}", src, row, audit['occurrences'][lid]['speaker'], lid)
            flags = (['BEST'] if row.get('best') else []) + ([f"best in {row['voice']}"] if row.get('best_of_voice') else [])
            if r3:
                flags = (['NEAREST THE JAPANESE (the measure)'] if row.get('jp_best') else []) + ([marks[row['render']]] if row['render'] in marks else [])
            if 'clear_fails' in row and (not r3):
                flags.append('CLEAR' if not row['clear_fails'] else 'not clear: ' + '; '.join(row['clear_fails']))
            if row.get('picked'):
                flags.append(f"{row['picked']['date']})")
            fit = row['fit']
            cast_note = '' if row['voice'] == cast else ' (not the cast voice)'
            cand_html.append(f"<tr><td>{lid} {html.escape(row['render'])}<br><b>{html.escape(' | '.join(flags))}</b><br>fits its slot: {('yes' if fit['fits'] else 'NO')} (voice {fit['voice_s']} s, x{fit['ratio_needed']})" + (f"<br><i>{html.escape(row['approach'])}</i>" if row.get('approach') else '') + f"</td><td>{html.escape(audit['occurrences'][lid]['speaker'])} ({row['voice']}){cast_note}</td><td>{html.escape(row['text'])}</td>{cells(row)}<td>{player(got)}</td></tr>")
            text_row(f"{lid} {row['render']}", row['voice'], row, flags + [f"fit x{fit['ratio_needed']}"], got)
    note = f'<p>{html.escape(a.note)}</p>' if a.note else ''
    if r3:
        tg = ', '.join((f'{k} {target[k]}' for k in ('v1_share', 'v1_ms', 'v2_ms', 'r_f2', 'r_f3_drop', 'pitch_v1_v2', 'pitch_fall_v2', 'level_v1_v2', 'dtw_ref')))
        note += f"""<p><b>Round 3: the target is the Japanese cast's 飛竜</b> (hi-ryū: a short "hi", a long "ryū", a tapped r, the pitch highest on "hi" and falling through "ryū"). The Japanese clips are disc audio and are not in this folder; their measured mean: {html.escape(tg)}. JP score: the RMS distance from it over those features (each in a fixed unit: "hi" share 0.10, F2 ratio 0.15, F3 drop 0.10, pitch 3 st, level 3 dB, DTW 0.25 above the Japanese clips' own spread; each capped at 4); lower is nearer. It only orders the takes: it is a guide, not a filter, and every take that fits is here."""
    explain = EXPLAIN3 if r3 else EXPLAIN12.format(REFERENCE=REFERENCE, llr=CLEAR['llr'], ee=CLEAR['ee_ms'])
    page = f"""<!doctype html><html lang="en"><head><meta charset="utf-8">\n<meta name="viewport" content="width=device-width, initial-scale=1"><title>Hiryu Pronunciation Check</title>\n<style>body{{font-family:system-ui,sans-serif;margin:16px;background:#fff;color:#111}}table{{border-collapse:collapse}}\ntd,th{{border:1px solid #bbb;padding:4px;vertical-align:top;font-size:13px}}audio{{width:220px}}</style></head><body>\n<h1>"Hiryu" in the Strider EX English dub</h1>{note}\n{explain}\n<h2>Approved takes (mix 9)</h2><table>{head}{''.join(rows_html)}</table>\n<h2>Candidate re-takes</h2><table>{head}{''.join(cand_html)}</table>\n</body></html>"""
    (out / 'index.html').write_text(page)
    (out / 'index.txt').write_text('"Hiryu" in the Strider EX English dub: our synthetic voices only (shareable).\n' + (a.note + '\n' if a.note else '') + '\n' + '\n'.join(txt) + '\n')
    (out / 'files.json').write_text(json.dumps(files, indent=1) + '\n')
    print(f'{len(files)} MP3s, index.html and index.txt in {out}')
    return 0

def synth_name(rate=24000, f2_path=((0.0, 2300), (0.1, 2300), (0.17, 1100), (0.22, 1100), (0.3, 2000), (0.45, 1000)), f0=140.0, h=0.12, seed=1):
    """A synthetic HEE-ryoo after another word: a vowel (F2 1200 Hz) and a pause, aspiration noise, then a"""
    from scipy.signal import lfilter
    rng = np.random.default_rng(seed)

    def reson(x, f, bw, zi=None):
        r = np.exp(-np.pi * bw / rate)
        a = [1, -2 * r * np.cos(2 * np.pi * f / rate), r * r]
        return lfilter([1 - r], a, x, zi=zi) if zi is not None else lfilter([1 - r], a, x)
    n_v = int(f2_path[-1][0] * rate) + 1
    F2 = np.interp(np.arange(n_v) / rate, [p[0] for p in f2_path], [p[1] for p in f2_path])
    src = np.zeros(n_v)
    src[np.arange(0, n_v, rate / f0).astype(int)] = 1.0
    y = np.zeros(n_v)
    hop = int(0.005 * rate)
    zi = [np.zeros(2) for _ in range(3)]
    for s in range(0, n_v, hop):
        blk = src[s:s + hop]
        for k, (f, bw) in enumerate(((260, 60), (F2[s], 90), (F2[s] + 800, 120))):
            blk, zi[k] = reson(blk, f, bw, zi[k])
        y[s:s + hop] = blk
    y /= np.abs(y).max()
    noise = rng.normal(0, 1, int(h * rate))
    noise = reson(noise, F2[0], 300) + reson(noise, F2[0] + 800, 400)
    noise = noise / np.abs(noise).max() * 0.15
    pre = 0.3
    v0 = np.zeros(int(pre * rate))
    v0[np.arange(0, len(v0), rate / 120).astype(int)] = 1.0
    for f, bw in ((600, 80), (1200, 100), (2500, 150)):
        v0 = reson(v0, f, bw)
    v0 = v0 / np.abs(v0).max() * 0.8
    sig = np.concatenate([np.zeros(int(0.1 * rate)), v0, np.zeros(int(0.08 * rate)), noise, y, np.zeros(int(0.2 * rate))])
    return (sig + rng.normal(0, 0.0001, len(sig)), 0.1 + pre + 0.08 + h)

def self_test():
    fails = []

    def check(name, cond, detail=''):
        print(f"{('PASS' if cond else 'FAIL')} {name} {detail}")
        if not cond:
            fails.append(name)
    rate = 24000
    t = np.arange(int(0.5 * rate)) / rate
    f0 = yin(t * 150.0 % 1.0 - 0.5, rate, np.array([0.1, 0.2, 0.3]))
    check('yin finds 150 Hz', bool(np.all(np.abs(f0 - 150) < 2)), str(np.round(f0, 1)))
    cf = cepstral_f0(t * 150.0 % 1.0 - 0.5, rate, np.array([0.1, 0.2, 0.3]))
    check('the cepstrum finds 150 Hz', bool(np.all(np.abs(cf - 150) < 4)), str(np.round(cf, 1)))
    space = dict(i_f2=2400)
    sig, on = synth_name(rate)
    T = analyse(sig, rate, 5000.0)
    _, F2, _ = name_tracks(T, space)
    k = int(np.argmin(np.abs(T['t'] - (on + 0.05))))
    check('F2 of the synthetic /i/ (2300 Hz)', bool(abs(F2[k] - 2300) < 150), f'{F2[k]:.0f} Hz')
    m = find_name(T, on - 0.2, on + 0.5, space)
    check('the name is found after the other word and the /h/', m is not None)
    if m is not None:
        tt = {key: T['t'][m[key]] - on for key in ('on', 'r', 'j')}
        check('vowel onset', abs(tt['on']) < 0.03, f"{tt['on']:+.3f} s")
        check('/r/ at the F2 minimum (0.17-0.22 s)', 0.15 < tt['r'] < 0.24, f"{tt['r']:.3f} s")
        check('/j/ at the F2 rise (0.30 s)', 0.26 < tt['j'] < 0.34, f"{tt['j']:.3f} s")
        row = name_features(T, dict(m), space)
        check('the /i/ is held about 0.10-0.13 s', 70 <= row['ee_ms'] <= 150, f"{row['ee_ms']} ms")
        sig2, on2 = synth_name(rate, f2_path=((0.0, 2300), (0.03, 2300), (0.1, 1100), (0.22, 1100), (0.3, 2000), (0.45, 1000)))
        T2 = analyse(sig2, rate, 5000.0)
        m2 = find_name(T2, on2 - 0.2, on2 + 0.5, space)
        row2 = name_features(T2, m2, space) if m2 else None
        check('a short /i/ (the "hear" shape) is held less', row2 is not None and row2['ee_ms'] < row['ee_ms'] - 40, f"{row2 and row2['ee_ms']} ms")
    a_ = mfcc(sig, rate)
    check('DTW of a take with itself is 0', dtw(a_, a_) < 1e-09)
    check('DTW to another take is positive', dtw(a_, mfcc(synth_name(rate, f0=180.0, seed=2)[0], rate)) > 0.05)
    words = [dict(start=0.0, end=0.5, word='Super'), dict(start=0.5, end=0.8, word='bass'), dict(start=0.8, end=0.95, word='to'), dict(start=0.96, end=1.14, word='hear'), dict(start=1.14, end=1.34, word='you.'), dict(start=1.7, end=2.1, word='Standard')]
    wa, wb, heard = name_window(words, 'Super Base to Hiryu. Standard time 0325 hours.')
    check('the window between the words around the name', wa == 0.95 and wb == 1.7 and (heard == 'hear you.'), f'{wa}-{wb} {heard!r}')
    wa, wb, heard = name_window(words[3:], 'Hiryu raced into the desert in pursuit.')
    check('a name that opens its line', wa == 0.0, f'{wa}-{wb} {heard!r}')
    check('classify', classify(dict(recognizer=dict(llr_line=1, llr_alone=-2))) == 'borderline' and classify(dict(recognizer=dict(llr_line=1, llr_alone=2))) == 'match' and (classify(dict(recognizer=dict(llr_line=-1, llr_alone=-2))) == 'mismatch'))
    ref_like = dict(found=True, class_='match', recognizer=dict(llr_line=1.97, llr_alone=2.88, heard='Hiryu.', heard_as_name=True), ee_ms=145)
    ref_like['class'] = ref_like.pop('class_')
    r1a_like = dict(found=True, recognizer=dict(llr_line=5.11, llr_alone=2.94, heard='Tijeru.', heard_as_name=False), ee_ms=80, fit=dict(fits=True))
    r1a_like['class'] = 'match'
    check('the reference is a clear match', clear_fails(ref_like) == [], str(clear_fails(ref_like)))
    check('', len(clear_fails(r1a_like)) == 2, str(clear_fails(r1a_like)))
    check('a take heard as "hear you" through the radio chain is not', clear_fails(dict(ref_like, radio=dict(llr_line=0.5, llr_alone=-1.0))) != [])
    rows = [dict(found=True, voice='Gacrux', render='a', clear_fails=['x'], recognizer=dict(llr_alone=5, llr_line=5), fit=dict(fits=True)), dict(found=True, voice='Gacrux', render='b', clear_fails=[], recognizer=dict(llr_alone=2, llr_line=2), fit=dict(fits=True)), dict(found=True, voice='Kore', render='c', clear_fails=['x'], recognizer=dict(llr_alone=1, llr_line=1), fit=dict(fits=True))]
    for r in rows:
        r['class'] = 'match'
    mark_best(rows)
    check('best: a clear take before a larger forced choice', [r['render'] for r in rows if r.get('best')] == ['b'])
    check('best per voice', sorted((r['render'] for r in rows if r.get('best_of_voice'))) == ['b', 'c'])
    m = dict(picked=dict(lines=dict(tr23_2=dict(render='b', wav_sha256='h', by='', date='d', words='w'))), candidates=dict(lines=dict(tr23_2=dict(candidates=[dict(render='b', wav_sha256='h'), dict(render='c', wav_sha256='h')]))))
    got = apply_picks(m)['candidates']['lines']['tr23_2']['candidates']
    check('a pick is flagged on its candidate row only', 'picked' in got[0] and 'picked' not in got[1])
    check('the name-like pattern', bool(NAME_LIKE.search('Super bass to hear you.')) and bool(NAME_LIKE.search('Can Hiryu destroy')) and (not NAME_LIKE.search('Head for Kozik at once')))
    w = [dict(start=0.0, end=0.5, word='ストライダー'), dict(start=0.5, end=0.8, word='ベース'), dict(start=0.8, end=0.98, word='より'), dict(start=0.98, end=1.08, word='飛'), dict(start=1.08, end=1.26, word='竜'), dict(start=1.26, end=1.46, word='へ'), dict(start=1.8, end=2.1, word='標準時間')]
    wa, wb, heard = jp_name_window(w, 'スーパーベースより飛竜へ。標準時間0325時。')
    check('the Japanese name between its neighbours', abs(wa - 0.98) < 1e-06 and abs(wb - 1.26) < 1e-06 and (heard == '飛竜'), f'{wa:.2f}-{wb:.2f} {heard!r}')
    w = [dict(start=0.0, end=0.4, word='急行'), dict(start=0.4, end=0.62, word='した'), dict(start=0.62, end=0.78, word='キ'), dict(start=0.78, end=1.0, word='リー')]
    wa, wb, heard = jp_name_window(w, '急行した飛竜')
    check('a misheard name at the end of its line', abs(wa - 0.62) < 1e-06 and abs(wb - 1.0) < 1e-06 and (heard == 'キリー'), f'{wa:.2f}-{wb:.2f} {heard!r}')
    tt = np.arange(400) * 0.0025
    lev = np.where((tt > 0.5) & (tt < 0.52), -20.0, 0.0)
    c = closure(tt, lev, 0.4, 0.6)
    check('a 20 ms, 20 dB dip', abs(c['t'] - 0.51) < 0.01 and c['depth_db'] > 12 and (c['width_ms'] <= 35), f"{c['t']:.3f} s {c['depth_db']} dB {c['width_ms']} ms")
    sigj, onj = synth_name(rate, f2_path=((0.0, 2300), (0.08, 2300), (0.1, 2250), (0.18, 1300), (0.34, 1300)))
    g = np.ones(len(sigj))
    g[int((onj + 0.065) * rate):int((onj + 0.085) * rate)] = 0.02
    g[:int(onj * rate)] = 0.1
    sigj = sigj * g
    Tj = analyse(sigj, rate, 5000.0)
    lmj = jp_find_name(sigj, rate, Tj, onj - 0.05, onj + 0.3, space)
    check('the Japanese landmarks: the vowel after the h, the tap at its closure', lmj is not None and abs(lmj['on'] - onj) < 0.03 and (abs(lmj['b'] - (onj + 0.075)) < 0.015), f"on {lmj and lmj['on'] - onj:+.3f} b {lmj and lmj['b'] - onj:+.3f} s")
    if lmj is not None:
        fj = jp_measure(Tj, lmj, space, lmj['f0'])
        check('a tap keeps F2 (r_f2 near 1) and the first vowel is short', (fj['r_f2'] or 0) > 0.85 and fj['v1_share'] < 0.4, f"r_f2 {fj['r_f2']} v1_share {fj['v1_share']} end {lmj['end'] - onj:+.3f} s")
    m = find_name(T, on - 0.2, on + 0.5, space)
    lme = en_landmarks(sig, rate, T, m, space)
    fe = jp_measure(T, lme, space, robust_f0(sig, rate, T['t']))
    check('an English r lowers F2 (r_f2 about 0.5)', fe['r_f2'] is not None and fe['r_f2'] < 0.65, f"r_f2 {fe['r_f2']} (b {lme['b'] - on:+.3f} s)")
    tgt = dict(v1_share=0.28, r_f2=0.98, r_f3_drop=0.03, pitch_v1_v2=2.5, pitch_fall_v2=5.5, level_v1_v2=1.4, dtw_ref=3.8)
    same = jp_score(dict(tgt, dtw=3.7), tgt)
    check('the target itself scores 0', same['score'] == 0.0, str(same))
    far = jp_score(dict(tgt, level_v1_v2=31.4), tgt)
    check('one feature counts at most JP_ZCAP', far['z']['level_v1_v2'] == JP_ZCAP, str(far['z']))
    check('every judged choice is in its heard set', all((J['best'] in J['heard'] and J.get('over', J['best']) in J['heard'] for J in JUDGED.values())))
    print('self-test', 'FAILED: ' + ', '.join(fails) if fails else 'PASS')
    return 1 if fails else 0

def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('--self-test', action='store_true')
    sub = p.add_subparsers(dest='cmd')
    s = sub.add_parser('audit')
    s.add_argument('--work', required=True, type=Path)
    s.add_argument('--compare', nargs='*', help='<label>=<render dir>: earlier renders, measured for context')
    s.add_argument('--write', action='store_true')
    s = sub.add_parser('target')
    s.add_argument('--work', required=True, type=Path)
    s.add_argument('--clips', type=Path, help='also write the Japanese clips here (disc audio: local listening only)')
    s.add_argument('--write', action='store_true')
    s = sub.add_parser('validate')
    s.add_argument('--work', required=True, type=Path)
    s.add_argument('--renders-root', nargs='+', required=True, type=__import__('dub_store').dir_arg, help="directories holding the earlier candidates' render directories")
    s.add_argument('--section', default='round3')
    s.add_argument('--write', action='store_true')
    s = sub.add_parser('candidates')
    s.add_argument('--work', required=True, type=Path)
    s.add_argument('--renders', nargs='+', required=True, type=__import__('dub_store').dir_arg)
    s.add_argument('--section', default='candidates', help='the manifest key the result is written to (a later round: its own key; default candidates)')
    s.add_argument('--notes-json', type=Path, help='{render directory name: the approach it tries}, recorded with its takes')
    s.add_argument('--write', action='store_true')
    s = sub.add_parser('listen')
    s.add_argument('--work', required=True, type=Path)
    s.add_argument('--out', required=True, type=Path)
    s.add_argument('--renders-root', type=__import__('dub_store').dir_arg, nargs='+', help='the parents of the candidate render directories, searched in order (default <work>/renders)')
    s.add_argument('--lines', help='comma-separated line ids: the reference and only these lines')
    s.add_argument('--renders', nargs='+', help='only these candidate render directories (names)')
    s.add_argument('--note', help='a paragraph for the top of the page')
    s.add_argument('--round3', action='store_true', help="jp_measure's columns and order (needs <work>/target.json)")
    s.add_argument('--mark', nargs='*', help='<render>=<label>: a label shown with that take')
    s.add_argument('--exclude', nargs='*', help='<render>=<reason>: listed without its audio, with the reason')
    a = p.parse_args()
    if a.self_test:
        return self_test()
    if not a.cmd:
        p.error('a command or --self-test')
    return dict(audit=cmd_audit, candidates=cmd_candidates, listen=cmd_listen, target=cmd_target, validate=cmd_validate)[a.cmd](a)
if __name__ == '__main__':
    sys.exit(main())
