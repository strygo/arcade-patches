"""Compare every sound command around the added native cinematic song."""
from concurrent.futures import ThreadPoolExecutor
import argparse
import json
from pathlib import Path
import shutil
import sys
import zipfile
import cinematic_followup as CF
import pce_sfx as PS
import sfx_gate as SG
COMMANDS = [c for c in range(256) if c != 36] + [36]
SLOT = 4.0

def compare(a, b, tolerance=0.02):
    return len(a) == len(b) and all((x[1:] == y[1:] and abs(x[0] - y[0]) <= tolerance for x, y in zip(a, b)))

def compare_ym(a, b):
    """Preserve each hardware channel's order, global order and 20 ms timing."""

    def partition(events):
        channels = {c: [] for c in range(9)}
        for t, register, value in events:
            channel = value & 7 if register == 8 else register & 7 if register >= 32 else 8
            channels[channel].append((t, register, value))
        return channels
    aa, bb = (partition(a), partition(b))
    return all((compare(aa[c], bb[c]) for c in aa))

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--self-test', action='store_true')
    for n in ('rom-dir', 'workdir', 'receipt'):
        p.add_argument('--' + n, type=Path)
    for n in ('build', 'control', 'baseline-kit', 'x68k-archive'):
        p.add_argument('--' + n, type=Path)
    p.add_argument('--mame', default='mame')
    p.add_argument('--score', choices=('amazon', 'original'), default='amazon')
    a = p.parse_args()
    if a.self_test:
        a0 = [(0.0, 40, 64), (0.001, 41, 80), (0.002, 8, 120)]
        reordered = [a0[1], a0[0], a0[2]]
        assert not compare(a0, reordered) and compare_ym(a0, reordered)
        assert not compare_ym(a0, [*a0[:2], (0.002, 8, 121)])
        assert not compare(a0, [(t + 0.03, r, v) for t, r, v in a0])
        assert not compare_ym([(0, 24, 1), (0, 25, 2)], [(0, 25, 2), (0, 24, 1)])
        print('self-test PASS')
        return 0
    if any((value is None for value in (a.rom_dir, a.workdir, a.receipt))):
        p.error('--rom-dir, --workdir and --receipt are required')
    work = a.workdir.resolve()
    work.mkdir(parents=True, exist_ok=False)
    payloads = {}
    names = ['09.12b', *PS.SAMPLE_MEMBERS['striderua']]
    if a.baseline_kit:
        if a.score == 'amazon' and a.x68k_archive is None or a.build or a.control:
            p.error('baseline-kit mode needs no build/control; Amazon also needs --x68k-archive')
        sys.path.insert(0, str(Path(__file__).resolve().parents[3] / 'release'))
        import private_mister as PM
        import cinematic_music as CM
        import restore_tunes as RT
        with PM.qualified_view(a.baseline_kit.resolve()) as view:
            with zipfile.ZipFile(view / 'games/mame/striderex_us.zip') as z:
                payloads['control'] = {n: z.read(n) for n in names}
        payloads['build'] = dict(payloads['control'])
        if a.score == 'original':
            import original_cinematic as OC
            payloads['build']['09.12b'], _ = OC.install(payloads['control']['09.12b'], 36)
        else:
            bank, _ = RT.load_bank(a.x68k_archive)
            payloads['build']['09.12b'], _ = CM.install(payloads['control']['09.12b'], bank)
    else:
        if not a.build or not a.control:
            p.error('need --build and --control, or --baseline-kit')
        payloads = {label: {n: (root / 'striderua' / n).read_bytes() for n in names} for label, root in (('build', a.build), ('control', a.control))}
    inputs = {}
    for label, files in payloads.items():
        target = work / label / 'roms/striderua'
        target.mkdir(parents=True)
        for q in (a.rom_dir.resolve() / 'striderua').iterdir():
            if q.is_file():
                shutil.copy2(q, target / q.name)
        for name, data in files.items():
            (target / name).write_bytes(data)
        inputs[label] = {n: CF.sha((target / n).read_bytes()) for n in names}

    def run(label):
        print('running', label, flush=True)
        return SG.run(a.mame, work / label / 'roms', 'striderua', work / label / 'run', COMMANDS, SLOT)
    with ThreadPoolExecutor(2) as pool:
        build, control = pool.map(run, ('build', 'control'))
    results = []
    for k, command in enumerate(COMMANDS):
        logs = []
        for r in (build, control):
            t0 = r['slots'][k][1]
            ym = [(t - t0, reg, val) for t, reg, val in r['ym'] if t0 <= t < t0 + SLOT and (not 16 <= reg <= 20)]
            oki = [(t - t0, val) for t, val in r['oki'] if t0 <= t < t0 + SLOT]
            logs.append((ym, oki))
        same_ym, same_oki = (compare(logs[0][0], logs[1][0]), compare(logs[0][1], logs[1][1]))
        results.append(dict(command=hex(command), ym_equal=same_ym, oki_equal=same_oki, ym_writes=[len(x[0]) for x in logs], oki_writes=[len(x[1]) for x in logs], passed=not same_ym and same_oki if command == 36 else same_ym and same_oki))
    report = dict(schema='striderex-cinematic-sound-census/1', inputs=inputs, slot_s=SLOT, comparison='YM and OKI in full order within 20 ms; changed command 0x24 last, all others have identical preceding state', results=results, passed=all((r['passed'] for r in results)))
    a.receipt.write_text(json.dumps(report, indent=2) + '\n')
    for row in results:
        if not row['passed']:
            print('FAIL', row, flush=True)
    print('PASS' if report['passed'] else 'FAIL', 'all 256 sound commands; only 0x24 changes', flush=True)
    return 0 if report['passed'] else 1
if __name__ == '__main__':
    raise SystemExit(main())
