"""CPS-1 graphics ROM encoding for Strider EX."""
import sys
import numpy as np
PLANES = (24, 16, 8, 0)
MB = 1048576

def ex_offset(layer, code):
    if layer in ('obj', 'scr2'):
        assert 32768 <= code <= 49151
        return 128 * (code - 32768)
    if layer == 'scr1':
        assert 32768 <= code <= 49151
        return 2 * MB + 64 * (code - 32768)
    if layer == 'scr3':
        assert 14336 <= code <= 16383
        return 3 * MB + 512 * (code - 14336)
    raise ValueError(layer)

def _put(buf, base, bit, value):
    for p, po in enumerate(PLANES):
        b = bit + po
        mask = 128 >> b % 8
        if value >> 3 - p & 1:
            buf[base + b // 8] |= mask
        else:
            buf[base + b // 8] &= ~mask

def _get(buf, base, bit):
    v = 0
    for p, po in enumerate(PLANES):
        b = bit + po
        v |= (buf[base + b // 8] >> 7 - b % 8 & 1) << 3 - p
    return v

def _xbit(size, x):
    if size == 8:
        return x
    if size == 16:
        return x if x < 8 else 32 + x - 8
    return 32 * (x // 8) + x % 8

def put_tile(buf, base, pens, half=None):
    """Write a square tile of pens (0-15). For 8x8, half = 0 (left/even"""
    n = pens.shape[0]
    row = 64 if n <= 16 else 128
    off = 32 * half if n == 8 else 0
    for y in range(n):
        for x in range(n):
            _put(buf, base, y * row + off + _xbit(n, x), int(pens[y, x]))

def get_tile(buf, base, n, half=None):
    row = 64 if n <= 16 else 128
    off = 32 * half if n == 8 else 0
    out = np.zeros((n, n), np.int32)
    for y in range(n):
        for x in range(n):
            out[y, x] = _get(buf, base, y * row + off + _xbit(n, x))
    return out

def split_region(ex):
    """4 MB EX region -> the four 1 MB ROM_LOAD64_WORD files (offsets 0/2/4/6)."""
    parts = []
    for j in range(4):
        part = bytearray(MB)
        for i in range(0, MB, 2):
            part[i:i + 2] = ex[4 * i + 2 * j:4 * i + 2 * j + 2]
        parts.append(bytes(part))
    return parts

def pce_pen(v):
    """PC Engine color index (0 transparent) -> CPS-1 pen (15 transparent)."""
    return 15 if v == 0 else v - 1

def cps_color(pce9):
    """PC Engine VCE 9-bit GRB -> CPS-1 word (brightness F, 4-bit RGB)."""
    b, r, g = (pce9 & 7, pce9 >> 3 & 7, pce9 >> 6 & 7)
    lv = (0, 2, 4, 6, 9, 11, 13, 15)
    return 61440 | lv[r] << 8 | lv[g] << 4 | lv[b]

def self_test():
    rng = np.random.default_rng(1)
    buf = bytearray(4096)
    for n, half in ((16, None), (32, None), (8, 0), (8, 1)):
        t = rng.integers(0, 16, (n, n))
        put_tile(buf, 512 if n != 32 else 0, t, half)
        assert (get_tile(buf, 512 if n != 32 else 0, n, half) == t).all(), (n, half)
    a, b = (rng.integers(0, 16, (8, 8)), rng.integers(0, 16, (8, 8)))
    put_tile(buf, 1024, a, 0)
    put_tile(buf, 1024, b, 1)
    assert (get_tile(buf, 1024, 8, 0) == a).all() and (get_tile(buf, 1024, 8, 1) == b).all()
    assert ex_offset('scr1', 32768) == 2 * MB and ex_offset('scr3', 14337) == 3 * MB + 512
    assert cps_color(0) == 61440 and cps_color(511) == 65535
    assert all((cps_color(v) >> s & 15 != 1 for v in range(512) for s in (0, 4, 8)))
    print('cps1_gfx self-test passed')
    return 0
if __name__ == '__main__':
    sys.exit(self_test())
