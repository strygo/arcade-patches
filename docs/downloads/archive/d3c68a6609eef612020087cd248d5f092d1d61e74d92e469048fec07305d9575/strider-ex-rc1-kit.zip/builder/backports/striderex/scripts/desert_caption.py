"""Strider EX: the desert's location caption, "Кызылкум" (manifests/desert_intro.json, caption;"""
import argparse
import hashlib
import json
import struct
import sys
from pathlib import Path
import numpy as np
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import cps1_gfx as G
ROOT = HERE.parents[2]
MANIFEST = ROOT / 'backports/striderex/manifests/desert_intro.json'
CODES = (48640, 48703)
SLOT = 29
BLANK = 5664
CENTER_X = 184
TOP_Y = 96
SCREEN = (64, 16)
MAX_GRID = (7, 2)
HOLD = {1: 13, 0: 12}

def manifest():
    return json.loads(MANIFEST.read_text())

def art_path():
    return ROOT / manifest()['caption']['art']

def color_word(rgb):
    """An 8-bit RGB on the CPS-1's 4-bit levels (each channel n * 0x11) -> a palette word at"""
    if any((v % 17 for v in rgb)):
        raise SystemExit(f'desert caption: color {rgb} is not on the CPS-1 4-bit levels')
    r, g, b = (v // 17 for v in rgb)
    return 61440 | r << 8 | g << 4 | b

def convert(path=None):
    """The caption from its PNG: grid, position, cells (16x16 pens, None when empty), palette."""
    from PIL import Image
    path = Path(path or art_path())
    im = np.asarray(Image.open(path).convert('RGBA'))
    a = im[..., 3]
    if not np.isin(a, (0, 255)).all():
        raise SystemExit(f'desert caption: {path.name}: alpha other than 0 and 255')
    rgb = im[..., :3].astype(np.int32)
    cols = sorted({tuple((int(v) for v in p)) for p in rgb[a == 255]}, key=lambda c: (-(299 * c[0] + 587 * c[1] + 114 * c[2]), c))
    if not cols or len(cols) > 15:
        raise SystemExit(f'desert caption: {path.name}: {len(cols)} colors (1-15)')
    pal = [color_word(c) for c in cols] + [61440] * (16 - len(cols))
    pen_of = {c: i for i, c in enumerate(cols)}
    h, w = a.shape
    gc, gr = (-(-w // 16), -(-h // 16))
    if gc > MAX_GRID[0] or gr > MAX_GRID[1]:
        raise SystemExit(f'desert caption: {path.name} is {w}x{h}: wider or taller than {MAX_GRID[0]}x{MAX_GRID[1]} cells')
    left, top = ((16 * gc - w) // 2, 16 * gr - h)
    pens = np.full((16 * gr, 16 * gc), 15, np.int32)
    for y, x in zip(*np.nonzero(a == 255)):
        pens[top + y, left + x] = pen_of[tuple((int(v) for v in rgb[y, x]))]
    cells = []
    for r in range(gr):
        for c in range(gc):
            t = pens[16 * r:16 * r + 16, 16 * c:16 * c + 16]
            cells.append(t.copy() if (t != 15).any() else None)
    x = CENTER_X + SCREEN[0] - 8 * gc
    return dict(art=str(path.relative_to(ROOT)) if path.is_relative_to(ROOT) else str(path), art_sha256=hashlib.sha256(path.read_bytes()).hexdigest(), size=[w, h], cols=gc, rows=gr, x=x, y=TOP_Y, offset=[left, top], pens=pens, cells=cells, palette=pal, colors=cols)

def claims_meet(lo, hi, taken):
    return [(name, u0, u1) for name, (u0, u1) in taken.items() if not (u1 < lo or u0 > hi)]

def install(region, cap, taken):
    """EX codes for the non-empty cells (identical cells share one), upward from CODES[0], written"""
    uniq = {}
    for t in cap['cells']:
        if t is not None:
            uniq.setdefault(t.astype(np.uint8).tobytes(), t)
    n = len(uniq)
    lo, hi = (CODES[0], CODES[0] + n - 1)
    if hi > CODES[1]:
        raise SystemExit(f'desert caption: {n} tiles do not fit {CODES[0]:#x}-{CODES[1]:#x}')
    hit = claims_meet(CODES[0], CODES[1], taken)
    if hit:
        name, u0, u1 = hit[0]
        raise SystemExit(f'desert caption codes {CODES[0]:#x}-{CODES[1]:#x} overlap {name} {u0:#x}-{u1:#x}')
    code_of = {}
    for i, (key, t) in enumerate(uniq.items()):
        off = G.ex_offset('obj', lo + i)
        if any(region[off:off + 128]):
            raise SystemExit(f'desert caption: EX OBJ code {lo + i:#06x} is already used')
        G.put_tile(region, off, t)
        code_of[key] = lo + i
    cap['codes'] = [BLANK if t is None else code_of[t.astype(np.uint8).tobytes()] for t in cap['cells']]
    return dict(art=cap['art'], art_sha256=cap['art_sha256'], codes=[f'{lo:#06x}', f'{hi:#06x}'], tiles=n, cells=len(cap['cells']), grid=[cap['cols'], cap['rows']], sprite_xy=[cap['x'], cap['y']], screen_xy=[cap['x'] - SCREEN[0], cap['y'] - SCREEN[1]], slot=SLOT, palette=[f'{v:#06x}' for v in cap['palette']])

def record(cap):
    """The kind-2 record: count, cols-1, rows-1, attribute (the slot), codes row-major."""
    return [len(cap['codes']), cap['cols'] - 1, cap['rows'] - 1, SLOT] + list(cap['codes'])

def inc_lines(cap):
    L = [f"DZ_CAP_X equ ${cap['x']:X}", f"DZ_CAP_Y equ ${cap['y']:X}", f'DZ_CAP_SLOT equ {SLOT}', '    ifne REGION_EN', f'DZ_CAP_HOLD equ {HOLD[1]}', '    else', f'DZ_CAP_HOLD equ {HOLD[0]}', '    endc', f"dz_cap_record:                          ; the location caption ({cap['art']}): count, cols-1, rows-1, attribute, codes row-major"]
    words = record(cap)
    L.append('        dc.w    ' + ','.join((f'${v:04X}' for v in words[:4])))
    for r in range(cap['rows']):
        row = words[4 + r * cap['cols']:4 + (r + 1) * cap['cols']]
        L.append('        dc.w    ' + ','.join((f'${v:04X}' for v in row)))
    return L

def with_palette(block, cap, actor_slots):
    """The desert's 1 KB OBJ block with the caption's palette in SLOT."""
    import desert_actors_ex as DA
    if SLOT not in DA.ENEMY_SLOTS or SLOT in actor_slots or SLOT in DA.SHARED_SLOTS:
        raise SystemExit(f'desert caption: palette slot {SLOT} is not a free enemy slot')
    words = list(struct.unpack('>512H', block))
    words[16 * SLOT:16 * SLOT + 16] = cap['palette']
    return struct.pack('>512H', *words)

def screen_art(cap):
    """(screen x, screen y, H x W x 4 RGBA) of the caption grid at full brightness, as HBMAME shows"""
    import scene_gate as SG
    p = cap['pens']
    out = np.zeros(p.shape + (4,), np.uint8)
    for pen in range(len(cap['colors'])):
        out[p == pen] = list(SG.hb_rgb(cap['palette'][pen])) + [255]
    return (cap['x'] - SCREEN[0], cap['y'] - SCREEN[1], out)
ROUTINES = {'DZ_OBJS': '41eddeda3e3c001348474a280000670c', 'DZ_SPRITES': '6100009861000370610003546100023a', 'DZ_SYSALLOC': '4a6de9e86712286de9d2225c2b4ce9d2536de9e880004e75', 'DZ_CAPFADE': '7000102800324840e8882468001e383c000f720032120241 0fff824034c151ccfff24e75'.replace(' ', ''), 'cap_obj': '7000102800023 03b00064efb000200080148????02cc'.replace(' ', ''), 'cap_draw': '301932193819362800 0c3a003428 00080c4201c06200001c38c238c338d938c4'.replace(' ', '')}
FADE_PATH = '700010280003303b00064efb0002000400325228003002280001003066 00001e522800320c28001000326700000a6100????4ef8????117c000200034ef8????522800300228000300306600000e532800326500000a6100????4ef8????117c000600024e75'.replace(' ', '')
SYM_NAMES = ['DZ_OBJS', 'DZ_SPRITES', 'DZ_SYSALLOC', 'DZ_CAPFADE', 'DZ_CAPOBJ']

def locate(img):
    """The stock caption pieces in one region's program, shape-checked: the system objects'"""
    import desert_ex as DX
    s = {k: DX.find1(img, p, 'caption ' + k) for k, p in ROUTINES.items()}
    disp = s['DZ_OBJS'] + 40
    if img[disp:disp + 16] != bytes.fromhex('700010280017d040d040227b00044ed1'):
        raise SystemExit("desert caption: the system objects' dispatch has an unexpected shape")
    if DX.be32(img, disp + 16 + 8) != s['cap_obj']:
        raise SystemExit('desert caption: system object kind 2 is not the caption object')
    obj = s.pop('cap_obj')
    s['DZ_CAPOBJ'] = obj
    run = obj + 14 + DX.be16(img, obj + 14 + 2)
    if img[run:run + 16] != bytes.fromhex('7000102800 06d040303b00064efb0002'.replace(' ', '')):
        raise SystemExit("desert caption: the caption's state 2 has an unexpected shape")
    fade = run + 16 + DX.be16(img, run + 16 + 4)
    if DX.find(img, FADE_PATH, fade, fade + len(FADE_PATH) // 2) != [fade]:
        raise SystemExit('desert caption: parameter 2 is not the fade path')
    for at in (fade + 46, fade + 86):
        if at + 2 + struct.unpack('>h', img[at + 2:at + 4])[0] != s['DZ_CAPFADE']:
            raise SystemExit('desert caption: the fade path does not apply DZ_CAPFADE')
    s.pop('cap_draw')
    return s

def stock_caption(img, stage):
    """A stock stage's caption (1-4) from its init entry (the table at DZ_CAPOBJ + 0x60): record"""
    import desert_ex as DX
    obj = locate(img)['DZ_CAPOBJ']
    tab = obj + 96
    if img[tab - 16:tab] != bytes.fromhex('7000102d8cb2d040303b00064efb0002'):
        raise SystemExit("desert caption: the caption init's stage table has an unexpected shape")
    at = tab + DX.be16(img, tab + 2 * stage)
    if img[at:at + 2] != b'!|' or img[at + 6:at + 8] != b'\x00\x1a' or img[at + 8:at + 10] != b'1|' or (img[at + 12:at + 16] != bytes.fromhex('0008317c')) or (img[at + 18:at + 20] != b'\x00\x0c'):
        raise SystemExit(f"desert caption: stage {stage}'s caption init has an unexpected shape")
    rec, x, y = (DX.be32(img, at + 2), DX.be16(img, at + 10), DX.be16(img, at + 16))
    p = at + 20
    if img[p:p + 2] == b'`\x00':
        p = p + 2 + struct.unpack('>h', img[p + 2:p + 4])[0]
    if img[p:p + 10] != bytes.fromhex('267c009140007000103c') or img[p + 10] != 0:
        raise SystemExit(f"desert caption: stage {stage}'s caption palette setup has an unexpected shape")
    n, c1, r1, attr = (DX.be16(img, rec + 2 * i) for i in range(4))
    if n != (c1 + 1) * (r1 + 1) or attr != img[p + 11]:
        raise SystemExit(f"desert caption: stage {stage}'s record is not a full grid in its palette slot")
    return dict(record=rec, x=x, y=y, slot=img[p + 11], cols=c1 + 1, rows=r1 + 1, codes=[DX.be16(img, rec + 8 + 2 * i) for i in range(n)])

def self_test(rom_dir):
    from PIL import Image
    import tempfile
    assert color_word((255, 238, 170)) == 65514 and color_word((51, 17, 0)) == 62224
    with tempfile.TemporaryDirectory() as d:
        im = np.zeros((5, 20, 4), np.uint8)
        im[1:4, 2:18] = [136, 68, 17, 255]
        im[2, 5] = [255, 238, 170, 255]
        p = Path(d) / 'bar.png'
        Image.fromarray(im).save(p)
        cap = convert(p)
        assert (cap['cols'], cap['rows'], cap['offset']) == (2, 1, [6, 11]), cap['offset']
        assert cap['x'] == CENTER_X + SCREEN[0] - 16 and cap['palette'][:2] == [65514, 63553]
        assert cap['pens'][13, 11] == 0 and cap['pens'][12, 8] == 1 and (cap['pens'][0, 0] == 15)
        region = bytearray(G.ex_offset('obj', CODES[1]) + 128)
        rep = install(region, cap, {'other': (32768, CODES[0] - 1)})
        assert cap['codes'] == [CODES[0], CODES[0] + 1] and rep['tiles'] == 2
        back = G.get_tile(region, G.ex_offset('obj', CODES[0]), 16)
        assert (back == cap['pens'][:, :16]).all()
        try:
            install(bytearray(len(region)), cap, {'other': (CODES[0] + 3, CODES[0] + 9)})
            raise AssertionError('an overlap was accepted')
        except SystemExit:
            pass
        bad = im.copy()
        bad[0, 0] = [18, 52, 86, 255]
        Image.fromarray(bad).save(p)
        try:
            convert(p)
            raise AssertionError('an off-level color was accepted')
        except SystemExit:
            pass
    cap = convert()
    print('art', cap['art'], cap['size'], 'grid', cap['cols'], cap['rows'], 'sprite xy', cap['x'], cap['y'], 'cells', sum((t is not None for t in cap['cells'])), 'colors', len(cap['colors']))
    for k in 'ABCDE':
        c = convert(art_path().parent / f'kyzylkum_{k}.png')
        n = sum((t is not None for t in c['cells']))
        assert n <= CODES[1] - CODES[0] + 1, (k, n)
        print(f"candidate {k}: {c['size']} -> {c['cols']}x{c['rows']} cells ({n} drawn), screen X {c['x'] - SCREEN[0]}")
    with tempfile.TemporaryDirectory() as d:
        p = Path(d) / 'wide.png'
        Image.fromarray(np.full((10, 16 * MAX_GRID[0] + 1, 4), 255, np.uint8)).save(p)
        try:
            convert(p)
            raise AssertionError('a caption wider than MAX_GRID was accepted')
        except SystemExit:
            pass
    if rom_dir:
        import title_ex as TX
        import mapper_testkit as K
        import respawn_fix as RF
        gfx = TX.stock_gfx(K.pool([rom_dir / 'striderua']))
        assert (G.get_tile(gfx, 128 * BLANK, 16) == 15).all(), 'the stock blank cell is not all pen 15'
        for m in ('striderua', 'striderjr'):
            files = {q.name: q.read_bytes() for q in (rom_dir / m).iterdir() if q.is_file()}
            img = bytes(RF.compose(files, RF.SETS[m]))
            s = locate(img)
            print(m, {k: f'{v:#x}' for k, v in s.items()})
            sc = [stock_caption(img, k) for k in range(1, 5)]
            assert [(c['x'], c['y'], c['slot'], c['cols'], c['rows']) for c in sc] == [(216, 96, 27, 4, 2), (216, 96, 18, 4, 1), (216, 96, 22, 3, 1), (200, 96, 22, 6, 2)], sc
            assert [c['x'] - SCREEN[0] + 8 * c['cols'] for c in sc] == [CENTER_X, CENTER_X, CENTER_X - 8, CENTER_X]
            assert sc[0]['codes'] == [2784, BLANK, BLANK, BLANK, 2800, 2801, 2802, 2803], sc[0]
    print('desert_caption self-test passed')
    return 0

def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('--self-test', action='store_true')
    p.add_argument('--rom-dir', type=Path)
    a = p.parse_args()
    if a.self_test:
        return self_test(a.rom_dir)
    p.error('give --self-test')
if __name__ == '__main__':
    sys.exit(main())
