"""Portable cinematic-score byte and qualification checks (standard library only)."""
from __future__ import annotations
import argparse
import hashlib
import json
LEGACY = {'prologue': 0, 'brief_st_petersburg': 17, 'intro_desert': 0, 'brief_siberia': 18, 'brief_aerial': 30, 'brief_amazon': 19, 'flight': 0, 'welcome_meio': 31}
SOUND = {'striderua': '09.12b', 'striderjr': 'sth_09.12a'}
ORIGINAL_SCORE = (29440, 885, 'ff3bd685ec3a328ee3f79eaf45804698df55906b698cfd594e9a3e4ed11bf710')
NATIVE_FADE = (1044480, 90, '688537c50d9e7dcff1838557328c7ebd978e3460468300914c3b7829a930ba92')
NATIVE_FADE_CALL = {'striderua': 1048748, 'striderjr': 1048734}
NATIVE_FLOW = (1044480, 278, 'bfafa963e158bd20c40cfac1e00d0fb6ae2b756bcb35f3a35671f7c57302c59e')
NATIVE_CUE_CALL = {'striderua': 1049182, 'striderjr': 1049168}
NATIVE_CUE_ORIGINAL = bytes.fromhex('33c200fff90c33c200fff9bc')
NATIVE_CUE_PATCH = bytes.fromhex('4eb9001ff1004e714e714e71')
READING_START, READING_SIZE = (1044992, 256)
READING_HELPER = {'striderua': '46b54b3af8ad011076e293d4c52363a6cc599cc4e3b9a3ac410cfbcc6312aac3', 'striderjr': '7fbeb8ee340f674b9c088de9bc5700fd27dfbb5b4d69f0814a6ead7b21c1dc74'}
READING_PREVIOUS_BANK = {'striderua': '7826c5cb7f099130f0018a6d994aaeb49656a19b141c600d64fe4f3be6acfafc', 'striderjr': 'aed427c2a54dd80918e7421a7bffd78781e288356d74cd850c2dc2822c69f5b8'}
READING_STEP = {'striderua': 3032, 'striderjr': 2872}
TIP_PARTS = {'strex_gfx.c25': 'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff809f808f808f808f808780878087808780878087808380838083808380838081', 'strex_gfx.c27': 'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff9f9f8f8f8f8f8f8f878787878787878787878787838383838383838383838181', 'strex_gfx.c29': 'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff2f7fafff0f4f9f4f9fef1fdf3f9f3f9f3fbf7fbf7fbf7f7fff7fff7f7f7f7f', 'strex_gfx.c31': 'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffdfffdfffffffffffffffffffffffffffffffffffffffffffffffffff7f7f7f7f'}

def reverse_tip(data, machine, name):
    spans = []
    if name in TIP_PARTS:
        spans = [(31392, bytes(64), bytes.fromhex(TIP_PARTS[name]))]
    if name == {'striderua': 'st-14.8h', 'striderjr': 'sthj_22.7f'}[machine]:
        swap = lambda p: bytes((p[i ^ 1] for i in range(len(p))))
        for at, old, new in ((95768, '010c2820000c350d000c2820000c', '010c2820000c83d6000c2820000c'), (95824, '000c2986000c3505010c2986000c', '000c2986000c83d5010c2986000c')):
            spans.append((at, swap(bytes.fromhex(old)), swap(bytes.fromhex(new))))
    restored = bytearray(data)
    for at, old, new in spans:
        if data[at:at + len(new)] != new:
            raise ValueError('Earth lower-tip bytes differ from the exact contract')
        restored[at:at + len(old)] = old
    return bytes(restored)

def reverse_reading(data, machine, name):
    if name != 'strex_p6.bin':
        return data
    raw = bytearray((data[i ^ 1] for i in range(len(data))))
    at = NATIVE_FADE_CALL[machine] - 1048576
    step = READING_STEP[machine]
    if raw[at:at + 6] != bytes.fromhex('4eb9001ff200') or raw[step:step + 10] != bytes.fromhex('4ef9001ff2804e714e71') or sha(raw[READING_START:READING_START + READING_SIZE]) != READING_HELPER[machine]:
        raise ValueError('reading helper/entries differ from the exact native contract')
    raw[at:at + 6] = bytes.fromhex('4eb9001ff000')
    raw[step:step + 10] = bytes.fromhex('6100fe5c4a7900fff910')
    raw[READING_START:READING_START + READING_SIZE] = b'\xff' * READING_SIZE
    restored = bytes((raw[i ^ 1] for i in range(len(raw))))
    if sha(restored) != READING_PREVIOUS_BANK[machine]:
        raise ValueError('reading changes do not restore the exact Kit v bank')
    return restored
EARTH_PALETTES = (bytes.fromhex('f111fffffccef000f000f9abf000fabdf8acf79bf08af057f045f034f023f000'), bytes.fromhex('f111fffffccef000f000f9abf000fabdf8acf79bf079f057f068f079f08af000'))
EARTH_TILE_PARTS = {'strex_gfx.c25': 'f90131c019e007f803fc00ff00ff007f003f000f000300000000000000000000', 'strex_gfx.c27': 'feffffffffffffffffffffffffff7f7f3f3f0f0f030300000000000000000000', 'strex_gfx.c29': 'fcff3c3f3f3f870763017c003cc00ff01fe003fc03fc01fe007f001f00070003', 'strex_gfx.c31': '00ffc0ffc0fff8fffeffffffffffffffffffffffffffffff7f7f1f1f07070303'}

def tile_spans(machine, name):
    if name in EARTH_TILE_PARTS:
        return [(31456, bytes(32), bytes.fromhex(EARTH_TILE_PARTS[name]))]
    if name == {'striderua': 'st-14.8h', 'striderjr': 'sthj_22.7f'}[machine]:
        old = bytes.fromhex('000c34c2000c34df010c34c3000c3496000c349e000c3497010c')
        new = old[:10] + bytes.fromhex('83d7') + old[12:]
        swap = lambda p: bytes((p[i ^ 1] for i in range(len(p))))
        return [(95632, swap(old), swap(new))]
    return []

def reverse_tile(data, machine, name):
    restored = bytearray(data)
    for at, old, new in tile_spans(machine, name):
        if data[at:at + len(new)] != new:
            raise ValueError('Earth composite/map differs from its exact contract')
        restored[at:at + len(old)] = old
    return bytes(restored)

def earth_spans(machine, name):
    swap = lambda p: b''.join((p[i:i + 2][::-1] for i in range(0, len(p), 2)))
    if machine == 'striderua':
        if name in ('31.12f', '36.12h'):
            side = int(name == '36.12h')
            return [(13985, EARTH_PALETTES[0][side::2], (b'\xf0\x00' + EARTH_PALETTES[0][2:])[side::2])]
        if name == 'st-14.8h':
            return [(326798, swap(EARTH_PALETTES[1]), swap(b'\xf0\x00' + EARTH_PALETTES[1][2:]))]
    elif machine == 'striderjr':
        if name == 'sthj_23.8f':
            return [(289418, swap(EARTH_PALETTES[0]), swap(b'\xf0\x00' + EARTH_PALETTES[0][2:]))]
        if name == 'sthj_22.7f':
            return [(326798, swap(EARTH_PALETTES[1]), swap(b'\xf0\x00' + EARTH_PALETTES[1][2:]))]
    return []

def reverse_earth(data, machine, name):
    restored = bytearray(data)
    for at, old, new in earth_spans(machine, name):
        if data[at:at + len(new)] != new:
            raise ValueError('Earth palette repair differs from its exact source contract')
        restored[at:at + len(old)] = old
    return bytes(restored)

def preceding_files(proof):
    source = proof['native_source_files'] if proof.get('schema') in ('striderex-cinematic-inheritance/5', 'striderex-cinematic-inheritance/6') else proof['build_files']
    files = {m: dict(s) for m, s in source.items()}
    for m, digest in {'striderua': '9b6860315407639f98e2680cc97dced1620e1c9a310463e3758aa07bde0c0349', 'striderjr': '3993e4aee3a7365a17721d7f6cc9205b78471d50da3cf8b990ffb129188d6b51'}.items():
        files[m]['strex_p6.bin'] = digest
    return files

def original_score(proof):
    return proof['schema'] == 'striderex-cinematic-inheritance/2' or proof.get('score') == 'original'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def json_sha(value):
    return sha(json.dumps(value, sort_keys=True, separators=(',', ':')).encode())

def reverse_member(data, machine, name, proof, retain_native=False):
    if proof['schema'] == 'striderex-cinematic-inheritance/6':
        data = reverse_tile(data, machine, name)
    if proof['schema'] in ('striderex-cinematic-inheritance/5', 'striderex-cinematic-inheritance/6'):
        data = reverse_earth(data, machine, name)
    restored = bytearray(data)
    if name == 'strex_p6.bin':
        spec = proof['regions'][machine]
        if proof['schema'] in ('striderex-cinematic-inheritance/4', 'striderex-cinematic-inheritance/5', 'striderex-cinematic-inheritance/6'):
            fade = spec['native_fade']
            start, size, digest = NATIVE_FLOW
            raw = bytes((data[i ^ 1] for i in range(len(data))))
            call = NATIVE_FADE_CALL[machine] - 1048576
            cue = NATIVE_CUE_CALL[machine] - 1048576
            if fade['address'] != 2093056 or fade['end'] != 2093334 or fade['call'] != call + 1048576 or (fade['frames'] != 210) or (fade['interval'] != 6) or (spec['native_opening']['cut_record'] != 2090) or (sha(raw[start:start + size]) != digest) or (raw[call:call + 6] != bytes.fromhex('4eb9001ff000')) or (raw[cue:cue + 12] != NATIVE_CUE_PATCH):
                raise ValueError('native opening differs from the qualified code')
            if not retain_native:
                for i, v in enumerate(bytes.fromhex('527900fff918'), call):
                    restored[i ^ 1] = v
                for i, v in enumerate(NATIVE_CUE_ORIGINAL, cue):
                    restored[i ^ 1] = v
                restored[start:start + size] = b'\xff' * size
        if proof['schema'] == 'striderex-cinematic-inheritance/3':
            fade = spec['native_fade']
            start, size, digest = NATIVE_FADE
            call = fade['call'] - 1048576
            raw = bytes((data[i ^ 1] for i in range(len(data))))
            if fade['call'] != NATIVE_FADE_CALL[machine] or fade['address'] != start + 1048576 or fade['end'] != start + size + 1048576 or (fade['frames'] != 100) or (fade['interval'] != 3) or (sha(raw[start:start + size]) != digest) or (raw[call:call + 6] != bytes.fromhex('4eb9001ff000')):
                raise ValueError('native closing fade differs from the qualified code')
            for i, value in enumerate(bytes.fromhex('527900fff918'), call):
                restored[i ^ 1] = value
            restored[start:start + size] = b'\xff' * size
        if set(spec['scene_order']) != set(LEGACY) or len(spec['scene_order']) != 8:
            raise ValueError('invalid opening-scene table')
        at = spec['table_offset']
        if not 0 <= at < len(data) - 8:
            raise ValueError('invalid cue table address')
        for i, sid in enumerate(spec['scene_order']):
            offset = at + i ^ 1
            if data[offset] != 36:
                raise ValueError('candidate scene does not use the selected score')
            restored[offset] = LEGACY[sid]
    elif name == SOUND[machine]:
        table = 3667
        pointer = table + 2 * 36
        original = original_score(proof)
        target = ORIGINAL_SCORE[0] if original else 28976
        if data[pointer:pointer + 2] != target.to_bytes(2, 'little'):
            raise ValueError('cinematic loop pointer differs')
        restored[pointer:pointer + 2] = data[table:table + 2]
        if original:
            start, size, digest = ORIGINAL_SCORE
            if sha(data[start:start + size]) != digest:
                raise ValueError('original composition differs from the reviewed score')
            restored[start:start + size] = b'\xff' * size
        else:
            restored[28672:28957] = b'\xff' * 285
            restored[28976:29284] = b'\xff' * 308
    return bytes(restored)

def verify(proof, members):
    if proof.get('schema') == 'striderex-cinematic-inheritance/8':
        if not proof.get('passed') or set(members) != set(SOUND) or proof['previous_test_id'] != '261025-11':
            raise ValueError('invalid lower-tip proof')
        previous = proof['previous']['proof']
        restored = {m: {n: reverse_tip(data, m, n) for n, data in files.items()} for m, files in members.items()}
        if proof['baseline_files'] != previous['baseline_files'] or {m: {n: sha(data) for n, data in files.items()} for m, files in members.items()} != proof['build_files'] or {m: {n: sha(data) for n, data in files.items()} for m, files in restored.items()} != previous['build_files']:
            raise ValueError('lower-tip changes do not restore the exact preceding kit')
        return verify(previous, restored)
    if proof.get('schema') == 'striderex-cinematic-inheritance/7':
        if not proof.get('passed') or set(members) != set(SOUND) or proof['previous_test_id'] != '261025-08':
            raise ValueError('invalid reading-time follow-up proof')
        previous = proof['previous']['proof']
        restored = {m: {n: reverse_reading(data, m, n) for n, data in files.items()} for m, files in members.items()}
        if proof['baseline_files'] != previous['baseline_files'] or {m: {n: sha(data) for n, data in files.items()} for m, files in members.items()} != proof['build_files'] or {m: {n: sha(data) for n, data in files.items()} for m, files in restored.items()} != previous['build_files']:
            raise ValueError('reading inventory differs from final or preceding bytes')
        return verify(previous, restored)
    if proof.get('schema') not in tuple(('striderex-cinematic-inheritance/' + n for n in ('1', '2', '3', '4', '5', '6'))) or set(members) != set(SOUND):
        raise ValueError('invalid cinematic follow-up proof')
    if not proof.get('passed'):
        raise ValueError('cinematic byte proof did not pass')
    if proof['schema'] in ('striderex-cinematic-inheritance/3', 'striderex-cinematic-inheritance/4', 'striderex-cinematic-inheritance/5', 'striderex-cinematic-inheritance/6') and proof.get('score') not in ('original', 'amazon'):
        raise ValueError('closing fade needs an explicit score identity')
    for machine, files in members.items():
        old, new = (proof['baseline_files'][machine], proof['build_files'][machine])
        if proof['schema'] in ('striderex-cinematic-inheritance/5', 'striderex-cinematic-inheritance/6') and (set(proof['native_source_files']) != set(members) or set(proof['native_source_files'][machine]) != set(files)):
            raise ValueError('pre-Earth native inventory differs')
        if proof['schema'] == 'striderex-cinematic-inheritance/6' and (set(proof['earth_source_files']) != set(members) or set(proof['earth_source_files'][machine]) != set(files)):
            raise ValueError('pre-composite Earth inventory differs')
        if set(files) != set(old) or set(files) != set(new):
            raise ValueError('candidate member inventory differs')
        for name, data in files.items():
            if sha(data) != new[name] or sha(reverse_member(data, machine, name, proof)) != old[name]:
                raise ValueError('changes outside cinematic data: ' + machine + '/' + name)
            if proof['schema'] in ('striderex-cinematic-inheritance/4', 'striderex-cinematic-inheritance/5', 'striderex-cinematic-inheritance/6') and sha(reverse_member(data, machine, name, proof, True)) != proof['control_files'][machine][name]:
                raise ValueError('native opening control differs from independently reconstructed bytes')
            if proof['schema'] == 'striderex-cinematic-inheritance/6':
                data = reverse_tile(data, machine, name)
                if sha(data) != proof['earth_source_files'][machine][name]:
                    raise ValueError('pre-composite Earth qualification describes different bytes')
            if proof['schema'] in ('striderex-cinematic-inheritance/5', 'striderex-cinematic-inheritance/6') and sha(reverse_earth(data, machine, name)) != proof['native_source_files'][machine][name]:
                raise ValueError('pre-Earth native qualification describes different bytes')
    return True

def validate_qualification(bundle, qualifications, rtl, expected):
    """Validate new focused checks and identify precisely which old checks apply."""
    proof = bundle['proof']
    if proof.get('schema') == 'striderex-cinematic-inheritance/8':
        previous = proof['previous']
        if expected != proof['build_files']:
            raise ValueError('lower-tip final inventory differs')
        validate_qualification(previous, qualifications, rtl, previous['proof']['build_files'])
        validate_tip(bundle, previous['proof']['build_files'], expected)
        return True
    if proof.get('schema') == 'striderex-cinematic-inheritance/7':
        previous = proof['previous']
        if expected != proof['build_files']:
            raise ValueError('reading qualification final inventory differs')
        validate_qualification(previous, qualifications, rtl, previous['proof']['build_files'])
        if bundle.get('reading_runtime', {}).get('runtime') != previous['runtime']['runtime']:
            raise ValueError('reading runtime differs from the qualified prepared driver')
        validate_reading(bundle.get('reading_runtime', {}), previous['proof']['build_files'], expected)
        return True
    if expected != proof['build_files'] or set(qualifications) != {'fixes', 'audio', 'combined'}:
        raise ValueError('cinematic follow-up describes different final files')
    if {s: json_sha(q) for s, q in qualifications.items()} != proof['baseline_qualifications']:
        raise ValueError('inherited qualification differs from the verified baseline')
    if qualifications['combined']['inputs']['test_build'] != proof['baseline_files']:
        raise ValueError('baseline combined qualification describes different files')
    if json_sha(rtl) != proof['baseline_rtl_sha256'] or rtl['build_files'] != proof['baseline_files']:
        raise ValueError('inherited RTL check describes different baseline files')
    runtime = bundle['runtime']
    if runtime.get('runtime') != qualifications['combined']['inputs']['runtime']:
        raise ValueError('cinematic runtime differs from the qualified driver')
    native_expected = proof['native_source_files'] if proof['schema'] in ('striderex-cinematic-inheritance/5', 'striderex-cinematic-inheritance/6') else expected
    wanted = set()
    stage_scenes = {0: ['prologue', 'brief_st_petersburg'], 1: ['brief_siberia'], 2: ['brief_amazon'], 3: ['brief_aerial'], 4: ['flight', 'welcome_meio'], 5: ['intro_desert']}
    for name in ('striderus01', 'striderjs01'):
        for stage, scenes in stage_scenes.items():
            wanted.update(((name, stage, v, None) for v in ('pack', 'other_voice', 'nopack')))
            wanted.update(((name, stage, 'skip', sid) for sid in scenes))
    got = {(r['set'], r['stage'], r['variant'], r.get('scene')) for r in runtime['results']}
    negative = runtime['negative_control']
    if runtime.get('schema') != 'striderex-cinematic-runtime/1' or not runtime['passed'] or (not runtime['full_matrix']) or (runtime['build_files'] != native_expected) or (runtime['control_files'] != proof.get('control_files', proof['baseline_files'])) or (got != wanted) or (len(runtime['results']) != len(wanted)) or (not all((r['passed'] for r in runtime['results']))) or ({(r['set'], r['scene']) for r in negative} != {(s, sid) for s in ('striderus01', 'striderjs01') for sid in LEGACY}) or (not all((r['failed'] for r in negative))):
        raise ValueError('incomplete full-scene cinematic runtime qualification')
    census = bundle['census']
    if census.get('schema') != 'striderex-cinematic-sound-census/1' or not census['passed'] or len(census['results']) != 256 or ({int(r['command'], 16) for r in census['results']} != set(range(256))) or (not all((r['passed'] for r in census['results']))):
        raise ValueError('incomplete cinematic sound-command census')
    for label, files in (('build', expected), ('control', proof['baseline_files'])):
        if set(census['inputs'][label]) != {'09.12b', '18.11c', '19.12c'} or not all((digest == files['striderua'][name] for name, digest in census['inputs'][label].items())):
            raise ValueError('sound census used different ROM bytes')
    loop = bundle['loop']
    if proof['schema'] in ('striderex-cinematic-inheritance/3', 'striderex-cinematic-inheritance/4', 'striderex-cinematic-inheritance/5', 'striderex-cinematic-inheritance/6'):
        for row in runtime['results']:
            if row['variant'] in ('nopack', 'skip'):
                required = {'fade_command', 'laugh_command', 'oki_samples'}
                if not required <= row['checks'].keys() or not all((row['checks'][k] for k in required)):
                    raise ValueError('native fade/laugh runtime checks missing')
                if row['variant'] == 'nopack':
                    if not all((row['checks'].get(k) for k in ('native_attenuation_ramp', 'fade_interval', 'fade_before_laugh'))) or not any((v.get('fade_tail_dbfs', 0) < -90 for v in row['coverage'].values())):
                        raise ValueError('native closing fade did not reach silence')
    if proof['schema'] in ('striderex-cinematic-inheritance/4', 'striderex-cinematic-inheritance/5', 'striderex-cinematic-inheritance/6'):
        checks = runtime.get('native_transition', {})
        if not checks.get('passed') or checks.get('baseline_test_id') != '261024-16' or checks.get('reference_files') != preceding_files(proof) or (len(checks.get('pack_parity', [])) != 24) or (not all((r['passed'] for r in checks['pack_parity']))) or (len(checks.get('continuity', [])) != 4) or (not all((r['passed'] and r['old_restart_rejected'] for r in checks['continuity']))) or (len(checks.get('opening', [])) != 2) or (not all((r['passed'] for r in checks['opening']))) or (not all((r['checks'].get('long_fade', False) for r in runtime['results'] if r['variant'] == 'nopack'))):
            raise ValueError('opening pacing/continuity/long-fade qualification incomplete')
    if proof['schema'] == 'striderex-cinematic-inheritance/5':
        validate_earth(bundle, native_expected, expected)
    if proof['schema'] == 'striderex-cinematic-inheritance/6':
        validate_earth(bundle, native_expected, proof['earth_source_files'])
        validate_tile(bundle, proof['earth_source_files'], expected)
    if original_score(proof):
        start, size, digest = ORIGINAL_SCORE
        patch = loop.get('patch', {})
        played = loop.get('playback', [])
        checked = loop.get('score_checks', [])
        if loop.get('schema') != 'striderex-original-cinematic/1' or not loop.get('passed') or (not loop.get('final_build')) or (patch.get('command') != '0x24') or (patch.get('address') != hex(start)) or (patch.get('size') != size) or (patch.get('sha256') != digest) or any((loop.get('sound_rom_sha256') != files[SOUND[m]] for m, files in expected.items())) or (len(played) != 6) or ({r['channel'] for r in played} != set(range(6))) or (not all((r['period_s'] and 30 < r['period_s'] < 45 and (r['last_note_s'] > 115) for r in played))) or (max((r['period_s'] for r in played)) - min((r['period_s'] for r in played)) > 0.01) or (len(checked) != 6) or ({r['channel'] for r in checked} != set(range(6))) or (not all((r['pitches_match_score'] and r['complete_loops_checked'] >= 3 for r in checked))) or (loop['quietest_quarter_second_dbfs'] <= -60) or (loop['stop_tail_dbfs'] >= -60) or any((r['sound_patch'].get('sha256') != digest or r['sound_patch'].get('command') != '0x24' for r in proof['regions'].values())):
            raise ValueError('original native cinematic loop was not qualified on the final ROM')
        return True
    if not loop['passed'] or not loop['original_phrase_intact'] or loop['patch']['command'] != '0x24' or (loop['results'][1]['loop_period_s'] is None) or (loop['results'][1]['last_note_s'] < 109) or (loop['results'][1]['audible_end_s'] < 109) or any((r['sound_patch']['source_song_sha256'] != loop['patch']['source_song_sha256'] for r in proof['regions'].values())):
        raise ValueError('native cinematic loop was not qualified')
    return True

def validate_reading(report, control, expected):
    rows = report.get('results', [])
    wanted = {(sn, st, variant) for sn in ('striderus01', 'striderjs01') for st in range(6) for variant in ('nopack', 'pack', 'other_voice')}
    wanted |= {(sn, st, 'hold_skip') for sn in ('striderus01', 'striderjs01') for st in (0, 1, 2, 3, 5)}
    negative_wanted = {(sn, st, check) for sn in ('striderus01', 'striderjs01') for st in (0, 1, 2, 3, 5) for check in ('exact_120_frame_pause', 'caption_stays_visible', 'fade_delayed_with_picture')}
    if report.get('schema') != 'striderex-reading-runtime/1' or not report.get('passed') or report.get('build_files') != expected or (report.get('control_files') != control) or (report.get('hold_frames') != 120) or (len(rows) != len(wanted)) or ({(r['set'], r['stage'], r['variant']) for r in rows} != wanted) or (not all((r['passed'] and r.get('exit_codes') == [0, 0] and r['checks'] and all(r['checks'].values()) for r in rows))) or (len(report.get('negative_controls', [])) != 30) or ({(r['set'], r['stage'], r['criterion']) for r in report.get('negative_controls', [])} != negative_wanted) or (not all((r['rejected'] for r in report['negative_controls']))):
        raise ValueError('final-page pause, pack parity, fade and skip qualification incomplete')
    for row in rows:
        variant = row['variant']
        if variant in ('pack', 'other_voice'):
            required = {'frame_and_voice_timing_identical', 'sound_commands_identical', 'ym_identical', 'fade_latch_identical', 'oki_identical'}
        elif variant == 'hold_skip':
            required = {'skip_during_hold', 'skip_returns', 'native_stop', 'no_late_fade', 'skip_prompt', 'gameplay_cue_same'}
        else:
            required = {'one_closing_fade', 'fade_delayed_with_picture', 'three_second_ramp', 'silent_before_laugh', 'interval_six', 'continuous_audible_score', 'quiet_before_native_stop', 'oki_after_handback_unchanged', 'gameplay_music_unchanged'}
            required |= {'unaffected_scene_flow'} if row['stage'] == 4 else {'exact_120_frame_pause', 'caption_stays_visible', 'picture_stays_unchanged', 'last_caption_unchanged', 'all_original_records_preserved', 'handback_delayed_120', 'commands_shift_only_as_intended'}
            if row['stage'] in (0, 4):
                required.add('connected_score_continuity')
        if not required <= row['checks'].keys():
            raise ValueError('reading runtime omits a required behavior check')

def validate_tip(bundle, control, expected):
    runtime = bundle.get('tip_runtime', {})
    render = bundle.get('tip_render', {})
    rows = runtime.get('results', [])
    checks = {'frame_flow_identical', 'registers_and_sound_identical', 'only_two_vram_map_words_changed', 'correct_map_references', 'exact_visible_pixels', 'only_tip_cells_changed', 'old_defect_rejected'}
    wanted = {(sn, flag) for sn in ('striderus01', 'striderjs01') for flag in (0, 1)}
    if runtime.get('schema') != 'striderex-earth-tip-runtime/1' or not runtime.get('passed') or runtime.get('control_files') != control or (runtime.get('build_files') != expected) or (runtime.get('reference_frame') != 1100) or (runtime.get('runtime') != bundle['proof']['previous']['runtime']['runtime']) or (len(rows) != 4) or ({(r['set'], r['flag']) for r in rows} != wanted) or (not all((r['passed'] and r['exit_codes'] == [0, 0] and (set(r['checks']) == checks) and all(r['checks'].values()) and (len(r['pictures']) == 14) and ({p['frame'] for p in r['pictures']} == set(range(1000, 1131, 10))) and all((p['exact_visible_pixels'] and p['only_tip_cells_changed'] for p in r['pictures'])) for r in rows))):
        raise ValueError('lower-tip game qualification incomplete')
    renders = render.get('results', [])
    if render.get('schema') != 'striderex-earth-tip-render/1' or not render.get('passed') or len(renders) != 2 or ({r['machine'] for r in renders} != set(SOUND)):
        raise ValueError('lower-tip core qualification incomplete')
    for r in renders:
        row = next((x for x in rows if x['machine'] == r['machine'] and x['flag'] == 0))
        for label, files in (('control', control), ('build', expected)):
            p = r[label]
            if not p['passed'] or p['build_files'] != files or p['vram_sha256'] != row[label + '_vram_sha256'] or (p['frame'] != 1100) or (p['mode'] != 'frozen-video') or (not p['graphics_ram_preserved']) or (p['exit_code'] != 0) or (p['harness_sha256'] != '5d7963b8dfef58d36f8eae9853f4a48b2b2293ef99351dc695a54644cc55c97c') or (p['model_sha256'] != '2925ae33929d5465406c06c98fd364c6ad1a2d32b8ec98d1547281f3fc027054'):
                raise ValueError('lower-tip core input/model mismatch')
        if not r['passed'] or not r['exact_visible_pixels'] or (not r['old_defect_rejected']) or (r['changed_pixels'] <= 0) or (r['control']['registers_sha256'] != r['build']['registers_sha256']):
            raise ValueError('lower-tip core pixels differ')
        count = {'striderua': 174, 'striderjr': 162}[r['machine']]
        reference = next((p for p in row['pictures'] if p['frame'] == 1100))
        if r['changed_pixels'] != count or reference['changed_pixels'] != count or r['occluded_repair_pixels'] != 0 or (reference['occluded_repair_pixels'] != 0):
            raise ValueError('lower-tip reference pixels do not match the complete unoccluded repair')

def validate_earth(bundle, control, expected):
    runtime = bundle.get('earth_runtime', {})
    wanted = {(sn, flag) for sn in ('striderus01', 'striderjs01') for flag in (0, 1)}
    rows = runtime.get('results', [])
    checks = {'pictures_identical', 'frame_flow_identical', 'registers_and_sound_identical', 'both_background_pens_corrected', 'only_these_vram_words_differ'}
    if runtime.get('schema') != 'striderex-earth-runtime/1' or not runtime.get('passed') or runtime.get('control_files') != control or (runtime.get('build_files') != expected) or (runtime.get('runtime') != bundle['runtime']['runtime']) or (len(rows) != 4) or ({(r['set'], r['flag']) for r in rows} != wanted) or (not all((r['passed'] and set(r['checks']) == checks and all(r['checks'].values()) and (len(r['pictures']) == 12) and ({p['frame'] for p in r['pictures']} == set(range(1140, 1471, 30))) and all((p['identical'] for p in r['pictures'])) for r in rows))):
        raise ValueError('Earth repair runtime qualification incomplete')
    render = bundle.get('earth_render', {})
    results = render.get('results', [])
    if render.get('schema') != 'striderex-earth-render-comparison/1' or not render.get('passed') or len(results) != 2 or ({r['machine'] for r in results} != set(SOUND)):
        raise ValueError('Earth repair core rendering incomplete')
    for row in results:
        machine = row['machine']
        sn = 'striderus01' if machine == 'striderua' else 'striderjs01'
        gate = next((r for r in rows if r['set'] == sn and r['flag'] == 0))
        for label, files, vram in (('control', control, gate['control_capture_vram_sha256']), ('build', expected, gate['capture_vram_sha256'])):
            r = row[label]
            if not r['passed'] or r['mode'] != 'frozen-video' or r['build_files'] != files or (r['machine'] != machine) or (r['frame'] != 1300) or (r['vram_sha256'] != vram) or (not r['graphics_ram_preserved']) or (r['exit_code'] != 0) or (r['harness_sha256'] != '5d7963b8dfef58d36f8eae9853f4a48b2b2293ef99351dc695a54644cc55c97c') or (r['model_sha256'] != '2925ae33929d5465406c06c98fd364c6ad1a2d32b8ec98d1547281f3fc027054'):
                raise ValueError('Earth core render used different game data or model')
        if row['control']['registers_sha256'] != row['build']['registers_sha256']:
            raise ValueError('Earth render changed its video registers')
        if not row['passed'] or not row['visible_art_unchanged'] or row['changed_pixels'] < 1000 or (row['old_rgb'] != [[15, 15, 15]]) or (row['new_rgb'] != [[0, 0, 0]]):
            raise ValueError('Earth rendering changed pixels outside its false black fills')

def validate_tile(bundle, control, expected):
    runtime = bundle.get('tile_runtime', {})
    rows = runtime.get('results', [])
    wanted = {(sn, flag) for sn in ('striderus01', 'striderjs01') for flag in (0, 1)}
    checks = {'frame_flow_identical', 'registers_and_sound_identical', 'only_one_vram_map_word_changed', 'correct_map_reference', 'only_lower_half_pixels_changed', 'exact_reference_pixels', 'old_gap_rejected'}
    frames = set(range(1140, 1471, 30)) | {1300}
    if runtime.get('schema') != 'striderex-earth-tile-runtime/1' or not runtime.get('passed') or runtime.get('control_files') != control or (runtime.get('build_files') != expected) or (runtime.get('runtime') != bundle['runtime']['runtime']) or (len(rows) != 4) or ({(r['set'], r['flag']) for r in rows} != wanted) or (not all((r['passed'] and set(r['checks']) == checks and all(r['checks'].values()) and (len(r['pictures']) == 13) and ({p['frame'] for p in r['pictures']} == frames) and all((p['only_lower_half_changed'] and p['changed_pixels'] == 61 for p in r['pictures'])) for r in rows))):
        raise ValueError('Earth composite runtime qualification incomplete')
    render = bundle.get('tile_render', {})
    results = render.get('results', [])
    if render.get('schema') != 'striderex-earth-tile-render/1' or not render.get('passed') or len(results) != 2 or ({r['machine'] for r in results} != set(SOUND)):
        raise ValueError('Earth composite core rendering incomplete')
    for row in results:
        machine = row['machine']
        sn = 'striderus01' if machine == 'striderua' else 'striderjs01'
        gate = next((r for r in rows if r['set'] == sn and r['flag'] == 0))
        for label, files in (('control', control), ('build', expected)):
            r = row[label]
            if not r['passed'] or r['mode'] != 'frozen-video' or r['build_files'] != files or (r['machine'] != machine) or (r['frame'] != 1300) or (r['vram_sha256'] != gate[label + '_vram_sha256']) or (not r['graphics_ram_preserved']) or (r['exit_code'] != 0) or (r['harness_sha256'] != '5d7963b8dfef58d36f8eae9853f4a48b2b2293ef99351dc695a54644cc55c97c') or (r['model_sha256'] != '2925ae33929d5465406c06c98fd364c6ad1a2d32b8ec98d1547281f3fc027054'):
                raise ValueError('Earth composite render used different game data or model')
        if not row['passed'] or not row['exact_reference_pixels'] or (not row['old_gap_rejected']) or (row['changed_pixels'] != 61) or (row['control']['registers_sha256'] != row['build']['registers_sha256']):
            raise ValueError('Earth composite rendering did not repair exactly the missing shadow')

def self_test():
    old, new, regions = ({}, {}, {})
    for machine, name in SOUND.items():
        program = bytearray(1048576)
        order = list(LEGACY)
        for i, sid in enumerate(order):
            program[256 + i ^ 1] = LEGACY[sid]
        sound = bytearray(b'\xff' * 65536)
        sound[3667:3669] = b'4\x12'
        sound[3739:3741] = b'4\x12'
        old[machine] = {'strex_p6.bin': bytes(program), name: bytes(sound)}
        for i in range(8):
            program[256 + i ^ 1] = 36
        sound[3739:3741] = b'0q'
        sound[28672:28957] = b'U' * 285
        sound[28976:29284] = b'f' * 308
        new[machine] = {'strex_p6.bin': bytes(program), name: bytes(sound)}
        regions[machine] = dict(table_offset=256, scene_order=order)
    proof = dict(schema='striderex-cinematic-inheritance/1', passed=True, regions=regions, baseline_files={m: {n: sha(b) for n, b in fs.items()} for m, fs in old.items()}, build_files={m: {n: sha(b) for n, b in fs.items()} for m, fs in new.items()})
    assert verify(proof, new)
    changed = bytearray(new['striderua']['strex_p6.bin'])
    changed[512] ^= 1
    new['striderua']['strex_p6.bin'] = bytes(changed)
    proof['build_files']['striderua']['strex_p6.bin'] = sha(changed)
    try:
        verify(proof, new)
    except ValueError:
        pass
    else:
        raise AssertionError('executable change incorrectly inherited qualification')
    proof['schema'] = 'striderex-cinematic-inheritance/2'
    try:
        reverse_member(new['striderua'][SOUND['striderua']], 'striderua', SOUND['striderua'], proof)
    except ValueError:
        pass
    else:
        raise AssertionError('original score contract accepted the alternate Amazon song')
    wrong_score = bytearray(new['striderua'][SOUND['striderua']])
    wrong_score[3739:3741] = ORIGINAL_SCORE[0].to_bytes(2, 'little')
    try:
        reverse_member(bytes(wrong_score), 'striderua', SOUND['striderua'], proof)
    except ValueError:
        pass
    else:
        raise AssertionError('original score contract accepted unreviewed sequence bytes')
    from copy import deepcopy
    code = bytes.fromhex('527900fff918083a00000ff5663e4a7900fff9bc67364a3900fff9ba662e7000103900fff93c5340b07c0005621ed040303b001cb0b900fff900661033fc00030080018833fc00fb00fff9164e750710050706c105300813045f')
    assert len(code) == NATIVE_FADE[1] and sha(code) == NATIVE_FADE[2]
    p = dict(schema='striderex-cinematic-inheritance/3', score='amazon', regions={})
    raw = bytearray(b'\xff' * 1048576)
    for i, sid in enumerate(LEGACY):
        raw[256 + i] = LEGACY[sid]
    raw[172:178] = bytes.fromhex('527900fff918')
    baseline = bytes(raw)
    raw[256:264] = b'$' * 8
    raw[172:178] = bytes.fromhex('4eb9001ff000')
    raw[1044480:1044570] = code
    p['regions']['striderua'] = dict(table_offset=256, scene_order=list(LEGACY), native_fade=dict(call=1048748, address=2093056, end=2093146, frames=100, interval=3))
    swap = lambda x: bytes((x[i ^ 1] for i in range(len(x))))
    assert reverse_member(swap(raw), 'striderua', 'strex_p6.bin', p) == swap(baseline)
    for at in (172, 1044543, 1044559):
        bad = bytearray(raw)
        bad[at] ^= 1
        try:
            reverse_member(swap(bad), 'striderua', 'strex_p6.bin', p)
        except ValueError:
            pass
        else:
            raise AssertionError('changed closing fade accepted')
    bad = deepcopy(p)
    bad['regions']['striderua']['native_fade']['call'] += 2
    try:
        reverse_member(swap(raw), 'striderua', 'strex_p6.bin', bad)
    except ValueError:
        pass
    else:
        raise AssertionError('moved fade call accepted')
    code = bytes.fromhex('527900fff918083a00000ff566624a3900fff9ba67220c39000100fff93c66500cb90000082a00fff9006644614433fc000100fff9104e750c79002400fff9bc662e7000103900fff93c5340b07c0005621ed040303b0058b0b900fff900661033fc00060080018833fc00fb00fff9164e75303900fff984672c343900fff986760143f90090000041f10000320222d822d851c9fffa43f90090080051cbffea42b900fff98442b900fff9804e7506a20499065304c207a503f1')
    code += b'\xff' * (256 - len(code))
    code += bytes.fromhex('b47900fff9bc670c33c200fff90c33c200fff9bc4e75')
    assert len(code) == NATIVE_FLOW[1] and sha(code) == NATIVE_FLOW[2]
    for machine in SOUND:
        call = NATIVE_FADE_CALL[machine] - 1048576
        cue = NATIVE_CUE_CALL[machine] - 1048576
        raw = bytearray(b'\xff' * 1048576)
        raw[call:call + 6] = bytes.fromhex('527900fff918')
        raw[cue:cue + 12] = NATIVE_CUE_ORIGINAL
        raw[2048:2056] = bytes(LEGACY.values())
        baseline = swap(raw)
        raw[call:call + 6] = bytes.fromhex('4eb9001ff000')
        raw[cue:cue + 12] = NATIVE_CUE_PATCH
        raw[2048:2056] = b'$' * 8
        raw[1044480:1044758] = code
        p = dict(schema='striderex-cinematic-inheritance/4', score='original', regions={machine: dict(table_offset=2048, scene_order=list(LEGACY), native_opening={'cut_record': 2090}, native_fade=dict(call=call + 1048576, address=2093056, end=2093334, frames=210, interval=6))})
        assert reverse_member(swap(raw), machine, 'strex_p6.bin', p) == baseline
        control = reverse_member(swap(raw), machine, 'strex_p6.bin', p, True)
        assert control != baseline and swap(control)[cue:cue + 12] == NATIVE_CUE_PATCH
        for address in (call, cue, 1044543, 1044736, 1044756):
            bad = bytearray(raw)
            bad[address] ^= 1
            try:
                reverse_member(swap(bad), machine, 'strex_p6.bin', p)
            except ValueError:
                pass
            else:
                raise AssertionError('altered native flow accepted')
    for machine, names in {'striderua': ('31.12f', '36.12h', 'st-14.8h'), 'striderjr': ('sthj_23.8f', 'sthj_22.7f')}.items():
        for name in names:
            at, old, new = earth_spans(machine, name)[0]
            data = bytearray(b'\xff' * (at + len(new) + 8))
            data[at:at + len(new)] = new
            restored = reverse_earth(data, machine, name)
            assert restored[at:at + len(old)] == old
            data[at + len(new) - 1] ^= 1
            try:
                reverse_earth(data, machine, name)
            except ValueError:
                pass
            else:
                raise AssertionError('foreign Earth palette accepted')
    for machine in SOUND:
        names = tuple(EARTH_TILE_PARTS) + ({'striderua': 'st-14.8h', 'striderjr': 'sthj_22.7f'}[machine],)
        for name in names:
            at, old, new = tile_spans(machine, name)[0]
            data = bytearray(b'\xff' * (at + len(new) + 8))
            data[at:at + len(new)] = new
            assert reverse_tile(data, machine, name)[at:at + len(old)] == old
            data[at + len(new) - 1] ^= 1
            try:
                reverse_tile(data, machine, name)
            except ValueError:
                pass
            else:
                raise AssertionError('foreign Earth tile/map accepted')
    print('self-test PASS')

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--self-test', action='store_true')
    a = p.parse_args()
    if a.self_test:
        return self_test()
    p.print_help()
if __name__ == '__main__':
    main()
