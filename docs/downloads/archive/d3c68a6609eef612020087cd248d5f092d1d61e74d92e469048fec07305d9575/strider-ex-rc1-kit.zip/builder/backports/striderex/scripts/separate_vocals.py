"""P0.12 route 2: can the PC Engine cinematic voices be removed from their"""
import argparse
import hashlib
import json
import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[3]
TRANSCRIPTS = ROOT / 'backports/striderex/manifests/pce_cinematic_transcripts.json'
SECTOR, RATE = (2352, 44100)

def speech_spans(track):
    data = json.loads(TRANSCRIPTS.read_text())
    for t in data['tracks']:
        if t['track'] == track:
            return [(s['start'], s['end']) for s in t['segments']]
    sys.exit(f'track {track} has no transcript')

def gaps(spans, total, min_len=0.5):
    out, cur = ([], 0.0)
    for s0, s1 in sorted(spans):
        if s0 - cur >= min_len:
            out.append((cur, s0))
        cur = max(cur, s1)
    if total - cur >= min_len:
        out.append((cur, total))
    return out

def power(x, spans, rate, band=None):
    import numpy as np
    mono = x.mean(0) if x.ndim == 2 else x
    if band:
        import numpy.fft as F
        spec = F.rfft(mono)
        f = F.rfftfreq(len(mono), 1 / rate)
        spec[(f < band[0]) | (f > band[1])] = 0
        mono = F.irfft(spec, len(mono))
    parts = [mono[int(a * rate):int(b * rate)] for a, b in spans]
    parts = [p for p in parts if len(p)]
    return float(np.mean(np.concatenate(parts) ** 2)) if parts else float('nan')

def db(a, b):
    import math
    return round(10 * math.log10(a / b), 2) if a > 0 and b > 0 else None

def separate(a):
    import numpy as np
    import random
    import soundfile as sf
    import torch
    from demucs.apply import apply_model
    from demucs.pretrained import get_model
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    from cinematic_transcripts import cue_tracks
    torch.manual_seed(0)
    random.seed(0)
    a.workdir.mkdir(parents=True, exist_ok=True)
    model = get_model(a.model)
    model.eval()
    device = a.device
    if device == 'auto':
        device = 'mps' if torch.backends.mps.is_available() else 'cpu'
    tracks = cue_tracks(a.cue)
    ckpt_dir = Path(torch.hub.get_dir()) / 'checkpoints'
    report = dict(model=a.model, device=device, shifts=a.shifts, demucs_sources=list(model.sources), checkpoints={p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(ckpt_dir.glob('*.th'))}, tracks=[])
    for t in a.tracks:
        bin_path, index01 = tracks[t]
        raw = bin_path.read_bytes()[round(index01 * 75) * SECTOR:]
        pcm = np.frombuffer(raw[:len(raw) // 4 * 4], '<i2').reshape(-1, 2).T.astype(np.float32) / 32768
        wav = torch.from_numpy(pcm)
        ref = wav.mean(0)
        x = (wav - ref.mean()) / ref.std()
        with torch.no_grad():
            out = apply_model(model, x[None], device=device, shifts=a.shifts, split=True, overlap=0.25, progress=False)[0]
        out = out * ref.std() + ref.mean()
        stems = {name: out[i].cpu().numpy() for i, name in enumerate(model.sources)}
        vocals = stems['vocals']
        bed = sum((v for k, v in stems.items() if k != 'vocals'))
        for name, sig in (('mix', pcm), ('vocals', vocals), ('bed', bed)):
            sf.write(a.workdir / f'tr{t:02d}_{name}.wav', np.clip(sig.T, -1, 1), RATE, subtype='PCM_16')
        total = pcm.shape[1] / RATE
        speech = speech_spans(t)
        music = gaps(speech, total)
        band = (300, 3400)
        row = dict(track=t, seconds=round(total, 2), speech_lines=len(speech), speech_seconds=round(sum((b - s for s, b in speech)), 2), music_seconds=round(sum((b - s for s, b in music)), 2), speech_band_cut_db=db(power(bed, speech, RATE, band), power(pcm, speech, RATE, band)), music_kept_db=db(power(bed, music, RATE), power(pcm, music, RATE)), vocals_off_speech_db=db(power(vocals, music, RATE), power(vocals, speech, RATE)), bin_sha256=hashlib.sha256(raw).hexdigest())
        report['tracks'].append(row)
        print(json.dumps(row))
    (a.workdir / 'separation.json').write_text(json.dumps(report, indent=1) + '\n')
    return 0

def residual_asr(a):
    from faster_whisper import WhisperModel
    model = WhisperModel('large-v3', device='cpu', compute_type='int8')
    rep = json.loads((a.workdir / 'separation.json').read_text())
    for row in rep['tracks']:
        t = row['track']
        for name in ('mix', 'bed'):
            segs, _ = model.transcribe(str(a.workdir / f'tr{t:02d}_{name}.wav'), language='ja', beam_size=5, temperature=0.0, vad_filter=True, condition_on_previous_text=False)
            segs = [dict(start=round(s.start, 2), end=round(s.end, 2), text=s.text.strip(), no_speech_prob=round(s.no_speech_prob, 3)) for s in segs]
            row[f'asr_{name}'] = dict(segments=len(segs), characters=sum((len(s['text']) for s in segs)), lines=segs)
        print(f"tr{t}: mix {row['asr_mix']['characters']} chars in {row['asr_mix']['segments']} segments; bed {row['asr_bed']['characters']} chars in {row['asr_bed']['segments']} segments")
        for s in row['asr_bed']['lines']:
            print(f"   bed {s['start']:6.2f}-{s['end']:6.2f} {s['text']}")
    (a.workdir / 'separation.json').write_text(json.dumps(rep, ensure_ascii=False, indent=1) + '\n')
    return 0

def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('command', choices=['separate', 'residual-asr'])
    p.add_argument('--workdir', type=Path, required=True)
    p.add_argument('--cue', type=Path, help='restored PCE disc cue sheet (separate)')
    p.add_argument('--tracks', type=int, nargs='+', default=[21, 24])
    p.add_argument('--model', default='htdemucs_ft')
    p.add_argument('--shifts', type=int, default=1)
    p.add_argument('--device', default='auto', help='auto, cpu or mps')
    a = p.parse_args()
    if a.command == 'separate':
        if not a.cue:
            p.error('separate needs --cue')
        return separate(a)
    return residual_asr(a)
if __name__ == '__main__':
    sys.exit(main())
