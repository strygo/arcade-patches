"""Strider EX caption pacing: when each spoken line starts and ends in the track the CPS+ pack"""
import argparse
import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
ROOT = Path(__file__).resolve().parents[3]
HERE = ROOT / 'backports/striderex'
M = HERE / 'manifests'
VOICE_MANIFEST = M / 'caption_voice.json'
SUBTITLES = M / 'subtitles.json'
CUES = M / 'ex_pack_cues.json'
FIT = M / 'dub_fit.json'
TAKES = M / 'dub_takes.json'
BEDS = M / 'dub_beds.json'
CPS1_HZ = 59.637
PCE_HZ = 59.826
SPRITE_LEAD = 2
BLANK_LINES = 38
LINES = 262
CUE_RECORD = 0.5
CUE_SLACK = 0.5
BAND = (200.0, 5000.0)
HOP = 0.005
WIN = 0.02
BELOW = 30.0
FLOOR = -72.0
MIN_RUN = 0.04
BRIDGE = 0.08
PAUSE = 0.15
ATTACH = 1.0
NONVERBAL_PAD = 0.2
RATE44, RATE48 = (44100, 48000)
LEAD = 4
LAG = 12
MIN_PAGE = 1.0
MIN_INNER = 0.6
CHAIN = 0.35
SNAP = 0.8
ON_EARLY, ON_LATE = (0.25, 1.5 / CPS1_HZ)
OFF_EARLY, OFF_LATE = (1.5 / CPS1_HZ, 0.75)
RULE_TOL = 1.0 + CUE_SLACK
PACK = dict(sha256='2cd4b039994a9e79386cfef1140a7c1a36fb8092402a1bbed56163714bee330e', bytes=80960520, windows=True, note="Petersburg, desert and Siberia rows at 0xA9-0xAB, the START skip's fade (0xFC fade_out, law 1, const1 23). Before: kit i's a3548b05 (mix 7, no windows), 060e039b (mix 7, windows; kits j and k), a089c1fb (mix 8, the Japanese rows at 0xFC-0xFE in the control region), branch packs 1d5f97e4, 035eaae6, 5a6616d6 and 6b2d37c0, then 58c96dc3 (mix 9; build 46, kit l), then a8059672 (mix 10; build 47, kit m), then 02d2601f (mix 11; build 48)")
SCENE_TRACK = {'prologue': 21, 'brief_st_petersburg': 22, 'intro_desert': 23, 'brief_siberia': 24, 'brief_aerial': 25, 'brief_amazon': 26, 'flight': 27, 'welcome_meio': 28}
VARIANTS = [('ja', 'ja', 'ja'), ('ja', 'en', 'en'), ('en', 'en', 'en_dub')]

def load(p):
    return json.loads(Path(p).read_text(encoding='utf-8'))

def file_sha(p):
    h = hashlib.sha256()
    with open(p, 'rb') as f:
        for chunk in iter(lambda: f.read(1 << 22), b''):
            h.update(chunk)
    return h.hexdigest()

def envelope(x, rate):
    """(times, dB): the BAND envelope of mono x, WIN RMS every HOP."""
    import numpy as np
    from scipy.signal import butter, sosfiltfilt
    y = sosfiltfilt(butter(4, BAND, 'bandpass', fs=rate, output='sos'), np.asarray(x, np.float64))
    c = np.concatenate([[0.0], np.cumsum(y * y)])
    hop, half = (int(round(rate * HOP)), int(round(rate * WIN / 2)))
    centers = np.arange(0, len(y), hop)
    a, b = (np.clip(centers - half, 0, len(y)), np.clip(centers + half, 0, len(y)))
    rms = np.sqrt((c[b] - c[a]) / np.maximum(b - a, 1) + 1e-20)
    return (centers / rate, 20 * np.log10(rms))

def runs_of(mask, t):
    """[[start, end]] seconds of True runs (a run's end is its last frame + HOP)."""
    import numpy as np
    m = np.concatenate([[False], np.asarray(mask, bool), [False]])
    d = np.diff(m.astype(np.int8))
    starts, ends = (np.nonzero(d == 1)[0], np.nonzero(d == -1)[0])
    return [[float(t[s]), float(t[e - 1]) + HOP] for s, e in zip(starts, ends)]

def clean_runs(rs):
    """Close gaps under BRIDGE, then drop runs under MIN_RUN."""
    out = []
    for s, e in rs:
        if out and s - out[-1][1] < BRIDGE:
            out[-1][1] = e
        else:
            out.append([s, e])
    return [[round(s, 3), round(e, 3)] for s, e in out if e - s >= MIN_RUN]

def line_activity(t, e, lo, hi, ref_lo, ref_hi):
    """Voice runs of one line inside [lo, hi], thresholded against its level over [ref_lo, ref_hi]."""
    import numpy as np
    inref = (t >= ref_lo) & (t <= ref_hi)
    w = (t >= lo) & (t <= hi)
    ref = float(np.percentile(e[inref if inref.any() else w], 95))
    act = w & (e > max(ref - BELOW, FLOOR))
    return (clean_runs(runs_of(act, t)), ref)

def stems(track):
    """(vocals, other) float32 (2, n) at 44.1 kHz, each checked against its pin."""
    import dub_beds as B
    man = B.manifest()
    v = man['params']['variants'][0]
    return B.external_stems(v, man['inputs']['external_separations'][v], track)

def takes_dir():
    st = load(TAKES)['store']
    return (ROOT / 'roms').resolve().parent / st['path']

def take(lid):
    """An approved take as dub_mix reads it, checked against its pin (dub_takes.json)."""
    import dub_mix as DM
    pin = load(TAKES)['lines'][lid]['wav_sha256']
    f = takes_dir() / f'{lid}.wav'
    if not f.exists() or file_sha(f) != pin:
        sys.exit(f'{f}: missing or not the pinned {pin[:16]} (dub_takes.json; references/separations/README.md)')
    return DM.read_any_wav(f)

def pack_reader(path):
    sys.path.insert(0, str(ROOT))
    from cpsplus.pack.format import PackReader
    if file_sha(path) != PACK['sha256']:
        sys.exit(f"{path}: not the pinned pack {PACK['sha256'][:16]} ({PACK['note']})")
    return PackReader(path)

def pack_track(rd, command):
    """A pack row's audio, decoded as the player plays it: float64 (2, n) at 48 kHz."""
    import numpy as np
    from cpsplus.pack import audition
    row = rd.triggers[command]
    pcm = audition._decode_track(rd, row.track)
    return np.frombuffer(pcm, '<i2').reshape(-1, 2).T.astype(np.float64) / 32768

def pack_head(cues, sid):
    """Disc samples (44.1 kHz from INDEX 01) before a pack row's first sample: a pack with the scene windows"""
    return round(cues[sid]['window_s'][0] * RATE44) if PACK.get('windows') else 0

def to48(x):
    """44.1 -> 48 kHz as the pack builder resamples (build_strider_ex.cinematic_pcm)."""
    from scipy import signal
    return signal.resample_poly(x, 160, 147, axis=-1, window=('kaiser', 8.6))

def subtitle_lines():
    return load(SUBTITLES)['lines']

def nonverbal(track):
    return [(r['start'], r['end']) for r in load(FIT).get('restore_original', []) if r['track'] == track]

def ja_voice(track, vocals):
    """{line id: dict(on, off, runs, ref_db)} of the Japanese voice in one track (every transcribed line,"""
    import numpy as np
    lines = sorted((l for l in subtitle_lines() if l['track'] == track and (not l.get('dub_only'))), key=lambda l: l['start'])
    t, e = envelope(vocals.mean(0), RATE44)
    for a, b in nonverbal(track):
        e[(t >= a - NONVERBAL_PAD) & (t <= b + NONVERBAL_PAD)] = -200.0
    refs = []
    for l in lines:
        inl = (t >= l['start']) & (t <= l['end'])
        refs.append(float(np.percentile(e[inl], 95)))
    tref = float(np.median(refs))
    quiet = e <= max(tref - BELOW, FLOOR)
    splits = []
    for k in range(len(lines) - 1):
        a, b = (lines[k]['end'], lines[k + 1]['start'])
        mid = (a + b) / 2
        lo, hi = (min(a, b) - 0.5, max(a, b) + 0.5)
        w = (t >= lo) & (t <= hi)
        gaps = [g for g in runs_of(quiet & w, t) if g[1] - g[0] >= MIN_RUN]
        if gaps:
            g = max(gaps, key=lambda g: (round(g[1] - g[0], 3), -abs((g[0] + g[1]) / 2 - mid)))
            splits.append((g[0] + g[1]) / 2)
        else:
            splits.append(mid)
    out = {}
    for k, l in enumerate(lines):
        lo = l['start'] - ATTACH if k == 0 else max(l['start'] - ATTACH, splits[k - 1])
        hi = l['end'] + ATTACH if k == len(lines) - 1 else min(l['end'] + ATTACH, splits[k])
        rs, ref = line_activity(t, e, lo, hi, l['start'], l['end'])
        if not rs:
            sys.exit(f"{l['id']}: no Japanese voice found in {lo:.2f}-{hi:.2f} s")
        out[l['id']] = dict(on=rs[0][0], off=rs[-1][1], runs=rs, ref_db=round(ref, 1), window=[round(lo, 3), round(hi, 3)])
    return out

def en_voice(track):
    """{line id: dict(on, off, runs, placed, ...)} of the English dub in one track: every take placed as"""
    import dub_mix as DM
    fit, subs = (DM.fit_plan(), DM.subtitle_index())
    slots = DM.slots_for(track, fit, subs)
    out = {}
    for k, (lid, slot) in enumerate(slots):
        nxt = slots[k + 1][1]['start'] if k + 1 < len(slots) else None
        x, s, e_, ratio, limit_end, notes = DM.place_line(take(lid), slot, nxt, fit['defaults']['min_gap'])
        if fit['defaults'].get('hush'):
            x = DM.hush(x)
        x = DM.post_chain(x, fit['speakers'].get(DM.speaker_key(slot['speaker']), {}).get('post'))
        a = int(round(s * RATE44))
        t, e = envelope(x, RATE44)
        t = t + a / RATE44
        rs, ref = line_activity(t, e, t[0], t[-1], t[0], t[-1])
        out[lid] = dict(on=rs[0][0], off=rs[-1][1], runs=rs, ref_db=round(ref, 1), placed=[round(a / RATE44, 3), round((a + len(x)) / RATE44, 3)], ratio=round(ratio, 4), _x=x, _a=a)
    return out

def xcorr_lag(a, b, max_lag):
    """The lag (samples) at which b best matches a (b[n] ~ a[n + lag]), FFT cross-correlation."""
    import numpy as np
    n = len(a) + len(b)
    nf = 1 << (n - 1).bit_length()
    c = np.fft.irfft(np.fft.rfft(a, nf) * np.conj(np.fft.rfft(b, nf)), nf)
    lags = np.concatenate([np.arange(0, max_lag + 1), np.arange(-max_lag, 0)])
    vals = np.concatenate([c[:max_lag + 1], c[nf - max_lag:]])
    i = int(np.argmax(vals))
    return (int(lags[i]), float(vals[i]))

def pack_alignment(ja48, mix48):
    """Lag of the pack's Japanese row against the stems' mix (both 48 kHz mono), and the residual."""
    import numpy as np
    n = min(len(ja48), len(mix48))
    lag, _ = xcorr_lag(ja48[:n], mix48[:n], 2400)
    r = ja48[:n] - mix48[:n]
    res = 10 * np.log10((r ** 2).mean() / max((ja48[:n] ** 2).mean(), 1e-20))
    return (lag, round(float(res), 1))

def en_in_pack(en48, ja48, voc48, lines, head=0):
    """For each placed English line: the lag (ms) at which its voice envelope best matches the English"""
    import numpy as np
    n = min(len(en48), len(ja48), len(voc48))
    r = en48[:n] - ja48[:n] + voc48[:n]
    tr, er = envelope(r, RATE48)
    t0 = head / RATE44
    spans = [(v['on'], v['off']) for v in lines.values()]
    out = {}
    for lid, v in lines.items():
        lo, hi = (v['on'] - 0.3, v['off'] + 0.3)
        for on2, off2 in spans:
            if off2 <= v['on']:
                lo = max(lo, (off2 + v['on']) / 2)
            elif on2 >= v['off']:
                hi = min(hi, (v['off'] + on2) / 2)
        x = np.zeros(n)
        a = int(round((v['_a'] - head) / RATE44 * RATE48))
        y = to48(v['_x'])
        if a < 0:
            y, a = (y[-a:], 0)
        x[a:a + len(y)] = y[:max(0, min(len(y), n - a))]
        tv, ev = envelope(x, RATE48)
        w = (tr >= lo - t0) & (tr <= hi - t0)
        A, Bv = (er[w], ev[w])
        A, Bv = (np.maximum(A, -60.0), np.maximum(Bv, -60.0))
        A, Bv = (A - A.mean(), Bv - Bv.mean())
        best = None
        for lag in range(-40, 41):
            if lag >= 0:
                p, q = (A[lag:], Bv[:len(Bv) - lag])
            else:
                p, q = (A[:lag], Bv[-lag:])
            rr = float((p * q).sum() / np.sqrt((p * p).sum() * (q * q).sum() + 1e-20))
            if best is None or rr > best[1]:
                best = (lag, rr)
        out[lid] = dict(lag_ms=round(best[0] * HOP * 1000, 1), r=round(best[1], 3))
    return out

def measure(pack=None):
    import numpy as np
    cues = {r['id']: r for r in load(CUES)['cinematics']['rows']}
    rd = pack_reader(pack) if pack else None
    lines, align = ({}, {})
    beds = load(BEDS)
    for sid, track in SCENE_TRACK.items():
        voc, oth = stems(track)
        ja = ja_voice(track, voc)
        en = en_voice(track)
        row = {}
        if rd is not None:
            head = pack_head(cues, sid)
            pja = pack_track(rd, int(cues[sid]['ja'], 16)).mean(0)
            pen = pack_track(rd, int(cues[sid]['en'], 16)).mean(0)
            mix48 = to48((voc + oth)[:, head:].mean(0).astype(np.float64))
            voc48 = to48(voc[:, head:].mean(0).astype(np.float64))
            lag, res = pack_alignment(pja, mix48)
            row = dict(ja_lag_samples=lag, ja_residual_db=res, ja_samples=len(pja), en_samples=len(pen), head_samples=head)
            for lid, v in en_in_pack(pen, pja, voc48, en, head).items():
                en[lid]['pack'] = v
        align[str(track)] = row
        for lid, v in ja.items():
            lines.setdefault(lid, {})['ja'] = v
        for lid, v in en.items():
            lines.setdefault(lid, {})['en'] = {k: x for k, x in v.items() if not k.startswith('_')}
        print(f'tr{track} {sid}: {len(ja)} Japanese, {len(en)} English lines; pack {row}', flush=True)
    sep = beds['inputs']['external_separations'][beds['params']['variants'][0]]
    return dict(schema=1, status="MEASURED by scripts/caption_pacing.py measure: voice on/off per line, seconds of track time (the CD_PLAY request = INDEX 01 = the pack row's first sample). Timings and digests only.", method=dict(band_hz=list(BAND), hop_s=HOP, win_s=WIN, below_db=BELOW, floor_dbfs=FLOOR, min_run_s=MIN_RUN, bridge_s=BRIDGE, attach_s=ATTACH, nonverbal_pad_s=NONVERBAL_PAD, japanese='the BS-RoFormer vocal stem (dub_beds.json inputs.external_separations), lines split at the silence between them; dub_fit.json restore_original spans belong to no line', english='each approved take placed as dub_mix.py mix places it (dub_fit.json), post chain applied', pack='the Japanese row against vocals + other at 48 kHz (lag, residual); the English voice in the pack (English row - Japanese row + vocal stem) against each placed take (envelope lag)'), inputs=dict(pack=PACK if rd else None, separation=dict(variant=beds['params']['variants'][0], files={t: {k: r[k]['sha256'] for k in ('vocals', 'other')} for t, r in sep['tracks'].items()}), takes=dict(store=load(TAKES)['store']['path'], wav_sha256={l: r['wav_sha256'] for l, r in load(TAKES)['lines'].items()}), dub_fit_sha256=file_sha(FIT), subtitles_sha256=file_sha(SUBTITLES)), pack_alignment=align, lines=lines)
PACK_LAG_MS, PACK_R = (10.0, 0.7)

def cmd_measure(a):
    rep = measure(a.pack)
    if a.pack:
        off = [t for t, r in rep['pack_alignment'].items() if r.get('ja_lag_samples') != 0]
        off += [lid for lid, v in rep['lines'].items() if 'en' in v and (abs(v['en']['pack']['lag_ms']) > PACK_LAG_MS or v['en']['pack']['r'] < PACK_R)]
        cues = {r['id']: r for r in load(CUES)['cinematics']['rows']}
        rd = pack_reader(a.pack)
        voc, _ = stems(21)
        en = en_voice(21)
        for v in en.values():
            v['_a'] += int(0.06 * RATE44)
        head = pack_head(cues, 'prologue')
        ctl = en_in_pack(pack_track(rd, int(cues['prologue']['en'], 16)).mean(0), pack_track(rd, int(cues['prologue']['ja'], 16)).mean(0), to48(voc[:, head:].mean(0).astype(float)), en, head)
        caught = all((abs(v['lag_ms'] + 60) <= PACK_LAG_MS for v in ctl.values()))
        print('pack alignment:', 'PASS' if not off else f'FAIL {off}', '; control (takes 60 ms late):', 'caught' if caught else f'MISSED {ctl}')
        if off or not caught:
            return 1
    if a.check:
        old = load(VOICE_MANIFEST)
        bad = []
        for lid, v in rep['lines'].items():
            for lang, x in v.items():
                y = old['lines'].get(lid, {}).get(lang)
                if y is None or abs(x['on'] - y['on']) > 0.005 or abs(x['off'] - y['off']) > 0.005:
                    bad.append((lid, lang, x['on'], x['off'], y and (y['on'], y['off'])))
        print('measure --check:', 'PASS' if not bad else f'FAIL {bad[:10]}')
        if bad:
            return 1
    if a.write:
        VOICE_MANIFEST.write_text(json.dumps(rep, indent=1, ensure_ascii=False) + '\n', encoding='utf-8')
        print(f'{VOICE_MANIFEST} written')
    if a.out:
        Path(a.out).write_text(json.dumps(rep, indent=1, ensure_ascii=False) + '\n', encoding='utf-8')
    return 0

def shown_at(r, cue=CUE_RECORD):
    """Track seconds from which a page written at record r is on screen (its picture's first line)."""
    return (r + SPRITE_LEAD - cue + BLANK_LINES / LINES) / CPS1_HZ

def record_for(t, cue=CUE_RECORD):
    """The record to write a page at so that it is on screen from track time t (nearest frame)."""
    import math
    return int(math.floor(t * CPS1_HZ - BLANK_LINES / LINES + cue + 0.5)) - SPRITE_LEAD

def voice_manifest():
    return load(VOICE_MANIFEST)

def track_seconds(track):
    """A cinematic track's length (manifests/dub_english.json: its samples at 44.1 kHz, the disc track's)."""
    if not _TRACKS:
        _TRACKS.update(load(M / 'dub_english.json')['tracks'])
    return _TRACKS[str(track)]['samples'] / RATE44
_TRACKS = {}

def line_voice(voices, lid, voice):
    """The line's voice in the speaking language; a line that language does not speak (tr21.9, the"""
    v = voices['lines'].get(lid, {})
    v = v.get(voice) or v.get('en' if voice == 'ja' else 'ja')
    end = track_seconds(int(lid[2:4])) if lid[:2] == 'tr' and lid[2:4].isdigit() else None
    if v and end is not None and (v['off'] > end):
        v = dict(v, off=end, runs=[[s, min(e, end)] for s, e in v['runs'] if s < end])
    return v

def page_breaks(v, weights):
    """Track times of the breaks between a line's pages (len(weights) - 1 of them): at each break's"""
    runs = v['runs']
    total = sum((e - s for s, e in runs))
    gaps = [(runs[i][1], runs[i + 1][0]) for i in range(len(runs) - 1) if runs[i + 1][0] - runs[i][1] >= PAUSE]
    out, used = ([], set())
    acc = 0.0
    for k in range(1, len(weights)):
        want = total * sum(weights[:k]) / sum(weights)
        t, acc = (None, 0.0)
        for s, e in runs:
            if acc + (e - s) >= want:
                t = s + (want - acc)
                break
            acc += e - s
        t = runs[-1][1] if t is None else t
        near = [g for i, g in enumerate(gaps) if i not in used and abs((g[0] + g[1]) / 2 - t) <= SNAP]
        if near:
            g = min(near, key=lambda g: abs((g[0] + g[1]) / 2 - t))
            used.add(gaps.index(g))
            out.append((g[1] - LEAD / CPS1_HZ, 'pause'))
        else:
            out.append((t, 'share'))
    for k in range(len(out)):
        lo = (v['on'] - LEAD / CPS1_HZ if k == 0 else out[k - 1][0]) + MIN_INNER
        if out[k][0] < lo:
            out[k] = (lo, out[k][1] + '+min')
    return out

def plan_scene(sid, lang, voice, voices=None, man=None, end=None):
    """The rule for one scene's schedule: [dict(line, page, lang, on, off, why)] in track seconds, pages in"""
    voices = voices or voice_manifest()
    man = man or load(SUBTITLES)
    rows = []
    lines = [l for l in man['lines'] if l['scene'] == sid and l[lang]['pages']]
    lines = sorted(lines, key=lambda l: line_voice(voices, l['id'], voice)['on'])
    for l in lines:
        v = line_voice(voices, l['id'], voice)
        pages = l[lang]['pages']
        weights = [max(1, sum((len(r) for r in pg))) for pg in pages]
        on = v['on'] - LEAD / CPS1_HZ
        brk = page_breaks(v, weights) if len(pages) > 1 else []
        starts = [on] + [b for b, _ in brk]
        whys = ['onset'] + [w for _, w in brk]
        for k, pg in enumerate(pages):
            rows.append(dict(line=l['id'], page=k, lang=lang, text=' / '.join(pg), on=starts[k], off=starts[k + 1] if k + 1 < len(pages) else None, why=whys[k], voice_on=v['on'], voice_off=v['off'], last=k + 1 == len(pages)))
        last = rows[-1]
        last['off'] = max(v['off'] + LAG / CPS1_HZ, last['on'] + MIN_PAGE)
        last['off_why'] = 'lag' if last['off'] == v['off'] + LAG / CPS1_HZ else 'min'
    for a, b in zip(rows, rows[1:]):
        if a['off'] > b['on']:
            a['off'], a['off_why'] = (b['on'], 'next')
        elif b['on'] - a['off'] < CHAIN:
            a['off'], a['off_why'] = (b['on'], 'chain')
    if end is not None:
        for r in rows:
            if r['off'] > end:
                r['off'], r['off_why'] = (end, 'scene end')
    return [r for r in rows if r['off'] > r['on']]

def schedule_of(rows, page_index, cue=CUE_RECORD):
    """[(record, page index or None)] from plan rows; page_index(row) -> the build's page number."""
    ev = []
    for r in rows:
        a, b = (record_for(r['on'], cue), record_for(r['off'], cue))
        if b <= a:
            b = a + 1
        ev.append((max(0, a), page_index(r)))
        ev.append((b, None))
    out = {}
    for rec, pg in ev:
        if pg is not None or rec not in out:
            out[rec] = pg
    return sorted(out.items())

def schedule_pages(sched, pages_detail, cue=CUE_RECORD, end_record=None):
    """[(page index, on s, off s)] of a built schedule, as the timeline shows it."""
    out = []
    for (rec, pg), nxt in zip(sched, list(sched[1:]) + [[end_record, None]]):
        if pg is None:
            continue
        stop = nxt[0] if nxt[0] is not None else rec + 1
        out.append((pg, shown_at(rec, cue), shown_at(stop, cue)))
    return out

def check_schedule(sid, key, voice, lang, sched, pages_detail, voices, cue=CUE_RECORD, end_record=None, rule=None):
    """Every line's pages in a built schedule against its voice: the bounds and, with rule (plan rows),"""
    by_line = {}
    for pg, on, off in schedule_pages(sched, pages_detail, cue, end_record):
        d = pages_detail[pg]
        by_line.setdefault(d['line'], []).append(dict(page=pg, text=' / '.join(d['page']), lang=d['lang'], on=on, off=off))
    rule_by = {}
    for r in rule or []:
        rule_by.setdefault(r['line'], []).append(r)
    rows, bad = ([], [])
    order = sorted(by_line, key=lambda lid: by_line[lid][0]['on'])
    for i, lid in enumerate(order):
        ps = by_line[lid]
        v = line_voice(voices, lid, voice)
        nxt_on = by_line[order[i + 1]][0]['on'] if i + 1 < len(order) else None
        on, off = (ps[0]['on'], ps[-1]['off'])
        row = dict(scene=sid, schedule=key, voice=voice, lang=lang, line=lid, pages=len(ps), voice_on=v['on'], voice_off=v['off'], on=round(on, 3), off=round(off, 3), on_ms=round((on - v['on']) * 1000), off_ms=round((off - v['off']) * 1000), page_text=[p['text'] for p in ps])
        fails = []
        if any((p['lang'] != lang for p in ps)):
            fails.append('a page in the wrong language')
        if not -ON_EARLY <= on - v['on'] <= ON_LATE:
            fails.append(f"first page {row['on_ms']:+d} ms from the voice onset")
        cut = nxt_on is not None and abs(off - nxt_on) < 1.5 / CPS1_HZ
        if not -OFF_EARLY <= off - v['off'] <= OFF_LATE and (not (cut and off >= v['off'] - 0.5)):
            fails.append(f"last page {row['off_ms']:+d} ms from the voice end")
        for p, q in zip(ps, ps[1:]):
            if abs(p['off'] - q['on']) > 1.5 / CPS1_HZ:
                fails.append('a gap between the pages of one line')
        if len(ps) > 1 and any((not v['on'] - ON_EARLY <= q['on'] <= v['off'] for q in ps[1:])):
            fails.append('a page break outside the voice')
        if rule is not None:
            want = rule_by.get(lid, [])
            if len(want) != len(ps):
                fails.append(f'{len(ps)} pages, the rule has {len(want)}')
            else:
                tol = RULE_TOL / CPS1_HZ
                for p, w in zip(ps, want):
                    if abs(p['on'] - w['on']) > tol or abs(p['off'] - w['off']) > tol:
                        fails.append(f"page {w['page']}: {p['on']:.3f}-{p['off']:.3f} s, the rule {w['on']:.3f}-{w['off']:.3f}")
        row['fails'] = fails
        rows.append(row)
        if fails:
            bad.append(row)
    for lid in sorted(set(rule_by) - set(by_line)):
        row = dict(scene=sid, schedule=key, voice=voice, lang=lang, line=lid, pages=0, fails=['no pages'])
        rows.append(row)
        bad.append(row)
    return (rows, bad)

def fit_line(xs, ys):
    """Least squares y = a + b x: (a, b)."""
    import numpy as np
    if len(xs) < 2:
        return (float(ys[0]) if ys else 0.0, 0.0)
    b, a = np.polyfit(np.asarray(xs, float), np.asarray(ys, float), 1)
    return (float(a), float(b))

def scene_cue(cue_record, lead_s=0.0):
    """The cue in this module's terms (record_for, shown_at: track time 0 = INDEX 01): the record of the"""
    return cue_record - lead_s * CPS1_HZ

def build_cues(build_json):
    """{scene: (the cue record, the track time its pack row starts at)} of a build_ex.py build.json;"""
    out = {}
    for s in build_json.get('scenes', []):
        if 'cue_record' in s and s.get('window'):
            out[s['id']] = (s['cue_record'], s['window']['window_s'][0])
        else:
            out[s['id']] = (CUE_RECORD, 0.0)
    return out

def stream_records(stream):
    import struct
    pos, k = (0, 0)
    while struct.unpack_from('>H', stream, pos)[0] != 65535:
        pos += 2 + struct.unpack_from('>H', stream, pos)[0]
        k += 1
    return k

def evaluate(build, cues=None, use_rule=True):
    """The pacing check of a build_ex.py output: {(scene, key): rows}, failures, summary. cues: {scene:"""
    build = Path(build)
    caps = load(build / 'captions.json')
    bcues = build_cues(load(build / 'build.json'))
    voices, man = (voice_manifest(), load(SUBTITLES))
    out, bad, summary = ({}, [], {})
    for sid in SCENE_TRACK:
        if sid not in caps['schedules']:
            continue
        stream = build / 'work' / f'scene_{sid}.bin'
        n = stream_records(stream.read_bytes()) if stream.exists() else None
        for voice, lang, key in VARIANTS:
            have = key if key in caps['schedules'][sid] else lang
            sched = caps['schedules'][sid][have]
            rec, lead_s = bcues.get(sid, (CUE_RECORD, 0.0))
            cue = scene_cue((cues or {}).get(sid, rec), lead_s)
            end = shown_at(n - SPRITE_LEAD, cue) if n else None
            rule = plan_scene(sid, lang, voice, voices, man, end) if use_rule else None
            rows, fails = check_schedule(sid, key, voice, lang, sched, caps['pages_detail'], voices, cue, n, rule)
            out[sid, key] = rows
            bad += fails
            shown = [r for r in rows if r['pages']]
            a, b = fit_line([r['voice_on'] for r in shown], [r['on_ms'] for r in shown]) if shown else (0.0, 0.0)
            summary[f'{sid} {key}'] = dict(schedule_used=have, lines=len(rows), failing=len(fails), on_ms=dict(mean=round(sum((r['on_ms'] for r in shown)) / max(1, len(shown))), min=min((r['on_ms'] for r in shown), default=0), max=max((r['on_ms'] for r in shown), default=0), fit_at_0s=round(a), drift_ms_per_s=round(b, 2)), off_ms=dict(mean=round(sum((r['off_ms'] for r in shown)) / max(1, len(shown))), min=min((r['off_ms'] for r in shown), default=0), max=max((r['off_ms'] for r in shown), default=0)))
    return (out, bad, summary)

def cmd_check(a):
    cues = {sid: a.cue for sid in SCENE_TRACK} if a.cue is not None else None
    rows, bad, summary = evaluate(a.build, cues=cues, use_rule=not a.bounds_only)
    for k, s in summary.items():
        print(f"{k:34s} {s['schedule_used']:6s} lines {s['lines']:2d} failing {s['failing']:2d}  on {s['on_ms']['min']:+5d}..{s['on_ms']['max']:+5d} ms (mean {s['on_ms']['mean']:+5d}, fit {s['on_ms']['fit_at_0s']:+5d} ms {s['on_ms']['drift_ms_per_s']:+.2f} ms/s)  off {s['off_ms']['min']:+5d}..{s['off_ms']['max']:+5d} ms")
    if a.verbose:
        for (sid, key), rs in rows.items():
            for r in rs:
                if not r['pages']:
                    print(f"  {sid:20s} {key:6s} {r['line']:7s} {'; '.join(r['fails'])}")
                    continue
                print(f"  {sid:20s} {key:6s} {r['line']:7s} voice {r['voice_on']:6.2f}-{r['voice_off']:6.2f} page {r['on']:6.2f}-{r['off']:6.2f}  on {r['on_ms']:+5d} off {r['off_ms']:+5d} {'; '.join(r['fails'])}")
    rep = dict(build=str(a.build), passed=not bad, failing=len(bad), summary=summary, lines={f'{s} {k}': v for (s, k), v in rows.items()}, rule=dict(lead_frames=LEAD, lag_frames=LAG, min_page_s=MIN_PAGE, min_inner_s=MIN_INNER, chain_s=CHAIN, pause_s=PAUSE, snap_s=SNAP, cue_record=CUE_RECORD, cps1_hz=CPS1_HZ), scene_cues={sid: dict(cue_record=r, lead_s=l) for sid, (r, l) in build_cues(load(Path(a.build) / 'build.json')).items()}, bounds=dict(on_early_s=ON_EARLY, on_late_s=round(ON_LATE, 4), off_early_s=round(OFF_EARLY, 4), off_late_s=OFF_LATE, rule_tolerance_frames=RULE_TOL), voice_manifest_sha256=file_sha(VOICE_MANIFEST))
    if a.json:
        Path(a.json).write_text(json.dumps(rep, indent=1, ensure_ascii=False) + '\n', encoding='utf-8')
    print('PASS' if not bad else f'FAIL: {len(bad)} lines')
    return 0 if not bad else 1
FLAG_RUNS = [('striderus01', 0, None, 'en'), ('striderus01', 1, 'en', 'en'), ('striderus01', 3, 'ja', 'en'), ('striderjs01', 0, None, 'ja'), ('striderjs01', 1, 'ja', 'ja'), ('striderjs01', 5, 'en', 'en')]
HB_LUA = "\nlocal m=manager.machine\nlocal sp=m.devices[':maincpu'].spaces['program']\nlocal fields={}\nfor _,port in pairs(m.ioport.ports) do for name,field in pairs(port.fields) do\n fields[m.ioport:input_type_to_token(field.type,field.player)]=field end end\nlocal out=os.getenv('OUT')\nlocal log=assert(io.open(out..'/frames.tsv','w'))\nlocal snd=assert(io.open(out..'/sound.tsv','w'))\nlocal cap=assert(io.open(out..'/cap.tsv','w'))\nlocal f=0\n-- CAP_PTR's low word: cap_step moves it at the record whose schedule entry it applies (FRAMES is that\n-- record's index then: it counts the record after cap_step)\n_G.strex_cap=sp:install_write_tap(0xfff982,0xfff983,'cap',function(off,data,mask)\n cap:write(string.format('%d\\t%d\\t%04x\\n',f+1,sp:read_u32(0xfff900),sp:read_u16(0xfff914))) end)\nlocal last=tonumber(os.getenv('END'))\nlocal debug=os.getenv('STREX_DEBUG_START')\nlocal caps={}\nfor s in string.gmatch(os.getenv('SHOTS') or '','%d+') do caps[tonumber(s)]=true end\nlocal screen=m.screens[':screen']\n_G.strex_snd=sp:install_write_tap(0x800180,0x800181,'snd',function(off,data,mask)\n snd:write(string.format('%d\\t%d\\t%04x\\t%04x\\t%.9f\\n',f+1,sp:read_u32(0xfff900),sp:read_u16(0xfff914),data&0xffff,\n  m.time:as_double())) end)\nemu.register_frame_done(function()\n f=f+1\n if not debug then\n  if f>=200 and f<=208 then fields.COIN1:set_value(1) else fields.COIN1:clear_value() end\n  if f>=400 and f<=408 then fields.START1:set_value(1) else fields.START1:clear_value() end\n end\n log:write(string.format('%d\\t%d\\t%08x\\t%04x\\t%08x\\t%04x\\t%.9f\\n',f,sp:read_u32(0xfff900),sp:read_u32(0xfff904),\n  sp:read_u16(0xfff914),sp:read_u32(0xfff980),sp:read_u16(0xfff918),m.time:as_double()))\n if caps[f] then screen:snapshot(string.format('%s/f_%05d.png',out,f)) end\n if f>=last then log:close() snd:close() cap:close() m:exit() end\nend)\nif debug then dofile(debug) end\n"

def hb_run(binary, sets, set_name, out, frames, stage, shots=()):
    """One focus-safe HBMAME run with HB_LUA; returns (frames rows, sound rows)."""
    import ex_gate as EG
    out.mkdir(parents=True)
    (out / 'pace.lua').write_text(HB_LUA)
    env = dict(os.environ, SDL_VIDEODRIVER='dummy', SDL_AUDIODRIVER='dummy', OUT=str(out), END=str(frames), SHOTS=','.join((str(s) for s in shots)))
    if stage:
        env.update(STREX_DEBUG_START=str(EG.DEBUG_START), STREX_STAGE=str(stage), STREX_AREA='0', STREX_END=str(frames + 100), STREX_PREFIX=str(out / 'dbg'), STREX_INPUTS='')
    cmd = [str(binary), set_name, '-rompath', str(sets), '-nothrottle', '-video', 'none', '-sound', 'none', '-seconds_to_run', str(frames // 50 + 30), '-skip_gameinfo', '-noautosave', '-cfg_directory', str(out / 'cfg'), '-nvram_directory', str(out / 'nv'), '-snapshot_directory', str(out), '-autoboot_script', str(out / 'pace.lua')]
    p = subprocess.run(cmd, env=env, cwd=out, capture_output=True, text=True, timeout=1800)
    (out / 'mame.log').write_text(p.stdout + p.stderr)
    if p.returncode:
        sys.exit(f'{out}: HBMAME exit {p.returncode}')
    rows = []
    for line in (out / 'frames.tsv').read_text().splitlines():
        f, rec, src, act, cap, tick, t = line.split('\t')
        rows.append(dict(f=int(f), rec=int(rec), src=int(src, 16), act=int(act, 16), cap=int(cap, 16), tick=int(tick, 16), t=float(t)))
    snd = []
    for line in (out / 'sound.tsv').read_text().splitlines():
        f, rec, act, v, t = line.split('\t')
        snd.append(dict(f=int(f), rec=int(rec), act=int(act, 16), v=int(v, 16), t=float(t)))
    caps = []
    for line in (out / 'cap.tsv').read_text().splitlines():
        f, rec, act = line.split('\t')
        caps.append(dict(f=int(f), rec=int(rec), act=int(act, 16)))
    return (rows, snd, caps)

def stage_variant(build, set_name, flag, work, hbmame, rom_dir):
    """The build's HBMAME set with the flag byte patched as the MRA patches it."""
    import ex_gate as EG
    parent = EG.PARENT[set_name]
    src = work / f'ex_{set_name}_{flag:02x}'
    (src / parent).mkdir(parents=True)
    for q in (Path(build) / parent).iterdir():
        b = q.read_bytes()
        if q.name == 'strex_p6.bin' and flag:
            b = bytearray(b)
            b[1048574] = flag
            b = bytes(b)
        (src / parent / q.name).write_bytes(b)
    sets = work / f'set_{set_name}_{flag:02x}'
    subprocess.run([sys.executable, str(EG.HBSET), 'build', '--hbmame', str(hbmame), '--rom-dir', str(rom_dir), '--ex-dir', str(src), '--set', set_name, '--date', '2026-10-10', '--out', str(sets)], check=True, stdout=subprocess.DEVNULL)
    return sets

def scenes_in_run(rows, snd, caps, streams):
    """Per scene played: its first ACTIVE frame, the cue (record, value), the schedule changes (records)."""
    order = sorted(streams, key=lambda k: streams[k])

    def scene_of(ptr):
        i = max((j for j, s0 in enumerate(order) if streams[s0] <= ptr), default=None)
        return order[i] if i is not None else None
    runs = []
    for r in rows:
        if r['act'] == 49637:
            if runs and r['f'] == runs[-1][-1]['f'] + 1 and (r['rec'] >= runs[-1][-1]['rec']):
                runs[-1].append(r)
            else:
                runs.append([r])
    out = []
    for k, rs in enumerate(runs):
        sid = scene_of(rs[len(rs) // 2]['src'])
        f0, f1 = (rs[0]['f'], rs[-1]['f'])
        nxt = runs[k + 1][0]['f'] if k + 1 < len(runs) else None
        end = f1 if nxt == f1 + 1 else f1 + 1
        cont = k > 0 and runs[k - 1][-1]['f'] == f0 - 1
        cues = [s for s in snd if f0 <= s['f'] <= end and s['v'] & 255 != 255]
        changes = [c['rec'] for c in caps if f0 <= c['f'] <= end and c['act'] == 49637 and (not (cont and c['f'] == f0 and (c['rec'] > rs[0]['rec'])))]
        before = next((r for r in rows if r['f'] == f0 - 1), None)
        tick0 = before['tick'] if before else None
        ticks = {}
        for r in rs:
            ticks.setdefault(r['rec'], r['tick'])
        out.append(dict(scene=sid, first_frame=f0, frames=len(rs), records=rs[-1]['rec'], cue=[dict(record=s['rec'] - 1, value=s['v'] & 255) for s in cues], tick_before=tick0, ticks=ticks, cap_changes=changes))
    return out

def which_schedule(changes, schedules):
    """The schedule keys whose entries are exactly the records at which CAP_PTR moved (two schedules"""
    return sorted((k for k, s in schedules.items() if k != 'card' and [r for r, _ in s] == changes))

def cmd_hbmame(a):
    build = a.build.resolve()
    bjs = load(build / 'build.json')
    caps = load(build / 'captions.json')
    binary = load(a.runtime / 'runtime.json')['binary']
    work = a.workdir.resolve()
    work.mkdir(parents=True, exist_ok=False)
    cues_tab = {r['id']: r for r in load(CUES)['cinematics']['rows']}
    bcues = build_cues(bjs)
    runs = [r for r in FLAG_RUNS if not a.variants or f'{r[0]}:{r[1]:02x}' in a.variants.split(',')]
    report, ok = (dict(build=str(build), runs=[]), True)
    measured = {}
    for set_name, flag, voice, lang in runs:
        import ex_gate as EG
        parent = EG.PARENT[set_name]
        streams = bjs['sets'][parent]['streams']
        sets = stage_variant(build, set_name, flag, work, a.hbmame, a.rom_dir.resolve())
        for stage in [int(s) for s in a.stages.split(',')]:
            if stage and flag not in (1,) and (not a.all_stages):
                continue
            out = work / f'run_{set_name}_{flag:02x}_s{stage}'
            rows, snd, capw = hb_run(binary, sets, set_name, out, a.frames if stage == 0 else a.stage_frames, stage)
            for sc in scenes_in_run(rows, snd, capw, streams):
                sid = sc['scene']
                key = 'en_dub' if voice == 'en' else lang
                want_key = key if key in caps['schedules'][sid] else lang
                got = which_schedule(sc['cap_changes'], caps['schedules'][sid])
                want_cue = int(cues_tab[sid]['en' if voice == 'en' else 'ja'], 16) if flag & 1 else None
                cue_rec = sc['cue'][0]['record'] if sc['cue'] else None
                pre = int(bcues.get(sid, (CUE_RECORD, 0))[0] - 0.5)
                tick = sc['ticks'].get(pre + 1)
                parity = None if tick is None else pre if tick % 2 else pre + 1
                checks = dict(schedule=want_key in got, cue=[c['value'] for c in sc['cue']] == ([want_cue] if want_cue is not None else []), cue_record=cue_rec is None or abs(cue_rec - bcues.get(sid, (CUE_RECORD, 0))[0]) <= CUE_SLACK, cue_parity=cue_rec is None or cue_rec == parity)
                row = dict(set=set_name, flag=f'0x{flag:02x}', stage=stage, voice=voice, lang=lang, scene=sid, schedule=got, schedule_expected=want_key, cue=sc['cue'], cue_record=cue_rec, parity_record=parity, records=sc['records'], first_frame=sc['first_frame'], checks=checks, passed=all(checks.values()))
                if voice is not None and cue_rec is not None:
                    measured.setdefault(sid, set()).add(cue_rec)
                ok &= row['passed']
                report['runs'].append(row)
                print(json.dumps(row), flush=True)
    pacing = {}
    for sid, recs in sorted(measured.items()):
        for c in sorted(recs):
            rows_c, bad_c, summ = evaluate(build, cues={sid: c})
            pacing[f'{sid} cue {c}'] = dict(failing=len([b for b in bad_c if b['scene'] == sid]), summary={k: v for k, v in summ.items() if k.startswith(sid + ' ')})
            ok &= not any((b['scene'] == sid for b in bad_c))
    report['pacing'] = pacing
    report['passed'] = bool(ok)
    (work / 'report.json').write_text(json.dumps(report, indent=1) + '\n')
    for k, v in pacing.items():
        print(k, 'failing', v['failing'])
    print('PASS' if ok else 'FAIL')
    return 0 if ok else 1
STRIP_ROWS = [('Japanese voice', 'voice', 'ja', None), ('JA captions, before', 'cap', 'ja', 'before'), ('JA captions, now', 'cap', 'ja', 'after'), ('EN over JA voice, before', 'cap', 'en', 'before'), ('EN over JA voice, now', 'cap', 'en', 'after'), ('English dub voice', 'voice', 'en', None), ('EN over the dub, before', 'cap', 'en_dub', 'before'), ('EN over the dub, now', 'cap', 'en_dub', 'after')]
CLIPS = [('prologue_en_dub', 'prologue', 'striderus01', 1, 0, 'en_dub', 'en', 5.5, 18.5), ('st_petersburg_ja', 'brief_st_petersburg', 'striderjs01', 1, 0, 'ja', 'ja', 5.0, 19.8), ('amazon_en_over_ja', 'brief_amazon', 'striderus01', 3, 2, 'en', 'ja', 5.0, 21.5), ('siberia_en_dub', 'brief_siberia', 'striderus01', 1, 1, 'en_dub', 'en', 1.0, 13.8)]

def strip_png(sid, builds, voices, path, cue=0):
    """One scene's caption pages against the voices, before and now, as a PNG timeline."""
    from PIL import Image, ImageDraw, ImageFont
    font = ImageFont.load_default()
    px, left, rh, top = (40, 200, 24, 30)
    n = {k: stream_records((Path(b) / 'work' / f'scene_{sid}.bin').read_bytes()) for k, b in builds.items()}
    span = max((shown_at(v, cue) for v in n.values())) + 0.5
    w, h = (left + int(span * px) + 10, top + rh * len(STRIP_ROWS) + 10)
    img = Image.new('RGB', (w, h), (255, 255, 255))
    d = ImageDraw.Draw(img)
    for s in range(int(span) + 1):
        x = left + s * px
        d.line([(x, top - 4), (x, h - 6)], fill=(235, 235, 235) if s % 5 else (200, 200, 200))
        if s % 5 == 0:
            d.text((x + 2, 8), f'{s} s', fill=(0, 0, 0), font=font)
    caps = {k: load(Path(b) / 'captions.json') for k, b in builds.items()}
    colors = {'before': (214, 80, 75), 'after': (46, 139, 87), None: (120, 120, 120)}
    for i, (label, kind, key, which) in enumerate(STRIP_ROWS):
        y = top + i * rh
        d.text((6, y + 6), label, fill=(0, 0, 0), font=font)
        boxes = []
        if kind == 'voice':
            for lid, v in voices['lines'].items():
                if v.get(key) and any((l['id'] == lid and l['scene'] == sid for l in load(SUBTITLES)['lines'])):
                    boxes += [(s, e, lid[2:] if j == 0 else '') for j, (s, e) in enumerate(v[key]['runs'])]
        else:
            c = caps[which]
            sk = key if key in c['schedules'][sid] else 'en' if key == 'en_dub' else key
            for pg, on, off in schedule_pages(c['schedules'][sid][sk], c['pages_detail'], cue, n[which]):
                boxes.append((on, off, c['pages_detail'][pg]['line'][2:]))
        for s, e, text in boxes:
            x0, x1 = (left + s * px, left + e * px)
            d.rectangle([x0, y + 3, max(x0 + 1, x1), y + rh - 3], fill=colors[which], outline=(40, 40, 40))
            if text:
                d.text((x0 + 3, y + 7), text, fill=(255, 255, 255), font=font)
    img.save(path)

def line_table(sid, builds, voices, cue=0):
    """Per line and schedule: its voice and its first/last page against it, before and now (ms)."""
    out = []
    for voice, lang, key in VARIANTS:
        res = {}
        for which, b in builds.items():
            caps = load(Path(b) / 'captions.json')
            sk = key if key in caps['schedules'][sid] else lang
            n = stream_records((Path(b) / 'work' / f'scene_{sid}.bin').read_bytes())
            rows, _ = check_schedule(sid, key, voice, lang, caps['schedules'][sid][sk], caps['pages_detail'], voices, cue, n)
            res[which] = {r['line']: r for r in rows}
        for lid in sorted(set(res['before']) | set(res['after']), key=lambda l: line_voice(voices, l, voice)['on']):
            b, a = (res['before'].get(lid), res['after'].get(lid))
            v = line_voice(voices, lid, voice)
            out.append(dict(schedule=key, line=lid, voice_on=v['on'], voice_off=v['off'], before_on=b and b['on_ms'], before_off=b and b['off_ms'], after_on=a and a['on_ms'], after_off=a and a['off_ms']))
    return out

def make_clip(run_dir, frames_rows, snd_rows, f0, pcm48, t0, t1, path, label):
    """Video of the snapshots in run_dir with the pack row's audio placed as the board plays it: track"""
    import numpy as np
    import wave
    cue = next((s for s in snd_rows if s['f'] >= f0 and s['v'] & 255 != 255))
    tim = {r['f']: r['t'] for r in frames_rows}
    shots = sorted((int(q.stem[2:]) for q in run_dir.glob('f_*.png')))
    if not shots:
        sys.exit(f'{run_dir}: no snapshots')
    shots = [f for f in shots if t0 <= tim[f - 1] - cue['t'] <= t1]
    tau0 = tim[shots[0] - 1] - cue['t']
    a = int(round(tau0 * RATE48))
    seg = pcm48[:, a:a + int(round(len(shots) / CPS1_HZ * RATE48))]
    wav = path.with_suffix('.wav')
    with wave.open(str(wav), 'wb') as w:
        w.setnchannels(2)
        w.setsampwidth(2)
        w.setframerate(RATE48)
        w.writeframes(np.clip(np.round(seg.T * 32768), -32768, 32767).astype('<i2').tobytes())
    lst = path.with_suffix('.txt')
    lst.write_text(''.join((f"file '{run_dir / f'f_{f:05d}.png'}'\nduration {1 / CPS1_HZ:.9f}\n" for f in shots)))
    subprocess.run(['ffmpeg', '-loglevel', 'error', '-y', '-f', 'concat', '-safe', '0', '-i', str(lst), '-i', str(wav), '-vf', 'scale=768:448:flags=neighbor,format=yuv420p', '-r', f'{CPS1_HZ}', '-c:v', 'libx264', '-crf', '18', '-c:a', 'aac', '-b:a', '192k', '-shortest', '-metadata', f'title={label}', str(path)], check=True)
    wav.unlink()
    lst.unlink()
    return dict(clip=path.name, frames=len(shots), track_from=round(tau0, 3), cue_frame=cue['f'], first_active=f0)

def cmd_review(a):
    import html
    import shutil
    out = a.out.resolve()
    out.mkdir(parents=True, exist_ok=True)
    voices = voice_manifest()
    builds = {'before': a.control.resolve(), 'after': a.build.resolve()}
    caps = load(builds['after'] / 'captions.json')
    parts = ['<!doctype html><meta charset="utf-8"><title>Caption pacing review</title>', '<style>body{font:14px system-ui;margin:16px;max-width:1700px}table{border-collapse:collapse;margin:8px 0}td,th{border:1px solid #ccc;padding:2px 6px;text-align:right}td.l{text-align:left}.bad{color:#b33}.ok{color:#286}img{max-width:100%;border:1px solid #ddd}</style>', '<h1>Strider EX: caption pacing (before = build 43, now = this build)</h1>', f"<p>Times are track seconds from the cue (the board's VBlank 0 of the scene, MEASURED in HBMAME). Rule now: a page comes up {LEAD} frames before its speech and leaves {LAG} frames after it, at least {MIN_PAGE} s on screen; gaps under {CHAIN} s are closed. Red = before, green = now, grey = voice. Deltas are page minus voice, in ms (negative = before the voice).</p>"]
    clips = []
    if a.pack and a.runtime:
        rd = pack_reader(a.pack)
        cues_tab = {r['id']: r for r in load(CUES)['cinematics']['rows']}
        binary = load(a.runtime / 'runtime.json')['binary']
        work = out / 'runs'
        work.mkdir(exist_ok=True)
        for name, sid, set_name, flag, stage, key, voice, t0, t1 in CLIPS:
            pcm = pack_track(rd, int(cues_tab[sid]['en' if voice == 'en' else 'ja'], 16))
            for which, b in builds.items():
                import ex_gate as EG
                tag = f'{name}_{which}'
                d, probe, stagework = (work / tag, work / f'{tag}_probe', work / f'sets_{tag}')
                for x in (d, probe, stagework):
                    if x.exists():
                        shutil.rmtree(x)
                stagework.mkdir()
                sets = stage_variant(b, set_name, flag, stagework, a.hbmame, a.rom_dir.resolve())
                streams = load(b / 'build.json')['sets'][EG.PARENT[set_name]]['streams']
                rows, snd, capw = hb_run(binary, sets, set_name, probe, 5400 if stage == 0 else 4200, stage)
                sc = next((s for s in scenes_in_run(rows, snd, capw, streams) if s['scene'] == sid))
                f0 = sc['first_frame']
                cue_f = sc['cue'][0]['record'] + f0
                shots = range(cue_f + int(t0 * CPS1_HZ) - 2, cue_f + int(t1 * CPS1_HZ) + 3)
                rows, snd, capw = hb_run(binary, sets, set_name, d, max(shots) + 5, stage, shots)
                info = make_clip(d, rows, snd, f0, pcm, t0, t1, out / f'{tag}.mp4', f'{sid} {key} {which}')
                clips.append(dict(name=name, which=which, scene=sid, schedule=key, **info))
                print(tag, info, flush=True)
        shutil.rmtree(work)
    for sid in SCENE_TRACK:
        if sid not in caps['schedules']:
            continue
        strip_png(sid, builds, voices, out / f'strip_{sid}.png')
        parts.append(f'<h2>{html.escape(sid)}</h2><img src="strip_{sid}.png">')
        for c in [c for c in clips if c['scene'] == sid]:
            parts.append(f'''<p>{c['which']}: {c['schedule']} <video controls src="{c['clip']}" width=768></video></p>''')
        rows = line_table(sid, builds, voices)
        parts.append('<table><tr><th>schedule</th><th>line</th><th>voice on</th><th>voice off</th><th>before on</th><th>before off</th><th>now on</th><th>now off</th></tr>')
        for r in rows:

            def cell(v, good):
                if v is None:
                    return '<td>-</td>'
                return f'''<td class="{('ok' if good(v) else 'bad')}">{v:+d}</td>'''
            parts.append(f"<tr><td class=l>{r['schedule']}</td><td class=l>{r['line']}</td><td>{r['voice_on']:.2f}</td><td>{r['voice_off']:.2f}</td>" + cell(r['before_on'], lambda v: -250 <= v <= 25) + cell(r['before_off'], lambda v: -25 <= v <= 750) + cell(r['after_on'], lambda v: -250 <= v <= 25) + cell(r['after_off'], lambda v: -25 <= v <= 750) + '</tr>')
        parts.append('</table>')
    (out / 'index.html').write_text('\n'.join(parts) + '\n', encoding='utf-8')
    (out / 'clips.json').write_text(json.dumps(clips, indent=1) + '\n')
    print(out / 'index.html')
    return 0

def self_test():
    """Synthetic checks of the timeline, the activity runs, the rule and the check (no audio needed)."""
    import numpy as np
    for r in range(0, 3000, 7):
        assert record_for(shown_at(r)) == r, r
    assert abs(shown_at(64, 0) - (66 + BLANK_LINES / LINES) / CPS1_HZ) < 1e-12
    t = np.arange(0, 2, HOP)
    e = np.full(len(t), -90.0)
    e[(t >= 0.5) & (t < 0.9)] = -20.0
    e[(t >= 0.95) & (t < 1.3)] = -22.0
    e[(t >= 1.6) & (t < 1.62)] = -20.0
    rs, ref = line_activity(t, e, 0.0, 2.0, 0.0, 2.0)
    assert rs == [[0.5, 1.3]], rs
    voices = dict(lines={'a': dict(ja=dict(on=1.0, off=3.0, runs=[[1.0, 1.8], [2.2, 3.0]])), 'b': dict(ja=dict(on=3.2, off=3.6, runs=[[3.2, 3.6]])), 'c': dict(en=dict(on=8.0, off=9.0, runs=[[8.0, 9.0]]))})
    man = dict(lines=[dict(id='a', scene='s', en=dict(pages=[['ONE'], ['TWO']]), ja=dict(pages=[['x']])), dict(id='b', scene='s', en=dict(pages=[['THREE']]), ja=dict(pages=[['y']])), dict(id='c', scene='s', dub_only=True, en=dict(pages=[['FOUR']]), ja=dict(pages=[]))])
    rows = plan_scene('s', 'en', 'ja', voices, man)
    lead = LEAD / CPS1_HZ
    assert [r['line'] for r in rows] == ['a', 'a', 'b', 'c']
    assert abs(rows[0]['on'] - (1.0 - lead)) < 1e-09
    assert abs(rows[1]['on'] - (2.2 - lead)) < 1e-09 and rows[1]['why'] == 'pause'
    assert rows[1]['off'] == rows[2]['on'] and rows[1]['off_why'] in ('next', 'chain')
    assert abs(rows[2]['off'] - max(3.6 + LAG / CPS1_HZ, rows[2]['on'] + MIN_PAGE)) < 1e-09
    assert abs(rows[3]['on'] - (8.0 - lead)) < 1e-09
    pages_detail = [dict(line=r['line'], lang='en', page=[r['text']]) for r in rows]
    sched = schedule_of(rows, lambda r: rows.index(r))
    got, bad = check_schedule('s', 'en', 'ja', 'en', sched, pages_detail, voices, rule=rows)
    assert not bad, bad
    late = [(rec + 60, pg) for rec, pg in sched]
    got, bad = check_schedule('s', 'en', 'ja', 'en', late, pages_detail, voices, rule=rows)
    assert bad and all(('first page' in ' '.join(b['fails']) for b in bad))
    lost = [(rec, pg) for rec, pg in sched if pg != 2]
    got, bad = check_schedule('s', 'en', 'ja', 'en', lost, pages_detail, voices, rule=rows)
    assert any((b['line'] == 'b' and b['fails'] == ['no pages'] for b in bad)), bad
    rng = np.random.default_rng(5)

    def burst(d):
        tt = np.arange(int(d * RATE44)) / RATE44
        return rng.standard_normal(len(tt)) * (0.3 + 0.7 * np.sin(2 * np.pi * 2 * tt) ** 2) * 0.1
    xa, xb = (burst(1.2), burst(1.5))
    a0, b0 = (int(1.0 * RATE44), int(2.35 * RATE44))
    total = np.zeros(int(5 * RATE44))
    total[a0:a0 + len(xa)] += xa
    total[b0:b0 + len(xb)] += xb
    en48 = to48(total)
    quiet = np.zeros_like(en48)
    lines = {'a': dict(on=1.0, off=2.2, _x=xa, _a=a0), 'b': dict(on=2.35, off=3.85, _x=xb, _a=b0)}
    got = en_in_pack(en48, quiet, quiet, lines)
    assert all((v['lag_ms'] == 0 and v['r'] >= 0.95 for v in got.values())), got
    got = en_in_pack(en48, quiet, quiet, dict(lines, a=dict(lines['a'], _a=a0 + int(0.06 * RATE44))))
    assert abs(got['a']['lag_ms'] + 60) <= PACK_LAG_MS and got['b']['lag_ms'] == 0, got
    print('caption_pacing self-test passed')
    return 0

def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('--self-test', action='store_true')
    sub = p.add_subparsers(dest='cmd')
    s = sub.add_parser('measure')
    s.add_argument('--pack', type=Path, help='strider_ex.cpk (PACK pin)')
    s.add_argument('--check', action='store_true', help='exit 1 unless the timings equal manifests/caption_voice.json')
    s.add_argument('--write', action='store_true', help='write manifests/caption_voice.json')
    s.add_argument('--out', type=Path)
    s = sub.add_parser('check')
    s.add_argument('--build', type=Path, required=True)
    s.add_argument('--json', type=Path)
    s.add_argument('--bounds-only', action='store_true', help='only the rule-independent bounds')
    s.add_argument('--cue', type=float, help='the cue record measured (hbmame); default CUE_RECORD')
    s.add_argument('--verbose', action='store_true')
    s = sub.add_parser('hbmame')
    s.add_argument('--build', type=Path, required=True)
    s.add_argument('--runtime', type=Path, required=True)
    s.add_argument('--hbmame', type=Path, required=True)
    s.add_argument('--rom-dir', type=Path, required=True)
    s.add_argument('--workdir', type=Path, required=True)
    s.add_argument('--stages', default='0,1,2,3,4', help='stage 0 for every flag byte; 1-4 (debug start) with 0x01')
    s.add_argument('--all-stages', action='store_true', help='stages 1-4 with every flag byte too')
    s.add_argument('--variants', help='comma list of <set>:<flag hex>, default all six')
    s.add_argument('--frames', type=int, default=5400)
    s.add_argument('--stage-frames', type=int, default=4200)
    s = sub.add_parser('review')
    s.add_argument('--build', type=Path, required=True)
    s.add_argument('--control', type=Path, required=True, help='the build before (build 43)')
    s.add_argument('--out', type=Path, required=True)
    s.add_argument('--pack', type=Path, help="with the HBMAME arguments: clips with the pack's audio")
    s.add_argument('--runtime', type=Path)
    s.add_argument('--hbmame', type=Path)
    s.add_argument('--rom-dir', type=Path)
    a = p.parse_args()
    if a.self_test:
        return self_test()
    return {'measure': cmd_measure, 'check': cmd_check, 'hbmame': cmd_hbmame, 'review': cmd_review}[a.cmd](a)
if __name__ == '__main__':
    sys.exit(main())
