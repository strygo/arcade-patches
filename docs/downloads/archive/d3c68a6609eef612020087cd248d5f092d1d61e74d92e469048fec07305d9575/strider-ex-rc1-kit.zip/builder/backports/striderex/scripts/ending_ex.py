"""Strider EX ending (D9, D9a): the arcade staff roll extended with the PC Engine credits."""
import argparse
import hashlib
import json
import os
import struct
import subprocess
import sys
from pathlib import Path
import numpy as np
sys.path.insert(0, str(Path(__file__).resolve().parent))
import cps1_gfx as G
ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent
ASM = ROOT / 'backports/striderex/asm'
MANIFEST = ROOT / 'backports/striderex/manifests/ending_roll.json'
DEBUG_START = ROOT / 'backports/striderex/lua/arcade_debug_start.lua'
FPS = 59.637
JR_DELTA = 600
MACHINES = ('striderua', 'striderjr')
SCROLL0 = 33
HOLD_START = 190
FADE_OUT = 150
LOOP0 = 31
STOCK_SPAWN = 774
ROW_Y0 = 240
NBLOCKS = 9
S3_FIRST = 15616
S2_LAST = 33791
S3_BLANK, S2_BLANK = (32, 10272)
FADE = 15
AFTER_END = 3000
AFTER_HOLD = 700
WIN_X, WIN_Y, WIN_W, WIN_H = (160, 48, 192, 128)
S3_COLS, S3_ROW0, S3_COL0 = (8, 58, 5)
S2_COLS, S2_ROW0 = (24, 52)
MAIN = {'bg3': (48, 63), 'spr6': (352, 367), 'spr1': (272, 287), 'spr5': (336, 351)}
STILL_X = {'s00': 32, 's01': 40, 's02': 0, 's03': 40}
FONT = {'.': '+', '&': '*', '©': '-'}
ALLOWED = set('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 .,&©')
EX_CREDIT_ROW = '{ex edition credit}'
EX_CREDIT_ROLE = 'EX EDITION'
EX_CREDIT_NAME = bytes.fromhex('535445564520474f52444f4e').decode('ascii')

def section_rows(rows):
    """Expand the staff entry in the manifest's arcade insertion rows."""
    out = []
    for t in rows:
        out += [EX_CREDIT_ROLE, '', EX_CREDIT_NAME] if t == EX_CREDIT_ROW else [t]
    return out

def staff_spacing(rows, plan):
    """Audit staff-entry spacing against the arcade's existing one/two-blank-row rhythm."""
    checks = []

    def group(section, first, last, headings, closing=False):
        heads = []
        for heading in headings:
            encoded = [font_row(t) for t in heading]
            matches = [i for i in range(first, last - len(encoded) + 1) if rows[i:i + len(encoded)] == encoded]
            if len(matches) != 1:
                raise SystemExit(f'ending staff spacing: {section} {heading} is not unique')
            heads.append((matches[0], len(encoded), ' / '.join(heading)))
        for i, (at, lines, label) in enumerate(heads):
            stop = heads[i + 1][0] if i + 1 < len(heads) else last
            names = [j for j in range(at + lines, stop) if rows[j]]
            gaps = [b - a - 1 for a, b in zip(names, names[1:])]
            role_gap = names[0] - (at + lines) if names else None
            next_gap = stop - names[-1] - 1 if names and (i + 1 < len(heads) or closing) else None
            ok = bool(names) and role_gap == 1 and all((g == 1 for g in gaps)) and (next_gap in (None, 2))
            checks.append(dict(section=section, role=label, role_row=at, role_to_name_blank_rows=role_gap, between_names_blank_rows=gaps, after_entry_blank_rows=next_gap, passed=ok))
            if not ok:
                raise SystemExit(f'ending staff spacing: {section} {label}: {checks[-1]}')
    credit = plan['ex_credit']
    group('arcade', 0, credit['first_changed_row'] + credit['inserted_rows'], [[t] for t in ('OBJECT DESIGNER', 'SCROLL DESIGNER', 'SOFT PROGRAMMER', 'PLANNING ADVISER', 'GAME PLANNER', EX_CREDIT_ROLE)], closing=True)
    sections = {s['still']: s for s in plan['sections']}
    for sid, headings in (('s01', [['PROGRAM'], ['MAP GRAPHICS']]), ('s02', [['PROGRAM'], ['CHARACTER DESIGN', '& ANIMATE'], ['GRAPHICS'], ['MUSIC'], ['ORIGINAL GAME', 'MADE BY'], ['PRODUCE'], ['DIRECTION'], ['EXECUTIVE PRODUCER']])):
        sec = sections[sid]
        group(sid, sec['first_row'], sec['last_row'] + 1, headings)
    return checks
SIG = {50366: '0c6d00f82022', 50514: '3b7c0834201c', 50892: '7000102d8cdd', 50316: '4eb9????????', 50632: '302d201ed040', 51076: '3a3c001f47ea000049eb0002383c001f', 50986: '4ef9????????', 50582: '227c009138a8'}

def sha(b):
    return hashlib.sha256(b).hexdigest()

def stock_programs(rom_dir):
    import respawn_fix as RF
    out = {}
    for m in MACHINES:
        files = {q.name: q.read_bytes() for q in (rom_dir / m).iterdir() if q.is_file()}
        out[m] = bytes(RF.compose(files, RF.SETS[m]))
    return out

def check_sig(img, machine):
    d = 0 if machine == 'striderua' else JR_DELTA
    for a, h in SIG.items():
        got = img[a - d:a - d + len(h) // 2].hex()
        if any((c != '?' and c != g for c, g in zip(h, got))):
            raise SystemExit(f'{machine}: unexpected stock bytes at {a - d:#x}: {got} (want {h})')

def region_addrs(img, machine):
    """The stock routines the EX code calls, read from each program."""
    d = 0 if machine == 'striderua' else JR_DELTA
    return dict(writer=51076 - d, spawn=int.from_bytes(img[50988 - d:50992 - d], 'big'), objupd=int.from_bytes(img[50318 - d:50322 - d], 'big'), water_ret=50638 - d, delta=d)

def decode_block(img, start):
    rows, p = ([], start)
    for _ in range(32):
        row = bytearray()
        while len(row) < 32:
            c = img[p]
            p += 1
            if c == 255:
                break
            row.append(c)
        rows.append(row.decode('latin1'))
    return (rows, p)

def stock_rows(img, machine):
    d = 0 if machine == 'striderua' else JR_DELTA
    rows = []
    for b in (51160, 51496, 51813):
        r, _ = decode_block(img, b - d)
        rows += r
    return rows

def encode_block(rows):
    assert len(rows) == 32
    out = b''
    for r in rows:
        assert len(r) < 32
        out += r.encode('latin1') + b'\xff'
    return out

def scrolled(f):
    """Pixels scrolled at frame f after the 0x21 latch write."""
    return 0 if f < SCROLL0 else (f - SCROLL0) // 3 + 1

def font_row(text):
    """A manifest row in the roll font: right-aligned to column 18 unless it starts with '|'."""
    raw = text[1:] if text.startswith('|') else text
    bad = set(raw) - ALLOWED
    if bad:
        raise SystemExit(f'ending_roll.json: characters {sorted(bad)} are not in the roll font ({text!r})')
    enc = ''.join((FONT.get(c, c) for c in raw))
    if text.startswith('|'):
        if len(enc) > 22:
            raise SystemExit(f'ending_roll.json: {text!r} is wider than the arcade copyright rows')
        return enc
    if len(enc) > 19:
        raise SystemExit(f'ending_roll.json: {text!r} is wider than 19 columns')
    return enc.rjust(19)

def roll_table(man, stock, machine):
    """(rows, plan): the full roll (NBLOCKS x 32 rows) for one region."""
    rows = list(stock)
    copy = [i for i, r in enumerate(rows) if r.strip().startswith('- CAPCOM')]
    if not copy or copy != list(range(copy[0], copy[-1] + 1)) or (not rows[copy[-1] + 1].strip().isdigit()):
        raise SystemExit(f'{machine}: stock copyright rows not found where expected')
    copy.append(copy[-1] + 1)
    copyright_rows = [rows[i] for i in copy]
    for i in copy:
        rows[i] = ''
    while rows and rows[-1] == '':
        rows.pop()
    credit = man['arcade']['ex_credit']
    anchors = [i for i, row in enumerate(rows) if row.strip() == credit['before']]
    if len(anchors) != 1 or anchors[0] == 0 or rows[anchors[0] - 1].strip() != credit['preceding_marker']:
        raise SystemExit(f'{machine}: arcade staff credit insertion anchor differs')
    credit_at = anchors[0] - 1
    inserted = [font_row(t) if t else '' for t in section_rows(credit['rows'])]
    rows[credit_at:credit_at] = inserted
    total = round(man['track']['seconds'] * FPS)
    end_s = scrolled(total)
    plan = dict(frames_from_0x21=total, hold=total - HOLD_START - FADE_OUT, scroll_px=end_s, arcade_last_row=len(rows) - 1, copyright_stock_rows=copy, sections=[], ex_credit=dict(role_row=credit_at + inserted.index(font_row(EX_CREDIT_ROLE)), name_row=credit_at + inserted.index(font_row(EX_CREDIT_NAME)), first_changed_row=credit_at, inserted_rows=len(inserted)))
    for sec in man['sections']:
        f = round(sec['cut_s'] * FPS)
        first = (scrolled(f) - 16) // 8
        if first < len(rows) + 2:
            raise SystemExit(f"{machine}: section {sec['still']} would start at row {first}, inside the rows before it (end {len(rows) - 1})")
        rows += [''] * (first - len(rows))
        rows += [font_row(t) if t else '' for t in sec['rows']]
        plan['sections'].append(dict(still=sec['still'], cut_s=sec['cut_s'], cut_frame=f, first_row=first, last_row=len(rows) - 1))
    rows += [''] * man['copyright']['gap_rows']
    for t in man['copyright']['rows']:
        if t == '{stock copyright rows}':
            rows += copyright_rows
        else:
            rows.append(font_row(t) if t else '')
    plan['last_row'] = len(rows) - 1
    plan['last_row_y_at_fade_start'] = 8 * plan['last_row'] + ROW_Y0 - scrolled(total - FADE_OUT)
    plan['last_row_y_at_end'] = 8 * plan['last_row'] + ROW_Y0 - end_s
    plan['staff_spacing'] = staff_spacing(rows, plan)
    if not 0 <= plan['last_row_y_at_fade_start'] <= 216:
        raise SystemExit(f"{machine}: the last row is off screen when the fade starts (y {plan['last_row_y_at_fade_start']})")
    need = end_s // 256 + 1
    if need != NBLOCKS or len(rows) > 32 * NBLOCKS:
        raise SystemExit(f'{machine}: {len(rows)} rows / {need} block writes do not fit {NBLOCKS} blocks')
    rows += [''] * (32 * NBLOCKS - len(rows))
    return (rows, plan)

def _composite(d):
    import pce_vdc as V
    bg, spr = V.render_layers(d)
    bg = np.where(bg >> 4 == 7, 0, bg)
    has = spr & 15 != 0
    idx = np.where(has & ((spr & 16384 != 0) | (bg & 15 == 0)), spr & 511, bg)
    return idx[:224]

def _load(cap, frame, want_sha=None):
    import pce_vdc as V
    p = cap / f'pce_{frame:05d}_scene.vdc'
    b = p.read_bytes()
    if want_sha and sha(b) != want_sha:
        raise SystemExit(f'{p}: SHA-256 {sha(b)} is not the pinned {want_sha}')
    return V.load(p)

def sky_strip(cap, spec):
    """The panning sky: (strip of VCE indices (-1 transparent), {pce frame: image x of PCE x 0})."""
    pan = spec['pan']
    h = hashlib.sha256()
    for f in range(pan['first'] - 18, pan['last'] + 2, 2):
        h.update(bytes.fromhex(sha((cap / f'pce_{f:05d}_scene.vdc').read_bytes())))
    if h.hexdigest() != pan['frames_sha256']:
        raise SystemExit('ending_roll.json: the pan frames are not the pinned capture')
    lo, hi = MAIN[spec['main']]
    frames = list(range(pan['first'], pan['last'] + 1, 2))
    shots, pals = ([], [])
    for f in frames:
        d = _load(cap, f)
        idx = _composite(d)
        sky = np.where((idx >= lo) & (idx <= hi) & (idx & 15 != 0), idx, -1)
        shots.append(sky)
        pals.append(d['pal'])
    off = {frames[0]: 0}
    o = 0
    for k in range(1, len(frames)):
        a, b = (shots[k - 1], shots[k])
        best = None
        for dx in range(-3, 4):
            if dx >= 0:
                aa, bb = (a[:, dx:], b[:, :b.shape[1] - dx])
            else:
                aa, bb = (a[:, :dx], b[:, -dx:])
            m = (aa >= 0) & (bb >= 0)
            score = int((aa[m] == bb[m]).sum()) - int((aa[m] != bb[m]).sum())
            if best is None or score > best[0]:
                best = (score, dx)
        o += best[1]
        off[frames[k]] = o
    lo_x = min((int(np.nonzero((s >= 0).any(0))[0].min()) + off[f] for s, f in zip(shots, frames) if (s >= 0).any()))
    width = max((int(np.nonzero((s >= 0).any(0))[0].max()) + off[f] for s, f in zip(shots, frames) if (s >= 0).any())) - lo_x + 1
    strip = np.full((224, width), -1, np.int64)
    words = {}
    for s, f, pal in zip(shots, frames, pals):
        ys, xs = np.nonzero(s >= 0)
        strip[ys, xs + off[f] - lo_x] = s[ys, xs]
        for v in np.unique(s[s >= 0]):
            words.setdefault(int(v), set()).add(int(pal[v]))
    if any((len(w) > 1 for w in words.values())):
        raise SystemExit('sky: a palette entry changes during the pan (fade) inside the pinned range')
    color = {v: next(iter(w)) for v, w in words.items()}
    y0, y1 = (spec['box'][1], spec['box'][3])
    vce = np.where(strip >= 0, np.vectorize(lambda v: color.get(int(v), -1) if v >= 0 else -1)(strip), -1)
    return (vce[y0:y1], {f: lo_x - off[f] for f in frames})

def still_layers(cap, name, spec):
    """(A, B): 128-row arrays of VCE colors (-1 = transparent). A is the main picture (SCROLL3,"""
    d = _load(cap, spec['frame'], spec['dump_sha256'])
    idx = _composite(d)
    x0, y0, x1, y1 = spec['box']
    crop = idx[y0:y1, x0:x1]
    lo, hi = MAIN[spec['main']]
    a_win = np.full((WIN_H, WIN_W), -1, np.int64)
    b_win = np.full((WIN_H, WIN_W), -1, np.int64)
    ox = STILL_X[name]
    sub = (slice(0, crop.shape[0]), slice(ox, ox + crop.shape[1]))
    vce = d['pal'][crop].astype(np.int64)
    is_a = (crop >= lo) & (crop <= hi) & (crop & 15 != 0)
    is_b = ~is_a & (crop & 15 != 0)
    a_win[sub] = np.where(is_a, vce, -1)
    b_win[sub] = np.where(is_b, vce, -1)
    return (a_win, b_win)

def pens_of(tile, colors):
    out = np.full(tile.shape, 15, np.int64)
    for i, c in enumerate(colors):
        out[tile == c] = i
    return out

def build_stills(cap, man):
    stills = man['stills']
    order = ['s00', 's01', 's02', 's03']
    s3_tiles, s3_index = ([], {})
    s2_tiles, s2_index = ([], {})
    out = {}
    b_sets = []
    layers = {}
    for name in order:
        spec = stills[name]
        a, b = still_layers(cap, name, spec)
        pan = None
        if 'pan' in spec:
            strip, left = sky_strip(cap, spec)
            a = np.full((WIN_H, 32 * S3_COLS), -1, np.int64)
            if strip.shape[1] > a.shape[1]:
                raise SystemExit(f'sky strip {strip.shape[1]} px wider than {S3_COLS} SCROLL3 columns')
            a[:, :strip.shape[1]] = strip
            pan = left
        layers[name] = (a, b, pan)
        for ty in range(WIN_H // 16):
            for tx in range(WIN_W // 16):
                t = b[16 * ty:16 * ty + 16, 16 * tx:16 * tx + 16]
                s = frozenset((int(v) for v in np.unique(t[t >= 0])))
                if len(s) > 15:
                    raise SystemExit(f'{name}: overlay cell {tx},{ty} has {len(s)} colors')
                if s:
                    b_sets.append(s)
    b_pals = []
    for s in sorted(set(b_sets), key=lambda s: (-len(s), sorted(s))):
        for p in b_pals:
            if len(p | s) <= 15:
                p |= s
                break
        else:
            b_pals.append(set(s))
    b_pals = [sorted(p) for p in b_pals]
    if len(b_pals) > 30:
        raise SystemExit('too many overlay palettes')
    mask_code = S2_LAST
    s2_tiles.append(('mask', np.zeros((16, 16), np.int64)))
    next_s2 = S2_LAST - 1
    next_s3 = S3_FIRST
    for name in order:
        a, b, pan = layers[name]
        colors = sorted(set((int(v) for v in np.unique(a[a >= 0]))))
        if len(colors) > 15:
            raise SystemExit(f'{name}: main picture has {len(colors)} colors')
        s3 = []
        for c in range(S3_COLS):
            for r in range(4):
                t = a[32 * r:32 * r + 32, 32 * c:32 * c + 32] if 32 * c < a.shape[1] else np.full((32, 32), -1)
                if t.shape[1] < 32:
                    t = np.pad(t, ((0, 0), (0, 32 - t.shape[1])), constant_values=-1)
                if (t < 0).all():
                    s3.append(S3_BLANK)
                    continue
                pens = pens_of(t, colors)
                key = pens.tobytes()
                if key not in s3_index:
                    s3_index[key] = next_s3
                    s3_tiles.append((next_s3, pens))
                    next_s3 += 1
                s3.append(s3_index[key])
        s2 = []
        for c in range(S2_COLS):
            for r in range(8):
                if c < 10 or c >= 22:
                    s2.append((mask_code, 1))
                    continue
                t = b[16 * r:16 * r + 16, 16 * (c - 10):16 * (c - 10) + 16]
                s = set((int(v) for v in np.unique(t[t >= 0])))
                if not s:
                    s2.append((S2_BLANK, 0))
                    continue
                pal = next((i for i, p in enumerate(b_pals) if s <= set(p)))
                pens = pens_of(t, b_pals[pal])
                key = (pens.tobytes(), pal)
                if pens.tobytes() not in s2_index:
                    s2_index[pens.tobytes()] = next_s2
                    s2_tiles.append((next_s2, pens))
                    next_s2 -= 1
                s2.append((s2_index[pens.tobytes()], 2 + pal))
        s3_pal = [G.cps_color(c) for c in colors] + [61440] * (16 - len(colors))
        entry = dict(s3=s3, s2=s2, s3_palette=s3_pal, colors=len(colors))
        if pan is not None:
            entry['pan_left'] = pan
        out[name] = entry
    if next_s3 - 1 >= 16352 or next_s2 + 1 <= 33751:
        raise SystemExit('ending codes overflow their ranges')
    s2_pals = [[61440] * 16]
    for p in b_pals:
        s2_pals.append([G.cps_color(c) for c in p] + [61440] * (16 - len(p)))
    tiles_s2 = [(code, pens) for code, pens in s2_tiles if not isinstance(code, str)]
    tiles_s2.insert(0, (mask_code, np.zeros((16, 16), np.int64)))
    return dict(stills=out, s3_tiles=s3_tiles, s2_tiles=tiles_s2, s2_palettes=s2_pals, s3_codes=(S3_FIRST, next_s3 - 1), s2_codes=(next_s2 + 1, S2_LAST), layers=layers)

def schedule(man, cap, stills):
    """Cut table (ending_frame frames, still index) and the sky's pan table."""
    import pce_cinematic_census as PC
    idx = PC.read_index(cap)
    req = [r for r in PC.cd_requests(cap) if r[2] == 29]
    if not req:
        raise SystemExit(f'{cap}: no CD_PLAY of track 29 in the capture')
    onset = PC.audio_onset(cap, req[0][1])
    order = [s['still'] for s in man['sections']]
    cuts = [(round(s['cut_s'] * FPS) - LOOP0 + 1, order.index(s['still'])) for s in man['sections']]
    pan = []
    left = stills['stills']['s02']['pan_left']
    for f in sorted(left):
        tau = float(idx[f]['time']) - onset
        ef = round(tau * FPS) - LOOP0 + 1
        v = 160 - (96 + left[f])
        if not pan or pan[-1][1] != v:
            pan.append((ef, v))
    c02 = cuts[order.index('s02')][0]
    pan = [(max(ef, c02), v) for ef, v in pan]
    if pan[0][0] > c02:
        pan.insert(0, (c02, pan[0][1]))
    return dict(cuts=cuts, pan=pan, onset_s_after_request=round(onset - req[0][1], 3))

def build(rom_dir, cap, man=None):
    man = man or json.loads(MANIFEST.read_text())
    progs = stock_programs(rom_dir)
    regions = {}
    for m, img in progs.items():
        check_sig(img, m)
        rows, plan = roll_table(man, stock_rows(img, m), m)
        blocks = [encode_block(rows[32 * k:32 * k + 32]) for k in range(NBLOCKS)]
        regions[m] = dict(addrs=region_addrs(img, m), rows=rows, plan=plan, blocks=blocks, program_sha256=sha(img))
    stills = build_stills(cap, man)
    sched = schedule(man, cap, stills)
    holds = {r['plan']['hold'] for r in regions.values()}
    assert len(holds) == 1
    return dict(regions=regions, stills=stills, schedule=sched, hold=holds.pop(), manifest_sha256=sha(MANIFEST.read_bytes()))

def install(region, data):
    """Write the ending's tiles into the 4 MB EX graphics region; the target tiles must be unused."""
    for code, pens in data['stills']['s3_tiles']:
        base = G.ex_offset('scr3', code)
        if any(region[base:base + 512]):
            raise SystemExit(f'EX SCROLL3 code {code:#06x} is already in use')
        G.put_tile(region, base, pens)
    for code, pens in data['stills']['s2_tiles']:
        base = G.ex_offset('scr2', code)
        if any(region[base:base + 128]):
            raise SystemExit(f'EX SCROLL2 code {code:#06x} is already in use')
        G.put_tile(region, base, pens)
    return dict(s3=[f'{c:#06x}' for c in data['stills']['s3_codes']], s2=[f'{c:#06x}' for c in data['stills']['s2_codes']], s3_count=len(data['stills']['s3_tiles']), s2_count=len(data['stills']['s2_tiles']))

def _words(ws, per=8):
    return '\n'.join(('        dc.w    ' + ','.join((f'${w & 65535:04X}' for w in ws[i:i + per])) for i in range(0, len(ws), per)))

def data_inc(data):
    """ending_data.inc for asm/ending.s: region equates and blocks, still tables, cuts, pan."""
    st = data['stills']
    n2 = len(st['s2_palettes'])
    if 16775696 + 2 * (32 + 16 * (n2 + 1)) > 16776192:
        raise SystemExit('ending: the fade snapshot would run past 0xFFFC00')
    lines = ['; generated by backports/striderex/scripts/ending_ex.py (do not edit)', f'END_NBLOCKS equ {NBLOCKS}', f'END_NS2PAL  equ {n2}', f'END_FADEW   equ {32 + 16 * (n2 + 1)}', f'END_FADE    equ {FADE}', f"END_SPAWN_F equ {STOCK_SPAWN - LOOP0 + 2}    ; ending_frame frame after the stock spawn's"]
    for m, cond in (('striderua', 'ifne'), ('striderjr', 'ifeq')):
        r = data['regions'][m]
        a = r['addrs']
        lines += [f'        {cond} REGION_EN', f"END_WRITER  equ ${a['writer']:X}", f"END_SPAWN   equ ${a['spawn']:X}", f"END_OBJUPD  equ ${a['objupd']:X}", f"END_WATER_RET equ ${a['water_ret']:X}", 'end_blocks:'] + [f'        dc.l    end_blk{k}' for k in range(NBLOCKS)]
        for k, b in enumerate(r['blocks']):
            lines.append(f'end_blk{k}:')
            for i in range(0, len(b), 16):
                lines.append('        dc.b    ' + ','.join((f'${x:02X}' for x in b[i:i + 16])))
        lines += ['        even', '        endc']
    lines.append('end_stills:')
    order = ['s00', 's01', 's02', 's03']
    for name in order:
        lines.append(f'        dc.l    end_{name}_s3,end_{name}_s2,end_{name}_pal,' + (f'end_{name}_pan' if 'pan_left' in st['stills'][name] else '0'))
    for name in order:
        e = st['stills'][name]
        lines += [f'end_{name}_s3:', _words(e['s3']), f'end_{name}_s2:', _words([w for c, p in e['s2'] for w in (c, p)]), f'end_{name}_pal:']
        tgt = e['s3_palette'] + [61440] * 16 + [61440] * 16 + [w for p in st['s2_palettes'] for w in p]
        lines.append(_words(tgt))
    pan = data['schedule']['pan']
    lines.append('end_s02_pan:')
    lines.append(_words([w for ef, v in pan for w in (ef, v)] + [65535, 0]))
    lines.append('end_cuts:')
    lines.append(_words([w for f, s in data['schedule']['cuts'] for w in (f, s)] + [65535, 0]))
    lines.append('end_scale:')
    for lv in range(16):
        lines.append('        dc.b    ' + ','.join((f'${(n * lv + 7) // 15:02X}' for n in range(16))))
    lines.append('        even')
    return '\n'.join(lines) + '\n'

def patch_list(img, machine, syms, data):
    d = 0 if machine == 'striderua' else JR_DELTA
    hold = data['hold']
    if not 2100 < hold < 32768:
        raise SystemExit(f'hold {hold} out of range')

    def jmp(op, sym):
        return bytes.fromhex(op) + syms[sym].to_bytes(4, 'big')
    out = [(50368 - d, bytes.fromhex('00f8'), bytes.fromhex('0100')), (50516 - d, bytes.fromhex('0834'), hold.to_bytes(2, 'big')), (50892 - d, bytes.fromhex('7000102d8cdd'), jmp('4ef9', 'ending_text')), (50316 - d, bytes(img[50316 - d:50322 - d]), jmp('4eb9', 'ending_frame')), (50632 - d, bytes.fromhex('302d201ed040'), jmp('4ef9', 'ending_water'))]
    if out[3][1][:2] != b'N\xb9':
        raise SystemExit(f'{machine}: the roll loop object-update call has an unexpected shape')
    return out

def patch_program(img, machine, syms, data):
    """Apply the ending's program changes in place after checking every stock byte."""
    check_sig(bytes(img), machine)
    done = []
    for at, stock, new in patch_list(img, machine, syms, data):
        if bytes(img[at:at + len(stock)]) != stock:
            raise SystemExit(f'{machine}: {at:#x} holds {bytes(img[at:at + len(stock)]).hex()}, not stock {stock.hex()}')
        img[at:at + len(new)] = new
        done.append(dict(at=f'{at:#x}', stock=stock.hex(), new=new.hex()))
    return done

def loop_song(snd, cmd=33):
    """Song `cmd` re-laid out so every track's end loops back to the track's start, with the stock"""
    import restore_tunes as RT
    at, count = RT.arcade_table(snd)
    ptrs = RT.table_ptrs(snd, at, count)
    start = ptrs[cmd]
    if start < RT.FREE_BASE:
        raise SystemExit(f'song {cmd:#04x} is not a restored song (at {start:#06x})')
    tracks, covered = RT.song_walk(snd, start, RT.FREE_END)
    end = max(covered) + 1
    ops = {}
    owner = {}
    for tr in tracks:
        for p, (b, opr) in tr['ops'].items():
            ops[p] = (b, opr)
            if b == 15:
                if p in owner and owner[p] != tr['start']:
                    raise SystemExit(f'track end {p:#06x} is shared by two tracks')
                owner[p] = tr['start']
    used_end = max(start + 17, *(p + 1 + len(o[1]) for p, o in ops.items()))
    data_end = max(used_end, *(int(p) + 1 for p in covered))
    new = max(data_end, *(q for q in ptrs if q >= RT.FREE_BASE)) + 31 & ~15
    while any((b not in (0, 255) for b in snd[new:new + 1])):
        new += 16
    addr = {}
    pos = new + 17
    for p in sorted(ops):
        addr[p] = pos
        b, opr = ops[p]
        pos += 5 if b == 15 else 1 + len(opr)
    size = pos - new
    if pos > RT.FREE_END or any((x not in (0, 255) for x in snd[new:pos])):
        raise SystemExit(f'no free space for the looping song at {new:#06x}-{pos:#06x}')
    out = bytearray(snd)
    blob = bytearray(snd[start:start + 17])
    for k, t in enumerate(RT.header_ptrs(snd, start)):
        if t:
            blob[1 + 2 * k:3 + 2 * k] = addr[t].to_bytes(2, 'little')
    for p in sorted(ops):
        b, opr = ops[p]
        if b == 15:
            blob += bytes([5, 0]) + addr[owner[p]].to_bytes(2, 'little') + b'\x0f'
            continue
        opr = bytearray(opr)
        if b in RT.ADDR_AT:
            o = RT.ADDR_AT[b]
            tgt = opr[o] | opr[o + 1] << 8
            opr[o:o + 2] = addr[tgt].to_bytes(2, 'little')
        blob += bytes([b]) + bytes(opr)
    assert len(blob) == size
    out[new:pos] = blob
    out[at + 2 * cmd:at + 2 * cmd + 2] = new.to_bytes(2, 'little')
    if any((b == 5 for b, _ in ops.values())):
        raise SystemExit(f'song {cmd:#04x} uses op 0x05 itself; the loop op would share its counter')
    t2, cov2 = RT.song_walk(bytes(out), new, pos)
    for tr in t2:
        last = max(tr['ops'])
        b, _ = tr['ops'][last]
        lb, lo = tr['ops'][last - 4]
        if b != 15 or lb != 5 or lo != bytes([0]) + tr['start'].to_bytes(2, 'little'):
            raise SystemExit(f"looping song: track at {tr['start']:#06x} does not end in its loop")
    if cov2 != set(range(new, pos)):
        raise SystemExit('looping song does not walk cleanly')
    changed = [k for k in range(len(snd)) if snd[k] != out[k]]
    if not set(changed) <= set(range(new, pos)) | {at + 2 * cmd, at + 2 * cmd + 1}:
        raise SystemExit('loop patch touched other bytes')
    return (bytes(out), dict(command=f'{cmd:#04x}', one_shot_at=f'{start:#06x}', one_shot_size=end - start, loop_at=f'{new:#06x}', loop_size=size, tracks=len(tracks), track_ends_to_jumps=len(owner), bytes_changed=len(changed), sha256=sha(bytes(out))))

def hb_rgb(word):
    bright = 15 + (word >> 12 << 1)
    return tuple((c * 17 * bright // 45 if c > 1 else 0 for c in (word >> s & 15 for s in (8, 4, 0))))

def window_model(data, name, pan_v=0):
    """Expected RGB of the 192x128 window for a still (HBMAME colors), -1 where nothing is drawn."""
    st = data['stills']
    tiles3 = dict(st['s3_tiles'])
    tiles2 = dict(st['s2_tiles'])
    e = st['stills'][name]
    out = np.full((WIN_H, WIN_W, 3), -1, np.int64)
    pal3 = e['s3_palette']
    for i, code in enumerate(e['s3']):
        c, r = divmod(i, 4)
        if code == S3_BLANK:
            continue
        pens = tiles3[code]
        x0 = 32 * c - pan_v
        for y in range(32):
            for x in range(32):
                p = pens[y, x]
                X = x0 + x
                if p != 15 and 0 <= X < WIN_W:
                    out[32 * r + y, X] = hb_rgb(pal3[p])
    for i, (code, pal) in enumerate(e['s2']):
        c, r = divmod(i, 8)
        if c < 10 or c >= 22 or code == S2_BLANK:
            continue
        pens = tiles2[code]
        words = st['s2_palettes'][pal - 1]
        for y in range(16):
            for x in range(16):
                p = pens[y, x]
                if p != 15:
                    out[16 * r + y, 16 * (c - 10) + x] = hb_rgb(words[p])
    return out

def previews(data, workdir):
    from PIL import Image
    for name in ('s00', 's01', 's02', 's03'):
        m = window_model(data, name)
        img = np.where(m < 0, 0, m).astype(np.uint8)
        Image.fromarray(img).resize((WIN_W * 2, WIN_H * 2), Image.NEAREST).save(workdir / f'still_{name}.png')

def cmd_build(a):
    work = a.workdir.resolve()
    work.mkdir(parents=True, exist_ok=False)
    data = build(a.rom_dir.resolve(), a.census.resolve() / 'ending')
    region = bytearray(4 * G.MB)
    inst = install(region, data)
    (work / 'ending_data.inc').write_text(data_inc(data))
    previews(data, work)
    rep = dict(manifest_sha256=data['manifest_sha256'], hold=data['hold'], install=inst, schedule=dict(cuts=data['schedule']['cuts'], pan_entries=len(data['schedule']['pan']), pan_first=data['schedule']['pan'][0], pan_last=data['schedule']['pan'][-1]), regions={m: dict(plan=r['plan'], addrs={k: hex(v) for k, v in r['addrs'].items()}) for m, r in data['regions'].items()}, s2_palettes=len(data['stills']['s2_palettes']))
    for m, r in data['regions'].items():
        (work / f'rows_{m}.txt').write_text('\n'.join((f'{i:3d}|{t}' for i, t in enumerate(r['rows']))) + '\n')
    (work / 'ending_report.json').write_text(json.dumps(rep, indent=1) + '\n')
    print(json.dumps(rep, indent=1))
    return 0

def cmd_testbuild(a):
    import build_ex as BX
    import mapper_testkit as K
    import respawn_fix as RF
    import restore_tunes as RT
    import title_ex as TX
    out = a.out.resolve()
    out.mkdir(parents=True, exist_ok=False)
    work = out / 'work'
    work.mkdir()
    rom_dir = a.rom_dir.resolve()
    census = a.census.resolve()
    cues = json.loads(BX.CUES.read_text())
    cv, scenes = BX.convert_scenes(census, a.scenes.split(','))
    title_cells = TX.install(cv.region, TX.stock_gfx(K.pool([rom_dir / 'striderua'])))
    data = build(rom_dir, census / 'ending')
    inst = install(cv.region, data)
    (work / 'ending_data.inc').write_text(data_inc(data))
    gfx = G.split_region(cv.region)
    snd, _ = RT.load_sound(rom_dir)
    bank, _ = RT.load_bank(a.x68k_archive)
    sound, _ = RT.build_patch(snd, bank)
    sound, loop_rep = loop_song(sound)
    wrapper = work / 'ex_bank_ending.s'
    wrapper.write_text((ASM / 'ex_bank.s').read_text() + '\n        include "ending.s"\n')
    report = dict(scenes=[s['id'] for s in scenes], ending_install=inst, sound_loop=loop_rep, sets={}, hold=data['hold'], schedule=data['schedule']['cuts'])
    for machine, layout in RF.SETS.items():
        region_en = 1 if machine == 'striderua' else 0
        for s in scenes:
            (work / f"scene_{s['id']}.lz").write_bytes(s['lz'])
            (work / f"scene_{s['id']}.bin").write_bytes(s['stream'])
        (work / 'stage_lists.inc').write_text(BX.stage_lists(scenes, cues))
        (work / 'title_cells.inc').write_text(TX.cells_inc(title_cells[machine]))
        binf, lst = (work / f'ex_bank_{region_en}.bin', work / f'ex_bank_{region_en}.lst')
        subprocess.run([str(a.vasm), '-Fbin', '-m68000', '-quiet', '-I', str(ASM), '-I', str(work), f'-DREGION_EN={region_en}', '-L', str(lst), '-o', str(binf), str(wrapper)], cwd=work, check=True)
        syms = {}
        for line in lst.read_text().splitlines():
            f = line.split()
            if len(f) == 2 and f[1][:2] in ('A:', 'E:'):
                syms[f[0]] = int(f[1][2:], 16)
        code = binf.read_bytes()
        bank_img = bytearray(b'\xff' * BX.MB)
        bank_img[:len(code)] = code
        bank_img[BX.MB - 16:] = BX.FLAG_BLOCK
        src = rom_dir / machine
        files = {q.name: q.read_bytes() for q in src.iterdir() if q.is_file()}
        sizes = {n: len(files[n]) for n, _, _ in layout}
        img = RF.compose(files, layout)
        RF.patch_image(img, a.vasm, work)
        BX.patch_program(img, machine, syms)
        patches = patch_program(img, machine, syms, data)
        d = out / machine
        d.mkdir()
        for n, b in RF.decompose(img, layout, sizes).items():
            if b != files[n]:
                (d / n).write_bytes(b)
        (d / 'strex_p6.bin').write_bytes(bytes((b for i in range(0, BX.MB, 2) for b in (bank_img[i + 1], bank_img[i]))))
        (d / BX.SOUND_MEMBER[machine]).write_bytes(sound)
        for n, b in zip(BX.EX_GFX, gfx):
            (d / n).write_bytes(b)
        report['sets'][machine] = dict(ex_bank_bytes=len(code), patches=patches, syms={k: f'{syms[k]:#x}' for k in ('ending_text', 'ending_frame', 'ending_water')}, streams={s['id']: syms[f"stream_{s['id']}"] for s in scenes}, files={q.name: sha(q.read_bytes()) for q in sorted(d.iterdir())})
        print(machine, 'EX bank', len(code), 'bytes', flush=True)
    (out / 'build.json').write_text(json.dumps(dict(report, sets_build={m: dict(streams=v['streams']) for m, v in report['sets'].items()}), indent=1) + '\n')
    (out / 'ending_build.json').write_text(json.dumps(report, indent=1) + '\n')
    return 0
GATE_LUA = "\ndofile(os.getenv('STREX_BASE_LUA'))\nlocal m=manager.machine\nlocal sp=m.devices[':maincpu'].spaces['program']\nlocal screen=m.screens[':screen']\nlocal out=os.getenv('OUT')\nlocal last=tonumber(os.getenv('LAST'))\nlocal shots={}\nfor v in string.gmatch(os.getenv('SHOTS') or '','%d+') do shots[tonumber(v)]=true end\nlocal log=assert(io.open(out..'/roll.tsv','w'))\nlocal wr=assert(io.open(out..'/s1writes.tsv','w'))\nlocal f,f21,prev=0,nil,''\nlocal credit_frame=tonumber(os.getenv('CREDIT_FRAME') or '-1')\nlocal function sc() return sp:read_u16(0xff0c2e) end\n_G.end_t1=sp:install_write_tap(0x800180,0x800181,'end_snd',function(off,data,mask)\n local v=data&0xff\n if v~=0xff then log:write(string.format('S\\t%d\\t%02x\\n',f,v)) end\n if v==0x21 and not f21 then f21=f end\nend)\n_G.end_t2=sp:install_write_tap(0x908000,0x90bfff,'end_s1',function(off,data,mask)\n if f21 and (off&2)==0 then\n  local old=sp:read_u16(off)\n  if old~=data then wr:write(string.format('%d\\t%06x\\t%04x\\t%04x\\t%d\\n',f+1,off,old,data,sc())) end\n end\nend)\nlocal start\nfor _,port in pairs(m.ioport.ports) do for name,field in pairs(port.fields) do\n if m.ioport:input_type_to_token(field.type,field.player)=='START1' then start=field end end end\nemu.register_frame_done(function()\n f=f+1\n -- a cinematic before the stage (EX player active): skip it with a fresh START press\n if sp:read_u16(0xfff914)==0xc1e5 and f%20<4 then start:set_value(1) end\n local row=string.format('%d\\t%d\\t%d\\t%d\\t%d\\t%d\\t%d\\t%d\\t%d',sp:read_u8(0xff0cdc),sp:read_u8(0xff0cdd),sp:read_u16(0xffa01c),\n  sc(),sp:read_u16(0xfffa00),sp:read_u16(0xfffa02),sp:read_u16(0xfffa04),sp:read_u16(0xff0c3c),sp:read_u8(0xff0c84))\n if row~=prev then log:write('R\\t'..f..'\\t'..row..'\\n'); prev=row end\n if f21 and shots[f-f21] then screen:snapshot(string.format('%s/s_%05d.png',out,f-f21)) end\n if f21 and f-f21==credit_frame then\n  local map=assert(io.open(out..'/credit_s1.bin','wb'))\n  for addr=0x908000,0x90bffe,2 do\n   local word=sp:read_u16(addr)\n   map:write(string.char((word>>8)&0xff,word&0xff))\n  end\n  map:close()\n end\n log:flush() wr:flush()\n if f>=last then m:exit() end\nend)\n"

def stage_stock(a, work, names):
    import mapper_testkit as K
    import strider_mapper_probe as M
    driver = (a.runtime / 'source/src/hbmame/drivers/cps1.cpp').read_text()
    pool = K.pool([a.rom_dir.resolve()])
    stock_dir = work / 'stock_sets'
    for name in names:
        d = stock_dir / name
        d.mkdir(parents=True)
        for member, _, _, c in M.rom_entries(driver, name):
            data = pool.get(c) if c else None
            if data is None and member.endswith('.key'):
                data = M.cps1_key(M.ST24M1, 'CPS_B_01' if name == 'striderua' else 'CPS_B_21_DEF')
            if data is None:
                raise SystemExit(f'{name}/{member}: no stock file with CRC {c}')
            (d / member).write_bytes(data)
    return stock_dir

def gate_run(binary, rompath, set_name, out, last, shots, credit_frame=None):
    out.mkdir(parents=True)
    (out / 'gate.lua').write_text(GATE_LUA)
    env = dict(os.environ, SDL_VIDEODRIVER='dummy', SDL_AUDIODRIVER='dummy', OUT=str(out), LAST=str(last), SHOTS=','.join(map(str, shots)), CREDIT_FRAME=str(credit_frame if credit_frame is not None else -1), STREX_BASE_LUA=str(DEBUG_START), STREX_PREFIX=str(out / 'dbg'), STREX_STAGE='4', STREX_AREA='10', STREX_INVINCIBLE='1', STREX_INVINCIBLE_END='1420', STREX_END=str(last + 10), STREX_INPUTS='450-1400@6/3:P1_BUTTON1')
    cmd = [str(binary), set_name, '-rompath', str(rompath), '-nothrottle', '-video', 'none', '-sound', 'none', '-seconds_to_run', str(last // 50 + 60), '-skip_gameinfo', '-noautosave', '-cfg_directory', str(out / 'cfg'), '-nvram_directory', str(out / 'nv'), '-snapshot_directory', str(out), '-autoboot_script', str(out / 'gate.lua')]
    p = subprocess.run(cmd, env=env, cwd=out, capture_output=True, text=True, timeout=1800)
    (out / 'mame.log').write_text(p.stdout + p.stderr)
    if p.returncode:
        raise SystemExit(f'{out}: exit {p.returncode}')
    rows, snd = ([], [])
    for line in (out / 'roll.tsv').read_text().splitlines():
        k, *v = line.split('\t')
        if k == 'R':
            rows.append([int(x) for x in v])
        else:
            snd.append((int(v[0]), int(v[1], 16)))
    writes = [(int(f), int(ad, 16), int(o, 16), int(n, 16), int(s)) for f, ad, o, n, s in (l.split('\t') for l in (out / 's1writes.tsv').read_text().splitlines())]
    return (rows, snd, writes)

def visible_changes(writes, f21):
    """SCROLL1 cells that change while their row is on screen (screen y of the row in -7..223)."""
    bad = []
    for f, addr, old, new, sc in writes:
        off = addr - 9469952
        row = off >> 2 & 31 | (off >> 13 & 1) << 5
        col = off >> 7 & 63
        if col > 18:
            continue
        s = 512 - sc & 511
        y = (8 * row + ROW_Y0 - s) % 512
        if y < 224 or y > 512 - 8:
            bad.append(dict(frame=f - f21, row=row, col=col, y=y if y < 224 else y - 512, old=f'{old:#06x}', new=f'{new:#06x}'))
    return bad

def sound_loop_gate(work, rom_dir, looped, oneshot):
    """MAME: 0x21 from the looping ROM against the one-shot restored ROM (stock MAME, 68K parked)."""
    import restore_tunes as RT
    res = {}
    for name, rom in (('oneshot', oneshot), ('looped', looped)):
        d = work / f'sound_{name}' / 'roms' / 'striderua'
        d.mkdir(parents=True)
        (d / '09.12b').write_bytes(rom)
        log = RT.run_mame('striderua', f'{d.parent};{rom_dir}', work / f'sound_{name}' / 'run', {'RT_MODE': 'arcade', 'RT_CMDS': '21', 'RT_SLOT': '125'}, 150)
        res[name] = {ch: [e for e in v if e[1] >= 0] for ch, v in RT.parse_log(log)[33]['keyons'].items()}
    one, loop = (res['oneshot'], res['looped'])
    rep = dict(channels=sorted(one), periods={}, problems=[])
    if sorted(one) != sorted(loop):
        rep['problems'].append(f'channels {sorted(loop)} vs one-shot {sorted(one)}')
    for ch in sorted(set(one) & set(loop)):
        n = len(one[ch])
        a, b = (one[ch], loop[ch])
        if len(b) < 2 * n:
            rep['problems'].append(f'ch{ch}: {len(b)} key-ons, fewer than two passes ({2 * n})')
            continue
        if [k for _, k in b[:n]] != [k for _, k in a] or [k for _, k in b[n:2 * n]] != [k for _, k in a]:
            rep['problems'].append(f'ch{ch}: a pass differs from the one-shot notes')
        first = max((abs(tb - ta) for (tb, _), (ta, _) in zip(b[:n], a)))
        period = b[n][0] - b[0][0]
        second = max((abs(b[n + i][0] - period - b[i][0]) for i in range(n)))
        rep['periods'][ch] = round(period, 4)
        if first > 0.02 or second > 0.02:
            rep['problems'].append(f'ch{ch}: timing off by {max(first, second):.3f} s')
    ps = list(rep['periods'].values())
    if ps and max(ps) - min(ps) > 0.02:
        rep['problems'].append(f'tracks loop with different periods {sorted(set(ps))}: they drift apart')
    rep['period_s'] = ps[0] if ps else None
    rep['passed'] = not rep['problems']
    return rep

def cmd_gate(a):
    from PIL import Image
    work = a.workdir.resolve()
    work.mkdir(parents=True, exist_ok=False)
    parent = {'striderus01': 'striderua', 'striderjs01': 'striderjr'}[a.set]
    binary = json.loads((a.runtime / 'runtime.json').read_text())['binary']
    rom_dir = a.rom_dir.resolve()
    data = build(rom_dir, a.census.resolve() / 'ending')
    plan = data['regions'][parent]['plan']
    total = plan['frames_from_0x21']
    cuts = data['schedule']['cuts']
    credit_frame = 3 * (8 * plan['ex_credit']['role_row'] + ROW_Y0 - 110 - 1) + SCROLL0
    shots = sorted(set(list(range(60, total - FADE_OUT, 120)) + [f + LOOP0 - 1 + FADE + 8 for f, _ in cuts] + [round(t * FPS) for t in (80.0, 90.0, 100.0)] + [credit_frame]))
    sets = work / 'ex_sets'
    subprocess.run([sys.executable, str(HERE / 'hbmame_set.py'), 'build', '--hbmame', str(a.hbmame), '--rom-dir', str(rom_dir), '--ex-dir', str(a.build.resolve()), '--set', a.set, '--date', '2026-10-10', '--out', str(sets)], check=True, stdout=subprocess.DEVNULL)
    stock_dir = stage_stock(a, work, [parent])
    last_guess = 3000 + total + 300 + AFTER_END
    runs = {}
    for kind, rp, name in (('ex', sets, a.set), ('stock', stock_dir, parent)):
        runs[kind] = gate_run(binary, rp, name, work / f'run_{kind}', last_guess if kind == 'ex' else 5000, shots if kind == 'ex' else [s for s in shots if s < 2500], credit_frame if kind == 'ex' else None)
    rep = dict(set=a.set, plan=plan, cuts=cuts, checks={})
    ok = True

    def first(rows, col, pred, after):
        return next((r[0] for r in rows if r[0] >= after and pred(r[col])), None)
    for kind, (rows, snd, writes) in runs.items():
        f21 = next((f for f, v in snd if v == 33))
        f0e = next((f for f, v in snd if v == 14 and f > f21), None)
        hold = first(rows, 1, lambda v: v == 2, f21)
        fade = first(rows, 1, lambda v: v == 4, f21)
        end = next((r[0] for r in rows if fade and r[0] > fade and (r[1] == 0)), None)
        ef1 = first(rows, 5, lambda v: v == 1, f21) if kind == 'ex' else None
        writes = [w for w in writes if end is None or w[0] < end]
        rep['checks'][kind] = dict(f21=f21, game_over=None if f0e is None else f0e - f21, hold_start=None if hold is None else hold - f21, fade_start=None if fade is None else fade - f21, roll_end=None if end is None else end - f21, ending_frame_1=None if ef1 is None else ef1 - f21, visible_text_changes=visible_changes(writes, f21))
    ex, st = (rep['checks']['ex'], rep['checks']['stock'])
    rows = runs['ex'][0]
    f21 = ex['f21']
    seen = {}
    for r in rows:
        if r[0] >= f21:
            seen.setdefault(r[6], r[0] - f21)
    ex['cut_index_frames'] = seen
    want_cut = {k + 1: f + LOOP0 - 1 + FADE for k, (f, _) in enumerate(cuts)}
    ex['cut_index_expected'] = want_cut
    still_px = {}
    for k, (f, si) in enumerate(cuts):
        name = ['s00', 's01', 's02', 's03'][si]
        at = f + LOOP0 - 1 + FADE + 8
        pan_v = 0
        if name == 's02':
            prev = [r for r in rows if r[0] - f21 <= at - 2]
            pan_v = struct.unpack('>h', prev[-1][8].to_bytes(2, 'big'))[0]
        model = window_model(data, name, pan_v)
        shot = np.asarray(Image.open(work / 'run_ex' / f's_{at:05d}.png').convert('RGB')).astype(np.int64)
        win = shot[WIN_Y:WIN_Y + WIN_H, WIN_X:WIN_X + WIN_W]
        drawn = model[..., 0] >= 0
        diff = (win != np.where(drawn[..., None], model, 0)).any(-1)
        still_px[name] = dict(frame=at, pan=pan_v, drawn=int(drawn.sum()), differing=int(diff.sum()))
    for t in (80.0, 90.0, 100.0):
        at = round(t * FPS)
        shot = np.asarray(Image.open(work / 'run_ex' / f's_{at:05d}.png').convert('RGB')).astype(np.int64)
        win = shot[WIN_Y:WIN_Y + WIN_H, WIN_X:WIN_X + WIN_W]
        best = None
        for back in (1, 2, 3):
            prev = [r for r in rows if r[0] - f21 <= at - back]
            v = struct.unpack('>h', prev[-1][8].to_bytes(2, 'big'))[0]
            model = window_model(data, 's02', v)
            drawn = model[..., 0] >= 0
            n = int((win != np.where(drawn[..., None], model, 0)).any(-1).sum())
            if best is None or n < best[2]:
                best = (back, v, n, int(drawn.sum()))
        still_px[f's02_pan_{at}'] = dict(frame=at, pan=best[1], frames_back=best[0], drawn=best[3], differing=best[2])
    ex['stills'] = still_px
    changed = min(min(plan['copyright_stock_rows']), plan['ex_credit']['first_changed_row'])
    limit = 3 * (8 * changed + 16 - 1) + SCROLL0 - 3
    same, compared = ([], 0)
    for s in shots:
        if s >= limit:
            break
        pa, pb = (work / 'run_ex' / f's_{s:05d}.png', work / 'run_stock' / f's_{s:05d}.png')
        if pa.exists() and pb.exists():
            A = np.asarray(Image.open(pa).convert('RGB'))
            B = np.asarray(Image.open(pb).convert('RGB'))
            compared += 1
            n = int((A != B).any(-1).sum())
            if n:
                same.append((s, n))
    rep['arcade_part'] = dict(compared=compared, until_frame=limit, frames_differing=same)
    cell_bytes = (work / 'run_ex/credit_s1.bin').read_bytes()
    if len(cell_bytes) != 16384:
        raise SystemExit('ending credit SCROLL1 dump is incomplete')
    credit_rows = []
    for row, text in ((plan['ex_credit']['role_row'], EX_CREDIT_ROLE), (plan['ex_credit']['name_row'], EX_CREDIT_NAME)):
        expected = font_row(text)
        base = 9469952 + ((row & 31) << 2) + ((row & 32) << 8)
        bad = [col for col, char in enumerate(expected) if struct.unpack_from('>H', cell_bytes, base - 9469952 + col * 128)[0] != 28672 | ord(char)]
        credit_rows.append(dict(row=row, text=text, differing_cells=bad))
    rep['ex_credit'] = dict(frame=credit_frame, screenshot=f'run_ex/s_{credit_frame:05d}.png', rows=credit_rows)
    import restore_tunes as RT
    snd_rom, _ = RT.load_sound(rom_dir)
    bank, _ = RT.load_bank(a.x68k_archive)
    oneshot, _ = RT.build_patch(snd_rom, bank)
    looped, lrep = loop_song(oneshot)
    built = (a.build.resolve() / parent / ('09.12b' if parent == 'striderua' else 'sth_09.12a')).read_bytes()
    pce = json.loads((a.build.resolve() / 'build.json').read_text()).get('pce_sfx')
    rep['sound'] = sound_loop_gate(work, rom_dir, built if pce else looped, oneshot)
    sha = lambda b: hashlib.sha256(b).hexdigest()
    rep['sound']['build_rom_is_looped'] = built == looped if not pce else pce['sound_before_sha256'] == sha(looped) and pce['sound_sha256'] == sha(built)
    if pce:
        rep['sound']['pce_sfx'] = dict(looped_sha256=sha(looped), built_sha256=sha(built))
    stock_bad = [b for b in st['visible_text_changes']]
    req = {'roll_end_frame': ex['roll_end'] == total, 'hold_start_unchanged': ex['hold_start'] == st['hold_start'] == HOLD_START, 'fade_start': ex['fade_start'] == total - FADE_OUT, 'game_over_follows': ex['game_over'] is not None and ex['game_over'] > ex['roll_end'], 'ending_frame_1_at_loop0': ex['ending_frame_1'] == LOOP0, 'no_visible_text_change_ex': not ex['visible_text_changes'], 'stock_negative_control_yossan': len(stock_bad) > 0, 'cuts_on_schedule': all((seen.get(k) == v for k, v in want_cut.items())), 'stills_match_model': all((v['differing'] <= 0.01 * v['drawn'] for v in still_px.values())), 'arcade_part_identical': compared > 0 and (not same), 'ex_credit_in_arcade_staff': all((not row['differing_cells'] for row in credit_rows)), 'sound_loops': rep['sound']['passed'] and rep['sound']['build_rom_is_looped']}
    ge = next((r[0] for r in rows if ex['game_over'] is not None and r[0] > f21 + ex['game_over'] and (r[9] == 0)), None)
    started = [r[0] for r in rows if ge is not None and r[0] > ge and (r[9] != 0)]
    ex['after_the_ending'] = dict(game_end=ge, run_end=last_guess, game_started_without_input=started[:3])
    req['no_game_starts_without_input'] = ge is not None and last_guess - ge >= AFTER_HOLD and (not started)
    rep['requirements'] = req
    ok = all(req.values())
    rep['passed'] = ok
    (work / 'report.json').write_text(json.dumps(rep, indent=1, default=str) + '\n')
    print(json.dumps(req, indent=1))
    print('PASS' if ok else 'FAIL')
    return 0 if ok else 1

def self_test():
    rows = ['    OBJECT DESIGNER'] + [''] * 31
    blob = encode_block(rows) + b'\x00'
    got, end = decode_block(blob, 0)
    assert got == rows and end == len(blob) - 1
    assert font_row('K.M. BROTHERS') == '      K+M+ BROTHERS'
    assert font_row('|  © NEC AVENUE,LTD.') == '  - NEC AVENUE,LTD+'
    assert scrolled(SCROLL0) == 1 and scrolled(SCROLL0 + 3) == 2
    stock = [''] * 96
    stock[0] = '    OBJECT DESIGNER'
    for first, last in ((2, 20), (25, 37), (42, 56)):
        for row in range(first, last + 1, 2):
            stock[row] = font_row('TEST')
    stock[23] = font_row('SCROLL DESIGNER')
    stock[40] = font_row('SOFT PROGRAMMER')
    stock[59], stock[61], stock[63] = (font_row('PLANNING ADVISER'), font_row('TEST'), font_row('TEST'))
    stock[66], stock[68] = (font_row('GAME PLANNER'), font_row('ISUKE'))
    stock[70:73] = ['           ,', '        T+F+S FIRST', '      PLANNING ROOM']
    stock[76:79] = ['          SOFT WARE', '                 IN', '    CP SYSTEM BOARD']
    stock[82:85] = ['  - CAPCOM CO+,LTD+', '  - CAPCOM U+S+A+,INC+', '               1989']
    man = json.loads(MANIFEST.read_text())
    rows, plan = roll_table(man, stock, 'test')
    assert rows[:70] == stock[:70] and '  - CAPCOM CO+,LTD+' in rows[200:]
    assert len(rows) == 32 * NBLOCKS and plan['hold'] == round(115.92 * FPS) - 340
    role, name = (font_row(EX_CREDIT_ROLE), font_row(EX_CREDIT_NAME))
    at = [i for i, r in enumerate(rows) if r == role]
    assert len(at) == 1 and rows[at[0] + 1] == '' and (rows[at[0] + 2] == name)
    assert rows.index(font_row('ISUKE')) < at[0] < rows.index('        T+F+S FIRST')
    assert at[0] < rows.index(font_row('PRODUCE'))
    assert sum((r.count(EX_CREDIT_ROW) for sec in man['sections'] for r in sec['rows'])) == 0
    assert man['arcade']['ex_credit']['rows'].count(EX_CREDIT_ROW) == 1
    original = [r for r in stock[:79] if r]
    kept = [r for r in rows[:plan['arcade_last_row'] + 1] if r and r not in (role, name)]
    assert kept == original and plan['ex_credit']['role_row'] == 71
    assert all((c['passed'] for c in plan['staff_spacing']))
    bad = json.loads(MANIFEST.read_text())
    bad['arcade']['ex_credit']['rows'].pop(0)
    try:
        roll_table(bad, stock, 'spacing negative control')
    except SystemExit as e:
        assert 'ending staff spacing' in str(e)
    else:
        raise AssertionError('the cramped EX heading must fail the staff spacing gate')
    import restore_tunes as RT
    snd = bytearray(65536)
    snd[24832:32768] = b'\xff' * (32768 - 24832)
    at = 3584
    snd[16384:16390] = b'!' + 3840 .to_bytes(2, 'little') + b'\x11' + at.to_bytes(2, 'little')
    snd[16390:16395] = b'G>\x002\x04'
    snd[16395] = 240
    snd[3840] = 47
    for i in range(48):
        snd[at + 2 * i:at + 2 * i + 2] = 24576 .to_bytes(2, 'little')
    snd[24576:24593] = b'\x00' + 24593 .to_bytes(2, 'little') + b'\x00' * 14
    snd[24593:24595] = b'0\x0f'
    s = 25024
    snd[s:s + 17] = b'\x00' + (s + 17).to_bytes(2, 'little') + (s + 20).to_bytes(2, 'little') + b'\x00' * 12
    snd[s + 17:s + 20] = b'@A\x0f'
    snd[s + 20:s + 24] = b'\t\xf0B\x0f'
    snd[at + 66:at + 68] = s.to_bytes(2, 'little')
    out, rep = loop_song(bytes(snd))
    new = int(rep['loop_at'], 16)
    assert RT.table_ptrs(out, at, 48)[33] == new and rep['track_ends_to_jumps'] == 2
    t2, _ = RT.song_walk(out, new, new + rep['loop_size'])
    for tr in t2:
        b, opr = tr['ops'][max(tr['ops']) - 4]
        assert b == 5 and opr[0] == 0 and (opr[1] | opr[2] << 8 == tr['start'])
    print('self-test ok')
    return 0

def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('--self-test', action='store_true')
    sub = p.add_subparsers(dest='cmd')
    x68 = ROOT / 'roms/x68000/Strider Hiryuu (1992)(Capcom).zip'
    s = sub.add_parser('build')
    s.add_argument('--rom-dir', type=Path, required=True)
    s.add_argument('--census', type=Path, required=True)
    s.add_argument('--workdir', type=Path, required=True)
    s = sub.add_parser('testbuild')
    s.add_argument('--rom-dir', type=Path, required=True)
    s.add_argument('--census', type=Path, required=True)
    s.add_argument('--vasm', type=Path, required=True)
    s.add_argument('--out', type=Path, required=True)
    s.add_argument('--x68k-archive', type=Path, default=x68)
    s.add_argument('--scenes', default='flight,welcome_meio')
    s = sub.add_parser('gate')
    s.add_argument('--build', type=Path, required=True)
    s.add_argument('--census', type=Path, required=True)
    s.add_argument('--runtime', type=Path, required=True)
    s.add_argument('--hbmame', type=Path, required=True)
    s.add_argument('--rom-dir', type=Path, required=True)
    s.add_argument('--workdir', type=Path, required=True)
    s.add_argument('--x68k-archive', type=Path, default=x68)
    s.add_argument('--set', default='striderus01', choices=['striderus01', 'striderjs01'])
    a = p.parse_args()
    if a.self_test:
        return self_test()
    if not a.cmd:
        p.error('a subcommand is required')
    return dict(build=cmd_build, testbuild=cmd_testbuild, gate=cmd_gate)[a.cmd](a)
if __name__ == '__main__':
    sys.exit(main())
