"""Capture native desert and stock slope cadence with the prepared runtime."""
import argparse
from concurrent.futures import ThreadPoolExecutor
from collections import Counter
import json
from pathlib import Path
import sys
import desert_gate as G
import desert_smooth as S
import desert_slopes as D
from boss_voice_gate import inventory, sha

def plans():
    out = {name: (stage, area, n, inputs, warp) for name, stage, area, n, inputs, warp in sum(S.walks(), []) if name in ('s0_shaft', 's0', 's1', 's2_turn', 'stock_stpetersburg_turn', 'stock_amazon_turn')}
    for name, stage in (('stock_siberia', 1), ('stock_aerial', 3), ('stock_moon', 4)):
        out[name] = (stage, 1, 1600, None, '')
    return out

def analyze(out):
    rows = S.read_motion(out)
    pairs = [(a, b) for a, b in zip(rows, rows[1:]) if a['frame'] > 650 and a['st'] == b['st'] == 0 and (a['kind'] == b['kind']) and (a['kind'] in range(2, 8)) and (a['hx'] != b['hx'])]
    return dict(slope_frames=len(pairs), world_steps=dict(Counter((str((b['hx'] - a['hx'], b['hy'] - a['hy'])) for a, b in pairs))), screen_steps=dict(Counter((str((b['hx'] - b['camx'] - a['hx'] + a['camx'], b['hy'] - b['camy'] - a['hy'] + a['camy'])) for a, b in pairs))), motion_sha256=sha((out / 'motion.tsv').read_bytes()))

def main():
    if sys.argv[1:2] == ['compare']:
        return compare_main(sys.argv[2:])
    p = argparse.ArgumentParser(description=__doc__)
    for n in ('build', 'runtime', 'hbmame', 'rom-dir', 'workdir'):
        p.add_argument('--' + n, type=Path, required=True)
    p.add_argument('--cases', default='s0_shaft,s0,s2_turn,stock_stpetersburg_turn,stock_amazon_turn')
    p.add_argument('--set', default='striderus01')
    p.add_argument('--reuse', action='store_true')
    a = p.parse_args()
    work = a.workdir.resolve()
    work.mkdir(parents=True, exist_ok=a.reuse)
    meta, _ = inventory(a.build)
    rt = json.loads((a.runtime / 'runtime.json').read_text())
    binary = Path(rt['binary'])
    if sha(binary.read_bytes()) != rt['binary_sha256']:
        raise ValueError('runtime changed')
    roms = work / 'sets'
    if not a.reuse:
        G.stage_sets(a.build.resolve(), a.set, a.hbmame, a.rom_dir.resolve(), roms)
    todo = {k: plans()[k] for k in a.cases.split(',')}

    def run(k):
        stage, area, n, inputs, warp = todo[k]
        out = work / k
        if not a.reuse or not (out / 'motion.tsv').exists():
            env = S.env_of(stage, area, n, inputs, warp)
            env['MOTION'] = '128'
            env['CADENCE'] = '1'
            G.run(binary, roms, a.set, out, env, n)
        result = analyze(out)
        print(k, result['slope_frames'], 'slope frames', flush=True)
        result['cadence_sha256'] = sha((out / 'cadence.tsv').read_bytes())
        return result
    with ThreadPoolExecutor(2) as ex:
        results = dict(zip(todo, ex.map(run, todo)))
    (work / 'report.json').write_text(json.dumps(dict(input_files={m: s['files'] for m, s in meta['sets'].items()}, runtime={k: rt[k] for k in ('binary_sha256', 'source_revision', 'board_wait')}, results=results), indent=2) + '\n')

def compare_main(argv):
    import numpy as np
    import desert_cadence_fix as C
    p = argparse.ArgumentParser(description='Check captured cadence, stock motion, floor following and board timing')
    for n in ('control', 'build', 'control-runs', 'runs', 'rom-dir', 'receipt'):
        p.add_argument('--' + n, type=Path, required=True)
    p.add_argument('--machine', choices=('striderua', 'striderjr'), required=True)
    a = p.parse_args(argv)
    meta = C.audit(a.control, a.build)
    old = json.loads((a.control_runs / 'report.json').read_text())
    new = json.loads((a.runs / 'report.json').read_text())
    cm, _ = inventory(a.control)
    if old['input_files'] != {m: s['files'] for m, s in cm['sets'].items()} or new['input_files'] != {m: s['files'] for m, s in meta['sets'].items()}:
        raise ValueError('capture inputs differ from the audited builds')
    if old['runtime'] != new['runtime'] or not new['runtime']['board_wait']:
        raise ValueError('need matching slower-board captures')
    if old['results'].keys() != new['results'].keys():
        raise ValueError('capture cases differ')
    img, bank = G.images(a.build.resolve(), a.rom_dir.resolve(), a.machine)
    floors = {k: D.Floor(img, bank, D.layer_record(img, 5, k)) for k in range(7)}
    results = []
    cadence = []
    ignored = set()
    import csv
    bits = C.body_bits(img, a.machine)
    for name in new['results']:
        stage, area, n, inputs, warp = plans()[name]
        control = a.control_runs / name
        out = a.runs / name
        before = S.read_motion(control)
        after = S.read_motion(out)
        frames = G.read(out)
        for root, rows in ((control, before), (out, after)):
            if len(rows) != n or sha((root / 'motion.tsv').read_bytes()) != (old if root == control else new)['results'][name]['motion_sha256']:
                raise ValueError('truncated or modified cadence capture')
        dz = G.read_desert(out)
        maps = [b['frame'] for a, b in zip(dz, dz[1:]) if a['map'] != b['map']]
        stock = name.startswith('stock_')
        smooth = S.analyze(frames, after, D.warp_frames(out), stage, not stock, maps)
        if stock:
            oldlag = G.lag(G.read(control), str(stage))
            newlag = G.lag(frames, str(stage))
            if newlag[1] > oldlag[1] or newlag[2] > oldlag[2]:
                raise ValueError('stock lag increased')
            smooth['stock_baseline_lag'] = list(oldlag)
            smooth['candidate_lag'] = list(newlag)
        split = []
        for seg in S.segments(frames, after, D.warp_frames(out), stage):
            for source, visible in zip(seg, seg[S.REG_LAG:]):
                expected = (source['sh3x'] + S.REG_X & 65535, S.REG_Y - source['sh3y'] & 65535)
                if (visible['s3x'], visible['s3y']) != expected:
                    raise ValueError('video does not follow native scroll shadow')
                if (source['sh3x'], source['sh3y']) != (source['camx'], source['camy']):
                    if source['gtask'] != 8 or not any((0 <= source['frame'] - f <= S.MAP_LOAD for f in maps)):
                        raise ValueError('camera/shadow split outside an allowed map-loading frame')
                    split.append(dict(source_frame=source['frame'], visible_frame=visible['frame']))
        if split:
            if smooth['layer_frames_off'] != len(split):
                raise ValueError('unexplained camera/register mismatch')
            smooth['passed'] = not (smooth['camera_x_reversals'] or smooth['camera_y_reversals'] or smooth['floor_against_slope'] or smooth['lag_elsewhere'])
        smooth['map_load_camera_shadow_split_frames'] = split
        smooth['native_scroll_shadow_register_mismatches'] = 0
        if not smooth['passed']:
            raise ValueError(name + ': camera, direction, layer or board timing failed')
        if stock:
            differences = [x['frame'] for x, y in zip(before, after) if any((x[k] != y[k] for k in x if k not in ignored))]
            sprites = lambda root: [r['sprites'] for r in csv.DictReader((root / 'motion.tsv').open(), delimiter='\t')]
            if differences or sprites(control) != sprites(out):
                raise ValueError(name + ': stock motion or sprite list changed')
            smooth['stock_motion_and_sprites_exact'] = True
        else:
            drawing = list(csv.DictReader((out / 'cadence.tsv').open(), delimiter='\t'))
            if sha((out / 'cadence.tsv').read_bytes()) != new['results'][name]['cadence_sha256'] or not drawing:
                raise ValueError('drawing trace missing or changed')
            edits = 0
            last = None
            parse = lambda s: [(int(x), int(y), int(code, 16), int(attr, 16)) for x, y, code, attr in (e.split(',') for e in s.split(';'))]
            for r in drawing:
                for k in ('frame', 'start_frame', 'latched_buffer', 'buffer', 'dy', 'edits', 'x', 'xf', 'y', 'kind', 'count'):
                    r[k] = int(r[k])
                if r['object_before'] != r['object_after']:
                    raise ValueError('drawing helper mutated live player state')
                if abs(r['dy']) > 2:
                    raise ValueError('drawing correction exceeded two pixels')
                if last and (r['count'] != last['count'] + 1 or r['buffer'] == last['buffer']):
                    raise ValueError('a sprite buffer was processed twice')
                last = r
                src, dst = (parse(r['before']), parse(r['after']))
                if len(src) != len(dst):
                    raise ValueError('sprite count changed')
                eligible = sum((attr & 31 == 14 and code < 8192 and bool(bits[code // 8] >> code % 8 & 1) for x, y, code, attr in src))
                changed = 0
                for oldent, newent in zip(src, dst):
                    if oldent == newent:
                        continue
                    x, y, code, attr = oldent
                    if attr & 31 != 14 or code >= 8192 or (not bits[code // 8] >> code % 8 & 1):
                        raise ValueError('a non-Hiryu sprite changed')
                    if newent != (x, y - r['dy'] & 65535, code, attr):
                        raise ValueError('sprite change is not the measured Y translation')
                    changed += 1
                if changed != r['edits']:
                    raise ValueError('sprite edit count disagrees')
                if r['dy'] and bytes.fromhex(r['object_before'])[1] and (changed != eligible):
                    raise ValueError('the visible native body was not translated as one complete pose')
                if changed and (r['frame'] != r['start_frame'] or r['buffer'] == r['latched_buffer']):
                    raise ValueError('sprite edits missed the hardware copy deadline')
                edits += changed
            smooth['drawing_frames'] = len(drawing)
            smooth['translated_body_entries'] = edits
            smooth['live_player_never_mutated'] = True
            smooth['sprite_copy_deadlines_passed'] = True
            map_at = D.maps_from(dz)
            warps = D.warp_frames(out)
            bad = []
            count = 0
            for segment in S.segments(frames, after, warps, 5):
                for r in segment:
                    if r['st'] or r['kind'] not in range(2, 8):
                        continue
                    floor = floors[map_at(r['frame'])]
                    near = floor.near(r['hx'], r['hy'] - 32)
                    count += 1
                    if near is None or abs(near[0] - (r['hy'] - 32)) > 2:
                        bad.append(r['frame'])
            if bad:
                raise ValueError(name + ': foot left the unchanged slope by more than two pixels')
            smooth['grounded_slope_samples'] = count
            ranges = {'s0': [(3340, 3400, 0, 3000)], 's2_turn': [(4800, 4900, 0, 1700), (5050, 5150, 0, 1700), (4800, 4900, 1700, 3000)]}
            for lo, hi, f0, f1 in ranges.get(name, []):

                def metric(rows):
                    r = [x for x in rows if lo < x['hx'] < hi and f0 < x['frame'] < f1 and (x['st'] == 0)]
                    if len(r) < 10:
                        raise ValueError('cadence span was not traversed')
                    dy = np.diff([x['hy'] for x in r])
                    return dict(frames=len(r), vertical_steps=dict(Counter(map(str, dy.tolist()))), step_change_mean_square=float(np.mean(np.diff(dy) ** 2)))
                displayed = [dict(frame=r['frame'], hx=r['x'], hy=r['y'], st=int.from_bytes(bytes.fromhex(r['object_before'])[3:4], 'big')) for r in drawing]
                x, y = (metric(before), metric(displayed))
                if y['step_change_mean_square'] >= x['step_change_mean_square']:
                    raise ValueError('slope cadence did not improve')
                cadence.append(dict(case=name, x_range=[lo, hi], frame_range=[f0, f1], control=x, candidate=y, reduction=1 - y['step_change_mean_square'] / x['step_change_mean_square']))
        smooth.update(case=name, passed=True)
        results.append(smooth)
    report = dict(schema='striderex-native-slope-cadence/1', passed=True, machine=a.machine, input_files=new['input_files'], control_files=old['input_files'], runtime=new['runtime'], results=results, cadence=cadence, native_speed_pose_and_collision_tables_unmodified=True, hardware_review_granted=False)
    a.receipt.write_text(json.dumps(report, indent=2) + '\n')
    print('PASS cadence:', a.machine, len(results), 'walks;', [(c['case'], round(100 * c['reduction'], 1)) for c in cadence])
if __name__ == '__main__':
    main()
