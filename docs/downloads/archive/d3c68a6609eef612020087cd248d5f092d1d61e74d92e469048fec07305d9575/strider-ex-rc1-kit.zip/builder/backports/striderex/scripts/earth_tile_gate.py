"""Qualify the ending-only Earth composite against a verified Kit u build."""
import argparse
from concurrent.futures import ThreadPoolExecutor
from copy import deepcopy
import json
from pathlib import Path
import subprocess
import sys
from types import SimpleNamespace
import numpy as np
from PIL import Image, ImageDraw
import earth_tile as ET
import earth_gate as EG
import earth_render_probe as ER
import mapper_testkit as K
import respawn_fix as RF
import title_ex as T
ROOT = Path(__file__).resolve().parents[3]
J = EG.J
NAMES = {'striderus01': 'striderua', 'striderjs01': 'striderjr'}
FRAME = 1300
CELL = 54876

def inventory(path):
    meta = json.loads((path / 'build.json').read_text())
    members = {}
    if set(meta['sets']) != set(RF.SETS):
        raise ValueError('both regional builds required')
    for machine, spec in meta['sets'].items():
        files = {n: (path / machine / n).read_bytes() for n in spec['files']}
        if any((ET.sha(data) != spec['files'][n] for n, data in files.items())):
            raise ValueError('input member changed')
        members[machine] = files
    return (meta, members)

def exact_candidate(old, new, stock):
    for machine, files in old.items():
        wanted = dict(files)
        image = RF.compose(files, RF.SETS[machine])
        ET.patch_image(image, machine)
        wanted.update(RF.decompose(image, RF.SETS[machine], {n: len(files[n]) for n, _, _ in RF.SETS[machine]}))
        region = ET.join_graphics(files)
        ET.install(region, stock)
        wanted.update(zip(ET.GFX_FILES, ET.G.split_region(region)))
        if wanted != new[machine]:
            raise ValueError('candidate differs outside exact Earth composite')

def cell_xy(regs):
    index = (CELL - 49152) // 4
    col = index >> 4 & 63
    row = index & 15 | index >> 6 & 48
    return ((16 * col - 64 - regs[8388880]) % 1024, (16 * row - 16 - regs[8388882]) % 1024)

def expected_frame(before, vram, regs, tile, rgb):
    after = before.copy()
    x, y = cell_xy(regs)
    if (x, y) != (242, 203):
        raise ValueError('unexpected reference Earth position')
    for ty in range(8, 16):
        for tx in range(16):
            pen = int(tile[ty, tx])
            word = int.from_bytes(vram[84352 + 2 * pen:84354 + 2 * pen], 'big')
            after[y + ty, x + tx] = rgb(word)
    return after

def runtime(a):
    work = a.workdir.resolve()
    work.mkdir(parents=True, exist_ok=False)
    paths = dict(control=a.control.resolve(), build=a.build.resolve())
    inventories = {k: inventory(v) for k, v in paths.items()}
    stock = T.stock_gfx(K.pool([a.rom_dir / 'striderua', a.rom_dir / 'strider']))
    tile = ET.repaired_tile(stock)
    exact_candidate(inventories['control'][1], inventories['build'][1], stock)
    studies = {}
    for label, path in paths.items():
        meta, members = inventories[label]
        meta = deepcopy(meta)
        source = work / (label + '_source')
        source.mkdir()
        for machine, files in members.items():
            meta['sets'][machine]['stage_select_syms'] = EG.stage_symbols(files, machine)
            (source / machine).symlink_to(path / machine, target_is_directory=True)
        (source / 'build.json').write_text(json.dumps(meta, indent=2) + '\n')
        studies[label] = work / (label + '_study')
        J.cmd_study(SimpleNamespace(build=source, rom_dir=a.rom_dir, out=studies[label], start_stage=None, stage_select_tour=False, stage_select_pick=6))
    rt = json.loads((a.runtime / 'runtime.json').read_text())
    if ET.sha(Path(rt['binary']).read_bytes()) != rt['binary_sha256']:
        raise ValueError('runtime changed')
    jobs = [(label, name, flag) for label in paths for name in NAMES for flag in (0, 1)]

    def one(key):
        label, name, flag = key
        out = work / f'{label}_{name}_{flag}'
        cmd = [sys.executable, str(ROOT / 'backports/striderex/rtl/jtcps1_sim.py'), 'hbref', '--build', str(studies[label]), '--runtime', str(a.runtime), '--hbmame', str(a.hbmame), '--rom-dir', str(a.rom_dir), '--out', str(out), '--set', name, '--flag', str(flag), '--frames', '1500', '--shots', '1140-1470/30,1300', '--memdump', '1300']
        with (work / (out.name + '.log')).open('w') as f:
            result = subprocess.run(cmd, stdout=f, stderr=subprocess.STDOUT)
        if result.returncode:
            raise ValueError('capture failed: ' + out.name)
        print('captured', out.name, flush=True)
        return (key, out)
    with ThreadPoolExecutor(a.jobs) as pool:
        runs = dict(pool.map(one, jobs))
    results = []
    for name, machine in NAMES.items():
        for flag in (0, 1):
            old, new = [runs[label, name, flag] for label in paths]
            before, after = [(p / 'vram_01300.bin').read_bytes() for p in (old, new)]
            diff = {i for i, (x, y) in enumerate(zip(before, after)) if x != y}
            pictures = []
            for frame in sorted(set(range(1140, 1471, 30)) | {1300}):
                x, y = [np.array(Image.open(p / f'f_{frame:05d}.png').convert('RGB')) for p in (old, new)]
                changed = np.any(x != y, axis=2)
                cx, cy = cell_xy(ER.registers(old, frame))
                allowed = np.zeros(changed.shape, dtype=bool)
                if 0 <= cx <= 368 and 0 <= cy <= 208:
                    allowed[cy + 8:cy + 16, cx:cx + 16] = True
                pictures.append(dict(frame=frame, changed_pixels=int(changed.sum()), only_lower_half_changed=not bool(np.any(changed & ~allowed))))
            x, y = [np.array(Image.open(p / 'f_01300.png').convert('RGB')) for p in (old, new)]
            expected = expected_frame(x, after, ER.registers(new, FRAME), tile, T.mame_rgb)
            checks = dict(frame_flow_identical=(old / 'frames.tsv').read_bytes() == (new / 'frames.tsv').read_bytes(), registers_and_sound_identical=(old / 'regs.tsv').read_bytes() == (new / 'regs.tsv').read_bytes(), only_one_vram_map_word_changed=diff == {CELL, CELL + 1}, correct_map_reference=before[CELL:CELL + 4] == bytes.fromhex('34c3000c') and after[CELL:CELL + 4] == bytes.fromhex('83d7000c'), only_lower_half_pixels_changed=all((p['only_lower_half_changed'] for p in pictures)), exact_reference_pixels=np.array_equal(y, expected), old_gap_rejected=not np.array_equal(x, expected))
            results.append(dict(set=name, machine=machine, flag=flag, checks=checks, pictures=pictures, control_vram_sha256=ET.sha(before), build_vram_sha256=ET.sha(after), passed=all(checks.values())))
    report = dict(schema='striderex-earth-tile-runtime/1', passed=all((r['passed'] for r in results)), control_files={m: s['files'] for m, s in inventories['control'][0]['sets'].items()}, build_files={m: s['files'] for m, s in inventories['build'][0]['sets'].items()}, runtime={k: rt[k] for k in ('binary_sha256', 'board_wait', 'source_revision')}, results=results)
    (work / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
    for row in results:
        print('PASS' if row['passed'] else 'FAIL', row['set'], row['flag'], row['checks'])
    if not report['passed']:
        raise ValueError('Earth tile runtime gate failed')

def render(a):
    tile = ET.repaired_tile(T.stock_gfx(K.pool([a.rom_dir / 'striderua', a.rom_dir / 'strider'])))
    runtime_report = json.loads(a.runtime_report.read_text())
    if not runtime_report['passed']:
        raise ValueError('runtime gate failed')
    rows = []
    for old, new, capture in zip(a.control, a.build, a.capture):
        receipts = [json.loads((p / 'render.json').read_text()) for p in (old, new)]
        machine = receipts[0]['machine']
        if receipts[1]['machine'] != machine:
            raise ValueError('regional render pair differs')
        runtime_row = next((r for r in runtime_report['results'] if r['machine'] == machine and r['flag'] == 0))
        for label, receipt in zip(('control', 'build'), receipts):
            if not receipt['passed'] or receipt['build_files'] != runtime_report[label + '_files'] or receipt['vram_sha256'] != runtime_row[label + '_vram_sha256']:
                raise ValueError('render inputs differ from runtime proof')
        if any((receipts[0][k] != receipts[1][k] for k in ('registers_sha256', 'model_sha256', 'harness_sha256'))):
            raise ValueError('render model or registers differ')
        images = [Image.open(p / 'render/f_00035.png').convert('RGB') for p in (old, new)]
        for p, receipt in zip((old, new), receipts):
            if ET.sha((p / 'render/f_00035.png').read_bytes()) != receipt['image_sha256']:
                raise ValueError('render image changed')
        lut = np.loadtxt(new / 'render/pal_lut.hex', dtype=str)
        lut = np.array([int(v, 16) for v in lut.flat]).reshape(16, 16)

        def rgb(word):
            return tuple((int(lut[word >> 12, word >> s & 15]) for s in (8, 4, 0)))
        before, after = map(np.array, images)
        expected = expected_frame(before, (capture / 'vram_01300.bin').read_bytes(), ER.registers(capture, FRAME), tile, rgb)
        count = int(np.any(before != after, axis=2).sum())
        passed = np.array_equal(after, expected) and count > 0 and (not np.array_equal(before, expected))
        rows.append(dict(machine=machine, control=receipts[0], build=receipts[1], changed_pixels=count, exact_reference_pixels=bool(np.array_equal(after, expected)), old_gap_rejected=not bool(np.array_equal(before, expected)), passed=bool(passed)))
        if a.review and machine == 'striderua':
            a.review.mkdir(parents=True, exist_ok=True)
            for label, im in zip(('before', 'after'), images):
                im.save(a.review / f'earth-tile-{label}.png')
            canvas = Image.new('RGB', (1024, 288), (24, 24, 24))
            draw = ImageDraw.Draw(canvas)
            for i, (label, im) in enumerate(zip(('Before: transparent lower half', 'After: continuous shadow edge'), images)):
                draw.text((i * 512 + 12, 8), label, fill='white')
                canvas.paste(im.crop((210, 187, 274, 219)).resize((512, 256), Image.Resampling.NEAREST), (i * 512, 32))
            canvas.save(a.review / 'earth-tile-before-after.png')
    report = dict(schema='striderex-earth-tile-render/1', passed={r['machine'] for r in rows} == set(RF.SETS) and all((r['passed'] for r in rows)), results=rows)
    a.receipt.write_text(json.dumps(report, indent=2) + '\n')
    if not report['passed']:
        raise ValueError('Earth tile core rendering failed')
    print('PASS: exact reconstructed lower-half pixels in both regional core renders')

def main():
    p = argparse.ArgumentParser(description=__doc__)
    sub = p.add_subparsers(dest='cmd', required=True)
    r = sub.add_parser('runtime')
    for name in ('build', 'control', 'rom-dir', 'runtime', 'hbmame', 'workdir'):
        r.add_argument('--' + name, type=Path, required=True)
    r.add_argument('--jobs', type=int, default=3)
    c = sub.add_parser('render')
    for name in ('control', 'build', 'capture'):
        c.add_argument('--' + name, type=Path, action='append', required=True)
    for name in ('rom-dir', 'runtime-report', 'receipt'):
        c.add_argument('--' + name, type=Path, required=True)
    c.add_argument('--review', type=Path)
    a = p.parse_args()
    a.rom_dir = a.rom_dir.resolve()
    if a.cmd == 'runtime':
        a.runtime = a.runtime.resolve()
        runtime(a)
    else:
        if any((len(v) != 2 for v in (a.control, a.build, a.capture))):
            raise ValueError('both regions required')
        render(a)
if __name__ == '__main__':
    main()
