-- Native Grandmaster text and post-initials flow checks. Debug start only;
-- the name is entered through player buttons, and Meio is defeated normally.
dofile(assert(os.getenv('STREX_DEBUG_START')))
local m=manager.machine
local sp=m.devices[':maincpu'].spaces['program']
local screen=m.screens[':screen']
local root=assert(os.getenv('OUT'))
local kind=assert(os.getenv('CASE'))
local unranked=os.getenv('UNRANKED')=='1'
local held_start=os.getenv('HELD_START')=='1'
local f,ranking,complete,exit,ended,text,lastrow=0,nil,nil,nil,nil,nil,''
local text_x=-1
local log=assert(io.open(root..'/events.tsv','w'))
local function event(k,v) log:write(string.format('%d\t%s\t%s\n',f,k,tostring(v)));log:flush() end
local fields={}
for _,port in pairs(m.ioport.ports) do for _,field in pairs(port.fields) do
 fields[m.ioport:input_type_to_token(field.type,field.player)]=field
end end
local function press(k,on) if on then fields[k]:set_value(1) else fields[k]:clear_value() end end
local function bytes(at,n)
 local t={};for a=at,at+n-1 do t[#t+1]=string.format('%02x',sp:read_u8(a)) end;return table.concat(t)
end
local function ranktable()
 local t={}
 for i=0,9 do t[#t+1]=bytes(sp:read_u32(0xff89aa+4*i),8) end
 return table.concat(t)
end
_G.af_sound=sp:install_write_tap(0x800180,0x800181,'af_sound',function(off,data,mask)
 local v=data&255
 if v==0x20 or v==0x21 or v==0x0e or v==0x22 then event('sound',string.format('%02x',v)) end
 if v==0x22 and not ranking then ranking=f;event('rank-start',ranktable()) end
end)
if kind=='text' then
 _G.af_text_x=sp:install_write_tap(0x80010c,0x80010d,'af_text_x',function(a,d,mask) text_x=d&0xffff end)
 _G.af_text=sp:install_read_tap(0xeb82,0xeb9b,'af_text',function(a,d,mask)
  if not text then text=f;event('text-read',string.format('%06x',a)) end
 end)
end
emu.register_frame_done(function()
 f=f+1
 if unranked and f==450 then sp:write_u8(0xfff924,1);event('research','stage-select no-ranking flag') end
 if kind=='text' then
  if f==600 then m.devices[':maincpu'].state['PC'].value=0x1ff700;event('research','native text drawer replay') end
  if text and f==text+12 then
   local t={}
   for i=0,25 do t[#t+1]=string.format('%04x:%04x',sp:read_u16(0x90a234+128*i),sp:read_u16(0x90a236+128*i)) end
   event('native-text-row',table.concat(t,','))
   event('native-text-palette',bytes(0x9147c0,32))
   event('native-text-scroll-x',string.format('%04x',text_x))
   screen:snapshot(root..'/text.png')
  end
  if text and f>=text+100 then event('done','text');m:exit() end
 else
  local phase,sub=sp:read_u8(0xff0cdd),sp:read_u8(0xff0cde)
  local row=string.format('%d,%d,%d,%d',phase,sub,sp:read_u8(0xff0c84),sp:read_u8(0xff8a22))
  if ranking and row~=lastrow then event('state',row);lastrow=row end
  local age=ranking and f-ranking or -999
  local key=ranking and phase==4 and sub==2 and (age-100)%24<3 and age>=100
  if ranking then
   press('P1_JOYSTICK_UP',phase==4 and sub==2 and age>=20 and age<44)
   press('P1_JOYSTICK_LEFT',phase==4 and sub==2 and age>=44 and age<68)
   press('P1_BUTTON1',key)
  end
  if ranking and not complete and phase==4 and sub==4 then
   complete=f;event('confirmed',bytes(0x90add0,2));screen:snapshot(root..'/confirmed.png')
  end
  if complete and not exit and phase==6 then
   exit=f;event('initials-exit',bytes(0xff0cd8,4));event('rank-end',ranktable())
  end
  if complete and f==complete+300 then screen:snapshot(root..'/held.png') end
  if exit and not ended and sp:read_u8(0xff0c84)==0 then ended=f;event('game-ended','0') end
  if held_start and complete then
   local holding=f>=complete+60 and (not ended or f<=ended+240)
   press('START1',holding)
   -- Add the test credit before holding Start, so the held press crosses
   -- the title transition with a usable credit already in the machine.
   press('COIN1',f>=complete+20 and f<=complete+27)
   if f==complete+60 then event('start-held','1') end
   if ended and f==ended+241 then event('start-released','0') end
  end
  if ended then
   if f==ended+200 then screen:snapshot(root..'/title.png') end
   if f<ended+800 and sp:read_u8(0xff0c84)~=0 then event('unexpected-start','1') end
   -- The ordinary case adds a coin here. The held-Start case must use its
   -- earlier credit; accepting the final fresh press proves it was available.
   if not held_start then press('COIN1',f>=ended+700 and f<=ended+707) end
   if not held_start or f>ended+240 then press('START1',f>=ended+800 and f<=ended+807) end
   if f==ended+800 then event('fresh-start','1') end
   if f>=ended+800 and sp:read_u8(0xff0c84)~=0 then event('fresh-game','1');m:exit() end
   if f>=ended+1000 then event('done','no fresh game');m:exit() end
  end
 end
end)
