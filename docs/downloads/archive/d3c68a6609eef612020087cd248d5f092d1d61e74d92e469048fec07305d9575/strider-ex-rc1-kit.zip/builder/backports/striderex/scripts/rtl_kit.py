"""Focused jtcps1 kit transition qualification with a matching prepared model."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
ROOT = Path(__file__).resolve().parents[3]
RTL = ROOT / 'backports/striderex/rtl'

def sha(path):
    with path.open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()

def main():
    p = argparse.ArgumentParser(description=__doc__)
    for name in ('build', 'rom-dir', 'model', 'workdir'):
        p.add_argument('--' + name, type=Path, required=True)
    p.add_argument('--jobs', type=int, default=2)
    a = p.parse_args()
    a.workdir = a.workdir.resolve()
    a.workdir.mkdir(parents=True, exist_ok=False)
    model = a.model.resolve()
    v = model / 'cores/cps1/ver/strex'
    if not (v / 'obj_dir/sim').is_file():
        p.error('--model must be the prepared jtcores tree, not its workdir')
    if sha(v / 'test.cpp') != sha(RTL / 'jtcps1_sim/test.cpp'):
        p.error('the prepared model uses a different harness')
    bj = json.loads((a.build / 'build.json').read_text())
    if not bj.get('test_ending'):
        p.error('the TEST build with ENDING is required')
    files = {m: s['files'] for m, s in bj['sets'].items()}
    for machine, members in files.items():
        for name, expected in members.items():
            if sha(a.build / machine / name) != expected:
                p.error('build member changed: ' + name)
    report = dict(build_files=files, model_sha256=sha(v / 'obj_dir/sim'), harness_sha256=sha(v / 'test.cpp'), seed_frame=390, last_frame=600, results=[], passed=False)

    def run(name, cmd, env=None):
        with (a.workdir / (name + '.log')).open('w') as log:
            r = subprocess.run([str(x) for x in cmd], stdout=log, stderr=subprocess.STDOUT, env=dict(os.environ, **env or {}))
        if r.returncode:
            raise RuntimeError(f'{name} failed ({r.returncode}); see its log')
    spaces = {}
    for k in (0, 1, 2, 6):
        study, w = (a.workdir / f'study{k}', a.workdir / f'workspace{k}')
        run(f'study{k}', [sys.executable, RTL / 'jtcps1_sim.py', 'study', '--build', a.build, '--rom-dir', a.rom_dir, '--stage-select-pick', k, '--out', study])
        w.mkdir()
        (w / 'jtcores').symlink_to(model)
        run(f'rom{k}', ['bash', RTL / 'run_jtcps1_sim.sh', 'rom', w, '--build', study, '--rom-dir', a.rom_dir])
        spaces[k] = w
    base = (spaces[0] / 'sdram/sdram_bank0.bin').read_bytes()
    immediate = bj['sets']['striderua']['stage_select_syms']['ss_buttons'] + 8
    patches = {}
    for k, w in spaces.items():
        candidate = (w / 'sdram/sdram_bank0.bin').read_bytes()
        differences = [i for i, (x, y) in enumerate(zip(base, candidate)) if x != y]
        if any((i not in (immediate, immediate + 1) for i in differences)):
            raise ValueError('Study differs outside the pick-index immediate')
        if int.from_bytes(candidate[immediate:immediate + 2], 'big') != k:
            raise ValueError('Study pick-index immediate differs')
        for bank in (1, 2, 3):
            if sha(w / f'sdram/sdram_bank{bank}.bin') != sha(spaces[0] / f'sdram/sdram_bank{bank}.bin'):
                raise ValueError('Study differs in a non-program bank')
        patches[k] = f'0:{immediate:x}:{k:04x}'
    seed = a.workdir / 'seed'
    print('START RTL boot to frame 390', flush=True)
    run('seed', ['bash', RTL / 'run_jtcps1_sim.sh', 'run', spaces[0], seed], dict(STREX_COIN='200', STREX_START='400', STREX_FRAMES='390', STREX_SAVE='390'))
    state = seed / 'state_00390.bin'
    if not state.is_file():
        raise ValueError('Seed did not finish and save frame 390')
    report['seed_sha256'] = sha(state)
    print('PASS RTL boot; starting four picks', flush=True)

    def one(k):
        r = a.workdir / f'pick{k}'
        print('START RTL pick', k, flush=True)
        run(f'run{k}', ['bash', RTL / 'run_jtcps1_sim.sh', 'run', spaces[k], r], dict(STREX_COIN='200', STREX_START='400', STREX_FRAMES='600', STREX_SHOTS='390-600/1', STREX_MEMDUMP='400-600/20', STREX_RESTORE=str(state), STREX_PATCH=patches[k]))
        run(f'black{k}', [sys.executable, RTL / 'jtcps1_sim.py', 'pickblack', '--run', r, '--json', a.workdir / f'pick{k}.json'])
        check = json.loads((a.workdir / f'pick{k}.json').read_text())
        last = check['next_scene'] + 11 if check['next_scene'] is not None else check['first_picture_after'][0]
        expected = set(range(check['first_black_shot'], last + 1))
        present = {int(q.stem[2:]) for q in r.glob('f_*.png')}
        if expected - present:
            raise ValueError('Transition captures are incomplete')
        if 'done at frame 601' not in (r / 'sim.log').read_text():
            raise ValueError('Simulation did not finish')
        print('PASS RTL pick', k, 'black frames', check['shots_checked'], flush=True)
        return dict(pick=k, black=check, consecutive_captures=True, exit_code=0, study_rom_sha256=sha(spaces[k] / 'sdram/rom.bin'), patch=patches[k], passed=True)
    with ThreadPoolExecutor(a.jobs) as pool:
        report['results'] = list(pool.map(one, (0, 1, 2, 6)))
    report['passed'] = all((r['passed'] for r in report['results']))
    (a.workdir / 'rtl.json').write_text(json.dumps(report, indent=2) + '\n')
    print('PASS RTL transition qualification', flush=True)
if __name__ == '__main__':
    main()
