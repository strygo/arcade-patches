"""Finalize the qualified native gameplay/Moon follow-up for private MiSTer use."""
import argparse
from copy import deepcopy
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys
import xml.etree.ElementTree as ET
import zipfile
import zlib
from boss_voice_gate import inventory, sha
import stage_clear as CLEAR
import desert_motion_fix as CAMERA
import desert_transition_fix as TRANSITION
import desert_pole_floor as POLE
import desert_climb_fix as CLIMB
import moon_start as MOON
import verify_gameplay_kit as PORTABLE
import build_gameplay_followup as BUILD
ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / 'release'))
import private_mister as PM
import mra_assembly

def qualification(a, meta):
    root = a.gameplay_root
    CLEAR.audit(root / 'base', root / 'stage_clear')
    CAMERA.audit(root / 'stage_clear', root / 'camera')
    TRANSITION.audit(root / 'camera', root / 'transition')
    POLE.audit(root / 'transition', root / 'pole_floor', a.rom_dir)
    CLIMB.audit(root / 'pole_floor', root / 'final')
    MOON.audit(root / 'final', a.build)
    folder = Path(__file__).resolve().parents[1] / 'manifests/qualification'
    names = dict(gameplay_runtime='gameplay_followup_runtime_20261026.json', gameplay_fresh='gameplay_followup_fresh_20261026.json', moon_runtime='moon_start_runtime_20261026.json', moon_fresh='moon_start_fresh_20261026.json')
    receipts = {key: json.loads((folder / name).read_text()) for key, name in names.items()}
    for key in ('gameplay_fresh', 'moon_fresh'):
        for name, digest in receipts[key]['source_sha256'].items():
            path = folder.parents[1] / name if '/' in name else folder.parents[1] / ('asm' if name.endswith('.s') else 'lua' if name.endswith('.lua') else 'scripts') / name
            if sha(path.read_bytes()) != digest:
                raise ValueError('qualified source changed: ' + name)
    chain = {name: {m: s['files'] for m, s in inventory(root / name)[0]['sets'].items()} for name in ('base', 'stage_clear', 'camera', 'transition', 'pole_floor', 'final')}
    return dict(baseline_test_id='261026-01', baseline_manifest_sha256=BUILD.BASELINE_SHA, chain=chain, regions={m: {k: s[k] for k in ('stage_clear', 'desert_motion', 'desert_transition', 'pole_floor', 'desert_climb', 'moon_start')} for m, s in meta['sets'].items()}, qualification=receipts, art_selection=meta['art_selection'], hardware_review_granted=False)

def build(a):
    meta, members = inventory(a.build)
    proof = qualification(a, meta)
    expected = {m: s['files'] for m, s in meta['sets'].items()}
    PORTABLE.qualification(dict(build_files=expected, gameplay_followup=proof))
    baseline_receipt = PM.verify(a.baseline)
    if baseline_receipt['test_id'] != '261026-01' or sha((a.baseline / 'private-mister.json').read_bytes()) != BUILD.BASELINE_SHA:
        raise ValueError('selected native Kit aa differs')
    a.out.mkdir(parents=True, exist_ok=False)
    with PM.qualified_view(a.baseline) as source:
        baseline = json.loads((source / 'producer.json').read_text())
        if baseline['build_files'] != proof['chain']['base']:
            raise ValueError('baseline ROMs differ from qualification')
        shutil.copytree(source, a.out, dirs_exist_ok=True)
        reverse = a.out / 'gameplay-reverse.zip'
        with zipfile.ZipFile(reverse, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
            saved = {}
            for path in sorted(source.rglob('*')):
                if path.is_file() and (not path.relative_to(source).as_posix().startswith(('games/', '_Arcade/cores/'))):
                    name = path.relative_to(source).as_posix()
                    data = path.read_bytes()
                    z.writestr('files/' + name, data)
                    saved[name] = sha(data)
            for machine, files in baseline['build_files'].items():
                region = 'us' if machine == 'striderua' else 'jp'
                with zipfile.ZipFile(source / f'games/mame/striderex_{region}.zip') as old:
                    for name, digest in files.items():
                        data = old.read(name)
                        if sha(data) != digest:
                            raise ValueError('baseline member changed')
                        if data != members[machine][name]:
                            z.writestr(f'roms/{machine}/{name}', data)
            z.writestr('baseline.json', json.dumps(dict(files=saved, build_files=baseline['build_files'])))
        report = deepcopy(baseline)
        report['build_files'] = expected
        report['gameplay_followup'] = dict(proof, reverse_sha256=sha(reverse.read_bytes()))
        for machine, files in members.items():
            region = 'us' if machine == 'striderua' else 'jp'
            path = a.out / f'games/mame/striderex_{region}.zip'
            with zipfile.ZipFile(path) as z:
                allfiles = {n: z.read(n) for n in z.namelist()}
            allfiles.update(files)
            with zipfile.ZipFile(path, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
                for name, data in sorted(allfiles.items()):
                    z.writestr(name, data)
            report['archives'][path.relative_to(a.out).as_posix()] = {n: sha(b) for n, b in allfiles.items()}
        mras = {}
        for old_title, old_spec in baseline['mras'].items():
            path = a.out / '_Arcade' / (old_title + '.mra')
            root = ET.parse(path).getroot()
            title = re.sub(' \\[Kit [^\\]]+\\]$', '', old_title) + ' [' + a.label + ']'
            root.find('name').text = title
            machine = 'striderua' if '(USA)' in title else 'striderjr'
            for part in root.iter('part'):
                name = part.get('name')
                if name in members[machine]:
                    part.set('crc', f'{zlib.crc32(members[machine][name]):08x}')
            text = ET.tostring(root, encoding='unicode')
            new = path.with_name(title + '.mra')
            new.write_text(text)
            path.unlink()
            refs = {Path(ref).name for node in root.iter() for ref in node.get('zip', '').split('|') if ref}
            paths = [a.out / p for p in report['archives'] if Path(p).name in refs]
            image = mra_assembly.assemble(text, mra_assembly.ZipSource(paths))
            mras[title] = dict(old_spec, assembled_sha256=sha(image))
        report['mras'] = mras
        (a.out / 'producer.json').write_text(json.dumps(report, indent=2) + '\n')
    (a.out / 'README.txt').write_text('STRIDER EX PRIVATE MISTER TEST\n\n' + a.label + '\n\nNative pixels for cutscenes and boss portraits; existing CPS+ pack and voices.\nStage-clear cleanup, whole-picture fades and STAGE 1-6 headings.\nDesert: hold Up to travel around a flat ledge end and climb onto it.\nGentler dune scrolling, repaired later-pole landings and post-boss map seam.\nThird Moon: camera settles before the opening fade, with title/READY/music timing preserved.\n\nUse Arcade -> Test. Choose the USA entry for English voices or the USA no-pack diagnostic.\n66 focused regional checks pass. MiSTer hardware review is pending.\n')
    shutil.copy2(Path(__file__).with_name('verify_gameplay_kit.py'), a.out / 'verify_kit.py')
    subprocess.run([sys.executable, '-B', str(a.out / 'verify_kit.py'), '--root', str(a.out)], check=True)
    record = PM.finalize(a.out, 'strider-ex', ledger=ROOT / 'release/private_mister_builds.json')
    isolated = 'import sys,runpy; root=sys.argv[1]; sys.path.insert(0,root); sys.argv=[root+"/verify_kit.py","--root",root]; runpy.run_path(root+"/verify_kit.py",run_name="__main__")'
    subprocess.run([sys.executable, '-I', '-B', '-c', isolated, str(a.out)], check=True)
    print('Finalized', a.label, record['test_id'], a.out)

def main():
    if sys.argv[1:] == ['--self-test']:
        return PORTABLE.self_test()
    p = argparse.ArgumentParser(description=__doc__)
    for n in ('gameplay-root', 'build', 'baseline', 'rom-dir', 'out'):
        p.add_argument('--' + n, type=Path, required=True)
    p.add_argument('--label', default='Kit ac - Native fixes')
    a = p.parse_args()
    for n in ('gameplay_root', 'build', 'baseline', 'rom_dir', 'out'):
        setattr(a, n, getattr(a, n).resolve())
    build(a)
if __name__ == '__main__':
    main()
