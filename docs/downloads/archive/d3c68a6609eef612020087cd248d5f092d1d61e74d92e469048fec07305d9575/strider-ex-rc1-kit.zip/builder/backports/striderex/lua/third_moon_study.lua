-- Ending-specific observation and optional presentation research control.
-- Loaded only by stage_clear_study.lua's explicit --third-moon option.
local m=manager.machine
local cpu=m.devices[':maincpu']
local sp=cpu.spaces['program']
local out=assert(os.getenv('OUT'))
local experiment=os.getenv('MOON_EXPERIMENT')=='1'
local frame,clear_start,clear_entry,bonus,roll,standing=0,nil,nil,nil,nil,nil
local colors,stars,bonus_colors=nil,nil,nil
local palette_shadow,cosmetic,restored=nil,false,false
local log=assert(io.open(out..'/moon.tsv','w'))
log:write('frame\tclear_entry\tbonus\troll\ttimer\tphase\tplayer_record\tsystem_objects\n')
local events=assert(io.open(out..'/moon_events.tsv','w'))
local function event(k,v) events:write(string.format('%d\t%s\t%s\n',frame,k,tostring(v)));events:flush() end
local function clear_return()
 for _,a in ipairs({0xc186,0xbf2e}) do
  if sp:read_u32(a)==0x4eb80b3a then return a+4 end
  if sp:read_u32(a)==0x4e714e71 and sp:read_u16(a+4)==0x4eb9 and sp:read_u32(a+6)==0x1f0000 then
   return a+4,true
  end
 end
 error('unrecognized Third Moon clear entry')
end
local return_address,native=clear_return()
local taps={}
if native then
 assert(not experiment,'native clear and drawing experiment cannot be combined')
 taps[#taps+1]=sp:install_write_tap(0xffcf00,0xffcf01,'moon_native_clear',function(a,d,mask)
  if clear_start and not clear_entry and d==1 and frame-clear_start>=350 then
   clear_entry=frame;event('clear-entry',return_address-4)
  end
 end)
end
taps[#taps+1]=sp:install_write_tap(0x914000,0x9157ff,'moon_palette_inheritance',function(a,d,mask)
 if palette_shadow and not cosmetic then
  local i=(a-0x914000)//2
  palette_shadow[i]=(palette_shadow[i]&(~mask&0xffff))|(d&mask)
 end
end)
taps[#taps+1]=sp:install_write_tap(0x900000,0x9047ff,'moon_initial_clear',function(a,d,mask)
 local pc=cpu.state['CURPC'].value
 if pc==0xb52 or pc==0xb54 then
  if clear_start and frame-clear_start>=350 and frame-clear_start<400 then
   if not clear_entry then clear_entry=frame;event('clear-entry',return_address-4) end
   if experiment then return sp:read_u16(a) end
  end
 end
end)
-- Mode 6 remains set through the credits. Detect their explicit blackout
-- instead of using the regular-stage mode-2 test.
taps[#taps+1]=sp:install_write_tap(0xff0c74,0xff0c75,'moon_roll',function(a,d,mask)
 local pc=cpu.state['CURPC'].value
 if clear_entry and not roll and d==0 and (pc==0xc46c or pc==0xc214 or (native and pc>=0x1f0000 and pc<0x1f1000)) then
  roll=frame;event('roll-black',pc)
 end
end)
_G.third_moon_taps=taps
return {frame=function(f,clear,mode,regs)
 frame=f
 clear_start=clear
 if mode==4 and not standing and sp:read_u8(0xff10ca)==1 and sp:read_u8(0xff10cb)==1
    and sp:read_u8(0xff10cd)==0 and sp:read_u16(0xff10dc)~=0 then standing=sp:read_u16(0xff10dc) end
 if clear_entry and not bonus and sp:read_u16(0xff10d2)==80 and sp:read_u16(0xff10d6)==128 then
  bonus=f;event('bonus-position',standing or 0)
  if experiment then
   assert(standing,'no standing record observed')
   sp:write_u16(0xff10dc,standing)
   for i=0,4 do sp:write_u8(0xff112a+0x50*i+1,0) end
  end
 end
 if experiment and clear_entry and not roll then
  if not colors then
   colors={};stars={}
   palette_shadow={}
   for i=0,3071 do palette_shadow[i]=sp:read_u16(0x914000+2*i) end
   for i=0,511 do colors[i]=sp:read_u16(0x914000+2*i) end
   for i=0,1023 do stars[i]=sp:read_u16(0x915000+2*i) end
  end
  local level=not bonus and sp:read_u16(0x914422)>>12 or math.min(15,math.max(0,f-bonus-3))
  cosmetic=true
  for i=0,511 do sp:write_u16(0x914000+2*i,level==0 and 0 or ((colors[i]&0xfff)|(level<<12))) end
  for i=0,1023 do sp:write_u16(0x915000+2*i,(level==0 or bonus) and 0 or ((stars[i]&0xfff)|(level<<12))) end
  if bonus and f-bonus==25 then
   bonus_colors={}
   for i=0,1023 do bonus_colors[i]=sp:read_u16(0x914000+2*i) end
  end
  local timer=sp:read_u16(0xff0c1a)
  if bonus_colors and timer<=24 then
   local fade=math.max(0,math.min(15,math.floor((timer-2)*15/22)))
   for i=0,1023 do sp:write_u16(0x914000+2*i,fade==0 and 0 or ((bonus_colors[i]&0xfff)|(fade<<12))) end
  end
  cosmetic=false
 end
 if experiment and roll and not restored and regs[0x800166]==0 then
  -- Credits inherit font colours. Preserve native writes made during the
  -- blackout setup, and undo only the callback's palette mask while hidden.
  cosmetic=true
  for i=0,3071 do sp:write_u16(0x914000+2*i,palette_shadow[i]) end
  cosmetic=false;restored=true
  event('palettes-restored',f)
 end
 if clear then
  local objects={}
  for i=0,19 do
   local a=0xff5eda+0x40*i
   if sp:read_u8(a)~=0 then
    objects[#objects+1]=string.format('%d:%x,%x,%x,%x,%x,%x',i,sp:read_u8(a+0x17),
       sp:read_u16(a+2),sp:read_u16(a+8),sp:read_u16(a+12),sp:read_u32(a+0x1a),sp:read_u16(a+0x32))
   end
  end
  log:write(string.format('%d\t%d\t%d\t%d\t%d\t%x\t%x\t%s\n',f,clear_entry or -1,bonus or -1,roll or -1,
   sp:read_u16(0xff0c1a),sp:read_u16(0xff0cdc),sp:read_u16(0xff10dc),table.concat(objects,';')))
  log:flush()
 end
end,capture=function(f)
 if not clear_start then return false end
 local age=f-clear_start
 return (age>=360 and age<=380) or (age>=425 and age<=470)
   or (bonus and not roll and sp:read_u16(0xff0c1a)<=30)
end}
