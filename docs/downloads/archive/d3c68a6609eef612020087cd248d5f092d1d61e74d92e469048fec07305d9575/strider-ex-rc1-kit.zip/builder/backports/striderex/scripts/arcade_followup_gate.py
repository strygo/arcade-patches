"""Qualify the approved native copyedit and the post-initials display hold."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import arcade_text_spacing as T
from boss_voice_gate import inventory
import desert_gate as G
import postgame_hold as H
import respawn_fix as R
ROOT = Path(__file__).resolve().parents[3]
LUA = ROOT / 'backports/striderex/lua/arcade_followup.lua'

def sha(b):
    return hashlib.sha256(b).hexdigest()

def held_start_check(events, confirmed, ended, fresh):
    held = [f for f, k, v in events if k == 'start-held' and v == '1']
    released = [f for f, k, v in events if k == 'start-released' and v == '0']
    if held != [confirmed + 60] or released != [ended + 241] or (not held[0] < ended < released[0] < fresh):
        raise ValueError('Start was not held across return and released before the fresh press')
    if any((k == 'unexpected-start' for f, k, v in events)):
        raise ValueError('held Start began a new game')
    return dict(held_from=held[0], released=released[0], held_after_game_end_frames=241, release_to_fresh_start_frames=fresh - released[0], credit_added_before_hold=True)

def inverse(control, build):
    cm, old = inventory(control)
    meta, new = inventory(build)
    row = json.loads(T.MANIFEST.read_text())['edits'][0]
    for m, s in meta['sets'].items():
        f = dict(new[m])
        image = R.compose(f, R.SETS[m])
        if m == row['machine']:
            at = row['text_address']
            after = T.encoded(row['after'])
            if image[at:at + len(after)] != after:
                raise ValueError('copyedit differs from approval')
            image[at:at + len(after)] = T.encoded(row['before'])
        for at in H.SITES:
            if image[at:at + 6] != b'N\xb9' + H.ENTRY.to_bytes(4, 'big'):
                raise ValueError('postgame call changed')
            image[at:at + 6] = H.OLD
        f.update(R.decompose(image, R.SETS[m], {n: len(f[n]) for n, _, _ in R.SETS[m]}))
        raw = bytearray((f['strex_p6.bin'][i ^ 1] for i in range(1048576)))
        spec = s['postgame_hold']
        off = H.ENTRY - 1048576
        n = spec['helper_bytes']
        if sha(raw[off:off + n]) != spec['helper_sha256']:
            raise ValueError('postgame helper changed')
        raw[off:off + n] = b'\xff' * n
        f['strex_p6.bin'] = bytes((raw[i ^ 1] for i in range(len(raw))))
        if f != old[m]:
            raise ValueError('changes outside approved text/hold')
    return (meta, cm)

def gate(a):
    meta, control = inverse(a.control, a.build)
    rt = json.loads((a.runtime / 'runtime.json').read_text())
    binary = Path(rt['binary'])
    if sha(binary.read_bytes()) != rt['binary_sha256']:
        raise ValueError('runtime changed')
    work = a.workdir.resolve()
    work.mkdir(parents=True, exist_ok=a.reuse)
    staged = {}
    for label, path in (('control', a.control), ('candidate', a.build)):
        for m, name in (('striderua', 'striderus01'), ('striderjr', 'striderjs01')):
            dest = work / 'sets' / (label + '_' + m)
            if not a.reuse:
                G.stage_sets(path.resolve(), name, a.hbmame, a.rom_dir.resolve(), dest)
            _, expected = inventory(path)
            hashes = {sha(p.read_bytes()) for p in (dest / name).iterdir() if p.is_file()}
            if any((sha(data) not in hashes for data in expected[m].values())):
                raise ValueError('staged ROM identities are stale')
            staged[label, m] = (dest, name)
    jobs = [('control', m, True) for m in ('striderua', 'striderjr')] + [('candidate', m, unranked) for m in ('striderua', 'striderjr') for unranked in (False, True)]
    if a.held_start_only:
        jobs = [j for j in jobs if j[0] == 'candidate']
    if a.only_text:
        jobs = []

    def run(job, kind='postgame'):
        label, m, unranked = job
        roms, name = staged[label, m]
        out = work / (kind + '_' + label + '_' + m + ('_unranked' if unranked else '_ranked'))
        if not a.reuse or not (out / 'events.tsv').exists():
            out.mkdir(parents=True, exist_ok=False)
            if kind == 'text':
                vm, ff = inventory(a.build)
                f = dict(ff['striderua'])
                bank = bytearray((f['strex_p6.bin'][k ^ 1] for k in range(1048576)))
                code = out / 'text-probe.bin'
                subprocess.run([str(a.vasm), '-Fbin', '-m68000', '-quiet', '-o', str(code), str(ROOT / 'backports/striderex/asm/grandmaster_text_probe.s')], check=True)
                probe = code.read_bytes()
                off = 1046272
                if len(probe) > 256 or bank[off:off + len(probe)] != b'\xff' * len(probe):
                    raise ValueError('text probe allocation occupied')
                bank[off:off + len(probe)] = probe
                f['strex_p6.bin'] = bytes((bank[k ^ 1] for k in range(len(bank))))
                variant = out / 'variant'
                d = variant / m
                d.mkdir(parents=True)
                for n, b in f.items():
                    (d / n).write_bytes(b)
                vm['sets'] = {m: dict(vm['sets'][m], files={n: sha(b) for n, b in f.items()})}
                (variant / 'build.json').write_text(json.dumps(vm) + '\n')
                roms = G.stage_sets(variant, name, a.hbmame, a.rom_dir.resolve(), out / 'sets')
            frames = 7000 if kind == 'text' else 15000
            env = dict(os.environ, SDL_VIDEODRIVER='dummy', SDL_AUDIODRIVER='dummy', OUT=str(out), CASE=kind, UNRANKED=str(int(unranked)), HELD_START=str(int(a.held_start_only)), STREX_DEBUG_START=str(G.DEBUG_START), STREX_PREFIX=str(out / 'dbg'), STREX_STAGE='0' if kind == 'text' else '4', STREX_AREA=str(a.text_area) if kind == 'text' else '10', STREX_INVINCIBLE='1', STREX_INVINCIBLE_END='1420' if kind != 'text' else '99999', STREX_END=str(frames), STREX_INPUTS='450-7000:P1_JOYSTICK_RIGHT;450-7000@10/3:P1_BUTTON1;450-7000@60/15:P1_BUTTON2' if kind == 'text' else '450-1400@6/3:P1_BUTTON1')
            cmd = [str(binary), name, '-rompath', str(roms), '-nothrottle', '-video', 'none', '-sound', 'none', '-skip_gameinfo', '-noautosave', '-seconds_to_run', str(frames // 50 + 60), '-cfg_directory', str(out / 'cfg'), '-nvram_directory', str(out / 'nv'), '-snapshot_directory', str(out), '-autoboot_script', str(LUA)]
            p = subprocess.run(cmd, env=env, cwd=out, capture_output=True, text=True, timeout=900)
            (out / 'mame.log').write_text(p.stdout + p.stderr)
            if p.returncode:
                raise ValueError('MAME follow-up run failed')
        events = [(int(f), k, v) for f, k, v in (r.split('\t') for r in (out / 'events.tsv').read_text().splitlines())]
        first = lambda key: next((f for f, k, v in events if k == key), None)
        if kind == 'text':
            rows = [v for f, k, v in events if k == 'native-text-row']
            text = json.loads(T.MANIFEST.read_text())['edits'][0]['after']
            want = ','.join((f'{28672 + c:04x}:001e' for c in T.encoded(text)))
            if rows != [want]:
                raise ValueError('native drawer did not render the approved text')
            palette = next((v for f, k, v in events if k == 'native-text-palette'), None)
            image = R.compose(inventory(a.build)[1]['striderua'], R.SETS['striderua'])
            if palette != bytes(image[473438:473470]).hex():
                raise ValueError('native text palette not retained')
            if not any((k == 'native-text-scroll-x' and v == 'ffc0' for f, k, v in events)):
                raise ValueError('native text would clip at the left edge')
            print('PASS native Grandmaster copyedit through original drawer', flush=True)
            return dict(passed=True, native_drawer_reads_and_vram_verified=True, text=text, palette_preserved=True, probe_is_diagnostic_only=True, visible_x=32, advance=8, columns=len(text), diagnostic_source_sha256=sha((ROOT / 'backports/striderex/asm/grandmaster_text_probe.s').read_bytes()), screenshot_sha256=sha((out / 'text.png').read_bytes()), event_sha256=sha((out / 'events.tsv').read_bytes()))
        confirmed, exit_, ended, fresh, started = [first(k) for k in ('confirmed', 'initials-exit', 'game-ended', 'fresh-start', 'fresh-game')]
        if None in (confirmed, exit_, ended, fresh, started):
            raise ValueError(f'{out.name}: incomplete initials/return/start path')
        want = 90 if label == 'control' else 480
        if exit_ - confirmed != want:
            raise ValueError(f'{out.name}: hold {exit_ - confirmed}, expected {want}')
        if not 80 < confirmed - first('rank-start') < 250:
            raise ValueError('initials were not entered with player controls')
        initials = next((v for f, k, v in events if k == 'initials-exit'))
        if initials[:6] == '202020':
            raise ValueError('blank-name END selection did not exercise three initials')
        if first('unexpected-start') is not None or started < fresh:
            raise ValueError('game started without fresh Start')
        sounds = [(f, v) for f, k, v in events if k == 'sound']
        milestones = [next((f for f, v in sounds if v == c)) for c in ('20', '21', '0e', '22')]
        if milestones != sorted(milestones):
            raise ValueError('clear/ending/game-over/name-entry path incomplete')
        table = [v for f, k, v in events if k == 'rank-end']
        if len(table) != 1:
            raise ValueError('no saved ranking table')
        held = held_start_check(events, confirmed, ended, fresh) if a.held_start_only else None
        print('PASS', out.name, 'confirmed hold', exit_ - confirmed, 'frames; fresh Start required', '(held Start checked)' if held else '', flush=True)
        return dict(label=label, machine=m, unranked=unranked, passed=True, confirmed=confirmed, exit=exit_, hold_frames=exit_ - confirmed, entered_initials_hex=initials, game_ended=ended, no_automatic_new_game_frames=fresh - ended, actual_game_clear_and_ending=True, fresh_start=fresh, fresh_game=started, ranking_table_sha256=sha(bytes.fromhex(table[0])), event_sha256=sha((out / 'events.tsv').read_bytes()), **{'held_start': held} if held else {})
    with ThreadPoolExecutor(2) as ex:
        results = list(ex.map(run, jobs))
    if results:
        for m in ('striderua', 'striderjr'):
            repaired = next((r for r in results if r['label'] == 'candidate' and r['machine'] == m and r['unranked']))
            ranked = next((r for r in results if r['label'] == 'candidate' and r['machine'] == m and (not r['unranked'])))
            if not a.held_start_only:
                c = next((r for r in results if r['label'] == 'control' and r['machine'] == m))
                for k in ('confirmed', 'entered_initials_hex', 'ranking_table_sha256'):
                    if c[k] != repaired[k]:
                        raise ValueError('confirmation or saved name/table changed')
            if ranked['ranking_table_sha256'] == repaired['ranking_table_sha256']:
                raise ValueError('ranked and no-ranking controls did not separate')
    text = run(('candidate', 'striderua', False), 'text') if not (a.no_text or a.held_start_only) else None
    receipt = dict(schema='striderex-arcade-copyedit-postgame/1', passed=True, exact_inverse_audit_passed=True, scope='postgame-held-start' if a.held_start_only else 'copyedit-and-postgame' if results and text else 'postgame' if results else 'copyedit', lua_sha256=sha(LUA.read_bytes()), runtime={k: rt[k] for k in ('binary_sha256', 'source_revision', 'board_wait')}, input_files={k: {m: s['files'] for m, s in v['sets'].items()} for k, v in (('control', control), ('candidate', meta))}, postgame=results, text=text, hardware_review_granted=False)
    a.receipt.write_text(json.dumps(receipt, indent=2) + '\n')
    print('PASS:', receipt['scope'])

def main():
    if sys.argv[1:] == ['--self-test']:
        good = [(160, 'start-held', '1'), (1241, 'start-released', '0')]
        assert held_start_check(good, 100, 1000, 1800)['release_to_fresh_start_frames'] == 559
        for bad in (good[:1], [(1001, 'start-held', '1'), good[1]], good + [(1100, 'unexpected-start', '1')]):
            try:
                held_start_check(bad, 100, 1000, 1800)
            except ValueError:
                pass
            else:
                raise AssertionError('invalid held-Start evidence accepted')
        print('Arcade follow-up self-test PASS: held input, release and automatic-start failures checked')
        return
    p = argparse.ArgumentParser(description=__doc__)
    for n in ('control', 'build', 'runtime', 'hbmame', 'rom-dir', 'workdir', 'receipt', 'vasm'):
        p.add_argument('--' + n, type=Path, required=True)
    p.add_argument('--reuse', action='store_true')
    p.add_argument('--only-text', action='store_true')
    p.add_argument('--no-text', action='store_true')
    p.add_argument('--text-area', type=int, default=1)
    p.add_argument('--held-start-only', action='store_true', help='four candidate clear paths with Start held across return')
    a = p.parse_args()
    if a.held_start_only and a.only_text:
        p.error('--held-start-only cannot be combined with --only-text')
    gate(a)
if __name__ == '__main__':
    main()
