-- Stage-clear observation. Optional forced mode 6 and draw-only experiments
-- are research controls, explicitly recorded by scripts/stage_clear_study.py.
local m=manager.machine
local cpu=m.devices[':maincpu']
local sp=cpu.spaces['program']
local screen=m.screens[':screen']
local out=assert(os.getenv('OUT'))
local limit=tonumber(os.getenv('END') or '4000')
local force=tonumber(os.getenv('CLEAR_AT') or '')
local after=tonumber(os.getenv('AFTER_CLEAR') or '400')
local f,clear,played=0,nil,false
local experiment=os.getenv('PRESENTATION_EXPERIMENT')=='1'
local idle,colors,stars,bonus,bonus_colors=nil,nil,nil,nil,nil
local regs={}
local events=assert(io.open(out..'/events.tsv','w'))
events:write('frame\tkind\taddress\tvalue\tpc\tline\n')
local log=assert(io.open(out..'/frames.tsv','w'))
log:write('frame\tmode\tstage\tstate\tsub\tx\ty\tcamx\tcamy\tlayer\tobjbase\tentries\thiryu_entries\tactive\tpalette\n')
local detail=assert(io.open(out..'/sprites.tsv','w'))
detail:write('frame\tplayer_palette\tpalette_words\tplayer_object\tlist\tbonus_label\n')
local taps={}
local extension=os.getenv('STUDY_EXTENSION') and dofile(os.getenv('STUDY_EXTENSION')) or nil
local function event(kind,a,v)
 local line=math.floor((262-screen:time_until_pos(0,0)/screen.scan_period)%262)
 events:write(string.format('%d\t%s\t%x\t%x\t%x\t%d\n',f,kind,a,v,cpu.state['CURPC'].value,line))
end
taps[#taps+1]=sp:install_write_tap(0x800100,0x80017f,'clear_regs',function(a,d,mask)
 regs[a]=d
 if clear and (a==0x800100 or a==0x800166) then event('reg',a,d) end
end)
taps[#taps+1]=sp:install_write_tap(0xff0c12,0xff0c13,'clear_mode',function(a,d,mask)
 if f>450 then event('mode',a,d) end
end)
taps[#taps+1]=sp:install_write_tap(0xff10ca,0xff111f,'clear_hiryu',function(a,d,mask)
 if clear and (a==0xff10ca or a==0xff10d2 or a==0xff10d6) then event('player',a,d) end
end)
_G.stage_clear_taps=taps
if experiment then
 taps[#taps+1]=sp:install_write_tap(0x900000,0x9047ff,'clear_keep_list',function(a,d,mask)
  local pc=cpu.state['CURPC'].value
  if clear and f-clear<6 and (pc==0xb52 or pc==0xb54) then return sp:read_u16(a) end
 end)
end
dofile(assert(os.getenv('STREX_DEBUG_START')))
emu.register_frame_done(function()
 f=f+1
 local mode=sp:read_u16(0xff0c12)
 if mode==4 and f>400 and not idle and sp:read_u8(0xff10ca)==1 and sp:read_u8(0xff10cb)==1
    and sp:read_u8(0xff10cd)==0 and sp:read_u16(0xff10dc)~=0 then idle=sp:read_u16(0xff10dc) end
 if f>450 and mode==4 then played=true end
 if played and force and f>=force and not clear and mode==4 and sp:read_u8(0xff10ca)==1 then
  event('forced_clear',0xff0c12,6)
  sp:write_u16(0xff0c12,6)
  mode=6
 end
 if played and mode==6 and not clear then clear=f;event('clear_observed',0,0) end
 if extension then extension.frame(f,clear,mode,regs) end
 if experiment and clear and mode==6 then
  local pal=sp:read_u8(0xff10f1)&31
  if not colors then
   colors={}
   for i=0,511 do colors[i]=sp:read_u16(0x914000+2*i) end
   stars={}
   for i=0,1023 do stars[i]=sp:read_u16(0x915000+2*i) end
  end
  if not bonus and sp:read_u16(0xff10d2)==80 and sp:read_u16(0xff10d6)==128 then
   bonus=f
   if idle then sp:write_u16(0xff10dc,idle) end
   for i=0,4 do sp:write_u8(0xff112a+0x50*i+1,0) end
   event('experiment_bonus_idle',0xff10dc,idle or 0)
  end
  local level
  if not bonus then level=sp:read_u16(0x914422)>>12
  else level=math.min(15,math.max(0,f-bonus-3)) end
  for i=0,511 do
   local v=level==0 and 0 or ((colors[i]&0xfff)|(level<<12))
   sp:write_u16(0x914000+2*i,v)
  end
  for i=0,1023 do
   local v=(level==0 or bonus) and 0 or ((stars[i]&0xfff)|(level<<12))
   sp:write_u16(0x915000+2*i,v)
  end
  if bonus and f-bonus==25 then
   bonus_colors={}
   for i=0,1023 do bonus_colors[i]=sp:read_u16(0x914000+2*i) end
  end
  local timer=sp:read_u16(0xff0c1a)
  if bonus_colors and timer<=24 then
   local fade=math.max(0,math.min(15,math.floor((timer-2)*15/22)))
   for i=0,1023 do
    local v=fade==0 and 0 or ((bonus_colors[i]&0xfff)|(fade<<12))
    sp:write_u16(0x914000+2*i,v)
   end
  end
 end
 local base=(regs[0x800100] or sp:read_u16(0xff0c9a))*256
 local n,h=0,0
 local pal=sp:read_u8(0xff10f1)&31
 local list={}
 if base>=0x900000 and base<0x930000 then
  for i=0,255 do
   local a=base+8*i
   local x,y,code,attr=sp:read_u16(a),sp:read_u16(a+2),sp:read_u16(a+4),sp:read_u16(a+6)
   if attr==0xff00 then break end
   if x~=0 or y~=0 then
    n=n+1
    if (attr&31)==pal then h=h+1;list[#list+1]=string.format('%x,%x,%x,%x',x,y,code,attr) end
   end
  end
 end
 log:write(string.format('%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%x\t%x\t%d\t%d\t%x\t%x\n',
  f,mode,sp:read_u8(0xff0cb2),sp:read_u8(0xff10cd),sp:read_u8(0xff10ce),
  sp:read_u16(0xff10d2),sp:read_u16(0xff10d6),sp:read_u16(0xff0ff4),sp:read_u16(0xff0ff8),
  regs[0x800166] or 0,base,n,h,sp:read_u16(0xfff914),sp:read_u16(0x914422)))
 if clear then
  local words,obj={},{}
  for i=0,15 do words[#words+1]=string.format('%04x',sp:read_u16(0x914000+32*pal+2*i)) end
  for i=0,47 do obj[#obj+1]=string.format('%04x',sp:read_u16(0xff10ca+2*i)) end
  local label={}
  for i=0,18 do label[#label+1]=string.format('%04x',sp:read_u16(0x90a728+128*i)) end
  detail:write(string.format('%d\t%d\t%s\t%s\t%s\t%s\n',f,pal,table.concat(words,','),table.concat(obj,','),table.concat(list,';'),table.concat(label,',')))
 end
 if played and not clear then
  screen:snapshot(string.format('%s/s_%05d.png',out,f))
  os.remove(string.format('%s/s_%05d.png',out,f-12))
 elseif clear and (f-clear<16 or (f-clear)%5==0 or (extension and extension.capture and extension.capture(f))) then
  screen:snapshot(string.format('%s/s_%05d.png',out,f))
 end
 log:flush();events:flush();detail:flush()
 if f>=limit or (clear and f>=clear+after) then m:exit() end
end)
