"""P0.2: capture the arcade ending and identify its music."""
import argparse
import json
import os
import subprocess
import sys
import wave
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
ROOT = Path(__file__).resolve().parents[3]
LUA = ROOT / 'backports/striderex/lua/arcade_debug_start.lua'
FPS = 59.637
RATE = 11025
MATCH_MIN = 0.8
CONTROL_MAX = 0.5
RUNS = {'ending': dict(STREX_STAGE='4', STREX_AREA='10', STREX_INVINCIBLE='1', STREX_INVINCIBLE_END='1420', STREX_END='4800', STREX_INPUTS='450-1400@6/3:P1_BUTTON1', STREX_SHOTS=','.join((str(f) for f in range(1380, 4800, 90)))), 'reference': dict(STREX_STAGE='0', STREX_AREA='0', STREX_INVINCIBLE='1', STREX_END='2400')}

def read_log(path):
    """[(frame, kind, value)] from the Lua's TSV."""
    rows = []
    for line in Path(path).read_text().splitlines()[1:]:
        f, kind, value = line.split('\t')[:3]
        rows.append((int(f), kind, value))
    return rows

def first_cue(rows, cue, after=0):
    for f, kind, value in rows:
        if kind == 'sound' and int(value, 16) == cue and (f >= after):
            return f
    return None

def run(name, workdir, rompath, mame):
    d = workdir / name
    d.mkdir(parents=True, exist_ok=True)
    env = dict(os.environ, SDL_VIDEODRIVER='dummy', SDL_AUDIODRIVER='dummy', STREX_PREFIX=str(d / 'run'), **RUNS[name])
    cmd = [mame, 'striderua', '-rompath', str(rompath), '-nothrottle', '-video', 'none', '-sound', 'none', '-wavwrite', str(d / 'run.wav'), '-skip_gameinfo', '-noautosave', '-cfg_directory', str(d / 'cfg'), '-nvram_directory', str(d / 'nv'), '-snapshot_directory', str(d), '-autoboot_script', str(LUA)]
    p = subprocess.run(cmd, env=env, cwd=d, capture_output=True, text=True, timeout=600)
    if p.returncode:
        sys.exit(f'{name}: MAME exit {p.returncode}\n{p.stderr[-2000:]}')
    return d

def load_wav(path):
    import numpy as np
    import scipy.signal as ss
    with wave.open(str(path)) as w:
        if w.getsampwidth() != 2:
            sys.exit(f'{path}: expected 16-bit PCM')
        x = np.frombuffer(w.readframes(w.getnframes()), '<i2').astype(np.float32) / 32768
        x = x.reshape(-1, w.getnchannels()).mean(1)
        rate = w.getframerate()
    g = np.gcd(rate, RATE)
    return ss.resample_poly(x, RATE // g, rate // g).astype(np.float32)

def contact_sheet(d, out):
    from PIL import Image
    shots = sorted(d.glob('run_*.png'))
    if not shots:
        return 0
    ims = [Image.open(p) for p in shots]
    w, h = ims[0].size
    cols = 8
    sheet = Image.new('RGB', (cols * w // 2, (len(ims) + cols - 1) // cols * h // 2))
    for i, im in enumerate(ims):
        sheet.paste(im.resize((w // 2, h // 2)), (i % cols * w // 2, i // cols * h // 2))
    sheet.save(out)
    return len(ims)

def analyze(workdir):
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    import cinematic_bed_match as cb
    end_rows = read_log(workdir / 'ending/run_log.tsv')
    ref_rows = read_log(workdir / 'reference/run_log.tsv')
    t = {name: first_cue(end_rows, cue, 1000) for name, cue in (('game_clear_0x20', 32), ('ending_0x21', 33), ('game_over_0x0e', 14))}
    ref00 = first_cue(ref_rows, 0, 450)
    missing = [k for k, v in t.items() if v is None] + ([] if ref00 is not None else ['reference_0x00'])
    report = dict(frames=t, reference_0x00=ref00, fps=FPS, missing=missing)
    if missing:
        return (report, False)
    end = load_wav(workdir / 'ending/run.wav')
    ref = load_wav(workdir / 'reference/run.wav')
    tgt = cb.features(ref)
    sec = cb.HOP / RATE

    def match(start_frame, length):
        s = start_frame / FPS + 0.5
        score, lag = cb.best_match(cb.features(end[int(s * RATE):int((s + length) * RATE)]), tgt)
        return (round(score, 3), round(lag * sec - (ref00 / FPS + 0.5), 2))
    score, offset = match(t['ending_0x21'], 20)
    control, _ = match(t['game_clear_0x20'], 10)
    report.update(seconds={'game_clear_to_ending': round((t['ending_0x21'] - t['game_clear_0x20']) / FPS, 2), 'ending_to_game_over': round((t['game_over_0x0e'] - t['ending_0x21']) / FPS, 2)}, ending_vs_tune00=dict(score=score, offset_s=offset), control_game_clear_vs_tune00=control, shots=contact_sheet(workdir / 'ending', workdir / 'contact.png'))
    ok = score >= MATCH_MIN and abs(offset) <= 0.1 and (control <= CONTROL_MAX)
    return (report, ok)

def self_test():
    import tempfile
    with tempfile.TemporaryDirectory() as tmp:
        p = Path(tmp) / 'log.tsv'
        p.write_text('frame\tkind\tvalue\n0\tdswa_raw\tfc\n500\tsound\t20\n1402\tsound\t20\n2258\tsound\t21\n4720\tsound\t0e\n4800\tcamera\t0000,0000\tplayer\t0000,0000\n')
        rows = read_log(p)
        assert first_cue(rows, 32, 1000) == 1402
        assert first_cue(rows, 33) == 2258
        assert first_cue(rows, 14) == 4720
        assert first_cue(rows, 34) is None
        assert rows[-1] == (4800, 'camera', '0000,0000')
    print('self-test ok')
    return 0

def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('--rompath', type=Path)
    p.add_argument('--workdir', type=Path)
    p.add_argument('--mame', default='mame')
    p.add_argument('--analyze-only', action='store_true', help='reuse the two runs already in --workdir')
    p.add_argument('--self-test', action='store_true')
    a = p.parse_args()
    if a.self_test:
        return self_test()
    if not a.workdir or (not a.analyze_only and (not a.rompath)):
        p.error('--workdir and --rompath are required')
    a.workdir.mkdir(parents=True, exist_ok=True)
    if not a.analyze_only:
        with ThreadPoolExecutor(2) as ex:
            list(ex.map(lambda n: run(n, a.workdir, a.rompath.resolve(), a.mame), RUNS))
    report, ok = analyze(a.workdir)
    (a.workdir / 'report.json').write_text(json.dumps(report, indent=1) + '\n')
    print(json.dumps(report, indent=1))
    print('PASS' if ok else 'FAIL')
    return 0 if ok else 1
if __name__ == '__main__':
    sys.exit(main())
