"""Keep confirmed initials visible for eight seconds before the stock exit."""
import argparse
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import subprocess
from asm_payload import command as assembly_command
import sys
from boss_voice_gate import inventory
import respawn_fix as R
ENTRY = 2094592
SITES = (13042, 13054)
OLD = bytes.fromhex('1b7c00068cdd')
EXTRA = 390

def sha(b):
    return hashlib.sha256(b).hexdigest()

def patch(image):
    b = bytearray(image)
    for at in SITES:
        if b[at:at + 6] != OLD:
            raise ValueError('unknown initials exit instruction')
        b[at:at + 6] = b'N\xb9' + ENTRY.to_bytes(4, 'big')
    return b

def build(a):
    meta, files = inventory(a.build)
    rep = deepcopy(meta)
    a.out.mkdir(parents=True, exist_ok=False)
    code = a.out / 'postgame-hold.bin'
    subprocess.run([*assembly_command(a.vasm), '-Fbin', '-m68000', '-quiet', '-o', str(code), str(Path(__file__).resolve().parents[1] / 'asm/postgame_hold.s')], check=True)
    helper = code.read_bytes()
    if len(helper) > 128:
        raise ValueError('postgame helper exceeds its allocation')
    for m, f in files.items():
        image = R.compose(f, R.SETS[m])
        changed = patch(image)
        p6 = f['strex_p6.bin']
        raw = bytearray((p6[i ^ 1] for i in range(len(p6))))
        start = ENTRY - 1048576
        if raw[start:start + len(helper)] != b'\xff' * len(helper):
            raise ValueError('postgame helper allocation occupied')
        raw[start:start + len(helper)] = helper
        f = dict(f, **R.decompose(changed, R.SETS[m], {n: len(f[n]) for n, _, _ in R.SETS[m]}))
        f['strex_p6.bin'] = bytes((raw[i ^ 1] for i in range(len(raw))))
        out = a.out / m
        out.mkdir()
        for n, b in f.items():
            (out / n).write_bytes(b)
        rep['sets'][m]['files'] = {n: sha(b) for n, b in f.items()}
        rep['sets'][m]['postgame_hold'] = dict(sites=list(SITES), original=OLD.hex(), helper_at=ENTRY, helper_bytes=len(helper), helper_sha256=sha(helper), extra_frames=EXTRA, total_confirmed_frames=480, source_files=meta['sets'][m]['files'])
        print(m, 'confirmed initials held for 480 frames', flush=True)
    (a.out / 'build.json').write_text(json.dumps(rep, indent=2) + '\n')

def main():
    if sys.argv[1:] == ['--self-test']:
        b = bytearray(16384)
        for at in SITES:
            b[at:at + 6] = OLD
        out = patch(b)
        assert sum((x != y for x, y in zip(b, out))) <= 12
        b[SITES[0]] ^= 1
        try:
            patch(b)
        except ValueError:
            pass
        else:
            raise AssertionError('changed exit accepted')
        assert 90 + EXTRA == 480
        print('Postgame hold self-test PASS: ranked/unranked exits, unknown code rejected')
        return
    p = argparse.ArgumentParser(description=__doc__)
    for n in ('build', 'vasm', 'out'):
        p.add_argument('--' + n, type=Path, required=True)
    build(p.parse_args())
if __name__ == '__main__':
    main()
