"""P0.4: extract and render the PC Engine desert's section maps."""
import argparse
import hashlib
import json
import re
import sys
from pathlib import Path
import numpy as np
sys.path.insert(0, str(Path(__file__).resolve().parent))
import pce_vdc as pv
RAM_LO = 851968
MAP_BANK, MAP_BYTES = (120, 24576)
DEF_BANK, DEF_OFFSET, DEF_BYTES = (124, 4096, 4096)
VIS_ROWS, VIS_COLS = (15, 17)
COLLISION_OFFSET = 3584
CODE_BANK, CLASS_TABLE = (105, 26520)

def bank(c, b, offset=0, n=8192):
    o = (b - 104) * 8192 + offset
    return c[o:o + n]

def section(capture, frame, tag):
    r = (capture / f'pce_{tag}_ram_1f0000.bin').read_bytes()
    c = (capture / f'pce_{tag}_ram_0d0000.bin').read_bytes()
    w, row0, col0 = (r[3465], r[3466], r[3467])
    cam_y, cam_x = (r[3468] | r[3469] << 8, r[3470] | r[3471] << 8)
    raw_map = bank(c, MAP_BANK, 0, MAP_BYTES)
    raw_defs = bank(c, DEF_BANK, DEF_OFFSET, DEF_BYTES)
    m = np.frombuffer(raw_map, '<u2').reshape(-1, w)
    defs = np.frombuffer(raw_defs, '<u2').reshape(-1, 4)
    collision = bank(c, DEF_BANK, COLLISION_OFFSET, 512)
    class_table = bank(c, CODE_BANK, CLASS_TABLE - 24576, 256)
    return dict(frame=frame, tag=tag, checkpoint=r[3205], section=r[3339], width=w, row0=row0, col0=col0, cam_x=cam_x, cam_y=cam_y, map=m, defs=defs, collision=collision, class_table=class_table, collision_sha256=hashlib.sha256(collision).hexdigest(), map_sha256=hashlib.sha256(raw_map).hexdigest(), defs_sha256=hashlib.sha256(raw_defs).hexdigest())

def check_bat(s, d):
    """Visible metatiles against the live BAT; returns (checked, mismatched)."""
    bat = d['vram'][:2048]
    r_cam, c_cam = (s['cam_y'] >> 4, s['cam_x'] >> 4)
    checked = bad = 0
    for row in range(r_cam, r_cam + VIS_ROWS):
        for col in range(c_cam, c_cam + VIS_COLS):
            y, x = (row - s['row0'], col - s['col0'] & 255)
            if not (0 <= y < s['map'].shape[0] and x < s['width']):
                continue
            n = s['map'][y, x]
            if n >= len(s['defs']):
                checked += 1
                bad += 1
                continue
            want = s['defs'][n]
            a = row * 128 + (col & 31) * 2 & 2047
            got = bat[[a, a + 1, a + 64 & 2047, a + 65 & 2047]]
            checked += 1
            bad += int((want != got).any())
    return (checked, bad)

def render(s, d):
    """RGB image, the BAT words of valid cells, and the valid-cell mask."""
    tiles = pv.all_bg_tiles(d['vram'])
    valid = s['map'] < len(s['defs'])
    words = s['defs'][np.where(valid, s['map'], 0)]
    h, w = s['map'].shape
    quad = words.reshape(h, w, 2, 2)
    px = tiles[quad & 2047]
    pal = (quad >> 8 & 240)[..., None, None]
    idx = np.where(px != 0, px | pal, 0)
    img = idx.transpose(0, 2, 4, 1, 3, 5).reshape(h * 16, w * 16)
    mask = np.repeat(np.repeat(~valid, 16, 0), 16, 1)
    img = np.where(mask, 0, img)
    rgb = pv.pal_rgb(d['pal'])[img]
    rgb[mask] = 0
    return (rgb, words[valid], valid, img)

def name_of(s):
    return f"map_{s['width']}x{s['map'].shape[0]}_row{s['row0']}_col{s['col0']}"

def tile_keys(idx, size):
    """Distinct non-empty size x size tiles, folding X/Y flips (CPS-1 tiles can"""
    h, w = idx.shape
    idx = np.pad(idx, ((0, -h % size), (0, -w % size)))
    t = idx.reshape(idx.shape[0] // size, size, -1, size).swapaxes(1, 2).reshape(-1, size, size)
    t = t[(t != 0).any((1, 2))]

    def canon(a):
        return min((v.astype(np.int16).tobytes() for v in (a, a[:, ::-1], a[::-1], a[::-1, ::-1])))
    return ({canon(x) for x in t}, {canon(x & 15) for x in t})

def tile_census(images):
    """Tile counts per map and for all maps together, at 1:1 and widened 1.5x"""
    from rescale_pilot import method_edge_pick
    out = {}
    for scale, conv in (('1x', lambda x: x), ('E1.5x', method_edge_pick)):
        widened = {name: conv(img) for name, img in images.items()}
        for size in (16, 32):
            union_full, union_pat, per = (set(), set(), {})
            for name, img in widened.items():
                full, pat = tile_keys(img, size)
                per[name] = [len(full), len(pat)]
                union_full |= full
                union_pat |= pat
            out[f'{scale}_{size}x{size}'] = dict(per_map=per, all_maps=[len(union_full), len(union_pat)], bytes_all_maps=len(union_full) * size * size // 2)
    return out

def collision_classes(s, valid):
    """{class: [shape, flags, cells]} over the map's valid cells (routine 0x6377/0x6351)."""
    cls = np.frombuffer(s['collision'], np.uint8)[s['map'][valid]]
    out = {}
    for k, n in zip(*np.unique(cls, return_counts=True)):
        out[int(k)] = [s['class_table'][2 * k], s['class_table'][2 * k + 1], int(n)]
    return out

def verified_maps(capture):
    """Check every checkpoint of a census; returns (rows, {(width, row0, col0): (s, d, row) or None})."""
    rows, entries = ([], {})
    for ram in sorted(capture.glob('pce_*_checkpoint_*_ram_1f0000.bin')):
        mt = re.match('pce_(\\d+)_(checkpoint_\\d+)_ram', ram.name)
        frame, tag = (int(mt[1]), f'{mt[1]}_{mt[2]}')
        scenes = sorted(capture.glob('pce_*_scene.vdc'), key=lambda q: abs(int(q.name.split('_')[1]) - frame))
        if not scenes or abs(int(scenes[0].name.split('_')[1]) - frame) > 8:
            sys.exit(f'{tag}: no scene dump within 8 frames; add --window {frame}:{frame}:1 to the census')
        d = pv.load(scenes[0])
        s = section(capture, frame, tag)
        checked, bad = check_bat(s, d)
        row = {k: s[k] for k in ('checkpoint', 'section', 'width', 'row0', 'col0', 'cam_x', 'cam_y', 'map_sha256', 'defs_sha256')}
        row.update(height=int(s['map'].shape[0]), scene=scenes[0].name, bat_checked=checked, bat_mismatched=bad)
        rows.append(row)
        entry = (s['width'], s['row0'], s['col0'])
        if checked and (not bad) and (entry not in entries):
            entries[entry] = (s, d, row)
        else:
            entries.setdefault(entry, None)
    return (rows, entries)

def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('capture', type=Path, help='checkpoint census directory with scene dumps')
    p.add_argument('--output', type=Path, required=True)
    a = p.parse_args()
    from PIL import Image
    a.output.mkdir(parents=True, exist_ok=True)
    images = {}
    rows, entries = verified_maps(a.capture)
    ok = bool(entries) and all((v is not None for v in entries.values()))
    for entry, v in entries.items():
        if v is None:
            print(f'FAIL: no checkpoint verifies map {entry}')
            continue
        s, d, row = v
        rgb, words, valid, idx = render(s, d)
        images[name_of(s)] = idx
        name = name_of(s) + '.png'
        Image.fromarray(rgb).save(a.output / name)
        row.update(image=name, pixels=[int(rgb.shape[1]), int(rgb.shape[0])], rows_all_valid=int(valid.all(1).sum()), metatiles_used=int(len(np.unique(s['map'][valid]))), tiles_8x8=int(len(np.unique(words & 2047))), palettes=sorted((int(x) for x in np.unique(words >> 12))), collision_sha256=s['collision_sha256'], collision_classes=collision_classes(s, valid))
    for row in rows:
        print(json.dumps(row))
    census = tile_census(images) if ok else None
    for k, v in (census or {}).items():
        print(k, json.dumps(v))
    report = dict(checkpoints=rows, tile_census=census, tile_census_note='[full, pattern-only] distinct non-empty tiles, X/Y flips folded; bytes at 4 bits per pixel for the full count')
    (a.output / 'maps.json').write_text(json.dumps(report, indent=1) + '\n')
    print('PASS' if ok else 'FAIL')
    return 0 if ok else 1
if __name__ == '__main__':
    sys.exit(main())
