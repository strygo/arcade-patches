"""Reconstruction helper."""
import argparse
import json
import sys
from pathlib import Path
import numpy as np
sys.path.insert(0, str(Path(__file__).resolve().parent))
import cps1_gfx as G
ROOT = Path(__file__).resolve().parents[3]
ASSETS = ROOT / 'backports/striderex/assets/title_ex'
FIRST_CODE, LAST_CODE = (16352, 16383)
S2_FIRST, S2_LAST = (33664, 33748)
TILE = {'scr3': 32, 'scr2': 16}
REGION_KEY = {'striderua': 'us', 'striderjr': 'jp'}

def mame_rgb(w):
    b = 15 + (w >> 12 << 1)
    return tuple(((w >> s & 15) * 17 * b // 45 for s in (8, 4, 0)))

def stock_gfx(files):
    """The stock 4 MB graphics region (files: {crc32 hex: bytes}, mapper_testkit.pool)."""
    import mapper_testkit as K
    gfx = bytearray(4 * G.MB)
    for off, c in K.GFX_CRCS.items():
        d = files[c]
        for i in range(0, len(d), 2):
            gfx[off + 4 * i:off + 4 * i + 2] = d[i:i + 2]
    return gfx

def stock_tile(gfx, code, layer='scr3'):
    """Stock tile pens. ST24M1: SCROLL3 in bank 1 at 2 MB (512 bytes a tile), SCROLL2 in bank 0"""
    if layer == 'scr2':
        return G.get_tile(gfx, 128 * code & 2097151, 16)
    return G.get_tile(gfx, 2097152 + 512 * (code & 2047), 32)

def composites(gfx, key, first_code, base=None):
    """[(map byte address, stock code, EX code, pens)] for one region's mark, on the layer cells.json"""
    cells = json.loads((ASSETS / 'cells.json').read_text())['regions'][key]
    layer = cells.get('layer', 'scr3')
    n = TILE[layer]
    first_code, last_code = (first_code, LAST_CODE) if layer == 'scr3' else (S2_FIRST, S2_LAST)
    layout = json.loads((ASSETS / 'layout.json').read_text())[key]
    grid = [l.rstrip('\n') for l in (ASSETS / f'{key}_pixels.txt').read_text().splitlines()]
    pal = [mame_rgb(int(w, 16)) for w in cells['s3_palette0']]
    pens_of = []
    for c in layout['palette']:
        hit = [p for p in range(15) if pal[p] == tuple(c)]
        if not hit:
            sys.exit(f'title_ex: {key} mark color {c} is not in SCROLL3 palette 0')
        pens_of.append(hit[0])
    x0, y0 = layout['position']
    out, code = ([], first_code)
    for cell in cells['cells']:
        if cell['attr'] & 96:
            sys.exit(f'title_ex: {key} cell {cell} is flipped (not supported)')
        sx, sy = cell['screen']
        stock_code = int(cell['stock_code'], 16)
        pens = stock_tile(gfx, stock_code, layer).copy()
        addr = int(cell['map_byte'], 16)
        if base and addr in base:
            stock_code, pens = (base[addr][0], base[addr][1].copy())
        changed = False
        for yy in range(n):
            gy = sy + yy - y0
            if not 0 <= gy < len(grid):
                continue
            for xx in range(n):
                gx = sx + xx - x0
                if 0 <= gx < len(grid[gy]) and grid[gy][gx] != '.':
                    if pens[yy, xx] != 15:
                        sys.exit(f'title_ex: {key} mark pixel ({sx + xx}, {sy + yy}) covers a stock pixel')
                    pens[yy, xx] = pens_of[int(grid[gy][gx])]
                    changed = True
        if changed:
            if code > last_code:
                sys.exit('title_ex: reserved title codes exhausted')
            out.append((int(cell['map_byte'], 16), stock_code, code, pens, layer))
            code += 1
    return (out, code if layer == 'scr3' else first_code)

def install(region, gfx, base=None):
    """Write both regions' composites into the EX region; returns {machine: cells}. base: {key: {map"""
    out, code = ({}, FIRST_CODE)
    for machine, key in REGION_KEY.items():
        cells, code = composites(gfx, key, code, (base or {}).get(key))
        for _, _, c, pens, layer in cells:
            at, size = (G.ex_offset(layer, c), TILE[layer] ** 2 // 2)
            if any(region[at:at + size]):
                sys.exit(f'title_ex: EX {layer} code {c:#06x} is already in use')
            G.put_tile(region, at, pens)
        out[machine] = [(a, s, c) for a, s, c, _, _ in cells]
    return out
USA_FADES = (23748, 23764)
LOGO_COLORS = 23838

def usa_fades(program):
    """[(first pen, last pen, steps)] of the stock USA logo's two fades, read from their calls."""
    out = []
    for at in USA_FADES:
        w = [int.from_bytes(program[at + 2 * i:at + 2 * i + 2], 'big') for i in range(6)]
        if (w[0], w[2], w[4]) != (12348, 12860, 13372) or w[1] & 1:
            sys.exit(f'title_ex: the logo fade call at {at:#x} has an unexpected shape')
        out.append((w[1] // 2, w[1] // 2 + w[3], w[5] + 1))
    return out

def mark_fades(gfx, program, base=None):
    """The USA mark's pens by stock fade (asm usa_draw draws the mark with the logo, in palette 0)."""
    cells = json.loads((ASSETS / 'cells.json').read_text())['regions']['us']['cells']
    if any((c['attr'] for c in cells)):
        sys.exit('title_ex: a USA mark cell has a stock attribute other than 0 (palette 0)')
    mark = set()
    for addr, stock_code, _, pens, layer in composites(gfx, 'us', FIRST_CODE, base)[0]:
        st = base[addr][1] if base and addr in base else stock_tile(gfx, stock_code, layer)
        mark |= set((int(p) for p in np.unique(pens[pens != st])))
    stages = [dict(fade=f'{at:#x}', logo_pens=[lo, hi], brightness=[0, steps], pens=sorted((p for p in mark if lo <= p <= hi))) for at, (lo, hi, steps) in zip(USA_FADES, usa_fades(program))]
    if mark != {p for st in stages for p in st['pens']}:
        sys.exit(f'title_ex: USA mark pens {sorted(mark)} are not all in the logo fades')
    return dict(palette=0, stages=stages)

def cells_inc(cells):
    """title_cells.inc: count, then (map byte address, stock code, EX code) per cell."""
    lines = ['title_cells:', f'        dc.w    {len(cells)}']
    for a, s, c in cells:
        lines.append(f'        dc.l    ${a:06X}')
        lines.append(f'        dc.w    ${s:04X},${c:04X}')
    return '\n'.join(lines) + '\n'

def self_test(rom_dir):
    import mapper_testkit as K
    gfx = stock_gfx(K.pool([rom_dir / 'striderua']))
    region = bytearray(4 * G.MB)
    cells = install(region, gfx)
    for machine, cs in cells.items():
        for a, s, c in cs:
            layer = 'scr2' if c >= 32768 else 'scr3'
            got = G.get_tile(region, G.ex_offset(layer, c), TILE[layer])
            stock = stock_tile(gfx, s, layer)
            keep = stock != 15
            if not (got[keep] == stock[keep]).all():
                sys.exit('title_ex self-test: a stock pixel changed')
        print(machine, len(cs), 'composite cells', [f'{c:04X}' for _, _, c in cs])
    import respawn_fix as RF
    import usa_slice as US
    files = {q.name: q.read_bytes() for q in (rom_dir / 'striderua').iterdir() if q.is_file()}
    program = RF.compose(files, RF.SETS['striderua'])
    s3, _, _ = US.split(program, gfx, stock_tile, 16256, 16351)
    plan = mark_fades(gfx, program, {a: (c, p) for a, _, c, p in s3 if p is not None})
    if [st['logo_pens'] for st in plan['stages']] != [[9, 13], [1, 8]] or not all((st['pens'] for st in plan['stages'])):
        sys.exit('title_ex self-test: the USA mark does not take its pens from both logo fades')
    print('us mark', plan)
    print('title_ex self-test passed')
    return 0
GATE_FRAMES = {'jp': range(240, 452), 'us': range(286, 600)}
PEN_REF = {'jp': 416, 'us': 440}
CONTROL_REGIONS = ('us',)
COIN = {'jp': 430, 'us': 480}
COIN_REF = {'jp': 412, 'us': 470}
COIN_SHOTS = (110, 125, 140, 155)
EX_SET = {'jp': 'striderjs01', 'us': 'striderus01'}
STOCK_SET = {'jp': 'striderjr', 'us': 'striderua'}
GATE_LUA = "\nlocal m=manager.machine\nlocal sp=m.devices[':maincpu'].spaces['program']\nlocal f=0\nlocal want={}\nfor v in string.gmatch(os.getenv('FRAMES'),'%d+') do want[tonumber(v)]=true end\nlocal last=tonumber(os.getenv('LAST'))\nlocal coin=tonumber(os.getenv('COIN') or '0')\nlocal fields={}\nfor _,port in pairs(m.ioport.ports) do for name,field in pairs(port.fields) do\n fields[m.ioport:input_type_to_token(field.type,field.player)]=field end end\nemu.register_frame_done(function() f=f+1\n if coin>0 then if f>=coin and f<=coin+8 then fields.COIN1:set_value(1) else fields.COIN1:clear_value() end end\n if f==1 then _G.sh=io.open(os.getenv('OUT')..'/shadows.tsv','w') end\n _G.sh:write(string.format('%d\\t%d\\t%d\\t%d\\t%d\\n',f,sp:read_i16(0xff0c3e),sp:read_i16(0xff0c3c),sp:read_i16(0xff0c36),sp:read_i16(0xff0c34)))\n if want[f] then m.screens[':screen']:snapshot(string.format('%s/s_%05d.png',os.getenv('OUT'),f)) end\n if f==tonumber(os.getenv('REF') or '0') then\n  local fh=io.open(os.getenv('OUT')..'/gfxram.bin','wb')\n  local t={} for a=0x900000,0x92fffe,2 do t[#t+1]=string.pack('>I2',sp:read_u16(a)) end fh:write(table.concat(t)) fh:close()\n  local a=m.memory.shares[':cps_a_regs']\n  local r={} for i=0,0x3e,2 do r[#r+1]=string.format('%04x',a:read_u16(i)) end\n  local fr=io.open(os.getenv('OUT')..'/cps_a.txt','w') fr:write(table.concat(r,' ')..'\\n') fr:close()\n end\n if want[f] or want[f+1] then\n  local fh=io.open(string.format('%s/p_%05d.bin',os.getenv('OUT'),f),'wb')\n  local t={} for a=0x914c00,0x914c1e,2 do t[#t+1]=string.pack('>I2',sp:read_u16(a)) end fh:write(table.concat(t)) fh:close()\n end\n if f>=last then _G.sh:close() m:exit() end end)\n"

def hb_rgb(word):
    bright = 15 + (word >> 12 << 1)
    return tuple((c * 17 * bright // 45 if c > 1 else 0 for c in (word >> s & 15 for s in (8, 4, 0))))

def usa_slice_check(shots, start, sh, frames):
    """The USA slice: every frame from its start equals the rest frame (start - 2) split along"""
    from PIL import Image
    import usa_slice as US
    if start is None:
        return dict(passed=False, why='the SCROLL3 shadow never moved: no slice')
    ref_f = start - 2 if start - 2 in frames else start - 3
    ref = np.asarray(Image.open(shots / f's_{ref_f:05d}.png').convert('RGB')).astype(int)
    yy, xx = np.mgrid[0:224, 0:384]
    (x0, y0), (x1, y1) = US.LINE
    up = (x1 - x0) * (yy - y0) - (y1 - y0) * (xx - x0) < 0
    lit = ref.sum(-1) > 0
    halves = (np.where((lit & up)[..., None], ref, 0), np.where((lit & ~up)[..., None], ref, 0))

    def shifted(img, dx, dy):
        out = np.zeros_like(img)
        ys, xs = (np.arange(224) + dy, np.arange(384) + dx)
        oky, okx = ((ys >= 0) & (ys < 224), (xs >= 0) & (xs < 384))
        out[np.ix_(oky, okx)] = img[np.ix_(ys[oky], xs[okx])]
        return out
    end = next((f for f in sorted(sh) if f > start and sh[f][0] == 0), None)
    if end is None:
        return dict(passed=False, why='the slice never ended')
    judged = [f for f in frames if start <= f < end]
    after = [f for f in frames if end + 3 <= f <= end + 12]
    dark = all((not np.asarray(Image.open(shots / f's_{f:05d}.png').convert('RGB')).any() for f in after))
    best = None
    for lag in (0, 1, 2):
        bad = moving = 0
        for f in judged:
            g = f - lag
            if g not in sh or ref_f not in sh:
                bad += 1
                continue
            d = [sh[g][i] - sh[ref_f][i] for i in range(4)]
            want = shifted(halves[0], d[1], -d[0]) + shifted(halves[1], d[3], -d[2])
            got = np.asarray(Image.open(shots / f's_{f:05d}.png').convert('RGB')).astype(int)
            bad += int((want != got).any(-1).sum())
            moving += any(d)
        if best is None or bad < best[0]:
            best = (bad, 1, lag, moving)
    bad, sign, lag, moving = best
    return dict(start=start, end=end, reference=ref_f, frames=len(judged), moving_frames=moving, sign=sign, lag=lag, pixels_wrong=bad, black_after=dark, frames_after=len(after), passed=bad == 0 and moving >= 20 and dark and (len(after) > 0))

def stage_stock(a, work):
    """The stock sets under HBMAME's member names, found by CRC (as strider_mapper_probe.stage)."""
    import mapper_testkit as K
    import strider_mapper_probe as M
    driver = (a.runtime / 'source/src/hbmame/drivers/cps1.cpp').read_text()
    pool = K.pool([a.rom_dir.resolve()])
    stock_dir = work / 'stock_sets'
    for name in STOCK_SET.values():
        d = stock_dir / name
        d.mkdir(parents=True)
        for member, _, _, c in M.rom_entries(driver, name):
            data = pool.get(c) if c else None
            if data is None and member.endswith('.key'):
                data = M.cps1_key(M.ST24M1, 'CPS_B_01' if name == 'striderua' else 'CPS_B_21_DEF')
            if data is None:
                sys.exit(f'title_ex: {name}/{member}: no stock file with CRC {c}')
            (d / member).write_bytes(data)
    return stock_dir
REFERENCE = {'jp': (410, 'scr3'), 'us': (440, 'scr3')}
MEASURE_LUA = "\nlocal m=manager.machine\nlocal sp=m.devices[':maincpu'].spaces['program']\nlocal out=os.getenv('OUT')\nlocal ref=tonumber(os.getenv('REF'))\nlocal f=0\nemu.register_frame_done(function() f=f+1\n if f==ref then\n  m.screens[':screen']:snapshot(out..'/screen.png')\n  local fh=io.open(out..'/gfxram.bin','wb')\n  local t={} for a=0x900000,0x92fffe,2 do t[#t+1]=string.pack('>I2',sp:read_u16(a)) end fh:write(table.concat(t)) fh:close()\n  local a=m.memory.shares[':cps_a_regs']\n  local r={} for i=0,0x3e,2 do r[#r+1]=string.format('%04x',a:read_u16(i)) end\n  local fr=io.open(out..'/cps_a.txt','w') fr:write(table.concat(r,' ')..'\\n') fr:close()\n  m:exit() end end)\n"
SCREEN = (384, 224)

def on_screen(x, y):
    return 0 <= x < SCREEN[0] and 0 <= y < SCREEN[1]

def measure(a):
    """cells.json: the cells under each mark at its layout position, from graphics RAM at the reference"""
    import os
    import subprocess
    from PIL import Image
    import mapper_testkit as K
    work = a.workdir.resolve()
    work.mkdir(parents=True, exist_ok=False)
    binary = json.loads((a.runtime / 'runtime.json').read_text())['binary']
    stock_dir = stage_stock(a, work)
    gfx = stock_gfx(K.pool([a.rom_dir.resolve() / 'striderua']))
    layout = json.loads((ASSETS / 'layout.json').read_text())
    result = dict(note='Cells under each EX mark (scripts/title_ex.py measure, from graphics RAM at the reference frame of the stock set; every opaque stock pixel of the cells matches the screen, every mark pixel lands on an empty screen pixel and a transparent cell pixel). The hook swaps a cell only if it still holds stock_code.', regions={})
    for key, (ref, layer) in REFERENCE.items():
        name = STOCK_SET[key]
        out = work / key
        out.mkdir()
        (out / 'measure.lua').write_text(MEASURE_LUA)
        env = dict(os.environ, SDL_VIDEODRIVER='dummy', SDL_AUDIODRIVER='dummy', OUT=str(out), REF=str(ref))
        subprocess.run([binary, name, '-rompath', str(stock_dir), '-nothrottle', '-video', 'none', '-sound', 'none', '-seconds_to_run', '30', '-skip_gameinfo', '-noautosave', '-cfg_directory', str(out / 'cfg'), '-nvram_directory', str(out / 'nv'), '-autoboot_script', str(out / 'measure.lua')], env=env, cwd=out, capture_output=True, text=True, timeout=600, check=True)
        ram = np.frombuffer((out / 'gfxram.bin').read_bytes(), '>u2')
        regs = [int(v, 16) for v in (out / 'cps_a.txt').read_text().split()]
        screen = np.asarray(Image.open(out / 'screen.png').convert('RGB')).astype(int)

        def word(addr):
            return int(ram[(addr - 9437184) // 2])
        n = TILE[layer]
        base, sx_, sy_, page, size = (regs[3] * 256, regs[10], regs[11], 3, 2048) if layer == 'scr3' else (regs[2] * 256, regs[8], regs[9], 2, 1024)
        palbase = regs[5] * 256 + page * 1024

        def color(attr, pen):
            w = word(palbase + 2 * (16 * (attr & 31) + pen))
            return hb_rgb(w)
        grid = [l.rstrip('\n') for l in (ASSETS / f'{key}_pixels.txt').read_text().splitlines()]
        x0, y0 = layout[key]['position']
        cells = {}
        for gy, row in enumerate(grid):
            for gx, ch in enumerate(row):
                if ch == '.':
                    continue
                x, y = (x0 + gx, y0 + gy)
                if not (0 <= x < SCREEN[0] and 0 <= y < SCREEN[1]):
                    continue
                if tuple(screen[y, x]) != (0, 0, 0):
                    sys.exit(f'title_ex measure: {key} mark pixel ({x}, {y}) is not on an empty screen pixel')
                mx, my = ((x + 64 + sx_) % size, (y + 16 + sy_) % size)
                col, rw = (mx // n, my // n)
                idx = rw & 7 | col << 3 | (rw & 56) << 6 if layer == 'scr3' else (rw & 15) + ((col & 63) << 4) + ((rw & 48) << 6)
                addr = base + 4 * idx
                cell = cells.setdefault(addr, dict(row=rw, col=col, map_byte=f'{addr:#08x}', stock_code=f'{word(addr):#06x}', attr=word(addr + 2), screen=[x - mx % n, y - my % n]))
                if stock_tile(gfx, word(addr), layer)[my % n, mx % n] != 15:
                    sys.exit(f'title_ex measure: {key} mark pixel ({x}, {y}) covers a stock pixel')
        checked = 0
        for addr, cell in cells.items():
            pens = stock_tile(gfx, int(cell['stock_code'], 16), layer)
            sx, sy = cell['screen']
            for yy in range(n):
                for xx in range(n):
                    if pens[yy, xx] != 15 and 0 <= sx + xx < 384 and (0 <= sy + yy < 224):
                        if tuple(screen[sy + yy, sx + xx]) != color(cell['attr'], int(pens[yy, xx])):
                            sys.exit(f"title_ex measure: {key} cell {cell['map_byte']} differs from the screen")
                        checked += 1
        result['regions'][key] = dict(machine=name, reference_frame=ref, layer=layer, scroll=[sx_, sy_], palette=0, s3_palette0=[f'{word(palbase + 2 * i):04X}' for i in range(16)], cells=sorted(cells.values(), key=lambda c: c['map_byte']))
        print(key, layer, len(cells), 'cells,', checked, 'stock pixels checked against the screen')
    (ASSETS / 'cells.json').write_text(json.dumps(result, indent=1) + '\n')
    return 0
BOOT_FRAME = 90

def boot_screen(a, binary, key, work, stock_dir):
    """The boot test screen: the same pixels lit as stock, nothing else changed, and the text in the"""
    import os
    import subprocess
    from PIL import Image
    import build_ex as BX
    want = {hb_rgb(w) for w in BX.BOOT_PALETTE[STOCK_SET[key]].values()}
    shots = {}
    for kind, name, rompath in (('ex', EX_SET[key], a.ex_sets), ('stock', STOCK_SET[key], stock_dir)):
        out = work / f'{key}_boot_{kind}'
        out.mkdir()
        (out / 'gate.lua').write_text(GATE_LUA)
        env = dict(os.environ, SDL_VIDEODRIVER='dummy', SDL_AUDIODRIVER='dummy', OUT=str(out), FRAMES=str(BOOT_FRAME), LAST=str(BOOT_FRAME + 2), COIN='99999')
        r = subprocess.run([binary, name, '-rompath', str(rompath), '-nothrottle', '-video', 'none', '-sound', 'none', '-seconds_to_run', '30', '-skip_gameinfo', '-noautosave', '-cfg_directory', str(out / 'cfg'), '-nvram_directory', str(out / 'nv'), '-snapshot_directory', str(out), '-autoboot_script', str(out / 'gate.lua')], env=env, cwd=out, capture_output=True, text=True, timeout=600)
        (out / 'mame.log').write_text(r.stdout + r.stderr)
        shots[kind] = np.asarray(Image.open(out / f's_{BOOT_FRAME:05d}.png').convert('RGB')).astype(int)
    st, ex = (shots['stock'], shots['ex'])
    text = st.any(-1)
    colors = {kind: {tuple((int(v) for v in c)) for c in img[text]} for kind, img in shots.items()}
    res = dict(text_pixels=int(text.sum()), changed_outside_text=int((ex != st).any(-1)[~text].sum()), ex_text_colors=sorted(colors['ex']), stock_text_colors=sorted(colors['stock']))
    ok = res['text_pixels'] > 0 and res['changed_outside_text'] == 0 and (colors['ex'] <= want | {(0, 0, 0)})
    control = not colors['stock'] <= want | {(0, 0, 0)}
    return dict(**res, control_fails=control, passed=ok and control)

def coin_screen(a, binary, key, work, stock_dir):
    """The coin screen shows the finished title (the EX title's end-state frame) everywhere outside the"""
    import os
    import subprocess
    from PIL import Image
    import build_ex as BX
    machine = STOCK_SET[key]
    rows = {r for r in BX.COIN_ROWS[machine].values()} | {23, 24, 26}
    band = np.zeros(224, bool)
    for r in rows:
        band[8 * r:8 * r + 8] = True
    frames = [COIN_REF[key]] + [COIN[key] + d for d in COIN_SHOTS]
    res = {}
    for kind, name, rompath in (('ex', EX_SET[key], a.ex_sets), ('stock', STOCK_SET[key], stock_dir)):
        out = work / f'{key}_coin_{kind}'
        out.mkdir()
        (out / 'gate.lua').write_text(GATE_LUA)
        env = dict(os.environ, SDL_VIDEODRIVER='dummy', SDL_AUDIODRIVER='dummy', OUT=str(out), FRAMES=','.join(map(str, frames)), LAST=str(frames[-1] + 2), COIN=str(COIN[key]))
        r = subprocess.run([binary, name, '-rompath', str(rompath), '-nothrottle', '-video', 'none', '-sound', 'none', '-seconds_to_run', '30', '-skip_gameinfo', '-noautosave', '-cfg_directory', str(out / 'cfg'), '-nvram_directory', str(out / 'nv'), '-snapshot_directory', str(out), '-autoboot_script', str(out / 'gate.lua')], env=env, cwd=out, capture_output=True, text=True, timeout=600)
        (out / 'mame.log').write_text(r.stdout + r.stderr)
        ref = np.asarray(Image.open(out / f's_{frames[0]:05d}.png').convert('RGB')).astype(int)
        words = np.frombuffer((out / f'p_{frames[0]:05d}.bin').read_bytes(), '>u2')
        logo = {hb_rgb(int(w)) for w in words} | {(0, 0, 0)}
        sprite = np.array([[tuple(c) not in logo for c in row] for row in ref])
        bad, text = ([], 0)
        for f in frames[1:]:
            img = np.asarray(Image.open(out / f's_{f:05d}.png').convert('RGB')).astype(int)
            shown_logo = np.array([[tuple(c) in logo for c in row] for row in img])
            diff = (img != ref).any(-1) & ~(sprite & shown_logo)
            bad.append(int(diff[~band].sum()))
            text += int((img[band].sum(-1) > 0).sum())
        res[kind] = dict(pixels_off_the_title_outside_text_rows=bad, text_row_pixels_lit=text)
    ok = all((v == 0 for v in res['ex']['pixels_off_the_title_outside_text_rows'])) and res['ex']['text_row_pixels_lit'] > 0
    control = any((v > 0 for v in res['stock']['pixels_off_the_title_outside_text_rows']))
    return dict(**res, rows=sorted(rows), control_fails=control, passed=ok and control)

def attract_run(binary, name, rompath, out, frames, ref=0):
    """Boot a set's attract, focus-safe, with a screenshot every frame of frames (and palette 0 there),"""
    import os
    import subprocess
    out.mkdir()
    (out / 'gate.lua').write_text(GATE_LUA)
    env = dict(os.environ, SDL_VIDEODRIVER='dummy', SDL_AUDIODRIVER='dummy', OUT=str(out), FRAMES=','.join(map(str, frames)), LAST=str(frames[-1] + 2), REF=str(ref))
    r = subprocess.run([binary, name, '-rompath', str(rompath), '-nothrottle', '-video', 'none', '-sound', 'none', '-seconds_to_run', '30', '-skip_gameinfo', '-noautosave', '-cfg_directory', str(out / 'cfg'), '-nvram_directory', str(out / 'nv'), '-snapshot_directory', str(out), '-autoboot_script', str(out / 'gate.lua')], env=env, cwd=out, capture_output=True, text=True, timeout=900)
    (out / 'mame.log').write_text(r.stdout + r.stderr)
    return out

def shot(out, f):
    from PIL import Image
    return np.asarray(Image.open(out / f's_{f:05d}.png').convert('RGB')).astype(int)

def logo_pens(out, ref, gfx):
    """{pen: (ys, xs)}: the stock logo's screen pixels (SCROLL3, palette 0) by pen, from graphics RAM at"""
    ram = np.frombuffer((out / 'gfxram.bin').read_bytes(), '>u2')
    regs = [int(v, 16) for v in (out / 'cps_a.txt').read_text().split()]
    screen = shot(out, ref)

    def word(addr):
        return int(ram[(addr - 9437184) // 2])
    base, sx_, sy_ = (regs[3] * 256, regs[10], regs[11])
    pal = [hb_rgb(word(regs[5] * 256 + 3 * 1024 + 2 * p)) for p in range(16)]
    tiles, pix = ({}, {})
    for y in range(SCREEN[1]):
        my = (y + 16 + sy_) % 2048
        for x in range(SCREEN[0]):
            mx = (x + 64 + sx_) % 2048
            col, rw = (mx // 32, my // 32)
            addr = base + 4 * (rw & 7 | col << 3 | (rw & 56) << 6)
            if word(addr + 2) & 31:
                continue
            code = word(addr)
            if code not in tiles:
                tiles[code] = stock_tile(gfx, code)
            pen = int(tiles[code][my % 32, mx % 32])
            if pen != 15 and tuple(screen[y, x]) == pal[pen]:
                pix.setdefault(pen, []).append((y, x))
    return {p: tuple(np.array(v).T) for p, v in pix.items()}

def pen_colors(img, pix):
    """{pen: the color most of its pixels show} (a sprite may cross a few of them)."""
    out = {}
    for p, (ys, xs) in pix.items():
        cols, counts = np.unique(img[ys, xs], axis=0, return_counts=True)
        out[p] = tuple((int(v) for v in cols[counts.argmax()]))
    return out
BLACK = (0, 0, 0)

def pen_spans(colors, frames, ref):
    """{pen: (first, full)} for each pen not black at ref: the frame from which it shows (not black)"""
    upto = [f for f in frames if f <= ref]
    out = {}
    for p, end in colors[ref].items():
        if end == BLACK:
            continue
        on = ref
        for f in reversed(upto):
            if colors[f][p] == BLACK:
                break
            on = f
        done = ref
        for f in reversed([g for g in upto if g >= on]):
            if colors[f][p] != end:
                break
            done = f
        out[p] = (on, done)
    return out

def logo_stages(colors, frames, ref):
    """The stock logo's stages: its pens grouped by the frame from which they show (not black) through"""
    stages = {}
    for p, (on, done) in sorted(pen_spans(colors, frames, ref).items()):
        s = stages.setdefault(on, dict(first=on, pens=[], full=on))
        s['pens'].append(p)
        s['full'] = max(s['full'], done)
    return [stages[k] for k in sorted(stages)]

def brightness_step(color, word):
    """The fade step k (0-15) at which a palette word at brightness 0 shows color: None when no step does"""
    hit = [k for k in range(16) if hb_rgb(word + (k << 12)) == color]
    return hit[0] if len(hit) == 1 else tuple(hit) or None

def mark_check(frames, colors, ref, judged, shots, mark_pix, base=None):
    """The mark's pixels against the stock logo's colors, frame by frame. colors: {frame: {pen: stock"""
    stages = logo_stages(colors, frames, ref)
    res = dict(logo_stages=stages)
    missing = sorted((p for p in mark_pix if colors[ref].get(p, BLACK) == BLACK))
    if missing:
        return dict(res, passed=False, why=f'mark pens {missing} have no lit logo pixels to compare with')
    if ref not in judged:
        return dict(res, passed=False, why=f'the reference frame {ref} is not judged')
    ex = {f: shot(shots, f) for f in judged}
    wrong, wrong_frames = (0, [])
    for f in judged:
        n = sum((int((ex[f][ys, xs] != colors[f][p]).any(-1).sum()) for p, (ys, xs) in mark_pix.items()))
        wrong += n
        if n:
            wrong_frames.append(f)
    logo = pen_spans(colors, judged, ref)
    mark_colors = {f: pen_colors(ex[f], mark_pix) for f in judged}
    mark = pen_spans(mark_colors, judged, judged[-1])
    in_step = all((mark.get(p) == logo[p] for p in mark_pix))

    def span(spans, pens):
        got = [spans.get(p) for p in pens]
        return None if None in got else [min((g[0] for g in got)), max((g[1] for g in got))]
    mark_stages, steps_ok = ([], True)
    for s in stages:
        pens = [p for p in s['pens'] if p in mark_pix]
        if not pens:
            continue
        ms = dict(pens=pens, logo=span(logo, pens), mark=span(mark, pens))
        if base:
            lo = min((x[0] for x in (ms['logo'], ms['mark']) if x)) - 1
            hi = max((x[1] for x in (ms['logo'], ms['mark']) if x)) + 1
            rows = []
            for f in (g for g in judged if lo <= g <= hi):
                one = []
                for cs in (colors[f], mark_colors[f]):
                    st = {brightness_step(cs[p], base[p]) for p in pens}
                    one.append(st.pop() if len(st) == 1 else sorted(st, key=str))
                rows.append([f] + one)
                steps_ok &= one[0] == one[1] and (one[0] is None or isinstance(one[0], int))
            ms['steps'] = rows
        mark_stages.append(ms)
    res.update(mark_stages=mark_stages, frames=len(judged), mark_pixels_wrong=wrong, frames_wrong=wrong_frames[:20], spans_as_the_logo=in_step)
    if base:
        res['steps_as_the_logo'] = steps_ok
    res['passed'] = wrong == 0 and in_step and steps_ok and (len(judged) > 0)
    return res

def review_strip(path, runs, frames, crop, cols=6):
    """Blocks of cols frames; in each block a row per run [(label, shots dir)]; each cell the crop, at 2x."""
    from PIL import Image, ImageDraw
    x0, y0, x1, y1 = crop
    w, h = (2 * (x1 - x0), 2 * (y1 - y0))
    blocks = [frames[i:i + cols] for i in range(0, len(frames), cols)]
    bh = len(runs) * (h + 18) + 12
    sheet = Image.new('RGB', (70 + cols * (w + 4), len(blocks) * bh), (40, 40, 40))
    d = ImageDraw.Draw(sheet)
    for b, block in enumerate(blocks):
        for r, (label, out) in enumerate(runs):
            top = b * bh + r * (h + 18) + 16
            d.text((4, top + h // 2), label, fill=(255, 255, 255))
            for c, f in enumerate(block):
                im = Image.open(out / f's_{f:05d}.png').convert('RGB').crop(crop).resize((w, h), Image.NEAREST)
                x = 70 + c * (w + 4)
                sheet.paste(im, (x, top))
                d.text((x + 2, top - 14), f'frame {f}', fill=(255, 255, 0))
    sheet.save(path)
REVIEW_CROP = {'jp': (180, 64, 384, 176), 'us': (190, 64, 384, 176)}

def gate(a):
    work = a.workdir.resolve()
    work.mkdir(parents=True, exist_ok=False)
    binary = json.loads((a.runtime / 'runtime.json').read_text())['binary']
    import mapper_testkit as K
    stock_dir = stage_stock(a, work)
    gfx = stock_gfx(K.pool([a.rom_dir.resolve() / 'striderua']))
    report, ok = ({}, True)
    for key in ('jp', 'us'):
        layout = json.loads((ASSETS / 'layout.json').read_text())[key]
        grid = [l.rstrip('\n') for l in (ASSETS / f'{key}_pixels.txt').read_text().splitlines()]
        cells = json.loads((ASSETS / 'cells.json').read_text())['regions'][key]
        pal = [mame_rgb(int(w, 16)) for w in cells['s3_palette0']]
        pens = [next((p for p in range(15) if pal[p] == tuple(c))) for c in layout['palette']]
        x0, y0 = layout['position']
        frames = list(GATE_FRAMES[key])
        ref = PEN_REF[key]
        runs = [('stock', STOCK_SET[key], stock_dir), ('ex', EX_SET[key], a.ex_sets)]
        if a.control_sets and key in CONTROL_REGIONS:
            runs.append(('control', EX_SET[key], a.control_sets))
        shots = {kind: attract_run(binary, name, rompath, work / f'{key}_{kind}', frames, ref if kind == 'stock' else 0) for kind, name, rompath in runs}
        mask = np.zeros((SCREEN[1], SCREEN[0]), bool)
        mark_pix = {}
        for gy, row in enumerate(grid):
            for gx, ch in enumerate(row):
                if ch != '.' and on_screen(x0 + gx, y0 + gy):
                    mask[y0 + gy, x0 + gx] = True
                    mark_pix.setdefault(pens[int(ch)], []).append((y0 + gy, x0 + gx))
        mark_pix = {p: tuple(np.array(v).T) for p, v in mark_pix.items()}
        pix = logo_pens(shots['stock'], ref, gfx)
        colors = {f: pen_colors(shot(shots['stock'], f), pix) for f in frames}
        slice_start, sh = (None, None)
        if key == 'us':
            sh = {int(r[0]): [int(v) for v in r[1:]] for r in (l.split('\t') for l in (shots['ex'] / 'shadows.tsv').read_text().splitlines())}
            slice_start = next((f for f in sorted(sh) if f > 300 and sh[f][0] != 0), None)
        outside, judged, skipped = (0, [], [])
        for f in frames:
            if slice_start is not None and f >= slice_start - 1:
                continue
            st, ex = (shot(shots['stock'], f), shot(shots['ex'], f))
            outside += int((ex != st).any(-1)[~mask].sum())
            if st[mask].any():
                skipped.append(f)
                continue
            judged.append(f)
        base = None
        if key == 'us':
            import respawn_fix as RF
            files = {q.name: q.read_bytes() for q in (a.rom_dir.resolve() / 'striderua').iterdir() if q.is_file()}
            program = RF.compose(files, RF.SETS['striderua'])
            base = {p: int.from_bytes(program[LOGO_COLORS + 2 * p:LOGO_COLORS + 2 * p + 2], 'big') for p in range(16)}
        marks = {kind: mark_check(frames, colors, ref, judged, shots[kind], mark_pix, base) for kind in shots}
        controls = {kind: not m['passed'] for kind, m in marks.items() if kind != 'ex'}
        coin = coin_screen(a, binary, key, work, stock_dir)
        boot = boot_screen(a, binary, key, work, stock_dir)
        sl = usa_slice_check(shots['ex'], slice_start, sh, frames) if key == 'us' else dict(passed=True)
        spans = [[s['first'], s['full']] for s in marks['ex']['logo_stages']]
        for m in marks.values():
            spans += [ms['mark'] for ms in m.get('mark_stages', []) if ms.get('mark')]
        picks = set()
        for first, full in spans:
            picks |= {first - 1, first, first + 1, first + 4, first + 8, full, full + 1}
        picks = sorted((f for f in picks if f in frames and (slice_start is None or f < slice_start - 1)))
        order = [('stock', 'stock')] + [(k, k) for k in ('control', 'ex') if k in shots]
        review_strip(work / f'review_{key}.png', [(lab, shots[k]) for lab, k in order], picks, REVIEW_CROP[key])
        r = dict(slice=sl, frames=len(judged), frames_with_something_over_the_mark=skipped, pixels_differing_outside_mark=outside, mark=marks['ex'], controls={kind: dict(fails=controls[kind], **{k: v for k, v in marks[kind].items() if k not in ('logo_stages',)}) for kind in controls}, coin_screen=coin, boot_screen=boot, passed=len(judged) > 0 and outside == 0 and marks['ex']['passed'] and all(controls.values()) and coin['passed'] and sl['passed'] and boot['passed'])
        report[key] = r
        ok &= r['passed']
        print(key, json.dumps(r, default=str)[:4000])
    (work / 'report.json').write_text(json.dumps(report, indent=1, default=str) + '\n')
    print('PASS' if ok else 'FAIL')
    return 0 if ok else 1

def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('command', nargs='?', choices=['gate', 'measure'])
    p.add_argument('--self-test', action='store_true')
    p.add_argument('--rom-dir', type=Path, required=True)
    p.add_argument('--runtime', type=Path)
    p.add_argument('--ex-sets', type=Path)
    p.add_argument('--control-sets', type=Path, help="gate: a build's HBMAME sets whose USA mark does not fade in with the logo (it must fail)")
    p.add_argument('--workdir', type=Path)
    a = p.parse_args()
    if a.command == 'gate':
        return gate(a)
    if a.command == 'measure':
        return measure(a)
    return self_test(a.rom_dir.resolve())
if __name__ == '__main__':
    sys.exit(main())
