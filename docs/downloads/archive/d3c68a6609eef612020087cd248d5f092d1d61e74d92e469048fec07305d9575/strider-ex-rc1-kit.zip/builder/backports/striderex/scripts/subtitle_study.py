"""Strider EX subtitle study (research; nothing here is approved text)."""
import argparse
import json
import sys
import textwrap
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path
import numpy as np
sys.path.insert(0, str(Path(__file__).resolve().parent))
import cinematic_convert as C
import cps1_gfx as G
import pce_vdc as P
HERE = Path(__file__).resolve().parents[1]
M = HERE / 'manifests'
CROP = 16
OBJ_BASE = 33792
STOP_BEFORE_SHOT = {'prologue': 10}
TRACK_OF = {}
ONSET_THRESHOLD = 256
ASCII_FONT = {32: ' ', 33: '-', 40: '?', 41: '!', 42: '&', 43: '.', 44: ',', 58: '-', 59: '+', 64: '%'}
ASCII_FONT.update({48 + i: str(i) for i in range(10)})
ASCII_FONT.update({65 + i: chr(65 + i) for i in range(26)})
JA_ROWS = ['との言シア帝都をリー親玉者なし。', '「」\x01べこへれ馬鹿奴ロ戦艦バルグ', 'め勝ったつもりかきさまどあお方敵', 'ではいわ!ストライダ生てユ大陸ら', '出ん承知余に逆うねよろ力思るが全', '世界足元、\x02―――空中ぎ我々だそ', '玩具必要太古怪物〝第3月〟来軍事', '科学手入え飛竜ひざづ市天打ちげ球', '上焼殺く新創命み死神子']
JA_FONT = {}
for _r, _s in enumerate(JA_ROWS):
    for _k, _ch in enumerate(_s):
        JA_FONT.setdefault(_ch, 13856 + 16 * _r + _k)
JA_EQUIV = {'！': '!', '３': '3', '3': '3', '、': '、', '。': '。'}
S3_FREE = (15565, 16351)

def load_text():
    review = json.loads((M / 'pce_cinematic_text_review.json').read_text())
    asr = json.loads((M / 'pce_cinematic_transcripts.json').read_text())
    seg = {(t['track'], i): s for t in asr['tracks'] for i, s in enumerate(t['segments'])}
    out = []
    for ln in review['lines']:
        tr, k = (int(v) for v in ln['id'][2:].split('.'))
        s = seg[tr, k]
        out.append(dict(id=ln['id'], track=tr, start=s['start'], end=s['end'], speaker=ln['speaker'], ja=ln['ja_reading'] or '', asr=s['text'], en=ln['en_draft'] or ''))
    return out

def catalog(census):
    cat = json.loads((census / 'catalog/catalog.json').read_text())
    return {c['track']: c for c in cat['cinematics']}

def track_lead(disc_dir, track):
    """Seconds from INDEX 01 (start of the track BIN) to its first sample above the"""
    if disc_dir is None:
        return None
    hits = sorted(disc_dir.glob(f'*(Track {track:02d}).bin'))
    if not hits:
        return None
    a = np.frombuffer(hits[0].read_bytes()[:44100 * 4 * 10], '<i2').reshape(-1, 2)
    loud = np.nonzero(np.abs(a).max(1) > ONSET_THRESHOLD)[0]
    return float(loud[0]) / 44100 if len(loud) else None

def frames_of(census, c):
    run = census / c['run']
    t0 = c['cd_request_time']
    t1 = t0 + c['track_seconds']
    if c['id'] in STOP_BEFORE_SHOT:
        t1 = t0 + next((x['start_t'] for x in c['shots'] if x['shot'] == STOP_BEFORE_SHOT[c['id']])) - 0.001
    return (run, C.frames_for(run, t0, t1))

def leading(mask):
    return int(np.argmin(mask)) if not mask.all() else len(mask)

def measure_cinematic(job):
    census, c, lead = job
    run, frames = frames_of(census, c)
    idx = P.read_index(run)
    writes = P.read_writes(run)
    zero = c['cd_request_time'] + c['audio_onset_after_request'] - (lead or 0.0)
    cv = C.Converter(CROP, OBJ_BASE)
    rows = []
    states = []
    for f in frames:
        d = P.load(run / f'pce_{f:05d}_scene.vdc')
        w = writes.get(f)
        ref = C.reference(d, w, CROP)[:, C.X_PICTURE:C.X_PICTURE + 256]
        black = ref == C.BLACK
        lum = ((ref >> 8 & 15) * 3 + (ref >> 4 & 15) * 6 + (ref & 15)) / 150.0
        brow, bcol = (black.all(1), black.all(0))
        st = cv.frame_state(d, w)
        states.append(st)
        rows.append(dict(frame=f, t=float(idx[f]['time']) - zero, top=leading(brow), bottom=leading(brow[::-1]), left=leading(bcol), right=leading(bcol[::-1]), lum_bottom32=float(lum[-32:].mean()), lum_bottom32_max=float(lum[-32:].max()), s2=st['s2'] is not None, s1=st['s1'] is not None, cover=bool(st['cover']), s1_scroll=(st['s1']['x'], st['s1']['y']) if st['s1'] else None))
    cv.allocate_sprites(states)
    for r, st in zip(rows, states):
        r['sprites'] = len(st['sprites'])
    pal_s3 = sorted({int(i) for st in states for i in np.nonzero(cv.palette(st)[C.PAL_S3:C.PAL_S3 + 512])[0]})
    return dict(id=c['id'], track=c['track'], zero=zero, lead=lead, rows=rows, s3_palette_entries_set=pal_s3)

def segment_stats(rows, start, end):
    w = [r for r in rows if start <= r['t'] <= end]
    if not w:
        return None
    sc = {r['s1_scroll'] for r in w if r['s1_scroll'] is not None}
    return dict(frames=len(w), free_bottom=min((r['bottom'] for r in w)), free_top=min((r['top'] for r in w)), free_left=min((r['left'] for r in w)), free_right=min((r['right'] for r in w)), frames_bottom_ge20=sum((r['bottom'] >= 20 for r in w)), frames_bottom_ge32=sum((r['bottom'] >= 32 for r in w)), lum_bottom32_mean=round(float(np.mean([r['lum_bottom32'] for r in w])), 3), lum_bottom32_max=round(max((r['lum_bottom32_max'] for r in w)), 3), sprites_max=max((r['sprites'] for r in w)), cover_frames=sum((r['cover'] for r in w)), s2_frames=sum((r['s2'] for r in w)), s1_scrolls=len(sc))

def en_text(s):
    return s.upper().replace('…', '...').replace('—', '-').replace('–', '-')

def font_report(lines):
    have = set(ASCII_FONT.values())
    en_chars = sorted({ch for ln in lines for ch in en_text(ln['en'])})
    missing_en = {ch: [ln['id'] for ln in lines if ch in en_text(ln['en'])] for ch in en_chars if ch not in have}
    ja_chars = sorted({ch for ln in lines for ch in ln['ja'] if not ch.isspace()})
    ja_have = [ch for ch in ja_chars if JA_EQUIV.get(ch, ch) in JA_FONT]
    ja_missing = [ch for ch in ja_chars if JA_EQUIV.get(ch, ch) not in JA_FONT]
    per_line = []
    for ln in lines:
        if ln['ja']:
            cs = [ch for ch in ln['ja'] if not ch.isspace()]
            ok = sum((JA_EQUIV.get(ch, ch) in JA_FONT for ch in cs))
            per_line.append((ln['id'], ok, len(cs)))
    return dict(en_chars=''.join(en_chars), en_missing=missing_en, ja_distinct=len(ja_chars), ja_in_arcade_font=len(ja_have), ja_have=''.join(ja_have), ja_missing=''.join(ja_missing), ja_lines_fully_covered=sum((ok == n for _, ok, n in per_line)), ja_lines=len(per_line), arcade_ja_glyphs=len(JA_FONT))

class Fonts:

    def __init__(self, gfx, ja_ttf=None, ja_size=12):
        self.gfx = gfx
        self.ja_ttf, self.ja_size = (ja_ttf, ja_size)
        self.cache = {}

    def en(self, ch):
        """8x8 pens (15 transparent) of an English character, or None."""
        code = next((b for b, c in ASCII_FONT.items() if c == ch), None)
        if code is None:
            return EXTRA_EN.get(ch)
        return G.get_tile(self.gfx, 2097152 + 64 * (28672 + code), 8, 0)

    def ja(self, ch):
        """16x16 pens of a Japanese character: the arcade glyph, else the fallback"""
        ch = JA_EQUIV.get(ch, ch)
        if ch in JA_FONT:
            return (G.get_tile(self.gfx, 128 * JA_FONT[ch], 16), 'arcade')
        if self.ja_ttf is None:
            return (None, 'missing')
        if ch not in self.cache:
            from PIL import Image, ImageDraw, ImageFont
            font = ImageFont.truetype(str(self.ja_ttf), self.ja_size)
            im = Image.new('L', (16, 16), 0)
            ImageDraw.Draw(im).text((8, 9), ch, fill=255, font=font, anchor='mm')
            a = np.array(im) >= 128
            pens = np.full((16, 16), 15)
            pens[a] = 3
            edge = np.zeros_like(a)
            edge[1:, 1:] = a[:-1, :-1]
            pens[edge & ~a] = 0
            self.cache[ch] = pens
        return (self.cache[ch], 'fallback')

def _glyph(rows):
    m = {'.': 15, '1': 1, '0': 0}
    return np.array([[m[c] for c in r] for r in rows])
EXTRA_EN = {"'": _glyph(['...11...', '...10...', '..10....', '........', '........', '........', '........', '........']), ':': _glyph(['........', '..11....', '..10....', '........', '........', '..11....', '..10....', '........']), '"': _glyph(['.11.11..', '.10.10..', '10.10...', '........', '........', '........', '........', '........'])}

def wrap(text, width):
    return textwrap.wrap(text, width) or ['']

def caption_band(lines, kind, fonts, band_w=384, x0=None):
    """Caption pens (15 transparent) in a band 32 lines tall, band_w wide,"""
    band = np.full((32, band_w), 15)
    src = []
    adv, ys = (8, (6, 18)) if kind == 'en' else (16, (0, 16))
    if len(lines) == 1:
        ys = (12,) if kind == 'en' else (8,)
    for y, ln in zip(ys, lines):
        w = adv * len(ln)
        x = (band_w - w) // 2 if x0 is None else x0
        for ch in ln:
            if ch != ' ':
                if kind == 'en':
                    g = fonts.en(ch)
                    src.append('arcade' if ch in ASCII_FONT.values() else 'draft' if g is not None else 'missing')
                else:
                    g, s = fonts.ja(ch)
                    src.append(s)
                if g is not None:
                    n = g.shape[0]
                    sub = band[y:y + n, x:x + n]
                    sub[g != 15] = g[g != 15]
            x += adv
    return (band, src)

def layout(ln, kind, width_px):
    if kind == 'en':
        return wrap(en_text(ln['en']), width_px // 8)
    text = ln['ja']
    per = width_px // 16
    return [text[i:i + per] for i in range(0, len(text), per)] or ['']

def tiles_of(band, size, x_offset=0, bars=()):
    """Distinct non-empty size x size tiles of a band laid on a grid whose column"""
    out = []
    for c in range(band.shape[1] // size):
        t = band[:, c * size:(c + 1) * size]
        for r in range(band.shape[0] // size):
            cell = t[r * size:(r + 1) * size]
            if (cell != 15).any():
                if c in bars:
                    cell = np.where(cell == 15, 14, cell)
                out.append(cell.astype(np.uint8).tobytes())
    return out

def budget(lines, fonts):
    res = {}
    for kind, langs in (('en', 'English'), ('ja', 'Japanese')):
        for width_name, width_px in (('picture', 256 - 16), ('screen', 384 - 16)):
            s3, spr, n_lines, overflow, entries = ([], [], 0, 0, 0)
            sources = {}
            for ln in lines:
                if not (ln['en'] if kind == 'en' else ln['ja']):
                    continue
                ls = layout(ln, kind, width_px)
                n_lines += 1
                if len(ls) > 2:
                    overflow += 1
                for i in range(0, len(ls), 2):
                    band, src = caption_band(ls[i:i + 2], kind, fonts)
                    for s in src:
                        sources[s] = sources.get(s, 0) + 1
                    s3 += tiles_of(band, 32, bars=(0, 1, 10, 11))
                    if width_name == 'picture':
                        cells = tiles_of(band[:, 64:320], 16)
                        spr += cells
                        entries = max(entries, len(cells))
            res[f'{kind}_{width_name}'] = dict(captions=n_lines, captions_over_two_lines=overflow, scroll3_tiles=len(s3), scroll3_distinct=len(set(s3)), sprite_cells=len(spr) if spr else None, sprite_cells_distinct=len(set(spr)) if spr else None, sprite_entries_max_as_cells=entries if spr else None, glyph_sources=sources)
    chars = {ch for ln in lines for ch in en_text(ln['en']) if ch != ' '}
    res['scroll1_glyph_codes'] = dict(en_distinct_chars=len(chars), ja_distinct_chars=len({c for ln in lines for c in ln['ja']}), ja_codes_as_8x8=4 * len({c for ln in lines for c in ln['ja']}))
    return res

def stock_gfx(rom_dir):
    import mapper_testkit as K
    import title_ex as TX
    return TX.stock_gfx(K.pool([rom_dir.resolve()]))

def cmd_measure(a):
    cat = catalog(a.census)
    lines = load_text()
    jobs = [(a.census, cat[t], track_lead(a.disc_dir, t)) for t in sorted(cat)]
    with ProcessPoolExecutor(a.jobs) as ex:
        per = {r['track']: r for r in ex.map(measure_cinematic, jobs)}
    segs = []
    for ln in lines:
        st = segment_stats(per[ln['track']]['rows'], ln['start'], ln['end'])
        segs.append(dict(id=ln['id'], cinematic=cat[ln['track']]['id'], start=ln['start'], end=ln['end'], **st or dict(frames=0)))
    cin = {}
    for t, r in sorted(per.items()):
        rows = r['rows']
        cin[r['id']] = dict(track=t, frames=len(rows), index01_capture_time=round(r['zero'], 3), track_lead_s=r['lead'], sprites_max=max((x['sprites'] for x in rows)), sprites_p99=int(np.percentile([x['sprites'] for x in rows], 99)), free_bottom_min=min((x['bottom'] for x in rows)), free_top_min=min((x['top'] for x in rows)), cover_frames=sum((x['cover'] for x in rows)), s2_frames=sum((x['s2'] for x in rows)), s3_palette_entries_set=r['s3_palette_entries_set'])
    gfx = stock_gfx(a.rom_dir)
    fonts = Fonts(gfx, a.ja_font)
    report = dict(status='RESEARCH; text is DRAFT (manifests/pce_cinematic_text_review.json, unapproved)', cinematics=cin, segments=segs, fonts=font_report(lines), budget=budget(lines, fonts), scroll3_free_codes=[f'{S3_FREE[0]:#06x}', f'{S3_FREE[1]:#06x}', S3_FREE[1] - S3_FREE[0] + 1])
    a.out.mkdir(parents=True, exist_ok=True)
    (a.out / 'subtitle_study.json').write_text(json.dumps(report, indent=1, ensure_ascii=False) + '\n')
    (a.out / 'frames.json').write_text(json.dumps({r['id']: r['rows'] for r in per.values()}) + '\n')
    print(json.dumps(dict(cinematics=cin, fonts=report['fonts'], budget=report['budget']), indent=1, ensure_ascii=False))
    print('segment  cinematic            frames bottom top left right sprmax cover s2')
    for s in segs:
        if s['frames']:
            print(f"{s['id']:8} {s['cinematic']:20} {s['frames']:6} {s['free_bottom']:6} {s['free_top']:3} {s['free_left']:4} {s['free_right']:5} {s['sprites_max']:6} {s['cover_frames']:5} {s['s2_frames']:3}")
        else:
            print(f"{s['id']:8} {s['cinematic']:20} no frames in window")
    return 0

def cps_rgb(w):
    b = 15 + (w >> 12 << 1)
    return [(w >> s & 15) * 17 * b // 45 for s in (8, 4, 0)]
EN_PAL = {1: 65535, 0: 61713, 14: 61440}
JA_PAL = {1: 65262, 2: 64716, 3: 64170, 4: 63624, 5: 63078, 0: 61713, 14: 61440}

def model_frames(census, c, wanted):
    """CPS-1 model renders (384x224 RGB) of the listed capture frames."""
    run, frames = frames_of(census, c)
    cv, stream, _ = C.convert(run, frames, CROP, C.Converter(CROP, OBJ_BASE))
    model = C.CpsModel(cv.region)
    pos = 0
    for _ in range(cv.preroll):
        pos = model.run(stream, pos)
    out = {}
    for f in frames:
        pos = model.run(stream, pos)
        if f in wanted:
            out[f] = model.pal[model.render()].copy()
    return out

def overlay(rgb, band, y, pal, plate=False):
    img = rgb.copy()
    if plate:
        yy, xx = np.mgrid[0:32, 0:384]
        sel = (yy + xx) % 2 == 0
        reg = img[y:y + 32]
        reg[sel] = 0
    m = band != 15
    for pen, w in pal.items():
        sel = band == pen
        img[y:y + 32][sel & m] = cps_rgb(w)
    return img

def cmd_mockup(a):
    from PIL import Image
    cat = catalog(a.census)
    by_id = {c['id']: c for c in cat.values()}
    lines = {ln['id']: ln for ln in load_text()}
    gfx = stock_gfx(a.rom_dir)
    fonts = Fonts(gfx, a.ja_font)
    plan = [('prologue', 'tr21.1'), ('brief_siberia', 'tr24.4')]
    a.out.mkdir(parents=True, exist_ok=True)
    cards = []
    for cid, lid in plan:
        c = by_id[cid]
        ln = lines[lid]
        lead = track_lead(a.disc_dir, c['track']) or 0.0
        zero = c['cd_request_time'] + c['audio_onset_after_request'] - lead
        run, frames = frames_of(a.census, c)
        idx = P.read_index(run)
        mid = (ln['start'] + ln['end']) / 2
        f = min(frames, key=lambda k: abs(float(idx[k]['time']) - zero - mid))
        rgb_words = model_frames(a.census, c, {f})[f]
        base = np.array([[cps_rgb(int(w)) for w in row] for row in rgb_words], np.uint8)
        variants = []
        for kind, pal in (('en', EN_PAL), ('ja', JA_PAL)):
            ls_pic = layout(ln, kind, 240)
            ls_scr = layout(ln, kind, 368)
            band_pic, _ = caption_band(ls_pic[:2], kind, fonts)
            band_scr, _ = caption_band(ls_scr[:2], kind, fonts)
            variants += [(kind, 'A bottom band over picture (SCROLL3, y 192-223)', overlay(base, band_pic, 192, pal)), (kind, 'B bottom band, full screen width incl. bars (SCROLL3)', overlay(base, band_scr, 192, pal)), (kind, 'C bottom band with dithered plate (SCROLL3)', overlay(base, band_scr, 192, pal, plate=True))]
        for kind, desc, img in variants:
            tag = desc.split()[0]
            name = f"{cid}_{lid.replace('.', '_')}_{kind}_{tag}"
            im = Image.fromarray(img.astype(np.uint8))
            im.save(a.out / f'{name}.png')
            im.resize((768, 448), Image.NEAREST).save(a.out / f'{name}_2x.png')
            cards.append(dict(name=name, cid=cid, lid=lid, kind=kind, desc=desc, frame=f, text=ln['en'] if kind == 'en' else ln['ja']))
    html = ['<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">', '<title>Strider EX subtitle mockups</title>', '<style>body{background:#16181d;color:#e6e8ec;font:14px/1.5 system-ui,sans-serif;margin:0;padding:16px}h1{font-size:20px}.g{display:grid;grid-template-columns:repeat(auto-fill,minmax(min(100%,780px),1fr));gap:20px}figure{margin:0}img{width:100%;max-width:768px;image-rendering:pixelated;display:block}figcaption{color:#a8adb7;font-size:13px}b{color:#e6e8ec}</style>', '<h1>Strider EX subtitle mockups (DRAFT text, not approved)</h1>', '<p>Converted CPS-1 frames (the cinematic model render, 384x224, shown 2x). English: arcade 8x8 font (SCROLL1 glyphs 0x7000+ASCII, re-cut as SCROLL3 32x32 tiles). Japanese: arcade 16x16 dialogue font (SCROLL2 0x3620-0x36AA); characters it lacks come from the fallback font, if one was given.</p><div class="g">']
    for k in cards:
        html.append(f'''<figure><img src="{k['name']}_2x.png" alt="{k['cid']} {k['lid']} {k['kind']}"><figcaption><b>{k['cid']} {k['lid']} ({k['kind']})</b>, capture frame {k['frame']}: {k['desc']}<br>{k['text']}</figcaption></figure>''')
    html.append('</div>')
    (a.out / 'index.html').write_text('\n'.join(html) + '\n')
    print(f'{len(cards)} mockups in {a.out}')
    return 0

def self_test():
    assert ASCII_FONT[65] == 'A' and ASCII_FONT[44] == ','
    assert JA_FONT['ス'] == 13909 and JA_FONT['「'] == 13872 and (JA_FONT['生'] == 13914)
    assert JA_FONT['子'] == 13994
    assert leading(np.array([True, True, False])) == 2 and leading(np.array([True])) == 1
    band, src = caption_band(['AB'], 'en', type('F', (), {'en': lambda s, c: np.zeros((8, 8), int)})())
    assert (band != 15).sum() == 128 and src == ['arcade', 'arcade']
    print('subtitle_study self-test passed')
    return 0

def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('--self-test', action='store_true')
    sub = p.add_subparsers(dest='cmd')
    for name in ('measure', 'mockup'):
        s = sub.add_parser(name)
        s.add_argument('--census', type=Path, required=True)
        s.add_argument('--rom-dir', type=Path, required=True, help='directory with the striderua graphics ROMs')
        s.add_argument('--disc-dir', type=Path, help='PCE track BINs, for the INDEX 01 lead-in')
        s.add_argument('--ja-font', type=Path, help='fallback Japanese font file (TTF/OTF/TTC) for missing glyphs')
        s.add_argument('--out', type=Path, required=True)
        s.add_argument('--jobs', type=int, default=5)
    a = p.parse_args()
    if a.self_test:
        return self_test()
    return {'measure': cmd_measure, 'mockup': cmd_mockup}[a.cmd](a)
if __name__ == '__main__':
    sys.exit(main())
