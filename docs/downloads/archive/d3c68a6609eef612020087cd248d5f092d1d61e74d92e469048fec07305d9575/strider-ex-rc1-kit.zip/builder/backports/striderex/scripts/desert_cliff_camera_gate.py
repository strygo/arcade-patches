"""Check desert wall descent and preserve the hardware-approved slope motion."""
import argparse
from concurrent.futures import ThreadPoolExecutor
from copy import deepcopy
import csv
import json
from pathlib import Path
import subprocess
import sys
import tempfile
from PIL import Image, ImageChops, ImageDraw
import desert_gate as G
import desert_smooth as S
import desert_cadence as C
import desert_cliff_camera as M
from boss_voice_gate import inventory, sha
SETS = {'striderua': 'striderus01', 'striderjr': 'striderjs01'}

def rows(path):
    with path.open() as f:
        return list(csv.DictReader(f, delimiter='\t'))

def plans():
    out = {}
    for case, end, inputs, shots in (('down', 1050, '450-1700:P1_JOYSTICK_RIGHT;1051-1650:P1_JOYSTICK_DOWN', '1100-1280@2'), ('stop_resume', 849, '450-1500:P1_JOYSTICK_RIGHT;850-970:P1_JOYSTICK_DOWN;1061-1250:P1_JOYSTICK_DOWN', '900-1100@4'), ('up', 1500, '450-1500:P1_JOYSTICK_RIGHT', '650-1500@50')):
        n = 1700
        out[case] = (n, dict(G.debug_env(5, 3, n, inputs=False), CLIMB='1', CLIMB_END=str(end), STREX_INPUTS=inputs, SHOTS=shots))
    for case, key in (('slope_s0', 's0'), ('slope_s2', 's2_turn'), ('stock', 'stock_stpetersburg_turn')):
        stage, area, n, inputs, warp = C.plans()[key]
        env = S.env_of(stage, area, n, inputs, warp)
        env['SHOTS'] = f'650-{n}@100'
        out[case] = (n, env)
    return out

def metric(motion, lo, hi):
    samples = [(a, b) for a, b in zip(motion, motion[1:]) if lo <= a['frame'] < hi]
    if len(samples) != hi - lo or any((a['st'] != 4 or b['st'] != 4 or b['hy'] - a['hy'] != -1 for a, b in samples)):
        raise ValueError('constant native one-pixel wall descent not observed')
    steps = [b['camy'] - a['camy'] for a, b in samples]
    return dict(frames=len(samples), stationary_camera_frames=steps.count(0), max_camera_step=max(map(abs, steps)), step_change_square=sum(((b - a) ** 2 for a, b in zip(steps, steps[1:]))) / (len(steps) - 1), step_counts={str(x): steps.count(x) for x in sorted(set(steps))})

def compare(case, old, new):
    a, b = [S.read_motion(p) for p in (old, new)]
    fa, fb = [G.read(p) for p in (old, new)]
    ca, cb = [rows(p / 'cadence.tsv') for p in (old, new)]
    if len(a) != len(b) or len(ca) != len(cb):
        raise ValueError('incomplete paired movement/drawing captures')
    physical = ('hx', 'hxf', 'hy', 'hyf', 'st', 'sub', 'kind', 'kind0', 'speed', 'face', 'follow', 'limits')
    if any((any((x[k] != y[k] for k in physical)) for x, y in zip(a, b))):
        raise ValueError('native player motion, physics or camera bounds changed')
    for x, y in zip(fa, fb):
        if any((x[k] != y[k] for k in ('sound', 'stage', 'area', 'mode', 'lives', 'active', 'layer'))):
            raise ValueError('game flow, audio or scene state changed')
    for x, y in zip(ca, cb):
        if any((x[k] != y[k] for k in ('frame', 'object_before', 'object_after', 'dy', 'edits'))):
            raise ValueError('live player/pose bytes or existing slope sprite correction changed')
        if y['object_before'] != y['object_after']:
            raise ValueError('drawing helper mutated player state')
    new_lag = [y['frame'] for x, y in zip(a, b) if y['frame'] >= 650 and y['gtask'] == 8 and (x['gtask'] != 8)]
    if new_lag:
        raise ValueError('added a game-task lag frame')
    result = dict(case=case, frames=len(b), physical_motion_and_game_clocks_exact=True, player_object_and_pose_snapshots_exact=len(cb), original_slope_sprite_correction_exact=True, added_lag_frames=0, passed=True)
    if case in ('down', 'stop_resume'):
        lo, hi = (1110, 1320) if case == 'down' else (915, 960)
        before, after = (metric(a, lo, hi), metric(b, lo, hi))
        if before['max_camera_step'] != 3 or not before['stationary_camera_frames']:
            raise ValueError('old hold/three-pixel camera stutter not reproduced')
        if after['max_camera_step'] != 1 or after['stationary_camera_frames'] or after['step_change_square'] != 0:
            raise ValueError('camera does not track the steady descent one pixel per frame')
        for x, y in zip(b, b[2:]):
            if 650 <= x['frame'] <= 1400 and (y['s3x'], y['s3y']) != (x['camx'] - 64 & 65535, 1792 - x['camy'] & 65535):
                raise ValueError('actual SCROLL3 registers lost the native camera pipeline')
        if case == 'stop_resume':
            stopped = [r for r in b if 980 <= r['frame'] <= 1060]
            if len({(r['hx'], r['hy'], r['st']) for r in stopped}) != 1:
                raise ValueError('player did not stop on the wall')
            if max((abs(y['camy'] - x['camy']) for x, y in zip(stopped, stopped[1:]))) > 1:
                raise ValueError('releasing Down reintroduced a camera lurch')
            metric(b, 1100, 1140)
            result['wall_stop_and_resume_smooth'] = True
        result.update(frame_range=[lo, hi], control=before, candidate=after, actual_scroll_register_pipeline_verified=True)
    else:
        slope = case.startswith('slope_')
        unaffected = {x['frame'] for x in a if not slope or x['st'] == 0}
        if slope and len([x for x in a if x['st'] == 0 and 2 <= x['kind'] <= 7]) < 100:
            raise ValueError('approved grounded slope was not exercised')
        ignored = {'sleep', 'wake', 's3line', 'objline'}
        if any((any((x[k] != y[k] for k in x if k not in ignored)) for x, y in zip(a, b) if x['frame'] in unaffected)):
            raise ValueError('approved slopes, upward climb or stock camera changed')
        if any((x['sprites'] != y['sprites'] for x, y in zip(rows(old / 'motion.tsv'), rows(new / 'motion.tsv')) if int(x['frame']) in unaffected)):
            raise ValueError('unaffected native sprite list changed')
        pictures = 0
        for p in new.glob('s_*.png'):
            if int(p.stem[2:]) not in unaffected:
                continue
            if ImageChops.difference(Image.open(p).convert('RGB'), Image.open(old / p.name).convert('RGB')).getbbox():
                raise ValueError('approved slope/upward-climb/stock picture changed')
            pictures += 1
        if pictures < 5:
            raise ValueError('unaffected visual samples missing')
        result.update(camera_motion_and_sprite_lists_exact=True, pictures_exact=pictures, compared_frames=len(unaffected), grounded_frames_only=slope)
    result['traces'] = {label: {n: sha((p / n).read_bytes()) for n in ('frames.tsv', 'motion.tsv', 'cadence.tsv')} for label, p in (('control', old), ('candidate', new))}
    return result

def main():
    p = argparse.ArgumentParser(description=__doc__)
    for name in ('control', 'build', 'runtime', 'hbmame', 'rom-dir', 'vasm', 'workdir', 'receipt'):
        p.add_argument('--' + name, type=Path, required=True)
    p.add_argument('--reuse', action='store_true')
    p.add_argument('--preview-out', type=Path)
    a = p.parse_args()
    M.audit(a.control, a.build)
    work = a.workdir.resolve()
    work.mkdir(parents=True, exist_ok=a.reuse)
    metas, files, sets = ({}, {}, {})
    rt = json.loads((a.runtime / 'runtime.json').read_text())
    binary = Path(rt['binary'])
    if sha(binary.read_bytes()) != rt['binary_sha256'] or not rt['board_wait']:
        raise ValueError('matching conservative prepared runtime required')
    for label, build in (('control', a.control), ('candidate', a.build)):
        metas[label], files[label] = inventory(build)
        for machine, setname in SETS.items():
            roms = G.stage_sets(build.resolve(), setname, a.hbmame, a.rom_dir.resolve(), work / 'sets' / f'{label}_{machine}')
            have = {sha(q.read_bytes()) for q in (roms / setname).iterdir() if q.is_file()}
            if not set(metas[label]['sets'][machine]['files'].values()) <= have:
                raise ValueError('staged ROM identity differs')
            sets[label, machine] = (roms, setname)
    scenarios = plans()
    jobs = [(label, machine, case) for label in metas for machine in SETS for case in scenarios]

    def run(job):
        label, machine, case = job
        n, extra = scenarios[case]
        env = dict(extra, MOTION='128', CADENCE='1')
        out = work / 'runs' / f'{label}_{machine}_{case}'
        pin = dict(files=metas[label]['sets'][machine]['files'], environment=env, frames=n, runtime_sha256=rt['binary_sha256'], lua_sha256=sha(G.LUA.read_bytes()), debug_start_sha256=sha(G.DEBUG_START.read_bytes()))
        if not a.reuse or not (out / 'case.json').exists():
            G.run(binary, *sets[label, machine], out, env, n)
            (out / 'case.json').write_text(json.dumps(pin, indent=2) + '\n')
        if json.loads((out / 'case.json').read_text()) != pin or len(G.read(out)) != n:
            raise ValueError('stale or incomplete runtime case')
        print('Captured', label, machine, case, flush=True)
        return out
    with ThreadPoolExecutor(2) as ex:
        captured = dict(zip(jobs, ex.map(run, jobs)))
    checks = []
    for machine in SETS:
        for case in scenarios:
            r = compare(case, captured['control', machine, case], captured['candidate', machine, case])
            checks.append(dict(machine=machine, **r))
            print('PASS', machine, case, flush=True)
    with tempfile.TemporaryDirectory(prefix='fresh-', dir=work) as temp:
        fresh = Path(temp) / 'build'
        subprocess.run([sys.executable, str(Path(M.__file__)), '--build', str(a.control), '--vasm', str(a.vasm), '--out', str(fresh)], check=True)
        if inventory(fresh) != inventory(a.build):
            raise ValueError('empty-output reconstruction differs')
    rejected = []
    with tempfile.TemporaryDirectory(prefix='damage-', dir=work) as temp:
        for machine in SETS:
            for kind, address in (('hook', M.HOOK), ('helper', M.BASE), ('slope_body', M.SMOOTH)):
                root = Path(temp) / f'{machine}_{kind}'
                meta = deepcopy(metas['candidate'])
                for m, fs in files['candidate'].items():
                    dest = root / m
                    dest.mkdir(parents=True)
                    for n, data in fs.items():
                        if m == machine and n == 'strex_p6.bin':
                            b = bytearray(data)
                            b[address - 1048576 ^ 1] ^= 1
                            (dest / n).write_bytes(b)
                            meta['sets'][m]['files'][n] = sha(b)
                        else:
                            (dest / n).symlink_to((a.build / m / n).resolve())
                (root / 'build.json').write_text(json.dumps(meta) + '\n')
                try:
                    M.audit(a.control, root)
                except ValueError:
                    rejected.append(dict(machine=machine, kind=kind, inventory_rehashed=True, rejected=True))
                else:
                    raise ValueError('rehashed camera damage accepted')
    sources = (Path(__file__), Path(M.__file__), M.ASM, Path(G.__file__), Path(S.__file__), Path(C.__file__), G.LUA, G.DEBUG_START)
    report = dict(schema='striderex-cliff-camera-gate/1', passed=True, checks=checks, inputs={label: {m: s['files'] for m, s in meta['sets'].items()} for label, meta in metas.items()}, runtime={k: rt[k] for k in ('binary_sha256', 'source_revision', 'board_wait')}, fresh_empty_output_files_and_metadata_exact=True, rehashed_damage_controls=rejected, assembler_sha256=sha(a.vasm.read_bytes()), source_sha256={str(q.relative_to(Path(__file__).parents[1])): sha(q.read_bytes()) for q in sources}, hardware_review_granted=False)
    a.receipt.parent.mkdir(parents=True, exist_ok=True)
    a.receipt.write_text(json.dumps(report, indent=2) + '\n')
    if a.preview_out:
        a.preview_out.mkdir(parents=True, exist_ok=False)
        pictures, sources = ([], [])
        for f in range(1100, 1281, 2):
            pic = Image.new('RGB', (768, 244))
            draw = ImageDraw.Draw(pic)
            pair = []
            for i, label in enumerate(('control', 'candidate')):
                source = captured[label, 'striderua', 'down'] / f's_{f:05d}.png'
                pic.paste(Image.open(source).convert('RGB'), (i * 384, 20))
                draw.text((i * 384 + 4, 4), 'Before' if i == 0 else 'After', fill='white')
                pair.append(sha(source.read_bytes()))
            pictures.append(pic)
            sources.append(dict(frame=f, sha256=pair))
        durations = [10 * (round((i + 1) * 2 / 59.637 * 100) - round(i * 2 / 59.637 * 100)) for i in range(len(pictures))]
        durations[-1] = 800
        pictures[0].save(a.preview_out / 'cliff-descent.gif', save_all=True, append_images=pictures[1:], duration=durations, loop=0)
        pictures[len(pictures) // 2].save(a.preview_out / 'cliff-descent.png')
        (a.preview_out / 'preview.json').write_text(json.dumps(dict(actual_emulator_pictures=True, sources=sources, files={q.name: sha(q.read_bytes()) for q in a.preview_out.iterdir()}), indent=2) + '\n')
    print('All 12 regional cliff/slope/stock comparisons PASS; fresh output exact')
if __name__ == '__main__':
    main()
