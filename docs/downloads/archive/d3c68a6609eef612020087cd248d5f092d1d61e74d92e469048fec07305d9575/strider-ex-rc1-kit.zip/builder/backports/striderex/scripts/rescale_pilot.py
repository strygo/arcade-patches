"""P0.11 re-scaling pilot: PC Engine art to CPS-1 width, by five methods."""
import argparse
import json
import math
import subprocess
import sys
from pathlib import Path
import numpy as np
from PIL import Image
sys.path.insert(0, str(Path(__file__).resolve().parent))
import pce_vdc as P
ROOT = Path(__file__).resolve().parents[3]
MANIFEST = ROOT / 'backports/striderex/manifests/rescale_pilot.json'
CAPTURE = ROOT / 'backports/striderex/scripts/run_pce_scene_capture.py'
METHODS = ('A', 'E', 'B', 'C', 'D', 'F', 'G', 'P')
PILLAR = 64
PALETTE_BUDGET = {'composite': 24, 'bg': 8, 'sprites': 2}
METHOD_NAMES = {'A': 'Nearest neighbor', 'E': 'Edge-directed pick', 'B': 'Scale3x + area, source palettes', 'C': 'Scale3x + area, per-tile palettes', 'D': 'Lanczos-3, per-tile palettes', 'F': 'Scale3x + area, shared palette budget', 'G': 'Column blend, shared palette budget', 'P': 'Pillarbox at 1:1'}
TRANSPARENT = -1
LAST_SHARED = {}

def nearest_exact(run_dir, frame, span=30):
    check = run_dir / 'check.json'
    if not check.exists():
        return frame
    status = {r['frame']: r['status'] for r in json.loads(check.read_text())['frames']}
    for off in sorted(range(-span, span + 1), key=abs):
        if status.get(frame + off) == 'exact':
            return frame + off
    return frame

def subject_indices(subj, run_dir):
    """(index image with TRANSPARENT, palette RGB 512x3, frame used)."""
    frame = subj['frame'] if subj['layer'] != 'composite' else nearest_exact(run_dir, subj['frame'])
    d = P.load(run_dir / f'pce_{frame:05d}_scene.vdc')
    wr = P.read_writes(run_dir).get(frame, [])
    pal = P.pal_rgb(d['pal']).astype(np.int32)
    if subj['layer'] == 'composite':
        img = P.screen_image(d, writes=wr)[:224]
    elif subj['layer'] == 'bg':
        bg, _ = P.render_layers(d, writes=wr)
        y0, y1 = subj['rows']
        img = bg[y0:y1]
    else:
        objs = {o[0]: o for o in P.sprite_objects(d)}
        chosen = [objs[i] for i in subj['objects']]
        top = min((o[1] for o in chosen))
        left = min((o[2] for o in chosen))
        h = max((o[1] + o[3].shape[0] for o in chosen)) - top
        w = max((o[2] + o[3].shape[1] for o in chosen)) - left
        img = np.full((h, w), TRANSPARENT, np.int32)
        for i, t, l, im, attr in sorted(chosen, key=lambda o: -o[0]):
            region = img[t - top:t - top + im.shape[0], l - left:l - left + im.shape[1]]
            m = im != 0
            region[m] = 256 | (attr & 15) << 4 | im[m]
    return (img, pal, frame)

def to_rgba(idx, pal):
    rgb = pal[np.clip(idx, 0, 511)]
    a = np.where(idx == TRANSPARENT, 0, 255)
    return np.dstack([rgb, a]).astype(np.uint8)

def scale3x(e):
    """AdvMAME3x/Scale3x on an index image (edge-replicated borders)."""
    p = np.pad(e, 1, mode='edge')
    A, B, C = (p[:-2, :-2], p[:-2, 1:-1], p[:-2, 2:])
    D, E, F = (p[1:-1, :-2], p[1:-1, 1:-1], p[1:-1, 2:])
    G, H, I = (p[2:, :-2], p[2:, 1:-1], p[2:, 2:])
    c1 = (D == B) & (B != F) & (D != H)
    c2 = (B == F) & (B != D) & (F != H)
    c3 = (D == H) & (D != B) & (H != F)
    c4 = (H == F) & (D != H) & (B != F)
    out = np.empty((3, 3) + E.shape, e.dtype)
    out[0, 0] = np.where(c1, D, E)
    out[0, 1] = np.where(c1 & (E != C) | c2 & (E != A), B, E)
    out[0, 2] = np.where(c2, F, E)
    out[1, 0] = np.where(c1 & (E != G) | c3 & (E != A), D, E)
    out[1, 1] = E
    out[1, 2] = np.where(c2 & (E != I) | c4 & (E != C), F, E)
    out[2, 0] = np.where(c3, D, E)
    out[2, 1] = np.where(c3 & (E != I) | c4 & (E != G), H, E)
    out[2, 2] = np.where(c4, F, E)
    h, w = E.shape
    return out.transpose(2, 0, 3, 1).reshape(3 * h, 3 * w)

def method_nearest(idx):
    w = idx.shape[1]
    return idx[:, (np.arange(math.ceil(w * 1.5)) / 1.5).astype(int)]

def method_edge_pick(idx):
    """[a, m, b] per source pair; m from Scale3x's middle row (E5 of a, E3 of b)."""
    h, w = idx.shape
    if w % 2:
        idx = np.pad(idx, ((0, 0), (0, 1)), mode='edge')
        w += 1
    s3 = scale3x(idx)[1::3]
    a, b = (idx[:, 0::2], idx[:, 1::2])
    a5, b3 = (s3[:, 2::6], s3[:, 3::6])
    m = np.where(a5 == b3, a5, np.where(a5 != a, a5, np.where(b3 != b, b3, TRANSPARENT - 1)))
    tie = m == TRANSPARENT - 1
    if tie.any():
        up = np.pad(idx, ((1, 1), (0, 0)), mode='edge')
        votes_a = (up[:-2, 0::2] == a).astype(int) + (up[2:, 0::2] == a) + (up[:-2, 1::2] == a) + (up[2:, 1::2] == a)
        votes_b = (up[:-2, 0::2] == b).astype(int) + (up[2:, 0::2] == b) + (up[:-2, 1::2] == b) + (up[2:, 1::2] == b)
        m = np.where(tie, np.where(votes_b > votes_a, b, a), m)
    out = np.stack([a, m, b], -1).reshape(h, -1)
    return out

def srgb_to_lin(x):
    x = x / 255.0
    return np.where(x <= 0.04045, x / 12.92, ((x + 0.055) / 1.055) ** 2.4)

def lin_to_srgb(x):
    x = np.clip(x, 0, 1)
    return np.where(x <= 0.0031308, x * 12.92, 1.055 * x ** (1 / 2.4) - 0.055) * 255

def area_from_scale3x(idx, pal):
    """Scale3x then 2x3 area reduction: (h, 1.5w) linear-light RGB and alpha."""
    h, w = idx.shape
    if w % 2:
        idx = np.pad(idx, ((0, 0), (0, 1)), mode='edge')
        w += 1
    s3 = scale3x(idx)
    rgb = srgb_to_lin(pal[np.clip(s3, 0, 511)].astype(float))
    alpha = (s3 != TRANSPARENT).astype(float)

    def reduce(x):
        return x.reshape(h, 3, w * 3 // 2, 2, *x.shape[2:]).mean((1, 3))
    a = reduce(alpha)
    c = reduce(rgb * alpha[..., None]) / np.maximum(a, 1e-09)[..., None]
    return (c, a)

def snap_to_source_palette(lin, alpha, idx, pal):
    """Each output pixel to the nearest color of its source pixel's sub-palette."""
    h, w2 = alpha.shape
    src = idx[:, (np.arange(w2) / 1.5).astype(int)]
    sub = np.clip(src, 0, 511) >> 4
    cand = sub[..., None] * 16 + np.arange(1, 16)
    sprite = (idx == TRANSPARENT).any()
    if not sprite:
        cand = np.concatenate([np.zeros(cand.shape[:2] + (1,), cand.dtype), cand], -1)
    cand_lin = srgb_to_lin(pal[cand].astype(float))
    d = ((cand_lin - lin[:, :, None, :]) ** 2).sum(-1)
    out = np.take_along_axis(cand, d.argmin(-1)[..., None], -1)[..., 0]
    if sprite:
        out = np.where(alpha < 0.5, TRANSPARENT, out)
    return out

def cps_quantize_tiles(rgb8, alpha):
    """Per 16x16 tile: 15 colors by k-means at 4-bit/channel; returns RGBA uint8."""
    h, w = alpha.shape
    q = (np.round(rgb8 / 17.0) * 17).clip(0, 255).astype(np.uint8)
    out = np.zeros((h, w, 4), np.uint8)
    for ty in range(0, h, 16):
        for tx in range(0, w, 16):
            tile = q[ty:ty + 16, tx:tx + 16]
            am = alpha[ty:ty + 16, tx:tx + 16] >= 0.5
            th, tw = am.shape
            res = np.zeros((th, tw, 3), np.uint8)
            if am.any():
                px = tile[am].reshape(-1, 1, 3)
                colors = np.unique(px.reshape(-1, 3), axis=0)
                if len(colors) <= 15:
                    res[am] = px[:, 0]
                else:
                    im = Image.fromarray(px).quantize(colors=15, method=Image.Quantize.MEDIANCUT, kmeans=4)
                    palette = np.array(im.getpalette()[:45], np.uint8).reshape(15, 3)
                    palette = (np.round(palette / 17.0) * 17).clip(0, 255).astype(np.uint8)
                    res[am] = palette[np.asarray(im)[:, 0]]
            out[ty:ty + 16, tx:tx + 16, :3] = res
            out[ty:ty + 16, tx:tx + 16, 3] = np.where(am, 255, 0)
    return out

def kmeans(x, k, iters=25, seed=1):
    """Plain k-means (k-means++ start) on rows of x; returns labels."""
    rng = np.random.default_rng(seed)
    k = min(k, len(x))
    centers = [x[rng.integers(len(x))]]
    for _ in range(1, k):
        d = np.min([((x - c) ** 2).sum(1) for c in centers], 0)
        centers.append(x[rng.choice(len(x), p=d / d.sum()) if d.sum() > 0 else rng.integers(len(x))])
    c = np.array(centers)
    for _ in range(iters):
        lab = ((x[:, None, :] - c[None]) ** 2).sum(-1).argmin(1)
        new = np.array([x[lab == j].mean(0) if (lab == j).any() else c[j] for j in range(k)])
        if np.allclose(new, c):
            break
        c = new
    return lab

def palette15(px):
    """15 colors for the pixels px (n x 3 uint8), at CPS-1 4-bit precision."""
    cols = np.unique(px, axis=0)
    if len(cols) <= 15:
        return cols
    im = Image.fromarray(px.reshape(-1, 1, 3)).quantize(colors=15, method=Image.Quantize.MEDIANCUT, kmeans=4)
    pal = np.array(im.getpalette()[:45], np.uint8).reshape(15, 3)
    return (np.round(pal / 17.0) * 17).clip(0, 255).astype(np.uint8)

def cps_quantize_shared(rgb8, alpha, budget):
    """Per 16x16 tile, one of at most `budget` shared 15-color palettes."""
    h, w = alpha.shape
    q = (np.round(rgb8 / 17.0) * 17).clip(0, 255).astype(np.uint8)
    op = alpha >= 0.5
    tiles = [(ty, tx) for ty in range(0, h, 16) for tx in range(0, w, 16) if op[ty:ty + 16, tx:tx + 16].any()]
    out = np.zeros((h, w, 4), np.uint8)
    if not tiles:
        return out
    allpx = q[op]
    gim = Image.fromarray(allpx.reshape(-1, 1, 3)).quantize(colors=64, method=Image.Quantize.MEDIANCUT)
    gp = gim.getpalette()
    gpal = np.array(gp[:3 * min(64, len(gp) // 3)], float).reshape(-1, 3)
    feats = []
    for ty, tx in tiles:
        px = q[ty:ty + 16, tx:tx + 16][op[ty:ty + 16, tx:tx + 16]].astype(float)
        near = ((px[:, None, :] - gpal[None]) ** 2).sum(-1).argmin(1)
        hist = np.bincount(near, minlength=len(gpal)).astype(float)
        feats.append(np.sqrt(hist / hist.sum()))
    lab = kmeans(np.array(feats), budget)
    pals = []
    for j in range(lab.max() + 1):
        members = [tiles[i] for i in np.where(lab == j)[0]]
        if not members:
            continue
        px = np.concatenate([q[ty:ty + 16, tx:tx + 16][op[ty:ty + 16, tx:tx + 16]] for ty, tx in members])
        pals.append(palette15(px).astype(float))
    used = set()
    for ty, tx in tiles:
        t = q[ty:ty + 16, tx:tx + 16].astype(float)
        m = op[ty:ty + 16, tx:tx + 16]
        best, best_err, best_map, best_k = (None, None, None, None)
        for k_pal, pal in enumerate(pals):
            d = ((t[m][:, None, :] - pal[None]) ** 2).sum(-1)
            err = d.min(1).sum()
            if best_err is None or err < best_err:
                best, best_err, best_map, best_k = (pal, err, d.argmin(1), k_pal)
        used.add(best_k)
        res = np.zeros(t.shape, np.uint8)
        res[m] = best[best_map].astype(np.uint8)
        out[ty:ty + 16, tx:tx + 16, :3] = res
        out[ty:ty + 16, tx:tx + 16, 3] = np.where(m, 255, 0)
    LAST_SHARED['palettes'] = len(used)
    return out

def method_lanczos(idx, pal):
    rgba = to_rgba(idx, pal)
    h, w = idx.shape
    lin = srgb_to_lin(rgba[..., :3].astype(float))
    a = rgba[..., 3].astype(float) / 255
    tw = math.ceil(w * 1.5)

    def rs(ch):
        return np.asarray(Image.fromarray(ch.astype(np.float32), 'F').resize((tw, h), Image.Resampling.LANCZOS))
    ar = np.clip(rs(a), 0, 1)
    premul = np.dstack([rs(lin[..., k] * a) for k in range(3)])
    c = premul / np.maximum(ar, 1e-06)[..., None]
    return (lin_to_srgb(c), ar)

def column_blend(idx, pal):
    """[a, (a+b)/2, b] per source pair, linear light: (h, 1.5w) RGB and alpha."""
    h, w = idx.shape
    if w % 2:
        idx = np.pad(idx, ((0, 0), (0, 1)), mode='edge')
    lin = srgb_to_lin(pal[np.clip(idx, 0, 511)].astype(float))
    alpha = (idx != TRANSPARENT).astype(float)
    a_l, b_l = (lin[:, 0::2], lin[:, 1::2])
    a_a, b_a = (alpha[:, 0::2], alpha[:, 1::2])
    mid_a = (a_a + b_a) / 2
    mid = (a_l * a_a[..., None] + b_l * b_a[..., None]) / np.maximum(a_a + b_a, 1e-09)[..., None]
    rgb = np.stack([a_l, mid, b_l], 2).reshape(h, -1, 3)
    al = np.stack([a_a, mid_a, b_a], 2).reshape(h, -1)
    return (rgb, al)

def pillarbox(idx, pal):
    """The art at 1:1 on a 384-px screen, centered, black bars (opaque)."""
    h, w = idx.shape
    out = np.zeros((h, w + 2 * PILLAR, 4), np.uint8)
    out[..., 3] = 255
    out[:, PILLAR:PILLAR + w] = to_rgba(idx, pal)
    return out

def convert(idx, pal, method, budget=24):
    """RGBA uint8 result at 1.5x width (P: 1:1 art inside the 384-px screen)."""
    if method == 'P':
        return pillarbox(idx, pal)
    if method == 'A':
        return to_rgba(method_nearest(idx), pal)
    if method == 'E':
        return to_rgba(method_edge_pick(idx), pal)
    if method in ('B', 'C', 'F'):
        lin, alpha = area_from_scale3x(idx, pal)
        if method == 'B':
            return to_rgba(snap_to_source_palette(lin, alpha, idx, pal), pal)
        if method == 'F':
            return cps_quantize_shared(lin_to_srgb(lin), alpha, budget)
        return cps_quantize_tiles(lin_to_srgb(lin), alpha)
    if method == 'D':
        rgb, alpha = method_lanczos(idx, pal)
        return cps_quantize_tiles(rgb, alpha)
    if method == 'G':
        lin, alpha = column_blend(idx, pal)
        return cps_quantize_shared(lin_to_srgb(lin), alpha, budget)
    raise ValueError(method)

def tile_metrics(rgba):
    h, w = rgba.shape[:2]
    counts, sets = ([], [])
    for ty in range(0, h, 16):
        for tx in range(0, w, 16):
            t = rgba[ty:ty + 16, tx:tx + 16]
            op = t[..., 3] > 0
            cols = {tuple(c) for c in t[op][:, :3].tolist()}
            if cols:
                counts.append(len(cols))
                sets.append(frozenset(cols))
    palettes = []
    for s in sorted(set(sets), key=len, reverse=True):
        if len(s) > 15:
            palettes.append(s)
            continue
        for k, p in enumerate(palettes):
            if len(p) <= 15 and len(p | s) <= 15:
                palettes[k] = p | s
                break
        else:
            palettes.append(set(s))
    return dict(tiles=len(counts), max_colors=max(counts, default=0), tiles_over_15=sum((1 for c in counts if c > 15)), palettes_greedy=len(palettes), distinct_colors=len({c for s in sets for c in s}))

def zoom(rgba, k, bg=(48, 48, 48)):
    im = Image.fromarray(rgba, 'RGBA')
    base = Image.new('RGBA', im.size, bg + (255,))
    base.alpha_composite(im)
    return base.convert('RGB').resize((im.width * k, im.height * k), Image.Resampling.NEAREST)

def cmd_capture(a, m):
    for c in m['captures']:
        out = a.workdir / c['run']
        if (out / 'run.log').exists():
            print(f"{c['run']}: already captured")
            continue
        cmd = [sys.executable, str(CAPTURE), '--cdrom', str(a.cue), '--rompath', str(a.rompath), '--outdir', str(out), '--window', c['window'], '--end', str(c['end']), '--timeout-seconds', '1200']
        if 'pce_start_stage' in c:
            cmd += ['--pce-start-stage', str(c['pce_start_stage'])]
        if c.get('pce_checkpoint_census'):
            cmd += ['--pce-checkpoint-census']
        r = subprocess.run(cmd)
        if r.returncode:
            return r.returncode
        r = subprocess.run([sys.executable, str(ROOT / 'backports/striderex/scripts/pce_vdc.py'), 'check', str(out), '--output', str(out / 'check.json')])
        if r.returncode:
            return r.returncode
    return 0

def cmd_render(a, m):
    out = a.workdir / 'pilot'
    out.mkdir(parents=True, exist_ok=True)
    report = dict(manifest=str(MANIFEST.relative_to(ROOT)), methods=METHOD_NAMES, subjects=[])
    for subj in m['subjects']:
        run_dir = a.census_dir / subj['run'] if (a.census_dir / subj['run']).exists() else a.workdir / subj['run']
        idx, pal, frame = subject_indices(subj, run_dir)
        native = to_rgba(idx, pal)
        Image.fromarray(native, 'RGBA').save(out / f"{subj['id']}_native.png")
        zk = 3 if idx.shape[1] <= 128 else 2
        zoom(native, zk).save(out / f"{subj['id']}_native_z.png")
        entry = dict(id=subj['id'], note=subj['note'], run=subj['run'], frame=frame, size=list(idx.shape[::-1]), palette_budget_F=PALETTE_BUDGET[subj['layer']], zoom=zk, native_metrics=tile_metrics(native), methods={})
        h, w = idx.shape
        cy, cx = (h // 2, w // 2)
        crop_h, crop_w = (min(h, 56), min(w, 64))
        y0, x0 = (max(0, cy - crop_h // 2), max(0, cx - crop_w // 2))
        zoom(native[y0:y0 + crop_h, x0:x0 + crop_w], 6).save(out / f"{subj['id']}_native_detail.png")
        for meth in METHODS:
            if meth == 'P' and subj['layer'] != 'composite':
                continue
            res = convert(idx, pal, meth, PALETTE_BUDGET[subj['layer']])
            Image.fromarray(res, 'RGBA').save(out / f"{subj['id']}_{meth}.png")
            zoom(res, zk).save(out / f"{subj['id']}_{meth}_z.png")
            if meth == 'P':
                zoom(res[y0:y0 + crop_h, PILLAR + x0:PILLAR + x0 + crop_w], 6).save(out / f"{subj['id']}_{meth}_detail.png")
                entry['methods'][meth] = dict(tile_metrics(res[:, PILLAR:-PILLAR]), tiles8_over_16=0)
            else:
                X0 = int(x0 * 1.5)
                zoom(res[y0:y0 + crop_h, X0:X0 + int(crop_w * 1.5)], 6).save(out / f"{subj['id']}_{meth}_detail.png")
                entry['methods'][meth] = tile_metrics(res)
            if meth in ('F', 'G'):
                entry['methods'][meth]['palettes_greedy'] = LAST_SHARED['palettes']
        report['subjects'].append(entry)
        print(subj['id'], frame, idx.shape, {k: (v['max_colors'], v['tiles_over_15'], v['palettes_greedy']) for k, v in entry['methods'].items()})
    (out / 'metrics.json').write_text(json.dumps(report, indent=1) + '\n')
    return 0

def self_test():
    idx = np.zeros((6, 8), np.int32)
    idx[:, 3:] = 5
    n = method_nearest(idx)
    assert n.shape == (6, 12) and n[0].tolist() == [0, 0, 0, 0, 0, 5, 5, 5, 5, 5, 5, 5], n[0]
    e = method_edge_pick(idx)
    assert e.shape == (6, 12) and (e == e[0]).all(), e
    d = np.tril(np.full((8, 8), 7, np.int32))
    assert set(np.unique(method_edge_pick(d))) <= {0, 7}
    s3 = scale3x(d)
    assert s3.shape == (24, 24) and set(np.unique(s3)) <= {0, 7}
    pal = np.zeros((512, 3), np.int32)
    pal[5] = [255, 0, 0]
    pal[7] = [0, 0, 255]
    for meth in METHODS:
        r = convert(d, pal, meth)
        assert r.shape == ((8, 8 + 2 * PILLAR, 4) if meth == 'P' else (8, 12, 4)), (meth, r.shape)
    pb = convert(d, pal, 'P')
    assert (pb[:, :PILLAR, :3] == 0).all() and (pb[:, PILLAR:PILLAR + 8, :3] == to_rgba(d, pal)[..., :3]).all()
    lin, al = column_blend(np.array([[5, 7]]), pal)
    mid = lin_to_srgb(lin[0, 1])
    assert lin.shape == (1, 3, 3) and np.allclose(lin_to_srgb(lin[0, 0]), [255, 0, 0])
    assert 180 < mid[0] < 190 and 180 < mid[2] < 190, mid
    m = tile_metrics(convert(d, pal, 'B'))
    assert m['tiles'] == 1 and m['max_colors'] <= 15
    rng = np.random.default_rng(0)
    noisy = rng.integers(0, 256, (64, 96, 3)).astype(np.uint8)
    shared = cps_quantize_shared(noisy, np.ones((64, 96)), 3)
    assert tile_metrics(shared)['palettes_greedy'] <= 3 and tile_metrics(shared)['max_colors'] <= 15
    print('rescale_pilot self-test: ok')
    return 0

def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('command', nargs='?', choices=['capture', 'render'])
    p.add_argument('--workdir', type=Path)
    p.add_argument('--census-dir', type=Path, help='workdir of pce_cinematic_census.py (cinematic runs)')
    p.add_argument('--cue', type=Path)
    p.add_argument('--rompath', type=Path)
    p.add_argument('--self-test', action='store_true')
    a = p.parse_args()
    if a.self_test:
        return self_test()
    if not a.command or not a.workdir:
        p.error('command and --workdir are required')
    a.workdir = a.workdir.resolve()
    m = json.loads(MANIFEST.read_text())
    if a.command == 'capture':
        if not (a.cue and a.rompath):
            p.error('capture needs --cue and --rompath')
        return cmd_capture(a, m)
    if not a.census_dir:
        p.error('render needs --census-dir')
    a.census_dir = a.census_dir.resolve()
    return cmd_render(a, m)
if __name__ == '__main__':
    sys.exit(main())
