"""Give the commander's opening question 72 more VBlanks to read."""
import argparse
from copy import deepcopy
import json
from pathlib import Path
import struct
import sys
import boss_scene_binary as B
from boss_voice_gate import inventory
from boss_followup_release import sha
EXTRA = 72

def patch(raw):
    b = bytearray(raw)
    s = B.scenes(b)[-1]
    if s['total'] != 626 or len(s['pages']) != 2:
        raise ValueError('commander source timeline changed')
    p = s['pages'][0]
    old = [B.word(b, p + i) for i in (4, 6, 8)]
    if old != [190, 207, 218]:
        raise ValueError('commander first page changed')
    rows = []
    for at in (s['at'], p + 4, p + 6, p + 8):
        before = B.word(b, at)
        struct.pack_into('>H', b, at, before + EXTRA)
        rows.append(dict(address=B.BASE + at, before=before, after=before + EXTRA))
    if B.scenes(b)[-1]['total'] != 698:
        raise ValueError('invalid extended scene')
    return (bytes(b), rows)

def self_test():
    b = bytearray(b'\xff' * 2048)
    for k in range(8):
        at = 64 + k * 112
        struct.pack_into('>I', b, 4 * k, B.BASE + at)
        struct.pack_into('>4H', b, at, 626 if k == 7 else 200, 184 + k, 192 + k, 0)
        struct.pack_into('>I', b, at + 48, B.BASE + 32)
        for i in range(2 if k == 7 else 1):
            p = at + 52 + 60 * i
            struct.pack_into('>I3H', b, p, B.BASE + p + 60 if k == 7 and i == 0 else 0, *([190, 207, 218] if i == 0 else [316, 333, 344]))
            struct.pack_into('>16H', b, p + 10, *[61440] * 16)
            struct.pack_into('>H', b, p + 42, 1)
            struct.pack_into('>HH', b, p + 56, 0, 0)
    out, changes = patch(b)
    assert len(changes) == 4 and B.scenes(out)[-1]['total'] == 698
    changed = {i for i, (x, y) in enumerate(zip(b, out)) if x != y}
    allowed = {r['address'] - B.BASE + j for r in changes for j in (0, 1)}
    assert changed <= allowed and out[:64 + 7 * 112] == b[:64 + 7 * 112]
    bad = bytearray(b)
    bad[64 + 7 * 112] ^= 1
    try:
        patch(bad)
    except ValueError:
        pass
    else:
        raise AssertionError('changed source timeline accepted')
    print('Commander reading self-test PASS: bounded data edit; altered source rejected')

def main():
    if sys.argv[1:] == ['--self-test']:
        return self_test()
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--build', type=Path, required=True)
    p.add_argument('--out', type=Path, required=True)
    a = p.parse_args()
    meta, files = inventory(a.build)
    rep = deepcopy(meta)
    a.out.mkdir(parents=True, exist_ok=False)
    for m, f in files.items():
        raw = f['strex_p6.bin']
        b = bytes((raw[k ^ 1] for k in range(len(raw))))
        new, rows = patch(b)
        f = dict(f, **{'strex_p6.bin': bytes((new[k ^ 1] for k in range(len(new))))})
        d = a.out / m
        d.mkdir()
        for n, data in f.items():
            (d / n).write_bytes(data)
        rep['sets'][m]['files'] = {n: sha(data) for n, data in f.items()}
        rep['sets'][m]['commander_reading'] = dict(extra_vblanks=EXTRA, changes=rows, source_files=meta['sets'][m]['files'])
    (a.out / 'build.json').write_text(json.dumps(rep, indent=2) + '\n')
    print('Commander first page: +72 ticks (1.207 s); voice, second-page hold and all other scenes unchanged')
if __name__ == '__main__':
    main()
