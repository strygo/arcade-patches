"""Verify extended page timing in the eight commander voice-routing runs."""
import argparse
import json
from pathlib import Path
import boss_scene_binary as BB
import boss_scene_gate as B
from boss_voice_gate import inventory, sha
import commander_reading as C

def gate(a):
    meta, files = inventory(a.build)
    voice = json.loads(a.voice_receipt.read_text())
    rows = []
    if not voice['passed']:
        raise ValueError('voice qualification failed')
    for p in sorted(a.runs.glob('*/desert_commander/qualified')):
        machine = p.parts[-3].split('_')[0]
        b = files[machine]['strex_p6.bin']
        bank = bytes((b[k ^ 1] for k in range(len(b))))
        record = BB.scenes(bank)[-1]
        spec = meta['sets'][machine]['commander_reading']
        old = bytearray(bank)
        for change in spec['changes']:
            at = change['address'] - BB.BASE
            if BB.word(bank, at) != change['after']:
                raise ValueError('timing bytes differ')
            old[at:at + 2] = change['before'].to_bytes(2, 'big')
        expected, _ = C.patch(old)
        if expected != bank:
            raise ValueError('candidate differs outside four timing words')
        log = B.load(p, len((p / 'g_frames.tsv').read_text().splitlines()))
        vb = B.scene_vblanks(log)
        if len(vb) != 698:
            raise ValueError('wrong scene duration')
        first = [v for v in vb if v['pl'] >> 8 == 4]
        second = [v for v in vb if v['pl'] >> 8 == 20]
        if len(first) != 290 or len(second) != 344:
            raise ValueError('page boundary changed')
        first_fade = next((v['n'] for v in first if v['t'] > 262 and v['pl'] & 255 < 16))
        if first_fade != 315 or second[0]['n'] != 342:
            raise ValueError('extended first-page reveal/fade mismatch')
        before = set((v['n'] for v in first if 190 < v['t'] <= 262 and v['pl'] & 255 == 16))
        if len(before) != 72:
            raise ValueError('extra readable hold is missing')
        if B.freeze_diff(log['dumps']['entry'], log['dumps']['exit']):
            raise ValueError('game state changed during reading hold')
        rows.append(dict(variant=p.parts[-3], scene_frames=len(vb), first_page_frames=len(first), first_fade_tick=first_fade, second_page_tick=second[0]['n'], extra_full_brightness_ticks=72, frames_sha256=sha((p / 'g_frames.tsv').read_bytes()), regs_sha256=sha((p / 'g_regs.tsv').read_bytes()), passed=True))
    if len(rows) != 8:
        raise ValueError('need all regional, pack/native and override paths')
    result = dict(schema='striderex-commander-reading-gate/1', passed=True, extra_vblanks=72, input_files={m: s['files'] for m, s in meta['sets'].items()}, voice_receipt_sha256=sha(a.voice_receipt.read_bytes()), results=rows, hardware_review_granted=False)
    a.receipt.write_text(json.dumps(result, indent=2) + '\n')
    print('PASS: eight actual page timelines, +72 fully readable ticks, uninterrupted voices and frozen game state')

def main():
    p = argparse.ArgumentParser(description=__doc__)
    for n in ('build', 'runs', 'voice-receipt', 'receipt'):
        p.add_argument('--' + n, type=Path, required=True)
    gate(p.parse_args())
if __name__ == '__main__':
    main()
