"""Qualify the restored first girder with natural controls in both regions."""
import argparse
import csv
import hashlib
import json
from pathlib import Path
from types import SimpleNamespace
import desert_feedback_probe as P
import desert_grip_fix as F

def sha(b):
    return hashlib.sha256(b).hexdigest()

def gate(a):
    work = a.workdir.resolve()
    work.mkdir(parents=True, exist_ok=a.reuse)
    metas = {k: json.loads((p / 'build.json').read_text()) for k, p in (('control', a.control), ('candidate', a.build))}
    mask, source = F.source_mask(a.capture)
    stock = F.DX.program_images(a.rom_dir)
    checks = []
    for machine, set_name in (('striderua', 'striderus01'), ('striderjr', 'striderjs01')):
        files = {}
        for label, path in (('control', a.control), ('candidate', a.build)):
            spec = metas[label]['sets'][machine]
            files[label] = {n: (path / machine / n).read_bytes() for n in spec['files']}
            if any((sha(b) != spec['files'][n] for n, b in files[label].items())):
                raise ValueError('input inventory changed')
        expected, geometry = F.patch(files['control'], machine, mask, stock[machine])
        if expected != files['candidate']:
            raise ValueError('candidate does not match the guarded geometry repair')
        changed = [n for n in files['control'] if files['control'][n] != files['candidate'][n]]
        data_name = 'st-14.8h' if machine == 'striderua' else 'sthj_22.7f'
        if set(changed) != {data_name, 'strex_p6.bin'}:
            raise ValueError('unexpected ROM surface changed')
        old, new = [F.RF.compose(files[k], F.RF.SETS[machine]) for k in ('control', 'candidate')]
        oldbank, newbank = [bytes((files[k]['strex_p6.bin'][i ^ 1] for i in range(1048576))) for k in ('control', 'candidate')]

        def read(img, bank, at, n):
            return bank[at - 1048576:at - 1048576 + n] if at >= 1048576 else img[at:at + n]
        for code, flip in F.DX.stock_scroll3_codes(stock[machine]):
            for key, old_set in F.DX.collision_sets(old).items():
                new_set = F.DX.collision_sets(new)[key]
                for img, bank, spec in ((old, oldbank, old_set), (new, newbank, new_set)):
                    pg, ty, _, _, rec = spec
                    page = read(img, bank, pg + (code >> 8) + 8 * flip, 1)[0]
                    value = read(img, bank, ty + (page - 1) * 256 + (code & 255), 1)[0] if page else 0
                    value = (value, read(img, bank, rec + (value - 32) * 33, 33) if value >= 32 else b'')
                    if img is old:
                        before = value
                    elif value != before:
                        raise ValueError('original arcade collision changed')
        traces = {}
        for label, path in (('control', a.control), ('candidate', a.build)):
            out = work / (label + '_' + machine)
            if not a.reuse or not (out / 'report.json').exists():
                P.probe(SimpleNamespace(build=path.resolve(), out=out, rom_dir=a.rom_dir.resolve(), runtime=a.runtime, hbmame=a.hbmame, set=set_name, cases='girder'))
            report = json.loads((out / 'report.json').read_text())
            if report['input_files'] != metas[label]['sets'][machine]['files']:
                raise ValueError('trace belongs to different inputs')
            expected_env = {k: v for k, v in P.CASES['girder'][1].items()}
            if any((report['results'][0]['input'].get(k) != v for k, v in expected_env.items())):
                raise ValueError('trace uses a different input or capture schedule')
            motion = out / 'girder/motion.tsv'
            if sha(motion.read_bytes()) != report['results'][0]['motion_sha256']:
                raise ValueError('trace changed')
            traces[label] = list(csv.DictReader(motion.open(), delimiter='\t'))
        control, candidate = [traces[k] for k in ('control', 'candidate')]
        if len(control) != 1820 or len(candidate) != 1820:
            raise ValueError('incomplete run')
        keys = ('hx', 'hxf', 'hy', 'hyf', 'st', 'sub', 'kind', 'speed', 'camx', 'camxf', 'camy', 'camyf')
        first = next((i for i, (x, y) in enumerate(zip(control, candidate)) if any((x[k] != y[k] for k in keys))))
        if not 1515 <= first <= 1520 or int(candidate[first]['st']) != 8 or int(control[first]['st']) != 12:
            raise ValueError('movement changed before the handhold')
        during = lambda rows: rows[1517:1800]
        grips = lambda rows: sum((int(r['st']) == 8 for r in during(rows)))
        if grips(control) != 0 or grips(candidate) < 250:
            raise ValueError('missing old failure or sustained new grip')
        last = candidate[1799]
        if int(last['hx']) < 2430 or int(last['hy']) < 1280 or int(last['st']) != 8:
            raise ValueError('girder did not connect to its horizontal handhold')
        checks.append(dict(machine=machine, passed=True, geometry=geometry, natural_player_controls=True, player_and_camera_warps=False, old_defect_rejected=True, original_arcade_collision_unchanged=True, all_graphics_sound_and_executable_roms_unchanged=True, unchanged_motion_before_grip_frames=first, grip_frames={'control': grips(control), 'candidate': grips(candidate)}, final_grip={k: int(last[k]) for k in ('frame', 'hx', 'hy', 'st')}, trace_hashes={k: sha((work / (k + '_' + machine) / 'girder/motion.tsv').read_bytes()) for k in traces}))
    receipt = dict(schema='striderex-first-girder-grip/1', passed=True, source=source, input_files={k: {m: s['files'] for m, s in v['sets'].items()} for k, v in metas.items()}, input=P.CASES['girder'][1], results=checks, hardware_review_granted=False)
    a.receipt.write_text(json.dumps(receipt, indent=2) + '\n')
    print('PASS: both regions catch, climb and traverse the first girder; original game code and jump unchanged')

def main():
    p = argparse.ArgumentParser(description=__doc__)
    for n in ('control', 'build', 'capture', 'rom-dir', 'runtime', 'hbmame', 'workdir', 'receipt'):
        p.add_argument('--' + n, type=Path, required=True)
    p.add_argument('--reuse', action='store_true')
    gate(p.parse_args())
if __name__ == '__main__':
    main()
