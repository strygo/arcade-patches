"""Synchronize a native music audition with captured prologue footage."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
HZ = 59.637
SR = 48000

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    p = argparse.ArgumentParser(description=__doc__)
    for name in ('video', 'music', 'music-receipt', 'out', 'receipt'):
        p.add_argument('--' + name, type=Path, required=True)
    p.add_argument('--cue-delay-frames', type=int, required=True)
    p.add_argument('--scene-frames', type=int, required=True)
    a = p.parse_args()
    native = json.loads(a.music_receipt.read_text())
    if not native['passed'] or sha(a.music) != native['mp3_sha256']:
        p.error('music must match its passing native audition receipt')
    if a.cue_delay_frames < 0 or a.scene_frames <= 0:
        p.error('invalid scene frame range')
    if a.out.exists() or a.receipt.exists():
        p.error('use fresh output files')
    delay = a.cue_delay_frames / HZ
    seconds = a.scene_frames / HZ
    samples = round(delay * SR)
    a.out.parent.mkdir(parents=True, exist_ok=True)
    af = f'atrim=duration={seconds:.9f},asetpts=PTS-STARTPTS,adelay={samples}S:all=1'
    subprocess.run(['ffmpeg', '-v', 'error', '-n', '-i', str(a.video.resolve()), '-i', str(a.music.resolve()), '-map', '0:v:0', '-map', '1:a:0', '-af', af, '-t', f'{delay + seconds:.9f}', '-c:v', 'libx264', '-crf', '16', '-pix_fmt', 'yuv420p', '-c:a', 'aac', '-b:a', '192k', '-movflags', '+faststart', str(a.out.resolve())], check=True)
    probe = json.loads(subprocess.check_output(['ffprobe', '-v', 'error', '-show_entries', 'format=duration:stream=codec_type,codec_name,width,height,sample_rate', '-of', 'json', str(a.out)], text=True))
    video = [s for s in probe['streams'] if s['codec_type'] == 'video']
    audio = [s for s in probe['streams'] if s['codec_type'] == 'audio']
    if len(video) != 1 or len(audio) != 1 or abs(float(probe['format']['duration']) - delay - seconds) > 0.05:
        raise ValueError('preview streams or duration differ from the requested scene')
    receipt = dict(schema='striderex-original-cinematic-preview/1', title=native['title'], type='edited listening preview', in_game_execution_capture=False, game_build_changed=False, source_video_sha256=sha(a.video), source_music_sha256=sha(a.music), native_music_receipt_sha256=sha(a.music_receipt), native_song_sha256=native['patch']['sha256'], frame_rate=HZ, cue_delay_frames=a.cue_delay_frames, scene_frames=a.scene_frames, delay_samples=samples, preview_gain_db=native['preview_gain_db'], video_timing_preserved=True, original_video_audio_replaced=True, output_file=a.out.name, output_sha256=sha(a.out), probe=probe, producer_sha256=sha(Path(__file__)), passed=True)
    a.receipt.parent.mkdir(parents=True, exist_ok=True)
    a.receipt.write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(receipt, indent=2))
if __name__ == '__main__':
    main()
