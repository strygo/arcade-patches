-- Add read-only pause/caption observations to the existing cinematic runner.
dofile(assert(os.getenv('READING_BASE_LUA')))
local m=manager.machine
local sp=m.devices[':maincpu'].spaces['program']
local out=assert(os.getenv('OUT'))
local log=assert(io.open(out..'/reading.tsv','w'))
local low=tonumber(os.getenv('READ_LO'))
local high=tonumber(os.getenv('READ_HI'))
local pause=tonumber(os.getenv('READ_PAUSE'))
local on=tonumber(os.getenv('READ_ON'))
local off=tonumber(os.getenv('READ_OFF'))
local skip=tonumber(os.getenv('READ_SKIP') or '0')
local start
for _,p in pairs(m.ioport.ports) do for _,field in pairs(p.fields) do
 if m.ioport:input_type_to_token(field.type,field.player)=='START1' then start=field end
end end
local f=0
local captured={}
local pressed
emu.register_frame_done(function()
 f=f+1
 local record=sp:read_u32(0xfff900)
 local held=sp:read_u16(0xfff9be)
 local active=sp:read_u16(0xfff914)
 local lz=sp:read_u32(0xfff904)
 local caption=sp:read_u16(0xfff984)
 log:write(string.format('%d\t%d\t%d\t%d\t%d\t%d\t%d\n',f,record,held,caption,sp:read_u32(0xfff980),active,lz))
 if active==0xc1e5 and lz>=low and lz<high then
  local label
  if record==on+10 then label='final-page' end
  if pause>0 and record==pause and held==0 then label='before-pause' end
  if pause>0 and record==pause and (held==3 or held==60 or held==120) then label='held-'..held end
  if record==off+3 then label='after-clear' end
  if label and not captured[label] then
   m.screens[':screen']:snapshot(out..'/reading-'..label..'.png');captured[label]=true
  end
  if skip>0 and held==skip and not pressed then pressed=f end
 end
 if pressed and f>=pressed and f<pressed+6 then start:set_value(1)
 elseif pressed and f==pressed+6 then start:clear_value() end
 log:flush()
end)
