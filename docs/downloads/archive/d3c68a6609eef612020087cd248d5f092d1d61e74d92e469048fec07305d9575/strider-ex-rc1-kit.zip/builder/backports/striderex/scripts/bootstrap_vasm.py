"""Build the pinned vasm 2.0f 68000 assembler for Strider EX in fresh scratch."""
import argparse
import hashlib
import json
import subprocess
import sys
from pathlib import Path
URL = 'https://github.com/siemens-mobile-hacks/vasm.git'
COMMIT = '2516daa63ddd61744dfaae72b829002fb22c2cfe'
FIXTURE = bytes.fromhex('70004e75')

def bootstrap(root):
    source = root / 'vasm'
    if source.exists():
        sys.exit('use a fresh directory')
    root.mkdir(parents=True, exist_ok=True)
    subprocess.run(['git', 'clone', '--quiet', '--no-checkout', URL, str(source)], check=True)
    subprocess.run(['git', '-C', str(source), 'checkout', '--quiet', '--detach', COMMIT], check=True)
    if subprocess.check_output(['git', '-C', str(source), 'rev-parse', 'HEAD'], text=True).strip() != COMMIT:
        sys.exit('assembler source revision differs')
    r = subprocess.run(['make', 'CPU=m68k', 'SYNTAX=mot'], cwd=source, capture_output=True, text=True)
    (root / 'make.log').write_text(r.stdout + r.stderr)
    if r.returncode:
        sys.exit('assembler build failed; see make.log')
    exe = (source / 'vasmm68k_mot').resolve()
    fixture, out = (root / 'fixture.s', root / 'fixture.bin')
    fixture.write_text(' moveq #0,d0\n rts\n')
    subprocess.run([str(exe), '-Fbin', '-quiet', '-m68000', '-o', str(out), str(fixture)], check=True)
    if out.read_bytes() != FIXTURE:
        sys.exit('assembler fixture differs')
    (root / 'toolchain.json').write_text(json.dumps(dict(source_url=URL, source_commit=COMMIT, executable=str(exe), executable_sha256=hashlib.sha256(exe.read_bytes()).hexdigest()), indent=1) + '\n')
    return exe

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root', type=Path, required=True)
    print(bootstrap(p.parse_args().root.resolve()))
    return 0
if __name__ == '__main__':
    sys.exit(main())
