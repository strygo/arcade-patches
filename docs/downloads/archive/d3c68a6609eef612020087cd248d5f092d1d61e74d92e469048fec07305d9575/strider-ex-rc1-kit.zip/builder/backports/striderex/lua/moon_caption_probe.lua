-- Read-only Moon caption/palette witness, wrapping the normal prepared gate.
local m=manager.machine
local cpu=m.devices[':maincpu']
local sp=cpu.spaces['program']
local out=assert(os.getenv('OUT'))
local frame=0
local log=assert(io.open(out..'/caption_writes.tsv','w'))
log:write('frame\tpc\taddress\tvalue\n')
local tap=sp:install_write_tap(0x9142c0,0x9142df,'moon_caption_palette',function(a,d,mask)
 log:write(string.format('%d\t%x\t%x\t%04x\n',frame+1,cpu.state['CURPC'].value,a,d))
end)
_G.moon_caption_tap=tap
emu.register_frame_done(function() frame=frame+1;log:flush() end)
dofile(assert(os.getenv('MOON_NATIVE_GATE_LUA')))
