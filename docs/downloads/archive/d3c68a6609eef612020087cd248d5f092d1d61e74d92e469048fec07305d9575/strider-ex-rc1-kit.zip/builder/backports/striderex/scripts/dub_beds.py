"""Strider EX English dub (W6, D13): voice-free music beds for the PC Engine"""
import argparse
import hashlib
import json
import math
import sys
import wave
from pathlib import Path
ROOT = Path(__file__).resolve().parents[3]
STREX = ROOT / 'backports/striderex'
MANIFEST = STREX / 'manifests/dub_beds.json'
TRANSCRIPTS = STREX / 'manifests/pce_cinematic_transcripts.json'
SUBTITLES = STREX / 'manifests/subtitles.json'
SEPARATIONS = STREX / 'references/separations'
DURABLE = Path('references/striderex/separations')
SECTOR, RATE = (2352, 44100)
TRACKS = tuple(range(21, 30))
VERSION = 1
MODELS = {'htdemucs_ft': dict(kind='hub', files={'04573f0d-f3cf25b2.th': 'f3cf25b222c4eed7cd49dd8b2c9597d50c18bd154090f7b919cfa5f93cf22c49', '92cfc3b6-ef3bcb9c.th': 'ef3bcb9c8b40d14ae5d51b6db2587339cc12c6b77c0be151ce6d69002e087bf2', 'd12395a8-e57c48e6.th': 'e57c48e6b0e38af4f7118d7bd08c49f0a0c0edf7d09143bdd902ea0d237303e6', 'f7e0c4bc-ba3fe64a.th': 'ba3fe64ae8ef66ac9a4857222ce48efbdc5eb3ad375cb79dd13debee5aaa4066'}), 'htdemucs_6s': dict(kind='safetensors', repo='adefossez/HTDemucs-6s', revision='3c5ee475be622df764938de97e4281a7b07ffa58', file='5c90dfd2.safetensors', sha256='d2a1745f0744721f6b8ca5bf469b67c651ea5ed1b52998cab033b2158609d411')}

def manifest():
    return json.loads(MANIFEST.read_text())

def sha256(b):
    return hashlib.sha256(b).hexdigest()

def cue_tracks(cue):
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    from cinematic_transcripts import cue_tracks as ct
    return ct(cue)

def disc_pcm(cue, track, pinned=None):
    """Track PCM from INDEX 01 as float32 (2, n), checked against its pin."""
    import numpy as np
    bin_path, index01 = cue_tracks(cue)[track]
    raw = bin_path.read_bytes()[round(index01 * 75) * SECTOR:]
    raw = raw[:len(raw) // 4 * 4]
    if pinned is not None and sha256(raw) != pinned:
        sys.exit(f'track {track}: PCM SHA-256 {sha256(raw)} does not match the pinned {pinned} (manifests/dub_beds.json); restore the disc from its archive')
    return np.frombuffer(raw, '<i2').reshape(-1, 2).T.astype(np.float32) / 32768

def speech_segments(track):
    data = json.loads(TRANSCRIPTS.read_text())
    for t in data['tracks']:
        if t['track'] == track:
            return [(s['start'], s['end']) for s in t['segments']]
    return []

def write_wav16(path, x):
    import numpy as np
    pcm = np.clip(np.round(x.T * 32768), -32768, 32767).astype('<i2')
    path.parent.mkdir(parents=True, exist_ok=True)
    with wave.open(str(path), 'wb') as w:
        w.setnchannels(pcm.shape[1])
        w.setsampwidth(2)
        w.setframerate(RATE)
        w.writeframes(pcm.tobytes())

def read_wav16(path):
    import numpy as np
    with wave.open(str(path), 'rb') as w:
        assert w.getsampwidth() == 2 and w.getframerate() == RATE, path
        ch = w.getnchannels()
        x = np.frombuffer(w.readframes(w.getnframes()), '<i2').reshape(-1, ch).T
    return x.astype(np.float32) / 32768

def file_digest(path):
    return sha256(Path(path).read_bytes())

def variant_name(model, shifts, overlap):
    return f'{model}_s{shifts}_o{int(round(overlap * 100))}'

def read_safetensors(path):
    """Minimal safetensors reader (the Demucs env has no safetensors package)."""
    import numpy as np
    import torch
    data = Path(path).read_bytes()
    n = int.from_bytes(data[:8], 'little')
    header = json.loads(data[8:8 + n])
    meta = header.pop('__metadata__', {})
    base = 8 + n
    dtypes = {'F32': np.float32, 'F16': np.float16, 'I64': np.int64}
    state = {}
    for name, info in header.items():
        a, b = info['data_offsets']
        arr = np.frombuffer(data[base + a:base + b], dtypes[info['dtype']]).reshape(info['shape'])
        state[name] = torch.from_numpy(arr.copy())
    return (meta, state)

def load_model(name, torch_home, hf_home):
    import fractions
    import os
    os.environ['TORCH_HOME'] = str(torch_home)
    import torch
    spec = MODELS[name]
    if spec['kind'] == 'hub':
        ckpt = Path(torch_home) / 'hub' / 'checkpoints'
        for f, digest in spec['files'].items():
            p = ckpt / f
            if not p.exists():
                sys.exit(f'{name}: checkpoint {p} is missing. It would be downloaded from https://dl.fbaipublicfiles.com/demucs/; ask before downloading.')
            if file_digest(p) != digest:
                sys.exit(f'{name}: {p} SHA-256 does not match {digest}')
        from demucs.pretrained import get_model
        return (get_model(name), {f: d for f, d in spec['files'].items()})
    snap = Path(hf_home) / 'hub' / ('models--' + spec['repo'].replace('/', '--')) / 'snapshots' / spec['revision'] / spec['file']
    if not snap.exists():
        sys.exit(f"{name}: {snap} is missing. It is {spec['repo']} on Hugging Face (revision {spec['revision']}, about 55 MB); ask before downloading.")
    if file_digest(snap) != spec['sha256']:
        sys.exit(f"{name}: {snap} SHA-256 does not match {spec['sha256']}")
    meta, state = read_safetensors(snap)
    from demucs.htdemucs import HTDemucs
    assert meta['klass'] == 'demucs.htdemucs.HTDemucs', meta['klass']
    kwargs = json.loads(meta['kwargs'])
    for k, v in list(kwargs.items()):
        if isinstance(v, dict) and v.get('_type') == 'fraction':
            kwargs[k] = fractions.Fraction(v['numerator'], v['denominator'])
    model = HTDemucs(*json.loads(meta['args']), **kwargs)
    model.load_state_dict(state)
    return (model, {spec['file']: spec['sha256']})

def separate(a):
    import random
    import numpy as np
    import torch
    from demucs.apply import apply_model
    man = manifest()
    model, ckpts = load_model(a.model, a.torch_home, a.hf_home)
    model.eval()
    variant = variant_name(a.model, a.shifts, a.overlap)
    out = a.workdir / 'sep' / variant
    out.mkdir(parents=True, exist_ok=True)
    rep_path = out / 'separation.json'
    rep = json.loads(rep_path.read_text()) if rep_path.exists() else {}
    key = dict(version=VERSION, model=a.model, checkpoints=ckpts, shifts=a.shifts, overlap=a.overlap, device='cpu', seed=0, torch=torch.__version__)
    if rep.get('key') != key:
        rep = dict(key=key, sources=list(model.sources), tracks={})
    torch.set_num_threads(a.threads) if a.threads else None
    for t in a.tracks:
        pin = man['inputs']['tracks'][str(t)]['pcm_sha256']
        row = rep['tracks'].get(str(t))
        files = {s: out / f'tr{t:02d}_{s}.npy' for s in ('vocals', 'rest')}
        if row and row['pcm_sha256'] == pin and all((p.exists() and file_digest(p) == row[s] for s, p in files.items())):
            print(f'tr{t}: cached {variant}')
            continue
        pcm = disc_pcm(a.cue, t, pin)
        torch.manual_seed(0)
        random.seed(0)
        wav = torch.from_numpy(pcm)
        ref = wav.mean(0)
        x = (wav - ref.mean()) / ref.std()
        with torch.no_grad():
            y = apply_model(model, x[None], device='cpu', shifts=a.shifts, split=True, overlap=a.overlap, progress=False)[0]
        y = (y * ref.std() + ref.mean()).numpy().astype(np.float32)
        vi = list(model.sources).index('vocals')
        stems = dict(vocals=y[vi], rest=sum((y[i] for i in range(len(model.sources)) if i != vi)).astype(np.float32))
        row = dict(pcm_sha256=pin)
        for s, p in files.items():
            np.save(p, stems[s])
            row[s] = file_digest(p)
        rep['tracks'][str(t)] = row
        rep_path.write_text(json.dumps(rep, indent=1) + '\n')
        print(f'tr{t}: separated with {variant}')
    rep_path.write_text(json.dumps(rep, indent=1) + '\n')
    return 0

def _window(n):
    import numpy as np
    return np.sqrt(0.5 - 0.5 * np.cos(2 * np.pi * np.arange(n) / n))

def stft(x, n, hop):
    """Frames centred at i*hop - n/2 (samples); sqrt-Hann analysis."""
    import numpy as np
    w = _window(n)
    xp = np.pad(x.astype(np.float64), (n, n + hop))
    fr = np.lib.stride_tricks.sliding_window_view(xp, n)[::hop]
    return np.fft.rfft(fr * w, axis=1).astype(np.complex64)

def istft(S, length, n, hop):
    """Weighted overlap-add inverse of stft(); a frame block of zeros gives exact zeros."""
    import numpy as np
    w = _window(n)
    y = np.fft.irfft(S.astype(np.complex128), n, axis=1) * w
    total = hop * (len(S) - 1) + n
    out = np.zeros(total)
    norm = np.zeros(total)
    for i in range(len(S)):
        out[i * hop:i * hop + n] += y[i]
        norm[i * hop:i * hop + n] += w * w
    out = np.divide(out, norm, out=np.zeros_like(out), where=norm > 1e-09)
    return out[n:n + length]

def frame_times(frames, n, hop):
    import numpy as np
    return (np.arange(frames) * hop - n / 2) / RATE

def raised_cosine(x):
    import numpy as np
    x = np.clip(x, 0.0, 1.0)
    return 0.5 - 0.5 * np.cos(np.pi * x)

def runs(mask, times):
    """Contiguous True runs of a frame mask as (start s, end s, first, last)."""
    out, i, n = ([], 0, len(mask))
    while i < n:
        if mask[i]:
            j = i
            while j + 1 < n and mask[j + 1]:
                j += 1
            out.append([float(times[i]), float(times[j]), i, j])
            i = j + 1
        else:
            i += 1
    return out

def merge(spans, gap):
    out = []
    for s in sorted(spans, key=lambda r: r[0]):
        if out and s[0] - out[-1][1] < gap:
            out[-1][1] = max(out[-1][1], s[1])
            out[-1][2] = min(out[-1][2], s[2])
            out[-1][3] = max(out[-1][3], s[3])
        else:
            out.append(list(s))
    return out

def gate_curve(times, regions, p):
    """1 inside each region [start - pre, end + post], raised-cosine ramps outside it."""
    import numpy as np
    g = np.zeros(len(times))
    for s, e in regions:
        a, b = (s - p['pre'], e + p['post'])
        up = raised_cosine((times - (a - p['ramp_in'])) / p['ramp_in'])
        down = 1 - raised_cosine((times - b) / p['ramp_out'])
        g = np.maximum(g, np.where(times < a, up, np.where(times > b, down, 1.0)))
    return g

def band_mask(freqs, lo, hi):
    return (freqs >= lo) & (freqs < hi)

def db(x):
    import numpy as np
    return 10 * np.log10(np.maximum(x, 1e-20))

def _biquads(fs=RATE):
    f0, g, q = (1681.974450955533, 3.999843853973347, 0.7071752369554196)
    k = math.tan(math.pi * f0 / fs)
    vh, vb = (10 ** (g / 20), (10 ** (g / 20)) ** 0.4996667741545416)
    a0 = 1 + k / q + k * k
    shelf = ([(vh + vb * k / q + k * k) / a0, 2 * (k * k - vh) / a0, (vh - vb * k / q + k * k) / a0], [1.0, 2 * (k * k - 1) / a0, (1 - k / q + k * k) / a0])
    f0, q = (38.13547087602444, 0.5003270373238773)
    k = math.tan(math.pi * f0 / fs)
    a0 = 1 + k / q + k * k
    hp = ([1.0, -2.0, 1.0], [1.0, 2 * (k * k - 1) / a0, (1 - k / q + k * k) / a0])
    return (shelf, hp)

def lfilter(b, a, x):
    import numpy as np
    try:
        from scipy.signal import lfilter as lf
        return lf(b, a, x)
    except ImportError:
        pass
    try:
        import torch
        import torchaudio.functional as F
        y = F.lfilter(torch.from_numpy(np.asarray(x, np.float64))[None], torch.tensor(a, dtype=torch.float64), torch.tensor(b, dtype=torch.float64), clamp=False)[0]
        return y.numpy()
    except ImportError:
        sys.exit('lfilter needs scipy (repository venv) or torchaudio (Demucs env)')

def k_weight(x):
    """x: (channels, n) -> K-weighted copy."""
    import numpy as np
    (b1, a1), (b2, a2) = _biquads()
    return np.stack([lfilter(b2, a2, lfilter(b1, a1, c)) for c in np.atleast_2d(x)])

def loudness(x, spans=None, kw=None):
    """Gated integrated loudness (LUFS, BS.1770-4) of x (channels, n), optionally only over spans (s)."""
    import numpy as np
    y = k_weight(x) if kw is None else kw
    blk, step = (int(0.4 * RATE), int(0.1 * RATE))
    if spans is None:
        spans = [(0, y.shape[1] / RATE)]
    zs = []
    for s, e in spans:
        a, b = (max(0, int(s * RATE)), min(y.shape[1], int(e * RATE)))
        if b - a < blk:
            if b - a > RATE // 50:
                zs.append((y[:, a:b] ** 2).mean(1).sum())
            continue
        for i in range(a, b - blk + 1, step):
            zs.append((y[:, i:i + blk] ** 2).mean(1).sum())
    zs = np.array(zs)
    if not len(zs):
        return None
    lk = -0.691 + 10 * np.log10(np.maximum(zs, 1e-20))
    zs = zs[lk > -70]
    if not len(zs):
        return None
    rel = -0.691 + 10 * np.log10(zs.mean()) - 10
    lk = -0.691 + 10 * np.log10(np.maximum(zs, 1e-20))
    zs = zs[lk > rel]
    return round(float(-0.691 + 10 * np.log10(zs.mean())), 2)

def subtitle_lines(track):
    data = json.loads(SUBTITLES.read_text())
    return [dict(id=l['id'], start=l['start'], end=l['end'], speaker=l['speaker']) for l in data['lines'] if l['track'] == track and (not l.get('dub_only'))]

def ensemble_vocals(F, p, wmax=None):
    """Cleaned vocal estimate per channel: per bin the smallest magnitude any model gives"""
    import numpy as np
    freqs = np.fft.rfftfreq(p['n_fft'], 1 / RATE)
    lo0, lo1 = p['f_low']
    wf = raised_cosine((freqs - lo0) / (lo1 - lo0)).astype(np.float32)
    mags = [np.abs(v) for v in F['vocals']]
    mm = np.abs(F['mix'])
    lo = np.minimum(np.minimum.reduce(mags), mm)
    if wmax is not None and np.any(wmax > 0):
        hi = np.minimum(np.maximum.reduce(mags), mm)
        w = wmax.astype(np.float32)[:, None]
        mag = (1 - w) * lo + w * hi
    else:
        mag = lo
    big = np.argmax(np.stack(mags), 0)
    pick = np.take_along_axis(np.stack(F['vocals']), big[None], 0)[0]
    ph = pick / np.maximum(np.abs(pick), 1e-12)
    return mag * wf[None, :] * ph

def model_disagreement(lines, F, times, p):
    """Per line: speech-band (300-3400 Hz) vocal power of each model over the segment, in dB"""
    import numpy as np
    freqs = np.fft.rfftfreq(p['n_fft'], 1 / RATE)
    sb = band_mask(freqs, 300, 3400)
    out = {}
    for l in lines:
        m = (times >= l['start']) & (times <= l['end'])
        if not m.any():
            continue
        pw = [sum(((np.abs(F[c]['vocals'][k][m][:, sb]) ** 2).sum() for c in range(2))) for k in range(len(F[0]['vocals']))]
        rel = [round(float(db(x) - db(pw[0])), 1) for x in pw]
        out[l['id']] = dict(models_db=rel, ensemble='max' if max(rel) - min(rel) > p['disagree_db'] else 'min')
    return out

def max_weight(lines, choice, times, p):
    """Per-frame weight of the 'max' ensemble: 1 over each 'max' line's window, 0.1 s ramps."""
    import numpy as np
    w = np.zeros(len(times))
    for l, (lo, hi) in zip(lines, line_windows(lines, p)):
        if choice.get(l['id'], {}).get('ensemble') == 'max':
            up = raised_cosine((times - (lo - 0.1)) / 0.1)
            down = 1 - raised_cosine((times - hi) / 0.1)
            w = np.maximum(w, np.where(times < lo, up, np.where(times > hi, down, 1.0)))
    return w

def line_windows(lines, p):
    """Search window per line: attach seconds either side, never past the midpoint to a neighbour."""
    out = []
    for k, l in enumerate(lines):
        lo = l['start'] - p['attach'] if k == 0 else max(l['start'] - p['attach'], (lines[k - 1]['end'] + l['start']) / 2)
        hi = l['end'] + p['attach'] if k == len(lines) - 1 else min(l['end'] + p['attach'], (l['end'] + lines[k + 1]['start']) / 2)
        out.append((lo, hi))
    return out

def voice_regions(lines, Pv, Pm, times, p):
    """Voice regions: every transcribed line's segment, widened to the vocal activity found near"""
    import numpy as np
    ev, em = (db(Pv), db(Pm))
    share = ev - em
    wins = line_windows(lines, p)
    raw, regions, refs = ([], [], [])
    for l, (lo, hi) in zip(lines, wins):
        inl = (times >= l['start']) & (times <= l['end'])
        ref = float(np.percentile(ev[inl], 95)) if inl.any() else float(ev.max())
        refs.append(ref)
        w = (times >= lo) & (times <= hi)
        act = w & (ev > ref - p['vad_below_peak_db']) & (share > p['vad_share_db'])
        rs = [r for r in runs(act, times) if r[1] - r[0] >= p['min_run']]
        s = min([l['start'] - p['line_pad'][0]] + [r[0] for r in rs])
        e = max([l['end'] + p['line_pad'][1]] + [r[1] for r in rs])
        s, e = (max(s, lo), min(e, hi))
        raw += [(r[0], r[1], l['id']) for r in rs]
        regions.append([s, e, [l['id']]])
    tref = float(np.median(refs)) if refs else float(ev.max())
    inwin = np.zeros(len(times), bool)
    for lo, hi in wins:
        inwin |= (times >= lo) & (times <= hi)
    act = ~inwin & (ev > tref - p['vad_below_peak_db']) & (share > p['vad_share_db'])
    extra = merge([list(r) for r in runs(act, times) if r[1] - r[0] >= p['min_run']], p['merge_gap'])
    out = []
    for s, e, ids in sorted(regions, key=lambda r: r[0]):
        if out and s - out[-1]['end'] < p['merge_gap'] and out[-1]['lines']:
            out[-1]['end'] = max(out[-1]['end'], e)
            out[-1]['lines'] += ids
        else:
            out.append(dict(start=s, end=e, lines=list(ids), action='remove'))
    for s, e, i, j in extra:
        peak = float(ev[i:j + 1].max())
        med = float(np.median(share[i:j + 1]))
        voice = tref - peak <= p['untranscribed_peak_db'] and e - s >= p['untranscribed_min'] and (med >= p['untranscribed_share_db'])
        out.append(dict(start=s, end=e, lines=[], peak_below_ref_db=round(tref - peak, 1), median_share_db=round(med, 1), action='remove' if voice else 'keep'))
    for r in out:
        r['start'], r['end'] = (round(r['start'], 3), round(r['end'], 3))
    out.sort(key=lambda r: r['start'])
    return (out, tref, raw)

def track_bed(lines, mix, stems, p):
    """Repaired bed, the gate, and per-frame powers for the measures."""
    import numpy as np
    n, hop = (p['n_fft'], p['hop'])
    length = mix.shape[1]
    F = [dict(mix=stft(mix[c], n, hop), vocals=[stft(v[c], n, hop) for v in stems]) for c in range(2)]
    times = frame_times(len(F[0]['mix']), n, hop)
    choice = model_disagreement(lines, F, times, p)
    wmax = max_weight(lines, choice, times, p)
    Ve = [ensemble_vocals(F[c], p, wmax) for c in range(2)]
    freqs = np.fft.rfftfreq(n, 1 / RATE)
    vb = band_mask(freqs, *p['vad_band'])
    Pv = sum(((np.abs(Ve[c][:, vb]) ** 2).sum(1) for c in range(2)))
    Pm = sum(((np.abs(F[c]['mix'][:, vb]) ** 2).sum(1) for c in range(2)))
    regions, ref, raw = voice_regions(lines, Pv, Pm, times, p)
    removed = [(r['start'], r['end']) for r in regions if r['action'] == 'remove']
    g = gate_curve(times, removed, p).astype(np.float32)
    bed = np.stack([mix[c] - istft(Ve[c] * g[:, None], length, n, hop) for c in range(2)]).astype(np.float32)
    voice = (mix - bed).astype(np.float32)
    for r in regions:
        r['ensemble'] = sorted({choice.get(i, {}).get('ensemble', 'min') for i in r['lines']}) or ['min']
    return (bed, voice, g, times, regions, ref, raw, choice)

def support(g, times, n, hop, length):
    """Sample mask of where the gated vocal estimate can be non-zero."""
    import numpy as np
    m = np.zeros(length, bool)
    for i in np.nonzero(g > 0)[0]:
        a = max(0, i * hop - n)
        m[a:min(length, a + n)] = True
    return m
MEASURE_N, MEASURE_HOP = (4096, 2205)

def power_spec(x):
    """Channel-summed power spectrogram on the 50 ms measure grid."""
    import numpy as np
    return sum((np.abs(stft(x[c], MEASURE_N, MEASURE_HOP)) ** 2 for c in range(x.shape[0])))

def band_power(S, band):
    import numpy as np
    freqs = np.fft.rfftfreq(MEASURE_N, 1 / RATE)
    return S[:, band_mask(freqs, *band)].sum(1)

def measures(mix, bed, regions, sup, p, Sm=None):
    """Measures of a bed against the mix, away from the voice and under it."""
    import numpy as np
    Sm = power_spec(mix) if Sm is None else Sm
    Sb = power_spec(bed)
    Pm, Pb = (band_power(Sm, (20, 20000)), band_power(Sb, (20, 20000)))
    times = frame_times(len(Pm), MEASURE_N, MEASURE_HOP)
    invoice = np.zeros(len(times), bool)
    for r in regions:
        if r['action'] == 'remove':
            a, b = (r['start'] - p['pre'] - p['ramp_in'], r['end'] + p['post'] + p['ramp_out'])
            invoice |= (times >= a - 0.05) & (times <= b + 0.05)
    loud = db(Pm) > db(Pm.max()) - 60
    off = ~invoice & loud
    out = {}
    d = db(Pb) - db(Pm)
    drops = runs(off & (d < -3), times)
    out['off_voice'] = dict(frames=int(off.sum()), median_db=round(float(np.median(d[off])), 2) if off.any() else None, drops_below_3db=len(drops), worst_db=round(float(d[off].min()), 1) if off.any() else None)
    Pms, Pbs = (band_power(Sm, (300, 3400)), band_power(Sb, (300, 3400)))
    out['speech_band_cut_db'] = round(float(db(Pbs[invoice].sum()) - db(Pms[invoice].sum())), 2) if invoice.any() else None
    Pml, Pbl = (band_power(Sm, (20, 80)), band_power(Sb, (20, 80)))
    sig = invoice & (db(Pml) > db(Pm) - 30)
    out['under_voice_bass_kept_db'] = round(float(db(Pbl[sig].sum()) - db(Pml[sig].sum())), 2) if sig.any() else None
    Pmh, Pbh = (band_power(Sm, (8000, 20000)), band_power(Sb, (8000, 20000)))
    sig = invoice & (db(Pmh) > db(Pm) - 40)
    out['under_voice_air_kept_db'] = round(float(db(Pbh[sig].sum()) - db(Pmh[sig].sum())), 2) if sig.any() else None
    mixi = np.round(mix * 32768)
    bedi = np.clip(np.round(bed * 32768), -32768, 32767)
    outside = ~sup
    out['samples_outside_voice'] = int(outside.sum())
    out['samples_changed_outside_voice'] = int((mixi[:, outside] != bedi[:, outside]).any(0).sum())
    return out

def cutouts(trial, bed, mix, p, min_depth=6.0, min_len=0.08, Sm=None):
    """Where the trial bed lost music that the repaired bed keeps (50 ms frames, 150-6000 Hz)."""
    import numpy as np
    band = (150, 6000)
    Pt, Pb = (band_power(power_spec(trial), band), band_power(power_spec(bed), band))
    Pm = band_power(power_spec(mix) if Sm is None else Sm, band)
    times = frame_times(len(Pt), MEASURE_N, MEASURE_HOP)
    loud = db(Pb) > db(Pm.max()) - 55
    depth = db(Pb) - db(Pt)
    ev = []
    for s, e, i, j in runs(loud & (depth >= min_depth), times):
        ev.append([s, e, i, j])
    ev = [r for r in merge(ev, 0.15) if r[1] - r[0] + 0.05 >= min_len]
    return [dict(start=round(s, 2), end=round(e + 0.05, 2), depth_db=round(float(depth[i:j + 1].max()), 1), mean_depth_db=round(float(depth[i:j + 1].mean()), 1)) for s, e, i, j in ev]

def residual_asr(paths):
    """Speech still recognised in each bed (faster-whisper large-v3, the transcripts' settings)."""
    from faster_whisper import WhisperModel
    model = WhisperModel('large-v3', device='cpu', compute_type='int8')
    out = {}
    for key, path in paths.items():
        segs, _ = model.transcribe(str(path), language='ja', beam_size=5, temperature=0.0, vad_filter=True, condition_on_previous_text=False)
        segs = [dict(start=round(s.start, 2), end=round(s.end, 2), text=s.text.strip()) for s in segs]
        out[key] = dict(segments=len(segs), characters=sum((len(s['text']) for s in segs)), lines=segs)
    return out

def stems_ok(d, track, pcm_sha256):
    """True when <d> holds digest-checked stems of this track's pinned PCM."""
    rp = d / 'separation.json'
    if not rp.exists():
        return False
    row = json.loads(rp.read_text())['tracks'].get(str(track))
    if not row or row['pcm_sha256'] != pcm_sha256:
        return False
    return all(((d / f'tr{track:02d}_{s}.npy').exists() and file_digest(d / f'tr{track:02d}_{s}.npy') == row[s] for s in ('vocals', 'rest')))

def load_stems(a, variants, track, man_track):
    """The separation cache, rebuilt with the Demucs env (--demucs-python) when it is missing or"""
    import re
    import subprocess
    import numpy as np
    stems, rests = ([], [])
    external = manifest()['inputs'].get('external_separations', {})
    for v in variants:
        if v in external:
            vocals, other = external_stems(v, external[v], track)
            stems.append(vocals)
            rests.append(other)
            continue
        d = Path(a.workdir) / 'sep' / v
        if not stems_ok(d, track, man_track['pcm_sha256']):
            m = re.fullmatch('(.+)_s(\\d+)_o(\\d+)', v)
            cmd = ['separate', '--model', m.group(1), '--shifts', m.group(2), '--overlap', str(int(m.group(3)) / 100), '--workdir', str(a.workdir), '--cue', str(a.cue), '--tracks', str(track)]
            if not a.demucs_python or not a.torch_home:
                sys.exit(f"tr{track}: no {v} separation for the pinned PCM. Run it with the Demucs env:\n  <env>/venv/bin/python {Path(__file__)} {' '.join(cmd)} --torch-home <env>/torch_home\nor pass --demucs-python and --torch-home to repair")
            cmd += ['--torch-home', str(a.torch_home), '--hf-home', str(a.hf_home)]
            subprocess.run([str(a.demucs_python), str(Path(__file__).resolve())] + cmd, check=True)
            if not stems_ok(d, track, man_track['pcm_sha256']):
                sys.exit(f'tr{track}: {v} separation failed its digest check')
        stems.append(np.load(d / f'tr{track:02d}_vocals.npy'))
        rests.append(np.load(d / f'tr{track:02d}_rest.npy'))
    return (stems, rests)

def store_roots():
    """Where stored separations are looked for, in order: STREX_SEPARATIONS, the durable"""
    import os
    roots = [Path(os.environ['STREX_SEPARATIONS'])] if os.environ.get('STREX_SEPARATIONS') else []
    roms = ROOT / 'roms'
    if roms.exists():
        roots.append(roms.resolve().parent / DURABLE)
    return roots + [SEPARATIONS]

def store_dir(variant, for_writing=False):
    """The variant's directory: the first root that has it (to read), or the first root"""
    roots = store_roots()
    for r in roots:
        if (r / variant).is_dir():
            return r / variant
    if for_writing:
        for r in roots:
            if r.parent.is_dir():
                return r / variant
    return roots[0] / variant

def external_stems(variant, spec, track):
    """A stored separation's (vocals, other) for one track, each checked against its pinned SHA-256."""
    row = spec['tracks'].get(str(track))
    if row is None:
        sys.exit(f'tr{track}: the {variant} separation has no stems for this track')
    out = []
    for kind in ('vocals', 'other'):
        f = store_dir(variant) / row[kind]['file']
        if not f.exists() or file_digest(f) != row[kind]['sha256']:
            sys.exit(f"tr{track}: {f} is missing or not the pinned {row[kind]['sha256'][:16]} (looked in {', '.join((str(r) for r in store_roots()))}); it is the {spec['source']} (original name {row[kind]['original_name']}). Put it back with\n  venv/bin/python {Path(__file__)} import --from <dir with the downloads> --variant {variant} --cue <cue>\n(references/separations/README.md)")
        out.append(read_wav16(f))
    return out

def export_tracks(a):
    """The pinned dialogue tracks as WAVs, named as the store's import expects back."""
    man = manifest()
    a.out.mkdir(parents=True, exist_ok=True)
    for t in a.tracks:
        mt = man['inputs']['tracks'][str(t)]
        if mt.get('dialogue', True):
            f = a.out / f"track{t}_{mt['id']}_original_mix.wav"
            write_wav16(f, disc_pcm(a.cue, t, mt['pcm_sha256']))
            print(f.name)
    return 0

def import_stems(a):
    """Check a separation made elsewhere against the disc and take it into the reference store."""
    import re
    import shutil
    import numpy as np
    man = manifest()
    if not a.variant or not a.source_dir:
        sys.exit('import needs --variant and --from')
    found = {}
    for f in sorted(Path(a.source_dir).iterdir()):
        m = re.search('track(\\d\\d)[-_].*_(vocals|other)_', f.name)
        if m and f.suffix.lower() == '.wav':
            found.setdefault(int(m.group(1)), {})[m.group(2)] = f
    spec = man['inputs'].setdefault('external_separations', {}).setdefault(a.variant, {})
    spec.update(source=a.source or spec.get('source', ''), store=f'{DURABLE / a.variant} beside the roms/ link target (or STREX_SEPARATIONS)')
    rows = spec.setdefault('tracks', {})
    dest = store_dir(a.variant, for_writing=True)
    dest.mkdir(parents=True, exist_ok=True)
    ok = True
    for t in a.tracks:
        mt = man['inputs']['tracks'][str(t)]
        if not mt.get('dialogue', True):
            continue
        pair = found.get(t, {})
        if set(pair) != {'vocals', 'other'}:
            print(f'tr{t}: no vocals/other pair in {a.source_dir}')
            ok = False
            continue
        mix = disc_pcm(a.cue, t, mt['pcm_sha256'])
        v, o = (read_wav16(pair['vocals']), read_wav16(pair['other']))
        if v.shape != mix.shape or o.shape != mix.shape:
            print(f'tr{t}: stems are {v.shape[1]}/{o.shape[1]} samples, the track {mix.shape[1]}')
            ok = False
            continue
        resid = db(float(((mix - v - o) ** 2).sum())) - db(float((mix ** 2).sum()))
        if resid > -50:
            print(f'tr{t}: vocals + other differ from the disc mix by {resid:.1f} dB (not this track, or shifted)')
            ok = False
            continue
        row = {}
        for kind, f in pair.items():
            name = f'tr{t:02d}_{kind}.wav'
            shutil.copyfile(f, dest / name)
            row[kind] = dict(file=name, original_name=f.name, sha256=file_digest(dest / name))
        row['residual_db'] = round(resid, 1)
        rows[str(t)] = row
        print(f'tr{t}: stored; vocals + other = the disc mix to {resid:.1f} dB')
    MANIFEST.write_text(json.dumps(man, ensure_ascii=False, indent=1) + '\n')
    return 0 if ok else 1

def repair(a):
    """Build, measure and (optionally) check the beds; with --clips also the review clips."""
    import numpy as np
    man = manifest()
    p = man['params']
    out = a.workdir / 'beds'
    out.mkdir(parents=True, exist_ok=True)
    report = dict(version=VERSION, params=p, tracks={})
    asr_paths = {}
    clip_rows = []
    for t in a.tracks:
        mt = man['inputs']['tracks'][str(t)]
        mix = disc_pcm(a.cue, t, mt['pcm_sha256'])
        row = dict(id=mt['id'])
        if not mt.get('dialogue', True):
            bed = mix
            row.update(dialogue=False, note=mt.get('note', 'no dialogue: the bed is the original track'))
        else:
            lines = subtitle_lines(t)
            stems, rests = load_stems(a, p['variants'], t, mt)
            bed, voice, g, times, regions, ref, raw, choice = track_bed(lines, mix, stems, p)
            sup = support(g, times, p['n_fft'], p['hop'], mix.shape[1])
            trial = rests[0]
            Sm = power_spec(mix)
            row['voice_ref_db'] = round(ref, 1)
            row['regions'] = regions
            row['trial'] = measures(mix, trial, regions, sup, p, Sm)
            row['repaired'] = measures(mix, bed, regions, sup, p, Sm)
            row['cutouts_fixed'] = cutouts(trial, bed, mix, p, Sm=Sm)
            row['lines'] = line_levels(lines, mix, bed, voice, raw, p, choice)
            tpath = a.workdir / 'trial' / f'tr{t:02d}_trial.wav'
            write_wav16(tpath, trial)
            asr_paths[f'{t}:trial'] = tpath
            vpath = a.workdir / 'trial' / f'tr{t:02d}_vocals.wav'
            write_wav16(vpath, stems[0])
            asr_paths[f'{t}:vocals'] = vpath
            if a.clips:
                clip_rows += make_clips(a.clips, t, mt['id'], mix, trial, bed, row['cutouts_fixed'], regions)
        path = out / f'tr{t:02d}_bed.wav'
        write_wav16(path, bed)
        row['bed_sha256'] = file_digest(path)
        row['bed_lufs'] = loudness(bed)
        row['mix_lufs'] = loudness(mix)
        if mt.get('dialogue', True):
            asr_paths[f'{t}:bed'] = path
        report['tracks'][str(t)] = row
        r = row.get('repaired', {})
        print(f"tr{t}: bed {row['bed_sha256'][:12]}; regions {len(row.get('regions', []))}; cut-outs fixed {len(row.get('cutouts_fixed', []))}; repaired {r}")
        (out / 'report.json').write_text(json.dumps(report, ensure_ascii=False, indent=1) + '\n')
    if a.asr:
        res = residual_asr(asr_paths)
        for key, v in res.items():
            t, kind = key.split(':')
            if kind == 'vocals':
                segs = [(l['start'], l['end']) for l in subtitle_lines(int(t))]
                v['untranscribed'] = [x for x in v['lines'] if not any((x['start'] < e and x['end'] > s for s, e in segs))]
            report['tracks'][t][f'asr_{kind}'] = v
            extra = f"; untranscribed {v['untranscribed']}" if kind == 'vocals' else ''
            print(f"tr{t} {kind}: ASR {v['segments']} segments, {v['characters']} characters{extra}")
    (out / 'report.json').write_text(json.dumps(report, ensure_ascii=False, indent=1) + '\n')
    if a.clips:
        write_clip_index(a.clips, clip_rows, report)
    rc = 0
    if a.pin:
        pin_outputs(man, report, a.tracks)
    if a.check:
        pins = man.get('outputs', {}).get('beds', {})
        for t in a.tracks:
            want = pins.get(str(t), {}).get('sha256')
            got = report['tracks'][str(t)]['bed_sha256']
            ok = want == got
            rc |= 0 if ok else 1
            print(f"tr{t}: bed {got[:16]} {('matches' if ok else 'DIFFERS from')} the pin {str(want)[:16]}")
    return rc

def pin_outputs(man, report, tracks):
    """Record the bed digests and the per-line Japanese references in the manifest."""
    outs = man.setdefault('outputs', {}).setdefault('beds', {})
    ref = man.setdefault('reference', {})
    ref['note'] = 'Japanese voice span and levels per line, measured by dub_beds.py repair (voice = mix - bed): the targets dub_mix.py matches. LUFS are BS.1770-4 gated loudness over the span.'
    lines = ref.setdefault('lines', {})
    for t in tracks:
        row = report['tracks'][str(t)]
        outs[str(t)] = dict(sha256=row['bed_sha256'], lufs=row['bed_lufs'], mix_lufs=row['mix_lufs'])
        for lid, v in row.get('lines', {}).items():
            lines[lid] = v
    MANIFEST.write_text(json.dumps(man, ensure_ascii=False, indent=1) + '\n')
    print(f"pinned {len(tracks)} beds and {sum((len(report['tracks'][str(t)].get('lines', {})) for t in tracks))} line references in {MANIFEST.relative_to(ROOT)}")

def line_levels(lines, mix, bed, voice, raw, p, choice=None):
    """Per line: the Japanese voice span (the vocal activity found for the line, else its"""
    kv, kb, km = (k_weight(voice), k_weight(bed), k_weight(mix))
    rows = {}
    for l in lines:
        near = [(s, e) for s, e, lid in raw if lid == l['id']]
        models = (choice or {}).get(l['id'])
        s, e = (min((x for x, _ in near)), max((y for _, y in near))) if near else (l['start'], l['end'])
        span = [(s, e)]
        seg = voice[:, int(s * RATE):int(e * RATE)].astype('float64')
        bal = 10 * math.log10(max((seg[0] ** 2).sum(), 1e-20) / max((seg[1] ** 2).sum(), 1e-20)) if seg.size else 0.0
        rows[l['id']] = dict(voice_start=round(s, 2), voice_end=round(e, 2), ja_voice_lufs=loudness(voice, span, kv), ja_mix_lufs=loudness(mix, span, km), bed_lufs=loudness(bed, span, kb), ja_balance_db=round(bal, 2))
        if models:
            rows[l['id']]['ensemble'] = models['ensemble']
            rows[l['id']]['models_db'] = models['models_db']
    return rows
CLIP_PAD, CLIP_GAP, CLIP_MAX, CLIPS_PER_TRACK = (1.0, 0.4, 4.0, 3)

def make_clips(outdir, track, name, mix, trial, bed, events, regions=()):
    """Short before/after WAVs at the deepest former cut-outs: mix, trial bed, repaired bed."""
    import numpy as np
    outdir = Path(outdir)
    groups = merge([[e['start'], e['end'], k, k] for k, e in enumerate(events)], 1.5)
    scored = []
    for s, e, i, j in groups:
        evs = events[i:j + 1]
        score = sum(((x['end'] - x['start']) * x['mean_depth_db'] for x in evs))
        scored.append((score, s, e, max((x['depth_db'] for x in evs))))
    scored = sorted(scored, reverse=True)[:CLIPS_PER_TRACK]
    rows = []
    n = mix.shape[1]
    gap = np.zeros((2, int(CLIP_GAP * RATE)), np.float32)
    for k, (score, s, e, depth) in enumerate(sorted(scored, key=lambda r: r[1])):
        c = (s + e) / 2
        half = min(CLIP_MAX, e - s + 2 * CLIP_PAD) / 2
        a, b = (max(0, int((c - half) * RATE)), min(n, int((c + half) * RATE)))
        fade = np.ones(b - a, np.float32)
        r = min(int(0.01 * RATE), (b - a) // 4)
        fade[:r] = np.linspace(0, 1, r)
        fade[-r:] = np.linspace(1, 0, r)
        seq = np.concatenate([mix[:, a:b] * fade, gap, trial[:, a:b] * fade, gap, bed[:, a:b] * fade], 1)
        fn = f'tr{track:02d}_{name}_cut{k + 1}_{a / RATE:05.2f}s.wav'
        write_wav16(outdir / fn, seq)
        rows.append(dict(file=fn, track=track, start=round(a / RATE, 2), end=round(b / RATE, 2), cutout=[round(s, 2), round(e, 2)], deepest_db=depth))
    for r in regions:
        if r['lines']:
            continue
        a, b = (max(0, int((r['start'] - 0.8) * RATE)), min(n, int((r['end'] + 0.8) * RATE)))
        fn = f"tr{track:02d}_{name}_untranscribed_{r['start']:05.2f}s.wav"
        write_wav16(outdir / fn, np.concatenate([mix[:, a:b], gap, bed[:, a:b]], 1))
        rows.append(dict(file=fn, track=track, start=round(a / RATE, 2), end=round(b / RATE, 2), untranscribed=[r['start'], r['end']], action=r['action']))
    write_wav16(outdir / 'beds' / f'tr{track:02d}_{name}_bed.wav', bed)
    return rows

def write_clip_index(outdir, rows, report):
    lines = ['Strider EX dub beds: review clips (PLAYBACK ORDER IN EACH CLIP: original mix, 0.4 s gap, trial bed (P0.12 method), 0.4 s gap, repaired bed).', 'Made by backports/striderex/scripts/dub_beds.py repair --clips. Scratch; never shipped.', '']
    for r in rows:
        if 'untranscribed' in r:
            lines.append(f"{r['file']}: track {r['track']} {r['start']:.2f}-{r['end']:.2f} s; ORIGINAL then BED: vocal sound with no transcribed line at {r['untranscribed'][0]:.2f}-{r['untranscribed'][1]:.2f} s ({('removed from' if r['action'] == 'remove' else 'kept in')} the bed); listen and decide")
        else:
            lines.append(f"{r['file']}: track {r['track']} {r['start']:.2f}-{r['end']:.2f} s; trial lost up to {r['deepest_db']} dB at {r['cutout'][0]:.2f}-{r['cutout'][1]:.2f} s")
    lines += ['', 'beds/: the full repaired beds (21-28), as the pack will take them.']
    (Path(outdir) / 'index.txt').write_text('\n'.join(lines) + '\n')

def self_test():
    """Synthetic music + voice through the bed logic: exact outside the voice, music restored"""
    import numpy as np
    rng = np.random.default_rng(1)
    p = manifest()['params']
    n = 6 * RATE
    t = np.arange(n) / RATE
    bass = 0.1 * np.sin(2 * np.pi * 55 * t)
    tone = 0.05 * np.sin(2 * np.pi * 440 * t)
    hiss = 0.002 * rng.standard_normal(n)
    music = np.stack([bass + tone + hiss] * 2).astype(np.float32)
    env = ((t >= 2.0) & (t < 4.0)) * (0.6 + 0.4 * np.sin(2 * np.pi * 4 * t) ** 2)
    voice1 = sum((np.sin(2 * np.pi * 120 * h * t) / h for h in range(1, 25))) * env * 0.08
    voice = np.stack([voice1, voice1]).astype(np.float32)
    mix = np.round((music + voice) * 32768) / 32768
    mix = mix.astype(np.float32)
    stem_a = voice + np.stack([tone * 0.8 + bass * 0.3 * (env > 0)] * 2)
    stem_b = voice + 0.0005 * rng.standard_normal((2, n))
    lines = [dict(id='x.0', start=2.05, end=3.9, speaker='test')]
    bed, v, g, times, regions, ref, raw, _ = track_bed(lines, mix, [stem_a.astype(np.float32), stem_b.astype(np.float32)], p)
    ok = True

    def check(name, cond, detail=''):
        nonlocal ok
        ok &= bool(cond)
        print(f"{('PASS' if cond else 'FAIL')} {name} {detail}")
    x = rng.standard_normal(RATE)
    rt = istft(stft(x, 2048, 512)[None][0], RATE, 2048, 512)
    check('stft round trip', np.abs(rt - x).max() < 1e-05, f'{np.abs(rt - x).max():.2e}')
    sup = support(g, times, p['n_fft'], p['hop'], n)
    bi = np.clip(np.round(bed * 32768), -32768, 32767)
    mi = np.round(mix * 32768)
    check('bed == mix outside the voice', (bi[:, ~sup] == mi[:, ~sup]).all(), f'{(~sup).sum()} samples')
    rem = [r for r in regions if r['action'] == 'remove']
    check('one voice region found', len(rem) == 1, str(regions))
    if rem:
        check('region start', abs(rem[0]['start'] - 2.0) < 0.1, str(rem[0]['start']))
        check('region end', abs(rem[0]['end'] - 4.0) < 0.15, str(rem[0]['end']))
    seg = (t > 2.3) & (t < 3.7)

    def pw(x, f):
        return np.abs(np.dot(x[0][seg], np.exp(-2j * np.pi * f * t[seg]))) ** 2
    check('tone kept under the voice', abs(db(pw(bed, 440)) - db(pw(music, 440))) < 1.0, f'{db(pw(bed, 440)) - db(pw(music, 440)):.2f} dB')
    check('bass kept under the voice', abs(db(pw(bed, 55)) - db(pw(music, 55))) < 1.0, f'{db(pw(bed, 55)) - db(pw(music, 55)):.2f} dB')
    resid = bed[0][seg] - music[0][seg]
    cut = db(np.mean(resid ** 2)) - db(np.mean(voice[0][seg] ** 2))
    check('voice removed by 20 dB', cut < -20, f'{cut:.1f} dB')
    sine = np.stack([0.1 * np.sin(2 * np.pi * 997 * t)] * 2)
    lk = loudness(sine)
    check('997 Hz at -20 dBFS reads -20 LUFS', abs(lk + 20.0) < 0.1, str(lk))
    return 0 if ok else 1

def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('command', nargs='?', choices=['separate', 'export', 'import', 'repair'])
    p.add_argument('--out', type=Path, help='export: the directory to write the tracks to')
    p.add_argument('--self-test', action='store_true')
    p.add_argument('--workdir', type=Path)
    p.add_argument('--cue', type=Path, help='restored PC Engine disc cue sheet')
    p.add_argument('--tracks', type=int, nargs='+', default=list(TRACKS))
    p.add_argument('--model', choices=sorted(MODELS), default='htdemucs_ft')
    p.add_argument('--shifts', type=int, default=1)
    p.add_argument('--overlap', type=float, default=0.25)
    p.add_argument('--threads', type=int, default=0)
    p.add_argument('--torch-home', type=Path, help='TORCH_HOME holding the htdemucs_ft checkpoints')
    p.add_argument('--hf-home', type=Path, default=Path.home() / '.cache/huggingface', help='Hugging Face cache holding htdemucs_6s')
    p.add_argument('--clips', type=Path, help='repair: also write review clips and full beds here')
    p.add_argument('--asr', action='store_true', help='repair: residual ASR on the trial and repaired beds')
    p.add_argument('--check', action='store_true', help='repair: exit 1 unless every bed matches its pinned digest')
    p.add_argument('--pin', action='store_true', help='repair: write the bed digests and line references to the manifest')
    p.add_argument('--from', dest='source_dir', type=Path, help='import: the directory holding the downloaded stems')
    p.add_argument('--variant', help="import: the stored separation's name (a params.variants entry)")
    p.add_argument('--source', help='import: where the separation came from (service, model, who, when)')
    p.add_argument('--demucs-python', type=Path, help='repair: the Demucs env python, to rebuild a missing separation cache automatically')
    a = p.parse_args()
    if a.self_test:
        return self_test()
    if a.command == 'import' and a.cue:
        return import_stems(a)
    if a.command == 'export' and a.cue and a.out:
        return export_tracks(a)
    if not a.command or not a.workdir or (not a.cue):
        p.error('a command, --workdir (not for import) and --cue are needed')
    if a.command == 'separate':
        if not a.torch_home:
            p.error('separate needs --torch-home')
        return separate(a)
    return repair(a)
if __name__ == '__main__':
    sys.exit(main())
