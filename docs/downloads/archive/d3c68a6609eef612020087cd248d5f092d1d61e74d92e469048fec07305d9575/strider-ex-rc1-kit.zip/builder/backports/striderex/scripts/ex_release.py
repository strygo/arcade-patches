"""Strider EX release MRAs: one per region and voice, with the EX pack and the flag patch."""
import argparse
import json
import re
import sys
import tempfile
import zipfile
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
import ex_kit as EK
import mapper_testkit as K
ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / 'cpsplus' / 'integration'))
FLAG_ADDR = 2097151
MAGIC_ADDR = 2097136
VARIANTS = [('striderua', 'Strider EX (USA)', 1, True), ('striderua', 'Strider EX (USA) [Japanese voices]', 3, False), ('striderjr', 'Strider Hiryu EX (Japan)', 1, False), ('striderjr', 'Strider Hiryu EX (Japan) [English voices]', 5, True)]
ROM_TOTAL = 10813440

def members_for(a, machine):
    stock_by_crc = K.pool([a.rom_dir.resolve() / machine, a.rom_dir.resolve() / 'strider'])
    built = {q.name: q.read_bytes() for q in (a.build / machine).iterdir() if q.is_file()}
    text = EK.BASES[machine][0].read_text()
    members = {}
    for n, c in re.findall('<part name="([^"]+)" crc="([0-9a-f]{8})"', text):
        members[n] = built.get(n) or stock_by_crc.get(c)
        if members[n] is None:
            sys.exit(f'{machine}: stock part {n} (CRC {c}) not in the given sets')
    for n in ['strex_p6.bin'] + EK.EX_GFX:
        members[n] = built[n]
    return (text, members)

def prove(mra_path, zips, flag):
    """Assemble the MRA from the zips, apply its patches, check the flag block."""
    import ffight_screen_patch as FS
    with tempfile.TemporaryDirectory() as d:
        for z in zips:
            with zipfile.ZipFile(z) as zf:
                zf.extractall(d)
        img, hdr, missing = FS.assemble_mra(str(mra_path), d)
    missing = [m for m in missing if not m.endswith('.cpk')]
    if missing:
        sys.exit(f'{mra_path}: cannot verify, missing {missing[:4]}')
    magic = bytes((img[hdr + (a ^ 1)] for a in range(MAGIC_ADDR, MAGIC_ADDR + 10)))
    if magic != b'STRIDER-EX':
        sys.exit(f'{mra_path}: no STRIDER-EX block at 0x{MAGIC_ADDR:X} ({magic!r})')
    if img[hdr + (FLAG_ADDR ^ 1)] != 0:
        sys.exit(f'{mra_path}: the unpatched flag byte is not 0')
    import xml.etree.ElementTree as ET
    rom = next((r for r in ET.parse(mra_path).getroot().findall('rom') if r.get('index') == '0'))
    offs = {int(p.get('offset')): p.text.split() for p in rom.findall('patch')}
    if offs.get(hdr + (FLAG_ADDR ^ 1)) != [f'{flag:02x}']:
        sys.exit(f'{mra_path}: the flag patch is missing or wrong: {offs}')
    if set(offs) != {8, hdr + (FLAG_ADDR ^ 1)}:
        sys.exit(f'{mra_path}: unexpected patches {sorted(offs)}')
    return dict(header=hdr, flag_offset=hdr + (FLAG_ADDR ^ 1), flag=flag)

def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('--build', type=Path, required=True)
    p.add_argument('--rom-dir', type=Path, required=True)
    p.add_argument('--pack', type=Path, required=True, help='directory holding strider_ex.cpk and its build.json')
    p.add_argument('--out', type=Path, required=True)
    p.add_argument('--rbf', default='jtcps1-cpsplus')
    p.add_argument('--core', type=Path, help='an RBF to include under _Arcade/cores (test kits)')
    p.add_argument('--date', default='20261010')
    a = p.parse_args()
    import embed_pack_mra as EP
    pack = a.pack / 'strider_ex.cpk'
    pack_info = json.loads((a.pack / 'strider_ex.build.json').read_text())
    out = a.out.resolve()
    out.mkdir(parents=True, exist_ok=False)
    arcade, games, cps = (out / '_Arcade', out / 'games/mame', out / 'games/CPS+')
    for d in (arcade, games, cps):
        d.mkdir(parents=True)
    if a.core:
        (arcade / 'cores').mkdir()
        (arcade / 'cores' / f'{a.rbf}_{a.date}.rbf').write_bytes(a.core.read_bytes())
    with zipfile.ZipFile(cps / 'strider_ex.zip', 'w', zipfile.ZIP_STORED) as z:
        z.writestr(zipfile.ZipInfo('strider_ex.cpk', (2026, 10, 10, 0, 0, 0)), pack.read_bytes())
    report, zips = (dict(pack=pack_info['sha256'], mras={}, skipped={}), {})
    for machine, name, flag, english in VARIANTS:
        if english and (not pack_info.get('english_voices')):
            report['skipped'][name] = 'the pack has no English dub yet (Phase 4)'
            continue
        key = EK.BASES[machine][2]
        zipname = f'striderex_{key}.zip'
        text, members = members_for(a, machine)
        if machine not in zips:
            zp = games / zipname
            with zipfile.ZipFile(zp, 'w', zipfile.ZIP_DEFLATED) as z:
                for n, b in sorted(members.items()):
                    z.writestr(zipfile.ZipInfo(n, (1996, 1, 1, 0, 0, 0)), b)
            zips[machine] = zp
        base = EK.make_mra(text, machine, name, a.rbf, zipname, members)
        with tempfile.TemporaryDirectory() as d:
            bp = Path(d) / 'base.mra'
            bp.write_text(base)
            tree, info = EP.embed(str(bp), pack.stat().st_size, 'strider_ex.cpk', ROM_TOTAL, pack_zip='/CPS+/strider_ex.zip', display_name=name, rbf=a.rbf, extra_patches=[(FLAG_ADDR, flag)])
        mp = arcade / f'{name}.mra'
        tree.write(mp, encoding='utf-8', xml_declaration=False)
        report['mras'][name] = dict(machine=machine, **prove(mp, [zips[machine]], flag), pack_offset=info['pack_off'])
        report['mras'][name]['flag'] = f'0x{flag:02x}'
        print(name, report['mras'][name])
    for name, why in report['skipped'].items():
        print('not written:', name, '-', why)
    (out / 'release.json').write_text(json.dumps(report, indent=1) + '\n')
    return 0
if __name__ == '__main__':
    sys.exit(main())
