"""Check the photographed desert edge after the pan, walking back and respawn."""
import argparse
from concurrent.futures import ThreadPoolExecutor
from copy import deepcopy
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import numpy as np
from PIL import Image, ImageChops, ImageDraw
import desert_gate as G
import desert_smooth as S
import desert_map_edge as M
from boss_voice_gate import inventory, sha
SETS = {'striderua': 'striderus01', 'striderjr': 'striderjs01'}

def plans():
    kill = G.OFFICER_KILL_INPUTS.replace('4200', '3240')
    return {'defeated_idle': (2, 3650, dict(STREX_INPUTS=kill + ';3050-3240:P1_JOYSTICK_RIGHT', SHOTS='3280-3650@10')), 'defeated_idle_native': (2, 3650, dict(STREX_INPUTS=kill + ';3050-3240:P1_JOYSTICK_RIGHT', SHOTS='3280-3650@10')), 'defeated_return': (2, 4100, dict(STREX_INPUTS=kill + ';3050-3330:P1_JOYSTICK_RIGHT;3450-3950:P1_JOYSTICK_LEFT', SHOTS='3300-4100@50')), 'checkpoint_left': (3, 1400, dict(STREX_INPUTS='700-1000:P1_JOYSTICK_LEFT', SHOTS='500-1400@100')), 'checkpoint_respawn': (3, 2700, dict(STREX_INPUTS='', WARP='1300:4250,0', SHOTS='500-2700@100')), 'stock_slope': (1, 1300, dict(STREX_INPUTS='450-1300:P1_JOYSTICK_RIGHT', SHOTS='500-1300@100'))}

def notch_pixels(path):
    a = np.asarray(Image.open(path).convert('RGB'))
    if a.shape != (224, 384, 3):
        raise ValueError('unexpected actual emulator picture dimensions')
    sky = a[100, 0]
    if not (sky[2] > sky[0] and sky[2] > sky[1]):
        raise ValueError('corner witness has no unobscured blue sky sample')
    return int(np.all(a[-12:, :32] == sky, axis=2).sum())

def check(case, old, new):
    a, b = [G.read(p) for p in (old, new)]
    ma, mb = [S.read_motion(p) for p in (old, new)]
    if len(a) != len(b):
        raise ValueError('incomplete paired traces')
    result = dict(case=case, frames=len(b), passed=True)
    if case == 'stock_slope':
        if a != b or ma != mb:
            raise ValueError('unrelated stock stage changed')
        pictures = 0
        for p in new.glob('s_*.png'):
            if ImageChops.difference(Image.open(p).convert('RGB'), Image.open(old / p.name).convert('RGB')).getbbox():
                raise ValueError('stock-stage image changed')
            pictures += 1
        if pictures < 5:
            raise ValueError('stock visual witness missing')
        result.update(stock_trace_and_pictures_exact=True, pictures_exact=pictures)
    else:
        for rr in (mb,):
            stable = [r for r in rr if r['frame'] > 3350] if case.startswith('defeated') else [r for r in rr if 600 <= r['frame'] < 1250]
            if not stable or min((r['camx'] for r in stable)) < M.MINIMUM:
                raise ValueError('camera can still expose the incomplete left tile')
            if min((r['camx'] for r in stable)) > M.MINIMUM + 2:
                raise ValueError('left-bound witness never reached the corrected boundary')
        if case.startswith('defeated'):
            da, db = [G.read_desert(p) for p in (old, new)]
            death = lambda rows: next((r['frame'] for r in rows if r['sec'] == 1 and r['step'] == 23))
            load = lambda rows: next((r['frame'] for r in rows if r['map'] == 1))
            if death(da) != death(db):
                raise ValueError('boss fight changed before the outgoing pan')
            if mb[load(db) - 1]['camx'] < M.MINIMUM:
                raise ValueError('first map-1 load still starts too far left')
            pan = [r for r in db if r['sec'] == 1 and r['step'] == 25]
            start = pan[0]['frame']
            moves = [abs(y['camx'] - x['camx']) for x, y in zip(mb, mb[1:]) if start <= y['frame'] < load(db)]
            if not moves or max(moves) > 2:
                raise ValueError('gentle outgoing pan was lost')
            result.update(antlion_dead_frame=death(db), control_map_load=load(da), candidate_map_load=load(db), maximum_pan_step=max(moves), camera_at_map_load=mb[load(db) - 1]['camx'])
            after = load(db) + 8
        else:
            after = 600
        if case == 'checkpoint_respawn':
            transitions = [int(y['frame']) for x, y in zip(b, b[1:]) if int(y['frame']) > 1300 and x['mode'] == '2' and (y['mode'] == '4')]
            if len(transitions) != 1 or not int(b[-1]['lives']) < int(b[1200]['lives']):
                raise ValueError('fixture did not die and naturally reload its checkpoint')
            restart = transitions[0]
            if min((r['camx'] for r in mb if r['frame'] >= restart)) < M.MINIMUM:
                raise ValueError('death reload restored the defective camera boundary')
            result.update(natural_respawn_frame=restart, life_lost=True)
            after = restart + 80
        witnesses = []
        for p in sorted(new.glob('s_*.png')):
            f = int(p.stem[2:])
            if f < after or b[f - 1]['mode'] != '4' or mb[f - 1]['camx'] > M.MINIMUM + 2:
                continue
            count = notch_pixels(p)
            if count:
                raise ValueError(f'{case} frame {f}: {count} sky pixels remain below the floor')
            witnesses.append(dict(frame=f, corner_sky_pixels=count, sha256=sha(p.read_bytes())))
        controls = [dict(frame=int(p.stem[2:]), pixels=notch_pixels(p)) for p in sorted(old.glob('s_*.png')) if int(p.stem[2:]) >= after and a[int(p.stem[2:]) - 1]['mode'] == '4' and (ma[int(p.stem[2:]) - 1]['camx'] <= 4106)]
        if len(witnesses) < 2 or not any((r['pixels'] for r in controls)):
            raise ValueError('missing old-notch/new-floor image witnesses')
        result.update(floor_witnesses=witnesses, control_notch_witnesses=controls, left_boundary_stays_safe=True)
    result['traces'] = {label: {n: sha((p / n).read_bytes()) for n in ('frames.tsv', 'motion.tsv', 'desert.tsv')} for label, p in (('control', old), ('candidate', new))}
    return result

def main():
    p = argparse.ArgumentParser(description=__doc__)
    for name in ('control', 'build', 'runtime', 'hbmame', 'rom-dir', 'workdir', 'receipt'):
        p.add_argument('--' + name, type=Path, required=True)
    p.add_argument('--reuse', action='store_true')
    p.add_argument('--preview-out', type=Path)
    a = p.parse_args()
    M.audit(a.control, a.build)
    work = a.workdir.resolve()
    work.mkdir(parents=True, exist_ok=a.reuse)
    metas, files = ({}, {})
    for label, build in (('control', a.control), ('candidate', a.build)):
        metas[label], files[label] = inventory(build)
    rt = json.loads((a.runtime / 'runtime.json').read_text())
    binary = Path(rt['binary'])
    if sha(binary.read_bytes()) != rt['binary_sha256'] or not rt['board_wait']:
        raise ValueError('matching conservative prepared runtime required')
    prepared, pins = ({}, {})
    for label in metas:
        for machine, setname in SETS.items():
            for native in (False, True):
                key = f'{label}_{machine}_{native}'
                f = dict(files[label][machine])
                p6 = bytearray(f['strex_p6.bin'])
                p6[-2] = p6[-2] & ~1 | (not native)
                f['strex_p6.bin'] = bytes(p6)
                source = work / 'variants' / key
                if not source.exists():
                    d = source / machine
                    d.mkdir(parents=True)
                    for n, data in f.items():
                        (d / n).write_bytes(data)
                    vm = deepcopy(metas[label])
                    vm['sets'] = {machine: dict(vm['sets'][machine], files={n: sha(b) for n, b in f.items()})}
                    (source / 'build.json').write_text(json.dumps(vm) + '\n')
                if inventory(source)[1][machine] != f:
                    raise ValueError('stale or changed audio-path variant')
                roms = G.stage_sets(source, setname, a.hbmame, a.rom_dir.resolve(), work / 'sets' / key)
                have = {sha(q.read_bytes()) for q in (roms / setname).iterdir() if q.is_file()}
                if not {sha(b) for b in f.values()} <= have:
                    raise ValueError('staged input identity differs')
                prepared[label, machine, native] = (roms, setname)
                pins[key] = {n: sha(b) for n, b in f.items()}
    scenarios = plans()
    jobs = [(label, machine, case) for label in metas for machine in SETS for case in scenarios]

    def run(job):
        label, machine, case = job
        area, n, extra = scenarios[case]
        stage = 0 if case == 'stock_slope' else 5
        native = case.endswith('_native')
        env = dict(G.debug_env(stage, area, n, inputs=False), MOTION='16', **extra)
        out = work / 'runs' / f'{label}_{machine}_{case}'
        pin = dict(files=pins[f'{label}_{machine}_{native}'], runtime_sha256=rt['binary_sha256'], environment=env, frames=n, lua_sha256=sha(G.LUA.read_bytes()), debug_start_sha256=sha(G.DEBUG_START.read_bytes()))
        if not a.reuse or not (out / 'case.json').exists():
            G.run(binary, *prepared[label, machine, native], out, env, n)
            (out / 'case.json').write_text(json.dumps(pin, indent=2) + '\n')
        if json.loads((out / 'case.json').read_text()) != pin or len(G.read(out)) != n:
            raise ValueError('stale or incomplete emulator case')
        print('Captured', label, machine, case, flush=True)
        return out
    with ThreadPoolExecutor(2) as ex:
        captured = dict(zip(jobs, ex.map(run, jobs)))
    checks = []
    for machine in SETS:
        for case in scenarios:
            r = check(case, captured['control', machine, case], captured['candidate', machine, case])
            checks.append(dict(machine=machine, native_audio=case.endswith('_native'), **r))
            print('PASS', machine, case, flush=True)
    with tempfile.TemporaryDirectory(prefix='fresh-', dir=work) as temp:
        fresh = Path(temp) / 'build'
        subprocess.run([sys.executable, str(Path(M.__file__)), '--build', str(a.control), '--out', str(fresh)], check=True)
        if inventory(fresh) != inventory(a.build):
            raise ValueError('fresh empty-output reconstruction differs')
    rejected = []
    with tempfile.TemporaryDirectory(prefix='damage-', dir=work) as temp:
        for machine in SETS:
            for i, change in enumerate(metas['candidate']['sets'][machine]['desert_map_edge']['change']['changes']):
                root = Path(temp) / f'{machine}_{i}'
                meta = deepcopy(metas['candidate'])
                for m, fs in files['candidate'].items():
                    dest = root / m
                    dest.mkdir(parents=True)
                    for n, data in fs.items():
                        if m == machine and n == 'strex_p6.bin':
                            b = bytearray(data)
                            b[change['address'] - 1048576 ^ 1] ^= 1
                            (dest / n).write_bytes(b)
                            meta['sets'][m]['files'][n] = sha(b)
                        else:
                            (dest / n).symlink_to((a.build / m / n).resolve())
                (root / 'build.json').write_text(json.dumps(meta) + '\n')
                try:
                    M.audit(a.control, root)
                except ValueError:
                    rejected.append(dict(machine=machine, word=i, rehashed_inventory=True, rejected=True))
                else:
                    raise ValueError('internally rehashed changed-bound damage accepted')
    report = dict(schema='striderex-desert-map-edge-gate/1', passed=True, checks=checks, inputs={label: {m: s['files'] for m, s in meta['sets'].items()} for label, meta in metas.items()}, runtime={k: rt[k] for k in ('binary_sha256', 'source_revision', 'board_wait')}, variant_inputs=pins, fresh_empty_output_files_and_metadata_exact=True, rehashed_damage_controls=rejected, hardware_review_granted=False, source_sha256={str(q.relative_to(Path(__file__).parents[1])): sha(q.read_bytes()) for q in (Path(__file__), Path(M.__file__), G.LUA, G.DEBUG_START)})
    a.receipt.parent.mkdir(parents=True, exist_ok=True)
    a.receipt.write_text(json.dumps(report, indent=2) + '\n')
    if a.preview_out:
        a.preview_out.mkdir(parents=True, exist_ok=False)
        poster = Image.new('RGB', (768, 244))
        draw = ImageDraw.Draw(poster)
        sources = []
        for i, label in enumerate(('control', 'candidate')):
            folder = captured[label, 'striderua', 'defeated_idle']
            source = folder / 's_03650.png'
            poster.paste(Image.open(source).convert('RGB'), (i * 384, 20))
            draw.text((i * 384 + 4, 4), 'Before' if i == 0 else 'After', fill='white')
            sources.append(dict(label=label, frame=3650, sha256=sha(source.read_bytes())))
        poster.save(a.preview_out / 'desert-edge.png')
        (a.preview_out / 'preview.json').write_text(json.dumps(dict(actual_emulator_pictures=True, sources=sources, sha256=sha((a.preview_out / 'desert-edge.png').read_bytes())), indent=2) + '\n')
    print('All 12 desert-edge/respawn/stock comparisons PASS; fresh output exact')
if __name__ == '__main__':
    main()
