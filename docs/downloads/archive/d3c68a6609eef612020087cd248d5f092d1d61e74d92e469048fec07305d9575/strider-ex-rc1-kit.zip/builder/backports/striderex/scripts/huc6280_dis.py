"""Minimal HuC6280 (65C02 plus the PC Engine extras) disassembler."""
import argparse
import sys
IMP, IMM, ZP, ZPX, ZPY, ABS, ABX, ABY, IND, IZX, IZY, IZP, REL, ZPR, AIX, BLK, TST_ZP, TST_ZPX, TST_AB, TST_ABX = range(20)
FMT = {IMP: ('', 0), IMM: ('#${:02X}', 1), ZP: ('${:02X}', 1), ZPX: ('${:02X},x', 1), ZPY: ('${:02X},y', 1), ABS: ('${:04X}', 2), ABX: ('${:04X},x', 2), ABY: ('${:04X},y', 2), IND: ('(${:04X})', 2), IZX: ('(${:02X},x)', 1), IZY: ('(${:02X}),y', 1), IZP: ('(${:02X})', 1), REL: (None, 1), ZPR: (None, 2), AIX: ('(${:04X},x)', 2), BLK: (None, 6), TST_ZP: (None, 2), TST_ZPX: (None, 2), TST_AB: (None, 3), TST_ABX: (None, 3)}
OPS = {}

def op(code, name, mode):
    OPS[code] = (name, mode)
for base, name in ((0, 'ora'), (32, 'and'), (64, 'eor'), (96, 'adc'), (192, 'cmp'), (224, 'sbc')):
    for off, mode in ((1, IZX), (5, ZP), (9, IMM), (13, ABS), (17, IZY), (18, IZP), (21, ZPX), (25, ABY), (29, ABX)):
        op(base + off, name, mode)
for off, mode in ((1, IZX), (5, ZP), (13, ABS), (17, IZY), (18, IZP), (21, ZPX), (25, ABY), (29, ABX)):
    op(128 + off, 'sta', mode)
for off, mode in ((1, IZX), (5, ZP), (9, IMM), (13, ABS), (17, IZY), (18, IZP), (21, ZPX), (25, ABY), (29, ABX)):
    op(160 + off, 'lda', mode)
for code, name, mode in [(0, 'brk', IMP), (2, 'sxy', IMP), (3, 'st0', IMM), (4, 'tsb', ZP), (6, 'asl', ZP), (8, 'php', IMP), (10, 'asl', IMP), (12, 'tsb', ABS), (14, 'asl', ABS), (16, 'bpl', REL), (19, 'st1', IMM), (20, 'trb', ZP), (22, 'asl', ZPX), (24, 'clc', IMP), (26, 'inc', IMP), (28, 'trb', ABS), (30, 'asl', ABX), (32, 'jsr', ABS), (34, 'sax', IMP), (35, 'st2', IMM), (36, 'bit', ZP), (38, 'rol', ZP), (40, 'plp', IMP), (42, 'rol', IMP), (44, 'bit', ABS), (46, 'rol', ABS), (48, 'bmi', REL), (52, 'bit', ZPX), (54, 'rol', ZPX), (56, 'sec', IMP), (58, 'dec', IMP), (60, 'bit', ABX), (62, 'rol', ABX), (64, 'rti', IMP), (66, 'say', IMP), (67, 'tma', IMM), (68, 'bsr', REL), (70, 'lsr', ZP), (72, 'pha', IMP), (74, 'lsr', IMP), (76, 'jmp', ABS), (78, 'lsr', ABS), (80, 'bvc', REL), (83, 'tam', IMM), (84, 'csl', IMP), (86, 'lsr', ZPX), (88, 'cli', IMP), (90, 'phy', IMP), (94, 'lsr', ABX), (96, 'rts', IMP), (98, 'cla', IMP), (100, 'stz', ZP), (102, 'ror', ZP), (104, 'pla', IMP), (106, 'ror', IMP), (108, 'jmp', IND), (110, 'ror', ABS), (112, 'bvs', REL), (115, 'tii', BLK), (116, 'stz', ZPX), (118, 'ror', ZPX), (120, 'sei', IMP), (122, 'ply', IMP), (124, 'jmp', AIX), (126, 'ror', ABX), (128, 'bra', REL), (130, 'clx', IMP), (131, 'tst', TST_ZP), (132, 'sty', ZP), (134, 'stx', ZP), (136, 'dey', IMP), (137, 'bit', IMM), (138, 'txa', IMP), (140, 'sty', ABS), (142, 'stx', ABS), (144, 'bcc', REL), (147, 'tst', TST_AB), (148, 'sty', ZPX), (150, 'stx', ZPY), (152, 'tya', IMP), (154, 'txs', IMP), (156, 'stz', ABS), (158, 'stz', ABX), (160, 'ldy', IMM), (162, 'ldx', IMM), (163, 'tst', TST_ZPX), (164, 'ldy', ZP), (166, 'ldx', ZP), (168, 'tay', IMP), (170, 'tax', IMP), (172, 'ldy', ABS), (174, 'ldx', ABS), (176, 'bcs', REL), (179, 'tst', TST_ABX), (180, 'ldy', ZPX), (182, 'ldx', ZPY), (184, 'clv', IMP), (186, 'tsx', IMP), (188, 'ldy', ABX), (190, 'ldx', ABY), (192, 'cpy', IMM), (194, 'cly', IMP), (195, 'tdd', BLK), (196, 'cpy', ZP), (198, 'dec', ZP), (200, 'iny', IMP), (202, 'dex', IMP), (204, 'cpy', ABS), (206, 'dec', ABS), (208, 'bne', REL), (211, 'tin', BLK), (212, 'csh', IMP), (214, 'dec', ZPX), (216, 'cld', IMP), (218, 'phx', IMP), (222, 'dec', ABX), (224, 'cpx', IMM), (227, 'tia', BLK), (228, 'cpx', ZP), (230, 'inc', ZP), (232, 'inx', IMP), (234, 'nop', IMP), (236, 'cpx', ABS), (238, 'inc', ABS), (240, 'beq', REL), (243, 'tai', BLK), (244, 'set', IMP), (246, 'inc', ZPX), (248, 'sed', IMP), (250, 'plx', IMP), (254, 'inc', ABX)]:
    op(code, name, mode)
for i in range(8):
    op(7 + 16 * i, f'rmb{i}', ZP)
    op(135 + 16 * i, f'smb{i}', ZP)
    op(15 + 16 * i, f'bbr{i}', ZPR)
    op(143 + 16 * i, f'bbs{i}', ZPR)

def length(code):
    name, mode = OPS.get(code, ('???', IMP))
    return 1 + FMT[mode][1]

def decode(read, pc):
    """(text, length, operand address or None) of the instruction at pc."""
    code = read(pc)
    name, mode = OPS.get(code, (f'.db ${code:02X}', IMP))
    n = FMT[mode][1]
    b = [read(pc + 1 + i) for i in range(n)]
    w = b[0] | b[1] << 8 if n >= 2 else None
    target = None
    if mode == REL:
        target = pc + 2 + (b[0] - 256 if b[0] > 127 else b[0]) & 65535
        txt = f'${target:04X}'
    elif mode == ZPR:
        target = pc + 3 + (b[1] - 256 if b[1] > 127 else b[1]) & 65535
        txt = f'${b[0]:02X},${target:04X}'
    elif mode == BLK:
        s, d, l = (b[0] | b[1] << 8, b[2] | b[3] << 8, b[4] | b[5] << 8)
        txt, target = (f'${s:04X},${d:04X},${l:04X}', s)
    elif mode in (TST_ZP, TST_ZPX):
        txt, target = (f'#${b[0]:02X},${b[1]:02X}' + (',x' if mode == TST_ZPX else ''), b[1])
    elif mode in (TST_AB, TST_ABX):
        a = b[1] | b[2] << 8
        txt, target = (f'#${b[0]:02X},${a:04X}' + (',x' if mode == TST_ABX else ''), a)
    elif n == 2:
        txt, target = (FMT[mode][0].format(w), w)
    elif n == 1:
        txt = FMT[mode][0].format(b[0])
        target = b[0] if mode != IMM else None
    else:
        txt = ''
    return (name + (' ' + txt if txt else ''), 1 + n, target)

def reader(dump, dump_base, mapping):

    def read(addr):
        bank = mapping.get(addr & 57344)
        if bank is None:
            return 0
        o = bank * 8192 + (addr & 8191) - dump_base
        return dump[o] if 0 <= o < len(dump) else 0
    return read

def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('dump')
    p.add_argument('--dump-base', type=lambda s: int(s, 16), default=851968)
    p.add_argument('--map', required=True, help='logical=bank,... e.g. 4000=68,6000=69,8000=6A (hex)')
    p.add_argument('--start', type=lambda s: int(s, 16))
    p.add_argument('--count', type=int, default=40)
    p.add_argument('--refs', type=lambda s: int(s, 16), help='list instructions naming this address')
    a = p.parse_args()
    mapping = {int(k, 16): int(v, 16) for k, v in (x.split('=') for x in a.map.split(','))}
    read = reader(open(a.dump, 'rb').read(), a.dump_base, mapping)
    if a.refs is not None:
        for win in sorted(mapping):
            for pc in range(win, win + 8192):
                text, n, target = decode(read, pc)
                if target == a.refs and OPS.get(read(pc), ('', IMP))[1] not in (REL, ZPR, IMM):
                    print(f'{pc:04X}  {text}')
        return 0
    pc = a.start
    for _ in range(a.count):
        text, n, _ = decode(read, pc)
        raw = ' '.join((f'{read(pc + i):02X}' for i in range(n)))
        print(f'{pc:04X}  {raw:<20} {text}')
        pc += n
    return 0
if __name__ == '__main__':
    sys.exit(main())
