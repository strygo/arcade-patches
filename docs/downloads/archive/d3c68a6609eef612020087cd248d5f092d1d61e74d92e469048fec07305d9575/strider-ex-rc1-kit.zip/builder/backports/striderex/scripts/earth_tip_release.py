"""Bind the ending-tip follow-up to exact sealed Kit w and new game/core checks."""
import argparse
from copy import deepcopy
import json
from pathlib import Path
import sys
import zipfile
import cinematic_followup as CF
ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / 'release'))
import private_mister as PM

def previous(kit):
    record = PM.verify(kit.resolve())
    if record['test_id'] != '261025-11':
        raise ValueError('need the verified Kit w export')
    with PM.qualified_view(kit.resolve()) as view:
        producer = json.loads((view / 'producer.json').read_text())
    return (record, producer)

def proof(a):
    record, producer = previous(a.previous_kit)
    meta = json.loads((a.build / 'build.json').read_text())
    old = producer['cinematic_music']
    p = deepcopy(old['proof'])
    p.update(schema='striderex-cinematic-inheritance/8', previous=old, previous_test_id=record['test_id'], build_files={m: s['files'] for m, s in meta['sets'].items()}, passed=True)
    for m, s in meta['sets'].items():
        p['regions'][m]['earth_tip'] = s['earth_tip']
    CF.verify(p, {m: {n: (a.build / m / n).read_bytes() for n in s['files']} for m, s in meta['sets'].items()})
    a.receipt.write_text(json.dumps(p, indent=2) + '\n')
    print('PASS: exact Kit w recovery and all inherited qualifications remain bound')

def inputs(a):
    record, producer = previous(a.previous_kit)
    out = a.out.resolve()
    out.mkdir(parents=True, exist_ok=False)
    with PM.qualified_view(a.previous_kit.resolve()) as view:
        for name, q in producer['qualification'].items():
            (out / ('qualification-' + name + '.json')).write_text(json.dumps(q, indent=2) + '\n')
        (out / 'rtl.json').write_text(json.dumps(producer['rtl'], indent=2) + '\n')
        for name in ('runtime', 'census', 'loop'):
            (out / (name + '.json')).write_text(json.dumps(producer['cinematic_music'][name], indent=2) + '\n')
        core = (view / producer['core']['file']).read_bytes()
        if CF.sha(core) != producer['core']['sha256']:
            raise ValueError('core identity changed')
        (out / 'core.rbf').write_bytes(core)
        with zipfile.ZipFile(view / 'games/CPS+/strider_ex.zip') as z:
            pack = z.read('strider_ex.cpk')
        digest = producer['qualification']['combined']['inputs']['pack_sha256']
        if CF.sha(pack) != digest or not any(('[English voices]' in n for n in producer['mras'])):
            raise ValueError('wrong bilingual pack')
        folder = out / 'pack'
        folder.mkdir()
        (folder / 'strider_ex.cpk').write_bytes(pack)
        (folder / 'strider_ex.build.json').write_text(json.dumps(dict(sha256=digest, english_voices=True, reconstructed_from_verified_test=record['test_id']), indent=2) + '\n')
    print('PASS: original delivery inputs recovered from verified Kit w')

def check(a):
    record, producer = previous(a.previous_kit)
    p = json.loads(a.proof.read_text())
    runtime = json.loads(a.runtime_report.read_text())
    render = json.loads(a.render_report.read_text())
    meta = json.loads((a.build / 'build.json').read_text())
    members = {m: {n: (a.build / m / n).read_bytes() for n in s['files']} for m, s in meta['sets'].items()}
    bundle = dict(p['previous'], proof=p, tip_runtime=runtime, tip_render=render)

    def validate(b, files):
        CF.verify(b['proof'], files)
        CF.validate_qualification(b, producer['qualification'], producer['rtl'], p['build_files'])
    validate(bundle, members)
    negative = []
    for label, member, at in (('composite-byte', 'strex_gfx.c25', 31392), ('wrong-ending-map', 'st-14.8h', 95774), ('unrelated-program', 'strex_p6.bin', 2048)):
        files = {m: dict(f) for m, f in members.items()}
        data = bytearray(files['striderua'][member])
        data[at] ^= 1
        files['striderua'][member] = bytes(data)
        bad = deepcopy(bundle)
        bad['proof']['build_files']['striderua'][member] = CF.sha(data)
        try:
            validate(bad, files)
        except ValueError:
            negative.append(dict(control=label, rejected=True))
        else:
            raise ValueError('damaged ROM accepted: ' + label)
    for label in ('missing-game-case', 'wrong-game-input', 'missing-core-region', 'wrong-core-input', 'old-defect-accepted', 'defeated-exact-pixel-check'):
        bad = deepcopy(bundle)
        if label == 'missing-game-case':
            bad['tip_runtime']['results'].pop()
        if label == 'wrong-game-input':
            bad['tip_runtime']['build_files']['striderua']['strex_p6.bin'] = '0' * 64
        if label == 'missing-core-region':
            bad['tip_render']['results'].pop()
        if label == 'wrong-core-input':
            bad['tip_render']['results'][0]['build']['vram_sha256'] = '0' * 64
        if label == 'old-defect-accepted':
            bad['tip_render']['results'][0]['old_defect_rejected'] = False
        if label == 'defeated-exact-pixel-check':
            bad['tip_runtime']['results'][0]['checks']['exact_visible_pixels'] = False
        try:
            validate(bad, members)
        except ValueError:
            negative.append(dict(control=label, rejected=True))
        else:
            raise ValueError('damaged qualification accepted: ' + label)
    r = dict(schema='striderex-earth-tip-acceptance/1', passed=True, previous_test_id=record['test_id'], build_files=p['build_files'], proof_sha256=CF.sha(a.proof.read_bytes()), runtime_sha256=CF.sha(a.runtime_report.read_bytes()), render_sha256=CF.sha(a.render_report.read_bytes()), exact_kit_w_reversal=True, game_cases=4, core_pairs=2, damaged_controls=negative, hardware_review_granted=False)
    a.receipt.write_text(json.dumps(r, indent=2) + '\n')
    print('PASS: exact prior kit, new game/core checks and nine damaged controls rejected')

def main():
    p = argparse.ArgumentParser(description=__doc__)
    sub = p.add_subparsers(dest='mode', required=True)
    s = sub.add_parser('proof')
    for n in ('build', 'previous-kit', 'receipt'):
        s.add_argument('--' + n, type=Path, required=True)
    s = sub.add_parser('delivery-inputs')
    for n in ('previous-kit', 'out'):
        s.add_argument('--' + n, type=Path, required=True)
    s = sub.add_parser('check')
    for n in ('build', 'previous-kit', 'proof', 'runtime-report', 'render-report', 'receipt'):
        s.add_argument('--' + n, type=Path, required=True)
    a = p.parse_args()
    {'proof': proof, 'delivery-inputs': inputs, 'check': check}[a.mode](a)
if __name__ == '__main__':
    main()
