"""Strider EX English dub: Google Cloud Text-to-Speech renders (D13a, D13b)."""
import argparse
import base64
import hashlib
import json
import os
import re
import subprocess
import sys
import tempfile
import urllib.request
import wave
from pathlib import Path
ROOT = Path(__file__).resolve().parents[3]
VOICES = ROOT / 'backports/striderex/manifests/dub_voices.json'
AUDITION_LINES = {'Narrator': 'tr21.1', 'Super Base': 'tr22.1', 'Grandmaster': 'tr26.0', 'Defeated enemy (desert)': 'tr24.0'}
PRICE_PER_M = {'Chirp3': 30.0, 'Neural2': 16.0, 'Studio': 160.0, 'Wavenet': 16.0, 'Standard': 4.0}
RATE = 48000
GEMINI_PRICE = {'gemini-3.1-flash-tts-preview': (1.0, 20.0), 'gemini-2.5-flash-tts': (0.5, 10.0), 'gemini-2.5-pro-tts': (1.0, 20.0)}

def token(credentials):
    gcloud = '/opt/homebrew/bin/gcloud'
    with tempfile.TemporaryDirectory() as cfg:
        env = dict(os.environ, CLOUDSDK_CONFIG=cfg, CLOUDSDK_CORE_DISABLE_PROMPTS='1')
        r = subprocess.run([gcloud, 'auth', 'activate-service-account', '--quiet', f'--key-file={credentials}'], env=env, capture_output=True, text=True)
        if r.returncode:
            sys.exit('service-account activation failed')
        t = subprocess.run([gcloud, 'auth', 'print-access-token'], env=env, capture_output=True, text=True)
        if t.returncode or not t.stdout.strip():
            sys.exit('access-token request failed')
        return t.stdout.strip()

def family(voice):
    return voice.split('-')[2]

def request(voice, line, speaker):
    """(body, billable characters) for one line in one voice."""
    lang = '-'.join(voice.split('-')[:2])
    cfg = dict(audioEncoding='LINEAR16', sampleRateHertz=RATE)
    if family(voice) == 'Chirp3':
        text = line['plain']
        inp = dict(text=text)
        cfg['speakingRate'] = speaker.get('base_rate', 1.0)
    else:
        text = line['ssml']
        inp = dict(ssml=text)
    return (dict(input=inp, voice=dict(languageCode=lang, name=voice), audioConfig=cfg), len(text))

def synth(tok, project, body):
    req = urllib.request.Request('https://texttospeech.googleapis.com/v1/text:synthesize', data=json.dumps(body).encode(), headers={'Authorization': f'Bearer {tok}', 'x-goog-user-project': project, 'Content-Type': 'application/json'})
    with urllib.request.urlopen(req, timeout=60) as r:
        return base64.b64decode(json.load(r)['audioContent'])
PRONOUNCE = {'Hiryu': dict(spell='Hee-ryoo', say='Say the name written Hee-ryoo exactly as HEE-ryoo: two syllables, "hee" as in "he", "ryoo" as in the name Ryu, a light stress on the first syllable, no pause between them; the same way every time.')}

def words(text):
    """A text's words, without case, punctuation or hyphens (what --text-json may not change)."""
    return re.sub("[^a-z0-9' ]", ' ', text.lower().replace('-', ' ')).split()

def gemini_request(plan, name, lid, voice, style=None, extra=None, pronounce=None, text=None):
    g = plan['gemini']
    line = plan['lines'][lid]
    direction = line.get('direction') or plan['directions'].get(lid)
    if text is not None and words(text) != words(line['plain']):
        sys.exit(f"{lid}: --text-json changes the words of the line ({text!r} against {line['plain']!r})")
    text = (text or line['plain']).replace('Hee-ryoo', 'Hiryu')
    pr = dict(PRONOUNCE, **pronounce or {})
    names = [n for n in pr if n in text]
    for n in names:
        text = text.replace(n, pr[n]['spell'])
    prompt = ' '.join([g['scene'], style or g['speakers'][name]['style']] + ([f'For this line: {direction}.'] if direction else []) + ([extra] if extra else []) + [pr[n]['say'] for n in names])
    body = dict(input=dict(prompt=prompt, text=text), voice=dict(languageCode='-'.join(voice.split('-')[:2]) if voice.count('-') >= 2 else 'en-us', name=voice, modelName=g['model']), audioConfig=dict(audioEncoding='LINEAR16', sampleRateHertz=g['sample_rate']))
    ipa = [(pr[n]['spell'], pr[n]['ipa']) for n in names if pr[n].get('ipa')]
    if ipa:
        body['input']['customPronunciations'] = dict(pronunciations=[dict(phrase=s, phoneticEncoding='PHONETIC_ENCODING_IPA', pronunciation=p) for s, p in ipa])
    tin, tout = GEMINI_PRICE[g['model']]
    n = max(len(line['plain']), len(text))
    usd = (len(prompt) + n) * tin / 1000000.0 + (3 + n / 12) * 25 * tout / 1000000.0
    return (body, len(prompt) + n, usd)

def audition(a):
    import dub_store as DS
    plan = json.loads(VOICES.read_text())
    out = DS.new_set(a.set)
    jobs = []
    for name, sp in plan['speakers'].items():
        lid = AUDITION_LINES.get(name) or next((k for k, v in plan['lines'].items() if v['speaker'] == name))
        if a.engine == 'gemini':
            for voice in plan['gemini']['speakers'][name]['voices']:
                body, chars, usd = gemini_request(plan, name, lid, voice)
                jobs.append((name, lid, voice, body, chars, usd))
            continue
        for voice in [sp['voice']] + sp.get('alternates', []):
            body, chars = request(voice, plan['lines'][lid], sp)
            jobs.append((name, lid, voice, body, chars, chars * PRICE_PER_M[family(voice)] / 1000000.0))
    total = sum((j[5] for j in jobs))
    print(f'{len(jobs)} renders, {sum((j[4] for j in jobs))} characters, at most ${total:.3f} before the free tier')
    if total > a.cap_usd:
        sys.exit(f'the audition would exceed the ${a.cap_usd} cap')
    project = json.loads(Path(a.credentials).read_text())['project_id']
    tok = token(a.credentials)
    log, spent = ([], 0.0)
    for name, lid, voice, body, chars, usd in jobs:
        if spent + usd > a.cap_usd:
            sys.exit('cap reached')
        pcm = synth(tok, project, body)
        if pcm[:4] == b'RIFF':
            data = pcm
        else:
            import io
            buf = io.BytesIO()
            with wave.open(buf, 'wb') as w:
                w.setnchannels(1)
                w.setsampwidth(2)
                w.setframerate(body['audioConfig']['sampleRateHertz'])
                w.writeframes(pcm)
            data = buf.getvalue()
        f = out / f"{name.replace(' ', '_').replace('(', '').replace(')', '')}__{voice}__{lid}.wav"
        f.write_bytes(data)
        spent += usd
        log.append(dict(speaker=name, line=lid, voice=voice, characters=chars, usd_upper_bound=round(usd, 5), file=f.name, text=plan['lines'][lid]['text']))
        print(f.name, flush=True)
    (out / 'log.json').write_text(json.dumps(dict(total_usd_upper_bound=round(spent, 4), renders=log), indent=1, ensure_ascii=False) + '\n')
    first = {n: s['voices'][0] for n, s in plan['gemini']['speakers'].items()} if a.engine == 'gemini' else {n: s['voice'] for n, s in plan['speakers'].items()}
    (out / 'index.txt').write_text(f"Strider EX dub audition ({a.engine}; Google stock voices; PROPOSED = the plan's first choice). Pick one voice per speaker.\n\n" + '\n'.join((f"{r['speaker']:28} {r['voice']:30} {('PROPOSED' if r['voice'] == first[r['speaker']] else ''):9}{r['line']}: {r['text']}" for r in log)) + '\n')
    DS.seal(out)
    print(f'done: {len(log)} renders, at most ${spent:.3f}')
    return 0

def render(a):
    import dub_store as DS
    plan = json.loads(VOICES.read_text())
    cast = json.loads((ROOT / 'backports/striderex/manifests/dub_cast.json').read_text())
    out = DS.new_set(a.set)
    want = set(a.lines.split(',')) if a.lines else None
    if (a.voice or a.style) and (not want):
        sys.exit('--voice and --style recast the lines named by --lines only')
    jobs = []
    for lid, line in plan['lines'].items():
        if not line.get('plain') or (want and lid not in want):
            continue
        c = dict(cast['speakers'][line['speaker']])
        if a.voice:
            c['voice'] = a.voice
        if a.style:
            c['direction'] = a.style
        pronounce = None
        if a.name_spell or a.name_say or a.name_ipa:
            pronounce = {'Hiryu': dict(spell=a.name_spell or PRONOUNCE['Hiryu']['spell'], say=a.name_say or PRONOUNCE['Hiryu']['say'], ipa=a.name_ipa)}
        body, chars, usd = gemini_request(plan, line['speaker'], lid, c['voice'], c.get('direction'), (a.extra or {}).get(lid), pronounce, (a.text or {}).get(lid))
        jobs.append((lid, line, c['voice'], body, chars, usd))
    total = sum((j[5] for j in jobs))
    print(f'{len(jobs)} lines, at most ${total:.3f}')
    if total > a.cap_usd:
        sys.exit(f'the render would exceed the ${a.cap_usd} cap')
    project = json.loads(Path(a.credentials).read_text())['project_id']
    tok = token(a.credentials)
    rows, spent, failed = ([], 0.0, [])
    import time
    import urllib.error
    for lid, line, voice, body, chars, usd in jobs:
        pcm = None
        for attempt in range(2):
            try:
                pcm = synth(tok, project, body)
                break
            except urllib.error.HTTPError as e:
                print(f'{lid}: HTTP {e.code}: {e.read().decode()[:300]}', flush=True)
                time.sleep(5)
        if pcm is None:
            failed.append(lid)
            continue
        if pcm[:4] != b'RIFF':
            import io
            buf = io.BytesIO()
            with wave.open(buf, 'wb') as w:
                w.setnchannels(1)
                w.setsampwidth(2)
                w.setframerate(body['audioConfig']['sampleRateHertz'])
                w.writeframes(pcm)
            pcm = buf.getvalue()
        (out / f'{lid}.wav').write_bytes(pcm)
        spent += usd
        rows.append(dict(line=lid, speaker=line['speaker'], voice=voice, model=body['voice']['modelName'], prompt=body['input']['prompt'], text=body['input']['text'], usd_upper_bound=round(usd, 5), wav_sha256=hashlib.sha256((out / f'{lid}.wav').read_bytes()).hexdigest(), **{'custom_pronunciations': body['input']['customPronunciations']} if 'customPronunciations' in body['input'] else {}))
        print(lid, voice, flush=True)
    (out / 'voices.json').write_text(json.dumps(dict(placeholder=False, source=f"Google Cloud Text-to-Speech, {plan['gemini']['model']}", total_usd_upper_bound=round(spent, 4), lines=rows), indent=1, ensure_ascii=False) + '\n')
    DS.seal(out)
    print(f'done: {len(rows)} lines, at most ${spent:.3f}' + (f'; FAILED: {failed}' if failed else ''))
    return 1 if failed else 0

def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest='cmd', required=True)
    s = sub.add_parser('audition')
    s.add_argument('--credentials', type=Path, required=True)
    s.add_argument('--set', required=True, help='a new set in the durable take store (dub_store.py)')
    s.add_argument('--cap-usd', type=float, default=5.0)
    s.add_argument('--engine', choices=['classic', 'gemini'], default='classic')
    s = sub.add_parser('render')
    s.add_argument('--credentials', type=Path, required=True)
    s.add_argument('--set', required=True, help='a new set in the durable take store (dub_store.py)')
    s.add_argument('--cap-usd', type=float, default=5.0)
    s.add_argument('--lines', help='comma-separated line ids (default: every voiced line)')
    s.add_argument('--extra-json', type=Path, help='{line id: extra direction} for retakes')
    s.add_argument('--voice', help="recast audition: this stock voice for the --lines instead of the cast's")
    s.add_argument('--style', help="recast audition: this acting style in place of the speaker's (dub_voices.json gemini.speakers), for the --lines")
    s.add_argument('--name-spell', help="candidate: the spelling of Hiryu sent to the engine in place of PRONOUNCE's (Hee-ryoo); the subtitles are not touched")
    s.add_argument('--name-say', help="candidate: the pronunciation instruction for the name in place of PRONOUNCE's")
    s.add_argument('--name-ipa', help="candidate: also send the API's custom pronunciation (IPA) for the spelled name")
    s.add_argument('--text-json', type=Path, help='candidate: {line id: the text sent to the engine}, the line re-punctuated (a pause, a beat); its words may not change')
    a = p.parse_args()
    if a.cmd == 'render':
        a.extra = json.loads(a.extra_json.read_text()) if a.extra_json else None
        a.text = json.loads(a.text_json.read_text()) if a.text_json else None
        return render(a)
    return audition(a)
if __name__ == '__main__':
    sys.exit(main())
