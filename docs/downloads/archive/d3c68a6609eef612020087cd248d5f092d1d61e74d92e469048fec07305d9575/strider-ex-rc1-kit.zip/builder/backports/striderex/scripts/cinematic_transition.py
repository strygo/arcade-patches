"""Native opening pacing derived from the unchanged scene stream."""
import struct
import cinematic_timing as T
FADE_LEAD = 210
FADE_INTERVAL = 6
LOGO_HOLD = 90

def logo_trim(stream, hold=LOGO_HOLD):
    records = T.records(stream)
    stable = max((i for i, (_, body) in enumerate(records) if any((op != 7 for op, slot, q in T.ops(body)))))
    state = {}
    history = []
    for i, (_, body) in enumerate(records[stable + 1:], stable + 1):
        for op, slot, q in T.ops(body):
            if op != 7:
                raise ValueError('title tail is not a cell-only hold')
            count = struct.unpack_from('>H', body, q + 2)[0]
            for n in range(count):
                off, value = struct.unpack_from('>HI', body, q + 4 + 6 * n)
                state[slot, off] = value
        history.append((i + 1, dict(state)))
    if not history or len(state) != 8:
        raise ValueError('unrecognized opening-title blink')
    cut = next((record for record, s in history if record >= stable + 1 + hold and s == state), None)
    if cut is None or len(records) - cut < 200:
        raise ValueError('opening title has no useful safe trim')
    return dict(cut_record=cut, original_records=len(records), removed_records=len(records) - cut, stable_record=stable + 1, hold_records=cut - stable - 1, final_cell_state_preserved=True)

def self_test():

    def record(body):
        return struct.pack('>H', len(body)) + body

    def cells(value):
        return struct.pack('>HH', 7, 8) + b''.join((struct.pack('>HI', n * 4, value + n) for n in range(8))) + b'\x00\x00'
    head = record(bytes.fromhex('000e0000'))
    tail = b''.join((record(cells(i // 10 % 2)) for i in range(500)))
    stream = head + tail + b'\xff\xff'
    trim = logo_trim(stream)
    assert trim['cut_record'] < 200 and trim['removed_records'] > 300
    assert trim['final_cell_state_preserved']
    for bad in (stream[:200] + b'\xff\xff', head + record(cells(0)) + b'\xff\xff'):
        try:
            logo_trim(bad)
        except (ValueError, struct.error):
            pass
        else:
            raise AssertionError('unsafe title trim accepted')
    print('title transition self-test PASS')
if __name__ == '__main__':
    import sys
    if sys.argv[1:] == ['--self-test']:
        self_test()
