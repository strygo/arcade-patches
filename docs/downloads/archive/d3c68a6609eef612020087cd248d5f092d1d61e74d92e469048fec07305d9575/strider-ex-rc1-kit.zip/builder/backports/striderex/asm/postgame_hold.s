; Original initials confirmation holds for 90 frames. Add 390 scheduler
; ticks before the existing transition, keeping the entered name visible
; for 480 frames (~8 seconds). No input or credit is synthesized.
        org $1FF600
        movem.l d0/a0,-(sp)
        move.w  #389,d0
.wait:
        move.w  d0,-(sp)
        moveq   #1,d0
        jsr     $7DE
        move.w  (sp)+,d0
        dbra    d0,.wait
        movem.l (sp)+,d0/a0
        move.b  #6,-$7323(a5)
        rts
