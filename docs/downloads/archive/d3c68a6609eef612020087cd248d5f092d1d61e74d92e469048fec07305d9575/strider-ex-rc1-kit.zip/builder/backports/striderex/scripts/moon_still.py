"""Match the Moon menu still to the settled native entrance camera."""
import argparse
from copy import deepcopy
import json
from pathlib import Path
import struct
import sys
import stage_openings as SO
import title_ex as TX
import mapper_testkit as K
from boss_voice_gate import inventory, sha
BASE = 2072576
LIMIT = 2076672

def record(still):
    band = SO.band(still)
    words = [band['word'], band['black'], *band['bases']['A'], *band['bases']['B'], *(band['regs'][k] for k in SO.SNAP_REGS)]
    data = bytearray(struct.pack('>' + str(len(words)) + 'H', *words))
    for address, values in SO.blocks(still):
        data += struct.pack('>IH', address, len(values) - 1)
        data += struct.pack('>' + str(len(values)) + 'H', *values)
    return bytes(data) + b'\x00' * 4

def patch(raw, table, before, after):
    bank = bytearray((raw[i ^ 1] for i in range(len(raw))))
    at = table - 1048576 + 5 * 4
    old = int.from_bytes(bank[at:at + 4], 'big') - 1048576
    if old < 0 or bank[old:old + len(before)] != before:
        raise ValueError('Moon still is not the original six-stage source snapshot')
    off = BASE - 1048576
    if len(after) > LIMIT - BASE or bank[off:off + len(after)] != b'\xff' * len(after):
        raise ValueError('Moon still data allocation occupied or oversized')
    bank[off:off + len(after)] = after
    bank[at:at + 4] = BASE.to_bytes(4, 'big')
    return bytes((bank[i ^ 1] for i in range(len(bank))))

def produce(a):
    meta, files = inventory(a.build)
    result = deepcopy(meta)
    if meta.get('test_ending') or len(meta['stills']['entries']) != 6:
        raise ValueError('six normal release entries required')
    snaps, _ = SO.load(a.openings, a.rom_dir)
    a.out.mkdir(parents=True, exist_ok=False)
    for machine, members in files.items():
        snap = snaps[machine, 4]
        if (snap['regs']['s2y'], snap['regs']['s3y']) != (704, 1763):
            raise ValueError('original Moon capture camera differs')
        tiles = SO.Tiles(TX.stock_gfx(K.pool([a.rom_dir / machine])))
        old = SO.still(snap, tiles)
        settled = deepcopy(snap)
        settled['regs']['s2y'] -= 23
        settled['regs']['s3y'] -= 30
        new = SO.still(settled, tiles)
        before, after = (record(old), record(new))
        changed = patch(members['strex_p6.bin'], meta['sets'][machine]['stage_select_syms']['ss_snaps'], before, after)
        dest = a.out / machine
        dest.mkdir()
        f = dict(members)
        f['strex_p6.bin'] = changed
        for name, data in f.items():
            (dest / name).write_bytes(data)
        entry = result['stills']['entries']['still5'][machine]
        entry.update(SO.report(new))
        result['sets'][machine]['moon_still'] = dict(address=BASE, bytes=len(after), sha256=sha(after), source_digest=SO.digest(old), settled_digest=SO.digest(new), camera_delta=[23, 30])
        result['sets'][machine]['files'] = {name: sha(data) for name, data in f.items()}
    (a.out / 'build.json').write_text(json.dumps(result, indent=2) + '\n')
    print('Moon menu still matches the settled entrance; all other ROM members preserved')

def main():
    if sys.argv[1:] == ['--self-test']:
        bank = bytearray(b'\xff' * 1048576)
        table = 1048704
        before = b'original snapshot'
        after = b'settled snapshot'
        bank[148:152] = 1048832 .to_bytes(4, 'big')
        bank[256:256 + len(before)] = before
        swap = lambda b: bytes((b[i ^ 1] for i in range(len(b))))
        changed = patch(swap(bank), table, before, after)
        assert swap(changed)[BASE - 1048576:BASE - 1048576 + len(after)] == after
        for kind in ('source', 'occupied', 'oversized'):
            damaged = bytearray(bank)
            if kind == 'source':
                damaged[256] ^= 1
            if kind == 'occupied':
                damaged[BASE - 1048576] = 0
            try:
                patch(swap(damaged), table, before, b'x' * 4097 if kind == 'oversized' else after)
            except ValueError:
                pass
            else:
                raise AssertionError('invalid still accepted: ' + kind)
        print('Moon still guards PASS: source, allocation and size damage rejected')
        return
    p = argparse.ArgumentParser(description=__doc__)
    for n in ('build', 'openings', 'rom-dir', 'out'):
        p.add_argument('--' + n, type=Path, required=True)
    a = p.parse_args()
    for k, v in vars(a).items():
        setattr(a, k, v.resolve())
    produce(a)
if __name__ == '__main__':
    main()
