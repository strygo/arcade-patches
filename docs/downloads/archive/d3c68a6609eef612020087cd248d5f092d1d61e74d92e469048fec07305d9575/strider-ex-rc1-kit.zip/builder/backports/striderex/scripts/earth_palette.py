"""Make the stock Earth's two background pens true black on CPS-1 hardware."""
import argparse
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import sys
PALETTES = (bytes.fromhex('f111fffffccef000f000f9abf000fabdf8acf79bf08af057f045f034f023f000'), bytes.fromhex('f111fffffccef000f000f9abf000fabdf8acf79bf079f057f068f079f08af000'))
OFFSETS = {'striderua': (290114, 851086), 'striderjr': (289418, 851086)}

def sha(data):
    return hashlib.sha256(data).hexdigest()

def patch_image(image, machine):
    """Guard both complete palettes, then replace their first words only."""
    for at, expected in zip(OFFSETS[machine], PALETTES):
        if image[at:at + 32] != expected:
            raise ValueError(f'{machine}: Earth palette at {at:#x} differs')
    before = bytes(image)
    for at in OFFSETS[machine]:
        image[at:at + 2] = bytes.fromhex('f000')
    allowed = {i for at in OFFSETS[machine] for i in (at, at + 1)}
    changed = {i for i, (a, b) in enumerate(zip(before, image)) if a != b}
    if changed != allowed:
        raise ValueError('Earth repair changed bytes outside its two pens')
    return dict(patches=[dict(address=hex(at), old='f111', new='f000', palette_sha256=sha(p)) for at, p in zip(OFFSETS[machine], PALETTES)], changed_bytes=len(changed), artwork_and_other_colors_unchanged=True)

def produce(build, out):
    import respawn_fix as RF
    metadata = json.loads((build / 'build.json').read_text())
    result = deepcopy(metadata)
    out.mkdir(parents=True, exist_ok=False)
    observations = {}
    for machine, spec in metadata['sets'].items():
        files = {n: (build / machine / n).read_bytes() for n in spec['files']}
        if any((sha(data) != spec['files'][n] for n, data in files.items())):
            raise ValueError('input build changed')
        image = RF.compose(files, RF.SETS[machine])
        observations[machine] = patch_image(image, machine)
        changed = RF.decompose(image, RF.SETS[machine], {n: len(files[n]) for n, _, _ in RF.SETS[machine]})
        files.update(changed)
        (out / machine).mkdir()
        for name, data in files.items():
            (out / machine / name).write_bytes(data)
        result['sets'][machine]['files'] = {n: sha(data) for n, data in files.items()}
        result['sets'][machine]['earth_palette'] = observations[machine]
    (out / 'build.json').write_text(json.dumps(result, indent=2) + '\n')
    receipt = dict(schema='striderex-earth-palette-build/1', passed=True, command='earth_palette.py --build <verified-or-fresh-build> --out <fresh-candidate>', input_files={m: s['files'] for m, s in metadata['sets'].items()}, build_files={m: s['files'] for m, s in result['sets'].items()}, regions=observations, script_sha256=sha(Path(__file__).read_bytes()))
    (out / 'earth-build.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print('PASS: two exact Earth background pens per region; every other ROM byte preserved')

def self_test():
    for machine, offsets in OFFSETS.items():
        image = bytearray(b'\xff' * 1048576)
        for at, data in zip(offsets, PALETTES):
            image[at:at + 32] = data
        original = bytes(image)
        assert patch_image(image, machine)['changed_bytes'] == 4
        for at in offsets:
            assert image[at:at + 2] == bytes.fromhex('f000')
        bad = bytearray(original)
        bad[offsets[1] + 7] ^= 1
        unchanged = bytes(bad)
        try:
            patch_image(bad, machine)
        except ValueError:
            pass
        else:
            raise AssertionError('foreign palette accepted')
        assert bytes(bad) == unchanged, 'failed guard modified the image'
    print('Earth palette self-test PASS')

def main():
    if sys.argv[1:] == ['--self-test']:
        return self_test()
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--build', type=Path, required=True)
    p.add_argument('--out', type=Path, required=True)
    a = p.parse_args()
    produce(a.build.resolve(), a.out.resolve())
if __name__ == '__main__':
    main()
