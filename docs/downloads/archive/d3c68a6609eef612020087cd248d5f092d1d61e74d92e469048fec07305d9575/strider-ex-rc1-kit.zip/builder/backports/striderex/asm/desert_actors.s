; Strider EX desert actors (DESERT_ENEMIES.md; step 1, the pilot: the rifle soldier; step 2: the
; bazooka soldier, its rocket and the buried mine; step 3: the wave managers, the winged drones and
; the item containers as the arcade's own capsules; step 4: the sandworm; step 5: the pipe walker robot, its
; legs and its beam, and the valve flames; step 6: the camouflaged jeep and its gunner; step 7: the red-cap
; officer who becomes the antlion, its sand grains, energy ball and needles, and the sand-pull controller; step 8: section
; 4's commander, the tank boss with its four parts, its hull (on SCROLL2), its shells, mortar shells and casings, the sand
; strip, and Hiryu riding its deck).
; Included by desert.s (DESERT builds only). scripts/desert_actors_ex.py writes
; desert_actors.inc (frame records, animation tables, hitboxes, spawn lists);
; desert_ex.py writes the stock addresses (DA_* in desert_syms.inc) and points
; pool 5's dead type 3 (its dispatch long, USA 0x1E748, Japan 0x1E490) at
; da_dispatch. No stock list, spawn site or run uses that type, so the stock
; stages run the same instructions as before.
;
; The actors are pool-5 objects of type 3 ($17), their kind in $6 (the
; record's first parameter). The stock record fill (0x2DC8, through the pool-5
; allocator stub 0x2DA0) makes them from 8-byte records: type, kind, facing,
; spawn-once id, X, Y (arcade world, Y up).
;
; They keep $7 bit 7 set (every frame record has it), so every stock collision
; pass skips them; da_collide runs their pass from dz_stage after the actors'
; update, with the stock pass's gates (Hiryu active and in a normal state, not
; invulnerable, odd frames) and the stock tests 0x82D0 (Hiryu) and 0x8216 (an
; attack in list P), the stock spark 0x8A16, Hiryu's own hurt path ($1E, as the
; stock contact response 0x84C0) and one target per slash (the attack's $33).
;
; Drawing: list A (0x13E0, behind Hiryu; the mine, the robot's beam, the valve
; flame and the jeep: list C, 0x140C, in front of him, as the PC Engine's layer 0) through the stock single emitter (0x6F8D4)
; with free-list frame records (format 28, one attribute; format 32, an
; attribute per piece, for frames that mix PC Engine palettes) and EX sprite
; codes; the stock animation helpers 0xB78 (start) and 0xBA6 (step).
;
; Time: a PC Engine tick is 2 frames; timers double, speeds per frame halve.
; Space: X 1.5x (desert_ex.arc_x), Y unchanged and up.

K_SOLDIER equ   0
K_BULLET equ    1
K_GRENADE equ   2
K_SMOKE  equ    3
K_GEN    equ    4
K_BAZOOKA equ   5
K_ROCKET equ    6
K_MINE   equ    7
K_DRONE  equ    8
K_WAVE   equ    9
K_ITEM   equ    10                      ; map lists only: a stock capsule (da_capsule), never an actor
K_WORM   equ    11
K_ROBOT  equ    12
K_LEG    equ    13                      ; a robot's leg: placed and drawn by its robot
K_BEAM   equ    14                      ; a robot's beam: its head
K_SEG    equ    15                      ; the beam's segment: placed and drawn by its head
K_FLAME  equ    16
K_JEEP   equ    17
K_GUNNER equ    18                      ; the jeep's gunner: placed, stepped and drawn by its jeep
K_OFFICER equ   19                      ; the red-cap officer, then the antlion (section 1's mid-boss)
K_GRAIN  equ    20                      ; its sand grains
K_BALL   equ    21                      ; its energy ball
K_NEEDLE equ    22                      ; the ball's needles
K_PULL   equ    23                      ; the sand-pull controller: unseen, stepped by the officer while it lives
K_COMMANDER equ 24                      ; section 4's commander
K_TANK   equ    25                      ; the tank: unseen (its hull is SCROLL2), it steps, places and draws its parts
K_PART   equ    26                      ; one of the tank's four parts (0 inert, 1 the turret, 2 the cannon, 3 the hatch soldier)
K_SHELL  equ    27                      ; the tank's shell, casing or mortar shell (O_SHP: the PC Engine 0x4B's parameter)
K_STRIP  equ    28                      ; the sand strip (block sprites)

; object fields (stock meaning: PHASE0_FINDINGS.md "The arcade enemy system")
O_SCR    equ    $01                     ; on screen (0xDD6, from the list registration)
O_ST     equ    $02                     ; state: 0 init, 2 run, 4 dying, 6 free
O_SUB    equ    $03                     ; sub-state (word offsets)
O_KIND   equ    $06                     ; kind (record parameter 1)
O_FLG    equ    $07                     ; 0x80 | hitbox (the frame records)
O_X      equ    $08                     ; 16.16
O_Y      equ    $0C                     ; 16.16, up
O_FACE   equ    $16                     ; bit 0: facing left (the PC Engine's +2; record parameter 2)
O_HITS   equ    $1E                     ; slashes received (da_collide)
O_KB     equ    $1F
O_ID     equ    $21                     ; spawn-once id (record parameter 3; $FF none)
O_FLOOR  equ    $22                     ; floor kind (the floor snap)
O_VX     equ    $34                     ; long, 16.16 per frame
O_VY     equ    $38                     ; long, 16.16 per frame, up
O_T1     equ    $3C                     ; word timer
O_T2     equ    $3E                     ; word
O_COL    equ    $40                     ; bit 0: hurts Hiryu on contact; bit 1: a slash kills it; bit 2: the
                                        ; contact spends it
O_ANIM   equ    $41                     ; current animation (anim * 2 + facing), $FF none
O_WDIR   equ    $42                     ; walking direction (bit 0: left)
O_GI     equ    $43                     ; generator: the once-id index 0-5
O_GN     equ    $44                     ; generator: the timer step 0-15
O_WPC    equ    $3E                     ; wave manager: its script position (bytes; O_T2)
O_WSET   equ    $43                     ; wave manager: bit 0 its PC Engine Y is not 0, bit 1 its X (O_GI)
O_HEAD   equ    $45                     ; drone: heading (256 a turn, 0 up, clockwise)
O_SPD    equ    $46                     ; drone: speed (da_dr_vel's block: DA_DR_GLIDE, _HOME, _ENTRY)
O_TICK   equ    $47                     ; drone: bit 0 set on the frames between its ticks
O_CAP    equ    $48                     ; drone: long, its capsule (0 none)
O_KID    equ    $48                     ; sandworm: long, the arch it made (0 none)
O_PAR    equ    $4C                     ; sandworm: long, the arch that made it
O_SWC    equ    $43                     ; sandworm: its next arch tried (the PC Engine's chain state 3)
O_PX     equ    $2A                     ; robot: long, its PC Engine X (8.8)
O_PY     equ    $2E                     ; robot: long, its PC Engine Y (8.8, down)
O_RSPD   equ    $32                     ; robot: its walk speed (the PC Engine's +0x2F: 0, DA_RB_SPEED right, minus left)
O_RPH    equ    $42                     ; robot: the dome's phase (0-7)
O_RCT    equ    $43                     ; robot: the ticks to the dome's next phase
O_RSPIN  equ    $44                     ; robot: the dome (+0x2C: 0 still, 1 turning, 2 aiming right, 3 aiming left)
O_RWALK  equ    $45                     ; robot: walking (+0x2D: its legs stride)
O_RDIR   equ    $46                     ; robot: its direction (+0x2E: 0 right, 1 left)
O_RSTEP  equ    $33                     ; robot: ticks to its next walk sound (+0x1C; O_RSPD is the byte at $32)
O_LEGA   equ    $48                     ; robot: long, leg A (3 px in front; 0 none)
O_LEGB   equ    $4C                     ; robot: long, leg B (3 px behind)
O_LPH    equ    $42                     ; leg: its stride's phase (0-7)
O_BN     equ    $42                     ; beam: its pieces (the PC Engine's +0x28)
O_SEG    equ    $48                     ; beam: long, its segment (0 none)
O_BODY   equ    $4C                     ; leg, segment, gunner: long, its robot, beam or jeep
O_JVX    equ    $32                     ; jeep: word, its X velocity (8.8 px/tick; the PC Engine's +0x14)
O_JHY    equ    $3E                     ; jeep: word, its home Y (PC Engine; +0x2C)
O_JAN    equ    $42                     ; jeep: the animation asked for (+0x0E)
O_JCUR   equ    $43                     ; jeep: the animation playing (+0x0F; $FF: start it again)
O_JSTEP  equ    $44                     ; jeep: its next step (+0x10)
O_JCT    equ    $45                     ; jeep: ticks left on its step (+0x11)
O_JFR    equ    $46                     ; jeep, gunner: the PC Engine frame shown (+0x03)
O_GUN    equ    $48                     ; jeep: long, its gunner (0 none)
O_JBC    equ    $4C                     ; jeep: the bounce's shake and the death drive's debris counter (+0x1B)
O_JFL    equ    $4D                     ; jeep: its displayed X flip (+0x01 bit 0: set facing right)
O_GST    equ    $42                     ; gunner: ticks to its next fire step (+0x1B)
O_GPA    equ    $43                     ; gunner: fire steps left in its pause (+0x2A)
O_GSH    equ    $44                     ; gunner: shots in this burst (+0x2B)
O_GFI    equ    $45                     ; gunner: its aim fires ($80; +0x29)
O_GFL    equ    $47                     ; gunner: its X flip, the jeep's as it last placed it (+0x01 bit 0)
O_OVY    equ    $32                     ; officer, projectiles: word, the Y velocity (8.8 px/tick, Y down: +0x12)
O_PVX    equ    $48                     ; projectiles: word, the X velocity (8.8 px/tick: +0x14)
O_HEAD7  equ    $4A                     ; projectiles: the heading (+0x1D)
O_GONE   equ    $4B                     ; projectiles: going (PC Engine state 2): freed on the next tick
O_PULL   equ    $48                     ; officer: long, its sand-pull controller (0 none)
O_PHITS  equ    $4C                     ; officer: ticks with a slash counted (+0x20)
O_PAT    equ    $4D                     ; officer: its place in its pattern (+0x2D)
O_RANK   equ    $4E                     ; officer: the rank its pattern is from (+0x2B)
O_ACT    equ    $4F                     ; officer: its action (+0x2C)
O_PCNT   equ    $42                     ; pull: ticks to the next phase of the cycle (+0x2B)
O_PPH    equ    $43                     ; pull: the cycle's phase (+0x29)
O_PSTR   equ    $44                     ; pull: its strength byte (+0x28; the strength is its top 2 bits)
O_PS     equ    $45                     ; pull: the strength the tick drags with (+0x28 >> 6, before its decay)
O_PLAST  equ    $46                     ; pull: the frame counter's byte of its last step (one step a frame)
O_TKCOLF equ    $41                     ; tank: its colflags (+0x0B: 0xC0 once its patrol starts; its parts' AND it)
O_TKCN   equ    $42                     ; tank: its cannon's machine (+0x2E)
O_TKTU   equ    $43                     ; tank: its turret's machine (+0x2F)
O_TKTT   equ    $44                     ; tank: the turret's timer (+0x1C)
O_TKAIM  equ    $45                     ; tank: the turret's aim (+0x1D: $80 fires, bit 0 low)
O_TKFL   equ    $46                     ; tank: its parts' bits (+0x29: 0-3 destroyed, 4-7 hit this tick)
O_TKMI   equ    $48                     ; tank: the mortar's shell index (+0x2A)
O_TKC0   equ    $49                     ; tank: part 0's command (+0x2B)
O_TKC2   equ    $4A                     ; tank: part 2's (+0x2C)
O_TKC1   equ    $4B                     ; tank: part 1's (+0x2D)
O_TKTP   equ    $4C                     ; tank: the treads' phase (+0x10)
O_TKTR   equ    $4D                     ; tank: their timer (+0x28)
O_TKBP   equ    $4E                     ; tank: the bob's phase (+0x22); dying: the debris script's place
O_TKBT   equ    $4F                     ; tank: its timer (+0x23); dying: the debris script's timer
O_TKVY   equ    $3E                     ; tank, dying: word, its Y velocity (8.8 px/tick, down: +0x12; O_T2, the cannon's
                                        ; timer while it lives: +0x11)
O_PIX    equ    $42                     ; part: its index (0-3)
O_PRM    equ    $43                     ; part: its rise machine (+0x14)
O_PAM    equ    $44                     ; part: its action machine (+0x15)
O_PT     equ    $45                     ; part: its timer (+0x17)
O_PFL    equ    $47                     ; part 3: its flags (+0x02: $80 raised, $40 lowered, $20 its shot done, $08 rise, $04
                                        ; lower and $02 shoot asked)
O_PHT    equ    $48                     ; part: its hits (+0x10; $FF destroyed)
O_PPU    equ    $49                     ; part 3: its pop-up machine (+0x11)
O_PRISE  equ    $32                     ; part: word, its rise (8.8, Y down: +0x12)
O_PPX    equ    $2A                     ; part: word, its PC Engine X as the tank placed it on its tick (+0x06)
O_PPY    equ    $2C                     ; part: word, its PC Engine Y (+0x04)
O_SHP    equ    $4A                     ; shell: its parameter (0 the shell, 1 a casing, 2 a mortar shell)
O_SHI    equ    $4C                     ; shell: a mortar shell's index (+0x1C)

HIRYU    equ    -$6F36                  ; (a5) Hiryu's object 0xFF10CA
INVULN   equ    -$730C                  ; (a5) 0xFF0CF4: frames of invulnerability after a hit
HOLDC    equ    -$7320                  ; (a5) 0xFF0CE0: the stock contact pass waits while it is set
FRAMEC   equ    -$73DD                  ; (a5) 0xFF0C23: frame counter (contact on odd frames)
LIST_P   equ    -$1C0A                  ; (a5) list P (Hiryu's attacks): stack pointer
LIST_PN  equ    -$1C26                  ; (a5) and count
POOL5_FREE equ  -$1622                  ; (a5) pool 5's free count
POOL6_FREE equ  -$1620                  ; (a5) pool 6's (the explosions and sparks; its allocator 0x11EE)
POOL5    equ    $FF211A                 ; 30 x 0x50
DA_S3Y   equ    $FF0C3E                 ; the SCROLL3 Y shadow the layer code leaves (0x1DCA4), the VBlank's
DA_CAM_TOP equ  DZ_CAM_TOP              ; layer Y = DA_CAM_TOP - the PC Engine camera's Y (desert_ex.CAM_TOP)
S2OBJ    equ    -$7054                  ; (a5) the SCROLL2 layer object 0xFF0FAC: X +8, Y +C (0x1CE9E, its shadow from them)
S2SHX    equ    -$73CC                  ; (a5) its scroll shadow 0xFF0C34/36, the VBlank's
S2SHY    equ    -$73CA

DA_VARS  equ    $FFFA00                 ; work RAM (ACTIVE_HANDOFF.md map), to 0xFFFA9F
DA_ONCE  equ    DA_VARS                 ; 128 bytes: per PC Engine spawn-once id: 0 free, 1 alive, 2 dead
DA_SCAN  equ    DA_VARS+$80             ; word: the map list has been scanned since the setup
DA_SEC   equ    DA_VARS+$82             ; word: the section the actors belong to
DA_REC   equ    DA_VARS+$84             ; 8 bytes: a spawn record being built
DA_KILLS equ    DA_VARS+$8C             ; word: soldiers killed (gates)
DA_SPAWN equ    DA_VARS+$8E             ; word: soldiers spawned (gates)
DA_HURT  equ    DA_VARS+$90             ; word: contacts that hurt Hiryu (gates)
DA_SHOTS equ    DA_VARS+$92             ; word: bullets and grenades fired (gates)
DA_CUTS  equ    DA_VARS+$94             ; word: slashes that hit an actor (gates)
DA2      equ    $FFFAA0                 ; step 2's work RAM (ACTIVE_HANDOFF.md map), to 0xFFFABF
DA_BZSPAWN equ  DA2+$00                 ; word: bazooka soldiers started (gates)
DA_BZKILL equ   DA2+$02                 ; word: bazooka soldiers killed (gates)
DA_ROCKETS equ  DA2+$04                 ; word: rockets fired (gates)
DA_MNSPAWN equ  DA2+$06                 ; word: mines started (gates)
DA_MNWARN equ   DA2+$08                 ; word: mine warnings: Hiryu over a mine (gates)
DA_MNBLAST equ  DA2+$0A                 ; word: mine blasts (gates)
DA3      equ    $FFFAC0                 ; step 3's work RAM (ACTIVE_HANDOFF.md map), to 0xFFFAFF
DA_RANKT equ    DA3+$00                 ; word: frames of desert play since the setup (the PC Engine's rank)
DA_DRSPAWN equ  DA3+$02                 ; word: drones started (gates)
DA_DRKILL equ   DA3+$04                 ; word: drones killed (gates)
DA_WVSPAWN equ  DA3+$06                 ; word: drones the wave managers spawned (gates)
DA_CAPS  equ    DA3+$08                 ; word: capsules spawned (gates)
DA_CAPFULL equ  DA3+$0A                 ; word: capsules pool 7 had no room for (gates)
DA_STRIP equ    DA3+$0C                 ; word: drone items the rank took away (gates)
DA_SWARCH equ   DA3+$0E                 ; word: arches the sandworms made (gates)
DA_CREC  equ    DA3+$10                 ; 8 bytes: a capsule's spawn record being built
DA_SWUP  equ    DA3+$18                 ; word: arches that surfaced (gates)
DA_SWKILL equ   DA3+$1A                 ; word: arches killed (gates)
DA_SWSTOP equ   DA3+$1C                 ; word: chains stopped off screen ahead (gates)
DA_SWEND equ    DA3+$1E                 ; word: chains stopped where the floor ends (gates)
DA4      equ    $FFFB00                 ; step 5's work RAM (ACTIVE_HANDOFF.md map), to 0xFFFB3F (0xFFFB00-2F: DA8 since step 8)
DA7      equ    $FFFBC0                 ; step 8's work RAM (ACTIVE_HANDOFF.md map), to 0xFFFBFF
DA_KHURT equ    DA7+$00                 ; 32 bytes: contacts that hurt Hiryu, per kind (mod 256; gates)
DA_KCUT  equ    DA7+$20                 ; 32 bytes: slashes that hit an actor, per kind (mod 256; gates; both were 8
                                        ; bytes at DA2+$0C and DA2+$14 until the drone, kind 8, 16 bytes at DA3+$20 and
                                        ; DA3+$30 until the flame, kind 16, and 24 bytes at DA4+$00 and DA4+$18 until the
                                        ; strip, kind 28)
DA8      equ    $FFFB00                 ; step 8's counters and the hull (DA4's old per-kind arrays), to 0xFFFB2F
DA_CMSPAWN equ  DA8+$00                 ; word: commanders started (gates)
DA_TKSPAWN equ  DA8+$02                 ; word: tanks started (gates)
DA_TKHIT equ    DA8+$04                 ; word: hatch soldier ticks with a slash counted (gates)
DA_TKKILL equ   DA8+$06                 ; word: tank deaths started (gates)
DA_TKEND equ    DA8+$08                 ; word: tank deaths ended: 1500 points (gates)
DA_SHELLS equ   DA8+$0A                 ; word: cannon shells fired (gates)
DA_MORTARS equ  DA8+$0C                 ; word: mortar shells fired (gates)
DA_TUSHOT equ   DA8+$0E                 ; word: turret bullets fired (gates)
DA_CASINGS equ  DA8+$10                 ; word: casings ejected (gates)
DA_B3SHOT equ   DA8+$12                 ; word: hatch soldier bullets fired (gates)
DA_TKBOOM equ   DA8+$14                 ; word: explosions of the tank's death and of the mortar shells (gates)
DA_RIDE  equ    DA8+$16                 ; word: frames the deck held Hiryu (gates)
DA_HULLX equ    DA8+$18                 ; word: the hull's X (the tank's arcade X; kept after the tank goes)
DA_HULLY equ    DA8+$1A                 ; word: its Y
DA_HULLON equ   DA8+$1C                 ; byte: the hull is drawn (dz_watch scrolls SCROLL2 to it: da_hull_scroll)
DA_RIDING equ   DA8+$1D                 ; byte: the deck holds Hiryu this frame
DA_TKP   equ    DA8+$1E                 ; 4 longs: the tank's parts 0-3 (0 none), to DA8+$2D
DA_RBSPAWN equ  DA4+$30                 ; word: robots started (gates)
DA_RBKILL equ   DA4+$32                 ; word: robots killed (gates)
DA_RBTURN equ   DA4+$34                 ; word: robots turned at a wall or a drop (gates)
DA_BMFIRE equ   DA4+$36                 ; word: beams fired (gates)
DA_BMSEG equ    DA4+$38                 ; word: beam segments made (gates)
DA_LGMADE equ   DA4+$3A                 ; word: robot legs made (gates)
DA_FLSPAWN equ  DA4+$3C                 ; word: flames started (gates)
DA_FLBURST equ  DA4+$3E                 ; word: flame bursts started (gates)
DA5      equ    $FFFB40                 ; step 6's work RAM (ACTIVE_HANDOFF.md map), to 0xFFFB7F
DA_JPSPAWN equ  DA5+$00                 ; word: jeeps started (gates)
DA_JPKILL equ   DA5+$02                 ; word: jeeps killed: death drives started (gates)
DA_JPEND equ    DA5+$04                 ; word: death drives ended: wrecks (gates)
DA_JPBOUNCE equ DA5+$06                 ; word: bounces off a wall (gates)
DA_JPTURN equ   DA5+$08                 ; word: turns (gates)
DA_GNMADE equ   DA5+$0A                 ; word: gunners made (gates)
DA_GNSHOT equ   DA5+$0C                 ; word: bullets the gunners fired (gates)
DA_JPBOOM equ   DA5+$0E                 ; word: explosions of the death drives and the gunners (gates)
DA6      equ    $FFFB80                 ; step 7's work RAM (ACTIVE_HANDOFF.md map), to 0xFFFBBF
DA_OFSPAWN equ  DA6+$00                 ; word: officers started (gates)
DA_OFHIT equ    DA6+$02                 ; word: officer ticks with a slash counted (gates)
DA_OFKILL equ   DA6+$04                 ; word: officers killed: deaths started (gates)
DA_OFEND equ    DA6+$06                 ; word: deaths ended: officers freed, 700 points (gates)
DA_GRMADE equ   DA6+$08                 ; word: sand grains made (gates)
DA_GRFULL equ   DA6+$0A                 ; word: sand grains left out: pool 5 short of GRAIN_FREE (gates)
DA_BLMADE equ   DA6+$0C                 ; word: energy balls made (gates)
DA_NDMADE equ   DA6+$0E                 ; word: needles made (gates)
DA_OFBOOM equ   DA6+$10                 ; word: explosions of the officers' deaths (gates)
DA_PLDRAG equ   DA6+$12                 ; word: frames the sand-pull dragged Hiryu (gates)
DA_PLARM equ    DA6+$14                 ; word: sand-pull re-arms (gates)
DA_PLSTEP equ   DA6+$16                 ; word: steps of the flowing sand's cycle (gates)
DA_PANF  equ    DA6+$18                 ; byte: the officer's tick aimed the camera at it (0x85BD: its subs 2-4)
DA_PANON equ    DA6+$19                 ; byte: the scripted pan holds the camera (its bounds pinned: da_pan)
DA_PANT  equ    DA6+$1A                 ; word: the camera's target then: the officer's PC Engine Y
DA_LIM   equ    DA6+$1C                 ; 8 bytes: the section's camera bounds, as dz_sections op 2 sets them (X min,
                                        ; X max, Y min, Y max: the pan puts them back when it ends)
DA_DLY   equ    DA6+$24                 ; word: frames left of a dz_sections delay (op 14), 0 none
DA_PIT   equ    DA6+$26                 ; word: the pit variant shown (dz_sections op 15; 0 closed)
DA_PITW  equ    DA6+$28                 ; word: pit cells written by the last op 15 (gates)
DA_PITS  equ    DA6+$2A                 ; word: pit cells left out (outside the maps' windows; gates)

A_STAND  equ    0                       ; soldier animations (PC Engine 0-3: stand, walk, fire, lob)
A_WALK   equ    1
A_FIRE   equ    2
A_LOB    equ    3
A_AIM    equ    0                       ; bazooka soldier animations (PC Engine 0, 1: aim, fire)
A_FIRE2  equ    1
M_ARMED  equ    0                       ; mine animations (PC Engine 0-2: armed, unseen; warning; blast)
M_WARN   equ    1
M_BLAST  equ    2

SMOKE_FREE equ  8                       ; smoke only while pool 5 has this many free slots
GEN_FREE equ    4                       ; a generator spawns only while pool 5 has this many free
BOOM_EVERY equ  8                       ; the jeep's small bursts: every 8 ticks of its drive (the PC Engine's every
BOOM_FREE equ   16                      ; 2), and only while pool 6 (30) has 16 free: a stock explosion takes about 7
                                        ; for its pieces over about 30 frames (MEASURED), and the two at the drive's
                                        ; end and its gunner's must find room
DA_JP_KEEP_X0 equ -160                  ; the jeep's wreck stays while X - camera X is in [X0, X1) (its frames reach
DA_JP_KEEP_X1 equ 384+160               ; 96 px either side), until section 3 is over
GRAIN_FREE equ  12                      ; the officer's sand grains only while pool 5 has this many free: a grain is up to 6
                                        ; sprite entries, the antlion 67, the list 256 (the PC Engine's 56 actor slots
                                        ; hold more grains; it skips one when none is free)

; ---------------------------------------------------------------- dispatch
; Pool 5 type 3 (the stock loop 0x1E708: A0 = object, A6 = its $1A; keep A0,
; A5 and D7's upper word).
da_dispatch:
        moveq   #0,d0
        move.b  O_KIND(a0),d0
        cmp.w   #K_STRIP,d0
        bhi.s   .bad
        add.w   d0,d0
        move.w  .t(pc,d0.w),d0
        jmp     .t(pc,d0.w)
.bad:   bra     da_free
.t:     dc.w    da_soldier-.t,da_bullet-.t,da_grenade-.t,da_smoke-.t,da_gen-.t,da_bazooka-.t,da_rocket-.t
        dc.w    da_mine-.t,da_drone-.t,da_wave-.t,da_free-.t,da_worm-.t,da_robot-.t,da_leg-.t,da_beam-.t
        dc.w    da_seg-.t,da_flame-.t,da_jeep-.t,da_gunner-.t,da_officer-.t,da_grain-.t,da_ball-.t,da_needle-.t
        dc.w    da_pull-.t,da_commander-.t,da_tank-.t,da_part-.t,da_shell-.t,da_strip-.t

; the state dispatch shared by every kind: a0 = object, a1 = the kind's table
; (init, run, dying, free)
da_state:
        moveq   #0,d0
        move.b  O_ST(a0),d0
        and.w   #6,d0
        move.w  0(a1,d0.w),d0
        jmp     0(a1,d0.w)

da_init:                                ; common setup; d0 = collision bits
        lea     da_blk,a6
        move.l  a6,$1A(a0)
        clr.w   $28(a0)                 ; hitboxes at da_blk
        move.b  d0,O_COL(a0)
        moveq   #0,d0                   ; the kind's shape now: the floor snap's probe point and the
        move.b  O_KIND(a0),d0           ; on-screen box come from it before the first frame record loads
        lea     da_kind_shape,a4
        move.b  0(a4,d0.w),$10(a0)
        st      O_ANIM(a0)
        move.b  #$80,O_FLG(a0)          ; intangible to the stock passes from the start
        move.b  #2,O_ST(a0)
        rts

da_free:                                ; the stock pool-5 free (0x12DE: back on the stack, record cleared)
        jmp     DA_FREE5

; d0 = animation (anim * 2 + facing): started unless it is the current one
da_fanim:
        add.b   d0,d0
        btst    #0,O_FACE(a0)
        beq.s   da_anim
        addq.b  #1,d0
        bra.s   da_anim
da_anim0:
        add.b   d0,d0
da_anim:
        cmp.b   O_ANIM(a0),d0
        beq.s   .r
        move.b  d0,O_ANIM(a0)
        moveq   #0,d1
        move.b  O_KIND(a0),d1
        add.w   d1,d1
        add.w   d1,d1
        lea     da_kind_anims,a4
        movea.l 0(a4,d1.w),a4
        movea.l $1A(a0),a6
        jmp     DA_ANIM_SET             ; 0xB78: d0 = index into a4's word table (offsets from a6)
.r:     rts

; the frame (0xBA6) and the list registration (0x13E0: list A if on screen; sets $1)
da_show:
        movea.l $1A(a0),a6
        jsr     DA_ANIM_STEP
        jmp     DA_LISTA

; the stock floor snap (0x1A3E, the shape's probe point within 13 px): carry
; set = on a floor (Y moved onto it)
da_snap:
        jsr     DA_SNAP
        bcc.s   .r
        add.w   d0,O_Y(a0)
        ori     #1,ccr
.r:     rts

da_move:
        move.l  O_VX(a0),d0
        add.l   d0,O_X(a0)
        move.l  O_VY(a0),d0
        add.l   d0,O_Y(a0)
        rts

; d0.b = state for this object's spawn-once id (if it has one)
da_once_set:
        moveq   #0,d1
        move.b  O_ID(a0),d1
        bmi.s   .r
        lea     DA_ONCE,a1
        move.b  d0,0(a1,d1.w)
.r:     rts

; a spawn: d0 kind, d1 facing, d2 once id, d3 X, d4 Y -> A1, carry set when pool 5 is full
da_spawn:
        lea     DA_REC,a2
        move.b  #3,(a2)
        move.b  d0,1(a2)
        move.b  d1,2(a2)
        move.b  d2,3(a2)
        move.w  d3,4(a2)
        move.w  d4,6(a2)
        jmp     DA_FILL5                ; 0x2DA0: the pool-5 allocator, then the stock record fill 0x2DC8

    ifd PCE_SFX
; a sound command: d0 = the command, queued by the stock setters' send (DA_SOUND, USA 0x496E: the queue at
; -$7116(a5), sent a frame apart); d6 and a4, which it uses, are kept
da_sound:
        movem.l d6/a4,-(sp)
        jsr     DA_SOUND
        movem.l (sp)+,d6/a4
        rts

; the PC Engine's near test (0x5C29): d2 = the command, sent when Hiryu is within DA_NEAR_X (240 PC Engine px)
; in X and DA_NEAR_Y in Y of the object, both from their origins (da_hiryu_d)
da_sound_near:
        bsr     da_hiryu_d
        cmp.w   #DA_NEAR_X,d0
        bcc.s   .r
        cmp.w   #DA_NEAR_Y,d1
        bcc.s   .r
        move.w  d2,d0
        bra.s   da_sound
.r:     rts
    endc

; the stock explosion (pool 6 type 1, as pool 5 type 0's death spawns it, 0x1E9C6) at the object
da_explode:
        jsr     DA_ALLOC6
        bcs.s   .r
        move.w  #$0100,(a1)
        move.b  #1,$17(a1)
        move.w  O_X(a0),8(a1)
        move.w  O_Y(a0),$C(a1)
        clr.b   $3E(a1)
.r:     rts

; face Hiryu (PC Engine 0x5835): right (bit 0 clear) when Hiryu's X is not less than the object's
da_face:
        move.w  HIRYU+8(a5),d0
        cmp.w   O_X(a0),d0
        blt.s   .l
        bclr    #0,O_FACE(a0)
        rts
.l:     bset    #0,O_FACE(a0)
        rts

; carry set when the object faces away from Hiryu (PC Engine 0x5857)
da_away:
        move.w  HIRYU+8(a5),d0
        cmp.w   O_X(a0),d0
        blt.s   .left
        btst    #0,O_FACE(a0)           ; Hiryu to the right: facing right is toward him
        bne.s   .yes
.no:    andi    #$FE,ccr
        rts
.left:  btst    #0,O_FACE(a0)
        bne.s   .no
.yes:   ori     #1,ccr
        rts

; d0 = |Hiryu X - X|, d1 = |Hiryu's middle - Y| (the PC Engine measures from both origins,
; 32 px above the feet; DA_HIRYU_DY places Hiryu's)
da_hiryu_d:
        move.w  HIRYU+8(a5),d0
        sub.w   O_X(a0),d0
        bpl.s   .x
        neg.w   d0
.x:     move.w  HIRYU+$C(a5),d1
        add.w   #DA_HIRYU_DY,d1
        sub.w   O_Y(a0),d1
        bpl.s   .y
        neg.w   d1
.y:     rts

; carry set when (X - camera X) is in [d2, d3) and (Y - camera Y) in [d4, d5]
da_window:
        move.w  O_X(a0),d0
da_window_xy:                           ; d0 = X, d1 = Y
        sub.w   CAMX(a5),d0
        cmp.w   d2,d0
        blt.s   .no
        cmp.w   d3,d0
        bge.s   .no
        sub.w   CAMY(a5),d1
        cmp.w   d4,d1
        blt.s   .no
        cmp.w   d5,d1
        bgt.s   .no
        ori     #1,ccr
        rts
.no:    andi    #$FE,ccr
        rts

; ------------------------------------------------------------ the soldier
; PC Engine actor 0x44 (0x72:0xAAD6): walks, stops to look around three
; times, fires a bullet when level with Hiryu, else lobs a grenade; one slash.
da_soldier:
        lea     .s(pc),a1
        bra     da_state
.s:     dc.w    sl_init-.s,sl_run-.s,sl_die-.s,da_free-.s

; Timers follow the PC Engine's: a step's entry tick already counts down
; when the PC Engine falls through into the step (walk, fire, lob), and an
; expired timer reloads without counting (look), so its period is a tick longer.
sl_init:
        moveq   #3,d0                   ; hurts Hiryu, a slash kills it (PC Engine colflags 0xC8)
        bsr     da_init
        addq.w  #1,DA_SPAWN
        move.b  #10,O_SUB(a0)           ; PC Engine sub-state 0: into the walk, this frame
sl_run:
        tst.b   O_HITS(a0)
        bne     sl_kill
        moveq   #0,d0
        move.b  O_SUB(a0),d0
        move.w  .t(pc,d0.w),d0
        jsr     .t(pc,d0.w)
        move.w  O_Y(a0),d1              ; fallen 320 px below the camera (a pit): gone, as if killed
        sub.w   CAMY(a5),d1
        cmp.w   #-320,d1
        blt.s   .fell
        move.w  #-640,d2                ; far from the camera: freed, its id spawnable again
        move.w  #1024,d3                ; (the PC Engine keeps it; pool 5 has 30 slots)
        move.w  #-320,d4
        move.w  #560,d5
        move.w  O_Y(a0),d1
        bsr     da_window
        bcs     da_show
        moveq   #0,d0
        bsr     da_once_set
        bra     da_free
.fell:  moveq   #2,d0
        bsr     da_once_set
        bra     da_free
.t:     dc.w    sl_stand-.t,sl_air-.t,sl_walk-.t,sl_fire-.t,sl_lob-.t,sl_walk_in-.t

; stand and look (PC Engine sub 1, 0xAB35): every 16 ticks turn, three times;
; then shoot if facing Hiryu within 120 x 64 px, else walk
sl_stand_in:
        clr.b   O_SUB(a0)
        move.w  #2*16-1,O_T1(a0)
        move.w  #3,O_T2(a0)
        clr.l   O_VX(a0)
        clr.l   O_VY(a0)
        moveq   #A_STAND,d0
        bra     da_fanim
sl_stand:
        bsr     da_snap
        bcc     sl_air_in
        tst.w   O_T1(a0)
        beq.s   .look
        subq.w  #1,O_T1(a0)
        rts
.look:  move.w  #2*16+1,O_T1(a0)
        tst.w   O_T2(a0)
        beq.s   .decide
        subq.w  #1,O_T2(a0)
        bchg    #0,O_FACE(a0)
        moveq   #A_STAND,d0
        bra     da_fanim
.decide:
        bsr     da_away
        bcs     sl_walk_in
        bsr     da_hiryu_d
        cmp.w   #120*3/2,d0
        bcc     sl_walk_in
        cmp.w   #64,d1
        bcc     sl_walk_in
        cmp.w   #32,d1
        bcs     sl_fire_in
        bra     sl_lob_in

; airborne (PC Engine sub 2): 0.25 px/tick^2 down, at most 7 px/tick; lands to stand
sl_air_in:
        move.b  #2,O_SUB(a0)
        clr.l   O_VX(a0)
        clr.l   O_VY(a0)
        moveq   #A_STAND,d0
        bra     da_fanim
sl_air:
        bsr     da_snap
        bcs     sl_stand_in
        sub.l   #$1000,O_VY(a0)
        cmp.l   #-$38000,O_VY(a0)
        bge.s   .m
        move.l  #-$38000,O_VY(a0)
.m:     move.l  O_VY(a0),d0
        add.l   d0,O_Y(a0)
        rts

; walk (PC Engine sub 3, 0xAC1C): 64 ticks toward Hiryu (32 when facing away),
; turning at a wall or a drop; then stand on flat ground, or walk on
sl_walk_in:
        move.b  #4,O_SUB(a0)
        move.w  #2*64,O_T1(a0)
        bsr     da_away
        bcc.s   .t
        move.w  #2*32,O_T1(a0)
.t:     move.b  O_FACE(a0),O_WDIR(a0)
sl_walk:
        tst.w   O_T1(a0)
        bne.s   .go
        cmpi.b  #1,O_FLOOR(a0)          ; flat (the snap's floor kind 1): stand and look
        beq     sl_stand_in
        bra     sl_walk_in
.go:    subq.w  #1,O_T1(a0)
        bsr     sl_ahead                ; a wall or a drop ahead: turn
        bcs.s   .ok
        bchg    #0,O_WDIR(a0)
.ok:    moveq   #0,d0
        move.b  O_FLOOR(a0),d0
        and.w   #7,d0
        add.w   d0,d0
        add.w   d0,d0
        lea     da_walk_speed,a1
        move.l  0(a1,d0.w),d0
        btst    #0,O_WDIR(a0)
        beq.s   .r
        neg.l   d0
.r:     add.l   d0,O_X(a0)
        bsr     da_snap
        bcc     sl_air_in
        move.b  O_WDIR(a0),O_FACE(a0)
        moveq   #A_WALK,d0
        bra     da_fanim

; carry set when the floor continues 10 px ahead (PC Engine: a wall within 8 px
; or no floor 7 px ahead turns it); the object is left as it was
sl_ahead:
        move.l  O_X(a0),-(sp)
        move.l  O_Y(a0),-(sp)
        move.l  O_FLOOR(a0),-(sp)       ; $22-$25: the snap's bytes
        moveq   #10,d0
        btst    #0,O_WDIR(a0)
        beq.s   .r
        neg.w   d0
.r:     add.w   d0,O_X(a0)
        jsr     DA_SNAP
        scs     d1
        move.l  (sp)+,O_FLOOR(a0)
        move.l  (sp)+,O_Y(a0)
        move.l  (sp)+,O_X(a0)
        add.b   d1,d1
        rts

; fire (PC Engine sub 4): animation 2, a bullet 6 px/tick ahead, 16 ticks
sl_fire_in:
        move.b  #6,O_SUB(a0)
        move.w  #2*16,O_T1(a0)
        moveq   #A_FIRE,d0
        bsr     da_fanim
        moveq   #K_BULLET,d0
        bsr     sl_child
        bcs.s   sl_fire
        move.l  #$48000,d0
        btst    #0,O_FACE(a0)
        beq.s   .v
        neg.l   d0
.v:     move.l  d0,O_VX(a1)
sl_fire:
sl_lob:
        tst.w   O_T1(a0)
        beq     sl_stand_in
        subq.w  #1,O_T1(a0)
        rts

; lob (PC Engine sub 5): animation 3, a grenade 2 px/tick ahead, 4 px/tick up
sl_lob_in:
        move.b  #8,O_SUB(a0)
        move.w  #2*16,O_T1(a0)
        moveq   #A_LOB,d0
        bsr     da_fanim
        moveq   #K_GRENADE,d0
        bsr     sl_child
        bcs.s   sl_lob
        move.l  #$18000,d0
        btst    #0,O_FACE(a0)
        beq.s   .v
        neg.l   d0
.v:     move.l  d0,O_VX(a1)
        move.l  #$20000,O_VY(a1)
        bra.s   sl_lob

; a child of kind d0 at (+-51, +14) (PC Engine (+-34, -14)), facing as the
; soldier: A1, carry set when none
sl_child:
        move.b  O_FACE(a0),d1
        moveq   #-1,d2
        moveq   #51,d3
        btst    #0,d1
        beq.s   .x
        neg.w   d3
.x:     add.w   O_X(a0),d3
        move.w  O_Y(a0),d4
        add.w   #14,d4
        bsr     da_spawn
        bcs.s   .r
        addq.w  #1,DA_SHOTS
.r:     rts

; a slash: the stock soldier's death sound, knocked away from Hiryu for 4
; ticks, then the stock explosion and 100 points (PC Engine state 3)
sl_kill:
        move.b  #4,O_ST(a0)
        clr.b   O_COL(a0)
        move.w  #8,O_T1(a0)
        move.l  #$48000,d0              ; 6 px/tick
        move.w  O_X(a0),d1
        cmp.w   HIRYU+8(a5),d1
        bge.s   .r
        neg.l   d0
.r:     move.l  d0,O_VX(a0)
        clr.l   O_VY(a0)
        addq.w  #1,DA_KILLS
        jsr     DA_SND_DEATH            ; 0x4F
sl_die:
        move.l  O_VX(a0),d0
        add.l   d0,O_X(a0)
        subq.w  #1,O_T1(a0)
        bne     da_show
        bsr     da_explode
        move.w  #DA_SCORE,d0            ; the score command (BCD table 0x6932)
        jsr     DZ_QUEUE
        moveq   #2,d0
        bsr     da_once_set
        bra     da_free

; ------------------------------------------------------------- the bullet
; PC Engine actor 0x07 (0x72:0x9051): straight on; gone 16 px off screen
da_bullet:
        lea     .s(pc),a1
        bra     da_state
.s:     dc.w    .init-.s,.run-.s,da_free-.s,da_free-.s
.init:  moveq   #1,d0                   ; hurts Hiryu (colflags 0x80)
        bsr     da_init
        moveq   #0,d0
        bsr     da_anim0
.run:   bsr     da_move
        move.w  #-24,d2
        move.w  #384+24,d3
        moveq   #0,d4
        move.w  #280,d5
        move.w  O_Y(a0),d1
        bsr     da_window
        bcs     da_show
        bra     da_free

; ------------------------------------------------------------ the grenade
; PC Engine actor 0x68 parameter 0 (0x74:0xA9EF): 0.125 px/tick^2 down, at
; most 7 px/tick; a smoke puff every 3 ticks; bursts on the floor, on a slash
; or on hurting Hiryu (the stock explosion: harmless, as the PC Engine's debris)
da_grenade:
        lea     .s(pc),a1
        bra     da_state
.s:     dc.w    .init-.s,.run-.s,da_free-.s,da_free-.s
.init:  moveq   #7,d0                   ; hurts Hiryu, a slash bursts it (colflags 0xC0), so does the contact
        bsr     da_init
        clr.w   O_T1(a0)
        moveq   #0,d0
        bsr     da_fanim
.run:   tst.b   O_HITS(a0)
        bne.s   .burst
        bsr     da_snap
        bcs.s   .burst
        sub.l   #$800,O_VY(a0)
        cmp.l   #-$38000,O_VY(a0)
        bge.s   .m
        move.l  #-$38000,O_VY(a0)
.m:     bsr     da_move
        tst.w   O_T1(a0)
        beq.s   .smoke
        subq.w  #1,O_T1(a0)
        bra.s   .on
.smoke: move.w  #2*3-1,O_T1(a0)
        cmpi.w  #SMOKE_FREE,POOL5_FREE(a5)
        bcs.s   .on
        moveq   #K_SMOKE,d0
        moveq   #0,d1
        moveq   #-1,d2
        move.w  O_X(a0),d3
        move.w  O_Y(a0),d4
        bsr     da_spawn
.on:    move.w  #-384,d2
        move.w  #768,d3
        move.w  #-320,d4
        move.w  #560,d5
        move.w  O_Y(a0),d1
        bsr     da_window
        bcs     da_show
        bra     da_free
.burst: bsr     da_explode
        bra     da_free

; smoke (0x68 parameter 1): 12 ticks, no collision
da_smoke:
        lea     .s(pc),a1
        bra     da_state
.s:     dc.w    .init-.s,.run-.s,da_free-.s,da_free-.s
.init:  moveq   #0,d0
        bsr     da_init
        move.w  #2*13,O_T1(a0)
        moveq   #0,d0
        bsr     da_anim0
.run:   subq.w  #1,O_T1(a0)
        beq     da_free
        bra     da_show


; ------------------------------------------------------ the bazooka soldier
; PC Engine actor 0x41 (0x72:0xA677): kneels, facing Hiryu every tick; DA_BZ_AIM
; ticks after its start or its last shot it fires a rocket (0x42) as soon as it
; is on screen (0x58E2: within 64 px of the screen), then holds DA_BZ_FIRE ticks:
; one rocket per 64 ticks while on screen. One slash kills it.
da_bazooka:
        lea     .s(pc),a1
        bra     da_state
.s:     dc.w    bz_init-.s,bz_run-.s,bz_die-.s,da_free-.s

bz_init:
        moveq   #3,d0                   ; hurts Hiryu, a slash kills it (PC Engine colflags 0xC0)
        bsr     da_init
        addq.w  #1,DA_BZSPAWN
        bsr     bz_aim_in               ; sub 0 runs on into sub 1 in the same tick (0xA6C7)
        bra.s   bz_keep
bz_run:
        tst.b   O_HITS(a0)
        bne     bz_kill
        moveq   #0,d0
        move.b  O_SUB(a0),d0
        move.w  .t(pc,d0.w),d0
        jsr     .t(pc,d0.w)
        bra.s   bz_keep
.t:     dc.w    bz_aim-.t,bz_fire-.t
bz_keep:                                ; far from the camera: freed, its id spawnable again (as the
        move.w  #-640,d2                ; soldier; the PC Engine keeps it)
        move.w  #1024,d3
        move.w  #-320,d4
        move.w  #560,d5
        move.w  O_Y(a0),d1
        bsr     da_window
        bcs     da_show
        moveq   #0,d0
        bsr     da_once_set
        bra     da_free

; aim (PC Engine sub 0 and 1, 0xA6C7): animation 0, facing Hiryu; when the timer has run out,
; fire once on screen
bz_aim_in:
        clr.b   O_SUB(a0)
        move.w  #2*DA_BZ_AIM,O_T1(a0)
bz_aim:
        bsr     da_face
        moveq   #A_AIM,d0
        bsr     da_fanim
        tst.w   O_T1(a0)
        beq.s   .go
        subq.w  #1,O_T1(a0)
        rts
.go:    move.w  #DA_SCR_X0,d2
        move.w  #DA_SCR_X1,d3
        move.w  #DA_SCR_Y0,d4
        move.w  #DA_SCR_Y1,d5
        move.w  O_Y(a0),d1
        bsr     da_window
        bcs.s   bz_fire_in
        rts

; fire (PC Engine sub 2, 0xA6FB): animation 1 (the back blast, then the aim frame), a rocket at
; (+-DA_BZ_RDX, +DA_BZ_RDY), DA_BZ_FIRE ticks, then aim again
bz_fire_in:
        move.b  #2,O_SUB(a0)
        move.w  #2*DA_BZ_FIRE,O_T1(a0)
        moveq   #A_FIRE2,d0
        bsr     da_fanim
        bsr.s   bz_rocket
bz_fire:
        tst.w   O_T1(a0)
        beq.s   bz_aim_in
        subq.w  #1,O_T1(a0)
        rts

bz_rocket:
        moveq   #K_ROCKET,d0
        move.b  O_FACE(a0),d1           ; the rocket flies the way the soldier faces
        moveq   #-1,d2
        move.w  #DA_BZ_RDX,d3
        btst    #0,d1
        beq.s   .x
        neg.w   d3
.x:     add.w   O_X(a0),d3
        move.w  O_Y(a0),d4
        add.w   #DA_BZ_RDY,d4
        bsr     da_spawn
        bcs.s   .r
        addq.w  #1,DA_ROCKETS
        jsr     DA_SND_MISSILE          
.r:     rts

; a slash (PC Engine state 3, 0xA7DA): the stock soldier's death sound, knocked away from Hiryu
; at 6 px/tick for DA_BZ_KNOCK ticks, then the stock explosion and 200 points (DA_SCORE_BZ)
bz_kill:
        move.b  #4,O_ST(a0)
        clr.b   O_COL(a0)
        move.w  #2*DA_BZ_KNOCK,O_T1(a0)
        move.l  #$48000,d0
        move.w  O_X(a0),d1
        cmp.w   HIRYU+8(a5),d1
        bge.s   .r
        neg.l   d0
.r:     move.l  d0,O_VX(a0)
        clr.l   O_VY(a0)
        addq.w  #1,DA_BZKILL
        jsr     DA_SND_DEATH            ; 0x4F
bz_die:
        move.l  O_VX(a0),d0
        add.l   d0,O_X(a0)
        subq.w  #1,O_T1(a0)
        bne     da_show
        bsr     da_explode
        move.w  #DA_SCORE_BZ,d0         ; the score command (BCD table 0x6932)
        jsr     DZ_QUEUE
        moveq   #2,d0
        bsr     da_once_set
        bra     da_free

; ------------------------------------------------------------- the rocket
; PC Engine actor 0x42 (0x72:0xA84C): straight on at 8 px/tick (DA_RK_VX); gone
; 16 px past the screen edge it flies toward (checked before the move, as the
; PC Engine); a slash or hurting Hiryu bursts it (0xA90F takes any collision)
da_rocket:
        lea     .s(pc),a1
        bra     da_state
.s:     dc.w    .init-.s,.run-.s,da_free-.s,da_free-.s
.init:  moveq   #7,d0                   ; hurts Hiryu, a slash bursts it, so does the contact (colflags 0xC0)
        bsr     da_init
        move.l  #DA_RK_VX,d0
        btst    #0,O_FACE(a0)
        beq.s   .v
        neg.l   d0
.v:     move.l  d0,O_VX(a0)
        clr.l   O_VY(a0)
        moveq   #0,d0
        bsr     da_fanim
.run:   tst.b   O_HITS(a0)
        bne.s   .burst
        move.w  O_X(a0),d0
        sub.w   CAMX(a5),d0
        tst.l   O_VX(a0)
        bmi.s   .l
        cmp.w   #DA_RK_RIGHT,d0
        bge     da_free
        bra.s   .m
.l:     cmp.w   #DA_RK_LEFT,d0
        blt     da_free
.m:     bsr     da_move
        bra     da_show
.burst: bsr     da_explode              ; the stock explosion (harmless, as the PC Engine's debris)
        bra     da_free

; --------------------------------------------------------------- the mine
; PC Engine actor 0x43 (0x72:0xA9D2): buried and unseen (animation 0, an empty
; frame). When Hiryu stands over it (|Y - Hiryu Y - DA_MN_DY| < DA_MN_TOLY and
; |Hiryu X - (X + DA_MN_DX)| < DA_MN_TOLX, the X offset on its facing side) a
; DA_MN_WARN-tick warning bump, then a DA_MN_BLAST-tick blast: the only frames
; with a hitbox (64 x 64 PC Engine px); it hurts Hiryu and plays a stock
; explosion (for the PC Engine's PSG effect 0x14). Then it re-arms, and can go
; off again at once. It cannot be slashed. Drawn in front of Hiryu (list C, as
; the PC Engine's layer 0). Gone, its id spawnable again, 384 px right or 128 px
; left of the camera (PC Engine px; da_maplist spawns it only inside that window).
da_mine:
        lea     .s(pc),a1
        bra     da_state
.s:     dc.w    mn_init-.s,mn_run-.s,da_free-.s,da_free-.s
mn_init:
        moveq   #0,d0                   ; harmless until it blasts (PC Engine colflags 0x80: no hitbox before)
        bsr     da_init
        addq.w  #1,DA_MNSPAWN
        bsr     mn_arm_in               ; sub 0 runs on into sub 1 in the same tick (0xAA1C)
        bra.s   mn_keep
mn_run:
        moveq   #0,d0
        move.b  O_SUB(a0),d0
        move.w  .t(pc,d0.w),d0
        jsr     .t(pc,d0.w)
        bra.s   mn_keep
.t:     dc.w    mn_arm-.t,mn_warn-.t,mn_blast-.t
mn_keep:                                ; PC Engine 0xAA83
        move.w  O_X(a0),d0
        sub.w   CAMX(a5),d0
        cmp.w   #DA_MN_RIGHT,d0
        bge.s   .gone
        cmp.w   #DA_MN_LEFT,d0
        blt.s   .gone
        movea.l $1A(a0),a6              ; the frame, and list C (in front of Hiryu; sets $1)
        jsr     DA_ANIM_STEP
        jmp     DA_LISTC
.gone:  moveq   #0,d0
        bsr     da_once_set
        bra     da_free

; armed (PC Engine sub 0 and 1, 0xAA1C)
mn_arm_in:
        clr.b   O_SUB(a0)
        clr.b   O_COL(a0)
        moveq   #M_ARMED,d0
        bsr     da_fanim
mn_arm:
        move.w  O_Y(a0),d1              ; the PC Engine's |Hiryu Y - DA_MN_DY - Y| (0x5A88), Y up
        sub.w   HIRYU+$C(a5),d1
        sub.w   #DA_HIRYU_DY+DA_MN_DY,d1
        bpl.s   .y
        neg.w   d1
.y:     cmp.w   #DA_MN_TOLY,d1
        bcc.s   .r
        move.w  #DA_MN_DX,d0            ; |X +- DA_MN_DX - Hiryu X| (0x5AD3)
        btst    #0,O_FACE(a0)
        beq.s   .x
        neg.w   d0
.x:     add.w   O_X(a0),d0
        sub.w   HIRYU+8(a5),d0
        bpl.s   .a
        neg.w   d0
.a:     cmp.w   #DA_MN_TOLX,d0
        bcs.s   mn_warn_in
.r:     rts

; the warning (PC Engine sub 2, 0xAA40): the bump rises
mn_warn_in:
        move.b  #2,O_SUB(a0)
        move.w  #2*DA_MN_WARN,O_T1(a0)
        addq.w  #1,DA_MNWARN
        moveq   #M_WARN,d0
        bsr     da_fanim
mn_warn:
        tst.w   O_T1(a0)
        beq.s   mn_blast_in
        subq.w  #1,O_T1(a0)
        rts

; the blast (PC Engine sub 3, 0xAA5C)
mn_blast_in:
        move.b  #4,O_SUB(a0)
        move.w  #2*DA_MN_BLAST,O_T1(a0)
        move.b  #1,O_COL(a0)            ; hurts Hiryu (the blast frames carry the hitbox)
        addq.w  #1,DA_MNBLAST
        moveq   #M_BLAST,d0
        bsr     da_fanim
        jsr     DA_SND_BLAST            ; BOMB 3 (0x45), the commonest stock explosion
mn_blast:
        tst.w   O_T1(a0)
        beq     mn_arm_in
        subq.w  #1,O_T1(a0)
        rts

; ---------------------------------------------------------- the generator
; PC Engine object 0x0F (0x6C:0x8004): every 64 ticks it turns toward Hiryu
; and, when it is 32 to 256 px off either side of the screen (and up to 64
; px above or below it), spawns a soldier with the next of its six once ids
; (its parameter's list) unless that soldier is alive; then the next id. Not
; drawn. Its parameter (0 or 1) is the record's second byte (O_FACE).
da_gen:
        lea     .s(pc),a1
        bra     da_state
.s:     dc.w    .init-.s,.run-.s,da_free-.s,da_free-.s
.init:  moveq   #0,d0
        bsr     da_init
        clr.b   O_GI(a0)
        clr.b   O_GN(a0)
        bsr     gen_timer
        bra.s   .dec
.run:   tst.w   O_T1(a0)
        beq.s   .fire
.dec:   subq.w  #1,O_T1(a0)
        rts
.fire:  moveq   #0,d0
        move.b  O_FACE(a0),d0           ; the parameter: its id list
        and.w   #1,d0
        mulu    #6,d0
        moveq   #0,d1
        move.b  O_GI(a0),d1
        add.w   d1,d0
        lea     da_gen_ids,a1
        moveq   #0,d6
        move.b  0(a1,d0.w),d6           ; the once id
        move.w  #-384,d2                ; left of the screen by 32-256 PC Engine px
        move.w  #-48,d3
        move.w  #-48,d4
        move.w  #304,d5
        move.w  O_Y(a0),d1
        bsr     da_window
        bcs.s   .in
        move.w  #384+48,d2              ; or right of it
        move.w  #768,d3
        move.w  O_Y(a0),d1
        bsr     da_window
        bcc.s   .next
.in:    lea     DA_ONCE,a1
        cmpi.b  #1,0(a1,d6.w)           ; alive: not again
        beq.s   .next
        cmpi.w  #GEN_FREE,POOL5_FREE(a5)
        bcs.s   .next
        moveq   #K_SOLDIER,d0
        moveq   #0,d1                   ; facing Hiryu
        move.w  HIRYU+8(a5),d3
        cmp.w   O_X(a0),d3
        bge.s   .f
        moveq   #1,d1
.f:     move.w  d6,d2
        move.w  O_X(a0),d3
        move.w  O_Y(a0),d4
        move.w  d6,-(sp)
        bsr     da_spawn
        move.w  (sp)+,d6
        bcs.s   .next
        lea     DA_ONCE,a1
        move.b  #1,0(a1,d6.w)
.next:  addq.b  #1,O_GI(a0)
        cmpi.b  #6,O_GI(a0)
        bcs.s   .t
        clr.b   O_GI(a0)
.t:     bsr.s   gen_timer
        bra     .dec
gen_timer:                              ; the next spawn period (PC Engine 0x8054, 2 frames a tick)
        moveq   #0,d0
        move.b  O_GN(a0),d0
        and.w   #15,d0
        lea     da_gen_timers,a1
        move.b  0(a1,d0.w),d0
        move.w  d0,O_T1(a0)
        addq.b  #1,O_GN(a0)
        rts

; ------------------------------------------------------- the wave manager
; PC Engine object 0x13 (0x6C:0x81BD): runs its parameter's script (da_wave_scripts, from 0x6C:0x8326),
; op after op in one frame until a wait. 1 n waits n ticks; 2 waits for Hiryu's Y to cross the
; manager's (his side of it changes from the side he was on when the wait began; 0x57ED, 0x580F), 3 the
; same for X (0x5835, 0x5857); both are skipped while the manager stands at the PC Engine's (0, 0).
; 4 and 5 set its Y and X; 6 and 7 spawn a drone of kind k at the left or right screen edge,
; DA_WM_DY above the camera (0x83B6), without its item once the PC Engine's rank would take it
; (DA_RANK_FRAMES of play since the setup: 0x6C:0x8395). Not drawn; freed at its end (op 0).
da_wave:
        lea     .s(pc),a1
        bra     da_state
.s:     dc.w    wv_init-.s,wv_run-.s,da_free-.s,da_free-.s
wv_init:
        moveq   #0,d0
        bsr     da_init
        clr.w   O_WPC(a0)
        clr.b   O_WSET(a0)              ; placed at (0, 0)
        clr.b   O_SUB(a0)
wv_run:
        moveq   #0,d0
        move.b  O_SUB(a0),d0
        move.w  .t(pc,d0.w),d0
        jmp     .t(pc,d0.w)
.t:     dc.w    wv_next-.t,wv_wait_y-.t,wv_wait_x-.t,wv_wait_t-.t

wv_next:                                ; the next op: d0 = op word, d1 = its value
        moveq   #0,d0
        move.b  O_FACE(a0),d0           ; the parameter: its script
        add.w   d0,d0
        add.w   d0,d0
        lea     da_wave_scripts,a1
        movea.l 0(a1,d0.w),a1
        adda.w  O_WPC(a0),a1
        addq.w  #4,O_WPC(a0)
        move.w  (a1)+,d0
        move.w  (a1),d1
        moveq   #0,d2
        move.b  d0,d2
        cmp.w   #7,d2
        bhi     da_free
        add.w   d2,d2
        move.w  .o(pc,d2.w),d2
        jmp     .o(pc,d2.w)
.o:     dc.w    da_free-.o,wv_wait-.o,wv_y-.o,wv_x-.o,wv_sety-.o,wv_setx-.o,wv_left-.o,wv_right-.o

wv_wait:                                ; 1: n ticks (the value is in frames)
        move.w  d1,O_T1(a0)
        move.b  #6,O_SUB(a0)
wv_wait_t:
        tst.w   O_T1(a0)
        beq.s   wv_go
        subq.w  #1,O_T1(a0)
        rts
wv_go:  clr.b   O_SUB(a0)
        bra     wv_next

wv_y:                                   ; 2: Hiryu's Y crosses the manager's
        tst.b   O_WSET(a0)
        beq     wv_next
        bsr.s   wv_side_y
        move.b  d0,O_WDIR(a0)
        move.b  #2,O_SUB(a0)
wv_wait_y:
        bsr.s   wv_side_y
        cmp.b   O_WDIR(a0),d0
        bne.s   wv_go
        rts

wv_x:                                   ; 3: Hiryu's X crosses the manager's
        tst.b   O_WSET(a0)
        beq     wv_next
        bsr.s   wv_side_x
        move.b  d0,O_WDIR(a0)
        move.b  #4,O_SUB(a0)
wv_wait_x:
        bsr.s   wv_side_x
        cmp.b   O_WDIR(a0),d0
        bne.s   wv_go
        rts

wv_side_y:                              ; d0 = 1 when Hiryu is above the manager (the PC Engine's
        moveq   #0,d0                   ; Hiryu Y - its Y < 0, Y down)
        move.w  HIRYU+$C(a5),d1
        add.w   #DA_HIRYU_DY,d1
        cmp.w   O_Y(a0),d1
        ble.s   .r
        moveq   #1,d0
.r:     rts
wv_side_x:                              ; d0 = 1 when Hiryu is left of it
        moveq   #0,d0
        move.w  HIRYU+8(a5),d1
        cmp.w   O_X(a0),d1
        bge.s   .r
        moveq   #1,d0
.r:     rts

wv_sety:                                ; 4: its Y (converted; op bit 8: the PC Engine's is not 0)
        move.w  d1,O_Y(a0)
        bclr    #0,O_WSET(a0)
        btst    #8,d0
        beq     wv_next
        bset    #0,O_WSET(a0)
        bra     wv_next
wv_setx:                                ; 5: its X
        move.w  d1,O_X(a0)
        bclr    #1,O_WSET(a0)
        btst    #8,d0
        beq     wv_next
        bset    #1,O_WSET(a0)
        bra     wv_next

wv_left:                                ; 6: a drone at the left screen edge
        move.w  #DA_WM_LEFT,d3
        bra.s   wv_drone
wv_right:                               ; 7: at the right edge
        move.w  #DA_WM_RIGHT,d3
wv_drone:
        add.w   CAMX(a5),d3
        move.w  CAMY(a5),d4
        add.w   #DA_WM_DY,d4
        move.w  d1,d6                   ; its kind
        cmpi.w  #DA_RANK_FRAMES,DA_RANKT
        bcs.s   .k
        move.w  d6,d0
        and.w   #DA_RANK_MASK,d6        ; the rank takes its item
        cmp.w   d0,d6
        beq.s   .k
        addq.w  #1,DA_STRIP
.k:     moveq   #K_DRONE,d0
        move.w  d6,d1
        moveq   #-1,d2
        bsr     da_spawn
        bcs     wv_next                 ; pool 5 full: none (the PC Engine skips it too)
        addq.w  #1,DA_WVSPAWN
        bra     wv_next

; ------------------------------------------------------------ the drone
; PC Engine actor 0x0B (0x72:0x94D6). It thinks once a tick (on its first frame and every other one
; after) and moves every frame by half a tick's move. Sub-states (0x953C): 0 the spawn: it heads for
; Hiryu, then makes a fast entry (kind bit 2) or homes; 1 the fast entry (0x955D): a heading from the
; screen bands (da_dr_entry; none on screen: a glide) at 8 px/tick until Hiryu's X is within
; DA_DR_EXIT_DX; 2 homing (0x95FB): DA_DR_HOME_T ticks at 4 px/tick, turning at most DA_DR_TURN a tick
; toward Hiryu, or straight up within DA_DR_CLOSE_X x DA_DR_CLOSE_Y of him; 3 the glide (0x965C):
; DA_DR_GLIDE_T ticks at 2 px/tick on its heading, then homing inside the box around the screen
; (DA_DR_BOX_*), else a fast entry. One slash kills it: knocked away for DA_DR_DEATH_T ticks, its frame
; held, then the stock explosion (its own sound) and 300 points. A kind with an item (bits 4-7: the
; PC Engine item, da_item_kind) carries a stock capsule DA_DR_ITEM_DY below it (0x9906): the capsule
; drops when the drone dies, and an opened capsule kills the drone at once (0x9974). It is never
; freed for its distance from the camera (the PC Engine keeps it too).
da_drone:
        lea     .s(pc),a1
        bra     da_state
.s:     dc.w    dr_init-.s,dr_run-.s,dr_die-.s,da_free-.s

dr_init:
        moveq   #3,d0                   ; hurts Hiryu, a slash kills it (PC Engine colflags 0xC8)
        bsr     da_init
        addq.w  #1,DA_DRSPAWN
        clr.b   O_SUB(a0)
        clr.b   O_TICK(a0)
        clr.l   O_CAP(a0)
        clr.l   O_VX(a0)
        clr.l   O_VY(a0)
        moveq   #0,d0                   ; its item: a capsule hanging below it
        move.b  O_FACE(a0),d0
        lsr.b   #4,d0
        beq.s   dr_run
        lea     da_item_kind,a1
        move.b  0(a1,d0.w),d0
        bmi.s   dr_run
        moveq   #0,d3
        move.w  #DA_DR_ITEM_DY,d4
        movea.l a0,a3
        bsr     da_carried
        bcs.s   dr_run
        move.l  a1,O_CAP(a0)
dr_run:
        tst.b   O_HITS(a0)
        bne     dr_kill
        bsr     dr_cap_open
        bcs     dr_burst
        bchg    #0,O_TICK(a0)
        bne.s   .move                   ; between its ticks
        moveq   #0,d0
        move.b  O_SUB(a0),d0
        move.w  .t(pc,d0.w),d0
        jsr     .t(pc,d0.w)
        bsr     dr_velocity
.move:  bsr     da_move
    ifd PCE_SFX
        bra     dr_show
    else
        bra     da_show
    endc
.t:     dc.w    dr_spawn-.t,dr_entry-.t,dr_home-.t,dr_glide-.t

    ifd PCE_SFX

; ends in psg_sfx then loop, and the interpreter plays the effect on the tick the animation starts again (0x54C8).
; Here: the frame the stock step (0xBA6) goes from a later record back to the animation's first (its $11 runs out
; with $14, the next record, the first and $12, the shown one, another; a start has $12 = $14), da_dr_sfx's command
dr_show:
        cmpi.b  #1,$11(a0)
        bne.s   .show
        move.w  $14(a0),d0
        cmp.w   $12(a0),d0
        beq.s   .show
        moveq   #0,d1
        move.b  O_ANIM(a0),d1
        movea.l da_kind_anims+4*K_DRONE,a1
        add.w   d1,d1
        cmp.w   0(a1,d1.w),d0
        bne.s   .show
        lsr.w   #1,d1
        lea     da_dr_sfx,a1
        moveq   #0,d0                   ; the queue takes a word: the command alone
        move.b  0(a1,d1.w),d0
        beq.s   .show
        bsr     da_sound
.show:  bra     da_show
    endc

dr_spawn:                               ; sub 0 (0x9544): toward Hiryu, then the entry or homing
        bsr     dr_dir
        lsl.b   #4,d0
        move.b  d0,O_HEAD(a0)
        move.b  O_FACE(a0),d0
        andi.b  #DA_DR_ENTRY_BIT,d0
        beq     dr_home_in

dr_entry_in:                            ; sub 1 (0x955D)
        move.b  #2,O_SUB(a0)
        bsr     dr_band
        bmi     dr_glide_in             ; on screen: a glide
        lsl.b   #4,d0
        move.b  d0,O_HEAD(a0)
        move.b  #DA_DR_ENTRY,O_SPD(a0)
        moveq   #DA_DR_A_ENTRY,d0
        bsr     da_anim0
dr_entry:                               ; 0x9582: on until Hiryu's X is near
        move.w  HIRYU+8(a5),d0
        sub.w   O_X(a0),d0
        bpl.s   .x
        neg.w   d0
.x:     cmp.w   #DA_DR_EXIT_DX,d0
        bcs.s   dr_home_in
        rts

dr_home_in:                             ; sub 2 (0x95FB)
        move.b  #4,O_SUB(a0)
        move.w  #DA_DR_HOME_T,O_T1(a0)
        moveq   #DA_DR_A_HOME,d0
        bsr     da_anim0
dr_home:                                ; 0x960D
        tst.w   O_T1(a0)
        beq.s   dr_glide_in
        subq.w  #1,O_T1(a0)
        bsr     da_hiryu_d              ; near him (|dX| < DA_DR_CLOSE_X, |dY| < DA_DR_CLOSE_Y): straight up
        cmp.w   #DA_DR_CLOSE_X,d0
        bcc.s   .far
        cmp.w   #DA_DR_CLOSE_Y,d1
        bcc.s   .far
        moveq   #0,d0
        bra.s   .turn
.far:   bsr     dr_dir
        cmp.b   #$10,d0
        bcs.s   .t
        move.b  O_HEAD(a0),d0           ; no direction: the heading kept
        bra.s   .turn
.t:     lsl.b   #4,d0
.turn:  sub.b   O_HEAD(a0),d0           ; the turn, at most DA_DR_TURN either way
        bmi.s   .neg
        cmp.b   #DA_DR_TURN,d0
        blt.s   .add
        moveq   #DA_DR_TURN,d0
        bra.s   .add
.neg:   cmp.b   #-DA_DR_TURN,d0
        bge.s   .add
        moveq   #-DA_DR_TURN,d0
.add:   add.b   d0,O_HEAD(a0)
        move.b  #DA_DR_HOME,O_SPD(a0)
        rts

dr_glide_in:                            ; sub 3 (0x965C)
        move.b  #6,O_SUB(a0)
        move.b  #DA_DR_GLIDE,O_SPD(a0)
        moveq   #DA_DR_A_GLIDE,d0
        bsr     da_anim0
        move.w  #DA_DR_GLIDE_T,O_T1(a0)
dr_glide:                               ; 0x9674
        tst.w   O_T1(a0)
        beq.s   .end
        subq.w  #1,O_T1(a0)
        rts
.end:   move.w  #DA_DR_BOX_X0,d2        ; inside the box around the screen: homing; else an entry (0x96B5)
        move.w  #DA_DR_BOX_X1,d3
        move.w  #DA_DR_BOX_Y0,d4
        move.w  #DA_DR_BOX_Y1,d5
        move.w  O_Y(a0),d1
        bsr     da_window
        bcs     dr_home_in
        bra     dr_entry_in

; d0 = the entry sector by the screen bands (0x958D: above, below, left of and right of the screen's
; middle), negative: none (a glide)
dr_band:
        moveq   #0,d1
        move.w  O_Y(a0),d0
        sub.w   CAMY(a5),d0
        cmp.w   #DA_DR_ABOVE,d0
        ble.s   .b
        bset    #0,d1
.b:     cmp.w   #DA_DR_BELOW,d0
        bgt.s   .l
        bset    #1,d1
.l:     move.w  O_X(a0),d0
        sub.w   CAMX(a5),d0
        cmp.w   #DA_DR_LEFT,d0
        bge.s   .r
        bset    #2,d1
.r:     cmp.w   #DA_DR_RIGHT,d0
        blt.s   .t
        bset    #3,d1
.t:     lea     da_dr_entry,a1
        moveq   #0,d0
        move.b  0(a1,d1.w),d0
        ext.w   d0
        rts

; d0 = the direction to Hiryu (0x587D, 0x4E35): 0-15 (0 up, clockwise), $10 when he is on it. dX and
; dY in PC Engine px (X / 1.5, Y down), each clamped to +-127, halved together until both are in
; -4..3, then da_atan[(dX & 7) * 8 + (dY & 7)]
dr_dir:
        move.w  HIRYU+8(a5),d1
        sub.w   O_X(a0),d1
        ext.l   d1
        add.l   d1,d1
        divs    #3,d1
        move.w  O_Y(a0),d2
        sub.w   HIRYU+$C(a5),d2
        sub.w   #DA_HIRYU_DY,d2
dr_dir_d:                               ; (d1 = dX, d2 = dY in PC Engine px: the tank's turret, tu_dir)
        moveq   #127,d3
        moveq   #-127,d4
        cmp.w   d3,d1
        ble.s   .x0
        move.w  d3,d1
.x0:    cmp.w   d4,d1
        bge.s   .y
        move.w  d4,d1
.y:     cmp.w   d3,d2
        ble.s   .y0
        move.w  d3,d2
.y0:    cmp.w   d4,d2
        bge.s   .h
        move.w  d4,d2
.h:     cmp.w   #3,d1
        bgt.s   .half
        cmp.w   #-4,d1
        blt.s   .half
        cmp.w   #3,d2
        bgt.s   .half
        cmp.w   #-4,d2
        bge.s   .look
.half:  asr.w   #1,d1
        asr.w   #1,d2
        bra.s   .h
.look:  and.w   #7,d1
        lsl.w   #3,d1
        and.w   #7,d2
        or.w    d2,d1
        lea     da_atan,a1
        moveq   #0,d0
        move.b  0(a1,d1.w),d0
        rts

dr_velocity:                            ; the heading's velocity at its speed (0x96F3): da_dr_vel
        moveq   #0,d0
        move.b  O_SPD(a0),d0
        lsl.w   #7,d0                   ; 16 sectors x 8 bytes
        moveq   #0,d1
        move.b  O_HEAD(a0),d1
        lsr.b   #4,d1
        lsl.w   #3,d1
        add.w   d1,d0
        lea     da_dr_vel,a1
        move.l  0(a1,d0.w),O_VX(a0)
        move.l  4(a1,d0.w),O_VY(a0)
        rts

; carry set when the drone's capsule has been opened (0x9974: its container's state 3), clearing the
; link when the capsule is gone (no longer pool 7 type 0x1A carried by this drone)
dr_cap_open:
        move.l  O_CAP(a0),d0
        beq.s   .no
        movea.l d0,a1
        tst.b   (a1)
        beq.s   .gone
        cmpi.b  #$1A,$17(a1)
        bne.s   .gone
        cmp.l   $38(a1),a0
        bne.s   .gone
        cmpi.b  #2,3(a1)                ; revealing or showing its item
        beq.s   .yes
        cmpi.b  #4,3(a1)
        bne.s   .no
.yes:   ori     #1,ccr
        rts
.gone:  clr.l   O_CAP(a0)
.no:    andi    #$FE,ccr
        rts

dr_kill:                                ; a slash (0x97DF): knocked away from Hiryu at 6 px/tick
        move.b  #4,O_ST(a0)
        clr.b   O_COL(a0)
        move.w  #2*DA_DR_DEATH_T,O_T1(a0)
        move.l  #$48000,d0
        move.w  O_X(a0),d1
        cmp.w   HIRYU+8(a5),d1
        bge.s   .r
        neg.l   d0
.r:     move.l  d0,O_VX(a0)
        clr.l   O_VY(a0)
        addq.w  #1,DA_DRKILL
        bra.s   dr_die
dr_burst:                               ; its capsule opened (0x998C): the explosion on its next tick
        move.b  #4,O_ST(a0)
        clr.b   O_COL(a0)
        move.w  #1,O_T1(a0)
        addq.w  #1,DA_DRKILL
dr_die:                                 ; PC Engine state 3 (0x98E5): moving, its frame held
        tst.w   O_T1(a0)
        beq.s   .boom
        subq.w  #1,O_T1(a0)
        bsr     da_move
        movea.l $1A(a0),a6
        jmp     DA_LISTA
.boom:  bsr     da_explode
        move.w  #DA_SCORE_DR,d0         ; the score command (BCD table 0x6932)
        jsr     DZ_QUEUE
        bra     da_free

; ---------------------------------------------------------- the sandworm
; PC Engine actor 0x40 (0x72:0xA3D1): each arch of a worm is one. A head (the map list's) lies hidden, not
; drawn, until it is within 64 px of the screen (0x58E2, step 2's window), then surfaces; an arch the worm
; made (O_FACE bit 7) surfaces at once (0xA418). Surfaced, it plays its animation for 2 x DA_SW_SURFACE + 2
; frames and goes (0xA458). 2 x DA_SW_PERIOD frames after surfacing it makes the next arch DA_SW_DX px
; ahead, at its Y (0xA495), unless it is off screen DA_SW_STOP px or more past the screen's centre ahead,
; or the floor ends (its arches left, this one included, in O_FACE bits 1-6: desert_actors_ex.worm_chains,
; from the PC Engine's floor probes). DA_SW_HITS slashes kill an arch: its frame held 2 x DA_SW_DEATH_T
; frames (no knockback), then the stock explosion and 400 points (0xA5FC); the arch that made it dies too
; on the frame it sees it dying (0xA4E8), and so back to the head. Nothing frees it for its distance.
da_worm:
        lea     .s(pc),a1
        bra     da_state
.s:     dc.w    sw_init-.s,sw_run-.s,sw_die-.s,da_free-.s

sw_init:
        moveq   #3,d0                   ; hurts Hiryu, a slash hurts it (PC Engine colflags 0xC0)
        bsr     da_init
        clr.b   O_SUB(a0)
        clr.b   O_SWC(a0)
        clr.l   O_KID(a0)
        tst.b   O_FACE(a0)              ; bit 7: an arch the worm made surfaces at once
        bpl.s   sw_run
        bsr     sw_surface
sw_run:
        cmpi.b  #DA_SW_HITS,O_HITS(a0)
        bcc.s   sw_kill
        bsr     sw_kid_dying            ; the arch it made is dying: so does it
        bcs.s   sw_kill
        tst.b   O_SUB(a0)
        bne.s   .up
        move.w  #DA_SCR_X0,d2           ; hidden until within 64 px of the screen
        move.w  #DA_SCR_X1,d3
        move.w  #DA_SCR_Y0,d4
        move.w  #DA_SCR_Y1,d5
        move.w  O_Y(a0),d1
        bsr     da_window
        bcs.s   .rise
        rts                             ; not drawn, not in any list
.rise:  bsr     sw_surface
.up:    tst.w   O_T1(a0)                ; surfaced: gone when its time is up
        beq.s   sw_gone
        subq.w  #1,O_T1(a0)
        tst.b   O_SWC(a0)
        bne.s   .show
        tst.w   O_T2(a0)
        beq.s   .next
        subq.w  #1,O_T2(a0)
        bra.s   .show
.next:  st      O_SWC(a0)
        bsr     sw_next
.show:  bra     da_show

sw_kill:                                ; DA_SW_HITS slashes, or the arch it made dying
        move.b  #4,O_ST(a0)
        clr.b   O_COL(a0)
        move.w  #2*DA_SW_DEATH_T,O_T1(a0)
        addq.w  #1,DA_SWKILL
sw_die:                                 ; PC Engine state 3 (0xA5FC): its frame held, no knockback
        tst.w   O_T1(a0)
        beq.s   .boom
        subq.w  #1,O_T1(a0)
        movea.l $1A(a0),a6
        jmp     DA_LISTA
.boom:  bsr     da_explode              ; the stock explosion (its own sound)
        move.w  #DA_SCORE_SW,d0         ; 400 points (the score command; BCD table 0x6932 entry 12)
        jsr     DZ_QUEUE
sw_gone:                                ; a head's once id is spent: it never comes back (0x5789)
        moveq   #2,d0
        bsr     da_once_set
        bra     da_free

sw_surface:                             ; 0xA42D: shown, its animation from the start
        move.b  #2,O_SUB(a0)
        move.w  #2*DA_SW_SURFACE+2,O_T1(a0)
        move.w  #2*DA_SW_PERIOD,O_T2(a0)
        addq.w  #1,DA_SWUP
        moveq   #0,d0
        bra     da_fanim

; the next arch (0xA49F, 0xA509): DA_SW_DX px ahead at the same Y, its arches one fewer, surfacing at once
sw_next:
        moveq   #0,d0
        move.b  O_FACE(a0),d0
        lsr.b   #1,d0
        and.b   #$3F,d0                 ; arches left, this one included
        cmp.b   #1,d0
        bhi.s   .scr
        addq.w  #1,DA_SWEND             ; the floor ends here
        rts
.scr:   move.w  #DA_SCR_X0,d2           ; off screen DA_SW_STOP px or more past the screen's centre
        move.w  #DA_SCR_X1,d3           ; ahead: none
        move.w  #DA_SCR_Y0,d4
        move.w  #DA_SCR_Y1,d5
        move.w  O_Y(a0),d1
        move.w  d0,d6                   ; (da_window keeps d6)
        bsr     da_window
        bcs.s   .go
        move.w  O_X(a0),d1
        sub.w   CAMX(a5),d1
        sub.w   #DA_SW_CX,d1
        btst    #0,O_FACE(a0)
        beq.s   .d
        neg.w   d1
.d:     cmp.w   #DA_SW_STOP,d1
        blt.s   .go
        addq.w  #1,DA_SWSTOP
        rts
.go:    move.w  d6,d0
        subq.b  #1,d0                   ; the child's facing byte: made (bit 7), arches left, facing
        add.b   d0,d0
        move.b  O_FACE(a0),d1
        and.b   #1,d1
        or.b    d0,d1
        or.b    #$80,d1
        moveq   #-1,d2
        move.w  #DA_SW_DX,d3
        btst    #0,O_FACE(a0)
        beq.s   .x
        neg.w   d3
.x:     add.w   O_X(a0),d3
        move.w  O_Y(a0),d4
        moveq   #K_WORM,d0
        bsr     da_spawn
        bcs.s   .r                      ; pool 5 full: none (the PC Engine skips it too)
        move.l  a1,O_KID(a0)
        move.l  a0,O_PAR(a1)
        addq.w  #1,DA_SWARCH
.r:     rts

; carry set when the arch this one made is dying (0xA4E8; its link cleared once it is gone)
sw_kid_dying:
        move.l  O_KID(a0),d0
        beq.s   .no
        movea.l d0,a1
        tst.b   (a1)
        beq.s   .gone
        cmpi.b  #3,$17(a1)
        bne.s   .gone
        cmpi.b  #K_WORM,O_KIND(a1)
        bne.s   .gone
        cmp.l   O_PAR(a1),a0
        bne.s   .gone
        cmpi.b  #4,O_ST(a1)
        bne.s   .no
        ori     #1,ccr
        rts
.gone:  clr.l   O_KID(a0)
.no:    andi    #$FE,ccr
        rts

; ------------------------------------------------------------- the robot
; PC Engine actor 0x19 (0x72:0x99B2), the pipe walker. It thinks once a tick (on its first update frame and
; every other one after) in the PC Engine's own terms: its position (O_PX, O_PY: 8.8, Y down), timers in ticks,
; and the PC Engine's floor and wall tests on that area's own collision data (rb_floor, rb_wall_*: the arcade
; streams its collision map only near the screen, and the robots walk off it). It moves every frame by half the
; tick's move (X 1.5x, Y up). Its AI (0x9A02): 0 rest; 1 wait DA_RB_WAIT0 ticks, then aim when it is on screen
; (step 2's window) and level with Hiryu (|dY| < DA_RB_FIRE_DY), else walk toward him; 2 walk DA_RB_WALK ticks at
; 1 px/tick along the floor (the velocity by the floor's class flags, 0x9EC5, then the snap, 0x9D12), turning at
; a wall or a drop (0x9B08); then aim the same way, or wait DA_RB_WAIT1 ticks; 3 aim: the dome turns a phase every
; DA_RB_SPIN_T + 1 ticks until it faces Hiryu's side, then a beam; 4 hold DA_RB_HOLD ticks, then rest. Its two
; legs (kind 13) are actors it makes at its start: it places and draws them, their frames by the floor under each
; and their stride (0x9C04; the build refuses a robot facing left: desert_actors_ex.robot_area). Any hit counts
; (a slash, or Hiryu's contact: the PC Engine counts any collision, 0xA038); DA_RB_HITS kill it: knocked away
; from Hiryu for DA_RB_KNOCK ticks, its frame and its legs' held, then the stock explosion (its own sound) and
; 300 points; its legs go with it. It is never freed for its distance (the PC Engine keeps it too). Its walk and
; fire sounds (PSG 0x1B, 0x16) play as OKI samples with PCE_SFX (pce_sfx.py: rb_step_sfx, rb_fire).
da_robot:
        lea     .s(pc),a1
        bra     da_state
.s:     dc.w    rb_init-.s,rb_run-.s,rb_die-.s,da_free-.s

rb_init:
        moveq   #7,d0                   ; hurts Hiryu, a slash hurts it, so does the contact (PC Engine colflags 0xC0)
        bsr     da_init
        addq.w  #1,DA_RBSPAWN
        clr.b   O_TICK(a0)
        clr.l   O_LEGA(a0)
        clr.l   O_LEGB(a0)
        moveq   #0,d0                   ; its PC Engine position (its X is 1.5x an even one: robot_area)
        move.w  O_X(a0),d0
        add.l   d0,d0
        divu    #3,d0
        swap    d0
        clr.w   d0
        swap    d0
        lsl.l   #8,d0
        move.l  d0,O_PX(a0)
        move.w  #2047,d0
        sub.w   O_Y(a0),d0
        ext.l   d0
        lsl.l   #8,d0
        move.l  d0,O_PY(a0)
        bsr     rb_legs_make
    ifd PCE_SFX
        clr.b   O_RSTEP(a0)
    endc
rb_run:
        cmpi.b  #DA_RB_HITS,O_HITS(a0)
        bcc     rb_kill
        bchg    #0,O_TICK(a0)
        bne.s   .move                   ; between its ticks
        bsr     rb_tick
.move:  bsr     da_move
rb_show:                                ; the body, then its legs in list A: registered after it, they are drawn in
        bsr     da_show                 ; front of it (the PC Engine draws them after the body, 0x9C04)
        moveq   #0,d5
rb_legs_show:                           ; d5 = 0: their animations step, else held
        move.l  O_LEGA(a0),d0
        beq.s   .b
        movea.l d0,a3
        moveq   #DA_LG_AX,d6
        bsr.s   rb_leg_show
.b:     move.l  O_LEGB(a0),d0
        beq.s   .r
        movea.l d0,a3
        moveq   #DA_LG_AXL,d6
        bra.s   rb_leg_show
.r:     rts

; a3 = a leg, d6 = its X offset (arcade px): it follows the body, DA_LG_AY px below it
rb_leg_show:
        move.w  d6,d0
        swap    d0
        clr.w   d0
        add.l   O_X(a0),d0
        move.l  d0,O_X(a3)
        move.l  O_Y(a0),d0
        sub.l   #DA_LG_AY<<16,d0
        move.l  d0,O_Y(a3)
        exg     a0,a3
        movea.l $1A(a0),a6
        tst.b   d5
        bne.s   .h
        jsr     DA_ANIM_STEP
.h:     jsr     DA_LISTA
        exg     a0,a3
        rts

; one PC Engine tick (0x99DE): the AI, the dome, the velocity, the move and the snap, the legs' frames
rb_tick:
        moveq   #0,d0
        move.b  O_SUB(a0),d0
        move.w  .t(pc,d0.w),d0
        jsr     .t(pc,d0.w)
    ifd PCE_SFX
        bsr     rb_step_sfx
    endc
        bsr     rb_dome
        bsr     rb_motion
        bra     rb_legs
.t:     dc.w    rb_rest-.t,rb_wait-.t,rb_walk-.t,rb_aim-.t,rb_hold-.t

    ifd PCE_SFX
; the walk's sound (0x9BAB, after the AI): while it walks (sub 2), every DA_RB_STEP_T + 1 ticks, PSG 0x1B as
; DA_SND_RB_WALK through the near test; its counter (O_RSTEP, the PC Engine's +0x1C) starts at 0 (the PC Engine
; leaves the slot's old byte there), so the first walking tick plays
rb_step_sfx:
        cmpi.b  #4,O_SUB(a0)
        bne.s   .r
        tst.b   O_RSTEP(a0)
        beq.s   .play
        subq.b  #1,O_RSTEP(a0)
.r:     rts
.play:  move.b  #DA_RB_STEP_T,O_RSTEP(a0)
        moveq   #0,d2
        move.b  #DA_SND_RB_WALK,d2
        bra     da_sound_near
    endc

rb_rest:                                ; sub 0 (0x9A15): wait, the dome turning
        move.b  #2,O_SUB(a0)
        move.w  #DA_RB_WAIT0,O_T1(a0)
        move.b  #1,O_RSPIN(a0)
        clr.b   O_RWALK(a0)
        rts
rb_wait:                                ; sub 1 (0x9A2E)
        tst.w   O_T1(a0)
        beq.s   .end
        subq.w  #1,O_T1(a0)
        rts
.end:   bsr     rb_level                ; aim when on screen and level with Hiryu (0x9A38), else walk toward him
        bcs.s   rb_aim_in
        bsr     rb_toward
        move.b  #4,O_SUB(a0)
        move.b  #1,O_RSPIN(a0)
        move.b  #1,O_RWALK(a0)
        move.w  #DA_RB_WALK,O_T1(a0)
        rts
rb_aim_in:                              ; the dome turns to Hiryu's side (phase DA_RB_AIM_R or DA_RB_AIM_L)
        bsr     rb_toward
        move.b  #6,O_SUB(a0)
        move.b  O_RDIR(a0),d0
        addq.b  #2,d0
        move.b  d0,O_RSPIN(a0)
        clr.b   O_RWALK(a0)
        rts

rb_walk:                                ; sub 2 (0x9AA7)
        tst.w   O_T1(a0)
        bne.s   .go
        clr.b   O_RSPD(a0)              ; the walk ends: aim, or wait
        bsr     rb_level
        bcs.s   rb_aim_in
        move.w  #DA_RB_WAIT1,O_T1(a0)
        move.b  #1,O_RSPIN(a0)
        clr.b   O_RWALK(a0)
        move.b  #2,O_SUB(a0)
        rts
.go:    subq.w  #1,O_T1(a0)
        bsr     rb_turn                 ; a wall or a drop ahead: turn (0x9B0B)
        move.b  #DA_RB_SPEED,O_RSPD(a0)
        tst.b   O_RDIR(a0)
        beq.s   .r
        move.b  #-DA_RB_SPEED,O_RSPD(a0)
.r:     rts

rb_aim:                                 ; sub 3 (0x9B66): the dome on Hiryu's side, a beam, then hold
        tst.b   O_RSPIN(a0)
        bne.s   .r
        move.w  #DA_RB_HOLD,O_T1(a0)
        clr.b   O_RWALK(a0)
        move.b  #8,O_SUB(a0)
        bra     rb_fire
.r:     rts

rb_hold:                                ; sub 4 (0x9B88), then rest
        tst.w   O_T1(a0)
        beq.s   .end
        subq.w  #1,O_T1(a0)
        rts
.end:   move.w  #DA_RB_REST,O_T1(a0)
        move.b  #1,O_RSPIN(a0)
        clr.b   O_RWALK(a0)
        clr.b   O_SUB(a0)
        rts

; carry set when the robot is on screen (0x58E2: step 2's window) and level with Hiryu (0x57A5)
rb_level:
        move.w  #DA_SCR_X0,d2
        move.w  #DA_SCR_X1,d3
        move.w  #DA_SCR_Y0,d4
        move.w  #DA_SCR_Y1,d5
        move.w  O_Y(a0),d1
        bsr     da_window
        bcc.s   .r
        bsr     da_hiryu_d
        cmp.w   #DA_RB_FIRE_DY,d1       ; (carry set when below)
.r:     rts

rb_toward:                              ; toward Hiryu (0x5857): right (0) when his X is not less than its X
        clr.b   O_RDIR(a0)
        move.w  HIRYU+8(a5),d0
        cmp.w   O_X(a0),d0
        bge.s   .r
        move.b  #1,O_RDIR(a0)
.r:     rts

rb_turn:                                ; 0x9B08: a wall within DA_RB_WALL_WANT px ahead, or no floor ahead within
        bsr     rb_pos                  ; DA_RB_DROP_WANT px: turn
        move.b  #DA_RB_WALL_MASK,d2
        tst.b   O_RDIR(a0)
        bne.s   .left
        bsr     rb_wall_right
        cmp.w   #DA_RB_WALL_WANT,d0
        bcs.s   .turn
        bsr     rb_pos
        add.w   #DA_RB_DROP_R,d0
        bra.s   .drop
.left:  bsr     rb_wall_left
        cmp.w   #DA_RB_WALL_WANT,d0
        bcs.s   .turn
        bsr     rb_pos
        add.w   #DA_RB_DROP_L,d0
.drop:  add.w   #DA_RB_DROP_DY,d1
        move.b  #DA_RB_MASK,d2
        bsr     rb_floor
        cmp.w   #DA_RB_DROP_WANT,d0
        bcc.s   .turn
        rts
.turn:  bchg    #0,O_RDIR(a0)
        addq.w  #1,DA_RBTURN
        rts

rb_pos:                                 ; d0 = its PC Engine X, d1 = Y
        move.l  O_PX(a0),d0
        asr.l   #8,d0
        move.l  O_PY(a0),d1
        asr.l   #8,d1
        rts

rb_dome:                                ; the dome (0x9CAC): its frame by its phase, which steps every DA_RB_SPIN_T + 1
        moveq   #0,d0                   ; ticks while it turns, and stops at the aimed phase
        move.b  O_RPH(a0),d0
        lea     da_rb_dome,a1
        move.b  0(a1,d0.w),d0
        bsr     da_anim0
        tst.b   O_RCT(a0)
        beq.s   .step
        subq.b  #1,O_RCT(a0)
        rts
.step:  move.b  #DA_RB_SPIN_T,O_RCT(a0)
        move.b  O_RSPIN(a0),d0
        beq.s   .r
        addq.b  #1,O_RPH(a0)
        andi.b  #7,O_RPH(a0)
        subq.b  #2,d0
        bcs.s   .r                      ; 1: turning
        moveq   #DA_RB_AIM_R,d1         ; 2: aiming right, 3: left
        tst.b   d0
        beq.s   .a
        moveq   #DA_RB_AIM_L,d1
.a:     cmp.b   O_RPH(a0),d1
        bne.s   .r
        clr.b   O_RSPIN(a0)
.r:     rts

; the velocity by the floor's class flags under it (0x9EC5: da_rb_v, negated walking left; none standing), the
; move (0x5634/0x5641) and the snap (0x9D12: Y += the floor's distance - DA_RB_REST_DY, at most DA_RB_REST_DY either
; way); the tick's move goes to O_VX and O_VY, half of it a frame (X 1.5x, Y up)
rb_motion:
        bsr     rb_pos
        add.w   #DA_RB_SNAP_DY,d1
        move.b  #DA_RB_MASK,d2
        bsr     rb_floor
        moveq   #0,d4                   ; vX
        moveq   #0,d5                   ; vY
        move.b  O_RSPD(a0),d0
        beq.s   .move
        and.w   #7,d1
        add.w   d1,d1
        add.w   d1,d1
        lea     da_rb_v,a1
        move.w  0(a1,d1.w),d4
        move.w  2(a1,d1.w),d5
        ext.l   d4
        ext.l   d5
        tst.b   d0
        bpl.s   .move
        neg.l   d4
        neg.l   d5
.move:  add.l   d4,O_PX(a0)
        add.l   d5,O_PY(a0)
        bsr     rb_pos                  ; (rb_floor keeps d2-d7)
        add.w   #DA_RB_SNAP_DY,d1
        bsr     rb_floor
        subq.w  #DA_RB_REST_DY,d0
        cmp.w   #-DA_RB_REST_DY,d0
        bge.s   .lo
        moveq   #-DA_RB_REST_DY,d0
.lo:    cmp.w   #DA_RB_REST_DY,d0
        ble.s   .hi
        moveq   #DA_RB_REST_DY,d0
.hi:    ext.l   d0
        asl.l   #8,d0
        add.l   d0,O_PY(a0)
        add.l   d0,d5
        muls    #192,d4                 ; 8.8 per tick -> 16.16 per frame: X 1.5 / 2, Y -1 / 2
        move.l  d4,O_VX(a0)
        asl.l   #7,d5
        neg.l   d5
        move.l  d5,O_VY(a0)
        rts

; the legs (0x9D2D, 0x9DF9): each 3 px in front of or behind the body and DA_LG_DY below it, its frame by the
; slope under it (the floor's class flags & 7: DA_LG_PROBE1 above the leg within DA_LG_WANT px, else DA_LG_PROBE2
; below; 0x9D50) and its step in the stride, which moves on every tick while the robot walks and finishes when it
; stops (0x9DB2): leg A shows its phases 0-3, leg B its 4-7 (else their step 0)
rb_legs:
        move.l  O_LEGA(a0),d0
        beq.s   .b
        movea.l d0,a3
        moveq   #DA_LG_DX,d6
        moveq   #0,d3
        lea     da_rb_lega,a4
        bsr.s   rb_leg
.b:     move.l  O_LEGB(a0),d0
        beq.s   .r
        movea.l d0,a3
        moveq   #-DA_LG_DX,d6
        moveq   #4,d3
        lea     da_rb_legb,a4
        bra.s   rb_leg
.r:     rts

; a3 = a leg, d6 = its X offset (PC Engine px), d3 = its phases' bit 2, a4 = its table
rb_leg:
        bsr     rb_pos
        add.w   d6,d0
        add.w   #DA_LG_DY,d1
        move.w  d0,d5
        move.w  d1,d6
        add.w   #DA_LG_PROBE1,d1
        move.b  #DA_RB_MASK,d2
        bsr     rb_floor
        cmp.w   #DA_LG_WANT,d0
        bcs.s   .d
        move.w  d5,d0
        move.w  d6,d1
        add.w   #DA_LG_PROBE2,d1
        bsr     rb_floor
.d:     and.w   #7,d1                   ; slope * 4 + its step
        lsl.w   #2,d1
        moveq   #0,d0
        move.b  O_LPH(a3),d0
        move.b  d0,d2
        and.b   #4,d2
        cmp.b   d3,d2
        beq.s   .p
        moveq   #0,d0
.p:     and.w   #3,d0
        add.w   d0,d1
        moveq   #0,d0
        move.b  0(a4,d1.w),d0
        exg     a0,a3
        bsr     da_anim0
        exg     a0,a3
        move.b  O_LPH(a3),d0
        tst.b   O_RWALK(a0)
        bne.s   .s
        tst.b   d0
        beq.s   .r
.s:     addq.b  #1,d0
        and.b   #7,d0
        move.b  d0,O_LPH(a3)
.r:     rts

rb_legs_make:                           ; its two legs (0x9BCD): leg B only with leg A
        bsr.s   rb_leg_make
        bcs.s   .r
        move.l  a1,O_LEGA(a0)
        bsr.s   rb_leg_make
        bcs.s   .r
        move.l  a1,O_LEGB(a0)
.r:     rts
rb_leg_make:                            ; a leg, set up at once (it runs only when the robot has placed it): A1, carry
        moveq   #K_LEG,d0               ; set when pool 5 is full
        move.b  O_FACE(a0),d1
        moveq   #-1,d2
        move.w  O_X(a0),d3
        move.w  O_Y(a0),d4
        bsr     da_spawn
        bcs.s   .r
        move.l  a0,O_BODY(a1)
        addq.w  #1,DA_LGMADE
        exg     a0,a1
        moveq   #0,d0                   ; no collision (a PC Engine part)
        bsr     da_init
        exg     a0,a1
        andi    #$FE,ccr
.r:     rts

rb_legs_free:                           ; its legs go with it (0x9C39)
        move.l  O_LEGA(a0),d0
        beq.s   .b
        movea.l d0,a1
        moveq   #K_LEG,d0
        bsr     da_free_part
.b:     move.l  O_LEGB(a0),d0
        beq.s   .r
        movea.l d0,a1
        moveq   #K_LEG,d0
        bra     da_free_part
.r:     rts

rb_fire:                                ; a beam (0x9FC2) DA_BM_SPAWN_DX px toward Hiryu's side and DA_BM_SPAWN_DY above
        moveq   #K_BEAM,d0              ; it, heading that way; none when pool 5 is full (the PC Engine skips it too)
        move.b  O_RDIR(a0),d1
        moveq   #-1,d2
        move.w  #DA_BM_SPAWN_DX,d3
        btst    #0,d1
        beq.s   .x
        neg.w   d3
.x:     add.w   O_X(a0),d3
        move.w  O_Y(a0),d4
        add.w   #DA_BM_SPAWN_DY,d4
        bsr     da_spawn
        bcs.s   .r
        addq.w  #1,DA_BMFIRE
    ifd PCE_SFX
        moveq   #0,d2                   ; its sound (0xA030, once the beam is made): PSG 0x16 through the near test
        move.b  #DA_SND_RB_FIRE,d2
        bra     da_sound_near
    endc
.r:     rts

rb_kill:                                ; DA_RB_HITS hits (0xA04D): knocked away from Hiryu at 6 px/tick
        move.b  #4,O_ST(a0)
        clr.b   O_COL(a0)
        move.w  #2*DA_RB_KNOCK,O_T1(a0)
        move.l  #$48000,d0
        move.w  O_X(a0),d1
        cmp.w   HIRYU+8(a5),d1
        bge.s   .r
        neg.l   d0
.r:     move.l  d0,O_VX(a0)
        clr.l   O_VY(a0)
        addq.w  #1,DA_RBKILL
rb_die:                                 ; PC Engine state 3 (0xA0F9): moving, its frame and its legs' held
        tst.w   O_T1(a0)
        beq.s   .boom
        subq.w  #1,O_T1(a0)
        bsr     da_move
        movea.l $1A(a0),a6
        jsr     DA_LISTA
        moveq   #1,d5
        bra     rb_legs_show
.boom:  bsr     da_explode              ; the stock explosion (its own sound)
        move.w  #DA_SCORE_RB,d0         ; 300 points (the score command; BCD table 0x6932)
        jsr     DZ_QUEUE
        moveq   #2,d0
        bsr     da_once_set
        bsr     rb_legs_free
        bra     da_free

; The PC Engine's collision tests on the robots' area (desert_actors_ex.robot_area: its metatiles' classes in
; da_rb_map, outside them class 0; each test's table gives a class's shape and flags; desert_ex.PceCollision has
; the same in Python). In: d0 = X, d1 = Y (PC Engine px), d2.b = the mask. Out: d0 = the distance (0-32), d1 =
; the class flags of the last metatile read. They keep d2-d7, a0 and a3-a6.
rb_floor:                               ; down (0x5765 -> 0x6191): the column's top in the metatile
        movem.l d2-d7/a1-a2,-(sp)
        lea     da_rb_floor,a2
        move.w  d0,d5
        and.w   #15,d5                  ; the shape's byte: the column
        move.w  d1,d6
        and.w   #15,d6                  ; t: the row
        bsr     rb_class
        bsr     rb_part
        bcs     rb_test_r
        move.w  d4,-(sp)                ; none: 16 - t and the metatile below, from its top
        add.w   #16,d1
        bra.s   rb_test2
rb_wall_right:                          ; to the right (0x5777 -> 0x6271): the row's left end
        movem.l d2-d7/a1-a2,-(sp)
        lea     da_rb_wallr,a2
        move.w  d1,d5
        and.w   #15,d5
        move.w  d0,d6
        and.w   #15,d6
        bsr     rb_class
        bsr     rb_part
        bcs     rb_test_r
        move.w  d4,-(sp)
        add.w   #16,d0
        bra.s   rb_test2
rb_wall_left:                           ; to the left (0x5780 -> 0x62DC): t = 16 - (X & 15), or the metatile to the
        movem.l d2-d7/a1-a2,-(sp)       ; left from its edge
        lea     da_rb_walll,a2
        move.w  d1,d5
        and.w   #15,d5
        move.w  d0,d6
        and.w   #15,d6
        bne.s   .t
        sub.w   #16,d0
        bra.s   .c
.t:     neg.w   d6
        add.w   #16,d6
.c:     bsr     rb_class
        bsr     rb_part
        bcs     rb_test_r
        move.w  d4,-(sp)
        sub.w   #16,d0
rb_test2:
        moveq   #0,d6
        bsr     rb_class
        bsr     rb_part
        add.w   (sp)+,d4
rb_test_r:
        move.w  d4,d0
        moveq   #0,d1
        move.b  d3,d1
        movem.l (sp)+,d2-d7/a1-a2
        rts

rb_class:                               ; d3 = the class of the metatile at (d0, d1) (0x6377; bits 0-6)
        move.w  d1,d3
        asr.w   #4,d3
        sub.w   #DA_RB_ROW0,d3
        bmi.s   .out
        cmp.w   #DA_RB_ROWS,d3
        bcc.s   .out
        mulu    #DA_RB_COLS,d3
        move.w  d0,d4
        asr.w   #4,d4
        sub.w   #DA_RB_COL0,d4
        bmi.s   .out
        cmp.w   #DA_RB_COLS,d4
        bcc.s   .out
        add.w   d4,d3
        lea     da_rb_map,a1
        move.b  0(a1,d3.w),d3
        and.w   #$7F,d3
        rts
.out:   moveq   #0,d3
        rts

; one metatile (0x6351): d3 = its class, a2 = the test's table, d5 = the shape's byte, d6 = t, d2 = the mask ->
; d4 = the distance in it, d3 = its flags, carry set when it holds the surface
rb_part:
        add.w   d3,d3
        moveq   #0,d4
        move.b  0(a2,d3.w),d4           ; its shape
        move.b  1(a2,d3.w),d3           ; its flags
        move.b  d3,d7
        and.b   d2,d7
        beq.s   .none
        lsl.w   #4,d4
        add.w   d5,d4
        lea     da_rb_shapes,a1
        moveq   #0,d7
        move.b  0(a1,d4.w),d7           ; $80 and up: none
        bmi.s   .none
        move.w  d7,d4
        sub.w   d6,d4
        bcs.s   .none                   ; above t: none in this metatile
        ori     #1,ccr
        rts
.none:  moveq   #16,d4
        sub.w   d6,d4
        andi    #$FE,ccr
        rts

; ---------------------------------------------------------------- the legs
; A robot's leg (kind 13; the PC Engine's part 0x19, never dispatched there): its robot places it, sets its frame
; and draws it (rb_legs, rb_leg_show). No collision. Gone with its robot.
da_leg:
        lea     .s(pc),a1
        bra     da_state
.s:     dc.w    da_free-.s,lg_run-.s,da_free-.s,da_free-.s
lg_run:
        move.l  O_BODY(a0),d0
        moveq   #K_ROBOT,d1
        bsr     da_linked
        bcc     da_free
        rts

; ---------------------------------------------------------------- the beam
; PC Engine actor 0x1A (0x72:0xA166), a robot's beam: its head (kind 14, no collision), heading the robot's way.
; Once a tick (its first update frame and every other one after) it lives DA_BM_LIFE ticks, then goes once off
; screen (step 2's window), a tick later (0xA18D); every DA_BM_PERIOD + 1 ticks, from its first, it jumps
; DA_BM_DX px (0xA1BE). Its second jump makes its segment (kind 15, DA_BM_PIECES pieces in all), which takes the
; head's place at each jump after (0xA23B): it trails the head by one jump. Only the segment hurts Hiryu (its
; colflags 0x80); neither can be slashed. Both drawn in list C, in front of Hiryu (the PC Engine's layer 0), the
; segment in front of the head (drawn after it, as the PC Engine's ring).
da_beam:
        lea     .s(pc),a1
        bra     da_state
.s:     dc.w    bm_init-.s,bm_run-.s,da_free-.s,da_free-.s

bm_init:
        moveq   #0,d0
        bsr     da_init
        clr.b   O_TICK(a0)
        clr.b   O_SUB(a0)
        clr.b   O_BN(a0)
        clr.w   O_T2(a0)
        clr.l   O_SEG(a0)
        moveq   #0,d0                   ; its frame, flipped heading left (0xA35D)
        bsr     da_fanim
bm_run:
        bchg    #0,O_TICK(a0)
        bne.s   bm_show                 ; between its ticks
        cmpi.b  #4,O_SUB(a0)            ; off screen past its life since the last tick: gone (0xA1D8)
        beq.s   bm_free
        tst.b   O_SUB(a0)
        bne.s   .life
        move.b  #2,O_SUB(a0)            ; its first tick (0xA19A)
        move.w  #DA_BM_LIFE,O_T1(a0)
        bra.s   .step
.life:  tst.w   O_T1(a0)
        beq.s   .end
        subq.w  #1,O_T1(a0)
        bra.s   .step
.end:   move.w  #DA_SCR_X0,d2
        move.w  #DA_SCR_X1,d3
        move.w  #DA_SCR_Y0,d4
        move.w  #DA_SCR_Y1,d5
        move.w  O_Y(a0),d1
        bsr     da_window
        bcs.s   .step
        move.b  #4,O_SUB(a0)
.step:  bsr.s   bm_step
bm_show:
        bsr.s   bm_showc
        move.l  O_SEG(a0),d0            ; then its segment
        beq.s   .r
        movea.l d0,a3
        exg     a0,a3
        bsr.s   bm_showc
        exg     a0,a3
.r:     rts
bm_showc:                               ; the frame and list C
        movea.l $1A(a0),a6
        jsr     DA_ANIM_STEP
        jmp     DA_LISTC

bm_free:                                ; its segment goes with it (0xA2B1)
        move.l  O_SEG(a0),d0
        beq.s   .f
        movea.l d0,a1
        moveq   #K_SEG,d0
        bsr     da_free_part
.f:     bra     da_free

bm_step:                                ; 0xA1BE
        tst.w   O_T2(a0)
        beq.s   .go
        subq.w  #1,O_T2(a0)
        rts
.go:    move.w  #DA_BM_PERIOD,O_T2(a0)
        move.b  O_BN(a0),d0             ; its pieces (0xA1DE): the first jump counts the head, the next makes the
        bne.s   .seg                    ; segment (tried again at the next jump while pool 5 is full)
        move.b  #1,O_BN(a0)
        bra.s   .move
.seg:   cmp.b   #DA_BM_PIECES,d0
        bcc.s   .move
        bsr.s   bm_seg_make
        bcs.s   .move
        addq.b  #1,O_BN(a0)
.move:  move.l  O_SEG(a0),d0            ; the segment takes the head's place, the head jumps (0xA32D)
        beq.s   .h
        movea.l d0,a1
        move.l  O_X(a0),O_X(a1)
        move.l  O_Y(a0),O_Y(a1)
.h:     move.l  #DA_BM_DX<<16,d0
        btst    #0,O_FACE(a0)
        beq.s   .r
        neg.l   d0
.r:     add.l   d0,O_X(a0)
        rts

bm_seg_make:                            ; its segment, set up at once: carry set when pool 5 is full
        moveq   #K_SEG,d0
        move.b  O_FACE(a0),d1
        moveq   #-1,d2
        move.w  O_X(a0),d3
        move.w  O_Y(a0),d4
        bsr     da_spawn
        bcs.s   .r
        move.l  a1,O_SEG(a0)
        move.l  a0,O_BODY(a1)
        addq.w  #1,DA_BMSEG
        exg     a0,a1
        moveq   #1,d0                   ; it hurts Hiryu (the part's colflags 0x80)
        bsr     da_init
        moveq   #0,d0
        bsr     da_fanim
        exg     a0,a1
        andi    #$FE,ccr
.r:     rts

; the beam's segment (kind 15): its head places and draws it; gone with its head
da_seg:
        lea     .s(pc),a1
        bra     da_state
.s:     dc.w    da_free-.s,sg_run-.s,da_free-.s,da_free-.s
sg_run:
        move.l  O_BODY(a0),d0
        moveq   #K_BEAM,d1
        bsr     da_linked
        bcc     da_free
        rts

; carry set when d0 still holds a0's robot or beam: an active desert actor of kind d1 that links back to a0 (a
; robot's O_LEGA or O_LEGB, a beam's O_SEG = O_LEGA); a1 = it
da_linked:
        tst.l   d0
        beq.s   .no
        movea.l d0,a1
        tst.b   (a1)
        beq.s   .no
        cmpi.b  #3,$17(a1)
        bne.s   .no
        cmp.b   O_KIND(a1),d1
        bne.s   .no
        cmp.l   O_LEGA(a1),a0
        beq.s   .yes
        cmp.l   O_LEGB(a1),a0
        bne.s   .no
.yes:   ori     #1,ccr
        rts
.no:    andi    #$FE,ccr
        rts

; free a1 when it is still a0's part: an active desert actor of kind d0 whose O_BODY is a0 (the stock free
; clears d0-d6 and a1-a4)
da_free_part:
        tst.b   (a1)
        beq.s   .r
        cmpi.b  #3,$17(a1)
        bne.s   .r
        cmp.b   O_KIND(a1),d0
        bne.s   .r
        cmp.l   O_BODY(a1),a0
        bne.s   .r
        move.l  a0,-(sp)
        movea.l a1,a0
        jsr     DA_FREE5
        movea.l (sp)+,a0
.r:     rts

; --------------------------------------------------------------- the flame
; PC Engine actor 0x76 (0x74:0xAE42), a valve flame: it never moves. Once a tick (its first update frame and every
; other one after), every DA_FL_PERIOD ticks from its first, it requests its burst (animation DA_FL_ANIM, 0xAE99),
; which starts only when the last one has gone on to animation 0 (the interpreter 0x68:0x53CA restarts only a
; different animation): one burst every 2 x DA_FL_PERIOD ticks. It hurts Hiryu only while its frame has a hitbox
; (only frame 1); it cannot be slashed. Drawn in list C, in front of Hiryu (the PC Engine's layer 0).
da_flame:
        lea     .s(pc),a1
        bra     da_state
.s:     dc.w    fl_init-.s,fl_run-.s,da_free-.s,da_free-.s
fl_init:
        moveq   #0,d0
        bsr     da_init
        addq.w  #1,DA_FLSPAWN
        clr.b   O_TICK(a0)
        clr.w   O_T1(a0)                ; its first tick requests the burst
fl_run:
        bchg    #0,O_TICK(a0)
        bne.s   .show                   ; between its ticks
        tst.w   O_T1(a0)
        bne.s   .dec
        move.w  #DA_FL_PERIOD,O_T1(a0)
        cmpi.b  #$FF,O_ANIM(a0)         ; the first, or the last burst over (its animation 0's record shown)
        beq.s   .go
        cmpi.w  #DA_FL_OUT,$12(a0)
        bne.s   .dec
.go:    st      O_ANIM(a0)
        moveq   #DA_FL_ANIM,d0
        bsr     da_anim0
        addq.w  #1,DA_FLBURST
.dec:   subq.w  #1,O_T1(a0)
.show:  movea.l $1A(a0),a6
        jsr     DA_ANIM_STEP
        clr.b   O_COL(a0)               ; it hurts Hiryu while its frame has a hitbox
        move.b  O_FLG(a0),d0
        and.b   #$3F,d0
        cmp.b   #DA_NOBOX,d0
        beq.s   .c
        move.b  #1,O_COL(a0)
.c:     jmp     DA_LISTC

; ---------------------------------------------------------------- the jeep
; PC Engine actor 0x48 (0x74:0x8A05), the camouflaged jeep: section 3's script places it (spawn list 2) and waits
; for it (dz_sections op 10). It thinks once a tick (on its first update frame and every other one after) in the PC
; Engine's own terms: its position (O_PX, O_PY: 8.8, Y down), its X velocity (O_JVX, 8.8 px/tick), timers in ticks;
; it moves every frame by half the tick's move (X 1.5x, Y up), so after each tick its arcade position is exactly
; 1.5x the PC Engine's. Its AI (0x8A5A): 0 its home Y; 1 wait DA_JP_WAIT ticks, then, level with Hiryu (|dY| <
; DA_JP_DY), charge when he is DA_JP_AHEAD px or more ahead, else reverse; 2 charge (DA_JP_ACC a tick up to DA_JP_CMAX,
; DA_JP_CHARGE_T ticks at least), then brake once he is nearer; 3 brake (DA_JP_BRAKE a tick to 0, then wait; after
; DA_JP_BRAKE_T ticks a turn if he is behind); 4 reverse (DA_JP_RACC a tick backward up to DA_JP_RMAX, DA_JP_REVERSE_T
; ticks, then a turn if he is behind, else wait); 6 bounce: in 2-4 a wall test ahead (by the velocity's sign, 0x8D66:
; jp_wall, on the PC Engine's own walls of its map, desert_actors_ex.jeep_walls) stops it: still DA_JP_BOUNCE_T ticks,
; its Y shaking the first DA_JP_BOUNCE_N, then its home Y and wait; 7 turn: it faces about and coasts DA_JP_TURN_T
; ticks at its velocity with no wall test (the PC Engine's quirk: a turn can carry it into the cliff), then wait. Sub-
; state 5 (0x8C37) is never set (its entry, 0x8C2B, is dead code). Its PC Engine animations step as the interpreter
; does (0x68:0x53B4, jp_anim: an animation asked for again goes on unless a wait restarts it); its frame is a held
; record per frame and displayed flip. Any hit counts (a slash, or Hiryu's contact: 0x8DAD reads $32D0); DA_JP_HITS
; start the death drive (0x8EB0) on its next tick: no collision, DA_JP_DEATH_V forward for at most DA_JP_DEATH_T ticks
; or to a wall, a stock explosion every BOOM_EVERY ticks at the PC Engine's debris (da_jp_debris; while pool 6 has
; BOOM_FREE free), then two more, 500 points and its once status DA_JP_DONE (section 3 goes on); the next tick it shows
; the wreck, which stays (no collision) until it is off screen once section 3 is over. Drawn in list C, in front of Hiryu (the PC Engine's layer 0). Its gunner
; (kind 18) is a part it makes at its start, steps on each of its ticks, places and draws. No sound: the PC Engine
; plays none for either (its debris only, PSG).
da_jeep:
        lea     .s(pc),a1
        bra     da_state
.s:     dc.w    jp_init-.s,jp_run-.s,jp_die-.s,da_free-.s

jp_init:
        moveq   #7,d0                   ; hurts Hiryu, a slash hurts it, so does the contact (PC Engine colflags 0xC0)
        bsr     da_init
        addq.w  #1,DA_JPSPAWN
        clr.b   O_TICK(a0)
        clr.b   O_SUB(a0)
        clr.w   O_JVX(a0)
        clr.b   O_JBC(a0)
        clr.b   O_JFL(a0)
        clr.b   O_JFR(a0)
        st      O_JCUR(a0)
        clr.l   O_GUN(a0)
        moveq   #0,d0                   ; its PC Engine position (its X is 1.5x an even one: spawn_data)
        move.w  O_X(a0),d0
        add.l   d0,d0
        divu    #3,d0
        swap    d0
        clr.w   d0
        swap    d0
        lsl.l   #8,d0
        move.l  d0,O_PX(a0)
        move.w  #2047,d0
        sub.w   O_Y(a0),d0
        ext.l   d0
        lsl.l   #8,d0
        move.l  d0,O_PY(a0)
        bsr     jp_gun_make
jp_run:
        bchg    #0,O_TICK(a0)
        bne.s   jp_frame                ; between its ticks
        cmpi.b  #DA_JP_HITS,O_HITS(a0)  ; the hits counted since its last tick (0x8DBD)
        bcc.s   jp_kill
        movem.l O_PX(a0),d0-d1          ; one PC Engine tick (0x8A39): the AI, the move, the animation, the gunner
        movem.l d0-d1,-(sp)
        bsr     jp_ai
        move.w  O_JVX(a0),d0            ; the move (0x5634/0x5641; Y moves only in a bounce)
        ext.l   d0
        add.l   d0,O_PX(a0)
jp_tick:                                ; the old PC Engine position on the stack: the tick's move, half of it a frame
        bsr     jp_anim
        bsr     jp_gun_tick
        movem.l (sp)+,d0-d1
        move.l  O_PX(a0),d2
        sub.l   d0,d2
        muls    #192,d2                 ; 8.8 per tick -> 16.16 per frame: X 1.5 / 2, Y -1 / 2
        move.l  d2,O_VX(a0)
        move.l  O_PY(a0),d2
        sub.l   d1,d2
        asl.l   #7,d2
        neg.l   d2
        move.l  d2,O_VY(a0)
jp_frame:
        bsr     da_move
        bsr     jp_gun_place
        bra     jp_show

jp_kill:                                ; DA_JP_HITS hits: the death drive (0x8EBF), its first tick now
        move.b  #4,O_ST(a0)
        clr.b   O_SUB(a0)
        clr.b   O_COL(a0)
        addq.w  #1,DA_JPKILL
        move.b  #DA_JP_DEATH_ANIM,O_JAN(a0)
        move.w  #DA_JP_DEATH_T,O_T1(a0)
        move.w  #DA_JP_DEATH_V,d0
        btst    #0,O_FACE(a0)
        beq.s   .v
        neg.w   d0
.v:     move.w  d0,O_JVX(a0)
        bra.s   jp_dtick
jp_die:                                 ; PC Engine states 3 (the death drive, O_SUB 0) and 4 (the wreck, 2 and 4)
        cmpi.b  #4,O_SUB(a0)            ; the wreck off screen once section 3 is over: gone
        bne.s   .t
        cmpi.w  #3,DZ_SEC
        beq.s   .t
        move.w  #DA_JP_KEEP_X0,d2
        move.w  #DA_JP_KEEP_X1,d3
        move.w  #-320,d4
        move.w  #560,d5
        move.w  O_Y(a0),d1
        bsr     da_window
        bcc     da_free
.t:     bchg    #0,O_TICK(a0)
        bne.s   jp_frame
jp_dtick:
        movem.l O_PX(a0),d0-d1
        movem.l d0-d1,-(sp)
        moveq   #0,d0
        move.b  O_SUB(a0),d0
        move.w  .t(pc,d0.w),d0
        jsr     .t(pc,d0.w)
        bra     jp_tick
.t:     dc.w    jp_drive-.t,jp_wreck_in-.t,jp_wreck-.t

jp_drive:                               ; 0x8F00: to the end of its time or a wall
        tst.w   O_T1(a0)
        beq.s   jp_end
        subq.w  #1,O_T1(a0)
        bsr     jp_wall
        bcs.s   jp_end
        moveq   #BOOM_EVERY-1,d0        ; a small burst every BOOM_EVERY ticks (the PC Engine's debris comes every
        and.b   O_JBC(a0),d0            ; second tick; its counter is the bounce's, never reset)
        bne.s   .n
        cmpi.w  #BOOM_FREE,POOL6_FREE(a5)
        bcs.s   .n
        moveq   #0,d0
        move.b  O_JBC(a0),d0
        lsr.b   #1,d0
        and.w   #15,d0
        bsr     jp_boom
.n:     addq.b  #1,O_JBC(a0)
        move.w  O_JVX(a0),d0
        ext.l   d0
        add.l   d0,O_PX(a0)
        rts
jp_end:                                 ; 0x8F32: two big bursts, 500 points, the once status section 3 waits for
        moveq   #DA_JP_END1,d0
        bsr     jp_boom
        moveq   #DA_JP_END2,d0
        bsr     jp_boom
        move.w  #DA_SCORE_JP,d0         ; the score command (BCD table 0x6932)
        jsr     DZ_QUEUE
        moveq   #DA_JP_DONE,d0
        bsr     da_once_set
        addq.w  #1,DA_JPEND
        move.b  #2,O_SUB(a0)
        rts
jp_wreck_in:                            ; PC Engine state 4 (0x8F6D): the wreck's frame, for good
        move.b  #DA_JP_WRECK_ANIM,O_JAN(a0)
        move.b  #4,O_SUB(a0)
jp_wreck:
        rts

jp_boom:                                ; the stock explosion at the death drive's debris d0 (0x8DD5; X by its facing)
        add.w   d0,d0
        add.w   d0,d0
        lea     da_jp_debris,a1
        move.w  0(a1,d0.w),d3
        move.w  2(a1,d0.w),d4
        btst    #0,O_FACE(a0)
        beq.s   da_explode_d
        neg.w   d3
da_explode_d:                           ; the stock explosion at the object + (d3, d4)
        jsr     DA_ALLOC6
        bcs.s   .r
        move.w  #$0100,(a1)
        move.b  #1,$17(a1)
        add.w   O_X(a0),d3
        move.w  d3,8(a1)
        add.w   O_Y(a0),d4
        move.w  d4,$C(a1)
        clr.b   $3E(a1)
        addq.w  #1,DA_JPBOOM
.r:     rts

jp_ai:                                  ; its sub-states (0x8A5A)
        moveq   #0,d0
        move.b  O_SUB(a0),d0
        move.w  .t(pc,d0.w),d0
        jmp     .t(pc,d0.w)
.t:     dc.w    jp_home-.t,jp_wait-.t,jp_charge-.t,jp_brake-.t,jp_rev-.t,jp_wait-.t,jp_bounce-.t,jp_turn-.t

jp_home:                                ; sub 0 (0x8A6A): its home Y, then wait
        move.l  O_PY(a0),d0
        asr.l   #8,d0
        move.w  d0,O_JHY(a0)
jp_wait_in:                             ; sub 1 (0x8A7A): still, animation DA_JP_WAIT_ANIM from its start
        move.b  #2,O_SUB(a0)
        move.w  #DA_JP_WAIT,O_T1(a0)
        move.b  #DA_JP_WAIT_ANIM,O_JAN(a0)
        st      O_JCUR(a0)
        clr.w   O_JVX(a0)
jp_wait:                                ; 0x8AA0
        tst.w   O_T1(a0)
        beq.s   .go
        subq.w  #1,O_T1(a0)
        rts
.go:    bsr     jp_level
        bcc.s   .r
        moveq   #0,d2                   ; (the carry 0x8D18 adds: clear here)
        bsr     jp_ahead
        bcs     jp_rev_in
        bra.s   jp_charge_in
.r:     rts

jp_charge_in:                           ; sub 2 (0x8ABD)
        move.b  #4,O_SUB(a0)
        move.w  #DA_JP_CHARGE_T,O_T1(a0)
jp_charge:                              ; 0x8AC9
        bsr     jp_wall
        bcs     jp_bounce_in
        move.w  O_JVX(a0),d0
        moveq   #0,d2                   ; the clamp's carry, which 0x8D18 adds: facing right, set at the top speed;
        btst    #0,O_FACE(a0)           ; facing left, set below it
        bne.s   .l
        add.w   #DA_JP_ACC,d0
        cmp.w   #DA_JP_CMAX,d0
        blt.s   .t
        move.w  #DA_JP_CMAX,d0
        moveq   #1,d2
        bra.s   .t
.l:     sub.w   #DA_JP_ACC,d0
        cmp.w   #-DA_JP_CMAX,d0
        blt.s   .c
        moveq   #1,d2
        bra.s   .t
.c:     move.w  #-DA_JP_CMAX,d0
.t:     move.w  d0,O_JVX(a0)
        tst.w   O_T1(a0)
        beq.s   .end
        subq.w  #1,O_T1(a0)
        rts
.end:   bsr     jp_ahead                ; Hiryu nearer than DA_JP_AHEAD ahead: brake
        bcs.s   jp_brake_in
        rts

jp_brake_in:                            ; sub 3 (0x8B3D)
        move.b  #6,O_SUB(a0)
        move.w  #DA_JP_BRAKE_T,O_T1(a0)
jp_brake:                               ; 0x8B49
        bsr     jp_wall
        bcs     jp_bounce_in
        move.w  O_JVX(a0),d0
        btst    #0,O_FACE(a0)
        bne.s   .l
        sub.w   #DA_JP_BRAKE,d0         ; facing right: stopped below 0 (0x8B69; so it stands a tick at 0 first)
        bpl.s   .t
        bra     jp_wait_in
.l:     add.w   #DA_JP_BRAKE,d0         ; facing left: stopped at 0 (0x8B86)
        bpl     jp_wait_in
.t:     move.w  d0,O_JVX(a0)
        tst.w   O_T1(a0)
        beq.s   .end
        subq.w  #1,O_T1(a0)
        rts
.end:   bsr     jp_away                 ; Hiryu behind it: a turn
        bcs     jp_turn_in
        rts

jp_rev_in:                              ; sub 4 (0x8BA6)
        move.b  #8,O_SUB(a0)
        move.w  #DA_JP_REVERSE_T,O_T1(a0)
jp_rev:                                 ; 0x8BB2
        bsr     jp_wall
        bcs.s   jp_bounce_in
        move.w  O_JVX(a0),d0
        btst    #0,O_FACE(a0)
        beq.s   .r
        add.w   #DA_JP_RACC,d0          ; facing left: backward is to the right
        cmp.w   #DA_JP_RMAX,d0
        blt.s   .t
        move.w  #DA_JP_RMAX,d0
        bra.s   .t
.r:     sub.w   #DA_JP_RACC,d0
        cmp.w   #-DA_JP_RMAX,d0
        bge.s   .t
        move.w  #-DA_JP_RMAX,d0
.t:     move.w  d0,O_JVX(a0)
        tst.w   O_T1(a0)
        beq.s   .end
        subq.w  #1,O_T1(a0)
        rts
.end:   bsr     jp_away                 ; Hiryu behind it: a turn, else wait
        bcs.s   jp_turn_in
        bra     jp_wait_in

jp_bounce_in:                           ; sub 6 (0x8C94): a wall ahead
        move.b  #12,O_SUB(a0)
        move.w  #DA_JP_BOUNCE_T,O_T1(a0)
        move.b  #DA_JP_BOUNCE_ANIM,O_JAN(a0)
        clr.b   O_JBC(a0)
        clr.w   O_JVX(a0)
        addq.w  #1,DA_JPBOUNCE
jp_bounce:                              ; 0x8CBA: still, its Y shaking (0x56DA), then its home Y and wait
        tst.w   O_T1(a0)
        beq.s   .end
        subq.w  #1,O_T1(a0)
        moveq   #0,d0
        move.b  O_JBC(a0),d0
        cmp.b   #DA_JP_BOUNCE_N,d0
        bcc.s   .r
        addq.b  #1,O_JBC(a0)
        lea     da_jp_shake,a1
        move.b  0(a1,d0.w),d0
        ext.w   d0
        ext.l   d0
        asl.l   #8,d0
        add.l   d0,O_PY(a0)
.r:     rts
.end:   move.w  O_JHY(a0),d0
        ext.l   d0
        asl.l   #8,d0
        move.l  d0,O_PY(a0)
        bra     jp_wait_in

jp_turn_in:                             ; sub 7 (0x8CF1): it faces about, its velocity kept, no wall test
        move.b  #14,O_SUB(a0)
        move.w  #DA_JP_TURN_T,O_T1(a0)
        move.b  #DA_JP_TURN_ANIM,O_JAN(a0)
        bchg    #0,O_FACE(a0)
        addq.w  #1,DA_JPTURN
jp_turn:                                ; 0x8D0B
        tst.w   O_T1(a0)
        beq     jp_wait_in
        subq.w  #1,O_T1(a0)
        rts

; carry set when its wall test fires (0x8D66: the right test with its velocity 0 or more, else the left one; the
; PC Engine X runs where each fires, da_jp_wallr and da_jp_walll: desert_actors_ex.jeep_walls)
jp_wall:
        lea     da_jp_wallr,a1
        tst.w   O_JVX(a0)
        bpl.s   .t
        lea     da_jp_walll,a1
.t:     move.l  O_PX(a0),d0
        asr.l   #8,d0
        move.w  (a1)+,d1
        bra.s   .n
.l:     cmp.w   (a1)+,d0
        blt.s   .s
        cmp.w   (a1)+,d0
        bgt.s   .n
        ori     #1,ccr
        rts
.s:     addq.l  #2,a1
.n:     dbra    d1,.l
        andi    #$FE,ccr
        rts

jp_hx:                                  ; d0.w = Hiryu's PC Engine X (X / 1.5)
        move.w  HIRYU+8(a5),d0
        ext.l   d0
        add.l   d0,d0
        divs    #3,d0
        ext.l   d0
        rts

; carry set when Hiryu is not DA_JP_AHEAD px ahead of it (0x8D18; d2 = the carry its adc adds)
jp_ahead:
        bsr.s   jp_hx
        move.l  O_PX(a0),d1
        asr.l   #8,d1
        add.w   d2,d1
        btst    #0,O_FACE(a0)
        bne.s   .l
        add.w   #DA_JP_AHEAD,d1         ; facing right: Hiryu X < X + 128 + c
        cmp.w   d1,d0
        blt.s   .yes
.no:    andi    #$FE,ccr
        rts
.l:     sub.w   #DA_JP_AHEAD,d1         ; facing left: Hiryu X >= X - 128 + c
        cmp.w   d1,d0
        blt.s   .no
.yes:   ori     #1,ccr
        rts

; carry set when it faces away from Hiryu (0x5857 in PC Engine X)
jp_away:
        bsr.s   jp_hx
        move.l  O_PX(a0),d1
        asr.l   #8,d1
        cmp.w   d1,d0
        blt.s   .left
        btst    #0,O_FACE(a0)
        bne.s   .yes
.no:    andi    #$FE,ccr
        rts
.left:  btst    #0,O_FACE(a0)
        bne.s   .no
.yes:   ori     #1,ccr
        rts

; carry set when it is level with Hiryu: |his PC Engine Y - its Y| < DA_JP_DY (0x57A5)
jp_level:
        move.w  #2047,d0
        sub.w   HIRYU+$C(a5),d0
        sub.w   #DA_HIRYU_DY,d0
        move.l  O_PY(a0),d1
        asr.l   #8,d1
        sub.w   d1,d0
        bpl.s   .a
        neg.w   d0
.a:     cmp.w   #DA_JP_DY,d0
        rts

; its animation (the interpreter 0x68:0x53B4, once a tick): another animation asked for starts from its first step;
; each step shows its ticks; past the last it loops (0xFF, 0xFE n) at once. A step's flip is shown XOR its facing as it
; is read (0x5438). Its record: the frame and that displayed flip (desert_actors_ex: 'frames').
jp_anim:
        move.b  O_JAN(a0),d0
        cmp.b   O_JCUR(a0),d0
        beq.s   .same
        move.b  d0,O_JCUR(a0)
        clr.b   O_JSTEP(a0)
        clr.b   O_JCT(a0)
.same:  tst.b   O_JCT(a0)
        beq.s   .step
        subq.b  #1,O_JCT(a0)
        rts
.step:  moveq   #0,d0
        move.b  O_JCUR(a0),d0
        add.w   d0,d0
        lea     da_jp_anims,a1
        adda.w  0(a1,d0.w),a1           ; ticks a step, steps, the step it loops to, the steps
        moveq   #0,d1
        move.b  O_JSTEP(a0),d1
        cmp.b   1(a1),d1
        bcs.s   .s
        move.b  2(a1),d1
.s:     move.b  0(a1),d0
        subq.b  #1,d0
        move.b  d0,O_JCT(a0)
        move.b  3(a1,d1.w),d0
        addq.b  #1,d1
        move.b  d1,O_JSTEP(a0)
        move.b  d0,d1
        and.b   #$1F,d0
        move.b  d0,O_JFR(a0)
        lsr.b   #5,d1
        move.b  O_FACE(a0),d0
        eor.b   d0,d1
        and.b   #1,d1
        move.b  d1,O_JFL(a0)
        move.b  O_JFR(a0),d0
        add.b   d0,d0
        add.b   d1,d0
        bra     da_anim

jp_show:                                ; the jeep in list C (in front of Hiryu), its gunner in list A (behind him)
        movea.l $1A(a0),a6
        jsr     DA_ANIM_STEP
        jsr     DA_LISTC
        move.l  O_GUN(a0),d0
        beq.s   .r
        movea.l d0,a3
        exg     a0,a3
        movea.l $1A(a0),a6
        jsr     DA_ANIM_STEP
        jsr     DA_LISTA
        exg     a0,a3
.r:     rts

jp_gun_make:                            ; its gunner (0x8D8C), set up at once, where the PC Engine's new record is: (0, 0)
        moveq   #K_GUNNER,d0
        move.b  O_FACE(a0),d1
        moveq   #-1,d2
        moveq   #0,d3
        move.w  #2047,d4
        bsr     da_spawn
        bcs.s   .r
        move.l  a1,O_GUN(a0)
        move.l  a0,O_BODY(a1)
        addq.w  #1,DA_GNMADE
        exg     a0,a1
        moveq   #0,d0                   ; no collision (PC Engine colflags 0)
        bsr     da_init
        clr.w   O_T1(a0)
        clr.l   O_GST(a0)               ; its step timer, pause, shots and fire flag
        clr.w   O_JFR(a0)               ; frame 0, no flip
        exg     a0,a1
.r:     rts

jp_gun_place:                           ; its gunner over it (0x9134): its X, its Y + da_gn_dy by its frame
        move.l  O_GUN(a0),d0
        beq.s   .r
        movea.l d0,a3
        cmpi.b  #2,O_ST(a3)             ; (not once it is going: the PC Engine leaves it where it was)
        bne.s   .r
        move.l  O_X(a0),O_X(a3)
        moveq   #0,d0
        move.b  O_JFR(a0),d0
        lea     da_gn_dy,a1
        move.b  0(a1,d0.w),d0
        ext.w   d0
        swap    d0
        clr.w   d0
        add.l   O_Y(a0),d0
        move.l  d0,O_Y(a3)
.r:     rts

jp_gun_tick:                            ; its gunner's tick, after its own (the PC Engine's slot order: 0x8F7F)
        move.l  O_GUN(a0),d0
        beq.s   .r
        movea.l d0,a3
        exg     a0,a3                   ; a0 = the gunner, a3 = its jeep
        bsr.s   gn_tick                 ; carry set: it goes
        exg     a0,a3
        bcc.s   .r
        clr.l   O_GUN(a0)
        movea.l a3,a1
        moveq   #K_GUNNER,d0
        bra     da_free_part
.r:     rts

; ---------------------------------------------------------------- the gunner
; PC Engine actor 0x49 (0x74:0x8F7F), the jeep's gunner (kind 18): its jeep makes it, steps it after its own tick,
; places it (X its X, Y its Y + da_gn_dy by its frame) and draws it. No collision. Each tick (0x8FAA): every
; DA_GN_AIM_T + 1 ticks, on screen (step 2's window, at its place as last placed: the PC Engine's new record is at
; (0, 0), so its first aim finds it off screen) it aims at Hiryu (the drone's direction, 0x587D, mirrored unless its
; X flip is set): da_gn_aim gives its frame and whether it fires; the jeep turning (its frame DA_GN_TURN) shows frame
; DA_GN_NOFIRE. Every 3 ticks a fire step: DA_GN_BURST bullets (the pilot's kind 1, da_gn_shot by its frame), then
; DA_GN_PAUSE steps without. Then it takes the jeep's displayed flip. When the jeep becomes the wreck it stops (the
; PC Engine's state 3); the next tick it goes in one stock explosion (its death path's sub-state is left at 1, so of
; its 220-tick drift only the last debris, entry 2, runs: 0x9235).
da_gunner:
        lea     .s(pc),a1
        bra     da_state
.s:     dc.w    da_free-.s,gn_run-.s,gn_run-.s,da_free-.s
gn_run:                                 ; its jeep runs it; alone it goes
        move.l  O_BODY(a0),d0
        moveq   #K_JEEP,d1
        bsr     da_linked
        bcc     da_free
        rts

gn_tick:                                ; a0 = the gunner, a3 = its jeep: carry set when it goes
        cmpi.b  #4,O_ST(a0)             ; stopped since the last tick: one big burst, gone
        beq.s   .gone
        cmpi.b  #4,O_ST(a3)             ; the jeep the wreck (PC Engine state 4: O_SUB 2 and up): stop (0x8FC4)
        bne.s   .live
        cmpi.b  #2,O_SUB(a3)
        bcs.s   .live
        move.b  #4,O_ST(a0)
        andi    #$FE,ccr
        rts
.live:  bsr.s   gn_aim
        bsr     gn_fire
        move.b  O_JFL(a3),O_GFL(a0)     ; 0x9134: the jeep's flip (its place: jp_gun_place, every frame)
        moveq   #0,d0
        move.b  O_JFR(a0),d0
        add.b   d0,d0
        add.b   O_GFL(a0),d0
        bsr     da_anim
        andi    #$FE,ccr
        rts
.gone:  move.w  #DA_GN_EX_DX,d3         ; (by its facing as it was made: the PC Engine never changes it)
        btst    #0,O_FACE(a0)
        beq.s   .x
        neg.w   d3
.x:     move.w  #DA_GN_EX_DY,d4
        bsr     da_explode_d
        ori     #1,ccr
        rts

gn_aim:                                 ; 0x9028
        cmpi.b  #DA_GN_TURN,O_JFR(a3)
        bne.s   .t
        move.b  #DA_GN_NOFIRE,O_JFR(a0)
        clr.w   O_T1(a0)
        rts
.t:     tst.w   O_T1(a0)
        beq.s   .aim
        subq.w  #1,O_T1(a0)
        rts
.aim:   move.w  #DA_GN_AIM_T,O_T1(a0)
        move.w  #DA_SCR_X0,d2           ; on screen (0x58E2)
        move.w  #DA_SCR_X1,d3
        move.w  #DA_SCR_Y0,d4
        move.w  #DA_SCR_Y1,d5
        move.w  O_Y(a0),d1
        bsr     da_window
        bcc.s   .none
        bsr     dr_dir                  ; the direction to Hiryu (0x587D)
        cmp.b   #$10,d0
        bcc.s   .none
        tst.b   O_GFL(a0)               ; its X flip clear (facing left): mirrored
        bne.s   .m
        neg.b   d0
.m:     and.w   #15,d0
        lea     da_gn_aim,a1
        move.b  0(a1,d0.w),d0
        move.b  d0,d1
        and.b   #$7F,d0
        move.b  d0,O_JFR(a0)
        and.b   #$80,d1
        move.b  d1,O_GFI(a0)
        rts
.none:  clr.b   O_JFR(a0)
        clr.b   O_GFI(a0)
        rts

gn_fire:                                ; 0x8FDF
        cmpi.b  #DA_GN_NOFIRE,O_JFR(a0)
        bne.s   .t
        clr.b   O_GST(a0)
        rts
.t:     tst.b   O_GST(a0)
        beq.s   .step
        subq.b  #1,O_GST(a0)
        rts
.step:  move.b  #DA_GN_GAP,O_GST(a0)
        tst.b   O_GPA(a0)
        beq.s   .p
        subq.b  #1,O_GPA(a0)
        rts
.p:     tst.b   O_GFI(a0)
        bne.s   .f
        clr.b   O_GSH(a0)
        rts
.f:     cmpi.b  #DA_GN_BURST,O_GSH(a0)
        bcs.s   .shot
        clr.b   O_GSH(a0)
        move.b  #DA_GN_PAUSE,O_GPA(a0)
        rts
.shot:  addq.b  #1,O_GSH(a0)            ; a bullet (0x909B) by its frame, ahead by its X flip; none when pool 5 is full
        moveq   #0,d5
        move.b  O_JFR(a0),d5
        mulu    #10,d5
        lea     da_gn_shot,a1
        move.w  O_Y(a0),d4
        add.w   0(a1,d5.w),d4
        move.w  #DA_GN_SHOT_DX,d3
        tst.b   O_GFL(a0)
        beq.s   .x
        neg.w   d3
.x:     add.w   O_X(a0),d3
        moveq   #K_BULLET,d0
        moveq   #0,d1
        moveq   #-1,d2
        movem.l d5/a3,-(sp)
        bsr     da_spawn
        movem.l (sp)+,d5/a3             ; (movem keeps the carry)
        bcs.s   .r
        addq.w  #1,DA_GNSHOT
        lea     da_gn_shot+2,a2
        move.l  0(a2,d5.w),d0
        tst.b   O_GFL(a0)
        bne.s   .v
        neg.l   d0
.v:     move.l  d0,O_VX(a1)
        move.l  4(a2,d5.w),O_VY(a1)
.r:     rts

; -------------------------------------------------------------- the officer
; PC Engine actor 0x45 (0x74:0x8071), the red-cap officer who becomes the antlion (kind 19; spawn list 3, section 1's
; state 0: PC Engine (2608, 1152), once id 0x70). Its frames 0-4 are the officer, 5-7 an energy ball turning into the
; antlion, 8 and 9 the antlion. It thinks once a tick (its first update frame and every other one after) in PC Engine
; terms (its 8.8 position O_PX, O_PY; its Y velocity O_OVY; timers in ticks) and moves every frame by half the tick's
; move; it never moves along X, never flips and has no floor or wall test. Each tick (0x809A): the AI, the move, its
; animation (pa_anim: the PC Engine's interpreter on its own scripts), the hits, the flash; then it steps its sand-pull
; controller (kind 23), after itself, as the PC Engine's slots run them. Its AI (0x80BE; O_SUB = 2 x the sub-state):
;   0 wait until its once status is DA_OF_GO (section 1's go, after the portrait); harmless until 4 ends (colflags 0);
;   1 0 ticks; 2 pointing, DA_OF_POINT_T ticks; 3 the blue ring and the sand, DA_OF_RING_T ticks, then it sinks
;     DA_OF_SINK_V a tick down to DA_OF_FLOOR; 4 the transform, DA_OF_MORPH_T ticks; then contact hurts (colflags
;     0x80) and its pattern starts (da_of_rank: the rank's, sampled again at each pattern's end, da_rank);
;   5 DA_OF_IDLE_T ticks before each action: 0 idle; 1 clack (6, DA_OF_CLACK_T ticks); 2 leap (7: DA_OF_LEAP_V, then
;     DA_OF_LEAP_G a tick before each move, down to DA_OF_FLOOR; slashable only then: colflags 0xC0); 3 sand burst (8:
;     DA_OF_BURST_N + 1 rounds of DA_OF_BURST_T ticks, 8 grains a round, each round re-arming the sand-pull through its
;     once status's bit DA_OF_ARM_BIT); 4 energy ball (9: DA_OF_BALL_T ticks, one ball).
; Its subs 2-4 aim the camera at it (0x85BD; da_pan pans the arcade camera the PC Engine's way while they last). A tick
; with a slash (da_collide counts slashes only, which reach it only in a leap; contact never counts) counts once and
; shows the antlion's slot white for the tick (0x856B); DA_OF_HITS of them start the death (0x83FC) on its next tick:
; no collision, sinking DA_OF_DIE_V a tick, the slot black on alternate ticks (0x8597), its debris script (da_of_dbr:
; stock explosions while pool 6 has BOOM_FREE free); at its end 500 and 200 points (two stock commands on one frame:

; Drawn in list C, in front of Hiryu (the PC Engine's layer 3, Hiryu's 4). Its colors: the officer's in DA_OF_SLOT,
; written at its start (the location caption's slot, shown only at the stage's start); the antlion's in DA_AL_SLOT.
da_officer:
        lea     .s(pc),a1
        bra     da_state
.s:     dc.w    of_init-.s,of_run-.s,of_die-.s,da_free-.s

of_init:
        moveq   #0,d0                   ; harmless until its transform ends (PC Engine colflags 0)
        bsr     da_init
        addq.w  #1,DA_OFSPAWN
        clr.b   O_TICK(a0)
        clr.b   O_SUB(a0)
        clr.w   O_OVY(a0)
        clr.w   O_T1(a0)
        clr.w   O_T2(a0)
        clr.l   O_PULL(a0)
        clr.l   O_PHITS(a0)             ; its hits, its place in its pattern, the pattern's rank, its action
        clr.b   O_JAN(a0)               ; animation 0 asked for, none playing (+0x0F = 0xFF)
        st      O_JCUR(a0)
        clr.w   O_JSTEP(a0)             ; (and O_JCT)
        clr.b   O_JFR(a0)
        moveq   #0,d0                   ; its PC Engine position (its X is 1.5x an even one: spawn_data)
        move.w  O_X(a0),d0
        add.l   d0,d0
        divu    #3,d0
        swap    d0
        clr.w   d0
        swap    d0
        lsl.l   #8,d0
        move.l  d0,O_PX(a0)
        move.w  #2047,d0
        sub.w   O_Y(a0),d0
        ext.l   d0
        lsl.l   #8,d0
        move.l  d0,O_PY(a0)
        lea     da_of_pal7,a1           ; the officer's colors into its slot
        lea     $914000+32*DA_OF_SLOT,a2
        moveq   #8-1,d0
.c:     move.l  (a1)+,(a2)+
        dbra    d0,.c
        lea     POOL5-$FF8000(a5),a1    ; its sand-pull (spawn list 3 makes it on the same frame; addressed from a5,
        moveq   #30-1,d0                ; 0xFFFFxxxx, as the pool loop's a0 is, for the links' compares)
.p:     tst.b   (a1)
        beq.s   .n
        cmpi.b  #3,$17(a1)
        bne.s   .n
        cmpi.b  #K_PULL,O_KIND(a1)
        bne.s   .n
        move.l  a1,O_PULL(a0)
        move.l  a0,O_BODY(a1)
        bra.s   of_run
.n:     lea     $50(a1),a1
        dbra    d0,.p
of_run:
        bchg    #0,O_TICK(a0)
        bne     of_frame                ; between its ticks
        movem.l O_PX(a0),d0-d1          ; one PC Engine tick (0x809A)
        movem.l d0-d1,-(sp)
        clr.b   DA_PANF                 ; the camera's target: its subs 2-4 aim it again
        bsr     of_ai
        move.w  O_OVY(a0),d0            ; the move (0x5634/0x5641; along Y only)
        ext.l   d0
        add.l   d0,O_PY(a0)
        bsr     of_anim
        bsr     of_hits
        bsr     of_flash
of_tick:                                ; the old PC Engine position on the stack: the tick's move, half of it a frame
        movem.l (sp)+,d0-d1
        move.l  O_PX(a0),d2
        sub.l   d0,d2
        muls    #192,d2                 ; 8.8 per tick -> 16.16 per frame: X 1.5 / 2, Y -1 / 2
        move.l  d2,O_VX(a0)
        move.l  O_PY(a0),d2
        sub.l   d1,d2
        asl.l   #7,d2
        neg.l   d2
        move.l  d2,O_VY(a0)
        bset    #4,O_TICK(a0)           ; (its sand-pull steps a tick below)
of_frame:
        bsr     da_move
        tst.b   DA_PANF                 ; the camera's target follows it every frame (da_pan: smooth as it moves)
        beq.s   .p
        move.w  #2047,d0
        sub.w   O_Y(a0),d0
        move.w  d0,DA_PANT
.p:     bsr     of_pull
        movea.l $1A(a0),a6
        jsr     DA_ANIM_STEP
        jmp     DA_LISTC

of_anim:                                ; its animation (0x53B4): frame f's held record (animation f)
        lea     da_of_anims,a1
        bsr     pa_anim
        bcc.s   .r
        and.b   #1,d1
        add.b   d0,d0
        add.b   d1,d0
        bra     da_anim
.r:     rts

of_hits:                                ; 0x83D4: a tick with a slash counts once (da_collide counts slashes in O_HITS)
        tst.b   O_HITS(a0)
        beq.s   .r
        clr.b   O_HITS(a0)
        addq.w  #1,DA_OFHIT
        bset    #1,O_TICK(a0)           ; the flash this tick
        addq.b  #1,O_PHITS(a0)
        cmpi.b  #DA_OF_HITS,O_PHITS(a0)
        bcs.s   .r
        move.b  #4,O_ST(a0)             ; the death (its state 3, sub-state 0) from its next tick
        clr.b   O_SUB(a0)
        addq.w  #1,DA_OFKILL
.r:     rts

of_flash:                               ; 0x856B: the antlion's slot white on a tick with a hit, its colors again the next
        bclr    #1,O_TICK(a0)
        beq.s   .no
        bset    #2,O_TICK(a0)
        lea     $914000+32*DA_AL_SLOT,a1
        moveq   #15-1,d0
.w:     move.w  #DA_OF_FLASH,(a1)+
        dbra    d0,.w
        rts
.no:    bclr    #2,O_TICK(a0)
        bne.s   of_colors
        rts
of_colors:                              ; the antlion's own colors in its slot (0x859E)
        lea     da_al_pal,a1
        lea     $914000+32*DA_AL_SLOT,a2
        moveq   #8-1,d0
.c:     move.l  (a1)+,(a2)+
        dbra    d0,.c
        rts

of_pull:                                ; its sand-pull's step this frame (pl_step; O_TICK bit 4: on its tick), after its own
        move.l  O_PULL(a0),d0
        beq.s   .r
        movea.l d0,a3
        tst.b   (a3)
        beq.s   .gone
        cmpi.b  #3,$17(a3)
        bne.s   .gone
        cmpi.b  #K_PULL,O_KIND(a3)
        bne.s   .gone
        cmp.l   O_BODY(a3),a0
        bne.s   .gone
        moveq   #0,d0
        btst    #4,O_TICK(a0)
        sne     d0
        exg     a0,a3
        bsr     pl_step
        exg     a0,a3
.r:     bclr    #4,O_TICK(a0)
        rts
.gone:  clr.l   O_PULL(a0)
        bra.s   .r

of_ai:                                  ; its sub-states (0x80BE)
        moveq   #0,d0
        move.b  O_SUB(a0),d0
        move.w  .t(pc,d0.w),d0
        jmp     .t(pc,d0.w)
.t:     dc.w    of_s0-.t,of_s1-.t,of_s2-.t,of_s3-.t,of_s4-.t,of_s5-.t,of_s6-.t,of_s7-.t,of_s8-.t,of_s9-.t

of_s0:                                  ; 0x80D2: until its once status is the go
        moveq   #0,d0
        move.b  O_ID(a0),d0
        lea     DA_ONCE,a1
        cmpi.b  #DA_OF_GO,0(a1,d0.w)
        beq.s   .go
        rts
.go:    move.b  #2,O_SUB(a0)
        move.b  #DA_OF_A_WAIT,O_JAN(a0)
        clr.w   O_T1(a0)
of_s1:                                  ; 0x80EC
        tst.w   O_T1(a0)
        beq.s   .n
        subq.w  #1,O_T1(a0)
        rts
.n:     move.b  #4,O_SUB(a0)            ; 0x80F6: pointing
        move.b  #DA_OF_A_POINT,O_JAN(a0)
        move.w  #DA_OF_POINT_T,O_T1(a0)
of_s2:                                  ; 0x8108
        tst.w   O_T1(a0)
        beq.s   .n
        subq.w  #1,O_T1(a0)
        bra     of_cam
.n:     move.b  #6,O_SUB(a0)            ; 0x8114: the ring
        move.b  #DA_OF_A_RING,O_JAN(a0)
        move.w  #DA_OF_RING_T,O_T1(a0)
of_s3:                                  ; 0x8126: the ring's time, then it sinks to its floor
        tst.w   O_OVY(a0)
        bne.s   .sink
        tst.w   O_T1(a0)
        beq.s   .v
        subq.w  #1,O_T1(a0)
        bra     of_cam
.v:     move.w  #DA_OF_SINK_V,O_OVY(a0)
        bra     of_cam
.sink:  bsr     of_py
        cmp.w   #DA_OF_FLOOR,d0
        bge.s   .in
        bra     of_cam
.in:    bsr     of_floor                ; 0x815A: on its floor, still
        move.b  #8,O_SUB(a0)            ; the transform
        move.b  #DA_OF_A_MORPH,O_JAN(a0)
        move.w  #DA_OF_MORPH_T,O_T1(a0)
of_s4:                                  ; 0x817F
        tst.w   O_T1(a0)
        beq.s   .n
        subq.w  #1,O_T1(a0)
        bra     of_cam
.n:     move.b  #1,O_COL(a0)            ; 0x818B: colflags 0x80, contact hurts; its pattern from the start
        bsr     da_rank
        move.b  d0,O_RANK(a0)
        clr.b   O_PAT(a0)
of_idle_in:                             ; 0x819D
        move.b  #10,O_SUB(a0)
        move.b  #DA_OF_A_IDLE,O_JAN(a0)
        move.w  #DA_OF_IDLE_T,O_T1(a0)
of_s5:                                  ; 0x81AF: then its next action
        tst.w   O_T1(a0)
        beq.s   .next
        subq.w  #1,O_T1(a0)
        rts
.next:  moveq   #0,d0                   ; 0x81EC: its pattern's next (0xFF: the rank again, the pattern from its start)
        move.b  O_RANK(a0),d0
        lea     da_of_rank,a1
        move.b  0(a1,d0.w),d0
        add.w   d0,d0
        lea     da_of_pats,a1
        adda.w  0(a1,d0.w),a1
        moveq   #0,d0
        move.b  O_PAT(a0),d0
        move.b  0(a1,d0.w),d0
        cmp.b   #$FF,d0
        bne.s   .a
        bsr     da_rank
        move.b  d0,O_RANK(a0)
        clr.b   O_PAT(a0)
        bra.s   .next
.a:     move.b  d0,O_ACT(a0)
        addq.b  #1,O_PAT(a0)
        add.w   d0,d0
        move.w  .act(pc,d0.w),d0
        jmp     .act(pc,d0.w)
.act:   dc.w    of_idle_in-.act,of_clack_in-.act,of_leap_in-.act,of_burst_in-.act,of_ball_in-.act

of_clack_in:                            ; action 1 (0x8262)
        move.b  #12,O_SUB(a0)
        move.b  #DA_OF_A_CLACK,O_JAN(a0)
        move.w  #DA_OF_CLACK_T,O_T1(a0)
of_s6:                                  ; 0x8274
        tst.w   O_T1(a0)
        beq     of_idle_in
        subq.w  #1,O_T1(a0)
        rts

of_leap_in:                             ; action 2 (0x8281): up, then down to its floor; slashable meanwhile
        move.b  #14,O_SUB(a0)
        move.b  #DA_OF_A_LEAP,O_JAN(a0)
        move.w  #DA_OF_LEAP_V,O_OVY(a0)
        move.b  #3,O_COL(a0)            ; colflags 0xC0
of_s7:                                  ; 0x829E: the gravity before each move
        move.w  O_OVY(a0),d0
        add.w   #DA_OF_LEAP_G,d0
        move.w  d0,O_OVY(a0)
        bmi.s   .r
        bsr     of_py
        cmp.w   #DA_OF_FLOOR,d0
        blt.s   .r
        bsr     of_floor                ; landed (0x82C0)
        move.b  #1,O_COL(a0)            ; colflags 0x80
        bra     of_idle_in
.r:     rts

of_burst_in:                            ; action 3 (0x82DC): DA_OF_BURST_N + 1 rounds
        move.b  #16,O_SUB(a0)
        move.w  #DA_OF_BURST_N,O_T2(a0)
of_round:                               ; 0x82E8
        move.b  #DA_OF_A_BURST,O_JAN(a0)
        move.w  #DA_OF_BURST_T,O_T1(a0)
        bsr     of_grains
        moveq   #DA_OF_ARM_ONCE,d0      ; the sand-pull re-armed (its once status's bit)
        lea     DA_ONCE,a1
        ori.b   #DA_OF_ARM_BIT,0(a1,d0.w)
of_s8:                                  ; 0x8303
        tst.w   O_T1(a0)
        beq.s   .n
        subq.w  #1,O_T1(a0)
        rts
.n:     tst.w   O_T2(a0)
        beq     of_idle_in
        subq.w  #1,O_T2(a0)
        bra.s   of_round

of_ball_in:                             ; action 4 (0x831B): one energy ball
        move.b  #18,O_SUB(a0)
        move.b  #DA_OF_A_BALL,O_JAN(a0)
        move.w  #DA_OF_BALL_T,O_T1(a0)
        bsr     of_ball
of_s9:                                  ; 0x8330
        tst.w   O_T1(a0)
        beq     of_idle_in
        subq.w  #1,O_T1(a0)
        rts

of_cam:                                 ; 0x85BD: the camera's target, its PC Engine Y (before this tick's move)
        st      DA_PANF
        bsr.s   of_py
        move.w  d0,DA_PANT
        rts

of_py:                                  ; d0.w = its PC Engine Y
        move.l  O_PY(a0),d0
        asr.l   #8,d0
        rts

of_floor:                               ; its Y at its floor, its fraction kept, still (0x815A, 0x82C0)
        move.l  O_PY(a0),d0
        and.l   #$FF,d0
        or.l    #DA_OF_FLOOR<<8,d0
        move.l  d0,O_PY(a0)
        clr.w   O_OVY(a0)
        rts

of_grains:                              ; a round (0x8340): a grain by heading 0-7 (da_gr_tab), but while pool 5 has
        moveq   #0,d6                   ; fewer than GRAIN_FREE free (the PC Engine skips one only with no slot)
.l:     cmpi.w  #GRAIN_FREE,POOL5_FREE(a5)
        bcs.s   .full
        move.w  d6,d0
        lsl.w   #3,d0
        lea     da_gr_tab,a3
        adda.w  d0,a3
        move.b  (a3),d3                 ; at (X + dX, Y + dY)
        ext.w   d3
        move.b  1(a3),d4
        ext.w   d4
        move.l  O_PX(a0),d0
        asr.l   #8,d0
        add.w   d0,d3
        bsr     of_py
        add.w   d0,d4
        moveq   #K_GRAIN,d0
        move.b  2(a3),d1
        movea.l a0,a2
        bsr     pr_new
        bcs.s   .full
        addq.w  #1,DA_GRMADE
.n:     addq.w  #1,d6
        cmp.w   #8,d6
        bcs.s   .l
        rts
.full:  addq.w  #1,DA_GRFULL
        bra.s   .n

of_ball:                                ; the energy ball (0x83AC) at (X + 0, Y + DA_OF_BALL_DY)
        move.l  O_PX(a0),d3
        asr.l   #8,d3
        bsr     of_py
        move.w  d0,d4
        add.w   #DA_OF_BALL_DY,d4
        moveq   #K_BALL,d0
        moveq   #0,d1
        moveq   #0,d6
        movea.l a0,a2
        bsr     pr_new
        bcs.s   .r
        addq.w  #1,DA_BLMADE
.r:     rts

of_die:                                 ; PC Engine state 3 (0x83FC): O_SUB 0 its first tick, then 2
        bchg    #0,O_TICK(a0)
        bne     of_frame
        movem.l O_PX(a0),d0-d1
        movem.l d0-d1,-(sp)
        tst.b   O_SUB(a0)
        bne.s   .d
        move.b  #2,O_SUB(a0)            ; 0x840B: no collision, its debris from the start, sinking
        clr.b   O_COL(a0)
        clr.w   O_T1(a0)
        clr.w   O_T2(a0)
        move.w  #DA_OF_DIE_V,O_OVY(a0)
.d:     bsr     of_debris
        bcs.s   .end
        bsr     of_blink
        move.w  O_OVY(a0),d0
        ext.l   d0
        add.l   d0,O_PY(a0)
        bra     of_tick
.end:   bsr     of_colors               ; 0x845B: its colors, 700 points, its once status 2, gone
        move.w  #DA_SCORE_OF1,d0
        jsr     DZ_QUEUE
        move.w  #DA_SCORE_OF2,d0
        jsr     DZ_QUEUE
        moveq   #2,d0
        bsr     da_once_set
        addq.w  #1,DA_OFEND
        addq.l  #8,sp
        bset    #4,O_TICK(a0)           ; its sand-pull's tick, as the PC Engine's slots run them, then it goes
        bsr     of_pull
        bra     da_free

of_debris:                              ; 0x846E: its debris script (da_of_dbr: ticks, entry), carry set at its end
        tst.w   O_T1(a0)
        beq.s   .read
        subq.w  #1,O_T1(a0)
        andi    #$FE,ccr
        rts
.read:  move.w  O_T2(a0),d0
        add.w   d0,d0
        lea     da_of_dbr,a1
        moveq   #0,d1
        move.b  0(a1,d0.w),d1
        cmp.b   #$FF,d1
        beq.s   .end
        move.w  d1,O_T1(a0)
        move.b  1(a1,d0.w),d2           ; its entry
        moveq   #0,d0
        move.b  d2,d0
        addq.w  #1,O_T2(a0)
        bsr.s   of_boom
        bra.s   of_debris
.end:   ori     #1,ccr
        rts

of_boom:                                ; the stock explosion at debris entry d0 (da_of_dbr_xy; X by facing), while pool 6
        cmpi.w  #BOOM_FREE,POOL6_FREE(a5)   ; has BOOM_FREE of its objects free (the jeep's rule: about 7 an explosion)
        bcs.s   .r
        add.w   d0,d0
        lea     da_of_dbr_xy,a1
        move.b  0(a1,d0.w),d3
        ext.w   d3
        move.b  1(a1,d0.w),d4
        ext.w   d4
        btst    #0,O_FACE(a0)
        beq.s   .x
        neg.w   d3
.x:     jsr     DA_ALLOC6
        bcs.s   .r
        move.w  #$0100,(a1)
        move.b  #1,$17(a1)
        add.w   O_X(a0),d3
        move.w  d3,8(a1)
        add.w   O_Y(a0),d4
        move.w  d4,$C(a1)
        clr.b   $3E(a1)
        addq.w  #1,DA_OFBOOM
.r:     rts

of_blink:                               ; 0x8597: the antlion's slot black and its colors on alternate ticks
        bchg    #3,O_TICK(a0)
        bne     of_colors
        lea     $914000+32*DA_AL_SLOT,a1
        moveq   #15-1,d0
.b:     move.w  #DA_OF_BLACK,(a1)+
        dbra    d0,.b
        rts

; ------------------------------------------------------- its projectiles
; PC Engine actor 0x47 (0x74:0x869F) by its parameter: a sand grain (kind 20, 0x86AE: harmless, DA_GR_LIFE ticks, its
; velocity by heading from da_gr_tab and DA_GR_G a tick down), the energy ball (kind 21, 0x879A: contact hurts;
; DA_BL_V up and DA_BL_G a tick down until it stops, then its ring DA_BL_RING_T ticks, then 6 needles where it is)
; and a needle (kind 22, 0x88BD: contact hurts; DA_ND_LIFE ticks, its animation, facing and velocity by heading from
; da_nd_tab, DA_ND_G a tick down). Each thinks once a tick in PC Engine terms and moves half the tick's move a frame;
; its first tick sets it up (its sub-state 0). The tick its time ends (or its officer is no longer a living one,
; 0x89AC: freed, or dying, the PC Engine's state 3: then without a move or collision) it is still shown; it goes on its
; next. Drawn in list C, in front of Hiryu (the PC Engine's layer 4, after his slot).
da_grain:
da_ball:
da_needle:
        lea     .s(pc),a1
        bra     da_state
.s:     dc.w    da_free-.s,pr_run-.s,da_free-.s,da_free-.s

pr_run:
        bchg    #0,O_TICK(a0)
        bne     pr_frame
        tst.b   O_GONE(a0)              ; going since its last tick (PC Engine state 2)
        bne     da_free
        movem.l O_PX(a0),d0-d1
        movem.l d0-d1,-(sp)
        bsr     pr_linked               ; 0x89AC: its officer alive
        bcs.s   .live
        st      O_GONE(a0)
        clr.b   O_COL(a0)
        bra.s   .anim
.live:  moveq   #0,d0
        move.b  O_KIND(a0),d0
        sub.b   #K_GRAIN,d0
        add.w   d0,d0
        lea     pr_kinds(pc),a1
        move.w  0(a1,d0.w),d0
        jsr     0(a1,d0.w)
        move.w  O_PVX(a0),d0            ; the move (0x5634/0x5641)
        ext.l   d0
        add.l   d0,O_PX(a0)
        move.w  O_OVY(a0),d0
        ext.l   d0
        add.l   d0,O_PY(a0)
.anim:  lea     da_pj_anims,a1          ; its animation (0x53B4): its kind's record of the frame and its flips
        bsr     pa_anim
        bcc.s   .v
        moveq   #0,d2
        move.b  O_KIND(a0),d2
        sub.b   #K_GRAIN,d2
        lea     pr_first(pc),a1
        sub.b   0(a1,d2.w),d0           ; the frame's place among its kind's frames
        cmpi.b  #K_BALL,O_KIND(a0)
        bne.s   .x
        add.b   d0,d0                   ; (the ball's, each with its Y-flipped one)
        btst    #1,d1
        beq.s   .x
        addq.b  #1,d0
.x:     add.b   d0,d0
        and.b   #1,d1
        add.b   d1,d0
        bsr     da_anim
.v:     movem.l (sp)+,d0-d1             ; the tick's move, half of it a frame
        move.l  O_PX(a0),d2
        sub.l   d0,d2
        muls    #192,d2
        move.l  d2,O_VX(a0)
        move.l  O_PY(a0),d2
        sub.l   d1,d2
        asl.l   #7,d2
        neg.l   d2
        move.l  d2,O_VY(a0)
pr_frame:
        bsr     da_move
        movea.l $1A(a0),a6
        jsr     DA_ANIM_STEP
        jmp     DA_LISTC
pr_kinds:
        dc.w    gr_tick-pr_kinds,bl_tick-pr_kinds,nd_tick-pr_kinds
pr_first:
        dc.b    DA_GR_F0,DA_BL_F0,DA_ND_F0,0    ; each kind's first frame of type 0x47 (desert_actors_ex KINDS 'frames')

gr_tick:                                ; a grain (0x8703)
        tst.b   O_SUB(a0)
        bne.s   .b
        move.b  #2,O_SUB(a0)            ; sub 0 (0x8710): its time, animation, facing and velocity by heading
        move.w  #DA_GR_LIFE,O_T1(a0)
        move.b  #DA_GR_A,O_JAN(a0)
        moveq   #0,d0
        move.b  O_HEAD7(a0),d0
        lsl.w   #3,d0
        lea     da_gr_tab,a1
        adda.w  d0,a1
        move.b  2(a1),O_FACE(a0)
        move.w  4(a1),O_PVX(a0)
        move.w  6(a1),O_OVY(a0)
.b:     add.w   #DA_GR_G,O_OVY(a0)      ; 0x874E
pr_life:
        tst.w   O_T1(a0)
        beq.s   .end
        subq.w  #1,O_T1(a0)
        rts
.end:   st      O_GONE(a0)
        rts

nd_tick:                                ; a needle (0x8918)
        tst.b   O_SUB(a0)
        bne.s   .b
        move.b  #2,O_SUB(a0)            ; sub 0 (0x8925)
        move.w  #DA_ND_LIFE,O_T1(a0)
        moveq   #0,d0
        move.b  O_HEAD7(a0),d0
        lsl.w   #3,d0
        lea     da_nd_tab,a1
        adda.w  d0,a1
        move.b  (a1),O_JAN(a0)
        move.b  1(a1),O_FACE(a0)
        move.w  4(a1),O_PVX(a0)
        move.w  6(a1),O_OVY(a0)
.b:     add.w   #DA_ND_G,O_OVY(a0)      ; 0x8964
        bra.s   pr_life

bl_tick:                                ; the ball (0x87F5)
        moveq   #0,d0
        move.b  O_SUB(a0),d0
        move.w  .t(pc,d0.w),d0
        jmp     .t(pc,d0.w)
.t:     dc.w    bl_s0-.t,bl_s1-.t,bl_s2-.t
bl_s0:  move.b  #2,O_SUB(a0)            ; 0x8804: up
        move.b  #DA_BL_A_RISE,O_JAN(a0)
        move.w  #DA_BL_V,O_OVY(a0)
bl_s1:  move.w  O_OVY(a0),d0            ; 0x881B: slowing until it stops
        add.w   #DA_BL_G,d0
        move.w  d0,O_OVY(a0)
        bmi.s   bl_r
        clr.w   O_OVY(a0)
        move.b  #4,O_SUB(a0)            ; its ring
        move.w  #DA_BL_RING_T,O_T1(a0)
        move.b  #DA_BL_A_RING,O_JAN(a0)
bl_s2:  tst.w   O_T1(a0)                ; 0x8848
        beq.s   bl_end
        subq.w  #1,O_T1(a0)
bl_r:   rts
bl_end: bsr.s   bl_needles              ; 0x885F: 6 needles where it is, then it goes
        st      O_GONE(a0)
        rts

bl_needles:
        moveq   #0,d6
.l:     move.w  d6,d0
        lsl.w   #3,d0
        lea     da_nd_tab,a3
        adda.w  d0,a3
        move.l  O_PX(a0),d3
        asr.l   #8,d3
        move.l  O_PY(a0),d4
        asr.l   #8,d4
        moveq   #K_NEEDLE,d0
        move.b  1(a3),d1
        movea.l O_BODY(a0),a2
        bsr     pr_new
        bcs.s   .n
        addq.w  #1,DA_NDMADE
.n:     addq.w  #1,d6
        cmp.w   #DA_ND_N,d6
        bcs.s   .l
        rts

pr_new:                                 ; a projectile of kind d0 (facing d1, heading d6) at the PC Engine (d3, d4) (an
        movem.l d3-d4/d6/a2-a3,-(sp)    ; even X: its arcade X is exactly 1.5x), linked to the officer a2: A1, carry set
        move.w  d3,d5                   ; when pool 5 is full. Keeps d6, a0, a2-a3
        asr.w   #1,d5
        add.w   d5,d3
        neg.w   d4
        add.w   #2047,d4
        moveq   #-1,d2
        bsr     da_spawn
        movem.l (sp)+,d3-d4/d6/a2-a3    ; (movem keeps the carry)
        bcs.s   .r
        exg     a0,a1
        moveq   #0,d0                   ; its collision: the ball's and the needles' contact hurts (colflags 0x80)
        cmpi.b  #K_GRAIN,O_KIND(a0)
        beq.s   .c
        moveq   #1,d0
.c:     bsr     da_init
        clr.b   O_TICK(a0)
        clr.b   O_SUB(a0)
        clr.b   O_GONE(a0)
        clr.w   O_T1(a0)
        clr.w   O_PVX(a0)
        clr.w   O_OVY(a0)
        move.b  d6,O_HEAD7(a0)
        move.l  a2,O_BODY(a0)
        clr.b   O_JAN(a0)               ; animation 0 asked for, none playing
        st      O_JCUR(a0)
        clr.w   O_JSTEP(a0)
        moveq   #0,d0
        move.w  d3,d0
        lsl.l   #8,d0
        move.l  d0,O_PX(a0)
        moveq   #0,d0
        move.w  d4,d0
        lsl.l   #8,d0
        move.l  d0,O_PY(a0)
        exg     a0,a1
        andi    #$FE,ccr
.r:     rts

pr_linked:                              ; carry set when its officer (O_BODY) is a living one (0x89AC; dying is the PC
        move.l  O_BODY(a0),d0           ; Engine's state 3)
        beq.s   .no
        movea.l d0,a1
        tst.b   (a1)
        beq.s   .no
        cmpi.b  #3,$17(a1)
        bne.s   .no
        cmpi.b  #K_OFFICER,O_KIND(a1)
        bne.s   .no
        cmpi.b  #2,O_ST(a1)
        bne.s   .no
        ori     #1,ccr
        rts
.no:    andi    #$FE,ccr
        rts

; the PC Engine's animation interpreter (0x68:0x53B4), once a tick, on the scripts at a1 (desert_actors_ex.pce_anims:
; per animation its ticks a step, its steps, where it goes on past its last, the steps): another animation asked for
; (O_JAN) starts from its first step; a step shows its ticks; past the last it loops ('loop', 'back n') at once, or
; asks for animation n ('goto_anim n', 0x5482: nothing new this tick; n starts on the next). Carry set when a step is
; shown: d0 its frame, d1 its flips as shown (bit 0 X: the step's XOR the facing; bit 1 Y). a1 is changed.
pa_anim:
        move.b  O_JAN(a0),d0
        cmp.b   O_JCUR(a0),d0
        beq.s   .same
        move.b  d0,O_JCUR(a0)
        clr.b   O_JSTEP(a0)
        clr.b   O_JCT(a0)
.same:  tst.b   O_JCT(a0)
        beq.s   .step
        subq.b  #1,O_JCT(a0)
        andi    #$FE,ccr
        rts
.step:  moveq   #0,d0
        move.b  O_JCUR(a0),d0
        add.w   d0,d0
        adda.w  0(a1,d0.w),a1
        moveq   #0,d1
        move.b  O_JSTEP(a0),d1
        cmp.b   1(a1),d1
        bcs.s   .s
        move.b  2(a1),d1
        bpl.s   .s
        and.b   #$7F,d1                 ; goto_anim
        move.b  d1,O_JAN(a0)
        clr.b   O_JSTEP(a0)
        clr.b   O_JCT(a0)
        andi    #$FE,ccr
        rts
.s:     move.b  (a1),d0
        subq.b  #1,d0
        move.b  d0,O_JCT(a0)
        move.b  3(a1,d1.w),d0
        addq.b  #1,d1
        move.b  d1,O_JSTEP(a0)
        move.b  d0,d1
        and.b   #$1F,d0
        move.b  d0,O_JFR(a0)
        lsr.b   #5,d1
        and.b   #3,d1
        btst    #0,O_FACE(a0)
        beq.s   .f
        eor.b   #1,d1
.f:     ori     #1,ccr
        rts

; d0.w = the PC Engine's rank now ($2D0D; pce_desert_actors.rank_strip_tick's timer on DA_RANKT, the frames since the
; setup: tick t = DA_RANKT / 2; DA_RANK0 to tick DA_RANK_FIRST, then 1 more and 1 more every DA_RANK_PERIOD, at most 15)
da_rank:
        moveq   #0,d0
        move.w  DA_RANKT,d0
        lsr.w   #1,d0
        sub.w   #DA_RANK_FIRST+1,d0
        bcc.s   .up
        moveq   #DA_RANK0,d0
        rts
.up:    divu    #DA_RANK_PERIOD,d0
        and.l   #$FFFF,d0
        add.w   #DA_RANK0+1,d0
        cmp.w   #15,d0
        bls.s   .r
        moveq   #15,d0
.r:     rts

; ------------------------------------------------------- the sand-pull
; PC Engine actor 0x58 (0x74:0xA681; kind 23, spawn list 3: once id 0x71), never drawn. Its officer steps it once a
; frame after its own (pl_step; the PC Engine's slots run the officer first); alone (its officer gone) it steps
; itself, on its own tick phase, which is the officer's. Each tick (0xA699): its sub-states (0: the cycled colors at
; phase 0 until its once status is the go; 1: DA_PL_WAIT ticks; 2: idle), the flowing sand (0xA6ED: the strength,
; O_PSTR's top 2 bits, picks the cycle's period, da_pl_period; each step the next of DA_PL_PHASES phases of
; da_pl_cycle into the 6 cycled pens of each flowing-sand palette, da_pl_pens), the strength its drag takes until the
; next tick, the re-arm (0xA9A8: its once status's bit DA_PL_ARM_BIT, which the officer's bursts set, gives O_PSTR
; da_pl_arm[rank]) and the decay (2 a tick). Each frame the drag (0xA8F7): Hiryu on the ground on a slope of the open
; pit (the PC Engine's own lines, 0xA7D9 and 0xA865, on his PC Engine position: the arcade's floor of variant 3 is the
; same line widened) is dragged toward its middle by da_pl_drag[strength] (the PC Engine's px a tick, 1.5x, half a
; frame); the arcade's own floor snap keeps him on the slope (the PC Engine's own snap, 0x5BC5, stands in for it).
da_pull:
        lea     .s(pc),a1
        bra     da_state
.s:     dc.w    pl_init-.s,pl_run-.s,da_free-.s,da_free-.s

pl_init:
        moveq   #0,d0
        bsr     da_init
        clr.b   O_TICK(a0)
        clr.b   O_SUB(a0)
        clr.w   O_T1(a0)
        clr.l   O_PCNT(a0)              ; its counter, phase, strength and the strength of its drag
        clr.l   O_BODY(a0)
        move.b  FRAMEC(a5),d0           ; (not yet stepped on this frame)
        not.b   d0
        move.b  d0,O_PLAST(a0)
pl_run:
        moveq   #0,d0
        bchg    #0,O_TICK(a0)           ; its tick phase (its officer's: both start on one frame)
        seq     d0
        move.l  O_BODY(a0),d1           ; stepped by its officer while that lives (none yet: its officer, made on
        beq.s   .r                      ; the same frame, takes it on its first update)
        movea.l d1,a1
        tst.b   (a1)
        beq.s   .own
        cmpi.b  #3,$17(a1)
        bne.s   .own
        cmpi.b  #K_OFFICER,O_KIND(a1)
        bne.s   .own
        cmp.l   O_PULL(a1),a0
        beq.s   .r
.own:   move.b  FRAMEC(a5),d1
        cmp.b   O_PLAST(a0),d1
        beq.s   .r                      ; stepped on this frame already (its officer's last)
        bra.s   pl_step
.r:     rts

pl_step:                                ; a0 = the sand-pull, d0.b = $FF on its tick: its step this frame. Keeps a3
        move.b  FRAMEC(a5),O_PLAST(a0)
        tst.b   d0
        beq.s   pl_drag
        bsr     pl_tick
pl_drag:                                ; 0xA7C8-0xA997
        moveq   #0,d0
        move.b  O_PS(a0),d0
        beq     .r
        lea     HIRYU(a5),a1
        tst.b   3(a1)                   ; on the ground (his state 0; the PC Engine's +0x2D bit 6)
        bne     .r
        move.w  8(a1),d1                ; his PC Engine position (X / 1.5; the origin's Y down)
        ext.l   d1
        add.l   d1,d1
        divs    #3,d1
        move.w  #2047,d2
        sub.w   $C(a1),d2
        sub.w   #DA_PL_LY,d2            ; his height below the lines' top: 0-255 only
        cmp.w   #256,d2
        bcc     .r
        move.w  d1,d3                   ; the left slope (0xA7D9): dX = X - DA_PL_LX in [0, DA_PL_W)
        sub.w   #DA_PL_LX,d3
        cmp.w   #DA_PL_W,d3
        bcc.s   .rt
        move.b  d3,d4                   ; on its line: 2 dX - his height (8 bits) in [-DA_PL_TOL, DA_PL_TOL)
        add.b   d4,d4
        sub.b   d2,d4
        cmp.b   #-DA_PL_TOL,d4
        blt.s   .rt
        cmp.b   #DA_PL_TOL,d4
        bge.s   .rt
        cmp.w   #DA_PL_LIM_L,d3         ; dragged right while dX < DA_PL_LIM_L
        bcc.s   .r
        moveq   #1,d5
        bra.s   .drag
.rt:    move.w  d1,d3                   ; the right slope (0xA865): dX = X - DA_PL_RX in [0, DA_PL_W)
        sub.w   #DA_PL_RX,d3
        cmp.w   #DA_PL_W,d3
        bcc.s   .r
        move.b  d3,d4                   ; DA_PL_RY - 2 dX - his height
        add.b   d4,d4
        neg.b   d4
        add.b   #DA_PL_RY,d4
        sub.b   d2,d4
        cmp.b   #-DA_PL_TOL,d4
        blt.s   .r
        cmp.b   #DA_PL_TOL,d4
        bge.s   .r
        cmp.w   #DA_PL_LIM_R,d3         ; dragged left while dX >= DA_PL_LIM_R
        bcs.s   .r
        moveq   #-1,d5
.drag:  add.w   d0,d0
        add.w   d0,d0
        lea     da_pl_drag,a2
        move.l  0(a2,d0.w),d0
        tst.b   d5
        bpl.s   .a
        neg.l   d0
.a:     add.l   d0,8(a1)                ; his X (16.16)
        addq.w  #1,DA_PLDRAG
.r:     rts

pl_tick:                                ; one PC Engine tick (0xA699)
        moveq   #0,d0
        move.b  O_SUB(a0),d0
        move.w  .t(pc,d0.w),d0
        jsr     .t(pc,d0.w)
        bsr.s   pl_cycle                ; 0xA6ED
        move.b  O_PSTR(a0),d0           ; the strength the drag takes until the next tick (0xA7C8: before the decay)
        lsr.b   #6,d0
        move.b  d0,O_PS(a0)
        moveq   #0,d0                   ; 0xA9A8: re-armed by the officer's burst, then the decay
        move.b  O_ID(a0),d0
        lea     DA_ONCE,a1
        bclr    #DA_PL_ARM_N,0(a1,d0.w)
        beq.s   .d
        bsr     da_rank
        lea     da_pl_arm,a1
        move.b  0(a1,d0.w),O_PSTR(a0)
        addq.w  #1,DA_PLARM
.d:     tst.b   O_PSTR(a0)
        beq.s   .r
        subq.b  #2,O_PSTR(a0)
.r:     rts
.t:     dc.w    pl_s0-.t,pl_s1-.t,pl_s2-.t
pl_s0:  moveq   #0,d0                   ; 0xA6B8: the cycled colors at phase 0, until the go
        bsr.s   pl_colors
        moveq   #0,d0
        move.b  O_ID(a0),d0
        lea     DA_ONCE,a1
        cmpi.b  #DA_PL_GO,0(a1,d0.w)
        bne.s   pl_s2
        move.b  #2,O_SUB(a0)
        move.w  #DA_PL_WAIT,O_T1(a0)
pl_s1:  tst.w   O_T1(a0)                ; 0xA6D5
        beq.s   .n
        subq.w  #1,O_T1(a0)
        rts
.n:     move.b  #4,O_SUB(a0)
pl_s2:  rts

pl_cycle:                               ; 0xA6ED: a phase every da_pl_period[strength] ticks (0: still)
        moveq   #0,d0
        move.b  O_PSTR(a0),d0
        lsr.b   #6,d0
        lea     da_pl_period,a1
        move.b  0(a1,d0.w),d1
        beq.s   .r
        tst.b   O_PCNT(a0)
        beq.s   .step
        subq.b  #1,O_PCNT(a0)
.r:     rts
.step:  subq.b  #1,d1                   ; the period again, less this tick (0xA70F, then 0xA6ED once more)
        move.b  d1,O_PCNT(a0)
        moveq   #0,d0
        move.b  O_PPH(a0),d0
        bsr.s   pl_colors
        addq.w  #1,DA_PLSTEP
        addq.b  #1,O_PPH(a0)
        cmpi.b  #DA_PL_PHASES,O_PPH(a0)
        bcs.s   .r
        clr.b   O_PPH(a0)
        rts

pl_colors:                              ; the cycle's phase d0 into each flowing-sand palette's 6 cycled pens (0xA72F). Keeps a3
        mulu    #12,d0
        lea     da_pl_cycle,a1
        adda.w  d0,a1
        lea     da_pl_pens,a2
        move.w  (a2)+,d1
        bra.s   .t
.l:     movea.l (a2)+,a4
        move.l  (a1),(a4)+
        move.l  4(a1),(a4)+
        move.l  8(a1),(a4)+
.t:     dbra    d1,.l
        rts

; ---------------------------------------------------------- the commander
; PC Engine actor 0x4C (0x74:0xA5E4), section 4's commander (kind 24; spawn list 4, section 4's state 0: PC Engine (5632,
; 1120), once id 0x73). Harmless (colflags 0, no hitbox). It thinks once a tick in PC Engine terms (its 8.8 position, its
; X velocity, timers in ticks) and moves every frame by half the tick's move: 0 until its once status is the go (section 4,
; after portrait 7), standing (animation 0); 1 DA_CM_T1 ticks; 2 its walk (animation DA_CM_A_WALK) to the right at DA_CM_VX
; for DA_CM_WALK_T ticks, then it goes (the PC Engine's state 2: freed on its next tick, its once status kept). Its
; animations step through pa_anim on the census's scripts. Drawn in list C (the PC Engine's list 3, Hiryu's 4); its colors
; (PC Engine palette 7) are written into DA_OF_SLOT at its start (the officer's: the location caption's slot).
da_commander:
        lea     .s(pc),a1
        bra     da_state
.s:     dc.w    cm_init-.s,cm_run-.s,da_free-.s,da_free-.s

cm_init:
        moveq   #0,d0
        bsr     da_init
        addq.w  #1,DA_CMSPAWN
        clr.b   O_TICK(a0)
        clr.b   O_SUB(a0)
        clr.w   O_T1(a0)
        clr.w   O_JVX(a0)
        clr.b   O_GONE(a0)
        clr.b   O_JAN(a0)               ; animation 0 asked for, none playing
        st      O_JCUR(a0)
        clr.w   O_JSTEP(a0)
        clr.b   O_JFR(a0)
        bsr     da_pce_pos
        bsr     da_pal7
cm_run:
        bchg    #0,O_TICK(a0)
        bne.s   cm_frame
        tst.b   O_GONE(a0)              ; going since its last tick (PC Engine state 2)
        bne     da_free
        movem.l O_PX(a0),d0-d1          ; one PC Engine tick (0xA60B)
        movem.l d0-d1,-(sp)
        bsr.s   cm_ai
        move.w  O_JVX(a0),d0            ; the move (0x5634)
        ext.l   d0
        add.l   d0,O_PX(a0)
        lea     da_cm_anims,a1          ; its animation (0x53B4)
        bsr     pa_anim
        bcc.s   .v
        and.b   #1,d1
        add.b   d0,d0
        add.b   d1,d0
        bsr     da_anim
.v:     movem.l (sp)+,d0-d1
        bsr     da_pce_vel
cm_frame:
        bsr     da_move
        movea.l $1A(a0),a6
        jsr     DA_ANIM_STEP
        jmp     DA_LISTC

cm_ai:                                  ; its sub-states (0xA61D)
        moveq   #0,d0
        move.b  O_SUB(a0),d0
        move.w  .t(pc,d0.w),d0
        jmp     .t(pc,d0.w)
.t:     dc.w    cm_s0-.t,cm_s1-.t,cm_s2-.t
cm_s0:  moveq   #0,d0                   ; 0xA62C: until its once status is the go
        move.b  O_ID(a0),d0
        lea     DA_ONCE,a1
        cmpi.b  #DA_CM_GO,0(a1,d0.w)
        beq.s   .go
        rts
.go:    move.b  #2,O_SUB(a0)            ; 0xA634: animation 0, DA_CM_T1 ticks
        clr.b   O_JAN(a0)
        move.w  #DA_CM_T1,O_T1(a0)
cm_s1:  tst.w   O_T1(a0)                ; 0xA646
        beq.s   .n
        subq.w  #1,O_T1(a0)
        rts
.n:     move.b  #4,O_SUB(a0)            ; 0xA650: its walk
        move.b  #DA_CM_A_WALK,O_JAN(a0)
        move.w  #DA_CM_WALK_T,O_T1(a0)
        move.w  #DA_CM_VX,O_JVX(a0)
cm_s2:  tst.w   O_T1(a0)                ; 0xA66D
        beq.s   .n
        subq.w  #1,O_T1(a0)
        rts
.n:     st      O_GONE(a0)              ; its state 2: freed on its next tick
        rts

; its PC Engine position from its arcade one (an X 1.5x an even one: spawn_data): O_PX, O_PY (8.8)
da_pce_pos:
        moveq   #0,d0
        move.w  O_X(a0),d0
        add.l   d0,d0
        divu    #3,d0
        swap    d0
        clr.w   d0
        swap    d0
        lsl.l   #8,d0
        move.l  d0,O_PX(a0)
        move.w  #2047,d0
        sub.w   O_Y(a0),d0
        ext.l   d0
        lsl.l   #8,d0
        move.l  d0,O_PY(a0)
        rts

; the tick's move (its old PC Engine position in d0-d1), half of it a frame: O_VX, O_VY (16.16, X 1.5x, Y up)
da_pce_vel:
        move.l  O_PX(a0),d2
        sub.l   d0,d2
        asl.l   #6,d2                   ; x 192 in 32 bits (muls takes 16 bits: a mortar shell's jump to its fixed
        move.l  d2,-(sp)                ; X is more than 128 px)
        add.l   d2,d2
        add.l   (sp)+,d2
        move.l  d2,O_VX(a0)
        move.l  O_PY(a0),d2
        sub.l   d1,d2
        asl.l   #7,d2
        neg.l   d2
        move.l  d2,O_VY(a0)
        rts

; PC Engine palette 7 (the commander, the officer, the tank's hatch soldier) into its slot (RUNTIME_SLOTS)
da_pal7:
        lea     da_of_pal7,a1
        lea     $914000+32*DA_OF_SLOT,a2
        moveq   #8-1,d0
.c:     move.l  (a1)+,(a2)+
        dbra    d0,.c
        rts

; d0.w = the PC Engine camera's X (the arcade camera's X / 1.5), d1.w = its Y
da_pce_cam:
        move.w  CAMX(a5),d0
        ext.l   d0
        add.l   d0,d0
        divs    #3,d0
        move.w  #DA_CAM_TOP,d1
        sub.w   CAMY(a5),d1
        rts

; ---------------------------------------------------------- the sand strip
; PC Engine actor 0x6E (0x74:0xAD8B; kind 28, spawn list 4: PC Engine (5632, 1152), once id 0x77): one 256 x 64 frame (its
; cell repeated, palette 8), no collision, drawn in front of Hiryu (list C; the PC Engine's list 1) as eight block sprites.
; Once a tick its X is the camera's to 32 px with its own X's low 5 bits (0xADDF): it hides the background sand the PC
; Engine moves with the tank (here only the hull moves; it shows the same sand).
da_strip:
        lea     .s(pc),a1
        bra     da_state
.s:     dc.w    st_init-.s,st_run-.s,da_free-.s,da_free-.s
st_init:
        moveq   #0,d0
        bsr     da_init
        clr.b   O_TICK(a0)
        bsr     da_pce_pos
        move.l  O_PX(a0),d0
        asr.l   #8,d0
        and.w   #31,d0                  ; (its X's low bits)
        move.w  d0,O_T2(a0)
        moveq   #0,d0
        bsr     da_anim0
st_run:
        bchg    #0,O_TICK(a0)
        bne.s   .show
        bsr     da_pce_cam
        and.w   #DA_ST_MASK|$FF00,d0
        or.w    O_T2(a0),d0
        move.w  d0,d1
        asr.w   #1,d1
        add.w   d1,d0                   ; 1.5x (a multiple of 32: exact)
        move.w  d0,O_X(a0)
        clr.w   O_X+2(a0)
.show:  movea.l $1A(a0),a6
        jsr     DA_ANIM_STEP
        jmp     DA_LISTC

; ---------------------------------------------------------------- the tank
; PC Engine actor 0x4A (0x74:0x9255), section 4's boss (kind 25; spawn list 4: PC Engine (5754, 1096), once id 0x74). Its
; hull is background art the PC Engine moves by scrolling its background with the tank (0x940C); here it is on SCROLL2
; (da_hull: drawn at the tank's start, placed by dz_watch every frame: da_hull_scroll). The tank itself is not drawn and
; has no collision; it makes its four parts at its start (0x9552: kind 26), steps them after its own tick (0x9594), places
; and draws them (list A: the PC Engine's lists 5-7, behind Hiryu's 4). It thinks once a tick in PC Engine terms (its 8.8
; position and X velocity, timers in ticks) and moves every frame by half the tick's move. Each tick (0x9285): its patrol
; (0x92B0), its cannon (0x9431) and turret (0x94C1) machines, the move, its parts' steps, the death test (0x9E44), the
; treads (0xA0F4), the bob (0xA160), the hit flash (0xA09B). Every frame it holds Hiryu on its deck when the PC Engine's
; ride would (tk_ride). Its patrol (0x92B9): 0, 1 until its once status is the go; 2 DA_TK_WAIT2 ticks; 3 DA_TK_WAIT3 ticks,
; its parts rising (command DA_TK_RISE to each), then colflags 0xC0 (its hatch soldier slashable when raised) and 7; 7 right
; while X - home < DA_TK_RIGHT_LIM (vX += DA_TK_RIGHT_ACC up to DA_TK_RIGHT_MAX), then 4: still DA_TK_PAUSE_R ticks; 5 left
; while X - home >= DA_TK_LEFT_LIM (vX += DA_TK_LEFT_ACC down to DA_TK_LEFT_MAX), then 6: still DA_TK_PAUSE_L ticks, then 7.
; Its part 3, the hatch soldier, is the only one hit (a slash, only while it is raised): DA_P3_HITS ticks with a slash start
; the death (0x9EED): DA_TK_DIE_T ticks frozen, then sinking DA_TK_SINK a tick while its debris script runs (stock
; explosions while pool 6 has room), then 1500 points (DA_SCORE_TK), its once status 2 (section 4 then clears) and it and
; its parts go. Its hull stays where it was. No sound: the PC Engine plays none (its debris only, PSG).
da_tank:
        lea     .s(pc),a1
        bra     da_state
.s:     dc.w    tk_init-.s,tk_run-.s,tk_die-.s,da_free-.s

tk_init:
        moveq   #0,d0
        bsr     da_init
        addq.w  #1,DA_TKSPAWN
        clr.b   O_TICK(a0)
        clr.b   O_SUB(a0)
        clr.w   O_T1(a0)
        clr.w   O_T2(a0)
        clr.w   O_JVX(a0)
        clr.b   O_TKCOLF(a0)
        clr.l   $42(a0)                 ; its machines, timers, aim, bits, mortar index and commands, treads and bob
        clr.l   $46(a0)                 ; (O_TICK at $47 cleared again below)
        clr.l   $4A(a0)
        clr.w   $4E(a0)
        clr.b   O_TICK(a0)
        bsr     da_pce_pos
        bsr     da_pal7                 ; its hatch soldier's colors (PC Engine palette 7)
        bsr     tk_p10                  ; its parts' (palette 10), as the block has them
        bsr     tk_parts_make           ; its parts (0x9552)
        bsr     tk_hull_draw            ; its hull on SCROLL2
tk_run:
        bsr     tk_ride                 ; first its deck (0xA1D7, its tick's first step), every frame
        bchg    #0,O_TICK(a0)
        bne     tk_frame
        movem.l O_PX(a0),d0-d1          ; one PC Engine tick (0x9285)
        movem.l d0-d1,-(sp)
        bsr     tk_ai                   ; 0x92B0
        bsr     tk_cannon               ; 0x9431
        bsr     tk_turret               ; 0x94C1
        move.w  O_JVX(a0),d0            ; the move (0x5634: along X only while it lives)
        ext.l   d0
        add.l   d0,O_PX(a0)
        bsr     tk_parts                ; 0x9594
        btst    #3,O_TKFL(a0)           ; 0x9E44: its hatch soldier destroyed: the death from its next tick
        beq.s   .a
        move.b  #4,O_ST(a0)
        clr.b   O_SUB(a0)
        addq.w  #1,DA_TKKILL
.a:     bsr     tk_treads               ; 0xA0F4
        bsr     tk_bob                  ; 0xA160
        bsr     tk_flash                ; 0xA09B
tk_tick:                                ; the old PC Engine position on the stack: the tick's move, half of it a frame
        movem.l (sp)+,d0-d1
        bsr     da_pce_vel
tk_frame:
        move.w  O_X(a0),d6              ; the frame's move, its integer X step (the ride's carry)
        bsr     da_move
        sub.w   O_X(a0),d6
        neg.w   d6
        move.w  O_X(a0),DA_HULLX        ; the hull with it (0x940C)
        move.w  O_Y(a0),DA_HULLY
        tst.b   DA_RIDING               ; the deck carries Hiryu by the frame's integer X step (0xA2B6, 0x5BA2)
        beq.s   .sh
        add.w   d6,HIRYU+8(a5)
.sh:    bra     tk_show

; the PC Engine's PC Engine integer position: d0.w = X, d1.w = Y
tk_pos:
        move.l  O_PX(a0),d0
        asr.l   #8,d0
        move.l  O_PY(a0),d1
        asr.l   #8,d1
        rts

; its patrol (0x92B0; O_SUB = 2 x the PC Engine's sub-state)
tk_ai:
        moveq   #0,d0
        move.b  O_SUB(a0),d0
        move.w  .t(pc,d0.w),d0
        jmp     .t(pc,d0.w)
.t:     dc.w    tk_s0-.t,tk_s1-.t,tk_s2-.t,tk_s3-.t,tk_s4-.t,tk_s5-.t,tk_s6-.t,tk_s7-.t
tk_s0:  move.b  #2,O_SUB(a0)            ; 0x92C9
tk_s1:  moveq   #0,d0                   ; 0x92CF: until its once status is the go
        move.b  O_ID(a0),d0
        lea     DA_ONCE,a1
        cmpi.b  #DA_TK_GO,0(a1,d0.w)
        beq.s   .go
        rts
.go:    move.b  #4,O_SUB(a0)
        move.w  #DA_TK_WAIT2,O_T1(a0)
tk_s2:  tst.w   O_T1(a0)                ; 0x92E3
        beq.s   .n
        subq.w  #1,O_T1(a0)
        rts
.n:     move.b  #6,O_SUB(a0)            ; its parts rise
        move.w  #DA_TK_WAIT3,O_T1(a0)
        move.b  #DA_TK_RISE,O_TKC0(a0)
        move.b  #DA_TK_RISE,O_TKC2(a0)
        move.b  #DA_TK_RISE,O_TKC1(a0)
tk_s3:  tst.w   O_T1(a0)                ; 0x9307
        beq.s   .n
        subq.w  #1,O_T1(a0)
        rts
.n:     move.b  #$C0,O_TKCOLF(a0)
        bra.s   tk_s7_in
tk_s4_in:                               ; 0x931A: the right pause
        move.b  #8,O_SUB(a0)
        clr.w   O_JVX(a0)
        move.w  #DA_TK_PAUSE_R,O_T1(a0)
tk_s4:  tst.w   O_T1(a0)                ; 0x932E
        beq.s   .n
        subq.w  #1,O_T1(a0)
        rts
.n:     move.b  #10,O_SUB(a0)           ; 0x9338: left
        clr.w   O_JVX(a0)
tk_s5:  bsr.s   tk_dx                   ; 0x9346
        cmp.w   #DA_TK_LEFT_LIM,d0
        blt.s   tk_s6_in
        move.w  O_JVX(a0),d0
        add.w   #DA_TK_LEFT_ACC,d0
        cmp.w   #DA_TK_LEFT_MAX,d0
        bge.s   .v
        move.w  #DA_TK_LEFT_MAX,d0
.v:     move.w  d0,O_JVX(a0)
        rts
tk_s6_in:                               ; 0x9393: the left pause
        move.b  #12,O_SUB(a0)
        clr.w   O_JVX(a0)
        move.w  #DA_TK_PAUSE_L,O_T1(a0)
tk_s6:  tst.w   O_T1(a0)                ; 0x93A7
        beq.s   tk_s7_in
        subq.w  #1,O_T1(a0)
        rts
tk_s7_in:                               ; 0x93B1: right
        move.b  #14,O_SUB(a0)
        clr.w   O_JVX(a0)
tk_s7:  bsr.s   tk_dx                   ; 0x93BF
        cmp.w   #DA_TK_RIGHT_LIM,d0
        bge     tk_s4_in
        move.w  O_JVX(a0),d0
        add.w   #DA_TK_RIGHT_ACC,d0
        cmp.w   #DA_TK_RIGHT_MAX,d0
        blt.s   .v
        move.w  #DA_TK_RIGHT_MAX,d0
.v:     move.w  d0,O_JVX(a0)
        rts
tk_dx:                                  ; d0.w = its PC Engine X - its home
        move.l  O_PX(a0),d0
        asr.l   #8,d0
        sub.w   #DA_TK_HOMEX,d0
        rts

; its cannon's machine (0x9431, O_TKCN; its timer O_T2): a DA_CN_WAIT-tick wait, then at its right pause (patrol 4) a shell
; (command DA_CN_CMD_FIRE to part 2) and DA_CN_FIRE_T ticks, or at its left pause (patrol 6) the mortar (DA_MT_N commands
; DA_CN_CMD_MORTAR, DA_MT_EVERY ticks apart); then the wait again
tk_cannon:
        moveq   #0,d0
        move.b  O_TKCN(a0),d0
        add.w   d0,d0
        move.w  .t(pc,d0.w),d0
        jmp     .t(pc,d0.w)
.t:     dc.w    cn_0-.t,cn_1-.t,cn_2-.t,cn_3-.t,cn_4-.t
cn_0:   move.b  #1,O_TKCN(a0)           ; 0x9444
cn_1:   move.b  #2,O_TKCN(a0)           ; 0x944A
        move.w  #DA_CN_WAIT,O_T2(a0)
cn_2:   tst.w   O_T2(a0)                ; 0x9456
        beq.s   .n
        subq.w  #1,O_T2(a0)
        rts
.n:     cmpi.b  #DA_CN_SUB_FIRE,O_SUB(a0)
        beq.s   .f
        cmpi.b  #DA_CN_SUB_MORTAR,O_SUB(a0)
        beq.s   cn_mortar
        rts
.f:     move.b  #3,O_TKCN(a0)           ; 0x9473: a shell
        move.w  #DA_CN_FIRE_T,O_T2(a0)
        move.b  #DA_CN_CMD_FIRE,O_TKC2(a0)
cn_3:   tst.w   O_T2(a0)                ; 0x9485
        beq.s   cn_1
        subq.w  #1,O_T2(a0)
        rts
cn_mortar:
        move.b  #4,O_TKCN(a0)           ; 0x9492: the mortar
        clr.b   O_TKMI(a0)
cn_next:
        move.w  #DA_MT_EVERY,O_T2(a0)   ; 0x949D
        move.b  #DA_CN_CMD_MORTAR,O_TKC2(a0)
cn_4:   tst.w   O_T2(a0)                ; 0x94A9
        beq.s   .n
        subq.w  #1,O_T2(a0)
        rts
.n:     addq.b  #1,O_TKMI(a0)
        cmpi.b  #DA_MT_N,O_TKMI(a0)
        bne.s   cn_next
        bra.s   cn_1

; its turret's machine (0x94C1, O_TKTU; its timer O_TKTT): from its patrol 3, every DA_TU_PERIOD ticks, on screen and its
; aim firing, DA_TU_BURST ticks of command DA_TU_CMD to part 1
tk_turret:
        moveq   #0,d0
        move.b  O_TKTU(a0),d0
        add.w   d0,d0
        move.w  .t(pc,d0.w),d0
        jmp     .t(pc,d0.w)
.t:     dc.w    tu_0-.t,tu_1-.t,tu_2-.t,tu_3-.t
tu_0:   move.b  #1,O_TKTU(a0)           ; 0x94D2
tu_1:   cmpi.b  #DA_TU_SUB,O_SUB(a0)    ; 0x94D8
        beq.s   tu_wait
        rts
tu_wait:
        move.b  #2,O_TKTU(a0)           ; 0x94E1
        move.b  #DA_TU_PERIOD,O_TKTT(a0)
tu_2:   tst.b   O_TKTT(a0)              ; 0x94ED
        beq.s   .n
        subq.b  #1,O_TKTT(a0)
        rts
.n:     bsr     tk_pos                  ; 0x9527: on screen (X - camera X < DA_TU_SCREEN)
        move.w  d0,d2
        bsr     da_pce_cam
        sub.w   d0,d2
        cmp.w   #DA_TU_SCREEN,d2
        bge.s   tu_wait
        tst.b   O_TKAIM(a0)             ; and its aim fires
        bpl.s   tu_wait
        move.b  #3,O_TKTU(a0)           ; 0x9508
        move.b  #DA_TU_BURST,O_TKTT(a0)
tu_3:   tst.b   O_TKTT(a0)              ; 0x9514
        beq.s   tu_wait
        subq.b  #1,O_TKTT(a0)
        move.b  #DA_TU_CMD,O_TKC1(a0)
        rts

; the treads (0xA0F4): every da_tr_period[(|vX hi| & 15) >> 1] ticks (0: still) their two pens swap (BG palette 8 colors
; 9 and 14: the hull's SCROLL2 palette DA_HULL_SLOT, pens 8 and 13)
tk_treads:
        bsr.s   tk_speed
        lsr.w   #1,d0
        lea     da_tr_period,a1
        move.b  0(a1,d0.w),d0
        beq.s   .r
        tst.b   O_TKTR(a0)
        beq.s   .n
        subq.b  #1,O_TKTR(a0)
.r:     rts
.n:     subq.b  #1,d0
        move.b  d0,O_TKTR(a0)
        moveq   #0,d0
        move.b  O_TKTP(a0),d0
        add.w   d0,d0
        add.w   d0,d0
        lea     da_tr_cols,a1
        move.w  0(a1,d0.w),$914800+32*DA_HULL_SLOT+2*8
        move.w  2(a1,d0.w),$914800+32*DA_HULL_SLOT+2*13
        eori.b  #1,O_TKTP(a0)
        rts
tk_speed:                               ; d0.w = |its vX's high byte| & 15 (0xA0F4: eor #$FF / inc of the byte)
        moveq   #0,d0
        move.b  O_JVX(a0),d0
        bpl.s   .p
        neg.b   d0
.p:     and.w   #15,d0
        rts

; the bob (0xA160): every da_bob_period[|vX hi| & 15] ticks (0: still) its Y is the home's + da_bob_dy[phase], the phase
; toggling
tk_bob:
        bsr.s   tk_speed
        lea     da_bob_period,a1
        move.b  0(a1,d0.w),d0
        beq.s   .r
        tst.b   O_TKBT(a0)
        beq.s   .n
        subq.b  #1,O_TKBT(a0)
.r:     rts
.n:     subq.b  #1,d0
        move.b  d0,O_TKBT(a0)
        moveq   #0,d0
        move.b  O_TKBP(a0),d0
        lea     da_bob_dy,a1
        move.b  0(a1,d0.w),d0
        ext.w   d0
        add.w   #DA_TK_HOMEY,d0
        move.b  d0,O_PY+2(a0)           ; its integer Y (its fraction kept)
        lsr.w   #8,d0
        move.b  d0,O_PY+1(a0)
        clr.b   O_PY(a0)
        eori.b  #1,O_TKBP(a0)
        rts

; the hit flash (0xA09B): a tick on which a part was hit (its bits 4-7), palette 10 (DA_P10_SLOT) white; restored after
tk_flash:
        move.b  O_TKFL(a0),d0
        and.b   #$F0,d0
        beq.s   .no
        bset    #1,O_TICK(a0)
        lea     $914000+32*DA_P10_SLOT,a1
        moveq   #15-1,d0
.w:     move.w  #DA_OF_FLASH,(a1)+
        dbra    d0,.w
        rts
.no:    bclr    #1,O_TICK(a0)
        bne.s   tk_p10
        rts
tk_p10: lea     da_p10_pal,a1           ; palette 10's own colors in its slot (0xA0D1)
        lea     $914000+32*DA_P10_SLOT,a2
        moveq   #8-1,d0
.c:     move.l  (a1)+,(a2)+
        dbra    d0,.c
        rts

; its parts (0x9552): four kind-26 actors, set up at once (they run only as it steps them), at (0, 2047); the first that
; pool 5 has no room for ends the making (0x9568)
tk_parts_make:
        lea     DA_TKP,a3
        clr.l   (a3)
        clr.l   4(a3)
        clr.l   8(a3)
        clr.l   12(a3)
        move.w  #0,d7
.l:     movem.l d7/a3,-(sp)
        moveq   #K_PART,d0
        moveq   #0,d1
        moveq   #-1,d2
        moveq   #0,d3
        move.w  #2047,d4
        bsr     da_spawn
        movem.l (sp)+,d7/a3             ; (movem keeps the carry)
        bcs.s   .r
        move.l  a1,(a3)+
        move.l  a0,O_BODY(a1)
        exg     a0,a1
        moveq   #0,d0                   ; no collision until its colflags say so (0x9EB3)
        bsr     da_init
        move.b  d7,O_PIX(a0)
        clr.b   O_PRM(a0)               ; its machines and timer (bytes: the fields start odd)
        clr.b   O_PAM(a0)
        clr.b   O_PT(a0)
        clr.b   O_PFL(a0)               ; its flags, hits and pop-up machine
        clr.b   O_PHT(a0)
        clr.b   O_PPU(a0)
        clr.w   O_PRISE(a0)
        lea     da_tk_pf,a2
        move.b  0(a2,d7.w),O_JFR(a0)
        exg     a0,a1
        addq.w  #1,d7
        cmp.w   #4,d7
        bcs.s   .l
.r:     rts

; its hull: its tiles into the SCROLL2 map (da_hull), its palette into SCROLL2 palette DA_HULL_SLOT, its place for dz_watch
; (da_hull_scroll), and SCROLL2 on (unless the layers are off or held: a respawn; area 5's restart record has it on)
tk_hull_draw:
        movem.l d0-d6/a0/a3-a4/a6,-(sp) ; the whole map first: the transparent tile (it held the stock's tiles)
        move.l  #DA_S2_BLANK<<16|DA_HULL_SLOT,d0
        move.l  d0,d1
        move.l  d0,d2
        move.l  d0,d3
        move.l  d0,d4
        move.l  d0,d5
        move.l  d0,d6
        movea.l d0,a0
        movea.l d0,a3
        movea.l d0,a4
        movea.l d0,a6
        movea.l d0,a1
        lea     DA_S2_MAP+$4000,a2
        move.w  #$4000/48-1,d7          ; 48 bytes a move: 341 of them, then the last 16 bytes
.f:     movem.l d0-d6/a0-a1/a3-a4/a6,-(a2)
        dbra    d7,.f
        movem.l d0-d3,-(a2)
        movem.l (sp)+,d0-d6/a0/a3-a4/a6
        lea     da_hull,a1
        lea     DA_S2_MAP,a2
        move.w  (a1)+,d7
        bra.s   .t
.l:     move.w  (a1)+,d0
        move.w  (a1)+,0(a2,d0.w)
        move.w  #DA_HULL_SLOT,2(a2,d0.w)
.t:     dbra    d7,.l
        lea     da_hull_pal,a1
        lea     $914800+32*DA_HULL_SLOT,a2
        moveq   #8-1,d0
.c:     move.l  (a1)+,(a2)+
        dbra    d0,.c
        move.w  O_X(a0),DA_HULLX
        move.w  O_Y(a0),DA_HULLY
        st      DA_HULLON
        tst.w   LAYER_W(a5)
        beq.s   .r
        cmpi.w  #$1540,LAYER_W(a5)      ; a respawn's hold (respawn_layers.s HIDE): its reveal puts back the
        beq.s   .r                      ; record's word, which has SCROLL2, and only while the shadow still is HIDE
        ori.w   #DZ_LAYER_S2,LAYER_W(a5)
.r:     rts

; from dz_watch (asm/desert.s), every frame after the game's: SCROLL2's position for the hull at DA_HULLX/Y on the camera's
; picture (the layer object's X and Y, which 0x1CE9E leaves in its shadow every frame, and the shadow itself now)
da_hull_scroll:
        tst.b   DA_HULLON
        beq.s   .r
        move.w  CAMX(a5),d0
        sub.w   DA_HULLX,d0
        add.w   #DA_S2X0,d0
        and.w   #$3FF,d0
        move.w  CAMY(a5),d1
        sub.w   DA_HULLY,d1
        add.w   #DA_S2Y0,d1
        and.w   #$3FF,d1
        move.w  d0,S2OBJ+8(a5)
        move.w  d1,S2OBJ+$C(a5)
        move.w  d0,S2SHX(a5)
        move.w  d1,S2SHY(a5)
.r:     rts

; its parts' steps (0x9594), after its own move, in their order: 0 inert, 1 the turret, 2 the cannon, 3 the hatch soldier
; (placed from part 2). a3 = the part. Each first clears its hit bit (0x9E5B)
tk_parts:
        move.w  #0,d7
.l:     move.w  d7,d0
        add.w   d0,d0
        add.w   d0,d0
        lea     DA_TKP,a1
        move.l  0(a1,d0.w),d0
        beq.s   .n
        movea.l d0,a3
        moveq   #K_PART,d1
        bsr     tk_mine
        bcc.s   .n
        move.w  d7,-(sp)
        lea     da_tk_hclr,a1
        move.b  0(a1,d7.w),d0
        and.b   d0,O_TKFL(a0)
        add.w   d7,d7
        move.w  .t(pc,d7.w),d0
        jsr     .t(pc,d0.w)
        move.w  (sp)+,d7
.n:     addq.w  #1,d7
        cmp.w   #4,d7
        bcs.s   .l
        rts
.t:     dc.w    pt_0-.t,pt_1-.t,pt_2-.t,pt_3-.t

tk_mine:                                ; carry set when a3 is still the tank's part (an active kind-26 actor linked to a0)
        tst.b   (a3)
        beq.s   .no
        cmpi.b  #3,$17(a3)
        bne.s   .no
        cmp.b   O_KIND(a3),d1
        bne.s   .no
        cmp.l   O_BODY(a3),a0
        bne.s   .no
        ori     #1,ccr
        rts
.no:    andi    #$FE,ccr
        rts

pt_place:                               ; its PC Engine place from the tank's (d0 = dX, d1 = dY) and its rise (0x56DA)
        move.l  O_PX(a0),d2
        asr.l   #8,d2
        add.w   d0,d2
        move.w  d2,O_PPX(a3)
        move.l  O_PY(a0),d2
        asr.l   #8,d2
        add.w   d1,d2
        move.b  O_PRISE(a3),d0
        ext.w   d0
        add.w   d0,d2
        move.w  d2,O_PPY(a3)
        rts

pt_0:   moveq   #DA_PT0_DX,d0           ; part 0 (0x96C8): inert
        moveq   #DA_PT0_DY,d1
        bsr.s   pt_place
        lea     O_TKC0(a0),a2
        moveq   #0,d4                   ; its destroyed bit's number
        move.b  #DA_PT0_TOP,d5
        move.w  #DA_PT0_RV,d6
        bsr     pt_rise
        bra     pt0_act

pt_1:   moveq   #DA_PT1_DX,d0           ; part 1, the turret (0x96FE)
        moveq   #DA_PT1_DY,d1
        bsr.s   pt_place
        lea     O_TKC1(a0),a2
        moveq   #1,d4
        move.b  #DA_PT1_TOP,d5
        move.w  #DA_PT1_RV,d6
        bsr     pt_rise
        bra     pt1_act

pt_2:   moveq   #DA_PT2_DX,d0           ; part 2, the cannon (0x96E3)
        moveq   #DA_PT2_DY,d1
        bsr.s   pt_place
        lea     O_TKC2(a0),a2
        moveq   #2,d4
        move.b  #DA_PT2_TOP,d5
        move.w  #DA_PT2_RV,d6
        bsr     pt_rise
        bra     pt2_act

pt_3:   move.l  DA_TKP+8,d0             ; part 3, the hatch soldier (0x9719): placed from part 2 (0x983C)
        beq.s   .r
        movea.l d0,a1
        move.w  O_PPX(a1),d0
        add.w   #DA_PT3_DX,d0
        move.w  d0,O_PPX(a3)
        move.w  O_PPY(a1),d0
        add.w   #DA_PT3_DY,d0
        move.b  O_PRISE(a3),d1
        ext.w   d1
        add.w   d1,d0
        move.w  d0,O_PPY(a3)
        bsr     p3_popup                ; 0x9729
        bsr     p3_rise                 ; 0x9BC3
        bsr     p3_act                  ; 0x9C88
        bsr     p3_col                  ; 0x9EB3
        bra     p3_hits                 ; 0x9E5B
.r:     rts

; a part's rise (0x9864, 0x9956, 0x9A7E; O_PRM): its command (a2: the tank's byte) DA_CMD_RISE rises it by d6 a tick to the
; top d5 (the rise's high byte), DA_CMD_LOWER (or its destroyed bit d4) lowers it DA_PT_LOWER_V a tick to 0, for good
pt_rise:
        moveq   #0,d0
        move.b  O_PRM(a3),d0
        add.w   d0,d0
        move.w  .t(pc,d0.w),d0
        jmp     .t(pc,d0.w)
.t:     dc.w    pr_0-.t,pr_1-.t,pr_2-.t,pr_3-.t,pr_4-.t
pr_0:   move.b  #1,O_PRM(a3)            ; 0x9877
pr_1:   btst    d4,O_TKFL(a0)           ; 0x987D
        bne.s   pr_down
        cmpi.b  #DA_CMD_RISE,(a2)
        beq.s   .u
        cmpi.b  #DA_CMD_LOWER,(a2)
        beq.s   pr_lower
        rts
.u:     clr.b   (a2)
        move.b  #2,O_PRM(a3)            ; 0x98A1
pr_2:   add.w   d6,O_PRISE(a3)          ; 0x98A7
        move.b  O_PRISE(a3),d0
        sub.b   d5,d0
        bmi.s   .top
        rts
.top:   move.b  d5,O_PRISE(a3)
        bra.s   pr_0
pr_lower:
        clr.b   (a2)
pr_down:
        move.b  #3,O_PRM(a3)            ; 0x98C3
pr_3:   add.w   #DA_PT_LOWER_V,O_PRISE(a3)    ; 0x98C9
        tst.b   O_PRISE(a3)
        bpl.s   .z
        rts
.z:     clr.b   O_PRISE(a3)
        move.b  #4,O_PRM(a3)
pr_4:   rts

; part 0's action (0x98E6): frame DA_PT0_F; its command 3 (which nothing sends) a DA_CN_FIRE_T/2-tick wait
pt0_act:
        moveq   #0,d0
        move.b  O_PAM(a3),d0
        add.w   d0,d0
        move.w  .t(pc,d0.w),d0
        jmp     .t(pc,d0.w)
.t:     dc.w    p0_0-.t,p0_1-.t,p0_2-.t,p0_3-.t
p0_0:   move.b  #1,O_PAM(a3)            ; 0x98F7
        move.b  #DA_PT0_F,O_JFR(a3)
p0_1:   btst    #0,O_TKFL(a0)           ; 0x9903
        bne.s   .dead
        cmpi.b  #3,O_TKC0(a0)
        beq.s   .w
        cmpi.b  #4,O_TKC0(a0)
        bne.s   p0_3
        clr.b   O_TKC0(a0)
        rts
.dead:  move.b  #3,O_PAM(a3)
        rts
.w:     clr.b   O_TKC0(a0)
        move.b  #2,O_PAM(a3)            ; 0x9925
        move.b  #$20,O_PT(a3)
        move.b  #DA_PT0_F,O_JFR(a3)
p0_2:   tst.b   O_PT(a3)                ; 0x9937
        beq.s   p0_0
        subq.b  #1,O_PT(a3)
        cmpi.b  #$1E,O_PT(a3)
        bne.s   p0_3
        move.b  #DA_PT0_F,O_JFR(a3)
p0_3:   rts

; part 2's action (0x99D8): command DA_CN_CMD_FIRE a shell (its recoil frame DA_CN_RECOIL_F until DA_CN_BACK of its
; DA_CN_RECOIL_T ticks are left), DA_CN_CMD_MORTAR a mortar shell
pt2_act:
        moveq   #0,d0
        move.b  O_PAM(a3),d0
        add.w   d0,d0
        move.w  .t(pc,d0.w),d0
        jmp     .t(pc,d0.w)
.t:     dc.w    p2_0-.t,p2_1-.t,p2_2-.t,p2_3-.t,p2_4-.t
p2_0:   move.b  #1,O_PAM(a3)            ; 0x99EB
        move.b  #DA_PT2_F,O_JFR(a3)
p2_1:   btst    #2,O_TKFL(a0)           ; 0x99F7
        bne.s   .dead
        move.b  O_TKC2(a0),d0
        cmp.b   #DA_CN_CMD_FIRE,d0
        beq.s   p2_fire
        cmp.b   #DA_CN_CMD_NONE,d0
        beq.s   .z
        cmp.b   #DA_CN_CMD_MORTAR,d0
        beq.s   p2_mortar
        rts
.z:     clr.b   O_TKC2(a0)
        rts
.dead:  move.b  #4,O_PAM(a3)
p2_4:   rts
p2_fire:
        clr.b   O_TKC2(a0)              ; 0x9A23
        move.b  #2,O_PAM(a3)
        move.b  #DA_CN_RECOIL_T,O_PT(a3)
        move.b  #DA_CN_RECOIL_F,O_JFR(a3)
        bsr     tk_shell                ; 0x9D07
p2_2:   tst.b   O_PT(a3)                ; 0x9A38
        beq.s   p2_0
        subq.b  #1,O_PT(a3)
        cmpi.b  #DA_CN_BACK,O_PT(a3)
        bne.s   .r
        move.b  #DA_PT2_F,O_JFR(a3)
.r:     rts
p2_mortar:
        clr.b   O_TKC2(a0)              ; 0x9A50
        move.b  #3,O_PAM(a3)
        move.b  #DA_CN_RECOIL_T,O_PT(a3)
        bsr     tk_mortar               ; 0x9DDC
p2_3:   tst.b   O_PT(a3)                ; 0x9A5F
        beq     p2_0
        subq.b  #1,O_PT(a3)
        cmpi.b  #DA_CN_BACK,O_PT(a3)
        bne.s   .r
        move.b  #DA_PT2_F,O_JFR(a3)
.r:     rts

; part 1's action, the turret (0x9B00): every DA_TU_AIM_T + 1 ticks its aim at Hiryu (0x587D from its place: da_tu_aim, its
; frame da_tu_frames); its command DA_TU_CMD a shot and a casing, its fire frame for one tick, the next command after two
pt1_act:
        moveq   #0,d0
        move.b  O_PAM(a3),d0
        add.w   d0,d0
        move.w  .t(pc,d0.w),d0
        jmp     .t(pc,d0.w)
.t:     dc.w    p1_0-.t,p1_1-.t,p1_2-.t,p1_3-.t
p1_0:   move.b  #1,O_PAM(a3)            ; 0x9B11
        clr.b   O_PT(a3)
p1_1:   btst    #1,O_TKFL(a0)           ; 0x9B1C
        bne.s   .dead
        move.b  O_TKC1(a0),d0
        cmp.b   #DA_TU_CMD,d0
        beq.s   p1_fire
        cmp.b   #DA_TU_CMD_NONE,d0
        beq.s   .z
        tst.b   O_PT(a3)
        beq.s   .aim
        subq.b  #1,O_PT(a3)
        rts
.aim:   move.b  #DA_TU_AIM_T,O_PT(a3)
        bsr     tu_dir                  ; 0x587D
        cmp.b   #$10,d0
        bcc.s   .r
        lea     da_tu_aim,a1
        move.b  0(a1,d0.w),d0
        move.b  d0,O_TKAIM(a0)
        and.w   #$7F,d0
        lea     da_tu_frames,a1
        move.b  0(a1,d0.w),O_JFR(a3)
.r:     rts
.z:     clr.b   O_TKC1(a0)
        rts
.dead:  move.b  #3,O_PAM(a3)
p1_3:   rts
p1_fire:
        clr.b   O_TKC1(a0)              ; 0x9B7A: a shot
        move.b  #2,O_PAM(a3)
        move.b  #DA_TU_FIRE_T,O_PT(a3)
        moveq   #0,d0
        move.b  O_TKAIM(a0),d0
        and.w   #$7F,d0
        lea     da_tu_frames+2,a1
        move.b  0(a1,d0.w),O_JFR(a3)
        bsr     tk_tushot               ; 0x9D3A
        bsr     tk_casing               ; 0x9D88
p1_2:   tst.b   O_PT(a3)                ; 0x9B9A
        beq     p1_0
        subq.b  #1,O_PT(a3)
        bne.s   .r
        moveq   #0,d0
        move.b  O_TKAIM(a0),d0
        and.w   #$7F,d0
        lea     da_tu_frames,a1
        move.b  0(a1,d0.w),O_JFR(a3)
.r:     rts

tu_dir:                                 ; d0 = the direction from the turret (its PC Engine place) to Hiryu (0x587D)
        bsr     jp_hx
        move.w  d0,d1
        sub.w   O_PPX(a3),d1
        move.w  #2047-DA_HIRYU_DY,d2
        sub.w   HIRYU+$C(a5),d2
        sub.w   O_PPY(a3),d2
        bra     dr_dir_d

; part 3's pop-up (0x9729, O_PPU): on screen with Hiryu DA_PU_NEAR to DA_PU_FAR - 1 px away it asks to rise; raised, it asks
; for its shot; its shot done, it asks to lower; lowered, it waits again
p3_popup:
        moveq   #0,d0
        move.b  O_PPU(a3),d0
        add.w   d0,d0
        move.w  .t(pc,d0.w),d0
        jmp     .t(pc,d0.w)
.t:     dc.w    pu_0-.t,pu_1-.t,pu_2-.t,pu_3-.t,pu_4-.t
pu_0:   move.b  #1,O_PPU(a3)            ; 0x973C
pu_1:   bsr     p3_screen               ; 0x9742
        bcc.s   pu_r
        bsr     jp_hx                   ; 0x57C9: |Hiryu X - its X|, at most 255
        sub.w   O_PPX(a3),d0
        bpl.s   .a
        neg.w   d0
.a:     cmp.w   #255,d0
        bls.s   .b
        move.w  #255,d0
.b:     cmp.w   #DA_PU_FAR,d0
        bcc.s   pu_r
        cmp.w   #DA_PU_NEAR,d0
        bcs.s   pu_r
        move.b  #2,O_PPU(a3)            ; 0x9755
        bset    #3,O_PFL(a3)
pu_2:   btst    #7,O_PFL(a3)            ; 0x9763
        beq.s   pu_r
        move.b  #3,O_PPU(a3)            ; 0x976C
        bset    #1,O_PFL(a3)
        bclr    #5,O_PFL(a3)
pu_3:   btst    #5,O_PFL(a3)            ; 0x977C
        beq.s   pu_r
        move.b  #4,O_PPU(a3)            ; 0x9785
        bset    #2,O_PFL(a3)
pu_4:   btst    #6,O_PFL(a3)            ; 0x9793
        bne.s   pu_0
pu_r:   rts
p3_screen:                              ; carry set when its X - camera X < DA_TU_SCREEN (0x979F)
        bsr     da_pce_cam
        move.w  O_PPX(a3),d1
        sub.w   d0,d1
        cmp.w   #DA_TU_SCREEN,d1
        blt.s   .y
        andi    #$FE,ccr
        rts
.y:     ori     #1,ccr
        rts

; part 3's rise (0x9BC3, O_PRM): asked, up DA_P3_RISE_V a tick to DA_P3_TOP (raised: $80); asked or destroyed (then frame
; DA_P3_DEAD_F), down DA_P3_LOWER_V a tick to 0 (lowered: $40)
p3_rise:
        moveq   #0,d0
        move.b  O_PRM(a3),d0
        add.w   d0,d0
        move.w  .t(pc,d0.w),d0
        jmp     .t(pc,d0.w)
.t:     dc.w    r3_0-.t,r3_1-.t,r3_2-.t,r3_3-.t,r3_4-.t
r3_0:   and.b   #$3F,O_PFL(a3)          ; 0x9BD6
r3_in:  move.b  #1,O_PRM(a3)            ; 0x9BDE
r3_1:   btst    #3,O_TKFL(a0)           ; 0x9BE4
        beq.s   .a
        move.b  #DA_P3_DEAD_F,O_JFR(a3)
        bra.s   r3_down
.a:     bclr    #3,O_PFL(a3)
        bne.s   r3_up
        bclr    #2,O_PFL(a3)
        bne.s   r3_down
        rts
r3_up:  move.b  #2,O_PRM(a3)            ; 0x9C18
        and.b   #$3F,O_PFL(a3)
r3_2:   add.w   #DA_P3_RISE_V,O_PRISE(a3)    ; 0x9C26
        move.b  O_PRISE(a3),d0
        sub.b   #DA_P3_TOP,d0
        bmi.s   .top
        rts
.top:   move.b  #DA_P3_TOP,O_PRISE(a3)
        bset    #7,O_PFL(a3)
        bra.s   r3_in
r3_down:
        move.b  #3,O_PRM(a3)            ; 0x9C4A
        and.b   #$3F,O_PFL(a3)
r3_3:   add.w   #DA_P3_LOWER_V,O_PRISE(a3)   ; 0x9C58
        tst.b   O_PRISE(a3)
        bpl.s   .z
        rts
.z:     clr.b   O_PRISE(a3)
        bset    #6,O_PFL(a3)
        btst    #3,O_TKFL(a0)
        beq.s   r3_in
        move.b  #4,O_PRM(a3)
r3_4:   rts

; part 3's action (0x9C88, O_PAM): asked, DA_P3_FIRE_T ticks, then a bullet (0x9E17) if on screen, unless it was hit (the
; tank's bit 7: then at once, no shot); then its shot is done ($20)
p3_act:
        moveq   #0,d0
        move.b  O_PAM(a3),d0
        add.w   d0,d0
        move.w  .t(pc,d0.w),d0
        jmp     .t(pc,d0.w)
.t:     dc.w    a3_0-.t,a3_1-.t,a3_2-.t,a3_3-.t
a3_0:   and.b   #$CF,O_PFL(a3)          ; 0x9C99
a3_in:  move.b  #1,O_PAM(a3)            ; 0x9CA1
a3_1:   btst    #3,O_TKFL(a0)           ; 0x9CA7
        bne.s   .dead
        bclr    #1,O_PFL(a3)
        bne.s   a3_go
        rts
.dead:  move.b  #3,O_PAM(a3)
a3_3:   rts
a3_go:  move.b  #2,O_PAM(a3)            ; 0x9CC7
        bclr    #5,O_PFL(a3)
        move.b  #DA_P3_FIRE_T,O_PT(a3)
a3_2:   btst    #7,O_TKFL(a0)           ; 0x9CDB: hit: done at once
        bne.s   .done
        tst.b   O_PT(a3)
        beq.s   .f
        subq.b  #1,O_PT(a3)
        rts
.f:     bsr     p3_screen
        bcc.s   .done
        bsr     tk_b3shot               ; 0x9E17
.done:  bset    #5,O_PFL(a3)            ; 0x9CF5
        bra.s   a3_in

p3_col:                                 ; 0x9EB3: slashable while raised and the tank's colflags allow it (0x40)
        moveq   #0,d0
        tst.b   O_PHT(a3)
        bmi.s   .s
        btst    #7,O_PFL(a3)
        beq.s   .s
        btst    #6,O_TKCOLF(a0)
        beq.s   .s
        moveq   #2,d0                   ; (O_COL bit 1: a slash hits it; it never hurts Hiryu)
.s:     move.b  d0,O_COL(a3)
        rts

p3_hits:                                ; 0x9E5B: a tick with a slash counts once (da_collide counts slashes in O_HITS)
        tst.b   O_PHT(a3)
        bmi.s   .r
        tst.b   O_HITS(a3)
        beq.s   .r
        clr.b   O_HITS(a3)
        bset    #7,O_TKFL(a0)
        addq.w  #1,DA_TKHIT
        addq.b  #1,O_PHT(a3)
        cmpi.b  #DA_P3_HITS,O_PHT(a3)
        bcs.s   .r
        st      O_PHT(a3)               ; destroyed: no collision, the tank's bit 3
        clr.b   O_COL(a3)
        bset    #3,O_TKFL(a0)
.r:     rts

; the shots. A bullet (the pilot's kind 1, its velocity set) at the PC Engine place (d3, d4) from a3 (X 1.5x, floored);
; carry set when pool 5 is full
tk_bullet:
        add.w   O_PPX(a3),d3
        add.w   O_PPY(a3),d4
        move.w  d3,d0
        asr.w   #1,d0
        add.w   d0,d3
        neg.w   d4
        add.w   #2047,d4
        moveq   #K_BULLET,d0
        moveq   #0,d1
        moveq   #-1,d2
        movem.l d5-d7/a3,-(sp)
        bsr     da_spawn
        movem.l (sp)+,d5-d7/a3          ; (movem keeps the carry)
        rts

tk_b3shot:                              ; 0x9E17: the hatch soldier's bullet
        moveq   #DA_B3_DX,d3
        moveq   #DA_B3_DY,d4
        bsr.s   tk_bullet
        bcs.s   .r
        move.l  #DA_B3_VX,O_VX(a1)
        move.l  #DA_B3_VY,O_VY(a1)
        addq.w  #1,DA_B3SHOT
.r:     rts

tk_tushot:                              ; 0x9D3A: the turret's bullet by its aim
        moveq   #0,d5
        move.b  O_TKAIM(a0),d5
        and.w   #$7F,d5
        mulu    #12,d5
        lea     da_tu_shot,a2
        move.w  0(a2,d5.w),d3
        move.w  2(a2,d5.w),d4
        bsr.s   tk_bullet
        bcs.s   .r
        lea     da_tu_shot,a2
        move.l  4(a2,d5.w),O_VX(a1)
        move.l  8(a2,d5.w),O_VY(a1)
        addq.w  #1,DA_TUSHOT
.r:     rts

; a shell, casing or mortar shell (kind 27, parameter d6) at the PC Engine place (d3, d4) from a3 with the velocity (d0
; vX, d1 vY: 8.8 px/tick), set up at once: A1, carry set when pool 5 is full
tk_new:
        add.w   O_PPX(a3),d3
        add.w   O_PPY(a3),d4
        movem.l d0-d1/d3-d4/d6/a3,-(sp)
        move.w  d3,d5
        asr.w   #1,d5
        add.w   d5,d3
        neg.w   d4
        add.w   #2047,d4
        moveq   #K_SHELL,d0
        moveq   #0,d1
        moveq   #-1,d2
        bsr     da_spawn
        movem.l (sp)+,d0-d1/d3-d4/d6/a3 ; (movem keeps the carry)
        bcs.s   .r
        exg     a0,a1
        movem.l d0-d1,-(sp)
        moveq   #1,d0                   ; contact hurts (colflags 0x80); a casing: none
        cmp.b   #1,d6
        bne.s   .c
        moveq   #0,d0
.c:     cmp.b   #2,d6                   ; a mortar shell: its contact spends it too (0xA52B: any collision)
        bne.s   .i
        moveq   #5,d0
.i:     bsr     da_init
        movem.l (sp)+,d0-d1
        clr.b   O_TICK(a0)
        clr.b   O_SUB(a0)
        clr.b   O_GONE(a0)
        move.b  d6,O_SHP(a0)
        move.w  d0,O_PVX(a0)
        move.w  d1,O_OVY(a0)
        clr.b   O_JAN(a0)
        st      O_JCUR(a0)
        clr.w   O_JSTEP(a0)
        clr.b   O_FACE(a0)
        moveq   #0,d0
        move.w  d3,d0
        lsl.l   #8,d0
        move.l  d0,O_PX(a0)
        moveq   #0,d0
        move.w  d4,d0
        lsl.l   #8,d0
        move.l  d0,O_PY(a0)
        exg     a0,a1
        andi    #$FE,ccr
.r:     rts

tk_shell:                               ; 0x9D07: the cannon's shell
        moveq   #DA_SH_DX,d3
        moveq   #DA_SH_DY,d4
        move.w  #DA_SH_VX,d0
        moveq   #0,d1
        moveq   #0,d6
        bsr     tk_new
        bcs.s   .r
        addq.w  #1,DA_SHELLS
.r:     rts

tk_mortar:                              ; 0x9DDC: a mortar shell, its index the cannon's
        moveq   #DA_MT_DX,d3
        moveq   #DA_MT_DY,d4
        moveq   #0,d0
        move.w  #DA_MT_VY,d1
        moveq   #2,d6
        bsr     tk_new
        bcs.s   .r
        move.b  O_TKMI(a0),O_SHI(a1)
        addq.w  #1,DA_MORTARS
.r:     rts

tk_casing:                              ; 0x9D88: the turret's casing by its aim
        moveq   #0,d5
        move.b  O_TKAIM(a0),d5
        and.w   #$7F,d5
        lsl.w   #3,d5
        lea     da_cs_tab,a2
        move.w  0(a2,d5.w),d3
        move.w  2(a2,d5.w),d4
        move.w  4(a2,d5.w),d0
        move.w  6(a2,d5.w),d1
        moveq   #1,d6
        bsr     tk_new
        bcs.s   .r
        addq.w  #1,DA_CASINGS
.r:     rts

; the stock explosion at the object + (d3, d4), with any room in pool 6 (not the jeep's reserve: the mortar's bursts
; drain the pool every volley, MEASURED, and the reserve left none of the death's 16 debris in the kill run)
tk_boom:
        jsr     DA_ALLOC6
        bcs.s   .r
        move.w  #$0100,(a1)
        move.b  #1,$17(a1)
        add.w   O_X(a0),d3
        move.w  d3,8(a1)
        add.w   O_Y(a0),d4
        move.w  d4,$C(a1)
        clr.b   $3E(a1)
        addq.w  #1,DA_TKBOOM
.r:     rts

; its parts placed (its X, Y and their places and rises: X 1.5x) and drawn, in list A behind Hiryu, back to front: 3, 2, 0,
; 1 (the PC Engine's lists 7, 6, 6, 5; within a list the earlier part in front)
tk_show:
        move.w  #3,d7
        bsr.s   .one
        move.w  #2,d7
        bsr.s   .one
        move.w  #0,d7
        bsr.s   .one
        move.w  #1,d7
.one:   move.w  d7,d0
        add.w   d0,d0
        add.w   d0,d0
        lea     DA_TKP,a1
        move.l  0(a1,d0.w),d0
        beq.s   .r
        movea.l d0,a3
        moveq   #K_PART,d1
        bsr     tk_mine
        bcc.s   .r
        add.w   d7,d7
        add.w   d7,d7
        lea     da_tk_pxy,a1            ; its X (arcade) and Y (PC Engine) from the tank's
        move.w  0(a1,d7.w),d0
        move.w  2(a1,d7.w),d1
        move.b  O_PRISE(a3),d2
        ext.w   d2
        add.w   d2,d1
        cmpi.b  #3,O_PIX(a3)            ; (the hatch soldier on the cannon: its rise too)
        bne.s   .p
        move.l  DA_TKP+8,d2
        beq.s   .p
        movea.l d2,a1
        move.b  O_PRISE(a1),d2
        ext.w   d2
        add.w   d2,d1
.p:     swap    d0
        clr.w   d0
        add.l   O_X(a0),d0
        move.l  d0,O_X(a3)
        swap    d1
        clr.w   d1
        move.l  O_Y(a0),d0
        sub.l   d1,d0
        move.l  d0,O_Y(a3)
        exg     a0,a3
        moveq   #0,d0
        move.b  O_JFR(a0),d0
        add.b   d0,d0
        bsr     da_anim
        movea.l $1A(a0),a6
        jsr     DA_ANIM_STEP
        jsr     DA_LISTA
        exg     a0,a3
.r:     rts

; Hiryu on its deck (0xA1D7; the stock platforms' way, 0x3C35E), every frame before its own move (on a tick, before its
; tick, as the PC Engine's): on a frame he ran his floor snap ($53 bit 0: on the ground or landing) with his X DA_RD_DX - X
; .. DA_RD_W px into the deck (d: PC Engine X - the tank's + DA_RD_DX) and his feet - Y + DA_RD_DY in [0, DA_RD_H), the
; deck's surface (Y + 8 + its profile at d, 0xA27F) within -DA_RD_TOL .. DA_RD_TOL - 1 of his feet holds him: his feet on
; it, his floor snap skipped on his next frame for the floor kind of that part of the deck ($53 bit 1, $54: the PC Engine's
; slope or flat, RIDE_KINDS); tk_frame then carries him by the frame's integer X step (0xA2B6)
tk_ride:
        clr.b   DA_RIDING
        btst    #0,HIRYU+$53(a5)
        beq     .r
        bsr     jp_hx                   ; d = his PC Engine X - its + DA_RD_DX
        move.l  O_PX(a0),d1
        asr.l   #8,d1
        sub.w   d1,d0
        add.w   #DA_RD_DX,d0
        cmp.w   #DA_RD_W,d0
        bcc     .r
        move.w  #2047+DA_HIRYU_HALF-DA_HIRYU_DY,d2   ; his feet - its Y
        sub.w   HIRYU+$C(a5),d2
        move.l  O_PY(a0),d1
        asr.l   #8,d1
        sub.w   d1,d2
        move.w  d2,d1
        add.w   #DA_RD_DY,d1
        cmp.w   #DA_RD_H,d1
        bcc     .r
        cmp.w   #DA_RD_D1,d0            ; its profile p and the floor kind (0xA27F)
        bcc.s   .p2
        move.w  #2*DA_RD_D1,d1
        sub.w   d0,d1
        moveq   #DA_RD_K1,d3
        bra.s   .s
.p2:    cmp.w   #DA_RD_D2,d0
        bcc.s   .p3
        moveq   #DA_RD_FLAT,d1
        moveq   #DA_RD_K2,d3
        bra.s   .s
.p3:    cmp.w   #DA_RD_D3,d0
        bcc.s   .p4
        move.w  #DA_RD_D3,d1
        sub.w   d0,d1
        moveq   #DA_RD_K3,d3
        bra.s   .s
.p4:    moveq   #0,d1
        moveq   #DA_RD_K4,d3
.s:     addq.w  #8,d1                   ; the surface - his feet: Y + 8 + p - feet
        sub.w   d2,d1
        cmp.w   #-DA_RD_TOL,d1
        blt.s   .r
        cmp.w   #DA_RD_TOL,d1
        bge.s   .r
        sub.w   d1,HIRYU+$C(a5)         ; his feet on it (0x5BC5; Y up)
        bset    #1,HIRYU+$53(a5)        ; as the stock platforms (0x3C3F6)
        bclr    #0,HIRYU+$53(a5)
        bclr    #2,HIRYU+$53(a5)
        move.b  d3,HIRYU+$54(a5)
        st      DA_RIDING
        addq.w  #1,DA_RIDE
.r:     rts

; its death (0x9EED; PC Engine state 3, O_SUB 0 its first tick, then 2 frozen, then 4 sinking with its debris)
tk_die:
        clr.b   DA_RIDING               ; (no ride: 0xA1D7 is in its live tick)
        bchg    #0,O_TICK(a0)
        bne     tk_frame
        movem.l O_PX(a0),d0-d1
        movem.l d0-d1,-(sp)
        moveq   #0,d0
        move.b  O_SUB(a0),d0
        move.w  .t(pc,d0.w),d0
        jmp     .t(pc,d0.w)
.t:     dc.w    td_0-.t,td_1-.t,td_2-.t
td_0:   move.b  #2,O_SUB(a0)            ; 0x9EFE: still, DA_TK_DIE_T ticks
        clr.w   O_JVX(a0)
        clr.w   O_TKVY(a0)
        move.w  #DA_TK_DIE_T,O_T1(a0)
td_1:   tst.w   O_T1(a0)                ; 0x9F19
        beq.s   .n
        subq.w  #1,O_T1(a0)
        bsr     td_move
        bsr     tk_parts
        bsr     tk_flash
        bra     tk_tick
.n:     move.b  #4,O_SUB(a0)            ; 0x9F32: sinking, its debris from the start
        clr.b   O_TKBP(a0)
        clr.b   O_TKBT(a0)
        clr.b   O_TKCOLF(a0)
        move.w  #DA_TK_SINK,O_TKVY(a0)
td_2:   bsr     td_debris               ; 0x9F70
        bcs.s   .end
        bsr     td_move                 ; (0xA0CA's black on alternate ticks is undone by 0xA09B in the same tick: no
        bsr     tk_parts                ; blink shows; MEASURED on the PC Engine)
        bsr     tk_flash
        bra     tk_tick
.end:   bsr     tk_p10                  ; 0x9F88: its colors, 1500 points, its parts and itself go (once status 2)
        move.w  #DA_SCORE_TK,d0
        jsr     DZ_QUEUE
        moveq   #2,d0
        bsr     da_once_set
        addq.w  #1,DA_TKEND
        addq.l  #8,sp
        move.w  #3,d7
.f:     move.w  d7,d0
        add.w   d0,d0
        add.w   d0,d0
        lea     DA_TKP,a1
        movea.l 0(a1,d0.w),a1
        cmpa.w  #0,a1
        beq.s   .g
        moveq   #K_PART,d0
        movem.l d7,-(sp)
        bsr     da_free_part
        movem.l (sp)+,d7
.g:     dbra    d7,.f
        bra     da_free
td_move:                                ; its move (0x5634: Y only)
        move.w  O_JVX(a0),d0
        ext.l   d0
        add.l   d0,O_PX(a0)
        move.w  O_TKVY(a0),d0
        ext.l   d0
        add.l   d0,O_PY(a0)
        rts
td_debris:                              ; 0x9F9E: its debris script (da_tk_dbr), carry set at its end
        tst.b   O_TKBT(a0)
        beq.s   .read
        subq.b  #1,O_TKBT(a0)
        andi    #$FE,ccr
        rts
.read:  moveq   #0,d0
        move.b  O_TKBP(a0),d0
        add.w   d0,d0
        lea     da_tk_dbr,a1
        move.b  0(a1,d0.w),d1
        cmp.b   #$FF,d1
        beq.s   .end
        move.b  d1,O_TKBT(a0)
        moveq   #0,d2
        move.b  1(a1,d0.w),d2
        addq.b  #1,O_TKBP(a0)
        add.w   d2,d2
        lea     da_tk_dbr_xy,a1
        move.b  0(a1,d2.w),d3
        ext.w   d3
        move.b  1(a1,d2.w),d4
        ext.w   d4
        bsr     tk_boom
        bra.s   td_debris
.end:   ori     #1,ccr
        rts

; ---------------------------------------------------------------- its parts
; Kind 26: one of the tank's four parts, which the tank sets up, steps, places and draws; alone it goes
da_part:
        lea     .s(pc),a1
        bra     da_state
.s:     dc.w    da_free-.s,pt_run-.s,da_free-.s,da_free-.s
pt_run: movea.l O_BODY(a0),a1           ; its tank still a living kind-25 actor
        tst.b   (a1)
        beq     da_free
        cmpi.b  #3,$17(a1)
        bne     da_free
        cmpi.b  #K_TANK,O_KIND(a1)
        bne     da_free
        rts

; ---------------------------------------------------------- its shells
; PC Engine actor 0x4B (0x74:0xA2D5) by its parameter (kind 27; O_SHP): 0 the cannon's shell (contact hurts; DA_SH_VX; it
; goes off screen: X - camera X >= DA_SH_RIGHT moving right, < DA_SH_LEFT moving left), 1 a casing (no collision; DA_CS_G a
; tick down; it goes falling DA_CS_FREE below the camera), 2 a mortar shell (contact hurts and bursts it: up at DA_MT_VY
; until DA_MT_TOP above the camera, then Y-flipped at its fixed X, slashable, DA_MT_G a tick down to DA_MT_MAX; it bursts
; within DA_MT_NEAR of its floor, or the tick after a hit, as a stock explosion). Each thinks once a tick in PC Engine terms
; (its 8.8 position and velocity) and moves every frame by half the tick's move; its animation steps through pa_anim on the
; census's scripts (its Y facing XORed in). Drawn in list A (the PC Engine's lists 7 and 4, behind Hiryu's 4).
da_shell:
        lea     .s(pc),a1
        bra     da_state
.s:     dc.w    da_free-.s,sh_run-.s,sh_die-.s,da_free-.s
sh_run:
        bchg    #0,O_TICK(a0)
        bne     sh_frame
        tst.b   O_GONE(a0)
        bne     da_free
        movem.l O_PX(a0),d0-d1
        movem.l d0-d1,-(sp)
        moveq   #0,d0
        move.b  O_SHP(a0),d0
        add.w   d0,d0
        move.w  sh_kinds(pc,d0.w),d0
        jsr     sh_kinds(pc,d0.w)
        move.w  O_PVX(a0),d0            ; the move (0x5634/0x5641)
        ext.l   d0
        add.l   d0,O_PX(a0)
        move.w  O_OVY(a0),d0
        ext.l   d0
        add.l   d0,O_PY(a0)
        lea     da_sh_anims,a1          ; its animation (0x53B4)
        bsr     pa_anim
        bcc.s   .h
        move.b  O_FACE(a0),d2           ; its Y facing (0xA4A0) with the step's
        and.b   #2,d2
        eor.b   d2,d1
        add.b   d0,d0
        btst    #1,d1
        beq.s   .x
        addq.b  #1,d0
.x:     add.b   d0,d0
        and.b   #1,d1
        add.b   d1,d0
        bsr     da_anim
.h:     cmpi.b  #2,O_SHP(a0)            ; a mortar shell: any collision bursts it on its next tick (0xA52B)
        bne.s   .v
        tst.b   O_HITS(a0)
        beq.s   .v
        move.b  #4,O_ST(a0)
.v:     movem.l (sp)+,d0-d1
        bsr     da_pce_vel
sh_frame:
        bsr     da_move
        movea.l $1A(a0),a6
        jsr     DA_ANIM_STEP
        jmp     DA_LISTA
sh_kinds:
        dc.w    sh_shell-sh_kinds,sh_casing-sh_kinds,sh_mortar-sh_kinds

sh_die:                                 ; its burst (0xA5B7): on its next tick, unseen, then it goes
        bchg    #0,O_TICK(a0)
        bne.s   .r
        moveq   #0,d3
        moveq   #0,d4
        bsr     tk_boom
        bra     da_free
.r:     rts

sh_xy:                                  ; d0.w = its PC Engine X - the camera's, d1.w = its Y - the camera's
        bsr     da_pce_cam
        move.w  d0,d2
        move.w  d1,d3
        move.l  O_PX(a0),d0
        asr.l   #8,d0
        sub.w   d2,d0
        move.l  O_PY(a0),d1
        asr.l   #8,d1
        sub.w   d3,d1
        rts

sh_shell:                               ; 0xA326
        tst.b   O_SUB(a0)
        bne.s   .a
        move.b  #2,O_SUB(a0)            ; animation 0
        clr.b   O_JAN(a0)
.a:     bsr.s   sh_xy
        tst.w   O_PVX(a0)
        bmi.s   .l
        cmp.w   #DA_SH_RIGHT,d0
        bge.s   sh_gone
        rts
.l:     cmp.w   #DA_SH_LEFT,d0
        blt.s   sh_gone
        rts
sh_gone:
        st      O_GONE(a0)              ; freed on its next tick (its state 2)
        rts

sh_casing:                              ; 0xA3B9
        tst.b   O_SUB(a0)
        bne.s   .a
        move.b  #2,O_SUB(a0)
        move.b  #DA_CS_A,O_JAN(a0)
.a:     bsr.s   sh_xy
        add.w   #DA_CS_G,O_OVY(a0)
        bmi.s   .r
        cmp.w   #DA_CS_FREE,d1
        bge.s   sh_gone
.r:     rts

sh_mortar:                              ; 0xA457
        moveq   #0,d0
        move.b  O_SUB(a0),d0
        move.w  .t(pc,d0.w),d0
        jmp     .t(pc,d0.w)
.t:     dc.w    mt_0-.t,mt_1-.t,mt_2-.t
mt_0:   move.b  #2,O_SUB(a0)            ; 0xA466
        move.b  #DA_MT_A,O_JAN(a0)
mt_1:   bsr     sh_xy                   ; 0xA472: up until DA_MT_TOP above the camera
        cmp.w   #DA_MT_TOP,d1
        blt.s   .t2
        rts
.t2:    move.b  #4,O_SUB(a0)            ; 0xA494: slashable, Y-flipped, at its fixed X
        move.b  #7,O_COL(a0)
        bset    #1,O_FACE(a0)
        moveq   #0,d0
        move.b  O_SHI(a0),d0
        add.w   d0,d0
        add.w   d0,d0
        lea     da_mt_tab,a1
        moveq   #0,d1
        move.w  0(a1,d0.w),d1
        move.b  O_PX+3(a0),d2           ; (its fraction kept)
        lsl.l   #8,d1
        move.b  d2,d1
        move.l  d1,O_PX(a0)
mt_2:   moveq   #0,d0                   ; 0xA4BA: within DA_MT_NEAR of its floor: it bursts
        move.b  O_SHI(a0),d0
        add.w   d0,d0
        add.w   d0,d0
        lea     da_mt_tab+2,a1
        move.w  0(a1,d0.w),d0
        move.l  O_PY(a0),d1
        asr.l   #8,d1
        sub.w   d1,d0
        cmp.w   #DA_MT_NEAR,d0
        bge.s   .fall
        moveq   #0,d3
        moveq   #0,d4
        bsr     tk_boom
        bra     sh_gone
.fall:  bsr     sh_xy                   ; 0xA4CE
        move.w  O_OVY(a0),d0
        add.w   #DA_MT_G,d0
        cmp.w   #DA_MT_MAX,d0
        blt.s   .v
        move.w  #DA_MT_MAX,d0
.v:     move.w  d0,O_OVY(a0)
        cmp.w   #DA_MT_FREE,d1
        bge     sh_gone
        rts

; ---------------------------------------------------------- the capsules
; A stock item capsule (pool 7 type 0x1A, through the stock spawn 0x2DAA; its own code draws it, opens it
; on a slash and gives its item on a touch) of kind d0. A1, carry set when pool 7 is full.
; da_capsule: placed (variant 0) at (d3, d4): unseen until it comes on screen, then floating there; off
; screen again it frees itself while the area byte is d2.
; da_carried: carried (variant 2) by a3 at (d3, d4) from it: it follows a3 until a3's state is 4 or more,
; then falls onto the floor (the stock floor snap) and waits there; it frees itself when the area byte
; changes.
da_capsule:
        lea     DA_CREC,a2
        move.b  #$1A,(a2)
        clr.b   1(a2)                   ; $06: variant 0
        move.b  d0,2(a2)                ; $16: its kind
        move.b  d2,3(a2)                ; $21: the area that frees it off screen
        move.w  d3,4(a2)
        move.w  d4,6(a2)
        bra.s   da_cap_fill
da_carried:
        lea     DA_CREC,a2
        move.b  #$1A,(a2)
        move.b  #2,1(a2)                ; $06: variant 2
        move.b  d0,2(a2)                ; $16 (variant 2 reads $3C)
        st      3(a2)                   ; $21
        clr.l   4(a2)                   ; $08, $0C: from its carrier at its first update
        bsr.s   da_cap_fill
        bcs.s   .r
        move.b  d0,$3C(a1)
        move.l  a3,$38(a1)
        move.w  d3,$3E(a1)
        move.w  d4,$40(a1)              ; (clears the carry)
.r:     rts
da_cap_fill:
        movem.l d0/a0/a3-a4,-(sp)
        jsr     DA_FILL7
        movem.l (sp)+,d0/a0/a3-a4
        bcs.s   .full
        addq.w  #1,DA_CAPS
        andi    #$FE,ccr
        rts
.full:  addq.w  #1,DA_CAPFULL
        ori     #1,ccr
        rts

; ================================================== from the stage handler
; da_setup: from dz_setup (a new stage or a respawn: the pools were rebuilt):
; every once id free, the map list scanned afresh, the actors' section.
da_setup:
        lea     DA_ONCE,a1
        moveq   #128/4-1,d0
.c:     clr.l   (a1)+
        dbra    d0,.c
        clr.w   DA_SCAN
        clr.w   DA_RANKT                ; the PC Engine resets its rank at a stage start and a lost life
        move.w  DZ_SEC,DA_SEC
        clr.w   DA_PANF                 ; no pan (DA_PANF, DA_PANON), delay or open pit; the bounds as the restart
        clr.w   DA_DLY                  ; record left them
        clr.w   DA_PIT
        clr.w   DA_HULLON               ; no hull, no ride (the respawn cleared the SCROLL2 map)
        lea     DA_LIM,a1
        move.w  -$6FE8(a5),(a1)+        ; X min
        move.w  -$6FEA(a5),(a1)+        ; X max
        move.w  -$6FE4(a5),(a1)+        ; Y min
        move.w  -$6FE6(a5),(a1)+        ; Y max
        rts

; da_spawn_list: a1 = list (count.w, then 8-byte records): spawn them all
; (dz_sections op 9, the section scripts' placements). Keeps d1, a1-a2.
da_spawn_list:
        movem.l d1/d7/a1-a2,-(sp)
        move.w  (a1)+,d7
        bra.s   .t
.l:     move.l  a1,a2
        movem.l d7/a1,-(sp)
        jsr     DA_FILL5
        movem.l (sp)+,d7/a1
        addq.l  #8,a1
.t:     dbra    d7,.l
        movem.l (sp)+,d1/d7/a1-a2
        rts

; da_frame: every frame of desert play, after the actors' update (dz_stage)
da_frame:
        addq.w  #1,DA_RANKT             ; frames of play since the setup, held at 0xFFFF
        bne.s   .rk
        subq.w  #1,DA_RANKT
.rk:    move.w  DZ_SEC,d0
        cmp.w   DA_SEC,d0
        beq.s   .same
        move.w  d0,DA_SEC
        bsr     da_leave
.same:  bsr     da_maplist
        bsr     da_collide
        bra     da_pan

; the officer's subs 2-4 aim the PC Engine's camera at it (0x85BD): while they do, the arcade camera's Y follows the PC
; Engine's rule (0x71EF, in PC Engine terms: the target less an offset kept within DA_PAN_LO .. DA_PAN_HI, within the
; section's bounds, at most DA_PAN_STEP a frame: its 16 px a tick), its Y bounds pinned where it is so that the stock
; camera holds it there; then the section's bounds come back (DA_LIM) and the stock camera goes back to Hiryu. (Its X
; is pinned by the section's own bounds.)
da_pan:
        tst.b   DA_PANF
        bne.s   .on
        tst.b   DA_PANON
        beq.s   .r
        clr.b   DA_PANON
        lea     DA_LIM,a1
        move.w  (a1)+,-$6FE8(a5)        ; X min
        move.w  (a1)+,-$6FEA(a5)        ; X max
        move.w  (a1)+,-$6FE4(a5)        ; Y min
        move.w  (a1)+,-$6FE6(a5)        ; Y max
.r:     rts
.on:    st      DA_PANON
        move.w  #DA_CAM_TOP,d0
        sub.w   CAMY(a5),d0             ; the camera's PC Engine Y (its picture's top)
        move.w  DA_PANT,d1
        move.w  d1,d2
        sub.w   d0,d2                   ; the target's offset in it, kept within the band
        cmp.w   #DA_PAN_LO,d2
        bge.s   .a
        move.w  #DA_PAN_LO,d2
.a:     cmp.w   #DA_PAN_HI,d2
        ble.s   .b
        move.w  #DA_PAN_HI,d2
.b:     sub.w   d2,d1                   ; the camera it wants, within the section's bounds (the layer's Y max is the least
        move.w  #DA_CAM_TOP,d2          ; PC Engine Y)
        sub.w   DA_LIM+6,d2
        cmp.w   d2,d1
        bge.s   .c
        move.w  d2,d1
.c:     move.w  #DA_CAM_TOP,d2
        sub.w   DA_LIM+4,d2
        cmp.w   d2,d1
        ble.s   .d
        move.w  d2,d1
.d:     sub.w   d0,d1                   ; the step
        cmp.w   #DA_PAN_STEP,d1
        ble.s   .e
        move.w  #DA_PAN_STEP,d1
.e:     cmp.w   #-DA_PAN_STEP,d1
        bge.s   .f
        move.w  #-DA_PAN_STEP,d1
.f:     move.w  CAMY(a5),d0             ; (layer Y up)
        sub.w   d1,d0
        move.w  HIRYU+$C(a5),d1         ; but Hiryu kept inside his own on-screen box (the stock player ends a life
        sub.w   #DA_PAN_HMAX,d1         ; outside it, 0x10C4A: the PC Engine lets the camera leave him)
        cmp.w   d1,d0
        bge.s   .g
        move.w  d1,d0
.g:     add.w   #DA_PAN_HMAX-DA_PAN_HMIN,d1
        cmp.w   d1,d0
        ble.s   .h
        move.w  d1,d0
.h:     move.w  d0,CAMY(a5)
        clr.w   CAMY+2(a5)
        move.w  d0,DA_S3Y               ; the SCROLL3 shadow the layer code leaves (0xFF0C3E) with it
        move.w  d0,-$6FE4(a5)           ; Y min and max pinned there
        move.w  d0,-$6FE6(a5)
        rts

; a new section: the actors its PC Engine sprite set does not allow go
; (PC Engine state 2: a soldier's id is spent)
da_leave:
        lea     POOL5,a0
        moveq   #30-1,d7
.l:     tst.b   (a0)
        beq.s   .n
        cmpi.b  #3,$17(a0)
        bne.s   .n
        moveq   #0,d0
        move.b  O_KIND(a0),d0
        lea     da_allow,a1
        move.b  0(a1,d0.w),d0
        move.w  DA_SEC,d1
        btst    d1,d0
        bne.s   .n
        move.b  #6,O_ST(a0)
        moveq   #2,d0
        bsr     da_once_set
.n:     lea     $50(a0),a0
        dbra    d7,.l
        rts

; the section's map list (PC Engine 0x69:0x77BA): an actor whose id is free
; spawns when it enters the window 320 px left / 576 px right and 160 px above /
; 192 px below the screen (PC Engine px), but not inside the screen and 64 px
; around it, except on the first scan after a setup
da_maplist:
        move.w  DZ_SEC,d0
        add.w   d0,d0
        add.w   d0,d0
        lea     da_maplists,a1
        movea.l 0(a1,d0.w),a1
        move.w  (a1)+,d7
        bra     .t
.l:     moveq   #0,d6
        move.b  3(a1),d6
        lea     DA_ONCE,a2
        tst.b   0(a2,d6.w)
        bne     .n
        move.w  4(a1),d0
        move.w  6(a1),d1
        move.w  #-480,d2
        move.w  #864,d3
        move.w  #-175,d4
        move.w  #400,d5
        bsr     da_window_xy
        bcc     .n
        tst.w   DA_SCAN
        beq.s   .sp
        move.w  4(a1),d0
        move.w  6(a1),d1
        move.w  #-96,d2
        move.w  #480,d3
        move.w  #-79,d4
        move.w  #304,d5
        bsr     da_window_xy
        bcs     .n
.sp:    cmpi.b  #K_ITEM,1(a1)           ; a container: a stock capsule (da_capsule)
        beq.s   .item
        cmpi.b  #K_MINE,1(a1)           ; a mine only inside the window it keeps itself in (mn_keep):
        bne.s   .fill                   ; the PC Engine frees one outside it on its first tick, unseen
        move.w  4(a1),d0
        sub.w   CAMX(a5),d0
        cmp.w   #DA_MN_RIGHT,d0
        bge     .n
        cmp.w   #DA_MN_LEFT,d0
        blt     .n
.fill:  move.l  a1,a2
        movem.l d6-d7/a1,-(sp)
        jsr     DA_FILL5
        movem.l (sp)+,d6-d7/a1
        bcs     .n
        lea     DA_ONCE,a2
        move.b  #1,0(a2,d6.w)
.n:     addq.l  #8,a1
.t:     dbra    d7,.l
        move.w  #1,DA_SCAN
        rts
.item:  movem.l d6-d7/a1,-(sp)          ; placed where the PC Engine's container comes to rest
        moveq   #0,d0                   ; (desert_actors_ex.container_rests); the kind is the record's third
        move.b  2(a1),d0                ; byte. Freed off screen in the next section (whose area byte is
        move.w  DZ_SEC,d2               ; the section + 2), as the PC Engine frees it at a section change
        addq.w  #2,d2
        move.w  4(a1),d3
        move.w  6(a1),d4
        bsr     da_capsule
        movem.l (sp)+,d6-d7/a1
        bcs     .n
        lea     DA_ONCE,a2              ; spent: the capsule stays until it is taken or freed in the next
        move.b  #2,0(a2,d6.w)           ; section, and a setup (a new life) brings it back
        bra     .n

; the actors' collision pass (the stock pass 0x75DE's gates and tests; the
; stock pass then skips them: $7 bit 7)
da_collide:
        cmpi.w  #30,POOL5_FREE(a5)      ; pool 5 empty (no actor: in the desert it holds only these)
        beq     .r
        lea     HIRYU(a5),a0
        tst.w   INVULN(a5)              ; contact: Hiryu not invulnerable,
        bne.s   .slash
        tst.w   HOLDC(a5)
        bne.s   .slash
        btst    #7,7(a0)                ; tangible,
        bne.s   .slash
        cmpi.b  #1,(a0)                 ; active and in a normal state,
        bne.s   .slash
        cmpi.b  #2,2(a0)
        bne.s   .slash
        btst    #0,FRAMEC(a5)           ; on odd frames
        beq.s   .slash
        lea     POOL5,a3
        moveq   #30-1,d7
.h:     moveq   #0,d6                   ; bit 0: hurts Hiryu
        bsr     da_target
        bne.s   .hn
        movem.l d7/a3,-(sp)
        jsr     DA_HIT_HIRYU            ; 0x82D0: a0 Hiryu, a3 the actor; carry set = overlap
        movem.l (sp)+,d7/a3
        bcs.s   .hurt
.hn:    lea     $50(a3),a3
        dbra    d7,.h
        bra.s   .slash
.hurt:  addq.b  #1,$1E(a0)              ; the stock hurt response (0x84C0): Hiryu's handler takes a bar
        move.b  #$80,7(a0)              ; and starts his invulnerability
        addq.w  #1,DA_HURT
        moveq   #0,d0
        move.b  O_KIND(a3),d0
        lea     DA_KHURT,a1
        addq.b  #1,0(a1,d0.w)
        btst    #2,O_COL(a3)            ; spent by the contact (the grenade: 0x74:0xAAF0 takes any hit)
        beq.s   .slash
        addq.b  #1,O_HITS(a3)
.slash: movea.l LIST_P(a5),a4           ; each of Hiryu's attacks not yet spent
        move.w  LIST_PN(a5),d6
        bra.s   .pt
.p:     movea.l (a4)+,a0
        tst.b   $33(a0)
        bne.s   .pt
        btst    #7,7(a0)
        bne.s   .pt
        cmpi.b  #1,(a0)
        bne.s   .pt
        cmpi.b  #2,2(a0)
        bne.s   .pt
        lea     POOL5,a3
        moveq   #30-1,d7
.c:     movem.l d6,-(sp)
        moveq   #1,d6                   ; bit 1: a slash hits it
        bsr     da_target
        movem.l (sp)+,d6
        bne.s   .cn
        movem.l d6-d7/a3-a4,-(sp)
        jsr     DA_HIT_ATTACK           ; 0x8216: a0 the attack, a3 the actor
        movem.l (sp)+,d6-d7/a3-a4
        bcs.s   .cut
.cn:    lea     $50(a3),a3
        dbra    d7,.c
.pt:    dbra    d6,.p
.r:     rts
.cut:   move.b  $30(a0),O_KB(a3)        ; as the stock slash (0x89FA): a hit, the attack spent, a spark
        addq.b  #1,O_HITS(a3)
        move.b  #1,$33(a0)
        addq.w  #1,DA_CUTS
        moveq   #0,d0
        move.b  O_KIND(a3),d0
        lea     DA_KCUT,a1
        addq.b  #1,0(a1,d0.w)
        movem.l d6/a4,-(sp)
        jsr     DA_SPARK                ; 0x8A16 (a0 = the attack)
        movem.l (sp)+,d6/a4
        bra.s   .pt

; Z set when a3 is a desert actor, active, running, on screen, with bit d6 of O_COL
da_target:
        cmpi.b  #1,(a3)
        bne.s   .r
        cmpi.b  #3,$17(a3)
        bne.s   .r
        cmpi.b  #2,O_ST(a3)
        bne.s   .r
        tst.b   O_SCR(a3)
        beq.s   .no
        btst    d6,O_COL(a3)
        beq.s   .no
        cmp.w   d0,d0                   ; Z set
.r:     rts
.no:    moveq   #1,d0                   ; Z clear
        rts

        even
        include "desert_actors.inc"
        even
