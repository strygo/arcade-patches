"""Separate the restored pole landing from an ID still used for empty space."""
import argparse
from copy import deepcopy
import json
from pathlib import Path
import struct
import sys
import desert_ex as D
import desert_slopes as S
import respawn_fix as R
from boss_voice_gate import inventory, sha
ALIAS = 1510
POLES = (5616, 5808, 6000, 6192, 6384)

def cells(image, bank, stage, index=0):
    rd = S.reader(image, bank)
    lr = S.layer_record(image, stage, index)
    grid, secs = (S.be32(rd(lr + 2, 4)), S.be32(rd(lr + 6, 4)))
    grid = rd(grid, 256)
    for gy in range(8):
        for gx in range(32):
            sec = secs + 384 * grid[gy * 32 + gx]
            for sr in range(8):
                for sc in range(12):
                    at = sec + 4 * (sr * 12 + sc)
                    yield ((gx * 12 + sc, gy * 8 + sr), at, rd(at, 4))

def unused_code(used, profiles):
    return next((c for c in range(1535, 1280, -1) if c not in used and profiles(c) == (0, 0, 0, 0)))

def patch(files, machine, source):
    image = R.compose(files, R.SETS[machine])
    raw = files['strex_p6.bin']
    bank = bytearray((raw[i ^ 1] for i in range(len(raw))))
    rd = S.reader(image, bank)
    floor = source['pole_floor']
    at, size = (floor['allocation_start'], floor['allocation_size'])
    if sha(rd(at, size)) != floor['allocation_sha256'] or floor['new_classes'] != 2:
        raise ValueError('supported historical pole-floor allocation required')
    tables = {}
    for key, (pg, ty, fp, flags, recs) in D.collision_sets(image).items():
        page = rd(pg + D.DZ_SLOT)[0]
        if not page or rd(fp + D.DZ_SLOT)[0]:
            raise ValueError('reserved collision page or flags differ')
        tables[key] = ty + (page - 1) * 256
    profiles = lambda code: tuple((rd(tables[k] + (code & 255))[0] for k in 'ABCD'))
    old_profile = profiles(ALIAS)
    if old_profile[0] or old_profile[2] or old_profile[1] < 32 or (old_profile[3] != 29):
        raise ValueError('historical aliased floor/wall profile differs')
    recs = D.collision_sets(image)['B'][4]
    if rd(recs + (old_profile[1] - 32) * 33, 33) != bytes([1, 31, 31] + [0] * 30):
        raise ValueError('two-column pole landing profile differs')
    used, aliases = (set(), [])
    for stage, index in [(s, 0) for s in range(5)] + [(5, i) for i in range(7)]:
        for position, address, entry in cells(image, bank, stage, index):
            code = S.be16(entry) & 16383
            used.add(code)
            if code == ALIAS:
                if stage != 5 or index != 1 or entry[3] >> 5 & 3 != 3:
                    raise ValueError('aliased class appears outside supported map-1 cells')
                aliases.append((position, address, entry))
    intended = {((left + 18) // 32, 49) for left in POLES}
    empty = {(left // 32, row) for left in POLES for row in (48, 50)}
    if {p for p, _, _ in aliases} != intended | empty:
        raise ValueError('historical landing/empty references differ')
    replacement = unused_code(used, profiles)
    changes = []

    def write(address, data):
        offset = address - 1048576
        before = bytes(bank[offset:offset + len(data)])
        if before == data:
            return
        changes.append(dict(address=address, before=before.hex(), after=data.hex()))
        bank[offset:offset + len(data)] = data
    for k, value in zip('ABCD', old_profile):
        write(tables[k] + (replacement & 255), bytes([value]))
        write(tables[k] + (ALIAS & 255), b'\x00')
    for position, address, entry in aliases:
        if position in intended:
            write(address, struct.pack('>H', S.be16(entry) & 49152 | replacement))
    result = dict(files, **{'strex_p6.bin': bytes((bank[i ^ 1] for i in range(len(bank))))})
    return (result, dict(changes=changes, old_empty_id=ALIAS, new_landing_id=replacement, intentional_landing_cells=[list(p) for p in sorted(intended)], restored_empty_cells=[list(p) for p in sorted(empty)], reserved_against_original_and_desert_maps=12, executable_art_audio_and_surface_records_unchanged=True))

def audit(control, build):
    cm, old = inventory(control)
    meta, new = inventory(build)
    if old.keys() != new.keys():
        raise ValueError('regional set inventory differs')
    for machine, files in old.items():
        expected, spec = patch(files, machine, cm['sets'][machine])
        declared = meta['sets'][machine]['desert_pole_alias']
        if expected != new[machine] or declared['change'] != spec:
            raise ValueError('unexpected pole alias ROM change')
        if declared['source_files'] != cm['sets'][machine]['files']:
            raise ValueError('pole alias source inventory differs')
    return meta

def main():
    if sys.argv[1:] == ['--self-test']:
        assert unused_code({1535, 1534}, lambda c: (0, 0, 0, 0)) == 1533
        assert unused_code({1535}, lambda c: (0, 1, 0, 0) if c == 1534 else (0, 0, 0, 0)) == 1533
        print('Pole allocation guards PASS: referenced empty and occupied IDs excluded')
        return
    p = argparse.ArgumentParser(description=__doc__)
    for name in ('build', 'out'):
        p.add_argument('--' + name, type=Path, required=True)
    a = p.parse_args()
    meta, old = inventory(a.build)
    rep = deepcopy(meta)
    a.out.mkdir(parents=True, exist_ok=False)
    for machine, files in old.items():
        result, spec = patch(files, machine, meta['sets'][machine])
        dest = a.out / machine
        dest.mkdir()
        for name, data in result.items():
            (dest / name).write_bytes(data)
        rep['sets'][machine]['desert_pole_alias'] = dict(change=spec, source_files=meta['sets'][machine]['files'], producer_sha256=sha(Path(__file__).read_bytes()))
        rep['sets'][machine]['files'] = {n: sha(b) for n, b in result.items()}
    (a.out / 'build.json').write_text(json.dumps(rep, indent=2) + '\n')
    audit(a.build, a.out)
    print('Pole landing isolated; ten empty cells restored in each region')
if __name__ == '__main__':
    main()
