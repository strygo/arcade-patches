"""Strider EX sound gate: the PC Engine effects on 0xB0-0xB3 (pce_sfx.py), and nothing else changed."""
import argparse
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path
import numpy as np
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import oki_adpcm as OKI
import pce_sfx as PS
ROOT = HERE.parents[2]
LUA = ROOT / 'backports/striderex/lua/sfx_gate.lua'
HBSET = HERE / 'hbmame_set.py'
PARENT = {'striderus01': 'striderua', 'striderjs01': 'striderjr'}
SR = 48000
PARK = 1000
CENSUS_SLOT = 4.0
NEW_SLOT = 3.0
LEVEL_SLOT = 8.5
LEVEL_TOL = 0.05
SPREAD_TOL = 1.0
MIN_DECODE_CORR = 0.98
TIME_TOL = 0.0001
MIN_PCE_CORR = 0.9
PACK_FLAG = 1
FLAG_AT = 1048574

def census_cmds():
    new = {int(e['command'], 16) for e in PS.manifest()['effects']}
    return [c for c in range(255) if c not in new]

def new_cmds():
    return [int(e['command'], 16) for e in PS.manifest()['effects']]

def run(binary, rompath, machine, out, cmds, slot, extra=()):
    out.mkdir(parents=True, exist_ok=False)
    env = dict(os.environ, SDL_VIDEODRIVER='dummy', SDL_AUDIODRIVER='dummy', SFX_LOG=str(out / 'sfx.tsv'), SFX_CMDS=','.join((f'{c:02x}' for c in cmds)), SFX_SLOT=str(slot), SFX_PARK=str(PARK))
    seconds = int(PARK / 59.6 + 2 + len(cmds) * slot + 10)
    cmd = [str(binary), machine, '-rompath', str(rompath), '-nothrottle', '-video', 'none', '-sound', 'none', '-wavwrite', str(out / 'mix.wav'), '-seconds_to_run', str(seconds), '-skip_gameinfo', '-noautosave', '-cfg_directory', str(out / 'cfg'), '-nvram_directory', str(out / 'nv'), '-snapshot_directory', str(out), '-autoboot_script', str(LUA), *extra]
    p = subprocess.run(cmd, env=env, cwd=out, capture_output=True, text=True, timeout=3600)
    (out / 'mame.log').write_text(p.stdout + p.stderr)
    if p.returncode:
        raise SystemExit(f'{out}: MAME exit {p.returncode}')
    return parse(out, cmds)

def parse(out, cmds):
    """{'slots': [(cmd, t0)], 'ym': [(t, reg, val)], 'oki': [(t, val)], 'mix': mono float array}."""
    lines = (out / 'sfx.tsv').read_text().splitlines()
    if not lines or lines[-1] != 'done':
        raise SystemExit(f'{out}: the run did not finish its slots')
    slots, ym, oki = ([], [], [])
    for line in lines[:-1]:
        f = line.split('\t')
        t = float(f[0])
        if f[1] == 'cmd':
            slots.append((int(f[2], 16), t))
        elif f[1] == 'ym':
            ym.append((t, int(f[2], 16), int(f[3], 16)))
        else:
            oki.append((t, int(f[2], 16)))
    if [c for c, _ in slots[1:]] != list(cmds) or slots[0][0] != 240:
        raise SystemExit(f'{out}: the slots sent {len(slots) - 1} commands, not the {len(cmds)} asked')
    x = PS.read_wav(out / 'mix.wav').astype(float)
    return dict(slots=slots[1:], ym=ym, oki=oki, mix=x.mean(1), raw=x)

def window(r, k, slot):
    t0 = r['slots'][k][1]
    a, b = (int(round(t0 * SR)), int(round((t0 + slot) * SR)))
    return (a, b)

def events_in(ev, t0, t1):
    return [e for e in ev if t0 <= e[0] < t1]

def stock_sound(rom_dir):
    """The stock sound program and the 256 KB sample ROM (striderua's members; striderjr's are identical)."""
    d = rom_dir / 'striderua'
    z = (d / '09.12b').read_bytes()
    o = b''.join(((d / n).read_bytes() for n in PS.SAMPLE_MEMBERS['striderua']))
    return (z, o)

def headers(oki, n=128):
    return [(int.from_bytes(oki[8 * p:8 * p + 3], 'big') & 262143, int.from_bytes(oki[8 * p + 3:8 * p + 6], 'big') & 262143) for p in range(n)]

def levels(a):
    """BOMB 3's loudness and the full-scale OKI level in stock MAME's mix (striderua)."""
    work = a.workdir.resolve()
    work.mkdir(parents=True, exist_ok=False)
    z, oki = stock_sound(a.rom_dir.resolve())
    table = z[PS.Z80_STOCK_TABLE:PS.Z80_STOCK_TABLE + PS.STOCK_PHRASES]
    anchor = int(PS.manifest()['anchor']['arcade_command'], 16)
    phrases = list(range(1, PS.STOCK_PHRASES))
    cmds = [anchor] + [128 | p for p in phrases]
    r = run(a.mame, a.rom_dir.resolve(), 'striderua', work / 'run', cmds, LEVEL_SLOT)
    a0, b0 = window(r, 0, LEVEL_SLOT)
    bomb = PS.loudness_db(r['mix'][a0:b0], SR)
    hdr = headers(oki)
    fs = []
    for k, p in enumerate(phrases, 1):
        s, e = hdr[p]
        dec = OKI.decode_phrase(oki, s, e).astype(float)
        a1, b1 = window(r, k, LEVEL_SLOT)
        vol = table[p] & 15
        mix_db, dec_db = (PS.loudness_db(r['mix'][a1:b1], SR), PS.loudness_db(dec, PS.OKI_RATE, 2048.0))
        fs.append(dict(phrase=p, mix_db=round(mix_db, 3), decode_db=round(dec_db, 3), volume=vol, full_scale_db=round(mix_db - dec_db - OKI.volume_db(vol), 3)))
    vals = np.array([f['full_scale_db'] for f in fs])
    rep = dict(bomb3_db=round(bomb, 3), oki_full_scale_db=round(float(np.median(vals)), 3), spread_db=round(float(vals.max() - vals.min()), 3), phrases=fs)
    (work / 'levels.json').write_text(json.dumps(rep, indent=1) + '\n')
    pin = PS.manifest().get('levels', {})
    errors = []
    if rep['spread_db'] > SPREAD_TOL:
        errors.append(f"the phrases' full-scale levels spread {rep['spread_db']} dB")
    for k in ('bomb3_db', 'oki_full_scale_db'):
        if k not in pin or abs(pin[k] - rep[k]) > LEVEL_TOL:
            errors.append(f'{k}: measured {rep[k]}, manifest {pin.get(k)}')
    print(json.dumps({k: v for k, v in rep.items() if k != 'phrases'}, indent=1))
    for e in errors:
        print('FAIL', e)
    print('levels', 'FAIL' if errors else 'PASS')
    return 1 if errors else 0

def best_corr(a, b, max_lag):
    """The largest normalized correlation of a and b over lags of b within +-max_lag samples, and that lag."""
    from scipy.signal import correlate
    n = max(len(a), len(b))
    a = np.pad(np.asarray(a, float), (0, n - len(a)))
    b = np.pad(np.asarray(b, float), (0, n - len(b)))
    c = correlate(a, b, 'full', method='fft')
    lags = np.arange(-n + 1, n)
    sel = np.abs(lags) <= max_lag
    k = int(np.argmax(c[sel]))
    den = np.sqrt((a * a).sum() * (b * b).sum())
    return (float(c[sel][k] / den) if den else 0.0, int(lags[sel][k]))

def resolve_oki(ev, rom):
    """OKI writes [(t, kind, value)] with each phrase select (0x80 | n) replaced by the phrase's header bytes (start,"""
    out, pending = ([], False)
    for t, v in ev:
        if pending:
            out.append((t, 'start', v))
            pending = False
        elif v & 128:
            p = v & 127
            out.append((t, 'phrase', bytes(rom[8 * p:8 * p + 6]).hex()))
            pending = True
        else:
            out.append((t, 'stop', v))
    return out

def lowpass(y, hz=3000.0):
    from scipy.signal import butter, sosfiltfilt
    return sosfiltfilt(butter(4, hz, fs=SR, output='sos'), np.asarray(y, float)) if len(y) > 30 else np.asarray(y, float)

def undo_install(z):
    """The sound program before pce_sfx.install: the operand, the count and the table space put back."""
    z = bytearray(z)
    z[PS.Z80_TABLE:PS.Z80_TABLE + 128] = b'\xff' * 128
    z[PS.Z80_TABLE_OP:PS.Z80_TABLE_OP + 2] = PS.Z80_STOCK_TABLE.to_bytes(2, 'little')
    z[PS.Z80_COUNT] = PS.STOCK_PHRASES - 1
    return bytes(z)

def stage(a, work, tag, files, flag):
    """A release set (hbmame_set.py) of the build's members `files`, the flag byte set to `flag`."""
    machine = PARENT[a.set]
    src = work / f'ex_{tag}' / machine
    src.mkdir(parents=True)
    for n, b in files.items():
        if n == 'strex_p6.bin' and flag:
            b = bytearray(b)
            b[FLAG_AT] |= flag
            b = bytes(b)
        (src / n).write_bytes(b)
    sets = work / f'set_{tag}'
    subprocess.run([sys.executable, str(HBSET), 'build', '--hbmame', str(a.hbmame), '--rom-dir', str(a.rom_dir.resolve()), '--ex-dir', str(src.parent), '--set', a.set, '--date', '2026-10-10', '--out', str(sets)], check=True, stdout=subprocess.DEVNULL)
    return sets

def census(a):
    import build_ex as BX
    work = a.workdir.resolve()
    work.mkdir(parents=True, exist_ok=False)
    build = a.build.resolve()
    machine = PARENT[a.set]
    bj = json.loads((build / 'build.json').read_text())
    if 'pce_sfx' not in bj:
        raise SystemExit(f'{build}: not built with --pce-sfx')
    binary = json.loads((a.runtime / 'runtime.json').read_text())['binary']
    files = {q.name: q.read_bytes() for q in (build / machine).iterdir() if q.is_file()}
    snd = BX.SOUND_MEMBER[machine]
    names = PS.SAMPLE_MEMBERS[machine]
    stock = {q.name: q.read_bytes() for q in (a.rom_dir.resolve() / machine).iterdir() if q.is_file()}
    after_oki = b''.join((files[n] for n in names))
    z_before = undo_install(files[snd])
    errors = []
    if PS.sha256(z_before) != bj['pce_sfx']['sound_before_sha256'] or PS.sha256(after_oki) != bj['pce_sfx']['samples_sha256'] or PS.sha256(files[snd]) != bj['pce_sfx']['sound_sha256']:
        raise SystemExit(f"{build}: the sound members are not build.json's")
    before = dict(files, **{snd: z_before}, **{n: stock[n] for n in names})
    cens, new = (census_cmds(), new_cmds())
    cmds = cens + new
    runs = {}
    for tag, fl, flag in (('after', files, 0), ('after_pack', files, PACK_FLAG), ('before', before, 0), ('before_pack', before, PACK_FLAG)):
        sets = stage(a, work, tag, fl, flag)
        runs[tag] = run(binary, sets, a.set, work / f'run_{tag}', cmds, CENSUS_SLOT)
        print(tag, 'ran', len(cmds), 'slots', flush=True)
    rep = dict(set=a.set, census_commands=len(cens), new_commands=[f'{c:#04x}' for c in new])
    t_end = runs['after']['slots'][len(cens)][1]
    n_end = int(round(t_end * SR))
    roms = {'after': after_oki, 'before': b''.join((stock[n] for n in names))}
    for fl in ('', '_pack'):
        ra, rb = (runs['after' + fl], runs['before' + fl])
        r = {}
        for chip, res in (('ym', lambda ev, rom: [(t, reg, v) for t, reg, v in ev]), ('oki', resolve_oki)):
            ea = res(events_in(ra[chip], 0, t_end), roms['after'])
            eb = res(events_in(rb[chip], 0, t_end), roms['before'])
            same = [x[1:] for x in ea] == [x[1:] for x in eb]
            dt = max((abs(x[0] - y[0]) for x, y in zip(ea, eb)), default=0.0)
            r[chip] = dict(writes=len(ea), same_values=same, max_shift_us=round(dt * 1000000.0, 1))
            if not same or dt > TIME_TOL:
                bad = sorted({f'{c:#04x}' for k, c in enumerate(cens) for x, y in zip(ea, eb) if x[1:] != y[1:] and ra['slots'][k][1] <= x[0] < ra['slots'][k][1] + CENSUS_SLOT})
                errors.append(f'census{fl}: the {chip} writes differ (values same {same}, shift {dt * 1000000.0:.1f} us): {bad[:12]}')
        renamed = sum((x != y for x, y in zip(events_in(ra['oki'], 0, t_end), events_in(rb['oki'], 0, t_end)) if x[1] != y[1]))
        r['oki']['phrase_numbers_renamed'] = renamed
        ctl = [x[1:] for x in resolve_oki(events_in(ra['oki'], 0, t_end), roms['before'])]
        r['oki']['control_without_copies_differs'] = ctl != [x[1:] for x in resolve_oki(events_in(rb['oki'], 0, t_end), roms['before'])]
        if not r['oki']['control_without_copies_differs']:
            errors.append(f'census{fl}: the control (no header copies) does not differ: the check cannot fail')
        n_same = sum((np.array_equal(ra['raw'][slice(*window(ra, k, CENSUS_SLOT))], rb['raw'][slice(*window(rb, k, CENSUS_SLOT))]) for k in range(len(cens))))
        r['mix_slots_sample_identical'] = n_same
        rep[f'census{fl}'] = r
    for t in ('after', 'before'):
        ra, rb = (runs[t], runs[t + '_pack'])
        if not (np.array_equal(ra['raw'], rb['raw']) and ra['ym'] == rb['ym'] and (ra['oki'] == rb['oki'])):
            errors.append(f'{t}: the pack flag changes the sound')
    cap = a.capture.resolve()
    PS.check_inputs(cap)
    cs = PS.clips(cap)
    plan = bj['pce_sfx']
    hdr = headers(after_oki)
    rep['new'] = {}
    for k, e in enumerate(PS.manifest()['effects']):
        c = int(e['command'], 16)
        kk = len(cens) + k
        ph = c & 127
        z = files[snd]
        vb = z[PS.Z80_TABLE + ph]
        s, stop = hdr[ph]
        r = {}
        for t in ('after', 'before'):
            ra = runs[t]
            w0, w1 = window(ra, kk, CENSUS_SLOT)
            t0 = ra['slots'][kk][1]
            mix = ra['mix'][w0:w1]
            nz = np.flatnonzero(np.abs(mix) > 0)
            got = mix[nz[0]:nz[-1] + 1] if len(nz) else mix[:0]
            pce = PS.mono(cs[int(e['pce_psg'], 16)])
            pce_band = PS.from_oki_rate(PS.to_oki_rate(pce), len(pce))
            corr_pce, lag_pce = best_corr(got, pce_band, SR // 20) if len(got) else (0.0, 0)
            r[t] = dict(oki=[f'{v:02x}' for _, v in events_in(ra['oki'], t0, t0 + CENSUS_SLOT)][:3], seconds=round(len(got) / SR, 4), corr_pce=round(corr_pce, 4), lag_pce=lag_pce)
            if t == 'after':
                dec = OKI.decode_phrase(after_oki, s, stop).astype(float) * OKI.VOLUME[vb & 15] / 32
                want = PS.from_oki_rate(dec)
                corr_dec, lag_dec = best_corr(lowpass(got), lowpass(want), SR // 20) if len(got) else (0.0, 0)
                loud = PS.loudness_db(got, SR)
                p = plan['effects'][e['id']]
                r[t].update(corr_decode=round(corr_dec, 4), lag_decode=lag_dec, loudness_db=round(loud, 2), target_db=p['target_db'], shortfall_db=p['shortfall_db'])
                want_oki = [f'{(vb & 240) >> 1:02x}', f'{128 | ph:02x}', f'{vb:02x}']
                if r[t]['oki'] != want_oki:
                    errors.append(f"{e['id']}: OKI writes {r[t]['oki']}, not {want_oki}")
                if corr_dec < MIN_DECODE_CORR:
                    errors.append(f"{e['id']}: its MAME output correlates {corr_dec:.4f} with its decode")
                if corr_pce < MIN_PCE_CORR:
                    errors.append(f"{e['id']}: its MAME output correlates {corr_pce:.4f} with the PC Engine render")
                if abs(loud - (p['target_db'] - p['shortfall_db'])) > 1.0:
                    errors.append(f"{e['id']}: loudness {loud:.2f} dB, planned {p['target_db'] - p['shortfall_db']:.2f}")
                if a.review:
                    a.review.mkdir(parents=True, exist_ok=True)
                    PS.write_wav(a.review / f"{c:02x}_{e['id']}_oki_mame_{machine}.wav", got)
                    if machine == 'striderua':
                        g = 10 ** ((loud - PS.loudness_db(pce, SR)) / 20)
                        PS.write_wav(a.review / f"{c:02x}_{e['id']}_pce_render.wav", pce * g)
            elif corr_pce >= MIN_PCE_CORR:
                errors.append(f"{e['id']}: the control (the stock driver) correlates {corr_pce:.4f}: the check cannot fail")
        rep['new'][e['id']] = r
    if a.pack:
        import pack_model as PM
        m = PM.Model(a.pack.resolve())
        rows = {f'{c:#04x}': dict(verb=m.triggers[c].verb, suppress=m.triggers[c].suppress) for c in new}
        rep['pack'] = dict(pack=PS.file_sha256(a.pack), native_rows=rows, suppressed=[f'{c:#04x}' for c in range(m.ctrl_start) if m.triggers[c].suppress])
        if any((r['verb'] != PM.VERB_NONE or r['suppress'] for r in rows.values())):
            errors.append(f'the pack has rows on the native effects: {rows}')
    rep['errors'] = errors
    rep['passed'] = not errors
    (work / 'report.json').write_text(json.dumps(rep, indent=1) + '\n')
    print(json.dumps(rep, indent=1))
    print('sfx census', a.set, 'PASS' if not errors else 'FAIL')
    return 0 if not errors else 1

def desert_review(a):
    """Listening captures (scratch: copyrighted sound): desert_gate.py actors' 'waves' run (section 2's drones,"""
    import desert_gate as DG
    work = a.workdir.resolve()
    work.mkdir(parents=True, exist_ok=False)
    out = a.out.resolve()
    out.mkdir(parents=True, exist_ok=True)
    machine = PARENT[a.set]
    binary = json.loads((a.runtime / 'runtime.json').read_text())['binary']
    roms = DG.stage_sets(a.build.resolve(), a.set, a.hbmame, a.rom_dir.resolve(), work / 'sets')
    wn = DG.WAVE_FRAMES
    wave_env = dict(DG.debug_env(5, 3, wn), ACTORS='1', WARP=DG.wave_path(), STREX_INPUTS=f'{DG.WAVE_PLAY}-{wn}@10/3:P1_BUTTON1')
    runs = {'drones': wave_env, 'robots': dict(wave_env, STREX_INPUTS='', WARP=DG.wave_path(DG.ROBOT_POINTS, DG.ROBOT_HOLD))}
    new = set(new_cmds())
    rep = {}
    for name, env in runs.items():
        d = work / name
        DG.run(binary, roms, a.set, d, env, wn, extra=('-wavwrite', str(d / 'mix.wav')))
        _, events = DG.read_actors(d)
        snd = [(e['frame'], e['value']) for e in events if e['what'] == 'snd' and e['value'] in new]
        x = PS.read_wav(d / 'mix.wav')
        t0 = int(round(DG.WAVE_PLAY / 59.637 * SR))
        dest = out / f'desert_section2_{name}_{machine}.wav'
        PS.write_wav(dest, x[t0:])
        rep[name] = dict(wav=str(dest), seconds=round((len(x) - t0) / SR, 1), commands={f'{c:#04x}': sum((v == c for _, v in snd)) for c in sorted(new)}, first=[(f, f'{v:#04x}') for f, v in snd[:6]])
    (work / 'review.json').write_text(json.dumps(rep, indent=1) + '\n')
    print(json.dumps(rep, indent=1))
    return 0

def self_test():
    OKI.self_test()
    rng = np.random.default_rng(3)
    x = rng.normal(0, 1, 4000)
    c, lag = best_corr(np.concatenate([np.zeros(37), x]), x, 100)
    assert c > 0.999 and lag == 37, (c, lag)
    assert best_corr(rng.normal(0, 1, 4000), x, 100)[0] < 0.2
    z = bytearray(b'\xff' * 65536)
    z[PS.Z80_TABLE_OP - 1:PS.Z80_TABLE_OP + 2] = bytes([33, 51, 14])
    z[PS.Z80_COUNT] = 28
    w = bytearray(z)
    w[PS.Z80_TABLE:PS.Z80_TABLE + 128] = bytes(range(128))
    w[PS.Z80_TABLE_OP:PS.Z80_TABLE_OP + 2] = b'\x00\x7f'
    w[PS.Z80_COUNT] = 127
    assert undo_install(bytes(w)) == bytes(z)
    rom = bytearray(1024)
    rom[8 * 3:8 * 3 + 6] = rom[8 * 32:8 * 32 + 6] = bytes.fromhex('000800000dff')
    a1 = resolve_oki([(0, 8), (1, 131), (2, 16)], rom)
    assert [x[1:] for x in a1] == [x[1:] for x in resolve_oki([(0, 8), (1, 160), (2, 16)], rom)]
    rom[8 * 32 + 5] = 254
    assert [x[1:] for x in a1] != [x[1:] for x in resolve_oki([(0, 8), (1, 160), (2, 16)], rom)]
    assert len(census_cmds()) == 255 - len(new_cmds()) and (not set(census_cmds()) & set(new_cmds()))
    print('sfx_gate self-test ok')
    return 0

def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('--self-test', action='store_true')
    sub = p.add_subparsers(dest='cmd')
    lv = sub.add_parser('levels')
    lv.add_argument('--rom-dir', type=Path, required=True)
    lv.add_argument('--workdir', type=Path, required=True)
    lv.add_argument('--mame', default='mame')
    cs = sub.add_parser('census')
    cs.add_argument('--build', type=Path, required=True)
    cs.add_argument('--runtime', type=Path, required=True)
    cs.add_argument('--hbmame', type=Path, required=True)
    cs.add_argument('--rom-dir', type=Path, required=True)
    cs.add_argument('--capture', type=Path, required=True)
    cs.add_argument('--set', choices=sorted(PARENT), required=True)
    cs.add_argument('--workdir', type=Path, required=True)
    cs.add_argument('--review', type=Path)
    cs.add_argument('--pack', type=Path, help='a strider_ex.cpk: no row may lie on a native effect command')
    dr = sub.add_parser('desert-review')
    dr.add_argument('--build', type=Path, required=True)
    dr.add_argument('--runtime', type=Path, required=True)
    dr.add_argument('--hbmame', type=Path, required=True)
    dr.add_argument('--rom-dir', type=Path, required=True)
    dr.add_argument('--set', choices=sorted(PARENT), required=True)
    dr.add_argument('--workdir', type=Path, required=True)
    dr.add_argument('--out', type=Path, required=True)
    a = p.parse_args()
    if a.self_test:
        return self_test()
    if a.cmd == 'desert-review':
        return desert_review(a)
    if a.cmd == 'levels':
        return levels(a)
    if a.cmd == 'census':
        return census(a)
    p.print_help()
    return 2
if __name__ == '__main__':
    sys.exit(main())
