"""Standard-library private-kit checks and exact native Kit aa recovery."""
import argparse
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import xml.etree.ElementTree as ET
import zipfile
sys.dont_write_bytecode = True
MACHINES = ('striderua', 'striderjr')
MOVEMENT = ('beam0', 'beam1', 'beam2', 'beam3', 'beam_right', 'beam4', 'beam5', 'beam6', 'pole1599', 'pole1615', 'pole1630', 'exit', 's0', 's2_turn', 'stock_stpetersburg_turn', 'stock_amazon_turn', 'stock_siberia', 'stock_aerial', 'stock_moon')
MOON = ('opening_pack', 'opening_native', 'select', 'restart', 'ending', 'amazon')
LAYERS = (('stage_clear', 'stage_clear'), ('camera', 'desert_motion'), ('transition', 'desert_transition'), ('pole_floor', 'pole_floor'), ('final', 'desert_climb'))

def sha(data):
    return hashlib.sha256(data).hexdigest()

def json_sha(data):
    return sha((json.dumps(data, indent=2) + '\n').encode())

def matrices(game, moon):
    wanted = {(m, 'movement', c) for m in MACHINES for c in MOVEMENT}
    wanted |= {(m, 'clear', s) for m in MACHINES for s in range(6)}
    wanted |= {(m, 'no_pack_clear', s) for m in MACHINES for s in (0, 4)}
    rows = game['results']
    got = {(r['machine'], r['kind'], r.get('case') if r['kind'] == 'movement' else r['stage']) for r in rows}
    if len(rows) != 54 or got != wanted or (not all((r['passed'] for r in rows))):
        raise ValueError('incomplete or failed gameplay matrix')
    rows = moon['checks']
    wanted = {(m, c) for m in MACHINES for c in MOON}
    if len(rows) != 12 or {(r['machine'], r['case']) for r in rows} != wanted or (not all((r['passed'] for r in rows))):
        raise ValueError('incomplete or failed Moon matrix')

def qualification(report):
    p = report['gameplay_followup']
    q = p['qualification']
    chain = p['chain']
    expected = report['build_files']
    g, f, m, mf = [q[k] for k in ('gameplay_runtime', 'gameplay_fresh', 'moon_runtime', 'moon_fresh')]
    if not all((r['passed'] for r in q.values())):
        raise ValueError('failed qualification')
    if f['builds'] != chain or g['inputs'] != {'control': chain['base'], 'candidate': chain['final']}:
        raise ValueError('gameplay qualification input chain differs')
    if m['inputs'] != {'control': chain['final'], 'candidate': expected} or mf['inputs'] != m['inputs']:
        raise ValueError('Moon qualification input chain differs')
    if f['focused_gate_sha256'] != json_sha(g) or mf['runtime_receipt_sha256'] != json_sha(m):
        raise ValueError('fresh/runtime receipt bindings differ')
    if not f['fresh_empty_output_reproduces_all_roms_and_metadata'] or not mf['fresh_files_and_metadata_exact']:
        raise ValueError('fresh reconstruction missing')
    if len(f['rehashed_damage_controls']) != 10 or not all((r['rejected'] for r in f['rehashed_damage_controls'])):
        raise ValueError('gameplay damage controls missing')
    if len(mf['damage_controls']) != 4 or not all((r['rejected'] for r in mf['damage_controls'])):
        raise ValueError('Moon damage controls missing')
    if p['baseline_test_id'] != '261026-01' or p['baseline_manifest_sha256'] != f['baseline_export_manifest_sha256']:
        raise ValueError('selected native baseline differs')
    matrices(g, m)
    previous = chain['base']
    for name, field in LAYERS:
        if any((p['regions'][machine][field]['source_files'] != previous[machine] for machine in MACHINES)):
            raise ValueError('producer source chain differs: ' + name)
        previous = chain[name]
    if any((p['regions'][machine]['moon_start']['source_files'] != previous[machine] for machine in MACHINES)):
        raise ValueError('Moon source chain differs')
    if p['art_selection']['scale'] != 'native':
        raise ValueError('native art selection missing')

def cpu_image(files, machine):
    image = bytearray(2097152)
    if machine == 'striderua':
        for name, start, odd in (('30.11f', 0, 0), ('35.11h', 0, 1), ('31.12f', 262144, 0), ('36.12h', 262144, 1)):
            data = files[name]
            image[start + odd:start + 2 * len(data) + odd:2] = data
        data = files['st-14.8h']
        image[524288:1048576] = bytes((data[i ^ 1] for i in range(len(data))))
    else:
        for name, start in (('sthj_23.8f', 0), ('sthj_22.7f', 524288)):
            data = files[name]
            image[start:start + len(data)] = bytes((data[i ^ 1] for i in range(len(data))))
    data = files['strex_p6.bin']
    image[1048576:] = bytes((data[i ^ 1] for i in range(len(data))))
    return image

def binary_checks(files, machine, spec):
    image = cpu_image(files, machine)
    for field in ('stage_clear', 'desert_motion', 'desert_transition', 'desert_climb', 'moon_start'):
        s = spec[field]
        h = s['change'] if field == 'moon_start' else s
        at, n = (h['helper_at'], h['helper_bytes'])
        if sha(image[at:at + n]) != h['helper_sha256']:
            raise ValueError('native helper changed: ' + field)
        changes = [h] if field == 'moon_start' else s.get('hooks', s.get('changes', []))
        for r in changes:
            data = bytes.fromhex(r['after'])
            at = r['address']
            if image[at:at + len(data)] != data:
                raise ValueError('native hook changed: ' + field)
    for r in spec['desert_climb']['changes']:
        at = r['address']
        data = bytes.fromhex(r['before'])
        image[at:at + len(data)] = data
    floor = spec['pole_floor']
    at, n = (floor['allocation_start'], floor['allocation_size'])
    if sha(image[at:at + n]) != floor['allocation_sha256']:
        raise ValueError('pole floor allocation changed')

def verify(root):
    sys.path.insert(0, str(root))
    import mra_assembly
    report = json.loads((root / 'producer.json').read_text())
    proof = report['gameplay_followup']
    qualification(report)
    members = {}
    for relative, expected in report['archives'].items():
        with zipfile.ZipFile(root / relative) as z:
            if len(z.namelist()) != len(set(z.namelist())):
                raise ValueError('duplicate ZIP member')
            got = {n: sha(z.read(n)) for n in z.namelist()}
            if relative.startswith('games/mame/striderex_'):
                machine = 'striderua' if relative.endswith('_us.zip') else 'striderjr'
                members[machine] = {n: z.read(n) for n in report['build_files'][machine]}
        if got != expected:
            raise ValueError('archive changed: ' + relative)
    for machine, files in members.items():
        if {n: sha(b) for n, b in files.items()} != report['build_files'][machine]:
            raise ValueError('final ROM inventory changed')
        binary_checks(files, machine, proof['regions'][machine])
    for title, expected in report['mras'].items():
        text = (root / '_Arcade' / (title + '.mra')).read_text()
        refs = {Path(ref).name for n in ET.fromstring(text).iter() for ref in n.get('zip', '').split('|') if ref}
        archives = [root / p for p in report['archives'] if Path(p).name in refs]
        image = mra_assembly.assemble(text, mra_assembly.ZipSource(archives))
        if sha(image) != expected['assembled_sha256'] or image[64 + (2097151 ^ 1)] != expected['flag']:
            raise ValueError('launcher assembly or defaults changed')
    if sha((root / report['core']['file']).read_bytes()) != report['core']['sha256']:
        raise ValueError('core changed')
    reverse = root / 'gameplay-reverse.zip'
    if sha(reverse.read_bytes()) != proof['reverse_sha256']:
        raise ValueError('baseline recovery payload changed')
    with tempfile.TemporaryDirectory(prefix='striderex-gameplay-') as temporary:
        baseline = Path(temporary) / 'baseline'
        shutil.copytree(root, baseline)
        with zipfile.ZipFile(reverse) as z:
            manifest = json.loads(z.read('baseline.json'))
            if manifest['build_files'] != proof['chain']['base']:
                raise ValueError('inverse baseline inventory differs')
            for name, digest in manifest['files'].items():
                if Path(name).is_absolute() or '..' in Path(name).parts:
                    raise ValueError('unsafe inverse path')
                data = z.read('files/' + name)
                if sha(data) != digest:
                    raise ValueError('baseline helper changed')
                target = baseline / name
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(data)
            for machine, expected in manifest['build_files'].items():
                region = 'us' if machine == 'striderua' else 'jp'
                path = baseline / f'games/mame/striderex_{region}.zip'
                with zipfile.ZipFile(path) as source:
                    old = {n: source.read(n) for n in source.namelist()}
                for name, digest in expected.items():
                    key = f'roms/{machine}/{name}'
                    if key in z.namelist():
                        old[name] = z.read(key)
                    if sha(old[name]) != digest:
                        raise ValueError('cannot recover baseline ROM: ' + name)
                with zipfile.ZipFile(path, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as target:
                    for name, data in sorted(old.items()):
                        target.writestr(name, data)
        subprocess.run([sys.executable, '-I', '-B', str(baseline / 'verify_kit.py'), '--root', str(baseline)], check=True)
    print('PASS gameplay kit: six native layers, 66 focused checks, ROM/MRA/core identities and exact native Kit aa recovery')

def self_test():
    game = dict(results=[dict(machine=m, kind='movement', case=c, passed=True) for m in MACHINES for c in MOVEMENT] + [dict(machine=m, kind='clear', stage=s, passed=True) for m in MACHINES for s in range(6)] + [dict(machine=m, kind='no_pack_clear', stage=s, passed=True) for m in MACHINES for s in (0, 4)])
    moon = dict(checks=[dict(machine=m, case=c, passed=True) for m in MACHINES for c in MOON])
    matrices(game, moon)
    for target in ('results', 'checks'):
        for fault in ('missing', 'duplicate', 'failed'):
            a, b = (deepcopy(game), deepcopy(moon))
            rows = a['results'] if target == 'results' else b['checks']
            if fault == 'missing':
                rows.pop()
            elif fault == 'duplicate':
                rows[0] = deepcopy(rows[1])
            else:
                rows[0]['passed'] = False
            try:
                matrices(a, b)
            except ValueError:
                pass
            else:
                raise AssertionError('incomplete matrix accepted')
    print('Gameplay portable self-test PASS: six incomplete/damaged matrix controls rejected')

def main():
    if sys.argv[1:] == ['--self-test']:
        return self_test()
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root', type=Path, default=Path(__file__).resolve().parent)
    verify(p.parse_args().root.resolve())
if __name__ == '__main__':
    main()
