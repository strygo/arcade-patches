-- PC Engine research probe (P0.4 desert spawn decode): record the whole of
-- main RAM (0x1F0000-0x1F1FFF) and the eight MPR registers every frame
-- from STRIDEREX_RAMREC_FROM to STRIDEREX_RAMREC_TO while a stage is in
-- play (0x1F00C7 = 8). Record: u32 frame, 8 MPR bytes, 8192 RAM bytes, then
-- each STRIDEREX_RAMREC_EXTRA range ("lo-hi,..." physical hex, e.g. the
-- actor bank 10C000-10DFFF), to STRIDEREX_RAMREC (one file). Loaded by
-- pce_vdc_shadow.lua when set.
local m=manager.machine
local cpu=m.devices[':maincpu']
local prog=cpu.spaces['program']
local path=os.getenv('STRIDEREX_RAMREC')
local f0=tonumber(os.getenv('STRIDEREX_RAMREC_FROM') or '0')
local f1=tonumber(os.getenv('STRIDEREX_RAMREC_TO') or '0')
local out=assert(io.open(path,'wb'))
local ranges={{0x1f0000,0x1f1fff}}
for lo,hi in string.gmatch(os.getenv('STRIDEREX_RAMREC_EXTRA') or '','(%x+)%-(%x+)') do
 ranges[#ranges+1]={tonumber(lo,16),tonumber(hi,16)}
end
local f=0
emu.register_frame_done(function()
 f=f+1
 if f<f0 or f>f1 or prog:read_u8(0x1f00c7)~=8 then return end
 local t={string.pack('<I4',f)}
 for i=0,7 do t[#t+1]=string.char(cpu.state['MPR'..i].value & 0xff) end
 for _,r in ipairs(ranges) do
  for a=r[1],r[2],4 do t[#t+1]=string.pack('<I4',prog:read_u32(a)) end
 end
 out:write(table.concat(t))
 if f==f1 then out:flush() end
end)

-- Optional write log: every write to physical STRIDEREX_WLOG_RANGE
-- ("lo-hi" hex, default main RAM 1F0000-1F1FFF) from STRIDEREX_WLOG_FROM to
-- STRIDEREX_WLOG_TO (frames) as "frame pc mpr2-6 physical-address data"
-- lines to STRIDEREX_WLOG.
local wpath=os.getenv('STRIDEREX_WLOG')
if wpath and wpath~='' then
 local w0=tonumber(os.getenv('STRIDEREX_WLOG_FROM')); local w1=tonumber(os.getenv('STRIDEREX_WLOG_TO'))
 local wf=assert(io.open(wpath,'w'))
 local st=cpu.state
 local lo,hi=string.match(os.getenv('STRIDEREX_WLOG_RANGE') or '1f0000-1f1fff','(%x+)%-(%x+)')
 lo,hi=tonumber(lo,16),tonumber(hi,16)
 _G.strex_wlog_tap=prog:install_write_tap(lo,hi,'strex_wlog',function(off,data,mask)
  if f+1<w0 or f+1>w1 then return end
  wf:write(string.format('%d %04x %02x%02x%02x%02x%02x %06x %02x\n',f+1,st['PC'].value,
   st['MPR2'].value&0xff,st['MPR3'].value&0xff,st['MPR4'].value&0xff,st['MPR5'].value&0xff,st['MPR6'].value&0xff,
   off,data&0xff))
 end)
 emu.register_frame_done(function() if f==w1 then wf:flush() end end)
end
