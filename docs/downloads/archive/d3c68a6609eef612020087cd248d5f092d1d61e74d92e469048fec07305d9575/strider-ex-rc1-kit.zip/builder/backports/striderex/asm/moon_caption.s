; Moon's first gameplay setup reloads all object palettes while its caption
; is still fading. Keep the live caption's 16 colours across that one copy.
; Native PAL owns d0-d7/a0-a2. Preserve its exact returned register values.
        org $1F4E00
        cmpi.b #4,$FF0CB2
        bne.s .native
        lea $FF5EDA,a0
        moveq #19,d0
.find:
        tst.b (a0)
        beq.s .next
        cmpi.b #2,$17(a0)
        bne.s .next
        cmpi.l #CAPTION,$1A(a0)
        beq.s .keep
.next:
        lea $40(a0),a0
        dbra d0,.find
.native:
        jmp PAL
.keep:
        movem.l $9142C0,d0-d6/a2
        movem.l d0-d6/a2,-(sp)
        jsr PAL
        movem.l d0-d6/a2,-(sp)
        movem.l 32(sp),d0-d6/a2
        movem.l d0-d6/a2,$9142C0
        movem.l (sp)+,d0-d6/a2
        lea 32(sp),sp
        rts
