"""P0.14 sizing: how much scene data would the cinematics need as a"""
import argparse
import json
import sys
import zlib
from pathlib import Path
import numpy as np
sys.path.insert(0, str(Path(__file__).resolve().parent))
import pce_vdc as P
REGS = (5, 7, 8)

def frame_list(run_dir, t0, t1):
    rows = {}
    lines = (run_dir / 'pce_scene_index.tsv').read_text().splitlines()
    head = lines[0].split('\t')
    for line in lines[1:]:
        r = dict(zip(head, line.split('\t')))
        if t0 <= float(r['time']) <= t1:
            rows[int(r['frame'])] = r
    return sorted(rows)

def stream(run_dir, frames):
    out = bytearray()
    prev = None
    counts = dict(frames=0, bat_words=0, keyframes=0, sat_entries=0, regs=0, pal_entries=0)
    for f in frames:
        d = P.load(run_dir / f'pce_{f:05d}_scene.vdc')
        g = P.geometry(d)
        n = g['map_h'] * g['map_w']
        bat = d['vram'][:n].astype(np.uint16)
        tiles = P.all_bg_tiles(d['vram']).reshape(2048, 64).astype(np.uint64)
        tkey = (tiles * (np.arange(64, dtype=np.uint64) * np.uint64(2654435761) + np.uint64(1))).sum(1)
        content = tkey[bat & 2047] * np.uint64(31) + (bat >> 12).astype(np.uint64)
        sat = d['sat'].astype(np.uint16).reshape(64, 4)
        pal = d['pal'].astype(np.uint16)
        regs = np.array([d['reg'][r] for r in REGS], np.uint16)
        counts['frames'] += 1
        if prev is None or prev[4].shape != content.shape:
            out += bat.tobytes() + sat.tobytes() + pal.tobytes() + regs.tobytes()
            counts['keyframes'] += 1
        else:
            pbat, psat, ppal, pregs, pcontent = prev
            ch = np.nonzero(content != pcontent)[0]
            if len(ch) * 4 > bat.nbytes:
                out += b'K' + bat.tobytes()
                counts['keyframes'] += 1
            else:
                for i in ch:
                    out += int(i).to_bytes(2, 'big') + int(bat[i]).to_bytes(2, 'big')
                counts['bat_words'] += len(ch)
            for i in np.nonzero((sat != psat).any(1))[0]:
                out += bytes([int(i)]) + sat[i].tobytes()
                counts['sat_entries'] += 1
            for i in np.nonzero(regs != pregs)[0]:
                out += bytes([int(i)]) + int(regs[i]).to_bytes(2, 'big')
                counts['regs'] += 1
            for i in np.nonzero(pal != ppal)[0]:
                out += int(i).to_bytes(2, 'big') + int(pal[i]).to_bytes(2, 'big')
                counts['pal_entries'] += 1
            out += b'\n'
        prev = (bat, sat, pal, regs, content)
    return (bytes(out), counts)

def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('--census', type=Path, required=True, help='pce_cinematic_census.py work directory')
    p.add_argument('--output', type=Path, required=True)
    a = p.parse_args()
    cat = json.loads((a.census / 'catalog/catalog.json').read_text())
    rows, tot_raw, tot_z = ([], 0, 0)
    for c in cat['cinematics']:
        run_dir = a.census / c['run']
        t0 = c['cd_request_time']
        frames = frame_list(run_dir, t0, t0 + c['track_seconds'])
        data, counts = stream(run_dir, frames)
        z = len(zlib.compress(data, 9))
        tot_raw += len(data)
        tot_z += z
        rows.append(dict(id=c['id'], track=c['track'], seconds=c['track_seconds'], raw_bytes=len(data), zlib_bytes=z, **counts))
        print(f"{c['id']:>14}  tr{c['track']}  {counts['frames']:5d} frames  raw {len(data) / 1024:8.1f} KB  zlib {z / 1024:7.1f} KB  bat {counts['bat_words']:7d}  key {counts['keyframes']:3d}  sat {counts['sat_entries']:6d}  pal {counts['pal_entries']:7d}")
    print(f"{'total':>14}  raw {tot_raw / 1024:.1f} KB  zlib {tot_z / 1024:.1f} KB")
    a.output.write_text(json.dumps(dict(cinematics=rows, raw_bytes=tot_raw, zlib_bytes=tot_z), indent=1) + '\n')
    return 0
if __name__ == '__main__':
    sys.exit(main())
