"""Strider EX boss scene gate (HBMAME): the eight boss scenes (build_ex.py, the default), exact, and play unchanged."""
import argparse
import json
import os
import shutil
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import numpy as np
from PIL import Image
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import boss_scene as BS
import cps1_gfx as G
import portrait_gate as PG
import respawn_fix as RF
import scene_gate as SG
ROOT = HERE.parents[2]
LUA = ROOT / 'backports/striderex/lua/boss_scene_gate.lua'
DEBUG_START = ROOT / 'backports/striderex/lua/arcade_debug_start.lua'
HBSET = HERE / 'hbmame_set.py'
PARENT = PG.PARENT
POST = 300
STACKS = (16711936, 16714736)
BS_RAM = (16775616, 16775680)
BS_STACK = (16766720, 16766976)
BOSS = 49638

def flag_p6(p6, bit):
    """strex_p6.bin (word-swapped) with a flag word bit set (the flag word's low byte is the bank's last byte)."""
    b = bytearray(p6)
    b[len(b) - 2] |= 1 << bit
    return bytes(b)

def stage_sets(a, work, machine, var):
    exdir = work / 'exdir'
    (exdir / machine).mkdir(parents=True)
    for n, b in var['build'].items():
        (exdir / machine / n).write_bytes(b)
    out = work / 'set_build'
    subprocess.run([sys.executable, str(HBSET), 'build', '--hbmame', str(a.hbmame), '--rom-dir', str(a.rom_dir), '--ex-dir', str(exdir), '--set', a.set, '--date', '2026-10-10', '--out', str(out)], check=True, stdout=subprocess.DEVNULL)
    members = {q.name: q.read_bytes() for q in (out / a.set).iterdir()}
    sets = {}
    for v in ('ex', 'pack', 'base', 'ctl'):
        d = work / f'set_{v}'
        shutil.copytree(out, d)
        for n, b in var[v].items():
            if b == var['build'][n]:
                continue
            hits = [m for m, mb in members.items() if mb == var['build'][n]]
            if not hits or len(hits) > 2:
                sys.exit(f'{n}: {len(hits)} set members carry its bytes')
            for h in hits:
                (d / a.set / h).write_bytes(b)
        sets[v] = d
    return sets

def shift_inputs(inputs, n, e):
    """The scenario's STREX_INPUTS for a run whose game stands still n frames from frame e: each range as it is up"""
    out = []
    for item in filter(None, inputs.split(';')):
        rng, tok = item.split(':')
        span, *per = rng.split('@')
        lo, hi = (int(x) for x in span.split('-'))
        p = f'@{per[0]}' if per else ''
        if lo <= e:
            out.append(f'{lo}-{min(hi, e)}{p}:{tok}')
        if hi <= e:
            continue
        lo2 = lo + n
        while lo2 <= e:
            lo2 += int(per[0].split('/')[0]) if per else e + 1 - lo2
        out.append(f'{lo2}-{hi + n}{p}:{tok}')
    return ';'.join(out)
FR_COLS = ['f', 'on', 'n', 'active', 'px', 'py', 'cx', 'cy', 'music', 'counter', 'sum', 'gfxw', 'lives']
REUSE = False

def run(binary, roms, set_name, out, sc, frames, inputs, shots='', shift=None, holds=None, video_frames='', audio=False):
    if REUSE and (out / 'mame.log').exists():
        return load(out, frames)
    out.mkdir(parents=True, exist_ok=True)
    env = dict(os.environ, SDL_VIDEODRIVER='dummy', SDL_AUDIODRIVER='dummy', STREX_GATE_OUT=str(out / 'g'), STREX_DEBUG_START=str(DEBUG_START), STREX_STAGE=str(sc['stage']), STREX_AREA=str(sc['area']), STREX_END=str(frames), STREX_INVINCIBLE='1' if sc.get('invincible', True) else '0', STREX_INPUTS=inputs, STREX_PREFIX=str(out / 'dbg'), STREX_SHIFT=f'{shift[0]},{shift[1]}' if shift else '', STREX_GATE_SHOTS=shots, STREX_GATE_AUDIO='1' if audio else '0', STREX_VIDEO_DUMPS=video_frames, STREX_GATE_VIDEO_DIR=str(out), STREX_HOLDS=holds if holds is not None else ';'.join((f'{a},{b},{x},{v}' for a, b, x, v in sc.get('holds', []))))
    cmd = [str(binary), set_name, '-rompath', str(roms), '-nothrottle', '-video', 'none', '-sound', 'none', '-skip_gameinfo', '-noautosave', '-cfg_directory', str(out / 'cfg'), '-nvram_directory', str(out / 'nv'), '-snapshot_directory', str(out), '-seconds_to_run', str(frames // 50 + 60), '-autoboot_script', str(LUA)]
    p = subprocess.run(cmd, env=env, cwd=out, capture_output=True, text=True, timeout=3600)
    (out / 'mame.log').write_text(p.stdout + p.stderr)
    if p.returncode:
        sys.exit(f'{out}: HBMAME exit {p.returncode} (see mame.log)')
    return load(out, frames)

def load(out, frames):
    rows = [r.split('\t') for r in (out / 'g_frames.tsv').read_text().splitlines()]
    fr = [dict(zip(FR_COLS, [int(r[0]), int(r[1], 16), int(r[2]), *(int(x, 16) for x in r[3:10]), r[10], int(r[11]), int(r[12])])) for r in rows]
    if len(fr) < frames:
        sys.exit(f'{out}: {len(fr)} frames of {frames} (see mame.log)')
    regs = [r.split('\t') for r in (out / 'g_regs.tsv').read_text().splitlines()]
    sync = [tuple(r.split('\t')) for r in (out / 'g_sync.tsv').read_text().splitlines()]
    dumps = {k: (out / f'g_{k}.bin').read_bytes() for k in ('entry', 'exit') if (out / f'g_{k}.bin').exists()}
    return dict(frames=fr, regs=regs, sync=sync, dumps=dumps, dir=out)

def scene_vblanks(log):
    """The scene's VBlanks from the register log: [dict(frame, n (BS_N + 1), prep, pl, t, pic, pal, layer, obj,"""
    out, cur = ([], None)
    for r in log['regs']:
        if len(r) < 4 or r[3] == '-' or r[1] not in ('pal', 'layer', 'obj'):
            continue
        if int(r[8], 16) != BOSS:
            continue
        if r[1] == 'pal':
            cur = dict(frame=int(r[0]), n=int(r[3]) + 1, prep=int(r[4]), pl=int(r[5], 16), t=int(r[6]), pic=int(r[7], 16), pal=int(r[2], 16), palsum=r[9] if len(r) > 9 else None, slots=[int(x, 16) for x in r[10].split(',')] if len(r) > 10 else None)
            out.append(cur)
        elif r[1] == 'layer' and cur is not None:
            cur['layer'] = int(r[2], 16)
        elif r[1] == 'obj' and cur is not None:
            cur['obj'] = int(r[2], 16)
            cur['list'] = [tuple((int(v, 16) for v in e.split(':'))) for e in r[9].split(',')] if len(r) > 9 and r[9] else []
    return out

def sound_writes(log):
    return [(int(r[0]), int(r[2], 16), r[3] != '-') for r in log['regs'] if r[1] == 'sound']

def palsum(words):
    h = 0
    for i in range(0, len(words), 2):
        h = h * 31 + (words[i] << 16 | words[i + 1]) & 4294967295
    return f'{h:08x}'

def freeze_diff(entry, exit_):
    """Differences between the start's and the end's dumps: work RAM without the stacks and the scene's variables,"""
    wr = 65536
    bad = []
    skip = [(lo - 16711680, hi - 16711680) for lo, hi in (STACKS, BS_RAM, BS_STACK)]
    a, b = (np.frombuffer(entry[:wr], np.uint8), np.frombuffer(exit_[:wr], np.uint8))
    d = np.nonzero(a != b)[0]
    d = [x for x in d if not any((lo <= x < hi for lo, hi in skip))]
    bad += [f'work {16711680 + x:#x}' for x in d[:10]]
    ga, gb = (np.frombuffer(entry[wr:wr + 114688], np.uint8), np.frombuffer(exit_[wr:wr + 114688], np.uint8))
    bad += [f'gfx {9437184 + x:#x}' for x in np.nonzero(ga != gb)[0][:10]]
    return bad

def game_palettes(entry):
    """The game's palettes at the scene's start (0x914000, 0xC00 words)."""
    off = 65536 + 81920
    return list(np.frombuffer(entry[off:off + 6144], '>u2').astype(int))

def check_frames(vb, tl, entry, rep_scene, glay, gobj):
    """Each scene VBlank against the timeline. -> list of problems (first 20)."""
    bad = []
    pals = game_palettes(entry)
    want_lay = {'game': glay}
    for k, fr in enumerate(tl):
        if k >= len(vb):
            bad.append(f"n {fr['n']}: no VBlank")
            break
        v = vb[k]
        if v['n'] != fr['n'] or v['prep'] != fr['n']:
            bad.append(f"n {fr['n']}: VBlank n {v['n']}, prepared {v['prep']}")
        phase = ['hold', 'fade_out', 'black', 'page', 'return'].index(fr['phase']) + 1
        if fr['phase'] == 'page':
            phase |= fr['page'] << 4
        if v['pl'] != phase << 8 | fr['level']:
            bad.append(f"n {fr['n']}: phase/level {v['pl']:#06x}, want {phase << 8 | fr['level']:#06x}")
        lay = want_lay.get(fr['layer'], fr['layer'])
        if v.get('layer') != lay:
            bad.append(f"n {fr['n']}: layer {v.get('layer')}, want {lay:#06x}")
        if fr['pal'] == 'game':
            if v['pal'] != BS.GAME_PAL:
                bad.append(f"n {fr['n']}: palette base {v['pal']:#06x}")
        else:
            if v['pal'] not in BS.PAL_BUFS:
                bad.append(f"n {fr['n']}: palette base {v['pal']:#06x} is not a scene buffer")
            if fr['phase'] in ('fade_out',) or (fr['phase'] == 'return' and fr['layer'] == 'game'):
                lv = fr['level']
                want = palsum([w & 4095 | lv << 12 for w in pals])
                if v['palsum'] != want:
                    bad.append(f"n {fr['n']}: palette buffer {v['palsum']}, want the game's at level {lv} {want}")
            if fr['phase'] == 'page' and v['slots'] != fr['ui'] + fr['pt']:
                bad.append(f"n {fr['n']}: page slots differ from the model")
        obj = v.get('obj')
        if fr['obj'] == 'game' and obj != gobj:
            bad.append(f"n {fr['n']}: OBJ base {obj}, want the game's {gobj:#06x}")
        if fr['obj'] == 'page':
            if obj not in BS.OBJ_LISTS:
                bad.append(f"n {fr['n']}: OBJ base {obj} is not a page list")
            elif v.get('list') != [tuple(e) for e in fr['list']]:
                bad.append(f"n {fr['n']}: page list differs from the model ({len(v.get('list') or [])} entries, want {len(fr['list'])})")
            if v['pic'] != BS.picture_at(rep_scene, fr['u'] - BS.HOLD_FROM):
                bad.append(f"n {fr['n']}: portrait code {v['pic']:#06x}")
    if len(vb) != len(tl):
        bad.append(f'{len(vb)} scene VBlanks, the timeline has {len(tl)}')
    return bad[:20]

def shot(d, f):
    return np.asarray(Image.open(d / f'g_{f:05d}.png').convert('RGB'))
STAR_MAX = 400
STAR_PIXELS = 3

def differ(a, b):
    """Pixels that differ, leaving out the star layer's blinking: MAME blinks the stars by its own frame number"""
    from scipy import ndimage
    d = (a != b).any(-1)
    n = int(d.sum())
    if not n:
        return (0, 0)
    lab, k = ndimage.label(d, structure=np.ones((3, 3)))
    sizes = np.bincount(lab.ravel())[1:]
    ai, bi = (a.astype(int), b.astype(int))
    grey = lambda x: (abs(x[..., 0] - x[..., 1]) <= 16) & (abs(x[..., 1] - x[..., 2]) <= 16)
    if n <= STAR_MAX and (sizes <= STAR_PIXELS).all() and (grey(ai) & grey(bi))[d].all():
        return (0, n)
    return (n, 0)

def check_pictures(ex_dir, base_dir, E, tl, rep, rep_scene, region):
    """Screenshots. The screenshot of frame E + k shows the palette base and layer word that scene VBlank k - lp"""
    out = {}
    N = len(tl)
    held = shot(ex_dir, E + 1)
    stars = 0
    out['held_differ'] = []
    for f in range(E + 2, E + 1 + BS.MUSIC_WAIT):
        n, st = differ(shot(ex_dir, f), held)
        stars += st
        if n:
            out['held_differ'].append((f, n))

    def want(k, lp, ls):
        fp, fs = (tl[k - lp - 1], tl[k - ls - 1])
        return BS.compose(fs['list'] or [] if fs['phase'] == 'page' else [], fp['ui'], fp['pt'], region, rgbf=SG.hb_rgb)
    pk = [fr['n'] for fr in tl if fr['phase'] == 'page' and fr['layer'] == BS.LAYER_PAGE]
    best = None
    for lp in (0, 1):
        for ls in (0, 1, 2):
            bad = sum((int((shot(ex_dir, E + k) != want(k, lp, ls)).any(-1).sum()) for k in pk[::12] if tl[k - ls - 1]['phase'] == 'page'))
            if best is None or bad < best[2]:
                best = (lp, ls, bad)
    lp, ls = best[:2]
    out['latency'] = dict(palette_layers=lp, sprites=ls)
    mism, pages, blacks = ([], 0, 0)
    for k in range(1 + max(lp, ls), N + 1):
        fp = tl[k - lp - 1]
        img = shot(ex_dir, E + k)
        if fp['layer'] == BS.LAYER_HIDE:
            blacks += 1
            if img.any():
                mism.append((k, E + k, 'not black'))
        elif fp['phase'] == 'page':
            pages += 1
            n = int((img != want(k, lp, ls)).any(-1).sum())
            if n:
                mism.append((k, E + k, n))
    out['page_frames_checked'], out['black_frames_checked'] = (pages, blacks)
    out['page_black_mismatch'] = mism[:10]
    out['page_black_mismatch_frames'] = len(mism)
    lum = {fr['n']: float(shot(ex_dir, E + fr['n'] + lp).mean()) for fr in tl if fr['phase'] in ('fade_out', 'return')}
    fo = [lum[fr['n']] for fr in tl if fr['phase'] == 'fade_out' and fr['level'] > 0]
    rt = [lum[fr['n']] for fr in tl if fr['phase'] == 'return' and fr['layer'] == 'game']
    lit = float(held.mean()) >= 1
    out['fade_out_darkens'] = all((x > y for x, y in zip(fo, fo[1:]))) if lit else all((x >= y for x, y in zip(fo, fo[1:])))
    out['return_brightens'] = all((x <= y for x, y in zip(rt, rt[1:]))) and (rt[-1] > rt[0] or not lit)
    out['fade_lum'] = dict(held=round(float(held.mean()), 1), fade_out=[round(x, 1) for x in fo], ret=[round(x, 1) for x in rt])
    post = []
    for k in range(1, POST + 1):
        n, st = differ(shot(ex_dir, E + N + k), shot(base_dir, E + k))
        stars += st
        if n:
            post.append((k, n))
    out['post_differ'] = post[:10]
    out['post_differ_frames'] = len(post)
    out['star_pixels_left_out'] = stars
    return out

def identity(ex, base, E, N):
    """Sync points: before the scene the same frame, after it N later; same checksums. -> problems."""
    bad = []
    for x, y in zip(ex['sync'], base['sync']):
        fb, fe = (int(y[1]), int(x[1]))
        want = fb if fb < E else fb + N
        if x[2] != y[2] or fe != want:
            bad.append((x[0], fe, fb, x[2], y[2]))
    if len(ex['sync']) < len(base['sync']) - 2:
        bad.append(('count', len(ex['sync']), len(base['sync'])))
    return bad[:10]

def unshifted(ex, base):
    return sum((1 for x, y in zip(ex['sync'], base['sync']) if x[1:] != y[1:]))

def review(a, ex_dir, E, tl, lat, set_name, sid):
    """A contact sheet (key frames) and an MP4 of every frame from 20 before the scene to 90 after it."""
    out = a.review
    out.mkdir(parents=True, exist_ok=True)
    N = len(tl)
    tag = f"{sid}_{('usa' if set_name == 'striderus01' else 'japan')}"
    keys = [('encounter: play stops', E + 1), ('held; the music has faded (n 24)', E + BS.MUSIC_WAIT)]
    keys += [(f'fade-out j {j}', E + BS.MUSIC_WAIT + j + lat) for j in (3, 6, 10)]
    keys += [('black', E + BS.MUSIC_WAIT + 20 + lat)]
    pages = sorted({fr['page'] for fr in tl if fr['phase'] == 'page'})
    for k in pages:
        pf = [fr for fr in tl if fr['phase'] == 'page' and fr['page'] == k]
        fade = next((fr['t'] for fr in pf if fr['level'] < BS.FULL and fr['t'] > BS.FADE_IN))
        for t in (2, 12, 60, fade - 1, fade + 4):
            fr = next((x for x in pf if x['t'] == t), None)
            if fr:
                keys.append((f"page {k + 1} t {t} (voice {fr['u'] - BS.HOLD_FROM:+d})", E + fr['n'] + lat))
    r0 = next((fr['n'] for fr in tl if fr['phase'] == 'return'))
    keys += [(f'return r {r}', E + r0 + r + lat) for r in (1, 4, 8, 12)]
    keys += [('fight resumes (+1)', E + N + 1), ('fight +60', E + N + 60)]
    from PIL import ImageDraw
    W, H = (384, 224)
    cols = 4
    rows = -(-len(keys) // cols)
    sheet = Image.new('RGB', (cols * (W + 8) + 8, rows * (H + 24) + 30), (30, 30, 34))
    d = ImageDraw.Draw(sheet)
    d.text((8, 8), f"Strider EX boss scene: {sid}, {tag.split('_')[-1].upper()} ({set_name}{N} frames from frame {E}", fill=(255, 220, 120))
    for i, (label, f) in enumerate(keys):
        x, y = (8 + i % cols * (W + 8), 30 + i // cols * (H + 24))
        sheet.paste(Image.open(ex_dir / f'g_{f:05d}.png').convert('RGB'), (x, y + 16))
        d.text((x, y + 2), f'{label}  [frame {f}]', fill=(220, 220, 220))
    sheet.save(out / f'boss_scene_{tag}_sheet.png')
    frames = out / f'_frames_{tag}'
    if frames.exists():
        shutil.rmtree(frames)
    frames.mkdir()
    for k, f in enumerate(range(E - 20, E + N + 90)):
        os.link(ex_dir / f'g_{f:05d}.png', frames / f'{k:05d}.png')
    subprocess.run(['ffmpeg', '-v', 'error', '-y', '-framerate', '59.637', '-i', str(frames / '%05d.png'), '-vf', 'scale=768:448:flags=neighbor', '-c:v', 'libx264', '-pix_fmt', 'yuv420p', '-crf', '16', str(out / f'boss_scene_{tag}.mp4')], check=True)
    shutil.rmtree(frames)
    return [str(out / f'boss_scene_{tag}_sheet.png'), str(out / f'boss_scene_{tag}.mp4')]

def research_writes(sc):
    """The scenario's research writes as (frame, addr, value) per frame: pokes 'f:addr=v', ramps [f0, addr, v0, v1,"""
    out = []
    for item in PG.pokes_of(dict(pokes=sc.get('pokes', []), ramps=sc.get('ramps', []))):
        f, rest = item.split(':')
        addr, v = rest.split('=')
        out.append((int(f), addr, v))
    for f0, f1, addr, v in sc.get('holds', []):
        out += [(f, addr, v) for f in range(f0, f1 + 1)]
    return out

def holds_env(writes, shift=None):
    """STREX_HOLDS for the writes; with shift (E, N) a write after frame E goes N frames later, as the inputs do."""
    out = []
    for f, addr, v in writes:
        if shift and f >= shift[0]:
            f += shift[1]
        out.append(f'{f},{f},{addr},{v}')
    return ';'.join(out)

def variants(build, machine, rom_dir):
    """The build's files and the gate's variants (see the module doc)."""
    import build_ex as BX
    built = {q.name: q.read_bytes() for q in (build / machine).iterdir() if q.is_file()}
    stock = {q.name: q.read_bytes() for q in (rom_dir / machine).iterdir() if q.is_file()}
    layout = RF.SETS[machine]
    files = dict(stock, **{k: v for k, v in built.items() if k in stock})
    sizes = {n: len(files[n]) for n, _, _ in layout}
    img = RF.compose(files, layout)
    at = BX.HOOKS[machine]
    if img[at:at + 2] != b'N\xb9':
        sys.exit(f'{machine}: the stage-intro hook at {at:#x} is not a jsr')
    img[at:at + 6] = BX.HOOK_BYTES
    ex = dict(built, **{n: b for n, b in RF.decompose(img, layout, sizes).items() if n in built})
    rep = json.loads((build / 'build.json').read_text())
    syms = rep['sets'][machine]['boss_scene_syms']

    def bank_of(files):
        p6 = files['strex_p6.bin']
        return bytearray((b for i in range(0, len(p6), 2) for b in (p6[i + 1], p6[i])))

    def p6_of(bank):
        return bytes((b for i in range(0, len(bank), 2) for b in (bank[i + 1], bank[i])))
    bank = bank_of(built)
    k = syms['bs_play_stage'] - 1048576
    bank[k:k + 10] = bytes.fromhex('33fcb05500fff9ea4e75')
    base = dict(ex, **{'strex_p6.bin': p6_of(bank)})
    pack = dict(ex, **{'strex_p6.bin': flag_p6(built['strex_p6.bin'], 0)})
    bank = bank_of(built)
    vbl = syms['bs_vbl'] - 1048576
    slot = None
    for k in range(vbl, vbl + 64, 2):
        at = 1048576 + k
        if bank[k:k + 6] == b'N\xb9' + syms['bs_nop'].to_bytes(4, 'big'):
            bank[k + 2:k + 6] = syms['bs_ctl'].to_bytes(4, 'big')
            slot = at
        elif bank[k:k + 2] == b'a\x00' and at + 2 + int.from_bytes(bank[k + 2:k + 4], 'big', signed=True) == syms['bs_nop']:
            bank[k + 2:k + 4] = (syms['bs_ctl'] - at - 2).to_bytes(2, 'big', signed=True)
            slot = at
        elif bank[k] == 97 and bank[k + 1] and (at + 2 + int.from_bytes(bank[k + 1:k + 2], 'big', signed=True) == syms['bs_nop']):
            bank[k + 1:k + 2] = (syms['bs_ctl'] - at - 2).to_bytes(1, 'big', signed=True)
            slot = at
        if slot:
            break
    if slot is None:
        sys.exit('bs_vbl has no control slot (a call of bs_nop)')
    ctl = dict(ex, **{'strex_p6.bin': p6_of(bank)})
    return (dict(build=built, ex=ex, pack=pack, base=base, ctl=ctl), rep)

def seen(log):
    """The base variant's encounter marks (BS_SEEN written with the magic; the boot's RAM clear writes it too)."""
    return [int(r[0]) for r in log['regs'] if r[1] == 'seen' and r[2] == 'b055']

def entries_of(log, kind):
    return [int(r[0]) for r in log['regs'] if r[1] == kind]

def scene_checks(name, lg, b, E, N, tl, tl_pack, rep_scene):
    """The checks of one ex-like run against its base (module doc)."""
    r = {}
    fr = lg['frames']
    ent, ext = (entries_of(lg, 'entry'), entries_of(lg, 'exit'))
    entry, exit_ = (ent[0] if ent else None, ext[0] if ext else None)
    r['moment'] = dict(entry=entry, exit=exit_, scenes=len(ent))
    r['moment_ok'] = entry == E and exit_ is not None and (exit_ - entry == N) and (len(ent) == 1)
    r['freeze_dump_diff'] = freeze_diff(lg['dumps']['entry'], lg['dumps']['exit']) if 'exit' in lg['dumps'] else ['no exit']
    up = [x for x in fr if x['on'] == BS_MAGIC]
    r['freeze_frames'] = len(up)
    keys = ('sum', 'px', 'py', 'cx', 'cy', 'counter')
    r['freeze_changes'] = [x['f'] for x, y in zip(up, up[1:]) if any((x[k] != y[k] for k in keys))][:10]
    r['scene_gfx_writes_outside'] = [x['f'] for x in fr if x['gfxw'] and x['on'] != BS_MAGIC and (not (entry and exit_ and (entry <= x['f'] <= exit_ + 1)))][:10]
    vb = scene_vblanks(lg)
    dump = lg['dumps']['entry']
    glay = int.from_bytes(dump[16775642 - 16711680:16775644 - 16711680], 'big')
    gobj = int.from_bytes(dump[16775644 - 16711680:16775646 - 16711680], 'big')
    r['game_layer_obj'] = [f'{glay:#06x}', f'{gobj:#06x}']
    r['frames_bad'] = check_frames(vb, tl, dump, rep_scene, glay, gobj)
    snd = sound_writes(lg)
    during = [(f, v) for f, v, s in snd if s and v != 255]
    want = BS.sends(tl_pack if name.endswith('pack') else tl)
    n_of = {v['frame']: v['n'] for v in vb}
    r['sound_scene'] = [(f, n_of.get(f), f'{v:#04x}') for f, v in during]
    r['sound_want'] = {n: f'{v:#04x}' for n, v in want.items()}
    r['sound_ok'] = sorted(((n_of.get(f), v) for f, v in during)) == sorted(want.items())
    after = [(f - N, v) for f, v, s in snd if not s and exit_ and (f > exit_) and (v != 255)][:8]
    stock = [(f, v) for f, v, s in sound_writes(b) if f > E and v != 255][:8]
    r['after_scene'] = [(f + N, f'{v:#04x}') for f, v in after]
    restart = rep_scene['restart']
    cue = None
    if restart == 'music_byte':
        cue = dump[16715973 - 16711680]
    elif restart == 'desert':
        cue = int.from_bytes(dump[16775478 - 16711680:16775480 - 16711680], 'big') & 255 or None
    if cue is None or cue == 255:
        r['restart'] = dict(kind=restart, cue=None)
        r['restart_ok'] = after == stock[:len(after)] and len(after) >= min(len(stock), 1)
    else:
        r['restart'] = dict(kind=restart, cue=f'{cue:#04x}')
        vals = [v for _, v in after]
        if cue in vals:
            vals.remove(cue)
        r['restart_ok'] = cue in [v for _, v in after] and vals == [v for _, v in stock][:len(vals)]
    if name.endswith('pack'):
        fade_n = next((n for n, v in want.items() if v == BS.FADE_CMD), None)
        first_fade = next((x['n'] for x in tl if x['phase'] == 'fade_out'))
        r['fade_before_screen'] = fade_n is not None and fade_n + BS.FADE_TICKS - 1 < first_fade
    r['identity'] = identity(lg, b, E, N)
    r['identity_control_unshifted'] = unshifted(lg, b)
    r['passed'] = bool(r['moment_ok'] and (not r['freeze_dump_diff']) and (not r['freeze_changes']) and (r['freeze_frames'] >= N - 1) and (not r['scene_gfx_writes_outside']) and (not r['frames_bad']) and r['sound_ok'] and r['restart_ok'] and (not r['identity']) and (r['identity_control_unshifted'] > 0) and r.get('fade_before_screen', True))
    return r

def pack_checks(M, lg, E, tl, rep_scene, model_music):
    """pack_model on a pack run's latch writes (with model_music under it when nothing plays at the encounter): the"""
    writes = [(f, v) for f, v, _ in sound_writes(lg)]
    ev, segs = M.run(writes)
    under = None
    if M.state(segs, E)[0] is None:
        under = model_music
        writes = [(E - 120, under), (E - 119, 255)] + [w for w in writes if w[0] > E - 119]
        ev, segs = M.run(writes)
    vb = scene_vblanks(lg)
    f_of = {v['n']: v['frame'] for v in vb}
    exit_ = entries_of(lg, 'exit')[0]
    first_fade = f_of[next((x['n'] for x in tl if x['phase'] == 'fade_out'))]
    fades = [s for s in segs if s[3] is not None and s[3].f0 >= E]
    voice = rep_scene['voice']['ja']
    vev = next((e for e in ev if e[1] == voice), None)
    out = dict(music_under=under and f'{under:#04x}', fade_lands=fades[0][3].end if fades else None, screen_fade_frame=first_fade, playing_at_screen_fade=M.state(segs, first_fade))
    if vev:
        x, m = M.pcm(vev[3])
        L = len(x) / m.sample_rate * PM_HZ
        out['voice'] = dict(cue=f'{voice:#04x}', frame=vev[0], effect=vev[4], track=vev[3], frames=round(L, 1), ends=round(vev[0] + L, 1), scene_end=exit_)
    after = next((e for e in ev if e[0] > exit_ and e[4] in ('start', 'drop')), None)
    out['restart'] = after
    out['ok'] = bool(fades and out['fade_lands'] < first_fade and (out['playing_at_screen_fade'][0] is None) and vev and (vev[4] == 'start') and (vev[0] + L <= exit_) and (after is None or after[4] == 'start'))
    return out
PM_HZ = 59.637

def gate_scene(a, work, machine, sets, var, rep, sid, binary, tbin, M, region):
    """One scene's runs and checks."""
    man = BS.manifest()
    scene = next((s for s in man['scenes'] if s['id'] == sid))
    sc = scene['gate']
    sct = sc if sid != 'stp_strongman' else dict(sc, inputs=man['gate_timing']['inputs'], holds=man['gate_timing']['holds'])
    brep = rep['boss_scene']
    rep_scene = next((s for s in brep['scenes'][machine] if s['id'] == sid))
    tl = BS.timeline(brep, rep_scene)
    tl_pack = BS.timeline(brep, rep_scene, pack=True)
    N = len(tl)
    F = sc['frames']
    wr, wrt = (research_writes(sc), research_writes(sct))
    report = dict(scene=sid, scene_frames=N)
    w = work / sid

    def first(k):
        if k == 'base':
            return (k, run(binary, sets['base'], a.set, w / 'base', sc, F + POST, sc['inputs'], holds=holds_env(wr)))
        return (k, run(tbin, sets['base'], a.set, w / 't_base', sct, F + POST, sct['inputs'], holds=holds_env(wrt)))
    with ThreadPoolExecutor(2) as ex:
        logs = dict(ex.map(first, ['base'] + (['t_base'] if tbin else [])))
    E = next(iter(seen(logs['base'])), None)
    Et = next(iter(seen(logs['t_base'])), None) if tbin else None
    if E is None or (tbin and Et is None):
        sys.exit(f'{sid}: base never reaches the encounter')
    report['encounter_frame'], report['timing_encounter_frame'] = (E, Et)
    jobs = {'ex': (binary, 'ex', F + N + POST, shift_inputs(sc['inputs'], N, E), f'{E - 25}-{E + N + POST + 2}', sc, wr, E), 'pack': (binary, 'pack', F + N + POST, shift_inputs(sc['inputs'], N, E), '', sc, wr, E), 'base_shots': (binary, 'base', F + POST, sc['inputs'], f'{E - 25}-{E + POST + 2}', sc, wr, None)}
    if a.control_scene == sid:
        jobs['ctl'] = (binary, 'ctl', E + 200, shift_inputs(sc['inputs'], N, E), '', sc, wr, E)
    if tbin:
        jobs['t_ex'] = (tbin, 'ex', F + N + POST, shift_inputs(sct['inputs'], N, Et), '', sct, wrt, Et)

    def go(k):
        b, v, frames, inputs, shots, s, writes, e = jobs[k]
        shift = (e, N) if e is not None else None
        return (k, run(b, sets[v], a.set, w / k, s, frames, inputs, shots, shift, holds=holds_env(writes, shift)))
    with ThreadPoolExecutor(a.jobs) as ex:
        logs.update(dict(ex.map(go, jobs)))
    ok = True
    for name in ['ex', 'pack'] + (['t_ex'] if tbin else []):
        e = Et if name == 't_ex' else E
        b = logs['t_base' if name == 't_ex' else 'base']
        r = scene_checks(name, logs[name], b, e, N, tl, tl_pack, rep_scene)
        report[name] = r
        ok &= r['passed']
        print(sid, name, json.dumps(r), flush=True)
    report['base_scene_gfx_writes'] = sum((x['gfxw'] for x in logs['base']['frames']))
    report['base_scene_started'] = any((x['on'] == BS_MAGIC for x in logs['base']['frames']))
    ok &= report['base_scene_gfx_writes'] == 0 and (not report['base_scene_started'])
    if 'ctl' in logs:
        up = [x for x in logs['ctl']['frames'] if x['on'] == BS_MAGIC]
        report['ctl_freeze_changes'] = len([1 for x, y in zip(up, up[1:]) if x['sum'] != y['sum'] or x['counter'] != y['counter']])
        ok &= report['ctl_freeze_changes'] > 0
    pic = check_pictures(logs['ex']['dir'], logs['base_shots']['dir'], E, tl, brep, rep_scene, region)
    report['pictures'] = pic
    ok &= not pic['held_differ'] and (not pic['page_black_mismatch']) and pic['fade_out_darkens'] and pic['return_brightens'] and (not pic['post_differ'])
    print(sid, 'pictures', json.dumps(pic), flush=True)
    if M:
        pm = pack_checks(M, logs['pack'], E, tl, rep_scene, int(man['gate_model_music'], 16))
        report['pack_model'] = pm
        ok &= pm['ok']
        print(sid, 'pack_model', json.dumps(pm, default=str), flush=True)
    if a.review:
        report['review'] = review(a, logs['ex']['dir'], E, tl, pic['latency']['palette_layers'], a.set, sid)
    report['passed'] = bool(ok)
    return report

def gate_once(a, work, sets, binary, rep, machine):
    """Once per stage (boss_scenes.json gate_once): a death after the scene and the encounter again: no scene the second"""
    man = BS.manifest()
    o = man['gate_once']
    brep = rep['boss_scene']
    rep_scene = next((s for s in brep['scenes'][machine] if s['id'] == o['scene']))
    N = len(BS.timeline(brep, rep_scene))
    sc = dict(o, holds=[])
    w = work / 'once'
    base = run(binary, sets['base'], a.set, w / 'base', sc, o['frames'], o['inputs'])
    marks = seen(base)
    if not marks:
        sys.exit('once: base never reaches the encounter')
    E = marks[0]
    ex = run(binary, sets['ex'], a.set, w / 'ex', sc, o['frames'] + N, shift_inputs(o['inputs'], N, E) if o['inputs'] else '', shift=(E, N))
    deaths = [x['f'] for x, y in zip(base['frames'], base['frames'][1:]) if y['lives'] < x['lives']]
    out = dict(scene=o['scene'], encounter=E, base_marks=marks[:6], base_deaths=deaths[:4], ex_scenes=entries_of(ex, 'entry'), ex_exits=entries_of(ex, 'exit'), identity=identity(ex, base, E, N), sync_points=len(base['sync']))
    second = [m for m in marks if deaths and m > deaths[0]]
    out['second_encounter'] = second[0] if second else None
    out['passed'] = bool(second and len(out['ex_scenes']) == 1 and (out['ex_scenes'][0] == E) and (not out['identity']))
    print('once', json.dumps(out), flush=True)
    return out

def desert_portraits_variant(build, out):
    """A copy of a build with the boss scenes whose desert sections arm their in-play portraits again (bs_portrait -> jmp"""
    rep = json.loads((build / 'build.json').read_text())
    shutil.copytree(build, out, ignore=shutil.ignore_patterns('work'))
    for machine in PARENT.values():
        syms = rep['sets'][machine]['boss_scene_syms']
        p6 = (out / machine / 'strex_p6.bin').read_bytes()
        bank = bytearray((b for i in range(0, len(p6), 2) for b in (p6[i + 1], p6[i])))
        k = syms['bs_portrait'] - 1048576
        bank[k:k + 6] = b'N\xf9' + syms['pt_arm'].to_bytes(4, 'big')
        (out / machine / 'strex_p6.bin').write_bytes(bytes((b for i in range(0, len(bank), 2) for b in (bank[i + 1], bank[i]))))
    print('wrote', out)
    return 0

def main():
    if len(sys.argv) == 4 and sys.argv[1] == 'desert-portraits':
        return desert_portraits_variant(Path(sys.argv[2]).resolve(), Path(sys.argv[3]).resolve())
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('--build', type=Path, required=True)
    p.add_argument('--runtime', type=Path, required=True)
    p.add_argument('--timing-runtime', type=Path)
    p.add_argument('--hbmame', type=Path, required=True)
    p.add_argument('--rom-dir', type=Path, required=True)
    p.add_argument('--workdir', type=Path, required=True)
    p.add_argument('--set', default='striderus01', choices=sorted(PARENT))
    p.add_argument('--scenes', default='', help='scene ids (default: all of boss_scenes.json)')
    p.add_argument('--once', action='store_true', help='also the once-per-stage check (boss_scenes.json gate_once)')
    p.add_argument('--control-scene', default='stp_strongman', help='the scene whose runs include the freeze control')
    p.add_argument('--pack', type=Path)
    p.add_argument('--portraits', type=Path, required=True, help='the portrait_pce.py capture the build used: the source check rebuilds the scenes from it')
    p.add_argument('--review', type=Path)
    p.add_argument('--jobs', type=int, default=4)
    p.add_argument('--reuse', action='store_true', help='analysis only: read the runs an existing workdir holds')
    a = p.parse_args()
    global REUSE
    REUSE = a.reuse
    a.rom_dir, a.build = (a.rom_dir.resolve(), a.build.resolve())
    work = a.workdir.resolve()
    work.mkdir(parents=True, exist_ok=True)
    machine = PARENT[a.set]
    var, rep = variants(a.build, machine, a.rom_dir)
    sets = {v: work / f'set_{v}' for v in ('ex', 'pack', 'base', 'ctl')} if (work / 'set_ex').exists() else stage_sets(a, work, machine, var)
    binary = json.loads((a.runtime / 'runtime.json').read_text())['binary']
    tbin = json.loads((a.timing_runtime / 'runtime.json').read_text())['binary'] if a.timing_runtime else None
    region = PG.region_of(var['build'])
    M = None
    if a.pack:
        import pack_model as PM
        M = PM.Model(a.pack)
    ids = [x for x in a.scenes.split(',') if x] or [s['id'] for s in BS.manifest()['scenes']]
    src_ok, src_bad = BS.source_check(rep['boss_scene'], region, machine, a.rom_dir, a.portraits.resolve())
    print('source check', 'PASS' if src_ok else 'FAIL', src_bad[:10], flush=True)
    report = dict(set=a.set, scenes={}, source_check=dict(passed=src_ok, problems=src_bad[:40]))
    ok = src_ok
    for sid in ids:
        r = gate_scene(a, work, machine, sets, var, rep, sid, binary, tbin, M, region)
        report['scenes'][sid] = r
        ok &= r['passed']
        print(sid, 'PASS' if r['passed'] else 'FAIL', flush=True)
    if a.once:
        report['once'] = gate_once(a, work, sets, binary, rep, machine)
        ok &= report['once']['passed']
    report['passed'] = bool(ok)
    (work / 'report.json').write_text(json.dumps(report, indent=1, default=str) + '\n')
    print('PASS' if ok else 'FAIL')
    return 0 if ok else 1
BS_MAGIC = 45141
if __name__ == '__main__':
    sys.exit(main())
