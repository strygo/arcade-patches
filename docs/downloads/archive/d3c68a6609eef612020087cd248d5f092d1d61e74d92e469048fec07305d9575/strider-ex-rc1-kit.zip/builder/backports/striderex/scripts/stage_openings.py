"""Reconstruction helper."""
import argparse
import hashlib
import json
import os
import struct
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import numpy as np
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
ROOT = HERE.parents[2]
LUA = ROOT / 'backports/striderex/lua/stage_opening.lua'
DEBUG_START = ROOT / 'backports/striderex/lua/arcade_debug_start.lua'
MANIFEST = ROOT / 'backports/striderex/manifests/stage_openings.json'
SETS = ('striderua', 'striderjr')
STAGES = {0: ('steps', 1300), 1: ('fade', 1700), 2: ('fade', 1700), 3: ('fade', 1900), 4: ('fade', 2000)}
STABLE = 60
MAP_BYTES = 16384
PAL_BYTES = 6144
SNAP_BYTES = 3 * MAP_BYTES + PAL_BYTES
SCREEN = (384, 224)
ORIGIN = (64, 16)
TILE = {1: 8, 2: 16, 3: 32}
STAR_BITS = 48
ENABLE = {1: 2, 2: 4, 3: 8}
LAYER_AND = 65487
FONT = (28672, 28799)
SPACE = 28704
BACKDROP = 6142
PAGE = {1: 1024, 2: 2048, 3: 3072}
STARS = (4096, 6144)
PLAYER_MAP = {1: 9469952, 2: 9486336, 3: 9502720}
PLAYER_PAL = 9441280
REG = dict(obj=0, s1base=2, s2base=4, s3base=6, rowbase=8, palbase=10, s1x=12, s1y=14, s2x=16, s2y=18, s3x=20, s3y=22, st1x=24, st1y=26, st2x=28, st2y=30, rowoff=32, vctrl=34, layer=102, prio0=104, prio1=106, prio2=108, prio3=110, palctl=112)
SNAP_REGS = ('s1x', 's1y', 's2x', 's2y', 's3x', 's3y', 'st1x', 'st1y', 'st2x', 'st2y', 'vctrl')

def sha(b):
    return hashlib.sha256(b).hexdigest()

def scan(layer, col, row):
    """Map entry index of (col, row) (MAME cps1.cpp tilemap0/1/2_scan)."""
    if layer == 1:
        return (row & 31) + ((col & 63) << 5) + ((row & 32) << 6)
    if layer == 2:
        return (row & 15) + ((col & 63) << 4) + ((row & 48) << 6)
    return (row & 7) + ((col & 63) << 3) + ((row & 56) << 6)

def window(layer, sx, sy):
    """[(col, row, screen x, screen y)] of every map cell the picture shows at scroll (sx, sy)."""
    ts = TILE[layer]
    size = 64 * ts
    x0, y0 = ((sx + ORIGIN[0]) % size, (sy + ORIGIN[1]) % size)
    out = []
    for py in range(y0 - y0 % ts, y0 + SCREEN[1], ts):
        for px in range(x0 - x0 % ts, x0 + SCREEN[0], ts):
            out.append((px // ts % 64, py // ts % 64, px - x0, py - y0))
    return out

def cells(maps, layer, sx, sy):
    """{entry: (code, attr)} of the cells the picture shows."""
    m = maps[layer]
    out = {}
    for col, row, _, _ in window(layer, sx, sy):
        e = scan(layer, col, row)
        out[e] = struct.unpack_from('>HH', m, 4 * e)
    return out

def tile_offset(layer, code):
    """(region, byte offset) of a code's ROM tile: 'stock' (the 4 MB stock graphics, ST24M1: bank 0"""
    import cps1_gfx as G
    if layer == 1:
        if 28672 <= code <= 32767:
            return ('stock', 2097152 + 64 * (code & 32767))
        if 32768 <= code <= 49151:
            return ('ex', G.ex_offset('scr1', code))
    elif layer == 2:
        if 8192 <= code <= 16383:
            return ('stock', 128 * code & 2097151)
        if 32768 <= code <= 49151:
            return ('ex', G.ex_offset('scr2', code))
    else:
        if code <= 4095:
            return ('stock', 2097152 + 512 * code)
        if 14336 <= code <= 16383:
            return ('ex', G.ex_offset('scr3', code))
    raise SystemExit(f'stage_openings: SCROLL{layer} code {code:#06x} is outside the ranges the mapper serves')

class Tiles:
    """Tile pens from the stock graphics and (optionally) the EX region."""

    def __init__(self, stock, ex=None):
        self.src = dict(stock=stock, ex=ex)
        self.cache = {}

    def pens(self, layer, code, half=0):
        import cps1_gfx as G
        k = (layer, code, half)
        if k not in self.cache:
            region, off = tile_offset(layer, code)
            if self.src[region] is None:
                raise SystemExit(f'stage_openings: SCROLL{layer} code {code:#06x} needs the EX region')
            self.cache[k] = G.get_tile(self.src[region], off, TILE[layer], half if layer == 1 else None)
        return self.cache[k]

    def blank(self, layer, code):
        return all(((self.pens(layer, code, h) == 15).all() for h in ((0, 1) if layer == 1 else (0,))))

def parse(data, regs):
    """A capture's snapshot (<set>_stage<k>.bin and its registers)."""
    if len(data) != SNAP_BYTES:
        raise SystemExit(f'stage_openings: a snapshot of {len(data)} bytes, {SNAP_BYTES} expected')
    maps = {k: data[(k - 1) * MAP_BYTES:k * MAP_BYTES] for k in (1, 2, 3)}
    return dict(maps=maps, pal=data[3 * MAP_BYTES:], regs=dict(regs))

def layer_order(word):
    """Bottom to top: the layers of the four order fields (0 = sprites, 1-3 = SCROLL1-3)."""
    return [word >> s & 3 for s in (6, 8, 10, 12)]

def still(snap, tiles):
    """The still of a snapshot: which tile layers it shows (a layer whose shown cells are all blank"""
    r = snap['regs']
    word = r['layer']
    shown, why = ({}, {})
    for L in (1, 2, 3):
        if not word & ENABLE[L]:
            why[L] = 'off in the snapshot'
            continue
        cs = cells(snap['maps'], L, r[f's{L}x'], r[f's{L}y'])
        opaque = {e: v for e, v in cs.items() if not tiles.blank(L, v[0])}
        if not opaque:
            why[L] = 'blank'
            continue
        if L == 1:
            font = {e for e, v in opaque.items() if FONT[0] <= v[0] <= FONT[1]}
            if font and len(font) == len(opaque):
                why[L] = f'the HUD only ({len(font)} font cells)'
                continue
            if font:
                raise SystemExit(f'stage_openings: SCROLL1 mixes {len(font)} font cells with {len(opaque) - len(font)} cells of scenery')
            for code in sorted({v[0] for v in cs.values()}):
                if (tiles.pens(1, code, 0) != tiles.pens(1, code, 1)).any():
                    raise SystemExit(f"stage_openings: SCROLL1 code {code:#06x}'s halves differ (jtcps1 would show the other one)")
        shown[L] = cs
        why[L] = f'{len(cs)} cells, {len(opaque)} not blank'
    layer = word & ~sum((ENABLE[L] for L in (1, 2, 3) if L not in shown))
    order = layer_order(layer)
    top = order.index(0) if 0 in order else -1
    over = [L for L in shown if L in order and order.index(L) > top]
    if over:
        raise SystemExit(f'stage_openings: SCROLL{over[0]} is drawn over the sprites (layer word {layer:#06x})')
    pal = snap['pal']
    words = {}
    for L, cs in shown.items():
        for p in sorted({a & 31 for _, a in cs.values()}):
            off = PAGE[L] + 32 * p
            words[off] = struct.unpack_from('>16H', pal, off)
    if layer & STAR_BITS:
        for off in range(STARS[0], STARS[1], 32):
            words[off] = struct.unpack_from('>16H', pal, off)
    else:
        words[BACKDROP] = struct.unpack_from('>H', pal, BACKDROP)
    used = {f's{L}{c}' for L in shown for c in 'xy'} | ({'st1x', 'st1y', 'st2x', 'st2y'} if layer & STAR_BITS else set())
    regs = {k: r[k] if k in used or k == 'vctrl' else 0 for k in SNAP_REGS}
    return dict(layer=layer, regs=regs, shown=shown, palette=words, why=why, stars=bool(layer & STAR_BITS))

def blocks(st):
    """[(graphics RAM address in the player's buffers, words)]: runs of consecutive map entries, then"""
    out = []
    for L in sorted(st['shown']):
        es = sorted(st['shown'][L])
        run = []
        for e in es + [None]:
            if run and (e is None or e != run[-1] + 1):
                ws = []
                for x in run:
                    ws += list(st['shown'][L][x])
                out.append((PLAYER_MAP[L] + 4 * run[0], ws))
                run = []
            if e is not None:
                run.append(e)
    offs = sorted(st['palette'])
    run = []
    for o in offs + [None]:
        if run and (o is None or o != run[-1][0] + 2 * len(run[-1][1])):
            ws = []
            for _, w in run:
                ws += list(w)
            out.append((PLAYER_PAL + run[0][0], ws))
            run = []
        if o is not None:
            run.append((o, st['palette'][o]))
    return out
BAND_TOP, BAND_LINES = (192, 32)
BAND_SCROLL = {1: (65472, 0), 2: (65472, 0)}
BAND_MAP = {1: 9584640, 2: 9601024}
SET_B = 65536
BASE_REG = {1: 's1base', 2: 's2base', 3: 's3base'}
FADE_LEVELS = (0, 2, 4, 6, 8, 10, 12)

def band_layer(st):
    """The tile layer that draws a still's band: the first of SCROLL1, SCROLL2 the still does not show."""
    L = next((x for x in (1, 2) if x not in st['shown']), None)
    if L is None:
        raise SystemExit('stage_openings: a still shows SCROLL1 and SCROLL2: no free layer for the band')
    return L

def band(st):
    """The still with its band: the band layer, the picture's layer word (the scenery layers in their order,"""
    L = band_layer(st)
    order = layer_order(st['layer'])
    new = [x for x in order if x not in (0, L)] + [L, 0]
    if sorted(new) != [0, 1, 2, 3]:
        raise SystemExit(f"stage_openings: layer word {st['layer']:#06x} has no valid order")
    bits = sum((v << s for v, s in zip(new, (6, 8, 10, 12))))
    keep = st['layer'] & 49153
    word = keep | bits | st['layer'] & (14 | STAR_BITS) | ENABLE[L]
    black = keep | bits | ENABLE[L]
    regs = dict(st['regs'])
    regs[f's{L}x'], regs[f's{L}y'] = BAND_SCROLL[L]
    bases = {}
    for s, delta in (('A', 0), ('B', SET_B)):
        bases[s] = [(BAND_MAP[k] if k == L else PLAYER_MAP[k] + delta) >> 8 for k in (1, 2, 3)]
    return dict(layer=L, word=word, black=black, regs=regs, bases=bases)

def band_fills(codes, pals):
    """ss_fill's records (address, long words, long value), run once at the screen's entry: each band"""
    out = []
    for L in (1, 2):
        clear, black = codes[L]
        p = pals[L]
        out.append((BAND_MAP[L], 4096, clear << 16 | p))
        sx, sy = BAND_SCROLL[L]
        ts = TILE[L]
        if (BAND_TOP + ORIGIN[1] + sy) % ts or BAND_LINES % ts or (sx + ORIGIN[0]) % ts:
            raise SystemExit(f'stage_openings: the band is not whole SCROLL{L} tiles')
        r0, n = ((BAND_TOP + ORIGIN[1] + sy) // ts % 64, BAND_LINES // ts)
        for col in range(64):
            e = scan(L, col, r0)
            if scan(L, col, r0 + n - 1) != e + n - 1:
                raise SystemExit(f'stage_openings: SCROLL{L} band rows {r0}-{r0 + n - 1} cross a block of the scan')
            out.append((BAND_MAP[L] + 4 * e, n, black << 16 | p))
        for buf in (PLAYER_PAL, PLAYER_PAL + PAL_BYTES):
            out.append((buf + PAGE[L] + 32 * p, 8, 4026593280))
    return out

def band_palettes(stills):
    """The band's palette on each band layer's page: the first one no still's cells use on that layer."""
    out = {}
    for L in (1, 2):
        used = {a & 31 for st in stills if L in st['shown'] for _, a in st['shown'][L].values()}
        out[L] = next((p for p in range(32) if p not in used))
    return out

def stills_inc(stills, codes, pals):
    """stills.inc: the band's fills (ss_fill), the fade steps, then per still (ss_snaps) its record:"""
    L = ['; stills.inc: written by scripts/build_ex.py (scripts/stage_openings.py); ROM-derived, never committed', f'SS_STEPS equ {len(FADE_LEVELS)}                      ; fade steps below "as authored" (stage_openings.FADE_LEVELS)', 'ss_levels:', '        dc.w    ' + ','.join((f'${v << 12:04X}' for v in FADE_LEVELS)), 'ss_fills:                               ; the band: its maps and palettes (stage_openings.band_fills)']
    for addr, n, v in band_fills(codes, pals):
        L += [f'        dc.l    ${addr:06X}', f'        dc.w    {n - 1}', f'        dc.l    ${v:08X}']
    L += ['        dc.l    0', 'ss_snaps:'] + [f'        dc.l    ss_snap{k}' for k in range(len(stills))]
    for k, st in enumerate(stills):
        b = band(st)
        L += [f"ss_snap{k}:                                ; {', '.join((f'S{x} {v}' for x, v in st['why'].items()))}; band on SCROLL{b['layer']}", f"        dc.w    ${b['word']:04X},${b['black']:04X}", '        dc.w    ' + ','.join((f'${v:04X}' for v in b['bases']['A'])), '        dc.w    ' + ','.join((f'${v:04X}' for v in b['bases']['B'])), '        dc.w    ' + ','.join((f"${b['regs'][x]:04X}" for x in SNAP_REGS))]
        for addr, ws in blocks(st):
            L.append(f'        dc.l    ${addr:06X}')
            L.append(f'        dc.w    {len(ws) - 1}')
            for i in range(0, len(ws), 16):
                L.append('        dc.w    ' + ','.join((f'${w:04X}' for w in ws[i:i + 16])))
        L.append('        dc.l    0')
    return '\n'.join(L) + '\n'

def faded(word, step):
    """A color at a fade step (asm/stage_select.s ss_fade): its own level, at most the step's."""
    if step >= len(FADE_LEVELS):
        return word
    lv = FADE_LEVELS[step]
    return word if word >> 12 <= lv else word & 4095 | lv << 12

def digest(st):
    """A digest of what the still shows (the stage select gate compares it with the frame it represents)."""
    h = hashlib.sha256()
    h.update(struct.pack('>H', st['layer']))
    h.update(struct.pack(f'>{len(SNAP_REGS)}H', *(st['regs'][k] for k in SNAP_REGS)))
    for addr, ws in blocks(st):
        h.update(struct.pack(f'>I{len(ws)}H', addr, *ws))
    return h.hexdigest()

def report(st):
    return dict(layer=f"{st['layer']:#06x}", stars=st['stars'], layers={f'S{k}': v for k, v in st['why'].items()}, regs={k: f'{v:#06x}' for k, v in st['regs'].items()}, bytes=sum((6 + 2 * len(ws) for _, ws in blocks(st))) + 2 * len(SNAP_REGS) + 4, palettes=len(st['palette']), sha256=digest(st))

def rgb(word, rule='mame'):
    """A palette word on screen: MAME cps1_build_palette, or HBMAME's (components <= 1 are 0)."""
    bright = 15 + (word >> 12 << 1)
    out = []
    for s in (8, 4, 0):
        c = word >> s & 15
        v = c * 17 * bright // 45
        out.append(0 if rule == 'hb' and c <= 1 else v)
    return out

def render(st, tiles, rule='mame'):
    """The still's tile layers as the screen shows them (MAME video/cps1.cpp: the backdrop pen 0xBFF,"""
    W, H = SCREEN
    pal = {}
    for off, ws in st['palette'].items():
        for i, w in enumerate(ws):
            pal[off + 2 * i] = w
    img = np.zeros((H, W, 3), np.int32)
    img[:, :] = rgb(pal.get(BACKDROP, 0), rule)
    r = st['regs']
    for L in layer_order(st['layer']):
        if L == 0 or L not in st['shown']:
            continue
        ts = TILE[L]
        cs = st['shown'][L]
        for col, row, x, y in window(L, r[f's{L}x'], r[f's{L}y']):
            code, attr = cs[scan(L, col, row)]
            p = tiles.pens(L, code, col & 1)
            if attr & 32:
                p = p[:, ::-1]
            if attr & 64:
                p = p[::-1, :]
            base = PAGE[L] + 32 * (attr & 31)
            colors = np.array([rgb(pal.get(base + 2 * k, 0), rule) for k in range(16)])
            y0, x0 = (max(y, 0), max(x, 0))
            y1, x1 = (min(y + ts, H), min(x + ts, W))
            sub = p[y0 - y:y1 - y, x0 - x:x1 - x]
            mask = sub != 15
            region = img[y0:y1, x0:x1]
            region[mask] = colors[sub[mask]]
    return img.astype(np.uint8)

def sprite_mask(gfx_ram, bases):
    """Screen pixels any sprite of the lists at these OBJ bases can cover (the 16x16 block of every"""
    W, H = SCREEN
    m = np.zeros((H, W), bool)
    for base in bases:
        a = (base << 8) - 9437184
        for i in range(256):
            x, y, code, attr = struct.unpack_from('>4H', gfx_ram, a + 8 * i)
            if attr & 65280 == 65280:
                break
            nx, ny = ((attr >> 8 & 15) + 1, (attr >> 12 & 15) + 1)
            for dx in (-512, 0, 512):
                for dy in (-512, -256, 0, 256):
                    sx, sy = ((x & 511) - ORIGIN[0] + dx, (y & 511) - ORIGIN[1] + dy)
                    x0, y0 = (max(sx, 0), max(sy, 0))
                    x1, y1 = (min(sx + 16 * nx, W), min(sy + 16 * ny, H))
                    if x0 < x1 and y0 < y1:
                        m[y0:y1, x0:x1] = True
    return m

def desert_snapshot(desert, offsets):
    """The desert's opening as dz_setup draws it (asm/desert.s): the display map (dz_draw_all from the"""
    import desert_ex as DX
    rec = desert['restart'][0]
    camx, camy = struct.unpack_from('>HH', rec, 4)
    layer = struct.unpack_from('>H', rec, DX.RESTART_SIZE - 6)[0]
    mi = struct.unpack_from('>H', rec, DX.RESTART_SIZE - 2)[0]
    w = desert['worlds'][mi]
    grid, secs = (w['disp_grid'], b''.join(w['disp_secs']))
    m3 = bytearray(MAP_BYTES)
    w0 = (camx >> 5) - 6
    for col in range(w0, w0 + 24):
        for vr in range(64):
            e = scan(3, col & 63, vr)
            if 0 <= col < 32 * 12:
                gx, sc = divmod(col, 12)
                s = grid[(7 - vr // 8) * 32 + gx]
                v = secs[s * 384 + (7 - vr % 8) * 48 + sc * 4:][:4]
            else:
                v = struct.pack('>HH', 14337, 0)
            m3[4 * e:4 * e + 4] = v
    pal = bytearray(PAL_BYTES)
    for i, row in enumerate(desert['pal_words']):
        struct.pack_into('>16H', pal, PAGE[3] + 32 * i, *(int(v) for v in row))
    struct.pack_into('>H', pal, BACKDROP, desert['sky'])
    regs = {k: 0 for k in REG}
    regs.update(layer=layer & ~(ENABLE[1] | ENABLE[2]), vctrl=offsets['vctrl'], s3x=camx + offsets['s3x'] & 65535, s3y=offsets['s3y'] - camy & 65535)
    return dict(maps={1: bytes(MAP_BYTES), 2: bytes(MAP_BYTES), 3: bytes(m3)}, pal=bytes(pal), regs=regs, camera=[camx, camy])

def camera_offsets(openings):
    """SCROLL3's register from its layer object's X and Y at the fade's end (the setup's camera; play"""
    seen = set()
    for key, o in openings.items():
        if o['rule'] != 'fade':
            continue
        cx, cy = (int(v, 16) for v in o['camera'][4:6])
        r = {k: int(v, 16) for k, v in o['regs'].items()}
        seen.add((r['s3x'] - cx & 65535, r['s3y'] + cy & 65535, r['vctrl']))
    if len(seen) != 1:
        raise SystemExit(f'stage_openings: the stock SCROLL3 camera offsets disagree: {sorted(seen)}')
    dx, dy, vc = seen.pop()
    return dict(s3x=dx, s3y=dy, vctrl=vc)
ENDING_STILL = 's03'
ENDING_SIG = {1372: '303cffc0', 1482: '303c0300', 1502: '303c0700', 50150: '3b7c????8c74', 50228: '3b7c00008c2c3b7c00008c2e3b7c00008c343b7c00008c363b7c00008c3c3b7c00008c3e'}

def ending_snapshot(ending, prog, machine, offsets, name=ENDING_STILL):
    """A snapshot (parse()'s shape) of the ending's picture `name` as the roll shows it at full brightness"""
    import ending_ex as EE
    d = 0 if machine == 'striderua' else EE.JR_DELTA
    for a, h in ENDING_SIG.items():
        at = a - d if a >= 4096 else a
        got = prog[at:at + len(h) // 2].hex()
        if any((c != '?' and c != g for c, g in zip(h, got))):
            raise SystemExit(f"stage_openings: {machine}: the ending's registers at {at:#x}: {got} (want {h})")
    layer = struct.unpack_from('>H', prog, 50152 - d)[0]
    st = ending['stills']
    e = st['stills'][name]
    if 'pan_left' in e:
        raise SystemExit(f'stage_openings: the ending picture {name} pans; the still is a resting one')
    m2, m3 = (bytearray(MAP_BYTES), bytearray(MAP_BYTES))
    for k in range(4096):
        struct.pack_into('>HH', m2, 4 * k, EE.S2_BLANK, 0)
        struct.pack_into('>HH', m3, 4 * k, EE.S3_BLANK, 0)
    for i, (code, pal) in enumerate(e['s2']):
        c, r = divmod(i, 8)
        struct.pack_into('>HH', m2, 4 * scan(2, c, EE.S2_ROW0 + r), code, pal)
    for i, code in enumerate(e['s3']):
        c, r = divmod(i, 4)
        struct.pack_into('>HH', m3, 4 * scan(3, EE.S3_COL0 + c, EE.S3_ROW0 + r), code, 0)
    pal = bytearray(PAL_BYTES)
    struct.pack_into('>16H', pal, PAGE[3], *e['s3_palette'])
    struct.pack_into('>16H', pal, PAGE[2], *[61440] * 16)
    for p, ws in enumerate(st['s2_palettes']):
        struct.pack_into('>16H', pal, PAGE[2] + 32 * (p + 1), *ws)
    struct.pack_into('>H', pal, BACKDROP, 61440)
    regs = {k: 0 for k in REG}
    regs.update(layer=layer & ~ENABLE[1], vctrl=offsets['vctrl'], s2x=65472, s2y=768, s3x=65472, s3y=1792)
    return dict(maps={1: bytes(MAP_BYTES), 2: bytes(m2), 3: bytes(m3)}, pal=bytes(pal), regs=regs)

def stock_identity(rom_dir):
    """The stock sets the capture runs: every file's SHA-256, per set."""
    return {m: {q.name: sha(q.read_bytes()) for q in sorted((rom_dir / m).iterdir()) if q.is_file()} for m in SETS}

def read_tsv(path):
    lines = path.read_text().splitlines()
    head = lines[0].split('\t')
    return [dict(zip(head, l.split('\t'))) for l in lines[1:]]

def run_opening(binary, roms, machine, stage, rule, end, out, layer_and=LAYER_AND):
    """One run of lua/stage_opening.lua from the debug start (focus-safe, bounded)."""
    out.mkdir(parents=True, exist_ok=False)
    env = dict(os.environ, SDL_VIDEODRIVER='dummy', SDL_AUDIODRIVER='dummy', OUT=str(out), END=str(end), RULE=rule, STAGE=str(stage), STABLE=str(STABLE), LAYER_AND=f'{layer_and:04x}', STREX_DEBUG_START=str(DEBUG_START), STREX_STAGE=str(stage), STREX_AREA='0', STREX_END=str(end + 100), STREX_PREFIX=str(out / 'dbg'))
    cmd = [str(binary), machine, '-rompath', str(roms), '-nothrottle', '-video', 'none', '-sound', 'none', '-seconds_to_run', str(end // 50 + 30), '-skip_gameinfo', '-noautosave', '-cfg_directory', str(out / 'cfg'), '-nvram_directory', str(out / 'nv'), '-snapshot_directory', str(out), '-autoboot_script', str(LUA)]
    p = subprocess.run(cmd, env=env, cwd=out, capture_output=True, text=True, timeout=1800)
    (out / 'mame.log').write_text(p.stdout + p.stderr)
    if p.returncode:
        raise SystemExit(f'{out}: emulator exit {p.returncode}')
    return opening(out, stage, rule)

def regs_at(out, frame):
    regs, cam = ({}, None)
    for line in (out / f'regs_{frame:05d}.txt').read_text().splitlines():
        a, v = line.split('\t')
        if a == 'cam':
            cam = [int(x, 16) for x in v.split(',')]
            continue
        regs[int(a, 16)] = int(v, 16)
    return ({k: regs[o] for k, o in REG.items()}, cam)

def opening(out, stage, rule):
    """The opening frame of one run: the candidate its rule takes (a fade: its one completion; steps:"""
    rows = read_tsv(out / 'opening.tsv')
    cands = [int(r['frame']) for r in read_tsv(out / 'candidates.tsv')]
    by = {int(r['frame']): r for r in rows}
    play = next((int(r['frame']) for r in rows if r['mode'] == '4' and int(r['stage']) == stage and (r['palbase'] == '914000')), None)
    if play is None:
        raise SystemExit(f'{out}: stage {stage} never reached play')
    if rule == 'fade':
        if len(cands) != 1:
            raise SystemExit(f'{out}: {len(cands)} fade completions, 1 expected')
        f = cands[0]
        stable_to = f + STABLE
    else:
        before = [c for c in cands if c < play]
        if not before:
            raise SystemExit(f'{out}: no palette step before play')
        f = before[-1]
        stable_to = play
    key = lambda r: (r['crc1'], r['crc2'], r['crc3'], r['crcs'])
    changed = [g for g in range(f + 1, stable_to + 1) if g in by and key(by[g]) != key(by[f])]
    if changed or stable_to not in by:
        raise SystemExit(f'{out}: the palette pages change after the opening frame {f} (at {changed[:3]})')
    regs, _ = regs_at(out, f + 1)
    cam = [int(v, 16) for v in by[f]['cam'].split(',')]
    gfx = (out / f'gfx_{f + 1:05d}.bin').read_bytes()
    pal = (out / f'pal_{f:05d}.bin').read_bytes()
    if regs['palbase'] != 37184:
        raise SystemExit(f"{out}: palette base {regs['palbase']:#06x}, the game's 0x9140 expected")
    maps = b''
    for k in ('s1base', 's2base', 's3base'):
        a = (regs[k] << 8) - 9437184
        if not 0 <= a <= len(gfx) - MAP_BYTES:
            raise SystemExit(f'{out}: {k} {regs[k]:#06x} outside graphics RAM')
        maps += gfx[a:a + MAP_BYTES]
    return dict(frame=f, shot=f + 1, play=play, rule=rule, candidates=cands, regs=regs, camera=cam, data=maps + pal, gfx=gfx)

def screen_check(out, r, tiles, rule='mame'):
    """The snapshot rendered (render(), every enabled layer with its shown cells) against the run's"""
    from PIL import Image
    snap = parse(r['data'], r['regs'])
    st = dict(layer=r['regs']['layer'], regs={k: r['regs'][k] for k in SNAP_REGS}, shown={L: cells(snap['maps'], L, r['regs'][f's{L}x'], r['regs'][f's{L}y']) for L in (1, 2, 3) if r['regs']['layer'] & ENABLE[L]}, palette={o: struct.unpack_from('>16H', snap['pal'], o) for o in range(0, PAL_BYTES, 32)})
    img = render(st, tiles, rule).astype(np.int32)
    shot = np.asarray(Image.open(out / f"s_{r['shot']:05d}.png").convert('RGB')).astype(np.int32)
    mask = ~sprite_mask(r['gfx'], (36864, 36928, r['regs']['obj']))
    bad = int(((img != shot).any(-1) & mask).sum())
    return (int(mask.sum()), bad)

def cmd_capture(a):
    import mapper_testkit as K
    import title_ex as TX
    out = a.out.resolve()
    out.mkdir(parents=True, exist_ok=False)
    rom_dir = a.rom_dir.resolve()
    jobs = [(m, st) for m in SETS for st in STAGES]
    with ThreadPoolExecutor(a.jobs) as ex:
        res = dict(zip(jobs, ex.map(lambda j: run_opening(a.mame, rom_dir, j[0], j[1], *STAGES[j[1]], out / 'runs' / f'{j[0]}_stage{j[1]}'), jobs)))
    rep = dict(schema=1, what="stage_openings.py capture: each arcade stage's opening, stock MAME, debug start at area 0", mame=subprocess.run([a.mame, '-version'], capture_output=True, text=True).stdout.strip(), inputs=stock_identity(rom_dir), openings={})
    ok = True
    for (m, st), r in res.items():
        tiles = Tiles(TX.stock_gfx(K.pool([rom_dir / m])))
        n, bad = screen_check(out / 'runs' / f'{m}_stage{st}', r, tiles)
        name = f'{m}_stage{st}.bin'
        (out / name).write_bytes(r['data'])
        rep['openings'][f'{m}_stage{st}'] = dict(file=name, sha256=sha(r['data']), frame=r['frame'], shot=r['shot'], play=r['play'], rule=r['rule'], regs={k: f'{v:#06x}' for k, v in r['regs'].items()}, camera=[f'{v:#06x}' for v in r['camera']], render_check=dict(pixels=n, mismatched=bad))
        ok &= bad == 0 and n > SCREEN[0] * SCREEN[1] // 2
        print(m, st, 'opening frame', r['frame'], 'play', r['play'], 'render check', n, 'pixels', bad, 'mismatched', 'sha256', sha(r['data'])[:16], flush=True)
    (out / 'openings.json').write_text(json.dumps(rep, indent=1) + '\n')
    print('PASS' if ok else 'FAIL: a snapshot does not render as MAME showed it')
    return 0 if ok else 1

def load(openings_dir, rom_dir=None):
    """A capture checked against manifests/stage_openings.json: the stock sets' identity (when rom_dir"""
    d = Path(openings_dir)
    rep = json.loads((d / 'openings.json').read_text())
    man = json.loads(MANIFEST.read_text())
    if rom_dir is not None:
        have = stock_identity(Path(rom_dir))
        for m, files in man['inputs'].items():
            for n, h in files.items():
                if have.get(m, {}).get(n) != h:
                    raise SystemExit(f'stage_openings: stock {m}/{n} is not the pinned input')
    out = {}
    for key, pin in man['openings'].items():
        o = rep['openings'].get(key)
        data = (d / pin['file']).read_bytes() if (d / pin['file']).exists() else b''
        if o is None or sha(data) != pin['sha256'] or o['sha256'] != pin['sha256'] or (o['frame'] != pin['frame']):
            raise SystemExit(f'stage_openings: {key}: the capture is not the pinned one (manifests/stage_openings.json)')
        m, st = key.split('_stage')
        out[m, int(st)] = parse(data, {k: int(v, 16) for k, v in o['regs'].items()})
    return (out, rep)

def cmd_check(a):
    snaps, rep = load(a.openings, a.rom_dir)
    print(f'{len(snaps)} snapshots match manifests/stage_openings.json')
    return 0

def self_test():
    assert scan(1, 0, 31) == 31 and scan(1, 1, 0) == 32 and (scan(1, 0, 32) == 2048)
    assert scan(2, 0, 15) == 15 and scan(2, 1, 0) == 16 and (scan(2, 0, 16) == 1024)
    assert scan(3, 0, 7) == 7 and scan(3, 1, 0) == 8 and (scan(3, 0, 8) == 512)
    assert len(window(1, 65472, 256)) == 48 * 28 and len(window(1, 810, 0)) == 49 * 28 and (len(window(1, 810, 3)) == 49 * 29)
    assert len(window(3, 65472, 1792)) == 12 * 8
    w = window(2, 65478, 640)
    assert w[0][2] == -6 and w[0][3] == 0 and (len(w) == 25 * 14)
    import cps1_gfx as G
    stock = bytearray(4 * G.MB)
    for code, pen in ((1, 3), (2, 15)):
        G.put_tile(stock, 2097152 + 512 * code, np.full((32, 32), pen))
    for code, pen in ((28737, 1), (28704, 15)):
        for h in (0, 1):
            G.put_tile(stock, 2097152 + 64 * code, np.full((8, 8), pen), h)
    G.put_tile(stock, 128 * 10272, np.full((16, 16), 15))
    maps = {1: bytearray(MAP_BYTES), 2: bytearray(MAP_BYTES), 3: bytearray(MAP_BYTES)}
    for e in range(4096):
        struct.pack_into('>HH', maps[1], 4 * e, 28704, 0)
        struct.pack_into('>HH', maps[2], 4 * e, 10272, 0)
        struct.pack_into('>HH', maps[3], 4 * e, 2, 0)
    struct.pack_into('>HH', maps[1], 4 * scan(1, 3, 34), 28737, 30)
    for col in range(4, 8):
        struct.pack_into('>HH', maps[3], 4 * scan(3, col, 60), 1, 5)
    pal = bytearray(PAL_BYTES)
    struct.pack_into('>16H', pal, PAGE[3] + 32 * 5, *[61731] * 16)
    struct.pack_into('>H', pal, BACKDROP, 61455)
    regs = {k: 0 for k in REG}
    regs.update(layer=3662, s1x=65472, s1y=256, s3x=65472, s3y=1792, vctrl=14)
    snap = parse(bytes(maps[1]) + bytes(maps[2]) + bytes(maps[3]) + bytes(pal), regs)
    st = still(snap, Tiles(stock))
    assert set(st['shown']) == {3} and st['layer'] == 3656, (st['why'], hex(st['layer']))
    assert set(st['palette']) == {PAGE[3] + 32 * 5, PAGE[3], BACKDROP}, sorted(st['palette'])
    bl = blocks(st)
    assert bl[0][0] == PLAYER_MAP[3] + 4 * scan(3, 0, 56), hex(bl[0][0])
    assert bl[0][1][:16] == list(struct.unpack('>16H', maps[3][4 * scan(3, 0, 56):][:32]))
    assert sum((len(ws) for a, ws in bl if PLAYER_MAP[3] <= a < PLAYER_MAP[3] + MAP_BYTES)) == 2 * 96
    img = render(st, Tiles(stock))
    y = 60 * 32 - 1808
    assert tuple(img[y + 4, 4 * 32 + 4]) == tuple(rgb(61731)) and tuple(img[0, 0]) == tuple(rgb(61455))
    b = band(st)
    assert b['layer'] == 1 and layer_order(b['word']) == [2, 3, 1, 0] and (b['word'] & 62 == 10), hex(b['word'])
    assert b['black'] & 62 == 2 and layer_order(b['black']) == layer_order(b['word'])
    assert b['regs']['s1x'] == 65472 and b['regs']['s1y'] == 0 and (b['regs']['s3y'] == 1792)
    assert b['bases']['A'] == [37440, 37056, 37120] and b['bases']['B'] == [37440, 37312, 37376]
    st2 = dict(st, shown={1: {}, 3: st['shown'][3]}, layer=3658)
    b2 = band(st2)
    assert b2['layer'] == 2 and layer_order(b2['word']) == [1, 3, 2, 0] and (b2['bases']['A'][1] == 37504)
    fills = band_fills({1: (32769, 32770), 2: (36865, 36866)}, {1: 3, 2: 4})
    rows = [(a, n, v) for a, n, v in fills if a < BAND_MAP[1] + MAP_BYTES and n == 4]
    assert len(rows) == 64 and rows[0] == (BAND_MAP[1] + 4 * 26, 4, 2147614723), rows[0]
    assert (BAND_MAP[2] + 4 * 13, 2, 2416050180) in fills and (PLAYER_PAL + 1024 + 96, 8, 4026593280) in fills
    assert band_palettes([st]) == {1: 0, 2: 0}
    assert faded(61731, 0) == 291 and faded(45347, 5) == 41251 and (faded(37155, 5) == 37155)
    assert faded(45347, len(FADE_LEVELS)) == 45347
    inc = stills_inc([st], {1: (32769, 32770), 2: (36865, 36866)}, {1: 3, 2: 4})
    assert 'ss_snap0:' in inc and f"        dc.w    ${b['word']:04X},${b['black']:04X}" in inc
    struct.pack_into('>HH', maps[1], 4 * scan(1, 10, 40), 29441, 0)
    G.put_tile(stock, 2097152 + 64 * 29441, np.full((8, 8), 2), 0)
    G.put_tile(stock, 2097152 + 64 * 29441, np.full((8, 8), 2), 1)
    try:
        still(parse(bytes(maps[1]) + bytes(maps[2]) + bytes(maps[3]) + bytes(pal), regs), Tiles(stock))
        raise AssertionError('a SCROLL1 mixing the HUD with scenery was accepted')
    except SystemExit:
        pass
    struct.pack_into('>HH', maps[1], 4 * scan(1, 3, 34), 28704, 0)
    G.put_tile(stock, 2097152 + 64 * 29441, np.full((8, 8), 3), 1)
    try:
        still(parse(bytes(maps[1]) + bytes(maps[2]) + bytes(maps[3]) + bytes(pal), regs), Tiles(stock))
        raise AssertionError('a SCROLL1 code with different halves was accepted')
    except SystemExit:
        pass
    regs2 = dict(regs, layer=3 << 12 | 0 << 10 | 2 << 8 | 1 << 6 | 14)
    try:
        still(parse(bytes(maps[1]) + bytes(maps[2]) + bytes(maps[3]) + bytes(pal), regs2), Tiles(stock))
        raise AssertionError('a layer over the sprites was accepted')
    except SystemExit:
        pass
    print('stage_openings self-test passed')
    return 0

def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('cmd', nargs='?', choices=['capture', 'check'])
    p.add_argument('--self-test', action='store_true')
    p.add_argument('--rom-dir', type=Path)
    p.add_argument('--out', type=Path)
    p.add_argument('--openings', type=Path)
    p.add_argument('--mame', default='mame')
    p.add_argument('--jobs', type=int, default=4)
    a = p.parse_args()
    if a.self_test:
        return self_test()
    if a.cmd == 'capture':
        if not (a.rom_dir and a.out):
            p.error('capture needs --rom-dir and --out')
        return cmd_capture(a)
    if a.cmd == 'check':
        if not (a.rom_dir and a.openings):
            p.error('check needs --rom-dir and --openings')
        return cmd_check(a)
    p.error('give a command or --self-test')
if __name__ == '__main__':
    sys.exit(main())
