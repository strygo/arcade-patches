"""Strider cross-version audio cue record: arcade, PC Engine CD, PSX."""
import argparse
import hashlib
import json
import re
import shutil
import subprocess
import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[3]
MAN = ROOT / 'cpsplus/manifests'
OUT_JSON = ROOT / 'backports/striderex/manifests/audio_cues.json'
OVERLAY = ROOT / 'backports/striderex/manifests/audio_cue_overlay.json'
SETS = {'striderua': [('30.11f', 'even0'), ('35.11h', 'odd0'), ('31.12f', 'even1'), ('36.12h', 'odd1'), ('st-14.8h', 'swap')], 'striderjr': [('sthj_23.8f', 'swap'), ('sthj_22.7f', 'swap')]}
SOUND_ROM = {'striderua': '09.12b', 'striderjr': 'sth_09.12a', 'strider': '09.12b'}
INTRO_TABLE_PATTERN = b'\\x10\\x2d\\x8c\\xb2\\x22\\x7c\\x00\\x00(..)\\x10\\x31\\x00\\x00\\x4e\\xf8(..)'
STAGE_NAMES = {0: 'St. Petersburg', 1: 'Siberia', 2: 'Amazon', 3: 'Aerial Battleship', 4: 'Third Moon'}
PLAY_ORDER = [0, 1, 3, 2, 4]

def sha1(b):
    return hashlib.sha1(b).hexdigest()

def find_file(set_dir, name):
    hits = list(set_dir.rglob(name))
    if not hits:
        sys.exit(f'{name} not found under {set_dir}')
    return hits[0].read_bytes()

def unpack(rom_dir, name, workdir):
    d = rom_dir / name
    if d.is_dir():
        return d
    for ext in ('.zip', '.7z'):
        arc = rom_dir / (name + ext)
        if arc.exists():
            out = workdir / name
            if out.exists():
                shutil.rmtree(out)
            out.mkdir(parents=True)
            subprocess.run(['7zz', 'e', '-y', f'-o{out}', str(arc)], check=True, capture_output=True)
            return out
    sys.exit(f'{name}: no directory, .zip or .7z under {rom_dir}')

def program_image(set_name, set_dir, parent_dir):
    parts = {}
    if set_name == 'striderua':
        for f, role in SETS[set_name]:
            try:
                parts[role] = (f, find_file(set_dir, f))
            except SystemExit:
                parts[role] = (f, find_file(parent_dir, f))

    def inter(e, o):
        return bytes((b for pair in zip(e, o) for b in pair))

    def swap(x):
        return bytes((c for i in range(0, len(x), 2) for c in (x[i + 1], x[i])))
    if set_name == 'striderua':
        img = inter(parts['even0'][1], parts['odd0'][1]) + inter(parts['even1'][1], parts['odd1'][1]) + swap(parts['swap'][1])
        files = {f: sha1(b) for f, b in parts.values()}
    else:
        lo = find_file(set_dir, 'sthj_23.8f')
        hi = find_file(set_dir, 'sthj_22.7f')
        img = swap(lo) + swap(hi)
        files = {'sthj_23.8f': sha1(lo), 'sthj_22.7f': sha1(hi)}
    return (img, files)

def stub_branches(img):
    """(address, cue, branch target) for every `move.w #cue,D0; bra.s/bra.w` in the stub area."""
    out = []
    for m in re.finditer(b'\\x30\\x3c\\x00(.)\\x60(.)', img, re.S):
        a = m.start()
        if a % 2 or not 18432 <= a <= 20480:
            continue
        d8 = m.group(2)[0]
        if d8 == 0:
            disp = int.from_bytes(img[a + 6:a + 8], 'big', signed=True)
        else:
            disp = d8 - 256 if d8 > 127 else d8
        out.append((a, m.group(1)[0], a + 6 + disp))
    return out

def send_entries(img):
    """The send routine's entry points: the two most common stub branch targets."""
    counts = {}
    for _, _, t in stub_branches(img):
        counts[t] = counts.get(t, 0) + 1
    return tuple(sorted(sorted(counts, key=counts.get, reverse=True)[:2]))

def setters(img, entries=None):
    """{entry address: (cue, gated)} for `move.w #cue,D0; bra send` stubs."""
    entries = entries or send_entries(img)
    out = {}
    for a, cue, target in stub_branches(img):
        if target not in entries:
            continue
        if img[a - 6:a - 2] == b'J-\x0b\x94' and img[a - 2] == 102:
            out[a - 6] = (cue, True)
        elif img[a - 8:a - 4] == b'J-\x0b\x94' and img[a - 4:a - 2] == b'f\x00':
            out[a - 8] = (cue, True)
        else:
            out[a] = (cue, False)
    return out

def callers(img, addr):
    """Call/jump sites of `addr`: jsr/jmp abs.w and abs.l, bsr.w and bsr.s."""
    a16 = addr.to_bytes(2, 'big')
    hits = set()
    for op in (b'N\xb8', b'N\xf8'):
        hits |= {m.start() for m in re.finditer(re.escape(op + a16), img)}
    for op in (b'N\xb9', b'N\xf9'):
        hits |= {m.start() for m in re.finditer(re.escape(op + b'\x00\x00' + a16), img)}
    for m in re.finditer(b'\\x61\\x00(..)', img, re.S):
        if m.start() + 2 + int.from_bytes(m.group(1), 'big', signed=True) == addr:
            hits.add(m.start())
    for m in re.finditer(b'\\x61([\\x01-\\xfe])', img, re.S):
        d = m.group(1)[0]
        if m.start() + 2 + (d - 256 if d > 127 else d) == addr:
            hits.add(m.start())
    return sorted((h for h in hits if h % 2 == 0))

def computed_sends(img, entries):
    found = []
    pat = b'|'.join((re.escape(op + e.to_bytes(2, 'big')) for op in (b'N\xb8', b'N\xf8') for e in entries))
    for m in re.finditer(pat, img):
        a = m.start()
        if a % 2 or 18432 <= a <= 20480:
            continue
        prev = img[a - 4:a]
        if prev[:2] == b'0<':
            found.append(dict(at=a, kind='immediate', value=int.from_bytes(prev[2:], 'big')))
        elif img[a - 2] == 112:
            found.append(dict(at=a, kind='immediate', value=img[a - 1]))
        else:
            found.append(dict(at=a, kind='computed'))
    return found

def intro_table(img):
    m = re.search(INTRO_TABLE_PATTERN, img, re.S)
    if not m:
        return (None, [])
    t = int.from_bytes(m.group(1), 'big')
    return (t, list(img[t:t + 5]))

def stage_orders(img, stub_cue):
    """Per stage: setter calls in address order inside the stage music handler."""
    by_cue = {}
    for entry, (cue, gated) in stub_cue.items():
        for c in callers(img, entry):
            by_cue.setdefault(cue, []).append(c)
    stages = {}
    for internal, (first, boss) in {0: (0, 5), 1: (6, 16), 2: (10, 13), 3: (24, 26), 4: (27, 29)}.items():
        lo = min(by_cue.get(first, [2147483647]))
        hi = max(by_cue.get(boss, [0]))
        seq = sorted(((c, cue) for cue, cs in by_cue.items() for c in cs if lo <= c <= hi and cue < 48))
        stages[internal] = [dict(at=c, cue=cue) for c, cue in seq]
    return (stages, by_cue)

def tune_table(snd):
    """(count address, entries address) of the first tune table, from the dispatch code"""
    m = re.search(b'\\x21(..)\\x11(..)\\x47\\x3e\\x00\\x32\\x04\\xf0', snd, re.S)
    if not m:
        raise ValueError('tune-table dispatch not found')
    return (int.from_bytes(m.group(1), 'little'), int.from_bytes(m.group(2), 'little'))

def driver_aliases(snd):
    cnt_at, ent_at = tune_table(snd)
    count = snd[cnt_at] + 1
    ptrs = [snd[ent_at + 2 * i] | snd[ent_at + 1 + 2 * i] << 8 for i in range(count)]
    groups = {}
    for i, p in enumerate(ptrs):
        groups.setdefault(p, []).append(i)
    return (count, ptrs, {i: groups[p][0] for i, p in enumerate(ptrs)})

def arcade_facts(set_name, rom_dir, workdir):
    set_dir = unpack(rom_dir, set_name, workdir)
    parent = unpack(rom_dir, 'strider', workdir) if (rom_dir / 'strider').exists() or any(((rom_dir / ('strider' + e)).exists() for e in ('.zip', '.7z'))) else set_dir
    img, files = program_image(set_name, set_dir, parent)
    snd = find_file(set_dir, SOUND_ROM[set_name])
    files[SOUND_ROM[set_name]] = sha1(snd)
    entries = send_entries(img)
    stubs = setters(img, entries)
    stub_cue = {e: c for e, (c, g) in stubs.items()}
    stages, by_cue = stage_orders(img, stubs)
    t_addr, intro = intro_table(img)
    count, ptrs, alias = driver_aliases(snd)
    sends = computed_sends(img, entries)
    return dict(set=set_name, files=files, program_sha1=sha1(img), send_entries=[f'{e:#07x}' for e in entries], setters={f'{c:#04x}': dict(entry=f'{e:#07x}', gated=stubs[e][1], callers=[f'{x:#07x}' for x in callers(img, e)]) for e, c in sorted(stub_cue.items(), key=lambda kv: kv[1])}, computed_sends=[dict(s, at=f"{s['at']:#07x}", **{'value': f"{s['value']:#04x}"} if 'value' in s else {}) for s in sends], intro_table=dict(at=None if t_addr is None else f'{t_addr:#07x}', cues=[f'{c:#04x}' for c in intro]), stage_order={STAGE_NAMES[k]: [f"{x['cue']:#04x}" for x in v] for k, v in stages.items()}, driver=dict(tunes=count, alias={f'{i:#04x}': f'{a:#04x}' for i, a in alias.items() if a != i}), emitted=sorted({f'{c:#04x}' for e, c in stub_cue.items() if callers(img, e)} | {f'{c:#04x}' for c in intro} | {s['value'] if isinstance(s.get('value'), str) else f"{s['value']:#04x}" for s in sends if 'value' in s}))

def build(a):
    a.workdir.mkdir(parents=True, exist_ok=True)
    arcade = {s: arcade_facts(s, a.rom_dir, a.workdir) for s in SETS}
    review = json.loads((MAN / 'strider_review_map.json').read_text())
    psx = {r['command']: r for r in json.loads((MAN / 'strider_psx_source_catalog.json').read_text())['commands']}
    titles = {}
    for line in (MAN / 'strider_track_titles.tsv').read_text().splitlines():
        f = line.split('\t')
        if len(f) >= 4 and f[0] == 'pce':
            titles[int(f[1])] = (f[2], f[3])
    decisions = {d['id']: d['verdict'] for d in json.loads((MAN / 'strider_listening_decisions.json').read_text())['decisions']}
    overlay = json.loads(OVERLAY.read_text())
    ua = arcade['striderua']
    rev1 = {}
    try:
        r1 = unpack(a.rom_dir, 'strider', a.workdir)
        snd1 = find_file(r1, SOUND_ROM['strider'])
        n1, p1, al1 = driver_aliases(snd1)
        n2, p2, al2 = driver_aliases(find_file(unpack(a.rom_dir, 'striderua', a.workdir), SOUND_ROM['striderua']))
        rev1 = dict(sound_sha1=sha1(snd1), tunes=n1, distinct=len(set(p1)), alias={f'{i:#04x}': f'{j:#04x}' for i, j in al1.items() if i != j}, differs_from_rev2=[f'{i:#04x}' for i in range(min(n1, n2)) if (al1[i] == i) != (al2[i] == i) or al1[i] != al2[i]])
    except (SystemExit, ValueError) as e:
        rev1 = dict(error=str(e))
    rows = []
    for r in review['rows']:
        cmd = r['command']
        p, s = (r.get('pce') or {}, r.get('psx') or {})
        ps = psx.get(cmd, {})
        pce_track = p.get('disc_track')
        stage = next((st for st, seq in ua['stage_order'].items() if cmd in seq), None)
        rows.append(dict(command=cmd, kind=r['kind'], arcade_title=r['role'], arcade_emitted=cmd in ua['emitted'], arcade_stage=stage, arcade_driver_alias_of=ua['driver']['alias'].get(cmd), pce=dict(track=pce_track, title=titles.get(pce_track, ('', ''))[0] if pce_track else None, pce_role=titles.get(pce_track, ('', ''))[1] if pce_track else None, research_proposal=p.get('disposition'), playback=p.get('playback'), listening=decisions.get(p.get('track'))), psx=dict(original_label=ps.get('original_label'), original=('xa' if ps.get('original_bank') == 0 else f"bank {ps.get('original_bank')} seq {ps.get('original_sequence')}") if ps else None, remix=(None if ps.get('remix_sequence', -1) < 0 else f"bank {ps['remix_bank']} seq {ps['remix_sequence']} ({ps['remix_label'].strip()})") if ps else None, pack_track=s.get('track') if s.get('disposition') == 'candidate' else None), ex=overlay['rows'].get(cmd, {})))
    for cmd in ('0x23',):
        ps = psx.get(cmd, {})
        rows.append(dict(command=cmd, kind='music', arcade_title='Time over (no VGM title)', arcade_emitted=cmd in ua['emitted'], arcade_stage=None, arcade_driver_alias_of=ua['driver']['alias'].get(cmd), pce=dict(track=None), psx=dict(original_label=ps.get('original_label'), original=f"bank {ps.get('original_bank')} seq {ps.get('original_sequence')}", remix=f"bank {ps['remix_bank']} seq {ps['remix_sequence']} ({ps['remix_label'].strip()})", pack_track=None), ex=overlay['rows'].get(cmd, {})))
    pce_only = overlay['pce_only']
    record = dict(description='Strider audio cues across arcade (striderua/striderjr), PC Engine CD and PSX; generated by scripts/audio_cue_map.py', arcade=arcade, arcade_rev1=rev1, rows=rows, pce_only=pce_only, ex_new_cues=overlay['ex_new_cues'], sources={p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in (MAN / 'strider_review_map.json', MAN / 'strider_psx_source_catalog.json', MAN / 'strider_track_titles.tsv', MAN / 'strider_listening_decisions.json', OVERLAY)})
    OUT_JSON.write_text(json.dumps(record, indent=1) + '\n')
    return record
GROUPS = [('Stage intros (play order)', ['0x11', '0x12', '0x1e', '0x13', '0x1f']), ('St. Petersburg', ['0x00', '0x04', '0x01', '0x02', '0x03', '0x05']), ('Siberia', ['0x06', '0x07', '0x08', '0x09', '0x10']), ('Aerial Battleship', ['0x18', '0x19', '0x1a']), ('Amazon', ['0x0a', '0x16', '0x0b', '0x0c', '0x0d']), ('Third Moon', ['0x1b', '0x1c', '0x1d']), ('Outcomes and ending', ['0x0f', '0x15', '0x0e', '0x23', '0x20', '0x21', '0x22']), ('Other', ['0x14', '0x17'])]

def markdown(rec):
    """Grouped tables in play order; the notes stay in the JSON."""
    rows = {r['command']: r for r in rec['rows']}
    out = []
    for title, cues in GROUPS:
        out += [f'**{title}**', '', '| Cue | Arcade tune | Arcade | PC Engine | PSX remix | PSX original | EX, PCE pack |', '|---|---|---|---|---|---|---|']
        for c in cues:
            r = rows[c]
            p, x, ex = (r['pce'], r['psx'], r['ex'])
            arc = 'sent' if r['arcade_emitted'] else 'never sent'
            if r['arcade_driver_alias_of']:
                arc += f", plays tune `{r['arcade_driver_alias_of']}`"
            pce = f"{p['track']:02d} {p['title']}" if p.get('track') else '—'
            out.append(f"| `{c}` | {r['arcade_title']} | {arc} | {pce} | {x.get('remix') or '—'} | {x.get('original') or '—'} | {ex.get('pce_pack', '—')} |")
        out.append('')
    return '\n'.join(out)

def self_test():
    img = bytearray(20480)
    img[18816:18822] = b'0<\x00\xf0`\xe8'
    a = 18936
    img[a:a + 4] = b'J-\x0b\x94'
    img[a + 4:a + 6] = b'f\x9a'
    img[a + 6:a + 10] = b'0<\x00\x06'
    disp = 18798 - (a + 12) & 65535
    img[a + 10:a + 12] = b'`\x00'
    img[a + 12:a + 14] = disp.to_bytes(2, 'big')
    s = setters(bytes(img), (18798,))
    assert s == {18816: (240, False), a: (6, True)}, s
    img[256:260] = b'N\xb8I\xf8'
    img[512:518] = b'N\xb9\x00\x00I\xf8'
    assert callers(bytes(img), a) == [256, 512], callers(bytes(img), a)
    snd = bytearray(4096)
    snd[316:326] = b'!P\x0e\x11S\x0eG>\x002'
    snd[326:328] = b'\x04\xf0'
    snd[3664] = 2
    snd[3667:3673] = bytes([179, 34, 191, 38, 179, 34])
    count, ptrs, alias = driver_aliases(bytes(snd))
    assert count == 3 and alias == {0: 0, 1: 1, 2: 0}, alias
    print('audio_cue_map self-test: ok')
    return 0

def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('--rom-dir', type=Path)
    p.add_argument('--workdir', type=Path)
    p.add_argument('--self-test', action='store_true')
    a = p.parse_args()
    if a.self_test:
        return self_test()
    if not (a.rom_dir and a.workdir):
        p.error('--rom-dir and --workdir are required')
    rec = build(a)
    for s, f in rec['arcade'].items():
        print(s, 'program', f['program_sha1'][:12], 'intro', f['intro_table']['cues'], 'stages', f['stage_order'])
        print('  emitted', ' '.join(f['emitted']))
    print(markdown(rec))
    return 0
if __name__ == '__main__':
    sys.exit(main())
