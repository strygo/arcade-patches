"""D9 study: the arcade staff roll and the PC Engine credit roll (track 29)."""
import argparse
import json
import os
import subprocess
import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent
BASE_LUA = ROOT / 'backports/striderex/lua/arcade_debug_start.lua'
CREDITS = ROOT / 'backports/striderex/manifests/pce_ending_credits.json'
FPS = 59.637
JR_DELTA = 600
SIG = {50060: '6100000c610000e2610001e8', 50146: '4eb84b54', 50348: '046d00018c2e026d01ff8c2e066d00012022', 50366: '0c6d00f82022', 50514: '3b7c0834201c', 51076: '3a3c001f47ea000049eb0002383c001f'}
BLOCKS = (51160, 51496, 51813)
RUN = dict(STREX_STAGE='4', STREX_AREA='10', STREX_INVINCIBLE='1', STREX_INVINCIBLE_END='1420', STREX_INPUTS='450-1400@6/3:P1_BUTTON1')
CHARSET_FRAME = 3300
WRAP_LUA = '\ndofile(os.getenv(\'STREX_BASE_LUA\'))\nlocal m=manager.machine\nlocal sp=m.devices[\':maincpu\'].spaces[\'program\']\nlocal prefix=os.getenv(\'STREX_PREFIX\')\nlocal charset=tonumber(os.getenv(\'STREX_CHARSET\') or \'\')\nlocal out=assert(io.open(prefix..\'_roll.tsv\',\'w\'))\nout:write(\'frame\\tphase\\ttext\\tfade\\ttimer\\tlines\\tscroll\\n\')\nlocal fr,prev=0,\'\'\nemu.register_frame_done(function()\n fr=fr+1\n local row=string.format(\'%d\\t%d\\t%d\\t%d\\t%d\\t%d\',sp:read_u8(0xff0cdc),sp:read_u8(0xff0cdd),sp:read_u16(0xffa01a),\n  sp:read_u16(0xffa01c),sp:read_u16(0xffa022),sp:read_u16(0xff0c2e))\n if row~=prev then out:write(fr..\'\\t\'..row..\'\\n\'); prev=row end\n out:flush()\n if charset and fr==charset then\n  -- research control: character codes 0x20-0x5F, 16 per map row, every other row, columns 0-15\n  local s=0x200-sp:read_u16(0xff0c2e)\n  local top=((s-241)>>3)+2\n  for i=0,63 do\n   local r=(top+2*(i//16))&0x3f\n   local a=0x908000+((r&0x20)<<8)+((i%16)<<7)+((r&0x1f)<<2)\n   sp:write_u16(a,0x7020+i); sp:write_u16(a+2,0x1e)\n  end\n  local f=assert(io.open(prefix..\'_charset.json\',\'w\'))\n  f:write(string.format(\'{"frame":%d,"scrolled":%d,"top_row":%d}\\n\',fr,s,top)); f:close()\n end\nend)\n'

def program(rom_dir, name, workdir):
    sys.path.insert(0, str(HERE))
    import audio_cue_map as ACM
    set_dir = ACM.unpack(rom_dir, name, workdir / 'sets')
    parent = ACM.unpack(rom_dir, 'strider', workdir / 'sets') if name == 'striderua' else None
    img, files = ACM.program_image(name, set_dir, parent)
    return (img, files)

def decode_block(img, start):
    """(rows, end): 32 rows, each up to 32 bytes, 0xFF ends a row."""
    rows, p = ([], start)
    for _ in range(32):
        row = bytearray()
        while len(row) < 32:
            c = img[p]
            p += 1
            if c == 255:
                break
            row.append(c)
        rows.append(row.decode('latin1'))
    return (rows, p)

def encode_block(rows):
    """Inverse of decode_block for rows shorter than 32 bytes (a 32-byte row has no terminator)."""
    assert len(rows) == 32
    return b''.join((r.encode('latin1') + (b'' if len(r) == 32 else b'\xff') for r in rows))

def static(img, delta):
    res = dict(signatures={}, blocks=[])
    for a, h in SIG.items():
        if delta and a == 50146:
            h = '4eb84b40'
        res['signatures'][hex(a - delta)] = img[a - delta:a - delta + len(h) // 2].hex() == h
    a = 50906 - delta
    res['text_state_table'] = [hex(50906 - delta + int.from_bytes(img[a + 2 * i:a + 2 * i + 2], 'big')) for i in range(5)]
    res['hold_frames'] = int.from_bytes(img[50516 - delta:50518 - delta], 'big')
    res['line_limit'] = int.from_bytes(img[50368 - delta:50370 - delta], 'big')
    for b in BLOCKS:
        rows, end = decode_block(img, b - delta)
        res['blocks'].append(dict(start=hex(b - delta), end=hex(end), rows=rows))
    return res

def mame_run(name, out, rompath, mame, end, shots, charset=None):
    out.mkdir(parents=True, exist_ok=True)
    lua = out / 'roll_wrap.lua'
    lua.write_text(WRAP_LUA)
    env = dict(os.environ, SDL_VIDEODRIVER='dummy', SDL_AUDIODRIVER='dummy', STREX_BASE_LUA=str(BASE_LUA), STREX_PREFIX=str(out / 'run'), STREX_END=str(end), STREX_SHOTS=','.join(map(str, shots)), **RUN)
    if charset:
        env['STREX_CHARSET'] = str(charset)
    cmd = [mame, name, '-rompath', str(rompath), '-nothrottle', '-video', 'none', '-sound', 'none', '-skip_gameinfo', '-noautosave', '-cfg_directory', str(out / 'cfg'), '-nvram_directory', str(out / 'nv'), '-snapshot_directory', str(out), '-autoboot_script', str(lua)]
    p = subprocess.run(cmd, env=env, cwd=out, capture_output=True, text=True, timeout=900)
    if p.returncode:
        sys.exit(f'{name}: MAME exit {p.returncode}\n{p.stderr[-2000:]}')

def roll_timeline(out):
    sys.path.insert(0, str(HERE))
    import arcade_ending_probe as AEP
    cues = AEP.read_log(out / 'run_log.tsv')
    rows = []
    for line in (out / 'run_roll.tsv').read_text().splitlines()[1:]:
        rows.append([int(x) for x in line.split('\t')])
    f21 = AEP.first_cue(cues, 33, 1000)
    f0e = AEP.first_cue(cues, 14, 1000)
    after = [r for r in rows if f21 and r[0] >= f21 - 10]

    def first(pred):
        return next((r[0] for r in after if pred(r)), None)
    t = dict(ending_0x21=f21, game_over_0x0e=f0e, scroll_start=first(lambda r: r[6] == 511), hold_start=first(lambda r: r[1] == 2), fade_out_start=first(lambda r: r[1] == 4))
    t['roll_end'] = first(lambda r: t['fade_out_start'] and r[0] > t['fade_out_start'] and (r[1] == 0))
    t['text_states'] = {}
    for r in after:
        t['text_states'].setdefault(str(r[2]), r[0])
    last = [r for r in after if t['roll_end'] and r[0] < t['roll_end']][-1]
    t['scrolled_px'] = sum((1 for a, b in zip(after, after[1:]) if b[6] != a[6] and t['scroll_start'] <= b[0] <= last[0])) + 1
    s = {}
    for k in ('hold_start', 'fade_out_start', 'roll_end', 'game_over_0x0e'):
        if t.get(k) and f21:
            s[k] = round((t[k] - f21) / FPS, 2)
    t['seconds_from_0x21'] = s
    return (t, rows)

def text_row_position(out, rows, frame):
    """Measured screen y of the first lit text row at `frame` (x < 152) and the scroll then."""
    from PIL import Image
    import numpy as np
    a = np.array(Image.open(out / f'run_{frame:05d}.png').convert('RGB')).astype(int)
    lit = np.nonzero(((a[:, :152, 0] > 200) & (a[:, :152, 2] < 140)).any(1))[0]
    sc = [r[6] for r in rows if r[0] <= frame][-1]
    return (int(lit[0]) if len(lit) else None, 512 - sc)

def font_atlas(out, workdir):
    """Cut 8x8 glyphs 0x20-0x5F (16 per row, every other map row) from the charset screenshot."""
    from PIL import Image
    import numpy as np
    meta = json.loads((out / 'run_charset.json').read_text())
    png = sorted(out.glob('run_*.png'))[-1]
    a = np.array(Image.open(png).convert('RGB'))
    lit = (a[:, :128].astype(int).sum(-1) > 0).any(1)
    expect = 8 * meta['top_row'] + 241 - meta['scrolled']
    band = [y for y in range(max(expect - 6, 0), expect + 7) if lit[y]]
    if not band:
        return None
    y0 = band[0]
    atlas = Image.new('RGB', (128, 32))
    for i in range(64):
        r, c = divmod(i, 16)
        atlas.paste(Image.fromarray(a[y0 + 16 * r:y0 + 16 * r + 8, 8 * c:8 * c + 8]), (8 * c, 8 * r))
    atlas.save(workdir / 'arcade_font_atlas.png')
    return dict(png=png.name, first_glyph_line=y0, expected=expect)

def cmd_arcade(a):
    w = a.workdir
    report = {}
    ok = True
    for name in ('striderua', 'striderjr'):
        img, files = program(a.rom_dir, name, w)
        st = static(img, 0 if name == 'striderua' else JR_DELTA)
        st['files'] = files
        ok &= all(st['signatures'].values()) and st['hold_frames'] == 2100 and (st['line_limit'] == 248)
        out = w / name
        mame_run(name, out, a.mame_rompath, a.mame, 5200, list(range(2200, 5200, 60)))
        tl, rows = roll_timeline(out)
        st['timeline'] = tl
        probe = 2680 if name == 'striderua' else 2560
        y, s = text_row_position(out, rows, probe)
        st['first_text_row'] = dict(frame=probe, screen_y=y, scrolled=s, block_row0_y_at_scroll0=None if y is None else y + s)
        ok &= tl['hold_start'] is not None and tl['hold_start'] - tl['fade_out_start'] == -2100
        report[name] = st
    out = w / 'striderua_charset'
    mame_run('striderua', out, a.mame_rompath, a.mame, CHARSET_FRAME + 4, [CHARSET_FRAME + 2], CHARSET_FRAME)
    report['font'] = font_atlas(out, w)
    ok &= report['font'] is not None
    (w / 'arcade_report.json').write_text(json.dumps(report, indent=1) + '\n')
    for name in ('striderua', 'striderjr'):
        print(name, json.dumps(report[name]['timeline']), json.dumps(report[name]['first_text_row']))
    print('PASS' if ok else 'FAIL')
    return 0 if ok else 1

def cmd_pce(a):
    import numpy as np
    from PIL import Image
    sys.path.insert(0, str(HERE))
    import pce_vdc as V
    import pce_cinematic_census as PC
    cap, w = (a.capture, a.workdir)
    idx = PC.read_index(cap)
    req = [r for r in PC.cd_requests(cap) if r[2] == 29]
    req_f, req_t = (req[0][0], req[0][1]) if req else (None, None)
    onset = PC.audio_onset(cap, req_t) if req else None
    frames = sorted(idx)
    rows = []
    for f in frames:
        d = V.load(cap / f'pce_{f:05d}_scene.vdc')
        bg, spr = V.render_layers(d)
        bg, spr = (bg[:224], spr[:224])
        rgb = V.pal_rgb(d['pal'])
        text = (bg >> 4 == 7) & (bg & 15 != 0) & (rgb[bg].astype(int).sum(-1) > 60)
        still = (bg & 15 != 0) & (bg >> 4 != 7) | (spr & 15 != 0)

        def bb(m):
            if not m.any():
                return None
            ys, xs = np.nonzero(m)
            return [int(xs.min()), int(ys.min()), int(xs.max()) + 1, int(ys.max()) + 1]
        t = float(idx[f]['time'])
        rows.append(dict(frame=f, t_audio=None if onset is None else round(t - onset, 3), text=bb(text), still=bb(still), overlap=int((text & still).sum())))
    pages, prev = ([], 'x')
    for r in rows:
        k = r['text']
        if k != prev:
            pages.append(dict(first=r['frame'], last=r['frame'], t0=r['t_audio'], text=k, still=r['still']))
            prev = k
        pages[-1]['last'] = r['frame']
        pages[-1]['t1'] = r['t_audio']
    pages = [p for p in pages if p['text'] and p['last'] - p['first'] >= 8]
    crops = {}
    for name, f, box in (('s00', 5904, (8, 16, 136, 144)), ('s01', 8098, (136, 80, 248, 208)), ('s02', 9800, (64, 16, 256, 144)), ('s03', 11100, (136, 80, 248, 208))):
        if f not in idx:
            continue
        d = V.load(cap / f'pce_{f:05d}_scene.vdc')
        bg, spr = V.render_layers(d)
        bg = np.where(bg >> 4 == 7, 0, bg)
        has = spr & 15 != 0
        idxs = np.where(has & ((spr & 16384 != 0) | (bg & 15 == 0)), spr & 511, bg)
        Image.fromarray(V.pal_rgb(d['pal'])[idxs][:224].astype(np.uint8)).crop(box).save(w / f'pce_still_{name}.png')
        crops[name] = dict(frame=f, box=box)
    rep = dict(cd_request_frame=req_f, audio_onset_s_after_request=None if onset is None else round(onset - req_t, 3), frames=len(rows), overlap_frames=sum((1 for r in rows if r['overlap'])), max_overlap_px=max((r['overlap'] for r in rows)), pages=pages, crops=crops)
    (w / 'pce_report.json').write_text(json.dumps(rep, indent=1) + '\n')
    for p in pages:
        print(f"{p['first']}-{p['last']}  t {p['t0']}-{p['t1']}  text {p['text']}  still {p['still']}")
    print('overlap frames', rep['overlap_frames'], 'max px', rep['max_overlap_px'])
    return 0
WIDTH = 19

def split_line(text, width=WIDTH):
    """Arcade-style wrap onto two adjacent rows (as T.F.'S FIRST / PLANNING ROOM): fill the first row,"""
    if len(text) <= width:
        return [text]
    w = text.split()
    i = max((k for k in range(1, len(w)) if len(' '.join(w[:k])) <= width))
    while i > 1 and (w[i - 1] == '&' or len(' '.join(w[i:])) <= 2):
        i -= 1
    return [' '.join(w[:i]), ' '.join(w[i:])]

def arcade_char(c):
    """Draft mapping to the roll font (charset probe): '.' is 0x2B ('+' in the table), '&' is 0x2A,"""
    return {'.': '+', '&': '*', '©': '-'}.get(c, c)

def draft_rows(credits):
    """Rows of the appended section in the arcade layout: a heading (wrapped onto adjacent rows), a blank,"""
    rows = []

    def heading(text):
        rows.extend((t.rjust(WIDTH) for t in split_line(text)))
        rows.append('')
    for p in credits['pages']:
        if p.get('heading') == 'END':
            continue
        if 'heading' in p:
            heading(p['heading'])
            rows.append('')
            continue
        if 'role' in p:
            heading(p['role'])
        for n in p['names']:
            rows.extend((n['display'].rjust(WIDTH), ''))
        rows.append('')
    while rows and rows[-1] == '':
        rows.pop()
    return rows

def align_plan(rows, plan, latency_s=0.0, first_row=96):
    """Pad rows so each still's first heading enters the screen at the PC Engine's cut time (track 29)."""
    cuts = (('STAFF', 's01', 56.5), ('VISUAL DEMO PART', 's02', 73.4), ('MANUFACTURED', 's03', 104.6))
    out, pads, base = ([], [], first_row)

    def enter_row(tau):
        return int(((tau + latency_s) * FPS - 33) / 3 - 16) // 8
    lead = enter_row(cuts[0][2]) - next((i for i, r in enumerate(rows) if r.strip() == cuts[0][0]))
    base = max(first_row, lead)
    out = list(rows)
    for key, still, tau in cuts:
        i = next((i for i, r in enumerate(out) if r.strip() == key))
        need = enter_row(tau) - base - i
        if need > 0:
            out[i:i] = [''] * need
        pads.append(dict(heading=key, still=still, cut_s=tau, pad_rows=max(need, 0), table_row=base + i + max(need, 0)))
    last = base + len(out) - 1
    s_fade = plan['scroll_px'] - 50
    return (dict(section_first_row=base, pads=pads, last_row=last, rows_after_padding=len(out), last_row_screen_y_at_fade_start=8 * last + 240 - s_fade, last_row_screen_y_at_end=8 * last + 240 - plan['scroll_px']), out)

def render_rows(atlas, rows):
    from PIL import Image
    im = Image.new('RGB', (152, 8 * len(rows)))
    for r, t in enumerate(rows):
        for c, ch in enumerate(t[:WIDTH]):
            code = ord(arcade_char(ch))
            if code == 32 or not 32 <= code <= 95:
                continue
            i = code - 32
            im.paste(atlas.crop((8 * (i % 16), 8 * (i // 16), 8 * (i % 16) + 8, 8 * (i // 16) + 8)), (8 * c, 8 * r))
    return im

def timing_plan(hold_arcade=2100, track_s=115.92, latency_s=0.0):
    """Hold length that ends the roll's fade with track 29, and the scroll it gives (1 px per 3 frames)."""
    setup, fade_in, fade_out = (30, 160, 150)
    total = round((track_s + latency_s) * FPS)
    hold = total - setup - fade_in - fade_out
    px = (fade_in + hold + fade_out) // 3
    px_arcade = (fade_in + hold_arcade + fade_out) // 3
    return dict(frames_from_0x21=total, hold_frames=hold, hold_hex=hex(hold), scroll_px=px, arcade_scroll_px=px_arcade, appended_px=px - px_arcade, appended_rows=(px - px_arcade) // 8)

def cmd_mockup(a):
    from PIL import Image
    w = a.workdir
    credits = json.loads(CREDITS.read_text())
    rows = draft_rows(credits)
    (w / 'draft_rows.txt').write_text('\n'.join((f'{i:3d}|{r}' for i, r in enumerate(rows))) + '\n')
    plan = timing_plan()
    plan['draft_rows'] = len(rows)
    plan['alignment'], padded = align_plan(rows, plan)
    (w / 'draft_rows_aligned.txt').write_text('\n'.join((f"{i + plan['alignment']['section_first_row']:3d}|{r}" for i, r in enumerate(padded))) + '\n')
    atlas = Image.open(w / 'arcade_font_atlas.png').convert('RGB')
    shots = []
    for name, still, first in (('cast', 's00', 0), ('visual_demo', 's02', None)):
        if first is None:
            first = next((i for i, r in enumerate(rows) if r.strip() == 'VISUAL DEMO PART')) - 2
        frame = Image.new('RGB', (384, 224))
        st = Image.open(w / f'pce_still_{still}.png').convert('RGB')
        frame.paste(st, (160 + (192 - st.width) // 2, 48 + (128 - st.height) // 2))
        y_off = 5
        text = render_rows(atlas, ([''] * 2 + rows)[first:first + 29])
        frame.paste(text, (0, y_off - 8), mask=text.convert('L').point(lambda v: 255 if v else 0))
        base = w / f'mockup_{name}'
        frame.save(f'{base}_384x224.png')
        frame.resize((768, 448), Image.NEAREST).save(f'{base}_768x448.png')
        shots.append(f'{base}_384x224.png')
    (w / 'mockup_plan.json').write_text(json.dumps(dict(plan=plan, mockups=shots), indent=1) + '\n')
    print(json.dumps(plan), *shots, sep='\n')
    return 0

def self_test():
    rows = ['    OBJECT DESIGNER', ''] + [''] * 30
    blob = encode_block(rows) + b'\x00'
    got, end = decode_block(blob, 0)
    assert got == rows and end == len(blob) - 1
    assert split_line('CHARACTER DESIGN & ANIMATE') == ['CHARACTER DESIGN', '& ANIMATE']
    assert split_line('ORIGINAL GAME MADE BY') == ['ORIGINAL GAME', 'MADE BY']
    assert split_line('EXECUTIVE PRODUCER') == ['EXECUTIVE PRODUCER']
    assert arcade_char('.') == '+'
    p = timing_plan(track_s=40.0)
    assert p['hold_frames'] == round(40 * FPS) - 340
    cr = dict(pages=[{'heading': 'CAST'}, {'role': 'HIRYU', 'names': [{'display': 'KANETO SHIOZAWA'}]}, {'heading': 'END'}])
    assert draft_rows(cr) == ['CAST'.rjust(19), '', '', 'HIRYU'.rjust(19), '', 'KANETO SHIOZAWA'.rjust(19)]
    cr['pages'][1:1] = [{'heading': h} for h in ('STAFF', 'VISUAL DEMO PART', 'MANUFACTURED')]
    al, padded = align_plan(draft_rows(cr), timing_plan())
    assert [p['table_row'] for p in al['pads']] == sorted((p['table_row'] for p in al['pads']))
    print('self-test ok')
    return 0

def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('--self-test', action='store_true')
    sub = p.add_subparsers(dest='cmd')
    s = sub.add_parser('arcade')
    s.add_argument('--rom-dir', type=Path, required=True, help='holds striderua/striderjr/strider as dirs, .zip or .7z')
    s.add_argument('--mame-rompath', type=Path, required=True)
    s.add_argument('--mame', default='mame')
    s.add_argument('--workdir', type=Path, required=True)
    s = sub.add_parser('pce')
    s.add_argument('--capture', type=Path, required=True, help='run_pce_scene_capture.py --pce-phase ending output')
    s.add_argument('--workdir', type=Path, required=True)
    s = sub.add_parser('mockup')
    s.add_argument('--workdir', type=Path, required=True, help='holds the arcade and pce outputs')
    a = p.parse_args()
    if a.self_test:
        return self_test()
    if not a.cmd:
        p.error('a subcommand is required')
    a.workdir = a.workdir.resolve()
    a.workdir.mkdir(parents=True, exist_ok=True)
    for k in ('rom_dir', 'mame_rompath', 'capture'):
        if getattr(a, k, None):
            setattr(a, k, getattr(a, k).resolve())
    return dict(arcade=cmd_arcade, pce=cmd_pce, mockup=cmd_mockup)[a.cmd](a)
if __name__ == '__main__':
    sys.exit(main())
