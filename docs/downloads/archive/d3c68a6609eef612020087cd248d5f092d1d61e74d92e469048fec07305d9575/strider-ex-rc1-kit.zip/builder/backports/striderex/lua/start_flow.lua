-- Strider EX: the start flow, from a coin and START to play (scripts/start_flow_gate.py).
--
-- Coin at frame COIN (9 frames), START at START (9 frames), no other input. Logs one row a
-- frame to OUT/frames.tsv: the EX player's state (ACTIVE, FRAMES = records played, the stream
-- pointer LZ_SRC), the game's mode word (0xFF0C12; 4 = play), stage, first-entry flag, intro
-- state, the last layer word written this frame (CPS-B +0x26; '-' = none) and the sound latch
-- writes of the frame other than 0xFF ('-' = none). A screenshot of every frame from SHOT_FROM
-- on (OUT/f_<frame>.png). Stops PLAY_TAIL frames after the first frame in play, or at END.
-- Write taps are anchored in _G (memory: a collected tap handle stops firing).
local m = manager.machine
local sp = m.devices[':maincpu'].spaces['program']
local screen = m.screens[':screen']
local fields = {}
for _, port in pairs(m.ioport.ports) do for _, field in pairs(port.fields) do
  fields[m.ioport:input_type_to_token(field.type, field.player)] = field end end
local out = assert(os.getenv('OUT'))
local last = tonumber(os.getenv('END') or '9000')
local coin = tonumber(os.getenv('COIN') or '200')
local start = tonumber(os.getenv('START') or '400')
local shot_from = tonumber(os.getenv('SHOT_FROM') or '390')
local tail = tonumber(os.getenv('PLAY_TAIL') or '60')
local log = assert(io.open(out .. '/frames.tsv', 'w'))
log:write('frame\tactive\trecords\tlz\tmode\tstage\tflag\tistate\tlayer\tsound\n')
local f, layer, sound, play_at = 0, nil, {}, nil
_G.strex_flow_layer = sp:install_write_tap(0x800166, 0x800167, 'layer', function(off, data, mask)
  layer = data & 0xffff end)
_G.strex_flow_snd = sp:install_write_tap(0x800180, 0x800181, 'snd', function(off, data, mask)
  local v = data & 0xffff
  if (v & 0xff) ~= 0xff then sound[#sound + 1] = string.format('%04x', v) end end)
emu.register_frame_done(function()
  f = f + 1
  if f >= coin and f <= coin + 8 then fields.COIN1:set_value(1) else fields.COIN1:clear_value() end
  if f >= start and f <= start + 8 then fields.START1:set_value(1) else fields.START1:clear_value() end
  local mode = sp:read_u16(0xff0c12)
  log:write(string.format('%d\t%04x\t%d\t%08x\t%d\t%d\t%d\t%d\t%s\t%s\n', f, sp:read_u16(0xfff914), sp:read_u32(0xfff900),
    sp:read_u32(0xfff904), mode, sp:read_u8(0xff0cb2), sp:read_u8(0xff0cba), sp:read_u8(0xff0cdc),
    layer and string.format('%04x', layer) or '-', #sound > 0 and table.concat(sound, ',') or '-'))
  layer, sound = nil, {}
  if f >= shot_from then screen:snapshot(string.format('%s/f_%05d.png', out, f)) end
  if mode == 4 and f > start and not play_at then play_at = f end
  if f >= last or (play_at and f >= play_at + tail) then log:close() m:exit() end
end)
