"""Strider EX native cinematic music: score every opening without a pack."""
import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import numpy as np
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
ROOT = HERE.parents[2]
CUES = ROOT / 'backports/striderex/manifests/ex_pack_cues.json'
LUA = ROOT / 'backports/striderex/lua/nopack_intros.lua'
DEBUG_START = ROOT / 'backports/striderex/lua/arcade_debug_start.lua'
HBSET = HERE / 'hbmame_set.py'
PARENT = {'striderus01': 'striderua', 'striderjs01': 'striderjr'}
HZ = 59.637
FLAG_AT = 1048574
BANK = 1048576
ON, HOLD = (49637, 49638)
STAGE_LIST = {0: ['prologue', 'brief_st_petersburg'], 1: ['brief_siberia'], 2: ['brief_amazon'], 3: ['brief_aerial'], 4: ['flight', 'welcome_meio'], 5: ['intro_desert']}
AUDITION = {'prologue': [20, 33, 27], 'intro_desert': [121, 122, 23], 'flight': [27, 28, 20]}
NAMES = {17: 'St. Petersburg Intro ~ Line of Defense', 18: 'Siberian Wilderness Intro', 30: 'The Aerial Battleship Intro (restored)', 19: 'Adventure in Amazon Intro', 31: 'The Third Moon Intro', 20: 'Credit', 33: 'Ending (restored, looped)', 27: 'The Third Moon 1 ~ Flying Dragon', 28: 'The Third Moon 2 ~ Swift Counterattack', 121: 'tune 0x01, St. Petersburg 2 (desert section 1 without a pack)', 122: 'tune 0x02, St. Petersburg 3 (desert sections 2-3 without a pack)', 23: 'Adventure in Amazon Opening 3 (unused) ~ Echo'}
SLOT = 110.0
END_DB = -60.0
LOOP_TOL = 0.004
FIRST_KEY = 0.25
STOP_WITHIN = 2
SKIP_AT = 0.4
SKIP_HOLD = 6
PLAY_TAIL = 300
MOST = 3000
END_FRAMES = 12000
REVIEW_LEAD = 60
REVIEW_TAIL = 600

def manifest():
    sec = json.loads(CUES.read_text())['nopack_intros']
    return ({r['id']: int(r['cue'], 16) for r in sec['rows']}, int(sec['stop'], 16))

def key_ons(ym, t0=0.0, t1=float('inf')):
    """[(t, channel, key code)] of the YM2151 key-ons in [t0, t1): register 0x08 with a slot mask, the key code"""
    kc, out = ([0] * 8, [])
    for t, reg, v in ym:
        if 40 <= reg <= 47:
            kc[reg - 40] = v
        elif reg == 8 and v & 120 and (t0 <= t < t1):
            out.append((t, v & 7, kc[v & 7]))
    return out

def find_loop(notes, tol=LOOP_TOL):
    """The loop of a key-on sequence: (start s, period s) for the smallest period with which the sequence, from"""
    n = len(notes)
    best = None
    for k in range(1, n // 2 + 1):
        d = notes[-1][0] - notes[-1 - k][0]
        if d < 1.0:
            continue
        a = n - k
        while a > 0:
            i = a - 1
            if notes[i][1:] != notes[i + k][1:] or abs(notes[i + k][0] - notes[i][0] - d) > tol:
                break
            a = i
        if n - k - a >= k and (best is None or d < best[1] - tol):
            best = (notes[a][0], d)
    return best

def audible_end(mix, sr, t0, t1, db=END_DB):
    """Seconds after t0 of the end of the last 50 ms window of mix[t0:t1] above db (full scale 32768); 0 if none."""
    a, b = (int(t0 * sr), int(t1 * sr))
    x = mix[a:b] / 32768.0
    w = int(0.05 * sr)
    n = len(x) // w
    if n == 0:
        return 0.0
    rms = np.sqrt((x[:n * w].reshape(n, w) ** 2).mean(1) + 1e-20)
    loud = np.nonzero(20 * np.log10(rms) > db)[0]
    return float((loud[-1] + 1) * w / sr) if len(loud) else 0.0

def scene_seconds(build_json):
    """{scene id: seconds the stream plays after its pre-roll} (its window's frames at the CPS-1 rate)."""
    return {s['id']: round(s['window']['frames'] / HZ, 3) for s in build_json['scenes']}

def measure(a):
    import sfx_gate as SG
    import build_ex as BX
    import pce_sfx as PS
    work = a.workdir.resolve()
    work.mkdir(parents=True, exist_ok=False)
    build = a.build.resolve()
    bj = json.loads((build / 'build.json').read_text())
    tunes, stop = manifest()
    continuous = json.loads(CUES.read_text())['nopack_intros'].get('mode') == 'continuous-native'
    rp = work / 'rompath' / 'striderua'
    rp.mkdir(parents=True)
    for q in (a.rom_dir.resolve() / 'striderua').iterdir():
        if q.is_file():
            shutil.copy(q, rp / q.name)
    members = [BX.SOUND_MEMBER['striderua'], *PS.SAMPLE_MEMBERS['striderua']]
    for n in members:
        shutil.copy(build / 'striderua' / n, rp / n)
    same_jp = all(((build / 'striderua' / u).read_bytes() == (build / 'striderjr' / j).read_bytes() for u, j in zip(members, [BX.SOUND_MEMBER['striderjr'], *PS.SAMPLE_MEMBERS['striderjr']])))
    auditions = {} if continuous else AUDITION
    cmds = [tunes[s] for s in tunes] + [c for s in auditions for c in auditions[s] if c not in tunes.values()]
    cmds = list(dict.fromkeys(cmds))
    r = SG.run(a.mame, work / 'rompath', 'striderua', work / 'run', cmds, SLOT)
    secs = scene_seconds(bj)
    out = dict(build=str(build), sound_sha256={n: PS.sha256((build / 'striderua' / n).read_bytes()) for n in members}, japan_sound_identical=same_jp, slot_s=SLOT, scenes_s=secs, commands={})
    for k, c in enumerate(cmds):
        t0 = r['slots'][k][1]
        notes = [(t - t0, ch, kc) for t, ch, kc in key_ons(r['ym'], t0, t0 + SLOT)]
        loop = find_loop(notes)
        if loop and notes[-1][0] < SLOT - loop[1] - 1.0:
            loop = None
        row = dict(name=NAMES.get(c, ''), key_ons=len(notes), first_key_on_s=round(notes[0][0], 3) if notes else None, last_key_on_s=round(notes[-1][0], 3) if notes else None, loops=loop is not None)
        if loop:
            row.update(loop_start_s=round(loop[0], 3), loop_period_s=round(loop[1], 3))
        else:
            row['sound_ends_s'] = round(audible_end(r['mix'], SG.SR, t0, t0 + SLOT), 2)
        out['commands'][f'{c:#04x}'] = row
    out['scenes'] = {}
    for sid, c in list(tunes.items()) + [(s, c) for s in auditions for c in auditions[s]]:
        row = out['commands'][f'{c:#04x}']
        length = secs[sid]
        v = dict(scene=sid, cue=f'{c:#04x}', scene_s=length, role='built' if tunes.get(sid) == c else 'audition')
        if row['loops']:
            v['verdict'] = f"loops (period {row['loop_period_s']} s from {row['loop_start_s']} s): plays to the scene's end"
        else:
            end = row['sound_ends_s']
            v['verdict'] = f'one-shot, sound ends at {end} s: ' + (f"{round(length - end, 2)} s of silence before the scene's end" if end < length else f'cut by the stop at {length} s')
        out['scenes'][f'{sid}:{c:#04x}'] = v
    out['passed'] = same_jp and (not continuous or all((out['commands'][f'{c:#04x}']['loops'] for c in tunes.values())))
    (work / 'measure.json').write_text(json.dumps(out, indent=1) + '\n')
    for k, v in out['commands'].items():
        print(k, json.dumps(v))
    for k, v in out['scenes'].items():
        print(k, v['scene_s'], 's:', v['verdict'])
    return 0 if out['passed'] else 1

def stage_set(hbmame, rom_dir, build, set_name, work, flag=0, patch=None):
    """A release set of the build (hbmame_set.py) with the flag byte or-ed in, and patch {bank offset: byte}."""
    machine = PARENT[set_name]
    src = work / 'ex' / machine
    src.mkdir(parents=True)
    for q in (build / machine).iterdir():
        b = q.read_bytes()
        if q.name == 'strex_p6.bin' and (flag or patch):
            b = bytearray(b)
            b[FLAG_AT] |= flag
            for off, v in (patch or {}).items():
                b[off ^ 1] = v
            b = bytes(b)
        (src / q.name).write_bytes(b)
    sets = work / 'sets'
    subprocess.run([sys.executable, str(HBSET), 'build', '--hbmame', str(hbmame), '--rom-dir', str(rom_dir), '--ex-dir', str(src.parent), '--set', set_name, '--date', '2026-10-10', '--out', str(sets)], check=True, stdout=subprocess.DEVNULL)
    return sets

def run(binary, sets, set_name, out, stage, skip=None, extra=(), tail=PLAY_TAIL, most=MOST, transition=None):
    """One HBMAME run (lua/nopack_intros.lua) -> dict(frames, latch, ym, meta)."""
    out.mkdir(parents=True)
    env = dict(os.environ, SDL_VIDEODRIVER='dummy', SDL_AUDIODRIVER='dummy', OUT=str(out), END=str(END_FRAMES), TAIL=str(tail), MOST=str(most), SKIP_HOLD=str(SKIP_HOLD))
    if transition:
        env.update({k: str(v) for k, v in transition.items()})
    if skip:
        env.update(SKIP_LO=str(skip[0]), SKIP_HI=str(skip[1]), SKIP_REC=str(skip[2]))
    if stage:
        env.update(STREX_DEBUG_START=str(DEBUG_START), STREX_STAGE=str(stage), STREX_AREA='0', STREX_END=str(END_FRAMES + 100), STREX_PREFIX=str(out / 'dbg'), STREX_INPUTS='')
    cmd = [str(binary), set_name, '-rompath', str(sets), '-nothrottle', '-video', 'none', '-sound', 'none', '-seconds_to_run', str(END_FRAMES // 50 + 30), '-skip_gameinfo', '-noautosave', '-cfg_directory', str(out / 'cfg'), '-nvram_directory', str(out / 'nv'), '-snapshot_directory', str(out), '-autoboot_script', str(LUA), *extra]
    p = subprocess.run(cmd, env=env, cwd=out, capture_output=True, text=True, timeout=3600)
    (out / 'mame.log').write_text(p.stdout + p.stderr)
    if p.returncode:
        raise SystemExit(f'{out}: HBMAME exit {p.returncode}')
    rd = lambda n: [l.split('\t') for l in (out / n).read_text().splitlines()]
    frames = [(int(f), int(r), int(lz, 16), int(ac, 16), int(e), int(md)) for f, r, lz, ac, e, md in rd('frames.tsv')]
    latch = [(int(f), int(ac, 16), int(v, 16)) for f, ac, v in rd('latch.tsv')]
    ym = [(int(f), float(t), int(rg, 16), int(v, 16)) for f, t, rg, v in rd('ym.tsv')]
    meta = {k: int(v) for k, v in rd('meta.tsv')}
    return dict(frames=frames, latch=latch, ym=ym, meta=meta, video=[tuple(map(int, row)) for row in rd('video.tsv')], pictures={q.stem: hashlib.sha256(q.read_bytes()).hexdigest() for q in out.glob('split_*.png')}, fade=[(int(f), int(v, 16)) for f, v in rd('fade.tsv')], oki=[(int(f), int(v, 16)) for f, v in rd('oki.tsv')], attenuation=[tuple(map(int, row)) for row in rd('atten.tsv')])

def scene_spans(r, streams):
    """{scene id: (first ON frame, end-mark frame or None, skip frame or None)} from the frame log: the scene is"""
    order = sorted(streams.items(), key=lambda kv: kv[1])
    out, cur = ({}, None)
    for f, rec, lz, ac, ended, md in r['frames']:
        if ac == ON and ended == 0:
            cur = max((s for s, at in order if at <= lz), key=lambda s: streams[s], default=None)
        elif ended == 0 or cur is None:
            continue
        sid = cur
        if sid is None:
            continue
        a, e, k = out.get(sid, (f, None, None))
        if ended == 1 and e is None:
            e = f
        if ended == 2 and k is None:
            k = f
        out[sid] = (a, e, k)
    return out

def ym_keys(r, f0, f1):
    """Key-on frames in [f0, f1)."""
    return [f for f, t, reg, v in r['ym'] if reg == 8 and v & 120 and (f0 <= f < f1)]

def next_command(r, after):
    """The frame of the first latch command below 0x80 (music or effect) after frame `after` (None: none)."""
    return next((f for f, ac, v in r['latch'] if f > after and v < 128), None)

def compare_tune(b, c, pack_b, sid, tune, stop, streams, pack_cue, skip=False):
    """The nopack checks of one tune scene: build run b against control run c (same inputs), pack_b the build's"""
    lb, lc = (b['latch'], c['latch'])
    facts, checks = ({}, {})
    extra = None
    i = j = 0
    diffs = []
    while i < len(lb) or j < len(lc):
        x = lb[i] if i < len(lb) else None
        y = lc[j] if j < len(lc) else None
        if x == y:
            i += 1
            j += 1
        elif x and y and (x[0] == y[0]) and (x[1] == y[1]) and (y[2] == 255):
            diffs.append(('replaced', x))
            i += 1
            j += 1
        elif x:
            diffs.append(('added', x))
            i += 1
        else:
            diffs.append(('missing', y))
            j += 1
    facts['latch_differences'] = [(k, f, f'{ac:#06x}', f'{v:#04x}') for k, (f, ac, v) in diffs]
    spans = scene_spans(b, streams)
    first, endmark, skipped = spans.get(sid, (None, None, None))
    facts.update(scene_first_frame=first, end_mark=endmark, skipped_at=skipped)
    cue = [x for k, x in diffs if k == 'replaced']
    stops = [x for k, x in diffs if k == 'added']
    pack_frame = next((f for f, ac, v in pack_b['latch'] if v == pack_cue and ac == ON), None) if pack_b else None
    facts['pack_cue_frame'] = pack_frame
    if skip and b['meta'].get('press') is not None:
        press = b['meta']['press']
        facts['press'] = press
        cue_ok = not cue if pack_frame is None or press <= pack_frame else True
        if cue:
            cue_ok = len(cue) == 1 and cue[0][2] == tune and (cue[0][1] == ON) and (pack_frame is None or cue[0][0] == pack_frame)
        checks['skipped'] = skipped is not None and skipped - press <= STOP_WITHIN
        checks['cue'] = cue_ok
        checks['stop'] = len(stops) == 1 and stops[0][2] == stop and (stops[0][1] == HOLD) and (0 <= stops[0][0] - press <= STOP_WITHIN)
    else:
        checks['cue'] = len(cue) == 1 and cue[0][2] == tune and (cue[0][1] == ON) and (pack_frame is not None) and (cue[0][0] == pack_frame)
        checks['stop'] = len(stops) == 1 and stops[0][2] == stop and (stops[0][1] == HOLD) and (endmark is not None) and (0 <= stops[0][0] - endmark <= 1)
    checks['nothing_else'] = all((k in ('replaced', 'added') for k, _ in diffs)) and len(diffs) <= 2
    facts['cue_frame'] = cue[0][0] if cue else None
    facts['stop_frame'] = stops[0][0] if stops else None
    if cue and stops:
        cf, sf = (cue[0][0], stops[0][0])
        keys = ym_keys(b, cf, sf + 1)
        facts['key_ons'] = len(keys)
        facts['span_s'] = round((keys[-1] - cf) / HZ, 2) if keys else None
        facts['first_key_on_frames'] = keys[0] - cf if keys else None
        checks['plays'] = bool(keys) and (keys[0] - cf) / HZ <= FIRST_KEY + 2 / HZ
    elif cue or not skip:
        checks['plays'] = False
    if stops:
        sf = stops[0][0]
        nxt = next_command(b, sf)
        stray = ym_keys(b, sf + 2, nxt if nxt is not None else 10 ** 9)
        stock = ym_keys(c, sf + 2, nxt if nxt is not None else 10 ** 9)
        facts['next_command_frame'] = nxt
        facts['key_ons_after_stop'] = len(stray)
        facts['control_key_ons_there'] = len(stock)
        checks['silent_after_stop'] = stray == stock
    hb = b['meta'].get('handback')
    music = next((f for f, ac, v in b['latch'] if hb and f > hb and (v < 48)), None)
    if music is not None:
        yb = [(f, reg, v) for f, t, reg, v in b['ym'] if f >= music and (not 16 <= reg <= 20)]
        yc = [(f, reg, v) for f, t, reg, v in c['ym'] if f >= music and (not 16 <= reg <= 20)]
        same = len(yb) == len(yc) and all((x[1:] == y[1:] and abs(x[0] - y[0]) <= 1 for x, y in zip(yb, yc)))
        facts['stage_music'] = dict(first_command_frame=music, ym_writes=len(yb), same=same, same_frames=[x[0] for x in yb] == [y[0] for y in yc])
        checks['stage_music'] = same and bool(yb)
    return dict(checks=checks, facts=facts, passed=all(checks.values()))

def identical(b, c):
    """With a pack (or a stage without a tune): the latch writes and the frame log (all but the stream pointer,"""
    fb = [(f, rec, ac, e, md) for f, rec, lz, ac, e, md in b['frames']]
    fc = [(f, rec, ac, e, md) for f, rec, lz, ac, e, md in c['frames']]
    first = next((x for x, y in zip(b['latch'], c['latch']) if x != y), None)
    return dict(latch_same=b['latch'] == c['latch'], latch_writes=len(b['latch']), frames_same=fb == fc, frames=len(fb), first_latch_difference=first, ym_same=[(f, rg, v) for f, t, rg, v in b['ym']] == [(f, rg, v) for f, t, rg, v in c['ym']])

def gate(a):
    if json.loads(CUES.read_text())['nopack_intros'].get('mode') == 'continuous-native':
        import cinematic_music_gate as CMG
        return CMG.gate(a)
    work = a.workdir.resolve()
    work.mkdir(parents=True, exist_ok=False)
    tunes, stop = manifest()
    binary = json.loads((a.runtime / 'runtime.json').read_text())['binary']
    builds = {'build': a.build.resolve(), 'control': a.control.resolve()}
    bjs = {k: json.loads((v / 'build.json').read_text()) for k, v in builds.items()}
    stages = [int(s) for s in a.stages.split(',')]
    jobs = []
    for set_name in a.sets.split(','):
        bset = bjs['build']['sets'][PARENT[set_name]]
        other = 1 if bset['region_en'] else 2
        for label in builds:
            for vname, flag in (('nopack', 0), ('pack', 1), (f'pack_voice{other}', 1 | other << 1)):
                for st in stages:
                    jobs.append(((label, set_name, vname, st, None), label, set_name, vname, flag, st, None))
            for st in stages:
                for sid in STAGE_LIST[st]:
                    if sid in tunes:
                        jobs.append(((label, set_name, 'nopack_skip', st, sid), label, set_name, 'nopack', 0, st, sid))
    sets_cache = {}

    def sets_for(label, set_name, flag):
        key = (label, set_name, flag)
        if key not in sets_cache:
            sets_cache[key] = stage_set(a.hbmame, a.rom_dir.resolve(), builds[label], set_name, work / 'sets' / f'{label}_{set_name}_{flag:02x}', flag)
        return sets_cache[key]
    for label in builds:
        for set_name in a.sets.split(','):
            bset = bjs['build']['sets'][PARENT[set_name]]
            other = 1 if bset['region_en'] else 2
            for flag in (0, 1, 1 | other << 1):
                sets_for(label, set_name, flag)

    def one(job):
        key, label, set_name, vname, flag, st, sid = job
        streams = bjs[label]['sets'][PARENT[set_name]]['streams']
        skip = None
        if sid:
            sc = next((s for s in bjs[label]['scenes'] if s['id'] == sid))
            order = sorted(streams.values())
            lo = streams[sid]
            skip = (lo, next((x for x in order if x > lo), 2097152), sc['preroll'] + int(sc['window']['frames'] * SKIP_AT))
        out = work / 'runs' / '_'.join((str(x) for x in key if x is not None))
        r = run(binary, sets_for(label, set_name, flag), set_name, out, st, skip)
        print('ran', out.name, r['meta'], flush=True)
        return (key, r)
    with ThreadPoolExecutor(a.jobs) as ex:
        res = dict(ex.map(one, jobs))
    report = dict(build=str(builds['build']), control=str(builds['control']), tunes={k: f'{v:#04x}' for k, v in tunes.items()}, stop=f'{stop:#04x}', results=[])
    ok, neg = (True, [])
    for set_name in a.sets.split(','):
        bset = bjs['build']['sets'][PARENT[set_name]]
        cset = bjs['control']['sets'][PARENT[set_name]]
        other = 1 if bset['region_en'] else 2
        lang = bset['region_en']
        for st in stages:
            tune_scenes = [s for s in STAGE_LIST[st] if s in tunes]
            for vname in ('pack', f'pack_voice{other}'):
                d = identical(res['build', set_name, vname, st, None], res['control', set_name, vname, st, None])
                passed = d['latch_same'] and d['frames_same']
                report['results'].append(dict(set=set_name, stage=st, variant=vname, facts=d, passed=passed))
                ok &= passed
                print(set_name, st, vname, 'PASS' if passed else 'FAIL', json.dumps(d), flush=True)
            b, c = (res['build', set_name, 'nopack', st, None], res['control', set_name, 'nopack', st, None])
            if not tune_scenes:
                d = identical(b, c)
                passed = d['latch_same'] and d['frames_same']
                report['results'].append(dict(set=set_name, stage=st, variant='nopack', facts=d, passed=passed))
                ok &= passed
                print(set_name, st, 'nopack (no tune)', 'PASS' if passed else 'FAIL', json.dumps(d), flush=True)
                continue
            pk = res['build', set_name, 'pack', st, None]
            fr = identical(b, c)
            for sid in tune_scenes:
                pack_cue = bset['cues'][sid][lang]
                r1 = compare_tune(b, c, pk, sid, tunes[sid], stop, bset['streams'], pack_cue)
                r1['frames_same'] = fr['frames_same']
                r1['passed'] &= fr['frames_same']
                report['results'].append(dict(set=set_name, stage=st, variant='nopack', scene=sid, **r1))
                ok &= r1['passed']
                print(set_name, st, sid, 'nopack', 'PASS' if r1['passed'] else 'FAIL', json.dumps(r1['checks']), json.dumps(r1['facts']), flush=True)
                bs, cs = (res['build', set_name, 'nopack_skip', st, sid], res['control', set_name, 'nopack_skip', st, sid])
                r2 = compare_tune(bs, cs, pk, sid, tunes[sid], stop, bset['streams'], pack_cue, skip=True)
                report['results'].append(dict(set=set_name, stage=st, variant='nopack_skip', scene=sid, **r2))
                ok &= r2['passed']
                print(set_name, st, sid, 'nopack skip', 'PASS' if r2['passed'] else 'FAIL', json.dumps(r2['checks']), json.dumps(r2['facts']), flush=True)
                rn = compare_tune(c, c, res['control', set_name, 'pack', st, None], sid, tunes[sid], stop, cset['streams'], cset['cues'][sid][lang])
                neg.append(dict(set=set_name, stage=st, scene=sid, failed=not rn['passed']))
    report['negative_control'] = neg
    neg_ok = bool(neg) and all((x['failed'] for x in neg))
    report['build_passed'] = ok
    report['negative_control_failed'] = neg_ok
    report['passed'] = ok and neg_ok
    (work / 'report.json').write_text(json.dumps(report, indent=1) + '\n')
    print('build', 'PASS' if ok else 'FAIL', '| negative control', 'fails as required' if neg_ok else 'DID NOT FAIL')
    print('PASS' if report['passed'] else 'FAIL')
    return 0 if report['passed'] else 1

def mp4(avi, out, f0, f1):
    """The AVI's frames [f0, f1) as an MP4 (H.264, 2x nearest-neighbor, AAC 192k)."""
    subprocess.run(['ffmpeg', '-v', 'error', '-y', '-ss', f'{(f0 - 1) / HZ:.4f}', '-i', str(avi), '-t', f'{(f1 - f0) / HZ:.4f}', '-vf', 'scale=iw*2:ih*2:flags=neighbor', '-c:v', 'libx264', '-crf', '18', '-pix_fmt', 'yuv420p', '-c:a', 'aac', '-b:a', '192k', str(out)], check=True)

def review(a):
    work = a.workdir.resolve()
    work.mkdir(parents=True, exist_ok=False)
    dest = a.out.resolve()
    dest.mkdir(parents=True, exist_ok=True)
    tunes, stop = manifest()
    binary = json.loads((a.runtime / 'runtime.json').read_text())['binary']
    build = a.build.resolve()
    bj = json.loads((build / 'build.json').read_text())
    jobs = []
    for set_name in a.sets.split(','):
        bset = bj['sets'][PARENT[set_name]]
        table = int(bset['nopack_cues_at'], 16) - BANK
        ids = [s['id'] for s in bj['scenes']]
        for st, lst in STAGE_LIST.items():
            for sid in lst:
                if a.scenes and sid not in a.scenes.split(','):
                    continue
                if sid in tunes and (not a.auditions_only):
                    jobs.append((set_name, st, sid, tunes[sid], None))
                for c in AUDITION.get(sid, []) if a.auditions_only or json.loads(CUES.read_text())['nopack_intros'].get('mode') != 'continuous-native' else []:
                    if sid in ids:
                        jobs.append((set_name, st, sid, c, {table + ids.index(sid): c}))

    def one(job):
        set_name, st, sid, c, patch = job
        tag = f"{('audition' if patch else 'tune')}_{set_name}_{sid}_{c:02x}"
        sets = stage_set(a.hbmame, a.rom_dir.resolve(), build, set_name, work / tag / 'set', 0, patch)
        out = work / tag / 'run'
        r = run(binary, sets, set_name, out, st, None, extra=('-aviwrite', 'clip.avi'), tail=REVIEW_TAIL, most=1 if patch else MOST)
        streams = bj['sets'][PARENT[set_name]]['streams']
        first, endmark, _ = scene_spans(r, streams)[sid]
        f0 = max(1, first - REVIEW_LEAD)
        f1 = r['meta']['play'] + REVIEW_TAIL if not patch else endmark + 30
        name = f"{set_name}_{('audition_' if patch else '')}{sid}_{c:02x}.mp4"
        mp4(out / 'clip.avi', dest / name, f0, f1)
        (out / 'clip.avi').unlink()
        cue = next((f for f, ac, v in r['latch'] if v == c and ac == ON), None)
        stp = next((f for f, ac, v in r['latch'] if v == stop and ac == HOLD), None)
        print('clip', name, flush=True)
        return dict(file=name, set=set_name, stage=st, scene=sid, cue=f'{c:#04x}', name=NAMES.get(c, ''), role='audition (not built)' if patch else 'built', clip_frames=[f0, f1], cue_at_s=round((cue - f0) / HZ, 2) if cue else None, stop_at_s=round((stp - f0) / HZ, 2) if stp else None, play_at_s=round((r['meta']['play'] - f0) / HZ, 2) if not patch and 'play' in r['meta'] else None)
    with ThreadPoolExecutor(a.jobs) as ex:
        rows = list(ex.map(one, jobs))
    old = json.loads((dest / 'review.json').read_text())['clips'] if (dest / 'review.json').is_file() else []
    rows = [c for c in old if c['file'] not in {r['file'] for r in rows}] + rows
    (dest / 'review.json').write_text(json.dumps(dict(build=str(build), clips=rows), indent=1) + '\n')
    return 0

def self_test():
    intro = [(0.1 * i, 0, 10 + i) for i in range(5)]
    fig = [(0.0, 1, 40), (0.5, 2, 41), (1.0, 1, 42), (1.5, 3, 43)]
    seq = intro + [(1.0 + 2.0 * r + t, ch, kc) for r in range(4) for t, ch, kc in fig]
    lp = find_loop(seq)
    assert lp and abs(lp[1] - 2.0) < 1e-09 and (abs(lp[0] - 1.0) < 1e-09), lp
    assert find_loop(intro) is None
    assert find_loop(seq[:5 + 6]) is None
    ym = [(0.0, 40, 74), (0.1, 8, 120), (0.2, 8, 0), (0.3, 41, 62), (0.4, 8, 121)]
    assert key_ons(ym) == [(0.1, 0, 74), (0.4, 1, 62)]
    sr = 1000
    mix = np.zeros(3 * sr)
    mix[:1500] = 3000.0
    assert abs(audible_end(mix, sr, 0, 3) - 1.5) < 0.051
    streams = {'s': 1048576}
    fr = [(f, 0, 1048576, ON if f < 10 else HOLD if f == 10 else 0, 1 if f == 9 else 0, 0) for f in range(1, 20)]
    c = dict(frames=fr, latch=[(f, ON, 255) for f in range(1, 10)] + [(15, 0, 6)], ym=[], meta={'handback': 11})
    b = dict(frames=fr, latch=[(f, ON, 18 if f == 3 else 255) for f in range(1, 10)] + [(9, HOLD, 241), (15, 0, 6)], ym=[(4, 0.0, 40, 64), (4, 0.0, 8, 120), (16, 0.0, 8, 120)], meta={'handback': 11})
    pk = dict(latch=[(3, ON, 163)])
    r = compare_tune(b, c, pk, 's', 18, 241, streams, 163)
    assert r['checks']['cue'] and r['checks']['stop'] and r['checks']['nothing_else'] and r['checks']['plays'], r
    assert r['checks']['silent_after_stop'] and (not r['checks']['stage_music'])
    rn = compare_tune(c, c, pk, 's', 18, 241, streams, 163)
    assert not rn['passed'] and (not rn['checks']['cue'])
    tunes, stop = manifest()
    assert stop == 241 and set(tunes) == {sid for rows in STAGE_LIST.values() for sid in rows}
    assert set(tunes.values()) == {36}
    import build_ex as BX
    contract = json.loads(CUES.read_text())
    assert BX.nopack_cues(contract) == tunes
    for mutation in ('missing', 'duplicate', 'zero'):
        bad = json.loads(CUES.read_text())
        rows = bad['nopack_intros']['rows']
        if mutation == 'missing':
            rows.pop()
        elif mutation == 'duplicate':
            rows.append(dict(rows[0]))
        else:
            rows[0]['cue'] = '0x00'
        try:
            BX.nopack_cues(bad)
        except SystemExit:
            pass
        else:
            raise AssertionError('invalid continuous score accepted: ' + mutation)
    import cinematic_music_gate as CMG
    CMG.self_test()
    print('self-test PASS')
    return 0

def main():
    if sys.argv[1:2] == ['--self-test']:
        return self_test()
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('command', choices=['measure', 'gate', 'review'])
    p.add_argument('--build', type=Path, required=True)
    p.add_argument('--control', type=Path)
    p.add_argument('--reference-build', type=Path, help='gate: reconstructed verified Kit s')
    p.add_argument('--runtime', type=Path)
    p.add_argument('--hbmame', type=Path)
    p.add_argument('--rom-dir', type=Path, required=True)
    p.add_argument('--workdir', type=Path, required=True)
    p.add_argument('--out', type=Path)
    p.add_argument('--mame', default='mame')
    p.add_argument('--sets', default='striderus01,striderjs01')
    p.add_argument('--stages', default='0,1,2,3,4,5')
    p.add_argument('--jobs', type=int, default=3)
    p.add_argument('--scenes', help='review: only these scene ids')
    p.add_argument('--auditions-only', action='store_true', help='review: the audition clips only')
    a = p.parse_args()
    if a.command == 'measure':
        return measure(a)
    if a.command == 'gate':
        if not (a.control and a.runtime and a.hbmame):
            p.error('gate needs --control, --runtime and --hbmame')
        return gate(a)
    if not (a.runtime and a.hbmame and a.out):
        p.error('review needs --runtime, --hbmame and --out')
    return review(a)
if __name__ == '__main__':
    sys.exit(main())
