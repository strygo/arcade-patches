; Complete the native opening follow while Third Moon is still black.
; Run the same SCROLL3 steps, including SCROLL2 parallax fractions, before
; the first fade-in draw. No sleep, sound, input or game task is advanced.
        org $1F5800
        movem.l d0-d7/a0-a6,-(sp)
        ; The game task installs these limits/follow lines on its first
        ; frame. Borrow its exact values early, then restore the old fields
        ; so that task's initialisation still happens on its original frame.
        movem.l $FF1016,d0-d3
        movem.l d0-d3,-(sp)
        move.l #X_LIMITS,$FF1016
        move.l #Y_LIMITS,$FF101A
        move.l #X_FOLLOW,$FF101E
        move.l #Y_FOLLOW,$FF1022
        move.w #32,-(sp)                ; bounded even if a future setup changes
.step:
        move.w $FF0FF8,-(sp)
        jsr S3
        move.w (sp)+,d0
        cmp.w $FF0FF8,d0
        beq.s .done
        subq.w #1,(sp)
        bne.s .step
.done:
        addq.l #2,sp
        jsr S2                         ; publish the final parallax shadow too
        movem.l (sp)+,d0-d3
        movem.l d0-d3,$FF1016
        movem.l (sp)+,d0-d7/a0-a6
        move.w #0,-$73E6(a5)            ; displaced native fade-level store
        rts
