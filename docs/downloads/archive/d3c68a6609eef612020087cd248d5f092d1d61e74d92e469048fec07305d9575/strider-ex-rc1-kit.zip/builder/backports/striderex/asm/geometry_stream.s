; Optional Method E cinematic stream operations 15/16. Installed by
; art_geometry.py in guarded free EX space. Legacy operations retain their
; original dispatch. Full SCROLL2 maps allow a 768-pixel source map instead
; of repeating a 512-pixel quadrant four times.
        org $1FFB00
geometry_next:
        move.w (a0)+,d0
        bne.s .word
        jmp GEOMETRY_DONE
.word:
        move.w d0,d1
        and.w #$00FF,d0
        cmp.w #15,d0
        beq.s .cells
        cmp.w #16,d0
        beq.s .run
        jmp GEOMETRY_LEGACY
.slot:  lsr.w #8,d1
        and.w #3,d1
        lsl.w #2,d1
        lea .slots(pc),a1
        move.l 0(a1,d1.w),a2
        rts
.cells: bsr.s .slot
        move.w (a0)+,d5
        bra.s .ct
.c:     move.l a2,a3
        add.w (a0)+,a3
        move.l (a0)+,(a3)
.ct:    dbra d5,.c
        bra geometry_next
.run:   bsr.s .slot
        move.w (a0)+,d5
        add.w (a0)+,a2
        bra.s .rt
.r:     move.l (a0)+,(a2)+
.rt:    dbra d5,.r
        bra geometry_next
.slots: dc.l $90C000,$91C000,$920000
geometry_end:
