"""Recreate Strider EX's media measurements from owned inputs in empty scratch."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
ROOT = Path(__file__).resolve().parents[3]
SCRIPTS = ROOT / 'backports/striderex/scripts'
NEW_GAME = '300-310:P1_START;3700-3710:P1_START;4000-4010:P1_START'

def run(script, *args):
    print('Reconstruct:', script, *map(str, args), flush=True)
    subprocess.run([sys.executable, str(SCRIPTS / script), *map(str, args)], check=True)

def capture(cue, bios, roms, mame, out, jobs=3):
    out.mkdir(parents=True, exist_ok=False)
    os.environ['STREX_MAME'] = str(mame)
    sys.path.insert(0, str(SCRIPTS))
    import pce_cinematic_census as C
    from types import SimpleNamespace
    a = SimpleNamespace(cue=cue, rompath=bios, workdir=out / 'cinematics', jobs=jobs)
    if C.cmd_capture(a, C.manifest()):
        raise ValueError('cinematic capture failed')
    if C.cmd_check(a, C.manifest()):
        raise ValueError('PC Engine rendering verification failed')
    if C.cmd_catalog(a, C.manifest()):
        raise ValueError('cinematic catalog failed')
    run('portrait_pce.py', 'capture', '--cue', cue, '--rompath', bios, '--workdir', out / 'portraits', '--jobs', jobs)
    windows = ['6201:6201:1', '6619:6619:1', '6711:6711:1', '6803:6803:1', '7420:7420:1']
    run('run_pce_scene_capture.py', '--cdrom', cue, '--rompath', bios, '--outdir', out / 'desert', '--end', 8000, '--pce-start-stage', 1, '--pce-checkpoint-census', *[v for w in windows for v in ('--window', w)])
    for cp in (1, 3):
        run('run_pce_scene_capture.py', '--cdrom', cue, '--rompath', bios, '--outdir', out / f'platform{cp}', '--window', '6201:6201:1', '--end', 6250, '--pce-start-stage', 1, '--pce-first-checkpoint', cp, '--pce-hold', 'timer', '--pce-hold', 'health')
    run('pce_sfx.py', 'capture', '--cue', cue, '--rompath', bios, '--out', out / 'sfx', '--mame', mame)
    run('stage_openings.py', 'capture', '--rom-dir', roms, '--mame', mame, '--out', out / 'openings', '--jobs', jobs)
    (out / 'receipt.json').write_text(json.dumps(dict(schema='striderex-source-captures/1', passed=True, mame_version=subprocess.check_output([str(mame), '-version'], text=True).strip(), mame_sha256=hashlib.sha256(Path(mame).read_bytes()).hexdigest(), cue_sha256=hashlib.sha256(cue.read_bytes()).hexdigest(), recipe_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()), indent=2) + '\n')

def main():
    p = argparse.ArgumentParser(description=__doc__)
    for name in ('cue', 'bios', 'rom-dir', 'mame', 'out'):
        p.add_argument('--' + name, type=Path, required=True)
    p.add_argument('--jobs', type=int, default=3)
    a = p.parse_args()
    capture(a.cue.resolve(), a.bios.resolve(), a.rom_dir.resolve(), a.mame.resolve(), a.out.resolve(), a.jobs)
if __name__ == '__main__':
    main()
