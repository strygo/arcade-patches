"""Decode, render and check PC Engine VDC/VCE dumps from run_pce_scene_capture."""
import argparse
import json
import struct
import sys
from pathlib import Path
import numpy as np
from PIL import Image
MAGIC = b'SXVDC1\x00\x00'
CGY = (16, 32, 64, 64)
MAP_W = (32, 64, 128, 128)
X0 = 32
PPC = 4
FIRST_LINE = 2
SHOT_RASTER = 18

def load(path):
    b = Path(path).read_bytes()
    if b[:8] != MAGIC:
        raise ValueError(f'{path}: not a scene dump')
    frame, vce_ctrl = struct.unpack_from('<II', b, 8)
    o = 16

    def words(n):
        nonlocal o
        a = np.frombuffer(b, '<u2', n, o).astype(np.int32)
        o += 2 * n
        return a
    d = dict(frame=frame, vce_ctrl=vce_ctrl, reg=words(32), pal=words(512), sat=words(256), satsrc=words(256), vram=words(32768))
    if o != len(b):
        raise ValueError(f'{path}: size {len(b)} != {o}')
    return d

def pal_rgb(pal):
    """VCE 9-bit GRB entries to 8-bit RGB, as huc6260.cpp palette_init (pal3bit)."""

    def p3(x):
        return x << 5 | x << 2 | x >> 1
    b, r, g = (pal & 7, pal >> 3 & 7, pal >> 6 & 7)
    return np.stack([p3(r), p3(g), p3(b)], -1).astype(np.uint8)

def bg_tile(vram, tile):
    """8x8 color indices (0-15) of background tile `tile`."""
    base = (tile & 4095) << 4
    w0 = vram[base:base + 8]
    w1 = vram[base + 8:base + 16]
    bits = 7 - np.arange(8)
    p0 = w0[:, None] >> bits & 1
    p1 = w0[:, None] >> bits + 8 & 1
    p2 = w1[:, None] >> bits & 1
    p3 = w1[:, None] >> bits + 8 & 1
    return p0 | p1 << 1 | p2 << 2 | p3 << 3

def sprite_cell(vram, pattern):
    """16x16 color indices of sprite cell `pattern` (64-word units)."""
    base = pattern << 6 & 32767
    bits = 15 - np.arange(16)
    out = np.zeros((16, 16), np.int32)
    for k in range(4):
        w = vram[base + 16 * k & 32767:(base + 16 * k & 32767) + 16]
        out |= (w[:, None] >> bits & 1) << k
    return out

def geometry(d):
    reg = [int(x) for x in d['reg']]
    mwr = reg[9]
    return dict(map_w=MAP_W[mwr >> 4 & 3], map_h=64 if mwr & 64 else 32, width=((reg[11] & 127) + 1) * 8, height=(reg[13] & 511) + 1, bxr=reg[7] & 1023, byr=reg[8] & 511, cr=reg[5])

def all_bg_tiles(vram):
    """Every 8x8 background tile in VRAM (2048 x 8 x 8 color indices)."""
    w = vram.reshape(2048, 16)
    bits = 7 - np.arange(8)
    w0, w1 = (w[:, :8, None], w[:, 8:, None])
    return w0 >> bits & 1 | (w0 >> bits + 8 & 1) << 1 | (w1 >> bits & 1) << 2 | (w1 >> bits + 8 & 1) << 3

def all_sprite_cells(vram):
    """Every 16x16 sprite cell in VRAM (512 x 16 x 16 color indices)."""
    w = vram.reshape(512, 4, 16)
    bits = 15 - np.arange(16)
    out = np.zeros((512, 16, 16), np.int32)
    for k in range(4):
        out |= (w[:, k, :, None] >> bits & 1) << k
    return out

def render_bg_map(d, tiles=None):
    """The whole virtual background as palette indices (0-255)."""
    g, vram = (geometry(d), d['vram'])
    if tiles is None:
        tiles = all_bg_tiles(vram)
    mh, mw = (g['map_h'], g['map_w'])
    bat = vram[:mh * mw].reshape(mh, mw)
    px = tiles[bat & 2047]
    pal = (bat >> 8 & 240)[:, :, None, None]
    img = np.where(px != 0, px | pal, 0)
    return img.transpose(0, 2, 1, 3).reshape(mh * 8, mw * 8)

def sprite_objects(d, sat_key='sat'):
    """Visible SAT entries as (index, top, left, image, attr), image = color indices."""
    g, sat = (geometry(d), d[sat_key])
    cells = all_sprite_cells(d['vram'])
    objs = []
    for i in range(64):
        sy, sx, pat, attr = (int(v) for v in sat[4 * i:4 * i + 4])
        cgy = attr >> 12 & 3
        height = CGY[cgy]
        pattern = pat >> 1
        if cgy & 1:
            pattern &= ~2
        if cgy & 2:
            pattern &= ~6
        cgx = bool(attr & 256)
        if cgx:
            pattern &= ~1
        top, left = (sy - 64, sx - 32)
        if top >= g['height'] or top + height <= 0 or left >= g['width'] or (left + (32 if cgx else 16) <= 0):
            continue
        rows = [np.concatenate([cells[pattern + r * 2 + c & 511] for c in range(2 if cgx else 1)], 1) for r in range(height // 16)]
        img = np.concatenate(rows, 0)
        if attr & 32768:
            img = img[::-1]
        if attr & 2048:
            img = img[:, ::-1]
        objs.append((i, top, left, img, attr))
    return objs

def display_raster(d):
    """Raster line of active display line 0, from VPR (VSW + VDS)."""
    vpr = int(d['reg'][12])
    return (vpr & 31) + 1 + ((vpr >> 8 & 255) + 2) - 4
HDS_PERMILLE = 200

def line_registers(d, writes=None, hds=None):
    """Per active line: BXR, background row (BYR latch) and CR."""
    hds = HDS_PERMILLE if hds is None else hds
    g = geometry(d)
    h = g['height']
    bxr, byr, cr = (g['bxr'], g['byr'], g['cr'])
    by_line = {}
    origin = display_raster(d)
    for w in writes or ():
        line, pm, r, v = w
        k = line - origin + (0 if pm < hds else 1)
        if 0 <= k < h and r in (5, 7, 8):
            by_line.setdefault(k, []).append((r, v))
    out = np.zeros((h, 3), np.int32)
    for k in range(h):
        if k:
            byr = byr + 1 & 511
        for r, v in by_line.get(k, ()):
            if r == 7:
                bxr = v & 1023
            elif r == 8:
                byr = v & 511
            else:
                cr = v
        out[k] = (bxr, byr, cr)
    return out

def render_layers(d, sat_key='sat', spr_dy=0, spr_dx=0, writes=None, tiles=None):
    """Background (palette indices) and sprite layer (0 or 0x100|pal<<4|c, 0x4000 = priority)."""
    g = geometry(d)
    w, h = (g['width'], g['height'])
    bgmap = render_bg_map(d, tiles)
    mh, mw = bgmap.shape
    lr = line_registers(d, writes)
    ys = lr[:, 1] % mh
    xs = (lr[:, 0][:, None] + np.arange(w)) % mw
    bg = np.where((lr[:, 2] & 128 != 0)[:, None], bgmap[ys[:, None], xs], 0)
    spr = np.zeros((h, w), np.int32)
    if (lr[:, 2] & 64).any():
        objs = sprite_objects(d, sat_key)
        used = np.zeros(h, np.int32)
        masks = {}
        for i, top, left, img, attr in objs:
            top += spr_dy
            left += spr_dx
            ncell = img.shape[1] // 16
            lines = np.arange(max(top, 0), min(top + img.shape[0], h))
            allowed = np.clip(16 - used[lines], 0, ncell)
            used[lines] = np.minimum(used[lines] + ncell, 16)
            m = np.zeros(img.shape, bool)
            for k in range(ncell):
                m[lines - top, k * 16:(k + 1) * 16] = (allowed > k)[:, None]
            masks[i] = (top, left, img, attr, m)
        for i in sorted(masks, reverse=True):
            top, left, img, attr, m = masks[i]
            y0, y1 = (max(top, 0), min(top + img.shape[0], h))
            x0, x1 = (max(left, 0), min(left + img.shape[1], w))
            if y0 >= y1 or x0 >= x1:
                continue
            sub = img[y0 - top:y1 - top, x0 - left:x1 - left]
            sm = m[y0 - top:y1 - top, x0 - left:x1 - left] & (sub != 0)
            val = (16384 if attr & 128 else 0) | 256 | (attr & 15) << 4
            region = spr[y0:y1, x0:x1]
            region[sm] = val | sub[sm]
        spr[lr[:, 2] & 64 == 0] = 0
    return (bg, spr)

def render(d, sat_key='sat', spr_dy=0, spr_dx=0, writes=None, tiles=None):
    """Active display as VCE palette indices (0-511), MAME's huc6270 rules (tiles: render_layers)."""
    bg, spr = render_layers(d, sat_key, spr_dy, spr_dx, writes, tiles)
    cr = line_registers(d, writes)[:, 2][:, None]
    has = spr != 0
    front = has & ((spr & 16384 != 0) | (bg == 0))
    both = np.where(front, spr & 511, bg)
    spr_only = np.where(has, spr & 511, 256)
    out = np.where(cr & 128 != 0, both, spr_only)
    return np.where(cr & 192 == 0, 256, out)

def read_writes(capture):
    """Register writes per dump frame: {frame: [(raster line, permille, reg, value)]}."""
    out = {}
    path = Path(capture) / 'pce_scene_writes.tsv'
    if path.exists():
        for line in path.read_text().splitlines()[1:]:
            f = line.split('\t')
            out.setdefault(int(f[0]), []).append((int(f[1]), int(f[2]), int(f[3], 16), int(f[5], 16)))
    return out

def native(png, width):
    """MAME screenshot reduced to native pixels; checks the 4-column grouping."""
    a = np.asarray(Image.open(png).convert('RGB')).astype(np.int32)
    cols = a[:, X0:X0 + width * PPC]
    groups = cols.reshape(a.shape[0], width, PPC, 3)
    uniform = bool((groups == groups[:, :, :1]).all())
    return (groups[:, :, 0].astype(np.uint8), uniform)

def screen_image(d, sat_key='sat', writes=None, rows=242):
    """The picture as MAME's screenshot rows show it: active lines placed by VPR,"""
    g = geometry(d)
    idx = render(d, sat_key, writes=writes)
    k = np.arange(rows) + SHOT_RASTER - display_raster(d)
    inside = (k >= 0) & (k < g['height'])
    out = np.full((rows, g['width']), 256, np.int32)
    out[inside] = idx[k[inside]]
    return out

def compare(d, png, sat_key, writes=None):
    """Mismatched pixels between the rendered picture and its screenshot."""
    g = geometry(d)
    shot, uniform = native(png, g['width'])
    rgb = pal_rgb(d['pal'])[screen_image(d, sat_key, writes, shot.shape[0])]
    diff = (rgb != shot).any(-1)
    bad_rows = np.where(diff.any(1))[0]
    return dict(mismatched=int(diff.sum()), pixels=int(diff.size), uniform=uniform, rows=[int(bad_rows[0]), int(bad_rows[-1])] if len(bad_rows) else [], lines=[int(r) + SHOT_RASTER - display_raster(d) for r in bad_rows[:8]], bad_row_count=int(len(bad_rows)))

def read_index(capture):
    rows = {}
    path = Path(capture) / 'pce_scene_index.tsv'
    if path.exists():
        lines = path.read_text().splitlines()
        head = lines[0].split('\t')
        for line in lines[1:]:
            r = dict(zip(head, line.split('\t')))
            rows[int(r['frame'])] = r
    return rows

def cmd_check(a):
    dumps = sorted(Path(a.capture).glob('*_scene.vdc'))
    if not dumps:
        print('no dumps', file=sys.stderr)
        return 2
    index = read_index(a.capture)
    writes = read_writes(a.capture)
    rows = []
    for p in dumps:
        d = load(p)
        png = p.with_suffix('.png')
        if d['vce_ctrl'] & 3 or not png.exists():
            rows.append(dict(frame=d['frame'], status='fail', reason='dot clock not 256-pixel mode' if d['vce_ctrl'] & 3 else 'no paired screenshot'))
            continue
        wr = writes.get(d['frame'], [])
        r = {k: compare(d, png, k, writes=wr) for k in ('sat', 'satsrc')}
        k = 'sat' if r['sat']['mismatched'] <= r['satsrc']['mismatched'] else 'satsrc'
        info = index.get(d['frame'], {})
        written = {n: int(info.get('display_' + n, 0)) for n in ('vram', 'reg', 'vce')}
        row = dict(frame=d['frame'], sat=k, **r[k], display_writes=written, geometry=geometry(d))
        origin = display_raster(d)
        write_lines = {w[0] - origin for w in wr}
        split = row['bad_row_count'] <= 2 and all((k in write_lines or k - 1 in write_lines for k in row['lines']))
        if row['mismatched'] <= a.tolerance and row['uniform']:
            row['status'] = 'exact' if row['mismatched'] == 0 else 'within_tolerance'
        elif (written['vram'] or written['vce']) and row['uniform']:
            row['status'] = 'torn'
        elif split and row['uniform']:
            row['status'] = 'split_line'
        else:
            row['status'] = 'fail'
        rows.append(row)
    count = lambda s: sum((1 for r in rows if r['status'] == s))
    summary = dict(capture=str(a.capture), frames=len(rows), exact=count('exact'), within_tolerance=count('within_tolerance'), split_line=count('split_line'), torn=count('torn'), failing=count('fail'), tolerance=a.tolerance, sat_source=sorted({r['sat'] for r in rows if 'sat' in r}))
    if a.output:
        Path(a.output).write_text(json.dumps(dict(summary=summary, frames=rows), indent=1) + '\n')
    for r in rows:
        if r['status'] in ('fail', 'torn'):
            print(r['status'].upper(), json.dumps({k: v for k, v in r.items() if k != 'geometry'}))
    print(json.dumps(summary))
    return 1 if summary['failing'] else 0

def self_test():
    vram = np.zeros(32768, np.int32)
    base = 256 << 4
    vram[base] = 32896 | 1
    vram[base + 8] = 32896
    t = bg_tile(vram, 256)
    assert t[0, 0] == 15 and t[0, 7] == 1 and (t[1].sum() == 0), t[0]
    vram[(128 << 6) + 16 + 3] = 32768
    c = sprite_cell(vram, 128)
    assert c[3, 0] == 2 and c.sum() == 2, c[3]
    p = pal_rgb(np.array([511, 7, 56, 448]))
    assert p[0].tolist() == [255, 255, 255] and p[1].tolist() == [0, 0, 255]
    assert p[2].tolist() == [255, 0, 0] and p[3].tolist() == [0, 255, 0]
    reg = np.zeros(32, np.int32)
    reg[5] = 192
    reg[9] = 0
    reg[11] = 31
    reg[13] = 223
    vram[0] = 8448
    sat = np.zeros(256, np.int32)
    sat[0:4] = [64 + 2 - 3, 32 + 4, 128 << 1, 128 | 5]
    d = dict(reg=reg, pal=np.zeros(512, np.int32), sat=sat, satsrc=sat, vram=vram, vce_ctrl=0, frame=0)
    out = render(d)
    assert out[0, 0] == 47 and out[0, 7] == 33, out[0, :8]
    assert out[2, 4] == 256 | 80 | 2, out[2, :8]
    print('pce_vdc self-test: ok')
    return 0

def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('--self-test', action='store_true')
    sub = p.add_subparsers(dest='cmd')
    c = sub.add_parser('check', help='render every dump and compare with its screenshot')
    c.add_argument('capture', type=Path)
    c.add_argument('--tolerance', type=int, default=0, help='mismatched pixels allowed per frame')
    c.add_argument('--output', type=Path)
    a = p.parse_args()
    if a.self_test:
        return self_test()
    if a.cmd == 'check':
        return cmd_check(a)
    p.print_help()
    return 2
if __name__ == '__main__':
    sys.exit(main())
