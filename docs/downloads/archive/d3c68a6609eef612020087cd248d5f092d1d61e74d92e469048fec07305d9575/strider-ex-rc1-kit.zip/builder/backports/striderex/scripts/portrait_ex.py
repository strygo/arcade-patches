"""Strider EX: the PC Engine boss portraits in the arcade game (W3b, D8): build step."""
import argparse
import hashlib
import json
import re
import sys
from pathlib import Path
import numpy as np
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import cps1_gfx as G
import pce_vdc as P
ROOT = HERE.parents[2]
MANIFEST = ROOT / 'backports/striderex/manifests/portraits.json'
RECEIPT = ROOT / 'backports/striderex/manifests/portraits_measured.json'
CODE_TOP = 48128
SPAN = 80
NX, NY = (8, 5)
TITLE_ENDING_S2 = (33664, 33791)

def manifest():
    return json.loads(MANIFEST.read_text())

def receipt():
    return {r['id']: r for r in json.loads(RECEIPT.read_text())['portraits']}

def edge_pick(img):
    import rescale_pilot as R
    return R.method_edge_pick(img)

def picture_key(img):
    """portrait_pce.measure_one's key: pens (0 where transparent) and the transparency mask."""
    return hashlib.sha256(np.where(img < 0, 0, img & 15).astype(np.uint8).tobytes() + (img < 0).tobytes()).hexdigest()[:16]

def load_picture(capture, pid, frame):
    import portrait_pce as PP
    d = P.load(Path(capture) / pid / f'pce_{frame:05d}_scene.vdc')
    got = PP.portrait_sprites(d)
    if got is None:
        raise SystemExit(f'{pid}: no portrait in the dump of frame {frame}')
    return got[3]

def to_pens(wide):
    """120x80 VCE indices (-1 transparent) -> 128x80 CPS-1 pens (15 transparent)."""
    pens = np.full((NY * 16, NX * 16), 15, np.int32)
    h, w = wide.shape
    pens[:h, :w] = np.where(wide < 0, 15, (wide & 15) - 1)
    if (pens[:h, :w] < 0).any():
        raise SystemExit('portrait has a PC Engine color 0 inside its picture (transparent pens are -1)')
    return pens

def colors(vce):
    """16 PC Engine sprite colors -> 16 CPS-1 words: pen k = color k+1, pen 15 unused (transparent)."""
    return [G.cps_color(v) for v in vce[1:16]] + [61440]

class Portraits:
    """The converted portraits: pictures, codes, colors, sequences; inc_text() and patch_program()."""

    def __init__(self, items, slot, report):
        self.items, self.slot, self.report = (items, slot, report)

    @property
    def enabled(self):
        return bool(self.items)

def prepare(cv, capture, rom_dir=None):
    """build_ex.py's portrait step: convert every manifest portrait from the capture into cv.region"""
    man = manifest()
    arc = man['arcade']
    if capture is None:
        return Portraits([], arc['palette_slot'], dict(enabled=False))
    rec = receipt()
    items, blocks = ([], [])
    for k, row in enumerate(arc['portraits']):
        r = rec[row['id']]
        pics = []
        for p in r['pictures']:
            img = load_picture(capture, row['id'], p['frame'])
            if picture_key(img) != p['key']:
                raise SystemExit(f"{row['id']}: picture at frame {p['frame']} is not the measured one ({picture_key(img)} != {p['key']})")
            wide = edge_pick(img)
            if wide.shape != (80, 120):
                raise SystemExit(f"{row['id']}: widened picture is {wide.shape}")
            pics.append(dict(key=p['key'], pens=to_pens(wide), wide=wide))
            blocks.append((k, len(pics) - 1))
        items.append(dict(index=k, id=row['id'], stage=row['stage'], screen=row['screen'], sites=row['sites'], pictures=pics, sequence=r['sequence'], colors=colors(r['palette_vce'])))
    for n, (k, i) in enumerate(blocks):
        span = CODE_TOP - SPAN * (n // 2 + 1)
        code = span + 8 * (n % 2)
        assert (code & 15) + NX <= 16
        items[k]['pictures'][i]['code'] = code
        for row in range(NY):
            for col in range(NX):
                G.put_tile(cv.region, G.ex_offset('obj', code + col + 16 * row), items[k]['pictures'][i]['pens'][16 * row:16 * row + 16, 16 * col:16 * col + 16])
    low = CODE_TOP - SPAN * ((len(blocks) + 1) // 2)
    check_range(cv, low, CODE_TOP - 1)
    rep = dict(enabled=True, codes=[f'{low:#06x}', f'{CODE_TOP - 1:#06x}'], blocks=len(blocks), palette_slot=arc['palette_slot'], portraits=[dict(index=it['index'], id=it['id'], stage=it['stage'], screen=it['screen'], sites=it['sites'], frames=sum((n for n, _ in it['sequence'])), codes=[f"{p['code']:#06x}" for p in it['pictures']], pens_sha256=hashlib.sha256(b''.join((p['pens'].astype(np.uint8).tobytes() for p in it['pictures']))).hexdigest()) for it in items])
    return Portraits(items, arc['palette_slot'], rep)

def check_range(cv, low, high):
    """The portrait codes must not meet the converter's blocks or cells, the captions, the"""
    import subtitle_ex as SX
    import usa_slice as US
    hw = SX.high_water(cv)
    taken = dict(hw)
    taken['captions'] = list(SX.CAPTION_CODES)
    taken['title_ending_s2'] = list(TITLE_ENDING_S2)
    taken['usa_split_s2'] = [US.S2_FIRST, US.S2_LAST]
    for name, (u0, u1) in taken.items():
        if not (u1 < low or u0 > high):
            raise SystemExit(f'portrait codes {low:#x}-{high:#x} overlap {name} {u0:#x}-{u1:#x}')

def rx(pattern):
    p = pattern.replace(' ', '')
    out = b''
    for i in range(0, len(p), 2):
        h = p[i:i + 2]
        out += b'.' if h == '??' else re.escape(bytes([int(h, 16)]))
    return re.compile(out, re.S)

def find_sites(img):
    """{site: (address of the replaced bytes, the replaced bytes)}; each signature exactly once."""
    out = {}
    for name, s in manifest()['arcade']['sites'].items():
        hits = [m.start() for m in rx(s['pattern']).finditer(bytes(img))]
        if len(hits) != 1:
            raise SystemExit(f'portrait site {name}: signature matches {len(hits)} times')
        at = hits[0] + s['at']
        out[name] = (at, bytes(img[at:at + s['length']]))
    return out

def stock_image(rom_dir, machine):
    import respawn_fix as RF
    files = {q.name: q.read_bytes() for q in (Path(rom_dir) / machine).iterdir() if q.is_file()}
    return RF.compose(files, RF.SETS[machine])

def inc_text(pt, machine, rom_dir, scenes=None):
    """portraits.inc for one region: equates, hook stubs, the portrait table and data. scenes: {portrait index:"""
    arc = manifest()['arcade']
    lines = [f'; portraits.inc ({machine}), written by scripts/portrait_ex.py', f'PT_SLOT equ {pt.slot}']
    sites = find_sites(stock_image(rom_dir, machine))
    at, raw = sites['frame']
    init = at + 2 + int.from_bytes(raw[2:4], 'big', signed=True)
    nxt = at + 4 + 2 + int.from_bytes(raw[6:8], 'big', signed=True)
    lines += [f"PT_INIT equ ${init:X}                 ; the frame routine's list init", f'PT_NEXT equ ${nxt:X}']
    for name in arc['sites']:
        if name == 'frame':
            continue
        at, raw = sites[name]
        lines.append(f'pt_hook_{name}:                          ; replaces {raw.hex()} at {at:#x}')
        lines.append('        movem.l d0-d1/a0-a1,-(sp)')
        for it in pt.items:
            if name in it['sites'] and scenes and (it['index'] in scenes):
                lines.append(f"        moveq   #{scenes[it['index']]},d0               ; {it['id']}: its boss scene")
                lines.append(f"        moveq   #{it['stage']},d1")
                lines.append('        jsr     bs_play_stage')
            elif name in it['sites']:
                lines.append(f"        moveq   #{it['index']},d0               ; {it['id']}")
                lines.append(f"        moveq   #{it['stage']},d1")
                lines.append('        jsr     pt_arm_stage')
        lines.append('        movem.l (sp)+,d0-d1/a0-a1')
        lines.append('        dc.w    ' + ','.join((f"${int.from_bytes(raw[i:i + 2], 'big'):04X}" for i in range(0, len(raw), 2))))
        lines.append('        rts')
    lines.append('        even')
    lines.append('pt_table:                               ; dc.w x+64, y+16 ; dc.l sequence, colors')
    for it in pt.items:
        x, y = it['screen']
        lines.append(f'        dc.w    {x + 64},{y + 16}')
        lines.append(f"        dc.l    pt_seq_{it['index']},pt_col_{it['index']}     ; {it['id']}")
    for it in pt.items:
        lines.append(f"pt_seq_{it['index']}:")
        for n, pic in it['sequence']:
            lines.append(f"        dc.w    {n},${it['pictures'][pic]['code']:04X}")
        lines.append('        dc.w    0,0')
        lines.append(f"pt_col_{it['index']}:")
        lines.append('        dc.w    ' + ','.join((f'${c:04X}' for c in it['colors'])))
    if not pt.items:
        lines.append('pt_frame_unused:')
    return '\n'.join(lines) + '\n'

def patch_program(img, machine, syms, pt):
    """The frame site and every trigger site -> jsr into the EX bank (verified stock bytes)."""
    if not pt.enabled:
        return {}
    arc = manifest()['arcade']
    sites = find_sites(img)
    done = {}
    for name, s in arc['sites'].items():
        at, raw = sites[name]
        target = syms['pt_frame' if name == 'frame' else f'pt_hook_{name}']
        new = b'N\xb9' + target.to_bytes(4, 'big') + b'Nq' * ((s['length'] - 6) // 2)
        assert len(new) == s['length'] == len(raw)
        img[at:at + len(raw)] = new
        done[name] = dict(at=f'{at:#x}', stock=raw.hex(), target=f'{target:#x}')
    return done

def model_rgb(pt_or_item, pic, rgb_of):
    """RGB (80x128x3) and opaque mask of one converted picture, colors through rgb_of(word)."""
    it = pt_or_item
    pens = it['pictures'][pic]['pens']
    lut = np.array([rgb_of(c) for c in it['colors']], np.uint8)
    return (lut[np.clip(pens, 0, 15)], pens != 15)

def sequence_at(it, t):
    """Picture index shown t frames after the trigger (None after the sequence)."""
    for n, pic in it['sequence']:
        if t < n:
            return pic
        t -= n
    return None

def cmd_sheet(a):
    """Review sheet: each picture as the PC Engine shows it (80 px stretched to the arcade's 120,"""
    from PIL import Image, ImageDraw

    class CV:
        region = bytearray(4 * G.MB)
    pt = prepare_unchecked(CV(), a.capture)
    rows = []
    for it in pt.items:
        for i, p in enumerate(it['pictures']):
            rgb, m = model_rgb(it, i, lambda w: [(w >> s & 15) * 17 for s in (8, 4, 0)])
            arc = np.where(m[..., None], rgb, 40).astype(np.uint8)[:, :120]
            src = load_picture(a.capture, it['id'], receipt()[it['id']]['pictures'][i]['frame'])
            rows.append((f"{it['id']} picture {i} (codes {p['code']:#06x})", src, it, arc))
    W, H = (2 * 3 * 120 + 40, 3 * 80 + 24)
    sheet = Image.new('RGB', (W, H * len(rows)), (24, 24, 24))
    d = ImageDraw.Draw(sheet)
    rec = receipt()
    for k, (label, src, it, arc) in enumerate(rows):
        vce = rec[it['id']]['palette_vce']
        pal = P.pal_rgb(np.array(vce))
        s = np.where((src >= 0)[..., None], pal[np.clip(src & 15, 0, 15)], 40).astype(np.uint8)
        y = k * H
        d.text((4, y + 4), label, fill=(255, 255, 0))
        sheet.paste(Image.fromarray(s).resize((360, 240), Image.NEAREST), (4, y + 20))
        sheet.paste(Image.fromarray(arc).resize((360, 240), Image.NEAREST), (384, y + 20))
    a.out.parent.mkdir(parents=True, exist_ok=True)
    sheet.save(a.out)
    print('wrote', a.out, len(rows), 'pictures')
    return 0

def prepare_unchecked(cv, capture):
    """prepare() without the build's high-water check (review sheets, self-test)."""
    global check_range
    saved = check_range
    check_range = lambda *_: None
    try:
        return prepare(cv, capture)
    finally:
        check_range = saved

def self_test(a):
    img = np.full((80, 80), 256 | 176 | 3, np.int32)
    img[10:30, 20:41] = 256 | 176 | 7
    wide = edge_pick(img)
    assert wide.shape == (80, 120) and set(np.unique(wide)) <= {435, 439}, np.unique(wide)
    pens = to_pens(wide)
    assert pens.shape == (80, 128) and (pens[:, 120:] == 15).all() and (set(np.unique(pens[:, :120])) == {2, 6})
    region = bytearray(4 * G.MB)
    code = CODE_TOP - SPAN + 8
    for row in range(NY):
        for col in range(NX):
            G.put_tile(region, G.ex_offset('obj', code + col + 16 * row), pens[16 * row:16 * row + 16, 16 * col:16 * col + 16])
    back = np.vstack([np.hstack([G.get_tile(region, G.ex_offset('obj', code + c + 16 * r), 16) for c in range(NX)]) for r in range(NY)])
    assert (back == pens).all()
    assert colors([0] * 16)[:15] == [61440] * 15
    m = manifest()
    assert m['arcade']['palette_slot'] < 32 and 'frame' in m['arcade']['sites']
    if a.rom_dir:
        for machine in ('striderua', 'striderjr'):
            s = find_sites(stock_image(a.rom_dir, machine))
            print(machine, {k: f'{v[0]:#x}' for k, v in s.items()})
    if a.capture:

        class CV:
            region = bytearray(4 * G.MB)
        pt = prepare_unchecked(CV(), a.capture)
        print('converted', [(it['id'], len(it['pictures'])) for it in pt.items], pt.report['codes'])
    print('portrait_ex self-test passed')
    return 0

def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('--self-test', action='store_true')
    p.add_argument('--rom-dir', type=Path)
    p.add_argument('--capture', type=Path)
    sub = p.add_subparsers(dest='cmd')
    s = sub.add_parser('sheet')
    s.add_argument('--capture', type=Path, required=True)
    s.add_argument('--out', type=Path, required=True)
    a = p.parse_args()
    if a.self_test:
        return self_test(a)
    if a.cmd == 'sheet':
        return cmd_sheet(a)
    p.print_help()
    return 2
if __name__ == '__main__':
    sys.exit(main())
