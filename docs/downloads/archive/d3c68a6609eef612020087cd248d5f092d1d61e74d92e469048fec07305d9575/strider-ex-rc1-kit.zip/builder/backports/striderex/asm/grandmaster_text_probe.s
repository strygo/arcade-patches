; Diagnostic only, never in the delivered game. Freeze an initialized game
; and call its unchanged text drawer on the real second-page record.
        org $1FF700
        move.w  #$2700,sr
        lea     $908000,a0
        move.w  #4095,d0
.s1:    move.l  #$7020001E,(a0)+
        dbra    d0,.s1
        lea     $90C000,a0
        move.w  #4095,d0
.s2:    move.l  #$28200000,(a0)+
        dbra    d0,.s2
        lea     $910000,a0
        move.w  #4095,d0
.s3:    move.l  #$00200000,(a0)+
        dbra    d0,.s3
        move.l  #$0000FF00,$900004
        lea     $7395E,a0
        lea     $9147C0,a1
        moveq   #15,d0
.pal:   move.w  (a0)+,(a1)+
        dbra    d0,.pal
        move.w  #$F000,$9157FE
        move.w  #$FFC0,$80010C
        move.w  #272,$80010E
        move.w  #$9140,$80010A
        lea     $FF8000,a5
        lea     $FF8B00,a0
        move.b  #1,$32(a0)
        jsr     $EAAA
.hold:  move.w  #$9000,$800100
        move.w  #$7FFF,d0
.delay: dbra    d0,.delay
        bra.s   .hold
