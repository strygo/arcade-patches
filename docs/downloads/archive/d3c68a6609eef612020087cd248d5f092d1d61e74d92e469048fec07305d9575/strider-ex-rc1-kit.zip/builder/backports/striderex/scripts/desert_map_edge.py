"""Keep map 1's incomplete left sand tile outside the desert camera."""
import argparse
from copy import deepcopy
import json
from pathlib import Path
import struct
import sys
from boss_voice_gate import inventory, sha
MINIMUM = 4128
TOLERANCE = 12
LIMITS = struct.pack('>8H', 2, 4104, 6672, 848, 1808, 0, 0, 0)
PAN = struct.pack('>24H', 2, 4116, 6672, 848, 1808, 0, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0, 5, 1, 0, 0, 0, 0, 0, 0)
CHECKPOINT = struct.pack('>23H', 4224, 927, 4104, 848, 0, 0, 0, 0, 512, 256, 6672, 4104, 1808, 848, 192, 176, 144, 112, 0, 0, 5002, 3, 1)

def patch(raw):
    bank = bytearray((raw[i ^ 1] for i in range(len(raw))))
    changes = []
    records = []
    for name, pattern, edits in (('outgoing_settle', PAN, ((2, MINIMUM + TOLERANCE),)), ('section2_limits', LIMITS, ((2, MINIMUM),)), ('section2_checkpoint', CHECKPOINT, ((4, MINIMUM), (22, MINIMUM)))):
        if bank.count(pattern) != 1:
            raise ValueError(name + ': unique supported desert record required')
        records.append((name, bank.index(pattern), edits))
    for name, at, edits in records:
        for off, value in edits:
            a = at + off
            before = bytes(bank[a:a + 2])
            after = value.to_bytes(2, 'big')
            changes.append(dict(record=name, address=1048576 + a, before=before.hex(), after=after.hex()))
            bank[a:a + 2] = after
    return (bytes((bank[i ^ 1] for i in range(len(bank)))), dict(changes=changes, camera_minimum=MINIMUM, temporary_pan_minimum=MINIMUM + TOLERANCE, checkpoint_camera_x=MINIMUM, art_and_collision_unchanged=True))

def audit(control, build):
    cm, old = inventory(control)
    meta, new = inventory(build)
    for machine, files in old.items():
        result, spec = patch(files['strex_p6.bin'])
        declared = meta['sets'][machine]['desert_map_edge']
        expected = dict(files, **{'strex_p6.bin': result})
        if new[machine] != expected or declared['change'] != spec:
            raise ValueError('unexpected desert map-edge ROM change')
        if declared['source_files'] != cm['sets'][machine]['files']:
            raise ValueError('desert map-edge source inventory differs')
    return meta

def main():
    if sys.argv[1:] == ['--self-test']:

        def raw(b):
            return bytes((b[i ^ 1] for i in range(len(b))))
        valid = PAN + LIMITS + CHECKPOINT
        result, spec = patch(raw(valid))
        assert len(result) == len(valid) and len(spec['changes']) == 4
        for invalid in (b'', valid + PAN, valid.replace(LIMITS, bytes(len(LIMITS)))):
            try:
                patch(raw(invalid))
            except ValueError:
                pass
            else:
                raise AssertionError('foreign/missing/duplicate record accepted')
        try:
            patch(result)
        except ValueError:
            pass
        else:
            raise AssertionError('already-patched records accepted')
        print('Desert map-edge record guards PASS')
        return
    p = argparse.ArgumentParser(description=__doc__)
    for name in ('build', 'out'):
        p.add_argument('--' + name, type=Path, required=True)
    a = p.parse_args()
    meta, old = inventory(a.build)
    rep = deepcopy(meta)
    a.out.mkdir(parents=True, exist_ok=False)
    for machine, files in old.items():
        bank, spec = patch(files['strex_p6.bin'])
        result = dict(files, **{'strex_p6.bin': bank})
        dest = a.out / machine
        dest.mkdir()
        for name, data in result.items():
            (dest / name).write_bytes(data)
        rep['sets'][machine]['desert_map_edge'] = dict(change=spec, source_files=meta['sets'][machine]['files'], producer_sha256=sha(Path(__file__).read_bytes()))
        rep['sets'][machine]['files'] = {n: sha(b) for n, b in result.items()}
    (a.out / 'build.json').write_text(json.dumps(rep, indent=2) + '\n')
    audit(a.build, a.out)
    print('Desert map-edge bounds corrected; all art/collision/code/audio bytes preserved')
if __name__ == '__main__':
    main()
