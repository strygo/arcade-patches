"""Build the five-launcher private Strider EX hardware kit after qualification."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import xml.etree.ElementTree as ET
import zipfile
import ex_kit
import ex_release
from qualify_kit import required_jobs
from verify_private_kit import archive_paths
ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / 'release'))
import mra_assembly
import private_mister

def sha(data):
    return hashlib.sha256(data).hexdigest()

def main():
    p = argparse.ArgumentParser(description=__doc__)
    for name in ('build', 'rom-dir', 'pack', 'core', 'out', 'readme'):
        p.add_argument('--' + name, type=Path, required=True)
    p.add_argument('--qualification', type=Path, action='append', required=True)
    p.add_argument('--rtl-receipt', type=Path, required=True)
    p.add_argument('--date', required=True, help='core producer suffix, YYYYMMDD')
    p.add_argument('--label', required=True, help='short private kit purpose, e.g. Kit p')
    p.add_argument('--test-id')
    p.add_argument('--ledger', type=Path)
    for name in ('music-proof', 'music-runtime', 'music-census', 'music-loop'):
        p.add_argument('--' + name, type=Path, help='focused music follow-up; all four receipts are required together')
    p.add_argument('--earth-runtime', type=Path)
    p.add_argument('--earth-render', type=Path)
    p.add_argument('--tile-runtime', type=Path)
    p.add_argument('--tile-render', type=Path)
    p.add_argument('--reading-runtime', type=Path)
    p.add_argument('--tip-runtime', type=Path)
    p.add_argument('--tip-render', type=Path)
    p.add_argument('--boss-followup', type=Path, help='qualified boss/desert/arcade inverse and focused checks')
    p.add_argument('--desert-followup', type=Path, help='post-Kit-y inverse, arranged pack and focused checks')
    a = p.parse_args()
    if not a.label.strip() or any((c in a.label for c in '\\/:*?"<>|[]')):
        p.error('label must be a nonempty filename-safe purpose without brackets')
    if (a.build / 'spacing-preview.json').exists():
        p.error('deliver the independently rebuilt build, not the spacing preview')
    build = json.loads((a.build / 'build.json').read_text())
    if not build.get('test_ending'):
        p.error('this private hardware kit needs the TEST build with ENDING')
    qualifications = {}
    for path in a.qualification:
        q = json.loads(path.read_text())
        if not q.get('passed') or not q.get('results') or any((not r.get('passed') or r.get('exit_code') != 0 for r in q['results'])):
            p.error('qualification is incomplete: ' + str(path))
        if {r['name'] for r in q['results']} != required_jobs(q['suite']):
            p.error('qualification omits required jobs: ' + str(path))
        qualifications[q['suite']] = q
    if set(qualifications) != {'fixes', 'audio', 'combined'}:
        p.error('qualification needs fixes, audio and combined receipts')
    expected = {m: spec['files'] for m, spec in build['sets'].items()}
    paths = [a.music_proof, a.music_runtime, a.music_census, a.music_loop]
    if any(paths) and (not all(paths)):
        p.error('the music follow-up needs all four receipts')
    music = {key: json.loads(path.read_text()) for key, path in zip(('proof', 'runtime', 'census', 'loop'), paths)} if all(paths) else None
    if a.earth_runtime or a.earth_render:
        if not (music and a.earth_runtime and a.earth_render):
            p.error('Earth repair requires both receipts and cinematic inheritance')
        music['earth_runtime'] = json.loads(a.earth_runtime.read_text())
        music['earth_render'] = json.loads(a.earth_render.read_text())
    if a.tile_runtime or a.tile_render:
        if not (music and a.tile_runtime and a.tile_render):
            p.error('Earth composite requires both receipts and cinematic inheritance')
        music['tile_runtime'] = json.loads(a.tile_runtime.read_text())
        music['tile_render'] = json.loads(a.tile_render.read_text())
    baseline_expected = music['proof']['baseline_files'] if music else expected
    if a.reading_runtime:
        if not music:
            p.error('reading follow-up requires cinematic inheritance')
        music['reading_runtime'] = json.loads(a.reading_runtime.read_text())
    if a.tip_runtime or a.tip_render:
        if not (music and a.tip_runtime and a.tip_render):
            p.error('lower-tip repair needs both focused reports')
        music['tip_runtime'] = json.loads(a.tip_runtime.read_text())
        music['tip_render'] = json.loads(a.tip_render.read_text())
    if qualifications['combined']['inputs'].get('test_build') != baseline_expected:
        p.error('combined qualification does not describe this TEST build')
    rtl = json.loads(a.rtl_receipt.read_text())
    if not rtl.get('passed') or rtl.get('build_files') != baseline_expected or {r['pick'] for r in rtl.get('results', [])} != {0, 1, 2, 6} or any((not r.get('passed') or not r.get('consecutive_captures') for r in rtl.get('results', []))):
        p.error('RTL receipt is incomplete or describes different build bytes')
    followup = json.loads(a.boss_followup.read_text()) if a.boss_followup else None
    desert = json.loads(a.desert_followup.read_text()) if a.desert_followup else None
    if desert and (not followup):
        p.error('desert follow-up requires its prior boss follow-up')
    if followup and (not music):
        p.error('boss follow-up requires the prior kit cinematic bundle')
    if music:
        import cinematic_followup as CF
        members = {m: {n: (a.build / m / n).read_bytes() for n in fs} for m, fs in expected.items()}
        inherited_expected = expected
        if desert:
            import desert_followup_release as DF
            DF.validate(desert, followup, music, qualifications, rtl, expected, sha(a.core.read_bytes()))
            members = DF.restore(desert, members)
            inherited_expected = desert['baseline_files']
            prior_pack = DF.restore_pack(desert, (a.pack / 'strider_ex.cpk').read_bytes())
        if followup:
            import boss_followup_release as BF
            BF.validate(followup, music, qualifications, rtl, inherited_expected, sha(a.core.read_bytes()))
            members = BF.restore(followup, members)
            inherited_expected = followup['baseline_files']
            BF.restore_pack(followup, prior_pack if desert else (a.pack / 'strider_ex.cpk').read_bytes())
        CF.validate_qualification(music, qualifications, rtl, inherited_expected)
        CF.verify(music['proof'], members)
    for machine, files in expected.items():
        for name, digest in files.items():
            if sha((a.build / machine / name).read_bytes()) != digest:
                p.error('build member changed: ' + name)
    pack_sha = sha((a.pack / 'strider_ex.cpk').read_bytes())
    qualified_pack = desert['pack']['sha256'] if desert else followup['reports']['boss_english_pack']['pack_sha256'] if followup else qualifications['combined']['inputs']['pack_sha256']
    if pack_sha != qualified_pack:
        p.error('pack differs from qualification')
    rbf = 'jtcps1-strex-test'
    subprocess.run([sys.executable, str(Path(ex_release.__file__)), '--build', str(a.build), '--rom-dir', str(a.rom_dir), '--pack', str(a.pack), '--core', str(a.core), '--rbf', rbf, '--date', a.date, '--out', str(a.out)], check=True)
    text, members = ex_release.members_for(a, 'striderua')
    diagnostic = 'Strider EX (USA) [no pack, diagnostic]'
    mra = ex_kit.make_mra(text, 'striderua', diagnostic, rbf, 'striderex_us.zip', members)
    (a.out / '_Arcade' / (diagnostic + '.mra')).write_text(mra)
    (a.out / 'README.txt').write_text(a.readme.read_text())
    archives = {}
    for relative in ('games/mame/striderex_us.zip', 'games/mame/striderex_jp.zip', 'games/CPS+/strider_ex.zip'):
        with zipfile.ZipFile(a.out / relative) as z:
            archives[relative] = {n: sha(z.read(n)) for n in z.namelist()}
    mras = {}
    flags = {n: flag for _, n, flag, _ in ex_release.VARIANTS}
    flags[diagnostic] = 0
    labelled_flags = {}
    for name, flag in flags.items():
        old = a.out / '_Arcade' / (name + '.mra')
        labelled = name + ' [' + a.label.strip() + ']'
        tree = ET.parse(old)
        tree.getroot().find('name').text = labelled
        tree.write(old.with_name(labelled + '.mra'), encoding='utf-8', xml_declaration=False)
        old.unlink()
        labelled_flags[labelled] = flag
    for name, flag in labelled_flags.items():
        mp = a.out / '_Arcade' / (name + '.mra')
        text = mp.read_text()
        image = mra_assembly.assemble(text, mra_assembly.ZipSource(archive_paths(a.out, text, archives)))
        if image[64 + (2097151 ^ 1)] != flag:
            raise ValueError('Wrong assembled flag: ' + name)
        mras[name] = dict(flag=flag, assembled_sha256=sha(image))
    core = next((a.out / '_Arcade/cores').glob('*.rbf'))
    receipt = dict(build_files=expected, archives=archives, mras=mras, rbf=rbf, core=dict(file=core.relative_to(a.out).as_posix(), sha256=sha(core.read_bytes())), qualification=qualifications, rtl=rtl, required_jobs={suite: sorted(required_jobs(suite)) for suite in qualifications})
    if music:
        receipt['cinematic_music'] = music
        shutil.copy2(Path(__file__).with_name('cinematic_followup.py'), a.out / 'cinematic_followup.py')
    if followup:
        receipt['boss_followup'] = followup
        shutil.copy2(Path(__file__).with_name('boss_followup_release.py'), a.out / 'boss_followup_release.py')
    if desert:
        receipt['desert_followup'] = desert
        shutil.copy2(Path(__file__).with_name('desert_followup_release.py'), a.out / 'desert_followup_release.py')
    (a.out / 'producer.json').write_text(json.dumps(receipt, indent=2) + '\n')
    shutil.copy2(ROOT / 'release/mra_assembly.py', a.out / 'mra_assembly.py')
    shutil.copy2(Path(__file__).with_name('verify_private_kit.py'), a.out / 'verify_kit.py')
    subprocess.run([sys.executable, str(a.out / 'verify_kit.py'), '--root', str(a.out)], check=True)
    report = private_mister.finalize(a.out, 'strider-ex', build_id=a.test_id, rompaths=[a.rom_dir], ledger=a.ledger)
    subprocess.run([sys.executable, str(a.out / 'verify_kit.py'), '--root', str(a.out)], check=True)
    print('Finalized private kit', report.get('test_id'), a.out)
if __name__ == '__main__':
    main()
