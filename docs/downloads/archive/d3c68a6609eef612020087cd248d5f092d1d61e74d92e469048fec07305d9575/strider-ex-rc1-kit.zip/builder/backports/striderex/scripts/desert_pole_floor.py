"""Restore the pipeline's landing surface beside the narrowed valve stems."""
import argparse
from copy import deepcopy
import json
from pathlib import Path
import sys
import desert_grip_fix as F
import desert_slopes as S
import respawn_fix as R
from boss_voice_gate import inventory, sha
BASE = 2056192

def overrides(image, bank):
    rd = S.reader(image, bank)
    lr = S.layer_record(image, 5, 1)
    grid = int.from_bytes(rd(lr + 2, 4), 'big')
    secs = int.from_bytes(rd(lr + 6, 4), 'big')
    pg, ty, _, _, recs = F.DX.collision_sets(image)['B']
    out = {}
    wr = 1599 // 32
    for left in (5616, 5808, 6000, 6192, 6384):
        for x in list(range(left, left + 18)) + list(range(left + 54, left + 72)):
            cx = x // 32
            key = (cx, 63 - wr)
            if key not in out:
                g = rd(grid + wr // 8 * 32 + cx // 12)[0]
                e = rd(secs + 384 * g + 4 * (wr % 8 * 12 + cx % 12), 4)
                code = int.from_bytes(e[:2], 'big') & 16383
                flips = e[3] >> 5 & 3
                page = rd(pg + (code >> 8) + 8 * flips)[0]
                v = rd(ty + (page - 1) * 256 + (code & 255))[0] if page else 0
                out[key] = {'B': list(rd(recs + (v - 32) * 33 + 1, 32)) if v >= 32 else [v] * 32}
            out[key]['B'][x % 32] = 31
    return out

def produce(files, m, stock):
    im = R.compose(files, R.SETS[m])
    p = files['strex_p6.bin']
    bank = bytes((p[i ^ 1] for i in range(len(p))))
    result, spec = F.patch(files, m, F.np.zeros((2048, 12288), bool), stock, map_index=1, allocation_base=BASE, merge=True, surface_overrides=overrides(im, bank))
    if BASE + spec['allocation_size'] > 2088960:
        raise ValueError('pole floor reaches the drawing helper')
    return (result, spec)

def audit(control, build, rom_dir):
    cm, old = inventory(control)
    meta, new = inventory(build)
    stock = F.DX.program_images(rom_dir)
    for m, f in old.items():
        expected, s = produce(f, m, stock[m])
        spec = meta['sets'][m]['pole_floor']
        if expected != new[m] or spec['source_files'] != cm['sets'][m]['files'] or s['allocation_sha256'] != spec['allocation_sha256']:
            raise ValueError('unexpected pole-floor ROM changes')
    return meta

def main():
    if sys.argv[1:] == ['--self-test']:
        assert 1599 % 32 == 31 and 2088960 - BASE == 32768
        print('Pole floor coordinate/allocation guards PASS')
        return
    p = argparse.ArgumentParser(description=__doc__)
    for n in ('build', 'rom-dir', 'out'):
        p.add_argument('--' + n, type=Path, required=True)
    a = p.parse_args()
    meta, files = inventory(a.build)
    stock = F.DX.program_images(a.rom_dir)
    rep = deepcopy(meta)
    a.out.mkdir(parents=True, exist_ok=False)
    for m, f in files.items():
        f, spec = produce(f, m, stock[m])
        d = a.out / m
        d.mkdir()
        for n, data in f.items():
            (d / n).write_bytes(data)
        spec['source_files'] = meta['sets'][m]['files']
        rep['sets'][m]['pole_floor'] = spec
        rep['sets'][m]['files'] = {n: sha(data) for n, data in f.items()}
    (a.out / 'build.json').write_text(json.dumps(rep, indent=2) + '\n')
    audit(a.build, a.out, a.rom_dir)
if __name__ == '__main__':
    main()
