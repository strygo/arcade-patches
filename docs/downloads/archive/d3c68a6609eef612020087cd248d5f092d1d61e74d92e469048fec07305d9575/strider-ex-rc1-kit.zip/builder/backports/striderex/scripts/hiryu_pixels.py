"""Clear nine detached black pixels in four original Hiryu sprite tiles."""
import argparse
from copy import deepcopy
import json
from pathlib import Path
import sys
import numpy as np
import boss_scene as B
import boss_voice_gate as V
import cps1_gfx as G
import mapper_testkit as K
PIXELS = {1845: ((8, 0), (9, 0), (10, 0)), 1974: ((0, 0), (0, 1), (0, 2), (0, 3)), 5173: ((0, 15),), 5315: ((0, 15),)}
SOURCES = {1845: 'dd5f7255633db792a5f28e3cd55103a54f8e0e03efc4226527955428c19c0baf', 1974: 'f4a9c29943506d4649de11c89c39c4e20829c225741f2da0af201384e7c284dd', 5173: 'a87e8cd904cd62f9f2ad0740224ab5862bbfd8663f6508b6f76c64ce3c312075', 5315: '3d3c0d5b43bd7c627ca2049d9129c551d88483c6f7f94a392f0272332d8f02b1'}

def repair(region):
    out = bytearray(region)
    for code, points in PIXELS.items():
        tile = G.get_tile(region, code * 128, 16)
        if V.sha(tile.astype('uint8').tobytes()) != SOURCES[code]:
            raise ValueError('Hiryu source tile differs: ' + hex(code))
        for x, y in points:
            if tile[y, x] != 0:
                raise ValueError('expected a black source pixel')
            tile[y, x] = 15
        G.put_tile(out, code * 128, tile)
    return out

def members(rom_dir, machine, region):
    stock = {p.name: p.read_bytes() for p in (rom_dir / machine).iterdir() if p.is_file()}
    result = {}
    for offset, crc in K.GFX_CRCS.items():
        names = [n for n, b in stock.items() if K.crc(b) == crc]
        if len(names) != 1:
            raise ValueError('canonical graphics member missing or ambiguous: ' + crc)
        name = names[0]
        view = np.frombuffer(region, dtype='uint8').reshape(-1, 8)
        data = view[offset // 8:, offset % 8:offset % 8 + 2].tobytes()
        data = data[:len(stock[name])]
        if data != stock[name]:
            result[name] = data
    return result

def produce(a):
    meta, files = V.inventory(a.build)
    rep = deepcopy(meta)
    stock = B.stock_gfx(a.rom_dir)
    fixed = repair(stock)
    a.out.mkdir(parents=True, exist_ok=False)
    for machine, original in files.items():
        changed = members(a.rom_dir, machine, fixed)
        if set(changed) & set(original):
            raise ValueError('input already replaces original graphics')
        result = dict(original, **changed)
        d = a.out / machine
        d.mkdir()
        for name, data in result.items():
            (d / name).write_bytes(data)
        rep['sets'][machine]['files'] = {n: V.sha(b) for n, b in result.items()}
        rep['sets'][machine]['hiryu_pixels'] = dict(pixels={hex(c): list(p) for c, p in PIXELS.items()}, source_pens_sha256={hex(c): h for c, h in SOURCES.items()}, native_graphics_overrides={n: V.sha(b) for n, b in changed.items()}, source_files=meta['sets'][machine]['files'], code_palettes_animation_audio_unchanged=True)
    (a.out / 'build.json').write_text(json.dumps(rep, indent=2) + '\n')
    print('PASS: nine black pixels cleared in four Hiryu tiles; all other pixels and existing ROM members exact')

def self_test():
    source = bytearray(128)
    pens = np.full((16, 16), 15, dtype='int32')
    for x, y in PIXELS[1845]:
        pens[y, x] = 0
    G.put_tile(source, 0, pens)
    assert np.array_equal(G.get_tile(source, 0, 16), pens)
    assert sum(map(len, PIXELS.values())) == 9
    print('Hiryu pixel self-test PASS: exact coordinates and graphics round trip')
if __name__ == '__main__':
    if sys.argv[1:] == ['--self-test']:
        self_test()
    else:
        p = argparse.ArgumentParser(description=__doc__)
        for name in ('build', 'rom-dir', 'out'):
            p.add_argument('--' + name, type=Path, required=True)
        produce(p.parse_args())
