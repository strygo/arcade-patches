; Long Dash's position trigger precedes Solo's first portrait. Record the
; native music byte on that trigger, but let the scene's existing restart
; queue the tune after dialogue. A retry retains the original setter.
bm_siberia_entry:
        btst #2,$FFF9E8
        bne.s .original
        tst.b $B94(a5)                 ; preserve the native hurry/hold gate and D0
        bne.s .remember
        move.w #8,d0
        bra.s .remember
.original:
        jsr SIB_SETTER
.remember:
        move.b #8,$FF10C5
        rts
