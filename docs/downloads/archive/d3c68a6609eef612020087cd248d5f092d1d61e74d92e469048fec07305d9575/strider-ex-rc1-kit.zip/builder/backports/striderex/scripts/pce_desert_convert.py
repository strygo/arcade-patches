"""Phase 1 milestone 9: convert the PC Engine desert maps to arcade SCROLL3 layer data."""
import argparse
import hashlib
import json
import sys
from pathlib import Path
import numpy as np
sys.path.insert(0, str(Path(__file__).resolve().parent))
import cps1_gfx as G
FIRST_CODE, LAST_CODE = (14338, 16383)
TILE, SEC_W, SEC_H, GRID_W, GRID_H = (32, 12, 8, 32, 8)
WORLD_W, WORLD_H = (SEC_W * TILE * GRID_W, SEC_H * TILE * GRID_H)
SHAPES_AT, SHAPES = (25496, 16)

def widen(a):
    """Method E on a color-id image (0 transparent, as rescale_pilot's TRANSPARENT = -1)."""
    from rescale_pilot import method_edge_pick
    return (method_edge_pick(a.astype(np.int32) - 1) + 1).astype(a.dtype)

def widen_copy(a):
    """1.5x for masks: [a, a, b] per source pair (the inserted column copies its left neighbor)."""
    if a.shape[1] % 2:
        a = np.pad(a, ((0, 0), (0, 1)), mode='edge')
    l, r = (a[:, 0::2], a[:, 1::2])
    return np.stack([l, l, r], -1).reshape(a.shape[0], -1)

def entry_bytes(code, flipx, flipy, pal, group=0):
    w = code | flipx << 15 | flipy << 14
    return bytes([w >> 8, w & 255, pal | group << 5, 0])

def entry_decode(b):
    """As the streamer (0x1E696): VRAM code word and attribute."""
    w = b[0] << 8 | b[1]
    return (w & 16383, b[2] & 31 | (w >> 15 & 1) << 5 | (w >> 14 & 1) << 6 | (b[2] >> 5 & 3) << 7)

def solid_mask(s, shapes):
    """Per-pixel solid mask and flags of one map (PC Engine routine 0x6377/0x6351)."""
    cls = np.frombuffer(s['collision'], np.uint8)[np.minimum(s['map'], 511)]
    shape = np.frombuffer(s['class_table'], np.uint8)[0::2][cls]
    flags = np.frombuffer(s['class_table'], np.uint8)[1::2][cls]
    prof = np.frombuffer(shapes, np.uint8).reshape(SHAPES, 16)[shape & 15]
    y = np.arange(16)[None, None, :, None]
    solid = (prof[:, :, None, :] != 255) & (y >= prof[:, :, None, :]) & (flags[:, :, None, None] != 0)
    h, w = s['map'].shape
    solid = solid.transpose(0, 2, 1, 3).reshape(h * 16, w * 16)
    fl = np.repeat(np.repeat(flags, 16, 0), 16, 1)
    valid = np.repeat(np.repeat(s['map'] < len(s['defs']), 16, 0), 16, 1)
    return (solid & valid, np.where(solid & valid, fl, 0))

def tile_profile(sol, fl):
    tops = tuple((int(np.argmax(c)) if c.any() else 255 for c in sol.T))
    return (tops, tuple(sorted((int(v) for v in np.unique(fl[sol])))))

def flip_variants(pens, prof):
    """(flipx, flipy, pens, profile) for the four orientations; Y flips only without collision."""
    tops, flags = prof
    out = []
    for fx in (0, 1):
        for fy in (0, 1):
            if fy and any((t != 255 for t in tops)):
                continue
            p = pens[::-1] if fy else pens
            p = p[:, ::-1] if fx else p
            t = tops[::-1] if fx else tops
            out.append((fx, fy, p, (t, flags)))
    return out

def pack_palettes(color_sets, limit=32):
    """First-fit decreasing: each tile's color set into a palette of <= 15 colors."""
    pals, assign = ([], {})
    for key in sorted(set(color_sets), key=lambda k: -len(k)):
        for i, p in enumerate(pals):
            if set(key) <= p:
                assign[key] = i
                break
        else:
            for i, p in enumerate(pals):
                if len(p | set(key)) <= 15:
                    p |= set(key)
                    assign[key] = i
                    break
            else:
                pals.append(set(key))
                assign[key] = len(pals) - 1
    if len(pals) > limit:
        sys.exit(f'pce_desert_convert: {len(pals)} palettes needed, {limit} available')
    return ([sorted(p) for p in pals], assign)

def cut(maps):
    """[(name, col, row, 32x32 color ids, color set, collision profile)] of every tile of the maps with art or solid."""
    tiles = []
    for name, x0, y0, img, colors, sol, fl in maps:
        wimg, wsol, wfl = (widen(img), widen_copy(sol), widen_copy(fl))
        X0 = x0 * 3 // 2
        left, top = (X0 % TILE, y0 % TILE)
        wimg = np.pad(wimg, ((top, -(top + wimg.shape[0]) % TILE), (left, -(left + wimg.shape[1]) % TILE)))
        wsol = np.pad(wsol, ((top, wimg.shape[0] - top - wsol.shape[0]), (left, wimg.shape[1] - left - wsol.shape[1])))
        wfl = np.pad(wfl, ((top, wimg.shape[0] - top - wfl.shape[0]), (left, wimg.shape[1] - left - wfl.shape[1])))
        c0, r0 = ((X0 - left) // TILE, (y0 - top) // TILE)
        for ty in range(wimg.shape[0] // TILE):
            for tx in range(wimg.shape[1] // TILE):
                t = wimg[ty * TILE:(ty + 1) * TILE, tx * TILE:(tx + 1) * TILE]
                ts = wsol[ty * TILE:(ty + 1) * TILE, tx * TILE:(tx + 1) * TILE]
                if not t.any() and (not ts.any()):
                    continue
                cs = tuple(sorted((int(v) for v in np.unique(t) if v)))
                if len(cs) > 15:
                    sys.exit(f'{name}: tile ({tx}, {ty}) has {len(cs)} colors')
                prof = tile_profile(ts, wfl[ty * TILE:(ty + 1) * TILE, tx * TILE:(tx + 1) * TILE])
                tiles.append((name, c0 + tx, r0 + ty, t, cs, prof))
    return tiles

def convert(maps, shapes, extra=(), cycle=(), extra_codes=None):
    """maps: [(name, x0, y0, color-id image (0 transparent), colors {id: pce9}, solid, flags)]. extra: more worlds in"""
    tiles = cut(maps)
    pals, assign = pack_palettes([cs for *_, cs, _ in tiles])
    more = cut(extra)
    cyc = tuple(cycle)
    if cyc and min(cyc) <= max((v for *_, cs, _ in tiles + more for v in cs if v not in cyc)):
        sys.exit('pce_desert_convert: the cycled colors must be the highest color ids')
    have = [set(p) for p in pals]
    new_keys = []
    for name, col, row, t, cs, prof in more:
        key = tuple(sorted(set(cs) | set(cyc))) if set(cs) & set(cyc) else cs
        if key in assign or key in new_keys:
            continue
        if not set(key) & set(cyc):
            hit = next((i for i, p in enumerate(have) if set(key) <= p), None)
            if hit is not None:
                assign[key] = hit
                continue
        new_keys.append(key)
    if new_keys:
        npals, nassign = pack_palettes(new_keys, limit=32 - len(pals))
        for k, i in nassign.items():
            assign[k] = len(pals) + i
        pals += npals
    if len(pals) > 32:
        sys.exit(f'pce_desert_convert: {len(pals)} palettes needed, 32 available')
    pen_of = [{c: i for i, c in enumerate(p)} for p in pals]
    codes, region, placed = ({}, bytearray(4 * G.MB), {})
    n_base, later = (None, [])
    for i, (name, col, row, t, cs, prof) in enumerate(tiles + more):
        if i == len(tiles):
            n_base = len(codes)
        key = tuple(sorted(set(cs) | set(cyc))) if set(cs) & set(cyc) else cs
        pal = assign[key]
        pens = np.vectorize(lambda v: 15 if v == 0 else pen_of[pal][int(v)])(t).astype(np.uint8)
        hit = None
        for fx, fy, p, pr in flip_variants(pens, prof):
            k = (p.tobytes(), pr)
            if k in codes:
                hit = (codes[k], fx, fy)
                break
        if hit is None:
            if n_base is None:
                code = FIRST_CODE + len(codes)
                if code > LAST_CODE:
                    sys.exit('pce_desert_convert: EX SCROLL3 codes exhausted')
                G.put_tile(region, G.ex_offset('scr3', code), pens)
            else:
                code = -1 - len(later)
                later.append(pens)
            codes[pens.tobytes(), prof] = code
            hit = (code, 0, 0)
        placed[name, col, row] = (hit[0], hit[1], hit[2], pal, prof)
    if later:
        first, last = extra_codes
        if len(later) > last - first + 1:
            sys.exit(f'pce_desert_convert: {len(later)} more tiles do not fit {first:#x}-{last:#x}')
        real = {-1 - i: last - i for i in range(len(later))}
        for i, pens in enumerate(later):
            G.put_tile(region, G.ex_offset('scr3', last - i), pens)
        codes = {k: real.get(c, c) for k, c in codes.items()}
        placed = {k: (real.get(v[0], v[0]),) + v[1:] for k, v in placed.items()}
    cycled = []
    for i, p in enumerate(pals):
        if set(cyc) & set(p):
            first = p.index(cyc[0])
            if p[first:first + len(cyc)] != list(cyc):
                sys.exit(f'pce_desert_convert: palette {i} does not hold the cycle in order')
            cycled.append((i, first))
    if extra:
        return (pals, codes, region, placed, cycled)
    return (pals, codes, region, placed)

def emit(name, placed, colors_of):
    """Grid and sections of one map's world; empty section 0 everywhere else."""
    cells = {(c, r): v for (n, c, r), v in placed.items() if n == name}
    sections, index, grid = ([bytes(SEC_W * SEC_H * 4)], {}, bytearray(GRID_W * GRID_H))
    for gx in range(GRID_W):
        for gy in range(GRID_H):
            body = bytearray()
            for sr in range(SEC_H):
                for sc in range(SEC_W):
                    wr = gy * SEC_H + sr
                    v = cells.get((gx * SEC_W + sc, 63 - wr))
                    body += entry_bytes(v[0], v[1], v[2], v[3]) if v else bytes(4)
            body = bytes(body)
            if body == sections[0]:
                continue
            if body not in index:
                index[body] = len(sections)
                sections.append(body)
            grid[gy * GRID_W + gx] = index[body]
    if len(sections) > 256:
        sys.exit(f'{name}: {len(sections)} sections (a grid byte holds 255)')
    return (bytes(grid), sections)

def render(grid, sections, region, pal_words):
    """Screen image (VRAM rows top-down) as the streamer lays it out: CPS-1 color words, 0 transparent."""
    out = np.zeros((WORLD_H, WORLD_W), np.uint32)
    cache = {}
    for gy in range(GRID_H):
        for gx in range(GRID_W):
            sec = sections[grid[gy * GRID_W + gx]]
            for sr in range(SEC_H):
                for sc in range(SEC_W):
                    e = sec[(sr * SEC_W + sc) * 4:(sr * SEC_W + sc) * 4 + 4]
                    if not any(e):
                        continue
                    code, attr = entry_decode(e)
                    if code not in cache:
                        cache[code] = G.get_tile(region, G.ex_offset('scr3', code), TILE)
                    pens = cache[code]
                    if attr >> 5 & 1:
                        pens = pens[:, ::-1]
                    if attr >> 6 & 1:
                        pens = pens[::-1]
                    words = np.where(pens == 15, 0, pal_words[attr & 31][np.minimum(pens, 14)])
                    vr = 63 - (gy * SEC_H + sr)
                    col = gx * SEC_W + sc
                    out[vr * TILE:(vr + 1) * TILE, col * TILE:(col + 1) * TILE] = words
    return out

def expected(img, colors, x0, y0):
    wimg = widen(img)
    X0 = x0 * 3 // 2
    out = np.zeros((WORLD_H, WORLD_W), np.uint32)
    lut = np.zeros(max(colors) + 1, np.uint32)
    for k, v in colors.items():
        lut[k] = G.cps_color(v)
    out[y0:y0 + wimg.shape[0], X0:X0 + wimg.shape[1]] = lut[wimg]
    return out

def load_maps(capture):
    import pce_desert_maps as M
    import pce_vdc as pv
    rows, entries = M.verified_maps(capture)
    if not entries or any((v is None for v in entries.values())):
        sys.exit('pce_desert_convert: a map does not verify against its screen in this census')
    ids, maps, shapes = ({}, [], None)
    for (w, r0, c0), (s, d, row) in sorted(entries.items(), key=lambda kv: kv[0][2] if kv[0][2] in (0, 166) else kv[0][2] + 256):
        rgb, words, valid, idx = M.render(s, d)
        pal = d['pal']
        cid = np.zeros(idx.shape, np.uint16)
        nz = idx & 15 != 0
        for v in np.unique(pal[idx[nz]]):
            ids.setdefault(int(v), len(ids) + 1)
        lut = np.zeros(512, np.uint16)
        for v, k in ids.items():
            lut[v] = k
        cid[nz] = lut[pal[idx[nz]]]
        c = (capture / f"pce_{s['tag']}_ram_0d0000.bin").read_bytes()
        shapes = c[(105 - 104) * 8192 + SHAPES_AT - 24576:][:SHAPES * 16]
        sol, fl = solid_mask(s, shapes)
        col0 = c0 if c0 in (0, 166) else c0 + 256
        maps.append((M.name_of(s), col0 * 16, r0 * 16, cid, None, sol, fl))
    colors = {k: v for v, k in ids.items()}
    return ([(n, x0, y0, img, colors, sol, fl) for n, x0, y0, img, _, sol, fl in maps], shapes)

def run(capture, out):
    from PIL import Image
    out.mkdir(parents=True)
    maps, shapes = load_maps(capture)
    pals, codes, region, placed = convert(maps, shapes)
    colors = maps[0][4]
    pal_words = np.zeros((32, 16), np.uint32)
    for i, p in enumerate(pals):
        for j, c in enumerate(p):
            pal_words[i, j] = G.cps_color(colors[c])
    report = dict(maps=[], palettes=len(pals), codes=len(codes), code_range=[f'0x{FIRST_CODE:04X}', f'0x{FIRST_CODE + len(codes) - 1:04X}'], tile_bytes=512 * len(codes))
    collision = {}
    for (n, col, row), (code, fx, fy, pal, prof) in placed.items():
        if any((t != 255 for t in prof[0])):
            collision[f'0x{code:04X}'] = dict(tops=list(prof[0]), flags=[f'0x{f:02X}' for f in prof[1]])
    ok = True
    for k, (name, x0, y0, img, colors, sol, fl) in enumerate(maps):
        grid, sections = emit(name, placed, colors)
        got = render(grid, sections, region, pal_words)
        want = expected(img, colors, x0, y0)
        bad = int((got != want).sum())
        ok &= bad == 0
        (out / f'map{k}_grid.bin').write_bytes(grid)
        (out / f'map{k}_sections.bin').write_bytes(b''.join(sections))
        rgb = np.stack([(got >> 8 & 15) * 17, (got >> 4 & 15) * 17, (got & 15) * 17], -1).astype(np.uint8)
        x1 = (x0 + img.shape[1]) * 3 // 2
        Image.fromarray(rgb[y0:y0 + img.shape[0], x0 * 3 // 2:x1]).save(out / f'map{k}.png')
        report['maps'].append(dict(name=name, pce_origin=[x0, y0], arcade_origin=[x0 * 3 // 2, y0], arcade_size=[x1 - x0 * 3 // 2, img.shape[0]], sections=len(sections) - 1, tiles=sum((1 for p in placed if p[0] == name)), pixel_mismatches=bad, grid_sha256=hashlib.sha256(grid).hexdigest(), sections_sha256=hashlib.sha256(b''.join(sections)).hexdigest()))
    gfx = bytes(region[3 * G.MB:3 * G.MB + 512 * (FIRST_CODE - 14336 + len(codes))])
    (out / 'scroll3_ex.bin').write_bytes(gfx)
    (out / 'palettes.bin').write_bytes(b''.join((int(w).to_bytes(2, 'big') for w in pal_words.ravel())))
    (out / 'collision.json').write_text(json.dumps(collision, indent=0) + '\n')
    report.update(collision_codes=len(collision), scroll3_ex_sha256=hashlib.sha256(gfx).hexdigest(), palettes_sha256=hashlib.sha256((out / 'palettes.bin').read_bytes()).hexdigest(), passed=ok)
    (out / 'report.json').write_text(json.dumps(report, indent=1) + '\n')
    print(json.dumps(report, indent=1))
    return 0 if ok else 1

def self_test():
    for code, fx, fy, pal, grp in ((14338, 0, 0, 0, 0), (16383, 1, 0, 31, 2), (14848, 0, 1, 5, 3)):
        c, attr = entry_decode(entry_bytes(code, fx, fy, pal, grp))
        assert c == code and attr == pal | fx << 5 | fy << 6 | grp << 7, (code, attr)
    rng = np.random.default_rng(5)
    img = np.zeros((64, 64), np.uint16)
    img[:32, :32] = rng.integers(1, 9, (32, 32))
    img[:32, 32:] = img[:32, :32][:, ::-1]
    colors = {k: k * 37 & 511 for k in range(1, 9)}
    sol = np.zeros((64, 64), bool)
    sol[48:, :] = True
    fl = np.where(sol, 128, 0).astype(np.uint8)
    maps = [('t', 0, 1536, img, colors, sol, fl)]
    pals, codes, region, placed = convert(maps, None)
    grid, sections = emit('t', placed, colors)
    pw = np.zeros((32, 16), np.uint32)
    for i, p in enumerate(pals):
        for j, c in enumerate(p):
            pw[i, j] = G.cps_color(colors[c])
    got = render(grid, sections, region, pw)
    want = expected(img, colors, 0, 1536)
    assert (got == want).all(), int((got != want).sum())
    assert widen(img).shape[1] == 96
    assert any((p[4][0][0] == 16 for k, p in placed.items() if k[2] == 49)), 'invisible solid tile lost'
    print('pce_desert_convert self-test passed:', len(codes), 'codes,', len(pals), 'palettes')
    return 0

def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('capture', nargs='?', type=Path)
    p.add_argument('--out', type=Path)
    p.add_argument('--self-test', action='store_true')
    a = p.parse_args()
    if a.self_test:
        return self_test()
    if not (a.capture and a.out):
        p.error('give the census directory and --out')
    if a.out.exists():
        p.error('use a fresh --out directory')
    return run(a.capture, a.out)
if __name__ == '__main__':
    sys.exit(main())
