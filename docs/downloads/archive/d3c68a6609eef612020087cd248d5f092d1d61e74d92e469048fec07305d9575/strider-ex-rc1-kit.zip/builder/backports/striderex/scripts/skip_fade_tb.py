"""The START skip's fade on the core's CPS+ RTL: a CPS-1 chain simulation on the latch writes the ROM makes."""
import argparse
import json
import math
import struct
import subprocess
import sys
from pathlib import Path
import numpy as np
sys.path.insert(0, str(Path(__file__).resolve().parent))
import pack_model as PM
ROOT = Path(__file__).resolve().parents[3]
TB = ROOT / 'cpsplus/rtl/tb/tb_cps1_chain.v'
HDL_FILES = ('cpsplus_cps1_top.v', 'cpsplus_cps1_tap.v', 'cpsplus_ddr.v', 'cpsplus_player.v', 'cpsplus_adx.v')
CUES = ROOT / 'backports/striderex/manifests/ex_pack_cues.json'
RATE = 48000
FR_NUM, FR_DEN = (59637, 48000000)
WRITE_AT = 200
TICK = 16
BASE = 805306368
STOP = 241

def frame_tick(k):
    """The sample tick at which tb_cps1_chain.v fires VBlank k (k >= 1): the first n with n * FR_NUM >= k * FR_DEN."""
    return -(-k * FR_DEN // FR_NUM)

def write_tick(frame):
    """The sample tick of a write made in frame `frame` (after VBlank frame - 1)."""
    return (frame_tick(frame - 1) if frame > 1 else 0) + WRITE_AT

def read_run(run):
    """A skip run's latch writes [(frame, byte)] and its press frame."""
    writes = []
    for line in (run / 'sound.tsv').read_text().splitlines():
        f, _, v = line.split('\t')[:3]
        writes.append((int(f), int(v, 16) & 255))
    meta = {l.split('\t')[0]: [int(x) for x in l.split('\t')[1:]] for l in (run / 'meta.tsv').read_text().splitlines()}
    return (writes, meta['press'][0])

def stimulus_from_run(model, writes, press, fade_cmd, lead, tail):
    """(writes in simulated frames, notes): from the skipped scene's cue to tail frames after the next start."""
    ev, _ = model.run(writes)
    starts = [(f, v) for f, v, _, _, e in ev if e == 'start']
    cue_f, cue_v = max((s for s in starts if s[0] < press), default=(None, None))
    if cue_f is None:
        sys.exit('no track started before the press')
    fade_f = next((f for f, v in writes if f > press and v == fade_cmd), None)
    if fade_f is None:
        sys.exit(f'no fade byte {fade_cmd:#04x} after the press (frame {press})')
    nxt = next((f for f, v in starts if f > fade_f), None)
    end = (nxt if nxt is not None else fade_f + model.fade_frames(0)) + tail
    held = {v for f, v in writes if cue_f < f < press}
    if not held <= {cue_v, 255}:
        sys.exit(f'between the cue and the press the latch carries {sorted(held)}: the cut would drop a command')
    shift = press - cue_f - lead
    if shift < 0:
        sys.exit(f'the press comes {press - cue_f} frames after the cue, less than --lead {lead}')
    out = []
    for f, v in writes:
        if f < cue_f or f > end:
            continue
        if cue_f < f < press:
            if f - cue_f > 2:
                continue
            g = f - cue_f + 2
        else:
            g = f - cue_f + 2 if f <= cue_f else f - shift - cue_f + 2
        out.append((g, v))
    notes = dict(cue=f'{cue_v:#04x}', cue_frame=cue_f, press=press, fade_frame=fade_f, next_start=nxt, frames_cut=shift, sim_frames=max(out[-1][0], end - shift - cue_f + 2) + 2)
    return (out, notes)

def same_song_stimulus(model, fade_cmd):
    """A cue, its idle, the fade 40 frames in, the same cue after the fade's end, STOP, the same cue."""
    cue = next((i for i, r in enumerate(model.triggers) if r.verb == PM.VERB_PLAY and (not model.tracks[r.track].loop_end_byte) and (i < model.ctrl_start)))
    n = model.fade_frames(0)
    a = 2
    f = a + 40
    w = [(a, cue), (a + 1, 255), (f, fade_cmd), (f + 1, 255), (f + n + 4, cue), (f + n + 5, 255), (f + n + 8, STOP), (f + n + 9, 255), (f + n + 12, cue), (f + n + 13, 255)]
    return (w, dict(cue=f'{cue:#04x}', sim_frames=f + n + 12 + 30))

def window_image(rd, model, writes, frames):
    """The pack's header and tables with every track the writes start relocated behind them, each cut to"""
    h = rd.header
    ev, _ = model.run(writes)
    tracks = sorted({t for _, _, _, t, e in ev if e == 'start'})
    head = bytearray(Path(rd.path).read_bytes()[:h.data_offset])
    data, where = (bytearray(), {})
    for t in tracks:
        m = rd.tracks[t]
        need = (frames / PM.CPS1_HZ + 1.0) * m.sample_rate
        nbytes = min(m.data_length, (int(need) // 32 + 2) * 18 * m.channels)
        off = len(data)
        struct.pack_into('<I', head, h.index_offset + t * 32, off)
        data += rd.read_track(t)[:nbytes]
        data += b'\x00' * (-len(data) % 64)
        where[t] = (off, nbytes)
    return (bytes(head + data), where)

def simulate(hdl, work, img, stim_ticks, nticks):
    work.mkdir(parents=True, exist_ok=False)
    (work / 'win.hex').write_text('\n'.join((f'{b:02x}' for b in img)) + '\n')
    (work / 'stim.hex').write_text('\n'.join((f'{t:08x}{v:02x}' for t, v in stim_ticks)) + '\n')
    vvp = work / 'tb.vvp'
    src = [str(TB)] + [str(hdl / f) for f in HDL_FILES]
    subprocess.run(['iverilog', '-g2005', '-o', str(vvp)] + src, check=True, capture_output=True, text=True)
    p = subprocess.run(['vvp', '-n', str(vvp), f"+WIN={work / 'win.hex'}", f'+WSIZE={len(img)}', f'+BASE={BASE}', f"+STIM={work / 'stim.hex'}", f'+NTICK={nticks}', f"+OUT={work / 'tb.log'}", f'+TICK={TICK}', f'+FR_NUM={FR_NUM}', f'+FR_DEN={FR_DEN}'], cwd=hdl, capture_output=True, text=True, timeout=7200)
    (work / 'vvp.log').write_text(p.stdout + p.stderr)
    if 'TB_CPS1_CHAIN DONE' not in p.stdout:
        sys.exit(f'simulation failed: {p.stdout[-2000:]} {p.stderr[-2000:]}')
    return parse_log(work / 'tb.log')

def parse_log(path):
    """The TB log by kind. S lines also carry, last, the number of I lines (track starts) before them in the"""
    log = dict(L=[], E=[], I=[], F=[], S=[], D=[])
    for line in path.read_text().splitlines():
        k, *f = line.split()
        if k in log:
            row = tuple((-1 if 'x' in x.lower() and k != 'L' else int(x, 16) if k == 'L' and i == 1 else int(x) for i, x in enumerate(f)))
            log[k].append(row + (len(log['I']),) if k == 'S' else row)
    return log

def analyze(rd, model, writes, log, fade_cmd):
    """Compare the simulation with the model and the pack's decode. -> report dict (checks, curve)."""
    ev, segs = model.run(writes)
    rep, checks = (dict(), {})
    want = [(verb, t if verb == PM.VERB_PLAY else 0, 1 if model.classify(v)[2] else 0) for f, v, verb, t, e in ev if verb != PM.VERB_NONE]
    got = [(verb, trk if verb == PM.VERB_PLAY else 0, ctrl) for _, verb, trk, ctrl, _ in log['E']]
    checks['events'] = got == want
    rep['events'] = dict(got=got, want=want)
    inits = [t for t, in log['I']]
    started = [(f, t) for f, v, _, t, e in ev if e == 'start']
    checks['starts'] = len(inits) == len(started)
    exact, compared = (0, 0)
    per_track = []
    for k, (t0, (f, trk)) in enumerate(zip(inits, started)):
        sel = [s for s in log['S'] if s[4] == k + 1]
        pcm = np.frombuffer(PM.audition._decode_track(rd, trk), '<i2').reshape(-1, rd.tracks[trk].channels)
        ok = 0
        for i, (tick, l, r, tq, _) in enumerate(sel):
            if i >= len(pcm):
                break
            if (l, r) == (int(pcm[i, 0]) * tq >> 14, int(pcm[i, -1]) * tq >> 14):
                ok += 1
        per_track.append(dict(track=trk, name=rd.tracks[trk].name, frame=f, samples=len(sel), exact=ok))
        exact += ok
        compared += min(len(sel), len(pcm))
    rep['tracks'] = per_track
    checks['samples_exact'] = compared > 0 and exact == compared
    fades = [(f, v) for f, v, _, _, e in ev if e == 'fade']
    curve = []
    if fades:
        ff = fades[0][0]
        _, _, fd = model.state_fade(segs, ff)
        if fd is None:
            fd = PM.Fade(ff, model.fade_frames(0), PM.UNITY, True)
            checks['playing_at_fade'] = False
        fticks = [x for x in log['F'] if x[1] >= ff - 1]
        write_t = write_tick(ff)
        ok = fd is not None
        for tick, frame, tq, act, playing, left in fticks:
            if frame > fd.end + 3:
                break
            track, _, mf = model.state_fade(segs, frame)
            want_tq = PM.total_q14(mf.level(frame)) if track is not None and mf is not None else 16384 if track is not None else 0
            want_playing = 1 if track is not None else 0
            seg = [s for s in log['S'] if tick < s[0] <= frame_tick(frame + 1)]
            y = np.array([[s[1], s[2]] for s in seg], np.float64) / 32768
            rms = float(20 * np.log10(np.sqrt((y ** 2).mean()) + 1e-20)) if len(y) else -math.inf
            row = dict(frame=frame, k=frame - ff + 1, ms=round((tick - write_t) / RATE * 1000, 2), total_q14=tq, gain_db=round(20 * math.log10(tq / 16384), 2) if tq else -math.inf, fade_act=act, playing=playing, frames_left=left, out_dbfs=round(rms, 2), want_total_q14=want_tq, want_playing=want_playing)
            ok &= (tq == want_tq or not playing) and playing == want_playing
            curve.append(row)
        land = next((r for r in curve if r['k'] >= 1 and (not r['playing'])), None)
        dones = [t for t, in log['D']]
        cut = next((f for f, t in started if ff <= f <= fd.end), None)
        checks['fade_curve'] = ok
        if cut is None:
            land_t = frame_tick(land['frame']) if land else None
            nxt = next((i for i in inits if land and i > land_t), None)
            after = [s for s in log['S'] if land and land_t < s[0] < (nxt if nxt is not None else 1 << 62)]
            checks['fade_lands'] = land is not None and land['k'] == fd.frames and any((abs(d - land_t) < 4 for d in dones))
            checks['silent_after'] = land is not None and (not after)
        else:
            nxt = next((i for i in inits if i > write_t), None)
            row = next((r for r in curve if r['frame'] == cut), None)
            checks['cut_by_next'] = row is not None and row['total_q14'] == 16384 and (row['playing'] == 1) and (not any((write_t < d < (nxt or 0) for d in dones)))
            rep['cut'] = dict(frame=cut, k=cut - ff + 1, total_q14_before=next((r['total_q14'] for r in curve if r['frame'] == cut - 1), None))
        checks['fade_starts'] = any((r['k'] == 0 and r['total_q14'] == 16384 for r in curve)) and any((r['k'] == 1 and r['total_q14'] < 16384 for r in curve))
        rep['fade'] = dict(byte=f'{fades[0][1]:#04x}', frame=ff, frames=fd.frames, step=fd.step, first_tick_ms=round((frame_tick(ff) - write_t) / RATE * 1000, 2), landing_ms=round((frame_tick(fd.end) - write_t) / RATE * 1000, 2) if land else None, next_start_ms=round((nxt - write_t) / RATE * 1000, 2) if nxt else None)
    rep['curve'] = curve
    rep['checks'] = checks
    rep['passed'] = all(checks.values())
    return rep

def self_test():
    assert frame_tick(1) == 805 and frame_tick(2) == 1610 and (write_tick(1) == WRITE_AT)
    assert write_tick(3) == frame_tick(2) + WRITE_AT
    print('skip_fade_tb self-test OK')
    return 0

def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('--pack', type=Path)
    p.add_argument('--run', type=Path, help='an ex_gate.py skip run directory (sound.tsv, meta.tsv)')
    p.add_argument('--same-song', action='store_true')
    p.add_argument('--hdl', type=Path, default=ROOT / 'cpsplus/rtl')
    p.add_argument('--workdir', type=Path)
    p.add_argument('--lead', type=int, default=60)
    p.add_argument('--tail', type=int, default=30)
    p.add_argument('--self-test', action='store_true')
    a = p.parse_args()
    if a.self_test:
        return self_test()
    model = PM.Model(a.pack)
    fade_cmd = int(json.loads(CUES.read_text())['skip_fade']['cue'], 16)
    if a.same_song:
        writes, notes = same_song_stimulus(model, fade_cmd)
    else:
        w, press = read_run(a.run)
        writes, notes = stimulus_from_run(model, w, press, fade_cmd, a.lead, a.tail)
    frames = notes['sim_frames']
    img, where = window_image(model.rd, model, writes, frames)
    stim = [(write_tick(f), v) for f, v in writes]
    log = simulate(a.hdl.resolve(), a.workdir.resolve(), img, stim, frame_tick(frames))
    rep = analyze(model.rd, model, writes, log, fade_cmd)
    rep.update(notes=notes, hdl=str(a.hdl), writes=[(f, f'{v:#04x}') for f, v in writes], window_bytes=len(img), tracks_in_window={str(k): v for k, v in where.items()})
    (a.workdir / 'report.json').write_text(json.dumps(rep, indent=1, default=str) + '\n')
    print(json.dumps({k: rep[k] for k in ('notes', 'tracks', 'fade', 'checks') if k in rep}, default=str))
    for r in rep['curve']:
        print('  k {k:3d} frame {frame:5d} {ms:8.2f} ms  total_q14 {total_q14:5d} ({gain_db} dB)  out {out_dbfs} dBFS  playing {playing} left {frames_left}'.format(**r))
    print('PASS' if rep['passed'] else 'FAIL')
    return 0 if rep['passed'] else 1
if __name__ == '__main__':
    sys.exit(main())
