"""Strider EX desert extra stage gates (Phase 3b; desert_ex.py, asm/desert.s)."""
import argparse
import json
import os
import struct
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import numpy as np
from PIL import Image
ROOT = Path(__file__).resolve().parents[3]
LUA = ROOT / 'backports/striderex/lua/desert_gate.lua'
DEBUG_START = ROOT / 'backports/striderex/lua/arcade_debug_start.lua'
CODES_LUA = ROOT / 'backports/striderex/lua/scroll3_codes.lua'
HBSET = ROOT / 'backports/striderex/scripts/hbmame_set.py'
PARENT = {'striderus01': 'striderua', 'striderjs01': 'striderjr'}
PLAY = '450-{e}@300/220:P1_JOYSTICK_RIGHT;450-{e}@50/15:P1_BUTTON2;450-{e}@10/3:P1_BUTTON1'
DEBUG5 = 9000
COLS = ['regs_crc', 'regs_n', 'sound', 'stage', 'area', 'mode', 'plx', 'ply', 'camx', 'camy']

def stage_sets(build, set_name, hbmame, rom_dir, out):
    """The HBMAME set of one build (hbmame_set.py). The desert build changes two more USA"""
    if not (out / set_name).is_dir():
        subprocess.run([sys.executable, str(HBSET), 'build', '--hbmame', str(hbmame), '--rom-dir', str(rom_dir), '--ex-dir', str(build), '--set', set_name, '--date', '2026-10-10', '--out', str(out)], check=True, stdout=subprocess.DEVNULL)
        d = out / set_name
        for n in ('p3', 'p4'):
            names = [d / f'c03ua.{n}', d / f'c03us01.{n}']
            have = [q for q in names if q.exists()]
            if len(have) == 1:
                for q in names:
                    if not q.exists():
                        q.write_bytes(have[0].read_bytes())
    return out

def run(binary, roms, set_name, out, env, frames, extra=()):
    out.mkdir(parents=True, exist_ok=False)
    e = dict(os.environ, SDL_VIDEODRIVER='dummy', SDL_AUDIODRIVER='dummy', OUT=str(out), END=str(frames), **env)
    if 'STREX_DEBUG_START' in env:
        e['STREX_PREFIX'] = str(out / 'dbg')
    cmd = [str(binary), set_name, '-rompath', str(roms), '-nothrottle', '-video', 'none', '-sound', 'none', '-seconds_to_run', str(frames // 50 + 30), '-skip_gameinfo', '-noautosave', '-cfg_directory', str(out / 'cfg'), '-nvram_directory', str(out / 'nv'), '-snapshot_directory', str(out), '-autoboot_script', str(LUA), *extra]
    p = subprocess.run(cmd, env=e, cwd=out, capture_output=True, text=True, timeout=1800)
    (out / 'mame.log').write_text(p.stdout + p.stderr)
    if p.returncode:
        raise SystemExit(f'{out}: HBMAME exit {p.returncode}')
    rows = read(out)
    if len(rows) != frames:
        raise SystemExit(f'{out}: {len(rows)} frames logged, {frames} expected')
    if 'STREX_DEBUG_START' in env:
        want = env['STREX_STAGE']
        if not any((r['stage'] == want and r['mode'] in ('2', '4') for r in rows[400:700])):
            raise SystemExit(f'{out}: the debug start did not start stage {want}')
    return rows

def read(out):
    rows = []
    lines = (out / 'frames.tsv').read_text().splitlines()
    head = lines[0].split('\t')
    for line in lines[1:]:
        if line.startswith('#'):
            continue
        rows.append(dict(zip(head, line.split('\t'))))
    return rows

def read_desert(out):
    """desert.tsv: the desert section machine on each change (lua/desert_gate.lua)."""
    rows = []
    lines = (out / 'desert.tsv').read_text().splitlines()
    for line in lines[1:]:
        f = line.split('\t')
        rows.append(dict(frame=int(f[0]), sec=int(f[1]), step=int(f[2]), map=int(f[3]), w0=int(f[4]), on=f[5], limits=f[6]))
    return rows

def debug_env(stage, area, end, invincible=True, inputs=True):
    env = dict(STREX_DEBUG_START=str(DEBUG_START), STREX_STAGE=str(stage), STREX_AREA=str(area), STREX_END=str(end + 100), STREX_INPUTS=PLAY.format(e=end) if inputs else '')
    if invincible:
        env['STREX_INVINCIBLE'] = '1'
    return env

def cases(frames):
    """A new game through the prologue and St. Petersburg briefing into play; each stage from"""
    n = frames + 4000
    out = {'newgame': (dict(NEWGAME='1', INPUTS=PLAY.format(e=n)), n)}
    for st in range(5):
        out[f'stage{st}'] = (debug_env(st, 0, frames), frames)
        out[f'stage{st}a3'] = (debug_env(st, 3, frames), frames)
    out['clear0'] = (dict(debug_env(0, 7, frames), CLEAR_AT='1000'), frames)
    return out

def compare(a, b, out_a, out_b):
    """First frame where the records differ, and screenshot mismatches."""
    first = None
    for ra, rb in zip(a, b):
        if any((ra[k] != rb[k] for k in COLS)):
            first = int(ra['frame'])
            break
    if first is None and len(a) != len(b):
        first = min(len(a), len(b)) + 1
    shots = sorted((q.name for q in out_a.glob('s_*.png')))
    bad = []
    for name in shots:
        qb = out_b / name
        if not qb.exists():
            bad.append(name)
            continue
        if (np.asarray(Image.open(out_a / name).convert('RGB')) != np.asarray(Image.open(qb).convert('RGB'))).any():
            bad.append(name)
    return dict(first_divergence=first, frames=len(a), shots=len(shots), shots_differ=bad[:10], n_shots_differ=len(bad))

def images(build, rom_dir, machine):
    """(program + data image 0-0xFFFFF, EX bank from 0x100000) of a build (changed members over the stock set)."""
    import respawn_fix as RF
    files = {q.name: q.read_bytes() for q in (rom_dir / machine).iterdir() if q.is_file()}
    stock = bytes(RF.compose(dict(files), RF.SETS[machine]))
    if build is None:
        return (stock, b'')
    for q in (build / machine).iterdir():
        if q.is_file():
            files[q.name] = q.read_bytes()
    p6 = files['strex_p6.bin']
    return (bytes(RF.compose(files, RF.SETS[machine])), bytes((b for i in range(0, len(p6), 2) for b in (p6[i + 1], p6[i]))))

def static(base, build, rom_dir):
    import desert_ex as DX
    import desert_actors_ex as DA
    import desert_caption as DC
    rep, ok = ({}, True)
    for machine in PARENT.values():
        stock, _ = images(None, rom_dir, machine)
        b_img, _ = images(base, rom_dir, machine)
        d_img, bank = images(build, rom_dir, machine)

        def at(a, n):
            return d_img[a:a + n] if a < 1048576 else bank[a - 1048576:a - 1048576 + n]
        s = DX.locate(stock)
        allowed, problems = ({}, [])
        for name, (pat, off, n, sym) in DX.HOOKS.items():
            allowed[s['site_' + name]] = (n, name)
        for name in ('pick_intro', 'pick_clear', 'dispatch_call'):
            allowed[s[name]] = (6, name)
        for name in DX.TASK_HOOKS:
            tgt = DX.be32(d_img, s[name] + 2)
            if d_img[s[name]:s[name] + 2] != b'N\xb9' or at(tgt, len(DX.TASK_COPY) // 2) != bytes.fromhex(DX.TASK_COPY):
                problems.append(f'{name}: the task start at {tgt:#x} is not the cycle-exact copy (desert_ex.TASK_COPY)')
        for i, (k, n) in enumerate(DX.LAYER_RECORD.items()):
            a = DX.LAYER_TABLE_DIR + 4 * i
            allowed[a] = (4, f'directory {k}')
            new = DX.be32(d_img, a)
            if new < 1048576 or at(new, 5 * n) != stock[s[f'DZ_TAB_{k}']:][:5 * n]:
                problems.append(f'directory {k}: {new:#x} is not a copy of the stock records')
        allowed[s['pal_obj']] = (4, 'sprite palette table')
        new = DX.be32(d_img, s['pal_obj'])
        if new < 1048576 or at(new, 20) != stock[s['DZ_PALOBJ_TABLE']:][:20]:
            problems.append('the sprite palette table copy differs')
        else:
            stand_in = stock[s['DZ_OBJPAL']:][:1024]
            cap_words = struct.pack('>16H', *DC.convert()['palette'])
            for area in range(6):
                blk = at(DX.be32(bank, DX.be32(bank, new + 20 - 1048576) + 4 * area - 1048576), 1024)
                moved = sorted({i // 32 for i in range(1024) if blk[i] != stand_in[i]})
                if not set(moved) <= set(DA.PAL_SLOTS.values()) | {DC.SLOT} or not moved:
                    problems.append(f'desert sprite palettes, area {area}: slots {moved} differ from the stand-in set')
                if blk[32 * DC.SLOT:32 * DC.SLOT + 32] != cap_words:
                    problems.append(f"desert sprite palettes, area {area}: slot {DC.SLOT} is not the caption's palette")
        a = DA.locate(stock)
        allowed[a['site_pool5_type3']] = (4, 'pool 5 type 3 dispatch')
        new = DX.be32(d_img, a['site_pool5_type3'])
        if not 1048576 <= new < 2097152 or DX.be32(b_img, a['site_pool5_type3']) != a['DA_TYPE3_STOCK'] or bank[new - 1048576:new - 1048576 + 2] == b'Nu':
            problems.append(f'pool 5 type 3: {new:#x} is not an EX dispatcher')
        tabs = DX.collision_tables(stock)
        for k, ((pg, ty, fpg, fl, recs), imms) in DX.collision_refs(stock).items():
            allowed[pg + DX.DZ_SLOT] = (1, f'set {k} page slot')
            if stock[pg + DX.DZ_SLOT] != 0 or d_img[pg + DX.DZ_SLOT] != tabs[k]['pages'] + 1:
                problems.append(f'set {k}: the desert page slot')
            for a in imms:
                allowed[a] = (4, f'set {k} type table')
                new = DX.be32(d_img, a)
                n = tabs[k]['pages'] * 256
                if new < 1048576 or at(new, n) != stock[ty:ty + n]:
                    problems.append(f'set {k}: the type table copy at {new:#x} differs')
            for t in tabs[k]['free']:
                allowed[recs + (t - 32) * 33] = (33, f'set {k} free type {t:#x}')
        spans = sorted(((a, a + n, what) for a, (n, what) in allowed.items()))
        changed, seen, moved = ([], set(), set())

        def ex_pointer(a):
            """a lies in a long that points into the EX bank in both builds (an EX symbol the"""
            for o in range(a - a % 2 - 2, a + 1, 2):
                vb, vd = (DX.be32(b_img, o), DX.be32(d_img, o))
                if vb != vd and 1048576 <= vb < 2097152 and (1048576 <= vd < 2097152) and (o <= a < o + 4):
                    return o
            return None
        for a in range(1048576):
            if b_img[a] != d_img[a]:
                hit = next((w for lo, hi, w in spans if lo <= a < hi), None)
                if hit is not None:
                    seen.add(hit)
                elif ex_pointer(a) is not None:
                    moved.add(ex_pointer(a))
                else:
                    changed.append(a)
        if changed:
            problems.append(f'{len(changed)} bytes changed outside the desert sites, first {changed[0]:#x}')
        if b_img[:1048576] == d_img[:1048576]:
            problems.append('nothing changed (not a desert build?)')
        rep[machine] = dict(sites_changed=len(seen), ex_pointers_moved=[f'{o:#x}' for o in sorted(moved)], problems=problems)
        ok &= not problems
    rep['passed'] = ok
    return rep

def cmd_static(a):
    rep = static(a.base.resolve(), a.build.resolve(), a.rom_dir.resolve())
    print(json.dumps(rep, indent=1))
    print('PASS' if rep['passed'] else 'FAIL')
    return 0 if rep['passed'] else 1

def cmd_identity(a):
    work = a.workdir.resolve()
    work.mkdir(parents=True, exist_ok=False)
    st = static(a.base.resolve(), a.build.resolve(), a.rom_dir.resolve())
    (work / 'static.json').write_text(json.dumps(st, indent=1) + '\n')
    if not st['passed']:
        print(json.dumps(st, indent=1))
        print('FAIL (static)')
        return 1
    binary = json.loads((a.runtime / 'runtime.json').read_text())['binary']
    sets = {tag: stage_sets(b.resolve(), a.set, a.hbmame, a.rom_dir.resolve(), work / f'sets_{tag}') for tag, b in (('base', a.base), ('desert', a.build))}
    jobs = []
    a.frames = a.frames or 5000
    shots = dict(SHOTS=f'400-{a.frames}@50', MOTION='1')
    for name, (env, frames) in cases(a.frames).items():
        jobs.append((f'{name}_base', 'base', dict(env, **shots), frames))
        jobs.append((f'{name}_desert', 'desert', dict(env, **shots), frames))
    with ThreadPoolExecutor(a.jobs) as ex:
        res = dict(zip([j[0] for j in jobs], ex.map(lambda j: run(binary, sets[j[1]], a.set, work / 'runs' / j[0], j[2], j[3]), jobs)))
    report, ok = (dict(set=a.set, cases={}), True)
    for name in cases(a.frames):
        base, desert = (res[f'{name}_base'], res[f'{name}_desert'])
        r = compare(base, desert, work / 'runs' / f'{name}_base', work / 'runs' / f'{name}_desert')
        if name == 'clear0':
            r['entered_stage5'] = any((row['stage'] == '5' for row in desert))
            r['base_entered_stage5'] = any((row['stage'] == '5' for row in base))
            good = r['first_divergence'] is not None and r['entered_stage5'] and (not r['base_entered_stage5'])
        else:
            good = r['first_divergence'] is None and r['n_shots_differ'] == 0
        r['margin'] = {tag: lag_margin(work / 'runs' / f'{name}_{tag}', res[f'{name}_{tag}']) for tag in ('base', 'desert')}
        r['passed'] = good
        ok &= good
        report['cases'][name] = r
        print(name, json.dumps(r), flush=True)
    report['passed'] = ok
    (work / 'report.json').write_text(json.dumps(report, indent=1) + '\n')
    print('PASS' if ok else 'FAIL')
    return 0 if ok else 1
CYCLES_FRAMES = 3300

def trace_interrupts(path):
    """[(interrupted pc, instructions since the interrupt before)] of a MAME debugger trace (lua TRACE). An EX"""
    out, n = ([], 0)
    with open(path, errors='replace') as f:
        for line in f:
            s = line.lstrip()
            if s.startswith('(interrupted at '):
                pc = int(s[16:].split(',')[0], 16)
                out.append(('EX' if pc >= 1048576 else f'{pc:06x}', n))
                n = 0
            elif len(s) > 7 and s[6] == ':':
                n += 1
    return out

def cmd_cycles(a):
    """cycles: the desert's routes through stock code cost a stock stage nothing, to the cycle (identity's"""
    work = a.workdir.resolve()
    work.mkdir(parents=True, exist_ok=False)
    binary = json.loads((a.runtime / 'runtime.json').read_text())['binary']
    sets = {tag: stage_sets(b.resolve(), a.set, a.hbmame, a.rom_dir.resolve(), work / f'sets_{tag}') for tag, b in (('base', a.base), ('desert', a.build))}
    frames = a.frames or CYCLES_FRAMES
    env = cases(frames)[a.case][0]
    (work / 'go.txt').write_text('go\n')
    extra = ('-debug', '-debugger', 'none', '-debugscript', str(work / 'go.txt'))

    def one(tag):
        out = work / 'runs' / tag
        trace = work / f'trace_{tag}.log'
        rows = run(binary, sets[tag], a.set, out, dict(env, TRACE=f'{trace}:1-{frames - 1}'), frames, extra)
        irqs = trace_interrupts(trace)
        trace.unlink()
        return (rows, irqs)
    with ThreadPoolExecutor(2) as ex:
        (rb, ib), (rd, idz) = ex.map(one, ('base', 'desert'))
    differ = next((k for k, (x, y) in enumerate(zip(ib, idz)) if x[0] != y[0]), None)
    counts = [[k, x[1], y[1]] for k, (x, y) in enumerate(zip(ib, idz)) if x[1] != y[1]]
    rec = next((int(x['frame']) for x, y in zip(rb, rd) if any((x[c] != y[c] for c in COLS))), None)
    rep = dict(case=a.case, set=a.set, frames=frames, board_wait=json.loads((a.runtime / 'runtime.json').read_text()).get('board_wait'), interrupts=[len(ib), len(idz)], first_interrupt_elsewhere=differ, intervals_with_other_counts=counts[:20], n_intervals_with_other_counts=len(counts), first_record_divergence=rec)
    rep['passed'] = bool(ib) and len(ib) == len(idz) and (differ is None) and (rec is None)
    (work / 'report.json').write_text(json.dumps(rep, indent=1) + '\n')
    print(json.dumps(rep, indent=1))
    print('PASS' if rep['passed'] else 'FAIL')
    return 0 if rep['passed'] else 1
LAG_RUN = 3
VBL_LINE, FRAME_LINES = (240, 262)

def lag_margin(out, rows):
    """For information (identity): the play frames (mode 4 on the frame and the one before) that end with the game"""
    mrows = {int(r['frame']): r for r in read_motion(out)}
    lagged, best = (0, None)
    for r0, r in zip(rows, rows[1:]):
        if r['mode'] != '4' or r0['mode'] != '4':
            continue
        if r['gtask'] == '8':
            lagged += 1
            continue
        m = mrows.get(int(r['frame']))
        if m is None or int(m['sleep']) < 0:
            continue
        room = (VBL_LINE - int(m['sleep'])) % FRAME_LINES
        if best is None or room < best[0]:
            best = (room, int(r['frame']))
    return dict(lag_frames=lagged, least_lines_to_vblank=best[0] if best else None, at_frame=best[1] if best else None)

def read_motion(out):
    lines = (out / 'motion.tsv').read_text().splitlines()
    head = lines[0].split('\t')
    return [dict(zip(head, line.split('\t'))) for line in lines[1:]]
SCENE_ACTIVE = 'c1e6'

def lag(rows, stage):
    """(play frames, lag frames, longest lag run) of a stage: frames in play (mode 4 on this"""
    n = lagged = run = worst = 0
    for r0, r in zip(rows, rows[1:]):
        if r.get('active') == SCENE_ACTIVE or r0.get('active') == SCENE_ACTIVE:
            run = 0
            continue
        if r['stage'] == stage and r['mode'] == '4' and (r0['mode'] == '4'):
            n += 1
            if r['gtask'] == '8':
                lagged += 1
                run += 1
                worst = max(worst, run)
            else:
                run = 0
        else:
            run = 0
    return (n, lagged, worst)

def cmd_timing(a):
    work = a.workdir.resolve()
    work.mkdir(parents=True, exist_ok=False)
    rt = json.loads((a.runtime / 'runtime.json').read_text())
    roms = stage_sets(a.build.resolve(), a.set, a.hbmame, a.rom_dir.resolve(), work / 'sets')
    jobs = {'desert': (debug_env(5, 0, DEBUG5), DEBUG5, '5'), 'desert_map': (debug_env(5, 2, 1500), 1500, '5'), 'desert_boss': (debug_env(5, 4, 3000), 3000, '5'), 'stpetersburg': (debug_env(0, 1, 5000), 5000, '0'), 'siberia': (debug_env(1, 1, 5000), 5000, '1')}
    with ThreadPoolExecutor(a.jobs) as ex:
        res = dict(zip(jobs, ex.map(lambda k: run(rt['binary'], roms, a.set, work / 'runs' / k, *jobs[k][:2]), jobs)))
    rep = dict(board_wait=rt.get('board_wait'), stages={})
    for k, (env, frames, st) in jobs.items():
        n, lagged, worst = lag(res[k], st)
        rep['stages'][k] = dict(play_frames=n, lag_frames=lagged, lag_share=round(lagged / n, 4) if n else None, longest_lag_run=worst)
    ds = [rep['stages'][k] for k in ('desert', 'desert_map', 'desert_boss')]
    stock = [rep['stages'][k] for k in ('stpetersburg', 'siberia')]
    rep['passed'] = bool(all((s['play_frames'] for s in ds + stock)) and all((d['lag_share'] <= max((s['lag_share'] for s in stock)) and d['longest_lag_run'] <= LAG_RUN for d in ds)))
    (work / 'report.json').write_text(json.dumps(rep, indent=1) + '\n')
    print(json.dumps(rep, indent=1))
    print('PASS' if rep['passed'] else 'FAIL')
    return 0 if rep['passed'] else 1
CENSUS_AREAS = (0, 2, 3, 4, 5, 6, 7, 8, 9)
CENSUS_FRAMES = 3000

def census_run(binary, roms, set_name, out, stage, area):
    out.mkdir(parents=True, exist_ok=False)
    env = debug_env(stage, area, CENSUS_FRAMES)
    e = dict(os.environ, SDL_VIDEODRIVER='dummy', SDL_AUDIODRIVER='dummy', OUT=str(out), STREX_PREFIX=str(out / 'dbg'), **env)
    cmd = [str(binary), set_name, '-rompath', str(roms), '-nothrottle', '-video', 'none', '-sound', 'none', '-seconds_to_run', str(CENSUS_FRAMES // 50 + 30), '-skip_gameinfo', '-noautosave', '-cfg_directory', str(out / 'cfg'), '-nvram_directory', str(out / 'nv'), '-snapshot_directory', str(out), '-autoboot_script', str(CODES_LUA)]
    p = subprocess.run(cmd, env=e, cwd=out, capture_output=True, text=True, timeout=1800)
    (out / 'mame.log').write_text(p.stdout + p.stderr)
    if p.returncode:
        raise SystemExit(f'{out}: HBMAME exit {p.returncode}')
    log = (out / 'dbg_log.tsv').read_text().splitlines()
    starts = [line.split('\t') for line in log[1:]]
    if not any((f[1] == 'stage_area' and f[2].startswith(f'{stage},') and (int(f[0]) > 1 or stage == 0) for f in starts)) or not any((f[1] == 'lives' and f[2] != '0' for f in starts)):
        raise SystemExit(f'{out}: the debug start did not start stage {stage} area {area}')
    rows = [line.split('\t') for line in (out / 'scroll3_codes.tsv').read_text().splitlines()[1:]]
    return {(int(r[0], 16), int(r[1])): r[3] for r in rows}

def cmd_census(a):
    import desert_ex as DX
    work = a.workdir.resolve()
    work.mkdir(parents=True, exist_ok=False)
    binary = a.mame
    machine = PARENT[a.set]
    jobs = [(st, ar) for st in range(5) for ar in CENSUS_AREAS]
    with ThreadPoolExecutor(a.jobs) as ex:
        res = list(ex.map(lambda j: census_run(binary, a.rom_dir.resolve(), machine, work / 'runs' / f's{j[0]}_a{j[1]}', *j), jobs))
    seen = {}
    for r in res:
        for k, pc in r.items():
            seen.setdefault(k, pc)
    page = DX.DZ_SLOT - 24
    in_slot = sorted((c for c, f in seen if f == DX.DZ_FLIPS and c >> 8 == page))
    stock = sorted((c for c, f in DX.stock_scroll3_codes(images(None, a.rom_dir.resolve(), PARENT[a.set])[0]) if f == DX.DZ_FLIPS and c >> 8 == page))
    rep = dict(runs=len(res), distinct_entries=len(seen), slot_codes_written=[f'{c:#x}' for c in in_slot], slot_codes_in_stock_records=[f'{c:#x}' for c in stock], flipped_writes=sum((1 for c, f in seen if f)), writers=sorted({pc for pc in seen.values()}))
    rep['passed'] = bool(in_slot) and set(in_slot) <= set(stock) and (set(stock) <= set(in_slot))
    (work / 'report.json').write_text(json.dumps(rep, indent=1) + '\n')
    print(json.dumps({k: v for k, v in rep.items() if k != 'writers'}, indent=1))
    print('PASS' if rep['passed'] else 'FAIL')
    return 0 if rep['passed'] else 1

def first(rows, pred, after=0):
    return next((int(r['frame']) for r in rows if int(r['frame']) > after and pred(r)), None)
TIMEOVER = 6600

def death_base(d):
    """A death in the desert: the watcher (asm/desert.s dz_watch) puts the stock SCROLL3 base back when"""
    play = first(d, lambda r: r['stage'] == '5' and r['mode'] == '4' and (r['s3base'] == '9180'))
    lives = [int(r['lives']) for r in d]
    death = next((int(r['frame']) for r0, r in zip(d, d[1:]) if int(r['lives']) < int(r0['lives']) and int(r0['lives']) > 0), None)
    dark = first(d, lambda r: r['layer'] == '0000', play or 0) if play else None
    back = first(d, lambda r: r['s3base'] == '9100', play or 0) if play else None
    replay = first(d, lambda r: r['stage'] == '5' and r['mode'] == '4' and (r['s3base'] == '9180'), death or 0) if death else None
    return dict(desert_play_at=play, blackout_at=dark, first_death_at=death, stock_base_at=back, respawn_play_at=replay, lives_min=min(lives) if lives else None, passed=all((v is not None for v in (play, dark, death, back, replay))) and dark <= back <= dark + 1 and (back < replay))
EXIT0_FRAMES = 4400

def exit0_env():
    """The slopes gate's walk of section 0 (desert_slopes.WALKS 's0'), for the flow gate's exit0 case."""
    import desert_slopes as DS
    name, area, frames, warp_at, _, _ = next((w for w in DS.WALKS if w[0] == 's0'))
    assert frames == EXIT0_FRAMES
    return DS.walk_env(area, frames, warp_at)

def cmd_flow(a):
    import desert_ex as DX
    work = a.workdir.resolve()
    work.mkdir(parents=True, exist_ok=False)
    binary = json.loads((a.runtime / 'runtime.json').read_text())['binary']
    roms = stage_sets(a.build.resolve(), a.set, a.hbmame, a.rom_dir.resolve(), work / 'sets')
    n = a.frames or 9000
    jobs = {'path': (dict(debug_env(0, 7, n), CLEAR_AT=f'1000,{a.desert_clear}', SHOTS=f'400-{n}@25'), n), 'debug5': (dict(debug_env(5, 0, DEBUG5, invincible=False), SHOTS=f'400-{DEBUG5}@25'), DEBUG5), 'timeover': (dict(debug_env(5, 1, TIMEOVER, inputs=False), SHOTS=f'400-{TIMEOVER}@25'), TIMEOVER), 'sections': (dict(debug_env(5, 4, 4500), SHOTS='400-4500@25', S4SKIP=f'{DX.S4_FIGHT_FROM}:{DX.S4_AFTER_TANK}'), 4500), 'mapswitch': (dict(debug_env(5, 2, 1500), SHOTS='400-1500@25', S1SKIP=f'{DX.S1_SKIP_FROM}:{DX.S1_AFTER_OFFICER}'), 1500), 'exit0': (exit0_env(), EXIT0_FRAMES)}
    with ThreadPoolExecutor(a.jobs) as ex:
        res = dict(zip(jobs, ex.map(lambda k: run(binary, roms, a.set, work / 'runs' / k, *jobs[k]), jobs)))
    rep = {}
    p = res['path']
    t5 = first(p, lambda r: r['stage'] == '5')
    play5 = first(p, lambda r: r['stage'] == '5' and r['mode'] == '4' and (r['s3base'] == '9180'), t5 or 0)
    t1 = first(p, lambda r: r['stage'] == '1', play5 or 0)
    play1 = first(p, lambda r: r['stage'] == '1' and r['mode'] == '4', t1 or 0)
    base1 = first(p, lambda r: r['s3base'] == '9100', t1 or 0)
    rep['path'] = dict(stage5_at=t5, desert_play_at=play5, stage1_at=t1, siberia_play_at=play1, stock_base_at=base1, passed=all((v is not None for v in (t5, play5, t1, play1, base1))) and base1 <= play1)
    for k in ('debug5', 'timeover'):
        rep[k] = death_base(res[k])
    rep['timeover']['passed'] &= bool(rep['timeover']['stock_base_at'] and rep['timeover']['first_death_at']) and rep['timeover']['stock_base_at'] < rep['timeover']['first_death_at']
    dz = {k: read_desert(work / 'runs' / k) for k in ('sections', 'mapswitch')}
    s = res['sections']
    sec4 = next((r['frame'] for r in dz['sections'] if r['sec'] == 4), None)
    clear = first(s, lambda r: r['stage'] == '1', sec4 or 0) if sec4 else None
    sib = first(s, lambda r: r['stage'] == '1' and r['mode'] == '4' and (r['s3base'] == '9100'), clear or 0) if clear else None
    rep['sections'] = dict(section4_at=sec4, stage1_at=clear, siberia_play_at=sib, passed=all((v is not None for v in (sec4, clear, sib))))
    sw = next((r for r in dz['mapswitch'] if r['sec'] == 2), None)
    rep['mapswitch'] = dict(section2_at=sw and sw['frame'], map_then=sw and sw['map'], still_in_play=all((r['mode'] == '4' and r['s3base'] == '9180' for r in res['mapswitch'] if sw and int(r['frame']) > sw['frame'])), passed=bool(sw) and sw['map'] == 1)
    rep['mapswitch']['passed'] &= rep['mapswitch']['still_in_play']
    ex0 = read_desert(work / 'runs' / 'exit0')
    sec1 = next((r['frame'] for r in ex0 if r['sec'] == 1), None)
    e = res['exit0']
    lives0 = int(e[499]['lives'])
    rep['exit0'] = dict(section1_at=sec1, lives=[lives0, int(e[-1]['lives'])], hiryu_x_at_end=int(e[-1]['plx']), passed=sec1 is not None and lives0 > 0 and (int(e[-1]['lives']) == lives0) and all((r['stage'] == '5' for r in e[450:])))
    ok = all((v['passed'] for v in rep.values()))
    rep['passed'] = ok
    (work / 'report.json').write_text(json.dumps(rep, indent=1) + '\n')
    print(json.dumps(rep, indent=1))
    print('PASS' if ok else 'FAIL')
    return 0 if ok else 1
PROG_PLAY = 300
PROG_SHOT = 50
GAME_ORDER = (0, 5, 1, 3, 2, 4)
ON = 'c1e5'

def played(rows, streams, lo=0, hi=None):
    """The cinematics shown in frames (lo, hi], in order, one entry per showing: runs of"""
    order = sorted(streams, key=lambda k: streams[k])

    def scene_of(ptr):
        return max((k for k in order if streams[k] <= ptr), key=lambda k: streams[k], default=None)
    out, cur, ptrs = ([], None, set())
    for r in rows:
        fr = int(r['frame'])
        if fr <= lo or (hi is not None and fr > hi):
            continue
        ptr = int(r['lz'], 16)
        k = scene_of(ptr) if r['active'] == ON else None
        if k == cur:
            ptrs.add(ptr)
            continue
        if cur is not None and len(ptrs) >= 10:
            out.append(cur)
        cur, ptrs = (k, {ptr})
    if cur is not None and len(ptrs) >= 10:
        out.append(cur)
    collapsed = []
    for k in out:
        if not collapsed or collapsed[-1] != k:
            collapsed.append(k)
    return collapsed

def chain(rows, streams, stages, want):
    """Each stage of `stages` in turn: when it was entered, its play, and what played between"""
    rep, ok, after = ([], True, 0)
    play_prev = first(rows, lambda r: r['mode'] == '4')
    for st in stages:
        t = first(rows, lambda r: r['stage'] == str(st), play_prev or 0)
        play = first(rows, lambda r: r['stage'] == str(st) and r['mode'] == '4', t or 0) if t else None
        nxt = first(rows, lambda r: r['stage'] != str(st), play or 0) if play else None
        before = played(rows, streams, play_prev or 0, play) if play else None
        during = played(rows, streams, play, nxt) if play else None
        good = play is not None and before == want[st] and (during == [])
        rep.append(dict(stage=st, entered_at=t, play_at=play, cinematics=before, in_play=during, want=want[st], passed=good))
        ok &= good
        play_prev = play
        if play is None:
            break
    return (rep, ok)
CINE = (ON, 'c1e6', 'c1e7', 'c1e8')

def unhooked(build, rom_dir, machine, out):
    """The build with the stage hook's jsr replaced by the stock instructions again (the control)."""
    import build_ex as BX
    import respawn_fix as RF
    stock = {q.name: q.read_bytes() for q in (rom_dir / machine).iterdir() if q.is_file()}
    mine = {q.name: q.read_bytes() for q in (build / machine).iterdir() if q.is_file()}
    layout = RF.SETS[machine]
    img = RF.compose({**stock, **mine}, layout)
    at = BX.STAGE_HOOKS[machine]
    if img[at:at + 2] != b'N\xb9':
        raise SystemExit(f'{machine}: no stage hook jsr at {at:#x}')
    img[at:at + 6] = BX.STAGE_HOOK_BYTES
    members = RF.decompose(img, layout, {n: len(stock[n]) for n, _, _ in layout})
    (out / machine).mkdir(parents=True)
    for name, data in mine.items():
        (out / machine / name).write_bytes(data)
    changed = [n for n, d in members.items() if d != {**stock, **mine}[n]]
    for n in changed:
        (out / machine / n).write_bytes(members[n])
    if not changed:
        raise SystemExit(f'{machine}: putting the stage hook back changed no member')
    return out

def play_seeds(rows, out, stages):
    """{stage: (frame counter 0xFF0C22, random byte 0xFF0CB3, the sprite lists' double-buffer flag 0xFF0C98 and"""
    lines = (out / 'intro.tsv').read_text().splitlines()
    head = lines[0].split('\t')
    it = {int(x[0]): dict(zip(head, x)) for x in (ln.split('\t') for ln in lines[1:])}
    out_, after = ({}, 0)
    for st in stages:
        play = first(rows, lambda r: r['stage'] == str(st) and r['mode'] == '4', after)
        if play is None:
            break
        r = it[play]
        out_[st] = (int(r['counter'], 16), int(r['random'], 16), int(r['objflag'], 16), int(r['objbase'], 16))
        after = play
    return out_

def seed_env(seed):
    return ';'.join((f'{st}:' + ','.join((f'{v:x}' for v in vals)) for st, vals in sorted(seed.items())))

def compare_play(rows_a, rows_b, dir_a, dir_b, stage, frames=PROG_PLAY, shot=PROG_SHOT):
    """A stage's play in run a against run b from its first frame (game mode 4): every frames.tsv column of"""
    pa = first(rows_a, lambda r: r['stage'] == str(stage) and r['mode'] == '4')
    pb = first(rows_b, lambda r: r['stage'] == str(stage) and r['mode'] == '4')
    if pa is None or pb is None:
        return dict(play=[pa, pb], passed=False)
    ia, ib = ({int(r['frame']): r for r in rows_a}, {int(r['frame']): r for r in rows_b})
    bad = []
    for k in range(1, frames - 1):
        cols = [c for c in COLS if ia[pa + k][c] != ib[pb + k][c]]
        if cols:
            bad.append([k, cols])
    cap_a, cap_b = (caption_frames(dir_a), caption_frames(dir_b))
    shots = [k for k in range(shot, frames + 1, shot) if (dir_b / f'p_{stage}_{k:05d}.png').exists()]
    captioned = [k for k in shots if pa + k - 1 in cap_a or pb + k - 1 in cap_b]
    shots = [k for k in shots if k not in captioned]
    differ = [k for k in shots if not (dir_a / f'p_{stage}_{k:05d}.png').exists() or (np.asarray(Image.open(dir_a / f'p_{stage}_{k:05d}.png').convert('RGB')) != np.asarray(Image.open(dir_b / f'p_{stage}_{k:05d}.png').convert('RGB'))).any()]
    return dict(play=[pa, pb], frames=frames - 2, frames_differ=len(bad), first=bad[:3], shots=len(shots), shots_with_caption=captioned, shots_differ=differ, passed=not bad and (not differ) and (len(shots) > 0))

def caption_frames(out):
    """The frames of a run with a location caption (a kind-2 system object; intro.tsv, lua INTRO), if logged."""
    p = out / 'intro.tsv'
    if not p.exists():
        return set()
    lines = p.read_text().splitlines()
    k = lines[0].split('\t').index('kind2')
    return {int(x[0]) for x in (ln.split('\t') for ln in lines[1:]) if x[k] != '0'}

def cmd_progression(a):
    import build_ex as BX
    work = a.workdir.resolve()
    work.mkdir(parents=True, exist_ok=False)
    binary = json.loads((a.runtime / 'runtime.json').read_text())['binary']
    streams = json.loads((a.build / 'build.json').read_text())['sets'][PARENT[a.set]]['streams']
    machine = PARENT[a.set]
    roms = stage_sets(a.build.resolve(), a.set, a.hbmame, a.rom_dir.resolve(), work / 'sets')
    ctl = stage_sets(unhooked(a.build.resolve(), a.rom_dir.resolve(), machine, work / 'control'), a.set, a.hbmame, a.rom_dir.resolve(), work / 'sets_control')
    want = {**BX.STAGE_SCENES, **BX.DESERT_SCENES}
    gs = dict(PSHOTS=str(PROG_SHOT), INTRO='1')
    chains = {'game': (dict(debug_env(0, 7, a.prog_frames, inputs=False), CLEAR_PLAY=f'{PROG_PLAY}*5', **gs), a.prog_frames)}
    jobs = [(k, roms, *v) for k, v in chains.items()] + [(k + '_control', ctl, *v) for k, v in chains.items()] + [('respawn', roms, debug_env(1, 0, 6000, invincible=False), 6000), ('attract', roms, dict(), 12000)]
    with ThreadPoolExecutor(a.jobs) as ex:
        res = dict(zip([j[0] for j in jobs], ex.map(lambda j: run(binary, j[1], a.set, work / 'runs' / j[0], *j[2:]), jobs)))
    for k, (env, n) in chains.items():
        seed = play_seeds(res[k], work / 'runs' / k, GAME_ORDER[1:])
        res[k + '_seeded'] = run(binary, ctl, a.set, work / 'runs' / f'{k}_seeded', dict(env, SEED=seed_env(seed)), n)
    rep = {}
    for k, stages in (('game', GAME_ORDER[1:]),):
        stages_rep, good = chain(res[k], streams, stages, want)
        c_rep, _ = chain(res[k + '_control'], streams, stages, want)
        c_none = len(c_rep) == len(stages) and all((x['cinematics'] == (want[5] if x['stage'] == 5 else []) for x in c_rep))
        d = {x: work / 'runs' / x for x in (k, k + '_control', k + '_seeded')}
        hand = {}
        for st in GAME_ORDER:
            seeded = compare_play(res[k], res[k + '_seeded'], d[k], d[k + '_seeded'], st)
            plain = compare_play(res[k], res[k + '_control'], d[k], d[k + '_control'], st)
            hand[str(st)] = dict(seeded, unseeded=dict(frames_differ=plain.get('frames_differ'), first=plain.get('first'), shots_differ=plain.get('shots_differ')))
        rep[k] = dict(stages=stages_rep, control_no_briefings=c_none, play=hand, passed=good and len(stages_rep) == len(stages) and c_none and all((v['passed'] for v in hand.values())))
    r = res['respawn']
    death = next((int(x['frame']) for x0, x in zip(r, r[1:]) if int(x['lives']) < int(x0['lives']) and int(x0['lives']) > 0), None)
    shown = played(r, streams)
    rep['respawn'] = dict(cinematics=shown, first_death_at=death, after_death=played(r, streams, death) if death else None, passed=shown == want[1] and death is not None and (played(r, streams, death) == []))
    t = res['attract']
    lit = [int(x['frame']) for x in t if x['active'] in CINE and int(x['frame']) > 100]
    rep['attract'] = dict(cinematic_frames=len(lit), first=lit[0] if lit else None, stages_seen=sorted({x['stage'] for x in t}), passed=not lit)
    ok = all((v['passed'] for v in rep.values()))
    rep['passed'] = ok
    (work / 'report.json').write_text(json.dumps(rep, indent=1) + '\n')
    print(json.dumps(rep, indent=1))
    print('PASS' if ok else 'FAIL')
    return 0 if ok else 1

def read_actors(out):
    """actors.tsv (lua/desert_gate.lua ACTORS): per-frame rows and the actor events. khurt and kcut"""
    rows, events = ([], [])
    lines = (out / 'actors.tsv').read_text().splitlines()
    head = lines[0].split('\t')
    for line in lines[1:]:
        f = line.split('\t')
        if f[0] == '#':
            if f[1] == 'cap':
                events.append(dict(what='cap', frame=int(f[2]), slot=int(f[3]), variant=int(f[4]), kind=int(f[5]), st=int(f[6]), sub=int(f[7]), x=int(f[8]), y=int(f[9]), carrier=int(f[10], 16)))
                continue
            if f[1] == 'capgone':
                events.append(dict(what='capgone', frame=int(f[2]), slot=int(f[3])))
                continue
            if f[1] == 'snd':
                events.append(dict(what='snd', frame=int(f[2]), value=int(f[3], 16)))
                continue
            kind, facing, oid = (int(v) for v in f[4].split(','))
            ev = dict(what=f[1], frame=int(f[2]), slot=int(f[3]), kind=kind, facing=facing, id=oid)
            if f[1] == 'new':
                ev.update(x=int(f[5]), y=int(f[6]))
            elif f[1] == 'dr':
                ev.update(st=int(f[5]), sub=int(f[6]), tick=int(f[7]), head=int(f[8]), spd=int(f[9]), t1=int(f[10]), x=int(f[11], 16), y=int(f[12], 16), cap=int(f[13], 16))
            elif f[1] == 'sw':
                ev.update(st=int(f[5]), sub=int(f[6]), t1=int(f[7]), t2=int(f[8]), swc=int(f[9]), hits=int(f[10]), kid=int(f[11], 16) & 16777215, par=int(f[12], 16) & 16777215)
            elif f[1] == 'a5':
                b = bytes.fromhex(f[14])
                ev.update(st=int(f[5]), sub=int(f[6]), t1=int(f[7]), t2=int(f[8]), x=int(f[9], 16), y=int(f[10], 16), hits=int(f[11]), col=int(f[12]), anim=int(f[13]), b42=b[0], b43=b[1], b44=b[2], b45=b[3], b46=b[4], b47=b[5], l48=int(f[15], 16) & 16777215, l4c=int(f[16], 16) & 16777215, px=int(f[17], 16), py=int(f[18], 16), spd=int(f[19]), rec=int(f[20], 16), flg=int(f[21], 16), l4c_raw=int(f[16], 16), l48_raw=int(f[15], 16), vxw=int(f[22]), vx=int(f[23], 16), vy=int(f[24], 16))
            events.append(ev)
            continue
        r = dict(zip(head, f))
        rows.append({k: int(v, 16) if k in ('score', 'pt_on', 'hx', 'hplat') else list(bytes.fromhex(v)) if k in ('khurt', 'kcut', 'bars', 'da6', 'da8', 'pals') else int(v) for k, v in r.items()})
    return (rows, events)

def bcd(v):
    return int(f'{v:08x}')

def control_build(build, rom_dir, machine, out):
    """The build with pool 5 type 3's dispatch long put back to the stock rts (no desert actors)."""
    import desert_actors_ex as DA
    import respawn_fix as RF
    stock = {q.name: q.read_bytes() for q in (rom_dir / machine).iterdir() if q.is_file()}
    mine = {q.name: q.read_bytes() for q in (build / machine).iterdir() if q.is_file()}
    layout = RF.SETS[machine]
    img = RF.compose({**stock, **mine}, layout)
    a = DA.locate(RF.compose(dict(stock), layout))
    at = a['site_pool5_type3']
    if int.from_bytes(img[at:at + 4], 'big') < 1048576:
        raise SystemExit(f'{machine}: pool 5 type 3 at {at:#x} is not repointed')
    img[at:at + 4] = a['DA_TYPE3_STOCK'].to_bytes(4, 'big')
    members = RF.decompose(img, layout, {n: len(stock[n]) for n, _, _ in layout})
    (out / machine).mkdir(parents=True)
    for name, data in mine.items():
        (out / machine / name).write_bytes(data)
    for n, d in members.items():
        if d != {**stock, **mine}[n]:
            (out / machine / n).write_bytes(d)
    return out

def map_list_model(camrows, records, first, keep=None):
    """The first spawn frame of each map-list actor by asm/desert_actors.s da_maplist's rule,"""
    keep = keep or {}
    out, scanned = ({}, False)
    for prev, r in zip(camrows, camrows[1:]):
        f = int(r['frame'])
        if f < first:
            continue
        cx, cy = (int(prev['camx']), int(prev['camy']))
        for kind, facing, oid, x, y in records:
            if oid in out:
                continue
            dx, dy = (x - cx, y - cy)
            if not (-480 <= dx < 864 and -175 <= dy <= 400):
                continue
            if scanned and -96 <= dx < 480 and (-79 <= dy <= 304):
                continue
            if kind in keep and (not keep[kind][0] <= dx < keep[kind][1]):
                continue
            out[oid] = f
        scanned = True
    return out

def onscreen_model(cam, x, y, eq):
    """The bazooka soldier's fire test (0x58E2 in arcade terms: desert_actors_ex.step2_equates)."""
    return eq['DA_SCR_X0'] <= x - cam[0] < eq['DA_SCR_X1'] and eq['DA_SCR_Y0'] <= y - cam[1] <= eq['DA_SCR_Y1']

def fire_model(frames, spawn, gone, x, y, eq):
    """The frames a bazooka soldier spawned (allocated) on frame `spawn` fires on, before `gone`:"""
    cam = {int(r['frame']): (int(r['camx']), int(r['camy'])) for r in frames}
    out, f = ([], spawn + 1 + 2 * eq['DA_BZ_AIM'])
    while f < gone:
        if f - 1 in cam and onscreen_model(cam[f - 1], x, y, eq):
            out.append(f)
            f += 2 * eq['DA_BZ_FIRE'] + 2 * eq['DA_BZ_AIM']
        else:
            f += 1
    return out

def wave_model(frames, rows, script, first, rank_frames, rank_mask, active):
    """The drones a wave manager whose first update is on frame `first` spawns: [(frame, X, Y, kind)], an"""
    pos = {int(r['frame']): (int(r['plx']), int(r['ply'])) for r in frames}
    cam = {int(r['frame']): (int(r['camx']), int(r['camy'])) for r in frames}
    rank = {r['frame']: r['rank_t'] for r in rows}
    pc, my, mx, set_y, set_x, wait, side, timer, out = (0, 0, 0, False, False, None, None, 0, [])
    for f in range(first, max(pos) + 1):
        if f not in pos or f - 1 not in cam or f not in active:
            continue
        (hx, hy), (cx, cy) = (pos[f], cam[f - 1])
        while True:
            if wait == 'y':
                if int(hy > my) == side:
                    break
                wait = None
            elif wait == 'x':
                if int(hx < mx) == side:
                    break
                wait = None
            elif wait == 't':
                if timer:
                    timer -= 1
                    break
                wait = None
            op = script[pc]
            pc += 1
            name = op['op']
            if name == 'end':
                return out
            if name == 'y':
                my, set_y = (2047 - op['value'], op['value'] != 0)
            elif name == 'x':
                mx, set_x = (op['value'] * 3 // 2, op['value'] != 0)
            elif name == 'wait':
                wait, timer = ('t', 2 * op['value'])
            elif name in ('wait_until_a', 'wait_until_b') and (set_y or set_x):
                wait = 'y' if name == 'wait_until_a' else 'x'
                side = int(hy > my) if wait == 'y' else int(hx < mx)
            elif name.startswith('spawn'):
                kind = op['kind']
                if rank.get(f - 1, 0) >= rank_frames:
                    kind &= rank_mask
                out.append((f, cx + (-48 if name == 'spawn_left' else 432), cy + 144, kind))
    return out

def drone_model(t, h, start, frames, until):
    """An independent model of the PC Engine's drone 0x0B (0x72:0x94D6) in arcade terms, run from its"""
    pos = {int(r['frame']): (int(r['plx']), int(r['ply'])) for r in frames}
    cam = {int(r['frame']): (int(r['camx']), int(r['camy'])) for r in frames}
    speeds = [h['dr_glide_speed'], h['dr_home_speed'], h['dr_entry_speed']]

    def vel(spd, head):
        row = t['velocity'][(speeds[spd] >> 4) - 1]

        def v(s):
            return -row[s & 7] if s & 8 else row[s & 7]
        s = head >> 4
        return (v(s) * 192, -v(s + 12 & 15) * 128)

    def word(v):
        v = v >> 16 & 65535
        return v - 65536 if v & 32768 else v

    def dir16(st, hx, hy):
        dx, dy = (hx - word(st['x']), word(st['y']) - hy)
        dx = abs(2 * dx) // 3 * (1 if dx >= 0 else -1)
        dx, dy = (max(-127, min(127, dx)), max(-127, min(127, dy)))
        while not (-4 <= dx <= 3 and -4 <= dy <= 3):
            dx, dy = (dx >> 1, dy >> 1)
        return t['atan'][(dx & 7) * 8 + (dy & 7)]
    st = dict(sub=0, head=0, spd=0, t1=0, x=(start[0] & 65535) << 16, y=(start[1] & 65535) << 16, vx=0, vy=0)
    kind = start[2]
    out = []
    for f, tick in until:
        hx, hy = pos[f]
        cx, cy = cam[f - 1]

        def glide():
            st.update(sub=6, spd=0, t1=h['dr_glide_timer'])
            glide_tick()

        def glide_tick():
            if st['t1']:
                st['t1'] -= 1
                return
            xr, yr = (word(st['x']) - cx, word(st['y']) - cy)
            if h['dr_box_left'] * 3 // 2 <= xr < h['dr_box_right'] * 3 // 2 and 240 - h['dr_box_bottom'] < yr <= 240 - h['dr_box_top']:
                home()
            else:
                entry()

        def entry():
            xr, yr = (word(st['x']) - cx, word(st['y']) - cy)
            b = (1 if yr > 240 - h['dr_band_top'] else 0) | (2 if yr <= 240 - h['dr_band_bottom'] else 0) | (4 if xr < h['dr_band_left'] * 3 // 2 else 0) | (8 if xr >= h['dr_band_right'] * 3 // 2 else 0)
            d = t['entry_dir'][b]
            if d & 128:
                return glide()
            st.update(sub=2, head=d << 4 & 255, spd=2)
            entry_tick()

        def entry_tick():
            if abs(hx - word(st['x'])) < h['dr_entry_exit_dx'] * 3 // 2:
                home()

        def home():
            st.update(sub=4, t1=h['dr_home_timer'])
            home_tick()

        def home_tick():
            if not st['t1']:
                return glide()
            st['t1'] -= 1
            if abs(hx - word(st['x'])) < h['dr_close_dx'] * 3 // 2 and abs(hy - word(st['y'])) < h['dr_close_dy']:
                target = 0
            else:
                d = dir16(st, hx, hy)
                target = st['head'] if d >= 16 else d << 4 & 255
            diff = (target - st['head'] + 128 & 255) - 128
            diff = min(diff, h['dr_turn_pos']) if diff >= 0 else max(diff, -h['dr_turn_pos'])
            st.update(head=st['head'] + diff & 255, spd=1)
        if tick:
            if st['sub'] == 0:
                st['head'] = dir16(st, hx, hy) << 4 & 255
                entry() if kind & h['dr_entry_bit'] else home()
            elif st['sub'] == 2:
                entry_tick()
            elif st['sub'] == 4:
                home_tick()
            else:
                glide_tick()
            st['vx'], st['vy'] = vel(st['spd'], st['head'])
        st['x'] = st['x'] + st['vx'] & 4294967295
        st['y'] = st['y'] + st['vy'] & 4294967295
        out.append((f, st['sub'], st['head'], st['spd'], st['t1'], st['x'], st['y']))
    return out
SFX = dict(built=False)

def drone_sounds(m, dec, h):
    """The wing sounds a drone queues [(frame, command)], from its model (drone_model: one row per update frame) and"""
    import desert_actors_ex as DA
    if not SFX['built']:
        return []
    cmds = DA.sfx_commands()
    anims = dec['actors'][11]['anims']
    by_sub = {2: h['dr_entry_anim'], 4: h['dr_home_anim'], 6: h['dr_glide_anim']}
    out, cur, start = ([], None, 0)
    for i, (f, sub, *_) in enumerate(m):
        a = by_sub.get(sub)
        if a is None:
            continue
        if a != cur:
            cur, start = (a, i)
            continue
        steps = anims[a]['steps']
        period = 2 * anims[a]['ticks'] * sum(('frame' in st for st in steps))
        if len(steps) > 1 and steps[-1].get('cmd') == 'loop' and (steps[-2].get('cmd') == 'psg_sfx') and ((i - start) % period == 0):
            out.append((f, cmds[steps[-2]['arg']]))
    return out

def queued(events, limit, cmds):
    """[(frame, command)] the sound queue took (lua: '#	snd') before `limit`, of the commands `cmds`."""
    return sorted(((e['frame'], e['value']) for e in events if e['what'] == 'snd' and e['frame'] < limit and (e['value'] in cmds)))

def sound_check(want, got):
    want = sorted(want)
    diff = sorted(set(want) ^ set(got))
    return dict(model=len(want), queued=len(got), first=got[:3], differ=diff[:6], ok=want == got)

def hiword(v):
    """The signed integer part of a logged 16.16 long."""
    v = v >> 16 & 65535
    return v - 65536 if v & 32768 else v

def capsule_points(events, until):
    """Points the stock capsules paid by frame `until`: a capsule collected (state 4) as kind 6 (400"""
    paid, life = (0, {})
    for e in sorted((e for e in events if e['what'] in ('cap', 'capgone')), key=lambda e: e['frame']):
        if e['what'] == 'capgone':
            life.pop(e['slot'], None)
            continue
        if e['st'] == 4 and e['kind'] in (6, 7) and (e['frame'] <= until) and (not life.get(e['slot'])):
            paid += 400 if e['kind'] == 6 else 200
            life[e['slot']] = True
        life.setdefault(e['slot'], False)
    return paid

def step3_checks(sec, sp, dec, rows, events, frames, limit):
    """Step 3 in one run of section `sec` (DESERT_ENEMIES.md), up to frame `limit` (a death starts a"""
    import desert_actors_ex as DA
    K, h, t = (DA.KIND, dec['handlers'], dec['step3'])
    eq3 = DA.step3_equates(h, t)
    out = {}
    active = {r['frame'] for p, r in zip(rows, rows[1:]) if r['rank_t'] != p['rank_t']}
    items = [r for r in sp['map_lists'][sec] if r[0] == K['item']]
    news = [e for e in events if e['what'] == 'new' and e['frame'] < limit]
    scan0 = min((e['frame'] for e in news if e['kind'] in (K['generator'], K['wave'])), default=None)
    caps = [e for e in events if e['what'] in ('cap', 'capgone') and e['frame'] < limit]
    first_cap, life = ([], {})
    for e in caps:
        if e['what'] == 'capgone':
            life.pop(e['slot'], None)
            continue
        if e['slot'] not in life:
            life[e['slot']] = [e]
            first_cap.append(life[e['slot']])
        else:
            life[e['slot']].append(e)
    model = map_list_model([r for r in frames if int(r['frame']) < limit], items, scan0) if scan0 and items else {}
    placed, bad = ({}, [])
    for oid, f in model.items():
        kd, kind, _, x, y = next((r for r in items if r[2] == oid))
        lv = next((L for L in first_cap if L[0]['frame'] == f and L[0]['variant'] == 0 and ((L[0]['x'], L[0]['y']) == (x, y)) and (not any((L is v for v in placed.values())))), None)
        if lv is None:
            bad.append((oid, f, 'not spawned', x, y))
            continue
        placed[oid] = lv
        shown = next((e for e in lv if e['st'] == 2), None)
        closed = [e for e in lv if e['st'] == 2 and e['sub'] == 0]
        if shown and shown['kind'] != kind or any(((e['x'], e['y']) != (x, y) for e in closed)):
            bad.append((oid, f, 'kind or place', [(e['frame'], e['kind'], e['st'], e['sub'], e['x'], e['y']) for e in lv[:4]]))
    out['capsules'] = dict(model=model, spawned={o: L[0]['frame'] for o, L in placed.items()}, shown={o: next((e['frame'] for e in L if e['st'] == 2), None) for o, L in placed.items()}, opened={o: next((e['frame'] for e in L if e['sub'] in (2, 4)), None) for o, L in placed.items()}, taken={o: next((e['frame'] for e in L if e['st'] == 4), None) for o, L in placed.items()}, counter=rows[-1]['caps'], bad=bad[:5], ok=not bad)
    wv = [e for e in news if e['kind'] == K['wave']]
    script = t['waves'][1 if sec == 2 else 0]
    want = wave_model(frames, rows, script, wv[0]['frame'] + 1, eq3['DA_RANK_FRAMES'], eq3['DA_RANK_MASK'], active) if wv else []
    want = [w for w in want if w[0] < limit]
    drones = sorted((e for e in news if e['kind'] == K['drone']), key=lambda e: (e['frame'], e['slot']))
    got = [(e['frame'], e['facing']) for e in drones]
    out['waves'] = dict(managers=len(wv), model=[(f, k) for f, _, _, k in want], got=got, spawned_counter=rows[-1]['wv_spawned'], ok=bool(wv) and got == [(f, k) for f, _, _, k in want])
    drl = {}
    for e in events:
        if e['what'] == 'dr' and e['frame'] < limit:
            drl.setdefault(e['slot'], []).append(e)
    per, mism, dsnd = ([], [], [])
    for d, w in zip(drones, want):
        lines = [e for e in drl.get(d['slot'], []) if e['frame'] >= d['frame']]
        upd = []
        for e in lines:
            if e['st'] == 0:
                continue
            if e['st'] != 2:
                break
            if e['frame'] in active:
                upd.append(e)
        if not upd:
            mism.append((d['frame'], 'never ran'))
            continue
        m = drone_model(t, h, (w[1], w[2], w[3]), frames, [(e['frame'], i % 2 == 0) for i, e in enumerate(upd)])
        bad_f = [(e['frame'], (e['sub'], e['head'], e['spd'], e['t1'], e['x'], e['y']), mm[1:]) for i, (e, mm) in enumerate(zip(upd, m)) if (e['sub'], e['head'], e['spd'], e['t1'], e['x'], e['y']) != mm[1:] or e['tick'] != (1 if i % 2 == 0 else 0)]
        if bad_f:
            mism.append((d['frame'], d['slot'], bad_f[:2]))
        dsnd += drone_sounds(m, dec, h)
        per.append(dict(spawn=d['frame'], slot=d['slot'], kind=d['facing'], frames=len(upd), subs=sorted({e['sub'] for e in upd}), ended=lines[len(upd)]['st'] if len(lines) > len(upd) else None))
    snd = sound_check(dsnd, queued(events, limit, {v for k, v in DA.sfx_commands().items() if k in (28, 29)}))
    out['drones'] = dict(n=len(drones), lives=per, mismatches=mism[:4], killed=rows[-1]['dr_killed'], started=rows[-1]['dr_spawned'], sounds=snd, ok=not mism and len(per) == len(drones) and snd['ok'])
    item_kind = DA.item_table()
    carried, cbad = ([], [])
    for d, w in zip(drones, want):
        it = item_kind[w[3] >> 4 & 15] if w[3] >> 4 else 255
        addr = 16720154 + 80 * d['slot']
        lv = next((L for L in first_cap if L[0]['carrier'] & 16777215 == addr and d['frame'] <= L[0]['frame'] <= d['frame'] + 2), None)
        if it == 255:
            if lv:
                cbad.append((d['frame'], 'a capsule without an item'))
            continue
        if lv is None or lv[0]['kind'] != it:
            cbad.append((d['frame'], 'no capsule', it))
            continue
        dl = {e['frame']: e for e in drl.get(d['slot'], [])}
        at = next((e for e in lv if e['sub'] == 6), None)
        src = dl.get(at['frame'] - 1) if at else None
        ok_at = bool(at and src and ((at['x'], at['y']) == (hiword(src['x']), hiword(src['y']) + eq3['DA_DR_ITEM_DY'])))
        fall = next((e for e in lv if e['sub'] == 8), None)
        death = next((e['frame'] for e in drl.get(d['slot'], []) if e['frame'] > d['frame'] and e['st'] == 4), None)
        opened = next((e for e in lv if e['sub'] in (2, 4) and (not fall)), None)
        dropped = bool(death and fall and (death <= fall['frame'] <= death + 2))
        land = next((e for e in lv if fall and e['frame'] > fall['frame'] and (e['st'] == 2) and (e['sub'] == 0)), None)
        carried.append(dict(drone=d['frame'], kind=it, at_ok=ok_at, drone_died=death, fell=fall and fall['frame'], landed=land and (land['frame'], land['x'], land['y']), opened=opened and opened['frame']))
        if not ok_at or (death and (not (dropped or opened))):
            cbad.append(carried[-1])
    out['carried'] = dict(capsules=carried, bad=cbad[:4], ok=not cbad)
    return out

def sp4_arches(sp, K):
    """The arches worm 11 (the second map-list sandworm) may make (its record's bits 1-6)."""
    return next((f >> 1 & 63 for kd, f, i, x, y in sp['map_lists'][0] if kd == K['worm'] and i == 11))

def worm_checks(sp, dec, rows, events, frames, limit):
    """Step 4 in a section 0 run, up to frame `limit`: the sandworms (DESERT_ENEMIES.md) against an"""
    import desert_actors_ex as DA
    K, h = (DA.KIND, dec['handlers'])
    e2, e4 = (DA.step2_equates(h), DA.step4_equates(h))
    active = sorted((r['frame'] for p, r in zip(rows, rows[1:]) if r['rank_t'] != p['rank_t'] and r['frame'] < limit))
    aset = set(active)
    cam = {int(r['frame']): (int(r['camx']), int(r['camy'])) for r in frames}

    def window(f, x, y):
        cx, cy = cam[f - 1]
        return e2['DA_SCR_X0'] <= x - cx < e2['DA_SCR_X1'] and e2['DA_SCR_Y0'] <= y - cy <= e2['DA_SCR_Y1']
    heads = {i: (f, x, y) for kd, f, i, x, y in sp['map_lists'][0] if kd == K['worm']}
    news = sorted((e for e in events if e['what'] == 'new' and e['kind'] == K['worm'] and (e['frame'] < limit)), key=lambda e: (e['frame'], e['slot']))
    lines = {}
    for e in events:
        if e['what'] == 'sw' and e['frame'] < limit:
            lines.setdefault(e['slot'], []).append(e)
    gone = [e for e in events if e['what'] == 'gone' and e['kind'] == K['worm'] and (e['frame'] < limit)]
    lives, bad = ([], [])
    for n in news:
        end = min((g['frame'] for g in gone if g['slot'] == n['slot'] and g['frame'] > n['frame']), default=limit)
        ls = [e for e in lines.get(n['slot'], []) if n['frame'] <= e['frame'] < end]
        surf = next((e['frame'] for e in ls if e['st'] == 2 and e['sub'] == 2), None)
        died = next((e['frame'] for e in ls if e['st'] == 4), None)
        lives.append(dict(frame=n['frame'], slot=n['slot'], face=n['facing'], id=n['id'], x=n['x'], y=n['y'], addr=16720154 + 80 * n['slot'], surf=surf, died=died, gone=end if end < limit else None, lines=ls))
    for L in lives:
        first = next((e['frame'] for e in L['lines'] if e['st'] != 0), None)
        if L['face'] & 128:
            want = first
        else:
            if L['id'] not in heads or (L['x'], L['y']) != heads[L['id']][1:]:
                bad.append((L['frame'], 'head not on the map list'))
                continue
            want = next((f for f in active if first is not None and f >= first and window(f, L['x'], L['y'])), None)
        if L['surf'] != want:
            bad.append((L['frame'], 'surfaced', L['surf'], want))
    for L in lives:
        if L['surf'] is None:
            continue
        run = [f for f in active if f >= L['surf'] and (L['died'] is None or f < L['died'])]
        nxt = run[24] if len(run) > 24 else None
        kid = None
        if nxt is not None:
            left, fwd = (L['face'] >> 1 & 63, -1 if L['face'] & 1 else 1)
            cx = cam[nxt - 1][0]
            dx = (L['x'] - cx - e4['DA_SW_CX']) * fwd
            if left > 1 and (window(nxt, L['x'], L['y']) or dx < e4['DA_SW_STOP']):
                kid = (nxt, L['x'] + fwd * e4['DA_SW_DX'], L['y'], 128 | left - 1 << 1 | L['face'] & 1)
        got = next(((k['frame'], k['x'], k['y'], k['face']) for k in lives if k['face'] & 128 and L['surf'] <= k['frame'] < (L['died'] or L['gone'] or limit) and any((e['par'] == L['addr'] for e in k['lines'][:1]))), None)
        if got != kid:
            bad.append((L['frame'], 'next arch', got, kid))
        L['kid'] = got
        if L['died'] is None:
            want_gone = run[66] if len(run) > 66 else None
            if L['gone'] != want_gone:
                bad.append((L['frame'], 'gone', L['gone'], want_gone))
    by_addr = {}
    for L in lives:
        by_addr.setdefault(L['addr'], []).append(L)
    for L in lives:
        if L['died'] is None or not L['face'] & 128:
            continue
        par = next((P for P in lives if P.get('kid') and P['kid'][0] == L['frame'] and (P['kid'][1:3] == (L['x'], L['y']))), None)
        alive = par and (par['gone'] is None or par['gone'] > L['died']) and (par['died'] is None or par['died'] >= L['died'])
        if alive and (not (par['died'] is not None and L['died'] <= par['died'] <= L['died'] + 1)):
            bad.append((L['frame'], 'the arch that made it', par['frame'], par['died'], L['died']))
    last = rows[-1] if rows[-1]['frame'] < limit else next((r for r in reversed(rows) if r['frame'] < limit))
    cnt = dict(surfaced=last['sw_up'], made=last['sw_arch'], killed=last['sw_kill'], stopped=last['sw_stop'], floor_ends=last['sw_end'])
    ok_cnt = cnt['surfaced'] == sum((1 for L in lives if L['surf'] is not None)) and cnt['made'] == sum((1 for L in lives if L['face'] & 128)) and (cnt['killed'] == sum((1 for L in lives if L['died'] is not None)))
    worms = {}
    for L in lives:
        if not L['face'] & 128:
            chain, cur = ([L], L)
            while cur.get('kid'):
                cur = next((k for k in lives if k['frame'] == cur['kid'][0] and (k['x'], k['y']) == cur['kid'][1:3]), None)
                if cur is None:
                    break
                chain.append(cur)
            worms[L['id']] = [(c['x'], c['surf'], c['died'] or c['gone']) for c in chain]
    return dict(worms=dict(arches=worms, counters=cnt, bad=bad[:6], ok=not bad and ok_cnt))

def robot_model(col, h, t5, eq, start, ups, frames, hits):
    """An independent model of the PC Engine's pipe walker robot 0x19 (0x72:0x99B2) in arcade terms, from its spawn"""
    import desert_actors_ex as DA
    sfx = DA.sfx_equates(h)
    pos = {int(r['frame']): (int(r['plx']), int(r['ply'])) for r in frames}
    cam = {int(r['frame']): (int(r['camx']), int(r['camy'])) for r in frames}
    row = t5['rb_vel'][1]
    legs = sorted(set(t5['lg_a']) | set(t5['lg_b']))
    domes = sorted(set(t5['rb_frames']))

    def v(i):
        return -row[i & 7] if i & 8 else row[i & 7]

    def word(v16):
        v16 = v16 >> 16 & 65535
        return v16 - 65536 if v16 & 32768 else v16
    st = dict(st=2, sub=0, t1=0, ph=0, ct=0, spin=0, walk=0, dir=0, spd=0, px=start[0] * 2 // 3 << 8, py=2047 - start[1] << 8, x=(start[0] & 65535) << 16, y=(start[1] & 65535) << 16, vx=0, vy=0, lph=[0, 0], lanim=[None, None], anim=None, stc=0)
    out, fires, sounds = ([], [], [])
    for i, f in enumerate(ups):
        hx, hy = pos[f]
        cx, cy = cam[f - 1]
        if st['st'] == 2 and hits.get(f - 1, 0) >= h['rb_hits']:
            st.update(st=4, t1=2 * h['rb_knock'], vy=0, vx=294912 if word(st['x']) >= hx else -294912)
        if st['st'] == 4:
            if not st['t1']:
                out.append((f, 'gone'))
                break
            st['t1'] -= 1
            st['x'] = st['x'] + st['vx'] & 4294967295
            st['y'] = st['y'] + st['vy'] & 4294967295
            out.append((f, dict(st)))
            continue
        if i % 2 == 0:
            x, y = (word(st['x']), word(st['y']))
            onscr = eq['DA_SCR_X0'] <= x - cx < eq['DA_SCR_X1'] and eq['DA_SCR_Y0'] <= y - cy <= eq['DA_SCR_Y1']
            level = onscr and abs(hy - y) < h['rb_fire_dy']

            def aim():
                st.update(dir=int(hx < x), sub=3, walk=0)
                st['spin'] = st['dir'] + 2
            if st['sub'] == 0:
                st.update(sub=1, t1=h['rb_wait0'], spin=1, walk=0)
            elif st['sub'] == 1:
                if st['t1']:
                    st['t1'] -= 1
                elif level:
                    aim()
                else:
                    st.update(dir=int(hx < x), sub=2, spin=1, walk=1, t1=h['rb_walk'])
            elif st['sub'] == 2:
                if not st['t1']:
                    st['spd'] = 0
                    if level:
                        aim()
                    else:
                        st.update(t1=h['rb_wait1'], spin=1, walk=0, sub=1)
                else:
                    st['t1'] -= 1
                    px, py = (st['px'] >> 8, st['py'] >> 8)
                    if st['dir'] == 0:
                        turn = col.wall_right(px, py, 128)[0] < 4 or col.floor(px + 1, py + 22, 192)[0] >= 16
                    else:
                        turn = col.wall_left(px, py, 128)[0] < 4 or col.floor(px - 2, py + 22, 192)[0] >= 16
                    st['dir'] ^= int(turn)
                    st['spd'] = -16 if st['dir'] else 16
            elif st['sub'] == 3:
                if not st['spin']:
                    st.update(t1=h['rb_hold'], walk=0, sub=4)
                    fires.append((f, x + (-24 if st['dir'] else 24), y + 16, st['dir']))
                    if abs(hx - x) < sfx['DA_NEAR_X'] and abs(hy - y) < sfx['DA_NEAR_Y']:
                        sounds.append((f, sfx['DA_SND_RB_FIRE']))
            elif st['t1']:
                st['t1'] -= 1
            else:
                st.update(t1=h['rb_rest'], spin=1, walk=0, sub=0)
            if st['sub'] == h['rb_step_gate']:
                if st['stc']:
                    st['stc'] -= 1
                else:
                    st['stc'] = h['rb_step_period']
                    if abs(hx - x) < sfx['DA_NEAR_X'] and abs(hy - y) < sfx['DA_NEAR_Y']:
                        sounds.append((f, sfx['DA_SND_RB_WALK']))
            st['anim'] = domes.index(t5['rb_frames'][st['ph']])
            if st['ct']:
                st['ct'] -= 1
            else:
                st['ct'] = h['rb_spin_period']
                if st['spin']:
                    st['ph'] = st['ph'] + 1 & 7
                    if st['spin'] == 2 and st['ph'] == h['rb_aim_right'] or (st['spin'] == 3 and st['ph'] == h['rb_aim_left']):
                        st['spin'] = 0
            px, py = (st['px'] >> 8, st['py'] >> 8)
            d = col.floor(px, py + 24, 192)[1] & 7
            vx, vy = (v(d), v(d + 4)) if st['spd'] else (0, 0)
            if st['spd'] < 0:
                vx, vy = (-vx, -vy)
            st['px'] += vx
            st['py'] += vy
            dist = col.floor(st['px'] >> 8, (st['py'] >> 8) + 24, 192)[0]
            s = max(-4, min(4, dist - 4))
            st['py'] += s << 8
            st['vx'], st['vy'] = (vx * 192, -(vy + 256 * s) * 128)
            px, py = (st['px'] >> 8, st['py'] >> 8)
            for k, (dx, table, half) in enumerate(((3, t5['lg_a'], 0), (-3, t5['lg_b'], 4))):
                lx, ly = (px + dx, py + 12)
                dist, fl = col.floor(lx, ly - 8, 192)
                if dist >= 16:
                    dist, fl = col.floor(lx, ly + 8, 192)
                p = st['lph'][k] & 3 if st['lph'][k] & 4 == half else 0
                st['lanim'][k] = legs.index(table[(fl & 7) * 4 + p])
                if st['walk'] or st['lph'][k]:
                    st['lph'][k] = st['lph'][k] + 1 & 7
        st['x'] = st['x'] + st['vx'] & 4294967295
        st['y'] = st['y'] + st['vy'] & 4294967295
        out.append((f, dict(st, lph=list(st['lph']), lanim=list(st['lanim']))))
    return (out, fires, sounds)

def step5_checks(sec, sp, dec, col, rows, events, frames, limit):
    """Step 5 in a section 2 run, up to frame `limit` (DESERT_ENEMIES.md): the map list's robots and flames on the"""
    import desert_actors_ex as DA
    K, h, t5 = (DA.KIND, dec['handlers'], dec['step5'])
    eq = DA.step2_equates(h)
    out = {}
    active = sorted((r['frame'] for p, r in zip(rows, rows[1:]) if r['rank_t'] != p['rank_t'] and r['frame'] < limit))
    aset = set(active)
    cam = {int(r['frame']): (int(r['camx']), int(r['camy'])) for r in frames}
    news = [e for e in events if e['what'] == 'new' and e['frame'] < limit]
    gones = [e for e in events if e['what'] == 'gone' and e['frame'] < limit]
    lines = {}
    for e in events:
        if e['what'] == 'a5' and e['frame'] < limit:
            lines.setdefault(e['slot'], []).append(e)

    def life(n):
        end = min((g['frame'] for g in gones if g['slot'] == n['slot'] and g['frame'] > n['frame']), default=limit)
        return ([e for e in lines.get(n['slot'], []) if n['frame'] <= e['frame'] < end], end if end < limit else None)
    recs = [r for r in sp['map_lists'][sec] if r[0] in (K['robot'], K['flame'])]
    scan0 = min((e['frame'] for e in news if e['kind'] == K['wave']), default=None)
    model = map_list_model([r for r in frames if int(r['frame']) < limit], recs, scan0) if scan0 and recs else {}
    firsts, bad_sp = ({}, [])
    for e in news:
        r = next((r for r in recs if r[2] == e['id'] and r[0] == e['kind']), None)
        if r is None:
            continue
        firsts.setdefault(e['id'], e['frame'])
        if (e['x'], e['y'], e['facing']) != (r[3], r[4], r[1]):
            bad_sp.append(e)
    out['spawns5'] = dict(model=model, first=firsts, wrong_place=bad_sp[:4], ok=bool(recs) and firsts == model and (not bad_sp))
    hits = {r['frame']: 0 for r in rows}
    robots, mism, fires, kills, rsnd = ([], [], [], [], [])
    for n in sorted((e for e in news if e['kind'] == K['robot']), key=lambda e: e['frame']):
        ls, end = life(n)
        for e in ls:
            hits[e['frame']] = e['hits']
        hs = {e['frame']: e['hits'] for e in ls}
        first = next((e['frame'] for e in ls if e['st'] != 0), None)
        if first is None:
            mism.append((n['frame'], 'never ran'))
            continue
        ups = [f for f in active if f >= first and (end is None or f <= end)]
        m, fi, snds = robot_model(col, h, t5, eq, (n['x'], n['y']), ups, frames, hs)
        rsnd += snds
        byf = {e['frame']: e for e in ls}
        addr = {16720154 + 80 * g['slot']: g for g in news if g['kind'] == K['leg'] and g['frame'] == first}
        r0 = byf[first]
        legs = [addr[a] for a in (r0['l48'], r0['l4c']) if a in addr]
        legl = {g['slot']: {e['frame']: e for e in life(g)[0]} for g in legs}
        bad = []
        for f, s in m:
            e = byf.get(f)
            if s == 'gone':
                if end != f:
                    bad.append((f, 'gone', end))
                continue
            if e is None:
                bad.append((f, 'no line'))
                break
            got = (e['st'], e['sub'], e['t1'], e['b42'], e['b43'], e['b44'], e['b45'], e['b46'], e['px'], e['py'], e['spd'], e['x'], e['y'])
            want = (s['st'], 2 * s['sub'], s['t1'], s['ph'], s['ct'], s['spin'], s['walk'], s['dir'], s['px'] & 4294967295, s['py'] & 4294967295, s['spd'], s['x'], s['y'])
            if s['st'] == 4:
                got, want = ((e['st'], e['t1'], e['x'], e['y']), (s['st'], s['t1'], s['x'], s['y']))
            if got != want:
                bad.append((f, got, want))
            for k, (slot, dx) in enumerate(zip([g['slot'] for g in legs], (4, -5))):
                le = legl[slot].get(f)
                lw = (s['x'] + (dx << 16) & 4294967295, s['y'] - (12 << 16) & 4294967295)
                if le is None or (le['x'], le['y']) != lw or (s['st'] == 2 and le['anim'] != 2 * s['lanim'][k]):
                    bad.append((f, 'leg', k, le and (le['x'], le['y'], le['anim']), lw, s['lanim'][k]))
        if len(legs) != 2 or any((life(g)[1] != end for g in legs)):
            bad.append((n['frame'], 'legs', [(g['frame'], life(g)[1]) for g in legs], end))
        died = next((f for f, s in m if s != 'gone' and s['st'] == 4), None)
        if died:
            kills.append(dict(id=n['id'], died=died, gone=end, hits=hs.get(died - 1)))
        fires += [(f2, x, y, d, n['id']) for f2, x, y, d in fi]
        if bad:
            mism.append((n['id'], n['frame'], bad[:3]))
        robots.append(dict(id=n['id'], spawn=n['frame'], first=first, frames=len(m), subs=sorted({s['sub'] for _, s in m if s != 'gone'}), fired=len(fi), died=died, gone=end, x_end=m[-1][1]['px'] >> 8 if m and m[-1][1] != 'gone' else None))
    last = rows[-1] if rows[-1]['frame'] < limit else next((r for r in reversed(rows) if r['frame'] < limit))
    robo_hits = increments([r for r in rows if r['frame'] < limit], 'khurt', K['robot'])
    sfx = DA.sfx_equates(h)
    rsnd = rsnd if SFX['built'] else []
    snd = sound_check(rsnd, queued(events, limit, {sfx['DA_SND_RB_WALK'], sfx['DA_SND_RB_FIRE']}))
    snd.update(walks=sum((c == sfx['DA_SND_RB_WALK'] for _, c in rsnd)), fires=sum((c == sfx['DA_SND_RB_FIRE'] for _, c in rsnd)))
    out['robots'] = dict(lives=robots, kills=kills, mismatches=mism[:4], started=last['rb_spawned'], killed=last['rb_killed'], legs=last['lg_made'], contacts=len(robo_hits), cuts=last['kcut'][K['robot']], sounds=snd, ok=not mism and snd['ok'] and (last['rb_spawned'] == len(robots)) and (last['rb_killed'] == len(kills)) and (last['lg_made'] == 2 * len(robots)) and all((k['hits'] is not None and k['hits'] >= h['rb_hits'] for k in kills)))
    beams, bbad = ([], [])
    heads = sorted((e for e in news if e['kind'] == K['beam']), key=lambda e: e['frame'])
    if [(e['frame'], e['facing']) for e in heads] != [(f2, d) for f2, x, y, d, i in sorted(fires)]:
        bbad.append(('fired', [(e['frame'], e['facing']) for e in heads], [(f2, d) for f2, x, y, d, i in sorted(fires)]))
    for n, (f0, x0, y0, d0, rid) in zip(heads, sorted(fires)):
        ls, end = life(n)
        first = next((e['frame'] for e in ls if e['st'] != 0), None)
        segs = [g for g in news if g['kind'] == K['segment'] and n['frame'] <= g['frame'] < (end or limit) and any((e['l4c'] == 16720154 + 80 * n['slot'] for e in life(g)[0][:1]))]
        sl = {e['frame']: e for e in life(segs[0])[0]} if segs else {}
        byf = {e['frame']: e for e in ls}
        hx, hy, sub, t1, t2, bn, seg, want_end, bad = (x0 << 16, y0 << 16, 0, 0, 0, 0, None, None, [])
        ups = [f for f in active if first is not None and f >= first]
        for i, f in enumerate(ups):
            if i % 2 == 0:
                if sub == 4:
                    want_end = f
                    break
                if sub == 0:
                    sub, t1 = (2, h['bm_life'])
                elif t1:
                    t1 -= 1
                else:
                    cx, cy = cam[f - 1]
                    w = lambda v: (v >> 16 & 65535) - (65536 if v & 2147483648 else 0)
                    if not (eq['DA_SCR_X0'] <= w(hx) - cx < eq['DA_SCR_X1'] and eq['DA_SCR_Y0'] <= w(hy) - cy <= eq['DA_SCR_Y1']):
                        sub = 4
                if t2:
                    t2 -= 1
                else:
                    t2 = h['bm_period']
                    if bn == 0:
                        bn = 1
                    elif bn < h['rb_beam_parts']:
                        bn += 1
                        seg = (f, hx, hy)
                    if seg:
                        seg = (seg[0], hx, hy)
                    hx = hx + (-24 << 16 if d0 else 24 << 16) & 4294967295
            e = byf.get(f)
            if e is None or (e['x'], e['y'], e['sub'], e['t1']) != (hx, hy, sub, t1):
                bad.append((f, e and (e['x'], e['y'], e['sub'], e['t1']), (hx, hy, sub, t1)))
            if seg:
                se = sl.get(f)
                if se is None or (se['x'], se['y'], se['col']) != (seg[1], seg[2], 1):
                    bad.append((f, 'segment', se and (se['x'], se['y'], se['col']), seg))
        if end != want_end or (segs and life(segs[0])[1] != end):
            bad.append(('end', end, want_end, segs and life(segs[0])[1]))
        if bad:
            bbad.append((n['frame'], bad[:3]))
        beams.append(dict(robot=rid, fired=f0, first=first, segment=segs[0]['frame'] if segs else None, gone=end))
    out['beams'] = dict(lives=beams, bad=bbad[:4], fired=last['bm_fired'], segments=last['bm_seg'], contacts=len(increments([r for r in rows if r['frame'] < limit], 'khurt', K['segment'])), ok=not bbad and last['bm_fired'] == len(heads) and (last['bm_seg'] == len([b for b in beams if b['segment']])) and (last['kcut'][K['beam']] == 0) and (last['kcut'][K['segment']] == 0) and (last['khurt'][K['beam']] == 0))
    flames, fbad, hot = ([], [], set())
    recs_seen = {}
    for n in sorted((e for e in news if e['kind'] == K['flame']), key=lambda e: e['frame']):
        ls, end = life(n)
        byf = {e['frame']: e for e in ls}
        first = next((e['frame'] for e in ls if e['st'] != 0), None)
        ups = [f for f in active if first is not None and f >= first and (end is None or f < end)]
        bad = []
        for c, f in enumerate(ups):
            e = byf.get(f)
            k = c % 128
            step = k // 2 if k < 62 else 31 if k < 66 else 'out'
            col1 = 1 if 52 <= k < 56 else 0
            if col1:
                hot.add(f)
            if e is None or e['col'] != col1:
                bad.append((f, c, e and e['col'], col1))
                continue
            recs_seen.setdefault(step, set()).add(e['rec'])
        bursts = (len(ups) + 127) // 128
        flames.append(dict(id=n['id'], spawn=n['frame'], first=first, frames=len(ups), bursts=bursts, gone=end))
        if bad:
            fbad.append((n['id'], bad[:3]))
    steps = [recs_seen.get(s) for s in range(32)]
    order = all((v and len(v) == 1 for v in steps)) and all((min(steps[i]) < min(steps[i + 1]) for i in range(31))) and (len(recs_seen.get('out', ())) == 1) and (min(recs_seen['out']) not in set().union(*steps))
    contacts = increments([r for r in rows if r['frame'] < limit], 'khurt', K['flame'])
    out['flames'] = dict(lives=flames, bad=fbad[:4], records_in_order=order, contacts=contacts[:8], contacts_outside=[f for f in contacts if f not in hot][:5], started=last['fl_spawned'], bursts=last['fl_burst'], cuts=last['kcut'][K['flame']], ok=bool(flames) and (not fbad) and order and all((f in hot for f in contacts)) and (last['fl_spawned'] == len(flames)) and (last['fl_burst'] == sum((x['bursts'] for x in flames))) and (last['kcut'][K['flame']] == 0))
    return out

def jeep_model(col, dec, eq, start, ups, frames, hits, secs, resumed=frozenset()):
    """An independent model of the PC Engine's camouflaged jeep 0x48 (0x74:0x8A05) and its gunner 0x49 (0x74:0x8F7F)"""
    import pce_desert_actors as PA
    h, t6 = (dec['handlers'], dec['step6'])
    pos = {int(r['frame']): (int(r['plx']), int(r['ply'])) for r in frames}
    cam = {int(r['frame']): (int(r['camx']), int(r['camy'])) for r in frames}
    anims = [PA.sequence(a) + (a['ticks'],) for a in dec['actors'][72]['anims']]
    t3 = dec['step3']

    def word(v16):
        v16 = v16 >> 16 & 65535
        return v16 - 65536 if v16 & 32768 else v16

    def s16(v):
        v &= 65535
        return v - 65536 if v & 32768 else v
    j = dict(st=2, sub=0, t1=0, px=start[0] * 2 // 3 << 8, py=2047 - start[1] << 8, v=0, face=start[2] & 1, home=0, jan=0, jcur=-1, jstep=0, jct=0, jfr=0, jfl=0, jbc=0, x=(start[0] & 65535) << 16, y=(start[1] & 65535) << 16, vx=0, vy=0)
    g = dict(st=2, t1=0, gst=0, gpa=0, gsh=0, gfi=0, gfr=0, gfl=0, x=0, y=2047 << 16, face=start[2] & 1)
    out, bullets, booms, ev = ([], [], [], dict(killed=None, end=None, wreck=None, gunner_gone=None, gone=None))
    for i, f in enumerate(ups):
        hx_a, hy_a = pos[f]
        cx, cy = cam[f - 1]
        hx, hy = (int(2 * hx_a / 3), 2047 - hy_a - DA_HIRYU_DY)

        def xp():
            return j['px'] >> 8

        def wall():
            w = h['jp_wall_r'] if s16(j['v']) >= 0 else h['jp_wall_l']
            test = col.wall_right if s16(j['v']) >= 0 else col.wall_left
            return test(xp() + w['dx'], (j['py'] >> 8) + w['dy'], w['mask'])[0] < w['want']

        def ahead(c):
            if j['face'] == 0:
                return s16(hx - (xp() + h['jp_ahead_r'] + c)) < 0
            return s16(hx - (xp() + h['jp_ahead_l'] + c)) >= 0

        def away():
            return j['face'] == 1 if s16(hx - xp()) >= 0 else j['face'] == 0

        def wait_in():
            j.update(sub=1, t1=h['jp_wait'], jan=h['jp_wait_anim'], jcur=-1, v=0)
            wait()

        def wait():
            if j['t1']:
                j['t1'] -= 1
                return
            if min(abs(hy - (j['py'] >> 8)), 255) >= h['jp_dy']:
                return
            if ahead(0):
                j.update(sub=4, t1=h['jp_reverse_t'])
                rev()
            else:
                j.update(sub=2, t1=h['jp_charge_t'])
                charge()

        def bounce_in():
            j.update(sub=6, t1=h['jp_bounce_t'], jan=h['jp_bounce_anim'], jbc=0, v=0)
            ev['bounces'] = ev.get('bounces', 0) + 1
            bounce()

        def bounce():
            if j['t1']:
                j['t1'] -= 1
                if j['jbc'] < h['jp_bounce_n']:
                    j['py'] += t6['jp_bounce_dy'][j['jbc']] << 8
                    j['jbc'] += 1
                return
            j['py'] = j['home'] << 8
            wait_in()

        def turn_in():
            j.update(sub=7, t1=h['jp_turn_t'], jan=h['jp_turn_anim'], face=j['face'] ^ 1)
            ev['turns'] = ev.get('turns', 0) + 1
            turn()

        def turn():
            if j['t1']:
                j['t1'] -= 1
            else:
                wait_in()

        def charge():
            if wall():
                return bounce_in()
            if j['face'] == 0:
                v = j['v'] + h['jp_charge_acc_r']
                c = int(v >= h['jp_charge_max_r'])
                v = min(v, h['jp_charge_max_r'])
            else:
                v = j['v'] + h['jp_charge_acc_l']
                c = int(v >= h['jp_charge_max_l'])
                v = max(v, h['jp_charge_max_l'])
            j['v'] = v
            if j['t1']:
                j['t1'] -= 1
                return
            if ahead(c):
                j.update(sub=3, t1=h['jp_brake_t'])
                brake()

        def brake():
            if wall():
                return bounce_in()
            v = j['v'] - (h['jp_brake_r'] if j['face'] == 0 else h['jp_brake_l'])
            if v < 0 if j['face'] == 0 else v >= 0:
                return wait_in()
            j['v'] = v
            if j['t1']:
                j['t1'] -= 1
                return
            if away():
                turn_in()

        def rev():
            if wall():
                return bounce_in()
            if j['face'] == 1:
                j['v'] = min(j['v'] + h['jp_rev_acc_l'], h['jp_rev_max_l'])
            else:
                j['v'] = max(j['v'] + h['jp_rev_acc_r'], h['jp_rev_max_r'])
            if j['t1']:
                j['t1'] -= 1
                return
            if away():
                turn_in()
            else:
                wait_in()

        def boom(k):
            dx = t6['jp_debris_dx'][k] * 3 // 2
            booms.append((f, word(j['x']) + (-dx if j['face'] else dx), word(j['y']) - t6['jp_debris_dy'][k], 'small' if k < 16 else 'end'))
        tick = i % 2 == 0
        if j['st'] == 4 and j['sub'] == 4 and (secs.get(f - 1, 3) != 3) and (f not in resumed) and (not (-160 <= word(j['x']) - cx < 544 and -320 <= word(j['y']) - cy <= 560)):
            ev['gone'] = f
            out.append((f, 'gone', None))
            break
        if tick:
            px0, py0 = (j['px'], j['py'])
            if j['st'] == 2 and hits.get(f - 1, 0) >= h['jp_hits']:
                v = h['jp_death_v_r'] if j['face'] == 0 else h['jp_death_v_l']
                j.update(st=4, sub=0, jan=h['jp_death_anim'], t1=h['jp_death_t'], v=v)
                ev['killed'] = f
            if j['st'] == 2:
                [lambda: (j.__setitem__('home', j['py'] >> 8), wait_in()), wait, charge, brake, rev, wait, bounce, turn][j['sub']]()
                j['px'] += j['v']
            elif j['sub'] == 0:
                end = not j['t1']
                if not end:
                    j['t1'] -= 1
                    end = wall()
                if end:
                    boom(h['jp_final'][0])
                    boom(h['jp_final'][1])
                    ev['end'] = f
                    j['sub'] = 2
                else:
                    if not j['jbc'] & 7:
                        boom(j['jbc'] >> 1 & 15)
                    j['jbc'] = j['jbc'] + 1 & 255
                    j['px'] += j['v']
            elif j['sub'] == 2:
                j.update(jan=h['jp_wreck_anim'], sub=4)
                ev['wreck'] = f
            if j['jan'] != j['jcur']:
                j.update(jcur=j['jan'], jstep=0, jct=0)
            if j['jct']:
                j['jct'] -= 1
            else:
                seq, again, ticks = anims[j['jcur']]
                if j['jstep'] >= len(seq):
                    j['jstep'] = again
                fr, fl = seq[j['jstep']]
                j.update(jstep=j['jstep'] + 1, jct=ticks - 1, jfr=fr, jfl=(fl ^ j['face']) & 1)
            if g['st'] == 4 and ev['gunner_gone'] is None:
                dx = t6['gn_debris_dx'][2] * 3 // 2
                booms.append((f, word(g['x']) + (-dx if g['face'] else dx), word(g['y']) - t6['gn_debris_dy'][2], 'gunner'))
                ev['gunner_gone'] = f
            elif g['st'] == 2 and j['st'] == 4 and (j['sub'] >= 2):
                g['st'] = 4
            elif g['st'] == 2:
                gx, gy = (word(g['x']), word(g['y']))
                if j['jfr'] == h['gn_turn_frame']:
                    g.update(gfr=h['gn_turn_set'], t1=0)
                elif g['t1']:
                    g['t1'] -= 1
                else:
                    g['t1'] = h['gn_aim_period']
                    g.update(gfr=0, gfi=0)
                    if eq['DA_SCR_X0'] <= gx - cx < eq['DA_SCR_X1'] and eq['DA_SCR_Y0'] <= gy - cy <= eq['DA_SCR_Y1']:
                        dx, dy = (hx_a - gx, gy - hy_a - DA_HIRYU_DY)
                        dx = abs(2 * dx) // 3 * (1 if dx >= 0 else -1)
                        dx, dy = (max(-127, min(127, dx)), max(-127, min(127, dy)))
                        while not (-4 <= dx <= 3 and -4 <= dy <= 3):
                            dx, dy = (dx >> 1, dy >> 1)
                        d = t3['atan'][(dx & 7) * 8 + (dy & 7)]
                        if d < 16:
                            if not g['gfl']:
                                d = 16 - d & 15
                            g.update(gfr=t6['gn_aim'][d] & 127, gfi=t6['gn_aim'][d] & 128)
                if g['gfr'] == h['gn_no_fire_frame']:
                    g['gst'] = 0
                elif g['gst']:
                    g['gst'] -= 1
                else:
                    g['gst'] = h['gn_shot_gap']
                    if g['gpa']:
                        g['gpa'] -= 1
                    elif not g['gfi']:
                        g['gsh'] = 0
                    elif g['gsh'] >= h['gn_burst']:
                        g.update(gsh=0, gpa=h['gn_pause'])
                    else:
                        g['gsh'] += 1
                        k, sgn = (g['gfr'], 1 if g['gfl'] else -1)
                        bullets.append((f, gx + sgn * -(t6['gn_shot_dx'][k] * 3 // 2), gy - t6['gn_shot_dy'][k], sgn * t6['gn_shot_vx'][k] * 192, -t6['gn_shot_vy'][k] * 128))
                g['gfl'] = j['jfl']
            j['vx'], j['vy'] = ((j['px'] - px0) * 192, -(j['py'] - py0) * 128)
        j['x'] = j['x'] + j['vx'] & 4294967295
        j['y'] = j['y'] + j['vy'] & 4294967295
        if g['st'] == 2:
            g['x'] = j['x']
            g['y'] = j['y'] - (t6['gn_dy'][j['jfr']] << 16) & 4294967295
        out.append((f, dict(j), dict(g) if ev['gunner_gone'] is None else None))
    return (out, bullets, booms, ev)
DA_HIRYU_DY = 0

def jeep_checks(sec, sp, dec, col, rows, events, frames, limit, dz):
    """Step 6 in a section 3 run, up to frame `limit` (DESERT_ENEMIES.md): the jeep (spawn list 2, at its converted"""
    import desert_actors_ex as DA
    K, h = (DA.KIND, dec['handlers'])
    if DA.HIRYU_DY != DA_HIRYU_DY:
        raise SystemExit('desert_gate: HIRYU_DY changed')
    eq = DA.step2_equates(h)
    active = sorted((r['frame'] for p, r in zip(rows, rows[1:]) if r['rank_t'] != p['rank_t'] and r['frame'] < limit))
    act = set(active)
    resumed = {f for f in active if f - 1 not in act}
    news = [e for e in events if e['what'] == 'new' and e['frame'] < limit]
    gones = [e for e in events if e['what'] == 'gone' and e['frame'] < limit]
    lines = {}
    for e in events:
        if e['what'] == 'a5' and e['frame'] < limit:
            lines.setdefault(e['slot'], []).append(e)

    def life(n):
        end = min((g['frame'] for g in gones if g['slot'] == n['slot'] and g['frame'] > n['frame']), default=limit)
        return ([e for e in lines.get(n['slot'], []) if n['frame'] <= e['frame'] < end], end if end < limit else None)
    secs, cur = ({}, None)
    by = {r['frame']: r for r in dz}
    for r in frames:
        f = int(r['frame'])
        if f in by:
            cur = by[f]['sec']
        secs[f] = cur
    want = sp['spawn_lists'][2]
    jeeps = sorted((e for e in news if e['kind'] == K['jeep']), key=lambda e: e['frame'])
    out, bad, lives = ({}, [], [])
    all_bullets, all_booms = ([], [])
    for n in jeeps:
        if (n['x'], n['y'], n['facing'], n['id']) != tuple(want[0][3:5]) + (want[0][1], want[0][2]):
            bad.append((n['frame'], 'spawn', (n['x'], n['y'], n['facing'], n['id']), want[0]))
        ls, end = life(n)
        byf = {e['frame']: e for e in ls}
        first = next((e['frame'] for e in ls if e['st'] != 0), None)
        if first is None:
            bad.append((n['frame'], 'never ran'))
            continue
        ups = [f for f in active if f >= first and (end is None or f <= end)]
        hs = {e['frame']: e['hits'] for e in ls}
        m, bl, bm, ev = jeep_model(col, dec, eq, (n['x'], n['y'], n['facing']), ups, frames, hs, secs, resumed)
        gun = next((g for g in news if g['kind'] == K['gunner'] and g['frame'] == first and (16720154 + 80 * g['slot'] == byf[first]['l48'])), None)
        gl = {e['frame']: e for e in life(gun)[0]} if gun else {}
        gend = life(gun)[1] if gun else None
        jb = []
        for f, s, gs in m:
            e = byf.get(f)
            if s == 'gone':
                if end != f:
                    jb.append((f, 'gone', end))
                continue
            if e is None:
                jb.append((f, 'no line'))
                break
            sub = 2 * s['sub'] if s['st'] == 2 else s['sub']
            got = (e['st'], e['sub'], e['t1'], e['px'], e['py'], e['vxw'], e['x'], e['y'], e['facing'] & 1, e['b46'], e['l4c_raw'] >> 16 & 255, e['l4c_raw'] >> 24, e['anim'], e['col'])
            wnt = (s['st'], sub, s['t1'], s['px'] & 4294967295, s['py'] & 4294967295, s['v'], s['x'], s['y'], s['face'], s['jfr'], s['jfl'], s['jbc'], 2 * s['jfr'] + s['jfl'], 7 if s['st'] == 2 else 0)
            if got != wnt:
                jb.append((f, got, wnt))
            if gs is not None and gun:
                ge = gl.get(f)
                gg = ge and (ge['st'], ge['t1'], ge['b42'], ge['b43'], ge['b44'], ge['b45'], ge['b46'], ge['b47'], ge['x'], ge['y'])
                gw = (gs['st'], gs['t1'], gs['gst'], gs['gpa'], gs['gsh'], gs['gfi'], gs['gfr'], gs['gfl'], gs['x'], gs['y'])
                if gg != gw:
                    jb.append((f, 'gunner', gg, gw))
        if gun is None or gend != ev['gunner_gone']:
            jb.append(('gunner end', gun and gun['frame'], gend, ev['gunner_gone']))
        if bad or jb:
            bad.append((n['frame'], jb[:3]))
        all_bullets += bl
        all_booms += bm
        lives.append(dict(spawn=n['frame'], first=first, frames=len(m), killed=ev['killed'], end=ev['end'], wreck=ev['wreck'], gone=end, gunner_gone=ev['gunner_gone'], bullets=len(bl), bounces=ev.get('bounces', 0), turns=ev.get('turns', 0), subs=sorted({s['sub'] for _, s, _ in m if s != 'gone' and s['st'] == 2}), x_range=[min((s['px'] >> 8 for _, s, _ in m if s != 'gone')), max((s['px'] >> 8 for _, s, _ in m if s != 'gone'))] if m else None, hits=hs.get(ev['killed'] - 1) if ev['killed'] else max(hs.values(), default=0)))
    bnew = sorted((e for e in news if e['kind'] == K['bullet']), key=lambda e: (e['frame'], e['slot']))
    got_b, bbad = ([], [])
    for e in bnew:
        ls, _ = life(e)
        v = (ls[0]['vx'], ls[0]['vy']) if ls else None
        got_b.append((e['frame'], e['x'], e['y'], v))
    for f, x, y, vx, vy in sorted(all_bullets):
        m2 = next((b for b in got_b if b[0] == f and b[3] == (vx & 4294967295, vy & 4294967295) and ((b[1], b[2]) in ((x, y), (hiword((x << 16) + vx), hiword((y << 16) + vy))))), None)
        if m2 is None:
            bbad.append((f, x, y, vx, vy))
        else:
            got_b.remove(m2)
    last = rows[-1] if rows[-1]['frame'] < limit else next((r for r in reversed(rows) if r['frame'] < limit))
    rl = [r for r in rows if r['frame'] < limit]
    delta = {r['frame']: r['jp_boom'] - p['jp_boom'] for p, r in zip(rl, rl[1:]) if r['jp_boom'] != p['jp_boom']}
    must = {}
    for b in all_booms:
        if b[3] != 'small':
            must[b[0]] = must.get(b[0], 0) + 1
    small = {b[0] for b in all_booms if b[3] == 'small'}
    out['jeeps'] = dict(lives=lives, bad=bad[:4], started=last['jp_spawned'], killed=last['jp_killed'], ended=last['jp_end'], bounces=last['jp_bounce'], turns=last['jp_turn'], gunners=last['gn_made'], contacts=len(increments([r for r in rows if r['frame'] < limit], 'khurt', K['jeep'])), cuts=last['kcut'][K['jeep']], ok=bool(jeeps) and (not bad) and (last['jp_spawned'] == len(jeeps) == last['gn_made']) and (last['jp_killed'] == sum((1 for x in lives if x['killed']))) and (last['jp_end'] == sum((1 for x in lives if x['end']))) and (last['jp_bounce'] == sum((x['bounces'] for x in lives))) and (last['jp_turn'] == sum((x['turns'] for x in lives))) and all((x['hits'] >= h['jp_hits'] for x in lives if x['killed'])) and (last['kcut'][K['gunner']] == 0) and (last['khurt'][K['gunner']] == 0))
    out['gunner_bullets'] = dict(model=len(all_bullets), fired=last['gn_shot'], unmatched=bbad[:4], ok=not bbad and last['gn_shot'] == len(all_bullets))
    bbad2 = [(f, d, must.get(f, 0)) for f, d in sorted(delta.items()) if not 0 <= d - must.get(f, 0) <= int(f in small)]
    bbad2 += [(f, 'missing', n2) for f, n2 in must.items() if delta.get(f, 0) < n2]
    out['explosions'] = dict(small=len(small), small_made=sum((1 for f in small if delta.get(f, 0) > must.get(f, 0))), end_and_gunner=sorted(must.items()), bad=bbad2[:6], ok=not bbad2 and last['jp_boom'] == sum(delta.values()))
    wait_at = next((i for i, s in enumerate(sp['flow'][3]) if s[0] == 'wait')) if sp.get('flow') else None
    s3 = [r for r in dz if r['sec'] == 3 and r['frame'] < limit]
    reached = next((r['frame'] for r in s3 if r['step'] == wait_at), None)
    passed = next((r['frame'] for r in s3 if wait_at is not None and r['step'] > wait_at), None)
    ends = [x['end'] for x in lives if x['end']]
    ok_wait = reached is not None and (passed is None if not ends else ends[0] <= passed <= ends[0] + 1)
    out['section_wait'] = dict(step=wait_at, reached=reached, passed=passed, drive_ended=ends, limits_after=[r['limits'] for r in s3 if passed and r['frame'] >= passed][:2], ok=ok_wait)
    return out
PT_MAGIC = 40570
PT_TAILN = 2

def pce_rank(t3, rank_t):
    """The PC Engine's rank ($2D0D) at a frame whose DA_RANKT (frames since the setup) was rank_t: its timer"""
    r, d = (t3['rank'], t3['difficulty'])
    t = rank_t // 2
    if t <= r['first'][d]:
        return r['start'][d]
    return min(15, r['start'][d] + 1 + (t - r['first'][d] - 1) // r['period'][d])

class PceAnim:
    """The PC Engine's animation interpreter (0x68:0x53B4) on a type's census scripts: request, current, step, count;"""

    def __init__(self, anims, face=0):
        import pce_desert_actors as PA
        self.scripts = [PA.sequence(a) + (a['ticks'],) for a in anims]
        self.jan, self.jcur, self.jstep, self.jct, self.jfr, self.face = (0, 255, 0, 0, 0, face)

    def tick(self):
        if self.jan != self.jcur:
            self.jcur, self.jstep, self.jct = (self.jan, 0, 0)
        if self.jct:
            self.jct -= 1
            return None
        seq, again, ticks = self.scripts[self.jcur]
        if self.jstep >= len(seq):
            if isinstance(again, tuple):
                self.jan, self.jstep, self.jct = (again[1], 0, 0)
                return None
            self.jstep = again
        fr, fl = seq[self.jstep]
        self.jstep += 1
        self.jct = ticks - 1
        self.jfr = fr
        return (fr, fl & 1 ^ self.face & 1 | fl & 2)

    def state(self):
        return (self.jan, self.jcur, self.jstep, self.jct, self.jfr)

def officer_model(dec, start, ups, go, hits, rank_t):
    """An independent model of the PC Engine's officer 0x45 (0x74:0x8071) in arcade terms (DESERT_ENEMIES.md step 7),"""
    h, t7, t3 = (dec['handlers'], dec['step7'], dec['step3'])
    an = PceAnim(dec['actors'][69]['anims'])
    o = dict(st=2, sub=0, t1=0, t2=0, py=2047 - start[1] << 8, vy=0, col=0, phits=0, pat=0, rank=0, act=0, flash=False, cam=False, pal='own', blink=0)
    px = start[0] * 2 // 3 << 8
    y16, vy16 = ((start[1] & 65535) << 16, 0)
    ev = dict(rounds=[], balls=[], arms=[], cam=[], death=None, debris=[], end=None, flashes=[], go_seen=None)
    pats, rank_pat = (t7['of_patterns'], t7['of_rank_pat'])
    out = []
    for i, f in enumerate(ups):
        if i % 2 == 0:
            py0 = o['py']

            def pye():
                return o['py'] >> 8

            def cam():
                o['cam'] = True

            def floor():
                o['py'] = o['py'] & 255 | h['of_floor'] << 8
                o['vy'] = 0

            def idle_in():
                o.update(sub=5, t1=h['of_idle_t'])
                an.jan = h['of_idle_anim']
                s5()

            def s5():
                if o['t1']:
                    o['t1'] -= 1
                    return
                while True:
                    p = pats[rank_pat[o['rank']]]
                    a = p[o['pat']] if o['pat'] < len(p) else h['of_pat_end']
                    if a != h['of_pat_end']:
                        break
                    o.update(rank=pce_rank(t3, rank_t[f - 1]), pat=0)
                o.update(act=a, pat=o['pat'] + 1)
                [idle_in, clack_in, leap_in, burst_in, ball_in][a]()

            def clack_in():
                o.update(sub=6, t1=h['of_clack_t'])
                an.jan = h['of_clack_anim']
                s6()

            def s6():
                if o['t1']:
                    o['t1'] -= 1
                else:
                    idle_in()

            def leap_in():
                o.update(sub=7, vy=h['of_leap_v'], col=3)
                an.jan = h['of_leap_anim']
                s7()

            def s7():
                o['vy'] += h['of_leap_g']
                if o['vy'] >= 0 and pye() >= h['of_floor']:
                    floor()
                    o['col'] = 1
                    idle_in()

            def burst_in():
                o.update(sub=8, t2=h['of_burst_n'])
                rnd()

            def rnd():
                an.jan = h['of_burst_anim']
                o['t1'] = h['of_burst_t']
                ev['rounds'].append((f, [(k, (px >> 8) + t7['gr_dx'][k], pye() + t7['gr_dy'][k]) for k in range(8)]))
                ev['arms'].append(f)
                s8()

            def s8():
                if o['t1']:
                    o['t1'] -= 1
                elif o['t2']:
                    o['t2'] -= 1
                    rnd()
                else:
                    idle_in()

            def ball_in():
                o.update(sub=9, t1=h['of_ball_t'])
                an.jan = h['of_ball_anim']
                ev['balls'].append((f, px >> 8, pye() + h['of_ball_dy']))
                s9()

            def s9():
                if o['t1']:
                    o['t1'] -= 1
                else:
                    idle_in()

            def s0():
                if f > go:
                    ev['go_seen'] = f
                    o.update(sub=1, t1=h['of_wait_t'])
                    an.jan = h['of_wait_anim']
                    s1()

            def s1():
                if o['t1']:
                    o['t1'] -= 1
                else:
                    o.update(sub=2, t1=h['of_point_t'])
                    an.jan = h['of_point_anim']
                    s2()

            def s2():
                if o['t1']:
                    o['t1'] -= 1
                    cam()
                else:
                    o.update(sub=3, t1=h['of_ring_t'])
                    an.jan = h['of_ring_anim']
                    s3()

            def s3():
                if o['vy']:
                    if pye() >= h['of_floor']:
                        floor()
                        o.update(sub=4, t1=h['of_morph_t'])
                        an.jan = h['of_morph_anim']
                        s4()
                    else:
                        cam()
                elif o['t1']:
                    o['t1'] -= 1
                    cam()
                else:
                    o['vy'] = h['of_sink_v']
                    cam()

            def s4():
                if o['t1']:
                    o['t1'] -= 1
                    cam()
                else:
                    o.update(col=1, rank=pce_rank(t3, rank_t[f - 1]), pat=0)
                    idle_in()
            if o['st'] == 2:
                o['cam'] = False
                [s0, s1, s2, s3, s4, s5, s6, s7, s8, s9][o['sub']]()
                o['py'] += o['vy']
                shown = an.tick()
                if hits.get(f - 1, 0):
                    o['phits'] += 1
                    o['flash'] = True
                    ev['flashes'].append(f)
                    if o['phits'] >= h['of_hits']:
                        o.update(st=4, sub=0)
                        ev['death'] = f
                else:
                    o['flash'] = False
                if o['cam']:
                    ev['cam'].append(f)
                o['pal'] = 'white' if o['flash'] else 'own'
            elif o['st'] == 4:
                o['cam'] = False
                if o['sub'] == 0:
                    o.update(sub=2, col=0, t1=0, t2=0, vy=h['of_die_v'], blink=0)
                o['pal'] = 'black' if o['blink'] % 2 == 0 else 'own'
                o['blink'] += 1
                ents, end = ([], False)
                while True:
                    if o['t1']:
                        o['t1'] -= 1
                        break
                    if o['t2'] >= len(t7['dbr_script']):
                        end = True
                        break
                    wait, e = t7['dbr_script'][o['t2']]
                    o['t1'] = wait
                    o['t2'] += 1
                    ents.append(e)
                if ents:
                    ev['debris'].append((f, ents))
                if end:
                    ev['end'] = f
                    out.append((f, 'gone', None))
                    break
                o['py'] += o['vy']
            vy16 = -(o['py'] - py0) * 128
        y16 = y16 + vy16 & 4294967295
        out.append((f, dict(o, an=an.state(), y=y16, px=px), None))
    return (out, ev)

def projectile_model(dec, kind, start, heading, ups, alive):
    """An independent model of one of the officer's projectiles 0x47 (0x74:0x869F; kind 'grain', 'ball' or 'needle')"""
    h, t7 = (dec['handlers'], dec['step7'])
    an = PceAnim(dec['actors'][71]['anims'])
    p = dict(sub=0, t1=0, px=start[0] << 8, py=start[1] << 8, vx=0, vy=0, gone=False, col=0 if kind == 'grain' else 1, face=0)
    x16, y16 = ((start[0] * 3 // 2 & 65535) << 16, (2047 - start[1] & 65535) << 16)
    vx16 = vy16 = 0
    out, needles = ([], [])
    for i, f in enumerate(ups):
        if i % 2 == 0:
            if p['gone']:
                out.append((f, None))
                break
            px0, py0 = (p['px'], p['py'])
            if not alive(f):
                p.update(gone=True, col=0)
            else:
                if kind == 'grain':
                    if p['sub'] == 0:
                        p.update(sub=1, t1=h['gr_life'], face=t7['gr_face'][heading], vy=t7['gr_vy'][heading], vx=t7['gr_vx'][heading])
                        an.jan = h['gr_anim']
                    p['vy'] += h['gr_g']
                    if p['t1']:
                        p['t1'] -= 1
                    else:
                        p['gone'] = True
                elif kind == 'needle':
                    if p['sub'] == 0:
                        p.update(sub=1, t1=h['nd_life'], face=t7['nd_face'][heading], vy=t7['nd_vy'][heading], vx=t7['nd_vx'][heading])
                        an.jan = t7['nd_anim'][heading]
                    p['vy'] += h['nd_g']
                    if p['t1']:
                        p['t1'] -= 1
                    else:
                        p['gone'] = True
                else:
                    if p['sub'] == 0:
                        p.update(sub=1, vy=h['bl_v'])
                        an.jan = h['bl_anim']
                    if p['sub'] == 1:
                        p['vy'] += h['bl_g']
                        if p['vy'] >= 0:
                            p.update(vy=0, sub=2, t1=h['bl_ring_t'])
                            an.jan = h['bl_ring_anim']
                    if p['sub'] == 2 and p['vy'] == 0:
                        if p['t1']:
                            p['t1'] -= 1
                        else:
                            needles += [(f, p['px'] >> 8, p['py'] >> 8, k) for k in range(len(t7['nd_head']))]
                            p['gone'] = True
                p['px'] += p['vx']
                p['py'] += p['vy']
            an.face = p['face']
            an.tick()
            vx16, vy16 = ((p['px'] - px0) * 192, -(p['py'] - py0) * 128)
        x16 = x16 + vx16 & 4294967295
        y16 = y16 + vy16 & 4294967295
        out.append((f, dict(p, an=an.state(), x=x16, y=y16)))
    return (out, needles)

def world_cells(world, owner):
    """{(world column, row from the top): (display entry, collision entry)} of one desert world (desert_ex.prepare)."""
    out = {}
    for key, secs in (('disp_grid', 'disp_secs'), ('coll_grid', 'coll_secs')):
        g, s = (world[key], b''.join(owner[secs]))
        for gy in range(8):
            for gx in range(32):
                body = s[g[gy * 32 + gx] * 384:][:384]
                for sr in range(8):
                    for sc in range(12):
                        c = (gx * 12 + sc, 63 - (gy * 8 + sr))
                        out[c] = out.get(c, ()) + (body[(sr * 12 + sc) * 4:][:4].hex(),)
    return out

def pit_samples(prep):
    """The pit's sample cells for lua PIT: each variant's first, middle and last changed cell (desert_ex.pit_cells),"""
    import desert_ex as DX
    ws = prep['worlds']
    cells = [world_cells(ws[DX.S1_WORLD + k], ws[ws[DX.S1_WORLD + k].get('shares', DX.S1_WORLD + k)]) for k in range(4)]
    pick = list(dict.fromkeys(((c[0], c[1]) for lst in prep['pits'] for c in (lst[0], lst[len(lst) // 2], lst[-1]))))
    changed = {(c, o) for lst in prep['pits'] for c, o, _, _ in lst}
    col, n = (pick[0][0], len(pick) + 2)
    r0 = (pick[0][1] >> 11) * 8 + ((pick[0][1] & 31) >> 2)
    for r in sorted(range(64), key=lambda r: abs(r - r0)):
        off = (col & 63) * 32 + (r >> 3) * 2048 + (r & 7) * 4
        if (col, off) not in changed and len(pick) < n:
            pick.append((col, off))
    out = []
    for c, off in pick:
        r = (off >> 11) * 8 + ((off & 31) >> 2)
        out.append(dict(col=c, off=off, row=r, want=[cells[k][c, r] for k in range(4)]))
    return out

def officer_checks(dec, steps1, prep, rows, events, frames, dz, pit, limit, pt_frames, pals, still):
    """Step 7 in a section 1 run, up to frame `limit` (DESERT_ENEMIES.md): the officer (spawn list 3, at its converted"""
    import desert_actors_ex as DA
    import desert_ex as DX
    K, h, t7 = (DA.KIND, dec['handlers'], dec['step7'])
    rl = [r for r in rows if r['frame'] < limit]
    by = {r['frame']: r for r in rows}
    fby = {int(r['frame']): r for r in frames}
    rank_t = {r['frame']: r['rank_t'] for r in rows}
    active = sorted((r['frame'] for p, r in zip(rows, rows[1:]) if r['rank_t'] != p['rank_t'] and r['frame'] < limit))
    news = [e for e in events if e['what'] == 'new' and e['frame'] < limit]
    gones = [e for e in events if e['what'] == 'gone' and e['frame'] < limit]
    lines = {}
    for e in events:
        if e['what'] == 'a5' and e['frame'] < limit:
            lines.setdefault(e['slot'], []).append(e)

    def life(n):
        end = min((g['frame'] for g in gones if g['slot'] == n['slot'] and g['frame'] > n['frame']), default=limit)
        return ([e for e in lines.get(n['slot'], []) if n['frame'] <= e['frame'] < end], end if end < limit else None)
    out, bad = ({}, [])
    s1 = [r for r in dz if r['sec'] == 1 and r['frame'] < limit]

    def ran(i):
        return next((r['frame'] for r in s1 if r['step'] > i), None)
    ix = {st: i for i, st in reversed(list(enumerate(steps1)))}
    i_pt, i_wp = (ix['portrait', DX.OFFICER_PORTRAIT], ix['waitpt',])
    i_once = max((i for i, st in enumerate(steps1) if st[0] == 'once'))
    i_pits = [i for i, st in enumerate(steps1) if st[0] == 'pit']
    i_wait = next((i for i, st in enumerate(steps1) if st[0] == 'wait'))
    pt_at, go = (ran(i_pt), ran(i_once))
    pt = [r['frame'] for r in rl if r['pt_on'] == PT_MAGIC]
    pt_end = next((r['frame'] for r in rl if pt_at and r['frame'] > pt_at and (r['pt_on'] != PT_MAGIC)), None)
    pt_want = pt_frames + PT_TAILN - 1
    out['portrait'] = dict(op_at=pt_at, shown=[pt[0], pt[-1]] if pt else None, frames=len(pt), want=pt_want, over_at=pt_end, go_at=go, ok=bool(pt) and pt[0] == pt_at and (len(pt) == pt_want) and (pt[-1] - pt[0] + 1 == len(pt)) and (go is not None) and (pt_end is not None) and (pt_end <= go <= pt_end + 1))
    want = prep['spawns']['spawn_lists'][3]
    ofs = sorted((e for e in news if e['kind'] == K['officer']), key=lambda e: e['frame'])
    lives, ev = ([], None)
    of_slot, of_lines, model = (None, {}, [])
    for n in ofs[:1]:
        if (n['x'], n['y'], n['facing'], n['id']) != tuple(want[0][3:5]) + (want[0][1], want[0][2]):
            bad.append((n['frame'], 'spawn', (n['x'], n['y'], n['facing'], n['id']), want[0]))
        ls, end = life(n)
        of_slot, of_lines = (n['slot'], {e['frame']: e for e in ls})
        first = next((e['frame'] for e in ls if e['st'] != 0), None)
        ups = [f for f in active if f >= first and (end is None or f <= end)]
        hits = {e['frame']: e['hits'] for e in ls}
        model, ev = officer_model(dec, (n['x'], n['y']), ups, go if go is not None else 10 ** 9, hits, rank_t)
        ob = []
        own = bytes(by[n['frame']]['pals'][pals['al_at']:pals['al_at'] + 30])
        white = bytes.fromhex(f"{DA.G.cps_color(h['of_flash_color']):04x}" * 15)
        black = bytes.fromhex(f'{DA.G.cps_color(0):04x}' * 15)
        for f, s, _ in model:
            e = of_lines.get(f)
            if s == 'gone':
                if end != f:
                    ob.append((f, 'gone', end))
                continue
            if e is None:
                ob.append((f, 'no line'))
                break
            got = (e['st'], e['sub'], e['t1'], e['t2'], e['py'], e['vxw'], e['y'], e['b42'], e['b43'], e['b44'], e['b45'], e['b46'], e['col'], e['l4c_raw'])
            wnt = (s['st'], 2 * s['sub'] if s['st'] == 2 else s['sub'], s['t1'], s['t2'], s['py'] & 4294967295, s['vy'], s['y']) + tuple(s['an']) + (s['col'], s['phits'] << 24 | s['pat'] << 16 | s['rank'] << 8 | s['act'])
            if got != wnt:
                ob.append((f, got, wnt))
            r = by.get(f)
            if r and bool(r['da6'][24]) != s['cam']:
                ob.append((f, 'camera target', r['da6'][24], s['cam']))
            if r:
                slot = bytes(r['pals'][pals['al_at']:pals['al_at'] + 30])
                if slot != {'own': own, 'white': white, 'black': black}[s['pal']]:
                    ob.append((f, 'antlion colors', slot.hex()[:16], s['pal']))
        if ob:
            bad.append((n['frame'], ob[:3]))
        lives.append(dict(spawn=n['frame'], first=first, frames=len(model), go_seen=ev['go_seen'], death=ev['death'], end=ev['end'], gone=end, rounds=len(ev['rounds']), balls=len(ev['balls']), actions=sorted({s['act'] for _, s, _ in model if s != 'gone' and s['st'] == 2 and (s['sub'] >= 5)}), ranks=sorted({s['rank'] for _, s, _ in model if s != 'gone' and s['st'] == 2 and (s['sub'] >= 5)}), hit_ticks=ev['flashes'], hits=max((e['hits'] for e in ls), default=0)))
    last, first_row = (rl[-1], rl[0])
    da6 = [a - b for a, b in zip(struct.unpack('>11H', bytes(last['da6'][:22])), struct.unpack('>11H', bytes(first_row['da6'][:22])))]
    c6 = dict(zip(('ofspawn', 'ofhit', 'ofkill', 'ofend', 'grmade', 'grfull', 'blmade', 'ndmade', 'ofboom', 'pldrag', 'plarm'), da6))
    kcut = [a - b for a, b in zip(last['kcut'], first_row['kcut'])]
    khurt = [a - b for a, b in zip(last['khurt'], first_row['khurt'])]
    out['officers'] = dict(lives=lives, bad=bad[:4], counters=c6, contacts=len(increments(rl, 'khurt', K['officer'])), cuts=kcut[K['officer']], ok=bool(ofs) and (not bad) and (c6['ofspawn'] == len(ofs)) and (c6['ofkill'] == sum((1 for x in lives if x['death']))) and (c6['ofend'] == sum((1 for x in lives if x['end']))) and (c6['ofhit'] == sum((len(x['hit_ticks']) for x in lives))))
    leaps = []
    for f in lives[0]['hit_ticks'] if lives else []:
        prev = max((g for g in of_lines if g < f), default=None)
        leaps.append(prev is not None and of_lines[prev]['sub'] == 14 and (of_lines[prev]['col'] == 3))
    out['hits'] = dict(ticks=lives[0]['hit_ticks'] if lives else [], in_leaps=sum(leaps), ok=all(leaps))
    of_st = {f: e['st'] for f, e in of_lines.items()}
    of_gone = lives[0]['gone'] if lives else None

    def alive_for(slot):

        def alive(f):
            g = f if of_slot is not None and of_slot < slot else f - 1
            if of_gone is not None and g >= of_gone:
                return False
            return of_st.get(g) == 2
        return alive
    spawns = {}
    if ev:
        for fr, ents in ev['rounds']:
            for k, x, y in ents:
                spawns[fr, 'grain', k] = (x, y)
        for fr, x, y in ev['balls']:
            spawns[fr, 'ball', 0] = (x, y)
    pb, made = ([], {'grain': 0, 'ball': 0, 'needle': 0})
    rounds = {}
    queue = sorted((e for e in news if e['kind'] in (K['grain'], K['ball'], K['needle'])), key=lambda e: (e['frame'], e['slot']))
    names = {K['grain']: 'grain', K['ball']: 'ball', K['needle']: 'needle'}
    for n in queue:
        kind = names[n['kind']]
        ls, end = life(n)
        if not ls:
            pb.append((n['frame'], kind, 'no line'))
            continue
        head = ls[0]['l48'] >> 8 & 255
        key = (n['frame'], kind, head if kind != 'ball' else 0)
        if key not in spawns:
            pb.append((n['frame'], kind, head, 'not a modeled spawn'))
            continue
        made[kind] += 1
        if kind == 'grain':
            rounds.setdefault(n['frame'], []).append(head)
        first = next((e['frame'] for e in ls if e['b47'] & 1), None)
        ups = [f for f in active if f >= first and (end is None or f <= end)]
        m, needles = projectile_model(dec, kind, spawns[key], head, ups, alive_for(n['slot']))
        for fr, x, y, k in needles:
            spawns[fr, 'needle', k] = (x, y)
        byf = {e['frame']: e for e in ls}
        for f, s in m:
            e = byf.get(f)
            if s is None:
                if end != f:
                    pb.append((f, kind, 'gone', end))
                continue
            if e is None:
                pb.append((f, kind, 'no line'))
                break
            pvx = (e['l48_raw'] >> 16) - (65536 if e['l48_raw'] >> 31 else 0)
            got = (e['sub'], e['t1'], e['px'], e['py'], e['vxw'], pvx, e['l48'] & 255, e['x'], e['y'], e['col'], e['b42'], e['b43'], e['b44'], e['b45'], e['b46'])
            wnt = (2 * s['sub'], s['t1'], s['px'] & 4294967295, s['py'] & 4294967295, s['vy'], s['vx'], 255 if s['gone'] else 0, s['x'], s['y'], s['col']) + tuple(s['an'])
            if got != wnt:
                pb.append((f, kind, n['slot'], got, wnt))
                break
    model_rounds = [fr for fr, _ in ev['rounds']] if ev else []
    bad_rounds = [(f, hs) for f, hs in rounds.items() if f not in model_rounds or sorted(hs) != list(range(len(hs))) or (len(hs) < 8 and by.get(f - 1, {}).get('free5', 0) >= GRAIN_FREE + 8)]
    out['projectiles'] = dict(made=made, counters=dict(grains=c6['grmade'], full=c6['grfull'], balls=c6['blmade'], needles=c6['ndmade']), rounds=len(rounds), model_rounds=len(model_rounds), short_rounds=sum((1 for hs in rounds.values() if len(hs) < 8)), bad=pb[:4], bad_rounds=bad_rounds[:4], ok=not pb and (not bad_rounds) and (c6['grmade'] + c6['grfull'] == 8 * len(model_rounds)) and (made['grain'] == c6['grmade']) and (made['ball'] == c6['blmade']) and (made['needle'] == c6['ndmade']) and (khurt[K['grain']] == 0) and (kcut[K['grain']] + kcut[K['ball']] + kcut[K['needle']] == 0))
    pulls = sorted((e for e in news if e['kind'] == K['pull']), key=lambda e: e['frame'])
    pbad = []
    if pulls and model:
        ls, _ = life(pulls[0])
        byf = {e['frame']: e for e in ls}
        ticks = [f for i, (f, s, _) in enumerate(model) if s != 'gone' and i % 2 == 0]
        if of_gone is not None:
            ticks.append(of_gone)
            ticks += [f for f in active if f > of_gone and (f - of_gone) % 2 == 0]
        pm = pull_model(dec, ticks, go if go is not None else 10 ** 9, ev['arms'], rank_t)
        wrote, cyc = (0, t7['pl_cycle'])
        for f in [f for f in active if f >= ticks[0]]:
            if f in pm:
                sub, t1, cnt, ph, st, ps, w = pm[f]
                wrote = w if w is not None else wrote
                e = byf.get(f)
                got = e and (e['sub'], e['t1'], e['b42'], e['b43'], e['b44'], e['b45'])
                if got != (2 * sub, t1, cnt, ph, st, ps):
                    pbad.append((f, 'pull', got, (2 * sub, t1, cnt, ph, st, ps)))
            r = by.get(f)
            pens = bytes(r['pals'][pals['cyc_at']:pals['cyc_at'] + 12]) if r else None
            if pens != b''.join((DA.G.cps_color(v).to_bytes(2, 'big') for v in cyc[wrote])):
                pbad.append((f, 'pens', pens and pens.hex(), wrote))
    out['pull'] = dict(ticks=len(pm) if pulls and model else 0, bad=pbad[:4], ok=bool(pulls) and (not pbad) and (len(pulls) == 1))
    every = h['pit_period'] + 1
    pit_at = [ran(i) for i in i_pits]
    pit_want = [go + 2 * (h['s1_open_wait'] + every * k) for k in range(1, h['pit_n'])] if go is not None else None
    samples = pits_bad = None
    if pit is not None:
        samples, pits_bad = (pit['samples'], [])
        marks = [(pt_at or 0, 0)] + [(f, k + 1) for k, f in enumerate(pit_at) if f is not None]
        for f, vals in pit['rows']:
            if f >= limit or f < (pt_at or 0):
                continue
            k = max((v for fr, v in marks if fr <= f))
            want = [(s['want'][k][0], s['want'][k][1]) for s in samples]
            if vals != want:
                pits_bad.append((f, k, [(s['col'], s['row']) for s, a, b in zip(samples, vals, want) if a != b][:4]))
        for f, k in marks:
            if pit['at'](f) != [(s['want'][k][0], s['want'][k][1]) for s in samples]:
                pits_bad.append((f, k, 'not on its frame'))
    skipped = max((r['da6'][42] << 8 | r['da6'][43] for r in rl), default=0)
    out['pit'] = dict(at=pit_at, want=pit_want, cells_bad=(pits_bad or [])[:4], left_out=skipped, ok=pit_at == pit_want and pits_bad == [] and (skipped == 0))
    reached, passed = (ran(i_wait - 1), ran(i_wait))
    ends = [x['end'] for x in lives if x['end']]
    out['section_wait'] = dict(step=i_wait, reached=reached, passed=passed, officer_end=ends, ok=reached is not None and (passed is None if not ends else ends[0] <= passed <= ends[0] + 1))
    sc = [(r['frame'], bcd(r['score']) - bcd(p['score'])) for p, r in zip(rl, rl[1:]) if r['score'] != p['score']]
    out['score'] = dict(changes=sc[:4], ok=sc == ([(ends[0], 700)] if ends else []))
    deb = dict(ev['debris']) if ev else {}
    delta = {r['frame']: r['da6'][17] - p['da6'][17] for p, r in zip(rl, rl[1:]) if r['da6'][17] != p['da6'][17]}
    dbad = [(f, d) for f, d in delta.items() if d > len(deb.get(f, []))]
    dbad += [(f, 'none with room') for f, ents in deb.items() if not delta.get(f) and by.get(f - 1, {}).get('free6', 0) >= 30]
    out['debris'] = dict(modeled=sum((len(v) for v in deb.values())), made=sum(delta.values()), bad=dbad[:4], ok=not dbad)
    eq7 = DA.step7_equates(h, t7, dec['step3']['rank'], dec['step3']['difficulty'], {1280: 0, 512: 0})
    pan, panbad = ([r['frame'] for r in rl if r['da6'][24]], [])
    for f in pan:
        r0, r1, ofl = (fby.get(f - 1), fby.get(f), of_lines.get(f))
        if not (r0 and r1 and ofl):
            panbad.append((f, 'no line'))
            continue
        sec = struct.unpack('>4h', bytes(by[f]['da6'][28:36]))
        want_sec = tuple((int(v) for v in pan_limits(s1, steps1, f)))
        lim = [int(v) for v in next((x['limits'] for x in reversed(s1) if x['frame'] <= f)).split(',')]
        cam0, hy = (int(r0['camy']), by[f]['hy'])
        t = 2047 - (ofl['y'] >> 16)
        pce = DX.CAM_TOP - cam0
        d = t - min(max(t - pce, eq7['DA_PAN_LO']), eq7['DA_PAN_HI'])
        d = min(max(d, DX.CAM_TOP - sec[3]), DX.CAM_TOP - sec[2])
        step = min(max(d - pce, -eq7['DA_PAN_STEP']), eq7['DA_PAN_STEP'])
        cam = min(max(cam0 - step, hy - eq7['DA_PAN_HMAX']), hy - eq7['DA_PAN_HMIN'])
        got = (int(r1['camy']), lim[2:], sec, by[f]['da6'][26] << 8 | by[f]['da6'][27])
        if got != (cam, [cam, cam], want_sec, t):
            panbad.append((f, got, (cam, want_sec, t)))
    after = next((r['frame'] for p, r in zip(rl, rl[1:]) if p['da6'][24] and (not r['da6'][24])), None)
    back = next((x['limits'] for x in s1 if after and x['frame'] >= after), None)
    back_ok = after is None or back == ','.join((str(v) for v in pan_limits(s1, steps1, after)))
    out['pan'] = dict(frames=len(pan), first=pan[0] if pan else None, last=pan[-1] if pan else None, bad=panbad[:4], back=back, back_ok=back_ok, ok=bool(pan) == bool(ev and ev['cam']) and (not panbad) and back_ok)
    dr, drbad = ([], [])
    pl_lines = {e['frame']: e for e in (life(pulls[0])[0] if pulls else [])}

    def s8(v):
        return (v & 255) - (256 if v & 128 else 0)

    def side(hx, hy, hst, ps):
        if not ps or hst:
            return 0
        x = (hx >> 16) * 2 // 3
        ht = 2047 - hy - eq7['DA_PL_LY']
        if not 0 <= ht < 256:
            return 0
        dx = x - h['pl_left_x']
        if 0 <= dx < h['pl_left_w'] and -h['pl_tol_hi'] <= s8(2 * dx - ht) < h['pl_tol_hi']:
            return 1 if dx < h['pl_lim_l'] else 0
        dx = x - h['pl_right_x']
        if 0 <= dx < h['pl_right_w'] and -h['pl_tol_hi'] <= s8(h['pl_right_y'] - 2 * dx - ht) < h['pl_tol_hi']:
            return -1 if dx >= h['pl_lim_r'] else 0
        return 0
    for p, r in zip(rl, rl[1:]):
        dd = (r['da6'][18] << 8 | r['da6'][19]) - (p['da6'][18] << 8 | p['da6'][19])
        e = pl_lines.get(r['frame'])
        ps = e['b45'] if e else 0
        step = (t7['pl_drag_x'][ps] << 8 | t7['pl_drag_xf'][ps]) * 192
        d = [s for s in (1, -1) if side(r['hx'] - s * step & 4294967295, r['hy'], r['hst'], ps) == s] if dd else [0] if side(r['hx'], r['hy'], r['hst'], ps) == 0 else []
        if dd:
            dr.append(r['frame'])
        if dd not in (0, 1) or len(d) != 1:
            drbad.append((r['frame'], dd, d, ps, hex(r['hx']), r['hy'], r['hst']))
        elif d[0] and still is not None and (r['frame'] > still) and (p['hst'] == r['hst'] == 0):
            if r['hx'] - p['hx'] & 4294967295 != d[0] * step & 4294967295:
                drbad.append((r['frame'], 'step', ps, hex(p['hx']), hex(r['hx'])))
    out['drag'] = dict(frames=len(dr), bad=drbad[:4], ok=not drbad)
    return out

def pan_limits(s1, steps1, f):
    """The camera bounds section 1's last limits step before frame f set (X min, X max, Y min, Y max: the step's own)."""
    reached = [r for r in s1 if r['frame'] <= f]
    step = reached[-1]['step'] if reached else 0
    i = max((k for k in range(min(step, len(steps1))) if steps1[k][0] == 'limits'), default=None)
    return steps1[i][1:5] if i is not None else (0, 0, 0, 0)

def pull_model(dec, ticks, go, arms, rank_t):
    """An independent model of the PC Engine's sand-pull 0x58 (0x74:0xA681) on its ticks: its sub-states (the cycled"""
    h, t7, t3 = (dec['handlers'], dec['step7'], dec['step3'])
    s = dict(sub=0, t1=0, cnt=0, ph=0, str=0, ps=0)
    wrote, out, armed = (None, {}, set(arms))
    for f in ticks:
        if s['sub'] == 0:
            wrote = 0
            if f > go:
                s.update(sub=1, t1=h['pl_wait'])
        if s['sub'] == 1:
            if s['t1']:
                s['t1'] -= 1
            else:
                s['sub'] = 2
        period = t7['pl_period'][s['str'] >> 6]
        if period:
            if s['cnt']:
                s['cnt'] -= 1
            else:
                s['cnt'] = period - 1
                wrote = s['ph']
                s['ph'] = (s['ph'] + 1) % h['pl_phases']
        s['ps'] = s['str'] >> 6
        if f in armed:
            s['str'] = t7['pl_arm'][pce_rank(t3, rank_t[f - 1])]
        if s['str']:
            s['str'] -= 2
        out[f] = (s['sub'], s['t1'], s['cnt'], s['ph'], s['str'], s['ps'], wrote)
    return out

def pce_camera(camx, camy):
    """The PC Engine camera the arcade's stands for (X / 1.5 truncated, as asm da_pce_cam's divs; Y CAM_TOP - Y)."""
    import desert_ex as DX
    return (int(2 * camx / 3), DX.CAM_TOP - camy)

def commander_model(dec, start, ups, go):
    """An independent model of the PC Engine's commander 0x4C (0x74:0xA5E4) in arcade terms, from its spawn record (start:"""
    h = dec['handlers']
    an = PceAnim(dec['actors'][76]['anims'])
    c = dict(sub=0, t1=0, vx=0, px=start[0] * 2 // 3 << 8, py=2047 - start[1] << 8, gone=False, seen=None)
    x16, y16 = ((start[0] & 65535) << 16, (start[1] & 65535) << 16)
    vx16 = vy16 = 0
    out = []

    def s1():
        if c['t1']:
            c['t1'] -= 1
            return
        c.update(sub=2, t1=h['cm_walk_t'], vx=h['cm_vx'])
        an.jan = h['cm_walk_anim']
        s2()

    def s2():
        if c['t1']:
            c['t1'] -= 1
        else:
            c['gone'] = True
    for i, f in enumerate(ups):
        if i % 2 == 0:
            if c['gone']:
                out.append((f, None))
                break
            px0, py0 = (c['px'], c['py'])
            if c['sub'] == 0:
                if f > go:
                    c.update(sub=1, t1=h['cm_t1'], seen=f)
                    an.jan = 0
                    s1()
            elif c['sub'] == 1:
                s1()
            else:
                s2()
            c['px'] += c['vx']
            an.tick()
            vx16, vy16 = ((c['px'] - px0) * 192, -(c['py'] - py0) * 128)
        x16 = x16 + vx16 & 4294967295
        y16 = y16 + vy16 & 4294967295
        out.append((f, dict(c, an=an.state(), x=x16, y=y16)))
    return out

def deck(dec, d):
    """The deck's profile at d (0xA27F): (p, the PC Engine's kind 2 sloped or 4 flat)."""
    h = dec['handlers']
    if d < h['rd_p1_d']:
        return (h['rd_p1_c'] - d, h['rd_p1_kind'])
    if d < h['rd_p2_d']:
        return (h['rd_p2_c'], h['rd_p2_kind'])
    if d < h['rd_p3_d']:
        return (h['rd_p3_c'] - d, h['rd_p3_kind'])
    return (h['rd_p4_c'], h['rd_p4_kind'])

def ride_test(dec, hx, hy, tpx, tpy):
    """The PC Engine's deck test (0xA1D7) for Hiryu at the arcade (hx, hy) and the tank at its PC Engine integer (tpx, tpy):"""
    import desert_actors_ex as DA
    h = dec['handlers']
    d = int(2 * hx / 3) - tpx + h['rd_dx']
    feet = 2047 - hy - DA_HIRYU_DY + DA.HIRYU_HALF - tpy
    if not (0 <= d < h['rd_w'] and 0 <= feet + h['rd_dy'] < h['rd_h']):
        return None
    p, kind = deck(dec, d)
    diff = 8 + p - feet
    return (diff, kind) if h['rd_tol_lo'] <= diff < h['rd_tol_hi'] else None

def tank_model(dec, start, ups, go, frames, riding, p3hits):
    """An independent model of the PC Engine's tank 0x4A (0x74:0x9255) with its four parts, in arcade terms (DESERT_ENEMIES.md"""
    h, t8 = (dec['handlers'], dec['step8'])
    pos = {int(r['frame']): (int(r['plx']), int(r['ply'])) for r in frames}
    cam = {int(r['frame']): (int(r['camx']), int(r['camy'])) for r in frames}
    t = dict(st=2, sub=0, t1=0, t2=0, cn=0, tu=0, tt=0, aim=0, fl=0, mi=0, c0=0, c2=0, c1=0, tp=0, tr=0, bp=0, bt=0, colf=0, px=start[0] * 2 // 3 << 8, py=2047 - start[1] << 8, vx=0, vy=0, white=False)
    parts = [dict(pix=k, rm=0, am=0, pt=0, jfr=h[f'pt{k}_frame'], pfl=0, pht=0, ppu=0, ppx=0, ppy=2047, rise=0, col=0) for k in range(4)]
    x16, y16 = ((start[0] & 65535) << 16, (start[1] & 65535) << 16)
    vx16 = vy16 = 0
    ev = dict(bullets=[], shells=[], debris=[], killed=None, end=None, hits=[])
    out = []
    pcx = pcy = hxp = hyp = 0
    f = None

    def s16(v):
        v &= 65535
        return v - 65536 if v & 32768 else v

    def s8(v):
        v &= 255
        return v - 256 if v & 128 else v

    def hi(v):
        return s8(v >> 8)

    def txy():
        return (t['px'] >> 8, t['py'] >> 8)

    def arc(x, y):
        return (x + (x >> 1), 2047 - y)

    def s4_in():
        t.update(sub=4, vx=0, t1=h['tk_pause_r'])
        s4()

    def s4():
        if t['t1']:
            t['t1'] -= 1
            return
        t.update(sub=5, vx=0)
        s5()

    def s5():
        if (t['px'] >> 8) - h['tk_home_x'] < h['tk_left_lim']:
            t.update(sub=6, vx=0, t1=h['tk_pause_l'])
            s6()
            return
        t['vx'] = max(t['vx'] + h['tk_left_acc'], h['tk_left_max'])

    def s6():
        if t['t1']:
            t['t1'] -= 1
            return
        s7_in()

    def s7_in():
        t.update(sub=7, vx=0)
        s7()

    def s7():
        if (t['px'] >> 8) - h['tk_home_x'] >= h['tk_right_lim']:
            s4_in()
            return
        t['vx'] = min(t['vx'] + h['tk_right_acc'], h['tk_right_max'])

    def ai():
        if t['sub'] == 0:
            t['sub'] = 1
        if t['sub'] == 1:
            if not f > go:
                return
            t.update(sub=2, t1=h['tk_wait2'])
        if t['sub'] == 2:
            if t['t1']:
                t['t1'] -= 1
                return
            t.update(sub=3, t1=h['tk_wait3'], c0=h['tk_rise_cmd'], c1=h['tk_rise_cmd'], c2=h['tk_rise_cmd'])
        if t['sub'] == 3:
            if t['t1']:
                t['t1'] -= 1
                return
            t['colf'] = h['tk_colflags']
            s7_in()
            return
        {4: s4, 5: s5, 6: s6, 7: s7}[t['sub']]()

    def cn1():
        t.update(cn=2, t2=h['cn_wait'])
        cn2()

    def cn2():
        if t['t2']:
            t['t2'] -= 1
            return
        if t['sub'] == h['cn_sub_fire']:
            t.update(cn=3, t2=h['cn_fire_t'], c2=h['cn_cmd_fire'])
            cn3()
        elif t['sub'] == h['cn_sub_mortar']:
            t.update(cn=4, mi=0)
            cn_next()

    def cn3():
        if t['t2']:
            t['t2'] -= 1
        else:
            cn1()

    def cn_next():
        t.update(t2=h['mt_every'], c2=h['cn_cmd_mortar'])
        cn4()

    def cn4():
        if t['t2']:
            t['t2'] -= 1
            return
        t['mi'] += 1
        if t['mi'] != h['mt_n']:
            cn_next()
        else:
            cn1()

    def cannon():
        if t['cn'] == 0:
            t['cn'] = 1
        if t['cn'] == 1:
            cn1()
        else:
            {2: cn2, 3: cn3, 4: cn4}[t['cn']]()

    def tu_wait():
        t.update(tu=2, tt=h['tu_period'])
        tu2()

    def tu2():
        if t['tt']:
            t['tt'] -= 1
            return
        if (t['px'] >> 8) - pcx >= h['tu_screen'] or not t['aim'] & 128:
            tu_wait()
            return
        t.update(tu=3, tt=h['tu_burst'])
        tu3()

    def tu3():
        if t['tt']:
            t['tt'] -= 1
            t['c1'] = h['tu_cmd']
        else:
            tu_wait()

    def turret():
        if t['tu'] == 0:
            t['tu'] = 1
        if t['tu'] == 1:
            if t['sub'] == h['tu_sub']:
                tu_wait()
        else:
            {2: tu2, 3: tu3}[t['tu']]()

    def place(p, dx, dy):
        x, y = txy()
        p['ppx'], p['ppy'] = (x + dx, y + dy + hi(p['rise']))

    def rise(p, ck, bit, top, v):

        def r0():
            p['rm'] = 1
            r1()

        def r1():
            if t['fl'] & bit:
                return down()
            if t[ck] == h['pt0_cmd_rise']:
                t[ck] = 0
                p['rm'] = 2
                r2()
            elif t[ck] == h['pt0_cmd_lower']:
                t[ck] = 0
                down()

        def r2():
            p['rise'] = p['rise'] + v & 65535
            if s8((p['rise'] >> 8) - top) < 0:
                p['rise'] = p['rise'] & 255 | top << 8
                r0()

        def down():
            p['rm'] = 3
            r3()

        def r3():
            p['rise'] = p['rise'] + h['pt0_lower'] & 65535
            if hi(p['rise']) >= 0:
                p['rise'] &= 255
                p['rm'] = 4
        [r0, r1, r2, r3, lambda: None][p['rm']]()

    def act0(p):

        def a0():
            p.update(am=1, jfr=h['pt0_frame'])
            a1()

        def a1():
            if t['fl'] & 1:
                p['am'] = 3
            elif t['c0'] == 3:
                t['c0'] = 0
                p.update(am=2, pt=32, jfr=h['pt0_frame'])
                a2()
            elif t['c0'] == 4:
                t['c0'] = 0

        def a2():
            if not p['pt']:
                return a0()
            p['pt'] -= 1
            if p['pt'] == 30:
                p['jfr'] = h['pt0_frame']
        [a0, a1, a2, lambda: None][p['am']]()

    def act2(p):

        def a0():
            p.update(am=1, jfr=h['pt2_frame'])
            a1()

        def a1():
            if t['fl'] & 4:
                p['am'] = 4
                return
            c = t['c2']
            if c == h['cn_cmd_fire']:
                t['c2'] = 0
                p.update(am=2, pt=h['cn_recoil_t'], jfr=h['cn_recoil_frame'])
                ev['shells'].append((f, 0, p['ppx'] + h['sh_dx'], p['ppy'] + h['sh_dy'], h['sh_vx'], h['sh_vy'], 0))
                a23()
            elif c == h['cn_cmd_none']:
                t['c2'] = 0
            elif c == h['cn_cmd_mortar']:
                t['c2'] = 0
                p.update(am=3, pt=h['cn_recoil_t'])
                ev['shells'].append((f, 2, p['ppx'] + h['mt_dx'], p['ppy'] + h['mt_dy'], h['mt_vx'], h['mt_vy'], t['mi']))
                a23()

        def a23():
            if not p['pt']:
                return a0()
            p['pt'] -= 1
            if p['pt'] == h['cn_back']:
                p['jfr'] = h['pt2_frame']
        [a0, a1, a23, a23, lambda: None][p['am']]()

    def act1(p):

        def a0():
            p.update(am=1, pt=0)
            a1()

        def a1():
            if t['fl'] & 2:
                p['am'] = 3
                return
            c = t['c1']
            if c == h['tu_cmd']:
                t['c1'] = 0
                a = t['aim'] & 127
                p.update(am=2, pt=h['tu_fire_t'], jfr=t8['tu_firef'][a])
                bx, by = arc(p['ppx'] + t8['tu_dx'][a], p['ppy'] + t8['tu_dy'][a])
                ev['bullets'].append((f, bx, by, t8['tu_vx'][a] * 192, -t8['tu_vy'][a] * 128))
                ev['shells'].append((f, 1, p['ppx'] + t8['cs_dx'][a], p['ppy'] + t8['cs_dy'][a], t8['cs_vx'][a], t8['cs_vy'][a], 0))
                a2()
            elif c == h['tu_cmd_none']:
                t['c1'] = 0
            elif p['pt']:
                p['pt'] -= 1
            else:
                p['pt'] = h['tu_aim_t']
                d = pce_dir(hxp - p['ppx'], hyp - p['ppy'])
                if d < h['tu_no_dir']:
                    t['aim'] = t8['tu_aim'][d]
                    p['jfr'] = t8['tu_idle'][t['aim'] & 127]

        def a2():
            if not p['pt']:
                return a0()
            p['pt'] -= 1
            if not p['pt']:
                p['jfr'] = t8['tu_idle'][t['aim'] & 127]
        [a0, a1, a2, lambda: None][p['am']]()

    def pce_dir(dx, dy):
        dx, dy = (max(-127, min(127, dx)), max(-127, min(127, dy)))
        while not (-4 <= dx <= 3 and -4 <= dy <= 3):
            dx, dy = (dx >> 1, dy >> 1)
        return dec['step3']['atan'][(dx & 7) * 8 + (dy & 7)]

    def on_screen(x):
        return x - pcx < h['pu_screen']

    def part3(p, p2):
        p['ppx'] = p2['ppx'] + h['pt3_dx']
        p['ppy'] = p2['ppy'] + h['pt3_dy'] + hi(p['rise'])
        if p['ppu'] == 0:
            p['ppu'] = 1
        if p['ppu'] == 1:
            if not on_screen(p['ppx']):
                pass
            else:
                d = min(abs(hxp - p['ppx']), 255)
                if h['pu_near'] <= d < h['pu_far']:
                    p['ppu'] = 2
                    p['pfl'] |= 8
        if p['ppu'] == 2 and p['pfl'] & 128:
            p['ppu'] = 3
            p['pfl'] = (p['pfl'] | 2) & ~32
        if p['ppu'] == 3 and p['pfl'] & 32:
            p['ppu'] = 4
            p['pfl'] |= 4
        if p['ppu'] == 4 and p['pfl'] & 64:
            p['ppu'] = 1
            if on_screen(p['ppx']):
                d = min(abs(hxp - p['ppx']), 255)
                if h['pu_near'] <= d < h['pu_far']:
                    p['ppu'] = 2
                    p['pfl'] |= 8

        def r_in():
            p['rm'] = 1
            r1()

        def r1():
            if t['fl'] & 8:
                p['jfr'] = h['pt3_dead_frame']
                return down()
            if p['pfl'] & 8:
                p['pfl'] &= ~8
                p['rm'] = 2
                p['pfl'] &= 63
                r2()
            elif p['pfl'] & 4:
                p['pfl'] &= ~4
                down()

        def r2():
            p['rise'] = p['rise'] + h['pt3_rise_v'] & 65535
            if s8((p['rise'] >> 8) - h['pt3_top']) < 0:
                p['rise'] = p['rise'] & 255 | h['pt3_top'] << 8
                p['pfl'] |= 128
                r_in()

        def down():
            p['rm'] = 3
            p['pfl'] &= 63
            r3()

        def r3():
            p['rise'] = p['rise'] + h['pt3_lower'] & 65535
            if hi(p['rise']) >= 0:
                p['rise'] &= 255
                p['pfl'] |= 64
                if t['fl'] & 8:
                    p['rm'] = 4
                else:
                    r_in()
        if p['rm'] == 0:
            p['pfl'] &= 63
            r_in()
        else:
            [None, r1, r2, r3, lambda: None][p['rm']]()

        def a_in():
            p['am'] = 1
            a1()

        def a1():
            if t['fl'] & 8:
                p['am'] = 3
            elif p['pfl'] & 2:
                p['pfl'] &= ~2
                p['am'] = 2
                p['pfl'] &= ~32
                p['pt'] = h['pt3_fire_t']
                a2()

        def a2():
            if not t['fl'] & 128:
                if p['pt']:
                    p['pt'] -= 1
                    return
                if on_screen(p['ppx']):
                    bx, by = arc(p['ppx'] + h['b3_dx'], p['ppy'] + h['b3_dy'])
                    ev['bullets'].append((f, bx, by, h['b3_vx'] * 192, -h['b3_vy'] * 128))
            p['pfl'] |= 32
            a_in()
        if p['am'] == 0:
            p['pfl'] &= 207
            a_in()
        else:
            [None, a1, a2, lambda: None][p['am']]()
        p['col'] = 2 if p['pht'] < 128 and p['pfl'] & 128 and t['colf'] & 64 else 0
        if p['pht'] < 128 and p3hits.get(f - 1, 0):
            t['fl'] |= 128
            ev['hits'].append(f)
            p['pht'] += 1
            if p['pht'] >= t8['hit_lim'][3]:
                p['pht'], p['col'] = (255, 0)
                t['fl'] |= 8

    def step_parts():
        for p in parts:
            t['fl'] &= t8['hit_clr'][p['pix']]
            k = p['pix']
            if k == 0:
                place(p, h['pt0_dx'], h['pt0_dy'])
                rise(p, 'c0', 1, h['pt0_top'], h['pt0_rise_v'])
                act0(p)
            elif k == 1:
                place(p, h['pt1_dx'], h['pt1_dy'])
                rise(p, 'c1', 2, h['pt1_top'], h['pt1_rise_v'])
                act1(p)
            elif k == 2:
                place(p, h['pt2_dx'], h['pt2_dy'])
                rise(p, 'c2', 4, h['pt2_top'], h['pt2_rise_v'])
                act2(p)
            else:
                part3(p, parts[2])

    def speed():
        v = t['vx'] >> 8 & 255
        return (-v & 255 if v & 128 else v) & 15

    def treads():
        per = t8['tr_period'][speed() >> 1]
        if not per:
            return
        if t['tr']:
            t['tr'] -= 1
            return
        t['tr'] = per - 1
        t['tp'] ^= 1

    def bob():
        per = t8['bob_period'][speed()]
        if not per:
            return
        if t['bt']:
            t['bt'] -= 1
            return
        t['bt'] = per - 1
        t['py'] = t['py'] & 255 | h['tk_home_y'] + t8['bob_dy'][t['bp']] << 8
        t['bp'] ^= 1

    def flash():
        t['white'] = bool(t['fl'] & 240)

    def debris():
        while True:
            if t['bt']:
                t['bt'] -= 1
                return False
            ticks, k = (t8['dbr_script'] + [(255, 0)])[t['bp']]
            if ticks == 255:
                return True
            t['bt'] = ticks
            t['bp'] += 1
            ev['debris'].append((f, (x16 >> 16) + t8['dbr_dx'][k] * 3 // 2, (y16 >> 16) - t8['dbr_dy'][k]))
    pxo = [h['pt0_dx'] * 3 // 2, h['pt1_dx'] * 3 // 2, h['pt2_dx'] * 3 // 2, (h['pt2_dx'] + h['pt3_dx']) * 3 // 2]
    pyo = [h['pt0_dy'], h['pt1_dy'], h['pt2_dy'], h['pt2_dy'] + h['pt3_dy']]

    def hiryu(step):
        nonlocal hxp, hyp
        fx = pos[f]
        hx_a = fx[0] - (step if f in riding else 0)
        hxp, hyp = (int(2 * hx_a / 3), 2047 - fx[1] - DA_HIRYU_DY)
    for i, f in enumerate(ups):
        if i % 2 == 0:
            cx, cy = cam[f - 1]
            pcx, pcy = pce_camera(cx, cy)
            hiryu(0)
            px0, py0 = (t['px'], t['py'])
            if t['st'] == 2:
                ai()
                cannon()
                turret()
                t['px'] += t['vx']
                hiryu((x16 + (t['px'] - px0) * 192 >> 16) - (x16 >> 16))
                step_parts()
                if t['fl'] & 8:
                    t.update(st=4, sub=0, vy=t['t2'])
                    ev['killed'] = f
                treads()
                bob()
                flash()
            else:
                if t['sub'] == 0:
                    t.update(sub=2, vx=0, vy=0, t1=h['tk_die_t'])
                if t['sub'] == 2:
                    if t['t1']:
                        t['t1'] -= 1
                        t['px'] += t['vx']
                        t['py'] += t['vy']
                        step_parts()
                        flash()
                    else:
                        t.update(sub=4, bp=0, bt=0, colf=0, vy=h['tk_sink'])
                if t['sub'] == 4:
                    if debris():
                        ev['end'] = f
                        t['white'] = False
                        out.append((f, None, None))
                        break
                    t['px'] += t['vx']
                    t['py'] += t['vy']
                    step_parts()
                    flash()
            vx16, vy16 = ((t['px'] - px0) * 192, -(t['py'] - py0) * 128)
        ox = x16 >> 16
        x16 = x16 + vx16 & 4294967295
        y16 = y16 + vy16 & 4294967295
        step = ((x16 >> 16) - ox + 32768 & 65535) - 32768
        pl = []
        for p in parts:
            dy = pyo[p['pix']] + hi(p['rise']) + (hi(parts[2]['rise']) if p['pix'] == 3 else 0)
            pl.append(dict(p, x=x16 + (pxo[p['pix']] << 16) & 4294967295, y=y16 - (dy << 16) & 4294967295))
        out.append((f, dict(t, tick=i % 2 == 0, x=x16, y=y16, step=step), pl))
    return (out, ev)

def shell_model(dec, param, start, vel, idx, ups, frames, hits, floors):
    """An independent model of one of the tank's 0x4B (0x74:0xA2D5): parameter 0 the shell, 1 a casing, 2 a mortar shell,"""
    h, t8 = (dec['handlers'], dec['step8'])
    an = PceAnim(dec['actors'][75]['anims'])
    cam = {int(r['frame']): (int(r['camx']), int(r['camy'])) for r in frames}
    s = dict(st=2, sub=0, px=start[0] << 8, py=start[1] << 8, vx=vel[0], vy=vel[1], gone=False, col={0: 1, 1: 0, 2: 5}[param], face=0)
    x16 = (start[0] + (start[0] >> 1) & 65535) << 16
    y16 = (2047 - start[1] & 65535) << 16
    vx16 = vy16 = 0
    out, bursts = ([], [])

    def sv(v):
        v &= 65535
        return v - 65536 if v & 32768 else v
    for i, f in enumerate(ups):
        if i % 2 == 0:
            if s['st'] == 4:
                bursts.append((f, x16 >> 16, y16 >> 16))
                out.append((f, None))
                break
            if s['gone']:
                out.append((f, None))
                break
            pcx, pcy = pce_camera(*cam[f - 1])
            px0, py0 = (s['px'], s['py'])
            dx, dy = ((s['px'] >> 8) - pcx, (s['py'] >> 8) - pcy)
            if param == 0:
                if s['sub'] == 0:
                    s['sub'] = 1
                    an.jan = 0
                if dx >= h['sh_right'] if s['vx'] >= 0 else dx < h['sh_left']:
                    s['gone'] = True
            elif param == 1:
                if s['sub'] == 0:
                    s['sub'] = 1
                    an.jan = h['cs_anim']
                s['vy'] = sv(s['vy'] + h['cs_g'])
                if s['vy'] >= 0 and dy >= h['cs_free']:
                    s['gone'] = True
            else:
                if s['sub'] == 0:
                    s['sub'] = 1
                    an.jan = h['mt_anim']
                if s['sub'] == 1 and dy < h['mt_top']:
                    s.update(sub=2, col=7)
                    s['face'] |= 2
                    s['px'] = t8['mt_x'][idx] << 8 | s['px'] & 255
                if s['sub'] == 2:
                    if floors[idx] - (s['py'] >> 8) < h['mt_floor']['want']:
                        bursts.append((f, x16 >> 16, y16 >> 16))
                        s['gone'] = True
                    else:
                        dy = (s['py'] >> 8) - pcy
                        s['vy'] = min(s['vy'] + h['mt_g'], h['mt_max'])
                        if dy >= h['mt_free']:
                            s['gone'] = True
            s['px'] += s['vx']
            s['py'] += s['vy']
            an.face = s['face'] & 1
            an.tick()
            if param == 2 and hits.get(f - 1, 0):
                s['st'] = 4
            vx16, vy16 = ((s['px'] - px0) * 192, -(s['py'] - py0) * 128)
        elif s['st'] == 4:
            vx16 = vy16 = 0
        x16 = x16 + vx16 & 4294967295
        y16 = y16 + vy16 & 4294967295
        out.append((f, dict(s, an=an.state(), x=x16, y=y16)))
    return (out, bursts)
DA8_NAMES = ('cmspawn', 'tkspawn', 'tkhit', 'tkkill', 'tkend', 'shells', 'mortars', 'tushot', 'casings', 'b3shot', 'tkboom', 'ride', 'hullx', 'hully')

def da8(row):
    """A row's step 8 work RAM (lua da8): its counters and the hull's place by name, and the flags."""
    b = bytes(row['da8'])
    v = dict(zip(DA8_NAMES, struct.unpack('>12H2h', b[:28])))
    v.update(hullon=b[28], riding=b[29])
    return v

def tank_checks(dec, steps4, prep, rows, events, frames, dz, limit, pt_frames, pals):
    """Step 8 in a section 4 run, up to frame `limit` (DESERT_ENEMIES.md): the commander, the tank and its four parts, the"""
    import desert_actors_ex as DA
    import desert_ex as DX
    K, h, t8 = (DA.KIND, dec['handlers'], dec['step8'])
    rl = [r for r in rows if r['frame'] < limit]
    by = {r['frame']: r for r in rows}
    fby = {int(r['frame']): r for r in frames}
    active = sorted((r['frame'] for p, r in zip(rows, rows[1:]) if r['rank_t'] != p['rank_t'] and r['frame'] < limit))
    news = [e for e in events if e['what'] == 'new' and e['frame'] < limit]
    gones = [e for e in events if e['what'] == 'gone' and e['frame'] < limit]
    lines = {}
    for e in events:
        if e['what'] == 'a5' and e['frame'] < limit:
            lines.setdefault(e['slot'], []).append(e)

    def life(n):
        end = min((g['frame'] for g in gones if g['slot'] == n['slot'] and g['frame'] > n['frame']), default=limit)
        return ([e for e in lines.get(n['slot'], []) if n['frame'] <= e['frame'] < end], end if end < limit else None)
    out, bad = ({}, [])
    s4 = [r for r in dz if r['sec'] == 4 and r['frame'] < limit]

    def ran(i):
        return next((r['frame'] for r in s4 if r['step'] > i), None)
    ix = {st: i for i, st in reversed(list(enumerate(steps4)))}
    i_pt = ix['portrait', DX.COMMANDER_PORTRAIT]
    i_once = max((i for i, st in enumerate(steps4) if st[0] == 'once'))
    i_wait = next((i for i, st in enumerate(steps4) if st[0] == 'wait'))
    i_clear = next((i for i, st in enumerate(steps4) if st[0] == 'clear'))
    pt_at, go = (ran(i_pt), ran(i_once))
    gof = go if go is not None else 10 ** 9
    pt = [r['frame'] for r in rl if r['pt_on'] == PT_MAGIC and pt_at and (r['frame'] >= pt_at)]
    pt_end = next((r['frame'] for r in rl if pt_at and r['frame'] > pt_at and (r['pt_on'] != PT_MAGIC)), None)
    out['portrait'] = dict(op_at=pt_at, frames=len(pt), want=pt_frames + PT_TAILN - 1, over_at=pt_end, go_at=go, ok=bool(pt) and pt[0] == pt_at and (len(pt) == pt_frames + PT_TAILN - 1) and (pt[-1] - pt[0] + 1 == len(pt)) and (go is not None) and (pt_end <= go <= pt_end + 1))
    want = prep['spawns']['spawn_lists'][4]
    spawn = {kd: (x, y, f, i) for kd, f, i, x, y in want}
    cms = sorted((e for e in news if e['kind'] == K['commander']), key=lambda e: e['frame'])
    cbad, cm = ([], [])
    for n in cms[:1]:
        if (n['x'], n['y'], n['facing'], n['id']) != spawn[K['commander']]:
            cbad.append((n['frame'], 'spawn'))
        ls, end = life(n)
        byf = {e['frame']: e for e in ls}
        first = next((e['frame'] for e in ls if e['st'] != 0), None)
        ups = [f for f in active if f >= first and (end is None or f <= end)]
        cm = commander_model(dec, (n['x'], n['y']), ups, gof)
        for f, s in cm:
            e = byf.get(f)
            if s is None:
                if end != f:
                    cbad.append((f, 'gone', end))
                continue
            got = e and (e['sub'], e['t1'], e['px'], e['py'], e['vxw'], e['x'], e['y'], e['b42'], e['b43'], e['b44'], e['b45'], e['b46'], e['col'])
            wnt = (2 * s['sub'], s['t1'], s['px'] & 4294967295, s['py'] & 4294967295, s['vx'], s['x'], s['y']) + tuple(s['an']) + (0,)
            if got != wnt:
                cbad.append((f, got, wnt))
                break
    out['commander'] = dict(spawned=[e['frame'] for e in cms], frames=len(cm), walked=next((f for f, s in cm if s and s['sub'] == 2), None), gone=cm[-1][0] if cm and cm[-1][1] is None else None, bad=cbad[:3], ok=len(cms) >= 1 and (not cbad))
    sts = [e for e in news if e['kind'] == K['strip']]
    sbad = []
    for n in sts[:1]:
        if (n['x'], n['y'], n['facing'], n['id']) != spawn[K['strip']]:
            sbad.append((n['frame'], 'spawn'))
        ls, _ = life(n)
        first = next((e['frame'] for e in ls if e['b47'] & 1), None)
        x = None
        for e in ls:
            if e['frame'] < first:
                continue
            if (e['frame'] - first) % 2 == 0:
                pcx = pce_camera(int(fby[e['frame'] - 1]['camx']), 0)[0]
                xp = pcx & ~(255 - h['st_x']) | spawn[K['strip']][0] * 2 // 3 & h['st_x2']
                x = xp + (xp >> 1)
            if (e['x'] >> 16, e['y'] >> 16) != (x, n['y']):
                sbad.append((e['frame'], e['x'] >> 16, x))
                break
    out['strip'] = dict(spawned=[e['frame'] for e in sts], bad=sbad[:3], ok=len(sts) >= 1 and (not sbad))
    tks = sorted((e for e in news if e['kind'] == K['tank']), key=lambda e: e['frame'])
    tbad, model, ev, parts = ([], [], None, {})
    riding = {r['frame'] for r in rl if da8(r)['riding']}
    for n in tks[:1]:
        if (n['x'], n['y'], n['facing'], n['id']) != spawn[K['tank']]:
            tbad.append((n['frame'], 'spawn'))
        ls, end = life(n)
        byf = {e['frame']: e for e in ls}
        first = next((e['frame'] for e in ls if e['st'] != 0), None)
        ups = [f for f in active if f >= first and (end is None or f <= end)]
        pnew = sorted((e for e in news if e['kind'] == K['part'] and e['frame'] == first), key=lambda e: e['slot'])
        plines = {}
        for p in pnew:
            for e in life(p)[0]:
                plines.setdefault(e['b42'], {})[e['frame']] = e
            parts[p['slot']] = p
        p3hits = {f: e['hits'] for f, e in plines.get(3, {}).items()}
        model, ev = tank_model(dec, (n['x'], n['y']), ups, gof, frames, riding, p3hits)
        for f, s, ps in model:
            e = byf.get(f)
            if s is None:
                if end != f:
                    tbad.append((f, 'gone', end))
                continue
            if e is None:
                tbad.append((f, 'no line'))
                break
            st = 2 * s['sub'] if s['st'] == 2 else s['sub']
            got = (e['st'], e['sub'], e['t1'], e['t2'], e['px'], e['py'], e['vxw'], e['x'], e['y'], e['b42'], e['b43'], e['b44'], e['b45'], e['b46'], e['b47'], e['l48_raw'], e['l4c_raw'], e['anim'])
            wnt = (s['st'], st, s['t1'], (s['t2'] if s['st'] == 2 else s['vy']) & 65535, s['px'] & 4294967295, s['py'] & 4294967295, s['vx'], s['x'], s['y'], s['cn'], s['tu'], s['tt'], s['aim'], s['fl'], int(s['tick']) | s['white'] << 1, s['mi'] << 24 | s['c0'] << 16 | s['c2'] << 8 | s['c1'], s['tp'] << 24 | s['tr'] << 16 | s['bp'] << 8 | s['bt'], s['colf'])
            if got != wnt:
                tbad.append((f, 'tank', got, wnt))
                break
            for p in ps:
                pe = plines.get(p['pix'], {}).get(f)
                pg = pe and (pe['b43'], pe['b44'], pe['b45'], pe['b46'], pe['b47'], pe['l48_raw'] >> 16, pe['px'], pe['vxw'] & 65535, pe['x'], pe['y'], pe['col'], pe['anim'])
                pw = (p['rm'], p['am'], p['pt'], p['jfr'], p['pfl'] & 255, p['pht'] << 8 | p['ppu'], (p['ppx'] & 65535) << 16 | p['ppy'] & 65535, p['rise'], p['x'], p['y'], p['col'], 2 * p['jfr'])
                if pg != pw:
                    tbad.append((f, 'part', p['pix'], pg, pw))
                    break
            if len(tbad) > 2:
                break
    out['tank'] = dict(spawned=[e['frame'] for e in tks], parts=len(parts), frames=len(model), killed=ev and ev['killed'], end=ev and ev['end'], hits=ev and ev['hits'], bad=tbad[:3], subs=sorted({s['sub'] for _, s, _ in model if s and s['st'] == 2}), ok=len(tks) >= 1 and len(parts) == 4 and (not tbad))
    return (out, model, ev, riding, parts)

def tank_checks2(dec, steps4, prep, rows, events, frames, dz, limit, pals, base, forced=False):
    """The rest of step 8's checks in a section 4 run (tank_checks' parts: base = its out, model, events, riding, parts):"""
    import desert_actors_ex as DA
    import desert_ex as DX
    out, model, ev, riding, parts = base
    K, h, t8 = (DA.KIND, dec['handlers'], dec['step8'])
    rl = [r for r in rows if r['frame'] < limit]
    by = {r['frame']: r for r in rows}
    fby = {int(r['frame']): r for r in frames}
    active = sorted((r['frame'] for p, r in zip(rows, rows[1:]) if r['rank_t'] != p['rank_t'] and r['frame'] < limit))
    news = [e for e in events if e['what'] == 'new' and e['frame'] < limit]
    gones = [e for e in events if e['what'] == 'gone' and e['frame'] < limit]
    lines = {}
    for e in events:
        if e['what'] == 'a5' and e['frame'] < limit:
            lines.setdefault(e['slot'], []).append(e)

    def life(n):
        end = min((g['frame'] for g in gones if g['slot'] == n['slot'] and g['frame'] > n['frame']), default=limit)
        return ([e for e in lines.get(n['slot'], []) if n['frame'] <= e['frame'] < end], end if end < limit else None)
    ev = ev or dict(bullets=[], shells=[], debris=[], killed=None, end=None, hits=[])
    first, last = (rl[0], rl[-1])
    c8 = {k: da8(last)[k] - da8(first)[k] for k in DA8_NAMES[:12]}
    kcut = [a - b for a, b in zip(last['kcut'], first['kcut'])]
    khurt = [a - b for a, b in zip(last['khurt'], first['khurt'])]
    bnew = sorted((e for e in news if e['kind'] == K['bullet']), key=lambda e: (e['frame'], e['slot']))
    got_b, bbad = ([], [])
    for e in bnew:
        ls, _ = life(e)
        got_b.append((e['frame'], e['x'], e['y'], (ls[0]['vx'], ls[0]['vy']) if ls else None))
    for f, x, y, vx, vy in sorted(ev['bullets']):
        m2 = next((b for b in got_b if b[0] == f and b[3] == (vx & 4294967295, vy & 4294967295) and ((b[1], b[2]) in ((x, y), (hiword((x << 16) + vx), hiword((y << 16) + vy))))), None)
        if m2 is None:
            bbad.append((f, x, y, vx, vy))
        else:
            got_b.remove(m2)
    out['bullets'] = dict(model=len(ev['bullets']), fired=c8['tushot'] + c8['b3shot'], unmatched=bbad[:4], extra=[b[:3] for b in got_b][:4], ok=not bbad and (not got_b) and (c8['tushot'] + c8['b3shot'] == len(ev['bullets'])))
    floors = prep['spawns']['mortar_floors']
    snew = sorted((e for e in news if e['kind'] == K['shell']), key=lambda e: (e['frame'], e['slot']))
    want_s = sorted(ev['shells'])
    sbad, made, bursts = ([], {0: 0, 1: 0, 2: 0}, [])
    for n in snew:
        ls, end = life(n)
        if not ls:
            sbad.append((n['frame'], 'no line'))
            continue
        param = ls[0]['l48_raw'] >> 8 & 255
        firstf = next((e['frame'] for e in ls if e['b47'] & 1), None)
        ups = [f for f in active if f >= firstf and (end is None or f <= end)]
        hs = {e['frame']: e['hits'] for e in ls}
        m2 = m = None
        for w in want_s:
            if w[0] != n['frame'] or w[1] != param:
                continue
            m, bu = shell_model(dec, param, w[2:4], w[4:6], w[6], ups, frames, hs, floors)
            on = firstf == n['frame'] and m and (m[0][0] == n['frame']) and m[0][1] and ((n['x'], n['y']) == (m[0][1]['x'] >> 16, m[0][1]['y'] >> 16))
            if (n['x'], n['y']) == (w[2] + (w[2] >> 1), 2047 - w[3]) or on:
                m2 = w
                break
        if m2 is None:
            sbad.append((n['frame'], param, n['x'], n['y'], 'not a modeled spawn'))
            continue
        want_s.remove(m2)
        made[param] += 1
        bursts += bu
        byf = {e['frame']: e for e in ls}
        for f, s in m:
            e = byf.get(f)
            if s is None:
                if end != f:
                    sbad.append((f, param, 'gone', end))
                continue
            got = e and (e['st'], e['sub'], e['px'], e['py'], e['vxw'], e['l48_raw'] >> 16, e['x'], e['y'], e['col'], e['facing'] & 2, e['b42'], e['b43'], e['b44'], e['b45'], e['b46'])
            wnt = (s['st'], 2 * s['sub'], s['px'] & 4294967295, s['py'] & 4294967295, s['vy'], s['vx'] & 65535, s['x'], s['y'], s['col'], s['face'] & 2) + tuple(s['an'])
            if got != wnt:
                sbad.append((f, param, n['slot'], got, wnt))
                break
    out['shells'] = dict(made=made, unmade=[w[:2] for w in want_s][:4], bad=sbad[:4], counters=dict(shells=c8['shells'], casings=c8['casings'], mortars=c8['mortars']), ok=not sbad and made[0] == c8['shells'] and (made[1] == c8['casings']) and (made[2] == c8['mortars']) and all((w[0] >= limit - 2 for w in want_s)))
    out['hits'] = dict(ticks=ev['hits'], counted=c8['tkhit'], part_cuts=kcut[K['part']], tank_cuts=kcut[K['tank']], part_contacts=khurt[K['part']], ok=c8['tkhit'] == len(ev['hits']) and kcut[K['tank']] + kcut[K['commander']] + kcut[K['strip']] == 0 and (khurt[K['part']] + khurt[K['tank']] + khurt[K['commander']] + khurt[K['strip']] == 0) and (forced or kcut[K['part']] >= len(ev['hits'])))
    sc = [(r['frame'], bcd(r['score']) - bcd(p['score'])) for p, r in zip(rl, rl[1:]) if r['score'] != p['score']]
    end = ev['end']
    out['score'] = dict(changes=sc[:4], ok=sc == ([(end, 1500)] if end else []) or (end and sc == [(end + 1, 1500)]))
    must = {}
    for f, _, _ in bursts:
        must[f] = must.get(f, 0) + 1
    deb = {}
    for f, _, _ in ev['debris']:
        deb[f] = deb.get(f, 0) + 1
    delta = {r['frame']: da8(r)['tkboom'] - da8(p)['tkboom'] for p, r in zip(rl, rl[1:]) if da8(r)['tkboom'] != da8(p)['tkboom']}
    dbad = [(f, d, must.get(f, 0), deb.get(f, 0)) for f, d in delta.items() if not must.get(f, 0) <= d <= must.get(f, 0) + deb.get(f, 0)]
    dbad += [(f, 'missing', n2) for f, n2 in must.items() if delta.get(f, 0) < n2]
    dbad += [(f, 'none with room') for f in deb if delta.get(f, 0) <= must.get(f, 0) and by.get(f - 1, {}).get('free6', 0) >= 30]
    out['explosions'] = dict(debris=sum(deb.values()), bursts=len(bursts), made=sum(delta.values()), bad=dbad[:4], ok=not dbad)
    out['death'] = dict(killed=ev['killed'], end=end, counters=(c8['tkkill'], c8['tkend']), ok=(c8['tkkill'], c8['tkend']) == (int(ev['killed'] is not None), int(end is not None)) and (end is None or ev['killed'] is not None))
    hbad, hx = ([], None)
    mx, my = prep['actors']['hull']['map']
    s2x0, s2y0 = (mx, 1023 - my)
    tank_at = {f: s for f, s, _ in model if s}
    for r in rl:
        v, fr = (da8(r), fby.get(r['frame']))
        if r['frame'] in tank_at:
            hx = (tank_at[r['frame']]['x'] >> 16, tank_at[r['frame']]['y'] >> 16)
            hx = tuple(((a + 32768 & 65535) - 32768 for a in hx))
        if hx is None or not v['hullon']:
            continue
        s2 = (int(fr['camx']) - hx[0] + s2x0 & 1023, int(fr['camy']) - hx[1] + s2y0 & 1023)
        if (v['hullx'], v['hully']) != hx or (r['s2x'], r['s2y']) != s2 or (r['s2sx'], r['s2sy']) != s2:
            hbad.append((r['frame'], (v['hullx'], v['hully']), hx, (r['s2x'], r['s2y'], r['s2sx'], r['s2sy']), s2))
    out['hull'] = dict(frames=sum((1 for r in rl if da8(r)['hullon'])), bad=hbad[:4], ok=not hbad and hx is not None)
    rbad, held, prev = ([], 0, None)
    for f, s, _ in model:
        if not s:
            continue
        r, fr, before, prev = (by.get(f), fby.get(f), prev, s)
        if not (r and fr and before):
            continue
        if s['st'] != 2 and da8(r)['riding'] and (f != ev['killed']):
            rbad.append((f, 'held while dying'))
            continue
        tpx, tpy = (before['px'] >> 8, before['py'] >> 8)
        hx_, hy_ = (int(fr['plx']) - (s['step'] if f in riding else 0), int(fr['ply']))
        test = ride_test(dec, hx_, hy_, tpx, tpy) if s['st'] == 2 or f == ev['killed'] else None
        if f in riding:
            held += 1
            kind = DA.RIDE_KINDS[test[1]] if test else None
            if not test or test[0] != 0 or r['hplat'] >> 8 & 3 != 2 or (r['hplat'] & 255 != kind):
                rbad.append((f, 'held', test, hex(r['hplat'])))
        elif test and r['hplat'] >> 8 & 1:
            rbad.append((f, 'not held', test, hex(r['hplat'])))
    out['ride'] = dict(frames=held, counter=c8['ride'], bad=rbad[:4], ok=not rbad and held == c8['ride'])
    white = bytes.fromhex(f"{DA.G.cps_color(h['of_flash_color']):04x}" * 15)
    own10 = b''.join((v.to_bytes(2, 'big') for v in DA.colors(dec['palettes'][10])))[:30]
    cols = [b''.join((DA.G.cps_color(v & 511).to_bytes(2, 'big') for v in (a, b))) for a, b in zip(t8['tr_pen9'], t8['tr_pen14'])]
    hull_cols = list(prep['actors']['hull']['colors'])
    own7 = b''.join((v.to_bytes(2, 'big') for v in DA.colors(dec['palettes'][7])))[:30]
    cm_at = min((e['frame'] for e in events if e['what'] == 'new' and e['kind'] == K['commander']), default=None)
    pbad, wf, tp, writes = ([], False, 0, 0)
    tick_frames = [(f, s) for f, s, _ in model if s and s['tick']]
    tick_of = {}
    for f, s in tick_frames:
        tick_of[f] = s
    for r in rl:
        f = r['frame']
        if f in tick_of:
            wf = tick_of[f]['white']
            if tick_of[f]['tp'] != tp:
                hull_cols[8], hull_cols[13] = (int.from_bytes(cols[tp][i:i + 2], 'big') for i in (0, 2))
                writes += 1
            tp = tick_of[f]['tp']
        slot = bytes(r['pals'][pals['p10']:pals['p10'] + 30])
        if tank_at and min(tank_at) <= f and (slot != (white if wf else own10)):
            pbad.append((f, 'p10', slot.hex()[:12], wf))
        if cm_at and f > cm_at and (bytes(r['pals'][pals['p7']:pals['p7'] + 30]) != own7):
            pbad.append((f, 'p7', bytes(r['pals'][pals['p7']:pals['p7'] + 12]).hex()))
        hslot = bytes(r['pals'][pals['hull']:pals['hull'] + 32])
        if da8(r)['hullon'] and hslot != b''.join((v.to_bytes(2, 'big') for v in hull_cols)):
            pbad.append((f, 'hull', hslot.hex()[:16]))
    out['palettes'] = dict(tread_steps=writes, bad=pbad[:4], ok=not pbad and (writes > 0 or not tick_frames))
    s4 = [r for r in dz if r['sec'] == 4 and r['frame'] < limit]
    i_wait = next((i for i, st in enumerate(steps4) if st[0] == 'wait'))
    reached = next((r['frame'] for r in s4 if r['step'] == i_wait), None)
    passed = next((r['frame'] for r in s4 if r['step'] > i_wait), None)
    i_clear = next((i for i, st in enumerate(steps4) if st[0] == 'clear'))
    clear = next((r['frame'] for r in s4 if r['step'] > i_clear), None)
    mode6 = next((int(r['frame']) for r in frames if r['mode'] == '6' and int(r['frame']) < limit), None)
    dly = steps4[i_wait + 1][1]
    out['section_wait'] = dict(reached=reached, passed=passed, end=end, clear=clear, mode6=mode6, ok=reached is not None and (passed is None if not end else end <= passed <= end + 1) and (clear is None if not passed else clear == passed + dly) and (mode6 is None if not clear else mode6 == clear))
    return out
WAVE_FRAMES = 2700
WAVE_START = (4224, 927)
WAVE_PLAY = 520
WAVE_HOLD, WAVE_SPEED = (150, 4)
WAVE_POINTS = [(4350, 1017), (4350, 1073), (4350, 1129), (4350, 1257), (4350, 1449), (5280, 1647), (5760, 1647), (5955, 1647), (6336, 1647)]
RANK_POKE = 600

def wave_path(points=WAVE_POINTS, hold=WAVE_HOLD, start=WAVE_START, play=WAVE_PLAY, frames=WAVE_FRAMES):
    """The WARP value of the section 2 runs (lua/desert_gate.lua): from WAVE_START at WAVE_PLAY through"""
    (x, y), f, out = (start, play, [])
    for wx, wy in points:
        while (x, y) != (wx, wy):
            x += max(-WAVE_SPEED, min(WAVE_SPEED, wx - x))
            y += max(-WAVE_SPEED, min(WAVE_SPEED, wy - y))
            out.append(f'{f}:{x},{y}')
            f += 1
        for _ in range(hold):
            out.append(f'{f}:{x},{y}')
            f += 1
    if f >= frames:
        raise SystemExit('desert_gate: the warp path outlasts the run')
    return ';'.join(out)
ROBOT_POINTS = [(4700, 1579), (4700, 1622), (5380, 1827)]
ROBOT_HOLD = 420
KILL_POINTS = [(5016, 1756), (5544, 1827), (4860, 1579)]
KILL_HOLD = 300
FLAME_POINTS = [(5340, 1855)] + [(x * 3 // 2, 1679) for x in range(3768, 4281, 128)]
FLAME_HOLD = 140
ACTOR_FRAMES = 3000
JEEP_FRAMES = 3000
JEEP_START = (6744, 927)
JEEP_POINTS = [(7700, 927), (7000, 927)]
JEEP_HOLD, JEEP_AT = (700, 900)
KILL_JEEP_POINTS, KILL_JEEP_HOLD, KILL_JEEP_AT = ([(7000, 927)], 900, 600)
JEEP_KILL_INPUTS = '450-1600@10/3:P1_BUTTON1;1600-3000:P1_JOYSTICK_RIGHT'
JEEP_DEATH_FRAMES = 6800
JEEP_DEATH_HIT = 60
JEEP_HITS = 5
MINE_FRAMES = 2500
MINE_HURT_FRAMES = 1600
MINE_RIGHT = (560, 948)
OFFICER_FRAMES = 4000
OFFICER_KILL_FRAMES = 4200
OFFICER_KILL_INPUTS = '930-960:P1_JOYSTICK_RIGHT;930-4200@10/3:P1_BUTTON1'
OFFICER_RANK_POKE = 600
OFFICER_RANK_T = 7232
OFFICER_PULL_WARP = '935:3759,875'
OFFICER_DEATH_FRAMES = 4200
TANK_FRAMES = 3600
TANK_KILL_FRAMES = 6000
TANK_DEATH_FRAMES = 6000
TANK_RIDE_WARP = '1500:8450,1000'
TANK_KILL_WARP = ';'.join((f'{f}:8388,990' for f in (1400, 1772, 2143, 2515, 2886, 3258, 3629, 4001)))
TANK_KILL_INPUTS = '1410-6000@24/3:P1_BUTTON1'
TANK_HITS_AT = (1400, 1420, 1440, 1460, 1480, 1500, 1520)
GRAIN_FREE = 12

def death_frame(frames):
    return next((int(r['frame']) for r0, r in zip(frames, frames[1:]) if int(r['lives']) < int(r0['lives']) and int(r0['lives']) > 0), None)

def increments(rows, key, index=None):
    """The frames a counter (or a per-kind count) went up on."""

    def v(r):
        return r[key][index] if index is not None else r[key]
    return [r['frame'] for p, r in zip(rows, rows[1:]) if v(r) != v(p)]

def stock_hurts(rows, hurts, death):
    """Per hurt frame: Hiryu's own handler took the bar on the next frame and started 150 frames of"""
    by = {r['frame']: r for r in rows}
    ok = []
    for f in hurts:
        nxt, cur = (by.get(f + 1), by[f])
        fatal = bool(death) and f < death <= f + 600 and (not any((f < g < death for g in hurts)))
        ok.append(bool(nxt) and nxt['damage'] == cur['damage'] + 1 and (nxt['invuln'] in (150, 149) or fatal))
    return ok

def cmd_actors(a):
    """The desert actors (DESERT_ENEMIES.md steps 1-8). Runs, from the debug start in section 0"""
    import desert_actors_ex as DA
    import pce_desert_actors as PA
    import pce_desert_spawns as SP
    work = a.workdir.resolve()
    work.mkdir(parents=True, exist_ok=False)
    binary = json.loads((a.runtime / 'runtime.json').read_text())['binary']
    machine = PARENT[a.set]
    if json.loads((a.build / 'build.json').read_text()).get('boss_scene'):
        import boss_scene_gate as BG
        BG.desert_portraits_variant(a.build.resolve(), work / 'build_desert_portraits')
        a.build = work / 'build_desert_portraits'
    roms = stage_sets(a.build.resolve(), a.set, a.hbmame, a.rom_dir.resolve(), work / 'sets')
    ctl = stage_sets(control_build(a.build.resolve(), a.rom_dir.resolve(), machine, work / 'control'), a.set, a.hbmame, a.rom_dir.resolve(), work / 'sets_control')
    dec = PA.extract(a.desert_census)
    script = SP.decode(sorted(a.desert_census.glob('pce_*_checkpoint_01_ram_0d0000.bin'))[0].read_bytes())
    import desert_ex as DX
    fl = DX.actor_floors(a.desert_census, dec)
    col = DX.pce_collision(a.desert_census, 2)
    sp = DA.spawn_data(dict(decoded=dec), script, fl['rests'], fl['chains'])
    sp['flow'] = DX.flow(script, dec['handlers'])
    col3 = DX.pce_collision(a.desert_census, 3)
    eq = DA.step2_equates(dec['handlers'])
    K = DA.KIND
    keep = {K['mine']: (eq['DA_MN_LEFT'], eq['DA_MN_RIGHT'])}
    n = ACTOR_FRAMES
    mid = '560-700:P1_JOYSTICK_RIGHT'
    mine_in = f'{MINE_RIGHT[0]}-{MINE_RIGHT[1]}:P1_JOYSTICK_RIGHT;{MINE_RIGHT[0]}-{MINE_FRAMES}@20/3:P1_BUTTON1'
    mine_env = dict(debug_env(5, 1, MINE_FRAMES), ACTORS='1', STREX_INPUTS=mine_in)
    hurt_env = dict(debug_env(5, 1, MINE_HURT_FRAMES, invincible=False), ACTORS='1', STREX_INPUTS=mine_in)
    jobs = {'walk': (roms, dict(debug_env(5, 1, n), ACTORS='1'), n), 'jump': (roms, dict(debug_env(5, 1, 4000), ACTORS='1', STREX_INPUTS=mid + ';720-4000@60/14:P1_BUTTON2'), 4000), 'stand': (roms, dict(debug_env(5, 1, 2 * n, invincible=False), ACTORS='1', STREX_INPUTS=mid), 2 * n), 'mine': (roms, mine_env, MINE_FRAMES), 'mine_hurt': (roms, hurt_env, MINE_HURT_FRAMES), 'control': (ctl, dict(debug_env(5, 1, n), ACTORS='1'), n), 'mine_control': (ctl, mine_env, MINE_FRAMES)}
    wn = WAVE_FRAMES
    wave_env = dict(debug_env(5, 3, wn), ACTORS='1', WARP=wave_path(), STREX_INPUTS=f'{WAVE_PLAY}-{wn}@10/3:P1_BUTTON1')
    strip = DA.step3_equates(dec['handlers'], dec['step3'])['DA_RANK_FRAMES']
    jobs.update({'waves': (roms, wave_env, wn), 'strip': (roms, dict(wave_env, STREX_INPUTS='', POKEW=f'{RANK_POKE}:fffac0={strip + 256:04x}'), wn), 'waves_control': (ctl, wave_env, wn), 'drop': (roms, dict(wave_env, STREX_INPUTS='', HITS=';'.join((f"{K['drone']},{k2},30" for k2 in (36, 68)))), wn)})
    jobs.update({'robots': (roms, dict(wave_env, STREX_INPUTS='', WARP=wave_path(ROBOT_POINTS, ROBOT_HOLD)), wn), 'robot_kill': (roms, dict(wave_env, WARP=wave_path(KILL_POINTS, KILL_HOLD)), wn), 'flames': (roms, dict(wave_env, STREX_INPUTS='', WARP=wave_path(FLAME_POINTS, FLAME_HOLD)), wn)})
    jn = JEEP_FRAMES
    jpath = wave_path(JEEP_POINTS, JEEP_HOLD, JEEP_START, JEEP_AT, jn)
    kpath = wave_path(KILL_JEEP_POINTS, KILL_JEEP_HOLD, JEEP_START, KILL_JEEP_AT, jn)
    jobs.update({'jeep': (roms, dict(debug_env(5, 4, jn), ACTORS='1', STREX_INPUTS='', WARP=jpath), jn), 'jeep_kill': (roms, dict(debug_env(5, 4, jn), ACTORS='1', STREX_INPUTS=JEEP_KILL_INPUTS, WARP=kpath), jn), 'jeep_death': (roms, dict(debug_env(5, 4, JEEP_DEATH_FRAMES, invincible=False), ACTORS='1', STREX_INPUTS='', HITS=f"{K['jeep']},1,{JEEP_DEATH_HIT},{JEEP_HITS}"), JEEP_DEATH_FRAMES), 'jeep_control': (ctl, dict(debug_env(5, 4, jn), ACTORS='1', STREX_INPUTS=JEEP_KILL_INPUTS, WARP=kpath), jn)})
    prep = DX.prepare(a.desert_census, a.rom_dir.resolve())
    steps1 = DX.flow(script, dec['handlers'])[1]
    samples = pit_samples(prep)
    cyc = prep['spawns']['cycle'][0]
    pal_env = dict(PALS=','.join((f'{v:x}' for v in (9519104 + 32 * DA.PAL_SLOTS[14], 9519104 + 32 * DA.RUNTIME_SLOTS[7], cyc & ~31))), PIT=','.join((f"{s['off']:x}" for s in samples)))
    pals7 = dict(al_at=0, cyc_at=64 + (cyc & 31))
    SFX['built'] = 'pce_sfx' in json.loads((a.build / 'build.json').read_text())
    pt_frames = next((p['frames'] for p in json.loads((a.build / 'build.json').read_text())['portraits']['portraits'] if p['index'] == DX.OFFICER_PORTRAIT))
    on, kn, dn = (OFFICER_FRAMES, OFFICER_KILL_FRAMES, OFFICER_DEATH_FRAMES)
    jobs.update({'officer': (roms, dict(debug_env(5, 2, on), ACTORS='1', STREX_INPUTS='', **pal_env), on), 'officer_kill': (roms, dict(debug_env(5, 2, kn), ACTORS='1', STREX_INPUTS=OFFICER_KILL_INPUTS, **pal_env), kn), 'officer_rank': (roms, dict(debug_env(5, 2, on), ACTORS='1', STREX_INPUTS='', POKEW=f'{OFFICER_RANK_POKE}:fffac0={OFFICER_RANK_T:04x}', **pal_env), on), 'officer_pull': (roms, dict(debug_env(5, 2, on), ACTORS='1', STREX_INPUTS='', WARP=OFFICER_PULL_WARP, **pal_env), on), 'officer_death': (roms, dict(debug_env(5, 2, dn, invincible=False), ACTORS='1', STREX_INPUTS='', **pal_env), dn), 'officer_control': (ctl, dict(debug_env(5, 2, kn), ACTORS='1', STREX_INPUTS=OFFICER_KILL_INPUTS, **pal_env), kn)})
    steps4 = DX.flow(script, dec['handlers'])[4]
    pal8 = dict(PALS=','.join((f'{v:x}' for v in (9519104 + 32 * DA.PAL_SLOTS[10], 9521152 + 32 * DA.HULL_SLOT, 9519104 + 32 * DA.RUNTIME_SLOTS[7]))))
    pt8 = next((p['frames'] for p in json.loads((a.build / 'build.json').read_text())['portraits']['portraits'] if p['index'] == DX.COMMANDER_PORTRAIT))
    tn = TANK_FRAMES
    jobs.update({'tank': (roms, dict(debug_env(5, 5, tn), ACTORS='1', STREX_INPUTS='', **pal8), tn), 'tank_ride': (roms, dict(debug_env(5, 5, tn), ACTORS='1', STREX_INPUTS='', WARP=TANK_RIDE_WARP, **pal8), tn), 'tank_kill': (roms, dict(debug_env(5, 5, TANK_KILL_FRAMES), ACTORS='1', STREX_INPUTS=TANK_KILL_INPUTS, WARP=TANK_KILL_WARP, **pal8), TANK_KILL_FRAMES), 'tank_hits': (roms, dict(debug_env(5, 5, tn), ACTORS='1', STREX_INPUTS='', HITS=';'.join((f"{K['part']},0,{k}" for k in TANK_HITS_AT)), **pal8), tn), 'tank_death': (roms, dict(debug_env(5, 5, TANK_DEATH_FRAMES, invincible=False), ACTORS='1', STREX_INPUTS='', **pal8), TANK_DEATH_FRAMES), 'tank_control': (ctl, dict(debug_env(5, 5, tn), ACTORS='1', STREX_INPUTS='', HITS=';'.join((f"{K['part']},0,{k}" for k in TANK_HITS_AT)), **pal8), tn)})
    walk_only = f'450-{n}@300/220:P1_JOYSTICK_RIGHT'
    second = 128 | sp4_arches(sp, K) - 1 << 1 | 1
    jobs.update({'worm': (roms, dict(debug_env(5, 1, n), ACTORS='1', STREX_INPUTS=walk_only), n), 'worm_kill': (roms, dict(debug_env(5, 1, n), ACTORS='1', STREX_INPUTS=walk_only, HITS=f"{K['worm']},{second},6,2"), n)})
    with ThreadPoolExecutor(a.jobs) as ex:
        res = dict(zip(jobs, ex.map(lambda k: run(binary, jobs[k][0], a.set, work / 'runs' / k, *jobs[k][1:]), jobs)))
    acts = {k: read_actors(work / 'runs' / k) for k in jobs}
    controls = ('control', 'mine_control')
    inits = {K['soldier']: 'spawned', K['bazooka']: 'bz_spawned', K['mine']: 'mn_spawned', K['drone']: 'dr_spawned'}

    def checks(k):
        frames, (rows, events) = (res[k], acts[k])
        play = first(frames, lambda r: r['stage'] == '5' and r['mode'] == '4')
        c = dict(play_at=play)
        gens = [e for e in events if e['what'] == 'new' and e['kind'] == 4]
        want_g = sorted(((x, y, f) for _, f, i, x, y in sp['generators']))
        got_g = sorted({(e['x'], e['y'], e['facing']) for e in gens})
        c['generators'] = dict(want=want_g, got=got_g, ok=bool(gens) and got_g == want_g)
        ml = {i: (kd, x, y, f) for kd, f, i, x, y in sp['map_lists'][0] if kd != K['item']}
        new = [e for e in events if e['what'] == 'new']
        placed = [e for e in new if e['id'] in ml and e['kind'] == ml[e['id']][0]]
        bad_ml = [e for e in placed if (e['x'], e['y'], e['facing']) != ml[e['id']][1:]]
        death = death_frame(frames)
        limit = death if death else int(frames[-1]['frame'])
        firsts = {}
        for e in placed:
            if e['frame'] < limit:
                firsts.setdefault(e['id'], e['frame'])
        scan0 = min((e['frame'] for e in gens), default=None)
        model = map_list_model([r for r in frames if int(r['frame']) < limit], [r for r in sp['map_lists'][0] if r[0] != K['item']], scan0, keep) if scan0 else {}
        times = {i: sum((1 for e in placed if e['id'] == i and e['frame'] < limit)) for i in firsts}
        loops = {i: v for i, v in times.items() if v > 2 and ml[i][0] != K['mine']}
        c['map_list'] = dict(spawned={DA.KINDS[kd]['name']: sum((1 for e in placed if e['kind'] == kd)) for kd in sorted({v[0] for v in ml.values()})}, first=firsts, model=model, spawns_per_id=times, wrong_place=bad_ml[:5], ok=bool(firsts) and (not bad_ml) and (firsts == model) and (not loops))
        soldiers = [e for e in new if e['kind'] == 0]
        gl = {i: [(x, y) for _, f, gi, x, y in sp['generators'] if i in dec['generator']['ids'][f]] for ids in dec['generator']['ids'] for i in ids}
        gsold = [e for e in soldiers if e['id'] in gl]
        bad_g = [e for e in gsold if not any((abs(e['x'] - x) <= 3 and abs(e['y'] - y) <= 13 for x, y in gl[e['id']]))]
        c['generator_soldiers'] = dict(spawned=len(gsold), wrong_place=bad_g[:5], ok=not bad_g)
        c['slots'] = dict(bad_frames=[r['frame'] for r in rows if r['frame'] >= (play or 0) and r['free5'] + r['active5'] != 30][:5])
        c['slots']['inits'] = {DA.KINDS[kd]['name']: rows[-1][col] for kd, col in inits.items()}
        c['slots']['spawns_logged'] = {DA.KINDS[kd]['name']: sum((1 for e in new if e['kind'] == kd)) for kd in inits}
        c['slots']['ok'] = not c['slots']['bad_frames'] and all((rows[-1][col] == (0 if k in controls else c['slots']['spawns_logged'][DA.KINDS[kd]['name']]) for kd, col in inits.items()))
        last = rows[-1]
        c['counters'] = {k2: last[k2] for k2 in ('spawned', 'killed', 'hurt', 'fired', 'cuts', 'bz_spawned', 'bz_killed', 'rockets', 'mn_spawned', 'mn_warn', 'mn_blast', 'khurt', 'kcut', 'dr_spawned', 'dr_killed', 'wv_spawned', 'caps', 'capfull', 'strip')}
        c.update(step3_checks(0, sp, dec, rows, events, frames, limit))
        c.update(worm_checks(sp, dec, rows, events, frames, limit))
        return (c, rows, events, frames)

    def fire(k, c, rows, events, frames):
        """The bazooka soldier's rockets against fire_model, per bazooka life up to the first death."""
        death = death_frame(frames)
        end = death if death else int(frames[-1]['frame'])
        new = sorted((e for e in events if e['what'] == 'new'), key=lambda e: e['frame'])
        gone = [e for e in events if e['what'] == 'gone']
        hx = {int(r['frame']): int(r['plx']) for r in frames}
        lives, bad = ([], [])
        for b in (e for e in new if e['kind'] == K['bazooka'] and e['frame'] < end):
            g = min((e['frame'] for e in gone if e['slot'] == b['slot'] and e['frame'] > b['frame']), default=end + 1)
            g = min(g, end)
            if g - b['frame'] < 2 * eq['DA_BZ_AIM'] + 8:
                continue
            want = fire_model(frames, b['frame'], g, b['x'], b['y'], eq)
            rk = [e for e in new if e['kind'] == K['rocket'] and b['frame'] < e['frame'] < g]
            got = [e['frame'] for e in rk]
            step = eq['DA_RK_VX'] >> 16
            for e in rk:
                left = hx.get(e['frame'] - 1, 0) < b['x']
                d = -1 if left else 1
                want_x = b['x'] + d * eq['DA_BZ_RDX']
                if not (e['x'] in (want_x, want_x + d * step) and (e['y'], e['facing']) == (b['y'] + eq['DA_BZ_RDY'], int(left))):
                    bad.append(e)
            lives.append(dict(spawn=b['frame'], end=g, rockets=got, model=want, ok=got == want))
        c['fire'] = dict(lives=lives, rockets=sum((len(x['rockets']) for x in lives)), wrong_rockets=bad[:5], rocket_counter=rows[-1]['rockets'])
        c['fire']['ok'] = bool(lives) and c['fire']['rockets'] > 0 and all((x['ok'] for x in lives)) and (not bad)
    rep = {}
    w, rows, events, frames = checks('walk')
    kills_scored = max((r['killed'] for r in rows if r['frame'] <= rows[-1]['frame'] - 10), default=0)
    bz_scored = max((r['bz_killed'] for r in rows if r['frame'] <= rows[-1]['frame'] - 10), default=0)
    dr_scored = max((r['dr_killed'] for r in rows if r['frame'] <= rows[-1]['frame'] - 10), default=0)
    sw_scored = max((r['sw_kill'] for r in rows if r['frame'] <= rows[-1]['frame'] - 10), default=0)
    cap_points = capsule_points(events, rows[-1]['frame'] - 2)
    s0 = next((bcd(r['score']) for r in rows if r['frame'] >= (w['play_at'] or 0)), 0)
    w['score'] = dict(at_play=s0, end=bcd(rows[-1]['score']), kills_scored=kills_scored, bazooka_kills_scored=bz_scored, drone_kills_scored=dr_scored, worm_kills_scored=sw_scored, capsule_points=cap_points, ok=kills_scored > 0 and bz_scored > 0 and (bcd(rows[-1]['score']) - s0 == 100 * kills_scored + 200 * bz_scored + 300 * dr_scored + 400 * sw_scored + cap_points))
    w['cuts'] = dict(cuts=rows[-1]['cuts'], killed=rows[-1]['killed'], bazooka_killed=rows[-1]['bz_killed'], bazooka_cuts=rows[-1]['kcut'][K['bazooka']], mine_cuts=rows[-1]['kcut'][K['mine']], ok=rows[-1]['cuts'] >= rows[-1]['killed'] + rows[-1]['bz_killed'] > 0 and rows[-1]['kcut'][K['bazooka']] >= rows[-1]['bz_killed'] > 0 and (rows[-1]['kcut'][K['mine']] == 0))
    script0 = [o['kind'] for o in dec['step3']['waves'][0] if o['op'].startswith('spawn')]
    w['expect3'] = dict(kinds=[k2 for _, k2 in w['waves']['got']], want=script0, capsules=len(w['capsules']['spawned']), want_capsules=len(w['capsules']['model']), ok=[k2 for _, k2 in w['waves']['got']] == script0 and w['drones']['killed'] > 0 and (len(w['capsules']['spawned']) == len(w['capsules']['model']) > 0))
    w['passed'] = all((w[k]['ok'] for k in ('generators', 'map_list', 'generator_soldiers', 'slots', 'score', 'cuts', 'capsules', 'waves', 'drones', 'carried', 'expect3', 'worms')))
    rep['walk'] = w
    j, rows, events, frames = checks('jump')
    new = [e for e in events if e['what'] == 'new']
    grenades = [e for e in new if e['kind'] == 2]
    smoked = [g for g in grenades if any((e['kind'] == 3 and g['frame'] <= e['frame'] <= g['frame'] + 6 for e in new))]
    j['shots'] = dict(fired=rows[-1]['fired'], bullets=sum((1 for e in new if e['kind'] == 1)), grenades=len(grenades), grenades_with_smoke=len(smoked), smoke=sum((1 for e in new if e['kind'] == 3)))
    j['shots']['ok'] = j['shots']['bullets'] > 0 and j['shots']['grenades'] > 0 and (len(smoked) == len(grenades)) and (j['shots']['fired'] == j['shots']['bullets'] + j['shots']['grenades'])
    fire('jump', j, rows, events, frames)
    j['passed'] = all((j[k]['ok'] for k in ('generators', 'map_list', 'slots', 'shots', 'fire')))
    rep['jump'] = j
    s, rows, events, frames = checks('stand')
    hurts = increments(rows, 'hurt')
    lives = [int(r['lives']) for r in frames]
    death = death_frame(frames)
    stock_path = stock_hurts(rows, hurts, death)
    replay = first(frames, lambda r: r['stage'] == '5' and r['mode'] == '4', death or 0) if death else None
    before = {e['slot'] for e in events if e['what'] == 'new' and e['frame'] < (death or 0)}
    alive_at_replay = set()
    for e in sorted((e for e in events if e['what'] in ('new', 'gone')), key=lambda e: e['frame']):
        if replay and e['frame'] <= replay:
            if e['what'] == 'new':
                alive_at_replay.add((e['slot'], e['frame']))
            else:
                alive_at_replay = {x for x in alive_at_replay if x[0] != e['slot']}
    kept = [x for x in alive_at_replay if x[1] < (death or 0)]
    regen = [e for e in events if e['what'] == 'new' and e['kind'] == 4 and death and (e['frame'] > death)]
    s['hurt'] = dict(hurts=len(hurts), via_stock_path=sum(stock_path), by_kind=rows[-1]['khurt'], ok=bool(hurts) and all(stock_path) and (rows[-1]['khurt'][K['rocket']] > 0))
    s['respawn'] = dict(death_at=death, replay_at=replay, actors_before=len(before), kept_over_death=kept[:5], generators_again=len(regen), lives_min=min(lives) if lives else None, ok=bool(death and replay) and (not kept) and (len(regen) == len(sp['generators'])))
    fire('stand', s, rows, events, frames)
    s['passed'] = all((s[k]['ok'] for k in ('generators', 'map_list', 'generator_soldiers', 'slots', 'hurt', 'respawn', 'fire')))
    rep['stand'] = s

    def mine_checks(k, c, rows, events, frames):
        """The mine runs' behavior (see the docstring); hurt: the run without invincibility."""
        mk = K['mine']
        mines = {i: (x, y, f) for kd, f, i, x, y in sp['map_lists'][0] if kd == mk}
        warns, blasts = (increments(rows, 'mn_warn'), increments(rows, 'mn_blast'))
        hurts = increments(rows, 'khurt', mk)
        death = death_frame(frames)
        pos = {int(r['frame']): (int(r['plx']), int(r['ply'])) for r in frames}
        new = [e for e in events if e['what'] == 'new' and e['kind'] == mk]

        def over(f):
            """the id of the mine Hiryu is over (its trigger box) as logged on frame f - 1 or f"""
            for g in (f - 1, f):
                if g not in pos:
                    continue
                hx, hy = pos[g]
                for i, (x, y, fc) in mines.items():
                    cx = x - eq['DA_MN_DX'] if fc else x + eq['DA_MN_DX']
                    if abs(hx - cx) < eq['DA_MN_TOLX'] and abs(y - hy - eq['DA_MN_DY']) < eq['DA_MN_TOLY']:
                        return i
            return None
        warn_t, blast_t = (2 * eq['DA_MN_WARN'], 2 * eq['DA_MN_BLAST'])
        cycle = warn_t + blast_t
        rearms = sum((1 for p, q in zip(warns, warns[1:]) if q - p == cycle))
        windows = [(b, b + blast_t) for b in blasts]
        mhurts = list(hurts)
        path = stock_hurts(rows, mhurts, death) if k == 'mine_hurt' else []
        used = over(warns[0]) if warns else None
        gone = [e for e in events if e['what'] == 'gone' and e['kind'] == mk and (e['id'] == used) and (warns[0] < e['frame'] < (death or int(frames[-1]['frame'])))]
        c['mine'] = dict(spawned=[(e['id'], e['x'], e['y'], e['facing']) for e in new][:6], warnings=len(warns), first_warnings=warns[:6], blasts=len(blasts), rearms=rearms, mine_used=used, warnings_with_hiryu_over=sum((1 for x in warns if over(x) is not None)), blasts_after_warnings=sum((1 for b in blasts if b - warn_t in warns)), hurts=mhurts[:8], n_hurts=len(mhurts), hurts_in_blasts=sum((1 for h in mhurts if any((lo <= h < hi for lo, hi in windows)))), via_stock_path=sum(path), death_at=death, mine_cuts=rows[-1]['kcut'][mk], cuts=rows[-1]['cuts'], mine_gone_while_used=len(gone))
        m = c['mine']
        m['ok'] = m['warnings'] >= 1 and m['warnings_with_hiryu_over'] == m['warnings'] and (m['blasts'] > 0) and (m['blasts_after_warnings'] == m['blasts']) and (len(mhurts) > 0) and (m['hurts_in_blasts'] == len(mhurts)) and (m['mine_cuts'] == 0)
        if k == 'mine_hurt':
            m['ok'] &= bool(path) and all(path) and (0 <= mhurts[0] - blasts[0] <= 1)
        else:
            m['ok'] &= m['warnings'] >= 3 and m['rearms'] >= 2 and (not gone)
    for k in ('mine', 'mine_hurt'):
        mn, rows, events, frames = checks(k)
        mine_checks(k, mn, rows, events, frames)
        mn['passed'] = all((mn[k2]['ok'] for k2 in ('generators', 'map_list', 'slots', 'mine')))
        rep[k] = mn

    def checks2(k):
        """A section 2 wave run: step3_checks up to a death, and pool 5's slots."""
        frames, (rows, events) = (res[k], acts[k])
        death = death_frame(frames)
        limit = death if death else int(frames[-1]['frame']) + 1
        c = dict(play_at=first(frames, lambda r: r['stage'] == '5' and r['mode'] == '4'), death_at=death)
        c.update(step3_checks(2, sp, dec, rows, events, frames, limit))
        if k != 'waves_control':
            c.update(step5_checks(2, sp, dec, col, rows, events, frames, limit))
        new = [e for e in events if e['what'] == 'new']
        c['slots'] = dict(bad_frames=[r['frame'] for r in rows if r['frame'] >= (c['play_at'] or 0) and r['free5'] + r['active5'] != 30][:5], drones_started=rows[-1]['dr_spawned'], drones_logged=sum((1 for e in new if e['kind'] == K['drone'])))
        c['slots']['ok'] = not c['slots']['bad_frames'] and c['slots']['drones_started'] == (0 if k == 'waves_control' else c['slots']['drones_logged'])
        return (c, rows, events, frames)
    script1 = [o['kind'] for o in dec['step3']['waves'][1] if o['op'].startswith('spawn')]
    wv, rows, events, frames = checks2('waves')
    dr_scored = max((r['dr_killed'] for r in rows if r['frame'] <= rows[-1]['frame'] - 10), default=0)
    s0 = next((bcd(r['score']) for r in rows if r['frame'] >= (wv['play_at'] or 0)), 0)
    pts = capsule_points(events, rows[-1]['frame'] - 2)
    rb_scored = max((r['rb_killed'] for r in rows if r['frame'] <= rows[-1]['frame'] - 14), default=0)
    wv['score'] = dict(at_play=s0, end=bcd(rows[-1]['score']), drone_kills_scored=dr_scored, robot_kills_scored=rb_scored, capsule_points=pts, ok=dr_scored > 0 and bcd(rows[-1]['score']) - s0 == 300 * dr_scored + 300 * rb_scored + pts)
    wv['expect'] = dict(kinds=[k2 for _, k2 in wv['waves']['got']], want=script1, carried=len(wv['carried']['capsules']), ok=[k2 for _, k2 in wv['waves']['got']] == script1 and (not wv['death_at']) and (len(wv['carried']['capsules']) == sum((1 for k2 in script1 if k2 >> 4))))
    wv['passed'] = all((wv[k2]['ok'] for k2 in ('capsules', 'waves', 'drones', 'carried', 'slots', 'score', 'expect', 'robots', 'beams', 'flames', 'spawns5')))
    rep['waves'] = wv
    st3, rows, events, frames = checks2('strip')
    stripped = [k2 & dec['handlers']['wm_rank_mask'] for k2 in script1]
    st3['expect'] = dict(kinds=[k2 for _, k2 in st3['waves']['got']], want=stripped, strip_counter=rows[-1]['strip'], carried=len(st3['carried']['capsules']), drone_contacts=rows[-1]['khurt'][K['drone']], ok=[k2 for _, k2 in st3['waves']['got']] == stripped and rows[-1]['strip'] == sum((1 for k2 in script1 if k2 >> 4)) > 0 and (not st3['carried']['capsules']) and (rows[-1]['khurt'][K['drone']] > 0))
    st3['passed'] = all((st3[k2]['ok'] for k2 in ('capsules', 'waves', 'drones', 'carried', 'slots', 'expect', 'robots', 'beams', 'flames', 'spawns5')))
    rep['strip'] = st3
    dp, rows, events, frames = checks2('drop')
    cc = dp['carried']['capsules']
    dp['expect'] = dict(carried=cc, drones_killed=rows[-1]['dr_killed'], ok=len(cc) == 2 and all((c2['fell'] and (not c2['opened']) for c2 in cc)) and cc[0]['landed'] and (rows[-1]['dr_killed'] == 2))
    dp['passed'] = all((dp[k2]['ok'] for k2 in ('capsules', 'waves', 'drones', 'carried', 'slots', 'expect', 'robots', 'beams', 'flames', 'spawns5')))
    rep['drop'] = dp
    rb, rows, events, frames = checks2('robots')
    fired = {b['robot'] for b in rb['beams']['lives']}
    rb['expect'] = dict(fired_by=sorted(fired), beams=len(rb['beams']['lives']), segment_contacts=rb['beams']['contacts'], ok=len(fired) == 3 and rb['beams']['contacts'] > 0 and (not rb['death_at']))
    rb['passed'] = all((rb[k2]['ok'] for k2 in ('waves', 'drones', 'slots', 'expect', 'robots', 'beams', 'flames', 'spawns5')))
    rep['robots'] = rb
    rk, rows, events, frames = checks2('robot_kill')
    s0 = next((bcd(r['score']) for r in rows if r['frame'] >= (rk['play_at'] or 0)), 0)
    dr_scored = max((r['dr_killed'] for r in rows if r['frame'] <= rows[-1]['frame'] - 10), default=0)
    rb_scored = max((r['rb_killed'] for r in rows if r['frame'] <= rows[-1]['frame'] - 14), default=0)
    pts = capsule_points(events, rows[-1]['frame'] - 2)
    rk['expect'] = dict(killed=rows[-1]['rb_killed'], robot_kills_scored=rb_scored, drone_kills_scored=dr_scored, capsule_points=pts, score=bcd(rows[-1]['score']) - s0, robot_contacts=rk['robots']['contacts'], robot_cuts=rk['robots']['cuts'], ok=rows[-1]['rb_killed'] == rb_scored == 3 and rk['robots']['contacts'] > 0 and (rk['robots']['cuts'] > 0) and (bcd(rows[-1]['score']) - s0 == 300 * (rb_scored + dr_scored) + pts))
    rk['passed'] = all((rk[k2]['ok'] for k2 in ('waves', 'drones', 'slots', 'expect', 'robots', 'beams', 'flames', 'spawns5')))
    rep['robot_kill'] = rk
    fm, rows, events, frames = checks2('flames')
    fm['expect'] = dict(flames=len(fm['flames']['lives']), contacts=len(increments(rows, 'khurt', K['flame'])), ok=len(fm['flames']['lives']) == 6 and fm['flames']['contacts'] != [] and (not fm['death_at']))
    fm['passed'] = all((fm[k2]['ok'] for k2 in ('waves', 'drones', 'slots', 'expect', 'robots', 'beams', 'flames', 'spawns5')))
    rep['flames'] = fm
    for k in ('worm', 'worm_kill'):
        wr, rows, events, frames = checks(k)
        sws = wr['worms']['arches']
        s0 = next((bcd(r['score']) for r in rows if r['frame'] >= (wr['play_at'] or 0)), 0)
        kill = rows[-1]['sw_kill']
        if k == 'worm':
            wr['expect'] = dict(heads=sorted(sws), arches={i: len(v) for i, v in sws.items()}, killed=kill, floor_ends=rows[-1]['sw_end'], stopped=rows[-1]['sw_stop'], ok=sorted(sws) == [9, 11] and all((len(v) > 1 for v in sws.values())) and (kill == 0) and (rows[-1]['sw_end'] >= 1))
        else:
            died = [a for a in sws.get(11, []) if a[2] is not None]
            wr['expect'] = dict(arches=sws.get(11), killed=kill, score=bcd(rows[-1]['score']) - s0, ok=kill >= 2 and len(sws.get(11, [])) == 2 and (bcd(rows[-1]['score']) - s0 == 400 * kill))
        wr['passed'] = all((wr[k2]['ok'] for k2 in ('generators', 'map_list', 'slots', 'worms', 'expect')))
        rep[k] = wr

    def checks3(k):
        """A section 3 run: jeep_checks up to a death, and pool 5's slots."""
        frames, (rows, events) = (res[k], acts[k])
        death = death_frame(frames)
        limit = death if death else int(frames[-1]['frame']) + 1
        dz = read_desert(work / 'runs' / k)
        c = dict(play_at=first(frames, lambda r: r['stage'] == '5' and r['mode'] == '4'), death_at=death)
        c.update(jeep_checks(3, sp, dec, col3, rows, events, frames, limit, dz))
        c['slots'] = dict(bad_frames=[r['frame'] for r in rows if r['frame'] >= (c['play_at'] or 0) and r['free5'] + r['active5'] != 30][:5])
        c['slots']['ok'] = not c['slots']['bad_frames']
        return (c, rows, events, frames, dz)
    s0j = lambda rows, c: next((bcd(r['score']) for r in rows if r['frame'] >= (c['play_at'] or 0)), 0)
    jp, rows, events, frames, dz = checks3('jeep')
    lv = jp['jeeps']['lives']
    jp['expect'] = dict(lives=len(lv), subs=lv[0]['subs'] if lv else None, bullets=jp['gunner_bullets']['model'], contacts=jp['jeeps']['contacts'], score=bcd(rows[-1]['score']) - s0j(rows, jp), ok=len(lv) == 1 and (not lv[0]['killed']) and ({2, 3, 4, 6, 7} <= set(lv[0]['subs'])) and (jp['gunner_bullets']['model'] >= 6) and (jp['jeeps']['contacts'] > 0) and (not jp['death_at']) and (jp['section_wait']['passed'] is None) and (bcd(rows[-1]['score']) == s0j(rows, jp)))
    jp['passed'] = all((jp[k2]['ok'] for k2 in ('jeeps', 'gunner_bullets', 'explosions', 'section_wait', 'slots', 'expect')))
    rep['jeep'] = jp
    jk, rows, events, frames, dz = checks3('jeep_kill')
    lv = jk['jeeps']['lives']
    sec4 = next((r['frame'] for r in dz if r['sec'] == 4), None)
    sc4 = next((bcd(r['score']) for r in rows if r['frame'] == sec4), 0) - s0j(rows, jk)
    jk['expect'] = dict(killed=[x['killed'] for x in lv], hits=[x['hits'] for x in lv], cuts=jk['jeeps']['cuts'], contacts=jk['jeeps']['contacts'], end=[x['end'] for x in lv], score_to_section4=sc4, section4_at=sec4, wreck_gone=[x['gone'] for x in lv], ok=len(lv) == 1 and bool(lv[0]['killed'] and lv[0]['end'] and lv[0]['wreck']) and (jk['jeeps']['cuts'] > 0) and (lv[0]['gunner_gone'] is not None) and (sc4 == 500) and (sec4 is not None) and (sec4 > lv[0]['end']) and (lv[0]['gone'] is not None))
    jk['passed'] = all((jk[k2]['ok'] for k2 in ('jeeps', 'gunner_bullets', 'explosions', 'section_wait', 'slots', 'expect')))
    rep['jeep_kill'] = jk
    jd, rows, events, frames, dz = checks3('jeep_death')
    death = jd['death_at']
    again = [e for e in events if e['what'] == 'new' and e['kind'] == K['jeep'] and death and (e['frame'] > death)]
    rewait = [r for r in dz if death and r['frame'] > death and (r['sec'] == 3)]
    wait_at = jd['section_wait']['step']
    end2 = [f for f in increments(rows, 'jp_end') if death and f > death]
    pass2 = next((r['frame'] for r in rewait if r['step'] > wait_at), None)
    jd['expect'] = dict(first_end=[x['end'] for x in jd['jeeps']['lives']], passed=jd['section_wait']['passed'], death_at=death, jeep_again=[e['frame'] for e in again], second_end=end2, second_pass=pass2, steps_after=[(r['frame'], r['step']) for r in rewait][:8], ok=bool(jd['jeeps']['lives'] and jd['jeeps']['lives'][0]['end'] and jd['section_wait']['passed'] and death and (len(again) == 1) and any((r['step'] == wait_at for r in rewait)) and (pass2 is None or (end2 and end2[0] <= pass2 <= end2[0] + 1)) and all((r['step'] <= wait_at for r in rewait if pass2 is None or r['frame'] < pass2))))
    jd['passed'] = all((jd[k2]['ok'] for k2 in ('jeeps', 'gunner_bullets', 'explosions', 'section_wait', 'slots', 'expect')))
    rep['jeep_death'] = jd

    def read_pit(out):
        """pit.tsv: [(frame, [(display entry, collision entry) per sample])], and the cells shown at a frame."""
        lines = (out / 'pit.tsv').read_text().splitlines()[1:]
        got = [(int(f), [tuple(c.split(',')) for c in v.split(';')]) for f, v in (ln.split('\t') for ln in lines)]

        def at(fr):
            return next((v for f, v in reversed(got) if f <= fr), None)
        return dict(rows=got, at=at, samples=samples)

    def checks7(k, still, lo=0, hi=None):
        """A section 1 run from frame lo up to a death (or hi): officer_checks, and pool 5's slots."""
        frames, (rows, events) = (res[k], acts[k])
        frames = [r for r in frames if int(r['frame']) >= lo]
        death = death_frame(frames)
        limit = min((v for v in (death, hi, int(frames[-1]['frame']) + 1) if v))
        dz = [r for r in read_desert(work / 'runs' / k) if r['frame'] >= lo]
        pit = read_pit(work / 'runs' / k)
        rows = [r for r in rows if r['frame'] >= lo]
        events = [e for e in events if e['frame'] >= lo]
        c = dict(play_at=first(frames, lambda r: r['stage'] == '5' and r['mode'] == '4'), death_at=death)
        c.update(officer_checks(dec, steps1, prep, rows, events, frames, dz, pit, limit, pt_frames, pals7, still))
        c['slots'] = dict(bad_frames=[r['frame'] for r in rows if r['frame'] >= (c['play_at'] or 0) and r['free5'] + r['active5'] != 30][:5])
        c['slots']['ok'] = not c['slots']['bad_frames']
        return (c, rows, events, frames, dz)
    every7 = ('portrait', 'officers', 'hits', 'projectiles', 'pull', 'pit', 'section_wait', 'score', 'debris', 'pan', 'drag', 'slots')
    of, rows, events, frames, dz = checks7('officer', 0)
    lv = of['officers']['lives']
    of['expect'] = dict(lives=len(lv), actions=lv[0]['actions'] if lv else None, rounds=of['projectiles']['rounds'], balls=of['projectiles']['made']['ball'], needles=of['projectiles']['made']['needle'], pan=of['pan']['frames'], pull_ticks=of['pull']['ticks'], ok=len(lv) == 1 and lv[0]['go_seen'] is not None and (not lv[0]['death']) and (set(lv[0]['actions']) == {0, 1, 2, 3, 4}) and (lv[0]['ranks'] == [6]) and (of['projectiles']['made']['needle'] > 0) and (of['pan']['frames'] > 0) and (of['section_wait']['passed'] is None) and (not of['death_at']))
    of['passed'] = all((of[k2]['ok'] for k2 in every7 + ('expect',)))
    rep['officer'] = of
    ok_, rows, events, frames, dz = checks7('officer_kill', None)
    lv = ok_['officers']['lives']
    ok_['expect'] = dict(hits=ok_['hits'], death=[x['death'] for x in lv], end=[x['end'] for x in lv], score=ok_['score']['changes'], passed=ok_['section_wait']['passed'], debris=ok_['debris'], ok=len(lv) == 1 and len(ok_['hits']['ticks']) == dec['handlers']['of_hits'] and bool(lv[0]['end']) and (ok_['section_wait']['passed'] is not None) and (ok_['debris']['made'] > 0) and (ok_['officers']['cuts'] > 0) and (not ok_['death_at']))
    ok_['passed'] = all((ok_[k2]['ok'] for k2 in every7 + ('expect',)))
    rep['officer_kill'] = ok_
    orank, rows, events, frames, dz = checks7('officer_rank', 0)
    lv = orank['officers']['lives']
    orank['expect'] = dict(rank_t=rows[-1]['rank_t'], actions=lv[0]['actions'] if lv else None, ranks=lv[0]['ranks'] if lv else None, ok=len(lv) == 1 and rows[-1]['rank_t'] > OFFICER_RANK_T and (lv[0]['ranks'][:1] == [11]))
    orank['passed'] = all((orank[k2]['ok'] for k2 in every7 + ('expect',)))
    rep['officer_rank'] = orank
    warped = int(OFFICER_PULL_WARP.split(':')[0]) + 1
    op, rows, events, frames, dz = checks7('officer_pull', warped)
    op['expect'] = dict(drag=op['drag']['frames'], ok=op['drag']['frames'] > 0 and (not op['death_at']))
    op['passed'] = all((op[k2]['ok'] for k2 in every7 + ('expect',)))
    rep['officer_pull'] = op
    od, rows, events, frames, dz = checks7('officer_death', 0)
    death = od['death_at']
    od2 = None
    if death:
        back = next((e['frame'] for e in acts['officer_death'][1] if e['what'] == 'new' and e['kind'] == K['officer'] and (e['frame'] > death)), None)
        if back:
            od2, rows2, _, _, dz2 = checks7('officer_death', 0, lo=back - 1)
            od2['respawn'] = dict(officer_at=back, steps=[(r['frame'], r['step'], r['map']) for r in dz2][:4], ok=dz2 != [] and dz2[0]['sec'] == 1 and (dz2[0]['map'] == DX.S1_WORLD) and (not rows2[0]['da6'][24]))
    od['expect'] = dict(death_at=death, second=od2, ok=bool(death) and od2 is not None and od2['respawn']['ok'] and all((od2[k2]['ok'] for k2 in ('portrait', 'officers', 'projectiles', 'pull', 'pit', 'pan'))))
    od['passed'] = all((od[k2]['ok'] for k2 in every7 + ('expect',)))
    rep['officer_death'] = od
    frames, (rows, events) = (res['officer_control'], acts['officer_control'])
    dzc = read_desert(work / 'runs' / 'officer_control')
    wait7 = next((i for i, st in enumerate(steps1) if st[0] == 'wait'))
    rep['officer_control'] = dict(da6=rows[-1]['da6'][:24], steps=sorted({r['step'] for r in dzc if r['sec'] == 1}), fails=not any(rows[-1]['da6'][:24]) and bcd(rows[-1]['score']) == 0 and (not any((r['sec'] == 1 and r['step'] > wait7 for r in dzc))))

    def checks8(k, lo=0, forced=False):
        """A section 4 run from frame lo up to a death or the stage's clear (its mode 6: the bonus and the next stage"""
        frames, (rows, events) = (res[k], acts[k])
        frames = [r for r in frames if int(r['frame']) >= lo]
        death = death_frame(frames)
        limit = death if death else int(frames[-1]['frame']) + 1
        clear6 = first(frames, lambda r: r['mode'] == '6', lo - 1)
        if clear6 and clear6 < limit:
            limit = clear6 + 1
        dz = [r for r in read_desert(work / 'runs' / k) if r['frame'] >= lo]
        rows = [r for r in rows if r['frame'] >= lo]
        events = [e for e in events if e['frame'] >= lo]
        c = dict(play_at=first(frames, lambda r: r['stage'] == '5' and r['mode'] == '4'), death_at=death)
        base = tank_checks(dec, steps4, prep, rows, events, frames, dz, limit, pt8, pals8)
        c.update(base[0])
        c.update(tank_checks2(dec, steps4, prep, rows, events, frames, dz, limit, pals8, base, forced))
        c['slots'] = dict(bad_frames=[r['frame'] for r in rows if r['frame'] >= (c['play_at'] or 0) and r['free5'] + r['active5'] != 30][:5])
        c['slots']['ok'] = not c['slots']['bad_frames']
        return (c, rows, events, frames, dz)
    every8 = ('portrait', 'commander', 'strip', 'tank', 'bullets', 'shells', 'hits', 'score', 'explosions', 'death', 'hull', 'ride', 'palettes', 'section_wait', 'slots')
    pals8 = dict(p10=0, hull=32, p7=64)
    tk, rows, events, frames, dz = checks8('tank')
    tk['expect'] = dict(subs=tk['tank']['subs'], shells=tk['shells']['made'], bullets=tk['bullets']['model'], ok=set(tk['tank']['subs']) >= {1, 2, 3, 4, 5, 6, 7} and all(tk['shells']['made'].values()) and (tk['bullets']['model'] > 0) and (tk['death']['killed'] is None) and (not tk['death_at']) and (tk['section_wait']['passed'] is None) and (tk['commander']['gone'] is not None))
    tk['passed'] = all((tk[k2]['ok'] for k2 in every8 + ('expect',)))
    rep['tank'] = tk
    tr, rows, events, frames, dz = checks8('tank_ride')
    tr['expect'] = dict(ride=tr['ride']['frames'], ok=tr['ride']['frames'] > 300 and (not tr['death_at']))
    tr['passed'] = all((tr[k2]['ok'] for k2 in every8 + ('expect',)))
    rep['tank_ride'] = tr
    tkk, rows, events, frames, dz = checks8('tank_kill')
    tkk['expect'] = dict(hits=tkk['hits']['ticks'], end=tkk['death']['end'], clear=tkk['section_wait']['mode6'], ok=len(tkk['hits']['ticks']) == dec['step8']['hit_lim'][3] and tkk['death']['end'] is not None and (tkk['section_wait']['mode6'] is not None) and (tkk['hits']['part_cuts'] > 0))
    tkk['passed'] = all((tkk[k2]['ok'] for k2 in every8 + ('expect',)))
    rep['tank_kill'] = tkk
    th, rows, events, frames, dz = checks8('tank_hits', forced=True)
    th['expect'] = dict(hits=th['hits']['ticks'], end=th['death']['end'], clear=th['section_wait']['mode6'], ok=len(th['hits']['ticks']) == dec['step8']['hit_lim'][3] and th['death']['end'] is not None and (th['section_wait']['mode6'] is not None))
    th['passed'] = all((th[k2]['ok'] for k2 in every8 + ('expect',)))
    rep['tank_hits'] = th
    td, rows, events, frames, dz = checks8('tank_death')
    death = td['death_at']
    td2 = None
    if death:
        back = next((e['frame'] for e in acts['tank_death'][1] if e['what'] == 'new' and e['kind'] == K['tank'] and (e['frame'] > death)), None)
        if back:
            td2, rows2, _, _, dz2 = checks8('tank_death', lo=back - 1)
            td2['respawn'] = dict(tank_at=back, steps=[(r['frame'], r['step'], r['map']) for r in dz2][:4], ok=dz2 != [] and dz2[0]['sec'] == 4 and (dz2[0]['map'] == DX.S4_WORLD))
    td['expect'] = dict(death_at=death, second=td2 and {k2: td2[k2]['ok'] for k2 in every8 + ('respawn',)}, ok=bool(death) and td2 is not None and td2['respawn']['ok'] and all((td2[k2]['ok'] for k2 in ('portrait', 'commander', 'strip', 'tank', 'hull'))))
    td['passed'] = all((td[k2]['ok'] for k2 in every8 + ('expect',)))
    rep['tank_death'] = td
    frames, (rows, events) = (res['tank_control'], acts['tank_control'])
    dzc = read_desert(work / 'runs' / 'tank_control')
    wait8 = next((i for i, st in enumerate(steps4) if st[0] == 'wait'))
    rep['tank_control'] = dict(da8=rows[-1]['da8'][:24], steps=sorted({r['step'] for r in dzc if r['sec'] == 4}), fails=not any(rows[-1]['da8'][:24]) and bcd(rows[-1]['score']) == 0 and (not any((r['sec'] == 4 and r['step'] > wait8 for r in dzc))))
    frames, (rows, events) = (res['jeep_control'], acts['jeep_control'])
    dzc = read_desert(work / 'runs' / 'jeep_control')
    rep['jeep_control'] = dict(jp_spawned=rows[-1]['jp_spawned'], gn_made=rows[-1]['gn_made'], shots=rows[-1]['gn_shot'], steps=sorted({r['step'] for r in dzc if r['sec'] == 3}), fails=rows[-1]['jp_spawned'] == 0 and rows[-1]['gn_shot'] == 0 and (not any((r['sec'] == 3 and r['step'] > jd['section_wait']['step'] for r in dzc))))
    wc, rows, events, frames = checks2('waves_control')
    wc['fails'] = rows[-1]['dr_spawned'] == 0 and (not wc['waves']['ok']) and (rows[-1]['rb_spawned'] == 0) and (rows[-1]['fl_spawned'] == 0) and (rows[-1]['bm_fired'] == 0) and (not any((e['what'] == 'new' and e['kind'] == K['drone'] for e in events)))
    rep['waves_control'] = wc
    c, rows, events, frames = checks('control')
    s0c = next((bcd(r['score']) for r in rows if r['frame'] >= (c['play_at'] or 0)), 0)
    fire('control', c, rows, events, frames)
    c['fails'] = rows[-1]['killed'] == 0 and rows[-1]['cuts'] == 0 and (rows[-1]['fired'] == 0) and (rows[-1]['bz_killed'] == 0) and (rows[-1]['rockets'] == 0) and (rows[-1]['mn_warn'] == 0) and (bcd(rows[-1]['score']) == s0c) and (not any((e.get('kind') in (1, 2, 3, 6, 8) for e in events if e['what'] in ('new', 'gone')))) and (not c['fire']['ok']) and (rows[-1]['dr_spawned'] == 0)
    rep['control'] = c
    mc, rows, events, frames = checks('mine_control')
    mine_checks('mine_control', mc, rows, events, frames)
    mc['fails'] = not mc['mine']['ok'] and rows[-1]['mn_warn'] == 0 and (rows[-1]['mn_blast'] == 0)
    rep['mine_control'] = mc
    rep['passed'] = rep['walk']['passed'] and rep['jump']['passed'] and rep['stand']['passed'] and rep['mine']['passed'] and rep['mine_hurt']['passed'] and c['fails'] and mc['fails'] and rep['waves']['passed'] and rep['strip']['passed'] and rep['drop']['passed'] and wc['fails'] and rep['worm']['passed'] and rep['worm_kill']['passed'] and rep['robots']['passed'] and rep['robot_kill']['passed'] and rep['flames']['passed'] and rep['jeep']['passed'] and rep['jeep_kill']['passed'] and rep['jeep_death']['passed'] and rep['jeep_control']['fails'] and all((rep[k]['passed'] for k in ('officer', 'officer_kill', 'officer_rank', 'officer_pull', 'officer_death'))) and rep['officer_control']['fails'] and all((rep[k]['passed'] for k in ('tank', 'tank_ride', 'tank_kill', 'tank_hits', 'tank_death'))) and rep['tank_control']['fails']
    (work / 'report.json').write_text(json.dumps(rep, indent=1, default=str) + '\n')
    print(json.dumps(rep, indent=1, default=str))
    print('PASS' if rep['passed'] else 'FAIL')
    return 0 if rep['passed'] else 1
CAPTION_FRAMES = 6000
CAPTION_SHOTS = (1700, 2100)
CAPTION_SCENE = 413
CAPTION_LEAD, CAPTION_SPAN = (100, 400)
DESERT_WIZARD = 36 + 240 + 15

def caption_window(build):
    """The screenshot window of the caption runs (desert and control): the caption spawns on the frame after"""
    bj = json.loads((build / 'build.json').read_text())
    s = next((x for x in bj['scenes'] if x['id'] == 'intro_desert'), None)
    if s is None or 'window' not in s or 'preroll' not in s:
        return CAPTION_SHOTS
    spawn = CAPTION_SCENE + s['preroll'] + s['window']['frames']
    if all(('intro_cut' in v for v in bj['sets'].values())):
        spawn += DESERT_WIZARD
    return (spawn - CAPTION_LEAD, spawn - CAPTION_LEAD + CAPTION_SPAN)
STOCK_REFS = {'siberia': 1, 'amazon': 2, 'aerial': 3, 'third_moon': 4}
FADE_SHOTS = 150
FADE_SPAN = 40

def hb_dim(comp, level):
    """HBMAME's picture of 4-bit components at a brightness level (scene_gate.hb_rgb)."""
    v = comp * 17 * (15 + 2 * level) // 45
    return np.where(comp > 1, v, 0)

def screen_levels(run, frames, mask):
    """{frame: 'black' | level 0-15 | None}: each screenshot outside `mask` (the caption) as one"""
    from PIL import Image
    imgs = {f: np.asarray(Image.open(run / f's_{f:05d}.png').convert('RGB')).astype(np.int32)[mask] for f in frames if (run / f's_{f:05d}.png').exists()}
    tables = [hb_dim(np.arange(16), L) for L in range(16)]
    fits = {f: [L for L in range(15) if np.isin(v, tables[L]).all()] for f, v in imgs.items() if v.any()}
    base = max(((fits[f][0], f) for f in fits if len(fits[f]) == 1), default=None)
    out = {}
    if base is None:
        return ({f: 'black' if not v.any() else None for f, v in imgs.items()}, None)
    L0, f0 = base
    inv = {int(v): c for c in range(15, -1, -1) for v in [tables[L0][c]]}
    comp = np.vectorize(lambda v: inv.get(int(v), -1))(imgs[f0])
    for f, v in imgs.items():
        if not v.any():
            out[f] = 'black'
            continue
        hit = [L for L in range(16) if (hb_dim(comp, L) == v).all()]
        out[f] = hit[0] if len(hit) == 1 else None
    return (out, f0)

def read_fade(out):
    rows = {}
    for line in (out / 'fade.tsv').read_text().splitlines()[1:]:
        f, layer, l1, l2, l3, uni, sky = line.split('\t')
        rows[int(f)] = dict(on=int(layer, 16) & 14 != 0, levels=(int(l1), int(l2), int(l3)), uniform=uni == '1', sky=int(sky, 16))
    return rows

def fade_pattern(run, rows, play, box):
    """One run's fade-in, relative to its first play frame P: the screen level of every frame in"""
    x0, y0, x1, y1 = box
    mask = np.ones((224, 384), bool)
    mask[max(y0, 0):y1, max(x0, 0):x1] = False
    frames = list(range(play - FADE_SPAN, play + 1))
    scr, base = screen_levels(run, frames, mask)

    def level(f):
        r = rows.get(f)
        return r['levels'][0] if r and r['uniform'] and (len(set(r['levels'])) == 1) else 'mixed' if r else None
    ram_on = next((f for f in frames if rows.get(f) and rows[f]['on']), None)
    return dict(screen=[[f - play, scr.get(f)] for f in frames], base_frame=base, on=next((f - play for f in frames if scr.get(f) not in ('black', None)), None), ram_on=ram_on - play if ram_on is not None else None, ram=[[f - play, level(f)] for f in range(ram_on, play)] if ram_on is not None else [], ram_restored_at_play=level(play) not in range(11))

def read_caption(out):
    """caption.tsv (lua/desert_gate.lua CAPTION)."""
    rows = []
    for line in (out / 'caption.tsv').read_text().splitlines()[1:]:
        f = line.split('\t')
        objs = []
        for o in filter(None, f[2].split(';')):
            k, v = o.split(':')
            st, sub, par, x, y, lvl, cnt, rec, pal = v.split(',')
            objs.append(dict(index=int(k), state=int(st), sub=int(sub), param=int(par), x=int(x), y=int(y), level=int(lvl), count=int(cnt), record=int(rec, 16), pal=int(pal, 16)))
        rows.append(dict(frame=int(f[0]), objs=objs, n=int(f[3]), box=tuple((int(v) for v in f[4].split(','))) if f[4] else None, codes=[int(c, 16) for c in f[5].split(',')] if f[5] else [], any=int(f[6]), ends=int(f[7]), fills=int(f[8]), pal=[int(w, 16) for w in f[9].split(',')], stale=int(f[10])))
    return rows

def caption_life(cap, frames):
    """One run's caption: its spawn (the first frame with a kind-2 object), its end (the first frame"""
    spawn = next((r['frame'] for r in cap if r['objs']), None)
    if spawn is None:
        return dict(spawn=None)
    end = next((r['frame'] for r in cap if r['frame'] > spawn and (not r['objs'])), None)
    life = [r for r in cap if spawn <= r['frame'] < (end or 10 ** 9)]
    ups, stalled, prev = ([], [], None)
    for r in life:
        o = r['objs'][0]
        t = (o['state'], o['sub'], o['level'], o['count'])
        if t == prev:
            stalled.append(r['frame'])
        elif ups or (o['state'] == 2 and o['level'] >= 1):
            ups.append(t)
        prev = t
    shown = [r['frame'] for r in cap if r['n']]
    runs = []
    for f in shown:
        if runs and f == runs[-1][1] + 1:
            runs[-1][1] = f
        else:
            runs.append([f, f])
    play = first(frames, lambda r: r['mode'] == '4', spawn)
    death = next((int(x['frame']) for x0, x in zip(frames, frames[1:]) if int(x['lives']) < int(x0['lives']) and int(x0['lives']) > 0), None)
    stall_runs = []
    for f in stalled:
        if stall_runs and f == stall_runs[-1][1] + 1:
            stall_runs[-1][1] = f
        else:
            stall_runs.append([f, f])
    return dict(spawn=spawn, end=end, objects=max((len(r['objs']) for r in life)), runs=runs, shown=len(shown), updates=ups, stalls=len(stalled), stall_runs=stall_runs, play=play, shown_to_play=play - runs[0][0] if play and runs else None, over_play=sum((1 for f in shown if play and f >= play)), death=death)
STOCK_CAPTION_FRAMES = 1500
STOCK_SKIP = '687-700:P1_BUTTON1'
STOCK_PLAY_FROM = 800
DESERT_PLAY_AFTER = 150

def play_from(a, e):
    """PLAY's held inputs from frame a (to e)."""
    return PLAY.replace('450-', f'{a}-').format(e=e)

def caption_marks(cap, frames):
    """A run's caption timeline: its spawn (the first frame with a kind-2 object), its first update (the first"""
    spawn = next((r['frame'] for r in cap if r['objs']), None)
    if spawn is None:
        return dict(spawn=None)
    update = next((r['frame'] for r in cap if r['frame'] >= spawn and r['objs'] and (r['objs'][0]['state'] == 2) and (r['objs'][0]['level'] >= 1)), None)
    listed = next((r['frame'] for r in cap if r['frame'] >= spawn and r['n']), None)
    play = first(frames, lambda r: r['mode'] == '4', spawn)
    gap = lambda x, y: y - x if x is not None and y is not None else None
    return dict(spawn=spawn, update=update, listed=listed, play=play, spawn_to_list=gap(spawn, listed), update_to_list=gap(update, listed), list_to_play=gap(listed, play))

def no_caption_after(cap, f0):
    """Frames after f0 with a kind-2 object or a caption code anywhere in the shown list."""
    return [r['frame'] for r in cap if r['frame'] > f0 and (r['objs'] or r['any'])]

def caption_control(build, machine, out):
    """The build with dz_cap_spawn's first instruction an rts (the control: everything else the same,"""
    syms = json.loads((build / 'build.json').read_text())['sets'][machine]['desert_syms']
    at = syms['dz_cap_spawn'] - 1048576
    (out / machine).mkdir(parents=True)
    for q in (build / machine).iterdir():
        b = bytearray(q.read_bytes())
        if q.name == 'strex_p6.bin':
            if b[at + 1] != 65 or b[at] not in (249, 250):
                raise SystemExit(f'{machine}: dz_cap_spawn at {at + 1048576:#x} has an unexpected shape')
            b[at:at + 2] = b'uN'
        (out / machine / q.name).write_bytes(bytes(b))
    return out

def ex_record(build, machine, rom_dir):
    """The caption record as the build's EX bank holds it: count, cols, rows, attribute, codes."""
    syms = json.loads((build / 'build.json').read_text())['sets'][machine]['desert_syms']
    _, bank = images(build, rom_dir, machine)
    a = syms['dz_cap_record'] - 1048576
    n, c1, r1, attr = struct.unpack('>4H', bank[a:a + 8])
    return dict(count=n, cols=c1 + 1, rows=r1 + 1, attr=attr, codes=list(struct.unpack(f'>{n}H', bank[a + 8:a + 8 + 2 * n])))

def cmd_caption(a):
    """caption (the desert's location caption, asm/desert.s dz_cap_spawn, desert_caption.py): from the"""
    import desert_caption as DC
    from PIL import Image
    work = a.workdir.resolve()
    work.mkdir(parents=True, exist_ok=False)
    binary = json.loads((a.runtime / 'runtime.json').read_text())['binary']
    machine = PARENT[a.set]
    build, rom_dir = (a.build.resolve(), a.rom_dir.resolve())
    roms = stage_sets(build, a.set, a.hbmame, rom_dir, work / 'sets')
    ctl = stage_sets(caption_control(build, machine, work / 'control'), a.set, a.hbmame, rom_dir, work / 'sets_control')
    rec = ex_record(build, machine, rom_dir)
    stock_img, _ = images(None, rom_dir, machine)
    refs = {name: DC.stock_caption(stock_img, st) for name, st in STOCK_REFS.items()}
    cap = DC.convert()
    lo, hi = caption_window(build)
    dz_env = dict(debug_env(5, 0, CAPTION_FRAMES, invincible=False), SHOTS=f'{lo}-{hi}@1', STREX_INPUTS=play_from(lo + CAPTION_LEAD + DESERT_PLAY_AFTER, CAPTION_FRAMES), CAPTION=f'{DC.SLOT}:{DC.CODES[0]:x}-{DC.CODES[1]:x},{DC.BLANK:x}-{DC.BLANK:x}', FADE=str(FADE_SHOTS))
    prev = stage_sets(a.fade_control.resolve(), a.set, a.hbmame, rom_dir, work / 'sets_previous')
    jobs = {'desert': (roms, dz_env), 'control': (ctl, dz_env), 'previous': (prev, dz_env)}
    for name, st in STOCK_REFS.items():
        jobs[name] = (roms, dict(debug_env(st, 0, CAPTION_FRAMES, invincible=False), FADE=str(FADE_SHOTS), STREX_INPUTS=STOCK_SKIP + ';' + play_from(STOCK_PLAY_FROM, CAPTION_FRAMES), CAPTION=f"{refs[name]['slot']}:" + ','.join((f'{c:x}-{c:x}' for c in sorted(set(refs[name]['codes']))))))
    sjobs = {f'stock_{name}': dict(jobs[name][1]) for name in STOCK_REFS}
    for k in sjobs:
        sjobs[k].update(debug_env(STOCK_REFS[k[6:]], 0, STOCK_CAPTION_FRAMES, invincible=False), STREX_INPUTS=STOCK_SKIP + ';' + play_from(STOCK_PLAY_FROM, STOCK_CAPTION_FRAMES))
    allj = [(k, binary, jobs[k][0], a.set, jobs[k][1], CAPTION_FRAMES) for k in jobs] + [(k, a.mame, rom_dir, machine, env, STOCK_CAPTION_FRAMES) for k, env in sjobs.items()]
    with ThreadPoolExecutor(a.jobs) as ex:
        res = dict(zip([j[0] for j in allj], ex.map(lambda j: run(j[1], j[2], j[3], work / 'runs' / j[0], j[4], j[5]), allj)))
    caps = {k: read_caption(work / 'runs' / k) for k in res}
    life = {k: caption_life(caps[k], res[k]) for k in jobs}
    marks = {k: caption_marks(caps[k], res[k]) for k in ['desert'] + list(STOCK_REFS) + list(sjobs)}
    rep = dict(set=a.set, record=dict(rec, codes=[f'{c:#06x}' for c in rec['codes']]), stock_records={k: dict(v, record=f"{v['record']:#x}", codes=[f'{c:#06x}' for c in v['codes']]) for k, v in refs.items()})
    d = life['desert']
    stock = {k: life[k] for k in STOCK_REFS}
    streams = json.loads((build / 'build.json').read_text())['sets'][machine]['streams']
    cine = [int(r['frame']) for r in res['desert'] if r['active'] in CINE]
    intro_end = max(cine) if cine else None
    want_box = (cap['x'], cap['y'], cap['x'] + 16 * (cap['cols'] - 1), cap['y'] + 16 * (cap['rows'] - 1))
    shown_rows = [r for r in caps['desert'] if r['n']]
    bad_cells = [r['frame'] for r in shown_rows if r['n'] != rec['count'] or r['codes'] != rec['codes'] or r['box'] != want_box]
    life_rows = [r for r in caps['desert'] if d['spawn'] and d['spawn'] <= r['frame'] < (d['end'] or 0)]
    flash = [r['frame'] for r in life_rows if r['objs'][0]['state'] == 2 and (r['pal'][0] >> 12 != min(r['objs'][0]['level'], 15) or [w & 4095 for w in r['pal']] != [w & 4095 for w in cap['palette']])]
    after = no_caption_after(caps['desert'], d['end'] or 0)
    stale = [r['frame'] for r in caps['desert'] if intro_end and r['frame'] > intro_end and r['stale']]

    def after_death(k):
        x = life[k]
        return no_caption_after(caps[k], x['death'])[:10] if x.get('spawn') and x.get('death') else None
    rep['desert'] = dict(d, updates=len(d.get('updates') or []), intro=played(res['desert'], streams), intro_end=intro_end, cells_wrong=bad_cells[:10], level_not_applied=flash[:10], caption_after_end=after[:10], stale_end_entries=stale[:10], after_death=after_death('desert'))
    for k, x in stock.items():
        lv = [r['frame'] for r in caps[k] if x.get('spawn') and x['spawn'] <= r['frame'] < (x['end'] or 0) and r['objs'] and (r['objs'][0]['state'] == 2) and (r['pal'][0] >> 12 != min(r['objs'][0]['level'], 15))]
        rep[k] = dict(x, updates=len(x.get('updates') or []), same_updates_as_desert=x.get('updates') == d.get('updates'), after_death=after_death(k), level_not_applied=lv)
    same_path = bool(d.get('updates')) and all((x.get('updates') == d['updates'] for x in stock.values()))
    timing = [x['shown_to_play'] for x in stock.values() if x.get('shown_to_play') is not None]
    rep['ex_stock_shown_to_play'] = [min(timing), max(timing)] if len(timing) == len(stock) else None
    sm = {k[6:]: marks[k] for k in sjobs}
    rep['stock_game'] = dict(mame=a.mame, set=machine, captions=sm)
    rep['build_marks'] = {k: marks[k] for k in ['desert'] + list(STOCK_REFS)}

    def one(key, ks):
        v = {sm[k].get(key) for k in ks}
        return v.pop() if len(v) == 1 and None not in v else None
    s_u2l, s_s2l = (one('update_to_list', STOCK_REFS), one('spawn_to_list', STOCK_REFS))
    s_l2p = [sm[k].get('list_to_play') for k in STOCK_REFS]
    s_l2p = [min(s_l2p), max(s_l2p)] if None not in s_l2p else None
    rep['stock_game'].update(update_to_list=s_u2l, spawn_to_list=s_s2l, list_to_play=s_l2p)
    bm = rep['build_marks']
    list_bad = [k for k in bm if s_u2l is None or bm[k].get('update_to_list') != s_u2l] + [k for k in STOCK_REFS if s_s2l is None or bm[k].get('spawn_to_list') != s_s2l]
    play_bad = [k for k in bm if s_l2p is None or bm[k].get('list_to_play') is None or (not s_l2p[0] <= bm[k]['list_to_play'] <= s_l2p[1])]
    rep['stock_game'].update(list_timing_wrong=list_bad, play_timing_wrong=play_bad)
    fr_d, fr_c = (res['desert'], res['control'])
    frames_differ = [int(x['frame']) for x, y in zip(fr_d, fr_c) if any((x[k] != y[k] for k in COLS))]
    sx, sy, art = DC.screen_art(cap)
    on = {r['frame'] for r in shown_rows}
    full = {r['frame'] for r in caps['desert'] if r['n'] and r['pal'][0] >> 12 == 15}
    exact, outside, unchanged_bad, compared = (0, [], [], 0)
    h, w = art.shape[:2]
    opaque = art[..., 3] == 255
    import scene_gate as SG
    by_frame = {r['frame']: r for r in caps['desert']}
    pens = cap['pens'][opaque]
    seen, unseen = (0, [])
    for f in range(lo, hi + 1):
        pa, pc = (work / 'runs' / 'desert' / f's_{f:05d}.png', work / 'runs' / 'control' / f's_{f:05d}.png')
        A = np.asarray(Image.open(pa).convert('RGB')).astype(np.int32)
        C = np.asarray(Image.open(pc).convert('RGB')).astype(np.int32)
        compared += 1
        diff = (A != C).any(-1)
        mask = np.zeros(diff.shape, bool)
        mask[sy:sy + h, sx:sx + w] = opaque
        if f in on or f - 1 in on:
            if (diff & ~mask).any():
                outside.append(f)
            if {f - 2, f - 1, f} <= full:
                if (A[sy:sy + h, sx:sx + w][opaque] == art[..., :3][opaque]).all():
                    exact += 1
                else:
                    outside.append(f)
        elif diff.any():
            unchanged_bad.append(f)
        r0, r1 = (by_frame.get(f - 1), by_frame.get(f))
        if r0 and r1 and r0['n'] and r1['n'] and (r0['pal'] == r1['pal']):
            want = np.array([SG.hb_rgb(wd) for wd in r1['pal']])[pens]
            got, ctl_px = (A[sy:sy + h, sx:sx + w][opaque], C[sy:sy + h, sx:sx + w][opaque])
            shows = (got == want).all(-1)
            seen += 1
            if shows.mean() < 0.5 or not (shows | (got == ctl_px).all(-1)).all():
                unseen.append(f)
    window_ok = bool(d.get('runs')) and lo < d['spawn'] and (d['runs'][-1][1] + 2 < hi)
    rep['control'] = dict(caption_spawned=life['control']['spawn'], frames=len(fr_c), frames_differ=frames_differ[:10], n_frames_differ=len(frames_differ), shots_compared=compared, shots_differ_off_caption=outside[:10], shots_differ_without_caption=unchanged_bad[:10], full_brightness_exact=exact, frames_caption_checked=seen, frames_caption_not_shown=unseen[:10], n_frames_caption_not_shown=len(unseen), window=[lo, hi], window_covers_caption=window_ok)
    sib = stock['siberia']
    checks = dict(intro_first=rep['desert']['intro'] == ['intro_desert'] and intro_end is not None and bool(d.get('runs')) and (d['runs'][0][0] > intro_end), one_caption=len(d.get('runs') or []) == 1 and d.get('objects') == 1, cells=not bad_cells and rec['attr'] == DC.SLOT and ((rec['cols'], rec['rows']) == (cap['cols'], cap['rows'])) and all((c == DC.BLANK or DC.CODES[0] <= c <= DC.CODES[1] for c in rec['codes'])) and ([c == DC.BLANK for c in rec['codes']] == [t is None for t in cap['cells']]), fade_path=same_path and (not flash) and all((x.get('play') and all((r[1] <= x['play'] for r in x['stall_runs'])) for x in [d] + list(stock.values()))), list_timing=s_u2l is not None and s_s2l is not None and (not list_bad), play_timing=s_l2p is not None and (not play_bad), gone=d.get('end') is not None and (not after) and (not stale), control=not frames_differ and (not outside) and (not unchanged_bad) and (exact > 0) and window_ok and (seen >= d['shown'] // 2) and (not unseen) and (life['control']['spawn'] is None) and (not any((r['any'] for r in caps['control']))), respawn=d.get('death') is not None and d['death'] > d['end'] and (rep['desert']['after_death'] == []) and (sib.get('death') is not None) and (len(sib.get('runs') or []) == 1) and (rep['siberia']['after_death'] == []) and all((rep[k]['after_death'] in (None, []) for k in stock)))

    def box_of(c):
        return (c['x'] - DC.SCREEN[0], c['y'] - DC.SCREEN[1], c['x'] - DC.SCREEN[0] + 16 * c['cols'], c['y'] - DC.SCREEN[1] + 16 * c['rows'])
    boxes = dict({k: box_of(v) for k, v in refs.items()}, desert=box_of(cap), previous=box_of(cap))
    fades = {}
    for k in ['desert', 'previous'] + list(STOCK_REFS):
        x = life[k]
        if x.get('play'):
            fades[k] = fade_pattern(work / 'runs' / k, read_fade(work / 'runs' / k), x['play'], boxes[k])
            fades[k]['on_after_caption'] = x['play'] + fades[k]['on'] - x['runs'][0][0] if fades[k]['on'] is not None and x.get('runs') else None
    key = lambda x: json.dumps([x['ram_on'], x['ram'], x['ram_restored_at_play']])
    stock_ram = {key(fades[k]) for k in STOCK_REFS if k in fades}
    stock_scr = {json.dumps(fades[k]['screen']) for k in STOCK_REFS if k in fades}
    stock_on = [fades[k]['on_after_caption'] for k in STOCK_REFS if k in fades]
    sfades = {k[6:]: fade_pattern(work / 'runs' / k, read_fade(work / 'runs' / k), marks[k]['play'], boxes[k[6:]]) for k in sjobs if marks[k].get('play')}
    game_ram = {key(v) for v in sfades.values()}
    game_on = {v['ram_on'] for v in sfades.values()}
    game_on = game_on.pop() if len(game_on) == 1 and len(sfades) == len(STOCK_REFS) and (None not in game_on) else None
    game_window = [s_l2p[0] + game_on, s_l2p[1] + game_on] if game_on is not None and s_l2p else None
    fz = fades.get('desert', {})
    dz_rows = read_fade(work / 'runs' / 'desert')
    sky_bad = [f for f in range(d['play'] + (fz.get('on') or 0), d['play']) if d.get('play') and dz_rows.get(f) and dz_rows[f]['uniform'] and (dz_rows[f]['sky'] >> 12 != dz_rows[f]['levels'][0])] if fz else ['no fade']

    def same(k):
        return k in fades and len(stock_ram) == 1 and (len(stock_scr) == 1) and (key(fades[k]) in stock_ram) and (json.dumps(fades[k]['screen']) in stock_scr)
    steps = [L for _, L in fz.get('screen') or [] if isinstance(L, int)]
    rep['fade'] = dict(stock_patterns_agree=len(stock_ram) == 1 and len(stock_scr) == 1 and (len(stock_on) == len(STOCK_REFS)), ex_stock_on_after_caption=[min(stock_on), max(stock_on)] if stock_on else None, stock_game_ram_agrees=len(game_ram) == 1 and game_ram == stock_ram, stock_game_on_after_caption=game_window, stock_game={k: v for k, v in sfades.items()}, desert=fades.get('desert'), previous=fades.get('previous'), stock={k: fades.get(k) for k in STOCK_REFS}, desert_sky_not_at_level=sky_bad[:10])
    checks['fade_in'] = same('desert') and (not sky_bad) and rep['fade']['stock_game_ram_agrees'] and (game_window is not None) and (fz.get('on_after_caption') is not None) and (game_window[0] <= fz['on_after_caption'] <= game_window[1]) and (steps == sorted(steps)) and (len(set(steps)) == 11)
    checks['fade_control_fails'] = not same('previous')
    rep['checks'] = checks
    rep['passed'] = all(checks.values())
    if fz.get('screen'):
        strip = []
        on = fz['on']
        picks = [on - 2, on, on + 3, on + 9, on + 15, on + 21, on + 27, -1, 0, 1]
        for k in ('desert', 'siberia', 'previous'):
            if k not in fades:
                continue
            row = []
            for dfr in picks:
                q = work / 'runs' / k / f"s_{life[k]['play'] + dfr:05d}.png"
                if q.exists():
                    row.append(Image.open(q).convert('RGB'))
            strip.append(row)
        W0, H0 = strip[0][0].size
        sheet = Image.new('RGB', (W0 * max((len(r) for r in strip)), H0 * len(strip)))
        for j, row in enumerate(strip):
            for i, im in enumerate(row):
                sheet.paste(im, (W0 * i, H0 * j))
        sheet.save(work / 'fade_strip.png')
        rep['fade_strip'] = dict(path=str(work / 'fade_strip.png'), rows=['desert', 'siberia', 'previous'], frames_from_play=picks)
    if d.get('runs'):
        s0 = d['runs'][0][0]
        picks = [f for f in (s0, s0 + 8, s0 + 16, s0 + 32, d['play'] or s0, (d['play'] or s0) + 20, d['runs'][0][1] - 8, d['runs'][0][1] + 2) if lo <= f <= hi]
        ims = [Image.open(work / 'runs' / 'desert' / f's_{f:05d}.png').convert('RGB') for f in picks]
        W0, H0 = ims[0].size
        sheet = Image.new('RGB', (4 * W0, H0 * -(-len(ims) // 4)))
        for i, im in enumerate(ims):
            sheet.paste(im, (W0 * (i % 4), H0 * (i // 4)))
        sheet.save(work / 'caption_sheet.png')
        rep['sheet'] = dict(path=str(work / 'caption_sheet.png'), frames=picks)
    (work / 'report.json').write_text(json.dumps(rep, indent=1, default=str) + '\n')
    print(json.dumps({k: v for k, v in rep.items() if k not in ('record', 'stock_records')}, indent=1, default=str))
    print('PASS' if rep['passed'] else 'FAIL')
    return 0 if rep['passed'] else 1

def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('cmd', choices=['identity', 'cycles', 'flow', 'static', 'timing', 'census', 'progression', 'actors', 'slopes', 'caption', 'smooth'])
    p.add_argument('--case', default='stage1', help='cycles: the identity case to trace (cases())')
    p.add_argument('--desert-census', type=Path, help='actors, slopes: the desert checkpoint census (the PC Engine data)')
    p.add_argument('--control', type=Path, help='slopes, smooth: a build that must fail the slope (smoothness) checks')
    p.add_argument('--wait-runtime', type=Path, help='smooth: the 8 MHz board-wait runtime (build_hbmame_probe.py --board-wait)')
    p.add_argument('--fade-control', type=Path, help='caption: the previous build (build 40: no fade-in under the caption), which must fail the fade check')
    p.add_argument('--base', type=Path)
    p.add_argument('--build', type=Path)
    p.add_argument('--runtime', type=Path)
    p.add_argument('--hbmame', type=Path)
    p.add_argument('--rom-dir', type=Path, required=True)
    p.add_argument('--workdir', type=Path)
    p.add_argument('--set', default='striderus01', choices=sorted(PARENT))
    p.add_argument('--frames', type=int, default=None, help='identity: frames per case (default 5000); cycles: frames traced (default 3300); flow: the path run (default 9000: Siberia plays its briefing after the desert clear)')
    p.add_argument('--desert-clear', type=int, default=4500, help='flow: the desert clear control frame')
    p.add_argument('--prog-frames', type=int, default=20000, help='progression: frames of the clears run')
    p.add_argument('--jobs', type=int, default=6)
    p.add_argument('--mame', default='mame', help="census, caption: stock MAME (the stock game's own runs)")
    a = p.parse_args()
    need = dict(identity=('base', 'build', 'runtime', 'hbmame', 'workdir'), cycles=('base', 'build', 'runtime', 'hbmame', 'workdir'), flow=('build', 'runtime', 'hbmame', 'workdir'), static=('base', 'build'), timing=('build', 'runtime', 'hbmame', 'workdir'), census=('workdir',), progression=('build', 'runtime', 'hbmame', 'workdir'), actors=('build', 'runtime', 'hbmame', 'workdir', 'desert_census'), slopes=('build', 'runtime', 'hbmame', 'workdir', 'desert_census'), caption=('build', 'fade_control', 'runtime', 'hbmame', 'workdir'), smooth=('build', 'runtime', 'wait_runtime', 'hbmame', 'workdir'))[a.cmd]
    missing = [k for k in need if getattr(a, k) is None]
    if missing:
        p.error(f'{a.cmd} needs ' + ', '.join(('--' + k for k in missing)))
    import desert_slopes as DS
    import desert_smooth as SM
    return dict(identity=cmd_identity, cycles=cmd_cycles, flow=cmd_flow, static=cmd_static, timing=cmd_timing, census=cmd_census, progression=cmd_progression, actors=cmd_actors, slopes=DS.cmd_slopes, caption=cmd_caption, smooth=SM.cmd_smooth)[a.cmd](a)
if __name__ == '__main__':
    sys.exit(main())
