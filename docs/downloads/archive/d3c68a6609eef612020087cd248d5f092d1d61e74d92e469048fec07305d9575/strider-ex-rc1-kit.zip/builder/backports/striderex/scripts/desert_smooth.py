"""Strider EX desert: the smoothness gate (desert_gate.py smooth). Hiryu and the camera on the dunes move"""
import json
import sys
from collections import Counter
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
import desert_slopes as DS
SETTLE = 20
SLOPE_STEP = 4
MAP_LOAD = 8
REG_LAG = 2
REG_X, REG_Y = (-64, 1792)
RISING, FALLING = ((2, 3, 4), (5, 6, 7))
LINES = 262
R, L = ('P1_JOYSTICK_RIGHT', 'P1_JOYSTICK_LEFT')

def turn(right_to, stop, left_to):
    """Right from 450 to right_to, nothing for `stop` frames, then left to left_to."""
    return f'450-{right_to}:{R};{right_to + stop + 1}-{left_to}:{L}'

def walks():
    out = [(name, 5, area, n, None, warp) for name, area, n, warp, want, sl in DS.WALKS if name != 's4']
    out += [('s0_shaft_x1', 5, 1, 1760, None, '42:43,1151,1'), ('s0_turn', 5, 1, 1900, turn(1100, 120, 1900), ''), ('s0_long_turn', 5, 1, 5400, turn(4300, 120, 5400), next((w for w in DS.WALKS if w[0] == 's0'))[3]), ('s2_turn', 5, 3, 2500, turn(1620, 120, 2500), '')]
    stock = [('stock_' + name, stage, area, n, None, '') for name, stage, area, n in DS.STOCK_WALKS]
    stock += [('stock_stpetersburg_turn', 0, 1, 2100, turn(1250, 120, 2100), ''), ('stock_amazon_turn', 2, 1, 1500, turn(800, 120, 1500), '')]
    return (out, stock)

def read_motion(out):
    lines = (out / 'motion.tsv').read_text().splitlines()
    head = lines[0].split('\t')
    rows = []
    for line in lines[1:]:
        r = dict(zip(head, line.split('\t')))
        r.pop('sprites', None)
        rows.append({k: v if k in ('follow', 'limits') else int(v) for k, v in r.items()})
    return rows

def sign(v):
    return (v > 0) - (v < 0)

def segments(frames, motion, warps, stage):
    """Runs of consecutive play frames of the stage (game mode 4), each without its first SETTLE frames"""
    import desert_gate as DG
    out, cur, settle = ([], [], 0)
    warps = set(warps)
    for fr, m in zip(frames, motion):
        if int(fr['frame']) != m['frame']:
            raise SystemExit(f"frame {m['frame']}: the logs disagree")
        if fr['stage'] != str(stage) or fr['mode'] != '4' or m['frame'] in warps or (fr.get('active') == DG.SCENE_ACTIVE):
            if cur:
                out.append(cur)
            cur, settle = ([], 0)
            continue
        settle += 1
        if settle > SETTLE:
            cur.append(m)
    if cur:
        out.append(cur)
    return out

def camera_reversals(seg, cam, obj):
    """Frames where the camera moves against its last move and Hiryu has not moved that way since. A"""
    out, last, moved = ([], None, set())
    for a, b in zip(seg, seg[1:]):
        if a['limits'] != b['limits']:
            last, moved = (None, set())
        dc, dh = (b[cam] - a[cam], b[obj] - a[obj])
        if dh:
            moved.add(sign(dh))
        if dc:
            s = sign(dc)
            if last is not None and s != last[1] and (s not in moved):
                out.append(dict(frame=b['frame'], step=dc, last_move_at=last[0], hiryu=[b['hx'], b['hy']], st=b['st']))
            last, moved = ((b['frame'], s), set())
    return out

def layer_offsets(seg):
    """Frames whose SCROLL3 registers are not the camera of REG_LAG frames before."""
    out = []
    for a, b in zip(seg, seg[REG_LAG:]):
        want = (a['camx'] + REG_X & 65535, REG_Y - a['camy'] & 65535)
        if (b['s3x'], b['s3y']) != want:
            out.append(dict(frame=b['frame'], registers=[b['s3x'], b['s3y']], camera_before=[a['camx'], a['camy']]))
    return out

def floor_against(seg):
    """Ground frames walking a slope (the same slope kind on this frame and the last, Hiryu's X moved)"""
    out, held, n = ([], [], 0)
    for a, b in zip(seg, seg[1:]):
        if a['st'] or b['st'] or b['kind'] not in RISING + FALLING or (a['kind'] != b['kind']):
            continue
        dx, dy = (b['hx'] - a['hx'], b['hy'] - a['hy'])
        if not dx:
            if dy:
                held.append(dict(frame=b['frame'], x=b['hx'], dy=dy, kind=b['kind'], camera_x=b['camx']))
            continue
        n += 1
        want = sign(dx) * (1 if b['kind'] in RISING else -1)
        if dy and sign(dy) != want:
            out.append(dict(frame=b['frame'], x=b['hx'], dx=dx, dy=dy, kind=b['kind']))
    return (n, out, held)

def floor_evenness(fl):
    """(column triples, uneven ones) over every slope tile (kinds 2-7) of a floor (desert_slopes.Floor):"""
    n = bad = 0
    for (c, r), (kind, hs) in fl.cells.items():
        if kind not in RISING + FALLING:
            continue
        for i in range(30):
            a, b, c3 = hs[i:i + 3]
            if a and b and c3 and (abs(b - a) <= SLOPE_STEP) and (abs(c3 - b) <= SLOPE_STEP) and (not {1, 31} & {a, b, c3}):
                n += 1
                bad += abs(c3 - b - (b - a)) > 1
    return (n, bad)

def static_check(a, build):
    """floor_evenness of every stock stage and desert map in both regions' images of the build: each"""
    import desert_gate as DG
    rep, ok = ({}, True)
    for machine in DG.PARENT.values():
        img, bank = DG.images(build.resolve(), a.rom_dir.resolve(), machine)
        st = {f'stage{s}': floor_evenness(DS.Floor(img, bank, DS.layer_record(img, s))) for s in range(5)}
        dz = {f'desert_map{k}': floor_evenness(DS.Floor(img, bank, DS.layer_record(img, 5, k))) for k in range(3)}
        worst = max((b / n for n, b in st.values()))
        r = {k: dict(triples=n, uneven=b, share=round(b / n, 4)) for k, (n, b) in {**st, **dz}.items()}
        good = all((n and b / n <= worst for n, b in dz.values()))
        rep[machine] = dict(floors=r, stock_worst_share=round(worst, 4), passed=good)
        ok &= good
    return (rep, bool(ok))

def busy(m):
    """Raster lines from the game task's wake to its sleep in a frame (None: it did not sleep)."""
    if m['sleep'] < 0 or m['wake'] < 0:
        return None
    return (m['sleep'] - m['wake']) % LINES

def analyze(frames, motion, warps, stage, lag_runtime, map_changes=()):
    import desert_gate as DG
    segs = segments(frames, motion, warps, stage)
    rep = dict(play_frames=sum((len(s) for s in segs)), segments=len(segs))
    rx = [r for s in segs for r in camera_reversals(s, 'camx', 'hx')]
    ry = [r for s in segs for r in camera_reversals(s, 'camy', 'hy')]
    lo = [r for s in segs for r in layer_offsets(s)]
    nf, fa, fh = (0, [], [])
    for s in segs:
        k, v, h = floor_against(s)
        nf, fa, fh = (nf + k, fa + v, fh + h)
    steps_x, steps_y, held = (Counter(), Counter(), 0)
    for s in segs:
        for a, b in zip(s, s[1:]):
            steps_x[b['camx'] - a['camx']] += 1
            steps_y[b['camy'] - a['camy']] += 1
            held += b['hx'] != a['hx'] and b['camx'] == a['camx']
    rep.update(camera_x_reversals=len(rx), camera_y_reversals=len(ry), first_reversals=(rx + ry)[:6], layer_frames_off=len(lo), first_layer_off=lo[:3], slope_frames=nf, floor_against_slope=len(fa), first_floor_against=fa[:4], held_on_slope_y_moves=len(fh), first_held=fh[:2], camera_x_steps=dict(sorted(steps_x.items())), camera_y_steps=dict(sorted(steps_y.items())), camera_held_while_hiryu_moved=held, follow_boxes=sorted({m['follow'] for s in segs for m in s}))
    b = [busy(m) for s in segs for m in s]
    rep['busiest_lines'] = max((v for v in b if v is not None), default=None)
    ok = not rx and (not ry) and (not lo) and (not fa) and (rep['play_frames'] > 0)
    if lag_runtime:
        n, lagged, worst = DG.lag(frames, str(stage))
        at = [int(r['frame']) for r0, r in zip(frames, frames[1:]) if r['stage'] == str(stage) and r['mode'] == '4' and (r0['mode'] == '4') and (r['gtask'] == '8') and (DG.SCENE_ACTIVE not in (r.get('active'), r0.get('active')))]
        loads = [f for f in at if any((0 <= f - m <= MAP_LOAD for m in map_changes))]
        rep.update(lag_frames=lagged, lag_play_frames=n, longest_lag_run=worst, lag_at_map_loads=len(loads), lag_elsewhere=[f for f in at if f not in loads][:8])
        ok &= len(loads) == lagged and worst <= DG.LAG_RUN
    rep['passed'] = bool(ok)
    return rep

def env_of(stage, area, frames, inputs, warp, s1skip=True):
    env = DS.walk_env(area, frames, warp, stage, s1skip)
    if inputs:
        env['STREX_INPUTS'] = inputs
    env['MOTION'] = '1'
    return env

def check_build(a, build, work, label, with_stock):
    import desert_gate as DG
    desert, stock = walks()
    todo = desert + (stock if with_stock else [])
    rts = {'10': a.runtime, '8': a.wait_runtime}
    roms = DG.stage_sets(build.resolve(), a.set, a.hbmame, a.rom_dir.resolve(), work / f'sets_{label}')
    jobs = {}
    for name, stage, area, n, inputs, warp in todo:
        for mhz, rt in rts.items():
            binary = json.loads((rt / 'runtime.json').read_text())['binary']
            jobs[f'{name}@{mhz}'] = (binary, env_of(stage, area, n, inputs, warp, label == 'build'), n, stage)
    with ThreadPoolExecutor(a.jobs) as ex:
        res = dict(zip(jobs, ex.map(lambda k: DG.run(jobs[k][0], roms, a.set, work / f'runs_{label}' / k, jobs[k][1], jobs[k][2]), jobs)))
    rep, ok = ({}, True)
    for k, (binary, env, n, stage) in jobs.items():
        out = work / f'runs_{label}' / k
        dz = DG.read_desert(out)
        maps = [r['frame'] for r0, r in zip(dz, dz[1:]) if r['map'] != r0['map']]
        r = analyze(res[k], read_motion(out), DS.warp_frames(out), stage, k.endswith('@8'), maps)
        rep[k] = r
        ok &= r['passed']
    return (rep, bool(ok))

def cmd_smooth(a):
    work = a.workdir.resolve()
    work.mkdir(parents=True, exist_ok=False)
    rep = {}
    rep['static'], ok = static_check(a, a.build)
    rep['build'], wok = check_build(a, a.build, work, 'build', True)
    ok &= wok
    rep['stock_passed'] = all((v['passed'] for k, v in rep['build'].items() if k.startswith('stock_')))
    rep['desert_passed'] = all((v['passed'] for k, v in rep['build'].items() if not k.startswith('stock_')))
    if a.control:
        rep['control_static'], csok = static_check(a, a.control)
        rep['control'], cok = check_build(a, a.control, work, 'control', False)
        rep['control_camera_reversals'] = {k: v['camera_x_reversals'] + v['camera_y_reversals'] for k, v in rep['control'].items()}
        rep['control_fails'] = any(rep['control_camera_reversals'].values()) and (not csok)
        ok &= rep['control_fails']
    rep['passed'] = bool(ok)
    (work / 'report.json').write_text(json.dumps(rep, indent=1) + '\n')
    summary = {lab: {k: [v['passed'], v['camera_x_reversals'], v['camera_y_reversals'], v['floor_against_slope'], v.get('lag_frames'), v['busiest_lines']] for k, v in rep[lab].items()} for lab in ('build', 'control') if lab in rep}
    summary.update({k: {m: (v['passed'], {f: x['share'] for f, x in v['floors'].items()}) for m, v in rep[k].items()} for k in ('static', 'control_static') if k in rep})
    print(json.dumps(summary))
    print('PASS' if ok else 'FAIL')
    return 0 if ok else 1

def self_test():
    seg = [dict(frame=i, hx=100, hy=50, st=0, camx=c, camy=10, limits='0') for i, c in enumerate([0, 2, 4, 0, 2, 4, 0])]
    assert [r['step'] for r in camera_reversals(seg, 'camx', 'hx')] == [-4, 2, -4]
    seg = [dict(frame=i, hx=100 + 2 * i - (6 * i - 30 if i > 5 else 0), hy=50, st=0, camx=c, camy=10, limits='0') for i, c in enumerate([0, 2, 4, 6, 8, 10, 10, 10, 10, 8, 6])]
    assert not camera_reversals(seg, 'camx', 'hx'), camera_reversals(seg, 'camx', 'hx')
    seg = [dict(frame=i, hx=i, hy=0, st=0, kind=2, camx=0, camy=0) for i in range(5)]
    seg[3]['hy'] = -1
    seg[4]['hx'] = 3
    assert floor_against(seg)[1][0]['frame'] == 3 and floor_against(seg)[2][0]['frame'] == 4
    seg = [dict(frame=i, hx=100, hy=50, st=0, camx=c, camy=10, limits=str(i > 3)) for i, c in enumerate([0, 2, 4, 6, 2])]
    assert not camera_reversals(seg, 'camx', 'hx')
    fl = type('F', (), {})()
    fl.cells = {(0, 0): (3, tuple((min(30, 2 + 4 * (v // 3) + 2 * (v % 3 == 2)) for v in range(32)))), (1, 0): (3, tuple(range(1, 32)) + (31,)), (2, 0): (1, (5,) * 32)}
    n, bad = floor_evenness(fl)
    assert n > 40 and bad > 5, (n, bad)
    assert busy(dict(sleep=60, wake=247)) == 75 and busy(dict(sleep=-1, wake=247)) is None
    print('desert_smooth self-test passed')
    return 0
if __name__ == '__main__':
    import argparse
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('--self-test', action='store_true', required=True)
    sys.exit(self_test())
