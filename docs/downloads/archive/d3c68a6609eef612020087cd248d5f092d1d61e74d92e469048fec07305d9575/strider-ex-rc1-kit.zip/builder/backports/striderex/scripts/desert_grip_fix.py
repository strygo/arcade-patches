"""Restore the first desert girder's omitted PC Engine grip surface."""
import argparse
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import struct
import numpy as np
import desert_ex as DX
import desert_slopes as DS
import pce_desert_convert as PC
import pce_desert_maps as M
import respawn_fix as RF
BASE = 1703936

def sha(b):
    return hashlib.sha256(b).hexdigest()

def source_mask(capture, all_platforms=False):
    dumps = list(capture.glob('pce_*_limit_ram_0d0000.bin'))
    if len(dumps) != 1:
        raise ValueError('need one fresh checkpoint-1 limit capture')
    tag = dumps[0].name.removeprefix('pce_').removesuffix('_ram_0d0000.bin')
    state = M.section(capture, 0, tag)
    c = dumps[0].read_bytes()
    identity = (state['checkpoint'], state['section'], state['width'], state['row0'], state['col0'])
    supported = ((1, 0, 192, 32, 0), (3, 2, 128, 0, 166)) if all_platforms else ((1, 0, 192, 32, 0),)
    if identity not in supported:
        raise ValueError('unsupported desert platform source map')
    expected = {38: (3, 115), 39: (4, 115), 52: (1, 116)}
    if all_platforms:
        expected.update({43: (6, 117), 44: (5, 117)})
    for kind, pair in expected.items():
        if tuple(M.bank(c, 105, 1176 + 2 * kind, 2)) != pair:
            raise ValueError('grip class contract changed')
    cells = state['map']
    classes = np.array(list(state['collision']))[np.minimum(cells, len(state['collision']) - 1)] & 127
    mask = np.zeros((2048, 12288 if all_platforms else 4608), bool)
    count = 0
    for row in range(classes.shape[0]) if all_platforms else range(13, 19):
        for col in range(classes.shape[1]) if all_platforms else range(83, 103):
            kind = int(classes[row, col])
            if kind not in expected:
                continue
            if not all_platforms and kind == 52 and (row != 13 or not 95 <= col <= 102):
                continue
            shape = expected[kind][0]
            profile = np.array(list(M.bank(c, 105, 920 + shape * 16, 16)))
            small = np.arange(16)[:, None] == profile[None, :]
            wide = PC.widen_copy(small)
            x = (state['col0'] + col) * 24
            y = (state['row0'] + row) * 16
            mask[y:y + 16, x:x + 24] |= wide
            count += 1
    wanted = (75 if state['checkpoint'] == 1 else 12) if all_platforms else 20
    if count != wanted:
        raise ValueError('girder cell selection changed')
    return (mask, dict(pce_cells=count, pce_bank_sha256=sha(c), grip_mask_sha256=sha(mask.tobytes()), class_records={hex(k): list(v) for k, v in expected.items()}))

def patch(files, machine, mask, stock, *, map_index=0, allocation_base=BASE, merge=False, wall_overrides=None, surface_overrides=None):
    image = RF.compose(files, RF.SETS[machine])
    p6 = files['strex_p6.bin']
    bank = bytearray((p6[i ^ 1] for i in range(len(p6))))

    def read(at, n):
        return bytes(bank[at - 1048576:at - 1048576 + n]) if at >= 1048576 else bytes(image[at:at + n])

    def write(at, data):
        if at >= 1048576:
            bank[at - 1048576:at - 1048576 + len(data)] = data
        else:
            image[at:at + len(data)] = data
    lr = DS.layer_record(image, 5, map_index)
    grid_at = int.from_bytes(read(lr + 2, 4), 'big')
    sec_at = int.from_bytes(read(lr + 6, 4), 'big')
    grid = bytearray(read(grid_at, 256))
    sections = [read(sec_at + 384 * i, 384) for i in range(max(grid) + 1)]
    sets = DX.collision_sets(image)
    stock_used = DX.stock_scroll3_codes(stock)
    tables = {}
    free = {}
    for key, (pg, ty, fpg, fl, rec) in sets.items():
        pages = read(pg, 32)
        page = pages[DX.DZ_SLOT]
        if not page:
            raise ValueError('desert collision page missing')
        tabs = read(ty, max(pages) * 256)
        tables[key] = (ty + (page - 1) * 256, tabs)
        free[key] = [v for v in range(32, 256) if v not in tabs]
    pool = [v for v in range(1535, 1280, -1) if (v, 3) not in stock_used and all((read(tables[k][0] + (v & 255), 1) == b'\x00' for k in sets))]
    top, bottom, left, right = DX.exposure(mask)
    points = np.argwhere(mask)
    tiles = sorted({(int(x) // 32, int(y) // 32) for y, x in points} | set(wall_overrides or {}) | set(surface_overrides or {}))
    profiles = {}
    by_tile = {}
    record_types = {k: {} for k in sets}
    record_changes = []
    if merge:
        for k, (_, tabs) in tables.items():
            for value in set(tabs) - set(range(32)):
                record_types[k][read(sets[k][4] + (value - 32) * 33, 33)] = value
        for code in range(1281, 1536):
            key = []
            for k in 'ABCD':
                value = read(tables[k][0] + (code & 255), 1)[0]
                key.append((None, read(sets[k][4] + (value - 32) * 33, 33)) if value >= 32 else (value, None))
            if any((v or r for v, r in key)):
                profiles[tuple(key)] = code
    inherited_profiles = len(profiles)
    for cx, cy in tiles:
        args = [a[cy * 32:cy * 32 + 32, cx * 32:cx * 32 + 32] for a in (top, bottom, left, right)]
        depths = DX.depth_records(*args)
        if merge:
            wr = 63 - cy
            entry = sections[grid[wr // 8 * 32 + cx // 12]][4 * (wr % 8 * 12 + cx % 12):][:4]
            old = int.from_bytes(entry[:2], 'big') & 16383
            flips = entry[3] >> 5 & 3
            for k, (pg, ty, _, _, recs) in sets.items():
                page = read(pg + (old >> 8) + 8 * flips, 1)[0]
                value = read(ty + (page - 1) * 256 + (old & 255), 1)[0] if page else 0
                previous = tuple(read(recs + (value - 32) * 33 + 1, 32)) if value >= 32 else (value,) * 32
                depths[k] = tuple((max(a, b) for a, b in zip(depths[k], previous)))
        for k, values in (wall_overrides or {}).get((cx, cy), {}).items():
            if k not in 'CD' or len(values) != 32 or any((not 0 <= v <= 31 for v in values)):
                raise ValueError('invalid wall override')
            depths[k] = tuple(values)
        for k, values in (surface_overrides or {}).get((cx, cy), {}).items():
            if k not in 'AB' or len(values) != 32 or any((not 0 <= v <= 31 for v in values)):
                raise ValueError('invalid floor/ceiling override')
            depths[k] = tuple(values)
        key = tuple((DX.entry_of(k, depths[k]) for k in 'ABCD'))
        if key not in profiles:
            if not pool:
                raise ValueError('no free desert collision code')
            code = pool.pop(0)
            profiles[key] = code
            for i, k in enumerate('ABCD'):
                value, record = key[i]
                if record is not None:
                    if record not in record_types[k]:
                        if not free[k]:
                            raise ValueError('no free collision record')
                        value = free[k].pop(0)
                        record_types[k][record] = value
                        at = sets[k][4] + (value - 32) * 33
                        record_changes.append(dict(set=k, address=at, before=read(at, 33).hex(), after=record.hex()))
                        write(at, record)
                    value = record_types[k][record]
                write(tables[k][0] + (code & 255), bytes([value]))
        by_tile[cx, 63 - cy] = profiles[key]
    groups = {}
    for (cx, wr), code in by_tile.items():
        groups.setdefault((cx // 12, wr // 8), []).append((cx % 12, wr % 8, code))
    for (gx, gy), changes in groups.items():
        section = bytearray(sections[grid[gy * 32 + gx]])
        for sc, sr, code in changes:
            at = (sr * 12 + sc) * 4
            old = int.from_bytes(section[at:at + 2], 'big') & 16383
            flips = section[at + 3] >> 5 & 3
            for k, (pg, ty, fpg, fl, recs) in sets.items():
                page = read(pg + (old >> 8) + 8 * flips, 1)[0]
                if not merge and page and (read(ty + (page - 1) * 256 + (old & 255), 1) != b'\x00'):
                    raise ValueError(f'grip overlaps an existing surface at ({gx * 12 + sc},{63 - (gy * 8 + sr)}), set {k}, code {old:04x}')
            section[at:at + 4] = DX.raw_entry(code, 1, 1, 0)
        if len(sections) >= 256:
            raise ValueError('collision grid index overflow')
        grid[gy * 32 + gx] = len(sections)
        sections.append(bytes(section))
    body = bytes(grid) + b''.join(sections)
    if read(allocation_base, len(body)) != b'\xff' * len(body):
        raise ValueError('new collision allocation is not free')
    old_pair = struct.pack('>II', grid_at, sec_at)
    refs = [at + 1048576 for at in range(0, len(bank) - 8, 2) if bank[at:at + 8] == old_pair]
    if len(refs) != 2 or lr + 2 not in refs:
        raise ValueError('unexpected map-zero pointer consumers')
    write(allocation_base, body)
    for at in refs:
        write(at, struct.pack('>II', allocation_base, allocation_base + 256))
    output = dict(files, **RF.decompose(image, RF.SETS[machine], {n: len(files[n]) for n, _, _ in RF.SETS[machine]}))
    output['strex_p6.bin'] = bytes((bank[i ^ 1] for i in range(len(bank))))
    return (output, dict(allocation_start=allocation_base, allocation_size=len(body), source_layer=lr, tiles=len(tiles), new_classes=len(profiles) - inherited_profiles, new_sections=len(groups), records=record_changes, pointer_consumers=refs, old_pointers=[grid_at, sec_at], allocation_sha256=sha(body), native_jump_and_game_code_unchanged=True))

def main():
    import sys
    if sys.argv[1:] == ['--self-test']:
        for shape in (np.zeros(16, dtype=int), np.arange(16), np.arange(15, -1, -1)):
            small = np.arange(16)[:, None] == shape[None, :]
            wide = PC.widen_copy(small)
            assert wide.shape == (16, 24) and np.all(wide.sum(0) == 1)
            mask = np.zeros((32, 64), bool)
            mask[8:24, 8:32] = wide
            mask[8:24, 32:56] = wide
            surf = DX.exposure(mask)
            assert np.array_equal(surf[0], mask) and np.array_equal(surf[1], mask)
            for x in range(8, 56):
                assert mask[:, x].sum() == 1
        print('Girder geometry self-test PASS: source profiles, widening and both faces')
        return
    p = argparse.ArgumentParser(description=__doc__)
    for n in ('build', 'rom-dir', 'capture', 'out'):
        p.add_argument('--' + n, type=Path, required=True)
    a = p.parse_args()
    mask, source = source_mask(a.capture)
    meta = json.loads((a.build / 'build.json').read_text())
    rep = deepcopy(meta)
    a.out.mkdir(parents=True, exist_ok=False)
    stock = DX.program_images(a.rom_dir)
    for machine, spec in meta['sets'].items():
        files = {n: (a.build / machine / n).read_bytes() for n in spec['files']}
        if any((sha(b) != spec['files'][n] for n, b in files.items())):
            raise ValueError('build input changed')
        output, report = patch(files, machine, mask, stock[machine])
        d = a.out / machine
        d.mkdir()
        for n, b in output.items():
            (d / n).write_bytes(b)
        rep['sets'][machine]['files'] = {n: sha(b) for n, b in output.items()}
        rep['sets'][machine]['desert_grip'] = dict(source=source, **report)
        print(machine, 'restored first girder:', report['tiles'], 'cells,', report['new_classes'], 'classes', flush=True)
    (a.out / 'build.json').write_text(json.dumps(rep, indent=2) + '\n')
if __name__ == '__main__':
    main()
