; Strider EX: PLAYER1/PLAYER2 READY and GO the same distance below the stage's name in every

; level"; scripts/ready_ex.py, PHASE0_FINDINGS.md "PLAYER1 READY and the location captions").
;
; The stock READY object (system object kind 0, parameters 9 and 10; GO: 11) finds its text in
; one record table for every stage: SCROLL1 text (RDY_TEXT_TABLE: draw RDY_DRAW, erase
; RDY_ERASE) or sprites (RDY_SPRITE_TABLE: the init stores the record pointer in +$1A, the sprite
; frame draws from it). Here each stage takes its own table (rdy_text_tabs, rdy_sprite_tabs,
; written by ready_ex.py as ready.inc): the stock table, whose records ready_ex.py moved to the
; position of the two-row names, or a table whose entries 9-11 hold the same records at the
; stage's position. Respawns, both players' turns and continues use the stage's table.
;
; Eight stock sites per region reach this code; all eight run only for parameters 9-11 (the
; object's dispatch tables, checked by ready_ex.py):
;   - the text draws and erases: the two inits' and the blink's jmp/jsr RDY_DRAW / RDY_ERASE (six
;     sites) -> rdy_draw / rdy_erase. Each repeats the stock routine's head, takes the stage's
;     table instead of the stock one, and goes on in the stock routine after its table load, so
;     the stack holds what it holds in stock (a0, then the cell writer's return address);
;   - the two inits' movea.l #RDY_SPRITE_TABLE,a3 -> jmp rdy_spr9 / rdy_spr11, back after it. D0
;     is 0 there (moveq) and is 0 again on the way back.
; Registers: rdy_draw / rdy_erase use d1, which the stock cell writer sets before reading it.
; Nothing is written but the replaced instruction's register and, for the text, the same stack.
; Cost: about 70 cycles a call (text: on the frames READY or GO is drawn or erased) and 90 an init.

rdy_draw:                               ; the stock draw's head (RDY_DRAW)
        moveq   #0,d0
        move.b  6(a0),d0
        add.b   d0,d0
        movem.l a0,-(a7)
        moveq   #0,d1
        move.b  (RDY_STAGE).l,d1
        cmpi.b  #RDY_STAGES,d1
        bls.s   .in
        moveq   #RDY_STAGES,d1          ; past the table: the stock table
.in:    add.w   d1,d1
        add.w   d1,d1
        lea     rdy_text_tabs(pc),a0
        movea.l (a0,d1.w),a0
        jmp     (RDY_DRAW_TAIL).l           ; the stock lookup, the cell writer, movem.l (a7)+,a0, rts

rdy_erase:                              ; the stock erase's head (RDY_ERASE)
        moveq   #0,d0
        move.b  6(a0),d0
        add.b   d0,d0
        movem.l a0,-(a7)
        moveq   #0,d1
        move.b  (RDY_STAGE).l,d1
        cmpi.b  #RDY_STAGES,d1
        bls.s   .in
        moveq   #RDY_STAGES,d1
.in:    add.w   d1,d1
        add.w   d1,d1
        lea     rdy_text_tabs(pc),a0
        movea.l (a0,d1.w),a0
        jmp     (RDY_ERASE_TAIL).l

rdy_spr9:                               ; READY's init (parameters 9, 10): a3 = the stage's sprite table
        move.b  (RDY_STAGE).l,d0
        cmpi.b  #RDY_STAGES,d0
        bls.s   .in
        moveq   #RDY_STAGES,d0
.in:    add.w   d0,d0
        add.w   d0,d0
        lea     rdy_sprite_tabs(pc),a3
        movea.l (a3,d0.w),a3
        moveq   #0,d0
        jmp     (RDY_SPR9_TAIL).l

rdy_spr11:                              ; GO's init (parameter 11)
        move.b  (RDY_STAGE).l,d0
        cmpi.b  #RDY_STAGES,d0
        bls.s   .in
        moveq   #RDY_STAGES,d0
.in:    add.w   d0,d0
        add.w   d0,d0
        lea     rdy_sprite_tabs(pc),a3
        movea.l (a3,d0.w),a3
        moveq   #0,d0
        jmp     (RDY_SPR11_TAIL).l

        even
        include "ready.inc"             ; ready_ex.py: the region's addresses, the tables, the records
