"""Capture PC Engine Strider frames with mirrored VDC/VCE state."""
import argparse
import hashlib
import json
import os
import re
import shutil
import signal
import subprocess
import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[3]
SHADOW = ROOT / 'backports/striderex/lua/pce_vdc_shadow.lua'
BASE = ROOT / 'cpsplus/lua/strider_console_probe.lua'
RAMREC = ROOT / 'backports/striderex/lua/pce_ram_record.lua'
RUNNER = ROOT / 'translations/vhunt2/scripts/run_surface_trace.py'
NEW_GAME = '300-310:P1_START;3700-3710:P1_START;4000-4010:P1_START'
WINDOW = re.compile('^\\d+:\\d+:\\d+$')

def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('--outdir', type=Path, required=True)
    p.add_argument('--cdrom', type=Path, required=True)
    p.add_argument('--rompath', type=Path, required=True)
    p.add_argument('--mame', default=os.environ.get('STREX_MAME', 'mame'))
    p.add_argument('--hashpath', default=os.environ.get('STREX_MAME_HASH', '/opt/homebrew/share/mame/hash'))
    p.add_argument('--schedule', default=NEW_GAME, help='input schedule (default: start a new game)')
    p.add_argument('--window', action='append', default=[], help='start:end:step frames to dump (repeatable)')
    p.add_argument('--end', type=int, required=True, help='frame at which the run stops')
    p.add_argument('--pce-start-stage', type=int, choices=range(7))
    p.add_argument('--pce-phase', choices=['stage_clear', 'continue', 'ending'])
    p.add_argument('--pce-checkpoint-census', action='store_true', help='step through the stage checkpoints (research control; the run ends at the last one)')
    p.add_argument('--pce-hold', action='append', choices=['timer', 'health', 'lives'], default=[], help='research control while in play (repeatable): timer = no TIME OVER, health = topped up, lives = 2+ (lua/pce_vdc_shadow.lua)')
    p.add_argument('--pce-first-checkpoint', type=int, help='start the stage at this checkpoint (research control)')
    p.add_argument('--timeout-seconds', type=float, default=900)
    p.add_argument('--log-vram', default='', help='lo-hi@f0-f1 (hex word addresses): log VRAM writers with PC and banks')
    p.add_argument('--ram-record', metavar='F0:F1', help='research: record main RAM and the MPRs every in-play frame F0..F1 (lua/pce_ram_record.lua) to ram_record.bin')
    p.add_argument('--ram-record-extra', default='', metavar='LO-HI,...', help='more physical ranges for --ram-record (hex, 4-byte aligned)')
    p.add_argument('--write-log', metavar='F0:F1', help='research: log every write (PC, MPRs) in frames F0..F1 to ram_writes.txt')
    p.add_argument('--write-log-range', default='1f0000-1f1fff', metavar='LO-HI', help='physical range for --write-log (hex; default main RAM)')
    p.add_argument('--verify-vram', action='store_true', help='diagnostic: read real VRAM back through the VDC port at each dump (disturbs the game)')
    p.add_argument('--poke', action='append', default=[], metavar='FRAME:ADDR=VALUE', help="research control: one 32-bit little-endian write to a physical address at the end of FRAME (hex 0x... allowed; at most one per frame), e.g. to place Hiryu's actor (0x10CE04: Y | X << 16) at a trigger the open-loop input cannot reach")
    a = p.parse_args()
    if any((not re.match('^\\d+:(0x[0-9a-fA-F]+|\\d+)=(0x[0-9a-fA-F]+|\\d+)$', x) for x in a.poke)) or len({x.split(':')[0] for x in a.poke}) != len(a.poke):
        p.error('--poke takes FRAME:ADDR=VALUE, one per frame')
    if not a.window:
        p.error('at least one --window is required')
    for w in a.window:
        if not WINDOW.match(w):
            p.error(f'bad --window {w!r}; expected start:end:step')
        start, end, step = map(int, w.split(':'))
        if step <= 0 or start > end or end + 2 > a.end:
            p.error(f'--window {w!r} must have step > 0 and finish at least two frames before --end')
    out = a.outdir.resolve()
    out.mkdir(parents=True, exist_ok=True)
    if (out / 'run.log').exists():
        p.error('choose a fresh output directory')
    shadow, base = (out / SHADOW.name, out / BASE.name)
    shutil.copyfile(SHADOW, shadow)
    shutil.copyfile(BASE, base)
    env = os.environ | dict(SDL_VIDEODRIVER='dummy', SDL_AUDIODRIVER='dummy', STRIDEREX_BASE_PROBE=str(base), STRIDEREX_SCENE_CAPTURE=','.join(a.window), STRIDER_PSX_POKES=';'.join(a.poke), STRIDER_CONSOLE_RAM_DUMP='0', STRIDER_PCE_STATE='1', STRIDER_PCE_START_STAGE='' if a.pce_start_stage is None else str(a.pce_start_stage), STRIDER_PCE_CHECKPOINT_CENSUS='1' if a.pce_checkpoint_census else '0', STRIDER_PCE_FIRST_CHECKPOINT='' if a.pce_first_checkpoint is None else str(a.pce_first_checkpoint), STRIDEREX_HOLD=','.join(a.pce_hold), STRIDER_PCE_PHASE=a.pce_phase or '', STRIDER_PSX_SOUND_STATE='0', STRIDEREX_VERIFY_VRAM='1' if a.verify_vram else '0', STRIDEREX_LOG_VRAM=a.log_vram)
    if a.ram_record or a.write_log:
        f0, f1 = map(int, (a.ram_record or '0:0').split(':'))
        rec = out / RAMREC.name
        shutil.copyfile(RAMREC, rec)
        env.update(STRIDEREX_RAMREC_LUA=str(rec), STRIDEREX_RAMREC=str(out / 'ram_record.bin'), STRIDEREX_RAMREC_FROM=str(f0), STRIDEREX_RAMREC_TO=str(f1), STRIDEREX_RAMREC_EXTRA=a.ram_record_extra)
        if a.write_log:
            w0, w1 = a.write_log.split(':')
            env.update(STRIDEREX_WLOG=str(out / 'ram_writes.txt'), STRIDEREX_WLOG_FROM=w0, STRIDEREX_WLOG_TO=w1, STRIDEREX_WLOG_RANGE=a.write_log_range)
    mame = ['-nothrottle', '-video', 'none', '-sound', 'none', '-hashpath', a.hashpath, '-cfg_directory', str(out / 'cfg'), '-nvram_directory', str(out / 'nvram'), '-wavwrite', str(out / 'audio.wav'), '-cdrom', str(a.cdrom.resolve()), '-cart', 'acardpro']
    cmd = [sys.executable, str(RUNNER), '--machine', 'pce', '--outdir', str(out), '--script', str(shadow), '--schedule', a.schedule, '--captures', f'{a.end}=limit', '--dump-range', '0:0x40', '--rompath', str(a.rompath.resolve()), '--mame', a.mame] + ['--mame-arg=' + x for x in mame]
    (out / 'invocation.json').write_text(json.dumps(dict(command=cmd, windows=a.window, end=a.end, schedule=a.schedule, pce_start_stage=a.pce_start_stage, pce_phase=a.pce_phase, pce_checkpoint_census=a.pce_checkpoint_census, pce_hold=a.pce_hold, pce_first_checkpoint=a.pce_first_checkpoint, pokes=a.poke, cdrom_name=a.cdrom.name, shadow_sha256=sha256(shadow), base_probe_sha256=sha256(base)), indent=2) + '\n')
    with (out / 'run.log').open('w') as log:
        proc = subprocess.Popen(cmd, env=env, cwd=out, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        try:
            code = proc.wait(timeout=a.timeout_seconds)
        except subprocess.TimeoutExpired:
            os.killpg(proc.pid, signal.SIGTERM)
            try:
                proc.wait(timeout=20)
            except subprocess.TimeoutExpired:
                os.killpg(proc.pid, signal.SIGKILL)
                proc.wait()
            code = 124
    dumps = sorted(out.glob('pce_*_scene.vdc'))
    tap_errors = [l for l in (out / 'run.log').read_text(errors='replace').splitlines() if 'STREX_TAP_ERROR' in l]
    if tap_errors and code == 0:
        code = 3
    (out / 'completion.json').write_text(json.dumps(dict(exit_code=code, scene_dumps=len(dumps), tap_errors=tap_errors), indent=2) + '\n')
    print(f'pce scene capture: exit {code}; {len(dumps)} dumps; {out}')
    return code
if __name__ == '__main__':
    sys.exit(main())
