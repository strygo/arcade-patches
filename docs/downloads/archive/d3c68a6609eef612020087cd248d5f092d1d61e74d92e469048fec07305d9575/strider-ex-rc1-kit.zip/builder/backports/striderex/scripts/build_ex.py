"""Build the Strider EX ROM files (both regions) from the stock sets and the PCE census."""
import argparse
import hashlib
import json
import re
import struct
import subprocess
from asm_payload import command as assembly_command
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
import cinematic_convert as C
import cinematic_lz as LZ
import cinematic_timing as CT
from cinematic_transition import logo_trim, FADE_LEAD, FADE_INTERVAL
import cps1_gfx as G
import respawn_fix as RF
import restore_tunes as RT
import title_ex as TX
import ending_ex as EE
import earth_palette as EP
import earth_tile as ET
import subtitle_ex as SX
import usa_slice as US
import portrait_ex as PX
import ready_ex as RX
ROOT = Path(__file__).resolve().parents[3]
ASM = ROOT / 'backports/striderex/asm'
CUES = ROOT / 'backports/striderex/manifests/ex_pack_cues.json'
MB = 1048576
EX_BASE = 1048576
FLAG_BLOCK = b'STRIDER-EX' + bytes([1, 0, 0, 0]) + b'\x00\x00'
STOCK_VBL = 1234
HOOKS = {'striderua': 37146, 'striderjr': 37008}
HOOK_BYTES = bytes.fromhex('1b7c00018cba')
STAGE_HOOKS = {'striderua': 37160, 'striderjr': 37022}
STAGE_HOOK_BYTES = bytes.fromhex('7000102d8cb2')
INTRO_CUT = {'striderua': dict(GLOBE=21804, INTRO_SKIP=38438, SND_RESET=18850, SND_STOP=18856, state0=37848), 'striderjr': dict(GLOBE=21818, INTRO_SKIP=38300, SND_RESET=18830, SND_STOP=18836, state0=37710)}
INTRO_SKIP_BYTES = bytes.fromhex('227c0091480043e9002030110240f0003b408c1a1b7c00048cdc1b7c00008cdd')
INTRO_STATE0_BYTES = bytes.fromhex('3b7c00008c74303c00014eb807de303c02004eb80e10303c03004eb80e10303c04004eb80e10303c000a4eb807de4eb80b3a3b7c00008c2c3b7c00008c2e3b7c00408c343b7c00008c363b7c00408c3c3b7c00008c3e3b7c00008c1a3b7c00008c1c3b7c00008c1e1b7c00028cdc')

def check_intro_cut(img, machine, syms):
    """The stage intros' stock addresses (INTRO_CUT): the EX bank's equates are the program's own, each with"""
    want = INTRO_CUT[machine]
    used = ('GLOBE', 'INTRO_SKIP') + (('SND_RESET', 'SND_STOP') if 'dz_i0' in syms else ())
    for name in used:
        if syms.get(name) != want[name]:
            sys.exit(f'{machine}: ex_bank.s {name} is {syms.get(name)}, not {want[name]:#x}')
    hook = HOOKS[machine]
    if img[hook + 6:hook + 12] != b'N\xb9' + want['GLOBE'].to_bytes(4, 'big') or img[hook + 12:hook + 14] != b'Nu':
        sys.exit(f"{machine}: the intro setup the first-entry step calls is not {want['GLOBE']:#x}")
    at = want['INTRO_SKIP']
    n = len(INTRO_SKIP_BYTES)
    calls = b'N\xb8' + want['SND_RESET'].to_bytes(2, 'big') + b'N\xb8' + want['SND_STOP'].to_bytes(2, 'big')
    if img[at:at + n] != INTRO_SKIP_BYTES or img[at + n:at + n + 8] != calls:
        sys.exit(f'{machine}: the dialogue skip path at {at:#x} has an unexpected shape')
    for name, cue in (('SND_RESET', 240), ('SND_STOP', 247)):
        a = want[name]
        if img[a:a + 4] != bytes.fromhex('303c00') + bytes([cue]) or img[a + 4] != 96:
            sys.exit(f'{machine}: {name} at {a:#x} is not the 0x{cue:02X} setter')
    s0 = want['state0']
    if img[s0:s0 + len(INTRO_STATE0_BYTES)] != INTRO_STATE0_BYTES:
        sys.exit(f'{machine}: intro state 0 at {s0:#x} has an unexpected shape')
    table = STAGE_HOOKS[machine] + 28
    for st in range(1, 5):
        entry = table + struct.unpack('>h', img[table + 2 * st:table + 2 * st + 2])[0]
        if img[entry:entry + 8] != bytes.fromhex('7000102d8cdc303b'):
            sys.exit(f'{machine}: stage {st} intro step at {entry:#x} has an unexpected shape')
        base = entry + 14
        s0_at = base + struct.unpack('>h', img[base:base + 2])[0]
        st2 = base + struct.unpack('>h', img[base + 2:base + 4])[0]
        if s0_at != s0:
            sys.exit(f'{machine}: stage {st} state 0 is {s0_at:#x}, not {s0:#x}')
        if img[st2:st2 + 14] != bytes.fromhex('4eb80e66102d8c7c08000004') + b'f\x00' or st2 + 14 + struct.unpack('>h', img[st2 + 14:st2 + 16])[0] != at:
            sys.exit(f'{machine}: stage {st} dialogue at {st2:#x} does not skip to {at:#x}')
STAGE_SCENES = {0: ['prologue', 'brief_st_petersburg'], 1: ['brief_siberia'], 2: ['brief_amazon'], 3: ['brief_aerial'], 4: ['flight', 'welcome_meio']}
CONTINUES = {'brief_st_petersburg': 'prologue', 'welcome_meio': 'flight'}
DESERT_SCENES = {5: ['intro_desert']}
ASM_DEFINES = []
OBJ_BASE = 33792
TITLE_SHOT = {'prologue': 10}
COPYRIGHT_SCENES = ('prologue', 'brief_st_petersburg')
STILLS = [(0, 'St. Petersburg'), (1, 'Siberian Wilderness'), (3, 'The Aerial Battleship'), (2, 'Adventure in Amazon'), (4, 'Third Moon')]
DESERT_STILL = (1, (5, 'Kyzylkum Desert'))
ENDING_STILL = ('ending', 'Ending')
MEIO_HOOKS = {'striderua': 217960, 'striderjr': 217264}
MEIO_HOOK_BYTES = bytes.fromhex('10280046b028001e67000022')
MEIO_FALL_BYTES = bytes.fromhex('0c280018001e6400')
CARD_AFTER = set()
CPS1_HZ = 59.637
STREAM_PAD = 16
SOUND_MEMBER = {'striderua': '09.12b', 'striderjr': 'sth_09.12a'}
X68K_ARCHIVE = ROOT / 'roms/x68000/Strider Hiryuu (1992)(Capcom).zip'
EX_GFX = ['strex_gfx.c25', 'strex_gfx.c27', 'strex_gfx.c29', 'strex_gfx.c31']

def sha(b):
    return hashlib.sha256(b).hexdigest()

def scene_window(census_run, cid, c, windows, hide):
    """The census frames a cinematic's stream plays: its window (manifests/ex_pack_cues.json window_s:"""
    t0 = c['cd_request_time']
    every = C.frames_for(census_run, t0, t0 + c['track_seconds'])
    idx = C.P.read_index(census_run)
    w0, w1 = windows[cid]
    inside = [f for f in every if w0 - 0.0005 <= float(idx[f]['time']) - t0 <= w1 + 0.0005]
    if not inside or abs(float(idx[inside[0]]['time']) - t0 - w0) > 0.001 or abs(float(idx[inside[-1]]['time']) - t0 - w1) > 0.001:
        sys.exit(f'{cid}: window {w0}-{w1} s does not begin and end on census frames')
    times = [float(idx[f]['time']) - t0 for f in inside]
    frames, j = ([], 0)
    for k in range(int((w1 - w0) * CPS1_HZ) + 2):
        want = w0 + k / CPS1_HZ
        if want > w1 + 0.5 / CPS1_HZ:
            break
        while j + 1 < len(inside) and abs(times[j + 1] - want) <= abs(times[j] - want):
            j += 1
        frames.append(inside[j])
    if len(set(frames)) != len(frames):
        sys.exit(f'{cid}: a census frame would show twice')
    writes = C.P.read_writes(census_run)

    def lit(f):
        return bool((C.reference(C.load_frame(census_run, f, hide), writes.get(f), 16) != C.BLACK).any())
    out = [f for f in every if f not in inside and lit(f)]
    if out:
        sys.exit(f'{cid}: the window leaves out census frames with a picture: {out[:5]}')
    tail = next((k for k, f in enumerate(reversed(frames)) if lit(f)))
    worst = max((abs(float(idx[f]['time']) - t0 - (w0 + k / CPS1_HZ)) for k, f in enumerate(frames)))
    return (every, frames, dict(window_s=[w0, w1], frames=len(frames), cut_before=every.index(inside[0]), cut_after=len(every) - 1 - every.index(inside[-1]), left_out=len(inside) - len(frames), worst_time_ms=round(1000 * worst, 2), tail_frames=tail))

def convert_scenes(census, ids):
    cat = json.loads((census / 'catalog/catalog.json').read_text())
    by = {c['id']: c for c in cat['cinematics']}
    windows = {r['id']: r['window_s'] for r in json.loads(CUES.read_text())['cinematics']['rows'] if 'window_s' in r}
    cv, out = (None, [])
    for cid in ids:
        c = by[cid]
        run = census / c['run']
        every = C.frames_for(run, c['cd_request_time'], c['cd_request_time'] + c['track_seconds'])
        hide = ()
        if cid in TITLE_SHOT:
            idx = C.P.read_index(run)
            t_title = c['cd_request_time'] + next((x['start_t'] for x in c['shots'] if x['shot'] == TITLE_SHOT[cid]))
            hide = frozenset((f for f in every if float(idx[f]['time']) >= t_title))
        every, frames, window = scene_window(run, cid, c, windows, hide)
        cont = None
        if cid in CONTINUES:
            if not out or out[-1]['id'] != CONTINUES[cid]:
                sys.exit(f'{cid} continues {CONTINUES[cid]}, which must be converted just before it')
            cont = out[-1]['fronts']
        at = {f: i for i, f in enumerate(every)}
        keep = [at[f] for f in frames]
        cv, stream, _ = C.convert(run, every, 16, cv or C.Converter(16, OBJ_BASE), hide_sprites=hide, keep=keep, cont=cont)
        idx = C.P.read_index(run)
        out.append(dict(id=cid, run=run, frames=frames, stream=stream, preroll=cv.preroll, pre_extra=cv.pre_extra, hide_sprites=hide, window=window, fronts=cv.fronts, continues=CONTINUES.get(cid), times=[round(float(idx[f]['time']) - c['cd_request_time'], 6) for f in frames]))
        print(f'converted {cid}: {len(stream)} bytes, pre-roll {cv.preroll}' + (f" ({cv.pre_extra} over the load's, C.PRE_EXTRA_MAX)" if cv.pre_extra else '') + f', window {window}' + (f', continues {CONTINUES[cid]} from its fronts {cont}' if cont else ''), flush=True)
    for s in out:
        cv.preroll = s['preroll']
        failures, _ = C.check(cv, s['stream'], s['frames'], s['run'], 16, s.get('hide_sprites', ()))
        if failures:
            sys.exit(f"{s['id']}: conversion check failed: {failures[:3]}")
        s['blanked'] = cv.blanked
        s['copyright'] = cv.copyright
        compress(s)
    shows = [s['id'] for s in out if s['copyright']]
    if shows != ([] if C.KEEP_COPYRIGHT else [i for i in ids if i in COPYRIGHT_SCENES]):
        sys.exit(f'the copyright line was taken from {shows}, not from the scenes that show it, {COPYRIGHT_SCENES}')
    if shows and cv.glyphs_seen != C.COPYRIGHT_GLYPHS:
        sys.exit(f'copyright glyphs never removed from a picture: {sorted(C.COPYRIGHT_GLYPHS - cv.glyphs_seen)}')
    print(f'SCROLL1 EX codes: {len(cv.s1_codes)} of {C.S1_LAST - C.S1_BASE + 1}', flush=True)
    return (cv, out)

def compress(s):
    lz = LZ.encode(s['stream'])
    if LZ.decode(lz, len(s['stream'])) != s['stream']:
        sys.exit(f"{s['id']}: LZ round trip failed")
    s['lz'] = lz
    s['timing'] = CT.report(CT.predict(s['stream'], lz))
    print(f"{s['id']}: jtcps1 handler worst {s['timing']['worst_lines']} lines (record {s['timing']['worst_record']})", flush=True)

def stage_stills(openings, rom_dir, desert, cv, ending=None):
    """The stage select's stills (STILLS, play order), per region: each stage's opening scene"""
    import mapper_testkit as K
    import stage_openings as SO
    snaps, rep = SO.load(openings, rom_dir)
    tiles = {m: SO.Tiles(TX.stock_gfx(K.pool([rom_dir / m])), desert['region'] if desert else None) for m in SO.SETS}
    dz = SO.desert_snapshot(desert, SO.camera_offsets(rep['openings'])) if desert else None
    if ending is not None:
        ex = bytearray(4 * G.MB)
        EE.install(ex, ending)
        progs = EE.stock_programs(rom_dir)
        end_tiles = {m: SO.Tiles(TX.stock_gfx(K.pool([rom_dir / m])), ex) for m in SO.SETS}
        end_snap = {m: SO.ending_snapshot(ending, progs[m], m, SO.camera_offsets(rep['openings'])) for m in SO.SETS}

    def one(m, st):
        if st == ENDING_STILL[0]:
            return SO.still(end_snap[m], end_tiles[m])
        return SO.still(dz if st == 5 else snaps[m, st], tiles[m])
    per = {m: [one(m, st) for st, _ in STILLS] for m in SO.SETS}
    codes = {1: (cv.solid('s1', 15), cv.solid('s1', 0)), 2: (cv.solid('s2', 15), cv.solid('s2', 0))}
    pals = SO.band_palettes([x for m in SO.SETS for x in per[m]])
    inc = {m: SO.stills_inc(per[m], codes, pals) for m in SO.SETS}
    data, stills = ({}, [])
    for m in SO.SETS:
        data[m] = []
        for x in per[m]:
            b = SO.band(x)
            pal = {}
            for addr, ws in SO.blocks(x):
                if addr < SO.PLAYER_MAP[1]:
                    pal.update({addr - SO.PLAYER_PAL + 2 * i: w for i, w in enumerate(ws)})
            data[m].append(dict(band_layer=b['layer'], word=b['word'], black=b['black'], palette=pal))
    for k, (st, name) in enumerate(STILLS):
        s = dict(id=f'still{k}', stage=st, name=name, page=['Select Stage', f'{k + 1} {name}'], still={m: dict(SO.report(per[m][k]), band_layer=f"SCROLL{data[m][k]['band_layer']}", layer_with_band=f"{data[m][k]['word']:#06x}", band_only=f"{data[m][k]['black']:#06x}") for m in SO.SETS})
        print(f"still{k} (stage {st}): {s['still']['striderua']['layers']}, {s['still']['striderua']['bytes']} bytes, band on {s['still']['striderua']['band_layer']}", flush=True)
        stills.append(s)
    band = dict(lines=[SO.BAND_TOP, SO.BAND_TOP + SO.BAND_LINES - 1], codes={f'SCROLL{L}': dict(transparent=f'{c[0]:#06x}', black=f'{c[1]:#06x}') for L, c in codes.items()}, palettes={f'SCROLL{L}': p for L, p in pals.items()}, fade_levels=[f'{v:X}' for v in SO.FADE_LEVELS])
    return (stills, inc, data, dict(capture={k: v['sha256'] for k, v in rep['openings'].items()}, desert_camera=dz['camera'] if dz else None, band=band))

def handler_timing(scenes, cap_report):
    """Every stream's VBlank handlers on jtcps1 (cinematic_timing.predict), with each caption"""
    pages = [(q['lang'], [tuple(e) for e in q['entries']]) for q in cap_report['pages_detail']]
    out = {}
    for s in scenes:
        rows = {}
        for lang in cap_report['schedules'].get(s['id'], {}) or ('en', 'ja'):
            sched = cap_report['schedules'].get(s['id'], {}).get(lang, [])
            rows[lang] = CT.report(CT.predict(s['stream'], s['lz'], sched, pages))
        worst = max(rows.values(), key=lambda r: r['worst_lines'])
        out[s['id']] = dict(worst_lines=worst['worst_lines'], worst_record=worst['worst_record'], over_plan=max((r['over_plan'] for r in rows.values())), handlers=worst['handlers'])
        if any((r['over_limit'] for r in rows.values())):
            sys.exit(f"{s['id']}: a VBlank handler would take {worst['worst_lines']} jtcps1 lines at record {worst['worst_record']} (limit {CT.HANDLER_LIMIT} of {CT.LINES_PER_FRAME})")
    return out

def card_length(census):
    """Frames of the EX title card: the prologue track from its title shot (TITLE_SHOT) to its end. The"""
    cat = {c['id']: c for c in json.loads((census / 'catalog/catalog.json').read_text())['cinematics']}
    c = cat['prologue']
    start = next((x['start_t'] for x in c['shots'] if x['shot'] == TITLE_SHOT['prologue']))
    return round((c['track_seconds'] - start) * CPS1_HZ)

def nopack_cues(cues):
    """Nonzero native music slots; continuous mode must score every opening."""
    sec = cues.get('nopack_intros', {})
    out = {r['id']: int(r['cue'], 16) for r in sec.get('rows', [])}
    known = {r['id'] for r in cues['cinematics']['rows']}
    if len(out) != len(sec.get('rows', [])):
        sys.exit('nopack_intros: duplicate scene')
    for sid, c in out.items():
        if sid not in known or not 0 < c <= 47:
            sys.exit(f'nopack_intros: {sid} cue {c:#04x} is not a stock music command of a cinematic')
    if sec.get('mode') == 'continuous-native' and set(out) != known - {'ending'}:
        sys.exit('nopack_intros: continuous score must cover all opening cinematics')
    if out:
        m = re.search('^NP_STOP\\s+equ\\s+\\$([0-9A-Fa-f]{2})', (ASM / 'ex_bank.s').read_text(), re.M)
        if not m or int(m.group(1), 16) != int(sec['stop'], 16):
            sys.exit(f"nopack_intros: stop {sec.get('stop')} is not asm/ex_bank.s NP_STOP")
    return out

def stage_lists(scenes, cues, card_frames):
    """stage_lists.inc: the scene table, the per-stage lists (0xFE = the EX title card, D17) and"""
    ix = {s['id']: i for i, s in enumerate(scenes)}
    rows = {r['id']: r for r in cues['cinematics']['rows']}
    ctrl = int(cues['cps_plus_control_region']['start'], 16)
    lines = ['scenes:']
    for s in scenes:
        r = rows[s['id']]
        if any((int(r[k], 16) >= ctrl for k in ('ja', 'en'))):
            sys.exit(f"{s['id']}: cue {r['ja']}/{r['en']} lies in the CPS+ control region ({ctrl:#04x} up)")
        lines.append(f"        dc.l    stream_{s['id']}")
        lines.append(f"        dc.w    ${int(r['ja'], 16):04X},${int(r['en'], 16):04X}  ; Japanese, English cue")
    nopack = nopack_cues(cues)
    lines.append('nopack_cues:                            ; native music by scene, 0 = silent')
    lines.append('        dc.b    ' + ','.join((f"${nopack.get(s['id'], 0):02X}" for s in scenes)))
    lines.append('        even')
    lines.append('stage_cines:')
    for st in sorted(STAGE_SCENES):
        lines.append(f'        dc.w    list{st}-stage_cines')
    for st in sorted(STAGE_SCENES):
        have = []
        for i in STAGE_SCENES[st]:
            if i in ix:
                if ix[i] >= 64:
                    sys.exit('the stage lists take scene numbers below 0x40')
                prev = bool(have) and have[-1] != 254 and scenes[have[-1] & 63]['id']
                have.append(ix[i] | (64 if prev and CONTINUES.get(i) == prev else 0))
                if i in CARD_AFTER:
                    have.append(254)
        lines.append(f'list{st}:  dc.b    ' + ','.join((str(i) for i in have + [255])))
    lines.append('        even')
    lines.append(f'CARD_FRAMES equ {card_frames}                ; the prologue track after its last shot (D17)')
    for s in scenes:
        lines += [f"stream_{s['id']}:", f'''        incbin  "scene_{s['id']}.lz"''', f'        dcb.b   {STREAM_PAD},0', '        even']
    return '\n'.join(lines) + '\n'
USA_DRAW_HOOK = (23596, bytes.fromhex('3b7c00008c3c'))
USA_SLICE_HOOK = (20620, bytes.fromhex('61000cb061000d3e'))
SPLIT_S3 = (16256, 16351)
TITLE_HOOKS = {'striderjr': (23854, bytes.fromhex('51cfffda4e75'), 'jmp')}
SLASH_HOOKS = {'striderua': (19396, bytes.fromhex('303c003b6000fda4'))}
STAGESEL_HOOK = (9552, bytes.fromhex('4a2d8c8667000046'))
RANK_HOOK = (13698, bytes.fromhex('303c000b3c3c0009'))
COIN_HOOKS = {'striderua': (20154, bytes.fromhex('61000cec303c0001')), 'striderjr': (20134, bytes.fromhex('61000ebc303c0001'))}
COIN_TEXT = {14834: b'1 PLAYER ONLY', 14851: b'1 OR 2 PLAYERS', 14869: b'PUSH START BUTTON)'}
COIN_ROWS = {'striderua': {14834: 19, 14851: 19, 14869: 21}, 'striderjr': {14834: 22, 14851: 22, 14869: 23}}

def native_fade_frames(scenes):
    by_id = {s['id']: s for s in scenes}
    last = [STAGE_SCENES[i][-1] for i in range(5)] + ['intro_desert']
    return [by_id[s]['preroll'] + by_id[s]['window']['frames'] - FADE_LEAD if s in by_id else 0 for s in last]

def assemble_bank(vasm, work, scenes, cues, region_en, title_cells, ending, captions, card_frames, split, stills):
    fade = native_fade_frames(scenes)
    prologue = next((s for s in scenes if s['id'] == 'prologue'), None)
    cut = logo_trim(prologue['stream'])['cut_record'] if prologue else 0
    (work / 'native_fade_frames.inc').write_text('        dc.w    ' + ','.join(map(str, fade)) + '\nOPENING_CUT_RECORD equ ' + str(cut) + '\n')
    (work / 'stills.inc').write_text(stills)
    for s in scenes:
        (work / f"scene_{s['id']}.lz").write_bytes(s['lz'])
        (work / f"scene_{s['id']}.bin").write_bytes(s['stream'])
    (work / 'stage_lists.inc').write_text(stage_lists(scenes, cues, card_frames))
    (work / 'title_cells.inc').write_text(TX.cells_inc(title_cells))
    (work / 'split_cells.inc').write_text(split)
    (work / 'ending_data.inc').write_text(EE.data_inc(ending))
    (work / 'captions.inc').write_text(captions)
    out, lst = (work / f'ex_bank_{region_en}.bin', work / f'ex_bank_{region_en}.lst')
    subprocess.run([*assembly_command(vasm), '-Fbin', '-m68000', '-quiet', '-I', str(ASM), '-I', str(work), f'-DREGION_EN={region_en}', *ASM_DEFINES, '-L', str(lst), '-o', str(out), str(ASM / 'ex_bank.s')], cwd=work, check=True)
    syms = {}
    for line in lst.read_text().splitlines():
        f = line.split()
        if len(f) == 2 and f[1][:2] in ('A:', 'E:'):
            syms[f[0]] = int(f[1][2:], 16)
    code = out.read_bytes()
    if len(code) > MB - len(FLAG_BLOCK):
        sys.exit(f'EX bank overflow: {len(code)} bytes')
    bank = bytearray(b'\xff' * MB)
    bank[:len(code)] = code
    bank[MB - 16:] = FLAG_BLOCK
    return (bytes(bank), syms, len(code))
BOOT_PAL_SIG = bytes.fromhex('3C3C001F41FA003043F9009144007E034CD8000348D1000343E9000851CFFFF251CEFFEC')
BOOT_PAL_OFFSETS = (160, 416)
BOOT_PALETTE = {'striderua': {1: 64767, 3: 63405, 0: 61734}, 'striderjr': {1: 65532, 3: 64901, 0: 63520}}

def boot_palette(img, machine):
    """The boot test screen's text colors (BOOT_PALETTE); returns what changed."""
    prog = bytes(img[:1048576])
    at = prog.find(BOOT_PAL_SIG)
    if at < 0 or prog.find(BOOT_PAL_SIG, at + 1) >= 0:
        sys.exit(f'{machine}: the boot palette loader is not where it is expected (once)')
    table = at + 6 + 48
    out = {}
    for off in BOOT_PAL_OFFSETS:
        for pen, word in BOOT_PALETTE[machine].items():
            a = table + off + 2 * pen
            if img[a:a + 2] != b'\xfa\xaa':
                sys.exit(f'{machine}: boot palette word {a:#x} is not the stock 0xFAAA')
            img[a:a + 2] = word.to_bytes(2, 'big')
            out[f'{off:#05x}_pen{pen}'] = dict(addr=f'{a:#x}', word=f'{word:#06x}')
    return out

def patch_meio(img, machine, syms):
    """TEST ONLY (--test-ending), after every other program patch: Meio's hit check -> jsr ss_meio, nop"""
    at = MEIO_HOOKS[machine]
    if img[at:at + 12] != MEIO_HOOK_BYTES or img[at + 34:at + 42] != MEIO_FALL_BYTES:
        sys.exit(f"{machine}: Meio's hit check at {at:#x} has an unexpected shape")
    img[at:at + 8] = b'N\xb9' + syms['ss_meio'].to_bytes(4, 'big') + b'Nq'
    return f'{at:#x}'

def patch_program(img, machine, syms):
    if int.from_bytes(img[104:108], 'big') != STOCK_VBL:
        sys.exit(f'{machine}: level-2 autovector is not the stock 0x4D2')
    img[104:108] = syms['ex_vbl'].to_bytes(4, 'big')
    at = HOOKS[machine]
    if img[at:at + 6] != HOOK_BYTES or img[at + 6:at + 8] != b'N\xb9':
        sys.exit(f'{machine}: intro flag store at {at:#x} has an unexpected shape')
    img[at:at + 6] = b'N\xb9' + syms['cine_hook'].to_bytes(4, 'big')
    at = STAGE_HOOKS[machine]
    if img[at:at + 6] != STAGE_HOOK_BYTES or img[at - 2:at] != b'Nu' or at - HOOKS[machine] != 14:
        sys.exit(f'{machine}: the intro task step at {at:#x} has an unexpected shape')
    check_intro_cut(img, machine, syms)
    img[at:at + 6] = b'N\xb9' + syms['stage_hook'].to_bytes(4, 'big')
    if machine in TITLE_HOOKS:
        at, stock, kind = TITLE_HOOKS[machine]
        if img[at:at + len(stock)] != stock:
            sys.exit(f'{machine}: title hook site at {at:#x} has an unexpected shape')
        img[at:at + len(stock)] = (b'N\xb9' if kind == 'jsr' else b'N\xf9') + syms['title_hook'].to_bytes(4, 'big') + b'Nq' * ((len(stock) - 6) // 2)
    at, stock = COIN_HOOKS[machine]
    if img[at:at + 8] != stock:
        sys.exit(f'{machine}: coin screen setup end at {at:#x} has an unexpected shape')
    img[at:at + 8] = b'N\xb9' + syms['coin_hook'].to_bytes(4, 'big') + b'Nq'
    at, stock = STAGESEL_HOOK
    if img[at:at + 8] != stock:
        sys.exit(f'{machine}: debug-start check at {at:#x} has an unexpected shape')
    img[at:at + 8] = b'N\xf9' + syms['stage_sel'].to_bytes(4, 'big') + b'Nq'
    at, stock = RANK_HOOK
    if img[at:at + 8] != stock:
        sys.exit(f'{machine}: rank routine at {at:#x} has an unexpected shape')
    img[at:at + 8] = b'N\xf9' + syms['rank_check'].to_bytes(4, 'big') + b'Nq'
    if machine == 'striderua':
        for (at, stock), sym, tail in ((USA_DRAW_HOOK, 'usa_draw', b''), (USA_SLICE_HOOK, 'usa_slice', b'Nq')):
            if img[at:at + len(stock)] != stock:
                sys.exit(f'{machine}: {sym} site at {at:#x} has an unexpected shape')
            img[at:at + 6 + len(tail)] = b'N\xb9' + syms[sym].to_bytes(4, 'big') + tail
    if machine in SLASH_HOOKS:
        at, stock = SLASH_HOOKS[machine]
        if img[at:at + 8] != stock or img[19922:19926] != bytes.fromhex('303c0081'):
            sys.exit(f'{machine}: slash sound stub at {at:#x} has an unexpected shape')
        img[at:at + 6] = b'N\xf9' + syms['slash_snd'].to_bytes(4, 'big')
    for at, text in COIN_TEXT.items():
        if img[at + 1] not in (10, 12) or img[at + 3:at + 3 + len(text) + 1] != text + b'\x00':
            sys.exit(f'{machine}: coin screen string at {at:#x} has an unexpected shape')
        img[at + 1] = COIN_ROWS[machine][at]

def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('--rom-dir', type=Path, required=True)
    p.add_argument('--census', type=Path, required=True)
    p.add_argument('--vasm', type=Path, required=True)
    p.add_argument('--out', type=Path, required=True)
    p.add_argument('--x68k-archive', type=Path, default=X68K_ARCHIVE, help='Strider Hiryuu (1992)(Capcom).zip, the X68000 disks (restored tunes)')
    p.add_argument('--scenes', default=','.join((x for v in STAGE_SCENES.values() for x in v)))
    p.add_argument('--portraits', type=Path, help='PC Engine portrait capture (scripts/portrait_pce.py capture); without it no portraits')
    p.add_argument('--desert-census', type=Path, help='PC Engine desert checkpoint census (pce_desert_maps.py input): build the desert extra stage')
    p.add_argument('--openings', type=Path, required=True, help='the stage openings capture (stage_openings.py capture; pinned by manifests/stage_openings.json)')
    p.add_argument('--ready-places', choices=RX.PLACES, default='equal', help="READY's per-stage places: equal (the build), or ready_gate.py's controls from this tree, uniform (every stage at build 42's place) or stock (every stage at the stock row)")
    p.add_argument('--test-ending', action='store_true', help='TEST ONLY, never a release: the stage select gets a last entry, ENDING, that plays the ending as after clearing Third Moon (ENDING_STILL, MEIO_HOOKS); default off')
    p.add_argument('--cinematic-score', choices=('amazon', 'original'), default='amazon', help='native no-pack score: selected alternate Amazon loop, or experimental Shadow Signal')
    p.add_argument('--keep-copyright', action='store_true', help="GATE CONTROL ONLY, never a release: keep the PC Engine title's copyright line (cinematic_convert.KEEP_COPYRIGHT), so start_flow_gate.py --copyright-control is this tree with only the line put back; default off")
    p.add_argument('--pce-sfx', type=Path, help='a pce_sfx.py capture: the PC Engine effects as OKI samples on 0xB0-0xB3 (manifests/pce_sfx.json), sent by the desert actors; without it, none')
    p.add_argument('--no-boss-scene', action='store_true', help='GATE CONTROL ONLY, never a release: the in-play portraits instead of the boss scenes.')
    p.add_argument('--boss-scene', action='store_true', help=argparse.SUPPRESS)
    a = p.parse_args()
    C.KEEP_COPYRIGHT = a.keep_copyright
    a.boss_scene = bool(a.portraits) and (not a.no_boss_scene)
    if a.no_boss_scene and a.boss_scene:
        sys.exit('--no-boss-scene with --boss-scene')
    if a.desert_census:
        STAGE_SCENES.update(DESERT_SCENES)
        a.scenes += ''.join((',' + x for x in DESERT_SCENES[5] if x not in a.scenes.split(',')))
        STILLS.insert(*DESERT_STILL)
    if a.test_ending:
        STILLS.append(ENDING_STILL)
        ASM_DEFINES.append('-DENDTEST=1')
    out = a.out.resolve()
    out.mkdir(parents=True, exist_ok=False)
    work = out / 'work'
    work.mkdir()
    cues = json.loads(CUES.read_text())
    desert = None
    if a.desert_census:
        import desert_ex as DX
        desert = DX.prepare(a.desert_census.resolve(), a.rom_dir.resolve())
    cv, scenes = convert_scenes(a.census.resolve(), a.scenes.split(','))
    ending = EE.build(a.rom_dir.resolve(), a.census.resolve() / 'ending')
    stills, stills_inc, stills_data, stills_report = stage_stills(a.openings.resolve(), a.rom_dir.resolve(), desert, cv, ending if a.test_ending else None)
    (out / 'stills.json').write_text(json.dumps(stills_data) + '\n')
    card_frames = card_length(a.census.resolve())
    (out / 'blanked.json').write_text(json.dumps({s['id']: dict(preroll=s['preroll'], frames={str(k): v for k, v in s['blanked'].items()}) for s in scenes}) + '\n')
    (out / 'copyright.json').write_text(json.dumps({s['id']: dict(preroll=s['preroll'], frames={str(k): [f, len(px), px[0][0], px[-1][0]] for k, (f, px) in s['copyright'].items()}) for s in scenes}) + '\n')
    (out / 'frames.json').write_text(json.dumps({s['id']: dict(preroll=s['preroll'], cue_record=s['preroll'] + 0.5, census=[[f, t] for f, t in zip(s['frames'], s['times'])]) for s in scenes}) + '\n')
    report = dict(card_frames=card_frames, scenes=[dict(id=s['id'], stream_bytes=len(s['stream']), lz_bytes=len(s['lz']), stream_sha256=sha(s['stream']), preroll=s['preroll'], pre_extra=s['pre_extra'], window=s['window'], cue_record=s['preroll'] + 0.5, continues=s['continues'], last_fronts=s['fronts'], blanked=dict(frames=len(s['blanked']), pixels=sum((len(v) for v in s['blanked'].values()))), copyright=dict(frames=len(s['copyright']), pixels=sum((len(v[1]) for v in s['copyright'].values())))) for s in scenes], sets={}, stills=dict(stills_report, entries={s['id']: dict(stage=s['stage'], name=s['name'], **s['still']) for s in stills}))
    import mapper_testkit as K
    blocks_end = SX.high_water(cv)['blocks'][1]
    if blocks_end >= US.S2_FIRST:
        sys.exit(f"cinematic sprite tiles reach {blocks_end:#06x}, into the USA split's SCROLL2 {US.S2_FIRST:#06x} up")
    if cv.next_s2 > TX.S2_FIRST:
        sys.exit(f"cinematic SCROLL2 tiles reach {cv.next_s2 - 1:#06x}, into the title marks' {TX.S2_FIRST:#06x} up")
    stock_gfx = TX.stock_gfx(K.pool([a.rom_dir.resolve() / 'striderua']))
    ua_files = {q.name: q.read_bytes() for q in (a.rom_dir.resolve() / 'striderua').iterdir() if q.is_file()}
    ua_prog = RF.compose(ua_files, RF.SETS['striderua'])
    s3, s2, _ = US.split(ua_prog, stock_gfx, TX.stock_tile, *SPLIT_S3)
    bad = US.check_halves(stock_gfx, TX.stock_tile, ua_prog, s3, s2)
    if bad:
        sys.exit(f'USA logo split: {bad}')
    US.install(cv.region, s3, s2)
    split_text = US.split_inc(s3, s2)
    report['usa_split'] = dict(s3_cells=len(s3), s3_composites=sum((p is not None for *_, p in s3)), s2_tiles=len(s2))
    split_base = {a: (c, p) for a, _, c, p in s3 if p is not None}
    title_cells = TX.install(cv.region, stock_gfx, {'us': split_base})
    report['usa_mark'] = TX.mark_fades(stock_gfx, ua_prog, split_base)
    report['title_cells'] = {m: [dict(map_byte=f'{x:#08x}', stock=f'{y:#06x}', ex=f'{z:#06x}') for x, y, z in v] for m, v in title_cells.items()}
    report['ending'] = EE.install(cv.region, ending)
    earth_graphics = ET.install(cv.region, stock_gfx)
    import earth_tip as ETP
    earth_tip_graphics = ETP.install(cv.region, stock_gfx)
    import stage_openings as SO
    captions, cap_report = SX.prepare(cv, scenes, a.census.resolve(), a.rom_dir.resolve(), [s['page'] for s in stills], (SO.BAND_TOP, SO.BAND_LINES))
    (out / 'captions.json').write_text(json.dumps(cap_report, indent=1, ensure_ascii=False) + '\n')
    report['captions'] = dict(codes_used=cap_report['codes_used'], pages=cap_report['pages'], manifest_sha256=cap_report['manifest_sha256'], captions_inc_sha256=sha(captions.encode()))
    report['jtcps1_handler_lines'] = dict(plan=CT.HANDLER_LINES, limit=CT.HANDLER_LIMIT, frame=CT.LINES_PER_FRAME, scenes=handler_timing(scenes, cap_report))
    report['scroll1_codes'] = dict(used=len(cv.s1_codes), available=C.S1_LAST - C.S1_BASE + 1)
    portraits = PX.prepare(cv, a.portraits.resolve() if a.portraits else None)
    report['portraits'] = portraits.report
    if a.desert_census:
        if RX.desert_bottom() != RX.NAME_BOTTOM[5]:
            sys.exit(f'the desert caption ends on line {RX.desert_bottom()}, not ready_ex.NAME_BOTTOM[5]')
        if not (portraits.report or {}).get('enabled'):
            sys.exit("the desert needs the portraits (--portraits): section 1 shows the officer's")
        import desert_actors_ex as DA
        report['desert'] = DX.install(cv.region, desert, DA.claims(cv, portraits.report))
        DX.write_includes(work, desert, DX.respawn_syms(a.vasm, work, a.rom_dir.resolve()))
        ASM_DEFINES.append('-DDESERT=1')
    scene_of = None
    if a.boss_scene:
        import boss_scene as BSC
        import desert_actors_ex as DA
        boss = BSC.prepare(lambda m: BSC.stock_image(a.rom_dir.resolve(), m), stock_gfx, portraits)
        taken = DA.claims(cv, portraits.report)
        if a.desert_census:
            taken['desert_actors'] = [int(v, 16) for v in report['desert']['actors']['codes']]
        report['boss_scene'] = BSC.install(cv.region, boss, taken)
        scene_of = {s['portrait']: k for k, s in enumerate(BSC.scenes_in_build())}
        ASM_DEFINES.append('-DBOSS_SCENE=1')
    gfx = G.split_region(cv.region)
    snd, snd_sets = RT.load_sound(a.rom_dir.resolve())
    bank, bank_info = RT.load_bank(a.x68k_archive)
    sound, sound_report = RT.build_patch(snd, bank)
    sound, loop_report = EE.loop_song(sound)
    cinematic_report = None
    if cues.get('nopack_intros', {}).get('mode') == 'continuous-native':
        import cinematic_music as CM
        if set(nopack_cues(cues).values()) != {CM.COMMAND}:
            sys.exit('continuous score cue differs from installed cinematic song')
        if a.cinematic_score == 'original':
            import original_cinematic as OC
            sound, cinematic_report = OC.install(sound, CM.COMMAND)
        else:
            sound, cinematic_report = CM.install(sound, bank)
    elif a.cinematic_score == 'original':
        sys.exit('original score requires continuous-native scene cueing')
    report['sound'] = dict(sha256=sha(sound), changes=sound_report.get('table_entries_changed'), bytes_changed=sound_report.get('bytes_changed'), x68k=bank_info, ending_loop=loop_report)
    if cinematic_report:
        report['sound']['cinematic_music'] = cinematic_report
    samples = None
    if a.pce_sfx:
        import pce_sfx as PS
        cap = a.pce_sfx.resolve()
        cap_info = PS.check_inputs(cap)
        conv = PS.convert(PS.clips(cap))
        ua = a.rom_dir.resolve() / 'striderua'
        stock_oki = b''.join(((ua / n).read_bytes() for n in PS.SAMPLE_MEMBERS['striderua']))
        before = sound
        sound, samples, sfx_report = PS.install(sound, stock_oki, conv)
        report['pce_sfx'] = dict(capture=dict(mame_version=cap_info['mame_version'], **{k: cap_info[k] for k in PS.manifest()['inputs'] if k != 'note'}), effects={c['id']: dict(command=f"{c['command']:#04x}", bytes=c['bytes'], adpcm_sha256=c['adpcm_sha256'], snr_db=c['snr_db'], **c['plan']) for c in conv.values()}, sound_before_sha256=sha(before), sound_sha256=sha(sound), samples_sha256=sha(samples), **sfx_report)
        report['sound']['sha256'] = sha(sound)
        ASM_DEFINES.append('-DPCE_SFX=1')
    for machine, layout in RF.SETS.items():
        region_en = 1 if machine == 'striderua' else 0
        (work / 'portraits.inc').write_text(PX.inc_text(portraits, machine, a.rom_dir.resolve(), scene_of))
        if a.boss_scene:
            (work / 'boss_scene.inc').write_text(BSC.inc_text(boss, machine, True))
        (work / 'ready.inc').write_text(RX.inc_text(machine, a.ready_places))
        bank, syms, used = assemble_bank(a.vasm, work, scenes, cues, region_en, title_cells[machine], ending, captions, card_frames, split_text, stills_inc[machine])
        src = a.rom_dir.resolve() / machine
        files = {q.name: q.read_bytes() for q in src.iterdir() if q.is_file()}
        sizes = {n: len(files[n]) for n, _, _ in layout}
        img = RF.compose(files, layout)
        fix = RF.patch_image(img, a.vasm, work)
        patch_program(img, machine, syms)
        boot_pal = boot_palette(img, machine)
        ready_patches = RX.patch_program(img, machine, syms, a.ready_places)
        ending_patches = EE.patch_program(img, machine, syms, ending)
        earth_palette = EP.patch_image(img, machine)
        earth_tile = dict(graphics=earth_graphics, mapping=ET.patch_image(img, machine))
        earth_tip = dict(graphics=earth_tip_graphics, mapping=ETP.patch(img, machine), translation_pixels=[ETP.SHIFT_X, 0], original_pixels_preserved=True)
        portrait_patches = PX.patch_program(img, machine, syms, portraits)
        desert_patches = DX.patch_program(img, machine, syms, desert) if desert else None
        meio = patch_meio(img, machine, syms) if a.test_ending else None
        d = out / machine
        d.mkdir()
        changed = {n: b for n, b in RF.decompose(img, layout, sizes).items() if b != files[n]}
        for n, b in changed.items():
            (d / n).write_bytes(b)
        p6 = bytes((b for i in range(0, MB, 2) for b in (bank[i + 1], bank[i])))
        (d / 'strex_p6.bin').write_bytes(p6)
        (d / SOUND_MEMBER[machine]).write_bytes(sound)
        if samples is not None:
            names = PS.SAMPLE_MEMBERS[machine]
            if b''.join((files[n] for n in names)) != stock_oki:
                sys.exit(f"{machine}: its sample ROMs are not striderua's")
            for n, b in zip(names, PS.split_oki(samples)):
                (d / n).write_bytes(b)
        for n, b in zip(EX_GFX, gfx):
            (d / n).write_bytes(b)
        report['sets'][machine] = dict(ex_bank_bytes_used=used, ex_vbl=f"{syms['ex_vbl']:#x}", cine_hook=f"{syms['cine_hook']:#x}", streams={s['id']: syms[f"stream_{s['id']}"] for s in scenes}, cues={s['id']: [int(r, 16) for r in (next((x for x in cues['cinematics']['rows'] if x['id'] == s['id']))[k] for k in ('ja', 'en'))] for s in scenes}, nopack_cues={k: v for k, v in nopack_cues(cues).items() if k in {s['id'] for s in scenes}}, nopack_cues_at=f"{syms['nopack_cues']:#x}", native_fade=dict(address=syms['np_fade_tick'], end=syms['np_native_end'], call=syms['sound'], frames=FADE_LEAD, interval=FADE_INTERVAL), native_opening=next((logo_trim(s['stream']) for s in scenes if s['id'] == 'prologue'), None), native_reading=dict(address=syms['np_read_tick'], end=syms['np_read_end'], hold_frames=120, pause_records=[1851, 1340, 1712, 1385, 0, 1169], caption_off_records=[1851, 1340, 1712, 1385, 0, 1193], fade_elapsed_records=[1818, 1297, 1739, 1338, 1957, 1129]), region_en=region_en, respawn_fix=fix, ending_patches=ending_patches, earth_palette=earth_palette, earth_tile=earth_tile, earth_tip=earth_tip, portrait_patches=portrait_patches, boot_palette=boot_pal, desert_patches=desert_patches, ready_patches=ready_patches, intro_cut=dict({k: f'{v:#x}' for k, v in INTRO_CUT[machine].items()}, stage_hook=f"{syms['stage_hook']:#x}", intro_cut=f"{syms['intro_cut']:#x}", intro_black=f"{syms['intro_black']:#x}"), desert_syms={k: syms[k] for k in ('dz_cap_spawn', 'dz_cap_record', 'dz_i0', 'dz_fade_in')} if desert else None, stage_select_syms={k: syms[k] for k in ('stage_sel', 'ss_screen', 'ss_buttons', 'rank_check', 'ss_frame', 'ss_write', 'ss_fade', 'ss_vbl', 'ss_snaps')}, files={q.name: sha(q.read_bytes()) for q in sorted(d.iterdir())})
        import cinematic_reading as CR
        import cinematic_followup as CF
        CR.contract(bank, report['sets'][machine], scenes)
        if syms['cine_step'] != 1048576 + CF.READING_STEP[machine] or syms['obj_flip'] != (1051190 if region_en else 1051030) or sha(bank[CF.READING_START:CF.READING_START + CF.READING_SIZE]) != CF.READING_HELPER[machine]:
            raise ValueError('native reading helper no longer matches the fixed player layout')
        if a.boss_scene:
            report['sets'][machine]['boss_scene_syms'] = {k: syms[k] for k in ('bs_vbl', 'bs_nop', 'bs_ctl', 'bs_play', 'bs_play_stage', 'bs_table', 'bs_portrait', 'pt_arm')}
        if a.test_ending:
            report['sets'][machine]['test_ending'] = dict(meio_hook=meio, ss_meio=f"{syms['ss_meio']:#x}")
        print(machine, 'EX bank', used, 'bytes; changed', sorted(changed), flush=True)
    if a.test_ending:
        import stage_openings as SO
        report['test_ending'] = dict(what="TEST ONLY: the stage select's last entry, ENDING, plays the ending as after clearing Third Moon", entry=len(STILLS) - 1, stage=4, area=10, still=SO.ENDING_STILL, meio_hooks={m: f'{v:#x}' for m, v in MEIO_HOOKS.items()})
    (out / 'build.json').write_text(json.dumps(report, indent=1) + '\n')
    return 0
if __name__ == '__main__':
    sys.exit(main())
