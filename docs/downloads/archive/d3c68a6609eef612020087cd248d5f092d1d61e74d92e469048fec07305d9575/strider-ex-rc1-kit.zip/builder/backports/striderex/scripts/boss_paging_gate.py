"""Qualify boss page continuity, row positions, voices and frozen game state."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import json
from pathlib import Path
import struct
import boss_paging as P
import boss_scene as S
import boss_scene_binary as BB
import boss_scene_gate as B
import desert_gate as G
from boss_voice_gate import inventory, sha
from boss_mouth_gate import picture

def page(bank, at):
    strips = []
    for i in range(BB.word(bank, at + 42)):
        x, y, vx, vy, life, n = struct.unpack_from('>HHhhHH', bank, at + 44 + 12 * i)
        strips.append(dict(x=x, y=y, vx=vx, vy=vy, life=life, n=n))
    pos = at + 44 + 12 * len(strips)
    entries = []
    for _ in range(2):
        n = BB.word(bank, pos)
        pos += 2
        entries.append([list(struct.unpack_from('>4H', bank, pos + 8 * k)) for k in range(n)])
        pos += 8 * n
    return dict(hold=BB.word(bank, at + 4) - S.HOLD_FROM, strips=strips, ui=list(struct.unpack_from('>16H', bank, at + 10)), before=entries[0], after=entries[1])

def gate(a):
    final = a.border_control or a.build
    meta = P.audit(a.control, a.paging_build or final)
    if a.paging_build:
        import desert_cadence_fix as C
        meta = C.audit(a.paging_build, final)
    if a.border_control:
        import boss_border as F
        meta = F.audit(a.border_control, a.build)
    _, files = inventory(a.build)
    rt = json.loads((a.runtime / 'runtime.json').read_text())
    binary = Path(rt['binary'])
    if sha(binary.read_bytes()) != rt['binary_sha256']:
        raise ValueError('runtime changed')
    work = a.workdir.resolve()
    work.mkdir(parents=True, exist_ok=a.reuse)
    prior = json.loads(a.routing_receipt.read_text())
    scenarios = {s['id']: s['gate'] for s in S.manifest()['scenes']}
    selected = a.scenes.split(',') if a.scenes else list(BB.IDS)
    jobs = []
    for m, set_name in (('striderua', 'striderus01'), ('striderjr', 'striderjs01')):
        for pack in (False, True):
            label = m + ('_pack' if pack else '_native')
            variant = work / 'variants' / label
            f = dict(files[m])
            p6 = bytearray(f['strex_p6.bin'])
            p6[-2] = p6[-2] & ~7 | int(pack)
            f['strex_p6.bin'] = bytes(p6)
            if not a.reuse or not (variant / 'build.json').exists():
                d = variant / m
                d.mkdir(parents=True)
                for n, b in f.items():
                    (d / n).write_bytes(b)
                vm = dict(meta, sets={m: dict(meta['sets'][m], files={n: sha(b) for n, b in f.items()})})
                (variant / 'build.json').write_text(json.dumps(vm) + '\n')
                G.stage_sets(variant, set_name, a.hbmame, a.rom_dir.resolve(), work / 'sets' / label)
            _, staged = inventory(variant)
            banks = list((work / 'sets' / label / set_name).glob('*.p6'))
            if staged[m] != f or len(banks) != 1 or banks[0].read_bytes() != f['strex_p6.bin']:
                raise ValueError('staged paging variant differs')
            for sid in selected:
                old = next((r for r in prior['results'] if r['machine'] == m and r['pack'] == pack and (not r['override']) and (r['scene'] == sid)))
                jobs.append((m, set_name, pack, label, sid, old))

    def run(job):
        m, set_name, pack, label, sid, old = job
        f = files[m]
        p6 = f['strex_p6.bin']
        bank = bytes((p6[k ^ 1] for k in range(len(p6))))
        record = next((s for s in BB.scenes(bank) if s['id'] == sid))
        E = old['entry']
        N = record['total']
        sc = scenarios[sid]
        n = sc['frames'] + N + 300
        out = work / 'runs' / label / sid
        if a.discover_entry:
            discovery = work / 'discovery' / label / sid
            if not a.reuse or not (discovery / 'mame.log').exists():
                B.run(binary, work / 'sets' / label, set_name, discovery, sc, n, sc['inputs'], holds=B.holds_env(B.research_writes(sc)))
            entries = B.entries_of(B.load(discovery, n), 'entry')
            if len(entries) != 1:
                raise ValueError('encounter discovery was ambiguous')
            E = entries[0]
        pages = [page(bank, p) for p in record['pages']]
        boundary = 52 + BB.word(bank, record['pages'][0] + 8)
        shots = ','.join((str(E + k) for k in (130, boundary - 18, boundary - 1, boundary + 1, boundary + 100))) if sid == 'desert_commander' and (not pack) else ''
        if not a.reuse or not (out / 'mame.log').exists():
            B.run(binary, work / 'sets' / label, set_name, out, sc, n, B.shift_inputs(sc['inputs'], N, E), shift=(E, N), holds=B.holds_env(B.research_writes(sc), (E, N)), shots=shots)
        log = B.load(out, n)
        vb = B.scene_vblanks(log)
        if B.entries_of(log, 'entry') != [E] or B.entries_of(log, 'exit') != [E + N] or len(vb) != N:
            raise ValueError(label + ' ' + sid + ': scene duration or boundary changed')
        if B.freeze_diff(log['dumps']['entry'], log['dumps']['exit']):
            raise ValueError('game state changed during scene')
        index = BB.IDS.index(sid)
        cue = 192 + index if m == 'striderua' else 184 + index if pack else None
        expected = [(E + 2, 252 if pack else 241)] + ([(E + 72, cue)] if cue is not None else [])
        sound = [(f, v) for f, v, on in B.sound_writes(log) if on and v != 255]
        if sound != expected:
            raise ValueError('voice/stop commands changed')
        at = record['at']
        pt = list(struct.unpack_from('>16H', bank, at + 8))
        px, py, attr, rest = struct.unpack_from('>4H', bank, at + 40)
        seq = []
        p = BB.long(bank, at + 48) - BB.BASE
        while BB.word(bank, p):
            seq.append([BB.word(bank, p), BB.word(bank, p + 2)])
            p += 4
        if m == 'striderua':
            seq = next((r['sequence'] for r in meta['sets'][m]['boss_mouth']['rows'] if r['id'] == sid and r['mode'] == ('pack' if pack else 'native')))
        u = 0
        count = 0
        full = 0
        strip_code = None
        pg = [v for v in vb if v['pl'] >> 8 & 15 == 4]
        strip_code = next((v['list'][0][2] for v in pg if v['t'] == 1 and v['pl'] >> 12 == 0))
        for k, p in enumerate(pages):
            for t in range(S.page_times(p['hold'])['next']):
                v = pg[count]
                count += 1
                lvl = S.page_level(t, p['hold'])
                pl = S.portrait_level(u, t, p['hold'], k == len(pages) - 1)
                shown = u > 0 and (k < len(pages) - 1 or t < S.page_times(p['hold'])['hide'])
                ui = S.colors(p['ui'], lvl, S.UI_FADE)
                if t == 0 or t >= S.page_times(p['hold'])['hide']:
                    ui = [0] * 16
                ui[1] = S.colors(p['ui'], pl, S.UI_FADE)[1]
                colors = ui + S.colors(pt, pl, S.PT_FADE)
                ents = []
                if shown:
                    for st in p['strips']:
                        ents += S.strip_entries(st, t, strip_code)
                    ents += p['before'] + [[px, py, picture(seq, u - S.HOLD_FROM, rest), attr]] + p['after']
                if v['prep'] != v['n'] or v['t'] != t or v['pl'] != k << 12 | 1024 | lvl or (v['slots'] != colors) or (v['layer'] != (S.LAYER_PAGE if shown else S.LAYER_HIDE)) or (v['list'] != [tuple(e) for e in ents]):
                    raise ValueError(f'{label} {sid} page {k} t {t}: palette/list/preparation mismatch')
                if pl == S.FULL:
                    full += 1
                u += 1
        if count != len(pg):
            raise ValueError('unmodeled page frames')
        print('PASS', label, sid, count, 'page frames;', full, 'continuous full portrait frames', flush=True)
        return dict(machine=m, pack=pack, scene=sid, entry=E, frames=N, page_frames=count, full_portrait_frames=full, row_pitch=meta['sets'][m]['boss_paging']['row_pitch'], sound=sound, register_trace_sha256=sha((out / 'g_regs.tsv').read_bytes()), passed=True)
    with ThreadPoolExecutor(2) as ex:
        results = list(ex.map(run, jobs))
    reviews = []
    if a.review:
        import numpy as np
        from PIL import Image, ImageDraw
        a.review.mkdir(parents=True, exist_ok=True)
        for m, set_name in (('striderua', 'striderus01'), ('striderjr', 'striderjs01')):
            sid = 'desert_commander'
            sc = scenarios[sid]
            r = next((r for r in results if r['machine'] == m and (not r['pack']) and (r['scene'] == sid)))
            E = r['entry']
            p6 = files[m]['strex_p6.bin']
            bank = bytes((p6[k ^ 1] for k in range(len(p6))))
            record = BB.scenes(bank)[-1]
            boundary = 52 + BB.word(bank, record['pages'][0] + 8)
            n = sc['frames'] + r['frames'] + 300
            shots = ','.join((str(E + k) for k in (boundary - 1, boundary + 100)))
            out = work / 'review_control' / m
            if not a.reuse or not (out / 'mame.log').exists():
                roms = G.stage_sets(a.control.resolve(), set_name, a.hbmame, a.rom_dir.resolve(), work / 'review_sets' / m)
                B.run(binary, roms, set_name, out, sc, n, B.shift_inputs(sc['inputs'], r['frames'], E), shift=(E, r['frames']), holds=B.holds_env(B.research_writes(sc), (E, r['frames'])), shots=shots)
            candidate = work / 'runs' / (m + '_native') / sid
            read = lambda root, k: np.asarray(Image.open(root / f'g_{E + k:05d}.png').convert('RGB'))
            oldpic, newpic = (read(out, boundary + 100), read(candidate, boundary + 100))
            oldgap, newgap = (read(out, boundary - 1), read(candidate, boundary - 1))
            if np.any(oldgap) or not np.any(newgap[52:140, 224:352]):
                raise ValueError('actual page-gap portrait control failed')
            y, delta = (200, 16) if m == 'striderua' else (192, 8)
            expected = oldpic.copy()
            expected[y:y + 16] = 0
            expected[y - delta:y - delta + 16] = oldpic[y:y + 16]
            if a.border_control:
                surround = np.all(expected[52:140, 224:352] == np.array(S.rgb(63232), np.uint8), axis=2)
                surround[4:84, 4:124] = False
                expected[52:140, 224:352][surround] = 0
            if not np.array_equal(expected, newpic):
                raise ValueError('actual spacing pixels differ outside the translated second row')
            sheet = Image.new('RGB', (768, 496), (24, 24, 24))
            draw = ImageDraw.Draw(sheet)
            for i, pic in enumerate((oldpic, newpic, oldgap, newgap)):
                sheet.paste(Image.fromarray(pic), (384 * (i % 2), 24 + 248 * (i // 2)))
            for x, y, label in ((8, 6, 'Before: 32-pixel line spacing'), (392, 6, 'After: tighter line spacing'), (8, 254, 'Before: portrait disappears between pages'), (392, 254, 'After: portrait stays visible')):
                draw.text((x, y), label, fill='white')
            target = a.review / (m + '-boss-pages.png')
            sheet.resize((1536, 992), Image.Resampling.NEAREST).save(target)
            reviews.append(dict(machine=m, actual_second_row_translation=[0, -delta], all_other_full_page_pixels_identical=not bool(a.border_control), border_palette_also_removed=bool(a.border_control), old_gap_black_new_portrait_visible=True, review_sha256=sha(target.read_bytes())))
    receipt = dict(schema='striderex-boss-paging-gate/1', passed=True, input_files={m: s['files'] for m, s in meta['sets'].items()}, results=results, runtime={k: rt[k] for k in ('binary_sha256', 'source_revision', 'board_wait')}, exact_inverse_audit=True, voices_and_page_timing_preserved=True, visual_checks=reviews, hardware_review_granted=False)
    a.receipt.write_text(json.dumps(receipt, indent=2) + '\n')

def main():
    p = argparse.ArgumentParser(description=__doc__)
    for n in ('control', 'build', 'routing-receipt', 'runtime', 'hbmame', 'rom-dir', 'workdir', 'receipt'):
        p.add_argument('--' + n, type=Path, required=True)
    p.add_argument('--scenes')
    p.add_argument('--paging-build', type=Path)
    p.add_argument('--border-control', type=Path, help='verified drawing build before the border palette overlay')
    p.add_argument('--review', type=Path)
    p.add_argument('--discover-entry', action='store_true', help='find encounter timing on a different prepared runtime')
    p.add_argument('--reuse', action='store_true')
    gate(p.parse_args())
if __name__ == '__main__':
    main()
