"""Strider EX English dub: one take per run of lines by one speaker (DUB.md section 13)."""
import argparse
import difflib
import hashlib
import json
import math
import re
import shutil
import sys
import time
from pathlib import Path
import numpy as np
sys.path.insert(0, str(Path(__file__).resolve().parent))
ROOT = Path(__file__).resolve().parents[3]
HERE = ROOT / 'backports/striderex'
MANIFEST = HERE / 'manifests/dub_runs.json'
TAKES = HERE / 'manifests/dub_takes.json'
VOICES = HERE / 'manifests/dub_voices.json'
CAST = HERE / 'manifests/dub_cast.json'
NAME_SAY = HERE / 'manifests/dub_name_say.json'
TRACKS = range(21, 29)
SCENES = {21: 'prologue', 22: 'brief_st_petersburg', 23: 'intro_desert', 24: 'brief_siberia', 25: 'brief_aerial', 26: 'brief_amazon', 27: 'flight', 28: 'welcome_meio'}
SIL_DB = 45.0
MIN_SIL = 0.03
EARLY = 0.25
LATE = 0.25
KEEP_START = {'tr21.9': 'English-only line on the EX title card (34.233 s): its start stays (DUB.md 9)'}
NUMBER_WORDS = set('zero oh one two three four five six seven eight nine ten eleven twelve thirteen fourteen fifteen sixteen seventeen eighteen nineteen twenty thirty forty fifty sixty seventy eighty ninety hundred thousand'.split())
NAME_TOKENS = {'hiryu', 'hirryu', 'hi', 'ryoo', 'hee', 'hiryus'}
NAME_PICKED_NARRATOR = 'Say the hero\'s name, written Hee-ryoo, exactly as HEE-ryoo: two syllables, "hee" as in "he", then "ryoo" as in the name Ryu, the r starting the second syllable; it is a name, never the words "here you" or "hear you"; a light stress on the first syllable, no pause between them; the same way every time.'

def recipes():
    """{recipe: (spelling, instruction, what it is)}: round 3's Japanese-target instruction (dub_name_say.json"""
    say_jp = load(NAME_SAY)['round3']['say']['say_jp']
    return {'jp': ('Hi-ryoo', say_jp.format(spell='Hi-ryoo'), 'round 3: Hi-ryoo with the Japanese-target instruction (DUB.md 12.9, approach a)'), 'jp_hirryu': ('Hirryu', say_jp.format(spell='Hirryu'), ''), 'name': ('Hee-ryoo', NAME_PICKED_NARRATOR, '')}
TEXT_SENT = {'tr22.0': 'Super Base to, Hiryu. Standard time zero three twenty-five hours.'}

def load(p):
    return json.loads(Path(p).read_text(encoding='utf-8'))

def file_sha(p):
    h = hashlib.sha256()
    with open(p, 'rb') as f:
        for chunk in iter(lambda: f.read(1 << 22), b''):
            h.update(chunk)
    return h.hexdigest()

def slug(s):
    return re.sub('[^a-z0-9]+', '_', s.lower()).strip('_')

def picks_of(lid, take, fitline):
    """Reconstruction helper."""
    out = []
    p = take['take']
    if p == 'takes8_retakes':
        out.append(dict(kind='mix 9 re-take', what="slower or tighter so that the voice ends with the portrait's mouth (DUB.md 10.10-10.11)", words=(fitline.get('retake') or {}).get('approved')))
    if p == 'takes9_hiryu':
        out.append(dict(kind='mix 10 Hiryu pick', what=f"{take['text']!r}", words=(fitline.get('retake') or {}).get('approved')))
    if p == 'takes7_chairman':
        out.append(dict(kind='chairman recast', what='Zubenelgenubi (DUB.md 11)', words=''))
    if p in ('takes6_hiryu_a', 'takes6_hiryu_b'):
        w = ''
        if lid == 'tr21.9':
            w += '; 2026-10-18, of the round 3 re-take: "The prologue\'s pronunciation is more wrong in this take" (this take kept)'
        out.append(dict(kind='name line (mix 6)', what=f"the name as approved: {take['text']!r}", words=w))
    if fitline.get('moved'):
        out.append(dict(kind='moved onto the mouth', what="tr23.0 starts with the chairman's mouth after tr23.0a (DUB.md 10.9)", words=fitline['moved'].get('approved')))
    if fitline.get('mix8'):
        out.append(dict(kind='placed on the mouth (mix 8 rule)', what='a portrait line placed and paced within the mouth animation (DUB.md 10)', words=''))
    return out

def find_runs(fit=None, subs=None):
    """Every run: consecutive voiced lines of one speaker in one track (slot order), at least two lines."""
    import caption_pacing as CP
    import dub_lipsync as DL
    import dub_mix as DM
    fit = fit or DM.fit_plan()
    subs = subs or DM.subtitle_index()
    cv = dict(CP.voice_manifest()['lines'])
    takes = load(TAKES)['lines']
    cast = load(CAST)['speakers']
    plain = load(VOICES)['lines']
    windows = {r['id']: r['window_s'] for r in load(CP.CUES)['cinematics']['rows'] if r.get('window_s')}
    mouth = {}
    for m in DL.MOUTHS:
        for lid in m['lines']:
            mouth.setdefault(lid, []).append(m['who'])
    gap = fit['solver']['gap']
    runs = []
    for t in TRACKS:
        slots = DM.slots_for(t, fit, subs)
        k = 0
        while k < len(slots):
            j = k
            while j + 1 < len(slots) and slots[j + 1][1]['speaker'] == slots[k][1]['speaker']:
                j += 1
            if j > k:
                ids = [s[0] for s in slots[k:j + 1]]
                spk = slots[k][1]['speaker']
                en = [cv[lid]['en'] for lid in ids]
                nxt = slots[j + 1][0] if j + 1 < len(slots) else None
                w1 = windows[SCENES[t]][1]
                if nxt:
                    latest, why = (cv[nxt]['en']['on'] - gap, f"{nxt} ({subs[nxt]['speaker']}) voice less solver.gap")
                else:
                    latest = max(en[-1]['off'], w1)
                    why = "the scene's picture window end" if w1 >= en[-1]['off'] else "mix 10's last voice off"
                lines = []
                for i, lid in enumerate(ids):
                    e, ja = (en[i], cv[lid].get('ja'))
                    row = dict(id=lid, text=subs[lid]['en']['text'], plain=plain[lid]['plain'], direction=plain[lid].get('direction'), slot=[slots[k + i][1]['start'], slots[k + i][1]['end']], mix10=dict(on=e['on'], off=e['off'], ratio=e['ratio'], placed=e['placed']), ja=dict(on=ja['on'], off=ja['off']) if ja else None, take=dict(pass_=takes[lid]['take'], voice=takes[lid]['voice'], wav_sha256=takes[lid]['wav_sha256']), portrait=mouth.get(lid), picks=picks_of(lid, takes[lid], fit['lines'].get(lid, {})))
                    row['take']['pass'] = row['take'].pop('pass_')
                    if lid in KEEP_START:
                        row['keep_start'] = KEEP_START[lid]
                    if i + 1 < len(ids):
                        row['gap_after'] = dict(voice=round(en[i + 1]['on'] - e['off'], 3), slot=round(slots[k + i + 1][1]['start'] - slots[k + i][1]['end'], 3))
                    lines.append(row)
                rid = f'r{t}_{slug(spk)}'
                if any((r['id'] == rid for r in runs)):
                    rid += f"_{ids[0].split('.')[1]}"
                voiced = sum(((e['off'] - e['on']) / e['ratio'] for e in en))
                runs.append(dict(id=rid, track=t, scene=SCENES[t], speaker=spk, voice=cast[spk]['voice'], lines=lines, first_on=en[0]['on'], latest_off=round(latest, 3), latest_why=why, room_s=round(latest - en[0]['on'], 3), mix10_span_s=round(en[-1]['off'] - en[0]['on'], 3), mix10_voiced_at_pace1_s=round(voiced, 3), name_lines=[lid for lid in ids if 'Hiryu' in subs[lid]['en']['text']]))
            k = j + 1
    order = {'Narrator': 0}
    runs.sort(key=lambda r: (order.get(r['speaker'], 1), r['track']))
    return runs

def run_by_id(rid):
    for r in find_runs():
        if r['id'] == rid:
            return r
    sys.exit(f'no run {rid!r}; dub_runs.py runs lists them')

def cmd_runs(a):
    runs = find_runs()
    for r in runs:
        print(f"{r['id']:22} tr{r['track']} {r['speaker']:24} {r['voice']:14} {len(r['lines'])} lines {r['lines'][0]['id']}-{r['lines'][-1]['id']}: mix 10 voice {r['first_on']:.2f}-{r['lines'][-1]['mix10']['off']:.2f} s ({r['mix10_span_s']:.2f} s); room to {r['latest_off']:.2f} ({r['latest_why']}): {r['room_s']:.2f} s; voiced at pace 1 {r['mix10_voiced_at_pace1_s']:.2f} s")
        for ln in r['lines']:
            g = ln.get('gap_after')
            print(f"    {ln['id']:8} slot {ln['slot'][0]:6.3f}-{ln['slot'][1]:6.3f} voice {ln['mix10']['on']:6.2f}-{ln['mix10']['off']:6.2f} x{ln['mix10']['ratio']:.3f}" + (f" gap {g['voice']:.2f}" if g else '          ') + (f" portrait: {ln['portrait'][0]}" if ln['portrait'] else '') + ''.join((f" [{p['kind']}]" for p in ln['picks'])) + f"  {ln['text']}")
    if a.write:
        m = load(MANIFEST) if MANIFEST.exists() else dict(schema=1)
        m['runs'] = runs
        m['runs_rule'] = "a run is two or more consecutive voiced lines of one speaker in one scene (track), nobody else's line between them, in the approved fit's slot order (dub_runs.find_runs)"
        write_manifest(m)
    return 0

def write_manifest(m):
    MANIFEST.write_text(json.dumps(m, indent=1, ensure_ascii=False) + '\n', encoding='utf-8')
    print(f'wrote {MANIFEST.relative_to(ROOT)}')

def r1(v):
    return f'{max(v, 0.1):.1f}'

def r05(v):
    """A pause in the text: to 0.05 s."""
    return f'{round(v * 20) / 20:.2f}'.rstrip('0').rstrip('.')

def run_text(run, spell):
    """The text sent: one paragraph per line, the name spelled as the recipe says (the words checked)."""
    import dub_tts as T
    paras = []
    for ln in run['lines']:
        t = TEXT_SENT.get(ln['id'], ln['plain'])
        if T.words(t.replace('Hee-ryoo', 'Hiryu')) != T.words(ln['plain'].replace('Hee-ryoo', 'Hiryu')):
            sys.exit(f"{ln['id']}: TEXT_SENT changes the words of the line")
        paras.append(t.replace('Hee-ryoo', 'Hiryu').replace('Hiryu', spell))
    return '\n\n'.join(paras)
URGENT = 'Pacing: this passage must be quick. Read every line at a brisk, urgent trailer pace, much quicker than a slow narration, with no pause inside a line and only the short pauses named between lines.'

def run_prompt(run, scene, style, say=None, pace=1.0, gap_min=0.15, urgent=False):
    """The direction for the whole run: one continuous take, each line's direction, each line's length and the"""
    n = len(run['lines'])
    dirs, timing = ([], [])
    k = 0
    while k < n:
        d0 = run['lines'][k].get('direction')
        j = k
        while j + 1 < n and run['lines'][j + 1].get('direction') == d0:
            j += 1
        if d0:
            dirs.append((f'lines {k + 1}-{j + 1}' if j > k else f'line {k + 1}') + f': {d0}')
        k = j + 1
    for i, ln in enumerate(run['lines']):
        d = (ln['mix10']['off'] - ln['mix10']['on']) * pace
        g = ln.get('gap_after')
        pause = max(g['voice'], gap_min) * pace if g else None
        timing.append(f'line {i + 1} about {r1(d)} seconds' + (f', then a pause of about {r05(pause)} seconds' if pause is not None else ''))
    total = (run['lines'][-1]['mix10']['off'] - run['lines'][0]['mix10']['on']) * pace
    parts = [scene, style, f'This text is {n} consecutive lines spoken by this one character in one scene, one paragraph per line. Perform them as a single continuous take, in order, as one actor delivering the whole speech: the same voice, energy and delivery carry through from line to line, and each line flows from the one before.', 'How each line is played: ' + '; '.join(dirs) + '.' if dirs else '', 'Timing (the picture fixes it): ' + '; '.join(timing) + f'. The whole passage, pauses included, must take about {r1(total)} seconds: keep it tight, with no long pauses other than those.', URGENT if urgent else '']
    if say:
        parts.append(say)
    return ' '.join((p for p in parts if p))

def run_request(run, recipe, pace=1.0, urgent=False):
    """(body, text, prompt, billable characters, USD upper bound) for one run take (dub_tts.py's pricing)."""
    import dub_tts as T
    plan, cast = (load(VOICES), load(CAST)['speakers'])
    g = plan['gemini']
    c = cast[run['speaker']]
    spell, say, _ = recipes()[recipe]
    text = run_text(run, spell)
    names = 'Hiryu' in ' '.join((ln['text'] for ln in run['lines']))
    prompt = run_prompt(run, g['scene'], c.get('direction') or g['speakers'][run['speaker']]['style'], say if names else None, pace, load(HERE / 'manifests/dub_fit.json')['solver']['gap'], urgent)
    voice = c['voice']
    body = dict(input=dict(prompt=prompt, text=text), voice=dict(languageCode='en-us', name=voice, modelName=g['model']), audioConfig=dict(audioEncoding='LINEAR16', sampleRateHertz=g['sample_rate']))
    tin, tout = T.GEMINI_PRICE[g['model']]
    n = len(text)
    usd = (len(prompt) + n) * tin / 1000000.0 + (3 + n / 12) * 25 * tout / 1000000.0
    return (body, text, prompt, len(prompt) + n, usd)

def ledger_add(path, row):
    led = load(path) if path.exists() else dict(attempts=[])
    led['attempts'].append(row)
    led['usd_upper_bound_saved'] = round(sum((r['usd_upper_bound'] for r in led['attempts'] if r['status'] == 'saved')), 4)
    led['usd_upper_bound_billable'] = round(sum((r['usd_upper_bound'] for r in led['attempts'] if r['status'] in ('saved', 'maybe billed, not saved'))), 4)
    path.write_text(json.dumps(led, indent=1) + '\n')
    return led

def cmd_render(a):
    import io
    import urllib.error
    import wave
    import dub_tts as T
    import dub_store as DS
    run = run_by_id(a.run)
    held = DS.root() / DS.check_name(a.set)
    out = held / f'{a.run}_{a.tag}'
    if not a.dry_run:
        DS.holding_set(a.set)
        out.mkdir(exist_ok=False)
    ledger = Path(a.ledger) if a.ledger else held / 'ledger.json'
    if not DS.in_store(ledger):
        sys.exit(f'{ledger}: the ledger of paid renders belongs in the take store')
    body, text, prompt, chars, usd = run_request(run, a.recipe, a.pace, a.urgent)
    led = load(ledger) if ledger.exists() else dict(attempts=[])
    spent = led.get('usd_upper_bound_billable', 0.0)
    print(f"{a.run} {a.tag}: {len(run['lines'])} lines, {chars} characters, at most ${usd:.4f} (ledger so far ${spent:.4f}, cap ${a.cap_usd})")
    if a.dry_run:
        print(f'PROMPT: {prompt}\n\nTEXT:\n{text}')
        return 0
    if spent + usd > a.cap_usd:
        sys.exit('the render would exceed the cap')
    project = load(a.credentials)['project_id']
    tok = T.token(a.credentials)
    pcm, err = (None, None)
    for attempt in range(3):
        status = None
        try:
            pcm = T.synth(tok, project, body)
            break
        except urllib.error.HTTPError as e:
            err = f'HTTP {e.code}: {e.read().decode()[:300]}'
            status = 'refused or failed (HTTP), not billed'
        except Exception as e:
            err = f'{type(e).__name__}: {e}'
            status = 'maybe billed, not saved'
        print(f'{a.run} {a.tag}: {err}', flush=True)
        ledger_add(ledger, dict(run=a.run, tag=a.tag, recipe=a.recipe, at=time.strftime('%Y-%m-%d %H:%M:%S'), status=status, error=err, usd_upper_bound=round(usd, 5)))
        time.sleep(10 * (attempt + 1))
    if pcm is None:
        sys.exit(f'{a.run} {a.tag}: no audio after 3 attempts')
    if pcm[:4] != b'RIFF':
        buf = io.BytesIO()
        with wave.open(buf, 'wb') as w:
            w.setnchannels(1)
            w.setsampwidth(2)
            w.setframerate(body['audioConfig']['sampleRateHertz'])
            w.writeframes(pcm)
        pcm = buf.getvalue()
    (out / 'take.wav').write_bytes(pcm)
    sha = file_sha(out / 'take.wav')
    x, rate = read_wav(out / 'take.wav')
    rec = dict(run=a.run, tag=a.tag, recipe=a.recipe, recipe_note=recipes()[a.recipe][2], pace=a.pace, urgent=a.urgent, speaker=run['speaker'], voice=body['voice']['name'], model=body['voice']['modelName'], lines=[ln['id'] for ln in run['lines']], prompt=prompt, text=text, characters=chars, usd_upper_bound=round(usd, 5), wav_sha256=sha, seconds=round(len(x) / rate, 3), rate=rate, at=time.strftime('%Y-%m-%d %H:%M:%S'))
    (out / 'render.json').write_text(json.dumps(rec, indent=1, ensure_ascii=False) + '\n')
    ledger_add(ledger, dict(run=a.run, tag=a.tag, recipe=a.recipe, at=rec['at'], status='saved', usd_upper_bound=round(usd, 5), wav_sha256=sha))
    DS.seal(out)
    print(f"{a.run} {a.tag}: {rec['seconds']} s, {sha[:16]}")
    return 0

def read_wav(path):
    from scipy.io import wavfile
    rate, x = wavfile.read(str(path))
    if x.dtype == np.int16:
        x = x / 32768.0
    x = np.asarray(x, np.float64)
    if x.ndim == 2:
        x = x.mean(1)
    return (x, rate)

def write_wav16(path, x, rate):
    from scipy.io import wavfile
    wavfile.write(str(path), rate, np.clip(np.round(x * 32768), -32768, 32767).astype(np.int16))

def frames_db(x, rate, win=0.01, hop=0.0025):
    """(frame centers s, dB RMS) in win windows every hop."""
    c = np.concatenate([[0.0], np.cumsum(x * x)])
    w, h = (int(round(win * rate)), int(round(hop * rate)))
    centers = np.arange(w // 2, max(len(x) - w // 2, w // 2 + 1), h)
    a, b = (np.clip(centers - w // 2, 0, len(x)), np.clip(centers + w // 2, 0, len(x)))
    rms = np.sqrt((c[b] - c[a]) / np.maximum(b - a, 1) + 1e-20)
    return (centers / rate, 20 * np.log10(rms))

def toks(text, name=True):
    """Normalized tokens: lower case, periods and apostrophes dropped, runs of single letters joined (A.D. = AD,"""
    s = text.lower().replace('’', "'").replace("'", '').replace('.', ' ')
    raw = re.sub('[^a-z0-9 ]', ' ', s).split()
    out, letters = ([], [])
    for t in raw + ['']:
        if len(t) == 1 and t.isalpha():
            letters.append(t)
            continue
        if letters:
            out.append(''.join(letters))
            letters = []
        if t:
            out.append(t)
    res = []
    for t in out:
        if t in NUMBER_WORDS or re.fullmatch('\\d+(st|nd|rd|th|s)?', t):
            if not res or res[-1] != 'NUM':
                res.append('NUM')
        elif name and t in NAME_TOKENS:
            res.append('NAME')
        else:
            res.append(t)
    return res

def align_lines(words, line_texts):
    """For each recognized word, the index of the line it belongs to: the words aligned to the text sent"""
    exp = [(i, t) for i, txt in enumerate(line_texts) for t in toks(txt)]
    rec = [(toks(w['word']) or [''])[0] for w in words]
    sm = difflib.SequenceMatcher(a=[e[1] for e in exp], b=rec, autojunk=False)
    owner = [None] * len(rec)
    for tag, i1, i2, j1, j2 in sm.get_opcodes():
        if tag in ('equal', 'replace'):
            for k in range(j2 - j1):
                owner[j1 + k] = exp[i1 + min(i2 - i1 - 1, k * (i2 - i1) // max(j2 - j1, 1))][0]
    last = None
    for k in range(len(owner)):
        if owner[k] is None:
            owner[k] = last
        last = owner[k]
    nxt = None
    for k in range(len(owner) - 1, -1, -1):
        if owner[k] is None:
            owner[k] = nxt if nxt is not None else 0
        nxt = owner[k]
    mx = 0
    for k in range(len(owner)):
        mx = max(mx, owner[k])
        owner[k] = mx
    return owner

def silences(t, db, peak, a, b, below=SIL_DB):
    """[(start, end)] s of the runs of frames more than `below` dB under `peak` inside [a, b]."""
    m = (t >= a) & (t <= b) & (db < peak - below)
    out, s = ([], None)
    for k in range(len(t)):
        if m[k] and s is None:
            s = t[k]
        if not m[k] and s is not None:
            out.append((s, t[k - 1]))
            s = None
    if s is not None:
        out.append((s, t[np.nonzero(m)[0][-1]]))
    return out
VALLEY_DB = 24.0
FADE = 0.008

def cut_candidates(t, db, peak, a, b, hint):
    """Where two lines may be cut inside [a, b] (s), best first: each silence of MIN_SIL or more (longest first;"""
    out = []
    sil = [s for s in silences(t, db, peak, a, b) if s[1] - s[0] >= MIN_SIL]
    for s, e in sil:
        inner = (t >= s + 0.01) & (t <= e - 0.01)
        if not inner.any():
            inner = (t >= s) & (t <= e)
        k = np.nonzero(inner)[0]
        quiet = k[db[k] <= db[k].min() + 3.0]
        c = quiet[int(np.argmin(np.abs(t[quiet] - (s + e) / 2)))]
        out.append(dict(kind='silence', cut_s=float(t[c]), silence=[round(s, 4), round(e, 4)], silence_s=round(e - s, 4), cut_db_under_peak=round(float(peak - db[c]), 1)))
    if out:
        longest = max((c['silence_s'] for c in out))
        top = [c for c in out if c['silence_s'] >= 0.7 * longest]
        rest = [c for c in out if c['silence_s'] < 0.7 * longest]
        out = sorted(top, key=lambda c: abs(c['cut_s'] - hint)) + sorted(rest, key=lambda c: -c['silence_s'])
    w = np.nonzero((t >= a) & (t <= b))[0]
    if len(w) > 2:
        sm = np.convolve(db, np.ones(3) / 3, mode='same')
        vals = []
        for k in w[1:-1]:
            if sm[k] <= sm[k - 1] and sm[k] <= sm[k + 1] and (peak - db[k] >= VALLEY_DB) and (not any((s <= t[k] <= e for s, e in sil))):
                vals.append(k)
        vals.sort(key=lambda k: db[k])
        keep = []
        for k in vals:
            if all((abs(t[k] - t[j]) > 0.04 for j in keep)):
                keep.append(k)
        out += [dict(kind='valley (no silence)', cut_s=float(t[k]), cut_db_under_peak=round(float(peak - db[k]), 1)) for k in keep]
    return out

def piece_check(heard, text):
    """A piece's recognized words against its line's: the alignment of the tokens (toks), where the name may be"""
    e, h = (toks(text), toks(heard))
    if not e:
        return dict(ratio=1.0, same=True, first=True, last=True, ok=True, heard_tokens=h)
    ops = difflib.SequenceMatcher(a=e, b=h, autojunk=False).get_opcodes()

    def fine(op):
        tag, i1, i2, j1, j2 = op
        return tag == 'equal' or (tag == 'replace' and e[i1:i2] == ['NAME'] and (j2 - j1 <= 3)) or (tag == 'replace' and ''.join(e[i1:i2]) == ''.join(h[j1:j2]))
    bad = sum((max(i2 - i1, j2 - j1) for tag, i1, i2, j1, j2 in ops if not fine((tag, i1, i2, j1, j2))))
    ratio = max(0.0, 1 - bad / len(e))
    first, last = (bool(ops) and fine(ops[0]), bool(ops) and fine(ops[-1]))
    return dict(ratio=round(ratio, 3), same=all((fine(o) for o in ops)), first=bool(first), last=bool(last), ok=bool(ratio >= 0.8 and first and last), heard_tokens=h)

def cut_pieces(x, rate, cuts, kinds):
    """The pieces between cuts (exact slices), each valley-cut edge faded over FADE (raised cosine)."""
    bounds = [0] + list(cuts) + [len(x)]
    out = []
    n = int(round(FADE * rate))
    for i in range(len(bounds) - 1):
        seg = x[bounds[i]:bounds[i + 1]].copy()
        ramp = 0.5 * (1 - np.cos(np.pi * np.arange(n) / n))
        if i > 0 and kinds[i - 1].startswith('valley') and (len(seg) > 2 * n):
            seg[:n] *= ramp
        if i < len(cuts) and kinds[i].startswith('valley') and (len(seg) > 2 * n):
            seg[-n:] *= ramp[::-1]
        out.append(seg)
    return out

def split_take(x, rate, words, line_texts, ids, hear, max_tries=8):
    """The cuts between a run take's lines, each confirmed by the recognizer: the lines' words placed by the"""
    t, db = frames_db(x, rate)
    peak = float(db.max())
    owner = align_lines(words, line_texts)
    by = [[w for w, o in zip(words, owner) if o == i] for i in range(len(ids))]
    empty = [ids[i] for i, b in enumerate(by) if not b]
    if empty:
        raise ValueError(f'no recognized word for {empty}')
    cands, choice = ([], [])
    for i in range(len(ids) - 1):
        lw, fw = (by[i][-1], by[i + 1][0])
        lo, hi = (min(lw['start'], fw['start']) - 0.15, max(lw['end'], fw['end']) + 0.15)
        cs = cut_candidates(t, db, peak, lo, hi, (lw['end'] + fw['start']) / 2)
        if not cs:
            raise ValueError(f'no cut candidate between {ids[i]} and {ids[i + 1]}')
        for c in cs:
            c.update(between=[ids[i], ids[i + 1]], words_gap=[round(lw['end'], 3), round(fw['start'], 3)])
        cands.append(cs)
        choice.append(0)
    cache = {}

    def piece(i):
        a = 0 if i == 0 else int(round(cands[i - 1][choice[i - 1]]['cut_s'] * rate))
        b = len(x) if i == len(ids) - 1 else int(round(cands[i][choice[i]]['cut_s'] * rate))
        kinds = [cands[j][choice[j]]['kind'] for j in range(len(cands))]
        key = (a, b)
        if key not in cache:
            cuts = [int(round(cands[j][choice[j]]['cut_s'] * rate)) for j in range(len(cands))]
            seg = cut_pieces(x, rate, cuts, kinds)[i]
            heard = hear(seg, rate)
            cache[key] = (heard, piece_check(heard, line_texts[i]))
        return cache[key]
    tries = 0
    for i in range(len(cands)):
        while True:
            _, left = piece(i)
            _, right = piece(i + 1)
            if left['last'] and right['first']:
                break
            if choice[i] + 1 >= len(cands[i]) or tries >= max_tries * len(cands):
                raise ValueError(f"no confirmed cut between {ids[i]} and {ids[i + 1]} (last tried at {cands[i][choice[i]]['cut_s']:.3f} s: {piece(i)[0]!r} | {piece(i + 1)[0]!r})")
            choice[i] += 1
            tries += 1
    cuts, info = ([], [])
    for i, cs in enumerate(cands):
        c = dict(cs[choice[i]])
        c.update(cut_s=round(c['cut_s'], 4), cut_sample=int(round(c['cut_s'] * rate)), candidate=choice[i] + 1, candidates=len(cs), fade_s=FADE if c['kind'].startswith('valley') else 0.0)
        cuts.append(c['cut_sample'])
        info.append(c)
    return (cuts, info, owner, [piece(i) for i in range(len(ids))])

def cmd_split(a):
    import dub_name as DN
    rd = Path(a.render)
    rec = load(rd / 'render.json')
    take = rd / 'take.wav'
    if file_sha(take) != rec['wav_sha256']:
        sys.exit(f'{take}: not the digest render.json records')
    run = run_by_id(rec['run'])
    ids = rec['lines']
    texts = rec['text'].split('\n\n')
    subtitle = {ln['id']: ln['text'] for ln in run['lines']}
    x, rate = read_wav(take)
    words = DN.transcribe(x, rate)

    def hear(seg, r):
        """The piece recognized alone: greedy decoding without timestamps (the check needs only the words)."""
        A = DN.asr()
        y = DN.resample(seg, r, 16000).astype(np.float32)
        segs, _ = A['m'].transcribe(y, language='en', beam_size=1, temperature=0.0, without_timestamps=True, condition_on_previous_text=False)
        return ' '.join((s.text.strip() for s in segs))
    try:
        cuts, info, owner, heard = split_take(x, rate, words, [subtitle[i] for i in ids], ids, hear)
    except ValueError as e:
        print(f'{rd.name}: SPLIT FAILED: {e}')
        (rd / 'split.json').write_text(json.dumps(dict(render=rd.name, ok=False, error=str(e), words=words), indent=1, ensure_ascii=False) + '\n')
        return 1
    pd = rd / 'pieces'
    if pd.exists():
        shutil.rmtree(pd)
    pd.mkdir()
    bounds = [0] + cuts + [len(x)]
    segs = cut_pieces(x, rate, cuts, [c['kind'] for c in info])
    pieces, ok, vrows = ([], True, [])
    for i, lid in enumerate(ids):
        f = pd / f'{lid}.wav'
        write_wav16(f, segs[i], rate)
        h, chk = heard[i]
        ok &= chk['ok']
        sha = file_sha(f)
        pieces.append(dict(line=lid, samples=[bounds[i], bounds[i + 1]], seconds=round(len(segs[i]) / rate, 3), text_sent=texts[i], heard=h, check=chk, wav_sha256=sha, words=[w for w, o in zip(words, owner) if o == i]))
        vrows.append(dict(line=lid, speaker=rec['speaker'], voice=rec['voice'], model=rec['model'], prompt=rec['prompt'], text=texts[i], usd_upper_bound=0.0, wav_sha256=sha, piece_of=dict(render=rd.name, take_sha256=rec['wav_sha256'], samples=[bounds[i], bounds[i + 1]])))
        print(f"{lid:8} {bounds[i] / rate:7.3f}-{bounds[i + 1] / rate:7.3f} s  heard {h!r}  {('OK' if chk['ok'] else 'MISMATCH')} (ratio {chk['ratio']})")
    for c in info:
        print(f"  cut {c['between'][0]}|{c['between'][1]} at {c['cut_s']:.3f} s: {c['kind']}" + (f", silence {c['silence_s'] * 1000:.0f} ms" if c.get('silence_s') else '') + f", {c['cut_db_under_peak']} dB under the peak; candidate {c['candidate']} of {c['candidates']}")
    (pd / 'voices.json').write_text(json.dumps(dict(placeholder=False, source=f"pieces of the run take {rd.name} (dub_runs.py split), {rec['model']}, {rec['voice']}", total_usd_upper_bound=0.0, lines=vrows), indent=1, ensure_ascii=False) + '\n')
    res = dict(render=rd.name, take_sha256=rec['wav_sha256'], rate=rate, seconds=round(len(x) / rate, 3), words=words, cuts=info, pieces=pieces, ok=bool(ok), method=f"faster-whisper {DN.ASR_MODEL} word times aligned to the text; for each boundary the cut candidates between the two lines' words: silences (10 ms frames more than {SIL_DB} dB under the take's loudest, at least {MIN_SIL} s; cut at the quietest frame nearest the middle), then valleys at least {VALLEY_DB} dB under it (faded {FADE * 1000:.0f} ms each side); the first candidate whose two neighbouring pieces the recognizer (greedy, no timestamps) hears starting and ending with their lines' words (dub_runs.piece_check)")
    (rd / 'split.json').write_text(json.dumps(res, indent=1, ensure_ascii=False) + '\n')
    print(f"{rd.name}: {('every piece matches its line' if ok else 'A PIECE DOES NOT MATCH')}")
    return 0 if ok else 1

def piece_timing(path, post, lead_trim_db=None):
    """A piece as dub_mix places it at pace 1: its trimmed length d, its voice on o and off f inside the trimmed"""
    import caption_pacing as CP
    import dub_mix as DM
    x = DM.read_any_wav(path)
    y, a0 = DM.trim(x)
    if lead_trim_db is not None:
        y, a1 = DM.trim_lead(y, lead_trim_db)
        a0 += a1
    z = DM.post_chain(y, post)
    t, e = CP.envelope(z, CP.RATE44)
    rs, _ = CP.line_activity(t, e, t[0], t[-1], t[0], t[-1])
    return dict(d=round(len(y) / DM.RATE, 4), o=round(rs[0][0], 4), f=round(rs[-1][1], 4), trim_s=round(a0 / DM.RATE, 4))

def scene_limit(track, fit=None):
    """How far a track's last English voice may run: the scene's picture window end, or mix 10's last voice off"""
    import caption_pacing as CP
    w1 = next((r['window_s'][1] for r in load(CP.CUES)['cinematics']['rows'] if r['id'] == SCENES[track]))
    offs = [v['en']['off'] for lid, v in dict(CP.voice_manifest()['lines']).items() if v.get('en') and int(lid[2:4]) == track]
    return max([w1] + offs)

def swap(takes=None, fit=None):
    """Point caption_pacing's takes manifest and dub_mix's fit at other files; returns the old pair."""
    import caption_pacing as CP
    import dub_mix as DM
    old = (CP.TAKES, DM.FIT)
    if takes is not None:
        CP.TAKES = Path(takes)
    if fit is not None:
        DM.FIT = Path(fit)
    return old

def cmd_place(a):
    import caption_pacing as CP
    import dub_lipsync as DL
    import dub_mix as DM
    import dub_store as DS
    out = Path(a.out).resolve()
    if out.exists():
        shutil.rmtree(out)
    (out / 'takes').mkdir(parents=True)
    fit0, subs = (DM.fit_plan(), DM.subtitle_index())
    takes_man = load(TAKES)
    store = CP.takes_dir()
    cv = dict(CP.voice_manifest()['lines'])
    runs = {r['id']: r for r in find_runs()}
    use = {}
    for spec in a.use:
        rid, d = spec.split('=', 1)
        if rid not in runs:
            sys.exit(f'no run {rid}')
        use[rid] = DS.dir_arg(d).resolve()
    keep = set(a.keep or ())
    pieces = {}
    for rid, d in use.items():
        sp, rec = (load(d / 'split.json'), load(d / 'render.json'))
        if not sp.get('ok') or rec['run'] != rid:
            sys.exit(f'{d.name}: not a passing split of {rid}')
        run = runs[rid]
        post = fit0['speakers'].get(DM.speaker_key(run['speaker']), {}).get('post')
        for p in sp['pieces']:
            f = d / 'pieces' / f"{p['line']}.wav"
            if file_sha(f) != p['wav_sha256']:
                sys.exit(f'{f}: not the digest split.json records')
            tm = piece_timing(f, post)
            t0 = p['samples'][0] / sp['rate'] + tm['trim_s']
            pieces[p['line']] = dict(run=rid, render=d.name, file=str(f), wav_sha256=p['wav_sha256'], samples=p['samples'], rate=sp['rate'], take_on=round(t0 + tm['o'], 4), take_off=round(t0 + tm['f'], 4), kept=p['line'] in keep, **tm)
    new = {lid: p for lid, p in pieces.items() if not p['kept']}
    for lid in takes_man['lines']:
        dst = out / 'takes' / f'{lid}.wav'
        if lid in new:
            shutil.copyfile(new[lid]['file'], dst)
        else:
            dst.symlink_to(store / f'{lid}.wav')
    (out / 'takes' / 'voices.json').write_text(json.dumps(dict(placeholder=False, source="English mix 10's approved takes with run pieces (dub_runs.py place): " + ', '.join((f'{r}={d.name}' for r, d in use.items())))) + '\n')
    tm2 = json.loads(json.dumps(takes_man))
    tm2['store'] = dict(path=str(out / 'takes'), lookup="candidate take set (scratch): mix 10's takes linked, the run pieces copied")
    for lid, p in new.items():
        tm2['lines'][lid] = dict(tm2['lines'][lid], take=f"run piece {p['render']}", wav_sha256=p['wav_sha256'], was=dict(take=takes_man['lines'][lid]['take'], wav_sha256=takes_man['lines'][lid]['wav_sha256']))
    takes_p = out / 'takes.json'
    takes_p.write_text(json.dumps(tm2, indent=1, ensure_ascii=False) + '\n')
    ns = argparse.Namespace(census=a.census, build=a.build, work=a.work)
    mouths = DL.measured_mouths(ns)
    tracks = sorted({runs[rid]['track'] for rid in use})
    base = json.loads(json.dumps(fit0))
    earliest, layouts = ({}, {})
    vgap, mgap = (fit0['solver']['gap'], fit0['defaults']['min_gap'])
    fails_pre = []
    for t in tracks:
        w0 = next((r['window_s'][0] for r in load(CP.CUES)['cinematics']['rows'] if r['id'] == SCENES[t]))
        appr = DL.track_voices(t)
        anchor, soft_end = ({}, {})
        for m in [m for m in mouths if m['track'] == t]:
            first, last = DL.mouth_lines(m, appr)
            if first:
                anchor[first] = round(m['runs'][0][0] - DL.LEAD, 4)
            if last:
                soft_end[last] = m['runs'][-1][1]
        order = [lid for lid, _ in DM.slots_for(t, fit0, subs)]
        groups, g = ([], [])
        for lid in order:
            if lid in new and (not g or new[g[-1]]['run'] == new[lid]['run']):
                g.append(lid)
            else:
                if g:
                    groups.append(g)
                g = [lid] if lid in new else []
        if g:
            groups.append(g)
        placed_on = {}
        for g in reversed(groups):
            rid = new[g[0]]['run']
            rl = {ln['id']: ln for ln in runs[rid]['lines']}
            k = order.index(g[-1])
            V = [new[lid]['f'] - new[lid]['o'] for lid in g]
            tail = new[g[-1]]['d'] - new[g[-1]]['f']
            if k + 1 < len(order):
                nid = order[k + 1]
                m10 = cv[g[-1]]['en']
                own = cv[nid]['en']['on'] - m10['off']
                if nid in placed_on:
                    n_on, n_start = placed_on[nid]
                else:
                    n_on, n_start = (cv[nid]['en']['on'], cv[nid]['en']['placed'][0])
                limit = min(n_on - min(vgap, own if own > 0 else vgap), n_start - mgap - DL.MARGIN - tail)
                why = f"{nid} ({subs[nid]['speaker']})"
            else:
                limit, why = (scene_limit(t), "the scene's end")
            fixed = {i: anchor[lid] if lid in anchor else rl[lid]['mix10']['on'] for i, lid in enumerate(g) if lid in anchor or lid in KEEP_START}
            for i, lid in fixed.items():
                pc = new[g[i]]
                if fixed[i] - pc['o'] < w0 + 0.005:
                    post = fit0['speakers'].get(DM.speaker_key(runs[rid]['speaker']), {}).get('post')
                    for db in (40.0, 35.0, 30.0, 25.0, 20.0):
                        tm = piece_timing(pc['file'], post, db)
                        if fixed[i] - tm['o'] >= w0 + 0.005:
                            pc.update(d=tm['d'], o=tm['o'], f=tm['f'], trim_s=tm['trim_s'], lead_trim_db=db)
                            break
                    else:
                        fails_pre.append(f"{g[i]}: its take would start before the scene's window ({w0} s)")
            V = [new[lid]['f'] - new[lid]['o'] for lid in g]
            tail = new[g[-1]]['d'] - new[g[-1]]['f']
            p = [new[g[i + 1]]['take_on'] - new[g[i]]['take_off'] for i in range(len(g) - 1)]
            mp = [new[g[i]]['d'] - new[g[i]]['f'] + new[g[i + 1]]['o'] + mgap + DL.MARGIN for i in range(len(g) - 1)]
            win = []
            for lid in g:
                m, j = (rl[lid]['mix10']['on'], (rl[lid]['ja'] or {}).get('on', rl[lid]['mix10']['on']))
                lo_w = max(min(m, j) - EARLY, w0 + 0.005 + new[lid]['o'])
                win.append((round(lo_w, 4), round(max(max(m, j) + LATE, lo_w), 4)))
            k0 = order.index(g[0])
            if k0 > 0 and 0 not in fixed:
                pid = order[k0 - 1]
                own0 = cv[g[0]]['en']['on'] - cv[pid]['en']['off']
                lo0 = max(win[0][0], cv[pid]['en']['off'] + min(vgap, own0 if own0 > 0 else vgap), cv[pid]['en']['placed'][1] + mgap + DL.MARGIN + new[g[0]]['o'])
                win[0] = (round(lo0, 4), round(max(win[0][1], lo0), 4))
            soft = {i: soft_end[lid] - 0.01 for i, lid in enumerate(g) if lid in soft_end}
            ons, r, ok = run_layout([rl[lid]['mix10']['on'] for lid in g], V, p, mp, fixed, limit - 0.025, window=win, soft=soft)
            soft_met = bool(soft) and ok
            if soft and (not ok):
                ons, r, ok = run_layout([rl[lid]['mix10']['on'] for lid in g], V, p, mp, fixed, limit - 0.025, window=win)
            layouts[f'{rid}:{g[0]}-{g[-1]}'] = dict(run=rid, lines=g, pace=r, fits=ok, limit=round(limit, 3), voice_lengths=[round(v, 3) for v in V], overrun_at_cap=None if ok else round(ons[-1] + V[-1] * r - limit, 3), limit_by=why, take_pauses=[round(v, 3) for v in p], least_pauses=[round(v, 3) for v in mp], fixed={g[i]: v for i, v in fixed.items()}, windows=win, voice_on=ons, mouth_ends={g[i]: v + 0.01 for i, v in soft.items()}, mouth_ends_met=soft_met)
            for i, (lid, on) in enumerate(zip(g, ons)):
                pc = new[lid]
                earliest[lid] = fixed.get(i, win[i][0])
                o = base['lines'].setdefault(lid, {})
                ln = rl[lid]
                was = dict(start=o.get('start'), end=o.get('end'), ratio=ln['mix10']['ratio'], voice_on=ln['mix10']['on'], voice_off=ln['mix10']['off'], wav_sha256=takes_man['lines'][lid]['wav_sha256'])
                for kk in ('mix8', 'lead_trim_db', 'moved', 'retake'):
                    if kk in o:
                        was[kk] = o.pop(kk)
                if pc.get('lead_trim_db') is not None:
                    o['lead_trim_db'] = pc['lead_trim_db']
                s = round(on - pc['o'] * r, 3)
                o['start'] = s
                if r < 1:
                    o['end'] = round(s + math.ceil((pc['d'] * r + 0.001) * 100 - 1e-09) / 100, 3)
                else:
                    o['end'] = math.ceil((s + pc['d']) * 1000 + 1) / 1000
                o['run'] = dict(run=rid, render=pc['render'], piece_sha256=pc['wav_sha256'], samples=pc['samples'], base_voice_on=round(on, 3), pace=r, was=was)
                placed_on[lid] = (on, s)
    base_p = out / 'fit_base.json'
    base_p.write_text(json.dumps(base, indent=1, ensure_ascii=False) + '\n')
    short = fails_pre + [f"{k}: its pieces do not fit by {v['limit']:.2f} s ({v['limit_by']}) even at the cap" for k, v in layouts.items() if not v['fits']]
    if short:
        (out / 'place.json').write_text(json.dumps(dict(use={r: str(d) for r, d in use.items()}, layouts=layouts, fits=False, fails=short), indent=1) + '\n')
        for k, v in layouts.items():
            print(f"{k}: pace {v['pace']}, {('fits' if v['fits'] else 'DOES NOT FIT')} by {v['limit']:.2f} s ({v['limit_by']}); voice starts {v['voice_on']}")
        print('place: DOES NOT FIT: ' + '; '.join(short))
        return 1
    plan = {}
    old = swap()
    try:
        for t in tracks:
            mt = [m for m in mouths if m['track'] == t]
            lim = scene_limit(t)
            swap(takes=takes_p)
            rows = DL.plan_track(t, mt, DL.track_voices(t, base_p), base, subs, lim, earliest)
            swap(takes=old[0])
            base_rows = DL.plan_track(t, mt, DL.track_voices(t), fit0, subs, lim)
            DL.keep_unmoved(rows, base_rows, set(new))
            plan[t] = rows
        swap(fit=base_p)
        DL.write_fit(plan, out / 'fit.json')
    finally:
        swap(*old)
    fit = load(out / 'fit.json')
    fit['status'] = '' + ', '.join((f'{r} {d.name}' for r, d in use.items())) + ") in place of the separate takes, laid out at the take's own pauses where the room allows (dub_runs.run_layout: within EARLY/LATE of mix 10, pauses given up before speed), then the mix 8 rule. Not the shipped fit."
    (out / 'fit.json').write_text(json.dumps(fit, indent=1, ensure_ascii=False) + '\n')
    (out / 'plan.json').write_text(json.dumps(plan, indent=1) + '\n')
    old = swap(fit=out / 'fit.json')
    try:
        mixed = list(tracks) if a.tracks_only else list(TRACKS) + [29]
        rc = DM.mix(argparse.Namespace(voices=out / 'takes', beds=Path(a.beds), cue=Path(a.cue), out=out / 'mix', tracks=mixed))
    finally:
        swap(*old)
    rep = load(out / 'mix' / 'mix_report.json')
    pins = load(HERE / 'manifests/dub_english.json')['tracks']
    old = swap(takes=takes_p, fit=out / 'fit.json')
    try:
        cand = {t: DL.track_voices(t, out / 'fit.json') for t in tracks}
    finally:
        swap(*old)
    lines, gaps = ({}, [])
    for rid in use:
        rl = runs[rid]['lines']
        for k, ln in enumerate(rl):
            lid = ln['id']
            c = cand[runs[rid]['track']][lid]['en']
            row = next((r for r in plan[runs[rid]['track']] if r['id'] == lid))
            lines[lid] = dict(run=rid, mix10=dict(on=ln['mix10']['on'], off=ln['mix10']['off'], ratio=ln['mix10']['ratio']), candidate=dict(on=c['on'], off=c['off'], ratio=c['ratio'], placed=c['placed']), kept=lid not in new, notes=row['notes'], anchored=row['anchored'])
            if lid in new:
                lines[lid]['piece'] = {k_: new[lid].get(k_) for k_ in ('render', 'wav_sha256', 'samples', 'rate', 'd', 'o', 'f', 'take_on', 'take_off', 'lead_trim_db')}
            if k + 1 < len(rl):
                nid = rl[k + 1]['id']
                cn = cand[runs[rid]['track']][nid]['en']
                gaps.append(dict(run=rid, between=[lid, nid], mix10=round(rl[k + 1]['mix10']['on'] - ln['mix10']['off'], 3), take=round(new[nid]['take_on'] - new[lid]['take_off'], 3) if lid in new and nid in new else None, candidate=round(cn['on'] - c['off'], 3)))
    mouth_rows = []
    for m in mouths:
        if m['track'] in tracks and any((lid in lines for lid in m['lines'])):
            old = swap()
            mix10_v = DL.track_voices(m['track'])
            mouth_rows.append(dict(scene=m['scene'], who=m['who'], runs=m['runs'], ja=DL.compare(m, mix10_v, 'ja'), mix10=DL.compare(m, mix10_v, 'en'), candidate=DL.compare(m, cand[m['track']], 'en')))
    tracks_rep = {}
    for t in [t for t in mixed if t in TRACKS]:
        r = rep['tracks'][str(t)]
        tracks_rep[t] = dict(ok=r['ok'], sha256=r['sha256'], same_as_mix10=r['sha256'] == pins[str(t)]['english_wav_sha256'], en_lufs=r['en_lufs'], ja_lufs=r['ja_lufs'], en_dialogue_lufs=r['en_dialogue_lufs'], ja_dialogue_lufs=r['ja_dialogue_lufs'], peak_dbfs=r['peak_dbfs'], track_margin_lu=round(2.0 - abs(r['en_lufs'] - r['ja_lufs']), 2), dialogue_margin_lu=round(1.0 - abs(r['en_dialogue_lufs'] - r['ja_dialogue_lufs']), 2), worst_line_lu=max((abs(x['voice_lufs'] - x['voice_target_lufs']) for x in r['lines'] if x.get('voice_target_lufs') is not None and x.get('voice_lufs') is not None), default=None))
    fails = []
    for t in tracks:
        rows = sorted(plan[t], key=lambda r: r['start'])
        for r in rows:
            if r['id'] not in lines and r['moved']:
                fails.append(f"{r['id']} (another line) moves: {'; '.join(r['notes'])}")
            if r['id'] in lines and any(('LONGER' in n for n in r['notes'])):
                fails.append(f"{r['id']}: {'; '.join(r['notes'])}")
        w0_t = next((r['window_s'][0] for r in load(CP.CUES)['cinematics']['rows'] if r['id'] == SCENES[t]))
        early = [lid for lid in lines if int(lid[2:4]) == t and lines[lid]['candidate']['placed'][0] < w0_t]
        if early:
            fails.append(f"{early}: placed before the scene's window ({w0_t} s), where the pack must be silent")
        lim = scene_limit(t)
        if rows and rows[-1]['id'] in lines and (lines[rows[-1]['id']]['candidate']['off'] > lim + 0.005):
            fails.append(f"{rows[-1]['id']} ends at {lines[rows[-1]['id']]['candidate']['off']:.2f} s, after the scene limit {lim:.2f} s")
    unchanged_bad = [] if a.tracks_only else [t for t in TRACKS if t not in tracks and (not tracks_rep[t]['same_as_mix10'])]
    res = dict(use={r: str(d) for r, d in use.items()}, keep=sorted(keep), tracks=tracks, layouts=layouts, lines=lines, gaps=gaps, mouths=mouth_rows, mix=dict(rc=rc, tracks=tracks_rep), fits=not fails, fails=fails, unchanged_tracks_identical=not unchanged_bad, fit_sha256=file_sha(out / 'fit.json'), takes_json_sha256=file_sha(takes_p), rule=f"run_layout (EARLY {EARLY} s, LATE {LATE} s, fixed: the portraits' anchors and KEEP_START {sorted(KEEP_START)}), then dub_lipsync.plan_track (the mix 8 rule) and keep_unmoved")
    (out / 'place.json').write_text(json.dumps(res, indent=1, ensure_ascii=False) + '\n')
    for lid, r in lines.items():
        m, c = (r['mix10'], r['candidate'])
        print(f"{lid:8} mix 10 {m['on']:6.2f}-{m['off']:6.2f} x{m['ratio']:.3f} -> {c['on']:6.2f}-{c['off']:6.2f} x{c['ratio']:.3f}{(' KEPT' if r['kept'] else '')}{(' ANCHOR' if r['anchored'] else '')} {'; '.join(r['notes'])}")
    for g in gaps:
        print(f"  gap {g['between'][0]}|{g['between'][1]}: mix 10 {g['mix10']:.2f}, take {('-' if g['take'] is None else format(g['take'], '.2f'))}, candidate {g['candidate']:.2f}")
    for m in mouth_rows:
        print(f"  mouth {m['who'][:40]}: start/end/silent/still  ja {m['ja']['start']}/{m['ja']['end']}/{m['ja']['moving_silent']}/{m['ja']['voice_still']}  mix10 {m['mix10']['start']}/{m['mix10']['end']}/{m['mix10']['moving_silent']}/{m['mix10']['voice_still']}  cand {m['candidate']['start']}/{m['candidate']['end']}/{m['candidate']['moving_silent']}/{m['candidate']['voice_still']}")
    for t, r in tracks_rep.items():
        print(f"  tr{t}: {('OK' if r['ok'] else 'FAIL')}{(' (= mix 10)' if r['same_as_mix10'] else '')} margins: track {r['track_margin_lu']} LU, dialogue {r['dialogue_margin_lu']} LU, peak {r['peak_dbfs']} dBFS, worst line {(r['worst_line_lu'] if r['worst_line_lu'] is None else round(r['worst_line_lu'], 2))} LU")
    print(f"place: mix rc {rc}; {('fits' if not fails else 'DOES NOT FIT: ' + '; '.join(fails))}; unchanged tracks {('identical to mix 10' if not unchanged_bad else 'DIFFER: ' + str(unchanged_bad))}")
    return 0 if rc == 0 and (not fails) and (not unchanged_bad) else 1

def voices_alone(track, takes=None, fit=None):
    """One track's English voices placed exactly as dub_mix.mix_track places them (slot, pace, level, post chain,"""
    import caption_pacing as CP
    import dub_beds as B
    import dub_mix as DM
    old = swap(takes, fit)
    try:
        fit_, subs = (DM.fit_plan(), DM.subtitle_index())
        refs = B.manifest().get('reference', {}).get('lines', {})
        n = int(load(HERE / 'manifests/dub_english.json')['tracks'][str(track)]['samples'])
        voices = {lid: CP.take(lid) for lid, s in subs.items() if s['track'] == track and fit_['lines'].get(lid, {}).get('voiced', True) is not False}
        out, _, _, _ = DM.mix_track(track, np.zeros((2, n)), voices, fit_, subs, refs, fit_['checks'], None)
    finally:
        swap(*old)
    return out

def cmd_voices(a):
    import dub_beds as B
    import dub_lipsync as DL
    cand = Path(a.cand) if a.cand else None
    y = voices_alone(a.track, cand / 'takes.json' if cand else None, cand / 'fit.json' if cand else None)
    out = Path(a.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    wav = out.with_suffix('.wav')
    B.write_wav16(wav, y.astype(np.float32))
    if out.suffix == '.mp3':
        sha = DL.mp3(wav, out)
        wav.unlink()
        print(f'{out} {sha[:16]}')
    else:
        print(f'{wav} {file_sha(wav)[:16]}')
    return 0

def name_rows(work, render):
    """dub_name's measures for each piece of a name line in a split render: the round 3 measure against the"""
    import dub_name as DN
    work = Path(work)
    DN.ASR_CACHE = work / 'asr'
    DN.ASR_CACHE.mkdir(parents=True, exist_ok=True)
    audit = load(work / 'audit.json')
    info = DN.line_info()
    spaces = dict(audit['voice_space'])
    target, clips = DN.load_target(work)
    rd = Path(render)
    rec = load(rd / 'render.json')
    out = {}
    for p in load(rd / 'split.json')['pieces']:
        lid = p['line']
        if lid not in info:
            continue
        f = rd / 'pieces' / f'{lid}.wav'
        i = dict(info[lid], voice=rec['voice'])
        row, aux = DN.measure_take(f, i, spaces[rec['voice']])
        if row['found']:
            row['class'] = DN.classify(row)
            if DN.post_spec(i['speaker']):
                row['radio'] = DN.radio_recognizer(f, i['text'], row['times'], i['speaker'])
        row['jp'] = DN.jp_take(aux['x'], aux['rate'], aux['T'], aux['m'], spaces[rec['voice']], rec['voice'], target, clips, row['window'])
        heard = row.get('heard') or ''
        row['sounds_like_hear_you'] = bool(re.search('\\b(hear|here|hea?r?)\\b.*\\byou\\b|\\bhear you\\b|\\bhere you\\b', heard, re.I))
        appr = audit['occurrences'].get(lid, {})
        row['approved'] = dict(jp_score=(appr.get('jp') or {}).get('score'), heard=appr.get('heard'), take=appr.get('take'), wav_sha256=appr.get('wav_sha256'))
        out[lid] = {k: row[k] for k in ('file_sha256', 'seconds', 'asr', 'heard', 'found', 'class', 'recognizer', 'radio', 'jp', 'sounds_like_hear_you', 'approved', 'window') if k in row}
    return out

def cmd_names(a):
    res = {}
    for r in a.renders:
        rows = name_rows(a.work, r)
        res[Path(r).name] = rows
        (Path(r) / 'names.json').write_text(json.dumps(rows, indent=1, ensure_ascii=False) + '\n')
        for lid, row in rows.items():
            j = row.get('jp') or {}
            print(f"{Path(r).name:22} {lid:7} JP {j.get('score')} (approved {row['approved']['jp_score']}); hi share {j.get('v1_share')}, r F2 {j.get('r_f2')}, pitch {j.get('pitch_v1_v2')}/{j.get('pitch_fall_v2')} st; recognizer wrote {row.get('heard')!r}" + (' HEAR-YOU' if row['sounds_like_hear_you'] else ''))
    return 0

def cmd_candidate(a):
    """A placed candidate as the game plays it, all in scratch: the payload (dub_delta.py encode, then decode"""
    import subprocess
    import caption_pacing as CP
    py = sys.executable
    cand = Path(a.cand).resolve()
    place = load(cand / 'place.json')
    rep = load(cand / 'mix' / 'mix_report.json')
    tracks = place['tracks']
    S = HERE / 'scripts'
    (cand / 'payload').mkdir(exist_ok=True)
    payload = cand / 'payload' / 'strider_ex_english.dub'
    subprocess.run([py, str(S / 'dub_delta.py'), 'encode', '--cue', str(a.cue), '--english', str(cand / 'mix'), '--out', str(payload)], check=True)
    dec = cand / 'payload' / 'decoded'
    if dec.exists():
        shutil.rmtree(dec)
    subprocess.run([py, str(S / 'dub_delta.py'), 'decode', '--cue', str(a.cue), '--payload', str(payload), '--out', str(dec)], check=True)
    bad = [t for t in TRACKS if file_sha(dec / f'tr{t:02d}_en.wav') != rep['tracks'][str(t)]['sha256']]
    if bad:
        sys.exit(f'decode differs from the mix: {bad}')
    man = load(ROOT / 'cpsplus/manifests/strider_ex_audio.json')
    for e in man['english']:
        if e['disc_track'] in tracks:
            e['pcm_sha256'] = None
    mp = cand / 'strider_ex_audio.json'
    mp.write_text(json.dumps(man, indent=1, ensure_ascii=False) + '\n')
    pk = cand / 'pack'
    if pk.exists():
        shutil.rmtree(pk)
    subprocess.run([py, '-m', 'cpsplus.pack.build_strider_ex', '--english', str(payload), '--pin', '--manifest', str(mp), '--out-dir', str(pk)], check=True, cwd=ROOT, stdout=subprocess.DEVNULL)
    pack = pk / 'strider_ex.cpk'
    man = load(mp)
    pin = dict(sha256=file_sha(pack), bytes=pack.stat().st_size, windows=True, note=f'candidate pack (dub_runs.py candidate) for {cand.name}')
    old = swap(cand / 'takes.json', cand / 'fit.json')
    saved = (CP.PACK, CP.VOICE_MANIFEST, CP.FIT)
    CP.PACK, CP.VOICE_MANIFEST, CP.FIT = (pin, cand / 'caption_voice.json', cand / 'fit.json')
    try:
        rc = CP.cmd_measure(argparse.Namespace(pack=pack, check=False, write=True, out=None))
        if rc:
            sys.exit('caption_pacing measure: the pack does not line up')
        if a.build_out:
            import build_ex as BX
            argv = ['build_ex.py', '--rom-dir', str(a.rom_dir), '--census', str(a.census), '--vasm', str(a.vasm), '--openings', str(a.openings), '--out', str(a.build_out)]
            if a.portraits:
                argv += ['--portraits', str(a.portraits)]
            if a.desert_census:
                argv += ['--desert-census', str(a.desert_census)]
            saved_argv = sys.argv
            sys.argv = argv
            try:
                BX.main()
            finally:
                sys.argv = saved_argv
            chk = CP.cmd_check(argparse.Namespace(build=a.build_out, cue=None, bounds_only=False, verbose=False, json=cand / 'pacing_check.json'))
            if chk:
                sys.exit('caption_pacing check FAILED on the candidate build')
    finally:
        CP.PACK, CP.VOICE_MANIFEST, CP.FIT = saved
        swap(*old)
    old_cv = dict(CP.voice_manifest()['lines'])
    new_cv = load(cand / 'caption_voice.json')['lines']
    moved = sorted((lid for lid, v in new_cv.items() for lang in v if lang in ('en', 'ja') if abs(v[lang]['on'] - old_cv[lid][lang]['on']) > 0.0005 or abs(v[lang]['off'] - old_cv[lid][lang]['off']) > 0.0005))
    res = dict(payload=dict(sha256=file_sha(payload), bytes=payload.stat().st_size), pack=dict(sha256=pin['sha256'], bytes=pin['bytes'], english_rows={e['id']: e['pcm_sha256'] for e in man['english'] if e['disc_track'] in tracks}), caption_voice_sha256=file_sha(cand / 'caption_voice.json'), caption_lines_moved=moved)
    if a.build_out:
        b = Path(a.build_out)
        res['build'] = dict(dir=str(b), ex_bank={m: file_sha(b / m / 'strex_p6.bin') for m in ('striderua', 'striderjr') if (b / m / 'strex_p6.bin').exists()}, pacing_check=load(cand / 'pacing_check.json')['passed'])
    (cand / 'candidate.json').write_text(json.dumps(res, indent=1) + '\n')
    print(json.dumps(res, indent=1))
    return 0

def cmd_clips(a):
    """The changed scenes as the candidate build plays them (USA, English dub, flag 0x01): HBMAME picture and"""
    import caption_pacing as CP
    import ex_gate as EG
    import subprocess
    stage = {'prologue': 0, 'brief_st_petersburg': 0, 'intro_desert': 5, 'brief_siberia': 1, 'brief_aerial': 3, 'brief_amazon': 2, 'flight': 4, 'welcome_meio': 4}
    b, pack = (Path(a.build), Path(a.pack))
    saved = CP.PACK
    CP.PACK = dict(sha256=file_sha(pack), bytes=pack.stat().st_size, windows=True, note='candidate pack')
    try:
        rd = CP.pack_reader(pack)
        cues = {r['id']: r for r in load(CP.CUES)['cinematics']['rows']}
        binary = load(Path(a.runtime) / 'runtime.json')['binary']
        streams = load(b / 'build.json')['sets'][EG.PARENT['striderus01']]['streams']
        out = Path(a.out)
        out.mkdir(parents=True, exist_ok=True)
        for sid in a.scenes:
            w0, w1 = cues[sid]['window_s']
            pcm = CP.pack_track(rd, int(cues[sid]['en'], 16))
            work = out / f'runs_{sid}'
            if work.exists():
                shutil.rmtree(work)
            work.mkdir()
            sets = CP.stage_variant(b, 'striderus01', 1, work / 'sets', Path(a.hbmame), Path(a.rom_dir))
            st = stage[sid]
            rows, snd, capw = CP.hb_run(binary, sets, 'striderus01', work / 'probe', 5400 if st == 0 else 4200, st)
            sc = next((s for s in CP.scenes_in_run(rows, snd, capw, streams) if s['scene'] == sid))
            f0 = sc['first_frame']
            cue_f = sc['cue'][0]['record'] + f0
            t1 = w1 - w0 + 0.3
            shots = range(cue_f - 2, cue_f + int(t1 * CP.CPS1_HZ) + 3)
            rows, snd, capw = CP.hb_run(binary, sets, 'striderus01', work / 'shots', max(shots) + 5, st, shots)
            raw = out / f'{sid}_raw.mp4'
            info = CP.make_clip(work / 'shots', rows, snd, f0, pcm, 0.0, t1, raw, f'{sid} en_dub {a.label}')
            subprocess.run(['ffmpeg', '-loglevel', 'error', '-y', '-i', str(raw), '-c:v', 'libx264', '-crf', '24', '-preset', 'slow', '-c:a', 'aac', '-b:a', '160k', '-movflags', '+faststart', str(out / f'{sid}.mp4')], check=True)
            raw.unlink()
            shutil.rmtree(work)
            print(sid, info, (out / f'{sid}.mp4').stat().st_size, flush=True)
    finally:
        CP.PACK = saved
    return 0

def compact_place(pl):
    """A place.json without the bulky parts: the layouts, each line's mix 10 and candidate voice, the gaps,"""
    out = dict(fits=pl.get('fits'), fails=pl.get('fails', []), layouts=pl.get('layouts'))
    if 'lines' in pl:
        out['lines'] = {lid: dict(mix10=v['mix10'], candidate={k: v['candidate'][k] for k in ('on', 'off', 'ratio')}, kept=v['kept'], anchored=v['anchored'], notes=v['notes'], **{'piece': {k: v['piece'][k] for k in ('wav_sha256', 'samples', 'rate')}} if 'piece' in v else {}) for lid, v in pl['lines'].items()}
        out['gaps'] = pl['gaps']
        out['mouths'] = [{k: m[k] for k in ('scene', 'who', 'ja', 'mix10', 'candidate')} for m in pl.get('mouths', [])]
        out['tracks'] = pl['mix']['tracks']
        out['mix_rc'] = pl['mix']['rc']
        out['unchanged_tracks_identical'] = pl.get('unchanged_tracks_identical')
        out['fit_sha256'] = pl.get('fit_sha256')
    return out

def cmd_record(a):
    root, cands = (Path(a.renders_root), Path(a.cands))
    renders = {}
    for rd in sorted((p for p in root.iterdir() if (p / 'render.json').exists())):
        rec = load(rd / 'render.json')
        row = {k: rec.get(k, False if k == 'urgent' else None) for k in ('run', 'tag', 'recipe', 'recipe_note', 'pace', 'urgent', 'speaker', 'voice', 'model', 'lines', 'prompt', 'text', 'characters', 'usd_upper_bound', 'wav_sha256', 'seconds', 'rate', 'at')}
        if (rd / 'split.json').exists():
            sp = load(rd / 'split.json')
            row['split'] = dict(ok=sp['ok'], error=sp.get('error'), method=sp.get('method'), cuts=[{k: c[k] for k in ('between', 'kind', 'cut_sample', 'cut_db_under_peak', 'candidate', 'candidates', 'fade_s', 'silence_s') if k in c} for c in sp.get('cuts', [])], pieces=[dict(line=p['line'], samples=p['samples'], wav_sha256=p['wav_sha256'], heard=p['heard'], ok=p['check']['ok'], ratio=p['check']['ratio']) for p in sp.get('pieces', [])])
        if (rd / 'names.json').exists():
            row['names'] = {lid: dict(jp_score=(n.get('jp') or {}).get('score'), jp={k: (n.get('jp') or {}).get(k) for k in ('v1_share', 'r_f2', 'r_f3_drop', 'pitch_v1_v2', 'pitch_fall_v2', 'level_v1_v2', 'dtw', 'r_kind')}, heard=n.get('heard'), sounds_like_hear_you=n.get('sounds_like_hear_you'), llr_line=(n.get('recognizer') or {}).get('llr_line'), approved_jp_score=n['approved']['jp_score']) for lid, n in load(rd / 'names.json').items()}
        pl = cands / f'take_{rd.name}' / 'place.json'
        if pl.exists():
            row['placement'] = compact_place(load(pl))
        renders[rd.name] = row
    m = load(MANIFEST) if MANIFEST.exists() else dict(schema=1)
    m['renders'] = renders
    ledgers = {f.name: load(f) for f in sorted(root.glob('ledger*.json'))}
    att = [r for led in ledgers.values() for r in led['attempts']]
    m['spend'] = dict(usd_upper_bound_saved=round(sum((led['usd_upper_bound_saved'] for led in ledgers.values())), 4), usd_upper_bound_billable=round(sum((led['usd_upper_bound_billable'] for led in ledgers.values())), 4), ledgers={k: dict(saved=v['usd_upper_bound_saved'], billable=v['usd_upper_bound_billable'], attempts=len(v['attempts'])) for k, v in ledgers.items()}, attempts=len(att), not_saved=[r for r in att if r['status'] != 'saved'], by_speaker={})
    for r in renders.values():
        k = 'narrator' if r['speaker'] == 'Narrator' else 'others'
        m['spend']['by_speaker'][k] = round(m['spend']['by_speaker'].get(k, 0) + r['usd_upper_bound'], 4)
    m['status'] = 'Digests, prompts, sample offsets and measures only (no audio); the takes are in the durable take store (dub_store.py), the review material is scratch.'
    for f in a.final or ():
        d = Path(f)
        fin = dict(place=compact_place(load(d / 'place.json')))
        fin['use'] = {r: Path(p).name for r, p in load(d / 'place.json')['use'].items()}
        fin['keep'] = load(d / 'place.json').get('keep', [])
        if (d / 'candidate.json').exists():
            fin['candidate'] = load(d / 'candidate.json')
            fin['candidate'].get('build', {}).pop('dir', None)
        m.setdefault('candidates', {})[d.name] = fin
    if a.write:
        write_manifest(m)
    else:
        print(json.dumps({k: len(v) if isinstance(v, dict) else v for k, v in m.items()}, indent=1)[:2000])
    return 0

def self_test():
    fails = []

    def check(name, cond, detail=''):
        print(f"{('PASS' if cond else 'FAIL')} {name}{(': ' + str(detail) if detail else '')}")
        if not cond:
            fails.append(name)
    words = [dict(word=w, start=s, end=e) for w, s, e in [('A.D.', 0.0, 0.3), ('2042.', 0.3, 0.9), ('A', 1.2, 1.3), ('dark', 1.3, 1.5), ('ruler,', 1.5, 1.8), ('um', 1.8, 1.9), ('Strider', 2.3, 2.7), ('hear', 2.8, 2.9), ('you.', 2.9, 3.1)]]
    own = align_lines(words, ['A.D. twenty forty-two.', 'A dark ruler,', 'Strider Hi-ryoo.'])
    check('align_lines: each word to its line, an insertion to the line before', own == [0, 0, 1, 1, 1, 1, 2, 2, 2], own)
    rate = 24000
    rng = np.random.default_rng(1)

    def burst(d, level=0.3):
        return rng.standard_normal(int(d * rate)) * level

    def gap(d):
        return np.zeros(int(round(d * rate)))
    x = np.concatenate([burst(0.4), gap(0.06), burst(0.25), gap(0.08), burst(0.25), gap(0.25), burst(0.15, 0.3 * 10 ** (-35 / 20)), gap(0.08), burst(0.8)])
    lengths = {'one': 0.4, 'two': 0.58, 'three': 0.8, 'tw': 0.25}

    def fake_hear(seg, r):
        """'Words': clusters of loud runs (within 30 dB of the loudest) closer than 0.12 s, named by length."""
        t, db = frames_db(seg, r)
        on = db > db.max() - 30
        runs, s = ([], None)
        for k, v in enumerate(on):
            if v and s is None:
                s = t[k]
            if not v and s is not None:
                runs.append([s, t[k - 1]])
                s = None
        if s is not None:
            runs.append([s, t[-1]])
        cl = []
        for a_, b_ in runs:
            if cl and a_ - cl[-1][1] < 0.12:
                cl[-1][1] = b_
            elif b_ - a_ > 0.1:
                cl.append([a_, b_])
        return ' '.join((min(lengths, key=lambda w: abs(lengths[w] - (b_ - a_))) for a_, b_ in cl))
    ws = [dict(word='one', start=0.0, end=0.4), dict(word='two', start=0.46, end=1.04), dict(word='three', start=1.52, end=2.32)]
    cuts, info, _, heard = split_take(x, rate, ws, ['one', 'two', 'three'], ['a', 'b', 'c'], fake_hear)
    check('split_take: the closure inside "two" (the longest silence) is rejected by the recognizer; the cut goes into the real gap', 0.4 * rate < cuts[0] < 0.46 * rate and info[0]['candidate'] > 1, (cuts[0] / rate, info[0]['candidate']))
    check('split_take: the second cut mid-way into the silence before the breath (the longer one)', 1.1 * rate < cuts[1] < 1.22 * rate, cuts[1] / rate)
    check('split_take: every piece heard as its line', [h for h, _ in heard] == ['one', 'two', 'three'], [h for h, _ in heard])
    y = np.concatenate([burst(0.4), burst(0.1, 0.3 * 10 ** (-28 / 20)), burst(0.8)])
    cuts2, info2, _, _ = split_take(y, rate, [dict(word='one', start=0, end=0.4), dict(word='three', start=0.5, end=1.3)], ['one', 'three'], ['a', 'b'], fake_hear)
    check('split_take: no silence: a valley, flagged and faded', info2[0]['kind'].startswith('valley') and 0.38 * rate <= cuts2[0] <= 0.52 * rate and (info2[0]['fade_s'] > 0), info2[0])
    p2 = cut_pieces(y, rate, cuts2, [info2[0]['kind']])
    check('cut_pieces: the valley edges fade to zero, the slices keep every sample', abs(p2[0][-1]) < 0.001 and abs(p2[1][0]) < 1e-09 and (sum((len(p) for p in p2)) == len(y)))
    check("toks: A.D. and U.N.'s as the recognizer writes them, numbers as one NUM", toks("A.D. twenty forty-two, the U.N.'s") == toks("A .D. 2042, the UN's") == toks("AD 2042, the UN's") == ['ad', 'NUM', 'the', 'uns'] and toks('A dark ruler') == ['a', 'dark', 'ruler'], toks("A .D. 2042, the UN's"))
    check("piece_check: the line's words, the name heard as anything, digits for number words", piece_check('Super Base to Hiro. Standard time 0325 hours.', 'Super Base to Hiryu. Standard time 0325 hours.')['ok'] and piece_check('Strider Hyrule', 'Strider Hiryu.')['ok'] and piece_check('A dark ruler, calling himself the Grand Master.', 'A dark ruler, calling himself the Grandmaster,')['ok'])
    check("piece_check: a neighbour's word at the end or start fails", not piece_check('His name... Strider', 'His name...')['ok'] and (not piece_check('Two. A dark ruler calling himself the Grandmaster.', 'A dark ruler, calling himself the Grandmaster,')['ok']))
    x, r, ok = run_layout([1.0, 2.3, 3.5], [1.0, 1.0, 1.0], [0.2, 0.2], [0.09, 0.09], {}, 10.0)
    check("run_layout: the take's pauses where the windows allow, at pace 1", ok and r == 1.0 and (abs(x[1] - x[0] - 1.2) < 0.002) and (abs(x[2] - x[1] - 1.2) < 0.002), (x, r))
    x, r, ok = run_layout([1.0, 2.3, 4.0], [1.0, 0.9, 0.95], [0.05, 0.1], [0.09, 0.09], {0: 1.0}, 10.0)
    check("run_layout: a line held at its window's start; the error shared, more in the longer pause", ok and abs(x[2] - 3.75) < 0.001 and (2.09 <= x[1] <= 2.55) and (x[1] - 2.09 < x[2] - x[1] - 0.9), x)
    x, r, ok = run_layout([1.0, 2.2], [1.0, 1.0], [0.3], [0.09], {}, 3.1)
    check('run_layout: a limit met by giving up pause first (pace 1)', ok and r == 1.0 and (x[1] + 1.0 <= 3.1 + 1e-06) and (x[1] - x[0] - 1.0 < 0.3), (x, r))
    x, r, ok = run_layout([1.0, 2.2], [1.0, 1.0], [0.3], [0.09], {}, 2.85)
    check('run_layout: then speed, down to the cap', ok and abs(r - 0.9) < 1e-09 and (x[1] + 0.9 <= 2.85 + 1e-06), (x, r))
    x, r, ok = run_layout([1.0, 2.2], [1.0, 1.0], [0.3], [0.09], {}, 2.6)
    check('run_layout: a run that cannot fit at the cap is reported', not ok, (x, r))
    x, r, ok = run_layout([1.0, 2.3], [1.0, 1.0], [3.0], [0.09], {1: 2.3}, 10.0)
    check('run_layout: a fixed line (an anchor, the title card) stays', ok and x[1] == 2.3, x)
    x, r, ok = run_layout([1.0, 2.3], [1.0, 1.0], [0.3], [0.09], {0: 1.0}, 10.0, soft={1: 3.2})
    check('run_layout: a mouth stopping (soft end) is met by giving up pause first', ok and r == 1.0 and (x[1] + 1.0 <= 3.2 + 1e-06), (x, r))
    x, r, ok = run_layout([1.0, 2.3], [1.0, 1.0], [0.3], [0.09], {0: 1.0}, 10.0, soft={1: 3.0})
    check('run_layout: then by speed within the cap', ok and 0.9 <= r < 1.0 and (x[1] + r <= 3.0 + 1e-06), (x, r))
    x, r, ok = run_layout([1.0, 2.3], [1.0, 1.0], [0.3], [0.09], {0: 1.0}, 10.0, soft={1: 2.8})
    check('run_layout: a soft end the cap cannot reach does not fit (cmd_place then drops it)', not ok, (x, r))
    run = dict(lines=[dict(direction='calm', mix10=dict(on=1.0, off=3.0), gap_after=dict(voice=0.05)), dict(direction='calm', mix10=dict(on=3.05, off=4.0))])
    p = run_prompt(run, 'S.', 'Y.', None, 1.0, 0.15)
    check("run_prompt: each line's length, the pause at least the gap, the total; one direction for both lines", 'line 1 about 2.0 seconds, then a pause of about 0.15 seconds' in p and 'about 3.0 seconds' in p and ('lines 1-2: calm' in p), p)
    print(f"\n{('ALL PASS' if not fails else 'FAILED: ' + ', '.join(fails))}")
    return 1 if fails else 0

def run_layout(m_on, V, p, mp, fixed, limit, r_min=0.9, iters=400, window=None, soft=None):
    """The base layout of a run's pieces (voice starts in track seconds, and one pace for the run) that keeps the"""
    n = len(V)
    window = window or [(m - EARLY, m + LATE) for m in m_on]
    lo = [fixed.get(i, window[i][0]) for i in range(n)]
    hi = [fixed.get(i, window[i][1]) for i in range(n)]
    soft = soft or {}

    def ends(i):
        return min([soft[i]] + ([limit] if i == n - 1 else [])) if i in soft else limit if i == n - 1 else None

    def minimal(r):
        x = [lo[0]]
        for i in range(1, n):
            x.append(max(lo[i], x[-1] + V[i - 1] * r + mp[i - 1]))
        ok = all((x[i] <= fixed[i] + 1e-06 for i in fixed)) and all((x[i] + V[i] * r <= ends(i) + 1e-06 for i in range(n) if ends(i) is not None))
        return (x, ok)
    r = 1.0
    x, ok = minimal(r)
    while not ok and r > r_min + 1e-09:
        r = max(r_min, round(r - 0.0025, 4))
        x, ok = minimal(r)
    if not ok:
        return ([round(v, 4) for v in x], r, False)
    P = [max(p[i] * r, mp[i]) for i in range(n - 1)]
    w = [1.0 / (q + 0.15) for q in P]
    lam = 0.02
    x[0] = min(max(m_on[0], lo[0]), hi[0])
    for i in range(1, n):
        x[i] = min(max(x[i - 1] + V[i - 1] * r + P[i - 1], lo[i]), hi[i])
    for _ in range(iters):
        for j in range(n):
            if j in fixed:
                continue
            num, den = (lam * m_on[j], lam)
            if j > 0:
                num += w[j - 1] * (x[j - 1] + V[j - 1] * r + P[j - 1])
                den += w[j - 1]
            if j + 1 < n:
                num += w[j] * (x[j + 1] - V[j] * r - P[j])
                den += w[j]
            x[j] = min(max(num / den, lo[j]), hi[j])
    for i in range(n - 1):
        x[i + 1] = max(x[i + 1], x[i] + V[i] * r + mp[i])
    for i in range(n - 1, -1, -1):
        if ends(i) is not None:
            x[i] = min(x[i], ends(i) - V[i] * r)
        if i + 1 < n:
            x[i] = min(x[i], x[i + 1] - mp[i] - V[i] * r)
    return ([round(v, 4) for v in x], r, True)

def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('--self-test', action='store_true')
    sub = p.add_subparsers(dest='cmd')
    s = sub.add_parser('runs')
    s.add_argument('--write', action='store_true')
    s = sub.add_parser('render')
    s.add_argument('--credentials', type=Path, required=True)
    s.add_argument('--set', required=True, help='a holding set in the durable take store (dub_store.py): each render is a new <run>_<tag> directory there, beside its ledger')
    s.add_argument('--run', required=True)
    s.add_argument('--tag', required=True)
    s.add_argument('--recipe', choices=['jp', 'jp_hirryu', 'name'], default='jp')
    s.add_argument('--pace', type=float, default=1.0, help='scale the asked lengths (a second pass)')
    s.add_argument('--urgent', action='store_true', help='add the firm pacing direction URGENT (a third pass)')
    s.add_argument('--cap-usd', type=float, default=0.3, help="the ledger's billable total may not pass this")
    s.add_argument('--ledger', type=Path)
    s.add_argument('--dry-run', action='store_true', help='print the prompt, text and cost bound; send nothing')
    s = sub.add_parser('split')
    s.add_argument('--render', type=__import__('dub_store').dir_arg, required=True, help='a render: a path, or <set>/<run>_<tag> in the take store')
    s = sub.add_parser('place')
    for k in ('census', 'build', 'work', 'beds', 'cue', 'out'):
        s.add_argument(f'--{k}', type=Path, required=True)
    s.add_argument('--use', nargs='+', required=True, help='<run id>=<render dir> (split): the pieces to place')
    s.add_argument('--keep', nargs='*', help='run lines that keep their approved take (tr21.9)')
    s.add_argument('--tracks-only', action='store_true', help="mix only the runs' tracks (a quick look at one take)")
    s = sub.add_parser('voices')
    s.add_argument('--track', type=int, required=True)
    s.add_argument('--out', type=Path, required=True, help='.mp3 or .wav')
    s.add_argument('--cand', type=Path, help='a candidate directory (place); default mix 10')
    s = sub.add_parser('names')
    s.add_argument('--work', type=Path, required=True, help='dub_name.py target and audit work directory')
    s.add_argument('--renders', type=__import__('dub_store').dir_arg, nargs='+', required=True)
    s = sub.add_parser('candidate')
    s.add_argument('--cand', type=Path, required=True)
    s.add_argument('--cue', type=Path, required=True)
    s.add_argument('--build-out', type=Path, help='also build the EX ROM here (build_ex.py) with the candidate captions')
    for k in ('rom-dir', 'census', 'vasm', 'openings', 'portraits', 'desert-census'):
        s.add_argument(f'--{k}', type=Path)
    s = sub.add_parser('clips')
    for k in ('build', 'pack', 'runtime', 'hbmame', 'rom-dir', 'out'):
        s.add_argument(f'--{k}', type=Path, required=True)
    s.add_argument('--scenes', nargs='+', required=True)
    s.add_argument('--label', default='candidate')
    s = sub.add_parser('record')
    s.add_argument('--renders-root', type=__import__('dub_store').dir_arg, required=True)
    s.add_argument('--cands', type=Path, required=True, help='the directory holding take_<render> placements')
    s.add_argument('--final', type=Path, nargs='*', help='candidate directories to record whole')
    s.add_argument('--write', action='store_true')
    a = p.parse_args()
    if a.self_test:
        return self_test()
    if not a.cmd:
        p.error('a command or --self-test')
    return dict(runs=cmd_runs, render=cmd_render, split=cmd_split, place=cmd_place, voices=cmd_voices, names=cmd_names, candidate=cmd_candidate, clips=cmd_clips, record=cmd_record)[a.cmd](a)
if __name__ == '__main__':
    sys.exit(main())
