"""Focused regional checks for the Third Moon entrance, with old-ROM controls."""
import argparse
from concurrent.futures import ThreadPoolExecutor
from copy import deepcopy
import csv
import json
from pathlib import Path
import sys
from PIL import Image, ImageChops, ImageDraw
import desert_gate as G
import desert_smooth as S
import intro_gate as IG
import moon_start as M
import respawn_fix as R
from boss_voice_gate import inventory, sha
SETS = {'striderua': 'striderus01', 'striderjr': 'striderjs01'}

def rows(path):
    with path.open() as f:
        return list(csv.DictReader(f, delimiter='\t'))

def caption_spec(image):
    signature = bytes.fromhex('7000102d8cb2d040303b00064efb0002')
    if image[51200:57344].count(signature) != 1:
        raise ValueError('native caption dispatcher differs')
    tab = image.index(signature, 51200, 57344) + len(signature)
    at = tab + int.from_bytes(image[tab + 8:tab + 10], 'big')
    if image[at:at + 2] != b'!|' or image[at + 6:at + 8] != b'\x00\x1a':
        raise ValueError('Moon caption record load differs')
    rec = int.from_bytes(image[at + 2:at + 6], 'big')
    n = int.from_bytes(image[rec:rec + 2], 'big')
    slot = int.from_bytes(image[rec + 6:rec + 8], 'big')
    codes = {int.from_bytes(image[rec + 8 + i * 2:rec + 10 + i * 2], 'big') for i in range(n)}
    if not 0 < n < 64 or not 0 <= slot < 32:
        raise ValueError('Moon caption bounds differ')
    return f'{slot}:' + ','.join((f'{c:x}-{c:x}' for c in sorted(codes)))

def compare(old, new, opening):
    a, b = [G.read(p) for p in (old, new)]
    ma, mb = [S.read_motion(p) for p in (old, new)]
    if len(a) != len(b) or [r['sound'] for r in a] != [r['sound'] for r in b]:
        raise ValueError('frame count or sound clock changed')
    ia, ib = [rows(p / 'intro.tsv') for p in (old, new)]
    for x, y in zip(ia, ib):
        if any((x[k] != y[k] for k in x if k != 's2y')):
            raise ValueError('intro, title or READY clock changed')
    ignored = {'sleep', 'wake', 's3line', 'objline'}
    play = next((int(r['frame']) for r in b if r['mode'] == '4'))
    if opening:
        lo = play - 30
        hi = play + 30
        before = [r for r in ma if lo <= r['frame'] <= hi]
        after = [r for r in mb if lo <= r['frame'] <= hi]
        if len({r['camy'] for r in before}) < 3 or max((r['camy'] for r in before)) - min((r['camy'] for r in before)) != 30:
            raise ValueError('old-ROM entrance lurch not reproduced')
        if {r['camy'] for r in after} != {59} or len({(r['s2y'], r['s3y']) for r in after}) != 1:
            raise ValueError('camera or parallax still pans through the entrance')
        ca, cb = [G.read_caption(p) for p in (old, new)]
        if ca != cb or not any((r['n'] for r in cb)):
            raise ValueError('level-name sprites or fade changed')
        late = play + 16
    else:
        late = 0
    for x, y in zip(ma, mb):
        if opening and x['frame'] < late:
            keep = ('hx', 'hxf', 'hy', 'hyf', 'st', 'sub', 'kind', 'kind0', 'speed', 'face', 'gtask')
        else:
            keep = [k for k in x if k not in ignored]
        if any((x[k] != y[k] for k in keep)):
            raise ValueError('native movement or post-settle camera changed')
    raw_a, raw_b = [rows(p / 'motion.tsv') for p in (old, new)]
    if any((x['sprites'] != y['sprites'] for x, y in zip(raw_a, raw_b) if int(x['frame']) >= late)):
        raise ValueError('post-settle sprite list changed')
    pictures = 0
    for p in new.glob('s_*.png'):
        if int(p.stem[2:]) < late:
            continue
        q = old / p.name
        if not q.exists() or ImageChops.difference(Image.open(p).convert('RGB'), Image.open(q).convert('RGB')).getbbox():
            raise ValueError('post-settle or unaffected picture changed: ' + p.name)
        pictures += 1
    if pictures < 4:
        raise ValueError('too few actual emulator pictures compared')
    chunks = []
    for folder in (old, new):
        frames = [int(x) for x in (folder / 'ram.idx').read_text().splitlines()]
        data = (folder / 'ram.bin').read_bytes()
        chunks.append({f: data[i * 65536:(i + 1) * 65536] for i, f in enumerate(frames) if f >= late})
    if chunks[0].keys() != chunks[1].keys():
        raise ValueError('RAM schedules differ')
    for f in chunks[0]:
        x, y = [c[f] for c in chunks]
        if any((x[at:at + 8] != y[at:at + 8] for at in (4020, 4084))):
            raise ValueError('settled camera/parallax fractions changed')
    return dict(passed=True, frames=len(b), play_frame=play, sound_and_title_clocks_exact=True, original_movement_exact=True, post_settle_sprites_exact=True, pictures_exact=pictures, parallax_fraction_snapshots_exact=len(chunks[0]), old_pan_pixels=30 if opening else None, new_entrance_pan_pixels=0 if opening else None, traces={label: {n: sha((folder / n).read_bytes()) for n in ('frames.tsv', 'motion.tsv', 'intro.tsv')} for label, folder in (('control', old), ('candidate', new))})

def preview(old, new, out, inputs, runtime):
    out.mkdir(parents=True, exist_ok=False)
    play = next((int(r['frame']) for r in G.read(new) if r['mode'] == '4'))
    pictures = []
    source = []
    for f in range(play - 30, play + 51, 2):
        paths = [p / f's_{f:05d}.png' for p in (old, new)]
        if not all((p.exists() for p in paths)):
            continue
        picture = Image.new('RGB', (768, 244))
        draw = ImageDraw.Draw(picture)
        for i, (p, label) in enumerate(zip(paths, ('Before', 'After'))):
            picture.paste(Image.open(p).convert('RGB'), (384 * i, 20))
            draw.text((384 * i + 4, 4), label, fill='white')
        pictures.append(picture)
        source.append(dict(frame=f, before_sha256=sha(paths[0].read_bytes()), after_sha256=sha(paths[1].read_bytes())))
    durations = [10 * (round((i + 1) * 2 / 59.637 * 100) - round(i * 2 / 59.637 * 100)) for i in range(len(pictures))]
    durations[-1] = 1200
    pictures[0].save(out / 'moon-start.gif', save_all=True, append_images=pictures[1:], duration=durations, loop=0)
    poster = Image.new('RGB', (768, 732))
    for j, i in enumerate((0, len(pictures) // 2, len(pictures) - 1)):
        poster.paste(pictures[i], (0, 244 * j))
    poster.save(out / 'moon-start.png')
    report = dict(schema='striderex-moon-start-preview/1', unmodified_emulator_pictures=True, inputs=inputs, runtime_sha256=runtime['binary_sha256'], sources=source, images={p.name: sha(p.read_bytes()) for p in out.iterdir()})
    (out / 'preview.json').write_text(json.dumps(report, indent=2) + '\n')

def main():
    p = argparse.ArgumentParser(description=__doc__)
    for n in ('control', 'build', 'runtime', 'hbmame', 'rom-dir', 'workdir', 'receipt'):
        p.add_argument('--' + n, type=Path, required=True)
    p.add_argument('--reuse', action='store_true')
    p.add_argument('--preview-out', type=Path)
    a = p.parse_args()
    M.audit(a.control, a.build)
    work = a.workdir.resolve()
    work.mkdir(parents=True, exist_ok=a.reuse)
    rt = json.loads((a.runtime / 'runtime.json').read_text())
    binary = Path(rt['binary'])
    if sha(binary.read_bytes()) != rt['binary_sha256'] or not rt['board_wait']:
        raise ValueError('matching slower-board runtime required')
    builds = {'control': a.control.resolve(), 'candidate': a.build.resolve()}
    metas = {}
    prepared = {}
    pins = {}
    for label, build in builds.items():
        meta, files = inventory(build)
        metas[label] = meta
        for native in (False, True):
            source = build
            if native:
                source = work / 'variants' / label
                if not source.exists():
                    source.mkdir(parents=True)
                    vm = deepcopy(meta)
                    for m, f in files.items():
                        dest = source / m
                        dest.mkdir()
                        changed = dict(f)
                        bank = bytearray(f['strex_p6.bin'])
                        bank[-2] &= 254
                        changed['strex_p6.bin'] = bytes(bank)
                        for n, b in changed.items():
                            (dest / n).write_bytes(b)
                        vm['sets'][m]['files'] = {n: sha(b) for n, b in changed.items()}
                    (source / 'build.json').write_text(json.dumps(vm, indent=2) + '\n')
            vm, vf = inventory(source)
            for m in SETS:
                for n, data in files[m].items():
                    expected = bytearray(data)
                    if native and n == 'strex_p6.bin':
                        expected[-2] &= 254
                    if bytes(expected) != vf[m][n]:
                        raise ValueError('audio-path variant changed extra bytes')
                roms = G.stage_sets(source, SETS[m], a.hbmame, a.rom_dir.resolve(), work / 'sets' / f'{label}_{native}_{m}')
                have = {sha(q.read_bytes()) for q in (roms / SETS[m]).iterdir() if q.is_file()}
                if not set(vm['sets'][m]['files'].values()) <= have:
                    raise ValueError('staged ROM identity differs')
                prepared[label, native, m] = roms
                pins[f'{label}_{native}_{m}'] = vm['sets'][m]['files']
    plans = {}
    for m in SETS:
        im = R.compose(inventory(a.control)[1][m], R.SETS[m])
        cap_env = caption_spec(im)
        for case in ('opening_pack', 'opening_native', 'select', 'restart', 'ending', 'amazon'):
            n = 6500
            opening = case in ('opening_pack', 'opening_native', 'select')
            env = dict(G.debug_env(4, 0, n, inputs=False))
            if case == 'select':
                env, n = IG.select_env(a.build, m, 4, shots=False)
                env = dict(env)
                order = IG.SSG.play_order(True, bool(metas['candidate'].get('test_ending')))
                k = next((i for i, (stage, _) in enumerate(order) if stage == 4))
                env['INPUTS'] = IG.SSG.CODE + IG.SSG.presses(k, len(order)) + f';{IG.SSG.PICK}-{IG.SSG.PICK + 4}:START1'
            elif case == 'restart':
                n = 1800
                env = G.debug_env(4, 1, n, inputs=False)
            elif case == 'ending':
                n = 4000
                env = G.debug_env(4, 10, n, inputs=False)
                env.update(STREX_INPUTS='450-1400@6/3:P1_BUTTON1', STREX_INVINCIBLE_END='1420')
            elif case == 'amazon':
                n = 5000
                env = G.debug_env(2, 0, n, inputs=False)
            env.update(MOTION='128', INTRO='1', RAM='100', SHOTS=f'{n - 200}-{n}@40')
            if opening:
                env.update(FADE='160', CAPTION=cap_env)
            elif case == 'ending':
                env['SHOTS'] = '1400-4000@100'
            else:
                env['SHOTS'] = f'400-{n}@40'
            plans[m, case] = (env, n, opening)
    jobs = [(label, m, case) for label in builds for m, case in plans]

    def run(job):
        label, m, case = job
        env, n, _ = plans[m, case]
        out = work / f'{label}_{m}_{case}'
        if not a.reuse or not (out / 'motion.tsv').exists():
            G.run(binary, prepared[label, case == 'opening_native', m], SETS[m], out, env, n)
        print('Captured', label, m, case, flush=True)
        return out
    with ThreadPoolExecutor(2) as ex:
        outputs = dict(zip(jobs, ex.map(run, jobs)))
    checks = []
    for (m, case), (_, _, opening) in plans.items():
        result = compare(outputs['control', m, case], outputs['candidate', m, case], opening)
        checks.append(dict(machine=m, case=case, **result))
        print('PASS', m, case, flush=True)
    result = dict(schema='striderex-moon-start-gate/1', passed=True, scope='focused ROM qualification', inputs={label: {m: s['files'] for m, s in meta['sets'].items()} for label, meta in metas.items()}, runtime={k: rt[k] for k in ('binary_sha256', 'source_revision', 'board_wait')}, variant_files=pins, source_sha256={q.name: sha(q.read_bytes()) for q in (Path(__file__), Path(M.__file__), M.ASM, G.LUA)}, checks=checks, hardware_review_granted=False)
    a.receipt.parent.mkdir(parents=True, exist_ok=True)
    a.receipt.write_text(json.dumps(result, indent=2) + '\n')
    if a.preview_out:
        preview(outputs['control', 'striderua', 'opening_pack'], outputs['candidate', 'striderua', 'opening_pack'], a.preview_out, result['inputs'], rt)
    print('All 12 regional entrance/regression comparisons passed')
if __name__ == '__main__':
    main()
