"""Focused final-page pause checks against exact Kit v, both regions/voices."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
from pathlib import Path
import sys
import cinematic_followup as CF
import cinematic_reading as C
import cinematic_music_gate as M
import nopack_intros as N
from cinematic_census import compare_ym
from opening_transition_gate import sequence
ON = (1745, 1225, 1587, 1237, 905, 1085)
BASE_LUA = N.LUA
N.LUA = Path(__file__).resolve().parents[1] / 'lua/reading_pause.lua'

def meaningful(run, held_at=None, extra=0, fade_shift=0):
    return [(f - (fade_shift if v == 251 else extra if held_at and f > held_at else 0), ac, v) for f, ac, v in run['latch'] if v != 255]

def compare(b, old, stage, skip=False):
    checks = {}
    facts = {}
    extra = 120 if C.HOLD[stage] else 0
    rows = b['reading']
    held = [r for r in rows if 1 <= r[2] <= 120 and r[1] == C.HOLD[stage] and (r[5] == N.ON)]
    begin = held[0][0] if held else None
    if skip:
        checks['skip_during_hold'] = bool(held) and max((r[2] for r in held)) in (60, 61, 62)
        checks['skip_returns'] = b['meta'].get('play', 0) > b['meta'].get('handback', 0) > 0
        checks['native_stop'] = sum((v == 241 and ac == N.HOLD for f, ac, v in b['latch'])) == 1
        checks['no_late_fade'] = not any((v == 251 for f, ac, v in b['latch'] if f > b['meta']['handback']))
        checks['skip_prompt'] = bool(held) and b['meta']['handback'] - held[-1][0] < 5
        checks['gameplay_cue_same'] = [v for f, ac, v in b['latch'] if f > b['meta']['handback'] and v != 255] == [v for f, ac, v in old['latch'] if f > old['meta']['handback'] and v != 255]
        return (checks, dict(held_frames=len(held), handback=b['meta'].get('handback')))
    if extra:
        checks['exact_120_frame_pause'] = len(held) == 120 and [r[2] for r in held] == list(range(1, 121))
        checks['caption_stays_visible'] = bool(held) and all((r[3] > 0 for r in held)) and (len({r[3:5] for r in held}) == 1)
        pictures = [b['pictures'].get('reading-held-' + str(n)) for n in (3, 60, 120)]
        checks['picture_stays_unchanged'] = None not in pictures and len(set(pictures)) == 1
        checks['last_caption_unchanged'] = b['pictures'].get('reading-final-page') == old['pictures'].get('reading-final-page') is not None
        end = held[-1][0] if held else 0
        collapsed = [(f - (extra if f > end else 0), *row) for f, *row in b['frames'] if not begin or not begin <= f <= end]
        checks['all_original_records_preserved'] = collapsed == old['frames']
        checks['handback_delayed_120'] = b['meta']['handback'] - old['meta']['handback'] == 120
        checks['commands_shift_only_as_intended'] = meaningful(b, end, extra, 120) == meaningful(old)
        facts.update(pause_first_frame=begin, pause_last_frame=end, held_frames=len(held), added_seconds=round(extra / N.HZ, 3))
    else:
        d = N.identical(b, old)
        checks['unaffected_scene_flow'] = d['frames_same'] and d['latch_same'] and d['ym_same']
    fades = [(f, v) for f, ac, v in b['latch'] if v == 251]
    old_fades = [(f, v) for f, ac, v in old['latch'] if v == 251]
    checks['one_closing_fade'] = len(fades) == len(old_fades) == 1
    if fades and old_fades:
        fade = fades[0][0]
        checks['fade_delayed_with_picture'] = abs(fade - old_fades[0][0] - extra) <= 1
        silent = next((f for f, v, interval in b['attenuation'] if f >= fade and v == 127), None)
        ramp = (silent - fade) / N.HZ if silent else 0
        laugh = next((f for f, ac, v in b['latch'] if v == 155), None)
        checks['three_second_ramp'] = 2.8 <= ramp <= 3.6
        checks['silent_before_laugh'] = silent is not None and laugh is not None and (silent < laugh)
        checks['interval_six'] = [(f, v) for f, v in b['fade'] if abs(f - fade) <= 1] == [(fade, 6)] or [(f, v) for f, v in b['fade'] if abs(f - fade) <= 1] == [(fade - 1, 6)]
        facts.update(fade_delay_frames=fade - old_fades[0][0], ramp_seconds=round(ramp, 3), laugh_frame=laugh)
    checks['continuous_audible_score'] = bool(b['coverage']) and all((r['passed'] for r in b['coverage'].values()))
    checks['quiet_before_native_stop'] = any((r.get('fade_tail_dbfs', 0) < -90 for r in b['coverage'].values()))
    hb, old_hb = (b['meta']['handback'], old['meta']['handback'])
    checks['oki_after_handback_unchanged'] = [(f - hb, v) for f, v in b['oki'] if f >= hb] == [(f - old_hb, v) for f, v in old['oki'] if f >= old_hb]

    def keys(r, back):
        music = next((f for f, ac, v in r['latch'] if f > back and v < 48), None)
        return [(f / N.HZ, reg, v) for f, t, reg, v in r['ym'] if music is not None and music <= f < r['frames'][-1][0] and (not 16 <= reg <= 20)]
    checks['gameplay_music_unchanged'] = compare_ym([(t - extra / N.HZ, reg, v) for t, reg, v in keys(b, hb)], keys(old, old_hb))
    facts['gameplay_comparison'] = 'From gameplay cue through the penultimate captured frame; excludes the final potentially incomplete Z80 write batch.'
    if stage in (0, 4):
        checks['connected_score_continuity'] = b['sequence_passed']
    facts['coverage'] = b['coverage']
    return (checks, facts)

def gate(a):
    work = a.workdir.resolve()
    work.mkdir(parents=True, exist_ok=False)
    builds = {'build': a.build.resolve(), 'control': a.control.resolve()}
    meta = {k: json.loads((p / 'build.json').read_text()) for k, p in builds.items()}
    runtime = json.loads((a.runtime / 'runtime.json').read_text())
    if CF.sha(Path(runtime['binary']).read_bytes()) != runtime['binary_sha256']:
        raise ValueError('runtime changed')
    for m, spec in meta['build']['sets'].items():
        for n, digest in spec['files'].items():
            data = (builds['build'] / m / n).read_bytes()
            if CF.sha(data) != digest or CF.sha(CF.reverse_reading(data, m, n)) != meta['control']['sets'][m]['files'][n]:
                raise ValueError('build is not the exact guarded timing change')
    names = a.sets.split(',')
    stages = list(map(int, a.stages.split(',')))
    variants = a.variants.split(',')
    sets = {}
    jobs = []
    for label, path in builds.items():
        for sn in names:
            other = 1 if meta['build']['sets'][N.PARENT[sn]]['region_en'] else 2
            for variant, flag in (('nopack', 0), ('pack', 1), ('other_voice', 1 | other << 1)):
                if variant not in variants and (not (variant == 'nopack' and 'hold_skip' in variants)):
                    continue
                sets[label, sn, variant] = N.stage_set(a.hbmame, a.rom_dir.resolve(), path, sn, work / 'sets' / f'{label}_{sn}_{variant}', flag)
                for stage in stages:
                    if variant in variants:
                        jobs.append((label, sn, variant, stage))
                    if variant == 'nopack' and 'hold_skip' in variants and C.HOLD[stage]:
                        jobs.append((label, sn, 'hold_skip', stage))

    def one(job):
        label, sn, variant, stage = job
        machine = N.PARENT[sn]
        spec = meta[label]['sets'][machine]
        sid = C.SCENES[stage]
        low = spec['streams'][sid]
        high = min((p for p in spec['streams'].values() if p > low), default=2097152)
        skip = (low, high, C.HOLD[stage]) if variant == 'hold_skip' and label == 'control' else None
        transition = dict(READING_BASE_LUA=BASE_LUA, READ_LO=low, READ_HI=high, READ_PAUSE=C.HOLD[stage], READ_ON=ON[stage], READ_OFF=C.OFF[stage], READ_SKIP=60 if variant == 'hold_skip' and label == 'build' else 0)
        out = work / 'runs' / '_'.join(map(str, job))
        extra = ('-wavwrite', str(out / 'mix.wav')) if variant == 'nopack' else ()
        r = N.run(runtime['binary'], sets[label, sn, 'nopack' if variant == 'hold_skip' else variant], sn, out, stage, skip, extra=extra, transition=transition)
        r['reading'] = [tuple(map(int, line.split('\t'))) for line in (out / 'reading.tsv').read_text().splitlines()]
        r['pictures'] = {p.stem: CF.sha(p.read_bytes()) for p in out.glob('reading-*.png')}
        if extra:
            r['coverage'] = M.coverage(r, out / 'mix.wav', spec['streams'], {s['id']: s for s in meta[label]['scenes']})
            if stage in (0, 4):
                r['sequence_passed'] = sequence(r, (builds[label] / machine / CF.SOUND[machine]).read_bytes())[0]
        print('ran', out.name, flush=True)
        return (job, r)
    with ThreadPoolExecutor(a.jobs) as pool:
        runs = dict(pool.map(one, jobs))
    rows = []
    for sn in names:
        for stage in stages:
            for variant in variants:
                if variant == 'hold_skip' and (not C.HOLD[stage]):
                    continue
                b, old = [runs[label, sn, variant, stage] for label in ('build', 'control')]
                if variant in ('pack', 'other_voice'):
                    d = N.identical(b, old)
                    checks = dict(frame_and_voice_timing_identical=d['frames_same'], sound_commands_identical=d['latch_same'], ym_identical=d['ym_same'], fade_latch_identical=b['fade'] == old['fade'], oki_identical=b['oki'] == old['oki'])
                    facts = {}
                else:
                    checks, facts = compare(b, old, stage, variant == 'hold_skip')
                passed = all(checks.values())
                rows.append(dict(set=sn, stage=stage, variant=variant, checks=checks, facts=facts, exit_codes=[0, 0], passed=passed))
                print(sn, stage, variant, 'PASS' if passed else 'FAIL', json.dumps(checks), flush=True)
    report = dict(schema='striderex-reading-runtime/1', passed=all((r['passed'] for r in rows)), hold_frames=120, build_files={m: s['files'] for m, s in meta['build']['sets'].items()}, control_files={m: s['files'] for m, s in meta['control']['sets'].items()}, runtime={k: runtime[k] for k in ('binary_sha256', 'board_wait', 'source_revision')}, results=rows, negative_controls=[], hardware_review_granted=False)
    for sn in names:
        for stage in stages:
            if not C.HOLD[stage] or 'nopack' not in variants:
                continue
            old = runs['control', sn, 'nopack', stage]
            checks, _ = compare(old, old, stage)
            for key in ('exact_120_frame_pause', 'caption_stays_visible', 'fade_delayed_with_picture'):
                report['negative_controls'].append(dict(set=sn, stage=stage, criterion=key, rejected=not checks[key]))
    report['passed'] &= all((r['rejected'] for r in report['negative_controls']))
    (work / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
    print('PASS' if report['passed'] else 'FAIL', len(rows), 'focused reading checks')
    return 0 if report['passed'] else 1

def main():
    p = argparse.ArgumentParser(description=__doc__)
    for name in ('build', 'control', 'rom-dir', 'runtime', 'hbmame', 'workdir'):
        p.add_argument('--' + name, type=Path, required=True)
    p.add_argument('--sets', default='striderus01,striderjs01')
    p.add_argument('--stages', default='0,1,2,3,4,5')
    p.add_argument('--variants', default='nopack,pack,other_voice,hold_skip')
    p.add_argument('--jobs', type=int, default=3)
    return gate(p.parse_args())
if __name__ == '__main__':
    sys.exit(main())
