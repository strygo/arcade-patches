"""Build release ROMs from fresh measurements, without a private test kit."""
import argparse
from copy import deepcopy
import json
from pathlib import Path
import subprocess
import sys
import shutil
ROOT = Path(__file__).resolve().parents[3]
SCRIPTS = ROOT / 'backports/striderex/scripts'
sys.path.insert(0, str(SCRIPTS))
from boss_voice_gate import inventory, sha

def platforms(build, captures, roms, out):
    import desert_grip_fix as F
    meta, files = inventory(build)
    result = deepcopy(meta)
    masks = [F.source_mask(captures / f'platform{k}', True) for k in (1, 3)]
    stock = F.DX.program_images(roms)
    out.mkdir(parents=True, exist_ok=False)
    for machine, members in files.items():
        reports = []
        base = 1703936
        for index, source_index in ((0, 0), (1, 1), (3, 0), (4, 0), (5, 0), (6, 0)):
            mask, source = masks[source_index]
            members, spec = F.patch(members, machine, mask, stock[machine], map_index=index, allocation_base=base, merge=True)
            if base + spec['allocation_size'] > 1802240:
                raise ValueError('platforms overlap voice mouth data')
            base = base + spec['allocation_size'] + 15 & ~15
            reports.append(dict(map_index=index, source=source, **spec))
        dest = out / machine
        dest.mkdir()
        for name, data in members.items():
            (dest / name).write_bytes(data)
        result['sets'][machine]['files'] = {n: sha(b) for n, b in members.items()}
        result['sets'][machine]['desert_grip'] = dict(all_platforms=True, maps=reports, source='owned PC Engine disc, freshly replayed checkpoints 1 and 3')
    (out / 'build.json').write_text(json.dumps(result, indent=2) + '\n')

def build(a):
    a.out.mkdir(parents=True, exist_ok=False)

    def run(script, *args):
        print('Build:', script, flush=True)
        subprocess.run([sys.executable, str(SCRIPTS / script), *map(str, args)], check=True)
    current = a.out / '00-assets'
    c = a.captures
    run('build_ex.py', '--rom-dir', a.rom_dir, '--census', c / 'cinematics', '--vasm', a.vasm, '--openings', c / 'openings', '--portraits', c / 'portraits', '--desert-census', c / 'desert', '--pce-sfx', c / 'sfx', '--x68k-archive', a.x68k, '--cinematic-score', 'original', '--out', current)
    return finish(a, current)

def finish(a, current):
    """Apply the source-built follow-ups; also usable during one build's iteration."""
    c = a.captures

    def run(script, *args):
        print('Build:', script, flush=True)
        subprocess.run([sys.executable, str(SCRIPTS / script), *map(str, args)], check=True)
    meta, _ = inventory(current)
    if meta.get('test_ending') or any((s.get('test_ending') for s in meta['sets'].values())):
        raise ValueError('temporary ENDING entry in release')
    stages = [('boss_voice_install.py', ['--voices', a.voices, '--vasm', a.vasm]), ('platforms', []), ('boss_mouth.py', ['--voices', a.voices, '--vasm', a.vasm]), ('postgame_hold.py', ['--vasm', a.vasm]), ('arcade_text_spacing.py', []), ('commander_reading.py', []), ('desert_pole_edges.py', ['--rom-dir', a.rom_dir]), ('hiryu_pixels.py', ['--rom-dir', a.rom_dir]), ('desert_wall_edge.py', []), ('desert_cadence_fix.py', ['--vasm', a.vasm]), ('art_geometry.py', ['--scale', 'native']), ('stage_clear.py', ['--vasm', a.vasm]), ('desert_motion_fix.py', ['--vasm', a.vasm]), ('desert_transition_fix.py', ['--vasm', a.vasm]), ('desert_pole_floor.py', ['--rom-dir', a.rom_dir]), ('desert_climb_fix.py', ['--vasm', a.vasm]), ('moon_start.py', ['--vasm', a.vasm]), ('boss_music_entry.py', ['--vasm', a.vasm]), ('desert_map_edge.py', []), ('desert_pole_alias.py', []), ('desert_cliff_camera.py', ['--vasm', a.vasm]), ('clear_music_timing.py', ['--vasm', a.vasm]), ('moon_caption.py', ['--vasm', a.vasm]), ('moon_still.py', ['--openings', c / 'openings', '--rom-dir', a.rom_dir])]
    for i, (script, extra) in enumerate(stages, 1):
        dest = a.out / f'{i:02}-{Path(script).stem}'
        if script == 'platforms':
            platforms(current, c, a.rom_dir, dest)
        else:
            run(script, '--build', current, '--out', dest, *extra)
        current = dest
    for name in ('captions.json', 'stills.json', 'frames.json'):
        shutil.copyfile(a.out / '00-assets' / name, current / name)
    (a.out / 'result.json').write_text(json.dumps(dict(build=current.name, files={m: s['files'] for m, s in inventory(current)[0]['sets'].items()}), indent=2) + '\n')
    return current

def main():
    p = argparse.ArgumentParser(description=__doc__)
    for name in ('captures', 'rom-dir', 'vasm', 'voices', 'x68k', 'out'):
        p.add_argument('--' + name, type=Path, required=True)
    a = p.parse_args()
    for name, value in vars(a).items():
        setattr(a, name, value.resolve())
    print(build(a))
if __name__ == '__main__':
    main()
