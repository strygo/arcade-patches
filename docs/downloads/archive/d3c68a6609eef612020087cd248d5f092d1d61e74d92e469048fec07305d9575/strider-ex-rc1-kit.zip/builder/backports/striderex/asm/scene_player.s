; Strider EX cinematic scene player (standalone test boot).
;
; Plays a cinematic_convert.py stream, one record per vertical blank. The
; stream is LZSS-compressed (scripts/cinematic_lz.py). Each record starts
; with its length; the player decodes tokens into a ring in work RAM until
; the whole record is there, then parses it straight from the ring (a
; record that wraps has the ring's first bytes copied past its end first).
; Records are at most TAIL bytes (the converter guarantees it).
; This build boots on its own: scene_gate.py points the reset vector and the
; level-2 (VBlank) autovector of a stock Strider program at `start` and
; `vbl`. The compressed stream follows the code (incbin "scene.lz").
;
; Video setup (CPS-A at 0x800100, CPS-B at 0x800140, Strider's CPS_B_01):
;   OBJ 0x900000 and 0x900800 (two lists, flipped each VBlank), row
;   scroll 0x900E00 (block 0x900800, offset 0x300), SCROLL3 0x910000;
;   buffer pools (the stream writes any slot and flips the base registers,
;   op 9, so a scene cut is prepared ahead): SCROLL1 0x908000 0x904000
;   0x914000 0x918000 0x924000 0x928000 0x92C000, SCROLL2 0x90C000
;   0x91C000 0x920000, palette 0x901000 0x902800 (slot 0 first, as RES in
;   scripts/cinematic_convert.py);
;   video control 0x000F (row scroll on, all layers fetched);
;   layer control and the group-0 priority mask come from the stream
;   (op 6); SCROLL3 is always last and enabled.
;   SCROLL3 holds the side bars: code 0x3800 (opaque, pen 0 = palette 0x60
;   entry 0 = black) in tile columns 2-3 and 12-13, 0x3801 (transparent)
;   elsewhere.
; Ops: word, low byte = op number, high byte = buffer slot (ops 1, 5, 7).

OBJ     equ $900000                     ; sprite list A
OBJ_B   equ $900800                     ; sprite list B (191 entries + end mark, below the rows)
ROWS    equ $900E00                     ; row scroll: block 0x900800, offset 0x300 words
SCR3    equ $910000
CPSA    equ $800100
CPSB    equ $800140
LAYER   equ CPSB+$26
RING    equ $FF2000                     ; RSIZE bytes + room for a wrapped record
RSIZE   equ $2000
RMASK   equ RSIZE-1
TAIL    equ $1002                       ; longest record + its length word
FRAMES  equ $FF8000                     ; long: records played
LZ_SRC  equ $FF8004                     ; long: next compressed byte
LZ_W    equ $FF8008                     ; ring write index
LZ_R    equ $FF800A                     ; ring read index
ENDED   equ $FF8010                     ; nonzero once the end mark is read
PALBASE equ $FF8012                     ; current palette base register value
OBJ_BACK equ $FF8014                    ; long: the sprite list being built
SPR_NEW equ $FF8018                     ; word: the list changed since the last flip
LAYER_BASE equ $3188                    ; until the stream's first op 6

        org     $100000

start:  move.w  #$2700,sr
        lea     $FF8000,sp
        bsr     cine_setup
        clr.l   FRAMES
        move.l  #stream,LZ_SRC
        clr.l   LZ_W                    ; LZ_W, LZ_R
        clr.w   ENDED
        bsr     ready                   ; the first record, before the first VBlank (cine_step)
        move.w  #$2000,sr
.idle:  bra.s   .idle

vbl:    movem.l d0-d7/a0-a6,-(sp)
        bsr     cine_step
        movem.l (sp)+,d0-d7/a0-a6
        rte

        include "scene_core.s"

        even
stream: incbin  "scene.lz"
