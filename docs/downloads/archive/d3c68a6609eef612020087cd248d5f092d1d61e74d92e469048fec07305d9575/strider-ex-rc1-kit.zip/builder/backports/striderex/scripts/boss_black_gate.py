"""Focused boss-reveal black qualification on actual game captures and core video."""
import argparse
import hashlib
import json
from pathlib import Path
from types import SimpleNamespace
import numpy as np
from PIL import Image, ImageDraw
import boss_scene_binary as BB
import boss_scene_gate as B
import desert_gate as G
import earth_render_probe as E

def sha(b):
    return hashlib.sha256(b).hexdigest()

def gate(a):
    work = a.workdir.resolve()
    work.mkdir(parents=True, exist_ok=a.reuse)
    builds = {'control': a.control.resolve(), 'candidate': a.build.resolve()}
    metadata = {k: json.loads((v / 'build.json').read_text()) for k, v in builds.items()}
    inventories = {}
    pages = {}
    for label, path in builds.items():
        inventories[label] = {}
        for m, s in metadata[label]['sets'].items():
            files = {n: (path / m / n).read_bytes() for n in s['files']}
            if any((sha(b) != s['files'][n] for n, b in files.items())):
                raise ValueError('input changed')
            inventories[label][m] = files
    for m, files in inventories['control'].items():
        raw = bytes((files['strex_p6.bin'][i ^ 1] for i in range(1048576)))
        raw, changes = BB.black_strips(raw)
        pages[m] = len(changes)
        expected = dict(files, **{'strex_p6.bin': bytes((raw[i ^ 1] for i in range(len(raw))))})
        if expected != inventories['candidate'][m]:
            raise ValueError('candidate differs outside reveal black')
    rt = json.loads((a.runtime / 'runtime.json').read_text())
    binary = Path(rt['binary'])
    if sha(binary.read_bytes()) != rt['binary_sha256']:
        raise ValueError('runtime changed')
    sc = json.loads((Path(__file__).resolve().parents[1] / 'manifests/boss_scenes.json').read_text())['scenes'][0]['gate']
    results = []
    for name, machine, tag in [('striderus01', 'striderua', 'us'), ('striderjs01', 'striderjr', 'jp')]:
        runs = {}
        cores = {}
        for label, path in builds.items():
            run = work / 'black_game' / (label + '_' + name)
            core = work / ('black_core_refresh_' + label + '_' + tag)
            if not a.reuse:
                sets = G.stage_sets(path, name, a.hbmame, a.rom_dir.resolve(), work / 'black_game' / (label + '_' + name + '_sets'))
                B.run(binary, sets, name, run, sc, 1250, sc['inputs'], shots='690', video_frames='690')
                E.freeze(SimpleNamespace(build=path, rom_dir=a.rom_dir.resolve(), capture=run, frame=690, render_frame=50, refresh_objects=True, machine=machine, model=a.model, out=core))
            runs[label] = B.load(run, 1250)
            staged = work / 'black_game' / (label + '_' + name + '_sets') / name
            p6 = list(staged.glob('*.p6'))
            if len(p6) != 1 or p6[0].read_bytes() != inventories[label][machine]['strex_p6.bin']:
                raise ValueError('game capture was staged with a different EX bank')
            cores[label] = json.loads((core / 'render.json').read_text())
            if cores[label]['build_files'] != {m: s['files'] for m, s in metadata[label]['sets'].items()} or not cores[label]['graphics_ram_preserved'] or (not cores[label]['object_list_refreshed']) or (cores[label]['frame'] != 690) or (cores[label]['render_frame'] != 50):
                raise ValueError('core render has wrong inputs')
        before, after = [runs[k] for k in builds]
        if before['frames'] != after['frames'] or before['sync'] != after['sync']:
            raise ValueError('game frame flow changed')
        snd = lambda run: [r for r in run['regs'] if len(r) > 1 and r[1] == 'sound']
        if snd(before) != snd(after):
            raise ValueError('sound trace changed')
        old, new = [work / ('black_core_refresh_' + k + '_' + tag) for k in builds]
        imgs = [np.asarray(Image.open(p / 'render/f_00050.png').convert('RGB')) for p in (old, new)]
        changed = np.any(imgs[0] != imgs[1], axis=2)
        yy, xx = np.where(changed)
        if not len(yy) or yy.min() < 145 or (not np.all(imgs[0][changed] == 15)) or (not np.all(imgs[1][changed] == 0)):
            raise ValueError('pixels differ outside the false near-black masks')
        if any((sha((p / 'render/f_00050.png').read_bytes()) != cores[k]['image_sha256'] for p, k in zip((old, new), builds))):
            raise ValueError('core pixels changed after capture')
        vram = [(work / 'black_game' / (k + '_' + name) / 'vram_00690.bin').read_bytes() for k in builds]
        if any((sha(data) != cores[k]['vram_sha256'] for data, k in zip(vram, builds))):
            raise ValueError('render and game-capture graphics RAM identities differ')
        allowed = {base + 12 * 32 + 28 + i for base in (114688, 120832) for i in (0, 1)}
        diff = {i for i, (x, y) in enumerate(zip(*vram)) if x != y}
        if not diff or not diff <= allowed:
            raise ValueError('graphics RAM differs outside the two reveal colors')
        results.append(dict(machine=machine, changed_pixels=int(changed.sum()), core=cores, unchanged_frame_sync_and_sound_traces=True, only_two_palette_pens_differ=True, old_defect_rejected=True, passed=True))
        if a.review and tag == 'us':
            a.review.mkdir(parents=True, exist_ok=True)
            im = Image.new('RGB', (768, 248), (24, 24, 24))
            draw = ImageDraw.Draw(im)
            for i, img in enumerate(imgs):
                im.paste(Image.fromarray(img), (384 * i, 24))
            draw.text((8, 6), 'Before: visible near-black masks', fill='white')
            draw.text((392, 6), 'After: masks match the background', fill='white')
            im.resize((1152, 372)).save(a.review / 'before-after.png')
    receipt = dict(schema='striderex-boss-reveal-black/1', passed=True, pages_guarded=pages, input_files={k: {m: s['files'] for m, s in v['sets'].items()} for k, v in metadata.items()}, runtime={k: rt[k] for k in ('binary_sha256', 'source_revision', 'board_wait')}, results=results, hardware_review_granted=False)
    a.receipt.write_text(json.dumps(receipt, indent=2) + '\n')
    print('PASS: all 23 page palettes; both regions preserve game/sound and remove only false near-black masks')

def main():
    p = argparse.ArgumentParser(description=__doc__)
    for n in ('control', 'build', 'runtime', 'rom-dir', 'hbmame', 'model', 'workdir', 'receipt'):
        p.add_argument('--' + n, type=Path, required=True)
    p.add_argument('--review', type=Path)
    p.add_argument('--reuse', action='store_true')
    gate(p.parse_args())
if __name__ == '__main__':
    main()
