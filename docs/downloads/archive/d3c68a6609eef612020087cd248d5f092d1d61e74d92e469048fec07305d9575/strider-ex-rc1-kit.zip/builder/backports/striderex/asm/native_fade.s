; Native cinematic music: a roughly three-second stock FB fade (interval 6)
; in the final 210 frames, and a shorter opening title hold. Pack timing stays
; unchanged. The producer checks the shortened title's final buffer state.
; OKI speech/laugh samples are unaffected. A new song resets FM attenuation.
; START still stops immediately; natural continued scenes keep their song.
np_fade_tick:
        addq.w  #1,TICK                 ; the replaced instruction
        btst    #PACK,FLAGS+$F
        bne.s   .out
        tst.b   CONT_NEXT               ; prologue / flight: keep playing into the next scene
        beq.s   .fade
        cmp.b   #1,CINE_STAGE            ; the first stage's prologue, not the flight
        bne.s   .out
        cmp.l   #OPENING_CUT_RECORD,FRAMES
        bne.s   .out
        bsr.s   np_title_caption_end   ; its final label must not spill into the next scene
        move.w  #1,ENDED                ; natural continuation on the title's matching final cell state
        rts
.fade:  cmp.w   #$24,NP_CUE              ; the legacy-cue negative control retains its original stops
        bne.s   .out
        moveq   #0,d0
        move.b  CINE_STAGE,d0
        subq.w  #1,d0
        cmp.w   #5,d0
        bhi.s   .out
        add.w   d0,d0
        move.w  np_fade_frames(pc,d0.w),d0
        cmp.l   FRAMES,d0
        bne.s   .out
        move.w  #6,SOUND+8              ; stock fade interval latch: about three seconds
        move.w  #$FB,CUE                ; normal odd-frame command / FF protocol
.out:   rts
; Remove the title's caption prefix from both sprite lists, retaining the
; stream's own objects and full end entry. cap_start selects the next schedule.
; CAP_OFF=$FFF984, CAP_SN=$FFF986 (subtitles.s); no pending caption survives.
np_title_caption_end:
        move.w  $FFF984,d0
        beq.s   .out
        move.w  $FFF986,d2
        moveq   #1,d3
        lea     OBJ,a1
.list:  lea     0(a1,d0.w),a0
        move.w  d2,d1
.copy:  move.l  (a0)+,(a1)+
        move.l  (a0)+,(a1)+
        dbra    d1,.copy                ; CAP_SN stream sprites plus the end entry
        lea     OBJ_B,a1
        dbra    d3,.list
        clr.l   $FFF984                ; CAP_OFF / CAP_SN
.out:   clr.l   $FFF980                ; CAP_PTR
        rts
np_fade_frames:
        include "native_fade_frames.inc"
np_fade_end:
        dcb.b   $1FF100-*, $FF
np_cue_start:
        cmp.w   NP_CUE,d2
        beq.s   .out                    ; already running: no new cue at the connected scene's first frame
        move.w  d2,CUE_NEXT
        move.w  d2,NP_CUE
.out:   rts
np_native_end:
