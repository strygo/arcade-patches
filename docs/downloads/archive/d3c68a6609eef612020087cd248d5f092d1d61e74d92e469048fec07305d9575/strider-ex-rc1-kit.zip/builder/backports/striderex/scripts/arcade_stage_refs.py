"""Census of the arcade program's uses of the stage variable (P0.5)."""
import argparse
import json
import re
import subprocess
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
import audio_cue_map as ACM
DISP = 36018
ORDERED = ('bcs', 'bcc', 'bhi', 'bls', 'blt', 'bge', 'bgt', 'ble', 'bmi', 'bpl', 'scs', 'scc', 'shi', 'sls')

def disasm(path, start, count=64):
    """(address, text) rows. -basepc makes addresses and (d16,PC) operands absolute;"""
    out = subprocess.run(['unidasm', '-arch', 'm68000', str(path), '-basepc', hex(start), '-skip', hex(start), '-count', hex(count)], capture_output=True, text=True).stdout.splitlines()
    rows = []
    for line in out:
        a, rest = line.split(':', 1)
        m = re.match('\\s*((?:[0-9a-f]{4} ?)+)\\s+(.*)$', rest)
        rows.append((int(a, 16), m.group(2).strip() if m else rest.strip()))
    return rows

def find_refs(img_path, img):
    refs = []
    for m in re.finditer(DISP.to_bytes(2, 'big'), img):
        h = m.start()
        if h % 2:
            continue
        for back in (2, 4, 6):
            a = h - back
            rows = disasm(img_path, a, 16)
            if rows and '-$734e,A5' in rows[0][1]:
                refs.append((a, rows[0][1]))
                break
    return sorted(set(refs))

def classify(img_path, img, a, text):
    rows = disasm(img_path, a, 80)
    op = text.split()[0]
    d = dict(at=f'{a:#07x}', instruction=text)
    if re.match('move\\.b\\s+(#\\$[0-9a-f]+|D\\d), \\(-\\$734e,A5\\)', text):
        d['kind'] = 'write'
        m = re.match('move\\.b\\s+#\\$([0-9a-f]+)', text)
        if m:
            d['value'] = int(m.group(1), 16)
        return d
    if op.startswith(('cmpi', 'tst')):
        d['kind'] = 'compare'
        m = re.search('#\\$([0-9a-f]+)', text)
        d['against'] = int(m.group(1), 16) if m and op.startswith('cmpi') else 0
        for _, t in rows[1:4]:
            b = t.split()[0] if t else ''
            if b.startswith(('b', 's')) and b[:3] not in ('bra', 'bsr', 'btst'[:3]):
                d['branch'] = t
                d['ordered'] = b.split('.')[0] in ORDERED
                break
        return d
    d['kind'] = 'index'
    window = rows[1:12]
    d['following'] = [t for _, t in window[:8]]
    scale = 1
    for at, t in window:
        if re.match('add\\.[bw]\\s+D0, D0', t):
            scale *= 2
        m = re.search('\\((-?)\\$([0-9a-f]+),PC,D\\d\\.w\\)', t)
        if m:
            disp = int(m.group(2), 16) * (-1 if m.group(1) else 1)
            d['table'] = dict(kind='pc-relative', base=f'{at + 2 + disp:#07x}', via=t, scale=scale)
            break
        m = re.search('\\(\\$([0-9a-f]+),PC\\)', t)
        if m:
            d['table'] = dict(kind='pc-relative', base=f'{int(m.group(1), 16):#07x}', via=t, scale=scale)
            break
        m = re.search('(lea|movea\\.l)\\s+#?\\$([0-9a-f]+)(\\.[lw])?, (A\\d)', t)
        if m:
            d['table'] = dict(kind='absolute', base=f'{int(m.group(2), 16):#07x}', via=t, scale=scale)
            break
    if 'table' not in d:
        back = disasm(img_path, max(0, a - 32), 32)
        for at, t in reversed([r for r in back if r[0] < a][-6:]):
            m = re.search('(lea|movea\\.l)\\s+\\(\\$([0-9a-f]+),PC\\), (A\\d)', t)
            if m:
                d['table'] = dict(kind='pc-relative', base=f'{int(m.group(2), 16):#07x}', via=t, scale=None)
                break
            m = re.search('(lea|movea\\.l)\\s+#?\\$([0-9a-f]+)(\\.[lw])?, (A\\d)', t)
            if m:
                d['table'] = dict(kind='absolute', base=f'{int(m.group(2), 16):#07x}', via=t, scale=None)
                break
    if 'table' in d and d['table'].get('scale') in (1, 2, 4):
        base, sc = (int(d['table']['base'], 16), d['table']['scale'])
        if base + 6 * sc <= len(img):
            d['table']['entries'] = [f"{int.from_bytes(img[base + i * sc:base + (i + 1) * sc], 'big'):#x}" for i in range(6)]
    return d

def census(img_path):
    img = Path(img_path).read_bytes()
    refs = find_refs(img_path, img)
    rows = [classify(img_path, img, a, t) for a, t in refs]
    summary = dict(total=len(rows), writes=sorted({r.get('value') for r in rows if r['kind'] == 'write' and 'value' in r}), compares=len([r for r in rows if r['kind'] == 'compare']), ordered_compares=[r['at'] for r in rows if r.get('ordered')], index_reads=len([r for r in rows if r['kind'] == 'index']), index_with_table=len([r for r in rows if r['kind'] == 'index' and 'table' in r]))
    return dict(summary=summary, refs=rows)

def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('--rom-dir', type=Path, required=True)
    p.add_argument('--workdir', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    a = p.parse_args()
    a.workdir.mkdir(parents=True, exist_ok=True)
    result = {}
    for s in ('striderua', 'striderjr'):
        set_dir = ACM.unpack(a.rom_dir, s, a.workdir)
        parent = ACM.unpack(a.rom_dir, 'strider', a.workdir)
        img, files = ACM.program_image(s, set_dir, parent)
        path = a.workdir / f'{s}_program.bin'
        path.write_bytes(img)
        result[s] = dict(files=files, **census(path))
        print(s, json.dumps(result[s]['summary']))
    a.output.write_text(json.dumps(result, indent=1) + '\n')
    return 0
if __name__ == '__main__':
    sys.exit(main())
