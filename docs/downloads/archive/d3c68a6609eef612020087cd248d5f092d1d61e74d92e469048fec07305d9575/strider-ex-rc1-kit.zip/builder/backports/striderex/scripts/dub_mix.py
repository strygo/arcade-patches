"""Strider EX English dub (W6, D13): fit per-line English voice recordings to the"""
import argparse
import json
import math
import subprocess
import sys
from fractions import Fraction
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
import dub_beds as B
FIT = B.STREX / 'manifests/dub_fit.json'
VOICES = B.STREX / 'manifests/dub_voices.json'
RATE = B.RATE
PLACEHOLDER_VOICES = {'Narrator': ('Daniel', 150), 'Super Base': ('Samantha', 165), 'Grandmaster': ('Ralph', 135), 'Hiryu': ('Alex', 160), 'enemy_a': ('Fred', 165), 'enemy_b': ('Albert', 160), 'enemy_c': ('Reed (English (US))', 165)}

def load_json(p):
    return json.loads(Path(p).read_text())

def read_any_wav(path):
    """Mono float64 at 44.1 kHz from a 16/24/32-bit PCM or float WAV at any rate."""
    import numpy as np
    from scipy.io import wavfile
    from scipy.signal import resample_poly
    rate, x = wavfile.read(str(path))
    if x.dtype == np.int16:
        x = x / 32768.0
    elif x.dtype == np.int32:
        x = x / 2147483648.0
    elif x.dtype == np.uint8:
        x = (x - 128) / 128.0
    x = np.asarray(x, np.float64)
    if x.ndim == 2:
        x = x.mean(1)
    if rate != RATE:
        fr = Fraction(RATE, rate).limit_denominator(1000)
        x = resample_poly(x, fr.numerator, fr.denominator)
    return x

def trim(x, below_db=45.0, keep=0.015):
    """Drop leading and trailing silence (10 ms RMS more than below_db under the peak)."""
    import numpy as np
    h = int(0.01 * RATE)
    n = len(x) // h
    if n == 0:
        return (x, 0)
    rms = np.sqrt((x[:n * h].reshape(n, h) ** 2).mean(1) + 1e-20)
    on = np.nonzero(20 * np.log10(rms) > 20 * np.log10(rms.max()) - below_db)[0]
    a = max(0, on[0] * h - int(keep * RATE))
    b = min(len(x), (on[-1] + 1) * h + int(keep * RATE))
    return (x[a:b], a)

def trim_lead(x, below_db, keep=0.015):
    """Drop a take's leading quiet (a breath, room tone) that trim keeps: everything before the first"""
    import numpy as np
    h = int(0.01 * RATE)
    n = len(x) // h
    if n == 0:
        return (x, 0)
    rms = np.sqrt((x[:n * h].reshape(n, h) ** 2).mean(1) + 1e-20)
    db = 20 * np.log10(rms)
    on = int(np.nonzero(db > db.max() - below_db)[0][0])
    a = max(0, on * h - int(keep * RATE))
    return (x[a:], a)

def wsola(x, ratio, frame=0.03, tol=0.01):
    """Time-scale x to round(len(x) * ratio) samples with pitch kept (ratio < 1 = shorter)."""
    import numpy as np
    out_len = int(round(len(x) * ratio))
    if abs(ratio - 1) < 1e-06:
        return x.copy()
    N = int(frame * RATE) // 2 * 2
    Hs = N // 2
    Ha = Hs / ratio
    D = int(tol * RATE)
    w = np.hanning(N + 2)[1:-1]
    xp = np.pad(x, (N + D, N + D + int(Ha) + N))
    off = N + D
    frames = int(math.ceil(out_len / Hs)) + 1
    y = np.zeros(frames * Hs + N)
    wsum = np.zeros_like(y)
    prev = None
    for k in range(frames):
        nominal = int(round(k * Ha)) + off
        if prev is None:
            pos = nominal
        else:
            target = xp[prev + Hs:prev + Hs + N]
            lo, hi = (nominal - D, nominal + D)
            region = xp[lo:hi + N]
            if len(region) < N or not target.any():
                pos = nominal
            else:
                c = np.correlate(region, target, 'valid')
                pos = lo + int(np.argmax(c))
        seg = xp[pos:pos + N]
        if len(seg) < N:
            break
        y[k * Hs:k * Hs + N] += seg * w
        wsum[k * Hs:k * Hs + N] += w
        prev = pos
    y = np.divide(y, wsum, out=np.zeros_like(y), where=wsum > 1e-06)
    return y[:out_len]

def subtitle_index():
    data = load_json(B.SUBTITLES)
    return {l['id']: l for l in data['lines']}

def fit_plan():
    return load_json(FIT)

def slots_for(track, fit, subs):
    """Ordered (line id, slot dict) for a track: slot = plan override or the subtitle segment."""
    rows = []
    for lid, l in subs.items():
        if l['track'] != track:
            continue
        o = fit['lines'].get(lid, {})
        if o.get('voiced') is False:
            continue
        d = fit['defaults']
        rows.append((lid, dict(start=o.get('start', l['start']), end=o.get('end', l['end']), overrun=o.get('overrun', d['overrun']), max_compress=o.get('max_compress', d['max_compress']), align=o.get('align', d['align']), speaker=l['speaker'], lead_trim_db=o.get('lead_trim_db'), gain_db=o.get('gain_db', fit['speakers'].get(speaker_key(l['speaker']), {}).get('gain_db', 0.0)))))
    rows.sort(key=lambda r: r[1]['start'])
    return rows

def speaker_key(speaker):
    return speaker.replace(' (provisional)', '')

def place_line(x, slot, next_start, min_gap):
    """(placed samples, start s, ratio, notes) for one line in its slot."""
    x, _ = trim(x)
    notes = []
    if slot.get('lead_trim_db') is not None:
        x, a = trim_lead(x, slot['lead_trim_db'])
        if a:
            notes.append(f"leading quiet trimmed ({a / RATE:.3f} s more than {slot['lead_trim_db']:g} dB under the peak)")
    d = len(x) / RATE
    avail = slot['end'] - slot['start']
    limit_end = slot['end'] + slot['overrun']
    if next_start is not None:
        limit_end = min(limit_end, next_start - min_gap)
    ratio = 1.0
    if d > avail:
        ratio = max(avail / d, 1 - slot['max_compress'])
        if ratio < 1:
            x = wsola(x, ratio)
            notes.append(f'compressed to {ratio:.3f}')
        d = len(x) / RATE
    start = slot['start']
    if slot['align'] == 'center' and d < avail:
        start = slot['start'] + (avail - d) / 2
    elif slot['align'] == 'end' and d < avail:
        start = slot['end'] - d
    end = start + d
    return (x, start, end, ratio, limit_end, notes)

def ja_balance(line_id, refs):
    return refs.get(line_id, {}).get('ja_balance_db', 0.0)

def post_chain(x, spec):
    """Per-speaker processing after TTS: an optional band-pass (radio) and soft saturation."""
    import numpy as np
    if not spec:
        return x
    if spec.get('bandpass'):
        from scipy.signal import butter, sosfilt
        lo, hi = spec['bandpass']
        x = sosfilt(butter(spec.get('order', 4), [lo, hi], 'bandpass', fs=RATE, output='sos'), x)
    if spec.get('drive'):
        d = spec['drive']
        peak = np.abs(x).max() or 1.0
        x = np.tanh(d * x / peak) / np.tanh(d) * peak
    return x
HUSH_UNDER_DB = 22.0
HUSH_MIN_S = 0.1
HUSH_DB = 24.0
HUSH_HOLD_S = 0.04
HUSH_RAMP_S = 0.03

def hush(x, rate=None):
    """A placed take's pauses and breaths turned down (HUSH_DB), as a dialogue expander does. The TTS"""
    import numpy as np
    rate = rate or RATE
    h = max(1, int(0.01 * rate))
    n = len(x) // h
    if n < 4:
        return x
    fr = x[:n * h].reshape(n, h)
    level = 20 * np.log10(np.sqrt((fr ** 2).mean(1)) + 0.001 / 32768)
    live = np.abs(fr).max(1) > 2 / 32768
    if not live.any():
        return x
    quiet = level < np.percentile(level[live], 95) - HUSH_UNDER_DB
    hold, shortest = (int(round(HUSH_HOLD_S / 0.01)), int(round(HUSH_MIN_S / 0.01)))
    g = np.ones(len(x))
    low, r = (10 ** (-HUSH_DB / 20), max(1, int(HUSH_RAMP_S * rate)))
    i = 0
    while i < n:
        if not quiet[i]:
            i += 1
            continue
        j = i
        while j < n and quiet[j]:
            j += 1
        if j - i >= shortest:
            a = (i + (hold if i > 0 else 0)) * h
            b = (j - (hold if j < n else 0)) * h if j < n else len(x)
            if b > a:
                k = min(r, (b - a) // 2)
                g[a:b] = low
                g[a:a + k] = np.linspace(1, low, k)
                g[b - k:b] = np.linspace(low, 1, k)
        i = j
    return x * g

def restore_spans(track, fit):
    return [r for r in fit.get('restore_original', []) if r['track'] == track and r.get('restore', True)]

def peak_limit(bed_seg, voice, ceiling, window=0.005):
    """Gain envelope (n,) for a line's voice so that bed + voice never passes the ceiling, or None"""
    import numpy as np
    v = np.abs(voice)
    room = np.maximum(ceiling - np.abs(bed_seg), 0.0)
    over = v > room
    if not over.any():
        return None
    f = np.ones_like(v)
    f[over] = room[over] / v[over]
    f = f.min(axis=0)
    w = max(3, int(window * RATE) | 1)
    pad = np.pad(f, w // 2, mode='edge')
    mf = np.lib.stride_tricks.sliding_window_view(pad, w).min(axis=1)
    pad = np.pad(mf, w // 2, mode='edge')
    c = np.concatenate([[0.0], np.cumsum(pad)])
    env = (c[w:] - c[:-w]) / w
    cut = env < 1 - 1e-09
    return (env, float(-20 * np.log10(max(env.min(), 1e-09))), 1000 * cut.sum() / RATE)

def solve_gain(bed_seg, voice, target, ja_voice_lufs):
    """Voice gain (dB) so the English track over the line is as loud as the Japanese track over"""
    lo, hi = (-40.0, 30.0)

    def f(gdb):
        return B.loudness(bed_seg + voice * 10 ** (gdb / 20)) - target
    if f(lo) > 0:
        lv = B.loudness(voice)
        if ja_voice_lufs is None or lv is None:
            return (0.0, 'bed alone louder than the Japanese line; gain 0 dB')
        return (ja_voice_lufs - lv, 'bed alone louder than the Japanese line; voice set to the Japanese voice level')
    if f(hi) < 0:
        return (hi, 'cannot reach the Japanese line level')
    for _ in range(40):
        mid = (lo + hi) / 2
        if f(mid) > 0:
            hi = mid
        else:
            lo = mid
    return ((lo + hi) / 2, 'matched')

def mix_track(track, bed, voices, fit, subs, refs, p_checks, ja=None):
    """English track for one cinematic; returns (track audio, touched mask, rows, ok)."""
    import numpy as np
    slots = slots_for(track, fit, subs)
    out = bed.astype(np.float64).copy()
    touched = np.zeros(bed.shape[1], bool)
    rows, ok = ([], True)
    placed = []
    prev_end = 0.0
    if ja is not None:
        for r in restore_spans(track, fit):
            a, b = (int(r['start'] * RATE), min(bed.shape[1], int(r['end'] * RATE)))
            fade = np.ones(b - a)
            n = min(int(0.03 * RATE), (b - a) // 2)
            fade[:n] = np.linspace(0, 1, n)
            fade[b - a - n:] = np.linspace(1, 0, n)
            out[:, a:b] += (ja[:, a:b] - bed[:, a:b]) * fade
            touched[a:b] = True
            rows.append(dict(restored_original=[r['start'], r['end']], note=r.get('note', '')))
    for k, (lid, slot) in enumerate(slots):
        if lid not in voices:
            rows.append(dict(id=lid, missing=True))
            ok = False
            continue
        nxt = slots[k + 1][1]['start'] if k + 1 < len(slots) else None
        x, s, e, ratio, limit_end, notes = place_line(voices[lid], slot, nxt, fit['defaults']['min_gap'])
        if fit['defaults'].get('hush'):
            x = hush(x)
        ref = refs.get(lid, {})
        x = post_chain(x, fit['speakers'].get(speaker_key(slot['speaker']), {}).get('post'))
        bal = ja_balance(lid, refs)
        gl, gr = (10 ** (-max(bal, 0) / 20), 10 ** (min(bal, 0) / 20))
        a = int(round(s * RATE))
        b = min(bed.shape[1], a + len(x))
        vst = np.zeros((2, bed.shape[1]))
        vst[:, a:b] = np.stack([x[:b - a] * gl, x[:b - a] * gr])
        ja_s, ja_e = (ref.get('voice_start', slot['start']), ref.get('voice_end', slot['end']))
        lo = max(min(ja_s, s), prev_end)
        nxt_ja = None
        if k + 1 < len(slots):
            nid = slots[k + 1][0]
            nxt_ja = refs.get(nid, {}).get('voice_start', slots[k + 1][1]['start'])
        hi = max(ja_e, e) if nxt_ja is None else max(min(max(ja_e, e), nxt_ja), e)
        u0, u1 = (int(lo * RATE), min(bed.shape[1], int(hi * RATE)))
        if ja is not None:
            target = B.loudness(ja[:, u0:u1])
        else:
            target = ref.get('ja_mix_lufs')
        if target is None:
            target = fit['defaults']['fallback_lufs']
            notes.append('no Japanese reference level; fallback target')
        target += slot['gain_db']
        voice_target = None
        ja_voice = ref.get('ja_voice_lufs')
        if ja_voice is None and fit['lines'].get(lid, {}).get('level_as'):
            ja_voice = refs.get(fit['lines'][lid]['level_as'], {}).get('ja_voice_lufs')
        if fit['defaults'].get('level_match', 'voice') == 'voice' and ja_voice is not None:
            voice_target = ja_voice + slot['gain_db']
            gdb = voice_target - B.loudness(vst[:, a:b])
        else:
            gdb, how = solve_gain(out[:, u0:u1], vst[:, u0:u1], target, ref.get('ja_voice_lufs'))
            if how != 'matched':
                notes.append(how)
        ceiling = 10 ** (p_checks.get('limit_dbfs', -1.0) / 20)
        lim = None
        for _ in range(4):
            g = 10 ** (gdb / 20)
            lim = peak_limit(out[:, a:b], vst[:, a:b] * g, ceiling)
            if lim is None or voice_target is None:
                break
            short = voice_target - B.loudness(vst[:, a:b] * g * lim[0])
            if abs(short) < 0.05:
                break
            gdb += short
        if lim is not None:
            env, cut_db, ms = lim
            vst[:, a:b] *= env
            notes.append(f"voice peaks limited (at most {cut_db:.1f} dB, {ms:.0f} ms) to stay under {p_checks.get('limit_dbfs', -1.0)} dBFS")
        duck = fit['defaults'].get('duck', {})
        bal = ref if ref.get('ja_voice_lufs') is not None else refs.get(fit['lines'].get(lid, {}).get('level_as'), {})
        ja_v, ja_b = (bal.get('ja_voice_lufs'), bal.get('bed_lufs'))
        v_now, b_now = (B.loudness(vst[:, a:b] * g), B.loudness(out[:, a:b]))
        if duck and None not in (ja_v, ja_b, v_now, b_now):
            deficit = ja_v - ja_b - (v_now - b_now)
            if deficit > duck['threshold_db']:
                ddb = min(deficit, duck['max_db'])
                r0 = max(int(round(prev_end * RATE)), a - int(duck['ramp_in'] * RATE))
                r1 = b + int(duck['ramp_out'] * RATE)
                if k + 1 < len(slots):
                    r1 = min(r1, int(round(slots[k + 1][1]['start'] * RATE)))
                r1 = min(r1, bed.shape[1])
                gain = np.full(r1 - r0, 10 ** (-ddb / 20))
                up, down = (a - r0, r1 - b)
                if up > 0:
                    gain[:up] = 1 - (1 - gain[up]) * 0.5 * (1 - np.cos(np.pi * np.arange(up) / up))
                if down > 0:
                    gain[-down:] = 1 - (1 - gain[-down - 1]) * 0.5 * (1 + np.cos(np.pi * np.arange(down) / down))
                out[:, r0:r1] *= gain
                touched[r0:r1] = True
                notes.append(f'music ducked {ddb:.1f} dB under the line (it sat {deficit:.1f} dB lower against the music than the Japanese line)')
        bed_en = B.loudness(out[:, a:b])
        out[:, a:b] += vst[:, a:b] * g
        touched[a:b] = True
        line_l = B.loudness(out[:, u0:u1])
        voice_l = B.loudness(vst[:, a:b] * g)
        over_bed = None if None in (voice_l, bed_en, ref.get('ja_voice_lufs'), ref.get('bed_lufs')) else round(voice_l - bed_en - (ref['ja_voice_lufs'] - ref['bed_lufs']), 2)
        prev_end = e
        row = dict(id=lid, speaker=slot['speaker'], slot=[slot['start'], slot['end']], placed=[round(s, 3), round(e, 3)], limit_end=round(limit_end, 3), natural_s=round(len(voices[lid]) / RATE, 3), ratio=round(ratio, 4), compare_span=[round(lo, 2), round(hi, 2)], target_lufs=round(target, 2), line_lufs=line_l, voice_lufs=voice_l, ja_voice_lufs=ref.get('ja_voice_lufs'), voice_target_lufs=voice_target, voice_over_bed_vs_ja_db=over_bed, gain_db=round(gdb, 2), notes=notes)
        if voice_target is not None:
            level = voice_l is not None and abs(voice_l - voice_target) <= p_checks['line_lu']
        else:
            level = line_l is not None and abs(line_l - target) <= p_checks['line_lu']
        checks = dict(in_slot=s >= slot['start'] - 0.02 and e <= limit_end + 1e-06, stretch=ratio >= 1 - slot['max_compress'] - 1e-09, level=level)
        row['checks'] = checks
        ok &= all(checks.values())
        rows.append(row)
        placed.append((s, e, row))
    for i in range(len(placed) - 1):
        if placed[i][1] > placed[i + 1][0] - fit['defaults']['min_gap'] + 1e-06:
            placed[i][2]['checks']['no_overlap'] = False
            ok = False
    return (out, touched, rows, ok)

def mix(a):
    import numpy as np
    man = B.manifest()
    fit = fit_plan()
    subs = subtitle_index()
    refs = man.get('reference', {}).get('lines', {})
    pins = man.get('outputs', {}).get('beds', {})
    vinfo = load_json(a.voices / 'voices.json')
    placeholder = bool(vinfo.get('placeholder'))
    a.out.mkdir(parents=True, exist_ok=True)
    report = dict(placeholder=placeholder, voices=vinfo.get('source'), tracks={}, fit=dict(path=FIT.name, sha256=B.file_digest(FIT)))
    if placeholder:
        report['warning'] = 'PLACEHOLDER VOICES (local macOS say): test audio only, never shipped'
    checks_cfg = fit['checks']
    rc = 0
    for t in a.tracks:
        mt = man['inputs']['tracks'][str(t)]
        bed_path = a.beds / f'tr{t:02d}_bed.wav'
        want = pins.get(str(t), {}).get('sha256')
        if not bed_path.exists() or (want and B.file_digest(bed_path) != want):
            sys.exit(f'tr{t}: bed {bed_path} missing or not the pinned {want}; rebuild it with\n  <demucs env>/bin/python backports/striderex/scripts/dub_beds.py separate --model htdemucs_ft ...\n  <demucs env>/bin/python backports/striderex/scripts/dub_beds.py separate --model htdemucs_6s ...\n  venv/bin/python backports/striderex/scripts/dub_beds.py repair --workdir <dir> --cue <cue>\n(DUB.md, "Reproduce")')
        bed = B.read_wav16(bed_path)
        ja = B.disc_pcm(a.cue, t, mt['pcm_sha256'])
        name = f'tr{t:02d}_en' + ('_PLACEHOLDER' if placeholder else '') + '.wav'
        if not mt.get('dialogue', True):
            en, touched, rows, ok = (ja.astype(np.float64), np.zeros(ja.shape[1], bool), [], True)
        else:
            voices = {}
            for lid, l in subs.items():
                f = a.voices / f'{lid}.wav'
                if l['track'] == t and f.exists():
                    voices[lid] = read_any_wav(f)
            en, touched, rows, ok = mix_track(t, bed, voices, fit, subs, refs, checks_cfg, ja)
        peak = float(np.abs(en).max())
        L_en, L_ja = (B.loudness(en), B.loudness(ja))
        bedi = np.round(bed * 32768)
        eni = np.clip(np.round(en * 32768), -32768, 32767)
        untouched = ~touched
        spans = [tuple(r['compare_span']) for r in rows if 'compare_span' in r]
        D_en = B.loudness(en, spans) if spans else None
        D_ja = B.loudness(ja, spans) if spans else None
        tchecks = dict(no_clip=peak <= 10 ** (checks_cfg['peak_dbfs'] / 20), dialogue_loudness=D_en is None or abs(D_en - D_ja) <= checks_cfg['dialogue_lu'], track_loudness=L_en is not None and L_ja is not None and (abs(L_en - L_ja) <= checks_cfg['track_lu']), bed_untouched=bool((eni[:, untouched] == bedi[:, untouched]).all()) if mt.get('dialogue', True) else True)
        ok &= all(tchecks.values())
        B.write_wav16(a.out / name, en.astype(np.float32))
        report['tracks'][str(t)] = dict(file=name, sha256=B.file_digest(a.out / name), en_lufs=L_en, ja_lufs=L_ja, en_dialogue_lufs=D_en, ja_dialogue_lufs=D_ja, peak_dbfs=round(20 * math.log10(max(peak, 1e-09)), 2), checks=tchecks, lines=rows, ok=bool(ok))
        bad = [r['id'] for r in rows if 'id' in r and (r.get('missing') or not all(r.get('checks', {}).values()))]
        print(f"tr{t}: {('OK' if ok else 'FAIL')} EN {L_en} LUFS vs JA {L_ja} (dialogue {D_en} vs {D_ja}); peak {report['tracks'][str(t)]['peak_dbfs']} dBFS; {len(rows)} lines{('; failing ' + ', '.join(bad) if bad else '')}{('' if all(tchecks.values()) else ' ' + str(tchecks))}")
        rc |= 0 if ok else 1
    (a.out / 'mix_report.json').write_text(json.dumps(report, indent=1) + '\n')
    return rc

def placeholder(a):
    subs = subtitle_index()
    fit = fit_plan()
    a.out.mkdir(parents=True, exist_ok=True)
    rendered = {}
    for lid, l in sorted(subs.items()):
        if a.tracks and l['track'] not in a.tracks:
            continue
        o = fit['lines'].get(lid, {})
        text = o.get('tts_text', l['en']['text'] if l.get('en') else '')
        if not text or o.get('voiced') is False:
            continue
        key = fit['speakers'].get(speaker_key(l['speaker']), {}).get('placeholder', 'Narrator')
        voice, rate = PLACEHOLDER_VOICES[key]
        rate = int(round(rate * (o.get('tts_rate', 1.0) if a.at_plan_rate else 1.0)))
        f = a.out / f'{lid}.wav'
        subprocess.run(['say', '-v', voice, '-r', str(rate), '--file-format=WAVE', '--data-format=LEI16@22050', '-o', str(f), text], check=True)
        rendered[lid] = dict(voice=voice, rate_wpm=rate, text=text)
    (a.out / 'voices.json').write_text(json.dumps(dict(placeholder=True, source='local macOS say (PLACEHOLDER; never shipped)', lines=rendered), indent=1) + '\n')
    print(f'{len(rendered)} placeholder lines in {a.out}')
    return 0

def natural_lengths(voices_dir, ids):
    out = {}
    for lid in ids:
        f = Path(voices_dir) / f'{lid}.wav'
        if f.exists():
            x, _ = trim(read_any_wav(f))
            out[lid] = len(x) / RATE
    return out

def propose(track, subs, fit, nat):
    """Greedy timing proposal for one track. Each English line starts where its Japanese line"""
    sv = fit['solver']
    lines = [(lid, l) for lid, l in sorted(subs.items(), key=lambda kv: kv[1]['start']) if l['track'] == track and fit['lines'].get(lid, {}).get('voiced') is not False]
    rows, prev_end = ([], -1000000000.0)
    for k, (lid, l) in enumerate(lines):
        d = nat.get(lid)
        s0, e0 = (l['start'], l['end'])
        start = max(s0, prev_end + sv['gap'])
        if k + 1 < len(lines):
            limit = max(e0, lines[k + 1][1]['start'] - sv['gap'])
        else:
            limit = e0 + sv['tail_last']
        if d is None:
            rows.append(dict(id=lid, start=round(start, 2), missing=True))
            continue
        room = max(limit - start, 0.001)
        rate = min(max(d / room, 1.0), sv['rate_max'])
        rate = min(math.ceil(round(rate * 100, 6)) / 100, sv['rate_max'])
        end = start + d / rate
        rows.append(dict(id=lid, ja=[s0, e0], start=round(start, 2), end=round(end, 4), limit=round(limit, 2), natural=round(d, 2), tts_rate=rate, shift=round(start - s0, 2), overrun=round(end - e0, 2), late=round(max(0.0, end - limit), 2)))
        prev_end = end
    return rows

def plan(a):
    subs = subtitle_index()
    fit = fit_plan()
    man = B.manifest()
    refs = man.get('reference', {}).get('lines', {})
    nat = natural_lengths(a.voices, list(subs)) if a.voices else {}
    allrows = []
    for t in a.tracks:
        rows = propose(t, subs, fit, nat)
        for r in rows:
            if r.get('missing'):
                print(f"{r['id']:7} no voice file")
                continue
            ref = refs.get(r['id'], {})
            flag = []
            if r['tts_rate'] > 1.0:
                flag.append(f"rate {r['tts_rate']:.2f}")
            if r['overrun'] > 0.05:
                flag.append(f"runs {r['overrun']:.2f}s past the JA segment")
            if r['shift'] > fit['solver']['retime_after']:
                flag.append(f"RETIME +{r['shift']:.2f}s")
            if r['late'] > 0:
                flag.append(f"LATE {r['late']:.2f}s")
            print(f"{r['id']:7} JA {r['ja'][0]:6.2f}-{r['ja'][1]:6.2f} (voice {ref.get('voice_start')}-{ref.get('voice_end')})  EN {r['start']:6.2f}-{r['end']:6.2f} nat {r['natural']:4.2f}  {'; '.join(flag)}")
        allrows += rows
    if a.json:
        Path(a.json).write_text(json.dumps(allrows, indent=1) + '\n')
    if a.write:
        for r in allrows:
            if r.get('missing'):
                continue
            o = fit['lines'].setdefault(r['id'], {})
            o.update(start=r['start'], end=math.ceil(round(max(r['end'], r['ja'][1]) * 100, 6)) / 100, tts_rate=r['tts_rate'], proposed=dict(natural_placeholder_s=r['natural'], shift_s=r['shift'], overrun_s=r['overrun']))
            if r['shift'] <= fit['solver']['retime_after']:
                o.pop('retime', None)
            else:
                o['retime'] = True
        FIT.write_text(json.dumps(fit, ensure_ascii=False, indent=1) + '\n')
        print(f'wrote proposals to {FIT.relative_to(B.ROOT)}')
    return 0

def tts_text(text, lexicon, engine):
    """Text as sent to the engine: spoken forms for numbers and initials, and either IPA phonemes"""
    import html
    import re
    out = text
    for k, v in lexicon.get('spoken', {}).items():
        out = out.replace(k, v)
    names = lexicon.get('names', {})
    if engine == 'plain':
        for k, v in names.items():
            out = re.sub(f'\\b{re.escape(k)}\\b', v['respell'], out)
        return out
    esc = html.escape(out, quote=False)
    for k, v in names.items():
        if engine == 'ssml_phoneme':
            rep = f'''<phoneme alphabet="ipa" ph="{v['ipa']}">{k}</phoneme>'''
        else:
            rep = v['respell']
        esc = re.sub(f'\\b{re.escape(k)}\\b', rep, esc)
    esc = esc.replace('...', '...<break time="400ms"/>')
    return esc

def line_ssml(text, profile, rate, lexicon):
    engine = profile['engine']
    body = tts_text(text, lexicon, 'ssml_phoneme' if engine == 'neural2' else 'ssml_respell')
    rate_pct = int(round(profile.get('base_rate', 1.0) * rate * 100))
    attrs = f' rate="{rate_pct}%"'
    if engine == 'neural2' and profile.get('pitch_st'):
        attrs += f''' pitch="{profile['pitch_st']:+g}st"'''
    return f'<speak><prosody{attrs}>{body}</prosody></speak>'

def script(a):
    """Write the exact per-line TTS input (plain text and SSML) into manifests/dub_voices.json."""
    voices = load_json(VOICES)
    fit = fit_plan()
    subs = subtitle_index()
    lex = voices['lexicon']
    rows = {}
    for lid, l in sorted(subs.items(), key=lambda kv: (kv[1]['track'], kv[1]['start'])):
        o = fit['lines'].get(lid, {})
        sp = speaker_key(l['speaker'])
        prof = voices['speakers'][sp]
        text = l['en']['text'] if l.get('en') else ''
        if o.get('voiced') is False or not text:
            rows[lid] = dict(speaker=sp, voiced=False, note=o.get('note', ''))
            continue
        rate = o.get('tts_rate', 1.0)
        rows[lid] = dict(speaker=sp, text=text, plain=tts_text(text, lex, 'plain'), ssml=line_ssml(text, prof, rate, lex), rate=round(prof.get('base_rate', 1.0) * rate, 3), pitch_st=prof.get('pitch_st', 0) if prof['engine'] == 'neural2' else 0, direction=voices.get('directions', {}).get(lid, prof.get('direction', '')))
    voices['lines'] = rows
    chars = sum((len(r['plain']) for r in rows.values() if r.get('plain')))
    ssml_chars = sum((len(r['ssml']) for r in rows.values() if r.get('ssml')))
    voices['counts'] = dict(lines=sum((1 for r in rows.values() if r.get('plain'))), plain_characters=chars, ssml_characters=ssml_chars)
    VOICES.write_text(json.dumps(voices, ensure_ascii=False, indent=1) + '\n')
    print(f"{voices['counts']} -> {VOICES.relative_to(B.ROOT)}")
    return 0

def self_test():
    import numpy as np
    ok = True

    def check(name, cond, detail=''):
        nonlocal ok
        ok &= bool(cond)
        print(f"{('PASS' if cond else 'FAIL')} {name} {detail}")
    t = np.arange(int(1.5 * RATE)) / RATE
    f0 = 150
    x = sum((np.sin(2 * np.pi * f0 * h * t) / h for h in range(1, 12))) * (0.5 + 0.5 * np.sin(2 * np.pi * 3 * t) ** 2)
    x = np.concatenate([np.zeros(RATE // 5), x * 0.2, np.zeros(RATE // 4)])
    y, a0 = trim(x)
    check('trim', abs(len(y) / RATE - 1.53) < 0.03 and abs(a0 / RATE - 0.185) < 0.02, f'{len(y) / RATE:.3f} s from {a0 / RATE:.3f}')
    z = wsola(y, 0.85)
    check('wsola length', len(z) == int(round(len(y) * 0.85)), f'{len(z)} vs {int(round(len(y) * 0.85))}')
    S = np.abs(np.fft.rfft(z[RATE // 10:RATE // 10 + 8192] * np.hanning(8192)))
    fpk = np.argmax(S) * RATE / 8192
    check('wsola keeps pitch', abs(fpk - f0) < 6, f'{fpk:.1f} Hz')
    slot = dict(start=1.0, end=2.4, overrun=0.3, max_compress=0.12, align='start')
    _, s, e, r, lim, _ = place_line(y, slot, 2.9, 0.05)
    check('compressed to the slot', abs(e - 2.4) < 0.002 and abs(r - 1.4 / len(y) * RATE) < 0.001, f'ratio {r:.3f} end {e:.3f}')
    q = np.concatenate([0.2 * 10 ** (-36 / 20) * np.sin(2 * np.pi * 300 * np.arange(int(0.4 * RATE)) / RATE), y])
    yq, _ = trim(q)
    _, sq, _, _, _, _ = place_line(q, dict(slot, end=3.0), None, 0.05)
    lq, sl, el, _, _, nl = place_line(q, dict(slot, end=3.0, lead_trim_db=30.0), None, 0.05)
    check('trim keeps a quiet lead', len(yq) / RATE > len(y) / RATE + 0.35, f'{len(yq) / RATE:.3f} s')
    check('lead_trim_db drops it', abs(len(lq) - len(y)) < 0.012 * RATE and sl == sq == 1.0 and nl, f'{len(lq) / RATE:.3f} s vs {len(y) / RATE:.3f} s')
    word = np.sin(2 * np.pi * 200 * np.arange(int(0.3 * RATE)) / RATE) * 0.25
    breath = np.sin(np.arange(int(0.3 * RATE)) * 1.1) * 0.25 * 10 ** (-34 / 20)
    hz = hush(np.concatenate([word, breath, word]))
    mid = hz[len(word) + int(0.1 * RATE):len(word) + int(0.2 * RATE)]
    check('hush turns a breath down', np.abs(mid).max() <= np.abs(breath).max() * 10 ** (-HUSH_DB / 20) + 1e-12)
    check('hush keeps the words', np.array_equal(hz[:len(word)], word) and np.array_equal(hz[-len(word):], word))
    dip = np.concatenate([word, breath[:int(0.05 * RATE)], word])
    check("hush keeps a consonant's dip", np.array_equal(hush(dip), dip))
    slot2 = dict(slot, end=1.2, overrun=0.0)
    _, s, e, r, lim, _ = place_line(y, slot2, 1.3, 0.05)
    check('an over-long line is caught', e > lim, f'end {e:.3f} > {lim:.3f}')
    rng = np.random.default_rng(2)
    n = 8 * RATE
    bed = (0.02 * rng.standard_normal((2, n))).astype(np.float32)
    tt = np.arange(n) / RATE
    jv = (np.sin(2 * np.pi * 180 * tt) * ((tt > 3) & (tt < 5)) * 0.2).astype(np.float32)
    ja = bed + np.stack([jv, jv])
    subs = {'x.0': dict(id='x.0', track=99, start=3.0, end=5.0, speaker='Narrator', en=dict(text='x'))}
    fit = dict(lines={}, defaults=dict(align='start', max_compress=0.1, overrun=0.0, min_gap=0.05, fallback_lufs=-21), speakers={'Narrator': dict(gain_db=0.0)}, restore_original=[])
    refs = {'x.0': dict(voice_start=3.0, voice_end=5.0, ja_voice_lufs=None, ja_balance_db=0.0)}
    en, touched, rows, okk = mix_track(99, bed, {'x.0': y}, fit, subs, refs, dict(line_lu=0.5), ja)
    r0 = rows[0]
    check('track mix: line placed and level matched', okk and abs(r0['line_lufs'] - r0['target_lufs']) < 0.1, f"{r0['line_lufs']} vs {r0['target_lufs']}")
    bi, ei = (np.round(bed * 32768), np.round(en * 32768))
    check('track mix: bed untouched outside the line', (bi[:, ~touched] == ei[:, ~touched]).all())
    refs['x.0'].update(ja_voice_lufs=-24.0, bed_lufs=-34.0)
    _, _, rows, okk = mix_track(99, bed, {'x.0': y}, fit, subs, refs, dict(line_lu=0.5), ja)
    r0 = rows[0]
    check('track mix: voice matched to the Japanese voice', okk and abs(r0['voice_lufs'] + 24.0) < 0.1, f"{r0['voice_lufs']} vs -24.0")
    return 0 if ok else 1

def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('command', nargs='?', choices=['placeholder', 'mix', 'plan', 'script'])
    p.add_argument('--self-test', action='store_true')
    p.add_argument('--voices', type=Path, help='directory of <line id>.wav plus voices.json')
    p.add_argument('--beds', type=Path, help='dub_beds.py repair beds/ directory')
    p.add_argument('--cue', type=Path, help='restored PC Engine disc cue sheet')
    p.add_argument('--out', type=Path)
    p.add_argument('--tracks', type=int, nargs='+', default=list(range(21, 29)))
    p.add_argument('--json', type=Path, help='plan: also write the table here')
    p.add_argument('--write', action='store_true', help='plan: write the proposals into manifests/dub_fit.json')
    p.add_argument('--at-plan-rate', action='store_true', help='placeholder: render each line at its planned tts_rate (else at rate 1.0, for planning)')
    p.add_argument('--fit', type=Path, help='mix: a candidate fit in place of manifests/dub_fit.json (a mix 8 candidate from dub_lipsync.py plan; DUB.md section 10)')
    a = p.parse_args()
    if a.fit:
        if a.command != 'mix':
            p.error('--fit is for mix only (plan --write edits manifests/dub_fit.json itself)')
        global FIT
        FIT = a.fit.resolve()
    if a.self_test:
        return self_test()
    if a.command == 'placeholder':
        if not a.out:
            p.error('placeholder needs --out')
        return placeholder(a)
    if a.command == 'plan':
        return plan(a)
    if a.command == 'script':
        return script(a)
    if a.command == 'mix':
        if not (a.voices and a.beds and a.cue and a.out):
            p.error('mix needs --voices, --beds, --cue and --out')
        return mix(a)
    p.error('a command is needed')
if __name__ == '__main__':
    sys.exit(main())
