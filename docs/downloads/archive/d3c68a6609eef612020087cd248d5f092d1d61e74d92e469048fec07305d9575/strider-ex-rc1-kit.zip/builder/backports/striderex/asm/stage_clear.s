; Stage-clear presentation. These hooks run only in the original clear task.
; RAM is disposable between gameplay and cinematics; never read it unless ACTIVE.
        org $1F0000
        dc.w $4EF9
        dc.l cc_setup
        dc.w $4EF9
        dc.l cc_frame
        dc.w $4EF9
        dc.l cc_bonus
        dc.w $4EF9
        dc.l cc_moon
        dc.w $4EF9
        dc.l cc_exit
        dc.w $4EF9
        dc.l cc_roll
        dc.w $4EF9
        dc.l cc_label_queue

ACTIVE  equ $FFCF00
PHASE   equ $FFCF02
AGE     equ $FFCF04
LEVEL   equ $FFCF06
TAIL    equ $FFCF08
ORIGIN  equ $FFCF0A
OBJ     equ $FFD000
STARS   equ $FFD400
BONUS   equ $FFDC00

cc_setup:
        jsr AUX
        movem.l d0-d2/a0-a1,-(sp)
        move.w #1,ACTIVE
        clr.w PHASE
        clr.w AGE
        clr.w TAIL
        move.w #-1,LEVEL
        moveq #0,d0
        move.b $FF0CB2,d0
        move.w d0,ORIGIN
        lea $914000,a0
        lea OBJ,a1
        move.w #255,d0
.obj:   move.l (a0)+,(a1)+
        dbra d0,.obj
        lea $915000,a0
        move.w #511,d0
.stars: move.l (a0)+,(a1)+
        dbra d0,.stars
        movem.l (sp)+,d0-d2/a0-a1
        rts
cc_frame:
        jsr FILL
        bra cc_update
cc_moon:
        jsr SPRITES
        bra cc_update
cc_bonus:
        movem.l d0-d2/a0-a1,-(sp)
        move.w #1,PHASE
        clr.w AGE
        move.w #-1,LEVEL
        lea $914000,a1
        move.w #511,d2
        moveq #0,d1
        bsr cc_palette
        tst.b $FF10CA
        beq.s .aux
        move.w #$1662,$FF10DC
.aux:   lea $FF112A,a0
        moveq #4,d0
.hide:  clr.b 1(a0)
        lea $50(a0),a0
        dbra d0,.hide
        movem.l (sp)+,d0-d2/a0-a1
        move.w -$6F2E(a5),d0
        subi.w #$50,d0
        jmp BONUS_RETURN
cc_update:
        tst.w ACTIVE
        beq .return
        movem.l d0-d3/a0-a1,-(sp)
        tst.w PHASE
        bne.s .bonus
        move.w $914422,d1
        and.w #$F000,d1
        bra.s .level
.bonus:
        addq.w #1,AGE
        move.w AGE,d1
        subq.w #3,d1
        bpl.s .positive
        moveq #0,d1
.positive:
        cmp.w #15,d1
        bls.s .bounded
        moveq #15,d1
.bounded:
        cmp.w #25,AGE
        bcs.s .bright
        cmp.w #24,$FF0C1A
        bhi.s .bright
        tst.w TAIL
        bne.s .fade
        lea $914000,a0
        lea BONUS,a1
        move.w #511,d0
.save:  move.l (a0)+,(a1)+
        dbra d0,.save
        move.w #1,TAIL
        move.w #-1,LEVEL
.fade:  move.w $FF0C1A,d1
        subq.w #2,d1
        bpl.s .scale
        moveq #0,d1
.scale: mulu.w #15,d1
        divu.w #22,d1
.bright:
        lsl.w #8,d1
        lsl.w #4,d1
.level: cmp.w LEVEL,d1
        beq.s .done
        move.w d1,LEVEL
        lea OBJ,a0
        lea $914000,a1
        move.w #511,d2
        tst.w TAIL
        beq.s .objects
        lea BONUS,a0
        move.w #1023,d2
.objects:
        bsr cc_palette
        lea STARS,a0
        lea $915000,a1
        move.w #1023,d2
        tst.w PHASE
        beq.s .starfade
        moveq #0,d1
.starfade:
        bsr cc_palette
.done:  movem.l (sp)+,d0-d3/a0-a1
.return:rts
; d1=brightness, zero means exact black (CPS brightness zero is not black).
cc_palette:
        tst.w d1
        beq.s .black
.word:  move.w (a0)+,d0
        and.w #$FFF,d0
        or.w d1,d0
        move.w d0,(a1)+
        dbra d2,.word
        rts
.black: clr.w (a1)+
        dbra d2,.black
        rts
cc_exit:
        clr.w ACTIVE
        jmp SCROLL1
cc_roll:
        move.w #0,-$738C(a5)
        ; The bonus is already black. Hide the physical layers before restoring
        ; the palette inherited by stock credits, including their font colours.
        move.w #0,$800166
        movem.l d0/a0-a1,-(sp)
        tst.w TAIL
        beq.s .end
        lea BONUS,a0
        lea $914000,a1
        move.w #511,d0
.restore:
        move.l (a0)+,(a1)+
        dbra d0,.restore
.end:   clr.w ACTIVE
        movem.l (sp)+,d0/a0-a1
        rts
cc_label_queue:
        move.w #$23,d0
        cmpi.w #5,ORIGIN
        bne.s .queue
        move.w #$3D,d0
.queue: jmp $E10.w
