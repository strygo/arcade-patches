"""Check a single Moon-name fade, READY timing and unchanged entrance motion."""
import argparse
from concurrent.futures import ThreadPoolExecutor
from copy import deepcopy
import csv
import json
from pathlib import Path
import re
import subprocess
import sys
import tempfile
from PIL import Image, ImageChops, ImageDraw
import desert_gate as G
import intro_gate as IG
import moon_start_gate as MS
import moon_caption as M
import ready_ex as RX
import respawn_fix as R
from boss_voice_gate import inventory, sha
ROOT = Path(__file__).resolve().parents[3]
NATIVE_LUA = G.LUA
LUA = NATIVE_LUA.with_name('moon_caption_probe.lua')
SETS = {'striderua': 'striderus01', 'striderjr': 'striderjs01'}

def rows(path):
    with path.open() as f:
        return list(csv.DictReader(f, delimiter='\t'))

def select_inputs(meta, stage, delay=0):
    order = IG.SSG.play_order(True, bool(meta.get('test_ending')))
    k = next((i for i, (s, _) in enumerate(order) if s == stage))
    inp = IG.SSG.CODE + IG.SSG.presses(k, len(order)) + f';{IG.SSG.PICK}-{IG.SSG.PICK + 4}:START1'
    return re.sub('(?<!\\d)(\\d+)-(\\d+)', lambda m: f'{int(m[1]) + delay}-{int(m[2]) + delay}', inp)

def plans(meta):
    pick = select_inputs(meta, 4)
    out = {'select_pack': (6500, dict(INPUTS_ONLY='1', INPUTS=pick), True, True), 'select_native': (6500, dict(INPUTS_ONLY='1', INPUTS=pick), False, True), 'select_late': (8500, dict(INPUTS_ONLY='1', INPUTS=select_inputs(meta, 4, 3000)), True, True), 'select_skips': (5000, dict(INPUTS_ONLY='1', INPUTS=pick + ';650-5000@80/4:START1'), True, True), 'direct': (5000, G.debug_env(4, 0, 5000, inputs=False), True, True), 'progression': (6500, dict(G.debug_env(2, 1, 6500, inputs=False), CLEAR_AT='900'), True, True), 'restart': (1800, G.debug_env(4, 1, 1800, inputs=False), True, False), 'ending': (4000, dict(G.debug_env(4, 10, 4000, inputs=False), STREX_INPUTS='450-1400@6/3:P1_BUTTON1', STREX_INVINCIBLE_END='1420'), True, False), 'amazon': (5000, dict(INPUTS_ONLY='1', INPUTS=select_inputs(meta, 2)), True, False)}
    return out

def ready_watch(files, machine):
    im = R.compose(files, R.SETS[machine])
    raw = files['strex_p6.bin']
    bank = bytes((raw[i ^ 1] for i in range(len(raw))))
    cells = set()
    for bt, bs in RX.stage_tables(im, bank, machine).values():
        for text, _, _, _ in RX.table_records(im, bank, machine, bt, bs).values():
            cells.update((a for a, _ in RX.record_cells(im, text)))
    return ','.join((f'{a:x}' for a in sorted(cells))) + ';0ac0-0aff,1600-16ff,2000-21ff,be00-be3f'

def compare(old, new, opening):
    a, b = [G.read(p) for p in (old, new)]
    if a != b:
        raise ValueError('native register/frame/sound/player/scene clock changed')
    ia, ib = [rows(p / 'intro.tsv') for p in (old, new)]
    if ia != ib:
        raise ValueError('title, READY, wizard or intro clock changed')
    ma, mb = [rows(p / 'motion.tsv') for p in (old, new)]
    ignored = {'sleep', 'wake', 's3line', 'objline'}
    if len(ma) != len(mb) or any((any((x[k] != y[k] for k in x if k not in ignored)) for x, y in zip(ma, mb))):
        raise ValueError('player, settled camera or sprite lists changed')
    ca, cb = [rows(p / 'caption.tsv') for p in (old, new)]
    ra, rb = [rows(p / 'ready.tsv') for p in (old, new)]
    if any((any((x[k] != y[k] for k in x if k != 'pal')) for x, y in zip(ca, cb))):
        raise ValueError('caption objects, cells or their original fade clock changed')
    if any((any((x[k] != y[k] for k in x if k != 'kind2pal')) for x, y in zip(ra, rb))):
        raise ValueError('READY/GO objects, font cells, timing or palettes changed')
    changed = []
    for x, y in zip(ca, cb):
        if x['pal'] != y['pal']:
            if any((int(u, 16) & 4095 != int(v, 16) & 4095 for u, v in zip(x['pal'].split(','), y['pal'].split(',')))):
                raise ValueError('caption native colours changed')
            changed.append(int(y['frame']))
    result = dict(frames=len(b), game_flow_registers_sound_and_intro_exact=True, player_camera_fractions_and_sprite_lists_exact=True, ready_go_cells_palettes_and_clocks_exact=True, caption_object_and_fade_clock_exact=True, corrected_palette_frames=changed, passed=True)
    if opening:
        title = [r for r in cb if int(r['n']) > 0]
        if not title:
            raise ValueError('Moon name did not appear')
        levels = [max((int(w, 16) >> 12 for w in r['pal'].split(','))) for r in title]
        peak = levels.index(15)
        if levels[-1] != 0 or any((y < x for x, y in zip(levels[:peak + 1], levels[1:peak + 1]))) or any((y > x for x, y in zip(levels[peak:], levels[peak + 1:]))):
            raise ValueError('Moon title still brightens again during its fade')
        oldlevels = [max((int(w, 16) >> 12 for w in r['pal'].split(','))) for r in ca if int(r['n']) > 0]
        bumps = [i for i, (x, y) in enumerate(zip(oldlevels, oldlevels[1:])) if i > peak and y > x]
        if len(bumps) != 1 or len(changed) != 3:
            raise ValueError('old-ROM three-frame caption flash not reproduced')
        play = next((int(r['frame']) for r in b if r['stage'] == '4' and r['mode'] == '4'))
        if changed != list(range(play + 1, play + 4)):
            raise ValueError('palette correction changed another part of the entrance')
        for r in rb:
            if int(title[0]['frame']) <= int(r['frame']) < play and r['kind0']:
                raise ValueError('an old prompt object survives into the location name')
        writes = [rows(p / 'caption_writes.tsv') for p in (old, new)]
        if not all(writes):
            raise ValueError('palette write witness missing')
        restores = [r for r in writes[1] if int(r['frame']) == play + 1 and M.BASE <= int(r['pc'], 16) < M.BASE + 512]
        if len(restores) != 16 or {int(r['address'], 16) for r in restores} != set(range(9519808, 9519840, 2)):
            raise ValueError('native helper did not restore the complete live name palette')
        result.update(play_frame=play, name_first_frame=int(title[0]['frame']), name_last_frame=int(title[-1]['frame']), single_monotonic_caption_fade=True, old_rom_brightness_reset_reproduced=True, live_native_palette_restore_verified=True, no_prompt_object_before_play=True, old_reset_level=15, preserved_level=levels[changed[0] - int(title[0]['frame'])])
    elif changed:
        raise ValueError('caption palette changed on an unrelated path')
    pictures, corrected_pictures = (0, 0)
    for p in new.glob('s_*.png'):
        q = old / p.name
        if not q.exists():
            raise ValueError('screenshot schedule differs')
        diff = ImageChops.difference(Image.open(p).convert('RGB'), Image.open(q).convert('RGB'))
        box = diff.getbbox()
        f = int(p.stem[2:])
        if box:
            if not opening or f not in {x + 1 for x in changed}:
                raise ValueError('unrelated emulator pixels changed: ' + p.name)
            x = cb[f - 1]
            x0, y0, x1, y1 = map(int, x['box'].split(','))
            allowed = (x0 - 64, y0 - 16, x1 - 48, y1)
            if not (allowed[0] <= box[0] <= box[2] <= allowed[2] and allowed[1] <= box[1] <= box[3] <= allowed[3]):
                raise ValueError('changed pixels extend beyond the Moon name')
            corrected_pictures += 1
        else:
            pictures += 1
    if pictures < 20 or (opening and corrected_pictures != 3):
        raise ValueError('insufficient exact/changed emulator pictures')
    result.update(pictures_exact=pictures, corrected_caption_only_pictures=corrected_pictures, traces={label: {n: sha((p / n).read_bytes()) for n in ('frames.tsv', 'intro.tsv', 'motion.tsv', 'caption.tsv', 'ready.tsv', 'caption_writes.tsv')} for label, p in (('control', old), ('candidate', new))})
    return result

def preview(old, new, out, play):
    out.mkdir(parents=True, exist_ok=False)
    pics, source = ([], [])
    frames = range(play - 20, play + 32)
    for f in frames:
        paths = [p / f's_{f:05d}.png' for p in (old, new)]
        pic = Image.new('RGB', (768, 244))
        draw = ImageDraw.Draw(pic)
        for i, (p, label) in enumerate(zip(paths, ('Before', 'After'))):
            pic.paste(Image.open(p).convert('RGB'), (384 * i, 20))
            draw.text((384 * i + 4, 4), label, fill='white')
        pics.append(pic)
        source.append(dict(frame=f, sha256=[sha(p.read_bytes()) for p in paths]))
    durations = [10 * (round((i + 1) * 4 / 59.637 * 100) - round(i * 4 / 59.637 * 100)) for i in range(len(pics))]
    durations[-1] = 1000
    pics[0].save(out / 'moon-caption.gif', save_all=True, append_images=pics[1:], duration=durations, loop=0)
    pics[22].save(out / 'moon-caption.png')
    (out / 'preview.json').write_text(json.dumps(dict(actual_emulator_images=True, playback_speed=0.25, source_images=source, files={p.name: sha(p.read_bytes()) for p in out.iterdir()}), indent=2) + '\n')

def main():
    p = argparse.ArgumentParser(description=__doc__)
    for n in ('control', 'build', 'runtime', 'hbmame', 'rom-dir', 'vasm', 'workdir', 'receipt'):
        p.add_argument('--' + n, type=Path, required=True)
    p.add_argument('--reuse', action='store_true')
    p.add_argument('--preview-out', type=Path)
    a = p.parse_args()
    M.audit(a.control, a.build)
    work = a.workdir.resolve()
    work.mkdir(parents=True, exist_ok=a.reuse)
    rt = json.loads((a.runtime / 'runtime.json').read_text())
    binary = Path(rt['binary'])
    if sha(binary.read_bytes()) != rt['binary_sha256'] or not rt['board_wait']:
        raise ValueError('matching prepared conservative board-wait runtime required')
    G.LUA = LUA
    metas, sets, pins = ({}, {}, {})
    for label, build in (('control', a.control), ('candidate', a.build)):
        meta, files = inventory(build)
        metas[label] = meta
        for machine, setname in SETS.items():
            for pack in (False, True):
                variant = work / 'variants' / f'{label}_{machine}_{int(pack)}'
                f = dict(files[machine])
                raw = bytearray(f['strex_p6.bin'])
                raw[-2] = raw[-2] & 254 | int(pack)
                f['strex_p6.bin'] = bytes(raw)
                if not variant.exists():
                    d = variant / machine
                    d.mkdir(parents=True)
                    vm = deepcopy(meta)
                    vm['sets'] = {machine: dict(meta['sets'][machine], files={n: sha(b) for n, b in f.items()})}
                    for n, data in f.items():
                        (d / n).write_bytes(data)
                    (variant / 'build.json').write_text(json.dumps(vm, indent=2) + '\n')
                vm, vf = inventory(variant)
                if vf != {machine: f}:
                    raise ValueError('audio variant differs outside its declared pack bit')
                roms = G.stage_sets(variant, setname, a.hbmame, a.rom_dir.resolve(), work / 'sets' / f'{label}_{machine}_{int(pack)}')
                have = {sha(p.read_bytes()) for p in (roms / setname).iterdir() if p.is_file()}
                if not set(vm['sets'][machine]['files'].values()) <= have:
                    raise ValueError('staged ROM identity differs')
                pins[f'{label}_{machine}_{int(pack)}'] = vm['sets'][machine]['files']
                sets[label, machine, pack] = (roms, setname, MS.caption_spec(R.compose(f, R.SETS[machine])), ready_watch(f, machine))
    plan = plans(metas['candidate'])
    jobs = [(label, machine, case) for label in metas for machine in SETS for case in plan]

    def run(job):
        label, machine, case = job
        n, extra, pack, opening = plan[case]
        roms, setname, caption, ready = sets[label, machine, pack]
        out = work / f'run_{label}_{machine}_{case}'
        env = dict(extra, INTRO='1', MOTION='128', READY=ready, READY_SHOTS='1', CAPTION=caption, ISHOTS='450', SHOTS=f'400-{n}@40', MOON_NATIVE_GATE_LUA=str(NATIVE_LUA))
        binding = dict(frames=n, env={k: Path(v).name if k.endswith('LUA') or k == 'STREX_DEBUG_START' else v for k, v in env.items()}, files=pins[f'{label}_{machine}_{int(pack)}'], runtime=rt['binary_sha256'], observers={p.name: sha(p.read_bytes()) for p in (LUA, NATIVE_LUA, G.DEBUG_START)})
        if a.reuse and (out / 'run.json').exists():
            if json.loads((out / 'run.json').read_text()) != binding:
                raise ValueError('stale observer/input binding')
            if len(G.read(out)) != n:
                raise ValueError('incomplete reused run')
        else:
            G.run(binary, roms, setname, out, env, n)
            if '[LUA ERROR]' in (out / 'mame.log').read_text() or not rows(out / 'caption_writes.tsv'):
                raise ValueError('palette observer failed')
            (out / 'run.json').write_text(json.dumps(binding, indent=2) + '\n')
        print('captured', *job, flush=True)
        return out
    with ThreadPoolExecutor(2) as pool:
        outputs = dict(zip(jobs, pool.map(run, jobs)))
    checks = []
    for machine in SETS:
        for case, (_, _, pack, opening) in plan.items():
            result = compare(*(outputs[label, machine, case] for label in metas), opening)
            checks.append(dict(machine=machine, case=case, pack=pack, **result))
            print('PASS', machine, case, flush=True)
    play = next((c['play_frame'] for c in checks if c['machine'] == 'striderua' and c['case'] == 'direct'))
    trace = work / 'palette-caller.log'
    go = work / 'go.txt'
    go.write_text('go\n')
    _, oldfiles = inventory(a.control)
    caller = M.model(R.compose(oldfiles['striderua'], R.SETS['striderua']))
    if not (a.reuse and trace.exists()):
        env = dict(G.debug_env(4, 0, play + 8, inputs=False), TRACE=f'{trace}:{play - 1}-{play + 3}', MOON_NATIVE_GATE_LUA=str(NATIVE_LUA))
        G.run(binary, sets['control', 'striderua', True][0], SETS['striderua'], work / 'caller_trace', env, play + 8, ('-debug', '-debugger', 'none', '-debugscript', str(go)))
    instruction = next((line for line in trace.read_text().splitlines() if line.startswith(f"{caller['hook']:06X}:")), '')
    if instruction.split() != [f"{caller['hook']:06X}:", 'jsr', f"${caller['palette']:x}.l"]:
        raise ValueError('native Moon palette reload caller not witnessed')
    caller_trace = dict(instruction=instruction, trace_sha256=sha(trace.read_bytes()), frame_window=[play - 1, play + 3], debugger='none', input_roms_exact=True)
    fresh = work / 'fresh'
    if not fresh.exists():
        subprocess.run([sys.executable, str(Path(M.__file__)), '--build', str(a.control), '--vasm', str(a.vasm), '--out', str(fresh)], check=True)
    if inventory(fresh) != inventory(a.build):
        raise ValueError('fresh empty-output replay differs')
    bm, bf = inventory(a.build)
    damages = []
    for machine in SETS:
        hook = bm['sets'][machine]['moon_caption']['change']['address']
        for kind, address in (('hook', hook), ('stage_guard', M.BASE), ('caption_guard', M.BASE + 20), ('palette_restore', M.BASE + 70)):
            with tempfile.TemporaryDirectory(dir=work, prefix='damage-') as tmp:
                dest = Path(tmp)
                dm = deepcopy(bm)
                for m, files in bf.items():
                    f = dict(files)
                    if m == machine:
                        if address < 1048576:
                            image = bytearray(R.compose(f, R.SETS[m]))
                            image[address] ^= 1
                            f.update(R.decompose(image, R.SETS[m], {n: len(f[n]) for n, _, _ in R.SETS[m]}))
                        else:
                            raw = bytearray(f['strex_p6.bin'])
                            raw[address - 1048576 ^ 1] ^= 1
                            f['strex_p6.bin'] = bytes(raw)
                    d = dest / m
                    d.mkdir()
                    for n, data in f.items():
                        (d / n).write_bytes(data)
                    dm['sets'][m]['files'] = {n: sha(b) for n, b in f.items()}
                (dest / 'build.json').write_text(json.dumps(dm) + '\n')
                try:
                    M.audit(a.control, dest)
                except ValueError:
                    damages.append(dict(machine=machine, kind=kind, inventory_rehashed=True, rejected=True))
                else:
                    raise ValueError('rehashed Moon caption damage accepted')
    sources = (Path(__file__), Path(M.__file__), M.ASM, LUA, NATIVE_LUA, G.DEBUG_START, Path(G.__file__), Path(IG.__file__), Path(RX.__file__), Path(MS.__file__), Path(R.__file__))
    receipt = dict(schema='striderex-moon-caption-gate/1', passed=True, checks=checks, inputs={label: {m: s['files'] for m, s in meta['sets'].items()} for label, meta in metas.items()}, runtime={k: rt[k] for k in ('binary_sha256', 'source_revision', 'board_wait')}, audio_variant_files=pins, fresh_empty_output_roms_and_metadata_exact=True, rehashed_damage_controls=damages, assembler_sha256=sha(a.vasm.read_bytes()), source_sha256={str(q.relative_to(ROOT)): sha(q.read_bytes()) for q in sources}, native_palette_caller=caller_trace, hardware_review_granted=False)
    a.receipt.parent.mkdir(parents=True, exist_ok=True)
    a.receipt.write_text(json.dumps(receipt, indent=2) + '\n')
    if a.preview_out:
        play = next((c['play_frame'] for c in checks if c['machine'] == 'striderua' and c['case'] == 'select_pack'))
        preview(outputs['control', 'striderua', 'select_pack'], outputs['candidate', 'striderua', 'select_pack'], a.preview_out, play)
    print('All 18 paired regional Moon/READY/regression checks PASS', flush=True)
if __name__ == '__main__':
    main()
