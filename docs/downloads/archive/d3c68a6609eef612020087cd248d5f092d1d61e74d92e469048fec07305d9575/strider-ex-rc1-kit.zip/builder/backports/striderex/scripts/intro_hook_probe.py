"""Phase 2 integration probe: what a cinematic may overwrite at the intro hook."""
import argparse
import json
import os
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
ROOT = Path(__file__).resolve().parents[3]
LUA = ROOT / 'backports/striderex/lua/intro_hook_probe.lua'
DEBUG_START = ROOT / 'backports/striderex/lua/arcade_debug_start.lua'
HOOK_PCS = {'striderua': 37146, 'striderjr': 37008}
REGIONS = {'obj': '900000-9007fe,904000-907ffe', 'scroll1': '908000-90bffe', 'scroll2': '90c000-90fffe', 'scroll3': '910000-913ffe', 'palette': '914000-917ffe', 'palette_obj': '914000-9143fe', 'palette_scroll1': '914400-9147fe', 'palette_scroll2': '914800-914bfe', 'palette_scroll3': '914c00-914ffe', 'palette_stars': '915000-9157fe', 'palette_rest': '915800-917ffe', 'unused_gfx': '900800-903ffe,918000-92fffe', 'work_top': 'ffc800-fffffe', 'work_mid': 'ffa400-ffbbfe', 'player_footprint': '900000-913ffe,915800-92fffe,ffa400-ffbbfe,ffc800-fffffe'}

def run(mame, roms, machine, stage, outdir, frames, poison):
    HOOK_PC = HOOK_PCS[machine]
    outdir.mkdir(parents=True)
    env = dict(os.environ, SDL_VIDEODRIVER='dummy', SDL_AUDIODRIVER='dummy', STREX_DEBUG_START=str(DEBUG_START), STREX_STAGE=str(stage), STREX_AREA='0', STREX_END=str(frames), STREX_INPUTS=f'450-{frames}:P1_JOYSTICK_RIGHT', STREX_PREFIX=str(outdir / 'run'), STREX_POISON=poison, INTRO_LOG=str(outdir / 'intro.txt'), VIDEO_LOG=str(outdir / 'video.tsv'), SHOTDIR=str(outdir), STREX_HOOK_PC=f'{HOOK_PC:x}')
    cmd = [mame, machine, '-rompath', str(roms), '-nothrottle', '-video', 'none', '-sound', 'none', '-skip_gameinfo', '-noautosave', '-cfg_directory', str(outdir / 'cfg'), '-nvram_directory', str(outdir / 'nv'), '-snapshot_directory', str(outdir), '-autoboot_script', str(LUA)]
    p = subprocess.run(cmd, env=env, cwd=outdir, capture_output=True, text=True, timeout=900)
    (outdir / 'mame.log').write_text(p.stdout + p.stderr)
    if p.returncode:
        raise RuntimeError(f'{outdir}: MAME exit {p.returncode}')
    hooks = [int(l.split()[0]) for l in (outdir / 'intro.txt').read_text().splitlines() if l.split()[1] == f'{HOOK_PC:06x}' and l.split()[2] != '00']
    return dict(hooks=hooks, video=(outdir / 'video.tsv').read_text().splitlines(), shots={q.name: q.read_bytes() for q in sorted(outdir.glob('s_*.png'))})

def compare(stock, test):
    from PIL import Image
    import io
    if not stock['hooks']:
        return dict(ok=False, why='no intro hook in the stock run')
    if test['hooks'][:1] != stock['hooks'][:1]:
        return dict(ok=False, why=f"hook frame {test['hooks'][:1]} vs {stock['hooks'][:1]}")
    h = stock['hooks'][0]
    vbad = [i + 1 for i, (a, b) in enumerate(zip(stock['video'], test['video'])) if i + 1 >= h and a != b]
    sbad = []
    for name, data in stock['shots'].items():
        other = test['shots'].get(name)
        if other is None or Image.open(io.BytesIO(data)).tobytes() != Image.open(io.BytesIO(other)).tobytes():
            sbad.append(int(name[2:7]))
    return dict(ok=not vbad and (not sbad), hook=h, video_first_diff=vbad[:1], video_diffs=len(vbad), shot_first_diff=sorted(sbad)[:1], shot_diffs=len(sbad), shots=len(stock['shots']))

def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('--rom-dir', type=Path, required=True)
    p.add_argument('--workdir', type=Path, required=True)
    p.add_argument('--mame', default='mame')
    p.add_argument('--machine', default='striderua')
    p.add_argument('--frames', type=int, default=2400)
    p.add_argument('--stages', default='0,1,2,3,4')
    a = p.parse_args()
    work = a.workdir.resolve()
    work.mkdir(parents=True, exist_ok=False)
    stages = [int(s) for s in a.stages.split(',')]
    jobs = [(s, v) for s in stages for v in ['stock'] + list(REGIONS)]
    with ThreadPoolExecutor(8) as ex:
        res = dict(zip(jobs, ex.map(lambda j: run(a.mame, a.rom_dir.resolve(), a.machine, j[0], work / f's{j[0]}_{j[1]}', a.frames, '' if j[1] == 'stock' else REGIONS[j[1]]), jobs)))
    report = dict(machine=a.machine, regions=REGIONS, results={})
    for v in REGIONS:
        row = {s: compare(res[s, 'stock'], res[s, v]) for s in stages}
        report['results'][v] = dict(free_at_hook=all((r['ok'] for r in row.values())), stages=row)
        print(f'{v:<11}', 'FREE' if report['results'][v]['free_at_hook'] else 'NEEDED', ' '.join((f"s{s}:{('ok' if r['ok'] else r.get('why') or 'diff@' + str((r['video_first_diff'] or r['shot_first_diff'])[0]))}" for s, r in row.items())))
    (work / 'report.json').write_text(json.dumps(report, indent=1) + '\n')
    return 0
if __name__ == '__main__':
    sys.exit(main())
