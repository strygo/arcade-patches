"""Exercise flat handholds and standing/walking on the desert's metal platforms."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import csv
import json
from pathlib import Path
import desert_gate as G
import boss_followup_release as BF
import desert_grip_fix as F
import desert_slopes as DS
import desert_smooth as SM

def cases():
    out = {}
    for i, (stop, jump) in enumerate(((940, 960), (1170, 1190), (1350, 1370), (1490, 1510))):
        end = jump + 300
        out['catch' + str(i)] = (1, end, dict(STREX_INPUTS=f'450-{stop}:P1_JOYSTICK_RIGHT;{jump}-{end}:P1_JOYSTICK_UP;{jump}-{jump + 14}:P1_BUTTON2', SHOTS=f'{jump}-{end}@30'), True)
    for name, x, y, stop in (('flat0', 888, 1232, 940), ('flat1', 1296, 1232, 1170), ('flat2', 1680, 1232, 1350), ('flat3', 1944, 1232, 1470), ('rise', 2040, 1249, 1550)):
        warp = stop + 50
        walk = warp + 250
        end = walk + 300
        out[name] = (1, end, dict(WARP=f'{warp - 20}:{x},{y - 26};{warp - 10}:{x},{y + 27};{warp}:{x},{y + 80}', STREX_INPUTS=f'450-{stop}:P1_JOYSTICK_RIGHT;{walk}-{walk + 250}:P1_JOYSTICK_RIGHT', SHOTS=f'{warp}-{end}@50'), False)
    return out

def gate(a):
    if a.cadence_control:
        import desert_cadence_fix as C
        C.audit(a.cadence_control, a.build)
    work = a.workdir.resolve()
    work.mkdir(parents=True, exist_ok=a.reuse)
    rt = json.loads((a.runtime / 'runtime.json').read_text())
    binary = Path(rt['binary'])
    if BF.sha(binary.read_bytes()) != rt['binary_sha256']:
        raise ValueError('runtime identity changed')
    prepared = {}
    metas = {}
    machines = ('striderua', 'striderjr') if a.regions == 'both' else ('striderua',)
    for label, path in (('control', a.control), ('candidate', a.build)):
        meta = json.loads((path / 'build.json').read_text())
        metas[label] = meta
        for machine, spec in meta['sets'].items():
            if any((BF.sha((path / machine / n).read_bytes()) != digest for n, digest in spec['files'].items())):
                raise ValueError('input ROM changed')
        for m in machines:
            name = 'striderus01' if m == 'striderua' else 'striderjs01'
            prepared[label, m] = (G.stage_sets(path.resolve(), name, a.hbmame, a.rom_dir.resolve(), work / 'sets' / (label + '_' + m)), name)
            staged = prepared[label, m][0] / name
            carried = {BF.sha(p.read_bytes()) for p in staged.iterdir() if p.is_file()}
            if not set(meta['sets'][m]['files'].values()) <= carried:
                raise ValueError('staged set does not carry every exact input member')
    plans = cases()
    selected = a.cases.split(',') if a.cases else list(plans)

    def run(job):
        label, m, case = job
        area, n, extra, natural = plans[case]
        roms, name = prepared[label, m]
        out = work / (label + '_' + m + '_' + case)
        if not a.reuse or not (out / 'motion.tsv').exists():
            env = dict(G.debug_env(5, area, n, inputs=False), MOTION='1', **extra)
            G.run(binary, roms, name, out, env, n)
        rows = list(csv.DictReader((out / 'motion.tsv').open(), delimiter='\t'))
        for r in rows:
            for k in ('frame', 'hx', 'hy', 'st', 'sub', 'kind', 'camx', 'camy'):
                r[k] = int(r[k])
        observed = rows[650:]
        fixed = []
        if not natural:
            warp, position = extra['WARP'].split(';')[-1].split(':')
            wx, wy = map(int, position.split(','))
            warp = int(warp)
            fixed = [r for r in rows if warp + 40 <= r['frame'] < warp + 250]
            fixed = [r for r in fixed if (r['st'], r['hx'], r['hy']) == (0, wx, wy - 48)]
        grips = [r for r in observed if r['st'] == 8]
        high = [r for r in observed if r['st'] == 0 and r['hy'] > 1210]
        slopes = [(x, y) for x, y in zip(observed, observed[1:]) if x['st'] == y['st'] == 0 and x['hx'] != y['hx'] and (x['kind'] == y['kind']) and (x['kind'] in range(2, 8))]
        wrong = [y['frame'] for x, y in slopes if (y['hy'] - x['hy']) * (1 if x['kind'] < 5 else -1) < 0]
        result = dict(label=label, machine=m, case=case, natural_controls=natural, grip_frames=len(grips), high_ground_frames=len(high), slope_frames=len(slopes), against_slope_frames=wrong, first_grip=grips[0] if grips else None, first_high_ground=high[0] if high else None, fixed_stand_frames=len(fixed), motion_sha256=BF.sha((out / 'motion.tsv').read_bytes()))
        print(label, m, case, 'grip', len(grips), 'high ground', len(high), 'slopes', len(slopes), 'wrong', wrong[:5], flush=True)
        return result
    jobs = [(label, m, c) for label in ('control', 'candidate') for m in machines for c in selected]
    with ThreadPoolExecutor(2) as ex:
        results = list(ex.map(run, jobs))
    checks = []
    for m in machines:
        for case in selected:
            old, new = [next((r for r in results if r['machine'] == m and r['case'] == case and (r['label'] == label))) for label in ('control', 'candidate')]
            if case.startswith('catch'):
                grip = new['first_grip']
                i = int(case[-1])
                left = (840, 1248, 1632, 1896)[i]
                passed = new['grip_frames'] >= 240 and old['grip_frames'] == 0 and (grip['hy'] == 1198) and (left <= grip['hx'] < left + 96)
            elif case.startswith('flat'):
                passed = new['fixed_stand_frames'] == 210 and old['fixed_stand_frames'] == 0
            else:
                passed = new['fixed_stand_frames'] == 210 and new['high_ground_frames'] >= 500 and (new['slope_frames'] >= 200) and (not new['against_slope_frames'])
            checks.append(dict(machine=m, case=case, passed=bool(passed)))
    if not all((c['passed'] for c in checks)):
        raise ValueError('platform behavior check failed')
    masks = [F.source_mask(p, True)[0] for p in (a.map0_capture, a.map1_capture)]
    geometry = []
    for m in machines:
        oldimg, oldbank = G.images(a.control.resolve(), a.rom_dir.resolve(), m)
        img, bank = G.images(a.build.resolve(), a.rom_dir.resolve(), m)
        if img[:524288] != oldimg[:524288]:
            raise ValueError('native program code changed')
        for map_index, source_index in ((0, 0), (1, 1), (3, 0), (4, 0), (5, 0), (6, 0)):
            floor = DS.Floor(img, bank, DS.layer_record(img, 5, map_index))
            mask = masks[source_index]
            count = bad = 0
            for x in range(mask.shape[1]):
                yy = F.np.flatnonzero(mask[:, x])
                if not len(yy):
                    continue
                surfaces = floor.surfaces(x)
                for y in yy:
                    count += 1
                    if not surfaces or min((abs(top - (2048 - int(y))) for top, k in surfaces)) > 2:
                        bad += 1
            if bad:
                raise ValueError('an omitted platform source column is still missing')
            geometry.append(dict(machine=m, map_index=map_index, source_columns=count, missing_columns=bad, passed=True))
        oldrd, rd = (DS.reader(oldimg, oldbank), DS.reader(img, bank))
        oldsets, newsets = (F.DX.collision_sets(oldimg), F.DX.collision_sets(img))

        def signature(read, table, code, flips):
            pg, ty, fp, flags, recs = table
            page = read(pg + (code >> 8) + 8 * flips)[0]
            value = read(ty + (page - 1) * 256 + (code & 255))[0] if page else 0
            flagpage = read(fp + (code >> 8) + 8 * flips)[0]
            flag = read(flags + (flagpage - 1) * 256 + (code & 255))[0] if flagpage else 0
            return (value, flag, read(recs + (value - 32) * 33, 33) if value >= 32 else None)
        for key in 'ABCD':
            for code in range(2040):
                for flips in range(4):
                    if code >> 8 == 5 and flips == 3:
                        continue
                    if signature(oldrd, oldsets[key], code, flips) != signature(rd, newsets[key], code, flips):
                        raise ValueError('stock collision profile or flag changed')
        for stage in range(5):
            before = DS.Floor(oldimg, oldbank, DS.layer_record(oldimg, stage)).cells
            after = DS.Floor(img, bank, DS.layer_record(img, stage)).cells
            if before != after:
                raise ValueError('stock stage floor changed')
    even, ok = SM.static_check(a, a.build)
    if not ok:
        raise ValueError('uneven slope records exceed the stock limit')
    report = dict(schema='striderex-platform-gate/1', passed=True, checks=checks, geometry=geometry, stock_program_and_all_collision_profiles_unchanged=True, desert_drawing_overlay_audited=bool(a.cadence_control), all_stock_collision_profiles_unchanged=True, static_evenness=even, runtime={k: rt[k] for k in ('binary_sha256', 'source_revision', 'board_wait')}, input_files={label: {m: s['files'] for m, s in meta['sets'].items()} for label, meta in metas.items()}, results=results, schedules={k: list(plans[k]) for k in selected}, hardware_review_granted=False)
    a.receipt.write_text(json.dumps(report, indent=2) + '\n')

def main():
    p = argparse.ArgumentParser(description=__doc__)
    for n in ('control', 'build', 'runtime', 'hbmame', 'rom-dir', 'workdir', 'receipt', 'map0-capture', 'map1-capture'):
        p.add_argument('--' + n, type=Path, required=True)
    p.add_argument('--regions', choices=('us', 'both'), default='both')
    p.add_argument('--cases')
    p.add_argument('--cadence-control', type=Path, help='parent of the separately audited desert drawing overlay')
    p.add_argument('--reuse', action='store_true')
    gate(p.parse_args())
if __name__ == '__main__':
    main()
