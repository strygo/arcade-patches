"""Audit every stage cue and model section/voice transitions on the exact pack."""
import argparse
from copy import deepcopy
import json
from pathlib import Path
import numpy as np
import gameplay_music as GM
import pack_model as PM
from cpsplus.pack import audition as A
from cpsplus.pack.format import PackReader, VERB_PLAY, VERB_NONE

def gate(a):
    rd = PackReader(a.pack)
    old = PackReader(a.control)
    if not all(rd.crc_check()) or not all(old.crc_check()):
        raise ValueError('pack CRC mismatch')
    checks = GM.coverage(rd)
    missing = [r['cue'] for r in GM.coverage(old) if not r['passed']]
    if missing != ['0x3', '0x79', '0x7a'] or not all((r['passed'] for r in checks)):
        raise ValueError('unexpected cue coverage')
    M = PM.Model(a.pack)
    manpath = GM.RECIPE.parent / 'audio_cues.json'
    man = json.loads(manpath.read_text())
    transitions = []
    for region, record in man['arcade'].items():
        for stage, seq in dict(record['stage_order'], Desert=['0x79', '0x04', '0x7a', '0x7a', '0x05']).items():
            writes = [(1, 240)]
            for i, c in enumerate(seq):
                writes.extend([(1000 * i + 100, int(c, 16)), (1000 * i + 101, 255)])
            events, segs = M.run(writes)
            for f, c in writes:
                if c in (255, 240):
                    continue
                track = M.state(segs, f)[0]
                if track != rd.triggers[c].track:
                    raise ValueError('stage transition loses arranged music')
            transitions.append(dict(region=region, stage=stage, cues=seq, passed=True))
    returns = []
    for cue in (184, 185, 186, 187, 188, 189, 190, 191, 192, 193, 194, 195, 196, 197, 198, 199):
        for row in checks:
            bg = int(row['cue'], 16)
            events, segs = M.run([(1, bg), (2, 255), (100, 252), (101, 255), (200, cue), (201, 255), (1500, bg)])
            if events[-1][-1] != 'start' or M.state(segs, 1500)[0] != row['track']:
                raise ValueError('voice return drops background music')
        returns.append(dict(voice_cue=hex(cue), backgrounds=len(checks), passed=True))
    seams = []
    for cue in (121, 122):
        index = rd.triggers[cue].track
        meta = rd.tracks[index]
        pcm = A._decode_track(rd, index)
        x = np.frombuffer(pcm, '<i2').reshape(-1, 2).astype(float) / 32768
        lo, hi = A._loop_points_samples(meta)
        if len(x) < hi or lo % 32 or hi % 32 or meta.xfade_enable:
            raise ValueError('invalid hardware loop')
        body = x[lo:hi]
        rms = float(np.sqrt(np.mean(body ** 2)))
        jump = float(np.max(abs(x[hi - 1] - x[lo])))
        if rms < 0.005 or jump > 0.08:
            raise ValueError('silent body or discontinuous join')
        seams.append(dict(cue=hex(cue), samples=[lo, hi], loop_seconds=(hi - lo) / 48000, body_rms=rms, seam_step=jump, decoded_sha256=GM.sha(pcm), passed=True))
    negative = []
    for cue in (3, 121, 122):
        row = rd.triggers[cue]
        rd.triggers[cue] = deepcopy(old.triggers[cue])
        assert not all((r['passed'] for r in GM.coverage(rd)))
        rd.triggers[cue] = row
        negative.append(hex(cue))
    row = rd.triggers[122]
    saved = row.suppress
    row.suppress = 0
    assert not all((r['passed'] for r in GM.coverage(rd)))
    row.suppress = saved
    report = dict(schema='striderex-gameplay-music-gate/1', passed=True, pack_sha256=GM.sha(a.pack.read_bytes()), control_pack_sha256=GM.sha(a.control.read_bytes()), cue_census_sha256=GM.sha(manpath.read_bytes()), coverage=checks, old_missing_cues=missing, stage_paths=transitions, voice_return_model=returns, seams=seams, negative_controls=negative + ['native leakage'], hardware_review_granted=False)
    a.receipt.write_text(json.dumps(report, indent=2) + '\n')
    print('PASS: 29 cues, both regional stage paths, 464 voice returns, two decoded joins; four negative controls rejected')

def main():
    p = argparse.ArgumentParser(description=__doc__)
    for n in ('pack', 'control', 'receipt'):
        p.add_argument('--' + n, type=Path, required=True)
    gate(p.parse_args())
if __name__ == '__main__':
    main()
