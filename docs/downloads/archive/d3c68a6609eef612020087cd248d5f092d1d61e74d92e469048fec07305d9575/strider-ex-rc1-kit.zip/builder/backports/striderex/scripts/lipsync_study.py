"""Strider EX: the speaking portraits' mouths against the voices, frame by frame (LIPSYNC.md; research)."""
import argparse
import hashlib
import json
import struct
import sys
from pathlib import Path
import numpy as np
sys.path.insert(0, str(Path(__file__).resolve().parent))
ROOT = Path(__file__).resolve().parents[3]
HERE = ROOT / 'backports/striderex'
CPS1_HZ = 59.637
FRAME = 1 / CPS1_HZ
BELOW = 30.0
FLOOR_DB = 36.0
LEAD_FRAMES = 1
MIN_HOLD = {0: 3, 1: 2, 2: 3}
MAX_HOLD = {2: 12}
SWITCH = 0.35
PEAK_FRAMES = 4
PEAK_DB, DIP_DB = (3.0, 8.0)
QUIET_DB = 24.0
HALF_FLOOR = 0.6
SHIFT_MAX = 0.25
REST, HALF, OPEN = (0, 1, 2)
SHAPES = {('intro_desert', 0): dict(half={128}, open={144}, rest=set()), ('brief_siberia', 0): dict(half={192}, open={208}, rest=set()), ('brief_siberia', 1): dict(half={192}, open={208}, rest=set()), ('brief_aerial', 0): dict(half={194}, open={196}, rest=set()), ('brief_aerial', 1): dict(half={198}, open={214}, rest=set()), ('flight', 0): dict(half={299}, open={297}, rest=set()), ('welcome_meio', 0): dict(half={448}, open={452}, rest={472}), ('welcome_meio', 1): dict(half={432, 417}, open={436, 421}, rest={424, 408})}

def load(p):
    return json.loads(Path(p).read_text(encoding='utf-8'))

def file_sha(p):
    h = hashlib.sha256()
    with open(p, 'rb') as f:
        for chunk in iter(lambda: f.read(1 << 22), b''):
            h.update(chunk)
    return h.hexdigest()

def mouth_keys():
    """[(key, dub_lipsync.MOUTHS entry)] in MOUTHS order; key = (scene, n-th mouth of that scene)."""
    import dub_lipsync as DL
    seen, out = ({}, [])
    for m in DL.MOUTHS:
        k = seen.get(m['scene'], 0)
        seen[m['scene']] = k + 1
        out.append(((m['scene'], k), m))
    return out

def catalog(census):
    return {c['id']: c for c in load(Path(census) / 'catalog/catalog.json')['cinematics']}

def sat_state(d, shapes, box):
    """The mouth state of one census frame: OPEN, HALF or REST, from the sprites over the mouth box, the patterns"""
    import pce_vdc as P
    y0, y1, x0, x1 = box
    known = shapes['open'] | shapes['half'] | shapes['rest']
    pats, places = (set(), set())
    for i, top, left, img, attr in P.sprite_objects(d):
        if top < y1 + 16 and top + img.shape[0] > y0 + 16 and (left < x1) and (left + img.shape[1] > x0):
            pat = int(d['sat'][4 * i + 2]) >> 1
            pats.add(pat)
            if pat in known:
                places.add((128 + left & 511, top & 511))
    if pats & shapes['open']:
        return (OPEN, pats, places)
    if pats & shapes['half']:
        return (HALF, pats, places)
    return (REST, pats, places)

def pce_states(census, build, key, m, every=False, shown=None):
    """(times, states, census frames, other patterns seen, mouth sprite places) of one mouth over its span, or"""
    import cinematic_convert as C
    cat = catalog(census)
    sid = m['scene']
    run = Path(census) / cat[sid]['run']
    if every:
        idx = C.P.read_index(run)
        t0 = cat[sid]['cd_request_time']
        rows = sorted(((f, float(r['time']) - t0) for f, r in idx.items()))
    else:
        rows = [(int(f), float(t)) for f, t in load(Path(build) / 'frames.json')[sid]['census']]
    lo, hi = shown if shown else (m['span'][0] - 0.001, m['span'][1] + 0.001)
    rows = [(f, t) for f, t in rows if lo - 1e-06 <= t < hi - 1e-06]
    shapes = SHAPES[key]
    known = shapes['open'] | shapes['half'] | shapes['rest']
    st, other, places = ([], set(), set())
    for f, t in rows:
        s, pats, pl = sat_state(C.load_frame(run, f), shapes, m['box'])
        st.append(s)
        other |= pats - known
        places |= pl
    return (np.array([t for _, t in rows]), np.array(st, np.int8), [f for f, _ in rows], other, places)

def cycles(states):
    """The talking pattern as cycles: [(half, open, half, rest)] frame counts, from the first movement; a cycle"""
    runs = []
    for s in states:
        if runs and runs[-1][0] == s:
            runs[-1][1] += 1
        else:
            runs.append([int(s), 1])
    while runs and runs[0][0] == REST:
        runs.pop(0)
    out, cur = ([], [])
    for s, n in runs:
        cur.append((s, n))
        if s == REST:
            out.append(tuple(cur))
            cur = []
    if cur:
        out.append(tuple(cur))
    return out

def loop_period(cyc):
    """The shortest p such that the cycle list repeats with period p (every complete cycle equal to the one p"""
    whole = cyc[:-1] if len(cyc) > 1 else cyc
    for p in range(1, len(whole) + 1):
        if all((whole[k] == whole[k - p] for k in range(p, len(whole)))):
            return p
    return None

def stream_lists(build, sid):
    """[(record, [(x, y, code, attr)])] of every op 2 sprite list in a scene's stream (build work dir)."""
    import cinematic_timing as T
    stream = (Path(build) / 'work' / f'scene_{sid}.bin').read_bytes()
    out = []
    for r, (pos, body) in enumerate(T.records(stream)):
        for op, slot, q in T.ops(body + b'\x00\x00'):
            if op == 2:
                cnt, = struct.unpack_from('>H', body, q + 2)
                out.append((r, [struct.unpack_from('>HHHH', body, q + 4 + 8 * i) for i in range(cnt)]))
    return out

def stream_mouth(build, m, times, states, frames, places):
    """The mouth in the EX stream: the sprite entries at the mouth sprites' places (pce_states) in the lists that"""
    import cinematic_convert as C
    fj = load(Path(build) / 'frames.json')[m['scene']]
    pre = fj['preroll']
    ctimes = [float(t) for _, t in fj['census']]
    lists = stream_lists(build, m['scene'])
    lo, hi = (float(times[0]), float(times[-1]) + FRAME)
    shown, cur, li = ({}, [], 0)
    for n in range(len(ctimes)):
        while li < len(lists) and lists[li][0] <= n + pre - C.SPRITE_LEAD:
            cur = lists[li][1]
            li += 1
        shown[n] = cur
    at_mouth = lambda lst: [(i, e) for i, e in enumerate(lst) if (e[0], e[1]) in places]
    entries = {}
    t2n = {round(t, 6): n for n, t in enumerate(ctimes)}
    for t, s in zip(times, states):
        n = t2n[round(float(t), 6)]
        entries.setdefault(int(s), set()).add(tuple(((i,) + tuple(e) for i, e in at_mouth(shown[n]))))
    changes, prev = ([], None)
    for r, lst in lists:
        n = r - pre + C.SPRITE_LEAD
        others = [e for e in lst if (e[0], e[1]) not in places]
        if 0 <= n < len(ctimes) and lo - 1e-06 <= ctimes[n] < hi - 1e-06:
            changes.append(dict(record=r, frame=n, t=round(ctimes[n], 3), entries=len(lst), mouth=[[i] + list(e) for i, e in at_mouth(lst)], mouth_only=prev is not None and others == prev))
        prev = others

    def rect(e):
        return (e[0], e[1], e[0] + 16 * ((e[3] >> 8 & 15) + 1), e[1] + 16 * ((e[3] >> 12 & 15) + 1))

    def meets(p, q):
        return p[0] < q[2] and q[0] < p[2] and (p[1] < q[3]) and (q[1] < p[3])
    over = set()
    for t in times:
        lst = shown[t2n[round(float(t), 6)]]
        for i, e in at_mouth(lst):
            for j, f in enumerate(lst[:i]):
                if (f[0], f[1]) not in places and meets(rect(e), rect(f)):
                    over.add(tuple(f))
    return dict(places=sorted(places), entries={str(s): sorted([list(x) for x in v]) for s, v in entries.items()}, lists=changes, mouth_only_bytes=sum((4 + 8 * c['entries'] for c in changes if c['mouth_only'])), drawn_over_mouth=sorted((list(x) for x in over)))

def speaker_levels(track, lines, lang, times, cand=None, lead=0):
    """Per stream frame: the speaker's voice level in dB re its line's loud level (the 95th percentile of the"""
    import caption_pacing as CP
    import dub_runs as DR
    at = np.asarray(times) + FRAME / 2 + lead * FRAME
    rel = np.full(len(at), -200.0)
    spans = {}
    if lang == 'ja':
        voc, _ = CP.stems(track)
        ja = CP.ja_voice(track, voc)
        t, e = CP.envelope(voc.mean(0), CP.RATE44)
        for lid in lines:
            v = ja.get(lid)
            if not v:
                continue
            lo, hi = v['window']
            w = (at >= lo) & (at <= hi)
            rel[w] = np.maximum(rel[w], np.interp(at[w], t, e) - v['ref_db'])
            spans[lid] = (v['on'], v['off'])
        return (rel, spans)
    old = DR.swap(Path(cand) / 'takes.json' if cand else None, Path(cand) / 'fit.json' if cand else None)
    try:
        en = CP.en_voice(track)
    finally:
        DR.swap(*old)
    for lid in lines:
        v = en.get(lid)
        if not v:
            continue
        t, e = CP.envelope(v['_x'], CP.RATE44)
        t = t + v['_a'] / CP.RATE44
        w = (at >= t[0]) & (at <= t[-1])
        rel[w] = np.maximum(rel[w], np.interp(at[w], t, e) - v['ref_db'])
        spans[lid] = (v['on'], v['off'])
    return (rel, spans)

def frame_runs(times, on, bridge_s=0.0):
    """[[start, end]] seconds of runs of frames where `on`, end = the last frame + one frame; gaps under bridge_s"""
    out = []
    for k in np.nonzero(on)[0]:
        a, b = (float(times[k]), float(times[k]) + FRAME)
        if out and a - out[-1][1] < 1e-06 + bridge_s:
            out[-1][1] = b
        else:
            out.append([a, b])
    return out

def measures(times, states, rel):
    """The agreement of one mouth sequence with one voice, on the frames given (the portrait up)."""
    import dub_lipsync as DL
    states = np.asarray(states)
    voiced = rel > -BELOW
    moving = states != REST
    M = frame_runs(times, moving, DL.MOUTH_BRIDGE)
    V = frame_runs(times, voiced, DL.MOUTH_BRIDGE)
    out = dict(frames=int(len(times)))
    if V and M:
        both = DL.overlap(M, V)
        out.update(start=round(V[0][0] - M[0][0], 3), end=round(V[-1][1] - M[-1][1], 3), moving_silent=round(sum((b - a for a, b in M)) - both, 3), voice_still=round(sum((b - a for a, b in V)) - both, 3))
    out['agree'] = round(float(np.mean(moving == voiced)), 3)
    out['open_silent_frames'] = int(np.sum(moving & ~voiced))
    out['still_voiced_frames'] = int(np.sum(~moving & voiced))
    lev = np.maximum(rel, -FLOOR_DB)
    if np.std(states) > 0 and np.std(lev) > 0:
        out['r'] = round(float(np.corrcoef(states.astype(float), lev)[0, 1]), 3)
    else:
        out['r'] = None
    out['changes'] = int(np.sum(states[1:] != states[:-1]))
    out['mouth_out_share'] = round(float(np.mean(moving)), 3)
    out['voiced_share'] = round(float(np.mean(voiced)), 3)
    return out

def driven_want(rel_lead):
    """The opening (0-2) each frame asks for: 0 in silence (BELOW dB under the line's loud level); while the voice"""
    lv = np.asarray(rel_lead, float)
    n = len(lv)
    peak = np.array([lv[max(0, k - PEAK_FRAMES):k + PEAK_FRAMES + 1].max() for k in range(n)])
    o = np.clip(1.0 + (lv - peak + DIP_DB) / (DIP_DB - PEAK_DB), HALF_FLOOR, 2.0)
    o = np.minimum(o, 1.0 + np.clip((lv + QUIET_DB) / 10.0, 0.0, 1.0))
    return np.where(lv > -BELOW, np.maximum(o, HALF_FLOOR), 0.0)

def driven_track(rel_lead, hold=MIN_HOLD, most=MAX_HOLD, switch=SWITCH):
    """Option a: a shape per frame from the voice's level (rel_lead: dB re the line's loud level, LEAD_FRAMES"""
    want = driven_want(rel_lead)
    cap = {s: most.get(s) or hold[s] for s in (REST, HALF, OPEN)}
    states = [(s, k) for s in (REST, HALF, OPEN) for k in range(1, cap[s] + 1)]
    ix = {st: i for i, st in enumerate(states)}
    n, ns = (len(want), len(states))
    INF = 1e+18
    cost = np.full(ns, INF)
    cost[ix[REST, cap[REST]]] = 0.0
    back = np.zeros((n, ns), np.int32)
    nxt = {REST: (HALF,), HALF: (REST, OPEN), OPEN: (HALF,)}
    for t in range(n):
        new = np.full(ns, INF)
        arg = np.zeros(ns, np.int32)
        for i, (s, k) in enumerate(states):
            c = cost[i]
            if c >= INF:
                continue
            if not (most.get(s) and k >= most[s]):
                j = ix[s, min(k + 1, cap[s])]
                if c < new[j]:
                    new[j], arg[j] = (c, i)
            if k >= hold[s]:
                for s2 in nxt[s]:
                    j = ix[s2, 1]
                    if c + switch < new[j]:
                        new[j], arg[j] = (c + switch, i)
        for j, (s, k) in enumerate(states):
            if new[j] < INF:
                new[j] += (want[t] - s) ** 2
        cost, back[t] = (new, arg)
    i = int(np.argmin(cost))
    out = np.zeros(n, np.int8)
    for t in range(n - 1, -1, -1):
        out[t] = states[i][0]
        i = back[t][i]
    return out

def retimed_track(pce_cycles, voiced, bridge_frames):
    """Option c: the PC Engine's talking loop (its cycles, from its first) started at each voiced run (runs"""
    seq = [s for cyc in pce_cycles for s, nn in cyc for _ in range(nn)]
    half_len = next((nn for s, nn in pce_cycles[0] if s == HALF))
    v = np.asarray(voiced, bool)
    n = len(v)
    runs = []
    for k in np.nonzero(v)[0]:
        if runs and k - runs[-1][1] <= bridge_frames:
            runs[-1][1] = k
        else:
            runs.append([k, k])
    out = np.zeros(n, np.int8)
    for a, b in runs:
        k = a
        while k <= b:
            out[k] = seq[(k - a) % len(seq)]
            k += 1
        if out[b] == OPEN:
            for j in range(b + 1, min(n, b + 1 + half_len)):
                out[j] = HALF
    return out

def place_bound(times, states, rel, shift_max=SHIFT_MAX):
    """Option b's ceiling: the best frame agreement the fixed loop gives when the voice is moved as a block by up"""
    n = len(states)
    best = (-1.0, 0.0)
    k_max = int(round(shift_max * CPS1_HZ))
    for k in range(-k_max, k_max + 1):
        r = np.full(n, -200.0)
        if k >= 0:
            r[k:] = rel[:n - k]
        else:
            r[:n + k] = rel[-k:]
        a = float(np.mean((np.asarray(states) != REST) == (r > -BELOW)))
        if a > best[0] + 1e-09:
            best = (round(a, 3), round(k * FRAME, 3))
    return best

def shown_span(a, m):
    """The portrait up and at rest in place (dub_lipsync.mouth_track's shown span, s)."""
    import dub_lipsync as DL
    return DL.mouth_track(DL.render_scene(a.census, a.build, m['scene'], a.work), m)['shown']

def cmd_mouths(a):
    rows = []
    for key, m in mouth_keys():
        sh = shown_span(a, m)
        times, states, frames, other, places = pce_states(a.census, a.build, key, m, every=True, shown=sh)
        cyc = cycles(states)
        p = loop_period(cyc)
        st_t, st_s, st_f, _, st_pl = pce_states(a.census, a.build, key, m, shown=sh)
        sm = stream_mouth(a.build, m, st_t, st_s, st_f, st_pl)
        row = dict(scene=m['scene'], who=m['who'], key=list(key), box=list(m['box']), shown=sh, sprites={k: sorted((f'{v:#05x}' for v in vs)) for k, vs in SHAPES[key].items()}, other_patterns=sorted((f'{v:#05x}' for v in other)), pce_frames=int(len(states)), shapes_seen=sorted({int(s) for s in states}), frames_by_shape={str(s): int(np.sum(states == s)) for s in (REST, HALF, OPEN)}, cycles=[[list(x) for x in c] for c in cyc], loop_period_cycles=p, loop=[[list(x) for x in c] for c in cyc[:p]] if p else None, loop_frames=sum((n for c in cyc[:p] for _, n in c)) if p else None, stream=sm)
        rows.append(row)
        mo = sum((1 for c in sm['lists'] if c['mouth_only']))
        row['mouth_only_bytes'] = sm['mouth_only_bytes']
        row['drawn_over_mouth'] = sm['drawn_over_mouth']
        print(f"{m['scene']} {m['who']}: shown {sh[0]:.2f}-{sh[1]:.2f} s")
        print(f"   PC Engine: {len(states)} frames, by shape {row['frames_by_shape']}, sprites {row['sprites']}{('; other sprites there ' + str(row['other_patterns']) if other else '')}; {len(cyc)} cycles; fixed loop of {p} cycle(s), {row['loop_frames']} frames: {row['loop']}")
        print(f"   EX: mouth places {sm['places']}; entries per state (index, x, y, code, attr) {sm['entries']}; {len(sm['lists'])} lists in the span, {mo} re-sent for the mouth alone ({sm['mouth_only_bytes']} stream bytes); list sizes {min((c['entries'] for c in sm['lists']))}-{max((c['entries'] for c in sm['lists']))}; entries drawn over the mouth {sm['drawn_over_mouth']}")
    if a.json:
        Path(a.json).write_text(json.dumps(dict(mouths=rows), indent=1) + '\n')
    return 0

def agree_rows(a):
    import dub_lipsync as DL
    out = []
    for key, m in mouth_keys():
        track = DL.SCENE_TRACK[m['scene']]
        sh = shown_span(a, m)
        times, states, frames, _, _ = pce_states(a.census, a.build, key, m, shown=sh)
        cyc_all = cycles(pce_states(a.census, a.build, key, m, every=True, shown=sh)[1])
        p = loop_period(cyc_all) or len(cyc_all)
        loop = cyc_all[:p]
        mt = DL.mouth_track(DL.render_scene(a.census, a.build, m['scene'], a.work), m)
        row = dict(scene=m['scene'], track=track, who=m['who'], key=list(key), shown=sh, mouth_runs=mt['runs'])
        for lang in ('ja', 'en'):
            cand = a.cand if lang == 'en' else None
            rel, spans = speaker_levels(track, m['lines'], lang, times, cand)
            rel_lead, _ = speaker_levels(track, m['lines'], lang, times, cand, lead=LEAD_FRAMES)
            voiced = rel > -BELOW
            drv = driven_track(rel_lead)
            ret = retimed_track(loop, voiced, int(round(DL.MOUTH_BRIDGE * CPS1_HZ)))
            row[lang] = dict(lines={k: [round(x, 3) for x in v] for k, v in spans.items()}, pce=measures(times, states, rel), driven=measures(times, drv, rel), retimed=measures(times, ret, rel), place_bound=place_bound(times, states, rel))
            row[lang]['_tracks'] = dict(pce=states, driven=drv, retimed=ret, rel=rel, times=times)
        out.append(row)
    return out

def cmd_agree(a):
    rows = agree_rows(a)
    keys = ('agree', 'r', 'start', 'end', 'moving_silent', 'voice_still', 'changes')
    for r in rows:
        print(f"{r['scene']} (tr{r['track']}) {r['who']}: shown {r['shown'][0]:.2f}-{r['shown'][1]:.2f} s")
        for lang in ('ja', 'en'):
            print(f"   {lang} lines {r[lang]['lines']}; option b ceiling {r[lang]['place_bound']}")
            for kind in ('pce', 'retimed', 'driven'):
                mm = r[lang][kind]
                print(f'      {kind:8} ' + '  '.join((f'{k} {mm.get(k)}' for k in keys)))
    if a.json:
        clean = [{k: {kk: vv for kk, vv in v.items() if kk != '_tracks'} if isinstance(v, dict) else v for k, v in r.items()} for r in rows]
        Path(a.json).write_text(json.dumps(dict(rows=clean), indent=1) + '\n')
    return 0
MTH_RAM = 16775616
SLOT = 3
BLANK = (0, 0, 0, 0)
MTH_POINT = 0.6
MTH_TEST = 0.05
HIDE_ENTRY = 0.12
HIDE_CODE = 0.06
MTH_INSERT = 0.07
PATCH_SUBTITLES_RESET = ('        clr.l   CAP_OFF                 ; CAP_OFF, CAP_SN\n', '        clr.l   CAP_OFF                 ; CAP_OFF, CAP_SN\n        clr.l   MTH_PTR                 ; no mouth track, no slot (LIPSYNC.md prototype)\n        clr.l   MTH_HIDE\n        clr.w   MTH_IN\n')
MTH_ASM = "\n; ---------------------------------------------------------------- mouth tracks (LIPSYNC.md, PROTOTYPE)\n; mouth_scenes (mouth.inc, lipsync_study.py proto): one long a scene (as `scenes`), the English dub's track\n; or 0. A track: the shape table (24 bytes a shape: three sprite entries), the stream's own mouth codes (words,\n; 0-ended), then (record.w, shape byte offset.w) points, ascending, ended by record $FFFF. The record is the\n; one the player has just applied (FRAMES before its increment), as cap_step's schedule: the shape is on\n; screen from the picture two records on. While a track runs the stream's list after the captions starts\n; with the three-entry slot (CAP_SN counts it), and op_sprites leaves out the stream's own mouth entries.\nMTH_PTR equ $%(ram)06X                   ; long: the next point, 0 = none\nMTH_SHP equ $%(ram4)06X                   ; long: the shape table\nMTH_HIDE equ $%(ram8)06X                  ; long: the hidden codes, 0 = no track (the stream's own mouths)\nMTH_CUR equ $%(ramc)06X                   ; long: the shape in the slot\nMTH_IN  equ $%(ram10)06X                   ; word: the slot is in the list (counted in CAP_SN)\n\n; mth_start: a2 = the scene's entry in `scenes`. The English dub's track (the voice resolved as cap_start\n; resolves it), else none. Clobbers d0, a0.\nmth_start:\n        clr.l   MTH_PTR\n        clr.l   MTH_HIDE\n        btst    #PACK,FLAGS+$F\n        beq.s   .out                    ; no pack: the stream's own mouths\n        move.b  FLAGS+$F,d0\n        lsr.b   #1,d0\n        and.w   #3,d0\n        bne.s   .v\n        moveq   #1+REGION_EN,d0\n.v:     cmp.w   #2,d0\n        bne.s   .out                    ; the Japanese voice: the PC Engine's own loop\n        move.l  a2,d0\n        sub.l   #scenes,d0              ; scene index * 8\n        lsr.w   #1,d0\n        lea     mouth_scenes,a0\n        move.l  0(a0,d0.w),d0\n        beq.s   .out\n        move.l  d0,a0\n        move.l  (a0)+,MTH_SHP\n        move.l  MTH_SHP,MTH_CUR         ; shape 0: rest\n        move.l  a0,MTH_HIDE\n.h:     tst.w   (a0)+\n        bne.s   .h\n        move.l  a0,MTH_PTR\n.out:   rts\n\n; mth_step: from cine_step after cap_step. Clobbers d0, d3, a1-a4.\nmth_step:\n        move.l  MTH_PTR,d0\n        beq     .out\n        move.l  d0,a1\n        move.w  FRAMES+2,d0\n        cmp.w   (a1)+,d0\n        bne     .out\n        move.w  (a1)+,d0\n        move.l  a1,MTH_PTR\n        move.l  MTH_SHP,a2\n        add.w   d0,a2\n        move.l  a2,MTH_CUR\n        move.l  OBJ_BACK,a3\n        add.w   CAP_OFF,a3\n        move.w  #1,SPR_NEW\n        tst.w   MTH_IN\n        bne.s   .put\n        move.w  CAP_SN,d3               ; the slot goes in: the stream's list up two entries, last first\n        move.w  d3,d0\n        lsl.w   #3,d0\n        lea     0(a3,d0.w),a4\n        lea     24(a4),a1\n        bra.s   .bt\n.b:     move.l  -(a4),-(a1)\n        move.l  -(a4),-(a1)\n.bt:    dbra    d3,.b\n        addq.w  #3,CAP_SN\n        move.w  #1,MTH_IN\n        move.w  CAP_SN,d0\n        lsl.w   #3,d0\n        move.l  a3,a4\n        add.w   d0,a3\n        bsr     end_a3\n        move.l  a4,a3\n.put:   move.l  (a2)+,(a3)+\n        move.l  (a2)+,(a3)+\n        move.l  (a2)+,(a3)+\n        move.l  (a2)+,(a3)+\n        move.l  (a2)+,(a3)+\n        move.l  (a2)+,(a3)+\n.out:   rts\n\n; op_sprites with a track: d5 = n, a3 = the list after the captions, d0 = the hidden codes. The slot, then the\n; stream's entries but its own mouth pictures.\nop_sprites_mth:\n        move.l  d0,a4\n        move.l  MTH_CUR,a1\n        move.l  (a1)+,(a3)+\n        move.l  (a1)+,(a3)+\n        move.l  (a1)+,(a3)+\n        move.l  (a1)+,(a3)+\n        move.l  (a1)+,(a3)+\n        move.l  (a1)+,(a3)+\n        moveq   #3,d6\n        bra.s   .t\n.s:     move.w  4(a0),d1\n        move.l  a4,a1\n.h:     move.w  (a1)+,d2\n        beq.s   .keep\n        cmp.w   d2,d1\n        bne.s   .h\n        addq.l  #8,a0                   ; one of the stream's own mouth pictures: left out\n        bra.s   .t\n.keep:  move.l  (a0)+,(a3)+\n        move.l  (a0)+,(a3)+\n        addq.w  #1,d6\n.t:     dbra    d5,.s\n        move.w  d6,CAP_SN\n        move.w  #1,MTH_IN\n        bsr     end_a3\n        bra     next_rec\n"
PATCH_CORE_SPRITES = ('    ifd CAP_OFF\n        add.w   CAP_OFF,a3              ; after the caption entries\n        move.w  d5,CAP_SN\n    endif\n        bra.s   .t\n', '    ifd CAP_OFF\n        add.w   CAP_OFF,a3              ; after the caption entries\n        move.w  d5,CAP_SN\n    endif\n    ifd MTH_HIDE\n        move.l  MTH_HIDE,d0             ; a mouth track (LIPSYNC.md prototype)\n        bne     op_sprites_mth\n        clr.w   MTH_IN\n    endif\n        bra.s   .t\n')
PATCH_CORE_DONE = ('        bsr     cap_step                ; caption schedule (subtitles.s)\n', '        bsr     cap_step                ; caption schedule (subtitles.s)\n    ifd MTH_PTR\n        bsr     mth_step                ; mouth track (LIPSYNC.md prototype)\n    endif\n')
PATCH_BANK_START = (".set:   bsr     cap_start               ; this scene's caption schedule\n", ".set:   bsr     cap_start               ; this scene's caption schedule\n        bsr     mth_start               ; and its mouth track (LIPSYNC.md prototype)\n")
PATCH_BANK_INC = ('        include "captions.inc"          ; subtitle_ex.py\n', '        include "captions.inc"          ; subtitle_ex.py\n        even\n        include "mouth.inc"             ; mouth tracks (LIPSYNC.md prototype)\n')

def proto_asm(dst):
    """Patched copies of subtitles.s, scene_core.s and ex_bank.s in dst (each patch must apply once)."""
    asm = HERE / 'asm'
    dst = Path(dst)
    dst.mkdir(parents=True, exist_ok=True)

    def patch(text, pair, name):
        if text.count(pair[0]) != 1:
            sys.exit(f'{name}: the prototype patch site is not there once')
        return text.replace(pair[0], pair[1])
    sub = patch((asm / 'subtitles.s').read_text(), PATCH_SUBTITLES_RESET, 'subtitles.s')
    r = MTH_RAM
    sub += MTH_ASM % dict(ram=r, ram4=r + 4, ram8=r + 8, ramc=r + 12, ram10=r + 16)
    (dst / 'subtitles.s').write_text(sub)
    core = (asm / 'scene_core.s').read_text()
    core = patch(patch(core, PATCH_CORE_SPRITES, 'scene_core.s'), PATCH_CORE_DONE, 'scene_core.s')
    (dst / 'scene_core.s').write_text(core)
    bank = (asm / 'ex_bank.s').read_text()
    bank = patch(patch(bank, PATCH_BANK_START, 'ex_bank.s'), PATCH_BANK_INC, 'ex_bank.s')
    (dst / 'ex_bank.s').write_text(bank)
    return dst

def scene_track(a, sid, lang='en', kind='driven'):
    """One scene's mouth track for one voice: per stream frame the slot's entries, every portrait's mouth of"""
    import cinematic_convert as C
    import dub_lipsync as DL
    fj = load(Path(a.build) / 'frames.json')[sid]
    pre = fj['preroll']
    ctimes = np.array([float(t) for _, t in fj['census']])
    n = len(ctimes)
    ports = [(k, m) for k, m in mouth_keys() if m['scene'] == sid]
    if not ports:
        return None
    lists = stream_lists(a.build, sid)
    shown_list, cur, li = ([], [], 0)
    for k in range(n):
        while li < len(lists) and lists[li][0] <= k + pre - C.SPRITE_LEAD:
            cur = lists[li][1]
            li += 1
        shown_list.append(cur)
    per, codes, report = ([], set(), [])
    t2n = {round(float(t), 6): k for k, t in enumerate(ctimes)}
    for key, m in ports:
        sh = shown_span(a, m)
        times, states, frames, _, places = pce_states(a.census, a.build, key, m, shown=sh)
        sm = stream_mouth(a.build, m, times, states, frames, places)
        shape, own_codes = ({}, set())
        for st, sets in sm['entries'].items():
            if len(sets) != 1:
                sys.exit(f"{sid} {m['who']}: state {st} is drawn {len(sets)} ways in the stream")
            ents = [tuple(e[1:]) for e in sets[0]]
            shape[int(st)] = tuple(ents)
            own_codes |= {e[2] for e in ents}
        codes |= own_codes
        track = DL.SCENE_TRACK[sid]
        cand = a.cand if lang == 'en' else None
        if kind == 'driven':
            rel_lead, _ = speaker_levels(track, m['lines'], lang, times, cand, lead=LEAD_FRAMES)
            got = driven_track(rel_lead)
        else:
            rel, _ = speaker_levels(track, m['lines'], lang, times, cand)
            cyc = cycles(pce_states(a.census, a.build, key, m, every=True, shown=sh)[1])
            got = retimed_track(cyc[:loop_period(cyc) or len(cyc)], rel > -BELOW, int(round(DL.MOUTH_BRIDGE * CPS1_HZ)))
        driven = {t2n[round(float(t), 6)]: shape.get(int(s_), ()) for t, s_ in zip(times, got)}
        per.append((driven, own_codes, set(places)))
        report.append(dict(who=m['who'], shown=sh, shapes={str(k): [list(e) for e in v] for k, v in shape.items()}, frames=int(len(times)), changes=int(np.sum(got[1:] != got[:-1])), states=''.join((str(int(x)) for x in got)), first_frame=t2n[round(float(times[0]), 6)], key=list(key)))
    slot = []
    for k in range(n):
        up = [i for i, (dv, _, _) in enumerate(per) if k in dv]
        if not up:
            sl = tuple((tuple(e) for e in shown_list[k] if e[2] in codes))
        else:
            sl = ()
            for i, (dv, cs, pl) in enumerate(per):
                sl += dv[k] if i in up else tuple((tuple(e) for e in shown_list[k] if e[2] in cs and (e[0], e[1]) in pl))
        if len(sl) > SLOT:
            sys.exit(f'{sid}: frame {k} needs {len(sl)} mouth entries (the slot holds {SLOT})')
        slot.append(sl)
    full = [tuple(sl) + (BLANK,) * (SLOT - len(sl)) for sl in slot]
    shapes = [(BLANK,) * SLOT]
    points, prev = ([], shapes[0])
    for k in range(n):
        if full[k] != prev:
            if full[k] not in shapes:
                shapes.append(full[k])
            points.append((k + pre - C.SPRITE_LEAD, shapes.index(full[k])))
            prev = full[k]
    if points and points[0][0] < 0:
        sys.exit(f"{sid}: a mouth point before the stream's first record")
    return dict(scene=sid, lang=lang, kind=kind, preroll=pre, points=points, hide=sorted(codes), shapes=shapes, portraits=report, bytes=4 + 2 * (len(codes) + 1) + 4 * len(points) + 2 + 8 * SLOT * len(shapes))

def mouth_inc(scene_ids, tracks):
    """mouth.inc: mouth_scenes (a long a scene in `scenes` order) and each track."""
    lines = ['; mouth tracks (lipsync_study.py proto: LIPSYNC.md, PROTOTYPE)', 'mouth_scenes:']
    for sid in scene_ids:
        lines.append(f"        dc.l    {('mt_' + sid if sid in tracks else '0')}")
    for sid, tr in tracks.items():
        lines += [f'mt_{sid}:', f'        dc.l    mts_{sid}', '        dc.w    ' + ','.join((f'${c:04X}' for c in tr['hide'] + [0]))]
        pts = [f'{r},{8 * SLOT * sh}' for r, sh in tr['points']] + ['$FFFF']
        for i in range(0, len(pts), 8):
            lines.append('        dc.w    ' + ','.join(pts[i:i + 8]))
        lines.append(f'mts_{sid}:')
        for sh in tr['shapes']:
            lines.append('        dc.w    ' + ','.join((f'${v:04X}' for e in sh for v in e)))
    return '\n'.join(lines) + '\n'

def predict_mouth(stream, lz, schedule, pages, track):
    """cinematic_timing.predict with a mouth track: the hide scan in every op 2 record once the track runs, the"""
    import cinematic_timing as T
    recs = T.records(stream)
    groups = T.lz_groups(lz)
    sched = dict(((int(r), p) for r, p in schedule))
    pts = dict(track['points']) if track else {}
    hide = set(track['hide']) if track else set()
    gi, w = (0, 0)

    def fill(r, need):
        nonlocal gi, w
        t = 0.0
        while w - r < need and gi < len(groups):
            end, lit, mt, mb = groups[gi]
            k = T.SLOW if w % T.RSIZE > T.SLOW_FROM else 1.0
            t += T.DECODE['group'] + k * (T.DECODE['literal'] * lit + T.DECODE['match'] * mt + T.DECODE['match_byte'] * mb)
            w = end
            gi += 1
        return t

    def mirror(pos, size):
        return T.MIRROR_BYTE * max(0, pos % T.RSIZE + size - T.RSIZE)
    fill(0, 2)
    if recs:
        fill(0, len(recs[0][1]) + 2)
    lines, cap, stream_n, spr_new, slot_in = ([], 0, 0, 0, False)
    for k, (pos, body) in enumerate(recs):
        t = T.BASE + (T.FLIP_ENTRY * spr_new if spr_new else 0.0)
        spr_new = 0
        a_, sprites, _ = T.apply_lines(body)
        t += a_
        if sprites is not None:
            if track:
                ents = [struct.unpack_from('>HHHH', body, q + 4 + 8 * i) for op, _, q in T.ops(body + b'\x00\x00') if op == 2 for i in range(sprites)]
                t += (HIDE_ENTRY + HIDE_CODE * (len(hide) + 1)) * sprites
                stream_n = sum((1 for e in ents if e[2] not in hide)) + SLOT
                slot_in = True
            else:
                stream_n = sprites
            spr_new = cap + stream_n + 1
        if k in sched:
            pg = sched[k]
            cap = len(pages[pg][1]) if pg is not None else 0
            t += T.CAP_ENTRY * (stream_n + cap)
            spr_new = cap + stream_n + 1
        if track:
            t += MTH_TEST
            if k in pts:
                t += MTH_POINT
                if not slot_in:
                    t += MTH_INSERT * stream_n
                    stream_n += SLOT
                    slot_in = True
                spr_new = cap + stream_n + 1
        r = pos + 2 + len(body)
        t += fill(r, 2)
        if k + 1 < len(recs):
            size = len(recs[k + 1][1]) + 2
            t += fill(r, size) + mirror(r, size)
        lines.append(t)
    return lines

def load_region(build):
    """The 4 MB EX graphics region of a build (its strex_gfx.c25-c31, cps1_gfx.split_region inverted)."""
    import build_ex as BX
    words = np.zeros((1 << 19, 4), '>u2')
    for j, name in enumerate(BX.EX_GFX):
        words[:, j] = np.frombuffer((Path(build) / 'striderua' / name).read_bytes(), '>u2')
    return bytearray(words.tobytes())

class MouthModel:
    """cinematic_convert.CpsModel with the prototype player's mouth track (no captions): op 2's list without the"""

    def __init__(self, region, stream, track):
        import cinematic_convert as C
        self.m = C.CpsModel(region)
        self.stream, self.pos, self.k = (stream, 0, 0)
        self.pts = dict(track['points'])
        self.hide = set(track['hide'])
        self.shapes = track['shapes']
        self.cur, self.slot_in, self.own = (self.shapes[0], False, [])
        self.composite = self.m.sprites

    def step(self):
        m = self.m
        pos = m.run(self.stream, self.pos)
        if pos is None:
            return False
        self.pos = pos
        if m.sprites is not self.composite:
            self.own = [e for e in m.sprites if e[2] not in self.hide]
            self.slot_in = True
        if self.k in self.pts:
            self.cur = self.shapes[self.pts[self.k]]
            self.slot_in = True
        slot = [e for e in self.cur if e != BLANK] if self.slot_in else []
        m.sprites = self.composite = [tuple(e) for e in slot] + list(self.own)
        self.k += 1
        return True

def sat_words(census, build, key, m, shown):
    """{state: {SAT index: its four words}} of a portrait's mouth sprites as the census shows each state."""
    import cinematic_convert as C
    import pce_vdc as P
    run = Path(census) / catalog(census)[m['scene']]['run']
    times, states, frames, _, _ = pce_states(census, build, key, m, shown=shown)
    sh = SHAPES[key]
    known = sh['open'] | sh['half'] | sh['rest']
    out = {}
    for f, s in zip(frames, states):
        if int(s) in out:
            continue
        d = C.load_frame(run, f)
        y0, y1, x0, x1 = m['box']
        ent = {}
        for i, top, left, img, attr in P.sprite_objects(d):
            pat = int(d['sat'][4 * i + 2]) >> 1
            over = top < y1 + 16 and top + img.shape[0] > y0 + 16 and (left < x1) and (left + img.shape[1] > x0)
            if pat in known and over:
                ent[i] = tuple((int(v) for v in d['sat'][4 * i:4 * i + 4]))
        out[int(s)] = ent
    return out

def cmd_model(a):
    """The model check of a mouth track (LIPSYNC.md 4.1, gate 1): every frame of the scene's stream played by"""
    import cinematic_convert as C
    import pce_vdc as P
    region = load_region(a.build)
    out = {}
    ok = True
    for sid in a.scenes:
        tr = scene_track(a, sid, 'en', a.kind)
        fj = load(Path(a.build) / 'frames.json')[sid]
        frames = [int(f) for f, _ in fj['census']]
        stream = (Path(a.build) / 'work' / f'scene_{sid}.bin').read_bytes()
        run = Path(a.census) / catalog(a.census)[sid]['run']
        writes = P.read_writes(run)
        want_state = {}
        idx_all = set()
        words = {}
        for p in tr['portraits']:
            key = tuple(p['key'])
            m = dict(mouth_keys())[key]
            words[key] = sat_words(a.census, a.build, key, m, p['shown'])
            idx = set((i for w in words[key].values() for i in w))
            idx_all |= idx
            for j, s_ in enumerate(p['states']):
                want_state[p['first_frame'] + j] = (key, int(s_), idx)
        mm = MouthModel(region, stream, tr)
        for _ in range(fj['preroll']):
            mm.step()
        bad, swapped = ([], 0)
        for i, f in enumerate(frames):
            mm.step()
            got = mm.m.pal[mm.m.render()]
            d = C.load_frame(run, f)
            if i in want_state:
                key, s_, idx = want_state[i]
                sh_ = SHAPES[key]
                known = sh_['open'] | sh_['half'] | sh_['rest']
                ents = [d['sat'][4 * k:4 * k + 4].copy() for k in range(64)]
                ents = [e for k, e in enumerate(ents) if not (k in idx and int(e[2]) >> 1 in known)]
                top = [np.array(wd) for k, wd in sorted(words[key][s_].items())]
                ents = top + ents
                if any((int(e[0]) != 0 for e in ents[64:])):
                    bad.append(dict(frame=i, census=f, sat_full=len(ents)))
                ents = (ents + [np.zeros(4, ents[0].dtype)] * 64)[:64]
                sat = np.concatenate(ents).astype(d['sat'].dtype)
                d['sat'] = sat
                swapped += 1
            want = C.reference(d, writes.get(f), 16)
            rows = np.nonzero((got != want).any(1))[0]
            if len(rows):
                bad.append(dict(frame=i, census=f, lines=rows[:6].tolist(), pixels=int((got != want).sum())))
        out[sid] = dict(frames=len(frames), mouth_frames=swapped, failing=len(bad), first_failures=bad[:8])
        ok &= not bad
        print(f"{sid}: {len(frames)} frames, {swapped} with the track's mouth; {len(bad)} differ" + (f': {bad[:3]}' if bad else ''), flush=True)
    if a.json:
        Path(a.json).write_text(json.dumps(out, indent=1) + '\n')
    print('PASS' if ok else 'FAIL')
    return 0 if ok else 1

def cmd_proto(a):
    """The prototype EX ROM in scratch: build_ex.py as dub_runs.py candidate runs it for the candidate (its"""
    import subprocess
    import caption_pacing as CP
    import cinematic_timing as CT
    import dub_runs as DR
    import build_ex as BX
    cand = Path(a.cand).resolve()
    before = Path(a.build).resolve()
    tracks = {}
    for sid in a.scenes:
        tracks[sid] = scene_track(a, sid, 'en', a.kind)
        tr = tracks[sid]
        print(f"{sid}: {len(tr['points'])} points, {len(tr['shapes'])} shapes, hide {tr['hide']}, {tr['bytes']} bytes; " + '; '.join((f"{p['who']} {p['changes']} changes" for p in tr['portraits'])), flush=True)
    if cmd_model(argparse.Namespace(census=a.census, build=a.build, work=a.work, cand=a.cand, scenes=a.scenes, kind=a.kind, json=None)):
        sys.exit('the mouth tracks fail the model check')
    import tempfile
    with tempfile.TemporaryDirectory() as d:
        pa = proto_asm(Path(d) / 'proto_asm')
        (Path(d) / 'mouth.inc').write_text(mouth_inc([s['id'] for s in load(before / 'build.json')['scenes']], tracks))
        r = subprocess.run([str(a.vasm), '-Fbin', '-m68000', '-quiet', '-I', str(pa), '-I', str(HERE / 'asm'), '-I', str(before / 'work'), '-DREGION_EN=1', '-DDESERT=1', '-o', str(Path(d) / 'bank.bin'), str(pa / 'ex_bank.s')], cwd=d, capture_output=True, text=True)
        if r.returncode:
            sys.exit(f'the patched EX bank does not assemble:\n{r.stdout}{r.stderr}')
        print(f"the patched EX bank assembles: {(Path(d) / 'bank.bin').stat().st_size} bytes", flush=True)
    rep = dict(kind=a.kind, before=str(before), tracks={k: {kk: vv for kk, vv in v.items() if kk != 'portraits'} for k, v in tracks.items()}, portraits={k: v['portraits'] for k, v in tracks.items()})
    asm = HERE / 'asm'

    def assemble(vasm, work, scenes, cues, region_en, title_cells, ending, captions, card_frames, split, stills):
        for s in scenes:
            old = before / 'work' / f"scene_{s['id']}.bin"
            if s['id'] in tracks and (not old.exists() or old.read_bytes() != s['stream']):
                sys.exit(f"{s['id']}: the stream differs from {before}'s: the mouth track's records do not hold")
        pa = proto_asm(work / 'proto_asm')
        (work / 'mouth.inc').write_text(mouth_inc([s['id'] for s in scenes], tracks))
        (work / 'stills.inc').write_text(stills)
        for s in scenes:
            (work / f"scene_{s['id']}.lz").write_bytes(s['lz'])
            (work / f"scene_{s['id']}.bin").write_bytes(s['stream'])
        (work / 'stage_lists.inc').write_text(BX.stage_lists(scenes, cues, card_frames))
        (work / 'title_cells.inc').write_text(BX.TX.cells_inc(title_cells))
        (work / 'split_cells.inc').write_text(split)
        (work / 'ending_data.inc').write_text(BX.EE.data_inc(ending))
        (work / 'captions.inc').write_text(captions)
        out, lst = (work / f'ex_bank_{region_en}.bin', work / f'ex_bank_{region_en}.lst')
        subprocess.run([str(vasm), '-Fbin', '-m68000', '-quiet', '-I', str(pa), '-I', str(asm), '-I', str(work), f'-DREGION_EN={region_en}', *BX.ASM_DEFINES, '-L', str(lst), '-o', str(out), str(pa / 'ex_bank.s')], cwd=work, check=True)
        syms = {}
        for line in lst.read_text().splitlines():
            f = line.split()
            if len(f) == 2 and f[1][:2] in ('A:', 'E:'):
                syms[f[0]] = int(f[1][2:], 16)
        code = out.read_bytes()
        if len(code) > BX.MB - len(BX.FLAG_BLOCK):
            sys.exit(f'EX bank overflow: {len(code)} bytes')
        bank = bytearray(b'\xff' * BX.MB)
        bank[:len(code)] = code
        bank[BX.MB - 16:] = BX.FLAG_BLOCK
        rep.setdefault('symbols', {})[region_en] = {k: f'{syms[k]:#x}' for k in ('mth_start', 'mth_step', 'op_sprites_mth', 'mouth_scenes') if k in syms}
        return (bytes(bank), syms, len(code))
    orig_timing = BX.handler_timing

    def timing(scenes, cap_report):
        got = orig_timing(scenes, cap_report)
        pages = [(q['lang'], [tuple(e) for e in q['entries']]) for q in cap_report['pages_detail']]
        rep['handlers'] = {}
        for s in scenes:
            if s['id'] not in tracks:
                continue
            sched = cap_report['schedules'].get(s['id'], {}).get('en_dub', [])
            base = CT.report(CT.predict(s['stream'], s['lz'], sched, pages))
            with_m = CT.report(predict_mouth(s['stream'], s['lz'], sched, pages, tracks[s['id']]))
            rep['handlers'][s['id']] = dict(en_dub=base, en_dub_with_mouth=with_m)
            print(f"{s['id']} en_dub handlers: worst {base['worst_lines']} lines (record {base['worst_record']}); with the mouth track {with_m['worst_lines']} (record {with_m['worst_record']}); limit {CT.HANDLER_LIMIT}", flush=True)
            if with_m['over_limit']:
                sys.exit(f"{s['id']}: a handler with the mouth track over {CT.HANDLER_LIMIT} lines")
        return got
    BX.assemble_bank, BX.handler_timing = (assemble, timing)
    pack = cand / 'pack' / 'strider_ex.cpk'
    pin = dict(sha256=file_sha(pack), bytes=pack.stat().st_size, windows=True, note=f'candidate pack for {cand.name}')
    old = DR.swap(cand / 'takes.json', cand / 'fit.json')
    saved = (CP.PACK, CP.VOICE_MANIFEST, CP.FIT)
    CP.PACK, CP.VOICE_MANIFEST, CP.FIT = (pin, cand / 'caption_voice.json', cand / 'fit.json')
    argv = ['build_ex.py', '--rom-dir', str(a.rom_dir), '--census', str(a.census), '--vasm', str(a.vasm), '--openings', str(a.openings), '--out', str(a.out)]
    if a.portraits:
        argv += ['--portraits', str(a.portraits)]
    if a.desert_census:
        argv += ['--desert-census', str(a.desert_census)]
    saved_argv = sys.argv
    sys.argv = argv
    try:
        BX.main()
    finally:
        sys.argv = saved_argv
        CP.PACK, CP.VOICE_MANIFEST, CP.FIT = saved
        DR.swap(*old)
    out = Path(a.out)
    bj, bb = (load(out / 'build.json'), load(before / 'build.json'))
    rep['ex_bank'] = {m: dict(used=bj['sets'][m]['ex_bank_bytes_used'], before=bb['sets'][m]['ex_bank_bytes_used'], sha256=file_sha(out / m / 'strex_p6.bin')) for m in ('striderua', 'striderjr')}
    rep['streams_identical'] = all((file_sha(out / 'work' / f"scene_{s['id']}.bin") == file_sha(before / 'work' / f"scene_{s['id']}.bin") for s in bb['scenes']))
    rep['frames_json_identical'] = file_sha(out / 'frames.json') == file_sha(before / 'frames.json')
    rep['captions_identical'] = file_sha(out / 'work' / 'captions.inc') == file_sha(before / 'work' / 'captions.inc')
    (out / 'proto.json').write_text(json.dumps(rep, indent=1) + '\n')
    print(json.dumps({k: rep[k] for k in ('ex_bank', 'streams_identical', 'frames_json_identical', 'captions_identical', 'handlers', 'symbols')}, indent=1))
    return 0

def best_lag(cap, plan, max_lag=3):
    """(share of equal frames, lag g) of cap[i] against plan[i + g] over their overlap, the best g in"""
    best = (None, None)
    for g in range(-max_lag, max_lag + 1):
        i0, i1 = (max(0, -g), min(len(cap), len(plan) - g))
        if i1 - i0 < 10:
            continue
        v = float(np.mean(cap[i0:i1] == plan[i0 + g:i1 + g]))
        if best[0] is None or v > best[0] + 1e-12:
            best = (v, g)
    return best
VOICE_FLAG = {'en': 1, 'ja': 3}
READ_MIN = 0.9
STAGE_OF = {'prologue': 0, 'brief_st_petersburg': 0, 'intro_desert': 5, 'brief_siberia': 1, 'brief_aerial': 3, 'brief_amazon': 2, 'flight': 4, 'welcome_meio': 4}

def reference_crops(a, key, m, sh):
    """{state: RGB crop} of the mouth box as EX draws each state (dub_lipsync.Scene.rgb of a census frame"""
    import dub_lipsync as DL
    sc = DL.render_scene(a.census, a.build, m['scene'], a.work)
    times, states, frames, _, _ = pce_states(a.census, a.build, key, m, shown=sh)
    out = {}
    idx = {f: k for k, f in enumerate(sc.frames)}
    for s in (REST, HALF, OPEN):
        hit = [f for f, x in zip(frames, states) if x == s]
        if hit:
            out[s] = sc.rgb(idx[hit[len(hit) // 2]], m['box']).astype(np.int16)
    return out

def cmd_capture(a):
    """One scene as a build plays it in HBMAME (the USA set with the pack: the English dub, flag 0x01, or with"""
    import shutil
    import subprocess
    from PIL import Image
    import caption_pacing as CP
    import dub_lipsync as DL
    import ex_gate as EG
    build, pack, out = (Path(a.build_dir).resolve(), Path(a.pack).resolve(), Path(a.out).resolve())
    out.mkdir(parents=True, exist_ok=True)
    sid = a.scene
    saved = CP.PACK
    CP.PACK = dict(sha256=file_sha(pack), bytes=pack.stat().st_size, windows=True, note='capture pack')
    try:
        rd = CP.pack_reader(pack)
        cues = {r['id']: r for r in load(CP.CUES)['cinematics']['rows']}
        w0, w1 = cues[sid]['window_s']
        pcm = CP.pack_track(rd, int(cues[sid][a.voice], 16))
    finally:
        CP.PACK = saved
    binary = load(Path(a.runtime) / 'runtime.json')['binary']
    streams = load(build / 'build.json')['sets'][EG.PARENT['striderus01']]['streams']
    work = Path(a.work_runs).resolve() / f'{sid}_{a.label}'
    if work.exists():
        shutil.rmtree(work)
    work.mkdir(parents=True)
    sets = CP.stage_variant(build, 'striderus01', VOICE_FLAG[a.voice], work / 'sets', Path(a.hbmame), Path(a.rom_dir))
    st = STAGE_OF[sid]
    rows, snd, capw = CP.hb_run(binary, sets, 'striderus01', work / 'probe', 5400 if st == 0 else 4200, st)
    sc = next((s for s in CP.scenes_in_run(rows, snd, capw, streams) if s['scene'] == sid))
    f0 = sc['first_frame']
    cue_f = sc['cue'][0]['record'] + f0
    t1 = w1 - w0 + 0.3
    shots = range(cue_f - 2, cue_f + int(t1 * CPS1_HZ) + 3)
    rows, snd, capw = CP.hb_run(binary, sets, 'striderus01', work / 'shots', max(shots) + 5, st, shots)
    cue = next((s for s in snd if s['f'] >= f0 and s['v'] & 255 != 255))
    tim = {r['f']: r['t'] for r in rows}
    got = sorted((int(q.stem[2:]) for q in (work / 'shots').glob('f_*.png')))
    shot_t = {f: tim[f - 1] - cue['t'] + w0 for f in got if f - 1 in tim}
    res = dict(scene=sid, label=a.label, build=str(build), pack_sha256=file_sha(pack), first_active=f0, cue_frame=cue['f'], shots=len(got), portraits=[])
    track = DL.SCENE_TRACK[sid]
    for key, m in mouth_keys():
        if m['scene'] != sid:
            continue
        sh = shown_span(a, m)
        refs = reference_crops(a, key, m, sh)
        y0, y1, x0, x1 = m['box']
        fs = [f for f in got if f in shot_t and sh[0] - 1e-06 <= shot_t[f] < sh[1] - 1e-06]
        states, score = ([], [])

        def unit(x):
            v = x.astype(np.float64).ravel()
            v -= v.mean()
            return v / (np.linalg.norm(v) + 1e-09)
        ref_u = {s_: unit(r) for s_, r in refs.items()}
        for f in fs:
            im = np.asarray(Image.open(work / 'shots' / f'f_{f:05d}.png').convert('RGB')).astype(np.int16)
            cu = unit(im[y0:y1, x0 + 64:x1 + 64])
            c = {s_: float(cu @ r) for s_, r in ref_u.items()}
            s_ = max(c, key=c.get)
            states.append(s_)
            score.append(c[s_])
        read = np.array(score) >= READ_MIN
        times = np.array([shot_t[f] for f in fs])[read]
        cap = np.array(states, np.int8)[read]
        rel, spans = speaker_levels(track, m['lines'], a.voice, times, a.cand if a.voice == 'en' else None)
        mm = measures(times, cap, rel)
        p_t, p_s, _, _, _ = pce_states(a.census, a.build, key, m, shown=sh)
        if a.plan == 'driven':
            rl, _ = speaker_levels(track, m['lines'], a.voice, p_t, a.cand if a.voice == 'en' else None, lead=LEAD_FRAMES)
            p_s = driven_track(rl)
        best = best_lag(np.array(states, np.int8), np.asarray(p_s, np.int8))
        res['portraits'].append(dict(who=m['who'], shown=sh, frames=len(fs), unread=int(np.sum(~read)), worst_match=round(min(score), 4), mean_match=round(float(np.mean(score)), 4), measures=mm, states=''.join((str(s) for s in states)), plan=a.plan, plan_states=''.join((str(int(x)) for x in p_s)), plan_match=round(best[0], 4) if best[0] is not None else None, plan_lag_frames=best[1], first_t=round(float(times[0]), 4) if len(times) else None))
        print(f"   against its plan ({a.plan}): {res['portraits'][-1]['plan_match']} of the pictures equal at a lag of {best[1]} frames; {int(np.sum(~read))} pictures unread", flush=True)
        print(f"{sid} {a.label} {m['who']}: {len(fs)} pictures; mouth read with correlation at least {min(score):.3f} (mean {np.mean(score):.4f}); against the voice ({a.voice}): {mm}", flush=True)
    raw = out / f'{sid}_{a.label}_raw.mp4'
    info = CP.make_clip(work / 'shots', rows, snd, f0, pcm, 0.0, t1, raw, f'{sid} {a.voice} {a.label}')
    clip = out / f'{sid}_{a.label}.mp4'
    subprocess.run(['ffmpeg', '-loglevel', 'error', '-y', '-i', str(raw), '-c:v', 'libx264', '-crf', '24', '-preset', 'slow', '-c:a', 'aac', '-b:a', '160k', '-movflags', '+faststart', str(clip)], check=True)
    raw.unlink()
    res['clip'] = dict(info, path=str(clip), bytes=clip.stat().st_size, sha256=file_sha(clip))
    (out / f'{sid}_{a.label}.json').write_text(json.dumps(res, indent=1) + '\n')
    if not a.keep_shots:
        shutil.rmtree(work)
    print(json.dumps(res['clip']))
    return 0

def self_test():
    seq = [0] * 5 + ([1] * 3 + [2] * 5 + [1] * 3 + [0] * 7) * 4
    cyc = cycles(np.array(seq))
    assert len(cyc) == 4 and loop_period(cyc) == 1, (cyc, loop_period(cyc))
    seq2 = [0] * 3 + ([1] * 3 + [2] * 5 + [1] * 3 + [0] * 5 + [1] * 3 + [2] * 10 + [1] * 3 + [0] * 17) * 3
    assert loop_period(cycles(np.array(seq2))) == 2
    rel = np.array([-200.0] * 10 + [-3.0] * 12 + [-200.0] * 10)
    d = driven_track(rel)
    assert d[0] == REST and d[-1] == REST and (OPEN in d), d
    for x, y in zip(d, d[1:]):
        assert abs(int(x) - int(y)) <= 1, d
    runs = []
    for s in d:
        if runs and runs[-1][0] == s:
            runs[-1][1] += 1
        else:
            runs.append([s, 1])
    assert all((n >= MIN_HOLD[s] for s, n in runs[1:-1])), runs
    loop = cycles(np.array([1] * 3 + [2] * 5 + [1] * 3 + [0] * 7))
    v = np.array([False] * 4 + [True] * 13 + [False] * 10)
    r = retimed_track(loop, v, 3)
    assert list(r[:4]) == [0] * 4 and list(r[4:7]) == [1] * 3 and (r[-1] == REST), r
    t = np.arange(len(v)) * FRAME
    lv = np.where(v, -3.0, -200.0)
    mm = measures(t, np.where(v, 2, 0), lv)
    assert mm['agree'] == 1.0 and mm['open_silent_frames'] == 0, mm
    st = np.array([0] * 10 + [2] * 10 + [0] * 20)
    lv2 = np.where((np.arange(40) >= 14) & (np.arange(40) < 24), -3.0, -200.0)
    b, s = place_bound(t[:40] if len(t) >= 40 else np.arange(40) * FRAME, st, lv2)
    assert b == 1.0 and abs(s + 4 * FRAME) < 0.001, (b, s)
    import tempfile
    import cinematic_lz as LZ
    import cinematic_timing as T
    with tempfile.TemporaryDirectory() as d:
        pa = proto_asm(d)
        core = (pa / 'scene_core.s').read_text()
        assert 'bne     op_sprites_mth' in core and 'bsr     mth_step' in core
        assert 'bsr     mth_start' in (pa / 'ex_bank.s').read_text()
        assert 'MTH_IN  equ $FFF9D0' in (pa / 'subtitles.s').read_text()
    shp = (BLANK,) * SLOT
    one = ((240, 128, 39594, 4353),) + (BLANK,) * (SLOT - 1)
    tr = dict(points=[(3, 1), (7, 0)], hide=[39594, 39596], shapes=[shp, one])
    inc = mouth_inc(['a', 'b'], {'b': tr})
    assert 'dc.l    0\n        dc.l    mt_b' in inc and f'3,{8 * SLOT},7,0,$FFFF' in inc and ('$9AAA,$9AAC,$0000' in inc)
    rec = struct.pack('>HH', 2, 1) + struct.pack('>HHHH', 240, 128, 39594, 4353) + struct.pack('>H', 0)
    stream = b''.join((struct.pack('>H', len(rec)) + rec for _ in range(10))) + struct.pack('>H', 65535)
    lz = LZ.encode(stream)
    plain, withm = (T.predict(stream, lz), predict_mouth(stream, lz, (), (), tr))
    assert len(plain) == len(withm) == 10 and all((b > p for p, b in zip(plain, withm))), (plain, withm)
    assert predict_mouth(stream, lz, (), (), None) == plain
    print('lipsync_study self-test passed')
    return 0

def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--self-test', action='store_true')
    sub = ap.add_subparsers(dest='cmd')
    p = sub.add_parser('mouths')
    p.add_argument('--census', required=True)
    p.add_argument('--build', required=True)
    p.add_argument('--work', required=True)
    p.add_argument('--json')
    p = sub.add_parser('agree')
    p.add_argument('--census', required=True)
    p.add_argument('--build', required=True)
    p.add_argument('--work', required=True)
    p.add_argument('--cand')
    p.add_argument('--json')
    p = sub.add_parser('proto')
    for k in ('census', 'build', 'work', 'cand', 'out', 'rom_dir', 'vasm', 'openings'):
        p.add_argument('--' + k.replace('_', '-'), required=True)
    p.add_argument('--portraits')
    p.add_argument('--desert-census')
    p.add_argument('--scenes', nargs='+', required=True)
    p.add_argument('--kind', choices=('driven', 'retimed'), default='driven')
    p = sub.add_parser('capture')
    for k in ('census', 'build', 'work', 'cand', 'build_dir', 'pack', 'runtime', 'hbmame', 'rom_dir', 'out', 'work_runs', 'scene', 'label'):
        p.add_argument('--' + k.replace('_', '-'), required=True)
    p.add_argument('--keep-shots', action='store_true')
    p.add_argument('--plan', choices=('pce', 'driven'), default='pce')
    p.add_argument('--voice', choices=('en', 'ja'), default='en')
    p = sub.add_parser('model')
    for k in ('census', 'build', 'work', 'cand'):
        p.add_argument('--' + k, required=True)
    p.add_argument('--scenes', nargs='+', required=True)
    p.add_argument('--kind', choices=('driven', 'retimed'), default='driven')
    p.add_argument('--json')
    a = ap.parse_args()
    if a.self_test:
        return self_test()
    if a.cmd == 'mouths':
        return cmd_mouths(a)
    if a.cmd == 'agree':
        return cmd_agree(a)
    if a.cmd == 'proto':
        return cmd_proto(a)
    if a.cmd == 'capture':
        return cmd_capture(a)
    if a.cmd == 'model':
        return cmd_model(a)
    ap.print_help()
    return 2
if __name__ == '__main__':
    sys.exit(main())
