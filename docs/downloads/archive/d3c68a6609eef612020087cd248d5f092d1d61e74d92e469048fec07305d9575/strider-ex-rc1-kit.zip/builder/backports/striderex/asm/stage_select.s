; Strider EX hidden stage select (D14), modeled on the Final Fight CD backport

;
; Code: on the credited screen, hold attack + jump and press START (either
; player's buttons count). Hiryu's claws (0x40) confirm it. The game-start
; routine then shows SELECT STAGE before the stage loads; the pick goes into
; the stage bytes as the arcade's own debug start does, so the stage's EX
; cinematics play as for a normal start (stage 1's prologue and card too).
;

; 2026-10-14: "screenshots of the levels' opening scene before anything
; appears") shows the selected stage's opening scene: its tile layers as they
; first stand fully faded in at the stage's start, with no sprite and no HUD
; (scripts/stage_openings.py: a snapshot of the map cells the picture shows,
; their palettes, the backdrop, the stars where the stage shows them, and the
; scroll and layer registers; stills.inc, build_ex.py). Across the bottom 32

; words sit on top of") holds a caption page "SELECT STAGE" / "n  STAGE NAME"
; (subtitle_ex.py prepare, the arcade 8x8 font, centered in the band). The band
; is a tile layer the still does not use (SCROLL1, else SCROLL2), placed directly
; under the sprites with its own map, scroll and black palette (ss_fill, once),
; so it is the same in every still and nothing shows through it.
;
; Left or up selects the previous stage, right or down the next, wrapping;
; attack, jump or START picks.
; stages fade slightly when you switch between them?"): the shown still dims
; through the stock brightness steps (ss_fade: the level in the top nibble of
; each color), one black frame shows the band and the caption alone, then the
; next still comes up through the same steps, its name with its first frame.
; The band and the caption stay at full brightness throughout. The next still's
; snapshot is written into the other of two map sets while the shown one fades
; (ss_write), so the black is one frame. A press during a switch heads for the
; newest selection from where the fade is (ss_step).
;
; The stage names are the stock stage titles (strings 0x34-0x37); THIRD MOON
; and KYZYLKUM DESERT are new. With the desert (DESERT), it is the second of
; six, in play order: its still is its own opening, computed from its data,
; and its pick starts internal stage 5 as the debug start's stage field 5 does
; (its introduction, then its caption, then play).
;
; Included by ex_bank.s. Two stock sites, both regions: the debug-start check
; at 0x2550 (tst.b -$737A(a5) / beq.w $259C) -> jmp stage_sel, which runs those
; two instructions as stock without the code; the rank routine's start at
; 0x3582 -> jmp rank_check (a stage-select run is not ranked).
;
; While the screen is up the player owns the video (ACTIVE = ON, the game's
; VBlank held, as in a cinematic, with no stream: cine_step only flips the
; sprite lists), so the loop waits on the player's frame tick, sends its sounds
; through the player's cue (sound(), ex_bank.s) and leaves its register and
; palette writes for the next VBlank (ss_vbl, called by ex_vbl's player path).
;

; final 'stage' in the stage select that takes you to the ending so I can review
; it"): a last entry, ENDING, after THIRD MOON. Its pick starts Third Moon's last
; area, Meio's room (internal stage 4, area 10, as the arcade's debug start
; writes it), and fells Meio on the first frame of his fight (ss_meio), so the
; stock clear plays from his death: Game Clear (0x20), Hiryu's leap, the moon's
; explosion, the bonus, the EX staff roll (0x21), Game Over, the title. Its
; still is the ending's last PC Engine picture (the glider over Earth) in the
; roll's window. A release build assembles none of it.

SS_FLAG equ VARS+$24                    ; byte: this game was started from the stage select (no ranking)
    ifd ENDTEST
SS_END  equ VARS+$25                    ; byte: the ENDING entry started this game; ss_meio fells Meio once
SS_ENDING equ $40                       ; ss_stage's value for the ENDING entry (no internal stage)
END_AREA equ 10                         ; Meio's room: Third Moon's last area (the debug start's area field)
    endc
SS_ROW  equ VARS+$26                    ; word: the selected stage in play order, 0 to SS_STAGES-1
SS_PREV equ VARS+$2A                    ; word: last frame's buttons (edge detect)
SSV     equ $FFF990                     ; the stage select's state (free work RAM after CAPVARS)
SS_SHOWN equ SSV+$00                    ; word: the still on screen (ss_vbl sets it at the swap), $FFFF none
SS_LEVEL equ SSV+$02                    ; word: its fade step as last requested, 0 to SS_STEPS (as authored)
SS_SET  equ SSV+$04                     ; word: the map set not on screen, 0 (A) or 1 (B, 0x10000 above A)
SS_WFOR equ SSV+$06                     ; word: the still that set holds or is being written with, $FFFF none
SS_WPTR equ SSV+$08                     ; long: ss_write's next block, 0 = that set complete
SS_PB   equ SSV+$0C                     ; word: the palette buffer to fill next, 0 (0x901000) or 1 (0x902800)
SS_PHASE equ SSV+$0E                    ; word: 1 = the black frame is requested, the swap comes next
SS_REQ  equ SSV+$10                     ; word: for the next VBlank (ss_vbl): bit 0 palette base, bit 1 layer word, bit 2 swap
SS_RPB  equ SSV+$12                     ; word: the palette base
SS_RLW  equ SSV+$14                     ; word: the layer word
SS_RSW  equ SSV+$16                     ; word: the still to swap in
SS_RSET equ SSV+$18                     ; word: its map set
SS_TICK equ SSV+$1A                     ; word: the player's TICK at the last frame (ss_frame)
SS_LATE equ SSV+$1C                     ; word: VBlanks the loop missed (the gates require 0)
SS_PICK equ SSV+$1E                     ; word: frames to the hand-back after a pick, 0 = none
SS_VARS equ $20
SS_HDR  equ 2*(2+3+3+11)                ; a still's record before its blocks (stills.inc, stage_openings.stills_inc)
SS_BUDGET equ 1024                      ; ss_write's words a frame: the snapshot over a few frames of the fade
    ifd DESERT
    ifd ENDTEST
SS_STAGES equ 7                         ; the desert, and the ENDING test entry last
    else
SS_STAGES equ 6                         ; the desert extra stage after St. Petersburg (build_ex.py STILLS)
    endif
    else
    ifd ENDTEST
SS_STAGES equ 6                         ; the ENDING test entry last
    else
SS_STAGES equ 5
    endif
    endif

stage_sel:
        movem.l d0-d3,-(sp)
        move.w  $800000,d0              ; IN1, active low: P1 in the low byte, P2 in the high byte
        not.w   d0
        move.w  d0,d1
        and.w   #$0030,d0               ; P1 attack + jump
        cmp.w   #$0030,d0
        beq.s   .code
        and.w   #$3000,d1               ; P2 attack + jump
        cmp.w   #$3000,d1
        beq.s   .code
        movem.l (sp)+,d0-d3
        sf      SS_FLAG                 ; a normal start
    ifd ENDTEST
        sf      SS_END
    endif
        tst.b   -$737A(a5)              ; the replaced debug check
        beq.s   .skip
        jmp     $2558
.skip:  jmp     $259C
.code:  movem.l (sp)+,d0-d3
        movem.l d0-d7/a0-a6,-(sp)
        st      SS_FLAG
    ifd ENDTEST
        sf      SS_END
    endif
        bsr     ss_screen               ; d0 = the picked internal stage
    ifd ENDTEST
        cmp.w   #SS_ENDING,d0
        beq.s   .end
    endif
        move.b  d0,-$734E(a5)           ; both players' stage, area 0 (set by 0x2538)
        move.b  d0,-$724E(a5)
        movem.l (sp)+,d0-d7/a0-a6
        jmp     $259C
    ifd ENDTEST
; the ENDING entry: Meio's room as the debug start (0x2562-0x2596) writes stage 4,
; area 10: the stage and area bytes (both players', as a pick), the intro task's
; first-entry flag set (0xFF0CBA: no stage intro, no EX cinematic) and its state 6
; (0xFF0CDC: the area's own entry, as after a death there); then ss_meio fells Meio.
.end:   move.b  #4,-$734E(a5)
        move.b  #4,-$724E(a5)
        move.b  #END_AREA,-$7332(a5)
        move.b  #END_AREA,-$7232(a5)
        move.b  #1,-$7346(a5)
        move.b  #6,-$7324(a5)
        st      SS_END
        movem.l (sp)+,d0-d7/a0-a6
        jmp     $259C
    endif

; ss_screen: the select loop. Returns d0 = internal stage (play order 0, 1,
; 3, 2, 4, or 0, 5, 1, 3, 2, 4 with the desert: ss_stage).
ss_screen:
        bsr     hold_black              ; from here the game's VBlank waits (ex_bank.s: black from the next VBlank)
        lea     PALS,a0                 ; keep the game's palettes, as play does
        lea     SAVE,a1
        move.w  #PALS_LONGS-1,d1
.sv:    move.l  (a0)+,(a1)+
        dbra    d1,.sv
        move.w  #$1540,d3               ; black, no sprite slot, until the first still (cine_setup_layer)
        bsr     cine_setup_layer        ; graphics RAM cleared, the player's bases, the caption palette
        bsr     ss_fill                 ; the band's maps and palettes
        lea     SSV,a0                  ; nothing shown; the back set (A) empty
        moveq   #SS_VARS/2-1,d0
.z:     clr.w   (a0)+
        dbra    d0,.z
        move.w  #$FFFF,SS_SHOWN
        move.w  #$FFFF,SS_WFOR
        move.w  TICK,SS_TICK
        clr.w   SS_ROW
        move.w  #$FFFF,SS_PREV          ; the code's buttons are still down: wait for a release
        clr.l   FRAMES
        move.w  #1,ENDED                ; no stream: cine_step flips the sprite lists, ss_vbl does the rest
        move.w  #ON,ACTIVE
        move.w  #$40,CUE                
.loop:  bsr     ss_frame
        tst.w   SS_PICK
        bne.s   .picked
        bsr     ss_buttons              ; d0 = newly pressed: 1 previous, 2 next, 4 pick
        btst    #2,d0
        bne.s   .pick
        and.w   #3,d0
        beq.s   .step
        btst    #0,d0
        beq.s   .nx
        subq.w  #1,SS_ROW
        bpl.s   .mv
        move.w  #SS_STAGES-1,SS_ROW
        bra.s   .mv
.nx:    addq.w  #1,SS_ROW
        cmp.w   #SS_STAGES,SS_ROW
        bcs.s   .mv
        clr.w   SS_ROW
.mv:    move.w  #$3B,CUE                ; the slash sound
        bra.s   .step
.pick:  move.w  #$81,CUE                ; the voice again, then a beat, on black (ss_black)
        move.w  #40,SS_PICK
        bsr     ss_black
        bra     .loop
.picked:
        subq.w  #1,SS_PICK              ; the beat: the screen stays black, nothing steps
        beq.s   .back
        bsr     ss_clear                ; the select's cells off the game's maps, a part a frame
        bra     .loop
.step:  bsr     ss_step
        bra     .loop
.back:  bsr     hold_black              ; hand back as play does, black from a VBlank (the board draws line by line)
        move.w  #OBJ_B>>8,CPSA          ; as play's .end: the base write copies the empty list B (ss_black), so the
                                        ; game's first base write shows nothing (jtcps1 shows a list from the base
                                        ; write after the one that copied it); the game never draws into 0x900800
        lea     SAVE,a0
        lea     PALS,a1
        move.w  #PALS_LONGS-1,d1
.rs:    move.l  (a0)+,(a1)+
        dbra    d1,.rs
        lea     CPSA,a0
        move.w  #$9080,$02(a0)
        move.w  #$90C0,$04(a0)
        move.w  #$9100,$06(a0)
        clr.w   $08(a0)
        clr.w   $20(a0)
        clr.w   CPSB+$28
        clr.w   ACTIVE                  ; the game's VBlank from the next frame
        move.w  SS_ROW,d0
        move.b  ss_stage(pc,d0.w),d0
        ext.w   d0
        rts
    ifd DESERT
    ifd ENDTEST
ss_stage: dc.b  0,5,1,3,2,4,SS_ENDING   ; play order -> internal stage; the ENDING test entry
    else
ss_stage: dc.b  0,5,1,3,2,4             ; play order -> internal stage
    endif
    else
    ifd ENDTEST
ss_stage: dc.b  0,1,3,2,4,SS_ENDING     ; play order -> internal stage; the ENDING test entry
    else
ss_stage: dc.b  0,1,3,2,4               ; play order -> internal stage
    endif
    endif
        even

; ss_black: the pick goes black at once, before the transition (MiSTer kit o,
; 2026-10-23: STAGE_SELECT.md "The pick: black at once"). Kit o kept
; the picked still up for the voice's beat (40 frames) and handed back without
; emptying the sprite lists: the game's VBlank then showed the select's caption
; page in the game's own colors (MEASURED, HBMAME: one frame, 42 frames after the
; pick; on the board the list shows from the base write after the copy). Now the
; next VBlank shows nothing: no layer and no sprite slot (the layer word 0x1540,
; as hold_black), and the backdrop black in the palette copied (the desert's sky
; is its backdrop). Both sprite lists are emptied now (full end entries), so
; every later flip and the hand-back's base write copy an empty list, and the
; screen stays black through the beat and the hand-back. A switch in progress
; stops where it is: the pick is SS_ROW. Clobbers d0-d1, a1, a3.
ss_black:
        lea     OBJ,a3
        bsr     end_a3
        lea     OBJ_B,a3
        bsr     end_a3
        bsr     ss_buf
        clr.w   $17FE(a1)               ; the backdrop pen 0xBFF black
        move.w  #$1540,SS_RLW           ; no layer, no sprite slot
        move.w  #3,SS_REQ               ; the layer word, the palette base, in the next VBlank (ss_vbl)
        rts

; ss_clear: during the pick's beat (SS_PICK 39 down to 28, one part a frame), the
; game's maps (map set A, the bases the hand-back restores: SCROLL1 0x908000,
; SCROLL2 0x90C000, SCROLL3 0x910000) filled with transparent cells: the band's
; own (its maps' first cell, ss_fill; one tile in both halves on SCROLL1) and the
; cinematics' SCROLL3 0x3801 (cine_setup). The game's VBlank, from the hand-back
; until its next scene or its stage draws, shows its layers over those maps: with
; the select's cells left there it showed the still in the game's colors
; (MEASURED, HBMAME, the Siberia, Aerial Battleship and Amazon picks: two
; frames, then a third when cine_hook's hold_black kept the last picture).
; 4 KB a frame (12 parts), so no frame of the loop is late. Clobbers d0-d1, a0-a1.
ss_clear:
        moveq   #39,d0
        sub.w   SS_PICK,d0              ; the part, 0 on the beat's first frame
        cmp.w   #12,d0
        bcc.s   .x
        move.w  d0,d1
        lsr.w   #2,d1
        lsl.w   #3,d1                   ; the layer's entry (8 bytes)
        and.w   #3,d0
        lsl.w   #8,d0
        lsl.w   #4,d0                   ; its 4 KB part of the map
        lea     ss_clrtab(pc),a1
        move.l  0(a1,d1.w),a0
        add.w   d0,a0
        move.l  4(a1,d1.w),a1
        move.l  (a1),d1                 ; the transparent cell (code, attribute)
        move.l  #$1000,d0
        bsr     memfill
.x:     rts
ss_clrtab:
        dc.l    $908000,$924000         ; SCROLL1: the band's SCROLL1 map's first cell
        dc.l    $90C000,$928000         ; SCROLL2: the band's SCROLL2 map's first cell
        dc.l    $910000,ss_s3clr        ; SCROLL3: 0x3801, as cine_setup
ss_s3clr:
        dc.l    $38010000

; ss_step: one frame of the screen's transitions, after ss_frame; its writes to the
; video registers and the palette base are requests for the next VBlank (ss_vbl).
; - The selected still (SS_ROW) is not the one shown: the shown one steps down,
;   one step a frame, while the selected one's snapshot goes into the map set not
;   on screen (ss_write, restarted on a newer selection). At the bottom step, with
;   the snapshot complete, its caption page goes into the sprite list being built
;   (shown two VBlanks on, ex_bank.s obj_flip) and the next VBlank shows the band
;   and the old caption alone (the black frame: the backdrop too); the one after
;   swaps the selected still in at the bottom step, with its page.
; - The selected still is the one shown: it steps up to its authored colors.
; So a press during a switch only moves SS_ROW: the steps head for the newest
; selection from where they are, and a selection back to the still shown brings
; it up again without a black frame. Clobbers everything.
ss_step:
        tst.w   SS_PHASE
        bne     .swap
        move.w  SS_ROW,d0
        cmp.w   SS_SHOWN,d0
        beq     .up
        cmp.w   SS_WFOR,d0              ; the back set holds the selection, or is getting it?
        beq.s   .dn
        bsr     ss_wstart
.dn:    move.w  SS_LEVEL,d1
        beq.s   .bottom
        subq.w  #1,d1
        move.w  d1,SS_LEVEL
        move.w  SS_SHOWN,d0
        bsr     ss_fadereq              ; the shown still a step down, in the next VBlank
        bra     ss_write                ; then a part of the snapshot
.bottom:
        tst.l   SS_WPTR
        bne     ss_write                ; the snapshot is not complete: the bottom step holds
        move.w  SS_WFOR,d0
        bsr     ss_page                 ; its page: copied in the next VBlank, shown from the swap
        move.w  #$1540,d2               ; the black frame: nothing before the first still,
        move.w  SS_SHOWN,d0
        bmi.s   .bl
        bsr     ss_rec
        move.w  2(a0),d2                ; else the band alone (and the sprites: the caption page)
.bl:    bsr     ss_buf
        clr.w   $17FE(a1)               ; the backdrop black (the desert's sky is its backdrop)
        move.w  d2,SS_RLW
        move.w  #3,SS_REQ               ; the layer word, the palette base
        move.w  #1,SS_PHASE
        rts
.swap:  clr.w   SS_PHASE
        move.w  SS_WFOR,d0
        moveq   #0,d1
        bsr     ss_buf
        bsr     ss_fade                 ; the new still at the bottom step
        move.w  SS_WFOR,SS_RSW
        move.w  SS_SET,SS_RSET
        move.w  #5,SS_REQ               ; the swap, the palette base
        move.w  SS_SHOWN,SS_WFOR        ; the set going off screen holds the still going off, complete
        eor.w   #1,SS_SET
        clr.w   SS_LEVEL
        rts
.up:    move.w  SS_LEVEL,d1
        cmp.w   #SS_STEPS,d1
        bcc.s   .out
        addq.w  #1,d1
        move.w  d1,SS_LEVEL
        bsr     ss_fadereq              ; a step up, in the next VBlank
.out:   rts

; ss_frame: wait for the next VBlank (the player's sound tick counts them) and for
; the last request to be applied; SS_LATE counts the VBlanks a frame's work missed.
; Out: d0-d1 clobbered.
ss_frame:
        move.w  SS_TICK,d0
.w:     cmp.w   TICK,d0
        beq.s   .w
.r:     tst.w   SS_REQ                  ; applied by the first VBlank after it was made
        bne.s   .r
        move.w  TICK,d1
        move.w  d1,SS_TICK
        sub.w   d0,d1
        subq.w  #1,d1
        add.w   d1,SS_LATE
        rts

; ss_vbl: the stage select's requests (ss_step), from ex_vbl's player path after
; cine_step's sprite-list flip, in the VBlank after they were made: the swap (the
; still's layer word, its SCROLL1-3 bases in its map set, the scroll, star and
; video control registers, SS_SHOWN), a layer word, then the palette base, whose
; copy holds the board's bus about 12 lines (PHASE0_FINDINGS.md "Cinematics on
; the jtcps1 core"). Clobbers d0, d7, a0-a1.
ss_vbl:
        move.w  SS_REQ,d7
        btst    #2,d7
        beq.s   .lw
        move.w  SS_RSW,d0
        move.w  d0,SS_SHOWN
        bsr     ss_rec
        move.w  (a0),LAYER              ; the picture's layer word
        addq.l  #4,a0                   ; set A's bases
        tst.w   SS_RSET
        beq.s   .a
        addq.l  #6,a0                   ; set B's
.a:     lea     CPSA+$02,a1
        move.w  (a0)+,(a1)+
        move.w  (a0)+,(a1)+
        move.w  (a0)+,(a1)+
        tst.w   SS_RSET
        bne.s   .b
        addq.l  #6,a0
.b:     lea     CPSA+$0C,a1             ; SCROLL1-3 X/Y, the stars' X/Y
        moveq   #10-1,d0
.r:     move.w  (a0)+,(a1)+
        dbra    d0,.r
        move.w  (a0)+,CPSA+$22          ; the video control
.lw:    btst    #1,d7
        beq.s   .pb
        move.w  SS_RLW,LAYER
.pb:    btst    #0,d7
        beq.s   .out
        move.w  SS_RPB,CPSA+$0A         ; the palette copy
.out:   clr.w   SS_REQ
        rts

; ss_rec: a0 = still d0's record (ss_snaps, stills.inc). Clobbers nothing else.
ss_rec: move.w  d0,-(sp)
        lsl.w   #2,d0
        lea     ss_snaps,a0
        move.l  0(a0,d0.w),a0
        move.w  (sp)+,d0
        rts

; ss_buf: a1 = the palette buffer to fill for the next VBlank, its base in SS_RPB.
; The two buffers alternate: the other is the one the last request copied.
ss_buf: tst.w   SS_PB
        bne.s   .b
        lea     $901000,a1
        move.w  #$9010,SS_RPB
        move.w  #1,SS_PB
        rts
.b:     lea     $902800,a1
        move.w  #$9028,SS_RPB
        clr.w   SS_PB
        rts

; ss_fadereq: still d0 at step d1 into the next palette buffer, its copy requested.
ss_fadereq:
        bsr     ss_buf
        bsr     ss_fade
        move.w  #1,SS_REQ
        rts

; ss_fade: still d0's palettes (its record's palette blocks: the colors its cells
; use, the backdrop, the stars' pages where shown) at step d1 into the palette
; buffer a1: each color at its own level or the step's (ss_levels), whichever is
; lower, in the top nibble as the stock fade sets it; step SS_STEPS: as authored.
; The band's and the caption's palettes are not touched. Clobbers d1-d6, a0, a2.
ss_fade:
        bsr     ss_rec
        lea     SS_HDR(a0),a0
        cmp.w   #SS_STEPS,d1
        bcc.s   .copy
        add.w   d1,d1
        lea     ss_levels,a2
        move.w  0(a2,d1.w),d2           ; the step's level (top nibble)
        move.w  d2,d3
        add.w   #$1000,d3               ; colors from this level up are lowered to the step's
        move.w  #$0FFF,d1
.blk:   move.l  (a0)+,d4
        beq.s   .out
        move.w  (a0)+,d5                ; words - 1
        cmp.l   #$904000,d4
        bcc.s   .skip                   ; map cells (ss_write's)
        sub.l   #$901000,d4             ; the offset in a palette buffer
        lea     0(a1,d4.w),a2
.w:     move.w  (a0)+,d6
        cmp.w   d3,d6
        bcs.s   .k
        and.w   d1,d6
        or.w    d2,d6
.k:     move.w  d6,(a2)+
        dbra    d5,.w
        bra.s   .blk
.skip:  addq.w  #1,d5
        add.w   d5,d5
        add.w   d5,a0
        bra.s   .blk
.copy:  move.l  (a0)+,d4
        beq.s   .out
        move.w  (a0)+,d5
        cmp.l   #$904000,d4
        bcc.s   .cskip
        sub.l   #$901000,d4
        lea     0(a1,d4.w),a2
.c:     move.w  (a0)+,(a2)+
        dbra    d5,.c
        bra.s   .copy
.cskip: addq.w  #1,d5
        add.w   d5,d5
        add.w   d5,a0
        bra.s   .copy
.out:   rts

; ss_wstart: start writing still d0's snapshot into the map set not on screen.
ss_wstart:
        move.w  d0,SS_WFOR
        bsr     ss_rec
        lea     SS_HDR(a0),a0
        move.l  a0,SS_WPTR
        rts

; ss_write: part of that snapshot: its map blocks (address in set A, words - 1,
; the cells' code and attribute words), into the set not on screen (set B:
; 0x10000 above A), until SS_BUDGET words are written or the record ends (the
; set complete: SS_WPTR 0). The palette blocks are ss_fade's. Clobbers d0-d2, a0-a1.
ss_write:
        move.l  SS_WPTR,d0
        beq.s   .out
        move.l  d0,a0
        move.w  #SS_BUDGET,d2
.blk:   move.l  (a0)+,d0
        beq.s   .done
        move.w  (a0)+,d1                ; words - 1
        cmp.l   #$904000,d0
        bcs.s   .skip                   ; a palette block
        tst.w   SS_SET
        beq.s   .a
        add.l   #$10000,d0
.a:     move.l  d0,a1
        sub.w   d1,d2
        subq.w  #1,d2
.w:     move.w  (a0)+,(a1)+
        dbra    d1,.w
        tst.w   d2
        bgt.s   .blk
        move.l  a0,SS_WPTR              ; the frame's budget spent: the rest next frame
.out:   rts
.skip:  addq.w  #1,d1
        add.w   d1,d1
        add.w   d1,a0
        bra.s   .blk
.done:  clr.l   SS_WPTR
        rts

; ss_page: still d0's caption page (cap_still_pages, captions.inc) into the sprite
; list being built, with a full end entry (scene_core.s end_a3). Clobbers d0-d1, a0, a3.
ss_page:
        lsl.w   #2,d0
        lea     cap_still_pages,a0
        move.l  0(a0,d0.w),a0
        move.l  OBJ_BACK,a3
        move.w  (a0)+,d1
        bra.s   .t
.c:     move.l  (a0)+,(a3)+             ; x, y, code, attr
        move.l  (a0)+,(a3)+
.t:     dbra    d1,.c
        bsr     end_a3
        move.w  #1,SPR_NEW
        rts

; ss_fill: the band's maps and palettes (ss_fills, stills.inc: address, long
; words - 1, long value; to address 0), once at the screen's entry. Clobbers
; d0-d1, a0-a1.
ss_fill:
        lea     ss_fills,a0
.f:     move.l  (a0)+,d0
        beq.s   .out
        move.l  d0,a1
        move.w  (a0)+,d1
        move.l  (a0)+,d0
.w:     move.l  d0,(a1)+
        dbra    d1,.w
        bra.s   .f
.out:   rts

; ss_buttons: d0 = buttons pressed this frame and not the last (bit 0
; previous: left or up; bit 1 next: right or down; bit 2 pick: attack, jump
; or START), either player.
ss_buttons:
        move.w  $800000,d0
        not.w   d0
        move.w  d0,d1
        lsr.w   #8,d1
        or.w    d1,d0                   ; P1 | P2
        moveq   #0,d1
        move.w  d0,d2
        and.w   #$000A,d2               ; left (bit 1), up (bit 3)
        beq.s   .a
        bset    #0,d1
.a:     move.w  d0,d2
        and.w   #$0005,d2               ; right (bit 0), down (bit 2)
        beq.s   .b
        bset    #1,d1
.b:     and.w   #$0030,d0               ; attack, jump
        beq.s   .c
        bset    #2,d1
.c:     btst    #4,IN0                  ; START1 (active low)
        bne.s   .d
        bset    #2,d1
.d:     btst    #5,IN0                  ; START2
        bne.s   .e
        bset    #2,d1
.e:     move.w  SS_PREV,d0
        move.w  d1,SS_PREV
        not.w   d0
        and.w   d1,d0
        rts

; rank_check: the high-score rank (0x3582: d0 = 11 minus the entries beaten,
; 0x0B = not ranked; both regions) starts here. A stage-select run is never
; ranked, as in Final Fight CD.
rank_check:
        move.w  #$B,d0                  ; the replaced move.w #$B,d0
        tst.b   SS_FLAG
        bne.s   .no
        move.w  #9,d6                   ; the replaced move.w #9,d6
        jmp     $358A
.no:    rts

    ifd ENDTEST
; ss_meio (TEST ONLY): Meio's body, every frame of its state 2 (USA 0x35368, Japan
; 0x350B0: move.b $46(a0),d0 / cmp.b $1E(a0),d0 -> jsr ss_meio, nop; build_ex.py
; MEIO_HOOKS, --test-ending only). $1E counts the hits he has taken, $46 the count
; his hit reaction last saw; 0x18 hits fell him (0x3538A: cmpi.b #$18,$1E(a0) ->
; 0x35834, his death). In a game the ENDING entry started, on the first frame of
; his fight (sub-state $3 = 6, where a player's hits land) the count becomes 0x18,
; once: the stock code then reacts as to the 24th hit and fells him, and the stock
; clear follows (his explosion, game mode 6 at 0x35B64, Game Clear 0x20). The
; replaced instructions' flags survive the rts for the beq after the call.
ss_meio:
        tst.b   SS_END
        beq.s   .x
        cmp.b   #6,3(a0)
        bne.s   .x
        sf      SS_END
        move.b  #$18,$1E(a0)
.x:     move.b  $46(a0),d0
        cmp.b   $1E(a0),d0
        rts
    endif
