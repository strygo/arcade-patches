"""Census of the PC Engine Strider cinematics (Strider EX Phase 0, P0.1)."""
import argparse
import hashlib
import json
import math
import os
import subprocess
import sys
import wave
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path
import numpy as np
from PIL import Image, ImageDraw
sys.path.insert(0, str(Path(__file__).resolve().parent))
import pce_vdc as P
ROOT = Path(__file__).resolve().parents[3]
MANIFEST = ROOT / 'backports/striderex/manifests/pce_cinematics.json'
CAPTURE = ROOT / 'backports/striderex/scripts/run_pce_scene_capture.py'
CHECK = ROOT / 'backports/striderex/scripts/pce_vdc.py'
CUT_FRACTION = 0.4
MIN_SHOT_SECONDS = 0.5
LIT_LUMA = 24
BLANK_LIT_SHARE = 0.002
TAIL_SECONDS = 0.25
RNG = np.random.default_rng(20261009)
W64 = RNG.integers(1, 2 ** 63, 64, dtype=np.uint64) | np.uint64(1)
W256 = RNG.integers(1, 2 ** 63, 256, dtype=np.uint64) | np.uint64(1)

def manifest():
    return json.loads(MANIFEST.read_text())

def capture_cmd(c, a, m):
    cmd = [sys.executable, str(CAPTURE), '--cdrom', str(a.cue), '--rompath', str(a.rompath), '--outdir', str(a.workdir / c['run']), '--window', c['window'], '--end', str(c['end']), '--schedule', c.get('schedule', m['new_game_schedule']), '--timeout-seconds', '1800']
    if 'pce_start_stage' in c:
        cmd += ['--pce-start-stage', str(c['pce_start_stage'])]
    if 'pce_phase' in c:
        cmd += ['--pce-phase', c['pce_phase']]
    return cmd

def run_all(cmds, jobs):
    procs, codes = ([], {})
    pending = list(cmds.items())
    while pending or procs:
        while pending and len(procs) < jobs:
            name, cmd = pending.pop(0)
            procs.append((name, subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)))
        name, proc = procs.pop(0)
        out, _ = proc.communicate()
        codes[name] = proc.returncode
        print(f"{name}: exit {proc.returncode}: {(out.strip().splitlines()[-1] if out.strip() else '')}")
    return codes

def cmd_capture(a, m):
    for c in m['captures']:
        if (a.workdir / c['run'] / 'run.log').exists():
            sys.exit(f"{a.workdir / c['run']} already exists; use a fresh --workdir")
    codes = run_all({c['run']: capture_cmd(c, a, m) for c in m['captures']}, a.jobs)
    return 1 if any(codes.values()) else 0

def cmd_check(a, m):
    cmds = {c['run']: [sys.executable, str(CHECK), 'check', str(a.workdir / c['run']), '--output', str(a.workdir / c['run'] / 'check.json')] for c in m['captures']}
    codes = run_all(cmds, a.jobs)
    return 1 if any(codes.values()) else 0

def cue_durations(cue):
    """Seconds from INDEX 01 to the end of each track's file, by track number."""
    tracks, cur = ({}, None)
    for line in Path(cue).read_text().splitlines():
        w = line.split()
        if not w:
            continue
        if w[0] == 'FILE':
            name = line.split('"')[1]
            size = (Path(cue).parent / name).stat().st_size
        elif w[0] == 'TRACK':
            cur = int(w[1])
            tracks[cur] = dict(sectors=size // 2352, type=w[2])
        elif w[0] == 'INDEX' and w[1] == '01':
            mm, ss, ff = map(int, w[2].split(':'))
            tracks[cur]['index01'] = (mm * 60 + ss) * 75 + ff
    return {t: (v['sectors'] - v.get('index01', 0)) / 75 for t, v in tracks.items() if v['type'] == 'AUDIO'}

def cd_requests(run_dir):
    """(frame, time, start_track) for each BIOS CD_PLAY parameter set the base probe logged."""
    out = []
    for line in (run_dir / 'pce_trace.tsv').read_text().splitlines()[1:]:
        f = line.split('\t')
        if f[0] == 'pce_write' and f[2].startswith('1f00fc='):
            regs = dict((kv.split('=') for kv in f[2].split(',') if '=' in kv))
            out.append((int(f[1]), float(f[7]), int(regs['ram0f8'], 10)))
    return out

def audio_onset(run_dir, after, threshold=256):
    with wave.open(str(run_dir / 'audio.wav')) as w:
        rate, ch = (w.getframerate(), w.getnchannels())
        w.setpos(min(int(after * rate), w.getnframes()))
        data = np.frombuffer(w.readframes(rate * 5), '<i2').reshape(-1, ch)
    hit = np.where(np.abs(data).max(1) > threshold)[0]
    return None if not len(hit) else after + hit[0] / rate

def read_index(run_dir):
    rows = {}
    lines = (run_dir / 'pce_scene_index.tsv').read_text().splitlines()
    head = lines[0].split('\t')
    for line in lines[1:]:
        r = dict(zip(head, line.split('\t')))
        rows[int(r['frame'])] = r
    return rows

def cell_keys(d, g):
    """Per BAT cell content key (0 = empty tile), shape (map_h, map_w)."""
    vram = d['vram']
    tiles = P.all_bg_tiles(vram).reshape(2048, 64)
    tk = (tiles.astype(np.uint64) * W64).sum(1)
    tk[tiles.max(1) == 0] = 0
    bat = vram[:g['map_h'] * g['map_w']].reshape(g['map_h'], g['map_w'])
    keys = tk[bat & 2047]
    pal = (bat >> 12 & 15).astype(np.uint64)
    return (np.where(keys != 0, keys * np.uint64(31) + pal + np.uint64(1), np.uint64(0)), bat)

def visible_mask(d, g, writes):
    """Background map pixels shown on screen (per-line scroll; BG-enabled lines), (map_h*8, map_w*8)."""
    mh, mw = (g['map_h'] * 8, g['map_w'] * 8)
    m = np.zeros((mh, mw), bool)
    lr = P.line_registers(d, writes)
    k0 = max(0, P.SHOT_RASTER - P.display_raster(d))
    k1 = min(g['height'], k0 + 224)
    for k in range(k0, k1):
        if lr[k, 2] & 128:
            m[lr[k, 1] % mh, (lr[k, 0] + np.arange(g['width'])) % mw] = True
    return m

def scaled_blocks(img, mask):
    """Keys of distinct non-empty 16x16 blocks of img after nearest 1.5x horizontal scaling."""
    h, w = img.shape
    sw = int(w * 1.5)
    src = (np.arange(sw) / 1.5).astype(int)
    s, sm = (img[:, src], mask[:, src])
    ph, pw = (-h % 16, -sw % 16)
    s = np.pad(s, ((0, ph), (0, pw)))
    sm = np.pad(sm, ((0, ph), (0, pw)))
    nb_y, nb_x = (s.shape[0] // 16, s.shape[1] // 16)
    blocks = s.reshape(nb_y, 16, nb_x, 16).transpose(0, 2, 1, 3).reshape(-1, 256)
    vis = sm.reshape(nb_y, 16, nb_x, 16).transpose(0, 2, 1, 3).reshape(-1, 256).any(1)
    keep = vis & (blocks.max(1) > 0)
    return set((blocks[keep].astype(np.uint64) * W256).sum(1).tolist())

def wrap_delta(b, a, size):
    return (b - a + size // 2) % size - size // 2

def changed_share(prev, cur, dx, dy):
    """Share of drawn pixels that differ once cur is aligned to prev by the BG scroll (dx, dy)."""
    h, w = cur.shape
    if abs(dx) >= w or abs(dy) >= h:
        return 1.0
    a = prev[max(dy, 0):h + min(dy, 0), max(dx, 0):w + min(dx, 0)]
    b = cur[max(-dy, 0):h + min(-dy, 0), max(-dx, 0):w + min(-dx, 0)]
    drawn = (a != 0) | (b != 0)
    n = int(drawn.sum())
    return 0.0 if n == 0 else int(((a != b) & drawn).sum()) / n

def analyse(job):
    """Catalog one cinematic (runs in a worker process)."""
    cine, run_dir, frames, req_time, out_dir = job
    run_dir, out_dir = (Path(run_dir), Path(out_dir))
    check = {r['frame']: r for r in json.loads((run_dir / 'check.json').read_text())['frames']}
    writes = P.read_writes(run_dir)
    rows, bg_blocks, spr_objs, spr_cells, tiles8 = ([], set(), {}, set(), set())
    state_key, state_mask, state_d = (None, None, None)

    def flush_state():
        if state_d is not None and state_mask is not None and state_mask.any():
            bg_blocks.update(scaled_blocks(P.render_bg_map(state_d), state_mask))
    prev = None
    for fr in frames:
        d = P.load(run_dir / f'pce_{fr:05d}_scene.vdc')
        g = P.geometry(d)
        wr = writes.get(fr, [])
        idx = P.screen_image(d, writes=wr)
        rgb = P.pal_rgb(d['pal'])[idx]
        lum = 0.299 * rgb[..., 0] + 0.587 * rgb[..., 1] + 0.114 * rgb[..., 2]
        luma = float(lum.mean())
        blank = float((lum > LIT_LUMA).mean()) < BLANK_LIT_SHARE
        bg_on, spr_on = (bool(g['cr'] & 128), bool(g['cr'] & 64))
        row = dict(frame=fr, t=None, luma=round(luma, 2), blank=blank, colors=int(len(np.unique(idx))), bxr=g['bxr'], byr=g['byr'], bg=bg_on, spr=spr_on, status=check.get(fr, {}).get('status', 'unchecked'))
        keys, bat = cell_keys(d, g) if bg_on else (None, None)
        vis = visible_mask(d, g, wr) if bg_on else None
        if bg_on:
            vcells = vis.reshape(g['map_h'], 8, g['map_w'], 8).any((1, 3))
            used = vcells & (keys != 0)
            tiles8.update(keys[used].tolist())
            row['bg_palettes'] = sorted({int(p) for p in (bat[used] >> 12 & 15).tolist()})
            skey = hashlib.blake2b(d['vram'].astype('<u2').tobytes() + bytes([g['map_w'] // 32, g['map_h'] // 32]), digest_size=16).hexdigest()
            if skey != state_key:
                flush_state()
                state_key, state_mask, state_d = (skey, np.zeros_like(vis), d)
            state_mask |= vis
        objs = P.sprite_objects(d) if spr_on else []
        spals = set()
        for i, top, left, img, attr in objs:
            if not img.any():
                continue
            k = hashlib.blake2b(img.astype(np.uint8).tobytes() + bytes([attr & 15, img.shape[1]]), digest_size=12).hexdigest()
            spr_objs[k] = img.shape
            spals.add(attr & 15)
            for cy in range(0, img.shape[0], 16):
                for cx in range(0, img.shape[1], 16):
                    c = img[cy:cy + 16, cx:cx + 16]
                    if c.any():
                        spr_cells.add(hashlib.blake2b(c.astype(np.uint8).tobytes(), digest_size=12).hexdigest())
        row['sprites'] = len(objs)
        row['spr_palettes'] = sorted(spals)
        cut, share = (False, 0.0)
        cur_idx = idx
        if prev is not None:
            pidx, pbxr, pbyr, pblank = prev
            if blank != pblank:
                cut = True
            elif not blank:
                share = min(changed_share(pidx, cur_idx, wrap_delta(g['bxr'], pbxr, 1024), wrap_delta(g['byr'], pbyr, 512)), changed_share(pidx, cur_idx, 0, 0))
                cut = share > CUT_FRACTION
        prev = (cur_idx, g['bxr'], g['byr'], blank)
        row['cut'], row['changed_share'] = (cut, round(share, 3))
        rows.append(row)
    flush_state()
    idx_rows = read_index(run_dir)
    for r in rows:
        r['t'] = round(float(idx_rows[r['frame']]['time']) - req_time, 3)
    shots, cur = ([], None)
    for r in rows:
        if r['blank']:
            if cur:
                shots.append(cur)
                cur = None
            continue
        if cur is None or r['cut']:
            if cur:
                shots.append(cur)
            cur = [r]
        else:
            cur.append(r)
    if cur:
        shots.append(cur)
    merged = []
    for sh in shots:
        short = sh[-1]['t'] - sh[0]['t'] < MIN_SHOT_SECONDS
        contiguous = merged and sh[0]['frame'] - merged[-1][-1]['frame'] <= 2
        if short and contiguous:
            merged[-1].extend(sh)
        else:
            merged.append(sh)
    shots = merged
    shot_rows = []
    out_dir.mkdir(parents=True, exist_ok=True)
    for n, s in enumerate(shots):
        best = max(s, key=lambda r: (r['colors'], r['status'] == 'exact', -abs(r['frame'] - s[len(s) // 2]['frame'])))
        png = run_dir / f"pce_{best['frame']:05d}_scene.png"
        native, _ = P.native(png, 256)
        rep = out_dir / f"{cine['id']}_s{n:02d}.png"
        Image.fromarray(native[:224]).save(rep)
        dx = sum((abs(wrap_delta(b['bxr'], a['bxr'], 1024)) for a, b in zip(s, s[1:])))
        dy = sum((abs(wrap_delta(b['byr'], a['byr'], 512)) for a, b in zip(s, s[1:])))
        lum = [r['luma'] for r in s]
        shot_rows.append(dict(shot=n, start_t=s[0]['t'], end_t=s[-1]['t'], frames=len(s), first_frame=s[0]['frame'], representative_frame=best['frame'], representative=rep.name, pan_x_pixels=dx, pan_y_pixels=dy, fade_in=lum[0] < 0.5 * max(lum), fade_out=lum[-1] < 0.5 * max(lum), max_sprites=max((r['sprites'] for r in s)), bg_palettes=sorted(set().union(*[r.get('bg_palettes', []) for r in s])), spr_palettes=sorted(set().union(*[r['spr_palettes'] for r in s])), torn=sum((1 for r in s if r['status'] == 'torn'))))
    sheet_cols = 4
    nrows = max(1, math.ceil(len(shot_rows) / sheet_cols))
    sheet = Image.new('RGB', (sheet_cols * 264, nrows * 246), 'black')
    draw = ImageDraw.Draw(sheet)
    for k, sr in enumerate(shot_rows):
        x, y = (k % sheet_cols * 264, k // sheet_cols * 246)
        sheet.paste(Image.open(out_dir / sr['representative']), (x + 4, y + 18))
        draw.text((x + 4, y + 3), f"{cine['id']} s{sr['shot']:02d}  {sr['start_t']:.1f}-{sr['end_t']:.1f}s", fill='yellow')
    sheet.save(out_dir / f"{cine['id']}_sheet.png")
    spr_tiles = sum((math.ceil(w * 1.5 / 16) * math.ceil(h / 16) for h, w in spr_objs.values()))
    return dict(id=cine['id'], frames=len(rows), torn=sum((1 for r in rows if r['status'] == 'torn')), failing=sum((1 for r in rows if r['status'] == 'fail')), shots=shot_rows, max_bg_palettes=max((len(r.get('bg_palettes', [])) for r in rows), default=0), max_spr_palettes=max((len(r['spr_palettes']) for r in rows), default=0), bg_tiles8=len(tiles8), bg_blocks_1p5=len(bg_blocks), sprite_objects=len(spr_objs), sprite_cells16=len(spr_cells), sprite_tiles_1p5=spr_tiles, _bg_block_keys=sorted(bg_blocks), _tile8_keys=sorted(tiles8), _spr_keys=sorted(spr_objs), _spr_shapes={k: list(v) for k, v in spr_objs.items()})

def cmd_catalog(a, m):
    durations = cue_durations(a.cue)
    out = a.workdir / 'catalog'
    out.mkdir(parents=True, exist_ok=True)
    jobs, meta = ([], {})
    for cine in m['cinematics']:
        run_dir = a.workdir / cine['run']
        reqs = cd_requests(run_dir)
        mine = [r for r in reqs if r[2] == cine['track']]
        if not mine:
            sys.exit(f"{cine['id']}: no CD_PLAY for track {cine['track']} in {run_dir}")
        fr0, t0, _ = mine[-1]
        later = [r[1] for r in reqs if r[1] > t0]
        t_end = min([t0 + durations[cine['track']] + TAIL_SECONDS] + later)
        idx = read_index(run_dir)
        frames = sorted((f for f, r in idx.items() if t0 <= float(r['time']) <= t_end))
        onset = audio_onset(run_dir, t0)
        meta[cine['id']] = dict(track=cine['track'], role=cine['role'], run=cine['run'], cd_request_frame=fr0, cd_request_time=round(t0, 6), track_seconds=round(durations[cine['track']], 3), audio_onset_after_request=None if onset is None else round(onset - t0, 3), captured_until_t=round(float(idx[frames[-1]]['time']) - t0 if frames else 0, 3), capture_step=int(next((c for c in m['captures'] if c['run'] == cine['run']))['window'].split(':')[2]))
        jobs.append((cine, str(run_dir), frames, t0, str(out)))
    with ProcessPoolExecutor(max_workers=a.jobs) as ex:
        results = list(ex.map(analyse, jobs))
    all_bg, all_t8, all_spr, shapes = (set(), set(), set(), {})
    cines = []
    for res in results:
        all_bg.update(res.pop('_bg_block_keys'))
        all_t8.update(res.pop('_tile8_keys'))
        all_spr.update(res.pop('_spr_keys'))
        shapes.update(res.pop('_spr_shapes'))
        cines.append(dict(meta[res['id']], **res))
    spr_tiles = sum((math.ceil(w * 1.5 / 16) * math.ceil(h / 16) for h, w in (shapes[k] for k in all_spr)))
    total = dict(cinematics=len(cines), shots=sum((len(c['shots']) for c in cines)), frames=sum((c['frames'] for c in cines)), torn=sum((c['torn'] for c in cines)), failing=sum((c['failing'] for c in cines)), bg_tiles8=len(all_t8), bg_blocks_1p5=len(all_bg), sprite_objects=len(all_spr), sprite_tiles_1p5=spr_tiles, cps1_tiles_estimate=len(all_bg) + spr_tiles, cps1_bytes_estimate=(len(all_bg) + spr_tiles) * 128)
    catalog = dict(manifest_sha256=hashlib.sha256(MANIFEST.read_bytes()).hexdigest(), method=dict(cut_fraction=CUT_FRACTION, min_shot_seconds=MIN_SHOT_SECONDS, lit_luma=LIT_LUMA, blank_lit_share=BLANK_LIT_SHARE, budget='nearest 1.5x horizontal; distinct non-empty 16x16 map-grid blocks; sprites ceil(1.5w/16)*ceil(h/16) per distinct object'), totals=total, cinematics=cines)
    (out / 'catalog.json').write_text(json.dumps(catalog, indent=1) + '\n')
    for c in cines:
        print(f"{c['id']:22} tr{c['track']} req f{c['cd_request_frame']} lat {c['audio_onset_after_request']}s {c['track_seconds']:6.1f}s frames {c['frames']:5d} shots {len(c['shots']):3d} torn {c['torn']:4d} bg8 {c['bg_tiles8']:5d} bg16@1.5 {c['bg_blocks_1p5']:5d} spr {c['sprite_objects']:4d}/{c['sprite_tiles_1p5']:5d}t pal bg{c['max_bg_palettes']} spr{c['max_spr_palettes']}")
    print(json.dumps(total))
    return 1 if total['failing'] else 0

def self_test():
    img = np.zeros((32, 32), np.int32)
    img[0:8, 0:8] = 5
    mask = np.ones_like(img, bool)
    blocks = scaled_blocks(img, mask)
    assert len(blocks) == 1, blocks
    img[0:8, 32:40] = 5
    assert len(scaled_blocks(img, mask)) == 1
    img[0:8, 16:24] = 5
    assert len(scaled_blocks(img, mask)) == 3
    assert wrap_delta(2, 1020, 1024) == 6 and wrap_delta(1020, 2, 1024) == -6
    a = np.zeros((10, 20), np.int32)
    a[2:5, 4:8] = 7
    b = np.roll(a, -3, axis=1)
    assert changed_share(a, b, 3, 0) == 0.0 and changed_share(a, b, 0, 0) > 0.4
    assert changed_share(a, np.where(a, 9, 0), 0, 0) == 1.0
    print('pce_cinematic_census self-test: ok')
    return 0

def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('command', nargs='?', choices=['capture', 'check', 'catalog', 'all'])
    p.add_argument('--workdir', type=Path)
    p.add_argument('--cue', type=Path, help='restored disc cue sheet (tracks beside it)')
    p.add_argument('--rompath', type=Path, help='rompath with pce/acardpro/<Super System Card image>')
    p.add_argument('--jobs', type=int, default=8)
    p.add_argument('--self-test', action='store_true')
    a = p.parse_args()
    if a.self_test:
        return self_test()
    if not a.command or not a.workdir:
        p.error('command and --workdir are required')
    if a.command in ('capture', 'all') and (not (a.cue and a.rompath)):
        p.error('capture needs --cue and --rompath')
    if a.command == 'catalog' and (not a.cue):
        p.error('catalog needs --cue (track lengths)')
    a.workdir = a.workdir.resolve()
    m = manifest()
    steps = {'capture': [cmd_capture], 'check': [cmd_check], 'catalog': [cmd_catalog], 'all': [cmd_capture, cmd_check, cmd_catalog]}[a.command]
    for step in steps:
        code = step(a, m)
        if code:
            return code
    return 0
if __name__ == '__main__':
    sys.exit(main())
