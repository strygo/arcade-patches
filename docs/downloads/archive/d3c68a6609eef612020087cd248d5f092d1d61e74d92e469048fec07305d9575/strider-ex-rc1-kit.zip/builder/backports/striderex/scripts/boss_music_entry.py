"""Defer early desert/Siberia music changes until first dialogue returns."""
import argparse
from copy import deepcopy
import json
from pathlib import Path
import subprocess
from asm_payload import command as assembly_command
import sys
from boss_voice_gate import inventory, sha
import respawn_fix as R
BASE = 2055168
ASM = Path(__file__).resolve().parents[1] / 'asm/boss_music_entry.s'
SIB_ASM = ASM.with_name('boss_music_siberia.s')
PREFIX = bytes.fromhex('b07900fff936670a33c000fff9364ef8')
LINKED_PREFIX = bytes.fromhex('b07900fff936670833c000fff93660024e75')
LINKED_BODY = bytes.fromhex('0c79000100fff93267160c79000400fff93266160839000700fff9e86710600a0839000600fff9e867044ef8')

def model(bank):
    if bank.count(PREFIX) == 0 and bank.count(LINKED_PREFIX) == 1:
        at = bank.index(LINKED_PREFIX)
        body = at + len(LINKED_PREFIX)
        end = body + len(LINKED_BODY)
        if bank[body:end] != LINKED_BODY or bank[end + 2:end + 4] != b'Nu':
            raise ValueError('linked desert music deferral differs')
        return dict(hook=1048576 + at + 8, queue=int.from_bytes(bank[end:end + 2], 'big'), linked=True)
    if bank.count(PREFIX) != 1:
        raise ValueError('unique native desert music setter required')
    at = bank.index(PREFIX)
    if bank[at + 18:at + 20] != b'Nu':
        raise ValueError('native desert music return differs')
    return dict(hook=1048576 + at + 8, queue=int.from_bytes(bank[at + 16:at + 18], 'big'))

def siberia_model(image):
    before = bytes.fromhex('0c2d000890c56700000c')
    found = [a for a in range(57344, 65536, 2) if image[a - 10:a] == before and image[a:a + 2] == b'N\xb8' and (image[a + 4:a + 10] == bytes.fromhex('1b7c000890c5'))]
    if len(found) != 1:
        raise ValueError('unique native Siberia Long Dash setter required')
    at = found[0]
    setter = int.from_bytes(image[at + 2:at + 4], 'big')
    if image[setter:setter + 4] != bytes.fromhex('4a2d0b94') or image[setter + 8:setter + 12] != bytes.fromhex('303c0008'):
        raise ValueError('native Long Dash cue differs')
    return dict(address=at, setter=setter)

def patch(image, raw, helper):
    bank = bytearray((raw[i ^ 1] for i in range(len(raw))))
    m = model(bank)
    off = BASE - 1048576
    sib = siberia_model(image)
    image = bytearray(image)
    if not helper or len(helper) > 256 or bank[off:off + len(helper)] != b'\xff' * len(helper):
        raise ValueError('boss music allocation occupied or oversized')
    if any((helper[a:a + 2] != b'N\xf9' for a in (0, 6))):
        raise ValueError('music helper entry slots differ')
    at = m['hook'] - 1048576
    before = bank[at:at + 6].hex()
    if not m.get('linked'):
        bank[at:at + 6] = b'N\xf9' + BASE.to_bytes(4, 'big')
    bank[off:off + len(helper)] = helper
    sat = sib['address']
    s_before = image[sat:sat + 10].hex()
    image[sat:sat + 10] = R.jsr(BASE + 6) + R.NOP * 2
    return (bytes(image), bytes((bank[i ^ 1] for i in range(len(bank)))), dict(address=m['hook'], before=before, after=bank[at:at + 6].hex(), helper_at=BASE, helper_bytes=len(helper), helper_sha256=sha(helper), deferred_sections=[1, 4], retry_music_preserved=True, siberia=dict(address=sat, before=s_before, after=image[sat:sat + 10].hex(), cue=8, seen_bit=2), **{'source_linked_desert': True} if m.get('linked') else {}))

def audit(control, build):
    cm, old = inventory(control)
    meta, new = inventory(build)
    for machine, files in old.items():
        spec = meta['sets'][machine]['boss_music_entry']
        p = new[machine]['strex_p6.bin']
        bank = bytes((p[i ^ 1] for i in range(len(p))))
        off = BASE - 1048576
        helper = bank[off:off + spec['helper_bytes']]
        image, changed, report = patch(R.compose(files, R.SETS[machine]), files['strex_p6.bin'], helper)
        expected = dict(files, **R.decompose(image, R.SETS[machine], {n: len(files[n]) for n, _, _ in R.SETS[machine]}))
        expected['strex_p6.bin'] = changed
        if expected != new[machine] or any((spec[k] != v for k, v in report.items())):
            raise ValueError('unexpected boss music ROM changes')
        if spec['source_files'] != cm['sets'][machine]['files']:
            raise ValueError('boss music source differs')
    return meta

def main():
    if sys.argv[1:] == ['--self-test']:
        good = PREFIX + bytes.fromhex('496e4e75')
        assert model(good) == dict(hook=1048584, queue=18798)
        linked = LINKED_PREFIX + LINKED_BODY + bytes.fromhex('496e4e75')
        assert model(linked) == dict(hook=1048584, queue=18798, linked=True)
        for index in (6, len(LINKED_PREFIX), len(linked) - 1):
            damaged = bytearray(linked)
            damaged[index] ^= 1
            try:
                model(damaged)
            except ValueError:
                pass
            else:
                raise AssertionError('foreign linked music setter accepted')
        for invalid in (b'', b'\xff' * 1048576, good + good, good[:6] + b'g\x0c' + good[8:]):
            try:
                model(invalid)
            except ValueError:
                pass
            else:
                raise AssertionError('foreign music setter accepted')
        print('Boss music entry guards PASS')
        return
    p = argparse.ArgumentParser(description=__doc__)
    for n in ('build', 'vasm', 'out'):
        p.add_argument('--' + n, type=Path, required=True)
    a = p.parse_args()
    meta, files = inventory(a.build)
    rep = deepcopy(meta)
    a.out.mkdir(parents=True, exist_ok=False)
    for machine, f in files.items():
        p6 = f['strex_p6.bin']
        bank = bytes((p6[i ^ 1] for i in range(len(p6))))
        m = model(bank)
        image = R.compose(f, R.SETS[machine])
        sib = siberia_model(image)
        src = a.out / (machine + '.s')
        src.write_text(f"DZ_SEC equ $FFF932\nBS_DONE equ $FFF9E8\nDZ_SOUND equ ${m['queue']:X}\nSIB_SETTER equ ${sib['setter']:X}\n org ${BASE:X}\n dc.w $4EF9\n dc.l bm_desert_entry\n dc.w $4EF9\n dc.l bm_siberia_entry\nbm_desert_entry:\n move.w d0,$FFF936\n" + ASM.read_text() + '\n' + SIB_ASM.read_text())
        binary = src.with_suffix('.bin')
        subprocess.run([*assembly_command(a.vasm), '-Fbin', '-m68000', '-quiet', '-o', str(binary), str(src)], check=True)
        image, changed, report = patch(image, p6, binary.read_bytes())
        f = dict(f, **R.decompose(image, R.SETS[machine], {n: len(f[n]) for n, _, _ in R.SETS[machine]}))
        f['strex_p6.bin'] = changed
        dest = a.out / machine
        dest.mkdir()
        for n, b in f.items():
            (dest / n).write_bytes(b)
        rep['sets'][machine]['boss_music_entry'] = dict(report, source_files=meta['sets'][machine]['files'])
        rep['sets'][machine]['files'] = {n: sha(b) for n, b in f.items()}
    (a.out / 'build.json').write_text(json.dumps(rep, indent=2) + '\n')
    audit(a.build, a.out)
    print('Desert/Siberia entry music deferred; native dialogue and fade clocks preserved')
if __name__ == '__main__':
    main()
