; Called once when a regular clear screen installs its native hold timer.
; Preserve every register. The following native render call replaces CCR.
        org $1F4C00
        move.w #200,-$73E6(a5)
        btst #0,$1FFFFF
        beq.s .native
        move.w #580,-$73E6(a5)
.native:
        rts
