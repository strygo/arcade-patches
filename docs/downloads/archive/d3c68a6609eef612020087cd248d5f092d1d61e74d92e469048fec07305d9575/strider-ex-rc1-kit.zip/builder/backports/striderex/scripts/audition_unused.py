"""Render unused/non-arcade Strider music for listening, without changing an EX build."""
from __future__ import annotations
import argparse
import json
import shutil
import subprocess
from pathlib import Path
import nopack_intros as NI
import restore_tunes as RT
import sfx_gate as SG
import ending_ex as EE
TRACKS = [('bullet-corridor', 'Bullet Corridor (arcade; normally replaced after two frames)', 3, None), ('echo', 'Echo (arcade; never requested by the game)', 23, None), ('arcade-ranking-control', 'Ranking (arcade; used, comparison only)', 34, None), ('x68000-amazon-intro', 'Alternate Amazon intro (X68000; absent from arcade)', 36, 19), ('x68000-game-clear', 'Alternate Game Clear (X68000; absent from arcade)', 37, 32), ('x68000-ranking', 'Ranking (X68000 version; comparison with arcade)', 38, 34), ('x68000-time-over', 'Time Over (X68000; absent from arcade)', 39, 35), ('restored-aerial-intro', 'Aerial intro (X68000; already restored in EX)', 30, None), ('restored-ending', 'Ending (X68000; already restored and looped in EX)', 33, None)]
SLOT = 110.0

def classify(notes):
    loop = NI.find_loop(notes)
    if loop and notes[-1][0] < SLOT - loop[1] - 1.0:
        loop = None
    return loop

def prepare(sound, bank):
    at, count = RT.arcade_table(sound)
    ptrs = RT.table_ptrs(sound, at, count)
    xat, xn = RT.x68k_table(bank)
    xptrs = RT.table_ptrs(bank, xat, xn)
    restored, restoration = RT.build_patch(sound, bank)
    restored, ending = EE.loop_song(restored)
    patched = bytearray(restored)
    where = int(ending['loop_at'], 16) + ending['loop_size'] + 15 & ~15
    report = []
    allowed = set()
    for slug, label, command, source in TRACKS:
        if source is None:
            continue
        if ptrs[command] != ptrs[0]:
            raise RT.RestoreError(f'{command:#04x} is not an unused alias slot')
        start, end = RT.song_bounds(xptrs, source, len(bank))
        if source == 35:
            _, covered = RT.song_walk(bank, start, end)
            end = max(covered) + 1
        data, fields = RT.relocate(bank, start, end, where)
        for instrument in fields['instruments']:
            a = RT.INSTR_ARCADE + RT.INSTR_SIZE * instrument
            x = RT.INSTR_X68K + RT.INSTR_SIZE * instrument
            if sound[a:a + RT.INSTR_SIZE] != bank[x:x + RT.INSTR_SIZE]:
                raise RT.RestoreError(f'{slug}: instrument {instrument:#04x} differs')
        if where + len(data) > 32512 or any((v not in (0, 255) for v in patched[where:where + len(data)])):
            raise RT.RestoreError('audition songs do not fit in erased ROM below the EX effects table')
        patched[where:where + len(data)] = data
        patched[at + 2 * command:at + 2 * command + 2] = where.to_bytes(2, 'little')
        allowed.update(range(where, where + len(data)))
        allowed.update((at + 2 * command, at + 2 * command + 1))
        RT.song_walk(bytes(patched), where, where + len(data))
        report.append(dict(id=slug, source_command=hex(source), scratch_command=hex(command), address=hex(where), size=len(data), sha256=RT.sha256(data), instruments=fields['instruments']))
        where = where + len(data) + 15 & ~15
    if any((restored[i] != patched[i] and i not in allowed for i in range(len(sound)))):
        raise RT.RestoreError('audition changed bytes outside allocated songs and alias pointers')
    return (bytes(patched), report, dict(restoration=restoration, ending_loop=ending))

def render(a):
    work, out = (a.workdir.resolve(), a.out.resolve())
    work.mkdir(parents=True, exist_ok=False)
    out.mkdir(parents=True, exist_ok=False)
    sound, identities = RT.load_sound(a.rom_dir.resolve())
    bank, source = RT.load_bank(a.x68k_archive.resolve())
    patched, patches, restored = prepare(sound, bank)
    roms = work / 'roms' / 'striderua'
    roms.mkdir(parents=True)
    for p in (a.rom_dir.resolve() / 'striderua').iterdir():
        if p.is_file():
            shutil.copy(p, roms / p.name)
    (roms / '09.12b').write_bytes(patched)
    run = SG.run(a.mame, roms.parent, 'striderua', work / 'run', [t[2] for t in TRACKS], SLOT)
    report = dict(schema='striderex-unused-auditions/1', qualified_game_change=False, command='backports/striderex/scripts/audition_unused.py', inputs=identities, tool_sha256=RT.sha256(Path(__file__).read_bytes()), probe_lua_sha256=RT.sha256(SG.LUA.read_bytes()), mame_sha256=RT.sha256(Path(shutil.which(str(a.mame)) or a.mame).read_bytes()), x68000=source, sound_sha256=RT.sha256(patched), relocations=patches, existing_ex_restorations=restored, slot_s=SLOT, tracks=[])
    for k, (slug, label, command, xsource) in enumerate(TRACKS):
        t0 = run['slots'][k][1]
        notes = [(t - t0, channel, key) for t, channel, key in NI.key_ons(run['ym'], t0, t0 + SLOT)]
        if not notes:
            raise RuntimeError(f'{slug}: no notes played')
        loop = classify(notes)
        end = NI.audible_end(run['mix'], SG.SR, t0, t0 + SLOT)
        excerpt = min(60.0, loop[0] + loop[1] + 3 if loop else end + 0.5)
        target = out / (slug + '.mp3')
        subprocess.run(['ffmpeg', '-v', 'error', '-y', '-ss', str(t0), '-i', str(work / 'run/mix.wav'), '-t', str(excerpt), '-codec:a', 'libmp3lame', '-b:a', '192k', str(target)], check=True)
        row = dict(id=slug, label=label, source='X68000' if xsource is not None or command in RT.RESTORE else 'arcade', command=hex(command), source_command=hex(xsource) if xsource is not None else hex(command), first_note_s=round(notes[0][0], 3), last_note_s=round(notes[-1][0], 3), notes=len(notes), loops=bool(loop), audible_end_s=round(end, 2), excerpt_s=round(excerpt, 3), file=target.name, sha256=RT.sha256(target.read_bytes()))
        row['sustains_full_test'] = end >= SLOT - 1 and notes[-1][0] >= SLOT - 1
        row['playback'] = 'repeating note pattern confirmed' if loop else 'sustained; common note period unresolved' if row['sustains_full_test'] else 'one-shot'
        if loop:
            row.update(loop_start_s=round(loop[0], 3), loop_period_s=round(loop[1], 3))
        report['tracks'].append(row)
        print(json.dumps(row), flush=True)
    (out / 'auditions.json').write_text(json.dumps(report, indent=2) + '\n')

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--self-test', action='store_true')
    p.add_argument('--rom-dir', type=Path)
    p.add_argument('--x68k-archive', type=Path)
    p.add_argument('--workdir', type=Path)
    p.add_argument('--out', type=Path)
    p.add_argument('--mame', default='mame')
    a = p.parse_args()
    if a.self_test:
        assert classify([(i * 2.0, 0, 40 + i % 4) for i in range(55)]) == (0.0, 8.0)
        assert classify([(i * 2.0, 0, 40 + i % 4) for i in range(12)]) is None
        assert classify([]) is None
        print('self-test PASS')
    else:
        if any((v is None for v in (a.rom_dir, a.x68k_archive, a.workdir, a.out))):
            p.error('--rom-dir, --x68k-archive, --workdir and --out are required')
        render(a)
if __name__ == '__main__':
    main()
