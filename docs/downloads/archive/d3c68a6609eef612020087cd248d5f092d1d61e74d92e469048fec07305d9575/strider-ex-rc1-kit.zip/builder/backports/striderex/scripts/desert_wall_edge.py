"""Keep the map-transition camera's 12-pixel settle tolerance inside the cliff."""
import argparse
from copy import deepcopy
import json
from pathlib import Path
import struct
import sys
import boss_voice_gate as V
TOL = 12
ORIGIN = 6672
CONTEXT = struct.pack('>32H', 2, 6672, 8208, 784, 1808, 0, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0, 5, 2, 0, 0, 0, 0, 0, 0, 4, 3, 0, 0, 0, 0, 0, 0)

def patch(raw):
    bank = bytearray((raw[i ^ 1] for i in range(len(raw))))
    at = bank.find(CONTEXT)
    if at < 0 or bank.count(CONTEXT) != 1 or at & 1:
        raise ValueError('pipe-to-jeep transition table differs')
    struct.pack_into('>H', bank, at + 2, ORIGIN + TOL)
    return (bytes((bank[i ^ 1] for i in range(len(bank)))), dict(address=1048576 + at + 2, before=ORIGIN, after=ORIGIN + TOL, source_context_sha256=V.sha(CONTEXT)))

def main():
    if sys.argv[1:] == ['--self-test']:
        source = bytearray(128)
        source[32:96] = CONTEXT
        raw = bytes((source[i ^ 1] for i in range(len(source))))
        new, r = patch(raw)
        assert r['address'] == 1048610 and sum((x != y for x, y in zip(raw, new))) == 1
        for k in (0, 1):
            bad = bytearray(raw)
            bad[32 + k] ^= 1
            try:
                patch(bad)
            except ValueError:
                pass
            else:
                raise AssertionError('wrong source accepted')
        print('Wall edge self-test PASS: one guarded data word; altered context rejected')
        return
    p = argparse.ArgumentParser(description=__doc__)
    for name in ('build', 'out'):
        p.add_argument('--' + name, type=Path, required=True)
    a = p.parse_args()
    meta, files = V.inventory(a.build)
    rep = deepcopy(meta)
    a.out.mkdir(parents=True, exist_ok=False)
    for m, f in files.items():
        changed, row = patch(f['strex_p6.bin'])
        result = dict(f, **{'strex_p6.bin': changed})
        d = a.out / m
        d.mkdir()
        for n, b in result.items():
            (d / n).write_bytes(b)
        rep['sets'][m]['files'] = {n: V.sha(b) for n, b in result.items()}
        rep['sets'][m]['wall_edge'] = dict(change=row, pan_tolerance=TOL, map_origin=ORIGIN, source_files=meta['sets'][m]['files'], only_transition_minimum=True)
    (a.out / 'build.json').write_text(json.dumps(rep, indent=2) + '\n')
    print('PASS: transition minimum +12; following section restores the original bounds')
if __name__ == '__main__':
    main()
