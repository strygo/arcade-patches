"""Portable geometry-kit verification, followed by exact Kit z recovery."""
import argparse
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import xml.etree.ElementTree as ET
import zipfile
sys.dont_write_bytecode = True

def sha(data):
    return hashlib.sha256(data).hexdigest()

def qualification(report):
    geometry = report['geometry']
    expected = report['build_files']
    for name, receipt in geometry['qualification'].items():
        if not receipt.get('passed') or receipt.get('build_files') != expected:
            raise ValueError('geometry qualification missing or mismatched: ' + name)
    runtime = geometry['qualification']['runtime']
    wanted = {(m, p, s) for m in ('striderua', 'striderjr') for p in (False, True) for s in range(6)}
    if len(runtime['results']) != len(wanted) or any((not r['passed'] or r['timing']['late_records'] for r in runtime['results'])):
        raise ValueError('failed or duplicated geometry runtime results')
    got = {(r['machine'], r['pack'], r['stage']) for r in runtime['results']}
    if got != wanted:
        raise ValueError('incomplete geometry runtime matrix')
    pixels = geometry['qualification']['pixels']
    if geometry['scale'] == 'method-e':
        if len(pixels['scenes']) != 8 or any((not s.get('pixel_frames_checked') or s['timing']['over_limit'] for s in pixels['scenes'])):
            raise ValueError('incomplete widened-scene pixel/timing qualification')
    elif pixels.get('page_mouth_images') != 57:
        raise ValueError('incomplete native portrait check')

def verify(root):
    sys.path.insert(0, str(root))
    import mra_assembly
    report = json.loads((root / 'producer.json').read_text())
    geometry = report['geometry']
    members = {}
    for relative, expected in report['archives'].items():
        with zipfile.ZipFile(root / relative) as z:
            got = {n: sha(z.read(n)) for n in z.namelist()}
            if relative.startswith('games/mame/striderex_'):
                machine = 'striderua' if relative.endswith('_us.zip') else 'striderjr'
                members[machine] = {n: z.read(n) for n in report['build_files'][machine]}
        if got != expected:
            raise ValueError('geometry archive changed: ' + relative)
    for title, expected in report['mras'].items():
        text = (root / '_Arcade' / (title + '.mra')).read_text()
        refs = {Path(ref).name for n in ET.fromstring(text).iter() for ref in n.get('zip', '').split('|') if ref}
        archives = [root / p for p in report['archives'] if Path(p).name in refs]
        image = mra_assembly.assemble(text, mra_assembly.ZipSource(archives))
        if sha(image) != expected['assembled_sha256'] or image[64 + (2097151 ^ 1)] != expected['flag']:
            raise ValueError('geometry launcher assembly changed')
    if sha((root / report['core']['file']).read_bytes()) != report['core']['sha256']:
        raise ValueError('core changed')
    qualification(report)
    reverse = root / 'geometry-reverse.zip'
    if sha(reverse.read_bytes()) != geometry['reverse_sha256']:
        raise ValueError('baseline reconstruction payload changed')
    with tempfile.TemporaryDirectory(prefix='striderex-geometry-') as temporary:
        baseline = Path(temporary) / 'baseline'
        shutil.copytree(root, baseline)
        with zipfile.ZipFile(reverse) as z:
            manifest = json.loads(z.read('baseline.json'))
            for name, digest in manifest['files'].items():
                data = z.read('files/' + name)
                if sha(data) != digest:
                    raise ValueError('reconstruction helper changed')
                target = baseline / name
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(data)
            for machine, inventory in manifest['build_files'].items():
                region = 'us' if machine == 'striderua' else 'jp'
                path = baseline / f'games/mame/striderex_{region}.zip'
                with zipfile.ZipFile(path) as original:
                    old = {n: original.read(n) for n in original.namelist()}
                for name, digest in inventory.items():
                    key = f'roms/{machine}/{name}'
                    if key in z.namelist():
                        old[name] = z.read(key)
                    if sha(old[name]) != digest:
                        raise ValueError('cannot recover baseline ROM: ' + name)
                with zipfile.ZipFile(path, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
                    for name, data in sorted(old.items()):
                        archive.writestr(name, data)
        subprocess.run([sys.executable, '-I', '-B', str(baseline / 'verify_kit.py'), '--root', str(baseline)], check=True)
    print('PASS geometry kit: final ROM/MRA/core identities, complete runtime/pixel checks and exact Kit z recovery')

def main():
    if sys.argv[1:] == ['--self-test']:
        return self_test()
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root', type=Path, default=Path(__file__).resolve().parent)
    a = p.parse_args()
    verify(a.root.resolve())

def self_test():
    files = {'striderua': {'test.bin': 'source'}}
    runtime = dict(passed=True, build_files=files, results=[dict(machine=m, pack=p, stage=s, passed=True, timing=dict(late_records=0)) for m in ('striderua', 'striderjr') for p in (False, True) for s in range(6)])
    good = dict(build_files=files, geometry=dict(scale='native', qualification=dict(runtime=runtime, pixels=dict(passed=True, build_files=files, page_mouth_images=57))))
    qualification(good)
    for change in ('missing', 'failed', 'late', 'duplicate', 'wrong-files', 'pixels'):
        bad = deepcopy(good)
        rs = bad['geometry']['qualification']['runtime']['results']
        if change == 'missing':
            rs.pop()
        if change == 'failed':
            rs[0]['passed'] = False
        if change == 'late':
            rs[0]['timing']['late_records'] = 1
        if change == 'duplicate':
            rs[0] = rs[1]
        if change == 'wrong-files':
            bad['geometry']['qualification']['pixels']['build_files'] = {}
        if change == 'pixels':
            bad['geometry']['qualification']['pixels']['page_mouth_images'] = 1
        try:
            qualification(bad)
        except ValueError:
            pass
        else:
            raise AssertionError('damaged qualification accepted: ' + change)
    print('Geometry portable self-test PASS: six incomplete/damaged qualification controls rejected')
if __name__ == '__main__':
    main()
