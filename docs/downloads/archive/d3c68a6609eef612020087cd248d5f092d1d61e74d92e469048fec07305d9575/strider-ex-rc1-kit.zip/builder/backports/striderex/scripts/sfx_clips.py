"""Strider EX: the stage select code's sound, candidates rendered from the stock arcade for listening."""
import argparse
import json
import os
import subprocess
import sys
from pathlib import Path
import numpy as np
sys.path.insert(0, str(Path(__file__).resolve().parent))
import audio_cue_map as ACM
LABEL_TABLE = 469422
INJECT = 150
ATTRACT_MUSIC = 600
RATE = 48000
FLOOR_DB = -50.0
PICKS = {129: ('PLAYER  ', "now: Hiryu's slash voice (Japan sends it with every slash; EX USA too, D10)"), 20: (' CREDIT ', 'the coin-in chime (music command 0x14, sent on every credit)'), 72: ('NODAMAGE', 'an effect the game never sends (its setter has no caller)'), 65: ('OP START', "an option (one of Hiryu's helpers) appears at his side: sent by its spawn (0x5E6B0)"), 88: ('FMM SHOT', "the item capsule's sound (pool 7 type 0x1A, 0x4BC88)"), 64: ('P KAMA2 ', 'a Hiryu move: sent after his wall and ceiling tests (0x139B6, 0x1443A, 0x14472), likely his claws catching hold (INFERRED)'), 144: ('HIRYU   ', "Hiryu's first line in the Aerial Battleship intro (voice table 0x9D34)"), 130: ('PLAYER  ', 'a Hiryu voice the game never sends (beside the slash voice 0x81)')}
SURVEY = {**PICKS, **{66: ('OP OUT  ', 'an option leaving Hiryu (0x519C8)'), 155: ('G MASTER', "the Grandmaster's laugh (the globe after START, game over)"), 131: ('PLAYER  ', 'a Hiryu voice the game never sends'), 132: ('PLAYER  ', 'a Hiryu voice the game never sends'), 133: ('PLAYER  ', 'a Hiryu voice the game never sends'), 146: ('HIRYU   ', "Hiryu's second line in the Aerial Battleship intro (voice table 0x9D38)"), 15: ('GM CLEAR', 'the stage clear jingle'), 63: ('P KAMA1 ', 'a Hiryu move (0x13AA2, after a wall test)'), 116: (' KINOKO ', 'an Amazon stage sound (0x2C364, 0x2CF28)'), 101: ('EDA  UP ', 'never sent'), 102: ('EDA DOWN', 'never sent'), 48: ('JUMP 1  ', "Hiryu's jump")}}
LUA = "\nlocal m=manager.machine\nlocal sp=m.devices[':maincpu'].spaces['program']\nlocal f=0\nlocal cur=nil\nlocal cue=tonumber(os.getenv('CUE'))\nlocal at=tonumber(os.getenv('AT'))\nlocal last=tonumber(os.getenv('END'))\n_G.strex_inj=sp:install_write_tap(0x800180,0x800181,'inj',function(o,d,mk) if cur then return cur end end)\nemu.register_frame_done(function()\n f=f+1\n cur=nil\n if f>=at and f<at+2 then cur=cue end\n if f>=last then m:exit() end\nend)\n"

def program(rom_dir):
    rom_dir = Path(rom_dir)
    img, _ = ACM.program_image('striderua', rom_dir / 'striderua', rom_dir / 'strider')
    return img

def labels(img):
    return {c: img[LABEL_TABLE + 8 * c:LABEL_TABLE + 8 * c + 8].decode('latin1') for c in range(160)}

def windows_db(x, k):
    n = len(x) // k
    return 20 * np.log10(np.sqrt((x[:n * k].reshape(n, k) ** 2).mean(1) + 1e-20))

def trim(x, start):
    """The sound after sample start: from 20 ms before its first 5 ms window above FLOOR_DB to 100 ms after"""
    k = RATE // 200
    db = windows_db(x[start:], k)
    on = np.nonzero(db > FLOOR_DB)[0]
    if not len(on):
        raise ValueError('no sound')
    a = start + max(0, on[0] * k - RATE // 50)
    b = min(len(x), start + (on[-1] + 1) * k + RATE // 10)
    y = x[a:b].copy()
    fade = RATE // 50
    y[-fade:] *= np.linspace(1, 0, fade)
    return (y, (a - start) / RATE)

def write_wav(path, y):
    import wave
    with wave.open(str(path), 'wb') as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(RATE)
        w.writeframes(np.rint(np.clip(y, -1, 32767 / 32768) * 32768).astype('<i2').tobytes())

def mp3(wav):
    subprocess.run(['ffmpeg', '-hide_banner', '-loglevel', 'error', '-y', '-i', str(wav), '-codec:a', 'libmp3lame', '-b:a', '192k', str(wav.with_suffix('.mp3'))], check=True)

def render_one(mame, rom_dir, cue, out):
    import wave
    run = out / f'run_{cue:02x}'
    run.mkdir(parents=True)
    (run / 'inj.lua').write_text(LUA)
    end = ATTRACT_MUSIC
    env = dict(os.environ, SDL_VIDEODRIVER='dummy', SDL_AUDIODRIVER='dummy', CUE=str(cue), AT=str(INJECT), END=str(end))
    cmd = [mame, 'striderua', '-rompath', str(rom_dir), '-nothrottle', '-video', 'none', '-sound', 'none', '-skip_gameinfo', '-noautosave', '-cfg_directory', str(run / 'cfg'), '-nvram_directory', str(run / 'nv'), '-snapshot_directory', str(run), '-wavwrite', str(run / 'raw.wav'), '-autoboot_script', str(run / 'inj.lua'), '-seconds_to_run', str(end // 50 + 30)]
    p = subprocess.run(cmd, env=env, capture_output=True, text=True, timeout=600)
    (run / 'mame.log').write_text(p.stdout + p.stderr)
    if p.returncode:
        sys.exit(f'{run}: MAME exit {p.returncode}')
    with wave.open(str(run / 'raw.wav')) as w:
        assert w.getframerate() == RATE, w.getframerate()
        ch = w.getnchannels()
        x = np.frombuffer(w.readframes(w.getnframes()), '<i2').reshape(-1, ch).astype(np.float64).mean(1) / 32768
    start = round((INJECT - 1) / 59.637 * RATE)
    before = windows_db(x[RATE:start], RATE // 200).max()
    if before > FLOOR_DB:
        sys.exit(f'{cue:#04x}: attract not silent before the cue ({before:.1f} dBFS)')
    clip, onset = trim(x, start)
    after = windows_db(x[-RATE // 4:], RATE // 200).max()
    if after > FLOOR_DB:
        sys.exit(f'{cue:#04x}: still sounding at the end of the run ({after:.1f} dBFS): longer than the silent attract')
    return (clip, onset)

def describe(y):
    k = RATE // 200
    db = windows_db(y, k)
    spec = np.abs(np.fft.rfft(y * np.hanning(len(y)))) + 1e-12
    freqs = np.fft.rfftfreq(len(y), 1 / RATE)
    centroid = float((freqs * spec).sum() / spec.sum())
    flatness = float(np.exp(np.log(spec).mean()) / spec.mean())
    return dict(seconds=round(len(y) / RATE, 2), peak_db=round(float(20 * np.log10(np.abs(y).max() + 1e-12)), 1), loud_s=round(float((db > -30).sum() * k / RATE), 2), centroid_hz=round(centroid), flatness=round(flatness, 3))

def render(a):
    out = a.out.resolve()
    out.mkdir(parents=True, exist_ok=False)
    img = program(a.rom_dir)
    lab = labels(img)
    table = SURVEY if a.survey else PICKS
    cues = [int(c, 16) for c in a.cues.split(',')] if a.cues else list(table)
    rows, joined = ([], [])
    for cue in cues:
        want = table.get(cue, (None, ''))[0]
        if want is not None and lab[cue] != want:
            sys.exit(f'{cue:#04x}: sound-test label {lab[cue]!r}, expected {want!r}')
        y, onset = render_one(a.mame, a.rom_dir.resolve(), cue, out / 'runs')
        name = f"{cue:02x}_{lab[cue].strip().replace(' ', '_').lower()}"
        wav = out / f'{name}.wav'
        write_wav(wav, y)
        mp3(wav)
        d = describe(y)
        rows.append(dict(cue=f'{cue:#04x}', label=lab[cue].strip(), file=wav.name, what=table.get(cue, ('', ''))[1], onset_after_cue_s=round(float(onset), 3), **d))
        joined += [y, np.zeros(RATE)]
        print(rows[-1], flush=True)
    write_wav(out / 'all.wav', np.concatenate(joined))
    mp3(out / 'all.wav')
    (out / 'index.json').write_text(json.dumps(rows, indent=1) + '\n')
    lines = [f"{r['file'][:-4]:<16} {r['cue']}  {r['label']:<8}  {r['seconds']:>4.2f} s  {r['what']}" for r in rows]
    (out / 'index.txt').write_text('\n'.join(lines) + '\n')
    print('\n'.join(lines))

def self_test(rom_dir):
    img = program(rom_dir)
    lab = labels(img)
    for cue, (want, _) in SURVEY.items():
        assert lab[cue] == want, (hex(cue), lab[cue], want)
    stubs = {c: e for e, (c, g) in ACM.setters(img).items()}
    assert ACM.callers(img, stubs[65]) == [386936, 386996]
    assert ACM.callers(img, stubs[66]) == [334280]
    assert ACM.callers(img, stubs[88]) == [310408]
    assert int.from_bytes(img[263242 + 4 * 26:263242 + 4 * 27], 'big') == 309770
    assert img[40244:40250] == bytes.fromhex('009000910092')
    assert img[386742:386746] == bytes.fromhex('43ed90ca')
    for cue in (72, 101, 102):
        assert ACM.callers(img, stubs[cue]) == [], hex(cue)
    for cue in range(130, 134):
        assert cue not in stubs, hex(cue)
    y = np.concatenate([np.zeros(RATE), 0.5 * np.sin(np.arange(RATE // 2) * 0.05), np.zeros(RATE)])
    clip, onset = trim(y, RATE // 2)
    assert abs(onset - 0.48) < 0.01 and abs(len(clip) / RATE - 0.62) < 0.02, (onset, len(clip) / RATE)
    print('self-test OK')

def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('cmd', nargs='?', choices=['render'])
    p.add_argument('--self-test', action='store_true')
    p.add_argument('--rom-dir', type=Path, required=True)
    p.add_argument('--out', type=Path)
    p.add_argument('--mame', default='mame')
    p.add_argument('--survey', action='store_true', help='the wider list the picks were chosen from')
    p.add_argument('--cues')
    a = p.parse_args()
    if a.self_test:
        self_test(a.rom_dir)
        return 0
    if a.cmd == 'render':
        if not a.out:
            p.error('render needs --out')
        render(a)
        return 0
    p.error('nothing to do')
if __name__ == '__main__':
    sys.exit(main())
