"""Reconstruction helper."""
import argparse
import json
import shutil
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import numpy as np
from PIL import Image, ImageDraw
sys.path.insert(0, str(Path(__file__).resolve().parent))
import build_ex as BX
import desert_gate as DG
import hbmame_set as HS
import stage_openings as SO
import stage_select_gate as SSG
import strider_mapper_probe as P
PARENT = DG.PARENT
STAGES = (5, 1, 3, 2, 4)
NAMES = {5: 'desert', 1: 'Siberia', 3: 'Aerial Battleship', 2: 'Amazon', 4: 'Third Moon', 0: 'St. Petersburg'}
DIALOGUE = {'striderua': (42332, 46121), 'striderjr': (42194, 45521)}
TUNES = {17, 18, 19, 30, 31}
VOICES = set(range(140, 154))
WIZ_SETUP = 36
WIZ_SCROLL = 240
SKIP = '687-700:P1_BUTTON1'
STOCK_END = 1300
STOCK_SHOTS_AT, STOCK_SHOTS = (400, 440)
PLAY_TAIL = 60
SHOTS_N = WIZ_SETUP + WIZ_SCROLL + 100 + PLAY_TAIL
TSHOTS = 72
PROG_PLAY = DG.PROG_PLAY
PSHOT = 50
CHAIN_END = 20000
LAYER_AND = 65535 & ~SO.STAR_BITS
CINE = DG.CINE
KEYS = {'striderua': ('strider.key', 'CPS_B_01', '39065af5'), 'striderjr': ('striderjr.key', 'CPS_B_21_DEF', '8a7819d0')}

def stock_sets(hbmame, rom_dir, out):
    """The parent sets under HBMAME's own names (its pinned driver's blocks): every member by CRC from the stock"""
    rev = HS.manifest()['hbmame_source_revision']
    for machine in PARENT.values():
        d = out / machine
        if d.is_dir():
            continue
        block = HS.parent_block(hbmame, rev, machine)
        files = HS.set_files(rom_dir, machine)
        by_crc = {HS.crc(b): b for b in files.values()}
        d.mkdir(parents=True)
        n = 0
        for line in block.splitlines():
            m = HS.LINE.search(line)
            if not m:
                continue
            if m['name'].endswith('.key'):
                name, board, crc = KEYS[machine]
                data = P.cps1_key(P.ST24M1, board)
                if HS.crc(data) != crc or m['crc'] != crc or m['name'] != name:
                    sys.exit(f"intro_gate: {machine}: the regenerated key does not match HBMAME ({m['name']} {m['crc']})")
            else:
                data = by_crc.get(m['crc'])
                if data is None:
                    sys.exit(f"intro_gate: {machine}/{m['name']}: no stock file with CRC {m['crc']}")
            (d / m['name']).write_bytes(data)
            n += 1
        if n < 10:
            sys.exit(f'intro_gate: {machine}: {n} members in the HBMAME block')
    return out

def common_env(machine, shots=True, tail=False):
    lo, hi = DIALOGUE[machine]
    env = dict(INTRO='1', DIALOGUE=f'{lo:x}-{hi:x}')
    if shots:
        env['LAYER_AND'] = f'{LAYER_AND:04x}'
    if tail:
        env['TSHOTS'] = str(TSHOTS)
    return env

def stock_env(stage, machine, shots=True):
    return (dict(DG.debug_env(stage, 0, STOCK_END, invincible=False, inputs=False), STREX_INPUTS=SKIP, ISHOTS_AT=str(STOCK_SHOTS_AT), ISHOTS=str(STOCK_SHOTS), **common_env(machine, shots)), STOCK_END)

def chain_env(machine, seed=None, shots=True, pshots=True, tail=False):
    env = dict(DG.debug_env(0, 7, CHAIN_END, inputs=False), CLEAR_PLAY=f'{PROG_PLAY}*5', ISHOTS=str(SHOTS_N), **common_env(machine, shots, tail))
    if pshots:
        env['PSHOTS'] = str(PSHOT)
    if seed:
        env['SEED'] = DG.seed_env(seed)
    return (env, CHAIN_END)

def select_inputs(stage, desert=True):
    order = [s for s, _ in SSG.ORDER if desert or s != 5]
    k = order.index(stage)
    return SSG.CODE + SSG.presses(k, len(order)) + f';{SSG.PICK}-{SSG.PICK + 4}:START1'

def select_end(build, machine, stage):
    """The pick's frames: the select screen, the stage's cinematics (pre-roll and window), the wizard, the start."""
    scenes = {s['id']: s for s in json.loads((build / 'build.json').read_text())['scenes']}
    ids = {**BX.STAGE_SCENES, **BX.DESERT_SCENES}[stage]
    cine = sum((scenes[i]['preroll'] + scenes[i]['window']['frames'] + 40 for i in ids))
    return SSG.PICK + 60 + cine + SHOTS_N + 120 + DIALOGUE_MAX
DIALOGUE_MAX = 1000

def select_env(build, machine, stage, shots=True, tail=False):
    return (dict(INPUTS_ONLY='1', INPUTS=select_inputs(stage), ISHOTS=str(SHOTS_N), **common_env(machine, shots, tail)), select_end(build, machine, stage))

def run_all(binary, jobs, n):
    with ThreadPoolExecutor(n) as ex:
        return dict(zip([j[0] for j in jobs], ex.map(lambda j: DG.run(binary, j[1], j[2], j[3], *j[4]), jobs)))

def read_intro(out):
    lines = (out / 'intro.tsv').read_text().splitlines()
    head = lines[0].split('\t')
    return [dict(zip(head, ln.split('\t'))) for ln in lines[1:]]

def sounds(row):
    return [int(x, 16) for x in row['sound'].split(',') if x and x != 'ff']

def stage_marks(fr, it, stage, after=0, cine=True):
    """The stage's marks from frame `after`: entered, its last cinematic frame and the hand-back, the wizard"""
    by = {int(r['frame']): r for r in it}
    t = DG.first(fr, lambda r: r['stage'] == str(stage), after)
    play = DG.first(fr, lambda r: r['stage'] == str(stage) and r['mode'] == '4', t or 0) if t else None
    if play is None:
        return dict(stage=stage, entered=t, play=None)
    cframes = [int(r['frame']) for r in fr if t <= int(r['frame']) < play and r['active'] in CINE] if cine else []
    hand = max(cframes) + 1 if cframes else None
    lo = hand if hand else t
    wset = next((f for f in range(lo, play) if by[f]['wizard'] == str(WIZ_SCROLL)), None)
    wend = next((f for f in range(wset, play) if by[f]['wizard'] == '0'), None) if wset else None
    cap = next((f for f in range(wend or lo, play + 1) if by[f]['kind2'] != '0'), None)
    setup = next((f for f in range(wend or lo, play + 1) if by[f]['state'] == '4' and by[f]['sub'] == '4'), None)
    ready = next((f for f in range(play - 2, play + 30) if by[f]['ready'] != '0'), None)
    full = bool(wset and wend and (wend - wset == WIZ_SCROLL) and all((int(by[f]['wizard']) == WIZ_SCROLL - (f - wset) for f in range(wset, wend + 1))))
    return dict(stage=stage, entered=t, last_cinematic=max(cframes) if cframes else None, hand_back=hand, wizard_start=wset - WIZ_SETUP if wset else None, wizard_set=wset, wizard_end=wend, full_scroll=full, caption=cap, setup=setup, play=play, ready=ready)

def dialogue_free(fr, it, lo, hi):
    """No dialogue in frames [lo, hi): the intro state never 2, no dialogue record read, no strip object, no"""
    by = {int(r['frame']): r for r in it}
    bad = dict(state2=[], reads=[], strips=[], tunes=[], voices=[])
    for r in fr:
        f = int(r['frame'])
        if not lo <= f < hi:
            continue
        i = by[f]
        if i['state'] == '2':
            bad['state2'].append(f)
        if i['dreads'] != '0':
            bad['reads'].append(f)
        if i['kind5'] != '0':
            bad['strips'].append(f)
        for c in sounds(r):
            if c in TUNES:
                bad['tunes'].append((f, f'{c:02x}'))
            if c in VOICES:
                bad['voices'].append((f, f'{c:02x}'))
    out = {k: dict(n=len(v), first=v[:3]) for k, v in bad.items()}
    out['passed'] = all((not v for v in bad.values()))
    return out

def hand_back(d, h, wizard_start, n_w):
    """The hand-back (PHASE0_FINDINGS.md "The white frame after Meio's welcome"): from the scene's last picture to"""
    if not h:
        return dict(passed=False, why='no hand-back')
    pre = [f for f in range(h - TSHOTS, h) if (d / f't_{f:05d}.png').exists()]
    shown = {f: img(d, f, 't_') for f in pre}
    lit = [f for f in pre if shown[f].any()]
    if not lit:
        return dict(passed=False, why=f'no lit cinematic frame among the {len(pre)} kept before the hand-back {h}')
    last = max(lit)
    missing = [f for f in range(last + 1, h) if f not in shown]
    seq, first_lit = ([(f, shown[f]) for f in range(last + 1, h) if f in shown], None)
    for f in range(h, h + SHOTS_N):
        x = img(d, f)
        if x is None:
            missing.append(f)
            break
        if x.any() and f > h:
            first_lit = f
            break
        seq.append((f, x))
    bad = [dict(frame=f, lit_pixels=int(x.any(axis=2).sum()), mean=[round(float(v), 1) for v in x.reshape(-1, 3).mean(axis=0)]) for f, x in seq if x.any()]
    x = img(d, h)
    hb = None if x is None else dict(black=not x.any(), mean=[round(float(v), 1) for v in x.reshape(-1, 3).mean(axis=0)])
    in_wizard = bool(first_lit and wizard_start and (h < first_lit < wizard_start + n_w))
    return dict(last_picture=last, hand_back=h, first_lit=first_lit, black_frames=len(seq) - len(bad), not_black=bad[:8], n_not_black=len(bad), missing=missing[:4], hand_back_frame=hb, first_lit_in_wizard=in_wizard, passed=bool(not bad and (not missing) and in_wizard))

def img(d, f, pre='i_'):
    p = d / f'{pre}{f:05d}.png'
    return np.asarray(Image.open(p).convert('RGB')) if p.exists() else None

def compare_frames(da, fa, db, fb, n):
    """Frames fa.. of run a against fb.. of run b, n of them, pixel for pixel. Returns the counts and the first"""
    same, diff, missing = (0, [], [])
    for k in range(n):
        x, y = (img(da, fa + k), img(db, fb + k))
        if x is None or y is None:
            missing.append(k)
            continue
        d = (x != y).any(axis=2)
        if d.any():
            ys, xs = np.nonzero(d)
            diff.append(dict(offset=k, frames=[fa + k, fb + k], pixels=int(d.sum()), box=[int(xs.min()), int(ys.min()), int(xs.max()), int(ys.max())]))
        else:
            same += 1
    return dict(compared=n, identical=same, differ=len(diff), missing=len(missing), first=diff[:4], missing_first=missing[:4], passed=same == n)

def numbers_equal(ita, fa, itb, fb, n, cols=('stars', 'starpal')):
    """The intro.tsv columns cols, frame by frame (the star scroll registers and palettes)."""
    ba, bb = ({int(r['frame']): r for r in ita}, {int(r['frame']): r for r in itb})
    bad = [k for k in range(n) if any((ba[fa + k][c] != bb[fb + k][c] for c in cols))]
    return dict(compared=n, differ=len(bad), first=bad[:4], passed=not bad)

def sound_seq(fr, lo, hi, drop=()):
    """(offset from lo, command, slots) of the frames [lo, hi), 0xFF and `drop` left out. The VBlank sends one"""
    out, left, last = ([], 0, None)
    for r in fr:
        f = int(r['frame'])
        if not lo <= f < hi:
            continue
        for c in sounds(r):
            if last is None or f - last > 2:
                left = 0
            last = f
            if c in drop:
                left += 1
            else:
                out.append((f - lo, c, left))
    return out

def music_cue(fr, play):
    """(frames from play, cue) of the first music command (below 0x30) from 10 frames before play."""
    for r in fr:
        f = int(r['frame'])
        if play - 10 <= f < play + PLAY_TAIL:
            for c in sounds(r):
                if c < 48:
                    return [f - play, f'{c:02x}']
    return None

def check_stage(fr, it, d, ref, stage, after, chain, machine, want, other=None, tail=False):
    """One stage of a run against its stock reference (ref: marks, rows, dir of stock<s>; the desert takes"""
    m = stage_marks(fr, it, stage, after)
    rep = dict(marks=m)
    keys = ('briefing', 'wizard', 'dialogue', 'start') + (('hand_back',) if tail else ())
    if m.get('play') is None:
        rep.update({k: dict(passed=False, why='no play in the run') for k in keys})
        rep['passed'] = False
        return rep
    streams = json.loads((want['build'] / 'build.json').read_text())['sets'][machine]['streams']
    shown = DG.played(fr, streams, after, m['play'])
    rep['briefing'] = dict(cinematics=shown, want=want['scenes'][stage], passed=shown == want['scenes'][stage])
    rm, rfr, rit, rdir = ref
    h, hs = (m['hand_back'], rm['wizard_start'])
    ok_w = bool(h and m['wizard_start'] == h and m['full_scroll'])
    rep['wizard'] = dict(starts_on_hand_back=bool(h and m['wizard_start'] == h), full_scroll=m['full_scroll'])
    n_w = WIZ_SETUP + WIZ_SCROLL + 1
    if ok_w:
        x = img(d, h)
        rep['wizard']['hand_back_frame'] = None if x is None else dict(black=bool((x == 0).all()), mean=[round(float(v), 1) for v in x.reshape(-1, 3).mean(axis=0)])
        rep['wizard']['frames'] = compare_frames(d, h + 1, rdir, hs + 1, n_w - 1)
        rep['wizard']['stars'] = numbers_equal(it, h + 1, rit, hs + 1, n_w - 1)
        np_stop = int(json.loads(BX.CUES.read_text())['nopack_intros']['stop'], 16)
        own = [dict(r, sound=','.join((x for x in r['sound'].split(',') if x and int(x, 16) != np_stop))) if int(r['frame']) == h else r for r in fr]
        rep['wizard']['stop_on_hand_back'] = any((int(r['frame']) == h and np_stop in sounds(r) for r in fr))
        rep['wizard']['sound'] = same_sounds(sound_seq(own, h, h + n_w), sound_seq(rfr, hs, hs + n_w))
        ok_w = all((rep['wizard'][k]['passed'] for k in ('frames', 'stars', 'sound')))
    rep['wizard']['passed'] = ok_w
    if tail:
        rep['hand_back'] = hand_back(d, h, m['wizard_start'], n_w)
    if stage == 0:
        keys = ('briefing', 'wizard', 'hand_back')
        rep['passed'] = all((rep[k]['passed'] for k in keys))
        return rep
    rep['dialogue'] = dialogue_free(fr, it, h or m['entered'], m['play'])
    rep['start'] = check_start(fr, d, m, ref, stage, chain, machine, want, other)
    rep['passed'] = all((rep[k]['passed'] for k in keys))
    return rep

def same_sounds(bs, ss, tol=1):
    """The same commands in the same order, each on the reference's frame within tol frames, or as many slots"""
    ok = len(bs) == len(ss) and all((c == e and g - 2 * k - tol <= f <= g + tol for (f, c, _), (g, e, k) in zip(bs, ss)))
    return dict(build=[[f, f'{c:02x}'] for f, c, _ in bs], reference=[[g, f'{e:02x}', k] for g, e, k in ss], passed=ok)

def marks_rel(m):
    e = m['wizard_end']
    return dict(caption=m['caption'] - e, setup=m['setup'] - e if m.get('setup') else None, play=m['play'] - e, ready=m['ready'] - m['play'] if m.get('ready') else None)

def check_start(fr, d, m, ref, stage, chain, machine, want, other):
    """The stage start after the wizard (see the module's doc): ref is the stock reference, other the run the"""
    rm, rfr, rit, rdir = ref
    st = dict(stock=marks_rel(rm))
    if not (m.get('wizard_end') and m.get('caption')):
        return dict(st, passed=False, why='no wizard or no caption')
    st['build'] = marks_rel(m)
    e, re_ = (m['wizard_end'], rm['wizard_end'])
    if stage == 5:
        n = rm['caption'] - re_
        st['frames_to_caption'] = compare_frames(d, e + 1, rdir, re_ + 1, n - 1)
        st['sound'] = same_sounds(sound_seq(fr, e + 1, e + 31), sound_seq(rfr, re_ + 1, re_ + 31, drop=TUNES))
        st['music'] = music_cue(fr, m['play'])
        st['passed'] = st['build']['caption'] == st['stock']['caption'] and st['frames_to_caption']['passed'] and st['sound']['passed']
        return st
    n = rm['setup'] - re_
    st['frames_to_setup'] = compare_frames(d, e + 1, rdir, re_ + 1, n)
    st['sound'] = same_sounds(sound_seq(fr, e + 1, m['play'] + PLAY_TAIL), sound_seq(rfr, re_ + 1, rm['play'] + PLAY_TAIL, drop=TUNES))
    st['music'] = dict(build=music_cue(fr, m['play']), stock=music_cue(rfr, rm['play']))
    timing = st['build']['caption'] == st['stock']['caption'] and st['build']['setup'] == st['stock']['setup'] and (st['build']['ready'] == st['stock']['ready'] == 0) and (0 <= st['build']['play'] - st['stock']['play'] <= 1)
    st['timing_as_stock'] = timing
    if other:
        om, ofr, odir = other
        n = om['play'] - om['wizard_end'] + (-1 if chain else PLAY_TAIL)
        st['frames_vs_' + other_name(chain)] = compare_frames(d, e + 1, odir, om['wizard_end'] + 1, n)
        st['marks_vs_' + other_name(chain)] = marks_rel(om) == st['build']
        if not chain:
            st['sound_vs_control_skip'] = same_sounds(sound_seq(fr, e + 1, e + 1 + n), sound_seq(ofr, om['wizard_end'] + 1, om['wizard_end'] + 1 + n, drop=TUNES), tol=0)
    vs = [v['passed'] for k, v in st.items() if k.startswith(('frames_vs_', 'sound_vs_'))] + [v for k, v in st.items() if k.startswith('marks_vs_')]
    st['passed'] = bool(timing and st['frames_to_setup']['passed'] and st['sound']['passed'] and (st['music']['build'] is not None) and (st['music']['build'][1] == st['music']['stock'][1]) and (other is not None) and all(vs))
    return st

def other_name(chain):
    return 'pick' if chain else 'control_skip'

def strip(path, rows, labels):
    """rows: [(title, dir, [frames])]: one labeled row of frames each."""
    w, h = (384, 224)
    cols = max((len(r[2]) for r in rows))
    sheet = Image.new('RGB', (cols * (w // 2), len(rows) * (h // 2 + 14) + 2), (32, 32, 32))
    dr = ImageDraw.Draw(sheet)
    for j, (title, d, frames) in enumerate(rows):
        y = j * (h // 2 + 14)
        for i, f in enumerate(frames):
            p = d / f'i_{f:05d}.png'
            if p.exists():
                sheet.paste(Image.open(p).convert('RGB').resize((w // 2, h // 2)), (i * (w // 2), y + 14))
            dr.text((i * (w // 2) + 3, y + 1), f"{title} {(labels[i] if i < len(labels) else '')} ({f})", fill=(255, 220, 0))
    sheet.save(path)

def key_frames(m):
    """Frames for a strip: the hand-back, the wizard rising, its end, the black, the caption, the fade-in, play."""
    h, e, c, p = (m['hand_back'], m['wizard_end'], m['caption'], m['play'])
    return ([h, h + 60, h + 130, h + 200, e, e + 8, c + 8, p - 30, p - 10, p + 20], ['hand-back', 'wizard', 'wizard', 'wizard', 'wizard end', 'black', 'caption', 'fade-in', 'fade-in', 'play'])

def gate_runs(a, work):
    """Every run of the gate into work/runs (the seeded control after the build's chain)."""
    machine = PARENT[a.set]
    binary = json.loads((a.runtime / 'runtime.json').read_text())['binary']
    rom_dir = a.rom_dir.resolve()
    sets_b = DG.stage_sets(a.build.resolve(), a.set, a.hbmame, rom_dir, work / 'sets_build')
    sets_c = DG.stage_sets(a.control.resolve(), a.set, a.hbmame, rom_dir, work / 'sets_control')
    sets_s = stock_sets(a.hbmame, rom_dir, work / 'sets_stock')
    sets_h = DG.stage_sets(a.handback_control.resolve(), a.set, a.hbmame, rom_dir, work / 'sets_handback_control')
    R = work / 'runs'
    jobs = [(f'stock{s}', sets_s, machine, R / f'stock{s}', stock_env(s, machine)) for s in (1, 2, 3, 4)]
    jobs += [('chain', sets_b, a.set, R / 'chain', chain_env(machine, tail=True))]
    jobs += [(f'select{s}', sets_b, a.set, R / f'select{s}', select_env(a.build, machine, s, tail=True)) for s in PICKS]
    jobs += [('control_chain', sets_c, a.set, R / 'control_chain', chain_env(machine))]
    jobs += [(f'control_select{s}', sets_c, a.set, R / f'control_select{s}', select_env(a.control, machine, s)) for s in CONTROL_PICKS]
    jobs += [('hb_control_chain', sets_h, a.set, R / 'hb_control_chain', chain_env(machine, tail=True))]
    jobs += [(f'hb_control_select{s}', sets_h, a.set, R / f'hb_control_select{s}', select_env(a.handback_control, machine, s, tail=True)) for s in HB_CONTROL_PICKS]
    res = run_all(binary, jobs, a.jobs)
    seed = DG.play_seeds(res['chain'], R / 'chain', STAGES)
    more = [('control_seeded', sets_c, a.set, R / 'control_seeded', chain_env(machine, seed=seed))]
    for s in SKIP_PICKS:
        m = stage_marks(res[f'select{s}'], read_intro(R / f'select{s}'), s, SSG.PICK - 10)
        if not m.get('wizard_end'):
            raise SystemExit(f'select{s}: no wizard, no control skip')
        e, n = select_env(a.control, machine, s)
        e = dict(e, INPUTS=e['INPUTS'] + skip_press(m['wizard_end']))
        more.append((f'control_skip{s}', sets_c, a.set, R / f'control_skip{s}', (e, n)))
    run_all(binary, more, a.jobs)
SKIP_PICKS = (1, 3, 2, 4)

def skip_press(wizard_end):
    """P1 button 1 held from the frame after the wizard's last check (its end) over the dialogue's first step"""
    return f';{wizard_end + 2}-{wizard_end + 15}:P1_BUTTON1'
CONTROL_PICKS = (5, 1)
PICKS = (0,) + STAGES
HB_CONTROL_PICKS = (4,)

def analyze(work, build, control, set_name):
    """The gate's checks over the runs in work/runs (gate_runs); writes report.json and the strips."""
    machine = PARENT[set_name]
    R = work / 'runs'
    names = [f'stock{s}' for s in (1, 2, 3, 4)] + ['chain'] + [f'select{s}' for s in PICKS] + ['control_chain', 'control_seeded'] + [f'control_select{s}' for s in CONTROL_PICKS] + [f'control_skip{s}' for s in SKIP_PICKS] + ['hb_control_chain'] + [f'hb_control_select{s}' for s in HB_CONTROL_PICKS]
    res = {k: DG.read(R / k) for k in names}
    it = {k: read_intro(R / k) for k in names}
    want = dict(build=build, scenes={**BX.STAGE_SCENES, **BX.DESERT_SCENES})
    rep = dict(set=set_name, stock={})
    refs = {}
    for s in (1, 2, 3, 4):
        k = f'stock{s}'
        m = stage_marks(res[k], it[k], s, cine=False)
        by = {int(r['frame']): r for r in it[k]}
        skip = DG.first(it[k], lambda r: r['state'] == '4', m['wizard_end'] or 0)
        ok = bool(m['full_scroll'] and skip == m['wizard_end'] + 13 and all((by[f]['dreads'] == '0' and by[f]['kind5'] == '0' for f in range(m['wizard_end'], m['play']))))
        m['skip_at'] = skip
        rep['stock'][k] = dict(marks=m, wizard_full_and_dialogue_skipped_at_its_first_step=ok)
        if not ok:
            raise SystemExit(f'{k}: the stock reference is not the wizard then the dialogue skipped at its first step')
        refs[s] = (m, res[k], it[k], R / k)
    w0 = refs[1][0]
    rep['stock']['wizard_same_in_stages_1_4'] = {f'stock{s}': compare_frames(R / 'stock1', w0['wizard_start'], R / f'stock{s}', refs[s][0]['wizard_start'], WIZ_SETUP + WIZ_SCROLL + 1)['passed'] for s in (2, 3, 4)}
    refs[5] = refs[0] = refs[1]
    picks, skips = ({}, {})
    for s in SKIP_PICKS:
        k = f'control_skip{s}'
        m = stage_marks(res[k], it[k], s, SSG.PICK - 10)
        by = {int(r['frame']): r for r in it[k]}
        at = DG.first(it[k], lambda r: r['state'] == '4', m.get('wizard_end') or 0)
        ok = bool(m.get('play') and m['full_scroll'] and (at == m['wizard_end'] + 13) and all((by[f]['dreads'] == '0' and by[f]['kind5'] == '0' for f in range(m['wizard_end'], m['play']))))
        rep['stock'][k] = dict(marks=m, skip_at=at, skipped_at_first_step=ok)
        if not ok:
            raise SystemExit(f'{k}: the control did not skip its dialogue at its first step')
        skips[s] = (m, res[k], R / k)
    for k in [f'select{s}' for s in PICKS] + ['chain']:
        stages = STAGES if k == 'chain' else (int(k[6:]),)
        out, after = ({}, 0 if k == 'chain' else SSG.PICK - 10)
        for s in stages:
            other = picks.get(s) if k == 'chain' else skips.get(s)
            out[NAMES[s]] = check_stage(res[k], it[k], R / k, refs[s], s, after, k == 'chain', machine, want, other, tail=True)
            if k != 'chain':
                picks[s] = (out[NAMES[s]]['marks'], res[k], R / k)
            after = out[NAMES[s]]['marks'].get('play') or after
        rep[k] = dict(stages=out, passed=all((v['passed'] for v in out.values())))
    rep['ex_setups'] = {NAMES[s]: dict(stock=refs[s][0]['play'] - refs[s][0]['setup'], control_skip=skips[s][0]['play'] - skips[s][0]['setup'], build=picks[s][0]['play'] - picks[s][0]['setup']) for s in SKIP_PICKS if picks[s][0].get('setup')}
    want_c = dict(want, build=control)
    ctl = {}
    for k in ['control_chain'] + [f'control_select{s}' for s in CONTROL_PICKS]:
        stages = STAGES if k == 'control_chain' else (int(k[-1]),)
        out, after = ({}, 0 if k == 'control_chain' else SSG.PICK - 10)
        for s in stages:
            out[NAMES[s]] = check_stage(res[k], it[k], R / k, refs[s], s, after, k == 'control_chain', machine, want_c)
            after = out[NAMES[s]]['marks'].get('play') or after
        ctl[k] = {n: dict(passed=v['passed'], briefing=v['briefing']['passed'], wizard=v['wizard']['passed'], dialogue_free=v['dialogue']['passed'], start=v['start']['passed']) for n, v in out.items()}
    ctl['failed'] = all((not (v['dialogue_free'] and v['wizard']) for k in ctl for v in ctl[k].values()))
    rep['control'] = ctl
    hbc = {}
    for k in ['hb_control_chain'] + [f'hb_control_select{s}' for s in HB_CONTROL_PICKS]:
        stages = STAGES if k == 'hb_control_chain' else (int(k[-1]),)
        after = 0 if k == 'hb_control_chain' else SSG.PICK - 10
        for s in stages:
            m = stage_marks(res[k], it[k], s, after)
            hbc[f'{k} {NAMES[s]}'] = hand_back(R / k, m.get('hand_back'), m.get('wizard_start'), WIZ_SETUP + WIZ_SCROLL + 1)
            after = m.get('play') or after
    meio = [v for n, v in hbc.items() if n.endswith(NAMES[4])]
    hbc['failed_at_meio'] = bool(meio and all((not v['passed'] and v.get('n_not_black') for v in meio)))
    hbc['passed_elsewhere'] = all((v['passed'] for n, v in hbc.items() if isinstance(v, dict) and (not n.endswith(NAMES[4]))))
    hbc['as_required'] = hbc['failed_at_meio'] and hbc['passed_elsewhere']
    rep['handback_control'] = hbc
    seed = DG.play_seeds(res['chain'], R / 'chain', STAGES)
    ctl_seed = DG.play_seeds(res['control_chain'], R / 'control_chain', STAGES)
    play = {}
    for s in STAGES:
        p = DG.compare_play(res['chain'], res['control_seeded'], R / 'chain', R / 'control_seeded', s, PROG_PLAY, PSHOT)
        u = DG.compare_play(res['chain'], res['control_chain'], R / 'chain', R / 'control_chain', s, PROG_PLAY, PSHOT)
        cb, cc = (seed.get(s), ctl_seed.get(s))
        play[NAMES[s]] = dict(seeded=p, unseeded=dict(frames_differ=u.get('frames_differ'), first=u.get('first'), shots_differ=u.get('shots_differ')), counter_at_play=dict(build=cb and f'{cb[0]:04x}', control=cc and f'{cc[0]:04x}', frames=cb and cc and cb[0] - cc[0]), passed=p['passed'])
    play['passed'] = all((v['passed'] for k, v in play.items() if k != 'passed'))
    rep['play'] = play
    for s in STAGES:
        mk = rep[f'select{s}']['stages'][NAMES[s]]['marks']
        if mk.get('hand_back') and mk.get('wizard_end') and mk.get('caption'):
            fb, labels = key_frames(mk)
            off = refs[s][0]['wizard_start'] - mk['hand_back']
            strip(work / f'strip_{s}.png', [('build', R / f'select{s}', fb), ('stock', R / f'stock{(1 if s == 5 else s)}', [f + off for f in fb])], labels)
    ok = all((rep[k]['passed'] for k in ['chain'] + [f'select{s}' for s in PICKS])) and ctl['failed'] and play['passed'] and all(rep['stock']['wizard_same_in_stages_1_4'].values()) and hbc['as_required']
    rep['passed'] = ok
    (work / 'report.json').write_text(json.dumps(rep, indent=1) + '\n')
    print(json.dumps(summary(rep), indent=1))
    print('PASS' if ok else 'FAIL')
    return 0 if ok else 1

def cmd_gate(a):
    if not a.handback_control:
        sys.exit('intro_gate gate: --handback-control is required')
    work = a.workdir.resolve()
    work.mkdir(parents=True, exist_ok=False)
    gate_runs(a, work)
    return analyze(work, a.build, a.control, a.set)

def summary(rep):
    out = {}
    for k in ['chain'] + [f'select{s}' for s in PICKS]:
        for n, v in rep[k]['stages'].items():
            m, hb = (v['marks'], v.get('hand_back', {}))
            out[f'{k} {n}'] = dict(passed=v['passed'], briefing=v['briefing']['passed'], wizard=v['wizard']['passed'], dialogue_free=v.get('dialogue', {}).get('passed'), start=v.get('start', {}).get('passed'), hand_back={x: hb.get(x) for x in ('passed', 'last_picture', 'first_lit', 'black_frames', 'n_not_black')}, marks={x: m.get(x) for x in ('hand_back', 'wizard_set', 'wizard_end', 'caption', 'setup', 'play')}, timing=v.get('start', {}).get('build'))
    out['control_failed'] = rep['control']['failed']
    out['handback_control'] = {n: v if not isinstance(v, dict) else {x: v.get(x) for x in ('passed', 'last_picture', 'hand_back', 'first_lit', 'n_not_black', 'hand_back_frame', 'why')} for n, v in rep['handback_control'].items()}
    out['play'] = {n: dict(passed=v['passed'], seeded_frames_differ=v['seeded'].get('frames_differ'), unseeded_first=v['unseeded'].get('first')[:1] if v['unseeded'].get('first') else None, counter=v['counter_at_play']) for n, v in rep['play'].items() if n != 'passed'}
    return out

def cmd_review(a):
    """Review material from unmasked runs (stars on): per stage before/after strips of the picks and of natural"""
    work = a.workdir.resolve()
    work.mkdir(parents=True, exist_ok=False)
    machine = PARENT[a.set]
    binary = json.loads((a.runtime / 'runtime.json').read_text())['binary']
    rom_dir = a.rom_dir.resolve()
    sets_b = DG.stage_sets(a.build.resolve(), a.set, a.hbmame, rom_dir, work / 'sets_build')
    sets_c = DG.stage_sets(a.control.resolve(), a.set, a.hbmame, rom_dir, work / 'sets_control')
    R = work / 'runs'
    big = SHOTS_N + 900
    jobs = []
    for tag, sets, build in (('build', sets_b, a.build), ('control', sets_c, a.control)):
        e, n = chain_env(machine, shots=False, pshots=False)
        e['ISHOTS'] = str(big)
        jobs.append((f'{tag}_chain', sets, a.set, R / f'{tag}_chain', (e, n)))
        for s in STAGES:
            e, n = select_env(build, machine, s, shots=False)
            e['ISHOTS'] = str(big)
            jobs.append((f'{tag}_select{s}', sets, a.set, R / f'{tag}_select{s}', (e, n)))
    res = run_all(binary, jobs, a.jobs)
    it = {k: read_intro(R / k) for k in res}
    rep = {}
    for s in STAGES:
        rows = []
        for tag in ('build', 'control'):
            for kind in ('select', 'chain'):
                k = f'{tag}_{kind}' + (str(s) if kind == 'select' else '')
                after = SSG.PICK - 10 if kind == 'select' else 0
                if kind == 'chain':
                    prev = STAGES.index(s)
                    after = DG.first(res[k], lambda r: r['stage'] == str(STAGES[prev - 1]) and r['mode'] == '4') if prev else 0
                m = stage_marks(res[k], it[k], s, after or 0)
                rep[k + ('' if kind == 'select' else f'_{s}')] = m
                h, p = (m.get('hand_back'), m.get('play'))
                if not h or not p:
                    continue
                fr = [h + i * (p + 30 - h) // 9 for i in range(10)]
                rows.append((f'{tag} {kind}', R / k, fr))
        strip(work / f"review_{s}_{NAMES[s].replace(' ', '_')}.png", rows, [])
    m = rep.get('build_select1')
    if m and m.get('hand_back'):
        clip = work / 'clip'
        clip.mkdir()
        for i, f in enumerate(range(m['hand_back'], m['play'] + 90)):
            src = R / 'build_select1' / f'i_{f:05d}.png'
            if src.exists():
                shutil.copy(src, clip / f'{i:05d}.png')
        if shutil.which('ffmpeg'):
            subprocess.run(['ffmpeg', '-loglevel', 'error', '-framerate', '59.637', '-i', str(clip / '%05d.png'), '-vf', 'scale=768:448:flags=neighbor', '-pix_fmt', 'yuv420p', str(work / 'siberia_intro.mp4')], check=False)
    (work / 'review.json').write_text(json.dumps(rep, indent=1) + '\n')
    print(json.dumps(rep, indent=1))
    return 0

def dialogue_span(img, lo, tables=12):
    """The end of the dialogue's record data: from the first table (lo), twelve tables in a row (stages 1-4: the"""
    import struct
    t = lo
    for _ in range(tables):
        first = t + struct.unpack('>H', img[t:t + 2])[0]
        recs = [t + struct.unpack('>H', img[i:i + 2])[0] for i in range(t, first, 2)]
        end = 0
        for r in recs:
            p = r
            while True:
                cols, rows = (struct.unpack('>H', img[p + 2:p + 4])[0] + 1, struct.unpack('>H', img[p + 4:p + 6])[0] + 1)
                p += 8 + 2 * cols * rows
                more = img[p:p + 2] == b'\xff\xff'
                p += 2
                if not more:
                    break
            end = max(end, p)
        t = end - 2
    return end

def self_test(a):
    ok = True

    def check(name, cond, detail=''):
        nonlocal ok
        print(('ok   ' if cond else 'FAIL ') + name + (f': {detail}' if detail else ''))
        ok &= bool(cond)
    for machine, (lo, hi) in DIALOGUE.items():
        files = HS.set_files(a.rom_dir, machine)
        import respawn_fix as RF
        imgb = bytes(RF.compose(files, RF.SETS[machine]))
        cut = BX.INTRO_CUT[machine]
        check(f'{machine} intro skip shape', imgb[cut['INTRO_SKIP']:cut['INTRO_SKIP'] + len(BX.INTRO_SKIP_BYTES)] == BX.INTRO_SKIP_BYTES)
        end = dialogue_span(imgb, lo)
        check(f'{machine} dialogue records: twelve tables from {lo:#x} to {hi:#x}, then the end word', end == hi + 3, f'{end:#x}')
    fr, it = ([], [])
    for f in range(1, 400):
        act = 'c1e5' if f < 10 else '0000'
        fr.append(dict(frame=str(f), stage='1', mode='4' if f >= 355 else '2', active=act, sound='', lz='0'))
        wiz = WIZ_SCROLL - (f - 46) if 46 <= f <= 286 else 0
        it.append(dict(frame=str(f), wizard=str(wiz), kind2='1' if 301 <= f < 400 else '0', ready='1' if f >= 355 else '0', state='0', dreads='0', kind5='0'))
    m = stage_marks(fr, it, 1)
    check('marks', (m['hand_back'], m['wizard_start'], m['wizard_end'], m['caption'], m['play'], m['full_scroll']) == (10, 10, 286, 301, 355, True), str(m))
    it[100]['wizard'] = '0'
    check('a cut scroll is not full', not stage_marks(fr, it, 1)['full_scroll'])
    it[50]['state'] = '2'
    it[60]['dreads'] = '5'
    fr[70]['sound'] = '12,ff'
    d = dialogue_free(fr, it, 10, 355)
    check('dialogue found', not d['passed'] and d['state2']['n'] == 1 and (d['reads']['n'] == 1) and (d['tunes']['n'] == 1))
    import tempfile
    with tempfile.TemporaryDirectory() as t:
        t = Path(t)
        black, lit = (np.zeros((4, 4, 3), np.uint8), np.full((4, 4, 3), 255, np.uint8))
        for f in range(40, 100):
            Image.fromarray(lit if f <= 97 else black).save(t / f't_{f:05d}.png')
        for f in range(100, 140):
            Image.fromarray(lit if f >= 130 else black).save(t / f'i_{f:05d}.png')
        hb = hand_back(t, 100, 100, WIZ_SETUP + WIZ_SCROLL + 1)
        check('hand-back black', hb['passed'] and (hb['last_picture'], hb['first_lit'], hb['black_frames']) == (97, 130, 32), str(hb))
        Image.fromarray(lit).save(t / 'i_00100.png')
        hb = hand_back(t, 100, 100, WIZ_SETUP + WIZ_SCROLL + 1)
        check('a white hand-back frame fails', not hb['passed'] and hb['n_not_black'] == 1 and (not hb['hand_back_frame']['black']), str(hb))
        Image.fromarray(black).save(t / 'i_00100.png')
        Image.fromarray(lit // 255).save(t / 't_00099.png')
        hb = hand_back(t, 100, 100, WIZ_SETUP + WIZ_SCROLL + 1)
        check('a dim lit frame is the last picture', hb['passed'] and hb['last_picture'] == 99, str(hb))
        Image.fromarray(black).save(t / 't_00099.png')
        (t / 't_00098.png').unlink()
        hb = hand_back(t, 100, 100, WIZ_SETUP + WIZ_SCROLL + 1)
        check('a frame missing after the last picture fails', not hb['passed'] and hb['missing'] == [98], str(hb))
        Image.fromarray(black).save(t / 't_00098.png')
        hb = hand_back(t, 100, 100, 20)
        check('a first lit frame outside the wizard fails', not hb['passed'] and (not hb['first_lit_in_wizard']), str(hb))
        for f in range(40, 100):
            q = t / f't_{f:05d}.png'
            if q.exists():
                Image.fromarray(black).save(q)
        check('no last picture fails', not hand_back(t, 100, 100, WIZ_SETUP + WIZ_SCROLL + 1)['passed'])
    if a.hbmame:
        import tempfile
        with tempfile.TemporaryDirectory() as t:
            stock_sets(a.hbmame, a.rom_dir, Path(t))
            check('stock HBMAME sets', all(((Path(t) / m).is_dir() for m in PARENT.values())))
    print('PASS' if ok else 'FAIL')
    return 0 if ok else 1

def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('cmd', nargs='?', choices=['gate', 'review'])
    p.add_argument('--self-test', action='store_true')
    p.add_argument('--build', type=Path)
    p.add_argument('--control', type=Path, help='a build before the change (build 45): must fail')
    p.add_argument('--handback-control', type=Path, help="gate: a build with Third Moon's white hand-back frame (b2adc2011, build 46): must fail there")
    p.add_argument('--runtime', type=Path)
    p.add_argument('--hbmame', type=Path)
    p.add_argument('--rom-dir', type=Path, required=True)
    p.add_argument('--workdir', type=Path)
    p.add_argument('--set', default='striderus01', choices=sorted(PARENT))
    p.add_argument('--jobs', type=int, default=2)
    a = p.parse_args()
    if a.self_test:
        return self_test(a)
    return {'gate': cmd_gate, 'review': cmd_review}[a.cmd](a)
if __name__ == '__main__':
    sys.exit(main())
