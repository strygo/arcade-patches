"""Render a captured ending frame with the matching jtcps1 video model."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import struct
import subprocess
import sys
ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / 'backports/striderex/rtl'))
import jtcps1_sim as J

def sha(data):
    return hashlib.sha256(data).hexdigest()

def registers(capture, frame):
    regs = {}
    for line in (capture / 'regs.tsv').read_text().splitlines():
        kind, f, t, addr, value, mask = line.split('\t')
        addr = int(addr, 16)
        if kind == 'W' and int(f) <= frame and (8388864 <= addr < 8388992):
            mask = int(mask, 16)
            regs[addr] = regs.get(addr, 0) & ~mask | int(value, 16) & mask
    if not {8388864, 8388868, 8388874, 8388966, 8388976} <= regs.keys():
        raise ValueError('incomplete video-register capture')
    return regs

def bootstrap(regs, refresh_objects=False):
    code = bytearray.fromhex('46fc270041f90011000043f900900000303cbfff22d851c8fffc')
    code += bytes.fromhex('33fc000000800030')
    for addr, value in sorted(regs.items()):
        code += struct.pack('>HHI', 13308, value, addr)
    code += struct.pack('>HHI', 13308, regs[8388874], 8388874)
    if refresh_objects:
        code += bytes.fromhex('303c7fff51c8fffe')
        code += struct.pack('>HHI', 13308, regs[8388864], 8388864)
        code += bytes.fromhex('60ee')
        return bytes(code)
    return bytes(code) + bytes.fromhex('60fe')

def freeze(a):
    out = a.out.resolve()
    out.mkdir(parents=True, exist_ok=False)
    model = a.model.resolve()
    v = model / 'cores/cps1/ver/strex'
    if sha((v / 'test.cpp').read_bytes()) != sha((ROOT / 'backports/striderex/rtl/jtcps1_sim/test.cpp').read_bytes()):
        raise ValueError('prepared model uses a different harness')
    metadata = json.loads((a.build / 'build.json').read_text())
    for m, spec in metadata['sets'].items():
        for name, digest in spec['files'].items():
            if sha((a.build / m / name).read_bytes()) != digest:
                raise ValueError('build bytes changed')
    (out / 'jtcores').symlink_to(model, target_is_directory=True)
    from types import SimpleNamespace
    J.cmd_rom(SimpleNamespace(build=a.build, rom_dir=a.rom_dir, machine=a.machine, out=out / 'sdram'))
    regs = registers(a.capture, a.frame)
    vram = (a.capture / f'vram_{a.frame:05d}.bin').read_bytes()
    if len(vram) != 196608:
        raise ValueError('incomplete graphics RAM capture')
    code = bootstrap(regs, a.refresh_objects)
    p = out / 'sdram/sdram_bank0.bin'
    bank = bytearray(p.read_bytes())
    bank[:8] = struct.pack('>II', 16744448, 256)
    bank[256:256 + len(code)] = code
    bank[1114112:1114112 + len(vram)] = vram
    p.write_bytes(bank)
    run = out / 'render'
    frame = a.render_frame
    env = dict(os.environ, STREX_FRAMES=str(frame), STREX_SHOTS=str(frame), STREX_MEMDUMP=str(frame - 1))
    p = subprocess.run(['bash', str(ROOT / 'backports/striderex/rtl/run_jtcps1_sim.sh'), 'run', str(out), str(run)], env=env)
    if p.returncode:
        raise ValueError('video model did not exit normally')
    dump = (run / f'vram_{frame - 1:05d}.bin').read_bytes()
    if dump != vram:
        raise ValueError('rendered graphics RAM differs from the capture')
    if f'done at frame {frame + 1}' not in (run / 'sim.log').read_text():
        raise ValueError('incomplete simulation')
    receipt = dict(schema='striderex-earth-render/1', passed=True, mode='frozen-video', machine=a.machine, frame=a.frame, build_files={m: s['files'] for m, s in metadata['sets'].items()}, vram_sha256=sha(vram), registers_sha256=sha(json.dumps(regs, sort_keys=True).encode()), bootstrap_sha256=sha(code), model_sha256=sha((v / 'obj_dir/sim').read_bytes()), harness_sha256=sha((v / 'test.cpp').read_bytes()), image_sha256=sha((run / f'f_{frame:05d}.png').read_bytes()), render_frame=frame, object_list_refreshed=a.refresh_objects, graphics_ram_preserved=True, exit_code=p.returncode, hardware_review_granted=False)
    (out / 'render.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print('PASS: captured video state rendered unchanged through jtcps1')

def compare(a):
    import numpy as np
    from PIL import Image, ImageDraw
    if len(a.control) != 2 or len(a.build) != 2:
        raise ValueError('both regional render pairs are required')
    rows = []
    for old, new in zip(a.control, a.build):
        control = json.loads((old / 'render.json').read_text())
        build = json.loads((new / 'render.json').read_text())
        if control['machine'] != build['machine']:
            raise ValueError('regional render pair differs')
        before = Image.open(old / 'render/f_00035.png').convert('RGB')
        after = Image.open(new / 'render/f_00035.png').convert('RGB')
        x, y = (np.array(before), np.array(after))
        changed = np.any(x != y, axis=2)
        old_rgb = np.unique(x[changed], axis=0).tolist()
        new_rgb = np.unique(y[changed], axis=0).tolist()
        visible = not np.any(changed & np.any(x != [15, 15, 15], axis=2))
        passed = int(changed.sum()) > 1000 and visible and (old_rgb == [[15, 15, 15]]) and (new_rgb == [[0, 0, 0]]) and (control['registers_sha256'] == build['registers_sha256'])
        rows.append(dict(machine=control['machine'], control=control, build=build, changed_pixels=int(changed.sum()), old_rgb=old_rgb, new_rgb=new_rgb, visible_art_unchanged=visible, passed=passed))
        if a.review and control['machine'] == 'striderua':
            a.review.mkdir(parents=True, exist_ok=True)
            before.save(a.review / 'earth-before.png')
            after.save(a.review / 'earth-after.png')
            canvas = Image.new('RGB', (1536, 480), (24, 24, 24))
            d = ImageDraw.Draw(canvas)
            for i, (im, label) in enumerate(((before, 'Before - core rendering'), (after, 'After - core rendering'))):
                d.text((i * 768 + 12, 9), label, fill='white')
                canvas.paste(im.resize((768, 448), Image.Resampling.NEAREST), (i * 768, 32))
            canvas.save(a.review / 'earth-before-after.png')
    report = dict(schema='striderex-earth-render-comparison/1', passed=all((r['passed'] for r in rows)), results=rows)
    a.receipt.write_text(json.dumps(report, indent=2) + '\n')
    print('PASS' if report['passed'] else 'FAIL', 'both core-rendered pairs; only false near-black fills differ')
    if not report['passed']:
        raise ValueError('Earth core-render comparison failed')

def self_test():
    regs = {8388874: 37184, 8388976: 63}
    code = bootstrap(regs)
    assert code.startswith(bytes.fromhex('46fc270041f90011000043f900900000303cbfff22d851c8fffc'))
    assert (49151 + 1) * 4 == 196608
    assert code.endswith(bytes.fromhex('33fc91400080010a60fe'))
    assert code.index(bytes.fromhex('33fc000000800030')) < code.index(bytes.fromhex('33fc91400080010a'))
    regs[8388864] = 37368
    refresh = bootstrap(regs, True)
    assert refresh.endswith(bytes.fromhex('303c7fff51c8fffe33fc91f80080010060ee'))
    assert len(refresh) - 18 == len(refresh) + int.from_bytes(refresh[-1:], 'big', signed=True)
    print('Earth render probe self-test PASS')

def main():
    if sys.argv[1:] == ['--self-test']:
        return self_test()
    if sys.argv[1:2] == ['compare']:
        p = argparse.ArgumentParser(description='Compare both regional core-rendered Earth frames')
        for name in ('control', 'build'):
            p.add_argument('--' + name, type=Path, action='append', required=True)
        p.add_argument('--receipt', type=Path, required=True)
        p.add_argument('--review', type=Path)
        return compare(p.parse_args(sys.argv[2:]))
    p = argparse.ArgumentParser(description=__doc__)
    for name in ('build', 'rom-dir', 'capture', 'model', 'out'):
        p.add_argument('--' + name, type=Path, required=True)
    p.add_argument('--machine', default='striderua', choices=('striderua', 'striderjr'))
    p.add_argument('--frame', type=int, default=1300)
    p.add_argument('--render-frame', type=int, default=35, choices=range(35, 91), help='allow additional scan frames for a captured object-list DMA to settle')
    p.add_argument('--refresh-objects', action='store_true', help='repeat the captured object-base write so its copied list becomes visible')
    a = p.parse_args()
    freeze(a)
if __name__ == '__main__':
    main()
