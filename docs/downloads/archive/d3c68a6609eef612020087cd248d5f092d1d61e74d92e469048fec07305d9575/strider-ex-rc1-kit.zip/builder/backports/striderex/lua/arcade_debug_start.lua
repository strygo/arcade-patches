-- Strider arcade: logged play from the built-in debug start select (P0.5).
--
-- The game's new-game code at 0x2550 picks the stage from DSWA bits 0-2
-- (the Coin A field) and the area from DSWB bits 3-6 when the debug flag
-- 0xFF0C86 is set and IN0 bit 2 (SERVICE1) is held at game start. The input reader at 0x650 rewrites
-- 0xFF0C86 every frame from IN0 bit 6, the cabinet's test switch (MAME's
-- "Service Mode" field), so the hardware route is: test switch and service
-- button held while START is pressed. Switches are active low; the game reads
-- them inverted. This script sets those DIP bits, coins up, holds the test
-- switch and SERVICE1 across START, and logs the stage/area bytes and every
-- sound command. Nothing in RAM is written; the one research control below
-- only changes what a single instruction reads.
--
-- The VBlank handler (0x4D2 -> 0x9CC) also sets 0xFF8E76 = test switch AND
-- DSWB bit 7; the player hit handlers (0x10CDA, 0x11FC0, 0x126CE, ...) skip
-- damage while it is set. STREX_INVINCIBLE=1 sets DSWB bit 7 and keeps the
-- test switch held for the whole game: the developers' own invincibility.
--
-- Environment: STREX_STAGE (0-4 internal), STREX_AREA (0-15), STREX_END
-- (frame), STREX_INVINCIBLE (1 = debug invincibility; STREX_INVINCIBLE_END
-- = frame to release the test switch), STREX_PREFIX for
-- outputs, STREX_SHOTS "frame,frame,...", STREX_INPUTS for play after the
-- start: "a-b:TOKEN;a-b@period/duty:TOKEN;..." holds TOKEN (an input token
-- such as P1_JOYSTICK_RIGHT or P1_BUTTON2) on frames a..b, or only while
-- (frame-a) mod period < duty. STREX_CAMERA_EVERY=n logs the camera
-- (0xFF10D2/D6) and 0xFF0FF4/F8 (a camera target, not the player) every n
-- frames. STREX_CLIMB_OVERRIDE=frame is a research control: from that frame,
-- only the camera-Y read by St. Petersburg's climb test (cmpi.w at 0xF192)
-- returns 0x400, as if the camera had climbed; nothing else sees it.
local m=manager.machine
local cpu=m.devices[':maincpu']
local sp=cpu.spaces['program']
local screen=m.screens[':screen']
local prefix=assert(os.getenv('STREX_PREFIX'))
local stage=assert(tonumber(os.getenv('STREX_STAGE') or '0'),'STREX_STAGE must be a number')
local area=assert(tonumber(os.getenv('STREX_AREA') or '0'),'STREX_AREA must be a number')
local last=tonumber(os.getenv('STREX_END') or '3000')
local invincible=os.getenv('STREX_INVINCIBLE')=='1'
local invincible_end=tonumber(os.getenv('STREX_INVINCIBLE_END') or '') or math.huge
local camera_every=tonumber(os.getenv('STREX_CAMERA_EVERY') or '0')
local climb_override=tonumber(os.getenv('STREX_CLIMB_OVERRIDE') or '')
local inputs={}
for item in string.gmatch(os.getenv('STREX_INPUTS') or '','[^;]+') do
 local a,b,per,duty,tok=string.match(item,'^%s*(%d+)-(%d+)@(%d+)/(%d+):([%w_]+)%s*$')
 if not a then a,b,tok=string.match(item,'^%s*(%d+)-(%d+):([%w_]+)%s*$') end
 assert(a,'bad STREX_INPUTS item: '..item)
 inputs[#inputs+1]={a=tonumber(a),b=tonumber(b),per=tonumber(per),duty=tonumber(duty),tok=tok}
end
local shots={}
for s in string.gmatch(os.getenv('STREX_SHOTS') or '','%d+') do shots[tonumber(s)]=true end
local log=assert(io.open(prefix..'_log.tsv','w'))
log:write('frame\tkind\tvalue\n')
local f=0

-- Active low: DSWA bits 0-2 = stage, DSWB bits 3-6 = area; other bits keep
-- their defaults (the stage field also sets Coin A, hence several coins).
local function set_bits(pname,bits,value)
 local raw=0
 for _,field in pairs(m.ioport.ports[pname].fields) do
  if field.mask&bits~=0 then
   field.user_value=(field.defvalue&field.mask&~bits)|(~value&field.mask&bits)
  end
  raw=raw|(field.user_value&field.mask)
 end
 log:write(string.format('0\t%s_raw\t%02x\n',pname:sub(2):lower(),raw))
end
local function set_dips()
 set_bits(':DSWA',0x07,stage)
 set_bits(':DSWB',invincible and 0xf8 or 0x78,(area<<3)|(invincible and 0x80 or 0))
end
local test_switch
for _,field in pairs(m.ioport.ports[':IN0'].fields) do if field.mask==0x40 then test_switch=field end end
assert(test_switch,'IN0 bit 6 (test switch) field not found')

local fields={}
for _,port in pairs(m.ioport.ports) do for name,field in pairs(port.fields) do
 fields[m.ioport:input_type_to_token(field.type,field.player)]=field
end end

local last_cmd=nil
local taps={}
taps[1]=sp:install_write_tap(0x800180,0x800181,'strex_snd',function(offset,data,mask)
 local v=(offset==0x800180) and (data>>8)&0xff or data&0xff
 if mask&0x00ff~=0 or offset==0x800181 then v=data&0xff end
 if v~=0xff and v~=last_cmd then log:write(string.format('%d\tsound\t%02x\n',f,v)) end
 last_cmd=v
end)
if climb_override then
 taps[2]=sp:install_read_tap(0xff10d6,0xff10d7,'strex_climb',function(offset,data,mask)
  if f>=climb_override and cpu.state['CURPC'].value==0xf192 then
   log:write(string.format('%d\tclimb_override\t%04x\n',f,data))
   return 0x0400
  end
 end)
end
_G.strex_taps=taps

local function hold(token,on) local fld=assert(fields[token],token); if on then fld:set_value(1) else fld:clear_value() end end

local prev_stage,prev_area,prev_inv,prev_lives=-1,-1,-1,-1
emu.register_frame_done(function()
 f=f+1
 if f==1 then set_dips() end
 hold('COIN1',(f>=200 and f<=360) and (f-200)%40<8)
 hold('SERVICE1',f>=380 and f<=440)
 test_switch.user_value=(f>=380 and (f<=440 or (invincible and f<invincible_end))) and 0 or 0x40
 hold('START1',f>=400 and f<=410)
 local want={}
 for _,e in ipairs(inputs) do
  local on=f>=e.a and f<=e.b and (not e.per or (f-e.a)%e.per<e.duty)
  want[e.tok]=want[e.tok] or on
 end
 for tok,on in pairs(want) do hold(tok,on) end
 if camera_every>0 and f%camera_every==0 then
  log:write(string.format('%d\tcamera\t%04x,%04x\tplayer\t%04x,%04x\n',f,sp:read_u16(0xff10d2),sp:read_u16(0xff10d6),sp:read_u16(0xff0ff4),sp:read_u16(0xff0ff8)))
 end
 local st=sp:read_u8(0xff0cb2);local ar=sp:read_u8(0xff0cce)
 if st~=prev_stage or ar~=prev_area then
  log:write(string.format('%d\tstage_area\t%d,%d\n',f,st,ar));prev_stage,prev_area=st,ar
 end
 local inv=sp:read_u8(0xff8e76)
 if inv~=prev_inv then log:write(string.format('%d\tinvincible\t%d\n',f,inv));prev_inv=inv end
 local lives=sp:read_u8(0xff0ca8)
 if lives~=prev_lives then log:write(string.format('%d\tlives\t%d\n',f,lives));prev_lives=lives end
 if shots[f] then screen:snapshot(string.format('%s_%05d.png',prefix,f)) end
 log:flush()
 if f>=last then m:exit() end
end)
