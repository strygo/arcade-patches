"""Verify a sealed kit from a fresh copy with isolated standard-library Python."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / 'release'))
import private_mister as PM

def main():
    p = argparse.ArgumentParser(description=__doc__)
    for name in ('kit', 'workdir', 'receipt'):
        p.add_argument('--' + name, type=Path, required=True)
    p.add_argument('--python', default=sys.executable)
    a = p.parse_args()
    record = PM.verify(a.kit.resolve())
    work = a.workdir.resolve()
    work.mkdir(parents=True, exist_ok=False)
    target = work / 'kit'
    shutil.copytree(a.kit.resolve(), target)
    copied = PM.verify(target)
    if copied != record:
        raise ValueError('sealed copy differs')
    bootstrap = "import sys,runpy;from pathlib import Path;root=Path(sys.argv[1]).resolve();sys.path.insert(0,str(root));sys.argv=[str(root/'verify_kit.py'),'--root',str(root)];runpy.run_path(sys.argv[0],run_name='__main__')"
    run = subprocess.run([a.python, '-I', '-B', '-c', bootstrap, str(target)], cwd=work, capture_output=True, text=True)
    output = run.stdout + run.stderr
    (work / 'verify.log').write_text(output)
    if run.returncode:
        raise ValueError('isolated copied verifier failed: ' + output[-2000:])
    version = subprocess.run([a.python, '--version'], capture_output=True, text=True, check=True).stdout.strip()
    report = dict(schema='striderex-private-portable/1', passed=True, test_id=record['test_id'], source_sha256=record['source_sha256'], python_version=version, isolated=True, copied_export_verified=True, checkout_independent_working_directory=True, exit_code=run.returncode, isolated_bootstrap_adds_only_copied_kit_to_import_path=True, output_sha256=hashlib.sha256(output.encode()).hexdigest(), hardware_review_granted=False)
    a.receipt.write_text(json.dumps(report, indent=2) + '\n')
    shutil.rmtree(target)
    print('PASS: independent sealed copy on', version, 'with -I -B')
if __name__ == '__main__':
    main()
