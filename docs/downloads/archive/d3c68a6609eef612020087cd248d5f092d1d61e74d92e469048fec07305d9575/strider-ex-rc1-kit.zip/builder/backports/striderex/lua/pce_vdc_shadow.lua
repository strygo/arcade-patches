-- PC Engine VDC/VCE state mirror for Strider EX source captures.
--
-- MAME keeps the HuC6270's VRAM and the HuC6260's palette private, so this
-- script mirrors them from power-on by tapping every CPU write to the two
-- chips: ordinary stores to the I/O page (0x1FE000-0x1FE7FF) and the ST0/ST1/
-- ST2 instructions, which MAME routes to the CPU's io space. The mirror
-- follows MAME's huc6270.cpp/huc6260.cpp register semantics, including
-- VRAM-VRAM DMA and the SATB copy. scripts/pce_vdc.py rebuilds frames from
-- the dumps and checks them against MAME's own screenshot, so a mirror
-- error shows up as a pixel mismatch rather than silently.
--
-- The existing Strider console probe (inputs, research controls, CD_PLAY
-- logging) runs unchanged alongside this script: STRIDEREX_BASE_PROBE names
-- the copy to load. This script registers its frame callback first, so its
-- work for a frame happens before the base probe can exit on that frame.
--
-- STRIDEREX_SCENE_CAPTURE = "start:end:step[,start:end:step...]" selects the
-- frames that get a state dump (<prefix>_<frame>_scene.vdc). The dump holds
-- the state at the moment the following picture starts to be drawn: it is
-- written at the first chip write once the beam reaches active display
-- (line 16), or at the next frame_done if nothing is written. frame_done
-- fires a few lines into vblank, and games still set up the coming picture
-- after it (seen in the St. Petersburg briefing), so dumping at frame_done
-- itself would miss those writes. The dump's screenshot
-- (<prefix>_<frame>_scene.png) is taken at that next frame_done, when MAME's
-- snapshot holds the picture drawn from the dumped state.
--
-- Writes made while that picture is being drawn can tear it. Active display
-- starts at raster VSW+VDS-4 (VPR; line 16 for the cinematics' 0x0F02, 24
-- for gameplay's 0x1603) and lasts VDW+1 lines. They are counted per dump in the index,
-- and register writes are logged with their vpos, so a renderer mismatch on
-- such a frame is classified rather than mistaken for a mirror error.

local m=manager.machine
local cpu=m.devices[':maincpu']
local prog=cpu.spaces['program']
local iosp=cpu.spaces['io']
local screen=m.screens[':screen']
local prefix=assert(os.getenv('VH2_TRACE_PREFIX'))

local want={}
for a,b,s in string.gmatch(os.getenv('STRIDEREX_SCENE_CAPTURE') or '','(%d+):(%d+):(%d+)') do
 for n=tonumber(a),tonumber(b),tonumber(s) do want[n]=true end
end

local vram={};for i=0,0x7fff do vram[i]=0 end
local reg={};for i=0,31 do reg[i]=0 end
local ri=0
local pal={};for i=0,511 do pal[i]=0 end
local vce_addr,vce_ctrl=0,0
local sat={};for i=0,255 do sat[i]=0 end
local dvssr_written=false
local inc={[0]=1,32,64,128}
local f=0
local writes={}   -- raster-relevant register writes since the last frame_done
local stats={vdc=0,vce=0,dma=0,satb=0}
local disp={vram=0,reg=0,vce=0}  -- writes during active display since the last frame_done
-- MAME 0.288's Lua screen object has no vpos/hpos; derive the beam position
-- from the time until the next (0,0). Raster lines count from the top of the
-- full frame, the same coordinates as the screen's visible area (18-259).
local LINES=math.floor(screen.frame_period/screen.scan_period+0.5)
local function beam()
 local t=screen:time_until_pos(0,0)/screen.scan_period
 local pos=(LINES-t)%LINES
 local v=math.floor(pos)
 return v,math.floor((pos-v)*1000)  -- line, thousandths of the line
end
local function display_first() local vpr=reg[0x0c];return ((vpr&0x1f)+1)+(((vpr>>8)&0xff)+2)-4 end
local function display_last() return display_first()+(reg[0x0d]&0x1ff) end
local function in_display() local v=beam();return v>=display_first() and v<=display_last() end

-- Optional writer log (STRIDEREX_LOG_VRAM="lo-hi@f0-f1", word addresses):
-- every VRAM word write in [lo,hi] during frames [f0,f1] is logged with the
-- CPU PC and bank registers, to find the code that streams map data.
local vlog_lo,vlog_hi,vlog_f0,vlog_f1=string.match(os.getenv('STRIDEREX_LOG_VRAM') or '','(%x+)%-(%x+)@(%d+)%-(%d+)')
local vlog=nil
if vlog_lo then
 vlog_lo,vlog_hi=tonumber(vlog_lo,16),tonumber(vlog_hi,16);vlog_f0,vlog_f1=tonumber(vlog_f0),tonumber(vlog_f1)
 vlog=assert(io.open(prefix..'_vram_writers.tsv','w'))
 vlog:write('frame\tpc\tmpr\taddr\tvalue\n')
end
local function log_vram(a,v)
 if vlog and f+1>=vlog_f0 and f+1<=vlog_f1 and a>=vlog_lo and a<=vlog_hi then
  local mpr={}
  for k=0,7 do mpr[#mpr+1]=string.format('%02x',cpu.state['MPR'..k].value) end
  vlog:write(string.format('%d\t%04x\t%s\t%04x\t%04x\n',f+1,cpu.state['PC'].value,table.concat(mpr,''),a,v))
 end
end

-- A requested dump; serialized once the coming picture starts (see header).
local pending=nil
local serialize  -- defined below
local function picture_started()
 if pending and not pending.done then
  local l=beam()
  if l>=pending.display_first and l<pending.request_line then serialize(l) end
 end
end

local function dma()
 local dcr=reg[0x0f]
 local di=(dcr&8)~=0 and -1 or 1
 local si=(dcr&4)~=0 and -1 or 1
 local s,d,l=reg[0x10],reg[0x11],reg[0x12]
 repeat
  local x=s<=0x7fff and vram[s] or 0
  if d<=0x7fff then vram[d]=x end
  s=(s+si)&0xffff;d=(d+di)&0xffff;l=(l-1)&0xffff
 until l==0xffff
 reg[0x10],reg[0x11],reg[0x12]=s,d,l
 stats.dma=stats.dma+1
 if in_display() then disp.vram=disp.vram+1 end
end

local function vdc_write(offset,data)
 picture_started()
 stats.vdc=stats.vdc+1
 local o=offset&3
 if o==0 then ri=data&0x1f return end
 if o==1 then return end
 local hi=(o==3)
 local r=ri
 local v=hi and ((reg[r]&0x00ff)|(data<<8)) or ((reg[r]&0xff00)|data)
 reg[r]=v
 if r==2 then
  if hi then
   local a=reg[0]
   if a<=0x7fff then vram[a]=v end
   if vlog then log_vram(a,v) end
   reg[0]=(a+inc[(reg[5]>>11)&3])&0xffff
   if in_display() then disp.vram=disp.vram+1 end
  end
 elseif r==0x12 then
  if hi then dma() end
 elseif r==0x13 then
  dvssr_written=true
 end
 if r>=5 and r<=0x0f or r==0x13 then
  local bv,bh=beam()
  writes[#writes+1]=string.format('%d\t%d\t%d\t%02x\t%d\t%04x',f,bv,bh,r,hi and 1 or 0,v)
  if in_display() then disp.reg=disp.reg+1 end
 end
end

local function vce_write(offset,data)
 picture_started()
 stats.vce=stats.vce+1
 if in_display() then disp.vce=disp.vce+1 end
 local o=offset&7
 if o==0 then vce_ctrl=data
 elseif o==2 then vce_addr=(vce_addr&0x100)|data
 elseif o==3 then vce_addr=(vce_addr&0xff)|((data&1)<<8)
 elseif o==4 then pal[vce_addr]=(pal[vce_addr]&0x100)|data
 elseif o==5 then pal[vce_addr]=(pal[vce_addr]&0xff)|((data&1)<<8);vce_addr=(vce_addr+1)&0x1ff
 end
end

-- MAME discards errors raised inside a tap handler, which would leave the
-- mirror silently stale. Each handler runs under pcall; the first error is
-- kept, printed as STREX_TAP_ERROR at the next frame_done, and the run stops.
local tap_error=nil
local function guarded(fn)
 return function(offset,data,mask)
  local ok,err=pcall(fn,offset,data)
  if not ok and not tap_error then tap_error=tostring(err) end
 end
end
local taps={}
taps[#taps+1]=prog:install_write_tap(0x1fe000,0x1fe3ff,'strex_vdc',guarded(vdc_write))
taps[#taps+1]=prog:install_write_tap(0x1fe400,0x1fe7ff,'strex_vce',guarded(vce_write))
taps[#taps+1]=iosp:install_write_tap(0x0000,0x0003,'strex_vdc_st',guarded(vdc_write))
_G.strex_taps=taps  -- anchor: unreferenced tap handles are garbage-collected

local function pack16(t,first,count)
 local out={}
 for i=first,first+count-1,256 do
  local n=math.min(256,first+count-i)
  out[#out+1]=string.pack('<'..string.rep('I2',n),table.unpack(t,i,i+n-1))
 end
 return table.concat(out)
end

local log=assert(io.open(prefix..'_scene_writes.tsv','w'))
log:write('dump_frame\tline\tline_permille\treg\thi\tvalue\n')
local index=assert(io.open(prefix..'_scene_index.tsv','w'))
index:write('frame\ttime\tvce_ctrl\tdvssr_pending\tvdc_writes\tvce_writes\tdma\tsatb\tdisplay_vram\tdisplay_reg\tdisplay_vce\trequest_line\tserialize_line\n')

-- Diagnostic only (STRIDEREX_VERIFY_VRAM=1): read the real VRAM back through
-- the VDC read port (MARR/VRR) and count words that differ from the mirror.
-- Reading moves MARR and the register select, so it can disturb the game;
-- never enable it for catalog captures.
local verify=os.getenv('STRIDEREX_VERIFY_VRAM')=='1'
local function verify_vram()
 local saved=ri
 prog:write_u8(0x1fe000,1);prog:write_u8(0x1fe002,0);prog:write_u8(0x1fe003,0)
 prog:write_u8(0x1fe000,2)
 local bad,first=0,nil
 for a=0,0x7fff do
  local lo=prog:read_u8(0x1fe002);local hi=prog:read_u8(0x1fe003)
  local v=lo|(hi<<8)
  if v~=vram[a] then bad=bad+1;first=first or a end
 end
 prog:write_u8(0x1fe000,saved)
 print(string.format('VERIFY frame=%d mismatched_words=%d first=%s',f,bad,first and string.format('%04x',first) or '-'))
end

serialize=function(line)
 local p=pending
 local satsrc={}
 for i=0,255 do satsrc[i]=vram[(reg[0x13]+i)&0x7fff] end
 local fh=assert(io.open(string.format('%s_%05d_scene.vdc',prefix,p.frame),'wb'))
 fh:write('SXVDC1\0\0',string.pack('<I4I4',p.frame,vce_ctrl))
 fh:write(pack16(reg,0,32),pack16(pal,0,512),pack16(sat,0,256),pack16(satsrc,0,256),pack16(vram,0,0x8000))
 fh:close()
 p.done=true;p.serialize_line=line;p.vce_ctrl=vce_ctrl;p.dvssr=dvssr_written and 1 or 0
end

local function finish()
 -- One frame after the request: the snapshot now holds the picture drawn
 -- from the dumped state, and `writes`/`disp` cover that picture's interval.
 if not pending.done then serialize(beam()) end
 local p=pending;pending=nil
 screen:snapshot(string.format('%s_%05d_scene.png',prefix,p.frame))
 for _,w in ipairs(writes) do log:write(w,'\n') end
 log:flush()
 index:write(string.format('%d\t%.9f\t%02x\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\n',p.frame,p.time,p.vce_ctrl,p.dvssr,
  stats.vdc,stats.vce,stats.dma,stats.satb,disp.vram,disp.reg,disp.vce,p.request_line,p.serialize_line))
 index:flush()
end

emu.register_frame_done(function()
 f=f+1
 for _,tap in ipairs(taps) do assert(tap) end
 if tap_error then
  print('STREX_TAP_ERROR frame='..f..' '..tap_error)
  m:exit()
  return
 end
 if pending then finish() end
 writes={};disp.vram,disp.reg,disp.vce=0,0,0
 -- SATB copy for the coming picture, as huc6270.cpp handle_vblank(); done
 -- before the dump so the dumped table is the one that picture uses.
 if dvssr_written or (reg[0x0f]&0x10)~=0 then
  local d=reg[0x13]
  for i=0,252,4 do
   sat[i]=vram[(d+i)&0x7fff]&0x3ff
   sat[i+1]=vram[(d+i+1)&0x7fff]&0x3ff
   sat[i+2]=vram[(d+i+2)&0x7fff]&0x7ff
   sat[i+3]=vram[(d+i+3)&0x7fff]
  end
  dvssr_written=false
  stats.satb=stats.satb+1
 end
 if want[f] then
  if verify then verify_vram() end
  pending={frame=f,time=m.time:as_double(),request_line=beam(),display_first=display_first(),done=false}
 end
end)

-- STRIDEREX_HOLD = a comma list of "timer", "health" and "lives": research
-- controls for long reference runs (P0.3). While a stage is in play
-- (0x1F00C7 = 8):
--   timer   the stage clock's minutes digit 0x1F0D13 (BCD, 3:00 counting
--           down; 0x68:0x506C) goes back to 3 whenever it reaches 1 or 2, so
--           TIME OVER never comes. (Until 2026-10-13 this was named "health",
--           a misreading; captures made with "health" then are "timer" now.)
--   health  Hiryu's health, zero page $C8 = 0x1F00C8 (3 per life, one less a
--           hit; MEASURED in the desert, 2026-10-13), topped up to 3; a death
--           that bypasses health (seen once, probably a fall) still happens
--   lives   0x1F00D4 kept at 2 or more: a death respawns at the last checkpoint
local hold={}
for item in string.gmatch(os.getenv('STRIDEREX_HOLD') or '','[^,]+') do
 assert(item=='timer' or item=='health' or item=='lives','STRIDEREX_HOLD: unknown '..item);hold[item]=true
end
if next(hold) then
 emu.register_frame_done(function()
  if prog:read_u8(0x1f00c7)~=8 then return end
  local mm=prog:read_u8(0x1f0d13)
  if hold.timer and mm>0 and mm<3 then prog:write_u8(0x1f0d13,3) end
  local hp=prog:read_u8(0x1f00c8)
  if hold.health and hp>0 and hp<3 then prog:write_u8(0x1f00c8,3) end
  if hold.lives and prog:read_u8(0x1f00d4)<2 then prog:write_u8(0x1f00d4,2) end
 end)
end

local ramrec=os.getenv('STRIDEREX_RAMREC_LUA')
if ramrec and ramrec~='' then dofile(ramrec) end

local base=os.getenv('STRIDEREX_BASE_PROBE')
if base and base~='' then dofile(base) end
