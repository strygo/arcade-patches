"""Strider EX: the boss scenes (manifests/boss_scenes.json), one for each of the eight PC Engine portraits."""
import argparse
import hashlib
import json
import re
import struct
import sys
from pathlib import Path
import numpy as np
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import cps1_gfx as G
ROOT = HERE.parents[2]
MANIFEST = ROOT / 'backports/striderex/manifests/boss_scenes.json'
CUES = ROOT / 'backports/striderex/manifests/ex_pack_cues.json'
REVIEW = ROOT / 'backports/striderex/manifests/portrait_text_review.json'
RECEIPT = ROOT / 'backports/striderex/manifests/portraits_measured.json'
TRANSCRIPTS = ROOT / 'backports/striderex/manifests/portrait_transcripts.json'
HZ = 59.637
BOSS_GRIDS = ROOT / 'backports/striderex/assets/boss_font/ja_glyphs.txt'
SCENE_CODES = (46528, 47327)
UI_SLOT = 12
PT_SLOT = 24
PLATE_PEN, STRIP_PEN = (0, 14)
PAD = 8
SCREEN = (64, 16)
CLIP_X = 448
FADE_IN = 12
HOLD_FROM = 19
FADE_OUT = 10
HIDE = 17
NEXT = 28
MUSIC_WAIT = 24
FADE_CMD = 252
FADE_TICKS = 23
STOP_CMD = 241
RESTART = {'site': 0, 'music_byte': 1, 'desert': 2}
QUEUE_SIG = bytes.fromhex('4a2d8c89 6700000a 4a2d8c84 67000018 3c2d8c28'.replace(' ', ''))
FULL = 16
LAYER_HIDE = 5440
LAYER_PAGE = 1344
GAME_PAL = 37184
PAL_BUFS = (37312, 37336)
OBJ_LISTS = (37360, 37368)
BACKDROP = 3071
SCENE_RAM = (9551872, 9568255)
STOCK_STRIP = 1273
EN_ROW_H = 10
EN_COLORS = {0: 62259, 1: 65262, 2: 64716, 3: 64170}
PT_W, PT_H = (120, 80)
FRAME = 4
REGION = {'striderua': 'en', 'striderjr': 'ja'}
FORMS = {'striderua': {'siberia': dict(stage=1, sub0=38022), 'aerial': dict(stage=3, sub0=40040)}, 'striderjr': {'siberia': dict(stage=1, sub0=37884), 'aerial': dict(stage=3, sub0=39902)}}
STOCK_PAGE_SHA256 = {('striderua', 'siberia'): 'e3d9973ddadd47ad593b70b0eba9a145770f7d8adb4b97bceb2dcbacb75c88c2', ('striderua', 'aerial'): 'ddfcc46841dfe915fafe3f85f6709ded2d58bfb66634cf6463c3e062ebd60a5b', ('striderjr', 'siberia'): '7da8bc34be09a228e5d19f922e451576cc31907d5ff71550557aa3f553bbc00d', ('striderjr', 'aerial'): 'e30a96caa2663e347af5e58590ffda5a056bd75bfc9d1974775f898057735e2c'}
SUB0 = re.compile(b'\\x22\\x7c(....)\\x70\\x00\\x30\\x2d\\x8c\\x1a\\xd0\\x40\\x30\\x31\\x00\\x00\\x4e\\xb9(....)\\x4e\\xb9....\\x4e\\xb9....\\x22\\x7c(....)\\x61\\x00..\\x22\\x7c(....)\\x61\\x00..\\x22\\x7c(....)\\x61\\x00', re.S)
STRIP_INIT = re.compile(b'\\x24\\x7c(....)\\x70\\x00\\x10\\x28\\x00\\x06\\xe9\\x48\\x31\\x72\\x00\\x00\\x00\\x30', re.S)
TEXT_PAL = re.compile(b'\\x26\\x7c(....)\\x22\\x7c\\x00\\x91\\x44\\x00\\x43\\xe9\\x03\\xc0', re.S)
SPAWNER = bytes.fromhex('72003200 0241ff00 ee49 323b1006 4efb1002'.replace(' ', ''))
LAYER_DIR = 524288

def manifest():
    return json.loads(MANIFEST.read_text())

def W(img, a):
    return struct.unpack('>H', bytes(img[a:a + 2]))[0]

def L(img, a):
    return struct.unpack('>I', bytes(img[a:a + 4]))[0]

def stock_image(rom_dir, machine):
    import respawn_fix as RF
    files = {q.name: q.read_bytes() for q in (Path(rom_dir) / machine).iterdir() if q.is_file()}
    return RF.compose(files, RF.SETS[machine])

def stock_gfx(rom_dir):
    import subtitle_ex as SX
    return SX.stock_gfx(Path(rom_dir) / 'striderua')

def records(img, table, page):
    """The records of one page of a record table: [{off, cols, rows, attr, codes (column-major)}] (0xA434's format)."""
    a = table + W(img, table + 2 * page)
    out = []
    while True:
        off, c1, r1, attr = (W(img, a + 2 * i) for i in range(4))
        a += 8
        n = (c1 + 1) * (r1 + 1)
        out.append(dict(off=off, cols=c1 + 1, rows=r1 + 1, attr=attr, codes=[W(img, a + 2 * i) for i in range(n)]))
        a += 2 * n
        if W(img, a) != 65535:
            return out
        a += 2
SIZE = {'s1': 8, 's2': 16, 's3': 32}
ORIGIN = {'s1': (0, 272), 's2': (64, 784), 's3': (64, 1808)}

def cell_of(layer, off):
    e = off // 4
    if layer == 's1':
        return (e >> 5 & 63, e & 31 | e >> 6 & 32)
    if layer == 's2':
        return (e >> 4 & 63, e & 15 | e >> 6 & 48)
    return (e >> 3 & 63, e & 7 | e >> 6 & 56)

def stage_palettes(img, stage):
    s1 = L(img, L(img, LAYER_DIR + 0) + 18 * stage + 14)
    s2 = L(img, L(img, LAYER_DIR + 4) + 18 * stage + 14)
    s3 = L(img, L(img, LAYER_DIR + 8) + 14 * stage + 10)
    return [[W(img, p + 2 * i) for i in range(512)] for p in (s1, s2, s3)]

def stock_form(img, machine, name):
    """One stock form: its tables (checked against the sub-state 0 code), records, strips and colors."""
    f = FORMS[machine][name]
    m = SUB0.match(bytes(img), f['sub0'])
    if not m:
        raise SystemExit(f"boss_scene: {machine} {name}: no page draw at {f['sub0']:#x}")
    strips_t, spawner, panel_t, portrait_t, text_t = (int.from_bytes(m.group(k), 'big') for k in range(1, 6))
    if bytes(img[spawner:spawner + len(SPAWNER)]) != SPAWNER:
        raise SystemExit(f'boss_scene: {machine}: the strip spawner at {spawner:#x} is not the stock one')
    hits = list(STRIP_INIT.finditer(bytes(img[:524288])))
    if len(hits) != 1:
        raise SystemExit(f'boss_scene: {machine}: the strip init matches {len(hits)} times')
    params = int.from_bytes(hits[0].group(1), 'big')
    tp = list(TEXT_PAL.finditer(bytes(img[:524288])))
    if len(tp) != 1:
        raise SystemExit(f'boss_scene: {machine}: the text palette load matches {len(tp)} times')
    text_pal = int.from_bytes(tp[0].group(1), 'big')
    word = W(img, strips_t)
    strips = []
    for k in range((word >> 8) + 1):
        p = params + 16 * ((word & 255) + k)
        life, vx, vy, x, y = (W(img, p), L(img, p + 2), L(img, p + 6), W(img, p + 10), W(img, p + 12))
        sv = lambda v: v - (1 << 32) if v & 2147483648 else v
        strips.append(dict(param=(word & 255) + k, life=life, vx=sv(vx), vy=sv(vy), x=x, y=y))
    pals = stage_palettes(img, f['stage'])
    pals[0][16 * 30:16 * 31] = [W(img, text_pal + 2 * i) for i in range(16)]
    tl = 's1' if machine == 'striderua' else 's2'
    rows = []
    for r in records(img, text_t, 0):
        c, rw = cell_of(tl, r['off'])
        if r['rows'] != 1:
            raise SystemExit(f"boss_scene: {machine} {name}: a text record of {r['rows']} rows")
        n = SIZE[tl]
        rows.append(dict(x=c * n - ORIGIN[tl][0], y=rw * n - ORIGIN[tl][1], col=c, attr=r['attr'], codes=r['codes'], width=n * r['cols']))
    return dict(name=name, machine=machine, stage=f['stage'], tables=dict(strips=strips_t, panel=panel_t, portrait=portrait_t, text=text_t, params=params, text_palette=text_pal), strip_word=word, strips=strips, panel=records(img, panel_t, 0), portrait=records(img, portrait_t, 0), rows=rows, text=records(img, text_t, 0), text_layer=tl, pals=dict(s1=pals[0], s2=pals[1], s3=pals[2]))

def tile_pens(gfx, layer, code, col=0):
    """Stock tile pens (ST24M1: SCROLL1 and SCROLL3 in bank 1 at 2 MB, sprites and SCROLL2 in bank 0)."""
    if layer == 's1':
        return G.get_tile(gfx, 2097152 + 64 * (code & 32767), 8, col & 1)
    if layer == 's2' or layer == 'obj':
        return G.get_tile(gfx, 128 * code & 2097151, 16)
    return G.get_tile(gfx, 2097152 + 512 * (code & 2047), 32)

def record_image(gfx, layer, recs, pal):
    """Records -> (screen x, y, colors HxW with -1 transparent) of their bounding box."""
    n = SIZE[layer]
    cells = []
    for r in recs:
        c0, r0 = cell_of(layer, r['off'])
        k = 0
        for c in range(r['cols']):
            for rr in range(r['rows']):
                p = tile_pens(gfx, layer, r['codes'][k], c0 + c)
                k += 1
                if r['attr'] & 32:
                    p = p[:, ::-1]
                if r['attr'] & 64:
                    p = p[::-1, :]
                cells.append(((c0 + c) * n - ORIGIN[layer][0], (r0 + rr) * n - ORIGIN[layer][1], p, r['attr'] & 31))
    x0, y0 = (min((c[0] for c in cells)), min((c[1] for c in cells)))
    x1, y1 = (max((c[0] for c in cells)) + n, max((c[1] for c in cells)) + n)
    img = np.full((y1 - y0, x1 - x0), -1, np.int64)
    for x, y, p, slot in cells:
        col = np.array([pal[16 * slot + v] for v in range(16)])
        img[y - y0:y - y0 + n, x - x0:x - x0 + n] = np.where(p == 15, -1, col[p])
    return (x0, y0, img)

def _paste(scr, x, y, img):
    h, w = img.shape
    for yy in range(h):
        for xx in range(w):
            if img[yy, xx] >= 0 and 0 <= x + xx < scr.shape[1] and (0 <= y + yy < scr.shape[0]):
                scr[y + yy, x + xx] = img[yy, xx]

def stock_page_image(gfx, form):
    """The stock page as its layers show it (black screen, SCROLL1 under SCROLL2 under SCROLL3), 384x224 colors."""
    scr = np.full((224, 384), 61440, np.int64)
    tl = form['text_layer']
    _paste(scr, *record_image(gfx, tl, form['text'], form['pals'][tl]))
    _paste(scr, *record_image(gfx, 's2', form['panel'], form['pals']['s2']))
    _paste(scr, *record_image(gfx, 's3', form['portrait'], form['pals']['s3']))
    return scr

class Font:
    """USA the arcade 8x8 font (SCROLL1 0x7000 + character); Japan the arcade 16x16 dialogue font (SCROLL2 0x3620 +"""

    def __init__(self, gfx):
        import subtitle_ex as SX
        self.gfx, self.SX = (gfx, SX)
        self.caption, _ = SX.read_grids(SX.JA_GRIDS)
        self.boss, _ = SX.read_grids(BOSS_GRIDS)
        self.marks, _ = SX.read_grids(SX.EN_GRIDS)
        self.lower, _ = SX.read_grids(SX.EN_LOWER, SX.EN_LOWER_SHAPE)

    def en(self, ch, col):
        """EN_ROW_H x 8 pens (15 transparent): the arcade 8x8 font's capitals, digits and marks (SCROLL1 0x7000 +"""
        out = np.full((EN_ROW_H, 8), 15, np.int64)
        if ch in self.SX.EN_CODE:
            out[:8] = tile_pens(self.gfx, 's1', 28672 + self.SX.EN_CODE[ch], col)
        elif ch in self.marks:
            out[:8] = self.marks[ch]
        elif ch in self.lower:
            out[:] = self.lower[ch]
        else:
            raise SystemExit(f'boss_scene: "{ch}" is not in the arcade 8x8 font, the drawn marks or the lower case')
        return out

    def ja(self, ch):
        c = self.SX.JA_EQUIV.get(ch, ch)
        if c in self.SX.JA_ARCADE:
            return (tile_pens(self.gfx, 's2', self.SX.JA_ARCADE[c]), f'arcade {self.SX.JA_ARCADE[c]:#06x}')
        if ch in self.caption:
            return (self.caption[ch], 'caption glyph (approved 2026-10-10)')
        if ch in self.boss:
            return (self.boss[ch], 'boss glyph (approved 2026-10-21)')
        raise SystemExit(f'boss_scene: no glyph for "{ch}" (U+{ord(ch):04X}): draw it with boss_glyphs.py')

def text_row_image(font, form, k, text, region):
    """Row k of the form with new text: (screen x, y, colors with -1 transparent, sources)."""
    row = form['rows'][k]
    pal = form['pals'][form['text_layer']]
    col = np.array([pal[16 * (row['attr'] & 31) + v] for v in range(16)])
    if region == 'en':
        img = np.full((EN_ROW_H, 8 * len(text)), -1, np.int64)
        for i, ch in enumerate(text):
            p = font.en(ch, row['col'] + i)
            if not set(np.unique(p).tolist()) <= set(EN_COLORS) | {15}:
                raise SystemExit(f'boss_scene: "{ch}" has a pen with no English text color')
            img[:, 8 * i:8 * i + 8] = np.where(p == 15, -1, np.vectorize(lambda v: EN_COLORS.get(v, -1))(p))
        return (row['x'], form['rows'][0]['y'] + 16 * k, img, [])
    img = np.full((16, 16 * len(text)), -1, np.int64)
    srcs = []
    for i, ch in enumerate(text):
        p, src = font.ja(ch)
        srcs.append((ch, src))
        img[:, 16 * i:16 * i + 16] = np.where(p == 15, -1, col[p])
    return (row['x'], form['rows'][0]['y'] + 24 * k, img, srcs)

def strip_place(row_x, width, strip):
    """A strip over a row: (sprite x, sprite y, cells): from the row's first character when it does not move left,"""
    n = -(-width // 16)
    x = row_x + SCREEN[0] if strip['vx'] >= 0 else row_x + width - 16 * n + SCREEN[0]
    return (x, strip['y'], n)

def check_limits(text, region, row):
    n = len(text)
    w = 8 * n if region == 'en' else 16 * n
    if region == 'en' and n > 44 or (region == 'ja' and n > 22) or row['x'] + w > 384:
        raise SystemExit(f'''boss_scene: "{text}" does not fit its row ({n} characters from x {row['x']})''')

def scene_text(scene):
    """{region: [{'lines': [...], 'hold': n}]}: the scene's approved pages (portrait_text_review.json en_pages /"""
    rev = {r['id']: r for r in json.loads(REVIEW.read_text(encoding='utf-8'))['lines']}[scene['id']]
    if rev.get('approval', {}).get('verdict') != 'approve':
        raise SystemExit(f"boss_scene: {scene['id']}: its text is not approved in {REVIEW.name}")
    import portrait_review_page as PR
    if rev['approval'].get('draft_hash') != PR.draft_hash(rev):
        raise SystemExit(f"boss_scene: {scene['id']}: its approval names draft_hash {rev['approval'].get('draft_hash')}, the text is {PR.draft_hash(rev)} (an edit needs a new approval)")
    holds = scene_holds(scene)
    out = {}
    for region in ('en', 'ja'):
        pages = rev[f'{region}_pages']
        h = holds[region]['holds']
        if len(h) != len(pages):
            raise SystemExit(f"boss_scene: {scene['id']} {region}: {len(pages)} pages, {len(h)} page starts + 1")
        out[region] = [dict(lines=list(pg), hold=x) for pg, x in zip(pages, h)]
    return out

def scene_holds(scene):
    """Each page's hold, from the voice (boss_scenes.json holds_note). Voice frame v counts from the voice cue (page"""
    tr = {r['id']: r for r in json.loads(TRANSCRIPTS.read_text(encoding='utf-8'))['lines']}[scene['id']]
    words = [w for seg in tr['variants']['primary']['segments'] for w in seg['words']]
    text, at = ('', [])
    for w in words:
        at += [w] * len(w['w'])
        text += w['w']
    seq = {r['id']: r for r in json.loads(RECEIPT.read_text())['portraits']}[scene['id']]
    T = sum((n for n, _ in seq['sequence']))
    out = {}
    for region, starts in scene['page_starts'].items():
        fades, ss, early = ([], [], [])
        for st in starts:
            k = text.find(st)
            if k < 0 or text.find(st, k + 1) >= 0:
                raise SystemExit(f'''boss_scene: {scene['id']}: page start "{st}" is not once in the transcript {text}''')
            w = at[k]
            i = words.index(w)
            sv = round(w['start'] * HZ)
            ev = round(words[i - 1]['end'] * HZ) if i else 0
            f = sv - (NEXT + FADE_IN)
            if f < ev:
                early.append(ev - f)
                f = (ev + f) // 2
            else:
                early.append(0)
            fades.append(f)
            ss.append(sv)
        holds, u = ([], 0)
        for f in fades:
            holds.append(f + HOLD_FROM - u - HOLD_FROM)
            u = f + HOLD_FROM + NEXT
        holds.append(T - u)
        if min(holds) < FADE_IN:
            raise SystemExit(f"boss_scene: {scene['id']} {region}: a page would hold {min(holds)} frames")
        out[region] = dict(holds=holds, starts=ss, fades=fades, early=early, T=T)
    return out

def build_page(img, gfx, font, machine, scene, portraits, lines, hold):
    """One page of a scene in one region: its parts (screen places and color images), strips, palettes."""
    region = REGION[machine]
    form = stock_form(img, machine, scene['form'])
    if len(lines) > len(form['rows']) or len(lines) > len(form['strips']):
        raise SystemExit(f"boss_scene: {scene['id']}: {len(lines)} rows, the form has {len(form['rows'])}")
    rows, strips, srcs = ([], [], [])
    for k, text in enumerate(lines):
        check_limits(text, region, form['rows'][k])
        x, y, im, s = text_row_image(font, form, k, text, region)
        rows.append((x, y, im))
        srcs += s
        sx, sy, n = strip_place(x, im.shape[1], form['strips'][k])
        sy += y - form['rows'][k]['y']
        below = y + im.shape[0] - (sy - SCREEN[1] + 16)
        if below > 0:
            sy += below
        if not (sy - SCREEN[1] <= y and y + im.shape[0] <= sy - SCREEN[1] + 16 and (sx - SCREEN[0] <= x) and (x + im.shape[1] <= sx - SCREEN[0] + 16 * n)):
            raise SystemExit(f"boss_scene: {scene['id']} row {k}: its strip does not cover it at the start")
        st = form['strips'][k]
        if st['vx'] & 255 or st['vy'] & 255:
            raise SystemExit(f"boss_scene: strip {st['param']}: its velocity has a fraction finer than 1/256")
        strips.append(dict(x=sx, y=sy, n=n, vx=st['vx'] >> 8, vy=st['vy'] >> 8, life=st['life'], param=st['param']))
    x0 = min((s['x'] for s in strips)) - SCREEN[0] - PAD
    x1 = max((s['x'] + 16 * s['n'] for s in strips)) - SCREEN[0] + PAD
    y0 = min((s['y'] for s in strips)) - SCREEN[1] - PAD
    y1 = max((s['y'] + 16 for s in strips)) - SCREEN[1] + PAD
    cw, ch = (-(-(x1 - x0) // 16), -(-(y1 - y0) // 16))
    x0 -= (16 * cw - (x1 - x0)) // 2
    y0 -= (16 * ch - (y1 - y0)) // 2
    plate = np.full((16 * ch, 16 * cw), 61440, np.int64)
    for x, y, im in rows:
        h, w = im.shape
        sub = plate[y - y0:y - y0 + h, x - x0:x - x0 + w]
        sub[im >= 0] = im[im >= 0]
    px, py, panel = record_image(gfx, 's2', form['panel'], form['pals']['s2'])
    wx, wy, window = record_image(gfx, 's3', form['portrait'], form['pals']['s3'])
    wh, ww = window.shape
    panel = panel[wy - py:wy - py + wh, wx - px:wx - px + ww]
    if (panel < 0).any() or len(np.unique(panel)) != 1:
        raise SystemExit(f'boss_scene: {machine}: the panel under the portrait window is not one solid color')
    ptx, pty = (wx + (ww - PT_W) // 2, wy + (wh - PT_H) // 2)
    if not (wx <= ptx - FRAME and ptx + PT_W + FRAME <= wx + ww and (wy <= pty - FRAME) and (pty + PT_H + FRAME <= wy + wh)):
        raise SystemExit(f'boss_scene: {machine}: a {FRAME}-pixel frame does not fit the portrait window')
    fh, fw = (PT_H + 2 * FRAME, PT_W + 2 * FRAME)
    frame = np.full((-(-fh // 16) * 16, -(-fw // 16) * 16), -1, np.int64)
    frame[:fh, :fw] = panel[0, 0]
    panel = frame
    px, py = (ptx - FRAME, pty - FRAME)
    page = dict(id=scene['id'], form=form['name'], region=region, hold=hold, lines=lines, rows=rows, strips=strips, plate=dict(x=x0, y=y0, img=plate), panel=dict(x=px, y=py, img=panel), glyphs=srcs, form_tables={k: f'{v:#x}' for k, v in form['tables'].items()}, window=dict(x=wx, y=wy, w=window.shape[1], h=window.shape[0]))
    k = scene['portrait']
    if portraits is None:
        page['portrait'] = dict(index=k)
        return page
    it = next((p for p in portraits.items if p['index'] == k))
    rest = it['sequence'][-1][1]
    ph = it['pictures'][rest]['pens'].shape[0]
    if ph != PT_H:
        raise SystemExit(f'boss_scene: portrait {k}: {ph} lines, not {PT_H}')
    page['portrait'] = dict(index=k, rest=rest, codes=[p['code'] for p in it['pictures']], sequence=[list(s) for s in it['sequence']], colors=list(it['colors']), x=ptx, y=pty)
    return page

def ui_palette(page):
    """The UI slot's 16 colors: pen PLATE_PEN 0xF000, the panel's colors, the plate's (the text), then STRIP_PEN"""
    words = [61440]
    for img in (page['panel']['img'], page['plate']['img']):
        for c in np.unique(img):
            if c >= 0 and int(c) not in words:
                words.append(int(c))
    if len(words) > STRIP_PEN:
        raise SystemExit(f'boss_scene: {len(words)} colors for the UI slot (at most {STRIP_PEN})')
    words += [61440] * (STRIP_PEN - len(words))
    return words + [61440, 61440]

def to_pens(img, words):
    inv = {}
    for i, w in enumerate(words[:STRIP_PEN]):
        inv.setdefault(w, i)
    out = np.full(img.shape, 15, np.int64)
    for c in np.unique(img):
        if c >= 0:
            out[img == c] = inv[int(c)]
    return out

def pack(blocks, lo, hi):
    """Block sprites (name, nx <= 16, ny) -> {name: code}: c + col + 16 row inside [lo, hi], c's low nibble + nx <= 16."""
    rows = (hi + 1 - lo) // 16
    used = np.zeros((rows, 16), bool)
    out = {}
    for name, nx, ny in sorted(blocks, key=lambda b: (-b[2], -b[1], b[0])):
        for r in range(rows - ny + 1):
            c = next((c for c in range(17 - nx) if not used[r:r + ny, c:c + nx].any()), None)
            if c is not None:
                used[r:r + ny, c:c + nx] = True
                out[name] = lo + 16 * r + c
                break
        else:
            raise SystemExit(f'boss_scene: no room for {name} ({nx}x{ny}) in {lo:#x}-{hi:#x}')
    return (out, int(used.sum()))

def split_blocks(name, pens):
    ch, cw = (pens.shape[0] // 16, pens.shape[1] // 16)
    out = []
    for k, c0 in enumerate(range(0, cw, 16)):
        nx = min(16, cw - c0)
        out.append((f'{name}.{k}', c0, 0, nx, ch, pens[:, 16 * c0:16 * (c0 + nx)]))
    return out

def scenes_in_build():
    return [s for s in manifest()['scenes']]

def prepare(img_of, gfx, portraits):
    """Both regions' scenes: their pages, palettes and blocks (img_of: machine -> stock program image)."""
    font = Font(gfx)
    out = dict(scenes={}, blocks={})
    blocks = out['blocks']
    blocks['strip'] = dict(nx=16, ny=1, pens=np.full((16, 256), STRIP_PEN, np.int64))
    for machine in FORMS:
        out['scenes'][machine] = []
        img = img_of(machine)
        hits = [k for k in range(0, 524288, 2) if img[k:k + len(QUEUE_SIG)] == QUEUE_SIG]
        if len(hits) != 1:
            raise SystemExit(f'boss_scene: {machine}: the stock sound queue matches {len(hits)} times')
        out.setdefault('queue', {})[machine] = hits[0]
        for s in scenes_in_build():
            text = scene_text(s)[REGION[machine]]
            pages = [build_page(img_of(machine), gfx, font, machine, s, portraits, t['lines'], t['hold']) for t in text]
            for k, p in enumerate(pages):
                words = ui_palette(p)
                pan = to_pens(p['panel']['img'], words)
                key = f'panel.{machine}'
                if key in blocks and (not np.array_equal(blocks[key]['pens'], pan)):
                    raise SystemExit(f"boss_scene: {p['id']}: its page draws the panel differently")
                blocks[key] = dict(nx=pan.shape[1] // 16, ny=pan.shape[0] // 16, pens=pan)
                p['before'] = []
                p['after'] = [(key, p['panel']['x'], p['panel']['y'], blocks[key]['nx'], blocks[key]['ny'])]
                for r, (x, y, im) in enumerate(p['rows']):
                    h, w = im.shape
                    cell = np.full((16, -(-w // 16) * 16), -1, np.int64)
                    cell[:h, :w] = im
                    for name, cx, cy, nx, ny, pens in split_blocks(f"row.{machine}.{p['id']}.{k}.{r}", to_pens(cell, words)):
                        blocks[name] = dict(nx=nx, ny=ny, pens=pens)
                        p['after'].append((name, x + 16 * cx, y + 16 * cy, nx, ny))
                p['ui'] = without_border(words)
            out['scenes'][machine].append(dict(id=s['id'], pages=pages, restart=s['restart'], portrait=s['portrait']))
    return out

def without_border(words):
    """Hide the stock red surround without changing any other UI pen."""
    if len(words) != 16 or words[1] != 63232:
        raise ValueError('boss portrait surround is not the reserved red palette pen')
    result = list(words)
    result[1] = 61440
    return result

def install(region, sc, taken):
    """Codes for the blocks written into the EX region; refuses a range met by another claim or a used tile."""
    lo, hi = SCENE_CODES
    for name, (u0, u1) in taken.items():
        if not (u1 < lo or u0 > hi):
            raise SystemExit(f'boss_scene: codes {lo:#x}-{hi:#x} meet {name} {u0:#x}-{u1:#x}')
    codes, cells = pack([(k, b['nx'], b['ny']) for k, b in sc['blocks'].items()], lo, hi)
    for k, b in sc['blocks'].items():
        c = codes[k]
        for r in range(b['ny']):
            for col in range(b['nx']):
                off = G.ex_offset('obj', c + col + 16 * r)
                if any(region[off:off + 128]):
                    raise SystemExit(f'boss_scene: EX OBJ code {c + col + 16 * r:#06x} is already used')
                G.put_tile(region, off, b['pens'][16 * r:16 * r + 16, 16 * col:16 * col + 16])
    sc['codes'] = codes
    top = max((codes[k] + 16 * (b['ny'] - 1) + b['nx'] - 1 for k, b in sc['blocks'].items()))
    sc['report'] = dict(mockup=True, codes=[f'{lo:#06x}', f'{top:#06x}'], claim=[f'{lo:#06x}', f'{hi:#06x}'], cells=cells, strip_code=f"{codes['strip']:#06x}", blocks=len(codes), ui_slot=UI_SLOT, pt_slot=PT_SLOT, tiles_sha256=hashlib.sha256(b''.join((sc['blocks'][k]['pens'].astype(np.uint8).tobytes() for k in sorted(sc['blocks'])))).hexdigest(), scenes={m: [scene_report(sc, s) for s in scenes] for m, scenes in sc['scenes'].items()})
    return sc['report']

def scene_report(sc, s):
    """What the gate needs of a scene (build.json boss_scene scenes): its pages (timing, strips, entries, colors),"""
    voice = next((r for r in manifest()['voice_cues']['rows'] if r['id'] == s['id']))
    p0 = s['pages'][0]
    pt = p0['portrait']
    return dict(id=s['id'], form=p0['form'], voice=dict(ja=int(voice['ja'], 16), en=int(voice['en'], 16)), restart=s['restart'], portrait_index=s['portrait'], portrait=dict(index=pt['index'], x=pt['x'], y=pt['y'], rest_code=pt['codes'][pt['rest']], codes=pt['codes'], sequence=pt['sequence']), pt=pt['colors'], form_tables=p0['form_tables'], window=p0['window'], pages=[dict(hold=p['hold'], lines=p['lines'], strips=p['strips'], before=[list(e) for e in entries(sc, p, 'before')], after=[list(e) for e in entries(sc, p, 'after')], ui=p['ui'], glyphs=[f'{c} {g}' for c, g in p['glyphs']], plate=[p['plate']['x'], p['plate']['y'], p['plate']['img'].shape[1], p['plate']['img'].shape[0]], panel=[p['panel']['x'], p['panel']['y']]) for p in s['pages']])

def entries(sc, p, which):
    """(sprite x, y, code, attribute) of a page's static parts before or after the portrait, top first."""
    return [(x + SCREEN[0], y + SCREEN[1], sc['codes'][name], UI_SLOT | nx - 1 << 8 | ny - 1 << 12) for name, x, y, nx, ny in p[which]]

def page_times(hold):
    fade = HOLD_FROM + hold
    return dict(fade=fade, hide=fade + HIDE, next=fade + NEXT)

def page_level(t, hold):
    """A page's brightness at t: 0-9, or FULL (its own colors)."""
    tm = page_times(hold)
    if t <= 2:
        return 0
    if t < FADE_IN:
        return t - 2
    if t <= tm['fade']:
        return FULL
    return max(0, FADE_OUT - (t - tm['fade']))

def portrait_level(u, t, hold, last):
    """Keep the portrait continuous across text-only transitions."""
    return page_level(t, hold) if u < FADE_IN or (last and t > page_times(hold)['fade']) else FULL

def colors(words, lvl, fade_mask):
    return [w if lvl == FULL or not fade_mask >> i & 1 else w & 4095 | lvl << 12 for i, w in enumerate(words)]
UI_FADE = 65535 & ~(1 << STRIP_PEN)
PT_FADE = 65535

def picture_at(rep_scene, v):
    """The portrait's code at voice time v (u - HOLD_FROM, u the time since the first page's draw): the mouth"""
    pt = rep_scene['portrait']
    if v >= 0:
        for n, pic in pt['sequence']:
            if v < n:
                return pt['codes'][pic]
            v -= n
    return pt['rest_code']

def strip_entries(st, t, code):
    if t < 0 or t > st['life']:
        return []
    x = st['x'] + (st['vx'] * (t - 1) >> 8)
    y = st['y'] + (st['vy'] * (t - 1) >> 8)
    vis = [i for i in range(st['n']) if 0 <= x + 16 * i & 65535 < CLIP_X]
    out = []
    while vis:
        run = [vis[0]]
        for i in vis[1:]:
            if i == run[-1] + 1 and len(run) < 16:
                run.append(i)
            else:
                break
        vis = vis[len(run):]
        out.append((x + 16 * run[0] & 65535, y & 65535, code, UI_SLOT | len(run) - 1 << 8))
    return out

def page_list(rep, rep_scene, page, t, u):
    """A page's sprite list at its t (u: the scene's page time), top first: strips, the portrait, the panel, the"""
    code = int(rep['strip_code'], 16)
    out = []
    for st in page['strips']:
        out += strip_entries(st, t, code)
    out += [tuple(e) for e in page['before']]
    pt = rep_scene['portrait']
    out.append((pt['x'] + SCREEN[0], pt['y'] + SCREEN[1], picture_at(rep_scene, u - HOLD_FROM), PT_SLOT | 7 << 8 | 4 << 12))
    out += [tuple(e) for e in page['after']]
    return out

def timeline(rep, rep_scene, pack=False, voice_lang='ja'):
    """The scene, VBlank by VBlank: [dict(n, phase, page, level, pal ('game', 'buf'), layer ('game', LAYER_HIDE,"""
    out = []

    def add(**k):
        out.append(dict(dict(n=len(out) + 1, t=None, u=None, page=None, list=None, cue=None, ui=None, pt=None), **k))
    for n in range(1, MUSIC_WAIT + 1):
        add(phase='hold', level=FULL, pal='game', layer='game', obj='game', cue=(FADE_CMD if pack else STOP_CMD) if n == 1 else None)
    for j in range(1, NEXT):
        if j < HIDE:
            add(phase='fade_out', level=max(0, FADE_OUT - j), pal='buf', layer='game', obj='game')
        else:
            add(phase='black', level=0, pal='buf', layer=LAYER_HIDE, obj='game')
    u = 0
    for k, page in enumerate(rep_scene['pages']):
        tm = page_times(page['hold'])
        for t in range(tm['next']):
            lvl = page_level(t, page['hold'])
            shown = u >= 1 and (k < len(rep_scene['pages']) - 1 or t < tm['hide'])
            plvl = portrait_level(u, t, page['hold'], k == len(rep_scene['pages']) - 1)
            ui = colors(page['ui'], lvl, UI_FADE)
            if t == 0 or t >= tm['hide']:
                ui = [0] * 16
            ui[1] = colors(page['ui'], plvl, UI_FADE)[1]
            cue = None
            if pack and u == HOLD_FROM:
                v = rep_scene['voice']
                cue = v['en'] if voice_lang == 'en' and v['en'] else v['ja']
            add(phase='page', page=k, level=lvl, pal='buf', layer=LAYER_PAGE if shown else LAYER_HIDE, obj='page', t=t, u=u, list=page_list(rep, rep_scene, page, t, u) if shown else [], cue=cue, ui=ui, pt=colors(rep_scene['pt'], plvl, PT_FADE))
            u += 1
    for r in range(13):
        if r == 0:
            add(phase='return', level=0, pal='buf', layer=LAYER_HIDE, obj='game', t=r)
        elif r < 12:
            add(phase='return', level=0 if r <= 2 else r - 2, pal='buf', layer='game', obj='game', t=r)
        else:
            add(phase='return', level=FULL, pal='game', layer='game', obj='game', t=r)
    return out

def sends(tl):
    """{n: command} the scene writes to the sound latch (ticks: odd at even n), from its prepared commands."""
    out, pend = ({}, None)
    for fr in tl:
        if fr['cue'] is not None:
            pend = fr['cue']
        if pend is not None and fr['n'] % 2 == 0:
            out[fr['n']] = pend
            pend = None
    return out

def inc_text(sc, machine, portraits_on):
    """boss_scene.inc for one region: the slots, the timeline constants and the scene records asm/boss_scene.s"""
    rep = sc['report']
    L_ = [f'; boss_scene.inc ({machine}), written by scripts/boss_scene.py', f'BS_UI_SLOT equ {UI_SLOT}', f'BS_PT_SLOT equ {PT_SLOT}', f"BS_STRIP_CODE equ ${int(rep['strip_code'], 16):04X}", f'BS_FADE_IN equ {FADE_IN}', f'BS_FADE_OUT equ {FADE_OUT}', f'BS_CLIP_X equ ${CLIP_X:X}', f'BS_UI_FADE equ ${UI_FADE:04X}', f'BS_PT_FADE equ ${PT_FADE:04X}', f'BS_MUSIC_WAIT equ {MUSIC_WAIT}', f'BS_HIDE equ {HIDE}', f'BS_NEXT equ {NEXT}', f'BS_HOLD_FROM equ {HOLD_FROM}', f'BS_LAYER_HIDE equ ${LAYER_HIDE:04X}', f'BS_LAYER_PAGE equ ${LAYER_PAGE:04X}', f'BS_PAL0 equ ${PAL_BUFS[0]:04X}', f'BS_PAL1 equ ${PAL_BUFS[1]:04X}', f'BS_OBJ0 equ ${OBJ_LISTS[0]:04X}', f'BS_OBJ1 equ ${OBJ_LISTS[1]:04X}', f'BS_FADE_CMD equ ${FADE_CMD:02X}', f'BS_STOP_CMD equ ${STOP_CMD:02X}', f"BS_QUEUE equ ${sc['queue'][machine]:X}                ; the stock sound queue (d0 = command)", f"BS_SCENES equ {len(sc['scenes'][machine])}", '        even', 'bs_table:']
    scenes = sc['scenes'][machine]
    L_ += [f'        dc.l    bs_scene{k}' for k in range(len(scenes))]
    by = {s['portrait']: k for k, s in enumerate(scenes)}
    L_.append('bs_by_portrait:                         ; portrait index -> its scene ($FF: none)')
    L_.append('        dc.b    ' + ','.join((f'${by.get(i, 255):02X}' for i in range(8))))
    L_.append('        even')
    for k, (s, rs) in enumerate(zip(scenes, rep['scenes'][machine])):
        total = len(timeline(rep, rs))
        L_.append(f"bs_scene{k}:                             ; {s['id']} ({rs['form']} form)")
        L_.append(f'        dc.w    {total}                      ; scene VBlanks')
        L_.append(f"        dc.w    ${rs['voice']['ja']:02X},${rs['voice']['en']:02X}                 ; voice cues (Japanese, English)")
        L_.append(f"        dc.w    {RESTART[rs['restart']]}                       ; the music's restart: {rs['restart']}")
        L_.append('        dc.w    ' + ','.join((f'${w:04X}' for w in rs['pt'])) + '   ; portrait slot')
        pt = rs['portrait']
        L_.append(f"        dc.w    ${pt['x'] + SCREEN[0]:04X},${pt['y'] + SCREEN[1]:04X},${PT_SLOT | 7 << 8 | 4 << 12:04X},${pt['rest_code']:04X}   ; portrait entry x, y, attribute, resting code")
        L_.append(f"        dc.l    pt_seq_{pt['index']}               ; its mouth sequence (portraits.inc: dc.w frames, code)")
        for j, (p, rp) in enumerate(zip(s['pages'], rs['pages'])):
            tm = page_times(p['hold'])
            last = j == len(s['pages']) - 1
            L_.append(f'bs_s{k}_p{j}:                              ; ' + ' / '.join((x.encode('unicode_escape').decode() if machine == 'striderjr' else x for x in p['lines'])))
            L_.append(f"        dc.l    {(0 if last else f'bs_s{k}_p{j + 1}')}                  ; the next page (0: the last)")
            L_.append(f"        dc.w    {tm['fade']},{tm['hide']},{tm['next']}           ; t of the fade-out, the hiding, the next")
            L_.append('        dc.w    ' + ','.join((f'${w:04X}' for w in p['ui'])) + '   ; UI slot')
            L_.append(f"        dc.w    {len(p['strips'])}                       ; strips: x, y, vx, vy (8.8), life, cells")
            for st in p['strips']:
                L_.append(f"        dc.w    ${st['x'] & 65535:04X},${st['y'] & 65535:04X},${st['vx'] & 65535:04X},${st['vy'] & 65535:04X},{st['life']},{st['n']}")
            for which in ('before', 'after'):
                ents = entries(sc, p, which)
                L_.append(f'        dc.w    {len(ents)}                       ; entries {which} the portrait: x, y, code, attribute')
                for e in ents:
                    L_.append('        dc.w    ' + ','.join((f'${v:04X}' for v in e)))
    return '\n'.join(L_) + '\n'

def rgb(word):
    import scene_gate as SG
    return tuple(SG.hb_rgb(word))

def frame_sides(scr, word=63232):
    """The red frame's width above, below, left and right of the portrait in a 384x224 RGB page (the frame's color"""
    red = np.all(scr == np.array(rgb(word), np.uint8), -1)
    ys, xs = np.nonzero(red)
    y0, y1, x0, x1 = (ys.min(), ys.max(), xs.min(), xs.max())
    iy, ix = np.nonzero(~red[y0:y1 + 1, x0:x1 + 1])
    return (int(iy.min()), int(y1 - y0 - iy.max()), int(ix.min()), int(x1 - x0 - ix.max()))

def compose(ents, ui, pt, gfx_region, base=None, rgbf=None):
    """The entries drawn as the board draws a list (the first entry on top) over base (384x224 RGB) or black."""
    rgbf = rgbf or rgb
    scr = np.zeros((224, 384, 3), np.uint8) if base is None else base.copy()
    pal = {UI_SLOT: ui, PT_SLOT: pt}
    for x, y, code, attr in reversed(ents):
        slot, nx, ny = (attr & 31, (attr >> 8 & 15) + 1, (attr >> 12 & 15) + 1)
        cols = np.array([rgbf(w) for w in pal[slot]], np.uint8)
        for r in range(ny):
            for c in range(nx):
                p = G.get_tile(gfx_region, G.ex_offset('obj', code + c + 16 * r), 16)
                X, Y = ((x + 16 * c & 511) - SCREEN[0], y + 16 * r - SCREEN[1])
                m = p != 15
                ys, xs = np.nonzero(m)
                ok = (X + xs >= 0) & (X + xs < 384) & (Y + ys >= 0) & (Y + ys < 224)
                scr[Y + ys[ok], X + xs[ok]] = cols[p[ys[ok], xs[ok]]]
    return scr

def check_voice_cues():
    """Every reserved voice cue is free: never sent by the stock game, not an EX cue, below the control region,"""
    import ex_pack_plan as EP
    vc = manifest()['voice_cues']
    cues = json.loads(CUES.read_text())
    emitted = set()
    for a, b in cues['stock_emitted']['ranges']:
        emitted |= set(range(int(a, 16), int(b, 16) + 1))
    rows, errors = EP.plan()
    if errors:
        raise SystemExit(f'boss_scene: ex_pack_plan errors {errors}')
    used = {int(r['cue'], 16) for r in rows if r['kind'] != 'boss_voice'}
    boss = {r['note'].split()[0]: int(r['cue'], 16) for r in rows if r['kind'] == 'boss_voice'}
    ctrl = int(cues['cps_plus_control_region']['start'], 16)
    others = {int(c, 16) for c in vc['reserved_for_others']} | {int(c, 16) for c in cues['spare']}
    seen = set()
    for r in vc['rows']:
        for k in ('ja', 'en'):
            v = int(r[k], 16)
            if k == 'ja' and boss and (boss.get(r['id']) != v):
                raise SystemExit(f"boss_scene: voice cue {r[k]} ({r['id']}) is not its pack row ({boss.get(r['id'])})")
            bad = [why for why, b in (('stock', v in emitted), ('EX cue', v in used), ('control region', v >= ctrl), ('reserved', v in others), ('twice', v in seen), ('the fade', v == FADE_CMD)) if b]
            if bad:
                raise SystemExit(f"boss_scene: voice cue {r[k]} ({r['id']} {k}) is not free: {bad}")
            seen.add(v)
    if int(cues['skip_fade']['cue'], 16) != FADE_CMD or cues['skip_fade']['frames'] != FADE_TICKS:
        raise SystemExit('boss_scene: the pack fade is not ex_pack_cues.json skip_fade')
    return sorted(seen)

def check_holds():
    """Every scene's pages hold as scene_holds() derives them; prints them (the self-test's record)."""
    for sc in scenes_in_build():
        for region, h in scene_holds(sc).items():
            print(f"{sc['id']} {region}: holds {h['holds']}, page starts at voice {h['starts']}, fade-outs {h['fades']}, early {h['early']}, T {h['T']}")

def self_test(a):
    assert page_level(0, 90) == 0 and page_level(2, 90) == 0 and (page_level(3, 90) == 1) and (page_level(11, 90) == 9)
    assert page_level(12, 90) == FULL and page_level(110, 90) == 9 and (page_level(119, 90) == 0)
    assert page_times(392) == dict(fade=411, hide=428, next=439)
    assert MUSIC_WAIT >= 1 + FADE_TICKS
    st = dict(x=416, y=176, n=4, vx=1024, vy=0, life=128)
    assert strip_entries(st, 1, 46592) == [(416, 176, 46592, UI_SLOT | 1 << 8)]
    pg = lambda h: dict(hold=h, strips=[], before=[], after=[], ui=[61440] * 16)
    rs = dict(voice=dict(ja=184, en=192), pages=[pg(4), pg(6)], pt=[61440] * 16, portrait=dict(x=0, y=0, rest_code=47328, codes=[47328, 47336], sequence=[[30, 1], [40, 0], [5, 1]]))
    rs['pt'][1] = 63333
    for p in rs['pages']:
        p['ui'][1:3] = [63232, 65262]
        p['ui'] = without_border(p['ui'])
    rep = dict(strip_code='0xb600')
    tl = timeline(rep, rs, pack=True)
    t1, t2 = (page_times(4), page_times(6))
    assert len(tl) == MUSIC_WAIT + NEXT - 1 + t1['next'] + t2['next'] + 13, len(tl)
    v0 = MUSIC_WAIT + NEXT + HOLD_FROM
    assert sends(tl) == {2: FADE_CMD, v0 + 1: 184}, sends(tl)
    assert sends(timeline(rep, rs, pack=True, voice_lang='en'))[v0 + 1] == 192
    assert sends(timeline(rep, rs)) == {2: STOP_CMD}
    assert [picture_at(rs, v) for v in (-1, 0, 29, 30, 69, 70, 75)] == [47328, 47336, 47336, 47328, 47328, 47336, 47328]
    p2 = [f for f in tl if f['page'] == 1]
    assert p2[0]['t'] == 0 and p2[0]['u'] == t1['next'] and (len(p2) == t2['next'])
    for fr in tl:
        if fr['phase'] == 'page' and FADE_IN <= fr['u'] <= t1['next'] + t2['fade']:
            assert fr['pt'] == rs['pt'] and fr['ui'][1] & 4095 == 0 and (fr['layer'] == LAYER_PAGE)
    assert p2[0]['ui'][2] == 0 and p2[0]['list']
    fo = [f['level'] for f in tl if f['phase'] == 'fade_out']
    assert fo == [9, 8, 7, 6, 5, 4, 3, 2, 1, 0, 0, 0, 0, 0, 0, 0], fo
    ret = [f['level'] for f in tl if f['phase'] == 'return']
    assert ret == [0, 0, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, FULL], ret
    assert tl[-1]['pal'] == 'game' and tl[0]['pal'] == 'game'
    check_holds()
    print('voice cues free:', ' '.join((f'{v:#04x}' for v in check_voice_cues())))
    if a.rom_dir:
        gfx = stock_gfx(a.rom_dir)
        for machine in FORMS:
            img = stock_image(a.rom_dir, machine)
            for name in FORMS[machine]:
                f = stock_form(img, machine, name)
                for k, (row, s) in enumerate(zip(f['rows'], f['strips'])):
                    x, y, n = strip_place(row['x'], row['width'], s)
                    if x != s['x']:
                        raise SystemExit(f"self-test: {machine} {name} strip {k}: rule x {x:#x}, stock {s['x']:#x}")
                got = hashlib.sha256(stock_page_image(gfx, f).astype('>u2').tobytes()).hexdigest()
                if got != STOCK_PAGE_SHA256[machine, name]:
                    raise SystemExit(f'self-test: {machine} {name}: the stock page model is {got}')
            font = Font(gfx)
            for s in scenes_in_build():
                for t in scene_text(s)[REGION[machine]]:
                    p = build_page(img, gfx, font, machine, s, None, t['lines'], t['hold'])
                    assert without_border(ui_palette(p))[1] == 61440
                    if REGION[machine] == 'en':
                        for (x, y, im), text, st in zip(p['rows'], t['lines'], p['strips']):
                            assert im.shape[0] == EN_ROW_H and set(np.unique(im[im >= 0]).tolist()) <= set(EN_COLORS.values())
                            assert (im[8:] >= 0).any() == any((c in 'gjpqy' for c in text)), (s['id'], text)
                            assert st['y'] - SCREEN[1] <= y and y + EN_ROW_H <= st['y'] - SCREEN[1] + 16, (s['id'], st)
                        assert any((ch.islower() for r in t['lines'] for ch in r)), s['id']
                    print(machine, s['id'], 'rows', p['lines'], 'hold', t['hold'], 'strips', [(x['x'], x['y'], x['n']) for x in p['strips']], 'glyphs', ''.join((c for c, _ in p['glyphs'])))
        print('stock forms and pages ok')
    import subtitle_ex as SX
    assert EN_COLORS == {0: SX.PALETTE[7], 1: SX.PALETTE[1], 2: SX.PALETTE[2], 3: SX.PALETTE[3]}, "not the captions'"
    if a.portraits:
        sc = prev(a.rom_dir, a.portraits, None)
        for machine, scenes in sc['report']['scenes'].items():
            for rs in scenes:
                fr = next((f for f in timeline(sc['report'], rs) if f['phase'] == 'page' and f['t'] == 100))
                assert fr['ui'][1] == 61440, (machine, rs['id'])
        print('All boss portrait surrounds use exact black')
    print('boss_scene self-test passed')
    return 0

def source_check(brep, region, machine, rom_dir, capture):
    """A build's boss scenes against the sources, independently of the build: prepare() and install() run again from"""
    import portrait_ex as PX
    gfx = stock_gfx(rom_dir)

    class CV:
        region = bytearray(4 * G.MB)
    portraits = PX.prepare_unchecked(CV, capture)
    sc = prepare(lambda m: stock_image(rom_dir, m), gfx, portraits)
    fresh = bytearray(4 * G.MB)
    rep = install(fresh, sc, {})
    bad = []
    norm = lambda v: json.loads(json.dumps(v, default=str))
    if rep['tiles_sha256'] != brep['tiles_sha256']:
        bad.append(f"tiles_sha256: build {brep['tiles_sha256'][:12]}, sources {rep['tiles_sha256'][:12]}")
    if norm(rep['scenes'][machine]) != norm(brep['scenes'][machine]):
        got = {s['id']: s for s in norm(brep['scenes'][machine])}
        for s in norm(rep['scenes'][machine]):
            if got.get(s['id']) != s:
                bad.append(f"{s['id']}: the build's scene report differs from the sources'")
    for name, code in sc['codes'].items():
        b = sc['blocks'][name]
        for r in range(b['ny']):
            for c in range(b['nx']):
                off = G.ex_offset('obj', code + c + 16 * r)
                if region[off:off + 128] != fresh[off:off + 128]:
                    bad.append(f"{name}: tile {code + c + 16 * r:#06x} differs from the sources'")
                    break
    return (not bad, bad)

def prev(rom_dir, capture, out):
    import portrait_ex as PX
    gfx = stock_gfx(rom_dir)

    class CV:
        region = bytearray(4 * G.MB)
    portraits = PX.prepare_unchecked(CV, capture)
    imgs = {m: stock_image(rom_dir, m) for m in FORMS}
    sc = prepare(lambda m: imgs[m], gfx, portraits)
    install(CV.region, sc, {})
    sc['region'] = CV.region
    if out is None:
        print('prepared', sc['report']['codes'], sc['report']['blocks'], 'blocks')
        return sc
    from PIL import Image
    out.mkdir(parents=True, exist_ok=True)
    for machine, scenes in sc['report']['scenes'].items():
        for rs in scenes:
            tl = timeline(sc['report'], rs)
            for k in range(len(rs['pages'])):
                for t in (12, 40, 100):
                    fr = next((f for f in tl if f['phase'] == 'page' and f['page'] == k and (f['t'] == t)))
                    scr = compose(fr['list'], fr['ui'], fr['pt'], CV.region)
                    Image.fromarray(scr).resize((768, 448), Image.NEAREST).save(out / f"{machine}_{rs['id']}_p{k}_t{t:03d}.png")
    print(out)
    return sc

def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('cmd', nargs='?', choices=['preview'])
    p.add_argument('--self-test', action='store_true')
    p.add_argument('--rom-dir', type=Path)
    p.add_argument('--portraits', type=Path)
    p.add_argument('--out', type=Path)
    a = p.parse_args()
    if a.self_test:
        return self_test(a)
    if a.cmd == 'preview':
        prev(a.rom_dir, a.portraits, a.out)
        return 0
    p.print_help()
    return 1
if __name__ == '__main__':
    sys.exit(main())
