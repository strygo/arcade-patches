; Strider EX cinematic scene player: the core shared by the standalone test
; boot (scene_player.s) and the in-game EX bank (ex_bank.s). The including
; file defines the RAM equates (RING, RSIZE, RMASK, FRAMES, LZ_SRC, LZ_W,
; LZ_R, ENDED, PALBASE) and the video equates (OBJ, ROWS, CPSA, CPSB, LAYER).

; cine_setup: the player's video state. Clears graphics RAM 0x900000-0x92FFFF,
; draws the SCROLL3 bars and sets the CPS-A/B registers, the layer word to
; LAYER_BASE until the stream's first op 6. Clobbers d0-d3, a0-a1.
; cine_setup_layer: the same with the layer word in d3 (the stage select's
; screen: 0x1540, no layer and no sprite slot, until its first still turns its
; layers on. LAYER_BASE has a sprite slot, and jtcps1 shows the sprite buffer
; it copied at the OBJ base write before last: MEASURED in its RTL, the last
; still's caption page over black for a frame).
cine_setup:
        move.w  #LAYER_BASE,d3
cine_setup_layer:
        move.w  #$1540,LAYER            ; black first: no scroll layer, no sprite slot (respawn_layers.s
                                        ; HIDE). The clear takes several frames, and the layers the last
                                        ; screen left on would show it (MEASURED after START: a frame of
                                        ; SCROLL3 code 0 over the whole screen)
        lea     $900000,a0              ; clear graphics RAM 0x900000-0x92FFFF (memfill: movem, about a third
        move.l  #$30000,d0              ; of the time of clr.l (a0)+, which held 10 black frames between
        moveq   #0,d1                   ; two scenes: PHASE0_FINDINGS.md "The start flow")
        bsr     memfill
        lea     SCR3,a0                 ; SCROLL3: transparent everywhere ...
        move.l  #$4000,d0
        move.l  #$38010000,d1
        bsr     memfill
        lea     barcols(pc),a1          ; ... black bars in four tile columns
        moveq   #4-1,d1
.col:   move.w  (a1)+,d2                ; column << 3 entries = byte offset col*32
        lsl.w   #5,d2
        lea     SCR3,a0
        add.w   d2,a0
        moveq   #8-1,d0                 ; tile rows 0-7 (rows & 7: consecutive entries)
.row:   move.l  #$38000000,(a0)+
        dbra    d0,.row
        dbra    d1,.col
        clr.l   OBJ                     ; empty sprite lists: a full end entry each (end_a3)
        clr.w   OBJ+4
        move.w  #$FF00,OBJ+6
        clr.l   OBJ_B
        clr.w   OBJ_B+4
        move.w  #$FF00,OBJ_B+6
        move.l  #OBJ_B,OBJ_BACK         ; A is shown first (the base below)
        clr.w   SPR_NEW
        lea     pal_slots(pc),a1        ; bar black (SCROLL3 palette 0x60, pen 0), every palette
        moveq   #2-1,d1
.pb:    move.l  (a1)+,a0
        move.w  #$F000,$600*2(a0)
        dbra    d1,.pb
    ifd CAP_OFF
        bsr     cap_reset               ; no captions, caption palette
    endif
        lea     CPSA,a0
        move.w  #$9000,(a0)             ; OBJ base
        move.w  #$9080,$02(a0)          ; SCROLL1 base (A)
        move.w  #$90C0,$04(a0)          ; SCROLL2 base (A)
    ifd S1_FRONT
        move.w  #$9080,S1_FRONT
        move.w  #$90C0,S2_FRONT
    endif
        move.w  #$9100,$06(a0)          ; SCROLL3 base
        move.w  #$9008,$08(a0)          ; row scroll ("other") base: block 0x900800 ...
        move.w  #$FFC0,$0C(a0)          ; SCROLL1 x/y (as the game)
        clr.w   $0E(a0)
        clr.w   $10(a0)                 ; SCROLL2 x (row scroll carries x)
        clr.w   $12(a0)
        clr.w   $14(a0)                 ; SCROLL3 x/y
        clr.w   $16(a0)
        move.w  #$0300,$20(a0)          ; ... offset 0x300 words: rows at 0x900E00, list B below
        move.w  #$000F,$22(a0)          ; video control
        lea     CPSB,a0
        move.w  d3,$26(a0)              ; the layer word (LAYER_BASE, or the caller's)
        clr.w   $28(a0)                 ; priority masks: no tile pens over sprites
        clr.w   $2A(a0)
        clr.w   $2C(a0)
        clr.w   $2E(a0)
        move.w  #$003F,$30(a0)          ; palette control: all six pages
        move.w  #$9010,PALBASE
        move.w  #$9010,CPSA+$0A         ; palette base (copies the palette)
        rts

; obj_flip: show the sprite list the last record built. The CPS-1 copies the
; sprite table only when the OBJ base register is written, one entry a line
; over the next frame, into the buffer it shows after the following write
; (MEASURED on a PCB, jtcps1_dma.v; MAME latches at each VBlank from the
; base set then, which gives the same picture). So the list being built must
; not be the one being copied: two lists, A and B, the base written first in
; each VBlank to the one finished in the last. A list written at record k is
; on screen from the frame after VBlank k+2 (cinematic_convert.SPRITE_LEAD).
; If that list changed, it is copied into the other buffer, which the next
; record edits. Clobbers d0, a0-a1.
obj_flip:
        move.l  OBJ_BACK,a0
        move.l  a0,d0
        lsr.l   #8,d0
        move.w  d0,CPSA                 ; OBJ base: start the copy of the finished list
        lea     OBJ,a1
        cmp.l   a1,a0
        bne.s   .b
        lea     OBJ_B,a1
.b:     move.l  a1,OBJ_BACK
        tst.w   SPR_NEW
        beq.s   .out
        clr.w   SPR_NEW
.c:     move.l  (a0)+,(a1)+             ; x, y
        move.l  (a0)+,d0                ; code, attr
        move.l  d0,(a1)+
        cmp.w   #$FF00,d0               ; up to and with the end entry (attr high byte 0xFF)
        bcs.s   .c
.out:   rts

; memfill: d0.l bytes (a multiple of 64, at most 0x40000) from a0 with the long d1, 64 bytes a pass
; (movem.l, down from the end: about 2.4 cycles a byte, where clr.l (a0)+ / dbra takes 7.5).
; Clobbers d0, a0.
memfill: movem.l d1-d7/a1,-(sp)
        move.l  d1,d2
        move.l  d1,d3
        move.l  d1,d4
        move.l  d1,d5
        move.l  d1,d6
        move.l  d1,d7
        move.l  d1,a1
        add.l   d0,a0
        lsr.l   #6,d0
        subq.w  #1,d0
.f:     movem.l d1-d7/a1,-(a0)
        movem.l d1-d7/a1,-(a0)
        dbra    d0,.f
        movem.l (sp)+,d1-d7/a1
        rts

; end_a3: a full sprite-list end entry at (a3): x, y and code 0, attribute
; 0xFF00. MAME stops at the mark. jtcps1's OBJ copy (MEASURED in its RTL,
; jtcps1_dma.v fill_found) recognizes the mark in the attribute word and
; zero-fills the table from there, but keeps the end entry's x, y and code,
; and its renderer draws all 256 entries: an end mark written over a longer
; list's entry showed that sprite with attribute 0 (stray caption letters, a
; "4" over the map). x = y = 0 is off screen on both. Clobbers nothing.
end_a3: clr.l   (a3)
        clr.w   4(a3)
        move.w  #$FF00,6(a3)
        rts

barcols: dc.w   2,3,12,13
s1_slots: dc.l  $908000,$904000,$914000,$918000,$924000,$928000,$92C000
s2_slots: dc.l  $90C000,$91C000,$920000
pal_slots: dc.l $901000,$902800

; slot: a2 = slot address from table a1 by the op word's high byte (d1)
slot:   move.w  d1,d0
        lsr.w   #6,d0
        and.w   #$1C,d0
        move.l  0(a1,d0.w),a2
        rts

; ------------------------------------------------------------- LZSS input
; fill: decode until at least d7.w bytes are unread in the ring. Works a
; flag group (8 tokens, at most 144 bytes) at a time: away from the ring's
; end the group is written through pointers with no index masking, which
; is most of the player's time. Decoder state stays in registers for the
; whole call. Clobbers d0-d6, a1-a4 (not a0, d7).
fill:   move.l  LZ_SRC,a2
        lea     RING,a1
        move.w  LZ_W,d1
        move.w  LZ_R,d2
.chk:   move.w  d1,d0
        sub.w   d2,d0
        and.w   #RMASK,d0
        cmp.w   d7,d0
        bcc     .done
        move.b  (a2)+,d4                ; flag byte of the next group
        moveq   #8-1,d5
        cmp.w   #RSIZE-8*18,d1
        bhi.s   .slow                   ; near the end: masked indices
        lea     0(a1,d1.w),a4           ; write pointer
.ftok:  lsr.b   #1,d4
        bcc.s   .fmat
        move.b  (a2)+,(a4)+             ; literal
        dbra    d5,.ftok
        bra.s   .fend
.fmat:  moveq   #0,d3
        move.b  (a2)+,d3
        lsl.w   #8,d3
        move.b  (a2)+,d3
        moveq   #15,d6
        and.w   d3,d6
        addq.w  #2,d6                   ; length - 1 (3-18 bytes)
        lsr.w   #4,d3
        addq.w  #1,d3                   ; distance 1-4096
        move.l  a4,d0
        sub.l   a1,d0                   ; write index
        sub.w   d3,d0
        bmi.s   .fwrap                  ; source before the ring start: masked copy
        lea     0(a1,d0.w),a3
.fcp:   move.b  (a3)+,(a4)+
        dbra    d6,.fcp
        dbra    d5,.ftok
        bra.s   .fend
.fwrap: and.w   #RMASK,d0
.fwc:   move.b  0(a1,d0.w),(a4)+
        addq.w  #1,d0
        and.w   #RMASK,d0
        dbra    d6,.fwc
        dbra    d5,.ftok
.fend:  move.l  a4,d1
        sub.l   a1,d1
        and.w   #RMASK,d1               ; (may reach RSIZE exactly)
        bra.s   .chk
.slow:  lsr.b   #1,d4
        bcc.s   .smat
        move.b  (a2)+,0(a1,d1.w)        ; literal
        addq.w  #1,d1
        and.w   #RMASK,d1
        dbra    d5,.slow
        bra     .chk
.smat:  moveq   #0,d3
        move.b  (a2)+,d3
        lsl.w   #8,d3
        move.b  (a2)+,d3
        moveq   #15,d6
        and.w   d3,d6
        addq.w  #2,d6
        lsr.w   #4,d3
        addq.w  #1,d3
        move.w  d1,d0
        sub.w   d3,d0
.scp:   and.w   #RMASK,d0
        move.b  0(a1,d0.w),0(a1,d1.w)
        addq.w  #1,d0
        addq.w  #1,d1
        and.w   #RMASK,d1
        dbra    d6,.scp
        dbra    d5,.slow
        bra     .chk
.done:  move.w  d1,LZ_W
        move.l  a2,LZ_SRC
        rts

; ------------------------------------------------- one record per VBlank
; cine_step: called from a VBlank handler with every register saved. The
; record it applies was decoded during the previous frame (lookahead), so
; the picture changes land in the blanking interval; then it decodes the
; next record in the time left. The first record is decoded in task time
; (ready, before the player's first VBlank: play, scene_player.s
; start), so every record here is already whole in the ring and mirrored:
; it is only read. (Calling ready again here mirrored a wrapping record a
; second time: MEASURED in the jtcps1 RTL, up to 55 lines before the first op.)
cine_step:
    ifd NP_READING
        jmp     np_read_step            ; same ten-byte entry; helper resumes at the ENDED branch
        nop
        nop
    else
        bsr     obj_flip                ; first, while the beam is in VBlank
        tst.w   ENDED                   ; end of stream: hold the last picture
    endif
        bne     vbl_out
        lea     RING,a0                 ; the record the lookahead made whole
        add.w   LZ_R,a0
        move.w  (a0)+,d7
        cmp.w   #$FFFF,d7
        bne.s   .rec
        move.w  #1,ENDED
        bra     vbl_out
.rec:   addq.w  #2,d7                   ; with its length word
        move.w  LZ_R,d0
        add.w   d7,d0
        and.w   #RMASK,d0
        move.w  d0,LZ_R                 ; consumed: the lookahead may reuse the ring after it
        bra.s   next_rec

; ready: the next record whole in the ring (decoding what is missing).
; Out: d7 = $FFFF at the end mark, else the record's length with its length
; word, a0 = its first op. A record that wraps has the ring's first bytes
; mirrored past its end, a long word at a time (the mirror area has room for
; the rounding). Clobbers d0-d6, a1-a4.
ready:  moveq   #2,d7                   ; the record length word
        bsr     fill
        lea     RING,a0                 ; records have even lengths, so a0 stays even
        add.w   LZ_R,a0
        move.w  (a0)+,d7
        cmp.w   #$FFFF,d7
        beq.s   .out
        addq.w  #2,d7
        bsr     fill                    ; the whole record is in the ring now
        move.w  LZ_R,d0
        add.w   d7,d0                   ; end index, unmasked
        cmp.w   #RSIZE,d0
        bls.s   .out
        sub.w   #RSIZE-3,d0             ; it wraps: mirror the ring's first bytes past its end,
        lsr.w   #2,d0                   ; whole long words (RING is long-aligned)
        lea     RING,a1
        lea     RING+RSIZE,a2
        subq.w  #1,d0
.mir:   move.l  (a1)+,(a2)+
        dbra    d0,.mir
.out:   rts

next_rec:
        move.w  (a0)+,d0
        beq.s   .done
        move.w  d0,d1
        and.w   #$00FF,d0
        add.w   d0,d0
        move.w  .ops-2(pc,d0.w),d0
        jmp     .ops(pc,d0.w)
.ops:   dc.w    op_cells-.ops,op_sprites-.ops,op_scrolly-.ops
        dc.w    op_rows-.ops,op_palette-.ops,op_layer-.ops
        dc.w    op_cells1-.ops,op_scroll1-.ops,op_flip-.ops,op_copy-.ops
        dc.w    op_palcopy-.ops,op_run1-.ops,op_run2-.ops,op_cue-.ops
.done:
    ifd CAP_OFF
        bsr     cap_step                ; caption schedule (subtitles.s)
    endif
        addq.l  #1,FRAMES
        bsr     ready                   ; lookahead: decode the next record now
vbl_out:
        rts

op_cells:                               ; n x (offset, code, attr), four quadrants
        lea     s2_slots(pc),a1
        bsr     slot
        move.w  (a0)+,d5
        bra.s   .t
.c:     move.l  a2,a3
        add.w   (a0)+,a3
        move.l  (a0)+,d6
        move.l  d6,(a3)
        move.l  d6,$0800(a3)
        move.l  d6,$2000(a3)
        move.l  d6,$2800(a3)
.t:     dbra    d5,.c
        bra     next_rec

op_cells1:                              ; n x (offset, code, attr)
        lea     s1_slots(pc),a1
        bsr     slot
        move.w  (a0)+,d5
        bra.s   .t
.c:     move.l  a2,a3
        add.w   (a0)+,a3
        move.l  (a0)+,(a3)
.t:     dbra    d5,.c
        bra     next_rec

; op_run1 / op_run2: n, a byte offset, n x (code, attr): cells at consecutive
; entries of the map's scan from that offset (a third fewer stream bytes than
; ops 7 and 1 for the long runs a scene cut or a prefetch writes: decoding
; the stream is most of the player's time on the board).
op_run1:
        lea     s1_slots(pc),a1
        bsr     slot
        move.w  (a0)+,d5
        add.w   (a0)+,a2
        bra.s   .t
.c:     move.l  (a0)+,(a2)+
.t:     dbra    d5,.c
        bra     next_rec

op_run2:                                ; SCROLL2: the four quadrants, as op 1
        lea     s2_slots(pc),a1
        bsr     slot
        move.w  (a0)+,d5
        add.w   (a0)+,a2
        bra.s   .t
.c:     move.l  (a0)+,d6
        move.l  d6,(a2)
        move.l  d6,$0800(a2)
        move.l  d6,$2000(a2)
        move.l  d6,$2800(a2)
        addq.l  #4,a2
.t:     dbra    d5,.c
        bra     next_rec

op_sprites:                             ; n x (x, y, code, attr) + end mark
        move.w  (a0)+,d5
        move.l  OBJ_BACK,a3
        move.w  #1,SPR_NEW
    ifd CAP_OFF
        add.w   CAP_OFF,a3              ; after the caption entries
        move.w  d5,CAP_SN
    endif
        bra.s   .t
.s:     move.l  (a0)+,(a3)+
        move.l  (a0)+,(a3)+
.t:     dbra    d5,.s
        bsr     end_a3
        bra     next_rec

op_scrolly:
        move.w  (a0)+,CPSA+$12
        bra     next_rec

op_scroll1:
        move.w  (a0)+,CPSA+$0C
        move.w  (a0)+,CPSA+$0E
        bra     next_rec

; op_rows: n, the SCROLL2 X register, then n x (count, x) runs over the 256
; lines, x relative to the register. jtcps1 (MEASURED in its RTL:
; jtcps1_dma.v, jtcps1_tilemap.v) fetches one 49-tile SCROLL2 row from the
; X register and adds a line's row value only when it reads that row, so a
; row value past the fetched window reads other layers' tiles. MAME and
; jtcps1 both show X + row (mod 1024); the converter puts the lines' common
; 16-aligned base in the register and keeps the rows within the window
; (cinematic_convert.ROW_SPAN).
op_rows:
        move.w  (a0)+,d5
        move.w  (a0)+,CPSA+$10          ; SCROLL2 X
        lea     ROWS,a3
        bra.s   .t
.r:     move.w  (a0)+,d6
        move.w  (a0)+,d0
        bra.s   .wt
.w:     move.w  d0,(a3)+
.wt:    dbra    d6,.w
.t:     dbra    d5,.r
        bra     next_rec

op_palette:                             ; start, n, n colors
        lea     pal_slots(pc),a1
        bsr     slot
        move.l  a2,a3
        move.w  (a0)+,d0
        add.w   d0,d0
        add.w   d0,a3
        move.w  (a0)+,d5
        bra.s   .t
.p:     move.w  (a0)+,(a3)+
.t:     dbra    d5,.p
        bra     next_rec

op_layer:                               ; layer control word, group-0 priority mask
        move.w  (a0)+,LAYER
        move.w  (a0)+,CPSB+$28
        bra     next_rec

op_flip:                                ; SCROLL1, SCROLL2 and palette base registers
    ifd S1_FRONT
        move.w  (a0),S1_FRONT           ; (the buffers shown: a continued scene keeps them, ex_bank.s play)
        move.w  2(a0),S2_FRONT
    endif
        move.w  (a0)+,CPSA+$02
        move.w  (a0)+,CPSA+$04
        move.w  (a0)+,PALBASE           ; (copied at the record's op 11)
        bra     next_rec

; op_palcopy: the palette base write, which copies the shown palette buffer
; into the palette. The converter writes it only in a record that changes
; that buffer or flips to another, before the record's sprite list and
; prefetch: on the board (jtcps1, MEASURED in its RTL) the copy of all six
; pages holds the 68000's bus for about 12 lines, and it must end in the
; blanking. (The player wrote it at every record's end before.)
op_palcopy:
        move.w  PALBASE,CPSA+$0A
        bra     next_rec

; op_cue: the scene's sound cue, in the record of the stream's first frame. The pack's track starts at
; that frame (manifests/ex_pack_cues.json window_s), so voice and picture start together; the sound
; protocol sends it on this or the next frame (ex_bank.s sound). The including file's CUE_NEXT holds
; the cue play chose (0: no pack); the test boot (scene_player.s) has none.
op_cue:
    ifd CUE_NEXT
        move.w  CUE_NEXT,CUE
    endif
        bra     next_rec

op_copy:                                ; kind (0 SCROLL1, 1 palette), src, dst, first, count
        lea     s1_slots(pc),a1
        move.w  (a0)+,d2
        beq.s   .k
        lea     pal_slots(pc),a1
.k:     move.w  (a0)+,d0
        lsl.w   #2,d0
        move.l  0(a1,d0.w),a2           ; source buffer
        move.w  (a0)+,d0
        lsl.w   #2,d0
        move.l  0(a1,d0.w),a3           ; destination buffer
        move.w  (a0)+,d0                ; first entry
        move.w  (a0)+,d5                ; count
        tst.w   d2
        bne.s   .pal
        lsl.w   #2,d0                   ; SCROLL1: 4-byte entries
        add.w   d0,a2
        add.w   d0,a3
        bra.s   .lt
.l:     move.l  (a2)+,(a3)+
.lt:    dbra    d5,.l
        bra     next_rec
.pal:   add.w   d0,d0                   ; palette: 2-byte entries
        add.w   d0,a2
        add.w   d0,a3
        bra.s   .wt
.w:     move.w  (a2)+,(a3)+
.wt:    dbra    d5,.w
        bra     next_rec

