"""P0.4: decode the PC Engine desert's section scripts and spawn records."""
import argparse
import json
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
import huc6280_dis as H
MAP = {16384: 104, 24576: 105, 32768: 106, 40960: 107}
DUMP_BASE = 851968
SECTION_DISPATCH, SECTION_TABLE, SECTIONS = (38383, 38391, 5)
STATE = 13322
CALLS = {31188: 'spawn_object', 31037: 'spawn_actor', 29886: 'camera_bounds', 29935: 'trigger', 29752: 'camera_settled', 31697: 'load_sprite_sets'}
BRANCHES = {'bpl', 'bmi', 'bvc', 'bvs', 'bcc', 'bcs', 'bne', 'beq'}

def words(read, a, n):
    return [read(a + 2 * i) | read(a + 2 * i + 1) << 8 for i in range(n)]

def spawn_record(read, a):
    b = [read(a + i) for i in range(8)]
    return dict(record=f'0x{a:04X}', x=b[0] | b[1] << 8, y=b[2] | (b[3] & 63) << 8, flags=b[3] >> 6, slot='free' if b[4] == 255 else b[4] & 127, only_if_free=b[4] != 255 and bool(b[4] & 128), once_id=b[5] if b[5] < 128 else None, type=f'0x{b[6]:02X}', param=b[7])

def byte_list(read, a):
    out = []
    while read(a) and len(out) < 32:
        out.append(f'0x{read(a):02X}')
        a += 1
    return out

def jump_table(read, at, entry_after):
    """Word table at `at` whose entries are code just after it (ends where the first entry starts)."""
    first = read(at) | read(at + 1) << 8
    n = (first - at) // 2 if at < first <= at + 64 else 0
    return [read(at + 2 * i) | read(at + 2 * i + 1) << 8 for i in range(max(n, 1))]

def walk(read, entry, stop):
    """Steps of one state: decoded calls and state stores along every path from entry."""
    seen, work, steps = (set(), [entry], [])
    while work:
        pc = work.pop()
        regs = {}
        while pc not in seen and pc not in stop:
            seen.add(pc)
            text, n, target = H.decode(read, pc)
            name = text.split()[0]
            code = read(pc)
            if name == 'lda' and H.OPS[code][1] == H.IMM:
                regs['a'] = read(pc + 1)
            elif name == 'cla':
                regs['a'] = 0
            elif name in ('sta', 'stz') and target is not None:
                regs[target] = 0 if name == 'stz' else regs.get('a')
                if target == STATE:
                    steps.append(dict(at=f'0x{pc:04X}', op='set_state', state=regs[target]))
                elif target in (11397, 11400):
                    steps.append(dict(at=f'0x{pc:04X}', op='section_end_flag', cell=f'0x{target:04X}', value=regs[target]))
            if name == 'jsr':
                kind = CALLS.get(target)
                ptr = lambda lo, hi: (regs.get(lo) if regs.get(lo) is not None else 0) | (regs.get(hi) or 0) << 8
                if kind in ('spawn_object', 'spawn_actor'):
                    steps.append(dict(at=f'0x{pc:04X}', op=kind, **spawn_record(read, ptr(98, 99))))
                elif kind == 'camera_bounds':
                    a = ptr(96, 97)
                    y0, y1, x0, x1 = words(read, a, 4)
                    steps.append(dict(at=f'0x{pc:04X}', op=kind, data=f'0x{a:04X}', y=[y0, y1], x=[x0, x1]))
                elif kind == 'trigger':
                    a = ptr(96, 97)
                    y0, y1, x0, x1 = words(read, a, 4)
                    steps.append(dict(at=f'0x{pc:04X}', op=kind, data=f'0x{a:04X}', hiryu_y=[y0, y1], hiryu_x=[x0, x1]))
                elif kind == 'load_sprite_sets':
                    a = ptr(8292, 8293)
                    steps.append(dict(at=f'0x{pc:04X}', op=kind, data=f'0x{a:04X}', sets=byte_list(read, a)))
                elif kind:
                    steps.append(dict(at=f'0x{pc:04X}', op=kind))
                else:
                    steps.append(dict(at=f'0x{pc:04X}', op='call', target=f'0x{target:04X}'))
                regs = {}
            if name in BRANCHES or H.OPS.get(code, ('', 0))[1] == H.ZPR:
                work.append(target)
            if name in ('rts', 'rti') or (name == 'jmp' and H.OPS[code][1] in (H.IND, H.AIX)):
                break
            if name in ('bra', 'jmp'):
                pc = target
                continue
            pc += n
    return sorted(steps, key=lambda s: int(s['at'], 16))

def decode(dump):
    read = H.reader(dump, DUMP_BASE, MAP)
    if [read(SECTION_DISPATCH + i) for i in range(8)] != [173, 11, 45, 10, 170, 124, 247, 149]:
        sys.exit('pce_desert_spawns: no desert section dispatch at 0x95EF (not a desert dump?)')
    sections = []
    entries = [read(SECTION_TABLE + 2 * i) | read(SECTION_TABLE + 2 * i + 1) << 8 for i in range(SECTIONS)]
    for s, entry in enumerate(entries):
        if [read(entry + i) for i in range(6)] != [173, 10, 52, 10, 170, 124]:
            sys.exit(f'section {s}: unexpected state dispatch at {entry:#06x}')
        table = read(entry + 6) | read(entry + 7) << 8
        states = jump_table(read, table, entry)
        stop = set(entries) | set(states)
        sec = dict(section=s, entry=f'0x{entry:04X}', state_table=f'0x{table:04X}', states=[])
        for i, st in enumerate(states):
            sec['states'].append(dict(state=i, entry=f'0x{st:04X}', steps=walk(read, st, stop - {st})))
        sections.append(sec)
    return sections
OBJECT_TYPES, ACTOR_TYPES = (32135, 31881)
GENERATOR_IDS, WAVE_SCRIPTS = (33103, 33574)
WAVE_OPS = {0: ('end', 0), 1: ('wait', 1), 2: ('wait_until_a', 0), 3: ('wait_until_b', 0), 4: ('y', 2), 5: ('x', 2), 6: ('spawn_left', 1), 7: ('spawn_right', 1)}
SHAPES = {33144: bytes.fromhex('a944a00091'), 33838: bytes.fromhex('a90ba00091'), 33271: bytes.fromhex('bd268385'), 33087: bytes.fromhex('bd4f8185')}

def handler(dump, table, add, t, size=2):
    """The handler of a type: size 2 for objects (a handler word), 4 for actors (a handler word,"""
    read = H.reader(dump, DUMP_BASE, MAP)
    off, idx = (read(table + 2 * t), read(table + 2 * t + 1))
    if off & 128:
        return None
    bank = 104 + add + off
    rb = H.reader(dump, DUMP_BASE, {32768: bank, 40960: bank + 1})
    e = 32768 + size * idx
    out = dict(bank=f'0x{bank:02X}', handler=idx, address=f'0x{rb(e) | rb(e + 1) << 8:04X}')
    if size == 4:
        out['animations'] = f'0x{rb(e + 2) | rb(e + 3) << 8:04X}'
    return out

def generators(dump):
    rb = H.reader(dump, DUMP_BASE, {32768: 108, 40960: 109})
    for at, want in SHAPES.items():
        if bytes((rb(at + i) for i in range(len(want)))) != want:
            sys.exit(f'pce_desert_spawns: bank 0x6C code at {at:#06x} has an unexpected shape')
    w = lambda a: rb(a) | rb(a + 1) << 8
    gen = {}
    for param in range(2):
        a = w(GENERATOR_IDS + 2 * param)
        gen[param] = dict(spawns_actor='0x44', once_ids=[f'0x{rb(a + i):02X}' for i in range(6)])
    waves = {}
    for param in range(2):
        ip, ops = (w(WAVE_SCRIPTS + 2 * param), [])
        while len(ops) < 256:
            name, n = WAVE_OPS.get(rb(ip), (None, 0))
            if name is None:
                sys.exit(f'wave script {param}: unknown op {rb(ip):#04x} at {ip:#06x}')
            arg = w(ip + 1) if n == 2 else rb(ip + 1) if n == 1 else None
            ops.append(dict(op=name) | ({} if arg is None else {'kind' if 'spawn' in name else 'value': arg}))
            ip += 1 + n
            if name == 'end':
                break
        waves[param] = dict(spawns_actor='0x0B', script=ops)
    return dict(generator_0x0F=gen, wave_manager_0x13=waves)

def decode_all(dump):
    secs = decode(dump)
    placed = sorted({(x['op'], x['type']) for s in secs for st in s['states'] for x in st['steps'] if x['op'].startswith('spawn')})
    types = {}
    for op, t in placed + [('spawn_actor', '0x0B'), ('spawn_actor', '0x44')]:
        table, add, size = (OBJECT_TYPES, 4, 2) if op == 'spawn_object' else (ACTOR_TYPES, 8, 4)
        types[f"{('object' if op == 'spawn_object' else 'actor')} {t}"] = handler(dump, table, add, int(t, 16), size)
    return dict(sections=secs, types=types, **generators(dump))

def wave_positions(waves):
    out = set()
    for w in waves.values():
        x = y = 0
        for o in w['script']:
            if o['op'] == 'x':
                x = o['value']
            elif o['op'] == 'y':
                y = o['value']
            out.add((x, y))
    return out

def check_run(result, record, extra):
    """A recorded run (pce_ram_record.lua with the actor bank 10C000-10DFFF)."""
    import numpy as np
    rec = 12 + 8192 + extra
    b = np.fromfile(record, np.uint8)
    b = b[:len(b) // rec * rec].reshape(-1, rec)
    ram, act = (b[:, 12:12 + 8192], b[:, 12 + 8192:])
    w = lambda r, o: int(r[o]) | int(r[o + 1]) << 8
    steps = {s['section']: [x for st in s['states'] for x in st['steps']] for s in result['sections']}
    valid = {int(k.split()[1], 16) for k, v in result['types'].items() if k.startswith('object') and v}
    waves = wave_positions(result['wave_manager_0x13'])
    started, played = (False, set())
    seen_obj, seen_act, unknown, alive, census = (set(), set(), set(), {}, {})
    for i in range(len(b)):
        if ram[i, 199] != 8:
            continue
        objs = [act[i, 16 * k:16 * k + 16] for k in range(32)]
        if not started:
            started = all((r[0] == 0 or int(r[0]) in valid for r in objs)) and act[i, 3584] == 1
            if not started:
                continue
        sec = int(ram[i, 3339])
        played.add(sec)
        placed = {(int(x['type'], 16), x['param'], x['x'], x['y']) for x in steps[sec] if x['op'] == 'spawn_object'}
        for r in objs:
            if not r[0]:
                continue
            o = (int(r[0]), int(r[1]), w(r, 6), w(r, 4))
            if o in placed:
                seen_obj.add((sec,) + o)
            elif o[0] == 19 and any((p[:2] == o[:2] for p in placed)) and ((o[2], o[3]) in waves or o[2:] == (0, 0)):
                seen_obj.add((sec,) + next((p for p in placed if p[:2] == o[:2])))
            else:
                unknown.add((sec,) + o)
        for k in range(1, 96):
            r = act[i, 3584 + 48 * k:3584 + 48 * k + 48]
            t = int(r[0])
            if t and alive.get(k) != t:
                census[f'0x{t:02X}'] = census.get(f'0x{t:02X}', 0) + 1
                for x in steps[sec]:
                    if x['op'] == 'spawn_actor' and int(x['type'], 16) == t and (abs(w(r, 6) - x['x']) <= 16) and (abs(w(r, 4) - x['y']) <= 16):
                        seen_act.add((sec, x['record']))
            alive[k] = t
    want_obj = {(s,) + (int(x['type'], 16), x['param'], x['x'], x['y']) for s in played for x in steps[s] if x['op'] == 'spawn_object'}
    want_act = {(s, x['record']) for s in played for x in steps[s] if x['op'] == 'spawn_actor'}
    missing = sorted(want_obj - seen_obj) + sorted(want_act - seen_act)
    report = dict(sections_played=sorted(played), object_placements=len(want_obj), actor_placements=len(want_act), missing=missing, unexplained_objects=sorted(unknown), actor_types_seen=census)
    return (started and (not unknown) and (not missing), report)

def self_test(dump):
    secs = decode(dump)
    s0 = secs[0]['states'][0]['steps']
    spawns = [x for x in s0 if x['op'] == 'spawn_object']
    if [(x['x'], x['y'], x['type']) for x in spawns] != [(800, 896, '0x0F'), (992, 896, '0x0F'), (1184, 896, '0x0F'), (1376, 896, '0x0F'), (0, 0, '0x13')]:
        sys.exit(f'self-test: section 0 opening spawns differ: {spawns}')
    bounds = next((x for x in s0 if x['op'] == 'camera_bounds'))
    if (bounds['y'], bounds['x']) != ([512, 1184], [0, 2248]):
        sys.exit(f'self-test: section 0 camera bounds {bounds}')
    r = decode_all(dump)
    if r['types']['object 0x0F']['address'] != '0x8004' or r['types']['object 0x13']['address'] != '0x81BD':
        sys.exit(f"self-test: generator handlers {r['types']}")
    if (r['types']['actor 0x0B']['bank'], r['types']['actor 0x0B']['address']) != ('0x72', '0x94D6') or (r['types']['actor 0x44']['bank'], r['types']['actor 0x44']['address']) != ('0x72', '0xAAD6'):
        sys.exit(f"self-test: actor handlers {r['types']['actor 0x0B']} {r['types']['actor 0x44']}")
    w0 = [o for o in r['wave_manager_0x13'][0]['script'] if o['op'].startswith('spawn')]
    if len(w0) != 3:
        sys.exit(f"self-test: section 0 wave script {r['wave_manager_0x13'][0]}")
    print('pce_desert_spawns self-test passed:', sum((len(st['steps']) for s in secs for st in s['states'])), 'steps')
    return 0

def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('dump', type=Path, help='banks 0x68-0x7F (pce_*_ram_0d0000.bin)')
    p.add_argument('--json', type=Path)
    p.add_argument('--self-test', action='store_true')
    p.add_argument('--check-run', type=Path, help='ram_record.bin of a desert run recorded with the actor bank')
    a = p.parse_args()
    dump = a.dump.read_bytes()
    if a.self_test:
        return self_test(dump)
    result = decode_all(dump)
    secs = result['sections']
    if a.json:
        a.json.write_text(json.dumps(dict(source='PC Engine Strider Hiryuu, desert chapter (banks 0x69, 0x6A, 0x6C)', **result), indent=1) + '\n')
    if a.check_run:
        ok, report = check_run(result, a.check_run, 8192)
        print(json.dumps(report, indent=1))
        print('run check', 'PASS' if ok else 'FAIL')
        return 0 if ok else 1
    for s in secs:
        print(f"section {s['section']} ({s['entry']}, states at {s['state_table']})")
        for st in s['states']:
            print(f"  state {st['state']} @ {st['entry']}")
            for x in st['steps']:
                rest = {k: v for k, v in x.items() if k not in ('at', 'op')}
                print(f"    {x['at']} {x['op']:<16} {rest}")
    print('types:', json.dumps(result['types']))
    print('generators:', json.dumps(result['generator_0x0F']))
    for k, w in result['wave_manager_0x13'].items():
        print(f'wave script {k}:', ' '.join((o['op'] + ('' if len(o) == 1 else f'={list(o.values())[1]}') for o in w['script'])))
    return 0
if __name__ == '__main__':
    sys.exit(main())
