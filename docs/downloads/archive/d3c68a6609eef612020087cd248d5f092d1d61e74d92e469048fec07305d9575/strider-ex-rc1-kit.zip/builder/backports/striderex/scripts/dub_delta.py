"""Strider EX English dub: the shipped form of the English cinematic tracks (DUB.md section 9)."""
import argparse
import hashlib
import json
import lzma
import struct
import sys
import wave
from pathlib import Path
MAGIC = b'STREXDUB'
FORMAT = 1
BLOCK = 4096
ORDERS = 4
GAP = 4410
TAG = b'strider-ex-dub-delta/1'
RATE = 44100

def track_key(track, pcm_bytes):
    """32-byte key: a domain-tagged SHAKE-256 of the track's whole disc PCM (16-bit LE stereo)."""
    h = hashlib.shake_256(TAG + b'/key\x00' + bytes([track]))
    h.update(pcm_bytes)
    return h.digest(32)

def keystream(key, n):
    return hashlib.shake_256(TAG + b'/stream\x00' + key).digest(n)

def xor(data, ks):
    import numpy as np
    return (np.frombuffer(data, np.uint8) ^ np.frombuffer(ks, np.uint8)).tobytes()

def spans_of(delta):
    """[start, end) sample spans where any channel differs, runs closer than GAP merged."""
    import numpy as np
    nz = np.flatnonzero((delta != 0).any(0))
    if not len(nz):
        return []
    cut = np.flatnonzero(np.diff(nz) > GAP)
    starts = np.concatenate([[nz[0]], nz[cut + 1]])
    ends = np.concatenate([nz[cut], [nz[-1]]]) + 1
    return [[int(a), int(b)] for a, b in zip(starts, ends)]

def to_ms(x):
    """FLAC's lossless mid/side: mid = (L + R) >> 1, side = L - R."""
    return (x[0] + x[1] >> 1, x[0] - x[1])

def from_ms(mid, side):
    import numpy as np
    m = mid << 1 | side & 1
    return np.stack([m + side >> 1, m - side >> 1])

def encode_channel(x):
    """(orders bytes, residuals int64): per block the fixed predictor with the least |residual|,"""
    import numpy as np
    orders, out = (bytearray(), [])
    hist = np.zeros(ORDERS - 1, np.int64)
    for i in range(0, len(x), BLOCK):
        blk = x[i:i + BLOCK]
        ext = np.concatenate([hist, blk])
        best = None
        for o in range(ORDERS):
            r = np.diff(ext, n=o)[-len(blk):] if o else blk
            cost = int(np.abs(r).sum())
            if best is None or cost < best[0]:
                best = (cost, o, r)
        orders.append(best[1])
        out.append(best[2])
        hist = ext[-(ORDERS - 1):]
    return (bytes(orders), np.concatenate(out) if out else np.zeros(0, np.int64))

def decode_channel(orders, r, n):
    """Inverse of encode_channel: integrate each block o times from the history's differences."""
    import numpy as np
    x = np.zeros(n, np.int64)
    hist = np.zeros(ORDERS - 1, np.int64)
    for b, i in enumerate(range(0, n, BLOCK)):
        o = orders[b]
        y = r[i:i + BLOCK].astype(np.int64)
        for k in range(o - 1, -1, -1):
            ck = np.diff(hist, n=k)[-1] if k else hist[-1]
            y = np.cumsum(y) + ck
        x[i:i + len(y)] = y
        hist = np.concatenate([hist, y])[-(ORDERS - 1):]
    return x

def zigzag(r):
    import numpy as np
    return np.where(r >= 0, 2 * r, -2 * r - 1).astype(np.uint32)

def unzigzag(u):
    import numpy as np
    u = u.astype(np.int64)
    return np.where(u & 1, -(u + 1 >> 1), u >> 1)

def planes(u):
    import numpy as np
    b = u.astype('<u4').view(np.uint8).reshape(-1, 4)
    return b''.join((b[:, k].tobytes() for k in range(4)))

def unplanes(data, n):
    import numpy as np
    b = np.frombuffer(data, np.uint8).reshape(4, n).T.copy()
    return b.view('<u4').reshape(-1)

def pack_track(delta):
    """(spans, coded bytes) for one track's delta (2, n) int64."""
    import numpy as np
    spans = spans_of(delta)
    x = np.concatenate([delta[:, a:b] for a, b in spans], axis=1) if spans else np.zeros((2, 0), np.int64)
    mid, side = to_ms(x)
    body = bytearray(struct.pack('<I', x.shape[1]))
    for ch in (mid, side):
        orders, r = encode_channel(ch)
        body += struct.pack('<I', len(orders)) + orders + planes(zigzag(r))
    return (spans, lzma.compress(bytes(body), preset=9 | lzma.PRESET_EXTREME))

def unpack_track(coded):
    data = lzma.decompress(coded)
    n = struct.unpack_from('<I', data, 0)[0]
    q, chans = (4, [])
    for _ in range(2):
        nb = struct.unpack_from('<I', data, q)[0]
        orders = data[q + 4:q + 4 + nb]
        q += 4 + nb
        r = unzigzag(unplanes(data[q:q + 4 * n], n))
        q += 4 * n
        chans.append(decode_channel(orders, r, n))
    return from_ms(*chans)

def pcm_bytes(x):
    import numpy as np
    return np.asarray(x, '<i2').T.tobytes()

def encode(tracks):
    """tracks: {number: (id, disc int (2, n), english int (2, n))} -> payload bytes."""
    import numpy as np
    header = dict(format=FORMAT, block=BLOCK, orders=ORDERS, gap=GAP, tag=TAG.decode(), note='EN = disc + delta over each span; key = SHAKE-256(tag/key, track, disc PCM); backports/striderex/DUB.md section 9', tracks={})
    blobs = bytearray()
    for t, (tid, disc, en) in sorted(tracks.items()):
        if disc.shape != en.shape:
            raise SystemExit(f'tr{t}: English {en.shape} and disc {disc.shape} differ in length')
        spans, coded = pack_track(en.astype(np.int64) - disc.astype(np.int64))
        keyed = xor(coded, keystream(track_key(t, pcm_bytes(disc)), len(coded)))
        header['tracks'][str(t)] = dict(id=tid, samples=int(disc.shape[1]), spans=spans, offset=len(blobs), length=len(keyed), english_sha256=hashlib.sha256(pcm_bytes(en)).hexdigest(), blob_sha256=hashlib.sha256(keyed).hexdigest())
        blobs += keyed
    h = json.dumps(header, indent=1).encode()
    return MAGIC + struct.pack('<I', len(h)) + h + bytes(blobs)

def read_header(payload):
    if payload[:8] != MAGIC:
        raise SystemExit('not a Strider EX dub payload')
    n = struct.unpack_from('<I', payload, 8)[0]
    header = json.loads(payload[12:12 + n])
    if header['format'] != FORMAT:
        raise SystemExit(f"payload format {header['format']}, this decoder reads {FORMAT}")
    return (header, 12 + n)

def decode_track(payload, track, disc):
    """The approved English track (2, n) int16 from the player's disc track, or SystemExit."""
    import numpy as np
    header, base = read_header(payload)
    row = header['tracks'][str(track)]
    keyed = payload[base + row['offset']:base + row['offset'] + row['length']]
    if hashlib.sha256(keyed).hexdigest() != row['blob_sha256']:
        raise SystemExit(f'tr{track}: the payload is damaged')
    if disc.shape[1] != row['samples']:
        raise SystemExit(f"tr{track}: the disc track has {disc.shape[1]} samples, the dub {row['samples']}")
    try:
        x = unpack_track(xor(keyed, keystream(track_key(track, pcm_bytes(disc)), len(keyed))))
    except lzma.LZMAError:
        raise SystemExit(f'tr{track}: this is not the disc the English track was made for')
    en = disc.astype(np.int64).copy()
    q = 0
    for a, b in row['spans']:
        en[:, a:b] += x[:, q:q + b - a]
        q += b - a
    if en.min() < -32768 or en.max() > 32767:
        raise SystemExit(f'tr{track}: decoded samples out of range (wrong disc?)')
    en = en.astype('<i2')
    if hashlib.sha256(pcm_bytes(en)).hexdigest() != row['english_sha256']:
        raise SystemExit(f'tr{track}: the decoded English track is not the approved one (wrong disc?)')
    return en

def read_wav(path):
    import numpy as np
    with wave.open(str(path), 'rb') as w:
        if w.getsampwidth() != 2 or w.getframerate() != RATE or w.getnchannels() != 2:
            raise SystemExit(f'{path}: not 16-bit 44.1 kHz stereo')
        return np.frombuffer(w.readframes(w.getnframes()), '<i2').reshape(-1, 2).T.astype(np.int64)

def write_wav(path, x):
    with wave.open(str(path), 'wb') as w:
        w.setnchannels(2)
        w.setsampwidth(2)
        w.setframerate(RATE)
        w.writeframes(pcm_bytes(x))

def disc_track(cue, track):
    """The pinned disc track as int (2, n), through dub_beds (checks the PCM pin)."""
    import numpy as np
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    import dub_beds as B
    mt = B.manifest()['inputs']['tracks'][str(track)]
    x = B.disc_pcm(cue, track, mt['pcm_sha256'])
    return (mt['id'], np.round(x * 32768).astype(np.int64))

def dialogue_tracks():
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    import dub_beds as B
    return [int(t) for t, m in B.manifest()['inputs']['tracks'].items() if m.get('dialogue', True)]

def cmd_encode(a):
    tracks = {}
    for t in a.tracks or dialogue_tracks():
        tid, disc = disc_track(a.cue, t)
        tracks[t] = (tid, disc, read_wav(a.english / f'tr{t:02d}_en.wav'))
    payload = encode(tracks)
    a.out.parent.mkdir(parents=True, exist_ok=True)
    a.out.write_bytes(payload)
    header, _ = read_header(payload)
    for t, row in header['tracks'].items():
        print(f"tr{t}: {sum((b - s for s, b in row['spans'])) / RATE:5.1f} s in {len(row['spans'])} spans, {row['length'] / 1000000.0:.2f} MB")
    print(f'{a.out}: {len(payload) / 1000000.0:.2f} MB, SHA-256 {hashlib.sha256(payload).hexdigest()}')
    return 0

def cmd_decode(a):
    payload = a.payload.read_bytes()
    header, _ = read_header(payload)
    a.out.mkdir(parents=True, exist_ok=True)
    for t in sorted((int(x) for x in header['tracks'])):
        _, disc = disc_track(a.cue, t)
        write_wav(a.out / f'tr{t:02d}_en.wav', decode_track(payload, t, disc))
        print(f'tr{t}: decoded, matches the approved English track')
    return 0
ENGLISH_MANIFEST = Path(__file__).resolve().parents[1] / 'manifests' / 'dub_english.json'

def cmd_pin(a):
    """Pin the approved English tracks and their payload (manifests/dub_english.json)."""
    payload = a.payload.read_bytes()
    header, _ = read_header(payload)
    man = json.loads(ENGLISH_MANIFEST.read_text()) if ENGLISH_MANIFEST.exists() else {}
    m = ENGLISH_MANIFEST.parent
    tracks = {}
    for t, row in header['tracks'].items():
        wav = a.english / f'tr{int(t):02d}_en.wav'
        if hashlib.sha256(pcm_bytes(read_wav(wav))).hexdigest() != row['english_sha256']:
            raise SystemExit(f'tr{t}: {wav} is not the track this payload was encoded from')
        tracks[t] = dict(id=row['id'], samples=row['samples'], english_pcm_sha256=row['english_sha256'], english_wav_sha256=hashlib.sha256(wav.read_bytes()).hexdigest())
    man.update(schema=1, tracks=tracks, inputs=dict(takes='manifests/dub_takes.json', beds='manifests/dub_beds.json outputs.beds', fit_sha256=hashlib.sha256((m / 'dub_fit.json').read_bytes()).hexdigest(), subtitles_sha256=hashlib.sha256((m / 'subtitles.json').read_bytes()).hexdigest()), payload=dict(format=header['format'], bytes=len(payload), sha256=hashlib.sha256(payload).hexdigest(), note='LZMA output can differ between liblzma versions, so a re-encode elsewhere may differ in bytes; it must decode to the same English PCM (english_pcm_sha256), which is the identity that matters'))
    ENGLISH_MANIFEST.write_text(json.dumps(man, indent=1, ensure_ascii=False) + '\n')
    print(f'pinned {len(tracks)} English tracks and the {len(payload) / 1000000.0:.2f} MB payload in {ENGLISH_MANIFEST.name}')
    return 0

def self_test():
    import numpy as np
    rng = np.random.default_rng(7)
    ok = True

    def check(name, cond, detail=''):
        nonlocal ok
        ok &= bool(cond)
        print(f"{('PASS' if cond else 'FAIL')} {name} {detail}")
    n = 3 * RATE + 123
    t = np.arange(n) / RATE
    music = np.stack([np.sin(2 * np.pi * 220 * t), np.sin(2 * np.pi * 330 * t)]) * 9000
    jav = np.sin(2 * np.pi * 150 * t) * 7000 * ((t > 0.8) & (t < 1.9))
    disc = np.round(music + np.stack([jav, jav * 0.9])).astype(np.int64)
    disc[:, ::97] += rng.integers(-3, 4, size=disc[:, ::97].shape)
    env = np.sin(2 * np.pi * 180 * t) * 6000 * ((t > 0.85) & (t < 2.2))
    en = np.clip(np.round(music + np.stack([env, env])), -32768, 32767).astype(np.int64)
    en[:, :int(0.7 * RATE)] = disc[:, :int(0.7 * RATE)]
    en[:, int(2.4 * RATE):] = disc[:, int(2.4 * RATE):]
    x = rng.integers(-30000, 30000, size=(2, 9000)).astype(np.int64)
    for o in range(ORDERS):
        orders, r = encode_channel(x[0])
        check(f'channel round trip (order choice {o})', np.array_equal(decode_channel(orders, r, x.shape[1]), x[0]))
        x[0] = np.cumsum(x[0]) % 30000 - 15000
    m, s = to_ms(x)
    check('mid/side round trip', np.array_equal(from_ms(m, s), x))
    payload = encode({99: ('test', disc, en)})
    got = decode_track(payload, 99, disc)
    check('decoded == English', np.array_equal(got.astype(np.int64), en), f'{len(payload)} bytes')
    header, _ = read_header(payload)
    sp = header['tracks']['99']['spans']
    check('only the differing span is stored', len(sp) == 1 and sp[0][0] >= int(0.7 * RATE) - 1 and (sp[0][1] <= int(2.4 * RATE) + 1), str(sp))
    other = disc.copy()
    other[0, 5] += 1
    try:
        decode_track(payload, 99, other)
        check('another disc is refused', False)
    except SystemExit as e:
        check('another disc is refused', True, str(e))
    keyed = payload[-header['tracks']['99']['length']:]
    zeros = sum((1 for b in keyed if b == 0)) / len(keyed)
    check('keyed bytes look random', zeros < 0.01, f'{zeros:.4f} zero bytes')
    return 0 if ok else 1

def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('command', nargs='?', choices=['encode', 'decode', 'pin'])
    p.add_argument('--self-test', action='store_true')
    p.add_argument('--cue', type=Path, help='the restored PC Engine disc cue sheet')
    p.add_argument('--english', type=Path, help='encode: dub_mix.py mix output (trNN_en.wav)')
    p.add_argument('--payload', type=Path, help='decode: the payload')
    p.add_argument('--out', type=Path, help='encode: the payload file; decode: a directory')
    p.add_argument('--tracks', type=int, nargs='+')
    a = p.parse_args()
    if a.self_test:
        return self_test()
    if a.command == 'encode' and a.cue and a.english and a.out:
        return cmd_encode(a)
    if a.command == 'decode' and a.cue and a.payload and a.out:
        return cmd_decode(a)
    if a.command == 'pin' and a.english and a.payload:
        return cmd_pin(a)
    p.error('encode needs --cue --english --out; decode needs --cue --payload --out; pin needs --english --payload')
if __name__ == '__main__':
    sys.exit(main())
