"""Check every English mouth frame and representative Japanese scenes in game."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
from pathlib import Path
import boss_mouth as M
import boss_scene_binary as BB
import boss_scene_gate as B
from boss_voice_gate import inventory
import desert_gate as G

def sha(b):
    return hashlib.sha256(b).hexdigest()

def picture(seq, v, rest):
    if v < 0:
        return rest
    for n, code in seq:
        if v < n:
            return code
        v -= n
    return rest

def gate(a):
    meta = M.audit(a.control, a.build)
    _, files = inventory(a.build)
    old = json.loads(a.routing_receipt.read_text())
    control = json.loads((a.control / 'build.json').read_text())
    if not old['passed'] or len(old['results']) != 36 or old['input_files'] != {m: s['files'] for m, s in control['sets'].items()}:
        raise ValueError('routing receipt does not match control')
    rt = json.loads((a.runtime / 'runtime.json').read_text())
    binary = Path(rt['binary'])
    if sha(binary.read_bytes()) != rt['binary_sha256'] or old['runtime']['binary_sha256'] != rt['binary_sha256']:
        raise ValueError('runtime changed')
    work = a.workdir.resolve()
    work.mkdir(parents=True, exist_ok=a.reuse)
    manifest = json.loads((Path(__file__).resolve().parents[1] / 'manifests/boss_scenes.json').read_text())
    cases = {s['id']: s['gate'] for s in manifest['scenes']}
    jobs = []
    for m, set_name in (('striderua', 'striderus01'), ('striderjr', 'striderjs01')):
        for pack in (False, True):
            label = m + ('_pack' if pack else '_native')
            variant = work / 'variants' / label
            f = dict(files[m])
            p6 = bytearray(f['strex_p6.bin'])
            p6[-2] = p6[-2] & ~7 | int(pack)
            f['strex_p6.bin'] = bytes(p6)
            if not a.reuse:
                d = variant / m
                d.mkdir(parents=True)
                for n, b in f.items():
                    (d / n).write_bytes(b)
                vm = dict(meta, sets={m: dict(meta['sets'][m], files={n: sha(b) for n, b in f.items()})})
                (variant / 'build.json').write_text(json.dumps(vm) + '\n')
                G.stage_sets(variant, set_name, a.hbmame, a.rom_dir.resolve(), work / 'sets' / label)
            _, actual = inventory(variant)
            if actual[m] != f:
                raise ValueError('staged variant is stale')
            staged = list((work / 'sets' / label / set_name).glob('*.p6'))
            if len(staged) != 1 or staged[0].read_bytes() != f['strex_p6.bin']:
                raise ValueError('staged bank is stale')
            for sid in BB.IDS if m == 'striderua' else ('stp_strongman', 'sib_solo'):
                prior = next((r for r in old['results'] if r['machine'] == m and r['pack'] == pack and (not r['override']) and (r['scene'] == sid)))
                jobs.append((m, set_name, pack, label, sid, prior))

    def run(job):
        m, set_name, pack, label, sid, prior = job
        E = prior['entry']
        N = prior['frames']
        sc = cases[sid]
        frames = sc['frames'] + N + 300
        out = work / 'runs' / label / sid
        if not a.reuse:
            B.run(binary, work / 'sets' / label, set_name, out, sc, frames, B.shift_inputs(sc['inputs'], N, E), shift=(E, N), holds=B.holds_env(B.research_writes(sc), (E, N)), shots=','.join((str(E + n) for n in (100, 200, 300, 400))) if sid == 'stp_strongman' else '')
        log = B.load(out, frames)
        if B.entries_of(log, 'entry') != [E] or B.entries_of(log, 'exit') != [E + N]:
            raise ValueError('scene duration changed')
        if B.freeze_diff(log['dumps']['entry'], log['dumps']['exit']):
            raise ValueError('game did not freeze')
        cue = 192 + BB.IDS.index(sid) if m == 'striderua' else 184 + BB.IDS.index(sid) if pack else None
        want = [(E + 2, 252 if pack else 241)] + ([] if cue is None else [(E + 72, cue)])
        if [(f, v) for f, v, s in B.sound_writes(log) if s and v != 255] != want:
            raise ValueError('voice timing changed')
        raw = files[m]['strex_p6.bin']
        bank = bytes((raw[k ^ 1] for k in range(1048576)))
        record = next((r for r in BB.scenes(bank) if r['id'] == sid))
        rest = BB.word(bank, record['at'] + 46)
        original = M.sequence(bank, BB.long(bank, record['at'] + 48) - BB.BASE)
        row = next((r for r in meta['sets'][m]['boss_mouth']['rows'] if r['id'] == sid and r['mode'] == ('pack' if pack else 'native')))
        expected = row['sequence'] if m == 'striderua' else original
        checked = changed = quiet_tail = 0
        for v in B.scene_vblanks(log):
            if v['prep'] != v['n']:
                raise ValueError('picture was not prepared in time')
            if v['pl'] >> 8 & 15 != 4:
                continue
            clock = v['n'] - 71
            code = picture(expected, clock, rest)
            if v['pic'] != code:
                raise ValueError(f"{label} {sid} n {v['n']}: wrong mouth picture")
            if v['layer'] != 0 and v['list'] and (not any((e[2] == code for e in v['list']))):
                raise ValueError('mouth picture is absent from the displayed object list')
            checked += 1
            changed += code != picture(original, clock, rest)
            if m == 'striderua' and clock >= row['frames']:
                if code != rest:
                    raise ValueError('mouth continues after English recording ends')
                quiet_tail += 1
        if checked < 200 or (m == 'striderjr' and changed):
            raise ValueError('missing frames or changed Japanese sequence')
        if m == 'striderua' and row['opens'] and (not changed or quiet_tail < 10):
            raise ValueError('new English envelope was not exercised')
        print('PASS mouth', label, sid, checked, 'frames;', changed, 'follow the new recording', flush=True)
        return dict(machine=m, pack=pack, scene=sid, checked_frames=checked, changed_mouth_frames=changed, resting_after_voice_frames=quiet_tail, japanese_sequence_unchanged=m == 'striderjr', sound_and_page_timing_unchanged=True, game_freeze_and_preparation_passed=True, register_trace_sha256=sha((out / 'g_regs.tsv').read_bytes()), passed=True)
    with ThreadPoolExecutor(2) as ex:
        results = list(ex.map(run, jobs))
    report = dict(schema='striderex-english-boss-mouth/1', passed=True, inherited_routing_receipt_sha256=sha(a.routing_receipt.read_bytes()), exact_inverse_audit_passed=True, input_files={m: s['files'] for m, s in meta['sets'].items()}, all_other_roms_and_voice_selector_byte_identical=True, results=results, hardware_review_granted=False)
    a.receipt.write_text(json.dumps(report, indent=2) + '\n')
    print('PASS: every English mouth frame, Japanese controls, original timing and inherited 36-case routing')

def main():
    p = argparse.ArgumentParser(description=__doc__)
    for n in ('control', 'build', 'routing-receipt', 'runtime', 'hbmame', 'rom-dir', 'workdir', 'receipt'):
        p.add_argument('--' + n, type=Path, required=True)
    p.add_argument('--reuse', action='store_true')
    gate(p.parse_args())
if __name__ == '__main__':
    main()
