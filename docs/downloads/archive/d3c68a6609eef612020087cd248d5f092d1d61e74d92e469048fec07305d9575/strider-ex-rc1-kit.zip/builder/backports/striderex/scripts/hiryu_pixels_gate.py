"""Check the exact sprite-pixel delta, all native body matrices and actual poses."""
import argparse
from concurrent.futures import ThreadPoolExecutor
from functools import lru_cache
import json
from pathlib import Path
import numpy as np
from PIL import Image, ImageDraw
import boss_scene as B
import boss_voice_gate as V
import cps1_gfx as C
import desert_gate as G
import hiryu_pixels as H
TABLES = {'striderua': (87550, 101164, 108178, 459226), 'striderjr': (86850, 100464, 107478, 458534)}
PALETTE = (61440, 65464, 64918, 64098, 63280, 65535, 64477, 63385, 62293, 64703, 64157, 63610, 62791, 65392, 64000, 63087)

def components(pens):
    """Eight-connected opaque components, independent of the producer."""
    todo = set(zip(*np.where(pens != 15)))
    result = []
    while todo:
        first = todo.pop()
        part, pending = ({first}, [first])
        while pending:
            y, x = pending.pop()
            for dy in (-1, 0, 1):
                for dx in (-1, 0, 1):
                    q = (y + dy, x + dx)
                    if q in todo:
                        todo.remove(q)
                        part.add(q)
                        pending.append(q)
        result.append(part)
    return result

def matrices(program, graphics, machine):
    base, start, end, shapes = TABLES[machine]
    word = lambda a: int.from_bytes(program[a:a + 2], 'big')

    @lru_cache(None)
    def tile(code):
        return C.get_tile(graphics, code * 128, 16)
    result = {}
    at = start
    while at < end:
        count, shape = program[at:at + 2]
        sh = program[shapes + shape * 8:shapes + shape * 8 + 8]
        nx, ny = (sh[4] + 1, sh[5] + 1)
        codes = [word(at + 2 + i * 2) for i in range(nx * ny)]
        if count != sum((c != 65535 for c in codes)):
            raise ValueError('native matrix boundary or count differs')
        pens = np.full((ny * 16, nx * 16), 15, dtype='int32')
        for i, code in enumerate(codes):
            if code != 65535:
                y, x = (i // nx * 16, i % nx * 16)
                pens[y:y + 16, x:x + 16] = tile(code)
        result[at] = (pens, codes, shape)
        at += 2 + 2 * nx * ny
    if at != end or len(result) != 249:
        raise ValueError('native Hiryu matrix census differs')
    return result

def catalog(program, graphics, machine):
    """Model the native compact two-part drawer, including ordering and flips."""
    mats = matrices(program, graphics, machine)
    base, start, _, shapes = TABLES[machine]
    word = lambda a: int.from_bytes(program[a:a + 2], 'big')
    signed = lambda v, bits: (v ^ 1 << bits - 1) - (1 << bits - 1)
    result = {}
    for at in range(base, start, 2):
        upper, lower, attr = (base + word(at + 4), base + word(at + 10), word(at + 6))
        if upper not in mats or lower not in mats or attr not in (14, 46, 78, 110):
            continue
        parts = [(upper, signed(program[at + 8], 8), signed(program[at + 9], 8)), (lower, 0, 0)]
        if program[at]:
            parts.reverse()
        entries = []
        for ptr, dx, dy in parts:
            pens, codes, shape = mats[ptr]
            nx = pens.shape[1] // 16
            ox = signed(word(shapes + shape * 8), 16)
            oy = signed(word(shapes + shape * 8 + 2), 16)
            for i, code in enumerate(codes):
                if code == 65535:
                    continue
                x = dx + (-ox - 16 - i % nx * 16 if attr & 32 else ox + i % nx * 16)
                y = -dy - oy + i // nx * 16
                tile = pens[i // nx * 16:i // nx * 16 + 16, i % nx * 16:i % nx * 16 + 16]
                if attr & 32:
                    tile = tile[:, ::-1]
                if attr & 64:
                    tile = tile[::-1]
                entries.append((x, y, tile))
        x0, y0 = (min((e[0] for e in entries)), min((e[1] for e in entries)))
        x1, y1 = (max((e[0] + 16 for e in entries)), max((e[1] + 16 for e in entries)))
        image = np.full((y1 - y0, x1 - x0), 15, dtype='int32')
        for x, y, tile in reversed(entries):
            target = image[y - y0:y - y0 + 16, x - x0:x - x0 + 16]
            target[tile != 15] = tile[tile != 15]
        result[at] = image
    return result

def gate(a):
    a.workdir = a.workdir.resolve()
    a.workdir.mkdir(parents=True, exist_ok=a.reuse)
    oldmeta, oldfiles = V.inventory(a.control)
    newmeta, newfiles = V.inventory(a.build)
    source = B.stock_gfx(a.rom_dir)
    expected = {(c * 16 + x, y) for c, ps in H.PIXELS.items() for x, y in ps}
    rows = []
    review = []
    for machine in TABLES:
        if any((newfiles[machine][n] != b for n, b in oldfiles[machine].items())):
            raise ValueError('pre-existing ROM member changed')
        region = bytearray(source)
        for offset, crc in H.K.GFX_CRCS.items():
            stock = {p.name: p.read_bytes() for p in (a.rom_dir / machine).iterdir() if p.is_file()}
            name = next((n for n, b in stock.items() if H.K.crc(b) == crc))
            if name in newfiles[machine]:
                view = np.frombuffer(region, dtype='uint8').reshape(-1, 8)
                data = np.frombuffer(newfiles[machine][name], dtype='uint8').reshape(-1, 2)
                view[offset // 8:offset // 8 + len(data), offset % 8:offset % 8 + 2] = data
        changed = set()
        for code in range(32768):
            if source[code * 128:(code + 1) * 128] == region[code * 128:(code + 1) * 128]:
                continue
            old = C.get_tile(source, code * 128, 16)
            new = C.get_tile(region, code * 128, 16)
            for y, x in zip(*np.where(old != new)):
                if (old[y, x], new[y, x]) != (0, 15):
                    raise ValueError('a pixel was repainted rather than cleared')
                changed.add((code * 16 + int(x), int(y)))
        if changed != expected:
            raise ValueError('pixel delta differs from the nine reviewed points')
        program = B.stock_image(a.rom_dir, machine)
        actual, _ = G.images(a.build.resolve(), a.rom_dir.resolve(), machine)
        base, start, end, shapes = TABLES[machine]
        if actual[base:end] != program[base:end]:
            raise ValueError('native Hiryu animation records changed')
        for _, _, shape in matrices(program, source, machine).values():
            at = shapes + shape * 8
            if actual[at:at + 8] != program[at:at + 8]:
                raise ValueError('native body shape changed')
        before, after = (catalog(program, source, machine), catalog(program, region, machine))
        altered = [at for at in before if not np.array_equal(before[at], after[at])]
        for at in altered:
            old, new = (before[at], after[at])
            delta = old != new
            if np.any(old[delta] != 0) or np.any(new[delta] != 15):
                raise ValueError('animation gained pixels or lost a nonblack pen')

        def specks(graphics):
            count = 0
            for pens, _, _ in matrices(program, graphics, machine).values():
                for part in components(pens):
                    nearby = any(((y + dy, x + dx) not in part and 0 <= y + dy < pens.shape[0] and (0 <= x + dx < pens.shape[1]) and (pens[y + dy, x + dx] != 15) for y, x in part for dy in range(-2, 3) for dx in range(-2, 3))) if len(part) <= 4 else True
                    if len(part) <= 4 and (not nearby) and all((pens[y, x] == 0 for y, x in part)):
                        count += 1
            return count
        oldspecks, newspecks = (specks(source), specks(region))
        if (oldspecks, newspecks) != (4, 0):
            raise ValueError('body matrix speck census differs')
        rows.append(dict(machine=machine, matrices=249, frames=len(before), changed_frames=len(altered), detached_components_before=oldspecks, detached_components_after=newspecks, exactly_nine_black_pixels_cleared=True, passed=True))
        if machine == 'striderua':
            review = [(at, before[at], after[at]) for at in altered]
    colors = np.array([B.rgb(w) for w in PALETTE], dtype='uint8')
    sheet = Image.new('RGB', (960, (len(review) + 3) // 4 * 230), '#6666ff')
    draw = ImageDraw.Draw(sheet)
    for i, (at, old, new) in enumerate(review):
        x, y = (i % 4 * 240, i // 4 * 230)
        draw.text((x, y), hex(at) + '  before / after', fill='white')
        for j, pens in enumerate((old, new)):
            im = Image.fromarray(colors[pens])
            im = im.resize((im.width * 2, im.height * 2), Image.Resampling.NEAREST)
            sheet.paste(im, (x + j * 120, y + 20))
    sheet.save(a.workdir / 'all-affected-poses.png')
    runtime = json.loads((a.runtime / 'runtime.json').read_text())
    binary = Path(runtime['binary'])
    if V.sha(binary.read_bytes()) != runtime['binary_sha256']:
        raise ValueError('runtime identity changed')
    jobs = []
    for label, build in (('control', a.control), ('candidate', a.build)):
        for machine in TABLES:
            name = 'striderus01' if machine == 'striderua' else 'striderjs01'
            sets = G.stage_sets(build.resolve(), name, a.hbmame, a.rom_dir.resolve(), a.workdir / 'sets' / (label + machine))
            inventory = oldmeta if label == 'control' else newmeta
            hashes = {V.sha(p.read_bytes()) for p in (sets / name).iterdir() if p.is_file()}
            if not set(inventory['sets'][machine]['files'].values()) <= hashes:
                raise ValueError('staged set does not carry every candidate member')
            jobs.append((label, machine, sets, name))

    def run(job):
        label, machine, sets, name = job
        out = a.workdir / (label + '_' + machine)
        env = dict(G.debug_env(5, 2, 1250, inputs=False), MOTION='128', CLIMB='1', STREX_INPUTS='450-1250:P1_JOYSTICK_RIGHT', SHOTS='1150-1200@50', VIDEO_DUMPS='1200')
        if not a.reuse or not (out / 'motion.tsv').exists():
            G.run(binary, sets, name, out, env, 1250)
        return (label, machine, out)
    with ThreadPoolExecutor(2) as ex:
        runs = {(l, m): p for l, m, p in ex.map(run, jobs)}
    comparisons = []
    for machine in TABLES:
        old, new = (runs['control', machine], runs['candidate', machine])
        if (old / 'motion.tsv').read_bytes() != (new / 'motion.tsv').read_bytes():
            raise ValueError('graphics repair changes player, camera or sprite entries')
        pixels = []
        for frame in (1150, 1200):
            original = np.array(Image.open(old / f's_{frame:05d}.png').convert('RGB'))
            repaired = np.array(Image.open(new / f's_{frame:05d}.png').convert('RGB'))
            delta = np.any(original != repaired, axis=2)
            if not 0 <= delta.sum() <= 9 or np.any(original[delta] != 0):
                raise ValueError('actual pose did not remove only detached black pixels')
            pixels.append(int(delta.sum()))
        if sum(pixels) < 3:
            raise ValueError('no affected actual pose was captured')
        comparisons.append(dict(machine=machine, captures_removed_black_pixels=pixels, motion_and_sprite_entries_identical=True, passed=True))
    report = dict(schema='striderex-hiryu-pixel-gate/1', passed=True, static=rows, runtime=comparisons, input_files={label: {m: s['files'] for m, s in meta['sets'].items()} for label, meta in (('control', oldmeta), ('candidate', newmeta))}, runtime_sha256=runtime['binary_sha256'], hardware_review_granted=False)
    a.receipt.write_text(json.dumps(report, indent=2) + '\n')
    print('PASS: exact nine-pixel delta; all 249 matrices; both regional actual poses; identical movement')
if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    for name in ('control', 'build', 'rom-dir', 'runtime', 'hbmame', 'workdir', 'receipt'):
        p.add_argument('--' + name, type=Path, required=True)
    p.add_argument('--reuse', action='store_true')
    gate(p.parse_args())
