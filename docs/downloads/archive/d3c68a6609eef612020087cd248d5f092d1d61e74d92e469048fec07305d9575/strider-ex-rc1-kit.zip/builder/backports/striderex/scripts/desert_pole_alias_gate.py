"""Qualify real pole-side walking and preserve the repaired landing surface."""
import argparse
from concurrent.futures import ThreadPoolExecutor
from copy import deepcopy
import json
from pathlib import Path
import subprocess
import sys
import tempfile
from PIL import Image, ImageChops, ImageDraw
import desert_gate as G
import desert_smooth as SM
import desert_pole_alias as M
import desert_slopes as S
import desert_ex as D
import respawn_fix as R
from boss_voice_gate import inventory, sha
SETS = {'striderua': 'striderus01', 'striderjr': 'striderjs01'}

def plans():
    out = {}
    for i, left in enumerate(M.POLES[1:], 1):
        x, y = (left - 68, 1631)
        out[f'walk{i}'] = (3, 2400, dict(WARP=';'.join((f'{f}:{x},{y}' for f in range(2100, 2141))), POKEW=f'2100:ff0ff4={x - 192:04x};2100:ff0ff8={y - 144:04x};2130:ff10cc=0200;2130:ff10ce=0000;2130:ff10ec=0100;2130:ff1116=0000', STREX_INPUTS='450-2099:P1_JOYSTICK_RIGHT;1800-2099@100/14:P1_BUTTON2;2150-2400:P1_JOYSTICK_RIGHT', CLIMB='1', CLIMB_END='2099', SHOTS='2140-2400@10'))
    for depth in (1599, 1615, 1630):
        out[f'release{depth}'] = (3, 2500, dict(CLIMB='1', CLIMB_END='2105', WARP=f'2100:6194,{depth}', STREX_INPUTS='450-2119:P1_JOYSTICK_RIGHT;1800-2099@100/14:P1_BUTTON2;2120-2133:P1_BUTTON2;2120-2140:P1_JOYSTICK_DOWN', SHOTS='2200-2500@50'))
    out['stock'] = (1, 1300, dict(STREX_INPUTS='450-1300:P1_JOYSTICK_RIGHT', SHOTS='500-1300@100'))
    return out

def signature(rd, tables, code, flips):
    result = []
    for k in 'ABCD':
        pg, ty, fp, flags, rec = tables[k]
        page = rd(pg + (code >> 8) + 8 * flips)[0]
        v = rd(ty + (page - 1) * 256 + (code & 255))[0] if page else 0
        flagpage = rd(fp + (code >> 8) + 8 * flips)[0]
        flag = rd(flags + (flagpage - 1) * 256 + (code & 255))[0] if flagpage else 0
        profile = rd(rec + (v - 32) * 33, 33) if v >= 32 else bytes([int(bool(v))] + [v] * 32)
        result.append((flag, profile))
    return tuple(result)

def static(old, new):
    results = []
    for machine in SETS:
        parts = []
        for fs in (old, new):
            f = fs[machine]
            im = R.compose(f, R.SETS[machine])
            p = f['strex_p6.bin']
            bank = bytes((p[i ^ 1] for i in range(len(p))))
            parts.append((im, bank, S.reader(im, bank), D.collision_sets(im)))
        caches = [{}, {}]
        changed, count = ([], 0)
        for stage, index in [(s, 0) for s in range(5)] + [(5, i) for i in range(7)]:
            generators = [M.cells(im, bank, stage, index) for im, bank, rd, tables in parts]
            for a, b in zip(*generators):
                if a[0] != b[0]:
                    raise ValueError('world-grid inventory disagrees')
                signs = []
                for i, cell in enumerate((a, b)):
                    e = cell[2]
                    key = (S.be16(e) & 16383, e[3] >> 5 & 3)
                    if key not in caches[i]:
                        im, bank, rd, tables = parts[i]
                        caches[i][key] = signature(rd, tables, *key)
                    signs.append(caches[i][key])
                count += 1
                if signs[0] != signs[1]:
                    if any((flag or any(profile[1:]) for flag, profile in signs[1])):
                        raise ValueError('changed cell was not restored to empty space')
                    changed.append([stage, index, *a[0]])
        expected = [[5, 1, left // 32, row] for left in M.POLES for row in (48, 50)]
        if sorted(changed) != sorted(expected):
            raise ValueError('collision changed beyond the ten aliased empty cells')
        im, bank, rd, tables = parts[1]
        floor = S.Floor(im, bank, S.layer_record(im, 5, 1))
        columns = 0
        for left in M.POLES:
            for x in list(range(left, left + 18)) + list(range(left + 54, left + 72)):
                if (1599, 1) not in floor.surfaces(x) or (1648, 1) not in floor.surfaces(x):
                    raise ValueError('repaired landing or original cap lost')
                columns += 1
        results.append(dict(machine=machine, compared_world_cells=count, restored_empty_cells=changed, other_cell_signatures_exact=True, landing_columns_and_caps_preserved=columns, passed=True))
    return results

def compare(case, old, new):
    a, b = [SM.read_motion(p) for p in (old, new)]
    result = dict(case=case, frames=len(b), passed=True)
    if len(a) != len(b):
        raise ValueError('paired frame counts differ')
    if case.startswith('walk'):
        left = M.POLES[int(case[-1])]
        want = left + 2
        for rr in (a, b):
            if any(((r['st'], r['hy'], r['hx']) != (0, 1631, left - 68) for r in rr if 2142 <= r['frame'] <= 2149)):
                raise ValueError('fixture did not settle on the real deck before release')
        for rr, x in ((a, left - 30), (b, want)):
            stable = [r for r in rr if 2250 <= r['frame'] <= 2400]
            if len(stable) != 151 or any(((r['st'], r['hx'], r['hy']) != (4, x, 1631) for r in stable)):
                raise ValueError('expected ghost/real pole contact not observed')
        first = next((r['frame'] for r in b if r['frame'] >= 2150 and r['st'] == 4))
        if any((r['st'] != 0 or r['hy'] != 1631 for r in b if 2150 <= r['frame'] < first)):
            raise ValueError('walk caught a wall or left the ground before the visible stem')
        if want + 16 != left + 18:
            raise ValueError('native hand probe does not meet the actual stem')
        result.update(old_ghost_contact_x=left - 30, new_contact_x=want, real_stem_left_x=left + 18, native_hand_probe_x=want + 16, first_real_contact_frame=first, gap_removed_pixels=32, stable_contact_frames=151, no_jump_or_fixture_writes_during_walk=True)
    elif case.startswith('release'):
        for rr in (a, b):
            stable = [r for r in rr if 2200 <= r['frame'] <= 2500]
            if len(stable) != 301 or any(((r['st'], r['hy']) != (0, 1631) for r in stable)):
                raise ValueError('low release no longer lands and stays on the deck')
        result.update(landing_preserved=True, stable_landing_frames=301)
    else:
        if a != b or G.read(old) != G.read(new):
            raise ValueError('stock movement or game clock changed')
        n = 0
        for p in new.glob('s_*.png'):
            if ImageChops.difference(Image.open(p).convert('RGB'), Image.open(old / p.name).convert('RGB')).getbbox():
                raise ValueError('stock picture changed')
            n += 1
        if n < 5:
            raise ValueError('stock picture witnesses missing')
        result.update(stock_trace_exact=True, pictures_exact=n)
    result['traces'] = {label: {n: sha((p / n).read_bytes()) for n in ('frames.tsv', 'motion.tsv', 'desert.tsv')} for label, p in (('control', old), ('candidate', new))}
    return result

def main():
    p = argparse.ArgumentParser(description=__doc__)
    for name in ('control', 'build', 'runtime', 'hbmame', 'rom-dir', 'workdir', 'receipt'):
        p.add_argument('--' + name, type=Path, required=True)
    p.add_argument('--reuse', action='store_true')
    p.add_argument('--preview-out', type=Path)
    a = p.parse_args()
    M.audit(a.control, a.build)
    work = a.workdir.resolve()
    work.mkdir(parents=True, exist_ok=a.reuse)
    metas, files, sets = ({}, {}, {})
    rt = json.loads((a.runtime / 'runtime.json').read_text())
    binary = Path(rt['binary'])
    if sha(binary.read_bytes()) != rt['binary_sha256'] or not rt['board_wait']:
        raise ValueError('matching conservative prepared runtime required')
    for label, build in (('control', a.control), ('candidate', a.build)):
        metas[label], files[label] = inventory(build)
        for machine, setname in SETS.items():
            roms = G.stage_sets(build.resolve(), setname, a.hbmame, a.rom_dir.resolve(), work / 'sets' / f'{label}_{machine}')
            have = {sha(q.read_bytes()) for q in (roms / setname).iterdir() if q.is_file()}
            if not set(metas[label]['sets'][machine]['files'].values()) <= have:
                raise ValueError('staged ROM identity differs')
            sets[label, machine] = (roms, setname)
    geometry = static(files['control'], files['candidate'])
    scenarios = plans()
    jobs = [(label, m, case) for label in metas for m in SETS for case in scenarios]

    def run(job):
        label, machine, case = job
        area, n, extra = scenarios[case]
        env = dict(G.debug_env(0 if case == 'stock' else 5, area, n, inputs=False), MOTION='16', **extra)
        out = work / 'runs' / f'{label}_{machine}_{case}'
        pin = dict(files=metas[label]['sets'][machine]['files'], environment=env, frames=n, runtime_sha256=rt['binary_sha256'], lua_sha256=sha(G.LUA.read_bytes()), debug_start_sha256=sha(G.DEBUG_START.read_bytes()))
        if not a.reuse or not (out / 'case.json').exists():
            G.run(binary, *sets[label, machine], out, env, n)
            (out / 'case.json').write_text(json.dumps(pin, indent=2) + '\n')
        if json.loads((out / 'case.json').read_text()) != pin or len(G.read(out)) != n:
            raise ValueError('stale or incomplete runtime case')
        print('Captured', label, machine, case, flush=True)
        return out
    with ThreadPoolExecutor(2) as ex:
        captured = dict(zip(jobs, ex.map(run, jobs)))
    checks = []
    for machine in SETS:
        for case in scenarios:
            r = compare(case, captured['control', machine, case], captured['candidate', machine, case])
            checks.append(dict(machine=machine, **r))
            print('PASS', machine, case, flush=True)
    with tempfile.TemporaryDirectory(prefix='fresh-', dir=work) as temp:
        fresh = Path(temp) / 'build'
        subprocess.run([sys.executable, str(Path(M.__file__)), '--build', str(a.control), '--out', str(fresh)], check=True)
        if inventory(fresh) != inventory(a.build):
            raise ValueError('empty-output reconstruction differs')
    rejected = []
    with tempfile.TemporaryDirectory(prefix='damage-', dir=work) as temp:
        for machine in SETS:
            changes = metas['candidate']['sets'][machine]['desert_pole_alias']['change']['changes']
            for i, change in enumerate(changes):
                root = Path(temp) / f'{machine}_{i}'
                meta = deepcopy(metas['candidate'])
                for m, fs in files['candidate'].items():
                    dest = root / m
                    dest.mkdir(parents=True)
                    for n, data in fs.items():
                        if m == machine and n == 'strex_p6.bin':
                            b = bytearray(data)
                            b[change['address'] - 1048576 ^ 1] ^= 1
                            (dest / n).write_bytes(b)
                            meta['sets'][m]['files'][n] = sha(b)
                        else:
                            (dest / n).symlink_to((a.build / m / n).resolve())
                (root / 'build.json').write_text(json.dumps(meta) + '\n')
                try:
                    M.audit(a.control, root)
                except ValueError:
                    rejected.append(dict(machine=machine, change=i, inventory_rehashed=True, rejected=True))
                else:
                    raise ValueError('rehashed collision damage accepted')
    report = dict(schema='striderex-pole-alias-gate/1', passed=True, geometry=geometry, checks=checks, inputs={label: {m: s['files'] for m, s in meta['sets'].items()} for label, meta in metas.items()}, runtime={k: rt[k] for k in ('binary_sha256', 'source_revision', 'board_wait')}, fresh_empty_output_files_and_metadata_exact=True, rehashed_damage_controls=rejected, source_sha256={str(q.relative_to(Path(__file__).parents[1])): sha(q.read_bytes()) for q in (Path(__file__), Path(M.__file__), Path(S.__file__), Path(D.__file__), Path(R.__file__), Path(SM.__file__), Path(G.__file__), G.LUA, G.DEBUG_START)}, hardware_review_granted=False)
    a.receipt.parent.mkdir(parents=True, exist_ok=True)
    a.receipt.write_text(json.dumps(report, indent=2) + '\n')
    if a.preview_out:
        a.preview_out.mkdir(parents=True, exist_ok=False)
        poster = Image.new('RGB', (768, 244))
        draw = ImageDraw.Draw(poster)
        sources = []
        for i, label in enumerate(('control', 'candidate')):
            source = captured[label, 'striderua', 'walk1'] / 's_02400.png'
            poster.paste(Image.open(source).convert('RGB'), (i * 384, 20))
            draw.text((i * 384 + 4, 4), 'Before' if i == 0 else 'After', fill='white')
            sources.append(dict(label=label, frame=2400, sha256=sha(source.read_bytes())))
        poster.save(a.preview_out / 'pole-contact.png')
        (a.preview_out / 'preview.json').write_text(json.dumps(dict(actual_emulator_pictures=True, sources=sources, sha256=sha((a.preview_out / 'pole-contact.png').read_bytes())), indent=2) + '\n')
    print('All 16 regional pole-contact/landing/stock comparisons PASS; full geometry and fresh output verified')
if __name__ == '__main__':
    main()
