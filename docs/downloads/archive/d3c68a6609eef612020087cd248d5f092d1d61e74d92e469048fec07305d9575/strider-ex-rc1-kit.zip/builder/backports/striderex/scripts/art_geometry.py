"""Build the native-pixel / Method E comparison from a verified producer."""
import argparse
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import struct
import subprocess
import sys
import numpy as np
import boss_scene_binary as B
from boss_voice_gate import inventory, sha
import cinematic_convert as C
import cinematic_lz as LZ
import cinematic_timing as T
import cps1_gfx as G
import portrait_gate as PG
from preview_boss_portrait_scale import source_picture
from reconstruct_private_build import decode_scene
from rescale_pilot import method_edge_pick

def swap(b):
    return bytes(np.frombuffer(b, np.uint8).reshape(-1, 2)[:, ::-1].ravel())

def still_codes(bank):
    """Guarded ss_rec instruction; preserve every EX still and band code."""
    prefix = bytes.fromhex('3f00e54841f9')
    hits = [i for i in range(0, len(bank) - 18, 2) if bank[i:i + 6] == prefix and bank[i + 10:i + 18] == bytes.fromhex('20700000301f4e75')]
    if len(hits) != 1:
        raise ValueError('stage-select snapshot table is not unique')
    table = B.long(bank, hits[0] + 6) - B.BASE
    count = (B.long(bank, table) - B.BASE - table) // 4
    if count != 7:
        raise ValueError('expected seven diagnostic stills')
    kept = {'s1': set(), 's2': set()}
    for k in range(count):
        pos = B.long(bank, table + 4 * k) - B.BASE + 38
        for _ in range(10000):
            addr = B.long(bank, pos)
            pos += 4
            if not addr:
                break
            n = B.word(bank, pos) + 1
            pos += 2
            for layer, base in (('s1', 9469952), ('s2', 9486336)):
                if base <= addr < base + 16384:
                    kept[layer].update((B.word(bank, pos + 2 * i) for i in range(0, n, 2) if B.word(bank, pos + 2 * i) >= 32768))
            pos += 2 * n
        else:
            raise ValueError('unbounded stage snapshot')
    return kept

def native_portraits(bank, gfx):
    result = bytearray(bank)
    seen = set()
    report = []
    for scene in B.scenes(bank):
        at = scene['at']
        x, y, attr, rest = struct.unpack_from('>4H', bank, at + 40)
        if attr >> 8 != 71:
            raise ValueError('unexpected portrait block dimensions')
        codes = {rest}
        pos = B.long(bank, at + 48) - B.BASE
        while B.word(bank, pos):
            codes.add(B.word(bank, pos + 2))
            pos += 4
        for code in codes - seen:
            im = source_picture(gfx, code)
            padded = np.full((80, 128), 15, np.int32)
            padded[:, :80] = np.where(im < 0, 15, im)
            for r in range(5):
                for c in range(8):
                    G.put_tile(gfx, G.ex_offset('obj', code + c + 16 * r), padded[16 * r:16 * r + 16, 16 * c:16 * c + 16])
        seen |= codes
        struct.pack_into('>H', result, at + 40, x + 20)
        report.append(dict(scene=scene['id'], x_before=x, x_after=x + 20, source_size=[80, 80], pictures=len(codes)))
    return (bytes(result), report)

class Palette:
    """Stable per-scene lists of source CPS palette-entry references."""

    def __init__(self, base):
        self.groups = [[base + 16 * q + p for p in range(15)] for q in range(16)]
        self.cache = {}

    def tile(self, refs):
        key = refs.tobytes()
        if key in self.cache:
            return self.cache[key]
        used = sorted((int(v) for v in np.unique(refs) if v >= 0))
        if len(used) > 15:
            raise ValueError(f'widened tile needs {len(used)} opaque pens')
        for q, group in enumerate(self.groups):
            if len(set(group) | set(used)) <= 15:
                group.extend((v for v in used if v not in group))
                break
        else:
            q = len(self.groups)
            if q >= 32:
                raise ValueError('widened layer needs more than 32 palette slots')
            self.groups.append(list(used))
            group = self.groups[-1]
        pens = np.full(refs.shape, 15, np.uint8)
        for pen, ref in enumerate(group):
            pens[refs == ref] = pen
        self.cache[key] = (pens, q)
        return (pens, q)

    def apply(self, old, new, base):
        for q, refs in enumerate(self.groups):
            new[base + 16 * q:base + 16 * q + len(refs)] = old[refs]

class Graphics:

    def __init__(self, original, kept):
        self.region = bytearray(original)
        self.books = {'s1': {}, 's2': {}, 'obj': {}}
        preserved = set(kept['s1'])
        solids = set()
        for code in range(32768, 49152):
            tile = G.get_tile(original, G.ex_offset('scr1', code), 8, 0)
            if np.all(tile == tile[0, 0]) and int(tile[0, 0]) not in solids:
                preserved.add(code)
                solids.add(int(tile[0, 0]))
        self.s1_free = iter((c for c in range(32768, 49152) if c not in preserved))
        reserved = set(range(33664, 33792)) | kept['s2']
        self.shared_free = set((c for c in range(32768, 45056) if c not in reserved))
        self.rectangles = {}
        self.high = {'s1': 0, 'shared': 0}

    def code(self, layer, pens):
        key = pens.astype(np.uint8).tobytes()
        book = self.books[layer]
        if key not in book:
            try:
                if layer == 's1':
                    code = next(self.s1_free)
                else:
                    code = min(self.shared_free)
                    self.shared_free.remove(code)
            except StopIteration:
                raise ValueError(f'{layer} cinematic graphics allocation exhausted') from None
            book[key] = code
            self.high['s1' if layer == 's1' else 'shared'] = max(code, self.high['s1' if layer == 's1' else 'shared'])
            gfx_layer = {'s1': 'scr1', 's2': 'scr2', 'obj': 'obj'}[layer]
            G.put_tile(self.region, G.ex_offset(gfx_layer, code), pens, 0 if layer == 's1' else None)
            if layer == 's1':
                G.put_tile(self.region, G.ex_offset('scr1', code), pens, 1)
        return book[key]

    def rectangle(self, pens):
        h, w = pens.shape
        nx, ny = (w // 16, h // 16)
        key = (h, w, pens.tobytes())
        if key in self.rectangles:
            return self.rectangles[key]
        for code in sorted(self.shared_free):
            if (code & 15) + nx > 16:
                continue
            codes = {code + c + 16 * r for r in range(ny) for c in range(nx)}
            if codes <= self.shared_free:
                break
        else:
            raise ValueError('cinematic rectangle allocation exhausted')
        self.shared_free -= codes
        for r in range(ny):
            for c in range(nx):
                G.put_tile(self.region, G.ex_offset('obj', code + c + 16 * r), pens[16 * r:16 * r + 16, 16 * c:16 * c + 16])
        self.rectangles[key] = code
        return code

class Wide:

    def __init__(self, graphics, canonical=None):
        self.gfx = graphics
        self.maps = {}
        self.windows = {}
        self.objects = {}
        self.object_images = {}
        self.pals = {'s1': Palette(C.PAL_S1), 's2': Palette(C.PAL_S2)}
        self.canonical = np.arange(3072) if canonical is None else canonical
        self.peak_sprites = 0
        self.origins = {}
        self.previous = {}

    def layer(self, model, layer):
        oldmap = (model.maps1 if layer == 's1' else model.maps2)[model.front[layer]][:64 if layer == 's1' else 32, :64 if layer == 's1' else 32]
        key = (layer, oldmap.tobytes())
        if key not in self.maps:
            n = 8 if layer == 's1' else 16
            yy, xx = np.indices((512, 512))
            idx, pens = model.layer(oldmap, xx, yy, n, 'scr1' if layer == 's1' else 'scr2', C.PAL_S1 if layer == 's1' else C.PAL_S2, layer == 's1')
            refs = np.where(pens == 15, -1, self.canonical[idx])
            self.maps[key] = method_edge_pick(refs)
        return (key, self.maps[key])

    def grid(self, model, layer, left):
        key, wide = self.layer(model, layer)
        origin = self.origins.get(layer)
        low, high, width, n = (0, 128, 512, 8) if layer == 's1' else (64, 512, 1024, 16)
        if origin is None or np.min(left) < origin + low or np.max(left) > origin + high:
            origin = int(np.floor((float(np.min(left)) + float(np.max(left)) - low - high) / (2 * n))) * n
            if np.max(left) - origin > high:
                origin = int(np.floor((float(np.min(left)) - low) / n)) * n
            self.origins[layer] = origin
        rel = np.asarray(left) - origin
        if rel.max() > high or rel.min() < low:
            raise ValueError(f'widened raster scroll exceeds the 512-pixel map window: {np.min(left)}..{np.max(left)}')
        cachekey = (key, origin % 768)
        if cachekey not in self.windows:
            refs = wide[:, (origin + np.arange(width)) % 768]
            gy, gx = (512 // n, width // n)
            tiles = refs.reshape(gy, n, gx, n).transpose(0, 2, 1, 3)
            self.windows[cachekey] = tiles
        return (self.windows[cachekey], rel)

    def visible(self, layer, tiles, left, yscroll):
        n = 8 if layer == 's1' else 16
        size = 512 if layer == 's1' else 1024
        cells = self.previous.get(layer, np.zeros((64, 64, 2), np.int32)).copy()
        ys = (np.arange(16, 240) + yscroll) % size // n
        xs = (np.asarray(left).reshape(-1, 1) + np.arange(384)) // n
        xs = np.broadcast_to(xs, (224, 384))
        seen = np.zeros((64, 64), bool)
        seen[ys[:, None], xs] = True
        for y, x in np.argwhere(seen):
            refs = tiles[y % tiles.shape[0], x]
            pens, q = self.pals[layer].tile(refs)
            cells[y, x] = (self.gfx.code(layer, pens), q)
        self.previous[layer] = cells
        return cells

    def sprites(self, model):
        out = []
        parts = []
        for x, y, code, attr in model.latched:
            begin = len(out)
            nx, ny = ((attr >> 8 & 15) + 1, (attr >> 12 & 15) + 1)
            key = (code, nx, ny)
            if key not in self.objects:
                old = np.block([[model.pens('obj', (code & ~15) + (code + c & 15) + 16 * r) for c in range(nx)] for r in range(ny)])
                wide = method_edge_pick(np.where(old == 15, -1, old))
                width = wide.shape[1]
                padded = np.full((16 * ny, -(-width // 16) * 16), 15, np.uint8)
                padded[:, :width] = np.where(wide < 0, 15, wide)
                rows = []
                for r in range(ny):
                    row = []
                    for c in range(padded.shape[1] // 16):
                        tile = padded[16 * r:16 * r + 16, 16 * c:16 * c + 16]
                        if (tile != 15).any():
                            row.append((c, self.gfx.code('obj', tile)))
                    rows.append(row)
                self.objects[key] = rows
                self.object_images[key] = padded
            sx = x - 128
            ox = 64 + sx * 3 // 2
            for r, row in enumerate(self.objects[key]):
                sy = y + 16 * r & 511
                if sy >= 240 or sy + 16 <= 16:
                    continue
                row = [(c, tc) for c, tc in row if ox + 16 * c < 448 and ox + 16 * (c + 1) > 64]
                i = 0
                while i < len(row):
                    c, tc = row[i]
                    count = 1
                    while i + count < len(row) and row[i + count] == (c + count, tc + count) and ((tc & 15) + count < 16):
                        count += 1
                    out.append((ox + 16 * c & 511, y + 16 * r & 511, tc, count - 1 << 8 | attr & 31))
                    i += count
            parts.append((begin, len(out), x, y, attr, key))
        limit = C.OBJ_ENTRIES - C.CAP_ALLOW
        if len(out) > limit:
            replacements = {}
            count = len(out)
            for begin, end, x, y, attr, key in sorted(parts, key=lambda p: p[1] - p[0], reverse=True):
                if end - begin < 3:
                    continue
                padded = self.object_images[key]
                ox = 64 + (x - 128) * 3 // 2
                cols = [c for c in range(padded.shape[1] // 16) if ox + 16 * c < 448 and ox + 16 * (c + 1) > 64]
                rows = [r for r in range(padded.shape[0] // 16) if 16 <= y + 16 * r & 511 < 240]
                packed = []
                if cols and rows:
                    for c in range(cols[0], cols[-1] + 1, 16):
                        c1 = min(c + 16, cols[-1] + 1)
                        r0, r1 = (rows[0], rows[-1] + 1)
                        block = padded[16 * r0:16 * r1, 16 * c:16 * c1]
                        tc = self.gfx.rectangle(block)
                        packed.append((ox + 16 * c & 511, y + 16 * r0 & 511, tc, r1 - r0 - 1 << 12 | c1 - c - 1 << 8 | attr & 31))
                replacements[begin] = (end, packed)
                count -= end - begin - len(packed)
                if count <= limit:
                    break
            merged = []
            i = 0
            while i < len(out):
                if i in replacements:
                    i, entries = replacements[i]
                    merged.extend(entries)
                else:
                    merged.append(out[i])
                    i += 1
            out = merged
        self.peak_sprites = max(self.peak_sprites, len(out))
        if len(out) > limit:
            raise ValueError(f'widened scene needs {len(out)} sprite entries (limit {limit} plus {C.CAP_ALLOW} caption entries)')
        return out

    def state(self, model):
        st = dict(bg_on=bool(model.ctrl & 6), s1=None, s2=None, cover=bool(model.prio), sprites=self.sprites(model))
        if model.ctrl & 2:
            left = (128 + model.s1[0]) % 512
            tiles, rel = self.grid(model, 's1', left * 3 // 2)
            cells = self.visible('s1', tiles, rel, model.s1[1])
            st['s1'] = dict(cells=cells, x=int(rel) - 64 & 511, y=model.s1[1])
        if model.ctrl & 4:
            raw = 64 + model.s2_x + model.rows[16:240] & 511
            raw = int(raw[0]) + (raw - int(raw[0]) + 256 & 511) - 256
            tiles, rel = self.grid(model, 's2', raw * 3 // 2)
            cells = self.visible('s2', tiles, rel, model.s2_y & 511)
            rows = np.full(256, int(rel[0]) - 64, np.int32)
            rows[16:240] = rel - 64
            rows[240:] = rows[239]
            st['s2'] = dict(cells=cells, y=model.s2_y & 511, rows=rows & 511)
        return st

    def reference(self, model):
        """Independent displayed-pixel oracle, without encoded destination tiles."""
        out = np.full((224, 384), C.BACKDROP, np.int32)
        blocked = np.zeros(out.shape, bool)
        by = np.arange(16, 240)[:, None]
        bx = np.arange(384)[None, :]
        order = [model.ctrl >> s & 3 for s in (6, 8, 10, 12)]
        for k, layer in enumerate(order):
            refs = None
            if layer == 1 and model.ctrl & 2:
                _, wide = self.layer(model, 's1')
                left = (128 + model.s1[0]) % 512 * 3 // 2
                refs = wide[(by + model.s1[1]) % 512, (left + bx) % 768]
            elif layer == 2 and model.ctrl & 4:
                _, wide = self.layer(model, 's2')
                raw = 64 + model.s2_x + model.rows[16:240] & 511
                raw = int(raw[0]) + (raw - int(raw[0]) + 256 & 511) - 256
                refs = wide[(by + model.s2_y) % 512, (raw[:, None] * 3 // 2 + bx) % 768]
            elif layer == 0:
                for x, y, code, attr in reversed(model.latched):
                    nx, ny = ((attr >> 8 & 15) + 1, (attr >> 12 & 15) + 1)
                    old = np.block([[model.pens('obj', (code & ~15) + (code + c & 15) + 16 * r) for c in range(nx)] for r in range(ny)])
                    wide = method_edge_pick(np.where(old == 15, -1, old))
                    left = (x - 128) * 3 // 2
                    for r in range(ny):
                        top = (y + 16 * r & 511) - 16
                        y0, y1 = (max(top, 0), min(top + 16, 224))
                        x0, x1 = (max(left, 0), min(left + wide.shape[1], 384))
                        if y0 >= y1 or x0 >= x1:
                            continue
                        part = wide[16 * r + y0 - top:16 * r + y1 - top, x0 - left:x1 - left]
                        keep = (part >= 0) & ~blocked[y0:y1, x0:x1]
                        out[y0:y1, x0:x1][keep] = (C.PAL_OBJ + 16 * (attr & 31) + part)[keep]
            if refs is not None:
                out = np.where(refs >= 0, refs, out)
                if k + 1 < 4 and order[k + 1] == 0:
                    blocked = refs >= 0 if model.prio else np.zeros(out.shape, bool)
        return model.pal[out]

def clear_continuation(model):
    for name, maps in (('s1', model.maps1), ('s2', model.maps2), ('pal', model.pals)):
        for k, value in enumerate(maps):
            if k != model.front[name]:
                value.fill(0)

def no_bars(stream):
    b = bytearray(stream)
    pos = 0
    while B.word(b, pos) != 65535:
        n = B.word(b, pos)
        for op, slot, q in T.ops(bytes(b[pos + 2:pos + 2 + n])):
            if op == 6:
                at = pos + 2 + q + 2
                struct.pack_into('>H', b, at, B.word(b, at) & ~8)
        pos += n + 2
    return bytes(b)

def convert(meta, files, out, only=None):
    bank = swap(files['strex_p6.bin'])
    source = C.CpsModel(PG.region_of(files))
    graphics = Graphics(source.region, still_codes(bank))
    allscenes = []
    fronts = {}
    for sc in meta['scenes']:
        if only and sc['id'] not in only:
            continue
        if not sc['continues']:
            source = C.CpsModel(source.region)
        else:
            clear_continuation(source)
        raw, records = decode_scene(bank[meta['sets']['striderua']['streams'][sc['id']] - B.BASE:])
        probe = deepcopy(source)
        probe_pos = 0
        timelines = []
        for k in range(len(records)):
            probe_pos = probe.run(raw, probe_pos)
            if k >= sc['preroll']:
                timelines.append(probe.pal.copy())
        timeline = np.asarray(timelines)
        canonical = np.arange(3072)
        for base in (C.PAL_S1, C.PAL_S2):
            identities = {}
            for q in range(16):
                for pen in range(15):
                    ref = base + 16 * q + pen
                    identities.setdefault(sha(timeline[:, ref].tobytes()), ref)
            for ref in range(base, base + 512):
                canonical[ref] = identities.get(sha(timeline[:, ref].tobytes()), ref)
        del timeline, timelines, probe
        converter = Wide(graphics, canonical)
        states, pals, expected = ([], [], [])
        resets = 0
        pos = 0
        for k in range(len(records)):
            pos = source.run(raw, pos)
            if k >= sc['preroll']:
                try:
                    st = converter.state(source)
                except ValueError as exc:
                    if '32 palette slots' not in str(exc):
                        raise
                    converter.pals = {'s1': Palette(C.PAL_S1), 's2': Palette(C.PAL_S2)}
                    resets += 1
                    st = converter.state(source)
                states.append(st)
                new = source.pal.copy()
                for layer, base in (('s1', C.PAL_S1), ('s2', C.PAL_S2)):
                    converter.pals[layer].apply(source.pal, new, base)
                pals.append(new)
                expected.append(sha(converter.reference(source).astype('>u2').tobytes()))
        cont = fronts.get(sc['continues']) if sc['continues'] else None
        stream, pre, _, final = C.encode_stream(states, pals, cont=cont)
        if pre > sc['preroll']:
            raise ValueError(f"{sc['id']}: conversion needs {pre} pre-roll records, original {sc['preroll']}")
        if pre < sc['preroll']:
            stream, pre, _, final = C.encode_stream(states, pals, cont=cont, pre_extra=sc['preroll'] - pre)
        stream = no_bars(stream)
        lz = LZ.encode(stream)
        if LZ.decode(lz, len(stream)) != stream:
            raise ValueError('compressed stream round trip failed')
        timing = T.report(T.predict(stream, lz, [(k, 0) for k in range(pre + len(states))], [('en', [0] * C.CAP_ALLOW)]))
        print(sc['id'], 'tiles', {k: len(v) for k, v in graphics.books.items()}, 'palettes', {k: len(v.groups) for k, v in converter.pals.items()}, 'palette resets', resets, 'peak sprites', converter.peak_sprites, 'timing', timing, flush=True)
        (out / (sc['id'] + '.bin')).write_bytes(stream)
        (out / (sc['id'] + '.lz')).write_bytes(lz)
        (out / (sc['id'] + '-pixels.json')).write_text(json.dumps(expected) + '\n')
        fronts[sc['id']] = final
        allscenes.append(dict(id=sc['id'], preroll=pre, stream_bytes=len(stream), stream_sha256=sha(stream), lz_bytes=len(lz), timing=timing, peak_sprites=converter.peak_sprites, fronts=final))
    (out / 'gfx.bin').write_bytes(graphics.region)
    target = None
    for sc in allscenes:
        source_sc = next((s for s in meta['scenes'] if s['id'] == sc['id']))
        if not source_sc['continues'] or target is None:
            target = C.CpsModel(graphics.region)
        else:
            clear_continuation(target)
        stream = (out / (sc['id'] + '.bin')).read_bytes()
        expected = json.loads((out / (sc['id'] + '-pixels.json')).read_text())
        pos = 0
        for k in range(sc['preroll'] + len(expected)):
            pos = target.run(stream, pos)
            if k >= sc['preroll']:
                pixels = target.pal[target.render()]
                if sha(pixels.astype('>u2').tobytes()) != expected[k - sc['preroll']]:
                    raise ValueError(f"{sc['id']}: encoded pixels differ at record {k}")
        sc['pixel_frames_checked'] = len(expected)
        print(sc['id'], 'all', len(expected), 'rendered pictures match', flush=True)
    (out / 'conversion.json').write_text(json.dumps(dict(scenes=allscenes, tiles={k: len(v) for k, v in graphics.books.items()}), indent=2) + '\n')

def install_helper(bank, vasm, work, machine):
    prefix = bytes.fromhex('3018')
    hits = [i for i in range(0, 6144, 2) if bank[i:i + 2] == prefix and bank[i + 2] == 103 and (bank[i + 4:i + 10] == bytes.fromhex('3200c07c00ff'))]
    if len(hits) != 1:
        raise ValueError('cinematic stream dispatch changed')
    at = hits[0]
    delta = int.from_bytes(bank[at + 3:at + 4], 'big', signed=True)
    done = B.BASE + at + 4 + delta
    src = Path(__file__).resolve().parents[1] / 'asm/geometry_stream.s'
    target = work / (machine + '-geometry.bin')
    subprocess.run([str(vasm), '-Fbin', '-m68000', '-quiet', '-DGEOMETRY_DONE=' + str(done), '-DGEOMETRY_LEGACY=' + str(B.BASE + at + 6), '-o', str(target), str(src)], check=True)
    helper = target.read_bytes()
    off = 1047296
    if len(helper) > 1024 or bank[off:off + len(helper)] != b'\xff' * len(helper):
        raise ValueError('wide-stream helper allocation is occupied')
    bank[at:at + 6] = bytes.fromhex('4ef9') + (B.BASE + off).to_bytes(4, 'big')
    bank[off:off + len(helper)] = helper
    return dict(entry=B.BASE + at, helper=B.BASE + off, bytes=len(helper), sha256=sha(helper))

def replace_streams(bank, meta, machine, conversion):
    spec = meta['sets'][machine]
    spans = []
    for scene in meta['scenes']:
        at = spec['streams'][scene['id']] - B.BASE
        raw, _ = decode_scene(bank[at:])
        comp = LZ.encode(raw)
        if bank[at:at + len(comp)] != comp:
            raise ValueError('source stream compression differs')
        end = at + len(comp) + 16 + 1 & ~1
        if any(bank[at + len(comp):end]):
            raise ValueError('source stream padding changed')
        spans.append((at, end))
    spans.sort()
    if any((a[1] != b[0] for a, b in zip(spans, spans[1:]))):
        raise ValueError('source stream allocation is not contiguous')
    start, end = (spans[0][0], spans[-1][1])
    bank[start:end] = b'\xff' * (end - start)
    free = [(start, end)]
    tail_start, tail_end = (784512, 1040384)
    if bank[tail_start:tail_end] != b'\xff' * (tail_end - tail_start):
        raise ValueError('cinematic overflow allocation changed')
    free.append((tail_start, tail_end))
    result = {}
    order = [s['id'] for s in meta['scenes']]
    table = int(spec['nopack_cues_at'], 16) - B.BASE - 8 * len(order)
    for index, sid in enumerate(order):
        comp = (conversion / (sid + '.lz')).read_bytes()
        size = len(comp) + 32 + 1 & ~1
        candidates = [(e - s, i) for i, (s, e) in enumerate(free) if e - s >= size]
        if not candidates:
            raise ValueError('widened streams exceed free program space')
        _, selected = min(candidates)
        at, stop = free[selected]
        bank[at:at + len(comp)] = comp
        bank[at + len(comp):at + size] = bytes(size - len(comp))
        free[selected] = (at + size, stop)
        old = B.long(bank, table + 8 * index)
        if old != spec['streams'][sid]:
            raise ValueError('scene directory changed')
        struct.pack_into('>I', bank, table + 8 * index, B.BASE + at)
        result[sid] = B.BASE + at
    return result

def build(a):
    meta, files = inventory(a.build)
    a.out.mkdir(parents=True, exist_ok=False)
    result = deepcopy(meta)
    report = dict(schema='striderex-art-geometry/1', scale=a.scale, passed=False, source_files={m: s['files'] for m, s in meta['sets'].items()}, regions={})
    if a.scale == 'method-e':
        if not a.vasm:
            raise ValueError('Method E requires the pinned assembler')
        work = a.out / 'conversion'
        work.mkdir()
        convert(meta, files['striderua'], work)
        converted = json.loads((work / 'conversion.json').read_text())
        if any((s['timing']['over_limit'] for s in converted['scenes'])):
            raise ValueError('widened scenes exceed the qualified handler limit')
    for machine, members in files.items():
        members = dict(members)
        bank = swap(members['strex_p6.bin'])
        if a.scale == 'native':
            gfx = bytearray(PG.region_of(members))
            bank, details = native_portraits(bank, gfx)
            report['regions'][machine] = dict(portraits=details, cinematics_exact=True)
        else:
            bank = bytearray(bank)
            gfx = bytearray((work / 'gfx.bin').read_bytes())
            result['sets'][machine]['streams'] = replace_streams(bank, meta, machine, work)
            helper = install_helper(bank, a.vasm, work, machine)
            for scene in result['scenes']:
                new = next((s for s in converted['scenes'] if s['id'] == scene['id']))
                for key in ('stream_bytes', 'stream_sha256', 'preroll'):
                    scene[key] = new[key]
            report['regions'][machine] = dict(helper=helper, portraits_exact=True)
        members['strex_p6.bin'] = swap(bank)
        members.update(zip(('strex_gfx.c25', 'strex_gfx.c27', 'strex_gfx.c29', 'strex_gfx.c31'), G.split_region(gfx)))
        target = a.out / machine
        target.mkdir()
        for name, data in members.items():
            (target / name).write_bytes(data)
        result['sets'][machine]['files'] = {n: sha(b) for n, b in members.items()}
        result['sets'][machine]['art_geometry'] = dict(scale=a.scale, source_files=meta['sets'][machine]['files'])
    report['build_files'] = {m: s['files'] for m, s in result['sets'].items()}
    report['passed'] = True
    (a.out / 'build.json').write_text(json.dumps(result, indent=2) + '\n')
    (a.out / 'geometry.json').write_text(json.dumps(report, indent=2) + '\n')

def main():
    if sys.argv[1:] == ['--self-test']:
        return self_test()
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--build', type=Path, required=True)
    p.add_argument('--out', type=Path, required=True)
    p.add_argument('--only')
    p.add_argument('--measure', action='store_true')
    p.add_argument('--scale', choices=('native', 'method-e'), default='method-e')
    p.add_argument('--vasm', type=Path)
    a = p.parse_args()
    if a.measure:
        meta, files = inventory(a.build)
        a.out.mkdir(parents=True, exist_ok=False)
        convert(meta, files['striderua'], a.out, a.only.split(',') if a.only else None)
    else:
        build(a)

def self_test():
    region = bytearray(4 * G.MB)
    tile = np.indices((8, 8)).sum(0) % 3
    for half in (0, 1):
        G.put_tile(region, G.ex_offset('scr1', 32769), tile, half)
    original = C.CpsModel(region)
    original.maps1[0][:] = (32769, 0)
    original.s1 = (65408, 0)
    original.ctrl = C.LAYERS_S1 | 10
    original.pal[:] = np.arange(3072) % 4096 | 61440
    graphics = Graphics(region, {'s1': set(), 's2': set()})
    wide = Wide(graphics)
    states, expected, oldpals = ([], [], [])
    for x in (65408, 65409, 65410, 65416):
        original.s1 = (x, 0)
        states.append(wide.state(original))
        expected.append(wide.reference(original))
        oldpals.append(original.pal.copy())
    pals = []
    for old in oldpals:
        new = old.copy()
        wide.pals['s1'].apply(old, new, C.PAL_S1)
        pals.append(new)
    stream, pre, _, _ = C.encode_stream(states, pals)
    stream = no_bars(stream)
    model = C.CpsModel(graphics.region)
    pos = 0
    for k in range(pre + len(states)):
        pos = model.run(stream, pos)
        if k >= pre:
            assert np.array_equal(model.pal[model.render()], expected[k - pre])
    cells = np.zeros((64, 64, 2), np.int32)
    cells[16, 35] = (32769, 3)
    body = C.emit('s2', 0, [(16, 35)], cells) + C.w16(0)
    assert T.ops(body)[0][0] == 15
    model = C.CpsModel(region)
    model.run(C.w16(len(body)) + body + C.w16(65535), 0)
    assert np.array_equal(model.maps2[0][16, 35], [32769, 3])
    assert np.count_nonzero(model.maps2[0]) == 2
    cells[17:21, 35] = (32769, 3)
    body = C.emit('s2', 0, [(r, 35) for r in range(16, 21)], cells) + C.w16(0)
    assert T.ops(body)[0][0] == 16
    model.run(C.w16(len(body)) + body + C.w16(65535), 0)
    assert np.count_nonzero(model.maps2[0]) == 10
    rows = np.resize(np.array([96, 352, 448], np.int32), 256)
    state = dict(bg_on=True, cover=False, sprites=[], s1=None, s2=dict(cells=np.full((64, 64, 2), (32769, 0), np.int32), y=0, rows=rows))
    stream, _, _, _ = C.encode_stream([state], [np.zeros(3072, np.int32)])
    found = False
    for _, body in T.records(stream):
        for op, _, q in T.ops(body):
            if op == 4:
                count, x0 = struct.unpack_from('>2H', body, q + 2)
                actual = []
                for k in range(count):
                    n, dx = struct.unpack_from('>2H', body, q + 6 + 4 * k)
                    actual.extend([x0 + dx] * n)
                assert np.array_equal(actual, rows), 'full-width rows must not wrap at 512 pixels'
                found = True
    assert found
    print('Art geometry self-test PASS: exact scrolling pixels, stream round trip, full-map writes without aliases')
if __name__ == '__main__':
    main()
