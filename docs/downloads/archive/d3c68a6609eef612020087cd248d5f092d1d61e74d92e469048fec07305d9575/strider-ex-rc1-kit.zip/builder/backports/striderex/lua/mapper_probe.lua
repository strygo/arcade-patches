-- Strider EX mapper probe (P0.6), run by scripts/strider_mapper_probe.py.
--
-- Starts a game through arcade_debug_start.lua (stage 0, area 0), turns on
-- the Freeze DIP (DSWC bit 2: the game spins at 0x6F0, so nothing it does
-- can touch video RAM), then from STREX_FILL_FRAME on rewrites one layer
-- every frame and takes a snapshot at STREX_SNAP_FRAME.
--
-- STREX_FILL = "none" | "scroll1" | "scroll2" | "scroll3" | "sprites"
-- STREX_FILL_BASE  first tile code; cell i gets BASE + (i % STREX_FILL_SPAN)
-- STREX_FILL_SPAN  number of consecutive codes used
-- Map bases are the CPS-A registers Strider sets at 0x73A8C: SCROLL1
-- 0x908000, SCROLL2 0x90C000, SCROLL3 0x910000, sprites 0x900000/0x904000.
local m=manager.machine
local sp=m.devices[':maincpu'].spaces['program']
local screen=m.screens[':screen']
local fill=os.getenv('STREX_FILL') or 'none'
local base=tonumber(os.getenv('STREX_FILL_BASE') or '0')
local span=tonumber(os.getenv('STREX_FILL_SPAN') or '1')
local freeze_frame=tonumber(os.getenv('STREX_FREEZE_FRAME') or '1100')
local fill_frame=tonumber(os.getenv('STREX_FILL_FRAME') or '1110')
local snap_frame=tonumber(os.getenv('STREX_SNAP_FRAME') or '1116')
local snap=assert(os.getenv('STREX_SNAP'))
local freeze
for _,field in pairs(m.ioport.ports[':DSWC'].fields) do if field.mask==0x04 then freeze=field end end
assert(freeze,'Freeze DIP not found')

local maps={scroll1=0x908000,scroll2=0x90c000,scroll3=0x910000}
local function do_fill()
 if maps[fill] then
  local a0=maps[fill]
  for i=0,0x0fff do                       -- 4096 entries: code word, attribute word
   sp:write_u16(a0+4*i,base+(i%span))
   sp:write_u16(a0+4*i+2,0x0000)
  end
 elseif fill=='sprites' then
  for _,a0 in ipairs({0x900000,0x904000}) do
   local n=0
   for row=0,6 do for col=0,11 do
    local a=a0+8*n
    sp:write_u16(a,64+col*28)              -- x
    sp:write_u16(a+2,16+row*28)            -- y
    sp:write_u16(a+4,base+(n%span))        -- code
    sp:write_u16(a+6,0x0000)               -- attribute: palette 0, 1x1
    n=n+1
   end end
   sp:write_u16(a0+8*n+6,0xff00)           -- end of list
  end
 end
end

local f=0
emu.register_frame_done(function()
 f=f+1
 if f==freeze_frame then freeze.user_value=0 end    -- active low: on
 if f>=fill_frame and fill~='none' then do_fill() end
 if f==snap_frame then screen:snapshot(snap); m:exit() end
end)

dofile(assert(os.getenv('STREX_DEBUG_START')))
