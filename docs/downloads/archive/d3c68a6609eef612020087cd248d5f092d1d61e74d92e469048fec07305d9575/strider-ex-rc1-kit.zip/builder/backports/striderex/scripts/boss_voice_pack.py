"""The boss scenes' voice lines in the Strider EX CPS+ pack (boss_scenes.json voice_cues, Japanese 0xB8-0xBF)."""
import argparse
import hashlib
import json
import math
import sys
import wave
from pathlib import Path
import numpy as np
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
ROOT = HERE.parents[2]
sys.path.insert(0, str(ROOT))
M = ROOT / 'backports/striderex/manifests'
CUES = M / 'ex_pack_cues.json'
MEASURED = M / 'portraits_measured.json'
SCENES = M / 'boss_scenes.json'
DUB_BEDS = M / 'dub_beds.json'
AUDIO = ROOT / 'cpsplus/manifests/strider_ex_audio.json'
PACK_RATE = 48000
PCE_FPS = 59.82
CPS1_HZ = 59.637
FADE_FRAME, VOICE_FRAME, AFTER_DELAY = (2, 72, 5)
MOUTH_MARGIN = 19
STOP_MARGIN = 2
PEAK_LIMIT_DB = -1.0
CUT_QUIET_DB = -40.0
MEAS_RATE = 44100

def load(p):
    return json.loads(Path(p).read_text(encoding='utf-8'))

def measured():
    return {p['id']: p for p in load(MEASURED)['portraits']}

def cue_rows():
    """[(id, cue)] of ex_pack_cues.json boss_voices, in order."""
    return [(r['id'], int(r['cue'], 16)) for r in load(CUES)['boss_voices']['rows']]

def played_samples(play, rate, n):
    """Samples of an n-sample clip the PC Engine played: up to its playback's stop frame (+1 frame of margin)."""
    if play.get('stop') is None:
        return n
    return min(n, int((play['stop'] - play['frame'] + 1) / PCE_FPS * rate))

def rms_db(x):
    return float(10 * np.log10(np.mean(np.asarray(x, np.float64) ** 2) + 1e-20))

def clip_source(capture, pid):
    """The clip as played: (float samples in [-1, 1) at its rate, rate, info)."""
    import portrait_transcripts as PT
    p = measured()[pid]
    v = p['voice'][0]
    k, play, pcm, rate = PT.clip_of(capture, pid, v['adpcm_sha256'])
    if rate != v['rate_hz']:
        raise SystemExit(f"boss_voice_pack: {pid}: playback rate {rate} Hz, measured {v['rate_hz']}")
    x = pcm.astype(np.float64) * 16 / 32768
    n = played_samples(play, rate, len(x))
    if n < len(x):
        tail = rms_db(x[max(0, n - rate // 20):n])
        if tail > CUT_QUIET_DB:
            raise SystemExit(f'boss_voice_pack: {pid}: the playback stop cuts sound ({tail:.1f} dBFS before it)')
    return (x[:n], rate, dict(playback=k, rate_hz=rate, adpcm_samples=len(x), played_samples=n))

def upsample(x, rate):
    from math import gcd
    from scipy import signal
    g = gcd(PACK_RATE, rate)
    return signal.resample_poly(x, PACK_RATE // g, rate // g, window=('kaiser', 8.6))

def voice_pcm(x, rate, gain_db):
    """The pack row's PCM: gain, 48 kHz, both channels, padded to 32 samples, 16-bit little-endian."""
    y = upsample(x * 10 ** (gain_db / 20), rate)
    peak = 20 * math.log10(max(np.max(np.abs(y)), 1e-12))
    if peak >= PEAK_LIMIT_DB:
        raise ValueError(f'gain {gain_db} dB peaks at {peak:.2f} dBFS (limit {PEAK_LIMIT_DB})')
    y = np.pad(np.stack([y, y], 1), ((0, -len(y) % 32), (0, 0)))
    return np.rint(y * 32768).clip(-32768, 32767).astype('<i2').tobytes()

def row_pcm(capture, row):
    """build_strider_ex.py's entry: the boss voice row's PCM (strider_ex_audio.json boss_voices row)."""
    x, rate, _ = clip_source(capture, row['id'])
    return voice_pcm(x, rate, float(row['gain_db']))

def lufs(x, rate):
    """BS.1770 gated loudness (dub_beds.loudness) of x: mono (n,) is measured on both channels, (n, 2) as is."""
    import dub_beds as DB
    from math import gcd
    from scipy import signal
    x = np.asarray(x, np.float64)
    if x.ndim == 1:
        x = np.stack([x, x], 1)
    if rate != MEAS_RATE:
        g = gcd(MEAS_RATE, rate)
        x = signal.resample_poly(x, MEAS_RATE // g, rate // g, axis=0, window=('kaiser', 8.6))
    return DB.loudness(x.T)

def cinematic_reference():
    """(median ja_voice_lufs, median ja_mix_lufs, lines) of the committed cinematic line references."""
    lines = load(DUB_BEDS)['reference']['lines']
    v = [r['ja_voice_lufs'] for r in lines.values() if r.get('ja_voice_lufs') is not None]
    m = [r['ja_mix_lufs'] for r in lines.values() if r.get('ja_mix_lufs') is not None]
    return (float(np.median(v)), float(np.median(m)), lines)

def pack_stereo(rd, i):
    from cpsplus.pack import audition
    t = rd.tracks[i]
    x = np.frombuffer(audition._decode_track(rd, i), '<i2').reshape(-1, t.channels).astype(np.float64) / 32768
    return (x, t)

def measure_pack(pack):
    """Loudness in the built pack: the stage music (every looped PLAY row's track, its first 60 s), the Japanese"""
    from cpsplus.pack.format import PackReader, VERB_PLAY
    rd = PackReader(pack)
    cues = load(CUES)
    out = dict(music={}, cinematic_lines={}, boss={})
    seen = set()
    for cue, r in enumerate(rd.triggers):
        if r.verb != VERB_PLAY or not rd.tracks[r.track].loop_end_byte or r.track in seen:
            continue
        seen.add(r.track)
        x, t = pack_stereo(rd, r.track)
        out['music'][f'0x{cue:02x}'] = dict(track=t.name, lufs=lufs(x[:60 * t.sample_rate], t.sample_rate))
    _, _, lines = cinematic_reference()
    names = {t.name: i for i, t in enumerate(rd.tracks)}
    audio = load(AUDIO)
    for c in cues['cinematics']['rows']:
        title = next((a['title'] for a in audio['cinematics'] if a['id'] == c['id']), None)
        if title not in names or 'window_s' not in c:
            continue
        x, t = pack_stereo(rd, names[title])
        w0 = c['window_s'][0]
        for lid, ref in lines.items():
            if not lid.startswith(f"tr{c['pce_track']}."):
                continue
            a, b = (round((ref['voice_start'] - w0) * t.sample_rate), round((ref['voice_end'] - w0) * t.sample_rate))
            out['cinematic_lines'][lid] = dict(pack_lufs=lufs(x[a:b], t.sample_rate), ja_mix_lufs=ref['ja_mix_lufs'], ja_voice_lufs=ref['ja_voice_lufs'])
    for row in audio.get('boss_voices', []):
        if row['title'] in names:
            x, t = pack_stereo(rd, names[row['title']])
            out['boss'][row['id']] = dict(lufs=lufs(x, t.sample_rate), peak_dbfs=round(20 * math.log10(np.max(np.abs(x)) + 1e-12), 2))
    return out

def cmd_measure(a):
    target, mix_med, lines = cinematic_reference()
    print(f'cinematic Japanese voices (dub_beds.json reference, {len(lines)} lines): voice stem median {target:.2f} LUFS, mix over the lines median {mix_med:.2f} LUFS')
    audio = load(AUDIO)
    rows = {r['id']: r for r in audio.get('boss_voices', [])}
    report = []
    for pid, _ in cue_rows():
        x, rate, info = clip_source(a.capture, pid)
        lk = lufs(x, rate)
        gain = round(target - lk, 1)
        y = upsample(x, rate)
        pk0 = 20 * math.log10(np.max(np.abs(y)))
        report.append(dict(id=pid, seconds=round(len(x) / rate, 3), lufs=lk, peak_dbfs=round(pk0, 2), gain_db=gain, peak_after_dbfs=round(pk0 + gain, 2), **info))
        print(f"{pid:17s} {len(x) / rate:5.2f} s ({info['played_samples']}/{info['adpcm_samples']} samples played)  {lk:6.2f} LUFS  peak {pk0:6.2f} dBFS  gain {gain:+5.1f} dB -> peak {pk0 + gain:6.2f} dBFS")
        if pk0 + gain >= PEAK_LIMIT_DB:
            raise SystemExit(f'{pid}: the gain would peak at {pk0 + gain:.2f} dBFS')
        if a.write:
            r = rows[pid]
            if r.get('gain_db') != gain:
                r['gain_db'], r['pcm_sha256'] = (gain, None)
    if a.pack:
        mp = measure_pack(a.pack)
        mus = [v['lufs'] for v in mp['music'].values()]
        print(f'pack {a.pack}: stage music ({len(mus)} looped tracks, first 60 s) median {np.median(mus):.2f} LUFS, range {min(mus):.2f} .. {max(mus):.2f}')
        for cue in ('0x02', '0x04'):
            if cue in mp['music']:
                print(f"  {cue} {mp['music'][cue]['track']}: {mp['music'][cue]['lufs']:.2f} LUFS")
        cl = mp['cinematic_lines']
        if cl:
            d = [v['pack_lufs'] - v['ja_mix_lufs'] for v in cl.values() if v['pack_lufs'] is not None]
            print(f"  cinematic rows over the {len(cl)} reference lines: median {np.median([v['pack_lufs'] for v in cl.values()]):.2f} LUFS (pack minus the disc reference mix: median {np.median(d):+.2f} dB)")
        for pid, v in mp['boss'].items():
            print(f"  boss {pid:17s} {v['lufs']:6.2f} LUFS, peak {v['peak_dbfs']:6.2f} dBFS")
    if a.write:
        AUDIO.write_text(json.dumps(audio, indent=1, ensure_ascii=False) + '\n', encoding='utf-8')
        print(f'wrote gain_db to {AUDIO.relative_to(ROOT)}')
    return 0

def model(pack):
    import pack_model as PM
    return PM.Model(pack)

def static_check(P):
    """Every boss voice cue a PLAY of its own one-shot, suppressed track (named as strider_ex_audio.json says,"""
    from cpsplus.pack.format import VERB_NONE, VERB_PLAY
    bad = []
    titles = {r['id']: r['title'] for r in load(AUDIO).get('boss_voices', [])}
    seen = set()
    for pid, cue in cue_rows():
        verb, track, ctrl = P.classify(cue)
        r = P.triggers[cue]
        if ctrl or verb != VERB_PLAY or (not r.suppress):
            bad.append(f'{pid} {cue:#04x}: control {ctrl}, verb {verb}, suppress {r.suppress}')
            continue
        t = P.tracks[track]
        if t.loop_end_byte:
            bad.append(f'{pid} {cue:#04x}: track {track} loops')
        if t.name and t.name != titles.get(pid):
            bad.append(f'{pid} {cue:#04x}: track {track} is {t.name!r}, not {titles.get(pid)!r}')
        if track in seen:
            bad.append(f'{pid} {cue:#04x}: track {track} shared')
        seen.add(track)
    for r in load(SCENES)['voice_cues']['rows']:
        v = int(r['en'], 16)
        if P.triggers[v].verb != VERB_NONE:
            bad.append(f"English dub cue {r['en']} ({r['id']}) has a row")
    return bad

def scene_writes(cue, base, n=None, before=2, after=None):
    """The latch writes of one scene (frames from base = scene frame 0): the stage music long before, the fade on"""
    w = [(base - 120, before), (base - 119, 255), (base + FADE_FRAME, 252), (base + FADE_FRAME + 1, 255), (base + VOICE_FRAME, cue), (base + VOICE_FRAME + 1, 255)]
    if n is not None and after is not None:
        w += [(base + n + AFTER_DELAY, after), (base + n + AFTER_DELAY + 1, 255)]
    return w

def scene_check(P, cue, mouth_frames, n=None, before=2, after=None, base=200):
    """One scene in the pack model (module docstring). -> dict(ok, problems, L, ...)."""
    probs = []
    ev, segs = P.run(scene_writes(cue, base, n, before, after))
    eff = {(f - base, v): e for f, v, _, _, e in ev}
    if eff.get((FADE_FRAME, 252)) != 'fade':
        probs.append(f'0xFC on frame {FADE_FRAME}: {eff.get((FADE_FRAME, 252))}')
    if eff.get((VOICE_FRAME, cue)) != 'start':
        probs.append(f'{cue:#04x} on frame {VOICE_FRAME}: {eff.get((VOICE_FRAME, cue))}')
    track, start = P.state(segs, base + VOICE_FRAME)
    x, m = P.pcm(track) if track is not None else (np.zeros(0), None)
    if m is None or m.loop_end_byte:
        probs.append('no one-shot voice track at frame 72')
        return dict(ok=False, problems=probs)
    fade_end = base + FADE_FRAME + P.fade_frames(0) - 1
    pre_peak, pre_s = P.level(segs, fade_end, base + VOICE_FRAME)
    if pre_s or pre_peak > -math.inf or P.state(segs, base + VOICE_FRAME - 1)[0] is not None:
        probs.append(f'the music is not silent and stopped before the voice ({pre_peak:.1f} dBFS, {pre_s} s)')
    secs = len(x) / m.sample_rate
    L = secs * CPS1_HZ
    Lf = math.ceil(L)
    peak, sounding = P.level(segs, base + VOICE_FRAME, base + VOICE_FRAME + Lf)
    if abs(sounding - secs) > 1 / CPS1_HZ or peak <= -55:
        probs.append(f'the voice sounds {sounding} s of {secs:.3f} s (peak {peak:.1f} dBFS)')
    if L > mouth_frames + MOUTH_MARGIN:
        probs.append(f'L {L:.1f} frames > mouth {mouth_frames} + {MOUTH_MARGIN}')
    stop = VOICE_FRAME + Lf + STOP_MARGIN
    quiet_to = stop + 60 if n is None or after is None else max(stop, n + AFTER_DELAY)
    post_peak, post_s = P.level(segs, base + stop - 1, base + quiet_to)
    if post_s or post_peak > -55:
        probs.append(f'still sounding at frame {stop - 1} ({post_s} s, {post_peak:.1f} dBFS)')
    res = dict(L=round(L, 1), limit=mouth_frames + MOUTH_MARGIN, end_frame=VOICE_FRAME + Lf, stopped_by=stop, peak_dbfs=round(peak, 1))
    if n is not None:
        res['N'] = n
        if stop > n:
            probs.append(f'the voice ends at frame {stop}, after the scene end N = {n}')
        if after is not None and eff.get((n + AFTER_DELAY, after)) != 'start':
            probs.append(f'the music cue {after:#04x} at frame {n + AFTER_DELAY}: {eff.get((n + AFTER_DELAY, after))}')
    return dict(res, ok=not probs, problems=probs)

def parse_scenes(path):
    out = {}
    if path is None:
        return out
    for k, v in load(path).items():
        if isinstance(v, dict):
            out[k] = (int(v['N']), int(v['after'], 16) if isinstance(v.get('after'), str) else v.get('after'))
        else:
            out[k] = (int(v), None)
    return out

def check(pack, scenes=None):
    P = model(pack)
    bad = static_check(P)
    for b in bad:
        print('FAIL', b)
    meas = measured()
    sc = parse_scenes(scenes)
    for pid, cue in cue_rows():
        n, after = sc.get(pid, (None, None))
        r = scene_check(P, cue, meas[pid]['frames'], n=n, after=after)
        name = P.tracks[P.triggers[cue].track].name
        print(f"{pid:17s} {cue:#04x} PLAY {name!r}: L {r.get('L')} frames (limit {r.get('limit')}), ends frame {r.get('end_frame')}, stopped by {r.get('stopped_by')}" + (f", N {r['N']}" if 'N' in r else '') + f", peak {r.get('peak_dbfs')} dBFS: " + ('OK' if r['ok'] else 'FAIL ' + '; '.join(r['problems'])))
        bad += [] if r['ok'] else [pid]
    print('boss voice check', 'FAILED' if bad else 'passed')
    return 1 if bad else 0

def render(pack, pid, out, n, before, after, lead_s=2.0, tail_s=3.0):
    """The model's output for one scene: `before` from frame 0, the scene from lead_s, `after` at N + 5."""
    P = model(pack)
    cue = dict(cue_rows())[pid]
    base = round(lead_s * CPS1_HZ)
    writes = [(0, before), (1, 255)] + scene_writes(cue, base, n, before, after)[2:]
    _, segs = P.run(writes)
    end = base + n + AFTER_DELAY + round(tail_s * CPS1_HZ)
    bounds = {0, end} | {f for f, _, _, _ in segs if 0 < f < end}
    for _, _, _, fade in segs:
        if fade is not None:
            bounds |= {g for g in range(fade.f0, fade.end + 1) if 0 < g < end}
    bounds = sorted(bounds)
    y = np.zeros(round(end / CPS1_HZ * PACK_RATE) + 64)
    for a, b in zip(bounds, bounds[1:]):
        track, start, fade = P.state_fade(segs, a)
        if track is None:
            continue
        s = P.samples(track, start, a, b) * P.gain(fade, a)
        if P.tracks[track].sample_rate != PACK_RATE:
            raise SystemExit('render: a track not at the pack rate')
        i = round(a / CPS1_HZ * PACK_RATE)
        y[i:i + len(s)] = s[:len(y) - i]
    y = y[:round(end / CPS1_HZ * PACK_RATE)]
    out = Path(out)
    out.parent.mkdir(parents=True, exist_ok=True)
    with wave.open(str(out), 'wb') as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(PACK_RATE)
        w.writeframes(np.rint(np.clip(y, -1, 32767 / 32768) * 32768).astype('<i2').tobytes())
    print(f'{out}: {len(y) / PACK_RATE:.2f} s, {before:#04x} at 0, 0xFC at {(base + FADE_FRAME) / CPS1_HZ:.3f} s, {cue:#04x} at {(base + VOICE_FRAME) / CPS1_HZ:.3f} s, {after:#04x} at {(base + n + AFTER_DELAY) / CPS1_HZ:.3f} s; sha256 {hashlib.sha256(out.read_bytes()).hexdigest()}')
    return 0

def self_test():
    import dataclasses
    import pack_model as PM
    from cpsplus.pack.format import TriggerRow, TrackMeta, VERB_PLAY
    from cpsplus.pack.protocols import PROTOCOLS
    assert played_samples(dict(frame=100, stop=402), 8000, 49120) == int(303 / PCE_FPS * 8000) == 40521
    assert played_samples(dict(frame=100, stop=447), 8000, 46344) == 46344
    assert played_samples(dict(frame=100), 8000, 10) == 10
    t = np.arange(8000) / 8000
    x = 0.25 * np.sin(2 * np.pi * 440 * t)
    raw = voice_pcm(x, 8000, 6.0)
    y = np.frombuffer(raw, '<i2').reshape(-1, 2)
    assert len(y) == 48000 and (y[:, 0] == y[:, 1]).all()
    assert abs(20 * math.log10(np.abs(y[1000:-1000, 0]).max() / 32768) - (20 * math.log10(0.25) + 6)) < 0.05
    assert len(np.frombuffer(voice_pcm(x[:1001], 8000, 0), '<i2')) // 2 % 32 == 0
    try:
        voice_pcm(x, 8000, 12.0)
        raise AssertionError('a peak above -1 dBFS must be refused')
    except ValueError:
        pass
    tone = 0.1 * np.sin(2 * np.pi * 1000 * np.arange(3 * 8000) / 8000)
    assert abs(lufs(tone, 8000) + 20) < 0.2, lufs(tone, 8000)
    proto = dataclasses.replace(PROTOCOLS['strider'], fade_law=1, fade_const1=23, fade_const2=0, control_verbs={240: PM.VERB_STOP, 241: PM.VERB_STOP, 252: PM.VERB_FADE_OUT})
    rows = [TriggerRow() for _ in range(256)]
    rows[2] = TriggerRow(verb=VERB_PLAY, track=0, suppress=1)
    rows[4] = TriggerRow(verb=VERB_PLAY, track=2, suppress=1)
    rows[184] = TriggerRow(verb=VERB_PLAY, track=1, suppress=1)
    P = PM.Model(None, rows, proto, tracks=[None, None, None])
    loop = TrackMeta(sample_rate=PACK_RATE, channels=2, loop_start_byte=18, loop_end_byte=36 * 1000)
    one = TrackMeta(sample_rate=PACK_RATE, channels=2)
    voice_s = 5.0
    P.tracks = [loop, one, loop]
    P._pcm = {0: (0.1 * np.ones(PACK_RATE * 10), loop), 2: (0.1 * np.ones(PACK_RATE * 10), loop), 1: (0.3 * np.ones(round(PACK_RATE * voice_s)), one)}
    L = voice_s * CPS1_HZ
    r = scene_check(P, 184, mouth_frames=300, n=VOICE_FRAME + math.ceil(L) + STOP_MARGIN, after=4)
    assert r['ok'], r
    assert scene_check(P, 184, mouth_frames=270)['problems'][0].startswith('L '), 'the mouth limit'
    late = scene_check(P, 184, mouth_frames=300, n=300, after=4)
    assert not late['ok'] and any(('after the scene end' in p for p in late['problems'])), late
    assert any((p.startswith('the voice sounds') for p in late['problems'])), "the game's cue cuts the voice"
    assert not scene_check(P, 4, mouth_frames=300)['ok'], 'a looped track is no voice'
    import ex_pack_plan as EP
    ids = [p['id'] for p in load(M / 'portraits.json')['pce']]
    assert [c for _, c in cue_rows()] == list(range(184, 192)) and [i for i, _ in cue_rows()] == ids, cue_rows()
    vc = {r['id']: int(r['ja'], 16) for r in load(SCENES)['voice_cues']['rows']}
    assert all((vc[i] == c for i, c in cue_rows())), 'ex_pack_cues.json boss_voices != boss_scenes.json voice_cues ja'
    rows_, errors = EP.plan()
    assert not errors, errors
    bv = [r for r in rows_ if r['kind'] == 'boss_voice']
    assert [int(r['cue'], 16) for r in bv] == list(range(184, 192)) and all((r['verb'] == 'one_shot' and r['suppress'] for r in bv)), bv
    audio = load(AUDIO).get('boss_voices', [])
    assert [(r['id'], int(r['command'], 16)) for r in audio] == cue_rows(), 'strider_ex_audio.json boss_voices'
    assert all((isinstance(r.get('gain_db'), (int, float)) for r in audio)), 'a boss voice row without gain_db'
    print('boss_voice_pack self-test passed')
    return 0

def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('--self-test', action='store_true')
    sub = p.add_subparsers(dest='cmd')
    m = sub.add_parser('measure')
    m.add_argument('--capture', type=Path, required=True, help='a portrait_pce.py capture (<id>/ram_writes.txt)')
    m.add_argument('--pack', type=Path, help='also measure the stage music and cinematic rows in this pack')
    m.add_argument('--write', action='store_true', help="write each clip's gain_db into strider_ex_audio.json")
    c = sub.add_parser('check')
    c.add_argument('--pack', type=Path, required=True)
    c.add_argument('--scenes', type=Path, help='JSON {id: N} or {id: {"N": n, "after": "0x04"}}: scene end frames')
    r = sub.add_parser('render')
    r.add_argument('--pack', type=Path, required=True)
    r.add_argument('--out', type=Path, required=True, help='a WAV outside the repository')
    r.add_argument('--id', default='stp_strongman')
    r.add_argument('--n', type=int, default=503, help='the scene end frame N')
    r.add_argument('--before', type=lambda s: int(s, 0), default=2, help='the stage music cue before the scene')
    r.add_argument('--after', type=lambda s: int(s, 0), default=4, help="the game's music cue at N + 5")
    a = p.parse_args()
    if a.self_test:
        return self_test()
    if a.cmd == 'measure':
        return cmd_measure(a)
    if a.cmd == 'check':
        return check(a.pack, a.scenes)
    if a.cmd == 'render':
        return render(a.pack, a.id, a.out, a.n, a.before, a.after)
    p.print_help()
    return 2
if __name__ == '__main__':
    sys.exit(main())
