"""Translate the ending Earth's intact lower strip nine pixels to the right."""
import argparse
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import numpy as np
import cps1_gfx as G
import earth_tile as E
ROOT = Path(__file__).resolve().parents[3]
CODES = (33749, 33750)
MAP = ((620118, 13573, CODES[0]), (620062, 13581, CODES[1]))
SHIFT_X = 9
SOURCES = {13573: 'c691a8eef665d43dadae19581a9f4088cce1a30b72cd09011ea33a99c4cfab87', 13580: 'f013b629712f02f829458e512fad742d350dea91395cfc489f29a9d5d6cb50b2', 13581: 'fffd744a85e8f532aee02cbaeed40b47aaa75693e3bddcc5d8b1876b521876e1'}

def sha(data):
    return hashlib.sha256(data).hexdigest()

def tiles(stock):
    import title_ex as T
    source = {c: T.stock_tile(stock, c, 'scr2') for c in SOURCES}
    if any((sha(t.astype('uint8').tobytes()) != SOURCES[c] for c, t in source.items())):
        raise ValueError('native Earth tip source differs')
    strip = np.concatenate((source[13573], source[13581]), axis=1)
    moved = translate(strip)
    return (moved[:, :16], moved[:, 16:])

def translate(strip):
    if strip.shape != (16, 32) or not np.all(strip[:, -SHIFT_X:] == 15):
        raise ValueError('translation would clip original artwork')
    moved = np.full_like(strip, 15)
    moved[:, SHIFT_X:] = strip[:, :-SHIFT_X]
    if not np.array_equal(np.sort(strip[strip != 15]), np.sort(moved[moved != 15])):
        raise ValueError('translation did not preserve every nontransparent pen')
    return moved

def install(region, stock):
    result = {}
    for code, pens in zip(CODES, tiles(stock)):
        at = G.ex_offset('scr2', code)
        if any(region[at:at + 128]):
            raise ValueError('Earth tip slot occupied')
        G.put_tile(region, at, pens)
        result[hex(code)] = dict(offset=hex(at), bytes=128, encoded_sha256=sha(region[at:at + 128]), pens_sha256=sha(pens.astype('uint8').tobytes()))
    return result

def patch(image, machine):
    for at, old, new in MAP:
        attr = 268 if old == 13573 else 12
        if image[at:at + 4] != old.to_bytes(2, 'big') + attr.to_bytes(2, 'big'):
            raise ValueError(machine + ': ending tip map differs')
    for at, old, new in MAP:
        image[at:at + 2] = new.to_bytes(2, 'big')
    return [dict(address=hex(at), old=hex(old), new=hex(new)) for at, old, new in MAP]

def produce(a):
    import title_ex as T
    import mapper_testkit as K
    import respawn_fix as RF
    meta = json.loads((a.build / 'build.json').read_text())
    if meta.get('reconstructed_from_verified_export') != '261025-11':
        raise ValueError('need fresh verified Kit w')
    result = deepcopy(meta)
    result.pop('reconstructed_from_verified_export')
    stock = T.stock_gfx(K.pool([a.rom_dir / 'striderua', a.rom_dir / 'strider']))
    a.out.mkdir(parents=True, exist_ok=False)
    for machine, spec in meta['sets'].items():
        files = {n: (a.build / machine / n).read_bytes() for n in spec['files']}
        if any((sha(b) != spec['files'][n] for n, b in files.items())):
            raise ValueError('input changed')
        region = E.join_graphics(files)
        graphics = install(region, stock)
        files.update(zip(E.GFX_FILES, G.split_region(region)))
        image = RF.compose(files, RF.SETS[machine])
        mapping = patch(image, machine)
        files.update(RF.decompose(image, RF.SETS[machine], {n: len(files[n]) for n, _, _ in RF.SETS[machine]}))
        out = a.out / machine
        out.mkdir()
        for n, b in files.items():
            (out / n).write_bytes(b)
        result['sets'][machine]['files'] = {n: sha(b) for n, b in files.items()}
        result['sets'][machine]['earth_tip'] = dict(graphics=graphics, mapping=mapping, translation_pixels=[SHIFT_X, 0], original_pixels_preserved=True)
    (a.out / 'build.json').write_text(json.dumps(result, indent=2) + '\n')
    report = dict(schema='striderex-earth-tip-build/1', passed=True, input_files={m: s['files'] for m, s in meta['sets'].items()}, build_files={m: s['files'] for m, s in result['sets'].items()}, native_source_pens_sha256={hex(c): h for c, h in SOURCES.items()}, script_sha256=sha(Path(__file__).read_bytes()), original_graphics_preserved=True, code_audio_and_timing_preserved=True, translation_pixels=[SHIFT_X, 0], every_nontransparent_pen_preserved=True, no_repainting_or_scaling=True, hardware_review_granted=False)
    (a.out / 'earth-tip-build.json').write_text(json.dumps(report, indent=2) + '\n')
    print('PASS: intact native Earth strip translated nine pixels right')

def self_test():
    image = bytearray(1048576)
    for at, old, new in MAP:
        image[at:at + 4] = old.to_bytes(2, 'big') + (268 if old == 13573 else 12).to_bytes(2, 'big')
    old = bytes(image)
    patch(image, 'test')
    assert {i for i, (a, b) in enumerate(zip(old, image)) if a != b} == {at + i for at, _, _ in MAP for i in (0, 1)}
    image = bytearray(old)
    image[MAP[0][0] + 2] ^= 1
    before = bytes(image)
    try:
        patch(image, 'test')
    except ValueError:
        pass
    else:
        raise AssertionError('unguarded map accepted')
    assert bytes(image) == before
    strip = np.full((16, 32), 15, dtype=np.int32)
    strip[:, :16] = np.arange(256).reshape(16, 16) % 15
    moved = translate(strip)
    assert np.array_equal(moved[:, SHIFT_X:SHIFT_X + 16], strip[:, :16])
    assert np.all(moved[:, :SHIFT_X] == 15)
    strip[:, -1] = 1
    try:
        translate(strip)
    except ValueError:
        pass
    else:
        raise AssertionError('clipped original artwork accepted')
    import title_ex as T
    import ending_ex as END
    assert T.S2_LAST < CODES[0] < CODES[1] < E.CODE < END.S2_LAST
    print('Earth tip source/map guard self-test PASS')

def main():
    import sys
    if sys.argv[1:] == ['--self-test']:
        return self_test()
    p = argparse.ArgumentParser(description=__doc__)
    for name in ('build', 'rom-dir', 'out'):
        p.add_argument('--' + name, type=Path, required=True)
    a = p.parse_args()
    a.build = a.build.resolve()
    a.rom_dir = a.rom_dir.resolve()
    a.out = a.out.resolve()
    produce(a)
if __name__ == '__main__':
    main()
