; Entered only from the desert camera's native-down fallback. Grounded
; slope following keeps every instruction and cycle of its approved path.
        org $1F4800
        cmpi.b #4,$FF10CD
        bne.s .native
        btst #3,$FF0C7C              ; preserve native Up; allow a gentle settle after releasing Down
        bne.s .native
        jmp SMOOTH_DOWN
.native:
        jmp NATIVE_DOWN
