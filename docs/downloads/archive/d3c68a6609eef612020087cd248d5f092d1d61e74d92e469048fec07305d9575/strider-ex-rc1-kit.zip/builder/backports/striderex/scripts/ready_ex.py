"""Strider EX: PLAYER1/PLAYER2 READY (and GO) the same distance below the stage's name in every stage."""
import argparse
import struct
import sys
from pathlib import Path
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
ITEMS = ('p1', 'p2', 'go')
PARAM = {'p1': 9, 'p2': 10, 'go': 11}
TEXT_TABLE = {'striderua': 29222, 'striderjr': 29084}
SPRITE_TABLE = {'striderua': 55410, 'striderjr': 54738}
TEXT = {'striderua': {'p1': 29476, 'p2': 29494, 'go': 29512}, 'striderjr': {'p1': 29338, 'p2': 29356, 'go': 29374}}
SPRITE = {'striderua': {'p1': 55982, 'p2': 56006, 'go': 56030}, 'striderjr': {'p1': 55310, 'p2': 55334, 'go': 55358}}
STOCK_TEXT = {'p1': b'\x10\x0c\x1ePLAYER1  READY\xff', 'p2': b'\x10\x0c\x1ePLAYER2  READY\xff', 'go': b'\x17\x0c\x1eGO\xff'}
STOCK_SPRITE = {'p1': bytes.fromhex('0007 0000 0010 00c0 0070 1634 1635 1636 1601 1621 1622 1623'), 'p2': bytes.fromhex('0007 0000 0010 00c0 0070 1634 1635 1636 1602 1621 1622 1623'), 'go': bytes.fromhex('0001 0000 0010 00f8 0070 163e')}
ROUTINES = {'striderua': {'handover': (41578, '3b7c00780e74303c09094eb80e10'), 'text_draw': (28988, '700010280006d00048e70080207c00007226'), 'text_erase': (29110, '700010280006d00048e70080207c00007226'), 'text_cell': (29042, '06800090a008ef89d280'), 'sprite_table': (54400, '267c0000d87210280006')}, 'striderjr': {'handover': (41440, '3b7c00780e74303c09094eb80e10'), 'text_draw': (28850, '700010280006d00048e70080207c0000719c'), 'text_erase': (28972, '700010280006d00048e70080207c0000719c'), 'text_cell': (28904, '06800090a008ef89d280'), 'sprite_table': (53728, '267c0000d5d210280006')}}
TEXT_ROW = (12, 15)
SPRITE_Y = (112, 136)
SPACE = 28704
FONT_MAP = 14470
STAGE_BYTE = 16714930
STAGE_NAMES = ('St. Petersburg', 'Siberia', 'Amazon', 'Aerial Battleship', 'Third Moon', 'Kyzylkum desert')
NAME_BOTTOM = (111, 111, 95, 95, 111, 111)
GAP = 8
GLYPH_TOP = 0
MOVED_TOP = 8 * TEXT_ROW[1]
assert MOVED_TOP == SPRITE_Y[1] - 16
OBJECT = {'striderua': dict(obj=54330, init=54642, blink=55096, reg=24118, free=24100), 'striderjr': dict(obj=53658, init=53970, blink=54424, reg=23980, free=23962)}
OBJ_HEAD = '700010280002303b00064efb0002000801bc041e0426700010280006d040303b00064efb0002'
PAR0 = '0018001800b600b600b600b60054008800e4011201120162'
PAR2_HEAD = '700010280006d040303b00064efb0002'
PAR2 = '00180018011001100110011000ae00fc011001240124020c'
INIT_CODE = '117c00010001102d8c82d12800067000267c{stab}10280006d0403033000047f30000214b001a117c00020002117c00010032117c000000334a2d8ccc6600000e117c000200044ef9{draw}4e75117c000100017000267c{stab}10280006d0403033000047f30000214b001a117c00020002117c007800324a2d8ccc6600000e117c000200044ef9{draw}4e75'
BLINK_CODE = '4a2d201466000014700010280004303b00064efb0002000600664e75700010280003303b00064efb00020004003a5328003267000006{reg}522800330c280003003367000010117c00020003117c001e00324e75117c00060002303c090b4ef80e1053280032670000044e75117c00000003117c001e00324e75700010280003303b00064efb00020004004253280032670000044e75522800330c280003003367000014117c001e0032117c000200034ef9{erase}117c000600024eb9{erase}303c090b4ef80e1053280032670000044e75117c00000003117c001e00324ef9{draw}4a2d201466000014700010280004303b00064efb00020006001a4e755328003267000006{reg}117c000600024e7553280032670000044e75117c000600024ef9{erase}117c000600024e75{free}'
TEXT_SITES = (('init', 72, 'rdy_draw'), ('init', 138, 'rdy_draw'), ('blink', 226, 'rdy_draw'), ('blink', 178, 'rdy_erase'), ('blink', 190, 'rdy_erase'), ('blink', 296, 'rdy_erase'))
SPRITE_SITES = (('init', 16, 'rdy_spr9'), ('init', 88, 'rdy_spr11'))
TAIL = 18
RDY_TEXT_ENTRY = '700010280006d00048e700807200123900ff0cb20c0100{n:02x}63027206d241d24141fa'
RDY_SPR_ENTRY = '103900ff0cb20c0000{n:02x}63027006d040d04047fa'
RDY_SPR_AFTER = '2673000070004ef9'

def be16(img, a):
    return int.from_bytes(img[a:a + 2], 'big')

def be32(img, a):
    return int.from_bytes(img[a:a + 4], 'big')

def ready_top(stage):
    """READY's top screen line in a stage: GAP empty lines below the name's lowest drawn pixel."""
    return NAME_BOTTOM[stage] + 1 + GAP - GLYPH_TOP

def addresses(machine):
    """The region's addresses the patch and asm/ready.s use."""
    o = OBJECT[machine]
    return dict(o, draw=ROUTINES[machine]['text_draw'][0], erase=ROUTINES[machine]['text_erase'][0], text_table=TEXT_TABLE[machine], sprite_table=SPRITE_TABLE[machine], go_init=o['init'] + 80, go_run=o['blink'] + 232)

def object_code(machine):
    """{block: (address, expected stock bytes)} of the READY object."""
    a = addresses(machine)
    f = dict(stab=f"{a['sprite_table']:08x}", draw=f"{a['draw']:08x}", erase=f"{a['erase']:08x}", reg=f"4ef8{a['reg']:04x}", free=f"4ef8{a['free']:04x}")
    return {'head': (a['obj'], bytes.fromhex(OBJ_HEAD)), 'par0': (a['obj'] + 38, bytes.fromhex(PAR0)), 'par2_head': (a['obj'] + 458, bytes.fromhex(PAR2_HEAD)), 'par2': (a['obj'] + 474, bytes.fromhex(PAR2)), 'init': (a['init'], bytearray.fromhex(INIT_CODE.format(**f))), 'blink': (a['blink'], bytearray.fromhex(BLINK_CODE.format(**f)))}

def sites(machine):
    """[(address, stock bytes, symbol, kind)] of the eight sites."""
    a = addresses(machine)
    blocks = object_code(machine)
    out = []
    for blk, off, sym in TEXT_SITES:
        at = blocks[blk][0] + off
        tgt = a['draw'] if sym == 'rdy_draw' else a['erase']
        out.append((at, bytes(blocks[blk][1][off:off + 6]), sym, 'text', tgt))
    for blk, off, sym in SPRITE_SITES:
        at = blocks[blk][0] + off
        out.append((at, bytes(blocks[blk][1][off:off + 6]), sym, 'sprite', a['sprite_table']))
    return out

def check_object(img, machine, hooked=None):
    """The READY object's code in one region's program: stock, or with the eight sites hooked (to any"""
    a = addresses(machine)
    blocks = object_code(machine)
    st = sites(machine)
    work = bytearray(img)
    targets, hooked_n = ({}, 0)
    for at, stock, sym, kind, tgt in st:
        cur = bytes(img[at:at + 6])
        if cur != stock:
            hooked_n += 1
            want = b'N\xf9' if kind == 'sprite' else stock[:2]
            if cur[:2] != want:
                raise SystemExit(f'ready_ex: {machine} site {at:#x} ({sym}) has an unexpected shape')
            v = be32(cur, 2)
            if targets.setdefault(sym, v) != v:
                raise SystemExit(f'ready_ex: {machine} the {sym} sites do not agree')
            work[at:at + 6] = stock
    for name, (at, want) in blocks.items():
        if bytes(work[at:at + len(want)]) != bytes(want):
            raise SystemExit(f'ready_ex: {machine} READY object {name} at {at:#x} has an unexpected shape')
    par0, par2 = (a['obj'] + 38, a['obj'] + 474)
    for p in range(12):
        t0, t2 = (par0 + be16(img, par0 + 2 * p), par2 + be16(img, par2 + 2 * p))
        if (t0 in (a['init'], a['go_init'])) != (p in (9, 10, 11)) or (t2 in (a['blink'], a['go_run'])) != (p in (9, 10, 11)):
            raise SystemExit(f'ready_ex: {machine} parameter {p} reaches the READY code (or 9-11 do not)')
    if par0 + be16(img, par0 + 22) != a['go_init'] or par2 + be16(img, par2 + 22) != a['go_run'] or {par0 + be16(img, par0 + 18), par0 + be16(img, par0 + 20)} != {a['init']} or ({par2 + be16(img, par2 + 18), par2 + be16(img, par2 + 20)} != {a['blink']}):
        raise SystemExit(f'ready_ex: {machine} parameters 9-11 do not reach the READY code as expected')
    if hooked_n not in (0, len(st)):
        raise SystemExit(f'ready_ex: {machine} only {hooked_n} of the {len(st)} READY sites are hooked')
    if hooked is False and targets:
        raise SystemExit(f'ready_ex: {machine} the READY sites are already hooked')
    if isinstance(hooked, dict) and targets != {k: hooked[k] for k in ('rdy_draw', 'rdy_erase', 'rdy_spr9', 'rdy_spr11')}:
        raise SystemExit(f'ready_ex: {machine} the READY sites do not reach ready.s')
    return targets or 'stock'

def locate(img, machine):
    """Check one region's stock program (or a READY-patched one) and return the stock records' rows and"""
    for name, (a, hexs) in ROUTINES[machine].items():
        if img[a:a + len(hexs) // 2] != bytes.fromhex(hexs):
            raise SystemExit(f'ready_ex: {machine} {name} at {a:#x} has an unexpected shape')
    out = {}
    for k in ITEMS:
        t, s = (TEXT[machine][k], SPRITE[machine][k])
        if TEXT_TABLE[machine] + be16(img, TEXT_TABLE[machine] + 2 * PARAM[k]) != t:
            raise SystemExit(f'ready_ex: {machine} text table entry {PARAM[k]} is not {t:#x}')
        if SPRITE_TABLE[machine] + be16(img, SPRITE_TABLE[machine] + 2 * PARAM[k]) != s:
            raise SystemExit(f'ready_ex: {machine} sprite table entry {PARAM[k]} is not {s:#x}')
        st, ss = (STOCK_TEXT[k], STOCK_SPRITE[k])
        rec = bytes(img[t:t + len(st)])
        if rec[0] != st[0] or rec[2:] != st[2:]:
            raise SystemExit(f'ready_ex: {machine} text record {k} at {t:#x} differs from stock beyond its row')
        spr = bytes(img[s:s + len(ss)])
        if spr[:8] != ss[:8] or spr[10:] != ss[10:]:
            raise SystemExit(f'ready_ex: {machine} sprite record {k} at {s:#x} differs from stock beyond its y')
        out[k] = dict(text=t, row=rec[1], sprite=s, y=be16(img, s + 8))
    return out

def records_at(top):
    """The text and sprite records with READY's top on screen line `top` (exact on a whole text row)."""
    if top % 8:
        raise SystemExit(f'ready_ex: READY at line {top} is not on a whole SCROLL1 row')
    text = {k: bytes([v[0], top // 8]) + v[2:] for k, v in STOCK_TEXT.items()}
    spr = {k: v[:8] + (top + 16).to_bytes(2, 'big') + v[10:] for k, v in STOCK_SPRITE.items()}
    return (text, spr)

def stage_tops():
    return [ready_top(s) for s in range(len(STAGE_NAMES))]
PLACES = ('equal', 'uniform', 'stock')

def place_tops(places='equal'):
    """READY's top screen line per stage: 'equal' GAP lines below every name (the build), 'uniform'"""
    if places == 'equal':
        return stage_tops()
    if places == 'uniform':
        return [MOVED_TOP] * len(STAGE_NAMES)
    if places == 'stock':
        return [8 * TEXT_ROW[0]] * len(STAGE_NAMES)
    raise SystemExit(f"ready_ex: unknown READY places {places!r} (one of {', '.join(PLACES)})")

def inc_text(machine, places='equal'):
    """ready.inc for asm/ready.s: the region's addresses, rdy_text_tabs / rdy_sprite_tabs (one long per"""
    a = addresses(machine)
    tops = place_tops(places)
    head = f"; ready_ex.py ({machine}): READY {GAP} lines below each stage's name; tops {tops}" if places == 'equal' else f'; ready_ex.py ({machine}): READY control, {places} places (ready_gate.py); tops {tops}'
    L = [head, f'RDY_STAGE equ ${STAGE_BYTE:X}', f'RDY_STAGES equ {len(STAGE_NAMES)}', f"RDY_DRAW_TAIL equ ${a['draw'] + TAIL:X}", f"RDY_ERASE_TAIL equ ${a['erase'] + TAIL:X}", f"RDY_SPR9_TAIL equ ${a['init'] + 22:X}", f"RDY_SPR11_TAIL equ ${a['init'] + 94:X}", f"RDY_TEXT_TABLE equ ${a['text_table']:X}", f"RDY_SPRITE_TABLE equ ${a['sprite_table']:X}"]
    alt = sorted({t for t in tops if t != MOVED_TOP})
    name = {t: ('RDY_TEXT_TABLE', 'RDY_SPRITE_TABLE') if t == MOVED_TOP else (f'rdy_t{t}', f'rdy_s{t}') for t in tops}
    L.append('rdy_text_tabs:   dc.l    ' + ','.join((name[t][0] for t in tops)) + ',RDY_TEXT_TABLE')
    L.append('rdy_sprite_tabs: dc.l    ' + ','.join((name[t][1] for t in tops)) + ',RDY_SPRITE_TABLE')
    for t in alt:
        text, spr = records_at(t)
        for form, recs, base in (('t', text, f'rdy_t{t}'), ('s', spr, f'rdy_s{t}')):
            L += ['        even', f"{base} equ {base}_w-{2 * PARAM['p1']}", f'{base}_w:', '        dc.w    ' + ','.join((f'{base}_{k}-{base}' for k in ITEMS))]
            for k in ITEMS:
                b = recs[k]
                if form == 't':
                    L.append(f'{base}_{k}: dc.b    ' + ','.join((f'${v:02X}' for v in b)))
                else:
                    L.append(f'{base}_{k}: dc.w    ' + ','.join((f'${be16(b, i):04X}' for i in range(0, len(b), 2))))
    L.append('        even')
    return '\n'.join(L) + '\n'

def patch_program(img, machine, syms, places='equal'):
    """Move the six stock records to build 42's place (stock rows and ys required) and send the READY"""
    loc = locate(img, machine)
    check_object(img, machine, hooked=False)
    rep = {}
    for k, v in loc.items():
        if (v['row'], v['y']) != (TEXT_ROW[0], SPRITE_Y[0]):
            raise SystemExit(f'ready_ex: {machine} record {k} is not at its stock row and y')
        img[v['text'] + 1] = TEXT_ROW[1]
        img[v['sprite'] + 8:v['sprite'] + 10] = SPRITE_Y[1].to_bytes(2, 'big')
        rep[k] = dict(text=f"{v['text']:#x}", row=[TEXT_ROW[0], TEXT_ROW[1]], sprite=f"{v['sprite']:#x}", y=[f'{SPRITE_Y[0]:#x}', f'{SPRITE_Y[1]:#x}'])
    hooks = []
    for at, stock, sym, kind, _ in sites(machine):
        new = (stock[:2] if kind == 'text' else b'N\xf9') + syms[sym].to_bytes(4, 'big')
        img[at:at + 6] = new
        hooks.append(dict(at=f'{at:#x}', stock=stock.hex(), new=new.hex(), to=sym))
    check_object(img, machine, hooked=syms)
    out = dict(records=rep, sites=hooks, gap=GAP, name_bottom=list(NAME_BOTTOM), ready_top=place_tops(places))
    if places != 'equal':
        out['places'] = places
    return out

def tabs_at(img, bank, machine):
    """{symbol: address} of the per-stage table lists asm/ready.s reads (rdy_text_tabs for rdy_draw and"""
    t = check_object(img, machine)
    if t == 'stock':
        return None

    def rd(a, k):
        src, o = (img, a) if a < 1048576 else (bank, a - 1048576)
        return bytes(src[o:o + k])
    n = len(STAGE_NAMES)
    tabs = {}
    for sym, shape, disp_at in (('rdy_draw', RDY_TEXT_ENTRY, 34), ('rdy_erase', RDY_TEXT_ENTRY, 34), ('rdy_spr9', RDY_SPR_ENTRY, 20), ('rdy_spr11', RDY_SPR_ENTRY, 20)):
        e = t[sym]
        want = bytes.fromhex(shape.format(n=n))
        if rd(e, len(want)) != want:
            raise SystemExit(f'ready_ex: {machine} {sym} at {e:#x} has an unexpected shape')
        tabs[sym] = e + disp_at + struct.unpack('>h', rd(e + disp_at, 2))[0]
        tail = e + disp_at + 2
        if sym.startswith('rdy_spr'):
            if rd(tail, 8) != bytes.fromhex(RDY_SPR_AFTER):
                raise SystemExit(f'ready_ex: {machine} {sym} has an unexpected end')
            back = be32(rd(tail + 8, 4), 0)
            if back != addresses(machine)['init'] + (22 if sym == 'rdy_spr9' else 94):
                raise SystemExit(f'ready_ex: {machine} {sym} does not return to its init')
        else:
            stock = ROUTINES[machine]['text_draw' if sym == 'rdy_draw' else 'text_erase'][0]
            if rd(tail, 6) != bytes.fromhex('20701000 4ef9'.replace(' ', '')) or be32(rd(tail + 6, 4), 0) != stock + TAIL:
                raise SystemExit(f'ready_ex: {machine} {sym} does not go on in the stock routine')
    if tabs['rdy_draw'] != tabs['rdy_erase'] or tabs['rdy_spr9'] != tabs['rdy_spr11']:
        raise SystemExit(f'ready_ex: {machine} draw and erase (or the two inits) read different tables')
    return tabs

def stage_tables(img, bank, machine):
    """{stage (0-5, and 'other'): (text table base, sprite table base)} as the program's READY code"""
    n = len(STAGE_NAMES)
    tabs = tabs_at(img, bank, machine)
    if tabs is None:
        return {s: (TEXT_TABLE[machine], SPRITE_TABLE[machine]) for s in [*range(n), 'other']}

    def rd(a, k):
        src, o = (img, a) if a < 1048576 else (bank, a - 1048576)
        return bytes(src[o:o + k])
    out = {}
    for i, s in enumerate([*range(n), 'other']):
        out[s] = (be32(rd(tabs['rdy_draw'] + 4 * i, 4), 0), be32(rd(tabs['rdy_spr9'] + 4 * i, 4), 0))
    return out

def table_records(img, bank, machine, base_t, base_s):
    """{item: (text record bytes, sprite record bytes, text record address, sprite record address)}"""

    def rd(a, k):
        src, o = (img, a) if a < 1048576 else (bank, a - 1048576)
        return bytes(src[o:o + k])
    out = {}
    for k in ITEMS:
        ta = base_t + struct.unpack('>h', rd(base_t + 2 * PARAM[k], 2))[0]
        sa = base_s + struct.unpack('>h', rd(base_s + 2 * PARAM[k], 2))[0]
        out[k] = (rd(ta, len(STOCK_TEXT[k])), rd(sa, len(STOCK_SPRITE[k])), ta, sa)
    return out

def text_cells(img, at):
    """A text record's cells as the draw routine writes them: [(graphics RAM address, code word)]."""
    out = []
    col, row, i = (img[at], img[at + 1], at + 3)
    d0 = 9478152 + 4 * row
    a1 = d0 + 128 * col
    while img[i] < 128:
        if img[i] == 47:
            col, row, i = (img[i + 1], img[i + 2], i + 4)
            d0 = 9478152 + 4 * row
            a1 = d0 + 128 * col
            continue
        out.append((a1, 28672 + img[FONT_MAP + img[i]]))
        a1 += 128
        if a1 > 9484288:
            d0 += 4
            a1 = d0
        i += 1
    return out

def record_cells(img, rec):
    """text_cells for a record given as bytes (the font map from the program image)."""
    out = []
    col, row = (rec[0], rec[1])
    a1 = 9478152 + 4 * row + 128 * col
    for c in rec[3:]:
        if c >= 128:
            break
        if c == 47:
            raise SystemExit('ready_ex: a READY record with a new row (not expected)')
        out.append((a1, 28672 + img[FONT_MAP + c]))
        a1 += 128
    return out

def sprite_cells(img, at):
    """A sprite record's entries as the sprite frame writes them: [(x, y, code, attribute)]."""
    return record_entries(bytes(img[at:at + 10 + 2 * be16(img, at)]))

def record_entries(rec):
    n, attr, step, x, y = struct.unpack('>5H', rec[:10])
    out = []
    for k in range(n):
        c = be16(rec, 10 + 2 * k)
        if c in (65535, 65534):
            raise SystemExit('ready_ex: a sprite record with a skip or segment mark (not expected)')
        out.append((x + step * k, y, c, attr))
    return out

def s1_screen(addr, base, sx, sy):
    """The screen (x, y) of a SCROLL1 cell at graphics RAM `addr`, for the SCROLL1 base register `base`"""
    idx = (addr - (base << 8)) // 4
    if not 0 <= idx < 4096:
        return None
    col = idx >> 5 & 63
    row = idx & 31 | idx >> 6 & 32
    return ((8 * col - sx & 511) - 64, (8 * row - sy & 511) - 16)

def s1_column(addr, base):
    return (addr - (base << 8)) // 4 >> 5 & 63

class Art:
    """Tile pens: stock graphics (title_ex.stock_gfx) and, for EX codes, a build's EX region."""
    _stock = {}

    def __init__(self, rom_dir, ex_region=None):
        import mapper_testkit as K
        import title_ex as TX
        if rom_dir not in Art._stock:
            Art._stock[rom_dir] = TX.stock_gfx(K.pool([rom_dir]))
        self.gfx = Art._stock[rom_dir]
        self.ex = ex_region
        self._c = {}

    def obj(self, code):
        """A 16x16 sprite tile (pen 15 transparent)."""
        import cps1_gfx as G
        if code not in self._c:
            if code >= 32768:
                if self.ex is None:
                    raise SystemExit(f'ready_ex: EX sprite code {code:#x} without an EX region')
                self._c[code] = G.get_tile(self.ex, G.ex_offset('obj', code), 16)
            else:
                self._c[code] = G.get_tile(self.gfx, 128 * code, 16)
        return self._c[code]

    def s1(self, code, half):
        """An 8x8 SCROLL1 tile (stock codes 0x7000-0x7FFF: bank 1; half = the map column's parity)."""
        import cps1_gfx as G
        key = ('s1', code, half)
        if key not in self._c:
            if not 28672 <= code < 32768:
                raise SystemExit(f'ready_ex: SCROLL1 code {code:#x} outside the stock font range')
            self._c[key] = G.get_tile(self.gfx, 2097152 + 64 * code, 8, half)
        return self._c[key]

    def cell(self, code, attr):
        """A sprite cell as drawn: the tile with the attribute's flips (0x20 X, 0x40 Y)."""
        t = self.obj(code)
        if attr & 32:
            t = t[:, ::-1]
        if attr & 64:
            t = t[::-1, :]
        return t

def drawn_rows(pens):
    """The rows of a pen array that draw a pixel (a pen other than 15)."""
    return [r for r in range(pens.shape[0]) if (pens[r] != 15).any()]

def card_records(img):
    """St. Petersburg's A.D. 2048 card: [(record, sprite Y)] of its two kind-2 objects (the caption"""
    import desert_caption as DC
    obj = DC.locate(img)['DZ_CAPOBJ']
    s0 = obj + 22
    if img[s0:s0 + 22] != bytes.fromhex('117c00020002317c010000304a28000667000028217c') or img[s0 + 26:s0 + 28] != b'\x00\x1a' or img[s0 + 50:s0 + 52] != b'1|' or (img[s0 + 54:s0 + 56] != b'\x00\x0c') or (img[s0 + 56:s0 + 58] != b'Nu'):
        raise SystemExit("ready_ex: the caption object's state 0 has an unexpected shape")
    tab = obj + 96
    at = tab + be16(img, tab)
    if img[at:at + 2] != b'!|' or img[at + 6:at + 8] != b'\x00\x1a' or img[at + 30:at + 32] != b'1|' or (img[at + 34:at + 36] != b'\x00\x0c') or (img[at + 36:at + 38] != b'Nu'):
        raise SystemExit("ready_ex: St. Petersburg's card entry has an unexpected shape")
    return [(be32(img, at + 2), be16(img, at + 32)), (be32(img, s0 + 22), be16(img, s0 + 52))]

def caption_bottom(art, img, rec, y, bank=b''):
    """The screen line of a kind-2 record's lowest drawn pixel at sprite Y `y` (cells at Y + 16 row)."""
    src, a = (img, rec) if rec < 1048576 else (bank, rec - 1048576)
    n, c1, r1, attr = (be16(src, a + 2 * i) for i in range(4))
    rows = []
    for i in range(n):
        r = i // (c1 + 1)
        d = drawn_rows(art.cell(be16(src, a + 8 + 2 * i), attr))
        if d:
            rows.append(16 * r + d[-1])
    return y - 16 + max(rows)

def desert_bottom():
    """The desert caption's lowest drawn screen line, from its art (desert_caption.convert)."""
    import desert_caption as DC
    cap = DC.convert()
    return cap['y'] - DC.SCREEN[1] + drawn_rows(cap['pens'])[-1]

def glyph_top(art, img):
    """The top drawn line of READY's and GO's glyphs within their cells, both fonts."""
    tops = []
    for k in ITEMS:
        for a, code in record_cells(img, STOCK_TEXT[k]):
            if code != SPACE:
                for half in (0, 1):
                    tops.append(drawn_rows(art.s1(code, half))[0])
        for x, y, code, attr in record_entries(STOCK_SPRITE[k]):
            tops.append(drawn_rows(art.cell(code, attr))[0])
    return (min(tops), max(tops))

def self_test(rom_dir):
    import desert_caption as DC
    import respawn_fix as RF
    art = Art(rom_dir)
    for machine in ('striderua', 'striderjr'):
        files = {q.name: q.read_bytes() for q in (rom_dir / machine).iterdir() if q.is_file()}
        img = RF.compose(files, RF.SETS[machine])
        loc = locate(img, machine)
        assert check_object(img, machine, hooked=False) == 'stock'
        assert all(((v['row'], v['y']) == (TEXT_ROW[0], SPRITE_Y[0]) for v in loc.values()))
        p1 = text_cells(img, TEXT[machine]['p1'])
        assert len(p1) == 14 and p1[0] == (9478152 + 48 + 2048, 28752) and (p1[6][1] == 28721)
        assert [c for _, c in p1] == [28672 + c for c in b'PLAYER1  READY']
        assert record_cells(img, STOCK_TEXT['p1']) == p1
        go = text_cells(img, TEXT[machine]['go'])
        assert [a for a, _ in go] == [a for a, _ in p1[7:9]]
        assert s1_screen(p1[0][0], 36992, 65472, 256) == (128, 96)
        assert sprite_cells(img, SPRITE[machine]['p1'])[0] == (192, 112, 5684, 0)
        bottoms = {s: caption_bottom(art, img, DC.stock_caption(img, s)['record'], DC.stock_caption(img, s)['y']) for s in (1, 2, 3, 4)}
        bottoms[0] = max((caption_bottom(art, img, r, y) for r, y in card_records(img)))
        bottoms[5] = desert_bottom()
        assert [bottoms[s] for s in range(6)] == list(NAME_BOTTOM), (machine, bottoms)
        assert glyph_top(art, img) == (GLYPH_TOP, GLYPH_TOP), glyph_top(art, img)
        tops = stage_tops()
        assert all((t % 8 == 0 for t in tops)) and MOVED_TOP in tops
        for t in tops:
            text, spr = records_at(t)
            cells = record_cells(img, text['p1'])
            assert s1_screen(cells[0][0], 36992, 65472, 256) == (128, t)
            assert [c for _, c in cells] == [c for _, c in p1]
            assert record_entries(spr['p1'])[0][1] - 16 == t
        syms = dict(rdy_draw=2031616, rdy_erase=2031680, rdy_spr9=2031744, rdy_spr11=2031808)
        before = bytes(img)
        rep = patch_program(img, machine, syms)
        changed = [a for a in range(len(img)) if img[a] != before[a]]
        want = [TEXT[machine][k] + 1 for k in ITEMS] + [SPRITE[machine][k] + 9 for k in ITEMS]
        for at, stock, sym, kind, _ in sites(machine):
            want += [at + i for i in range(6) if img[at + i] != stock[i]]
            assert img[at + 2:at + 6] == syms[sym].to_bytes(4, 'big')
        assert changed == sorted(want), (machine, [hex(a) for a in changed])
        assert check_object(img, machine) == syms
        assert [a for a, _ in text_cells(img, TEXT[machine]['p1'])] == [a + 12 for a, _ in p1]
        assert s1_screen(text_cells(img, TEXT[machine]['p1'])[0][0], 36992, 65472, 256) == (128, MOVED_TOP)
        assert sprite_cells(img, SPRITE[machine]['p1'])[0][1] - 16 == MOVED_TOP
        inc = inc_text(machine)
        for t in sorted(set(tops) - {MOVED_TOP}):
            text, spr = records_at(t)
            assert f'rdy_t{t}_p1: dc.b    ' + ','.join((f'${v:02X}' for v in text['p1'])) in inc
        assert place_tops('equal') == tops and set(place_tops('uniform')) == {MOVED_TOP}
        assert set(place_tops('stock')) == {8 * TEXT_ROW[0]} and 8 * TEXT_ROW[0] == SPRITE_Y[0] - 16
        for places in PLACES:
            ctl = bytearray(before)
            rp = patch_program(ctl, machine, syms, places)
            assert bytes(ctl) == bytes(img) and rp['ready_top'] == place_tops(places)
            assert ('places' in rp) == (places != 'equal')
            ci = inc_text(machine, places)
            names = {t: ('RDY_TEXT_TABLE', 'RDY_SPRITE_TABLE') if t == MOVED_TOP else (f'rdy_t{t}', f'rdy_s{t}') for t in place_tops(places)}
            assert 'rdy_text_tabs:   dc.l    ' + ','.join((names[t][0] for t in place_tops(places))) + ',RDY_TEXT_TABLE' in ci
            assert 'rdy_sprite_tabs: dc.l    ' + ','.join((names[t][1] for t in place_tops(places))) + ',RDY_SPRITE_TABLE' in ci
            assert ci.split('\n')[1:3] == inc.split('\n')[1:3]
            assert (ci == inc) == (places == 'equal')
        assert 'rdy_t' not in inc_text(machine, 'uniform').split('rdy_sprite_tabs')[1]
        text96, _ = records_at(8 * TEXT_ROW[0])
        assert text96['p1'] == STOCK_TEXT['p1']
        assert 'rdy_t96_p1: dc.b    ' + ','.join((f'${v:02X}' for v in text96['p1'])) in inc_text(machine, 'stock')
        for refuse in ('again', 'record'):
            bad = bytearray(img if refuse == 'again' else before)
            if refuse == 'record':
                bad[TEXT[machine]['p1'] + 4] ^= 1
            try:
                (patch_program if refuse == 'again' else locate)(bad, machine, *([syms] if refuse == 'again' else []))
            except SystemExit:
                pass
            else:
                raise AssertionError(f'{refuse}: not refused')
        half = bytearray(before)
        at, stock, sym, kind, _ = sites(machine)[0]
        half[at + 2:at + 6] = syms[sym].to_bytes(4, 'big')
        try:
            check_object(half, machine)
        except SystemExit:
            pass
        else:
            raise AssertionError('a partly hooked object was not refused')
        print(machine, 'ok: bottoms', [bottoms[s] for s in range(6)], 'tops', tops, 'sites', [h['at'] for h in rep['sites']])
    print('PASS')

def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('--self-test', action='store_true')
    p.add_argument('--rom-dir', type=Path, required=True)
    a = p.parse_args()
    if a.self_test:
        self_test(a.rom_dir.resolve())
    return 0
if __name__ == '__main__':
    sys.exit(main())
