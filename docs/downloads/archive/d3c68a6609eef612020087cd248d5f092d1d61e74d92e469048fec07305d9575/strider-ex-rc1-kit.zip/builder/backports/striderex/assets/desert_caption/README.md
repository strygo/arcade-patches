# The desert's location caption: Кызылкум

The arcade-style fade-in name for the desert (manifests/desert_intro.json:
art, each in its own script themed to its stage. Siberia's "Сибирь", for
example, is flowing teal Cyrillic (PHASE0_FINDINGS.md "Stock stage
intros").

**Candidates** (`kyzylkum_A.png` to `kyzylkum_E.png`):
- **Rendering:** each is the word set in a macOS font with Cyrillic, drawn
  at 8x and box-downsampled to caption scale. The alpha is thresholded at
  110/255.
- **Colors:** a five-step sand gradient from top to bottom, on the CPS-1's
  4-bit levels (#FFEEAA, #EECC77, #DDAA44, #BB7722, #884411), with a 1-px
  dark outline (#331100). The background is transparent.
- **Fonts:**
  - A: Trattatello, 22 px;
  - B: Luminari, 18;
  - C: Phosphate, 18;
  - D: Rockwell, 17;
  - E: Copperplate, 18.

restyled, stock-like variant of B may follow; it would be a data swap of the
one PNG (below).

**In the build** (since 2026-10-14):
- **The file:** `scripts/desert_caption.py` reads the one PNG named by the
  `caption.art` line of `manifests/desert_intro.json`. To switch candidates,
  change that line.
- **What the PNG may hold:** any size up to 7×2 cells of 16 px, alpha 0 or
  255 only, and at most 15 colors on the 4-bit levels. The build refuses
  anything else.
- **Placement:** the grid is centered on screen X 184, its top at Y 80, and
  the art sits on its bottom line, as the stock captions do.
- **HBMAME:** it shows a 4-bit level of 1 as 0, so the outline `#331100`
  shows there as `#330000` (`scene_gate.hb_rgb`).
