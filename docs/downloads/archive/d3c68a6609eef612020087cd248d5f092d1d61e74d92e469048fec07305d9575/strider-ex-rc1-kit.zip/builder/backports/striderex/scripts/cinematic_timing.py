"""The cinematic player's VBlank handler time on the jtcps1 core, from a scene stream."""
import struct
import sys
LINES_PER_FRAME = 262
BLANK_LINES = 38
HANDLER_LINES = 200
HANDLER_LIMIT = 215
BASE = 2.0
OP = 0.37
APPLY = {1: 0.207, 7: 0.09, 2: 0.096, 5: 0.043, 10: (0.063, 0.046), 12: 0.065, 13: 0.19}
PAL_OP = 0.039
ROWS_OP, ROWS_RUN = (11.0, 0.05)
FLIP_ENTRY = 0.21
PAL_COPY = 12.6
CAP_ENTRY = 0.07
DECODE = dict(group=0.051, literal=0.107, match=0.301, match_byte=0.051)
SLOW = 2.0
MIRROR_BYTE = 0.02
DECODE_BYTE = 0.13
RSIZE, SLOW_FROM = (8192, 8192 - 8 * 18)
TAIL = 4096

def op_size(body, q):
    """Bytes of the op at body[q] (scene_core.s formats), its op word included."""
    word, = struct.unpack_from('>H', body, q)
    op = word & 255
    if op in (11, 14):
        return 2
    cnt, = struct.unpack_from('>H', body, q + 2)
    return {1: 4 + 6 * cnt, 7: 4 + 6 * cnt, 15: 4 + 6 * cnt, 2: 4 + 8 * cnt, 4: 6 + 4 * cnt, 3: 4, 6: 6, 8: 6, 9: 8, 10: 12, 12: 6 + 4 * cnt, 13: 6 + 4 * cnt, 16: 6 + 4 * cnt, 5: 6 + 2 * (struct.unpack_from('>H', body, q + 4)[0] if op == 5 else 0)}[op]

def ops(body):
    """[(op, slot, offset)] of a record body (ending with its 0x0000)."""
    out, q = ([], 0)
    while True:
        word, = struct.unpack_from('>H', body, q)
        if word == 0:
            return out
        out.append((word & 255, word >> 8, q))
        q += op_size(body, q)

def apply_lines(body):
    """(lines, sprite entries of its op 2 or None, palette copy) of one record body's ops."""
    t, sprites, palcopy = (0.0, None, False)
    for op, _, q in ops(body):
        t += OP
        if op in (1, 7, 2, 12, 13, 15, 16):
            cnt, = struct.unpack_from('>H', body, q + 2)
            t += APPLY[{15: 1, 16: 13}.get(op, op)] * cnt
            if op == 2:
                sprites = cnt
        elif op == 5:
            cnt, = struct.unpack_from('>H', body, q + 4)
            t += PAL_OP + APPLY[5] * cnt
        elif op == 4:
            cnt, = struct.unpack_from('>H', body, q + 2)
            t += ROWS_OP + ROWS_RUN * cnt
        elif op == 10:
            kind, cnt = (struct.unpack_from('>H', body, q + 2)[0], struct.unpack_from('>H', body, q + 10)[0])
            t += APPLY[10][kind] * cnt
        elif op == 11:
            t += PAL_COPY
            palcopy = True
    return (t, sprites, palcopy)

def records(stream):
    """[(offset of the length word, body)] up to the 0xFFFF end mark."""
    pos, out = (0, [])
    while True:
        n, = struct.unpack_from('>H', stream, pos)
        if n == 65535:
            return out
        out.append((pos, stream[pos + 2:pos + 2 + n]))
        pos += 2 + n

def lz_groups(lz):
    """Per LZSS group: (output bytes after it, literals, matches, match bytes)."""
    out, i, w = ([], 0, 0)
    while i < len(lz):
        flags = lz[i]
        i += 1
        lit = mt = mb = 0
        for bit in range(8):
            if i >= len(lz):
                break
            if flags >> bit & 1:
                lit += 1
                i += 1
            else:
                v = lz[i] << 8 | lz[i + 1]
                i += 2
                mt += 1
                mb += (v & 15) + 3
        w += lit + mb
        out.append((w, lit, mt, mb))
    return out

def predict(stream, lz, schedule=(), pages=()):
    """Lines of each VBlank handler (index = the record it applies) on jtcps1."""
    recs = records(stream)
    groups = lz_groups(lz)
    sched = dict(((int(r), p) for r, p in schedule))
    gi, w = (0, 0)

    def fill(r, need):
        nonlocal gi, w
        t = 0.0
        while w - r < need and gi < len(groups):
            end, lit, mt, mb = groups[gi]
            k = SLOW if w % RSIZE > SLOW_FROM else 1.0
            t += DECODE['group'] + k * (DECODE['literal'] * lit + DECODE['match'] * mt + DECODE['match_byte'] * mb)
            w = end
            gi += 1
        return t

    def mirror(pos, size):
        return MIRROR_BYTE * max(0, pos % RSIZE + size - RSIZE)
    fill(0, 2)
    if recs:
        fill(0, len(recs[0][1]) + 2)
    lines, cap, stream_n, spr_new = ([], 0, 0, 0)
    for k, (pos, body) in enumerate(recs):
        t = BASE + (FLIP_ENTRY * spr_new if spr_new else 0.0)
        spr_new = 0
        a, sprites, _ = apply_lines(body)
        t += a
        if sprites is not None:
            stream_n = sprites
            spr_new = cap + stream_n + 1
        if k in sched:
            pg = sched[k]
            cap = len(pages[pg][1]) if pg is not None else 0
            t += CAP_ENTRY * (stream_n + cap)
            spr_new = cap + stream_n + 1
        r = pos + 2 + len(body)
        t += fill(r, 2)
        if k + 1 < len(recs):
            size = len(recs[k + 1][1]) + 2
            t += fill(r, size) + mirror(r, size)
        lines.append(t)
    return lines

def report(lines):
    worst = max(range(len(lines)), key=lines.__getitem__) if lines else None
    return dict(handlers=len(lines), worst_lines=round(lines[worst], 1) if lines else 0, worst_record=worst, over_plan=sum((1 for x in lines if x > HANDLER_LINES)), over_limit=sum((1 for x in lines if x > HANDLER_LIMIT)))

def self_test():
    body = struct.pack('>HH', 7, 3) + bytes(18) + struct.pack('>HHH', 5, 0, 2) + bytes(4) + struct.pack('>H', 11) + struct.pack('>HH', 2, 1) + bytes(8) + struct.pack('>H', 0)
    names = [o for o, _, _ in ops(body)]
    assert names == [7, 5, 11, 2], names
    a, spr, pc = apply_lines(body)
    want = 4 * OP + 3 * APPLY[7] + PAL_OP + 2 * APPLY[5] + PAL_COPY + APPLY[2]
    assert abs(a - want) < 1e-09 and spr == 1 and pc
    rows = struct.pack('>HHH', 4, 2, 896) + struct.pack('>HHHH', 100, 0, 156, 16) + struct.pack('>H', 0)
    assert op_size(rows, 0) == len(rows) - 2
    cue = struct.pack('>HHHH', 14, 11, 14, 0)
    assert [o for o, _, _ in ops(cue)] == [14, 11, 14] and abs(apply_lines(cue)[0] - 3 * OP - PAL_COPY) < 1e-09
    import cinematic_lz as LZ
    stream = struct.pack('>H', len(body)) + body + struct.pack('>H', len(rows)) + rows + struct.pack('>H', 65535)
    lz = LZ.encode(stream)
    got = predict(stream, lz)
    assert len(got) == 2 and got[0] > a and (got[1] > ROWS_OP), got
    print('cinematic_timing self-test passed')
    return 0
if __name__ == '__main__':
    sys.path.insert(0, __import__('os').path.dirname(__file__))
    sys.exit(self_test())
