-- Strider arcade research probe (W3b portraits): the debug start
-- (lua/arcade_debug_start.lua, loaded unchanged: stage/area DIPs, inputs,
-- sound log) plus an object census. Nothing is written to the machine
-- unless STREX_POKES asks for it.
--
-- Every frame each object pool slot is read (pool base, slot count, slot
-- size, from the pool builder at 0x2B64-0x2C98): an object is live while
-- its bytes $0 and $1 are nonzero (the sprite emitter 0x6F8D4's test); its
-- animation table pointer $1A names its kind. A row is logged when a slot
-- becomes live, changes kind or dies:
--   frame  obj  pool.slot  +/-  kind($1A)  x($8)  y($C)  state($2)
-- Also logged: the stage/area bytes on change, and every STREX_CAMERA_EVERY
-- frames (the debug start's own option, whose labels predate this) the
-- player's X/Y 0xFF10D2/D6 (object 0xFF10CA) and the camera 0xFF0FF4/F8; with
-- STREX_SHOT_EVERY=n a screenshot every n frames from STREX_SHOT_FROM.
-- STREX_WATCH="addr,addr,..." logs each listed byte when it changes.
-- STREX_SHOT_NEW_KIND=1 takes a screenshot the first time each object kind is seen.
local m=manager.machine
local sp=m.devices[':maincpu'].spaces['program']
local screen=m.screens[':screen']
local prefix=assert(os.getenv('STREX_PREFIX'))
dofile(assert(os.getenv('STREX_DEBUG_START')))
local pools={{0xff112a,5,0x50},{0xff12ba,10,0x50},{0xff15da,5,0x60},{0xff17ba,30,0x50},{0xff211a,30,0x50},
 {0xff2a7a,30,0x50},{0xff33da,30,0x50},{0xff553a,30,0x50},{0xff3d3a,16,0x40},{0xff5eda,20,0x40},{0xff6d22,60,0x50}}
local out=assert(io.open(prefix..'_objects.tsv','w'))
out:write('frame\tkind\tpool.slot\tevent\tanim\tx\ty\tstate\n')
_G.strex_palout=out
local every=tonumber(os.getenv('STREX_SHOT_EVERY') or '0')
local from=tonumber(os.getenv('STREX_SHOT_FROM') or '0')
local watch={}
for a in string.gmatch(os.getenv('STREX_WATCH') or '','[^,]+') do watch[#watch+1]={tonumber(a),-1} end
-- STREX_POKES="frame:addr=value;..." (hex allowed): research control, a 16-bit write at the
-- end of that frame, e.g. the player object's X/Y (0xFF10D2/0xFF10D6) to reach an encounter
-- open-loop input cannot; a gate applies the same pokes to the stock and the EX run.
local pokes={}
for fr,addr,val in string.gmatch(os.getenv('STREX_POKES') or '','(%d+):([%x]+)=([%x]+)') do
 pokes[#pokes+1]={tonumber(fr),tonumber(addr,16),tonumber(val,16)}
end
-- STREX_PALWRITES=1: log the first write after the start (frame 420) to each OBJ palette
-- (0x914000 + 32 * n, the base the VBlank sets every frame), to choose a slot the game leaves alone.
if os.getenv('STREX_PALWRITES')=='1' then
 local palseen={}
 _G.strex_paltap=sp:install_write_tap(0x914000,0x9143ff,'strex_pal',function(off,data,mask)
  local n=(off-0x914000)//32
  if (_G.strex_f or 0)>420 and not palseen[n] then
   palseen[n]=true
   _G.strex_palout:write(string.format('%d\tpalwrite\t%02x\t=\t%06x\t\t\t\n',_G.strex_f,n,manager.machine.devices[':maincpu'].state['CURPC'].value))
  end
 end)
end
local seen={}
local shot_new=os.getenv('STREX_SHOT_NEW_KIND')=='1'
local kinds_shot,pending={},{}
local f=0
emu.register_frame_done(function()
 f=f+1
 _G.strex_f=f
 for _,pk in ipairs(pokes) do
  if pk[1]==f then sp:write_u16(pk[2],pk[3]);out:write(string.format('%d\tpoke\t%06x\t=\t%04x\t\t\t\n',f,pk[2],pk[3])) end
 end
 for p,pool in ipairs(pools) do
  for s=0,pool[2]-1 do
   local a=pool[1]+s*pool[3]
   local live=sp:read_u8(a)~=0 and sp:read_u8(a+1)~=0
   local kind=live and sp:read_u32(a+0x1a) or 0
   local key=p*256+s
   if kind~=(seen[key] or 0) then
    if seen[key] and seen[key]~=0 then
     out:write(string.format('%d\tobj\t%d.%d\t-\t%08x\t\t\t\n',f,p,s,seen[key]))
    end
    if kind~=0 then
     out:write(string.format('%d\tobj\t%d.%d\t+\t%08x\t%d\t%d\t%02x\n',f,p,s,kind,sp:read_u16(a+8),sp:read_u16(a+0xc),sp:read_u8(a+2)))
     -- STREX_SHOT_NEW_KIND=1: a screenshot the first time each kind is seen (after the start)
     if shot_new and f>420 and not kinds_shot[kind] then
      kinds_shot[kind]=true;pending[#pending+1]=string.format('%s_k%08x_%05d.png',prefix,kind,f)
     end
    end
    seen[key]=kind
   end
  end
 end
 for _,w in ipairs(watch) do
  local v=sp:read_u8(w[1])
  if v~=w[2] then out:write(string.format('%d\twatch\t%06x\t=\t%02x\t\t\t\n',f,w[1],v));w[2]=v end
 end
 -- sprite list census: the list the OBJ base shadow (0xFF0C9A) names, 256 entries of 8 bytes,
 -- stock blank entries (0,0,0x0888,0) skipped; logs the OBJ palettes used and the entry count
 local base=sp:read_u16(0xff0c9a)*0x100
 local used,mask=0,0
 for i=0,255 do
  local e=base+8*i
  local code,attr=sp:read_u16(e+4),sp:read_u16(e+6)
  if not (code==0x0888 and attr==0 and sp:read_u32(e)==0) then
   used=used+1;mask=mask|(1<<(attr&0x1f))
  end
 end
 -- the game's own count: 0xFF0C8C (-$7374,A5) = 256 minus the entries the last list used
 local gused=0x100-sp:read_u16(0xff0c8c)
 if mask~=(_G.strex_palmask or -1) or gused>(_G.strex_used or 0) then
  out:write(string.format('%d\tobjlist\t%06x\t=\t%08x\t%d\t%d\t\n',f,base,mask,used,gused))
  _G.strex_palmask=mask;_G.strex_used=math.max(gused,_G.strex_used or 0)
 end
 if every>0 and f>=from and (f-from)%every==0 then screen:snapshot(string.format('%s_s%05d.png',prefix,f)) end
 for _,name in ipairs(pending) do screen:snapshot(name) end
 pending={}
 out:flush()
end)
