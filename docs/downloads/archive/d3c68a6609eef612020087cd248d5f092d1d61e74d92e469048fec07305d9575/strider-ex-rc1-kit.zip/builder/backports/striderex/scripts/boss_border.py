"""Remove the red boss surround with one palette word per linked page."""
import argparse
from copy import deepcopy
import json
from pathlib import Path
import struct
import sys
import boss_scene as S
import boss_scene_binary as B
from boss_voice_gate import inventory, sha

def patch(raw):
    bank = bytearray((raw[k ^ 1] for k in range(len(raw))))
    changes = []
    for scene in B.scenes(bank):
        for page in scene['pages']:
            words = list(struct.unpack_from('>16H', bank, page + 10))
            target = S.without_border(words)
            at = page + 12
            struct.pack_into('>H', bank, at, target[1])
            changes.append(dict(scene=scene['id'], page=B.BASE + page, address=B.BASE + at, before=words[1], after=target[1]))
    return (bytes((bank[k ^ 1] for k in range(len(bank)))), changes)

def audit(control, build):
    source, old = inventory(control)
    meta, new = inventory(build)
    if old.keys() != new.keys():
        raise ValueError('regional inventory changed')
    for machine, files in old.items():
        expected = dict(files)
        expected['strex_p6.bin'], changes = patch(files['strex_p6.bin'])
        spec = meta['sets'][machine]['boss_border']
        if new[machine] != expected or spec['changes'] != changes or spec['source_files'] != source['sets'][machine]['files']:
            raise ValueError('build differs outside the reserved border colour words')
    return meta

def build(a):
    meta, files = inventory(a.build)
    result = deepcopy(meta)
    a.out.mkdir(parents=True, exist_ok=False)
    for machine, members in files.items():
        changed, rows = patch(members['strex_p6.bin'])
        members = dict(members, **{'strex_p6.bin': changed})
        dest = a.out / machine
        dest.mkdir()
        for name, data in members.items():
            (dest / name).write_bytes(data)
        result['sets'][machine]['files'] = {n: sha(b) for n, b in members.items()}
        result['sets'][machine]['boss_border'] = dict(source_files=meta['sets'][machine]['files'], changes=rows, portrait_scale_unchanged=True, only_palette_words=True)
        print(machine, len(rows), 'page surrounds changed to exact black')
    (a.out / 'build.json').write_text(json.dumps(result, indent=2) + '\n')
    audit(a.build, a.out)

def self_test():
    bank = bytearray(b'\xff' * 2048)
    for k in range(8):
        at = 64 + k * 112
        struct.pack_into('>I', bank, 4 * k, B.BASE + at)
        struct.pack_into('>4H', bank, at, 200, 184 + k, 192 + k, 0)
        struct.pack_into('>I', bank, at + 48, B.BASE + 32)
        page = at + 52
        struct.pack_into('>I3H', bank, page, 0, 80, 97, 108)
        struct.pack_into('>16H', bank, page + 10, 61440, 63232, *[61440] * 14)
        struct.pack_into('>H', bank, page + 42, 1)
        struct.pack_into('>HH', bank, page + 56, 0, 0)
    raw = bytes((bank[k ^ 1] for k in range(len(bank))))
    changed, rows = patch(raw)
    assert len(rows) == 8 and sum((a != b for a, b in zip(raw, changed))) == 8
    for damaged in (changed, bytes([raw[0] ^ 1]) + raw[1:]):
        try:
            patch(damaged)
        except ValueError:
            pass
        else:
            raise AssertionError('already patched or damaged source accepted')
    print('Boss border guards PASS: only colour words change; invalid sources rejected')

def review(a):
    import numpy as np
    from PIL import Image, ImageDraw
    import portrait_gate as PG
    from preview_boss_portrait_scale import page_data, source_picture
    from rescale_pilot import method_edge_pick
    meta = audit(a.control, a.build)
    _, old = inventory(a.control)
    _, new = inventory(a.build)
    a.out.mkdir(parents=True, exist_ok=False)
    rows = []
    for machine in old:
        gfx = PG.region_of(old[machine])
        p6 = old[machine]['strex_p6.bin']
        before = bytes((p6[k ^ 1] for k in range(len(p6))))
        p6 = new[machine]['strex_p6.bin']
        after = bytes((p6[k ^ 1] for k in range(len(p6))))
        cache = {}
        for scene in B.scenes(before):
            at = scene['at']
            x, y, attr, rest = struct.unpack_from('>4H', before, at + 40)
            px, py = (x - S.SCREEN[0], y - S.SCREEN[1])
            pt = list(struct.unpack_from('>16H', before, at + 8))
            codes = {rest}
            pos = B.long(before, at + 48) - B.BASE
            while B.word(before, pos):
                codes.add(B.word(before, pos + 2))
                pos += 4
            for index, page in enumerate(scene['pages']):
                pg = page_data(before, page)
                palette = page_data(after, page)['ui']
                for code in sorted(codes):
                    if code not in cache:
                        cache[code] = method_edge_pick(source_picture(gfx, code)) < 0
                    ents = pg['before'] + [[x, y, code, attr]] + pg['after']
                    oldpic = S.compose(ents, pg['ui'], pt, gfx)
                    newpic = S.compose(ents, palette, pt, gfx)
                    mask = np.zeros((224, 384), dtype=bool)
                    mask[py - 4:py + 84, px - 4:px + 124] = True
                    mask[py:py + 80, px:px + 120] = cache[code]
                    if not np.all(oldpic[mask] == np.array(S.rgb(63232), np.uint8)):
                        raise ValueError('surround contains other visible content')
                    expected = oldpic.copy()
                    expected[mask] = 0
                    if not np.array_equal(newpic, expected):
                        raise ValueError('portrait or text changed outside the visible surround')
                    rows.append(dict(machine=machine, scene=scene['id'], page=index, picture_code=code, removed_pixels=int(mask.sum()), portrait_and_text_identical=True, passed=True))
                    if machine == 'striderua' and scene['id'] == 'desert_commander' and (index == 0) and (code == rest):
                        sheet = Image.new('RGB', (1280, 512), (24, 24, 24))
                        draw = ImageDraw.Draw(sheet)
                        for col, (label, pic) in enumerate((('Before', oldpic), ('After: portrait on black', newpic))):
                            draw.text((col * 640 + 12, 10), label, fill='white')
                            sheet.paste(Image.fromarray(pic).resize((640, 480), Image.Resampling.NEAREST), (col * 640, 32))
                        sheet.save(a.out / 'boss-border-before-after.png')
    report = dict(schema='striderex-boss-border-pixels/1', passed=True, results=rows, input_files={m: s['files'] for m, s in meta['sets'].items()}, only_reserved_palette_words_changed=True, portrait_scale_unchanged=True, hardware_review_granted=False)
    a.receipt.write_text(json.dumps(report, indent=2) + '\n')
    print('PASS:', len(rows), 'page/mouth pictures; only the surround becomes black')

def main():
    if sys.argv[1:] == ['--self-test']:
        return self_test()
    if sys.argv[1:2] == ['verify-fresh']:
        parser = argparse.ArgumentParser(description='Compare two fresh border-removal producer outputs')
        for name in ('control', 'build', 'fresh-build', 'receipt'):
            parser.add_argument('--' + name, type=Path, required=True)
        a = parser.parse_args(sys.argv[2:])
        meta = audit(a.control, a.build)
        fresh = audit(a.control, a.fresh_build)
        if meta != fresh:
            raise ValueError('fresh producer metadata or ROM inventory differs')
        report = dict(schema='striderex-boss-border-fresh/1', passed=True, input_files={m: s['boss_border']['source_files'] for m, s in meta['sets'].items()}, output_files={m: s['files'] for m, s in meta['sets'].items()}, producer_sha256=sha(Path(__file__).read_bytes()), all_metadata_and_rom_bytes_identical=True, hardware_review_granted=False)
        a.receipt.write_text(json.dumps(report, indent=2) + '\n')
        print('PASS: fresh border-removal output reproduces all ROMs and metadata')
        return
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('build', 'out'):
        parser.add_argument('--' + name, type=Path, required=True)
    if sys.argv[1:2] == ['review']:
        for name in ('control', 'receipt'):
            parser.add_argument('--' + name, type=Path, required=True)
        return review(parser.parse_args(sys.argv[2:]))
    build(parser.parse_args())
if __name__ == '__main__':
    main()
