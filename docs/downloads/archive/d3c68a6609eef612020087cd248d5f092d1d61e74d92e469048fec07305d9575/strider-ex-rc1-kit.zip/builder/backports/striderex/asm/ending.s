; Strider EX ending (D9, D9a): the arcade staff roll, extended. Included by
; ex_bank.s (after its other includes); needs REGION_EN and, on the include
; path, ending_data.inc (written by scripts/ending_ex.py).
;
; The stock roll (striderua 0xC38C-0xCB52; striderjr 0x258 lower) is kept: its
; loop scrolls SCROLL1 one pixel every 3 frames and calls the text state
; machine every 256 pixels (EX cadence; stock 248). ending_ex.py patches:
;   - the state machine's head -> jmp ending_text: writes the EX table's
;     32-row blocks into the SCROLL1 map halves in turn, with the stock block
;     writer (rows 0-31 at 0x908000, rows 32-63 at 0x90A000);
;   - the loop's object-update call -> jsr ending_frame: after the replaced
;     call, counts the loop's frames and runs the still cuts (fade to black over
;     END_FADE frames, swap, fade back in), the sky pan and, in the stock fade
;     out (phase 4), the brightness of the EX SCROLL2 palettes; it also spawns
;     the glider on the frame the stock roll does (its state 2 ran at 248 px,
;     the stock cadence), so the arcade part stays frame-identical to stock;
;   - the airship wake animation's head -> jmp ending_water: off once the
;     first PC Engine still shows.
; The first cut also ends the airship's objects (Hiryu, the glider) and
; clears the wake. A still is SCROLL3 map cols 5-12 x rows 58-61 (palette 0;
; the stock roll fades it in its phase 4) plus a SCROLL2 overlay, cols 10-21 x
; rows 52-59, with a black mask in cols 0-9 and 22-23 (SCROLL2 is above
; SCROLL3 and below the text), so the panning sky shows only in the window.
;
; Work RAM from 0xFFFA00: 16 bytes of state, then EF_SNAP (END_FADEW words;
; 128 with 5 SCROLL2 palettes: up to 0xFFFB0F). The game leaves 0xFFC800 up
; alone, and the cinematic player (and its captions, 0xFFF980) is not running
; during the ending.

END_PHASE  equ -$7324                   ; (a5) roll phase: 0 fade in, 2 hold, 4 fade out
END_TEXT   equ -$7323                   ; (a5) the stock text state byte, here the block index
END_S3X    equ -$73C4                   ; (a5) SCROLL3 x shadow (the VBlank writes it two frames on)
END_OBJS   equ -$2126                   ; (a5) 20 objects, 0x40 bytes each, byte 0 = active
EF         equ $FFFA00
EF_FRAME   equ EF+$00                   ; word: roll loop frames (1 = first)
EF_CUT     equ EF+$02                   ; word: next cut
EF_ON      equ EF+$04                   ; word: a PC Engine still has been shown
EF_PAN     equ EF+$06                   ; long: next pan entry, 0 = no pan
EF_SNAP    equ EF+$10                   ; END_FADEW words: the fade set's full colors

; -------------------------------------------------------------- text blocks
ending_text:
        moveq   #0,d0
        move.b  END_TEXT(a5),d0
        cmp.w   #END_NBLOCKS,d0
        bcc.s   .done
        addq.b  #1,END_TEXT(a5)
        tst.w   d0
        bne.s   .w
        clr.l   EF_FRAME                ; the roll starts: EF_FRAME, EF_CUT
        clr.w   EF_ON
        clr.l   EF_PAN
.w:     move.w  d0,-(sp)
        lsl.w   #2,d0
        lea     end_blocks(pc),a1
        move.l  0(a1,d0.w),a1
        lea     $908000,a2
        btst    #2,d0                   ; odd block: the lower half of the map
        beq.s   .e
        lea     $90A000,a2
.e:     jsr     END_WRITER
        move.w  (sp)+,d0
.done:  rts

; -------------------------------------------------------------- wake animation
ending_water:
        tst.w   EF_ON
        bne.s   .off
        move.w  $201E(a5),d0            ; the replaced instructions
        add.w   d0,d0
        jmp     END_WATER_RET
.off:   rts

; -------------------------------------------------------------- every roll frame
ending_frame:
        addq.w  #1,EF_FRAME
        cmp.w   #END_SPAWN_F,EF_FRAME   ; the glider, when the stock 248-px cadence spawned it
        bne.s   .u                      ; (stock: after block 2, at the end of the frame before)
        jsr     END_SPAWN
.u:     jsr     END_OBJUPD              ; the replaced call
        movem.l d0-d4/a0-a3,-(sp)
        move.w  EF_CUT,d0
        lsl.w   #2,d0
        lea     end_cuts(pc),a0
        move.w  0(a0,d0.w),d1           ; swap frame, $FFFF = none
        cmp.w   #$FFFF,d1
        beq.s   .pan
        move.w  EF_FRAME,d2
        sub.w   d1,d2                   ; frames from the swap
        cmp.w   #-END_FADE,d2
        blt.s   .pan
        cmp.w   #END_FADE,d2
        bgt.s   .pan
        bne.s   .nf
        addq.w  #1,EF_CUT               ; the last fade-in frame
.nf:    cmp.w   #-END_FADE,d2
        bne.s   .ns
        bsr     end_snapshot
.ns:    tst.w   d2
        bne.s   .lv
        move.w  2(a0,d0.w),d0
        bsr     end_install
.lv:    move.w  d2,d3
        bpl.s   .p
        neg.w   d3
.p:     bsr     end_fade
.pan:   move.l  EF_PAN,d0
        beq.s   .mirror
        move.l  d0,a0
        move.w  EF_FRAME,d1
.pl:    move.w  (a0),d2
        cmp.w   #$FFFF,d2
        beq.s   .pe
        cmp.w   d1,d2
        bhi.s   .pe
        move.w  2(a0),END_S3X(a5)
        addq.l  #4,a0
        bra.s   .pl
.pe:    move.l  a0,EF_PAN
.mirror:
        cmp.b   #4,END_PHASE(a5)        ; stock fade out: SCROLL3 palette 0 sets the level
        bne.s   .out
        tst.w   EF_ON
        beq.s   .out
        move.w  $914C00,d0
        and.w   #$F000,d0
        lea     $914820,a0              ; SCROLL2 palettes 1..END_NS2PAL
        move.w  #END_NS2PAL*16-1,d1
.m:     move.w  (a0),d2
        and.w   #$0FFF,d2
        or.w    d0,d2
        move.w  d2,(a0)+
        dbra    d1,.m
.out:   movem.l (sp)+,d0-d4/a0-a3
        rts

; the fade set: SCROLL3 palette 0, OBJ palette 0x0E, SCROLL2 palettes 0..END_NS2PAL
end_fadeset:
        dc.l    $914C00
        dc.w    16-1
        dc.l    $9141C0
        dc.w    16-1
        dc.l    $914800
        dc.w    (END_NS2PAL+1)*16-1
        dc.l    0

end_snapshot:                           ; palette RAM -> EF_SNAP
        movem.l d0-d1/a0-a2,-(sp)
        lea     end_fadeset(pc),a2
        lea     EF_SNAP,a1
.s:     move.l  (a2)+,d0
        beq.s   .x
        move.l  d0,a0
        move.w  (a2)+,d1
.w:     move.w  (a0)+,(a1)+
        dbra    d1,.w
        bra.s   .s
.x:     movem.l (sp)+,d0-d1/a0-a2
        rts

end_fade:                               ; d3 = level 0 (black) - 15 (full): EF_SNAP scaled -> palette RAM
        movem.l d0-d4/a0-a3,-(sp)
        lea     EF_SNAP,a0
        lea     end_scale(pc),a1
        lsl.w   #4,d3
        add.w   d3,a1
        lea     end_fadeset(pc),a2
.s:     move.l  (a2)+,d0
        beq.s   .x
        move.l  d0,a3
        move.w  (a2)+,d1
.w:     move.w  (a0)+,d0
        move.w  d0,d2
        and.w   #$F000,d2
        move.w  d0,d4
        lsr.w   #8,d4
        and.w   #15,d4
        move.b  0(a1,d4.w),d4
        lsl.w   #8,d4
        or.w    d4,d2
        move.w  d0,d4
        lsr.w   #4,d4
        and.w   #15,d4
        move.b  0(a1,d4.w),d4
        lsl.w   #4,d4
        or.w    d4,d2
        move.w  d0,d4
        and.w   #15,d4
        move.b  0(a1,d4.w),d4
        or.w    d4,d2
        move.w  d2,(a3)+
        dbra    d1,.w
        bra.s   .s
.x:     movem.l (sp)+,d0-d4/a0-a3
        rts

end_install:                            ; d0 = still 0-3, at black
        movem.l d0-d2/a0-a2,-(sp)
        lsl.w   #4,d0
        lea     end_stills(pc),a2
        add.w   d0,a2
        move.l  (a2)+,a0                ; SCROLL3 codes: 8 columns x 4 rows, palette 0
        lea     $9138A8,a1
        moveq   #8-1,d1
.c3:    moveq   #4-1,d2
        move.l  a1,-(sp)
.r3:    move.w  (a0)+,(a1)+
        clr.w   (a1)+
        dbra    d2,.r3
        move.l  (sp)+,a1
        lea     $20(a1),a1
        dbra    d1,.c3
        move.l  (a2)+,a0                ; SCROLL2 (code, attribute): 24 columns x 8 rows
        lea     $90F010,a1
        moveq   #24-1,d1
.c2:    moveq   #8-1,d2
        move.l  a1,-(sp)
.r2:    move.l  (a0)+,(a1)+
        dbra    d2,.r2
        move.l  (sp)+,a1
        lea     $40(a1),a1
        dbra    d1,.c2
        move.l  (a2)+,a0                ; fade-set targets
        lea     EF_SNAP,a1
        move.w  #END_FADEW-1,d1
.t:     move.w  (a0)+,(a1)+
        dbra    d1,.t
        move.l  (a2)+,EF_PAN
        clr.w   END_S3X(a5)
        tst.w   EF_ON
        bne.s   .x
        move.w  #1,EF_ON                ; the first still: the airship's objects end
        lea     END_OBJS(a5),a0
        moveq   #20-1,d1
.k:     clr.b   (a0)
        lea     $40(a0),a0
        dbra    d1,.k
.x:     movem.l (sp)+,d0-d2/a0-a2
        rts

        even
        include "ending_data.inc"
        even
