"""Run the focused Strider EX private-kit checks and retain a portable receipt."""
import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]

def sha(path):
    with path.open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()

def required_jobs(suite):
    if suite == 'fixes':
        return {f'{name}_{region}' for name in ('select_default', 'select_test', 'ending') for region in ('us', 'jp')}
    if suite == 'audio':
        return {'nopack', 'intro_us', 'intro_jp', 'measure'}
    names = {'nopack', 'start_flow', 'skip', 'pacing'}
    names |= {f'{name}_{region}' for name in ('select_test', 'ending', 'intro', 'boss', 'sfx', 'desert_flow', 'desert_progression', 'desert_actors') for region in ('us', 'jp')}
    names |= {f'ex_{region}_{stage}' for region in ('us', 'jp') for stage in range(5)}
    names |= {f'subtitle_{stage}' for stage in range(6)}
    return names

def combine_receipts():
    p = argparse.ArgumentParser(description='Apply passing focused follow-ups to a complete suite receipt.')
    p.add_argument('--base', type=Path, required=True)
    p.add_argument('--followup', type=Path, action='append', required=True)
    p.add_argument('--out', type=Path, required=True)
    a = p.parse_args(sys.argv[2:])
    report = json.loads(a.base.read_text())
    results = {r['name']: r for r in report['results']}
    if set(results) != required_jobs(report['suite']):
        p.error('base receipt is not a completed full suite')
    report['base_receipt_sha256'] = sha(a.base)
    report['superseded_failures'] = []
    report['followups'] = []
    for path in a.followup:
        followup = json.loads(path.read_text())
        if followup['suite'] != report['suite'] or followup['inputs'] != report['inputs']:
            p.error('follow-up suite or input identities differ')
        if not followup['passed'] or any((not r['passed'] or r['exit_code'] for r in followup['results'])):
            p.error('follow-up has not passed')
        replaced = []
        for row in followup['results']:
            old = results.get(row['name'])
            if old is None or old['passed']:
                p.error('follow-up must replace a failed required job')
            report['superseded_failures'].append(old)
            results[row['name']] = row
            replaced.append(row['name'])
        report['followups'].append(dict(receipt_sha256=sha(path), replaced=sorted(replaced)))
    report['results'] = sorted(results.values(), key=lambda r: r['name'])
    report['passed'] = all((r['passed'] and r['exit_code'] == 0 for r in report['results']))
    with a.out.open('x') as f:
        f.write(json.dumps(report, indent=2) + '\n')
    print('PASS' if report['passed'] else 'FAIL', report['suite'])
    return 0 if report['passed'] else 1

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--suite', choices=['fixes', 'audio', 'combined'], required=True)
    p.add_argument('--source', type=Path, default=ROOT, help='source tree used by every gate (default: this checkout)')
    for name in ('build', 'runtime', 'hbmame', 'rom-dir', 'census', 'pack', 'workdir'):
        p.add_argument('--' + name, type=Path, required=True)
    for name in ('test-build', 'control', 'copyright-control', 'start-control', 'intro-control', 'handback-control', 'timing-runtime', 'portraits', 'pce-sfx', 'desert-census'):
        p.add_argument('--' + name, type=Path)
    p.add_argument('--mame', default='mame')
    p.add_argument('--jobs', type=int, default=3)
    p.add_argument('--only', help='comma-separated job names, for a fresh focused follow-up')
    a = p.parse_args()
    a.workdir = a.workdir.resolve()
    a.workdir.mkdir(parents=True, exist_ok=False)
    common = ['--runtime', a.runtime, '--hbmame', a.hbmame, '--rom-dir', a.rom_dir]
    jobs = []

    def add(name, script, args=(), build=None, common_args=True, work=True):
        cmd = [sys.executable, a.source / 'backports/striderex/scripts' / script, *args]
        if build is not False:
            cmd += ['--build', build or a.build]
        if common_args:
            cmd += common
        if work:
            cmd += ['--workdir', a.workdir / name]
        jobs.append((name, [str(x) for x in cmd]))
    if a.suite in ('fixes', 'combined'):
        if not a.test_build:
            p.error('fixes and combined need --test-build')
        for region, set_name in [('us', 'striderus01'), ('jp', 'striderjs01')]:
            if a.suite == 'fixes':
                add('select_default_' + region, 'stage_select_gate.py', ['--set', set_name, '--census', a.census, '--jobs', '1'])
            add('select_test_' + region, 'stage_select_gate.py', ['--set', set_name, '--census', a.census, '--jobs', '1'], a.test_build)
            add('ending_' + region, 'ending_ex.py', ['gate', '--set', set_name, '--census', a.census], a.test_build)
    if a.suite in ('audio', 'combined'):
        if not all((a.control, a.intro_control, a.handback_control)):
            p.error('audio and combined need --control, --intro-control, --handback-control')
        add('nopack', 'nopack_intros.py', ['gate', '--control', a.control, '--jobs', '2'])
        for region, set_name in [('us', 'striderus01'), ('jp', 'striderjs01')]:
            add('intro_' + region, 'intro_gate.py', ['gate', '--set', set_name, '--control', a.intro_control, '--handback-control', a.handback_control, '--jobs', '1'])
        if a.suite == 'audio':
            add('measure', 'nopack_intros.py', ['measure', '--rom-dir', a.rom_dir, '--mame', a.mame], common_args=False)
    if a.suite == 'combined':
        if not all((a.copyright_control, a.start_control, a.portraits, a.pce_sfx, a.timing_runtime, a.desert_census)):
            p.error('combined needs the copyright/start controls, portraits, pce-sfx, timing-runtime')
        add('start_flow', 'start_flow_gate.py', ['gate', '--control', a.start_control, '--copyright-control', a.copyright_control, '--census', a.census, '--mame', a.mame])
        add('skip', 'ex_gate.py', ['skip', '--control', a.intro_control, '--pack', a.pack])
        for region, set_name in [('us', 'striderus01'), ('jp', 'striderjs01')]:
            for stage in range(5):
                add(f'ex_{region}_{stage}', 'ex_gate.py', ['--set', set_name, '--stage', stage, '--pack', a.pack])
            add('boss_' + region, 'boss_scene_gate.py', ['--set', set_name, '--timing-runtime', a.timing_runtime, '--once', '--jobs', '1', '--pack', a.pack, '--portraits', a.portraits], a.test_build)
            add('sfx_' + region, 'sfx_gate.py', ['census', '--set', set_name, '--capture', a.pce_sfx, '--pack', a.pack], a.test_build)
            add('desert_flow_' + region, 'desert_gate.py', ['flow', '--set', set_name, '--jobs', '1'])
            add('desert_progression_' + region, 'desert_gate.py', ['progression', '--set', set_name])
            add('desert_actors_' + region, 'desert_gate.py', ['actors', '--set', set_name, '--jobs', '1', '--desert-census', a.desert_census])
        for stage in range(6):
            add(f'subtitle_{stage}', 'subtitle_ex.py', ['gate', '--stage', stage])
        add('pacing', 'caption_pacing.py', ['check', '--json', a.workdir / 'pacing.json'], common_args=False, work=False)
    if {name for name, _ in jobs} != required_jobs(a.suite):
        raise RuntimeError('Suite definition differs from its required job contract')
    if a.only:
        only = set(a.only.split(','))
        missing = only - {n for n, _ in jobs}
        if missing:
            p.error('unknown jobs: ' + ', '.join(sorted(missing)))
        jobs = [(n, c) for n, c in jobs if n in only]
    aliases = {str(ROOT): '<source>', sys.executable: '<python>'}
    if Path(a.mame).is_absolute():
        aliases[a.mame] = '<mame>'
    for name, value in vars(a).items():
        if isinstance(value, Path):
            aliases[str(value.resolve())] = '<' + name.replace('_', '-') + '>'

    def portable(value):
        for source, label in sorted(aliases.items(), key=lambda x: -len(x[0])):
            value = value.replace(source, label)
        return value
    inputs = {}
    for name in ('build', 'test_build', 'control', 'copyright_control', 'intro_control', 'handback_control', 'start_control'):
        value = getattr(a, name)
        if value:
            bj = json.loads((value / 'build.json').read_text())
            for parent, spec in bj['sets'].items():
                for filename, expected in spec['files'].items():
                    if sha(value / parent / filename) != expected:
                        raise SystemExit(f'{name}: build member changed: {parent}/{filename}')
            inputs[name] = {parent: spec['files'] for parent, spec in bj['sets'].items()}
    inputs['pack_sha256'] = sha(a.pack)
    for name in ('runtime', 'timing_runtime'):
        value = getattr(a, name)
        if value:
            r = json.loads((value / 'runtime.json').read_text())
            if sha(Path(r['binary'])) != r['binary_sha256']:
                raise SystemExit(name + ': runtime hash changed')
            inputs[name] = {k: r[k] for k in ('source_revision', 'binary_sha256', 'board_wait')}
    report = dict(suite=a.suite, inputs=inputs, required_jobs=sorted(required_jobs(a.suite)), results=[], passed=False)

    def run(job):
        name, cmd = job
        start = time.monotonic()
        print('START', name, flush=True)
        with (a.workdir / (name + '.log')).open('w') as log:
            r = subprocess.run(cmd, cwd=a.source, stdout=log, stderr=subprocess.STDOUT, env=dict(os.environ, SDL_VIDEODRIVER='dummy', SDL_AUDIODRIVER='dummy'))
        result = dict(name=name, command=portable(' '.join(cmd)), exit_code=r.returncode, seconds=round(time.monotonic() - start, 1), passed=r.returncode == 0)
        print('PASS' if result['passed'] else 'FAIL', name, result['seconds'], flush=True)
        return result
    with ThreadPoolExecutor(a.jobs) as pool:
        for f in as_completed([pool.submit(run, job) for job in jobs]):
            report['results'].append(f.result())
            (a.workdir / 'qualification.json').write_text(json.dumps(report, indent=2) + '\n')
    report['results'].sort(key=lambda r: r['name'])
    report['passed'] = bool(jobs) and all((r['passed'] for r in report['results']))
    (a.workdir / 'qualification.json').write_text(json.dumps(report, indent=2) + '\n')
    print('PASS' if report['passed'] else 'FAIL', a.suite, flush=True)
    return 0 if report['passed'] else 1
if __name__ == '__main__':
    sys.exit(combine_receipts() if sys.argv[1:2] == ['combine'] else main())
