"""Focused final-combination boot, platform, pole and arranged-pack smoke."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import json
from pathlib import Path
import boss_voice_gate as V
import boss_scene_binary as BB
import desert_gate as G
import gameplay_music_gate as GM

def gate(a):
    work = a.workdir.resolve()
    work.mkdir(parents=True, exist_ok=False)
    meta, files = V.inventory(a.build)
    expected = {m: s['files'] for m, s in meta['sets'].items()}
    rt = json.loads((a.runtime / 'runtime.json').read_text())
    binary = Path(rt['binary'])
    if V.sha(binary.read_bytes()) != rt['binary_sha256']:
        raise ValueError('runtime differs')
    sets = {}
    for m, f in files.items():
        name = 'striderus01' if m == 'striderua' else 'striderjs01'
        roms = G.stage_sets(a.build.resolve(), name, a.hbmame, a.rom_dir.resolve(), work / 'sets' / m)
        hashes = {V.sha(p.read_bytes()) for p in (roms / name).iterdir() if p.is_file()}
        if not set(expected[m].values()) <= hashes:
            raise ValueError('staging lost an exact candidate member')
        sets[m] = (roms, name)
        raw = f['strex_p6.bin']
        bank = bytes((raw[i ^ 1] for i in range(len(raw))))
        scene = BB.scenes(bank)[-1]
        if scene['total'] != 698 or [BB.word(bank, scene['pages'][0] + i) for i in (4, 6, 8)] != [262, 279, 290]:
            raise ValueError('final commander timing differs')
    pack_receipt = work / 'music.json'
    GM.gate(argparse.Namespace(pack=a.pack, control=a.control_pack, receipt=pack_receipt))

    def run(job):
        m, case = job
        roms, name = sets[m]
        out = work / (m + '_' + case)
        if case == 'boot':
            env = {}
            n = 600
        elif case == 'catch':
            n = 1260
            env = dict(G.debug_env(5, 1, n, inputs=False), MOTION='1', STREX_INPUTS='450-940:P1_JOYSTICK_RIGHT;960-1260:P1_JOYSTICK_UP;960-974:P1_BUTTON2')
        else:
            n = 2350
            env = dict(G.debug_env(5, 3, n, inputs=False), MOTION='1', CLIMB='1', STREX_INPUTS='450-2350:P1_JOYSTICK_RIGHT;1800-2099@100/14:P1_BUTTON2')
        G.run(binary, roms, name, out, env, n)
        result = dict(machine=m, case=case, frames=n, exit_code=0, passed=True)
        if case != 'boot':
            rows = G.read_motion(out)
            if case == 'catch':
                caught = [r for r in rows if r['st'] == '8']
                if len(caught) < 240 or any((int(r['hy']) != 1198 or not 840 <= int(r['hx']) < 936 for r in caught)):
                    raise ValueError('final platform catch failed')
                result['grip_frames'] = len(caught)
            else:
                held = rows[2199:2350]
                if any(((int(r['st']), int(r['hx']), int(r['hy'])) != (4, 6194, 1631) for r in held)):
                    raise ValueError('final natural pole contact failed')
                result['stable_contact_frames'] = len(held)
            result['motion_sha256'] = V.sha((out / 'motion.tsv').read_bytes())
        print('PASS final', m, case, flush=True)
        return result
    with ThreadPoolExecutor(2) as ex:
        checks = list(ex.map(run, [(m, c) for m in files for c in ('boot', 'catch', 'pole')]))
    report = dict(schema='striderex-desert-delivery-smoke/1', passed=True, input_files=expected, pack_sha256=V.sha(a.pack.read_bytes()), pack_gate=json.loads(pack_receipt.read_text()), runtime={k: rt[k] for k in ('binary_sha256', 'source_revision', 'board_wait')}, results=[dict(machine=m, passed=True, checks=[r for r in checks if r['machine'] == m]) for m in files], hardware_review_granted=False, scope='focused private development qualification')
    a.receipt.write_text(json.dumps(report, indent=2) + '\n')
if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    for n in ('build', 'pack', 'control-pack', 'runtime', 'hbmame', 'rom-dir', 'workdir', 'receipt'):
        p.add_argument('--' + n, type=Path, required=True)
    gate(p.parse_args())
