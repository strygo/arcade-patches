; Strider: keep the layers off until a respawn's area rebuild has finished.
;
; Stock bug (PHASE0_FINDINGS.md, "Arcade respawn defect"): each stage's
; respawn routine (five per region, same shape) calls the checkpoint loader,
; which sets the layer-control shadow 0xFF0C74 from the area's restart
; record at once, and only then rebuilds SCROLL1, SCROLL2 and SCROLL3 over
; the next frames. So ~8 frames show half-built maps at the old scroll
; positions.
;
; The fix changes nothing that runs in a normal frame. Two instructions of
; each respawn routine are replaced:
;   jsr <SCROLL1 rebuild>.l         -> jsr respawn_hold.l
;       stash the shadow the loader just set, hide everything (sprites
;       too), then run the SCROLL1 rebuild as before;
;   move.w #1,d0 / jsr $7de.w       -> jsr respawn_show.l / nop
;       the routine's one-frame wait after the SCROLL3 rebuild, then
;       start the reveal task (the stock code that follows sets the
;       priority masks and ends the routine, as before).
; The stash is a word of graphics RAM the game never writes (0x900800-
; 0x903FFF is unused; MEASURED by a write census of every stage).
;
; REVEAL (the reveal task's wait, in frames) and SLOT (a task slot the game
; never uses, gated) are set by respawn_fix.py.
;
; Assembled once per region: SCROLL1 is the region's SCROLL1 rebuild
; routine (striderua 0x1C1FC, striderjr 0x1BF44). A5 = 0xFFFF8000.

LAYER_SH equ -$738c                     ; 0xFF0C74 layer-control shadow
STASH    equ $903FFE                    ; unused graphics RAM
SLEEP    equ $7DE                       ; the game's task wait (d0 = frames), both regions
START    equ $758                       ; the game's task start (d0 = slot offset, a0 = entry)
EXIT     equ $796                       ; the game's task end
HIDE     equ $1540                      ; every order slot SCROLL1, no layer enabled: no sprites either

        org     $FFE00

respawn_hold:
        move.w  LAYER_SH(a5),STASH      ; what the loader set
        move.w  #HIDE,LAYER_SH(a5)      ; nothing shows during the rebuild
        jmp     SCROLL1                 ; the replaced call (returns to the routine)

respawn_show:
        move.w  #1,d0                   ; the replaced wait
        jsr     SLEEP
        move.w  #SLOT,d0                ; the layers come on later, from a task of their own,
        lea     reveal(pc),a0           ; so the respawn routine keeps its stock timing
        jsr     START
        rts

; The game draws the HUD and the sprites over the first frames after the
; respawn routine ends; reveal waits for them, so the whole scene appears at
; once (as on the PC Engine), then ends. It costs nothing outside a respawn.
reveal:
        move.w  #REVEAL,d0
        jsr     SLEEP
        cmpi.w  #HIDE,LAYER_SH(a5)      ; if the game set the layers meanwhile
        bne.s   .done                   ; (Siberia does), its value stands
        move.w  STASH,LAYER_SH(a5)      ; the area is complete: layers on
.done:  jsr     EXIT
