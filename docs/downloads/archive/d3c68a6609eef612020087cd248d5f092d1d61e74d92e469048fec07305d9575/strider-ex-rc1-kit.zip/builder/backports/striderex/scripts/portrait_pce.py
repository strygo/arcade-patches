"""W3b / D8: measure every PC Engine boss portrait moment (P0.3 completion)."""
import argparse
import hashlib
import json
import re
import subprocess
import sys
import wave
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import numpy as np
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import huc6280_dis as H
import pce_portrait_census as PC
import pce_vdc as P
ROOT = HERE.parents[2]
MANIFEST = ROOT / 'backports/striderex/manifests/portraits.json'
CAPTURE = HERE / 'run_pce_scene_capture.py'
NEW_GAME = '300-310:P1_START;3700-3710:P1_START;4000-4010:P1_START'
PORTRAIT_TYPE = 107
DUMP_BASE = 851968
MAP = {16384: 104, 24576: 105, 32768: 106, 40960: 107}
CALLS = {31037: 'spawn_actor', 31188: 'spawn_object', 29886: 'camera_bounds', 29935: 'trigger', 29752: 'camera_settled', 31697: 'load_sprite_sets', 30382: 'once_state', 30369: 'set_once_state', 32878: 'call_806E', 32845: 'call_804D', 32877: 'call_806D'}
STATE, DELAY = (13322, 13324)
BRANCHES = {'bpl', 'bmi', 'bvc', 'bvs', 'bcc', 'bcs', 'bne', 'beq'}
REC = 12 + 8192 + 8192
ACTORS, ACTOR_SIZE = (3584, 48)
ADPCM_RATE = 32000

def manifest():
    return json.loads(MANIFEST.read_text())['pce']

def capture(a):
    rows = [r for r in manifest() if not a.only or r['id'] in a.only.split(',')]
    work = a.workdir.resolve()
    work.mkdir(parents=True, exist_ok=bool(a.only))

    def one(r):
        f0, f1 = r['window']
        sched = PC.schedule(r['end']) if r['inputs'] == 'census' else NEW_GAME
        cmd = [sys.executable, str(CAPTURE), '--outdir', str(work / r['id']), '--cdrom', str(a.cue), '--rompath', str(a.rompath), '--schedule', sched, '--window', f'{f0}:{f1}:1', '--end', str(r['end']), '--pce-start-stage', str(r['chapter']), '--pce-first-checkpoint', str(r['checkpoint']), '--pce-hold', 'timer', '--pce-hold', 'lives', '--ram-record', f"6000:{r['end'] - 2}", '--ram-record-extra', '10c000-10dfff', '--write-log', f"6000:{r['end'] - 2}", '--write-log-range', '1ff800-1ff80f']
        for x in r['pokes']:
            cmd += ['--poke', x]
        return (r['id'], subprocess.run(cmd, capture_output=True, text=True).returncode)
    with ThreadPoolExecutor(a.jobs) as ex:
        bad = [i for i, code in ex.map(one, rows) if code]
    if bad:
        sys.exit(f'portrait_pce: capture failed for {bad}')
    return 0

def spawn_record(read, at):
    b = [read(at + i) for i in range(8)]
    return dict(x=b[0] | b[1] << 8, y=b[2] | (b[3] & 63) << 8, once_id=b[5] if b[5] < 128 else None, type=b[6], param=b[7])

def words(read, at, n):
    return [read(at + 2 * i) | read(at + 2 * i + 1) << 8 for i in range(n)]

def dispatchers(dump):
    """(table address, [state entries]) of every `lda $340A / asl / tax / jmp (t,x)` in banks 0x6A/0x6B."""
    read = H.reader(dump, DUMP_BASE, MAP)
    out = []
    for m in re.finditer(b'\\xad\\x0a\\x34\\x0a\\xaa\\x7c(..)', dump, re.S):
        phys = DUMP_BASE + m.start()
        bank = phys >> 13
        if bank not in (106, 107):
            continue
        table = m.group(1)[0] | m.group(1)[1] << 8
        first = read(table) | read(table + 1) << 8
        n = (first - table) // 2 if table < first <= table + 64 else 0
        if n:
            out.append((table, [read(table + 2 * i) | read(table + 2 * i + 1) << 8 for i in range(n)]))
    return (out, read)

def walk(read, entry, stops):
    """Events of one state in address order (every path from entry, `bra` followed)."""
    seen, todo, ev = (set(), [entry], [])
    while todo:
        pc = todo.pop()
        regs = {}
        while pc not in seen and (pc == entry or pc not in stops):
            seen.add(pc)
            text, n, target = H.decode(read, pc)
            name = text.split()[0]
            code = read(pc)
            mode = H.OPS.get(code, ('', H.IMP))[1]
            if name in ('lda', 'ldx') and mode == H.IMM:
                regs[name[-1]] = read(pc + 1)
            elif name == 'cla':
                regs['a'] = 0
            elif name in ('sta', 'stz') and target in (STATE, DELAY):
                v = 0 if name == 'stz' else regs.get('a')
                ev.append((pc, 'set_state' if target == STATE else 'delay', v))
            elif name == 'sta' and target is not None and (mode in (H.ZP, H.ABS)):
                regs[target] = regs.get('a')
            elif name == 'cmp' and mode == H.IMM and ev and (ev[-1][1] == 'once_state') and (ev[-1][3] is None):
                ev[-1] = ev[-1][:3] + (read(pc + 1),)
            if name == 'jsr':
                kind = CALLS.get(target, f'call_{target:04X}')
                ptr = lambda lo, hi: (regs.get(lo) or 0) | (regs.get(hi) or 0) << 8
                if kind in ('spawn_actor', 'spawn_object'):
                    ev.append((pc, kind, spawn_record(read, ptr(98, 99))))
                elif kind in ('camera_bounds', 'trigger'):
                    y0, y1, x0, x1 = words(read, ptr(96, 97), 4)
                    ev.append((pc, kind, dict(y=[y0, y1], x=[x0, x1])))
                elif kind == 'once_state':
                    ev.append((pc, kind, regs.get('x'), None))
                elif kind == 'set_once_state':
                    ev.append((pc, kind, dict(once_id=regs.get('x'), value=regs.get('a'))))
                elif kind in ('call_806E', 'call_804D'):
                    ev.append((pc, kind, regs.get('a')))
                else:
                    ev.append((pc, kind, None))
                regs = {}
            if name in BRANCHES or mode == H.ZPR:
                todo.append(target)
            if name == 'bra':
                pc = target
                continue
            if name in ('rts', 'rti', 'jmp'):
                break
            pc += n
    return sorted(ev)

def static_portraits(dump):
    """[{table, state, spawn, before: [events of earlier states], after: [events of the next state]}]."""
    found = []
    tables, read = dispatchers(dump)
    for table, entries in tables:
        stops = set(entries)
        states = [walk(read, e, stops - {e}) for e in entries]
        for k, ev in enumerate(states):
            for pc, kind, *rest in ev:
                if kind == 'spawn_actor' and rest[0]['type'] == PORTRAIT_TYPE:
                    found.append(dict(table=f'0x{table:04X}', state=k, site=f'0x{pc:04X}', spawn=rest[0], states={j: [describe(e) for e in states[j]] for j in range(max(0, k - 2), min(len(states), k + 2))}))
    return found

def describe(e):
    pc, kind, *rest = e
    v = rest[0] if len(rest) == 1 else rest
    if kind == 'once_state':
        v = dict(once_id=rest[0], waits_for=rest[1])
    if kind in ('spawn_actor', 'spawn_object'):
        v = dict(v, type=f"0x{v['type']:02X}")
    return dict(at=f'0x{pc:04X}', op=kind, arg=v)

def cmd_static(a):
    rows = manifest()
    want = {(r['chapter'], r['param']) for r in rows}
    got, report = (set(), {})
    for r in rows:
        run = a.capture / r['id']
        dump = (run / f"pce_{r['end']:04d}_limit_ram_0d0000.bin").read_bytes()
        if r['chapter'] in report:
            continue
        sites = static_portraits(dump)
        report[r['chapter']] = sites
        got |= {(r['chapter'], s['spawn']['param']) for s in sites}
    chapters = {r['chapter'] for r in rows}
    out = dict(chapters=sorted(chapters), spawns={c: s for c, s in report.items()}, manifest_matches=got == want, missing_from_manifest=sorted(got - want), missing_in_code=sorted(want - got))
    print(json.dumps(out, indent=1))
    if a.out:
        a.out.write_text(json.dumps(out, indent=1) + '\n')
    return 0 if got == want else 1

def ram_record(run):
    b = np.fromfile(run / 'ram_record.bin', np.uint8)
    b = b[:len(b) // REC * REC].reshape(-1, REC)
    return (b[:, :4].copy().view('<u4')[:, 0].astype(int), b[:, 12:12 + 8192], b[:, 12 + 8192:])

def portrait_sprites(d):
    """(entries, top, left, picture as VCE indices with -1 transparent) of the portrait in a dump, or None."""
    if int(d['reg'][12]) != PC.GAMEPLAY_VPR:
        return None
    objs = P.sprite_objects(d)
    groups = {}
    for o in objs:
        groups.setdefault(o[4] & 15, []).append(o)
    for pal, g in groups.items():
        if min((o[0] for o in g)) != 0 or len(g) < 6:
            continue
        y0, x0 = (min((o[1] for o in g)), min((o[2] for o in g)))
        y1, x1 = (max((o[1] + o[3].shape[0] for o in g)), max((o[2] + o[3].shape[1] for o in g)))
        if (x1 - x0, y1 - y0) != (80, 80):
            continue
        img = np.full((80, 80), -1, np.int32)
        for i, t, l, im, attr in sorted(g, key=lambda o: -o[0]):
            m = im != 0
            region = img[t - y0:t - y0 + im.shape[0], l - x0:l - x0 + im.shape[1]]
            region[m] = 256 | pal << 4 | im[m]
        return (sorted((o[0] for o in g)), y0, x0, img)
    return None

def adpcm_events(run):
    """ADPCM RAM writes (frame, address, byte), playbacks and CD commands from ram_writes.txt."""
    ram, wptr, latch, ctl, rate = ({}, 0, 0, 0, 0)
    lo = hi = 0
    plays, cd = ([], [])
    start = length = 0
    for line in (run / 'ram_writes.txt').read_text().splitlines():
        f, pc, mpr, addr, data = line.split()
        f, addr, data = (int(f), int(addr, 16), int(data, 16))
        reg = addr & 15
        if reg == 8:
            lo = data
        elif reg == 9:
            hi = data
        elif reg == 10:
            ram.setdefault(wptr, []).append((f, data))
            wptr = wptr + 1 & 65535
        elif reg == 14:
            rate = data & 15
        elif reg == 13:
            latch = lo | hi << 8
            rise = data & ~ctl
            if rise & 2:
                wptr = latch if data & 1 else latch - 1 & 65535
            if rise & 8:
                start = latch
            if rise & 16:
                length = latch
            if rise & 64:
                plays.append(dict(frame=f, start=start, length=length, rate=rate, repeat=bool(data & 32)))
            if ctl & 64 and (not data & 64) and plays and ('stop' not in plays[-1]):
                plays[-1]['stop'] = f
            ctl = data
        elif reg == 1 and data in (216, 217, 218):
            cd.append(dict(frame=f, scsi=f'0x{data:02X}'))
    return (ram, plays, cd)

def msm5205(nibbles):
    steps = [int(16 * 1.1 ** i) for i in range(49)]
    adj = [-1, -1, -1, -1, 2, 4, 6, 8]
    s, idx, out = (0, 0, [])
    for n in nibbles:
        st = steps[idx]
        diff = st // 8 + (st // 4 if n & 1 else 0) + (st // 2 if n & 2 else 0) + (st if n & 4 else 0)
        s = max(-2048, min(2047, s - diff if n & 8 else s + diff))
        idx = max(0, min(48, idx + adj[n & 7]))
        out.append(s)
    return np.array(out, np.int16)

def clip(ram, play, fps=59.82):
    """The bytes a playback reads, with the frames they were written; nibbles high first."""
    rate = ADPCM_RATE // (16 - play['rate'])
    data, frames = ([], [])
    for i in range(play['length']):
        due = play['frame'] + int(2 * i / rate * fps) + 1
        hist = [w for w in ram.get(play['start'] + i & 65535, []) if w[0] <= due]
        f, b = hist[-1] if hist else (None, 0)
        data.append(b)
        frames.append(f)
    nib = [x for b in data for x in (b >> 4, b & 15)]
    return (bytes(data), msm5205(nib), frames)

def write_wav(path, pcm, rate):
    with wave.open(str(path), 'wb') as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(rate)
        w.writeframes((pcm.astype(np.int32) * 16).astype('<i2').tobytes())

def measure_one(r, run, out):
    fr, ram, act = ram_record(run)
    alive = [int(f) for f, a in zip(fr, act) if any((a[ACTORS + ACTOR_SIZE * k] == PORTRAIT_TYPE for k in range(1, 96)))]
    if not alive:
        raise SystemExit(f"{r['id']}: no portrait actor in the RAM record")
    life = [alive[0], alive[-1]]
    runs = []
    for f in alive:
        if runs and f == runs[-1][1] + 1:
            runs[-1][1] = f
        else:
            runs.append([f, f])
    first = runs[0]
    shown, pictures, pal_seq, pos, sat, seq = ([], {}, [], set(), set(), [])
    checks = {}
    writes = P.read_writes(run)
    for p in sorted(run.glob('pce_*_scene.vdc')):
        d = P.load(p)
        f = d['frame']
        got = portrait_sprites(d)
        if got is None:
            continue
        ents, top, left, img = got
        shown.append(f)
        pos.add((int(left), int(top)))
        sat.add(tuple(ents))
        key = hashlib.sha256(np.where(img < 0, 0, img & 15).astype(np.uint8).tobytes() + (img < 0).tobytes()).hexdigest()[:16]
        pictures.setdefault(key, dict(first=f, last=f, frames=0, img=img, pal=int(img[img >= 0][0] >> 4 & 15), rgb=P.pal_rgb(d['pal'])[np.clip(img, 0, 511)]))
        pictures[key]['last'] = f
        pictures[key]['frames'] += 1
        seq.append((f, key))
        sub = img[img >= 0][0] >> 4 & 31
        cols = tuple((int(c) for c in d['pal'][sub * 16:(sub + 1) * 16]))
        if not pal_seq or pal_seq[-1][1] != cols:
            pal_seq.append((f, cols))
        png = p.with_suffix('.png')
        if png.exists():
            shot, _ = P.native(png, P.geometry(d)['width'])
            want = P.pal_rgb(d['pal'])[P.screen_image(d, writes=writes.get(f, []), rows=shot.shape[0])]
            k = np.arange(shot.shape[0]) + P.SHOT_RASTER - P.display_raster(d)
            rows = np.where((k >= top) & (k < top + 80))[0]
            box = (slice(rows[0], rows[-1] + 1), slice(max(left, 0), left + 80))
            checks[f] = int((want[box] != shot[box]).any(-1).sum())
    if not shown:
        raise SystemExit(f"{r['id']}: no portrait sprites in the dumps")
    spans = []
    for f in shown:
        if spans and f == spans[-1][1] + 1:
            spans[-1][1] = f
        else:
            spans.append([f, f])
    exact = sum((1 for v in checks.values() if v == 0))
    i0, i1 = (int(np.searchsorted(fr, spans[0][0])), int(np.searchsorted(fr, spans[0][1])))
    w = lambda a, o: int(a[o]) | int(a[o + 1]) << 8
    hiryu = {(w(act[i], ACTORS + 6), w(act[i], ACTORS + 4)) for i in range(i0, i1)}
    ram_bytes, plays, cd = adpcm_events(run)
    clips = []
    for k, pl in enumerate(plays):
        if not first[0] - 5 <= pl['frame'] <= first[1] + 5:
            continue
        data, pcm, wf = clip(ram_bytes, pl)
        rate = ADPCM_RATE // (16 - pl['rate'])
        name = f"{r['id']}_adpcm{k}.wav"
        write_wav(out / name, pcm, rate)
        rms = float(np.sqrt(np.mean(pcm.astype(float) ** 2))) if len(pcm) else 0.0
        clips.append(dict(frame=pl['frame'], stop=pl.get('stop'), start=f"0x{pl['start']:04X}", length=pl['length'], rate_hz=rate, seconds=round(2 * pl['length'] / rate, 2), repeat=pl['repeat'], written_frames=[min((x for x in wf if x is not None)), max((x for x in wf if x is not None))] if any((x is not None for x in wf)) else None, wav=name, data_sha256=hashlib.sha256(data).hexdigest(), rms=round(rms, 1)))
    from PIL import Image
    pics = []
    for key, v in sorted(pictures.items(), key=lambda kv: kv[1]['first']):
        name = f"{r['id']}_{key}.png"
        rgba = np.dstack([v['rgb'], np.where(v['img'] < 0, 0, 255)]).astype(np.uint8)
        Image.fromarray(rgba).resize((240, 240), Image.NEAREST).save(out / name)
        pics.append(dict(key=key, first=v['first'], last=v['last'], frames=v['frames'], palette=v['pal'], transparent_pixels=int((v['img'] < 0).sum()), png=name))
    return dict(id=r['id'], param=r['param'], chapter=r['chapter'], who=r['who'], arcade_stage=r['arcade_stage'], actor_life=life, actor_spans=runs, actor_frames=first[1] - first[0] + 1, sprites_shown=spans, sprite_frames=spans[0][1] - spans[0][0] + 1, position=sorted(pos), sat_entries=[list(s) for s in sorted(sat)], pictures=pics, sequence=runs_of(seq), palette_changes=[dict(frame=f, colors=[f'{c:03X}' for c in cols]) for f, cols in pal_seq], play_stands_still=len(hiryu) == 1, hiryu_positions=len(hiryu), adpcm=clips, cd_commands=[c for c in cd if first[0] - 60 <= c['frame'] <= first[1] + 60], dumps_checked=len(checks), dumps_exact=exact, worst_mismatch=max(checks.values()) if checks else None)

def runs_of(seq):
    """[[first frame, frames, picture key], ...] of the per-frame picture sequence."""
    out = []
    for f, k in seq:
        if out and out[-1][2] == k and (out[-1][0] + out[-1][1] == f):
            out[-1][1] += 1
        else:
            out.append([f, 1, k])
    return out

def transcribe(out, rows):
    from faster_whisper import WhisperModel
    model = WhisperModel('large-v3', device='cpu', compute_type='int8')
    for r in rows:
        for c in r['adpcm']:
            segs, _ = model.transcribe(str(out / c['wav']), language='ja', beam_size=5, temperature=0.0, vad_filter=True, word_timestamps=False)
            c['asr'] = [dict(start=round(s.start, 2), end=round(s.end, 2), text=s.text, no_speech_prob=round(s.no_speech_prob, 3)) for s in segs]

def cmd_measure(a):
    out = a.out.resolve()
    out.mkdir(parents=True, exist_ok=True)
    rows = []
    for r in manifest():
        m = measure_one(r, a.capture / r['id'], out)
        rows.append(m)
        print(json.dumps({k: v for k, v in m.items() if k not in ('palette_changes', 'pictures', 'adpcm')}))
        for c in m['adpcm']:
            print('   adpcm', json.dumps(c))
    if a.transcribe:
        transcribe(out, rows)
        for r in rows:
            for c in r['adpcm']:
                print(r['id'], c['wav'], [s['text'] for s in c.get('asr', [])])
    (out / 'portraits_pce.json').write_text(json.dumps(dict(portraits=rows), indent=1, ensure_ascii=False) + '\n')
    bad = [r['id'] for r in rows if r['dumps_exact'] != r['dumps_checked'] or not r['pictures'] or abs(r['sprites_shown'][0][1] - r['actor_spans'][0][1]) > 2 or (sum((n for _, n, _ in r['sequence'])) != r['sprite_frames'])]
    if bad:
        print('portrait_pce: measurement checks failed for', bad)
        return 1
    return 0

def cmd_receipt(a):
    """The committed receipt (manifests/portraits_measured.json): what the build and the"""
    m = json.loads((a.measure / 'portraits_pce.json').read_text())
    st = json.loads(a.static.read_text())
    out = []
    for r in m['portraits']:
        keys = [p['key'] for p in r['pictures']]
        seq = [[n, keys.index(k)] for _, n, k in r['sequence']]
        steady = r['palette_changes'][-1]
        sites = [s for s in st['spawns'][str(r['chapter'])] if s['spawn']['param'] == r['param']]
        out.append(dict(id=r['id'], param=r['param'], chapter=r['chapter'], who=r['who'], arcade_stage=r['arcade_stage'], actor_frames=r['actor_life'], shown_frames=r['sprites_shown'][0], frames=r['sprite_frames'], position=r['position'][0], size=[80, 80], palette_vce=[int(c, 16) for c in steady['colors']], palette_from_frame=steady['frame'], pictures=[dict(key=p['key'], frame=p['first'], shown=p['frames']) for p in r['pictures']], sequence=seq, play_stands_still=r['play_stands_still'], voice=[dict(start_frame=c['frame'], offset_frames=c['frame'] - r['sprites_shown'][0][0], seconds=c['seconds'], rate_hz=c['rate_hz'], adpcm_sha256=c['data_sha256'], asr_ja=[x['text'] for x in c.get('asr', [])]) for c in r['adpcm']], pce_trigger=dict(table=sites[0]['table'], state=sites[0]['state'], site=sites[0]['site'], states=sites[0]['states']) if sites else None, dumps_exact=f"{r['dumps_exact']}/{r['dumps_checked']}"))
    doc = dict(description='W3b / D8 PC Engine portrait measurements (portrait_pce.py capture + measure + static; MEASURED 2026-10-10). Frames are PC Engine MAME frames of each capture in manifests/portraits.json. sequence = [frames, picture index] runs from the first shown frame (the mouth animation). asr_ja is a faster-whisper large-v3 machine transcript of the ADPCM voice clip, not a reviewed text.', portraits=out)
    a.out.write_text(json.dumps(doc, indent=1, ensure_ascii=False) + '\n')
    print('wrote', a.out, len(out), 'portraits')
    return 0

def self_test():
    up = msm5205([7] * 4)
    down = msm5205([15] * 4)
    assert (up == -down).all() and list(up) == [30, 93, 229, 522], (up, down)
    code = bytes.fromhex('a9208562a9808563203d79a9038d0a3460')
    mem = bytearray(65536)
    mem[32768:32768 + len(code)] = code
    mem[32800:32808] = bytes([64, 1, 128, 0, 255, 113, 107, 2])
    ev = walk(lambda a: mem[a], 32768, set())
    kinds = [e[1] for e in ev]
    assert kinds == ['spawn_actor', 'set_state'], ev
    assert ev[0][2]['type'] == 107 and ev[0][2]['param'] == 2 and (ev[0][2]['x'] == 320) and (ev[1][2] == 3), ev
    print('portrait_pce self-test passed')
    return 0

def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('--self-test', action='store_true')
    sub = p.add_subparsers(dest='cmd')
    c = sub.add_parser('capture')
    c.add_argument('--cue', type=Path, required=True)
    c.add_argument('--rompath', type=Path, required=True)
    c.add_argument('--workdir', type=Path, required=True)
    c.add_argument('--jobs', type=int, default=8)
    c.add_argument('--only', help='comma-separated portrait ids (into an existing workdir)')
    s = sub.add_parser('static')
    s.add_argument('capture', type=Path)
    s.add_argument('--out', type=Path)
    m = sub.add_parser('measure')
    m.add_argument('capture', type=Path)
    m.add_argument('--out', type=Path, required=True)
    m.add_argument('--transcribe', action='store_true')
    r = sub.add_parser('receipt')
    r.add_argument('measure', type=Path, help='a measure --out directory')
    r.add_argument('--static', type=Path, required=True, help='a static --out report')
    r.add_argument('--out', type=Path, required=True)
    a = p.parse_args()
    if a.self_test:
        return self_test()
    if a.cmd == 'capture':
        return capture(a)
    if a.cmd == 'static':
        return cmd_static(a)
    if a.cmd == 'measure':
        return cmd_measure(a)
    if a.cmd == 'receipt':
        return cmd_receipt(a)
    p.print_help()
    return 2
if __name__ == '__main__':
    sys.exit(main())
