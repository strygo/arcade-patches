"""Strider EX cinematic captions (D4a): glyphs, caption tables, schedule, gate."""
import argparse
import hashlib
import json
import os
import re
import struct
import subprocess
import sys
import textwrap
from pathlib import Path
import numpy as np
sys.path.insert(0, str(Path(__file__).resolve().parent))
import cinematic_convert as C
import cinematic_timing as CT
import cps1_gfx as G
ROOT = Path(__file__).resolve().parents[3]
HERE = ROOT / 'backports/striderex'
M = HERE / 'manifests'
ASSETS = HERE / 'assets/subtitle_font'
MANIFEST = M / 'subtitles.json'
JA_GRIDS = ASSETS / 'ja_glyphs.txt'
EN_GRIDS = ASSETS / 'en_marks.txt'
EN_LOWER = ASSETS / 'en_lower.txt'
EN_LOWER_SHAPE = (10, 8)
CAP_PALETTE = 31
CAPTION_CODES = (48128, 48639)
OUTLINE = 6
PALETTE = [61440, 65262, 64716, 64170, 63624, 63078, 61713, 62259] + [61440] * 8
EN_ADVANCE, EN_PITCH, EN_MAX = (9, 11, 27)
EN_INK = 10
EN_DESCENT = 2
STILL_DESCENT = EN_DESCENT
JA_ADVANCE, JA_PITCH, JA_MAX = (16, 16, 15)
PICTURE_X0, PICTURE_W = (64, 256)
BOTTOM = 222
ASCII_FONT = {32: ' ', 33: '-', 40: '?', 41: '!', 42: '&', 43: '.', 44: ','}
ASCII_FONT.update({48 + i: str(i) for i in range(10)})
ASCII_FONT.update({65 + i: chr(65 + i) for i in range(26)})
EN_CODE = {c: b for b, c in ASCII_FONT.items()}
JA_ROWS = ['との言シア帝都をリー親玉者なし。', '「」\x01べこへれ馬鹿奴ロ戦艦バルグ', 'め勝ったつもりかきさまどあお方敵', 'ではいわ!ストライダ生てユ大陸ら', '出ん承知余に逆うねよろ力思るが全', '世界足元、\x02―――空中ぎ我々だそ', '玩具必要太古怪物〝第3月〟来軍事', '科学手入え飛竜ひざづ市天打ちげ球', '上焼殺く新創命み死神子']
JA_ARCADE = {}
for _r, _s in enumerate(JA_ROWS):
    for _k, _ch in enumerate(_s):
        JA_ARCADE.setdefault(_ch, 13856 + 16 * _r + _k)
JA_EQUIV = {'！': '!', '３': '3'}
ASM_HOOKS = {'ex_bank.s': ['include "subtitles.s"', 'include "captions.inc"', 'bsr     cap_start'], 'scene_core.s': ['bsr     cap_reset', 'add.w   CAP_OFF,a3', 'move.w  d5,CAP_SN', 'bsr     cap_step'], 'subtitles.s': ['lea     cap_dub,a0', 'moveq   #1+REGION_EN,d0']}

def sha12(*parts):
    return hashlib.sha256('\n'.join(parts).encode()).hexdigest()[:12]

def read_grids(path, shape=None):
    """{char: pens (15 transparent)} from a grid file: a header line `U+XXXX <char> [status]`, then the"""
    out, meta, cur, rows = ({}, {}, None, [])
    for line in path.read_text(encoding='utf-8').splitlines():
        if line.startswith('#') or not line.strip():
            continue
        m = re.match('^U\\+([0-9A-F]{4,5})\\s+(\\S)\\s*(.*)$', line)
        if m:
            if cur is not None:
                out[cur] = rows
            cur, rows = (chr(int(m.group(1), 16)), [])
            meta[cur] = m.group(3).strip()
            if m.group(2) != cur:
                raise SystemExit(f'{path}: header {line!r}: character does not match its code point')
            continue
        rows.append([15 if c == '.' else int(c) for c in line.strip()])
    if cur is not None:
        out[cur] = rows
    grids = {}
    for ch, rows in out.items():
        a = np.array(rows)
        if shape is None and (a.ndim != 2 or a.shape[0] != a.shape[1]):
            raise SystemExit(f'{path}: {ch} is not square ({a.shape})')
        if shape is not None and a.shape != tuple(shape):
            raise SystemExit(f'{path}: {ch} is {a.shape}, not {tuple(shape)}')
        grids[ch] = a
    return (grids, meta)

def write_grids(path, grids, meta, header):
    lines = [f'# {h}' for h in header]
    for ch, a in grids.items():
        lines.append('')
        lines.append(f"U+{ord(ch):04X} {ch} {meta.get(ch, '')}".rstrip())
        lines += [''.join(('.' if v == 15 else str(int(v)) for v in r)) for r in a]
    path.write_text('\n'.join(lines) + '\n', encoding='utf-8')

def stock_gfx(rom_dir):
    import mapper_testkit as K
    import title_ex as TX
    return TX.stock_gfx(K.pool([Path(rom_dir).resolve()]))

class Glyphs:
    """Glyph pens per language: arcade glyphs from the stock graphics, the rest from the grid files."""

    def __init__(self, gfx):
        self.gfx = gfx
        self.ja_new, self.ja_meta = read_grids(JA_GRIDS) if JA_GRIDS.exists() else ({}, {})
        self.en_new, _ = read_grids(EN_GRIDS) if EN_GRIDS.exists() else ({}, {})
        self.en_lower, self.en_lower_meta = read_grids(EN_LOWER, EN_LOWER_SHAPE)
        if sorted(self.en_lower) != [chr(c) for c in range(97, 123)]:
            raise SystemExit(f'{EN_LOWER}: not the 26 letters a-z')

    def en(self, ch):
        """English pens: 8x8 (the arcade capitals, digits and marks; the drawn marks) or 10x8 (the drawn"""
        if ch in EN_CODE:
            t = G.get_tile(self.gfx, 2097152 + 64 * (28672 + EN_CODE[ch]), 8, 0)
            return (np.where(t == 0, 7, t), 'arcade')
        if ch in self.en_new:
            t = self.en_new[ch]
            return (np.where(t == 0, 7, t), 'new')
        if ch in self.en_lower:
            t = self.en_lower[ch]
            return (np.where(t == 0, 7, t), 'lower')
        return (None, 'missing')

    def ja(self, ch):
        ch = JA_EQUIV.get(ch, ch)
        if ch in JA_ARCADE:
            return (G.get_tile(self.gfx, 128 * JA_ARCADE[ch], 16), 'arcade')
        if ch in self.ja_new:
            return (self.ja_new[ch], 'new')
        return (None, 'missing')

def outlined_cell(pens, origin):
    """16x16 cell: pens (h x w, as an 8x8 capital or a 10x8 lower-case letter) placed at origin (y, x), plus a"""
    cell = np.full((16, 16), 15)
    h, w = pens.shape
    y0, x0 = origin
    for y in range(h):
        for x in range(w):
            if pens[y, x] != 15 and 0 <= y0 + y < 16 and (0 <= x0 + x < 16):
                cell[y0 + y, x0 + x] = pens[y, x]
    ink = cell != 15
    pad = np.pad(ink, 1)
    ring = np.zeros_like(ink)
    for dy in (-1, 0, 1):
        for dx in (-1, 0, 1):
            ring |= pad[1 + dy:17 + dy, 1 + dx:17 + dx]
    cell[ring & ~ink] = OUTLINE
    return cell

def ja_origin(pens):
    """Japanese glyphs keep the arcade's vertical metrics; shifted horizontally (by at most 1)"""
    xs = np.nonzero((pens != 15).any(0))[0]
    if len(xs) == 0:
        return (0, 0)
    lo, hi = (xs.min(), xs.max())
    if lo == 0 and hi <= 13:
        return (0, 1)
    if hi == 15 and lo >= 2:
        return (0, -1)
    return (0, 0)

def en_charset():
    """Every character English text can show (captions, boss pages): the arcade 8x8 font's, the drawn marks"""
    marks, _ = read_grids(EN_GRIDS)
    lower, _ = read_grids(EN_LOWER, EN_LOWER_SHAPE)
    return set(EN_CODE) | set(marks) | set(lower)

def en_norm(text):
    """An approved English line as the pages spell it: the ellipsis and the dashes in the font's marks."""
    return text.replace('…', '...').replace('—', '-').replace('–', '-')

def cased_pages(text, pages):
    """pages (lists of rows) re-cased from the approved text: the same characters, rows and page breaks, each"""
    t = en_norm(text)
    flat = ' '.join((r for pg in pages for r in pg))
    if len(flat) != len(t) or flat.upper() != t.upper():
        raise ValueError(f'pages {flat!r} are not the words of {t!r}')
    out, k = ([], 0)
    for pg in pages:
        out.append([])
        for r in pg:
            out[-1].append(t[k:k + len(r)])
            k += len(r) + 1
    return out

def cmd_mixed_case(a):
    """Reconstruction helper."""
    man = json.loads(MANIFEST.read_text(encoding='utf-8'))
    changed, flagged = (0, [])
    for ln in man['lines']:
        if not ln['en']['pages']:
            continue
        try:
            new = cased_pages(ln['en']['text'], ln['en']['pages'])
        except ValueError as e:
            flagged.append(f"{ln['id']}: {e}")
            continue
        changed += new != ln['en']['pages']
        ln['en']['pages'] = new
    MANIFEST.write_text(json.dumps(man, indent=1, ensure_ascii=False) + '\n', encoding='utf-8')
    print(f'{MANIFEST.name}: {changed} lines re-cased; flagged {len(flagged)}')
    for f in flagged:
        print('  FLAG', f)
    return 1 if flagged else 0

def wrap_en(text):
    """The text's own case (mixed, 2026-10-21), the fewest lines of at most EN_MAX, then balanced (narrowest"""
    text = en_norm(text)
    n = len(textwrap.wrap(text, EN_MAX)) or 1
    for w in range(max((len(x) for x in text.split())), EN_MAX + 1):
        lines = textwrap.wrap(text, w)
        if len(lines) == n:
            return lines
    return textwrap.wrap(text, EN_MAX) or ['']
JA_BREAK_AFTER = '、。'
JA_SOFT_AFTER = 'をはがのにでともへや'

def wrap_ja(text):
    """The fewest lines of at most JA_MAX characters, each break placed near an even share,"""
    n = -(-len(text) // JA_MAX)
    out, rest = ([], text)
    for k in range(n, 1, -1):
        target = -(-len(rest) // k)
        best = None
        lo, hi = (max(1, len(rest) - JA_MAX * (k - 1)), min(JA_MAX, len(rest) - 1))
        for cut in range(lo, hi + 1):
            prev, nxt = (rest[cut - 1], rest[cut])
            score = abs(cut - target)
            if prev in JA_BREAK_AFTER:
                score -= 6
            elif prev in JA_SOFT_AFTER:
                score -= 3
            elif (prev > '\u3040' and prev < 'ヿ') != (nxt > '\u3040' and nxt < 'ヿ'):
                score -= 1
            if nxt in '、。ーっッゃゅょャ':
                score += 20
            if best is None or score < best[0]:
                best = (score, cut)
        out.append(rest[:best[1]])
        rest = rest[best[1]:]
    out.append(rest)
    return out

def pages_of(lines):
    return [lines[i:i + 2] for i in range(0, len(lines), 2)]

def cmd_init_manifest(a):
    review = json.loads((M / 'pce_cinematic_text_review.json').read_text())
    asr = json.loads((M / 'pce_cinematic_transcripts.json').read_text())
    cines = json.loads((M / 'pce_cinematics.json').read_text())['cinematics']
    scene_of = {c['track']: c['id'] for c in cines}
    seg = {(t['track'], i): s for t in asr['tracks'] for i, s in enumerate(t['segments'])}
    rows = []
    for ln in review['lines']:
        tr, k = (int(v) for v in ln['id'][2:].split('.'))
        s = seg[tr, k]
        ja, en = (ln['ja_reading'] or '', ln['en_draft'] or '')
        rows.append(dict(id=ln['id'], scene=scene_of[tr], track=tr, start=round(s['start'], 2), end=round(s['end'], 2), speaker=ln['speaker'], draft_hash=sha12(ja, en), en=dict(text=en, pages=pages_of(wrap_en(en)) if en else []), ja=dict(text=ja, pages=pages_of(wrap_ja(ja)) if ja else [])))
    man = dict(schema=1, status='DRAFT: no line is approved (CAPCOM_TRANSLATION_GUIDELINES.md; review page in PHASE0_FINDINGS.md P0.9). Text, page breaks and times may be edited here; subtitle_ex.py build picks them up.', sources=dict(text='manifests/pce_cinematic_text_review.json (en_draft, ja_reading)', times='manifests/pce_cinematic_transcripts.json (seconds from each track INDEX 01)', draft_hash='SHA-256 of ja_reading + newline + en_draft, first 12 hex (as subtitle_review_page.py)'), rules=dict(language='FLAGS_AND_LANGUAGE.md "Subtitles": no pack -> always on, region language; pack + Japanese voices -> region language; pack + English dub -> English (L2). striderua = English, striderjr = Japanese.', layout=f"two lines a page at most; English in the text's mixed case, {EN_MAX} characters a line ({EN_ADVANCE}-pixel advance); Japanese {JA_MAX} characters a line (16-pixel advance); bottom-anchored inside the 256-pixel picture", timing="caption times follow the voice measured in the pack's tracks (manifests/caption_voice.json) by the rule in scripts/caption_pacing.py; start/end here are the transcript segments (the dub plan's slots), not caption times"), lines=rows)
    MANIFEST.write_text(json.dumps(man, indent=1, ensure_ascii=False) + '\n', encoding='utf-8')
    print(f'{MANIFEST}: {len(rows)} lines')
    return 0

def load_manifest():
    man = json.loads(MANIFEST.read_text(encoding='utf-8'))
    for ln in man['lines']:
        for lang, limit in (('en', EN_MAX), ('ja', JA_MAX)):
            for pg in ln[lang]['pages']:
                if not 1 <= len(pg) <= 2:
                    raise SystemExit(f"{ln['id']} {lang}: a page has {len(pg)} lines (1-2)")
                for row in pg:
                    if len(row) > limit:
                        raise SystemExit(f"{ln['id']} {lang}: {row!r} is longer than {limit}")
    chars = en_charset()
    for ln in man['lines']:
        pages = ln['en']['pages']
        if not pages:
            continue
        try:
            same = cased_pages(ln['en']['text'], pages) == pages
        except ValueError as e:
            raise SystemExit(f"{ln['id']} en: {e}")
        if not same:
            raise SystemExit(f"{ln['id']} en: the pages are not in the approved text's case (subtitle_ex.py mixed-case)")
        bad = {ch for pg in pages for row in pg for ch in row} - chars - {' '}
        if bad:
            raise SystemExit(f"{ln['id']} en: no glyph for {sorted(bad)}")
    return man

class Captions:

    def __init__(self, gfx, man, extra=()):
        self.glyphs = Glyphs(gfx)
        self.man = man
        self.codes = {}
        self.cells = {}
        self.missing = {}
        nxt = CAPTION_CODES[0]
        for lang in ('en', 'ja'):
            chars = sorted({ch for ln in man['lines'] for pg in ln[lang]['pages'] for row in pg for ch in row if ch not in (' ', '\u3000')} | {ch for lg, text in extra if lg == lang for ch in text if ch not in (' ', '\u3000')})
            for ch in chars:
                pens, src = getattr(self.glyphs, lang)(ch)
                if pens is None:
                    self.missing.setdefault(lang, []).append(ch)
                    continue
                cell = outlined_cell(pens, (1, 1) if lang == 'en' else ja_origin(pens))
                if lang == 'en' and ((cell != 15) & (cell != OUTLINE)).sum() != (pens != 15).sum():
                    raise SystemExit(f'caption glyph {ch!r}: clipped by its cell')
                if lang == 'en' and (cell[-1] != 15).any():
                    raise SystemExit(f"caption glyph {ch!r}: its outline reaches the cell's last row")
                key = cell.astype(np.uint8).tobytes()
                code = next((c for c, v in self.cells.items() if v.astype(np.uint8).tobytes() == key), None)
                if code is None:
                    if nxt > CAPTION_CODES[1]:
                        raise SystemExit('caption codes exhausted')
                    code, nxt = (nxt, nxt + 1)
                    self.cells[code] = cell
                self.codes[lang, ch] = code
        if self.missing:
            raise SystemExit(f'glyphs missing: {self.missing}')

    def page_entries(self, lang, page, bottom=BOTTOM, descent=EN_DESCENT):
        """CPS-1 sprite entries (x, y, code, attr) of one page, glyph order = list order (first on top);"""
        if lang == 'en' and (not descent) and any((ch.islower() for row in page for ch in row)):
            raise SystemExit(f'{page}: lower case on a page without descender room')
        if lang == 'en':
            adv, pitch, ink = (EN_ADVANCE, EN_PITCH + descent, EN_INK + descent)
        else:
            adv, pitch, ink = (JA_ADVANCE, JA_PITCH, 16)
        out = []
        n = len(page)
        for i, row in enumerate(page):
            top = bottom - ink - pitch * (n - 1 - i)
            w = adv * len(row) + (1 if lang == 'en' else 0)
            x = PICTURE_X0 + (PICTURE_W - w) // 2
            for ch in row:
                if ch not in (' ', '\u3000'):
                    out.append((x + 64 & 511, top + 16 & 511, self.codes[lang, ch], CAP_PALETTE))
                x += adv
        return out

    def ink_rows(self, lang, page, bottom=BOTTOM, descent=EN_DESCENT):
        """Screen lines of a page that show a glyph's pixels (pens other than the outline, which is"""
        rows = set()
        for _, y, code, _ in self.page_entries(lang, page, bottom, descent):
            cell = self.cells[code]
            rows |= {(y - 16) % 512 + r for r in range(16) if ((cell[r] != 15) & (cell[r] != OUTLINE)).any()}
        return sorted(rows)

    def still_bottom(self, pages, band_top, band_lines):
        """The stage select's caption pages (pages: lists of English rows) centered in its band: the"""
        rows = sorted({r for pg in pages for r in self.ink_rows('en', pg, BOTTOM, STILL_DESCENT)})
        first, last = (rows[0], rows[-1])
        free = band_lines - (last - first + 1)
        if free < 2:
            raise SystemExit(f'the stage select caption ({last - first + 1} lines) does not fit its band ({band_lines})')
        shift = band_top + free // 2 - first
        return (BOTTOM + shift, first + shift, last + shift)

    def install(self, region):
        """Write the glyph cells; refuses a code whose 128 bytes are not still empty (zero)."""
        for code, cell in self.cells.items():
            at = G.ex_offset('obj', code)
            if any(region[at:at + 128]):
                raise SystemExit(f'caption code {code:#06x} is already used in the EX graphics region')
            G.put_tile(region, at, cell)

    def schedules(self, scenes, census):
        """{scene id: {key: [(record, page index or None)]}} and the page list [(lang, entries, line, rows)]."""
        import build_ex as BX
        import caption_pacing as CP
        if BX.CARD_AFTER:
            raise SystemExit('captions on the EX title card are not planned by caption_pacing.py (CARD_AFTER)')
        voices = CP.voice_manifest()
        lines = {ln['id']: ln for ln in self.man['lines']}
        pages, sched, report, index = ([], {}, dict(plan={}), {})
        sched['card'] = {'en': [], 'ja': []}

        def page_index(lang, row):
            key = (lang, row['line'], row['page'])
            if key not in index:
                pg = lines[row['line']][lang]['pages'][row['page']]
                pages.append((lang, self.page_entries(lang, pg), row['line'], pg))
                index[key] = len(pages) - 1
            return index[key]
        cues = {}
        for s in scenes:
            n = CP.stream_records(s['stream'])
            cue = CP.scene_cue(s['preroll'] + 0.5, s['window']['window_s'][0]) if s.get('window') else CP.CUE_RECORD
            cues[s['id']] = round(cue, 3)
            end = CP.shown_at(n - C.SPRITE_LEAD, cue)
            sched[s['id']] = {}
            for voice, lang, key in CP.VARIANTS:
                rows = CP.plan_scene(s['id'], lang, voice, voices, self.man, end)
                want = {(ln['id'], k) for ln in lines.values() if ln['scene'] == s['id'] for k in range(len(ln[lang]['pages']))}
                lost = sorted(want - {(r['line'], r['page']) for r in rows})
                if lost:
                    report.setdefault('dropped', []).append(f"{s['id']} {key}: {lost} (after the scene's last picture)")
                sched[s['id']][key] = CP.schedule_of(rows, lambda r, lang=lang: page_index(lang, r), cue)
                report['plan'][f"{s['id']} {key}"] = [dict(line=r['line'], page=r['page'], on=round(r['on'], 3), off=round(r['off'], 3), why=r['why'], off_why=r.get('off_why'), voice=[r['voice_on'], r['voice_off']]) for r in rows]
        report['timing'] = dict(cue=cues, cps1_hz=CP.CPS1_HZ, lead_frames=CP.LEAD, lag_frames=CP.LAG, min_page_s=CP.MIN_PAGE, chain_s=CP.CHAIN, voice_manifest_sha256=CP.file_sha(CP.VOICE_MANIFEST))
        return (sched, pages, report)

def stream_sprite_counts(stream):
    """Per record, the stream's own sprite entry count after it (op 2 persists until the next op 2)."""
    pos, n, out = (0, 0, [])
    while True:
        size, = struct.unpack_from('>H', stream, pos)
        if size == 65535:
            return out
        q, end = (pos + 2, pos + 2 + size)
        while q < end - 2:
            word, = struct.unpack_from('>H', stream, q)
            if word & 255 == 2:
                n, = struct.unpack_from('>H', stream, q + 2)
            q += CT.op_size(stream, q)
        out.append(n)
        pos = end

def captions_inc(scenes, sched, pages, caps, still_pages=()):
    lines = ['; captions.inc: written by scripts/subtitle_ex.py (DRAFT text, manifests/subtitles.json)', 'cap_scenes:                             ; per scene (scenes order): Japanese, English schedule,', '                                        ; timed to the Japanese voices (also without a pack)']
    for s in scenes:
        lines.append(f"        dc.l    cap_{s['id']}_ja,cap_{s['id']}_en")
    lines.append('cap_dub:                                ; per scene: the English schedule timed to the English dub')
    lines.append('                                        ; (twice: cap_start indexes it as cap_scenes, English)')
    for s in scenes:
        lines.append(f"        dc.l    cap_{s['id']}_en_dub,cap_{s['id']}_en_dub")
    for s in scenes:
        for lang in ('ja', 'en', 'en_dub'):
            lines.append(f"cap_{s['id']}_{lang}:")
            for rec, pg in sched[s['id']][lang]:
                lines.append(f"        dc.w    {rec}\n        dc.l    {(f'cap_page{pg}' if pg is not None else 0)}")
            lines.append('        dc.w    $FFFF')
    lines.append('cap_card:                               ; the EX title card: Japanese, English schedule')
    lines.append('        dc.l    cap_card_ja,cap_card_en')
    for lang in ('ja', 'en'):
        lines.append(f'cap_card_{lang}:')
        for tick, pg in sorted(sched['card'][lang]):
            lines.append(f"        dc.w    {tick}\n        dc.l    {(f'cap_page{pg}' if pg is not None else 0)}")
        lines.append('        dc.w    $FFFF')
    lines.append('        even')
    for i, (lang, ent, lid, pg) in enumerate(pages):
        lines.append(f'cap_page{i}:                             ; {lid} {lang}: ' + ' / '.join(pg).encode('ascii', 'replace').decode())
        lines.append(f'        dc.w    {len(ent)}')
        for e in ent:
            lines.append('        dc.w    ' + ','.join((f'${v:04X}' for v in e)))
    lines.append('cap_palette:')
    lines.append('        dc.w    ' + ','.join((f'${v:04X}' for v in PALETTE)))
    lines.append('cap_still_pages:                        ; the stage select caption pages, one a still (stage_select.s)')
    lines += [f'        dc.l    cap_page{p}' for p in still_pages]
    return '\n'.join(lines) + '\n'

def high_water(cv):
    """EX OBJ/SCROLL2 codes the converter used: SCROLL2 tiles, sprite blocks, single cells."""
    obj_end = cv.obj_shelf[0] + 16 * cv.obj_shelf[2] if cv.obj_shelf else cv.obj_base
    return dict(s2=[C.S2_BASE, cv.next_s2 - 1], blocks=[cv.obj_base, obj_end - 1], cells=[49152 - len(cv.cell_codes), 49151])

def prepare(cv, scenes, census, rom_dir, stills=(), band=None):
    """build_ex.py's caption step, after convert_scenes: checks the caption codes against the"""
    extra = [('en', row) for pg in stills for row in pg]
    caps = Captions(stock_gfx(rom_dir / 'striderua'), load_manifest(), extra)
    hw = high_water(cv)
    lo, hi = CAPTION_CODES
    for name, (u0, u1) in hw.items():
        if not (u1 < lo or u0 > hi):
            raise SystemExit(f"caption codes {lo:#x}-{hi:#x} overlap the converter's {name} {u0:#x}-{u1:#x}")
    caps.install(cv.region)
    sched, pages, rep = caps.schedules(scenes, census)
    still_pages, still_text = ([], None)
    if stills:
        bottom, first, last = caps.still_bottom(stills, *band)
        for pg in stills:
            pages.append(('en', caps.page_entries('en', pg, bottom, STILL_DESCENT), 'stage select', pg))
            still_pages.append(len(pages) - 1)
        still_text = dict(bottom=bottom, ink_lines=[first, last], band=[band[0], band[0] + band[1] - 1], black_above=first - band[0], black_below=band[0] + band[1] - 1 - last)
    for s in scenes:
        counts = stream_sprite_counts(s['stream'])
        for lang in sched[s['id']]:
            sch, cur = (dict(sched[s['id']][lang]), 0)
            for k, n in enumerate(counts):
                if k in sch:
                    cur = len(pages[sch[k]][1]) if sch[k] is not None else 0
                if cur + n > C.OBJ_ENTRIES:
                    raise SystemExit(f"{s['id']} {lang}: record {k}: {cur} caption + {n} stream entries > {C.OBJ_ENTRIES}")
    report = dict(caption_codes=[f'{lo:#06x}', f'{hi:#06x}'], codes_used=len(caps.cells), first_free=f'{lo + len(caps.cells):#06x}', codes_by_lang={lang: len({c for (lg, _), c in caps.codes.items() if lg == lang}) for lang in ('en', 'ja')}, converter_high_water={k: [f'{v:#06x}' for v in r] for k, r in hw.items()}, palette=f'OBJ {CAP_PALETTE:#04x}', pages=len(pages), max_page_entries=max((len(p[1]) for p in pages)), glyph_sources={lang: {src: sum((1 for lg, ch in caps.codes if lg == lang and getattr(caps.glyphs, lang)(ch)[1] == src)) for src in ('arcade', 'new', 'lower')} for lang in ('en', 'ja')}, schedules={sid: {lang: [[r, p] for r, p in v] for lang, v in d.items()} for sid, d in sched.items()}, pages_detail=[dict(lang=l, line=lid, page=pg, entries=[list(e) for e in ent]) for l, ent, lid, pg in pages], preroll={s['id']: s['preroll'] for s in scenes}, still_pages=still_pages, still_text=still_text, manifest_sha256=hashlib.sha256(MANIFEST.read_bytes()).hexdigest(), **rep)
    return (captions_inc(scenes, sched, pages, caps, still_pages), report)

class CaptionModel:
    """cinematic_convert.CpsModel with the player's caption behavior: caption palette in every"""

    def __init__(self, region, stream, schedule, pages):
        self.m = C.CpsModel(region)
        for p in self.m.pals:
            p[16 * CAP_PALETTE:16 * CAP_PALETTE + 16] = PALETTE
        self.m.pal[16 * CAP_PALETTE:16 * CAP_PALETTE + 16] = PALETTE
        self.stream, self.pos, self.k = (stream, 0, 0)
        self.sched = dict(schedule)
        self.pages = pages
        self.cap = []
        self.own = []
        self.composite = self.m.sprites

    def step(self):
        """One record. Returns False at the end mark."""
        m = self.m
        pos = m.run(self.stream, self.pos)
        if pos is None:
            return False
        self.pos = pos
        if m.sprites is not self.composite:
            self.own = m.sprites
        if self.k in self.sched:
            pg = self.sched[self.k]
            self.cap = list(self.pages[pg][1]) if pg is not None else []
        m.sprites = self.composite = [tuple(e) for e in self.cap] + list(self.own)
        self.k += 1
        return True

    def render(self, captions=True):
        if captions:
            return self.m.pal[self.m.render()]
        saved = self.m.latched
        self.m.latched = [e for e in saved if not (e[3] == CAP_PALETTE and CAPTION_CODES[0] <= e[2] <= CAPTION_CODES[1])]
        out = self.m.pal[self.m.render()]
        self.m.latched = saved
        return out
GATE_LUA_EXTRA = "\nlocal targets={}\nfor s in string.gmatch(os.getenv('CAP_TARGETS') or '','%d+') do targets[tonumber(s)]=true end\nlocal cards={}\nfor s in string.gmatch(os.getenv('CARD_TARGETS') or '','%d+') do cards[tonumber(s)]=true end\nlocal cardk=nil\nemu.register_frame_done(function()\n local act=sp:read_u16(0xfff914)\n if act==0xc1e5 and targets[sp:read_u32(0xfff900)] then\n  screen:snapshot(string.format('%s/c_%05d_%d.png',out,f,sp:read_u32(0xfff900))) end\n if act==0xc1e7 then                       -- the EX title card: its frames counted from the first\n  cardk=(cardk or -1)+1\n  if cards[cardk] then screen:snapshot(string.format('%s/k_%05d.png',out,cardk)) end\n else cardk=nil end\nend)\n"

def card_targets(sched_card):
    """Card frames to capture around each caption window ([on, off) as written; seen LEAD on):"""
    out = []
    ev = sorted(sched_card)
    for (on, pg), (off, _) in zip(ev[0::2], ev[1::2]):
        a, b = (on + C.SPRITE_LEAD, off + C.SPRITE_LEAD)
        out += [(max(0, a - 3), False), (a + 3, True), ((a + b) // 2, True), (b - 3, True), (b + 3, False)]
    return out

def card_check(out, targets, palette_rgb):
    """The card: no caption before a window, only caption colors changed inside it, the"""
    from PIL import Image
    rows, ref = ([], None)
    for k, want in targets:
        q = out / f'k_{k:05d}.png'
        if not q.exists():
            rows.append(dict(frame=k, missing=True))
            continue
        img = np.asarray(Image.open(q).convert('RGB')).astype(int)
        if ref is None:
            ref = img
        diff = (img != ref).any(-1)
        colors = {tuple(c) for c in img[diff]}
        rows.append(dict(frame=k, caption_expected=want, changed_pixels=int(diff.sum()), only_caption_colors=colors <= palette_rgb))
    ok = len(rows) > 0 and (not any((r.get('missing') for r in rows))) and all(((r['changed_pixels'] > 0) == r['caption_expected'] and r['only_caption_colors'] for r in rows))
    return (ok, rows)

def cmd_measure_codes(a):
    """Converter high-water marks with every listed scene in one shared converter (build_ex's"""
    import build_ex as BX
    cv, scenes = BX.convert_scenes(a.census.resolve(), a.scenes.split(','))
    hw = high_water(cv)
    lo, hi = CAPTION_CODES
    free = [hw['blocks'][1] + 1, hw['cells'][0] - 1]
    rep = dict(scenes=[s['id'] for s in scenes], high_water={k: [f'{v:#06x}' for v in r] for k, r in hw.items()}, free_gap=[f'{v:#06x}' for v in free], free_codes=free[1] - free[0] + 1, caption_codes=[f'{lo:#06x}', f'{hi:#06x}'], caption_codes_in_gap=free[0] <= lo and hi <= free[1], margin_below=lo - free[0], margin_above=free[1] - hi)
    print(json.dumps(rep, indent=1))
    if a.out:
        a.out.write_text(json.dumps(rep, indent=1) + '\n')
    return 0 if rep['caption_codes_in_gap'] else 1
GATE_RUNS = [('striderus01', 'striderus01', 0, 'en', 'en'), ('striderjs01', 'striderjs01', 0, 'ja', 'ja'), ('striderus01-dub', 'striderus01', 1, 'en_dub', 'en'), ('striderjs01-dub', 'striderjs01', 5, 'en_dub', 'en')]

def source_check(caps, region, gfx):
    """The build's caption pages and glyph cells against the sources, independently of the build: every"""
    man = load_manifest()
    still = [p['page'] for p in caps['pages_detail'] if p['line'] == 'stage select']
    fresh = Captions(gfx, man, [('en', row) for pg in still for row in pg])
    lines = {ln['id']: ln for ln in man['lines']}
    bad = []
    for i, p in enumerate(caps['pages_detail']):
        if p['line'] == 'stage select':
            want = fresh.page_entries('en', p['page'], caps['still_text']['bottom'], STILL_DESCENT)
        else:
            if p['page'] not in lines[p['line']][p['lang']]['pages']:
                bad.append(f"page {i} ({p['line']} {p['lang']}): {p['page']} is not a manifest page")
                continue
            want = fresh.page_entries(p['lang'], p['page'])
        got = [tuple(e) for e in p['entries']]
        if [e[:2] + e[3:] for e in got] != [e[:2] + e[3:] for e in want]:
            bad.append(f"page {i} ({p['line']} {p['lang']}): entry places differ from page_entries")
            continue
        for (_, _, gc, _), (_, _, wc, _) in zip(got, want):
            cell = G.get_tile(region, G.ex_offset('obj', gc), 16)
            if not np.array_equal(cell, fresh.cells[wc]):
                bad.append(f"page {i} ({p['line']} {p['lang']}): code {gc:#06x} is not its glyph from the fonts")
                break
    return (not bad, bad)

def cmd_gate(a):
    import ex_gate as EG
    import scene_gate as SG
    from PIL import Image
    build = a.build.resolve()
    caps = json.loads((build / 'captions.json').read_text())
    bjs = json.loads((build / 'build.json').read_text())
    binary = json.loads((a.runtime / 'runtime.json').read_text())['binary']
    work = a.workdir.resolve()
    work.mkdir(parents=True, exist_ok=False)
    pages = [(p['lang'], [tuple(e) for e in p['entries']]) for p in caps['pages_detail']]
    report, ok = (dict(runs={}), True)
    gfx, src_checked = (stock_gfx(a.rom_dir / 'striderua'), {})
    variants = [r for r in GATE_RUNS if not a.runs or r[0] in a.runs.split(',')]
    for name, set_name, flag, key, lang in variants:
        parent = EG.PARENT[set_name]
        bset = bjs['sets'][parent]
        streams = bset['streams']
        files = {q.name: q.read_bytes() for q in (build / parent).iterdir()}
        region = EG.region_from(files)
        if parent not in src_checked:
            src_checked[parent] = source_check(caps, region, gfx)
        src_ok, src_bad = src_checked[parent]
        src = work / f'ex_{name}'
        (src / parent).mkdir(parents=True)
        for n, b in files.items():
            if n == 'strex_p6.bin' and flag:
                b = bytearray(b)
                b[1048574] = flag
                b = bytes(b)
            (src / parent / n).write_bytes(b)
        sets = work / f'set_{name}'
        if not any((key in caps['schedules'][sid] for sid in streams if sid in caps['schedules'])):
            key = lang
        subprocess.run([sys.executable, str(EG.HBSET), 'build', '--hbmame', str(a.hbmame), '--rom-dir', str(a.rom_dir.resolve()), '--ex-dir', str(src), '--set', set_name, '--date', '2026-10-10', '--out', str(sets)], check=True, stdout=subprocess.DEVNULL)
        expect = [i for i in {**EG.BX.STAGE_SCENES, **EG.BX.DESERT_SCENES}[a.stage] if i in streams]
        targets, plan = (set(), {})
        for sid in expect:
            sch = caps['schedules'][sid][key]
            for (rec, pg), nxt in zip(sch, sch[1:] + [[None, None]]):
                if pg is None:
                    continue
                first = rec + 1 + C.SPRITE_LEAD
                last = nxt[0] + C.SPRITE_LEAD if nxt[0] is not None else first
                for r in sorted({first - 1, first, (first + last) // 2, last, last + 1}):
                    targets.add(r)
                    plan.setdefault((sid, r), pg)
        out = work / f'run_{name}'
        out.mkdir()
        (out / 'gate.lua').write_text(EG.LUA + GATE_LUA_EXTRA)
        card = caps['schedules'].get('card', {})
        ktargets = [(k, w and bool(card.get(lang))) for k, w in card_targets(card.get('en', []))] if a.stage == 0 else []
        env = dict(os.environ, SDL_VIDEODRIVER='dummy', SDL_AUDIODRIVER='dummy', OUT=str(out), END=str(a.frames), STEP=str(10 ** 6), CAP_TARGETS=','.join((str(t) for t in sorted(targets))), CARD_TARGETS=','.join((str(k) for k, _ in ktargets)))
        if a.stage:
            env.update(STREX_DEBUG_START=str(EG.DEBUG_START), STREX_STAGE=str(a.stage), STREX_AREA='0', STREX_END=str(a.frames + 100), STREX_PREFIX=str(out / 'dbg'), STREX_INPUTS='')
        cmd = [str(binary), set_name, '-rompath', str(sets), '-nothrottle', '-video', 'none', '-sound', 'none', '-seconds_to_run', str(a.frames // 50 + 30), '-skip_gameinfo', '-noautosave', '-cfg_directory', str(out / 'cfg'), '-nvram_directory', str(out / 'nv'), '-snapshot_directory', str(out), '-autoboot_script', str(out / 'gate.lua')]
        p = subprocess.run(cmd, env=env, cwd=out, capture_output=True, text=True, timeout=1500)
        (out / 'mame.log').write_text(p.stdout + p.stderr)
        if p.returncode:
            raise SystemExit(f'{name}: HBMAME exit {p.returncode}')
        log = [tuple((int(v, 16) if i in (2, 3) else int(v) for i, v in enumerate(l.split('\t')))) for l in (out / 'log.tsv').read_text().splitlines()]
        order = sorted(streams, key=lambda k: streams[k])

        def scene_of(ptr):
            i = max((j for j, s0 in enumerate(order) if streams[s0] <= ptr), default=None)
            return order[i] if i is not None else None
        runs, scene_at = ([], {})
        for r in (r for r in log if r[3] == 49637):
            if runs and r[0] == runs[-1][-1][0] + 1 and (r[1] >= runs[-1][-1][1]):
                runs[-1].append(r)
            else:
                runs.append([r])
        seen = []
        for rs in runs:
            s = scene_of(rs[len(rs) // 2][2])
            seen.append(s)
            for r in rs:
                scene_at[r[0]] = s
        shots = {}
        for q in sorted(out.glob('c_*.png')):
            _, f, r = q.stem.split('_')
            sid = scene_at.get(int(f))
            if sid is not None and int(r) == log[int(f) - 1][1]:
                shots.setdefault(sid, []).append((int(f), int(r), q))
        rows, rgb = ([], {})
        for sid, lst in shots.items():
            stream = (build / 'work' / f'scene_{sid}.bin').read_bytes()
            model = CaptionModel(region, stream, caps['schedules'][sid][key], pages)
            want = {r for _, r, _ in lst}
            k, models = (0, {})
            while k < max(want):
                if not model.step():
                    break
                k += 1
                if k in want:
                    models[k] = (model.render(True), model.render(False))
            sch = dict(map(tuple, caps['schedules'][sid][key]))
            for f, r, q in lst:
                snap = np.asarray(Image.open(q).convert('RGB'))
                withc, without = models[r]

                def to_rgb(words):
                    uniq, inv = np.unique(words, return_inverse=True)
                    lut = np.array([rgb.setdefault(int(w), SG.hb_rgb(int(w))) for w in uniq], np.uint8)
                    return lut[inv].reshape(words.shape + (3,))
                mw, mo = (to_rgb(withc), to_rgb(without))
                cap_px = (mw != mo).any(-1)
                applied = [p for rr, p in sorted(sch.items()) if rr <= r - 1 - C.SPRITE_LEAD]
                planned = applied[-1] if applied else None
                rows.append(dict(scene=sid, frame=f, records=r, planned_page=planned, mismatched=int((mw != snap).any(-1).sum()), outside_caption_mismatched=int(((mo != snap).any(-1) & ~cap_px).sum()), caption_pixels=int(cap_px.sum())))
        planned_ok = all(((x['caption_pixels'] > 0) == (x['planned_page'] is not None) for x in rows))
        exact = all((x['mismatched'] == 0 for x in rows))
        outside = all((x['outside_caption_mismatched'] == 0 for x in rows))
        covered = {x['planned_page'] for x in rows if x['planned_page'] is not None}
        want_pages = {p for sid in expect for _, p in caps['schedules'][sid][key] if p is not None}
        tm = EG.timing(out, scene_at)
        langs = {pages[p][0] for p in covered}
        card_ok, card_rows = card_check(out, ktargets, {tuple(SG.hb_rgb(w)) for w in PALETTE}) if ktargets else (True, [])
        r_ok = seen == expect and exact and outside and planned_ok and (covered == want_pages) and (langs <= {lang}) and (tm['late_records'] == 0) and (len(rows) > 0) and card_ok and src_ok
        ok &= r_ok
        report['runs'][name] = dict(set=set_name, flag=f'0x{flag:02x}', schedule=key, lang=lang, scenes_played=seen, expected=expect, shots=len(rows), source_check=dict(passed=src_ok, problems=src_bad[:20]), pages_planned=len(want_pages), pages_seen=len(covered), pixel_exact=exact, picture_unchanged_outside_captions=outside, captions_only_when_planned=planned_ok, timing=tm, card_caption=dict(passed=card_ok, frames=card_rows), passed=r_ok, failures=[x for x in rows if x['mismatched'] or x['outside_caption_mismatched'] or (x['caption_pixels'] > 0) != (x['planned_page'] is not None)][:20])
        print(name, json.dumps({k: v for k, v in report['runs'][name].items() if k != 'failures'}), flush=True)
    report['passed'] = ok
    (work / 'report.json').write_text(json.dumps(report, indent=1, ensure_ascii=False) + '\n')
    print('PASS' if ok else 'FAIL')
    return 0 if ok else 1

def zs_thin(img):
    """Zhang-Suen thinning (1-pixel skeleton)."""
    img = img.copy().astype(np.uint8)
    changed = True
    while changed:
        changed = False
        for step in (0, 1):
            p = np.pad(img, 1)
            h, w = img.shape
            n = [p[1 + dy:1 + dy + h, 1 + dx:1 + dx + w] for dy, dx in ((-1, 0), (-1, 1), (0, 1), (1, 1), (1, 0), (1, -1), (0, -1), (-1, -1))]
            b = sum((x.astype(int) for x in n))
            seq = n + [n[0]]
            trans = sum((((seq[i] == 0) & (seq[i + 1] == 1)).astype(int) for i in range(8)))
            p2, p4, p6, p8 = (n[0], n[2], n[4], n[6])
            c = (p2 * p4 * p6 == 0) & (p4 * p6 * p8 == 0) if step == 0 else (p2 * p4 * p8 == 0) & (p2 * p6 * p8 == 0)
            kill = (img == 1) & (b >= 2) & (b <= 6) & (trans == 1) & c
            if kill.any():
                img[kill] = 0
                changed = True
    return img

def trace_guide(ch, guide_font, box=(1, 2, 15, 15), scale=12):
    """Draft 16x16 pens for ch: the guide font's outline at 12x the target size is reduced to a"""
    from PIL import Image, ImageDraw, ImageFont
    x0, y0, x1, y1 = box
    w, h = (x1 - x0, y1 - y0)
    font = ImageFont.truetype(str(guide_font), max(w, h) * scale)
    im = Image.new('L', (w * scale, h * scale), 0)
    ImageDraw.Draw(im).text((w * scale / 2, h * scale / 2), ch, fill=255, font=font, anchor='mm')
    sk = zs_thin(np.array(im) > 127)
    g = np.zeros((h, w), np.uint8)
    ys, xs = np.nonzero(sk)
    g[np.minimum(ys // scale, h - 1), np.minimum(xs // scale, w - 1)] = 1
    return pen_style(unstair(g), box)

def unstair(g):
    """Remove stair corners: a pixel whose only neighbors are one vertical and one horizontal"""
    g = g.copy()
    h, w = g.shape
    changed = True
    while changed:
        changed = False
        for y in range(h):
            for x in range(w):
                if not g[y, x]:
                    continue
                nb = [(dy, dx) for dy in (-1, 0, 1) for dx in (-1, 0, 1) if (dy or dx) and 0 <= y + dy < h and (0 <= x + dx < w) and g[y + dy, x + dx]]
                if len(nb) != 2:
                    continue
                (a, b), (c, d) = nb
                if {abs(a) + abs(b), abs(c) + abs(d)} == {1} and (a == 0) != (c == 0):
                    g[y, x] = 0
                    changed = True
    return g

def pen_style(g, box=(1, 2, 15, 15)):
    x0, y0, x1, y1 = box
    out = np.full((16, 16), 15)
    sub = out[y0:y1, x0:x1]
    sub[g == 1] = 1
    gg = np.pad(g, 1).astype(bool)
    hor = (gg[1:-1, :-2] | gg[1:-1, 2:]) & ~(gg[:-2, 1:-1] | gg[2:, 1:-1]) & (g == 1)
    sub[hor] = 2
    return out

def needed_new(gfx):
    man = load_manifest()
    gl = Glyphs(gfx)
    ja = sorted({ch for ln in man['lines'] for pg in ln['ja']['pages'] for row in pg for ch in row} - {' ', '\u3000'})
    return ([ch for ch in ja if JA_EQUIV.get(ch, ch) not in JA_ARCADE], gl)

def cmd_draft_glyphs(a):
    gfx = stock_gfx(a.rom_dir)
    need, gl = needed_new(gfx)
    if JA_GRIDS.exists() and (not a.force):
        need = [ch for ch in need if ch not in gl.ja_new]
    grids, meta = (dict(gl.ja_new), dict(gl.ja_meta)) if JA_GRIDS.exists() and (not a.force) else ({}, {})
    for ch in need:
        grids[ch] = trace_guide(ch, a.guide_font)
        meta[ch] = 'traced-draft'
    ASSETS.mkdir(parents=True, exist_ok=True)
    write_grids(JA_GRIDS, dict(sorted(grids.items(), key=lambda kv: ord(kv[0]))), meta, ['', '16x16, "." transparent, pens 1-5 as the arcade dialogue font (1 face, 2 horizontal strokes, 3-5 softer).', 'The builder bakes the dark outline; leave column 0/15 and rows 0-1/15 empty where possible.', 'Status after the character: traced-draft (guide trace, not yet cleaned) or hand-edited.'])
    print(f'{JA_GRIDS}: {len(grids)} glyphs ({len(need)} drafted now)')
    return 0

def cmd_sheet(a):
    from PIL import Image, ImageDraw, ImageFont
    gfx = stock_gfx(a.rom_dir)
    gl = Glyphs(gfx)
    arcade = {ch: G.get_tile(gfx, 128 * code, 16) for ch, code in JA_ARCADE.items()}
    pal = {i: tuple(((PALETTE[i] >> s & 15) * 17 for s in (8, 4, 0))) for i in range(16)}
    label_font = ImageFont.truetype(str(a.label_font), 14) if a.label_font else None

    def img(pens, scale, outline=False):
        cell = outlined_cell(pens, (0, 0) if pens.shape[0] == 16 else (1, 1)) if outline else pens
        h, w = cell.shape
        arr = np.zeros((h, w, 3), np.uint8)
        arr[:] = (40, 44, 52)
        for p, c in pal.items():
            if p != 15:
                arr[cell == p] = c
        return Image.fromarray(arr).resize((w * scale, h * scale), Image.NEAREST)

    def similar(pens, k=3):
        m = pens != 15
        best = []
        for ch, t in arcade.items():
            n = t != 15
            inter = (m & n).sum()
            union = (m | n).sum() or 1
            best.append((inter / union, ch))
        return [ch for _, ch in sorted(best, reverse=True)[:k]]
    items = list(gl.ja_new.items())
    a.out.mkdir(parents=True, exist_ok=True)
    cols, cw, ch_ = (2, 520, 92)
    rows = -(-len(items) // cols)
    sheet = Image.new('RGB', (cols * cw, rows * ch_ + 30), (24, 26, 31))
    d = ImageDraw.Draw(sheet)
    d.text((8, 8), 'New glyphs (1x, 4x, 4x outlined) | similar arcade glyphs (4x) - DRAFT for review', fill=(220, 220, 220))
    html = ['<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">', '<title>Strider EX caption glyphs</title><style>body{background:#181a1f;color:#e6e8ec;font:14px/1.4 system-ui;margin:0;padding:16px}table{border-collapse:collapse}td{padding:4px 8px;border-bottom:1px solid #333;vertical-align:middle}img{image-rendering:pixelated}.c{font-size:28px}</style>', '<h1>Strider EX caption glyphs (DRAFT)</h1><p>Each new glyph at 1x, 4x and 4x with the baked outline, next to the three most similar arcade dialogue glyphs (pixel overlap). Arcade glyphs are stock tiles 0x3620-0x36AA.</p><table>']
    tiles = a.out / 'tiles'
    tiles.mkdir(exist_ok=True)
    for i, (c, pens) in enumerate(items):
        x, y = (i % cols * cw, 30 + i // cols * ch_)
        if label_font:
            d.text((x + 6, y + 30), c, fill=(255, 255, 255), font=label_font)
        d.text((x + 24, y + 34), f"{ord(c):04X} {gl.ja_meta.get(c, '')}", fill=(150, 150, 150))
        sheet.paste(img(pens, 1), (x + 130, y + 36))
        sheet.paste(img(pens, 4), (x + 150, y + 8))
        sheet.paste(img(pens, 4, True), (x + 220, y + 8))
        sims = similar(pens)
        for j, s in enumerate(sims):
            sheet.paste(img(arcade[s], 4), (x + 300 + 70 * j, y + 8))
        names = []
        for tag, im in (('n1', img(pens, 1)), ('n4', img(pens, 4)), ('o4', img(pens, 4, True))):
            fn = f'{ord(c):04x}_{tag}.png'
            im.save(tiles / fn)
            names.append(fn)
        sim_names = []
        for s in sims:
            fn = f'arc_{JA_ARCADE[s]:04x}.png'
            if not (tiles / fn).exists():
                img(arcade[s], 4).save(tiles / fn)
            sim_names.append((s, fn))
        html.append(f"""<tr><td class="c">{c}</td><td>U+{ord(c):04X}<br>{gl.ja_meta.get(c, '')}</td>""" + ''.join((f'<td><img src="tiles/{n}" alt=""></td>' for n in names)) + ''.join((f'<td><img src="tiles/{n}" alt="{s}"><br>{s}</td>' for s, n in sim_names)) + '</tr>')
    for c, pens in gl.en_new.items():
        html.append(f'<tr><td class="c">{c}</td><td>English mark</td><td><img src="tiles/en_{ord(c):02x}.png"></td></tr>')
        img(pens, 4, True).save(tiles / f'en_{ord(c):02x}.png')
    html.append('</table>')
    sheet.save(a.out / 'glyph_review.png')
    allg = [(c, p) for c, p in items] + [(c, p) for c, p in gl.en_new.items()]
    per, sc = (12, 4)
    comp = Image.new('RGB', (per * (16 * sc + 8), -(-len(allg) // per) * (16 * sc + 26)), (24, 26, 31))
    dc = ImageDraw.Draw(comp)
    for i, (c, pens) in enumerate(allg):
        x, y = (i % per * (16 * sc + 8), i // per * (16 * sc + 26))
        comp.paste(img(pens, sc, True), (x + 4, y + 22))
        dc.text((x + 4, y + 2), f'{ord(c):04X} {c}' if label_font is None else c, fill=(255, 220, 120), font=label_font)
    comp.save(a.out / 'glyphs.png')
    (a.out / 'glyph_review.html').write_text('\n'.join(html) + '\n', encoding='utf-8')
    print(a.out / 'glyph_review.png', len(items), 'glyphs')
    return 0

def self_test(rom_dir=None):
    cell = outlined_cell(np.full((8, 8), 1), (1, 1))
    assert (cell[1:9, 1:9] == 1).all() and cell[0, 0] == OUTLINE and (cell[9, 9] == OUTLINE) and (cell[10, 10] == 15)
    assert JA_ARCADE['ス'] == 13909 and JA_ARCADE['子'] == 13994
    assert [len(x) for x in wrap_ja('あ' * 20)] == [10, 10] and wrap_ja('あいう') == ['あいう']
    assert pages_of(['a', 'b', 'c']) == [['a', 'b'], ['c']]
    inc = captions_inc([dict(id='x')], {'x': {'ja': [(5, 0), (9, None)], 'en': [], 'en_dub': [(7, 0)]}, 'card': {'en': [], 'ja': []}}, [('en', [(1, 2, 3, 4)], 'tr0', ['A'])], None)
    assert 'cap_dub:' in inc and 'dc.l    cap_x_en_dub,cap_x_en_dub' in inc and ('cap_x_en_dub:\n        dc.w    7' in inc)
    import caption_pacing as CP
    CP.self_test()
    g = np.zeros((13, 14), np.uint8)
    g[5, 2:10] = 1
    g[2:12, 6] = 1
    p = pen_style(g)
    assert p[7, 3] == 2 and p[5, 7] == 1 and (p[0, 0] == 15)
    for name, hooks in ASM_HOOKS.items():
        text = (HERE / 'asm' / name).read_text()
        for h in hooks:
            assert text.count(h) == 1, (name, h)
    lower, meta = read_grids(EN_LOWER, EN_LOWER_SHAPE)
    assert sorted(lower) == [chr(c) for c in range(97, 123)] and set(meta.values()) == {'hand-drawn'}
    for ch, g in lower.items():
        assert set(g.flat) <= {0, 1, 15}, ch
        assert ((g[8:] != 15).any() or (g[7] == 1).any()) == (ch in 'gjpqy'), ch
    try:
        read_grids(EN_LOWER)
        raise AssertionError('read_grids accepted a non-square grid without a shape')
    except SystemExit:
        pass
    g = outlined_cell(np.where(lower['g'] == 0, 7, lower['g']), (1, 1))
    assert (g[10] != 15).any() and (g[11] == OUTLINE).any() and (g[12:] == 15).all()
    assert EN_PITCH + EN_DESCENT == 13 and EN_INK + EN_DESCENT == 12
    assert cased_pages("It's too late, Strider!", [["IT'S TOO LATE,", 'STRIDER!']]) == [["It's too late,", 'Strider!']]
    assert cased_pages('His name…', [['HIS NAME...']]) == [['His name...']]
    for text, pages in (('You go.', [['YOU GO!']]), ('You go no further.', [['YOU GO', 'FURTHER.']]), ('A dark ruler', [['A DARKRULER']])):
        try:
            cased_pages(text, pages)
            raise AssertionError(f'cased_pages accepted {pages} for {text!r}')
        except ValueError:
            pass
    assert {'a', 'z', "'", ':', '"', 'A', '9', '&'} <= en_charset() and '@' not in en_charset()
    man = load_manifest()
    assert any((ch.islower() for ln in man['lines'] for pg in ln['en']['pages'] for r in pg for ch in r))
    if rom_dir:
        gfx = stock_gfx(Path(rom_dir) / 'striderua')
        caps = Captions(gfx, man, [('en', 'Select Stage'), ('en', '1  Third Moon'), ('en', 'SELECT STAGE'), ('en', '1  THIRD MOON')])
        pg = man['lines'][1]['en']['pages'][0]
        e = caps.page_entries('en', pg)
        assert len(pg) == 2 and e[-1][1] - 16 == BOTTOM - EN_INK - EN_DESCENT, e[-1]
        assert {y for _, y, _, _ in e} == {e[-1][1] - EN_PITCH - EN_DESCENT, e[-1][1]}
        assert {y for _, y, _, _ in caps.page_entries('en', ['SELECT STAGE', '1  THIRD MOON'], BOTTOM, 0)} == {BOTTOM - EN_INK + 16 - EN_PITCH, BOTTOM - EN_INK + 16}, 'capitals-only metrics'
        assert STILL_DESCENT == EN_DESCENT
        assert {y for _, y, _, _ in caps.page_entries('en', ['Select Stage', '1  Third Moon'], BOTTOM, STILL_DESCENT)} == {y for _, y, _, _ in e}, "the stage select takes the captions' metrics"
        bottom, first, last = caps.still_bottom([['Select Stage', '1  Third Moon']], 192, 32)
        assert 192 <= first and last <= 223 and (first - 192 - (223 - last) in (0, -1)), (bottom, first, last)
        try:
            caps.page_entries('en', pg, BOTTOM, 0)
            raise AssertionError('lower case accepted on a page without descender room')
        except SystemExit:
            pass
        region = bytearray(4 << 20)
        caps.install(region)
        detail = [dict(lang='en', line=man['lines'][1]['id'], page=pg, entries=[list(x) for x in e])]
        rep = dict(pages_detail=detail, still_text=None)
        assert source_check(rep, region, gfx) == (True, [])
        code = e[0][2]
        G.put_tile(region, G.ex_offset('obj', code), np.where(caps.cells[code] == 1, 7, caps.cells[code]))
        assert not source_check(rep, region, gfx)[0], 'source_check missed a changed glyph'
        bad = dict(pages_detail=[dict(detail[0], entries=[[x[0], x[1] + 2, x[2], x[3]] for x in e])], still_text=None)
        assert not source_check(bad, bytearray(4 << 20), gfx)[0], 'source_check missed a moved page'
        upper = dict(pages_detail=[dict(detail[0], page=[r.upper() for r in pg])], still_text=None)
        assert not source_check(upper, region, gfx)[0], 'source_check missed an upper-case page'
    print('subtitle_ex self-test passed' + (' (with the fonts)' if rom_dir else ''))
    return 0

def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('--self-test', action='store_true')
    p.add_argument('--rom-dir', dest='test_rom_dir', type=Path, help='with --self-test: stock sets (the font checks)')
    sub = p.add_subparsers(dest='cmd')
    s = sub.add_parser('init-manifest')
    s = sub.add_parser('mixed-case', help='re-case the English pages from the approved text')
    s = sub.add_parser('draft-glyphs')
    s.add_argument('--rom-dir', type=Path, required=True, help='striderua graphics ROMs')
    s.add_argument('--guide-font', type=Path, required=True, help='a Japanese font used only as a tracing guide')
    s.add_argument('--force', action='store_true', help='retrace every glyph (discards hand edits)')
    s = sub.add_parser('sheet')
    s.add_argument('--rom-dir', type=Path, required=True)
    s.add_argument('--label-font', type=Path, help='font for the character labels on the PNG')
    s.add_argument('--out', type=Path, required=True)
    s = sub.add_parser('measure-codes')
    s.add_argument('--census', type=Path, required=True)
    s.add_argument('--scenes', default='prologue,brief_st_petersburg,intro_desert,brief_siberia,brief_aerial,brief_amazon,flight,welcome_meio,ending')
    s.add_argument('--out', type=Path)
    s = sub.add_parser('gate')
    s.add_argument('--build', type=Path, required=True)
    s.add_argument('--runtime', type=Path, required=True)
    s.add_argument('--hbmame', type=Path, required=True)
    s.add_argument('--rom-dir', type=Path, required=True)
    s.add_argument('--workdir', type=Path, required=True)
    s.add_argument('--stage', type=int, default=0)
    s.add_argument('--frames', type=int, default=7000)
    s.add_argument('--runs', help='comma list of GATE_RUNS names (default all four)')
    a = p.parse_args()
    if a.self_test:
        return self_test(a.test_rom_dir)
    return {'init-manifest': cmd_init_manifest, 'draft-glyphs': cmd_draft_glyphs, 'sheet': cmd_sheet, 'gate': cmd_gate, 'measure-codes': cmd_measure_codes, 'mixed-case': cmd_mixed_case}[a.cmd](a)
if __name__ == '__main__':
    sys.exit(main())
