"""The boss scenes' Japanese glyphs: the characters of the approved boss lines that no EX font has."""
import argparse
import json
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
import subtitle_ex as S
HERE = Path(__file__).resolve().parents[1]
REVIEW = HERE / 'manifests/portrait_text_review.json'
ASSETS = HERE / 'assets/boss_font'
GRIDS = ASSETS / 'ja_glyphs.txt'
HEADER = ['', '16x16, "." transparent, pens 1-5 as the arcade dialogue font (1 face, 2 horizontal strokes, 3-5 softer).', 'The builder bakes the dark outline; leave column 0/15 and rows 0-1/15 empty where possible.', 'Status after the character: traced-draft (guide trace, not yet cleaned) or hand-edited.']

def page_chars():
    man = json.loads(REVIEW.read_text(encoding='utf-8'))
    return sorted({ch for ln in man['lines'] for pg in ln['ja_pages'] for row in pg for ch in row} - {' ', '\u3000'})

def needed():
    caption, _ = S.read_grids(S.JA_GRIDS)
    return [ch for ch in page_chars() if S.JA_EQUIV.get(ch, ch) not in S.JA_ARCADE and ch not in caption]

def cmd_draft(a):
    grids, meta = S.read_grids(GRIDS) if GRIDS.exists() else ({}, {})
    new = [ch for ch in needed() if ch not in grids]
    for ch in new:
        grids[ch] = S.trace_guide(ch, a.guide_font)
        meta[ch] = 'traced-draft'
    ASSETS.mkdir(parents=True, exist_ok=True)
    S.write_grids(GRIDS, dict(sorted(grids.items(), key=lambda kv: ord(kv[0]))), meta, HEADER)
    print(f'{GRIDS}: {len(grids)} glyphs ({len(new)} drafted now)')
    return 0

def cmd_sheet(a):
    S.JA_GRIDS = GRIDS
    return S.cmd_sheet(a)

def self_test():
    need = needed()
    grids, meta = S.read_grids(GRIDS)
    missing = [ch for ch in need if ch not in grids]
    assert not missing, f"boss_glyphs: no glyph for {''.join(missing)} (run draft)"
    extra = [ch for ch in grids if ch not in need]
    assert not extra, f"boss_glyphs: grids for characters the lines do not need: {''.join(extra)}"
    for ch, g in grids.items():
        assert g.shape == (16, 16) and set(g.flat) <= {1, 2, 3, 4, 5, 15}, ch
        assert meta[ch] in ('traced-draft', 'hand-edited'), (ch, meta[ch])
    print(f'boss_glyphs self-test passed: {len(page_chars())} characters, {len(grids)} from {GRIDS.name}')
    return 0

def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('--self-test', action='store_true')
    sub = p.add_subparsers(dest='cmd')
    s = sub.add_parser('draft')
    s.add_argument('--guide-font', type=Path, required=True, help='a Japanese font used only as a tracing guide')
    s = sub.add_parser('sheet')
    s.add_argument('--rom-dir', type=Path, required=True)
    s.add_argument('--label-font', type=Path)
    s.add_argument('--out', type=Path, required=True)
    a = p.parse_args()
    if a.self_test:
        return self_test()
    if not a.cmd:
        p.error('a command or --self-test')
    return {'draft': cmd_draft, 'sheet': cmd_sheet}[a.cmd](a)
if __name__ == '__main__':
    sys.exit(main())
