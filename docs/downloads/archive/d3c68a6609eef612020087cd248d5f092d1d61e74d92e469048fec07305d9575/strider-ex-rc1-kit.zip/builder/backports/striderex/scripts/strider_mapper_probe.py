"""P0.6: verify the Strider EX graphics mapper in HBMAME."""
import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import zlib
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
ROOT = Path(__file__).resolve().parents[3]
LUA = ROOT / 'backports/striderex/lua/mapper_probe.lua'
DEBUG_START = ROOT / 'backports/striderex/lua/arcade_debug_start.lua'
MB = 1048576
SPR, S1, S2, S3, STARS = (1, 2, 4, 8, 16)
ST24M1 = ([32768, 32768, 0, 0], [(STARS, 0, 1023, 0), (SPR, 0, 20479, 0), (S2, 16384, 32767, 0), (S3, 0, 32767, 1), (S1, 28672, 32767, 1)])
STREX = ([32768, 32768, 65536, 0], ST24M1[1] + [(SPR | S2, 65536, 98303, 2), (S1, 32768, 49151, 2), (S3, 114688, 131071, 2)])
STRIDER_KEY_CRC = '39065af5'
BOARDS = {'CPS_B_01': bytes([255, 0, 0, 255, 255, 255, 255]), 'CPS_B_21_DEF': bytes([50, 255, 255, 0, 2, 4, 6])}

def cps1_key(mapper, board='CPS_B_01'):
    """HBMAME's 128-byte CPS-1 key: 'U', then CPS-B config (Strider's boards"""
    sizes, ranges = mapper
    b = bytearray(b'U')
    b += BOARDS[board]
    b += bytes([38, 40, 42, 44, 46, 48])
    b += bytes([2, 4, 8, 48, 48])
    b += bytes(3 + 2 + 3)
    for size in sizes:
        b += size.to_bytes(3, 'little')
    for i in range(8):
        t, start, end, bank = ranges[i] if i < len(ranges) else (0, 0, 0, 0)
        b += bytes([t | bank << 6]) + start.to_bytes(3, 'little') + end.to_bytes(3, 'little')
    return bytes(b) + bytes(128 - len(b))
TESTS = {'scroll1': (28672, 45056, 1024), 'scroll2': (8192, 40960, 1024), 'scroll3': (0, 14336, 512), 'sprites': (0, 32768, 84)}

def rom_entries(driver_text, set_name):
    start = driver_text.index(f'ROM_START( {set_name} )')
    block = driver_text[start:driver_text.index('ROM_END', start)]
    return re.findall('ROM_LOAD\\w*\\(\\s*"([^"]+)",\\s*(0x[0-9a-f]+),\\s*(0x[0-9a-f]+),\\s*(?:CRC\\(([0-9a-f]+)\\)|NO_DUMP)', block)

def stock_files(rom_dirs):
    """{crc32: bytes} for every file in the stock set directories or archives."""
    out = {}
    for d in rom_dirs:
        for p in d.rglob('*'):
            if p.is_file():
                b = p.read_bytes()
                out[f'{zlib.crc32(b):08x}'] = b
    return out

def stage(driver_text, rom_dirs, work):
    """striderua from the stock files; striderex from the same plus the"""
    import mapper_testkit as K
    pool = stock_files(rom_dirs)
    kit = {}
    kit['strex_14.8h'], kit['strex_p6.bin'], _ = K.twin_program(pool[K.DATA_ROM_CRC])
    kit.update(zip(K.EX_GFX, K.twin_gfx(pool)))
    kit['striderex.key'] = cps1_key(STREX)
    roms = work / 'roms'
    for set_name in ('striderua', 'striderex'):
        d = roms / set_name
        d.mkdir(parents=True, exist_ok=True)
        for name, offset, size, crc in rom_entries(driver_text, set_name):
            data = pool.get(crc) if crc else kit.get(name) if set_name == 'striderex' else None
            if data is None and name == 'strider.key':
                data = cps1_key(ST24M1)
                if f'{zlib.crc32(data):08x}' != STRIDER_KEY_CRC:
                    sys.exit('regenerated strider.key does not match HBMAME (CRC 39065af5)')
            if data is None:
                sys.exit(f'{set_name}/{name}: no stock file with CRC {crc}')
            (d / name).write_bytes(data)
    digest = hashlib.sha256(b''.join((kit[n] for n in sorted(kit)))).hexdigest()
    return (roms, digest)

def run(binary, roms, work, name, machine, fill='none', base=0, span=1, extra=None):
    d = work / name
    d.mkdir(parents=True, exist_ok=True)
    env = dict(os.environ, SDL_VIDEODRIVER='dummy', SDL_AUDIODRIVER='dummy', STREX_PREFIX=str(d / 'run'), STREX_STAGE='0', STREX_AREA='0', STREX_INVINCIBLE='1', STREX_END='99999', STREX_DEBUG_START=str(DEBUG_START), STREX_FILL=fill, STREX_FILL_BASE=str(base), STREX_FILL_SPAN=str(span), STREX_SNAP=str(d / 'snap.png'))
    env.update(extra or {})
    cmd = [str(binary), machine, '-rompath', str(roms), '-nothrottle', '-video', 'none', '-sound', 'none', '-skip_gameinfo', '-noautosave', '-cfg_directory', str(d / 'cfg'), '-nvram_directory', str(d / 'nv'), '-snapshot_directory', str(d), '-autoboot_script', str(LUA)]
    p = subprocess.run(cmd, env=env, cwd=d, capture_output=True, text=True, timeout=600)
    (d / 'mame.log').write_text(p.stdout + p.stderr)
    if p.returncode or not (d / 'snap.png').exists():
        sys.exit(f"{name}: exit {p.returncode}, see {d / 'mame.log'}")
    return d / 'snap.png'

def pixels(png):
    from PIL import Image
    return Image.open(png).convert('RGB').tobytes()

def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('--runtime', type=Path, required=True, help='build_hbmame_probe.py output directory')
    p.add_argument('--rom-dir', type=Path, action='append', required=True, help='stock striderua and strider set directories (repeat)')
    p.add_argument('--workdir', type=Path, required=True)
    a = p.parse_args()
    info = json.loads((a.runtime / 'runtime.json').read_text())
    binary = Path(info['binary'])
    driver = (a.runtime / 'source/src/hbmame/drivers/cps1.cpp').read_text()
    a.workdir.mkdir(parents=True, exist_ok=True)
    roms, ex_sha = stage(driver, [d.resolve() for d in a.rom_dir], a.workdir)
    blank = a.workdir / 'roms_blank'
    shutil.rmtree(blank, ignore_errors=True)
    shutil.copytree(roms, blank)
    for f in (blank / 'striderex').glob('strex_gfx.*'):
        f.write_bytes(bytes(f.stat().st_size))
    jobs = {'stock_none': ('striderua', 'none', 0, 1), 'ex_none': ('striderex', 'none', 0, 1)}
    play = {}
    for st in range(5):
        for fr in (2000, 2600):
            env = dict(STREX_STAGE=str(st), STREX_FREEZE_FRAME='999999', STREX_FILL_FRAME='999999', STREX_SNAP_FRAME=str(fr))
            for tag, machine, path in (('stock', 'striderua', roms), ('ex', 'striderex', roms), ('blank', 'striderex', blank)):
                play[f'play{st}_{fr}_{tag}'] = (machine, path, env)
    for layer, (stock, twin, span) in TESTS.items():
        jobs[f'{layer}_stock'] = ('striderex', layer, stock, span)
        jobs[f'{layer}_ex'] = ('striderex', layer, twin, span)
        jobs[f'{layer}_shift'] = ('striderex', layer, stock + 1, span)
    with ThreadPoolExecutor(6) as ex:
        snaps = dict(zip(jobs, ex.map(lambda k: run(binary, roms, a.workdir, k, *jobs[k]), jobs)))
        snaps.update(zip(play, ex.map(lambda k: run(binary, play[k][1], a.workdir, k, play[k][0], extra=play[k][2]), play)))
    px = {k: pixels(v) for k, v in snaps.items()}
    checks = [('stock rendering unchanged', 'stock_none', 'ex_none', True)]
    for layer in TESTS:
        checks += [(f'{layer}: EX twins match stock', f'{layer}_stock', f'{layer}_ex', True), (f'{layer}: control, codes shifted by one', f'{layer}_stock', f'{layer}_shift', False), (f'{layer}: control, fill visible', f'{layer}_stock', 'ex_none', False)]
    for k in sorted({k.rsplit('_', 1)[0] for k in play}):
        checks += [(f'{k}: gameplay on EX twins matches stock', f'{k}_stock', f'{k}_ex', True), (f'{k}: control, blank EX graphics', f'{k}_ex', f'{k}_blank', False)]
    rows, ok = ([], True)
    for label, x, y, want_equal in checks:
        equal = px[x] == px[y]
        passed = equal == want_equal
        ok &= passed
        rows.append(dict(check=label, a=x, b=y, equal=equal, expected_equal=want_equal, passed=passed))
        print(f"{('PASS' if passed else 'FAIL')}  {label}: {('identical' if equal else 'different')}")
    report = dict(runtime=info, ex_region_sha256=ex_sha, tests={k: list(v) for k, v in TESTS.items()}, snapshots={k: hashlib.sha256(v.read_bytes()).hexdigest() for k, v in snaps.items()}, checks=rows)
    (a.workdir / 'report.json').write_text(json.dumps(report, indent=1) + '\n')
    print('PASS' if ok else 'FAIL')
    return 0 if ok else 1
if __name__ == '__main__':
    sys.exit(main())
