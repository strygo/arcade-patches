"""Keep boss portraits continuous between pages and tighten dialogue rows."""
import argparse
from copy import deepcopy
import json
from pathlib import Path
import re
import struct
import subprocess
import sys
import boss_scene as S
import boss_scene_binary as B
from boss_voice_gate import inventory, sha
ENTRY = 2094848
PAL = 2095616
ORIGINAL_SHA = 'f5a7ba982edb35dd232dcb11d762d2ed16b03eb2bb5420ac8d81ca21de4a378f'
PREFIX = bytes.fromhex('48e7fef8247900fff9d4')
ASM = Path(__file__).resolve().parents[1] / 'asm/boss_scene.s'

def symbols(raw):
    hits = [i for i in range(0, len(raw) - 332, 2) if raw[i:i + len(PREFIX)] == PREFIX]
    if len(hits) != 1 or sha(raw[hits[0]:hits[0] + 332]) != ORIGINAL_SHA:
        raise ValueError('original boss frame preparation differs')
    at = hits[0] + B.BASE
    return dict(bs_nextbuf=at + 332, bs_gamepal=at + 366, bs_blackpal=at + 440, bs_picture=at + 542, bs_list=at + 588, original=at)

def assembly(bindings):
    src = ASM.read_text()
    constants = src[src.index('BS_VARS  equ'):src.index('; ------------------------------------------------------------ the VBlank')]
    model = {'FADE_IN': S.FADE_IN, 'FADE_OUT': S.FADE_OUT, 'MUSIC_WAIT': S.MUSIC_WAIT, 'HIDE': S.HIDE, 'NEXT': S.NEXT, 'HOLD_FROM': S.HOLD_FROM, 'FADE_CMD': S.FADE_CMD, 'STOP_CMD': S.STOP_CMD, 'LAYER_HIDE': S.LAYER_HIDE, 'LAYER_PAGE': S.LAYER_PAGE, 'UI_SLOT': S.UI_SLOT, 'PT_SLOT': S.PT_SLOT, 'UI_FADE': S.UI_FADE, 'PT_FADE': S.PT_FADE}
    constants += '\nFLAGS equ $1FFFF0\nPACK equ 0\n'
    constants += ''.join((f'BS_{k} equ ${v:X}\n' for k, v in model.items()))
    constants += ''.join((f'{k} equ ${v:X}\n' for k, v in bindings.items() if k != 'original'))
    prep = src[src.index('bs_prep:\n'):src.index('; bs_nextbuf:')]
    pal = src[src.index('bs_pagepal:\n'):src.index('; bs_picture:')]
    for label in bindings:
        prep = re.sub('\\bbsr(?:\\.s)?\\s+' + label + '\\b', 'jsr     ' + label, prep)
        pal = re.sub('\\bbsr(?:\\.s)?\\s+' + label + '\\b', 'jsr     ' + label, pal)
    return constants + f'\n        org ${ENTRY:X}\n' + prep + f'\n        org ${PAL:X}\n' + pal

def row_changes(raw, machine):
    """Move second-row sprites and masks together; no text or bitmap edit."""
    b = bytearray(raw)
    changes = []
    delta = 16 if machine == 'striderua' else 8
    for scene in B.scenes(b):
        for p in scene['pages']:
            n = B.word(b, p + 42)
            if n != 2:
                continue
            first, second = (B.word(b, p + 46), B.word(b, p + 58))
            if second - first != 32:
                raise ValueError('unexpected boss reveal row pitch')
            pos = p + 44 + 12 * n
            ents = []
            for group in range(2):
                count = B.word(b, pos)
                pos += 2
                for _ in range(count):
                    if group == 1:
                        ents.append(pos)
                    pos += 8
            ys = sorted({B.word(b, e + 2) for e in ents[1:]})
            if len(ys) != 2 or ys[1] - ys[0] != 32:
                raise ValueError('unexpected boss text row placement')
            for at in [p + 58] + [e + 2 for e in ents[1:] if B.word(b, e + 2) == ys[1]]:
                old = B.word(b, at)
                struct.pack_into('>H', b, at, old - delta)
                changes.append(dict(scene=scene['id'], page=B.BASE + p, address=B.BASE + at, before=old, after=old - delta))
    return (bytes(b), changes)

def patch(raw, machine, helper):
    bind = symbols(raw)
    b, rows = row_changes(raw, machine)
    b = bytearray(b)
    off = ENTRY - B.BASE
    if not helper or len(helper) > 2048 or b[off:off + len(helper)] != b'\xff' * len(helper):
        raise ValueError('boss paging allocation occupied or oversized')
    at = bind['original'] - B.BASE
    before = b[at:at + 6].hex()
    b[at:at + 6] = b'N\xf9' + ENTRY.to_bytes(4, 'big')
    b[off:off + len(helper)] = helper
    return (bytes(b), dict(original_at=bind['original'], original_prefix=before, helper_at=ENTRY, helper_bytes=len(helper), helper_sha256=sha(helper), row_pitch=16 if machine == 'striderua' else 24, changes=rows, continuous_portrait=True))

def audit(control, build):
    cm, old = inventory(control)
    meta, new = inventory(build)
    for m, s in meta['sets'].items():
        spec = s['boss_paging']
        p = new[m]['strex_p6.bin']
        b = bytearray((p[i ^ 1] for i in range(len(p))))
        if spec['source_files'] != cm['sets'][m]['files']:
            raise ValueError('paging source inventory differs')
        for n in old[m]:
            if n != 'strex_p6.bin' and old[m][n] != new[m][n]:
                raise ValueError('another ROM changed')
        off = ENTRY - B.BASE
        helper = b[off:off + spec['helper_bytes']]
        expected, report = patch(bytes((old[m]['strex_p6.bin'][i ^ 1] for i in range(len(p)))), m, helper)
        if expected != b or sha(helper) != spec['helper_sha256']:
            raise ValueError('unexpected paging ROM bytes')
        if report['changes'] != spec['changes']:
            raise ValueError('unexpected paging geometry')
    return meta

def main():
    if sys.argv[1:] == ['--self-test']:
        b = bytearray(b'\xff' * 2048)
        for k in range(8):
            at = 64 + 148 * k
            struct.pack_into('>I', b, 4 * k, B.BASE + at)
            struct.pack_into('>4H', b, at, 200, 184 + k, 192 + k, 0)
            struct.pack_into('>I', b, at + 48, B.BASE + 32)
            pg = at + 52
            struct.pack_into('>I3H16HH', b, pg, 0, 80, 97, 108, *[61440] * 16, 2)
            for i in range(2):
                struct.pack_into('>6H', b, pg + 44 + 12 * i, 104, 178 + 32 * i, 1024, 0, 128, 16)
            pos = pg + 68
            struct.pack_into('>HH', b, pos, 0, 3)
            pos += 4
            for i, y in enumerate((68, 184, 216)):
                struct.pack_into('>4H', b, pos + 8 * i, 104, y, 46592 + i, 12)
        for m, delta in (('striderua', 16), ('striderjr', 8)):
            new, changes = row_changes(b, m)
            assert len(changes) == 16 and all((r['before'] - r['after'] == delta for r in changes))
            for k in range(8):
                assert B.word(new, 64 + 148 * k + 52 + 70 + 2 + 2) == 68
        bad = bytearray(b)
        struct.pack_into('>H', bad, 64 + 52 + 58, 211)
        try:
            row_changes(bad, 'striderua')
        except ValueError:
            pass
        else:
            raise AssertionError('foreign row pitch accepted')
        print('Boss paging row guards PASS: eight scenes, both pitches, altered source rejected')
        return
    p = argparse.ArgumentParser(description=__doc__)
    for n in ('build', 'vasm', 'out'):
        p.add_argument('--' + n, type=Path, required=True)
    a = p.parse_args()
    a.out = a.out.resolve()
    meta, files = inventory(a.build)
    rep = deepcopy(meta)
    a.out.mkdir(parents=True, exist_ok=False)
    for m, f in files.items():
        p6 = f['strex_p6.bin']
        raw = bytes((p6[i ^ 1] for i in range(len(p6))))
        src = a.out / (m + '-paging.s')
        src.write_text(assembly(symbols(raw)))
        binary = src.with_suffix('.bin')
        subprocess.run([str(a.vasm), '-Fbin', '-m68000', '-quiet', '-o', str(binary), str(src)], check=True)
        b, report = patch(raw, m, binary.read_bytes())
        f = dict(f, **{'strex_p6.bin': bytes((b[i ^ 1] for i in range(len(b))))})
        target = a.out / m
        target.mkdir()
        for n, data in f.items():
            (target / n).write_bytes(data)
        rep['sets'][m]['files'] = {n: sha(data) for n, data in f.items()}
        report['source_files'] = meta['sets'][m]['files']
        rep['sets'][m]['boss_paging'] = report
        print(m, 'continuous portrait;', report['row_pitch'], 'pixel row pitch;', len(report['changes']), 'data words')
    (a.out / 'build.json').write_text(json.dumps(rep, indent=2) + '\n')
    audit(a.build, a.out)
if __name__ == '__main__':
    main()
