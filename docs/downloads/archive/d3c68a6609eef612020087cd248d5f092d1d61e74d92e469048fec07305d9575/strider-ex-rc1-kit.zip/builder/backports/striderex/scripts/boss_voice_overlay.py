"""Append English boss recordings to a verified CPS+ pack without recoding it."""
import argparse
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import sys
import wave
import numpy as np
ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT))
from cpsplus.pack.format import PackReader, PackWriter, TrackMeta, TriggerRow, CODEC_PCM, VERB_PLAY, VERB_NONE
import boss_scene_binary as BB

def sha(b):
    return hashlib.sha256(b).hexdigest()

def copy_writer(reader):
    h = reader.header
    w = PackWriter(deepcopy(h.proto), title=h.title, trigger_rows=h.trigger_rows, default_rate=h.default_rate, xfade_samples=h.xfade_samples)
    w.triggers = deepcopy(reader.triggers)
    for i, t in enumerate(reader.tracks):
        w.add_track(reader.read_track(i), deepcopy(t))
    return w

def overlay(a):
    if a.out.exists():
        raise ValueError('use a fresh pack path')
    a.out.parent.mkdir(parents=True, exist_ok=True)
    rd = PackReader(a.pack)
    if not all(rd.crc_check()):
        raise ValueError('input pack CRC mismatch')
    w = copy_writer(rd)
    replay = a.out.parent / (a.out.name + '.replay')
    w.write(replay, sidecar=False)
    if replay.read_bytes() != a.pack.read_bytes():
        raise ValueError('source pack does not reconstruct byte-for-byte')
    replay.unlink()
    assets = json.loads((a.voices / 'voices.json').read_text())
    if [r['id'] for r in assets['voices']] != list(BB.IDS):
        raise ValueError('need all eight ordered English voices')
    rows = []
    for i, r in enumerate(assets['voices']):
        cue = 192 + i
        if rd.triggers[cue].verb != VERB_NONE:
            raise ValueError('English cue already occupied')
        path = a.voices / r['master_file']
        if sha(path.read_bytes()) != r['master_sha256']:
            raise ValueError('master identity changed')
        with wave.open(str(path), 'rb') as f:
            if f.getframerate() != 48000 or f.getnchannels() != 1 or f.getsampwidth() != 2:
                raise ValueError('unexpected voice master format')
            mono = np.frombuffer(f.readframes(f.getnframes()), '<i2')
        stereo = np.stack([mono, mono], 1).astype('<i2').tobytes()
        index = w.add_track(stereo, TrackMeta(sample_rate=48000, channels=2, codec=CODEC_PCM, gain=127, name='boss_' + r['id'] + '_en', source='durable English boss take'))
        gain = rd.triggers[184 + i].gain
        w.set_trigger(cue, TriggerRow(verb=VERB_PLAY, track=index, gain=gain, suppress=1))
        rows.append(dict(id=r['id'], cue=hex(cue), track=index, samples=len(mono), seconds=len(mono) / 48000, pcm_sha256=sha(stereo), master_sha256=r['master_sha256'], trigger_gain=gain))
    w.write(a.out)
    new = PackReader(a.out)
    if not all(new.crc_check()) or len(new.tracks) != len(rd.tracks) + 8:
        raise ValueError('new pack validation failed')
    for i in range(len(rd.tracks)):
        if new.read_track(i) != rd.read_track(i):
            raise ValueError('existing track changed')
    for i, (x, y) in enumerate(zip(rd.triggers, new.triggers)):
        if not 192 <= i <= 199 and x.pack() != y.pack():
            raise ValueError('unrelated trigger changed')
    receipt = dict(schema='striderex-boss-voice-pack-overlay/1', passed=True, source_pack_sha256=sha(a.pack.read_bytes()), pack_sha256=sha(a.out.read_bytes()), old_pack_reconstructed_exactly=True, original_tracks_preserved=True, original_trigger_rows_preserved=True, asset_receipt_sha256=sha((a.voices / 'voices.json').read_bytes()), voices=rows, full_quality_stereo_pcm=True, hardware_review_granted=False)
    a.out.with_suffix('.boss-voices.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print('PASS: eight full-quality English rows; every original track and unrelated trigger preserved')

def main():
    if sys.argv[1:] == ['--self-test']:
        from tempfile import TemporaryDirectory
        from types import SimpleNamespace
        from cpsplus.pack.format import Protocol, DIALECT_CPS1_BYTE
        import boss_voice_assets as A
        scratch = Path(__file__).resolve().parents[1] / 'work'
        if not scratch.is_dir():
            raise ValueError('mounted project scratch is missing')
        with TemporaryDirectory(prefix='boss-pack-selftest-', dir=scratch) as t:
            root = Path(t)
            voices = root / 'voices'
            voices.mkdir()
            w = PackWriter(Protocol(game_id='strider', dialect=DIALECT_CPS1_BYTE, control_region_start=240), title='Synthetic boss overlay fixture', trigger_rows=256)
            w.add_track(bytes(128), TrackMeta(sample_rate=48000, channels=2, codec=CODEC_PCM))
            for i in range(8):
                w.set_trigger(184 + i, TriggerRow(verb=VERB_PLAY, track=0, suppress=1))
            w.write(root / 'base.cpk', sidecar=False)
            rows = []
            for lid in BB.IDS:
                data = A.wav_bytes(np.sin(np.arange(96) * 0.1) * 0.1)
                path = voices / (lid + '.wav')
                path.write_bytes(data)
                rows.append(dict(id=lid, master_file=path.name, master_sha256=sha(data)))
            (voices / 'voices.json').write_text(json.dumps(dict(voices=rows)))
            overlay(SimpleNamespace(pack=root / 'base.cpk', voices=voices, out=root / 'english.cpk'))
            rd = PackReader(root / 'english.cpk')
            assert rd.read_track(0) == bytes(128) and len(rd.tracks) == 9
            assert all((rd.triggers[192 + i].suppress == 1 for i in range(8)))
            try:
                overlay(SimpleNamespace(pack=root / 'english.cpk', voices=voices, out=root / 'duplicate.cpk'))
            except ValueError as e:
                assert 'already occupied' in str(e)
            else:
                raise AssertionError('an occupied English cue was overwritten')
        print('Pack overlay self-test PASS: exact baseline, eight rows, occupied cues rejected')
        return
    p = argparse.ArgumentParser(description=__doc__)
    for n in ('pack', 'voices', 'out'):
        p.add_argument('--' + n, type=Path, required=True)
    overlay(p.parse_args())
if __name__ == '__main__':
    main()
