"""Give only the desert a continuous SCROLL3 slope-following state."""
import argparse
from copy import deepcopy
import json
from pathlib import Path
import struct
import subprocess
from asm_payload import command as assembly_command
import sys
import respawn_fix as R
from boss_voice_gate import inventory, sha
ENTRY = 2048000
INIT = 2048768
ASM = Path(__file__).resolve().parents[1] / 'asm/desert_motion.s'
PREFIX = bytes.fromhex('41ed8fec102800024880227b00164e91')
STEP = bytes.fromhex('43fa00c420315000')

def model(image, bank):
    hits = [a for a in range(118784, 123904, 2) if image[a:a + len(PREFIX)] == PREFIX]
    if len(hits) != 1:
        raise ValueError('native SCROLL3 dispatcher differs')
    s3 = hits[0]
    table = s3 + 34
    init, play = struct.unpack_from('>II', image, table)
    original = bytes(image[init:play])
    if init != table + 8 or len(original) != 52 or original[:2] != b'N\xb9' or (original[-6:] != bytes.fromhex('582800024e75')):
        raise ValueError('native SCROLL3 initialiser is not the supported position-independent body')
    if b'N\xb9' + init.to_bytes(4, 'big') in image or b'N\xf9' + init.to_bytes(4, 'big') in image:
        raise ValueError('SCROLL3 initialiser has a direct caller')
    steps = [a for a in range(118784, 123904, 2) if image[a:a + 8] == STEP]
    if len(steps) != 4 or [steps[i + 1] - steps[i] for i in range(3)] != [296, 294, 296]:
        raise ValueError('four native scroll step tables required')
    up, down = (steps[-2] - 24, steps[-1] - 26)
    xfollow = play + 88
    if any((image[a:a + 4] != bytes.fromhex('3a3c0020') for a in (up, down))):
        raise ValueError('native vertical scroll entry differs')
    if image[xfollow:xfollow + 4] != bytes.fromhex('302d90d2'):
        raise ValueError('native horizontal camera differs')
    branch = up + 138
    if image[branch:branch + 2] != b'a\x00':
        raise ValueError('native row streamer call differs')
    row = branch + 2 + struct.unpack_from('>h', image, branch + 2)[0]
    setup = [a for a in range(0, len(bank) - 6, 2) if bank[a:a + 6] == R.jsr(s3)]
    if len(setup) != 1:
        raise ValueError('desert SCROLL3 setup call is not unique')
    return dict(table=table, setup=1048576 + setup[0], original_init=original, constants=dict(S3=s3, PLAY=play, X_FOLLOW=xfollow, UP=up, DOWN=down, ROW=row))

def patch(image, bank, helper):
    m = model(image, bank)
    image = bytearray(image)
    bank = bytearray(bank)
    hooks = []

    def change(a, new):
        buf, off = (bank, a - 1048576) if a >= 1048576 else (image, a)
        hooks.append(dict(address=a, before=buf[off:off + len(new)].hex(), after=new.hex()))
        buf[off:off + len(new)] = new
    change(m['table'], INIT.to_bytes(4, 'big'))
    change(m['table'] + 8, (ENTRY + 6).to_bytes(4, 'big'))
    change(m['setup'], R.jsr(ENTRY))
    off = ENTRY - 1048576
    if not helper or len(helper) > 1024 or bank[off:off + len(helper)] != b'\xff' * len(helper):
        raise ValueError('desert camera allocation occupied or oversized')
    if any((helper[a:a + 2] != b'N\xf9' for a in (0, 6))) or helper[INIT - ENTRY:] != m['original_init']:
        raise ValueError('camera entry offsets or exact native initialiser differ')
    bank[off:off + len(helper)] = helper
    return (image, bank, dict(hooks=hooks, helper_at=ENTRY, helper_bytes=len(helper), helper_sha256=sha(helper), stock_play_handler_unchanged=True, native_initialiser_relocated_byte_exact=True, desert_state=8))

def audit(control, build):
    cm, old = inventory(control)
    meta, new = inventory(build)
    for m, f in old.items():
        s = meta['sets'][m]['desert_motion']
        p = new[m]['strex_p6.bin']
        b = bytes((p[i ^ 1] for i in range(len(p))))
        off = ENTRY - 1048576
        h = b[off:off + s['helper_bytes']]
        ob = f['strex_p6.bin']
        ob = bytes((ob[i ^ 1] for i in range(len(ob))))
        im, expected, report = patch(R.compose(f, R.SETS[m]), ob, h)
        nf = dict(f, **R.decompose(im, R.SETS[m], {n: len(f[n]) for n, _, _ in R.SETS[m]}))
        nf['strex_p6.bin'] = bytes((expected[i ^ 1] for i in range(len(expected))))
        if nf != new[m] or report['hooks'] != s['hooks'] or sha(h) != s['helper_sha256'] or (s['source_files'] != cm['sets'][m]['files']):
            raise ValueError('unexpected camera ROM changes')
    return meta

def main():
    if sys.argv[1:] == ['--self-test']:
        try:
            model(bytes(131072), bytes(1048576))
        except ValueError:
            pass
        else:
            raise AssertionError('foreign scroll code accepted')
        print('Desert camera source guards PASS')
        return
    p = argparse.ArgumentParser(description=__doc__)
    for n in ('build', 'vasm', 'out'):
        p.add_argument('--' + n, type=Path, required=True)
    a = p.parse_args()
    meta, files = inventory(a.build)
    rep = deepcopy(meta)
    a.out.mkdir(parents=True, exist_ok=False)
    for m, f in files.items():
        im = R.compose(f, R.SETS[m])
        p6 = f['strex_p6.bin']
        b = bytes((p6[i ^ 1] for i in range(len(p6))))
        s = model(im, b)
        src = a.out / (m + '.s')
        src.write_text(''.join((f'{k} equ ${v:X}\n' for k, v in s['constants'].items())) + ASM.read_text() + f'\n org ${INIT:X}\n dc.b ' + ','.join((str(v) for v in s['original_init'])) + '\n')
        binary = src.with_suffix('.bin')
        subprocess.run([*assembly_command(a.vasm), '-Fbin', '-m68000', '-quiet', '-o', str(binary), str(src)], check=True)
        im, b, spec = patch(im, b, binary.read_bytes())
        f = dict(f, **R.decompose(im, R.SETS[m], {n: len(f[n]) for n, _, _ in R.SETS[m]}))
        f['strex_p6.bin'] = bytes((b[i ^ 1] for i in range(len(b))))
        d = a.out / m
        d.mkdir()
        for n, data in f.items():
            (d / n).write_bytes(data)
        spec['source_files'] = meta['sets'][m]['files']
        rep['sets'][m]['desert_motion'] = spec
        rep['sets'][m]['files'] = {n: sha(data) for n, data in f.items()}
    (a.out / 'build.json').write_text(json.dumps(rep, indent=2) + '\n')
    audit(a.build, a.out)
if __name__ == '__main__':
    main()
