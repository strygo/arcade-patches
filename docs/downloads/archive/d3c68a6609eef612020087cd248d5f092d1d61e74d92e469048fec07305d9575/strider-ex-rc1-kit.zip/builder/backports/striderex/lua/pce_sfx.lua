-- Strider EX: render PC Engine PSG sound effects in isolation (scripts/pce_sfx.py capture).
--
-- Loads the Strider console probe (STRIDEREX_BASE_PROBE: inputs, the desert chapter start, the
-- run's end), waits for play in the desert chapter (MPR2 = 0x68, game phase $C7 = 8), then:
--   - 90 frames later freezes the game's main loop in its idle wait (zero page $0A held at 0
--     every frame) and fades the CD-DA/ADPCM out (0x1FF80F = 0x08); the PSG driver runs from the
--     VSync IRQ, so it keeps playing;
--   - from 420 frames after that, injects each effect of PCE_SFX_LIST (hex, comma separated)
--     PCE_SFX_GAP frames apart, as the game's own call does: when the CPU is in the idle loop
--     (0x43DF-0x43E5, the chapter mapping), a jsr-like entry to 0x6B88 (sta $F8 / _DH = 0x0B /
--     jsr PSG_BIOS) with A = the effect and the return address 0x43DF on the stack.
-- PCE_SFX_LOG (TSV: frame, emulated time, event) gets 'inplay', 'freeze', 'inject eff=..' and every
-- PSG register write (physical 0x1FE800-0x1FE809) as 'psg reg=.. val=..', so the script's caller
-- can find each effect in the -wavwrite recording and the PSG channels it uses.
-- Every tap handle is anchored in _G (Lua GC would otherwise remove it).
dofile(assert(os.getenv('STRIDEREX_BASE_PROBE')))
local m=manager.machine
local cpu=m.devices[':maincpu']
local sp=cpu.spaces['program']
local out=assert(io.open(assert(os.getenv('PCE_SFX_LOG')),'w'))
local effects={}
for h in string.gmatch(assert(os.getenv('PCE_SFX_LIST')),'[^,]+') do effects[#effects+1]=tonumber(h,16) end
local gap=tonumber(os.getenv('PCE_SFX_GAP') or '240')
local f=0
local inplay,frozen,nextf=nil,nil,nil
local nexti=1
local function log(s) out:write(string.format('%d\t%.9f\t%s\n',f,m.time:as_double(),s)); out:flush() end
_G.strex_pce_sfx_psg=sp:install_write_tap(0x1fe800,0x1fe809,'strex_pce_sfx_psg',function(a,d,mk)
  if frozen then log(string.format('psg reg=%x val=%02x',a-0x1fe800,d&0xff)) end
end)
emu.register_frame_done(function()
  f=f+1
  assert(_G.strex_pce_sfx_psg)
  if not inplay and f>6000 and cpu.state['MPR2'].value==0x68 and sp:read_u8(0x1f00c7)==8 then
    inplay=f; log('inplay')
  end
  if inplay and not frozen and f>=inplay+90 then
    frozen=f; sp:write_u8(0x1ff80f,0x08); log('freeze'); nextf=f+420
  end
  if frozen then sp:write_u8(0x1f000a,0) end
  if nextf and f>=nextf and nexti<=#effects then
    local p=cpu.state['PC'].value
    if p>=0x43df and p<=0x43e5 and cpu.state['MPR2'].value==0x68 and cpu.state['MPR3'].value==0x69
       and sp:read_u8(0xd2b88)==0x85 and sp:read_u8(0xd2b89)==0xf8 and sp:read_u8(0xd2b8b)==0x0b then
      local s=cpu.state['S'].value
      sp:write_u8(0x1f0100+s,0x43); s=(s-1)&0xff
      sp:write_u8(0x1f0100+s,0xde); s=(s-1)&0xff
      cpu.state['S'].value=s; cpu.state['A'].value=effects[nexti]; cpu.state['PC'].value=0x6b88
      log(string.format('inject eff=%02x pc_was=%04x',effects[nexti],p))
      nexti=nexti+1; nextf=f+gap
    end
  end
  if nexti>#effects and nextf and f>=nextf then log('done') end
end)
