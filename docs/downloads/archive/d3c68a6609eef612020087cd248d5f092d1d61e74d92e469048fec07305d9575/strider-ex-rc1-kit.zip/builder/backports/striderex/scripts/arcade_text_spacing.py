"""Reconstruction helper."""
import argparse
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import sys
import respawn_fix as R
from boss_voice_gate import inventory
import subtitle_ex as S
MANIFEST = Path(__file__).resolve().parents[1] / 'manifests/arcade_text_edits.json'

def sha(b):
    return hashlib.sha256(b).hexdigest()

def encoded(text):
    return bytes((S.EN_CODE[c] for c in text))

def patch(image, row):
    old, new = (encoded(row['before']), encoded(row['after']))
    at = row['text_address']
    rec = row['record_address']
    if len(old) != len(new) or at != rec + 4:
        raise ValueError('copyedit changes the native record size')
    if image[rec:at] != bytes.fromhex('22341900') or image[at:at + len(old)] != old:
        raise ValueError('Grandmaster native text record changed')
    if row['approval'].get('text_sha256') != sha(row['after'].encode()):
        raise ValueError('copyedit lacks exact wording approval')
    b = bytearray(image)
    b[at:at + len(new)] = new
    return b

def build(a):
    rows = json.loads(MANIFEST.read_text())['edits']
    meta, files = inventory(a.build)
    rep = deepcopy(meta)
    a.out.mkdir(parents=True, exist_ok=False)
    for m, f in files.items():
        image = R.compose(f, R.SETS[m])
        changed = image
        applied = []
        for row in rows:
            if row['machine'] != m:
                continue
            changed = patch(changed, row)
            applied.append(dict(id=row['id'], address=row['text_address'], before_sha256=sha(encoded(row['before'])), after_sha256=sha(encoded(row['after'])), text_sha256=sha(row['after'].encode()), bytes=len(encoded(row['after']))))
        f = dict(f, **R.decompose(changed, R.SETS[m], {n: len(f[n]) for n, _, _ in R.SETS[m]}))
        out = a.out / m
        out.mkdir()
        for n, b in f.items():
            (out / n).write_bytes(b)
        rep['sets'][m]['files'] = {n: sha(b) for n, b in f.items()}
        rep['sets'][m]['arcade_copyedit'] = dict(edits=applied, source_files=meta['sets'][m]['files'])
        print(m, 'native copyedits', len(applied), flush=True)
    (a.out / 'build.json').write_text(json.dumps(rep, indent=2) + '\n')

def main():
    if sys.argv[1:] == ['--self-test']:
        row = json.loads(MANIFEST.read_text())['edits'][0]
        b = bytearray(65536)
        at = row['text_address']
        rec = row['record_address']
        b[rec:at] = bytes.fromhex('22341900')
        b[at:at + 26] = encoded(row['before'])
        out = patch(b, row)
        assert out[at:at + 26] == encoded(row['after']) and out[:at] == b[:at] and (out[at + 26:] == b[at + 26:])
        bad = deepcopy(row)
        bad['after'] += '!'
        try:
            patch(b, bad)
        except ValueError:
            pass
        else:
            raise AssertionError('a larger record overwrote executable code')
        bad = deepcopy(row)
        bad['approval']['text_sha256'] = '0' * 64
        try:
            patch(b, bad)
        except ValueError:
            pass
        else:
            raise AssertionError('unapproved copyedit accepted')
        print('Arcade copyedit self-test PASS: exact bytes/approval; changed size rejected')
        return
    p = argparse.ArgumentParser(description=__doc__)
    for n in ('build', 'out'):
        p.add_argument('--' + n, type=Path, required=True)
    build(p.parse_args())
if __name__ == '__main__':
    main()
