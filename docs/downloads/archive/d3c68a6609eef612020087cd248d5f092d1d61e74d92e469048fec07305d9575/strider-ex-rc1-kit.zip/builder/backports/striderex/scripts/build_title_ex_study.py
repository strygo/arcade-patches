"""Render the editable native Strider EX pixel grids and optional title mockups."""
from __future__ import annotations
import argparse
import hashlib
from io import BytesIO
import json
from pathlib import Path
import subprocess
import xml.etree.ElementTree as ET
from zipfile import ZipFile, ZIP_DEFLATED, ZIP_STORED
from PIL import Image
TRACK = Path(__file__).resolve().parents[1]
ART = TRACK / 'assets/title_ex'

def png_bytes(image):
    buf = BytesIO()
    image.save(buf, format='PNG')
    return buf.getvalue()

def save_ora(path, layers):
    size = layers[0][1].size
    root = ET.Element('image', w=str(size[0]), h=str(size[1]), version='0.0.3', name='Strider EX')
    stack = ET.SubElement(root, 'stack')
    merged = Image.new('RGBA', size)
    with ZipFile(path, 'w', ZIP_DEFLATED) as archive:
        archive.writestr('mimetype', 'image/openraster', compress_type=ZIP_STORED)
        for i, (name, layer) in enumerate(layers):
            source = f'data/{i}.png'
            archive.writestr(source, png_bytes(layer))
            ET.SubElement(stack, 'layer', name=name, src=source, x='0', y='0', opacity='1.0', visibility='visible', **{'composite-op': 'svg:src-over'})
        for _, layer in reversed(layers):
            merged = Image.alpha_composite(merged, layer)
        archive.writestr('mergedimage.png', png_bytes(merged))
        archive.writestr('stack.xml', ET.tostring(root, encoding='utf-8', xml_declaration=True))

def render_mark(region, spec):
    rows = (ART / f'{region}_pixels.txt').read_text().splitlines()
    width, height = spec['size']
    assert len(rows) == height and all((len(row) == width for row in rows)), 'pixel grid dimensions'
    mark = Image.new('RGBA', (width, height))
    face = Image.new('RGBA', mark.size)
    accents = Image.new('RGBA', mark.size)
    palette = spec['palette']
    for y, row in enumerate(rows):
        for x, c in enumerate(row):
            if c == '.':
                continue
            assert c.isdigit() and int(c) < len(palette), (region, x, y, c)
            index = int(c)
            color = (*palette[index], 255)
            mark.putpixel((x, y), color)
            (face if index == 0 else accents).putpixel((x, y), color)
    assert Image.alpha_composite(accents, face).tobytes() == mark.tobytes()
    assert set(mark.getchannel('A').get_flattened_data()) <= {0, 255}
    return (mark, [('Letter faces', face), ('Flame edge' if region == 'jp' else 'Cyan edge and purple shadow', accents)])

def read_stock(path, spec):
    image = Image.open(path).convert('RGB')
    if image.size == (768, 448):
        native = image.resize((384, 224), Image.Resampling.NEAREST)
        assert native.resize(image.size, Image.Resampling.NEAREST).tobytes() == image.tobytes(), 'reference is not exact 2x'
        image = native
    assert image.size == (384, 224), 'expected native 384x224 or exact 2x screenshot'
    assert hashlib.sha256(image.tobytes()).hexdigest() == spec['native_rgb_sha256'], 'wrong title reference'
    return image.convert('RGBA')

def save_xcf(jobs):
    batch = '\nimport json, os\nfrom gi.repository import Gimp, Gio\nfor job in json.loads(os.environ["STRIDER_TITLE_XCF_JOBS"]):\n    image = Gimp.file_load(Gimp.RunMode.NONINTERACTIVE, Gio.File.new_for_path(job["source"]))\n    assert image is not None\n    assert [image.get_width(), image.get_height()] == job["size"]\n    assert len(image.get_layers()) == job["layers"]\n    save = Gimp.get_pdb().lookup_procedure("gimp-xcf-save")\n    config = save.create_config()\n    config.set_property("run-mode", Gimp.RunMode.NONINTERACTIVE)\n    config.set_property("image", image)\n    config.set_property("file", Gio.File.new_for_path(job["destination"]))\n    assert save.run(config).index(0) == Gimp.PDBStatusType.SUCCESS\n    image.delete()\n    reopened = Gimp.file_load(Gimp.RunMode.NONINTERACTIVE, Gio.File.new_for_path(job["destination"]))\n    assert [reopened.get_width(), reopened.get_height()] == job["size"]\n    assert len(reopened.get_layers()) == job["layers"]\n    assert all(layer.get_visible() for layer in reopened.get_layers())\n    reopened.delete()\n'
    import os
    subprocess.run(['/Applications/GIMP.app/Contents/MacOS/gimp-console', '--no-interface', '--new-instance', '--no-data', '--no-fonts', '--batch-interpreter=python-fu-eval', '--batch=' + batch, '--quit'], check=True, env=dict(os.environ, STRIDER_TITLE_XCF_JOBS=json.dumps(jobs)))

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, default=TRACK / 'out/title_ex')
    parser.add_argument('--jp-screen', type=Path)
    parser.add_argument('--us-screen', type=Path)
    parser.add_argument('--xcf', action='store_true', help='save layered GIMP documents')
    parser.add_argument('--publish-assets', action='store_true', help='update durable transparent PNGs and XCFs')
    args = parser.parse_args()
    out = args.out.resolve()
    out.mkdir(parents=True, exist_ok=True)
    layout = json.loads((ART / 'layout.json').read_text())
    jobs, receipt = ([], {})
    for region, spec in layout.items():
        mark, layers = render_mark(region, spec)
        mark.save(out / f'{region}_ex.png')
        background = Image.new('RGBA', mark.size, (0, 0, 0, 255))
        Image.alpha_composite(background, mark).resize((mark.width * 8, mark.height * 8), Image.Resampling.NEAREST).save(out / f'{region}_mark_zoom.png')
        ora = out / f'{region}_mark.ora'
        save_ora(ora, layers)
        if args.publish_assets:
            mark.save(ART / f'{region}_ex.png')
        if args.xcf:
            destination = ART / f'{region}_ex.xcf' if args.publish_assets else out / f'{region}_ex.xcf'
            jobs.append({'source': str(ora), 'destination': str(destination.resolve()), 'size': list(mark.size), 'layers': 2})
        receipt[region] = {'size': mark.size, 'sha256': hashlib.sha256(png_bytes(mark)).hexdigest(), 'opaque_colors': len(set(mark.get_flattened_data()) - {(0, 0, 0, 0)}), 'alpha': 'binary'}
        source = getattr(args, f'{region}_screen')
        if source:
            stock = read_stock(source, spec)
            palette = set(stock.convert('RGB').get_flattened_data())
            assert all((tuple(color) in palette for color in spec['palette'])), 'palette not stock'
            position = tuple(spec['position'])
            placed = []
            for name, layer in layers:
                canvas = Image.new('RGBA', stock.size)
                canvas.alpha_composite(layer, position)
                placed.append((name, canvas))
            screen = stock.copy()
            screen.alpha_composite(mark, position)
            mask = Image.new('RGBA', stock.size)
            mask.alpha_composite(mark, position)
            changed = covered = 0
            for before, after, overlay in zip(stock.get_flattened_data(), screen.get_flattened_data(), mask.get_flattened_data()):
                assert overlay[3] or before == after, 'stock pixel changed outside EX'
                changed += before != after
                covered += bool(overlay[3] and before[:3] != (0, 0, 0))
            assert covered == 0, 'EX covers existing logo'
            screen.save(out / f'{region}_title.png')
            screen.resize((768, 448), Image.Resampling.NEAREST).save(out / f'{region}_title_2x.png')
            title_ora = out / f'{region}_title.ora'
            save_ora(title_ora, placed + [('Stock title', stock)])
            if args.xcf:
                jobs.append({'source': str(title_ora), 'destination': str(out / f'{region}_title.xcf'), 'size': [384, 224], 'layers': 3})
            receipt[region].update(position=position, stock_pixels_covered=covered, added_pixels=changed)
    if jobs:
        save_xcf(jobs)
    (out / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    header = '<!doctype html><html lang="en"><meta charset="utf-8">\n<title>Strider EX — native title studies</title><style>\nbody{background:#17171d;color:#eee;font:16px system-ui;max-width:1100px;margin:2rem auto;padding:0 1rem}\nimg{image-rendering:pixelated;max-width:100%}figure{margin:1.5rem 0}a{color:#9deaff}\n.screen{width:768px}.sprite{width:672px}figcaption{margin:.5rem 0;color:#bfc6d0}\n</style><h1>Strider EX · title studies</h1>\n<p>Native pixel artwork. Original logo palettes, binary transparency.</p>'
    sections = []
    for region, title in (('jp', 'Japanese · cream brush lettering and rust flame edge'), ('us', 'English · cyan calligraphy and purple shadow')):
        sections.append(f'<h2>{title}</h2>')
        if getattr(args, f'{region}_screen'):
            link = f' · <a href="{region}_title.xcf">Layered title XCF</a>' if args.xcf else ''
            sections.append(f'<figure><img class="screen" src="{region}_title.png"><figcaption>Full screen, 2× nearest neighbor{link}. Every existing logo pixel is preserved.</figcaption></figure>')
        w, h = layout[region]['size']
        sections.append(f'<figure><img class="sprite" src="{region}_mark_zoom.png"><figcaption>{w}×{h} mark, 8× pixel view · <a href="{region}_ex.png">Transparent PNG</a></figcaption></figure>')
    (out / 'index.html').write_text(header + '\n'.join(sections) + '</html>')
    print(json.dumps(receipt, indent=2))
if __name__ == '__main__':
    main()
