"""Convert a captured PC Engine cinematic into CPS-1 graphics and a scene stream."""
import argparse
import hashlib
import json
import struct
import sys
from pathlib import Path
import numpy as np
sys.path.insert(0, str(Path(__file__).resolve().parent))
import cinematic_lz as LZ
import cinematic_timing as T
import cps1_gfx as G
import pce_vdc as P
S2_BASE = 32768
OBJ_BASE = 40960
S1_BASE = 32768
S1_LAST = 49151
ROW_SPAN = 384
BARS = 14336
PAL_OBJ, PAL_S1, PAL_S2, PAL_S3 = (0, 512, 1024, 1536)
BACKDROP = 3071
X_PICTURE = 64
SCREEN_W, SCREEN_H = (384, 224)
BLACK = 61440
BLOCK_MIN = 4
LAYERS_S1 = 12672
LAYERS_S2 = 12864
COVER = 32767
SWITCH_COST = 64
COPYRIGHT_GLYPHS = frozenset(('4606e388ecafd75a', 'c57e15f0edf450e2', 'cd14cfe2396945ef', 'f771b780c26f1217', 'b2a1bfbcb100be79', 'ff9946ba7c91a9ce', '14fd96954eefd068', '2b97a6cfaca9a221', 'ff4db4db0b9abfb1', 'd67d3ca0f4635e3b', '0518089769fc1521', '281b990ccedda3da', 'd671386a72235842', '19d776c0aac25645', '460c8d03c522757a', 'e047530aa2f28bd3', '4b6cdaa79c53cd31', '60cc4626b55c6dcb', '85d79bdd102e5efb', 'ca79f336cac75e2e', '680f07d49b7e37d6', 'b4bd196e6b65d647', '121405161f8f2b5f', 'f81738b1da4fe6d5', '8e9416392aadf110'))
_glyph_digest = {}

def glyph_digest(tile):
    """A tile's pattern digest: the first 16 hex digits of the SHA-256 of its 64 color indices."""
    key = tile.astype(np.uint8).tobytes()
    if key not in _glyph_digest:
        _glyph_digest[key] = hashlib.sha256(key).hexdigest()[:16]
    return _glyph_digest[key]

def copyright_tiles(d, tiles=None):
    """{tile: digest} of the tiles the frame's map uses whose pattern is a copyright glyph (above)."""
    g = P.geometry(d)
    tiles = P.all_bg_tiles(d['vram']) if tiles is None else tiles
    used = np.unique(d['vram'][:g['map_w'] * g['map_h']] & 2047)
    return {int(t): h for t in used if (h := glyph_digest(tiles[t])) in COPYRIGHT_GLYPHS}
KEEP_COPYRIGHT = False

def bat_tiles(d, copyright=True):
    """The 2048 background tiles as EX draws them: those inside the map (BAT) blank, and (copyright)"""
    g = P.geometry(d)
    tiles = P.all_bg_tiles(d['vram'])
    glyphs = list(copyright_tiles(d, tiles)) if copyright and (not KEEP_COPYRIGHT) else []
    tiles[:g['map_w'] * g['map_h'] // 16] = 0
    tiles[glyphs] = 0
    return tiles

def frames_for(run_dir, t0, t1):
    rows = P.read_index(run_dir)
    return sorted((f for f, r in rows.items() if t0 <= float(r['time']) <= t1))

def s2_offset(row, col):
    """Byte offset of SCROLL2 cell (row, col) in the tilemap1_scan layout."""
    return 4 * ((row & 15) + ((col & 63) << 4) + ((row & 48) << 6))

def s1_offset(row, col):
    """Byte offset of SCROLL1 cell (row, col) in the tilemap0_scan layout."""
    return 4 * ((row & 31) + ((col & 63) << 5) + ((row & 32) << 6))

def mode_of(a):
    v, n = np.unique(a, return_counts=True)
    return int(v[n.argmax()])

class Merged:
    """Up to 16 merged palettes (slots 16-31) of one layer."""

    def __init__(self):
        self.lists = []

    def fit(self, used):
        for k, lst in enumerate(self.lists):
            if len(set(lst) | set(used)) <= 15:
                lst += [v for v in used if v not in lst]
                return 16 + k
        if len(used) > 15 or len(self.lists) == 16:
            return None
        self.lists.append(list(used))
        return 16 + len(self.lists) - 1

class Converter:

    def __init__(self, crop_top, obj_base=OBJ_BASE):
        self.crop = crop_top
        self.obj_base = obj_base
        self.region = bytearray(4 * G.MB)
        G.put_tile(self.region, G.ex_offset('scr3', BARS + 1), np.full((32, 32), 15))
        self.merged = {'s1': Merged(), 's2': Merged()}
        self.s1_codes = {}
        self.s2_codes = {}
        self.next_s2 = S2_BASE
        self.obj_codes = {}
        self.cell_codes = {}
        self.images = {}
        self.image_frames = {}
        self.obj_shelf = None
        self.cache = {}
        self.deviations = {}
        self.modes = {}
        self.last = None
        self.glyphs_seen = set()

    def tile(self, layer, refs):
        """refs: n x n of (pal << 4 | color), -1 transparent -> (code, palette) or None."""
        key = (layer, refs.tobytes())
        if key not in self.cache:
            self.cache[key] = self._tile(layer, refs)
        return self.cache[key]

    def _tile(self, layer, refs):
        used = sorted((int(v) for v in np.unique(refs) if v >= 0))
        pals = {v >> 4 for v in used}
        if len(pals) <= 1 and 0 not in used:
            q = pals.pop() if pals else 0
            pens = np.where(refs >= 0, (refs & 15) - 1, 15)
        else:
            q = self.merged[layer].fit(used)
            if q is None:
                return None
            pens = np.full(refs.shape, 15)
            for i, v in enumerate(self.merged[layer].lists[q - 16]):
                pens[refs == v] = i
        return (self.code(layer, pens), q)

    def solid(self, layer, pen):
        """The code of a tile with one pen everywhere ('s1' 8x8, 's2' 16x16): the stage select's band"""
        return self.code(layer, np.full((8, 8) if layer == 's1' else (16, 16), pen))

    def code(self, layer, pens):
        """The EX code of a tile's pens, allocated on first use (SCROLL1: one tile in both halves)."""
        key = pens.astype(np.uint8).tobytes()
        if layer == 's1':
            book = self.s1_codes
            if key not in book:
                if S1_BASE + len(book) > S1_LAST:
                    raise SystemExit(f'SCROLL1 EX codes exhausted: {len(book) + 1} tiles need more than the {S1_LAST - S1_BASE + 1} codes {S1_BASE:#06x}-{S1_LAST:#06x}')
                book[key] = len(book)
                at = G.ex_offset('scr1', S1_BASE + book[key])
                G.put_tile(self.region, at, pens, 0)
                G.put_tile(self.region, at, pens, 1)
            return S1_BASE + book[key]
        if key not in self.s2_codes:
            if self.next_s2 >= self.obj_base:
                raise SystemExit('SCROLL2 tiles overflow into the sprite area')
            self.s2_codes[key] = self.next_s2
            G.put_tile(self.region, G.ex_offset('scr2', self.next_s2), pens)
            self.next_s2 += 1
        return self.s2_codes[key]

    def obj_block(self, img):
        h, w = img.shape
        pens = np.where(img == 0, 15, img - 1).astype(np.uint8)
        key = (h, w, pens.tobytes())
        code = self.obj_codes.get(key)
        if code is not None:
            return code
        nx, ny = (w // 16, h // 16)
        if self.obj_shelf is None:
            self.obj_shelf = [self.obj_base, 0, 0]
        row, x, sh = self.obj_shelf
        if x + nx > 16:
            row, x, sh = (row + 16 * sh, 0, 0)
        code = row + x
        if code + 16 * (ny - 1) + nx > 49152 - len(self.cell_codes):
            raise SystemExit('sprite codes exhausted')
        self.obj_shelf = [row, x + nx, max(sh, ny)]
        for r in range(ny):
            for c in range(nx):
                G.put_tile(self.region, G.ex_offset('obj', code + c + 16 * r), pens[16 * r:16 * r + 16, 16 * c:16 * c + 16])
        self.obj_codes[key] = code
        return code

    def frame_state(self, d, writes):
        g = P.geometry(d)
        if (g['map_w'], g['map_h'], g['width']) != (64, 64, 256) or g['height'] < self.crop + SCREEN_H:
            raise SystemExit(f"frame {d['frame']}: unsupported geometry {g}")
        lr = P.line_registers(d, writes)
        ks = np.arange(self.crop, self.crop + SCREEN_H)
        rows, xs, crs = (lr[ks, 1] % 512, lr[ks, 0] % 512, lr[ks, 2])
        yrel = (rows - ks) % 512
        Y, X, cr = (mode_of(yrel), mode_of(xs), mode_of(crs & 192))
        odd = np.nonzero(crs & 192 != cr)[0]
        if len(odd):
            self.deviations[int(d['frame'])] = odd.tolist()
        tiles = bat_tiles(d)
        bat = d['vram'][:4096].reshape(64, 64)
        img = tiles[bat & 2047]
        refs = np.where(img != 0, (bat >> 12)[:, :, None, None] << 4 | img, -1)
        refs = refs.transpose(0, 2, 1, 3).reshape(512, 512)
        vis = refs[rows[:, None], (xs[:, None] + np.arange(256)) % 512]
        st = dict(bg_on=bool(cr & 128), pce_pal=d['pal'].copy(), s1=None, s2=None)
        plans = self.plans(refs, vis, ks, xs, yrel, X, Y)
        cost = {}
        for name, pl in plans.items():
            cost[name] = sum((self.new_tiles(g) for g in pl['grids'].values()))
            if (name == 's2') != (self.last == 's2') and self.last is not None:
                cost[name] += SWITCH_COST
        for name in sorted(plans, key=lambda n: (cost[n], n != self.last, n)):
            got = self.commit(plans[name])
            if got is not None:
                st.update(got)
                self.last = name
                break
        else:
            raise SystemExit(f"frame {d['frame']}: no CPS layer plan fits")
        self.modes[self.last] = self.modes.get(self.last, 0) + 1
        st['objs'], st['cover'] = ([], False)
        if cr & 64:
            st['cover'], shown = self.sprite_plan(d, writes, ks, cover_ok=not (st['s1'] and st['s2']))
            for top, left, im, attr in shown:
                key = (im.shape, im.astype(np.uint8).tobytes())
                self.images.setdefault(key, im)
                self.image_frames[key] = self.image_frames.get(key, 0) + 1
                st['objs'].append((top, left, key, attr))
        return st

    def allocate_sprites(self, states):
        """After all frames: an object image shown on BLOCK_MIN or more frames"""
        for st in states:
            out = []
            for top, left, key, attr in st['objs']:
                im = self.images[key]
                if self.image_frames[key] >= BLOCK_MIN:
                    nx, ny = (im.shape[1] // 16, im.shape[0] // 16)
                    out.append((128 + left & 511, top & 511, self.obj_block(im), ny - 1 << 12 | nx - 1 << 8 | attr & 15))
                    continue
                for r in range(im.shape[0] // 16):
                    for c in range(im.shape[1] // 16):
                        cell = im[16 * r:16 * r + 16, 16 * c:16 * c + 16]
                        if cell.any():
                            out.append((128 + left + 16 * c & 511, top + 16 * r & 511, self.obj_cell(cell), attr & 15))
            if len(out) > OBJ_ENTRIES:
                raise SystemExit(f"{len(out)} sprite entries in one frame (the player's lists hold {OBJ_ENTRIES})")
            st['sprites'] = out

    def obj_cell(self, cell):
        pens = np.where(cell == 0, 15, cell - 1).astype(np.uint8)
        key = pens.tobytes()
        if key not in self.cell_codes:
            code = 49151 - len(self.cell_codes)
            top = self.obj_shelf[0] + 16 * self.obj_shelf[2] if self.obj_shelf else self.obj_base
            if code < top:
                raise SystemExit('sprite codes exhausted')
            self.cell_codes[key] = code
            G.put_tile(self.region, G.ex_offset('obj', code), pens)
        return self.cell_codes[key]

    def sprite_plan(self, d, writes, ks, cover_ok):
        """(cover, objects) for one frame. The PCE shows a sprite pixel by its"""
        g = P.geometry(d)
        h, w = (g['height'], g['width'])
        objs = P.sprite_objects(d)
        used = np.zeros(h, np.int32)
        owner = np.full((h, w), -1, np.int32)
        raw = np.full((h, w), -1, np.int32)
        masks = {}
        for i, top, left, img, attr in objs:
            ncell = img.shape[1] // 16
            lines = np.arange(max(top, 0), min(top + img.shape[0], h))
            allowed = np.clip(16 - used[lines], 0, ncell)
            used[lines] = np.minimum(used[lines] + ncell, 16)
            m = np.zeros(img.shape, bool)
            for k in range(ncell):
                m[lines - top, k * 16:(k + 1) * 16] = (allowed > k)[:, None]
            masks[i] = m & (img != 0)
        for i, top, left, img, attr in reversed(objs):
            y0, y1, x0, x1 = (max(top, 0), min(top + img.shape[0], h), max(left, 0), min(left + img.shape[1], w))
            if y0 < y1 and x0 < x1:
                sl = (slice(y0 - top, y1 - top), slice(x0 - left, x1 - left))
                owner[y0:y1, x0:x1][masks[i][sl]] = i
                raw[y0:y1, x0:x1][img[sl] != 0] = i
        bg = P.render_layers(d, writes=writes)[0]
        cr = P.line_registers(d, writes)[:, 2]
        front = np.zeros(65, bool)
        for i, top, left, img, attr in objs:
            front[i] = bool(attr & 128)
        shown = (owner >= 0) & (front[owner] | (bg == 0)) & (cr & 64 != 0)[:, None]
        want = np.where(shown, owner, -1)[ks]
        whole = [(top, left, img, attr) for i, top, left, img, attr in objs]
        if (np.where(raw >= 0, raw, -1)[ks] == want).all():
            return (False, whole)
        if cover_ok and (np.where((raw >= 0) & (bg == 0), raw, -1)[ks] == want).all():
            return (True, whole)
        rows = np.zeros(h, bool)
        rows[ks] = True
        shown &= rows[:, None]
        out = []
        for i, top, left, img, attr in objs:
            keep = np.zeros(img.shape, bool)
            y0, y1, x0, x1 = (max(top, 0), min(top + img.shape[0], h), max(left, 0), min(left + img.shape[1], w))
            if y0 < y1 and x0 < x1:
                keep[y0 - top:y1 - top, x0 - left:x1 - left] = (owner[y0:y1, x0:x1] == i) & shown[y0:y1, x0:x1]
            if keep.any():
                out.append((top, left, np.where(keep, img, 0), attr))
        return (False, out)

    def plans(self, refs, vis, ks, xs, yrel, X, Y):
        """Candidate layer plans for one frame (see the module docstring)."""
        cols = np.arange(256)
        wavy = xs != X
        dev = wavy | (yrel != Y)
        line = np.full(256, int(xs[0]) - 128 & 1023, np.int32)
        line[ks] = xs - 128 & 1023
        c1 = refs.copy()
        for i in np.nonzero(dev)[0]:
            c1[(Y + ks[i]) % 512, (X + cols) % 512] = vis[i]
        out = {'s1': dict(grids={'s1': self.grid('s1', c1)}, x=X, y1=Y)}
        if not dev.any():
            return out

        def rows(shown):
            """The row table with every line SCROLL2 does not show (off the picture, or"""
            used = np.zeros(256, bool)
            used[ks[shown]] = True
            if row_span(line[used]) > ROW_SPAN:
                return None
            out = line.copy()
            last = int(line[np.argmax(used)])
            for k in range(256):
                if used[k]:
                    last = int(line[k])
                else:
                    out[k] = last
            return out
        c2 = refs.copy()
        for i in np.nonzero(yrel != Y)[0]:
            c2[(Y + ks[i]) % 512, (xs[i] + cols) % 512] = vis[i]
        seen = np.zeros((32, 32), bool)
        for i in range(len(ks)):
            seen[(Y + ks[i]) % 512 // 16, (xs[i] + cols) % 512 // 16] = True
        r2 = rows(np.ones(len(ks), bool))
        if r2 is not None:
            out['s2'] = dict(grids={'s2': self.grid('s2', c2)}, y2=Y, rows=r2, seen=seen)
        Y2 = mode_of(yrel[dev])
        c2 = np.full((512, 512), -1, refs.dtype)
        for i in np.nonzero(dev)[0]:
            c2[(Y2 + ks[i]) % 512, (xs[i] + cols) % 512] = np.maximum(vis[i], 0)
        rd = rows(dev)
        if rd is not None:
            out['dual'] = dict(grids={'s1': self.grid('s1', refs), 's2': self.grid('s2', c2)}, x=X, y1=Y, y2=Y2, rows=rd)
        return out

    @staticmethod
    def grid(layer, cmap):
        n = 8 if layer == 's1' else 16
        g = 512 // n
        cm = cmap.reshape(g, n, g, n).transpose(0, 2, 1, 3)
        return [[(layer, np.ascontiguousarray(cm[r, c])) for c in range(g)] for r in range(g)]

    def new_tiles(self, grid):
        return len({(l, a.tobytes()) for row in grid for l, a in row} - self.cache.keys())

    def commit(self, plan):
        out = {}
        for layer, grid in plan['grids'].items():
            g = len(grid)
            cells = np.zeros((g, g, 2), np.int32)
            for r in range(g):
                for c in range(g):
                    lay, refs = grid[r][c]
                    t = self.tile(lay, refs)
                    if t is None and layer == 's2' and ('seen' in plan) and (not plan['seen'][r, c]):
                        t = self.tile('s2', np.full((16, 16), -1))
                    if t is None:
                        return None
                    cells[r, c] = t
            if layer == 's1':
                out['s1'] = dict(cells=cells, x=plan['x'] - 128 & 65535, y=plan['y1'])
            else:
                out['s2'] = dict(cells=cells, y=plan['y2'], rows=plan['rows'])
        return out

    def palette(self, st):
        pal = np.zeros(3072, np.int32)
        word = np.array([G.cps_color(int(v)) for v in st['pce_pal']], np.int32)
        for q in range(16):
            pal[PAL_OBJ + 16 * q:PAL_OBJ + 16 * q + 15] = word[256 + 16 * q + 1:256 + 16 * q + 16]
            for base in (PAL_S1, PAL_S2):
                pal[base + 16 * q:base + 16 * q + 15] = word[16 * q + 1:16 * q + 16]
        for layer, base in (('s1', PAL_S1), ('s2', PAL_S2)):
            for k, lst in enumerate(self.merged[layer].lists):
                at = base + 16 * (16 + k)
                pal[at:at + len(lst)] = word[lst]
        pal[PAL_S3] = BLACK
        pal[BACKDROP] = word[0] if st['bg_on'] else word[256]
        return pal

def w16(v):
    return struct.pack('>H', v & 65535)

def sprite_record(sprites):
    return w16(2) + w16(len(sprites)) + b''.join((w16(v) for s in sprites for v in s))
RES = {'s1': (36992, 36928, 37184, 37248, 37440, 37504, 37568), 's2': (37056, 37312, 37376), 'pal': (36880, 36904)}
DIRECT_MAX = {'s1': 200, 's2': 200, 'pal': 256}
PRE_LINES = 150
PRE_COST = {'s1': 4 * T.DECODE_BYTE + T.APPLY[12], 's2': 4 * T.DECODE_BYTE + T.APPLY[13], 'pal': 2 * T.DECODE_BYTE + T.APPLY[5]}
PRE_STEP = 2
PRE_EXTRA_MAX = 8
BUDGET = 1200
CAP_ALLOW = 54
RUN_MIN = 4
PREFETCH = 240
NEED_FIRST = False
TAIL = 4096
COPY_CHUNK = {'s1': 512, 'pal': 1024}
COPY_SIZE = {'s1': 4096, 'pal': 3072}
COPY_KIND = {'s1': 0, 'pal': 1}
OBJ_ENTRIES = 191
SPRITE_LEAD = 2
COPY_LEAD = {'s1': 16, 'pal': 4}
COPY_TAIL = {'s1': 100, 'pal': 128}
COPY_GAIN = 64
S1_ENTRY = np.array([(e & 31 | e >> 6 & 32, e >> 5 & 63) for e in range(4096)])

def copy_entries(res, src, dst, first, count):
    if res == 'pal':
        dst[first:first + count] = src[first:first + count]
    else:
        rc = S1_ENTRY[first:first + count]
        dst[rc[:, 0], rc[:, 1]] = src[rc[:, 0], rc[:, 1]]

def changed(a, b):
    """Indices (cells or palette entries) where a differs from b."""
    if a.ndim == 1:
        return [(int(i),) for i in np.nonzero(a != b)[0]]
    return [tuple((int(v) for v in rc)) for rc in np.argwhere((a != b).any(-1))]

def emit(res, buf, items, content):
    """Ops writing `items` of resource `res` from `content` into buffer `buf`."""
    if not items:
        return b''
    flag = buf << 8
    if res == 'pal':
        out = bytearray()
        idx = sorted((i for i, in items))
        start = prev_i = idx[0]
        for i in idx[1:] + [None]:
            if i is None or i - prev_i > 3:
                out += w16(5 | flag) + w16(start) + w16(prev_i - start + 1)
                out += b''.join((w16(v) for v in content[start:prev_i + 1]))
                start = i
            if i is not None:
                prev_i = i
        return bytes(out)
    op, run_op, offset = (7, 12, s1_offset) if res == 's1' else (1, 13, s2_offset)
    if res == 's2' and content.shape[:2] == (64, 64):
        op, run_op = (15, 16)
    single, runs = ([], [])
    for it in sorted(items, key=lambda rc: offset(*rc)):
        if runs and offset(*it) == offset(*runs[-1][-1]) + 4:
            runs[-1].append(it)
        else:
            runs.append([it])
    out = bytearray()
    for run in runs:
        if len(run) < RUN_MIN:
            single += run
            continue
        out += w16(run_op | flag) + w16(len(run)) + w16(offset(*run[0]))
        out += b''.join((w16(content[r, c, 0]) + w16(content[r, c, 1]) for r, c in run))
    if single:
        out += w16(op | flag) + w16(len(single))
        for r, c in single:
            out += w16(offset(r, c)) + w16(content[r, c, 0]) + w16(content[r, c, 1])
    return bytes(out)

def scan_order(res, items):
    """Cells in the map's scan order (so a prefetch's share makes long runs, ops 12/13)."""
    if res == 'pal':
        return items
    offset = s1_offset if res == 's1' else s2_offset
    return sorted(items, key=lambda rc: offset(*rc))

def row_fit(rows, period=512):
    """(span, x0): the 16-aligned SCROLL2 X with the smallest span of the lines above it. The"""
    vals = np.unique(np.asarray(rows) & period - 1)
    best = None
    for c in np.unique(vals & ~15):
        span = int((vals - c & period - 1).max())
        if best is None or span < best[0]:
            best = (span, int(c))
    return best

def row_span(rows):
    return row_fit(rows)[0]

def row_base(rows, t=None, period=512):
    """(x0, rows - x0 mod 512): the SCROLL2 X register for a row table (row_fit) and the lines'"""
    span, x0 = row_fit(rows, period)
    if span > ROW_SPAN:
        raise SystemExit(f'frame {t}: row scroll spans {span:#x} above X {x0:#x}; jtcps1 fetches one SCROLL2 row of 49 tiles from the X register, so a line may be at most {ROW_SPAN:#x} above it')
    return (x0, np.asarray(rows) - x0 & period - 1)

def row_runs(rel):
    runs = []
    for v in rel:
        if runs and runs[-1][1] == v:
            runs[-1][0] += 1
        else:
            runs.append([1, int(v)])
    return runs
RESERVE = {'s1': 16, 's2': 16, 'pal': 8}

def encode_stream(states, pals, cont=None, pre_extra=0):
    """All records. Each layer map and the palette have a pool of buffers"""
    n = len(states)
    targets = {'s1': [st['s1']['cells'] if st['s1'] else None for st in states], 's2': [st['s2']['cells'] if st['s2'] else None for st in states], 'pal': pals}
    s2_shape = next((a.shape for a in targets['s2'] if a is not None), (32, 32, 2))
    zero = {'s1': np.zeros((64, 64, 2), np.int32), 's2': np.zeros(s2_shape, np.int32), 'pal': np.zeros(3072, np.int32)}
    cuts = {}
    mand = [2] * (n + 1)
    for res, ts in targets.items():
        prev, cuts[res] = (zero[res], [])
        for t, tg in enumerate(ts):
            if tg is not None:
                k = len(changed(tg, prev))
                if k > DIRECT_MAX[res] or (cont is not None and prev is zero[res]):
                    cuts[res].append(t)
                    mand[t] += 8
                elif k:
                    mand[t] += 2 + 2 * k + 6 * -(-k // 8) if res == 'pal' else 4 + 6 * k
                prev = tg
    for t in range(n):
        sp, last = (states[min(t + SPRITE_LEAD, n - 1)]['sprites'], states[min(max(t - 1 + SPRITE_LEAD, 0), n - 1)]['sprites'])
        if t == 0 or sp != last:
            mand[t] += 4 + 8 * len(sp)
        if states[t]['s2']:
            mand[t] += 6 + 4 * len(row_runs(states[t]['s2']['rows'])) + 4
        mand[t] += 6 + 6 + 2
    load = sum((len(changed(targets[res][0], zero[res])) * PRE_COST[res] for res in cuts if cuts[res] and cuts[res][0] == 0))
    pre = max(SPRITE_LEAD, int(-(-load // PRE_LINES))) + pre_extra
    buf = {res: [zero[res].copy() for _ in RES[res]] for res in RES}
    front = {res: cont[res] if cont else 0 for res in RES}
    reserved = {res: [cont[res], None] for res in RES} if cont else {}

    def blocked(res, t):
        """Buffers a cut, a prefetch or a copy may not use at record t (the previous scene's fronts)."""
        r = reserved.get(res)
        return {r[0]} if r and (r[1] is None or t < r[1]) else set()
    assign = {res: {} for res in RES}
    copying = {}
    copied = {res: set() for res in RES}
    stream, offsets = (bytearray(), [])
    state = dict(s1_scroll=None, s2_y=None, rows=None, sprites='held' if cont else [], ctrl='held' if cont else None)
    plan = dict(prev=T.BASE, sprites=None)

    def record(body):
        body += w16(0)
        if len(body) > TAIL:
            ops = {}
            for op, _, q in T.ops(bytes(body)):
                ops[op] = ops.get(op, 0) + T.op_size(body, q)
            raise SystemExit(f'frame {t}: record of {len(body)} bytes (the player takes {TAIL}): bytes by op {ops}')
        a, sprites, _ = T.apply_lines(bytes(body))
        flip = T.FLIP_ENTRY * (plan['sprites'] + 1 + CAP_ALLOW) if plan['sprites'] is not None else 0.0
        plan.update(prev=T.BASE + flip + a, sprites=sprites)
        stream.extend(w16(len(body)) + body)
    for t in range(-pre, n):
        body = bytearray(w16(14) if t == 0 else b'')
        flips = palcopy = False
        for res in RES:
            f = front[res]
            tg = targets[res][t] if t >= 0 else None
            if t in cuts[res]:
                b = assign[res].pop(t, None)
                if b is None:
                    free = set(range(len(RES[res]))) - {f} - set(assign[res].values()) - blocked(res, t)
                    if not free:
                        raise SystemExit(f"frame {t}: a {res} cut finds no free buffer (the last scene's still reserved)")
                    b = min(sorted(free), key=lambda k: len(changed(tg, buf[res][k])))
                if (res, b) in copying:
                    raise SystemExit(f'frame {t}: cut before its buffer copy finished')
                body += emit(res, b, changed(tg, buf[res][b]), tg)
                buf[res][b] = tg.copy()
                copied[res].discard(b)
                if res in reserved and f == reserved[res][0] and (b != f) and (reserved[res][1] is None):
                    reserved[res][1] = t + RESERVE[res]
                front[res], flips = (b, True)
                palcopy |= res == 'pal'
            elif tg is not None:
                items = changed(tg, buf[res][f])
                body += emit(res, f, items, tg)
                buf[res][f] = tg.copy()
                palcopy |= res == 'pal' and bool(items)
        if flips:
            body += w16(9) + b''.join((w16(RES[res][front[res]]) for res in ('s1', 's2', 'pal')))
        if t >= 0:
            st = states[t]
            if st['s2']:
                s2 = st['s2']
                if s2['y'] != state['s2_y']:
                    body += w16(3) + w16(s2['y'])
                    state['s2_y'] = s2['y']
                if state['rows'] is None or (s2['rows'] != state['rows']).any():
                    x0, rel = row_base(s2['rows'], t, 1024 if s2['cells'].shape[0] == 64 else 512)
                    runs = row_runs(rel)
                    body += w16(4) + w16(len(runs)) + w16(x0) + b''.join((w16(k) + w16(v) for k, v in runs))
                    state['rows'] = s2['rows']
            if st['s1'] and (st['s1']['x'], st['s1']['y']) != state['s1_scroll']:
                body += w16(8) + w16(st['s1']['x']) + w16(st['s1']['y'])
                state['s1_scroll'] = (st['s1']['x'], st['s1']['y'])
            order = LAYERS_S1 if not st['s2'] else LAYERS_S2
            en = (4 if st['s2'] else 0) | (2 if st['s1'] else 0) if st['bg_on'] else 0
            ctrl = (order | 8 | en, COVER if st['cover'] else 0)
        else:
            ctrl = state['ctrl'] if cont else (LAYERS_S1 | 8, 0)
        if ctrl != state['ctrl']:
            body += w16(6) + w16(ctrl[0]) + w16(ctrl[1])
            state['ctrl'] = ctrl
        if palcopy:
            body += w16(11)
        sprites = states[min(t + SPRITE_LEAD, n - 1)]['sprites'] if t >= -SPRITE_LEAD else state['sprites']
        if sprites != state['sprites']:
            body += sprite_record(sprites)
            state['sprites'] = sprites
        ring = len(stream) % T.RSIZE
        mand_next = mand[t + 1] if 0 <= t + 1 < n else 64
        flip_here = T.FLIP_ENTRY * (plan['sprites'] + 1 + CAP_ALLOW) if plan['sprites'] is not None else 0.0

        def room(nbytes, lines, extra=None):
            """Items of nbytes stream bytes and `lines` of apply time each that still fit: handler k-1"""
            whole = bytes(body) + (extra or b'')
            size = len(whole) + 4
            per = T.DECODE_BYTE + (T.MIRROR_BYTE if ring + size + BUDGET > T.RSIZE else 0.0)
            a = T.HANDLER_LINES - plan['prev'] - per * (size + (0 if extra is not None else 6))
            b = T.HANDLER_LINES - T.BASE - flip_here - T.apply_lines(whole + w16(0))[0] - T.DECODE_BYTE * (mand_next + 2)
            if extra is not None:
                return -1 if a < 0 or b < 0 else 0
            fits = [a / (per * nbytes)] if nbytes else []
            if lines:
                fits.append(b / lines)
            return max(0, int(min(fits))) if fits else 0
        pending = []
        for res in RES:
            for c in [c for c in cuts[res] if t < c <= t + PREFETCH]:
                if c not in assign[res]:
                    free = set(range(len(RES[res]))) - {front[res]} - set(assign[res].values()) - blocked(res, t)
                    if not free:
                        break
                    goal = targets[res][c]
                    assign[res][c] = min(sorted(free), key=lambda k: len(changed(goal, buf[res][k])))
                pending.append((c, res))
        if NEED_FIRST:
            for c, res in sorted(pending):
                bk, goal = (assign[res][c], targets[res][c])
                if (res, bk) in copying:
                    continue
                todo = scan_order(res, changed(goal, buf[res][bk]))
                take = todo[:-(-len(todo) // (c - t))]
                body += emit(res, bk, take, goal)
                for it in take:
                    buf[res][bk][it] = goal[it]
        for c, res in sorted(pending):
            bk, goal = (assign[res][c], targets[res][c])
            if res in COPY_CHUNK:
                if (res, bk) not in copying and c - t > COPY_LEAD[res] and (bk not in copied[res]):
                    src = min((k for k in range(len(RES[res])) if k != bk and k not in blocked(res, t)), key=lambda k: len(changed(goal, buf[res][k])), default=None)
                    if src is not None and len(changed(goal, buf[res][src])) + COPY_GAIN < len(changed(goal, buf[res][bk])):
                        copying[res, bk] = (0, src)
                if (res, bk) in copying:
                    k, src = copying[res, bk]
                    cnt = min(COPY_CHUNK[res], COPY_SIZE[res] - k)
                    chunks_left = -(-(COPY_SIZE[res] - k) // COPY_CHUNK[res])
                    tail = -(-len(changed(goal, buf[res][src])) // COPY_TAIL[res])
                    due = chunks_left + tail >= c - t
                    if not due and room(12, T.OP + T.APPLY[10][COPY_KIND[res]] * cnt) < 1:
                        continue
                    body += w16(10) + w16(COPY_KIND[res]) + w16(src) + w16(bk) + w16(k) + w16(cnt)
                    copy_entries(res, buf[res][src], buf[res][bk], k, cnt)
                    if k + cnt == COPY_SIZE[res]:
                        del copying[res, bk]
                        copied[res].add(bk)
                    else:
                        copying[res, bk] = (k + cnt, src)
                        continue
            todo = scan_order(res, changed(goal, buf[res][bk]))
            cost = 2 if res == 'pal' else 4
            per_item = T.APPLY[5] if res == 'pal' else T.APPLY[12 if res == 's1' else 13]
            need = 0 if NEED_FIRST else -(-len(todo) // (c - t))
            fit = min((BUDGET - len(body)) // cost, room(cost, per_item) if todo else 0)
            take = todo[:max(need, min(len(todo), max(fit, 0)))]
            ops = emit(res, bk, take, goal)
            while len(take) > need and room(len(ops), 0, extra=ops) < 0:
                take = take[:max(need, len(take) * 7 // 8)]
                ops = emit(res, bk, take, goal)
            body += ops
            for it in take:
                buf[res][bk][it] = goal[it]
        if t >= 0:
            offsets.append(len(stream))
        record(body)
    stream += w16(65535)
    return (bytes(stream), pre, offsets, dict(front))

class CpsModel:
    """CPS-1 video state driven by the stream; renders as HBMAME video/cps1.cpp"""

    def __init__(self, region):
        self.region = region
        self.maps1 = [np.zeros((64, 64, 2), np.int32) for _ in RES['s1']]
        self.maps2 = [np.zeros((64, 64, 2), np.int32) for _ in RES['s2']]
        self.pals = [np.zeros(3072, np.int32) for _ in RES['pal']]
        self.front = {'s1': 0, 's2': 0, 'pal': 0}
        self.pal = np.zeros(3072, np.int32)
        self.sprites = []
        self.pending = []
        self.latched = []
        self.s1 = (0, 0)
        self.s2_y = 0
        self.s2_x = 0
        self.rows = np.zeros(256, np.int32)
        self.ctrl, self.prio = (LAYERS_S1 | 8, 0)
        self.cache = {}

    def pens(self, layer, code, half=None):
        k = (layer, code, half)
        if k not in self.cache:
            n = 8 if layer == 'scr1' else 16
            self.cache[k] = G.get_tile(self.region, G.ex_offset(layer, code), n, half)
        return self.cache[k]

    def run(self, data, pos):
        """Play one record (the VBlank handler: first the sprite list flip, the"""
        self.latched, self.pending = (self.pending, self.sprites)
        size, = struct.unpack_from('>H', data, pos)
        if size == 65535:
            return None
        pos += 2
        end = pos + size
        while True:
            word, = struct.unpack_from('>H', data, pos)
            op, bank = (word & 255, word >> 8)
            pos += 2
            if op == 0:
                if pos != end:
                    raise ValueError('record length mismatch')
                return pos
            if op == 11:
                self.pal = self.pals[self.front['pal']].copy()
                continue
            if op == 14:
                continue
            if op in (12, 13, 16):
                n, off = struct.unpack_from('>2H', data, pos)
                for i in range(n):
                    code, attr = struct.unpack_from('>2H', data, pos + 4 + 4 * i)
                    e = off // 4 + i
                    if op in (13, 16):
                        row, col = (e & 15 | e >> 6 & 48, e >> 4 & 63)
                        for dr in (0, 32) if op == 13 else (0,):
                            for dc in (0, 32) if op == 13 else (0,):
                                self.maps2[bank][row + dr, col + dc] = (code, attr)
                    else:
                        row, col = (e & 31 | e >> 6 & 32, e >> 5 & 63)
                        self.maps1[bank][row, col] = (code, attr)
                pos += 4 + 4 * n
                continue
            if op in (1, 7, 15):
                n, = struct.unpack_from('>H', data, pos)
                for i in range(n):
                    off, code, attr = struct.unpack_from('>3H', data, pos + 2 + 6 * i)
                    e = off // 4
                    if op in (1, 15):
                        row, col = (e & 15 | e >> 6 & 48, e >> 4 & 63)
                        for dr in (0, 32) if op == 1 else (0,):
                            for dc in (0, 32) if op == 1 else (0,):
                                self.maps2[bank][row + dr, col + dc] = (code, attr)
                    else:
                        row, col = (e & 31 | e >> 6 & 32, e >> 5 & 63)
                        self.maps1[bank][row, col] = (code, attr)
                pos += 2 + 6 * n
            elif op == 2:
                n, = struct.unpack_from('>H', data, pos)
                self.sprites = [struct.unpack_from('>4H', data, pos + 2 + 8 * i) for i in range(n)]
                pos += 2 + 8 * n
            elif op == 3:
                self.s2_y, = struct.unpack_from('>H', data, pos)
                pos += 2
            elif op == 4:
                n, self.s2_x = struct.unpack_from('>2H', data, pos)
                vals = []
                for i in range(n):
                    cnt, v = struct.unpack_from('>2H', data, pos + 4 + 4 * i)
                    if v > ROW_SPAN or self.s2_x & 15:
                        raise ValueError(f'row value {v:#x} over X {self.s2_x:#x}: past what jtcps1 fetches')
                    vals += [v] * cnt
                assert len(vals) == 256
                self.rows = np.array(vals, np.int32)
                pos += 4 + 4 * n
            elif op == 5:
                start, n = struct.unpack_from('>2H', data, pos)
                self.pals[bank][start:start + n] = struct.unpack_from(f'>{n}H', data, pos + 4)
                pos += 4 + 2 * n
            elif op == 6:
                self.ctrl, self.prio = struct.unpack_from('>2H', data, pos)
                pos += 4
            elif op == 9:
                for res, v in zip(('s1', 's2', 'pal'), struct.unpack_from('>3H', data, pos)):
                    self.front[res] = RES[res].index(v)
                pos += 6
            elif op == 10:
                kind, src, dst, first, count = struct.unpack_from('>5H', data, pos)
                if kind == 0:
                    copy_entries('s1', self.maps1[src], self.maps1[dst], first, count)
                else:
                    copy_entries('pal', self.pals[src], self.pals[dst], first, count)
                pos += 10
            elif op == 8:
                self.s1 = struct.unpack_from('>2H', data, pos)
                pos += 4
            else:
                raise ValueError(f'bad stream op {op:#x} at {pos - 2}')

    def layer(self, tmap, tx, ty, n, gfx, pal_base, halves):
        """(palette entries, pens) of one tilemap layer."""
        code = tmap[ty // n, tx // n, 0]
        attr = tmap[ty // n, tx // n, 1]
        half = tx // n & 1 if halves else np.zeros_like(code)
        key = code * 2 + half
        uniq = np.unique(key)
        stack = np.stack([self.pens(gfx, int(k) >> 1, int(k) & 1 if halves else None) for k in uniq])
        pen = stack[np.searchsorted(uniq, key), ty % n, tx % n]
        return (pal_base + 16 * (attr & 31) + pen, pen)

    def draw_sprites(self, out, blocked):
        for x, y, code, attr in reversed(self.latched):
            nx, ny = ((attr >> 8 & 15) + 1, (attr >> 12 & 15) + 1)
            for r in range(ny):
                for c in range(nx):
                    t = self.pens('obj', (code & ~15) + (code + c & 15) + 16 * r)
                    sx, sy = ((x + 16 * c & 511) - 64, (y + 16 * r & 511) - 16)
                    y0, y1 = (max(sy, 0), min(sy + 16, SCREEN_H))
                    x0, x1 = (max(sx, 0), min(sx + 16, SCREEN_W))
                    if y0 >= y1 or x0 >= x1:
                        continue
                    sub = t[y0 - sy:y1 - sy, x0 - sx:x1 - sx]
                    m = (sub != 15) & ~blocked[y0:y1, x0:x1]
                    out[y0:y1, x0:x1][m] = PAL_OBJ + 16 * (attr & 31) + sub[m]

    def render(self):
        """224x384 palette entry indices (bitmap x 64-447, y 16-239), drawn in"""
        shape = (SCREEN_H, SCREEN_W)
        out = np.full(shape, BACKDROP, np.int32)
        blocked = np.zeros(shape, bool)
        by = np.arange(16, 16 + SCREEN_H)[:, None]
        bx = np.arange(64, 64 + SCREEN_W)[None, :]
        order = [self.ctrl >> s & 3 for s in (6, 8, 10, 12)]
        for k, l in enumerate(order):
            pen = None
            if l == 2 and self.ctrl & 4:
                idx, pen = self.layer(self.maps2[self.front['s2']], bx + self.s2_x + self.rows[by] & 1023, np.broadcast_to(by + self.s2_y & 1023, shape), 16, 'scr2', PAL_S2, False)
            elif l == 1 and self.ctrl & 2:
                idx, pen = self.layer(self.maps1[self.front['s1']], np.broadcast_to(bx + self.s1[0] & 511, shape), np.broadcast_to(by + self.s1[1] & 511, shape), 8, 'scr1', PAL_S1, True)
            elif l == 0:
                self.draw_sprites(out, blocked)
            if pen is not None:
                out = np.where(pen != 15, idx, out)
                if k + 1 < 4 and order[k + 1] == 0:
                    blocked = (pen != 15) & (self.prio >> pen & 1 != 0)
        if self.ctrl & 8:
            out[:, :X_PICTURE] = PAL_S3
            out[:, X_PICTURE + 256:] = PAL_S3
        return out

def reference(d, writes, crop, raw=False, copyright=True):
    """The PCE picture in CPS color words, framed as the CPS screen: as EX draws it (bat_tiles: the"""
    idx = P.render(d, writes=writes, tiles=None if raw else bat_tiles(d, copyright))[crop:crop + SCREEN_H]
    word = np.array([G.cps_color(int(v)) for v in d['pal']], np.int32)
    out = np.full((SCREEN_H, SCREEN_W), BLACK, np.int32)
    out[:, X_PICTURE:X_PICTURE + 256] = word[idx]
    return out

def load_frame(run_dir, f, hide_sprites=()):
    """A census frame's video state. Frames in hide_sprites lose every sprite: an EX edit, the PC"""
    d = P.load(run_dir / f'pce_{f:05d}_scene.vdc')
    if f in hide_sprites:
        d['sat'] = np.zeros_like(d['sat'])
    return d

def convert(run_dir, frames, crop, cv=None, hide_sprites=(), keep=None, cont=None):
    """One cinematic. Pass the Converter of earlier cinematics to share its graphics"""
    cv = cv or Converter(crop)
    writes = P.read_writes(run_dir)
    states = [cv.frame_state(load_frame(run_dir, f, hide_sprites), writes.get(f)) for f in frames]
    cv.allocate_sprites(states)
    if keep is not None:
        states = [states[i] for i in keep]
    pals = [cv.palette(st) for st in states]
    best = None
    for extra in range(0, PRE_EXTRA_MAX + 1, PRE_STEP):
        stream, pre, offsets, fronts = encode_stream(states, pals, cont, extra)
        worst = max(T.predict(stream, LZ.encode(stream))[:pre])
        if best is None or worst < best[0]:
            best = (worst, extra, stream, pre, offsets, fronts)
        if worst <= T.HANDLER_LINES:
            break
    _, cv.pre_extra, stream, cv.preroll, offsets, cv.fronts = best
    return (cv, stream, offsets)

def check(cv, stream, frames, run_dir, crop, hide_sprites=()):
    model = CpsModel(cv.region)
    writes = P.read_writes(run_dir)
    pos, failures, dev_pixels = (0, [], 0)
    cv.blanked = {}
    cv.copyright = {}
    for _ in range(cv.preroll):
        pos = model.run(stream, pos)
    for i, f in enumerate(frames):
        pos = model.run(stream, pos)
        got = model.pal[model.render()]
        d = load_frame(run_dir, f, hide_sprites)
        want = reference(d, writes.get(f), crop)
        raw = reference(d, writes.get(f), crop, raw=True)
        if (raw != want).any():
            dots = reference(d, writes.get(f), crop, copyright=False)
            if (raw != dots).any():
                cv.blanked[i] = [(int(y), int(x)) for y, x in zip(*np.nonzero(raw != dots))]
            if (dots != want).any():
                ys, xs = np.nonzero(dots != want)
                cv.copyright[i] = (f, [(int(y), int(x)) for y, x in zip(ys, xs)])
                cv.glyphs_seen |= set(copyright_tiles(d).values())
                lo, hi = (max(int(ys.min()) - 8, 0), min(int(ys.max()) + 8, SCREEN_H - 1))
                left = want[lo:hi + 1, X_PICTURE:X_PICTURE + 256] != BLACK
                if left.any():
                    failures.append(dict(frame=f, copyright_left=int(left.sum()), lines=[lo, hi]))
                if (got[ys, xs] == dots[ys, xs]).any():
                    failures.append(dict(frame=f, copyright_shown=int((got[ys, xs] == dots[ys, xs]).sum())))
        bad = (got != want).any(1)
        allowed = np.zeros(SCREEN_H, bool)
        allowed[cv.deviations.get(f, [])] = True
        if (bad & ~allowed).any():
            failures.append(dict(frame=f, lines=np.nonzero(bad & ~allowed)[0][:8].tolist(), pixels=int((got != want)[bad & ~allowed].sum())))
        dev_pixels += int((got != want)[allowed].sum())
    if model.run(stream, pos) is not None or pos + 2 != len(stream):
        failures.append(dict(stream_left=len(stream) - pos))
    split = s1_split_codes(cv.region, len(cv.s1_codes))
    if split:
        failures.append(dict(s1_codes_with_two_tiles=[f'{c:#06x}' for c in split[:8]], count=len(split)))
    return (failures, dev_pixels)

def s1_split_codes(region, count):
    """SCROLL1 EX codes whose two 8x8 halves differ (jtcps1 would show the other half: the"""
    at = G.ex_offset('scr1', S1_BASE)
    rows = np.frombuffer(bytes(region[at:at + 64 * count]), np.uint8).reshape(count, 8, 2, 4)
    return [S1_BASE + int(i) for i in np.nonzero((rows[:, :, 0] != rows[:, :, 1]).any((1, 2)))[0]]

def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('--census', type=Path, required=True, help='pce_cinematic_census.py work directory')
    p.add_argument('--id', required=True, help='cinematic id in the census catalog (e.g. brief_siberia)')
    p.add_argument('--crop-top', type=int, default=16, help='PCE lines dropped above the 224 CPS lines')
    p.add_argument('--outdir', type=Path, required=True)
    a = p.parse_args()
    cat = json.loads((a.census / 'catalog/catalog.json').read_text())
    c = next((x for x in cat['cinematics'] if x['id'] == a.id))
    run_dir = a.census / c['run']
    t0 = c['cd_request_time']
    frames = frames_for(run_dir, t0, t0 + c['track_seconds'])
    cv, stream, offsets = convert(run_dir, frames, a.crop_top)
    failures, dev_pixels = check(cv, stream, frames, run_dir, a.crop_top)
    a.outdir.mkdir(parents=True, exist_ok=True)
    (a.outdir / 'scene.bin').write_bytes(stream)
    (a.outdir / 'gfx_ex.bin').write_bytes(bytes(cv.region))
    obj_end = cv.obj_shelf[0] + 16 * cv.obj_shelf[2] if cv.obj_shelf else OBJ_BASE
    sizes = np.diff(offsets + [len(stream)])
    timing = T.report(T.predict(stream, LZ.encode(stream)))
    if timing['over_limit']:
        failures.append(dict(handler_lines=timing))
    report = dict(id=a.id, track=c['track'], first_frame=frames[0], frames=len(frames), crop_top=a.crop_top, frames_on=cv.modes, s1_codes=len(cv.s1_codes), s2_tiles=len(cv.s2_codes), jtcps1_handler=timing, merged_palettes={k: len(m.lists) for k, m in cv.merged.items()}, sprite_blocks=len(cv.obj_codes), sprite_cells=len(cv.cell_codes), s2_codes=[S2_BASE, cv.next_s2 - 1], obj_codes=[OBJ_BASE, obj_end - 1], stream_bytes=len(stream), largest_records=sorted((int(x) for x in sizes))[-3:], preroll=cv.preroll, stream_sha256=hashlib.sha256(stream).hexdigest(), gfx_sha256=hashlib.sha256(cv.region).hexdigest(), deviated_frames={str(k): [v[0], v[-1], len(v)] for k, v in sorted(cv.deviations.items())}, deviated_pixels=dev_pixels, failures=failures[:20], failure_count=len(failures))
    (a.outdir / 'scene.json').write_text(json.dumps(report, indent=1) + '\n')
    print(json.dumps({k: v for k, v in report.items() if k not in ('deviated_frames', 'failures')}))
    print('deviated frames:', report['deviated_frames'])
    if failures:
        print('FAIL', failures[:5])
        return 1
    print('PASS: stream renders the capture exactly outside the listed deviation lines')
    return 0
if __name__ == '__main__':
    sys.exit(main())
