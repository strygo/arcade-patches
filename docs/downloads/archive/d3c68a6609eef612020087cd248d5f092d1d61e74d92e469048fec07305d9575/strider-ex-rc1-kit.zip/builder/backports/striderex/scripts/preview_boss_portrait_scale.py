"""Preview boss and cutscene width changes from a verified build, without editing ROMs."""
import argparse
import hashlib
import json
import struct
from pathlib import Path
import numpy as np
from PIL import Image, ImageDraw
import boss_scene as S
import boss_scene_binary as B
import cps1_gfx as G
import portrait_gate as PG
from rescale_pilot import method_edge_pick

def digest(data):
    return hashlib.sha256(data).hexdigest()

def page_data(bank, at):
    pos = at + 44 + 12 * B.word(bank, at + 42)
    lists = []
    for _ in range(2):
        count = B.word(bank, pos)
        pos += 2
        lists.append([list(struct.unpack_from('>4H', bank, pos + 8 * k)) for k in range(count)])
        pos += 8 * count
    return dict(ui=list(struct.unpack_from('>16H', bank, at + 10)), before=lists[0], after=lists[1])

def source_picture(gfx, code):
    wide = np.concatenate([np.concatenate([G.get_tile(gfx, G.ex_offset('obj', code + x + 16 * y), 16) for x in range(8)], axis=1) for y in range(5)], axis=0)
    if not np.all(wide[:, 120:] == 15):
        raise ValueError('Portrait padding is not transparent')
    wide = np.where(wide[:, :120] == 15, -1, wide[:, :120])
    source = wide[:, np.array([x // 2 * 3 + (2 if x % 2 else 0) for x in range(80)])]
    if not np.array_equal(method_edge_pick(source), wide):
        raise ValueError('Recovered source does not reproduce the exact encoded portrait')
    return source

def preview(build, out):
    meta = json.loads((build / 'build.json').read_text())
    machine = 'striderua'
    files = {n: (build / machine / n).read_bytes() for n in meta['sets'][machine]['files']}
    if {n: digest(b) for n, b in files.items()} != meta['sets'][machine]['files']:
        raise ValueError('Producer build inventory changed')
    gfx = PG.region_of(files)
    p6 = files['strex_p6.bin']
    bank = bytes((p6[k ^ 1] for k in range(len(p6))))
    records = {r['id']: r for r in B.scenes(bank)}
    out.mkdir(parents=True, exist_ok=True)
    rows = []
    checks = []
    for sid in ('stp_strongman', 'desert_commander'):
        record = records[sid]
        at = record['at']
        page = page_data(bank, record['pages'][0])
        pt = list(struct.unpack_from('>16H', bank, at + 8))
        x, y, attr, code = struct.unpack_from('>4H', bank, at + 40)
        source = source_picture(gfx, code)
        entries = page['before'] + [[x, y, code, attr]] + page['after']
        current = S.compose(entries, page['ui'], pt, gfx)
        px, py = (x - S.SCREEN[0], y - S.SCREEN[1])
        candidate = current.copy()
        candidate[py - 4:py + 84, px - 4:px + 124] = 0
        nx = px + 20
        red = np.array(S.rgb(page['ui'][1]), dtype=np.uint8)
        candidate[py - 4:py + 84, nx - 4:nx + 84] = red
        portrait = np.full((80, 80, 3), red, dtype=np.uint8)
        opaque = source >= 0
        lut = np.array([S.rgb(w) for w in pt], dtype=np.uint8)
        portrait[opaque] = lut[source[opaque]]
        candidate[py:py + 80, nx:nx + 80] = portrait
        outside = np.ones((224, 384), dtype=bool)
        outside[py - 4:py + 84, px - 4:px + 124] = False
        if not np.array_equal(candidate[outside], current[outside]):
            raise ValueError('Preview changed other page pixels')
        for name, image in (('current', current), ('native', candidate)):
            Image.fromarray(image).save(out / f'{sid}-{name}.png')
        rows.append((sid, current, candidate))
        checks.append(dict(scene=sid, source_rewidens_exactly=True, outside_portrait_and_frame_identical=True, source_size=[80, 80], current_size=[120, 80], frame=4))
    sheet = Image.new('RGB', (1280, 1040), (24, 24, 24))
    draw = ImageDraw.Draw(sheet)
    for row, (_, current, candidate) in enumerate(rows):
        for col, image in enumerate((current, candidate)):
            base = row * 520
            label = 'Current: 120 x 80' if col == 0 else 'Preview: 80 x 80 (1:1 source pixels)'
            draw.text((col * 640 + 12, base + 12), label, fill='white')
            sheet.paste(Image.fromarray(image).resize((640, 480), Image.Resampling.NEAREST), (col * 640, base + 40))
    path = out / 'boss-portrait-scale-preview.png'
    sheet.save(path)
    report = dict(schema='striderex-portrait-scale-preview/1', machine=machine, input_files=meta['sets'][machine]['files'], checks=checks, display_aspect='4:3', roms_modified=False, preview_sha256=digest(path.read_bytes()))
    (out / 'preview.json').write_text(json.dumps(report, indent=2) + '\n')
    print(path)

def filter_comparison(picture, out):
    """Compare two linear-light filters at native CPS frame size, before palette fitting."""
    import rescale_pilot as R
    values, inverse = np.unique(picture, return_inverse=True)
    palette = np.array([S.rgb(int(w)) for w in values], dtype=np.uint8)
    indices = inverse.reshape(picture.shape)
    linear, alpha = R.area_from_scale3x(indices, palette)
    scale3x = np.rint(R.lin_to_srgb(linear)).astype(np.uint8)
    lanczos_rgb, lanczos_alpha = R.method_lanczos(indices, palette)
    lanczos = np.rint(lanczos_rgb).astype(np.uint8)
    if scale3x.shape != (224, 384, 3) or lanczos.shape != scale3x.shape or (not np.allclose(alpha, 1)) or (not np.allclose(lanczos_alpha, 1)):
        raise ValueError('Filter dimensions or opacity changed')
    sheet = Image.new('RGB', (1280, 928), (24, 24, 24))
    draw = ImageDraw.Draw(sheet)
    outputs = []
    for col, (name, label, rgb) in enumerate((('scale3x-area', 'Scale3x + area downsample', scale3x), ('lanczos', 'Lanczos', lanczos))):
        image = Image.fromarray(rgb)
        path = out / f'cutscene-{name}.png'
        image.save(path)
        draw.text((col * 640 + 12, 10), label + ' - 384 x 224', fill='white')
        sheet.paste(image.resize((640, 480), Image.Resampling.NEAREST), (col * 640, 32))
        draw.text((col * 640 + 12, 524), 'Portrait detail (same crop and display proportions)', fill='white')
        sheet.paste(image.crop((120, 128, 264, 224)).resize((448, 384), Image.Resampling.NEAREST), (col * 640 + 96, 544))
        outputs.append(dict(method=name, file=path.name, sha256=digest(path.read_bytes()), colors=len(np.unique(rgb.reshape(-1, 3), axis=0))))
    target = out / 'scale3x-versus-lanczos.png'
    sheet.save(target)
    return dict(outputs=outputs, scale3x_intermediate_size=[768, 672], scale3x_reduction='2 columns by 3 rows averaged in linear light', lanczos='horizontal Lanczos resampling in linear light', output_size=[384, 224], display_aspect='4:3', display_resampling='nearest neighbour for both', palette_fitting_applied=False, comparison_sha256=digest(target.read_bytes()))

def preview_cinematic(build, out, sid, frame, compare_filters=False):
    """Widen one verified encoded cutscene frame with the portraits' method E."""
    import cinematic_convert as C
    import cinematic_lz as LZ
    meta = json.loads((build / 'build.json').read_text())
    spec = meta['sets']['striderua']
    files = {n: (build / 'striderua' / n).read_bytes() for n in spec['files']}
    if {n: digest(b) for n, b in files.items()} != spec['files']:
        raise ValueError('Producer build inventory changed')
    p6 = files['strex_p6.bin']
    bank = bytes((p6[k ^ 1] for k in range(len(p6))))
    scenes = {s['id']: s for s in meta['scenes']}
    scene = scenes[sid]
    if not 1 <= frame <= scene['preroll'] + scene['window']['frames']:
        raise ValueError('Frame is outside the selected scene')
    model = C.CpsModel(PG.region_of(files))

    def play(name, stop=None):
        sc = scenes[name]
        if sc['continues']:
            play(sc['continues'])
        off = spec['streams'][name] - B.BASE
        stream = LZ.decode(bank[off:], sc['stream_bytes'])
        if digest(stream) != sc['stream_sha256']:
            raise ValueError('Cinematic stream differs from the producer receipt')
        pos, count = (0, 0)
        while pos is not None and (stop is None or count < stop):
            pos = model.run(stream, pos)
            count += 1
    play(sid, frame)
    words = model.pal[model.render()]
    current = np.array([S.rgb(int(w)) for w in words.flat], np.uint8).reshape((224, 384, 3))
    picture = words[:, C.X_PICTURE:C.X_PICTURE + 256]
    wide = method_edge_pick(picture)
    assert wide.shape == (224, 384)
    assert np.array_equal(wide[:, 0::3], picture[:, 0::2])
    assert np.array_equal(wide[:, 2::3], picture[:, 1::2])
    widened = np.array([S.rgb(int(w)) for w in wide.flat], np.uint8).reshape((224, 384, 3))
    out.mkdir(parents=True, exist_ok=False)
    sheet = Image.new('RGB', (1280, 512), (24, 24, 24))
    draw = ImageDraw.Draw(sheet)
    for col, (label, pic) in enumerate((('Current cutscene', current), ('Preview: same 1.5x horizontal widening as boss portraits', widened))):
        draw.text((col * 640 + 12, 10), label, fill='white')
        sheet.paste(Image.fromarray(pic).resize((640, 480), Image.Resampling.NEAREST), (col * 640, 32))
    path = out / 'cutscene-widening-preview.png'
    sheet.save(path)
    source_path = out / 'cutscene-original-256x224.png'
    Image.fromarray(current[:, C.X_PICTURE:C.X_PICTURE + 256]).save(source_path)
    Image.fromarray(widened).save(out / 'cutscene-widened-native.png')
    report = dict(schema='striderex-cutscene-widening-preview/1', scene=sid, stream_record=frame, input_files=spec['files'], stream_sha256=scene['stream_sha256'], method='rescale_pilot.method_edge_pick', source_picture_size=[256, 224], widened_picture_size=[384, 224], display_aspect='4:3', source_picture_sha256=digest(source_path.read_bytes()), all_original_columns_preserved=True, roms_modified=False, type='static composite artwork preview; no ROM palette or tile allocation qualification', preview_sha256=digest(path.read_bytes()))
    if compare_filters:
        if (sid, frame) != ('brief_siberia', 600):
            raise ValueError('Portrait detail crop is defined only for Siberia record 600')
        report['filter_comparison'] = filter_comparison(picture, out)
    (out / 'preview.json').write_text(json.dumps(report, indent=2) + '\n')
    print(out / 'scale3x-versus-lanczos.png' if compare_filters else path)

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--build', type=Path, required=True)
    parser.add_argument('--outdir', type=Path, required=True)
    parser.add_argument('--cinematic', help='preview widening a cutscene instead of narrowing boss portraits')
    parser.add_argument('--frame', type=int, default=600, help='encoded stream record for a cutscene preview')
    parser.add_argument('--compare-filters', action='store_true', help='compare Scale3x plus area reduction with Lanczos on Siberia record 600')
    args = parser.parse_args()
    if args.cinematic:
        return preview_cinematic(args.build.resolve(), args.outdir.resolve(), args.cinematic, args.frame, args.compare_filters)
    if args.compare_filters:
        parser.error('--compare-filters requires --cinematic brief_siberia --frame 600')
    preview(args.build.resolve(), args.outdir.resolve())
if __name__ == '__main__':
    main()
