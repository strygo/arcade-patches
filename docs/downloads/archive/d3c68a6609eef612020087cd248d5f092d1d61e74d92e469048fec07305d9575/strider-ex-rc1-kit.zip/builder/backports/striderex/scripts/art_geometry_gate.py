"""Focused pixel and runtime checks for the Strider EX geometry pair."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import json
from pathlib import Path
import struct
import sys
import numpy as np
from PIL import Image, ImageDraw
import art_geometry as A
import boss_scene as S
import boss_scene_binary as B
from boss_voice_gate import inventory, sha
from preview_boss_portrait_scale import page_data
import portrait_gate as PG
import cinematic_convert as C
from reconstruct_private_build import decode_scene
import subtitle_ex as SX
import ex_gate as E
import desert_gate as D
import scene_gate as SG

def captions(bank, meta, machine):
    prefix = bytes.fromhex('720141f9' if machine == 'striderua' else '720041f9')
    hits = [i for i in range(0, 8192, 2) if bank[i:i + 4] == prefix and bank[i + 8:i + 16] == bytes.fromhex('08390000001fffff')]
    if len(hits) != 1:
        raise ValueError('subtitle table entry changed')
    at = hits[0]
    normal = B.long(bank, at + 4) - B.BASE
    dub_ops = [i for i in range(at + 10, at + 55, 2) if bank[i:i + 2] == bytes.fromhex('41f9')]
    if len(dub_ops) != 1:
        raise ValueError('English dub table is not unique')
    dub = B.long(bank, dub_ops[0] + 2) - B.BASE
    pages, page_index, schedules = ([], {}, {})
    for i, sc in enumerate(meta['scenes']):
        schedules[sc['id']] = {}
        for lang, table, col in (('ja', normal, 0), ('en', normal, 4), ('en_dub', dub, 4)):
            pos = B.long(bank, table + 8 * i + col) - B.BASE
            rows = []
            for _ in range(1000):
                record = B.word(bank, pos)
                if record == 65535:
                    break
                ptr = B.long(bank, pos + 2)
                page = None
                if ptr:
                    if ptr not in page_index:
                        count = B.word(bank, ptr - B.BASE)
                        if count > C.CAP_ALLOW:
                            raise ValueError('caption exceeds the reserved list space')
                        entries = [list(struct.unpack_from('>4H', bank, ptr - B.BASE + 2 + 8 * k)) for k in range(count)]
                        page_index[ptr] = len(pages)
                        pages.append(('ja' if lang == 'ja' else 'en', entries))
                    page = page_index[ptr]
                rows.append((record, page))
                pos += 6
            else:
                raise ValueError('unbounded subtitle schedule')
            schedules[sc['id']][lang] = rows
    return (schedules, pages)

def native_pixels(control, build, review):
    oldmeta, old = inventory(control)
    meta, files = inventory(build)
    checks, images = ([], [])
    for machine in files:
        original, new = (A.swap(old[machine]['strex_p6.bin']), A.swap(files[machine]['strex_p6.bin']))
        expected = bytearray(original)
        oldgfx, newgfx = (PG.region_of(old[machine]), PG.region_of(files[machine]))
        unchanged = np.ones(len(oldgfx), bool)
        for sc in B.scenes(original):
            at = sc['at']
            x, y, attr, rest = struct.unpack_from('>4H', original, at + 40)
            struct.pack_into('>H', expected, at + 40, x + 20)
            pt = list(struct.unpack_from('>16H', original, at + 8))
            codes = {rest}
            pos = B.long(original, at + 48) - B.BASE
            while B.word(original, pos):
                codes.add(B.word(original, pos + 2))
                pos += 4
            for code in codes:
                for row in range(5):
                    for col in range(8):
                        offset = A.G.ex_offset('obj', code + col + 16 * row)
                        unchanged[offset:offset + 128] = False
            for page in sc['pages']:
                pg = page_data(original, page)
                for code in sorted(codes):
                    before = S.compose(pg['before'] + [[x, y, code, attr]] + pg['after'], pg['ui'], pt, oldgfx)
                    after = S.compose(pg['before'] + [[x + 20, y, code, attr]] + pg['after'], pg['ui'], pt, newgfx)
                    px, py = (x - S.SCREEN[0], y - S.SCREEN[1])
                    want = before.copy()
                    want[py:py + 80, px:px + 128] = 0
                    source_cols = [k // 2 * 3 + (2 if k % 2 else 0) for k in range(80)]
                    want[py:py + 80, px + 20:px + 100] = before[py:py + 80, px + np.array(source_cols)]
                    if not np.array_equal(want, after):
                        raise ValueError(f"{machine} {sc['id']}: native portrait/page pixels differ")
                    checks.append(dict(machine=machine, scene=sc['id'], page=B.BASE + page, code=code))
                    if machine == 'striderua' and code == rest and (page == sc['pages'][0]) and (sc['id'] in ('stp_strongman', 'desert_commander')):
                        images.append((sc['id'], after, before))
        if bytes(expected) != new:
            raise ValueError('native build changes other program bytes')
        if np.any((np.frombuffer(oldgfx, np.uint8) != np.frombuffer(newgfx, np.uint8)) & unchanged):
            raise ValueError('native build changed graphics outside portrait blocks')
        for n in old[machine]:
            if n != 'strex_p6.bin' and (not n.startswith('strex_gfx.')) and (old[machine][n] != files[machine][n]):
                raise ValueError('native gameplay/audio ROM changed')
    review.mkdir(parents=True, exist_ok=False)
    sheet = Image.new('RGB', (1280, 1040), (24, 24, 24))
    draw = ImageDraw.Draw(sheet)
    for row, (sid, native, wide) in enumerate(images):
        for col, picture in enumerate((native, wide)):
            draw.text((col * 640 + 12, row * 520 + 12), 'Native pixels: 80 x 80' if col == 0 else 'Method E: 120 x 80', fill='white')
            sheet.paste(Image.fromarray(picture).resize((640, 480), Image.Resampling.NEAREST), (col * 640, row * 520 + 40))
    sheet.save(review / 'boss-comparison.png')
    return dict(passed=True, build_files={m: s['files'] for m, s in meta['sets'].items()}, page_mouth_images=len(checks), checks=checks)

def wide_pixels(control, build):
    source, old = inventory(control)
    meta, files = inventory(build)
    converted = json.loads((build / 'conversion/conversion.json').read_text())
    if len(converted['scenes']) != len(source['scenes']):
        raise ValueError('widening omitted a scene')
    for scene in converted['scenes']:
        sc = next((s for s in source['scenes'] if s['id'] == scene['id']))
        if scene['pixel_frames_checked'] != sc['window']['frames'] or scene['preroll'] != sc['preroll'] or scene['timing']['over_limit']:
            raise ValueError('scene pixels, cue record or timing not qualified')
    boss_checks = 0
    for machine in files:
        before, after = (A.swap(old[machine]['strex_p6.bin']), A.swap(files[machine]['strex_p6.bin']))
        gfx0, gfx1 = (PG.region_of(old[machine]), PG.region_of(files[machine]))
        for name in old[machine]:
            if name != 'strex_p6.bin' and (not name.startswith('strex_gfx.')) and (old[machine][name] != files[machine][name]):
                raise ValueError('widening changed native gameplay/audio ROMs')
        if gfx0[1572864:2097152] != gfx1[1572864:2097152] or gfx0[3145728:] != gfx1[3145728:]:
            raise ValueError('widening changed reserved portraits, captions or SCROLL3 graphics')
        kept = A.still_codes(before)
        for layer in ('s1', 's2'):
            for code in kept[layer]:
                offset = A.G.ex_offset('scr1' if layer == 's1' else 'scr2', code)
                size = 64 if layer == 's1' else 128
                if gfx0[offset:offset + size] != gfx1[offset:offset + size]:
                    raise ValueError('widening changed a stage-select snapshot dependency')
        allowed = np.zeros(len(before), bool)
        spec0, spec1 = (source['sets'][machine], meta['sets'][machine])
        for sc in source['scenes']:
            at = spec0['streams'][sc['id']] - B.BASE
            raw, _ = decode_scene(before[at:])
            comp = A.LZ.encode(raw)
            allowed[at:at + len(comp) + 17 & ~1] = True
            at = spec1['streams'][sc['id']] - B.BASE
            raw, _ = decode_scene(after[at:])
            comp = A.LZ.encode(raw)
            if sha(raw) != next((s['stream_sha256'] for s in converted['scenes'] if s['id'] == sc['id'])):
                raise ValueError('delivered scene differs from all-frame pixel check')
            allowed[at:at + len(comp) + 33 & ~1] = True
        table = int(spec0['nopack_cues_at'], 16) - B.BASE - 8 * len(source['scenes'])
        for k in range(len(source['scenes'])):
            allowed[table + 8 * k:table + 8 * k + 4] = True
        helper = json.loads((build / 'geometry.json').read_text())['regions'][machine]['helper']
        at = helper['entry'] - B.BASE
        allowed[at:at + 6] = True
        off = helper['helper'] - B.BASE
        allowed[off:off + helper['bytes']] = True
        if sha(after[off:off + helper['bytes']]) != helper['sha256']:
            raise ValueError('wide dispatch helper differs')
        if np.any((np.frombuffer(before, np.uint8) != np.frombuffer(after, np.uint8)) & ~allowed):
            raise ValueError('widening changed unrelated program/data bytes')
        for sc in B.scenes(before):
            at = sc['at']
            x, y, attr, rest = struct.unpack_from('>4H', before, at + 40)
            pt = list(struct.unpack_from('>16H', before, at + 8))
            codes = {rest}
            pos = B.long(before, at + 48) - B.BASE
            while B.word(before, pos):
                codes.add(B.word(before, pos + 2))
                pos += 4
            for pg_at in sc['pages']:
                pg = page_data(before, pg_at)
                for code in codes:
                    entries = pg['before'] + [[x, y, code, attr]] + pg['after']
                    if not np.array_equal(S.compose(entries, pg['ui'], pt, gfx0), S.compose(entries, pg['ui'], pt, gfx1)):
                        raise ValueError('Method E boss portrait/page changed')
                    boss_checks += 1
    return dict(passed=True, build_files={m: s['files'] for m, s in meta['sets'].items()}, scenes=converted['scenes'], graphics_tiles=converted['tiles'], boss_page_mouth_images=boss_checks, native_program_audio_and_subtitles_preserved=True, original_stage_select_graphics_preserved=True)

def comparison(native, wide, out):
    out.mkdir(parents=True, exist_ok=False)
    sheet = Image.new('RGB', (1280, 1040), (24, 24, 24))
    draw = ImageDraw.Draw(sheet)
    for col, build in enumerate((native, wide)):
        meta, files = inventory(build)
        machine = 'striderua'
        bank = A.swap(files[machine]['strex_p6.bin'])
        gfx = PG.region_of(files[machine])
        schedules, pages = captions(bank, meta, machine)
        raw, _ = decode_scene(bank[meta['sets'][machine]['streams']['brief_siberia'] - B.BASE:])
        model = SX.CaptionModel(gfx, raw, schedules['brief_siberia']['en_dub'], pages)
        for _ in range(600):
            model.step()
        words = model.render()
        values, inv = np.unique(words, return_inverse=True)
        lut = np.array([SG.hb_rgb(int(v)) for v in values], np.uint8)
        cinematic = lut[inv].reshape(224, 384, 3)
        sc = next((s for s in B.scenes(bank) if s['id'] == 'desert_commander'))
        at = sc['at']
        x, y, attr, rest = struct.unpack_from('>4H', bank, at + 40)
        pt = list(struct.unpack_from('>16H', bank, at + 8))
        pg = page_data(bank, sc['pages'][0])
        boss = S.compose(pg['before'] + [[x, y, rest, attr]] + pg['after'], pg['ui'], pt, gfx)
        for row, (label, picture) in enumerate((('Siberia briefing', cinematic), ('Desert commander', boss))):
            title = ('1: Native pixels' if col == 0 else '2: Method E, 1.5x horizontal') + ' - ' + label
            draw.text((col * 640 + 12, row * 520 + 12), title, fill='white')
            sheet.paste(Image.fromarray(picture).resize((640, 480), Image.Resampling.NEAREST), (col * 640, row * 520 + 40))
    path = out / 'geometry-comparison.png'
    sheet.save(path)
    return dict(passed=True, sha256=sha(path.read_bytes()), display_aspect='4:3', rendered_from_final_builds=True)

def dispatch_timing(build):
    """Conservative extra allowance for the optional dispatch trampoline."""
    meta, files = inventory(build)
    bank = A.swap(files['striderua']['strex_p6.bin'])
    results = []
    for scene in meta['scenes']:
        raw, _ = decode_scene(bank[meta['sets']['striderua']['streams'][scene['id']] - B.BASE:])
        records = A.T.records(raw)
        comp = A.LZ.encode(raw)
        lines = A.T.predict(raw, comp, [(k, 0) for k in range(len(records))], [('en', [0] * C.CAP_ALLOW)])
        bounded = [t + 0.25 * len(A.T.ops(body)) for t, (_, body) in zip(lines, records)]
        result = dict(scene=scene['id'], **A.T.report(bounded))
        if result['over_limit']:
            raise ValueError('dispatch overhead exceeds the handler limit')
        results.append(result)
    return dict(passed=True, build_files={m: s['files'] for m, s in meta['sets'].items()}, allowance_lines_per_operation=0.25, clock_hz=8000000, maximum_caption_entries_every_record=C.CAP_ALLOW, results=results)

def runtime(a):
    for key in ('build', 'runtime', 'hbmame', 'rom_dir', 'workdir'):
        setattr(a, key, getattr(a, key).resolve())
    meta, files = inventory(a.build)
    rt = json.loads((a.runtime / 'runtime.json').read_text())
    binary = Path(rt['binary'])
    if sha(binary.read_bytes()) != rt['binary_sha256']:
        raise ValueError('prepared runtime changed')
    a.workdir.mkdir(parents=True, exist_ok=a.reuse)
    sources = {}
    staged = {}
    for machine, sn in (('striderua', 'striderus01'), ('striderjr', 'striderjs01')):
        bank = A.swap(files[machine]['strex_p6.bin'])
        schedules, pages = captions(bank, meta, machine)
        streams = {s['id']: decode_scene(bank[meta['sets'][machine]['streams'][s['id']] - B.BASE:])[0] for s in meta['scenes']}
        sources[machine] = (streams, schedules, pages)
        for flag in (0, 1):
            target = a.workdir / 'variants' / f'{machine}_{flag}'
            members = dict(files[machine])
            p6 = bytearray(members['strex_p6.bin'])
            p6[-2] = p6[-2] & ~7 | flag
            members['strex_p6.bin'] = bytes(p6)
            staged[machine, flag] = a.workdir / 'sets' / f'{machine}_{flag}'
            if a.reuse and (target / 'build.json').exists():
                _, prior = inventory(target)
                if prior[machine] != members:
                    raise ValueError('reused runtime input changed')
            else:
                dest = target / machine
                dest.mkdir(parents=True)
                for n, b in members.items():
                    (dest / n).write_bytes(b)
                (target / 'build.json').write_text(json.dumps(dict(sets={machine: dict(files={n: sha(b) for n, b in members.items()})})) + '\n')
                D.stage_sets(target, sn, a.hbmame, a.rom_dir, staged[machine, flag])
    jobs = [(m, sn, flag, stage) for m, sn in (('striderua', 'striderus01'), ('striderjr', 'striderjs01')) for flag in (0, 1) for stage in map(int, a.stages.split(','))]

    def run(job):
        machine, sn, flag, stage = job
        out = a.workdir / 'runs' / f'{machine}_{flag}_{stage}'
        if a.reuse and (out / 'log.tsv').exists():
            log = [tuple((int(v, 16) if i in (2, 3) else int(v) for i, v in enumerate(line.split('\t')))) for line in (out / 'log.tsv').read_text().splitlines()]
        else:
            log, _ = E.run(binary, staged[machine, flag], sn, out, 6500 if stage == 0 else 5500 if stage == 4 else 3800, stage)
        spec = meta['sets'][machine]
        streams, schedules, pages = sources[machine]
        starts = sorted(((at, sid) for sid, at in spec['streams'].items()))

        def scene_of(ptr):
            return max(((a, sid) for a, sid in starts if a <= ptr))[1]
        active = {f: (record, scene_of(ptr)) for f, record, ptr, ac, *_ in log if ac == 49637}
        photos = {}
        for path in out.glob('s_*.png'):
            f = int(path.stem[2:])
            record, sid = active[f]
            pre = next((s['preroll'] for s in meta['scenes'] if s['id'] == sid))
            if record < pre + 3:
                continue
            photos.setdefault(sid, []).append((record, path))
        seen = list(photos)
        expected = [s for s in {0: ['prologue', 'brief_st_petersburg'], 1: ['brief_siberia'], 2: ['brief_amazon'], 3: ['brief_aerial'], 4: ['flight', 'welcome_meio'], 5: ['intro_desert']}[stage]]
        if set(seen) != set(expected) or log[-1][3] in (49637, 49638):
            raise ValueError(f'{job}: scenes did not finish and return to gameplay')
        checked = 0
        offsets = {}
        for sid, shots in photos.items():
            lang = 'en_dub' if flag and machine == 'striderua' else 'en' if machine == 'striderua' else 'ja'
            needed = {r + dk for r, _ in shots for dk in E.OFFSETS if r + dk > 0}
            model = SX.CaptionModel(PG.region_of(files[machine]), streams[sid], schedules[sid][lang], pages)
            rendered, settled = ({}, {})
            rgb = {}
            for k in range(1, max(needed) + 1):
                if not model.step():
                    break
                if k in needed:
                    words = model.render()
                    values, inv = np.unique(words, return_inverse=True)
                    lut = np.array([rgb.setdefault(int(v), SG.hb_rgb(int(v))) for v in values], np.uint8)
                    rendered[k] = lut[inv].reshape(words.shape + (3,))
                    saved = model.m.latched
                    model.m.latched = model.m.sprites
                    words = model.render()
                    values, inv = np.unique(words, return_inverse=True)
                    lut = np.array([rgb.setdefault(int(v), SG.hb_rgb(int(v))) for v in values], np.uint8)
                    settled[k] = lut[inv].reshape(words.shape + (3,))
                    model.m.latched = saved
            fits = set()
            for r, path in shots:
                image = np.asarray(Image.open(path).convert('RGB'))
                matching = {dk for dk in E.OFFSETS if r + dk in rendered and np.array_equal(image, rendered[r + dk])}
                f = int(path.stem[2:])
                held = any((active.get(f + d, (None, None)) == (r, sid) for d in (-1, 1)))
                dma_settled = not flag and held and (r in settled) and np.array_equal(image, settled[r])
                if not matching and (not dma_settled):
                    raise ValueError(f'{job} {sid}: emulator pixels differ at record {r}')
                fits |= matching
                checked += 1
            if not fits:
                raise ValueError(f'{job} {sid}: emulator pixels differ from the encoded model')
            offsets[sid] = sorted(fits)
        tm = E.timing(out, {f: sid for f, (_, sid) in active.items()})
        if tm['late_records']:
            raise ValueError(f'{job}: late cinematic handlers')
        result = dict(machine=machine, pack=bool(flag), stage=stage, passed=True, screenshots=checked, offsets=offsets, timing=tm)
        print('PASS runtime', job, checked, 'pictures', flush=True)
        return result
    with ThreadPoolExecutor(max_workers=a.jobs) as pool:
        results = list(pool.map(run, jobs))
    return dict(passed=True, schema='striderex-geometry-runtime/1', runtime_sha256=rt['binary_sha256'], build_files={m: s['files'] for m, s in meta['sets'].items()}, results=results)

def main():
    if sys.argv[1:] == ['--self-test']:
        return self_test()
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('command', choices=('native', 'wide', 'runtime', 'preview', 'dispatch'))
    for n in ('build', 'receipt'):
        p.add_argument('--' + n, type=Path, required=True)
    for n in ('control', 'review', 'runtime', 'hbmame', 'rom-dir', 'workdir'):
        p.add_argument('--' + n, type=Path)
    p.add_argument('--stages', default='0,1,2,3,4,5')
    p.add_argument('--jobs', type=int, default=2)
    p.add_argument('--reuse', action='store_true')
    a = p.parse_args()
    report = native_pixels(a.control, a.build, a.review) if a.command == 'native' else wide_pixels(a.control, a.build) if a.command == 'wide' else dispatch_timing(a.build) if a.command == 'dispatch' else comparison(a.control, a.build, a.review) if a.command == 'preview' else runtime(a)
    a.receipt.write_text(json.dumps(report, indent=2) + '\n')

def self_test():
    bank = bytearray(b'\xff' * 20480)
    at = 256
    bank[at:at + 16] = bytes.fromhex('720141f90010200008390000001fffff')
    bank[at + 32:at + 38] = bytes.fromhex('41f900102040')
    for table in (8192, 8256):
        struct.pack_into('>2I', bank, table, B.BASE + 12288, B.BASE + 12288)
    struct.pack_into('>HIHIH', bank, 12288, 10, B.BASE + 16384, 30, 0, 65535)
    struct.pack_into('>H4H', bank, 16384, 1, 100, 100, 48128, 31)
    schedules, pages = captions(bank, dict(scenes=[dict(id='sample')]), 'striderua')
    assert len(pages) == 1 and schedules['sample']['en'] == [(10, 0), (30, None)]
    bank[at] ^= 1
    try:
        captions(bank, dict(scenes=[dict(id='sample')]), 'striderua')
    except ValueError:
        pass
    else:
        raise AssertionError('changed subtitle entry accepted')
    print('Geometry gate self-test PASS: binary caption schedules and entry guards')
if __name__ == '__main__':
    main()
