"""D10 gate: Hiryu's slash voice in the EX USA set."""
import argparse
import json
import os
import subprocess
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
import ex_gate as EG
ROOT = Path(__file__).resolve().parents[3]
DEBUG_START = ROOT / 'backports/striderex/lua/arcade_debug_start.lua'
SLASH_FROM, SLASH_TO = (3000, 3600)
LUA = "\nlocal m=manager.machine\nlocal sp=m.devices[':maincpu'].spaces['program']\nlocal zp=m.devices[':audiocpu'].spaces['program']\nlocal out=os.getenv('OUT')\nlocal lg=assert(io.open(out..'/sound.tsv','w'))\nlocal f=0\n_G.slash_t1=sp:install_write_tap(0x800180,0x800181,'snd',function(off,data,mask)\n if (data&0xff)~=0xff then lg:write(string.format('%d\\tcmd\\t%02x\\n',f,data&0xff)) end end)\n_G.slash_t2=zp:install_write_tap(0xf002,0xf002,'oki',function(off,data,mask)\n lg:write(string.format('%d\\toki\\t%02x\\n',f,data&0xff)) end)\nemu.register_frame_done(function() f=f+1 if f==tonumber(os.getenv('END')) then lg:close() end end)\ndofile(os.getenv('DEBUG_START'))\n"

def run(binary, rompath, set_name, out, frames):
    out.mkdir(parents=True)
    (out / 'gate.lua').write_text(LUA)
    env = dict(os.environ, SDL_VIDEODRIVER='dummy', SDL_AUDIODRIVER='dummy', OUT=str(out), END=str(frames), DEBUG_START=str(DEBUG_START), STREX_STAGE='1', STREX_AREA='0', STREX_END=str(frames + 2), STREX_PREFIX=str(out / 'dbg'), STREX_INPUTS=f'{SLASH_FROM}-{SLASH_TO}@40/6:P1_BUTTON1')
    p = subprocess.run([str(binary), set_name, '-rompath', str(rompath), '-nothrottle', '-video', 'none', '-sound', 'none', '-seconds_to_run', str(frames // 50 + 30), '-skip_gameinfo', '-noautosave', '-cfg_directory', str(out / 'cfg'), '-nvram_directory', str(out / 'nv'), '-autoboot_script', str(out / 'gate.lua')], env=env, cwd=out, capture_output=True, text=True, timeout=1200)
    (out / 'mame.log').write_text(p.stdout + p.stderr)
    if p.returncode:
        sys.exit(f'{out}: HBMAME exit {p.returncode}')
    return [(int(f), k, int(v, 16)) for f, k, v in (l.split('\t') for l in (out / 'sound.tsv').read_text().splitlines())]

def pairs(events):
    """Per slash (0x3B): whether 0x81 follows within 2 frames, and whether the OKI start"""
    cmds = [(f, v) for f, k, v in events if k == 'cmd' and f >= SLASH_FROM]
    okis = [(f, v) for f, k, v in events if k == 'oki']
    out = []
    for f, v in cmds:
        if v != 59:
            continue
        voice = next((g for g, w in cmds if w == 129 and f <= g <= f + 2), None)
        started = voice is not None and any(([w for g, w in okis if voice <= g <= voice + 2][i:i + 3] == [8, 129, 16] for i in range(3)))
        out.append(dict(frame=f, voice=voice is not None, oki=started))
    return out

def gate(a):
    work = a.workdir.resolve()
    work.mkdir(parents=True, exist_ok=False)
    binary = json.loads((a.runtime / 'runtime.json').read_text())['binary']
    import title_ex as TX
    stock = TX.stage_stock(a, work)
    report, frames = ({}, SLASH_TO + 60)
    for set_name in ('striderus01', 'striderjs01'):
        parent = EG.PARENT[set_name]
        src = work / f'ex_{set_name}'
        (src / parent).mkdir(parents=True)
        for q in (a.build / parent).iterdir():
            (src / parent / q.name).write_bytes(q.read_bytes())
        sets = work / f'set_{set_name}'
        subprocess.run([sys.executable, str(EG.HBSET), 'build', '--hbmame', str(a.hbmame), '--rom-dir', str(a.rom_dir.resolve()), '--ex-dir', str(src), '--set', set_name, '--date', '2026-10-10', '--out', str(sets)], check=True, stdout=subprocess.DEVNULL)
        report[set_name] = pairs(run(binary, sets, set_name, work / f'run_{set_name}', frames))
    for name in ('striderua', 'striderjr'):
        report[name] = pairs(run(binary, stock, name, work / f'run_{name}', frames))

    def all_voiced(rows):
        return len(rows) >= 5 and all((r['voice'] and r['oki'] for r in rows))
    summary = {k: dict(slashes=len(v), voiced=sum((r['voice'] for r in v)), oki_starts=sum((r['oki'] for r in v))) for k, v in report.items()}
    ok = all_voiced(report['striderus01']) and all_voiced(report['striderjr']) and all_voiced(report['striderjs01']) and (not all_voiced(report['striderua'])) and (summary['striderua']['voiced'] == 0)
    (work / 'report.json').write_text(json.dumps(dict(summary=summary, slashes=report, passed=ok), indent=1) + '\n')
    print(json.dumps(summary))
    print('PASS' if ok else 'FAIL')
    return 0 if ok else 1

def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('command', choices=['gate'])
    p.add_argument('--build', type=Path, required=True)
    p.add_argument('--runtime', type=Path, required=True)
    p.add_argument('--hbmame', type=Path, required=True)
    p.add_argument('--rom-dir', type=Path, required=True)
    p.add_argument('--workdir', type=Path, required=True)
    a = p.parse_args()
    return gate(a)
if __name__ == '__main__':
    sys.exit(main())
