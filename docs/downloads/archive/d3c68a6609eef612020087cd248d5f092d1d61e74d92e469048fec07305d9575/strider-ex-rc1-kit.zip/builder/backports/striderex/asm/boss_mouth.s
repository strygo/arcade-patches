; English uses the envelope of its actual pack/native recording. Japanese
; follows the original scene's sequence byte for byte. Same saved registers
; and result as bs_picture; page and sound timing stay unchanged.
        org $1FF500
        movem.l d0-d2/d5/a0,-(sp)
        move.w  $2E(a2),d5
        sub.w   #19,d0
        bmi.s   .out
        move.w  $FFF9E0,d1
        sub.w   #$C0,d1
        cmp.w   #7,d1
        bhi.s   .japanese
        lsl.w   #2,d1
        btst    #0,$1FFFFF
        beq.s   .native
        add.w   #32,d1
.native:
        lea     $1B8000,a0
        movea.l 0(a0,d1.w),a0
        bra.s   .loop
.japanese:
        movea.l $30(a2),a0
.loop:
        move.w  (a0)+,d1
        beq.s   .out
        move.w  (a0)+,d2
        cmp.w   d1,d0
        bcs.s   .hit
        sub.w   d1,d0
        bra.s   .loop
.hit:
        move.w  d2,d5
.out:
        move.w  d5,$FFF9D8
        movem.l (sp)+,d0-d2/d5/a0
        rts
