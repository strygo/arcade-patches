"""Check an Earth follow-up bundle and reject damaged qualification controls."""
import argparse
from copy import deepcopy
import json
from pathlib import Path
import sys
import cinematic_followup as CF
Q = Path(__file__).resolve().parents[1] / 'manifests/qualification'

def main():
    if sys.argv[1:] == ['--self-test']:
        return CF.self_test()
    p = argparse.ArgumentParser(description=__doc__)
    for name in ('proof', 'earth-runtime', 'earth-render', 'receipt'):
        p.add_argument('--' + name, type=Path, required=True)
    p.add_argument('--native-runtime', type=Path, default=Q / 'kit_t_runtime.json')
    p.add_argument('--tile-runtime', type=Path)
    p.add_argument('--tile-render', type=Path)
    a = p.parse_args()
    paths = dict(proof=a.proof, runtime=a.native_runtime, census=Q / 'kit_r_census.json', loop=Q / 'kit_r_measure.json', earth_runtime=a.earth_runtime, earth_render=a.earth_render)
    if a.tile_runtime or a.tile_render:
        if not (a.tile_runtime and a.tile_render):
            p.error('both tile receipts required')
        paths.update(tile_runtime=a.tile_runtime, tile_render=a.tile_render)
    bundle = {k: json.loads(path.read_text()) for k, path in paths.items()}
    quals = {k: json.loads((Q / ('kit_p_' + k + '.json')).read_text()) for k in ('fixes', 'audio', 'combined')}
    rtl = json.loads((Q / 'kit_p_rtl.json').read_text())
    CF.validate_qualification(bundle, quals, rtl, bundle['proof']['build_files'])
    rejected = []
    mutations = ['missing', 'pictures', 'color', 'source', 'vram']
    if 'tile_runtime' in bundle:
        mutations += ['tile_missing', 'tile_pixels', 'tile_source', 'tile_vram', 'tile_negative', 'tile_model']
    for mutation in mutations:
        bad = deepcopy(bundle)
        if mutation == 'missing':
            bad['earth_runtime']['results'].pop()
        elif mutation == 'pictures':
            bad['earth_runtime']['results'][0]['pictures'][0]['identical'] = False
        elif mutation == 'color':
            bad['earth_render']['results'][0]['new_rgb'] = [[1, 1, 1]]
        elif mutation == 'source':
            bad['earth_render']['results'][0]['build']['build_files'] = {}
        elif mutation == 'vram':
            bad['earth_render']['results'][0]['build']['vram_sha256'] = '0' * 64
        elif mutation == 'tile_missing':
            bad['tile_runtime']['results'].pop()
        elif mutation == 'tile_pixels':
            bad['tile_runtime']['results'][0]['pictures'][0]['changed_pixels'] = 60
        elif mutation == 'tile_source':
            bad['tile_render']['results'][0]['build']['build_files'] = {}
        elif mutation == 'tile_vram':
            bad['tile_render']['results'][0]['build']['vram_sha256'] = '0' * 64
        elif mutation == 'tile_negative':
            bad['tile_render']['results'][0]['old_gap_rejected'] = False
        elif mutation == 'tile_model':
            bad['tile_render']['results'][0]['build']['model_sha256'] = '0' * 64
        try:
            CF.validate_qualification(bad, quals, rtl, bad['proof']['build_files'])
        except ValueError:
            rejected.append(mutation)
        else:
            raise ValueError('damaged qualification accepted: ' + mutation)
    receipt = dict(schema='striderex-earth-receipt-gate/1', passed=True, rejected_controls=rejected, inputs={k: CF.sha(path.read_bytes()) for k, path in paths.items()}, script_sha256=CF.sha(Path(__file__).read_bytes()))
    a.receipt.write_text(json.dumps(receipt, indent=2) + '\n')
    print('PASS: complete', bundle['proof']['schema'], 'bundle;', len(rejected), 'damaged controls rejected')
if __name__ == '__main__':
    main()
