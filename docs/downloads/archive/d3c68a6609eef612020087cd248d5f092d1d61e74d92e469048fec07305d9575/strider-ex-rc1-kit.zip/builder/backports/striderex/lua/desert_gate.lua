-- Strider EX desert gate (scripts/desert_gate.py): per-frame record of what the game
-- shows and sends, for frame-by-frame comparison between builds, plus screenshots.
--
-- Environment:
--   OUT          output directory
--   END          last frame (the run exits there)
--   SHOTS        "a-b@n" screenshot every n frames from a to b (optional)
--   GSHOTS       n: a screenshot g_<g>.png each n game frames (frames that end with no EX cinematic
--                state in 0xFFF914: the game's own frames, numbered from 1)
--   DSWC_SW2     1: the Freeze switch (DSWC bit 2) on (the stock pause; no gate uses it)
--   NEWGAME      1: coin at 200 and START at 400 (no debug start)
--   INPUTS       "a-b:TOKEN;a-b@period/duty:TOKEN;..." held inputs (NEWGAME runs; the debug start
--                takes STREX_INPUTS itself)
--   CLEAR_AT     research control, "frame,frame,...": for each, the first frame from it with
--                the game in play (mode word 0xFF0C12 = 4) gets mode 6, the mode a boss's
--                fall sets (the stage clear); a RAM write at a frame boundary, no emulated cycles
--   CLEAR_PLAY   research control, "n" or "n*k": the same clear each time the game has been in
--                play for n frames running (at most k times)
--   WARP         research control, "frame:x,y;...": at each frame (in play) Hiryu's position
--                (0xFF10D2/D6, world X and up-Y) is written, as if he had walked there; the
--                camera follows him at its own pace
--   WARP_AT      research control, "xt:x,y[,n];...": each once, at the first frame in play with
--                Hiryu's X at or past xt, the same write as WARP, repeated on n frames (default
--                1) so the camera can catch up before he is let go (the game ends a life when
--                he gets too far off its screen); in order: the next entry waits for the hold
--                to end and for its own xt
--   POKEW        research control, "frame:addr=word;..." (hex address and word): the word written at the
--                end of that frame (a RAM write at a frame boundary, no emulated cycles); logged as a
--                '#\tpoke' line in frames.tsv
--   HITS         research control, "kind,facing,n[,hits];...": a desert actor (pool 5 type 3) of that
--                kind and facing byte (+6, +16) gets its hit count (+1E) set to hits (default 1: what a
--                slash adds) n frames after it first appears in its slot; logged as a '#\thit' line in
--                frames.tsv
--   HIRYU        1: hiryu.tsv, Hiryu's object (0xFF10CA) at the end of each frame: X, Y (+8,
--                +C; his foot is 32 px below Y: floor probe 0x74B44), state and sub-state (+3,
--                +4: 0 on the ground; 0x0C airborne, sub 0x0C after a floor that ended (0x10ECC),
--                sub 8 after a launch off a crest (0x11A04)), the floor kind (+22), the speed
--                (+38, 8.8 px/frame) and the facing (+30)
--   CLIMB        1: up is held while Hiryu clings to a wall (state 4), as a player climbs one
--                he walked into; released otherwise (up held on a steep slope stops him)
--   STREX_DEBUG_START  arcade_debug_start.lua (its STREX_* variables apply)
--   ACTORS       1: actors.tsv, the desert actors (asm/desert_actors.s); also every word the sound queue
--                takes ('#\tsnd', its frame and value) and, on each drone line, its animation ($41) and
--                the stock animation step's counter and records ($11, $12, $14); per frame the counters
--                (spawned, killed, hurt, fired, cuts at 0xFFFA8E/8C/90/92/94), pool 5's free count
--                (0xFF69DE) and active records, the score (0xFF0CB6, BCD), Hiryu's damage count
--                (0xFF0CF6) and invulnerability (0xFF0CF4); step 2's counters (bazooka soldiers
--                started and killed, rockets, mines started, warnings, blasts at 0xFFFAA0-AA), the
--                per-kind hurt and cut bytes (0xFFFBC0, 0xFFFBE0: 32 each, hex; at 0xFFFB00 and 0xFFFB18,
--                24 each, before step 8), step 3's counters
--                (0xFFFAC0-CC: the rank timer, drones started, killed and spawned by the wave
--                managers, capsules spawned and refused, items the rank took), pool 7's free count
--                (0xFF69E2), Hiryu's health bars (max 0xFF0CCF, the five bars 0xFF0CE6, hex), the
--                cypher's count (0xFF0CE2) and the lives (0xFF0CA8); an event line per desert actor
--                (pool 5 type 3) that appears or goes: slot, kind, facing, once id, X, Y; a line per
--                drone (kind 8) per frame: slot, state, sub-state, tick bit, heading, speed, timer, X
--                and Y (16.16, hex), the capsule link (+48); a line per sandworm arch (kind 11) per frame:
--                slot, state, sub-state, its two timers (+3C, +3E), the chain tried (+43), hits (+1E), the
--                arch it made and the one that made it (+48, +4C); step 4's counters (0xFFFACE, D8, DA,
--                DC, DE: arches made, surfaced, killed, chains stopped off screen and by the floor); a line
--                per step 5 actor (kinds 12-16: the robot, its legs, its beam and segment, the valve flame)
--                per frame: slot, state, sub-state, its timers (+3C, +3E), X and Y (16.16, hex), hits (+1E),
--                collision bits (+40), animation (+41), bytes +42-+47 (hex), the links +48 and +4C, the
--                robot's PC Engine X and Y (+2A, +2E: 8.8, hex) and speed (+32), the frame record (+12) and
--                flags (+7), the word +32 (the jeep's X velocity) and the velocities +34, +38 (16.16, hex); the
--                same line for the jeep and its gunner (kinds 17, 18) and every bullet (kind 1); step 5's
--                counters (0xFFFB30-3E: robots started, killed, turned, beams fired, segments, legs, flames
--                started, bursts); step 6's (0xFFFB40-4E: jeeps started, killed, ended, bounces, turns, gunners
--                made, gunner bullets, explosions) and pool 6's free count (0xFF69E0); step 7's work RAM
--                (0xFFFB80-AB, hex: its counters, the pan, the delay, the pit), the palettes PALS names, the
--                portrait's state word (0xFFF940, PT_ON), Hiryu's X (16.16, hex), Y and state (0xFF10CD); the a5 line
--                for the officer, its projectiles and the sand-pull (kinds 19-23) too; step 8's work RAM (0xFFFB00-2F,
--                hex: its counters, the hull's place, the ride, the parts), the SCROLL2 layer object's X and Y
--                (0xFF0FB4/B8) and its scroll shadow (0xFF0C34/36), Hiryu's platform bits and kind (0xFF111D, 0xFF111E,
--                hex) and his frame's first floor kind and his floor kind (+31, +22); the a5 line for the commander, the
--                tank, its parts, its shells and the strip (kinds 24-28) too; and a line per stock
--                capsule (pool 7 type 0x1A) when it appears, changes its state, sub-state or kind, or goes: slot, variant (+6), kind
--                (+3C), state (+2), sub-state (+3), X, Y, carrier (+38)
--   S1SKIP       research control, "a:n": on the first frame the desert's section machine (0xFFF932/34) is in
--                section 1 at its step a or later, its step word is set to n (asm/desert.s dz_sections; a
--                desert_ex.S1_SKIP_FROM, the settle before the portrait, n S1_AFTER_OFFICER, the steps after the officer's:
--                its portrait, its fight and the pit's opening are left out, the officer and the sand-pull stay
--                harmless in their wait for the go); logged as a '#\tskip' line
--   S4SKIP       research control, "a:n": the same in section 4 (desert_ex.S4_FIGHT_FROM, the settle before its portrait,
--                and S4_AFTER_TANK, its delay after the wait on the tank: no portrait and no go, the commander and the
--                tank stay harmless in their wait, the section clears after its delay); logged as a '#\tskip' line
--   PALS         "addr,addr,...": the palettes (32 bytes each, hex) the ACTORS rows log
--   PIT          "offset,offset,...": pit.tsv, on each change, these offsets' entries (hex longs) in the display
--                map (0x918000) and the collision map (0x910000)
--   CAPTION      "slot:lo-hi,lo-hi,...": caption.tsv, the location caption (a system object of kind 2,
--                0xDAEA: 20 records of 0x40 bytes at 0xFF5EDA, the kind at +17) on each frame: the
--                kind-2 objects (index, state +2, sub-state +3, parameter +6, X +8, Y +C, fade level
--                +32, update count +30, record +1A, palette pointer +1E), the sprite list at the last
--                OBJ base write
--                (the list the board copies: 256 entries of x, y, code, attribute), its entries
--                of palette `slot` whose code is in the ranges (count, bounding box of their x and
--                y, the codes in list order), every entry anywhere in that list with a code in the
--                ranges (any palette: a stale caption sprite would be one), the list's end marks
--                (attribute 0xFF00), those that are not full end entries (x, y and code 0, attribute
--                0xFF00: scene_core.s end_a3), blank fills (x = y = 0, code 0x888, attribute 0: the
--                stock sprite frame's fill, 0x6F890), and the slot's 16 palette words in graphics RAM
--                (0x914000 + 32 * slot), whose top nibble the fade sets
--   FADE         n: fade.tsv, the scene's fade-in (desert_gate.py caption): on each frame the layer-control
--                register as last written (CPS-B 0x800166), the brightness nibble most colors of the
--                SCROLL1, SCROLL2 and SCROLL3 palette pages (0x914400-0x914FFF, the colors that are not 0)
--                have, whether every such color has it, and the backdrop pen (0x9157FE); and a screenshot
--                s_<frame>.png on each of the n frames from the first with a system object of kind 2
--                (a location caption)
--   READY        "addr,addr,...;lo-hi,lo-hi,...": ready.tsv (scripts/ready_gate.py), on each frame: the
--                SCROLL1 base and scroll registers as last written (CPS-A 0x800102, 0x80010C, 0x80010E), the
--                sprite-text flag 0xFF0CCC (set: the kind-0 texts draw as sprites, not SCROLL1) and the
--                player-2 flag 0xFF0C82, the system objects of kind 0 (index: parameter +6, state +2,
--                sub-states +3 and +4, timers +32 and +33) and of kinds 2 and 3 (the location captions and
--                St. Petersburg's card: index: kind, parameter, state, X, Y, record +1A), the code word
--                at each graphics RAM address listed (the text cells the READY and GO records draw),
--                and every entry of the sprite list at the last OBJ base write, up to its end mark,
--                whose code is in the ranges (x, y, code, attribute; any palette); then the colors: for
--                each kind-2 object with a record, its fade level +32 and the 16 words of its record's
--                palette slot (the record's attribute word +6, slot = attribute & 0x1F, at 0x914000 +
--                32 slot), and READY's two palettes (SCROLL1 palette 0x1E at 0x9147C0, OBJ palette 0 at
--                0x914000; 16 words each)
--   READY_SHOTS  1 (with READY): a screenshot s_<frame>.png on every frame with a READY or GO object (kind 0,
--                parameter 9-11) or a location caption (kind 2), and on the 4 frames after
--   RAM          n: work RAM (0xFF0000-0xFFFFFF) every n frames, appended to ram.bin (64 KiB each), the
--                frames in ram.idx
--   NEWGAME=2    a two-player game: coins at 200 and 240, START2 at 400 (instead of one coin and START1)
--   MOTION       n: motion.tsv (desert_gate.py smooth), on each frame: Hiryu's object (0xFF10CA: X and its
--                fraction +8/+A, Y up and its fraction +C/+E, state +3, sub-state +4, the floor kind +22 and
--                the frame's first kind +31, the speed +38, the facing +30), the camera (the SCROLL3 layer
--                object 0xFF0FEC: X, fraction, Y, fraction at +8..+E) and the SCROLL3 scroll shadow the
--                layer code leaves (0xFF0C3C/3E); the CPS-A SCROLL2 and SCROLL3 scroll registers as last
--                written (0x800110-0x800116), how many SCROLL3 scroll writes the frame had and the raster
--                line of its last one and of its last OBJ base write; the game task's state byte (0xFF0030)
--                at the frame's end and the raster line of its last write of 1 (asleep: the frame's work
--                done) and of 8 (woken); the camera's follow box (0xFF101E-24, hex: Hiryu's screen X past
--                which it scrolls right, left, his height above it up, down) and limits (0xFF1016-1C: X
--                max, X min, Y max, Y min). Lines count from the top of the frame (0-261; MAME's VBlank, the
--                frame's end, at 240). With n > 1, the first n entries of the sprite list at the last OBJ
--                base write (x, y, code, attribute; to the end mark) too
--   INTRO        1: intro.tsv (scripts/intro_gate.py), on each frame: the intro task's state and sub-state
--                (0xFF0CDC/DD), the counter of the stock intro setup's picture (0xFFA00A: the wizard rising, 0x552C,
--                set to 0xF0 after its 36 frames of setup and counted down to 0), the layer-control shadow
--                (0xFF0C74) and the register as last written, the SCROLL2 Y shadow (0xFF0C36), the frame counter
--                (0xFF0C22, the VBlank's) and the random byte (0xFF0CB3, 0x486C), the intro's level word (0xFF0C1A),
--                the system objects of kind 2 (the location captions), of kind 5 (the dialogue's dark strips,
--                0xDF08) and of kind 0 with parameter 9-11 (READY, GO), the reads of the dialogue's records in the
--                frame (DIALOGUE="lo-hi": the stock intros' panel, portrait and text record data, which only
--                the dialogue's writers read; intro_gate.DIALOGUE), the star scroll registers as last
--                written (CPS-A 0x800118-0x80011E), a checksum of the star palettes (0x915000-0x9157FF) and the
--                sprite lists' double-buffer flag and OBJ base shadow (0xFF0C98, 0xFF0C9A; SEED)
--   ISHOTS       n: a screenshot i_<frame>.png on each of the n frames from each hand-back (the first frame with
--                no EX cinematic state after one with it); ISHOTS_AT=frame starts such a window there too (the
--                stock runs, which have no cinematic)
--   TSHOTS       n: a screenshot t_<frame>.png on each frame with an EX cinematic state, which also removes
--                t_<frame - n>.png: at each hand-back, the last n frames before it stay on disk (intro_gate.py
--                hand_back: the scene's last picture and what follows it)
--   PSHOTS       n: a screenshot p_<stage>_<k>.png on each n-th frame of a stage's play (game mode 4), k counting
--                that stage's play frames from 1 (its first)
--   SEED         research control, "stage:counter,random,flag,base;...": at the end of the first frame in play
--                (mode 4) of each stage listed, the frame counter (0xFF0C22), the random byte (0xFF0CB3) and the
--                sprite lists' double-buffer phase (the flag 0xFF0C98 the sprite frame toggles, 0x51BC, and the OBJ
--                base shadow 0xFF0C9A the VBlank writes) are written, so play can be compared from its first frame
--                between builds whose intros differ in length (RAM writes at a frame boundary, no emulated cycles)
--   LAYER_AND    hex mask: every layer-control register write (CPS-B 0x800166) is ANDed with it on its way to the
--                video (the game's shadow is untouched); the gates drop the star layers, whose colors MAME cycles
--                with its own frame number
--   INPUTS_ONLY  1: INPUTS are applied without the debug start and without NEWGAME's coin and START (the stage
--                select's code: the coin, attack and jump held across START, then the stick and the pick)
--   VIDEO_DUMPS "frame,...": full VRAM snapshots and regs.tsv for earth_render_probe.py.
--   REGLOG       "a-b": reglog.tsv, every CPS-A/B register write of frames a-b (frame, address, data), the writes
--                frames.tsv's register CRC covers (a debugging aid: which write two runs differ in)
--   TRACE        "file:from-to" (desert_gate.py cycles; MAME run with -debug -debugger none): the debugger's
--                instruction trace of the main CPU into file, from the end of frame `from` to the end of frame
--                `to` (noloop: every instruction; each interrupt as "(interrupted at <pc>, IRQ n)")
-- Output: frames.tsv (frame, a CRC of the CPS-A/B register writes of the frame in order,
-- their count, the sound latch writes, stage, area, mode, player X/Y, camera X/Y, the
-- SCROLL3 base register as last written, lives, OBJ base writes, the game task's state byte
-- at the frame's end (task slot 0x30, 0xFF0030: 1 asleep, its frame's work done; 8 still
-- running at the vertical blank, a lag frame), the EX cinematic state word (0xFFF914, ACTIVE in
-- asm/ex_bank.s) and its stream pointer (0xFFF904, LZ_SRC), the layer-control word
-- (0xFF0C74: 0 once a death blacks the screen out, the word asm/desert.s dz_watch keys on)),
-- s_<frame>.png.
local m=manager.machine
local cpu=m.devices[':maincpu']
local sp=cpu.spaces['program']
local screen=m.screen or m.screens[':screen']
local out=assert(os.getenv('OUT'))
local last=tonumber(os.getenv('END') or '3000')
local clears={}
for s in string.gmatch(os.getenv('CLEAR_AT') or '','%d+') do clears[#clears+1]=tonumber(s) end
local sa,sb,sn=string.match(os.getenv('SHOTS') or '','(%d+)-(%d+)@(%d+)')
sa,sb,sn=tonumber(sa),tonumber(sb),tonumber(sn)
local f=0
local cpu_log=os.getenv('CPU_TRACE')=='1' and assert(io.open(out..'/cpu.tsv','w')) or nil
-- Bounded contact diagnosis: arguments at the native floor/ceiling/wall
-- probes and the instruction that changes Hiryu's movement state.
local contact_a,contact_b=string.match(os.getenv('CONTACT_TRACE') or '','^(%d+)-(%d+)$')
contact_a,contact_b=tonumber(contact_a),tonumber(contact_b)
if contact_a then
 local cf=assert(io.open(out..'/contacts.tsv','w'))
 cf:write('frame\taddress\tpc\tx\ty\tstate\tshape\td0\td1\td2\n')
 local taps={}
 local function contact(a)
  if f>=contact_a and f<=contact_b and cpu.state['A0'].value&0xffffff==0xff10ca then
   cf:write(string.format('%d\t%x\t%x\t%d\t%d\t%d\t%d\t%x\t%x\t%x\n',f,a,cpu.state['CURPC'].value,
    sp:read_u16(0xff10d2),sp:read_u16(0xff10d6),sp:read_u8(0xff10cd),sp:read_u8(0xff10db),
    cpu.state['D0'].value,cpu.state['D1'].value,cpu.state['D2'].value));cf:flush()
  end
 end
 for _,a in ipairs({0x18ca,0x1a3e,0x1e54,0x1f9c}) do
  taps[#taps+1]=sp:install_read_tap(a,a+1,'contact_'..a,function(o,d,mk) contact(o) end)
 end
 taps[#taps+1]=sp:install_write_tap(0xff10cc,0xff10cd,'contact_state',function(o,d,mk) contact(o) end)
 _G.dg_contacts=taps
end
local video_frames={}
for n in string.gmatch(os.getenv('VIDEO_DUMPS') or '','%d+') do video_frames[tonumber(n)]=true end
local video_log
if next(video_frames) then
  video_log=assert(io.open(out..'/regs.tsv','w'))
  _G.dg_video=sp:install_write_tap(0x800100,0x80017f,'dg_video',function(offset,data,mask)
    video_log:write(string.format('W\t%d\t0\t%x\t%x\t%x\n',f+1,offset,data,mask))
  end)
end
local g,gsn=0,tonumber(os.getenv('GSHOTS') or '')
local crc,nw,snd,s3base,objw=0,0,{},0,0
local layer_reg=0
local objbase=0
local s1base,s1x,s1y=0,0,0
local log=assert(io.open(out..'/frames.tsv','w'))
log:write('frame\tregs_crc\tregs_n\tsound\tstage\tarea\tmode\tplx\tply\tcamx\tcamy\ts3base\tlives\tobjw\tgtask\tactive\tlz\t'..
  'layer\n')
local function mix(v) crc=(crc*31+v)&0xffffffff end
local motion_n=tonumber(os.getenv('MOTION') or '')
-- Optional post-build sprite instrumentation. The write boundaries belong
-- to the desert-only drawing helper; this does not change emulated state.
local cadence_log,cadence_before
if os.getenv('CADENCE')=='1' then
  cadence_log=assert(io.open(out..'/cadence.tsv','w'))
  cadence_log:write('frame\tstart_frame\tlatched_buffer\tstamp\tcount\tbuffer\tdy\tedits\tx\txf\ty\tkind\tobject_before\tobject_after\tbefore\tafter\n')
  cadence_before={}
  local function object_hex()
    local r={}
    for a=0xff10ca,0xff1128,2 do r[#r+1]=string.format('%04x',sp:read_u16(a)) end
    return table.concat(r)
  end
  local function sprite_text(base)
    local r={}
    for i=0,255 do
      local a=base+8*i
      local at=sp:read_u16(a+6)
      if at&0xff00==0xff00 then break end
      r[#r+1]=string.format('%d,%d,%x,%x',sp:read_u16(a),sp:read_u16(a+2),sp:read_u16(a+4),at)
    end
    return table.concat(r,';')
  end
  _G.cadence_start=sp:install_write_tap(0xfff9ee,0xfff9ef,'cadence_start',function(o,d,mk)
    local buf=d&0xffff
    if buf==0x9000 or buf==0x9040 then
      cadence_before[buf]={sprites=sprite_text(buf<<8),object=object_hex(),frame=f,latched=objbase}
    end
  end)
  _G.cadence_end=sp:install_write_tap(0xfff9f0,0xfff9f1,'cadence_end',function(o,d,mk)
    local buf=sp:read_u16(0xfff9ee)
    local before=cadence_before[buf]
    if before then
      cadence_log:write(string.format('%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%s\t%s\t%s\t%s\n',
        f,before.frame,before.latched,sp:read_u16(0xfff9f4),d&0xffff,buf,sp:read_i16(0xfff9ec),sp:read_u16(0xfff9f6),
        sp:read_i16(0xfff9fa),sp:read_u16(0xfff9fc),sp:read_i16(0xfff9f8),sp:read_u16(0xfff9fe),
        before.object,object_hex(),before.sprites,sprite_text(buf<<8)))
    end
  end)
end
local LINES=math.floor(screen.frame_period/screen.scan_period+0.5)
local function beam()                   -- the raster line now (0 = the frame's top)
  return math.floor((LINES-screen:time_until_pos(0,0)/screen.scan_period)%LINES)
end
local mo={s2x=0,s2y=0,s3x=0,s3y=0,s3n=0,s3line=-1,objline=-1,sleep=-1,wake=-1}
local reglog,rla,rlb=nil,string.match(os.getenv('REGLOG') or '','^(%d+)-(%d+)$')
rla,rlb=tonumber(rla),tonumber(rlb)
if rla then reglog=assert(io.open(out..'/reglog.tsv','w')) end
_G.dg_regs=sp:install_write_tap(0x800100,0x80017f,'dg_regs',function(o,d,mk)
  mix(o&0xff) mix(d&0xffff) nw=nw+1
  if reglog and f+1>=rla and f+1<=rlb then reglog:write(string.format('%d\t%06x\t%04x\n',f+1,o,d&0xffff)) end
  if o==0x800106 then s3base=d&0xffff end
  if motion_n then
    if o==0x800110 then mo.s2x=d&0xffff elseif o==0x800112 then mo.s2y=d&0xffff
    elseif o==0x800114 or o==0x800116 then
      if o==0x800114 then mo.s3x=d&0xffff else mo.s3y=d&0xffff end
      mo.s3n=mo.s3n+1 mo.s3line=beam()
    elseif o==0x800100 then mo.objline=beam() end
  end
  if o==0x800100 then objw=objw+1 objbase=d&0xffff end
  if o==0x800166 then layer_reg=d&0xffff end
  if o==0x800102 then s1base=d&0xffff end
  if o==0x80010c then s1x=d&0xffff end
  if o==0x80010e then s1y=d&0xffff end
end)
local mlog=nil
if motion_n then
  mlog=assert(io.open(out..'/motion.tsv','w'))
  mlog:write('frame\thx\thxf\thy\thyf\tst\tsub\tkind\tkind0\tspeed\tface\tcamx\tcamxf\tcamy\tcamyf\tsh3x\tsh3y\t'..
    's2x\ts2y\ts3x\ts3y\ts3n\ts3line\tobjline\tgtask\tsleep\twake\tfollow\tlimits'..(motion_n>1 and '\tsprites' or '')..'\n')
  _G.dg_task=sp:install_write_tap(0xff0030,0xff0031,'dg_task',function(o,d,mk)
    local v=nil
    if o==0xff0030 and mk&0xff00~=0 then v=(d>>8)&0xff elseif o==0xff0030 and mk==0xff then v=d&0xff end
    if v==1 then mo.sleep=beam() elseif v==8 then mo.wake=beam() end
  end)
end
local function motion()
  local spr=''
  if motion_n>1 then
    local base,e=(objbase&0xffff)<<8,{}
    for i=0,motion_n-1 do
      local a=base+8*i
      local at=sp:read_u16(a+6)
      if at&0xff00==0xff00 then break end
      e[#e+1]=string.format('%d,%d,%x,%x',sp:read_u16(a),sp:read_u16(a+2),sp:read_u16(a+4),at)
    end
    spr='\t'..table.concat(e,';')
  end
  mlog:write(string.format('%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t'..
    '%d\t%d\t%d\t%x,%x,%x,%x\t%d,%d,%d,%d%s\n',f,sp:read_i16(0xff10d2),sp:read_u16(0xff10d4),sp:read_i16(0xff10d6),sp:read_u16(0xff10d8),
    sp:read_u8(0xff10cd),sp:read_u8(0xff10ce),sp:read_u8(0xff10ec),sp:read_u8(0xff10fb),sp:read_i16(0xff1102),
    sp:read_u8(0xff10fa),sp:read_i16(0xff0ff4),sp:read_u16(0xff0ff6),sp:read_i16(0xff0ff8),sp:read_u16(0xff0ffa),
    sp:read_i16(0xff0c3c),sp:read_i16(0xff0c3e),mo.s2x,mo.s2y,mo.s3x,mo.s3y,mo.s3n,mo.s3line,mo.objline,
    sp:read_u8(0xff0030),mo.sleep,mo.wake,sp:read_u16(0xff101e),sp:read_u16(0xff1020),sp:read_u16(0xff1022),
    sp:read_u16(0xff1024),sp:read_i16(0xff1016),sp:read_i16(0xff1018),sp:read_i16(0xff101a),sp:read_i16(0xff101c),spr))
  mo.s3n,mo.s3line,mo.objline,mo.sleep,mo.wake=0,-1,-1,-1,-1
end
_G.dg_snd=sp:install_write_tap(0x800180,0x800181,'dg_snd',function(o,d,mk)
  snd[#snd+1]=string.format('%02x',d&0xff)
end)
local fields={}
for _,port in pairs(m.ioport.ports) do for name,field in pairs(port.fields) do
  fields[m.ioport:input_type_to_token(field.type,field.player)]=field end end
if os.getenv('DSWC_SW2')=='1' then
  for _,field in pairs(m.ioport.ports[':DSWC'].fields) do
    if field.mask&0x04~=0 then field.user_value=field.defvalue&~0x04 end   -- active low: on
  end
end
local inputs={}
for item in string.gmatch(os.getenv('INPUTS') or '','[^;]+') do
  local a,b,per,duty,tok=string.match(item,'^%s*(%d+)-(%d+)@(%d+)/(%d+):([%w_]+)%s*$')
  if not a then a,b,tok=string.match(item,'^%s*(%d+)-(%d+):([%w_]+)%s*$') end
  assert(a,'bad INPUTS item: '..item)
  inputs[#inputs+1]={a=tonumber(a),b=tonumber(b),per=tonumber(per),duty=tonumber(duty),tok=tok}
end
local newgame=os.getenv('NEWGAME')=='1' or os.getenv('NEWGAME')=='2'
local two=os.getenv('NEWGAME')=='2'
local nclear=1
local cp_n,cp_k=string.match(os.getenv('CLEAR_PLAY') or '','^(%d+)%*?(%d*)$')
cp_n,cp_k=tonumber(cp_n),tonumber(cp_k) or math.huge
local inplay=0
local warps={}
for fr,x,y in string.gmatch(os.getenv('WARP') or '','(%d+):(%-?%d+),(%-?%d+)') do
  warps[tonumber(fr)]={tonumber(x),tonumber(y)}
end
local pokes={}
for fr,a,v in string.gmatch(os.getenv('POKEW') or '','(%d+):(%x+)=(%x+)') do
  pokes[#pokes+1]={tonumber(fr),tonumber(a,16),tonumber(v,16)}
end
local hits,hitseen={},{}
for item in string.gmatch(os.getenv('HITS') or '','[^;]+') do
  local kd,fc,n,c=string.match(item,'^(%d+),(%d+),(%d+),?(%d*)$')
  assert(kd,'bad HITS item: '..item)
  hits[#hits+1]={tonumber(kd),tonumber(fc),tonumber(n),tonumber(c) or 1}
end
local warps_at,nwarp={},1
for item in string.gmatch(os.getenv('WARP_AT') or '','[^;]+') do
  local xt,x,y,n=string.match(item,'^%s*(%-?%d+):(%-?%d+),(%-?%d+),?(%d*)%s*$')
  assert(xt,'bad WARP_AT item: '..item)
  warps_at[#warps_at+1]={tonumber(xt),tonumber(x),tonumber(y),tonumber(n) or 1}
end
local hold=0
local climb=os.getenv('CLIMB')=='1'
local climb_end=tonumber(os.getenv('CLIMB_END') or '')
local hlog=nil
if os.getenv('HIRYU')=='1' then
  hlog=assert(io.open(out..'/hiryu.tsv','w'))
  hlog:write('frame\tx\ty\tst\tsub\tfloor\tspeed\tface\n')
end
local dzlog=assert(io.open(out..'/desert.tsv','w'))
dzlog:write('frame\tsec\tstep\tmap\tw0\ton\tlimits\n')
local prevdz=''
local pitlog,pitcells,prevpit=nil,{},''
for o in string.gmatch(os.getenv('PIT') or '','%x+') do pitcells[#pitcells+1]=tonumber(o,16) end
if #pitcells>0 then
  pitlog=assert(io.open(out..'/pit.tsv','w'))
  pitlog:write('frame\tcells\n')
end
local palw={}
for a in string.gmatch(os.getenv('PALS') or '','%x+') do palw[#palw+1]=tonumber(a,16) end
local s1from,s1skip=string.match(os.getenv('S1SKIP') or '','^(%d+):(%d+)$')
s1from,s1skip=tonumber(s1from),tonumber(s1skip)
local s4from,s4skip=string.match(os.getenv('S4SKIP') or '','^(%d+):(%d+)$')
s4from,s4skip=tonumber(s4from),tonumber(s4skip)
local alog,aseen=nil,{}
if os.getenv('ACTORS')=='1' then
  alog=assert(io.open(out..'/actors.tsv','w'))
  alog:write('frame\tspawned\tkilled\thurt\tfired\tcuts\tfree5\tactive5\tscore\tdamage\tinvuln\tbz_spawned\t'..
    'bz_killed\trockets\tmn_spawned\tmn_warn\tmn_blast\tkhurt\tkcut\trank_t\tdr_spawned\tdr_killed\twv_spawned\t'..
    'caps\tcapfull\tstrip\tfree7\tmaxhp\tbars\tcypher\tlives\tsw_arch\tsw_up\tsw_kill\tsw_stop\tsw_end\t'..
    'rb_spawned\trb_killed\trb_turn\tbm_fired\tbm_seg\tlg_made\tfl_spawned\tfl_burst\tjp_spawned\tjp_killed\tjp_end\t'..
    'jp_bounce\tjp_turn\tgn_made\tgn_shot\tjp_boom\tfree6\tda6\tpals\tpt_on\thx\thy\thst\tda8\ts2x\ts2y\ts2sx\t'..
    's2sy\thplat\thkind0\thkind\n')
  -- the sound queue (0x496E: -$7116(a5), 64 words): every command queued, as '#\tsnd\tframe\tvalue', the frame
  -- whose emulation queued it (the rows' numbering: f is the last frame done)
  _G.dg_sndq=sp:install_write_tap(0xff0eea,0xff0f69,'dg_sndq',function(o,d,mk)
    alog:write(string.format('#\tsnd\t%d\t%04x\n',f+1,d&0xffff))
  end)
end
local flog,fade_n,fade_from=nil,tonumber(os.getenv('FADE') or ''),nil
if fade_n then
  flog=assert(io.open(out..'/fade.tsv','w'))
  flog:write('frame\tlayer\tlv1\tlv2\tlv3\tuniform\tsky\n')
end
local function fade_page(base)
  local h,n={},0
  for i=0,511 do
    local w=sp:read_u16(base+2*i)
    if w&0x0fff~=0 then local k=w>>12 h[k]=(h[k] or 0)+1 n=n+1 end
  end
  local best,bn=-1,0
  for k,v in pairs(h) do if v>bn then best,bn=k,v end end
  return best,bn==n
end
local function fade()
  local l1,u1=fade_page(0x914400)
  local l2,u2=fade_page(0x914800)
  local l3,u3=fade_page(0x914c00)
  flog:write(string.format('%d\t%04x\t%d\t%d\t%d\t%d\t%04x\n',f,layer_reg,l1,l2,l3,(u1 and u2 and u3) and 1 or 0,
    sp:read_u16(0x9157fe)))
  if not fade_from then
    for k=0,19 do
      local o=0xff5eda+0x40*k
      if sp:read_u8(o)~=0 and sp:read_u8(o+0x17)==2 then fade_from=f break end
    end
  end
  if fade_from and f<fade_from+fade_n then screen:snapshot(string.format('%s/s_%05d.png',out,f)) end
end
local clog,cslot,cranges=nil,nil,{}
do
  local slot,ranges=string.match(os.getenv('CAPTION') or '','^(%d+):(.+)$')
  if slot then
    cslot=tonumber(slot)
    for lo,hi in string.gmatch(ranges,'(%x+)-(%x+)') do cranges[#cranges+1]={tonumber(lo,16),tonumber(hi,16)} end
    assert(#cranges>0,'bad CAPTION ranges')
    clog=assert(io.open(out..'/caption.tsv','w'))
    clog:write('frame\tobjbase\tkind2\tn\tbox\tcodes\tany\tends\tfills\tpal\tstale\n')
  end
end
local function caption_code(c)
  for _,r in ipairs(cranges) do if c>=r[1] and c<=r[2] then return true end end
  return false
end
local function caption()
  local k2={}
  for k=0,19 do
    local o=0xff5eda+0x40*k
    if sp:read_u8(o)~=0 and sp:read_u8(o+0x17)==2 then
      k2[#k2+1]=string.format('%d:%d,%d,%d,%d,%d,%d,%d,%x,%x',k,sp:read_u8(o+2),sp:read_u8(o+3),sp:read_u8(o+6),
        sp:read_i16(o+8),sp:read_i16(o+12),sp:read_u8(o+0x32),sp:read_u8(o+0x30),sp:read_u32(o+0x1a),
        sp:read_u32(o+0x1e))
    end
  end
  local base=(objbase&0xffff)<<8
  local n,any,ends,fills,stale,codes=0,0,0,0,0,{}
  local x0,y0,x1,y1=99999,99999,-99999,-99999
  for i=0,255 do
    local e=base+8*i
    local x,y,c,a=sp:read_u16(e),sp:read_u16(e+2),sp:read_u16(e+4),sp:read_u16(e+6)
    if a&0xff00==0xff00 then
      ends=ends+1
      if x~=0 or y~=0 or c~=0 or a~=0xff00 then stale=stale+1 end
    end
    if x==0 and y==0 and c==0x888 and a==0 then fills=fills+1 end
    if caption_code(c) then
      any=any+1
      if a&0x1f==cslot then
        n=n+1
        codes[#codes+1]=string.format('%x',c)
        x0,y0,x1,y1=math.min(x0,x),math.min(y0,y),math.max(x1,x),math.max(y1,y)
      end
    end
  end
  local pal={}
  for i=0,15 do pal[#pal+1]=string.format('%04x',sp:read_u16(0x914000+32*cslot+2*i)) end
  clog:write(string.format('%d\t%04x\t%s\t%d\t%s\t%s\t%d\t%d\t%d\t%s\t%d\n',f,objbase,table.concat(k2,';'),n,
    n>0 and string.format('%d,%d,%d,%d',x0,y0,x1,y1) or '',table.concat(codes,','),any,ends,fills,table.concat(pal,','),
    stale))
end
local rlog,rcells,rranges=nil,{},{}
do
  local cells,ranges=string.match(os.getenv('READY') or '','^([^;]*);(.*)$')
  if cells then
    for a in string.gmatch(cells,'%x+') do rcells[#rcells+1]=tonumber(a,16) end
    for lo,hi in string.gmatch(ranges,'(%x+)-(%x+)') do rranges[#rranges+1]={tonumber(lo,16),tonumber(hi,16)} end
    rlog=assert(io.open(out..'/ready.tsv','w'))
    rlog:write('frame\ts1base\ts1x\ts1y\tspr\tp2\tkind0\tkind2\tcells\tsprites\tkind2pal\treadypal\n')
  end
end
local rshots,rlast=os.getenv('READY_SHOTS')=='1',-99
local ram_n,ramf,rami=tonumber(os.getenv('RAM') or ''),nil,nil
if ram_n then
  ramf=assert(io.open(out..'/ram.bin','wb'))
  rami=assert(io.open(out..'/ram.idx','w'))
end
local function words16(a)
  local w={}
  for i=0,15 do w[#w+1]=string.format('%04x',sp:read_u16(a+2*i)) end
  return table.concat(w,',')
end
local function ready()
  local k0,k2,kp={},{},{}
  for k=0,19 do
    local o=0xff5eda+0x40*k
    if sp:read_u8(o)~=0 then
      local kind=sp:read_u8(o+0x17)
      if kind==0 then
        local par=sp:read_u8(o+6)
        if par>=9 and par<=11 then rlast=f end
        k0[#k0+1]=string.format('%d:%d,%d,%d,%d,%d,%d',k,par,sp:read_u8(o+2),sp:read_u8(o+3),
          sp:read_u8(o+4),sp:read_u8(o+0x32),sp:read_u8(o+0x33))
      elseif kind==2 or kind==3 then
        if kind==2 then rlast=f end
        k2[#k2+1]=string.format('%d:%d,%d,%d,%d,%d,%x',k,kind,sp:read_u8(o+6),sp:read_u8(o+2),sp:read_i16(o+8),
          sp:read_i16(o+12),sp:read_u32(o+0x1a))
        local rec=sp:read_u32(o+0x1a)
        if kind==2 and rec~=0 then
          kp[#kp+1]=string.format('%d:%d,%s',k,sp:read_u8(o+0x32),words16(0x914000+32*(sp:read_u16(rec+6)&0x1f)))
        end
      end
    end
  end
  local cw={}
  for i,a in ipairs(rcells) do cw[i]=string.format('%04x',sp:read_u16(a)) end
  local base=(objbase&0xffff)<<8
  local ents={}
  for i=0,255 do
    local e=base+8*i
    local a=sp:read_u16(e+6)
    if a&0xff00==0xff00 then break end
    local c=sp:read_u16(e+4)
    for _,r in ipairs(rranges) do
      if c>=r[1] and c<=r[2] then
        ents[#ents+1]=string.format('%d,%d,%x,%x',sp:read_u16(e),sp:read_u16(e+2),c,a)
        break
      end
    end
  end
  rlog:write(string.format('%d\t%04x\t%04x\t%04x\t%d\t%d\t%s\t%s\t%s\t%s\t%s\t%s;%s\n',f,s1base,s1x,s1y,sp:read_u8(0xff0ccc),
    sp:read_u8(0xff0c82),table.concat(k0,';'),table.concat(k2,';'),table.concat(cw,','),table.concat(ents,';'),
    table.concat(kp,';'),words16(0x9147c0),words16(0x914000)))
end
-- the stage intros (INTRO, ISHOTS, PSHOTS, SEED, LAYER_AND: scripts/intro_gate.py)
local ilog,dreads,stars=nil,0,{0,0,0,0}
if os.getenv('INTRO')=='1' then
  ilog=assert(io.open(out..'/intro.tsv','w'))
  ilog:write('frame\tstate\tsub\twizard\tlayer\tlayer_reg\ts2y\tcounter\trandom\tlevel\tkind2\tkind5\tready\tdreads\tstars\t'..
    'starpal\tobjflag\tobjbase\n')
  local dlo,dhi=string.match(os.getenv('DIALOGUE') or '','^(%x+)-(%x+)$')
  if dlo then
    _G.dg_dialogue=sp:install_read_tap(tonumber(dlo,16),tonumber(dhi,16),'dg_dialogue',function(o,d,mk)
      dreads=dreads+1 end)
  end
  _G.dg_stars=sp:install_write_tap(0x800118,0x80011f,'dg_stars',function(o,d,mk)
    stars[((o-0x800118)>>1)+1]=d&0xffff end)
end
local layer_and=tonumber(os.getenv('LAYER_AND') or '',16)
if layer_and then
  _G.dg_layer_and=sp:install_write_tap(0x800166,0x800167,'dg_layer_and',function(o,d,mk) return d&layer_and end)
end
local function intro()
  local k2,k5,rd=0,0,0
  for k=0,19 do
    local o=0xff5eda+0x40*k
    if sp:read_u8(o)~=0 then
      local kind=sp:read_u8(o+0x17)
      if kind==2 then k2=k2+1 elseif kind==5 then k5=k5+1
      elseif kind==0 then local par=sp:read_u8(o+6) if par>=9 and par<=11 then rd=rd+1 end end
    end
  end
  local sc=0                             -- the star palettes (0x915000-0x9157FF): a checksum of the 1,024 words
  for a=0x915000,0x9157fc,4 do sc=(sc*33+sp:read_u32(a))&0xffffffff end
  ilog:write(string.format('%d\t%d\t%d\t%d\t%04x\t%04x\t%04x\t%04x\t%02x\t%04x\t%d\t%d\t%d\t%d\t%04x,%04x,%04x,%04x\t%08x\t'..
    '%02x\t%04x\n',f,
    sp:read_u8(0xff0cdc),sp:read_u8(0xff0cdd),sp:read_u16(0xffa00a),sp:read_u16(0xff0c74),layer_reg,sp:read_u16(0xff0c36),
    sp:read_u16(0xff0c22),sp:read_u8(0xff0cb3),sp:read_u16(0xff0c1a),k2,k5,rd,dreads,stars[1],stars[2],stars[3],stars[4],sc,
    sp:read_u8(0xff0c98),sp:read_u16(0xff0c9a)))
  dreads=0
end
local ishots_n,ishots_until=tonumber(os.getenv('ISHOTS') or ''),-1
local ishots_at=tonumber(os.getenv('ISHOTS_AT') or '')
local tshots_n=tonumber(os.getenv('TSHOTS') or '')
local was_cine=false
local pshots_n=tonumber(os.getenv('PSHOTS') or '')
local pstage,pk=-1,0
local seeds={}
for st,c,r,fl,ba in string.gmatch(os.getenv('SEED') or '','(%d+):(%x+),(%x+),(%x+),(%x+)') do
  seeds[tonumber(st)]={tonumber(c,16),tonumber(r,16),tonumber(fl,16),tonumber(ba,16)}
end
local function intro_shots(act)
  local cine=act==0xc1e5 or act==0xc1e6 or act==0xc1e7 or act==0xc1e8
  if ishots_n then
    if (was_cine and not cine) or (ishots_at and f==ishots_at) then ishots_until=f+ishots_n-1 end
    if f<=ishots_until then screen:snapshot(string.format('%s/i_%05d.png',out,f)) end
  end
  if tshots_n and cine then
    screen:snapshot(string.format('%s/t_%05d.png',out,f))
    os.remove(string.format('%s/t_%05d.png',out,f-tshots_n))
  end
  was_cine=cine
  local st,mode=sp:read_u8(0xff0cb2),sp:read_u16(0xff0c12)
  if mode==4 then
    if st~=pstage then pstage,pk=st,0 end
    pk=pk+1
    if pshots_n and pk%pshots_n==0 then screen:snapshot(string.format('%s/p_%d_%05d.png',out,st,pk)) end
    local s=seeds[st]
    if s and pk==1 then
      sp:write_u16(0xff0c22,s[1])
      sp:write_u8(0xff0cb3,s[2])
      sp:write_u8(0xff0c98,s[3])
      sp:write_u16(0xff0c9a,s[4])
      log:write(string.format('#\tseed\t%d\t%d\t%04x\t%02x\t%02x\t%04x\n',f,st,s[1],s[2],s[3],s[4]))
      seeds[st]=nil
    end
  end
end
local inputs_only=os.getenv('INPUTS_ONLY')=='1'
local cseen={}
local function hexbytes(a,n)
  local t={}
  for i=0,n-1 do t[#t+1]=string.format('%02x',sp:read_u8(a+i)) end
  return table.concat(t)
end
local function pals()                     -- the palettes PALS names, 32 bytes each (hex)
  local t={}
  for _,a in ipairs(palw) do t[#t+1]=hexbytes(a,32) end
  return table.concat(t)
end
local function actors()
  local active=0
  for k=0,29 do
    local o=0xff211a+0x50*k
    local key,desc=nil,nil
    if sp:read_u8(o)~=0 then
      active=active+1
      if sp:read_u8(o+0x17)==3 then          -- an actor is its kind and once id; the facing is logged as it spawned
        key=string.format('%d,%d',sp:read_u8(o+6),sp:read_u8(o+0x21))
        desc=string.format('%d,%d,%d',sp:read_u8(o+6),sp:read_u8(o+0x16),sp:read_u8(o+0x21))
        if sp:read_u8(o+6)==11 then
          alog:write(string.format('#\tsw\t%d\t%d\t%s\t%d\t%d\t%d\t%d\t%d\t%d\t%08x\t%08x\n',f,k,desc,sp:read_u8(o+2),
            sp:read_u8(o+3),sp:read_u16(o+0x3c),sp:read_u16(o+0x3e),sp:read_u8(o+0x43),sp:read_u8(o+0x1e),
            sp:read_u32(o+0x48),sp:read_u32(o+0x4c)))
        end
        local kd=sp:read_u8(o+6)
        if (kd>=12 and kd<=28) or kd==1 then
          alog:write(string.format('#\ta5\t%d\t%d\t%s\t%d\t%d\t%d\t%d\t%08x\t%08x\t%d\t%d\t%d\t%02x%02x%02x%02x%02x%02x\t'..
            '%08x\t%08x\t%08x\t%08x\t%d\t%04x\t%02x\t%d\t%08x\t%08x\n',f,k,desc,sp:read_u8(o+2),sp:read_u8(o+3),
            sp:read_u16(o+0x3c),sp:read_u16(o+0x3e),sp:read_u32(o+8),sp:read_u32(o+12),sp:read_u8(o+0x1e),sp:read_u8(o+0x40),
            sp:read_u8(o+0x41),sp:read_u8(o+0x42),sp:read_u8(o+0x43),sp:read_u8(o+0x44),sp:read_u8(o+0x45),sp:read_u8(o+0x46),
            sp:read_u8(o+0x47),sp:read_u32(o+0x48),sp:read_u32(o+0x4c),sp:read_u32(o+0x2a),sp:read_u32(o+0x2e),
            sp:read_i8(o+0x32),sp:read_u16(o+0x12),sp:read_u8(o+7),sp:read_i16(o+0x32),sp:read_u32(o+0x34),sp:read_u32(o+0x38)))
        end
        if sp:read_u8(o+6)==8 then
          alog:write(string.format('#\tdr\t%d\t%d\t%s\t%d\t%d\t%d\t%d\t%d\t%d\t%08x\t%08x\t%08x\t%02x\t%02x\t%04x\t%04x\n',
            f,k,desc,sp:read_u8(o+2),
            sp:read_u8(o+3),sp:read_u8(o+0x47),sp:read_u8(o+0x45),sp:read_u8(o+0x46),sp:read_u16(o+0x3c),sp:read_u32(o+8),
            sp:read_u32(o+12),sp:read_u32(o+0x48),sp:read_u8(o+0x41),sp:read_u8(o+0x11),sp:read_u16(o+0x12),sp:read_u16(o+0x14)))
        end
      end
    end
    -- a record still in state 0 at the frame's end is a new life (the fill clears the state; its handler
    -- has not run): one freed and spawned again in its slot on one frame, the same kind and id, shows too
    local st=key and sp:read_u8(o+2) or nil
    local fresh=key and aseen[k] and st==0 and aseen[k][3]~=0
    if key~=(aseen[k] and aseen[k][1]) or fresh then
      if aseen[k] then alog:write(string.format('#\tgone\t%d\t%d\t%s\n',f,k,aseen[k][2])) end
      if key then alog:write(string.format('#\tnew\t%d\t%d\t%s\t%d\t%d\n',f,k,desc,sp:read_i16(o+8),sp:read_i16(o+12))) end
      aseen[k]=key and {key,desc,st} or nil
    elseif aseen[k] then
      aseen[k][3]=st
    end
  end
  for k=0,29 do                             -- the stock capsules (pool 7 type 0x1A): appear, change, go
    local o=0xff33da+0x50*k
    local key=nil
    if sp:read_u8(o)~=0 and sp:read_u8(o+0x17)==0x1a then
      key=string.format('%d\t%d\t%d\t%d',sp:read_u8(o+6),sp:read_u8(o+0x3c),sp:read_u8(o+2),sp:read_u8(o+3))
    end
    if key~=cseen[k] then
      if key then
        alog:write(string.format('#\tcap\t%d\t%d\t%s\t%d\t%d\t%08x\n',f,k,key,sp:read_i16(o+8),sp:read_i16(o+12),
          sp:read_u32(o+0x38)))
      else
        alog:write(string.format('#\tcapgone\t%d\t%d\n',f,k))
      end
      cseen[k]=key
    end
  end
  alog:write(string.format('%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%08x\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%s\t'..
    '%s\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%08x%02x\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t'..
    '%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%s\t%s\t%04x\t%08x\t%d\t%d\t%s\t'..
    '%d\t%d\t%d\t%d\t%02x%02x\t%d\t%d\n',f,
    sp:read_u16(0xfffa8e),sp:read_u16(0xfffa8c),sp:read_u16(0xfffa90),sp:read_u16(0xfffa92),sp:read_u16(0xfffa94),
    sp:read_u16(0xff69de),active,sp:read_u32(0xff0cb6),sp:read_u8(0xff0cf6),sp:read_u16(0xff0cf4),
    sp:read_u16(0xfffaa0),sp:read_u16(0xfffaa2),sp:read_u16(0xfffaa4),sp:read_u16(0xfffaa6),sp:read_u16(0xfffaa8),
    sp:read_u16(0xfffaaa),hexbytes(0xfffbc0,32),hexbytes(0xfffbe0,32),
    sp:read_u16(0xfffac0),sp:read_u16(0xfffac2),sp:read_u16(0xfffac4),sp:read_u16(0xfffac6),sp:read_u16(0xfffac8),
    sp:read_u16(0xfffaca),sp:read_u16(0xfffacc),sp:read_u16(0xff69e2),sp:read_u8(0xff0ccf),sp:read_u32(0xff0ce6),
    sp:read_u8(0xff0cea),sp:read_u16(0xff0ce2),sp:read_u8(0xff0ca8),sp:read_u16(0xffface),sp:read_u16(0xfffad8),
    sp:read_u16(0xfffada),sp:read_u16(0xfffadc),sp:read_u16(0xfffade),sp:read_u16(0xfffb30),sp:read_u16(0xfffb32),
    sp:read_u16(0xfffb34),sp:read_u16(0xfffb36),sp:read_u16(0xfffb38),sp:read_u16(0xfffb3a),sp:read_u16(0xfffb3c),
    sp:read_u16(0xfffb3e),sp:read_u16(0xfffb40),sp:read_u16(0xfffb42),sp:read_u16(0xfffb44),sp:read_u16(0xfffb46),
    sp:read_u16(0xfffb48),sp:read_u16(0xfffb4a),sp:read_u16(0xfffb4c),sp:read_u16(0xfffb4e),sp:read_u16(0xff69e0),
    hexbytes(0xfffb80,0x2c),pals(),sp:read_u16(0xfff940),sp:read_u32(0xff10d2),sp:read_i16(0xff10d6),sp:read_u8(0xff10cd),
    hexbytes(0xfffb00,0x30),sp:read_i16(0xff0fb4),sp:read_i16(0xff0fb8),sp:read_i16(0xff0c34),sp:read_i16(0xff0c36),
    sp:read_u8(0xff111d),sp:read_u8(0xff111e),sp:read_u8(0xff10fb),sp:read_u8(0xff10ec)))
end
emu.register_frame_done(function()
  if cpu_log then
    cpu_log:write(string.format('%d\t%x\t%x\t%x\t%x\t%x\t%x\n',f,cpu.state['CURPC'].value,
      cpu.state['A0'].value,cpu.state['SP'] and cpu.state['SP'].value or 0,cpu.state['D0'].value,cpu.state['D1'].value,cpu.state['D5'].value))
    cpu_log:flush()
  end
  f=f+1
  if video_frames[f] then
    local file=assert(io.open(string.format('%s/vram_%05d.bin',out,f),'wb'))
    local data={}
    for address=0x900000,0x92ffff,4 do data[#data+1]=string.pack('>I4',sp:read_u32(address)) end
    file:write(table.concat(data));file:close()
  end
  if video_log then video_log:flush() end
  if alog then actors() end
  if clog then caption() end
  if rlog then ready() end
  if flog then fade() end
  if mlog then motion() end
  log:write(string.format('%d\t%08x\t%d\t%s\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%04x\t%d\t%d\t%d\t%04x\t%08x\t%04x\n',f,crc,nw,
    table.concat(snd,','),sp:read_u8(0xff0cb2),sp:read_u8(0xff0cce),sp:read_u16(0xff0c12),sp:read_i16(0xff10d2),
    sp:read_i16(0xff10d6),sp:read_i16(0xff0ff4),sp:read_i16(0xff0ff8),s3base,sp:read_u8(0xff0ca8),objw,sp:read_u8(0xff0030),
    sp:read_u16(0xfff914),sp:read_u32(0xfff904),sp:read_u16(0xff0c74)))
  crc,nw,snd,objw=0,0,{},0
  if (sa and f>=sa and f<=sb and (f-sa)%sn==0) or (rshots and f-rlast<=4) then
    screen:snapshot(string.format('%s/s_%05d.png',out,f))
  end
  if ram_n and f%ram_n==0 then
    ramf:write(sp:read_range(0xff0000,0xffffff,8))
    rami:write(f..'\n')
  end
  local act=sp:read_u16(0xfff914)
  if ilog then intro() end
  intro_shots(act)
  if act~=0xc1e5 and act~=0xc1e6 and act~=0xc1e7 and act~=0xc1e8 then
    g=g+1
    if gsn and g%gsn==0 then screen:snapshot(string.format('%s/g_%06d.png',out,g)) end
  end
  if climb and (not climb_end or f<=climb_end) then
    if sp:read_u8(0xff10cd)==4 then fields.P1_JOYSTICK_UP:set_value(1) else fields.P1_JOYSTICK_UP:clear_value() end
  elseif climb and f==climb_end+1 then
    fields.P1_JOYSTICK_UP:clear_value()
  end
  if hlog then
    hlog:write(string.format('%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\n',f,sp:read_i16(0xff10d2),sp:read_i16(0xff10d6),
      sp:read_u8(0xff10cd),sp:read_u8(0xff10ce),sp:read_u8(0xff10ec),sp:read_i16(0xff1102),sp:read_u8(0xff10fa)))
  end
  local w=warps[f]
  if w and sp:read_u16(0xff0c12)==4 then
    sp:write_u16(0xff10d2,w[1]&0xffff)
    sp:write_u16(0xff10d6,w[2]&0xffff)
    log:write(string.format('#\twarp\t%d\t%d\t%d\n',f,w[1],w[2]))
  end
  if #hits>0 then
    for k=0,29 do
      local o=0xff211a+0x50*k
      local key=nil
      if sp:read_u8(o)~=0 and sp:read_u8(o+0x17)==3 then key=sp:read_u8(o+6)*256+sp:read_u8(o+0x16) end
      if key~=(hitseen[k] and hitseen[k][1]) then hitseen[k]=key and {key,f} or nil end
      if key then
        for _,h in ipairs(hits) do
          if key==h[1]*256+h[2] and f==hitseen[k][2]+h[3] then
            sp:write_u8(o+0x1e,h[4])
            log:write(string.format('#\thit\t%d\t%d\t%d\t%d\n',f,k,h[1],h[2]))
          end
        end
      end
    end
  end
  for _,pk in ipairs(pokes) do
    if pk[1]==f then
      sp:write_u16(pk[2],pk[3])
      log:write(string.format('#\tpoke\t%d\t%06x\t%04x\n',f,pk[2],pk[3]))
    end
  end
  local wa=warps_at[nwarp]
  if wa and sp:read_u16(0xff0c12)==4 and (hold>0 or sp:read_i16(0xff10d2)>=wa[1]) then
    sp:write_u16(0xff10d2,wa[2]&0xffff)
    sp:write_u16(0xff10d6,wa[3]&0xffff)
    log:write(string.format('#\twarp\t%d\t%d\t%d\n',f,wa[2],wa[3]))
    hold=hold+1
    if hold>=wa[4] then hold=0 nwarp=nwarp+1 end
  end
  -- the desert's section machine (asm/desert.s DZV 0xFFF92C): logged on change
  local dz=string.format('%d\t%d\t%d\t%d\t%04x\t%d,%d,%d,%d',sp:read_u16(0xfff932),sp:read_u16(0xfff934),
    sp:read_u16(0xfff930),sp:read_i16(0xfff92c),sp:read_u16(0xfff92e),sp:read_i16(0xff1018),sp:read_i16(0xff1016),
    sp:read_i16(0xff101c),sp:read_i16(0xff101a))
  if dz~=prevdz then dzlog:write(f..'\t'..dz..'\n') dzlog:flush() prevdz=dz end
  if s1skip and sp:read_u16(0xfff932)==1 and sp:read_u16(0xfff934)>=s1from then
    sp:write_u16(0xfff934,s1skip)
    log:write(string.format('#\tskip\t%d\t%d\n',f,s1skip))
    s1skip=nil
  end
  if s4skip and sp:read_u16(0xfff932)==4 and sp:read_u16(0xfff934)>=s4from then
    sp:write_u16(0xfff934,s4skip)
    log:write(string.format('#\tskip\t%d\t%d\n',f,s4skip))
    s4skip=nil
  end
  if pitlog then                            -- the pit's sample cells in both SCROLL3 maps, on change
    local v={}
    for i,o in ipairs(pitcells) do v[i]=string.format('%08x,%08x',sp:read_u32(0x918000+o),sp:read_u32(0x910000+o)) end
    local s=table.concat(v,';')
    if s~=prevpit then pitlog:write(f..'\t'..s..'\n') prevpit=s end
  end
  if clears[nclear] and f>=clears[nclear] and sp:read_u16(0xff0c12)==4 then
    sp:write_u16(0xff0c12,6)
    log:write(string.format('#\tclear control\t%d\n',f))
    nclear=nclear+1
  end
  if cp_n and cp_k>0 then
    if sp:read_u16(0xff0c12)==4 then inplay=inplay+1 else inplay=0 end
    if inplay>=cp_n then
      sp:write_u16(0xff0c12,6)
      log:write(string.format('#\tclear control\t%d\n',f))
      inplay,cp_k=0,cp_k-1
    end
  end
  if newgame then
    if (f>=200 and f<=208) or (two and f>=240 and f<=248) then fields.COIN1:set_value(1)
    else fields.COIN1:clear_value() end
    local start=two and fields.START2 or fields.START1
    if f>=400 and f<=408 then start:set_value(1) else start:clear_value() end
    local want={}
    for _,e in ipairs(inputs) do
      local on=f>=e.a and f<=e.b and (not e.per or (f-e.a)%e.per<e.duty)
      want[e.tok]=want[e.tok] or on
    end
    for tok,on in pairs(want) do if on then fields[tok]:set_value(1) else fields[tok]:clear_value() end end
  elseif inputs_only then
    local want={}
    for _,e in ipairs(inputs) do
      local on=f>=e.a and f<=e.b and (not e.per or (f-e.a)%e.per<e.duty)
      want[e.tok]=want[e.tok] or on
    end
    for tok,on in pairs(want) do if on then fields[tok]:set_value(1) else fields[tok]:clear_value() end end
  end
  if f>=last then log:close() if alog then alog:close() end if hlog then hlog:close() end
    if ilog then ilog:close() end
    if clog then clog:close() end if flog then flog:close() end if rlog then rlog:close() end
    if ramf then ramf:close() rami:close() end
    if mlog then mlog:close() end m:exit() end
end)
local tfile,tfrom,tto=string.match(os.getenv('TRACE') or '','^(.+):(%d+)-(%d+)$')
if tfile then
  tfrom,tto=tonumber(tfrom),tonumber(tto)
  local tf=0
  emu.register_frame_done(function()
    tf=tf+1
    if tf==tfrom then m.debugger:command('trace '..tfile..',maincpu,noloop') end
    if tf==tto then m.debugger:command('trace off,maincpu') end
  end)
end
local dbg=os.getenv('STREX_DEBUG_START')
if dbg and not newgame then dofile(dbg) end
