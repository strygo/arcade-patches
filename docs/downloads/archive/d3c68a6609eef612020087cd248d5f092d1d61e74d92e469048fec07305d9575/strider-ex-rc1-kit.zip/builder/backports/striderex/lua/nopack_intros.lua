-- Strider EX: a stage's cinematics and the stage start, with the sound commands and the YM2151 writes
-- (scripts/nopack_intros.py gate and review). Focus-safe when run as the script runs it.
--
-- Env:
--   OUT        output directory: frames.tsv (frame, records, stream pointer, ACTIVE, ENDED, game mode),
--              latch.tsv (frame, ACTIVE, value) per 68000 write to the sound latch 0x800180,
--              ym.tsv (frame, machine time, register, value) per Z80 write to the YM2151 data port,
--              meta.tsv (press, handback, play: their frames)
--   END        the last frame
--   TAIL       frames run after play starts (game mode 4 after the hand-back)
--   MOST       frames run after the hand-back at most
--   SKIP_LO, SKIP_HI, SKIP_REC   a START press once the scene whose stream lies in [SKIP_LO, SKIP_HI) has
--              played SKIP_REC records (-1: at its end mark); SKIP_HOLD frames held
--   STREX_DEBUG_START   lua/arcade_debug_start.lua for a debug start (its STREX_* variables); else a coin
--              at frame 200 and START at 400, as ex_gate.py runs it
-- Every tap handle is kept in a global: Lua GC would otherwise remove it.
local m=manager.machine
local sp=m.devices[':maincpu'].spaces['program']
local z=m.devices[':audiocpu'].spaces['program']
local fields={}
for _,port in pairs(m.ioport.ports) do for name,field in pairs(port.fields) do
 fields[m.ioport:input_type_to_token(field.type,field.player)]=field end end
local out=os.getenv('OUT')
local frames=assert(io.open(out..'/frames.tsv','w'))
local latch=assert(io.open(out..'/latch.tsv','w'))
local ym=assert(io.open(out..'/ym.tsv','w'))
local meta=assert(io.open(out..'/meta.tsv','w'))
local fade=assert(io.open(out..'/fade.tsv','w'))
local oki=assert(io.open(out..'/oki.tsv','w'))
local atten=assert(io.open(out..'/atten.tsv','w'))
local video=assert(io.open(out..'/video.tsv','w'))
local splitlo=tonumber(os.getenv('SPLIT_LO') or '0')
local splithi=tonumber(os.getenv('SPLIT_HI') or '0')
local splitpre=tonumber(os.getenv('SPLIT_PRE') or '0')
local captured={}
local f=0
local last=tonumber(os.getenv('END'))
local tail=tonumber(os.getenv('TAIL'))
local most=tonumber(os.getenv('MOST'))
local lo=tonumber(os.getenv('SKIP_LO') or '0')
local hi=tonumber(os.getenv('SKIP_HI') or '0')
local rec=tonumber(os.getenv('SKIP_REC') or '0')
local hold=tonumber(os.getenv('SKIP_HOLD') or '6')
local debug=os.getenv('STREX_DEBUG_START')
_G.npi_latch=sp:install_write_tap(0x800180,0x800181,'npi_latch',function(off,data,mask)
 latch:write(string.format('%d\t%04x\t%02x\n',f+1,sp:read_u16(0xfff914),data&0xff)) end)
_G.npi_fade=sp:install_write_tap(0x800188,0x800189,'npi_fade',function(off,data,mask)
 fade:write(string.format('%d\t%02x\n',f+1,data&0xff)) end)
_G.npi_oki=z:install_write_tap(0xf002,0xf002,'npi_oki',function(a,d,mask)
 oki:write(string.format('%d\t%02x\n',f+1,d&0xff)) end)
local reg=0
_G.npi_ym=z:install_write_tap(0xf000,0xf001,'npi_ym',function(a,d,mask)
 if a==0xf000 then reg=d&0xff
 else ym:write(string.format('%d\t%.9f\t%02x\t%02x\n',f+1,m.time:as_double(),reg,d&0xff)) end end)
if debug then dofile(debug) end                          -- (its frame callback first: the press below wins)
local press,was_on,back,play=nil,false,nil,nil
emu.register_frame_done(function()
 f=f+1
 if not debug then
  if f>=200 and f<=208 then fields.COIN1:set_value(1) else fields.COIN1:clear_value() end
  if f>=400 and f<=408 then fields.START1:set_value(1) else fields.START1:clear_value() end
 end
 local active=sp:read_u16(0xfff914)
 local records=sp:read_u32(0xfff900)
 local lz=sp:read_u32(0xfff904)
 local ended=sp:read_u16(0xfff910)
 video:write(string.format('%d\t%d\t%d\t%d\n',f,sp:read_u16(0xfff9b0),sp:read_u16(0xfff9b2),sp:read_u16(0xfff912)))
 if active==0xc1e5 and lz>=splitlo and lz<splithi then
  for _,delta in ipairs({5,30,60,120}) do
   if records==splitpre+delta and not captured[records] then
    m.screens[':screen']:snapshot(out..'/split_'..records..'.png')
    captured[records]=true
   end
  end
 end
 atten:write(string.format('%d\t%d\t%d\n',f,z:read_u8(0xd010),z:read_u8(0xd003)))
 if not press and hi>0 and active==0xc1e5 and lz>=lo and lz<hi and
    ((rec>=0 and ended==0 and records>=rec) or (rec<0 and ended==1)) then
  press=f
  meta:write(string.format('press\t%d\n',f))
 end
 if press and f>=press and f<press+hold then fields.START1:set_value(1)
 elseif press and f==press+hold then fields.START1:clear_value() end
 if active==0xc1e5 then was_on=true end
 if was_on and active==0 and not back then back=f meta:write(string.format('handback\t%d\n',f)) end
 local mode=sp:read_u16(0xff0c12)
 frames:write(string.format('%d\t%d\t%08x\t%04x\t%d\t%d\n',f,records,lz,active,ended,mode))
 if back and not play and mode==4 then play=f meta:write(string.format('play\t%d\n',f)) end
 if f>=last or (play and f>=play+tail) or (back and f>=back+most) then
  frames:close() latch:close() ym:close() meta:close() fade:close() oki:close() atten:close() video:close() m:exit() end
end)
