-- Census of the SCROLL3 tile codes the game writes into the map at 0x910000-0x913FFF
-- (scripts/desert_gate.py census): every distinct (code, flips) pair (the code word
-- masked to 14 bits, the attribute word's flip bits 5-6) and the first frame, writer PC,
-- stage and area it was seen with. Runs the arcade debug start
-- (lua/arcade_debug_start.lua; STREX_* variables) and exits at its STREX_END.
-- Output: $OUT/scroll3_codes.tsv.
local m=manager.machine
local cpu=m.devices[':maincpu']
local sp=cpu.spaces['program']
local out=assert(os.getenv('OUT'))
local seen={}
local f=0
local log=assert(io.open(out..'/scroll3_codes.tsv','w'))
log:write('code\tflips\tframe\tpc\tstage\tarea\n')
-- an entry is two words, the code then the attribute (flips: bits 5-6); a pair is logged
-- when the attribute word is written (also a long write, which taps as two words)
local code_at={}
_G.s3c=sp:install_write_tap(0x910000,0x913fff,'s3c',function(o,d,mk)
  if (o&2)==0 then
    code_at[o]=d&0x3fff
  else
    local c=code_at[o-2] or (sp:read_u16(o-2)&0x3fff)
    local k=c*4+((d>>5)&3)
    if not seen[k] then
      seen[k]=true
      log:write(string.format('%04x\t%d\t%d\t%06x\t%d\t%d\n',c,(d>>5)&3,f,cpu.state['CURPC'].value,sp:read_u8(0xff0cb2),sp:read_u8(0xff0cce)))
      log:flush()
    end
  end
end)
emu.register_frame_done(function() f=f+1 end)
dofile(assert(os.getenv('STREX_DEBUG_START')))
