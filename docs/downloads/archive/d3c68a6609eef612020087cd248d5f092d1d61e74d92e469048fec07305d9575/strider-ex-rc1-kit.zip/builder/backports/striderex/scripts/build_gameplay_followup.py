"""Recreate the approved native-art stage-clear/desert follow-up from Kit aa."""
import argparse
import json
from pathlib import Path
import subprocess
import sys
from boss_voice_gate import inventory, sha
import respawn_fix as R
ROOT = Path(__file__).resolve().parents[3]
SCRIPTS = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'release'))
import private_mister as PM
STAGES = (('stage_clear', 'stage_clear.py'), ('camera', 'desert_motion_fix.py'), ('transition', 'desert_transition_fix.py'), ('pole_floor', 'desert_pole_floor.py'), ('final', 'desert_climb_fix.py'))
BASELINE_SHA = 'dac84177383bdf75fc479e57ab9a8895b66b7f6cca9a585102239b072a4872a2'

def main():
    if sys.argv[1:] == ['--self-test']:
        for _, script in STAGES:
            subprocess.run([sys.executable, str(SCRIPTS / script), '--self-test'], check=True)
        print('Gameplay follow-up producer guards PASS')
        return
    p = argparse.ArgumentParser(description=__doc__)
    for n in ('baseline-kit', 'rom-dir', 'vasm', 'out'):
        p.add_argument('--' + n, type=Path, required=True)
    a = p.parse_args()
    receipt = PM.verify(a.baseline_kit.resolve())
    if receipt['test_id'] != '261026-01':
        raise ValueError('need the selected native-pixel Kit aa, 261026-01')
    if sha((a.baseline_kit / 'private-mister.json').read_bytes()) != BASELINE_SHA:
        raise ValueError('selected native-pixel export identity differs')
    a.out = a.out.resolve()
    a.out.mkdir(parents=True, exist_ok=False)

    def run(script, *args):
        subprocess.run([sys.executable, str(SCRIPTS / script), *map(str, args)], check=True)
    source = a.out / 'base'
    run('reconstruct_private_build.py', '--kit', a.baseline_kit.resolve(), '--out', source)
    before, files = inventory(source)
    builds = []
    for name, script in STAGES:
        dest = a.out / name
        extra = ['--rom-dir', a.rom_dir.resolve()] if name == 'pole_floor' else ['--vasm', a.vasm.resolve()]
        run(script, '--self-test')
        run(script, '--build', source, *extra, '--out', dest)
        meta, _ = inventory(dest)
        builds.append(dict(name=name, files={m: s['files'] for m, s in meta['sets'].items()}))
        source = dest
    meta, result = inventory(source)
    preserved = {}
    for m, old in files.items():
        data_names = {n for n, _, _ in R.SETS[m]} | {'strex_p6.bin'}
        kept = {n: sha(b) for n, b in old.items() if n not in data_names}
        if any((sha(result[m][n]) != v for n, v in kept.items())):
            raise ValueError('selected art or sound changed')
        preserved[m] = kept
    meta['art_selection'] = dict(scale='native', approved='2026-10-26', source_private_test_id=receipt['test_id'], image_and_sound_files_preserved=preserved)
    (source / 'build.json').write_text(json.dumps(meta, indent=2) + '\n')
    report = dict(schema='striderex-gameplay-followup-build/1', passed=True, baseline_test_id=receipt['test_id'], baseline_export_manifest_sha256=sha((a.baseline_kit / 'private-mister.json').read_bytes()), art_selection=meta['art_selection'], builds=builds, producer_source_sha256={script: sha((SCRIPTS / script).read_bytes()) for _, script in STAGES}, hardware_review_granted=False)
    (a.out / 'receipt.json').write_text(json.dumps(report, indent=2) + '\n')
    print('Native-pixel gameplay follow-up recreated; all selected artwork and sound preserved')
if __name__ == '__main__':
    main()
