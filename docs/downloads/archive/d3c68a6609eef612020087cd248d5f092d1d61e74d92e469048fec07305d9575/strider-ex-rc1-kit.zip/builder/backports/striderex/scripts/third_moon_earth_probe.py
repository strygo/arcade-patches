"""Capture the original Third Moon Earth with canonical stock MAME ROMs."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
ROOT = Path(__file__).resolve().parents[3]
DEBUG = ROOT / 'backports/striderex/lua/arcade_debug_start.lua'
REF = ROOT / 'backports/striderex/rtl/jtcps1_sim/hbmame_ref.lua'
LUA = "dofile(os.getenv('STREX_REF_LUA'))\ndofile(os.getenv('STREX_DEBUG_START'))\n"

def sha(data):
    return hashlib.sha256(data).hexdigest()

def run(a):
    out = a.out.resolve()
    out.mkdir(parents=True, exist_ok=False)
    binary = Path(shutil.which(a.mame) or a.mame).resolve()
    verification = subprocess.run([str(binary), a.machine, '-rompath', str(a.rom_dir.resolve()), '-verifyroms'], capture_output=True, text=True)
    (out / 'verifyroms.log').write_text(verification.stdout + verification.stderr)
    if verification.returncode:
        raise ValueError('stock ROM verification failed')
    script = out / 'capture.lua'
    script.write_text(LUA)
    inherited = {k: v for k, v in os.environ.items() if not k.startswith('STREX_') and k not in ('OUT', 'END', 'SHOTS', 'MEMDUMP', 'VRAMLOG')}
    env = dict(inherited, SDL_VIDEODRIVER='dummy', SDL_AUDIODRIVER='dummy', OUT=str(out), END=str(a.frames + 1), SHOTS=a.shots, MEMDUMP=a.dumps, STREX_REF_LUA=str(REF), STREX_DEBUG_START=str(DEBUG), STREX_STAGE='4', STREX_AREA=str(a.area), STREX_INVINCIBLE='1', STREX_INVINCIBLE_END=str(a.invincible_end or a.frames + 1), STREX_END=str(a.frames), STREX_PREFIX=str(out / 'debug'), STREX_INPUTS=a.inputs, STREX_CAMERA_EVERY='30')
    command = [str(binary), a.machine, '-rompath', str(a.rom_dir.resolve()), '-nothrottle', '-video', 'none', '-sound', 'none', '-seconds_to_run', str(a.frames // 50 + 60), '-skip_gameinfo', '-noautosave', '-cfg_directory', str(out / 'cfg'), '-nvram_directory', str(out / 'nv'), '-snapshot_directory', str(out), '-autoboot_script', str(script)]
    result = subprocess.run(command, env=env, cwd=out, capture_output=True, text=True, timeout=600)
    (out / 'mame.log').write_text(result.stdout + result.stderr)
    if result.returncode:
        raise ValueError('stock capture failed')
    frames = (out / 'frames.tsv').read_text().splitlines()
    if len(frames) != a.frames:
        raise ValueError('stock run did not reach its frame bound')
    sources = {p.relative_to(a.rom_dir).as_posix(): sha(p.read_bytes()) for folder in (a.rom_dir / 'strider', a.rom_dir / a.machine) for p in sorted(folder.iterdir()) if p.is_file()}
    report = dict(schema='striderex-stock-third-moon-capture/1', passed=True, machine=a.machine, stage=4, area=a.area, frames=a.frames, inputs=a.inputs, shots=a.shots, dumps=a.dumps, invincible_end=a.invincible_end or a.frames + 1, runtime_sha256=sha(binary.read_bytes()), runtime_version=subprocess.check_output([str(binary), '-version'], text=True).strip(), canonical_files=sources, rom_verification_exit=verification.returncode, debug_lua_sha256=sha(DEBUG.read_bytes()), reference_lua_sha256=sha(REF.read_bytes()), wrapper_sha256=sha(LUA.encode()), exit_code=result.returncode, rom_and_ram_patches=False, hardware_review_granted=False, trace_sha256={p.name: sha(p.read_bytes()) for p in sorted(out.iterdir()) if p.suffix in ('.bin', '.tsv')}, images={p.name: sha(p.read_bytes()) for p in sorted(out.glob('f_*.png'))})
    (out / 'capture.json').write_text(json.dumps(report, indent=2) + '\n')
    print('PASS: canonical stock Third Moon capture, no ROM or RAM patches')

def compare(a):
    import sys
    import zipfile
    import respawn_fix as RF
    import earth_palette as EP
    sys.path.insert(0, str(ROOT / 'release'))
    import private_mister as PM
    source = json.loads((a.capture / 'capture.json').read_text())
    if not source['passed'] or source['machine'] != 'striderua' or source['area'] != 10 or source['rom_and_ram_patches']:
        raise ValueError('need the untouched USA final-room capture')
    if a.frame != 1440:
        raise ValueError('the mapped lower-tip reference is frame 1440')
    picture = a.capture / f'f_{a.frame:05d}.png'
    if sha(picture.read_bytes()) != source['images'][picture.name]:
        raise ValueError('stock screenshot changed')
    dump = a.capture / f'vram_{a.frame:05d}.bin'
    vram = dump.read_bytes()
    if sha(vram) != source['trace_sha256'][dump.name]:
        raise ValueError('stock video state changed')
    stock = {p.name: p.read_bytes() for p in (a.rom_dir / 'striderua').iterdir() if p.is_file()}
    for name, data in stock.items():
        if sha(data) != source['canonical_files']['striderua/' + name]:
            raise ValueError('stock input changed')
    record = PM.verify(a.kit.resolve())
    archive = next((n for n in record['files'] if n.endswith('/striderex_us.zip')))
    with zipfile.ZipFile(a.kit / archive) as z:
        final = {n: z.read(n) for n in z.namelist()}
    old, new = [RF.compose(files, RF.SETS['striderua']) for files in (stock, final)]
    graphics = ('st-1.7a', 'st-2.8a', 'st-4.3a', 'st-5.4a', 'st-8.5a', 'st-9.6a', 'st-10.9a', 'st-11.10a')
    if any((stock[n] != final[n] for n in graphics)):
        raise ValueError('original graphics changed')
    if old[296704:296868] != new[296704:296868]:
        raise ValueError('Earth animation table changed')
    differences = [i for i in range(606208, 622592) if old[i] != new[i]]
    if differences != [619930, 619931] or old[619930:619932] != bytes.fromhex('34c3') or new[619930:619932] != bytes.fromhex('83d7'):
        raise ValueError('map differs beyond the independently qualified inner-edge repair')
    palettes = []
    for at, expected in zip(EP.OFFSETS['striderua'], EP.PALETTES):
        if old[at:at + 32] != expected or new[at:at + 32] != bytes.fromhex('f000') + expected[2:]:
            raise ValueError('Earth colors changed beyond the background black level')
        palettes.append(dict(cpu_address=hex(at), original_pen_zero='f111', final_pen_zero='f000', all_visible_color_words_identical=True))
    tiles = []
    for code, video_at in ((13580, 55212), (13581, 55216)):
        pattern = code.to_bytes(2, 'big') + bytes.fromhex('000c')
        if vram[video_at:video_at + 4] != pattern:
            raise ValueError('reference lower-tip video cell differs')
        hits = [i for i in range(606208, 622592, 2) if old[i:i + 4] == pattern]
        if len(hits) != 1 or new[hits[0]:hits[0] + 4] != pattern:
            raise ValueError('lower-tip map entry differs')
        tiles.append(dict(code=hex(code), cpu_address=hex(hits[0]), attribute='000c', captured_vram_address=hex(9437184 + video_at), identical=True))
    report = dict(schema='striderex-earth-lower-tip-origin/1', passed=True, test_id=record['test_id'], command='third_moon_earth_probe.py compare --capture <stock-final-room-capture> --frame 1440 --rom-dir <canonical-stock-sets> --kit <sealed-Kit-v> --receipt <report> --review <images>', finding='The squared lower tip and narrow fragment are visible in unmodified stock Strider; not introduced by the Kit v inner-edge repair.', method='The visual defect is not classified automatically.', source_capture=source, reference_frame=a.frame, stock_image_sha256=sha(picture.read_bytes()), final_private_manifest_sha256=sha((a.kit / 'private-mister.json').read_bytes()), original_graphics_sha256={n: sha(stock[n]) for n in graphics}, earth_animation_table_sha256=sha(old[296704:296868]), map_changed_bytes=[hex(i) for i in differences], lower_tip_entries=tiles, palettes=palettes, rom_changes_produced=False, hardware_review_granted=False)
    if a.review:
        from PIL import Image, ImageDraw
        a.review.mkdir(parents=True, exist_ok=True)
        im = Image.open(picture).convert('RGB')
        im.save(a.review / 'stock-earth-lower-tip.png')
        canvas = Image.new('RGB', (1088, 496), (24, 24, 24))
        draw = ImageDraw.Draw(canvas)
        draw.text((16, 10), 'Original arcade Strider (USA) - unmodified program and graphics', fill='white')
        canvas.paste(im.resize((768, 448), Image.Resampling.NEAREST), (16, 32))
        draw.rectangle((16 + 322 * 2, 32 + 198 * 2, 16 + 339 * 2, 32 + 223 * 2), outline=(255, 160, 64), width=2)
        draw.text((808, 40), 'Same lower-tip cutoff', fill='white')
        canvas.paste(im.crop((306, 180, 346, 224)).resize((240, 264), Image.Resampling.NEAREST), (808, 64))
        canvas.save(a.review / 'stock-earth-lower-tip-detail.png')
        report['review_images'] = {p.name: sha(p.read_bytes()) for p in sorted(a.review.glob('*.png'))}
    a.receipt.write_text(json.dumps(report, indent=2) + '\n')
    print('PASS: stock lower-tip defect; original graphics, tip map and visible colors unchanged in', record['test_id'])

def main():
    import sys
    if sys.argv[1:2] == ['compare']:
        p = argparse.ArgumentParser(description='Compare the stock lower-tip Earth data with a sealed EX kit')
        for name in ('capture', 'rom-dir', 'kit', 'receipt'):
            p.add_argument('--' + name, type=Path, required=True)
        p.add_argument('--frame', type=int, default=1440)
        p.add_argument('--review', type=Path)
        return compare(p.parse_args(sys.argv[2:]))
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--rom-dir', type=Path, required=True)
    p.add_argument('--out', type=Path, required=True)
    p.add_argument('--mame', default='mame')
    p.add_argument('--machine', default='striderua', choices=('striderua', 'striderjr'))
    p.add_argument('--area', type=int, default=0)
    p.add_argument('--frames', type=int, default=2400)
    p.add_argument('--invincible-end', type=int)
    p.add_argument('--shots', default='600-2400/200')
    p.add_argument('--dumps', default='1000,1600,2200')
    p.add_argument('--inputs', default='430-2400@6/3:P1_BUTTON1')
    run(p.parse_args())
if __name__ == '__main__':
    main()
