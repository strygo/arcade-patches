"""Reconstruction helper."""
import argparse
import base64
import html
import io
import json
import subprocess
import sys
import tempfile
import wave
from pathlib import Path
import numpy as np
from PIL import Image
sys.path.insert(0, str(Path(__file__).resolve().parent))
import pce_vdc as P
ROOT = Path(__file__).resolve().parents[3]
M = ROOT / 'backports/striderex/manifests'
TITLES = {'prologue': 'Prologue', 'brief_st_petersburg': 'St. Petersburg briefing', 'intro_desert': 'Desert introduction', 'brief_siberia': 'Siberia briefing', 'brief_aerial': 'Aerial Battleship briefing', 'brief_amazon': 'Amazon briefing', 'flight': 'Earth-to-Moon flight', 'welcome_meio': "Meio's welcome"}
GEMINI_VOICES = [('Zephyr', 'Bright'), ('Puck', 'Upbeat'), ('Charon', 'Informative'), ('Kore', 'Firm'), ('Fenrir', 'Excitable'), ('Leda', 'Youthful'), ('Orus', 'Firm'), ('Aoede', 'Breezy'), ('Callirrhoe', 'Easy-going'), ('Autonoe', 'Bright'), ('Enceladus', 'Breathy'), ('Iapetus', 'Clear'), ('Umbriel', 'Easy-going'), ('Algieba', 'Smooth'), ('Despina', 'Smooth'), ('Erinome', 'Clear'), ('Algenib', 'Gravelly'), ('Rasalgethi', 'Informative'), ('Laomedeia', 'Upbeat'), ('Achernar', 'Soft'), ('Alnilam', 'Firm'), ('Schedar', 'Even'), ('Gacrux', 'Mature'), ('Pulcherrima', 'Forward'), ('Achird', 'Friendly'), ('Zubenelgenubi', 'Casual'), ('Vindemiatrix', 'Gentle'), ('Sadachbia', 'Lively'), ('Sadaltager', 'Knowledgeable'), ('Sulafat', 'Warm')]

def jpeg_uri(arr):
    buf = io.BytesIO()
    Image.fromarray(arr).save(buf, 'JPEG', quality=82)
    return 'data:image/jpeg;base64,' + base64.b64encode(buf.getvalue()).decode()

def clip_uri(wav_path, t0, t1):
    with wave.open(str(wav_path)) as w:
        rate, ch = (w.getframerate(), w.getnchannels())
        a, b = (max(0, int(t0 * rate)), int(t1 * rate))
        w.setpos(min(a, w.getnframes()))
        raw = w.readframes(max(0, b - a))
    with tempfile.TemporaryDirectory() as d:
        src = Path(d) / 'c.wav'
        with wave.open(str(src), 'wb') as o:
            o.setnchannels(ch)
            o.setsampwidth(2)
            o.setframerate(rate)
            o.writeframes(raw)
        dst = Path(d) / 'c.mp3'
        subprocess.run(['ffmpeg', '-v', 'error', '-y', '-i', str(src), '-ac', '1', '-ar', '22050', '-b:a', '48k', str(dst)], check=True)
        return 'data:audio/mpeg;base64,' + base64.b64encode(dst.read_bytes()).decode()

def collect(census):
    subs = json.loads((M / 'subtitles.json').read_text())
    voices = json.loads((M / 'dub_voices.json').read_text())
    fit = json.loads((M / 'dub_fit.json').read_text())
    cat = {c['id']: c for c in json.loads((census / 'catalog/catalog.json').read_text())['cinematics']}
    idx_cache = {}
    lines = []
    for ln in subs['lines']:
        c = cat[ln['scene']]
        run = census / c['run']
        if run not in idx_cache:
            idx_cache[run] = P.read_index(run)
        idx = idx_cache[run]
        req = c['cd_request_time']
        mid = req + (ln['start'] + ln['end']) / 2
        frame = min(idx, key=lambda f: abs(float(idx[f]['time']) - mid))
        native, _ = P.native(run / f'pce_{frame:05d}_scene.png', 256)
        vl = voices['lines'].get(ln['id'], {})
        fl = fit['lines'].get(ln['id'], {})
        lines.append(dict(id=ln['id'], scene=ln['scene'], speaker=ln['speaker'], start=ln['start'], end=ln['end'], ja=ln['ja']['text'], en=ln['en']['text'], plain=vl.get('plain', ''), direction=voices['directions'].get(ln['id'], ''), rate=fl.get('tts_rate'), shift=(fl.get('proposed') or {}).get('shift_s'), voiced=fl.get('voiced', True), img=jpeg_uri(native[:224]), audio=clip_uri(run / 'audio.wav', req + ln['start'] - 0.25, req + ln['end'] + 0.35)))
        print(ln['id'], flush=True)
    speakers = []
    for name, sp in voices['speakers'].items():
        g = voices['gemini']['speakers'][name]
        own = [v['plain'].replace('Hee-ryoo', 'Hiryu') for v in voices['lines'].values() if v.get('speaker') == name and v.get('plain')]
        sample, n = ([], 0)
        for s in own:
            if sample and n + len(s) > 420:
                break
            sample.append(s)
            n += len(s) + 1
        speakers.append(dict(name=name, role=sp.get('role', ''), profile=sp['profile'], sample=' '.join(sample), measured=voices['japanese_voices']['findings'].get(name, ''), classic=[sp['voice']] + sp.get('alternates', []), gemini=g['voices'], style=g['style'], post=sp.get('post', ''), lines=sum((1 for l in lines if l['speaker'] == name))))
    return (lines, speakers, voices['gemini'])

def page(lines, speakers, gem):
    data = dict(lines=lines, speakers=speakers, voices=GEMINI_VOICES, scene=gem['scene'], model=gem['model'], titles=TITLES)
    blob = json.dumps(data, ensure_ascii=False).replace('</', '<\\/')
    return TEMPLATE.replace('__DATA__', blob)
TEMPLATE = '<title>Strider EX Dub Casting</title>\n<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Barlow+Condensed:wght@500;600;700&family=Source+Serif+4:opsz,wght@8..60,400;8..60,600&family=JetBrains+Mono:wght@400;500&family=Noto+Sans+JP:wght@400;500&display=swap">\n<style>\n/* Layout: a casting sheet. Speakers first (the decisions), then every line in scene order, picture left, script right. */\n:root{\n  --bg:#f2f1ee;--panel:#ffffff;--ink:#17191d;--muted:#5b616b;--line:#d9d8d3;--accent:#a3271f;--accent-ink:#ffffff;\n  --ok:#2c7a4b;--chip:#ece9e2;--field:#fbfaf8;\n  --f-display:"Barlow Condensed","Arial Narrow",sans-serif;--f-body:"Source Serif 4",Georgia,serif;\n  --f-mono:"JetBrains Mono",ui-monospace,Menlo,monospace;--f-ja:"Noto Sans JP","Hiragino Sans","Yu Gothic",sans-serif;\n}\n@media (prefers-color-scheme:dark){:root:not([data-theme="light"]){\n  --bg:#121315;--panel:#1b1d20;--ink:#e9e7e2;--muted:#9da2aa;--line:#2e3136;--accent:#e2574b;--accent-ink:#160807;\n  --ok:#5ec48b;--chip:#26292e;--field:#202327;color-scheme:dark}}\n:root[data-theme="dark"]{--bg:#121315;--panel:#1b1d20;--ink:#e9e7e2;--muted:#9da2aa;--line:#2e3136;--accent:#e2574b;\n  --accent-ink:#160807;--ok:#5ec48b;--chip:#26292e;--field:#202327;color-scheme:dark}\nbody{background:var(--bg);color:var(--ink);font:16px/1.55 var(--f-body)}\n.wrap{max-width:1040px;margin:0 auto;padding-inline:16px;padding-block:24px 96px}\nh1,h2,h3{font-family:var(--f-display);letter-spacing:.02em;margin:0;text-wrap:balance}\nh1{font-size:2.4rem;font-weight:700;text-transform:uppercase}\nh2{font-size:1.5rem;font-weight:600;text-transform:uppercase;margin-block:40px 12px;border-bottom:2px solid var(--accent);padding-bottom:4px}\nh3{font-size:1.2rem;font-weight:600}\n.lede{color:var(--muted);max-width:68ch;margin:8px 0 0}\n.mono{font:13px/1.45 var(--f-mono)}\n.ja{font-family:var(--f-ja);font-size:1.05rem}\n.state{font:13px var(--f-mono);color:var(--muted);margin-top:10px}\n.spk{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1.1fr);gap:16px;background:var(--panel);border:1px solid var(--line);\n  border-radius:6px;padding:16px;margin-bottom:12px}\n.spk .meta{display:grid;gap:6px;min-width:0}\n.k{font:600 .72rem var(--f-display);letter-spacing:.08em;text-transform:uppercase;color:var(--muted)}\n.chips{display:flex;flex-wrap:wrap;gap:6px}\n.chip{font:12px var(--f-mono);background:var(--chip);border-radius:3px;padding:2px 7px}\n.form{display:grid;gap:8px;min-width:0}\nselect,textarea,input[type=text]{width:100%;box-sizing:border-box;font:15px/1.45 var(--f-body);color:var(--ink);background:var(--field);\n  border:1px solid var(--line);border-radius:4px;padding:7px 9px}\ntextarea{resize:vertical;min-height:4.5em}\nbutton{font:600 .9rem var(--f-display);letter-spacing:.06em;text-transform:uppercase;background:var(--accent);color:var(--accent-ink);\n  border:0;border-radius:4px;padding:7px 14px;cursor:pointer;justify-self:start}\nbutton:disabled{opacity:.45;cursor:default}\n:focus-visible{outline:2px solid var(--accent);outline-offset:2px}\n.saved{font:12px var(--f-mono);color:var(--ok)}\n.scene-note{color:var(--muted);font-size:.9rem;margin:-4px 0 12px}\n.line{display:grid;grid-template-columns:256px minmax(0,1fr);gap:16px;padding-block:14px;border-bottom:1px solid var(--line)}\n.line img{width:256px;height:224px;image-rendering:pixelated;border-radius:3px;background:#000;max-width:100%}\n.line .txt{display:grid;gap:6px;min-width:0;align-content:start}\n.head{display:flex;flex-wrap:wrap;gap:8px 12px;align-items:baseline}\n.who{font:600 1.1rem var(--f-display);text-transform:uppercase;letter-spacing:.04em;color:var(--accent)}\n.en{font-size:1.15rem}\n.small{font-size:.9rem;color:var(--muted)}\naudio{width:100%;max-width:340px;height:34px}\ndetails{background:var(--panel);border:1px solid var(--line);border-radius:6px;padding:10px 14px}\nsummary{cursor:pointer;font:600 1rem var(--f-display);text-transform:uppercase;letter-spacing:.05em}\n.vgrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:6px 14px;margin-top:10px}\n.try{display:grid;gap:8px;margin-top:6px;padding-top:10px;border-top:1px dashed var(--line)}\n.snip{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:4px 8px;align-items:center}\n.snip p{grid-column:1/-1;margin:0;background:var(--field);border:1px solid var(--line);border-radius:4px;padding:6px 8px;white-space:pre-wrap;word-break:break-word}\nbutton.copy{background:var(--chip);color:var(--ink);padding:3px 10px;font-size:.78rem}\nnav.toc{display:flex;flex-wrap:wrap;gap:6px 14px;margin-top:14px;font:14px var(--f-display);text-transform:uppercase;letter-spacing:.05em}\nnav.toc a{color:var(--accent);text-decoration:none}\n@media (max-width:720px){.spk{grid-template-columns:minmax(0,1fr)}.line{grid-template-columns:minmax(0,1fr)}.line img{width:100%;height:auto;aspect-ratio:256/224}}\n@media (prefers-reduced-motion:no-preference){button{transition:opacity .15s}}\n</style>\n<div class="wrap">\n  <h1>Strider EX dub casting</h1>\n  <p class="lede">Every spoken line of the PC Engine cinematics, in scene order, with the picture on screen when it is spoken, the original Japanese performance, the approved English subtitle and what the voice will say. Pick a Gemini voice and write a direction for each speaker; add a note to any line that needs its own direction. Each Save is stored with this page, and the renders follow what you save here.</p>\n  <p class="state" id="state">Connecting to the casting store…</p>\n  <nav class="toc" id="toc"></nav>\n  <h2 id="speakers">Speakers</h2>\n  <p class="scene-note" id="scene-note"></p>\n  <div id="spk"></div>\n  <details><summary>The 30 Gemini voices (Google\'s own descriptions)</summary><div class="vgrid mono" id="vgrid"></div>\n    <p class="small">Google lists no genders. Every voice can be heard in Google\'s Text-to-Speech demo.</p></details>\n  <div id="scenes"></div>\n</div>\n<script>\nconst D=__DATA__;\nconst $=s=>document.querySelector(s);\nconst esc=s=>String(s??\'\').replace(/[&<>"\']/g,c=>({\'&\':\'&amp;\',\'<\':\'&lt;\',\'>\':\'&gt;\',\'"\':\'&quot;\',"\'":\'&#39;\'}[c]));\nconst slug=s=>s.replace(/[^A-Za-z0-9]+/g,\'_\');\nconst st={speakers:{},lines:{},db:null};\nconst voiceOpts=sel=>[\'<option value="">(keep the proposal)</option>\'].concat(D.voices.map(([n,d])=>`<option value="${n}"${n===sel?\' selected\':\'\'}>${n} — ${d}</option>`)).join(\'\');\nfunction spkHTML(s){\n  const r=st.speakers[slug(s.name)]||{};\n  return `<section class="spk" id="spk-${slug(s.name)}">\n   <div class="meta"><h3>${esc(s.name)}</h3><div class="small">${esc(s.role)} · ${s.lines} line${s.lines===1?\'\':\'s\'}</div>\n    <div><span class="k">Japanese voice (measured)</span><br>${esc(s.measured)}</div>\n    <div><span class="k">Profile</span><br>${esc(s.profile)}</div>\n    <div><span class="k">Proposed Gemini voices</span><div class="chips">${s.gemini.map(v=>`<span class="chip">${esc(v)}</span>`).join(\'\')}</div></div>\n    <div><span class="k">Proposed direction</span><br><span class="small">${esc(s.style)}</span></div>\n    ${s.post?`<div><span class="k">Post-processing</span><br><span class="small">${esc(s.post)}</span></div>`:\'\'}\n    <div class="try"><span class="k">Try it in Google\'s demo</span> <span class="small">(model Gemini 3.1 Flash TTS, your voice)</span>\n     <div class="snip"><span class="k">Style instructions</span><button type="button" class="copy" data-copy="st-${slug(s.name)}">Copy</button>\n      <p class="mono" id="st-${slug(s.name)}">${esc(D.scene+\' \'+(r.direction||s.style))}</p></div>\n     <div class="snip"><span class="k">Text to speak</span><button type="button" class="copy" data-copy="tx-${slug(s.name)}">Copy</button>\n      <p class="mono" id="tx-${slug(s.name)}">${esc(s.sample)}</p></div></div></div>\n   <form class="form" data-spk="${esc(s.name)}">\n    <label class="k" for="v-${slug(s.name)}">Your voice</label>\n    <select id="v-${slug(s.name)}">${voiceOpts(r.voice||\'\')}</select>\n    <label class="k" for="d-${slug(s.name)}">Your direction (leave empty to keep the proposal)</label>\n    <textarea id="d-${slug(s.name)}">${esc(r.direction||\'\')}</textarea>\n    <button type="submit">Save speaker</button><span class="saved">${r.at?\'Saved \'+new Date(r.at).toLocaleString():\'\'}</span>\n   </form></section>`}\nfunction lineHTML(l){\n  const r=st.lines[slug(l.id)]||{};\n  const fitBits=[l.rate&&l.rate!==1?`speak at ${Math.round(l.rate*100)}%`:\'\',l.shift?`starts ${l.shift.toFixed(2)} s after the Japanese`:\'\'].filter(Boolean).join(\' · \');\n  return `<article class="line" id="L-${slug(l.id)}">\n   <img src="${l.img}" alt="${esc(D.titles[l.scene])} at ${l.start.toFixed(1)} s" width="256" height="224" loading="lazy">\n   <div class="txt">\n    <div class="head"><span class="who">${esc(l.speaker)}</span><span class="mono">${esc(l.id)} · ${l.start.toFixed(2)}–${l.end.toFixed(2)} s (${(l.end-l.start).toFixed(1)} s)</span></div>\n    <div class="ja" lang="ja">${esc(l.ja)}</div>\n    <div class="en">${esc(l.en)}</div>\n    ${l.plain&&l.plain!==l.en?`<div class="small"><span class="k">Spoken as</span> ${esc(l.plain)}</div>`:\'\'}\n    ${l.direction?`<div class="small"><span class="k">Planned direction</span> ${esc(l.direction)}</div>`:\'\'}\n    ${fitBits?`<div class="small"><span class="k">Timing</span> ${esc(fitBits)}</div>`:\'\'}\n    <div><span class="k">Japanese original</span><br><audio controls preload="none" src="${l.audio}"></audio></div>\n    <form class="form" data-line="${esc(l.id)}">\n     <label class="k" for="n-${slug(l.id)}">Line note (direction for this line only)</label>\n     <input type="text" id="n-${slug(l.id)}" value="${esc(r.note||\'\')}" placeholder="e.g. louder, slower, a sneer on \'Strider\'">\n     <button type="submit">Save line</button><span class="saved">${r.at?\'Saved\':\'\'}</span>\n    </form></div></article>`}\nfunction render(){\n  $(\'#scene-note\').textContent=\'Every line is sent with this scene note: \'+D.scene+\' Model: \'+D.model+\'.\';\n  $(\'#spk\').innerHTML=D.speakers.map(spkHTML).join(\'\');\n  $(\'#vgrid\').innerHTML=D.voices.map(([n,d])=>`<div><b>${n}</b> ${d}</div>`).join(\'\');\n  const by={};D.lines.forEach(l=>(by[l.scene]??=[]).push(l));\n  $(\'#toc\').innerHTML=\'<a href="#speakers">Speakers</a>\'+Object.keys(by).map(s=>`<a href="#S-${s}">${esc(D.titles[s])}</a>`).join(\'\');\n  $(\'#scenes\').innerHTML=Object.entries(by).map(([s,ls])=>`<h2 id="S-${s}">${esc(D.titles[s])}</h2>${ls.map(lineHTML).join(\'\')}`).join(\'\');\n  document.querySelectorAll(\'button[type=submit]\').forEach(b=>b.disabled=!st.db);\n}\nfunction redraw(coll,id){\n  if(coll===\'speakers\'){const s=D.speakers.find(x=>slug(x.name)===id);const old=document.getElementById(\'spk-\'+id);\n    if(s&&old)old.outerHTML=spkHTML(s)}\n  else{const l=D.lines.find(x=>slug(x.id)===id);const old=document.getElementById(\'L-\'+id);if(l&&old)old.outerHTML=lineHTML(l)}\n  document.querySelectorAll(\'button[type=submit]\').forEach(b=>b.disabled=!st.db)}\nconst typing=()=>{const a=document.activeElement;return a&&(a.tagName===\'TEXTAREA\'||a.tagName===\'SELECT\'||(a.tagName===\'INPUT\'&&a.type===\'text\'))};\nasync function save(coll,id,body){\n  const el=$(\'#state\');\n  try{const rec={...body,at:new Date().toISOString()};await st.db.collection(coll).doc(id).set(rec);\n    st[coll]={...st[coll],[id]:rec};el.textContent=\'Saved.\';redraw(coll,id)}\n  catch(e){el.textContent=\'Could not save: \'+(e&&e.message||\'unknown error\')+\'. Try again in a moment.\'}}\ndocument.addEventListener(\'click\',async e=>{\n  const b=e.target.closest(\'button.copy\');if(!b)return;\n  const el=document.getElementById(b.dataset.copy);\n  try{await navigator.clipboard.writeText(el.textContent);b.textContent=\'Copied\'}\n  catch{const r=document.createRange();r.selectNodeContents(el);const s=getSelection();s.removeAllRanges();s.addRange(r);b.textContent=\'Selected: press Copy\'}\n  setTimeout(()=>b.textContent=\'Copy\',1600)});\ndocument.addEventListener(\'submit\',e=>{\n  e.preventDefault();if(!st.db)return;\n  const f=e.target;\n  if(f.dataset.spk){const n=f.dataset.spk;save(\'speakers\',slug(n),{speaker:n,voice:$(\'#v-\'+slug(n)).value,direction:$(\'#d-\'+slug(n)).value.trim()})}\n  else if(f.dataset.line){const id=f.dataset.line;save(\'lines\',slug(id),{line:id,note:$(\'#n-\'+slug(id)).value.trim()})}\n});\nrender();\n(async()=>{\n  const db=await window.claude?.use?.(\'db\').catch(()=>null);\n  if(!db){$(\'#state\').textContent=\'The casting store is not available in this view. Open the page in claude.ai to save picks.\';return}\n  st.db=db;$(\'#state\').textContent=\'Your picks save to this page when you press Save.\';\n  const sub=(coll)=>db.collection(coll).onSnapshot(s=>{const m={};s.docs.forEach(d=>{m[d.id]={...d.data()}});\n    const changed=JSON.stringify(m)!==JSON.stringify(st[coll]);st[coll]=m;if(changed&&!typing())render();},\n    e=>{$(\'#state\').textContent=\'Lost the connection to the casting store (\'+e.code+\'). Reload to reconnect.\'});\n  sub(\'speakers\');sub(\'lines\');render();\n})();\n</script>\n'

def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('--census', type=Path, required=True)
    p.add_argument('--out', type=Path, required=True)
    a = p.parse_args()
    lines, speakers, gem = collect(a.census)
    a.out.parent.mkdir(parents=True, exist_ok=True)
    a.out.write_text(page(lines, speakers, gem))
    print(a.out, a.out.stat().st_size)
    return 0
if __name__ == '__main__':
    sys.exit(main())
