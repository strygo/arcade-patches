"""Qualify the lower Earth tip during the early ending jump in both regions."""
import argparse
from concurrent.futures import ThreadPoolExecutor
from copy import deepcopy
import json
from pathlib import Path
import subprocess
import sys
from types import SimpleNamespace
import numpy as np
from PIL import Image, ImageDraw
import earth_tip as E
import earth_tile as ET
import earth_tile_gate as TG
import earth_gate as EG
import earth_render_probe as ER
import mapper_testkit as K
import respawn_fix as RF
import title_ex as T
ROOT = Path(__file__).resolve().parents[3]
FRAME = 1100
SHOTS = list(range(1000, 1131, 10))
CELLS = (55152, 55216)

def xy(cell, regs):
    index = (cell - 49152) // 4
    col = index >> 4 & 63
    row = index & 15 | index >> 6 & 48
    return ((16 * col - 64 - regs[8388880]) % 1024, (16 * row - 16 - regs[8388882]) % 1024)

def expected_frame(before, vram, regs, old_tiles, new_tiles, rgb):
    expected = before.copy()
    occluded = 0
    for cell, old, new in zip(CELLS, old_tiles, new_tiles):
        x, y = xy(cell, regs)
        for ty in range(16):
            for tx in range(16):
                if x + tx >= 384 or y + ty >= 224:
                    continue

                def color(pen):
                    if pen == 15:
                        return (0, 0, 0)
                    return rgb(int.from_bytes(vram[84352 + 2 * int(pen):84354 + 2 * int(pen)], 'big'))
                a, b = (color(old[ty, tx]), color(new[ty, tx]))
                if a == b:
                    continue
                if tuple(before[y + ty, x + tx]) != a:
                    occluded += 1
                    continue
                expected[y + ty, x + tx] = b
    return (expected, occluded)

def exact_candidate(old, new, stock):
    for machine, files in old.items():
        wanted = dict(files)
        region = ET.join_graphics(files)
        E.install(region, stock)
        wanted.update(zip(ET.GFX_FILES, E.G.split_region(region)))
        image = RF.compose(files, RF.SETS[machine])
        E.patch(image, machine)
        wanted.update(RF.decompose(image, RF.SETS[machine], {n: len(files[n]) for n, _, _ in RF.SETS[machine]}))
        if wanted != new[machine]:
            raise ValueError('change outside the exact lower-tip repair')

def runtime(a):
    work = a.workdir.resolve()
    work.mkdir(parents=True, exist_ok=False)
    paths = dict(control=a.control.resolve(), build=a.build.resolve())
    inventories = {k: TG.inventory(v) for k, v in paths.items()}
    stock = T.stock_gfx(K.pool([a.rom_dir / 'striderua', a.rom_dir / 'strider']))
    old_tiles = [T.stock_tile(stock, c, 'scr2') for c in (13573, 13581)]
    new_tiles = E.tiles(stock)
    exact_candidate(inventories['control'][1], inventories['build'][1], stock)
    studies = {}
    for label, path in paths.items():
        meta, members = inventories[label]
        meta = deepcopy(meta)
        source = work / (label + '_source')
        source.mkdir()
        for machine, files in members.items():
            meta['sets'][machine]['stage_select_syms'] = EG.stage_symbols(files, machine)
            (source / machine).symlink_to(path / machine, target_is_directory=True)
        (source / 'build.json').write_text(json.dumps(meta, indent=2) + '\n')
        studies[label] = work / (label + '_study')
        EG.J.cmd_study(SimpleNamespace(build=source, rom_dir=a.rom_dir, out=studies[label], start_stage=None, stage_select_tour=False, stage_select_pick=6))
    rt = json.loads((a.runtime / 'runtime.json').read_text())
    if E.sha(Path(rt['binary']).read_bytes()) != rt['binary_sha256']:
        raise ValueError('runtime changed')

    def one(key):
        label, name, flag = key
        out = work / f'{label}_{name}_{flag}'
        cmd = [sys.executable, str(ROOT / 'backports/striderex/rtl/jtcps1_sim.py'), 'hbref', '--build', str(studies[label]), '--runtime', str(a.runtime), '--hbmame', str(a.hbmame), '--rom-dir', str(a.rom_dir), '--out', str(out), '--set', name, '--flag', str(flag), '--frames', '1200', '--shots', '1000-1130/10', '--memdump', str(FRAME)]
        with (work / (out.name + '.log')).open('w') as f:
            r = subprocess.run(cmd, stdout=f, stderr=subprocess.STDOUT)
        if r.returncode:
            raise ValueError('capture failed: ' + out.name)
        print('captured', out.name, flush=True)
        return (key, out)
    jobs = [(label, name, flag) for label in paths for name in TG.NAMES for flag in (0, 1)]
    with ThreadPoolExecutor(a.jobs) as pool:
        runs = dict(pool.map(one, jobs))
    rows = []
    for name, machine in TG.NAMES.items():
        for flag in (0, 1):
            old, new = [runs[label, name, flag] for label in paths]
            before, after = [(p / f'vram_{FRAME:05d}.bin').read_bytes() for p in (old, new)]
            diff = {i for i, (x, y) in enumerate(zip(before, after)) if x != y}
            pictures = []
            for frame in SHOTS:
                x, y = [np.array(Image.open(p / f'f_{frame:05d}.png').convert('RGB')) for p in (old, new)]
                changed = np.any(x != y, axis=2)
                allowed = np.zeros(changed.shape, dtype=bool)
                regs = ER.registers(old, frame)
                for cell in CELLS:
                    cx, cy = xy(cell, regs)
                    if cx < 384 and cy < 224:
                        allowed[cy:min(cy + 16, 224), cx:min(cx + 16, 384)] = True
                expected, occluded = expected_frame(x, after, regs, old_tiles, new_tiles, T.mame_rgb)
                pictures.append(dict(frame=frame, changed_pixels=int(changed.sum()), only_tip_cells_changed=not bool(np.any(changed & ~allowed)), exact_visible_pixels=bool(np.array_equal(y, expected)), occluded_repair_pixels=occluded))
            checks = dict(frame_flow_identical=(old / 'frames.tsv').read_bytes() == (new / 'frames.tsv').read_bytes(), registers_and_sound_identical=(old / 'regs.tsv').read_bytes() == (new / 'regs.tsv').read_bytes(), only_two_vram_map_words_changed=diff == {c + i for c in CELLS for i in (0, 1)}, correct_map_references=all((before[c:c + 2] == code.to_bytes(2, 'big') and after[c:c + 2] == newcode.to_bytes(2, 'big') for c, code, newcode in zip(CELLS, (13573, 13581), E.CODES))), exact_visible_pixels=all((p['exact_visible_pixels'] for p in pictures)), only_tip_cells_changed=all((p['only_tip_cells_changed'] for p in pictures)), old_defect_rejected=next((p for p in pictures if p['frame'] == FRAME))['changed_pixels'] > 0)
            rows.append(dict(set=name, machine=machine, flag=flag, checks=checks, pictures=pictures, control_vram_sha256=E.sha(before), build_vram_sha256=E.sha(after), exit_codes=[0, 0], passed=all(checks.values())))
    report = dict(schema='striderex-earth-tip-runtime/1', passed=all((r['passed'] for r in rows)), reference_frame=FRAME, control_files={m: s['files'] for m, s in inventories['control'][0]['sets'].items()}, build_files={m: s['files'] for m, s in inventories['build'][0]['sets'].items()}, runtime={k: rt[k] for k in ('binary_sha256', 'board_wait', 'source_revision')}, results=rows, hardware_review_granted=False)
    (work / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
    for r in rows:
        print('PASS' if r['passed'] else 'FAIL', r['set'], r['flag'], r['checks'])
    if not report['passed']:
        raise ValueError('lower Earth tip runtime check failed')

def render(a):
    stock = T.stock_gfx(K.pool([a.rom_dir / 'striderua', a.rom_dir / 'strider']))
    old_tiles = [T.stock_tile(stock, c, 'scr2') for c in (13573, 13581)]
    new_tiles = E.tiles(stock)
    runtime_report = json.loads(a.runtime_report.read_text())
    rows = []
    if not runtime_report['passed']:
        raise ValueError('runtime failed')
    for old, new, capture in zip(a.control, a.build, a.capture):
        receipts = [json.loads((p / 'render.json').read_text()) for p in (old, new)]
        machine = receipts[0]['machine']
        row = next((r for r in runtime_report['results'] if r['machine'] == machine and r['flag'] == 0))
        for label, r in zip(('control', 'build'), receipts):
            if not r['passed'] or r['build_files'] != runtime_report[label + '_files'] or r['vram_sha256'] != row[label + '_vram_sha256'] or (r['frame'] != FRAME):
                raise ValueError('render used different inputs')
        if any((receipts[0][k] != receipts[1][k] for k in ('machine', 'registers_sha256', 'model_sha256', 'harness_sha256'))):
            raise ValueError('render pair mismatch')
        ims = [Image.open(p / 'render/f_00035.png').convert('RGB') for p in (old, new)]
        for p, r in zip((old, new), receipts):
            if E.sha((p / 'render/f_00035.png').read_bytes()) != r['image_sha256']:
                raise ValueError('render image changed')
        lut = np.array([int(v, 16) for v in np.loadtxt(new / 'render/pal_lut.hex', dtype=str).flat]).reshape(16, 16)
        rgb = lambda w: tuple((int(lut[w >> 12, w >> s & 15]) for s in (8, 4, 0)))
        before, after = map(np.array, ims)
        expected, occluded = expected_frame(before, (capture / f'vram_{FRAME:05d}.bin').read_bytes(), ER.registers(capture, FRAME), old_tiles, new_tiles, rgb)
        count = int(np.any(before != after, axis=2).sum())
        passed = bool(np.array_equal(after, expected) and count > 0)
        rows.append(dict(machine=machine, control=receipts[0], build=receipts[1], changed_pixels=count, exact_visible_pixels=bool(np.array_equal(after, expected)), old_defect_rejected=count > 0, occluded_repair_pixels=occluded, passed=passed))
        if a.review and machine == 'striderua':
            a.review.mkdir(parents=True, exist_ok=True)
            for label, im in zip(('before', 'after'), ims):
                im.save(a.review / f'earth-tip-{label}.png')
            canvas = Image.new('RGB', (1024, 288), (24, 24, 24))
            draw = ImageDraw.Draw(canvas)
            for i, (label, im) in enumerate(zip(('Before: displaced original strip', 'After: original strip moved right 9 px'), ims)):
                draw.text((i * 512 + 12, 8), label, fill='white')
                canvas.paste(im.crop((296, 192, 344, 224)).resize((384, 256), Image.Resampling.NEAREST), (i * 512 + 64, 32))
            canvas.save(a.review / 'earth-tip-before-after.png')
    report = dict(schema='striderex-earth-tip-render/1', passed={r['machine'] for r in rows} == set(RF.SETS) and all((r['passed'] for r in rows)), results=rows)
    a.receipt.write_text(json.dumps(report, indent=2) + '\n')
    if not report['passed']:
        raise ValueError('lower Earth tip core render failed')
    print('PASS: exact lower-tip pixels in both regional core renders')

def main():
    p = argparse.ArgumentParser(description=__doc__)
    sub = p.add_subparsers(dest='mode', required=True)
    r = sub.add_parser('runtime')
    for n in ('build', 'control', 'rom-dir', 'runtime', 'hbmame', 'workdir'):
        r.add_argument('--' + n, type=Path, required=True)
    r.add_argument('--jobs', type=int, default=3)
    r = sub.add_parser('render')
    for n in ('control', 'build', 'capture'):
        r.add_argument('--' + n, type=Path, action='append', required=True)
    for n in ('rom-dir', 'runtime-report', 'receipt'):
        r.add_argument('--' + n, type=Path, required=True)
    r.add_argument('--review', type=Path)
    a = p.parse_args()
    a.rom_dir = a.rom_dir.resolve()
    if a.mode == 'runtime':
        runtime(a)
    else:
        if any((len(v) != 2 for v in (a.control, a.build, a.capture))):
            raise ValueError('both regional pairs required')
        render(a)
if __name__ == '__main__':
    main()
