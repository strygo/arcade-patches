"""Compare all regional clear screens and the exact deployed CPS+ fanfare."""
import argparse
from concurrent.futures import ThreadPoolExecutor
from copy import deepcopy
import csv
import json
import math
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import zipfile
import numpy as np
from PIL import Image, ImageChops
import clear_music_timing as M
import desert_gate as G
import respawn_fix as R
import pack_model as PM
from boss_voice_gate import inventory, sha
from cpsplus.pack import audition
ROOT = Path(__file__).resolve().parents[3]
LUA = ROOT / 'backports/striderex/lua/clear_music_timing.lua'
STUDY = LUA.with_name('stage_clear_study.lua')
MOON = LUA.with_name('third_moon_study.lua')
RUNNER = Path(__file__).with_name('stage_clear_study.py')
sys.path.insert(0, str(ROOT / 'release'))
import private_mister as PRIVATE
SETS = {'striderua': 'striderus01', 'striderjr': 'striderjs01'}
PLANS = {0: (7, None, '450-5800@6/3:P1_BUTTON1'), 1: (1, 1800, '1790-1850:P1_BUTTON2'), 2: (1, 1800, ''), 3: (6, 1800, ''), 4: (10, None, '450-1400@6/3:P1_BUTTON1'), 5: (5, 1800, '')}
PACK_SHA = '02aa41624d55e2aa135cdfad399987ba489d2f693fa9c8c1a51caf4105ff8aa6'

def rows(path):
    with path.open() as f:
        return list(csv.DictReader(f, delimiter='\t'))

def pack_check(kit, out):
    """Extract from a verified declared export; never a cache in another work tree."""
    receipt = PRIVATE.verify(kit)
    with PRIVATE.qualified_view(kit) as view:
        producer = json.loads((view / 'producer.json').read_text())
        archives = [n for n in producer['archives'] if n.endswith('/strider_ex.zip')]
        if len(archives) != 1:
            raise ValueError('unique declared audio archive required')
        with zipfile.ZipFile(view / archives[0]) as z:
            names = [n for n in z.namelist() if n.endswith('.cpk')]
            if len(names) != 1:
                raise ValueError('unique declared CPS+ pack required')
            data = z.read(names[0])
    if sha(data) != PACK_SHA:
        raise ValueError('timing must be requalified against this changed audio pack')
    out.write_bytes(data)
    model = PM.Model(out)
    verb, track, control = model.classify(15)
    if (verb, track, control) != (1, 2, False):
        raise ValueError('regular clear cue no longer plays expected fanfare')
    meta = model.tracks[track]
    pcm = audition._decode_track(model.rd, track)
    samples = np.frombuffer(pcm, dtype='<i2').reshape(-1, meta.channels).astype(float) / 32768
    if meta.loops:
        raise ValueError('clear fanfare must be a one-shot')
    w = round(meta.sample_rate * 0.02)
    rms = [max(np.sqrt(np.mean(samples[i:i + w] ** 2, axis=0))) for i in range(0, len(samples), w)]
    audible = {}
    for db in (-45, -50, -55, -60):
        present = [i for i, v in enumerate(rms) if v > 10 ** (db / 20)]
        audible[str(db)] = min(len(samples) / meta.sample_rate, (max(present) + 1) * w / meta.sample_rate)
    return (model, dict(pack_sha256=PACK_SHA, source_test_id=receipt['test_id'], export_manifest_sha256=sha((kit / 'private-mister.json').read_bytes()), cue=15, track=track, sample_rate=meta.sample_rate, channels=meta.channels, decoded_samples=len(samples), seconds=len(samples) / meta.sample_rate, audible_end_seconds_by_dbfs=audible))

def sound(path):
    return [(int(f), int(v, 16)) for f, kind, v in (line.split('\t') for line in (path / 'debug_log.tsv').read_text().splitlines()[1:]) if kind == 'sound']

def same_picture(a, b):
    return ImageChops.difference(Image.open(a).convert('RGB'), Image.open(b).convert('RGB')).getbbox() is None

def compare(old, new, machine, stage, pack, audio, glyphs, model):
    reports = [json.loads((d / 'report.json').read_text()) for d in (old, new)]
    if not all((r['completed'] for r in reports)) or reports[0]['clear_frame'] != reports[1]['clear_frame']:
        raise ValueError('paired clear runs incomplete or different defeat clocks')
    a, b = [rows(d / 'frames.tsv') for d in (old, new)]
    ca, cb = [rows(d / 'clear_music.tsv') for d in (old, new)]
    sa, sb = [sound(d) for d in (old, new)]
    if any((int(r['pack']) != int(pack) for r in cb)):
        raise ValueError('runtime pack option differs')
    clear = reports[1]['clear_frame']
    result = dict(machine=machine, stage=stage, pack=pack, natural_defeat=PLANS[stage][1] is None, clear_frame=clear, passed=True)
    keys = ('mode', 'stage', 'state', 'sub', 'x', 'y', 'camx', 'camy', 'layer', 'entries', 'hiryu_entries', 'active', 'palette')
    if not pack or stage == 4:
        if len(a) != len(b) or any((any((x[k] != y[k] for k in keys)) for x, y in zip(a, b))) or ca != cb or (sa != sb):
            raise ValueError('native clear or Third Moon timing/state/sound changed')
        pics = list(old.glob('s_*.png'))
        if not pics or any((not (new / p.name).exists() or not same_picture(p, new / p.name) for p in pics)):
            raise ValueError('native clear or Third Moon pixels changed')
        if stage == 4 and (old / 'moon_events.tsv').read_bytes() != (new / 'moon_events.tsv').read_bytes():
            raise ValueError('ending phase clocks changed')
        result.update(native_timing_state_and_sound_exact=True, pictures_exact=len(pics))
    else:
        delta = M.PACK_FRAMES - M.NATIVE_FRAMES
        exit_a, exit_b = [next((int(r['frame']) for r in rr if int(r['frame']) > clear and r['mode'] == '2')) for rr in (a, b)]
        hold_a, hold_b = [next((int(r['frame']) for r in rr if int(r['frame']) > clear and r['active'] == '1' and (r['phase'] == '1') and (int(r['timer']) >= 190))) for rr in (ca, cb)]
        if hold_a != hold_b or int(ca[hold_a - 1]['timer']) != M.NATIVE_FRAMES or int(cb[hold_b - 1]['timer']) != M.PACK_FRAMES:
            raise ValueError('bonus hold timer was not installed correctly')
        fade_a, fade_b = [next((int(r['frame']) for r in rr if int(r['frame']) > hold_a and r['tail'] == '1')) for rr in (ca, cb)]
        if exit_b - exit_a != delta or fade_b - fade_a != delta:
            raise ValueError('CPS+ hold changed fade length or handoff duration')
        if any((any((x[k] != y[k] for k in keys)) for x, y in zip(a[:hold_a], b[:hold_a]))):
            raise ValueError('outgoing clear presentation changed')
        if [x for x in sa if x[0] <= hold_a] != [x for x in sb if x[0] <= hold_a]:
            raise ValueError('fanfare entry sound clock changed')
        held_score = ca[hold_a - 1]['score']
        if ca[exit_a - 1]['score'] != cb[exit_b - 1]['score'] or any((r['score'] != held_score for r in cb if hold_b <= int(r['frame']) < fade_b)):
            raise ValueError('clear score changed or was awarded again during the hold')
        matched = min(len(a) - fade_a + 1, len(b) - fade_b + 1)
        for i in range(matched):
            x, y = (a[fade_a - 1 + i], b[fade_b - 1 + i])
            if any((x[k] != y[k] for k in keys)):
                raise ValueError('clear fade/next-briefing state differs after time alignment')
            if ca[fade_a - 1 + i]['score'] != cb[fade_b - 1 + i]['score']:
                raise ValueError('bonus score award changed after time alignment')
        next_a = [(f, v) for f, v in sa if f > hold_a]
        next_b = [(f - delta, v) for f, v in sb if f > hold_b]
        common_end = min(len(a), len(b) - delta)
        if [(f, v) for f, v in next_a if f < common_end] != [(f, v) for f, v in next_b if f < common_end]:
            raise ValueError('post-clear sound stream differs after time alignment')
        cue = next((f for f, v in sb if f > clear and v == 15))
        cue_end = cue + math.ceil(audio['seconds'] * PM.CPS1_HZ)
        if fade_b < cue_end or exit_b < cue_end:
            raise ValueError('CPS+ clear still fades before the complete fanfare ends')
        events, _ = model.run(sb)
        if not any((f == cue and t == audio['track'] and (effect == 'start') for f, v, verb, t, effect in events)):
            raise ValueError('clear cue did not start its own pack track')
        if any((cue < f < cue_end and effect in ('start', 'stop', 'fade') for f, v, verb, t, effect in events)):
            raise ValueError('clear fanfare interrupted by a later pack command')
        if exit_a - cue >= math.ceil(audio['seconds'] * PM.CPS1_HZ):
            raise ValueError('old-ROM control did not reproduce the early exit')
        detail = rows(new / 'sprites.tsv')
        number = (1, 3, 5, 4, 6, 2)[stage]
        expected = [28672 + glyphs[ord(c)] for c in f'STAGE {number} CLEAR BONUS']
        if not any(([int(v, 16) for v in r['bonus_label'].split(',')] == expected and r['player_object'].split(',')[9] == '1662' for r in detail if hold_b + 25 <= int(r['frame']) <= hold_b + 40)):
            raise ValueError('numbered label or standing bonus pose missing')
        dark = [p for p in new.glob('s_*.png') if exit_b - 5 <= int(p.stem[2:]) < exit_b and Image.open(p).convert('RGB').getbbox() is None]
        if not dark:
            raise ValueError('bonus screen was not completely black before removal')
        pics = 0
        for p in old.glob('s_*.png'):
            f = int(p.stem[2:])
            shifted = f if f < fade_a else f + delta
            q = new / f's_{shifted:05d}.png'
            if q.exists() and (f < hold_a + 30 or f >= fade_a):
                if not same_picture(p, q):
                    raise ValueError('clear or aligned fade image changed')
                pics += 1
        result.update(added_frames=delta, hold_start=hold_b, old_exit=exit_a, new_exit=exit_b, cue_frame=cue, cue_end_frame=cue_end, fade_start=fade_b, fade_seconds_after_cue=(fade_b - cue) / PM.CPS1_HZ, exit_seconds_after_cue=(exit_b - cue) / PM.CPS1_HZ, aligned_tail_frames_exact=matched, pictures_exact=pics, score_exact=True, full_pack_track_finishes_before_picture_fade=True, label_pose_and_final_black_verified=True)
    result['traces'] = {label: {n: sha((d / n).read_bytes()) for n in ('frames.tsv', 'clear_music.tsv', 'debug_log.tsv')} for label, d in (('control', old), ('candidate', new))}
    return result

def main():
    p = argparse.ArgumentParser(description=__doc__)
    for n in ('control', 'build', 'audio-kit', 'runtime', 'hbmame', 'rom-dir', 'vasm', 'workdir', 'receipt'):
        p.add_argument('--' + n, type=Path, required=True)
    p.add_argument('--reuse', action='store_true')
    a = p.parse_args()
    M.audit(a.control, a.build)
    work = a.workdir.resolve()
    work.mkdir(parents=True, exist_ok=a.reuse)
    model, audio = pack_check(a.audio_kit.resolve(), work / 'fanfare.cpk')
    rt = json.loads((a.runtime / 'runtime.json').read_text())
    binary = Path(rt['binary'])
    if sha(binary.read_bytes()) != rt['binary_sha256'] or not rt['board_wait']:
        raise ValueError('matching prepared conservative board-wait runtime required')
    metas, inputs, sets = ({}, {}, {})
    glyphs = None
    for label, build in (('control', a.control), ('candidate', a.build)):
        meta, files = inventory(build)
        metas[label] = meta
        if glyphs is None:
            glyphs = R.compose(files['striderua'], R.SETS['striderua'])[14470:14598]
        for machine, setname in SETS.items():
            for pack in (False, True):
                key = f'{label}_{machine}_{int(pack)}'
                variant = work / 'variants' / key
                expected = dict(files[machine])
                raw = bytearray(expected['strex_p6.bin'])
                raw[-2] = raw[-2] & 254 | int(pack)
                expected['strex_p6.bin'] = bytes(raw)
                if not variant.exists():
                    d = variant / machine
                    d.mkdir(parents=True)
                    vm = deepcopy(meta)
                    vm['sets'] = {machine: dict(meta['sets'][machine], files={n: sha(b) for n, b in expected.items()})}
                    for n, data in expected.items():
                        (d / n).write_bytes(data)
                    (variant / 'build.json').write_text(json.dumps(vm, indent=2) + '\n')
                vm, vf = inventory(variant)
                if vf != {machine: expected}:
                    raise ValueError('audio variant differs outside its single declared pack bit')
                inputs[key] = vm['sets'][machine]['files']
                roms = G.stage_sets(variant, setname, a.hbmame, a.rom_dir.resolve(), work / 'sets' / key)
                have = {sha(q.read_bytes()) for q in (roms / setname).iterdir() if q.is_file()}
                if any((digest not in have for digest in inputs[key].values())):
                    raise ValueError('staged variant is missing a declared final ROM')
                sets[label, machine, pack] = (roms, setname)
    jobs = [(label, machine, pack, stage) for label in ('control', 'candidate') for machine in SETS for pack in (False, True) for stage in PLANS]

    def run(job):
        label, machine, pack, stage = job
        roms, setname = sets[label, machine, pack]
        out = work / f'run_{label}_{machine}_{int(pack)}_{stage}'
        if not (a.reuse and (out / 'report.json').exists()):
            area, force, presses = PLANS[stage]
            cmd = [sys.executable, str(RUNNER), '--mame', str(binary), '--rompath', str(roms), '--machine', setname, '--stage', str(stage), '--area', str(area), '--frames', '6000', '--after-clear', str(1400 if stage == 4 else 1000), '--inputs', presses, '--out', str(out)]
            if force:
                cmd += ['--clear-at', str(force)]
            if stage == 4:
                cmd += ['--invincible-end', '1420']
            env = dict(os.environ, STUDY_EXTENSION=str(LUA))
            if stage == 4:
                env['CLEAR_MUSIC_MOON_LUA'] = str(MOON)
            else:
                env.pop('CLEAR_MUSIC_MOON_LUA', None)
            r = subprocess.run(cmd, env=env, capture_output=True, text=True)
            if r.returncode:
                raise ValueError(str(out) + ': failed ' + r.stdout[-500:] + r.stderr[-1000:])
        report = json.loads((out / 'report.json').read_text())
        current = __import__('stage_clear_study').input_inventory(roms, setname)
        if not report['completed'] or report['rom_inputs'] != current or report['runtime_sha256'] != rt['binary_sha256']:
            raise ValueError('incomplete/stale clear run')
        print('captured', *job, flush=True)
        return out
    with ThreadPoolExecutor(2) as pool:
        outputs = dict(zip(jobs, pool.map(run, jobs)))
    checks = []
    for machine in SETS:
        for pack in (False, True):
            for stage in PLANS:
                result = compare(*(outputs[label, machine, pack, stage] for label in ('control', 'candidate')), machine, stage, pack, audio, glyphs, model)
                checks.append(result)
                print('PASS', machine, pack, stage, flush=True)
    fresh = work / 'fresh'
    if not fresh.exists():
        subprocess.run([sys.executable, str(Path(M.__file__)), '--build', str(a.control), '--vasm', str(a.vasm), '--out', str(fresh)], check=True)
    fm, ff = inventory(fresh)
    bm, bf = inventory(a.build)
    if fm != bm or ff != bf:
        raise ValueError('fresh empty output differs')
    damages = []
    for machine in SETS:
        sites = M.model(R.compose(inventory(a.control)[1][machine], R.SETS[machine]))
        for kind, member, address in [('timer_hook_' + str(i), 'program', at) for i, at in enumerate(sites)] + [('pack_flag_test', 'bank', M.BASE + 6), ('pack_duration', 'bank', M.BASE + 18), ('third_moon_timer', 'program', sites[0] - 48816 + 49792)]:
            with tempfile.TemporaryDirectory(dir=work, prefix='damage-') as tmp:
                root = Path(tmp)
                dm = deepcopy(bm)
                for m, files in bf.items():
                    f = dict(files)
                    if m == machine:
                        if member == 'bank':
                            b = bytearray(f['strex_p6.bin'])
                            b[address - 1048576 ^ 1] ^= 1
                            f['strex_p6.bin'] = bytes(b)
                        else:
                            b = bytearray(R.compose(f, R.SETS[m]))
                            b[address] ^= 1
                            f.update(R.decompose(bytes(b), R.SETS[m], {n: len(f[n]) for n, _, _ in R.SETS[m]}))
                    d = root / m
                    d.mkdir()
                    for n, b in f.items():
                        (d / n).write_bytes(b)
                    dm['sets'][m]['files'] = {n: sha(b) for n, b in f.items()}
                (root / 'build.json').write_text(json.dumps(dm) + '\n')
                try:
                    M.audit(a.control, root)
                except ValueError:
                    damages.append(dict(machine=machine, kind=kind, inventory_rehashed=True, rejected=True))
                else:
                    raise ValueError('rehashed clear timing damage accepted')
    sources = (Path(__file__), Path(M.__file__), M.ASM, LUA, STUDY, MOON, RUNNER, Path(PM.__file__), Path(G.__file__), G.DEBUG_START)
    report = dict(schema='striderex-clear-music-timing-gate/1', passed=True, checks=checks, audio=audio, option_variant_inputs=inputs, inputs={label: {m: s['files'] for m, s in meta['sets'].items()} for label, meta in metas.items()}, runtime={k: rt[k] for k in ('binary_sha256', 'source_revision', 'board_wait')}, fresh_empty_output_roms_and_metadata_exact=True, rehashed_damage_controls=damages, assembler_sha256=sha(a.vasm.read_bytes()), source_sha256={str(q.relative_to(ROOT)): sha(q.read_bytes()) for q in sources}, hardware_review_granted=False)
    a.receipt.parent.mkdir(parents=True, exist_ok=True)
    a.receipt.write_text(json.dumps(report, indent=2) + '\n')
    print('All 24 paired regional/audio/stage checks PASS; fresh output exact', flush=True)
if __name__ == '__main__':
    main()
