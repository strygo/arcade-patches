"""Render approved boss lines into the durable, non-deterministic take store."""
import argparse
import io
import json
from pathlib import Path
import wave
import dub_store as DS
import dub_tts as DT
MANIFEST = Path(__file__).resolve().parents[1] / 'manifests/portrait_text_review.json'
CAST = {'stp_strongman': ('Charon', 'A huge rough male bruiser, impatient and threatening. Enjoy the challenge.'), 'stp_chairman': ('Zubenelgenubi', 'An older male council chairman, fanatical and proud. Commanding defiance, before battle.'), 'sib_solo': ('Algenib', 'A hardened male mercenary and rival. Low, gravelly, direct, cool confidence with an eager edge.'), 'sib_sisters': ('Leda', 'An adult female martial artist speaking for three sisters. Assertive, focused, energetic battle challenge.'), 'aerial_captain': ('Puck', 'An older male airship captain. Anger and disbelief turn to vengeful resolve as his ship falls.'), 'moon_solo': ('Algenib', 'The same hardened male mercenary. A bitter rematch: controlled, personal, determined to finish it.'), 'desert_officer': ('Rasalgethi', 'A male desert officer facing his enemy. Forceful, proud, menacing, projecting a clear threat.'), 'desert_commander': ('Schedar', 'A mature male enemy commander. Disdainful disbelief, then cold and imperious menace.')}

def jobs(language, selected):
    source = json.loads(MANIFEST.read_text())
    out = []
    for row in source['lines']:
        lid = row['id']
        if lid not in selected:
            continue
        if row['approval']['verdict'] != 'approve':
            raise ValueError('unapproved boss dialogue')
        voice, style = CAST[lid]
        text = row['en_draft'] if language == 'en' else row['ja_reading']
        prompt = 'You are performing a short dramatic challenge in a 1990s arcade action game. Use a natural character performance with clear consonants and brisk continuous delivery. Keep the speech compact; avoid long pauses or an announcer tone. ' + style + (' Speak natural Japanese.' if language == 'ja' else ' Speak American English.') + ' Read only the supplied words, exactly once. No additional sounds or commentary.'
        if language == 'en':
            for name, pron in DT.PRONOUNCE.items():
                if name in text:
                    text = text.replace(name, pron['spell'])
                    prompt += ' ' + pron['say']
            if 'Cypher' in text:
                prompt += ' Cypher is pronounced SY-fer.'
        body = dict(input=dict(prompt=prompt, text=text), voice=dict(languageCode='en-US' if language == 'en' else 'ja-JP', name=voice, modelName='gemini-3.1-flash-tts-preview'), audioConfig=dict(audioEncoding='LINEAR16', sampleRateHertz=48000))
        estimate = (len(prompt) + len(text)) / 1000000.0 + (3 + len(text) / 12) * 25 * 20 / 1000000.0
        out.append(dict(id=lid, language=language, voice=voice, approved_text=row['en_draft'] if language == 'en' else row['ja_reading'], source_approval=row['approval'], body=body, estimated_usd=estimate))
    if {r['id'] for r in out} != selected:
        raise ValueError('unknown selected boss')
    return out

def render(a):
    plan = jobs(a.language, set(a.lines.split(',')) if a.lines else set(CAST))
    total = sum((j['estimated_usd'] for j in plan))
    if total > a.cap_usd:
        raise ValueError('estimated cost exceeds the requested cap')
    credentials = json.loads(a.credentials.read_text())
    token = DT.token(a.credentials)
    output = DS.new_set(a.set)
    receipt = dict(schema='striderex-boss-dub-takes/1', status='audition', source_sha256=DS.sha(MANIFEST), provider='Google Cloud Text-to-Speech', model='gemini-3.1-flash-tts-preview', stock_voices_only=True, estimated_usd=total, cap_usd=a.cap_usd, takes=[])
    log = output / 'boss-dub.json'
    log.write_text(json.dumps(receipt, indent=2, ensure_ascii=False) + '\n')
    for job in plan:
        raw = DT.synth(token, credentials['project_id'], job['body'])
        if raw[:4] != b'RIFF':
            b = io.BytesIO()
            with wave.open(b, 'wb') as w:
                w.setnchannels(1)
                w.setsampwidth(2)
                w.setframerate(48000)
                w.writeframes(raw)
            raw = b.getvalue()
        path = output / (job['id'] + '.' + a.language + '.wav')
        path.write_bytes(raw)
        with wave.open(str(path), 'rb') as w:
            rate = w.getframerate()
            samples = w.getnframes()
            channels = w.getnchannels()
            if rate != 48000 or channels != 1 or w.getsampwidth() != 2:
                raise ValueError('unexpected provider WAV format')
        receipt['takes'].append(dict(job, file=path.name, wav_sha256=DS.sha(path), samples=samples, rate=rate, seconds=round(samples / rate, 4)))
        log.write_text(json.dumps(receipt, indent=2, ensure_ascii=False) + '\n')
        print(path.name, round(samples / rate, 3), 's', flush=True)
    DS.seal(output)
    print('Saved', len(receipt['takes']), 'takes in the durable store; estimated cost $%.3f' % total)

def main():
    import sys
    if sys.argv[1:] == ['--self-test']:
        en = jobs('en', set(CAST))
        ja = jobs('ja', {'stp_strongman'})
        assert len(en) == 8 and len(ja) == 1
        cast = json.loads((MANIFEST.parent / 'dub_cast.json').read_text())['speakers']
        assert CAST['stp_chairman'][0] == cast['Council chairman']['voice']
        assert CAST['aerial_captain'][0] == cast['Enemy officer']['voice']
        assert CAST['desert_commander'][0] == cast['Enemy commander']['voice']
        assert ja[0]['body']['input']['text'] == ja[0]['approved_text']
        try:
            jobs('en', {'unknown'})
        except ValueError:
            pass
        else:
            raise AssertionError('unknown dialogue accepted')
        print('Boss dub self-test PASS: approved lines, returning cast and unknown-line guard')
        return
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--credentials', type=Path, required=True)
    p.add_argument('--set', required=True)
    p.add_argument('--language', choices=('en', 'ja'), default='en')
    p.add_argument('--lines')
    p.add_argument('--cap-usd', type=float, default=0.25)
    a = p.parse_args()
    render(a)
if __name__ == '__main__':
    main()
