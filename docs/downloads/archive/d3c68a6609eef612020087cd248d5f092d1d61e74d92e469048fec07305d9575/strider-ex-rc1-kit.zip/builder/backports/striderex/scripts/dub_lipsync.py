"""Strider EX English dub: the speaking portraits' mouths against the voices (DUB.md sections 10-11)."""
import argparse
import hashlib
import json
import sys
from pathlib import Path
import numpy as np
sys.path.insert(0, str(Path(__file__).resolve().parent))
ROOT = Path(__file__).resolve().parents[3]
HERE = ROOT / 'backports/striderex'
MANIFEST = HERE / 'manifests/dub_lipsync.json'
SCENE_TRACK = {'prologue': 21, 'brief_st_petersburg': 22, 'intro_desert': 23, 'brief_siberia': 24, 'brief_aerial': 25, 'brief_amazon': 26, 'flight': 27, 'welcome_meio': 28}
MOUTH_BRIDGE = 0.35
LOCAL_MAX = 2500
RENDER_VERSION = 2

def sha_bytes(b):
    return hashlib.sha256(b).hexdigest()

def file_sha(p):
    h = hashlib.sha256()
    with open(p, 'rb') as f:
        for chunk in iter(lambda: f.read(1 << 22), b''):
            h.update(chunk)
    return h.hexdigest()

def scene_frames(build, sid):
    rows = json.loads((Path(build) / 'frames.json').read_text())[sid]['census']
    return ([int(f) for f, t in rows], np.array([float(t) for f, t in rows]))

class Scene:
    """Every census frame a stream shows, drawn as EX draws it (cinematic_convert.reference before its"""

    def __init__(self, frames, times, idx, pal, scroll):
        self.frames, self.times, self.idx, self.pal, self.scroll = (frames, times, idx, pal, scroll)

    def rgb(self, k, box=None):
        """Frame k (or a box (y0, y1, x0, x1) of it) as 8-bit RGB in the CPS colors EX shows."""
        import cps1_gfx as G
        y0, y1, x0, x1 = box or (0, self.idx.shape[1], 0, self.idx.shape[2])
        word = np.array([G.cps_color(int(v)) for v in self.pal[k]], np.int32)[self.idx[k, y0:y1, x0:x1]]
        return (np.stack([word >> 8 & 15, word >> 4 & 15, word & 15], -1) * 17).astype(np.uint8)

def render_scene(census, build, sid, work):
    """The Scene of one cinematic. Cached under work by a key of the inputs (the frame list and the"""
    import cinematic_convert as C
    cat = {c['id']: c for c in json.loads((Path(census) / 'catalog/catalog.json').read_text())['cinematics']}
    run = Path(census) / cat[sid]['run']
    frames, times = scene_frames(build, sid)
    key = sha_bytes(json.dumps([RENDER_VERSION, sid, frames, file_sha(run / 'pce_scene_index.tsv')]).encode())[:16]
    work = Path(work)
    work.mkdir(parents=True, exist_ok=True)
    npz, dig = (work / f'{sid}_{key}.npz', work / f'{sid}_{key}.sha256')
    if npz.exists() and dig.exists() and (file_sha(npz) == dig.read_text().strip()):
        z = np.load(npz)
        return Scene(frames, times, z['idx'], z['pal'], z['scroll'])
    writes = C.P.read_writes(run)
    idx = np.zeros((len(frames), C.SCREEN_H, 256), np.uint16)
    pal = np.zeros((len(frames), 512), np.uint16)
    scroll = np.zeros((len(frames), 2), np.int32)
    for k, f in enumerate(frames):
        d = C.load_frame(run, f)
        idx[k] = C.P.render(d, writes=writes.get(f), tiles=C.bat_tiles(d))[16:16 + C.SCREEN_H]
        pal[k] = d['pal']
        g = C.P.geometry(d)
        scroll[k] = (g['bxr'], g['byr'])
    np.savez(npz, idx=idx, pal=pal, scroll=scroll)
    dig.write_text(file_sha(npz) + '\n')
    return Scene(frames, times, idx, pal, scroll)

def clusters(pics, times, frames, cell=8, min_hits=6):
    """Local recurring changes: per 8x8 cell, the frames in which it changed while the whole frame"""
    n, h, w = pics.shape
    ch = pics[1:] != pics[:-1]
    total = ch.reshape(n - 1, -1).sum(1)
    local = (total > 0) & (total < LOCAL_MAX)
    cells = ch.reshape(n - 1, h // cell, cell, w // cell, cell).any(axis=(2, 4))
    hits = cells[local].sum(0)
    on = hits >= min_hits
    seen = np.zeros_like(on)
    out = []
    for cy, cx in zip(*np.nonzero(on)):
        if seen[cy, cx]:
            continue
        stack, comp = ([(cy, cx)], [])
        seen[cy, cx] = True
        while stack:
            y, x = stack.pop()
            comp.append((y, x))
            for dy in (-1, 0, 1):
                for dx in (-1, 0, 1):
                    yy, xx = (y + dy, x + dx)
                    if 0 <= yy < on.shape[0] and 0 <= xx < on.shape[1] and on[yy, xx] and (not seen[yy, xx]):
                        seen[yy, xx] = True
                        stack.append((yy, xx))
        ys, xs = ([c[0] for c in comp], [c[1] for c in comp])
        box = (min(ys) * cell, (max(ys) + 1) * cell, min(xs) * cell, (max(xs) + 1) * cell)
        m = cells[:, min(ys):max(ys) + 1, min(xs):max(xs) + 1].any(axis=(1, 2)) & local
        ks = np.nonzero(m)[0] + 1
        out.append(dict(box=box, hits=int(len(ks)), first_t=round(float(times[ks[0]]), 3), last_t=round(float(times[ks[-1]]), 3), first_frame=frames[ks[0]], last_frame=frames[ks[-1]]))
    return sorted(out, key=lambda c: c['first_t'])
MOUTHS = [dict(scene='intro_desert', who="the council chairman (St. Petersburg's last portrait), beaten", box=(100, 120, 116, 144), span=(1.404, 5.75), lines=['tr23.0a', 'tr23.0']), dict(scene='brief_siberia', who='the desert officer in a field cap (shot 0)', box=(112, 144, 112, 144), span=(1.304, 7.522), lines=['tr24.0', 'tr24.1']), dict(scene='brief_siberia', who='the desert officer in a field cap (shot 1, lower)', box=(160, 192, 112, 144), span=(7.539, 11.801), lines=['tr24.1', 'tr24.2']), dict(scene='brief_aerial', who='the woman with braided hair (left portrait)', box=(104, 120, 112, 144), span=(1.805, 8.13), lines=['tr25.0']), dict(scene='brief_aerial', who='Hiryu (right portrait)', box=(152, 168, 152, 184), span=(8.6, 11.1), lines=['tr25.1']), dict(scene='flight', who='the wounded woman (red hair)', box=(104, 124, 128, 148), span=(1.404, 9.177), lines=['tr27.0']), dict(scene='welcome_meio', who='the bearded captain (right)', box=(164, 184, 164, 188), span=(2.9, 7.3), lines=['tr28.0']), dict(scene='welcome_meio', who='the council chairman (left)', box=(152, 184, 32, 65), span=(7.3, 10.7), lines=['tr28.1'])]

def mouth_track(sc, m):
    """The mouth's frames: (times, state per frame, rest state, runs [(on, off)]), runs bridged over rest"""
    y0, y1, x0, x1 = m['box']
    ks = np.nonzero((sc.times >= m['span'][0] - 0.001) & (sc.times <= m['span'][1] + 0.001))[0]
    k0, k1 = (int(ks[0]), int(ks[-1]) + 1)
    reg = sc.idx[k0:k1, y0:y1, x0:x1].reshape(k1 - k0, -1)
    whole = np.concatenate([[0], (sc.idx[k0 + 1:k1] != sc.idx[k0:k1 - 1]).reshape(k1 - k0 - 1, -1).sum(1)])
    boxch = np.concatenate([[False], (reg[1:] != reg[:-1]).any(1)])
    local = np.nonzero(boxch & (whole < LOCAL_MAX))[0]
    if not len(local):
        sys.exit(f"{m['scene']} {m['who']}: the mouth box {m['box']} never changes in {m['span']}")
    big = np.nonzero(whole >= LOCAL_MAX)[0]
    a = int(max([b for b in big if b < local[0]], default=0))
    b = int(min([b for b in big if b > local[-1]], default=k1 - k0))
    t = sc.times[k0 + a:k0 + b]
    _, state = np.unique(reg[a:b], axis=0, return_inverse=True)
    state = state.ravel()
    rest = int(state[local[0] - a - 1])
    open_ = state != rest
    runs = []
    period = float(np.median(np.diff(sc.times)))
    k = 0
    while k < len(state):
        if open_[k]:
            j = k
            while j < len(state) and open_[j]:
                j += 1
            on, off = (float(t[k]), float(t[j]) if j < len(t) else float(t[-1]) + period)
            if runs and on - runs[-1][1] < MOUTH_BRIDGE:
                runs[-1][1] = off
            else:
                runs.append([on, off])
            k = j
        else:
            k += 1
    return dict(times=t, state=state, rest=rest, pictures=int(state.max()) + 1, changes=int((state[1:] != state[:-1]).sum()), shown=[round(float(t[0]), 3), round(float(t[-1]) + period, 3)], runs=[[round(on, 3), round(off, 3)] for on, off in runs])

def track_voices(track, fit=None):
    """{line id: {'ja': ..., 'en': ...}} of one track, measured as caption_pacing.py measure measures them"""
    import caption_pacing as CP
    import dub_mix as DM
    saved = DM.FIT
    try:
        if fit:
            DM.FIT = Path(fit)
        voc, _ = CP.stems(track)
        ja = CP.ja_voice(track, voc)
        en = CP.en_voice(track)
    finally:
        DM.FIT = saved
    out = {}
    for lid, v in ja.items():
        out.setdefault(lid, {})['ja'] = v
    for lid, v in en.items():
        out.setdefault(lid, {})['en'] = {k: x for k, x in v.items() if not k.startswith('_')}
    return out

def bridge(runs, gap=MOUTH_BRIDGE):
    out = []
    for a, b in sorted(runs):
        if out and a - out[-1][1] < gap:
            out[-1][1] = max(out[-1][1], b)
        else:
            out.append([a, b])
    return out

def clip(runs, a, b):
    return [[max(x, a), min(y, b)] for x, y in runs if min(y, b) > max(x, a)]

def overlap(r1, r2):
    return sum((max(0.0, min(b, d) - max(a, c)) for a, b in r1 for c, d in r2))

def compare(track_m, voices, lang):
    """One mouth against one language: its speaker's voice runs while the portrait is up (bridged as the"""
    a, b = track_m['shown']
    rs = []
    for lid in track_m['lines']:
        v = voices.get(lid, {}).get(lang)
        if v and v.get('runs'):
            rs += [list(r) for r in v['runs']]
    V = clip(bridge(rs), a, b)
    M = track_m['runs']
    if not V:
        return dict(voice=[], start=None, end=None, moving_silent=None, voice_still=None)
    both = overlap(M, V)
    return dict(voice=[[round(x, 3), round(y, 3)] for x, y in V], start=round(V[0][0] - M[0][0], 3), end=round(V[-1][1] - M[-1][1], 3), moving_silent=round(sum((y - x for x, y in M)) - both, 3), voice_still=round(sum((y - x for x, y in V)) - both, 3))
MARGIN = 0.012
LEAD = 0.05

def mouth_lines(m, voices):
    """(the line the mouth's first run belongs to, the line its last run belongs to): the first of its"""
    a, b = m['shown']
    ja = {lid: voices[lid]['ja'] for lid in m['lines'] if lid in voices and voices[lid].get('ja')}
    first = next((lid for lid in m['lines'] if lid in ja and ja[lid]['on'] >= a - 0.2), None)
    last = next((lid for lid in reversed(m['lines']) if lid in ja and ja[lid]['off'] <= b + 0.2), None)
    return (first, last)

def plan_track(track, mouths, voices, fit, subs, track_end, earliest=None):
    """The mix 8 placement of one track's English lines (the rule: DUB.md section 10):"""
    earliest = earliest or {}
    import dub_mix as DM
    vgap, mgap = (fit['solver']['gap'], fit['defaults']['min_gap'])
    cap = 1 - fit['defaults']['max_compress']
    slots = DM.slots_for(track, fit, subs)
    info = {}
    for lid, slot in slots:
        e = voices[lid]['en']
        s7, e7 = e['placed']
        r7 = e['ratio']
        info[lid] = dict(d=(e7 - s7) / r7, o=(e['on'] - s7) / r7, f=(e['off'] - s7) / r7, s7=s7, e7=e7, r7=r7, on7=e['on'], off7=e['off'])
    anchor, soft, portrait = ({}, {}, set())
    for m in mouths:
        first, last = mouth_lines(m, voices)
        if first:
            anchor[first] = m['runs'][0][0] - LEAD
        if last:
            soft[last] = m['runs'][-1][1]
        portrait |= set(m['lines'])

    def wanted(lid):
        """(voice on, ratio) a line asks for before its neighbours are known: its anchor or its approved"""
        i = info[lid]
        return (anchor.get(lid, i['on7']), i['r7'])

    def gap(rule, own):
        """The least gap between two lines: the rule's, or the approved pair's own when that is shorter. A pair"""
        return min(rule, own) if own > 0 else rule
    rows, prev = ([], None)
    for k, (lid, slot) in enumerate(slots):
        i, notes = (info[lid], [])
        o, f, d = (i['o'], i['f'], i['d'])
        if prev is None:
            lo_on, lo_start = (-1000000000.0, -1000000000.0)
        else:
            p7 = info[prev['id']]
            lo_on = prev['off'] + gap(vgap, i['on7'] - p7['off7'])
            lo_start = prev['end'] + gap(mgap + MARGIN, i['s7'] - p7['e7'])
        if k + 1 < len(slots):
            nid = slots[k + 1][0]
            n_on, n_r = wanted(nid)
            hard_off = n_on - gap(vgap, info[nid]['on7'] - i['off7'])
            hard_end = n_on - info[nid]['o'] * n_r - gap(mgap + MARGIN, info[nid]['s7'] - i['e7'])
        else:
            hard_off, hard_end = (max(track_end, i['off7']), max(track_end, i['e7']))

        def room(on):
            """The largest ratio (at most 1) at which a line whose voice starts at `on` fits before the next."""
            return min(1.0, (hard_off - on) / max(f - o, 1e-09), (hard_end - on) / max(d - o, 1e-09))
        on, r = wanted(lid)
        floor = max(lo_on, lo_start + o * r)
        if lid in earliest and lid not in anchor:
            floor = max(floor, min(earliest[lid], on))
        if on < floor - 1e-09:
            if on < floor - 0.005:
                notes.append(f'pushed {floor - on:.2f} s by the line before')
            on = floor
        if room(on) < r - 1e-09:
            if lid not in anchor:
                on = max(floor, min(on, hard_off - (f - o) * r, hard_end - (d - o) * r))
            r = max(min(r, room(on)), cap)
            if room(on) < r - 0.005:
                notes.append('pushes the next line' if k + 1 < len(slots) and slots[k + 1][0] not in anchor else 'LONGER THAN ITS ROOM even at the cap: pushes an anchored line')
        if lid in soft and on + (f - o) * r > soft[lid] + 1e-09:
            need = (soft[lid] - on) / (f - o)
            if need >= cap:
                r = min(r, need)
                notes.append(f'sped up to end with the mouth ({soft[lid]:.2f} s)')
            else:
                notes.append(f'runs {on + (f - o) * r - soft[lid]:.2f} s past the mouth (the cap cannot bring it in: kept at its pace)')
        start = on - o * r
        row = dict(id=lid, start=round(start, 3), end=round(start + d * r, 3), ratio=round(r, 4), natural=round(d, 4), on=round(on, 3), off=round(on + (f - o) * r, 3), mix7=dict(start=round(i['s7'], 3), ratio=i['r7'], on=i['on7'], off=i['off7']), anchored=lid in anchor, portrait=lid in portrait, notes=notes)
        row['moved'] = abs(start - i['s7']) > 0.0005 or abs(r - i['r7']) > 0.0005
        rows.append(row)
        prev = dict(row, end=start + d * r, off=on + (f - o) * r)
    for a_, b_ in zip(rows, rows[1:]):
        unchanged = not a_['moved'] and (not b_['moved'])
        if not unchanged and b_['start'] < a_['end'] + mgap - 0.002:
            sys.exit(f"tr{track}: {b_['id']} starts {a_['end'] + mgap - b_['start']:.3f} s inside the mixer's gap after {a_['id']}")
    return rows

def write_fit(plan, out):
    """The candidate fit: manifests/dub_fit.json with each moved line's slot set so that dub_mix.py places"""
    import math
    import dub_mix as DM
    fit = json.loads(DM.FIT.read_text())
    for track, rows in plan.items():
        for r in rows:
            if not r['moved']:
                continue
            o = fit['lines'].setdefault(r['id'], {})
            o['start'] = r['start']
            span = r['natural'] * r['ratio'] + 0.001
            if r['ratio'] < 1:
                span = math.ceil(span * 100 - 1e-09) / 100
            o['end'] = math.ceil((r['start'] + span) * 1000 - 1e-06) / 1000 if r['ratio'] >= 1 else round(r['start'] + span, 3)
            o['mix8'] = dict(rule='DUB.md section 10', voice_on=r['on'], voice_off=r['off'], ratio=r['ratio'], was=dict(start=r['mix7']['start'], ratio=r['mix7']['ratio']))
    fit['status'] = ''
    Path(out).write_text(json.dumps(fit, ensure_ascii=False, indent=1) + '\n')

def shots(census, sid):
    cat = {c['id']: c for c in json.loads((Path(census) / 'catalog/catalog.json').read_text())['cinematics']}
    return [(s['shot'], s['start_t'], s['end_t']) for s in cat[sid]['shots']]

def cmd_clusters(a):
    for sid in a.scenes or list(SCENE_TRACK):
        sc = render_scene(a.census, a.build, sid, a.work)
        spans = [(f'{t0}-{t1} s', t0, t1) for t0, t1 in a.window] if a.window else [(f'shot {n} {t0}-{t1} s', t0, t1) for n, t0, t1 in shots(a.census, sid)]
        for label, t0, t1 in spans:
            ks = np.nonzero((sc.times >= t0 - 0.001) & (sc.times <= t1 + 0.001))[0]
            if len(ks) < 10:
                continue
            k0, k1 = (ks[0], ks[-1] + 1)
            print(f'{sid} {label}: scroll {sorted(set(map(tuple, sc.scroll[k0:k1].tolist())))[:4]}')
            for c in clusters(sc.idx[k0:k1], sc.times[k0:k1], sc.frames[k0:k1], cell=4, min_hits=4):
                y0, y1, x0, x1 = c['box']
                reg = sc.idx[k0:k1, y0:y1, x0:x1].reshape(k1 - k0, -1)
                n = len(np.unique(reg, axis=0))
                print(f"   box y {y0}-{y1} x {x0}-{x1}: {c['hits']} local changes, {c['first_t']}-{c['last_t']} s (census {c['first_frame']}-{c['last_frame']}), {n} pictures", flush=True)
    return 0

def measured_mouths(a):
    out = []
    for m in MOUTHS:
        sc = render_scene(a.census, a.build, m['scene'], a.work)
        t = mouth_track(sc, m)
        out.append(dict(scene=m['scene'], track=SCENE_TRACK[m['scene']], who=m['who'], box=list(m['box']), lines=m['lines'], shown=t['shown'], pictures=t['pictures'], changes=t['changes'], runs=t['runs']))
    return out

def all_voices(tracks, fit=None):
    v = {}
    for t in tracks:
        v.update(track_voices(t, fit))
    return v

def inputs_record(a, extra=None):
    cat = Path(a.census) / 'catalog/catalog.json'
    rec = dict(census_catalog_sha256=file_sha(cat), frames_json_sha256=file_sha(Path(a.build) / 'frames.json'), dub_fit_sha256=file_sha(HERE / 'manifests/dub_fit.json'), dub_takes_sha256=file_sha(HERE / 'manifests/dub_takes.json'), dub_beds_sha256=file_sha(HERE / 'manifests/dub_beds.json'))
    rec.update(extra or {})
    return rec

def report(mouths, voices_by, labels):
    """Per mouth and voice (Japanese, and each English placement in voices_by): the comparison; and per"""
    rows = []
    for m in mouths:
        r = dict(m)
        r['compare'] = {lab: compare(m, voices_by[key], lang) for lab, key, lang in labels}
        rows.append(r)
    lines = {}
    for m in mouths:
        for lid in m['lines']:
            row = lines.setdefault(lid, dict(scene=m['scene'], mouths=[]))
            row['mouths'].append(m['who'])
            for lab, key, lang in labels:
                v = voices_by[key].get(lid, {}).get(lang)
                row[lab] = v and dict(on=v['on'], off=v['off'], runs=v['runs'])
    return (rows, lines)

def print_report(rows, lines, labels):
    for r in rows:
        print(f"{r['scene']} (tr{r['track']}): {r['who']}; shown {r['shown'][0]:.2f}-{r['shown'][1]:.2f} s; mouth moving {', '.join((f'{a:.2f}-{b:.2f}' for a, b in r['runs']))}")
        for lab, _, _ in labels:
            c = r['compare'][lab]
            if c['start'] is None:
                print(f'   {lab:9} no voice')
                continue
            print(f"   {lab:9} voice {', '.join((f'{a:.2f}-{b:.2f}' for a, b in c['voice']))}; starts {c['start']:+.2f} s, ends {c['end']:+.2f} s against the mouth; mouth moving with no voice {c['moving_silent']:.2f} s, voice with the mouth at rest {c['voice_still']:.2f} s")
    print()
    for lid, row in lines.items():
        print(f'{lid:8} ' + '  '.join((f"{lab} {row[lab]['on']:.2f}-{row[lab]['off']:.2f}" if row.get(lab) else f'{lab} -' for lab, _, _ in labels)))

def cmd_measure(a):
    mouths = measured_mouths(a)
    tracks = sorted({m['track'] for m in mouths})
    voices_by = {'approved': all_voices(tracks)}
    labels = [('ja', 'approved', 'ja'), ('en_mix7', 'approved', 'en')]
    if a.fit:
        voices_by['candidate'] = all_voices(tracks, a.fit)
        labels.append(('en_mix8', 'candidate', 'en'))
    rows, lines = report(mouths, voices_by, labels)
    print_report(rows, lines, labels)
    va = voices_by['approved']
    ja_starts = [va[f]['ja']['on'] - r['runs'][0][0] for r in rows if (f := mouth_lines(r, va)[0])]
    lead = round(float(-np.median(ja_starts)), 3) if ja_starts else None
    print(f'\nJapanese voice start against the mouth, first lines of each shot: median {-lead:+.3f} s (LEAD {LEAD})')
    if a.write:
        man = dict(schema=1, status="MEASURED by scripts/dub_lipsync.py measure: each speaking portrait's mouth animation (the census frames EX shows, build frames.json) against the voices in the tracks the pack plays. Seconds of track time (INDEX 01). Timings only.", method=dict(mouth="the mouth box's palette-index pictures frame by frame; moving = not the rest picture (the one shown before it first moves); rest holds under mouth_bridge_s closed", mouth_bridge_s=MOUTH_BRIDGE, local_max_pixels=LOCAL_MAX, voices="caption_pacing.py measure: Japanese = the BS-RoFormer vocal stem, English = each take placed as dub_mix.py mix places it; a mouth's voice = its speaker's lines while the portrait is up, bridged as the mouth is", offsets='start/end = voice minus mouth (s); moving_silent = mouth moving with no voice (s); voice_still = voice with the mouth at rest (s)'), inputs=inputs_record(a, dict(candidate_fit=str(a.fit.name) if a.fit else None, candidate_fit_sha256=file_sha(a.fit) if a.fit else None)), japanese_lead_median_s=lead, mouths=rows, lines=lines)
        MANIFEST.write_text(json.dumps(man, indent=1, ensure_ascii=False) + '\n')
        print(f'wrote {MANIFEST.relative_to(ROOT)}')
    return 0

def retaken_base(approved, nat, subs):
    """The fit new takes are planned from (retake, plan --retaken): each line in nat ({line id: the new take's"""
    import math
    f0 = json.loads(json.dumps(approved))
    for lid, d in nat.items():
        o = f0['lines'].setdefault(lid, {})
        s = o.get('start', subs[lid]['start'])
        o['start'], o['end'] = (s, math.ceil((s + d) * 1000 + 1) / 1000)
        for k in ('mix8', 'lead_trim_db', 'moved'):
            o.pop(k, None)
    return f0

def keep_unmoved(rows, base_rows, retaken):
    """plan --retaken: a line that is not re-taken keeps its approved fit when the rule places it exactly as it does"""
    base = {r['id']: r for r in base_rows}
    kept = []
    for r in rows:
        b = base.get(r['id'])
        if r['id'] in retaken or not r['moved'] or b is None:
            continue
        if all((r[k] == b[k] for k in ('start', 'end', 'ratio', 'on', 'off'))):
            r['moved'] = False
            r['notes'].append('kept as approved: the plan moves it the same without the new takes (its measuring step)')
            kept.append(r['id'])
    return kept

def cmd_plan(a):
    import dub_mix as DM
    import caption_pacing as CP
    mouths = measured_mouths(a)
    tracks = sorted({m['track'] for m in mouths})
    fit, subs = (DM.fit_plan(), DM.subtitle_index())
    approved = fit
    saved = DM.FIT
    if a.retaken:
        unknown = [lid for lid in a.retaken if lid not in subs]
        if unknown:
            sys.exit(f'--retaken: no such line {unknown}')
        fit = retaken_base(fit, {lid: len(DM.trim(CP.take(lid))[0]) / DM.RATE for lid in a.retaken}, subs)
        base = Path(a.work) / 'plan_retaken_base.json'
        base.parent.mkdir(parents=True, exist_ok=True)
        base.write_text(json.dumps(fit, ensure_ascii=False, indent=1) + '\n')
        DM.FIT = base
        tracks = sorted({subs[lid]['track'] for lid in a.retaken})
    try:
        plan = {}
        for t in tracks:
            voices = track_voices(t)
            mt = [m for m in mouths if m['track'] == t]
            plan[t] = plan_track(t, mt, voices, fit, subs, CP.track_seconds(t))
            if a.retaken:
                keep_unmoved(plan[t], plan_track(t, mt, track_voices(t, saved), approved, subs, CP.track_seconds(t)), a.retaken)
            for r in plan[t]:
                if r['moved'] or r['portrait'] or r['id'] in (a.retaken or ()):
                    m7 = r['mix7']
                    print(f"tr{t} {r['id']:8} voice {m7['on']:6.2f}-{m7['off']:6.2f} x{m7['ratio']:.3f} -> {r['on']:6.2f}-{r['off']:6.2f} x{r['ratio']:.3f}  {('ANCHOR ' if r['anchored'] else '')}{('RETAKEN ' if r['id'] in (a.retaken or ()) else '')}{'; '.join(r['notes'])}")
        Path(a.out).parent.mkdir(parents=True, exist_ok=True)
        write_fit(plan, a.out)
    finally:
        DM.FIT = saved
    Path(a.out).with_suffix('.plan.json').write_text(json.dumps(plan, indent=1) + '\n')
    print(f'wrote {a.out}')
    return 0
RETAKE_MANIFEST = HERE / 'manifests/dub_retake_candidates.json'

def take_stats(x):
    """A take's raw and trimmed length and its voice span (s), measured as caption_pacing measures a take."""
    import caption_pacing as CP
    import dub_mix as DM
    y, _ = DM.trim(x)
    t, e = CP.envelope(y, CP.RATE44)
    rs, _ = CP.line_activity(t, e, t[0], t[-1], t[0], t[-1])
    return dict(seconds=round(len(x) / DM.RATE, 3), trimmed_s=round(len(y) / DM.RATE, 3), voice_s=round(rs[-1][1] - rs[0][0], 3))

def mouth_fit(lid, mouths, voices):
    """The line's voice against each mouth it is spoken over: its own voice on/off, the mouth's first and"""
    v = voices[lid]['en']
    out = []
    for m in mouths:
        c = compare(m, voices, 'en')
        on, off = (m['runs'][0][0], m['runs'][-1][1])
        out.append(dict(mouth=m['who'], mouth_on=on, mouth_off=off, voice_on=round(v['on'], 3), voice_off=round(v['off'], 3), on_minus_mouth=round(v['on'] - on, 3), off_minus_mouth=round(v['off'] - off, 3), start=c['start'], end=c['end'], moving_silent=c['moving_silent'], voice_still=c['voice_still']))
    return out

def place_candidate(lid, x, mouths_t, subs, approved, work, tag):
    """The mix 8 plan of lid's track with take x in place of the approved one (every other line as approved):"""
    import caption_pacing as CP
    import dub_mix as DM
    t = subs[lid]['track']
    f0 = retaken_base(approved, {lid: len(DM.trim(x)[0]) / DM.RATE}, subs)
    p0, p1 = (work / f'{tag}_fit0.json', work / f'{tag}_fit.json')
    p0.write_text(json.dumps(f0, ensure_ascii=False, indent=1) + '\n')
    voices = track_voices(t, p0)
    try:
        rows = plan_track(t, mouths_t, voices, f0, subs, CP.track_seconds(t))
    except SystemExit as e:
        return (None, None, str(e))
    saved = DM.FIT
    DM.FIT = p0
    try:
        write_fit({t: rows}, p1)
    finally:
        DM.FIT = saved
    return (rows, p1, track_voices(t, p1))

def retake_mix(a, lid, cand_wav, fit_path, work, tag):
    """dub_mix.py mix of lid's track with the candidate take and the candidate fit (every check): (rc, the"""
    import caption_pacing as CP
    import dub_mix as DM
    t = int(lid[2:4])
    vd = work / f'{tag}_voices'
    vd.mkdir(parents=True, exist_ok=True)
    for f in vd.glob('*.wav'):
        f.unlink()
    for l, row in DM.subtitle_index().items():
        if row['track'] == t:
            src = Path(cand_wav) if l == lid else CP.takes_dir() / f'{l}.wav'
            if src.exists():
                (vd / f'{l}.wav').symlink_to(src.resolve())
    (vd / 'voices.json').write_text(json.dumps(dict(placeholder=False, source=f'approved takes with candidate {tag}')) + '\n')
    saved = DM.FIT
    DM.FIT = Path(fit_path)
    try:
        rc = DM.mix(argparse.Namespace(voices=vd, beds=a.beds, cue=a.cue, out=work / f'{tag}_mix', tracks=[t]))
    finally:
        DM.FIT = saved
    rep = json.loads((work / f'{tag}_mix' / 'mix_report.json').read_text())['tracks'][str(t)]
    row = next((r for r in rep['lines'] if r.get('id') == lid))
    return (rc, dict(track_ok=rep['ok'], ratio=row['ratio'], placed=row['placed'], checks=row['checks'], voice_lufs=row['voice_lufs'], voice_target_lufs=row['voice_target_lufs'], notes=row['notes']))

def mp3(src, dst):
    import subprocess
    subprocess.run(['ffmpeg', '-loglevel', 'error', '-y', '-i', str(src), '-map_metadata', '-1', '-codec:a', 'libmp3lame', '-q:a', '2', str(dst)], check=True)
    return file_sha(dst)

def cmd_retake(a):
    import caption_pacing as CP
    import dub_mix as DM
    work = Path(a.work)
    work.mkdir(parents=True, exist_ok=True)
    mouths = measured_mouths(a)
    subs, approved = (DM.subtitle_index(), DM.fit_plan())
    takes = json.loads((HERE / 'manifests/dub_takes.json').read_text())
    cands = {}
    for d in a.renders:
        v = json.loads((Path(d) / 'voices.json').read_text())
        for row in v['lines']:
            f = Path(d) / f"{row['line']}.wav"
            if file_sha(f) != row['wav_sha256']:
                sys.exit(f'{f}: not the take its voices.json names')
            cands.setdefault(row['line'], []).append((Path(d), row))
    if a.mp3:
        Path(a.mp3).mkdir(parents=True, exist_ok=True)
    orig_take = CP.take
    lines = {}
    try:
        for lid in sorted(cands):
            t = subs[lid]['track']
            ms = [m for m in mouths if lid in m['lines']]
            if not ms:
                sys.exit(f'{lid}: no speaking portrait')
            ms_t = [m for m in mouths if m['track'] == t]
            CP.take = orig_take
            cur = track_voices(t)
            tk = takes['lines'][lid]
            x0 = CP.take(lid)
            rec = dict(track=t, speaker=subs[lid]['speaker'], text=subs[lid]['en']['text'], current=dict(take=tk['take'], voice=tk['voice'], model=tk['model'], wav_sha256=tk['wav_sha256'], extra_direction=tk.get('extra_direction'), **take_stats(x0), placed=cur[lid]['en']['placed'], ratio=cur[lid]['en']['ratio'], fit=mouth_fit(lid, ms, cur)), candidates=[])
            if a.mp3:
                rec['current']['mp3'] = f'{lid}_current.mp3'
                rec['current']['mp3_sha256'] = mp3(CP.takes_dir() / f'{lid}.wav', Path(a.mp3) / f'{lid}_current.mp3')
            for k, (d, row) in enumerate(cands[lid]):
                label = chr(ord('A') + k)
                wav = d / f'{lid}.wav'
                x = DM.read_any_wav(wav)
                CP.take = lambda l, _x=x, _lid=lid: _x if l == _lid else orig_take(l)
                tag = f'{lid}_{label}'
                rows, fit_path, placed = place_candidate(lid, x, ms_t, subs, approved, work, tag)
                c = dict(label=label, render=d.name, voice=row['voice'], model=row['model'], prompt=row['prompt'], text=row['text'], usd_upper_bound=row['usd_upper_bound'], wav_sha256=row['wav_sha256'], **take_stats(x))
                if rows is None:
                    c['plan'] = dict(failed=placed)
                else:
                    r = next((r for r in rows if r['id'] == lid))
                    c['plan'] = dict(start=r['start'], end=r['end'], ratio=r['ratio'], notes=r['notes'], others_moved=[dict(id=o['id'], start=o['start'], ratio=o['ratio'], notes=o['notes']) for o in rows if o['id'] != lid and o['moved']])
                    c['fit'] = mouth_fit(lid, ms, placed)
                    if a.beds and a.cue:
                        rc, mixrow = retake_mix(a, lid, wav, fit_path, work, tag)
                        c['mix'] = dict(passed=rc == 0, **mixrow)
                if a.mp3:
                    c['mp3'] = f'{lid}_cand_{label}.mp3'
                    c['mp3_sha256'] = mp3(wav, Path(a.mp3) / c['mp3'])
                rec['candidates'].append(c)
            lines[lid] = rec
    finally:
        CP.take = orig_take
    for lid, rec in lines.items():
        print(f'''{lid} ({rec['speaker']}): "{rec['text']}"''')
        for lab, c in [('current', rec['current'])] + [(f"cand {c['label']}", c) for c in rec['candidates']]:
            f = c.get('fit') or []
            fit_s = '; '.join((f"voice {x['voice_on']:.2f}-{x['voice_off']:.2f} vs mouth {x['mouth_on']:.2f}-{x['mouth_off']:.2f} (on {x['on_minus_mouth']:+.2f}, off {x['off_minus_mouth']:+.2f}); while shown: mouth silent {x['moving_silent']:.2f}, voice still {x['voice_still']:.2f}" for x in f)) or c.get('plan', {}).get('failed', '')
            plan = c.get('plan', {})
            extra = f" x{plan.get('ratio', c.get('ratio', 1.0)):.3f}" + (f" [{'; '.join(plan['notes'])}]" if plan.get('notes') else '') + (f" MOVES {[o['id'] for o in plan['others_moved']]}" if plan.get('others_moved') else '') + (f" mix {('PASS' if c['mix']['passed'] else 'FAIL')}" if c.get('mix') else '')
            print(f"   {lab:8} voice {c['voice_s']:.2f} s (take {c['seconds']:.2f} s){extra}: {fit_s}")
    if a.write:
        man = dict(schema=1, status='The approved takes, fit and mix are unchanged. The WAVs and MP3s are scratch (not committed); the digests here identify them.', method=dict(placement='plan_track (the mix 8 rule) over the approved fit with the candidate take', fit="mouth_fit: the line's voice on/off against the mouth's first and last movement; start/end = voice minus mouth over the speaker's lines while the portrait is up (s); moving_silent = mouth moving with no voice (s); voice_still = voice with the mouth at rest (s)", mix='dub_mix.py mix of the track with the candidate fit (every check)' if a.beds else None), inputs=inputs_record(a), usd_upper_bound=round(sum((c['usd_upper_bound'] for r in lines.values() for c in r['candidates'])), 4), lines=lines)
        RETAKE_MANIFEST.write_text(json.dumps(man, indent=1, ensure_ascii=False) + '\n')
        print(f'wrote {RETAKE_MANIFEST.relative_to(ROOT)}')
    return 0
CPS1_HZ = 59.637
PITCH_RATE = 22050

def yin(x, rate, fmin=70.0, fmax=600.0, frame=0.04, hop=0.01, thr=0.25):
    """[(time, f0 or nan, frame dB)] by YIN (cumulative mean normalized difference, absolute threshold)."""
    n, h = (int(frame * rate), int(hop * rate))
    tmax, tmin = (int(rate / fmin), int(rate / fmax))
    out = []
    for s in range(0, len(x) - n - tmax, h):
        w = x[s:s + n + tmax]
        d = np.array([np.sum((w[:n] - w[t:t + n]) ** 2) for t in range(tmax + 1)])
        cm = np.ones_like(d)
        cm[1:] = d[1:] * np.arange(1, tmax + 1) / np.maximum(np.cumsum(d[1:]), 1e-12)
        db = 10 * np.log10(np.mean(w[:n] ** 2) + 1e-12)
        hit = np.nonzero(cm[tmin:] < thr)[0]
        if len(hit):
            t = hit[0] + tmin
            while t + 1 <= tmax and cm[t + 1] < cm[t]:
                t += 1
            out.append(((s + n / 2) / rate, rate / t, db))
        else:
            out.append(((s + n / 2) / rate, float('nan'), db))
    return np.array(out)

def f0_stats(x, rate, spans):
    """Median, 10th and 90th percentile f0 (Hz) and the voiced frame count over the spans (s) of mono x:"""
    from scipy.signal import resample_poly
    if rate != PITCH_RATE:
        from fractions import Fraction
        fr = Fraction(PITCH_RATE, rate).limit_denominator(1000)
        x = resample_poly(x, fr.numerator, fr.denominator)
    f = []
    for a, b in spans:
        r = yin(x[int(a * PITCH_RATE):int(b * PITCH_RATE)], PITCH_RATE)
        if not len(r):
            continue
        ok = ~np.isnan(r[:, 1]) & (r[:, 2] > r[:, 2].max() - 25)
        f += list(r[ok, 1])
    if not f:
        return None
    return dict(median_hz=round(float(np.median(f))), p10_hz=round(float(np.percentile(f, 10))), p90_hz=round(float(np.percentile(f, 90))), voiced_frames=len(f))

def cmd_pitch(a):
    """f0 of the Japanese voice of each named line (the vocal stem over its measured voice runs) and of any"""
    import caption_pacing as CP
    out = {}
    by_track = {}
    for lid in a.lines:
        by_track.setdefault(int(lid[2:4]), []).append(lid)
    for t, lids in sorted(by_track.items()):
        voc, _ = CP.stems(t)
        ja = CP.ja_voice(t, voc)
        x = voc.mean(0).astype(np.float64)
        for lid in lids:
            out[lid] = dict(runs=ja[lid]['runs'], **f0_stats(x, CP.RATE44, ja[lid]['runs']) or {})
            print(f"{lid:8} Japanese voice {ja[lid]['on']:.2f}-{ja[lid]['off']:.2f} s: {out[lid]}", flush=True)
    for p in a.clip or ():
        from scipy.io import wavfile
        rate, y = wavfile.read(str(p))
        y = (y.astype(np.float64) / 32768).reshape(len(y), -1).mean(1)
        out[p.name] = dict(sha256=file_sha(p), seconds=round(len(y) / rate, 3), **f0_stats(y, rate, [(0, len(y) / rate)]) or {})
        print(f'{p.name}: {out[p.name]}')
    if a.json:
        Path(a.json).write_text(json.dumps(out, indent=1) + '\n')
    return 0

def strip_png(rows, labels, path, px=60):
    """One scene's mouths against the voices: per mouth, the portrait's time on screen (light), its mouth"""
    from PIL import Image, ImageDraw, ImageFont
    font = ImageFont.load_default()
    left, rh, top = (230, 22, 28)
    t0 = min((r['shown'][0] for r in rows)) - 0.5
    t1 = max((max(r['shown'][1], *(c['voice'][-1][1] for c in r['compare'].values() if c['voice'])) for r in rows)) + 0.5
    n = len(rows) * (len(labels) + 1)
    w, h = (left + int((t1 - t0) * px) + 10, top + rh * n + 8 * len(rows) + 10)
    img = Image.new('RGB', (w, h), (255, 255, 255))
    d = ImageDraw.Draw(img)

    def x(t):
        return left + (t - t0) * px
    for s in range(int(t0), int(t1) + 1):
        d.line([(x(s), top - 4), (x(s), h - 6)], fill=(235, 235, 235))
        d.text((x(s) + 2, 8), f'{s} s', fill=(0, 0, 0), font=font)
    colors = {'ja': (70, 110, 200), 'en_mix7': (214, 80, 75), 'en_mix8': (46, 139, 87)}
    y = top
    for r in rows:
        d.text((6, y + 6), f"mouth: {r['who'][:34]}", fill=(0, 0, 0), font=font)
        d.rectangle([x(r['shown'][0]), y + 3, x(r['shown'][1]), y + rh - 3], fill=(225, 225, 225))
        for a_, b_ in r['runs']:
            d.rectangle([x(a_), y + 3, x(b_), y + rh - 3], fill=(60, 60, 60))
        y += rh
        for lab, _, _ in labels:
            c = r['compare'][lab]
            d.text((6, y + 6), f'  {lab}' + (f"  start {c['start']:+.2f} end {c['end']:+.2f}" if c['voice'] else ''), fill=(0, 0, 0), font=font)
            for a_, b_ in r['runs']:
                d.rectangle([x(a_), y + 2, x(b_), y + rh - 2], outline=(200, 200, 200))
            for a_, b_ in c['voice']:
                d.rectangle([x(a_), y + 5, max(x(a_) + 1, x(b_)), y + rh - 5], fill=colors.get(lab, (120, 120, 120)))
            y += rh
        y += 8
    img.save(path)

def make_clip(sc, pcm, rate, path, title):
    """A video of the scene as EX shows it (one census frame per CPS-1 frame, 2x, CPS colors) with the"""
    import subprocess
    import tempfile
    import wave
    a = int(round(sc.times[0] * rate))
    seg = pcm[:, a:a + int(round(len(sc.frames) / CPS1_HZ * rate))]
    with tempfile.TemporaryDirectory() as tmp:
        wav = Path(tmp) / 'a.wav'
        with wave.open(str(wav), 'wb') as w:
            w.setnchannels(2)
            w.setsampwidth(2)
            w.setframerate(rate)
            w.writeframes(np.clip(np.round(seg.T * 32768), -32768, 32767).astype('<i2').tobytes())
        proc = subprocess.Popen(['ffmpeg', '-loglevel', 'error', '-y', '-f', 'rawvideo', '-pix_fmt', 'rgb24', '-s', '256x224', '-r', f'{CPS1_HZ}', '-i', '-', '-i', str(wav), '-vf', 'scale=512:448:flags=neighbor,format=yuv420p', '-c:v', 'libx264', '-crf', '18', '-c:a', 'aac', '-b:a', '192k', '-shortest', '-metadata', f'title={title}', str(path)], stdin=subprocess.PIPE)
        for k in range(len(sc.frames)):
            proc.stdin.write(sc.rgb(k).tobytes())
        proc.stdin.close()
        if proc.wait():
            sys.exit(f'ffmpeg failed on {path}')

def read_track(path):
    import dub_beds as B
    return B.read_wav16(path).astype(np.float64)

def cmd_review(a):
    """Before/after strips for every scene with a speaking portrait, local clips (the picture with the"""
    import html
    import dub_beds as B
    out = a.out.resolve()
    out.mkdir(parents=True, exist_ok=True)
    mouths = measured_mouths(a)
    tracks = sorted({m['track'] for m in mouths})
    voices_by = {'approved': all_voices(tracks), 'candidate': all_voices(tracks, a.fit)}
    labels = [('ja', 'approved', 'ja'), ('en_mix7', 'approved', 'en'), ('en_mix8', 'candidate', 'en')]
    rows, lines = report(mouths, voices_by, labels)
    man = B.manifest()
    parts = ['<!doctype html><meta charset="utf-8"><title>Strider EX dub: mouths and voices</title><style>body{font:14px sans-serif;margin:16px}td,th{padding:2px 8px;border-bottom:1px solid #ddd}video{width:512px}</style>', "<h1>Strider EX dub: the portraits' mouths against the voices</h1>", "<p>Dark bars: the mouth moving (the PC Engine frames EX shows, at their track time). Blue: the Japanese voice. Red: English mix 7 (approved). Green: candidate mix 8 (DUB.md section 10). Local review material: the clips carry the disc's picture and music, never share them.</p>"]
    for sid in [s for s in SCENE_TRACK if any((r['scene'] == s for r in rows))]:
        track = SCENE_TRACK[sid]
        srows = [r for r in rows if r['scene'] == sid]
        png = out / f'strip_{sid}.png'
        strip_png(srows, labels, png)
        parts.append(f'<h2>{html.escape(sid)} (track {track})</h2><img src="{png.name}">')
        parts.append('<table><tr><th>mouth</th><th>voice</th><th>start</th><th>end</th><th>mouth moving, no voice</th><th>voice, mouth at rest</th></tr>')
        for r in srows:
            for lab, _, _ in labels:
                c = r['compare'][lab]
                if c['voice']:
                    parts.append(f"<tr><td>{html.escape(r['who'])}</td><td>{lab}</td><td>{c['start']:+.2f} s</td><td>{c['end']:+.2f} s</td><td>{c['moving_silent']:.2f} s</td><td>{c['voice_still']:.2f} s</td></tr>")
        parts.append('</table>')
        if not a.no_clips:
            sc = render_scene(a.census, a.build, sid, a.work)
            ja = B.disc_pcm(a.cue, track, man['inputs']['tracks'][str(track)]['pcm_sha256']).astype(np.float64)
            for lab, pcm in (('ja', ja), ('en_mix7', read_track(a.before / f'tr{track:02d}_en.wav')), ('en_mix8', read_track(a.after / f'tr{track:02d}_en.wav'))):
                mp4 = out / f'clip_{sid}_{lab}.mp4'
                make_clip(sc, pcm, B.RATE, mp4, f'{sid} {lab}')
                parts.append(f'<p>{lab}<br><video controls src="{mp4.name}"></video></p>')
            print(f'{sid}: clips done', flush=True)
    (out / 'index.html').write_text('\n'.join(parts) + '\n')
    (out / 'report.json').write_text(json.dumps(dict(mouths=rows, lines=lines), indent=1) + '\n')
    print(f"wrote {out / 'index.html'}")
    return 0

def self_test():
    """Synthetic checks of the mouth tracker, the comparison and the planner."""
    n, period = (80, 1 / 60)
    idx = np.zeros((n, 8, 8), np.uint16)
    talk = list(range(10, 13)) + list(range(17, 20)) + list(range(50, 55))
    for k in talk:
        idx[k, 2:4, 2:4] = 1 + k % 2
    sc = Scene(list(range(n)), np.arange(n) * period, idx, np.zeros((n, 512), np.uint16), np.zeros((n, 2), np.int32))
    t = mouth_track(sc, dict(scene='t', who='t', box=(0, 8, 0, 8), span=(0, 2)))
    assert t['pictures'] == 3 and t['rest'] == 0, t
    assert t['runs'] == [[round(10 * period, 3), round(20 * period, 3)], [round(50 * period, 3), round(55 * period, 3)]], t['runs']
    m = dict(shown=[0.0, 1.3], runs=t['runs'], lines=['a'])
    c = compare(m, {'a': {'ja': {'runs': [[0.1, 0.3], [0.8, 0.95]]}}}, 'ja')
    assert c['start'] == round(0.1 - 10 * period, 3) and c['moving_silent'] >= 0, c
    still = Scene(list(range(5)), np.arange(5) * period, np.zeros((5, 8, 8), np.uint16), np.zeros((5, 512), np.uint16), np.zeros((5, 2), np.int32))
    try:
        mouth_track(still, dict(scene='s', who='s', box=(0, 8, 0, 8), span=(0, 1)))
        raise AssertionError('a still mouth passed')
    except SystemExit:
        pass
    fit = dict(lines={}, speakers={}, solver=dict(gap=0.15), defaults=dict(align='start', max_compress=0.1, overrun=0.0, min_gap=0.05))
    subs = {'a': dict(track=99, start=2.0, end=3.0, speaker='P'), 'b': dict(track=99, start=3.5, end=5.0, speaker='P'), 'n': dict(track=99, start=8.0, end=9.0, speaker='N')}

    def en(s, d, o, f, r=1.0):
        return dict(placed=[s, s + d * r], ratio=r, on=s + o * r, off=s + f * r)
    voices = {'a': dict(ja=dict(on=1.5, off=2.9), en=en(2.0, 1.2, 0.1, 1.1)), 'b': dict(ja=dict(on=3.1, off=5.2), en=en(3.4, 2.0, 0.1, 1.9)), 'n': dict(ja=dict(on=8.0, off=9.0), en=en(8.0, 1.0, 0.05, 0.95))}
    mth = dict(shown=[1.0, 6.0], runs=[[1.6, 5.3]], lines=['a', 'b'])
    rows = {r['id']: r for r in plan_track(99, [mth], voices, fit, subs, 20.0)}
    assert abs(rows['a']['on'] - (1.6 - LEAD)) < 0.001 and rows['a']['anchored'], rows['a']
    assert not rows['b']['moved'] and (not rows['n']['moved']), rows
    rows = {r['id']: r for r in plan_track(99, [dict(mth, runs=[[1.6, 5.2]])], voices, fit, subs, 20.0)}
    assert abs(rows['b']['off'] - 5.2) < 0.002 and 0.9 <= rows['b']['ratio'] < 1, rows['b']
    rows = {r['id']: r for r in plan_track(99, [dict(mth, runs=[[1.6, 5.0]])], voices, fit, subs, 20.0)}
    assert rows['b']['ratio'] == 1.0 and (not rows['b']['moved']), rows['b']
    long_b = dict(voices, b=dict(voices['b'], en=en(3.4, 6.0, 0.1, 5.9)))
    rows = {r['id']: r for r in plan_track(99, [mth], long_b, fit, subs, 20.0)}
    assert rows['b']['ratio'] == 0.9 and rows['n']['moved'], rows
    assert rows['n']['on'] >= rows['b']['off'] + 0.15 - 1e-06 and rows['n']['start'] >= rows['b']['end'] + 0.05, rows
    tight = dict(voices, n=dict(voices['n'], en=en(8.0, 1.0, 0.05, 0.95)), m=dict(ja=dict(on=9.1, off=9.9), en=en(9.1, 1.0, 0.05, 0.95)))
    subs_m = dict(subs, m=dict(track=99, start=9.1, end=10.0, speaker='N'))
    free = {r['id']: r for r in plan_track(99, [mth], dict(tight, n=dict(tight['n'], en=en(8.0, 1.3, 0.05, 1.25))), fit, subs_m, 20.0)}
    held = {r['id']: r for r in plan_track(99, [mth], dict(tight, n=dict(tight['n'], en=en(8.0, 1.3, 0.05, 1.25))), fit, subs_m, 20.0, earliest={'n': 7.95})}
    assert free['n']['on'] < 7.95 - 0.001 and free['n']['ratio'] == 1.0, free['n']
    assert abs(held['n']['on'] - 7.95) < 0.001 and held['n']['ratio'] < 1.0, held['n']
    ap = dict(lines={'a': dict(start=2.0, end=3.2), 'b': dict(start=3.4, end=5.4, mix8=dict(ratio=1.0), lead_trim_db=30.0)})
    f0 = retaken_base(ap, {'b': 2.4996, 'n': 1.0}, subs)
    assert f0['lines']['b'] == dict(start=3.4, end=5.901) and f0['lines']['n'] == dict(start=8.0, end=9.001), f0
    assert f0['lines']['a'] == ap['lines']['a'] and 'mix8' in ap['lines']['b'] and ('n' not in ap['lines']), ap
    long_rows = plan_track(99, [mth], long_b, fit, subs, 20.0)
    base_rows = plan_track(99, [mth], voices, fit, subs, 20.0)
    step = {r['id']: dict(r, notes=list(r['notes'])) for r in long_rows}
    step['a'].update(moved=True)
    assert keep_unmoved(list(step.values()), [dict(r, moved=True) if r['id'] == 'a' else r for r in base_rows], ['b']) == ['a'] and (not step['a']['moved']), step['a']
    assert step['b']['moved'] and step['n']['moved'], step
    print('self-test OK')
    return 0

def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('--self-test', action='store_true')
    sub = p.add_subparsers(dest='cmd')
    for name in ('clusters', 'measure', 'plan', 'review', 'retake'):
        s = sub.add_parser(name)
        s.add_argument('--census', type=Path, required=True, help='the P0.1 census directory (pce_cinematic_census.py)')
        s.add_argument('--build', type=Path, required=True, help='an EX build directory (its frames.json)')
        s.add_argument('--work', type=Path, required=True, help='scratch for the rendered pictures')
        if name == 'clusters':
            s.add_argument('--scenes', nargs='*')
            s.add_argument('--window', nargs=2, type=float, action='append', metavar=('T0', 'T1'), help='track seconds to search (default: each census shot)')
        if name == 'measure':
            s.add_argument('--fit', type=Path, help='a candidate fit (plan --out) to measure beside the approved one')
            s.add_argument('--write', action='store_true', help='write manifests/dub_lipsync.json')
        if name == 'plan':
            s.add_argument('--out', type=Path, required=True, help='the candidate fit to write')
            s.add_argument('--retaken', nargs='+', metavar='LINE', help="lines with a new take in the store (dub_takes.json): each is planned from its approved place at its new take's own pace, as retake plans a candidate; only their tracks are planned")
        if name == 'review':
            s.add_argument('--fit', type=Path, required=True, help='the candidate fit')
            s.add_argument('--cue', type=Path, required=True, help='the restored PC Engine disc cue sheet')
            s.add_argument('--before', type=Path, required=True, help='dub_mix.py mix output with the approved fit')
            s.add_argument('--after', type=Path, required=True, help='dub_mix.py mix output with the candidate fit')
            s.add_argument('--out', type=Path, required=True)
            s.add_argument('--no-clips', action='store_true')
        if name == 'retake':
            s.add_argument('--renders', type=__import__('dub_store').dir_arg, nargs='+', required=True, help="dub_tts.py render directories (<line>.wav, voices.json); a line's candidates are labeled A, B, C... in this order")
            s.add_argument('--beds', type=Path, help='dub_beds.py repair beds/ (with --cue: mix and check each candidate)')
            s.add_argument('--cue', type=Path, help='the restored PC Engine disc cue sheet')
            s.add_argument('--mp3', type=Path, help='write each approved take and candidate alone as MP3 here')
            s.add_argument('--write', action='store_true', help='write manifests/dub_retake_candidates.json')
    s = sub.add_parser('pitch')
    s.add_argument('--lines', nargs='+', default=['tr23.0a', 'tr23.0', 'tr28.0', 'tr28.1'])
    s.add_argument('--clip', type=Path, action='append', help='another recording to measure (WAV)')
    s.add_argument('--json', type=Path)
    a = p.parse_args()
    if a.cmd == 'pitch':
        return cmd_pitch(a)
    if a.self_test:
        return self_test()
    if a.cmd == 'clusters':
        return cmd_clusters(a)
    if a.cmd == 'measure':
        return cmd_measure(a)
    if a.cmd == 'plan':
        return cmd_plan(a)
    if a.cmd == 'review':
        return cmd_review(a)
    if a.cmd == 'retake':
        if bool(a.beds) != bool(a.cue):
            p.error('retake: --beds and --cue go together')
        return cmd_retake(a)
    p.print_help()
    return 2
if __name__ == '__main__':
    sys.exit(main())
