; Strider EX desert extra stage (PC Engine "Oil Fields"), internal stage 5:
; PHASE0_PLAN.md W3 / Phase 3b, PHASE0_FINDINGS.md "Desert stage in the
; arcade engine". Included by ex_bank.s; scripts/desert_ex.py writes the
; per-region addresses (desert_syms.inc), the stage data (desert_data.inc)
; and the stock-program patches that reach this code.
;
; Play order: St. Petersburg (0) -> desert (5) -> Siberia (1) -> ... The

; DIP keeps its stock function, a pause.
;
; What runs where (A5 = 0xFF8000 in game code):
;   - per-stage tables reached through a pointer (the layer record
;     directory, the sprite palette table) get a sixth entry by data alone:
;     desert_ex.py points them at copies with the desert appended;
;   - the per-frame stage handler dispatch goes through a cycle-identical
;     copy with a sixth entry (dz_stage_dispatch), and the intro and clear
;     task starts through cycle-identical copies of the task start
;     (dz_task_intro, dz_task_clear); two paths a stock stage never takes
;     (St. Petersburg's next-stage store, two stage-0-only jump tables) call
;     a short hook here;
;   - so a stock stage runs the same instructions in the same cycles as
;     before, frame for frame and to the cycle (desert_gate.py identity
;     replays it against the build without the desert, at 8 MHz too: a
;     one-time hook of 60 cycles moved the frame phase and, at the bound,
;     the lag frames);
;   - the desert has its own intro task (dz_intro_task: new stage, respawn),
;     stage handler (dz_stage: areas, camera, music, display streaming) and
;     clear task (dz_clear_task: St. Petersburg's clear, which then stores
;     Siberia); a new stage shows its location caption (dz_cap_spawn, a stock
;     caption object: desert_caption.py) after the PC Engine introduction;
;   - its enemies are pool-5 objects of the dead type 3 (desert_actors.s):
;     dz_sections op 9 places a section's spawn list, dz_stage then runs the
;     map lists and the actors' collision pass (da_frame); section 4's tank
;     draws its hull on SCROLL2, which dz_watch moves with it.
;
; Two maps for one layer. Arcade collision is a property of SCROLL3 tile
; codes below 0x7F8 (stock art); the desert art has EX codes (0x3802 up).
; So the desert keeps two SCROLL3 maps of the same world:
;   - the collision map at 0x910000, where the game's collision code reads
;     it: stock codes in a page no stock map collides with (code page 5
;     drawn flipped both ways), whose collision types desert_ex.py adds,
;     streamed by the stock SCROLL3 streamer from the desert's
;     stock-format layer record;
;   - the display map at DZ_MAP, the desert art, which the CPS-A SCROLL3
;     base shows instead; dz_stream keeps it up to date from the camera.
; The stock code, the stock stages and their collision are unchanged. Every
; exit from desert play puts the base back: a death (dz_watch), the clear
; (dz_clear_task copies the display into the stock map first).

        include "desert_syms.inc"

DZ_STAGE equ    5
STAGE_B  equ    -$734E                  ; (a5) stage byte 0xFF0CB2
AREA_B   equ    -$7332                  ; area byte
IN_ST    equ    -$7324                  ; intro state byte (0xFF0CDC)
IN_SUB   equ    -$7323
FIRST_B  equ    -$7346                  ; intro first-entry flag
LAYER_W  equ    -$738C                  ; layer-control shadow
PLX      equ    -$6F2E                  ; player X (0xFF10D2), world up-Y below
PLY      equ    -$6F2A
CAMX     equ    -$700C                  ; SCROLL3 layer object 0xFF0FEC: X (0xFF0FF4)
CAMY     equ    -$7008                  ;                                Y (0xFF0FF8)
STAGEOBJ equ    -$2166                  ; the stage object (0xFF5E9A), A0 of a stage handler
PRI_A    equ    -$738A                  ; priority mask shadows (0xFF0C76..7A)
S3BASE   equ    $800106                 ; CPS-A SCROLL3 base
DZ_MAP   equ    $918000                 ; the desert display map (16 KB; free in play: intro_hook_probe.py)
DZ_BASEW equ    $9180
ST_BASEW equ    $9100

DZV      equ    $FFF92C                 ; desert variables, to 0xFFF937 (the EX VARS block's free tail: after stage_select.s SS_PREV; portraits.s holds 0xFFF940-0xFFF975)
DZ_W0    equ    DZV+$00                 ; word: first world column the display map holds
DZ_ON    equ    DZV+$02                 ; word: DZ_MAGIC while the display map is valid
DZ_MAP_I equ    DZV+$04                 ; word: map record index (0-2) shown
DZ_SEC   equ    DZV+$06                 ; word: section 0-4
DZ_STAT  equ    DZV+$08                 ; word: section state
DZ_MUS   equ    DZV+$0A                 ; word: music cue sent last (0 = none)
DZ_MAGIC equ    $D5E7
DZ_COLS  equ    24                      ; display map columns kept around the camera

; ------------------------------------------------------------------ hooks
; Per-frame stage handler dispatch (0xD38A jsr $EBF0 -> here): an exact
; copy of the stock dispatcher with a six-entry table, so stages 0-4 take
; the same instructions and cycles as before.
dz_stage_dispatch:
        lea     STAGEOBJ(a5),a0
        moveq   #0,d0
        move.b  STAGE_B(a5),d0
        add.w   d0,d0
        add.w   d0,d0
        movea.l .t(pc,d0.w),a1
        jmp     (a1)
.t:     dc.l    DZ_H0,DZ_H1,DZ_H2,DZ_H3,DZ_H4,dz_stage

; The intro task start (move.w #$40,d0 / movea.l #<intro task>,a0 / jsr <task start> -> jsr here; one call
; per stage start or respawn) and the clear task start (the same with the clear task): the stock task start
; (DZ_TSTART, 0x758: movem.l d0-d7/a0-a6,-(sp) / trap #0 / movem.l (sp)+,d0-d7/a0-a6 / rts) with the
; desert's own task in a0 for stage 5. For stages 0-4 each takes the stock routine's cycles exactly, so the
; stock stages keep their frame phase to the cycle: the stage test (16 + 8 not taken) and two nops (8) are
; paid for by the two registers fewer the movems move (2 x 16). TRAP #0 writes only d0, a4 and a6
; (desert_ex.TRAP0, shape-checked), so the 13 saved here keep every register as the stock routine does;
; d1 and d2 it never touches. The condition codes on return are the compare's, which no caller reads (each
; sets d0 next). The cycles: stock 128 + 132 + 16 = 276; here 16 + 8 + 4 + 4 + 112 + 116 + 16 = 276 (and
; the trap's own, the same). desert_gate.py static checks these bytes (desert_ex.TASK_COPY).
dz_task_intro:
        cmpi.b  #DZ_STAGE,STAGE_B(a5)   ; 16
        beq.s   .dz                     ; 8 (not taken)
        nop                             ; 4
        nop                             ; 4
        movem.l d0/d3-d7/a0-a6,-(sp)    ; 8 + 13 x 8
        trap    #0
        movem.l (sp)+,d0/d3-d7/a0-a6    ; 12 + 13 x 8
        rts                             ; 16
.dz:    lea     dz_intro_task,a0
        jmp     DZ_TSTART

dz_task_clear:
        cmpi.b  #DZ_STAGE,STAGE_B(a5)
        beq.s   .dz
        nop
        nop
        movem.l d0/d3-d7/a0-a6,-(sp)
        trap    #0
        movem.l (sp)+,d0/d3-d7/a0-a6
        rts
.dz:    lea     dz_clear_task,a0
        jmp     DZ_TSTART

; St. Petersburg's clear stores the next stage (move.b #1,STAGE(a5) ->
; jsr). From St. Petersburg: the desert. From the desert (dz_clear_task runs
; the same clear): Siberia.
dz_next_stage:
        cmpi.b  #DZ_STAGE,STAGE_B(a5)
        beq.s   .sib
        move.b  #DZ_STAGE,STAGE_B(a5)
        rts
.sib:   move.b  #1,STAGE_B(a5)
        rts

; Stage-indexed jumps that only stage 0 takes (0x5260 / 0x52A2 layer
; specials, which no code reaches: desert_ex.HOOKS): the desert takes
; Siberia's entry (move.b STAGE(a5),d0 / add.b d0,d0 -> jsr; d0 = the
; doubled stage). The caption object's per-stage init (0xDB3C) is left
; stock: the desert's caption starts on its fade path (dz_cap_spawn).
dz_as_sib_b:
        move.b  STAGE_B(a5),d0
        cmp.b   #DZ_STAGE,d0
        bne.s   .r
        moveq   #1,d0
.r:     add.b   d0,d0
        rts

; The stock SCROLL3 base and backdrop from here on (the end of desert play).
dz_base_stock:
        clr.w   DZ_ON
        move.w  #ST_BASEW,S3BASE
        move.w  DZ_STARS2+$3FE,$9157FE  ; the backdrop pen as the stage init loads it (stars palette 2)
        rts

; The watcher (task slot DZ_WSLOT from desert_syms.inc, one the game never
; uses: desert_ex.py checks), started by every desert setup. When a death
; blacks the screen out (the death task's move.w #0,LAYER(a5), 0xD182),
; the stock base and backdrop come back, before a respawn's setup or the
; time-over, continue and game-over screens draw. Then it ends; it also
; ends once the clear has put the base back. A stock stage never runs it,
; so the death path is unchanged. Each frame, after the game task's (slot
; 0x30; the scheduler runs the slots in order), it scrolls SCROLL2 to the
; tank's hull (desert_actors.s da_hull_scroll: the camera's final place).
dz_watch:
        lea     $FFFF8000.w,a5
.l:     move.w  #1,d0
        jsr     DZ_SLEEP
        cmpi.w  #DZ_MAGIC,DZ_ON
        bne.s   .end
        tst.w   LAYER_W(a5)
        beq.s   .off
        bsr     da_hull_scroll
        bra.s   .l
.off:   bsr     dz_base_stock
.end:   jmp     DZ_EXIT

; Stage 5's attract-demo slot (0x920014: the stock table holds a recording
; pointer per stage, 0x920000; the clear's store, 0x1156, keeps the best
; desert play there, and attract never plays it): 0 unless it holds one of
; the seven recording buffers (0x921000 + n * 0x800), as the store expects.
; Graphics RAM: the cinematics clear it.
dz_demo_slot:
        move.l  $920014,d0
        beq.s   .r
        sub.l   #$921000,d0
        bcs.s   .z
        cmp.l   #7*$800,d0
        bcc.s   .z
        and.w   #$7FF,d0
        beq.s   .r
.z:     clr.l   $920014
.r:     rts

; ------------------------------------------------------------ intro task
; As the stock intro task loop (0x90F6): one state step per frame, from the
; desert's own state table. New stage: state 0 (the desert cinematic, then
; setup and play); a death: state 6 (respawn).
dz_intro_task:
        lea     $FFFF8000.w,a5          ; A5 = 0xFF8000 (as the stock tasks: lea $8000.w,a5)
.loop:  move.w  #1,d0
        jsr     DZ_SLEEP
        pea     .loop(pc)
        tst.b   $FF0C84
        beq.s   .out
        moveq   #0,d0
        move.b  IN_ST(a5),d0
        cmp.w   #6,d0
        bls.s   .ok
        moveq   #6,d0
.ok:    move.w  .st(pc,d0.w),d0
        jmp     .st(pc,d0.w)
.out:   jmp     DZ_NOTGAME
.st:    dc.w    dz_i0-.st,dz_i2-.st,dz_i2-.st,dz_i6-.st

; state 0: a new desert stage. After the PC Engine introduction, the location caption, as a stock
; intro's end spawns one (0x96BE): it fades in over the black screen, the desert fades in under it
; (dz_setup: dz_fade_in, the stock setups' fade) and it fades out over the start of play. The waits
; run the system objects and the sprite frame, as the stock intro's do after its dialogue, so the
; caption moves on every frame; DZ_CAP_HOLD more frames stand for the stock dialogue's fade-out, so
; the scene and play come as many frames after the caption first shows as in the stock stages
; (desert_caption.py HOLD), and dz_setup keeps it on screen. A respawn (state 6) shows no caption
; and no fade, as in stock.

; show the wizard slide up before the level 2 start like the others"; ex_bank.s stage_hook, intro_cut):
; the wizard (GLOBE), the intro task loop's frame, their state 0 without its tune (intro_black), the
; frame of the dialogue's P1 button 1 path (the sound controls 0xF0 and 0xF7, the system objects and
; the sprite frame) and the frame of state 4's first step, so the caption is spawned on the frame the
; stock stages' fade-out spawns theirs, as many frames after the wizard (scripts/intro_gate.py). The
; desert's portrait dialogue (manifests/desert_intro.json lines) is superseded by that direction.
dz_i0:  move.b  #1,FIRST_B(a5)          ; as the stock first entry leaves it
    ifd BOSS_SCENE
        clr.b   BS_DONE                 ; a new desert: each boss scene may play once (boss_scene.s)
    endc
        jsr     cine_hook               ; the PC Engine desert introduction (stage_cines[5])
        jsr     wizard                  ; the wizard (ex_bank.s: GLOBE, the stars as at a game's first stage)
        moveq   #1,d0
        jsr     DZ_SLEEP                ; the loop's frame
        jsr     intro_black             ; state 0: black, the maps and sprite lists cleared (12 frames)
        moveq   #1,d0
        jsr     DZ_SLEEP
        jsr     SND_RESET               ; the P1 button 1 path's frame (INTRO_SKIP): 0xF0, 0xF7,
        jsr     SND_STOP
        moveq   #1,d0
        bsr     dz_frames               ; the system objects and the sprite frame
        moveq   #1,d0
        jsr     DZ_SLEEP                ; state 4's first step (0x969A): nothing drawn
        move.w  #0,LAYER_W(a5)
        jsr     DZ_CLRSPR               ; the cinematic's sprite lists go before the caption's frames
        bsr     dz_cap_spawn
        moveq   #1,d0
        bsr     dz_frames
        move.w  #$200,d0                ; clear the three maps
        jsr     DZ_QUEUE
        move.w  #$300,d0
        jsr     DZ_QUEUE
        move.w  #$400,d0
        jsr     DZ_QUEUE
        move.w  #10+DZ_CAP_HOLD,d0
        bsr     dz_frames
        moveq   #0,d0
        move.l  d0,-$73D4(a5)           ; scroll shadows
        move.l  d0,-$73CC(a5)
        move.l  d0,-$73C4(a5)
        move.b  d0,AREA_B(a5)           ; area 0: the start
        clr.w   DZ_MUS
        bra.s   dz_setup

; states 2 and 4 are not used (the arcade dialogue and title); go on to play
dz_i2:  move.b  #6,IN_ST(a5)
        rts

; state 6: respawn after a death (stock respawn routine shape, with the
; respawn reveal fix of respawn_layers.s)
dz_i6:  clr.w   DZ_MUS                  ; the section's music starts again
        move.w  #0,LAYER_W(a5)
        move.w  #1,d0
        jsr     DZ_SLEEP
        move.w  #$200,d0
        jsr     DZ_QUEUE
        move.w  #$300,d0
        jsr     DZ_QUEUE
        move.w  #$400,d0
        jsr     DZ_QUEUE
        move.w  #10,d0
        jsr     DZ_SLEEP
        jsr     DZ_CLRSPR

; Setup for the area in AREA_B: the restart record (stock loader), the
; three layers' init (the stock streamers read the desert's records, the
; sixth of each table: desert_ex.py relocates the record directory; SCROLL3
; draws the collision map), the display map, then play. The layers stay
; hidden until the whole scene is drawn. A respawn (intro state 6) hides
; the sprites too and shows the scene a few frames into play, as the respawn
; fix does for the stock stages (respawn_layers.s). A new stage (state 0)
; keeps its sprites, the location caption, and fades the scene in once it is
; drawn, as a stock stage's setup does (dz_fade_in), then plays.
dz_setup:
        moveq   #0,d0
        move.b  AREA_B(a5),d0           ; area 0 (the start) or a section's area 1-5
        cmp.w   #DZ_AREAS-1,d0
        bls.s   .a
        moveq   #0,d0
.a:     mulu    #DZ_RESTART_SIZE,d0
        lea     dz_restart,a1
        add.w   d0,a1
        move.l  a1,-(sp)
        jsr     DZ_CPLOAD               ; the stock checkpoint loader core: a1 = record (sets the area
        move.l  (sp)+,a1                ; and the layer word)
        move.w  LAYER_W(a5),-(sp)       ; the record's layer word
        tst.b   IN_ST(a5)
        bne.s   .rs
        clr.w   LAYER_W(a5)             ; a new stage: no layer until the scene is drawn; the sprites show
.rs:    move.w  DZ_RESTART_SIZE-2(a1),DZ_MAP_I   ; the record's last word: the map it is in
        moveq   #0,d0
        move.b  AREA_B(a5),d0
        subq.w  #1,d0
        move.w  d0,DZ_SEC               ; area n = section n-1
        clr.w   DZ_STAT
        bsr     da_setup                ; the actors' once ids and map list afresh (the pools were rebuilt)
        tst.b   IN_ST(a5)
        bne.s   .hold
        jsr     DZ_S1                   ; a new stage: the SCROLL1 init (no hold)
        bra.s   .s2
.hold:  jsr     DZ_HOLD                 ; a respawn: respawn_hold: stash the loader's layer word, hide, SCROLL1 init
.s2:    jsr     DZ_S2
        jsr     DZ_S3                   ; the collision map: the record is map 0's
        tst.w   DZ_MAP_I
        beq.s   .m0
        bsr     dz_select_map           ; another map: its grid and sections, drawn again
        lea     -$7014(a5),a0
        jsr     DZ_S3INIT
.m0:    bsr     dz_draw_all             ; the display map around the camera
        bsr     dz_demo_slot
        move.w  #DZ_SKY,$9157FE         ; the sky: the backdrop pen 0xBFF (a new stage: black, until
        tst.b   IN_ST(a5)               ; dz_fade_in shows it with the scene)
        bne.s   .sky
        clr.w   $9157FE
.sky:   move.w  #DZ_BASEW,S3BASE        ; and show the display map
        move.w  (sp)+,d0
        tst.b   IN_ST(a5)
        bne.s   .on
        bsr     dz_fade_in              ; a new stage: the scene is drawn; it fades in, its layers on
        move.w  #DZ_MAGIC,DZ_ON         ; (d0), and play follows in the frame the fade ends, as in stock
        move.w  #DZ_WSLOT,d0
        lea     dz_watch,a0
        jsr     DZ_TSTART
        bra.s   .shown
.on:    move.w  #DZ_MAGIC,DZ_ON
        move.w  #DZ_WSLOT,d0
        lea     dz_watch,a0
        jsr     DZ_TSTART
        jsr     DZ_SHOW                 ; respawn_show: one frame, then the reveal task
.shown: move.w  #$7E,PRI_A(a5)          ; priority masks (as Siberia)
        move.w  #$3FE,PRI_A+2(a5)
        move.w  #$7FFF,PRI_A+4(a5)
        move.b  #6,IN_ST(a5)            ; the next start in this stage is a respawn
        move.w  #DZ_TIMER,-$7096(a5)    ; the area timer, and its HUD digits (video command
        move.w  #$C00,d0                ; 0xC00, as the timer's tick, 0x266E), so the HUD
        jsr     DZ_QUEUE                ; shows it from the first frame
        bsr     dz_music
        jmp     DZ_PLAY                 ; the stock start of play (ends this task)

; dz_fade_in: a new desert stage's scene fades in, the steps of the stock setups' fade-in (USA 0x97BE-
; 0x984C, the same in all four stages and in Japan): the level word 0xFF0C1A (-$73E6(a5)) 0 into the
; brightness of every color of the SCROLL1-3 pages, a frame, the layer word on (d0: the desert's, from its
; restart record), then a level up every 3 frames to A; at B the system objects and the sprite frame run
; once more and the stage's palette sets are reloaded at full brightness (DZ_PAL1-3, which reach the
; desert's sets through the relocated record directory: desert_ex.py). The sky (the backdrop pen, which
; the stock stages keep black) takes each level with the rest, from the frame the layers come on: with
; them off the backdrop is the whole picture, and a stock one is black then (MEASURED: a sky at level 0
; one frame before the scene). Each wait frame runs the system objects and the sprite frame (dz_frames),
; so the caption moves on every frame.
dz_fade_in:
        move.w  d0,-(sp)
        clr.w   -$73E6(a5)              ; level 0 (0x97BE)
        bsr.s   dz_fade_pages
        moveq   #1,d0
        bsr     dz_frames
        moveq   #0,d2
        bsr.s   dz_fade_sky             ; the sky at level 0 with the layer word: both in the next VBlank
        move.w  (sp)+,LAYER_W(a5)       ; the scene on, at level 0 (0x97DC)
.lv:    moveq   #3,d0
        bsr     dz_frames
        add.w   #$1000,-$73E6(a5)
        cmp.w   #$B000,-$73E6(a5)
        beq.s   .full
        bsr.s   dz_fade
        bra.s   .lv
.full:  jsr     DZ_OBJS                 ; (0x9834)
        jsr     DZ_SPRITES
        jsr     DZ_PAL1
        jsr     DZ_PAL2
        jsr     DZ_PAL3
        move.w  #DZ_SKY,$9157FE
        rts

; dz_fade: the stock fade step (0x993A): the level in -$73E6(a5) into the brightness nibble of every
; color of the SCROLL1, SCROLL2 and SCROLL3 pages (0x914400-0x914FFF), and the sky's (dz_fade_sky: the
; level in d2). Clobbers d0-d3, a1.
dz_fade:
        bsr.s   dz_fade_pages
dz_fade_sky:
        move.w  #DZ_SKY&$0FFF,d3
        or.w    d2,d3
        move.w  d3,$9157FE
        rts
dz_fade_pages:
        move.w  -$73E6(a5),d2
        lea     $914400,a1
        move.w  #3*32*16-1,d0
.c:     move.w  (a1),d3
        and.w   #$0FFF,d3
        or.w    d2,d3
        move.w  d3,(a1)+
        dbra    d0,.c
        rts

; dz_cap_spawn: the location caption, a stock caption object (system object kind 2, DZ_CAPOBJ)
; created as its init leaves one (0xDB00, a stage's entry of 0xDB4A): state 2, parameter 2 (the
; fade path: a level up every 2 updates, then down every 4, then the area's sprite palettes
; reloaded), the record, the position and the palette slot, then fade level 0 applied (the
; init's last step). The init's per-stage table has five entries, so it is not run. The stock
; captions' colors are already loaded with their stage's set; the desert's set loads only with
; its setup, so the slot's colors go into the palettes first. No free system object: no caption.
dz_cap_spawn:
        lea     dz_obj_block+32*DZ_CAP_SLOT,a0
        lea     $914000+32*DZ_CAP_SLOT,a1
        moveq   #8-1,d0
.c:     move.l  (a0)+,(a1)+
        dbra    d0,.c
        jsr     DZ_SYSALLOC             ; a1 = a free system object (0x40 bytes, cleared); carry: none
        bcs.s   .r
        move.b  #1,$00(a1)              ; active
        move.b  #2,$17(a1)              ; kind 2: the caption
        move.b  #2,$02(a1)              ; state 2 (the init's own setting)
        move.w  #$100,$30(a1)           ; the fade's update count (the init's own setting)
        move.l  #dz_cap_record,$1A(a1)  ; {count, cols-1, rows-1, attribute, codes}
        move.w  #DZ_CAP_X,$08(a1)
        move.w  #DZ_CAP_Y,$0C(a1)
        move.l  #$914000+32*DZ_CAP_SLOT,$1E(a1)   ; the palette the fade sets
        move.b  #2,$06(a1)              ; parameter 2: the fade path
        clr.b   $32(a1)                 ; fade level 0
        movea.l a1,a0
        jsr     DZ_CAPFADE              ; the slot at level 0
.r:     rts

; dz_frames: d0 frames as the stock intro's waits after its dialogue (0x96E2-0x96F2): the system
; objects (DZ_OBJS: the caption), the sprite frame (DZ_SPRITES), a frame's sleep.
dz_frames:
        move.w  d0,-(sp)
.l:     jsr     DZ_OBJS
        jsr     DZ_SPRITES
        move.w  #1,d0
        jsr     DZ_SLEEP
        subq.w  #1,(sp)
        bne.s   .l
        addq.l  #2,sp
        rts

; --------------------------------------------------------------- clear
; As the stock clear task (0xBDC8) with St. Petersburg's clear handler,
; whose next-stage store (dz_next_stage) gives Siberia from here. First the
; display map goes into the stock SCROLL3 map, so the stock base shows the
; same picture through the clear.
dz_clear_task:
        lea     $FFFF8000.w,a5          ; A5 = 0xFF8000 (as the stock tasks: lea $8000.w,a5)
        jsr     DZ_DEMOEND              ; as the stock task (0x112A)
        tst.w   DZ_ON
        beq.s   .l
        lea     DZ_MAP,a0
        lea     $910000,a1
        move.w  #$4000/16-1,d0
.c:     move.l  (a0)+,(a1)+
        move.l  (a0)+,(a1)+
        move.l  (a0)+,(a1)+
        move.l  (a0)+,(a1)+
        dbra    d0,.c
        bsr     dz_base_stock
.l:     move.w  #1,d0
        jsr     DZ_SLEEP
        pea     .l(pc)
        jmp     DZ_STPCLEAR

; ------------------------------------------------------- stage handler
; Every frame of desert play (from dz_stage_dispatch, a0 = stage object).
dz_stage:
        bsr     dz_sections
        bsr     dz_stream
        bra     da_frame                ; the desert actors (desert_actors.s): map lists, collision

; Sections (PC Engine $2D0B, 0-4; area byte = section + 1, the respawn
; point) and their states, from the PC Engine section scripts (desert_ex.py
; flow). Table dz_sec_tab (desert_data.inc): per section a list of 16-byte
; steps, an op word and its words:
;   1 trigger  x min, x max, y min, y max: wait for Hiryu inside (world, Y up)
;   2 limits   x min, x max, y min, y max: the camera bounds (layer terms)
;   3 music    cue
;   4 section  n: go on with section n (its steps from the start)
;   5 map      k: the world of map k (both maps redrawn: a PC Engine map load)
;   6 clear    the stage clear (game mode 6, as a boss's fall sets it)
;   7 settle   wait for the camera inside the bounds
;   8 timer    seconds (the stock area timer, 0xFF0F6A)
;   9 actors   k: spawn list k of the desert actors (desert_actors.s)
;  10 wait     id: wait for that spawn-once id's status DA_AWAIT_A or DA_AWAIT_B (the PC Engine's
;              0x6A:0x99D6: section 3 waits for the jeep, which sets DA_JP_DONE at the end of its
;              death drive; section 1 for the officer, freed with status 2, 0x6A:0x9846; section 4 for
;              the tank, freed with status 2 at the end of its death, 0x6A:0x9B68; da_setup clears the
;              statuses, so a respawn waits again)

;              the PC Engine freezes it, 0x6A:0x97D4)
;  12 waitpt   wait until the portrait (and its colors' tail) is over (the PC Engine's 0x97E9)
;  13 once     id, status: that spawn-once id's status (the go after a portrait: section 1's,
;              0x97FE, the officer and the sand-pull, 3; section 4's, 0x9B45, the commander and the
;              tank, 3)
;  14 delay    n: go on n frames later (DA_DLY)
;  15 pit      k: the pit's variant k (1-3: map record DZ_PIT0 + k, the cells it changes written
;              where the two maps hold their columns, dz_pit_cells; the streamers read its grids
;              from then on: the PC Engine's 0x9B9B through 0x60FE)
;   0 end      wait here
; Several steps can run in one frame; a wait ends the frame's run. The camera bounds a limits
; step sets are kept in DA_LIM too: while the officer's pan holds the camera (DA_PANON), only
; there, and the pan puts them back when it ends (desert_actors.s da_pan).
dz_sections:
        move.w  DZ_SEC,d0
        add.w   d0,d0
        lea     dz_sec_tab,a1
        move.w  0(a1,d0.w),d0
        lea     0(a1,d0.w),a1           ; this section's steps
        move.w  DZ_STAT,d1              ; step index
.next:  move.w  d1,d2
        lsl.w   #4,d2                   ; 16-byte steps
        lea     0(a1,d2.w),a2
        move.w  (a2)+,d0                ; op
        beq     .done                   ; end
        cmp.w   #1,d0
        bne.s   .lim
        move.w  PLX(a5),d2              ; trigger: wait for Hiryu in the box
        cmp.w   (a2)+,d2
        blt     .done
        cmp.w   (a2)+,d2
        bgt     .done
        move.w  PLY(a5),d2
        cmp.w   (a2)+,d2
        blt     .done
        cmp.w   (a2)+,d2
        bgt     .done
        bra     .adv
.lim:   cmp.w   #2,d0
        bne.s   .mus
        lea     DA_LIM,a3               ; the section's bounds (the officer's pan puts them back when it ends)
        move.l  (a2),(a3)+
        move.l  4(a2),(a3)
        tst.b   DA_PANON
        bne     .adv
        move.w  (a2)+,-$6FE8(a5)        ; X min (0xFF1018)
        move.w  (a2)+,-$6FEA(a5)        ; X max (0xFF1016)
        move.w  (a2)+,-$6FE4(a5)        ; Y min (0xFF101C)
        move.w  (a2)+,-$6FE6(a5)        ; Y max (0xFF101A)
        bra     .adv
.mus:   cmp.w   #3,d0
        bne.s   .sec
        move.w  (a2)+,d0
        movem.l d1/a1,-(sp)
        bsr     dz_cue
        movem.l (sp)+,d1/a1
        bra     .adv
.sec:   cmp.w   #4,d0
        bne.s   .map
        move.w  (a2)+,d0
        move.w  d0,DZ_SEC               ; a new section: its steps from the start
        addq.b  #1,d0
        move.b  d0,AREA_B(a5)           ; its respawn point
        tst.b   $B94(a5)                ; the hurry-up tune played: the section's music again (as 0xF2AE)
        beq.s   .s0
        clr.b   $B94(a5)
        clr.w   DZ_MUS
.s0:    clr.w   DZ_STAT
        bra     dz_sections
.map:   cmp.w   #5,d0
        bne.s   .clr
        move.w  (a2)+,d0
        cmp.w   DZ_MAP_I,d0             ; (shown already: a respawn's setup drew it)
        beq     .adv
        move.w  d0,DZ_MAP_I
        movem.l d1/a0-a1,-(sp)
        bsr     dz_select_map
        lea     -$7014(a5),a0           ; the collision map: the stock SCROLL3 full draw
        jsr     DZ_S3INIT
        bsr     dz_draw_all
        movem.l (sp)+,d1/a0-a1
        bra     .adv
.clr:   cmp.w   #6,d0
        bne.s   .set
        cmpi.w  #4,-$73EE(a5)           ; in play: the stage clear, as a boss's fall
        bne     .done
        move.w  #6,-$73EE(a5)
        bra     .adv
.set:   cmp.w   #7,d0
        bne.s   .tim
        bsr     dz_pan                  ; settle: pan the camera into the bounds, then go on
        tst.w   d3
        bne     .done
        bra     .adv
.tim:   cmp.w   #8,d0
        bne.s   .act
        move.w  (a2)+,-$7096(a5)        ; the area timer (seconds) and its HUD digits
        move.w  #$C00,d0
        jsr     DZ_QUEUE
        bra     .adv
.act:   cmp.w   #9,d0
        bne.s   .wt
        move.w  (a2)+,d0                ; actors: spawn list k (desert_actors.s)
        add.w   d0,d0
        add.w   d0,d0
        movem.l d1/a1,-(sp)
        lea     da_spawn_lists,a1
        movea.l 0(a1,d0.w),a1
        bsr     da_spawn_list
        movem.l (sp)+,d1/a1
        bra     .adv
.wt:    cmp.w   #10,d0
        bne.s   .pt
        move.w  (a2)+,d0                ; wait: the once id's status
        lea     DA_ONCE,a2
        move.b  0(a2,d0.w),d0
        cmp.b   #DA_AWAIT_A,d0
        beq     .adv
        cmp.b   #DA_AWAIT_B,d0
        bne     .done
        bra     .adv
.pt:    cmp.w   #11,d0
        bne.s   .wp
        move.w  (a2)+,d0                ; portrait k
        movem.l d1/a0-a1,-(sp)
    ifd BOSS_SCENE
        jsr     bs_portrait             ; its boss scene, in place of the portrait (play stands still during it; the
    else                                ; waitpt after it goes straight on, so the boss starts after the scene)
        jsr     pt_arm
    endc
        movem.l (sp)+,d1/a0-a1
        bra     .adv
.wp:    cmp.w   #12,d0
        bne.s   .on
        cmpi.w  #PT_MAGIC,PT_ON         ; until the portrait is over
        beq     .done
        bra     .adv
.on:    cmp.w   #13,d0
        bne.s   .dl
        move.w  (a2)+,d0                ; once: the id's status
        lea     DA_ONCE,a3
        move.b  1(a2),0(a3,d0.w)
        bra     .adv
.dl:    cmp.w   #14,d0
        bne.s   .pi
        tst.w   DA_DLY                  ; delay: its first frame sets the count, the n-th after it goes on
        bne.s   .dn
        move.w  (a2),DA_DLY
        bra     .done
.dn:    subq.w  #1,DA_DLY
        bne     .done
        bra     .adv
.pi:    cmp.w   #15,d0
        bne.s   .adv
        move.w  (a2)+,d2                ; pit: variant k
        move.w  d2,DA_PIT
        movem.l d1/a0-a1,-(sp)
        move.w  d2,d0
        add.w   #DZ_PIT0,d0
        move.w  d0,DZ_MAP_I
        bsr     dz_select_map           ; the collision streamer's grid and sections (dz_column reads DZ_MAP_I's)
        bsr     dz_pit_cells
        movem.l (sp)+,d1/a0-a1
.adv:   addq.w  #1,d1
        move.w  d1,DZ_STAT
        bra     .next
.done:  rts

; dz_pan: one step of the PC Engine's camera settle. The arcade camera only
; follows Hiryu inside its bounds and never moves to them by itself, so a
; camera outside new bounds is moved toward them through the stock scroll
; steps (which stream what they uncover and stop at the bounds), as if Hiryu
; stood 0x18 px past the follow box on that side. d3 = 0 once inside.
; Keeps d1, a1-a2.
PAN_TOL equ     12                      ; the stock steps never land on a bound (a step to or past it is
                                        ; refused: 0x1DF12 bge, 0x1E03E ble), and move up to 10 px
dz_pan: movem.l d1/a1-a2,-(sp)
        lea     -$7014(a5),a0           ; SCROLL3 layer object (the camera)
        moveq   #0,d3
        move.w  CAMX(a5),d2
        add.w   #PAN_TOL,d2
        cmp.w   -$6FE8(a5),d2           ; X min
        bge.s   .x1
        bsr.s   dz_pan_pos
        move.w  $32(a0),d0
        add.w   #$18,d0
        jsr     DZ_SCR_R
        bra.s   .xm
.x1:    sub.w   #2*PAN_TOL,d2
        cmp.w   -$6FEA(a5),d2           ; X max
        ble.s   .y0
        bsr.s   dz_pan_pos
        move.w  $34(a0),d0
        sub.w   #$18,d0
        jsr     DZ_SCR_L
.xm:    moveq   #1,d3
.y0:    lea     -$7014(a5),a0
        move.w  CAMY(a5),d2
        add.w   #PAN_TOL,d2
        cmp.w   -$6FE4(a5),d2           ; Y min
        bge.s   .y1
        bsr.s   dz_pan_pos
        move.w  $36(a0),d0
        add.w   #$18,d0
        jsr     DZ_SCR_U
        bra.s   .ym
.y1:    sub.w   #2*PAN_TOL,d2
        cmp.w   -$6FE6(a5),d2           ; Y max
        ble.s   .out
        bsr.s   dz_pan_pos
        move.w  $38(a0),d0
        sub.w   #$18,d0
        jsr     DZ_SCR_D
.ym:    moveq   #1,d3
.out:   movem.l (sp)+,d1/a1-a2
        rts
dz_pan_pos:                             ; as the stock per-frame code before a scroll step (0x1DCF4)
        move.w  8(a0),$10(a0)
        move.w  $C(a0),$12(a0)
        rts

; Music: the section's cue (AUDIO_CUES.md: 0x79 desert 1, 0x7A desert 2,
; 0x04 mid-boss, 0x05 boss; without a pack the Z80 plays the aliased tune).
dz_music:
        move.w  DZ_SEC,d0
        add.w   d0,d0
        lea     dz_sec_music,a1
        move.w  0(a1,d0.w),d0
dz_cue: cmp.w   DZ_MUS,d0
        beq.s   .r
        move.w  d0,DZ_MUS
    ifd BOSS_SCENE
        jmp     dz_boss_music           ; defer a first encounter's new tune until its scene returns
    else
        jmp     DZ_SOUND
    endc
.r:     rts

    ifd BOSS_SCENE
        include "boss_music_entry.s"
    endc

; Map record DZ_MAP_I: the SCROLL3 layer object's grid, sections and
; palettes (the collision map), and dz_disp (the display map).
dz_select_map:
        move.w  DZ_MAP_I,d0
        mulu    #DZ_MAPREC,d0
        lea     dz_maps,a1
        add.w   d0,a1
        lea     -$7014(a5),a0           ; SCROLL3 layer object
        move.l  (a1)+,$1A(a0)           ; collision grid
        move.l  (a1)+,$1E(a0)           ; collision sections
        rts

; dz_pit_cells: the cells the pit's variant d2 (1-3) changes from the one before (desert_ex.pit_cells: world column,
; offset in a 64 x 64 map, display and collision entries), written where the two maps hold their column now: the
; display map's window (DZ_W0, DZ_COLS columns) and the collision map's (the stock streamer keeps the camera's column
; - 24 to + 36: written from -20 to +31). A column outside either is drawn from the record's grid when it comes in.
; In section 1 the camera's X is pinned (its bounds) while the pit opens: none is left out (DA_PITS, the gate's).
dz_pit_cells:
        movem.l d2-d7/a1-a3,-(sp)
        add.w   d2,d2
        add.w   d2,d2
        lea     dz_pit_tab,a1
        movea.l -4(a1,d2.w),a1
        move.w  (a1)+,d7
        clr.w   DA_PITW
        clr.w   DA_PITS
        move.w  CAMX(a5),d4
        asr.w   #5,d4                   ; the camera's column
        move.w  DZ_W0,d5
        bra.s   .t
.l:     move.w  (a1)+,d0                ; its world column
        move.w  (a1)+,d1                ; its offset
        move.l  (a1)+,d2
        move.l  (a1)+,d3
        move.w  d0,d6
        sub.w   d5,d6
        cmp.w   #DZ_COLS,d6
        bcc.s   .s1
        lea     DZ_MAP,a3
        move.l  d2,0(a3,d1.w)
        addq.w  #1,DA_PITW
        bra.s   .c
.s1:    addq.w  #1,DA_PITS
.c:     move.w  d0,d6
        sub.w   d4,d6
        add.w   #20,d6
        cmp.w   #52,d6
        bcc.s   .s2
        lea     $910000,a3
        move.l  d3,0(a3,d1.w)
        addq.w  #1,DA_PITW
        bra.s   .t
.s2:    addq.w  #1,DA_PITS
.t:     dbra    d7,.l
        movem.l (sp)+,d2-d7/a1-a3
        rts

; ----------------------------------------------------- display streaming
; The display map holds world columns DZ_W0 .. DZ_W0+DZ_COLS-1 (all 64
; rows: the world is one map tall). Each frame the window follows the
; camera; columns entering it are written. The stock streamer works the
; same way on the collision map (a column at a time, the full height).
dz_stream:
        cmpi.w  #DZ_MAGIC,DZ_ON
        bne.s   .r
        move.w  CAMX(a5),d0
        asr.w   #5,d0
        subq.w  #6,d0                   ; desired first column
        move.w  DZ_W0,d1
        cmp.w   d1,d0
        beq.s   .r
        bgt.s   .right
        move.w  d1,d2                   ; moving left: columns d0 .. d1-1
        sub.w   d0,d2
        cmp.w   #DZ_COLS,d2
        bcc.s   dz_draw_all
        move.w  d0,DZ_W0
.l:     bsr.s   dz_column               ; d0 = column
        addq.w  #1,d0
        cmp.w   d1,d0
        blt.s   .l
.r:     rts
.right: move.w  d0,d2                   ; moving right: columns d1+N .. d0+N-1
        sub.w   d1,d2
        cmp.w   #DZ_COLS,d2
        bcc.s   dz_draw_all
        move.w  d0,DZ_W0
        add.w   #DZ_COLS,d0
        add.w   #DZ_COLS,d1
        exg     d0,d1
.rr:    bsr.s   dz_column
        addq.w  #1,d0
        cmp.w   d1,d0
        blt.s   .rr
        rts

; the whole window from the camera
dz_draw_all:
        movem.l d0-d1,-(sp)
        move.w  CAMX(a5),d0
        asr.w   #5,d0
        subq.w  #6,d0
        move.w  d0,DZ_W0
        move.w  d0,d1
        add.w   #DZ_COLS,d1
.c:     bsr.s   dz_column
        addq.w  #1,d0
        cmp.w   d1,d0
        blt.s   .c
        movem.l (sp)+,d0-d1
        rts

; dz_column: world column d0 (32 px) into the display map, 64 rows, from
; the display record of DZ_MAP_I. Outside the world: transparent.
; Keeps d0-d1, a5. 64 entries, about 3,000 cycles.
dz_column:
        movem.l d0-d7/a0-a4,-(sp)
        move.w  d0,d3
        and.w   #63,d3
        lsl.w   #5,d3                   ; VRAM column byte offset (col & 63) * 32
        lea     DZ_MAP,a3
        add.w   d3,a3                   ; rows 0-7 of the column; +$800 per 8 rows
        move.l  #$38010000,d5           ; transparent (EX code 0x3801, as the cinematic bars' clear)
        tst.w   d0
        bmi     .blank
        cmp.w   #32*12,d0
        bcc     .blank
        move.w  DZ_MAP_I,d1
        mulu    #DZ_MAPREC,d1
        lea     dz_maps+8,a1
        add.w   d1,a1
        move.l  (a1)+,a0                ; display grid (32 x 8)
        move.l  (a1)+,a1                ; display sections (384 bytes)
        ext.l   d0
        divu    #12,d0                  ; grid column, section column
        move.w  d0,d1                   ; gx
        swap    d0                      ; sc
        lsl.w   #2,d0                   ; sc * 4
        add.w   #7*32,d1                ; grid row 7 = the top: VRAM rows 0-7
        moveq   #8-1,d7                 ; grid rows 7 .. 0
.g:     moveq   #0,d2
        move.b  0(a0,d1.w),d2           ; section number
        mulu    #384,d2
        lea     0(a1,d2.l),a2
        add.w   d0,a2
        lea     7*48(a2),a2             ; section row 7 = the top of the section
        moveq   #8-1,d6                 ; section rows 7 .. 0 -> VRAM rows down
.r:     move.l  (a2),(a3)+              ; the raw VRAM entry (code, attribute), as the stock streamer
        lea     -48(a2),a2
        dbra    d6,.r
        lea     $800-32(a3),a3          ; the next 8 VRAM rows of this column
        sub.w   #32,d1                  ; the grid row below
        dbra    d7,.g
        bra.s   .out
.blank: moveq   #64-1,d7
        moveq   #0,d6
.b:     move.l  d5,(a3)+
        addq.w  #1,d6
        cmp.w   #8,d6
        bne.s   .bn
        moveq   #0,d6
        lea     $800-32(a3),a3
.bn:    dbra    d7,.b
.out:   movem.l (sp)+,d0-d7/a0-a4
        rts

        even
        include "desert_actors.s"       ; the desert enemies (DESERT_ENEMIES.md)
        even
        include "desert_data.inc"
        even
