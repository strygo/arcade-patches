"""Audit final no-pack caption time against music and terminal picture fades."""
import argparse
import hashlib
import json
from pathlib import Path
import struct
import cinematic_followup as CF
import cinematic_timing as T
from reconstruct_private_build import decode_scene
HZ = 59.637
SPRITE_LEAD = 2
SCENES = ('brief_st_petersburg', 'brief_siberia', 'brief_amazon', 'brief_aerial', 'welcome_meio', 'intro_desert')
PAL_SLOTS = (36880, 36904)

def sha(data):
    return hashlib.sha256(data).hexdigest()

def schedule_table(bank, english):
    marker = bytes((114, int(english))) + bytes.fromhex('41f9')
    hits = [i for i in range(0, len(bank) - 16, 2) if bank[i:i + 4] == marker and bank[i + 8:i + 16] == bytes.fromhex('08390000001fffff')]
    if len(hits) != 1:
        raise ValueError('ambiguous caption selector')
    at = int.from_bytes(bank[hits[0] + 4:hits[0] + 8], 'big') - 1048576
    if not 0 <= at < len(bank) - 128:
        raise ValueError('caption table outside bank')
    return at

def schedule(bank, address):
    at = address - 1048576
    rows = []
    for _ in range(512):
        if not 0 <= at <= len(bank) - 6:
            raise ValueError('caption schedule outside bank')
        frame = int.from_bytes(bank[at:at + 2], 'big')
        if frame == 65535:
            if not rows or [r for r, _ in rows] != sorted({r for r, _ in rows}):
                raise ValueError('invalid caption schedule')
            return rows
        page = int.from_bytes(bank[at + 2:at + 6], 'big')
        if page and (not 1048576 <= page < 2097152):
            raise ValueError('caption page outside bank')
        rows.append((frame, page))
        at += 6
    raise ValueError('unterminated caption schedule')

def palette_energy(records):
    buffers = [[0] * 3072 for _ in PAL_SLOTS]
    front = 0
    live = list(buffers[0])
    result = []
    for body in records:
        for op, slot, at in T.ops(body):
            if op == 5:
                start, count = struct.unpack_from('>HH', body, at + 2)
                buffers[slot][start:start + count] = struct.unpack_from('>' + str(count) + 'H', body, at + 6)
            elif op == 9:
                front = PAL_SLOTS.index(struct.unpack_from('>H', body, at + 6)[0])
            elif op == 10:
                kind, src, dst, first, count = struct.unpack_from('>5H', body, at + 2)
                if kind == 1:
                    buffers[dst][first:first + count] = buffers[src][first:first + count]
            elif op == 11:
                live = list(buffers[front])
        picture = live[:496] + live[512:1536]
        result.append(sum((word >> shift & 15 for word in picture for shift in (0, 4, 8))))
    return result

def terminal_fade(energy, after):
    changes = [(i, e) for i, e in enumerate(energy) if i >= after and (i == 0 or e != energy[i - 1])]
    if not changes:
        return None
    start = len(changes) - 1
    while start and changes[start - 1][1] >= changes[start][1]:
        start -= 1
    tail = changes[start:]
    if len(tail) < 3:
        return None
    at = tail[0][0]
    before = energy[at - 1] if at else 0
    if tail[0][1] >= before or tail[-1][1] >= before / 2:
        return None
    return at

def audit(build, receipt):
    metadata = json.loads((build / 'build.json').read_text())
    subtitles_path = Path(__file__).resolve().parents[1] / 'manifests/subtitles.json'
    subtitles = json.loads(subtitles_path.read_text())
    rows = []
    for machine, spec in metadata['sets'].items():
        members = {n: (build / machine / n).read_bytes() for n in spec['files']}
        if any((sha(data) != spec['files'][n] for n, data in members.items())):
            raise ValueError('build bytes changed')
        bank = bytes((members['strex_p6.bin'][i ^ 1] for i in range(1048576)))
        start, size, digest = CF.NATIVE_FLOW
        if sha(bank[start:start + size]) != digest or spec['native_fade']['frames'] != 210:
            raise ValueError('unrecognized native music timing contract')
        reading = spec.get('native_reading')
        if reading:
            import cinematic_reading as C
            CF.reverse_reading(members['strex_p6.bin'], machine, 'strex_p6.bin')
            if reading['hold_frames'] != 120 or reading['pause_records'] != list(C.HOLD):
                raise ValueError('unrecognized reading pause contract')
        english = bool(spec['region_en'])
        lang = 'en' if english else 'ja'
        table = schedule_table(bank, english)
        for index, scene in enumerate(metadata['scenes']):
            sid = scene['id']
            if sid not in SCENES:
                continue
            pointer = struct.unpack_from('>I', bank, table + 8 * index + 4 * int(english))[0]
            changes = schedule(bank, pointer)
            on, page = next((row for row in reversed(changes) if row[1]))
            off = next((r for r, p in changes if r > on and (not p)), None)
            stream, records = decode_scene(bank[spec['streams'][sid] - 1048576:])
            if off is None or off > len(records):
                raise ValueError('unbounded final caption')
            fade = terminal_fade(palette_energy(records), on)
            final = [line for line in subtitles['lines'] if line['scene'] == sid and line[lang]['pages']][-1]
            music = len(records) - spec['native_fade']['frames']
            original_on, original_off, original_fade = (on, off, fade)
            pause = C.HOLD[C.SCENES.index(sid)] if reading else 0
            added = 120 if pause else 0
            if added:
                off += added
                if fade is not None and fade >= pause:
                    fade += added
                music += added
            rows.append(dict(machine=machine, scene=sid, language=lang, final_line=final['id'], final_page=final[lang]['pages'][-1], final_caption_on_record=on, final_caption_off_record=off, final_caption_seconds=round((off - on) / HZ, 3), scene_end_record=len(records) + added, music_fade_record=music, music_fade_seconds_after_caption_appears=round((music - on - SPRITE_LEAD) / HZ, 3), terminal_picture_fade_record=fade, picture_fade_seconds_after_caption_appears=round((fade - on - SPRITE_LEAD) / HZ, 3) if fade else None, source_stream_sha256=sha(stream), schedule_address=hex(pointer), source_caption_on_record=original_on, source_caption_off_record=original_off, source_picture_fade_record=original_fade, inserted_pause_record=pause, added_reading_frames=added))
    if len(rows) != 12:
        raise ValueError('both regions and all six closing scenes required')
    report = dict(schema='striderex-final-caption-audit/1', passed=True, source_kit=metadata.get('reconstructed_from_verified_export'), command='reconstruct_private_build.py --kit <sealed-kit> --out <fresh-build>; cinematic_reading_audit.py --build <fresh-build> --receipt <report>', input_files={m: s['files'] for m, s in metadata['sets'].items()}, native_helper_sha256=CF.NATIVE_FLOW[2], subtitles_sha256=sha(subtitles_path.read_bytes()), reading_helper_sha256=CF.READING_HELPER if any((s.get('native_reading') for s in metadata['sets'].values())) else None, cps1_hz=HZ, sprite_lead_frames=SPRITE_LEAD, method='Exact caption record schedules and palette-buffer terminal dimming; static byte audit, not a new runtime measurement.', changes_rom_bytes=False, hardware_review_granted=False, results=rows)
    receipt.write_text(json.dumps(report, indent=2, ensure_ascii=False) + '\n')
    for r in rows:
        print(r['machine'], r['scene'], r['final_caption_seconds'], r['music_fade_seconds_after_caption_appears'])

def main():
    import sys
    if sys.argv[1:] == ['--self-test']:
        assert terminal_fade([100, 100, 90, 70, 40, 0, 0], 1) == 2
        assert terminal_fade([100, 90, 70, 40, 80, 100, 100], 1) is None
        assert terminal_fade([100] * 10, 1) is None
        print('Final caption audit self-test PASS')
        return
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--build', type=Path, required=True)
    p.add_argument('--receipt', type=Path, required=True)
    a = p.parse_args()
    audit(a.build, a.receipt)
if __name__ == '__main__':
    main()
