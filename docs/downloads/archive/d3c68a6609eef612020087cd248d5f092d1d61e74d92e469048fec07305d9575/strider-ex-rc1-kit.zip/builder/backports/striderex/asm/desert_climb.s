; Reuse native ceiling travel, wall climbing and corner-to-floor transitions.
; Flat metal beams need a corner for the native +$29 (41px) turn probe.
        org $1F5000
        dc.w $4EF9
        dc.l dc_ceiling
        dc.w $4EF9
        dc.l dc_wall

dc_ceiling:
        cmpi.b #5,$FF0CB2
        bne .native
        btst #3,$FF0C7C               ; Up: round the nearest end of this beam.
        beq .native
        move.w $FF0C7C,-(sp)
        movem.l d0-d2/a1,-(sp)
        bsr dc_beam
        beq.s .skip
        move.b $FF0C7C,d0
        and.w #3,d0                  ; honour a held horizontal direction
        bne.s .direction
        move.w 8(a0),d0
        sub.w d1,d0                  ; d1 = midpoint
        bpl.s .right
        moveq #2,d0
        bra.s .direction
.right: moveq #1,d0
.direction:
        move.b $FF0C7C,d2
        and.b #$F0,d2
        or.b d0,d2
        move.b d2,$FF0C7C
        movem.l (sp)+,d0-d2/a1
        jsr CEILING
        move.w (sp)+,$FF0C7C
        rts
.skip:  movem.l (sp)+,d0-d2/a1
        addq.l #2,sp
.native:jmp CEILING

dc_wall:
        cmpi.b #5,$FF0CB2
        bne .native
        jsr WALL
        cmpi.b #2,2(a0)              ; never replace a hurt/death transition
        bne .done
        cmpi.b #4,3(a0)
        beq.s .floor
        cmpi.b #12,3(a0)
        bne .done
        cmpi.b #6,4(a0)
        bne .done
.floor:
        cmpi.w #1,$FFF930
        bne .done
        cmpi.w #5598,8(a0)
        bcs .done
        cmpi.w #6458,8(a0)
        bhi .done
        cmpi.w #1599,12(a0)
        bcs .done
        cmpi.w #1631,12(a0)
        bcc .done
        ; A wall pose may put the feet inside the pipeline deck. Resolve
        ; that penetration against its restored floor through the native
        ; probe. The cap, 49px higher, is outside this probe's reach.
        movem.l d0-d7/a1-a3,-(sp)
        move.w 12(a0),-(sp)
        move.w $22(a0),-(sp)
        move.w $24(a0),-(sp)
        move.w #1633,12(a0)
        jsr $1A3E.w
        bcc.s .miss
        add.w d0,12(a0)
        addq.l #6,sp
        clr.w 14(a0)
        clr.b 3(a0)
        clr.b 4(a0)
        clr.b 5(a0)
        clr.b $4D(a0)
        clr.b $5B(a0)
        move.b #$FF,$16(a0)
        move.b #$FF,$33(a0)
        bra.s .restore
.miss:  move.w (sp)+,$24(a0)
        move.w (sp)+,$22(a0)
        move.w (sp)+,12(a0)
.restore:
        movem.l (sp)+,d0-d7/a1-a3
.done:  rts
.native:jmp WALL

dc_beam:
        ; Bounds match the encoded, restored flat handholds.
        lea dc_beams,a1
        moveq #BEAM_COUNT-1,d0
.next:  move.w 12(a0),d1
        cmp.w 4(a1),d1
        bne.s .advance
        move.w 8(a0),d1
        cmp.w (a1),d1
        bcs.s .advance
        cmp.w 2(a1),d1
        bcc.s .advance
        move.w (a1),d1
        add.w 2(a1),d1
        lsr.w #1,d1
        moveq #1,d0
        rts
.advance:
        addq.l #6,a1
        dbra d0,.next
        moveq #0,d0
        rts
dc_beams:
