"""Strider EX desert enemies (DESERT_ENEMIES.md): the PC Engine actors in the arcade engine."""
import argparse
import json
import struct
import sys
from pathlib import Path
import numpy as np
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import cps1_gfx as G
import pce_desert_actors as PA
ROOT = HERE.parents[2]
MANIFEST = ROOT / 'backports/striderex/manifests/desert_actors.json'
CODES = (45312, 47327)
FORMAT = 28
FORMAT_ATTR = 32
SHAPE_SOLDIER = 179
SHAPE_SMALL = 0
SHAPE_WIDE = 21
SHAPE_JEEP = 223
SHAPE_HIRYU = 28
PAN_MARGIN = 8
SHAPES = {SHAPE_SOLDIER: ((-8, 32, 6, 3), (104, 592, 32, 320), (0, -32)), SHAPE_HIRYU: ((-24, 32, 2, 3), (24, 432, 32, 320), (0, -32)), SHAPE_SMALL: ((-8, 8, 0, 0), (8, 400, 8, 272), (8, -8)), SHAPE_WIDE: ((-32, 64, 5, 4), (64, 512, 64, 384), (0, -32)), SHAPE_JEEP: ((-40, 24, 11, 1), (152, 704, 16, 288), (0, -32))}
PAL_SLOTS = {13: 3, 1: 4, 0: 6, 12: 7, 4: 8, 3: 9, 6: 18, 8: 18, 14: 19, 10: 28}
RUNTIME_SLOTS = {7: 29}
PAL_ALIAS = {5: (1, {5: 15, 10: 7, 11: 8, 12: 9})}
SHARED_PENS = {6: (1, 6), 8: (9, 14)}
SHARED_SLOTS = (0, 1, 2, 5, 13, 14, 15, 22, 24)
ENEMY_SLOTS = (3, 4, 6, 7, 8, 9, 18, 19, 28, 29)
KINDS = [dict(name='soldier', type=68, anims=[0, 1, 2, 3], shape=SHAPE_SOLDIER, facing=True), dict(name='bullet', type=7, anims=[0], shape=SHAPE_SMALL, facing=False), dict(name='grenade', type=104, anims=[0], shape=SHAPE_SMALL, facing=True), dict(name='smoke', type=104, anims=[1], shape=SHAPE_SMALL, facing=False), dict(name='generator', type=None, anims=[], shape=SHAPE_SMALL, facing=False), dict(name='bazooka', type=65, anims=[0, 1], shape=SHAPE_SOLDIER, facing=True), dict(name='rocket', type=66, anims=[0], shape=SHAPE_SMALL, facing=True), dict(name='mine', type=67, anims=[0, 1, 2], shape=SHAPE_WIDE, facing=True), dict(name='drone', type=11, anims=[0, 1, 2], shape=SHAPE_WIDE, facing=False), dict(name='wave', type=None, anims=[], shape=SHAPE_SMALL, facing=False), dict(name='item', type=None, anims=[], shape=SHAPE_SMALL, facing=False), dict(name='worm', type=64, anims=[0], shape=SHAPE_SOLDIER, facing=True), dict(name='robot', type=25, anims=[], seqs='dome', shape=SHAPE_WIDE, facing=False), dict(name='leg', type=25, anims=[], seqs='legs', shape=SHAPE_WIDE, facing=False), dict(name='beam', type=26, anims=[], seqs='beam', shape=SHAPE_WIDE, facing=True), dict(name='segment', type=26, anims=[], seqs='beam', shape=SHAPE_WIDE, facing=True), dict(name='flame', type=118, anims=[0, 1], shape=SHAPE_WIDE, facing=False), dict(name='jeep', type=72, anims=[], seqs='frames', shape=SHAPE_JEEP, facing=True), dict(name='gunner', type=73, anims=[], seqs='frames', shape=SHAPE_JEEP, facing=True), dict(name='officer', type=69, anims=[], seqs='frames', shape=SHAPE_WIDE, facing=True), dict(name='grain', type=71, anims=[], seqs='frames', frames=(0, 4), shape=SHAPE_WIDE, facing=True), dict(name='ball', type=71, anims=[], seqs='frames', frames=(4, 7), yflip=True, shape=SHAPE_WIDE, facing=True), dict(name='needle', type=71, anims=[], seqs='frames', frames=(7, 10), shape=SHAPE_WIDE, facing=True), dict(name='pull', type=None, anims=[], shape=SHAPE_SMALL, facing=False), dict(name='commander', type=76, anims=[], seqs='frames', shape=SHAPE_WIDE, facing=True), dict(name='tank', type=None, anims=[], shape=SHAPE_SMALL, facing=False), dict(name='part', type=74, anims=[], seqs='frames', shape=SHAPE_JEEP, facing=True), dict(name='shell', type=75, anims=[], seqs='frames', frames=(0, 3), yflip=True, shape=SHAPE_WIDE, facing=True), dict(name='strip', type=110, anims=[], seqs='frames', block=(3, 4), shape=SHAPE_JEEP, facing=False)]
KIND = {k['name']: i for i, k in enumerate(KINDS)}
MAP_KINDS = {68: KIND['soldier'], 65: KIND['bazooka'], 67: KIND['mine'], 5: KIND['item'], 64: KIND['worm'], 25: KIND['robot'], 118: KIND['flame']}
ITEM_KINDS = {1: 8, 2: 1, 3: 2, 4: 3, 5: 0, 7: 4, 8: 5, 10: 6, 11: 7}
CAPSULE_KINDS = range(14)
CAPSULE_NEVER = (9,)

def manifest():
    return json.loads(MANIFEST.read_text())

def widen_frame(img, origin):
    """PC Engine frame (color ids, 0 transparent) and its top-left offset -> the widened image and"""
    import pce_desert_convert as PC
    x0, y0 = origin
    if x0 % 2:
        img = np.pad(img, ((0, 0), (1, 0)))
        x0 -= 1
    if img.shape[1] % 2:
        img = np.pad(img, ((0, 0), (0, 1)))
    w = PC.widen(img.astype(np.int32))
    assert w.shape == (img.shape[0], img.shape[1] * 3 // 2)
    return (w, (x0 * 3 // 2, y0))

def cut(img, origin):
    """16x16 tiles of a widened frame on the grid offset with the fewest non-empty tiles:"""
    best = None
    h, w = img.shape
    for gy in range(16):
        for gx in range(16):
            H, W = (-(-(h + gy) // 16) * 16, -(-(w + gx) // 16) * 16)
            p = np.zeros((H, W), img.dtype)
            p[gy:gy + h, gx:gx + w] = img
            t = p.reshape(H // 16, 16, W // 16, 16).transpose(0, 2, 1, 3)
            used = t.any((2, 3))
            n = int(used.sum())
            if best is None or n < best[0]:
                best = (n, gx, gy, t, used)
    n, gx, gy, t, used = best
    out = []
    for r, c in zip(*np.nonzero(used)):
        out.append((origin[0] - gx + 16 * c, origin[1] - gy + 16 * r, t[r, c]))
    return out

def slot_of(palette):
    return PAL_SLOTS.get(palette, RUNTIME_SLOTS.get(palette, ('pce', palette)))

def arc_slot(palette):
    """The arcade OBJ slot a PC Engine palette is drawn in (PAL_SLOTS or RUNTIME_SLOTS)."""
    s = slot_of(palette)
    if not isinstance(s, int):
        raise SystemExit(f'desert actors: PC Engine palette {palette} has no arcade slot')
    return s

def alias(image, pals, palettes):
    """A frame's color ids and palettes with the PAL_ALIAS palettes drawn as the ones whose colors they are (checked"""
    image = np.array(image)
    for q, (to, pens_map) in PAL_ALIAS.items():
        m = (image != 0) & (image >> 4 == q)
        if not m.any():
            continue
        used = set((image[m] & 15).tolist())
        if not used <= set(pens_map) or any((palettes[q][c] != palettes[to][pens_map[c]] for c in used)):
            raise SystemExit(f"desert actors: PC Engine palette {q} colors {sorted(used)} are not palette {to}'s")
        image[m] = 16 * to + np.vectorize(lambda c: pens_map[int(c)])(image[m] & 15)
    return (image, sorted({PAL_ALIAS[p][0] if p in PAL_ALIAS else p for p in pals}))

def pens(tile, palette):
    """Color ids (16 * palette + pen) of one PC Engine palette, or of palettes sharing its arcade slot"""
    pal = tile >> 4
    used = sorted(set(pal[tile != 0].tolist()))
    if any((slot_of(q) != slot_of(palette) for q in used)):
        raise SystemExit(f'desert actors: a tile mixes PC Engine palettes of different slots ({used})')
    if len(used) > 1 or (used and used[0] in SHARED_PENS):
        for q in used:
            lo, hi = SHARED_PENS[q]
            pq = tile[(tile != 0) & (pal == q)] & 15
            if pq.size and (pq.min() < lo or pq.max() > hi):
                raise SystemExit(f'desert actors: PC Engine palette {q} uses pens outside {lo}-{hi} of its shared slot')
    return np.where(tile == 0, 15, (tile & 15) - 1).astype(np.int32)

def layers(wide):
    """A widened frame (color ids) split by arcade palette slot: [(the lowest PC Engine palette of the"""
    out, groups = ([], {})
    for pal in sorted({int(v) >> 4 for v in np.unique(wide[wide != 0])}):
        groups.setdefault(slot_of(pal), []).append(pal)
    for slot, pals in sorted(groups.items(), key=lambda g: g[1][0]):
        out.append((pals[0], np.where((wide != 0) & np.isin(wide >> 4, pals), wide, 0)))
    return out

def colors(vce):
    """16 PC Engine colors -> 16 CPS-1 words: pen k = color k + 1, pen 15 transparent."""
    return [G.cps_color(v) for v in vce[1:16]] + [61440]

def leg_frames(t5):
    """The (frame, flips) values the robot's two leg tables hold (0x72:0x9DD9, 0x9EA5: frame bits 0-5, X flip"""
    return sorted(set(t5['lg_a']) | set(t5['lg_b']))

def sequences(kind, d):
    """A kind's arcade animations: [(steps [(frame, flip bits)], ticks a step, where it goes on: a step index, or"""
    a = d['actors'][kind['type']]
    if kind.get('seqs') == 'dome':
        return [([(f, 0)], 1, 0) for f in sorted(set(d['step5']['rb_frames']))]
    if kind.get('seqs') == 'legs':
        return [([(v & 63, v >> 6 & 3)], 1, 0) for v in leg_frames(d['step5'])]
    if kind.get('seqs') == 'beam':
        return [([(0, 0)], 1, 0)]
    if kind.get('seqs') == 'frames':
        lo, hi = kind.get('frames', (0, len(a['frames'])))
        return [([(f, 2 * y)], 1, 0) for f in range(lo, hi) for y in ((0, 1) if kind.get('yflip') else (0,))]
    out = []
    for ai in kind['anims']:
        seq, again = PA.sequence(a['anims'][ai])
        out.append((seq, a['anims'][ai]['ticks'], again))
    return out
BLOCKS = {k['type']: k['block'] for k in KINDS if k.get('block')}

def block_frame(image, f, pals, block):
    """A frame that repeats one cell (the sand strip 0x6E: eight copies of a 32 x 64 cell, palette 8) drawn as block"""
    import pce_desert_convert as PC
    nx, ny = block
    cells = {(p['cell'], p['w'], p['h'], p['palette'], p['xflip'], p['yflip'], p['dy']) for p in f['pieces']}
    xs = sorted((p['dx'] for p in f['pieces']))
    w = f['pieces'][0]['w']
    if len(cells) != 1 or xs != [xs[0] + w * k for k in range(len(xs))] or w % 2 or f['origin'][0] % 2:
        raise SystemExit('desert actors: a block frame is not one cell repeated in a row')
    if len(pals) != 1:
        raise SystemExit('desert actors: a block frame mixes palettes')
    x0 = xs[0] - f['origin'][0]
    cell = np.asarray(image)[:, x0:x0 + w]
    if any(((np.asarray(image)[:, x0 + w * k:x0 + w * (k + 1)] != cell).any() for k in range(len(xs)))):
        raise SystemExit("desert actors: a block frame's copies differ")
    wide = PC.widen(np.concatenate([cell] * 3, 1).astype(np.int32))[:, w * 3 // 2:w * 3]
    if wide.shape != (16 * ny, 16 * nx):
        raise SystemExit(f'desert actors: a block cell widens to {wide.shape}, not {ny} x {nx} tiles')
    tiles = [pens(wide[16 * r:16 * r + 16, 16 * c:16 * c + 16], pals[0]) for r in range(ny) for c in range(nx)]
    return dict(wide=wide, origin=((f['origin'][0] + x0) * 3 // 2, f['origin'][1] + f['pieces'][0]['dy']), pals=pals, tiles=[], block=dict(nx=nx, ny=ny, tiles=tiles, copies=len(xs), step=w * 3 // 2))

def used_frames(d):
    """{PC Engine type: sorted frame indices} the ported kinds' animations show."""
    out = {}
    for kind in KINDS:
        if kind['type'] is None:
            continue
        for seq, _, _ in sequences(kind, d):
            out.setdefault(kind['type'], set()).update((fr for fr, _ in seq))
    return {t: sorted(v) for t, v in out.items()}

def prepare(census):
    """Decode the PC Engine actors and convert their art and animations (no codes yet). Only the"""
    d = PA.extract(census)
    man = manifest()
    for t, a in d['actors'].items():
        want = man['frame_keys'][f'{t:#04x}']
        got = [f['key'] for f in a['frames']]
        if got != want:
            raise SystemExit(f'desert actors: type {t:#04x}: frames {got} are not the pinned {want} (another census?)')
    frames = {}
    used = used_frames(d)
    for t, a in d['actors'].items():
        for f in a['frames']:
            if f['index'] not in used.get(t, ()):
                continue
            image, pals = alias(f['image'], {p['palette'] for p in f['pieces']}, d['palettes'])
            for pal in pals:
                arc_slot(pal)
            if not f['pieces']:
                frames[t, f['index']] = dict(wide=np.zeros((0, 0), np.int32), origin=(0, 0), pals=[], tiles=[])
                continue
            if t in BLOCKS:
                frames[t, f['index']] = block_frame(image, f, pals, BLOCKS[t])
                continue
            w, org = widen_frame(image, f['origin'])
            tl = [(ox, oy, pens(t16, pal), pal) for pal, img in layers(w) for ox, oy, t16 in cut(img, org)]
            frames[t, f['index']] = dict(wide=w, origin=org, pals=pals, tiles=tl)
    uniq = {}
    for k, fr in frames.items():
        for ox, oy, p, _ in fr['tiles']:
            uniq.setdefault(p.astype(np.uint8).tobytes(), p)
    boxes, frame_box = ([], {})
    for kind in KINDS:
        if kind['type'] is None:
            continue
        bx = d['actors'][kind['type']]['boxes']
        for seq, _, _ in sequences(kind, d):
            for fr, _ in seq:
                fb = bx[fr] if fr < len(bx) else []
                if len(fb) > 1:
                    raise SystemExit(f"desert actors: {kind['name']} frame {fr}: {len(fb)} hitboxes")
                b = fb[0] if fb else dict(dx=0, dy=0, hw=0, hh=0)
                box = (b['dx'] * 3 // 2, -b['dy'], -(-b['hw'] * 3 // 2), b['hh'])
                if box not in boxes:
                    boxes.append(box)
                frame_box[kind['type'], fr] = boxes.index(box)
    if len(boxes) > 64:
        raise SystemExit('desert actors: more hitboxes than $7 can index')
    return dict(decoded=d, frames=frames, tiles=list(uniq.values()), tile_keys=list(uniq), boxes=boxes, frame_box=frame_box)

def claims(cv, portraits_report):
    """The EX OBJ code ranges other parts of the build own (name -> (first, last))."""
    import subtitle_ex as SX
    import usa_slice as US
    import portrait_ex as PX
    out = dict(SX.high_water(cv))
    out['captions'] = list(SX.CAPTION_CODES)
    out['title_ending_s2'] = list(PX.TITLE_ENDING_S2)
    out['usa_split_s2'] = [US.S2_FIRST, US.S2_LAST]
    if portraits_report and portraits_report.get('enabled'):
        out['portraits'] = [int(portraits_report['codes'][0], 16), int(portraits_report['codes'][1], 16)]
    else:
        out['portraits'] = [PX.CODE_TOP - PX.SPAN * 10, PX.CODE_TOP - 1]
    return out

def install(region, act, taken):
    """Codes for the tiles (upward from CODES[0]), written into the EX region. Refuses a range that"""
    n = len(act['tiles'])
    lo, hi = (CODES[0], CODES[0] + n - 1)
    blocks = [(k, fr['block']) for k, fr in sorted(act['frames'].items()) if fr.get('block')]
    act['block_code'] = {}
    for k, b in blocks:
        base = -(-(hi + 1) // 16) * 16
        act['block_code'][k] = base
        hi = base + 16 * (b['ny'] - 1) + b['nx'] - 1
    if hi > CODES[1]:
        raise SystemExit(f'desert actors: {n} tiles do not fit {CODES[0]:#x}-{CODES[1]:#x}')
    for name, (u0, u1) in taken.items():
        if not (u1 < lo or u0 > hi):
            raise SystemExit(f'desert actor codes {lo:#x}-{hi:#x} overlap {name} {u0:#x}-{u1:#x}')
    code_of = {}
    for i, (key, p) in enumerate(zip(act['tile_keys'], act['tiles'])):
        off = G.ex_offset('obj', lo + i)
        if any(region[off:off + 128]):
            raise SystemExit(f'desert actors: EX OBJ code {lo + i:#06x} is already used')
        G.put_tile(region, off, p)
        code_of[key] = lo + i
    nblk = 0
    for k, b in blocks:
        for i, p in enumerate(b['tiles']):
            code = act['block_code'][k] + 16 * (i // b['nx']) + i % b['nx']
            off = G.ex_offset('obj', code)
            if any(region[off:off + 128]):
                raise SystemExit(f'desert actors: EX OBJ code {code:#06x} is already used')
            G.put_tile(region, off, p)
            nblk += 1
    act['codes'] = (lo, hi)
    act['code_of'] = code_of
    return dict(codes=[f'{lo:#06x}', f'{hi:#06x}'], tiles=n + nblk, bytes=128 * (n + nblk))

def frame_record(act, t, frame, fx, fy, ticks, shape, loop_to=None):
    """One frame record: format 28 (one attribute word) when the frame uses one PC Engine palette,"""
    fr = act['frames'][t, frame]
    xo, yo = SHAPES[shape][0][:2]
    pieces = []
    if fr.get('block'):
        b = fr['block']
        if fx or fy:
            raise SystemExit('desert actors: a block frame is never flipped')
        at = arc_slot(fr['pals'][0]) | b['nx'] - 1 << 8 | b['ny'] - 1 << 12
        pieces = [(fr['origin'][0] + b['step'] * k, fr['origin'][1], act['block_code'][t, frame], at) for k in range(b['copies'])]
    for ox, oy, p, pal in fr['tiles']:
        x = -ox - 16 if fx else ox
        y = -oy - 16 if fy else oy
        pieces.append((x, y, act['code_of'][p.astype(np.uint8).tobytes()], arc_slot(pal) | fx << 5 | fy << 6))
    fmt = FORMAT if len({arc_slot(q) for q in fr['pals']}) <= 1 else FORMAT_ATTR
    out = None
    rows = sorted({q[1] for q in pieces})
    for order in ((1, 0), (0, 1), 'snake'):
        if order == 'snake':
            pieces.sort(key=lambda q: (q[1], q[0] if rows.index(q[1]) % 2 == 0 else -q[0]))
        else:
            pieces.sort(key=lambda q: (q[order[0]], q[order[1]]))
        steps, px, py = ([], None, None)
        for x, y, code, at in pieces:
            sx, sy = (x - xo, y + yo)
            dx, dy = (sx, sy) if px is None else (sx - px, sy - py)
            if not (-128 <= dx < 128 and -128 <= dy < 128):
                break
            steps.append((dx & 255, dy & 255, code, at))
            px, py = (sx, sy)
        else:
            out = steps
            break
    if out is None:
        raise SystemExit(f'desert actors: type {t:#04x} frame {frame}: no piece order fits signed-byte steps')
    attr = pieces[0][3] if pieces else PAL_SLOTS[min(PAL_SLOTS)] | fx << 5 | fy << 6
    dur = 2 * ticks
    if not 1 <= dur < 128:
        raise SystemExit(f'desert actors: duration {dur}')
    return dict(fmt=fmt, shape=shape, n=len(out), flags=128 | act['frame_box'][t, frame], dur=dur | (128 if loop_to is not None else 0), attr=attr, pieces=out, loop_to=loop_to)

def animations(act):
    """{(kind, arcade anim, facing): [records]}: each animation's steps (sequences); the last loops to the"""
    d = act['decoded']
    out = {}
    for ki, kind in enumerate(KINDS):
        if kind['type'] is None:
            continue
        for ai, (seq, ticks, again) in enumerate(sequences(kind, d)):
            for facing in (0, 1):
                if isinstance(again, tuple):
                    if again[1] not in kind['anims']:
                        raise SystemExit(f"desert actors: {kind['name']}: animation {kind['anims'][ai]} goes on with {again[1]}, which is not ported")
                    to = f"da_a{ki}_{kind['anims'].index(again[1])}_{facing}_0"
                else:
                    to = f'da_a{ki}_{ai}_{facing}_{again}'
                recs = []
                for si, (fr, flip) in enumerate(seq):
                    fx = flip & 1 ^ (facing if kind['facing'] else 0)
                    fy = flip >> 1 & 1
                    last = si == len(seq) - 1
                    recs.append(frame_record(act, kind['type'], fr, fx, fy, ticks + (1 if last and isinstance(again, tuple) else 0), kind['shape'], loop_to=to if last else None))
                out[ki, ai, facing] = recs
    return out

def frame_entries(act):
    """Sprite entries per drawn frame (the sprite list budget is 256)."""
    return {f'{t:#04x}/{i}': len(fr['tiles']) or fr.get('block', {}).get('copies', 0) for (t, i), fr in act['frames'].items()}

def obj_block(stock_block, pce_palettes):
    """The desert's 1 KB OBJ palette block: St. Petersburg area 1's, the ported PC Engine palettes"""
    if len(stock_block) != 1024:
        raise SystemExit('desert actors: the stand-in palette block is not 1 KB')
    words = list(struct.unpack('>512H', stock_block))
    for pce, slot in PAL_SLOTS.items():
        if slot not in ENEMY_SLOTS:
            raise SystemExit(f"desert actors: slot {slot} is not one of St. Petersburg's enemy slots")
        c = colors(pce_palettes[pce])
        if pce in SHARED_PENS:
            lo, hi = SHARED_PENS[pce]
            words[16 * slot + lo - 1:16 * slot + hi] = c[lo - 1:hi]
            words[16 * slot + 15] = c[15]
        else:
            words[16 * slot:16 * slot + 16] = c
    return struct.pack('>512H', *words)

def arc_x(x):
    return x * 3 // 2

def arc_y(y):
    return 2047 - y

def capsule_kind(item):
    """A PC Engine item id -> the arcade capsule kind (ITEM_KINDS); refuses one without a mapping."""
    if item not in ITEM_KINDS:
        raise SystemExit(f'desert actors: PC Engine item {item} has no arcade capsule')
    k = ITEM_KINDS[item]
    if k not in CAPSULE_KINDS or k in CAPSULE_NEVER:
        raise SystemExit(f'desert actors: capsule kind {k} is not one to place')
    return k

def container_rests(map_lists, origins, section_maps, masks, h=None):
    """{(section, once id): arcade Y} of each map-list item container: where the PC Engine's comes to"""
    rest = (h or {}).get('it_rest', 9)
    out = {}
    for sec, recs in map_lists.items():
        for r in recs:
            if r['type'] != 5:
                continue
            name = section_maps[sec]
            x0, y0 = origins[name]
            col = masks[name][r['y'] - y0:, r['x'] - x0]
            below = np.nonzero(col)[0]
            if not len(below):
                raise SystemExit(f"desert actors: no floor below the container at {r['x']}, {r['y']}")
            floor = r['y'] + int(below[0])
            y = floor - (rest - 1) if floor - r['y'] >= rest else r['y']
            out[sec, r['once_id']] = arc_y(y) + 8
    return out

def pce_floor_distance(col, y):
    """The PC Engine floor test's result (0x6191) for one map column of a class's solid mask (rows from"""
    t, base = (y & 15, y - (y & 15))
    top = np.nonzero(col[base:base + 16])[0]
    if len(top) and top[0] >= t:
        return int(top[0]) - t
    nxt = np.nonzero(col[base + 16:base + 32])[0]
    return 16 - t + (int(nxt[0]) if len(nxt) else 16)

def worm_chains(map_lists, origins, section_maps, masks, h, limit=32):
    """{(section, once id): arches} of each map-list sandworm: how many arches the floor lets its chain"""
    pa, pb = (h['sw_probe_a'], h['sw_probe_b'])
    if pa['mask'] != pb['mask'] or pa['dy'] != pb['dy'] or pa['want'] != pb['want'] or h['sw_child_dy']:
        raise SystemExit("desert actors: the sandworm's floor probes changed shape")
    out = {}
    for sec, recs in map_lists.items():
        for r in recs:
            if r['type'] != 64:
                continue
            name = section_maps[sec]
            x0, y0 = origins[name]
            fwd = -1 if r['flags'] & 1 else 1
            x, n = (r['x'], 1)
            while n < limit and all((pce_floor_distance(masks[name][:, x + fwd * q['dx'] - x0], r['y'] + q['dy'] - y0) == q['want'] for q in (pa, pb))):
                x += fwd * h['sw_child_dx']
                n += 1
            out[sec, r['once_id']] = n
    return out

def spawn_data(act, dec_script, rests=None, chains=None, robots=None, walls=None):
    """The section scripts' placements and the map-list actors per section. Spawn list 0 (section 0's"""
    d = act['decoded']
    placed = {s: [x for st in dec_script[s]['states'] for x in st['steps'] if x['op'] == 'spawn_object'] for s in range(len(dec_script))}
    gens = [x for x in placed.get(0, []) if x['type'] == '0x0F']
    waves = {s: [x for x in v if x['type'] == '0x13'] for s, v in placed.items()}
    lists = {}
    for s, recs in d['map_lists'].items():
        lists[s] = [(MAP_KINDS[r['type']], capsule_kind(r['param']) if r['type'] == 5 else r['flags'] & 1 | (chains or {}).get((s, r['once_id']), 1) << 1 if r['type'] == 64 else r['flags'] & 1, r['once_id'], arc_x(r['x']), (rests or {}).get((s, r['once_id']), arc_y(r['y']))) for r in recs if r['type'] in MAP_KINDS]
    generators = [(KIND['generator'], x['param'], x['once_id'], arc_x(x['x']), arc_y(x['y'])) for x in gens]
    spawn = [list(generators), []]
    for s, li in ((0, 0), (2, 1)):
        if len(waves.get(s, [])) != (1 if dec_script[0]['states'] else 0):
            raise SystemExit(f'desert actors: section {s} places {len(waves.get(s, []))} wave managers')
        spawn[li] += [(KIND['wave'], x['param'], 255, 0, 0) for x in waves.get(s, [])]
    jeeps = [x for st in (dec_script[3]['states'] if len(dec_script) > 3 else []) for x in st['steps'] if x['op'] == 'spawn_actor' and x['type'] == '0x48']
    if len(jeeps) != (1 if dec_script[0]['states'] else 0) or any((x['x'] & 1 for x in jeeps)):
        raise SystemExit(f'desert actors: section 3 places {len(jeeps)} jeeps (or one on an odd X)')
    spawn.append([(KIND['jeep'], x['flags'] & 1, x['once_id'], arc_x(x['x']), arc_y(x['y'])) for x in jeeps])
    s1 = [x for x in (dec_script[1]['states'][0]['steps'] if len(dec_script) > 1 and dec_script[1]['states'] else []) if x['op'] == 'spawn_actor']
    if dec_script[0]['states'] and ([x['type'] for x in s1] != ['0x45', '0x58'] or any((x['x'] & 1 for x in s1))):
        raise SystemExit(f"desert actors: section 1 places {[x['type'] for x in s1]}, not the officer and the pull")
    s1_kind = dict((('0x45', KIND['officer']), ('0x58', KIND['pull'])))
    spawn.append([(s1_kind[x['type']], x['flags'] & 1, x['once_id'], arc_x(x['x']), arc_y(x['y'])) for x in s1])
    s4 = [x for x in (dec_script[4]['states'][0]['steps'] if len(dec_script) > 4 and dec_script[4]['states'] else []) if x['op'] == 'spawn_actor']
    if dec_script[0]['states'] and ([x['type'] for x in s4] != ['0x4C', '0x4A', '0x6E'] or any((x['x'] & 1 for x in s4))):
        raise SystemExit(f"desert actors: section 4 places {[x['type'] for x in s4]}, not the commander, the tank, the strip")
    s4_kind = {'0x4C': KIND['commander'], '0x4A': KIND['tank'], '0x6E': KIND['strip']}
    spawn.append([(s4_kind[x['type']], x['flags'] & 1, x['once_id'], arc_x(x['x']), arc_y(x['y'])) for x in s4])
    return dict(generators=generators, spawn_lists=spawn, map_lists=lists, robot_area=robots, jeep_walls=walls)
CAM_Y = 240

def win_x(lo, hi):
    """A PC Engine window lo < x - camX < hi -> the arcade [d2, d3) of da_window."""
    return (lo * 3 // 2 + 1, hi * 3 // 2)

def win_y(lo, hi):
    """A PC Engine window lo < y - camY < hi (Y down) -> the arcade [d4, d5] of da_window (Y up)."""
    return (CAM_Y - hi + 1, CAM_Y - lo - 1)

def step2_equates(h):
    """asm equates for the bazooka soldier, its rocket and the mine, from the PC Engine handlers'"""
    if h['bz_child'] != 66 or not h['rk_hit']:
        raise SystemExit("desert actors: the bazooka soldier's child or the rocket's hit rule changed")
    for k, want in (('bz_colflags', 192), ('rk_colflags', 192), ('mn_colflags', 128)):
        if h[k] != want:
            raise SystemExit(f'desert actors: {k} is {h[k]:#04x}, not {want:#04x}')
    if h['bz_knock_vx'] != [1536, -1536]:
        raise SystemExit(f"desert actors: the bazooka soldier's knockback {h['bz_knock_vx']}")
    c = h['scr_cx']
    if h['scr_cy'] != c:
        raise SystemExit('desert actors: the on-screen test is not centered the same way in X and Y')
    x0, x1 = win_x(c - h['scr_h'], c + h['scr_h'])
    y0, y1 = win_y(c - h['scr_h'], c + h['scr_h'])
    return dict(DA_BZ_AIM=h['bz_aim'], DA_BZ_FIRE=h['bz_fire'], DA_BZ_KNOCK=h['bz_knock'], DA_BZ_RDX=h['bz_rocket_dx'] * 3 // 2, DA_BZ_RDY=-h['bz_rocket_dy'], DA_SCR_X0=x0, DA_SCR_X1=x1, DA_SCR_Y0=y0, DA_SCR_Y1=y1, DA_RK_VX=h['rk_vx'] * 3 * 256 // 4, DA_RK_RIGHT=h['rk_right'] * 3 // 2, DA_RK_LEFT=h['rk_left'] * 3 // 2, DA_MN_DY=h['mn_dy'], DA_MN_TOLY=h['mn_tol_y'], DA_MN_DX=h['mn_dx'] * 3 // 2, DA_MN_TOLX=h['mn_tol_x'] * 3 // 2, DA_MN_WARN=h['mn_warn'], DA_MN_BLAST=h['mn_blast'], DA_MN_RIGHT=h['mn_right'] * 3 // 2, DA_MN_LEFT=h['mn_left'] * 3 // 2)
DRONE_SPEEDS = ('dr_glide_speed', 'dr_home_speed', 'dr_entry_speed')

def step3_equates(h, t):
    """asm equates for the drone and the wave manager (pce_desert_actors HANDLER_SHAPES, step3_tables)."""
    want = dict(dr_colflags=200, dr_item_bits=240, dr_item_type=5, dr_item_dx=0, dr_item_open=3, wm_kind_at=36, wm_type=11, dr_vy_phase=192, dr_turn_neg=-h['dr_turn_pos'])
    bad = {k: (h[k], v) for k, v in want.items() if h[k] != v}
    if bad:
        raise SystemExit(f"desert actors: the drone's or the wave manager's code changed: {bad}")
    if t['knock_vx'] != [1536, -1536]:
        raise SystemExit(f"desert actors: the drone's knockback {t['knock_vx']}")
    if h['dr_band_top'] != 0 or h['dr_box_top'] >= 0:
        raise SystemExit("desert actors: the drone's screen bands changed shape")
    return dict(DA_DR_ENTRY_BIT=h['dr_entry_bit'], DA_DR_ITEM_DY=-h['dr_item_dy'], DA_DR_EXIT_DX=h['dr_entry_exit_dx'] * 3 // 2, DA_DR_ABOVE=CAM_Y - h['dr_band_top'], DA_DR_BELOW=CAM_Y - h['dr_band_bottom'], DA_DR_LEFT=h['dr_band_left'] * 3 // 2, DA_DR_RIGHT=h['dr_band_right'] * 3 // 2, DA_DR_BOX_X0=h['dr_box_left'] * 3 // 2, DA_DR_BOX_X1=h['dr_box_right'] * 3 // 2, DA_DR_BOX_Y0=CAM_Y - h['dr_box_bottom'] + 1, DA_DR_BOX_Y1=CAM_Y - h['dr_box_top'], DA_DR_CLOSE_X=h['dr_close_dx'] * 3 // 2, DA_DR_CLOSE_Y=h['dr_close_dy'], DA_DR_TURN=h['dr_turn_pos'], DA_DR_HOME_T=h['dr_home_timer'], DA_DR_GLIDE_T=h['dr_glide_timer'], DA_DR_DEATH_T=h['dr_death_timer'], DA_DR_A_HOME=h['dr_home_anim'], DA_DR_A_GLIDE=h['dr_glide_anim'], DA_DR_A_ENTRY=h['dr_entry_anim'], DA_DR_GLIDE=0, DA_DR_HOME=1, DA_DR_ENTRY=2, DA_WM_DY=CAM_Y - h['wm_spawn_dy'], DA_WM_LEFT=h['wm_left_dx'] * 3 // 2, DA_WM_RIGHT=h['wm_right_dx'] * 3 // 2, DA_RANK_MASK=h['wm_rank_mask'], DA_RANK_FRAMES=2 * PA.rank_strip_tick(t['rank'], t['difficulty']))

def drone_velocity(h, t):
    """da_dr_vel: per speed (DRONE_SPEEDS) and heading sector (heading >> 4, 0 = up, clockwise) the"""
    out = []
    for name in DRONE_SPEEDS:
        sp = h[name]
        if sp & 143 or not sp:
            raise SystemExit(f'desert actors: drone speed {sp:#x}')
        row = t['velocity'][(sp >> 4) - 1]

        def v(sector):
            return -row[sector & 7] if sector & 8 else row[sector & 7]
        out.append([(v(i) * 3 * 256 // 4, -v(i + 12 & 15) * 256 // 2) for i in range(16)])
    return out

def wave_scripts(t):
    """da_wave_scripts: the PC Engine wave scripts (0x6C:0x8326) as (op, value) word pairs. Ops as the"""
    ops = {'end': 0, 'wait': 1, 'wait_until_a': 2, 'wait_until_b': 3, 'y': 4, 'x': 5, 'spawn_left': 6, 'spawn_right': 7}
    out = {}
    for p, script in t['waves'].items():
        rows = []
        for o in script:
            op = ops[o['op']]
            if op == 4:
                rows.append((op | (256 if o['value'] else 0), arc_y(o['value'])))
            elif op == 5:
                rows.append((op | (256 if o['value'] else 0), arc_x(o['value'])))
            elif op == 1:
                rows.append((op, 2 * o['value']))
            elif op in (6, 7):
                rows.append((op, o['kind']))
            else:
                rows.append((op, 0))
        out[p] = rows
    return out

def item_table():
    """da_item_kind: the PC Engine item id (a drone's kind >> 4) -> the arcade capsule kind, 0xFF none."""
    return [ITEM_KINDS.get(i, 255) for i in range(16)]

def step4_equates(h):
    """asm equates for the sandworm (pce_desert_actors HANDLER_SHAPES): timers in ticks (the asm doubles"""
    want = dict(sw_colflags=192, sw_child_type=64, sw_child_dy=0, sw_child_k=1, sw_follow=3)
    bad = {k: (h[k], v) for k, v in want.items() if h[k] != v}
    if bad:
        raise SystemExit(f"desert actors: the sandworm's code changed: {bad}")
    return dict(DA_SW_SURFACE=h['sw_surface'], DA_SW_PERIOD=h['sw_period'], DA_SW_HITS=h['sw_hits'], DA_SW_DEATH_T=h['sw_death_timer'], DA_SW_DX=h['sw_child_dx'] * 3 // 2, DA_SW_STOP=h['sw_stop_dx'] * 3 // 2, DA_SW_CX=128 * 3 // 2)

def step5_equates(h, t):
    """asm equates for the robot, its legs and beam, and the valve flame (pce_desert_actors HANDLER_SHAPES,"""
    want = dict(rb_colflags=192, rb_layer=4, rb_beam_type=26, rb_beam_parts=2, bm_part_type=26, bm_part_colflags=128, fl_colflags=128, rb_rest_dy=4, rb_debris=3, rb_speed=[16, -16], rb_fire_dy2=h['rb_fire_dy'], rb_beam_dx_l=-h['rb_beam_dx_r'], lg_dx_b=-h['lg_dx_a'], lgb_probe=h['lg_probe'], lgb_probe2=h['lg_probe2'], rb_vel_probe=h['rb_snap'], rb_wall_l=h['rb_wall_r'])
    bad = {k: (h[k], v) for k, v in want.items() if h[k] != v}
    if bad:
        raise SystemExit(f"desert actors: the robot's, its beam's or the flame's code changed: {bad}")
    if t['rb_knock_vx'] != [1536, -1536] or t['rb_heading'] != [64, 192]:
        raise SystemExit(f"desert actors: the robot's knockback {t['rb_knock_vx']} or headings {t['rb_heading']}")
    st = t['bm_step']
    if [st[h2 >> 4] for h2 in t['rb_heading']] != [16, -16] or [st[(h2 + 192 & 255) >> 4] for h2 in t['rb_heading']] != [0, 0] or [t['bm_frame'][h2 >> 4] for h2 in t['rb_heading']] != [0, 64]:
        raise SystemExit("desert actors: the beam's step or frame table changed")
    if h['rb_drop_r']['dy'] != h['rb_drop_l']['dy'] or h['rb_drop_r']['mask'] != h['rb_drop_l']['mask'] or h['rb_drop_r']['want'] != h['rb_drop_l']['want'] or h['rb_snap']['dx'] or h['rb_wall_r']['dx'] or h['rb_wall_r']['dy'] or h['lg_probe']['dx'] or h['lg_probe2']['dx'] or (h['lg_probe']['mask'] != h['rb_snap']['mask']) or (h['lg_probe2']['mask'] != h['rb_snap']['mask']) or (h['rb_drop_r']['mask'] != h['rb_snap']['mask']):
        raise SystemExit("desert actors: the robot's probes changed shape")
    return dict(DA_RB_WAIT0=h['rb_wait0'], DA_RB_WALK=h['rb_walk'], DA_RB_WAIT1=h['rb_wait1'], DA_RB_HOLD=h['rb_hold'], DA_RB_REST=h['rb_rest'], DA_RB_FIRE_DY=h['rb_fire_dy'], DA_RB_SPIN_T=h['rb_spin_period'], DA_RB_AIM_R=h['rb_aim_right'], DA_RB_AIM_L=h['rb_aim_left'], DA_RB_HITS=h['rb_hits'], DA_RB_KNOCK=h['rb_knock'], DA_RB_SPEED=h['rb_speed'][0], DA_RB_MASK=h['rb_snap']['mask'], DA_RB_SNAP_DY=h['rb_snap']['dy'], DA_RB_REST_DY=h['rb_rest_dy'], DA_RB_WALL_MASK=h['rb_wall_r']['mask'], DA_RB_WALL_WANT=h['rb_wall_r']['want'], DA_RB_DROP_DY=h['rb_drop_r']['dy'], DA_RB_DROP_R=h['rb_drop_r']['dx'], DA_RB_DROP_L=h['rb_drop_l']['dx'], DA_RB_DROP_WANT=h['rb_drop_r']['want'], DA_LG_DX=h['lg_dx_a'], DA_LG_DY=h['lg_dy'], DA_LG_PROBE1=h['lg_probe']['dy'], DA_LG_PROBE2=h['lg_probe2']['dy'], DA_LG_WANT=h['lg_probe']['want'], DA_LG_AX=h['lg_dx_a'] * 3 // 2, DA_LG_AXL=-h['lg_dx_a'] * 3 // 2, DA_LG_AY=h['lg_dy'], DA_BM_SPAWN_DX=h['rb_beam_dx_r'] * 3 // 2, DA_BM_SPAWN_DY=-h['rb_beam_dy'], DA_BM_DX=t['bm_step'][t['rb_heading'][0] >> 4] * 3 // 2, DA_BM_LIFE=h['bm_life'], DA_BM_PERIOD=h['bm_period'], DA_BM_PIECES=h['rb_beam_parts'], DA_FL_PERIOD=h['fl_period'], DA_FL_ANIM=h['fl_burst_anim'])

def sfx_commands():
    """{PC Engine PSG effect: arcade sound command} (manifests/pce_sfx.json, pce_sfx.py)."""
    import pce_sfx as PS
    return {int(e['pce_psg'], 16): int(e['command'], 16) for e in PS.manifest()['effects']}

def sfx_equates(h):
    """Reconstruction helper."""
    cmd = sfx_commands()
    if h['rb_step_gate'] != 2 or not h['anim_psg'] or h['sfx_near'][0] != h['sfx_near'][1]:
        raise SystemExit("desert actors: the sounds' code changed (the walk's gate, 0xF9 or the near test)")
    for v in (h['rb_step_sfx'], h['rb_beam_sfx']):
        if v not in cmd:
            raise SystemExit(f'desert actors: PSG effect {v:#04x} has no command in pce_sfx.json')
    return dict(DA_SND_RB_WALK=cmd[h['rb_step_sfx']], DA_SND_RB_FIRE=cmd[h['rb_beam_sfx']], DA_RB_STEP_T=h['rb_step_period'], DA_NEAR_X=h['sfx_near'][1] * 3 // 2, DA_NEAR_Y=h['sfx_near'][0])

def anim_sfx(d):
    """{kind index: per arcade animation (anim * 2 + facing) the command its PC Engine script plays as it loops}:"""
    cmd = sfx_commands()
    out = {}
    for ki, kind in enumerate(KINDS):
        if kind['type'] is None or kind.get('seqs') or (not kind.get('anims')):
            continue
        a = d['actors'][kind['type']]
        row = []
        for ai in kind['anims']:
            steps = a['anims'][ai]['steps']
            snd = [k for k, s in enumerate(steps) if s.get('cmd', '').startswith(('psg', 'adpcm'))]
            if not snd:
                row.append(0)
                continue
            if snd != [len(steps) - 2] or steps[-1].get('cmd') != 'loop' or steps[-2]['cmd'] != 'psg_sfx' or (steps[-2]['arg'] not in cmd):
                raise SystemExit(f"desert actors: {kind['name']} animation {ai}: a sound the port does not play ({steps})")
            row.append(cmd[steps[-2]['arg']])
        if any(row):
            out[ki] = [c for c in row for _ in (0, 1)]
    if set(out) - {KIND['drone']}:
        raise SystemExit(f"desert actors: animation sounds in kinds {sorted(out)}: only the drone's are ported")
    return out

def robot_velocity(t):
    """da_rb_v: per floor direction d (a floor class's flags & 7) the robot's walking velocity to the right"""
    row = t['rb_vel'][1]

    def v(i):
        return -row[i & 7] if i & 8 else row[i & 7]
    return [(v(d), v(d + 4)) for d in range(8)]

def robot_tick(col, h, t, st, legs=True):
    """One tick of a walking robot in the PC Engine's own terms (an independent model of what asm/desert_actors.s"""
    x, y = (st['x'] >> 8, st['y'] >> 8)
    if st['dir'] == 0:
        turn = col.wall_right(x, y, h['rb_wall_r']['mask'])[0] < h['rb_wall_r']['want'] or col.floor(x + h['rb_drop_r']['dx'], y + h['rb_drop_r']['dy'], h['rb_drop_r']['mask'])[0] >= h['rb_drop_r']['want']
    else:
        turn = col.wall_left(x, y, h['rb_wall_l']['mask'])[0] < h['rb_wall_l']['want'] or col.floor(x + h['rb_drop_l']['dx'], y + h['rb_drop_l']['dy'], h['rb_drop_l']['mask'])[0] >= h['rb_drop_l']['want']
    if turn:
        st['dir'] ^= 1
    vx, vy = robot_velocity(t)[col.floor(x, y + h['rb_snap']['dy'], h['rb_snap']['mask'])[1] & 7]
    if st['dir']:
        vx, vy = (-vx, -vy)
    st['x'] += vx
    st['y'] += vy
    x, y = (st['x'] >> 8, st['y'] >> 8)
    d = col.floor(x, y + h['rb_snap']['dy'], h['rb_snap']['mask'])[0]
    st['y'] += max(-h['rb_rest_dy'], min(h['rb_rest_dy'], d - h['rb_rest_dy'])) << 8
    st['turns'] = st.get('turns', 0) + turn
    return robot_legs(col, h, st['x'] >> 8, st['y'] >> 8) if legs else None

def robot_legs(col, h, x, y):
    """Each leg's slope (0x72:0x9D50): the floor's flags & 7 at the leg (X +- 3, Y + 12) DA_LG_PROBE1 above, or"""
    out = []
    for dx in (h['lg_dx_a'], h['lg_dx_b']):
        lx, ly = (x + dx, y + h['lg_dy'])
        d, fl = col.floor(lx, ly + h['lg_probe']['dy'], h['lg_probe']['mask'])
        if d >= h['lg_probe']['want']:
            d, fl = col.floor(lx, ly + h['lg_probe2']['dy'], h['lg_probe2']['mask'])
        out.append(fl & 7)
    return out

def robot_area(col, d, margin=1):
    """The PC Engine collision data of the area the section 2 robots walk (desert_ex.pce_collision, section 2's"""
    h, t = (d['handlers'], d['step5'])
    robots = [r for r in d['map_lists'][2] if r['type'] == 25]
    if not robots or any((r['flags'] & 1 or r['x'] & 1 for r in robots)):
        raise SystemExit('desert actors: a section 2 robot faces left or stands on an odd X')
    col.seen = set()
    for r in robots:
        for d0 in (0, 1):
            st = dict(x=r['x'] << 8, y=r['y'] << 8, dir=d0)
            for _ in range(40):
                y = st['y'] >> 8
                dist = col.floor(st['x'] >> 8, y + h['rb_snap']['dy'], h['rb_snap']['mask'])[0]
                st['y'] += max(-h['rb_rest_dy'], min(h['rb_rest_dy'], dist - h['rb_rest_dy'])) << 8
                robot_legs(col, h, st['x'] >> 8, st['y'] >> 8)
            for _ in range(20000):
                robot_tick(col, h, t, st)
                if st.get('turns', 0) >= 3:
                    break
            else:
                raise SystemExit(f"desert actors: robot {r['once_id']} never turned three times")
    seen, col.seen = (col.seen, None)
    r0, r1 = (min((r for r, c in seen)) - margin, max((r for r, c in seen)) + margin)
    c0, c1 = (min((c for r, c in seen)) - margin, max((c for r, c in seen)) + margin)
    ox, oy = (col.origin[0] >> 4, col.origin[1] >> 4)
    classes = bytes((col.klass(16 * (ox + c), 16 * (oy + r)) for r in range(r0, r1 + 1) for c in range(c0, c1 + 1)))
    used = set(classes)
    if any((col.tables[k][2 * c] > 15 for k in col.tables for c in used)):
        raise SystemExit("desert actors: a class of the robots' area has a shape past 15")
    return dict(col0=ox + c0, row0=oy + r0, cols=c1 - c0 + 1, rows=r1 - r0 + 1, classes=classes, tables={k: bytes(v) for k, v in col.tables.items()}, shapes=bytes(col.shapes))

def step6_equates(h, t6):
    """asm equates for the jeep, its gunner and section 3's wait (pce_desert_actors HANDLER_SHAPES, step6_tables). The"""
    want = dict(jp_colflags=192, jp_gunner=73, jp_charge_acc_l=-h['jp_charge_acc_r'], jp_charge_max_l=-h['jp_charge_max_r'], jp_brake_l=-h['jp_brake_r'], jp_rev_acc_r=-h['jp_rev_acc_l'], jp_rev_max_r=-h['jp_rev_max_l'], jp_ahead_l=-h['jp_ahead_r'], jp_death_v_l=-h['jp_death_v_r'], gn_bullet=7, gn_parent_dead=4, jp_dead_once=h['s3_status_b'], gn_turn_set=h['gn_no_fire_frame'], jp_debris=3, jp_final=[16, 17])
    bad = {k: (h[k], v) for k, v in want.items() if h[k] != v}
    if bad:
        raise SystemExit(f"desert actors: the jeep's or its gunner's code changed: {bad}")
    wr, wl = (h['jp_wall_r'], h['jp_wall_l'])
    if wr['dy'] or wl['dy'] or wl['dx'] != -wr['dx'] or ((wl['mask'], wl['want']) != (wr['mask'], wr['want'])):
        raise SystemExit("desert actors: the jeep's wall tests changed shape")
    if len(set(t6['gn_shot_dx'])) != 1 or any((v & 1 for v in t6['jp_debris_dx'])) or t6['gn_debris_dx'][2] & 1:
        raise SystemExit("desert actors: the gunner's or the jeep's debris offsets changed")
    return dict(DA_JP_WAIT=h['jp_wait'], DA_JP_WAIT_ANIM=h['jp_wait_anim'], DA_JP_DY=h['jp_dy'], DA_JP_CHARGE_T=h['jp_charge_t'], DA_JP_REVERSE_T=h['jp_reverse_t'], DA_JP_ACC=h['jp_charge_acc_r'], DA_JP_CMAX=h['jp_charge_max_r'], DA_JP_BRAKE_T=h['jp_brake_t'], DA_JP_BRAKE=h['jp_brake_r'], DA_JP_RACC=h['jp_rev_acc_l'], DA_JP_RMAX=h['jp_rev_max_l'], DA_JP_BOUNCE_T=h['jp_bounce_t'], DA_JP_BOUNCE_ANIM=h['jp_bounce_anim'], DA_JP_BOUNCE_N=h['jp_bounce_n'], DA_JP_TURN_T=h['jp_turn_t'], DA_JP_TURN_ANIM=h['jp_turn_anim'], DA_JP_AHEAD=h['jp_ahead_r'], DA_JP_HITS=h['jp_hits'], DA_JP_DEATH_ANIM=h['jp_death_anim'], DA_JP_DEATH_T=h['jp_death_t'], DA_JP_DEATH_V=h['jp_death_v_r'], DA_JP_WRECK_ANIM=h['jp_wreck_anim'], DA_JP_DONE=h['jp_dead_once'], DA_JP_END1=h['jp_final'][0], DA_JP_END2=h['jp_final'][1], DA_GN_AIM_T=h['gn_aim_period'], DA_GN_GAP=h['gn_shot_gap'], DA_GN_BURST=h['gn_burst'], DA_GN_PAUSE=h['gn_pause'], DA_GN_NOFIRE=h['gn_no_fire_frame'], DA_GN_TURN=h['gn_turn_frame'], DA_GN_SHOT_DX=t6['gn_shot_dx'][0] * 3 // 2, DA_GN_EX_DX=t6['gn_debris_dx'][2] * 3 // 2, DA_GN_EX_DY=-t6['gn_debris_dy'][2], DA_AWAIT_A=h['s3_status_a'], DA_AWAIT_B=h['s3_status_b'])

def jeep_anims(d):
    """da_jp_anims: the jeep's PC Engine animation scripts (0x74:0x89D1, interpreter 0x68:0x53B4) as the asm steps them:"""
    out = []
    for an in d['actors'][72]['anims']:
        seq, again = PA.sequence(an)
        if isinstance(again, tuple) or any((f > 31 or flip & 2 for f, flip in seq)):
            raise SystemExit('desert actors: a jeep animation the asm does not step')
        out.append((an['ticks'], again, [f | (flip & 1) << 5 for f, flip in seq]))
    return out
HIRYU_HALF = 32

def step7_equates(h, t7, rank, difficulty, scores):
    """asm equates for the officer and antlion (0x45), its projectiles (0x47), the sand-pull controller (0x58) and the"""
    want = dict(of_layer=3, gr_layer=4, of_go=h['s1_go_status'], pl_go=h['s1_go_status'], of_wait_t=0, of_col=128, of_leap_col=192, of_land_col=128, bl_col=128, nd_col=128, of_grain_type=71, of_grain_param=0, of_ball_type=71, of_ball_param=1, bl_needle_type=71, bl_needle_param=2, of_arm_once=h['s1_go_b'], s1_wait_once=h['s1_go_a'], of_floor_set=h['of_floor'], of_leap_floor=h['of_floor'], of_flash_color=511, of_flash_n=30, of_ball_dx=0, of_blink=1, pl_arm_mask=255 ^ h['pl_arm_bit'], of_arm_bit=h['pl_arm_bit'], pl_right_x=h['pl_left_x'] + h['pl_left_w'], pl_right_w=h['pl_left_w'], pl_tol_lo=-h['pl_tol_hi'], pl_phases=6, cam_step_neg=-h['cam_step'])
    bad = {k: (h[k], v) for k, v in want.items() if h[k] != v}
    if bad:
        raise SystemExit(f"desert actors: the officer's, its projectiles' or the sand-pull's code changed: {bad}")
    if t7['of_subs'] != [32978, 33004, 33032, 33062, 33151, 33199, 33396, 33438, 33539, 33584] or t7['of_actions'] != [33181, 33378, 33409, 33500, 33563] or t7['of_die_vx'] != [0, 0] or (t7['gr_dy'] != [h['of_ball_dy']] * 8) or any(t7['nd_dx']) or any(t7['nd_dy']) or (t7['pl_drag_xf'] != [0] * 4) or (t7['pl_drag_yf'] != [0] * 4) or (t7['gr_head'] != list(range(8))) or (t7['nd_head'] != list(range(6))):
        raise SystemExit("desert actors: the officer's actions or its projectiles' tables changed shape")
    if h['of_score_bcd'] != 1280 + 512 or 1280 not in scores or 512 not in scores:
        raise SystemExit(f"desert actors: the officer's {h['of_score_bcd']:x} points are not 500 + 200")
    if (h['pit_n'], h['pit_w'], h['pit_h'], len(t7['pit'])) != (4, 26, 20, 4):
        raise SystemExit('desert actors: the pit opening changed shape')
    return dict(DA_OF_GO=h['of_go'], DA_OF_POINT_T=h['of_point_t'], DA_OF_RING_T=h['of_ring_t'], DA_OF_SINK_V=h['of_sink_v'], DA_OF_FLOOR=h['of_floor'], DA_OF_MORPH_T=h['of_morph_t'], DA_OF_IDLE_T=h['of_idle_t'], DA_OF_CLACK_T=h['of_clack_t'], DA_OF_LEAP_V=h['of_leap_v'], DA_OF_LEAP_G=h['of_leap_g'], DA_OF_BURST_N=h['of_burst_n'], DA_OF_BURST_T=h['of_burst_t'], DA_OF_BALL_T=h['of_ball_t'], DA_OF_HITS=h['of_hits'], DA_OF_DIE_V=h['of_die_v'], DA_OF_A_WAIT=h['of_wait_anim'], DA_OF_A_POINT=h['of_point_anim'], DA_OF_A_RING=h['of_ring_anim'], DA_OF_A_MORPH=h['of_morph_anim'], DA_OF_A_IDLE=h['of_idle_anim'], DA_OF_A_CLACK=h['of_clack_anim'], DA_OF_A_LEAP=h['of_leap_anim'], DA_OF_A_BURST=h['of_burst_anim'], DA_OF_A_BALL=h['of_ball_anim'], DA_OF_ARM_ONCE=h['of_arm_once'], DA_OF_ARM_BIT=h['of_arm_bit'], DA_OF_BALL_DY=h['of_ball_dy'], DA_OF_FLASH=G.cps_color(h['of_flash_color']), DA_SCORE_OF1=f'${scores[1280]:04X}', DA_SCORE_OF2=f'${scores[512]:04X}', DA_GR_LIFE=h['gr_life'], DA_GR_G=h['gr_g'], DA_GR_A=h['gr_anim'], DA_BL_V=h['bl_v'], DA_BL_G=h['bl_g'], DA_BL_RING_T=h['bl_ring_t'], DA_BL_A_RISE=h['bl_anim'], DA_BL_A_RING=h['bl_ring_anim'], DA_ND_LIFE=h['nd_life'], DA_ND_G=h['nd_g'], DA_ND_N=len(t7['nd_head']), DA_PL_GO=h['pl_go'], DA_PL_WAIT=h['pl_wait'], DA_PL_PHASES=h['pl_phases'], DA_PL_LX=h['pl_left_x'], DA_PL_W=h['pl_left_w'], DA_PL_LY=h['pl_line_y'] - HIRYU_HALF, DA_PL_RX=h['pl_right_x'], DA_PL_RY=h['pl_right_y'], DA_PL_TOL=h['pl_tol_hi'], DA_PL_LIM_L=h['pl_lim_l'], DA_PL_LIM_R=h['pl_lim_r'], DA_PL_ARM_BIT=h['pl_arm_bit'], DA_RANK0=rank['start'][difficulty], DA_RANK_FIRST=rank['first'][difficulty], DA_RANK_PERIOD=rank['period'][difficulty], DA_PAN_LO=t7['cam_band_y'][0], DA_PAN_HI=t7['cam_band_y'][1], DA_PAN_STEP=h['cam_step'] // 2, DA_PAN_HMAX=SHAPES[SHAPE_HIRYU][1][3] - SHAPES[SHAPE_HIRYU][1][2] - PAN_MARGIN, DA_PAN_HMIN=-SHAPES[SHAPE_HIRYU][1][2] + PAN_MARGIN)

def pce_anims(d, t):
    """A type's PC Engine animation scripts (the interpreter 0x68:0x53B4) as asm/desert_actors.s pa_anim steps them: per"""
    out = []
    for an in d['actors'][t]['anims']:
        seq, again = PA.sequence(an)
        if an['steps'][-1].get('cmd') == 'hold' or any((f > 31 for f, _ in seq)):
            raise SystemExit(f'desert actors: a type {t:#04x} animation the asm does not step')
        out.append((an['ticks'], 128 | again[1] if isinstance(again, tuple) else again, [f | (flip & 3) << 5 for f, flip in seq]))
    return out
HULL_SLOT = 31
HULL_MAP = (512, 512)
S2_MAP = 9486336
RIDE_KINDS = {4: 1, 2: 2}

def step8_equates(h, t8, scores):
    """asm equates for the commander (0x4C), the tank (0x4A), its parts, shells and hull, the strip (0x6E) and section 4's"""
    want = dict(cm_go=h['s4_go_status'], tk_go=h['s4_go_status'], tk_off_y=h['tk_home_y'], tk_off_x=h['tk_home_x'], tk_bob_y=h['tk_home_y'], tu_type=7, b3_type=7, sh_type=75, cs_type=75, mt_type=75, sh_param=0, cs_param=1, mt_param=2, sh_vy=0, mt_vx=0, tk_dead_mask=h['pt3_bit'], tk_dead_bit=h['pt3_bit'], hit_slash=True, mt_hit=True, s4_wait_once=h['s4_go_b'], tk_colflags=192, sh_colflags=128, mt_colflags=128, mt_colflags2=192, mt_flip=2, pt3_colflags=64, pt3_raised_bit=128, tk_blink=1, tk_restore=30, rd_add=32, cn_cmd_shell=h['cn_cmd_fire'], cn_cmd_mortar2=h['cn_cmd_mortar'], tu_cmd_shot=h['tu_cmd'], pu_screen=h['tu_screen'], tu_no_dir=16, pt0_cmd_rise=h['tk_rise_cmd'], pt1_cmd_rise=h['tk_rise_cmd'], pt2_cmd_rise=h['tk_rise_cmd'], pt0_bit=1, pt1_bit=2, pt2_bit=4, pt3_bit=8, rd_p2_d=h['rd_p1_d'] + 32, rd_p3_d=h['rd_p2_d'] + 16, rd_p3_c=h['rd_p3_d'], rd_p1_c=2 * h['rd_p1_d'], rd_p2_c=h['rd_p1_d'], rd_p4_c=0, rd_tol_lo=-h['rd_tol_hi'], st_x=255 ^ h['st_x2'], mt_n=4)
    bad = {k: (h[k], v) for k, v in want.items() if h[k] != v}
    if bad:
        raise SystemExit(f"desert actors: the tank's, its parts', the commander's or the strip's code changed: {bad}")
    if t8['tk_subs'] != [37577, 37583, 37603, 37639, 37678, 37702, 37799, 37823] or t8['cn_states'] != [37956, 37962, 37974, 38021, 38057] or t8['tu_states'] != [38098, 38104, 38125, 38164] or (t8['pt_handlers'] != [38586, 38640, 38613, 38667]) or (t8['col_parts'] != [40649, 40651, 40663, 40665]) or (t8['hit_lim'] != [0, 0, 7, 7]) or (t8['hit_dead'] != [1, 2, 4, 8]) or (t8['hit_bit'] != [16, 32, 64, 128]) or (t8['hit_clr'] != [239, 223, 191, 127]) or (set(t8['dbr_par']) != {4}) or (t8['bob_dy'] != [0, 1]) or any((x & 1 for x in t8['mt_x'])) or any((v & 65024 != 2048 for v in t8['tr_pen9'] + t8['tr_pen14'])):
        raise SystemExit("desert actors: the tank's machines or tables changed shape")
    if h['tk_score_bcd'] not in scores:
        raise SystemExit(f"desert actors: no stock score command gives {h['tk_score_bcd']:x} points")
    if (h['pt0_list'], h['pt1_list'], h['pt2_list'], h['pt3_list'], h['cm_list'], h['st_list'], h['sh_list'], h['mt_list'], h['cs_list']) != (6, 5, 6, 7, 3, 1, 7, 4, 4):
        raise SystemExit("desert actors: the tank's, its parts', the commander's or the strip's draw lists changed")
    e = dict(DA_CM_GO=h['cm_go'], DA_CM_T1=h['cm_t1'], DA_CM_A_WALK=h['cm_walk_anim'], DA_CM_WALK_T=h['cm_walk_t'], DA_CM_VX=h['cm_vx'], DA_TK_GO=h['tk_go'], DA_TK_WAIT2=h['tk_wait2'], DA_TK_WAIT3=h['tk_wait3'], DA_TK_RISE=h['tk_rise_cmd'], DA_TK_PAUSE_R=h['tk_pause_r'], DA_TK_LEFT_LIM=h['tk_left_lim'], DA_TK_LEFT_ACC=h['tk_left_acc'], DA_TK_LEFT_MAX=h['tk_left_max'], DA_TK_PAUSE_L=h['tk_pause_l'], DA_TK_RIGHT_LIM=h['tk_right_lim'], DA_TK_RIGHT_ACC=h['tk_right_acc'], DA_TK_RIGHT_MAX=h['tk_right_max'], DA_TK_HOMEX=h['tk_home_x'], DA_TK_HOMEY=h['tk_home_y'], DA_CN_WAIT=h['cn_wait'], DA_CN_SUB_FIRE=2 * h['cn_sub_fire'], DA_CN_SUB_MORTAR=2 * h['cn_sub_mortar'], DA_CN_FIRE_T=h['cn_fire_t'], DA_CN_CMD_FIRE=h['cn_cmd_fire'], DA_MT_EVERY=h['mt_every'], DA_CN_CMD_MORTAR=h['cn_cmd_mortar'], DA_CN_CMD_NONE=h['cn_cmd_none'], DA_MT_N=h['mt_n'], DA_TU_SUB=2 * h['tu_sub'], DA_TU_PERIOD=h['tu_period'], DA_TU_BURST=h['tu_burst'], DA_TU_CMD=h['tu_cmd'], DA_TU_CMD_NONE=h['tu_cmd_none'], DA_TU_SCREEN=h['tu_screen'], DA_TU_AIM_T=h['tu_aim_t'], DA_TU_FIRE_T=h['tu_fire_t'], DA_CMD_RISE=h['pt0_cmd_rise'], DA_CMD_LOWER=h['pt0_cmd_lower'], DA_CN_RECOIL_T=h['cn_recoil_t'], DA_CN_RECOIL_F=h['cn_recoil_frame'], DA_CN_BACK=h['cn_back'], DA_P3_TOP=h['pt3_top'], DA_P3_RISE_V=h['pt3_rise_v'], DA_P3_LOWER_V=h['pt3_lower'], DA_P3_FIRE_T=h['pt3_fire_t'], DA_P3_DEAD_F=h['pt3_dead_frame'], DA_P3_HITS=t8['hit_lim'][3], DA_PU_FAR=h['pu_far'], DA_PU_NEAR=h['pu_near'], DA_B3_DX=h['b3_dx'], DA_B3_DY=h['b3_dy'], DA_B3_VX=h['b3_vx'] * 192, DA_B3_VY=-h['b3_vy'] * 128, DA_SH_DX=h['sh_dx'], DA_SH_DY=h['sh_dy'], DA_SH_VX=h['sh_vx'], DA_SH_RIGHT=h['sh_right'], DA_SH_LEFT=h['sh_left'], DA_CS_G=h['cs_g'], DA_CS_FREE=h['cs_free'], DA_CS_A=h['cs_anim'], DA_MT_DX=h['mt_dx'], DA_MT_DY=h['mt_dy'], DA_MT_VY=h['mt_vy'], DA_MT_TOP=h['mt_top'], DA_MT_G=h['mt_g'], DA_MT_MAX=h['mt_max'], DA_MT_FREE=h['mt_free'], DA_MT_A=h['mt_anim'], DA_MT_NEAR=h['mt_floor']['want'], DA_TK_DIE_T=h['tk_die_t'], DA_TK_SINK=h['tk_sink'], DA_SCORE_TK=f"${scores[h['tk_score_bcd']]:04X}", DA_RD_DX=h['rd_dx'], DA_RD_W=h['rd_w'], DA_RD_DY=h['rd_dy'], DA_RD_H=h['rd_h'], DA_RD_TOL=h['rd_tol_hi'], DA_RD_D1=h['rd_p1_d'], DA_RD_D2=h['rd_p2_d'], DA_RD_D3=h['rd_p3_d'], DA_RD_FLAT=h['rd_p2_c'], DA_RD_K1=RIDE_KINDS[h['rd_p1_kind']], DA_RD_K2=RIDE_KINDS[h['rd_p2_kind']], DA_RD_K3=RIDE_KINDS[h['rd_p3_kind']], DA_RD_K4=RIDE_KINDS[h['rd_p4_kind']], DA_RD_ADD=h['rd_add'], DA_ST_MASK=h['st_x'], DA_HULL_SLOT=HULL_SLOT, DA_P10_SLOT=PAL_SLOTS[10], DA_S2_MAP=f'${S2_MAP:06X}')
    for p in range(4):
        e[f'DA_PT{p}_DY'], e[f'DA_PT{p}_DX'] = (h[f'pt{p}_dy'], h[f'pt{p}_dx'])
        e[f'DA_PT{p}_F'] = h[f'pt{p}_frame']
    for p in range(3):
        e[f'DA_PT{p}_TOP'] = h[f'pt{p}_top']
        e[f'DA_PT{p}_RV'] = h[f'pt{p}_rise_v']
    e['DA_PT_LOWER_V'] = h['pt0_lower']
    return e

def hull_tiles(act, idx, origin, bg):
    """The tank's hull (PC Engine background art moved by the tank, 0x940C: map 2's metatiles of the tank, desert_ex"""
    pals = sorted({int(v) >> 4 for v in np.unique(idx[idx != 0])})
    if len(pals) != 1:
        raise SystemExit(f'desert actors: the hull uses BG palettes {pals}, not one')
    w, org = widen_frame(np.where(idx != 0, idx, 0), origin)
    cells = []
    for ox, oy, t in cut(w, org):
        p = np.where(t == 0, 15, (t & 15) - 1).astype(np.int32)
        key = p.astype(np.uint8).tobytes()
        if key not in act['tile_keys']:
            act['tile_keys'].append(key)
            act['tiles'].append(p)
        cells.append((ox, oy, key))
    blank = np.full((16, 16), 15, np.int32)
    bkey = blank.astype(np.uint8).tobytes()
    if bkey not in act['tile_keys']:
        act['tile_keys'].append(bkey)
        act['tiles'].append(blank)
    mx = HULL_MAP[0] + int(-cells[0][0]) % 16
    my = HULL_MAP[1] + int(-cells[0][1]) % 16
    act['hull'] = dict(cells=cells, palette=pals[0], colors=colors(bg), map=(mx, my), wide=w, origin=org, blank=bkey)
    return act['hull']

def hull_map_cells(hull, code_of):
    """da_hull: per hull tile its SCROLL2 map entry's offset from the map's base (asm writes code, attribute) and code."""
    mx, my = hull['map']
    out = []
    for ox, oy, key in hull['cells']:
        x, y = (mx + ox, my + oy)
        if x % 16 or y % 16 or (not (0 <= x < 1024 and 0 <= y < 1024)):
            raise SystemExit('desert actors: a hull tile is off the SCROLL2 grid')
        col, row = (x // 16, y // 16)
        out.append((4 * ((row & 15) + (col & 63) * 16 + (row & 48) * 64), code_of[key]))
    return out

def mortar_floors(col, h, t8):
    """Each mortar shell's floor (0x74:0xA4BA, 0x5C53 -> 0x6898: the floor table's solids of mask 0xF0 scanned down three"""
    m = h['mt_floor']
    out = []
    for x in t8['mt_x']:
        top = next((y for y in range(640, 2048) if col.floor(x + m['dx'], y + m['dy'], m['mask'])[0] == 0), None)
        if top is None:
            raise SystemExit(f'desert actors: no floor below the mortar at X {x}')
        for y in range(640, top):
            dist = col.floor(x + m['dx'], y + m['dy'], m['mask'])[0]
            if dist != top - y if y > top - 32 else dist < m['want']:
                raise SystemExit(f"desert actors: the mortar's floor at X {x} is not one surface")
        out.append(top)
    return out

def jeep_walls(col, h, t6, spawn):
    """Where the jeep's wall tests fire (0x74:0x8D66: right at (X + 48, Y), left at (X - 48, Y), mask 0x80, a wall"""
    _, y = spawn
    ys, run = ({y}, 0)
    for dy in t6['jp_bounce_dy'][:h['jp_bounce_n']]:
        run += dy
        ys.add(y + run)
    lo, hi = (col.origin[0] - 128, col.origin[0] + 16 * col.cls.shape[1] + 128)
    wr, wl = (h['jp_wall_r'], h['jp_wall_l'])
    out = None
    for yy in sorted(ys):
        got = {}
        for side, test, w in (('right', col.wall_right, wr), ('left', col.wall_left, wl)):
            runs = []
            for px in range(lo, hi):
                if test(px + w['dx'], yy + w['dy'], w['mask'])[0] < w['want']:
                    if runs and runs[-1][1] == px - 1:
                        runs[-1][1] = px
                    else:
                        runs.append([px, px])
            got[side] = [tuple(r) for r in runs]
        if out is not None and got != out:
            raise SystemExit("desert actors: the jeep's wall tests differ between the Ys of its bounce")
        out = got
    if any((r[0] == lo or r[1] == hi - 1 for v in out.values() for r in v)) or not out['left']:
        raise SystemExit(f"desert actors: the jeep's walls {out} reach the scan's ends (or there is none)")
    return out

def inc_text(act, spawns, walk_speeds, scores=None):
    """desert_actors.inc: the data block (hitboxes, animation tables, frame records), the walk"""
    scores = scores or {256: SCORE, 512: SCORE + 1, 768: SCORE + 2, 1280: SCORE + 3, 1024: SCORE + 10, 5376: SCORE + 5}
    d = act['decoded']
    h, t, t5, t6 = (d['handlers'], d['step3'], d['step5'], d['step6'])
    if scores.get(256) != SCORE:
        raise SystemExit(f'desert actors: 100 points is not command {SCORE:#06x} ({scores})')
    for bcd in (h['bz_score_bcd'], h['dr_score_bcd'], h['sw_score_bcd'], h['rb_score_bcd'], h['jp_score_bcd']):
        if bcd not in scores:
            raise SystemExit(f'desert actors: no stock score command gives {bcd:x} points')
    anims = animations(act)
    names = [k['name'] for k in KINDS]
    L = ["; desert_actors_ex.py: the desert actors' data for asm/desert_actors.s", '        even', f'DA_SHAPE_SOLDIER equ {SHAPE_SOLDIER}', f'DA_SHAPE_SMALL equ {SHAPE_SMALL}', f'DA_SCORE equ ${SCORE:04X}', f"DA_SCORE_BZ equ ${scores[h['bz_score_bcd']]:04X}", f'DA_HIRYU_DY equ {HIRYU_DY}', f"DA_SCORE_DR equ ${scores[h['dr_score_bcd']]:04X}", f"DA_SCORE_SW equ ${scores[h['sw_score_bcd']]:04X}", f"DA_SCORE_RB equ ${scores[h['rb_score_bcd']]:04X}", f"DA_SCORE_JP equ ${scores[h['jp_score_bcd']]:04X}", f'DA_SHAPE_JEEP equ {SHAPE_JEEP}', f"DA_NOBOX equ {act['boxes'].index((0, 0, 0, 0))}                       ; the hitbox of a frame with none", f"DA_FL_OUT equ da_a{KIND['flame']}_0_0_0-da_blk     ; the flame's animation 0 (out): its one record"]
    L += [f'{k} equ {v}' for k, v in step2_equates(h).items()]
    L += [f'{k} equ {v}' for k, v in step3_equates(h, t).items()]
    L += [f'{k} equ {v}' for k, v in step4_equates(h).items()]
    L += [f'{k} equ {v}' for k, v in step5_equates(h, t5).items()]
    L += [f'{k} equ {v}' for k, v in step6_equates(h, t6).items()]
    t7 = d['step7']
    L += [f'{k} equ {v}' for k, v in step7_equates(h, t7, t['rank'], t['difficulty'], scores).items()]
    L += [f'{k} equ {v}' for k, v in sfx_equates(h).items()]
    area = spawns.get('robot_area') or dict(col0=0, row0=0, cols=0, rows=0, classes=b'', shapes=bytes(256), tables={k: bytes(256) for k in ('floor', 'right', 'left')})
    L += [f"DA_RB_COL0 equ {area['col0']}", f"DA_RB_ROW0 equ {area['row0']}", f"DA_RB_COLS equ {area['cols']}", f"DA_RB_ROWS equ {area['rows']}"]
    L += ['da_allow:                               ; per kind: the sections (bits) whose PC Engine sprite set allows it', '        dc.b    ' + ','.join((f'%{ALLOW[k]:05b}' for k in names)), "da_kind_shape:                          ; per kind: its frames' shape (set at init: the snap needs it)", '        dc.b    ' + ','.join((str(k['shape']) for k in KINDS)), '        even', 'da_blk:', '; hitboxes ($28 = 0): dx, dy (up), half-width, half-height']
    for b in act['boxes']:
        L.append('        dc.b    ' + ','.join((str(v & 255) for v in b)))
    L.append('; per kind: animation tables (anim * 2 + facing), words from da_blk')
    for ki, kind in enumerate(KINDS):
        L.append(f"da_anims{ki}:                             ; {kind['name']}")
        for ai in range(len(sequences(kind, d)) if kind['type'] is not None else 0):
            for facing in (0, 1):
                L.append(f'        dc.w    da_a{ki}_{ai}_{facing}_0-da_blk')
    for (ki, ai, facing), recs in sorted(anims.items()):
        for si, r in enumerate(recs):
            L.append(f'da_a{ki}_{ai}_{facing}_{si}:')
            L.append(f"        dc.b    {r['fmt']},{r['shape']},0,{r['n']},${r['flags']:02X},${r['dur']:02X}")
            if r['fmt'] == FORMAT:
                L.append(f"        dc.w    ${r['attr']:04X}")
                for dx, dy, code, _ in r['pieces']:
                    L.append(f'        dc.b    ${dx:02X},${dy:02X}')
                    L.append(f'        dc.w    ${code:04X}')
            else:
                for dx, dy, code, at in r['pieces']:
                    L.append(f'        dc.w    ${at:04X}')
                    L.append(f'        dc.b    ${dx:02X},${dy:02X}')
                    L.append(f'        dc.w    ${code:04X}')
            if r['loop_to']:
                L.append(f"        dc.w    {r['loop_to']}-da_blk")
    L.append('        even')
    sfx = anim_sfx(d)
    L.append('da_dr_sfx:                              ; the drone, per animation (anim * 2 + facing): the command its PC Engine script plays as the animation loops, 0 none (anim_sfx)')
    L.append('        dc.b    ' + ','.join((f'${v:02X}' for v in sfx[KIND['drone']])))
    L.append('        even')
    L.append('da_kind_anims:                          ; per kind: its animation table')
    L.append('        dc.l    ' + ','.join((f'da_anims{ki}' for ki in range(len(KINDS)))))
    L.append('da_walk_speed:                          ; per floor kind ($22 0-7): X speed (16.16 px/frame)')
    L.append('        dc.l    ' + ','.join((f'${v:X}' for v in walk_speeds)))
    g = act['decoded']['generator']
    L.append("da_gen_ids:                             ; the generator's once-id lists (parameter 0, 1)")
    for ids in g['ids']:
        L.append('        dc.b    ' + ','.join((str(v) for v in ids)))
    L.append('da_gen_timers:                          ; spawn period per step (frames: 2 x the ticks)')
    L.append('        dc.b    ' + ','.join((str(min(2 * v, 255)) for v in g['timers'])))
    L.append('        even')
    L.append('da_dr_vel:                              ; per speed (glide, home, entry), heading >> 4: X, Y (16.16/frame)')
    for blk in drone_velocity(h, t):
        L.append('        dc.l    ' + ','.join((f'{vx},{vy}' for vx, vy in blk)))
    L.append('da_dr_entry:                            ; the entry direction (sector) by the screen bands, $FF: glide')
    L.append('        dc.b    ' + ','.join((f'${v:02X}' for v in t['entry_dir'])))
    L.append('da_atan:                                ; the direction to Hiryu: (dX & 7) * 8 + (dY & 7), $10 none')
    L.append('        dc.b    ' + ','.join((f'${v:02X}' for v in t['atan'])))
    L.append('da_item_kind:                           ; the PC Engine item (kind >> 4) -> capsule kind, $FF none')
    L.append('        dc.b    ' + ','.join((f'${v:02X}' for v in item_table())))
    L.append('        even')
    L.append('da_rb_v:                                ; per floor direction (flags & 7): vX, vY walking right (8.8/tick, Y down)')
    L.append('        dc.w    ' + ','.join((f'{vx},{vy}' for vx, vy in robot_velocity(t5))))
    domes = sorted(set(t5['rb_frames']))
    L.append("da_rb_dome:                             ; per dome phase: the robot's animation (its frame, 0x72:0x9D0A)")
    L.append('        dc.b    ' + ','.join((str(domes.index(v)) for v in t5['rb_frames'])))
    legs = leg_frames(t5)
    for name, key, at in (('da_rb_lega', 'lg_a', 40409), ('da_rb_legb', 'lg_b', 40613)):
        L.append(f"{name}:                             ; per slope * 4 + step: the leg's animation (0x72:{at:#06x})")
        L.append('        dc.b    ' + ','.join((str(legs.index(v)) for v in t5[key])))
    L.append("da_rb_map:                              ; the robots' area: class bytes, DA_RB_ROWS x DA_RB_COLS metatiles")
    for r in range(area['rows']):
        L.append('        dc.b    ' + ','.join((f'${v:02X}' for v in area['classes'][r * area['cols']:(r + 1) * area['cols']])))
    for name, key in (('da_rb_floor', 'floor'), ('da_rb_wallr', 'right'), ('da_rb_walll', 'left')):
        L.append(f"{name}:                            ; the PC Engine {key} test's table: per class (shape, flags)")
        for i in range(0, 256, 32):
            L.append('        dc.b    ' + ','.join((f'${v:02X}' for v in area['tables'][key][i:i + 32])))
    L.append('da_rb_shapes:                           ; the PC Engine shapes (0x69:0x6398): 16 bytes each, $80 up none')
    for i in range(0, 256, 32):
        L.append('        dc.b    ' + ','.join((f'${v:02X}' for v in area['shapes'][i:i + 32])))
    L.append('        even')
    ja = jeep_anims(d)
    L.append('da_jp_anims:                            ; per jeep animation: its script (words from da_jp_anims)')
    L.append('        dc.w    ' + ','.join((f'da_jp_an{i}-da_jp_anims' for i in range(len(ja)))))
    for i, (ticks, again, steps) in enumerate(ja):
        L.append(f'da_jp_an{i}:                              ; ticks a step, steps, the step it loops to; frame | X flip << 5')
        L.append(f'        dc.b    {ticks},{len(steps)},{again}')
        L.append('        dc.b    ' + ','.join((f'${v:02X}' for v in steps)))
    L.append('        even')
    walls = spawns.get('jeep_walls') or dict(right=[], left=[])
    for name, side in (('da_jp_wallr', 'right'), ('da_jp_walll', 'left')):
        L.append(f"{name}:                            ; PC Engine X where the jeep's {side} wall test fires: count, (from, to)")
        L.append(f'        dc.w    {len(walls[side])}' + ''.join((f',{a},{b}' for a, b in walls[side])))
    L.append("da_jp_debris:                           ; the death drive's debris (facing right): X, Y (arcade, up)")
    L.append('        dc.w    ' + ','.join((f'{dx * 3 // 2},{-dy}' for dx, dy in zip(t6['jp_debris_dx'], t6['jp_debris_dy']))))
    L.append('da_gn_shot:                             ; per gunner frame (X flip set): bullet Y, vX, vY (16.16/frame, up)')
    for f in range(2):
        L.append(f"        dc.w    {-t6['gn_shot_dy'][f]}")
        L.append(f"        dc.l    {t6['gn_shot_vx'][f] * 192},{-t6['gn_shot_vy'][f] * 128}")
    L.append('da_gn_dy:                               ; per jeep frame: the gunner above the jeep (arcade px)')
    L.append('        dc.b    ' + ','.join((str(-v & 255) for v in t6['gn_dy'])))
    L.append('da_gn_aim:                              ; per direction to Hiryu (facing right): frame, $80 fire (0x74:0x908B)')
    L.append('        dc.b    ' + ','.join((f'${v:02X}' for v in t6['gn_aim'])))
    L.append("da_jp_shake:                            ; the bounce's Y shake per tick (PC Engine px, down; 0x74:0x8CE9)")
    L.append('        dc.b    ' + ','.join((str(v & 255) for v in t6['jp_bounce_dy'][:h['jp_bounce_n']])))
    L.append('        even')
    for name, typ in (('da_of_anims', 69), ('da_pj_anims', 71)):
        sc = pce_anims(d, typ)
        L.append('        even')
        L.append(f'{name}:                            ; per animation of type {typ:#04x}: its script (words from {name})')
        L.append('        dc.w    ' + ','.join((f'{name}{i}-{name}' for i in range(len(sc)))))
        for i, (ticks, again, steps) in enumerate(sc):
            L.append(f'{name}{i}:                     ; ticks a step, steps, where it goes on ($80 | n: animation n); frame | X flip << 5 | Y flip << 6')
            L.append(f'        dc.b    {ticks},{len(steps)},${again:02X}')
            L.append('        dc.b    ' + ','.join((f'${v:02X}' for v in steps)))
    L.append('        even')
    L.append('da_of_rank:                             ; the officer: its pattern by rank (0x74:0x8207)')
    L.append('        dc.b    ' + ','.join((str(v) for v in t7['of_rank_pat'])))
    L.append('da_of_pats:                             ; its patterns (words from da_of_pats): the actions, $FF ends')
    L.append('        dc.w    ' + ','.join((f'da_of_pat{i}-da_of_pats' for i in range(len(t7['of_patterns'])))))
    for i, pat in enumerate(t7['of_patterns']):
        L.append(f'da_of_pat{i}:')
        L.append('        dc.b    ' + ','.join((str(v) for v in pat)) + ',$FF')
    L.append("da_of_dbr:                              ; its death's debris (0x74:0x8507): ticks, entry; $FF ends")
    L.append('        dc.b    ' + ','.join((f'{a},{b}' for a, b in t7['dbr_script'])) + ',$FF')
    L.append('da_of_dbr_xy:                           ; a debris entry: X (arcade, facing right), Y (arcade, up)')
    L.append('        dc.b    ' + ','.join((f'{dx * 3 // 2 & 255},{-dy & 255}' for dx, dy in zip(t7['dbr_dx'], t7['dbr_dy']))))
    L.append('        even')
    L.append("da_gr_tab:                              ; a burst's grain by heading: dX, dY (PC Engine, down), facing, 0, vX, vY (8.8 px/tick, down)")
    for i in range(8):
        L.append(f"        dc.b    {t7['gr_dx'][i] & 255},{t7['gr_dy'][i] & 255},{t7['gr_face'][i]},0")
        L.append(f"        dc.w    {t7['gr_vx'][i]},{t7['gr_vy'][i]}")
    L.append("da_nd_tab:                              ; the ball's needle by heading: animation, facing, 0, 0, vX, vY")
    for i in range(len(t7['nd_head'])):
        L.append(f"        dc.b    {t7['nd_anim'][i]},{t7['nd_face'][i]},0,0")
        L.append(f"        dc.w    {t7['nd_vx'][i]},{t7['nd_vy'][i]}")
    L.append("da_of_pal7:                             ; the officer's colors (PC Engine palette 7) for its slot (RUNTIME_SLOTS)")
    L.append('        dc.w    ' + ','.join((f'${v:04X}' for v in colors(d['palettes'][7]))))
    L.append(f'DA_OF_SLOT equ {RUNTIME_SLOTS[7]}')
    L.append(f'DA_AL_SLOT equ {PAL_SLOTS[14]}')
    L.append(f"DA_OF_BLACK equ ${G.cps_color(0):04X}                ; the death's blink (PC Engine color 0, 0x8597)")
    L.append(f"DA_PL_ARM_N equ {h['pl_arm_bit'].bit_length() - 1}")
    for name, k in (('DA_GR_F0', 'grain'), ('DA_BL_F0', 'ball'), ('DA_ND_F0', 'needle')):
        L.append(f"{name} equ {KINDS[KIND[k]]['frames'][0]}")
    L.append("da_al_pal:                              ; the antlion's colors (PC Engine palette 14; restored after a flash)")
    L.append('        dc.w    ' + ','.join((f'${v:04X}' for v in colors(d['palettes'][14]))))
    L.append("da_pl_period:                           ; the sand-pull: the cycle's period (ticks) by strength (0 still)")
    L.append('        dc.b    ' + ','.join((str(v) for v in t7['pl_period'])))
    L.append('da_pl_arm:                              ; its strength byte on a re-arm, by rank')
    L.append('        dc.b    ' + ','.join((str(v) for v in t7['pl_arm'])))
    L.append('da_pl_cycle:                            ; its 6 cycled colors (CPS-1) by phase')
    for ph in t7['pl_cycle']:
        L.append('        dc.w    ' + ','.join((f'${G.cps_color(v):04X}' for v in ph)))
    L.append("da_pl_drag:                             ; its drag by strength: Hiryu's X a frame (16.16, toward the middle; the PC Engine's px a tick x 1.5 / 2)")
    L.append('        dc.l    ' + ','.join((str(v * 3 * 65536 // 4) for v in t7['pl_drag_x'])))
    cyc = spawns.get('cycle') or []
    L.append("da_pl_pens:                             ; the flowing sand's SCROLL3 palettes: count, the address of each one's first cycled pen (6 in a row)")
    L.append(f'        dc.w    {len(cyc)}')
    for a in cyc:
        L.append(f'        dc.l    ${a:06X}')
    L.append('        even')
    t8 = d['step8']
    L += [f'{k} equ {v}' for k, v in step8_equates(h, t8, scores).items()]
    for name, typ in (('da_cm_anims', 76), ('da_sh_anims', 75)):
        sc = pce_anims(d, typ)
        L.append('        even')
        L.append(f'{name}:                            ; per animation of type {typ:#04x}: its script (words from {name})')
        L.append('        dc.w    ' + ','.join((f'{name}{i}-{name}' for i in range(len(sc)))))
        for i, (ticks, again, steps) in enumerate(sc):
            L.append(f'{name}{i}:                     ; ticks a step, steps, where it goes on; frame | X flip << 5 | Y flip << 6')
            L.append(f'        dc.b    {ticks},{len(steps)},${again:02X}')
            L.append('        dc.b    ' + ','.join((f'${v:02X}' for v in steps)))
    L.append('        even')
    L.append('da_tu_aim:                              ; the turret: its aim by direction to Hiryu (0x74:0x9B68): $80 fires, bit 0 low')
    L.append('        dc.b    ' + ','.join((f'${v:02X}' for v in t8['tu_aim'])))
    L.append('da_tu_frames:                           ; its frame by aim: idle (0x9B78), firing (0x9BBA)')
    L.append('        dc.b    ' + ','.join((str(v) for v in t8['tu_idle'] + t8['tu_firef'])))
    L.append('da_tu_shot:                             ; its shot (0x07) by aim: dX, dY (PC Engine, down, from the turret), vX, vY (16.16 a frame, Y up)')
    for a in range(2):
        L.append(f"        dc.w    {t8['tu_dx'][a]},{t8['tu_dy'][a]}")
        L.append(f"        dc.l    {t8['tu_vx'][a] * 192},{-t8['tu_vy'][a] * 128}")
    L.append('da_cs_tab:                              ; its casing (0x4B parameter 1) by aim: dX, dY (PC Engine, down), vX, vY (8.8 px/tick)')
    for a in range(2):
        L.append(f"        dc.w    {t8['cs_dx'][a]},{t8['cs_dy'][a]},{t8['cs_vx'][a]},{t8['cs_vy'][a]}")
    L.append("da_tk_dbr:                              ; its death's debris (0x74:0xA037): ticks, entry; $FF ends")
    L.append('        dc.b    ' + ','.join((f'{a},{b}' for a, b in t8['dbr_script'])) + ',$FF')
    L.append('da_tk_dbr_xy:                           ; a debris entry: X (arcade), Y (arcade, up)')
    L.append('        dc.b    ' + ','.join((f'{dx * 3 // 2 & 255},{-dy & 255}' for dx, dy in zip(t8['dbr_dx'], t8['dbr_dy']))))
    L.append("da_tr_period:                           ; the treads' period (ticks) by (|vX hi| & 15) >> 1 (0x74:0xA150)")
    L.append('        dc.b    ' + ','.join((str(v) for v in t8['tr_period'])))
    L.append("da_bob_period:                          ; the bob's period (ticks) by |vX hi| & 15 (0x74:0xA1C5)")
    L.append('        dc.b    ' + ','.join((str(v) for v in t8['bob_period'])))
    L.append('da_bob_dy:                              ; its Y from the home by phase')
    L.append('        dc.b    ' + ','.join((str(v) for v in t8['bob_dy'])))
    L.append('        even')
    L.append("da_tr_cols:                             ; the treads' two pens by phase (CPS-1): color 9, color 14 (BG palette 8 at 0x74:0xA158)")
    L.append('        dc.w    ' + ','.join((f'${G.cps_color(a & 511):04X},${G.cps_color(b & 511):04X}' for a, b in zip(t8['tr_pen9'], t8['tr_pen14']))))
    mf = spawns.get('mortar_floors') or [0] * len(t8['mt_x'])
    L.append("da_mt_tab:                              ; the mortar shells' fixed X and their floor's top (PC Engine; mortar_floors)")
    L.append('        dc.w    ' + ','.join((f'{x},{y}' for x, y in zip(t8['mt_x'], mf))))
    L.append(f'DA_HIRYU_HALF equ {HIRYU_HALF}')
    L.append("da_tk_pf:                               ; the tank's parts' first frames (0x9626: parts 0-3)")
    L.append('        dc.b    ' + ','.join((str(h[f'pt{p}_frame']) for p in range(4))))
    L.append('        even')
    L.append("da_tk_pxy:                              ; per part its X (arcade) and Y (PC Engine, down) from the tank's (0x97C4..: part 3 on part 2)")
    pxy = [(h['pt0_dx'], h['pt0_dy']), (h['pt1_dx'], h['pt1_dy']), (h['pt2_dx'], h['pt2_dy']), (h['pt2_dx'] + h['pt3_dx'], h['pt2_dy'] + h['pt3_dy'])]
    L.append('        dc.w    ' + ','.join((f'{dx * 3 // 2},{dy}' for dx, dy in pxy)))
    L.append('da_tk_hclr:                             ; per part the mask that clears its hit bit (0x9EAF)')
    L.append('        dc.b    ' + ','.join((f'${v:02X}' for v in t8['hit_clr'])))
    L.append('        even')
    L.append("da_p10_pal:                             ; PC Engine palette 10 (the tank's parts, its shells) for its slot")
    L.append('        dc.w    ' + ','.join((f'${v:04X}' for v in colors(d['palettes'][10]))))
    hull = act.get('hull')
    L.append("da_hull_pal:                            ; the hull's BG palette (its SCROLL2 palette DA_HULL_SLOT)")
    L.append('        dc.w    ' + ','.join((f'${v:04X}' for v in (hull['colors'] if hull else [0] * 16))))
    cells = hull_map_cells(hull, act['code_of']) if hull and act.get('code_of') else []
    mx, my = hull['map'] if hull else (0, 0)
    L.append(f"DA_S2X0 equ {mx}                        ; SCROLL2 X = camera X - the hull's X + this; Y = camera Y - its Y + DA_S2Y0")
    L.append(f'DA_S2Y0 equ {1023 - my}')
    blank = act['code_of'][hull['blank']] if hull and act.get('code_of') else 0
    L.append(f'DA_S2_BLANK equ ${blank:04X}                ; a transparent tile: the rest of the SCROLL2 map')
    L.append('da_hull:                                ; its tiles: count, (SCROLL2 map offset, code)')
    L.append(f'        dc.w    {len(cells)}')
    for off, code in cells:
        L.append(f'        dc.w    ${off:04X},${code:04X}')
    L.append('        even')
    ws = wave_scripts(t)
    L.append('da_wave_scripts:                        ; per wave-manager parameter: its script (op, value)')
    L.append('        dc.l    ' + ','.join((f'da_ws{p}' for p in sorted(ws))))
    for p in sorted(ws):
        L.append(f'da_ws{p}:')
        for op, v in ws[p]:
            L.append(f'        dc.w    ${op:04X},{v}')
    L.append('da_spawn_lists:                         ; dz_sections op 9 (actors k): the spawn lists')
    L.append('        dc.l    ' + ','.join((f'da_spawn{k}' for k in range(len(spawns['spawn_lists'])))))
    for k, li in enumerate(spawns['spawn_lists']):
        L.append(f'da_spawn{k}:                              ; kind, param, id, X, Y')
        L.append(f'        dc.w    {len(li)}')
        for kd, f, i, x, y in li:
            L.append(f'        dc.b    3,{kd},{f},{i}')
            L.append(f'        dc.w    {x},{y}')
    L.append('da_maplists:                            ; per section: its map-list actors')
    L.append('        dc.l    ' + ','.join((f'da_ml{s}' for s in range(5))))
    for s in range(5):
        L.append(f'da_ml{s}:')
        L.append(f"        dc.w    {len(spawns['map_lists'][s])}")
        for k, f, i, x, y in spawns['map_lists'][s]:
            L.append(f'        dc.b    3,{k},{f},{i}')
            L.append(f'        dc.w    {x},{y}')
    L.append('        even')
    return '\n'.join(L) + '\n'

def walk_speeds(sine):
    """Arcade X speed per floor kind (the snap's $22): flat (1) = the PC Engine's 4 px/tick (16-direction"""
    entry = {0: 4, 1: 4, 2: 3, 3: 2, 4: 4, 5: 1, 6: 2, 7: 3}
    return [sine[entry[k]] * 3 * 65536 // (2 * 2 * 256) for k in range(8)]
ROUTINES = {'DA_RECFILL': '42a90002337c01000000135a0017135a0006135a0016135a0021335a0008335a000c4e75', 'DA_FREE5': '286de9be29082b4ce9be526de9de', 'DA_ALLOC5': '4a6de9de6712286de9be225c2b4ce9be536de9de', 'DA_ALLOC6': '4a6de9e06712286de9c2225c2b4ce9c2536de9e0', 'DA_ALLOC7': '4a6de9e26712286de9c6225c2b4ce9c6536de9e2', 'DA_LISTA': '6100????670e286de40a29082b4ce40a526de3e4', 'DA_LISTC': '6100????670e286de41229082b4ce412526de3e8', 'DA_ONSCREEN': '700010280010e748287c????????49f4000032280008926d8ff4', 'DA_ANIM_SET': '4880d040303400003140001231400014117c00010011', 'DA_ANIM_STEP': '53280011660000e63028001431400012', 'DA_HIT_ATTACK': '0c2b00060002670000ac2268001a', 'DA_HIT_HIRYU': '0c2b0006000267f22268001a', 'DA_SPARK': '48e7004048e7000848e700042a7c00ff80004eb8????65000034137c00010000137c001f0017', 'DA_SND_DEATH': '303c004f6000', 'DA_SND_SHOT': '303c004e6000', 'DA_SND_MISSILE': '303c00546000', 'DA_SND_BLAST': '303c00456000', 'DA_SCORES': '00000010000000500000010000000200000003000000050000001000000015000000200000005000', 'DA_EMIT': '10280001670000ea10280000670000e230280012', 'DA_POOL5_LOOP': '41eda11a3e3c001d48474a28000067046100000e'}
SNAP = '06680005000c4eb9????????640000044e750468000a000c'
POOL5_BASE = 16720154
SCORE = 1538
HIRYU_DY = 0
ALLOW = {'soldier': 5, 'bullet': 31, 'grenade': 1, 'smoke': 1, 'generator': 1, 'bazooka': 5, 'rocket': 5, 'mine': 5, 'drone': 5, 'wave': 5, 'item': 31, 'worm': 1, 'robot': 4, 'leg': 4, 'beam': 4, 'segment': 4, 'flame': 4, 'jeep': 24, 'gunner': 8, 'officer': 2, 'grain': 2, 'ball': 2, 'needle': 2, 'pull': 2, 'commander': 16, 'tank': 16, 'part': 16, 'shell': 16, 'strip': 16}
FORMAT32_CODE = '956d8c8c534243e90006361910194880da4010194880dc403819'
FORMAT32_SIZE = '720012360003d2413401d241d2425c41'

def locate(img):
    """Every stock address asm/desert_actors.s needs in one region's program, and the pool-5"""
    import desert_ex as DX
    s = {name: DX.find1(img, pat, name) for name, pat in ROUTINES.items()}
    sends = {s[n] + 6 + (DX.be16(img, s[n] + 6) ^ 32768) - 32768 for n in ('DA_SND_DEATH', 'DA_SND_SHOT', 'DA_SND_MISSILE', 'DA_SND_BLAST')}
    if len(sends) != 1 or img[min(sends):min(sends) + 2] != b'J-':
        raise SystemExit(f'desert actors: the sound setters branch to {sorted(map(hex, sends))}')
    s['DA_SOUND'] = sends.pop()
    fill = s.pop('DA_RECFILL')
    stub = fill - 40
    if img[stub:stub + 2] != b'N\xb8' or DX.be16(img, stub + 2) != s['DA_ALLOC5'] or img[stub + 4:stub + 10] != bytes.fromhex('640000224e75'):
        raise SystemExit('desert actors: the pool-5 spawn stub has an unexpected shape')
    s['DA_FILL5'] = stub
    stub7 = fill - 30
    if img[stub7:stub7 + 2] != b'N\xb8' or DX.be16(img, stub7 + 2) != s['DA_ALLOC7'] or img[stub7 + 4:stub7 + 10] != bytes.fromhex('640000184e75'):
        raise SystemExit('desert actors: the pool-7 spawn stub has an unexpected shape')
    s['DA_FILL7'] = stub7
    snaps = [a for a in DX.find(img, SNAP) if DX.be32(img, a + 8) + 34 in DX.SET_ROUTINES['B'] and len(DX.find(img, f'4eb8{a:04x}') + DX.find(img, f'4eb9{a:08x}')) >= 5]
    if len(snaps) != 1:
        raise SystemExit(f'desert actors: {len(snaps)} floor snaps')
    s['DA_SNAP'] = snaps[0]
    s['DA_PROBE_TABLE'] = DX.be32(img, DX.be32(img, snaps[0] + 8) + 2)
    loop = s.pop('DA_POOL5_LOOP')
    if img[loop + 32:loop + 52] != bytes.fromhex('2c68001a70001028 0017d040d040227b00044ed1'.replace(' ', '')):
        raise SystemExit('desert actors: the pool-5 dispatch has an unexpected shape')
    table = loop + 52
    types = [DX.be32(img, table + 4 * t) for t in range(50)]
    dead = types[3]
    if img[dead:dead + 2] != b'Nu' or types.count(dead) != 1:
        raise SystemExit(f'desert actors: pool 5 type 3 ({dead:#x}) is not a dead rts slot')
    s['site_pool5_type3'] = table + 12
    s['DA_TYPE3_STOCK'] = dead
    s['DA_SHAPES'] = DX.be32(img, s['DA_EMIT'] + 64)
    if img[s['DA_EMIT'] + 62:s['DA_EMIT'] + 64] != b'$|':
        raise SystemExit("desert actors: the emitter's shape table operand moved")
    s['DA_BOXES'] = DX.be32(img, s['DA_ONSCREEN'] + 10)
    emit_tab, step_tab = (s['DA_EMIT'] + 116, s['DA_ANIM_STEP'] + 50)
    if img[emit_tab - 6:emit_tab] != bytes.fromhex('2c7b00044ed6') or img[step_tab - 6:step_tab] != bytes.fromhex('287b10044ed4'):
        raise SystemExit("desert actors: the emitter's or the animation step's format table moved")
    f32 = DX.be32(img, emit_tab + 4 * 8)
    if img[f32:f32 + len(FORMAT32_CODE) // 2] != bytes.fromhex(FORMAT32_CODE) or img[DX.be32(img, step_tab + FORMAT_ATTR):][:len(FORMAT32_SIZE) // 2] != bytes.fromhex(FORMAT32_SIZE):
        raise SystemExit('desert actors: frame format 32 is not the per-piece-attribute free list')
    s['DA_FORMAT32'] = f32
    return s
SCORE_ENTRIES = 16

def score_commands(img, s):
    """{BCD points: the stock score command 0x06nn} from the region's table (DA_SCORES, SCORE_ENTRIES"""
    out = {}
    for i in range(SCORE_ENTRIES):
        v = img[s['DA_SCORES'] + 4 * i:][:4]
        if any((b >> 4 > 9 or b & 15 > 9 for b in v)):
            raise SystemExit(f'desert actors: score table entry {i} is not BCD ({v.hex()})')
        out[int.from_bytes(v, 'big')] = 1536 + i
    return out

def check_shapes(img, s):
    """The shapes the frame records use must have the offsets, on-screen boxes and probe points"""
    import desert_ex as DX
    for shape, (geom, box, probe) in SHAPES.items():
        a, b = (s['DA_SHAPES'] + 8 * shape, s['DA_BOXES'] + 8 * shape)
        got = (struct.unpack('>h', img[a:a + 2])[0], struct.unpack('>h', img[a + 2:a + 4])[0], img[a + 4], img[a + 5])
        gbox = struct.unpack('>4h', img[b:b + 8])
        p = s['DA_PROBE_TABLE'] + DX.be16(img, s['DA_PROBE_TABLE'] + 2 * shape)
        gprobe = struct.unpack('>2h', img[p:p + 4])
        if (got, gbox, gprobe) != (geom, box, probe):
            raise SystemExit(f'desert actors: shape {shape} is {got} {gbox} {gprobe}, not {geom} {box} {probe}')
SYM_NAMES = ['DA_FILL5', 'DA_FILL7', 'DA_FREE5', 'DA_ALLOC6', 'DA_LISTA', 'DA_LISTC', 'DA_ANIM_SET', 'DA_ANIM_STEP', 'DA_SNAP', 'DA_HIT_ATTACK', 'DA_HIT_HIRYU', 'DA_SPARK', 'DA_SND_DEATH', 'DA_SND_SHOT', 'DA_SND_BLAST', 'DA_SND_MISSILE', 'DA_SOUND']

def sheet(census, out):
    from PIL import Image
    import pce_vdc as V
    act = prepare(census)
    pal = V.pal_rgb(np.array([v for p in act['decoded']['palettes'] for v in p]))
    rows = []
    for (t, i), fr in sorted(act['frames'].items()):
        src = act['decoded']['actors'][t]['frames'][i]['image']
        if not src.size:
            continue
        a = np.where((src > 0)[..., None], pal[np.clip(src, 0, 255)], 40).astype(np.uint8)
        s = Image.fromarray(a).resize((src.shape[1] * 3 * 3 // 2, src.shape[0] * 3), Image.NEAREST)
        w = fr['wide']
        b = np.where((w > 0)[..., None], pal[np.clip(w, 0, 255)], 40).astype(np.uint8)
        b = Image.fromarray(b).resize((w.shape[1] * 3, w.shape[0] * 3), Image.NEAREST)
        rows.append((s, b))
    W = max((s.width + b.width for s, b in rows)) + 30
    Hh = sum((max(s.height, b.height) + 8 for s, b in rows))
    S = Image.new('RGB', (W, Hh), (20, 20, 20))
    y = 0
    for s, b in rows:
        S.paste(s, (4, y))
        S.paste(b, (s.width + 20, y))
        y += max(s.height, b.height) + 8
    S.save(out)
    print('wrote', out)

def self_test(a):
    img = np.zeros((16, 20), np.int32)
    img[2:10, 3:9] = 16 * 13 + 5
    w, org = widen_frame(img, (-11, -8))
    assert org == (-18, -8) and w.shape == (16, 33), (org, w.shape)
    t = cut(w, org)
    assert len(t) == 1, len(t)
    assert sorted(set(pens(t[0][2], 13).ravel().tolist())) == [4, 15]
    assert colors([0] * 16)[15] == 61440
    lay = layers(np.array([[16 * 12 + 3, 16 + 2, 0]]))
    assert [q for q, _ in lay] == [1, 12] and lay[0][1].tolist() == [[0, 18, 0]], lay
    assert win_x(-64, 320) == (-95, 480) and win_y(-64, 320) == (-79, 303)
    if a.census:
        act = prepare(a.census)
        print('tiles', len(act['tiles']), 'boxes', act['boxes'], 'entries', frame_entries(act))
        assert act['boxes'][:4] == [(0, 0, 12, 32), (0, 0, 3, 2), (0, 0, 12, 8), (0, 0, 0, 0)], act['boxes']
        assert act['frame_box'][67, 2] == act['boxes'].index((0, 0, 48, 32)) and act['frame_box'][67, 6] == 3
        assert act['frame_box'][65, 0] == 0 and act['frame_box'][66, 0] == 2
        assert sorted((k for k in act['frames'] if k[0] == 65)) == [(65, i) for i in range(4)]
        assert [act['frames'][65, i]['pals'] for i in range(4)] == [[12], [1, 12], [1, 12], [1, 12]]
        region = bytearray(G.ex_offset('obj', CODES[1]) + 128)
        install(region, act, {})
        an = animations(act)
        fire = an[KIND['bazooka'], 1, 0]
        assert [r['fmt'] for r in fire] == [FORMAT_ATTR] * 3 and fire[-1]['loop_to'] == 'da_a5_0_0_0', fire[-1]
        assert an[KIND['bazooka'], 0, 1][0]['fmt'] == FORMAT
        assert an[KIND['mine'], 0, 0][0]['n'] == 0 and an[KIND['mine'], 2, 0][-1]['loop_to'] == 'da_a7_2_0_3'
        assert all((r['flags'] == 128 | 3 for r in an[KIND['mine'], 1, 0]))
        sp = spawn_data(act, [dict(states=[])])
        assert [r for r in sp['map_lists'][0] if r[0] not in (KIND['soldier'], KIND['item'], KIND['worm'])] == [(KIND['bazooka'], 1, 5, 576, 1143), (KIND['mine'], 0, 6, 816, 1087), (KIND['mine'], 0, 7, 1224, 1119), (KIND['mine'], 0, 10, 1608, 1119), (KIND['mine'], 0, 13, 2304, 1119)], sp['map_lists'][0]
        assert [r for r in sp['map_lists'][0] if r[0] == KIND['item']] == [(KIND['item'], 1, 8, 1296, 1263), (KIND['item'], 2, 17, 2568, 1263), (KIND['item'], 0, 20, 3060, 1151)]
        assert [r for r in sp['map_lists'][2] if r[0] == KIND['item']] == [(KIND['item'], 3, 25, 4320, 1215), (KIND['item'], 0, 35, 6693, 1407)], sp['map_lists'][2]
        assert item_table()[2:6] == [1, 2, 3, 0] and item_table()[6] == 255 and (item_table()[9] == 255)
        assert [r for r in sp['map_lists'][0] if r[0] == KIND['worm']] == [(KIND['worm'], 1 | 1 << 1, 9, 1392, 1119), (KIND['worm'], 1 | 1 << 1, 11, 1920, 1119)]
        sp4 = spawn_data(act, [dict(states=[])], chains={(0, 9): 3, (0, 11): 8})
        assert [r[1] for r in sp4['map_lists'][0] if r[0] == KIND['worm']] == [1 | 3 << 1, 1 | 8 << 1]
        assert step4_equates(act['decoded']['handlers']) == dict(DA_SW_SURFACE=32, DA_SW_PERIOD=12, DA_SW_HITS=2, DA_SW_DEATH_T=4, DA_SW_DX=120, DA_SW_STOP=180, DA_SW_CX=192)
        an4 = animations(act)
        assert all((r['fmt'] == FORMAT and r['attr'] & 31 == 18 for f in (0, 1) for r in an4[KIND['worm'], 0, f])), an4[KIND['worm'], 0, 0][1]
        assert an4[KIND['worm'], 0, 0][-1]['loop_to'] == f"da_a{KIND['worm']}_0_0_6"
        col = np.zeros(64, bool)
        col[40:] = True
        assert pce_floor_distance(col, 32) == 8 and pce_floor_distance(col, 24) == 16 and (pce_floor_distance(col, 16) == 24)
        assert pce_floor_distance(col, 44) == 16 - 12 + 0
        assert pce_floor_distance(np.zeros(64, bool), 8) == 16 - 8 + 16
        h, t = (act['decoded']['handlers'], act['decoded']['step3'])
        eq3 = step3_equates(h, t)
        assert eq3 == dict(DA_DR_ENTRY_BIT=4, DA_DR_ITEM_DY=-12, DA_DR_EXIT_DX=96, DA_DR_ABOVE=240, DA_DR_BELOW=16, DA_DR_LEFT=144, DA_DR_RIGHT=240, DA_DR_BOX_X0=-96, DA_DR_BOX_X1=480, DA_DR_BOX_Y0=-15, DA_DR_BOX_Y1=304, DA_DR_CLOSE_X=96, DA_DR_CLOSE_Y=64, DA_DR_TURN=8, DA_DR_HOME_T=32, DA_DR_GLIDE_T=32, DA_DR_DEATH_T=4, DA_DR_A_HOME=0, DA_DR_A_GLIDE=1, DA_DR_A_ENTRY=2, DA_DR_GLIDE=0, DA_DR_HOME=1, DA_DR_ENTRY=2, DA_WM_DY=144, DA_WM_LEFT=-48, DA_WM_RIGHT=432, DA_RANK_MASK=15, DA_RANK_FRAMES=5402), eq3
        vel = drone_velocity(h, t)
        assert vel[1][0] == (0, 1024 * 128) and vel[1][4] == (1024 * 192, 0) and (vel[2][8] == (0, -2048 * 128))
        assert vel[0][12] == (-512 * 192, 0), vel[0][12]
        ws = wave_scripts(t)
        assert ws[0][:4] == [(260, 2047 - 768), (261, 432), (3, 0), (7, 0)] and ws[0][-1] == (0, 0), ws[0]
        assert ws[1][2:4] == [(2, 0), (6, 4)] and (6, 36) in ws[1] and ((6, 68) in ws[1])
        import pce_desert_spawns as SP
        script = SP.decode(sorted(Path(a.census).glob('pce_*_checkpoint_01_ram_0d0000.bin'))[0].read_bytes())
        lists = spawn_data(act, script)['spawn_lists']
        assert [r[:3] for r in lists[0]] == [(KIND['generator'], p, i) for p, i in ((0, 255), (1, 255), (0, 255), (1, 255))] + [(KIND['wave'], 0, 255)] or [r[0] for r in lists[0]] == [KIND['generator']] * 4 + [KIND['wave']], lists[0]
        assert [r[:2] for r in lists[1]] == [(KIND['wave'], 1)], lists[1]
        eq = step2_equates(act['decoded']['handlers'])
        assert eq == dict(DA_BZ_AIM=32, DA_BZ_FIRE=32, DA_BZ_KNOCK=4, DA_BZ_RDX=72, DA_BZ_RDY=12, DA_SCR_X0=-95, DA_SCR_X1=480, DA_SCR_Y0=-79, DA_SCR_Y1=303, DA_RK_VX=393216, DA_RK_RIGHT=408, DA_RK_LEFT=-24, DA_MN_DY=-32, DA_MN_TOLY=16, DA_MN_DX=24, DA_MN_TOLX=24, DA_MN_WARN=16, DA_MN_BLAST=8, DA_MN_RIGHT=576, DA_MN_LEFT=-192), eq
        text = inc_text(act, sp, [0] * 8)
        assert 'DA_SCORE_BZ equ $0603' in text, "the bazooka soldier's 200 points"
        assert 'DA_SCORE_DR equ $0604' in text, "the drone's 300 points"
        assert 'DA_SCORE_SW equ $060C' in text, "the sandworm's 400 points"
        assert [r for r in sp['map_lists'][2] if r[0] in (KIND['robot'], KIND['flame'])] == [(KIND['robot'], 0, 26, 4860, 1591), (KIND['robot'], 0, 27, 5016, 1759), (KIND['flame'], 0, 28, 5340, 1855), (KIND['robot'], 0, 29, 5544, 1831)] + [(KIND['flame'], 0, i, x * 3 // 2, 1679) for x, i in zip(range(3768, 4281, 128), range(30, 35))], sp['map_lists'][2]
        t5 = act['decoded']['step5']
        eq5 = step5_equates(h, t5)
        assert eq5 == dict(DA_RB_WAIT0=60, DA_RB_WALK=180, DA_RB_WAIT1=60, DA_RB_HOLD=60, DA_RB_REST=60, DA_RB_FIRE_DY=32, DA_RB_SPIN_T=4, DA_RB_AIM_R=6, DA_RB_AIM_L=2, DA_RB_HITS=4, DA_RB_KNOCK=6, DA_RB_SPEED=16, DA_RB_MASK=192, DA_RB_SNAP_DY=24, DA_RB_REST_DY=4, DA_RB_WALL_MASK=128, DA_RB_WALL_WANT=4, DA_RB_DROP_DY=22, DA_RB_DROP_R=1, DA_RB_DROP_L=-2, DA_RB_DROP_WANT=16, DA_LG_DX=3, DA_LG_DY=12, DA_LG_PROBE1=-8, DA_LG_PROBE2=8, DA_LG_WANT=16, DA_LG_AX=4, DA_LG_AXL=-5, DA_LG_AY=12, DA_BM_SPAWN_DX=24, DA_BM_SPAWN_DY=16, DA_BM_DX=24, DA_BM_LIFE=200, DA_BM_PERIOD=2, DA_BM_PIECES=2, DA_FL_PERIOD=32, DA_FL_ANIM=1), eq5
        assert robot_velocity(t5) == [(0, 256), (98, 237), (181, 181), (237, 98), (256, 0), (237, -98), (181, -181), (98, -237)]
        assert len(leg_frames(t5)) == 20 and 'DA_SCORE_RB equ $0604' in text, "the robot's 300 points"
        an5 = animations(act)
        assert [an5[KIND['robot'], i, 0][0]['n'] for i in range(6)] == [9, 9, 9, 8, 9, 9]
        lg = an5[KIND['leg'], leg_frames(t5).index(205), 0][0]
        assert lg['attr'] & 96 == 96 and lg['loop_to'] == f"da_a{KIND['leg']}_{leg_frames(t5).index(205)}_0_0"
        bm = an5[KIND['beam'], 0, 1][0]
        assert bm['attr'] & 96 == 32 and an5[KIND['beam'], 0, 0][0]['attr'] & 96 == 0
        burst = an5[KIND['flame'], 1, 0]
        assert len(burst) == 32 and [r['dur'] & 127 for r in burst] == [2] * 31 + [4], [r['dur'] for r in burst]
        assert burst[-1]['loop_to'] == f"da_a{KIND['flame']}_0_0_0" and an5[KIND['flame'], 0, 0][0]['n'] == 0
        nobox = 128 | act['boxes'].index((0, 0, 0, 0))
        assert [i for i, r in enumerate(burst) if r['flags'] != nobox] == [26, 27], [r['flags'] for r in burst]
        import desert_ex as DX
        col = DX.pce_collision(a.census, 2)
        st, got = (dict(x=3240 << 8, y=468 << 8, dir=1), {})
        for k in range(1, 178):
            robot_tick(col, h, t5, st)
            got[k] = (st['x'] >> 8, st['y'] >> 8)
        assert [got[k] for k in (2, 7, 12, 177)] == [(3238, 468), (3233, 464), (3231, 468), (3167, 596)], got
        area = robot_area(col, act['decoded'])
        assert (area['col0'], area['row0'], area['cols'], area['rows']) == (182, 11, 54, 33), area
        assert 'DA_RB_COLS equ 54' in inc_text(act, dict(sp, robot_area=area), [0] * 8)
        assert spawn_data(act, script)['spawn_lists'][2] == [(KIND['jeep'], 1, 118, 7248, 943)]
        t6 = act['decoded']['step6']
        eq6 = step6_equates(h, t6)
        assert {k: eq6[k] for k in ('DA_JP_ACC', 'DA_JP_CMAX', 'DA_JP_BRAKE', 'DA_JP_RACC', 'DA_JP_RMAX', 'DA_JP_AHEAD', 'DA_JP_HITS', 'DA_JP_DEATH_V', 'DA_JP_DONE', 'DA_GN_SHOT_DX', 'DA_GN_EX_DX', 'DA_GN_EX_DY', 'DA_AWAIT_A', 'DA_AWAIT_B')} == dict(DA_JP_ACC=64, DA_JP_CMAX=2048, DA_JP_BRAKE=128, DA_JP_RACC=128, DA_JP_RMAX=1024, DA_JP_AHEAD=128, DA_JP_HITS=5, DA_JP_DEATH_V=2048, DA_JP_DONE=4, DA_GN_SHOT_DX=-48, DA_GN_EX_DX=-51, DA_GN_EX_DY=-34, DA_AWAIT_A=2, DA_AWAIT_B=4), eq6
        assert jeep_anims(act['decoded'])[3] == (4, 2, [3, 35, 32, 33])
        walls = jeep_walls(DX.pce_collision(a.census, 3), h, t6, (4832, 1104))
        assert walls == dict(right=[(4393, 4400), (4409, 4416)], left=[(4512, 4519), (4528, 4535)]), walls
        an6 = animations(act)
        assert [r['fmt'] for r in an6[KIND['gunner'], 0, 0] + an6[KIND['gunner'], 2, 1]] == [FORMAT_ATTR, FORMAT]
        assert all((r['attr'] & 31 == 7 for f in range(4) for r in an6[KIND['jeep'], f, 0]))
        assert act['frame_box'][72, 0] == 0 and act['frame_box'][73, 2] == act['boxes'].index((0, 0, 0, 0))
        text6 = inc_text(act, dict(sp, robot_area=area), [0] * 8)
        assert 'DA_SCORE_JP equ $0605' in text6, "the jeep's 500 points"
        assert spawn_data(act, script)['spawn_lists'][3] == [(KIND['officer'], 0, 112, 3912, 895), (KIND['pull'], 0, 113, 3912, 863)]
        an7 = animations(act)
        assert [an7[KIND['officer'], f, 0][0]['fmt'] for f in range(10)] == [FORMAT] * 2 + [FORMAT_ATTR] * 6 + [FORMAT] * 2
        assert an7[KIND['officer'], 0, 0][0]['attr'] & 31 == RUNTIME_SLOTS[7] == 29
        assert an7[KIND['officer'], 9, 0][0]['attr'] & 31 == PAL_SLOTS[14] == 19
        assert len([k for k in an7 if k[0] == KIND['ball']]) == 12 and all((r['attr'] & 31 == PAL_SLOTS[1] for k, v in an7.items() if k[0] in (KIND['ball'], KIND['needle']) for r in v))
        assert pce_anims(act['decoded'], 69)[3] == (2, 132, [5, 6, 7]) and pce_anims(act['decoded'], 71)[0][1] == 3
        assert 'DA_SCORE_OF1 equ $0605' in text6 and 'DA_SCORE_OF2 equ $0603' in text6, "the officer's 500 + 200 points"
    if a.rom_dir:
        import respawn_fix as RF
        for m in ('striderua', 'striderjr'):
            files = {q.name: q.read_bytes() for q in (a.rom_dir / m).iterdir() if q.is_file()}
            img = bytes(RF.compose(files, RF.SETS[m]))
            s = locate(img)
            check_shapes(img, s)
            sc = score_commands(img, s)
            assert sc[256] == SCORE and sc[512] == 1539 and (sc[768] == 1540) and (sc[1024] == 1548), sc
            print(m, {k: f'{v:#x}' for k, v in s.items() if k in SYM_NAMES or k == 'DA_FORMAT32'})
    print('desert_actors_ex self-test passed')
    return 0

def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('cmd', nargs='?', choices=['sheet'])
    p.add_argument('--self-test', action='store_true')
    p.add_argument('--census', type=Path)
    p.add_argument('--rom-dir', type=Path, help='self-test: the stock sets (striderua/, striderjr/): locate in both regions')
    p.add_argument('--out', type=Path)
    a = p.parse_args()
    if a.self_test:
        return self_test(a)
    if a.cmd == 'sheet':
        sheet(a.census, a.out)
        return 0
    p.error('give a command or --self-test')
if __name__ == '__main__':
    sys.exit(main())
