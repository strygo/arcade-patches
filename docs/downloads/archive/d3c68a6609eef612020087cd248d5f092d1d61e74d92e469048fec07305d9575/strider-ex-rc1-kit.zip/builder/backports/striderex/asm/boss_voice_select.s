; Selected boss voice: the same VOICE bits and regional default as cinematics.
; English C0-C7 exists in both the new pack and native OKI. Japanese B8-BF
; remains pack-only; no-pack Japan retains the previous silent fallback.
        org $1FF400
        moveq   #0,d1
        move.b  $1FFFFF,d1
        lsr.b   #1,d1
        and.w   #3,d1
        bne.s   .selected
    ifne REGION_EN
        moveq   #2,d1
    else
        moveq   #1,d1
    endc
.selected:
        cmp.w   #2,d1
        bne.s   .japanese
        move.w  4(a2),$FFF9E0
        rts
.japanese:
        btst    #0,$1FFFFF
        beq.s   .return
        move.w  2(a2),$FFF9E0
.return:
        rts
