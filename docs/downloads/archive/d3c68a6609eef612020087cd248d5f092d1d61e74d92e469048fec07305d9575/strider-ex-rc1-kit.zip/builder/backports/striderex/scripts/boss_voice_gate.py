"""Check boss voice routing, native phrase playback and CPS+ one-shot delivery."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
import math
from pathlib import Path
from types import SimpleNamespace
import boss_scene_binary as BB
import boss_scene_gate as B
import desert_gate as G
import oki_adpcm as O
import pack_model as PM
import pce_sfx as PS
from cpsplus.pack.format import CODEC_PCM

def sha(b):
    return hashlib.sha256(b).hexdigest()

def inventory(path):
    meta = json.loads((path / 'build.json').read_text())
    result = {}
    for m, s in meta['sets'].items():
        result[m] = {n: (path / m / n).read_bytes() for n in s['files']}
        if any((sha(b) != s['files'][n] for n, b in result[m].items())):
            raise ValueError('ROM inventory changed')
    return (meta, result)

def gate(a):
    work = a.workdir.resolve()
    work.mkdir(parents=True, exist_ok=a.reuse)
    meta, files = inventory(a.build)
    assets = json.loads((a.voices / 'voices.json').read_text())
    if [r['id'] for r in assets['voices']] != list(BB.IDS):
        raise ValueError('voice inventory incomplete')
    rt = json.loads((a.runtime / 'runtime.json').read_text())
    binary = Path(rt['binary'])
    if sha(binary.read_bytes()) != rt['binary_sha256']:
        raise ValueError('runtime changed')
    model = PM.Model(a.pack)
    manifest = json.loads((Path(__file__).resolve().parents[1] / 'manifests/boss_scenes.json').read_text())
    cases = {s['id']: s['gate'] for s in manifest['scenes']}
    selected = a.scenes.split(',') if a.scenes else list(BB.IDS)
    staged = {}
    records = {}
    native = {}
    pack_rows = {}
    for machine, set_name in (('striderua', 'striderus01'), ('striderjr', 'striderjs01')):
        p6 = files[machine]['strex_p6.bin']
        bank = bytes((p6[i ^ 1] for i in range(len(p6))))
        records[machine] = {r['id']: r for r in BB.scenes(bank)}
        sound = files[machine]['09.12b' if machine == 'striderua' else 'sth_09.12a']
        oki = b''.join((files[machine][n] for n in PS.SAMPLE_MEMBERS[machine]))
        native[machine] = {}
        for i, voice in enumerate(assets['voices']):
            header, channel = PS.driver_play(sound, oki, 192 + i)
            start, stop = [int.from_bytes(header[k:k + 3], 'big') for k in (0, 3)]
            raw = oki[start:stop + 1]
            if channel != 16 or sha(raw) != voice['native_sha256'] or len(raw) != voice['native_bytes']:
                raise ValueError('native cue points at the wrong sample or voice')
            native[machine][voice['id']] = dict(sha256=sha(raw), start=start, stop=stop, channel=channel)
        for pack in (False, True):
            for override in (False, True):
                label = machine + ('_pack' if pack else '_native') + ('_override' if override else '')
                variant = work / 'variants' / label
                if not a.reuse:
                    variant.mkdir(parents=True)
                    variant_meta = json.loads(json.dumps(meta))
                    d = variant / machine
                    d.mkdir()
                    f = dict(files[machine])
                    p = bytearray(p6)
                    voice = (1 if machine == 'striderua' else 2) if override else 0
                    p[-2] = p[-2] & ~7 | int(pack) | voice << 1
                    f['strex_p6.bin'] = bytes(p)
                    for n, b in f.items():
                        (d / n).write_bytes(b)
                    variant_meta['sets'] = {machine: dict(meta['sets'][machine], files={n: sha(b) for n, b in f.items()})}
                    (variant / 'build.json').write_text(json.dumps(variant_meta) + '\n')
                    roms = G.stage_sets(variant, set_name, a.hbmame, a.rom_dir.resolve(), work / 'sets' / label)
                staged[label] = (work / 'sets' / label, set_name, pack, override, machine)
    jobs = []
    for label, (roms, set_name, pack, override, machine) in staged.items():
        ids = selected[:1] if override else selected
        for sid in ids:
            jobs.append((label, sid))

    def run(job):
        label, sid = job
        roms, set_name, pack, override, machine = staged[label]
        sc = cases[sid]
        record = records[machine][sid]
        N = record['total']
        frames = sc['frames'] + N + 300
        probe = work / 'runs' / label / sid
        if not a.reuse or not (probe / 'mame.log').exists():
            B.run(binary, roms, set_name, probe, sc, frames, sc['inputs'], holds=B.holds_env(B.research_writes(sc)), audio=True)
        initial = B.load(probe, frames)
        first = B.entries_of(initial, 'entry')
        if len(first) != 1:
            raise ValueError('encounter discovery did not find exactly one scene')
        E = first[0]
        out = probe / 'qualified'
        if not a.reuse or not (out / 'mame.log').exists():
            B.run(binary, roms, set_name, out, sc, frames, B.shift_inputs(sc['inputs'], N, E), shift=(E, N), holds=B.holds_env(B.research_writes(sc), (E, N)), audio=True)
        log = B.load(out, frames)
        entry, exit_ = [B.entries_of(log, k) for k in ('entry', 'exit')]
        if len(entry) != 1 or len(exit_) != 1 or exit_[0] - entry[0] != N:
            raise ValueError(label + ' ' + sid + ': scene boundary changed')
        if B.freeze_diff(log['dumps']['entry'], log['dumps']['exit']):
            raise ValueError('game state changed during scene')
        E = entry[0]
        i = BB.IDS.index(sid)
        language = ('ja' if machine == 'striderua' else 'en') if override else 'en' if machine == 'striderua' else 'ja'
        expected = 192 + i if language == 'en' else 184 + i if pack else None
        writes = B.sound_writes(log)
        during = [(f, v) for f, v, s in writes if s and v != 255]
        want = [(E + 2, 252 if pack else 241)] + ([] if expected is None else [(E + 72, expected)])
        if during != want:
            raise ValueError(f'{label} {sid}: {during} expected {want}')
        oki_path = out / 'g_oki.tsv'
        actual = [(int(f), int(v, 16)) for f, v in (r.split('\t') for r in oki_path.read_text().splitlines())]
        if language == 'en':
            at = next((k for k, (f, v) in enumerate(actual) if E + 70 <= f <= E + 75 and v == expected), None)
            if at is None or actual[at + 1][1] != 16:
                raise ValueError('English command did not start its OKI phrase')
            voice = assets['voices'][i]
            bank_bytes = files[machine]['strex_p6.bin']
            bank = bytes((bank_bytes[k ^ 1] for k in range(len(bank_bytes))))
            final_fade = 51 + sum((BB.word(bank, p + 8) for p in record['pages'][:-1])) + BB.word(bank, record['pages'][-1] + 4)
            native_end = 72 + math.ceil(voice['native_seconds'] * PM.CPS1_HZ)
            row = model.triggers[expected]
            track = model.tracks[row.track]
            pcm, t = model.pcm(row.track)
            if row.suppress != 1 or track.loop_end_byte or track.sample_rate != 48000 or (track.channels != 2):
                raise ValueError('CPS+ English voice is not a suppressed full-quality one-shot')
            if track.codec != CODEC_PCM:
                raise ValueError('English voice is not PCM')
            pack_end = 72 + math.ceil(len(pcm) / track.sample_rate * PM.CPS1_HZ)
            if max(native_end, pack_end) > final_fade:
                raise ValueError('voice is cut off by the final page fade')
            if pack:
                events, segs = model.run([(E - 120, int(manifest.get('gate_model_music', '0x02'), 16)), *[(f, v) for f, v, s in writes]])
                starts = [ev for ev in events if ev[1] == expected]
                if len(starts) != 1 or starts[0][-1] != 'start':
                    raise ValueError('CPS+ voice did not start exactly once')
                db, seconds = model.level(segs, E + 71, E + pack_end)
                if db < -40 or abs(seconds - len(pcm) / 48000) > 0.035:
                    raise ValueError('CPS+ voice was not played to completion')
            pack_rows[sid] = dict(native_end_frame=native_end, pack_end_frame=pack_end, final_page_fade=final_fade, english_track=row.track, full_voice_before_fade=True)
        print('PASS', label, sid, 'cue', hex(expected) if expected else 'silent Japanese fallback', flush=True)
        return dict(machine=machine, pack=pack, override=override, voice=language, scene=sid, entry=E, frames=N, cue=hex(expected) if expected else None, scene_sound=during, native_oki_writes_sha256=sha(oki_path.read_bytes()), frames_sha256=sha((out / 'g_frames.tsv').read_bytes()), regs_sha256=sha((out / 'g_regs.tsv').read_bytes()), passed=True)
    with ThreadPoolExecutor(a.jobs) as ex:
        results = list(ex.map(run, jobs))
    receipt = dict(schema='striderex-boss-voice-routing/1', passed=True, scope='focused development qualification', input_files={m: s['files'] for m, s in meta['sets'].items()}, pack_sha256=sha(a.pack.read_bytes()), asset_receipt_sha256=sha((a.voices / 'voices.json').read_bytes()), runtime={k: rt[k] for k in ('binary_sha256', 'source_revision', 'board_wait')}, native_phrases=native, english_playback=pack_rows, results=results, hardware_review_granted=False)
    a.receipt.write_text(json.dumps(receipt, indent=2) + '\n')
    print('PASS:', len(results), 'encounters, native phrase addresses, full CPS+ one-shots and regional defaults')

def main():
    p = argparse.ArgumentParser(description=__doc__)
    for n in ('build', 'voices', 'pack', 'runtime', 'hbmame', 'rom-dir', 'workdir', 'receipt'):
        p.add_argument('--' + n, type=Path, required=True)
    p.add_argument('--scenes', default='')
    p.add_argument('--jobs', type=int, default=2)
    p.add_argument('--reuse', action='store_true')
    gate(p.parse_args())
if __name__ == '__main__':
    main()
