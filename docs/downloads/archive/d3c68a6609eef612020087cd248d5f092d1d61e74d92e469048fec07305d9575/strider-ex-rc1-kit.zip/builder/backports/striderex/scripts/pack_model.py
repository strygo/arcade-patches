"""What the MiSTer core's CPS+ player plays for a sound-latch write sequence, offline."""
import argparse
import math
import sys
from pathlib import Path
import numpy as np
ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT))
from cpsplus.pack import audition
from cpsplus.pack.format import PackReader, VERB_NONE, VERB_PLAY, VERB_STOP, VERB_FADE_OUT, VERB_FADE_KEEP, VERB_MASTER_FADE
CPS1_HZ = 59.637
SILENT_DB = -55.0
WIN_S = 0.02
UNITY = 8388608
FADE_VERBS = (VERB_FADE_OUT, VERB_FADE_KEEP, VERB_MASTER_FADE)

class Fade:
    """One fade as cpsplus_player.v runs it. Written in frame f0 (the run's frame of the latch write), it"""

    def __init__(self, f0, frames, l0, stop0):
        self.f0, self.frames, self.l0, self.stop0 = (f0, frames, l0, stop0)
        self.step = l0 // frames
        self.end = f0 + frames - 1

    def level(self, f):
        """The level (Q15.8) in frame f (after that frame's tick)."""
        k = min(max(f - self.f0 + 1, 0), self.frames)
        return 0 if k >= self.frames else self.l0 - k * self.step

def total_q14(level, vol_q14=16384):
    """cpsplus_player.v: total_q14 = (vol_q14 * level_q15) >> 15 (15 bits); vol_q14 = 16384 for gains 0x7F,0x7F."""
    return vol_q14 * (level >> 8) >> 15 & 32767

class Model:

    def __init__(self, pack, triggers=None, proto=None, tracks=None):
        """pack: a .cpk path (or None with triggers/proto/tracks given, for the self-test)."""
        if pack is not None:
            self.rd = PackReader(pack)
            self.triggers = self.rd.triggers
            proto = self.rd.header.proto
            self.tracks = self.rd.tracks
        else:
            self.rd, self.triggers, self.tracks = (None, triggers, tracks)
        self.ctrl_start = proto.control_region_start
        self.ctrl_verbs = dict(proto.control_verbs)
        self.ctrl_dflt = proto.control_default_verb
        self.fade_law, self.fade_c1, self.fade_c2 = (proto.fade_law, proto.fade_const1, proto.fade_const2)
        self._pcm = {}

    def classify(self, v):
        """(verb, track, control) for a latch byte (cpsplus_cps1_tap.v)."""
        if v >= self.ctrl_start:
            return (self.ctrl_verbs.get(v, self.ctrl_dflt), None, True)
        r = self.triggers[v]
        return (r.verb, r.track if r.verb == VERB_PLAY else None, False)

    def fade_frames(self, arg=0):
        """cpsplus_player.v FS_LAW with the fade's argument (0 on CPS-1: the divider takes 0 as 1): law 0 one"""
        q = self.fade_c1 // max(arg, 1)
        if self.fade_law == 0:
            return 1
        if self.fade_law == 1:
            return q or 1
        if self.fade_law == 2:
            return min(q, 65535) * (self.fade_c2 & 65535) or 1
        raise ValueError(f'fade law {self.fade_law} (the dB ramp) is not modeled')

    def run(self, writes):
        """writes: [(frame, byte)] in bus order. -> (events, segments)."""
        cur, cur_track, playing = (255, None, None)
        fade, held = (None, UNITY)
        events, segs = ([], [(0, None, None, None)])

        def settle(f):
            nonlocal fade, playing, held
            if fade is not None and fade.end < f:
                held = 0
                if fade.stop0 and playing is not None:
                    segs.append((fade.end, None, None, None))
                    playing = None
                fade = None
        for f, v in writes:
            if v == cur:
                continue
            cur = v
            settle(f)
            verb, track, ctrl = self.classify(v)
            effect = None
            if verb == VERB_PLAY:
                if cur_track is not None and track == cur_track:
                    effect = 'drop'
                else:
                    cur_track, effect = (track, 'start')
                    playing, fade, held = ((track, f), None, UNITY)
                    segs.append((f, track, f, None))
            elif verb == VERB_STOP:
                cur_track, effect, playing, fade = (None, 'stop', None, None)
                segs.append((f, None, None, None))
            elif verb in FADE_VERBS:
                lvl = fade.level(f - 1) if fade is not None else held
                fade = Fade(f, self.fade_frames(0), lvl, verb in (VERB_FADE_OUT, VERB_MASTER_FADE))
                effect = 'fade'
                if playing is not None:
                    segs.append((f, playing[0], playing[1], fade))
            elif verb != VERB_NONE:
                raise ValueError(f'frame {f}: command {v:#04x} has verb {verb}, which the model does not cover')
            events.append((f, v, verb, track, effect))
        settle(float('inf'))
        return (events, segs)

    def state(self, segs, frame):
        """(track, start frame) the player holds at frame (track None: stopped)."""
        return self.state_fade(segs, frame)[:2]

    def state_fade(self, segs, frame):
        """(track, start frame, Fade or None) the player holds at frame."""
        t = (None, None, None)
        for f, track, start, fade in segs:
            if f <= frame:
                t = (track, start, fade)
        return t

    def pcm(self, track):
        """The track's PCM as float mono-mixed samples at its rate (decoded once)."""
        if track not in self._pcm:
            m = self.tracks[track]
            raw = audition._decode_track(self.rd, track)
            x = np.frombuffer(raw, '<i2').reshape(-1, m.channels).astype(np.float64).mean(1) / 32768
            self._pcm[track] = (x, m)
        return self._pcm[track]

    def samples(self, track, start, f0, f1):
        """The samples the player outputs for track (started at frame start) over frames [f0, f1), at unity."""
        x, m = self.pcm(track)
        rate = m.sample_rate
        a, b = (round((f0 - start) / CPS1_HZ * rate), round((f1 - start) / CPS1_HZ * rate))
        idx = np.arange(a, b)
        if m.loop_end_byte:
            ls, le = audition._loop_points_samples(m)
            over = idx >= le
            idx[over] = ls + (idx[over] - ls) % (le - ls)
            return x[idx]
        out = np.zeros(len(idx))
        ok = idx < len(x)
        out[ok] = x[idx[ok]]
        return out

    def gain(self, fade, frame):
        """The player's output gain in a frame: total_q14 / 16384 (1 without a fade)."""
        return 1.0 if fade is None else total_q14(fade.level(frame)) / 16384

    def level(self, segs, f0, f1):
        """The loudest 20 ms window (dBFS) of what the player outputs over frames [f0, f1), and the"""
        peak, sounding = (-math.inf, 0.0)
        if f1 <= f0:
            return (peak, sounding)
        bounds = {f0, f1} | {f for f, _, _, _ in segs if f0 < f < f1}
        for f, _, _, fade in segs:
            if fade is not None:
                bounds |= {g for g in range(fade.f0, fade.end + 1) if f0 < g < f1}
        bounds = sorted(bounds)
        for a, b in zip(bounds, bounds[1:]):
            track, start, fade = self.state_fade(segs, a)
            if track is None:
                continue
            y = self.samples(track, start, a, b) * self.gain(fade, a)
            x, m = self.pcm(track)
            past = np.arange(len(y)) + round((a - start) / CPS1_HZ * m.sample_rate) >= len(x)
            if not m.loop_end_byte:
                sounding += (~past & (self.gain(fade, a) > 0)).sum() / m.sample_rate
            k = round(WIN_S * m.sample_rate)
            n = len(y) // k
            if n:
                db = 20 * np.log10(np.sqrt((y[:n * k].reshape(n, k) ** 2).mean(1) + 1e-20))
                peak = max(peak, float(db.max()))
        return (peak, round(sounding, 3))

    def envelope(self, segs, f0, f1):
        """Per frame in [f0, f1): (frame, track or None, total_q14 the player applies, dBFS of the frame's"""
        out = []
        for f in range(f0, f1):
            track, start, fade = self.state_fade(segs, f)
            tq = None if track is None else 16384 if fade is None else total_q14(fade.level(f))
            db = -math.inf
            if track is not None:
                y = self.samples(track, start, f, f + 1) * (tq / 16384)
                db = float(20 * np.log10(np.sqrt((y ** 2).mean() + 1e-20))) if len(y) else -math.inf
            out.append((f, track, tq, round(db, 2)))
        return out
AUDIO_MANIFEST = ROOT / 'cpsplus/manifests/strider_ex_audio.json'

def track_names(manifest=AUDIO_MANIFEST):
    """{(scene id, lang): the track name build_strider_ex.py gives that scene's row}: lang 0 Japanese (the"""
    import json
    man = json.loads(Path(manifest).read_text(encoding='utf-8'))
    out = {(c['id'], 0): c['title'] for c in man['cinematics']}
    out.update({(e['id'], 1): f"{e['title']} (English)" for e in man.get('english', [])})
    return out

def cue_starts(model, writes, want):
    """Does each cue in want start its own pack row on the core? writes: a run's latch writes [(frame, byte)];"""
    ev, _ = model.run(writes)
    named = any((getattr(m, 'name', '') for m in model.tracks))
    out, i = ([], 0)
    for cue, name in want:
        j = next((k for k in range(i, len(ev)) if ev[k][1] == cue), None)
        verb, track, ctrl = model.classify(cue)
        r = dict(cue=f'{cue:#04x}', control=ctrl, verb=verb, row_track=track, want_name=name if named else None)
        if j is None:
            out.append(dict(r, frame=None, sent=False, effect=None, track=None, name=None, ok=False))
            continue
        f, v, _, started, effect = ev[j]
        i = j + 1
        got = model.tracks[started].name if started is not None and named else None
        ok = not ctrl and verb == VERB_PLAY and (effect == 'start') and (started == track) and (not named or name is None or got == name)
        out.append(dict(r, frame=f, sent=True, effect=effect, track=started, name=got, ok=ok))
    return out

def read_sound(path):
    """An ex_gate run's sound.tsv -> [(frame, byte)] (the latch's low byte, every write)."""
    out = []
    for line in Path(path).read_text().splitlines():
        f, _, v = line.split('\t')[:3]
        out.append((int(f), int(v, 16) & 255))
    return out

def self_test(pack=None):
    from cpsplus.pack.format import TriggerRow
    from cpsplus.pack.protocols import PROTOCOLS
    rows = [TriggerRow() for _ in range(256)]
    rows[17] = TriggerRow(verb=VERB_PLAY, track=0, suppress=1)
    rows[0] = TriggerRow(verb=VERB_PLAY, track=0, suppress=1)
    rows[161] = TriggerRow(verb=VERB_PLAY, track=1, suppress=1)
    rows[252] = TriggerRow(verb=VERB_PLAY, track=1, suppress=1)
    rows[35] = TriggerRow(verb=VERB_STOP)
    proto = PROTOCOLS['strider']
    assert proto.control_region_start == 240 and proto.control_verbs == {240: VERB_STOP, 241: VERB_STOP}
    M = Model(None, rows, proto, tracks=[None, None])
    ev, segs = M.run([(1, 161), (2, 255), (3, 161), (4, 255), (5, 252), (6, 255), (7, 241), (8, 241), (9, 17), (10, 255), (11, 0), (12, 35), (13, 0), (14, 0)])
    got = [(f, v, e) for f, v, _, _, e in ev]
    want = [(1, 161, 'start'), (2, 255, None), (3, 161, 'drop'), (4, 255, None), (5, 252, None), (6, 255, None), (7, 241, 'stop'), (9, 17, 'start'), (10, 255, None), (11, 0, 'drop'), (12, 35, 'stop'), (13, 0, 'start')]
    assert got == want, got
    assert M.state(segs, 6) == (1, 1) and M.state(segs, 7) == (None, None) and (M.state(segs, 13) == (0, 13))
    cs = cue_starts(M, [(1, 161), (2, 255), (3, 252), (4, 255), (5, 17), (6, 255), (7, 0), (8, 124)], [(161, None), (252, None), (0, None), (124, None), (34, None)])
    assert [(c['ok'], c['control'], c['effect'], c['sent']) for c in cs] == [(True, False, 'start', True), (False, True, None, True), (False, False, 'drop', True), (False, False, None, True), (False, False, None, False)], cs
    import dataclasses
    fproto = dataclasses.replace(proto, fade_law=1, fade_const1=30, fade_const2=0, control_verbs={240: VERB_STOP, 241: VERB_STOP, 252: VERB_FADE_OUT})
    F = Model(None, rows, fproto, tracks=[None, None])
    assert F.fade_frames(0) == 30 and F.fade_frames(3) == 10
    ev, segs = F.run([(10, 17), (11, 255), (20, 252), (21, 255), (60, 17), (61, 255), (62, 241), (63, 255), (64, 17)])
    assert [(f, e) for f, _, _, _, e in ev if e] == [(10, 'start'), (20, 'fade'), (60, 'drop'), (62, 'stop'), (64, 'start')], ev
    _, _, fd = F.state_fade(segs, 20)
    assert fd.step == UNITY // 30 == 279620 and fd.end == 49
    assert fd.level(19) == UNITY and fd.level(20) == UNITY - 279620 and (fd.level(48) == UNITY - 29 * 279620)
    assert fd.level(49) == 0 and total_q14(fd.level(48)) == 546 and (total_q14(UNITY) == 16384)
    assert F.state(segs, 48) == (0, 10) and F.state(segs, 49) == (None, None) and (F.state(segs, 64) == (0, 64))
    curve = [total_q14(fd.level(f)) for f in range(19, 50)]
    assert curve == sorted(curve, reverse=True) and curve[0] == 16384 and (curve[-1] == 0), curve
    ev, segs = F.run([(10, 17), (11, 255), (20, 252), (21, 255), (30, 161), (31, 255)])
    assert F.state_fade(segs, 60) == (1, 30, None)
    ev, segs = F.run([(20, 252), (21, 255), (30, 161)])
    assert segs == [(0, None, None, None), (30, 1, 30, None)], segs
    sys.path.insert(0, str(ROOT / 'cpsplus'))
    sys.path.insert(0, str(ROOT / 'cpsplus/rtl/tb'))
    import gen_cps1_vectors as GV
    for mm, pp in ((M, proto), (F, fproto)):
        ref = GV.Cps1Tables(pp, rows)
        for v in range(256):
            verb, track, ctrl = mm.classify(v)
            rv, rt, _, _, rc = ref.classify(v)
            assert (verb, bool(ctrl)) == (rv, bool(rc)) and (verb != VERB_PLAY or track == rt), hex(v)
    if pack:
        P = Model(pack)
        ref = GV.Cps1Tables(P.rd.header.proto, P.triggers)
        for v in range(256):
            verb, track, ctrl = P.classify(v)
            rv, rt, _, _, rc = ref.classify(v)
            assert (verb, bool(ctrl)) == (rv, bool(rc)) and (verb != VERB_PLAY or track == rt), hex(v)
        t = next((r.track for r in P.triggers if r.verb == VERB_PLAY and (not P.tracks[r.track].loop_end_byte)))
        cue = next((i for i, r in enumerate(P.triggers) if r.verb == VERB_PLAY and r.track == t))
        _, segs = P.run([(100, cue), (101, 255), (400, 241)])
        loud, s1 = P.level(segs, 100, 400)
        quiet, s2 = P.level(segs, 400, 700)
        assert loud > SILENT_DB and quiet == -math.inf and (s2 == 0) and (s1 > 4.9), (loud, quiet, s1, s2)
        fades = sorted((c for c, v in P.ctrl_verbs.items() if v in FADE_VERBS))
        if fades:
            n = P.fade_frames(0)
            _, segs = P.run([(100, cue), (101, 255), (400, fades[0]), (401, 255)])
            env = P.envelope(segs, 399, 400 + n + 2)
            tq = [e[2] for e in env]
            assert tq[0] == 16384 and all((a > b for a, b in zip(tq[:n], tq[1:n]))), tq
            assert tq[n:] == [None] * (len(tq) - n), tq
            assert n != 30 or tq[n - 1] == 546, tq
            assert P.level(segs, 400 + n - 1, 700)[0] == -math.inf
            print(f'pack fade: control {fades[0]:#04x} (verb {P.ctrl_verbs[fades[0]]}), law {P.fade_law}, const1 {P.fade_c1}: {n} frames, total_q14 {tq[:3]}...{tq[n - 2:n + 1]}, silent after')
        import json
        man = json.loads(AUDIO_MANIFEST.read_text(encoding='utf-8'))
        names = track_names()
        bad = []
        for lang, key in ((0, 'cinematics'), (1, 'english')):
            for c in man.get(key, []):
                cue = int(c['command'], 16)
                cs = cue_starts(P, [(10, cue)], [(cue, names[c['id'], lang])])[0]
                if not cs['ok']:
                    bad.append((c['id'], lang, c['command'], cs))
        assert not bad and P.rd.sidecar, bad or 'the pack has no sidecar (track names)'
        print(f"pack {pack}: classifier agrees with the RTL reference on all 256 bytes; track {t} ({P.tracks[t].name}) {loud:.1f} dBFS, stopped silent; {sum((len(man.get(k, [])) for k in ('cinematics', 'english')))} cinematic cues each start their own row")
    print('self-test OK')

def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('cmd', nargs='?', choices=['trace'])
    p.add_argument('--self-test', action='store_true')
    p.add_argument('--pack', type=Path)
    p.add_argument('--sound', type=Path)
    a = p.parse_args()
    if a.self_test:
        self_test(a.pack)
        return 0
    if a.cmd == 'trace':
        M = Model(a.pack)
        ev, segs = M.run(read_sound(a.sound))
        for f, v, verb, track, effect in ev:
            if effect:
                name = M.tracks[track].name if track is not None else ''
                print(f'{f}\t{v:#04x}\t{effect}\t{name}')
        return 0
    p.error('nothing to do')
if __name__ == '__main__':
    sys.exit(main())
