-- Strider EX: a stage's opening scene, located by its palette state (scripts/stage_openings.py).
--
-- Runs from the arcade's debug start (STREX_DEBUG_START, arcade_debug_start.lua and its STREX_*
-- variables) in stock MAME (the capture) or HBMAME (the stage select gate's reference frames).
-- Each frame it logs the game's video state and looks for the frame where the stage's scene stands
-- fully in, only on the game's own frames (the palette base register at the game's buffer
-- 0x914000, and in an EX build no EX cinematic state in 0xFFF914):
--   RULE=fade   (Siberia, the Amazon, the Aerial Battleship, Third Moon, and the EX desert): the
--               stage setup's fade-in (USA 0x9732, 0x9ABC, 0x9D4E, 0x9FE6) steps the brightness
--               nibble of the SCROLL1-3 palette pages from 0 to A, three frames a step, then reloads
--               the stage's palette sets (mostly at F: some stock colors are authored at other
--               levels) at the first play frame. F is the first frame whose three pages are mostly
--               at F after a frame with every color that is not 0 at A;
--   RULE=steps  (St. Petersburg): its intro brightens the city by palette content (SCROLL1, a
--               step every 12 frames, brightness F throughout). Every change of the three pages
--               after the layer register shows a tile layer is a candidate; F is the last one
--               before the first play frame (scripts/stage_openings.py picks it).
-- At a candidate F it dumps the palette buffer as it stands at F (the next picture copies it:
-- MEASURED, the screenshot follows the palette RAM by one frame) and, at F + 1, graphics RAM
-- 0x900000-0x92FFFF, the CPS-A/B registers as last written and the camera (the SCROLL1-3 layer
-- objects' X and Y), with a screenshot (the picture of the state dumped). The run ends STABLE frames
-- after a fade's F, or at the first play frame of a steps run. Nothing is written to the machine,
-- except with LAYER_AND (below).
--
-- Environment: OUT (output directory), END (last frame), RULE (fade or steps), STAGE (internal
-- stage; candidates only while the stage byte 0xFF0CB2 holds it), STABLE (frames logged after a
-- fade's F), SHOTS "a-b" (extra screenshots), LAYER_AND (hex; the stage select gate's tile-layer
-- comparison: every layer-control write is ANDed with it, for example 0xFFCF to drop the star
-- layers, whose colors MAME cycles with the frame number, or 0xFFCD to drop SCROLL1 too; only the
-- picture changes, the game reads nothing back; the logs keep the value the game wrote).
-- Output: opening.tsv (per frame), candidates.tsv, pal_<F>.bin (0x914000-0x9157FF at F),
-- gfx_<F+1>.bin, regs_<F+1>.txt, s_<F+1>.png.
local m=manager.machine
local sp=m.devices[':maincpu'].spaces['program']
local screen=m.screens[':screen']
local out=assert(os.getenv('OUT'))
local last=assert(tonumber(os.getenv('END')))
local rule=assert(os.getenv('RULE'))
local stage=assert(tonumber(os.getenv('STAGE')))
local stable=tonumber(os.getenv('STABLE') or '60')
local sa,sb=string.match(os.getenv('SHOTS') or '','(%d+)-(%d+)')
sa,sb=tonumber(sa),tonumber(sb)
local layer_and=tonumber(os.getenv('LAYER_AND') or 'ffff',16)
local regs={}
for i=0,0x3f do regs[i]=0 end
_G.so_regs=sp:install_write_tap(0x800100,0x80017f,'so_regs',function(o,d,mk)
  local i=(o-0x800100)>>1
  regs[i]=d&0xffff                      -- the value the game wrote (logged and dumped as such)
  if i==0x33 and layer_and~=0xffff then return d&layer_and end
end)
local lg=assert(io.open(out..'/opening.tsv','w'))
lg:write('frame\tmode\tist\tisub\tstage\tlayer\tpalbase\tex\tlv1\tlv2\tlv3\tuni\tcrc1\tcrc2\tcrc3\tcrcs\tcam\tregs\n')
local cg=assert(io.open(out..'/candidates.tsv','w'))
cg:write('frame\tkind\n')
local f=0
local pending,stop=nil,nil
local prev_lv,prev_crc,prev_u=nil,nil,false
local EX_CINE={[0xc1e5]=true,[0xc1e6]=true,[0xc1e7]=true,[0xc1e8]=true}

local function page(base)
  -- the majority brightness nibble over the page's non-zero colors, whether every one has it, a CRC
  local h,c,n={},0,0
  for i=0,511 do
    local w=sp:read_u16(base+2*i)
    c=(c*31+w)&0xffffff
    if w&0x0fff~=0 then local k=w>>12 h[k]=(h[k] or 0)+1 n=n+1 end
  end
  local best,bn=-1,0
  for k,v in pairs(h) do if v>bn then best,bn=k,v end end
  return best,(bn==n),c
end

local function dump_ram(path,a0,a1)
  local fh=assert(io.open(path,'wb'))
  local t={}
  for a=a0,a1,2 do
    local w=sp:read_u16(a)
    t[#t+1]=string.char(w>>8,w&0xff)
    if #t==4096 then fh:write(table.concat(t)) t={} end
  end
  fh:write(table.concat(t))
  fh:close()
end

local function cams()
  -- the SCROLL1, SCROLL2 and SCROLL3 layer objects' X and Y (0xFF0F74/78, 0xFF0FB4/B8, 0xFF0FF4/F8)
  return string.format('%04x,%04x,%04x,%04x,%04x,%04x',sp:read_u16(0xff0f74),sp:read_u16(0xff0f78),
    sp:read_u16(0xff0fb4),sp:read_u16(0xff0fb8),sp:read_u16(0xff0ff4),sp:read_u16(0xff0ff8))
end

emu.register_frame_done(function()
  f=f+1
  local pb=((regs[5]&0xffff)<<8)
  local ex=sp:read_u16(0xfff914)
  local game=pb==0x914000 and not EX_CINE[ex]
  if pb<0x900000 then pb=0x914000 end
  local l1,u1,c1=page(pb+0x400)
  local l2,u2,c2=page(pb+0x800)
  local l3,u3,c3=page(pb+0xc00)
  local cs=0
  for i=0,1023 do cs=(cs*31+sp:read_u16(pb+0x1000+2*i))&0xffffff end
  local r={}
  for i=0,0x11 do r[#r+1]=string.format('%04x',regs[i]) end
  for i=0x33,0x38 do r[#r+1]=string.format('%04x',regs[i]) end
  local layer=regs[0x33]
  local lv=string.format('%x%x%x',l1<0 and 0 or l1,l2<0 and 0 or l2,l3<0 and 0 or l3)
  local crc=string.format('%06x%06x%06x',c1,c2,c3)
  local mode=sp:read_u16(0xff0c12)
  local st=sp:read_u8(0xff0cb2)
  lg:write(string.format('%d\t%d\t%d\t%d\t%d\t%04x\t%06x\t%04x\t%x\t%x\t%x\t%d\t%06x\t%06x\t%06x\t%06x\t%s\t%s\n',f,
    mode,sp:read_u8(0xff0cdc),sp:read_u8(0xff0cdd),st,layer,pb,ex,l1<0 and 0 or l1,l2<0 and 0 or l2,
    l3<0 and 0 or l3,(u1 and u2 and u3) and 1 or 0,c1,c2,c3,cs,cams(),table.concat(r,',')))
  if pending and f==pending then
    dump_ram(string.format('%s/gfx_%05d.bin',out,f),0x900000,0x92ffff)
    local fr=assert(io.open(string.format('%s/regs_%05d.txt',out,f),'w'))
    for i=0,0x3f do fr:write(string.format('%02x\t%04x\n',2*i,regs[i])) end
    fr:write('cam\t'..cams()..'\n')
    fr:close()
    screen:snapshot(string.format('%s/s_%05d.png',out,f))
    pending=nil
  end
  local cand=nil
  if game and st==stage and layer&0x0e~=0 then
    if rule=='fade' then
      if prev_lv=='aaa' and prev_u and lv=='fff' then cand='fade' end
    elseif rule=='steps' then
      if prev_crc and crc~=prev_crc then cand='step' end
    end
  end
  if cand then
    cg:write(string.format('%d\t%s\n',f,cand)) cg:flush()
    dump_ram(string.format('%s/pal_%05d.bin',out,f),0x914000,0x9157ff)
    pending=f+1
    if rule=='fade' and not stop then stop=f+stable+2 end
  end
  if rule=='steps' and game and st==stage and mode==4 and not stop then stop=f+2 end
  prev_lv,prev_crc,prev_u=lv,crc,(u1 and u2 and u3)
  if sa and f>=sa and f<=sb then screen:snapshot(string.format('%s/s_%05d.png',out,f)) end
  if f>=last or (stop and f>=stop and not pending) then lg:close() cg:close() m:exit() end
end)
dofile(assert(os.getenv('STREX_DEBUG_START')))
