"""Phase 2 gate: the 68K scene player shows a converted cinematic in HBMAME."""
import argparse
import hashlib
import json
import os
import struct
import subprocess
import sys
from pathlib import Path
import numpy as np
from PIL import Image
sys.path.insert(0, str(Path(__file__).resolve().parent))
import cinematic_convert as C
import cinematic_lz as LZ
import cps1_gfx as G
import mapper_testkit as K
import strider_mapper_probe as M
ROOT = Path(__file__).resolve().parents[3]
PLAYER = ROOT / 'backports/striderex/asm/scene_player.s'
LUA = ROOT / 'backports/striderex/lua/scene_gate.lua'
MB = 1048576
OFFSETS = (-3, -2, -1, 0, 1)

def hb_rgb(word):
    """HBMAME cps1_build_palette (its 'grey squares' rule: components <= 1 are 0)."""
    bright = 15 + (word >> 12 << 1)
    out = []
    for s in (8, 4, 0):
        c = word >> s & 15
        out.append(c * 17 * bright // 45 if c > 1 else 0)
    return out

def assemble(vasm, stream, work):
    lz = LZ.encode(stream)
    if LZ.decode(lz, len(stream)) != stream:
        sys.exit('LZ round trip failed')
    (work / 'scene.lz').write_bytes(lz)
    out, lst = (work / 'player.bin', work / 'player.lst')
    subprocess.run([str(vasm), '-Fbin', '-m68000', '-quiet', '-I', str(PLAYER.parent), '-L', str(lst), '-o', str(out), str(PLAYER)], cwd=work, check=True)
    syms = {}
    for line in lst.read_text().splitlines():
        f = line.split()
        if len(f) == 2 and f[1].startswith('A:'):
            syms[f[0]] = int(f[1][2:], 16)
    return (out.read_bytes(), syms)

def stage(driver_text, rom_dirs, player, syms, region, work):
    pool = M.stock_files(rom_dirs)
    p6 = bytearray(b'\xff' * MB)
    p6[:len(player)] = player
    kit = {'strex_p6.bin': K.swap16(bytes(p6))}
    kit['strex_14.8h'] = pool[K.DATA_ROM_CRC]
    kit.update(zip(K.EX_GFX, G.split_region(region)))
    kit['striderex.key'] = M.cps1_key(M.STREX)
    vectors = {4: syms['start'], 104: syms['vbl']}
    d = work / 'roms/striderex'
    d.mkdir(parents=True, exist_ok=True)
    for name, offset, size, crc in M.rom_entries(driver_text, 'striderex'):
        data = bytearray(pool[crc]) if crc else bytearray(kit[name])
        if name in ('c03ua.p1', 'c03ua.p2'):
            odd = name.endswith('p2')
            for at, value in vectors.items():
                be = struct.pack('>I', value)
                for i in range(4):
                    if (at + i) % 2 == odd:
                        data[(at + i) // 2] = be[i]
        (d / name).write_bytes(data)
    return work / 'roms'

def run(binary, roms, work, first, every, count):
    env = dict(os.environ, SDL_VIDEODRIVER='dummy', SDL_AUDIODRIVER='dummy', STREX_PREFIX=str(work / 'shot'), STREX_SHOT_FIRST=str(first), STREX_SHOT_EVERY=str(every), STREX_SHOT_COUNT=str(count))
    cmd = [str(binary), 'striderex', '-rompath', str(roms), '-nothrottle', '-video', 'none', '-sound', 'none', '-skip_gameinfo', '-noautosave', '-cfg_directory', str(work / 'cfg'), '-nvram_directory', str(work / 'nv'), '-snapshot_directory', str(work), '-autoboot_script', str(LUA)]
    p = subprocess.run(cmd, env=env, cwd=work, capture_output=True, text=True, timeout=900)
    (work / 'mame.log').write_text(p.stdout + p.stderr)
    if p.returncode:
        sys.exit(f"HBMAME exit {p.returncode}, see {work / 'mame.log'}")
    rows = (work / 'shot_shots.tsv').read_text().splitlines()[1:]
    return [(int(a), int(b)) for a, b in (r.split('\t') for r in rows)]

def model_frames(cv, stream, n):
    """Model render (palette entry indices, palette words, sprite mask) after k records, k = 0..n."""
    model = C.CpsModel(cv.region)
    out = [None]
    pos = 0
    for k in range(n):
        pos = model.run(stream, pos)
        idx = model.render()
        out.append((idx, model.pal.copy()))
    return out

def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('--census', type=Path, required=True)
    p.add_argument('--id', default='brief_siberia')
    p.add_argument('--runtime', type=Path, required=True, help='build_hbmame_probe.py output directory')
    p.add_argument('--vasm', type=Path, required=True, help='vasmm68k_mot from bootstrap_vasm.py')
    p.add_argument('--rom-dir', type=Path, action='append', required=True, help='stock striderua/strider files')
    p.add_argument('--workdir', type=Path, required=True)
    p.add_argument('--step', type=int, default=13)
    p.add_argument('--count', type=int, default=0, help='snapshots (default: cover the whole cinematic)')
    a = p.parse_args()
    work = a.workdir.resolve()
    work.mkdir(parents=True, exist_ok=False)
    cat = json.loads((a.census / 'catalog/catalog.json').read_text())
    c = next((x for x in cat['cinematics'] if x['id'] == a.id))
    run_dir = a.census / c['run']
    frames = C.frames_for(run_dir, c['cd_request_time'], c['cd_request_time'] + c['track_seconds'])
    cv, stream, _ = C.convert(run_dir, frames, 16)
    failures, _ = C.check(cv, stream, frames, run_dir, 16)
    if failures:
        sys.exit(f'conversion check failed: {failures[:3]}')
    player, syms = assemble(a.vasm, stream, work)
    runtime = json.loads((a.runtime / 'runtime.json').read_text())
    driver = (a.runtime / 'source/src/hbmame/drivers/cps1.cpp').read_text()
    roms = stage(driver, [d.resolve() for d in a.rom_dir], player, syms, cv.region, work)
    shots = run(runtime['binary'], roms, work, 5, a.step, a.count or (len(frames) + 1) // a.step)
    models = model_frames(cv, stream, cv.preroll + len(frames))
    rgb_cache = {}

    def to_rgb(idx, pal):
        words = pal[idx]
        uniq, inv = np.unique(words, return_inverse=True)
        lut = np.array([rgb_cache.setdefault(int(w), hb_rgb(int(w))) for w in uniq], np.uint8)
        return lut[inv].reshape(idx.shape + (3,))
    rows = []
    for frame, records in shots:
        snap = np.asarray(Image.open(work / f'shot_{frame:05d}.png').convert('RGB'))
        if snap.shape[:2] != (C.SCREEN_H, C.SCREEN_W):
            sys.exit(f'snapshot size {snap.shape}')
        bad = {}
        for dk in OFFSETS:
            k = records + dk
            if 1 <= k < len(models):
                idx, pal = models[k]
                bad[dk] = int((to_rgb(idx, pal) != snap).any(-1).sum())
        rows.append(dict(frame=frame, records=records, mismatched=bad))
    fits = [dk for dk in OFFSETS if all((r['mismatched'].get(dk, 0) == 0 for r in rows))]
    lags = [r['frame'] - r['records'] for r in rows if 0 < r['records'] < len(models) - 1]
    keeps_up = bool(lags) and max(lags) == min(lags)
    ok = len(fits) >= 1 and any((r['records'] > 0 for r in rows)) and keeps_up
    offsets = fits
    report = dict(id=a.id, binary_sha256=runtime['binary_sha256'], player_sha256=hashlib.sha256(player).hexdigest(), stream_bytes=len(stream), lz_bytes=(work / 'scene.lz').stat().st_size, shots=rows, offsets=offsets, lag=[min(lags), max(lags)] if lags else None, keeps_up=keeps_up, passed=ok)
    (work / 'report.json').write_text(json.dumps(report, indent=1) + '\n')
    for r in rows:
        print(r['frame'], r['records'], r['mismatched'])
    print('offsets', offsets, 'lag', report['lag'], 'PASS' if ok else 'FAIL')
    return 0 if ok else 1
if __name__ == '__main__':
    sys.exit(main())
