"""Repair the ending Earth's truncated lower-right shadow tile."""
import argparse
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import numpy as np
import cps1_gfx as G
CODE = 33751
MAP_AT = 619930
CONTEXT_AT = 619920
CONTEXT = bytes.fromhex('000c34c2000c34df010c34c3000c3496000c349e000c3497010c')
SOURCES = {13506: '87d6922c5b43dace41c3e7c608f7a254652645cf45a24b6a21c754bf8b6ac55e', 13507: 'ce286f2c58aa436cebf56dad53f6aed3b0bbc5cab93753dd0069641256f8384d', 13470: 'efe4f0346a4a44b925583f6f68d224d2be3e9e84284aaaab4f2f7fe6e9cc2129'}
GFX_FILES = ('strex_gfx.c25', 'strex_gfx.c27', 'strex_gfx.c29', 'strex_gfx.c31')

def sha(data):
    return hashlib.sha256(data).hexdigest()

def repaired_tile(stock_gfx):
    import title_ex as T
    tiles = {c: T.stock_tile(stock_gfx, c, 'scr2') for c in SOURCES}
    if any((sha(t.astype('uint8').tobytes()) != SOURCES[c] for c, t in tiles.items())):
        raise ValueError('Earth source artwork differs')
    old = tiles[13507]
    if not np.all(old[8:] == 15):
        raise ValueError('Earth tile is not truncated')
    new = old.copy()
    new[8:, :14] = tiles[13506][:8, 2:]
    new[8:, 14:] = tiles[13470][8:, :2]
    if not np.array_equal(new[:8], old[:8]) or np.any(new[8:] == 15):
        raise ValueError('Earth composite did not preserve the original upper half')
    return new

def install(region, stock_gfx):
    tile = repaired_tile(stock_gfx)
    at = G.ex_offset('scr2', CODE)
    if any(region[at:at + 128]):
        raise ValueError('Earth EX tile slot is occupied')
    G.put_tile(region, at, tile)
    return dict(code=hex(CODE), region_offset=hex(at), bytes=128, encoded_sha256=sha(region[at:at + 128]), source_pens_sha256={hex(c): digest for c, digest in SOURCES.items()}, upper_half_preserved=True, lower_half_reconstructed=True)

def patch_image(image, machine):
    if image[CONTEXT_AT:CONTEXT_AT + len(CONTEXT)] != CONTEXT:
        raise ValueError(f'{machine}: ending Earth map differs')
    image[MAP_AT:MAP_AT + 2] = CODE.to_bytes(2, 'big')
    return dict(address=hex(MAP_AT), old='34c3', new=f'{CODE:04x}', scope='ending map only', context_sha256=sha(CONTEXT))

def join_graphics(files):
    region = bytearray(4 * G.MB)
    view = np.frombuffer(region, dtype='uint8').reshape(-1, 8)
    for i, name in enumerate(GFX_FILES):
        view[:, 2 * i:2 * i + 2] = np.frombuffer(files[name], dtype='uint8').reshape(-1, 2)
    return region

def produce(build, rom_dir, out):
    import mapper_testkit as K
    import respawn_fix as RF
    import title_ex as T
    stock_gfx = T.stock_gfx(K.pool([rom_dir / 'striderua', rom_dir / 'strider']))
    metadata = json.loads((build / 'build.json').read_text())
    result = deepcopy(metadata)
    out.mkdir(parents=True, exist_ok=False)
    observations = {}
    for machine, spec in metadata['sets'].items():
        files = {n: (build / machine / n).read_bytes() for n in spec['files']}
        if any((sha(data) != spec['files'][n] for n, data in files.items())):
            raise ValueError('input build changed')
        region = join_graphics(files)
        graphics = install(region, stock_gfx)
        files.update(zip(GFX_FILES, G.split_region(region)))
        image = RF.compose(files, RF.SETS[machine])
        mapping = patch_image(image, machine)
        files.update(RF.decompose(image, RF.SETS[machine], {n: len(files[n]) for n, _, _ in RF.SETS[machine]}))
        (out / machine).mkdir()
        for n, data in files.items():
            (out / machine / n).write_bytes(data)
        observations[machine] = dict(graphics=graphics, mapping=mapping)
        result['sets'][machine]['files'] = {n: sha(data) for n, data in files.items()}
        result['sets'][machine]['earth_tile'] = observations[machine]
    (out / 'build.json').write_text(json.dumps(result, indent=2) + '\n')
    report = dict(schema='striderex-earth-tile-build/1', passed=True, input_files={m: s['files'] for m, s in metadata['sets'].items()}, build_files={m: s['files'] for m, s in result['sets'].items()}, regions=observations, script_sha256=sha(Path(__file__).read_bytes()))
    (out / 'earth-tile-build.json').write_text(json.dumps(report, indent=2) + '\n')
    print('PASS: one ending map word and one reserved composite tile per region')

def self_test():
    image = bytearray(1048576)
    image[CONTEXT_AT:CONTEXT_AT + len(CONTEXT)] = CONTEXT
    old = bytes(image)
    patch_image(image, 'test')
    assert {i for i, (a, b) in enumerate(zip(old, image)) if a != b} == {MAP_AT, MAP_AT + 1}
    image = bytearray(old)
    image[CONTEXT_AT] ^= 1
    old = bytes(image)
    try:
        patch_image(image, 'test')
    except ValueError:
        pass
    else:
        raise AssertionError('foreign map accepted')
    assert bytes(image) == old
    import title_ex as T
    import ending_ex as E
    assert T.S2_LAST < CODE < E.S2_LAST
    print('Earth tile self-test PASS')

def main():
    import sys
    if sys.argv[1:] == ['--self-test']:
        return self_test()
    p = argparse.ArgumentParser(description=__doc__)
    for name in ('build', 'rom-dir', 'out'):
        p.add_argument('--' + name, type=Path, required=True)
    a = p.parse_args()
    produce(a.build.resolve(), a.rom_dir.resolve(), a.out.resolve())
if __name__ == '__main__':
    main()
