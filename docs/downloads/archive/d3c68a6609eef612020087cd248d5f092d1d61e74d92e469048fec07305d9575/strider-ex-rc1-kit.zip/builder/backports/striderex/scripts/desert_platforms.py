"""Restore omitted metal platforms in both maps and the four pit variants."""
import argparse
from copy import deepcopy
import json
from pathlib import Path
import sys
import boss_followup_release as BF
import desert_grip_fix as F
ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / 'release'))
import private_mister as PM

def produce(a):
    record = PM.verify(a.baseline_kit.resolve())
    if record['test_id'] != '261025-13':
        raise ValueError('need verified Kit y as the control')
    with PM.qualified_view(a.baseline_kit.resolve()) as view:
        producer = json.loads((view / 'producer.json').read_text())
    meta = json.loads((a.build / 'build.json').read_text())
    rep = deepcopy(meta)
    files = {m: {n: (a.build / m / n).read_bytes() for n in s['files']} for m, s in meta['sets'].items()}
    if BF.hashes(files) != producer['build_files']:
        raise ValueError('input is not the complete Kit y build')
    old = producer['boss_followup']['stages'][2]
    for m, parts in old['reverse'].items():
        for n, rows in parts.items():
            files[m][n] = BF.reverse(files[m][n], rows)
    masks = [F.source_mask(p, True) for p in (a.map0_capture, a.map1_capture)]
    stock = F.DX.program_images(a.rom_dir)
    a.out.mkdir(parents=True, exist_ok=False)
    for m, f in files.items():
        reports = []
        base = 1703936
        for index, source_index in ((0, 0), (1, 1), (3, 0), (4, 0), (5, 0), (6, 0)):
            mask, source = masks[source_index]
            f, spec = F.patch(f, m, mask, stock[m], map_index=index, allocation_base=base, merge=True)
            if base + spec['allocation_size'] > 1802240:
                raise ValueError('platform maps reach mouth data')
            base = base + spec['allocation_size'] + 15 & ~15
            reports.append(dict(map_index=index, source=source, **spec))
        rep['sets'][m]['files'] = {n: BF.sha(b) for n, b in f.items()}
        rep['sets'][m]['desert_grip'] = dict(all_platforms=True, maps=reports, source_test_id=record['test_id'])
        d = a.out / m
        d.mkdir()
        for n, b in f.items():
            (d / n).write_bytes(b)
        print(m, 'restored platforms:', [(r['map_index'], r['source']['pce_cells'], r['tiles']) for r in reports], flush=True)
    (a.out / 'build.json').write_text(json.dumps(rep, indent=2) + '\n')

def main():
    if sys.argv[1:] == ['--self-test']:
        old = (8, 8, 0, 0)
        new = (0, 0, 4, 5)
        assert tuple((max(a, b) for a, b in zip(old, new))) == (8, 8, 4, 5)
        assert 1703936 + 98304 == 1802240
        print('Platform allocations self-test PASS: all six map allocations stop before mouth data')
        return
    p = argparse.ArgumentParser(description=__doc__)
    for n in ('build', 'baseline-kit', 'map0-capture', 'map1-capture', 'rom-dir', 'out'):
        p.add_argument('--' + n, type=Path, required=True)
    produce(p.parse_args())
if __name__ == '__main__':
    main()
