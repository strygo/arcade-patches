; Runs only in the desert's existing watcher, after the game builds its
; sprite buffer. Interpolate Hiryu's displayed Y; physics and camera stay
; native. Probe a disposable copy, never the live player object.
        org $1FE000
        jsr     HULL_SCROLL
        movem.l d0-d7/a0-a3/a6,-(sp)
        suba.l  a6,a6
        tst.w   $FFF914
        bne     .done
        cmpi.w  #4,-$73EE(a5)
        bne     .done
        move.w  -$7366(a5),d0
        cmp.w   $FFF9EE,d0
        beq     .done                   ; never shift a held buffer twice
        move.w  d0,$FFF9EE
        movea.l #1,a6
        clr.w   $FFF9EC                 ; displayed Y correction
        clr.w   $FFF9F6                 ; sprite entries changed
        move.w  -$73DE(a5),$FFF9F4
        lea     -$6F36(a5),a0
        move.w  8(a0),$FFF9FA
        move.w  $0A(a0),$FFF9FC
        move.w  $0C(a0),$FFF9F8
        moveq   #0,d1
        move.b  $22(a0),d1
        move.w  d1,$FFF9FE
        tst.b   3(a0)
        bne     .done
        cmp.w   #2,d1
        bcs     .done
        cmp.w   #7,d1
        bhi     .done
        lea     $FFD000,a1
        moveq   #23,d0
.copy:  move.l  (a0)+,(a1)+
        dbra    d0,.copy
        lea     $FFD000,a0
        subq.w  #1,8(a0)
        bsr     .probe
        bcs.s   .minus
        bra     .done
.minus: addq.w  #1,8(a0)
        cmp.w   #2,d0
        bgt     .done
        cmp.w   #-2,d0
        blt     .done
        move.w  d0,d6
        move.w  d0,d7
        bsr     .probe
        bcs.s   .center
        bra     .done
.center:
        add.w   d0,d6
        addq.w  #1,8(a0)
        bsr     .probe
        bcs.s   .plus
        bra     .done
.plus:  subq.w  #1,8(a0)
        cmp.w   #2,d0
        bgt     .done
        cmp.w   #-2,d0
        blt     .done
        add.w   d0,d6                  ; f(-1)+f(0)+f(1), relative to native Y
        addq.w  #2,8(a0)
        bsr     .probe
        bcs.s   .plus2
        bra     .done
.plus2: subq.w  #2,8(a0)
        cmp.w   #4,d0
        bgt     .done
        cmp.w   #-4,d0
        blt     .done
        sub.w   d7,d0                  ; f(2)-f(-1)
        ext.l   d6
        asl.l   #8,d6
        moveq   #0,d1
        move.w  $0A(a0),d1
        lsr.w   #8,d1
        muls.w  d0,d1
        add.l   d6,d1
        divs.w  #3,d1
        ext.l   d1
        asl.l   #8,d1
        add.l   #$8000,d1
        swap    d1
        cmp.w   #2,d1
        bgt     .done
        cmp.w   #-2,d1
        blt     .done
        move.w  d1,$FFF9EC
        add.w   d1,$FFF9F8
        tst.w   d1
        beq     .done
        moveq   #0,d0
        move.w  $FFF9EE,d0
        lsl.l   #8,d0
        movea.l d0,a1
        lea     $1FE800,a2              ; allowed native Hiryu body tile bits
        move.w  8(a0),d6
        sub.w   -$700C(a5),d6
        add.w   #64,d6
        move.w  $0C(a0),d7
        sub.w   -$7008(a5),d7
        neg.b   d7
        move.w  #255,d5
        sub.w   -$7374(a5),d5          ; only the entries actually built, not 256 blank tail cells
        bmi.s   .done
.sprite:
        move.w  6(a1),d0
        cmp.w   #$FF00,d0
        bcc.s   .done
        and.w   #31,d0
        cmp.w   #14,d0
        bne.s   .next
        move.w  4(a1),d0
        cmp.w   #$2000,d0
        bcc.s   .next
        move.w  d0,d1
        lsr.w   #3,d0
        move.b  0(a2,d0.w),d0
        and.w   #7,d1
        btst    d1,d0
        beq.s   .next
        move.w  (a1),d0
        sub.w   d6,d0
        lsl.w   #7,d0
        asr.w   #7,d0
        cmp.w   #64,d0
        bgt.s   .next
        cmp.w   #-64,d0
        blt.s   .next
        move.w  2(a1),d0
        sub.w   d7,d0
        ext.w   d0                      ; native sprite Y wraps at 256
        cmp.w   #64,d0
        bgt.s   .next
        cmp.w   #-64,d0
        blt.s   .next
        move.w  $FFF9EC,d0
        sub.w   d0,2(a1)
        addq.w  #1,$FFF9F6
.next:  lea     8(a1),a1
        dbra    d5,.sprite
.done:  move.l  a6,d0
        beq.s   .return
        addq.w  #1,$FFF9F0              ; after all edits: trace boundary for the acceptance gate
.return:
        movem.l (sp)+,d0-d7/a0-a3/a6
        jmp     WATCH_LOOP
.probe:
        move.w  $0C(a0),-(sp)
        move.w  $22(a0),-(sp)
        move.w  $24(a0),-(sp)
        jsr     $1A3E.w
        bcc.s   .miss
        add.w   $0C(a0),d0
        sub.w   4(sp),d0
        move.w  (sp)+,$24(a0)
        move.w  (sp)+,$22(a0)
        move.w  (sp)+,$0C(a0)
        move.w  #1,ccr
        rts
.miss:  move.w  (sp)+,$24(a0)
        move.w  (sp)+,$22(a0)
        move.w  (sp)+,$0C(a0)
        move.w  #0,ccr
        rts
