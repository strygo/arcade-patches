; Strider EX: the PC Engine boss portraits over arcade gameplay (W3b, D8).
;
; Included in the EX bank (ex_bank.s); scripts/portrait_ex.py writes
; portraits.inc (per region: the hook stubs, the portrait table, the
; pictures' sprite codes, palettes and mouth sequences) and patches the
; stock program:
;   - the gameplay sprite frame (USA 0x6F4C4, Japan by signature): its first
;     two calls (bsr <list init> / bsr <first emitter>) become
;     jsr pt_frame / nop. pt_frame runs the list init (A4 = the back list),
;     puts the portrait's entry first in the game's own list (on top of every
;     sprite, as the PC Engine draws it from SAT entry 0), takes it from the
;     game's own entry budget, then jumps to the first emitter. The list is
;     the one the game shows with its OBJ base write at the next VBlank, so
;     on the board (which copies the table only on that write) the portrait
;     travels with the game's own sprites.
;   - one instruction (or two) at each encounter start becomes a jsr to a
;     stub that arms the portrait, then replays the replaced bytes (copied
;     verbatim, so the condition codes are the stock ones on return).
; While no portrait shows, a frame costs one compare and branch (~30 cycles).
;
; A portrait is one block sprite: 8x5 16x16 cells (the 80x80 PC Engine box
; widened to 120 by method E, D5), codes c + col + 16 * row. Its colors use
; one OBJ palette slot (PT_SLOT, never referenced by a gameplay sprite;
; MEASURED), saved when a portrait starts and put back after it. The board
; shows a sprite list from the base write after the one that copied it, a
; frame after MAME, while palette RAM is copied at every VBlank; so the
; portrait's colors stay PT_TAIL frames after its last entry, and the saved
; colors return only then.
;
; A portrait ends after its sequence (the PC Engine's mouth animation, in
; frames), or at once when the player's life count drops (a death).
; Nothing here changes game state: only the sprite list, the budget counters
; the list builder keeps for that list, and the one palette slot.

PT_VARS  equ $FFF940                    ; work RAM (the EX block: cinematic VARS below, CAPVARS at 0xFFF980)
PT_ON    equ PT_VARS+$00                ; word: PT_MAGIC while a portrait (or its tail) is up
PT_ID    equ PT_VARS+$02                ; word: portrait index
PT_X     equ PT_VARS+$04                ; word: sprite X (screen x + 64)
PT_Y     equ PT_VARS+$06                ; word: sprite Y (screen y + 16)
PT_RUN   equ PT_VARS+$08                ; long: current sequence entry (dc.w frames, code)
PT_LEFT  equ PT_VARS+$0C                ; word: frames left in the current entry
PT_TAIL  equ PT_VARS+$0E                ; word: >0 = drawing done, palette held this many frames more
PT_PAL   equ PT_VARS+$10                ; long: the portrait's 16 colors
PT_LIVES equ PT_VARS+$14                ; byte: the life count when it started
PT_SAVE  equ PT_VARS+$16                ; 16 words: the slot's own colors (to 0xFFF976)
PT_MAGIC equ $9E7A                      ; (work RAM is not cleared before the first frame)
PT_TAILN equ 2                          ; frames the colors outlast the last entry (board sprite lag + 1)
PT_SLOTA equ $914000+32*PT_SLOT         ; the slot in palette RAM (the VBlank's base, every frame)
PT_ATTR  equ $4700+PT_SLOT              ; block 8x5 (nx-1 = 7, ny-1 = 4), the slot's palette
LIVES    equ -$7358                     ; (a5) 0xFF0CA8 player 1 lives
BUDGET   equ -$7372                     ; (a5) entries the list may still take (emitters test it)
USED     equ -$7374                     ; (a5) 256 minus entries written (the list finalizer reads it)

; ------------------------------------------------------------ the frame
pt_frame:
        jsr     PT_INIT                 ; the replaced first call: A4 = the back list
        cmp.w   #PT_MAGIC,PT_ON
        bne.s   .next
        bsr.s   pt_draw
.next:  jmp     PT_NEXT                 ; the replaced second call; returns to the frame routine

pt_draw:
        movem.l d0/a0-a1,-(sp)
        move.b  LIVES(a5),d0
        cmp.b   PT_LIVES,d0
        bcs.s   .death                  ; fewer lives than at the start (an extra life is no reason)
        tst.w   PT_TAIL
        bne.s   .tail
        tst.w   BUDGET(a5)              ; the entry is the list's first: always room, but keep
        ble.s   .pal                    ; the game's own accounting exact
        subq.w  #1,BUDGET(a5)
        subq.w  #1,USED(a5)
        move.l  PT_RUN,a0
        move.w  PT_X,(a4)+
        move.w  PT_Y,(a4)+
        move.w  2(a0),(a4)+             ; the picture's first code
        move.w  #PT_ATTR,(a4)+
.pal:   bsr.s   pt_colors
        subq.w  #1,PT_LEFT
        bne.s   .out
        move.l  PT_RUN,a0
        addq.l  #4,a0
        move.l  a0,PT_RUN
        move.w  (a0),PT_LEFT
        bne.s   .out
.end:   move.w  #PT_TAILN,PT_TAIL       ; sequence over: no more entries
.out:   movem.l (sp)+,d0/a0-a1
        rts
.death: tst.w   PT_TAIL
        beq.s   .end                    ; a death ends it now (its colors still get the tail)
.tail:  bsr.s   pt_colors
        subq.w  #1,PT_TAIL
        bne.s   .out
        lea     PT_SAVE,a0              ; put the slot's own colors back
        lea     PT_SLOTA,a1
        moveq   #8-1,d0
.rs:    move.l  (a0)+,(a1)+
        dbra    d0,.rs
        clr.w   PT_ON
        bra.s   .out

pt_colors:
        move.l  PT_PAL,a0
        lea     PT_SLOTA,a1
        moveq   #8-1,d0
.c:     move.l  (a0)+,(a1)+
        dbra    d0,.c
        rts

; ------------------------------------------------------------ arming
; d0 = portrait index (pt_table entry). Called from the hook stubs with the
; registers they need saved; uses d0-d1/a0-a1.
pt_arm:
        cmp.w   #PT_MAGIC,PT_ON
        bne.s   .fresh
        tst.w   PT_TAIL
        bne.s   .take                   ; the last one is only holding its colors: replace it
        cmp.w   PT_ID,d0
        beq.s   .done                   ; already showing this one
        bra.s   .take
.fresh: lea     PT_SLOTA,a0             ; keep the slot's own colors
        lea     PT_SAVE,a1
        moveq   #8-1,d1
.sv:    move.l  (a0)+,(a1)+
        dbra    d1,.sv
.take:  move.w  d0,PT_ID
        lea     pt_table,a0
        mulu    #12,d0
        add.w   d0,a0                   ; dc.w x, y ; dc.l sequence, colors
        move.w  (a0)+,PT_X
        move.w  (a0)+,PT_Y
        move.l  (a0)+,a1
        move.l  a1,PT_RUN
        move.w  (a1),PT_LEFT
        move.l  (a0),PT_PAL
        clr.w   PT_TAIL
        move.b  LIVES(a5),PT_LIVES
        move.w  #PT_MAGIC,PT_ON
.done:  rts

; pt_arm_stage: d0 = portrait index, d1 = the internal stage it belongs to
pt_arm_stage:
        cmp.b   -$734E(a5),d1           ; 0xFF0CB2 internal stage
        bne.s   .no
        bsr.s   pt_arm
.no:    rts
