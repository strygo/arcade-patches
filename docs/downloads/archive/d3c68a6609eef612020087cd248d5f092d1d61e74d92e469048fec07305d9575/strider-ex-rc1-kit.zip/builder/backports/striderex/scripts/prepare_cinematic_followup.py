"""Prepare a cinematic-score baseline/proof or combine focused runtime checks."""
from __future__ import annotations
import argparse
from copy import deepcopy
import json
from pathlib import Path
import sys
import zipfile
from cinematic_followup import LEGACY, SOUND, sha, json_sha, verify, self_test, reverse_member, reverse_earth, reverse_tile

def combine_runtime(argv):
    p = argparse.ArgumentParser(description='Replace failed score checks with focused passing follow-ups on the same ROM inputs.')
    for name in ('base', 'followup', 'runtime', 'receipt'):
        p.add_argument('--' + name, type=Path, required=True)
    a = p.parse_args(argv)
    base = json.loads(a.base.read_text())
    followup = json.loads(a.followup.read_text())
    if not base['full_matrix'] or not followup['passed'] or any((base[k] != followup[k] for k in ('schema', 'build_files', 'control_files'))):
        p.error('need a full base and passing focused follow-up on identical files')
    key = lambda r: (r['set'], r['stage'], r['variant'], r.get('scene'))
    newer = {key(r): r for r in followup['results']}
    if not all((r['passed'] for r in newer.values())):
        p.error('focused follow-up has failures')
    replaced, rows = ([], [])
    for row in base['results']:
        if not row['passed']:
            replacement = newer.get(key(row))
            if replacement is None:
                p.error('failed check has no passing follow-up: ' + str(key(row)))
            replaced.append(row)
            row = replacement
        rows.append(row)
    if 'native_transition' in base:
        old, new = (base['native_transition'], followup.get('native_transition', {}))
        if old.get('reference_files') != new.get('reference_files') or old.get('baseline_test_id') != new.get('baseline_test_id'):
            p.error('transition follow-up used a different reference')
        replaced_transition = []
        for group in ('pack_parity', 'continuity', 'opening'):
            key_transition = lambda r: (r['set'], r.get('stage'), r.get('variant'))
            newer_transition = {key_transition(r): r for r in new[group]}
            final = []
            for row in old[group]:
                if not row['passed']:
                    replacement = newer_transition.get(key_transition(row))
                    if replacement is None or not replacement['passed']:
                        p.error('transition failure has no passing follow-up')
                    replaced_transition.append(dict(group=group, **row))
                    row = replacement
                final.append(row)
            old[group] = final
        old['passed'] = all((r['passed'] for group in ('pack_parity', 'continuity', 'opening') for r in old[group]))
        base['superseded_transition_failures'] = replaced_transition
    base['results'] = rows
    base['superseded_failures'] = replaced
    base['base_receipt_sha256'] = sha(a.base.read_bytes())
    base['followup_receipt_sha256'] = sha(a.followup.read_bytes())
    meta = json.loads((a.runtime / 'runtime.json').read_text())
    if sha(Path(meta['binary']).read_bytes()) != meta['binary_sha256']:
        p.error('runtime binary changed')
    base['runtime'] = {k: meta[k] for k in ('binary_sha256', 'board_wait', 'source_revision')}
    base['passed'] = all((r['passed'] for r in rows)) and all((r['failed'] for r in base['negative_control'])) and base.get('native_transition', {'passed': True})['passed']
    a.receipt.write_text(json.dumps(base, indent=2) + '\n')
    print('PASS' if base['passed'] else 'FAIL', len(rows), 'checks;', len(replaced), 'diagnosed failures replaced')

def prepare(a):
    root = Path(__file__).resolve().parents[3]
    sys.path.insert(0, str(root / 'release'))
    import private_mister as PM
    import cinematic_music as CM
    import restore_tunes as RT
    build = json.loads((a.build / 'build.json').read_text())
    bank, source = RT.load_bank(a.x68k_archive)
    control = a.control.resolve()
    control.mkdir(parents=True, exist_ok=False)
    with PM.qualified_view(a.baseline_kit.resolve()) as view:
        producer = json.loads((view / 'producer.json').read_text())
        baseline = producer['build_files']
        fading = all((s.get('native_fade') for s in build['sets'].values()))
        transition = all((s.get('native_opening') for s in build['sets'].values()))
        tile = all((s.get('earth_tile') for s in build['sets'].values()))
        earth = tile or all((s.get('earth_palette') for s in build['sets'].values()))
        proof = dict(schema='striderex-cinematic-inheritance/' + ('6' if tile and transition else '5' if earth and transition else '4' if transition else '3' if fading else '2' if a.score == 'original' else '1'), score=a.score, passed=True, baseline_test_id=json.loads((a.baseline_kit / 'private-mister.json').read_text())['test_id'], baseline_producer_sha256=sha((view / 'producer.json').read_bytes()), baseline_files=baseline, build_files={m: s['files'] for m, s in build['sets'].items()}, baseline_qualifications={s: json_sha(q) for s, q in producer['qualification'].items()}, baseline_rtl_sha256=json_sha(producer['rtl']), x68000=source, regions={})
        candidate, old = ({}, {})
        for machine, spec in build['sets'].items():
            region = 'us' if machine == 'striderua' else 'jp'
            with zipfile.ZipFile(view / f'games/mame/striderex_{region}.zip') as z:
                old[machine] = {name: z.read(name) for name in baseline[machine]}
            candidate[machine] = {name: (a.build / machine / name).read_bytes() for name in spec['files']}
            if a.score == 'original':
                import original_cinematic as OC
                sound, installed = OC.install(old[machine][SOUND[machine]], CM.COMMAND)
            else:
                sound, installed = CM.install(old[machine][SOUND[machine]], bank)
            if sound != candidate[machine][SOUND[machine]]:
                raise ValueError('final sound ROM differs from declared cinematic recipe')
            order = [s['id'] for s in build['scenes']]
            proof['regions'][machine] = dict(table_offset=int(spec['nopack_cues_at'], 16) - 1048576, scene_order=order, sound_patch=installed)
            if fading:
                proof['regions'][machine]['native_fade'] = spec['native_fade']
            if transition:
                proof['regions'][machine]['native_opening'] = spec['native_opening']
            if earth:
                proof['regions'][machine]['earth_palette'] = spec.get('earth_palette', {'inherited_by_exact_reversal': True})
            if tile:
                proof['regions'][machine]['earth_tile'] = spec['earth_tile']
            for name, data in old[machine].items():
                if sha(data) != baseline[machine][name]:
                    raise ValueError('sealed baseline differs: ' + name)
                if transition:
                    data = reverse_member(candidate[machine][name], machine, name, proof, True)
                target = control / machine / name
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(data)
        if transition:
            proof['control_files'] = {m: {n: sha((control / m / n).read_bytes()) for n in files} for m, files in baseline.items()}
        if earth and transition:
            earth_members = {m: {n: reverse_tile(data, m, n) for n, data in files.items()} for m, files in candidate.items()} if tile else candidate
            if tile:
                proof['earth_source_files'] = {m: {n: sha(data) for n, data in files.items()} for m, files in earth_members.items()}
            proof['native_source_files'] = {m: {n: sha(reverse_earth(data, m, n)) for n, data in files.items()} for m, files in earth_members.items()}
        verify(proof, candidate)
    control_json = deepcopy(build)
    for machine, spec in control_json['sets'].items():
        spec['files'] = proof.get('control_files', baseline)[machine]
        spec['nopack_cues'] = {sid: cue for sid, cue in LEGACY.items() if cue}
    control_json['control_from_verified_private_kit'] = proof['baseline_test_id']
    (control / 'build.json').write_text(json.dumps(control_json, indent=2) + '\n')
    a.receipt.write_text(json.dumps(proof, indent=2) + '\n')
    print('PASS: exact sealed Kit p reconstruction; only declared scene/native/Earth changes differ')

def main():
    if len(sys.argv) > 1 and sys.argv[1] == 'combine':
        return combine_runtime(sys.argv[2:])
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--self-test', action='store_true')
    p.add_argument('--score', choices=('amazon', 'original'), default='amazon')
    for name in ('build', 'baseline-kit', 'control', 'x68k-archive', 'receipt'):
        p.add_argument('--' + name, type=Path)
    a = p.parse_args()
    if a.self_test:
        return self_test()
    if any((v is None for k, v in vars(a).items() if k not in ('self_test', 'score'))):
        p.error('all input paths are required')
    prepare(a)
if __name__ == '__main__':
    main()
