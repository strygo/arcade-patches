"""Native no-pack cinematic bed: loop the alternate X68000 Amazon intro."""
from __future__ import annotations
import argparse
import json
import shutil
import subprocess
from pathlib import Path
import ending_ex as EE
import nopack_intros as NI
import restore_tunes as RT
import sfx_gate as SG
COMMAND = 36
SOURCE = 19
BASE = 28672
LIMIT = 32512

def phrase_notes(ym, t0, t1):
    """Sequence notes after each channel's first pitch write after the cue."""
    pitch, notes = ({}, [])
    for t, register, value in ym:
        if not t0 <= t < t1:
            continue
        if 40 <= register <= 47:
            pitch[register - 40] = value
        elif register == 8 and value & 120 and (value & 7 in pitch):
            channel = value & 7
            notes.append((t - t0, channel, pitch[channel]))
    return notes

def install(sound, bank):
    at, n = RT.arcade_table(sound)
    pointers = RT.table_ptrs(sound, at, n)
    if pointers[COMMAND] != pointers[0]:
        raise RT.RestoreError('cinematic slot is not the stock tune-0 alias')
    xat, xn = RT.x68k_table(bank)
    xp = RT.table_ptrs(bank, xat, xn)
    start, end = RT.song_bounds(xp, SOURCE, len(bank))
    song, fields = RT.relocate(bank, start, end, BASE)
    for i in fields['instruments']:
        a, x = (RT.INSTR_ARCADE + 40 * i, RT.INSTR_X68K + 40 * i)
        if sound[a:a + 40] != bank[x:x + 40]:
            raise RT.RestoreError(f'cinematic instrument {i:#04x} differs')
    if BASE + len(song) >= LIMIT or any((b not in (0, 255) for b in sound[BASE:BASE + len(song)])):
        raise RT.RestoreError('cinematic allocation is not erased')
    patched = bytearray(sound)
    patched[BASE:BASE + len(song)] = song
    patched[at + 2 * COMMAND:at + 2 * COMMAND + 2] = BASE.to_bytes(2, 'little')
    patched, loop = EE.loop_song(bytes(patched), COMMAND)
    lo, hi = (int(loop['loop_at'], 16), int(loop['loop_at'], 16) + loop['loop_size'])
    if hi > LIMIT:
        raise RT.RestoreError('cinematic loop overlaps the PC Engine effects table')
    allowed = set(range(BASE, BASE + len(song))) | set(range(lo, hi)) | {at + 2 * COMMAND, at + 2 * COMMAND + 1}
    changed = [i for i in range(len(sound)) if sound[i] != patched[i]]
    if not set(changed) <= allowed:
        raise RT.RestoreError('cinematic installation changed unrelated bytes')
    return (patched, dict(command=hex(COMMAND), source_command=hex(SOURCE), source_song_sha256=RT.sha256(bank[start:end]), one_shot_address=hex(BASE), one_shot_size=len(song), loop=loop, instruments_identical=fields['instruments'], bytes_changed=len(changed), input_sha256=RT.sha256(sound), output_sha256=RT.sha256(patched)))

def audition(a):
    work, out = (a.workdir.resolve(), a.out.resolve())
    work.mkdir(parents=True, exist_ok=False)
    out.mkdir(parents=True, exist_ok=False)
    sound, inputs = RT.load_sound(a.rom_dir.resolve())
    bank, source = RT.load_bank(a.x68k_archive.resolve())
    sound, _ = RT.build_patch(sound, bank)
    sound, _ = EE.loop_song(sound)
    sound, patch = install(sound, bank)
    at, _ = RT.arcade_table(sound)
    test = bytearray(sound)
    test[at + 2 * 37:at + 2 * 37 + 2] = BASE.to_bytes(2, 'little')
    roms = work / 'roms/striderua'
    roms.mkdir(parents=True)
    for p in (a.rom_dir.resolve() / 'striderua').iterdir():
        if p.is_file():
            shutil.copy2(p, roms / p.name)
    (roms / '09.12b').write_bytes(test)
    r = SG.run(a.mame, roms.parent, 'striderua', work / 'run', [37, COMMAND], 110.0)
    results = []
    note_lists = []
    for k, label in enumerate(('one-shot', 'loop')):
        t0 = r['slots'][k][1]
        notes = phrase_notes(r['ym'], t0, t0 + 110)
        note_lists.append(notes)
        period = NI.find_loop(notes)
        end = NI.audible_end(r['mix'], SG.SR, t0, t0 + 110)
        row = dict(variant=label, key_ons=len(notes), audible_end_s=round(end, 3), last_note_s=round(notes[-1][0], 3), loop_start_s=round(period[0], 3) if period else None, loop_period_s=round(period[1], 3) if period else None)
        length = 45 if k else end + 0.5
        target = out / (label + '.mp3')
        subprocess.run(['ffmpeg', '-v', 'error', '-y', '-ss', str(t0), '-i', str(work / 'run/mix.wav'), '-t', str(length), '-codec:a', 'libmp3lame', '-b:a', '192k', str(target)], check=True)
        row.update(file=target.name, sha256=RT.sha256(target.read_bytes()))
        results.append(row)
    intact = True
    for ch in range(8):
        original = [(t, p) for t, c, p in note_lists[0] if c == ch]
        repeated = [(t, p) for t, c, p in note_lists[1] if c == ch]
        intact &= len(repeated) >= len(original) and all((p == q and abs(t - u) < 0.02 for (t, p), (u, q) in zip(original, repeated)))
    passed = intact and results[0]['audible_end_s'] < 20 and (results[1]['audible_end_s'] > 109) and (results[1]['last_note_s'] > 109) and (results[1]['loop_period_s'] is not None)
    report = dict(schema='striderex-cinematic-loop/1', inputs=inputs, x68000=source, patch=patch, original_phrase_intact=intact, passed=passed, results=results)
    (out / 'loop.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2), flush=True)
    return 0 if passed else 1

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--self-test', action='store_true')
    p.add_argument('--rom-dir', type=Path, required=True)
    p.add_argument('--x68k-archive', type=Path, required=True)
    p.add_argument('--workdir', type=Path)
    p.add_argument('--out', type=Path)
    p.add_argument('--mame', default='mame')
    a = p.parse_args()
    if a.self_test:
        sound, _ = RT.load_sound(a.rom_dir.resolve())
        bank, _ = RT.load_bank(a.x68k_archive.resolve())
        sound, _ = RT.build_patch(sound, bank)
        sound, _ = EE.loop_song(sound)
        installed, report = install(sound, bank)
        at, _ = RT.arcade_table(sound)
        for cause in ('occupied', 'slot', 'instrument'):
            bad = bytearray(sound)
            bad[BASE if cause == 'occupied' else at + 2 * COMMAND if cause == 'slot' else RT.INSTR_ARCADE] ^= 66
            try:
                install(bytes(bad), bank)
            except RT.RestoreError:
                pass
            else:
                raise AssertionError('unsafe cinematic allocation accepted: ' + cause)
        assert installed[LIMIT:] == sound[LIMIT:]
        assert report['loop']['tracks'] == 6
        assert phrase_notes([(0.1, 8, 120), (0.2, 40, 65), (0.3, 8, 120)], 0, 1) == [(0.3, 0, 65)]
        print('self-test PASS')
        return 0
    if a.workdir is None or a.out is None:
        p.error('--workdir and --out are required for the audition')
    return audition(a)
if __name__ == '__main__':
    raise SystemExit(main())
