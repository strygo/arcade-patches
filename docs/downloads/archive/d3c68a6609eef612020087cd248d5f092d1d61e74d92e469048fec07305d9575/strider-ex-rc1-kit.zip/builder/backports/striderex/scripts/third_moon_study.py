"""Analyze the ending-specific stage-clear observation/presentation pair."""
import argparse
import csv
import hashlib
import json
from pathlib import Path
import struct
import tempfile
import stage_clear_study as S

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def rows(p):
    with p.open() as f:
        return list(csv.DictReader(f, delimiter='\t'))

def events(p):
    return {k: int(f) for f, k, v in (line.split('\t') for line in p.read_text().splitlines())}

def code(rom_dir, build):
    import respawn_fix as R
    import desert_ex as D
    result = {}
    for machine in R.SETS:
        stock = {p.name: p.read_bytes() for p in (rom_dir / machine).iterdir() if p.is_file()}
        original = R.compose(stock, R.SETS[machine])
        files = {p.name: p.read_bytes() for p in (build / machine).iterdir() if p.is_file()}
        candidate = R.compose({**stock, **files}, R.SETS[machine])
        symbols = D.locate(original)
        table = symbols['DZ_CLEAR'] + 36
        handler = table + struct.unpack_from('>h', original, table + 8)[0]
        spans = [(10072, 10174, 'leap_and_explosion_loop'), (handler, handler + 306, 'final_clear_handler')]
        result[machine] = {}
        for start, end, label in spans:
            a, b = (original[start:end], candidate[start:end])
            if a != b:
                raise ValueError(machine + ': stock ending code changed: ' + label)
            result[machine][label] = dict(start=hex(start), bytes=end - start, stock_matches_ex=True, sha256=hashlib.sha256(a).hexdigest())
    return result

def compare(control, experiment, review):
    from PIL import Image, ImageDraw
    reports = [json.loads((d / 'report.json').read_text()) for d in (control, experiment)]
    a, b = reports
    if not all((r['completed'] and (not r['lua_errors']) and r['third_moon'] and (r['forced_clear_at'] is None) for r in reports)):
        raise ValueError('incomplete or synthetic ending run')
    if a['moon_experiment'] or not b['moon_experiment']:
        raise ValueError('need one untouched control and one Third Moon experiment')
    for key in ('machine', 'rom_inputs', 'runtime_sha256', 'lua_sha256', 'extension_sha256', 'clear_frame', 'frames'):
        if a[key] != b[key]:
            raise ValueError('input or execution mismatch: ' + key)
    ea, eb = [events(d / 'moon_events.tsv') for d in (control, experiment)]
    for k in ('clear-entry', 'bonus-position', 'roll-black'):
        if ea.get(k) is None or ea[k] != eb.get(k):
            raise ValueError('ending phase mismatch: ' + k)
    clear = a['clear_frame']
    entry = ea['clear-entry']
    roll = ea['roll-black']
    restored = eb.get('palettes-restored')
    if restored is None or not roll <= restored <= roll + 4:
        raise ValueError('inherited palettes were not restored during the credits blackout')
    if not 360 <= entry - clear <= 370:
        raise ValueError('unexpected post-leap clear timing')
    x, y = [rows(d / 'frames.tsv') for d in (control, experiment)]
    keys = ('frame', 'mode', 'stage', 'state', 'sub', 'x', 'y', 'camx', 'camy', 'layer', 'objbase', 'active')
    if len(x) != len(y) or any((any((r[k] != s[k] for k in keys)) for r, s in zip(x, y))):
        raise ValueError('non-presentation game flow changed')
    if (control / 'debug_log.tsv').read_bytes() != (experiment / 'debug_log.tsv').read_bytes():
        raise ValueError('sound or debug-input timeline changed')
    ma, mb = [rows(d / 'moon.tsv') for d in (control, experiment)]
    if any((r['system_objects'] != s['system_objects'] for r, s in zip(ma, mb))):
        raise ValueError('ending system-object states changed')
    files = [{int(p.stem[2:]): p for p in d.glob('s_*.png')} for d in (control, experiment)]
    frames = sorted(set(files[0]) & set(files[1]))

    def same(f):
        return Image.open(files[0][f]).convert('RGB').tobytes() == Image.open(files[1][f]).convert('RGB').tobytes()
    leap = [f for f in frames if clear - 10 <= f <= entry]
    credits = [f for f in frames if f >= roll + 3]
    if len(leap) < 70 or len(credits) < 70 or (not all((same(f) for f in leap + credits))):
        raise ValueError('leap/explosion or credits pixels changed')
    changed = [f for f in frames if not same(f)]
    if not changed:
        raise ValueError('experiment made no visible change')
    review.mkdir(parents=True, exist_ok=False)

    def picture(f):
        out = Image.new('RGB', (768, 244))
        draw = ImageDraw.Draw(out)
        for j, label in enumerate(('Current EX', 'Third Moon presentation experiment')):
            out.paste(Image.open(files[j][f]).convert('RGB'), (384 * j, 20))
            draw.text((384 * j + 4, 4), f'{label} | clear {f - clear:+d}', fill='white')
        return out
    clip = [f for f in frames if clear - 10 <= f <= roll + 70]
    images = [picture(f) for f in clip]
    durations = [max(10, round((q - p) * 100 / 59.637) * 10) for p, q in zip(clip, clip[1:])] + [500]
    images[0].save(review / 'comparison.gif', save_all=True, append_images=images[1:], duration=durations, loop=0)
    poster = Image.new('RGB', (768, 244 * 5))
    for i, target in enumerate((clear + 100, entry + 2, clear + 420, ea['bonus-position'] + 25, roll - 5)):
        poster.paste(picture(min(frames, key=lambda f: abs(f - target))), (0, 244 * i))
    poster.save(review / 'comparison.png')
    return dict(schema='striderex-third-moon-presentation-study/1', machine=a['machine'], release_qualification=False, native_patch_implemented=False, hardware_review_granted=False, frames=len(x), rom_inputs=a['rom_inputs'], runtime_sha256=a['runtime_sha256'], lua_sha256=a['lua_sha256'], extension_sha256=a['extension_sha256'], phase_frames={k: dict(absolute=v, relative_to_clear=v - clear) for k, v in ea.items()}, palettes_restored_relative_frame=restored - clear, game_flow_positions_clocks_identical=True, system_objects_identical=True, sound_command_log_identical=True, leap_explosion_identical_pictures=len(leap), credits_identical_pictures=len(credits), changed_pictures=len(changed), first_changed_relative_frame=changed[0] - clear, last_changed_relative_frame=changed[-1] - clear, report_sha256={label: sha(d / 'report.json') for label, d in (('control', control), ('experiment', experiment))}, preview_sha256={p.name: sha(p) for p in review.iterdir()})

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--self-test', action='store_true')
    for name in ('control', 'experiment', 'review', 'receipt', 'rom-dir', 'build'):
        p.add_argument('--' + name, type=Path)
    a = p.parse_args()
    if a.self_test:
        with tempfile.TemporaryDirectory() as tmp:
            q = Path(tmp) / 'events.tsv'
            q.write_text('100\tclear-entry\t49542\n200\troll-black\t50284\n')
            assert events(q) == {'clear-entry': 100, 'roll-black': 200}
        print('Third Moon study self-test passed')
        return
    if not all((a.control, a.experiment, a.review, a.receipt)):
        p.error('--control, --experiment, --review and --receipt are required')
    result = compare(a.control, a.experiment, a.review)
    if a.rom_dir or a.build:
        if not (a.rom_dir and a.build):
            p.error('provide both --rom-dir and --build for the stock-code study')
        result['stock_code'] = code(a.rom_dir, a.build)
    a.receipt.parent.mkdir(parents=True, exist_ok=True)
    a.receipt.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: v for k, v in result.items() if k not in ('rom_inputs', 'stock_code')}, indent=2))
if __name__ == '__main__':
    main()
