"""OKI MSM6295 ADPCM, bit-exact with MAME's decoder (src/devices/sound/okiadpcm.cpp, okim6295.cpp)."""
import argparse
import math
import sys
import numpy as np
STEPS = 49
INDEX_SHIFT = (-1, -1, -1, -1, 2, 4, 6, 8)
NBL2BIT = ((1, 0, 0, 0), (1, 0, 0, 1), (1, 0, 1, 0), (1, 0, 1, 1), (1, 1, 0, 0), (1, 1, 0, 1), (1, 1, 1, 0), (1, 1, 1, 1), (-1, 0, 0, 0), (-1, 0, 0, 1), (-1, 0, 1, 0), (-1, 0, 1, 1), (-1, 1, 0, 0), (-1, 1, 0, 1), (-1, 1, 1, 0), (-1, 1, 1, 1))
DIFF = np.zeros((STEPS, 16), dtype=np.int64)
for _s in range(STEPS):
    _v = math.floor(16.0 * pow(11.0 / 10.0, _s))
    for _n in range(16):
        _b = NBL2BIT[_n]
        DIFF[_s, _n] = _b[0] * (_v * _b[1] + _v // 2 * _b[2] + _v // 4 * _b[3] + _v // 8)
IDX = np.array(INDEX_SHIFT * 2, dtype=np.int64)
VOLUME = (32, 22, 16, 11, 8, 6, 4, 3, 2, 0, 0, 0, 0, 0, 0, 0)

def volume_db(n):
    return 20 * math.log10(VOLUME[n] / 32)

def step(sig, st, n):
    sig = max(-2048, min(2047, sig + int(DIFF[st, n])))
    st = max(0, min(48, st + INDEX_SHIFT[n & 7]))
    return (sig, st)

def decode_nibbles(nibs):
    sig = st = 0
    out = np.empty(len(nibs), dtype=np.int64)
    for i, n in enumerate(nibs):
        sig, st = step(sig, st, n)
        out[i] = sig
    return out

def phrase_nibbles(rom, start, stop):
    """The nibbles MAME plays for a phrase header (start, stop): 2 * (stop - start + 1), high first."""
    return [rom[start + k // 2] >> ((k & 1) << 2 ^ 4) & 15 for k in range(2 * (stop - start + 1))]

def decode_phrase(rom, start, stop):
    return decode_nibbles(phrase_nibbles(rom, start, stop))

def pack(nibs):
    nibs = list(nibs) + ([0] if len(nibs) % 2 else [])
    return bytes((nibs[i] << 4 | nibs[i + 1] for i in range(0, len(nibs), 2)))

def encode_greedy(x):
    """Per sample, the nibble with the least squared error (the reference the trellis must beat)."""
    sig = st = 0
    out = []
    for v in np.asarray(x, dtype=float):
        best = min(range(16), key=lambda n: ((v - step(sig, st, n)[0]) ** 2, n))
        sig, st = step(sig, st, best)
        out.append(best)
    return out

def encode_trellis(x, beam=2048):
    """The nibbles whose decode is closest to x (squared error) among the paths a `beam`-wide"""
    x = np.asarray(x, dtype=float)
    sig = np.zeros(1, dtype=np.int64)
    st = np.zeros(1, dtype=np.int64)
    cost = np.zeros(1)
    parents, nibs_at = ([], [])
    n16 = np.arange(16)
    for i in range(len(x)):
        s2 = np.clip(sig[:, None] + DIFF[st], -2048, 2047)
        t2 = np.clip(st[:, None] + IDX[None, :], 0, 48)
        d = x[i] - s2
        c2 = cost[:, None] + d * d
        s2, t2, c2 = (s2.ravel(), t2.ravel(), c2.ravel())
        par = np.repeat(np.arange(len(sig)), 16)
        nib = np.tile(n16, len(sig))
        order = np.argsort(c2, kind='stable')
        key = (s2[order] + 2048) * STEPS + t2[order]
        _, first = np.unique(key, return_index=True)
        keep = order[np.sort(first)]
        keep = keep[np.argsort(c2[keep], kind='stable')][:beam]
        sig, st, cost = (s2[keep], t2[keep], c2[keep])
        parents.append(par[keep])
        nibs_at.append(nib[keep])
    k = int(np.argmin(cost))
    out = [0] * len(x)
    for i in range(len(x) - 1, -1, -1):
        out[i] = int(nibs_at[i][k])
        k = int(parents[i][k])
    return out

def round_trip(data, nibs):
    """The bytes as MAME plays them (a phrase from byte 0 to the last) decode to the encoder's own"""
    want = decode_nibbles(list(nibs) + ([0] if len(nibs) % 2 else []))
    got = decode_phrase(data, 0, len(data) - 1)
    if len(got) != len(want) or not np.array_equal(got, want):
        raise SystemExit("oki_adpcm: the packed bytes do not decode to the encoder's own decode")
    return got

def self_test():
    assert DIFF[0].tolist() == [2, 6, 10, 14, 18, 22, 26, 30, -2, -6, -10, -14, -18, -22, -26, -30], DIFF[0]
    assert math.floor(16 * 1.1 ** 48) == 1552 and DIFF[48, 7] == 1552 + 776 + 388 + 194 and (DIFF[48, 15] == -2910)
    assert step(2040, 48, 7) == (2047, 48) and step(-2040, 48, 15) == (-2048, 48) and (step(0, 0, 0) == (2, 0))
    rom = bytes([0, 113, 240, 7])
    assert phrase_nibbles(rom, 1, 2) == [7, 1, 15, 0]
    assert len(decode_phrase(rom, 0, 3)) == 8
    rng = np.random.default_rng(1)
    for n in (1, 2, 7, 64):
        nibs = rng.integers(0, 16, n).tolist()
        round_trip(pack(nibs), nibs)
    try:
        nibs = rng.integers(0, 16, 32).tolist()
        bad = bytearray(pack(nibs))
        bad[3] ^= 16
        round_trip(bytes(bad), nibs)
        raise AssertionError('a corrupted byte passed the round trip')
    except SystemExit:
        pass
    t = np.arange(600)
    x = 1500 * np.sign(np.sin(2 * np.pi * 741 / 7575.76 * t)) * np.exp(-t / 500) + rng.normal(0, 20, 600)
    g, tr = (encode_greedy(x), encode_trellis(x, 256))
    eg, et = (((x - decode_nibbles(g)) ** 2).sum(), ((x - decode_nibbles(tr)) ** 2).sum())
    assert et <= eg, (et, eg)
    assert encode_trellis(x, 256) == tr
    assert abs(volume_db(1) + 3.25) < 0.01 and VOLUME[9] == 0
    print('oki_adpcm self-test ok: greedy %.2f dB, trellis %.2f dB SNR' % (10 * np.log10((x ** 2).sum() / eg), 10 * np.log10((x ** 2).sum() / et)))
    return 0

def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('--self-test', action='store_true')
    a = p.parse_args()
    if a.self_test:
        return self_test()
    p.print_help()
    return 2
if __name__ == '__main__':
    sys.exit(main())
