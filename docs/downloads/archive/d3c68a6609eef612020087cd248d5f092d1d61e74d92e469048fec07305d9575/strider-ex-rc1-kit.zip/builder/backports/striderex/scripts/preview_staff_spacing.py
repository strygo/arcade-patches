"""Fast, guarded ending-spacing iteration from a build produced in this run."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import struct
import sys
import ending_ex as E

def sha(data):
    return hashlib.sha256(data).hexdigest()

def verify_full_build():
    p = argparse.ArgumentParser(description='Require exact ROM-member parity with an independent full rebuild.')
    p.add_argument('--preview', type=Path, required=True)
    p.add_argument('--full-build', type=Path, required=True)
    p.add_argument('--receipt', type=Path, required=True)
    a = p.parse_args(sys.argv[2:])
    if not (a.preview / 'spacing-preview.json').is_file() or (a.full_build / 'spacing-preview.json').exists():
        p.error('need a preview and an independently produced full build')
    identities = []
    for root in (a.preview, a.full_build):
        build = json.loads((root / 'build.json').read_text())
        members = {m: s['files'] for m, s in build['sets'].items()}
        for machine, files in members.items():
            for name, digest in files.items():
                if sha((root / machine / name).read_bytes()) != digest:
                    raise ValueError('Build member changed: ' + name)
        identities.append(members)
    if identities[0] != identities[1]:
        raise ValueError('Preview differs from the independent full rebuild')
    receipt = dict(passed=True, full_build_member_parity=True, build_files=identities[1], preview_recipe_sha256=sha((a.preview / 'spacing-preview.json').read_bytes()))
    with a.receipt.open('x') as f:
        f.write(json.dumps(receipt, indent=2) + '\n')
    print('PASS every preview ROM member matches the independent full rebuild')

def main():
    p = argparse.ArgumentParser(description=__doc__)
    for name in ('base', 'rom-dir', 'out'):
        p.add_argument('--' + name, type=Path, required=True)
    a = p.parse_args()
    bj = json.loads((a.base / 'build.json').read_text())
    manifest = json.loads(E.MANIFEST.read_text())
    programs = E.stock_programs(a.rom_dir)
    patched = {}
    receipt = dict(manifest_sha256=sha(E.MANIFEST.read_bytes()), regions={})
    for machine, spec in bj['sets'].items():
        for name, digest in spec['files'].items():
            if sha((a.base / machine / name).read_bytes()) != digest:
                raise ValueError('Base member changed: ' + name)
        stored = (a.base / machine / 'strex_p6.bin').read_bytes()
        bank = bytearray(len(stored))
        bank[0::2], bank[1::2] = (stored[1::2], stored[0::2])
        rows, plan = E.roll_table(manifest, E.stock_rows(programs[machine], machine), machine)
        blocks = [E.encode_block(rows[32 * k:32 * (k + 1)]) for k in range(E.NBLOCKS)]
        first = bytes(bank).find(blocks[0])
        if first < 0 or bytes(bank).count(blocks[0]) != 1:
            raise ValueError('First native ending block is not unique')
        pointer = struct.pack('>I', 1048576 + first)
        candidates = []
        at = 0
        while True:
            at = bytes(bank).find(pointer, at)
            if at < 0:
                break
            ptrs = struct.unpack_from('>9I', bank, at)
            if all((1048576 <= v < 2097152 for v in ptrs)):
                candidates.append(ptrs)
            at += 1
        if len(candidates) != 1:
            raise ValueError('Native ending block pointer table is not unique')
        spans = []
        for k, address in enumerate(candidates[0]):
            offset = address - 1048576
            old_rows, end = E.decode_block(bank, offset)
            before, after = (bytes(bank[offset:end]), blocks[k])
            if before == after:
                continue
            if [r for r in old_rows if r] != [r for r in rows[32 * k:32 * (k + 1)] if r]:
                raise ValueError('Preview would change text or its order, not just spacing')
            if len(before) != len(after):
                raise ValueError('Spacing requires relocation; use a full rebuild')
            bank[offset:end] = after
            spans.append(dict(block=k, start=address, bytes=len(after), before_sha256=sha(before), after_sha256=sha(after)))
        if not spans or any((span['block'] != 2 for span in spans)):
            raise ValueError('Preview must change only the arcade closing staff block')
        result = bytearray(len(bank))
        result[0::2], result[1::2] = (bank[1::2], bank[0::2])
        patched[machine] = result
        receipt['regions'][machine] = dict(before_sha256=sha(stored), after_sha256=sha(result), spans=spans, staff_spacing=plan['staff_spacing'])
    a.out.mkdir(parents=True, exist_ok=False)
    for path in a.base.glob('*.json'):
        shutil.copy2(path, a.out / path.name)
    if (a.base / 'work').is_dir():
        shutil.copytree(a.base / 'work', a.out / 'work', symlinks=True)
    for machine, result in patched.items():
        shutil.copytree(a.base / machine, a.out / machine)
        (a.out / machine / 'strex_p6.bin').write_bytes(result)
        bj['sets'][machine]['files']['strex_p6.bin'] = sha(result)
    (a.out / 'build.json').write_text(json.dumps(bj, indent=1) + '\n')
    (a.out / 'spacing-preview.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print('Preview written; independent full-build member parity is still required')
if __name__ == '__main__':
    verify_full_build() if sys.argv[1:2] == ['verify'] else main()
