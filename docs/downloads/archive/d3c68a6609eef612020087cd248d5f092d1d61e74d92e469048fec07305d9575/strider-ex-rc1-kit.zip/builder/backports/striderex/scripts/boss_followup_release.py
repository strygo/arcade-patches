"""Bind the boss/desert follow-up to its exact prior kit and focused checks."""
import argparse
import base64
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import struct
import sys
import zipfile
import zlib
STAGES = ('black', 'voice', 'grip', 'mouth', 'arcade')
REPORTS = ('boss_reveal_black', 'boss_english_routing', 'boss_native_voice_audit', 'boss_english_pack', 'boss_english_mouth', 'desert_first_girder', 'arcade_copyedit_postgame', 'postgame_held_start')
IDS = ('stp_strongman', 'stp_chairman', 'sib_solo', 'sib_sisters', 'aerial_captain', 'moon_solo', 'desert_officer', 'desert_commander')
HDR = struct.Struct('<4sHH16s64sHHIIIIQQQII')
MACHINES = {'striderua', 'striderjr'}

def sha(b):
    return hashlib.sha256(b).hexdigest()

def jsha(v):
    return sha(json.dumps(v, sort_keys=True, separators=(',', ':')).encode())

def hashes(files):
    return {m: {n: sha(b) for n, b in f.items()} for m, f in files.items()}

def delta(old, new):
    if len(old) != len(new):
        raise ValueError('ROM member size changed')
    changes = []
    lo = last = None
    for i, (x, y) in enumerate(zip(old, new)):
        if x == y:
            continue
        if last is not None and i - last > 32:
            changes.append((lo, last + 1))
            lo = None
        if lo is None:
            lo = i
        last = i
    if lo is not None:
        changes.append((lo, last + 1))
    return [dict(offset=lo, size=hi - lo, after_sha256=sha(new[lo:hi]), original_zlib=base64.b64encode(zlib.compress(old[lo:hi], 9)).decode()) for lo, hi in changes]

def reverse(data, rows):
    b = bytearray(data)
    end = 0
    for r in rows:
        at, n = (r['offset'], r['size'])
        if at < end or n <= 0 or at + n > len(b) or (sha(b[at:at + n]) != r['after_sha256']):
            raise ValueError('reverse span differs or overlaps')
        old = zlib.decompress(base64.b64decode(r['original_zlib']))
        if len(old) != n:
            raise ValueError('reverse payload size differs')
        b[at:at + n] = old
        end = at + n
    return bytes(b)

def restore(bundle, members):
    if bundle.get('schema') != 'striderex-boss-followup/1' or set(members) != MACHINES:
        raise ValueError('wrong boss follow-up contract')
    if hashes(members) != bundle['build_files']:
        raise ValueError('final boss follow-up ROMs differ')
    files = {m: dict(f) for m, f in members.items()}
    if [s['name'] for s in bundle['stages']] != list(STAGES):
        raise ValueError('missing follow-up stage')
    for s in reversed(bundle['stages']):
        if hashes(files) != s['after']:
            raise ValueError('follow-up stage output differs')
        if s['name'] == 'grip':
            shadow = {m: dict(f) for m, f in files.items()}
            for m, parts in bundle['stages'][1]['reverse'].items():
                for n, rows in parts.items():
                    shadow[m][n] = reverse(shadow[m][n], rows)
            if hashes(shadow) != bundle['reports']['boss_native_voice_audit']['input_files']['control']:
                raise ValueError('native voice audit control was not recovered')
        for m, f in files.items():
            for n, rows in s['reverse'].get(m, {}).items():
                f[n] = reverse(f[n], rows)
        if hashes(files) != s['before']:
            raise ValueError('follow-up inverse changed unrelated bytes')
    if hashes(files) != bundle['baseline_files']:
        raise ValueError('prior kit was not recovered exactly')
    return files

def pack_sections(data):
    if len(data) < 4096:
        raise ValueError('truncated pack')
    h = HDR.unpack_from(data)
    if h[0] != b'CP2A' or h[1] > 2 or h[2] != 4096 or (h[13] != len(data)):
        raise ValueError('invalid pack header')
    to, rows, io, count, do, size = h[7:13]
    if to != 4096 or io != to + rows * 4 or do != (io + count * 32 + 63) // 64 * 64 or (do + size != len(data)):
        raise ValueError('invalid pack sections')
    triggers = data[to:io]
    index = data[io:io + count * 32]
    audio = data[do:]
    if zlib.crc32(index, zlib.crc32(triggers)) != h[14] or zlib.crc32(audio) != h[15]:
        raise ValueError('pack CRC mismatch')
    return (h, triggers, index, audio)

def restore_pack(bundle, data):
    report = bundle['reports']['boss_english_pack']
    if sha(data) != report['pack_sha256']:
        raise ValueError('English pack identity differs')
    h, triggers, index, audio = pack_sections(data)
    original = bytes.fromhex(bundle['pack_original_header'])
    old = HDR.unpack_from(original)
    if h[:10] != old[:10] or h[10] != old[10] + 8 or data[140:4096] != original[140:4096]:
        raise ValueError('pack protocol or old index shape changed')
    rows = report['voices']
    if [r['id'] for r in rows] != list(IDS):
        raise ValueError('missing English pack voice')
    for i, r in enumerate(rows):
        at = (old[10] + i) * 32
        off, n, lss, lsb, les, leb, rate, cc, gain, c1, c2 = struct.unpack_from('<IIIIIIHBBhh', index, at)
        if (rate, cc, gain, lss, lsb, les, leb, c1, c2) != (48000, 18, 127, 0, 0, 0, 0, 0, 0):
            raise ValueError('English track is not a full-quality PCM one-shot')
        if n != r['samples'] * 4 or sha(audio[off:off + n]) != r['pcm_sha256']:
            raise ValueError('English voice PCM changed')
        track = old[10] + i
        want = bytes([1, track & 255, r['trigger_gain'], 1 | track >> 8 << 4])
        if triggers[(192 + i) * 4:(193 + i) * 4] != want:
            raise ValueError('English trigger/handshake differs')
    t = bytearray(triggers)
    t[192 * 4:200 * 4] = bytes.fromhex(bundle['pack_original_english_rows'])
    oldindex = index[:old[10] * 32]
    restored = original + bytes(t) + oldindex + b'\x00' * (old[11] - old[9] - len(oldindex)) + audio[:old[12]]
    pack_sections(restored)
    if sha(restored) != report['source_pack_sha256']:
        raise ValueError('original pack tracks/triggers were not recovered exactly')
    return restored

def validate(bundle, music, qualifications, rtl, expected, core_sha):
    if expected != bundle['build_files'] or core_sha != bundle['baseline_core_sha256']:
        raise ValueError('candidate/core differs')
    if jsha(music) != bundle['baseline_cinematic_sha256'] or jsha(qualifications) != bundle['baseline_qualification_sha256'] or jsha(rtl) != bundle['baseline_rtl_sha256'] or (music['proof']['build_files'] != bundle['baseline_files']):
        raise ValueError('inherited prior-kit checks changed')
    q = bundle['reports']
    st = bundle['stages']
    base = bundle['baseline_files']
    if set(q) != set(REPORTS) or any((not r.get('passed') for r in q.values())):
        raise ValueError('missing focused qualification')
    for name, before, after in (('boss_reveal_black', base, st[0]['after']), ('desert_first_girder', st[1]['after'], st[2]['after']), ('arcade_copyedit_postgame', st[3]['after'], expected), ('postgame_held_start', st[3]['after'], expected)):
        if q[name]['input_files'] != {'control': before, 'candidate': after}:
            raise ValueError('focused check input differs: ' + name)
    if q['boss_english_routing']['input_files'] != st[2]['after'] or q['boss_native_voice_audit']['input_files']['candidate'] != st[2]['after'] or q['boss_english_mouth']['input_files'] != st[3]['after']:
        raise ValueError('voice/mouth qualification describes different files')
    for name, count in (('boss_reveal_black', 2), ('boss_native_voice_audit', 2), ('desert_first_girder', 2), ('boss_english_routing', 36), ('boss_english_mouth', 20)):
        rows = q[name]['results']
        if len(rows) != count or any((not r.get('passed') for r in rows)):
            raise ValueError('incomplete focused results: ' + name)
    for r in q['desert_first_girder']['results']:
        if not r['natural_player_controls'] or r['player_and_camera_warps'] or (not r['old_defect_rejected']) or (r['grip_frames']['candidate'] < 250) or (r['grip_frames']['control'] != 0):
            raise ValueError('girder lacks a natural climb or negative control')
    for r in q['boss_reveal_black']['results']:
        if not all((r[k] for k in ('unchanged_frame_sync_and_sound_traces', 'only_two_palette_pens_differ', 'old_defect_rejected'))):
            raise ValueError('dialogue black comparison failed')
    for name in ('arcade_copyedit_postgame', 'postgame_held_start'):
        rows = [r for r in q[name]['postgame'] if r['label'] == 'candidate']
        if {(r['machine'], r['unranked']) for r in rows} != {(m, u) for m in MACHINES for u in (False, True)} or len(rows) != 4:
            raise ValueError('postgame region/ranking coverage is incomplete')
        for r in rows:
            if not r['passed'] or r['hold_frames'] != 480 or r['no_automatic_new_game_frames'] != 800 or (r['fresh_game'] != r['fresh_start'] + 1):
                raise ValueError('postgame hold or fresh Start failed')
            if name == 'postgame_held_start' and (r.get('held_start', {}).get('held_after_game_end_frames') != 241 or not r['held_start']['credit_added_before_hold']):
                raise ValueError('held Start coverage missing')
    text = q['arcade_copyedit_postgame']['text']
    if text['text'] != 'ALL SONS OF OLD GODS, DIE!' or not text['native_drawer_reads_and_vram_verified']:
        raise ValueError('unapproved native wording')
    if q['boss_english_routing']['pack_sha256'] != q['boss_english_pack']['pack_sha256'] or q['boss_english_pack']['source_pack_sha256'] != qualifications['combined']['inputs']['pack_sha256']:
        raise ValueError('pack qualification input differs')
    return True

def prepare(a):
    root = Path(__file__).resolve().parents[3]
    sys.path.insert(0, str(root / 'release'))
    import private_mister as PM
    import cinematic_followup as CF
    PM.verify(a.previous_kit)
    with PM.qualified_view(a.previous_kit) as view:
        producer = json.loads((view / 'producer.json').read_text())
        old = {}
        for m, names in producer['build_files'].items():
            region = 'us' if m == 'striderua' else 'jp'
            with zipfile.ZipFile(view / f'games/mame/striderex_{region}.zip') as z:
                old[m] = {n: z.read(n) for n in names}
        with zipfile.ZipFile(view / 'games/CPS+/strider_ex.zip') as z:
            pack = z.read('strider_ex.cpk')
        core = (view / producer['core']['file']).read_bytes()
    reports = {n: json.loads((a.reports / (n + '.json')).read_text()) for n in REPORTS}
    stages = []
    before = old
    for name, path in zip(STAGES, a.stage):
        meta = json.loads((path / 'build.json').read_text())
        after = {m: {n: (path / m / n).read_bytes() for n in s['files']} for m, s in meta['sets'].items()}
        if hashes(after) != {m: s['files'] for m, s in meta['sets'].items()}:
            raise ValueError('producer member changed')
        rev = {m: {n: delta(before[m][n], b) for n, b in f.items() if b != before[m][n]} for m, f in after.items()}
        stages.append(dict(name=name, before=hashes(before), after=hashes(after), reverse=rev))
        before = after
    bundle = dict(schema='striderex-boss-followup/1', passed=True, previous_test_id=PM.verify(a.previous_kit)['test_id'], baseline_files=producer['build_files'], build_files=hashes(before), baseline_core_sha256=sha(core), baseline_cinematic_sha256=jsha(producer['cinematic_music']), baseline_qualification_sha256=jsha(producer['qualification']), baseline_rtl_sha256=jsha(producer['rtl']), pack_original_header=pack[:4096].hex(), pack_original_english_rows=pack[4096 + 192 * 4:4096 + 200 * 4].hex(), stages=stages, reports=reports, build_sets=meta['sets'], hardware_review_granted=False)
    restored = restore(bundle, before)
    restore_pack(bundle, a.pack.read_bytes())
    validate(bundle, producer['cinematic_music'], producer['qualification'], producer['rtl'], hashes(before), sha(core))
    CF.verify(producer['cinematic_music']['proof'], restored)
    CF.validate_qualification(producer['cinematic_music'], producer['qualification'], producer['rtl'], hashes(old))
    a.out.mkdir(parents=True, exist_ok=False)
    for name, q in producer['qualification'].items():
        (a.out / ('qualification-' + name + '.json')).write_text(json.dumps(q, indent=2) + '\n')
    (a.out / 'rtl.json').write_text(json.dumps(producer['rtl'], indent=2) + '\n')
    for name, q in producer['cinematic_music'].items():
        (a.out / (name + '.json')).write_text(json.dumps(q, indent=2) + '\n')
    (a.out / 'core.rbf').write_bytes(core)
    (a.out / 'boss-followup.json').write_text(json.dumps(bundle, indent=2) + '\n')
    p = a.out / 'pack'
    p.mkdir()
    (p / 'strider_ex.cpk').write_bytes(a.pack.read_bytes())
    (p / 'strider_ex.build.json').write_text(json.dumps(dict(sha256=sha(a.pack.read_bytes()), english_voices=True)) + '\n')
    print('PASS: exact prior ROM/pack recovery; all focused checks bound; portable delivery inputs prepared')

def check(a):
    import cinematic_followup as CF
    b = json.loads(a.bundle.read_text())
    meta = json.loads((a.build / 'build.json').read_text())
    files = {m: {n: (a.build / m / n).read_bytes() for n in s['files']} for m, s in meta['sets'].items()}
    music = {n: json.loads((a.inputs / (n + '.json')).read_text()) for n in ('proof', 'runtime', 'census', 'loop', 'tip_runtime', 'tip_render')}
    qs = {n: json.loads((a.inputs / ('qualification-' + n + '.json')).read_text()) for n in ('fixes', 'audio', 'combined')}
    rtl = json.loads((a.inputs / 'rtl.json').read_text())
    core = sha((a.inputs / 'core.rbf').read_bytes())
    pack = a.pack.read_bytes()

    def verify(bundle, members, data=pack):
        restored = restore(bundle, members)
        restore_pack(bundle, data)
        validate(bundle, music, qs, rtl, hashes(members), core)
        CF.verify(music['proof'], restored)
        CF.validate_qualification(music, qs, rtl, bundle['baseline_files'])
    verify(b, files)
    negative = []
    for name in ('unrelated-code', 'voice-byte', 'missing-routing', 'missing-mouth', 'missing-girder', 'held-start-not-checked', 'wrong-copyedit', 'wrong-core', 'wrong-inherited-input', 'pack-pcm', 'missing-pack-voice'):
        bad = deepcopy(b)
        f = {m: dict(v) for m, v in files.items()}
        p = pack
        if name in ('unrelated-code', 'voice-byte'):
            member, at = ('strex_p6.bin', 2048) if name == 'unrelated-code' else ('18.11c', 38656)
            data = bytearray(f['striderua'][member])
            data[at] ^= 1
            f['striderua'][member] = bytes(data)
            bad['build_files'] = hashes(f)
            bad['stages'][-1]['after'] = hashes(f)
        if name == 'missing-routing':
            bad['reports']['boss_english_routing']['results'].pop()
        if name == 'missing-mouth':
            bad['reports']['boss_english_mouth']['results'].pop()
        if name == 'missing-girder':
            bad['reports']['desert_first_girder']['results'].pop()
        if name == 'held-start-not-checked':
            bad['reports']['postgame_held_start']['postgame'][0]['held_start']['held_after_game_end_frames'] = 0
        if name == 'wrong-copyedit':
            bad['reports']['arcade_copyedit_postgame']['text']['text'] = 'UNAPPROVED'
        if name == 'wrong-core':
            bad['baseline_core_sha256'] = '0' * 64
        if name == 'wrong-inherited-input':
            bad['baseline_cinematic_sha256'] = '0' * 64
        if name == 'pack-pcm':
            data = bytearray(p)
            data[-100] ^= 1
            p = bytes(data)
            bad['reports']['boss_english_pack']['pack_sha256'] = sha(p)
        if name == 'missing-pack-voice':
            bad['reports']['boss_english_pack']['voices'].pop()
        try:
            verify(bad, f, p)
        except ValueError:
            negative.append(dict(control=name, rejected=True))
        else:
            raise ValueError('damaged follow-up accepted: ' + name)
    report = dict(schema='striderex-boss-followup-acceptance/1', passed=True, previous_test_id=b['previous_test_id'], build_files=b['build_files'], proof_sha256=sha(a.bundle.read_bytes()), pack_sha256=sha(pack), exact_prior_rom_and_pack_reconstruction=True, focused_cases=dict(routing=36, mouth=20, girder=2, black_core=2, postgame=6, held_start=4), damaged_controls=negative, hardware_review_granted=False)
    a.receipt.write_text(json.dumps(report, indent=2) + '\n')
    print('PASS: final candidate and eleven damaged ROM/pack/qualification controls rejected')

def main():
    if sys.argv[1:] == ['--self-test']:
        a = bytes(range(256)) * 8
        b = bytearray(a)
        b[5] ^= 1
        b[100:200] = bytes(100)
        rows = delta(a, b)
        assert reverse(b, rows) == a
        b[100] ^= 1
        try:
            reverse(b, rows)
        except ValueError:
            pass
        else:
            raise AssertionError('changed new bytes accepted')
        print('Boss follow-up release self-test PASS: exact inverse and changed-byte rejection')
        return
    if sys.argv[1:2] == ['check']:
        p = argparse.ArgumentParser(description='Check the final follow-up and reject damaged controls')
        for n in ('bundle', 'build', 'inputs', 'pack', 'receipt'):
            p.add_argument('--' + n, type=Path, required=True)
        check(p.parse_args(sys.argv[2:]))
        return
    p = argparse.ArgumentParser(description=__doc__)
    for n in ('previous-kit', 'reports', 'pack', 'out'):
        p.add_argument('--' + n, type=Path, required=True)
    p.add_argument('--stage', type=Path, action='append', required=True, help='black, voice, grip, mouth, arcade builds, in order')
    a = p.parse_args()
    if len(a.stage) != 5:
        p.error('five stages required')
    prepare(a)
if __name__ == '__main__':
    main()
