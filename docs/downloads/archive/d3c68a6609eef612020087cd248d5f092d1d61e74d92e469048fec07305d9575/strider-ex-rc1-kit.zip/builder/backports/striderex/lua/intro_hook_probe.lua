-- Strider EX intro-hook probe (Phase 2 integration). Loaded with
-- lua/arcade_debug_start.lua. Watches the stage-intro first-entry flag
-- 0xFF0CBA (-$7346(a5), set at 0x911A just before the intro setup 0x552C):
-- the frame a cinematic would play. With STREX_POISON = "lo-hi,..." (hex,
-- word-aligned) every range is filled with 0x5AA5 at that moment, the way a
-- cinematic would leave memory. Writes INTRO_LOG lines "frame pc value" for
-- every write to the flag, VIDEO_LOG per frame: the CPS-A/B registers as last
-- written (as respawn_fix.py), and screenshots every SHOT_EVERY frames from
-- the first hook (screen:snapshot to SHOTDIR).
local m=manager.machine
local cpu=m.devices[':maincpu']
local sp=cpu.spaces['program']
local screen=m.screens[':screen']
local poison={}
for lo,hi in string.gmatch(os.getenv('STREX_POISON') or '','(%x+)%-(%x+)') do poison[#poison+1]={tonumber(lo,16),tonumber(hi,16)} end
local every=tonumber(os.getenv('SHOT_EVERY') or '8')
local il=assert(io.open(os.getenv('INTRO_LOG'),'w'))
local vl=assert(io.open(os.getenv('VIDEO_LOG'),'w'))
local f, hooked, prev = 0, nil, 0
local hook_pc=tonumber(os.getenv('STREX_HOOK_PC') or '911a',16)   -- the flag store (boot RAM tests also write it)
local cur={}
local function fill()
 for _,r in ipairs(poison) do for a=r[1],r[2],2 do sp:write_u16(a,0x5aa5) end end
end
_G.strex_intro_taps={
 sp:install_write_tap(0xff0cba,0xff0cbb,'strex_intro',function(off,data,mask)
  local v=(off==0xff0cba) and (data>>8)&0xff or data&0xff
  if mask==0x00ff and off==0xff0cba then v=data&0xff end
  local pc=cpu.state['CURPC'].value
  il:write(string.format('%d %06x %02x\n',f+1,pc,v))
  if v~=0 and pc==hook_pc then
   if not hooked then hooked=f+1 end
   if #poison>0 then fill() end
  end
  prev=v
 end),
 sp:install_write_tap(0x800100,0x800171,'strex_vregs',function(off,data,mask) cur[off]=data end)}
emu.register_frame_done(function()
 f=f+1
 local t={}
 for a=0x800100,0x800122,2 do t[#t+1]=string.format('%04x',cur[a] or 0) end
 for a=0x800166,0x800170,2 do t[#t+1]=string.format('%04x',cur[a] or 0) end
 vl:write(f..'\t'..table.concat(t,' ')..'\n')
 if hooked and f>=hooked and (f-hooked)%every==0 then
  screen:snapshot(string.format('%s/s_%05d.png',os.getenv('SHOTDIR'),f))
 end
 if f%60==0 then il:flush() vl:flush() end
end)
dofile(os.getenv('STREX_DEBUG_START'))
