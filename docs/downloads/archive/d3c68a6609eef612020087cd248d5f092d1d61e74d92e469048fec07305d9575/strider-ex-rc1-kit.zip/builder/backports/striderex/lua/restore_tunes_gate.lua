-- Strider tune restoration gate: render music commands headlessly and log
-- every YM2151 register write.  Driven by scripts/restore_tunes.py.
--
-- Env:
--   RT_MODE    'arcade' (striderua/striderjr) or 'x68k' (x68000 + Strider disks)
--   RT_LOG     output TSV: "time<TAB>cmd<TAB>hex" markers and
--              "time<TAB>ym<TAB>reg<TAB>data" for every YM2151 data write
--   RT_CMDS    comma-separated hex commands, rendered one per slot
--   RT_SLOT    slot length in emulated seconds (stop command 1 s before the end)
--   RT_TAP     (arcade, optional) "lo-hi" hex Z80 range: log every read in it
--              as "time<TAB>read<TAB>addr" (unused-space proof)
--   RT_LIVE    (arcade, optional) if set, do not freeze the 68K: the game runs
--              its own attract for RT_LIVE seconds before the command slots
--   RT_DISKS   (x68k) "system|diskA|diskB" .dim paths
--
-- Arcade: the 68K is parked in a bra-self loop at 1000 frames (IRQs masked)
-- so only the injected latch bytes (0x800180) reach the Z80.  X68000: the
-- RP5C15 is pinned, the disks are swapped as the loader expects (eject at
-- frame 1300, insert Disk A / Disk B at 1400), the main loop is parked at
-- frame 2990 (bra-self at 0x28D000, IRQs on), and the song number is written
-- to the driver mailbox 0x8F856 (a write tap keeps the game from changing it).
-- Every tap handle is kept in a global table: Lua GC would otherwise remove it.
local m = manager.machine
local mode = assert(os.getenv('RT_MODE'))
local log = assert(io.open(assert(os.getenv('RT_LOG')), 'w'))
local slot = tonumber(os.getenv('RT_SLOT') or '60')
local cmds = {}
for h in string.gmatch(os.getenv('RT_CMDS') or '', '[^,]+') do cmds[#cmds + 1] = tonumber(h, 16) end
local maincpu = m.devices[':maincpu']
local sp = maincpu.spaces['program']
_G.rt_taps = {}
local function now() return m.time:as_double() end
local function mark(kind, v) log:write(string.format('%.6f\t%s\t%02x\n', now(), kind, v)); log:flush() end

local send, park_frame, stop
if mode == 'arcade' then
  local z = m.devices[':audiocpu'].spaces['program']
  local reg = 0
  _G.rt_taps[1] = z:install_write_tap(0xf000, 0xf001, 'rt_ym', function(a, d, mask)
    if a == 0xf000 then reg = d & 0xff
    else log:write(string.format('%.6f\tym\t%02x\t%02x\n', now(), reg, d & 0xff)) end
  end)
  local tap = os.getenv('RT_TAP')
  if tap then
    local lo, hi = tap:match('(%x+)-(%x+)')
    _G.rt_taps[2] = z:install_read_tap(tonumber(lo, 16), tonumber(hi, 16), 'rt_free', function(a, d, mask)
      log:write(string.format('%.6f\tread\t%04x\n', now(), a)); return d
    end)
  end
  send = function(c) mark('cmd', c); sp:write_u16(0x800180, c * 0x101) end
  stop = 0xf0
  park_frame = os.getenv('RT_LIVE') and -1 or 1000
elseif mode == 'x68k' then
  do
    local function rtc(r, v) sp:write_u8(0xe8a001 + r * 2, v) end
    rtc(0xd, 0)
    for r, v in pairs({[0] = 0, 0, 0, 0, 0, 0, 6, 1, 0, 1, 0, 4, 1}) do rtc(r, v) end
    rtc(0xd, 8)
  end
  local reg = 0
  _G.rt_taps[1] = sp:install_write_tap(0xe90000, 0xe90003, 'rt_opm', function(a, d, mask)
    local v = d & 0xff
    if (a & 2) == 0 then reg = v
    else log:write(string.format('%.6f\tym\t%02x\t%02x\n', now(), reg, v)) end
  end)
  local MB = 0x8f856
  local want = nil
  _G.rt_taps[2] = sp:install_write_tap(MB & ~1, MB | 1, 'rt_mbox', function(a, d, mask)
    if want and (mask & 0xff00) ~= 0 then return (d & 0x00ff) | (want << 8) end
  end)
  send = function(c) mark('cmd', c); want = c; sp:write_u8(MB, c) end
  stop = 0xf0
  park_frame = 2990
  local disks = {}
  for p in string.gmatch(assert(os.getenv('RT_DISKS')), '[^|]+') do disks[#disks + 1] = p end
  local drives = {}
  for tag, img in pairs(m.images) do
    local u = tag:match(':upd72065:(%d+):')
    if u then drives[tonumber(u)] = img end
  end
  _G.rt_swap = function(frame)
    if frame == 1300 then drives[0]:unload(); drives[1]:unload() end
    if frame == 1400 then drives[0]:load(disks[2]); drives[1]:load(disks[3]) end
  end
else
  error('RT_MODE must be arcade or x68k')
end

local frame = 0
local t0 = nil
local live = tonumber(os.getenv('RT_LIVE') or '0')
emu.register_frame_done(function()
  frame = frame + 1
  if _G.rt_swap then _G.rt_swap(frame) end
  if frame == park_frame then
    if mode == 'arcade' then
      sp:write_u16(0xff0000, 0x60fe); maincpu.state['SR'].value = 0x2700; maincpu.state['PC'].value = 0xff0000
      send(0xf0)
    else
      sp:write_u16(0x28d000, 0x60fe); maincpu.state['SR'].value = 0x2000; maincpu.state['PC'].value = 0x28d000
    end
    t0 = now() + 1.0
  end
  if park_frame < 0 and t0 == nil and now() >= live then t0 = now() end
  if t0 == nil or now() < t0 then return end
  local k = math.floor((now() - t0) / slot)
  local r = (now() - t0) - k * slot
  _G.rt_state = _G.rt_state or {}
  if k < #cmds then
    if _G.rt_state.sent ~= k then _G.rt_state.sent = k; send(cmds[k + 1]) end
    if r >= slot - 1.0 and _G.rt_state.stopped ~= k then _G.rt_state.stopped = k; send(stop) end
  else
    log:write('done\n'); log:close(); m:exit()
  end
  if frame % 600 == 0 then assert(#_G.rt_taps >= 1) end
end)
