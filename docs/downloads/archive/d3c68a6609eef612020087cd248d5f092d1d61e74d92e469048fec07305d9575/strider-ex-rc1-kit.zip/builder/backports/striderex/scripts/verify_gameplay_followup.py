"""Bind focused checks to a fresh replay and reject internally rehashed damage."""
import argparse
import json
from pathlib import Path
import shutil
import sys
import tempfile
import bootstrap_vasm as V
import build_gameplay_followup as BUILD
from boss_voice_gate import inventory, sha
import stage_clear as CLEAR
import desert_motion_fix as CAMERA
import desert_transition_fix as TRANSITION
import desert_pole_floor as POLE
import desert_climb_fix as CLIMB

def verify(a):
    root, fresh = (a.build_root.resolve(), a.fresh_root.resolve())
    builds = {}
    for name in ('base',) + tuple((name for name, _ in BUILD.STAGES)):
        before, _ = inventory(root / name)
        after, _ = inventory(fresh / name)
        if before != after:
            raise ValueError(name + ': fresh ROMs or metadata differ')
        builds[name] = {m: s['files'] for m, s in before['sets'].items()}
    receipt = json.loads(a.gate.read_text())
    if not receipt['passed'] or len(receipt['results']) != 54 or (not all((r['passed'] for r in receipt['results']))):
        raise ValueError('need all 54 focused regional movement/clear/no-pack checks')
    if receipt['inputs'] != {'control': builds['base'], 'candidate': builds['final']}:
        raise ValueError('focused gate did not run these exact final ROMs')
    project = Path(__file__).resolve().parents[1]
    for name, digest in receipt['source_sha256'].items():
        path = project / ('scripts' if name.endswith('.py') else 'lua') / name
        if sha(path.read_bytes()) != digest:
            raise ValueError('focused gate source changed: ' + name)
    tc = json.loads(a.toolchain_receipt.read_text())
    if tc['source_commit'] != V.COMMIT or sha(a.vasm.read_bytes()) != tc['executable_sha256']:
        raise ValueError('assembler identity differs from the pinned bootstrap receipt')
    checks = (('stage_clear', 'base', CLEAR.audit, 'stage_clear', CLEAR.BASE), ('camera', 'stage_clear', CAMERA.audit, 'desert_motion', CAMERA.INIT), ('transition', 'camera', TRANSITION.audit, 'desert_transition', TRANSITION.ENTRY + 24), ('pole_floor', 'transition', lambda x, y: POLE.audit(x, y, a.rom_dir.resolve()), 'pole_floor', POLE.BASE + 256), ('final', 'pole_floor', CLIMB.audit, 'desert_climb', CLIMB.ENTRY + 12))
    controls = []
    for child, parent, audit, field, address in checks:
        audit(root / parent, root / child)
        for machine in ('striderua', 'striderjr'):
            with tempfile.TemporaryDirectory(prefix='damage-', dir=root) as temp:
                damaged = Path(temp) / 'build'
                shutil.copytree(root / child, damaged)
                meta, files = inventory(damaged)
                p = damaged / machine / 'strex_p6.bin'
                data = bytearray(p.read_bytes())
                offset = address - 1048576 ^ 1
                data[offset] ^= 1
                p.write_bytes(data)
                meta['sets'][machine]['files']['strex_p6.bin'] = sha(data)
                (damaged / 'build.json').write_text(json.dumps(meta, indent=2) + '\n')
                try:
                    audit(root / parent, damaged)
                except ValueError:
                    pass
                else:
                    raise ValueError('rehashed damage accepted: ' + child + ' ' + machine)
                controls.append(dict(producer=child, machine=machine, changed_address=address, rejected=True))
    sources = ['scripts/' + name for _, name in BUILD.STAGES] + ['scripts/build_gameplay_followup.py', 'scripts/gameplay_followup_gate.py', 'scripts/verify_gameplay_followup.py', 'scripts/preview_gameplay_followup.py', 'scripts/desert_grip_fix.py', 'scripts/bootstrap_vasm.py', 'scripts/stage_clear_study.py', 'scripts/third_moon_study.py', 'lua/desert_gate.lua', 'lua/stage_clear_study.lua', 'lua/third_moon_study.lua', 'asm/stage_clear.s', 'asm/desert_motion.s', 'asm/desert_transition.s', 'asm/desert_climb.s']
    result = dict(schema='striderex-gameplay-followup-fresh/1', passed=True, baseline_export_manifest_sha256=BUILD.BASELINE_SHA, fresh_empty_output_reproduces_all_roms_and_metadata=True, builds=builds, focused_gate_sha256=sha(a.gate.read_bytes()), focused_checks=len(receipt['results']), assembler={k: tc[k] for k in ('source_url', 'source_commit', 'executable_sha256')}, source_sha256={n: sha((project / n).read_bytes()) for n in sources}, rehashed_damage_controls=controls, hardware_review_granted=False)
    a.receipt.write_text(json.dumps(result, indent=2) + '\n')
    print('PASS: every ROM and metadata field reproduced from empty output; all 54 checks bound; ten rehashed damage controls rejected')

def main():
    p = argparse.ArgumentParser(description=__doc__)
    for n in ('build-root', 'fresh-root', 'gate', 'rom-dir', 'vasm', 'toolchain-receipt', 'receipt'):
        p.add_argument('--' + n, type=Path, required=True)
    verify(p.parse_args())
if __name__ == '__main__':
    main()
