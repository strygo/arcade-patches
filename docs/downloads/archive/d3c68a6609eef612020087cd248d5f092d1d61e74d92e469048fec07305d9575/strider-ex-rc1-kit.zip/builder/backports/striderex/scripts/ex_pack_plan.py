"""Strider EX pack plan: the trigger table the EX pack will carry, and what"""
import argparse
import json
import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[3]
CUES = ROOT / 'backports/striderex/manifests/ex_pack_cues.json'

def load(rel):
    return json.loads((ROOT / rel).read_text())

def plan():
    amap = load('cpsplus/manifests/strider_review_map.json')
    dec = load('cpsplus/manifests/strider_listening_decisions.json')
    inv = load('cpsplus/manifests/strider_source_inventory.json')
    cues = json.loads(CUES.read_text())
    good = {d['id'] for d in dec['decisions'] if d['verdict'] == 'good'}
    disc = {r['track'] for r in inv['pce']}
    emitted = set()
    for lo, hi in cues['stock_emitted']['ranges']:
        emitted |= set(range(int(lo, 16), int(hi, 16) + 1))
    rows, errors = ([], [])
    intro = {o['cue']: o['pce_track'] for o in cues['ex_overrides']['rows']}
    cinematic_tracks = {c['pce_track'] for c in cues['cinematics']['rows']}
    for r in amap['rows']:
        p = r['pce']
        if r['kind'] != 'music' or p['disposition'] not in ('candidate', 'one_shot_candidate'):
            continue
        track, verb, note = (p['disc_track'], p['playback'], r['role'])
        if r['command'] in intro:
            track, verb, note = (intro[r['command']], 'loop', note + f" (EX override; research map: track {p['disc_track']})")
        if verb == 'loop':
            status = 'ready' if f'pce_{track:02}' in good else 'loop join pending'
        else:
            status = 'ready'
        rows.append(dict(kind='music', cue=r['command'], track=track, verb=verb, suppress=True, status=status, note=note))
    music = {r['cue']: r for r in rows}
    for c in cues['cinematics']['rows']:
        m = music.get(c['ja'])
        if m and m['track'] == c['pce_track']:
            m['note'] += f" = {c['id']} (Japanese voices)"
        else:
            rows.append(dict(kind='cinematic', cue=c['ja'], track=c['pce_track'], verb='one_shot', suppress=True, status='ready', note=f"{c['id']} (Japanese voices)"))
        rows.append(dict(kind='cinematic', cue=c['en'], track=None, verb='one_shot', suppress=True, status='dub pending (Phase 4)', note=f"{c['id']} (English dub of track {c['pce_track']})"))
    for n in cues['native_stops']['rows']:
        rows.append(dict(kind='native', cue=n['cue'], track=None, verb='stop', suppress=False, status='ready', note=n['role']))
    for d in cues['desert']['rows']:
        rows.append(dict(kind='desert', cue=d['cue'], track=d['pce_track'], verb='loop', suppress=True, status='loop points pending', note=f"{d['id']} (no pack: tune {d['fallback_tune']})"))
    bv = cues.get('boss_voices', {'rows': [], 'english_reserved': []})
    for b in bv['rows']:
        rows.append(dict(kind='boss_voice', cue=b['cue'], track=None, verb='one_shot', suppress=True, status='ready', note=f"{b['id']} (boss scene voice, Japanese)"))
    scenes = load('backports/striderex/manifests/boss_scenes.json')['voice_cues']['rows']
    if bv['rows'] and [(b['id'], int(b['cue'], 16)) for b in bv['rows']] != [(r['id'], int(r['ja'], 16)) for r in scenes]:
        errors.append('ex_pack_cues.json boss_voices is not boss_scenes.json voice_cues (id, ja) in order')
    english = {int(r['en'], 16) for r in scenes}
    if bv['english_reserved']:
        lo, hi = (int(c, 16) for c in bv['english_reserved'])
        if english != set(range(lo, hi + 1)):
            errors.append(f"boss_voices english_reserved {bv['english_reserved']} is not boss_scenes.json's English cues")
    sys.path.insert(0, str(ROOT))
    from cpsplus.pack.protocols import PROTOCOLS
    ctrl = int(cues['cps_plus_control_region']['start'], 16)
    if ctrl != PROTOCOLS['strider'].control_region_start:
        errors.append(f"cps_plus_control_region {ctrl:#04x} is not the strider protocol's {PROTOCOLS['strider'].control_region_start:#04x}")
    seen = {}
    for r in rows:
        v = int(r['cue'], 16)
        if r['cue'] in seen:
            errors.append(f"cue {r['cue']} maps twice ({seen[r['cue']]}, {r['note']})")
        seen[r['cue']] = r['note']
        if r['kind'] in ('cinematic', 'desert', 'boss_voice') and v in emitted and (r['cue'] != '0x21'):
            errors.append(f"new cue {r['cue']} ({r['note']}) is sent by the stock game")
        if v >= min(ctrl, PROTOCOLS['strider'].control_region_start):
            errors.append(f"cue {r['cue']} ({r['note']}) lies in the CPS+ control region: the core never plays its row")
        if r['track'] is not None and r['track'] not in disc:
            errors.append(f"track {r['track']} is not on the disc")
    used = {int(c, 16) for c in seen}
    fade = int(cues['skip_fade']['cue'], 16)
    if fade < ctrl or fade in emitted or fade in used or (fade in PROTOCOLS['strider'].control_verbs) or (fade == 255):
        errors.append(f'skip_fade cue {fade:#04x} is not a free control byte')
    for v in sorted(english):
        if v in emitted or v in used or v >= ctrl:
            errors.append(f'boss voice English cue {v:#04x} is not free (stock {v in emitted}, a cue {v in used}, control region {v >= ctrl})')
    for c in cues['spare']:
        v = int(c, 16)
        if v in emitted or v in used or v >= ctrl:
            errors.append(f'spare {c} is not free (stock {v in emitted}, a cue {v in used}, control region {v >= ctrl})')
    sfx = load('backports/striderex/manifests/pce_sfx.json')['effects']
    native = [(r['cue'], r['id'], r['pce_psg']) for r in cues.get('native_sfx', {}).get('rows', [])]
    if [(int(c, 16), i, int(p, 16)) for c, i, p in native] != [(int(e['command'], 16), e['id'], int(e['pce_psg'], 16)) for e in sfx]:
        errors.append("ex_pack_cues.json native_sfx is not pce_sfx.json's effects (cue, id, PSG) in order")
    spare = {int(c, 16) for c in cues['spare']}
    for c, i, _ in native:
        v = int(c, 16)
        if v in emitted or v in used or v in spare or (v in english) or (v >= ctrl):
            errors.append(f'native effect {c} ({i}) is not a free native command (stock {v in emitted}, a row {v in used}, spare {v in spare}, control region {v >= ctrl})')
    return (rows, errors)

def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('--tsv', type=Path, help='write the cue sheet here')
    a = p.parse_args()
    rows, errors = plan()
    if a.tsv:
        lines = ['cue\tkind\tpce_track\tverb\tsuppress\tstatus\tnote']
        lines += [f"{r['cue']}\t{r['kind']}\t{r['track'] or ''}\t{r['verb']}\t{int(r['suppress'])}\t{r['status']}\t{r['note']}" for r in sorted(rows, key=lambda r: int(r['cue'], 16))]
        a.tsv.write_text('\n'.join(lines) + '\n')
    by = {}
    for r in rows:
        by.setdefault((r['kind'], r['status']), []).append(r['cue'])
    for (kind, status), cues in sorted(by.items()):
        print(f"{kind:9} {status:22} {len(cues):3}  {' '.join(cues)}")
    for e in errors:
        print('ERROR', e)
    return 1 if errors else 0
if __name__ == '__main__':
    sys.exit(main())
