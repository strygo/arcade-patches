"""Match English boss mouth movement to the actual native and CPS+ audio."""
import argparse
from copy import deepcopy
import hashlib
import json
import math
from pathlib import Path
import struct
import subprocess
from asm_payload import command as assembly_command
import sys
import numpy as np
import boss_scene_binary as BB
from boss_voice_gate import inventory
import boss_voice_assets as A
import oki_adpcm as O
import pce_sfx as PS
ENTRY = 2094336
DATA = 1802240
HZ = 59.637
STEP = 6
THRESHOLD = 10 ** (-40 / 20)
ORIGINAL = bytes.fromhex('48e7e4803a2a002e907c00136b14206a00303218670c3418b0416504904160f23a0233c500fff9d84cdf01274e75')

def sha(b):
    return hashlib.sha256(b).hexdigest()

def envelope(x, rate, rest, opens):
    frames = math.ceil(len(x) / rate * HZ)
    seq = []
    for f in range(0, frames, STEP):
        chunk = x[round(f / HZ * rate):round(min(frames, f + STEP) / HZ * rate)]
        active = len(chunk) and float(np.sqrt(np.mean(chunk ** 2))) >= THRESHOLD
        code = opens[f // STEP % len(opens)] if active and opens else rest
        n = min(STEP, frames - f)
        if seq and seq[-1][1] == code:
            seq[-1][0] += n
        else:
            seq.append([n, code])
    return seq

def sequence(bank, p):
    rows = []
    while BB.word(bank, p):
        if len(rows) >= 1024:
            raise ValueError('unbounded mouth sequence')
        rows.append([BB.word(bank, p), BB.word(bank, p + 2)])
        p += 4
    return rows

def produce(a):
    meta, files = inventory(a.build)
    rep = deepcopy(meta)
    assets = json.loads((a.voices / 'voices.json').read_text())
    if [r['id'] for r in assets['voices']] != list(BB.IDS):
        raise ValueError('voice inventory changed')
    audio = {'native': [], 'pack': []}
    for r in assets['voices']:
        raw = (a.voices / r['native_file']).read_bytes()
        master = (a.voices / r['master_file']).read_bytes()
        if sha(raw) != r['native_sha256'] or sha(master) != r['master_sha256']:
            raise ValueError('voice audio changed')
        audio['native'].append((O.decode_phrase(raw, 0, len(raw) - 1).astype(float) / 2048, PS.OKI_RATE))
        audio['pack'].append((A.read_wav(master), 48000))
    a.out.mkdir(parents=True, exist_ok=False)
    for m, f in files.items():
        p6 = f['strex_p6.bin']
        bank = bytearray((p6[i ^ 1] for i in range(len(p6))))
        scenes = BB.scenes(bank)
        hits = [k for k in range(0, len(bank) - len(ORIGINAL), 2) if bank[k:k + len(ORIGINAL)] == ORIGINAL]
        if len(hits) != 1:
            raise ValueError('original bs_picture does not match')
        body = bytearray(64)
        rows = []
        for mode in ('native', 'pack'):
            for i, scene in enumerate(scenes):
                rest = BB.word(bank, scene['at'] + 46)
                old = sequence(bank, BB.long(bank, scene['at'] + 48) - BB.BASE)
                opens = sorted({code for n, code in old} - {rest})
                seq = envelope(*audio[mode][i], rest, opens)
                ptr = DATA + len(body)
                struct.pack_into('>I', body, (int(mode == 'pack') * 8 + i) * 4, ptr)
                for n, code in seq:
                    body.extend(struct.pack('>HH', n, code))
                body.extend(b'\x00\x00')
                rows.append(dict(id=scene['id'], mode=mode, frames=sum((n for n, c in seq)), rest=rest, opens=opens, sequence=seq, pointer=ptr))
        code = a.out / (m + '-mouth.bin')
        subprocess.run([*assembly_command(a.vasm), '-Fbin', '-m68000', '-quiet', '-o', str(code), str(Path(__file__).resolve().parents[1] / 'asm/boss_mouth.s')], check=True)
        helper = code.read_bytes()
        off = ENTRY - BB.BASE
        data_at = DATA - BB.BASE
        if len(helper) > 256 or bank[off:off + len(helper)] != b'\xff' * len(helper):
            raise ValueError('mouth helper allocation occupied')
        if bank[data_at:data_at + len(body)] != b'\xff' * len(body):
            raise ValueError('mouth data allocation occupied')
        bank[off:off + len(helper)] = helper
        bank[data_at:data_at + len(body)] = body
        at = hits[0]
        bank[at:at + 6] = b'N\xf9' + ENTRY.to_bytes(4, 'big')
        f = dict(f, **{'strex_p6.bin': bytes((bank[i ^ 1] for i in range(len(bank))))})
        target = a.out / m
        target.mkdir()
        for n, b in f.items():
            (target / n).write_bytes(b)
        rep['sets'][m]['files'] = {n: sha(b) for n, b in f.items()}
        rep['sets'][m]['boss_mouth'] = dict(original_at=BB.BASE + at, original_prefix=ORIGINAL[:6].hex(), helper_at=ENTRY, helper_bytes=len(helper), helper_sha256=sha(helper), data_at=DATA, data_bytes=len(body), data_sha256=sha(body), block_frames=STEP, rms_threshold_dbfs=-40, rows=rows, source_files=meta['sets'][m]['files'])
        print(m, 'English mouth envelopes:', len(body), 'data bytes; original Japanese sequence preserved', flush=True)
    (a.out / 'build.json').write_text(json.dumps(rep, indent=2) + '\n')

def audit(control, build):
    cm, old = inventory(control)
    meta, new = inventory(build)
    for m, s in meta['sets'].items():
        spec = s['boss_mouth']
        bank = bytearray((new[m]['strex_p6.bin'][i ^ 1] for i in range(1048576)))
        if spec['source_files'] != cm['sets'][m]['files']:
            raise ValueError('mouth source inventory mismatch')
        for name in old[m]:
            if name != 'strex_p6.bin' and old[m][name] != new[m][name]:
                raise ValueError('mouth patch changes another ROM')
        at = spec['original_at'] - BB.BASE
        if bank[at:at + 6] != b'N\xf9' + ENTRY.to_bytes(4, 'big'):
            raise ValueError('mouth trampoline changed')
        bank[at:at + 6] = bytes.fromhex(spec['original_prefix'])
        for label in ('helper', 'data'):
            start = spec[label + '_at'] - BB.BASE
            n = spec[label + '_bytes']
            if sha(bank[start:start + n]) != spec[label + '_sha256']:
                raise ValueError('mouth allocation changed')
            bank[start:start + n] = b'\xff' * n
        if bytes((bank[i ^ 1] for i in range(len(bank)))) != old[m]['strex_p6.bin']:
            raise ValueError('mouth inverse does not match')
    return meta

def main():
    if sys.argv[1:] == ['--self-test']:
        rate = 48000
        x = np.r_[np.ones(rate // 2) * 0.1, np.zeros(rate // 2)]
        seq = envelope(x, rate, 10, [20, 30])
        assert sum((n for n, c in seq)) == math.ceil(HZ) and seq[-1][1] == 10 and ({20, 30} <= {c for n, c in seq})
        assert all((c == 10 for n, c in envelope(x, rate, 10, [])))
        assert all((c == 10 for n, c in envelope(np.zeros(rate), rate, 10, [20, 30])))
        print('Mouth envelope self-test PASS: speech, quiet tail, masked Solo, exact duration')
        return
    p = argparse.ArgumentParser(description=__doc__)
    for n in ('build', 'voices', 'vasm', 'out'):
        p.add_argument('--' + n, type=Path, required=True)
    produce(p.parse_args())
if __name__ == '__main__':
    main()
