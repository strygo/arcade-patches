"""Pair actual gate screenshots with nearest-neighbour enlargement for review."""
import argparse
from pathlib import Path
from PIL import Image, ImageDraw

def main():
    p = argparse.ArgumentParser(description=__doc__)
    for name in ('pixel-run', 'wall-run', 'out'):
        p.add_argument('--' + name, type=Path, required=True)
    a = p.parse_args()
    rows = [('Pose-linked black dash', a.pixel_run, '', 1200, (204, 56, 268, 152), 4), ('Left edge while climbing down', a.wall_run, '_8', 1150, (0, 40, 128, 184), 3)]
    height = sum((60 + (box[3] - box[1]) * scale for _, _, _, _, box, scale in rows))
    sheet = Image.new('RGB', (800, height), '#202020')
    draw = ImageDraw.Draw(sheet)
    y = 0
    for title, root, suffix, frame, box, scale in rows:
        draw.text((12, y + 7), title, fill='white')
        y += 28
        for col, label in enumerate(('control', 'candidate')):
            draw.text((12 + 400 * col, y), 'Before' if col == 0 else 'After', fill='white')
            im = Image.open(root / f'{label}_striderua{suffix}' / f's_{frame:05d}.png').convert('RGB').crop(box)
            im = im.resize((im.width * scale, im.height * scale), Image.Resampling.NEAREST)
            sheet.paste(im, (12 + 400 * col, y + 20))
        y += im.height + 32
    a.out.parent.mkdir(parents=True, exist_ok=True)
    sheet.crop((0, 0, 800, y)).save(a.out)
if __name__ == '__main__':
    main()
