"""Capture bounded before/after views of the actual native follow-up ROMs."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import csv
import json
from pathlib import Path
import subprocess
import sys
from PIL import Image, ImageDraw
import desert_gate as G
from boss_voice_gate import inventory, sha

def panel(left, right, caption=''):
    im = Image.new('RGB', (768, 244))
    draw = ImageDraw.Draw(im)
    for i, (p, label) in enumerate(((left, 'Kit aa'), (right, 'Native follow-up'))):
        im.paste(Image.open(p).convert('RGB'), (i * 384, 20))
        draw.text((i * 384 + 4, 4), label + ' ' + caption, fill='white')
    return im

def main():
    p = argparse.ArgumentParser(description=__doc__)
    for n in ('build-root', 'runtime', 'hbmame', 'rom-dir', 'workdir', 'out'):
        p.add_argument('--' + n, type=Path, required=True)
    a = p.parse_args()
    root = a.build_root.resolve()
    work = a.workdir.resolve()
    out = a.out.resolve()
    work.mkdir(parents=True, exist_ok=False)
    out.mkdir(parents=True, exist_ok=False)
    rt = json.loads((a.runtime / 'runtime.json').read_text())
    binary = Path(rt['binary'])
    if sha(binary.read_bytes()) != rt['binary_sha256']:
        raise ValueError('runtime identity differs')
    prepared = {}
    inputs = {}
    for label, folder in (('before', 'base'), ('after', 'final')):
        meta, _ = inventory(root / folder)
        inputs[label] = meta['sets']['striderua']['files']
        prepared[label] = G.stage_sets(root / folder, 'striderus01', a.hbmame, a.rom_dir.resolve(), work / 'sets' / label)
    jobs = [(label, case) for label in prepared for case in ('climb', 'seam', 'clear')]

    def run(job):
        label, case = job
        target = work / (label + '_' + case)
        roms = prepared[label]
        if case == 'clear':
            cmd = [sys.executable, str(Path(__file__).with_name('stage_clear_study.py')), '--mame', str(binary), '--rompath', str(roms), '--machine', 'striderus01', '--frames', '6000', '--after-clear', '400', '--out', str(target)]
            r = subprocess.run(cmd, capture_output=True, text=True)
            if r.returncode:
                raise ValueError(r.stdout[-500:] + r.stderr[-1000:])
        else:
            n = 1400 if case == 'climb' else 3450
            area = 1 if case == 'climb' else 2
            inputs = '450-940:P1_JOYSTICK_RIGHT;960-1400:P1_JOYSTICK_UP;960-974:P1_BUTTON2' if case == 'climb' else G.OFFICER_KILL_INPUTS + ';3050-3450:P1_JOYSTICK_RIGHT'
            G.run(binary, roms, 'striderus01', target, dict(G.debug_env(5, area, n, inputs=False), MOTION='1', SHOTS='970-1040@2' if case == 'climb' else '3240-3380@2', STREX_INPUTS=inputs), n)
        return target
    with ThreadPoolExecutor(2) as ex:
        paths = dict(zip(jobs, ex.map(run, jobs)))

    def closest(folder, frame):
        return min(folder.glob('s_*.png'), key=lambda p: abs(int(p.stem[2:]) - frame))
    clear = [json.loads((paths[l, 'clear'] / 'report.json').read_text())['clear_frame'] for l in prepared]
    if clear[0] != clear[1]:
        raise ValueError('clear preview clocks differ')
    source = {}
    for case in ('climb', 'clear'):
        start, end, step = (970, 1040, 2) if case == 'climb' else (clear[0], clear[0] + 290, 5)
        pictures = []
        pairs = []
        for f in range(start, end + 1, step):
            pair = [closest(paths[label, case], f) for label in prepared]
            pictures.append(panel(*pair))
            pairs.append(pair)
        duration = round(step / 59.637 * 100) * 10
        pictures[0].save(out / (case + '.gif'), save_all=True, append_images=pictures[1:], duration=[duration] * (len(pictures) - 1) + [1500], loop=0)
        poster = Image.new('RGB', (768, 244 * 3))
        for j, i in enumerate((0, len(pictures) // 2, len(pictures) - 1)):
            poster.paste(pictures[i], (0, j * 244))
        poster.save(out / (case + '.png'))
        source[case] = [dict(frame=int(p[0].stem[2:]), before_sha256=sha(p[0].read_bytes()), after_sha256=sha(p[1].read_bytes())) for p in pairs]
    loads = []
    for label in prepared:
        dz = G.read_desert(paths[label, 'seam'])
        loads.append(next((r['frame'] for r in dz if r['map'] == 1)))
    pair = [closest(paths[label, 'seam'], f + 8) for label, f in zip(prepared, loads)]
    panel(*pair, '| map 1 reveal').save(out / 'seam.png')
    source['seam'] = [dict(label=label, frame=int(p.stem[2:]), sha256=sha(p.read_bytes())) for label, p in zip(prepared, pair)]
    report = dict(schema='striderex-gameplay-followup-preview/1', input_files=inputs, runtime_sha256=rt['binary_sha256'], source_sha256={p.name: sha(p.read_bytes()) for p in (Path(__file__), G.LUA, Path(__file__).parents[1] / 'lua/stage_clear_study.lua')}, unmodified_emulator_pictures=True, images={p.name: sha(p.read_bytes()) for p in out.iterdir()}, sources=source)
    (out / 'preview.json').write_text(json.dumps(report, indent=2) + '\n')
    print('Saved actual ROM before/after stage-clear, ceiling-climb and map-seam previews')
if __name__ == '__main__':
    main()
