-- Driven surface trace for VH2 translation review.
--
-- Env:
--   VH2_TRACE_PREFIX     output path prefix, default "/private/tmp/vh2_surface"
--   VH2_TRACE_CAPTURES   "frame=label;frame=label", default captures boot/title/select path
--   VH2_TRACE_SCHEDULE   "start-end:TOKEN;start-end:TOKEN+TOKEN", default coins/starts/selects P1
--   VH2_TRACE_POKES      "frame:addr=value;frame:addr=value", optional one-shot RAM writes
--   VH2_TRACE_POST_FILLS "frame:addr-addr=value;frame:addr-addr=value", optional frame-done fills before capture
--   VH2_TRACE_POST_POKES "frame:addr=value;start-end:addr=value", optional frame-done RAM writes before capture
--   VH2_TRACE_WATCHES    "addr;start-end;addr@frame-frame", optional write taps
--   VH2_TRACE_READ_WATCHES "addr;start-end;addr@frame-frame", optional read taps
--   VH2_TRACE_QUIET_READS "1" suppresses read-tap stdout while keeping TSV rows
--   VH2_TRACE_READ_OVERRIDES "addr=value;addr=value@frame-frame", optional byte overrides for ROM reads
--   VH2_TRACE_WRITE_OVERRIDES "addr=value;addr=value@frame-frame", optional byte overrides for RAM writes
--   VH2_TRACE_DUMPS      "addr:len;addr:len", capture-time memory dumps
--   VH2_TRACE_FAST_DUMPS "1" uses MAME read_range for bulk byte dumps
--   VH2_TRACE_HISTOGRAMS "0" skips optional tile-word histograms
--
-- TOKEN values are MAME input tokens such as COIN1, START1, P1_BUTTON1,
-- P1_JOYSTICK_RIGHT, etc. SERVICE_MODE and SERVICE1 also resolve by their
-- CPS-2 field names because MAME does not assign the test switch an input
-- token. Digital fields are pressed with field:set_value(1) and released with
-- field:clear_value().

local cpu = manager.machine.devices[':maincpu']
local mem = cpu.spaces['program']
local screen = manager.machine.screens[':screen']
local ioport = manager.machine.ioport

local prefix = os.getenv('VH2_TRACE_PREFIX') or '/private/tmp/vh2_surface'
local capture_spec = os.getenv('VH2_TRACE_CAPTURES') or
  '600=boot_qsound;3000=title;3300=character_select;3600=select_options;3900=pre_fight_transition;4500=early_fight;5400=fight_stable'
local schedule_spec = os.getenv('VH2_TRACE_SCHEDULE') or
  '3050-3070:COIN1;3090-3110:COIN1;3170-3190:START1;3560-3580:P1_BUTTON1;3860-3880:P1_BUTTON1'
local poke_spec = os.getenv('VH2_TRACE_POKES') or ''
local post_fill_spec = os.getenv('VH2_TRACE_POST_FILLS') or ''
local post_poke_spec = os.getenv('VH2_TRACE_POST_POKES') or ''
local watch_spec = os.getenv('VH2_TRACE_WATCHES') or ''
local read_watch_spec = os.getenv('VH2_TRACE_READ_WATCHES') or ''
local quiet_reads = os.getenv('VH2_TRACE_QUIET_READS') == '1'
local read_override_spec = os.getenv('VH2_TRACE_READ_OVERRIDES') or ''
local write_override_spec = os.getenv('VH2_TRACE_WRITE_OVERRIDES') or ''
local dump_spec = os.getenv('VH2_TRACE_DUMPS') or
  '0x900000:0x4000;0x904000:0x4000;0x908000:0x4000;0x90c000:0x1000'

local function rb(a) return mem:read_u8(a & 0xffffff) end
local function rw(a) return mem:read_u16(a & 0xffffff) end

local function trim(s)
  return (s:gsub('^%s+', ''):gsub('%s+$', ''))
end

local function safe_label(s)
  local out = trim(s):gsub('[^A-Za-z0-9_.-]+', '_')
  if out == '' then return 'capture' end
  return out
end

local captures = {}
local last_frame = 0
for part in string.gmatch(capture_spec, '[^;]+') do
  local frame_s, label = part:match('^%s*(%d+)%s*=%s*([^;]+)%s*$')
  if frame_s and label then
    local frame = tonumber(frame_s)
    captures[frame] = safe_label(label)
    if frame > last_frame then last_frame = frame end
  end
end

local fields_by_token = {}
for _, port in pairs(ioport.ports) do
  for _, field in pairs(port.fields) do
    local token = ioport:input_type_to_token(field.type, field.player)
    if token and token ~= '' then
      fields_by_token[token] = field
    end
  end
end

local named_input_aliases = {
  SERVICE_MODE = 'Service Mode',
  SERVICE1 = 'Service 1',
}
for token, wanted in pairs(named_input_aliases) do
  if not fields_by_token[token] then
    for _, port in pairs(ioport.ports) do
      for name, field in pairs(port.fields) do
        if name == wanted then fields_by_token[token] = field end
      end
    end
  end
end

local schedule = {}
for part in string.gmatch(schedule_spec, '[^;]+') do
  local start_s, end_s, tokens_s = part:match('^%s*(%d+)%s*%-%s*(%d+)%s*:%s*([^;]+)%s*$')
  if start_s and end_s and tokens_s then
    local rec = { start = tonumber(start_s), finish = tonumber(end_s), tokens = {} }
    for tok in string.gmatch(tokens_s, '[^+]+') do
      tok = trim(tok)
      if tok ~= '' then
        if not fields_by_token[tok] then
          print(string.format('TRACE missing_input token=%s', tok))
        end
        rec.tokens[#rec.tokens + 1] = tok
      end
    end
    schedule[#schedule + 1] = rec
    if rec.finish > last_frame then last_frame = rec.finish end
  end
end

local dump_ranges = {}
for part in string.gmatch(dump_spec, '[^;]+') do
  local addr_s, len_s = part:match('^%s*(0?x?[%da-fA-F]+)%s*:%s*(0?x?[%da-fA-F]+)%s*$')
  if addr_s and len_s then
    local addr = tonumber(addr_s)
    local len = tonumber(len_s)
    dump_ranges[#dump_ranges + 1] = {
      base = addr & 0xffffff,
      len = len,
      label = string.format('%06x', addr & 0xffffff),
    }
  end
end

local pokes = {}
for part in string.gmatch(poke_spec, '[^;]+') do
  local frame_s, addr_s, value_s = part:match('^%s*(%d+)%s*:%s*(0?x?[%da-fA-F]+)%s*=%s*(0?x?[%da-fA-F]+)%s*$')
  if frame_s and addr_s and value_s then
    local frame = tonumber(frame_s)
    pokes[#pokes + 1] = {
      frame = frame,
      addr = tonumber(addr_s),
      value = tonumber(value_s),
      done = false,
    }
    if frame > last_frame then last_frame = frame end
  end
end

local post_fills = {}
for part in string.gmatch(post_fill_spec, '[^;]+') do
  local frame_s, start_s, end_s, value_s =
    part:match('^%s*(%d+)%s*:%s*(0?x?[%da-fA-F]+)%s*%-%s*(0?x?[%da-fA-F]+)%s*=%s*(0?x?[%da-fA-F]+)%s*$')
  if frame_s and start_s and end_s and value_s then
    local start_addr = tonumber(start_s) & 0xffffff
    local end_addr = tonumber(end_s) & 0xffffff
    if end_addr < start_addr then
      local tmp = start_addr
      start_addr = end_addr
      end_addr = tmp
    end
    local frame = tonumber(frame_s)
    post_fills[#post_fills + 1] = {
      frame = frame,
      start_addr = start_addr,
      end_addr = end_addr,
      value = tonumber(value_s) & 0xff,
      done = false,
    }
    if frame > last_frame then last_frame = frame end
  end
end

local post_pokes = {}
for part in string.gmatch(post_poke_spec, '[^;]+') do
  local start_s, finish_s, addr_s, value_s =
    part:match('^%s*(%d+)%s*%-%s*(%d+)%s*:%s*(0?x?[%da-fA-F]+)%s*=%s*(0?x?[%da-fA-F]+)%s*$')
  if not start_s then
    start_s, addr_s, value_s =
      part:match('^%s*(%d+)%s*:%s*(0?x?[%da-fA-F]+)%s*=%s*(0?x?[%da-fA-F]+)%s*$')
    finish_s = start_s
  end
  if start_s and addr_s and value_s then
    local start_frame = tonumber(start_s)
    local finish_frame = tonumber(finish_s)
    if finish_frame < start_frame then
      local tmp = start_frame
      start_frame = finish_frame
      finish_frame = tmp
    end
    post_pokes[#post_pokes + 1] = {
      start_frame = start_frame,
      finish_frame = finish_frame,
      addr = tonumber(addr_s) & 0xffffff,
      value = tonumber(value_s) & 0xff,
      done = false,
    }
    if finish_frame > last_frame then last_frame = finish_frame end
  end
end

local meta_path = prefix .. '_trace.tsv'
local meta = assert(io.open(meta_path, 'w'))
meta:write('kind\tframe\tlabel\tpc\tmode\ttimer\tpath\n')

local active_tokens = {}
local taps = {}
local pending_watch_reads = {}
local read_overrides = {}
local write_overrides = {}

local function parse_hex(s)
  return tonumber(s)
end

local function effective_addr(base, offset)
  if offset >= base then return offset & 0xffffff end
  return (base + offset) & 0xffffff
end

local function tap_range_end(addr)
  local bytes = math.max(1, math.floor(mem.data_width / 8))
  return (addr | (bytes - 1)) & 0xffffff
end

local function parse_frame_filter(s)
  if not s or trim(s) == '' then return nil end
  local start_s, end_s = s:match('^%s*(%d+)%s*%-%s*(%d+)%s*$')
  if start_s and end_s then
    return { start = tonumber(start_s), finish = tonumber(end_s) }
  end
  local frame_s = s:match('^%s*(%d+)%s*$')
  if frame_s then
    local frame = tonumber(frame_s)
    return { start = frame, finish = frame }
  end
  print(string.format('TRACE invalid_watch_frame_filter spec=%s', s))
  return nil
end

local function frame_matches(filter, frame)
  return (not filter) or (frame >= filter.start and frame <= filter.finish)
end

for part in string.gmatch(read_override_spec, '[^;]+') do
  local override_part, frame_part = part:match('^%s*([^@]+)%s*@%s*([^@]+)%s*$')
  if not override_part then override_part = part end
  local addr_s, value_s = override_part:match('^%s*(0?x?[%da-fA-F]+)%s*=%s*(0?x?[%da-fA-F]+)%s*$')
  if addr_s and value_s then
    local addr = tonumber(addr_s) & 0xffffff
    if not read_overrides[addr] then read_overrides[addr] = {} end
    read_overrides[addr][#read_overrides[addr] + 1] = {
      value = tonumber(value_s) & 0xff,
      frame_filter = parse_frame_filter(frame_part),
    }
  end
end

local function read_override_byte(overrides, addr)
  local records = overrides[addr & 0xffffff]
  if not records then return nil end
  local frame = screen:frame_number()
  for _, rec in ipairs(records) do
    if frame_matches(rec.frame_filter, frame) then
      return rec.value
    end
  end
  return nil
end

local function override_value(overrides, addr, data)
  if mem.data_width == 8 then
    return read_override_byte(overrides, addr) or data
  end
  if mem.data_width == 16 then
    local out = data & 0xffff
    local high = read_override_byte(overrides, addr)
    local low = read_override_byte(overrides, addr + 1)
    if high then out = ((high & 0xff) << 8) | (out & 0x00ff) end
    if low then out = (out & 0xff00) | (low & 0xff) end
    return out
  end
  return data
end

do
  local min_addr = nil
  local max_addr = nil
  for addr, _value in pairs(read_overrides) do
    min_addr = min_addr and math.min(min_addr, addr) or addr
    max_addr = max_addr and math.max(max_addr, addr) or addr
  end
  if min_addr and max_addr then
    taps[#taps + 1] = mem:install_read_tap(min_addr, max_addr, 'vh2_surface_read_override', function(offset, data, mask)
      return override_value(read_overrides, effective_addr(min_addr, offset), data, mask)
    end)
    meta:write(string.format('read_override\t0\t%06x-%06x\t%06x\t%04x\t%04x\t\n',
      min_addr, max_addr, cpu.state['PC'].value & 0xffffff, rw(0xff8000), rw(0xff8006)))
  end
end

local function write_override_byte(addr)
  local records = write_overrides[addr & 0xffffff]
  if not records then return nil end
  local frame = screen:frame_number()
  for _, rec in ipairs(records) do
    if frame_matches(rec.frame_filter, frame) then
      return rec.value
    end
  end
  return nil
end

local function override_write_value(addr, data)
  if mem.data_width == 8 then
    return write_override_byte(addr) or data
  end
  if mem.data_width == 16 then
    local out = data & 0xffff
    local high = write_override_byte(addr)
    local low = write_override_byte(addr + 1)
    if high then out = ((high & 0xff) << 8) | (out & 0x00ff) end
    if low then out = (out & 0xff00) | (low & 0xff) end
    return out
  end
  return data
end

for part in string.gmatch(write_override_spec, '[^;]+') do
  local override_part, frame_part = part:match('^%s*([^@]+)%s*@%s*([^@]+)%s*$')
  if not override_part then override_part = part end
  local addr_s, value_s = override_part:match('^%s*(0?x?[%da-fA-F]+)%s*=%s*(0?x?[%da-fA-F]+)%s*$')
  if addr_s and value_s then
    local addr = tonumber(addr_s) & 0xffffff
    if not write_overrides[addr] then write_overrides[addr] = {} end
    write_overrides[addr][#write_overrides[addr] + 1] = {
      value = tonumber(value_s) & 0xff,
      frame_filter = parse_frame_filter(frame_part),
    }
  end
end

do
  local min_addr = nil
  local max_addr = nil
  for addr, _value in pairs(write_overrides) do
    min_addr = min_addr and math.min(min_addr, addr) or addr
    max_addr = max_addr and math.max(max_addr, addr) or addr
  end
  if min_addr and max_addr then
    taps[#taps + 1] = mem:install_write_tap(min_addr, max_addr, 'vh2_surface_write_override', function(offset, data, mask)
      return override_write_value(effective_addr(min_addr, offset), data, mask)
    end)
    meta:write(string.format('write_override\t0\t%06x-%06x\t%06x\t%04x\t%04x\t\n',
      min_addr, max_addr, cpu.state['PC'].value & 0xffffff, rw(0xff8000), rw(0xff8006)))
  end
end

for part in string.gmatch(watch_spec, '[^;]+') do
  local watch_part, frame_part = part:match('^%s*([^@]+)%s*@%s*([^@]+)%s*$')
  if not watch_part then watch_part = part end
  local frame_filter = parse_frame_filter(frame_part)
  local start_s, end_s = watch_part:match('^%s*(0?x?[%da-fA-F]+)%s*%-%s*(0?x?[%da-fA-F]+)%s*$')
  if not start_s then
    start_s = watch_part:match('^%s*(0?x?[%da-fA-F]+)%s*$')
    end_s = start_s
  end
  if start_s and end_s then
    local start_addr = parse_hex(start_s) & 0xffffff
    local end_addr = parse_hex(end_s) & 0xffffff
    taps[#taps + 1] = mem:install_write_tap(start_addr, tap_range_end(end_addr), 'vh2_surface_watch', function(offset, data, mask)
      local frame = screen:frame_number()
      if not frame_matches(frame_filter, frame) then return data end
      local addr = effective_addr(start_addr, offset)
      pending_watch_reads[#pending_watch_reads + 1] = {
        frame = frame,
        addr = addr,
        pc = cpu.state['PC'].value & 0xffffff,
        data = data & 0xffffffff,
        mask = mask & 0xffffffff,
      }
      local label = string.format('%06x data=%08x mask=%08x value=%02x d0=%08x d1=%08x a0=%06x a1=%06x a2=%06x a5=%06x a6=%06x',
        addr,
        data & 0xffffffff,
        mask & 0xffffffff,
        rb(addr),
        cpu.state['D0'].value & 0xffffffff,
        cpu.state['D1'].value & 0xffffffff,
        cpu.state['A0'].value & 0xffffff,
        cpu.state['A1'].value & 0xffffff,
        cpu.state['A2'].value & 0xffffff,
        cpu.state['A5'].value & 0xffffff,
        cpu.state['A6'].value & 0xffffff)
      print(string.format('TRACE write f=%04d addr=%06x pc=%06x %s', frame, addr, cpu.state['PC'].value & 0xffffff, label))
      meta:write(string.format('write\t%d\t%s\t%06x\t%04x\t%04x\t\n',
        frame, label, cpu.state['PC'].value & 0xffffff, rw(0xff8000), rw(0xff8006)))
      return data
    end)
  end
end

for part in string.gmatch(read_watch_spec, '[^;]+') do
  local watch_part, frame_part = part:match('^%s*([^@]+)%s*@%s*([^@]+)%s*$')
  if not watch_part then watch_part = part end
  local frame_filter = parse_frame_filter(frame_part)
  local start_s, end_s = watch_part:match('^%s*(0?x?[%da-fA-F]+)%s*%-%s*(0?x?[%da-fA-F]+)%s*$')
  if not start_s then
    start_s = watch_part:match('^%s*(0?x?[%da-fA-F]+)%s*$')
    end_s = start_s
  end
  if start_s and end_s then
    local start_addr = parse_hex(start_s) & 0xffffff
    local end_addr = parse_hex(end_s) & 0xffffff
    taps[#taps + 1] = mem:install_read_tap(start_addr, tap_range_end(end_addr), 'vh2_surface_read_watch', function(offset, data, mask)
      local frame = screen:frame_number()
      if not frame_matches(frame_filter, frame) then return data end
      local addr = effective_addr(start_addr, offset)
      local label = string.format('%06x data=%08x mask=%08x d0=%08x d1=%08x a0=%06x a1=%06x a2=%06x a5=%06x a6=%06x',
        addr,
        data & 0xffffffff,
        mask & 0xffffffff,
        cpu.state['D0'].value & 0xffffffff,
        cpu.state['D1'].value & 0xffffffff,
        cpu.state['A0'].value & 0xffffff,
        cpu.state['A1'].value & 0xffffff,
        cpu.state['A2'].value & 0xffffff,
        cpu.state['A5'].value & 0xffffff,
        cpu.state['A6'].value & 0xffffff)
      if not quiet_reads then
        print(string.format('TRACE read f=%04d addr=%06x pc=%06x %s', frame, addr, cpu.state['PC'].value & 0xffffff, label))
      end
      meta:write(string.format('read\t%d\t%s\t%06x\t%04x\t%04x\t\n',
        frame, label, cpu.state['PC'].value & 0xffffff, rw(0xff8000), rw(0xff8006)))
      return data
    end)
  end
end

local function dump(path, base, len)
  local f = assert(io.open(path, 'wb'))
  if os.getenv('VH2_TRACE_FAST_DUMPS') == '1' then
    f:write(mem:read_range(base, base + len - 1, 8))
    f:close()
    return
  end
  for off = 0, len - 1 do
    f:write(string.char(rb(base + off)))
  end
  f:close()
end

local function top_words(base, bytes)
  if os.getenv('VH2_TRACE_HISTOGRAMS') == '0' then return '-' end
  local counts = {}
  for off = 0, bytes - 2, 2 do
    local v = rw(base + off)
    counts[v] = (counts[v] or 0) + 1
  end
  local arr = {}
  for k, v in pairs(counts) do
    arr[#arr + 1] = { k = k, v = v }
  end
  table.sort(arr, function(a, b)
    if a.v == b.v then return a.k < b.k end
    return a.v > b.v
  end)
  local out = {}
  for i = 1, math.min(8, #arr) do
    out[#out + 1] = string.format('%04x:%d', arr[i].k, arr[i].v)
  end
  return table.concat(out, ',')
end

local function set_input_state(frame)
  for _, rec in ipairs(pokes) do
    if (not rec.done) and frame >= rec.frame then
      mem:write_u8(rec.addr & 0xffffff, rec.value & 0xff)
      rec.done = true
      print(string.format('TRACE poke f=%04d addr=%06x value=%02x', frame, rec.addr & 0xffffff, rec.value & 0xff))
      meta:write(string.format('poke\t%d\t%06x=%02x\t%06x\t%04x\t%04x\t\n',
        frame, rec.addr & 0xffffff, rec.value & 0xff,
        cpu.state['PC'].value & 0xffffff, rw(0xff8000), rw(0xff8006)))
    end
  end
  local wanted = {}
  for _, rec in ipairs(schedule) do
    if frame >= rec.start and frame <= rec.finish then
      for _, tok in ipairs(rec.tokens) do wanted[tok] = true end
    end
  end
  for tok, _ in pairs(wanted) do
    local field = fields_by_token[tok]
    if field then
      field:set_value(1)
      if not active_tokens[tok] then
        active_tokens[tok] = true
        print(string.format('TRACE input_down f=%04d token=%s', frame, tok))
        meta:write(string.format('input_down\t%d\t%s\t%06x\t%04x\t%04x\t\n',
          frame, tok, cpu.state['PC'].value & 0xffffff, rw(0xff8000), rw(0xff8006)))
      end
    end
  end
  for tok, _ in pairs(active_tokens) do
    if not wanted[tok] then
      local field = fields_by_token[tok]
      if field then field:clear_value() end
      active_tokens[tok] = nil
      print(string.format('TRACE input_up f=%04d token=%s', frame, tok))
      meta:write(string.format('input_up\t%d\t%s\t%06x\t%04x\t%04x\t\n',
        frame, tok, cpu.state['PC'].value & 0xffffff, rw(0xff8000), rw(0xff8006)))
    end
  end
end

local frame_subscription = emu.add_machine_frame_notifier(function()
  set_input_state(screen:frame_number())
end)

emu.register_frame_done(function()
  local frame = screen:frame_number()
  if #pending_watch_reads > 0 then
    for _, rec in ipairs(pending_watch_reads) do
      print(string.format('TRACE write_after f=%04d addr=%06x pc=%06x data=%08x mask=%08x value=%02x',
        frame, rec.addr, rec.pc, rec.data, rec.mask, rb(rec.addr)))
      meta:write(string.format('write_after\t%d\t%06x data=%08x mask=%08x value=%02x\t%06x\t%04x\t%04x\t\n',
        frame, rec.addr, rec.data, rec.mask, rb(rec.addr), rec.pc, rw(0xff8000), rw(0xff8006)))
    end
    pending_watch_reads = {}
  end
  for _, rec in ipairs(post_fills) do
    if (not rec.done) and frame >= rec.frame then
      for addr = rec.start_addr, rec.end_addr do
        mem:write_u8(addr & 0xffffff, rec.value)
      end
      rec.done = true
      print(string.format('TRACE post_fill f=%04d addr=%06x-%06x value=%02x',
        frame, rec.start_addr, rec.end_addr, rec.value))
      meta:write(string.format('post_fill\t%d\t%06x-%06x=%02x\t%06x\t%04x\t%04x\t\n',
        frame, rec.start_addr, rec.end_addr, rec.value,
        cpu.state['PC'].value & 0xffffff, rw(0xff8000), rw(0xff8006)))
    end
  end
  for _, rec in ipairs(post_pokes) do
    if frame >= rec.start_frame and frame <= rec.finish_frame then
      mem:write_u8(rec.addr, rec.value)
      if rec.start_frame == rec.finish_frame or frame == rec.start_frame or frame == rec.finish_frame then
        print(string.format('TRACE post_poke f=%04d addr=%06x value=%02x',
          frame, rec.addr, rec.value))
        meta:write(string.format('post_poke\t%d\t%06x=%02x\t%06x\t%04x\t%04x\t\n',
          frame, rec.addr, rec.value,
          cpu.state['PC'].value & 0xffffff, rw(0xff8000), rw(0xff8006)))
      end
      if rec.start_frame == rec.finish_frame then rec.done = true end
    end
  end
  local label = captures[frame]
  if label then
    local base = string.format('%s_%04d_%s', prefix, frame, label)
    local png = base .. '.png'
    screen:snapshot(png)
    for _, rec in ipairs(dump_ranges) do
      dump(base .. '_' .. rec.label .. '.bin', rec.base, rec.len)
    end
    print(string.format(
      'TRACE capture f=%04d label=%s pc=%06x mode=%04x timer=%04x top900=%s top904=%s top908=%s top90c=%s png=%s',
      frame, label, cpu.state['PC'].value & 0xffffff, rw(0xff8000), rw(0xff8006),
      top_words(0x900000, 0x4000),
      top_words(0x904000, 0x4000),
      top_words(0x908000, 0x4000),
      top_words(0x90c000, 0x1000),
      png))
    meta:write(string.format('capture\t%d\t%s\t%06x\t%04x\t%04x\t%s\n',
      frame, label, cpu.state['PC'].value & 0xffffff, rw(0xff8000), rw(0xff8006), png))
  end
  if frame > last_frame + 30 then
    for tok, _ in pairs(active_tokens) do
      local field = fields_by_token[tok]
      if field then field:clear_value() end
    end
    for _, tap in ipairs(taps) do tap:remove() end
    meta:close()
    if frame_subscription then frame_subscription:unsubscribe() end
    manager.machine:exit()
  end
end)
