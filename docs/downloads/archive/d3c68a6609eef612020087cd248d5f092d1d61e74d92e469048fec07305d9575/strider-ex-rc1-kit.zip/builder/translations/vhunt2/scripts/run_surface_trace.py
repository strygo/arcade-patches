"""Run a driven MAME surface trace and catalog the generated artifacts."""
from __future__ import annotations
import argparse
import csv
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
from collections import Counter
import inventory
ROOT = Path(__file__).resolve().parents[3]
PROJECT = Path(__file__).resolve().parents[1]
DEFAULT_CAPTURES = '600=boot_qsound;3000=title;3300=character_select;3600=select_options;3900=pre_fight_transition;4500=early_fight;5400=fight_stable'
DEFAULT_SCHEDULE = '3050-3070:COIN1;3090-3110:COIN1;3170-3190:START1;3560-3580:P1_BUTTON1;3860-3880:P1_BUTTON1'
DEFAULT_DUMP_RANGES = (('900000', 16384), ('904000', 16384), ('908000', 16384), ('90c000', 4096))

def rompath_arg(extra: list[str], prefer_extra: bool=False) -> str:
    extra_paths = [Path(p).expanduser().resolve() for p in extra]
    default_paths = inventory.default_rompaths(ROOT)
    paths = extra_paths + default_paths if prefer_extra else default_paths + extra_paths
    return ';'.join((str(p) for p in paths))

def inputs_complete(machine: str, extra_rompaths: list[str]) -> tuple[bool, str]:
    sources = inventory.index_sources(inventory.default_rompaths(ROOT) + [Path(p).expanduser().resolve() for p in extra_rompaths])
    if machine not in inventory.SETS:
        return (True, '')
    rec = inventory.inventory_set(machine, sources)
    if rec['complete']:
        return (True, '')
    missing = ', '.join(rec['missing'] + rec['mismatches'])
    return (False, f'{machine} input set incomplete: {missing}')

def build_command(machine: str, script: str, rompaths: list[str], mame_args: list[str], mame_bin: str, prefer_rompath: bool=False) -> list[str]:
    mame_args = normalize_mame_args(mame_args)
    return [mame_bin, machine, '-rompath', rompath_arg(rompaths, prefer_rompath), '-skip_gameinfo', '-noautosave', '-autoboot_script', script, *mame_args]

def normalize_mame_args(mame_args: list[str]) -> list[str]:
    return list(mame_args)

def apply_mame_environment(env: dict[str, str], mame_args: list[str]) -> None:
    video_none = any((mame_args[index:index + 2] == ['-video', 'none'] for index in range(len(mame_args) - 1)))
    visible_window = '-window' in mame_args
    if video_none and (not visible_window):
        env['SDL_VIDEODRIVER'] = 'dummy'
        env['SDL_AUDIODRIVER'] = 'dummy'

def file_sha1(path: Path) -> str | None:
    if not path.exists():
        return None
    h = hashlib.sha1()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()

def top_words(path: Path, limit: int) -> list[dict]:
    if not path.exists():
        return []
    data = path.read_bytes()
    counts = Counter((int.from_bytes(data[i:i + 2], 'big') for i in range(0, len(data) - 1, 2)))
    return [{'word': f'0x{word:04x}', 'count': count} for word, count in sorted(counts.items(), key=lambda kv: (-kv[1], kv[0]))[:limit]]

def parse_dump_ranges(parts: list[str]) -> list[tuple[str, int]]:
    ranges = []
    for part in parts:
        for item in part.split(';'):
            item = item.strip()
            if not item:
                continue
            try:
                addr_s, len_s = item.split(':', 1)
                addr = int(addr_s, 0)
                length = int(len_s, 0)
            except ValueError as exc:
                raise SystemExit(f'invalid dump range {item!r}; expected addr:len') from exc
            ranges.append((f'{addr & 16777215:06x}', length))
    return ranges or list(DEFAULT_DUMP_RANGES)

def dump_spec(ranges: list[tuple[str, int]]) -> str:
    return ';'.join((f'0x{label}:0x{length:x}' for label, length in ranges))

def read_trace_rows(path: Path) -> list[dict]:
    if not path.exists():
        raise SystemExit(f'missing trace TSV: {path}')
    with path.open(newline='', encoding='utf-8') as f:
        return list(csv.DictReader(f, delimiter='\t'))

def catalog_trace(machine: str, outdir: Path, prefix: Path, dump_ranges: list[tuple[str, int]], top_limit: int) -> dict:
    rows = read_trace_rows(Path(str(prefix) + '_trace.tsv'))
    captures = []
    for row in rows:
        if row.get('kind') != 'capture':
            continue
        frame = int(row['frame'])
        label = row['label']
        base = Path(str(prefix) + f'_{frame:04d}_{label}')
        png = base.with_suffix('.png')
        bins = {page: Path(str(base) + f'_{page}.bin') for page, _length in dump_ranges}
        captures.append({'frame': frame, 'label': label, 'pc': '0x' + row['pc'], 'mode': '0x' + row['mode'], 'timer': '0x' + row['timer'], 'png': rel(png), 'png_sha1': file_sha1(png), 'vram_pages': {page: {'path': rel(path), 'sha1': file_sha1(path), 'top_words': top_words(path, top_limit)} for page, path in bins.items()}})
    input_events = [{'kind': row['kind'], 'frame': int(row['frame']), 'token': row['label'], 'pc': '0x' + row['pc'], 'mode': '0x' + row['mode'], 'timer': '0x' + row['timer']} for row in rows if row.get('kind') in {'input_down', 'input_up', 'poke'}]
    write_events = [{'frame': int(row['frame']), 'label': row['label'], 'pc': '0x' + row['pc'], 'mode': '0x' + row['mode'], 'timer': '0x' + row['timer']} for row in rows if row.get('kind') in {'write', 'write_after'}]
    read_events = [{'frame': int(row['frame']), 'label': row['label'], 'pc': '0x' + row['pc'], 'mode': '0x' + row['mode'], 'timer': '0x' + row['timer']} for row in rows if row.get('kind') == 'read']
    return {'machine': machine, 'outdir': rel(outdir), 'trace_tsv': rel(Path(str(prefix) + '_trace.tsv')), 'captures': captures, 'input_events': input_events, 'read_events': read_events, 'write_events': write_events}

def rel(path: Path) -> str:
    return inventory.repo_relative(path)

def self_test() -> int:
    cmd = build_command('vhunt2', 'trace.lua', [], ['-window'], 'mame')
    if 'vhunt2' not in cmd or '-autoboot_script' not in cmd:
        print('surface trace runner self-test failed', file=sys.stderr)
        return 1
    headless = build_command('vhunt2', 'trace.lua', [], ['-video', 'none'], 'mame')
    headless_env = {'PRESERVE': 'yes'}
    apply_mame_environment(headless_env, ['-video', 'none', '-sound', 'none'])
    if '-videodriver' in headless or headless_env.get('SDL_VIDEODRIVER') != 'dummy' or headless_env.get('SDL_AUDIODRIVER') != 'dummy' or (headless_env.get('PRESERVE') != 'yes'):
        print('surface trace SDL dummy-driver self-test failed', file=sys.stderr)
        return 1
    visible = build_command('vhunt2', 'trace.lua', [], ['-video', 'none', '-window'], 'mame')
    if '-videodriver' in visible:
        print('surface trace visible-window self-test failed', file=sys.stderr)
        return 1
    visible_env = {}
    apply_mame_environment(visible_env, ['-video', 'none', '-window'])
    if visible_env:
        print('surface trace visible-window environment self-test failed', file=sys.stderr)
        return 1
    data = b'\x00\x01\x00\x02\x00\x01'
    tmp = PROJECT / 'work' / '.surface_trace_selftest.bin'
    try:
        tmp.parent.mkdir(parents=True, exist_ok=True)
        tmp.write_bytes(data)
        got = top_words(tmp, 2)
        if got != [{'word': '0x0001', 'count': 2}, {'word': '0x0002', 'count': 1}]:
            print('surface trace histogram self-test failed', file=sys.stderr)
            return 1
    finally:
        try:
            tmp.unlink()
        except FileNotFoundError:
            pass
    print('surface trace runner self-test passed')
    return 0

def main(argv: list[str] | None=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--machine', default='vhunt2')
    parser.add_argument('--script', default=str(PROJECT / 'lua' / 'vh2_surface_trace.lua'))
    parser.add_argument('--outdir', default=str(PROJECT / 'work' / 'surface_trace_vhunt2'))
    parser.add_argument('--captures', default=DEFAULT_CAPTURES)
    parser.add_argument('--schedule', default=DEFAULT_SCHEDULE)
    parser.add_argument('--pokes', default='')
    parser.add_argument('--post-fills', default='', help='frame-done byte fills like frame:addr-addr=value; applied immediately before capture, after game writes for that frame')
    parser.add_argument('--post-pokes', default='', help='frame-done byte writes like frame:addr=value or start-end:addr=value; applied after game writes for each matching frame')
    parser.add_argument('--watches', default='')
    parser.add_argument('--read-watches', default='')
    parser.add_argument('--quiet-reads', action='store_true')
    parser.add_argument('--read-overrides', default='')
    parser.add_argument('--write-overrides', default='', help='byte write overrides like addr=value or addr=value@frame-frame; semicolon-separated')
    parser.add_argument('--dump-range', action='append', default=[], help='capture memory range as addr:len; may be repeated or semicolon-separated')
    parser.add_argument('--rompath', action='append', default=[])
    parser.add_argument('--rompath-first', action='store_true')
    parser.add_argument('--mame', default=os.environ.get('MAME', 'mame'))
    parser.add_argument('--mame-arg', action='append', default=[])
    parser.add_argument('--catalog-out', default='')
    parser.add_argument('--top-limit', type=int, default=12)
    parser.add_argument('--dry-run', action='store_true')
    parser.add_argument('--no-input-check', action='store_true')
    parser.add_argument('--self-test', action='store_true')
    args = parser.parse_args(argv)
    if args.self_test:
        return self_test()
    if not args.no_input_check:
        ok, msg = inputs_complete(args.machine, args.rompath)
        if not ok:
            print(msg, file=sys.stderr)
            return 2
    outdir = Path(args.outdir).expanduser().resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    prefix = outdir / args.machine
    env = os.environ.copy()
    env['VH2_TRACE_PREFIX'] = str(prefix)
    env['VH2_TRACE_CAPTURES'] = args.captures
    env['VH2_TRACE_SCHEDULE'] = args.schedule
    env['VH2_TRACE_POKES'] = args.pokes
    env['VH2_TRACE_POST_FILLS'] = args.post_fills
    env['VH2_TRACE_POST_POKES'] = args.post_pokes
    env['VH2_TRACE_WATCHES'] = args.watches
    env['VH2_TRACE_READ_WATCHES'] = args.read_watches
    env['VH2_TRACE_QUIET_READS'] = '1' if args.quiet_reads else ''
    env['VH2_TRACE_READ_OVERRIDES'] = args.read_overrides
    env['VH2_TRACE_WRITE_OVERRIDES'] = args.write_overrides
    apply_mame_environment(env, args.mame_arg)
    dump_ranges = parse_dump_ranges(args.dump_range)
    env['VH2_TRACE_DUMPS'] = dump_spec(dump_ranges)
    cmd = build_command(args.machine, args.script, args.rompath, args.mame_arg, args.mame, args.rompath_first)
    print(' '.join(cmd))
    if args.dry_run:
        return 0
    result = subprocess.run(cmd, env=env, check=False)
    if result.returncode != 0:
        return result.returncode
    catalog = catalog_trace(args.machine, outdir, prefix, dump_ranges, args.top_limit)
    catalog_path = Path(args.catalog_out).expanduser().resolve() if args.catalog_out else outdir / f'{args.machine}_surface_catalog.json'
    catalog_path.parent.mkdir(parents=True, exist_ok=True)
    catalog_path.write_text(json.dumps(catalog, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    print(f'wrote {catalog_path}')
    print(f"captures: {len(catalog['captures'])}, input_events: {len(catalog['input_events'])}, read_events: {len(catalog['read_events'])}, write_events: {len(catalog['write_events'])}")
    return 0
if __name__ == '__main__':
    raise SystemExit(main())
