"""Inventory canonical arcade ROM inputs for the VH2 translation work."""
from __future__ import annotations
import argparse
import datetime as _dt
import hashlib
import json
import os
from pathlib import Path
import sys
import zipfile
import zlib
from arcade_data import SETS, VH2_FIRST_SETS, validate_metadata
ROOT = Path(__file__).resolve().parents[3]
PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))
from repo_paths import repo_display_path

def repo_relative(path: Path) -> str:
    return repo_display_path(path, ROOT)

class RomSource:

    def __init__(self, label: str, kind: str, path: Path, member: str | None=None):
        self.label = label
        self.kind = kind
        self.path = path
        self.member = member

    def read(self) -> bytes:
        if self.kind == 'zip':
            with zipfile.ZipFile(self.path) as zf:
                return zf.read(self.member)
        return self.path.read_bytes()

    def as_json(self) -> dict:
        out = {'kind': self.kind, 'path': repo_relative(self.path)}
        if self.member is not None:
            out['member'] = self.member
        return out

def default_rompaths(root: Path) -> list[Path]:
    paths = [root / 'roms', root / 'roms' / 'mame0260']
    extra = os.environ.get('CAPCOM_ARCADE_ROM_PATH')
    if extra:
        paths.extend((Path(p) for p in extra.split(os.pathsep) if p))
    seen = set()
    out = []
    for path in paths:
        path = path.expanduser().resolve()
        if path not in seen:
            seen.add(path)
            out.append(path)
    return out

def index_sources(rompaths: list[Path]) -> dict[str, RomSource]:
    found: dict[str, RomSource] = {}
    for base in rompaths:
        if not base.exists():
            continue
        for zip_path in sorted(base.glob('*.zip')):
            try:
                with zipfile.ZipFile(zip_path) as zf:
                    for name in zf.namelist():
                        key = Path(name).name.lower()
                        found.setdefault(key, RomSource(zip_path.name, 'zip', zip_path, name))
            except zipfile.BadZipFile:
                continue
        for child in sorted(base.iterdir()):
            if child.is_dir():
                for rom_path in sorted((p for p in child.iterdir() if p.is_file())):
                    found.setdefault(rom_path.name.lower(), RomSource(child.name, 'file', rom_path))
            elif child.is_file() and child.suffix.lower() != '.zip':
                found.setdefault(child.name.lower(), RomSource(base.name, 'file', child))
    return found

def file_info(data: bytes) -> dict:
    return {'size': len(data), 'crc32': f'{zlib.crc32(data) & 4294967295:08x}', 'sha1': hashlib.sha1(data).hexdigest()}

def inventory_set(set_name: str, sources: dict[str, RomSource]) -> dict:
    meta = SETS[set_name]
    files = []
    missing = []
    mismatches = []
    for rom in meta['roms']:
        src = sources.get(rom['name'].lower())
        rec = {'name': rom['name'], 'role': rom['role'], 'expected_size': rom['size'], 'expected_crc32': rom['crc32'], 'present': src is not None}
        if 'bank' in rom:
            rec['bank'] = rom['bank']
            rec['plane'] = rom['plane']
        if src is None:
            missing.append(rom['name'])
        else:
            data = src.read()
            actual = file_info(data)
            rec['source'] = src.as_json()
            rec['actual_size'] = actual['size']
            rec['actual_crc32'] = actual['crc32']
            rec['sha1'] = actual['sha1']
            if actual['size'] != rom['size'] or actual['crc32'] != rom['crc32']:
                mismatches.append(rom['name'])
        files.append(rec)
    return {'description': meta['description'], 'role': meta['role'], 'parent': meta['parent'], 'complete': not missing and (not mismatches), 'present_count': sum((1 for f in files if f['present'])), 'expected_count': len(files), 'missing': missing, 'mismatches': mismatches, 'files': files}

def oracle_inventory(root: Path) -> dict:
    arc = root / 'extraction' / 'arc'
    names = {'nwarru': 'nwarru_dec.bin', 'vhuntj': 'vhuntj_dec.bin', 'vhunt2': 'vhunt2_dec.bin', 'vsav': 'vsav_dec.bin', 'vsavj': 'vsavj_dec.bin', 'vsav2': 'vsav2_dec.bin'}
    out = {}
    for set_name, filename in names.items():
        path = arc / filename
        rec = {'path': str(path.relative_to(root)), 'present': path.exists()}
        if path.exists():
            data = path.read_bytes()
            rec.update(file_info(data))
        out[set_name] = rec
    return out

def write_json(path: Path, obj: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, sort_keys=True) + '\n')

def parse_sets(raw: str) -> list[str]:
    names = [x.strip() for x in raw.split(',') if x.strip()]
    unknown = [x for x in names if x not in SETS]
    if unknown:
        raise SystemExit(f"unknown set(s): {', '.join(unknown)}")
    return names

def self_test() -> int:
    errors = validate_metadata()
    if errors:
        for err in errors:
            print(err, file=sys.stderr)
        return 1
    print('arcade metadata self-test passed')
    return 0

def main(argv: list[str] | None=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--sets', default=','.join(VH2_FIRST_SETS), help='comma-separated set names')
    parser.add_argument('--rompath', action='append', default=[], help='additional MAME rom path')
    parser.add_argument('--out', default=str(PROJECT / 'manifests' / 'sources.json'))
    parser.add_argument('--check', action='store_true', help='return nonzero if any requested set is incomplete')
    parser.add_argument('--self-test', action='store_true')
    args = parser.parse_args(argv)
    if args.self_test:
        return self_test()
    errors = validate_metadata()
    if errors:
        for err in errors:
            print(err, file=sys.stderr)
        return 1
    set_names = parse_sets(args.sets)
    rompaths = default_rompaths(ROOT) + [Path(p).expanduser().resolve() for p in args.rompath]
    sources = index_sources(rompaths)
    result = {'generated_at': _dt.datetime.now(_dt.UTC).replace(microsecond=0).isoformat(), 'scope': 'arcade_mame_roms_only', 'search_paths': [repo_relative(p) for p in rompaths], 'sets': {name: inventory_set(name, sources) for name in set_names}, 'oracles': oracle_inventory(ROOT)}
    write_json(Path(args.out), result)
    for name, rec in result['sets'].items():
        status = 'OK' if rec['complete'] else 'MISSING'
        print(f"{name}: {status} ({rec['present_count']}/{rec['expected_count']} files present)")
        if rec['missing']:
            print('  missing: ' + ', '.join(rec['missing']))
        if rec['mismatches']:
            print('  mismatches: ' + ', '.join(rec['mismatches']))
    print(f'wrote {args.out}')
    if args.check and any((not rec['complete'] for rec in result['sets'].values())):
        return 2
    return 0
if __name__ == '__main__':
    raise SystemExit(main())
