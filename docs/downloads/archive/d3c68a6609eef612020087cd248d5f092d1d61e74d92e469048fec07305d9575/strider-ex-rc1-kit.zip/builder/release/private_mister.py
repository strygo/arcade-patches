"""Finalize private MiSTer deliveries; public builders must never call this."""
from __future__ import annotations
import argparse
import base64
from contextlib import contextmanager
from datetime import datetime
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import sys
import tempfile
import xml.etree.ElementTree as ET
import zipfile
from zoneinfo import ZoneInfo
sys.dont_write_bytecode = True
RECEIPT = 'private-mister.json'
REPO = Path(__file__).resolve().parent.parent
LEDGER = REPO / 'release/private_mister_builds.json'
if (REPO / '.git').exists():
    os.environ.setdefault('CAPCOM_MISTER_TEST_LEDGER', str(LEDGER))

def sha(data):
    return hashlib.sha256(data).hexdigest()

def checked_path(root, relative):
    p = PurePosixPath(relative)
    if not relative or p.is_absolute() or '..' in p.parts or ('\\' in relative):
        raise ValueError('Unsafe kit path: ' + relative)
    path = root / relative
    if not path.resolve().is_relative_to(root.resolve()):
        raise ValueError('Escaping kit path: ' + relative)
    return path

def inventory(root):
    return {p.relative_to(root).as_posix(): sha(p.read_bytes()) for p in sorted(root.rglob('*')) if p.is_file()}

def valid_id(value):
    if not re.fullmatch('\\d{6}-\\d{2}', value) or value.endswith('-00'):
        raise ValueError('Test ID must be YYMMDD-NN, with NN from 01 to 99')
    datetime.strptime(value[:6], '%y%m%d')
    return value

def allocate(project, identity, requested=None, ledger=None):
    """Durable global daily sequence, reused for an identical project/input set."""
    ledger = Path(ledger or os.environ.get('CAPCOM_MISTER_TEST_LEDGER', LEDGER)).expanduser()
    if not ledger.parent.is_dir():
        raise ValueError('Run the exporter from the checkout, or supply a ledger')
    lock = ledger.with_suffix('.lock')
    with lock.open('a') as handle:
        if os.name == 'nt':
            import msvcrt
            if handle.tell() == 0:
                handle.write('0')
                handle.flush()
            handle.seek(0)
            msvcrt.locking(handle.fileno(), msvcrt.LK_LOCK, 1)
        else:
            import fcntl
            fcntl.flock(handle, fcntl.LOCK_EX)
        records = json.loads(ledger.read_text()) if ledger.exists() else {'schema': 1, 'builds': {}}
        builds = records['builds']
        requested = requested or os.environ.get('CAPCOM_MISTER_TEST_ID')
        if requested:
            chosen = valid_id(requested)
        else:
            day = datetime.now(ZoneInfo('America/Los_Angeles')).strftime('%y%m%d')
            same = [k for k, v in builds.items() if k.startswith(day + '-') and v == {'project': project, 'source_sha256': identity}]
            if same:
                return same[0]
            number = max([int(k[-2:]) for k in builds if k.startswith(day + '-')] or [0]) + 1
            if number > 99:
                raise ValueError('Daily test ID sequence exhausted')
            chosen = f'{day}-{number:02d}'
        row = {'project': project, 'source_sha256': identity}
        if chosen in builds and builds[chosen] != row:
            raise ValueError('Test ID already belongs to different contents: ' + chosen)
        builds[chosen] = row
        temp = ledger.with_suffix('.tmp')
        temp.write_text(json.dumps(records, indent=2, sort_keys=True) + '\n')
        temp.replace(ledger)
        return chosen

def rom_roots(extra=()):
    roots = [Path(p).expanduser() for p in extra]
    roots.extend([REPO / 'roms', REPO / 'roms/mame0260'])
    if os.environ.get('CAPCOM_ARCADE_ROM_PATH'):
        roots.extend((Path(p).expanduser() for p in os.environ['CAPCOM_ARCADE_ROM_PATH'].split(os.pathsep)))
    return roots

def rewrite_json(value, replacements):
    if isinstance(value, str):
        return replacements.get(value, value)
    if isinstance(value, list):
        return [rewrite_json(v, replacements) for v in value]
    if isinstance(value, dict):
        return {replacements.get(k, k): rewrite_json(v, replacements) for k, v in value.items()}
    return value

def refresh_sizes(value, sizes):
    if isinstance(value, list):
        return [refresh_sizes(v, sizes) for v in value]
    if isinstance(value, dict):
        result = {k: refresh_sizes(v, sizes) for k, v in value.items()}
        if 'bytes' in result and result.get('sha256') in sizes:
            result['bytes'] = sizes[result['sha256']]
        return result
    return value

def finalize(root, project, *, build_id=None, rompaths=(), ledger=None):
    """Transform one qualified private kit in place, after producer checks."""
    root = Path(root).expanduser().resolve()
    if (root / RECEIPT).exists():
        record = verify(root)
        if project != record['project']:
            raise ValueError('Existing private delivery belongs to a different project')
        requested = build_id or os.environ.get('CAPCOM_MISTER_TEST_ID')
        if requested and requested != record['test_id']:
            raise ValueError('Existing private delivery has a different test ID')
        return record
    if len(project) > 64 or not re.fullmatch('[a-z0-9]+(?:-[a-z0-9]+)*', project):
        raise ValueError('Project must be a lowercase slug')
    original = inventory(root)
    card_roots = [p for p in (root, root / 'SD', root / 'mister') if (p / '_Arcade').is_dir()]
    if len(card_roots) != 1:
        raise ValueError('Expected exactly one MiSTer card tree')
    card = card_roots[0]
    mras = sorted([*(card / '_Arcade').rglob('*.mra'), *(card / '_Arcade').rglob('*.mgl')])
    if not mras:
        raise ValueError('Private export requires MRAs or MGL launchers')
    additions, mapping, modified, dependencies = ({}, {}, {}, {})
    zip_entries = {}
    roots = rom_roots(rompaths)
    trees = {p: ET.parse(p, parser=ET.XMLParser(target=ET.TreeBuilder(insert_comments=True))).getroot() for p in mras}
    for tree in trees.values():
        for node in tree.iter():
            if 'zip' not in node.attrib:
                continue
            for reference in node.get('zip').split('|'):
                name = PurePosixPath(reference).name
                if not name.lower().endswith('.zip') or '..' in PurePosixPath(reference).parts:
                    raise ValueError('Unsupported archive reference: ' + reference)
                candidates = [card / 'games' / reference.lstrip('/')] if reference.startswith('/') else [card / 'games/mame' / name, card / '_Arcade/mame' / name]
                candidates += [p / name if p.is_dir() else p for p in roots if p.is_dir() or p.name == name]
                for folder in roots:
                    if folder.is_dir() and reference.startswith('/'):
                        candidates.extend((folder / sub / reference.lstrip('/') for sub in ('games', 'SD/games', 'mister/games')))
                    if folder.is_dir():
                        candidates.extend((folder / sub / name for sub in ('games/mame', 'games/hbmame', '_Arcade/mame', 'mame', 'hbmame', 'SD/_Arcade/mame', 'SD/games/mame')))
                found = next((p for p in candidates if p.is_file()), None)
                if found is None:
                    continue
                body = found.read_bytes()
                with zipfile.ZipFile(found) as archive:
                    if archive.testzip() is not None:
                        raise ValueError('Corrupt archive: ' + reference)
                    if len(archive.namelist()) != len(set(archive.namelist())):
                        raise ValueError('Duplicate archive members: ' + reference)
                    members = {n: sha(archive.read(n)) for n in sorted(archive.namelist()) if not n.endswith('/')}
                    zip_entries[reference] = {i.filename: i.CRC for i in archive.infolist() if not i.is_dir()}
                key = reference
                if key in dependencies and dependencies[key]['sha256'] != sha(body):
                    raise ValueError('Ambiguous archive: ' + reference)
                dependencies[key] = {'name': name, 'sha256': sha(body), 'members': members}
                additions[key] = (found, body)

    def require_parts(node, inherited=()):
        refs = node.get('zip').split('|') if 'zip' in node.attrib else inherited
        if 'zip' in node.attrib and (not any((r in dependencies for r in refs))):
            raise ValueError('Missing private test dependency: ' + node.get('zip'))
        name = node.get('name') if node.tag == 'part' else None
        if name:
            crc = int(node.get('crc'), 16) if node.get('crc') else None
            available = [zip_entries[r] for r in refs if r in zip_entries]
            if not any((name in entries if crc is None else crc in entries.values() for entries in available)):
                raise ValueError('Missing private test ROM part: ' + name)
        for child in node:
            require_parts(child, refs)
    for tree in trees.values():
        for rom in tree.findall('rom'):
            require_parts(rom)
    mgl_files = {}
    for path, tree in trees.items():
        if path.suffix.lower() != '.mgl':
            continue
        for node in tree.findall('file'):
            reference = node.get('path', '')
            if not reference or '..' in PurePosixPath(reference).parts:
                raise ValueError('Unsafe MGL image reference')
            source = card / reference.removeprefix('/media/fat/') if reference.startswith('/media/fat/') else card / 'games/NG+' / reference
            if not source.is_file():
                raise ValueError('Missing NG+ test image: ' + reference)
            mgl_files[path, reference] = source
    identity = sha(json.dumps({'files': original, 'dependencies': dependencies, 'exporter_sha256': sha(Path(__file__).read_bytes())}, sort_keys=True).encode())
    test_id = allocate(project, identity, build_id, ledger)
    build_dir = f'{project}-{test_id}'
    rom_dir = f'games/test/{build_dir}'
    prefix = card.relative_to(root).as_posix()
    prefix = '' if prefix == '.' else prefix + '/'
    output, destinations = ({}, {})

    def put(relative, body):
        destination = prefix + relative
        if destination in output and output[destination] != body:
            raise ValueError('Conflicting private export destination: ' + destination)
        output[destination] = body
        return destination
    for reference, (source, body) in additions.items():
        name = dependencies[reference]['name']
        if name in destinations and destinations[name] != sha(body):
            name = Path(name).stem + '-' + sha(body)[:12] + '.zip'
        destinations[name] = sha(body)
        destination = put(rom_dir + '/' + name, body)
        dependencies[reference]['file'] = destination
        if source.is_relative_to(root):
            mapping[source.relative_to(root).as_posix()] = destination
    for source in mgl_files.values():
        old = source.relative_to(root).as_posix()
        mapping[old] = put(rom_dir + '/' + source.name, source.read_bytes())
    for path in sorted(card.rglob('*')):
        if not path.is_file() or path in trees:
            continue
        rel = path.relative_to(card).as_posix()
        if rel.startswith('games/') or rel.startswith('_Arcade/mame/'):
            old = path.relative_to(root).as_posix()
            if old not in mapping:
                destination = put(rom_dir + '/support/' + rel, path.read_bytes())
                mapping[old] = destination
    cores = sorted((card / '_Arcade').rglob('*.rbf'))
    bindings = {}
    for tree in trees.values():
        binding_path = tree.findtext('rbf') or ''
        binding = PurePosixPath(binding_path).name
        matches = [p for p in cores if re.fullmatch('(?:Arcade-)?' + re.escape(binding or '') + '(?:_.*)?\\.rbf', p.name, re.I)]
        directory = card / PurePosixPath(binding_path).parent if tree.tag == 'mistergamedescription' else card / '_Arcade/cores'
        matches = [p for p in matches if p.parent == directory]
        if not matches and binding.lower() not in ('jtcps1', 'jtcps15', 'jtcps2'):
            raise ValueError('Include the custom core selected by this test: ' + binding_path)
        if matches:
            source = max(matches, key=lambda p: p.name)
            new_binding = f'{binding}-test-{build_dir}'
            bindings[binding_path] = ('_Arcade/cores/' if tree.tag == 'mistergamedescription' else '') + new_binding
            destination = put('_Arcade/cores/' + new_binding + '.rbf', source.read_bytes())
            mapping[source.relative_to(root).as_posix()] = destination
    for source in cores:
        old = source.relative_to(root).as_posix()
        if old not in mapping:
            mapping[old] = put('_Arcade/cores/test-' + build_dir + '-' + source.name, source.read_bytes())
    names = set()
    for path, tree in trees.items():
        old = path.relative_to(root).as_posix()
        title = ' '.join(re.sub('[\\\\/:*?"<>|]', ' ', path.stem).split()).rstrip(' .')
        name = f'[{test_id}] {title}'
        if name.casefold() in names:
            qualifier = ' '.join(re.sub('[\\\\/:*?"<>|]', ' ', path.parent.name.lstrip('_')).split())
            name += ' [' + (qualifier or sha(old.encode())[:8]) + ']'
            if name.casefold() in names:
                name += ' [' + sha(old.encode())[:8] + ']'
        names.add(name.casefold())
        if len(name.encode()) > 180:
            raise ValueError('MRA name exceeds portable saved-state limit: ' + name)
        for node in tree.iter():
            if 'zip' in node.attrib:
                node.set('zip', '|'.join(('/' + dependencies[r]['file'].removeprefix(prefix + 'games/') for r in node.get('zip').split('|') if r in dependencies)))
        if path.suffix.lower() == '.mgl':
            for node in tree.findall('file'):
                source = mgl_files[path, node.get('path')]
                new = mapping[source.relative_to(root).as_posix()].removeprefix(prefix)
                node.set('path', '/media/fat/' + new)
        if tree.find('name') is not None:
            tree.find('name').text = f'[{test_id}] ' + (tree.findtext('name') or path.stem)
        if tree.findtext('rbf') in bindings:
            tree.find('rbf').text = bindings[tree.findtext('rbf')]
        ET.indent(tree)
        notices = b'\n'.join(re.findall(b'<!--.*?-->', path.read_bytes().split(b'<misterromdescription', 1)[0], re.S))
        body = notices + b'\n' + ET.tostring(tree, encoding='utf-8') + b'\n'
        mapping[old] = put('_Arcade/_Test/' + name + path.suffix.lower(), body)
        modified[old] = base64.b64encode(path.read_bytes()).decode()
    for entry in ('verify_kit.py', 'verify_pack.py', 'verify_update.py'):
        if entry not in original:
            continue
        modified[entry] = base64.b64encode((root / entry).read_bytes()).decode()
        output[entry] = f"#!/usr/bin/env python3\nfrom pathlib import Path\nimport runpy\nimport sys\nsys.dont_write_bytecode = True\nimport private_mister\nroot = Path(__file__).resolve().parent\nwith private_mister.qualified_view(root) as source:\n    for i, arg in enumerate(sys.argv[1:], 1):\n        if i > 1 and sys.argv[i - 1] in ('--pack', '--root', '--verify') and Path(arg).resolve() == root:\n            sys.argv[i] = str(source)\n    sys.path.insert(0, str(source))\n    runpy.run_path(str(source / {entry!r}), run_name='__main__')\n".encode()
    instructions = f'Private MiSTer test [{test_id}] — {project}\n\nCopy {prefix}_Arcade/ and {prefix}games/ to the SD card root, merging folders.\nOpen Arcade → Test; launch an entry beginning [{test_id}].\nTest ROM inputs are isolated. MRAs have separate NVRAM and DIP filenames; MGL saves follow the core. Hardware review remains separate.\nOlder installation paths in source qualification notes describe the producer layout.\nUse this installation instruction for this private export.\n'.encode()
    output['INSTALL-MISTER-TEST.txt'] = instructions
    for name in ('README.md', 'README.txt', 'readme.md'):
        if name in original:
            modified[name] = base64.b64encode((root / name).read_bytes()).decode()
            output[name] = instructions + b'\n--- Source qualification notes ---\n\n' + (root / name).read_bytes()
    put('games/mame/README-test-path.txt', b'This directory anchors MiSTer games/ lookup. Test ROMs are under games/test/.\n')
    output['private_mister.py'] = Path(__file__).read_bytes()
    if 'private_mister.py' in original:
        modified['private_mister.py'] = base64.b64encode((root / 'private_mister.py').read_bytes()).decode()
    replacements = dict(mapping)
    for old, new in mapping.items():
        replacements[original[old]] = sha(output[new])
        replacements[hashlib.md5((root / old).read_bytes()).hexdigest()] = hashlib.md5(output[new]).hexdigest()
    for old in modified:
        if old in output:
            replacements[original[old]] = sha(output[old])
    documents = {p.relative_to(root).as_posix(): (p.read_bytes(), json.loads(p.read_text())) for p in sorted(root.rglob('*.json')) if p.relative_to(root).as_posix() not in mapping}
    sizes = {sha(b): len(b) for b in output.values()}
    for _ in range(len(documents) + 2):
        changed = False
        for old, (raw, value) in documents.items():
            updated = refresh_sizes(rewrite_json(value, replacements), sizes)
            body = (json.dumps(updated, indent=2, sort_keys=True) + '\n').encode() if updated != value else raw
            if body != output.get(old, raw):
                changed = True
                modified[old] = base64.b64encode(raw).decode()
                output[old] = body
                replacements[original[old]] = sha(body)
                replacements[hashlib.md5(raw).hexdigest()] = hashlib.md5(body).hexdigest()
                sizes[sha(body)] = len(body)
        if not changed:
            break
    else:
        raise ValueError('Producer metadata hashes did not settle')
    for name in original:
        if Path(name).name.lower() in ('sha256sums', 'sha256sums.txt', 'checksums.sha256'):
            modified[name] = base64.b64encode((root / name).read_bytes()).decode()
            base = PurePosixPath(name).parent
            rows = {}
            for line in (root / name).read_text().splitlines():
                digest, relative = line.split('  ', 1)
                old = (base / relative).as_posix()
                new = mapping.get(old, old)
                rows[os.path.relpath(new, str(base))] = sha(output[new]) if new in output else original[old]
            output[name] = ''.join((f'{h}  {p}\n' for p, h in sorted(rows.items()))).encode()
    audits = {}
    if (REPO / 'extraction/cps2_code_guard.py').is_file():
        import sys
        sys.path.insert(0, str(REPO / 'extraction'))
        from cps2_code_guard import check_archive
        cache = {}
        for reference, (source, _) in additions.items():
            result = check_archive(source, cache=cache)
            if result is not None:
                audits[reference] = result
    sd_manifest = {'schema': 'private-mister-sd/1', 'project': project, 'test_id': test_id, 'source_sha256': identity, 'hardware_review_granted': False, 'launchers': {new.removeprefix(prefix): sha(output[new]) for old, new in mapping.items() if old.endswith(('.mra', '.mgl'))}, 'inputs': {ref: {**row, 'file': row['file'].removeprefix(prefix)} for ref, row in dependencies.items()}, 'images': {mapping[p.relative_to(root).as_posix()].removeprefix(prefix): original[p.relative_to(root).as_posix()] for p in mgl_files.values()}, 'cores': {name.removeprefix(prefix): sha(body) for name, body in output.items() if name.endswith('.rbf')}, 'cps2_code_guard': audits}
    put(rom_dir + '/manifest.json', (json.dumps(sd_manifest, indent=2, sort_keys=True) + '\n').encode())
    for old in mapping:
        (root / old).unlink()
    for name, body in output.items():
        path = checked_path(root, name)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(body)
    for directory in sorted(card.rglob('*'), reverse=True):
        if directory.is_dir() and (not any(directory.iterdir())):
            directory.rmdir()
    report = {'schema': 'private-mister/1', 'project': project, 'test_id': test_id, 'source_sha256': identity, 'card_prefix': prefix, 'mapping': mapping, 'original_files': original, 'original_metadata': modified, 'dependencies': dependencies, 'bindings': bindings, 'cps2_code_guard': audits, 'files': inventory(root), 'hardware_review_granted': False}
    (root / RECEIPT).write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
    verify(root)
    return report

def verify(root):
    root = Path(root)
    record = json.loads((root / RECEIPT).read_text())
    if record['schema'] != 'private-mister/1':
        raise ValueError('Unknown private MiSTer schema')
    valid_id(record['test_id'])
    actual = inventory(root)
    actual.pop(RECEIPT)
    for name in list(actual):
        if Path(name).name == 'TEST-RESULTS.txt':
            actual[name] = record['files'].get(name)
    if actual != record['files']:
        raise ValueError('Private MiSTer file changed or missing')
    prefix = record['card_prefix']
    for name in actual:
        checked_path(root, name)
        if name.endswith(('.mra', '.mgl')) and name.startswith(prefix + '_Arcade/'):
            if not name.startswith(prefix + '_Arcade/_Test/[' + record['test_id'] + '] '):
                raise ValueError('MRA outside isolated test menu')
            tree = ET.parse(root / name).getroot()
            for node in tree.findall('file'):
                ref = node.get('path', '')
                expected = '/media/fat/games/test/' + record['project'] + '-' + record['test_id'] + '/'
                if not ref.startswith(expected) or not checked_path(root, prefix + ref.removeprefix('/media/fat/')).is_file():
                    raise ValueError('Unisolated or missing MGL test image')
            for node in tree.iter():
                if 'zip' in node.attrib:
                    for ref in node.get('zip').split('|'):
                        if not ref.startswith('/test/' + record['project'] + '-' + record['test_id'] + '/'):
                            raise ValueError('Unisolated test ROM reference')
                        if not checked_path(root, prefix + 'games' + ref).is_file():
                            raise ValueError('Missing test ROM dependency')
    for old, new in record['mapping'].items():
        if not old.endswith(('.mra', '.mgl')):
            continue
        original = base64.b64decode(record['original_metadata'][old])
        if sha(original) != record['original_files'][old]:
            raise ValueError('Original descriptor identity differs')
        before = ET.fromstring(original)
        after = ET.parse(checked_path(root, new)).getroot()
        left, right = (list(before.iter()), list(after.iter()))
        if len(left) != len(right):
            raise ValueError('Test descriptor structure changed')
        for a, b in zip(left, right):
            attrs = dict(a.attrib)
            if 'zip' in attrs:
                attrs['zip'] = '|'.join(('/' + record['dependencies'][ref]['file'].removeprefix(prefix + 'games/') for ref in attrs['zip'].split('|') if ref in record['dependencies']))
            if a.tag == 'file' and before.tag == 'mistergamedescription':
                reference = attrs['path']
                source = prefix + reference.removeprefix('/media/fat/') if reference.startswith('/media/fat/') else prefix + 'games/NG+/' + reference
                attrs['path'] = '/media/fat/' + record['mapping'][source].removeprefix(prefix)
            text = (a.text or '').strip()
            if a.tag == 'name':
                text = '[' + record['test_id'] + '] ' + (text or Path(old).stem)
            if a.tag == 'rbf':
                text = record['bindings'].get(text, text)
            if a.tag != b.tag or attrs != b.attrib or text != (b.text or '').strip():
                raise ValueError('ROM assembly/defaults or core binding changed during export')
    return record

@contextmanager
def qualified_view(root):
    """Restore producer paths/metadata for its unchanged independent verifier."""
    root = Path(root)
    record = verify(root)
    with tempfile.TemporaryDirectory(prefix='private-mister-verify-', dir=root.parent) as tmp:
        view = Path(tmp) / (root.name or 'kit')
        view.mkdir()
        for old, digest in record['original_files'].items():
            destination = checked_path(view, old)
            destination.parent.mkdir(parents=True, exist_ok=True)
            if old in record['original_metadata']:
                destination.write_bytes(base64.b64decode(record['original_metadata'][old]))
            else:
                source = checked_path(root, record['mapping'].get(old, old))
                try:
                    os.link(source, destination)
                except OSError:
                    shutil.copyfile(source, destination)
            if Path(old).name != 'TEST-RESULTS.txt' and sha(destination.read_bytes()) != digest:
                raise ValueError('Producer reconstruction differs: ' + old)
        yield view

def archive(root, target):
    """Deterministic ZIP of a finalized delivery."""
    if Path(target).resolve().is_relative_to(Path(root).resolve()):
        raise ValueError('Archive target must be outside the kit tree')
    verify(root)
    with zipfile.ZipFile(target, 'w', zipfile.ZIP_DEFLATED) as output:
        for path in sorted(Path(root).rglob('*')):
            if path.is_file():
                row = zipfile.ZipInfo(path.relative_to(root).as_posix(), (1980, 1, 1, 0, 0, 0))
                row.compress_type = zipfile.ZIP_DEFLATED
                row.external_attr = 420 << 16
                output.writestr(row, path.read_bytes())

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--root', type=Path)
    ap.add_argument('--project')
    ap.add_argument('--test-id')
    ap.add_argument('--ledger', type=Path)
    ap.add_argument('--rompath', type=Path, action='append', default=[])
    ap.add_argument('--verify', type=Path)
    ap.add_argument('--zip', type=Path)
    ap.add_argument('--self-test', action='store_true')
    args = ap.parse_args()
    if args.self_test:
        import unittest
        suite = unittest.defaultTestLoader.discover(str(Path(__file__).parent), pattern='test_private_mister.py')
        if not unittest.TextTestRunner().run(suite).wasSuccessful():
            raise SystemExit(1)
    elif args.verify:
        verify(args.verify)
    else:
        if not args.root or not args.project:
            ap.error('--root and --project required')
        report = finalize(args.root, args.project, build_id=args.test_id, rompaths=args.rompath, ledger=args.ledger)
        if args.zip:
            archive(args.root, args.zip)
        print('Private MiSTer test [' + report['test_id'] + '] ready: ' + str(args.root))
if __name__ == '__main__':
    main()
