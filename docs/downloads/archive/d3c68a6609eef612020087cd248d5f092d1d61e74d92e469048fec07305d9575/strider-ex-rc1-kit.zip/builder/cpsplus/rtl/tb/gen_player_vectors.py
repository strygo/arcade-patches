"""tb_player vector generator."""
from __future__ import annotations
import argparse
import array
import struct
import sys
from math import sin, pi
from pathlib import Path
PROJECT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(PROJECT))
from pack import adxcodec, xfade
from pack.format import PackReader
from pack.audition import render
TRK_ADDR = 64
UNITY24 = 8388608
RESTORE_FRAMES = 8
XFADE_N_TB = 256

def vol_q14(tgain: int, kgain: int) -> int:
    return (tgain * kgain << 14) // 16129

def tgt_q15(t: int) -> int:
    return 32768 if t == 127 else t * 258

def law_frames(law: int, c1: int, c2: int, arg: int) -> int:
    q = c1 // (arg if arg else 1)
    if law == 2:
        return min(q, 65535) * c2
    if law == 3:
        return c2 + q
    return q if q else 1
DB_LUT = [round(32768 * 10 ** (-0.75 * i / 20)) for i in range(64)]

def db_step(frames: int) -> int:
    return (63 << 16) // (frames if frames else 1)

def db_level(start24: int, step: int, ticks: int) -> int:
    att = ticks * step >> 16
    return start24 * DB_LUT[att] >> 15

def fade_step(lvl24: int, t24: int, frames: int) -> int:
    return abs(lvl24 - t24) // (frames if frames else 1)

def steady_sample(amp: int, vq14: int, lvl_q15: int) -> int:
    total = vq14 * lvl_q15 >> 15
    return amp * total >> 14

def pcm_to_words(pcm: bytes, channels: int, vq14: int=16384) -> list[int]:
    a = array.array('h')
    a.frombytes(pcm)
    n = len(a) // channels
    out = []
    for i in range(n):
        l = a[i * channels] * vq14 >> 14
        r = a[i * channels + 1] * vq14 >> 14 if channels == 2 else l
        out.append((r & 65535) << 16 | l & 65535)
    return out

def splice(pcm: bytes, channels: int, start_smp: int, end_smp: int, loops: int=2) -> bytes:
    fb = 2 * channels
    return pcm[:end_smp * fb] + pcm[start_smp * fb:end_smp * fb] * loops

def sine_pcm(n: int, rate: int, freq: float, amp: int, ch: int) -> bytes:
    a = array.array('h')
    for i in range(n):
        v = int(amp * sin(2 * pi * freq * i / rate))
        a.append(v)
        if ch == 2:
            a.append(-v)
    return a.tobytes()

def write_vec(out: Path, mem: bytes | None, words: list[int] | None, plus: dict):
    out.mkdir(parents=True, exist_ok=True)
    if mem is not None:
        with open(out / 'mem.hex', 'w') as f:
            f.write('\n'.join((f'{b:02x}' for b in mem)) + '\n')
    if words is not None:
        with open(out / 'golden.hex', 'w') as f:
            f.write('\n'.join((f'{w:08x}' for w in words)) + '\n')
    (out / 'plusargs.txt').write_text(' '.join((f'+{k}={v}' for k, v in plus.items())) + '\n')

def base_plus(out: Path, *, length: int, lstart: int, lend: int, stereo: int, codec: int, c1: int=0, c2: int=0, gain: int=127, tgain: int=127, ngold: int=0, mem_dir: Path | None=None, **extra) -> dict:
    d = mem_dir if mem_dir is not None else out
    plus = {'MEM': d / 'mem.hex', 'GOLD': d / 'golden.hex', 'NGOLD': ngold, 'TRK_ADDR': TRK_ADDR, 'TRK_LEN': length, 'LSTART': lstart, 'LEND': lend, 'STEREO': stereo, 'CODEC': codec, 'C1': c1 & 65535, 'C2': c2 & 65535, 'GAIN': gain, 'TGAIN': tgain}
    plus.update(extra)
    return plus

def mode_loop(args, out: Path):
    rd = PackReader(args.pack)
    try:
        m = rd.tracks[args.track]
        data = rd.read_track(args.track)
        pcm, _ = render(rd, args.track, loops=2)
    finally:
        rd.close()
    words = pcm_to_words(pcm, m.channels)
    mem = bytes(TRK_ADDR) + data
    plus = base_plus(out, length=m.data_length, lstart=m.loop_start_byte, lend=m.loop_end_byte, stereo=m.channels - 1, codec=0, c1=m.coef1, c2=m.coef2, ngold=len(words), EXP_VOLQ14=16384)
    write_vec(out, mem, words, plus)
    print(f'[loop] track {args.track} ({m.name}): {len(words)} golden pairs (intro {m.loop_end_byte // (18 * m.channels) * 32} + 2 loop passes)')

def mode_restart(args, out: Path, loop_dir: Path):
    rd = PackReader(args.pack)
    m = rd.tracks[args.track]
    rd.close()
    plus = base_plus(out, length=m.data_length, lstart=m.loop_start_byte, lend=m.loop_end_byte, stereo=m.channels - 1, codec=0, c1=m.coef1, c2=m.coef2, ngold=40000, mem_dir=loop_dir, RESTART_AT=800, RESTART_DOUBLE=1)
    write_vec(out, None, None, plus)
    print('[restart] restart at 800 pairs (~1 frame) + racing double start, 40000 pairs compared from sample 0')

def mode_stop(args, out: Path, loop_dir: Path):
    rd = PackReader(args.pack)
    m = rd.tracks[args.track]
    rd.close()
    plus = base_plus(out, length=m.data_length, lstart=m.loop_start_byte, lend=m.loop_end_byte, stereo=m.channels - 1, codec=0, c1=m.coef1, c2=m.coef2, ngold=5000, mem_dir=loop_dir, STOP_AT=5000)
    write_vec(out, None, None, plus)
    print('[stop] stop at 5000 pairs, silence within one tick expected')

def mode_underrun(args, out: Path, loop_dir: Path):
    rd = PackReader(args.pack)
    m = rd.tracks[args.track]
    rd.close()
    plus = base_plus(out, length=m.data_length, lstart=m.loop_start_byte, lend=m.loop_end_byte, stereo=m.channels - 1, codec=0, c1=m.coef1, c2=m.coef2, ngold=40000, mem_dir=loop_dir, STALL_AT=2000, STALL_EVERY=500, STALL_N=64, STALL_LEN=3000)
    write_vec(out, None, None, plus)
    print('[underrun] 64 memory stalls (3000..3063 clk) from 2000 pairs, 40000 pairs compared across the refills')

def mode_monoadx(args, out: Path):
    rate, n = (32000, 96000)
    pcm = sine_pcm(n, rate, 700.0, 11000, 1)
    stream = adxcodec.encode(pcm, 1, rate)
    c1, c2 = adxcodec.calc_coeffs(500, rate)
    assert len(stream) == 3000 * 18
    lstart_b, lend_b = (500 * 18, 2500 * 18)
    start_s, end_s = (500 * 32, 2500 * 32)
    dec = adxcodec.py_decode(stream, 1, c1, c2)
    ff = array.array('h')
    ff.frombytes(adxcodec.decode(stream, 1, rate))
    assert list(ff) == dec[0], 'py_decode vs ffmpeg divergence'
    full = array.array('h', dec[0]).tobytes()
    gold = splice(full, 1, start_s, end_s, loops=2)
    words = pcm_to_words(gold, 1)
    mem = bytes(TRK_ADDR) + stream
    plus = base_plus(out, length=len(stream), lstart=lstart_b, lend=lend_b, stereo=0, codec=0, c1=c1, c2=c2, ngold=len(words))
    write_vec(out, mem, words, plus)
    print(f'[monoadx] mono ADX loop (end mid-stream): {len(words)} pairs')

def chirp_pcm(n: int, rate: int, f0: float, f1: float, amp: int, ch: int) -> bytes:
    """Frequency sweep f0->f1 (phase-continuous) so head and tail material"""
    a = array.array('h')
    ph = 0.0
    for i in range(n):
        f = f0 + (f1 - f0) * i / n
        ph += 2 * pi * f / rate
        v = int(amp * sin(ph))
        a.append(v)
        if ch == 2:
            a.append(int(0.6 * amp * sin(1.5 * ph)))
    return a.tobytes()

def mode_xfade(args, out: Path):
    """Synthetic stereo ADX crossfade track (loop-with-tail).  Golden = the"""
    rate, ch = (48000, 2)
    n = args.xfade_n
    ls = 1024
    le = ls + (max(3 * n, 5120) + 31) // 32 * 32
    n_src = le + n + 2048
    pcm = chirp_pcm(n_src, rate, 200.0, 5000.0, 12000, ch)
    stream = adxcodec.encode(pcm, ch, rate)
    c1, c2 = adxcodec.calc_coeffs(500, rate)
    fg = 18 * ch
    ls_b = adxcodec.samples_to_stream_byte(ls, ch)
    le_b = adxcodec.samples_to_stream_byte(le, ch)
    tail_b = adxcodec.samples_to_stream_byte(n, ch)
    end_b = le_b + tail_b
    stored = stream[:end_b]
    assert len(stored) == end_b, 'source too short for the tail'
    dec = adxcodec.decode(stored, ch, rate, total_samples=end_b // fg * 32)
    a = array.array('h')
    a.frombytes(dec)
    pairs = [(a[i * ch], a[i * ch + 1]) for i in range(len(a) // ch)]
    lut = xfade.make_lut(n)
    out_pairs = xfade.render(pairs, ls, le, n, loops=2, lut=lut)
    words = [(r & 65535) << 16 | l & 65535 for l, r in out_pairs]
    xfade.write_lut_hex(n, out / 'xf_lut.hex')
    mem = bytes(TRK_ADDR) + stored
    plus = base_plus(out, length=len(stored), lstart=ls_b, lend=le_b, stereo=1, codec=0, c1=c1, c2=c2, ngold=len(words), EXP_VOLQ14=16384, XFEN=1, LSTART_SMP=ls, LEND_SMP=le, LUT=out / 'xf_lut.hex')
    write_vec(out, mem, words, plus)
    print(f'[xfade] stereo ADX loop-with-tail crossfade N={n}: {len(words)} golden pairs (intro {le} + 2 loop passes), tail {tail_b} B past loop_end')

def mode_xfcnt(args, out: Path):
    """Finite-count crossfade track (the ffight INTRO shape): stereo ADX,"""
    rate, ch = (48000, 2)
    n = args.xfade_n
    ls = 1024
    le = ls + (max(3 * n, 5120) + 31) // 32 * 32
    outro = 4096
    n_src = le + n + outro
    pcm = chirp_pcm(n_src, rate, 200.0, 5000.0, 12000, ch)
    stream = adxcodec.encode(pcm, ch, rate)
    c1, c2 = adxcodec.calc_coeffs(500, rate)
    ls_b = adxcodec.samples_to_stream_byte(ls, ch)
    le_b = adxcodec.samples_to_stream_byte(le, ch)
    total = len(stream) // (18 * ch) * 32
    dec = adxcodec.decode(stream, ch, rate, total_samples=total)
    a = array.array('h')
    a.frombytes(dec)
    pairs = [(a[i * ch], a[i * ch + 1]) for i in range(len(a) // ch)]
    lut = xfade.make_lut(n)
    out_pairs = xfade.render(pairs, ls, le, n, loops=0, lut=lut) + pairs[ls + n:]
    words = [(r & 65535) << 16 | l & 65535 for l, r in out_pairs]
    xfade.write_lut_hex(n, out / 'xf_lut.hex')
    mem = bytes(TRK_ADDR) + stream
    plus = base_plus(out, length=len(stream), lstart=ls_b, lend=le_b, stereo=1, codec=0, c1=c1, c2=c2, ngold=len(words), EXP_VOLQ14=16384, XFEN=1, LSTART_SMP=ls, LEND_SMP=le, LCNT=1, LUT=out / 'xf_lut.hex')
    write_vec(out, mem, words, plus)
    print(f'[xfcnt] finite crossfade count=1: {len(words)} golden pairs (intro {le} + 1 blended wrap + play-through outro)')

def mode_hccnt(args, out: Path):
    """Finite-count hard-cut track (the ffight ENDING shape): stereo PCM,"""
    rate, n, ch = (32000, 40000, 2)
    pcm = sine_pcm(n, rate, 500.0, 13000, ch)
    ls, le = (8000, 28000)
    gold = splice(pcm, ch, ls, le, loops=3) + pcm[le * 2 * ch:]
    words = pcm_to_words(gold, ch)
    mem = bytes(TRK_ADDR) + pcm
    plus = base_plus(out, length=len(pcm), lstart=ls * 2 * ch, lend=le * 2 * ch, stereo=1, codec=1, ngold=len(words), LCNT=3, EXPECT_END=1, TICK=12)
    write_vec(out, mem, words, plus)
    print(f'[hccnt] finite hard-cut count=3: {len(words)} pairs (3 wraps + outro, track_done at the last sample)')

def mode_pcm(args, out: Path):
    rate, n, ch = (32000, 32000, 2)
    tgain, kgain = (64, 127)
    pcm = sine_pcm(n, rate, 500.0, 13000, ch)
    lstart_b, lend_b = (8000 * 4, 28000 * 4)
    gold = splice(pcm, ch, 8000, 28000, loops=2)
    vq = vol_q14(tgain, kgain)
    words = pcm_to_words(gold, ch, vq)
    mem = bytes(TRK_ADDR) + pcm
    plus = base_plus(out, length=len(pcm), lstart=lstart_b, lend=lend_b, stereo=1, codec=1, gain=kgain, tgain=tgain, ngold=len(words), EXP_VOLQ14=vq, TICK=12)
    write_vec(out, mem, words, plus)
    print(f'[pcm] stereo PCM loop, gain 0x{tgain:02x}x0x{kgain:02x} (vol_q14={vq}): {len(words)} pairs')

def mode_pcm_mono(args, out: Path):
    rate, n = (32000, 16000)
    pcm = sine_pcm(n, rate, 350.0, 9000, 1)
    words = pcm_to_words(pcm, 1)
    mem = bytes(TRK_ADDR) + pcm
    plus = base_plus(out, length=len(pcm), lstart=0, lend=0, stereo=0, codec=1, ngold=len(words), EXPECT_END=1, END_MIN=n, END_MAX=n)
    write_vec(out, mem, words, plus)
    print(f'[pcm_mono] one-shot mono PCM: {len(words)} pairs, track_done at {n}')

def _dc_track(amp: int, samples: int) -> bytes:
    return struct.pack('<h', amp) * 2 * samples

def mode_fade1(args, out: Path):
    amp, n = (16000, 48000)
    law, c1, c2 = (1, 65535, 0)
    pcm = _dc_track(amp, n)
    words = pcm_to_words(pcm[:2000 * 4], 2)
    mem = bytes(TRK_ADDR) + pcm
    lvl = UNITY24
    ev = {}
    t1 = tgt_q15(64) << 8
    f1 = law_frames(law, c1, c2, 2048)
    ev.update(F1_AT=2000, F1_TGT=64, F1_ARG=2048, F1_EXP_FRAMES=f1, F1_EXP_STEP=fade_step(lvl, t1, f1), F1_EXP_TGT=t1, F1_CHK_SAMPLE=1, F1_EXP_SAMPLE=steady_sample(amp, 16384, t1 >> 8) & 65535)
    lvl = t1
    ev.update(F2_AT=8000, F2_RESTORE=1, F2_EXP_FRAMES=RESTORE_FRAMES, F2_EXP_STEP=fade_step(lvl, UNITY24, RESTORE_FRAMES), F2_EXP_TGT=UNITY24, F2_CHK_SAMPLE=1, F2_EXP_SAMPLE=amp)
    lvl = UNITY24
    f3 = law_frames(law, c1, c2, 768)
    ev.update(F3_AT=14000, F3_TGT=0, F3_ARG=768, F3_EXP_FRAMES=f3, F3_EXP_STEP=fade_step(lvl, 0, f3), F3_EXP_TGT=0, F3_STOP0=1)
    plus = base_plus(out, length=len(pcm), lstart=0, lend=len(pcm), stereo=1, codec=1, ngold=2000, LAW=law, CONST1=c1, CONST2=c2, EXP_VOLQ14=16384, EXPECT_END=1, END_MIN=22300, END_MAX=22800, TICK=12, **ev)
    write_vec(out, mem, words, plus)
    print(f"[fade1] Anthology law: 31-frame fade-keep, restore, 85-frame fade-out w/ auto-stop (steps {ev['F1_EXP_STEP']}/{ev['F2_EXP_STEP']}/{ev['F3_EXP_STEP']})")

def mode_fadein(args, out: Path):
    """The arcade dramatic finish, replayed: a verb-4 fade to SILENCE, then the"""
    amp, n = (16000, 48000)
    law, c1, c2 = (1, 65535, 0)
    pcm = _dc_track(amp, n)
    words = pcm_to_words(pcm[:2000 * 4], 2)
    mem = bytes(TRK_ADDR) + pcm
    ev = {}
    f1 = law_frames(law, c1, c2, 8192)
    ev.update(F1_AT=2000, F1_TGT=0, F1_ARG=8192, F1_EXP_FRAMES=f1, F1_EXP_STEP=fade_step(UNITY24, 0, f1), F1_EXP_TGT=0, F1_CHK_SAMPLE=1, F1_EXP_SAMPLE=0)
    ev.update(F2_AT=8000, F2_TGT=127, F2_ARG=512, F2_EXP_FRAMES=law_frames(law, c1, c2, 512), F2_EXP_STEP=fade_step(0, UNITY24, law_frames(law, c1, c2, 512)), F2_EXP_TGT=UNITY24, F2_CHK_SAMPLE=1, F2_EXP_SAMPLE=amp)
    plus = base_plus(out, length=len(pcm), lstart=0, lend=len(pcm), stereo=1, codec=1, ngold=2000, LAW=law, CONST1=c1, CONST2=c2, EXP_VOLQ14=16384, EXPECT_NO_END=1, TICK=12, **ev)
    write_vec(out, mem, words, plus)
    print(f"[fadein] fade_keep to silence ({ev['F1_EXP_FRAMES']} frames) then back to unity ({ev['F2_EXP_FRAMES']} frames), track kept running")

def mode_fade2(args, out: Path):
    amp, n = (16000, 20000)
    law, c1, c2 = (2, 1092, 60)
    pcm = _dc_track(amp, n)
    words = pcm_to_words(pcm[:1000 * 4], 2)
    mem = bytes(TRK_ADDR) + pcm
    lvl = UNITY24
    ev = {}
    t1 = tgt_q15(32) << 8
    f1 = law_frames(law, c1, c2, 1092)
    ev.update(F1_AT=1000, F1_TGT=32, F1_ARG=1092, F1_EXP_FRAMES=f1, F1_EXP_STEP=fade_step(lvl, t1, f1), F1_EXP_TGT=t1, F1_CHK_SAMPLE=1, F1_EXP_SAMPLE=steady_sample(amp, 16384, t1 >> 8) & 65535)
    lvl = t1
    t2 = tgt_q15(64) << 8
    f2 = law_frames(law, c1, c2, 1092)
    ev.update(F2_AT=8000, F2_TGT=64, F2_ARG=1092, F2_LOOPOFF=1, F2_STOP0=1, F2_EXP_FRAMES=f2, F2_EXP_STEP=fade_step(lvl, t2, f2), F2_EXP_TGT=t2, F2_CHK_SAMPLE=1, F2_EXP_SAMPLE=steady_sample(amp, 16384, t2 >> 8) & 65535)
    plus = base_plus(out, length=len(pcm), lstart=4000 * 4, lend=len(pcm), stereo=1, codec=1, ngold=1000, LAW=law, CONST1=c1, CONST2=c2, EXP_VOLQ14=16384, EXPECT_END=1, END_MIN=n, END_MAX=n, **ev)
    write_vec(out, mem, words, plus)
    print(f'[fade2] HSF2 law: 60-frame fades (down then up w/ loop-off), track ends at loop_end sample {n}')

def mode_fade3(args, out: Path):
    """Neo Geo MAKOTO law (3): frames = 59 + 5860/speed, dB-linear ladder,"""
    amp, n = (16000, 48000)
    law, c1, c2 = (3, 5860, 59)
    pcm = _dc_track(amp, n)
    words = pcm_to_words(pcm[:2000 * 4], 2)
    mem = bytes(TRK_ADDR) + pcm
    ev = {}
    f1 = law_frames(law, c1, c2, 160)
    s1 = db_step(f1)
    ev.update(F1_AT=2000, F1_TGT=0, F1_ARG=160, F1_LOOPOFF=1, F1_STOP0=1, F1_EXP_FRAMES=f1, F1_EXP_STEP=s1, F1_EXP_TGT=0, F1_NOWAIT=1)
    k = 40
    ev.update(F2_AT=4000, F2_TGT=0, F2_ARG=32, F2_LOOPOFF=1, F2_STOP0=1, F2_EXP_FRAMES=f1, F2_EXP_STEP=s1, F2_EXP_TGT=0, F2_MID_LEFT=f1 - k, F2_MID_LVL=db_level(UNITY24, s1, k))
    plus = base_plus(out, length=len(pcm), lstart=0, lend=len(pcm), stereo=1, codec=1, ngold=2000, LAW=law, CONST1=c1, CONST2=c2, EXP_VOLQ14=16384, EXPECT_END=1, END_MIN=11300, END_MAX=11800, TICK=12, **ev)
    write_vec(out, mem, words, plus)
    print(f"[fade3] NG MAKOTO law: 95-frame dB ladder (index step {s1}), repeat ignored, level after {k} ticks = {ev['F2_MID_LVL']}, auto-stop")
MODES = {'loop': mode_loop, 'monoadx': mode_monoadx, 'pcm': mode_pcm, 'pcm_mono': mode_pcm_mono, 'fade1': mode_fade1, 'fade2': mode_fade2, 'fade3': mode_fade3, 'fadein': mode_fadein, 'xfade': mode_xfade, 'xfcnt': mode_xfcnt, 'hccnt': mode_hccnt}

def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--mode', required=True, choices=list(MODES) + ['restart', 'stop', 'underrun'])
    ap.add_argument('--pack', default=str(PROJECT / 'packs' / 'ssf2_arrange.cpk'))
    ap.add_argument('--track', type=int, default=54)
    ap.add_argument('--xfade-n', type=int, default=XFADE_N_TB, help='crossfade length for the xfade mode (== tb XFADE_N)')
    ap.add_argument('--out', required=True)
    ap.add_argument('--loop-dir', default='', help='restart/stop/underrun: dir holding the `loop` mode vectors')
    args = ap.parse_args()
    out = Path(args.out).resolve()
    if args.mode in ('restart', 'stop', 'underrun'):
        if not args.loop_dir:
            raise SystemExit('--loop-dir required for restart/stop/underrun')
        loop_dir = Path(args.loop_dir).resolve()
        if not (loop_dir / 'mem.hex').exists():
            raise SystemExit(f'generate `loop` vectors first ({loop_dir})')
        {'restart': mode_restart, 'stop': mode_stop, 'underrun': mode_underrun}[args.mode](args, out, loop_dir)
    else:
        MODES[args.mode](args, out)
    return 0
if __name__ == '__main__':
    raise SystemExit(main())
