"""Vector generator for tb_cps1_tap.v (cpsplus_cps1_tap RTL acceptance)."""
from __future__ import annotations
import argparse
import json
import sys
from pathlib import Path
RTL_DIR = Path(__file__).resolve().parents[1]
CPSPLUS = RTL_DIR.parent
sys.path.insert(0, str(CPSPLUS))
from pack.format import TriggerRow, VERB_PLAY, VERB_STOP, VERB_NONE
from pack import protocols as P
TRIG_ROWS = 256
CFG_LINES = 8 + 64
IDLE = 255

class Cps1Tables:
    """sf2 protocol descriptor + 256-row trigger table + control map."""

    def __init__(self, proto, triggers, mode=1):
        self.p = proto
        self.triggers = triggers
        self.mode = mode
        self.idle = proto.handshake_ready
        self.ctrl_start = proto.control_region_start
        self.ctrl_dflt = proto.control_default_verb
        self.ctrl_verbs = dict(proto.control_verbs)

    def classify(self, val):
        """-> (verb, track, gain, sup, is_ctrl)."""
        if val >= self.ctrl_start:
            return (self.ctrl_verbs.get(val, self.ctrl_dflt), 0, 0, 0, 1)
        r = self.triggers[val]
        return (r.verb, r.track, r.gain, r.suppress, 0)

    def sub_level(self, val):
        verb, _t, _g, sup, ctrl = self.classify(val)
        en = bool(self.mode & 1)
        nogate = bool(self.mode & 4)
        return 1 if en and (not nogate) and sup and (not ctrl) else 0

    def cfg_words(self):
        p = self.p
        w = [(0, p.latch_page & 65535), (1, p.latch_page >> 16 & 255), (2, p.off_cmd_lo << 8 | p.off_cmd_hi), (3, p.off_arg_lo << 8 | p.off_arg_hi), (4, p.off_handshake << 8 | p.off_arg_byte), (5, p.handshake_ready << 8 | p.handshake_pending), (6, p.control_region_start), (7, self.mode & 7 | (self.ctrl_dflt & 7) << 4)]
        entries = sorted(self.ctrl_verbs.items())
        assert len(entries) <= 32, 'control map overflow'
        for i in range(32):
            cmd, vb = entries[i] if i < len(entries) else (0, 0)
            w.append((64 + 2 * i, cmd))
            w.append((65 + 2 * i, vb))
        assert len(w) == CFG_LINES
        return w

    def trig_words(self):
        return [int.from_bytes(r.pack(), 'little') for r in self.triggers]

def synthetic_triggers():
    """A synthetic sf2 trigger table: every verified music command is a"""
    trig = [TriggerRow() for _ in range(TRIG_ROWS)]
    for i, cmd in enumerate(sorted(P.SF2_MUSIC_COMMANDS)):
        trig[cmd] = TriggerRow(verb=VERB_PLAY, track=i, gain=96, suppress=1)
    trig[15] = TriggerRow(verb=VERB_STOP, track=0, gain=0, suppress=1)
    return trig

class Run:

    def __init__(self, tables: Cps1Tables):
        self.t = tables
        self.stim = []
        self.gold = []
        self.last = IDLE
        self.subs = 0

    def drive(self, frame, val):
        t = self.t
        sub = t.sub_level(val)
        self.subs += sub
        self.stim.append((frame & 1048575) << 20 | (sub & 1) << 8 | val & 255)
        if val != self.last and t.mode & 1:
            verb, track, gain, sup, ctrl = t.classify(val)
            if verb != VERB_NONE:
                gsup = 1 if sup and (not t.mode & 4) else 0
                self.gold.append((frame & 1048575) << 60 | (verb & 15) << 56 | (track & 4095) << 44 | (gain & 255) << 36 | (ctrl & 1) << 1 | gsup & 1)
        self.last = val

    def dump(self, outdir: Path, name: str):
        outdir.mkdir(parents=True, exist_ok=True)
        p = {}
        for kind, data, width in (('cfg', [a << 16 | d for a, d in self.t.cfg_words()], 6), ('trig', self.t.trig_words(), 8), ('stim', self.stim, 10), ('gold', self.gold, 20)):
            f = outdir / f'{name}_{kind}.hex'
            f.write_text(''.join((f'{v:0{width}x}\n' for v in data)))
            p[kind] = f
        return p

def build_trace(mode=1) -> Run:
    proto = P.get_protocol('sf2')
    tab = Cps1Tables(proto, synthetic_triggers(), mode=mode)
    run = Run(tab)
    events = json.loads((CPSPLUS / 'manifests/protocol/sf2.json').read_text())
    for e in events['command_events_first_64']:
        run.drive(int(e['frame']), int(e['value']) & 255)
    return run

def build_directed() -> Run:
    proto = P.get_protocol('sf2')
    tab = Cps1Tables(proto, synthetic_triggers(), mode=1)
    run = Run(tab)
    fr = 100
    seq = [240, 22, 255, 33, 255, 5, 255, 8, 22, 255, 22, 255, 22, 255, 15, 255, 247, 86, 255, 140, 255]
    for v in seq:
        run.drive(fr, v)
        fr += 1
    return run

def build_disabled() -> Run:
    proto = P.get_protocol('sf2')
    tab = Cps1Tables(proto, synthetic_triggers(), mode=0)
    run = Run(tab)
    for fr, v in enumerate((22, 255, 5, 255, 15), start=100):
        run.drive(fr, v)
    return run

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('mode', choices=['all'])
    ap.add_argument('--outdir', required=True, type=Path)
    args = ap.parse_args()
    runs = [('sf2_trace', build_trace(mode=1)), ('sf2_directed', build_directed()), ('sf2_nogate', build_trace(mode=5)), ('sf2_disabled', build_disabled())]
    manifest = []
    for name, run in runs:
        p = run.dump(args.outdir, name)
        manifest.append(f"{name} {p['cfg']} {p['trig']} {p['stim']} {p['gold']}")
        print(f'{name:14s} stim={len(run.stim):4d} gold={len(run.gold):3d} subs={run.subs:3d}')
    (args.outdir / 'runs.txt').write_text('\n'.join(manifest) + '\n')
    print(f'wrote {args.outdir}/runs.txt ({len(runs)} runs)')
if __name__ == '__main__':
    main()
