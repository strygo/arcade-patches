"""Synthetic rejection/packaging tests; no game, keys or toolchain required."""
import hashlib
from pathlib import Path
import struct
import subprocess
import tempfile
import unittest
from unittest.mock import patch
from . import switch_source as source

def archive(files, magic=b'PFS0'):
    names = b''
    records = bytearray()
    data = b''
    for name, content in files:
        row = struct.pack('<QQII', len(data), len(content), len(names), 0)
        if magic == b'HFS0':
            row += bytes(40)
        records.extend(row)
        names += name.encode() + b'\x00'
        data += content
    return struct.pack('<4sIII', magic, len(files), len(names), 0) + records + names + data

def xci(secure, update=(), declared_secure_size=None):
    partition = archive(secure, b'HFS0')
    root = bytearray(archive([('update', archive(update, b'HFS0')), ('secure', partition)], b'HFS0'))
    if declared_secure_size is not None:
        struct.pack_into('<Q', root, 16 + 64 + 8, declared_secure_size)
    header = bytearray(512)
    header[256:260] = b'HEAD'
    struct.pack_into('<Q', header, 304, 512)
    return bytes(header + root)

class SwitchSources(unittest.TestCase):

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix='Switch sources with spaces ')
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.program = b'unchanged program fixture' * 50
        self.pin = dict(program_name='base.nca', program_sha256=hashlib.sha256(self.program).hexdigest(), ticket_name='base.tik', nsp_sha256='deliberately irrelevant outer hash')

    def package(self, content, name='source.nsp'):
        path = self.root / name
        path.write_bytes(content)
        return path

    def test_repack_order_metadata_filename_and_outer_hash_do_not_change_identity(self):
        a = self.package(archive([('base.nca', self.program), ('base.tik', b'ticket')]), 'one.nsp')
        b = self.package(archive([('note.xml', b'extra metadata'), ('base.tik', b'ticket'), ('base.nca', self.program)]), 'renamed package.NSP')
        self.assertNotEqual(source.file_sha(a), source.file_sha(b))
        for path in (a, b):
            self.assertEqual(source.authenticate(path, self.pin)['program_sha256'], self.pin['program_sha256'])
            with source.open_program(path, self.pin, self.root / 'work') as (program, ticket, _):
                self.assertEqual(program.read_bytes(), self.program)
                self.assertEqual(ticket.read_bytes(), b'ticket')
            self.assertFalse(program.exists())

    def test_content_corruption_is_rejected_before_decryption(self):
        path = self.package(archive([('base.nca', b'X' + self.program[1:]), ('base.tik', b'ticket')]))
        with self.assertRaisesRegex(ValueError, 'Program NCA identity differs'):
            source.authenticate(path, self.pin)
        with self.assertRaisesRegex(ValueError, 'Program NCA identity differs'):
            with source.open_program(path, self.pin, self.root / 'work'):
                self.fail('unverified NCA was yielded')
        self.assertEqual(list((self.root / 'work').iterdir()), [])

    def test_update_only_wrong_region_and_missing_ticket_fail(self):
        for files in ([('update.nca', b'patch')], [('japan.nca', self.program)], [('base.nca', self.program)]):
            with self.subTest(files=files):
                with self.assertRaises(ValueError):
                    source.authenticate(self.package(archive(files)), self.pin)

    def test_xci_without_ticket_uses_only_secure_partition(self):
        pin = dict(self.pin, program_variants=[dict(program_name='card.nca', program_sha256=self.pin['program_sha256'], ticket_name=None)])
        path = self.package(xci([('card.nca', self.program)]), 'game.xci')
        with source.open_program(path, pin, self.root / 'work') as (program, ticket, selected):
            self.assertIsNone(ticket)
            self.assertEqual(selected['program_name'], 'card.nca')
            self.assertEqual(program.read_bytes(), self.program)
        path.write_bytes(xci([('other.nca', b'wrong')], [('card.nca', self.program)]))
        with self.assertRaises(ValueError):
            source.authenticate(path, pin)

    def test_unknown_or_ambiguous_program_variant_fails(self):
        path = self.package(archive([('base.nca', self.program), ('card.nca', self.program), ('base.tik', b'tik')]))
        pin = dict(self.pin, program_variants=[dict(program_name='card.nca', program_sha256=self.pin['program_sha256'], ticket_name=None)])
        with self.assertRaisesRegex(ValueError, 'ambiguous'):
            source.authenticate(path, pin)

    def test_unsafe_duplicate_overlap_out_of_bounds_and_truncation(self):
        for name in ('../bad', '..', '.', 'a/b', 'a\\b', 'C:bad', '\x01bad'):
            with self.assertRaises(ValueError):
                source.entries(self.package(archive([(name, b'a')])))
        with self.assertRaises(ValueError):
            source.entries(self.package(archive([('same', b'a'), ('same', b'b')])))
        original = archive([('one', b'123'), ('two', b'456')])
        cases = [original[:-1], b'PFS0', b'garbage']
        overlap = bytearray(original)
        struct.pack_into('<Q', overlap, 16 + 24, 1)
        cases.append(overlap)
        too_many = bytearray(original)
        struct.pack_into('<I', too_many, 4, 4294967295)
        cases.append(too_many)
        bad_name = bytearray(original)
        struct.pack_into('<I', bad_name, 16 + 16, 4294967295)
        cases.append(bad_name)
        cases.append(xci([('card.nca', b'not within declared partition')], declared_secure_size=16))
        bad_root = bytearray(xci([]))
        struct.pack_into('<Q', bad_root, 304, len(bad_root) + 1)
        cases.append(bad_root)
        for case in cases:
            with self.subTest(case=bytes(case[:20])):
                with self.assertRaises(ValueError):
                    source.entries(self.package(case))

    def test_resource_hash_folder_extraction_and_redacted_errors(self):
        data = b'resource fixture'
        pin = dict(self.pin, resource_path='/1/game/mess/resource.arc', resource_sha256=hashlib.sha256(data).hexdigest())

        def extract(command, **kwargs):
            self.assertEqual(command[command.index('-x') + 1], '/1/game/mess')
            self.assertNotIn('--tik', command)
            self.assertNotIn('--showkeys', command)
            self.assertNotIn('--verbose', command)
            (Path(command[command.index('-x') + 2]) / 'resource.arc').write_bytes(data)
            return subprocess.CompletedProcess(command, 0, '', '')
        with patch.object(source.subprocess, 'run', side_effect=extract):
            source.resource('nstool', self.root / 'keys', self.root / 'program', None, pin, self.root / 'resource')
            with self.assertRaisesRegex(ValueError, 'resource identity differs'):
                source.resource('nstool', self.root / 'keys', self.root / 'program', None, dict(pin, resource_sha256='0' * 64), self.root / 'resource')
        with patch.object(source.subprocess, 'run', return_value=subprocess.CompletedProcess([], -1, 'key: ' + 'ab' * 16, 'Access denied')):
            with self.assertRaises(ValueError) as caught:
                source.extract('nstool', self.root / 'keys', self.root / 'program', None, '/1', self.root)
            self.assertIn('0xFFFFFFFF', str(caught.exception))
            self.assertIn('Access denied', str(caught.exception))
            self.assertNotIn('ab' * 16, str(caught.exception))
if __name__ == '__main__':
    unittest.main()
