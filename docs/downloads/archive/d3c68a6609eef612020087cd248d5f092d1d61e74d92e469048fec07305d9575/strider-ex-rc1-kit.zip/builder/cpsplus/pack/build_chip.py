"""Build a `<game>_spc` pack: SNES SPC songs, rendered by the accurate core."""
from __future__ import annotations
import argparse
import hashlib
import json
import sys
from pathlib import Path
import numpy as np
from . import adxcodec, loop_bake, protocols, spc_engine
from .build_common import MANIFESTS, PACKS_DIR
from .format import CODEC_ADX, PackReader, PackWriter, TrackMeta, TriggerRow, VERB_PLAY
TOOLS = Path(__file__).resolve().parents[1] / 'tools'
sys.path.insert(0, str(TOOLS))
import pin_spc_sets
RATE = spc_engine.RATE
GAMES = {'sfa2': {'set': 'sfa2', 'protocol': 'sfa2', 'title': 'Street Fighter Alpha 2 (SNES SPC Soundtrack)', 'pack': 'sfa2_spc'}}

def map_path(game: str) -> Path:
    return MANIFESTS / f'{game}_spc_trigger_map.tsv'

def recipe_path(game: str) -> Path:
    return MANIFESTS / f'{game}_spc_audio.json'

def read_map(game: str) -> list[tuple[int, str]]:
    rows = []
    for line in map_path(game).read_text().splitlines():
        f = line.split('\t')
        if line.startswith('#') or line.startswith('cmd') or len(f) < 2:
            continue
        rows.append((int(f[0], 16), f[1]))
    return rows

def pcm_sha256(pcm: np.ndarray) -> str:
    return hashlib.sha256(np.ascontiguousarray(pcm, '<i2').tobytes()).hexdigest()

def stored_pcm(spc: Path, t: dict) -> np.ndarray:
    """Render and cut one track exactly as the recipe says."""
    pcm = spc_engine.render(spc, t['render_frames'])
    if t['mode'] == 'loop':
        ls, le, n = (t['loop_start'], t['loop_end'], t['blend'])
        if ls % 32 or le % 32 or (not n <= ls < le <= len(pcm)):
            raise ValueError(f"{t['spc']}: bad loop points {ls}..{le}")
        return loop_bake.bake(pcm, ls, le, n)
    if t['mode'] == 'one_shot':
        return pcm[:t['end']].astype(np.int16)
    raise ValueError(f"{t['spc']}: unknown mode {t['mode']}")

def extract_set(project: str, spc_dir: Path | None) -> Path:
    sources = {x['project']: x for x in json.loads(pin_spc_sets.MANIFEST.read_text())['sets']}
    rsn = pin_spc_sets.spc_dir(spc_dir) / f'{project}.rsn'
    problems = pin_spc_sets.verify(project, rsn, sources[project])
    if problems:
        raise SystemExit('\n'.join(problems))
    dest = PACKS_DIR.parent / 'spc' / f'build_{project}'
    spc_engine.extract(rsn, dest)
    return dest

def build(game: str, spc_dir: Path | None=None, outdir: Path=PACKS_DIR) -> Path:
    cfg = GAMES[game]
    recipe = json.loads(recipe_path(game).read_text())
    if [(int(r['cmd'], 16), r['spc']) for r in recipe['triggers']] != read_map(game):
        raise SystemExit(f'{recipe_path(game).name} is stale: re-plan against the map')
    src = extract_set(cfg['set'], spc_dir)
    proto = protocols.get_protocol(cfg['protocol'])
    w = PackWriter(proto, title=cfg['title'], default_rate=RATE)
    index, audit = ({}, [])
    c1, c2 = adxcodec.calc_coeffs(adxcodec.DEFAULT_CUTOFF, RATE)
    for t in recipe['tracks']:
        pcm = stored_pcm(src / t['spc'], t)
        if pcm_sha256(pcm) != t['pcm_sha256']:
            raise SystemExit(f"{t['spc']}: stored PCM differs from the recipe")
        raw = np.ascontiguousarray(pcm, '<i2').tobytes()
        stream = adxcodec.encode(raw, 2, RATE)
        loop = t['mode'] == 'loop'
        ls, le = (t['loop_start'], t['loop_end']) if loop else (0, 0)
        meta = TrackMeta(sample_rate=RATE, channels=2, codec=CODEC_ADX, gain=127, loop_start_sample=ls, loop_end_sample=le, loop_start_byte=adxcodec.samples_to_stream_byte(ls, 2) if loop else 0, loop_end_byte=adxcodec.samples_to_stream_byte(le, 2) if loop else 0, coef1=c1, coef2=c2, xfade_enable=0, name=f"{t['title']} ({t['mode']})", source=t['spc'])
        index[t['spc']] = w.add_track(stream, meta)
        audit.append({'spc': t['spc'], 'mode': t['mode'], 'frames': len(pcm), 'pcm_sha256': t['pcm_sha256'], 'adx_sha256': hashlib.sha256(stream).hexdigest()})
        print(f"[{cfg['pack']}] {t['spc']:14} {t['mode']:8} {len(pcm) / RATE:6.1f} s {len(stream) / 1000000.0:5.2f} MB  {t['title']}", flush=True)
    gain = recipe['trigger_gain']
    for r in recipe['triggers']:
        w.set_trigger(int(r['cmd'], 16), TriggerRow(verb=VERB_PLAY, track=index[r['spc']], gain=gain, suppress=1))
    outdir = Path(outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    pack = outdir / f"{cfg['pack']}.cpk"
    w.write(pack)
    rd = PackReader(pack)
    for r in recipe['triggers']:
        row = rd.triggers[int(r['cmd'], 16)]
        if row.verb != VERB_PLAY or row.track != index[r['spc']] or row.suppress != 1:
            raise SystemExit(f"readback: {r['cmd']} is not mapped as built")
    digest = hashlib.sha256(pack.read_bytes()).hexdigest()
    (outdir / f"{cfg['pack']}.build.json").write_text(json.dumps({'pack': pack.name, 'sha256': digest, 'bytes': pack.stat().st_size, 'tracks': audit}, indent=1) + '\n')
    print(f"[{cfg['pack']}] {pack}  {pack.stat().st_size / 1000000.0:.1f} MB, {len(w.tracks)} tracks, {len(recipe['triggers'])} triggers, sha256 {digest[:16]}")
    return pack

def main(argv: list[str] | None=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--game', required=True, choices=sorted(GAMES))
    ap.add_argument('--spc-dir', type=Path)
    ap.add_argument('--out', type=Path, default=PACKS_DIR)
    a = ap.parse_args(argv)
    build(a.game, a.spc_dir, a.out)
    return 0
if __name__ == '__main__':
    raise SystemExit(main())
