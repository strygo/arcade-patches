"""Build the Strider EX pack: the PC Engine soundtrack plus the cinematic tracks."""
from __future__ import annotations
import argparse
import dataclasses
import hashlib
import json
import sys
from pathlib import Path
import numpy as np
from scipy import signal
from . import adxcodec, protocols
from .build_common import MANIFESTS, PACKS_DIR, PKG_ROOT
from .build_strider_pce import DISC, RATE, RECIPE, digest, disc_bins, stored_zip, track_pcm
from .format import FADE_ANTHOLOGY, PackWriter, TrackMeta, TriggerRow, VERB_FADE_OUT, VERB_PLAY, VERB_STOP
EX_MANIFEST = MANIFESTS / 'strider_ex_audio.json'
CUES = PKG_ROOT.parent / 'backports' / 'striderex' / 'manifests' / 'ex_pack_cues.json'
DISC_RATE = 44100
SILENT_DB = -55.0

def window(bin_bytes, window_s, what):
    """The cinematic track's samples from window_s[0] (backports/striderex/manifests/ex_pack_cues.json:"""
    x = np.frombuffer(bin_bytes[:len(bin_bytes) // 4 * 4], '<i2').reshape(-1, 2)
    head, tail = (round(window_s[0] * DISC_RATE), round(window_s[1] * DISC_RATE))
    k = DISC_RATE // 50
    for name, part in (('head', x[:head]), ('tail', x[tail:])):
        y = part.astype(np.float64).mean(1) / 32768
        m = len(y) // k
        if m:
            db = 20 * np.log10(np.sqrt((y[:m * k].reshape(m, k) ** 2).mean(1) + 1e-20))
            if db.max() > SILENT_DB:
                raise ValueError(f"{what}: the {name} outside window {window_s} s is not silent ({db.max():.1f} dBFS at {(np.argmax(db) * k + (0 if name == 'head' else tail)) / DISC_RATE:.2f} s)")
    return x[head:].tobytes()

def cinematic_pcm(bin_bytes):
    """A cinematic track (from its window's start): 44.1 -> 48 kHz as the soundtrack, padded to 32 frames."""
    x = np.frombuffer(bin_bytes, '<i2').reshape(-1, 2).astype(np.float64) / 32768
    y = signal.resample_poly(x, 160, 147, axis=0, window=('kaiser', 8.6))
    y = np.pad(y, ((0, -len(y) % 32), (0, 0)))
    if not (np.isfinite(y).all() and np.max(np.abs(y)) < 1):
        y = np.clip(y, -32767 / 32768, 32767 / 32768)
    return np.rint(y * 32768).clip(-32768, 32767).astype('<i2').tobytes()

def dub_delta():
    """The English dub decoder: shipped beside this file in a kit, else the repository's."""
    try:
        from . import dub_delta as X
    except ImportError:
        sys.path.insert(0, str(PKG_ROOT.parent / 'backports' / 'striderex' / 'scripts'))
        import dub_delta as X
    return X

def boss_voice_pack():
    """The boss voice converter (backports/striderex/scripts/boss_voice_pack.py)."""
    try:
        from . import boss_voice_pack as X
    except ImportError:
        sys.path.insert(0, str(PKG_ROOT.parent / 'backports' / 'striderex' / 'scripts'))
        import boss_voice_pack as X
    return X

def english_pcm(payload, track, bin_bytes, window_s, what):
    """The approved English cinematic track at the pack's rate, from the player's disc track (its window)."""
    X = dub_delta()
    disc = np.frombuffer(bin_bytes[:len(bin_bytes) // 4 * 4], '<i2').reshape(-1, 2).T.astype(np.int64)
    en = X.decode_track(payload, track, disc)
    return cinematic_pcm(window(en.T.astype('<i2').tobytes(), window_s, what))

def skip_fade_protocol(skip):
    """The strider protocol with the START skip's fade (ex_pack_cues.json skip_fade): its control byte mapped"""
    base = protocols.PROTOCOLS['strider']
    cmd, frames = (int(skip['cue'], 16), int(skip['frames']))
    if skip['verb'] != 'fade_out' or skip['law'] != 'anthology':
        raise ValueError(f'skip_fade: only fade_out under the Anthology law is built ({skip})')
    if not base.control_region_start <= cmd <= 255 or cmd in base.control_verbs or cmd == 255:
        raise ValueError(f'skip_fade cue {cmd:#04x}: must be a free control byte (control region, no verb, not idle)')
    if not 1 <= frames <= 65535:
        raise ValueError(f'skip_fade frames {frames}')
    return dataclasses.replace(base, fade_law=FADE_ANTHOLOGY, fade_const1=frames, fade_const2=0, control_verbs={**base.control_verbs, cmd: VERB_FADE_OUT})

def build(recipe_path=RECIPE, manifest_path=EX_MANIFEST, disc=DISC, outdir=PACKS_DIR, pin=False, english=None, portraits=None):
    recipe = json.loads(Path(recipe_path).read_text(encoding='utf-8'))
    man = json.loads(Path(manifest_path).read_text(encoding='utf-8'))
    cues = json.loads(CUES.read_text(encoding='utf-8'))['cinematics']['rows']
    boss = man.get('boss_voices', []) if portraits else []
    boss_cues = {b['id']: b['cue'] for b in json.loads(CUES.read_text(encoding='utf-8')).get('boss_voices', {}).get('rows', [])}
    if portraits and [(b['id'], int(b['command'], 16)) for b in boss] != [(i, int(c, 16)) for i, c in boss_cues.items()]:
        raise ValueError('boss_voices: manifest disagrees with ex_pack_cues.json')
    disc = Path(disc)
    if digest(disc) != recipe['source']['disc_sha256']:
        raise ValueError(f'{disc}: not the pinned disc archive')
    outdir = Path(outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    rows = {r['id']: r for r in cues}
    cin = [c for c in man['cinematics']]
    for c in cin:
        r = rows[c['id']]
        if r['pce_track'] != c['disc_track'] or r['ja'] != c['command']:
            raise ValueError(f"{c['id']}: manifest disagrees with ex_pack_cues.json")
    eng = man.get('english', []) if english else []
    for e in eng:
        r = rows[e['id']]
        if r['pce_track'] != e['disc_track'] or r['en'] != e['command']:
            raise ValueError(f"{e['id']}: English row disagrees with ex_pack_cues.json")
    payload = Path(english).read_bytes() if english else None
    proto = skip_fade_protocol(json.loads(CUES.read_text(encoding='utf-8'))['skip_fade'])
    rows_at = {int(r['command'], 16) for r in recipe['triggers']} | {int(c['command'], 16) for c in cin} | {int(e['command'], 16) for e in eng + (man.get('english_same', []) if english else [])} | {int(b['command'], 16) for b in boss}
    ctrl = sorted((c for c in rows_at if c >= proto.control_region_start))
    if ctrl:
        raise ValueError(f"rows {[f'0x{c:02X}' for c in ctrl]} lie in the control region (0x{proto.control_region_start:02X} up), where the core reads no trigger row")
    bins = disc_bins(disc, sorted({t['disc_track'] for t in recipe['tracks']} | {c['disc_track'] for c in cin} | {e['disc_track'] for e in eng}))
    w = PackWriter(proto, title='Strider EX (PC Engine)', trigger_rows=256, default_rate=RATE, xfade_samples=0)
    tracks, audit = ({}, [])

    def add(tid, title, pcm, loop):
        stream = adxcodec.encode(pcm, 2, RATE)
        c1, c2 = adxcodec.calc_coeffs(adxcodec.DEFAULT_CUTOFF, RATE)
        meta = TrackMeta(sample_rate=RATE, channels=2, gain=127, coef1=c1, coef2=c2, loop_start_sample=loop[0] if loop else 0, loop_end_sample=loop[1] if loop else 0, loop_start_byte=adxcodec.samples_to_stream_byte(loop[0], 2) if loop else 0, loop_end_byte=adxcodec.samples_to_stream_byte(loop[1], 2) if loop else 0, xfade_enable=False, name=title, source=recipe['source']['disc'])
        tracks[tid] = w.add_track(stream, meta)
        audit.append(dict(id=tid, pcm_sha256=hashlib.sha256(pcm).hexdigest(), adx_sha256=hashlib.sha256(stream).hexdigest()))
        print(tid, title, flush=True)
    for row in recipe['tracks']:
        pcm = track_pcm(row, bins[row['disc_track']])
        loop = (row['loop_start'], row['loop_end']) if row['loop_start'] is not None else None
        add(row['id'], row['title'], pcm, loop)
    pinned = False
    for c in cin:
        pcm = cinematic_pcm(window(bins[c['disc_track']], rows[c['id']]['window_s'], c['id']))
        got = hashlib.sha256(pcm).hexdigest()
        if c.get('pcm_sha256') is None:
            if not pin:
                raise ValueError(f"{c['id']}: no pinned digest (run with --pin once)")
            c['pcm_sha256'] = got
            pinned = True
        elif c['pcm_sha256'] != got:
            raise ValueError(f"{c['id']}: rebuilt PCM differs from the pinned digest")
        add(c['id'], c['title'], pcm, None)
    for e in eng:
        pcm = english_pcm(payload, e['disc_track'], bins[e['disc_track']], rows[e['id']]['window_s'], f"{e['id']} (English)")
        got = hashlib.sha256(pcm).hexdigest()
        if e.get('pcm_sha256') is None:
            if not pin:
                raise ValueError(f"{e['id']} (English): no pinned digest (run with --pin once)")
            e['pcm_sha256'] = got
            pinned = True
        elif e['pcm_sha256'] != got:
            raise ValueError(f"{e['id']} (English): rebuilt PCM differs from the pinned digest")
        add(f"{e['id']}_en", f"{e['title']} (English)", pcm, None)
    for b in boss:
        pcm = boss_voice_pack().row_pcm(portraits, b)
        got = hashlib.sha256(pcm).hexdigest()
        if b.get('pcm_sha256') is None:
            if not pin:
                raise ValueError(f"{b['id']} (boss voice): no pinned digest (run with --pin once)")
            b['pcm_sha256'] = got
            pinned = True
        elif b['pcm_sha256'] != got:
            raise ValueError(f"{b['id']} (boss voice): rebuilt PCM differs from the pinned digest")
        add(f"boss_{b['id']}", b['title'], pcm, None)
    for row in recipe['triggers']:
        cmd = int(row['command'], 16)
        if row['track']:
            w.set_trigger(cmd, TriggerRow(verb=VERB_PLAY, track=tracks[row['track']], gain=recipe['trigger_gain'], suppress=1))
        elif row['stop_arranged']:
            w.set_trigger(cmd, TriggerRow(verb=VERB_STOP, suppress=0))
    for c in cin:
        w.set_trigger(int(c['command'], 16), TriggerRow(verb=VERB_PLAY, track=tracks[c['id']], gain=recipe['trigger_gain'], suppress=1))
    for e in eng:
        w.set_trigger(int(e['command'], 16), TriggerRow(verb=VERB_PLAY, track=tracks[f"{e['id']}_en"], gain=recipe['trigger_gain'], suppress=1))
    same = man.get('english_same', []) if english else []
    for e in same:
        src = next((r for r in recipe['triggers'] if int(r['command'], 16) == int(e['as'], 16)))
        w.set_trigger(int(e['command'], 16), TriggerRow(verb=VERB_PLAY, track=tracks[src['track']], gain=recipe['trigger_gain'], suppress=1))
    for b in boss:
        w.set_trigger(int(b['command'], 16), TriggerRow(verb=VERB_PLAY, track=tracks[f"boss_{b['id']}"], gain=recipe['trigger_gain'], suppress=1))
    native = {int(r['cue'], 16) for r in json.loads(CUES.read_text(encoding='utf-8')).get('native_sfx', {}).get('rows', [])}
    rowed = {int(r['command'], 16) for r in recipe['triggers']} | {int(c['command'], 16) for c in cin} | {int(e['command'], 16) for e in eng + same} | {int(b['command'], 16) for b in boss}
    if rowed & native:
        raise ValueError(f'rows on the native effect commands {sorted(map(hex, rowed & native))} (ex_pack_cues.json native_sfx): the core would take them from the Z80')
    if pinned:
        Path(manifest_path).write_text(json.dumps(man, indent=1, ensure_ascii=False) + '\n', encoding='utf-8')
    pack = outdir / 'strider_ex.cpk'
    w.write(pack)
    stored_zip(outdir / 'strider_ex.zip', {pack.name: pack.read_bytes()})
    commands = sorted({int(r['command'], 16) for r in recipe['triggers']} | {int(c['command'], 16) for c in cin} | {int(e['command'], 16) for e in eng + same} | {int(b['command'], 16) for b in boss})
    report = dict(pack=pack.name, sha256=digest(pack), bytes=pack.stat().st_size, recipe_sha256=digest(recipe_path), manifest_sha256=digest(manifest_path), commands=[f'0x{c:02x}' for c in commands], english_voices=bool(eng), english_payload_sha256=hashlib.sha256(payload).hexdigest() if payload else None, skip_fade=dict(cue=f'0x{max((c for c, v in proto.control_verbs.items() if v == VERB_FADE_OUT)):02x}', law=proto.fade_law, const1=proto.fade_const1, const2=proto.fade_const2), boss_voices=[dict(id=b['id'], command=b['command'], gain_db=b['gain_db']) for b in boss], desert=False, tracks=audit)
    (outdir / 'strider_ex.build.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8', newline='\n')
    return report

def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('--recipe', type=Path, default=RECIPE)
    p.add_argument('--manifest', type=Path, default=EX_MANIFEST)
    p.add_argument('--disc', type=Path, default=DISC, help='Strider Hiryuu (Japan).7z (the PC Engine CD)')
    p.add_argument('--out-dir', type=Path, default=PACKS_DIR)
    p.add_argument('--pin', action='store_true', help='write the cinematic PCM digests the first time')
    p.add_argument('--english', type=Path, help='the English dub payload (backports/striderex/scripts/dub_delta.py encode): add the English rows')
    p.add_argument('--portraits', type=Path, help='a portrait_pce.py capture (<id>/ram_writes.txt): add the boss voice rows (0xB8-0xBF)')
    a = p.parse_args(argv)
    print(json.dumps(build(a.recipe, a.manifest, a.disc, a.out_dir, a.pin, a.english, a.portraits), indent=2))
    return 0
if __name__ == '__main__':
    raise SystemExit(main())
