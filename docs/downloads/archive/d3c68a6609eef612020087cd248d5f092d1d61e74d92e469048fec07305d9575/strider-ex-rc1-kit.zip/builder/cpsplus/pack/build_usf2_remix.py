"""Build the SSF2-family USF2 remix pack from a Switch base NSP or XCI."""
from __future__ import annotations
import argparse
from collections import Counter
import csv
from dataclasses import dataclass
import hashlib
import json
from pathlib import Path
import re
import struct
import subprocess
import sys
import tempfile
from . import adxcodec, ssf2_family
from .build_common import MANIFESTS, PACKS_DIR, PKG_ROOT
from .format import CODEC_ADX, PackReader, PackWriter, TrackMeta, TriggerRow, VERB_PLAY
from . import switch_source
EXPECTED_NSP_SHA256 = '235c8f3d1a83d81703acd7309458e8646564df982edfd271652a6e993487ab8f'
TICKET_NAME = '01007330027ee0000000000000000000.tik'
PROGRAM_NAME = '95497f167915f13705a441cc7d2bbef0.nca'
PROGRAM_SHA256 = '95497f167915f13705a441cc7d2bbef09e9f26fd0f317d9c2a1befde53103784'
SOURCE_PINS = MANIFESTS / 'usf2_switch_sources.json'
BGM_PATH = '/1/nativeNXx64/app/sound/bgm/wav'
PACK_NAME = 'ssf2_usf2_remix'
DEFAULT_WORK = PKG_ROOT / 'work' / 'usf2_remix'
TOOLS = PKG_ROOT / 'tools'
DEFAULT_GAIN = 33
NAME_COMMAND = re.compile('_([0-9a-f]{2})(?:_v\\d+(?:_add)?)?\\.opus$')
EXPECTED_MISSING = frozenset({56, 211, 224})
BAKE_COMMANDS = frozenset({4, 10, 13, 14, 17, 21, 24, 26, 27, 29, 31, 32, 35, 44, 47, 49, 52, 59, 193, 213, 214})
BAKE_SAMPLES = 1024

def run(*args: str) -> str:
    proc = subprocess.run(args, capture_output=True, text=True, check=False)
    if proc.returncode:
        raise RuntimeError(f'{args[0]} failed ({proc.returncode}): {(proc.stdout + proc.stderr)[-3000:]}')
    return proc.stdout

def digest_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open('rb') as source:
        while (chunk := source.read(8 * 1024 * 1024)):
            digest.update(chunk)
    return digest.hexdigest()

def switch_tools(root: Path) -> dict[str, Path]:
    """Use authenticated recipient binaries; never compile a fallback."""
    sys.path.insert(0, str(TOOLS))
    try:
        import fetch_switch_tools
    finally:
        sys.path.remove(str(TOOLS))
    manifest = TOOLS / 'switch_helpers.json'
    if not manifest.is_file():
        manifest = PKG_ROOT / 'manifests/switch_helpers_v1.json'
    try:
        return fetch_switch_tools.setup(root, manifest=manifest)
    except fetch_switch_tools.SetupError as exc:
        raise ValueError(str(exc)) from exc

def commands() -> dict[int, str]:
    with (MANIFESTS / 'hsf2_bgm_command_map.tsv').open(newline='') as source:
        rows = csv.DictReader(source, delimiter='\t')
        mapped = {int(row['cmd'], 16): row['name'] for row in rows if row['set'] == 'ARRANGE' and row['in_game'] == 'yes'}
    if len(mapped) != 68:
        raise ValueError(f'Expected 68 in-game SSF2-family music commands, got {len(mapped)}')
    return mapped

def match_sources(root: Path, required: dict[int, str]) -> dict[int, Path]:
    paths = sorted((path for path in root.rglob('*.opus') if not path.name.startswith('._')))
    if len(paths) != 158:
        groups = Counter((path.relative_to(root).parts[0] for path in paths))
        raise ValueError(f'Expected 158 USF2 music files, got {len(paths)} in {dict(groups)}; examples: {[p.relative_to(root).as_posix() for p in paths[:5]]}')
    found: dict[int, Path] = {}
    for path in paths:
        rel = path.relative_to(root)
        if rel.parts[0] != 'remix':
            continue
        match = NAME_COMMAND.search(path.name)
        if not match:
            continue
        cmd = int(match.group(1), 16)
        if cmd not in required:
            continue
        if cmd in found:
            raise ValueError(f'Duplicate remix join for 0x{cmd:02x}: {found[cmd]} and {path}')
        found[cmd] = path
    missing = required.keys() - found.keys()
    if len(found) != 65 or missing != EXPECTED_MISSING:
        raise ValueError(f'USF2 remix join changed: found {len(found)}, missing {[hex(c) for c in sorted(missing)]}')
    return found

@dataclass
class SwitchOpus:
    total: int
    channels: int
    loop_start: int
    loop_end: int
    pre_skip: int
    packets: list[bytes]

def read_switch_opus(path: Path) -> SwitchOpus:
    """Parse Capcom's wrapper and the Nintendo Opus stream inside it."""
    data = path.read_bytes()
    total, channels, loop_start, loop_end = struct.unpack_from('<IIii', data, 0)
    base = struct.unpack_from('<I', data, 28)[0]
    if struct.unpack_from('<I', data, base)[0] != 2147483649:
        raise ValueError(f'No Nintendo Opus header: {path}')
    rate = struct.unpack_from('<I', data, base + 12)[0]
    pre_skip = struct.unpack_from('<H', data, base + 28)[0]
    chunk = base + struct.unpack_from('<I', data, base + 16)[0]
    if struct.unpack_from('<I', data, chunk)[0] != 2147483652:
        raise ValueError(f'No Nintendo Opus data chunk: {path}')
    pos = chunk + 8
    end = pos + struct.unpack_from('<I', data, chunk + 4)[0]
    if rate != 48000 or channels != 2 or data[base + 9] != 2 or (not 0 < total < 48000 * 600) or (end > len(data)):
        raise ValueError(f'Unexpected USF2 audio header: {path}')
    packets = []
    while pos < end:
        size = struct.unpack_from('>I', data, pos)[0]
        if not 0 < size <= 65536 or pos + 8 + size > end:
            raise ValueError(f'Bad Opus packet at 0x{pos:x}: {path}')
        packets.append(data[pos + 8:pos + 8 + size])
        pos += 8 + size
    if loop_end > 0:
        if not 0 <= loop_start < loop_end <= total:
            raise ValueError(f'Invalid loop samples {loop_start}..{loop_end}: {path}')
    else:
        loop_start = loop_end = 0
    return SwitchOpus(total, channels, loop_start, loop_end, pre_skip, packets)

def align_loop(start: int, end: int, total: int) -> tuple[int, int]:
    """Choose the nearest ADX frame, never extending beyond decoded PCM."""
    a = (start + 16) // 32 * 32
    b = min((end + 16) // 32 * 32, total // 32 * 32)
    if not 0 <= a < b:
        raise ValueError(f'Loop collapsed after ADX alignment: {start}..{end}/{total}')
    return (a, b)

def bake_join(pcm: bytes, start: int, end: int, samples: int=BAKE_SAMPLES) -> bytes:
    """Blend the last `samples` frames into the frames before loop start."""
    if start < samples or end - start <= samples:
        raise ValueError(f'Cannot bake loop {start}..{end} with {samples} samples')
    audio = bytearray(pcm[:end * 4])
    for i in range(samples):
        for channel in range(2):
            tail = struct.unpack_from('<h', pcm, (end - samples + i) * 4 + channel * 2)[0]
            head = struct.unpack_from('<h', pcm, (start - samples + i) * 4 + channel * 2)[0]
            value = round(((samples - i - 1) * tail + (i + 1) * head) / samples)
            struct.pack_into('<h', audio, (end - samples + i) * 4 + channel * 2, max(-32768, min(32767, value)))
    return bytes(audio)

def decode_pcm(decoder: Path, opus: SwitchOpus, scratch: Path) -> bytes:
    """Interleaved s16le PCM of exactly ``opus.total`` frames."""
    packets, raw = (scratch / 'packets.cpop', scratch / 'decoded.raw')
    with packets.open('wb') as out:
        out.write(b'CPOP' + struct.pack('<III', opus.channels, opus.pre_skip, opus.total))
        for packet in opus.packets:
            out.write(struct.pack('<I', len(packet)) + packet)
    run(str(decoder), str(packets), str(raw))
    pcm = raw.read_bytes()
    if len(pcm) != opus.total * opus.channels * 2:
        raise ValueError(f'Decoder wrote {len(pcm)} bytes for {opus.total} frames')
    return pcm

def build(nsp: Path, keys: Path, *, out: Path | None=None, work: Path=DEFAULT_WORK, scratch: Path | None=None, gain: int=DEFAULT_GAIN, source_pin: dict | None=None) -> Path:
    pin = source_pin or json.loads(SOURCE_PINS.read_text())['regions']['us']
    switch_source.select(nsp, pin)
    if not keys.is_file():
        raise FileNotFoundError(keys)
    if not 0 <= gain <= 127:
        raise ValueError('--gain must be 0..127')
    source_hash = digest_file(nsp)
    work.mkdir(parents=True, exist_ok=True)
    scratch_root = scratch or work
    scratch_root.mkdir(parents=True, exist_ok=True)
    tools = switch_tools(work / 'tools')
    nstool, decoder = (tools['nstool'], tools['decoder'])
    required = commands()
    ssf2_family.check_protocol(ssf2_family.PROTOCOL)
    writer = PackWriter(ssf2_family.PROTOCOL, title='Ultra SFII remix for SSF2 family')
    coef1, coef2 = adxcodec.calc_coeffs(adxcodec.DEFAULT_CUTOFF, 48000)
    audit: list[dict] = []
    with tempfile.TemporaryDirectory(prefix='extract-', dir=scratch_root) as tmp:
        scratch = Path(tmp)
        bgm = scratch / 'bgm'
        bgm.mkdir()
        with switch_source.open_program(nsp, pin, scratch) as (program, ticket, selected):
            program_hash = selected['program_sha256']
            switch_source.resource(nstool, keys, program, ticket, pin, scratch / 'resource')
            switch_source.extract(nstool, keys, program, ticket, BGM_PATH, bgm)
        sources = match_sources(bgm, required)
        for index, (cmd, source) in enumerate(sorted(sources.items()), 1):
            opus = read_switch_opus(source)
            total, channels = (opus.total, opus.channels)
            loop_start, loop_end = (opus.loop_start, opus.loop_end)
            pcm = decode_pcm(decoder, opus, scratch)
            rel = source.relative_to(bgm).as_posix()
            meta = TrackMeta(sample_rate=48000, channels=2, codec=CODEC_ADX, coef1=coef1, coef2=coef2, name=source.stem, source=f'USF2:{rel}')
            aligned = None
            baked = False
            if loop_end:
                start, end = align_loop(loop_start, loop_end, total)
                if cmd in BAKE_COMMANDS:
                    start = max(start, BAKE_SAMPLES)
                    pcm = bake_join(pcm, start, end)
                    baked = True
                meta.loop_start_sample, meta.loop_end_sample = (start, end)
                meta.loop_start_byte = adxcodec.samples_to_stream_byte(start, channels)
                meta.loop_end_byte = adxcodec.samples_to_stream_byte(end, channels)
                aligned = {'start': start - loop_start, 'end': end - loop_end}
            elif cmd in BAKE_COMMANDS:
                raise ValueError(f'Expected 0x{cmd:02x} to have a source loop')
            stream = adxcodec.encode(pcm, channels, 48000)
            if loop_end:
                stream = stream[:meta.loop_end_byte]
            track = writer.add_track(stream, meta)
            writer.set_trigger(cmd, TriggerRow(verb=VERB_PLAY, track=track, gain=gain, suppress=1))
            audit.append({'cmd': f'0x{cmd:02x}', 'role': required[cmd], 'source': rel, 'sha256': digest_file(source), 'samples': total, 'source_loop': [loop_start, loop_end], 'adx_loop_adjustment': aligned, 'baked_join_samples': BAKE_SAMPLES if baked else 0, 'adx_bytes': len(stream)})
            print(f'[{index:02d}/65] 0x{cmd:02x} {source.name} {len(stream) / 1048576:.2f} MiB', flush=True)
        select = writer.triggers[52]
        writer.set_trigger(211, TriggerRow(verb=VERB_PLAY, track=select.track, gain=gain, suppress=1))
        for cmd in (56, 61, 224):
            if writer.triggers[cmd].verb != 0:
                raise AssertionError(f'0x{cmd:02x} must fail open')
        out = out or PACKS_DIR / f'{PACK_NAME}.cpk'
        writer.write(out)
    reader = PackReader(out)
    try:
        if reader.header.game_id != 'ssf2' or len(reader.tracks) != 65 or sum((row.verb == VERB_PLAY for row in reader.triggers)) != 66:
            raise AssertionError('Written USF2 pack has an unexpected table')
    finally:
        reader.close()
    sidecar = Path(str(out) + '.json')
    record = json.loads(sidecar.read_text())
    record['provenance'] = {'source_sha256': source_hash, 'source_format': 'xci' if selected['ticket_name'] is None else 'nsp', 'program_nca_sha256': program_hash, 'resource_sha256': pin['resource_sha256'], 'decoder': 'libopus v1.5.2 fixed point, no intrinsics', 'ffmpeg': adxcodec.ffmpeg_version(), 'trigger_gain': gain}
    with nsp.open('rb') as container:
        is_nsp = container.read(4) == b'PFS0'
    if is_nsp:
        record['provenance']['nsp_sha256'] = source_hash
        record['provenance']['source_format'] = 'nsp'
    record['source_audit'] = audit
    sidecar.write_text(json.dumps(record, indent=2) + '\n')
    print(f'[usf2] {out}  {out.stat().st_size / 1048576:.2f} MiB; 65 tracks, 66 PLAY rows; 0x38/0xe0 fail open', flush=True)
    return out

def main(argv=None) -> None:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--source', '--nsp', '--xci', dest='nsp', type=Path, required=True, help='USF2 USA base .nsp or .xci (content hashes are verified)')
    ap.add_argument('--keys', type=Path, required=True, help="owner's prod.keys")
    ap.add_argument('--out', type=Path)
    ap.add_argument('--work', type=Path, default=DEFAULT_WORK)
    ap.add_argument('--scratch', type=Path, help='volume with 4+ GiB free for temporary NCA/audio extraction')
    ap.add_argument('--gain', type=lambda value: int(value, 0), default=DEFAULT_GAIN)
    args = ap.parse_args(argv)
    build(args.nsp.resolve(), args.keys.resolve(), out=args.out, work=args.work, scratch=args.scratch, gain=args.gain)
if __name__ == '__main__':
    main()
