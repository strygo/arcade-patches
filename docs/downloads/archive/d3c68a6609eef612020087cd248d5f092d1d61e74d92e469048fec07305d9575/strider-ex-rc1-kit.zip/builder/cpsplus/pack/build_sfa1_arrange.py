"""`build_pack.py zero1-arrange` — SFA1 ARRANGE pack from the SF Alpha Anthology."""
from __future__ import annotations
from pathlib import Path
from . import adxcodec, protocols
from .afs import AfsArchive
from .build_common import PACKS_DIR, PKG_ROOT
from .format import PackWriter, TrackMeta, TriggerRow, CODEC_ADX, VERB_PLAY
from .isofs import IsoFS
from .sources import resolve_image
TRIG_GAIN = 34
ARCADE_STAGE_CMDS = {1: 'ryu', 2: 'ken', 3: 'chunli', 4: 'sagat', 5: 'sodom', 6: 'adon', 7: 'birdie', 8: 'guy', 9: 'nash', 10: 'rose', 11: 'gouki', 12: 'vega', 50: 'dan'}
ARCADE_JOIN_OFFSET = 56
CMD_REKEY = {**{c: c - 8 for c in range(9, 21)}, 21: 50}
STAGE_ENTRIES = range(97, 110)
INGAME_TO_ARRANGE = {97: 141, 98: 142, 99: 145, 100: 152, 101: 147, 102: 146, 103: 149, 104: 148, 105: 144, 106: 150, 107: 143, 108: 151, 109: 153}
LOOPS_TSV = PKG_ROOT / 'manifests' / 'sfa1_arrange_loops.tsv'
SATURN_LOOPS_TSV = PKG_ROOT / 'manifests' / 'sfa1_arrange_loops_saturn.tsv'
FULLCOV_TSV = PKG_ROOT / 'manifests' / 'sfa1_fullcov_candidate_map.tsv'
SATURN_CD_DIR = PKG_ROOT / 'work' / 'intermediate' / 'sfa1_fullcov' / 'saturn_cdda'
FULLCOV_LOOP_ROLES = {'select', 'continue', 'ending', 'ending_dup'}
TRIGGER_TSV = PKG_ROOT / 'manifests' / 'sfa1_arrange_trigger_map.tsv'
if not LOOPS_TSV.exists():
    LOOPS_TSV = PKG_ROOT / 'work' / 'intermediate' / 'sfa1_arrange_loops' / 'LOOPS.tsv'
XFADE_SAMPLES = 7200

def _load_loops(path: Path) -> dict[int, dict]:
    """entry(int e.g. 141) -> {char, ls, le, method, quality}."""
    rows = path.read_text(encoding='utf-8').splitlines()
    hdr = rows[0].split('\t')
    out: dict[int, dict] = {}
    for line in rows[1:]:
        if not line.strip():
            continue
        f = dict(zip(hdr, line.split('\t')))
        entry = int(f['entry'].lstrip('eE'))
        out[entry] = {'char': f['char'], 'ls': int(f['loop_start_sample']), 'le': int(f['loop_end_sample']), 'method': f['method'].strip(), 'quality': float(f['quality'])}
    return out

def _round32(v: int) -> int:
    return (v + 16) // 32 * 32

def _pcm_loop_track(pcm: bytes, rate: int, ch: int, ls: int, le: int, method: str, *, name: str, source: str, gain: int=127) -> tuple[bytes, TrackMeta]:
    """Saturn CD-DA source: ADX-encode, then cut per the loop method."""
    stream = adxcodec.encode(pcm, ch, rate)
    c1, c2 = adxcodec.calc_coeffs(adxcodec.DEFAULT_CUTOFF, rate)
    ls_byte = adxcodec.samples_to_stream_byte(ls, ch)
    le_byte = adxcodec.samples_to_stream_byte(le, ch)
    meta = TrackMeta(sample_rate=rate, channels=ch, codec=CODEC_ADX, gain=gain, coef1=c1, coef2=c2, name=name, source=source, loop_start_sample=ls, loop_start_byte=ls_byte, loop_end_sample=le, loop_end_byte=le_byte)
    if method == 'crossfade':
        end_byte = le_byte + adxcodec.samples_to_stream_byte(XFADE_SAMPLES, ch)
        if len(stream) < end_byte:
            raise ValueError(f'{name}: no room for the crossfade tail')
        meta.xfade_enable = 1
        return (stream[:end_byte], meta)
    return (stream[:le_byte], meta)

def _natural_track(raw: bytes, ls: int, le: int, *, name: str, source: str, gain: int=127) -> tuple[bytes, TrackMeta, dict]:
    """Hard-cut loop: reuse the source ADX frame bytes truncated at loop_end"""
    info = adxcodec.parse_header(raw)
    ch = info.channels
    ls_byte = adxcodec.samples_to_stream_byte(ls, ch)
    le_byte = adxcodec.samples_to_stream_byte(le, ch)
    stream = raw[info.data_offset:info.data_offset + le_byte]
    if len(stream) != le_byte:
        raise ValueError(f'{name}: source truncated ({len(stream)} < {le_byte} loop_end bytes)')
    coef1, coef2 = adxcodec.calc_coeffs(info.cutoff or adxcodec.DEFAULT_CUTOFF, info.sample_rate)
    meta = TrackMeta(sample_rate=info.sample_rate, channels=ch, codec=CODEC_ADX, gain=gain, coef1=coef1, coef2=coef2, name=name, source=source, loop_start_sample=ls, loop_start_byte=ls_byte, loop_end_sample=le, loop_end_byte=le_byte)
    return (stream, meta, {'reencoded': False})

def _crossfade_track(raw: bytes, ls: int, le: int, *, name: str, source: str, gain: int=127, xfade_samples: int=XFADE_SAMPLES) -> tuple[bytes, TrackMeta, dict]:
    """Crossfade loop, stored byte-exact: reuse the ORIGINAL ADX frame bytes"""
    info = adxcodec.parse_header(raw)
    ch = info.channels
    ls_byte = adxcodec.samples_to_stream_byte(ls, ch)
    le_byte = adxcodec.samples_to_stream_byte(le, ch)
    tail_byte = adxcodec.samples_to_stream_byte(xfade_samples, ch)
    end_byte = le_byte + tail_byte
    stream = raw[info.data_offset:info.data_offset + end_byte]
    if len(stream) != end_byte:
        raise ValueError(f'{name}: source too short for the crossfade tail ({len(stream)} < {end_byte}; need {xfade_samples} samples of continuation past loop_end)')
    coef1, coef2 = adxcodec.calc_coeffs(info.cutoff or adxcodec.DEFAULT_CUTOFF, info.sample_rate)
    meta = TrackMeta(sample_rate=info.sample_rate, channels=ch, codec=CODEC_ADX, gain=gain, coef1=coef1, coef2=coef2, name=name, source=source, xfade_enable=1, loop_start_sample=ls, loop_start_byte=ls_byte, loop_end_sample=le, loop_end_byte=le_byte)
    return (stream, meta, {'reencoded': False, 'xfade_samples': xfade_samples, 'tail_bytes': tail_byte})

def _load_fullcov(path: Path):
    """(cmd, trNN, role, char) rows that carry a Saturn track and passed the"""
    rows = []
    for line in path.read_text(encoding='utf-8').splitlines():
        line = line.strip()
        if not line or line.startswith('#') or line.startswith('cmd'):
            continue
        f = line.split('\t')
        if len(f) >= 6 and f[1].startswith('tr') and (f[5] == 'ear_confirmed'):
            rows.append((int(f[0], 0), f[1], f[2], f[3]))
    return rows

def _load_saturn_loops(path: Path):
    """char -> {tr, entry, ls, le, method} from the Saturn-coordinate"""
    out = {}
    for line in path.read_text(encoding='utf-8').splitlines():
        line = line.strip()
        if not line or line.startswith('#') or line.startswith('char'):
            continue
        f = line.split('\t')
        out[int(f[2][1:])] = dict(char=f[0], tr=f[1], ls=int(f[3]), le=int(f[4]), method=f[5])
    return out

def build(disc: str, out: str | None=None, loops_path: str | None=None, trigger_map: str | None=None) -> Path:
    loops = _load_saturn_loops(Path(loops_path) if loops_path else SATURN_LOOPS_TSV)
    map_tsv = Path(trigger_map) if trigger_map else TRIGGER_TSV
    stage_cmds: dict[int, int] = {}
    for line in map_tsv.read_text(encoding='utf-8').splitlines():
        line = line.strip()
        if not line or line.startswith('#') or line.startswith('cmd'):
            continue
        f = line.split('\t')
        stage_cmds[int(f[0], 0)] = int(f[1])
    expect = {}
    for key, entry in protocols.ZERO1_MUSIC_MAP.items():
        cmd = key - ARCADE_JOIN_OFFSET
        if cmd > 0 and entry in STAGE_ENTRIES:
            expect[CMD_REKEY.get(cmd, cmd)] = entry
    if stage_cmds != expect:
        raise AssertionError(f'{map_tsv.name} disagrees with the derivation constants (protocols.ZERO1_MUSIC_MAP + CMD_REKEY)')
    proto = protocols.get_protocol('sfa1')
    w = PackWriter(proto, title='SFA1 arranged soundtrack (SF Alpha Anthology, authored loops)', xfade_samples=XFADE_SAMPLES)
    from .adxencode import read_wav
    from .discsrc import ensure_audio_cache
    fullcov = _load_fullcov(FULLCOV_TSV)
    needed = {lp['tr'] for lp in loops.values()} | {tr for _, tr, _, _ in fullcov}
    ensure_audio_cache(SATURN_CD_DIR, needed, disc, '--disc', pregap='trim')
    track_of_arr: dict[int, int] = {}
    trigger_rows: list[tuple[int, int, int, str, str, int, int]] = []
    for cmd, in_game in sorted(stage_cmds.items()):
        arr = INGAME_TO_ARRANGE[in_game]
        if arr not in loops:
            raise AssertionError(f'no Saturn-loops row for arrange entry {arr} (in-game {in_game}, cmd 0x{cmd:02x})')
        lp = loops[arr]
        if arr not in track_of_arr:
            pcm, rate, ch, n = read_wav(SATURN_CD_DIR / f"{lp['tr']}.wav")
            stream, meta = _pcm_loop_track(pcm, rate, ch, lp['ls'], lp['le'], lp['method'], name=f"{lp['char']}_arr_{lp['tr']}", source=f"sfa1_saturn/{lp['tr']}.wav[0:{n}]")
            track_of_arr[arr] = w.add_track(stream, meta)
        ti = track_of_arr[arr]
        w.set_trigger(cmd, TriggerRow(verb=VERB_PLAY, track=ti, gain=TRIG_GAIN, suppress=1))
        trigger_rows.append((cmd, in_game, arr, lp['char'], lp['method'], lp['ls'], lp['le']))
    c1, c2 = adxcodec.calc_coeffs(adxcodec.DEFAULT_CUTOFF, 44100)
    track_of_tr: dict[str, int] = {}
    n_cov = 0
    for cmd, tr, role, char in sorted(fullcov):
        if tr not in track_of_tr:
            pcm, rate, ch, n = read_wav(SATURN_CD_DIR / f'{tr}.wav')
            stream = adxcodec.encode(pcm, ch, rate)
            meta = TrackMeta(sample_rate=rate, channels=ch, codec=CODEC_ADX, gain=127, coef1=c1, coef2=c2, name=f'{role}_{tr}', source=f'sfa1_saturn/{tr}.wav[0:{n}]')
            if role in FULLCOV_LOOP_ROLES:
                le = n // 32 * 32
                meta.loop_start_sample = 0
                meta.loop_end_sample = le
                meta.loop_start_byte = 0
                meta.loop_end_byte = adxcodec.samples_to_stream_byte(le, ch)
                stream = stream[:meta.loop_end_byte]
            track_of_tr[tr] = w.add_track(stream, meta)
        w.set_trigger(cmd, TriggerRow(verb=VERB_PLAY, track=track_of_tr[tr], gain=TRIG_GAIN, suppress=1))
        n_cov += 1
        kind = 'loop' if role in FULLCOV_LOOP_ROLES else 'once'
        print(f'[sfa1] 0x{cmd:02x} -> {tr} {role:18s} {char:8s} {kind}')
    out_path = Path(out) if out else PACKS_DIR / 'sfa1_arrange.cpk'
    w.write(out_path)
    size = out_path.stat().st_size
    print(f'[sfa1] {out_path}  {size / 1000000.0:.1f} MB, {len(w.tracks)} tracks, {len(trigger_rows) + n_cov} play triggers (single Saturn disc source)')
    print('[sfa1] arcade_cmd  in-game  arrange  char     method     loop_start  loop_end  (44.1k samples)')
    for cmd, ig, arr, char, method, ls, le in trigger_rows:
        print(f'    0x{cmd:02x}        e{ig}    e{arr}   {char:<8} {method:<9} {ls:>9}  {le:>9}')
    return out_path
