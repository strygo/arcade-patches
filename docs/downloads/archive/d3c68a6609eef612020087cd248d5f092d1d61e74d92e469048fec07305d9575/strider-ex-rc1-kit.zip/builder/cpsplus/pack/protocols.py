"""Per-game protocol descriptors and verified command-map data."""
from __future__ import annotations
import dataclasses
from .format import Protocol, FADE_ANTHOLOGY, FADE_HSF2, FADE_NONE, VERB_NONE, VERB_STOP, VERB_FADE_OUT, VERB_FADE_KEEP, VERB_RESTORE, VERB_MASTER_FADE
CONTROL_ANTHOLOGY = {65280: VERB_STOP, 65281: VERB_NONE, 65282: VERB_NONE, 65283: VERB_NONE, 65284: VERB_NONE, 65285: VERB_STOP, 65286: VERB_FADE_OUT, 65287: VERB_FADE_KEEP, 65288: VERB_NONE, 65289: VERB_NONE, 65290: VERB_NONE, 65291: VERB_NONE, 65292: VERB_RESTORE, 65293: VERB_MASTER_FADE}
CONTROL_ALPHA2_ARCADE = {65280: VERB_STOP, 65286: VERB_FADE_KEEP, 65287: VERB_FADE_KEEP}
CONTROL_ALPHA1_ARCADE = {65280: VERB_STOP, 65287: VERB_FADE_KEEP}
CONTROL_SPF2T_ARCADE = {65280: VERB_STOP, 65287: VERB_FADE_KEEP}
CONTROL_CPS15_ARCADE = {65280: VERB_STOP, 65286: VERB_MASTER_FADE, 65287: VERB_MASTER_FADE}
CONTROL_HSF2 = {65280: VERB_STOP, 65287: VERB_FADE_KEEP}
CONTROL_SSF2 = {65280: VERB_STOP, 65287: VERB_FADE_KEEP}
assert CONTROL_SSF2 == CONTROL_HSF2

def _proto(game_id: str, fade_law: int, fc1: int, fc2: int, control: dict, default_verb: int) -> Protocol:
    return Protocol(game_id=game_id, fade_law=fade_law, fade_const1=fc1, fade_const2=fc2, control_verbs=dict(control), control_default_verb=default_verb)

def _cps15(game_id: str, off_arg_byte: int) -> Protocol:
    return Protocol(game_id=game_id, latch_page=15826944, off_cmd_hi=1, off_cmd_lo=3, off_arg_hi=7, off_arg_lo=9, off_arg_byte=off_arg_byte, off_handshake=31, handshake_pending=0, handshake_ready=255, fade_law=FADE_ANTHOLOGY, fade_const1=65535, fade_const2=0, control_default_verb=VERB_NONE, control_region_start=65280, control_verbs=dict(CONTROL_CPS15_ARCADE))
PROTOCOLS: dict[str, Protocol] = {'hsf2': _proto('hsf2', FADE_HSF2, 1092, 60, CONTROL_HSF2, VERB_NONE), 'sfa1': _proto('sfa1', FADE_ANTHOLOGY, 65535, 0, CONTROL_ALPHA1_ARCADE, VERB_NONE), 'sfz2al': _proto('sfz2al', FADE_ANTHOLOGY, 65535, 0, CONTROL_ALPHA2_ARCADE, VERB_NONE), 'sfa2': _proto('sfa2', FADE_ANTHOLOGY, 65535, 0, CONTROL_ALPHA2_ARCADE, VERB_NONE), 'ssf2': _proto('ssf2', FADE_HSF2, 1092, 60, CONTROL_SSF2, VERB_NONE), 'ssf2t': _proto('ssf2t', FADE_HSF2, 1092, 60, CONTROL_SSF2, VERB_NONE), 'sf2': Protocol(game_id='sf2', latch_page=8388992, off_cmd_hi=0, off_cmd_lo=1, off_arg_hi=0, off_arg_lo=0, off_arg_byte=0, off_handshake=0, handshake_pending=0, handshake_ready=247, fade_law=FADE_NONE, fade_const1=0, fade_const2=0, control_default_verb=VERB_NONE, control_region_start=240, control_verbs={247: VERB_STOP}), 'wof': _cps15('wof', off_arg_byte=0), 'dino': _cps15('dino', off_arg_byte=0), 'punisher': _cps15('punisher', off_arg_byte=0), 'slammast': _cps15('slammast', off_arg_byte=5), 'mbombrd': _cps15('mbombrd', off_arg_byte=5)}
PROTOCOLS['hsf2'].off_arg_byte = 0
PROTOCOLS['ssf2'].off_arg_byte = 0
PROTOCOLS['ssf2t'].off_arg_byte = 0
PROTOCOLS['forgottn'] = dataclasses.replace(PROTOCOLS['sf2'], game_id='forgottn', control_verbs={240: VERB_STOP, 241: VERB_STOP})
PROTOCOLS['unsquad'] = dataclasses.replace(PROTOCOLS['sf2'], game_id='unsquad', handshake_ready=240, control_verbs={240: VERB_STOP, 241: VERB_STOP, 242: VERB_STOP, 250: VERB_STOP})
PROTOCOLS['msword'] = dataclasses.replace(PROTOCOLS['sf2'], game_id='msword', handshake_ready=247, control_verbs={240: VERB_STOP, 247: VERB_STOP})
PROTOCOLS['strider'] = dataclasses.replace(PROTOCOLS['sf2'], game_id='strider', handshake_ready=241, control_verbs={240: VERB_STOP, 241: VERB_STOP})
PROTOCOLS['captcomm'] = dataclasses.replace(PROTOCOLS['sf2'], game_id='captcomm', handshake_ready=247, control_verbs={240: VERB_STOP, 242: VERB_STOP, 247: VERB_STOP})
PROTOCOLS['ghouls'] = dataclasses.replace(PROTOCOLS['sf2'], game_id='ghouls', handshake_ready=240, control_verbs={240: VERB_STOP, 241: VERB_STOP, 242: VERB_STOP})
PROTOCOLS['ffightae_cps2'] = _proto('ffightae_cps2', FADE_ANTHOLOGY, 65535, 0, {**CONTROL_ALPHA2_ARCADE, 65285: VERB_STOP}, VERB_NONE)
PROTOCOLS['ffightcps2_ex'] = _proto('ffightcps2_ex', FADE_ANTHOLOGY, 65535, 0, {65285: VERB_STOP}, VERB_NONE)
CONTROL_QSOUND_MINIMAL = {65280: VERB_STOP}

def generic_protocol(game_id: str) -> Protocol:
    """Fallback descriptor for games without Phase-0 data yet: family latch"""
    return _proto(game_id, FADE_ANTHOLOGY, 65535, 0, CONTROL_QSOUND_MINIMAL, VERB_NONE)

def get_protocol(game_id: str) -> Protocol:
    p = PROTOCOLS.get(game_id)
    return p if p else generic_protocol(game_id)
ZERO1_MUSIC_MAP = {65 + i: 97 + i for i in range(97 - 65 + 1)}
ZERO1_MUSIC_MAP.update({104: 130, 105: 131})
ZERO1_TABLE_OFFSET = 61616
ZERO1_CLEAN_ROWS = 2048
ZERO1_TYPE_HISTOGRAM = {0: 1921, 1: 127}
HSF2_ELF_NAME = 'SLPM_654.96'
HSF2_ELF_MD5 = '18c61372fc86c57b60f5e62212aaf734'
HSF2_TABLE_OFFSET = 6529264
HSF2_TABLE_NEEDLE = bytes.fromhex('0000000000000000010000000168000001000000026800000100000003 6c00000100000004680000010000000568000001000000067000000100000007 680000'.replace(' ', ''))
HSF2_TABLE_ROWS = 1280
HSF2_BANKS = {'arrange': 0, 'cps2': 768, 'cps1': 1024}
HSF2_AFS_NAME = 'HSF2.AFS'
HSF2_TYPE_BGM = 1
SF2_STAGE_MUSIC = {1: 2, 2: 3, 3: 5, 5: 7, 4: 1, 6: 4, 7: 6, 8: 8, 9: 9, 10: 10, 11: 11, 12: 12, 13: 59}
SF2_ATTRACT_MUSIC = {22: 51, 14: 52, 15: 53, 20: 58}
SF2_ENDING_MUSIC = {24: 35, 25: 36, 26: 39, 27: 41, 28: 34, 29: 37, 30: 40, 31: 42, 52: 33, 53: 38}
SF2_HURRY_MUSIC = {121: 18, 122: 19, 123: 21, 124: 23, 125: 17, 126: 20, 127: 22, 128: 24, 129: 25, 130: 26, 131: 27, 132: 28}
SF2_CONTINUE_MUSIC = {17: 55}
SF2_CREDITS_MUSIC = {141: 60}
SF2_MUSIC_COMMANDS = set(SF2_STAGE_MUSIC) | set(SF2_ATTRACT_MUSIC) | set(SF2_ENDING_MUSIC) | set(SF2_HURRY_MUSIC) | set(SF2_CONTINUE_MUSIC) | set(SF2_CREDITS_MUSIC)
SF2_CONTROL_BYTES = {240, 247, 255}
SF2_IDLE_BYTE = 255
SF2_TRIGGER_ROWS = 256

def cps1_protocol() -> 'Protocol':
    """The `ffight` descriptor if protocols.py ever grows one, else the tracked"""
    if 'ffight' in PROTOCOLS:
        return PROTOCOLS['ffight']
    proto = dataclasses.replace(PROTOCOLS['sf2'], game_id='ffight')
    if proto.latch_page != 8388992:
        raise ValueError('sf2 descriptor is not the CPS1 byte latch')
    return proto
