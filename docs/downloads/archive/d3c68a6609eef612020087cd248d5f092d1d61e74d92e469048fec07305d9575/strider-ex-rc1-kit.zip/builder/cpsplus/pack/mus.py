"""Saturn MUS stream decoder."""
from __future__ import annotations
import array
import sys
MUS_RATE = 32000
MUS_CHANNELS = 2
BLOCK = 4096
BLOCK_SAMPLES = BLOCK // 2

def decode_mus(data: bytes, swap: bool=False) -> bytes:
    """Decode raw MUS bytes to s16le interleaved stereo PCM bytes."""
    nb = len(data) // BLOCK
    if nb % 2:
        nb -= 1
    data = data[:nb * BLOCK]
    a = array.array('h')
    a.frombytes(data)
    if sys.byteorder == 'little':
        a.byteswap()
    ch0 = array.array('h')
    ch1 = array.array('h')
    for blk in range(0, nb, 2):
        s = blk * BLOCK_SAMPLES
        ch0 += a[s:s + BLOCK_SAMPLES]
        ch1 += a[s + BLOCK_SAMPLES:s + 2 * BLOCK_SAMPLES]
    if swap:
        ch0, ch1 = (ch1, ch0)
    out = array.array('h', bytes(4 * len(ch0)))
    out[0::2] = ch0
    out[1::2] = ch1
    if sys.byteorder == 'big':
        out.byteswap()
    return out.tobytes()
