"""`build_ffightae_cps2_arrange.py` — Final Fight 30th Anniversary CPS2 Edition ARRANGE pack."""
from __future__ import annotations
import argparse
from pathlib import Path
from . import adxcodec, protocols
from .adxencode import encode_adx_track, read_wav
from .audition import verify as audition_verify
from .build_common import MANIFESTS, PACKS_DIR, MapRow, VERBS, _rows
from .build_ffight_arrange import AUTHORED_LOOPS, CD_DIR, LOOPING, ONE_SHOT, XFADE_SAMPLES, ensure_disc_audio
from .format import DEFAULT_TRIGGER_ROWS, PackWriter, PackReader, TrackMeta, TriggerRow, CODEC_ADX, VERB_NONE, VERB_PLAY, VERB_STOP, VERB_NAMES
TRIGGER_TSV = MANIFESTS / 'ffightae_cps2_arrange_trigger_map.tsv'
FFIGHTAE_ROM_BYTES = 46407700
DDR_HARD_CAP_BYTES = 256 * 1024 * 1024
OPENING_TRACK = 'tr25'
OPENING_LOOP = (1056928, 1183904, 1, 1)
TRIG_GAIN = 45

def load_triggers(path: Path=TRIGGER_TSV) -> list[MapRow]:
    """Parse the tracked 16-bit trigger map (same row shapes as the CPS1"""
    out: list[MapRow] = []
    for r in _rows(path):
        if len(r) < 5:
            raise ValueError(f'short row in {path.name}: {r!r}')
        cmd_s, verb_s, sup_s, track_s, cue = (r[0], r[1], r[2], r[3], r[4])
        if verb_s not in VERBS:
            raise ValueError(f'cmd {cmd_s}: unknown verb {verb_s!r}')
        verb = VERBS[verb_s]
        cmd = int(cmd_s, 16)
        if not 0 <= cmd < DEFAULT_TRIGGER_ROWS:
            raise ValueError(f'cmd {cmd_s} outside the CPS2 trigger table')
        track = None if track_s.strip() in ('-', '') else track_s.strip()
        if verb == VERB_PLAY and track is None:
            raise ValueError(f'cmd {cmd_s}: verb=play with no track')
        if verb == VERB_NONE and track is not None:
            raise ValueError(f'cmd {cmd_s}: verb=none must not name a track')
        out.append(MapRow(cmd=cmd, verb=verb, suppress=int(sup_s), track=track, cue=cue))
    seen = set()
    for row in out:
        if row.cmd in seen:
            raise ValueError(f'duplicate command 0x{row.cmd:04x} in {path.name}')
        seen.add(row.cmd)
    return out

def build(out: str | None=None, triggers_path: str | None=None, cd_dir: str | None=None, measure_snr: bool=True, us_disc: str | None=None) -> dict:
    rows = load_triggers(Path(triggers_path) if triggers_path else TRIGGER_TSV)
    cd = Path(cd_dir) if cd_dir else CD_DIR
    needed = {r.track for r in rows if r.track}
    ensure_disc_audio(cd, needed, us_disc, '--us-disc')
    tracks = [r.track for r in rows if r.track]
    unknown = sorted(set(tracks) - LOOPING - ONE_SHOT)
    if unknown:
        raise ValueError(f'tracks with no loop treatment decided: {unknown}')
    proto = protocols.PROTOCOLS['ffightae_cps2']
    if proto.latch_page != 6389760:
        raise ValueError('ffightae_cps2 descriptor is not the CPS2 QSound latch')
    w = PackWriter(proto, title='Final Fight 30th Anniversary CPS2 Edition (Arrange)', trigger_rows=DEFAULT_TRIGGER_ROWS, default_rate=44100, xfade_samples=XFADE_SAMPLES)
    ti_of: dict[str, int] = {}
    snrs: list[tuple[str, float]] = []
    print('[ffightae_cps2] === adx ===')
    for row in rows:
        if row.verb == VERB_NONE:
            if row.suppress == 0:
                print(f'[ffightae_cps2] 0x{row.cmd:04x} -> (fail open, not written)  {row.cue}')
                continue
            w.set_trigger(row.cmd, TriggerRow(verb=VERB_NONE, track=0, gain=127, suppress=row.suppress))
            print(f'[ffightae_cps2] 0x{row.cmd:04x} -> (silence, no restart)  {row.cue}')
            continue
        track = row.track
        if track not in ti_of:
            src = cd / f'{track}.wav'
            pcm, rate, ch, n = read_wav(src)
            loops = track in LOOPING
            authored = OPENING_LOOP if track == OPENING_TRACK else AUTHORED_LOOPS.get(track)
            data, coef1, coef2, snr = encode_adx_track(pcm, rate, ch, n, track, measure_snr)
            if snr is not None:
                snrs.append((track, snr))
            if adxcodec.samples_to_stream_byte(0, ch) != 0:
                raise ValueError('loop start not frame-aligned')
            loop_end_byte = len(data) if loops else 0
            loop_end_sample = n if loops else 0
            if loops and loop_end_byte % (adxcodec.FRAME_BYTES * ch):
                raise ValueError(f'{track}: loop end not frame-aligned')
            if authored:
                als, ale, axf, acnt = authored
                loop_start_sample, loop_start_byte = (als, adxcodec.samples_to_stream_byte(als, ch))
                loop_end_sample, loop_end_byte = (ale, adxcodec.samples_to_stream_byte(ale, ch))
                if axf and acnt == 0:
                    tail = XFADE_SAMPLES // 32 * 18 * ch
                    data = data[:loop_end_byte + tail]
            else:
                loop_start_sample = loop_start_byte = 0
            kind = ('inner loop' if authored[3] == 0 else 'finite loop') if authored else 'whole-track loop' if loops else 'one_shot'
            meta = TrackMeta(sample_rate=rate, channels=ch, codec=CODEC_ADX, gain=127, loop_start_sample=loop_start_sample, loop_start_byte=loop_start_byte, loop_end_sample=loop_end_sample, loop_end_byte=loop_end_byte, coef1=coef1, coef2=coef2, xfade_enable=authored[2] if authored else 0, loop_count=authored[3] if authored else 0, name=f'{track} ({kind})', source=f'ffightcd/cd_full/{track}.wav[0:{n}]')
            ti_of[track] = w.add_track(data, meta)
            print(f"[ffightae_cps2] 0x{row.cmd:04x} -> {track} track{ti_of[track]:<3} {n / rate:7.2f}s  {('loop ' if loops else 'once ')}  {len(data) / 1000000.0:7.2f} MB  {row.cue}")
        else:
            print(f"[ffightae_cps2] 0x{row.cmd:04x} -> {track} track{ti_of[track]:<3} {'(shared)':>22}  {row.cue}")
        w.set_trigger(row.cmd, TriggerRow(verb=VERB_PLAY, track=ti_of[track], gain=TRIG_GAIN, suppress=row.suppress))
    out_path = Path(out) if out else PACKS_DIR / 'ffightae_cps2_arrange.cpk'
    w.write(out_path)
    size = out_path.stat().st_size
    rd = PackReader(out_path)
    try:
        for row in rows:
            if row.verb == VERB_NONE and row.suppress == 0:
                got = rd.triggers[row.cmd]
                if got.verb != VERB_NONE or got.suppress != 0:
                    raise ValueError(f'readback: fail-open 0x{row.cmd:04x} has bytes written')
                continue
            got = rd.triggers[row.cmd]
            if got.verb != row.verb or got.suppress != row.suppress:
                raise ValueError(f'readback: cmd 0x{row.cmd:04x} is verb {VERB_NAMES[got.verb]}/suppress {got.suppress}, expected {VERB_NAMES[row.verb]}/{row.suppress}')
            if row.verb == VERB_PLAY and got.track != ti_of[row.track]:
                raise ValueError(f'readback: cmd 0x{row.cmd:04x} wrong track')
        for cmd in range(256):
            got = rd.triggers[cmd]
            if got.verb != VERB_NONE or got.suppress != 0:
                raise ValueError(f'readback: byte row 0x{cmd:02x} is not empty in a CPS2-only pack')
        if rd.header.proto.latch_page != 6389760:
            raise ValueError('readback: latch page is not the CPS2 dialect')
        if rd.header.trigger_rows != DEFAULT_TRIGGER_ROWS:
            raise ValueError('readback: trigger table is not 0x1200 rows')
        for stop in (65280, 65285):
            if rd.header.proto.control_verbs.get(stop) != VERB_STOP:
                raise ValueError(f'readback: control 0x{stop:04x} is not STOP')
    finally:
        rd.close()
    image = size + FFIGHTAE_ROM_BYTES
    n_play = sum((1 for r in rows if r.verb == VERB_PLAY))
    print(f'[ffightae_cps2] {out_path}')
    print(f'[ffightae_cps2]   pack        {size:,} B ({size / 1000000.0:.1f} MB), {len(w.tracks)} tracks, {n_play} play triggers, gain 0x{TRIG_GAIN:02x}')
    print(f'[ffightae_cps2]   + ROM       {FFIGHTAE_ROM_BYTES:,} B = image {image:,} B ({image / 1000000.0:.1f} MB)')
    over = image - DDR_HARD_CAP_BYTES
    verdict = f'OVER by {over:,} B' if over > 0 else f'fits, {-over:,} B ({-over / 1000000.0:.1f} MB) headroom'
    print(f'[ffightae_cps2]   256 MiB cap -> {100.0 * image / DDR_HARD_CAP_BYTES:.1f}% — {verdict}')
    if image > DDR_HARD_CAP_BYTES:
        raise SystemExit('[ffightae_cps2] image exceeds the DDR cap')
    if snrs:
        worst = min(snrs, key=lambda s: s[1])
        mean = sum((s for _, s in snrs)) / len(snrs)
        print(f'[ffightae_cps2]   ADX SNR: mean {mean:.2f} dB, worst {worst[0]} {worst[1]:.2f} dB')
    return {'path': out_path, 'size': size, 'image': image, 'tracks': len(w.tracks), 'snrs': snrs}

def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog='python -m cpsplus.pack.build_ffightae_cps2_arrange')
    ap.add_argument('--out')
    ap.add_argument('--triggers')
    ap.add_argument('--cd-dir')
    ap.add_argument('--us-disc', help='US Final Fight CD rip: a .cue, or a .zip/.7z containing one (needed when the extraction cache is empty)')
    ap.add_argument('--no-snr', action='store_true')
    ap.add_argument('--no-verify', action='store_true')
    a = ap.parse_args(argv)
    res = build(out=a.out, triggers_path=a.triggers, cd_dir=a.cd_dir, measure_snr=not a.no_snr, us_disc=a.us_disc)
    if not a.no_verify and (not audition_verify(str(res['path']))):
        raise SystemExit(f"verification FAILED for {res['path']}")
    return 0
if __name__ == '__main__':
    raise SystemExit(main())
