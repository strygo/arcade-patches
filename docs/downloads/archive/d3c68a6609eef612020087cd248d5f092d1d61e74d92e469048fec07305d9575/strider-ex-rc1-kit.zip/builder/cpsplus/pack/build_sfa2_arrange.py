"""`build_pack.py saturn-mus` — SFZ2 pack from the Saturn disc(s), for the"""
from __future__ import annotations
import re
import struct
from pathlib import Path
from . import adxcodec, protocols
from .build_common import MANIFESTS, PACKS_DIR, REPO_ROOT
from .format import PackWriter, TrackMeta, TriggerRow, CODEC_ADX, VERB_PLAY, VERB_STOP
from .isofs import IsoFS
from .mus import decode_mus, MUS_RATE, MUS_CHANNELS
from .sources import resolve_image
TRIG_GAIN = {'sfa2': 37, 'sfz2al': 37}
ADX_ENTRY_BASE = 169
SATURN_MAP_TSV = MANIFESTS / 'sfz2_saturn_zero6_map.tsv'
LOOPTABLE_TSV = MANIFESTS / 'sfz2_saturn_looptable.tsv'

class SaturnDisc:
    """One Saturn data track: its MUS files and 0.BIN control table."""

    def __init__(self, image: Path):
        self.image = image
        self.iso = IsoFS(image)
        self.songs: dict[int, dict[int, tuple[int, int]]] = {}
        for full, lba, size, isdir in self.iso.entries():
            m = re.fullmatch('/S([0-9A-F]{2})([01])\\.MUS', full.upper())
            if m and (not isdir):
                sid, part = (int(m.group(1), 16), int(m.group(2)))
                self.songs.setdefault(sid, {})[part] = (lba, size)
        if not self.songs:
            from .build_common import is_playstation_disc
            if is_playstation_disc(self.iso):
                raise SystemExit(f'{image} is the PLAYSTATION release -- only the Saturn discs carry the MUS masters these packs use (see pack/README.md for the verified Saturn carriers)')
            raise ValueError(f'no SXX[01].MUS files on {image}')
        self.flags = self._control_flags()

    def _control_flags(self) -> dict[int, tuple[int, int]]:
        """song id -> (pair_flag, loop_forever_flag) from 0.BIN."""
        bin0 = self.iso.read_file('/0.BIN')
        expect = {sid: 1 if 1 in parts else 0 for sid, parts in self.songs.items()}
        max_id = max(expect)
        hits = []
        for base in range(0, len(bin0) - (max_id + 1) * 8):
            for sid, pair in expect.items():
                o = base + sid * 8
                if bin0[o] != pair or bin0[o + 7] not in (0, 255):
                    break
            else:
                hits.append(base)
        if len(hits) != 1:
            raise ValueError(f'0.BIN control-table search on {self.image.name}: {len(hits)} hits {[hex(h) for h in hits[:4]]} (need 1)')
        base = hits[0]
        print(f'[saturn] {self.image.name}: control table at 0.BIN+0x{base:x} ({len(self.songs)} songs)')
        return {sid: (bin0[base + sid * 8], bin0[base + sid * 8 + 7]) for sid in self.songs}

    def read_song_pcm(self, sid: int) -> tuple[bytes, int]:
        """Return (s16le stereo PCM, intro_frames) for a song."""
        parts = self.songs[sid]
        intro = decode_mus(self.iso.read_extent(*parts[0]))
        if 1 in parts:
            loop = decode_mus(self.iso.read_extent(*parts[1]))
            return (intro + loop, len(intro) // 4)
        return (intro, 0)

def _load_trigger_map_tsv(path: Path) -> tuple[dict[int, tuple[int, int | None]], list[int]]:
    """Trigger map TSV -> ({cmd: (song_id, gain or None)}, [stop_cmds])."""
    plays: dict[int, tuple[int, int | None]] = {}
    stops: list[int] = []
    for line in Path(path).read_text(encoding='utf-8').splitlines():
        line = line.strip()
        if not line or line.startswith('#') or line.lower().startswith('cmd'):
            continue
        f = line.split('\t')
        cmd = int(f[0], 0)
        if len(f) > 2 and f[2] == 'stop':
            stops.append(cmd)
            continue
        gain = None
        if len(f) > 2 and f[2] not in ('play', ''):
            gain = int(f[2], 0)
        plays[cmd] = (int(f[1], 16), gain)
    return (plays, stops)

def build(iso_path: str, out: str | None=None, game: str='sfz2al', trigger_map: str | None=None, crosscheck: bool=True) -> Path:
    discs = [SaturnDisc(resolve_image(iso_path, member_hint='(Track 1).bin'))]
    if not trigger_map:
        cand = MANIFESTS / f'{game}_arrange_trigger_map.tsv'
        if not cand.exists():
            raise ValueError(f'no verified trigger map for game {game!r} — this needs a Phase-0 command trace; pass --trigger-map')
        trigger_map = cand
    plays, stops = _load_trigger_map_tsv(Path(trigger_map))
    print(f'[saturn] trigger map from {trigger_map}: {len(plays)} play + {len(stops)} stop rows')
    if game == 'sfz2al' and SATURN_MAP_TSV.exists():
        want = {}
        for line in SATURN_MAP_TSV.read_text(encoding='utf-8').splitlines():
            if line.startswith('#') or line.startswith('saturn_song'):
                continue
            f = line.split('\t')
            if f[3] != '-':
                want[int(f[3], 0)] = int(f[0], 16)
        got = {c: s for c, (s, _) in plays.items()}
        if got != want:
            raise AssertionError(f'{Path(trigger_map).name} cmd->song rows differ from {SATURN_MAP_TSV.name}')
    ref = {}
    if LOOPTABLE_TSV.exists():
        rows = LOOPTABLE_TSV.read_text(encoding='utf-8').splitlines()
        hdr = rows[0].split('\t')
        for line in rows[1:]:
            f = dict(zip(hdr, line.split('\t')))
            ref[int(f['song'], 16)] = (int(f['intro_bytes']), int(f['loop_len_frames']))
    proto = protocols.get_protocol(game)
    w = PackWriter(proto, title=f'{game} Saturn MUS arranged soundtrack', default_rate=MUS_RATE)
    coef1, coef2 = adxcodec.calc_coeffs(adxcodec.DEFAULT_CUTOFF, MUS_RATE)
    all_songs = sorted({sid for d in discs for sid in d.songs})
    if game == 'sfa2':
        all_songs = [s for s in all_songs if s <= 59]
    track_of_song: dict[int, int] = {}
    src_pcm: dict[int, bytes] = {}
    for sid in all_songs:
        disc = next((d for d in discs if sid in d.songs))
        pair_flag, loop_forever = disc.flags[sid]
        pcm, intro_frames = disc.read_song_pcm(sid)
        total_frames = len(pcm) // 4
        if sid in ref:
            r_intro_b, r_loop_f = ref[sid]
            if r_intro_b != intro_frames * 4 or r_loop_f != total_frames - intro_frames:
                print(f'[warn] song {sid:02X}: disc sizes differ from {LOOPTABLE_TSV.name} ({intro_frames * 4}/{total_frames - intro_frames} vs {r_intro_b}/{r_loop_f})')
        loops = loop_forever == 255
        if pair_flag and (not loops):
            print(f'[note] song {sid:02X}: intro+body pair played once (0.BIN byte7=00) — packed as one-shot')
        stream = adxcodec.encode(pcm, MUS_CHANNELS, MUS_RATE)
        meta = TrackMeta(sample_rate=MUS_RATE, channels=MUS_CHANNELS, codec=CODEC_ADX, gain=127, coef1=coef1, coef2=coef2, name=f'S{sid:02X}', source=disc.image.name)
        if loops:
            loop_start, loop_end = (intro_frames, total_frames)
            meta.loop_start_sample = loop_start
            meta.loop_end_sample = loop_end
            meta.loop_start_byte = adxcodec.samples_to_stream_byte(loop_start, MUS_CHANNELS)
            meta.loop_end_byte = adxcodec.samples_to_stream_byte(loop_end, MUS_CHANNELS)
            stream = stream[:meta.loop_end_byte]
        ti = w.add_track(stream, meta)
        track_of_song[sid] = ti
        if crosscheck and len(src_pcm) < 2 and loops and intro_frames:
            src_pcm[ti] = pcm
    n_play = 0
    for cmd, (sid, gain) in sorted(plays.items()):
        if sid not in track_of_song:
            raise SystemExit(f"cmd 0x{cmd:02x} -> song {sid:02X} is not on this disc — wrong disc for game {game!r}? (sfz2al needs the SFZ2' dash disc, which carries all 60 songs)")
        w.set_trigger(cmd, TriggerRow(verb=VERB_PLAY, track=track_of_song[sid], gain=TRIG_GAIN.get(game, min(gain if gain is not None else 96, 127)), suppress=1))
        n_play += 1
    for cmd in stops:
        w.set_trigger(cmd, TriggerRow(verb=VERB_STOP, suppress=0))
    out_path = Path(out) if out else PACKS_DIR / f'{game}_arrange.cpk'
    w.write(out_path)
    size = out_path.stat().st_size
    print(f'[saturn] {out_path}  {size / 1000000.0:.1f} MB, {len(w.tracks)} tracks, {n_play} play + {len(stops)} stop triggers')
    if crosscheck and src_pcm:
        from .format import PackReader
        rd = PackReader(out_path)
        for ti, pcm in src_pcm.items():
            m = rd.tracks[ti]
            n = m.data_length // 36 * 32
            dec = adxcodec.decode(rd.read_track(ti), 2, MUS_RATE, total_samples=n)
            ncc = _ncc(pcm, dec, MUS_RATE * 5)
            print(f'[saturn] track {ti} ({m.name}) encode fidelity NCC (first 5 s) = {ncc:.4f}')
            if ncc < 0.9:
                raise AssertionError(f'track {ti}: ADX encode NCC {ncc:.3f} < 0.90 — encoder problem?')
        rd.close()
    for d in discs:
        d.iso.close()
    return out_path

def _ncc(a_pcm: bytes, b_pcm: bytes, frames: int) -> float:
    """Normalized cross-correlation of two s16le stereo buffers at lag 0."""
    import array
    n = min(len(a_pcm), len(b_pcm), frames * 4) // 2
    a = array.array('h')
    a.frombytes(a_pcm[:n * 2])
    b = array.array('h')
    b.frombytes(b_pcm[:n * 2])
    sab = saa = sbb = 0
    for x, y in zip(a, b):
        sab += x * y
        saa += x * x
        sbb += y * y
    return sab / ((saa * sbb) ** 0.5 + 1e-09)
