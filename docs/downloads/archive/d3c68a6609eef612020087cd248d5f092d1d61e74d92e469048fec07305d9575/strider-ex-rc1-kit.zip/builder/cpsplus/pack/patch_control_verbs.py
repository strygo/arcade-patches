"""Patch the control-verb map of an already-built CPS+ pack, in place."""
import argparse
import struct
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from pack.format import MAGIC, MAX_CONTROL_VERBS, VERB_NONE, VERB_STOP, VERB_FADE_OUT, VERB_FADE_KEEP, VERB_RESTORE, VERB_MASTER_FADE, _HDR_PROTO
PROTO_OFF = 140
VERBS_OFF = 168
NVERBS_FIELD = -1
VERB_NAMES = {'none': VERB_NONE, 'stop': VERB_STOP, 'fade_out': VERB_FADE_OUT, 'fade_keep': VERB_FADE_KEEP, 'restore': VERB_RESTORE, 'master_fade': VERB_MASTER_FADE}
VERB_REV = {v: k for k, v in VERB_NAMES.items()}

def read_map(hdr: bytes):
    """-> (control_default_verb, control_region_start, {cmd: verb})"""
    fields = _HDR_PROTO.unpack_from(hdr, PROTO_OFF)
    dverb, cstart, nverbs = (fields[10], fields[11], fields[NVERBS_FIELD])
    verbs = {}
    for i in range(nverbs):
        cmd, verb, _ = struct.unpack_from('<HBB', hdr, VERBS_OFF + 4 * i)
        verbs[cmd] = verb
    return (dverb, cstart, verbs)

def write_map(hdr: bytearray, verbs: dict, default_verb: int | None=None):
    if len(verbs) > MAX_CONTROL_VERBS:
        raise ValueError(f'too many control verbs ({len(verbs)} > {MAX_CONTROL_VERBS})')
    fields = list(_HDR_PROTO.unpack_from(hdr, PROTO_OFF))
    if default_verb is not None:
        fields[10] = default_verb
    fields[NVERBS_FIELD] = len(verbs)
    _HDR_PROTO.pack_into(hdr, PROTO_OFF, *fields)
    off = VERBS_OFF
    for cmd, verb in sorted(verbs.items()):
        struct.pack_into('<HBB', hdr, off, cmd, verb, 0)
        off += 4
    while off < VERBS_OFF + 4 * MAX_CONTROL_VERBS:
        struct.pack_into('<HBB', hdr, off, 0, 0, 0)
        off += 4
    return hdr

def _fmt(dverb, cstart, verbs):
    body = ', '.join((f'0x{c:04x}->{VERB_REV.get(v, v)}' for c, v in sorted(verbs.items())))
    return f'default={VERB_REV.get(dverb, dverb)} region_start=0x{cstart:04x} n={len(verbs)}' + (f'  [{body}]' if verbs else '  [empty]')

def run(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('pack', nargs='?', type=Path)
    ap.add_argument('--set', action='append', default=[], metavar='CMD=VERB', help='map a command to a verb, e.g. 0xf7=stop (repeatable)')
    ap.add_argument('--default-verb', choices=sorted(VERB_NAMES), help='control-region default verb (leave alone unless sure: an idle byte sent every frame would fire it)')
    ap.add_argument('--clear', action='store_true', help='drop existing entries first')
    ap.add_argument('--substitute-byte', metavar='HEX', help="byte the tap feeds the sound CPU while suppressing a mapped command (proto field handshake_ready). 0xff (idle) leaves the native driver's music running, which desyncs it when only SOME cues are mapped: it never receives the command that would have changed its music. 0xf7 (section stop) silences it instead -- measured safe on sf2 (native music stops and a later command still starts a song).")
    ap.add_argument('--show', action='store_true', help='print the map and exit')
    ap.add_argument('--self-test', action='store_true')
    args = ap.parse_args(argv)
    if args.self_test:
        return _selftest()
    if not args.pack:
        ap.error('pack is required')
    hdr = bytearray(args.pack.open('rb').read((OFF_END := (296 + 2))))
    if bytes(hdr[:4]) != MAGIC:
        raise SystemExit(f'{args.pack}: not a CPS+ pack (magic {bytes(hdr[:4])!r})')
    dverb, cstart, verbs = read_map(hdr)
    if args.show or not (args.set or args.default_verb or args.clear or args.substitute_byte):
        print(f'{args.pack.name}: {_fmt(dverb, cstart, verbs)}')
        return 0
    before = _fmt(dverb, cstart, verbs)
    if args.clear:
        verbs = {}
    for item in args.set:
        k, _, v = item.partition('=')
        if v.lower() not in VERB_NAMES:
            raise SystemExit(f'unknown verb {v!r}; pick from {sorted(VERB_NAMES)}')
        cmd = int(k, 0)
        if cmd < cstart:
            raise SystemExit(f"command 0x{cmd:04x} is below this pack's control region start 0x{cstart:04x} -- it would never be treated as a control command")
        verbs[cmd] = VERB_NAMES[v.lower()]
    dv = VERB_NAMES[args.default_verb] if args.default_verb else None
    write_map(hdr, verbs, dv)
    if args.substitute_byte is not None:
        sb = int(args.substitute_byte, 0) & 255
        f = list(_HDR_PROTO.unpack_from(hdr, PROTO_OFF))
        f[8] = sb
        _HDR_PROTO.pack_into(hdr, PROTO_OFF, *f)
        print(f'  substitute byte -> 0x{sb:02x}')
    with args.pack.open('r+b') as fh:
        fh.write(bytes(hdr))
    d2, c2, v2 = read_map(bytes(args.pack.open('rb').read(298)))
    print(f'{args.pack.name}:\n  before: {before}\n  after : {_fmt(d2, c2, v2)}')
    return 0

def _selftest():
    hdr = bytearray(298)
    hdr[:4] = MAGIC
    _HDR_PROTO.pack_into(hdr, PROTO_OFF, 8388992, 0, 1, 0, 0, 0, 0, 0, 255, 0, VERB_NONE, 240, 0, 0, 0)
    d, c, v = read_map(bytes(hdr))
    assert (d, c, v) == (VERB_NONE, 240, {}), (d, c, v)
    write_map(hdr, {247: VERB_STOP})
    d, c, v = read_map(bytes(hdr))
    assert v == {247: VERB_STOP} and d == VERB_NONE and (c == 240), (d, c, v)
    write_map(hdr, {247: VERB_STOP, 248: VERB_RESTORE})
    write_map(hdr, {247: VERB_STOP})
    assert read_map(bytes(hdr))[2] == {247: VERB_STOP}, read_map(bytes(hdr))[2]
    print('patch_control_verbs self-test: PASS')
    return 0
if __name__ == '__main__':
    sys.exit(run())
