"""Build the MS-DOS Super Street Fighter II Turbo packs (OPL / GS / MT-32 / CD)."""
from __future__ import annotations
import argparse
import csv
import json
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path
import numpy as np
from . import adxcodec, ssf2_family
from .adxencode import encode_adx_track
from .build_common import MANIFESTS, PACKS_DIR
from .format import CODEC_ADX, VERB_NONE, VERB_PLAY, PackReader, PackWriter, TrackMeta, TriggerRow
MAP_TSV = MANIFESTS / 'ssf2t_dos_map.tsv'
CD_MAP_TSV = MANIFESTS / 'ssf2t_dos_cd_map.tsv'
TRIGGER_ROWS = 4608
CHANNELS = 2
NATIVE_RESTORE_CMDS = frozenset({56})
CD_VS_CMD = 53

def cd_vs_trigger(track_of: dict[str, int], gain: int) -> TriggerRow:
    """Fail closed rather than reintroducing native VS/stage overlap."""
    if 'VERS' not in track_of:
        raise ValueError('CD VS requires VERS.flac and one-shot metadata; re-extract the disc instead of using an older FLAC cache')
    return TriggerRow(verb=VERB_PLAY, track=track_of['VERS'], gain=gain, suppress=1)

def apply_device_policy(writer: PackWriter, device: str, track_of: dict[str, int]) -> None:
    if device == 'cd':
        missing = {'VERS', 'E_CHN1', 'HI_SCO', 'CD_GAME_OVER'} - track_of.keys()
        if missing:
            raise ValueError(f'CD is missing confirmed cues {sorted(missing)}; re-extract the disc')
        writer.set_trigger(CD_VS_CMD, cd_vs_trigger(track_of, DEVICES[device].trigger_gain))
    else:
        if 'CONTJ' not in track_of:
            raise ValueError('MIDI game over requires CONTJ; re-render the installed sequence')
        writer.set_trigger(57, TriggerRow(verb=VERB_PLAY, track=track_of['CONTJ'], gain=DEVICES[device].trigger_gain, suppress=1))

def self_test() -> int:
    assert cd_vs_trigger({'VERS': 54}, 39) == TriggerRow(verb=VERB_PLAY, track=54, gain=39, suppress=1)
    try:
        cd_vs_trigger({}, 39)
    except ValueError:
        pass
    else:
        raise AssertionError('missing VERS must refuse the build')
    assert load_cd_loops()['VERS'] is None
    assert any((r.command == CD_VS_CMD and r.song == 'VERS' for r in load_map()))
    cd = {r.command: r.song for r in load_device_map('cd')}
    fm = {r.command: r.song for r in load_device_map('fm')}
    assert cd[37] == 'E_CHN1' and cd[57] == 'CD_GAME_OVER'
    assert 37 not in fm and fm[57] == 'CONTJ'
    assert cd[54] == fm[54] == 'GAMEO'
    try:
        apply_device_policy(None, 'cd', {'VERS': 54})
    except ValueError:
        pass
    else:
        raise AssertionError('missing confirmed CD sources must refuse the build')
    try:
        apply_device_policy(None, 'fm', {})
    except ValueError:
        pass
    else:
        raise AssertionError('missing CONTJ must refuse MIDI builds')
    print('PASS CD VS: suppressed PLAY, one-shot, missing-source refusal')
    return 0
CD_LOOPS_TSV = MANIFESTS / 'ssf2t_dos_cd_bargrid.tsv'

@dataclass(frozen=True)
class Device:
    key: str
    letter: str
    rate: int
    trigger_gain: int
    pack_name: str
    title: str
    note: str
DEVICES = {'fm': Device('fm', 'F', 49716, 89, 'ssf2_dos_fm.cpk', 'Super Street Fighter II Turbo (MS-DOS FM Soundtrack)', "Nuked OPL3 at its own 49716 Hz, one chip, the disc's own banks"), 'sc55': Device('sc55', 'G', 48000, 21, 'ssf2_dos_sc55.cpk', 'Super Street Fighter II Turbo (MS-DOS Sound Canvas Soundtrack)', "Nuked-SC55, the disc's sc55 preset device"), 'mt32': Device('mt32', 'M', 48000, 34, 'ssf2_dos_mt32.cpk', 'Super Street Fighter II Turbo (MS-DOS MT-32 Soundtrack)', "Munt mt32_1_07, the disc's mt32 preset device"), 'cd': Device('cd', '', 44100, 39, 'ssf2_dos_cd.cpk', 'Super Street Fighter II Turbo (MS-DOS CD Soundtrack)', "the disc's own Red Book audio")}

def load_cd_loops(path: Path=CD_LOOPS_TSV) -> dict[str, tuple[float, float] | None]:
    """piece -> (loop_start, loop_end) in seconds, None for a one-shot."""
    out: dict[str, tuple[float, float] | None] = {}
    with path.open(newline='', encoding='utf-8') as handle:
        for row in csv.DictReader((line for line in handle if line.strip() and (not line.startswith('#'))), delimiter='\t'):
            if row['confidence'] == 'one-shot':
                out[row['piece']] = None
            elif row['confidence'] in ('high', 'medium'):
                out[row['piece']] = (float(row['loop_start']), float(row['loop_end']))
    return out

@dataclass(frozen=True)
class Row:
    command: int
    role: str
    song: str
    confidence: str

def load_map(path: Path=MAP_TSV) -> list[Row]:
    rows: list[Row] = []
    seen: set[int] = set()
    with path.open(newline='', encoding='utf-8') as handle:
        for raw in csv.DictReader((line for line in handle if line.strip() and (not line.startswith('#'))), delimiter='\t'):
            command = int(raw['cmd'], 0)
            if command in seen:
                raise ValueError(f'duplicate command 0x{command:02x}')
            if command in NATIVE_RESTORE_CMDS:
                raise ValueError(f'0x{command:02x} is restore-class and must stay unmapped')
            seen.add(command)
            rows.append(Row(command, raw['role'], raw['dos_song'], raw['confidence']))
    if not rows:
        raise ValueError(f'{path}: no rows')
    return rows

def load_device_map(device: str, path: Path=MAP_TSV) -> list[Row]:
    """CD-only recordings must not fabricate missing MIDI sequences."""
    rows = {r.command: r for r in load_map(path)}
    if device == 'cd':
        rows.update({r.command: r for r in load_map(CD_MAP_TSV)})
    return [rows[cmd] for cmd in sorted(rows)]

def probe(path: Path) -> tuple[int, int, dict[str, int]]:
    out = subprocess.run([adxcodec.ffprobe_exe(), '-v', 'error', '-select_streams', 'a:0', '-show_entries', 'stream=sample_rate,channels:format_tags', '-of', 'json', str(path)], capture_output=True, text=True, check=True).stdout
    info = json.loads(out)
    stream = info['streams'][0]
    tags = {key.upper(): int(value) for key, value in info.get('format', {}).get('tags', {}).items() if key.upper().startswith('LOOP') and value.lstrip('-').isdigit()}
    return (int(stream['sample_rate']), int(stream['channels']), tags)

def decode(path: Path) -> np.ndarray:
    """The FLAC's samples as s16 frames."""
    raw = subprocess.run([adxcodec.FFMPEG, '-v', 'error', '-i', str(path), '-map', '0:a:0', '-f', 's32le', '-acodec', 'pcm_s32le', '-'], capture_output=True, check=True).stdout
    s32 = np.frombuffer(raw, dtype='<i4')
    if s32.size % CHANNELS:
        raise ValueError(f'{path.name}: decoded PCM ends mid-frame')
    return (s32 >> 16).astype('<i2').reshape(-1, CHANNELS)

def source_name(stem: str, letter: str) -> str:
    """The rendered file's stem for a map entry on a given device."""
    if not letter:
        return stem
    return f'{stem}{letter}' if stem.endswith('_KO') else f'{stem}_{letter}'

def _align32(value: int) -> int:
    return value // 32 * 32

def xfade_samples(rate: int) -> int:
    """One second of crossfade, rounded down to the ADX frame grid."""
    return _align32(rate)

def build(*, device: str, flac_dir: Path, out: Path | None=None, map_path: Path=MAP_TSV, measure_snr: bool=False) -> dict:
    spec = DEVICES[device]
    rows = load_device_map(device, map_path)
    proto = ssf2_family.PROTOCOL
    ssf2_family.check_protocol(proto)
    cd_loops = load_cd_loops() if device == 'cd' else None
    writer = PackWriter(proto, title=spec.title, trigger_rows=TRIGGER_ROWS, default_rate=spec.rate, xfade_samples=xfade_samples(spec.rate))
    track_of: dict[str, int] = {}
    unbuilt: list[str] = []
    snrs: list[tuple[str, float]] = []
    loops = 0
    print(f'[ssf2t-dos:{device}] === {spec.title} ===')
    print(f'[ssf2t-dos:{device}] {spec.note}; trigger gain 0x{spec.trigger_gain:02x}')
    for song in sorted({row.song for row in rows}):
        if cd_loops is not None and song not in cd_loops:
            unbuilt.append(song)
            continue
        source = flac_dir / f'{source_name(song, spec.letter)}.flac'
        if not source.is_file():
            if cd_loops is not None:
                unbuilt.append(song)
                continue
            raise FileNotFoundError(f'missing rendered source: {source}')
        rate, channels, tags = probe(source)
        if (rate, channels) != (spec.rate, CHANNELS):
            raise ValueError(f'{source.name}: {rate} Hz/{channels}ch, expected {spec.rate} Hz stereo')
        pcm = decode(source)
        if cd_loops is not None:
            span = cd_loops[song]
            if span is not None and song.endswith('_KO'):
                span = None
            if span is None:
                keep, ls, le, xfade_enable, kind = (len(pcm), 0, 0, 0, 'one-shot')
            else:
                xfade = xfade_samples(spec.rate)
                ls = _align32(round(span[0] * spec.rate))
                le = _align32(round(span[1] * spec.rate))
                if le - ls <= xfade:
                    raise ValueError(f'{source.name}: loop shorter than the crossfade')
                keep = le + xfade
                if keep > len(pcm):
                    raise ValueError(f'{source.name}: needs {keep} frames for the crossfade tail but the piece holds {len(pcm)}')
                pcm = pcm[:keep]
                xfade_enable, kind = (1, 'xfade loop')
                loops += 1
        elif 'LOOPSTART' in tags:
            source_ls, source_le = (tags['LOOPSTART'], tags['LOOPEND'])
            if source_le != len(pcm):
                raise ValueError(f'{source.name}: LOOPEND {source_le} but the file holds {len(pcm)} frames; the render must end on its loop')
            xfade = xfade_samples(spec.rate)
            pack_ls, pack_le = (_align32(source_ls - xfade), _align32(source_le - xfade))
            if pack_ls < 0:
                raise ValueError(f'{source.name}: loop starts inside the crossfade')
            if pack_le - pack_ls <= xfade:
                raise ValueError(f'{source.name}: loop body shorter than the crossfade')
            keep = pack_le + xfade
            if keep > len(pcm):
                raise ValueError(f'{source.name}: crossfade tail runs past the file')
            pcm = pcm[:keep]
            ls, le, xfade_enable, kind = (pack_ls, pack_le, 1, 'xfade loop')
            loops += 1
        else:
            keep, ls, le, xfade_enable, kind = (len(pcm), 0, 0, 0, 'one-shot')
        data, coef1, coef2, snr = encode_adx_track(pcm.tobytes(), spec.rate, CHANNELS, keep, song, measure_snr)
        if snr is not None:
            snrs.append((song, snr))
        meta = TrackMeta(sample_rate=spec.rate, channels=CHANNELS, codec=CODEC_ADX, gain=127, loop_start_sample=ls, loop_start_byte=adxcodec.samples_to_stream_byte(ls, CHANNELS) if xfade_enable else 0, loop_end_sample=le, loop_end_byte=adxcodec.samples_to_stream_byte(le, CHANNELS) if xfade_enable else 0, coef1=coef1, coef2=coef2, xfade_enable=xfade_enable, name=f'{song} ({kind})', source=f'dos/{device}/{source.name}')
        index = writer.add_track(data, meta)
        track_of[song] = index
        print(f'[ssf2t-dos:{device}] t{index:02d} {song:10s} {keep / spec.rate:7.2f}s  {kind:<11} {len(data) / 1000000.0:6.2f} MB')
    for row in rows:
        if row.song not in track_of:
            continue
        writer.set_trigger(row.command, TriggerRow(verb=VERB_PLAY, track=track_of[row.song], gain=spec.trigger_gain, suppress=1))
    if device == 'cd':
        if CD_VS_CMD not in {row.command for row in rows}:
            raise ValueError('the DOS map must include the VS command')
    apply_device_policy(writer, device, track_of)
    out_path = out or PACKS_DIR / spec.pack_name
    writer.write(out_path)
    reader = PackReader(str(out_path))
    try:
        if reader.header.game_id != ssf2_family.GAME_ID:
            raise ValueError('readback: wrong game id')
        if reader.header.trigger_rows != TRIGGER_ROWS:
            raise ValueError('readback: wrong trigger table size')
        ssf2_family.check_protocol(reader.header.proto)
        mapped = {row.command for row in rows if row.song in track_of}
        for row in rows:
            if row.song not in track_of:
                continue
            got = reader.triggers[row.command]
            if (got.verb, got.track, got.gain, got.suppress) != (VERB_PLAY, track_of[row.song], spec.trigger_gain, 1):
                raise ValueError(f'readback: 0x{row.command:02x} does not map to {row.song}')
        for command, got in enumerate(reader.triggers):
            if command in mapped:
                continue
            if got.verb != VERB_NONE or got.suppress:
                raise ValueError(f'readback: unmapped 0x{command:04x} does not fail open')
        for command in NATIVE_RESTORE_CMDS:
            got = reader.triggers[command]
            if got.verb != VERB_NONE or got.suppress:
                raise ValueError(f'readback: restore-class 0x{command:02x} must fail open')
    finally:
        reader.close()
    size = out_path.stat().st_size
    if snrs:
        mean = sum((value for _, value in snrs)) / len(snrs)
        worst = min(snrs, key=lambda item: item[1])
        print(f'[ssf2t-dos:{device}] ADX SNR mean {mean:.2f} dB, worst {worst[0]} {worst[1]:.2f} dB')
    played = sum((1 for row in rows if row.song in track_of))
    if unbuilt:
        print(f"[ssf2t-dos:{device}] {len(set(unbuilt))} piece(s) left out (no derivable loop); their commands fail open: {', '.join(sorted(set(unbuilt)))}")
    print(f'[ssf2t-dos:{device}] {out_path}: {len(track_of)} tracks, {played} play commands, {loops} loops, {size / 1000000.0:.1f} MB')
    return {'path': out_path, 'size': size, 'tracks': len(track_of), 'commands': played, 'loops': loops, 'snrs': snrs}

def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--self-test', action='store_true')
    ap.add_argument('--device', choices=sorted(DEVICES))
    ap.add_argument('--flac-dir', type=Path)
    ap.add_argument('--out', type=Path)
    ap.add_argument('--map', type=Path, default=MAP_TSV)
    ap.add_argument('--measure-snr', action='store_true')
    args = ap.parse_args(argv)
    if args.self_test:
        return self_test()
    if not args.device or not args.flac_dir:
        ap.error('--device and --flac-dir are required')
    build(device=args.device, flac_dir=args.flac_dir, out=args.out, map_path=args.map, measure_snr=args.measure_snr)
    return 0
if __name__ == '__main__':
    raise SystemExit(main())
