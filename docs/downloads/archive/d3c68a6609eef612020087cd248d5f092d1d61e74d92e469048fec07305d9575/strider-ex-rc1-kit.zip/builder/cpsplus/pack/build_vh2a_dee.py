"""Hunter Arrange's Dee pack, using the shared byte-exact Collection builder."""
from .build_common import MANIFESTS
from . import build_vs2a_dee as shared
RECIPE = MANIFESTS / 'vh2a_dee_recipe.json'

def main(argv=None):
    return shared.main(argv, recipe_path=RECIPE)
