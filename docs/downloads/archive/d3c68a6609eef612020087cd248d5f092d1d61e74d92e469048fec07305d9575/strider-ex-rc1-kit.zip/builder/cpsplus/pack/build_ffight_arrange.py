"""`build_ffight_arrange.py` — Final Fight (CPS1 `ffight`) ARRANGE pack, per region."""
from __future__ import annotations
import argparse
import csv
import dataclasses
import math
import wave
from pathlib import Path
from . import adxcodec, protocols
from .protocols import cps1_protocol
from .adxencode import encode_adx_track, read_wav, snr_db
from .audition import verify as audition_verify
from .build_common import MANIFESTS, PACKS_DIR, PKG_ROOT, MapRow, VERBS, _rows
from .format import PackWriter, PackReader, TrackMeta, TriggerRow, CODEC_ADX, CODEC_PCM, VERB_NONE, VERB_PLAY, VERB_NAMES, DDR_BUDGET_BYTES
CD_DIR = PKG_ROOT / 'work' / 'intermediate' / 'ffightcd' / 'cd_full'
TRIGGER_TSV = MANIFESTS / 'ffight_arrange_trigger_map.tsv'
DDR_HARD_CAP_BYTES = 256 * 1024 * 1024
FFIGHT_ROM_BYTES = 3473408
AUTHORED_LOOPS = {'tr26': (59488, 1164864, 1, 3), 'tr02': (1524736, 5203808, 1, 0), 'tr03': (4268864, 5591424, 1, 0), 'tr04': (2782688, 5292416, 1, 0), 'tr05': (2187360, 5078528, 1, 0), 'tr06': (3968992, 7144192, 1, 0), 'tr07': (1750752, 5030016, 1, 0), 'tr08': (1252416, 4736768, 1, 0), 'tr09': (2429888, 5306976, 1, 0), 'tr10': (1653728, 4968736, 1, 0), 'tr11': (2406080, 4205696, 1, 0)}
XFADE_SAMPLES = 7200
VOICED_CUES = [(112, 'us', 'tr23', 'Opening voiced US (backport cutscene)'), (113, 'us', 'tr24', 'Ending voiced US (backport cutscene)'), (114, 'jp', 'tr23', 'Opening voiced JP (backport cutscene)'), (115, 'jp', 'tr24', 'Ending voiced JP (backport cutscene)')]
OPENING_TRACK = 'tr25'
ARCADE_CUT = {113: (88200, 39.225, 7, 82.19, 0.12), 115: (87612, 56.0, 8, 82.19, 0.12)}
PREGAP_LEAD = {112: 150 * 588, 114: 149 * 588}
ARCADE_CUT_PIN = {113: ('1f4e57194345feb8ee7a80eb006e276b', 4252985), 115: ('fff5689dbd124b0df49d1d6786af9a84', 5163206)}

def arcade_cut(pcm: bytes, ch: int, rate: int, lead_samples: int, cut_at: float, bars: int, bpm: float, xfade: float) -> tuple[bytes, int]:
    """Pad with `lead_samples` of silence, then lift `bars` bars -> (pcm, frames)."""
    import numpy as np
    a = np.frombuffer(pcm, dtype='<i2').astype(np.float64).reshape(-1, ch)
    if lead_samples:
        a = np.concatenate([np.zeros((lead_samples, ch), np.float64), a])
    drop = 60.0 / bpm * 4 * bars
    t0 = int(cut_at * rate)
    t1 = t0 + int(drop * rate)
    xf = int(xfade * rate)
    if t1 + xf > len(a):
        raise ValueError('arcade cut runs past the end of the track')
    head, tail = (a[:t0], a[t1:])
    n = min(xf, len(head), len(tail))
    if n:
        f = np.linspace(0, np.pi / 2, n)[:, None]
        joined = head[-n:] * np.cos(f) ** 2 + tail[:n] * np.sin(f) ** 2
        out = np.concatenate([head[:-n], joined, tail[n:]])
    else:
        out = np.concatenate([head, tail])
    return (np.clip(out, -32768, 32767).astype('<i2').tobytes(), len(out))
REGIONS = {'us': {'cd_subdir': 'cd_full', 'disc_flag': '--us-disc', 'voiced_kind': 'us', 'track_alias': {}, 'loop_shift': 0, 'opening_cmd': 53, 'opening_loop': (732352, 1183904, 1, 1), 'pack': 'ffight_arrange', 'title': 'Final Fight (Arrange)'}, 'jp': {'cd_subdir': 'cd_jp_full', 'disc_flag': '--jp-disc', 'voiced_kind': 'jp', 'track_alias': {'tr25': 'tr28', 'tr26': 'tr29'}, 'loop_shift': -128, 'opening_cmd': 82, 'opening_loop': (1056928, 1183904, 1, 1), 'pack': 'ffight_arrange_jp', 'title': 'Final Fight (Arrange, Japan)'}}

def apply_region(rows: list['MapRow'], region: str) -> list['MapRow']:
    """Move the opening PLAY onto the cue THIS region issues first."""
    cfg = REGIONS[region]
    if cfg['opening_cmd'] == 53:
        return rows
    start = next((r for r in rows if r.cmd == 53 and r.verb == VERB_PLAY))
    out = []
    for r in rows:
        if r.cmd == 53:
            out.append(dataclasses.replace(r, verb=VERB_NONE, track=None, cue=f"Phone RINGING (this region enters on 0x{cfg['opening_cmd']:02x})"))
        elif r.cmd == cfg['opening_cmd']:
            out.append(dataclasses.replace(r, verb=VERB_PLAY, track=start.track, cue='Opening entry (JP) - the SONG cue - ATTRACT ONLY'))
        else:
            out.append(r)
    return out
LOOPING = {'tr02', 'tr03', 'tr04', 'tr05', 'tr06', 'tr07', 'tr08', 'tr09', 'tr10', 'tr11', 'tr12', 'tr17', 'tr25', 'tr26'}
ONE_SHOT = {'tr13', 'tr14', 'tr15', 'tr16', 'tr18'}

def load_triggers(path: Path=TRIGGER_TSV) -> list[MapRow]:
    """Parse the tracked trigger map.  Every row is built — the map carries no"""
    out: list[MapRow] = []
    for r in _rows(path):
        if len(r) < 5:
            raise ValueError(f'short row in {path.name}: {r!r}')
        cmd_s, verb_s, sup_s, track_s, cue = (r[0], r[1], r[2], r[3], r[4])
        if verb_s not in VERBS:
            raise ValueError(f'cmd {cmd_s}: unknown verb {verb_s!r}')
        verb = VERBS[verb_s]
        cmd = int(cmd_s, 16)
        if not 0 <= cmd < protocols.SF2_TRIGGER_ROWS:
            raise ValueError(f'cmd {cmd_s} outside the CPS1 byte-command range')
        track = None if track_s.strip() in ('-', '') else track_s.strip()
        if verb == VERB_PLAY and track is None:
            raise ValueError(f'cmd {cmd_s}: verb=play with no track')
        if verb == VERB_NONE and track is not None:
            raise ValueError(f'cmd {cmd_s}: verb=none must not name a track')
        if verb == VERB_NONE and int(sup_s) not in (0, 1):
            raise ValueError(f'cmd {cmd_s}: verb=none suppress must be 0 or 1')
        out.append(MapRow(cmd=cmd, verb=verb, suppress=int(sup_s), track=track, cue=cue))
    seen = {}
    for row in out:
        if row.cmd in seen:
            raise ValueError(f'duplicate command 0x{row.cmd:02x} in {path.name}')
        seen[row.cmd] = row
    return out

def ensure_disc_audio(dest: Path, needed: set[str], disc: str | None, flag: str) -> None:
    """Fill the extraction cache from the user-supplied rip (pregap=trim --"""
    from .discsrc import ensure_audio_cache
    ensure_audio_cache(dest, needed, disc, flag, pregap='trim')

def build(variant: str, out: str | None=None, triggers_path: str | None=None, cd_dir: str | None=None, measure_snr: bool=True, us_disc: str | None=None, jp_disc: str | None=None, region: str='us') -> dict:
    if variant not in ('pcm', 'adx'):
        raise ValueError(f'unknown variant {variant!r}')
    if region not in REGIONS:
        raise ValueError(f'unknown region {region!r}')
    cfg = REGIONS[region]
    alias = cfg['track_alias']
    rows = apply_region(load_triggers(Path(triggers_path) if triggers_path else TRIGGER_TSV), region)
    cd = Path(cd_dir) if cd_dir else CD_DIR.parent / cfg['cd_subdir']
    voiced = [v for v in VOICED_CUES if v[1] == cfg['voiced_kind']]
    needed = {alias.get(r.track, r.track) for r in rows if r.track}
    needed |= {v[2] for v in voiced}
    ensure_disc_audio(cd, needed, us_disc if region == 'us' else jp_disc, cfg['disc_flag'])
    tracks = [r.track for r in rows if r.track]
    unknown = sorted(set(tracks) - LOOPING - ONE_SHOT)
    if unknown:
        raise ValueError(f'tracks with no loop treatment decided: {unknown}')
    dup = sorted({t for t in tracks if tracks.count(t) > 1})
    if dup:
        print(f'[ffight] note: track(s) driven by more than one command: {dup}')
    codec = CODEC_PCM if variant == 'pcm' else CODEC_ADX
    title = cfg['title'] + (' [PCM]' if variant == 'pcm' else '')
    w = PackWriter(cps1_protocol(), title=title, trigger_rows=protocols.SF2_TRIGGER_ROWS, default_rate=44100, xfade_samples=XFADE_SAMPLES)
    ti_of: dict[str, int] = {}
    snrs: list[tuple[str, float]] = []
    total_audio = 0
    print(f'[ffight] === variant {variant} ===')
    for row in rows:
        if row.verb == VERB_NONE:
            if row.suppress == 0:
                print(f"[ffight] 0x{row.cmd:02x} -> (fail open, not written){'':>21}  {row.cue}")
                continue
            w.set_trigger(row.cmd, TriggerRow(verb=VERB_NONE, track=0, gain=127, suppress=row.suppress))
            print(f"[ffight] 0x{row.cmd:02x} -> (silence, no restart){'':>26}  {row.cue}")
            continue
        track = row.track
        if track not in ti_of:
            fname = alias.get(track, track)
            src = cd / f'{fname}.wav'
            pcm, rate, ch, n = read_wav(src)
            loops = track in LOOPING
            authored = AUTHORED_LOOPS.get(track)
            if track == OPENING_TRACK:
                authored, loops = (cfg['opening_loop'], True)
            if authored and cfg['loop_shift']:
                als, ale, axf, acnt = authored
                sh = cfg['loop_shift']
                authored = (als + sh, ale + sh, axf, acnt)
            if variant == 'pcm':
                data = pcm
                coef1 = coef2 = 0
                loop_end_byte = len(data) if loops else 0
                loop_end_sample = n if loops else 0
                if authored:
                    als, ale, axf, acnt = authored
                    loop_start_sample, loop_start_byte = (als, als * 2 * ch)
                    loop_end_sample, loop_end_byte = (ale, ale * 2 * ch)
                    if axf and acnt == 0:
                        data = data[:loop_end_byte + XFADE_SAMPLES * 2 * ch]
            else:
                data, coef1, coef2, snr = encode_adx_track(pcm, rate, ch, n, track, measure_snr)
                if snr is not None:
                    snrs.append((track, snr))
                if adxcodec.samples_to_stream_byte(0, ch) != 0:
                    raise ValueError('loop start not frame-aligned')
                loop_end_byte = len(data) if loops else 0
                loop_end_sample = n if loops else 0
                if loops and loop_end_byte % (adxcodec.FRAME_BYTES * ch):
                    raise ValueError(f'{track}: loop end not frame-aligned')
                if authored:
                    als, ale, axf, acnt = authored
                    loop_start_sample, loop_start_byte = (als, adxcodec.samples_to_stream_byte(als, ch))
                    loop_end_sample, loop_end_byte = (ale, adxcodec.samples_to_stream_byte(ale, ch))
                    if axf and acnt == 0:
                        tail = XFADE_SAMPLES // 32 * 18 * ch
                        data = data[:loop_end_byte + tail]
            if not authored:
                loop_start_sample = loop_start_byte = 0
            kind = ('inner loop' if authored[3] == 0 else 'finite loop') if authored else 'whole-track loop' if loops else 'one_shot'
            meta = TrackMeta(sample_rate=rate, channels=ch, codec=codec, gain=127, loop_start_sample=loop_start_sample, loop_start_byte=loop_start_byte, loop_end_sample=loop_end_sample, loop_end_byte=loop_end_byte, coef1=coef1, coef2=coef2, xfade_enable=authored[2] if authored else 0, loop_count=authored[3] if authored else 0, name=f'{track} ({kind})', source=f"ffightcd/{cfg['cd_subdir']}/{fname}.wav[0:{n}]")
            ti_of[track] = w.add_track(data, meta)
            total_audio += len(data)
            print(f"[ffight] 0x{row.cmd:02x} -> {track} track{ti_of[track]:<3} {n / rate:7.2f}s  {('loop ' if loops else 'once ')}  {len(data) / 1000000.0:7.2f} MB  {row.cue}")
        else:
            print(f"[ffight] 0x{row.cmd:02x} -> {track} track{ti_of[track]:<3} {'(shared)':>22}  {row.cue}")
        w.set_trigger(row.cmd, TriggerRow(verb=VERB_PLAY, track=ti_of[track], gain=127, suppress=row.suppress))
    for vcmd, kind, vtrack, vlabel in voiced:
        vsrc = cd / f'{vtrack}.wav'
        pcm, rate, ch, n = read_wav(vsrc)
        lead = PREGAP_LEAD.get(vcmd)
        if lead:
            head = bytes(lead * ch * 2)
            pcm, n = (head + pcm, n + lead)
            if len(pcm) != n * ch * 2 or any(pcm[:lead * ch * 2]):
                raise SystemExit(f'pregap lead broken on 0x{vcmd:02x}')
            vlabel += f' [+{lead / rate:.3f}s disc pregap]'
        cut = ARCADE_CUT.get(vcmd)
        if cut:
            pcm, n = arcade_cut(pcm, ch, rate, *cut)
            pin = ARCADE_CUT_PIN.get(vcmd)
            if pin:
                import hashlib
                got = (hashlib.md5(pcm).hexdigest(), n)
                if got != pin:
                    raise SystemExit(f'ARCADE_CUT drift on 0x{vcmd:02x}: got {got}, pinned {pin} -- the transform no longer matches the files the backport ROMs were tuned against')
            vlabel += f' [arcade cut -> {n / rate:.2f}s]'
        if variant == 'pcm':
            vdata, vc1, vc2 = (pcm, 0, 0)
        else:
            vdata, vc1, vc2, _ = encode_adx_track(pcm, rate, ch, n, f'{kind}_{vtrack}', False)
        vmeta = TrackMeta(sample_rate=rate, channels=ch, codec=codec, gain=127, loop_start_sample=0, loop_start_byte=0, loop_end_sample=0, loop_end_byte=0, coef1=vc1, coef2=vc2, xfade_enable=0, name=f'{kind}_{vtrack} (voiced one_shot)', source=f"ffightcd/{cfg['cd_subdir']}/{vtrack}.wav" + (f'[arcade cut @{cut[0]}s -{cut[1]}bars -> 0:{n}]' if cut else f'[0:{n}]'))
        vti = w.add_track(vdata, vmeta)
        w.set_trigger(vcmd, TriggerRow(verb=VERB_PLAY, track=vti, gain=127, suppress=1))
        total_audio += len(vdata)
        print(f'[ffight] 0x{vcmd:02x} -> {kind}/{vtrack} track{vti:<3d} {n / rate:7.2f}s  voiced one-shot  {vlabel}')
    name = cfg['pack'] + ('_pcm' if variant == 'pcm' else '') + '.cpk'
    out_path = Path(out) if out else PACKS_DIR / name
    w.write(out_path)
    size = out_path.stat().st_size
    rd = PackReader(out_path)
    try:
        for row in rows:
            got = rd.triggers[row.cmd]
            if got.verb != row.verb or got.suppress != row.suppress:
                raise ValueError(f'readback: cmd 0x{row.cmd:02x} is verb {VERB_NAMES[got.verb]}/suppress {got.suppress}, expected {VERB_NAMES[row.verb]}/{row.suppress}')
            if row.verb == VERB_PLAY and got.track != ti_of[row.track]:
                raise ValueError(f'readback: cmd 0x{row.cmd:02x} wrong track')
        if rd.header.proto.latch_page != 8388992:
            raise ValueError('readback: latch page is not the CPS1 dialect')
        if rd.header.trigger_rows != protocols.SF2_TRIGGER_ROWS:
            raise ValueError('readback: trigger table is not 256 rows')
    finally:
        rd.close()
    image = size + FFIGHT_ROM_BYTES
    n_play = sum((1 for r in rows if r.verb == VERB_PLAY))
    n_sil = sum((1 for r in rows if r.verb == VERB_NONE))
    print(f'[ffight] {out_path}')
    print(f'[ffight]   pack        {size:,} B ({size / 1000000.0:.1f} MB), {len(w.tracks)} tracks, {n_play} play + {n_sil} silence triggers')
    print(f'[ffight]   + ROM       {FFIGHT_ROM_BYTES:,} B = image {image:,} B ({image / 1000000.0:.1f} MB)')
    over = image - DDR_HARD_CAP_BYTES
    verdict = f'OVER by {over:,} B ({over / 1000000.0:.1f} MB)' if over > 0 else f'fits, {-over:,} B ({-over / 1000000.0:.1f} MB) headroom'
    print(f'[ffight]   256 MiB cap {DDR_HARD_CAP_BYTES:,} B -> {100.0 * image / DDR_HARD_CAP_BYTES:.1f}% — {verdict}')
    if image > DDR_HARD_CAP_BYTES:
        print('[ffight]   *** THIS IMAGE EXCEEDS THE DDR CAP — built on purpose, to be tested on hardware ***')
    if snrs:
        worst = min(snrs, key=lambda s: s[1])
        mean = sum((s for _, s in snrs)) / len(snrs)
        print(f'[ffight]   ADX SNR: mean {mean:.2f} dB, worst {worst[0]} {worst[1]:.2f} dB, best {max(snrs, key=lambda s: s[1])[1]:.2f} dB')
        for t, s in snrs:
            print(f'[ffight]     {t}  {s:6.2f} dB')
    return {'path': out_path, 'size': size, 'image': image, 'tracks': len(w.tracks), 'snrs': snrs, 'audio': total_audio}

def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog='python -m cpsplus.pack.build_ffight_arrange')
    ap.add_argument('--variant', choices=('pcm', 'adx', 'both'), default='both')
    ap.add_argument('--out', help='output path (single-variant builds only)')
    ap.add_argument('--triggers')
    ap.add_argument('--cd-dir')
    ap.add_argument('--us-disc', help='US Final Fight CD rip: a .cue, or a .zip/.7z containing one (needed when the extraction cache is empty)')
    ap.add_argument('--jp-disc', help='JP Final Fight CD rip, same forms')
    ap.add_argument('--region', choices=('us', 'jp', 'both'), default='us', help='which region pack to build (default us).  Each region needs ONLY its own disc and carries only its own voiced cutscene pair -- see REGIONS')
    ap.add_argument('--no-snr', action='store_true', help='skip the ADX decode-back SNR measurement')
    ap.add_argument('--no-verify', action='store_true')
    a = ap.parse_args(argv)
    if a.out and (a.variant == 'both' or a.region == 'both'):
        ap.error('--out needs a single --variant and a single --region')
    variants = ['pcm', 'adx'] if a.variant == 'both' else [a.variant]
    regions = ['us', 'jp'] if a.region == 'both' else [a.region]
    results = []
    for reg in regions:
        for v in variants:
            res = build(v, out=a.out, triggers_path=a.triggers, cd_dir=a.cd_dir, measure_snr=not a.no_snr, us_disc=a.us_disc, jp_disc=a.jp_disc, region=reg)
            results.append(res)
            if not a.no_verify and (not audition_verify(str(res['path']))):
                raise SystemExit(f"verification FAILED for {res['path']}")
    return 0
if __name__ == '__main__':
    raise SystemExit(main())
