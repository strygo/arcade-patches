"""Coverage report: what the arcade actually plays vs what a pack maps."""
import argparse
import csv
import json
import struct
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from pack.format import _parse_header

def read_capture(path: Path):
    """-> [(seconds, command)] from any of our capture formats."""
    out = []
    with path.open() as fh:
        rows = [ln for ln in fh if not ln.startswith('#')]
    for r in csv.DictReader(rows, delimiter='\t'):
        sec = r.get('sec') or r.get('seconds')
        cmd = r.get('cmd') or r.get('value')
        if not sec or not cmd:
            continue
        try:
            out.append((float(sec), int(cmd, 16) if cmd.startswith('0x') else int(cmd)))
        except ValueError:
            continue
    return out

def classify(events, idle=(255,), window=10.0):
    """-> {cmd: (max_window, occurrences)}; idle bytes are not commands."""
    ev = [(t, c) for t, c in events if c not in idle]
    stats = {}
    for i, (t, c) in enumerate(ev):
        nxt = ev[i + 1][0] if i + 1 < len(ev) else t + window * 2
        w = nxt - t
        prev = stats.get(c, (0.0, 0))
        stats[c] = (max(prev[0], w), prev[1] + 1)
    return stats

def pack_rows(path: Path):
    """-> ({cmd: track}, track_count)"""
    d = path.read_bytes()
    h = _parse_header(d)
    rows = {}
    for i in range(h.trigger_rows):
        b = d[h.trigger_offset + 4 * i:h.trigger_offset + 4 * i + 4]
        if len(b) < 4:
            break
        if b[0] != 0:
            rows[i] = b[1] | b[3] >> 4 << 8
    return (rows, h.track_count)

def run(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('capture', type=Path)
    ap.add_argument('pack', type=Path)
    ap.add_argument('--window', type=float, default=10.0, help="clean-window seconds above which a command counts as music (default 10; raise it if a game's cues are long)")
    ap.add_argument('--json', type=Path)
    args = ap.parse_args(argv)
    ev = read_capture(args.capture)
    stats = classify(ev, window=args.window)
    rows, ntracks = pack_rows(args.pack)
    music = {c: s for c, s in stats.items() if s[0] >= args.window}
    short = {c: s for c, s in stats.items() if s[0] < args.window}
    unmapped = sorted((c for c in music if c not in rows))
    mapped_music = sorted((c for c in music if c in rows))
    mapped_sfx = sorted((c for c in rows if c in short))
    used_tracks = {rows[c] for c in rows}
    dead_tracks = sorted(set(range(ntracks)) - used_tracks)
    print(f'  capture : {args.capture.name}  ({len(ev)} events, {len(stats)} distinct commands)')
    print(f'  pack    : {args.pack.name}  ({len(rows)} mapped commands, {ntracks} tracks)')
    print(f'  music threshold: a clean window >= {args.window:g}s\n')
    print(f'  ARCADE SONGS WITH NO ARRANGED TRACK ({len(unmapped)}) -- these fall through to native audio:')
    for c in unmapped:
        w, n = stats[c]
        print(f'    0x{c:02x}   longest window {w:6.1f}s   heard {n}x')
    if not unmapped:
        print('    (none)')
    print(f'\n  ARRANGED TRACKS NO ARCADE SONG REACHES ({len(dead_tracks)}) -- dead weight in the pack:')
    print('    ' + (' '.join((f't{t}' for t in dead_tracks)) if dead_tracks else '(none)'))
    print(f'\n  MAPPED BUT NOT MUSIC ({len(mapped_sfx)}) -- an SFX command mapped as a song will play a track over the wrong cue:')
    for c in mapped_sfx:
        w, n = stats[c]
        print(f'    0x{c:02x} -> track {rows[c]:3d}   longest window only {w:5.1f}s   heard {n}x')
    if not mapped_sfx:
        print('    (none)')
    print(f'\n  CORRECTLY MAPPED MUSIC ({len(mapped_music)}):')
    for c in mapped_music:
        w, n = stats[c]
        print(f'    0x{c:02x} -> track {rows[c]:3d}   window {w:6.1f}s   heard {n}x')
    if not mapped_music:
        print('    (none)')
    print(f'\n  NOT SEEN IN THIS CAPTURE: {len(set(rows) - set(stats))} mapped commands never fired -- coverage is only as good as the run.')
    if args.json:
        args.json.write_text(json.dumps({'capture': str(args.capture), 'pack': str(args.pack), 'window_s': args.window, 'arcade_unmapped': [f'0x{c:02x}' for c in unmapped], 'tracks_unreached': dead_tracks, 'mapped_but_not_music': {f'0x{c:02x}': rows[c] for c in mapped_sfx}, 'mapped_music': {f'0x{c:02x}': rows[c] for c in mapped_music}, 'never_fired': [f'0x{c:02x}' for c in sorted(set(rows) - set(stats))]}, indent=2))
        print(f'\n  wrote {args.json}')
    return 0
if __name__ == '__main__':
    sys.exit(run())
