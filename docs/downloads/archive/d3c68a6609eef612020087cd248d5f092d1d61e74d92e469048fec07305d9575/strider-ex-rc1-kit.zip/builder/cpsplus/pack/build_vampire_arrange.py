"""Build one byte-preserving CPK for VSA, VS2 Arrange and VH2 Arrange."""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import tempfile
from . import build_vs2a_dee as shared
from . import adxcodec
from .build_common import MANIFESTS, adx_entry_to_track
from .format import PackReader, PackWriter, TrackMeta, CODEC_ADX, TriggerRow, VERB_NONE
RECIPE = MANIFESTS / 'vampire_arrange_recipe.json'

def require(ok, why):
    if not ok:
        raise ValueError(why)

def recipe():
    r = json.loads(RECIPE.read_text())
    require(r['game_id'] == 'vampire-arrange' and len(r['tracks']) == 11, 'shared family contract differs')
    require([int(t['command'], 0) for t in r['tracks']] == [*range(92, 100), 125, 126, 127], 'shared stream command ordering differs')
    require([t['entry'] for t in r['tracks']] == [*range(199, 207), 378, 377, 376], 'shared stream resource ordering differs')
    streamed = {int(t['command'], 0) for t in r['tracks']}
    native = {int(c, 0) for c in r['native_music_commands']}
    ambiguous = {int(c, 0) for c in r['ambiguous_commands']}
    require(not (streamed & native or streamed & ambiguous or native & ambiguous), 'shared music/control/effect command collision')
    require(all((t['games'] for t in r['tracks'])), 'track without a game caller')
    return r

def verify(pack, blobs, r, *, decode=True):
    expected = shared.rows(r)
    reader = PackReader(pack)
    checks = []
    try:
        require(reader.header.proto == expected.proto and reader.header.track_count == 11 and (reader.triggers == expected.triggers) and (reader.crc_check() == (True, True)), 'shared CPK protocol, trigger table or CRC differs')
        for command in r['ambiguous_commands']:
            require(reader.triggers[int(command, 0)].verb == VERB_NONE, 'ambiguous native program acquired CPK side effects')
        for i, t in enumerate(r['tracks']):
            raw = blobs[t['entry']]
            require(len(raw) == t['bytes'] and shared.sha(raw) == t['sha256'], 'declared recording differs')
            stream, meta, info = adx_entry_to_track(raw, name=t['name'], source='Collection AFS' + str(t['entry']))
            require(info.channels == 2 and info.sample_rate == 48000 and (meta.codec == CODEC_ADX), 'source stream format changed')
            got = reader.tracks[i]
            require(reader.read_track(i) == stream and all((getattr(got, k) == getattr(meta, k) for k in ('sample_rate', 'channels', 'codec', 'gain', 'loop_start_sample', 'loop_start_byte', 'loop_end_sample', 'loop_end_byte', 'coef1', 'coef2'))), 'source frames or authored loops changed')
            if decode:
                count = len(stream) // 36 * 32
                packed = adxcodec.decode(stream, 2, 48000, total_samples=count)
                original, _ = adxcodec.decode_file_bytes(raw)
                valid = min(count, info.total_samples)
                require(packed[:valid * 4] == original[:valid * 4] and 0 <= count - valid < 32, 'decoded source samples differ beyond final-frame padding')
                checks.append(dict(entry=t['entry'], byte_exact=True, sample_exact_pairs=valid))
    finally:
        reader.close()
    return checks

def emit(blobs, out, r=None, *, decode=True):
    r = recipe() if r is None else r
    writer = shared.rows(r)
    for t in r['tracks']:
        stream, meta, _ = adx_entry_to_track(blobs[t['entry']], name=t['name'], source='Collection AFS' + str(t['entry']))
        writer.add_track(stream, meta)
    out = Path(out)
    require(not out.exists(), 'fresh shared pack output required')
    writer.write(out)
    checks = verify(out, blobs, r, decode=decode)
    reader = PackReader(out)
    try:
        tracks = []
        for i, t in enumerate(r['tracks']):
            m = reader.tracks[i]
            tracks.append(dict(command=t['command'], entry=t['entry'], games=t['games'], source_bytes=t['bytes'], source_sha256=t['sha256'], stream_bytes=m.data_length, stream_sha256=shared.sha(reader.read_track(i)), sample_rate=m.sample_rate, channels=m.channels, loop_start_sample=m.loop_start_sample, loop_end_sample=m.loop_end_sample, loop_start_byte=m.loop_start_byte, loop_end_byte=m.loop_end_byte, active_scene_consumer_bound=True))
    finally:
        reader.close()
    report = dict(pack_name='vampire_arrange.cpk', pack_bytes=out.stat().st_size, pack_sha256=shared.sha(out.read_bytes()), tracks=tracks, native_music_handoffs=r['native_music_commands'], ambiguous_commands=r['ambiguous_commands'], shared_recipe_sha256=shared.sha(RECIPE.read_bytes()), source_reencoded=False, source_rate_or_stereo_changed=False, native_images_changed=False, new_interpreter_or_dsp=False, whole_song_ROM_PCM=False, source_checks=checks, hardware_listening_passed=False)
    return dict(pack=out.read_bytes(), path=out, report=report)

def self_test():
    r = recipe()
    writer = shared.rows(r)
    for _ in r['tracks']:
        writer.add_track(bytes(36), TrackMeta(sample_rate=48000, channels=2, codec=CODEC_ADX))
    with tempfile.TemporaryDirectory() as tmp:
        rd = PackReader(writer.write(Path(tmp) / 'test.cpk'))
        try:
            require(rd.header.track_count == 11 and rd.crc_check() == (True, True), 'shared synthetic pack')
            require(all((rd.triggers[int(c, 0)].verb == VERB_NONE for c in r['ambiguous_commands'])), 'shared ambiguous commands')
            require(all((rd.triggers[int(t['command'], 0)].suppress == 1 for t in r['tracks'])), 'native fallback not suppressed during stream playback')
            require(all((rd.triggers[int(c, 0)].suppress == 0 for c in r['native_music_commands'])), 'native music handoff suppressed')
        finally:
            rd.close()
    print('PASS shared family ordering/caller/collision/CRC/suppression contract')

def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--self-test', action='store_true')
    p.add_argument('--disc', type=Path)
    p.add_argument('--out', type=Path)
    p.add_argument('--receipt', type=Path)
    a = p.parse_args(argv)
    if a.self_test:
        return self_test()
    require(a.disc and a.out, '--disc and --out required')
    r = recipe()
    a.out.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='vampire-pack-', dir=a.out.parent) as temp:
        reader = shared.Dvd(a.disc, Path(temp), r)
        blobs = reader.sources()
        result = emit(blobs, a.out, r)
        reader.unchanged()
    if a.receipt:
        a.receipt.write_text(json.dumps(result['report'], indent=2, sort_keys=True) + '\n')
    print('Built shared Vampire Arrange CPK', result['report']['pack_sha256'])
if __name__ == '__main__':
    main()
