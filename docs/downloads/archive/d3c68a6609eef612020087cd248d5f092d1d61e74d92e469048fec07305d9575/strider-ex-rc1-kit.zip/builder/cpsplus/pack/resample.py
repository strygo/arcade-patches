"""Deterministic sample-rate conversion: ffmpeg's swresample, redone in-repo."""
from __future__ import annotations
import hashlib
import os
from concurrent.futures import ThreadPoolExecutor
from decimal import Decimal, localcontext
from fractions import Fraction
from functools import lru_cache
import math
from math import gcd
import numpy as np
from numpy.lib.stride_tricks import sliding_window_view
FILTER_SIZE = 32
PHASE_LIMIT = 1 << 10
KAISER_BETA = 9
CUTOFF = 0.97
COEF_BITS = 36
_PREC = 40
_PI = Decimal('3.14159265358979323846264338327950288419716939937510582097494')
TABLE_SHA256 = {(44100, 48000, 32, 36): '1726d10b2d7ebcb7f1d0c91e5df76f15c32e33d67b85c7d13f499a1a73600a3a'}
_BLOCK = 1 << 12
_JOB_ROWS = 1 << 18
_F32_BLOCK = 1 << 16

def sin_pi(r: Fraction, prec: int=_PREC) -> Decimal:
    """sin(pi*r) in decimal arithmetic, folded into [0, pi/2] so the Taylor"""
    with localcontext() as ctx:
        ctx.prec = prec
        r %= 2
        neg = r >= 1
        if neg:
            r -= 1
        if r > Fraction(1, 2):
            r = 1 - r
        x = _PI * r.numerator / r.denominator
        x2, term, total, k = (x * x, x, x, 1)
        eps = Decimal(10) ** (-(prec - 2))
        while abs(term) > eps:
            term = -term * x2 / (2 * k * (2 * k + 1))
            total += term
            k += 1
        return +(-total if neg else total)

def _i0(q: Decimal) -> Decimal:
    """Modified Bessel I0 at z where q = (z/2)**2: sum q**k / (k!)**2."""
    term, total, k = (Decimal(1), Decimal(1), 1)
    eps = Decimal(10) ** (-(_PREC - 2))
    while term > eps * total:
        term = term * q / (k * k)
        total += term
        k += 1
    return total

def design(src_rate: int, dst_rate: int, filter_size: int=FILTER_SIZE) -> tuple[int, int, int, float]:
    """(L, M, taps, factor) as swr's resample_init derives them: L exact-"""
    g = gcd(src_rate, dst_rate)
    L, M = (dst_rate // g, src_rate // g)
    if L > PHASE_LIMIT:
        raise ValueError(f'{src_rate} -> {dst_rate} Hz needs more than {PHASE_LIMIT} phases')
    factor = min(dst_rate * CUTOFF / src_rate, 1.0)
    taps = max(math.ceil(filter_size / factor), 1)
    if taps % 2:
        raise ValueError(f'{src_rate} -> {dst_rate} Hz: odd tap count {taps}')
    return (L, M, taps, factor)

@lru_cache(maxsize=None)
def taps32(src_rate: int, dst_rate: int, filter_size: int=FILTER_SIZE) -> np.ndarray:
    """swr's float32 filter bank, shape (L, taps).  Tap i of row p weights"""
    L, _, taps, factor = design(src_rate, dst_rate, filter_size)
    center = (taps - 1) // 2
    fac = Fraction(factor)
    built = L // 2 + 1 if L % 2 == 0 else L
    with localcontext() as ctx:
        ctx.prec = _PREC
        b2 = Decimal(KAISER_BETA * KAISER_BETA) / 4
        half = []
        for p in range(built):
            row = []
            for i in range(taps):
                r = Fraction(i - center) - Fraction(p, L)
                rf = r * fac
                y = Decimal(1) if r == 0 else sin_pi(rf) / (_PI * rf.numerator / rf.denominator)
                w2 = min((2 * r / taps) ** 2, Fraction(1))
                y *= _i0(b2 * (1 - Decimal(w2.numerator) / w2.denominator))
                row.append(y)
            half.append(row)
        norm = sum(half[0])
        rows = np.zeros((L + 1, taps), dtype='<f4')
        for p, row in enumerate(half):
            rows[p] = [np.float32(float(y / norm)) for y in row]
            if L % 2 == 0:
                for i in range(taps):
                    rows[L - p, taps - 1 - i] = rows[p, i]
    return rows[:L]

def table_sha256(src_rate: int, dst_rate: int, filter_size: int=FILTER_SIZE, coef_bits: int=COEF_BITS) -> str:
    """The pinned digest for a rate pair, looked up the one way."""
    try:
        return TABLE_SHA256[src_rate, dst_rate, filter_size, coef_bits]
    except KeyError:
        raise KeyError(f'no pinned resampler table for {src_rate}->{dst_rate} filter_size {filter_size} coef_bits {coef_bits}') from None

@lru_cache(maxsize=None)
def table(src_rate: int, dst_rate: int, filter_size: int=FILTER_SIZE, coef_bits: int=COEF_BITS) -> np.ndarray:
    """taps32() as integers, value * 2**coef_bits, rounded exactly."""
    scale = 1 << coef_bits
    t = taps32(src_rate, dst_rate, filter_size)
    h = np.array([[round(Fraction(float(v)) * scale) for v in row] for row in t], dtype='<i8')
    want = TABLE_SHA256.get((src_rate, dst_rate, filter_size, coef_bits))
    if want and hashlib.sha256(h.tobytes()).hexdigest() != want:
        raise AssertionError(f'resampler table {src_rate}->{dst_rate} filter_size {filter_size} changed')
    return h

def convolve(channel, frames: int, channels: int, src_rate: int, dst_rate: int, convert, dtype, filter_size: int=FILTER_SIZE, coef_bits: int=COEF_BITS) -> np.ndarray:
    """swr's filter over integer samples: channel(k) gives channel k as int64,"""
    h = table(src_rate, dst_rate, filter_size, coef_bits)
    L, M, taps, _ = design(src_rate, dst_rate, filter_size)
    c = (taps - 1) // 2
    if frames <= 2 * taps:
        raise ValueError('track too short to resample')
    n_out = -(-frames * L // M)
    out = np.empty((n_out, channels), dtype=dtype)
    inv = pow(M, -1, L)

    def job(win, k: int, p: int, q0: int, q1: int):
        dst = out[p * inv % L::L, k]
        for q in range(q0, q1, _BLOCK):
            rows = win[q:min(q + _BLOCK, q1)]
            dst[q:q + len(rows)] = convert(rows @ h[p])
    with ThreadPoolExecutor(min(8, os.cpu_count() or 1)) as pool:
        for k in range(channels):
            x = channel(k)
            ext = sliding_window_view(np.concatenate((x[c:0:-1], x, x[:-taps // 2 - 1:-1])), taps)
            jobs = []
            for p in range(L):
                j0 = p * inv % L
                win = ext[j0 * M // L::M]
                rows = len(range(j0, n_out, L))
                jobs += [pool.submit(job, win, k, p, q, min(q + _JOB_ROWS, rows)) for q in range(0, rows, _JOB_ROWS)]
            for f in jobs:
                f.result()
            del ext, x
    return out

def fma32(p: np.ndarray, c: np.ndarray) -> np.ndarray:
    """Fused multiply-add rounded once to float32, as AArch64's fmla does:"""
    s = p + c
    bb = s - p
    err = p - (s - bb) + (c - bb)
    r = s.astype(np.float32).astype(np.float64)
    other = 2 * s - r
    cand = np.flatnonzero((err != 0) & (other != r) & (other.astype(np.float32) == other))
    if len(cand):
        sc, rc, ec = (s.flat[cand], r.flat[cand], err.flat[cand])
        oc = other.flat[cand]
        lo, hi = (np.minimum(rc, oc), np.maximum(rc, oc))
        adjacent = np.nextafter(lo.astype(np.float32), np.float32(np.inf)) == hi
        mid = adjacent & (lo + hi == 2 * sc)
        r.flat[cand] = np.where(mid, np.where(ec > 0, hi, lo), rc)
    return r

def neon_dot(win: np.ndarray, h: np.ndarray) -> np.ndarray:
    """swr's aarch64 resample_common_float over rows of float32 windows: four"""
    n, taps = win.shape
    prod = np.ascontiguousarray((win.astype(np.float64).reshape(n, taps // 4, 4) * h.astype(np.float64).reshape(taps // 4, 4)).transpose(1, 0, 2))
    lanes = np.zeros((n, 4), dtype=np.float64)
    for p in prod:
        lanes = fma32(p, lanes)
    l32 = lanes.astype(np.float32)
    return l32[:, 0] + l32[:, 1] + (l32[:, 2] + l32[:, 3])

def convolve_f32(channel, frames: int, channels: int, src_rate: int, dst_rate: int, convert, dtype, filter_size: int=FILTER_SIZE, limit: int | None=None) -> np.ndarray:
    """swr's float resampler over float32 samples, reproduced exactly: the"""
    t = taps32(src_rate, dst_rate, filter_size)
    L, M, taps, _ = design(src_rate, dst_rate, filter_size)
    if taps % 4:
        raise ValueError('the arm64 accumulation needs a tap count divisible by 4')
    c = (taps - 1) // 2
    if frames <= 2 * taps:
        raise ValueError('track too short to resample')
    n_out = -(-frames * L // M)
    if limit is not None:
        n_out = min(n_out, limit)
    out = np.empty((n_out, channels), dtype=dtype)
    inv = pow(M, -1, L)

    def job(win, k: int, p: int, q0: int, q1: int):
        dst = out[p * inv % L::L, k]
        for q in range(q0, q1, _F32_BLOCK):
            rows = win[q:min(q + _F32_BLOCK, q1)]
            dst[q:q + len(rows)] = convert(neon_dot(rows, t[p]))
    exts = []
    for k in range(channels):
        x = channel(k)
        exts.append(sliding_window_view(np.concatenate((x[c:0:-1], x, x[:-taps // 2 - 1:-1])), taps))
    jobs = []
    step = max(_F32_BLOCK, -(-n_out // (L * 64)))
    with ThreadPoolExecutor(min(8, os.cpu_count() or 1)) as pool:
        for k, ext in enumerate(exts):
            for p in range(L):
                j0 = p * inv % L
                win = ext[j0 * M // L::M]
                rows = len(range(j0, n_out, L))
                jobs += [pool.submit(job, win, k, p, q, min(q + step, rows)) for q in range(0, rows, step)]
        for f in jobs:
            f.result()
    return out

def to_s16(acc: np.ndarray, frac_bits: int) -> np.ndarray:
    """acc / 2**frac_bits full-scale-1.0 float as arm64 swr converts it to"""
    shift = frac_bits - 31
    if shift <= 0:
        q31 = acc << -shift
    else:
        q31 = np.where(acc >= 0, acc >> shift, -(-acc >> shift))
    return np.clip(q31 >> 16, -32768, 32767).astype('<i2')

def resample(pcm: np.ndarray, src_rate: int, dst_rate: int, extra_bits: int=0) -> np.ndarray:
    """(frames, channels) integers worth s16 * 2**extra_bits (0 or 8) at"""
    if extra_bits not in (0, 8):
        raise ValueError('16- or 24-bit sources only')
    if src_rate == dst_rate:
        return to_s16(pcm.astype(np.int64) << 8 - extra_bits, 23)
    return convolve(lambda k: pcm[:, k].astype(np.int64) << 8 - extra_bits, len(pcm), pcm.shape[1], src_rate, dst_rate, lambda acc: to_s16(acc, COEF_BITS + 23), '<i2')
