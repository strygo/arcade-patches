"""Set the trigger-row gain of a built pack, in place."""
from __future__ import annotations
import argparse
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from pack.format import _parse_header, TriggerRow
CRC_TABLES_OFF = 132
_INDEX_ENTRY = 32

def set_gain(pack: Path, gain: int, dry: bool=False) -> int:
    if not 1 <= gain <= 127:
        raise SystemExit(f'gain {gain} out of range 1..0x7f')
    data = bytearray(pack.read_bytes())
    h = _parse_header(bytes(data))
    n = 0
    for i in range(h.trigger_rows):
        off = h.trigger_offset + 4 * i
        row = data[off:off + 4]
        if len(row) < 4 or row[0] == 0:
            continue
        r = TriggerRow.unpack(bytes(row))
        if r.gain != gain:
            data[off:off + 4] = TriggerRow(verb=r.verb, track=r.track, gain=gain, suppress=r.suppress).pack()
            n += 1
    import zlib, struct
    trig = bytes(data[h.trigger_offset:h.trigger_offset + 4 * h.trigger_rows])
    index = bytes(data[h.index_offset:h.data_offset])
    index = index[:_INDEX_ENTRY * h.track_count] if _INDEX_ENTRY else index
    crc = zlib.crc32(trig)
    crc = zlib.crc32(index, crc)
    struct.pack_into('<I', data, CRC_TABLES_OFF, crc & 4294967295)
    if not dry:
        pack.write_bytes(bytes(data))
    return n

def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('pack', type=Path)
    ap.add_argument('--gain', required=True, help='1..0x7f (0x7f = unity)')
    ap.add_argument('--dry-run', action='store_true')
    a = ap.parse_args(argv)
    g = int(a.gain, 0)
    n = set_gain(a.pack, g, a.dry_run)
    print(f"  {a.pack.name}: {n} trigger rows -> gain 0x{g:02x}{(' (dry run)' if a.dry_run else '')}")
    return 0
if __name__ == '__main__':
    raise SystemExit(main())
