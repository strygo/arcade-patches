"""Read a kit's TOML config the way the people who fill it in actually write it."""
from __future__ import annotations
import locale
import re
import sys
import tomllib
from pathlib import Path
_ASSIGN = re.compile('^(\\s*[A-Za-z0-9_-]+\\s*=\\s*)(\\S.*?)\\s*$')
_ALL_DOUBLED = re.compile('(?:[^\\\\]|\\\\\\\\)*')

def path_line(line: str) -> str:
    """One `key = value` line of a kit's config, made safe for tomllib."""
    m = _ASSIGN.match(line)
    if not m or line.lstrip().startswith('#'):
        return line
    head, rest = m.groups()
    if rest.startswith(("'", '[', '{', '"""')):
        return line
    if rest.startswith('"'):
        inner = rest.lstrip('"')
        end = inner.find('"')
        if end < 0:
            return line
        value, comment = (inner[:end], inner[end:].lstrip('"').strip())
        if comment and (not comment.startswith('#')):
            return line
        if '\\' not in value and len(rest) - len(inner) == 1:
            return line
    else:
        cut = re.search('\\s#', rest)
        value = (rest[:cut.start()] if cut else rest).strip()
        comment = rest[cut.start():].strip() if cut else ''
        if not re.search('[\\\\/:]', value):
            return line
    if _ALL_DOUBLED.fullmatch(value) and '\\\\' in value:
        value = value.replace('\\\\', '\\')
    fixed = head + '"' + value.replace('\\', '\\\\') + '"'
    return fixed + ('  ' + comment if comment else '')

def read_text(path: Path) -> str:
    raw = path.read_bytes()
    if raw[:2] in (b'\xff\xfe', b'\xfe\xff'):
        return raw.decode('utf-16')
    try:
        return raw.decode('utf-8-sig')
    except UnicodeDecodeError:
        enc = locale.getpreferredencoding(False)
        if enc.lower().replace('-', '') == 'utf8':
            enc = 'cp1252'
        print(f'{path.name}: not UTF-8, reading it as {enc}')
        return raw.decode(enc, errors='replace')

def unquote(v: str) -> str:
    v = v.strip()
    while len(v) >= 2 and v[0] == v[-1] and (v[0] in '"\''):
        v = v[1:-1].strip()
    return v

def load(path: Path) -> dict:
    lines = read_text(path).splitlines()
    try:
        return tomllib.loads('\n'.join((path_line(l) for l in lines)) + '\n')
    except tomllib.TOMLDecodeError as e:
        n = getattr(e, 'lineno', None)
        if n is None:
            m = re.search('line (\\d+)', str(e))
            n = int(m.group(1)) if m else None
        where = f'{path}:{n}' if n else str(path)
        shown = f'\n    {lines[n - 1].strip()}' if n and 0 < n <= len(lines) else ''
        sys.exit(f"""{where}: cannot read this line ({getattr(e, 'msg', e)}){shown}\nEach entry is one line:  key = "path"   -- a path copied from Explorer or Finder can be pasted between the quotes as it is.  Lines starting with # are ignored.""")
