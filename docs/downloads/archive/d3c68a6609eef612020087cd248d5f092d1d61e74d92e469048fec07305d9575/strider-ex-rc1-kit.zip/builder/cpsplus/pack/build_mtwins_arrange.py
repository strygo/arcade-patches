"""`build_mtwins_arrange.py` — Mega Twins / Chiki Chiki Boys (CPS1 `mtwins`) ARRANGE pack."""
from __future__ import annotations
import argparse
import dataclasses
from pathlib import Path
from . import adxcodec, protocols
from .audition import verify as audition_verify
from .build_common import MANIFESTS, PACKS_DIR, PKG_ROOT
from .adxencode import encode_adx_track, read_wav
from .build_common import MapRow, VERBS, _rows
from .protocols import cps1_protocol
from .format import PackWriter, PackReader, TrackMeta, TriggerRow, CODEC_ADX, VERB_NONE, VERB_PLAY, VERB_NAMES
CD_DIR = PKG_ROOT / 'work' / 'intermediate' / 'mtwins' / 'cd_full'
TRIGGER_TSV = MANIFESTS / 'mtwins_arrange_trigger_map.tsv'
INPUT_PINS = MANIFESTS / 'mtwins_arrange_inputs.json'
PINS_SOURCE = {'release': 'Chiki Chiki Boys (Japan), PC Engine Super CD-ROM2', 'rip': "cue sheet with one .bin per track (redump layout); every audio track extracted whole, its INDEX 00 pregap included, so crc32 is that track's .bin CRC32"}
DDR_HARD_CAP_BYTES = 256 * 1024 * 1024
MTWINS_ROM_BYTES = 3473408
ONE_SHOT: set[str] = set()

def load_triggers(path: Path=TRIGGER_TSV) -> list[MapRow]:
    """Parse the mtwins map.  Same 5-column shape as ffight (cmd, verb,"""
    out: list[MapRow] = []
    for r in _rows(path):
        if len(r) < 5:
            raise ValueError(f'short row in {path.name}: {r!r}')
        cmd_s, verb_s, sup_s, track_s, cue = (r[0], r[1], r[2], r[3], r[4])
        if cmd_s == 'cmd' and verb_s == 'verb':
            continue
        if verb_s not in VERBS:
            raise ValueError(f'cmd {cmd_s}: unknown verb {verb_s!r}')
        verb = VERBS[verb_s]
        cmd = int(cmd_s, 16)
        if not 0 <= cmd < protocols.SF2_TRIGGER_ROWS:
            raise ValueError(f'cmd {cmd_s} outside the CPS1 byte-command range')
        track = None if track_s.strip() in ('-', '') else track_s.strip()
        if verb == VERB_PLAY and track is None:
            raise ValueError(f'cmd {cmd_s}: verb=play with no track')
        if verb == VERB_NONE and track is not None:
            raise ValueError(f'cmd {cmd_s}: verb=none must not name a track')
        out.append(MapRow(cmd=cmd, verb=verb, suppress=int(sup_s), track=track, cue=cue))
    seen: dict[int, MapRow] = {}
    for row in out:
        if row.cmd in seen:
            raise ValueError(f'duplicate command 0x{row.cmd:02x} in {path.name}')
        seen[row.cmd] = row
    for secret in (27, 30):
        if secret in seen and (not (seen[secret].verb == VERB_NONE and seen[secret].suppress == 0)):
            raise ValueError(f'cmd 0x{secret:02x} is a SECRET arcade cue that must fail open (verb=none, suppress=0); got a suppressing row in {path.name}')
    return out

def build(out: str | None=None, triggers_path: str | None=None, cd_dir: str | None=None, measure_snr: bool=True, disc: str | None=None, check_inputs: bool=False, allow_input_mismatch: bool=False, write_pins: bool=False) -> dict:
    rows = load_triggers(Path(triggers_path) if triggers_path else TRIGGER_TSV)
    cd = Path(cd_dir) if cd_dir else CD_DIR
    from . import inputpins
    from .discsrc import check_audio_cache, ensure_audio_cache
    needed = {r.track for r in rows if r.track}
    ensure_audio_cache(cd, needed, disc, '--disc', pregap='keep')
    out_path = Path(out) if out else PACKS_DIR / 'mtwins_arrange.cpk'
    pins = None if write_pins else inputpins.load_pins(INPUT_PINS)
    checks = {}
    if pins:
        checks = check_audio_cache(cd, needed, INPUT_PINS, 'Chiki Chiki Boys (PC Engine CD)', '[mtwins]')
        inputpins.gate('mtwins_arrange', checks, pins, out_path, allow_input_mismatch, check_inputs, '[mtwins]')
    elif check_inputs:
        print(f'[mtwins] {INPUT_PINS.name} not found: nothing to check against')
        raise SystemExit(0)
    audit = inputpins.Audit('mtwins_arrange', pins, checks)
    pin_tracks: dict = {}
    play_rows = [r for r in rows if r.verb == VERB_PLAY]
    silence_rows = [r for r in rows if r.verb == VERB_NONE and r.suppress == 1]
    if silence_rows:
        raise ValueError(f'build_mtwins_arrange has no silence-only handling but the map has {len(silence_rows)} suppress=1 none row(s): {[hex(r.cmd) for r in silence_rows]}')
    proto = cps1_protocol()
    proto = dataclasses.replace(proto, game_id='mtwins')
    w = PackWriter(proto, title='Mega Twins (Arrange)', trigger_rows=protocols.SF2_TRIGGER_ROWS, default_rate=44100)
    ti_of: dict[str, int] = {}
    snrs: list[tuple[str, float]] = []
    total_audio = 0
    print('[mtwins] === ADX arrange pack ===')
    for row in play_rows:
        track = row.track
        if track not in ti_of:
            src = cd / f'{track}.wav'
            pcm, rate, ch, n = read_wav(src)
            if write_pins:
                pin_tracks[track] = inputpins.fingerprint(pcm)
            loops = track not in ONE_SHOT
            data, coef1, coef2, snr = encode_adx_track(pcm, rate, ch, n, track, measure_snr)
            if snr is not None:
                snrs.append((track, snr))
            if adxcodec.samples_to_stream_byte(0, ch) != 0:
                raise ValueError('loop start not frame-aligned')
            loop_end_byte = len(data) if loops else 0
            loop_end_sample = n if loops else 0
            if loops and loop_end_byte % (adxcodec.FRAME_BYTES * ch):
                raise ValueError(f'{track}: loop end not frame-aligned')
            audit.track(track, [track], pcm, data, (0, loop_end_sample, 0))
            meta = TrackMeta(sample_rate=rate, channels=ch, codec=CODEC_ADX, gain=127, loop_start_sample=0, loop_start_byte=0, loop_end_sample=loop_end_sample, loop_end_byte=loop_end_byte, coef1=coef1, coef2=coef2, xfade_enable=0, name=f"{track} ({('whole-track loop' if loops else 'one_shot')})", source=f'mtwins/cd_full/{track}.wav[0:{n}]')
            ti_of[track] = w.add_track(data, meta)
            total_audio += len(data)
            print(f"[mtwins] 0x{row.cmd:02x} -> {track} track{ti_of[track]:<3} {n / rate:7.2f}s  {('loop ' if loops else 'once ')}  {len(data) / 1000000.0:7.2f} MB  {row.cue}")
        else:
            print(f"[mtwins] 0x{row.cmd:02x} -> {track} track{ti_of[track]:<3} {'(shared)':>22}  {row.cue}")
        w.set_trigger(row.cmd, TriggerRow(verb=VERB_PLAY, track=ti_of[track], gain=127, suppress=row.suppress))
    w.write(out_path)
    size = out_path.stat().st_size
    rd = PackReader(out_path)
    try:
        for row in play_rows:
            got = rd.triggers[row.cmd]
            if got.verb != VERB_PLAY or got.suppress != row.suppress:
                raise ValueError(f'readback: cmd 0x{row.cmd:02x} verb/suppress mismatch')
            if got.track != ti_of[row.track]:
                raise ValueError(f'readback: cmd 0x{row.cmd:02x} wrong track')
        failopen = [r.cmd for r in rows if r.verb == VERB_NONE]
        for cmd in failopen:
            g = rd.triggers[cmd]
            if g.verb != VERB_NONE or g.suppress != 0:
                raise ValueError(f'readback: fail-open cmd 0x{cmd:02x} is not passthrough (verb {VERB_NAMES[g.verb]}, suppress {g.suppress})')
        if rd.header.proto.latch_page != 8388992:
            raise ValueError('readback: latch page is not the CPS1 dialect')
        if rd.header.trigger_rows != protocols.SF2_TRIGGER_ROWS:
            raise ValueError('readback: trigger table is not 256 rows')
    finally:
        rd.close()
    rec = audit.write(inputpins.audit_path(out_path), out_path)
    if pins:
        print(f"[mtwins] {out_path.name}: {rec['diagnosis']}")
    if write_pins:
        inputpins.write_pins(INPUT_PINS, PINS_SOURCE, dict(sorted(pin_tracks.items())), {'mtwins_arrange': audit.pins_entry(out_path)})
    image = size + MTWINS_ROM_BYTES
    print(f'[mtwins] {out_path}')
    print(f'[mtwins]   pack        {size:,} B ({size / 1000000.0:.1f} MB), {len(w.tracks)} tracks, {len(play_rows)} play triggers')
    print(f'[mtwins]   + ROM       {MTWINS_ROM_BYTES:,} B = image {image:,} B ({image / 1000000.0:.1f} MB)')
    over = image - DDR_HARD_CAP_BYTES
    verdict = f'OVER by {over:,} B' if over > 0 else f'fits, {-over:,} B ({-over / 1000000.0:.1f} MB) headroom'
    print(f'[mtwins]   256 MiB cap -> {100.0 * image / DDR_HARD_CAP_BYTES:.1f}% — {verdict}')
    print('[mtwins]   secret cues 0x1b/0x1e: unmapped -> fail open to arcade FM')
    if snrs:
        mean = sum((s for _, s in snrs)) / len(snrs)
        worst = min(snrs, key=lambda s: s[1])
        print(f'[mtwins]   ADX SNR: mean {mean:.2f} dB, worst {worst[0]} {worst[1]:.2f} dB')
    return {'path': out_path, 'size': size, 'image': image, 'tracks': len(w.tracks), 'snrs': snrs, 'audio': total_audio}

def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog='python -m cpsplus.pack.build_mtwins_arrange')
    ap.add_argument('--out')
    ap.add_argument('--triggers')
    ap.add_argument('--cd-dir')
    ap.add_argument('--disc', help='Chiki Chiki Boys (Japan) PCE CD rip: a .cue, or a .zip/.7z containing one (needed when the extraction cache is empty)')
    ap.add_argument('--no-snr', action='store_true')
    ap.add_argument('--no-verify', action='store_true')
    ap.add_argument('--check-inputs', action='store_true', help="only check the disc's tracks against the pinned inputs (one row per track) and exit: 0 all match, 3 not")
    ap.add_argument('--allow-input-mismatch', action='store_true', help='build even when tracks differ from the verified disc (it will not match the published pack)')
    ap.add_argument('--write-pins', action='store_true', help='maintainer: build from the verified disc and write ' + INPUT_PINS.name)
    a = ap.parse_args(argv)
    res = build(out=a.out, triggers_path=a.triggers, cd_dir=a.cd_dir, disc=a.disc, measure_snr=not a.no_snr, check_inputs=a.check_inputs, allow_input_mismatch=a.allow_input_mismatch, write_pins=a.write_pins)
    if not a.no_verify:
        audition_verify(str(res['path']))
    return 0
if __name__ == '__main__':
    raise SystemExit(main())
