"""cpsplus.pack — CPS2 arranged-audio pack toolchain (Phase 1)."""
