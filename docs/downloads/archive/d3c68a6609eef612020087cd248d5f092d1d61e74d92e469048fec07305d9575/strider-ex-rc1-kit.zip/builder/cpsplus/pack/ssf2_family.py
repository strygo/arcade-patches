"""The SSF2 family's shared packs."""
from __future__ import annotations
from . import protocols
from .format import VERB_FADE_KEEP, VERB_STOP
PROTOCOL = protocols.PROTOCOLS['ssf2']
GAME_ID = 'ssf2'
TURBO_STAND_INS = {211: 52, 212: 51}
FAIL_OPEN = {56: 'HERE COMES A NEW CHALLENGER plays over the BGM and hands it back', 61: 'the native QSound logo'}

def check_protocol(proto) -> None:
    """Raise unless `proto` is the family's shared contract."""
    if proto.control_verbs != {65280: VERB_STOP, 65287: VERB_FADE_KEEP}:
        raise ValueError(f'not the SSF2 family control map: {proto.control_verbs}')
    if (proto.latch_page, proto.off_arg_byte, proto.fade_law, proto.fade_const1, proto.fade_const2) != (6389760, 0, 2, 1092, 60):
        raise ValueError('not the SSF2 family latch/fade contract')
