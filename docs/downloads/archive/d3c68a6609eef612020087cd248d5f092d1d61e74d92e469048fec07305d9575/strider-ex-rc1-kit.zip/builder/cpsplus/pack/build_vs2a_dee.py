"""A partial VS2 Arrange pack: Collection Dee music, native QSound elsewhere."""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import struct
import subprocess
import tempfile
import zipfile
from . import adxcodec
from .build_common import MANIFESTS, PACKS_DIR, adx_entry_to_track
from .format import FADE_ANTHOLOGY, PackReader, PackWriter, Protocol, TriggerRow, VERB_FADE_KEEP, VERB_NONE, VERB_PLAY, VERB_STOP
RECIPE = MANIFESTS / 'vs2a_dee_recipe.json'

def require(ok, message):
    if not ok:
        raise ValueError(message)

def sha(data):
    return hashlib.sha256(data).hexdigest()

def protocol(recipe=None):
    return Protocol(game_id=(recipe or {}).get('game_id', 'vsav2-arrange'), fade_law=FADE_ANTHOLOGY, fade_const1=65535, control_verbs={65280: VERB_STOP, 65285: VERB_STOP, 65286: VERB_FADE_KEEP, 65287: VERB_FADE_KEEP})

def rows(recipe):
    writer = PackWriter(protocol(recipe), title=recipe.get('title', 'VS2 Arrange - Dee music + native QSound'))
    for command in recipe['native_music_commands']:
        writer.set_trigger(int(command, 0), TriggerRow(verb=VERB_STOP, suppress=0))
    for track, record in enumerate(recipe['tracks']):
        writer.set_trigger(int(record['command'], 0), TriggerRow(verb=VERB_PLAY, track=track, gain=recipe['trigger_gain'], suppress=1))
    return writer

class Dvd:
    """Bounded CHD reads; every extracted source is checked by content hash."""

    def __init__(self, path, work, recipe):
        self.path, self.work = (Path(path), work)
        from .media_tools import disc_tool
        self.tool = disc_tool('chdman')
        require(self.tool, 'chdman is required to read the Collection DVD')
        self.recipe = recipe
        info = subprocess.run([self.tool, 'info', '-i', str(self.path)], capture_output=True, text=True, check=True).stdout
        require('Data SHA1:    ' + recipe['disc']['data_sha1'] in info, 'Collection CHD data identity differs')
        with self.path.open('rb') as handle:
            header = handle.read(124)
        require(header[:8] == b'MComprHD' and struct.unpack_from('>II', header, 8) == (124, 5), 'a version-5 DVD CHD is required')
        require(struct.unpack_from('>Q', header, 32)[0] == recipe['disc']['logical_bytes'], 'Collection DVD logical size differs')
        self.header = header

    def read(self, offset, size):
        target = self.work / 'slice.bin'
        subprocess.run([self.tool, 'extractraw', '-i', str(self.path), '-o', str(target), '-isb', str(offset), '-ib', str(size), '-f'], check=True, capture_output=True)
        result = target.read_bytes()
        require(len(result) == size, 'short DVD extraction')
        return result

    def sources(self):
        pvd = self.read(16 * 2048, 2048)
        require(pvd[1:6] == b'CD001', 'DVD has no ISO9660 volume')
        base, size = (struct.unpack_from('<I', pvd, 158)[0], struct.unpack_from('<I', pvd, 166)[0])
        directory = self.read(base * 2048, size)
        files, at = ({}, 0)
        while at < len(directory):
            length = directory[at]
            if not length:
                at = (at // 2048 + 1) * 2048
                continue
            require(length >= 34 and at + length <= len(directory), 'bad ISO directory record')
            name = directory[at + 33:at + 33 + directory[at + 32]].decode('ascii')
            files[name] = (struct.unpack_from('<I', directory, at + 2)[0] * 2048, struct.unpack_from('<I', directory, at + 10)[0])
            at += length
        base, size = files['Y_DATA.BIN;1']
        require(size == self.recipe['afs']['bytes'], 'Y_DATA size differs')
        table = self.read(base, 8 + 8 * self.recipe['afs']['entries'] + 8)
        require(table[:4] == b'AFS\x00' and struct.unpack_from('<I', table, 4)[0] == self.recipe['afs']['entries'] and (sha(table) == self.recipe['afs']['table_sha256']), 'Y_DATA archive table identity differs')
        result = {}
        for track in self.recipe['tracks']:
            entry = track['entry']
            offset, length = struct.unpack_from('<II', table, 8 + 8 * entry)
            require(offset + length <= size, 'ADX entry exceeds Y_DATA')
            blob = self.read(base + offset, length)
            require(len(blob) == track['bytes'] and sha(blob) == track['sha256'], f'ADX entry {entry} identity differs')
            (self.work / f'entry_{entry}.adx').write_bytes(blob)
            result[entry] = blob
        return result

    def unchanged(self):
        with self.path.open('rb') as handle:
            require(handle.read(124) == self.header, 'DVD header changed during build')

def verify_mapping(reader, recipe):
    expected = rows(recipe)
    require(reader.header.proto == expected.proto, 'pack protocol differs')
    require(reader.header.track_count == 3 and reader.header.trigger_rows == len(expected.triggers), 'pack table/track count differs')
    require(reader.triggers == expected.triggers, 'native handoff or Dee trigger mapping differs')
    require(reader.crc_check() == (True, True), 'pack CRCs failed')

def check_sources(pack, blobs, recipe):
    """Re-read written streams and compare every valid decoded source sample."""
    reader = PackReader(pack)
    checks = []
    try:
        for i, record in enumerate(recipe['tracks']):
            raw = blobs[record['entry']]
            info = adxcodec.parse_header(raw)
            meta = reader.tracks[i]
            stream = reader.read_track(i)
            require(stream == raw[info.data_offset:info.loop_end_byte], 'written ADX frame stream differs from DVD')
            require((meta.loop_start_byte, meta.loop_end_byte) == (info.loop_start_byte - info.data_offset, info.loop_end_byte - info.data_offset), 'authored loop bytes changed')
            samples = len(stream) // 36 * 32
            packed_pcm = adxcodec.decode(stream, 2, 48000, total_samples=samples)
            source_pcm, _ = adxcodec.decode_file_bytes(raw)
            valid = min(samples, info.total_samples) * 4
            require(len(source_pcm) >= valid and len(packed_pcm) == samples * 4 and (packed_pcm[:valid] == source_pcm[:valid]), 'source PCM differs')
            padding = samples - valid // 4
            require(0 <= padding < 32, 'more than a partial ADX frame of padding')
            checks.append({'entry': record['entry'], 'byte_exact': True, 'sample_exact_pairs': valid // 4, 'final_frame_padding_samples': padding})
    finally:
        reader.close()
    return checks

def validate_native_driver(rompath, recipe):
    with zipfile.ZipFile(Path(rompath) / (recipe['native_driver']['set'] + '.zip')) as archive:
        parts = [archive.read(name) for name in recipe['native_driver']['members_sha1']]
        require(all((hashlib.sha1(data).hexdigest() == pin for data, pin in zip(parts, recipe['native_driver']['members_sha1'].values()))), 'native audio driver identity differs')
    blob = b''.join(parts)
    modulus = int(recipe['native_driver'].get('command_modulus', '0xa70'), 0)
    require(struct.unpack_from('<H', blob, 15104)[0] == 36864 and struct.unpack_from('>H', blob, 36864)[0] == modulus, 'native command-table layout differs')
    commands = []
    for i in range(modulus):
        at = 36870 + 4 * i
        address = blob[at] << 16 | struct.unpack_from('>H', blob, at + 1)[0]
        if address and blob[address] == 0:
            commands.append(hex(i))
    require(commands == recipe['native_music_commands'], 'native handoff list differs from BGM scripts')
    require(struct.unpack_from('<H', blob, 2450 + 2 * 5)[0] == 2742 and blob[2742:2746] == bytes.fromhex('dd2100f7') and (blob[1825:1829] == bytes.fromhex('dd2100f7')), 'FF05 does not clear the kind-0 music pool')

def build(disc, work, out, rompath, recipe_path=RECIPE):
    recipe_path = Path(recipe_path)
    recipe = json.loads(recipe_path.read_text())
    work, out = (Path(work), Path(out))
    require(not work.exists(), 'use a new empty --work directory')
    require(any((p.is_symlink() and p.exists() for p in work.absolute().parents)), '--work must use the configured mounted scratch link')
    work.mkdir(parents=True)
    before = sha(recipe_path.read_bytes())
    validate_native_driver(rompath, recipe)
    dvd = Dvd(disc, work, recipe)
    blobs = dvd.sources()
    writer = rows(recipe)
    for record in recipe['tracks']:
        stream, meta, info = adx_entry_to_track(blobs[record['entry']], name=record['name'], source=f"Vampire Collection JP / Y_DATA.BIN / ADX {record['entry']}")
        require(info.channels == 2 and info.sample_rate == 48000 and (info.loop_flag == 1), 'Dee ADX audio/loop format differs')
        writer.add_track(stream, meta)
    writer.write(out)
    reader = PackReader(out)
    try:
        verify_mapping(reader, recipe)
        metadata = [{'command': r['command'], 'entry': r['entry'], 'audio_sha256': sha(reader.read_track(i)), 'loop_start_byte': m.loop_start_byte, 'loop_end_byte': m.loop_end_byte, 'loop_start_sample': m.loop_start_sample, 'loop_end_sample': m.loop_end_sample} for i, (r, m) in enumerate(zip(recipe['tracks'], reader.tracks))]
    finally:
        reader.close()
    check = check_sources(out, dvd.sources(), recipe)
    dvd.unchanged()
    validate_native_driver(rompath, recipe)
    require(before == sha(recipe_path.read_bytes()), 'recipe changed during build')
    receipt = {'schema_version': 1, 'status': 'pass', 'recipe_sha256': before, 'pack_sha256': sha(out.read_bytes()), 'bytes': out.stat().st_size, 'source_decode': check, 'tracks': metadata, 'native_music_handoffs': len(recipe['native_music_commands']), 'rom_changes': False, 'hardware_review': False}
    (work / 'receipt.json').write_text(json.dumps(receipt, indent=2, sort_keys=True) + '\n')
    print(f"PASS {out.name}: {receipt['bytes']} bytes, three byte-exact Dee songs; hardware pending")
    return receipt

def self_test(recipe_path=RECIPE):
    recipe = json.loads(Path(recipe_path).read_text())
    writer = rows(recipe)
    require(all((r.suppress == int(r.verb == VERB_PLAY) for r in writer.triggers)), 'native commands must never be suppressed')
    native_command = int(recipe['gain_calibration']['native_command'], 0)
    require(writer.triggers[127].verb == VERB_PLAY and writer.triggers[native_command].verb == VERB_STOP, 'Dee boss/native handoff classification differs')
    require(all((writer.triggers[c].verb == VERB_NONE for c in (257, 1271, 1943, 2688))), 'native voice/effect was classified as music')
    require(writer.proto.control_verbs[65285] == VERB_STOP, 'native BGM-stop control missing')
    from .format import CODEC_PCM, TrackMeta
    for i in range(3):
        writer.add_track(bytes(128), TrackMeta(sample_rate=48000, channels=2, codec=CODEC_PCM))
    with tempfile.TemporaryDirectory() as tmp:
        pack = writer.write(Path(tmp) / 'test.cpk')
        reader = PackReader(pack)
        try:
            verify_mapping(reader, recipe)
            writer.set_trigger(44, TriggerRow())
            altered = writer.write(Path(tmp) / 'bad.cpk')
            bad = PackReader(altered)
            try:
                try:
                    verify_mapping(bad, recipe)
                except ValueError:
                    pass
                else:
                    raise AssertionError('missing native handoff accepted')
            finally:
                bad.close()
        finally:
            reader.close()
    print('PASS ' + recipe['pack'] + ' self-test: native handoffs, effect isolation, mapping mutation rejected')

def main(argv=None, recipe_path=RECIPE):
    recipe_path = Path(recipe_path)
    recipe = json.loads(recipe_path.read_text())
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--disc', type=Path)
    parser.add_argument('--work', type=Path)
    parser.add_argument('--rompath', type=Path, default=recipe_path.parents[2] / 'roms/mame0260')
    parser.add_argument('--out', type=Path, default=PACKS_DIR / (recipe['pack'] + '.cpk'))
    parser.add_argument('--self-test', action='store_true')
    args = parser.parse_args(argv)
    if args.self_test:
        self_test(recipe_path)
        return 0
    if args.disc is None or args.work is None:
        parser.error('--disc and --work are required')
    build(args.disc, args.work, args.out, args.rompath, recipe_path)
    return 0
