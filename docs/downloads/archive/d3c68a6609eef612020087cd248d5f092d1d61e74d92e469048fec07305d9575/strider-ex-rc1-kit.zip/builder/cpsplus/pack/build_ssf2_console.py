"""Build the 3DO and FM Towns SSF2 soundtrack packs."""
from __future__ import annotations
import argparse
import csv
import hashlib
import sys
import tomllib
import wave
from dataclasses import dataclass
from math import ceil
from pathlib import Path
import numpy as np
from . import adxcodec, ssf2_family
from .adxencode import encode_adx_track
from .build_common import MANIFESTS, PACKS_DIR, PKG_ROOT, REPO_ROOT
from .build_hsf2 import TRIG_GAIN
from .format import CODEC_ADX, VERB_NONE, VERB_PLAY, PackReader, PackWriter, TrackMeta, TriggerRow
LOOP_MAP_TSV = MANIFESTS / 'ssf2_console_loop_map.tsv'
HSF2_MAP_TSV = MANIFESTS / 'hsf2_bgm_command_map.tsv'
TRIGGER_ROWS = 4608
CHANNELS = 2
RATE = 44100
BUILD = ('LOOP_OK', 'ONE_SHOT')
NATIVE_RESTORE_CMDS = frozenset({56})
LEAD_THRESHOLD = 200
LEAD_PREROLL = 256
LEAD_RMS = 60
LEAD_MIN = 4410
TAIL_MAX_DB = 3.0
ARRANGE_GAIN_TOL_DB = 0.5

@dataclass(frozen=True)
class Source:
    key: str
    pack_name: str
    title: str
    note: str
    disc_key: str
SOURCES = {'3do': Source('3do', 'ssf2_3do.cpk', 'Super Street Fighter II Turbo (3DO Soundtrack)', "the 3DO disc's /BGM SDX2 audio", 'ssf2t_3do_disc'), 'fmtowns': Source('fmtowns', 'ssf2_fmtowns.cpk', 'Super Street Fighter II (FM Towns Soundtrack)', "the FM Towns disc's Red Book audio", 'ssf2_fmtowns_disc')}

def _align32(value: int) -> int:
    return value // 32 * 32

def xfade_samples() -> int:
    return _align32(RATE)

def pcm_sha1(pcm: np.ndarray) -> str:
    return hashlib.sha1(np.ascontiguousarray(pcm, dtype='<i2').tobytes()).hexdigest()[:16]

def load_map(source: str, path: Path=LOOP_MAP_TSV) -> list[dict]:
    with path.open(newline='', encoding='utf-8') as f:
        rows = [r for r in csv.DictReader(f, delimiter='\t') if r['source'] == source]
    if not rows:
        raise ValueError(f'{path.name}: no rows for source {source}')
    return rows

def load_arrange(path: Path=HSF2_MAP_TSV) -> dict[int, tuple[int, int]]:
    """cmd -> (HSF2 arrange entry, Capcom's volume) for the in-game ARRANGE rows."""
    out: dict[int, tuple[int, int]] = {}
    with path.open(newline='', encoding='utf-8') as f:
        for r in csv.DictReader(f, delimiter='\t'):
            if r['set'] == 'ARRANGE' and r['in_game'] == 'yes':
                out[int(r['cmd'], 0)] = (int(r['afs_entry']), int(r['vol'], 0))
    return out

def solve_gains(items: dict[int, tuple[int, float]], base: int=TRIG_GAIN['arrange']) -> tuple[int, dict[int, int]]:
    """entry -> (vol, level_db)  ==>  (trigger gain, entry -> track gain)."""
    want = {e: base * vol * 10 ** (-lvl / 20) for e, (vol, lvl) in items.items()}
    trig = max(1, ceil(max(want.values()) / 127))
    out = {}
    for e, p in want.items():
        g = round(p / trig)
        if not 1 <= g <= 127:
            raise ValueError(f'entry {e}: track gain {g} out of range')
        out[e] = g
    return (trig, out)

def lead_trim(pcm: np.ndarray) -> int:
    """Samples of leading silence to cut, or 0 when the cue starts at once."""
    peak = np.abs(pcm.astype(np.int32)).max(axis=1)
    for i in np.flatnonzero(peak > LEAD_THRESHOLD):
        after = pcm[i + 50:i + 50 + 441].astype(np.float64)
        if len(after) < 441:
            break
        if np.sqrt((after ** 2).mean()) > LEAD_RMS:
            return max(0, int(i) - LEAD_PREROLL) if i - LEAD_PREROLL >= LEAD_MIN else 0
    return 0

def load_pcm(source: str, disc: str, cache: Path, tracks: set[str]) -> dict[str, np.ndarray]:
    out: dict[str, np.ndarray] = {}
    if source == '3do':
        sys.path.insert(0, str(PKG_ROOT / 'tools'))
        import extract_3do_bgm as e3
        fs = e3.open_disc(disc)
        for name, a in e3.read_bgm(fs):
            stem = name.rsplit('.', 1)[0]
            if stem in tracks:
                if int(round(a.rate)) != RATE or a.channels != CHANNELS:
                    raise ValueError(f'3DO {name}: {a.rate} Hz/{a.channels}ch')
                out[stem] = e3.decode_aifc(a)
    else:
        from . import discsrc
        discsrc.ensure_audio_cache(cache, tracks, disc, '--disc')
        for t in tracks:
            with wave.open(str(cache / f'{t}.wav')) as w:
                if (w.getframerate(), w.getnchannels()) != (RATE, CHANNELS):
                    raise ValueError(f'{t}.wav: {w.getframerate()} Hz/{w.getnchannels()}ch')
                out[t] = np.frombuffer(w.readframes(w.getnframes()), '<i2').reshape(-1, CHANNELS)
    missing = tracks - out.keys()
    if missing:
        raise FileNotFoundError(f'{source}: tracks not on the disc: {sorted(missing)}')
    return out

def plan(rows: list[dict], arrange: dict[int, tuple[int, int]]):
    """Which map rows build, which commands they answer, and what fails open."""
    by_entry = {int(r['entry']): r for r in rows if r['cls'] in BUILD}
    cmds_of: dict[int, list[int]] = {}
    for cmd, (entry, _vol) in arrange.items():
        if cmd in NATIVE_RESTORE_CMDS or cmd in ssf2_family.FAIL_OPEN:
            continue
        if entry in by_entry:
            cmds_of.setdefault(entry, []).append(cmd)
    for entry, r in by_entry.items():
        listed = sorted((int(c, 0) for c in r['cmds'].split()))
        got = sorted(cmds_of.get(entry, []))
        want = [c for c in listed if c not in NATIVE_RESTORE_CMDS | set(ssf2_family.FAIL_OPEN)]
        if want != got:
            raise ValueError(f'entry {entry}: loop map says commands {want}, hsf2_bgm_command_map.tsv says {got}')
    by_entry = {e: r for e, r in by_entry.items() if cmds_of.get(e)}
    return (list(by_entry.values()), by_entry, cmds_of)

def build(*, source: str, disc: str, out: Path | None=None, cache: Path | None=None, allow_input_mismatch: bool=False, measure_snr: bool=False, compare: Path | None=None) -> dict:
    spec = SOURCES[source]
    proto = ssf2_family.PROTOCOL
    ssf2_family.check_protocol(proto)
    arrange = load_arrange()
    rows = load_map(source)
    usable, by_entry, cmds_of = plan(rows, arrange)
    vol_of = {}
    for cmd, (entry, vol) in arrange.items():
        if vol_of.setdefault(entry, vol) != vol:
            raise ValueError(f'entry {entry} carries two volumes')
    trig_gain, track_gain = solve_gains({e: (vol_of[e], float(r['level_db'])) for e, r in by_entry.items()})
    cache = cache or PKG_ROOT / 'work' / 'console_loops' / source
    pcms = load_pcm(source, disc, cache, {r['track'] for r in usable})
    for r in usable:
        got = pcm_sha1(pcms[r['track']])
        if got != r['pcm_sha1']:
            msg = f"{source} {r['track']}: decoded audio sha1 {got} is not the {r['pcm_sha1']} the loop map was made from -- a different rip?"
            if not allow_input_mismatch:
                raise ValueError(msg)
            print(f'[ssf2-console:{source}] WARNING {msg}')
    xfade = xfade_samples()
    w = PackWriter(proto, title=spec.title, trigger_rows=TRIGGER_ROWS, default_rate=RATE, xfade_samples=xfade)
    track_of: dict[int, int] = {}
    loops = 0
    print(f'[ssf2-console:{source}] === {spec.title} ===')
    print(f'[ssf2-console:{source}] {spec.note}; trigger gain 0x{trig_gain:02x}')
    for r in sorted(usable, key=lambda r: int(r['entry'])):
        entry = int(r['entry'])
        pcm = pcms[r['track']]
        trim = lead_trim(pcm)
        pcm = pcm[trim:]
        if r['cls'] == 'LOOP_OK':
            ls, le = (_align32(int(r['loop_start']) - trim), _align32(int(r['loop_end']) - trim))
            if ls < 0 or le - ls <= xfade:
                raise ValueError(f"{r['track']}: loop {ls}-{le} cannot take a crossfade")
            keep = le + xfade
            if keep > len(pcm):
                raise ValueError(f"{r['track']}: needs {keep} frames, holds {len(pcm)}")
            body = pcm[le - xfade:le].astype(np.float64)
            tail = pcm[le:keep].astype(np.float64)
            db = 20 * np.log10((np.sqrt((tail ** 2).mean()) + 1e-09) / (np.sqrt((body ** 2).mean()) + 1e-09))
            if abs(db) > TAIL_MAX_DB:
                raise ValueError(f"{r['track']}: crossfade tail is {db:+.1f} dB from the body -- the loop end is in the fade")
            pcm, kind, xf = (pcm[:keep], 'xfade loop', 1)
            loops += 1
        else:
            keep, ls, le, kind, xf = (len(pcm), 0, 0, 'one-shot', 0)
        data, c1, c2, _snr = encode_adx_track(pcm.tobytes(), RATE, CHANNELS, keep, r['hsf2_name'], measure_snr)
        meta = TrackMeta(sample_rate=RATE, channels=CHANNELS, codec=CODEC_ADX, gain=track_gain[entry], loop_start_sample=ls, loop_start_byte=adxcodec.samples_to_stream_byte(ls, CHANNELS) if xf else 0, loop_end_sample=le, loop_end_byte=adxcodec.samples_to_stream_byte(le, CHANNELS) if xf else 0, coef1=c1, coef2=c2, xfade_enable=xf, name=f"{r['hsf2_name']} ({kind})", source=f"{source}/{r['track']}")
        track_of[entry] = w.add_track(data, meta)
        print(f"[ssf2-console:{source}] t{track_of[entry]:02d} {r['hsf2_name']:<22} {keep / RATE:7.2f}s  {kind:<10} gain 0x{track_gain[entry]:02x}" + (f'  lead-in cut {trim / RATE:.2f}s' if trim else ''))
    cmd_track: dict[int, int] = {}
    for entry, cmds in cmds_of.items():
        for cmd in cmds:
            cmd_track[cmd] = track_of[entry]
    stand_ins = {}
    for cmd, src in ssf2_family.TURBO_STAND_INS.items():
        if cmd not in cmd_track and src in cmd_track:
            cmd_track[cmd] = cmd_track[src]
            stand_ins[cmd] = src
    for cmd, t in sorted(cmd_track.items()):
        w.set_trigger(cmd, TriggerRow(verb=VERB_PLAY, track=t, gain=trig_gain, suppress=1))
    out_path = out or PACKS_DIR / spec.pack_name
    w.write(out_path)
    rd = PackReader(str(out_path))
    try:
        if rd.header.game_id != ssf2_family.GAME_ID or rd.header.trigger_rows != TRIGGER_ROWS:
            raise ValueError('readback: wrong game id or trigger table size')
        ssf2_family.check_protocol(rd.header.proto)
        for cmd, got in enumerate(rd.triggers):
            if cmd in cmd_track:
                if (got.verb, got.track, got.gain, got.suppress) != (VERB_PLAY, cmd_track[cmd], trig_gain, 1):
                    raise ValueError(f'readback: 0x{cmd:02x} does not map as built')
            elif got.verb != VERB_NONE or got.suppress:
                raise ValueError(f'readback: unmapped 0x{cmd:04x} does not fail open')
        for cmd in NATIVE_RESTORE_CMDS | set(ssf2_family.FAIL_OPEN):
            if rd.triggers[cmd].verb != VERB_NONE:
                raise ValueError(f'readback: 0x{cmd:02x} must pass through to the board')
    finally:
        rd.close()
    open_cmds = sorted((c for c, (e, _v) in arrange.items() if c not in cmd_track and c not in NATIVE_RESTORE_CMDS and (c not in ssf2_family.FAIL_OPEN)))
    size = out_path.stat().st_size
    if stand_ins:
        print(f'[ssf2-console:{source}] Turbo stand-ins: ' + ', '.join((f"0x{c:02x} plays 0x{s:02x}'s track" for c, s in sorted(stand_ins.items()))))
    print(f'[ssf2-console:{source}] {len(open_cmds)} commands fail open to the board: ' + ' '.join((f'0x{c:02x}' for c in open_cmds)))
    print(f'[ssf2-console:{source}] {out_path}: {len(track_of)} tracks, {len(cmd_track)} play commands, {loops} loops, {size / 1000000.0:.1f} MB')
    res = {'path': out_path, 'size': size, 'tracks': len(track_of), 'commands': len(cmd_track), 'loops': loops, 'fail_open': open_cmds}
    if compare:
        res['level_diff_db'] = compare_levels(out_path, compare, source)
    return res

def _pack_pcm(rd: PackReader, cmd: int, seconds: float) -> np.ndarray:
    """The first `seconds` of the track a command plays, decoded, scaled by the"""
    t = rd.triggers[cmd]
    m = rd.tracks[t.track]
    stream = rd.read_track(t.track)
    fb = adxcodec.FRAME_BYTES * m.channels
    frames = min(len(stream) // fb, int(seconds * m.sample_rate) // adxcodec.FRAME_SAMPLES)
    pcm = np.frombuffer(adxcodec.decode(stream[:frames * fb], m.channels, m.sample_rate), '<i2').astype(np.float64)
    return pcm * (t.gain / 127) * (m.gain / 127)

def _seconds(rd: PackReader, cmd: int) -> float:
    m = rd.tracks[rd.triggers[cmd].track]
    return len(rd.read_track(rd.triggers[cmd].track)) / (adxcodec.FRAME_BYTES * m.channels) * adxcodec.FRAME_SAMPLES / m.sample_rate

def compare_levels(mine: Path, arrange: Path, source: str, seconds: float=20.0) -> float:
    """Decode the start of every command both packs play and compare the"""
    a, b = (PackReader(str(mine)), PackReader(str(arrange)))
    try:
        diffs: dict[int, float] = {}
        for cmd, ta in enumerate(a.triggers):
            if ta.verb != VERB_PLAY or b.triggers[cmd].verb != VERB_PLAY:
                continue
            src = ssf2_family.TURBO_STAND_INS.get(cmd)
            if src is not None and a.triggers[src].track == ta.track:
                continue
            win = min(seconds, 0.6 * min(_seconds(a, cmd), _seconds(b, cmd)))
            xa, xb = (_pack_pcm(a, cmd, win), _pack_pcm(b, cmd, win))
            ma, mb = (xa.reshape(-1, CHANNELS).mean(axis=1), xb.reshape(-1, CHANNELS).mean(axis=1))
            ra, rb = (a.tracks[ta.track].sample_rate, b.tracks[b.triggers[cmd].track].sample_rate)
            step = 2.0 if win >= 4.0 else win
            vals = []
            for t in np.arange(0.0, win - step + 1e-09, step):
                pa = np.sqrt((ma[int(t * ra):int((t + step) * ra)] ** 2).mean())
                pb = np.sqrt((mb[int(t * rb):int((t + step) * rb)] ** 2).mean())
                if pa > 0 and pb > 0:
                    vals.append(20 * np.log10(pa / pb))
            if vals:
                diffs[cmd] = float(np.median(vals))
        if not diffs:
            raise ValueError('no commands in common with the arrange pack')
        worst = max(diffs.values(), key=abs)
        print(f'[ssf2-console:{source}] loudness vs ssf2_arrange: {len(diffs)} commands, worst {worst:+.2f} dB, mean abs {np.mean([abs(v) for v in diffs.values()]):.2f} dB (tolerance {ARRANGE_GAIN_TOL_DB})')
        bad = {c: v for c, v in diffs.items() if abs(v) > ARRANGE_GAIN_TOL_DB}
        if bad:
            raise ValueError(f'{source}: outside {ARRANGE_GAIN_TOL_DB} dB of ssf2_arrange: ' + ', '.join((f'0x{c:02x} {v:+.2f}' for c, v in sorted(bad.items()))))
        return worst
    finally:
        a.close()
        b.close()

def self_test() -> int:
    trig, g = solve_gains({1: (104, -5.0), 2: (120, -2.0)})
    assert 112 <= max(g.values()) <= 127, (trig, g)
    for e, (vol, lvl) in {1: (104, -5.0), 2: (120, -2.0)}.items():
        got = trig * g[e]
        want = 29 * vol * 10 ** (-lvl / 20)
        assert abs(20 * np.log10(got / want)) < 0.15, (e, got, want)
    assert solve_gains({1: (104, -9.0)})[0] * 127 >= 29 * 104
    x = np.zeros((20000, 2), np.int16)
    x[10000:, 0] = 1000
    assert lead_trim(x) == 10000 - LEAD_PREROLL
    x[:8, 1] = 3000
    assert lead_trim(x) == 10000 - LEAD_PREROLL
    x[:100, 1] = 500
    assert lead_trim(x) == 0
    x = np.zeros((20000, 2), np.int16)
    x[1000:, 0] = 1000
    assert lead_trim(x) == 0
    arr = {1: (1, 104), 56: (56, 112), 211: (65, 104), 52: (52, 120)}
    rows = [{'cls': 'LOOP_OK', 'entry': '1', 'cmds': '0x01'}, {'cls': 'ONE_SHOT', 'entry': '56', 'cmds': '0x38'}, {'cls': 'PAST_END', 'entry': '52', 'cmds': '0x34'}, {'cls': 'ONE_SHOT', 'entry': '65', 'cmds': '0xd3'}]
    usable, by_entry, cmds_of = plan(rows, arr)
    assert sorted(by_entry) == [1, 65] and cmds_of == {1: [1], 65: [211]}, cmds_of
    rows[0]['cmds'] = '0x02'
    try:
        plan(rows, arr)
    except ValueError:
        pass
    else:
        raise AssertionError('a map that disagrees with the command table must refuse')
    assert xfade_samples() == 44096 and _align32(44100) == 44096
    print('PASS ssf2-console: gains, lead-in, plan, refusals')
    return 0

def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--self-test', action='store_true')
    ap.add_argument('--source', choices=sorted(SOURCES))
    ap.add_argument('--disc', help='the disc (default: release/discs.toml)')
    ap.add_argument('--out', type=Path)
    ap.add_argument('--cache', type=Path, help='FM Towns CD-DA cache dir')
    ap.add_argument('--work', type=Path, help="scratch root for the disc caches (default: this tree's work/)")
    ap.add_argument('--allow-input-mismatch', action='store_true')
    ap.add_argument('--measure-snr', action='store_true')
    ap.add_argument('--compare', type=Path, metavar='ARRANGE_CPK', help='also check loudness against a built ssf2_arrange pack')
    a = ap.parse_args(argv)
    if a.self_test:
        return self_test()
    if not a.source:
        ap.error('--source is required')
    if a.work:
        from . import discsrc, sources
        sources.CACHE_DIR = a.work / 'cache'
        discsrc.DISC_CACHE = a.work / 'discs'
        a.cache = a.cache or a.work / 'console_loops' / a.source
    disc = a.disc
    if not disc:
        cfg = tomllib.loads((REPO_ROOT / 'release' / 'discs.toml').read_text())
        disc = cfg.get(SOURCES[a.source].disc_key)
        if not disc:
            ap.error(f'no --disc and {SOURCES[a.source].disc_key} is not in release/discs.toml')
    build(source=a.source, disc=disc, out=a.out, cache=a.cache, allow_input_mismatch=a.allow_input_mismatch, measure_snr=a.measure_snr, compare=a.compare)
    return 0
if __name__ == '__main__':
    raise SystemExit(main())
