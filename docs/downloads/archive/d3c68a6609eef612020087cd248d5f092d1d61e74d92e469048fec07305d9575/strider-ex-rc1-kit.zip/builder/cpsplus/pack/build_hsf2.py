"""`build_pack.py hsf2` — fully automatic packs from the HSF2 AE PS2 disc."""
from __future__ import annotations
import hashlib
import re
import struct
from pathlib import Path
from . import protocols, ssf2_family
from .afs import AfsArchive
from .build_common import adx_entry_to_track, crosscheck_pack, MANIFESTS, PACKS_DIR
from .format import PackWriter, TriggerRow, VERB_NONE, VERB_PLAY, VERB_STOP
from .isofs import IsoFS
from .sources import resolve_image
TRIG_GAIN = {'arrange': 29, 'cps1': 24}
PACK_NAMES = {'arrange': 'ssf2_arrange', 'cps1': 'ssf2_cps1'}
TITLES = {'arrange': 'SSF2 family arranged soundtrack (HSF2 AE PS2)', 'cps1': 'SSF2 family CPS-1 soundtrack (HSF2 AE PS2)'}
STANDALONE_ARRANGE_MAPS = (MANIFESTS / 'ssf2_arrange_trigger_map.tsv', MANIFESTS / 'ssf2t_arrange_trigger_map.tsv')
NATIVE_RESTORE_CMDS = frozenset({56})

def _boot_elf_name(iso: IsoFS) -> str:
    cnf = iso.read_file('/SYSTEM.CNF').decode('ascii', 'replace')
    m = re.search('BOOT2\\s*=\\s*cdrom0:\\\\([^;\\s]+)', cnf)
    if not m:
        raise ValueError('cannot parse SYSTEM.CNF BOOT2')
    return m.group(1)

def _standalone_arrange_entries(path: Path) -> dict[int, int]:
    """cmd -> arrange entry from a standalone game's own identification."""
    rows = [line for line in path.read_text(encoding='utf-8').splitlines() if line.strip() and (not line.startswith('#'))]
    hdr = rows[0].split('\t')
    out = {}
    for line in rows[1:]:
        f = dict(zip(hdr, line.split('\t')))
        out[int(f['cmd'], 16)] = int(f['arrange_entry'])
    return out

def _load_manifest_map(bank: str) -> dict[int, tuple[int, int, str]]:
    """cmd -> (afs_entry, vol, in_game) for the chosen bank, from the TSV."""
    path = MANIFESTS / 'hsf2_bgm_command_map.tsv'
    if not path.exists():
        return {}
    want_set = {'arrange': 'ARRANGE', 'cps2': 'CPS2', 'cps1': 'CPS1'}[bank]
    out = {}
    rows = path.read_text(encoding='utf-8').splitlines()
    hdr = rows[0].split('\t')
    for line in rows[1:]:
        f = dict(zip(hdr, line.split('\t')))
        if f['set'] != want_set:
            continue
        out[int(f['cmd'], 16)] = (int(f['afs_entry']), int(f['vol'], 16), f['in_game'])
    return out

def build(iso_path: str, out: str | None=None, bank: str='arrange', table_offset: int | None=None, crosscheck: bool=True) -> Path:
    if bank not in protocols.HSF2_BANKS:
        raise ValueError(f'bank must be one of {list(protocols.HSF2_BANKS)}')
    bank_off = protocols.HSF2_BANKS[bank]
    table_offset = table_offset or protocols.HSF2_TABLE_OFFSET
    img = resolve_image(iso_path, member_hint='.iso')
    iso = IsoFS(img)
    elf_name = _boot_elf_name(iso)
    elf = iso.read_file('/' + elf_name)
    md5 = hashlib.md5(elf).hexdigest()
    if md5 != protocols.HSF2_ELF_MD5:
        first = elf.find(protocols.HSF2_TABLE_NEEDLE)
        hits = [] if first < 0 else [first] if elf.find(protocols.HSF2_TABLE_NEEDLE, first + 1) < 0 else [first, -1]
        if len(hits) == 1 and table_offset == protocols.HSF2_TABLE_OFFSET:
            table_offset = hits[0]
            print(f'[hsf2] boot ELF {elf_name} (md5 {md5}) is not the verified JP disc; dispatch table located by signature at 0x{table_offset:x}')
        elif not hits:
            raise SystemExit(f"{elf_name}: dispatch-table signature not found in this region's ELF -- pass --table-offset (see the docstring)")
    table = elf[table_offset:table_offset + protocols.HSF2_TABLE_ROWS * 8]
    from .build_common import iso_find_basename
    afs_path, afs_lba, afs_size = iso_find_basename(iso, protocols.HSF2_AFS_NAME)
    afs = AfsArchive(iso.f, iso.byte_offset(afs_lba))
    family = bank in PACK_NAMES
    if family:
        proto = ssf2_family.PROTOCOL
        ssf2_family.check_protocol(proto)
        title = TITLES[bank]
    else:
        proto = protocols.get_protocol('hsf2')
        title = f'HSF2 AE {bank} soundtrack (PS2 SLPM-65496)'
    w = PackWriter(proto, title=title)

    def row(idx: int) -> tuple[int, int, int, int]:
        t, = struct.unpack_from('<I', table, idx * 8)
        entry = table[idx * 8 + 4]
        vol = table[idx * 8 + 5]
        param, = struct.unpack_from('<H', table, idx * 8 + 6)
        return (t & 127, entry, vol, param)
    track_of_entry: dict[int, int] = {}
    track_sources: dict[int, int] = {}
    generated: dict[int, tuple[int, int]] = {}
    vol_of_entry: dict[int, int] = {}
    stand_ins: dict[int, int] = {}
    n_play = n_stop = 0
    for cmd in range(1, min(768, protocols.HSF2_TABLE_ROWS - bank_off)):
        typ, _, _, _ = row(cmd)
        if typ != protocols.HSF2_TYPE_BGM:
            continue
        if cmd in NATIVE_RESTORE_CMDS:
            continue
        _, entry, vol, _ = row(cmd + bank_off)
        generated[cmd] = (entry, vol)
        if family and cmd in ssf2_family.TURBO_STAND_INS and afs.name(entry).startswith('___blank'):
            src = ssf2_family.TURBO_STAND_INS[cmd]
            _, entry, vol, _ = row(src + bank_off)
            stand_ins[cmd] = src
        name = afs.name(entry)
        if name.startswith('___blank'):
            w.set_trigger(cmd, TriggerRow(verb=VERB_STOP, gain=TRIG_GAIN.get(bank, 127), suppress=1))
            n_stop += 1
            continue
        if family:
            track_gain, trig_gain = (min(vol, 127), TRIG_GAIN[bank])
            if vol_of_entry.setdefault(entry, vol) != vol:
                raise ValueError(f'AFS entry {entry} carries two volumes (0x{vol_of_entry[entry]:02x}, 0x{vol:02x})')
        else:
            track_gain, trig_gain = (127, min(vol, 127))
        if entry not in track_of_entry:
            raw = afs.read(entry)
            stream, meta, _ = adx_entry_to_track(raw, name=name, source=f'HSF2.AFS#{entry}', gain=track_gain)
            ti = w.add_track(stream, meta)
            track_of_entry[entry] = ti
            track_sources[ti] = entry
        w.set_trigger(cmd, TriggerRow(verb=VERB_PLAY, track=track_of_entry[entry], gain=trig_gain, suppress=1))
        n_play += 1
    manifest = _load_manifest_map(bank)
    mismatches = []
    unexpected = [c for c in generated if manifest and c not in manifest]
    if unexpected:
        raise AssertionError(f'ELF table yields commands absent from the verified manifest: ' + ' '.join((f'0x{c:03x}' for c in unexpected[:10])))
    for cmd, (entry, vol) in generated.items():
        if cmd in manifest and manifest[cmd][:2] != (entry, vol):
            mismatches.append((cmd, (entry, vol), manifest[cmd][:2]))
    missing_ingame = [c for c, (_, _, ig) in manifest.items() if c not in generated and c != 0 and (ig == 'yes') and (c not in NATIVE_RESTORE_CMDS)]
    missing_other = [c for c, (_, _, ig) in manifest.items() if c not in generated and c != 0 and (ig != 'yes' or c in NATIVE_RESTORE_CMDS)]
    if mismatches or missing_ingame:
        raise AssertionError(f'ELF table does not match hsf2_bgm_command_map.tsv: mismatches={mismatches[:5]} missing={missing_ingame[:5]}')
    if bank == 'arrange':
        for path in STANDALONE_ARRANGE_MAPS:
            standalone = _standalone_arrange_entries(path)
            disagree = {c: (generated.get(c, (None,))[0], e) for c, e in standalone.items() if generated.get(c, (None,))[0] != e}
            if disagree:
                raise AssertionError(f'disc table and {path.name} disagree (cmd: disc, standalone): ' + ' '.join((f'0x{c:02x}:{d}' for c, d in sorted(disagree.items())[:8])))
    if missing_other:
        print(f'[hsf2:{bank}] note: manifest rows not typed BGM by the ELF (native/sound-test-only slots), skipped: ' + ' '.join((f'0x{c:02x}' for c in missing_other)))
    out_path = Path(out) if out else PACKS_DIR / (f'{PACK_NAMES[bank]}.cpk' if family else f'hsf2_{bank}.cpk')
    w.write(out_path)
    from .format import PackReader
    rd = PackReader(out_path)
    try:
        for cmd in sorted(NATIVE_RESTORE_CMDS | (set(ssf2_family.FAIL_OPEN) if family else set())):
            trg = rd.triggers[cmd]
            if trg.verb != VERB_NONE or trg.suppress:
                raise ValueError(f'readback: command 0x{cmd:02x} must pass through to native QSound')
        if family:
            ssf2_family.check_protocol(rd.header.proto)
            for cmd, src in ssf2_family.TURBO_STAND_INS.items():
                got = rd.triggers[cmd]
                if got.verb != VERB_PLAY:
                    raise ValueError(f'readback: Turbo command 0x{cmd:02x} does not play')
                if cmd in stand_ins and got.track != rd.triggers[src].track:
                    raise ValueError(f"readback: 0x{cmd:02x} does not play 0x{src:02x}'s track")
    finally:
        rd.close()
    size = out_path.stat().st_size
    if stand_ins:
        print(f'[hsf2:{bank}] Turbo stand-ins: ' + ', '.join((f"0x{c:02x} plays 0x{s:02x}'s track" for c, s in sorted(stand_ins.items()))))
    print(f'[hsf2:{bank}] {out_path}  {size / 1000000.0:.1f} MB, {len(w.tracks)} tracks, {n_play} play + {n_stop} stop triggers (manifest cross-check OK: {len(manifest)} rows)')
    if crosscheck:
        res = crosscheck_pack(out_path, afs, track_sources)
        print(f"[hsf2:{bank}] byte-exact vs HSF2.AFS: {res['byte_exact_tracks']}/{len(track_sources)} tracks; decode-exact: {res['decode_exact_tracks']} tracks")
    iso.close()
    return out_path
