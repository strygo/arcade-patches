"""SPC (SNES) source handling for the `_spc` packs."""
from __future__ import annotations
import hashlib
import json
import os
import shutil
import struct
import subprocess
import sys
import tempfile
from pathlib import Path
import numpy as np
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'tools'))
import setup_spc_tools
RATE = 32000
TICK = np.dtype([('frame', '<i8'), ('kon', 'u1'), ('regs', 'u1', 128), ('ram', 'u1', 1024)])
assert TICK.itemsize == 1161

def harness() -> Path:
    return setup_spc_tools.ensure()

def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def ram_sha256(spc: bytes) -> str:
    """SHA-256 of the 64 KB RAM image alone (audio-bearing; tags excluded)."""
    return sha256(spc[256:65792])

def render(spc: Path, frames: int, *, filter: bool=False, mute: int=0) -> np.ndarray:
    cmd = [str(harness()), 'render', str(spc), '--frames', str(frames), '--out', '-']
    if filter:
        cmd.append('--filter')
    if mute:
        cmd += ['--mute', str(mute)]
    out = subprocess.run(cmd, capture_output=True, check=True).stdout
    pcm = np.frombuffer(out, dtype='<i2').reshape(-1, 2)
    if len(pcm) != frames:
        raise RuntimeError(f'{spc.name}: harness returned {len(pcm)} frames, asked {frames}')
    return pcm

def ticks(spc: Path, frames: int, scratch: Path) -> tuple[np.ndarray, dict]:
    scratch.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(suffix='.ticks', dir=scratch)
    os.close(fd)
    try:
        res = subprocess.run([str(harness()), 'ticks', str(spc), '--frames', str(frames), '--out', tmp], capture_output=True, text=True, check=True)
        summary = json.loads(res.stdout)
        recs = np.fromfile(tmp, dtype=TICK)
    finally:
        os.unlink(tmp)
    if len(recs) != summary['ticks']:
        raise RuntimeError(f"{spc.name}: {len(recs)} tick records, summary says {summary['ticks']}")
    return (recs, summary)

def _text(b: bytes) -> str:
    return b.split(b'\x00', 1)[0].decode('latin-1').strip()

def read_tags(spc: bytes) -> dict:
    """ID666 fields, plus the xid6 chunk when present.  Lengths are the"""
    if spc[:27] != b'SNES-SPC700 Sound File Data':
        raise ValueError('not an SPC file')
    tags: dict = {}
    if spc[35] == 26:
        tags['title'] = _text(spc[46:78])
        tags['game'] = _text(spc[78:110])
        tags['dumper'] = _text(spc[110:126])
        tags['comment'] = _text(spc[126:158])
        secs, fade = (spc[169:172], spc[172:177])
        textual = all((c in b'0123456789\x00' for c in secs + fade)) and any(secs + fade)
        if textual:
            tags['seconds'] = int(_text(secs) or 0)
            tags['fade_ms'] = int(_text(fade) or 0)
            tags['artist'] = _text(spc[177:209])
        else:
            tags['seconds'] = int.from_bytes(spc[169:172], 'little')
            tags['fade_ms'] = int.from_bytes(spc[172:176], 'little')
            tags['artist'] = _text(spc[176:208])
    if len(spc) >= 66056 and spc[66048:66052] == b'xid6':
        size = int.from_bytes(spc[66052:66056], 'little')
        pos, end, x = (66056, min(len(spc), 66056 + size), {})
        while pos + 4 <= end:
            ident, typ, val = (spc[pos], spc[pos + 1], int.from_bytes(spc[pos + 2:pos + 4], 'little'))
            pos += 4
            if typ == 0:
                data = val
            else:
                data = spc[pos:pos + val]
                pos += val + 3 & ~3
                if typ == 1:
                    data = _text(data)
                elif typ == 4:
                    data = int.from_bytes(data, 'little')
            names = {1: 'song', 2: 'game', 3: 'artist', 4: 'dumper', 7: 'comment', 19: 'publisher', 20: 'copyright', 48: 'intro_ticks', 49: 'loop_ticks', 50: 'end_ticks', 51: 'fade_ticks', 52: 'muted_voices', 53: 'loop_times'}
            if ident in names:
                x[names[ident]] = data
        tags['xid6'] = x
    return tags

def extractor() -> list[str]:
    """A command prefix that can unpack SOLID RAR 3, or an error naming one."""
    for exe in ('unar',):
        if shutil.which(exe):
            return [exe, '-q', '-f', '-D', '-o']
    for exe in ('7z', '7zz', '7za'):
        if shutil.which(exe):
            return [exe, 'x', '-y', '-bso0', '-bsp0', '-o']
    raise RuntimeError("no RAR extractor: install unar, or 7-Zip from 7-zip.org (Homebrew's 7zz has no RAR codec)")

def extract(rsn: Path, dest: Path) -> dict[str, bytes]:
    """Every member of `rsn`, by name.  `dest` is scratch, emptied first."""
    if dest.exists():
        shutil.rmtree(dest)
    dest.mkdir(parents=True)
    cmd = extractor()
    if cmd[-1] == '-o' and cmd[0].startswith('7z'):
        cmd = cmd[:-1] + ['-o' + str(dest), str(rsn)]
    else:
        cmd = cmd + [str(dest), str(rsn)]
    res = subprocess.run(cmd, capture_output=True, text=True)
    if res.returncode:
        raise RuntimeError(f'{rsn.name}: extraction failed\n{res.stdout}{res.stderr}')
    members = {p.name: p.read_bytes() for p in sorted(dest.rglob('*')) if p.is_file()}
    if not members:
        raise RuntimeError(f'{rsn.name}: extractor produced no files')
    return members

def self_test() -> None:
    hdr = bytearray(66048)
    hdr[:33] = b'SNES-SPC700 Sound File Data v0.30'
    hdr[35] = 26
    hdr[46:46 + 6] = b'Boss 1'
    hdr[169:172] = b'061'
    hdr[172:177] = b'10000'
    t = read_tags(bytes(hdr))
    assert t['title'] == 'Boss 1' and t['seconds'] == 61 and (t['fade_ms'] == 10000), t
    hdr[210] = ord('2')
    hdr[169:177] = b'1024000\x00'
    t = read_tags(bytes(hdr))
    assert t['seconds'] == 102 and t['fade_ms'] == 4000, t
    assert TICK.itemsize == 1161
    print('spc_engine self-test: OK')
if __name__ == '__main__':
    self_test()
