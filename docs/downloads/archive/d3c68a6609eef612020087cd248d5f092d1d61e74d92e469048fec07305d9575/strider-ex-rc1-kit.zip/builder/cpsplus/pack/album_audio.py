"""Decode album tracks for the packs built from soundtrack releases."""
from __future__ import annotations
import hashlib
import struct
import subprocess
from pathlib import Path
import numpy as np
from . import adxcodec, resample
RATE = 48000
_CHAINS = {'.mp3': ('mp3', 'pcm_s16le', 2, ('-flags2', '+skip_manual')), '.flac': ('flac', 'pcm_s32le', 4, ())}

def sha256(path) -> str:
    with open(path, 'rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()

def _wav_pcm(buf: bytes) -> tuple[int, int, int, bytes]:
    """(channels, rate, bits, sample bytes) of ffmpeg's piped WAV output."""
    if buf[:4] != b'RIFF' or buf[8:12] != b'WAVE':
        raise RuntimeError('ffmpeg did not produce WAV')
    pos, fmt = (12, None)
    while pos + 8 <= len(buf):
        cid, size = (buf[pos:pos + 4], struct.unpack_from('<I', buf, pos + 4)[0])
        if cid == b'fmt ':
            _, ch, rate, _, _, bits = struct.unpack_from('<HHIIHH', buf, pos + 8)
            fmt = (ch, rate, bits)
        elif cid == b'data':
            if fmt is None:
                break
            return (*fmt, buf[pos + 8:])
        pos += 8 + size + (size & 1)
    raise RuntimeError('ffmpeg WAV output has no fmt/data chunk')

def decode_native(path) -> tuple[np.ndarray, int, int]:
    """(samples, rate, extra_bits): the file's first audio stream at its own"""
    path = Path(path)
    chain = _CHAINS.get(path.suffix.lower())
    if chain is None:
        raise ValueError(f"{path.name}: no deterministic decode for {path.suffix or 'this file'} (MP3 and FLAC only)")
    decoder, codec, width, decoder_options = chain
    proc = subprocess.run([adxcodec.FFMPEG, '-nostdin', '-hide_banner', '-loglevel', 'error', '-c:a', decoder, *decoder_options, '-i', str(path), '-map', '0:a:0', '-map_metadata', '-1', '-c:a', codec, '-f', 'wav', '-'], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if proc.returncode != 0:
        raise RuntimeError(f"ffmpeg could not decode {path.name}: {proc.stderr.decode(errors='replace')[:500]}")
    ch, rate, bits, data = _wav_pcm(proc.stdout)
    if bits != 8 * width or ch not in (1, 2):
        raise RuntimeError(f'{path.name}: unexpected {ch} ch / {bits}-bit output')
    data = data[:len(data) // (width * ch) * width * ch]
    pcm = np.frombuffer(data, f'<i{width}').reshape(-1, ch).astype(np.int32)
    if width == 4:
        if np.any(pcm & 255):
            raise ValueError(f'{path.name}: deeper than 24-bit')
        pcm >>= 8
    if ch == 1:
        pcm = np.repeat(pcm, 2, axis=1)
    return (pcm, rate, 8 if width == 4 else 0)

def decode(path) -> np.ndarray:
    """The file as 48 kHz stereo s16 PCM, shape (frames, 2)."""
    pcm, rate, extra_bits = decode_native(path)
    return resample.resample(pcm, rate, RATE, extra_bits)

def locate(source_root: Path, rel: str) -> Path:
    """The album file `rel` under `source_root`."""
    direct = Path(source_root) / rel
    if direct.exists():
        return direct
    name = Path(rel).name
    hits = [p for p in Path(source_root).rglob(name) if p.is_file()]
    if len(hits) == 1:
        return hits[0]
    if not hits:
        raise FileNotFoundError(f'{name} not found under {source_root}')
    raise FileExistsError(f'{name} appears {len(hits)} times under {source_root}')
