"""`build_pack.py cps1-sf2` — SF2 World Warrior (CPS1) ARRANGE pack."""
from __future__ import annotations
import argparse
import sys
from pathlib import Path
from . import protocols
from .afs import AfsArchive
from .build_common import adx_entry_to_track, crosscheck_pack, MANIFESTS, PACKS_DIR
from .format import PackWriter, TriggerRow, VERB_PLAY
from .isofs import IsoFS
from .sources import resolve_image
TRIG_GAIN = 99
HSF2_AFS_NAME = protocols.HSF2_AFS_NAME
HSF2_MAP = MANIFESTS / 'hsf2_bgm_command_map.tsv'
DEFAULT_MAP = MANIFESTS / 'sf2_arrange_trigger_map.tsv'
_ROW_ORDER: list[tuple[int, str, str, str]] = [(1, 'Ryu', 'high', 'stage'), (2, 'E.Honda', 'high', 'stage'), (3, 'Blanka', 'high', 'stage'), (4, 'Ken', 'high', 'stage'), (5, 'Guile', 'high', 'stage'), (6, 'Chun-Li', 'high', 'stage'), (7, 'Zangief', 'high', 'stage'), (8, 'Dhalsim', 'high', 'stage'), (9, 'Boss:Balrog(boxer)', 'high', 'boss'), (10, 'Boss:Vega(claw)', 'high', 'boss'), (11, 'Boss:Sagat', 'high', 'boss'), (12, 'Boss:M.Bison(dictator)', 'high', 'boss'), (13, 'Bonus', 'high', 'bonus'), (22, 'Title/Opening', 'high', 'attract'), (14, 'Player-Select', 'high', 'attract'), (15, 'VS screen', 'high', 'attract'), (20, 'Ranking', 'high', 'attract'), (17, 'Continue', 'high', 'continue'), (24, 'Ending:Ryu', 'high', 'ending'), (25, 'Ending:E.Honda', 'high', 'ending'), (26, 'Ending:Blanka', 'high', 'ending'), (27, 'Ending:Guile', 'high', 'ending'), (28, 'Ending:Ken', 'high', 'ending'), (29, 'Ending:Chun-Li', 'high', 'ending'), (30, 'Ending:Zangief', 'high', 'ending'), (31, 'Ending:Dhalsim', 'high', 'ending'), (52, 'Ending:Ken(2)', 'high', 'ending'), (53, 'Ending:Chun-Li(2)', 'high', 'ending'), (121, 'HurryUp:Ryu', 'high', 'hurry'), (122, 'HurryUp:E.Honda', 'high', 'hurry'), (123, 'HurryUp:Blanka', 'high', 'hurry'), (124, 'HurryUp:Guile', 'high', 'hurry'), (125, 'HurryUp:Ken', 'high', 'hurry'), (126, 'HurryUp:Chun-Li', 'high', 'hurry'), (127, 'HurryUp:Zangief', 'high', 'hurry'), (128, 'HurryUp:Dhalsim', 'high', 'hurry'), (129, 'HurryUp:M.Bison', 'high', 'hurry'), (130, 'HurryUp:Balrog', 'high', 'hurry'), (131, 'HurryUp:Sagat', 'high', 'hurry'), (132, 'HurryUp:Vega', 'high', 'hurry'), (141, 'Credits Roll', 'high', 'credits')]
_SF2_CMD_TO_HSF2 = {**protocols.SF2_STAGE_MUSIC, **protocols.SF2_ATTRACT_MUSIC, **protocols.SF2_ENDING_MUSIC, **protocols.SF2_HURRY_MUSIC, **protocols.SF2_CONTINUE_MUSIC, **protocols.SF2_CREDITS_MUSIC}

def _arrange_bank() -> dict[int, tuple[int, str, int]]:
    """HSF2 arrange cmd -> (afs_entry, arrange track name, authored volume)."""
    out: dict[int, tuple[int, str, int]] = {}
    rows = HSF2_MAP.read_text(encoding='utf-8').splitlines()
    hdr = rows[0].split('\t')
    for line in rows[1:]:
        d = dict(zip(hdr, line.split('\t')))
        if d.get('set') == 'ARRANGE':
            out[int(d['cmd'], 0)] = (int(d['afs_entry']), d.get('name', ''), int(d['vol'], 16))
    return out

def canonical_rows() -> list[dict]:
    """Derive the trigger map from protocols.py + the HSF2 arrange bank."""
    bank = _arrange_bank()
    rows = []
    for sf2_cmd, char, conf, group in _ROW_ORDER:
        hsf2_cmd = _SF2_CMD_TO_HSF2[sf2_cmd]
        if hsf2_cmd not in bank:
            raise KeyError(f'HSF2 arrange cmd 0x{hsf2_cmd:02x} (sf2 0x{sf2_cmd:02x}) not in {HSF2_MAP.name}')
        entry, name, vol = bank[hsf2_cmd]
        note = {'stage': f'sf2 {char} stage -> HSF2 {name}', 'boss': f'sf2 boss stage -> HSF2 {name} (sound-test NCC + nameplate verified)', 'bonus': f'sf2 bonus stage -> HSF2 {name}', 'attract': f'sf2 {char.lower()} -> HSF2 {name}', 'ending': f"sf2 ending -> HSF2 {name}; align_ncc vs the album's CPS1/FM bank, ear-confirmed where it floored", 'hurry': f'sf2 time-low variant -> HSF2 {name}; bijection over the twelve (2) tracks, found only after skipping the 0x50 loop', 'continue': f'sf2 continue -> HSF2 {name}', 'credits': f'CE credits -> HSF2 {name}; found by playthrough (the driver is stateful -- cold-boot 0x8d plays other music)'}[group]
        rows.append(dict(sf2_cmd=sf2_cmd, hsf2_cmd=hsf2_cmd, arrange_entry=entry, character=char, confidence=conf, vol=vol, arrange_name=name, note=note))
    return rows
_MAP_HEADER = 'cmd\tarrange_entry\thsf2_cmd\tcharacter\tconfidence\tnote'

def emit_map(path: Path) -> Path:
    """Write the tracked trigger map from the protocols.py-derived rows."""
    lines = ['# SF2 World Warrior (CPS1 `sf2`) ARRANGE trigger map: sf2 byte-latch', '#   stage command -> HSF2 AE ARRANGE-bank ADX entry (the console-', '#   arranged SF2 soundtrack).  RE-KEY of the HSF2 arrange ADX', '#   (manifests/hsf2_bgm_command_map.tsv, set=ARRANGE), byte-exact +', '#   Capcom header loops — NOT a new arrangement.', '#', '# JOIN: sf2_cmd --(protocols.SF2_STAGE_MUSIC / SF2_ATTRACT_MUSIC)-->', '#   HSF2 arrange cmd --(hsf2 map, set=ARRANGE)--> arrange_entry.  The', '#   sf2 stage table is keyed by CHARACTER, HSF2 by its own command', '#   numbers, so the re-key is NOT identity (Ryu 0x01 vs HSF2 0x02,', '#   Ken 0x04 vs 0x01, ...).  Ground truth:', '#   internal research notes + manifests/protocol/sf2.json.', '#', '# CONFIDENCE: every row is high.  Base-8 stages confirmed;', '#   title/select/ranking snapshot-verified; bosses (0x09-0x0c) were', '#   SCRAMBLED by a US/JP naming assumption and re-keyed,', '#   then ear-verified.  Endings (0x18-0x1f, 0x34, 0x35) and the twelve', '#   time-low variants (0x79-0x84) were joined with tools/align_ncc.py', "#   against the album's CPS1/FM bank -- same soundtrack the board plays,", '#   so a true pair correlates where an ARRANGED cover does not.', '#', '# The matcher certifies its POSITIVES only.  Both Chun-Li endings floor', '#   against the very tracks they match (0x1d at 0.089, 0x35 at 0.123)', '#   and were confirmed by ear; every other ending lands 0.38-0.52.', "#   Never read a floor here as 'not in the album'.", '#', '# NOT mapped, on purpose: 0x38 is garbage data; 0x50 and 0xde are', '#   crowd-cheer LOOPS that ignore the 0xf7 stop (which is why 164', '#   commands were unmeasurable until sweeps started skipping them);', "#   0x8d-0xab are a shadow bank replaying c-0x8c; 0x8c is SF2CE's", '#   four-boss ending, which the arrange album has no counterpart for.', '#', '# Emitted by pack/build_sf2_arrange.py from protocols.py + the HSF2 map;', '#   the builder cross-checks this file against that derivation, so it', '#   is regenerated byte-identical.  Cols: cmd, arrange_entry, hsf2_cmd,', '#   character, confidence, note.', '#', _MAP_HEADER]
    for r in canonical_rows():
        lines.append('\t'.join((f"0x{r['sf2_cmd']:02x}", str(r['arrange_entry']), f"0x{r['hsf2_cmd']:02x}", r['character'], r['confidence'], r['note'])))
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text('\n'.join(lines) + '\n', encoding='utf-8', newline='\n')
    return path

def read_map(path: Path) -> list[dict]:
    """Parse the tracked trigger map (cmd, arrange_entry, hsf2_cmd, ...)."""
    rows = []
    for line in path.read_text(encoding='utf-8').splitlines():
        if not line.strip() or line.lstrip().startswith('#'):
            continue
        f = line.split('\t')
        if f[0].strip().lower() == 'cmd':
            continue
        rows.append(dict(sf2_cmd=int(f[0], 0), arrange_entry=int(f[1]), hsf2_cmd=int(f[2], 0) if len(f) > 2 and f[2] else None, character=f[3] if len(f) > 3 else '', confidence=f[4] if len(f) > 4 else '', note=f[5] if len(f) > 5 else ''))
    return rows

def build(iso_path: str, map_path: str | None=None, out: str | None=None, crosscheck: bool=True) -> Path:
    map_file = Path(map_path) if map_path else DEFAULT_MAP
    canon = canonical_rows()
    if not map_file.exists():
        emit_map(map_file)
        print(f'[cps1-sf2] emitted trigger map -> {map_file}')
    trig = read_map(map_file)
    canon_key = [(r['sf2_cmd'], r['hsf2_cmd'], r['arrange_entry']) for r in canon]
    read_key = [(r['sf2_cmd'], r['hsf2_cmd'], r['arrange_entry']) for r in trig]
    if read_key != canon_key:
        raise SystemExit(f'{map_file} does not match the protocols.py-derived mapping (regenerate with --emit-map).\n  tracked: {read_key}\n  derived: {canon_key}')
    vols = {r['arrange_entry']: r['vol'] for r in canon}
    names = {r['arrange_entry']: r['arrange_name'] for r in canon}
    img = resolve_image(iso_path, member_hint='.iso')
    iso = IsoFS(img)
    from .build_common import iso_find_basename
    _, lba, _ = iso_find_basename(iso, HSF2_AFS_NAME)
    afs = AfsArchive(iso.f, iso.byte_offset(lba))
    proto = protocols.get_protocol('sf2')
    w = PackWriter(proto, trigger_rows=protocols.SF2_TRIGGER_ROWS, title='SF2 World Warrior arranged soundtrack (HSF2 AE arrange bank, byte-exact + Capcom header loops)')
    track_of_entry: dict[int, int] = {}
    track_sources: dict[int, int] = {}
    built = []
    for r in trig:
        entry = r['arrange_entry']
        if entry not in track_of_entry:
            raw = afs.read(entry)
            label = names.get(entry, '').replace(' ', '_').lower() or 'arr'
            gain = min(vols.get(entry, 127), 127)
            stream, meta, _ = adx_entry_to_track(raw, name=f'{label}_e{entry}', source=f'HSF2.AFS#{entry}', gain=gain)
            ti = w.add_track(stream, meta)
            track_of_entry[entry] = ti
            track_sources[ti] = entry
        ti = track_of_entry[entry]
        w.set_trigger(r['sf2_cmd'], TriggerRow(verb=VERB_PLAY, track=ti, gain=TRIG_GAIN, suppress=1))
        built.append(r)
    out_path = Path(out) if out else PACKS_DIR / 'sf2_arrange.cpk'
    w.write(out_path)
    size = out_path.stat().st_size
    print(f'[cps1-sf2] {out_path}  {size / 1000000.0:.1f} MB, {len(w.tracks)} tracks, {len(built)} play triggers (sf2 byte-latch stage commands -> HSF2 arrange entries)')
    print(f'[cps1-sf2] sf2_cmd  hsf2_cmd  arrange_entry  character       conf')
    for r in built:
        print(f"    0x{r['sf2_cmd']:02x}     0x{r['hsf2_cmd']:02x}      e{r['arrange_entry']:<3}          {r['character']:<15} {r['confidence']}")
    if crosscheck:
        res = crosscheck_pack(out_path, afs, track_sources)
        print(f"[cps1-sf2] byte-exact vs HSF2.AFS: {res['byte_exact_tracks']}/{len(track_sources)} tracks; decode-exact: {res['decode_exact_tracks']} tracks")
    iso.close()
    return out_path
if __name__ == '__main__':
    REPO = Path(__file__).resolve().parents[2]
    sys.path.insert(0, str(REPO / 'cpsplus'))
    ap = argparse.ArgumentParser()
    ap.add_argument('--iso', required=True, help='')
    ap.add_argument('--map')
    ap.add_argument('--out')
    ap.add_argument('--emit-map', action='store_true', help='(re)write the tracked trigger map and exit')
    ap.add_argument('--no-crosscheck', action='store_true')
    a = ap.parse_args()
    if a.emit_map:
        emit_map(Path(a.map) if a.map else DEFAULT_MAP)
        print(f'emitted {a.map or DEFAULT_MAP}')
        sys.exit(0)
    build(a.iso, map_path=a.map, out=a.out, crosscheck=not a.no_crosscheck)
