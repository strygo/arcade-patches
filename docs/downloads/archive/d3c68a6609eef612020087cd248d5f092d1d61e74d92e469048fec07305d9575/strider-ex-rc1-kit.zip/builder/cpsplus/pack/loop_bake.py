"""Sample-exact loop joins for masters that repeat, baked into the stored PCM."""
from __future__ import annotations
import numpy as np
GRID = 32
BLEND_N = 1024

def _ncc(a: np.ndarray, b: np.ndarray) -> float:
    a = a - a.mean()
    b = b - b.mean()
    d = float(np.sqrt((a * a).sum() * (b * b).sum()))
    return float((a * b).sum() / d) if d > 0 else 0.0

def mono(pcm: np.ndarray) -> np.ndarray:
    return pcm.astype(np.float64).mean(1) / 32768

def exact_lag(x: np.ndarray, t: int, lag: int, rate: int, span: int=400) -> tuple[int, float]:
    """Refine a lag (samples) at full rate: 3 s window at t, +/- span samples."""
    w = 3 * rate
    seg = x[t:t + w]
    best = (-2.0, lag)
    for L in range(lag - span, lag + span + 1):
        if t + L + w > len(x):
            break
        v = _ncc(seg, x[t + L:t + L + w])
        if v > best[0]:
            best = (v, L)
    return (best[1], best[0])

def best_wrap(x: np.ndarray, ls_lo: int, ls_hi: int, lag: int, limit: int, n: int=BLEND_N) -> dict:
    """Grid-aligned (ls, le) with le - ls = lag rounded to the grid, minimising"""
    body = (lag + GRID // 2) // GRID * GRID
    best = None
    for ls in range(max(n, ls_lo) // GRID * GRID, ls_hi, GRID):
        le = ls + body
        if le > limit:
            break
        a, b = (x[le - n:le], x[ls - n:ls])
        cost = float(((a - b) ** 2).sum() / max((b * b).sum(), 1e-12))
        if best is None or cost < best['cost']:
            best = {'ls': ls, 'le': le, 'cost': cost}
    if best is None:
        raise ValueError('no grid position fits before the limit')
    best.update(lag=lag, offset=best['le'] - best['ls'] - lag, blend_n=n)
    return best

def bake(pcm: np.ndarray, ls: int, le: int, n: int=BLEND_N) -> np.ndarray:
    """Copy of pcm[:le] whose last n samples blend into the audio before ls."""
    out = pcm[:le].astype(np.int32).copy()
    w = (np.arange(n) + 0.5) / n
    mix = (1 - w)[:, None] * pcm[le - n:le] + w[:, None] * pcm[ls - n:ls]
    out[le - n:le] = np.rint(mix)
    return np.clip(out, -32768, 32767).astype(np.int16)

def phrase_search(x: np.ndarray, rate: int, limit: int, min_body_s: float, window_s: float=3.0, span_s: float=60.0, dec: int=8) -> dict | None:
    """For masters without a whole second pass: find a loop end le (before"""
    xd, r = (x[::dec], rate // dec)
    best = None
    lo = max(min_body_s + 5, limit / rate - span_s)
    for le_s in np.arange(lo, limit / rate - window_s, 0.25):
        p = xd[int(le_s * r):int((le_s + window_s) * r)]
        hay = xd[:int((le_s - min_body_s) * r) + len(p)]
        if len(hay) <= len(p):
            continue
        nfft = 1 << int(np.ceil(np.log2(len(hay) + len(p))))
        c = np.fft.irfft(np.fft.rfft(hay, nfft) * np.conj(np.fft.rfft(p, nfft)), nfft)
        c = c[:len(hay) - len(p) + 1]
        cs = np.cumsum(np.concatenate(([0.0], hay ** 2)))
        e = cs[len(p):len(p) + len(c)] - cs[:len(c)]
        v = c / (np.sqrt((p * p).sum()) * np.sqrt(np.maximum(e, 1e-12)))
        j = int(np.argmax(v))
        if best is None or v[j] > best['score']:
            best = {'score': float(v[j]), 'le': int(le_s * rate), 'ls': j * dec}
    return best
