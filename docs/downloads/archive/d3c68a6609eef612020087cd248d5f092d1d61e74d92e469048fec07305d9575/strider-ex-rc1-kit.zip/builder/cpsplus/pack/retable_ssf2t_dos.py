"""Rebuild the four accepted DOS packs after a trigger-only map correction."""
from __future__ import annotations
import argparse
import hashlib
from dataclasses import replace
from pathlib import Path
from .build_ssf2t_dos import CD_VS_CMD, DEVICES, load_map
from .format import VERB_NONE, VERB_PLAY, VERB_STOP, PackReader, PackWriter, TriggerRow
CP = Path(__file__).resolve().parents[1]
ACCEPTED = CP / 'packs'
RETIRED = ACCEPTED / 'retired' / 'ssf2_dos_1_4'
SCRATCH = CP / 'work' / 'packs'
HISTORICAL_MAP = CP / 'manifests' / 'ssf2t_dos_1_5_map.tsv'
SOURCE_SHA256 = {'cd': '428d4a73f5bd7ef4da569051de0800ba82c75ce7b3104ce4d3d58041e17b9543', 'fm': 'a0b1bea97581a5f82c42fa6d20abd9db3aa40ba1bec0d670e2ada67b705aa373', 'sc55': '3382712ead182629f54451c2b4892590557feed2b1e5448067f38e7e7b40c767', 'mt32': '058ff2ce5ecb0b8b43e750ca86fafe0d80500f9acb777327701c5941885fd0d6'}
BOSS_COMMANDS = frozenset({9, 10, 12, 25, 26, 43, 44, 46})

def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b''):
            h.update(chunk)
    return h.hexdigest()

def retable(device: str, out_dir: Path=SCRATCH) -> Path:
    spec = DEVICES[device]
    src = ACCEPTED / spec.pack_name
    if not src.is_file() or digest(src) != SOURCE_SHA256[device]:
        src = RETIRED / spec.pack_name
    out = out_dir / spec.pack_name
    got_hash = digest(src)
    if got_hash != SOURCE_SHA256[device]:
        raise ValueError(f'{src}: expected 1.4 source {SOURCE_SHA256[device]}, got {got_hash}')
    source = PackReader(src)
    try:
        if source.crc_check() != (True, True) or not source.sidecar:
            raise ValueError(f'{src}: invalid pack or missing track catalog')
        h = source.header
        writer = PackWriter(h.proto, title=h.title, trigger_rows=h.trigger_rows, default_rate=h.default_rate, xfade_samples=h.xfade_samples)
        track_of = {}
        for i, meta in enumerate(source.tracks):
            song = meta.name.split(' (', 1)[0]
            if not song or song in track_of:
                raise ValueError(f'{src}: unnamed or duplicate song {song!r}')
            track_of[song] = i
            writer.add_track(source.read_track(i), replace(meta))
        writer.triggers = [replace(row) for row in source.triggers]
        rows = load_map(HISTORICAL_MAP)
        for row in rows:
            if row.song in track_of:
                writer.set_trigger(row.command, TriggerRow(verb=VERB_PLAY, track=track_of[row.song], gain=spec.trigger_gain, suppress=1))
            elif device == 'cd' and row.command == CD_VS_CMD:
                writer.set_trigger(row.command, TriggerRow(verb=VERB_STOP, suppress=0))
            elif source.triggers[row.command].verb != VERB_NONE:
                raise ValueError(f'{src}: lost mapped song {row.song}')
        changed = {cmd for cmd, (before, after) in enumerate(zip(source.triggers, writer.triggers)) if before != after}
        expected = BOSS_COMMANDS | ({CD_VS_CMD} if device == 'cd' else set())
        if changed != expected:
            raise ValueError(f'{src}: changed rows {sorted(changed)}, expected {sorted(expected)}')
        writer.write(out)
        rebuilt = PackReader(out)
        try:
            if rebuilt.crc_check() != (True, True):
                raise ValueError(f'{out}: CRC check failed')
            if rebuilt.header.track_count != h.track_count or rebuilt.header.data_size != h.data_size or rebuilt._raw_idx != source._raw_idx:
                raise ValueError(f'{out}: audio index changed')
            if rebuilt.header.proto != h.proto or rebuilt.header.title != h.title or rebuilt.header.default_rate != h.default_rate or (rebuilt.header.xfade_samples != h.xfade_samples) or (rebuilt.tracks != source.tracks):
                raise ValueError(f'{out}: protocol or track metadata changed')
            for i in range(h.track_count):
                if rebuilt.read_track(i) != source.read_track(i):
                    raise ValueError(f'{out}: audio track {i} changed')
        finally:
            rebuilt.close()
    finally:
        source.close()
    print(f'{device}: {out}, trigger rows {[hex(c) for c in sorted(changed)]}, SHA-256 {digest(out)}')
    return out

def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    group = ap.add_mutually_exclusive_group(required=True)
    group.add_argument('--device', choices=sorted(DEVICES))
    group.add_argument('--all', action='store_true')
    ap.add_argument('--out-dir', type=Path, default=SCRATCH, help='candidate destination (default: work/packs)')
    args = ap.parse_args(argv)
    for device in sorted(DEVICES) if args.all else (args.device,):
        retable(device, args.out_dir)
    return 0
if __name__ == '__main__':
    raise SystemExit(main())
