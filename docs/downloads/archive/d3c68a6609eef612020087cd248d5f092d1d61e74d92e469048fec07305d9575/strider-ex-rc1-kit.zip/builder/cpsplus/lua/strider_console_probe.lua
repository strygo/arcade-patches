-- Console-safe capture adapter, used by the standard surface-trace runner.
local m=manager.machine;local cpu=m.devices[':maincpu']; local sp=cpu.spaces['program']
local screen=m.screens[':screen'];local prefix=assert(os.getenv('VH2_TRACE_PREFIX'))
local meta=assert(io.open(prefix..'_trace.tsv','w'));meta:write('kind\tframe\tlabel\tpc\tmode\ttimer\tpath\ttime\n')
local caps={};local last=0;local f=0
for fs,label in string.gmatch(os.getenv('VH2_TRACE_CAPTURES') or '', '(%d+)=([^;]+)') do local n=tonumber(fs);caps[n]=label;last=math.max(last,n) end
local fields={}
for _,port in pairs(m.ioport.ports) do for name,field in pairs(port.fields) do
 local tok=m.ioport:input_type_to_token(field.type,field.player);fields[tok]=field
 print('INPUT '..tok..' '..name)
end end
print('PSX register PC='..tostring(cpu.state['pc']))
local function pc() local s=cpu.state['PC'] or cpu.state['pc'] or cpu.state['GENPC'];return s and s.value or 0 end
local function row(kind,label,path) meta:write(string.format('%s\t%d\t%s\t%08x\t0000\t0000\t%s\t%.9f\n',kind,f,label,pc(),path or '',m.time:as_double()));meta:flush() end
local schedule={};local active={}
local sound_state=os.getenv('STRIDER_PSX_SOUND_STATE')=='1';local last_sound=''
-- PCE's physical program space includes device registers and unmapped areas.
-- Avoid the PSX-style whole-space dump and its diagnostic flood; source-scene
-- captures use screenshots/audio until a useful PCE RAM region is selected.
local ram_dump=os.getenv('STRIDER_CONSOLE_RAM_DUMP')~='0'
local pce_state=os.getenv('STRIDER_PCE_STATE')=='1'
local taps={}
local function pce_regs()
 local values={}
 for _,key in ipairs({'A','X','Y','S','MPR0','MPR1','MPR2','MPR3','MPR4','MPR5','MPR6','MPR7'}) do
  values[#values+1]=string.format('%s=%02x',key,cpu.state[key].value)
 end
 for _,a in ipairs({0x00,0x01,0x1d,0xc1,0xc4,0xc7,0xf8,0xf9,0xfa,0xfb,0xfc,0xfd,0xfe,0xff,0xc85,0xd0b,0xca7}) do
  values[#values+1]=string.format('ram%03x=%02x',a,sp:read_u8(0x1f0000+a))
 end
 local s=cpu.state['S'].value
 for i=1,12 do values[#values+1]=string.format('stack%d=%02x',i,sp:read_u8(0x1f0100+((s+i)&0xff))) end
 return table.concat(values,',')
end
if pce_state then
 for _,a in ipairs({0x1f001d,0x1f00fc,0x1f00ff,0x1f00c1,0x1f00c7,0x1f0c85,0x1f0d0b,0x1f0ca7}) do
  taps[#taps+1]=sp:install_write_tap(a,a,'strider_pce_'..a,function(addr,data,mask)
   local p=pc()
   if f>320 and (addr>=0x1f0c00 and data~=sp:read_u8(addr)
      or addr==0x1f001d and p==0x813d
      or addr==0x1f00c1 or addr==0x1f00c7
      or (addr==0x1f00fc or addr==0x1f00ff) and (p==0x8151 or p==0x46bd or p==0x8f61 or p==0x8f78)) then
    row('pce_write',string.format('%x=%02x,',addr,data)..pce_regs())
   end
  end)
 end
end
local pce_start_stage=tonumber(os.getenv('STRIDER_PCE_START_STAGE') or '')
if pce_start_stage then
 local applied=false
 taps[#taps+1]=sp:install_write_tap(0x1f00c1,0x1f00c1,'strider_pce_initial_stage',function(addr,data,mask)
  if not applied and pc()==0x30d0 and data==0 then
   assert(sp:read_u8(0x1f10ce)==0x64 and sp:read_u8(0x1f10cf)==0xc1,'stage-init opcode mismatch')
   -- Enter the existing asset preloader even though this is a new game.
   -- Otherwise the title's stage-zero asset cache remains selected.
   assert(sp:read_u8(0x1f11c0)==0xd0 and sp:read_u8(0x1f11c1)==8,'preload branch mismatch')
   sp:write_u8(0x1f11c1,0)
   applied=true;row('stage_override','new_game_stage='..pce_start_stage..',preload_branch=31c1:08>00')
   return pce_start_stage
  end
 end)
end
local first_checkpoint=tonumber(os.getenv('STRIDER_PCE_FIRST_CHECKPOINT') or '')
if first_checkpoint then
 local used=false
 taps[#taps+1]=sp:install_write_tap(0x1f0c85,0x1f0c85,'strider_pce_first_checkpoint',function(addr,data,mask)
  if not used and pc()==0x4438 and data==1 and cpu.state['MPR2'].value==0x68 then
   assert(sp:read_u8(0xd0433)==0xa9 and sp:read_u8(0xd0434)==1,'checkpoint initialization mismatch')
   used=true;row('checkpoint_override','initial_checkpoint='..first_checkpoint)
   return first_checkpoint
  end
 end)
end
local phase=({stage_clear=8,continue=10,ending=13})[os.getenv('STRIDER_PCE_PHASE') or '']
if phase then
 local used=false
 taps[#taps+1]=sp:install_write_tap(0x1f00c7,0x1f00c7,'strider_pce_outcome_phase',function(addr,data,mask)
  if not used and pc()==0x30e6 and data==6 then
   assert(sp:read_u8(0x1f10e4)==0x85 and sp:read_u8(0x1f10e5)==0xc7,'phase initialization mismatch')
   used=true;if phase==8 then sp:write_u8(0x1f00c4,1) end
   row('phase_override','phase='..phase)
   return phase
  end
 end)
end
local checkpoint_census=os.getenv('STRIDER_PCE_CHECKPOINT_CENSUS')=='1'
local checkpoint_seen={};local checkpoint_ready=0;local checkpoint_last=-1
local checkpoint_pending=false
if checkpoint_census then assert(pce_state,'checkpoint census needs --pce-state') end
local pokes={}
for fs,addr,val in string.gmatch(os.getenv('STRIDER_PSX_POKES') or '', '(%d+):([^=;]+)=([^;]+)') do pokes[tonumber(fs)]={tonumber(addr),tonumber(val)} end
for a,b,ts in string.gmatch(os.getenv('VH2_TRACE_SCHEDULE') or '', '(%d+)%-(%d+):([^;]+)') do
 local tokens={};for t in ts:gmatch('[^+]+') do assert(fields[t],t);tokens[#tokens+1]=t end
 schedule[#schedule+1]={tonumber(a),tonumber(b),tokens}
end
emu.register_frame_done(function()
 f=f+1
 for _,tap in ipairs(taps) do assert(tap) end
 if checkpoint_census and cpu.state['MPR2'].value==0x68
    and sp:read_u8(0x1f00c7)==8 and sp:read_u8(0x1f0c80)==0x38 and sp:read_u8(0x1f0c81)==0x45 then
  local checkpoint=sp:read_u8(0x1f0c85)
  if checkpoint~=checkpoint_last then
   checkpoint_last=checkpoint;checkpoint_ready=f+90
  end
  if f>=checkpoint_ready then
   checkpoint_ready=math.huge
   if checkpoint_seen[checkpoint] then last=f
   else
    checkpoint_seen[checkpoint]=true
    caps[f]=string.format('checkpoint_%02d',checkpoint)
    local final_checkpoint=({[0]=8,[1]=5,[2]=9,[3]=9,[4]=5,[6]=14})[sp:read_u8(0x1f00c1)]
    assert(final_checkpoint,'unknown checkpoint table')
    if checkpoint>=final_checkpoint then last=f else checkpoint_pending=true end
    row('checkpoint_step','checkpoint='..checkpoint)
   end
  end
 end
 if checkpoint_pending and not caps[f] and pc()>=0x43df and pc()<=0x43e5
    and cpu.state['S'].value==0xfd and sp:read_u8(0x1f01fe)==0xaa and sp:read_u8(0x1f01ff)==0x43 then
  assert(cpu.state['MPR2'].value==0x68 and sp:read_u8(0xd053f)==0xae
    and sp:read_u8(0xd0540)==0x0c and sp:read_u8(0xd0541)==0x2d,'checkpoint entry mismatch')
  row('checkpoint_invoke','idle_return=43aa,target=453f')
  cpu.state['PC'].value=0x453f;checkpoint_pending=false
 end
 if sound_state and f>=1400 then
  local s=string.format('remix=%d,bank=%d,seq=%d,xa=%d,xa_active=%d',sp:read_u8(0x4d6e4),sp:read_u8(0x4d753),sp:read_u8(0x4d9d0),sp:read_u8(0x4d999),sp:read_u8(0x4d9b0))
  if s~=last_sound then row('sound_state',s);last_sound=s end
 end
 if pokes[f] then local p=pokes[f];sp:write_u32(p[1],p[2]);row('poke',string.format('%x=%x',p[1],p[2])) end
 local wanted={};for _,r in ipairs(schedule) do if f>=r[1] and f<=r[2] then for _,t in ipairs(r[3]) do wanted[t]=true end end end
 for t in pairs(wanted) do fields[t]:set_value(1);if not active[t] then row('input_down',t);active[t]=true end end
 for t in pairs(active) do if not wanted[t] then fields[t]:clear_value();row('input_up',t);active[t]=nil end end
 if caps[f] then
  local base=string.format('%s_%04d_%s',prefix,f,caps[f]);screen:snapshot(base..'.png')
  if pce_state then
   row('pce_registers',pce_regs())
   -- Only actual RAM, excluding Arcade Card data ports and hardware registers.
   for _,range in ipairs({{0x1f0000,0x2000},{0x100000,0x10000},{0xd0000,0x30000}}) do
    local dump=assert(io.open(base..string.format('_ram_%06x.bin',range[1]),'wb'))
    local bytes={};for a=range[1],range[1]+range[2]-1 do
     bytes[#bytes+1]=string.char(sp:read_u8(a));if #bytes==4096 then dump:write(table.concat(bytes));bytes={} end
    end;dump:close()
   end
  end
  if ram_dump then
   local dump=assert(io.open(base..'_ram.bin','wb'));local bytes={}
   for a=0,0x1fffff do bytes[#bytes+1]=string.char(sp:read_u8(a));if #bytes==4096 then dump:write(table.concat(bytes));bytes={} end end;dump:close()
  end
  row('capture',caps[f],base..'.png');print('CAPTURE '..f..' '..caps[f])
 end
 if (pce_state and f>=last) or f>last+10 then meta:close();m:exit() end
end)
