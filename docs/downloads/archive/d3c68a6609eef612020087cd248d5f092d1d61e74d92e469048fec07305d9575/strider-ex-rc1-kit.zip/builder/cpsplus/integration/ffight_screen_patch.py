"""Size Final Fight's ROUND CLEAR screens to the pack's own jingles."""
from __future__ import annotations
import array
import math
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from pack.format import PackReader, CODEC_ADX, VERB_PLAY
from pack import adxcodec
FPS = 59.637405
INNER_FRAMES = 12
SITES: dict[int, tuple[int, int, float]] = {}
R6_SITE, R6_STOCK, ARCADE_0x58 = (99776, 413, 6.9)
FADE_SITE, FADE_STOCK, ARCADE_0x57 = (59673, 80, 4.0)
R6_INSTRUCTION = (99774, bytes.fromhex('3b7c019d9290'))
FADE_INSTRUCTION = (59670, bytes.fromhex('1d7c0050001e'))
FADE_CONTEXT = (59664, bytes.fromhex('61000af86baa1d7c0050001e4e75'))
CUE_ROWS = {87: 87, 88: 88}

def music_end(rd: PackReader, cmd: int, res: float=0.05, floor_db: float=-12.0) -> float | None:
    """Seconds of MUSICAL CONTENT -- the last point still within 12 dB of peak."""
    t = rd.triggers[cmd]
    if t.verb != VERB_PLAY:
        return None
    m = rd.tracks[t.track]
    data = rd.read_track(t.track)
    if m.codec == CODEC_ADX:
        u = 18 * m.channels
        data = data[:len(data) // u * u]
        pcm = adxcodec.decode(data, m.channels, m.sample_rate, total_samples=len(data) // u * 32)
    else:
        pcm = data
    a = array.array('h')
    a.frombytes(pcm)
    sr, ch = (m.sample_rate, m.channels)
    dur = len(a) / ch / sr

    def rms(t0: float, t1: float) -> float:
        i0, i1 = (int(t0 * sr) * ch, int(t1 * sr) * ch)
        seg = a[max(0, i0):i1]
        return math.sqrt(sum((float(v) * v for v in seg)) / max(1, len(seg)))
    n = int(dur / res)
    peak = max((rms(k * 0.1, (k + 1) * 0.1) for k in range(int(dur * 10))))
    if peak <= 0:
        return None
    thr = peak * 10 ** (floor_db / 20)
    hits = [(k + 1) * res for k in range(n) if rms(k * res, (k + 1) * res) > thr]
    return max(hits) if hits else None

def screen_patches(pack: str | Path, rows: dict[int, int]=CUE_ROWS) -> list[tuple[int, int]]:
    """[(68K address, value)] for a Final Fight pack; [] if it already fits."""
    rd = PackReader(pack)
    out = []
    end58 = music_end(rd, rows[88])
    if end58 and end58 > ARCADE_0x58:
        val = R6_STOCK + math.ceil((end58 - ARCADE_0x58) * FPS)
        if val > 65535:
            raise SystemExit(f'{Path(pack).name}: round-6 counter {val} overflows a word')
        out.append((R6_SITE, val))
    end57 = music_end(rd, rows[87])
    if end57 and end57 > ARCADE_0x57:
        delay = math.ceil((end57 - ARCADE_0x57) * FPS)
        val = FADE_STOCK + delay
        if val > 255:
            raise SystemExit(f'{Path(pack).name}: 0x57 needs {val} frames of fade delay, past the byte the counter lives in')
        out.append((FADE_SITE, val))
    for cmd, (addr, stock, window) in SITES.items():
        end = music_end(rd, rows.get(cmd, cmd))
        if end is None:
            continue
        over = end - window
        if over <= 0:
            continue
        add = math.ceil(over * FPS / INNER_FRAMES)
        out.append((addr, stock + add))
    return out
if __name__ == '__main__':
    for p in sys.argv[1:]:
        rd = PackReader(p)
        print(f'{Path(p).name}:')
        for cmd, (addr, stock, window) in SITES.items():
            end = music_end(rd, cmd)
            if end is None:
                print(f'  0x{cmd:02x}: unmapped')
                continue
            pats = dict(screen_patches(p))
            v = pats.get(addr)
            state = f'{stock} -> {v} blinks' if v else f'{stock} (fits, no patch)'
            print(f'  0x{cmd:02x}: music ends {end:5.2f}s, window {window:5.2f}s  -> {state}')

def assemble_mra(mra_path, rom_dir):
    import xml.etree.ElementTree as ET
    from embed_pack_mra import measure_header_len
    rom = ET.parse(mra_path).getroot().find('rom')
    R, img, missing = (Path(rom_dir), bytearray(), [])

    def rd(name):
        f = R / name
        if not f.exists():
            missing.append(name)
            return b''
        return f.read_bytes()
    for node in rom:
        if node.tag == 'interleave':
            w = int(node.get('output', '16')) // 8
            parts = [(p.get('map', ''), rd(p.get('name'))) for p in node if p.tag == 'part']
            n = min((len(d) for _, d in parts), default=0)
            if w == 2 and all((m.count('0') == len(m) - 1 for m, _ in parts)):
                out = bytearray(n * 2)
                for m, d in parts:
                    mm = m[::-1]
                    out[mm.index(next((c for c in mm if c != '0')))::2] = d[:n]
                img.extend(out)
            else:
                img.extend(b'\x00' * (n * w))
        elif node.tag == 'part':
            if node.get('name'):
                img.extend(rd(node.get('name')))
            elif node.text:
                img.extend(bytes((int(b, 16) for b in node.text.split())))
    return (img, measure_header_len(rom), missing)

def verify_sites(mra_path, rom_dir):
    """Raise unless every blink-count byte is where SITES says it is."""
    img, hdr, missing = assemble_mra(mra_path, rom_dir)
    if missing:
        raise SystemExit(f'{mra_path}: cannot verify, missing {missing[:4]}')
    checks = [(addr, stock, 1) for addr, stock, _w in SITES.values()]
    checks.append((FADE_SITE, FADE_STOCK, 1))
    checks.append((R6_SITE, R6_STOCK, 2))
    for addr, stock, width in checks:
        if width == 2:
            off = hdr + addr
            got = img[off] | img[off + 1] << 8 if off + 1 < len(img) else None
        else:
            off = hdr + (addr ^ 1)
            got = img[off] if off < len(img) else None
        if got != stock:
            raise SystemExit(f'{Path(mra_path).name}: 68K 0x{addr:X} -> MRA byte {off} holds {got}, expected the stock value {stock}. The patch would corrupt the ROM -- do not ship.')
    return True
