"""Embed a CPS+ pack into a jtCPS2/jtCPS1.5 MRA — the MiSTer-native delivery."""
import argparse
import re
import sys
import zipfile
import zlib
import xml.etree.ElementTree as ET
import mra_meta
from pathlib import Path
KB = 1024
POINTER_OFFSET = 8
MAGIC = b'CP2A'

def measure_header_len(rom_node):
    """Bytes of the LEADING inline <part>s — the jtframe MRA header."""
    total = 0
    for el in list(rom_node):
        if el.tag == 'interleave' or (el.tag == 'part' and el.get('name')):
            break
        if el.tag == 'part' and (not el.get('name')):
            text = (el.text or '').strip()
            if not text:
                continue
            nbytes = len(bytes.fromhex(text.replace(' ', '').replace('\n', '')))
            total += nbytes * int(el.get('repeat', '1'), 0)
    return total

def measure_rom_len(rom_node):
    """Sum byte lengths of the existing index-0 parts (best effort)."""
    total = 0
    measurable = True
    for part in rom_node.findall('part'):
        if part.get('name') is not None:
            measurable = False
            continue
        text = (part.text or '').strip()
        if not text:
            continue
        nbytes = len(bytes.fromhex(text.replace(' ', '').replace('\n', '')))
        total += nbytes * int(part.get('repeat', '1'), 0)
    return (total, measurable)

def archive_index(stem, zip_dirs):
    """member basename -> byte size, for the ROM archive named <stem>."""
    import subprocess
    import zipfile
    for d in zip_dirs:
        d = Path(d)
        zp, sp = (d / f'{stem}.zip', d / f'{stem}.7z')
        if zp.exists():
            with zipfile.ZipFile(zp) as z:
                return {Path(i.filename).name: i.file_size for i in z.infolist()}
        if sp.exists():
            binary = next((c for c in ('7zz', '7z', '7za') if subprocess.run(['which', c], capture_output=True).returncode == 0), None)
            if binary is None:
                raise SystemExit(f'{sp.name} needs a 7-Zip binary on PATH')
            out = subprocess.run([binary, 'l', '-slt', str(sp)], capture_output=True, text=True).stdout
            idx, name = ({}, None)
            for line in out.splitlines():
                if line.startswith('Path = '):
                    name = line[7:].strip()
                elif line.startswith('Size = ') and name:
                    idx[Path(name).name] = int(line[7:].strip())
                    name = None
            return idx
    return {}

def measure_rom_len_files(rom_node, zip_dirs):
    """(body_len, unresolved) for a base MRA, measured against the REAL ROMs."""
    total = 0
    unresolved = []
    zip_stem = Path((rom_node.get('zip') or '').split('|')[0]).stem
    seen_file_part = False
    for el in list(rom_node):
        parts = el.findall('part') if el.tag == 'interleave' else [el]
        for part in parts:
            if part.tag != 'part':
                continue
            name = part.get('name')
            if name is None:
                text = (part.text or '').strip()
                if not text:
                    continue
                n = len(bytes.fromhex(text.replace(' ', '').replace('\n', '')))
                n *= int(part.get('repeat', '1'), 0)
                if seen_file_part:
                    total += n
                continue
            seen_file_part = True
            stem = Path(part.get('zip').lstrip('/')).stem if part.get('zip') else zip_stem
            size = archive_index(stem, zip_dirs).get(name)
            if size is None:
                unresolved.append(f'{stem}:{name}')
                continue
            if part.get('length'):
                size = min(size, int(part.get('length'), 0))
            total += size
    return (total, unresolved)

def repin_crcs(tree, zip_path) -> list[str]:
    """Repin every part CRC in rom 0 to the set this MRA will actually load."""
    zips = [Path(zip_path)] if isinstance(zip_path, (str, Path)) else [Path(z) for z in zip_path]
    have: dict[str, str] = {}
    for zp in zips:
        with zipfile.ZipFile(zp) as z:
            for n in z.namelist():
                have.setdefault(n, f'{zlib.crc32(z.read(n)) & 4294967295:08x}')
    rom0 = next((r for r in tree.getroot().findall('rom') if r.get('index') == '0'))
    moved, unknown = ([], [])
    for part in rom0.iter('part'):
        name = part.get('name')
        if not name or part.get('zip'):
            continue
        if name not in have:
            unknown.append(name)
        elif part.get('crc') != have[name]:
            moved.append(f"{name} {part.get('crc')}->{have[name]}")
            part.set('crc', have[name])
    if unknown:
        raise SystemExit(f"{'|'.join((z.name for z in zips))}: MRA names parts the set does not hold: {unknown[:4]} -- wrong set?")
    return moved

def embed(base_mra: str, pack_len: int, pack_zip_name: str, rom_len: int | None, pack_zip: str | None=None, display_name: str | None=None, rbf: str | None=None, rom_zip: str | None=None, extra_patches: list[tuple[int, int]] | None=None, region: str | None=None):
    tree = ET.parse(base_mra)
    root = tree.getroot()
    if display_name is not None:
        nm = root.find('name')
        if nm is None:
            nm = ET.SubElement(root, 'name')
        nm.text = display_name
    if region is not None:
        mra_meta.apply_meta(root, region, rbf)
    if rbf is not None:
        rb = root.find('rbf')
        if rb is None:
            rb = ET.SubElement(root, 'rbf')
        rb.text = rbf
    rom = None
    for r in root.findall('rom'):
        if r.get('index') == '0':
            rom = r
            break
    if rom is None:
        raise SystemExit('no <rom index="0"> node in base MRA')
    for attr in ('asm_md5', 'md5'):
        if attr in rom.attrib:
            del rom.attrib[attr]
    if rom_zip is not None:
        rom.set('zip', rom_zip)
    hdr_len = measure_header_len(rom)
    if rom_len is None:
        rom_len, ok = measure_rom_len(rom)
        if not ok:
            raise SystemExit('base MRA has file-backed <part>s; pass --rom-len (assembled arcade ROM size in bytes, e.g. from the build image)')
    else:
        rom_len += hdr_len
    pack_off = (rom_len + KB - 1) // KB * KB
    pad = pack_off - rom_len
    units = pack_off // KB
    if units > 65535:
        raise SystemExit(f'pack offset {pack_off} exceeds 16-bit 1kB pointer')
    if pad:
        p = ET.SubElement(rom, 'part', {'repeat': str(pad)})
        p.text = '00'
    part_attrs = {'name': pack_zip_name}
    if pack_zip:
        part_attrs['zip'] = pack_zip
    pk = ET.SubElement(rom, 'part', part_attrs)
    pk.tail = '\n    '
    patch = ET.SubElement(rom, 'patch', {'offset': str(POINTER_OFFSET)})
    patch.text = f'{units & 255:02x} {units >> 8 & 255:02x} {pad & 255:02x} {pad >> 8 & 255:02x}'
    patch.tail = '\n  '
    for addr, val in extra_patches or []:
        if val > 255:
            ep = ET.SubElement(rom, 'patch', {'offset': str(hdr_len + addr)})
            ep.text = f'{val & 255:02x} {val >> 8 & 255:02x}'
        else:
            ep = ET.SubElement(rom, 'patch', {'offset': str(hdr_len + (addr ^ 1))})
            ep.text = f'{val & 255:02x}'
        ep.tail = '\n  '
    return (tree, {'rom_len': rom_len, 'pad': pad, 'pack_off': pack_off, 'units': units, 'pack_len': pack_len, 'hdr_len': hdr_len})

def run(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('base', nargs='?', type=Path, help='base jtCPS2 MRA')
    ap.add_argument('pack', nargs='?', type=Path, help='CPS+ pack .cpk')
    ap.add_argument('--zip-name', help='pack part name as it appears inside the pack zip (default: pack filename)')
    ap.add_argument('--pack-zip', help="relative path of the zip containing the .cpk, as a per-part zip= override, e.g. 'CPS+/hsf2_arrange.zip'. Leading-slash form = games-root relative (e.g. /CPS+/pack.zip); non-slash resolves under games/mame/.")
    ap.add_argument('--rom-len', help='assembled arcade ROM size in bytes (hex ok); required when parts are file-backed')
    ap.add_argument('--name', help='override the <name> shown in the arcade menu')
    ap.add_argument('--rbf', default='jtcps2-cpsplus', help="core RBF the MRA binds to (default jtcps2-cpsplus — the opt-in CPS+ core; the name must NOT be <stock>_<suffix>, because MiSTer's get_rbf() treats '_' as a version separator and picks the alphabetically-last match -- jtcps1_cpsplus.rbf hijacked every stock <rbf>jtcps1</rbf> MRA). Pass --rbf jtcps2 to target the stock core.")
    ap.add_argument('-o', '--out', type=Path, help='output MRA (default stdout)')
    ap.add_argument('--self-test', action='store_true')
    args = ap.parse_args(argv)
    if args.self_test:
        return _selftest()
    if not args.base or not args.pack:
        ap.error('base MRA and pack are required')
    magic = args.pack.open('rb').read(4)
    if magic != MAGIC:
        raise SystemExit(f'{args.pack}: not a CPS+ pack (magic {magic!r})')
    pack_len = args.pack.stat().st_size
    rom_len = int(args.rom_len, 0) if args.rom_len else None
    zip_name = args.zip_name or args.pack.name
    tree, info = embed(str(args.base), pack_len, zip_name, rom_len, args.pack_zip, args.name, args.rbf)
    out = ET.tostring(tree.getroot(), encoding='unicode')
    if args.out:
        args.out.write_text(out)
        where = str(args.out)
    else:
        sys.stdout.write(out)
        where = 'stdout'
    sys.stderr.write(f"embedded {zip_name} ({pack_len} B) at ROM offset 0x{info['pack_off']:x} (pad {info['pad']} B, pointer {info['units']} kB-units) -> {where}\n")
    return 0

def _selftest():
    import io
    base = '<misterromdescription><rom index="0" zip="game.zip"><part>0011 2233</part><part repeat="6">00</part></rom></misterromdescription>'
    p = Path('/tmp/_cpsplus_selftest_base.mra')
    p.write_text(base)
    tree, info = embed(str(p), pack_len=4096, pack_zip_name='game.cpk', rom_len=None)
    assert info['rom_len'] == 10, info
    assert info['pack_off'] == 1024 and info['units'] == 1, info
    rom = tree.getroot().find('rom')
    patch = rom.find('patch')
    assert patch.get('offset') == '8' and patch.text == '01 00 f6 03', patch.text
    names = [pt.get('name') for pt in rom.findall('part') if pt.get('name')]
    assert names == ['game.cpk'], names
    pads = [pt for pt in rom.findall('part') if pt.get('repeat') and pt.text == '00']
    assert any((pt.get('repeat') == '1014' for pt in pads)), [pt.get('repeat') for pt in pads]
    base2 = '<misterromdescription><rom index="0" zip="hsf2.zip|qsound.zip" asm_md5="deadbeef" md5="None"><part name="a.03"/></rom></misterromdescription>'
    p2 = Path('/tmp/_cpsplus_selftest_base2.mra')
    p2.write_text(base2)
    tree2, info2 = embed(str(p2), 4096, 'game.cpk', rom_len=12582912, pack_zip='CPSPlus/hsf2_arrange.zip')
    assert info2['pack_off'] == 12582912 and info2['units'] == 12582912 // KB, info2
    rom2 = tree2.getroot().find('rom')
    assert 'asm_md5' not in rom2.attrib and 'md5' not in rom2.attrib, rom2.attrib
    assert rom2.get('zip') == 'hsf2.zip|qsound.zip', rom2.get('zip')
    pk = [pt for pt in rom2.findall('part') if pt.get('name') == 'game.cpk'][0]
    assert pk.get('zip') == 'CPSPlus/hsf2_arrange.zip', pk.get('zip')
    hdr64 = ' '.join(['00'] * 64)
    base3 = f'<misterromdescription><rom index="0" zip="sf2uk.zip"><part>{hdr64}</part><interleave output="16"><part name="a.11f" map="01"/><part name="b.11e" map="10"/></interleave></rom></misterromdescription>'
    p3 = Path('/tmp/_cpsplus_selftest_base3.mra')
    p3.write_text(base3)
    tree3, info3 = embed(str(p3), 4096, 'game.cpk', rom_len=7667712)
    assert info3['hdr_len'] == 64, info3
    assert info3['pack_off'] == 7668736, hex(info3['pack_off'])
    assert info3['pad'] == 7668736 - 7667776, info3['pad']
    assert info3['units'] == 7668736 // KB == 7489, info3['units']
    rom3 = tree3.getroot().find('rom')
    patch3 = rom3.find('patch')
    assert patch3.text == '41 1d c0 03', patch3.text
    assert info3['hdr_len'] + 7667712 + info3['pad'] == info3['units'] * KB
    print('embed_pack_mra self-test: PASS')
    return 0
if __name__ == '__main__':
    sys.exit(run())
