"""Arcade-menu naming and the fields MiSTer's Arcade Organizer sorts by."""
from __future__ import annotations
import json
import re
from pathlib import Path
import xml.etree.ElementTree as ET
HERE = Path(__file__).resolve().parent
CATVER = json.loads((HERE.parent / 'manifests' / 'mra_catver.json').read_text())['catver']
CATEGORY = {'Fighter / Versus': 'Fighting', 'Fighter / 2.5D': "Beat 'em up", 'Platform / Fighter Scrolling': 'Platform', 'Puzzle / Drop': 'Puzzle', 'Shooter / Flying Horizontal': 'Shooter', 'Sports / Wrestling': 'Sports'}
PLATFORM = {'jtcps1-cpsplus': 'CPS-1', 'jtcps15-cpsplus': 'CPS-1.5', 'jtcps2-cpsplus': 'CPS-2'}
MRAAUTHOR = 'jotego,strygo'
FIELDS = ('region', 'platform', 'category', 'catver', 'mraauthor')

def format_name(name: str, region: str) -> str:
    """"Final Fight (Arrange, Japan)" + Japan -> "Final Fight (Japan) [Arrange]"."""
    m = re.fullmatch('(?P<title>.+?) \\((?P<tag>[^()]+)\\)', name)
    if not m:
        raise ValueError(f'cannot read a title and tag out of {name!r}')
    tag = re.sub(f',\\s*{re.escape(region)}$', '', m.group('tag')).strip()
    return f"{m.group('title')} ({region}) [{tag}]"

def apply_meta(root: ET.Element, region: str, rbf: str | None) -> None:
    """Set the organizer fields, in order, after <region>."""
    setname = root.findtext('setname')
    catver = CATVER.get(setname)
    if catver is None:
        raise SystemExit(f'{setname}: no genre in manifests/mra_catver.json')
    values = {'region': region, 'platform': PLATFORM.get(rbf or ''), 'category': CATEGORY[catver], 'catver': catver, 'mraauthor': MRAAUTHOR}
    ref = root.find('region')
    anchor = list(root).index(ref) if ref is not None else len(root)
    for offset, field in enumerate(FIELDS):
        value = values[field]
        if value is None:
            continue
        el = root.find(field)
        if el is None:
            el = ET.Element(field)
            el.tail = ref.tail if ref is not None else '\n    '
            root.insert(anchor + offset, el)
        el.text = value
