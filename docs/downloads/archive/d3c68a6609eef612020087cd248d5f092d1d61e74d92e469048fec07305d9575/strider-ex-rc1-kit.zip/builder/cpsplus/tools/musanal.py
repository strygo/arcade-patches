"""Analyze headerless PCM candidates: channel layout, block interleave, edge continuity."""
import sys, struct, math

def s16be(buf):
    n = len(buf) // 2
    return struct.unpack('>%dh' % n, buf[:n * 2])

def smoothness(samples):
    """mean abs first difference / mean abs value — lower = smoother waveform"""
    if len(samples) < 3:
        return 0
    d = [abs(samples[i + 1] - samples[i]) for i in range(len(samples) - 1)]
    a = [abs(x) for x in samples]
    ma = sum(a) / len(a) or 1
    return sum(d) / len(d) / ma

def rms(samples):
    if not samples:
        return 0
    return math.sqrt(sum((x * x for x in samples)) / len(samples))

def main():
    path = sys.argv[1]
    data = open(path, 'rb').read()
    print(f'{path}: {len(data)} bytes ({len(data) / 2048} sectors of 2048)')
    mid = len(data) // 2 & ~4095
    win = data[mid:mid + 8192]
    s = s16be(win)
    print(f'mono16BE smoothness: {smoothness(s):.3f}')
    print(f'stereo16BE-interleaved L smoothness: {smoothness(s[0::2]):.3f}, R: {smoothness(s[1::2]):.3f}')
    for bs in (1024, 2048, 4096):
        b1 = s16be(data[mid:mid + bs])
        b2 = s16be(data[mid + bs:mid + 2 * bs])
        n = min(len(b1), len(b2))
        m1 = sum(b1[:n]) / n
        m2 = sum(b2[:n]) / n
        num = sum(((b1[i] - m1) * (b2[i] - m2) for i in range(n)))
        den = math.sqrt(sum(((x - m1) ** 2 for x in b1[:n])) * sum(((x - m2) ** 2 for x in b2[:n]))) or 1
        edge = s16be(data[mid + bs - 8:mid + bs + 8])
        jump = abs(edge[4] - edge[3])
        print(f'block {bs}: corr(next-block)={num / den:+.3f} boundary-jump={jump}')
    head = s16be(data[:64])
    tail = s16be(data[-64:])
    print('head samples:', head[:16])
    print('tail samples:', tail[-16:])
    print(f'RMS first4k={rms(s16be(data[:4096])):.0f} mid4k={rms(s)::=.0f}' if False else f'RMS first4k={rms(s16be(data[:4096])):.0f} mid={rms(s):.0f} last4k={rms(s16be(data[-4096:])):.0f}')
main()
