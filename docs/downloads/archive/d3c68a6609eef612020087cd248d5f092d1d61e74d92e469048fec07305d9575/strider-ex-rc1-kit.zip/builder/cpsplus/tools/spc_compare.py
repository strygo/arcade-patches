"""Are two SPC rips the same music?  (plan decisions D2 and D4)"""
from __future__ import annotations
import argparse
import hashlib
import json
import re
import sys
from pathlib import Path
import numpy as np
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
sys.path.insert(0, str(Path(__file__).resolve().parent))
from pack import spc_engine
import pin_spc_sets
import spc_loops
SCRATCH = spc_loops.SCRATCH
HOP, WIN = (512, 2048)

def sample_hash(ram: bytes, directory: int, srcn: int) -> str:
    """SHA-256 of one BRR sample: from its directory start to the end flag."""
    entry = directory * 256 + srcn * 4 & 65535
    start = ram[entry] | ram[entry + 1 & 65535] << 8
    out, pos = (bytearray(), start)
    for _ in range(4096):
        block = bytes((ram[pos + i & 65535] for i in range(9)))
        out += block
        if block[0] & 1:
            break
        pos = pos + 9 & 65535
    return hashlib.sha256(out).hexdigest()[:16]

def profile(spc: Path, seconds: int=150) -> dict:
    blob = spc.read_bytes()
    ram, directory = (blob[256:65792], blob[65792 + 93])
    recs, _ = spc_engine.ticks(spc, seconds * spc_engine.RATE, SCRATCH)
    ev = spc_loops._events(recs)
    if ev is None:
        return {'events': 0}
    first, last, mask = ev
    srcn, semi = spc_loops._notes(recs, last, mask)
    hashes = {}
    sig = []
    for j in range(len(first)):
        row = []
        for v in range(8):
            if srcn[j, v] >= 0:
                s = int(srcn[j, v])
                hashes.setdefault(s, sample_hash(ram, directory, s))
                row.append((v, hashes[s], float(semi[j, v])))
        sig.append(row)
    pcm = spc_engine.render(spc, 90 * spc_engine.RATE)
    return {'events': len(first), 'first': first, 'sig': sig, 'samples': sorted(set(hashes.values())), 'spec': _spec(pcm)}

def _spec(pcm: np.ndarray) -> np.ndarray:
    x = pcm.astype(np.float32).mean(1)
    n = (len(x) - WIN) // HOP
    frames = np.lib.stride_tricks.sliding_window_view(x, WIN)[::HOP][:n] * np.hanning(WIN).astype(np.float32)
    out = np.empty((n, 64), np.float32)
    for i in range(0, n, 4096):
        m = np.abs(np.fft.rfft(frames[i:i + 4096], axis=1))[:, :1024]
        out[i:i + 4096] = np.log1p(m.reshape(len(m), 64, 16).mean(2))
    return out

def _align(a: np.ndarray, b: np.ndarray, max_lag: int=300) -> tuple[int, float]:
    """Lag (hops) of b against a maximizing spectral correlation, and it."""
    np.seterr(invalid='ignore', divide='ignore')
    best = (0, -1.0)
    T = min(len(a), len(b)) - max_lag - 1
    for lag in range(-max_lag, max_lag + 1):
        A = a[max(0, -lag):max(0, -lag) + T].ravel()
        B = b[max(0, lag):max(0, lag) + T].ravel()
        n = min(len(A), len(B))
        if n < 1000:
            continue
        c = float(np.corrcoef(A[:n], B[:n])[0, 1])
        if c > best[1]:
            best = (lag, c)
    return best

def compare(pa: dict, pb: dict) -> dict:
    if not pa['events'] or not pb['events']:
        return {'verdict': 'DIFFERENT', 'why': 'no notes in one rip'}
    lag, audio = _align(pa['spec'], pb['spec'])
    best_off, best_frac = (0, 0.0)
    for off in range(-40, 41):
        n, same = (0, 0)
        for j in range(150):
            k = j + off
            if 0 <= j < len(pa['sig']) and 0 <= k < len(pb['sig']):
                x, y = (pa['sig'][j], pb['sig'][k])
                n += 1
                same += len(x) == len(y) and all((u[0] == w[0] and u[1] == w[1] and (abs(u[2] - w[2]) < spc_loops.PITCH_TOL) for u, w in zip(x, y)))
        if n and same / n > best_frac:
            best_off, best_frac = (off, same / n)
    samples_same = pa['samples'] == pb['samples']
    if samples_same and best_frac >= 0.99 and (audio >= 0.99):
        verdict = 'SAME'
    elif best_frac >= 0.95:
        verdict = 'CLOSE'
    else:
        verdict = 'DIFFERENT'
    return {'verdict': verdict, 'notes': round(best_frac, 4), 'audio': round(audio, 4), 'samples_same': samples_same, 'event_offset': best_off, 'lag_hops': lag, 'samples_a': len(pa['samples']), 'samples_b': len(pb['samples'])}

def _norm(title: str) -> str:
    t = title.lower().replace('jap', '').replace('us, europe', '')
    return re.sub('[^a-z0-9]+', '', t)

def _note_score(pa: dict, pb: dict) -> float:
    best = 0.0
    for off in range(-40, 41):
        n = same = 0
        for j in range(150):
            k = j + off
            if 0 <= j < len(pa['sig']) and 0 <= k < len(pb['sig']):
                x, y = (pa['sig'][j], pb['sig'][k])
                n += 1
                same += len(x) == len(y) and all((u[1] == w[1] and abs(u[2] - w[2]) < spc_loops.PITCH_TOL for u, w in zip(x, y)))
        if n >= 20:
            best = max(best, same / n)
    return best

def pair_sets(a: str, b: str, pre_a: str | None, pre_b: str | None, by_notes: bool=False) -> list[dict]:
    sources = {x['project']: x for x in json.loads(pin_spc_sets.MANIFEST.read_text())['sets']}
    directory = pin_spc_sets.spc_dir(None)
    dirs = {}
    for project in {a, b}:
        rsn = directory / f'{project}.rsn'
        problems = pin_spc_sets.verify(project, rsn, sources[project])
        if problems:
            raise SystemExit('\n'.join(problems))
        dirs[project] = SCRATCH / f'compare_{project}'
        spc_engine.extract(rsn, dirs[project])

    def songs(project, prefix):
        return {_norm(m['title']): m for m in sources[project]['members'] if m.get('kind') in ('music', 'bonus') and (prefix is None or m['name'].startswith(prefix))}
    sa, sb = (songs(a, pre_a), songs(b, pre_b))
    rows = []
    if by_notes:
        pa = {k: profile(dirs[a] / m['name']) for k, m in sa.items()}
        pb = {k: profile(dirs[b] / m['name']) for k, m in sb.items()}
        pairs, used = ([], set())
        scored = sorted(((_note_score(pa[x], pb[y]), x, y) for x in pa for y in pb if pa[x]['events'] and pb[y]['events']), reverse=True)
        for score, x, y in scored:
            if score < 0.5 or x in {p[0] for p in pairs} or y in used:
                continue
            pairs.append((x, y))
            used.add(y)
        for x, y in sorted(pairs, key=lambda p: sa[p[0]]['name']):
            res = compare(pa[x], pb[y])
            res.update(a=sa[x]['name'], b=sb[y]['name'], title=sa[x]['title'], title_b=sb[y]['title'])
            rows.append(res)
            print(json.dumps(res), flush=True)
        matched_a, matched_b = ({p[0] for p in pairs}, {p[1] for p in pairs})
    else:
        for key in sorted(set(sa) & set(sb)):
            ma, mb = (sa[key], sb[key])
            res = compare(profile(dirs[a] / ma['name']), profile(dirs[b] / mb['name']))
            res.update(a=ma['name'], b=mb['name'], title=ma['title'])
            rows.append(res)
            print(json.dumps(res), flush=True)
        matched_a = matched_b = set(sa) & set(sb)
    only_a = sorted((sa[k]['name'] for k in set(sa) - matched_a))
    only_b = sorted((sb[k]['name'] for k in set(sb) - matched_b))
    print(json.dumps({'unmatched_a': only_a, 'unmatched_b': only_b}))
    tally = {v: sum((r['verdict'] == v for r in rows)) for v in ('SAME', 'CLOSE', 'DIFFERENT')}
    print(json.dumps({'pairs': len(rows), **tally}))
    return rows

def self_test() -> None:
    ram = bytearray(65536)
    ram[512:516] = bytes([0, 48, 0, 48])
    ram[12288] = 0
    ram[12297] = 1
    h = sample_hash(bytes(ram), 2, 0)
    ram[12293] = 85
    assert sample_hash(bytes(ram), 2, 0) != h
    assert _norm('M. Bison (Jap)/Balrog (US, Europe)') == 'mbisonbalrog'
    print('spc_compare self-test: OK')

def main(argv: list[str] | None=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('sets', nargs='*')
    ap.add_argument('--prefix-a')
    ap.add_argument('--prefix-b')
    ap.add_argument('--by-notes', action='store_true')
    ap.add_argument('--self-test', action='store_true')
    a = ap.parse_args(argv)
    if a.self_test:
        self_test()
        return 0
    if len(a.sets) != 2:
        ap.error('give two set projects')
    pair_sets(a.sets[0], a.sets[1], a.prefix_a, a.prefix_b, a.by_notes)
    return 0
if __name__ == '__main__':
    raise SystemExit(main())
