"""Pair arcade music commands with SNES SPC songs: scores, then a listening page."""
from __future__ import annotations
import argparse
import html
import json
import sys
import wave
from pathlib import Path
import numpy as np
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
sys.path.insert(0, str(HERE))
from pack import spc_engine
import pin_spc_sets
RATE = 24000
CLIP_S = 30

def _read(path: Path) -> np.ndarray:
    with wave.open(str(path)) as w:
        x = np.frombuffer(w.readframes(w.getnframes()), dtype='<i2').astype(np.float64)
        if w.getnchannels() == 2:
            x = x.reshape(-1, 2).mean(1)
        sr = w.getframerate()
    if sr != RATE:
        k = int(round(len(x) * RATE / sr))
        x = np.interp(np.linspace(0, len(x) - 1, k), np.arange(len(x)), x)
    return x / 32768

def _write(path: Path, x: np.ndarray) -> str:
    with wave.open(str(path), 'wb') as o:
        o.setnchannels(1)
        o.setsampwidth(2)
        o.setframerate(RATE)
        o.writeframes(np.clip(np.round(x * 32767), -32768, 32767).astype('<i2').tobytes())
    return path.name

def chroma(x: np.ndarray) -> np.ndarray:
    """12 x frames pitch-class energy (4096-point frames, hop 2048 at 24 kHz),"""
    n = 4096
    hop = 2048
    frames = np.lib.stride_tricks.sliding_window_view(x, n)[::hop] * np.hanning(n)
    mag = np.abs(np.fft.rfft(frames, axis=1))
    f = np.fft.rfftfreq(n, 1 / RATE)
    sel = (f > 55) & (f < 4000)
    pc = np.round(12 * np.log2(f[sel] / 440.0)).astype(int) % 12
    c = np.zeros((12, len(frames)))
    for k in range(12):
        c[k] = mag[:, sel][:, pc == k].sum(1)
    c = np.log1p(c)
    c -= c.mean(1, keepdims=True)
    sd = c.std(1, keepdims=True)
    return c / np.where(sd > 0, sd, 1)

def score(ca: np.ndarray, cb: np.ndarray, max_lag: int=60) -> float:
    """Best mean correlation of the two chroma sequences over lag and +/-2"""
    best = -1.0
    for shift in (-2, -1, 0, 1, 2):
        b = np.roll(cb, shift, axis=0)
        for lag in range(-max_lag, max_lag + 1, 2):
            if lag >= 0:
                A, B = (ca[:, lag:], b)
            else:
                A, B = (ca, b[:, -lag:])
            n = min(A.shape[1], B.shape[1])
            if n < 40:
                continue
            r = float((A[:, :n] * B[:, :n]).mean())
            best = max(best, r)
    return best

def main(argv: list[str] | None=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--catalog', type=Path)
    ap.add_argument('--set')
    ap.add_argument('--work', type=Path)
    ap.add_argument('--prior', type=Path)
    ap.add_argument('--control', action='store_true')
    ap.add_argument('--apply', type=Path)
    ap.add_argument('--deep')
    ap.add_argument('--deep-seconds', type=int, default=150)
    ap.add_argument('--only', help='comma list of commands: a focused page of just these')
    ap.add_argument('--roles', type=Path, help='TSV cmd<TAB>role...: shown on each row')
    ap.add_argument('--propose', help='cmd=song or cmd=hold:song overrides, comma list')
    ap.add_argument('--alts', help='cmd=song[/song] alternatives to name on the row')
    ap.add_argument('--name', default='', help='page/storage suffix for a focused page')
    ap.add_argument('--out', type=Path)
    a = ap.parse_args(argv)
    if a.apply:
        return apply(a.apply, a.out)
    if a.deep:
        return deep(a.catalog, a.set, a.work, [int(c, 16) for c in a.deep.split(',')], a.deep_seconds)
    cat = json.loads((a.catalog / 'catalog.json').read_text())
    sources = {x['project']: x for x in json.loads(pin_spc_sets.MANIFEST.read_text())['sets']}
    entry = sources[a.set]
    rsn = pin_spc_sets.spc_dir(None) / f'{a.set}.rsn'
    problems = pin_spc_sets.verify(a.set, rsn, entry)
    if problems:
        raise SystemExit('\n'.join(problems))
    page_id = a.set + (f'_{a.name}' if a.name else '')
    work = a.work.resolve() / f'review_pairing_{page_id}'
    work.mkdir(parents=True, exist_ok=True)
    extract = a.work.resolve() / f'extract_{a.set}'
    spc_engine.extract(rsn, extract)
    inventory = {}
    inv_path = pin_spc_sets.MANIFEST.parent / 'spc_inventory.json'
    if inv_path.exists():
        for s in json.loads(inv_path.read_text())['sets']:
            if s['project'] == a.set:
                inventory = {x['name']: x for x in s['songs']}
    songs = [m for m in entry['members'] if m.get('kind') in ('music', 'bonus')]
    snes = {}
    for m in songs:
        pcm = spc_engine.render(extract / m['name'], CLIP_S * spc_engine.RATE)
        x = pcm.astype(np.float64).mean(1) / 32768
        k = int(round(len(x) * RATE / spc_engine.RATE))
        x = np.interp(np.linspace(0, len(x) - 1, k), np.arange(len(x)), x)
        snes[m['name']] = {'title': m['title'], 'file': _write(work / f"snes_{m['name'][:-4]}.wav", x), 'chroma': chroma(x), 'kind': inventory.get(m['name'], {}).get('kind', '?')}
    prior = {}
    if a.prior:
        for line in a.prior.read_text().splitlines():
            f = line.split('\t')
            if line.startswith('#') or len(f) < 3:
                continue
            prior[int(f[0], 16)] = f[2]
    only = {int(c, 16) for c in a.only.split(',')} if a.only else None
    override = dict((kv.split('=', 1) for kv in a.propose.split(','))) if a.propose else {}
    alts = dict((kv.split('=', 1) for kv in a.alts.split(','))) if a.alts else {}
    roles = {}
    if a.roles:
        for line in a.roles.read_text().splitlines():
            f = line.split('\t')
            if not line.startswith('#') and len(f) >= 2 and f[0].startswith('0x'):
                roles[int(f[0], 16)] = f[1]
    rows = []
    for key, info in sorted(cat['commands'].items()):
        cmd = int(key, 16)
        if info['silent'] or cmd == 0 or (only is not None and cmd not in only):
            continue
        x = _read(a.catalog / 'clips' / f'{cmd:02x}.wav')
        ca = chroma(x)
        ranked = sorted(((score(ca, s['chroma']), n) for n, s in snes.items()), reverse=True)
        proposal, why = (ranked[0][1], f'chroma {ranked[0][0]:.3f} (next {ranked[1][0]:.3f})')
        if cmd in prior:
            want = prior[cmd].lower().replace('chunli', 'chun-li')
            exact = [n for n, s in snes.items() if s['title'].lower() == f'stage {want}']
            named = exact or [n for n, s in snes.items() if want in s['title'].lower() and s['title'].lower().startswith('stage')]
            if named:
                proposal, why = (named[0], f'prior map: {prior[cmd]}')
        ov = override.get(key) or override.get(f'0x{cmd:02x}')
        if ov:
            proposal, why = (ov, "proposed from the command's role")
        rows.append({'cmd': key, 'arcade': _write(work / f'arcade_{cmd:02x}.wav', x), 'arcade_sounding_s': info['sounding_s'], 'proposal': proposal, 'why': why, 'role': roles.get(cmd, ''), 'alts': alts.get(key, alts.get(f'0x{cmd:02x}', '')), 'ranked': [[n, round(r, 3)] for r, n in ranked[:5]]})
    if a.control and prior:
        ranks = []
        for r in rows:
            cmd = int(r['cmd'], 16)
            if cmd in prior and r['why'].startswith('prior'):
                order = [n for n, _ in r['ranked']] + [n for n in snes if n not in {x for x, _ in r['ranked']}]
                full = sorted(((score(chroma(_read(a.catalog / 'clips' / f'{cmd:02x}.wav')), s['chroma']), n) for n, s in snes.items()), reverse=True)
                rank = [n for _, n in full].index(r['proposal']) + 1
                ranks.append(rank)
        print(json.dumps({'control_prior_rows': len(ranks), 'true_pair_rank_1': sum((1 for k in ranks if k == 1)), 'true_pair_top_3': sum((1 for k in ranks if k <= 3)), 'ranks': ranks}))
    (work / 'index.html').write_text(_page(page_id, rows, snes))
    (work / 'proposals.json').write_text(json.dumps(rows, indent=1) + '\n')
    print(f"page: {work / 'index.html'} ({len(rows)} commands, {len(snes)} SNES songs)")
    return 0

def deep(catalog: Path, project: str, work_root: Path, cmds: list[int], seconds: int=150) -> int:
    sources = {x['project']: x for x in json.loads(pin_spc_sets.MANIFEST.read_text())['sets']}
    entry = sources[project]
    rsn = pin_spc_sets.spc_dir(None) / f'{project}.rsn'
    problems = pin_spc_sets.verify(project, rsn, entry)
    if problems:
        raise SystemExit('\n'.join(problems))
    extract = work_root.resolve() / f'extract_{project}'
    spc_engine.extract(rsn, extract)
    long = {}
    for m in entry['members']:
        if m.get('kind') not in ('music', 'bonus'):
            continue
        pcm = spc_engine.render(extract / m['name'], seconds * spc_engine.RATE)
        x = pcm.astype(np.float64).mean(1) / 32768
        k = int(round(len(x) * RATE / spc_engine.RATE))
        x = np.interp(np.linspace(0, len(x) - 1, k), np.arange(len(x)), x)
        long[m['name']] = (m['title'], chroma(x))
    hop_frames = int(5 * RATE / 2048)
    for cmd in cmds:
        ca = chroma(_read(catalog / 'clips' / f'{cmd:02x}.wav'))
        w = ca.shape[1]
        best = []
        for name, (title, cb) in long.items():
            top = (-1.0, 0)
            for start in range(0, max(1, cb.shape[1] - w // 2), hop_frames):
                r = score(ca, cb[:, start:start + w + 60], max_lag=30)
                if r > top[0]:
                    top = (r, start)
            best.append((top[0], name, title, round(top[1] * 2048 / RATE, 1)))
        best.sort(reverse=True)
        print(json.dumps({'cmd': f'0x{cmd:02x}', 'best': [[n, t, round(r, 3), f'at {o} s'] for r, n, t, o in best[:4]]}))
    return 0

def apply(decisions: Path, out: Path) -> int:
    d = json.loads(decisions.read_text())
    lines = ['', f'# source: {decisions.name}', 'cmd\tspc\tnote']
    for cmd in sorted((k for k in d if k.startswith('0x'))):
        v = d[cmd]
        if v and v != 'none':
            spc = 'hold' if v.startswith('hold:') else v
            lines.append(f"{cmd}\t{spc}\t{d.get(cmd + '-note', '')}")
    out.write_text('\n'.join(lines) + '\n')
    print(f'wrote {out} ({len(lines) - 3} rows)')
    return 0

def _page(project: str, rows: list[dict], snes: dict) -> str:
    options = ''.join((f'''<option value="{html.escape(n)}">{html.escape(n)} {html.escape(s['title'])} [{s['kind']}]</option>''' for n, s in sorted(snes.items())))
    files = json.dumps({n: s['file'] for n, s in snes.items()})
    body = []
    for r in rows:
        top = ', '.join((f"{html.escape(n)} {html.escape(snes[n]['title'])} ({v})" for n, v in r['ranked'][:3]))
        prop = r['proposal']
        held = prop.split(':', 1)[1] if prop.startswith('hold:') else None
        hold_opt = f'''<option value="{html.escape(prop)}">hold: keep playing {html.escape(snes[held]['title'])}</option>''' if held else ''
        shown = f"hold, {snes[held]['title']} plays on" if held else f"{prop} {snes[prop]['title']}" if prop in snes else prop
        alt = ''
        if r.get('alts'):
            alt = '<br>alternative: ' + ' / '.join((f"{html.escape(n)} {html.escape(snes[n]['title'])}" for n in r['alts'].split('/') if n in snes))
        role = f"""<p class="role">{html.escape(r['role'])}</p>""" if r.get('role') else ''
        body.append(f'''<section data-cmd="{r['cmd']}" data-proposal="{html.escape(prop)}">\n<h2>{r['cmd']} <small>arcade sounds {r['arcade_sounding_s']} s</small></h2>{role}\n<div class="row"><span>arcade</span><audio controls preload="none" src="{r['arcade']}"></audio></div>\n<div class="row"><span>SNES</span><select name="{r['cmd']}"><option value="none">no SNES counterpart</option>{hold_opt}{options}</select></div>\n<div class="row"><span></span><audio class="snes" controls preload="none"></audio></div>\n<p class="why">proposed: {html.escape(shown)} &middot; {html.escape(r['why'])}{alt}<br>top by score: {top}</p>\n<input type="text" name="{r['cmd']}-note" placeholder="note">\n</section>''')
    return '<!doctype html><html lang="en"><head><meta charset="utf-8">\n<meta name="viewport" content="width=device-width,initial-scale=1"><title>' + project + ' SPC pairing</title>\n<style>\n:root{--bg:#fff;--fg:#1b1b1b;--muted:#666;--line:#ddd}\n@media (prefers-color-scheme:dark){:root{--bg:#161616;--fg:#eee;--muted:#aaa;--line:#333}}\nbody{background:var(--bg);color:var(--fg);font:15px/1.45 system-ui,sans-serif;max-width:900px;margin:0 auto;padding:16px}\nsection{border-top:1px solid var(--line);padding:10px 0}.row{display:flex;gap:10px;align-items:center;flex-wrap:wrap}\n.row span{min-width:60px}.why,small{color:var(--muted)}.role{margin:2px 0 6px;font-weight:600}select{max-width:100%}audio{max-width:100%}\n</style></head><body>\n<h1>' + project + ': arcade command &rarr; SNES song</h1>\n<p>Each arcade command as the board plays it, and the SNES song proposed for it; the SNES player follows the picker. Starting any player pauses the others. "hold" swallows the arcade command and lets the SNES song already playing carry on (the player shows that song). "no SNES counterpart" leaves the command on the arcade music.</p>\n<p><button id="export">Export decisions</button> <span id="count"></span></p>\n' + '\n'.join(body) + '\n<script>\nconst FILES=' + files + ";\nconst KEY='spc-pairing-" + project + "';\nfunction load(){try{return JSON.parse(localStorage.getItem(KEY)||'{}')}catch(e){return{}}}\nfunction save(d){try{localStorage.setItem(KEY,JSON.stringify(d))}catch(e){}}\nconst d=load();\ndocument.querySelectorAll('section').forEach(s=>{\n  const sel=s.querySelector('select'); sel.value=d[sel.name]||s.dataset.proposal;\n  const note=s.querySelector('input'); if(d[note.name])note.value=d[note.name];\n  const player=s.querySelector('audio.snes');\n  const follow=()=>{player.pause();const v=sel.value.startsWith('hold:')?sel.value.slice(5):sel.value;\n    if(FILES[v]){player.src=FILES[v];player.hidden=false}\n    else{player.removeAttribute('src');player.hidden=true}};\n  follow();\n  const store=()=>{const x=load();x[sel.name]=sel.value;x[note.name]=note.value;save(x);count()};\n  sel.addEventListener('change',()=>{follow();store()}); note.addEventListener('change',store);\n});\ndocument.addEventListener('play',e=>{document.querySelectorAll('audio').forEach(a=>{if(a!==e.target)a.pause()})},true);\nfunction count(){const x=load();document.getElementById('count').textContent=\n  Object.keys(x).filter(k=>/^0x..$/.test(k)).length+' of '+document.querySelectorAll('section').length+' touched'}\ncount();\ndocument.getElementById('export').onclick=()=>{const x=load();\n  document.querySelectorAll('section select').forEach(s=>{if(!(s.name in x))x[s.name]=s.value});\n  const b=new Blob([JSON.stringify(x,null,1)],{type:'application/json'});\n  const a=document.createElement('a');a.href=URL.createObjectURL(b);a.download='" + project + "_pairing_decisions.json';a.click()};\n</script></body></html>"
if __name__ == '__main__':
    raise SystemExit(main())
