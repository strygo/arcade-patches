"""Catalog Strider PSX SEP timing and the disc's original/remix dispatch table."""
from __future__ import annotations
import argparse
import hashlib
import json
import struct
from pathlib import Path

def require(condition, message):
    if not condition:
        raise ValueError(message)

def score(data: bytes, ppqn: int, tempo: int) -> dict:
    require(ppqn > 0 and tempo > 0, 'invalid initial timing')
    pos = tick = 0
    seconds = 0.0
    running = None
    controls, tempos = ([], [])
    notes = 0
    ended = False
    while pos < len(data):
        delta = 0
        for _ in range(4):
            require(pos < len(data), 'truncated delta')
            byte = data[pos]
            pos += 1
            delta = delta << 7 | byte & 127
            if byte < 128:
                break
        else:
            raise ValueError('delta exceeds four bytes')
        tick += delta
        seconds += delta * tempo / ppqn / 1000000.0
        require(pos < len(data), 'missing event')
        if data[pos] & 128:
            running = data[pos]
            pos += 1
        require(running is not None, 'running status without status byte')
        if running == 255:
            require(pos < len(data), 'missing meta type')
            kind = data[pos]
            pos += 1
            if kind == 47:
                require(data[pos:] == b'\x00', 'invalid end or trailing event data')
                ended = True
                break
            require(kind == 81, f'unsupported meta event {kind:02x}')
            require(pos + 3 <= len(data), 'truncated tempo')
            tempo = int.from_bytes(data[pos:pos + 3], 'big')
            require(tempo > 0, 'zero tempo')
            pos += 3
            tempos.append(dict(tick=tick, seconds=seconds, tempo=tempo))
        elif running < 240:
            size = 1 if running >> 4 in (12, 13) else 2
            args = list(data[pos:pos + size])
            require(len(args) == size and all((x < 128 for x in args)), 'invalid event data')
            pos += size
            if running >> 4 == 11 and args[0] in (6, 98, 99):
                controls.append(dict(tick=tick, seconds=seconds, channel=running & 15, controller=args[0], value=args[1]))
            if running >> 4 == 9 and args[1]:
                notes += 1
        else:
            raise ValueError(f'unsupported status {running:02x}')
    require(ended, 'missing sequence end')
    return dict(end_tick=tick, end_seconds=seconds, note_count=notes, controls=controls, tempo_changes=tempos)

def sep(data: bytes) -> list[dict]:
    require(data[:6] == b'pQES\x00\x00', 'not a version-zero SEP')
    pos = 6
    rows = []
    while pos < len(data):
        if not any(data[pos:]):
            break
        require(pos + 13 <= len(data), 'truncated SEP sequence header')
        start = pos
        ident, ppqn = struct.unpack_from('>HH', data, pos)
        tempo = int.from_bytes(data[pos + 4:pos + 7], 'big')
        rhythm = list(data[pos + 7:pos + 9])
        size = int.from_bytes(data[pos + 9:pos + 13], 'big')
        pos += 13
        require(size > 0 and pos + size <= len(data), 'invalid SEP data size')
        payload = data[pos:pos + size]
        require(ident not in [r['id'] for r in rows], 'duplicate sequence ID')
        rows.append(dict(id=ident, offset=start, bytes=size, ppqn=ppqn, initial_tempo=tempo, rhythm=rhythm, sha256=hashlib.sha256(payload).hexdigest(), **score(payload, ppqn, tempo)))
        pos += size
    require(bool(rows), 'empty SEP')
    return rows

def command_table(exe: bytes) -> list[dict]:
    require(exe[:8] == b'PS-X EXE', 'not a PS-X EXE')
    base = int.from_bytes(exe[24:28], 'little')
    require(base == 2147549184, 'unexpected Strider executable load address')

    def offset(address):
        pos = address - base + 2048
        require(2048 <= pos < len(exe), 'pointer outside executable')
        return pos

    def text(address):
        pos = offset(address)
        end = exe.find(b'\x00', pos, pos + 100)
        require(end >= pos, 'unterminated dispatch label')
        return exe[pos:end].decode('ascii')
    start = offset(2147785432)
    rows = []
    for command in range(36):
        a = struct.unpack_from('<bbbBIbbbBI', exe, start + command * 16)
        require(a[3] == a[8] == 0, 'unexpected dispatch padding')
        rows.append(dict(command=f'0x{command:02x}', original_bank=a[0], original_sequence=a[1], original_play_count=a[2], original_label=text(a[4]), remix_bank=a[5], remix_sequence=a[6], remix_label=text(a[9])))
    require(rows[0]['original_label'] == 'ST1 BGM1' and rows[33]['original_label'] == 'ENDING BGM', 'dispatch identity mismatch')
    return rows

def self_test():
    payload = bytes.fromhex('00 b0 63 14 00 06 7f 60 ff 51 03 d0 90 60 b0 63 1e 00 ff 2f 00')
    result = score(payload, 96, 500000)
    require(result['end_tick'] == 192 and result['end_seconds'] == 0.75, 'tempo timing')
    require([r['value'] for r in result['controls']] == [20, 127, 30], 'NRPN parsing')
    header = struct.pack('>HH', 0, 96) + 500000 .to_bytes(3, 'big') + b'\x04\x02' + len(payload).to_bytes(4, 'big')
    fixture = b'pQES\x00\x00' + header + payload
    require(len(sep(fixture)) == 1, 'SEP framing')
    for bad in (fixture[:-1], b'pQES\x00\x00' + header[:5], b'bad'):
        try:
            sep(bad)
        except ValueError:
            continue
        raise AssertionError('accepted malformed SEP')
    print('Strider PSX catalog self-test passed')

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--files', type=Path, help='extracted PSX ISO files directory')
    parser.add_argument('--output', type=Path)
    parser.add_argument('--self-test', action='store_true')
    args = parser.parse_args()
    if args.self_test:
        self_test()
        return
    parser.error('--files and --output are required') if not args.files or not args.output else None
    paths = sorted((args.files / 'SOUND/BGM').glob('*.SEP'))
    require(len(paths) == 10, 'expected five original and five remix SEP banks')
    banks = [dict(file=p.name, sha256=hashlib.sha256(p.read_bytes()).hexdigest(), sequences=sep(p.read_bytes())) for p in paths]
    exe = (args.files / 'MAIN.EXE').read_bytes()
    result = dict(status='source_metadata_runtime_loops_not_yet_accepted', main_exe_sha256=hashlib.sha256(exe).hexdigest(), banks=banks, commands=command_table(exe))
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + '\n')
    print(f"{len(banks)} banks, {sum((len(b['sequences']) for b in banks))} sequences; 36 dispatch entries")
if __name__ == '__main__':
    main()
