"""Verify the PSX first-stage remix continues through the glider introduction."""
import argparse, csv, hashlib, json
from pathlib import Path
import numpy as np
from scipy import signal
from strider_psx_xa_catalog import ROOT, read_mono, feature

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--work', type=Path, default=ROOT / 'cpsplus/work/strider')
    p.add_argument('--output', type=Path, required=True)
    a = p.parse_args()
    run = a.work / 'psx/remix_game_start'
    assert 'Average speed:' in (run / 'run.log').read_text()
    trace = list(csv.DictReader((run / 'psu_trace.tsv').open(), delimiter='\t'))
    start = next((r for r in trace if r['kind'] == 'sound_state' and int(r['frame']) > 6000 and (r['label'] == 'remix=1,bank=0,seq=0,xa=0,xa_active=0')))
    sep = (a.work / 'sources/psx/files/SOUND/BGM/BGM_ST1R.SEP').read_bytes()
    ram = []
    for frame in [6400, 9000]:
        path = next(run.glob(f'psu_{frame}_*_ram.bin'))
        b = path.read_bytes()
        assert b[317156] == 1 and b[317267] == 0 and (b[317904] == 0) and (b.find(sep) >= 0)
        ram.append(dict(file=str(path.absolute().relative_to(ROOT)), sha256=hashlib.sha256(b).hexdigest(), sep_offset=b.find(sep)))
    source = feature(read_mono(a.work / 'review/audio_v2/psx_01_source.wav', 0, 45))
    rows = []
    for elapsed in [1, 4, 7, 10, 15]:
        x = feature(read_mono(run / 'audio.wav', float(start['time']) + elapsed, 2.5))
        n = x.shape[1]
        scores = np.zeros(source.shape[1] - n + 1)
        for s, t in zip(source, x):
            scores += signal.correlate(s, t, 'valid', method='fft')
        j = int(np.argmax(scores))
        matched = j * 128 / 5512
        score = float(scores[j] / n)
        assert abs(matched - elapsed) < 0.1 and score > 0.9, (elapsed, matched, score)
        rows.append(dict(game_elapsed_seconds=elapsed, source_match_seconds=matched, spectral_match=score))
    with (run / 'audio.wav').open('rb') as f:
        h = hashlib.file_digest(f, 'sha256').hexdigest()
    result = dict(status='intro_continuation_verified_only', native_audio_sha256=h, sequence_start_frame=int(start['frame']), sequence_start_seconds=float(start['time']), ram_checks=ram, reference_search_first_seconds=45, rows=rows, limit='First-stage intro-to-gameplay only; other stage transitions and final scenes remain open.')
    a.output.parent.mkdir(parents=True, exist_ok=True)
    a.output.write_text(json.dumps(result, indent=2) + '\n')
    print('PSX remix intro continuation: RAM identity plus five advancing audio excerpts pass')
if __name__ == '__main__':
    main()
