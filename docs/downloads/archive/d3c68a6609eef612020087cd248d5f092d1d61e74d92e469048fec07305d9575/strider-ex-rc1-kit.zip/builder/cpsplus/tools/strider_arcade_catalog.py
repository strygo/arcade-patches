"""Match isolated Strider YM2151 captures to the preserved arcade VGM dump."""
import argparse
from collections import defaultdict
import csv
import gzip
import hashlib
import json
from pathlib import Path

def vgm_events(path):
    data = gzip.decompress(path.read_bytes())
    if data[:4] != b'Vgm ':
        raise ValueError(f'not VGM: {path}')
    version = int.from_bytes(data[8:12], 'little')
    pos = 52 + int.from_bytes(data[52:56], 'little') if version >= 336 else 64
    if pos == 52:
        pos = 64
    time, out = (0, [])
    while pos < len(data):
        op = data[pos]
        pos += 1
        if op == 102:
            return out
        if op == 84:
            out.append((time / 44100, data[pos], data[pos + 1]))
            pos += 2
        elif op == 97:
            time += int.from_bytes(data[pos:pos + 2], 'little')
            pos += 2
        elif op in (98, 99):
            time += 735 if op == 98 else 882
        elif 112 <= op <= 127:
            time += op - 112 + 1
        elif op == 103:
            if data[pos] != 102:
                raise ValueError('invalid VGM data block')
            size = int.from_bytes(data[pos + 2:pos + 6], 'little')
            pos += 6 + size
        elif op in (79, 80):
            pos += 1
        elif 81 <= op <= 95 or 160 <= op <= 191:
            pos += 2
        elif 192 <= op <= 223:
            pos += 3
        elif op in (224, 225):
            pos += 4
        else:
            raise ValueError(f'unsupported VGM opcode {op:02x}')
    raise ValueError('missing VGM end')

def read_events(path):
    by_command = defaultdict(list)
    for row in csv.DictReader(path.open(), delimiter='\t'):
        command = int(row['cmd'])
        if row['kind'] == 'ym' and 0 <= command < 240:
            by_command[command].append((float(row['time']), int(row['addr'], 16), int(row['data'], 16)))
    if not by_command:
        raise ValueError('no YM events; check tap lifetime')
    return by_command

def pitches(events):
    channels = [bytearray() for _ in range(8)]
    for time, address, data in events:
        if 40 <= address <= 47:
            channel = channels[address - 40]
            if not channel or channel[-1] != data:
                channel.append(data)
    return list(map(bytes, channels))

def pitch_score(query, reference):
    count = total = 0
    for q, ref in zip(pitches(query), pitches(reference)):
        windows = [q[i:i + 6] for i in range(len(q) - 5)]
        count += sum((window in ref for window in windows))
        total += len(windows)
    return (count / total if total else 0, total)

def keyons(events):
    pitch = [0] * 8
    last = [None] * 8
    out = [[] for _ in range(8)]
    for time, address, data in events:
        if 40 <= address <= 47:
            pitch[address - 40] = data
        if address == 8 and data & 120:
            channel = data & 7
            if last[channel] is not None:
                out[channel].append((pitch[channel], round((time - last[channel]) * 100)))
            last[channel] = time
    return out

def rhythm_error(query, reference):
    errors = []
    for q, ref in zip(keyons(query), keyons(reference)):
        size = min(20, len(q), len(ref))
        if size < 5:
            continue
        errors.append(min((sum(((0 if q[i][0] == ref[i + start][0] else 10) + abs(q[i][1] - ref[i + start][1]) / 10 for i in range(size))) / size for start in range(len(ref) - size + 1))))
    return sum(errors) / len(errors) if errors else 99

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--vgm-dir', type=Path, required=True)
    p.add_argument('--events', type=Path, required=True)
    p.add_argument('--compare-events', type=Path)
    p.add_argument('--output', type=Path, required=True)
    args = p.parse_args()
    refs = {path.name: vgm_events(path) for path in sorted(args.vgm_dir.glob('*.vgz'))}
    if len(refs) != 33:
        p.error('expected 33 reference VGMs')
    queries = read_events(args.events)
    comparison = read_events(args.compare_events) if args.compare_events else None
    rows = []
    for command, query in sorted(queries.items()):
        ranked = sorted(((pitch_score(query, ref)[0], name) for name, ref in refs.items()), reverse=True)
        score, name = ranked[0]
        windows = pitch_score(query, refs[name])[1]
        if windows >= 5:
            if score < 0.9 or score - ranked[1][0] < 0.5:
                raise ValueError(f'ambiguous pitch match for {command:02x}: {ranked[:2]}')
            evidence = dict(method='per_channel_six_pitch_windows', match_fraction=score, windows=windows, runner_up_fraction=ranked[1][0])
        else:
            timing = sorted(((rhythm_error(query, ref), name) for name, ref in refs.items()))
            error, name = timing[0]
            if error >= 0.1 or timing[1][0] - error < 1:
                raise ValueError(f'ambiguous rhythm match for {command:02x}: {timing[:2]}')
            evidence = dict(method='per_channel_timed_keyons', error=error, runner_up_error=timing[1][0])
        row = dict(command=f'0x{command:02x}', vgm=name, evidence=evidence)
        if comparison is not None:
            same = pitches(query) == pitches(comparison[command])
            error = rhythm_error(comparison[command], refs[name])
            if not same or (windows < 5 and error >= 0.1) or (windows >= 5 and pitch_score(comparison[command], refs[name])[0] < 0.9):
                raise ValueError(f'regional tune mismatch at {command:02x}: pitch={same}, rhythm={error}')
            row['japan_same_pitch_sequence'] = same
            row['japan_reference_match_fraction'] = pitch_score(comparison[command], refs[name])[0] if windows >= 5 else None
            if windows < 5:
                row['japan_rhythm_error'] = error
        rows.append(row)
    result = dict(status='isolated_identity_only_scene_census_pending', commands=rows, events_sha256=hashlib.sha256(args.events.read_bytes()).hexdigest(), comparison_sha256=hashlib.sha256(args.compare_events.read_bytes()).hexdigest() if args.compare_events else None)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + '\n')
    print(f'{len(rows)} unique command identities verified' + (' in USA and Japan' if comparison else ''))
if __name__ == '__main__':
    main()
