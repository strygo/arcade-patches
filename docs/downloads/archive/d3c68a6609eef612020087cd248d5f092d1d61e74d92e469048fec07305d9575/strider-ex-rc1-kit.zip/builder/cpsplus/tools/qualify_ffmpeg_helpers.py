"""Exercise media formats and ffprobe required by standalone CPS+ builders."""
import argparse
import hashlib
import json
from pathlib import Path
import platform
import re
import struct
import subprocess
import tempfile

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def run(binary, args, data=None):
    return subprocess.run([str(binary), *args], input=data, capture_output=True, check=True).stdout

def main():
    p = argparse.ArgumentParser(description=__doc__)
    for name in ('ffmpeg', 'ffprobe', 'record'):
        p.add_argument('--' + name, required=True, type=Path)
    a = p.parse_args()
    ff = a.ffmpeg.resolve()
    probe = a.ffprobe.resolve()
    version = run(ff, ['-version']).decode().splitlines()[0]
    license_text = ' '.join(run(ff, ['-L']).decode().split())
    if 'GNU Lesser General Public License' not in license_text:
        raise ValueError('Unexpected media-tool license')
    for binary in (ff, probe):
        if '9.0.2' not in run(binary, ['-version']).decode().splitlines()[0]:
            raise ValueError('Unexpected FFmpeg version')
    for mode, names in (('-decoders', ('adpcm_adx', 'adpcm_xa', 'mp3', 'flac', 'pcm_s16le')), ('-encoders', ('adpcm_adx', 'flac', 'pcm_s16le', 'pcm_s24le')), ('-filters', ('aresample', 'atrim', 'afade', 'volume', 'concat', 'pan', 'alimiter'))):
        output = run(ff, ['-hide_banner', mode]).decode()
        if any((not re.search('\\s' + re.escape(name) + '\\s', output) for name in names)):
            raise ValueError('Missing CPS+ feature: ' + mode)
    cases = []
    with tempfile.TemporaryDirectory() as temporary:
        root = Path(temporary)
        for width in (2, 3):
            fmt = 's16le' if width == 2 else 's24le'
            pcm = b''.join(((i * 37 % 12000 - 6000).to_bytes(width, 'little', signed=True) for i in range(64000)))
            f = root / (fmt + '.flac')
            run(ff, ['-v', 'error', '-f', fmt, '-ar', '32000', '-ac', '2', '-i', 'pipe:0', '-metadata', 'LOOPSTART=32', '-metadata', 'LOOPEND=16000', str(f)], pcm)
            decoded = run(ff, ['-v', 'error', '-i', str(f), '-f', fmt, 'pipe:1'])
            if decoded != pcm:
                raise ValueError('FLAC did not round-trip ' + fmt)
            info = json.loads(run(probe, ['-v', 'error', '-show_streams', '-show_format', '-of', 'json', str(f)]))
            stream = info['streams'][0]
            tags = {k.upper(): v for k, v in info['format']['tags'].items()}
            if stream['sample_rate'] != '32000' or stream['channels'] != 2 or tags['LOOPSTART'] != '32' or (tags['LOOPEND'] != '16000'):
                raise ValueError('ffprobe lost rate, channel or loop metadata')
            cases.append(dict(format=fmt, lossless_round_trip=True, probe_and_loop_tags=True))
    result = dict(schema=1, status='passed', version=version, license='LGPL-2.1-or-later', ffmpeg_sha256=sha(ff), ffprobe_sha256=sha(probe), system=platform.platform(), machine=platform.machine(), cases=cases, cpsplus_codec_and_filter_inventory=True, recipe_sha256=sha(Path(__file__)))
    a.record.parent.mkdir(parents=True, exist_ok=True)
    a.record.write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
    print('PASS CPS+ media formats, loop tags, ffprobe, codecs and filters', flush=True)
if __name__ == '__main__':
    main()
