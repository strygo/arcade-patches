"""Rhythm-signature comparison, WAV vs WAV, as a full matrix."""
from __future__ import annotations
import argparse, array, glob, sys, wave
import numpy as np
LAG_LO, LAG_HI = (0.2, 2.0)
ENV_RATE = 100

def load_mono(path: str) -> tuple[np.ndarray, int]:
    w = wave.open(path)
    sr, ch, n = (w.getframerate(), w.getnchannels(), w.getnframes())
    raw = w.readframes(n)
    w.close()
    a = array.array('h')
    a.frombytes(raw)
    x = np.asarray(a, dtype=np.float64)
    if ch > 1:
        x = x.reshape(-1, ch).mean(axis=1)
    return (x, sr)

def onset_ac(x: np.ndarray, sr: int, skip: float, seg: float) -> np.ndarray | None:
    x = x[int(skip * sr):]
    if seg:
        x = x[:int(seg * sr)]
    hop = max(sr // ENV_RATE, 1)
    m = x.size // hop * hop
    if m < ENV_RATE * 8 * hop // hop:
        pass
    if m == 0:
        return None
    e = np.sqrt((x[:m].reshape(-1, hop) ** 2).mean(axis=1) + 1e-09)
    if len(e) < int(LAG_HI * ENV_RATE) * 2:
        return None
    d = np.maximum(np.diff(np.log10(e + 1e-06)), 0)
    d = d - d.mean()
    ac = np.correlate(d, d, 'full')[d.size - 1:]
    ac = ac / (ac[0] + 1e-12)
    lo, hi = (int(LAG_LO * ENV_RATE), int(LAG_HI * ENV_RATE))
    sig = ac[lo:hi]
    sig = (sig - sig.mean()) / (sig.std() + 1e-12)
    return sig

def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--a', required=True)
    ap.add_argument('--b', required=True)
    ap.add_argument('--out', required=True)
    ap.add_argument('--a-skip', type=float, default=0.0)
    ap.add_argument('--b-skip', type=float, default=0.0)
    ap.add_argument('--seg', type=float, default=40.0, help='analysis window length after skip (0 = all)')
    ap.add_argument('--top', type=int, default=3)
    a = ap.parse_args(argv)
    A = sorted(glob.glob(a.a))
    B = sorted(glob.glob(a.b))
    print(f'# A={len(A)}  B={len(B)}  lags {LAG_LO}-{LAG_HI}s')
    sigs_b = {}
    for fb in B:
        x, sr = load_mono(fb)
        sigs_b[fb] = onset_ac(x, sr, a.b_skip, a.seg)
    rows = []
    for fa in A:
        x, sr = load_mono(fa)
        sa = onset_ac(x, sr, a.a_skip, a.seg)
        if sa is None:
            continue
        scored = []
        for fb, sb in sigs_b.items():
            if sb is None:
                continue
            r = float(np.corrcoef(sa, sb)[0, 1])
            scored.append((r, fb))
        scored.sort(reverse=True)
        for r, fb in scored[:a.top]:
            rows.append((fa.split('/')[-1], fb.split('/')[-1], r))
        if scored:
            print(f"  {fa.split('/')[-1]:14s} best r={scored[0][0]:+.3f} -> {scored[0][1].split('/')[-1]}")
    with open(a.out, 'w') as f:
        f.write('a\tb\trhythm_r\n')
        for fa, fb, r in rows:
            f.write(f'{fa}\t{fb}\t{r:.4f}\n')
    print(f'wrote {a.out} ({len(rows)} rows)')
    return 0
if __name__ == '__main__':
    sys.exit(main())
