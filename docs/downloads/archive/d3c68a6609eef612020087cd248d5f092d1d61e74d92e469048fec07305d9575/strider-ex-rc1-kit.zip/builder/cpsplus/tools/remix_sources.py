"""Source readers and alignment for the Double Impact / HD Remix packs."""
from __future__ import annotations
from pathlib import Path
import struct
import sys
import tempfile
import zlib
import numpy as np
from scipy import signal
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from pack.album_audio import RATE, sha256, decode

def fpg_entry(path, index):
    with open(path, 'rb') as f:
        assert f.read(4) in (b'30GF', b'FG03')
        count = struct.unpack('<I', f.read(4))[0]
        if not 0 <= index < count:
            raise ValueError('FPG index outside table')
        f.seek(4096 + index * 16)
        h, off, stored, real = struct.unpack('<IIII', f.read(16))
        f.seek(off)
        b = f.read(stored)
        if len(b) != stored:
            raise ValueError('truncated FPG entry')
        b = zlib.decompress(b) if b[:2] == b'x\x9c' else b[:real]
        if len(b) != real:
            raise ValueError('FPG expanded size mismatch')
        return (b, h)

def msf_info(b):
    if b[:4] != b'MSFC':
        raise ValueError('expected remix MSFC stream')
    codec, ch, size, rate, flags, start, length = struct.unpack_from('>7I', b, 4)
    frame_bytes = 192 if codec == 4 else 304
    if ch != 2 or codec not in (4, 5) or size % frame_bytes or (len(b) != size + 64):
        raise ValueError('unsupported MSFC layout')
    n = size // frame_bytes * 1024
    loop = bool(flags & 16)
    ls = start // frame_bytes * 1024 if flags & 1 else 0
    le = (start + length) // frame_bytes * 1024 if flags & 1 else n
    return dict(rate=rate, samples=n, loop=loop, loop_start=ls, loop_end=le, flags=flags)

def riff_chunks(b):
    if b[:4] != b'RIFF' or b[8:12] != b'WAVE':
        raise ValueError('expected RIFF WAVE')
    chunks = {}
    pos = 12
    while pos + 8 <= len(b):
        key = b[pos:pos + 4]
        n = struct.unpack_from('<I', b, pos + 4)[0]
        chunks[key] = b[pos + 8:pos + 8 + n]
        pos += 8 + n + (n & 1)
    return chunks

def bits(b, pos, n):
    lo = pos // 8
    hi = (pos + n + 7) // 8
    if pos < 0 or hi > len(b):
        raise ValueError('truncated XMA bitstream')
    return int.from_bytes(b[lo:hi], 'big') >> hi * 8 - pos - n & (1 << n) - 1

def xma1_info(b):
    chunks = riff_chunks(b)
    f = chunks[b'fmt ']
    data = chunks[b'data']
    if struct.unpack_from('<H', f)[0] != 357 or struct.unpack_from('<H', f, 8)[0] != 1:
        raise ValueError('expected single-stream XMA1')
    rate, ls, le = struct.unpack_from('<III', f, 16)
    sub = f[28]
    found = {}
    frames = 0
    off = 0
    skip_start = 0
    while off < len(data):
        base = off * 8
        first = bits(data, base + 6, 15)
        skip = bits(data, base + 21, 11)
        off += 2048
        if skip & 1792 == 256:
            skip &= ~256
        if skip in (2047, 255):
            continue
        if skip:
            raise ValueError('unexpected interleaved XMA1 stream')
        p = 32 + first
        while p < 16384:
            pos = base + p
            size = bits(data, pos, 15)
            if size in (0, 32767):
                break
            found[pos] = frames * 512
            if frames == 0:
                q = pos + 30
                if bits(data, q, 1):
                    q += 1
                    if bits(data, q, 1):
                        q += 17
                q += 1
                if bits(data, q, 1):
                    q += 1
                    if bits(data, q, 1):
                        skip_start = min(bits(data, q + 1, 10), 512)
            frames += 1
            p += size
            if p < 16384 and (not bits(data, base + p - 1, 1)):
                break
    loop = bool(f[10])
    start = end = 0
    if loop:
        if ls not in found or le not in found:
            raise ValueError('XMA loop bit is not a frame boundary')
        start = found[ls] + (sub & 15) * 128 + 128 - skip_start
        end = found[le] + (sub >> 4) * 128 + 128 - skip_start
        if not 0 <= start < end:
            raise ValueError('invalid XMA loop')
    return dict(rate=rate, samples=frames * 512 + 128 - skip_start, loop=loop, loop_start=start, loop_end=end, skip_start=skip_start, loop_start_bits=ls, loop_end_bits=le, subframes=sub)

def decode_blob(blob, suffix):
    with tempfile.NamedTemporaryFile(suffix=suffix) as f:
        f.write(blob)
        f.flush()
        return decode(f.name)

def ncc(a, b):
    a = a.astype(float).ravel()
    b = b.astype(float).ravel()
    a -= a.mean()
    b -= b.mean()
    return float(a @ b / (np.linalg.norm(a) * np.linalg.norm(b) + 1e-20))

def spectral_features(pcm):
    x = signal.resample_poly(pcm.astype(float).mean(axis=1), 1, 6)
    _, _, z = signal.stft(x, fs=8000, nperseg=512, noverlap=448, boundary=None)
    edges = np.unique(np.geomspace(2, 250, 49).astype(int))
    a = np.array([np.log1p(np.abs(z[l:r]).mean(axis=0)) for l, r in zip(edges[:-1], edges[1:])])
    return a - a.mean(axis=1, keepdims=True)

def spectral_alignment(album, reference, points=None):
    """Locate five reference windows in the album, retaining every observation."""
    a = spectral_features(album)
    b = spectral_features(reference)
    step = 384
    width = min(250, b.shape[1] // 3, a.shape[1] // 3)
    if width < 40:
        return []
    out = []
    positions = np.linspace(0, max(0, min(a.shape[1], b.shape[1]) - width - 250), 7).astype(int)
    if points is not None:
        positions = np.array([min(max(0, int(p / step) - width // 2), b.shape[1] - width) for p in points])
    for pos in np.unique(positions):
        q = b[:, pos:pos + width]
        q = q - q.mean(axis=1, keepdims=True)
        corr = sum((signal.correlate(a[i], q[i], mode='valid', method='fft') for i in range(len(a))))
        energy = sum((signal.convolve(a[i] ** 2, np.ones(width), mode='valid', method='fft') - signal.convolve(a[i], np.ones(width), mode='valid', method='fft') ** 2 / width for i in range(len(a))))
        score = corr / np.sqrt(np.maximum(energy, 1e-15) * (q * q).sum())
        lo = min(len(score) - 1, max(0, int(pos) - 250))
        hi = min(len(score), int(pos) + 250)
        loc = lo + int(score[lo:hi].argmax())
        out.append(dict(reference_sample=int(pos * step), album_sample=loc * step, offset=(loc - int(pos)) * step, score=round(float(score[loc]), 5)))
    return out

def waveform_offset(album, ref, approx=0, at=2.0, seconds=5.0, radius=0.08):
    """Fine displacement: album coordinate = reference coordinate + offset."""
    pos = int(at * RATE)
    width = min(int(seconds * RATE), len(ref) - pos)
    if width <= 100:
        raise ValueError('short alignment reference')
    q = ref[pos:pos + width].astype(float).mean(axis=1)
    q -= q.mean()
    lo = max(0, pos + int(approx - radius * RATE))
    hi = min(len(album) - width, pos + int(approx + radius * RATE))
    if hi < lo:
        raise ValueError('no alignment search window')
    x = album[lo:hi + width].astype(float).mean(axis=1)
    c = signal.correlate(x, q, mode='valid', method='fft')
    e = signal.convolve(x * x, np.ones(width), mode='valid', method='fft')
    scores = c / np.sqrt(np.maximum(e, 1e-15) * (q * q).sum())
    i = int(scores.argmax())
    return (lo + i - pos, float(scores[i]))

def self_test():
    assert bits(bytes.fromhex('a5f0'), 4, 8) == 95

    def put(b, p, n, v):
        for i in range(n):
            if v & 1 << n - 1 - i:
                b[(p + i) // 8] |= 1 << 7 - (p + i) % 8
    data = bytearray(2048)
    put(data, 4, 2, 2)
    put(data, 32, 15, 80)
    put(data, 111, 1, 1)
    put(data, 112, 15, 80)
    fmt = bytearray(32)
    struct.pack_into('<H', fmt, 0, 357)
    struct.pack_into('<H', fmt, 8, 1)
    fmt[10] = 255
    struct.pack_into('<III', fmt, 16, 48000, 32, 112)
    fmt[29] = 2

    def riff(f):
        body = b'WAVEfmt ' + struct.pack('<I', len(f)) + f + b'data' + struct.pack('<I', len(data)) + data
        return b'RIFF' + struct.pack('<I', len(body)) + body
    info = xma1_info(riff(fmt))
    assert (info['loop_start'], info['loop_end'], info['samples']) == (128, 640, 1152)
    struct.pack_into('<I', fmt, 20, 33)
    try:
        xma1_info(riff(fmt))
    except ValueError:
        pass
    else:
        raise AssertionError('unaligned XMA loop bit accepted')
    for codec, frame in [(4, 192), (5, 304)]:
        b = b'MSFC' + struct.pack('>7I', codec, 2, frame * 100, 48000, 81, frame * 10, frame * 90) + bytes(32 + frame * 100)
        info = msf_info(b)
        assert (info['samples'], info['loop_start'], info['loop_end']) == (102400, 10240, 102400)
    noise = np.random.default_rng(42).integers(-16000, 16000, (48000 * 4, 2), dtype=np.int16)
    shifted = np.concatenate([np.zeros((1056, 2), dtype=np.int16), noise])
    off, score = waveform_offset(shifted, noise, at=1, seconds=2)
    assert off == 1056 and score > 0.999
    print('remix source tests passed (MSF codecs, XMA frame/subframe loops, alignment)')
if __name__ == '__main__':
    import argparse
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--self-test', action='store_true')
    args = ap.parse_args()
    if args.self_test:
        self_test()
