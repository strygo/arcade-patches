"""Read-only reader for the 3DO "Opera" file system on a CD data track."""
from __future__ import annotations
import struct
import sys
from dataclasses import dataclass
from pathlib import Path
RAW = 2352
COOKED = 2048
SYNC = bytes([0]) + bytes([255] * 10) + bytes([0])

@dataclass
class Entry:
    path: str
    is_dir: bool
    size: int
    block_size: int
    blocks: int
    first_block: int
    type: bytes

class OperaError(ValueError):
    pass

class OperaFS:

    def __init__(self, image: Path | str):
        path = Path(image)
        if path.suffix.lower() == '.cue':
            sys.path.insert(0, str(Path(__file__).resolve().parent))
            from extract_cdda import cue_files
            path = cue_files(path)[0]
        self.path = path
        self.f = open(path, 'rb')
        head = self.f.read(16)
        self.raw = head[:12] == SYNC
        self.sector = RAW if self.raw else COOKED
        self.f.seek(0, 2)
        self.sectors = self.f.tell() // self.sector
        vol = self.read_sectors(0, 1)
        if vol[0] != 1 or vol[1:6] != b'ZZZZZ':
            raise OperaError(f'{path.name}: no Opera volume header at sector 0')
        self.block_size, self.block_count, _root_id, self.root_blocks, _root_bsize, last_copy = struct.unpack_from('>6I', vol, 76)
        self.label = vol[40:72].split(b'\x00')[0].decode('ascii', 'replace')
        self.root_block = struct.unpack_from('>I', vol, 100)[0]
        if self.block_size != COOKED:
            raise OperaError(f'block size {self.block_size}: only 2048 handled')
        self._entries: list[Entry] | None = None

    def close(self) -> None:
        self.f.close()

    def read_sectors(self, first: int, count: int) -> bytes:
        if first < 0 or first + count > self.sectors:
            raise OperaError(f'sectors {first}+{count} outside the image')
        if not self.raw:
            self.f.seek(first * COOKED)
            return self.f.read(count * COOKED)
        out = []
        for s in range(first, first + count):
            self.f.seek(s * RAW + 16)
            out.append(self.f.read(COOKED))
        return b''.join(out)

    def _dir(self, block: int, blocks: int, prefix: str):
        data = self.read_sectors(block, blocks)
        pos = 0
        while pos < len(data):
            nxt, _prev, _flags, _free, first = struct.unpack_from('>iiIII', data, pos)
            off = pos + first
            while True:
                flags, _id, typ, bsize, nbytes, nblocks, _burst, _gap = struct.unpack_from('>I I 4s I I I I I', data, off)
                name = data[off + 32:off + 64].split(b'\x00')[0].decode('ascii', 'replace')
                last_copy = struct.unpack_from('>I', data, off + 64)[0]
                copies = struct.unpack_from(f'>{last_copy + 1}I', data, off + 68)
                kind = flags & 255
                is_dir = kind == 7
                full = f'{prefix}/{name}'
                if kind in (2, 7):
                    e = Entry(full, is_dir, nbytes, bsize, nblocks, copies[0], typ)
                    yield e
                    if is_dir:
                        yield from self._dir(copies[0], max(nblocks, 1), full)
                off += 68 + 4 * (last_copy + 1)
                if flags & 2147483648 or flags & 1073741824:
                    break
            if nxt < 0 or nxt * COOKED >= len(data):
                break
            pos = nxt * COOKED

    def entries(self) -> list[Entry]:
        if self._entries is None:
            self._entries = list(self._dir(self.root_block, self.root_blocks, ''))
        return self._entries

    def find(self, path: str) -> Entry:
        for e in self.entries():
            if e.path.lower() == path.lower():
                return e
        raise FileNotFoundError(path)

    def read(self, entry: Entry | str) -> bytes:
        e = self.find(entry) if isinstance(entry, str) else entry
        blocks = -(-e.size // COOKED)
        return self.read_sectors(e.first_block, blocks)[:e.size]

def _build_test_image(raw: bool) -> bytes:
    """A two-file Opera volume with a subdirectory, built from the layout"""

    def entry(flags, name, typ, nbytes, nblocks, first):
        return struct.pack('>I I 4s I I I I I', flags, 0, typ, COOKED, nbytes, nblocks, 1, 0) + name.ljust(32, b'\x00') + struct.pack('>I I', 0, first)

    def dirblock(entries):
        body = b''.join(entries)
        hdr = struct.pack('>iiIII', -1, -1, 0, 20 + len(body), 20)
        return (hdr + body).ljust(COOKED, b'\x00')
    f1 = bytes(range(256)) * 10
    f2 = b'abcdefg'
    vol = bytearray(COOKED)
    vol[0] = 1
    vol[1:6] = b'ZZZZZ'
    vol[6] = 1
    vol[40:40 + 4] = b'TEST'
    struct.pack_into('>6I', vol, 76, COOKED, 6, 0, 1, COOKED, 0)
    struct.pack_into('>I', vol, 100, 1)
    root = dirblock([entry(2, b'ONE.BIN', b'\x00\x00\x00\x00', len(f1), 2, 3), entry(7, b'SUB', b'*dir', COOKED, 1, 2), entry(2 | 1073741824 | 2147483648, b'LAST.TXT', b'\x00\x00\x00\x00', 0, 0, 5)])
    sub = dirblock([entry(2 | 1073741824 | 2147483648, b'TWO.TXT', b'\x00\x00\x00\x00', len(f2), 1, 5)])
    sectors = [bytes(vol), root, sub, f1[:COOKED], f1[COOKED:].ljust(COOKED, b'\x00'), f2.ljust(COOKED, b'\x00')]
    if not raw:
        return b''.join(sectors)
    return b''.join((SYNC + b'\x00\x02\x00\x01' + s + bytes(288) for s in sectors))

def _self_test() -> None:
    import tempfile
    for raw in (False, True):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / 't.bin'
            p.write_bytes(_build_test_image(raw))
            fs = OperaFS(p)
            assert fs.raw is raw and fs.label == 'TEST'
            names = [(e.path, e.is_dir, e.size) for e in fs.entries()]
            assert names == [('/ONE.BIN', False, 2560), ('/SUB', True, 2048), ('/SUB/TWO.TXT', False, 7), ('/LAST.TXT', False, 0)], names
            assert fs.read('/one.bin') == bytes(range(256)) * 10
            assert fs.read('/SUB/TWO.TXT') == b'abcdefg'
            fs.close()
    print('opera_fs self-test OK')
if __name__ == '__main__':
    if '--self-test' in sys.argv:
        _self_test()
    elif len(sys.argv) >= 2:
        fs = OperaFS(sys.argv[1])
        print(f'{fs.label}: {fs.block_count} blocks')
        for e in fs.entries():
            print(f"{('d' if e.is_dir else 'f')} {e.size:>10} {e.path}")
    else:
        print(__doc__)
