"""Decode Capcom Saturn .MUS streams (SFZ2/SFZ2'/SFZ3/SPF2T family) to WAV."""
import sys, wave
import numpy as np
RATE = 32000

def decode(path, swap=False):
    """Return (n,2) little-endian s16 stereo frames."""
    d = np.fromfile(path, dtype=np.uint8)
    nb = len(d) // 4096
    blocks = d[:nb * 4096].reshape(nb, 4096)
    A = blocks[0::2].reshape(-1).view('>i2')
    B = blocks[1::2].reshape(-1).view('>i2')
    n = min(len(A), len(B))
    st = np.empty((n, 2), dtype='<i2')
    st[:, 0] = B[:n] if swap else A[:n]
    st[:, 1] = A[:n] if swap else B[:n]
    return st

def wav(path, data, rate=RATE):
    w = wave.open(path, 'wb')
    w.setnchannels(2)
    w.setsampwidth(2)
    w.setframerate(rate)
    w.writeframes(data.tobytes())
    w.close()
if __name__ == '__main__':
    args = sys.argv[1:]
    rate = RATE
    if args and args[0] == '--rate':
        rate = int(args[1])
        args = args[2:]
    if len(args) < 2:
        sys.exit(__doc__)
    out, ins = (args[0], args[1:])
    data = np.concatenate([decode(p) for p in ins], axis=0)
    wav(out, data, rate)
    print(f'{out}: {len(data)} frames = {len(data) / rate:.3f} s @ {rate} Hz stereo')
