"""Fetch the pinned snes_spc 0.9.0 sources and build tools/spc_harness."""
from __future__ import annotations
import argparse
import hashlib
import json
import shutil
import subprocess
import sys
from pathlib import Path
SNES_SPC_REPOSITORY = 'https://github.com/blarggs-audio-libraries/snes_spc.git'
SNES_SPC_COMMIT = 'ec8ee2bbe30451614c1d02a83f7af1c97d497d45'
SNES_SPC_FILES = {'snes_spc/SNES_SPC.cpp': 'ff58cfe6cb5e038fd0e9b9070620860bfd9a58a1a733fbda540689af386d9605', 'snes_spc/SNES_SPC.h': '8a4c9589c316afa3c2d371ebb1f80f9de349556ab46ed87b0e04682953db9f00', 'snes_spc/SNES_SPC_misc.cpp': 'd89d85fd584299360eb304219658f2b92121b5dd4e8a4089e1e7d4806c1a8d3e', 'snes_spc/SNES_SPC_state.cpp': '6af18978d82617f12b9830b87e06dd6c27f772b78de9d18a8ebbdf38d93309d2', 'snes_spc/SPC_CPU.h': '9894932d00bbe1c64be3cdc0c6a3d0423b55b5cd531e7e7b1bff25b5c4a04676', 'snes_spc/SPC_DSP.cpp': '42a48152675eaa772f3bd534122fa71c3d6adec9566d9f5f63e53a556849ac22', 'snes_spc/SPC_DSP.h': 'fc8a028699c9fb22983d4368fabd152d8396443ff021c2e6918ecefd2982a598', 'snes_spc/SPC_Filter.cpp': '34c6ab92475d5fd700c3e01bff7d2fe8e59f8d188a0719c1ad12141d905f62e8', 'snes_spc/SPC_Filter.h': 'a86f33de7fbaa1d448de8e3879c4619e1d9a30a494c5a9606d682cee8dd89bb9', 'snes_spc/blargg_common.h': '4bc17a19fe46de2860868d3f88c037aee718b4dedc61450a28de3d1336053dba', 'snes_spc/blargg_config.h': 'b318cfcd2828719d8e3435e4972bc75ba82697c2cc6b8d291130d66d7b6904b8', 'snes_spc/blargg_endian.h': '97062e15b46e1347a4fc2e95fd131bcb89c1b8947b28d20a27c1f342a387d637', 'snes_spc/blargg_source.h': 'bd6b376d6d9b1bccce3b89e915b1ad9a6fede7d43b273258bfa13c3855fb1a6a'}
HERE = Path(__file__).resolve().parent
HARNESS_SRC = HERE / 'spc_harness'
REPO = HERE.parents[1]
DEFAULT_ROOT = REPO / 'cpsplus' / 'work' / 'spc'
EXE = '.exe' if sys.platform == 'win32' else ''

class SetupError(RuntimeError):
    pass

def _run(command: list[str], cwd: Path | None=None) -> str:
    result = subprocess.run(command, cwd=cwd, text=True, capture_output=True)
    if result.returncode:
        details = '\n'.join((part for part in (result.stdout, result.stderr) if part))
        raise SetupError(f"command failed ({result.returncode}): {' '.join(command)}\n{details}")
    return result.stdout.strip()

def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()

def harness_digest() -> str:
    """One digest over the committed harness sources (what the stamp keys on)."""
    h = hashlib.sha256()
    for name in ('CMakeLists.txt', 'spc_harness.cpp'):
        h.update(name.encode() + b'\x00' + (HARNESS_SRC / name).read_bytes())
    return h.hexdigest()

def _checkout(path: Path) -> None:
    if not path.exists():
        _run(['git', 'clone', '--no-checkout', SNES_SPC_REPOSITORY, str(path)])
        _run(['git', 'checkout', '--detach', SNES_SPC_COMMIT], path)
    elif not (path / '.git').is_dir():
        raise SetupError(f'existing path is not a Git checkout: {path}')
    head = _run(['git', 'rev-parse', 'HEAD'], path)
    if head != SNES_SPC_COMMIT:
        raise SetupError(f'{path} is at {head}, expected {SNES_SPC_COMMIT}; move it aside')
    dirty = _run(['git', 'status', '--porcelain', '--untracked-files=no'], path)
    if dirty:
        raise SetupError(f'tracked files are modified in {path}; move it aside')
    for rel, want in SNES_SPC_FILES.items():
        got = _sha256(path / rel)
        if got != want:
            raise SetupError(f'{rel}: sha256 {got}, pinned {want}')

def paths(root: Path=DEFAULT_ROOT) -> dict[str, Path]:
    return {'source': root / 'upstream' / 'snes_spc', 'build': root / 'build', 'binary': root / 'build' / ('Release' if sys.platform == 'win32' else '') / f'spc_harness{EXE}', 'stamp': root / 'build' / 'stamp.json'}

def setup(root: Path=DEFAULT_ROOT) -> Path:
    p = paths(root)
    p['source'].parent.mkdir(parents=True, exist_ok=True)
    _checkout(p['source'])
    generator = [] if (p['build'] / 'CMakeCache.txt').is_file() else ['-G', 'Ninja'] if shutil.which('ninja') else []
    _run(['cmake', '-S', str(HARNESS_SRC), '-B', str(p['build']), *generator, '-DCMAKE_BUILD_TYPE=Release', f"-DSNES_SPC_DIR={p['source']}"])
    _run(['cmake', '--build', str(p['build']), '--config', 'Release'])
    if not p['binary'].is_file():
        raise SetupError(f"build succeeded but {p['binary']} is missing")
    stamp = {'snes_spc_commit': SNES_SPC_COMMIT, 'harness': harness_digest(), 'binary_sha256': _sha256(p['binary'])}
    p['stamp'].write_text(json.dumps(stamp, indent=1) + '\n')
    print(f"ready: {p['binary']}")
    return p['binary']

def ensure(root: Path=DEFAULT_ROOT) -> Path:
    """The harness binary, rebuilt first if anything it depends on changed."""
    p = paths(root)
    try:
        stamp = json.loads(p['stamp'].read_text())
        if stamp.get('snes_spc_commit') == SNES_SPC_COMMIT and stamp.get('harness') == harness_digest() and p['binary'].is_file() and (stamp.get('binary_sha256') == _sha256(p['binary'])):
            return p['binary']
    except (OSError, ValueError):
        pass
    return setup(root)

def self_test() -> None:
    assert len(SNES_SPC_COMMIT) == 40
    assert SNES_SPC_REPOSITORY.startswith('https://github.com/')
    assert all((len(v) == 64 for v in SNES_SPC_FILES.values())), 'unpinned source file'
    assert (HARNESS_SRC / 'spc_harness.cpp').is_file()
    assert len(harness_digest()) == 64
    print('setup_spc_tools self-test: OK')

def main(argv: list[str] | None=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('--self-test', action='store_true')
    parser.add_argument('--root', type=Path, default=DEFAULT_ROOT)
    args = parser.parse_args(argv)
    if args.self_test:
        self_test()
        return 0
    setup(args.root)
    return 0
if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except (OSError, SetupError) as exc:
        print(f'setup_spc_tools: error: {exc}', file=sys.stderr)
        raise SystemExit(1)
