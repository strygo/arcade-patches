"""Summarize bounded regional Strider stage-entry traces, not full playthroughs."""
import argparse, csv, hashlib, json
from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--work', type=Path, default=ROOT / 'cpsplus/work/strider')
    p.add_argument('--output', type=Path, required=True)
    a = p.parse_args()
    rows = []
    for machine in ['striderua', 'striderjr']:
        for scene, cmd, nxt in [('st_petersburg', 17, 0), ('siberia', 18, 6), ('aerial', 30, 24), ('amazon', 19, 10), ('third_moon', 31, 27)]:
            first = scene == 'st_petersburg'
            folder = ('live_start' if machine == 'striderua' else 'japan_live_start') if first else f'{machine}_{scene}_v2'
            run = a.work / 'native' / folder
            events = run / 'events.tsv'
            assert 'Average speed:' in (run / 'run.log').read_text()
            raw = list(csv.DictReader(events.open(), delimiter='\t'))
            commands = [r for r in raw if r['kind'] == 'host' and int(r['cmd']) < 48]
            intro = next((r for r in commands if int(r['cmd']) == cmd))
            stage = next((r for r in commands if int(r['cmd']) == nxt and float(r['time']) > float(intro['time'])))
            item = dict(machine=machine, scene=scene, intro_command=f'0x{cmd:02x}', next_command=f'0x{nxt:02x}', intro_frame=int(intro['frame']), next_frame=int(stage['frame']), intro_seconds=float(intro['time']), next_seconds=float(stage['time']), window_seconds=float(stage['time']) - float(intro['time']), assistance='none' if first else 'starting-stage immediate operand override at 0x253b; guarded ROM bytes, no other gameplay change', evidence=str(events.absolute().relative_to(ROOT)), sha256=hashlib.sha256(events.read_bytes()).hexdigest())
            rows.append(item)
    result = dict(status='stage_entries_verified_full_scene_census_pending', rows=rows, limits=['Four later stages use a documented stage-selection override; untouched transition checks remain.', 'Subarea, boss, ending and ranking scene timelines are incomplete.', 'Ending 0x21 has a verified native call site, not a completed runtime scene trace.'])
    a.output.parent.mkdir(parents=True, exist_ok=True)
    a.output.write_text(json.dumps(result, indent=2) + '\n')
    for r in rows:
        print(r['machine'], r['scene'], r['intro_command'], r['next_command'], round(r['window_seconds'], 6))
if __name__ == '__main__':
    main()
