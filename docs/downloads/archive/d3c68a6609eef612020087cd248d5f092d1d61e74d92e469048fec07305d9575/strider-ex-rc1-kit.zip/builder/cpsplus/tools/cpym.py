"""Capcom-Yamaha (CP_YM) 4-bit ADPCM decoder, per vgmstream yamaha_decoder.c."""
import sys, math, wave
import numpy as np
SCALE_STEP = [58982, 58982, 58982, 58982, 78643, 104858, 131072, 157286]

def decode_cpym_stereo(data, start=0, nbytes=None, state=None):
    """Returns (L, R, endstate). state = (histL, stepL, histR, stepR)."""
    if nbytes is None:
        nbytes = len(data) - start
    buf = data[start:start + nbytes]
    n = len(buf)
    L = np.empty(n, dtype=np.int32)
    R = np.empty(n, dtype=np.int32)
    histL, stepL, histR, stepR = state if state else (0, 128, 0, 128)
    for i in range(n):
        b = buf[i]
        code = b & 15
        ucode = code & 7
        delta = ucode * stepL >> 2
        if code & 8:
            delta = -delta
        s = histL + delta
        s = (s + 32768 & 65535) - 32768
        stepL = stepL * SCALE_STEP[ucode] >> 16
        if stepL < 128:
            stepL = 128
        elif stepL > 24576:
            stepL = 24576
        histL = s
        L[i] = 512 * s >> 8
        code = b >> 4 & 15
        ucode = code & 7
        delta = ucode * stepR >> 2
        if code & 8:
            delta = -delta
        s = histR + delta
        s = (s + 32768 & 65535) - 32768
        stepR = stepR * SCALE_STEP[ucode] >> 16
        if stepR < 128:
            stepR = 128
        elif stepR > 24576:
            stepR = 24576
        histR = s
        R[i] = 512 * s >> 8
    return (L, R, (histL, stepL, histR, stepR))

def metrics(x):
    xf = x.astype(np.float64)
    k = 801
    ma = np.convolve(xf, np.ones(k) / k, mode='same')
    hp = xf - ma
    drift = math.sqrt(np.mean(ma ** 2))
    hprms = math.sqrt(np.mean(hp ** 2))
    d = np.abs(np.diff(xf))
    m = np.mean(np.abs(xf)) or 1
    return (drift, hprms, np.mean(d) / m)

def main():
    cmd = sys.argv[1]
    path = sys.argv[2]
    data = open(path, 'rb').read()
    if cmd == 'analyze':
        nb = min(len(data), 400000)
        L, R, st = decode_cpym_stereo(data, 0, nb)
        dL, hL, sL = metrics(L)
        dR, hR, sR = metrics(R)
        corr = np.corrcoef(L.astype(np.float64), R.astype(np.float64))[0, 1]
        print(f'{path}: {len(data)} bytes = {len(data)} stereo samples = {len(data) / 24000:.2f}s @24kHz')
        print(f'L: drift={dL:.0f} hp={hL:.0f} smooth={sL:.3f}   R: drift={dR:.0f} hp={hR:.0f} smooth={sR:.3f}   L/R corr={corr:+.3f}')
        print(f'L clip%={np.mean(np.abs(L) > 32000) * 100:.2f} R clip%={np.mean(np.abs(R) > 32000) * 100:.2f}')
        print(f'peak L={np.max(np.abs(L))} R={np.max(np.abs(R))}')
    elif cmd == 'decode':
        out = sys.argv[3]
        rate = int(sys.argv[4]) if len(sys.argv) > 4 else 24000
        nb = int(sys.argv[5]) if len(sys.argv) > 5 else None
        L, R, st = decode_cpym_stereo(data, 0, nb)
        inter = np.empty(L.size * 2, dtype=np.int16)
        inter[0::2] = np.clip(L, -32768, 32767).astype(np.int16)
        inter[1::2] = np.clip(R, -32768, 32767).astype(np.int16)
        w = wave.open(out, 'wb')
        w.setnchannels(2)
        w.setsampwidth(2)
        w.setframerate(rate)
        w.writeframes(inter.tobytes())
        w.close()
        print(f'wrote {out}: {L.size} samples = {L.size / rate:.2f}s @{rate}')
    elif cmd == 'loopcheck':
        ls = int(sys.argv[3])
        L, R, st = decode_cpym_stereo(data)
        segL_end = L[-16:]
        segL_start = L[ls:ls + 16]
        print('tail L:', segL_end.tolist())
        print('loop-start L:', segL_start.tolist())
        d_body = np.mean(np.abs(np.diff(L[ls:ls + 24000])))
        jump = abs(int(L[ls]) - int(L[-1]))
        print(f'junction jump={jump} vs mean delta near loop start={d_body:.0f}')
        print(f'tail 0.25s RMS={math.sqrt(np.mean(L[-6000:].astype(np.float64) ** 2)):.0f}, body RMS={math.sqrt(np.mean(L[ls:ls + 24000].astype(np.float64) ** 2)):.0f}')
if __name__ == '__main__':
    main()
