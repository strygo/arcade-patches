"""Measure remix source alignment; emit reviewable, reproducible audio recipes."""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import re
import sys
import numpy as np
from remix_sources import RATE, decode, decode_blob, fpg_entry, msf_info, xma1_info, sha256, spectral_alignment, waveform_offset
ROOT = Path(__file__).resolve().parents[2]
DI = ROOT / 'roms/soundtracks/final_fight_double_impact_remixed_soundtrack_2010'
HDR = ROOT / 'roms/soundtracks/ssf2t_hd_remix_ocremix_ost'
PS3 = ROOT / 'cpsplus/work/ps3'
FF = {64: 'Level 1-1&Main Menu', 65: 'Level 1-2', 66: 'Level 2-1', 67: 'Level 2-2', 68: 'z_Andore Wrestling Ring', 69: 'z_Bonus Track', 70: 'Level 5-1b', 71: 'Level 5-1c', 72: 'Level 4-1', 73: 'Level 4-2', 76: 'z_Bonus Stage', 80: 'z_Game Start', 81: 'z_Game Over', 82: 'Level 5-1a', 83: 'z_Continue On', 84: 'z_End Credits', 85: 'z_Character Select', 87: 'Stage Clear', 88: 'z_Game Clear'}
MS = ['Priestly Charge', 'Release the Hounds', 'Play It Again Big Man', 'Renewed Hope', 'Thieves Guild', 'The Lizardman Cometh', 'No Escape', 'Knights March', 'Raise the Gate', 'The Scryer', 'Main_Menu', 'Trouble From Afar', 'Battle Charge', 'Tears for Alan', 'Amazonian Goddesses', 'Onwards and Upwards', 'Drokmars Revenge', 'Eternal Struggle', 'Sanctuary', 'Refuge', 'Trust No One', 'Sword of Magic', 'The Black Orb', 'Level Clear']
ORDER = [1, 2, 3, 4, 5, 6, 7, 8, 10, 12, 11, 9, 13, 14, 15, 16]
STAGES = {1: 9, 2: 6, 3: 13, 4: 16, 5: 21, 6: 24, 7: 27, 8: 30, 9: 58, 10: 49, 11: 55, 12: 52, 13: 37, 14: 43, 15: 34, 16: 40}
ENDINGS = {33: 12, 34: 11, 35: 8, 36: 15, 37: 18, 38: 19, 39: 23, 40: 26, 41: 29, 42: 32, 43: 60, 44: 51, 45: 57, 46: 54, 47: 39, 48: 45, 49: 36, 50: 42, 62: 20}
UI = {51: 1, 52: 3, 53: 5, 54: 46, 55: 47, 56: 48, 57: 65, 58: 66, 60: 64, 211: 3, 212: 1}

def unique(paths):
    paths = list(paths)
    if len(paths) != 1:
        raise ValueError(f'expected one source, found {paths}')
    return paths[0]

def di_rows(game):
    table = FF if game == 'ff' else dict(enumerate(MS)) | {27: 'Triumph'}
    out = []
    for cmd, title in table.items():
        event = cmd
        src = unique(DI.rglob(f'{game}_{title}.mp3'))
        ref = unique((PS3 / 'ffdi_usa/msf').glob(f'{game}_event_{event:04x}_*enh.msf'))
        blob = ref.read_bytes()
        info = msf_info(blob)
        album = decode(src)
        pcm = decode_blob(blob, '.msf')
        witness = unique((PS3 / 'x360/di/xma').glob(f'{game}_event_{event:04x}_*enh.xma2'))
        xpcm = decode(witness)
        observations = []
        for t in [1.0, max(1.0, len(pcm) / RATE * 0.45), max(1.0, len(pcm) / RATE - 5)]:
            off, score = waveform_offset(album, xpcm, at=t, seconds=min(3, len(xpcm) / RATE - t))
            observations.append(dict(at=t, offset=off, score=round(score, 5)))
        offset = int(np.median([r['offset'] for r in observations]))
        trim = max(0, offset)
        count = min(info['samples'], len(album) - trim)
        loops = '_loop_' in ref.name
        if game == 'ms':
            loops = cmd in set(range(2, 17)) | {21}
        cue_title = 'Opening / intro' if game == 'ff' and cmd == 82 else title
        row = dict(cmd=cmd, title=cue_title, album_title=title, source=str(src.relative_to(DI)), source_sha256=sha256(src), reference=ref.name, reference_sha256=sha256(ref), disc=info, alignment=observations, witness=witness.name, witness_sha256=sha256(witness), trim_start=trim, keep_samples=count, loop_start=0, loop_end=count // 32 * 32 if loops else 0, loop_count=0, xfade_samples=0, status='listening_pending')
        out.append(row)
        print(game, hex(cmd), title, observations, flush=True)
    return out

def hdr_rows(previous=None):
    sys.path.insert(0, str(ROOT / 'cpsplus'))
    from pack.build_ffight_ost import index_ost
    index = index_ost(HDR, default_disc=1)
    refs = {c: 5339 + 2 * ORDER.index(c) for c in ORDER}
    refs |= {c + 16: 5371 + 2 * ORDER.index(c) for c in ORDER}
    end_order = [34, 35, 36, 37, 38, 39, 40, 41, 42, 44, 46, 45, 43, 47, 48, 49, 50]
    refs |= {c: 5403 + 2 * i for i, c in enumerate(end_order)}
    refs |= {52: 321, 211: 321, 60: 5447, 62: 5449}
    table = STAGES | {c + 16: t + 1 for c, t in STAGES.items()} | ENDINGS | UI
    out = []
    cache = {}
    for cmd, tr in sorted(table.items()):
        prior = next((r for r in previous or [] if r['cmd'] == cmd), None)
        if prior is not None:
            out.append(prior)
            yield out
            continue
        src = index[1, tr]
        album = decode(src)
        title = src.stem
        row = dict(cmd=cmd, album_track=tr, title=title, source=str(src.relative_to(HDR)), source_sha256=sha256(src), trim_start=0, keep_samples=len(album), loop_start=0, loop_end=0, loop_count=0, xfade_samples=0, status='listening_pending')
        if cmd in refs:
            idx = refs[cmd]
            psb, _ = fpg_entry(PS3 / 'hdr/out/USRDIR/flog_ps3.fpg', idx)
            xb, _ = fpg_entry(PS3 / 'x360/hdr/flog_x360.fpg', idx + 19)
            psinfo = msf_info(psb)
            xi = xma1_info(xb)
            ref = decode_blob(xb, '.xma')
            obs = spectral_alignment(album, ref)
            row.update(ps3_index=idx, x360_index=idx + 19, ps3=psinfo, x360=xi, alignment=obs, reference_sha256=__import__('hashlib').sha256(xb).hexdigest())
            offsets = np.array([o['offset'] for o in obs])
            scores = [o['score'] for o in obs]
            stable = bool(min(scores) > 0.65 and np.max(np.abs(offsets)) <= RATE * 1.5)
            approx = int(np.median(offsets))
            fine = []
            if stable and np.ptp(offsets) < RATE * 0.02:
                for o in obs:
                    at = max(0.25, o['reference_sample'] / RATE)
                    f, s = waveform_offset(album, ref, approx, at=at, seconds=3)
                    fine.append(dict(offset=f, score=round(s, 5)))
                good = [o['offset'] for o in fine if o['score'] > 0.25]
                if len(good) >= 3 and np.ptp(good) < 240:
                    approx = int(np.median(good))
            row.update(alignment_stable=stable, fine_alignment=fine, offset=approx)
            if xi['loop'] and stable:
                bounds = spectral_alignment(album, ref, points=[xi['loop_start'], xi['loop_end']])
                row['boundary_alignment'] = bounds
                if min((b['score'] for b in bounds)) < 0.65:
                    row['status'] = 'structure_required'
                    out.append(row)
                    yield out
                    continue
                ls = max(0, xi['loop_start'] + bounds[0]['offset'])
                le = min(len(album), xi['loop_end'] + bounds[-1]['offset'])
                if np.ptp(offsets) < RATE * 0.02 and len(good) >= 3:
                    ls = max(0, xi['loop_start'] + approx)
                    le = min(len(album), xi['loop_end'] + approx)
                row.update(loop_start=round(ls / 32) * 32, loop_end=le // 32 * 32)
                xf = min(4800, (len(album) - row['loop_end']) // 32 * 32)
                row['xfade_samples'] = xf if xf >= 1024 else 0
                row['keep_samples'] = row['loop_end'] + row['xfade_samples']
            elif xi['loop']:
                row['status'] = 'structure_required'
        out.append(row)
        print(hex(cmd), tr, row.get('alignment_stable'), [(x['offset'], x['score']) for x in row.get('alignment', [])], flush=True)
        cache[cmd] = row
        yield out

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('game', choices=['ffight_di', 'msword_di', 'ssf2_hdremix'])
    ap.add_argument('--out', type=Path, required=True)
    ap.add_argument('--resume', action='store_true')
    a = ap.parse_args()
    a.out.parent.mkdir(parents=True, exist_ok=True)
    if a.game == 'ssf2_hdremix':
        previous = json.loads(a.out.read_text()) if a.resume and a.out.exists() else None
        for rows in hdr_rows(previous):
            a.out.write_text(json.dumps(rows, indent=2) + '\n')
    else:
        a.out.write_text(json.dumps(di_rows('ff' if a.game == 'ffight_di' else 'ms'), indent=2) + '\n')
if __name__ == '__main__':
    main()
