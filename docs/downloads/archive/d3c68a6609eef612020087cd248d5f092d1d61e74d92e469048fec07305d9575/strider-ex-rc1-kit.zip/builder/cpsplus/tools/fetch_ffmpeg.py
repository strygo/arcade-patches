"""Resolve content-pinned FFmpeg with the kit's shared offline/cache controls."""
from pathlib import Path
import fetch_switch_tools as common
HERE = Path(__file__).resolve().parent

def setup(root=None, *, manifest=None, host=None):
    default = HERE / 'ffmpeg_helpers.json'
    if not default.is_file():
        default = HERE.parent / 'manifests/ffmpeg_helpers_v1.json'
    lock = common.read_lock(manifest or default)
    host = host or common.host_id()
    common.require(host in lock['platforms'], 'No qualified FFmpeg helper for ' + host)
    record = lock['platforms'][host]
    common.require(set(record['executables']) == {'ffmpeg', 'ffprobe'}, 'Invalid FFmpeg helper record')
    return common.obtain(record, host, label='FFmpeg')
