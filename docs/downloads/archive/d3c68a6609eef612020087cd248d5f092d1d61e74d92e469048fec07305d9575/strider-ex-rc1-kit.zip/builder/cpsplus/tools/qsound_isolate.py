"""Capture isolated native CPS-2 QSound music cues, one cold MAME boot each."""
from __future__ import annotations
import argparse
import os
import shutil
import subprocess
import tempfile
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
CPSPLUS = Path(__file__).resolve().parent.parent
REPO = CPSPLUS.parent
LUA = CPSPLUS / 'lua' / 'qsound_music_capture.lua'
FIRST_FRAME = 1500
GAP_FRAMES = 60
PLAY_FRAME = FIRST_FRAME + GAP_FRAMES
REFRESH = 59.637405

def parse_commands(tokens: list[str]) -> list[int]:
    out: list[int] = []
    for tok in tokens:
        lo, _, hi = tok.partition('-')
        a = int(lo, 16)
        b = int(hi, 16) if hi else a
        if not 0 <= a <= b <= 255:
            raise SystemExit(f'bad command range {tok!r}')
        out.extend(range(a, b + 1))
    return sorted(set(out))

def find_rompath(given: str | None) -> str:
    candidates = [given] if given else []
    candidates += [str(REPO / 'roms'), str(REPO / 'roms' / 'mame0260'), os.environ.get('CAPCOM_ARCADE_ROM_PATH', '')]
    return ';'.join((c for c in candidates if c))

def capture(machine: str, cmd: int, outdir: Path, seconds: float, rompath: str, mame: str) -> tuple[int, str]:
    wav = outdir / f'0x{cmd:02x}.wav'
    tsv = outdir / f'0x{cmd:02x}.tsv'
    end_frame = PLAY_FRAME + int(round(seconds * REFRESH))
    env = dict(os.environ, SDL_VIDEODRIVER='dummy', SDL_AUDIODRIVER='dummy', CPSPLUS_QSOUND_CMD=f'{cmd:02x}', CPSPLUS_QSOUND_FIRST_FRAME=str(FIRST_FRAME), CPSPLUS_QSOUND_GAP_FRAMES=str(GAP_FRAMES), CPSPLUS_QSOUND_END_FRAME=str(end_frame))
    with tempfile.TemporaryDirectory(prefix='qsiso_') as state:
        proc = subprocess.run([mame, machine, '-rompath', rompath, '-autoboot_script', str(LUA), '-video', 'soft', '-sound', 'sdl', '-nothrottle', '-skip_gameinfo', '-wavwrite', str(wav), '-cfg_directory', f'{state}/cfg', '-nvram_directory', f'{state}/nvram', '-snapshot_directory', f'{state}/snap'], env=env, capture_output=True, text=True)
    if proc.returncode != 0:
        return (cmd, f'mame exit {proc.returncode}: {proc.stderr.strip()[-300:]}')
    if not wav.is_file() or wav.stat().st_size < 1000000:
        return (cmd, 'no usable -wavwrite output')
    tsv.write_text(f'frame\tevent\n{PLAY_FRAME}\tplay\n', encoding='utf-8')
    return (cmd, 'ok')

def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('machine')
    ap.add_argument('outdir', type=Path)
    ap.add_argument('commands', nargs='+', help='hex bytes or ranges, e.g. 0x01-0x37')
    ap.add_argument('--seconds', type=float, default=12.0, help='capture length after the injection (default 12)')
    ap.add_argument('--jobs', type=int, default=4)
    ap.add_argument('--rompath')
    ap.add_argument('--mame', default=shutil.which('mame') or 'mame')
    args = ap.parse_args(argv)
    cmds = parse_commands(args.commands)
    args.outdir.mkdir(parents=True, exist_ok=True)
    rompath = find_rompath(args.rompath)
    failures = 0
    with ThreadPoolExecutor(max_workers=max(1, args.jobs)) as pool:
        for cmd, status in pool.map(lambda c: capture(args.machine, c, args.outdir, args.seconds, rompath, args.mame), cmds):
            print(f'[{args.machine}] 0x{cmd:02x} {status}', flush=True)
            failures += status != 'ok'
    print(f'[{args.machine}] {len(cmds) - failures}/{len(cmds)} captured -> {args.outdir}')
    return 1 if failures else 0
if __name__ == '__main__':
    raise SystemExit(main())
