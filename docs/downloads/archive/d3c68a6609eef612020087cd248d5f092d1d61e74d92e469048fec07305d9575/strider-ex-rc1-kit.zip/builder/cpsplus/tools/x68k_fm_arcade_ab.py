"""Arcade-vs-X68000-FM listening pairs for an FM pack's ear gate."""
from __future__ import annotations
import argparse
import array
import csv
import math
import re
import sys
import wave
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from pack import build_x68k_fm
REFRESH = 59.637405
AUDIBLE = 16
TARGET_RMS = 0.1 * 32767

def read_stereo(path: Path) -> tuple[array.array, int, int]:
    with wave.open(str(path), 'rb') as w:
        ch, rate = (w.getnchannels(), w.getframerate())
        pcm = array.array('h', w.readframes(w.getnframes()))
    return (pcm, ch, rate)

def stereo_from(pcm: array.array, ch: int, start: int, frames: int) -> array.array:
    out = array.array('h')
    for i in range(start, min(start + frames, len(pcm) // ch)):
        left = pcm[i * ch]
        out.append(left)
        out.append(pcm[i * ch + 1] if ch > 1 else left)
    return out

def onset(pcm: array.array, ch: int, start: int) -> int:
    for i in range(start, len(pcm) // ch):
        if max((abs(pcm[i * ch + c]) for c in range(min(ch, 2)))) >= AUDIBLE:
            return i
    raise ValueError('no audio after the start point')

def injection_frame(tsv: Path, rate: int) -> int:
    rows = list(csv.DictReader(tsv.open(), delimiter='\t'))
    if not rows:
        return 0
    row = rows[0]
    if 'seconds' in row:
        return int(float(row['seconds']) * rate)
    if 'sec' in row:
        return int(float(row['sec']) * rate)
    return int(int(row['frame']) / REFRESH * rate)

def native_clip(native_dir: Path, cmd: int) -> Path | None:
    for name in (f'0x{cmd:02x}.wav', f'{cmd:02x}.wav'):
        if (native_dir / name).is_file():
            return native_dir / name
    return None

def level(clip: array.array) -> array.array:
    rms = math.sqrt(sum((v * v for v in clip)) / max(len(clip), 1))
    gain = TARGET_RMS / rms if rms else 1.0
    return array.array('h', (max(-32768, min(32767, round(v * gain))) for v in clip))

def write(path: Path, clip: array.array, rate: int) -> None:
    with wave.open(str(path), 'wb') as w:
        w.setnchannels(2)
        w.setsampwidth(2)
        w.setframerate(rate)
        w.writeframes(clip.tobytes())

def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.split('\n\n')[0])
    ap.add_argument('--game', required=True, choices=sorted(build_x68k_fm.GAMES))
    ap.add_argument('--native-dir', type=Path, required=True)
    ap.add_argument('--capture-dir', type=Path)
    ap.add_argument('--out-dir', type=Path, required=True)
    ap.add_argument('--seconds', type=float, default=20.0)
    a = ap.parse_args(argv)
    game = build_x68k_fm.GAMES[a.game]
    capture_dir = a.capture_dir or build_x68k_fm.CAPTURE_ROOT / game.capture
    music = {row.song: row for row in game.midi.load_music_map()}
    by_cmd = build_x68k_fm.song_of_command(a.game, list(music.values()))
    first_cmd: dict[str, int] = {}
    for cmd, song in sorted(by_cmd.items()):
        first_cmd.setdefault(song, cmd)
    a.out_dir.mkdir(parents=True, exist_ok=True)
    rows, playlist = ([], ['#EXTM3U'])
    for song, cmd in sorted(first_cmd.items(), key=lambda item: item[1]):
        native = native_clip(a.native_dir, cmd)
        if native is None:
            print(f'skip {song}: no native clip for 0x{cmd:02x}')
            continue
        fm_pcm, fm_ch, rate = read_stereo(capture_dir / f'{song}.wav')
        nat_pcm, nat_ch, nat_rate = read_stereo(native)
        if nat_rate != rate:
            raise SystemExit(f'{native.name}: {nat_rate} Hz, capture {rate} Hz')
        frames = round(a.seconds * rate)
        start = onset(nat_pcm, nat_ch, injection_frame(native.with_suffix('.tsv'), rate))
        fm = level(stereo_from(fm_pcm, fm_ch, 0, frames))
        arcade = level(stereo_from(nat_pcm, nat_ch, start, frames))
        role = re.sub('[^A-Za-z0-9]+', '_', music[song].role).strip('_')
        stem = f'{cmd:02x}_{song}_{role}'
        for tag, clip in (('A_X68000_FM', fm), ('B_ARCADE', arcade)):
            write(a.out_dir / f'{stem}_{tag}.wav', clip, rate)
            playlist.extend((f"#EXTINF:{a.seconds:.0f},0x{cmd:02x} {music[song].role} ({tag[2:].replace('_', ' ')})", f'{stem}_{tag}.wav'))
        rows.append((f'0x{cmd:02x}', song, music[song].role, native.name, f'{len(arcade) / 2 / rate:.2f}'))
    (a.out_dir / 'ab.m3u').write_text('\n'.join(playlist) + '\n')
    with (a.out_dir / 'index.tsv').open('w', newline='') as f:
        out = csv.writer(f, delimiter='\t')
        out.writerow(('cmd', 'song', 'role', 'native_clip', 'arcade_seconds'))
        out.writerows(rows)
    print(f'{a.game}: {len(rows)} A/B pairs in {a.out_dir}')
    return 0
if __name__ == '__main__':
    raise SystemExit(main())
