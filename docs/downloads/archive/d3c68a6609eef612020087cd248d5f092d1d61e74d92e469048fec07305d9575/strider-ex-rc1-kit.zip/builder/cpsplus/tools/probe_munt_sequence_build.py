"""Experimental Munt argument-order probe; not a qualified producer archive."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import build_optional_helpers as producer

def main(a):
    if a.root.exists() or a.out.exists():
        raise ValueError('Fresh experiment required')
    a.root = a.root.absolute()
    a.sources = a.sources.absolute()
    a.root.mkdir(parents=True)
    a.source_pins = json.loads((Path(__file__).resolve().parent.parent / 'manifests/optional_helpers_sources_v1.json').read_text())['sources']
    source = producer.source('munt', a, a.source_pins)
    cpp = source / 'mt32emu/src/Partial.cpp'
    text = cpp.read_text()
    for role, base in (('MASTER', ''), ('SLAVE', 'pair->')):
        old = f'la32PairImpl->generateNextSample(LA32PartialPair::{role}, {base}getAmpValue(), {base}tvp->nextPitch(), {base}getCutoffValue());'
        if text.count(old) != 1:
            raise ValueError('Unexpected partial call site')
        new = f'const Bit32u amp{role} = {base}getAmpValue();\n        const Bit16u pitch{role} = {base}tvp->nextPitch();\n        const Bit32u cutoff{role} = {base}getCutoffValue();\n        la32PairImpl->generateNextSample(LA32PartialPair::{role}, amp{role}, pitch{role}, cutoff{role});'
        if a.mode == 'sequenced':
            text = text.replace(old, new)
    cpp.write_text('/* Experimental explicit evaluation order, 2026-10-24. */\n' + text)
    producer.munt_sequence_adapter = lambda _: None
    os.environ['SOURCE_DATE_EPOCH'] = '1792828800'
    binaries = producer.build('munt', source, a)
    a.out.mkdir(parents=True)
    exe = binaries['mt32']
    shutil.copyfile(exe, a.out / exe.name)
    (a.out / 'probe.json').write_text(json.dumps(dict(source=a.source_pins['munt'], mode=a.mode, modified_source_sha256=hashlib.sha256(cpp.read_bytes()).hexdigest(), executable_sha256=hashlib.sha256(exe.read_bytes()).hexdigest(), recipe_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()), indent=2) + '\n')
if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    for name in ('root', 'out', 'sources'):
        p.add_argument('--' + name, type=Path, required=True)
    p.add_argument('--host', choices=('windows-x86_64', 'macos-arm64'), required=True)
    p.add_argument('--jobs', type=int, default=2)
    p.add_argument('--mode', choices=('baseline', 'sequenced'), default='sequenced')
    main(p.parse_args())
