"""CD-DA track edge analysis: is the audio authored to loop end->start?"""
import sys, struct, math

def rms(s):
    return math.sqrt(sum((x * x for x in s)) / len(s)) if s else 0

def main():
    path = sys.argv[1]
    pregap = int(sys.argv[2]) if len(sys.argv) > 2 else 150
    data = open(path, 'rb').read()
    body = data[pregap * 2352:]
    n = len(body) // 4

    def win(off_samples, count):
        o = off_samples * 4
        return struct.unpack('<%dh' % (count * 2), body[o:o + count * 4])
    total_s = n / 44100
    print(f"{path.split('/')[-1]}: {n} samples = {total_s:.2f}s (pregap {pregap} sectors excluded)")
    step = 588
    first_ns = None
    last_ns = None
    for i in range(0, n - step, step):
        w = win(i, step // 2)
        if max((abs(x) for x in w)) > 48:
            first_ns = i
            break
    for i in range(n - step, 0, -step):
        w = win(i, step // 2)
        if max((abs(x) for x in w)) > 48:
            last_ns = i + step
            break
    print(f'  first non-silence at {first_ns / 44100:.3f}s, last at {last_ns / 44100:.3f}s (trailing silence {(n - last_ns) / 44100:.3f}s)')
    pts = [rms(win(int(n * p / 10), 4410)) for p in range(10)]
    print('  RMS profile:', ' '.join((f'{p:.0f}' for p in pts)))
    print(f'  RMS last 0.5s: {rms(win(n - 22050 // 2 - (n - last_ns), 11025)):.0f}  last 2s: {rms(win(n - 88200, 44100)):.0f}')
    a = win(n - 8, 8)
    b = win(first_ns, 8)
    print('  tail L/R:', a)
    print('  head L/R:', b)
main()
