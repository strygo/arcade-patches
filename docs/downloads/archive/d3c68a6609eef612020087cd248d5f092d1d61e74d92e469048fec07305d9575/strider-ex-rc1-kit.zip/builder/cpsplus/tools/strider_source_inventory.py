"""Rebuild the recovered Strider source inventory from local extracted inputs."""
import sys, struct, json, hashlib, gzip, wave, xml.etree.ElementTree as ET, zlib
import argparse
from pathlib import Path
root = Path(__file__).resolve().parents[2]
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--work', type=Path, default=root / 'cpsplus/work/strider')
parser.add_argument('--output', type=Path, required=True)
parser.add_argument('--inputs', type=Path, default=root / 'cpsplus/manifests/strider_source_inputs.json')
args = parser.parse_args()
work = args.work.resolve()
import iso9660
inputs = json.loads(args.inputs.read_text())
for rec in inputs:
    path = Path(rec['path']).expanduser()
    if not path.is_absolute():
        path = root / path
    assert path.stat().st_size == rec['bytes'], path
    with path.open('rb') as stream:
        assert hashlib.file_digest(stream, 'sha256').hexdigest() == rec['sha256'], path
raw = work / 'sources/psx/strider.bin'
files = work / 'sources/psx/files'
files.mkdir(exist_ok=True)

def rawread(f, lba, size):
    data = bytearray()
    for pos in range(lba, lba + (size + 2047) // 2048):
        f.seek(pos * 2352)
        sec = f.read(2352)
        assert len(sec) == 2352
        assert sec[15] in (1, 2)
        off = 16 if sec[15] == 1 else 24
        data.extend(sec[off:off + 2048])
    return bytes(data[:size])
iso9660.rd = rawread
psx = []
with raw.open('rb') as f:
    for name, lba, size, isdir in iso9660.walk(f, *iso9660.root(f)):
        if isdir:
            continue
        row = dict(file=name, lba=lba, bytes=size)
        if name.startswith('/SOUND/') or name in ('/SYSTEM.CNF', '/SLUS_011.42', '/MAIN.EXE', '/OPTION/OPTION.BIN', '/GAME/GAME.BIN'):
            data = rawread(f, lba, size)
            out = files / name.lstrip('/')
            out.parent.mkdir(parents=True, exist_ok=True)
            out.write_bytes(data)
            row.update(sha256=hashlib.sha256(data).hexdigest(), header=data[:32].hex())
        psx.append(row)
vgm = []
for p in sorted((work / 'sources/vgm').glob('*.vgz')):
    b = gzip.decompress(p.read_bytes())
    g = 20 + int.from_bytes(b[20:24], 'little')
    assert b[g:g + 4] == b'Gd3 '
    txt = b[g + 12:g + 12 + int.from_bytes(b[g + 8:g + 12], 'little')].decode('utf-16-le').split('\x00')
    vgm.append(dict(file=p.name, title=txt[0], notes=txt[10], samples=int.from_bytes(b[24:28], 'little'), loop_samples=int.from_bytes(b[32:36], 'little'), sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
pce = []
for p in sorted((work / 'sources/pce').glob('*.bin')):
    n = int(p.stem.split('Track ')[1].rstrip(')'))
    h = hashlib.file_digest(p.open('rb'), 'sha256').hexdigest()
    row = dict(track=n, file=p.name, bytes=p.stat().st_size, sha256=h)
    if n == 1 or 3 <= n <= 29:
        w = root / f'cpsplus/work/listening/strider/cd_full/tr{n:02}.wav'
        with wave.open(str(w)) as f:
            data = f.readframes(f.getnframes())
            row.update(wav_sha256=hashlib.file_digest(w.open('rb'), 'sha256').hexdigest(), rate=f.getframerate(), channels=f.getnchannels(), frames=f.getnframes(), matches_retained_wav=hashlib.sha256(data).hexdigest() == h)
        assert row['matches_retained_wav'], n
    pce.append(row)
arcade = []
for m in ET.parse(work / 'sources/arcade/sets.xml').getroot().findall('machine'):
    name = m.get('name')
    if name not in ('striderua', 'striderjr'):
        continue
    roms = []
    for r in m.findall('rom'):
        if r.get('region') not in ('maincpu', 'audiocpu', 'gfx', 'oki'):
            continue
        p = work / 'sources/arcade' / name / r.get('name')
        b = p.read_bytes()
        assert f'{zlib.crc32(b):08x}' == r.get('crc')
        assert hashlib.sha1(b).hexdigest() == r.get('sha1')
        roms.append(dict(r.attrib))
    arcade.append(dict(set=name, description=m.findtext('description'), roms=roms))
result = dict(inputs=inputs, psx=dict(system_cnf=(files / 'SYSTEM.CNF').read_text(), files=psx), pce=pce, arcade=arcade, vgm=vgm)
args.output.parent.mkdir(parents=True, exist_ok=True)
args.output.write_text(json.dumps(result, indent=2) + '\n')
print('PSX', result['psx']['system_cnf'], len(psx), 'files')
print('PCE', len(pce), 'BIN tracks;', sum((r.get('matches_retained_wav', False) for r in pce)), 'retained WAVs match exactly')
print('VGM', len(vgm), 'tracks; arcade runtime ROM regions verified for', [r['set'] for r in arcade])
