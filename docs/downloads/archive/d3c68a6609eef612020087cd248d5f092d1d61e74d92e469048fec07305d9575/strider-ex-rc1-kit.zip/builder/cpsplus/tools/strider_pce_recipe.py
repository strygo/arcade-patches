"""Write the Strider (PC Engine Soundtrack) pack recipe from the reviewed research."""
import argparse
import json
import subprocess
import sys
import tempfile
import wave
from pathlib import Path
import numpy as np
ROOT = Path(__file__).resolve().parents[2]
MAN = ROOT / 'cpsplus/manifests'
RATE = 48000
DISC = 'Strider Hiryuu (Japan).7z'
INTROS = {'0x11', '0x12', '0x13', '0x1e', '0x1f'}

def lufs(x):
    with tempfile.TemporaryDirectory() as d:
        p = Path(d) / 'x.wav'
        with wave.open(str(p), 'wb') as w:
            (w.setnchannels(2), w.setsampwidth(2), w.setframerate(RATE))
            w.writeframes(np.rint(x * 32768).clip(-32768, 32767).astype('<i2').tobytes())
        err = subprocess.run(['ffmpeg', '-hide_banner', '-nostats', '-i', str(p), '-filter_complex', 'ebur128', '-f', 'null', '-'], capture_output=True, text=True).stderr
    vals = [float(l.split('I:')[1].split('LUFS')[0]) for l in err.splitlines() if 'I:' in l and 'LUFS' in l]
    return vals[-1]

def read(path, start, frames):
    with wave.open(str(path)) as f:
        assert f.getframerate() == RATE and f.getnchannels() == 2
        f.setpos(start)
        return np.frombuffer(f.readframes(frames), '<i2').reshape(-1, 2) / 32768

def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('--review', type=Path, default=ROOT / 'cpsplus/work/strider/review')
    p.add_argument('--output', type=Path, default=MAN / 'strider_pce_audio.json')
    a = p.parse_args()
    amap = json.loads((MAN / 'strider_review_map.json').read_text())
    dec = {d['id']: d for d in json.loads((MAN / 'strider_listening_decisions.json').read_text())['decisions']}
    inputs = json.loads((MAN / 'strider_source_inputs.json').read_text())
    disc = next((r for r in inputs if r['path'].endswith(DISC)))
    cands = json.loads((a.review / 'audio_v2/candidates.json').read_text())
    cands = {c['id']: c for c in (cands if isinstance(cands, list) else cands['candidates'])}
    review = {c['id']: c for c in json.loads((a.review / 'review_data.json').read_text())['candidates']}
    used = sorted({r['pce']['track'] for r in amap['rows'] if r['pce'].get('track')})
    tracks = []
    for key in used:
        d = dec.get(key)
        if not d or d['verdict'] != 'good':
            sys.exit(f'{key}: no approved listening decision')
        if d.get('loop_start') is not None:
            c = cands[key]
            out = 'candidate'
            row = dict(loop_start=c['loop_start'], loop_end=c['loop_end'], crossfade_frames=c['crossfade_frames'], source_trim_frames=c['source']['source_trim_frames'])
        else:
            c = review[key]
            out = 'source'
            row = dict(loop_start=None, loop_end=None, crossfade_frames=0, source_trim_frames=c['source']['source_trim_frames'])
        tracks.append(dict(id=key, disc_track=int(key[4:]), title=review[key]['title'], reviewed_file=d['outputs'][out]['file'], reviewed_wav_sha256=d['outputs'][out]['sha256'], listening='', **row))
    triggers = []
    for r in amap['rows']:
        t = r['pce'].get('track')
        triggers.append(dict(command=r['command'], role=r['role'], track=t, stop_arranged=t is None and r['kind'] != 'native_effect' and (r['command'] != '0x14')))
    triggers.append(dict(command='0x23', role='Time Over (driver plays tune 0x00)', track=None, stop_arranged=True))
    rows = []
    by = {t['id']: t for t in tracks}
    for tr in triggers:
        t = by.get(tr['track'])
        if not t or t['loop_start'] is None or tr['command'] in INTROS:
            continue
        ref = a.review / f"reference/arc_{int(tr['command'], 16):02x}.wav"
        if not ref.exists():
            continue
        native = lufs(read(ref, RATE, 8 * RATE))
        pce = lufs(read(a.review / 'audio_v2' / Path(t['reviewed_file']).name, RATE, 8 * RATE))
        rows.append(dict(command=tr['command'], track=t['id'], native_lufs=round(native, 1), pce_lufs=round(pce, 1), delta_lu=round(pce - native, 1)))
    delta = float(np.median([r['delta_lu'] for r in rows]))
    gain = min(127, round(127 * 10 ** (-delta / 20)))
    recipe = dict(schema=1, pack='strider_pce', review_status='approved', source=dict(disc=DISC, disc_sha256=disc['sha256'], disc_bytes=disc['bytes'], tracks='Red Book audio, 44.1 kHz s16 stereo; each track is the disc bin itself'), resampling='scipy.signal.resample_poly(x[trim:], 160, 147, axis=0, window=("kaiser", 8.6)) on the whole track', loop_policy='Preserve the reviewed baked linear blend before loop_end; hardware crossfade disabled.', trigger_gain=gain, loudness=dict(method='EBU R128 integrated loudness on source seconds 1..9, per mapped looping arcade command; stage intros excluded.', median_delta_lu=delta, trigger_gain=gain, effective_gain_db=20 * np.log10(gain / 127), rows=rows), tracks=tracks, triggers=triggers)
    a.output.write_text(json.dumps(recipe, indent=1, ensure_ascii=False) + '\n')
    print(f'{len(tracks)} tracks, {len(triggers)} triggers, gain {gain} (median {delta:+.1f} LU) -> {a.output}')
    return 0
if __name__ == '__main__':
    sys.exit(main())
