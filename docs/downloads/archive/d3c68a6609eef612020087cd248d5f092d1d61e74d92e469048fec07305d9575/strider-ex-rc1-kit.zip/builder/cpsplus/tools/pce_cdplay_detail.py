"""Per-site evidence dump for CD_PLAY ($E012) call sites in a PCE CD data track."""
from __future__ import annotations
import argparse
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
from pce_cdbios_scan import BIOS_CALLS, REG_NAMES, ADDR_TYPE, PLAY_MODE, _L, LDA_IMM, STA_ZP, STZ_ZP
MNEM = {169: 'LDA #${:02X}', 133: 'STA ${:02X}', 100: 'STZ ${:02X}', 165: 'LDA ${:02X}', 173: 'LDA ${:04X}', 189: 'LDA ${:04X},X', 185: 'LDA ${:04X},Y', 181: 'LDA ${:02X},X', 32: 'JSR ${:04X}', 96: 'RTS', 234: 'NOP', 141: 'STA ${:04X}', 156: 'STZ ${:04X}'}

def disasm_one(buf, pc):
    op = buf[pc]
    n = _L[op]
    if op in MNEM:
        if n == 2:
            return (MNEM[op].format(buf[pc + 1]), n)
        if n == 3:
            return (MNEM[op].format(buf[pc + 1] | buf[pc + 2] << 8), n)
        return (MNEM[op], n)
    return (f'.byte ${op:02X}' + ('' if n == 1 else f' (+{n - 1})'), n)

def best_stream(buf, jsr_off, window):
    best = None
    for origin in range(max(0, jsr_off - window), jsr_off):
        pc, writes, stream, acc = (origin, {}, [], None)
        while pc < jsr_off:
            op = buf[pc]
            if op == LDA_IMM:
                acc = buf[pc + 1]
            elif op == STA_ZP and buf[pc + 1] in REG_NAMES:
                writes[buf[pc + 1]] = acc
            elif op == STZ_ZP and buf[pc + 1] in REG_NAMES:
                writes[buf[pc + 1]] = 0
            elif op in (165, 173, 181, 189, 185, 161, 177, 178):
                acc = None
            txt, n = disasm_one(buf, pc)
            stream.append((pc, txt))
            pc += n
        if pc == jsr_off and (best is None or len(writes) > len(best[1])):
            best = (origin, writes, stream)
    return best

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('image', type=Path)
    ap.add_argument('--window', type=int, default=64)
    a = ap.parse_args()
    buf = a.image.read_bytes()
    allcalls = [i for i in range(len(buf) - 2) if buf[i] == 32 and buf[i + 2] == 224 and (buf[i + 1] in BIOS_CALLS)]
    sites = [i for i in allcalls if buf[i + 1] == 18]
    print(f'=== {a.image.name}: {len(sites)} raw CD_PLAY match(es) ===\n')
    for off in sites:
        got = best_stream(buf, off, a.window)
        near = sum((1 for c in allcalls if abs(c - off) <= 2048 and c != off))
        print(f'--- @0x{off:08X}  (sector {off // 2048})  neighbouring BIOS calls +/-2KB: {near}')
        if not got:
            print('    no coherent stream -> LIKELY NOISE\n')
            continue
        origin, w, stream = got
        for pc, txt in stream[-10:]:
            print(f'    {pc:08X}: {txt}')
        print(f'    {off:08X}: JSR $E012   ; CD_PLAY')
        if w:
            print('    regs:', ', '.join((f'{REG_NAMES[r]}=' + ('VAR' if v is None else f'${v:02X}') for r, v in sorted(w.items()))))
            bh, dh = (w.get(251), w.get(255))
            if bh is not None:
                print(f'      start type : {ADDR_TYPE[bh >> 6]}')
            if dh is not None:
                print(f'      end type   : {ADDR_TYPE[dh >> 6]}')
                print(f"      PLAY MODE  : {PLAY_MODE.get(dh & 15, '?')}")
            verdict = 'REAL' if len(w) >= 1 else 'SUSPECT'
        else:
            verdict = 'LIKELY NOISE (no BIOS-register writes)'
        print(f'    VERDICT: {verdict}')
        print('    hex:', buf[max(0, off - 24):off + 3].hex(' '), '\n')
if __name__ == '__main__':
    main()
