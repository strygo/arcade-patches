"""Same-carrier tune identity with a FULL-RANGE lag search."""
from __future__ import annotations
import argparse, glob, sys, wave
from pathlib import Path
import numpy as np
RATE = 16000

def load(path, max_s=None):
    w = wave.open(str(path))
    n = w.getnframes()
    x = np.frombuffer(w.readframes(n), dtype='<i2').astype(np.float32)
    if w.getnchannels() == 2:
        x = x.reshape(-1, 2).mean(axis=1)
    sr = w.getframerate()
    if sr != RATE:
        idx = np.arange(0, len(x), sr / RATE)[:int(len(x) * RATE / sr)]
        x = np.interp(idx, np.arange(len(x)), x)
    nz = np.nonzero(np.abs(x) > 200)[0]
    if len(nz):
        x = x[nz[0]:]
    if max_s:
        x = x[:int(max_s * RATE)]
    return x

def peak_ncc(a, b):
    """max over all lags of the normalised cross-correlation of a against b."""
    if len(a) < RATE or len(b) < len(a):
        return 0.0
    a = a - a.mean()
    n = 1 << int(np.ceil(np.log2(len(a) + len(b))))
    A, B = (np.fft.rfft(a, n), np.fft.rfft(b - b.mean(), n))
    cc = np.fft.irfft(np.conj(A) * B, n)
    cs = np.concatenate(([0.0], np.cumsum(b.astype(np.float64) ** 2)))
    e_b = cs[len(a):] - cs[:-len(a)]
    lim = min(len(cc), len(e_b))
    denom = np.sqrt((a * a).sum() * np.maximum(e_b[:lim], 1e-09))
    return float(np.max(cc[:lim] / denom))

def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument('--a', required=True)
    ap.add_argument('--b', required=True)
    ap.add_argument('--clip-s', type=float, default=8.0)
    ap.add_argument('--truth', help='TSV of expected a<TAB>b pairs, for a control run')
    args = ap.parse_args(argv)
    A = {Path(p).name: load(p, args.clip_s) for p in sorted(glob.glob(args.a))}
    B = {Path(p).name: load(p) for p in sorted(glob.glob(args.b))}
    truth = {}
    if args.truth:
        for ln in open(args.truth):
            if ln.strip() and (not ln.startswith('#')):
                k, v = ln.rstrip('\n').split('\t')[:2]
                truth[k] = v
    hits = 0
    for an, a in A.items():
        sc = sorted(((peak_ncc(a, b), bn) for bn, b in B.items()), reverse=True)
        top, second = (sc[0], sc[1] if len(sc) > 1 else (0.0, '-'))
        margin = top[0] - second[0]
        line = f'  {an:<24} -> {top[1]:<24} r={top[0]:.3f} (2nd {second[0]:.3f}, margin {margin:+.3f})'
        if truth:
            ok = truth.get(an) == top[1]
            hits += ok
            line += '  OK' if ok else f"  MISS (true {truth.get(an, '?')} r={dict(((b, s) for s, b in sc)).get(truth.get(an), 0):.3f})"
        print(line)
    if truth:
        print(f'\n  control: {hits}/{len(truth)} correct')
    return 0
if __name__ == '__main__':
    sys.exit(main())
