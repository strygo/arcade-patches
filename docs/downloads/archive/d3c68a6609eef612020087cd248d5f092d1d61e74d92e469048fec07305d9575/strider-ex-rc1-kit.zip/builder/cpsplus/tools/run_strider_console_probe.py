"""Run Strider PSX/PCE source captures with the repository surface runner."""
import argparse
import hashlib
import json
import os
import signal
import shutil
from pathlib import Path
import subprocess
import sys
ROOT = Path(__file__).resolve().parents[2]

def remix_schedule():
    inputs = ['2450-2470:P1_START', '2620-2622:P1_JOYSTICK_DOWN', '2680-2682:P1_JOYSTICK_DOWN', '2740-2742:P1_BUTTON2']
    inputs += [f'{3500 + i * 15}-{3502 + i * 15}:P1_JOYSTICK_DOWN' for i in range(11)]
    inputs += ['3700-3702:P1_JOYSTICK_RIGHT']
    inputs += [f'{3800 + i * 15}-{3802 + i * 15}:P1_JOYSTICK_UP' for i in range(5)]
    pokes, captures = ([], [])
    for index in range(10):
        frame = 4000 + 9000 * index
        stop = frame - (300 if index else 20)
        inputs += [f'{stop}-{stop + 2}:P1_BUTTON4', f'{frame}-{frame + 2}:P1_BUTTON2']
        pokes.append(f'{frame - 10}:0x4d8cc={index}')
        captures += [f'{frame + 500}=remix_{index + 1:02}_loaded', f'{frame + 8500}=remix_{index + 1:02}_looped']
    return (';'.join(inputs), ';'.join(pokes), ';'.join(captures))

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--machine', choices=['psu', 'pce'], default='psu')
    p.add_argument('--outdir', type=Path, required=True)
    p.add_argument('--cdrom', type=Path, required=True)
    p.add_argument('--cart')
    p.add_argument('--rompath', type=Path)
    p.add_argument('--schedule', default='')
    p.add_argument('--captures', default='2400=title;3600=later')
    p.add_argument('--pokes', default='')
    p.add_argument('--remix-census', action='store_true')
    p.add_argument('--sound-state', action='store_true', help='poll observed PSX sound state each frame')
    p.add_argument('--pce-state', action='store_true', help='trace PCE BIOS parameters and capture mapped RAM/registers')
    p.add_argument('--pce-start-stage', type=int, choices=range(7), help='select the initial chapter and run its existing asset preloader (research)')
    p.add_argument('--pce-checkpoint-census', action='store_true', help='invoke the verified checkpoint-step routine from a guarded idle return (research)')
    p.add_argument('--pce-first-checkpoint', type=int, choices=range(1, 15), help='select an existing initial checkpoint in the loaded stage (research)')
    p.add_argument('--pce-phase', choices=['stage_clear', 'continue', 'ending'], help='enter an original outcome dispatcher after new-game initialization (research)')
    p.add_argument('--log', action='store_true', help='MAME device diagnostics under outdir')
    p.add_argument('--timeout-seconds', type=float, default=300, help='wall-clock bound for the complete probe process group')
    a = p.parse_args()
    pce_controls = a.pce_start_stage is not None or a.pce_first_checkpoint is not None or a.pce_phase or a.pce_checkpoint_census
    if (a.pce_state or pce_controls) and a.machine != 'pce':
        p.error('PCE capture controls require --machine pce')
    if pce_controls and (not a.pce_state):
        p.error('PCE research controls require --pce-state')
    if a.pokes and a.machine != 'psu':
        p.error('--pokes writes PSX 32-bit words; use the explicit PCE research controls')
    if a.timeout_seconds <= 0:
        p.error('--timeout-seconds must be positive')
    if a.remix_census:
        if a.machine != 'psu':
            p.error('--remix-census requires psu')
        a.schedule, a.pokes, a.captures = remix_schedule()
    out = a.outdir.resolve()
    out.mkdir(parents=True, exist_ok=True)
    if (out / 'run.log').exists():
        p.error('choose a fresh output directory')
    script = out / 'strider_console_probe.lua'
    shutil.copyfile(ROOT / 'cpsplus/lua/strider_console_probe.lua', script)
    env = os.environ | dict(SDL_VIDEODRIVER='dummy', SDL_AUDIODRIVER='dummy', STRIDER_PSX_POKES=a.pokes, STRIDER_CONSOLE_RAM_DUMP='1' if a.machine == 'psu' else '0', STRIDER_PCE_STATE='1' if a.pce_state and a.machine == 'pce' else '0', STRIDER_PCE_START_STAGE='' if a.pce_start_stage is None else str(a.pce_start_stage), STRIDER_PCE_CHECKPOINT_CENSUS='1' if a.pce_checkpoint_census else '0', STRIDER_PCE_FIRST_CHECKPOINT='' if a.pce_first_checkpoint is None else str(a.pce_first_checkpoint), STRIDER_PCE_PHASE=a.pce_phase or '', STRIDER_PSX_SOUND_STATE='1' if a.sound_state and a.machine == 'psu' else '0')
    cmd = [sys.executable, str(ROOT / 'translations/vhunt2/scripts/run_surface_trace.py'), '--machine', a.machine, '--outdir', str(out), '--script', str(script), '--schedule', a.schedule, '--captures', a.captures, '--dump-range', '0:0x40']
    if a.rompath:
        cmd += ['--rompath', str(a.rompath.resolve())]
    mame = ['-nothrottle', '-video', 'none', '-sound', 'none', '-hashpath', '/opt/homebrew/share/mame/hash', '-cfg_directory', str(out / 'cfg'), '-nvram_directory', str(out / 'nvram'), '-wavwrite', str(out / 'audio.wav'), '-cdrom', str(a.cdrom.resolve())]
    if a.cart:
        mame += ['-cart', a.cart]
    if a.log:
        mame += ['-log']
    cmd += ['--mame-arg=' + x for x in mame]
    (out / 'invocation.json').write_text(json.dumps(dict(command=cmd, pokes=a.pokes, ram_dump=a.machine == 'psu', pce_state=a.pce_state, pce_start_stage=a.pce_start_stage, pce_checkpoint_census=a.pce_checkpoint_census, pce_first_checkpoint=a.pce_first_checkpoint, pce_phase=a.pce_phase, script_sha256=hashlib.sha256(script.read_bytes()).hexdigest()), indent=2) + '\n')
    with (out / 'run.log').open('w') as log:
        process = subprocess.Popen(cmd, env=env, cwd=out, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        try:
            code = process.wait(timeout=a.timeout_seconds)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGTERM)
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
                process.wait()
            code = 124
            log.write('\nProbe wall-clock timeout; owned process group stopped.\n')
    (out / 'completion.json').write_text(json.dumps(dict(exit_code=code), indent=2) + '\n')
    print(f"{a.machine}: exit {code}; {out / 'run.log'}")
    raise SystemExit(code)
if __name__ == '__main__':
    main()
