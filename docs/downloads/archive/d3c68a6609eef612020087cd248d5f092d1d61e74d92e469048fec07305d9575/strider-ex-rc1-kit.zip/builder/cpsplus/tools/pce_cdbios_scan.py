"""Static scan of a PC Engine CD-ROM(2) data track for CD-ROM BIOS audio calls."""
from __future__ import annotations
import argparse
import collections
import sys
from pathlib import Path
BIOS_CALLS = {0: 'CD_BOOT', 3: 'CD_RESET', 6: 'CD_BASE', 9: 'CD_READ', 12: 'CD_SEEK', 15: 'CD_EXEC', 18: 'CD_PLAY', 21: 'CD_SEARCH', 24: 'CD_PAUSE', 27: 'CD_STAT', 30: 'CD_SUBQ', 33: 'CD_DINFO', 36: 'CD_CONTNTS', 39: 'CD_SUBRD', 42: 'CD_PCMRD', 45: 'CD_FADE', 48: 'AD_RESET', 51: 'AD_TRANS', 54: 'AD_READ', 57: 'AD_WRITE', 60: 'AD_PLAY', 63: 'AD_CPLY', 66: 'AD_STOP', 69: 'AD_STAT'}
REG_NAMES = {248: '_al', 249: '_ah', 250: '_bl', 251: '_bh', 252: '_cl', 253: '_ch', 254: '_dl', 255: '_dh'}
ADDR_TYPE = {0: 'LOG.BLOCK', 1: 'CD-A TIME', 2: 'CD-TNO', 3: 'CURRENT/READOUT'}
PLAY_MODE = {0: 'mute', 1: 'INFINITE REPEAT', 2: 'normal (blocking)', 3: 'normal (async)', 4: 'no change'}
_L = [0] * 256

def _fill(length, opcodes):
    for o in opcodes:
        _L[o] = length
_fill(1, [0, 2, 8, 10, 24, 26, 34, 40, 42, 56, 58, 64, 66, 72, 74, 88, 90, 96, 104, 106, 120, 122, 136, 138, 152, 154, 168, 170, 184, 186, 200, 202, 216, 218, 232, 234, 248, 250, 27, 59, 91, 123, 155, 187, 219, 251, 84, 212, 244, 20, 52])
_fill(2, [1, 4, 5, 6, 9, 16, 17, 18, 21, 22, 33, 36, 37, 38, 41, 48, 49, 50, 53, 54, 65, 68, 69, 70, 73, 80, 81, 82, 85, 86, 97, 100, 101, 102, 105, 112, 113, 114, 116, 117, 118, 128, 129, 132, 133, 134, 137, 144, 145, 146, 148, 149, 150, 160, 161, 162, 164, 165, 166, 169, 176, 177, 178, 180, 181, 182, 192, 193, 194, 196, 197, 198, 201, 208, 209, 210, 213, 214, 224, 225, 228, 229, 230, 233, 240, 241, 242, 245, 246, 98, 130])
_fill(3, [12, 13, 14, 19, 25, 28, 29, 30, 32, 44, 45, 46, 57, 60, 61, 62, 76, 77, 78, 89, 93, 94, 108, 109, 110, 121, 124, 125, 126, 140, 141, 142, 147, 153, 156, 157, 158, 172, 173, 174, 185, 188, 189, 190, 204, 205, 206, 217, 221, 222, 236, 237, 238, 249, 253, 254, 35, 67, 83, 99, 115, 131, 163, 195, 227])
_fill(3, [15, 31, 47, 63, 79, 95, 111, 127, 143, 159, 175, 191, 207, 223, 239, 255])
_fill(4, [3, 7, 11, 23, 39, 43, 55, 71, 75, 87, 103, 107, 119, 135, 139, 151, 167, 171, 183, 199, 203, 215, 231, 235, 247])
_fill(7, [115, 195, 211, 227, 243])
for _i in range(256):
    if _L[_i] == 0:
        _L[_i] = 1
LDA_IMM, STA_ZP, STZ_ZP = (169, 133, 100)

def recover_params(buf: bytes, jsr_off: int, window: int=96):
    """Replay writes to $F8-$FF in the window preceding a call."""
    start = max(0, jsr_off - window)
    best = None
    for origin in range(start, jsr_off):
        pc, acc, writes, ok = (origin, None, {}, False)
        while pc < jsr_off:
            op = buf[pc]
            if op == LDA_IMM:
                acc = buf[pc + 1] if pc + 1 < len(buf) else None
            elif op == STA_ZP and pc + 1 < len(buf) and (buf[pc + 1] in REG_NAMES):
                writes[buf[pc + 1]] = acc
            elif op == STZ_ZP and pc + 1 < len(buf) and (buf[pc + 1] in REG_NAMES):
                writes[buf[pc + 1]] = 0
            elif op in (165, 173, 181, 189, 185, 161, 177, 178):
                acc = None
            pc += _L[op]
        ok = pc == jsr_off
        if ok and (best is None or len(writes) > len(best[1])):
            best = (origin, writes)
    return best[1] if best else {}

def scan(path: Path, window: int):
    buf = path.read_bytes()
    sites = collections.defaultdict(list)
    for i in range(len(buf) - 2):
        if buf[i] == 32 and buf[i + 2] == 224 and (buf[i + 1] in BIOS_CALLS):
            sites[BIOS_CALLS[buf[i + 1]]].append(i)
    return (buf, sites)

def describe_play(w):
    dh, bh, al = (w.get(255), w.get(251), w.get(248))
    parts = []
    if bh is None:
        parts.append('start_type=VARIABLE')
    else:
        parts.append(f'start_type={ADDR_TYPE[bh >> 6]}(${bh:02X})')
    parts.append(f"start_track/addr={('VARIABLE' if al is None else f'${al:02X}')}")
    if dh is None:
        parts.append('end_type=VARIABLE mode=VARIABLE')
    else:
        parts.append(f'end_type={ADDR_TYPE[dh >> 6]}')
        parts.append(f"MODE={PLAY_MODE.get(dh & 15, f'?{dh & 15}')}(${dh:02X})")
    return '  '.join(parts)

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('image', type=Path, help='data-track user-data image')
    ap.add_argument('--window', type=int, default=96)
    ap.add_argument('--quiet', action='store_true')
    a = ap.parse_args()
    buf, sites = scan(a.image, a.window)
    print(f'=== {a.image.name}  ({len(buf):,} bytes) ===')
    for name in sorted(sites, key=lambda n: -len(sites[n])):
        print(f'  {name:<11} {len(sites[name]):>5} call site(s)')
    play = sites.get('CD_PLAY', [])
    if not play:
        print('\n  NO CD_PLAY CALL SITES FOUND.')
        return
    print(f'\n--- CD_PLAY parameter recovery ({len(play)} sites) ---')
    tally = collections.Counter()
    starttype = collections.Counter()
    for off in play:
        w = recover_params(buf, off, a.window)
        dh = w.get(255)
        mode = 'VARIABLE' if dh is None else PLAY_MODE.get(dh & 15, f'?{dh & 15}')
        tally[mode] += 1
        bh = w.get(251)
        starttype['VARIABLE' if bh is None else ADDR_TYPE[bh >> 6]] += 1
        if not a.quiet:
            print(f'  @0x{off:08X}  {describe_play(w)}')
    print('\n--- PLAY MODE tally ---')
    for m, c in tally.most_common():
        print(f'  {m:<22} {c:>5}')
    print('--- START ADDRESS TYPE tally ---')
    for m, c in starttype.most_common():
        print(f'  {m:<22} {c:>5}')
if __name__ == '__main__':
    sys.exit(main())
