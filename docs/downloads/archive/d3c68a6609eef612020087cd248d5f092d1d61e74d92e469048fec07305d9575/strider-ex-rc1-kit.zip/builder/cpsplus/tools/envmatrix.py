"""Envelope correlation matrix: all ADP stage themes (C decoder @24kHz) vs all CD-DA tracks."""
import sys, glob, math, subprocess
import numpy as np

def env100_from_s16(mono, rate):
    hop = rate // 100
    n = mono.size // hop * hop
    e = np.abs(mono[:n].astype(np.float64)).reshape(-1, hop).mean(axis=1)
    return e

def norm(e):
    e = e - e.mean()
    s = math.sqrt(np.sum(e * e)) or 1
    return e / s

def xcorr_max(ea, eb, maxlag=500):
    best = (-9, 0)
    n = min(ea.size, eb.size) - maxlag
    if n < 300:
        n = min(ea.size, eb.size) // 2
    for lag in range(-maxlag, maxlag + 1):
        if lag >= 0:
            a = ea[lag:lag + n]
            b = eb[:n]
        else:
            a = ea[:n]
            b = eb[-lag:-lag + n]
        m = min(a.size, b.size)
        if m < 200:
            continue
        a = a[:m]
        b = b[:m]
        aa = norm(a)
        bb = norm(b)
        c = float(np.dot(aa, bb))
        if c > best[0]:
            best = (c, lag)
    return best

def main():
    adps = sorted(glob.glob(sys.argv[1]))
    cds = sorted(glob.glob(sys.argv[2]))
    cpymc = sys.argv[3]
    aenv = {}
    for a in adps:
        raw = subprocess.run([cpymc, a], capture_output=True).stdout
        x = np.frombuffer(raw, dtype='<i2')
        mono = (x[0::2].astype(np.float64) + x[1::2]) / 2
        aenv[a] = env100_from_s16(mono, 24000)
    cenv = {}
    for c in cds:
        raw = open(c, 'rb').read()[150 * 2352:]
        x = np.frombuffer(raw[:len(raw) // 4 * 4], dtype='<i2')
        mono = (x[0::2].astype(np.float64) + x[1::2]) / 2
        cenv[c] = env100_from_s16(mono, 44100)
    print(f"{'ADP':16s} {'dur':>6s}  best-track  corr  lag(s)  2nd-best")
    for a in adps:
        ea = aenv[a]
        results = []
        for c in cds:
            corr, lag = xcorr_max(ea, cenv[c], maxlag=400)
            results.append((corr, c, lag))
        results.sort(reverse=True)
        r0, r1 = (results[0], results[1])
        t0 = r0[1].split('Track ')[1][:2]
        t1 = r1[1].split('Track ')[1][:2]
        print(f"{a.split('/')[-1]:16s} {ea.size / 100:6.1f}  tr{t0}  {r0[0]:+.3f} {r0[2] / 100:+6.2f}  tr{t1} {r1[0]:+.3f}")
main()
