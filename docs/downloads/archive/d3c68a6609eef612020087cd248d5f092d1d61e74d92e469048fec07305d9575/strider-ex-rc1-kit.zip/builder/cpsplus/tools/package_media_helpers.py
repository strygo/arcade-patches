"""Seal FFmpeg identities and the shared CPS+/Switch offline tools bundle."""
import argparse
import copy
import hashlib
import json
from pathlib import Path
import shutil
import zipfile
from fetch_switch_tools import inventory
HERE = Path(__file__).resolve().parent
HOSTS = {'macos-arm64', 'macos-x86_64', 'windows-x86_64', 'linux-arm64', 'linux-x86_64'}
URL = 'https://github.com/strygo/arcade-patches/releases/download/ffmpeg-helpers-v1'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--host', action='append', required=True, type=Path)
    for n in ('switch-lock', 'switch-archives', 'source', 'out'):
        p.add_argument('--' + n, required=True, type=Path)
    a = p.parse_args()
    if a.out.exists():
        raise ValueError('Fresh helper release output required')
    pin = json.loads((HERE.parent / 'manifests/ffmpeg_source_v1.json').read_text())
    source = a.source.read_bytes()
    if len(source) != pin['source_bytes'] or sha(source) != pin['source_sha256']:
        raise ValueError('Corresponding source archive differs')
    records = {}
    archives = {}
    for folder in a.host:
        record = json.loads((folder / 'record.json').read_text())
        host = record['sources']['host']
        if host not in HOSTS or host in records or record['sources']['source'] != pin:
            raise ValueError('Duplicate, unknown or unpinned producer')
        if set(record['executables']) != {'ffmpeg', 'ffprobe'}:
            raise ValueError('Incomplete media pair')
        data = (folder / record['filename']).read_bytes()
        inventory(data, record)
        record['url'] = URL + '/' + record['filename']
        records[host] = record
        archives[record['filename']] = data
    if set(records) != HOSTS:
        raise ValueError('All five producer hosts required')
    alias = copy.deepcopy(records['windows-x86_64'])
    alias.update(minimum_windows_build=22000, execution='Windows 11 ARM x64 emulation')
    records['windows-arm64'] = alias
    lock = dict(schema=1, release='ffmpeg-helpers-v1', platforms=records)
    switch = json.loads(a.switch_lock.read_text())
    for record in switch['platforms'].values():
        if record['filename'] in archives:
            continue
        data = (a.switch_archives / record['filename']).read_bytes()
        inventory(data, record)
        archives[record['filename']] = data
    a.out.mkdir(parents=True)
    for name, data in archives.items():
        (a.out / name).write_bytes(data)
    (a.out / 'ffmpeg_helpers.json').write_text(json.dumps(lock, indent=2, sort_keys=True) + '\n')
    shutil.copyfile(a.switch_lock, a.out / 'switch_helpers.json')
    (a.out / pin['source_filename']).write_bytes(source)
    (a.out / 'README.txt').write_text('CPS+ and USF2 shared offline tools v2\n\nAdd --tools-bundle cpsplus-tools-v2-offline.zip --offline to the normal build.\nContains the verified Switch helper pair and FFmpeg/ffprobe for all supported hosts.\nEach kit supplies its trusted manifests; bundle metadata never replaces them.\nFFmpeg corresponding source, licenses, configuration and standalone build recipes\nare included. FFmpeg binaries are LGPL 2.1 or later, without GPL/nonfree features.\nLinux requires Ubuntu 24.04+; Windows ARM requires Windows 11 x64 emulation.\nNo games, keys, music or instrument firmware are included.\n')
    files = sorted(a.out.iterdir())
    bundle = a.out / 'cpsplus-tools-v2-offline.zip'
    with zipfile.ZipFile(bundle, 'w', zipfile.ZIP_STORED) as z:
        for f in files:
            info = zipfile.ZipInfo(f.name, (2026, 10, 23, 0, 0, 0))
            info.create_system = 3
            info.external_attr = 33188 << 16
            z.writestr(info, f.read_bytes())
    if bundle.stat().st_size > 256 * 1024 * 1024:
        raise ValueError('Combined bundle exceeds recipient loader limit')
    print('PASS shared offline tools', sha(bundle.read_bytes()), flush=True)
if __name__ == '__main__':
    main()
