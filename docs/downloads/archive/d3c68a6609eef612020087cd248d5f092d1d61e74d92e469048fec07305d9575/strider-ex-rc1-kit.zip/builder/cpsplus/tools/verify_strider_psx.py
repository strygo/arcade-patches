"""Verify Strider PSX packaging, encoded joins, CPS1 routing and native fallback."""
from __future__ import annotations
import argparse
import csv
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import wave
import xml.etree.ElementTree as ET
import zipfile
import zlib
import numpy as np
ROOT = Path(__file__).resolve().parents[2]
CP = ROOT / 'cpsplus'
sys.path.insert(0, str(CP))
sys.path.insert(0, str(CP / 'rtl/tb'))
sys.path.insert(0, str(CP / 'integration'))
from pack import adxcodec, audition
from pack.format import PackReader
from pack.build_strider_psx import pcm_for
from gen_cps1_vectors import Cps1Tables, Run
from verify_mra_pointer import check as check_pointer
from embed_pack_mra import archive_index
NATIVE_CAPTURE = CP / 'work/strider/psx/remix_clean_capture/audio.wav'

def digest(p):
    with Path(p).open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()

def pin(p):
    return dict(file=str(Path(p).relative_to(ROOT)), sha256=digest(p))

def mra_audit():

    def canonical(e):
        return (e.tag, sorted(e.attrib.items()), ''.join((e.text or '').split()), [canonical(c) for c in e])
    results = []
    for base, generated in [('base_us/striderua.mra', 'CPS+/Strider (PSX Soundtrack).mra'), ('base_alt/Strider Hiryu (Japan Resale Ver.).mra', 'CPS+/Japan/Strider Hiryu (PSX Soundtrack, Japan).mra')]:
        bp, gp = (CP / 'mra' / base, CP / 'mra' / generated)
        br, gr = (ET.parse(bp).getroot(), ET.parse(gp).getroot())
        bro, gro = (br.find("rom[@index='0']"), gr.find("rom[@index='0']"))
        n = len(list(bro))
        assert len(list(gro)) == n + 3
        assert [canonical(e) for e in bro] == [canonical(e) for e in list(gro)[:n]]
        for e in br:
            if e.tag not in ['name', 'rbf'] and (not (e.tag == 'rom' and e.get('index') == '0')):
                assert any((canonical(e) == canonical(v) for v in gr.findall(e.tag))), e.tag
        assert gr.findtext('rbf') == 'jtcps1-cpsplus'
        assert gro.attrib == {k: v for k, v in bro.attrib.items() if k not in ['asm_md5', 'md5']}
        crcs = []
        for part in bro.findall('.//part[@name]'):
            name = part.get('name')
            found = None
            for directory in [ROOT / 'roms', ROOT / 'roms/mame0260']:
                for stem in part.get('zip', bro.get('zip')).split('|'):
                    zp = directory / stem
                    data = None
                    if zp.exists():
                        with zipfile.ZipFile(zp) as archive:
                            members = [v for v in archive.namelist() if Path(v).name == name]
                            if members:
                                data = archive.read(members[0])
                    elif zp.with_suffix('.7z').exists() and name in archive_index(Path(stem).stem, [directory]):
                        zp = zp.with_suffix('.7z')
                        data = subprocess.run(['7zz', 'e', '-so', str(zp), name], check=True, capture_output=True).stdout
                    if data is not None:
                        crc = f'{zlib.crc32(data):08x}'
                        if crc == part.get('crc'):
                            found = dict(archive=str(zp.relative_to(ROOT)), name=name, bytes=len(data), crc=crc)
                            break
                if found:
                    break
            assert found, name
            crcs.append(found)
        assert check_pointer(gp, [ROOT / 'roms', ROOT / 'roms/mame0260']) == 'ok'
        results.append(dict(base=pin(bp), mra=pin(gp), setname=gr.findtext('setname'), inherited_content_identical=True, roms=crcs, pointer='0x1541', offset_bytes=5441 * 1024, pad_bytes=960))
    return results

def control_audit():
    results = []
    for region, machine in [('usa', 'striderua'), ('japan', 'striderjr')]:
        for kind in ['music', 'fm', 'oki']:
            paths = [CP / 'work/strider/native' / ('controls_' + region) / (kind + '_baseline'), CP / 'work/strider/psx/package/controls' / (machine + '_' + kind + '_f1')]
            traces = [list(csv.DictReader((p / 'events.tsv').open(), delimiter='\t')) for p in paths]
            when = next((float(v['time']) for v in traces[1] if v['kind'] == 'inject' and int(v['cmd']) == 241))
            waves = []
            for folder in paths:
                with wave.open(str(folder / 'audio.wav')) as f:
                    rate = f.getframerate()
                    x = np.frombuffer(f.readframes(f.getnframes()), '<i2').reshape(-1, f.getnchannels()).astype(float)
                waves.append(x[int((when + 0.5 if kind == 'music' else when) * rate):int((when + 3) * rate)])
            n = min(map(len, waves))
            x, y = [v[:n] for v in waves]
            rms = lambda a: float(np.sqrt(np.mean(a * a)))
            result = dict(region=region, kind=kind, baseline=pin(paths[0] / 'events.tsv'), treatment=pin(paths[1] / 'events.tsv'), baseline_rms=rms(x), substituted_rms=rms(y), pcm_ncc=float(np.sum(x * y) / max(1, np.sqrt(np.sum(x * x) * np.sum(y * y)))))
            if kind == 'music':
                assert rms(x) > 100 and rms(y) == 0
                result['result'] = 'native music stops; tail is digital silence'
            elif kind == 'oki':
                assert np.array_equal(x, y)
                result['result'] = 'native sampled effect remains sample-identical'
            else:
                seq = []
                for trace in traces:
                    seq.append([(int(v['addr'], 16), int(v['data'], 16), float(v['time'])) for v in trace if v['kind'] == 'ym' and float(v['time']) >= when and (int(v['addr'], 16) not in [16, 17, 18, 20])])
                assert [(a, b) for a, b, t in seq[0]] == [(a, b) for a, b, t in seq[1]]
                delays = [abs(a[2] - b[2]) for a, b in zip(*seq)]
                assert delays and max(delays) < 1 / 60
                delta = float(20 * np.log10(rms(y) / rms(x)))
                assert abs(delta) < 0.1
                result.update(result='same FM effect writes; key-off delayed, not truncated', max_write_delay_seconds=max(delays), level_delta_db=delta, ordered_musical_ym_writes_identical=True)
            results.append(result)
    return results

def capture(rd, out, machine):
    folder = out / (machine + '_substituted')
    if (folder / 'completion.json').exists():
        saved = json.loads((folder / 'invocation.json').read_text())
        assert saved['pack_sha256'] == digest(rd.path), 'stale capture for different pack'
        assert json.loads((folder / 'completion.json').read_text())['exit_code'] == 0
        return folder
    folder.mkdir(parents=True, exist_ok=False)
    gate = ','.join((f'[{i}]=true' for i, r in enumerate(rd.triggers) if r.suppress))
    lua = (CP / 'lua/strider_sound_probe.lua').read_text() + f"\nlocal gate={{{gate}}}\nlocal z=manager.machine.devices[':audiocpu'].spaces['program']\nlocal gate_log=assert(io.open(os.getenv('STRIDER_GATE_LOG'),'w'))\ngate_log:write('input,output\\n')\nlocal last=-1\nlocal gate_tap=z:install_read_tap(0xf008,0xf008,'strider_pack_substitute',function(a,d,mask)\n local v=gate[d] and {rd.header.proto.handshake_ready} or d\n if d~=last then gate_log:write(d..','..v..'\\n');gate_log:flush();last=d end\n return v\nend)\nemu.register_frame_done(function() assert(gate_tap) end)\n"
    script = folder / 'probe.lua'
    script.write_text(lua)
    command = [sys.executable, str(ROOT / 'translations/vhunt2/scripts/run_surface_trace.py'), '--machine', machine, '--outdir', str(folder), '--script', str(script), '--schedule', '650-660:COIN1;720-730:START1;1250-4600:P1_JOYSTICK_RIGHT', '--captures', '1000=intro;1500=stage;4000=game_over;4500=continue;4600=end', '--dump-range', '0xff0000:0x10000']
    for arg in ['-nothrottle', '-video', 'none', '-sound', 'none', '-cfg_directory', str(folder / 'cfg'), '-nvram_directory', str(folder / 'nvram'), '-wavwrite', str(folder / 'audio.wav')]:
        command.append('--mame-arg=' + arg)
    env = os.environ | dict(SDL_VIDEODRIVER='dummy', SDL_AUDIODRIVER='dummy', CPSP_REPO=str(ROOT), STRIDER_LOG=str(folder / 'events.tsv'), STRIDER_FREEZE_FRAME='0', STRIDER_CAPTURE_YM='0', STRIDER_EVENTS='', STRIDER_START_STAGE='-1', STRIDER_GATE_LOG=str(folder / 'gate_reads.csv'))
    (folder / 'invocation.json').write_text(json.dumps(dict(command=command, pack_sha256=digest(rd.path), script_sha256=digest(script)), indent=2) + '\n')
    with (folder / 'run.log').open('w') as log:
        p = subprocess.Popen(command, env=env, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        try:
            code = p.wait(timeout=180)
        except subprocess.TimeoutExpired:
            os.killpg(p.pid, signal.SIGTERM)
            try:
                p.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(p.pid, signal.SIGKILL)
                p.wait()
            code = 124
    (folder / 'completion.json').write_text(json.dumps(dict(exit_code=code)) + '\n')
    assert code == 0, folder
    return folder

def native_audit(rd, folder, machine):
    baseline = CP / 'work/strider/native' / f'{machine}_game_over'
    host = []
    for p in [baseline, folder]:
        rows = list(csv.DictReader((p / 'events.tsv').open(), delimiter='\t'))
        host.append([(int(r['frame']), int(r['cmd'])) for r in rows if r['kind'] == 'host' and int(r['frame']) < 4600])
    assert host[0] == host[1], 'suppression changed game-side timing'
    reads = list(csv.DictReader((folder / 'gate_reads.csv').open()))
    for r in reads:
        c, v = (int(r['input']), int(r['output']))
        assert v == (rd.header.proto.handshake_ready if rd.triggers[c].suppress else c)
    for c in [14, 21, 155]:
        assert any((int(r['input']) == c and int(r['output']) == c for r in reads))
    for frame, label in [(4000, 'game_over'), (4500, 'continue')]:
        assert digest(baseline / f'{machine}_{frame}_scene_{frame}.png') == digest(folder / f'{machine}_{frame}_{label}.png')
    return dict(machine=machine, host_events=len(host[0]), host_timing_identical=True, native_game_over_continue_laugh_preserved=True, scene_pixels_identical=True, baseline=pin(baseline / 'events.tsv'), invocation=pin(folder / 'invocation.json'), trace=pin(folder / 'events.tsv'), reads=pin(folder / 'gate_reads.csv'))

def rtl_audit(rd, out):
    binary = out / 'tap.vvp'
    subprocess.run(['iverilog', '-g2005', '-o', str(binary), str(CP / 'rtl/tb/tb_cps1_tap.v'), str(CP / 'rtl/cpsplus_cps1_tap.v')], check=True)
    results = []
    tab = Cps1Tables(rd.header.proto, rd.triggers)
    for machine in ['striderua', 'striderjr']:
        run = Run(tab)
        with (CP / f'work/strider/native/{machine}_game_over/events.tsv').open() as f:
            for r in csv.DictReader(f, delimiter='\t'):
                if r['kind'] == 'host':
                    run.drive(int(r['frame']), int(r['cmd']))
        paths = run.dump(out, machine)
        command = ['vvp', str(binary), f'+NAME={machine}', f'+IDLE={rd.header.proto.handshake_ready:02x}'] + [f'+{k.upper()}={v}' for k, v in paths.items()]
        p = subprocess.run(command, capture_output=True, text=True, check=True)
        (out / f'{machine}_tap.log').write_text(p.stdout + p.stderr)
        assert 'PASS' in p.stdout and 'FAIL' not in p.stdout, p.stdout[-1000:]
        results.append(dict(machine=machine, stimuli=len(run.stim), events=len(run.gold), log=pin(out / f'{machine}_tap.log')))
    return results

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--pack', type=Path, default=CP / 'work/packs/strider_psx.cpk')
    p.add_argument('--outdir', type=Path, default=CP / 'work/strider/psx/package/verification')
    p.add_argument('--capture-native', action='store_true')
    a = p.parse_args()
    a.pack = a.pack.resolve()
    a.outdir = a.outdir.resolve()
    a.outdir.mkdir(parents=True, exist_ok=True)
    recipe = json.loads((CP / 'manifests/strider_psx_audio.json').read_text())
    rd = PackReader(a.pack)
    rd.path = a.pack.resolve()
    assert audition.verify(str(a.pack), quick=True)
    assert len(rd.tracks) == 10 and len(rd.triggers) == 256
    assert rd.header.proto.handshake_ready == 241
    assert rd.header.proto.control_verbs == {240: 2, 241: 2}
    for c in range(256):
        r = rd.triggers[c]
        expected = next((v for v in recipe['triggers'] if int(v['command'], 16) == c), None)
        verb = 1 if expected and expected['track'] else 2 if expected and expected['stop_arranged'] else 0
        assert r.verb == verb and r.suppress == (verb == 1), (c, r)
        if verb == 1:
            assert r.track == int(expected['track'][-2:]) - 1 and r.gain == recipe['trigger_gain']
    audio = []
    for i, (m, row) in enumerate(zip(rd.tracks, recipe['tracks'])):
        source = pcm_for(row, NATIVE_CAPTURE)
        n = len(source) // 4
        decoded = adxcodec.decode(rd.read_track(i), 2, 48000, total_samples=n)
        x = np.frombuffer(source, '<i2').astype(float).reshape(-1, 2)
        y = np.frombuffer(decoded, '<i2').astype(float).reshape(-1, 2)
        snr = float(10 * np.log10(np.sum(x * x) / max(1, np.sum((y - x) ** 2))))
        assert snr > 25, (i, snr)
        assert (m.loop_start_sample, m.loop_end_sample) == (row['loop_start'], row['loop_end'])
        assert not m.xfade_enable and m.loop_end_byte == m.data_length
        ls, le = (m.loop_start_sample, m.loop_end_sample)
        step = float(np.max(abs(y[le - 1] - y[ls])))
        context = max(float(np.max(abs(np.diff(y[le - 480:le], axis=0)))), float(np.max(abs(np.diff(y[ls:ls + 480], axis=0)))))
        assert step <= context + 256, (i, step, context)
        rendered, _ = audition.render(rd, i, loops=2)
        body = (le - ls) * 4
        assert rendered[le * 4:le * 4 + body] == rendered[le * 4 + body:le * 4 + 2 * body]
        audition.audition(str(a.pack), track=i, out=str(a.outdir / f"{row['id']}_encoded.wav"), loops=2)
        audio.append(dict(id=row['id'], snr_db=snr, join_step=step, nearby_max_step=context, repeated_loops_identical=True, preview=pin(a.outdir / f"{row['id']}_encoded.wav")))
    rtl = rtl_audit(rd, a.outdir)
    native = []
    if a.capture_native:
        for machine in ['striderua', 'striderjr']:
            print('Native substitution:', machine, flush=True)
            native.append(native_audit(rd, capture(rd, a.outdir, machine), machine))
    report = dict(status='pass', pack=pin(a.pack), audio=audio, rtl=rtl, native=native, mras=mra_audit(), controls=control_audit(), limits=['MAME verifies native suppression/fallback; FPGA mixer and final hardware remain playtest gates.'])
    rd.close()
    (a.outdir / 'verification.json').write_text(json.dumps(report, indent=2) + '\n')
    print('Strider PSX verification passed', flush=True)
if __name__ == '__main__':
    main()
