"""Catalog the Captain Commando (PlayStation, 1998) music from the disc."""
from __future__ import annotations
import argparse
import json
import struct
import sys
import wave
from pathlib import Path
HERE = Path(__file__).resolve()
PKG = HERE.parents[1]
sys.path.insert(0, str(PKG))
from pack import psx_xa
OUT = PKG / 'manifests' / 'captcomm_psx_source_catalog.json'
WAV_DIR = PKG / 'work' / 'captcomm' / 'psx' / 'xa'
EXE_PATH = '/CAP.EXE'
EXE_LOAD = 2147549184
NAME_TABLE = 2147554352
MUSIC_TABLE = 2147553080
MUSIC_IDS = range(128, 159)
ARRANGE_SKIP_ID = 158
PLAY_ROUTINE = {2147802408: 270528, 2147802412: 1006796801, 2147802416: 608309048, 2147802424: 333888, 2147802436: 2489516036, 2147802480: 2424438785, 2147802488: 4526113, 2147802500: 2424504322}
ROLES = {128: 'Game Start', 129: 'Stage 1 (City)', 130: 'Stage 2 (Museum)', 131: 'Stage 3 (Ninja House)', 132: 'Stage 4-1 (Circus Camp)', 133: 'Stage 5 (Sea Port)', 134: 'Stage 6 (Aquarium)', 135: 'Stage 7 (Underground Base)', 136: "Stage 8 (Enemy's Spaceship)", 137: 'Stage 9 (Callisto)', 138: 'Stage Clear', 139: 'Continue', 140: 'Game Over', 141: 'Name Entry', 142: 'Player Select', 143: 'Ending', 147: 'Boss 1 (Dolg)', 148: 'Boss 2 (Shtrom Jr.)', 149: 'Boss 3 (Yamato)', 150: 'Boss 4 (Monster)', 151: 'Boss 5 (Dr. T.W.)', 152: 'Boss 6 (Shtrom & Druk)', 153: 'Boss 7 (Blood)', 154: 'Boss 8 (Doppelganger)', 155: 'Room of Final Boss', 156: 'Stage 4-2 (Colosseum)', 157: 'Final Boss (Genocide)', 158: 'Credits Roll'}

def exe_word(exe: bytes, addr: int) -> int:
    return struct.unpack_from('<I', exe, addr - EXE_LOAD + 2048)[0]

def read_tables(exe: bytes) -> tuple[list[str], list[dict]]:
    if exe[:8] != b'PS-X EXE' or struct.unpack_from('<I', exe, 24)[0] != EXE_LOAD:
        raise ValueError('CAP.EXE is not a PS-X EXE loaded at 0x80010000')
    for addr, word in PLAY_ROUTINE.items():
        if exe_word(exe, addr) != word:
            raise ValueError(f'CAP.EXE play routine differs at {addr:#x}: {exe_word(exe, addr):#010x} != {word:#010x}')
    names = []
    for i in range(10):
        p = exe_word(exe, NAME_TABLE + 4 * i) - EXE_LOAD + 2048
        names.append(exe[p:exe.index(b'\x00', p)].decode('ascii'))
    rows = []
    for mid in MUSIC_IDS:
        off = MUSIC_TABLE + 8 * mid - EXE_LOAD + 2048
        f, ch, loop, _pad, n_orig, n_arr = struct.unpack_from('<BBBBHH', exe, off)
        rows.append({'id': mid, 'file': names[f], 'channel': ch, 'loop': loop, 'sectors': [n_orig, n_arr]})
    return (names, rows)

def write_wav(path: Path, pcm, rate: int) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with wave.open(str(path), 'wb') as w:
        w.setnchannels(pcm.shape[1])
        w.setsampwidth(2)
        w.setframerate(rate)
        w.writeframes(pcm.astype('<i2').tobytes())

def stream_record(xa: psx_xa.XaFile, channel: int, end: int, wav_dir: Path | None) -> dict:
    s = xa.stream(channel)
    pcm = s.decode()
    stem = f"{xa.path.rsplit('/', 1)[-1].split('.')[0]}_ch{channel}"
    if wav_dir:
        write_wav(wav_dir / f'{stem}.wav', pcm, s.rate)
    return {'channel': channel, 'sectors': len(s.sectors), 'rate': s.rate, 'stereo': s.stereo, 'frames': s.frames, 'seconds': round(s.frames / s.rate, 3), 'first_position': s.positions[0], 'last_position': s.positions[-1], 'eof_positions': s.eof, 'table_end_position': end - 1, 'sectors_after_table_end': sum((p > end - 1 for p in s.positions)), 'raw_sha256': psx_xa.hashlib.sha256(s.raw()).hexdigest(), 'pcm_sha256': psx_xa.pcm_sha256(pcm), 'wav': f'{stem}.wav'}

def build(disc: Path, wav_dir: Path | None) -> dict:
    img = psx_xa.disc_image(disc)
    d = psx_xa.XaDisc(img)
    exe = d.iso.read_file(EXE_PATH)
    names, rows = read_tables(exe)
    files: dict[str, psx_xa.XaFile] = {}
    out_rows = []
    for r in rows:
        if r['sectors'] == [0, 0]:
            out_rows.append({'id': f"{r['id']:#04x}", 'unused': True})
            continue
        path = f"/XA/{r['file']}.XA"
        xa = files.get(path) or files.setdefault(path, d.xa_file(path))
        rec = {'id': f"{r['id']:#04x}", 'role_proposed': ROLES.get(r['id']), 'file': path, 'loop': bool(r['loop']), 'table_sectors': {'original': r['sectors'][0], 'arranged': r['sectors'][1]}, 'original': stream_record(xa, r['channel'], r['sectors'][0], wav_dir)}
        if r['sectors'][1]:
            rec['arranged'] = stream_record(xa, r['channel'] + 1, r['sectors'][1], wav_dir)
        else:
            rec['arranged'] = None
        if r['id'] == ARRANGE_SKIP_ID:
            rec['arrange_mode'] = 'play routine returns without playing: the previous music (the arranged Ending) continues'
        out_rows.append(rec)
        arr_ch = f"/{r['channel'] + 1}" if rec['arranged'] else '  '
        print(f"{rec['id']} {path:16} ch{r['channel']}{arr_ch} {rec['original']['seconds']:7.1f}s / {(rec['arranged']['seconds'] if rec['arranged'] else 0):7.1f}s  {rec['role_proposed']}", flush=True)
    used = {(o['file'], o[k]['channel']) for o in out_rows if not o.get('unused') for k in ('original', 'arranged') if o.get(k)}
    orphans = [f'{p} ch{c}' for p, xa in files.items() for c in xa.channels() if (p, c) not in used]
    return {'schema': 1, 'title': 'Captain Commando (PlayStation, Japan, SLPS-01567)', 'status': 'source cataloged; roles proposed from rip titles, pending the arcade census', 'disc': {'image_sha256': psx_xa.sha256_file(img), 'exe': EXE_PATH, 'exe_sha256': psx_xa.hashlib.sha256(exe).hexdigest()}, 'routing': {'play_routine': '0x8004dd28', 'music_table': f'{MUSIC_TABLE:#x}', 'name_table': f'{NAME_TABLE:#x}', 'arrange_flag': '0x8019e7a2', 'channel_rule': 'record channel + arrange flag', 'arrange_skip_id': f'{ARRANGE_SKIP_ID:#04x}', 'xa_files': names}, 'unreferenced_streams': orphans, 'music': out_rows}

def self_test(disc: Path | None) -> int:
    sec = bytearray(psx_xa.SYNC + b'\x00\x00\x00\x02' + bytes([1, 4, 100, 1] * 2))
    for g in range(18):
        grp = bytearray(128)
        grp[4:12] = bytes([36] * 8)
        for j in range(112):
            grp[16 + j] = j * 37 + g & 255
        sec += grp
    sec += bytes(2352 - len(sec))
    s = psx_xa.XaStream('synthetic', 4, [0, 8], [bytes(sec)] * 2)
    ref = psx_xa.decode_reference(s.raw())
    ok = (s.decode() == ref).all()
    print(f'synthetic sectors: FFmpeg == reference decoder: {ok}')
    if not ok:
        return 1
    if disc:
        d = psx_xa.XaDisc(psx_xa.disc_image(disc))
        names, rows = read_tables(d.iso.read_file(EXE_PATH))
        assert names[0] == 'ETC1' and names[-1] == 'LAST', names
        st = d.xa_file('/XA/ETC1.XA').stream(4)
        ok = (st.decode() == psx_xa.decode_reference(st.raw())).all()
        print(f"disc ETC1 ch4: FFmpeg == reference decoder: {ok}; {sum((r['sectors'] != [0, 0] for r in rows))} table rows in use")
        if not ok:
            return 1
    return 0

def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--disc', type=Path, help='.chd, .cue or raw .bin of SLPS-01567')
    ap.add_argument('--out', type=Path, default=OUT)
    ap.add_argument('--wav-dir', type=Path, default=WAV_DIR)
    ap.add_argument('--no-wav', action='store_true')
    ap.add_argument('--self-test', action='store_true')
    a = ap.parse_args()
    if a.self_test:
        return self_test(a.disc)
    if not a.disc:
        ap.error('--disc is required')
    cat = build(a.disc, None if a.no_wav else a.wav_dir)
    a.out.write_text(json.dumps(cat, indent=1) + '\n')
    print(f'wrote {a.out}')
    return 0
if __name__ == '__main__':
    sys.exit(main())
