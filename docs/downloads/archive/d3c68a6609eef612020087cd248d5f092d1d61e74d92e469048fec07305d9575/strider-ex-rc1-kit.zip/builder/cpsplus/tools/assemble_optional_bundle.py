"""Assemble the review offline tools ZIP from authenticated component records."""
import argparse
import hashlib
import json
from pathlib import Path
import urllib.request
import zipfile
HERE = Path(__file__).resolve().parent

def main(a):
    if a.out.exists():
        raise ValueError('Fresh output required')
    records = {}
    files = {}
    for manifest in ('ffmpeg_helpers_v1.json', 'switch_helpers_v1.json', 'optional_helpers_v1.json'):
        data = (HERE.parent / 'manifests' / manifest).read_bytes()
        lock = json.loads(data)
        platforms = [lock['platforms']] if 'platforms' in lock else [x['platforms'] for x in lock['components'].values()]
        for cohort in platforms:
            for record in cohort.values():
                previous = records.setdefault(record['filename'], record)
                if previous['sha256'] != record['sha256']:
                    raise ValueError('Conflicting archive name')
        files[manifest] = data
    a.cache.mkdir(parents=True, exist_ok=True)
    source = json.loads((HERE.parent / 'manifests/ffmpeg_source_v1.json').read_text())
    source_path = a.cache / source['source_filename']
    if not source_path.is_file():
        with urllib.request.urlopen(source['source_url'], timeout=90) as response:
            source_path.write_bytes(response.read(source['source_bytes'] + 1))
    data = source_path.read_bytes()
    if len(data) != source['source_bytes'] or hashlib.sha256(data).hexdigest() != source['source_sha256']:
        raise ValueError('FFmpeg corresponding source identity differs')
    (a.out.parent / source['source_filename']).write_bytes(data)
    for name, pin in records.items():
        path = a.cache / name
        if not path.is_file():
            with urllib.request.urlopen(pin['url'], timeout=90) as response:
                data = response.read(pin['bytes'] + 1)
            path.write_bytes(data)
        data = path.read_bytes()
        if len(data) != pin['bytes'] or hashlib.sha256(data).hexdigest() != pin['sha256']:
            raise ValueError('Archive identity differs: ' + name)
        files[name] = data
    files['README.txt'] = 'Shared offline tools v3 — prepared for review, not published.\nFFmpeg/ffprobe, Switch helpers, MIDI tools, chdman and reduced 7-Zip.\nPass --tools-bundle /path/to/this.zip --offline to a compatible kit.\nEach kit retains its trusted manifest and installs only requested components.\nOriginal licenses, notices and producer recipes are inside each archive.\nSC-55 uses the original MAME noncommercial license.\nKeep optional-helpers-v1-sources.zip and the existing FFmpeg/Switch\ncorresponding source downloads available beside the binaries.\nPython wheels are separate and specific to interpreter ABI/architecture.\nNo game data, keys or instrument firmware are included.\n'.encode()
    with zipfile.ZipFile(a.out, 'w', compression=zipfile.ZIP_STORED) as z:
        for name, data in sorted(files.items()):
            i = zipfile.ZipInfo(name, (2026, 10, 24, 0, 0, 0))
            i.external_attr = 33188 << 16
            z.writestr(i, data)
    if a.out.stat().st_size > 256 * 1024 * 1024:
        raise ValueError('Offline bundle exceeds recipient limit')
    print('PREPARED', a.out.stat().st_size, 'bytes', len(records), 'component archives')
if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--cache', type=Path, required=True)
    p.add_argument('--out', type=Path, required=True)
    main(p.parse_args())
