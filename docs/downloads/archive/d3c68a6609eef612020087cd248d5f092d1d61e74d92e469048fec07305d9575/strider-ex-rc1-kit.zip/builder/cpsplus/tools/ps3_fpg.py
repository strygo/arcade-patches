"""FG03 ('30GF') container (SSF2T HD Remix PS3 flog_ps3.fpg) extractor."""
import struct, sys, os, zlib, collections
p, outdir = (sys.argv[1], sys.argv[2])
data = open(p, 'rb').read()
n = len(data)
count = struct.unpack('<I', data[4:8])[0]
os.makedirs(outdir, exist_ok=True)
stats = collections.Counter()
magics = collections.Counter()
bad = 0
rows = []
for i in range(count):
    h, off, stored, real = struct.unpack('<IIII', data[4096 + i * 16:4096 + i * 16 + 16])
    if stored == 0 or off + stored > n or off < 100848:
        bad += 1
        continue
    blob = data[off:off + stored]
    comp = blob[:2] == b'x\x9c'
    if comp:
        try:
            out = zlib.decompressobj().decompress(blob)
        except Exception as e:
            stats['zlib_fail'] += 1
            out = blob
    else:
        out = blob[:real] if real <= stored else blob
    stats['comp' if comp else 'raw'] += 1
    magics[out[:4]] += 1
    name = f'{i:04d}_{h:08x}.bin'
    open(os.path.join(outdir, name), 'wb').write(out)
    rows.append((i, h, off, stored, real, comp, len(out), out[:8].hex()))
print('rows', count, 'bad', bad, dict(stats))
print('magics top:')
for m, c in magics.most_common(30):
    print('  ', m, c)
with open(os.path.join(outdir, '_index.tsv'), 'w') as w:
    w.write('idx\thash\toff\tstored\treal\tcomp\tout_len\thead\n')
    for r in rows:
        w.write('\t'.join((str(x) for x in r)) + '\n')
