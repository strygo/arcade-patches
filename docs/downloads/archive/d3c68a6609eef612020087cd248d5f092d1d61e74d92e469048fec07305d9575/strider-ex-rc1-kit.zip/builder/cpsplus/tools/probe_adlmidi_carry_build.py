"""Experimental source-bound OPL carry/FMA probe; never package its DLL as qualified."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import build_optional_helpers as producer

def main(a):
    if a.root.exists() or a.out.exists():
        raise ValueError('Fresh experiment required')
    a.root = a.root.absolute()
    a.sources = a.sources.absolute()
    a.root.mkdir(parents=True)
    pins = json.loads((Path(__file__).resolve().parent.parent / 'manifests/optional_helpers_sources_v1.json').read_text())['sources']
    a.source_pins = pins
    source = producer.source('adlmidi', a, pins)
    cpp = source / 'src/adlmidi.cpp'
    text = cpp.read_text()
    old = 'setup.carry += double(setup.PCM_RATE) * eat_delay;'
    if text.count(old) != 2:
        raise ValueError('Unexpected source carry sites')
    if a.mode == 'fused':
        text = text.replace(old, 'setup.carry = ::fma(double(setup.PCM_RATE), eat_delay, setup.carry);')
    cpp.write_text('/* Experimental FMA timing probe, 2026-10-24. Not a release. */\n' + text)
    producer.adlmidi_timing_adapter = lambda _: None
    os.environ['SOURCE_DATE_EPOCH'] = '1792828800'
    binaries = producer.build('adlmidi', source, a)
    a.out.mkdir(parents=True)
    library = binaries['adlmidi']
    shutil.copyfile(library, a.out / library.name)
    (a.out / 'probe.json').write_text(json.dumps(dict(source=pins['adlmidi'], mode=a.mode, modified_source_sha256=hashlib.sha256(cpp.read_bytes()).hexdigest(), library_sha256=hashlib.sha256(library.read_bytes()).hexdigest(), recipe_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()), indent=2) + '\n')
    print('BUILT experimental carry library; runtime equivalence not yet established')
if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    for name in ('root', 'out', 'sources'):
        p.add_argument('--' + name, type=Path, required=True)
    p.add_argument('--host', choices=('windows-x86_64', 'macos-arm64'), required=True)
    p.add_argument('--jobs', type=int, default=2)
    p.add_argument('--mode', choices=('baseline', 'fused'), default='fused')
    main(p.parse_args())
