"""Find the exact musical repeat in an album track and propose loop points."""
from __future__ import annotations
import argparse, subprocess, sys
from pathlib import Path
import numpy as np
RATE = 44100
COARSE = 10
PROBE_S = 20.0
MATCH_NCC = 0.95

def decode_mono(path: Path) -> np.ndarray:
    out = subprocess.run(['ffmpeg', '-v', 'error', '-i', str(path), '-f', 'f32le', '-acodec', 'pcm_f32le', '-ac', '1', '-ar', str(RATE), '-'], capture_output=True, check=True).stdout
    return np.frombuffer(out, dtype='<f4').astype(np.float64)

def ncc(a: np.ndarray, b: np.ndarray) -> float:
    a = a - a.mean()
    b = b - b.mean()
    d = float(np.sqrt((a * a).sum() * (b * b).sum()))
    return float((a * b).sum() / d) if d > 0 else 0.0

def _coarse_lag(x, a, w, min_lag_s):
    """Best (ncc, lag) for a probe at sample a, searched at COARSE rate."""
    n = x.size
    probe = x[a:a + w:COARSE]
    hay = x[::COARSE]
    lo = (a + int(min_lag_s * RATE)) // COARSE
    hi = min((a + int(0.85 * n)) // COARSE, hay.size - probe.size)
    if hi <= lo:
        return None
    p = probe - probe.mean()
    pn = np.sqrt((p * p).sum())
    h = hay[lo:hi + probe.size]
    nfft = 1 << int(np.ceil(np.log2(h.size + p.size)))
    c = np.fft.irfft(np.fft.rfft(h, nfft) * np.conj(np.fft.rfft(p, nfft)), nfft)[:h.size - p.size + 1]
    csum = np.cumsum(np.concatenate(([0.0], h ** 2)))
    e = csum[p.size:p.size + c.size] - csum[:c.size]
    v = c / (pn * np.sqrt(np.maximum(e, 0.0)) + 1e-12)
    best_lag = int(np.argmax(v))
    return (float(v[best_lag]), (lo + best_lag) * COARSE - a)

def find_loop(x: np.ndarray, min_lag_s: float):
    n = x.size
    dur = n / RATE
    w = int(PROBE_S * RATE)
    best = None
    for frac in (0.15, 0.25, 0.35, 0.45):
        a = int(frac * n)
        if a + w >= n:
            continue
        r = _coarse_lag(x, a, w, min_lag_s)
        if r and (best is None or r[0] > best[0]):
            best = (r[0], r[1], a)
    if best is None:
        return None
    _, L_coarse, a = best
    span = 1200
    seg = x[a:a + w]
    best_v, L = (-1.0, L_coarse)
    for lag in range(max(int(min_lag_s * RATE), L_coarse - span), L_coarse + span):
        if a + lag + w > n:
            break
        v = ncc(seg, x[a + lag:a + lag + w])
        if v > best_v:
            best_v, L = (v, lag)
    sec = RATE
    ok = []
    for t in range(0, n - L - sec, sec):
        ok.append(ncc(x[t:t + sec], x[t + L:t + L + sec]) >= MATCH_NCC)
    ls_sec = None
    for i in range(len(ok) - 2):
        if ok[i] and ok[i + 1] and ok[i + 2]:
            ls_sec = i
            break
    if ls_sec is None:
        return {'lag': L, 'peak': best_v, 'ls': None}
    ls = (ls_sec * sec + 31) // 32 * 32
    seam_exact = ncc(x[ls + L:ls + L + 3 * sec], x[ls:ls + 3 * sec])
    le = (ls + L + 16) // 32 * 32
    return {'lag': L, 'peak': best_v, 'ls': ls, 'le': le, 'seam': seam_exact, 'dur': dur}

def lag_tol_ncc(a: np.ndarray, b: np.ndarray, tol: int) -> float:
    """max NCC of a vs b over relative lags +/-tol (content match, phase-blind)."""
    best = -1.0
    for lag in range(-tol, tol + 1, 8):
        if lag >= 0:
            aa, bb = (a[lag:], b[:b.size - lag])
        else:
            aa, bb = (a[:a.size + lag], b[-lag:])
        m = min(aa.size, bb.size)
        v = ncc(aa[:m], bb[:m])
        if v > best:
            best = v
    return best

def fade_onset_mono(x: np.ndarray) -> int:
    blk = RATE // 2
    n = x.size // blk
    if n < 8:
        return x.size
    e = np.array([np.sqrt((x[i * blk:(i + 1) * blk] ** 2).mean()) for i in range(n)])
    body = np.median(e[n // 4:n // 2]) or 1.0
    i = n - 1
    while i > n // 2 and e[i] < body * 0.55:
        i -= 1
    return min((i + 1) * blk, x.size)

def best_splice(x: np.ndarray):
    """Single-pass fallback: keep le at the fade onset, choose the ls whose"""
    le = fade_onset_mono(x) // 32 * 32
    tail = x[le:le + 2 * RATE]
    if tail.size < RATE:
        le = (x.size - 2 * RATE) // 32 * 32
        tail = x[le:le + 2 * RATE]
    tol = int(0.045 * RATE)
    best, best_ls = (-1.0, 0)
    for ls in range(0, le - 20 * RATE, RATE // 4):
        v = lag_tol_ncc(x[ls:ls + 2 * RATE], tail, tol)
        if v > best:
            best, best_ls = (v, ls)
    return {'ls': (best_ls + 31) // 32 * 32, 'le': le, 'score': best}

def main(argv=None) -> int:
    global RATE
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('files', nargs='+')
    ap.add_argument('--tsv')
    ap.add_argument('--min-lag', type=float, default=15.0)
    ap.add_argument('--rate', type=int, default=44100, help="analysis rate; pass the source's own rate (e.g. 37800 for PSX XA) to get loop points in its native samples")
    a = ap.parse_args(argv)
    RATE = a.rate
    rows = []
    for f in a.files:
        p = Path(f)
        x = decode_mono(p)
        r = find_loop(x, a.min_lag)
        name = p.stem.split('.')[0]
        if r is None or r['ls'] is None:
            s = best_splice(x)
            print(f"{p.name}: no repeat (peak {(0 if r is None else r['peak']):.3f}) -> SPLICE ls {s['ls'] / RATE:6.2f}s le {s['le'] / RATE:7.2f}s match {s['score']:.3f}")
            rows.append((name, str(s['ls']), str(s['le']), '-', f"{s['score']:.4f}", 'SPLICE'))
            continue
        v = 'REPEAT' if r['seam'] >= MATCH_NCC else 'WEAK'
        print(f"{p.name}: lag {r['lag'] / RATE:7.2f}s  ls {r['ls'] / RATE:6.2f}s  le {r['le'] / RATE:7.2f}s  seam NCC {r['seam']:.4f}  {v}")
        rows.append((name, str(r['ls']), str(r['le']), f"{r['lag'] / RATE:.2f}", f"{r['seam']:.4f}", v))
    if a.tsv:
        with open(a.tsv, 'w') as f:
            f.write('track\tls\tle\tlag_s\tseam_ncc\tverdict\n')
            for row in rows:
                f.write('\t'.join(row) + '\n')
        print(f'wrote {a.tsv}')
    return 0
if __name__ == '__main__':
    sys.exit(main())
