"""Build the Captain Commando PSX arrangement listening review, from nothing."""
from __future__ import annotations
import argparse
import concurrent.futures as cf
import hashlib
import html
import importlib.util
import json
import subprocess
import sys
import wave
from pathlib import Path
import numpy as np
HERE = Path(__file__).resolve().parent
PKG = HERE.parent
sys.path.insert(0, str(PKG))
sys.path.insert(0, str(HERE))
from pack import loop_bake, xfade
import captcomm_census as census
_spec = importlib.util.spec_from_file_location('frl', HERE / 'find_repeat_loop.py')
frl = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(frl)
RATE = 37800
XFADE_N = 44096
PREVIEW_S = 12
OUT = PKG / 'manifests' / 'captcomm_psx_loop_candidates.json'
DECISIONS = PKG / 'manifests' / 'captcomm_psx_listening_decisions.json'
ONE_SHOT_R2 = {'0x8d': 'the master never repeats and the arcade leaves name entry after ~20 s, long before its 99 s run out'}
ENDING_TO_CREDITS_S = 25.86
CREDITS_TO_GAME_OVER_S = 39.47
WEAK_JOIN = {'0x8c': 'ranks 2nd behind Game Start (both ~5 s jingles)', '0x8e': 'ranks 9th: envelope match is weak', '0x9b': 'first by only 0.001'}

def read(path: Path) -> np.ndarray:
    with wave.open(str(path)) as w:
        assert w.getframerate() == RATE
        return np.frombuffer(w.readframes(w.getnframes()), '<i2').reshape(-1, w.getnchannels())

def write(path: Path, pcm: np.ndarray, rate: int=RATE) -> str:
    pcm = np.ascontiguousarray(pcm, '<i2')
    if pcm.ndim == 1:
        pcm = pcm[:, None]
    with wave.open(str(path), 'wb') as w:
        w.setnchannels(pcm.shape[1])
        w.setsampwidth(2)
        w.setframerate(rate)
        w.writeframes(pcm.tobytes())
    return hashlib.sha256(pcm.tobytes()).hexdigest()

def find(pcm: np.ndarray) -> dict:
    frl.RATE = RATE
    x = pcm.astype(np.float64).mean(1) / 32768
    min_lag = 15.0 if len(x) > 40 * RATE else 5.0
    fade = frl.fade_onset_mono(x)
    r = frl.find_loop(x, min_lag)
    if r and r['ls'] is not None and (r['seam'] >= frl.MATCH_NCC) and (r['le'] + XFADE_N <= fade):
        return {'mode': 'repeat', 'ls': r['ls'], 'le': r['le'], 'lag_s': round(r['lag'] / RATE, 3), 'lag_samples': r['lag'], 'seam_ncc': round(r['seam'], 4), 'fade_onset': fade}
    s = frl.best_splice(x)
    le = min(s['le'], (len(x) - XFADE_N) // 32 * 32)
    return {'mode': 'splice', 'ls': s['ls'], 'le': le, 'match': round(s['score'], 4), 'fade_onset': fade, 'repeat_probe': None if r is None else {'lag_s': round(r['lag'] / RATE, 3), 'peak': round(r['peak'], 4)}}

def baked_loop(pcm: np.ndarray, lp: dict) -> dict:
    """Round 2: the sample-exact join for a flagged row."""
    x = loop_bake.mono(pcm)
    limit = lp['fade_onset'] - RATE // 2
    if lp['mode'] == 'repeat':
        ls0, lag, score, how = (lp['ls'], lp['lag_samples'], lp['seam_ncc'], 'second pass')
    else:
        body = 10.0 if len(x) < 40 * RATE else 20.0
        h = loop_bake.phrase_search(x, RATE, limit, body)
        ls0, how = (h['ls'], 'matching phrase')
        lag, score = loop_bake.exact_lag(x, h['ls'], h['le'] - h['ls'], RATE)
    w = loop_bake.best_wrap(x, ls0 - 2 * RATE, ls0 + 4 * RATE, lag, limit)
    cont = loop_bake._ncc(x[w['le']:w['le'] + 3 * RATE], x[w['ls']:w['ls'] + 3 * RATE])
    return {'mode': 'baked', 'found_by': how, 'ls': w['ls'], 'le': w['le'], 'lag_samples': lag, 'lag_s': round(lag / RATE, 3), 'match': round(score, 4), 'continuation_ncc': round(cont, 4), 'grid_offset': w['offset'], 'blend_samples': w['blend_n'], 'blend_cost': round(w['cost'], 5), 'hardware_crossfade': False, 'fade_onset': lp['fade_onset']}

def baked_preview(pcm: np.ndarray, ls: int, le: int) -> np.ndarray:
    stored = loop_bake.bake(pcm, ls, le)
    return np.concatenate([stored[max(0, le - PREVIEW_S * RATE):le], pcm[ls:ls + PREVIEW_S * RATE]])

def seam_preview(pcm: np.ndarray, ls: int, le: int) -> np.ndarray:
    """PREVIEW_S before the wrap, the player's crossfade, PREVIEW_S after."""
    lut = xfade.make_lut(XFADE_N)
    a = max(0, le - PREVIEW_S * RATE)
    blend = np.empty((XFADE_N, 2), np.int16)
    for k in range(XFADE_N):
        t, h = (pcm[le + k], pcm[ls + k])
        blend[k] = xfade.blend_pair(int(t[0]), int(t[1]), int(h[0]), int(h[1]), k, lut, XFADE_N)
    after = pcm[ls + XFADE_N:ls + XFADE_N + PREVIEW_S * RATE]
    return np.concatenate([pcm[a:le], blend, after])

def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--disc', type=Path, required=True)
    ap.add_argument('--work', type=Path, required=True)
    ap.add_argument('--out', type=Path, default=OUT)
    a = ap.parse_args()
    if a.work.exists() and any(a.work.iterdir()):
        ap.error(f'{a.work} is not empty: the review builds from nothing')
    xa, page, audio = (a.work / 'xa', a.work / 'review', a.work / 'review' / 'audio')
    audio.mkdir(parents=True)
    cat_path = a.work / 'catalog.json'
    subprocess.run([sys.executable, str(HERE / 'captcomm_psx_xa_catalog.py'), '--disc', str(a.disc), '--out', str(cat_path), '--wav-dir', str(xa)], stdout=subprocess.DEVNULL, check=True)
    cat = json.loads(cat_path.read_text())
    r1 = json.loads(DECISIONS.read_text())['rounds'][0]
    flagged = set(r1['fades_at_join']) | set(r1['crossfade_audible'])
    music = {m['id']: m for m in cat['music'] if not m.get('unused')}

    def arcade(cmd: str) -> str:
        o = census.inject('captcommu', a.work / 'arcade' / cmd, cmd[2:], slot=3700)
        x, r = census.pcm(o / 'audio.wav')
        t = census.markers(o)[0]
        return write(audio / f'{cmd}_arcade.wav', x[int(t * r):int((t + 60) * r)], r)
    with cf.ThreadPoolExecutor(4) as ex:
        arc = dict(zip(music, ex.map(arcade, music)))
    rows = []
    for cmd, m in music.items():
        row = {'cmd': cmd, 'role': m['role_proposed'], 'psx_loop_flag': m['loop'], 'arcade_sha256': arc[cmd], 'join_note': WEAK_JOIN.get(cmd)}
        orig = read(xa / m['original']['wav'])
        row['original_sha256'] = write(audio / f'{cmd}_psx_original.wav', orig)
        if not m['arranged']:
            row['arranged'] = None
            row['proposal'] = 'native arcade music: the disc has no arrangement'
            rows.append(row)
            continue
        arr = read(xa / m['arranged']['wav'])
        row['arranged'] = {'stream': m['arranged']['wav'], 'pcm_sha256': m['arranged']['pcm_sha256'], 'frames': len(arr), 'seconds': round(len(arr) / RATE, 3)}
        write(audio / f'{cmd}_psx_arranged.wav', arr)
        row['round2'] = cmd in flagged
        if cmd in ONE_SHOT_R2:
            row['proposal'] = 'one-shot'
            row['one_shot_reason'] = ONE_SHOT_R2[cmd]
        elif not m['loop']:
            row['proposal'] = 'one-shot'
        else:
            lp = find(arr)
            if cmd in flagged:
                row['round1_loop'] = lp
                lp = baked_loop(arr, lp)
                row['seam_preview_sha256'] = write(audio / f'{cmd}_seam.wav', baked_preview(arr, lp['ls'], lp['le']))
            else:
                row['seam_preview_sha256'] = write(audio / f'{cmd}_seam.wav', seam_preview(arr, lp['ls'], lp['le']))
            row['loop'] = lp
            row['proposal'] = f"loop ({lp['mode']})"
        rows.append(row)
        print(cmd, row['role'], row['proposal'], {k: row['loop'][k] for k in ('ls', 'le', 'match', 'continuation_ncc', 'grid_offset') if k in row['loop']} if row.get('loop') and row['round2'] else '', flush=True)
    end = read(xa / music['0x8f']['arranged']['wav'])
    cut = int(ENDING_TO_CREDITS_S * RATE)
    tmp = a.work / 'credits_arcade_37800.wav'
    subprocess.run(['ffmpeg', '-v', 'error', '-y', '-i', str(audio / '0x9e_arcade.wav'), '-t', str(CREDITS_TO_GAME_OVER_S), '-ar', str(RATE), '-ac', '2', str(tmp)], check=True)
    cred = read(tmp)
    write(audio / 'credits_a_native.wav', np.concatenate([end[:cut], cred]))
    write(audio / 'credits_d_continuous.wav', end[:int((ENDING_TO_CREDITS_S + CREDITS_TO_GAME_OVER_S) * RATE)])
    rec_credits = {'ending_to_credits_s': ENDING_TO_CREDITS_S, 'credits_to_game_over_s': CREDITS_TO_GAME_OVER_S}
    rec = {'schema': 1, 'credits_scene': rec_credits, 'status': 'proposals for listening review; nothing approved', 'rate': RATE, 'xfade_samples': XFADE_N, 'disc_image_sha256': cat['disc']['image_sha256'], 'rows': rows}
    a.out.write_text(json.dumps(rec, indent=1) + '\n')
    (page / 'index.html').write_text(render_page(rec))
    print(f"wrote {a.out}\nreview page: {page / 'index.html'}")
    return 0

def render_page(rec: dict) -> str:
    rev = hashlib.sha256(json.dumps(rec, sort_keys=True).encode()).hexdigest()[:12]
    E = html.escape
    cards = []
    for r in rec['rows']:
        c = r['cmd']
        clips = [('Arcade', f'{c}_arcade.wav'), ('PSX arranged', f'{c}_psx_arranged.wav'), ('PSX original', f'{c}_psx_original.wav')]
        if r.get('loop'):
            clips.append(('Loop join', f'{c}_seam.wav'))
        if not r['arranged']:
            clips = [x for x in clips if x[0] != 'PSX arranged']
        lp = r.get('loop')
        detail = ''
        if lp:
            s, e = (lp['ls'] / RATE, lp['le'] / RATE)
            q = f"repeat lag {lp['lag_s']} s, seam NCC {lp['seam_ncc']}" if lp['mode'] == 'repeat' else f"exact {lp['found_by']} (match {lp['match']}), 27 ms join baked in, no hardware crossfade" if lp['mode'] == 'baked' else f"splice at the fade onset, match {lp['match']}"
            detail = f'Loop {s:.2f} s → {e:.2f} s ({e - s:.1f} s body); {q}.'
        warn = ''
        if r.get('round2'):
            why = r.get('one_shot_reason')
            warn = '<p class="new">Changed for round 2' + (f': {E(why)}' if why else '') + '.</p>'
        buttons = ''.join((f'<button data-src="audio/{f}?v={rev}">{E(n)}</button>' for n, f in clips))
        cards.append(f'''<section class="card{(' r2' if r.get('round2') else '')}" data-id="{c}"><h2>{c} · {E(r['role'] or '')}</h2>\n<p class="meta">Proposal: {E(r['proposal'])}. {E(detail)}</p>{warn}<div class="clips">{buttons}</div>\n<div class="decide"><label>Mapping <select data-k="mapping"><option value="">not reviewed</option>\n<option>right</option><option>wrong</option></select></label>\n<label>Playback <select data-k="playback"><option value="">not reviewed</option><option>good</option>\n<option>needs a change</option></select></label>\n<textarea data-k="note" placeholder="Note (optional)"></textarea></div></section>''')
    cards.append('<section class="card" data-id="credits"><h2>Decision · Ending into Credits</h2>\n<p class="meta">The arcade sends Ending (0x8f), then 0xf0 and Credits (0x9e) 25.9 s later, then Game Over\n39.5 s after that. The PSX arrange mode ignores the Credits command, so its arranged Ending plays on through the\ncredits. Both previews follow the arcade\'s own timing and end where Game Over cuts in.\nDecided in round 1: (d).</p>\n<div class="clips"><button data-src="audio/credits_a_native.wav?v=' + rev + '">(a) arranged Ending, then native Credits</button>\n<button data-src="audio/credits_d_continuous.wav?v=' + rev + '">(d) arranged Ending all the way through</button></div>\n<div class="decide"><label>Choice <select data-k="mapping"><option value="">not reviewed</option><option>a</option>\n<option>d</option></select></label><label>Playback <select data-k="playback"><option value="">not reviewed</option>\n<option>good</option><option>needs a change</option></select></label>\n<textarea data-k="note" placeholder="Note (optional)"></textarea></div></section>')
    return f"""<!doctype html><html lang="en"><head><meta charset="utf-8">\n<meta name="viewport" content="width=device-width,initial-scale=1"><title>Captain Commando PSX review</title>\n<style>:root{{--bg:#11161c;--panel:#1a222c;--ink:#e6edf3;--muted:#9aa7b4;--line:#2c3947;--accent:#f0b429;--warn:#ff9f6e}}\nbody{{margin:0;background:var(--bg);color:var(--ink);font:15px/1.5 system-ui,sans-serif}}\nheader{{position:sticky;top:0;background:#0d1217;border-bottom:1px solid var(--line);padding:12px 16px;z-index:2}}\nh1{{font-size:19px;margin:0 0 6px}}audio{{width:100%}}main{{max-width:1000px;margin:auto;padding:16px}}\n.card{{background:var(--panel);border:1px solid var(--line);border-radius:10px;padding:14px 16px;margin:0 0 14px}}\n.card h2{{font-size:17px;margin:0 0 4px}}.meta{{color:var(--muted);margin:4px 0}}.warn{{color:var(--warn);margin:4px 0}}.new{{color:var(--accent);margin:4px 0}}\nbody.r2only .card:not(.r2):not([data-id=credits]){{display:none}}\nbutton{{background:#243140;color:var(--ink);border:1px solid var(--line);border-radius:6px;padding:7px 11px;margin:4px 6px 4px 0;cursor:pointer}}\nbutton.on{{border-color:var(--accent);color:var(--accent)}}.decide{{display:flex;gap:12px;flex-wrap:wrap;align-items:center;margin-top:8px}}\nselect,textarea{{background:#0d1217;color:var(--ink);border:1px solid var(--line);border-radius:6px;padding:5px}}\ntextarea{{flex:1;min-width:220px;min-height:34px}}#count{{color:var(--muted)}}</style></head><body>\n<header><h1>Captain Commando · PSX arrangement review</h1><audio id="p" controls></audio>\n<p id="count"></p><button id="export">Export decisions</button>\n<label><input id="r2only" type="checkbox" checked> Round 2: show only the changed rows</label></header><main>\n<p class="meta">Arcade = the board's own cue, first 60 s. Loop join = the 12 s before the wrap, the player's\n1.17 s crossfade, then 12 s after. Revision {rev}. Decisions stay in this browser until exported.</p>\n{''.join(cards)}</main><script>\nconst KEY='captcomm-psx-{rev}',p=document.getElementById('p');let N={{}};\ntry{{N=JSON.parse(localStorage.getItem(KEY)||'{{}}')}}catch(e){{}}\nfunction save(){{try{{localStorage.setItem(KEY,JSON.stringify(N))}}catch(e){{}};count()}}\nfunction count(){{const c=document.querySelectorAll('.card');let d=0;c.forEach(x=>{{const n=N[x.dataset.id]||{{}};if(n.mapping&&n.playback)d++}});\ndocument.getElementById('count').textContent=d+' / '+c.length+' rows decided'}}\ndocument.querySelectorAll('.card').forEach(card=>{{const id=card.dataset.id;card.querySelectorAll('[data-k]').forEach(el=>{{\nel.value=(N[id]||{{}})[el.dataset.k]||'';el.oninput=el.onchange=()=>{{N[id]={{...N[id],[el.dataset.k]:el.value}};save()}}}});\ncard.querySelectorAll('button[data-src]').forEach(b=>b.onclick=()=>{{document.querySelectorAll('button.on').forEach(x=>x.classList.remove('on'));\nb.classList.add('on');p.src=b.dataset.src;p.play()}})}});\ndocument.getElementById('export').onclick=()=>{{const u=URL.createObjectURL(new Blob([JSON.stringify({{revision:'{rev}',decisions:N}},null,1)],{{type:'application/json'}}));\nconst l=document.createElement('a');l.href=u;l.download='captcomm-psx-decisions.json';l.click();setTimeout(()=>URL.revokeObjectURL(u),1000)}};\nconst r2=document.getElementById('r2only');const r2set=()=>document.body.classList.toggle('r2only',r2.checked);r2.onchange=r2set;r2set();\ncount();</script></body></html>\n"""
if __name__ == '__main__':
    sys.exit(main())
