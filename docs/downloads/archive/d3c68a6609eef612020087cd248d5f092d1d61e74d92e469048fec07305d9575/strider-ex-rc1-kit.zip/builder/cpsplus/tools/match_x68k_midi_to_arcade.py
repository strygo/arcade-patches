"""Build an evidence-first X68000 MIDI -> arcade music mapping catalog."""
from __future__ import annotations
import argparse
import csv
import dataclasses
import hashlib
import io
import json
import math
import re
import shutil
import subprocess
import sys
import wave
from collections import Counter
from pathlib import Path
from typing import Iterable
try:
    import numpy as np
except ModuleNotFoundError:
    np = None
REPO = Path(__file__).resolve().parent.parent.parent
CPSPLUS = REPO / 'cpsplus'
DEFAULT_MANIFEST = CPSPLUS / 'manifests' / 'x68k_midi_arcade_map.tsv'
DEFAULT_EXPORT_ROOT = CPSPLUS / 'work' / 'x68000' / 'export'
DEFAULT_FLAC_ROOT = CPSPLUS / 'work' / 'x68000' / 'flac' / 'midi'
DEFAULT_OUTPUT = CPSPLUS / 'work' / 'x68000' / 'arcade_match'
SCHEMA = 'cpsplus-x68000-midi-arcade-match-v2'
ANALYSIS_RATE = 11025
FFT_SIZE = 4096
CHROMA_HOP = 1102
TEMPO_FACTORS = (0.94, 1.0, 1.06)
AUDIO_SUFFIXES = {'.wav', '.flac', '.aif', '.aiff'}
STATUSES = {'verified', 'structural', 'role-only', 'unresolved', 'no-counterpart'}

class MatchError(RuntimeError):
    """Actionable input or evidence error."""

@dataclasses.dataclass(frozen=True)
class EvidenceRow:
    game: str
    song: str
    x68k_select: int
    arcade_set: str
    arcade_cmd: int | None
    role: str
    match_status: str
    in_game: str
    evidence: str
    arcade_aliases: tuple[int, ...] = ()

@dataclasses.dataclass(frozen=True)
class SourceTrack:
    row: EvidenceRow
    midi: Path
    flac: Path | None
    loop_status: str
    loop_start: int | None
    loop_end: int | None
    loop_period_seconds: float | None

@dataclasses.dataclass(frozen=True)
class ArcadeTrack:
    command: int
    path: Path
    loop_period_seconds: float | None

@dataclasses.dataclass
class AudioFeatures:
    samples: np.ndarray
    duration_seconds: float
    chroma: np.ndarray
    rhythm: np.ndarray | None

@dataclasses.dataclass(frozen=True)
class PairScore:
    score: float
    chroma_r: float
    rhythm_r: float | None
    duration_score: float
    loop_score: float | None
    tempo_factor: float
    lag_frames: int

def _require_numpy() -> None:
    if np is None:
        raise MatchError('NumPy is required only for --arcade-dir audio ranking; install numpy or run without arcade captures to build the evidence catalog')

def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()

def _parse_int(value: str, *, field: str) -> int:
    try:
        return int(value, 0)
    except ValueError as exc:
        raise MatchError(f'invalid {field} value {value!r}') from exc

def _parse_command_list(value: str, *, field: str) -> tuple[int, ...]:
    commands = tuple((_parse_int(token, field=field) for token in re.split('[,; ]+', value.strip()) if token))
    if any((not 0 <= command <= 255 for command in commands)):
        raise MatchError(f'{field} commands must be bytes: {value!r}')
    if len(commands) != len(set(commands)):
        raise MatchError(f'duplicate {field} command in {value!r}')
    return commands

def load_manifest(path: Path) -> list[EvidenceRow]:
    if not path.is_file():
        raise MatchError(f'mapping manifest not found: {path}')
    lines = [line for line in path.read_text().splitlines() if line.strip() and (not line.lstrip().startswith('#'))]
    if not lines:
        raise MatchError(f'mapping manifest has no rows: {path}')
    reader = csv.DictReader(io.StringIO('\n'.join(lines)), delimiter='\t')
    required = {'game', 'song', 'x68k_select', 'arcade_set', 'arcade_cmd', 'role', 'match_status', 'in_game', 'evidence'}
    missing = required - set(reader.fieldnames or ())
    if missing:
        raise MatchError(f"{path}: missing columns: {', '.join(sorted(missing))}")
    rows: list[EvidenceRow] = []
    keys: set[tuple[str, str]] = set()
    commands: set[tuple[str, int]] = set()
    for line_number, raw in enumerate(reader, 2):
        game = raw['game'].strip()
        song = raw['song'].strip().lower()
        if not re.fullmatch('song[0-9a-f]{2}', song):
            raise MatchError(f'{path}:{line_number}: invalid song {song!r}')
        key = (game, song)
        if key in keys:
            raise MatchError(f'{path}:{line_number}: duplicate {game}/{song}')
        keys.add(key)
        status = raw['match_status'].strip()
        if status not in STATUSES:
            raise MatchError(f'{path}:{line_number}: unknown status {status!r}')
        cmd_text = raw['arcade_cmd'].strip()
        command = _parse_int(cmd_text, field='arcade_cmd') if cmd_text else None
        if command is not None and (not 0 <= command <= 255):
            raise MatchError(f'{path}:{line_number}: arcade command must be a byte')
        aliases = _parse_command_list(raw.get('arcade_aliases') or '', field='arcade_aliases')
        if command is None and aliases:
            raise MatchError(f'{path}:{line_number}: aliases require a primary arcade command')
        assigned = (() if command is None else (command,)) + aliases
        if len(assigned) != len(set(assigned)):
            raise MatchError(f'{path}:{line_number}: primary command is repeated as an alias')
        for assigned_command in assigned:
            cmd_key = (game, assigned_command)
            if cmd_key in commands:
                raise MatchError(f'{path}:{line_number}: arcade command 0x{assigned_command:x} is assigned more than once for {game}')
            commands.add(cmd_key)
        rows.append(EvidenceRow(game=game, song=song, x68k_select=_parse_int(raw['x68k_select'].strip(), field='x68k_select'), arcade_set=raw['arcade_set'].strip(), arcade_cmd=command, role=raw['role'].strip(), match_status=status, in_game=raw['in_game'].strip(), evidence=raw['evidence'].strip(), arcade_aliases=aliases))
    return rows

def _loop_index(catalog: dict) -> dict[str, dict]:
    result: dict[str, dict] = {}
    for row in catalog.get('loop_points', {}).get('midi', []):
        result[row['song'].lower()] = row
    return result

def _flac_file_index(flac_root: Path) -> dict[tuple[str, str], dict]:
    path = flac_root / 'catalog.json'
    if not path.is_file():
        return {}
    catalog = json.loads(path.read_text())
    return {(row['game'], row['song'].lower()): row for row in catalog.get('files', [])}

def _tag_int(tags: dict, key: str) -> int | None:
    value = tags.get(key)
    if value in (None, ''):
        return None
    try:
        return int(value)
    except (TypeError, ValueError) as exc:
        raise MatchError(f'invalid {key} tag {value!r}') from exc

def join_sources(rows: Iterable[EvidenceRow], export_root: Path, flac_root: Path) -> list[SourceTrack]:
    by_game: dict[str, list[EvidenceRow]] = {}
    for row in rows:
        by_game.setdefault(row.game, []).append(row)
    flac_index = _flac_file_index(flac_root)
    result: list[SourceTrack] = []
    for game, game_rows in sorted(by_game.items()):
        catalog_path = export_root / game / 'catalog.json'
        if not catalog_path.is_file():
            raise MatchError(f'X68000 extraction catalog not found: {catalog_path}')
        catalog = json.loads(catalog_path.read_text())
        midi_paths = {Path(value).stem.lower(): Path(value) for value in catalog.get('midi', {}).get('songs', [])}
        loops = _loop_index(catalog)
        expected = {row.song for row in game_rows}
        actual = set(midi_paths)
        if expected != actual:
            missing = sorted(expected - actual)
            extra = sorted(actual - expected)
            raise MatchError(f'{game}: evidence/extraction song census differs; missing={missing}, extra={extra}')
        for row in sorted(game_rows, key=lambda item: item.x68k_select):
            midi = midi_paths[row.song]
            if not midi.is_file():
                candidates = sorted((export_root / game / 'midi' / 'sc55').glob(f'{row.song}.*'))
                if not candidates:
                    raise MatchError(f'MIDI source not found for {game}/{row.song}')
                midi = candidates[0]
            loop_row = loops.get(row.song, {})
            loop = loop_row.get('loop')
            flac_row = flac_index.get((game, row.song), {})
            output = flac_row.get('output')
            flac = Path(output) if output else flac_root / game / f'{row.song}.flac'
            if not flac.is_absolute():
                flac = REPO / flac
            if not flac.is_file():
                flac = None
            tags = flac_row.get('loop_tags', {})
            loop_start = _tag_int(tags, 'LOOPSTART')
            loop_end = _tag_int(tags, 'LOOPEND')
            period = None
            if loop and loop.get('period_seconds') is not None:
                period = float(loop['period_seconds'])
            result.append(SourceTrack(row=row, midi=midi, flac=flac, loop_status=loop_row.get('loop_status', 'unknown'), loop_start=loop_start, loop_end=loop_end, loop_period_seconds=period))
    return result

def _command_from_stem(stem: str) -> int | None:
    text = stem.lower()
    patterns = ('^0x([0-9a-f]{2,4})(?:[-_ ].*)?$', '^(?:cmd|command|music)[-_ ]?(?:0x)?([0-9a-f]{2,4})(?:[-_ ].*)?$', '^([0-9a-f]{2,4})$')
    for pattern in patterns:
        match = re.match(pattern, text)
        if match:
            return int(match.group(1), 16)
    return None

def _find_period(obj: object) -> float | None:
    """Find an explicit seconds-valued loop period in a capture sidecar."""
    if isinstance(obj, dict):
        for key in ('period_seconds', 'loop_period_seconds'):
            value = obj.get(key)
            if isinstance(value, (int, float)) and value > 0:
                return float(value)
        start = obj.get('start_seconds')
        end = obj.get('end_seconds')
        if isinstance(start, (int, float)) and isinstance(end, (int, float)) and (end > start):
            return float(end - start)
        for value in obj.values():
            period = _find_period(value)
            if period is not None:
                return period
    elif isinstance(obj, list):
        for value in obj:
            period = _find_period(value)
            if period is not None:
                return period
    return None

def scan_arcade_dir(path: Path) -> list[ArcadeTrack]:
    if not path.is_dir():
        raise MatchError(f'arcade capture directory not found: {path}')
    result: dict[int, ArcadeTrack] = {}
    for audio in sorted((p for p in path.iterdir() if p.is_file() and p.suffix.lower() in AUDIO_SUFFIXES)):
        command = _command_from_stem(audio.stem)
        if command is None:
            continue
        if command in result:
            raise MatchError(f'duplicate capture for command 0x{command:x}: {result[command].path} and {audio}')
        sidecar = audio.with_suffix('.json')
        period = None
        if sidecar.is_file():
            period = _find_period(json.loads(sidecar.read_text()))
        result[command] = ArcadeTrack(command, audio, period)
    if not result:
        raise MatchError(f'no command-named audio files under {path}; use 0xNN.wav or cmdNN.wav')
    return [result[key] for key in sorted(result)]

def _trim_leading_near_silence(samples: np.ndarray) -> np.ndarray:
    """Remove capture pre-roll without treating a flat DC bias as audio."""
    if samples.size < ANALYSIS_RATE // 4:
        return samples
    window = max(ANALYSIS_RATE // 50, 32)
    count = samples.size // window
    frames = samples[:count * window].reshape(count, window)
    ac_rms = frames.std(axis=1)
    peak_ac = float(np.max(ac_rms))
    if peak_ac <= 0:
        return samples
    head = samples[:min(samples.size, ANALYSIS_RATE // 2)]
    baseline = float(np.median(head))
    if float(np.std(head)) < max(peak_ac * 0.001, 1e-06) and abs(baseline) >= 1e-05:
        samples = samples - baseline
    active = ac_rms >= max(peak_ac * 0.001, 1e-05)
    sustained = np.convolve(active.astype(np.int8), np.ones(3, dtype=np.int8), mode='same') >= 2
    audible = np.flatnonzero(sustained)
    if audible.size:
        start = max(int(audible[0]) * window - ANALYSIS_RATE // 20, 0)
        samples = samples[start:]
    return samples

def _decode_audio(path: Path, max_seconds: float) -> np.ndarray:
    _require_numpy()
    if not shutil.which('ffmpeg'):
        raise MatchError('ffmpeg is required when --arcade-dir is used')
    command = ['ffmpeg', '-v', 'error', '-i', str(path), '-t', f'{max_seconds:.6f}', '-f', 'f32le', '-acodec', 'pcm_f32le', '-ac', '1', '-ar', str(ANALYSIS_RATE), '-']
    proc = subprocess.run(command, capture_output=True)
    if proc.returncode:
        raise MatchError(f"ffmpeg could not decode {path}: {proc.stderr.decode(errors='replace')}")
    samples = np.frombuffer(proc.stdout, dtype='<f4').astype(np.float64)
    if samples.size < ANALYSIS_RATE // 4:
        raise MatchError(f'audio is too short to compare: {path}')
    return _trim_leading_near_silence(samples)

def _chroma(samples: np.ndarray) -> np.ndarray:
    if samples.size < FFT_SIZE * 2:
        return np.zeros((12, 0), dtype=np.float64)
    count = 1 + (samples.size - FFT_SIZE) // CHROMA_HOP
    indexes = np.arange(FFT_SIZE)[None, :] + CHROMA_HOP * np.arange(count)[:, None]
    frames = samples[indexes] * np.hanning(FFT_SIZE)
    spectrum = np.abs(np.fft.rfft(frames, axis=1))
    freqs = np.fft.rfftfreq(FFT_SIZE, 1.0 / ANALYSIS_RATE)
    keep = (freqs >= 55.0) & (freqs <= 1760.0)
    kept_freqs = freqs[keep]
    kept = np.log1p(spectrum[:, keep] * 50.0)
    pitch_class = np.round(12 * np.log2(kept_freqs / 440.0) + 69).astype(int) % 12
    chroma = np.zeros((count, 12), dtype=np.float64)
    weights = 1.0 / np.sqrt(np.maximum(kept_freqs / 110.0, 1.0))
    for pc in range(12):
        mask = pitch_class == pc
        if np.any(mask):
            chroma[:, pc] = (kept[:, mask] * weights[mask]).sum(axis=1)
    norm = np.linalg.norm(chroma, axis=1, keepdims=True)
    norm[norm == 0] = 1.0
    chroma /= norm
    mean = chroma.mean(axis=0, keepdims=True)
    std = chroma.std(axis=0, keepdims=True)
    std[std < 1e-08] = 1.0
    return ((chroma - mean) / std).T

def _rhythm_signature(samples: np.ndarray) -> np.ndarray | None:
    rate = 50
    hop = ANALYSIS_RATE // rate
    length = samples.size // hop * hop
    if length < ANALYSIS_RATE * 5:
        return None
    envelope = np.sqrt((samples[:length].reshape(-1, hop) ** 2).mean(axis=1) + 1e-12)
    onset = np.maximum(np.diff(np.log(envelope + 1e-07)), 0.0)
    onset -= onset.mean()
    corr = np.correlate(onset, onset, mode='full')[onset.size - 1:]
    if not corr.size or corr[0] <= 0:
        return None
    corr /= corr[0]
    signature = corr[int(0.2 * rate):int(2.0 * rate)]
    std = float(signature.std())
    if std < 1e-10:
        return None
    return (signature - signature.mean()) / std

def audio_features(path: Path, max_seconds: float) -> AudioFeatures:
    samples = _decode_audio(path, max_seconds)
    return AudioFeatures(samples=samples[:20 * ANALYSIS_RATE], duration_seconds=samples.size / ANALYSIS_RATE, chroma=_chroma(samples), rhythm=_rhythm_signature(samples))

def _chroma_ncc(a: np.ndarray, b: np.ndarray, max_lag: int=300) -> tuple[float, int]:
    if a.shape[1] < 30 or b.shape[1] < 30:
        return (0.0, 0)
    size = 1 << int(np.ceil(np.log2(a.shape[1] + b.shape[1])))
    accum = np.zeros(size, dtype=np.float64)
    denominator = 0.0
    for pitch_class in range(12):
        av = a[pitch_class] - a[pitch_class].mean()
        bv = b[pitch_class] - b[pitch_class].mean()
        accum += np.fft.irfft(np.fft.rfft(av, size) * np.conj(np.fft.rfft(bv, size)), size)
        denominator += math.sqrt(float(av @ av)) * math.sqrt(float(bv @ bv))
    if denominator <= 0:
        return (0.0, 0)
    accum /= denominator
    limit = min(max_lag, a.shape[1] // 2, b.shape[1] // 2)
    positive = accum[:limit + 1]
    pos_index = int(np.argmax(positive))
    best = (float(positive[pos_index]), pos_index)
    if limit:
        negative = accum[-limit:]
        neg_index = int(np.argmax(negative))
        candidate = (float(negative[neg_index]), -(limit - neg_index))
        if candidate[0] > best[0]:
            best = candidate
    return best

def _resample_chroma(chroma: np.ndarray, factor: float) -> np.ndarray:
    if factor == 1.0 or not chroma.shape[1]:
        return chroma
    output_length = max(int(round(chroma.shape[1] / factor)), 2)
    source_x = np.arange(chroma.shape[1], dtype=np.float64)
    output_x = np.linspace(0, chroma.shape[1] - 1, output_length)
    return np.vstack([np.interp(output_x, source_x, row) for row in chroma])

def compare_features(source: AudioFeatures, arcade: AudioFeatures, source_loop: float | None, arcade_loop: float | None) -> PairScore:
    best_chroma = (-2.0, 1.0, 0)
    for factor in TEMPO_FACTORS:
        value, lag = _chroma_ncc(source.chroma, _resample_chroma(arcade.chroma, factor))
        if value > best_chroma[0]:
            best_chroma = (value, factor, lag)
    rhythm_r = None
    if source.rhythm is not None and arcade.rhythm is not None:
        rhythm_r = float(np.corrcoef(source.rhythm, arcade.rhythm)[0, 1])
    duration_score = math.exp(-abs(math.log(max(source.duration_seconds, 0.1) / max(arcade.duration_seconds, 0.1))))
    loop_score = None
    if source_loop and arcade_loop:
        loop_score = math.exp(-abs(math.log(source_loop / arcade_loop)) / 0.2)
    chroma_component = float(np.clip((best_chroma[0] - 0.03) / 0.35, 0.0, 1.0))
    rhythm_component = 0.5 if rhythm_r is None else float(np.clip((rhythm_r + 0.15) / 0.75, 0.0, 1.0))
    loop_component = 0.5 if loop_score is None else loop_score
    score = 0.55 * chroma_component + 0.22 * rhythm_component + 0.08 * duration_score + 0.15 * loop_component
    return PairScore(score=score, chroma_r=best_chroma[0], rhythm_r=rhythm_r, duration_score=duration_score, loop_score=loop_score, tempo_factor=best_chroma[1], lag_frames=best_chroma[2])

def _hungarian_max(weights: list[list[float]]) -> list[int]:
    """Return the selected column for each row of an n<=m weight matrix."""
    if not weights:
        return []
    n = len(weights)
    m = len(weights[0])
    if any((len(row) != m for row in weights)) or n > m:
        raise ValueError('Hungarian input must be rectangular with rows <= columns')
    maximum = max((max(row) for row in weights))
    cost = [[maximum - value for value in row] for row in weights]
    u = [0.0] * (n + 1)
    v = [0.0] * (m + 1)
    p = [0] * (m + 1)
    way = [0] * (m + 1)
    for i in range(1, n + 1):
        p[0] = i
        j0 = 0
        minimum = [float('inf')] * (m + 1)
        used = [False] * (m + 1)
        while True:
            used[j0] = True
            i0 = p[j0]
            delta = float('inf')
            j1 = 0
            for j in range(1, m + 1):
                if used[j]:
                    continue
                current = cost[i0 - 1][j - 1] - u[i0] - v[j]
                if current < minimum[j]:
                    minimum[j] = current
                    way[j] = j0
                if minimum[j] < delta:
                    delta = minimum[j]
                    j1 = j
            for j in range(m + 1):
                if used[j]:
                    u[p[j]] += delta
                    v[j] -= delta
                else:
                    minimum[j] -= delta
            j0 = j1
            if p[j0] == 0:
                break
        while True:
            j1 = way[j0]
            p[j0] = p[j1]
            j0 = j1
            if j0 == 0:
                break
    assignment = [-1] * n
    for j in range(1, m + 1):
        if p[j]:
            assignment[p[j] - 1] = j - 1
    return assignment

def _parse_arcade_dirs(values: list[str]) -> dict[str, Path]:
    result: dict[str, Path] = {}
    for value in values:
        if '=' not in value:
            raise MatchError('--arcade-dir must use GAME=PATH')
        game, raw_path = value.split('=', 1)
        game = game.strip()
        if not game or game in result:
            raise MatchError(f'invalid or duplicate --arcade-dir game {game!r}')
        result[game] = Path(raw_path).expanduser().resolve()
    return result

def rank_game(sources: list[SourceTrack], arcade: list[ArcadeTrack], max_seconds: float, top: int, unmatched_score: float) -> tuple[list[dict], dict[str, int | None], dict[tuple[str, int], PairScore], dict[Path, AudioFeatures]]:
    comparison_sources = [source for source in sources if source.flac is not None and source.row.match_status != 'no-counterpart']
    fixed_commands = {command for source in sources for command in (() if source.row.arcade_cmd is None else (source.row.arcade_cmd,)) + source.row.arcade_aliases}
    unresolved = [source for source in comparison_sources if source.row.arcade_cmd is None and source.row.match_status not in {'no-counterpart'}]
    available_arcade = [track for track in arcade if track.command not in fixed_commands]
    features: dict[Path, AudioFeatures] = {}
    for source in comparison_sources:
        assert source.flac is not None
        features[source.flac] = audio_features(source.flac, max_seconds)
    for track in arcade:
        features[track.path] = audio_features(track.path, max_seconds)
    scores: dict[tuple[str, int], PairScore] = {}
    rows: list[dict] = []
    for source in comparison_sources:
        assert source.flac is not None
        candidates: list[tuple[float, ArcadeTrack, PairScore]] = []
        for track in arcade:
            pair = compare_features(features[source.flac], features[track.path], source.loop_period_seconds, track.loop_period_seconds)
            scores[source.row.song, track.command] = pair
            candidates.append((pair.score, track, pair))
        candidates.sort(key=lambda item: (-item[0], item[1].command))
        for rank, (_, track, pair) in enumerate(candidates[:top], 1):
            rows.append({'game': source.row.game, 'song': source.row.song, 'match_status': source.row.match_status, 'rank': rank, 'arcade_cmd': f'0x{track.command:02x}', 'authored_match': int(source.row.arcade_cmd == track.command or track.command in source.row.arcade_aliases), 'ranking_score': pair.score, 'chroma_r': pair.chroma_r, 'rhythm_r': pair.rhythm_r, 'duration_score': pair.duration_score, 'loop_score': pair.loop_score, 'tempo_factor': pair.tempo_factor, 'lag_frames': pair.lag_frames, 'arcade_audio': str(track.path)})
    suggested: dict[str, int | None] = {source.row.song: None for source in unresolved}
    if unresolved and available_arcade:
        real_columns = len(available_arcade)
        matrix = [[scores[source.row.song, track.command].score for track in available_arcade] + [unmatched_score] * len(unresolved) for source in unresolved]
        for source, column in zip(unresolved, _hungarian_max(matrix)):
            if 0 <= column < real_columns:
                candidate = available_arcade[column]
                pair = scores[source.row.song, candidate.command]
                if pair.score >= unmatched_score:
                    suggested[source.row.song] = candidate.command
    return (rows, suggested, scores, features)

def _preview_pcm(samples: np.ndarray) -> bytes:
    channel = samples.copy()
    rms = math.sqrt(float(np.mean(channel * channel)))
    if rms > 1e-08:
        channel *= min(0.16 / rms, 8.0)
    channel = np.clip(channel, -0.98, 0.98)
    return np.round(channel * 32767.0).astype('<i2').tobytes()

def _write_mono_preview(path: Path, samples: np.ndarray) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with wave.open(str(path), 'wb') as output:
        output.setnchannels(1)
        output.setsampwidth(2)
        output.setframerate(ANALYSIS_RATE)
        output.writeframes(_preview_pcm(samples))

def _write_preview_pair(base: Path, source_path: Path, arcade_path: Path, seconds: float=20.0) -> tuple[Path, Path]:
    """Write two onset-aligned, independently playable review WAVs."""
    source = _decode_audio(source_path, seconds)
    arcade = _decode_audio(arcade_path, seconds)
    count = min(source.size, arcade.size, int(seconds * ANALYSIS_RATE))
    if count <= 0:
        raise MatchError(f'cannot write an empty preview pair for {base.name}')
    x68000_path = base.with_name(base.name + '__A_X68000.wav')
    arcade_output_path = base.with_name(base.name + '__B_ARCADE.wav')
    _write_mono_preview(x68000_path, source[:count])
    _write_mono_preview(arcade_output_path, arcade[:count])
    return (x68000_path, arcade_output_path)

def _write_tsv(path: Path, fieldnames: list[str], rows: Iterable[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('w', newline='') as output:
        writer = csv.DictWriter(output, fieldnames=fieldnames, delimiter='\t', lineterminator='\n', extrasaction='ignore')
        writer.writeheader()
        for row in rows:
            cooked = {}
            for key in fieldnames:
                value = row.get(key, '')
                cooked[key] = '' if value is None else value
            writer.writerow(cooked)

def write_outputs(output: Path, manifest: Path, sources: list[SourceTrack], candidates: list[dict], suggestions: dict[tuple[str, str], int | None], arcade_dirs: dict[str, Path]) -> dict:
    output.mkdir(parents=True, exist_ok=True)
    mapping_rows = []
    for source in sources:
        row = source.row
        suggestion = suggestions.get((row.game, row.song))
        mapping_rows.append({'game': row.game, 'song': row.song, 'x68k_select': f'0x{row.x68k_select:02x}', 'arcade_set': row.arcade_set, 'arcade_cmd': '' if row.arcade_cmd is None else f'0x{row.arcade_cmd:02x}', 'arcade_aliases': ','.join((f'0x{command:02x}' for command in row.arcade_aliases)), 'role': row.role, 'match_status': row.match_status, 'in_game': row.in_game, 'suggested_cmd': '' if suggestion is None else f'0x{suggestion:02x}', 'source_flac': '' if source.flac is None else str(source.flac), 'loop_status': source.loop_status, 'loop_start': source.loop_start, 'loop_end': source.loop_end, 'loop_period_seconds': None if source.loop_period_seconds is None else f'{source.loop_period_seconds:.9f}', 'evidence': row.evidence})
    mapping_fields = ['game', 'song', 'x68k_select', 'arcade_set', 'arcade_cmd', 'arcade_aliases', 'role', 'match_status', 'in_game', 'suggested_cmd', 'source_flac', 'loop_status', 'loop_start', 'loop_end', 'loop_period_seconds', 'evidence']
    _write_tsv(output / 'mapping.tsv', mapping_fields, mapping_rows)
    candidate_fields = ['game', 'song', 'match_status', 'rank', 'arcade_cmd', 'authored_match', 'ranking_score', 'chroma_r', 'rhythm_r', 'duration_score', 'loop_score', 'tempo_factor', 'lag_frames', 'arcade_audio']
    _write_tsv(output / 'candidates.tsv', candidate_fields, candidates)
    by_game: dict[str, Counter] = {}
    for source in sources:
        counter = by_game.setdefault(source.row.game, Counter())
        counter['tracks'] += 1
        counter[source.row.match_status] += 1
        if source.row.arcade_cmd is not None:
            counter['arcade_mapped'] += 1
            counter['arcade_commands'] += 1 + len(source.row.arcade_aliases)
        if source.loop_start is not None and source.loop_end is not None:
            counter['loop_tagged'] += 1
        if suggestions.get((source.row.game, source.row.song)) is not None:
            counter['candidate_assignments'] += 1
    catalog = {'schema': SCHEMA, 'manifest': str(manifest), 'manifest_sha256': _sha256(manifest), 'output': str(output), 'counts': dict(Counter(tracks=len(sources), arcade_mapped=sum((s.row.arcade_cmd is not None for s in sources)), arcade_commands=sum((1 + len(s.row.arcade_aliases) for s in sources if s.row.arcade_cmd is not None)), verified=sum((s.row.match_status == 'verified' for s in sources)), structural=sum((s.row.match_status == 'structural' for s in sources)), role_only=sum((s.row.match_status == 'role-only' for s in sources)), unresolved=sum((s.row.match_status == 'unresolved' for s in sources)), no_counterpart=sum((s.row.match_status == 'no-counterpart' for s in sources)), loop_tagged=sum((s.loop_start is not None and s.loop_end is not None for s in sources)), candidate_rows=len(candidates))), 'counts_by_game': {game: dict(counter) for game, counter in sorted(by_game.items())}, 'arcade_capture_dirs': {game: str(path) for game, path in sorted(arcade_dirs.items())}, 'score_policy': 'Audio scores rank review candidates only. They cannot verify a mapping, and a low score is not negative identity evidence.', 'files': {'mapping': 'mapping.tsv', 'candidates': 'candidates.tsv', 'coverage': 'coverage.md'}}
    (output / 'catalog.json').write_text(json.dumps(catalog, indent=2) + '\n')
    lines = ['# X68000 MIDI → arcade mapping coverage', '', 'Audio similarity is a review queue, not proof. `verified` rows carry existing trace/role/ear evidence; `structural` rows preserve a documented bank/command bijection and still merit an A/B spot check.', '', '| Game | Tracks | Mapped songs | Arcade commands | Verified | Structural | Role only | Unresolved | No counterpart | Loop-tagged |', '|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|']
    for game, counter in sorted(by_game.items()):
        lines.append(f"| `{game}` | {counter['tracks']} | {counter['arcade_mapped']} | {counter['arcade_commands']} | {counter['verified']} | {counter['structural']} | {counter['role-only']} | {counter['unresolved']} | {counter['no-counterpart']} | {counter['loop_tagged']} |")
    lines += ['', '`mapping.tsv` is the pack-authoring input. `suggested_cmd` remains non-authoritative until its row is reviewed and moved into the tracked evidence manifest.', '']
    (output / 'coverage.md').write_text('\n'.join(lines))
    return catalog

def self_test() -> None:
    assert _command_from_stem('0x2a') == 42
    assert _command_from_stem('cmd2A_stage') == 42
    assert _command_from_stem('not-a-command') is None
    weights = [[9.0, 2.0, 1.0], [8.0, 7.0, 3.0]]
    assert _hungarian_max(weights) == [0, 1]
    assert _find_period({'loop_candidate': {'start_seconds': 2.0, 'end_seconds': 5.5}}) == 3.5
    if np is not None:
        seconds = 8.0
        t = np.arange(int(seconds * ANALYSIS_RATE)) / ANALYSIS_RATE
        melody = 0.5 * np.sin(2 * np.pi * 220 * t) + 0.3 * np.sin(2 * np.pi * 329.63 * t)
        other = 0.5 * np.sin(2 * np.pi * 277.18 * t)
        a = AudioFeatures(melody, seconds, _chroma(melody), _rhythm_signature(melody))
        b = AudioFeatures(melody.copy(), seconds, _chroma(melody), _rhythm_signature(melody))
        c = AudioFeatures(other, seconds, _chroma(other), _rhythm_signature(other))
        assert compare_features(a, b, None, None).chroma_r > compare_features(a, c, None, None).chroma_r
        lead = np.full(2 * ANALYSIS_RATE, 0.056, dtype=np.float64)
        tone = 0.056 + 0.2 * np.sin(2 * np.pi * 220 * np.arange(4 * ANALYSIS_RATE) / ANALYSIS_RATE)
        trimmed = _trim_leading_near_silence(np.concatenate((lead, tone)))
        assert 3.9 < trimmed.size / ANALYSIS_RATE < 4.1
        assert abs(float(trimmed[:ANALYSIS_RATE].mean())) < 0.01
    rows = load_manifest(DEFAULT_MANIFEST)
    counts = Counter((row.game for row in rows))
    assert counts == {'daimakaimura': 27, 'ffight': 20, 'sf2ce': 46, 'ssf2': 63}
    daimakaimura = [row for row in rows if row.game == 'daimakaimura']
    assert sum((1 + len(row.arcade_aliases) for row in daimakaimura if row.arcade_cmd is not None)) == 64
    print('self-test: PASS')

def main(argv: list[str] | None=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--manifest', type=Path, default=DEFAULT_MANIFEST)
    parser.add_argument('--export-root', type=Path, default=DEFAULT_EXPORT_ROOT)
    parser.add_argument('--flac-root', type=Path, default=DEFAULT_FLAC_ROOT)
    parser.add_argument('--output', type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument('--game', action='append', default=[], help='game to include (repeatable; default: all)')
    parser.add_argument('--arcade-dir', action='append', default=[], metavar='GAME=PATH', help='isolated command captures named 0xNN.wav/cmdNN.wav')
    parser.add_argument('--top', type=int, default=3, help='rank this many audio candidates per reviewed row')
    parser.add_argument('--max-seconds', type=float, default=90.0, help='maximum audio decoded per candidate')
    parser.add_argument('--unmatched-score', type=float, default=0.62, help='assignment score below which a row stays unmatched')
    parser.add_argument('--previews', action='store_true', help='write separate onset-aligned X68000/arcade WAVs')
    parser.add_argument('--preview-seconds', type=float, default=20.0, help='duration of each separate review file')
    parser.add_argument('--self-test', action='store_true')
    args = parser.parse_args(argv)
    try:
        if args.self_test:
            self_test()
            return 0
        if args.top < 1 or args.max_seconds < 5 or (not 0 < args.preview_seconds <= args.max_seconds) or (not 0 <= args.unmatched_score <= 1):
            raise MatchError('invalid --top, --max-seconds, --preview-seconds, or --unmatched-score')
        rows = load_manifest(args.manifest.resolve())
        selected_games = set(args.game) if args.game else {row.game for row in rows}
        unknown_games = selected_games - {row.game for row in rows}
        if unknown_games:
            raise MatchError(f'games not present in manifest: {sorted(unknown_games)}')
        rows = [row for row in rows if row.game in selected_games]
        sources = join_sources(rows, args.export_root.resolve(), args.flac_root.resolve())
        arcade_dirs = _parse_arcade_dirs(args.arcade_dir)
        if set(arcade_dirs) - selected_games:
            raise MatchError('--arcade-dir includes a game excluded by --game')
        candidates: list[dict] = []
        suggestions: dict[tuple[str, str], int | None] = {}
        for game, directory in sorted(arcade_dirs.items()):
            game_sources = [source for source in sources if source.row.game == game]
            arcade = scan_arcade_dir(directory)
            ranked, suggested, _scores, _features = rank_game(game_sources, arcade, args.max_seconds, args.top, args.unmatched_score)
            candidates.extend(ranked)
            suggestions.update({(game, song): command for song, command in suggested.items()})
            if args.previews:
                arcade_by_command = {track.command: track for track in arcade}
                review_pairs = {source.row.song: source.row.arcade_cmd for source in game_sources if source.row.arcade_cmd is not None}
                review_pairs.update({song: command for song, command in suggested.items() if command is not None})
                source_by_song = {source.row.song: source for source in game_sources}
                preview_dir = args.output.resolve() / 'previews' / game
                review_rows = []
                for song, command in review_pairs.items():
                    if command is None:
                        continue
                    source = source_by_song[song]
                    if source.flac is None or command not in arcade_by_command:
                        continue
                    target = arcade_by_command[command]
                    role_slug = re.sub('[^A-Za-z0-9]+', '_', source.row.role).strip('_') or 'Untitled'
                    base = preview_dir / f'{song}__0x{command:02x}__{role_slug}'
                    x68000_path, arcade_path = _write_preview_pair(base, source.flac, target.path, args.preview_seconds)
                    review_rows.append({'song': song, 'arcade_cmd': f'0x{command:02x}', 'role': source.row.role, 'match_status': source.row.match_status, 'x68000_file': x68000_path.name, 'arcade_file': arcade_path.name})
                _write_tsv(preview_dir / 'review.tsv', ['song', 'arcade_cmd', 'role', 'match_status', 'x68000_file', 'arcade_file'], review_rows)
        catalog = write_outputs(args.output.resolve(), args.manifest.resolve(), sources, candidates, suggestions, arcade_dirs)
        print(json.dumps(catalog['counts'], sort_keys=True))
        print(f'wrote {args.output.resolve()}')
        return 0
    except (MatchError, OSError, json.JSONDecodeError, subprocess.SubprocessError) as exc:
        print(f'error: {exc}', file=sys.stderr)
        return 2
if __name__ == '__main__':
    raise SystemExit(main())
