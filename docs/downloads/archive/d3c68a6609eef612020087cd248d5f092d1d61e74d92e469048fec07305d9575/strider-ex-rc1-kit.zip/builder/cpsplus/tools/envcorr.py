"""Decode PS1 XA channel 0..7 (first N seconds) of ZERO200.XA and correlate amplitude"""
import struct, math
K0 = [0.0, 0.9375, 1.796875, 1.53125]
K1 = [0.0, 0.0, -0.8125, -0.859375]

def decode_xa_channel(binpath, lba, nsect, chan, max_audio_sect):
    f = open(binpath, 'rb')
    h1L = h2L = h1R = h2R = 0.0
    L = []
    R = []
    got = 0
    for i in range(nsect):
        f.seek((lba + i) * 2352)
        raw = f.read(2352)
        if raw[17] != chan or not raw[18] & 4:
            continue
        payload = raw[24:24 + 2304]
        for g in range(18):
            grp = payload[g * 128:(g + 1) * 128]
            for unit in range(8):
                param = grp[4 + unit]
                shift = param & 15
                filt = param >> 4 & 3
                k0 = K0[filt]
                k1 = K1[filt]
                out = L if unit & 1 == 0 else R
                if unit & 1 == 0:
                    h1, h2 = (h1L, h2L)
                else:
                    h1, h2 = (h1R, h2R)
                base = 16 + (unit >> 1)
                for j in range(28):
                    b = grp[base + j * 4]
                    nib = b >> 4 if unit & 1 else b & 15
                    if nib >= 8:
                        nib -= 16
                    s = nib << 12 >> shift
                    s = s + h1 * k0 + h2 * k1
                    if s > 32767:
                        s = 32767
                    if s < -32768:
                        s = -32768
                    h2 = h1
                    h1 = s
                    out.append(s)
                if unit & 1 == 0:
                    h1L, h2L = (h1, h2)
                else:
                    h1R, h2R = (h1, h2)
        got += 1
        if got >= max_audio_sect:
            break
    return (L, R)

def envelope(samples, samples_per_win):
    env = []
    n = len(samples)
    i = 0
    while i + samples_per_win <= n:
        w = samples[i:i + samples_per_win]
        env.append(math.sqrt(sum((x * x for x in w)) / len(w)))
        i += samples_per_win
    return env

def norm(env):
    m = sum(env) / len(env)
    sd = math.sqrt(sum(((x - m) ** 2 for x in env)) / len(env)) or 1
    return [(x - m) / sd for x in env]

def corr(a, b):
    n = min(len(a), len(b))
    if n < 10:
        return 0
    a = a[:n]
    b = b[:n]
    return sum((a[i] * b[i] for i in range(n))) / n

def main():
    win_s = 0.1
    secs = 40
    sat = open('sfz2_saturn/S010.MUS', 'rb').read() + open('sfz2_saturn/S011.MUS', 'rb').read()
    satsm = struct.unpack('>%dh' % (len(sat) // 2), sat)
    sat_envs = {}
    for rate in (44100, 22050, 32000, 30720):
        spw = int(rate * win_s)
        need = int(secs / win_s) * spw
        sat_envs[rate] = norm(envelope(list(satsm[:need]), spw))
    xa_rate = 37800
    spw_xa = int(xa_rate * win_s)
    need_sect = int(secs * xa_rate / 2016) + 2
    results = []
    for chan in range(8):
        L, R = decode_xa_channel('sfz2_psx/sfz2.bin', 24, 36608, chan, need_sect)
        mono = [(L[i] + R[i]) / 2 for i in range(min(len(L), len(R)))]
        e = norm(envelope(mono, spw_xa))
        for rate, se in sat_envs.items():
            best = max((corr(se[lag:], e) for lag in range(0, 60, 2)))
            results.append((chan, rate, best))
        print(f'chan {chan}: ' + '  '.join((f'{rate}:{c:+.3f}' for ch, rate, c in results[-4:])))
    results.sort(key=lambda x: -x[2])
    print('TOP:', results[:6])
main()
