"""Render every music command of a QSound game (CPS2, CPS1.5) to its own clip."""
from __future__ import annotations
import argparse
import csv
import json
import os
import subprocess
import sys
import wave
from pathlib import Path
import numpy as np
HERE = Path(__file__).resolve().parent
REPO = HERE.parents[1]
LUA = REPO / 'cpsplus' / 'lua' / 'qsound_soundtest.lua'
REFRESH = 59.637405
CLIP_RATE = 24000

def _dbfs(x: np.ndarray) -> float:
    p = float(np.abs(x).max()) if x.size else 0.0
    return 20 * np.log10(p) if p > 0 else -200.0

def sweep(game: str, latch: str, first: int, last: int, hold_s: int, rompath: Path, work: Path) -> Path:
    for sub in ('cfg', 'nvram'):
        (work / sub).mkdir(parents=True, exist_ok=True)
    hold = int(round(hold_s * REFRESH))
    env = dict(os.environ, SDL_VIDEODRIVER='dummy', SDL_AUDIODRIVER='dummy', SW_LATCH=latch, SW_FIRST=f'{first:02x}', SW_LAST=f'{last:02x}', SW_HOLD=str(hold), SW_OUT=str(work / 'markers.tsv'))
    seconds = int(((last - first + 2) * hold + 600) / REFRESH) + 10
    cmd = ['mame', game, '-rompath', str(rompath), '-skip_gameinfo', '-noautosave', '-autoboot_script', str(LUA), '-nvram_directory', str(work / 'nvram'), '-cfg_directory', str(work / 'cfg'), '-video', 'none', '-sound', 'sdl', '-wavwrite', str(work / 'sweep.wav'), '-nothrottle', '-seconds_to_run', str(seconds)]
    subprocess.run(cmd, check=True, env=env, cwd=work, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    return work

def cut(work: Path, out: Path, hold_s: int) -> dict:
    clips = out / 'clips'
    clips.mkdir(parents=True, exist_ok=True)
    rows = [(int(r['cmd'], 16), int(r['frame'])) for r in csv.DictReader(open(work / 'markers.tsv'), delimiter='\t')]
    catalog = {}
    with wave.open(str(work / 'sweep.wav')) as w:
        sr = w.getframerate()
        for cmd, f0 in rows:
            w.setpos(int((f0 / REFRESH + 0.02) * sr))
            n = int((hold_s - 0.15) * sr)
            x = np.frombuffer(w.readframes(n), dtype='<i2').reshape(-1, 2).astype(np.float64)
            m = x.mean(1) / 32768
            peak = _dbfs(m)
            loud = np.nonzero(np.abs(m) > 10 ** (-50 / 20))[0]
            sounding = (loud[-1] - loud[0]) / sr if len(loud) else 0.0
            k = int(round(len(m) * CLIP_RATE / sr))
            y = np.interp(np.linspace(0, len(m) - 1, k), np.arange(len(m)), m)
            with wave.open(str(clips / f'{cmd:02x}.wav'), 'wb') as o:
                o.setnchannels(1)
                o.setsampwidth(2)
                o.setframerate(CLIP_RATE)
                o.writeframes(np.clip(np.round(y * 32767), -32768, 32767).astype('<i2').tobytes())
            catalog[f'0x{cmd:02x}'] = {'peak_dbfs': round(float(peak), 1), 'sounding_s': round(float(sounding), 2), 'silent': bool(peak < -60)}
    return catalog

def main(argv: list[str] | None=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--game', required=True)
    ap.add_argument('--first', default='00')
    ap.add_argument('--last', required=True)
    ap.add_argument('--latch', default='0x618000')
    ap.add_argument('--hold', type=int, default=30)
    ap.add_argument('--rompath', type=Path, default=REPO / 'roms' / 'mame0260')
    ap.add_argument('--expect-loud', default='01')
    ap.add_argument('--skip-below', default=None, help='keep clips only for commands >= this (hex); 0x00 and --expect-loud are always kept as controls (the Lua sweeps a contiguous range, so the gap is played but not kept)')
    ap.add_argument('--out', type=Path, required=True)
    a = ap.parse_args(argv)
    first, last = (int(a.first, 16), int(a.last, 16))
    if first != 0:
        ap.error('--first must be 00: command 0x00 is the silence control')
    a.out = a.out.resolve()
    work = a.out / 'sweep'
    sweep(a.game, a.latch, first, last, a.hold, a.rompath, work)
    catalog = cut(work, a.out, a.hold)
    if a.skip_below:
        lo = int(a.skip_below, 16)
        keep = {'0x00', f'0x{int(a.expect_loud, 16):02x}'}
        for k in list(catalog):
            if k not in keep and int(k, 16) < lo:
                del catalog[k]
                (a.out / 'clips' / f'{int(k, 16):02x}.wav').unlink(missing_ok=True)
    (work / 'sweep.wav').unlink()
    silence = catalog.get('0x00', {}).get('peak_dbfs', 0.0)
    loud = catalog.get(f'0x{int(a.expect_loud, 16):02x}', {}).get('peak_dbfs', -200.0)
    controls = {'silence_0x00_dbfs': silence, 'silence_ok': bool(silence < -60), f'positive_0x{int(a.expect_loud, 16):02x}_dbfs': loud, 'positive_ok': bool(loud > -30)}
    doc = {'game': a.game, 'latch': a.latch, 'hold_s': a.hold, 'controls': controls, 'commands': catalog}
    (a.out / 'catalog.json').write_text(json.dumps(doc, indent=1) + '\n')
    sounding = sum((1 for v in catalog.values() if not v['silent']))
    print(json.dumps({'commands': len(catalog), 'sounding': sounding, **controls}))
    return 0 if controls['silence_ok'] and controls['positive_ok'] else 1
if __name__ == '__main__':
    raise SystemExit(main())
