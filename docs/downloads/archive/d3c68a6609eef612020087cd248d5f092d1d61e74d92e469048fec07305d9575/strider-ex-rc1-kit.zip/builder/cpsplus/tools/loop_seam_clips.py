"""Make short, exact wrap clips for listening to every loop in a CPS+ pack."""
from __future__ import annotations
import argparse
import csv
import json
from pathlib import Path
import re
import sys
import wave
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from pack import audition
from pack.format import PackReader, VERB_PLAY

def clips(pack: Path, out_dir: Path, seconds: float) -> tuple[int, int]:
    if seconds <= 0:
        raise ValueError('--seconds must be positive')
    sidecar = Path(str(pack) + '.json')
    audit = json.loads(sidecar.read_text()).get('source_audit', []) if sidecar.exists() else []
    priority = {int(item['cmd'], 16) for item in audit if item.get('baked_join_samples')}
    out_dir.mkdir(parents=True, exist_ok=True)
    rows = []
    rd = PackReader(pack)
    try:
        commands = {}
        for cmd, trigger in enumerate(rd.triggers):
            if trigger.verb == VERB_PLAY:
                commands.setdefault(trigger.track, cmd)
        for track, meta in enumerate(rd.tracks):
            if not meta.loops:
                continue
            cmd = commands.get(track)
            start, end = audition._loop_points_samples(meta)
            window = round(seconds * meta.sample_rate)
            if start + window > end or end - window < 0:
                raise ValueError(f'track {track}: loop is too short for {seconds}s clips')
            pcm = audition._decode_track(rd, track)
            frame = 2 * meta.channels
            if len(pcm) < end * frame:
                raise ValueError(f'track {track}: decoded audio ends before loop end')
            wrap = pcm[(end - window) * frame:end * frame] + pcm[start * frame:(start + window) * frame]
            group = 'priority' if cmd in priority else 'other'
            safe_name = re.sub('[^A-Za-z0-9_.-]+', '_', meta.name or f'track{track}')
            name = f'{cmd:02x}_{safe_name}.wav' if cmd is not None else f'--_{safe_name}.wav'
            target = out_dir / group / name
            target.parent.mkdir(parents=True, exist_ok=True)
            with wave.open(str(target), 'wb') as wav:
                wav.setnchannels(meta.channels)
                wav.setsampwidth(2)
                wav.setframerate(meta.sample_rate)
                wav.writeframes(wrap)
            rows.append((f'0x{cmd:02x}' if cmd is not None else '-', track, meta.name, group, f'{seconds:.3f}', start, end, target.relative_to(out_dir)))
    finally:
        rd.close()
    with (out_dir / 'index.tsv').open('w', newline='') as output:
        writer = csv.writer(output, delimiter='\t')
        writer.writerow(('cmd', 'track', 'name', 'group', 'seam_at_seconds', 'loop_start_sample', 'loop_end_sample', 'file'))
        writer.writerows(rows)
    ordered = sorted(rows, key=lambda row: (row[3] != 'priority', row[1]))
    for playlist, items in (('priority.m3u', [r for r in ordered if r[3] == 'priority']), ('all.m3u', ordered)):
        lines = ['#EXTM3U']
        for cmd, _, name, _, _, _, _, path in items:
            lines.extend((f'#EXTINF:{2 * seconds:.3f},{cmd} {name}', str(path)))
        (out_dir / playlist).write_text('\n'.join(lines) + '\n')
    (out_dir / 'README.txt').write_text(f'Listen at {seconds:.3f} seconds in each WAV, where the CPS+ player wraps from loop end to loop start.\nStart with priority.m3u, then all.m3u. Listen for a click, beat skip, repeated attack, or change in ambience.\nThese are raw pack clips; check music and SFX balance in game separately.\n')
    return (len(rows), sum((row[3] == 'priority' for row in rows)))

def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--pack', type=Path, required=True)
    ap.add_argument('--out-dir', type=Path, required=True)
    ap.add_argument('--seconds', type=float, default=3.0, help='audio on each side of the seam (default: 3 seconds)')
    args = ap.parse_args(argv)
    total, urgent = clips(args.pack, args.out_dir, args.seconds)
    print(f'Wrote {total} loop seam clips ({urgent} priority) to {args.out_dir}')
    return 0
if __name__ == '__main__':
    raise SystemExit(main())
