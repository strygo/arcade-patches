"""Convert the MS-DOS SSF2T disc's AdLib instrument banks to one WOPL bank."""
from __future__ import annotations
import argparse
import struct
import sys
from dataclasses import dataclass
from pathlib import Path
BNK_MAGIC = b'ADLIB-'
NAME_RECORD = 12
INSTRUMENT_RECORD = 30
WOPL_MAGIC = b'WOPL3-BANK\x00'
WOPL_VERSION = 3
WOPL_INST_SIZE = 66
WOPL_VM_HMI = 9
WOPL_INS_2OP = 0
WOPL_INS_BLANK = 4

class BankError(ValueError):
    pass

@dataclass(frozen=True)
class Patch:
    name: str
    blank: bool
    fb_conn: int
    ops: tuple[tuple[int, int, int, int, int], ...]

def _op_registers(op: bytes, waveform: int) -> tuple[int, int, int, int, int]:
    ksl, freqmul, feedback, attack, sustain, sustain_flag, decay, release, level, tremolo, vibrato, scaling, additive = op
    avekf_20 = (tremolo & 1) << 7 | (vibrato & 1) << 6 | (sustain_flag & 1) << 5 | (scaling & 1) << 4 | freqmul & 15
    ksl_l_40 = (ksl & 3) << 6 | level & 63
    atdec_60 = (attack & 15) << 4 | decay & 15
    susrel_80 = (sustain & 15) << 4 | release & 15
    return (avekf_20, ksl_l_40, atdec_60, susrel_80, waveform & 7)

def read_bnk(path: Path) -> list[Patch]:
    raw = path.read_bytes()
    if raw[2:8] != BNK_MAGIC:
        raise BankError(f'{path.name}: not an AdLib BNK bank')
    used, total = struct.unpack_from('<HH', raw, 8)
    name_offset, data_offset = struct.unpack_from('<II', raw, 12)
    if used > total:
        raise BankError(f'{path.name}: {used} entries used of {total}')
    patches: list[Patch] = []
    for slot in range(used):
        base = name_offset + slot * NAME_RECORD
        if base + NAME_RECORD > len(raw):
            raise BankError(f'{path.name}: name table runs past end of file')
        index = struct.unpack_from('<H', raw, base)[0]
        name = raw[base + 3:base + 12].split(b'\x00')[0].decode('latin-1')
        entry = data_offset + index * INSTRUMENT_RECORD
        if entry + INSTRUMENT_RECORD > len(raw):
            raise BankError(f'{path.name}: slot {slot} data past end of file')
        record = raw[entry:entry + INSTRUMENT_RECORD]
        op1, op2 = (record[2:15], record[15:28])
        wave_mod, wave_car = (record[28], record[29])
        fb_conn = (op1[2] & 7) << 1 | op1[12] & 1
        patches.append(Patch(name=name, blank=name.lower().startswith('blank'), fb_conn=fb_conn, ops=(_op_registers(op2, wave_car), _op_registers(op1, wave_mod))))
    while len(patches) < 128:
        patches.append(Patch('', True, 0, ((0, 0, 0, 0, 0), (0, 0, 0, 0, 0))))
    return patches[:128]

def _instrument(patch: Patch) -> bytes:
    out = bytearray(WOPL_INST_SIZE)
    out[0:32] = patch.name.encode('latin-1', 'replace')[:32].ljust(32, b'\x00')
    struct.pack_into('>hh', out, 32, 0, 0)
    out[36] = 0
    out[37] = 0
    out[38] = 0
    out[39] = WOPL_INS_BLANK if patch.blank else WOPL_INS_2OP
    out[40] = patch.fb_conn
    out[41] = 0
    for index, op in enumerate(patch.ops):
        off = 42 + index * 5
        out[off:off + 5] = bytes(op)
    struct.pack_into('>HH', out, 62, 0, 0)
    return bytes(out)

def build_wopl(melodic: list[Patch], drums: list[Patch]) -> bytes:
    out = bytearray()
    out += WOPL_MAGIC
    out += struct.pack('<H', WOPL_VERSION)
    out += struct.pack('>HH', 1, 1)
    out += bytes([0, WOPL_VM_HMI])
    for name in (b'SSF2T DOS melodic', b'SSF2T DOS drums'):
        out += name.ljust(32, b'\x00') + bytes([0, 0])
    for bank in (melodic, drums):
        for patch in bank:
            out += _instrument(patch)
    return bytes(out)

def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--melodic', required=True, type=Path)
    ap.add_argument('--drum', required=True, type=Path)
    ap.add_argument('--out', required=True, type=Path)
    a = ap.parse_args(argv)
    melodic = read_bnk(a.melodic)
    drums = read_bnk(a.drum)
    blob = build_wopl(melodic, drums)
    expected = 11 + 2 + 4 + 2 + 2 * 34 + 2 * 128 * WOPL_INST_SIZE
    if len(blob) != expected:
        raise SystemExit(f'internal error: wrote {len(blob)} bytes, expected {expected}')
    a.out.parent.mkdir(parents=True, exist_ok=True)
    a.out.write_bytes(blob)
    named = sum((1 for p in melodic if not p.blank))
    print(f'{a.melodic.name}: {named} named of {len(melodic)} melodic slots')
    print(f'{a.drum.name}: {sum((1 for p in drums if not p.blank))} named of {len(drums)} percussion slots')
    print(f'wrote {a.out} ({len(blob)} bytes, WOPL v{WOPL_VERSION}, volume model HMI)')
    return 0
if __name__ == '__main__':
    sys.exit(main())
