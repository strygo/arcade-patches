"""List ISO9660 filesystem from a raw 2352-byte/sector bin (Mode1 or Mode2Form1)."""
import sys, struct
SECTOR = 2352

def user_data(f, lba, base_lba=0):
    f.seek((lba - base_lba) * SECTOR)
    raw = f.read(SECTOR)
    if len(raw) < SECTOR:
        return b''
    mode = raw[15]
    if mode == 1:
        return raw[16:16 + 2048]
    elif mode == 2:
        return raw[24:24 + 2048]
    else:
        return raw[16:16 + 2048]

def read_extent(f, lba, size, base_lba=0):
    out = b''
    n = (size + 2047) // 2048
    for i in range(n):
        out += user_data(f, lba + i, base_lba)
    return out[:size]

def parse_dir(f, lba, size, base_lba, path, out, depth=0):
    data = read_extent(f, lba, size, base_lba)
    off = 0
    while off < len(data):
        ln = data[off]
        if ln == 0:
            off = (off // 2048 + 1) * 2048
            continue
        rec = data[off:off + ln]
        ext_lba = struct.unpack('<I', rec[2:6])[0]
        ext_size = struct.unpack('<I', rec[10:14])[0]
        flags = rec[25]
        name_len = rec[32]
        name = rec[33:33 + name_len].decode('ascii', 'replace')
        if name not in ('\x00', '\x01'):
            nm = name.split(';')[0]
            full = path + '/' + nm
            isdir = bool(flags & 2)
            out.append((full, ext_lba, ext_size, isdir))
            if isdir and depth < 8:
                parse_dir(f, ext_lba, ext_size, base_lba, full, out, depth + 1)
        off += ln

def main():
    binpath = sys.argv[1]
    base_lba = 0
    extract = None
    args = sys.argv[2:]
    while args:
        a = args.pop(0)
        if a == '--extract':
            extract = (args.pop(0), args.pop(0))
        elif a == '--track-start-lba':
            base_lba = int(args.pop(0))
    f = open(binpath, 'rb')
    pvd = user_data(f, 16 + base_lba, base_lba)
    assert pvd[1:6] == b'CD001', f'no PVD: {pvd[:8]!r}'
    root = pvd[156:156 + 34]
    root_lba = struct.unpack('<I', root[2:6])[0]
    root_size = struct.unpack('<I', root[10:14])[0]
    vol_size = struct.unpack('<I', pvd[80:84])[0]
    print(f"# volume: {pvd[40:72].decode('ascii', 'replace').strip()} vol_sectors={vol_size} root_lba={root_lba}")
    out = []
    parse_dir(f, root_lba, root_size, base_lba, '', out)
    if extract:
        name, dest = extract
        for full, lba, size, isdir in out:
            if full.lstrip('/').upper() == name.upper() and (not isdir):
                data = read_extent(f, lba, size, base_lba)
                open(dest, 'wb').write(data)
                print(f'extracted {full} lba={lba} size={size} -> {dest}')
                return
        print(f'NOT FOUND: {name}')
    else:
        for full, lba, size, isdir in sorted(out):
            t = 'DIR ' if isdir else 'file'
            print(f'{t} lba={lba:7d} size={size:10d} {full}')
if __name__ == '__main__':
    main()
