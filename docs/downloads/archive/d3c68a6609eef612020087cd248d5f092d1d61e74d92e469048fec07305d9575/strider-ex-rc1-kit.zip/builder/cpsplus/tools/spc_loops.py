"""Loop points for SPC songs, from the sound driver's own state."""
from __future__ import annotations
import argparse
import json
import sys
from pathlib import Path
import numpy as np
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
sys.path.insert(0, str(Path(__file__).resolve().parent))
from pack import spc_engine
REPO = Path(__file__).resolve().parents[2]
SCRATCH = REPO / 'cpsplus' / 'work' / 'spc' / 'tmp'
PMIN_SECONDS = 0.5
PITCH_TOL = 0.95
WOBBLE_FRAMES = 768
WOBBLE_LOOSE_FRAMES = 1536
MERGE_FRAMES = 256

def _periodic_from(sig: np.ndarray, q: int) -> int:
    """Earliest k0 with sig[k] == sig[k+q] for all k >= k0, or -1."""
    same = np.all(sig[:-q] == sig[q:], axis=1) if sig.ndim == 2 else sig[:-q] == sig[q:]
    if not same[-1]:
        return -1
    bad = np.nonzero(~same)[0]
    return int(bad[-1] + 1) if len(bad) else 0

def _events(recs: np.ndarray):
    """Key-on events: key-on ticks no more than MERGE_FRAMES apart are one"""
    kon = recs['kon']
    ticks = np.nonzero(kon)[0]
    if len(ticks) == 0:
        return None
    spacing = float(np.median(np.diff(recs['frame'])))
    gap = max(1, int(MERGE_FRAMES // spacing))
    breaks = np.nonzero(np.diff(ticks) > gap)[0]
    first = np.concatenate([[ticks[0]], ticks[breaks + 1]])
    last = np.concatenate([ticks[breaks], [ticks[-1]]])
    mask = np.bitwise_or.reduceat(kon[ticks], np.concatenate([[0], breaks + 1]))
    return (first, last, mask.astype(np.int32))

def _notes(recs: np.ndarray, last: np.ndarray, mask: np.ndarray):
    """Per event and voice: instrument (SRCN) and pitch in semitones for the"""
    regs = recs['regs'][last].astype(np.int32)
    on = np.stack([(mask >> v & 1).astype(bool) for v in range(8)], 1)
    srcn = np.where(on, regs[:, 4:128:16], -1)
    pitch = (regs[:, 2:128:16] | regs[:, 3:128:16] << 8) & 16383
    semi = np.where(on, 12 * np.log2(np.maximum(pitch, 1) / 4096.0), 0.0)
    return (srcn, semi)

def _same_notes(mask, srcn, semi, n):
    """Events j and j+n carry the same notes.  A pitch-only mismatch at a"""
    base = (mask[:-n] == mask[n:]) & np.all(srcn[:-n] == srcn[n:], axis=1)
    pitch = np.all(np.abs(semi[:-n] - semi[n:]) < PITCH_TOL, axis=1)
    prev = np.concatenate([[True], pitch[:-1]])
    nxt = np.concatenate([pitch[1:], [True]])
    return base & (pitch | prev & nxt)
VOICE_REGS = (0, 1, 4, 5, 6, 7)
GLOBAL_REGS = (12, 28, 44, 60, 13, 45, 61, 77, 93, 108, 109, 125, 15, 31, 47, 63, 79, 95, 111, 127)

def _voices(recs: np.ndarray) -> list[dict]:
    """Each voice's own note stream: the tick of every key-on, and at it the"""
    kon = recs['kon'].astype(np.int32)
    regs = recs['regs'].astype(np.int32)
    out = []
    for v in range(8):
        t = np.nonzero(kon >> v & 1)[0]
        r = regs[t]
        pitch = (r[:, v * 16 + 2] | r[:, v * 16 + 3] << 8) & 16383
        cols = [v * 16 + x for x in VOICE_REGS] + list(GLOBAL_REGS)
        out.append({'t': t, 'srcn': r[:, v * 16 + 4], 'semi': 12 * np.log2(np.maximum(pitch, 1) / 4096.0), 'regs': r[:, cols], 'cols': cols})
    return out

def _periodic_start(ok: np.ndarray) -> int:
    """Earliest index from which ok holds to the end (len(ok) if never)."""
    if len(ok) == 0:
        return 0
    if not ok[-1]:
        return len(ok)
    bad = np.nonzero(~ok)[0]
    return int(bad[-1] + 1) if len(bad) else 0

def _systematic(m: np.ndarray) -> np.ndarray:
    """Mismatches that are not isolated: a lone mismatch between two matches"""
    prev = np.concatenate([[False], m[:-1]])
    nxt = np.concatenate([m[1:], [False]])
    return m & (prev | nxt)

def _voice_fit(vc: dict, P: int, wobble: int):
    """For one voice and a period of about P ticks: its notes per pass n (the"""
    t = vc['t']
    if len(t) < 2:
        return None
    back = np.nonzero(np.abs(t[-1] - t[:-1] - P) <= wobble)[0]
    if len(back) == 0:
        return None
    n = int(len(t) - 1 - back[-1])
    dt = t[n:] - t[:-n]
    timing = np.abs(dt - P) <= wobble
    srcn = vc['srcn'][:-n] == vc['srcn'][n:]
    pitch = np.abs(vc['semi'][:-n] - vc['semi'][n:]) < PITCH_TOL
    ok = srcn & timing & ~_systematic(~pitch)
    return {'n': n, 'ok': ok, 'start': _periodic_start(ok), 'dt': dt}

def _fit(voices: list[dict], P: int, wobble: int, K: int):
    """Loop start tick for period ~P: after the last note, in any voice, that"""
    start_tick, fits = (0, {})
    for v, vc in enumerate(voices):
        t = vc['t']
        if len(t) == 0:
            continue
        if t[-1] < K - 2 * P:
            start_tick = max(start_tick, int(t[-1]) + 1)
            continue
        f = _voice_fit(vc, P, wobble)
        if f is None or f['start'] >= len(f['ok']):
            return None
        fits[v] = f
        if f['start'] > 0:
            start_tick = max(start_tick, int(t[f['start'] - 1]) + 1)
    return (start_tick, fits) if fits else None

def _own_periods(voices: list[dict], wobble: int, K: int, pmin: int, spacing: float) -> dict:
    """Diagnostic for a song with no common period: each voice's OWN period"""
    out = {}
    for v, vc in enumerate(voices):
        t = vc['t']
        if len(t) < 4 or t[-1] < K * 3 // 4:
            continue
        r = len(t) - 1
        same = (vc['srcn'][:r] == vc['srcn'][r]) & (np.abs(vc['semi'][:r] - vc['semi'][r]) < PITCH_TOL)
        for g in np.sort(t[r] - t[:r][same]):
            if g < pmin or g > K // 3:
                continue
            f = _voice_fit(vc, int(g), wobble)
            if f is not None and f['start'] < len(f['ok']) and (K - t[f['start']] >= 3 * g):
                out[f'v{v}'] = round(float(g) * spacing / spc_engine.RATE, 3)
                break
        else:
            out[f'v{v}'] = None
    return out

def analyse(recs: np.ndarray, frames: int, wobble_frames: int=WOBBLE_FRAMES) -> dict:
    K = len(recs)
    out: dict = {'ticks': int(K), 'frames': int(frames)}
    if K < 64:
        out.update(kind='error', reason=f'only {K} driver ticks')
        return out
    fr = recs['frame']
    spacing = float(np.median(np.diff(fr)))
    out['tick_frames'] = spacing
    kon = recs['kon'].astype(np.int32)
    keyed = np.nonzero(kon)[0]
    last_kon = int(keyed[-1]) if len(keyed) else -1
    out['last_kon_tick'] = last_kon
    if last_kon < K * 3 // 4:
        out['kind'] = 'one_shot'
        out['end_frame'] = int(fr[last_kon]) if last_kon >= 0 else 0
        return out
    wobble = max(1, int(round(wobble_frames / spacing)))
    out['wobble_ticks'] = wobble
    out['wobble_ms'] = round(wobble_frames / spc_engine.RATE * 1000)
    voices = _voices(recs)
    pmin = int(PMIN_SECONDS * spc_engine.RATE / spacing)
    active = [vc for vc in voices if len(vc['t']) >= 2 and vc['t'][-1] >= K * 3 // 4]
    if not active:
        out.update(kind='fail', reason='the key-ons never recur')
        return out
    gaps = []
    for vc in active:
        t, gs = (vc['t'], [])
        for r in range(max(1, len(t) - 8), len(t)):
            same = (vc['srcn'][:r] == vc['srcn'][r]) & (np.abs(vc['semi'][:r] - vc['semi'][r]) < PITCH_TOL)
            gs.append(t[r] - t[:r][same])
        g = np.unique(np.concatenate(gs))
        gaps.append(g[(g >= pmin) & (g <= (K - K // 4) // 2)])
    base = min(gaps, key=len)
    cands, prev = ([], -10 ** 9)
    for g in base:
        if all((len(o) and np.min(np.abs(o[np.clip(np.searchsorted(o, g) - 1, 0, len(o) - 1):np.searchsorted(o, g) + 1] - g)) <= wobble for o in gaps)):
            if g > prev + 2 * wobble:
                cands.append(int(g))
            prev = g
    if not cands:
        out.update(kind='fail', reason='the key-ons never recur')
        return out
    fit, P = (None, None)
    dil = np.zeros_like(kon)
    for d in range(-wobble, wobble + 1):
        dil |= np.roll(kon, d)
    a = K // 3
    for c in cands[:64]:
        x = kon[a:K - c]
        n = np.count_nonzero(x)
        if not n or np.count_nonzero(x & ~dil[a + c:K]) > 0.01 * n:
            continue
        f = _fit(voices, c, wobble, K)
        if f is not None and K - f[0] >= 3 * c:
            P, fit = (c, f)
            break
    out['tick_periods'] = [int(c) for c in cands[:6]]
    if fit is None:
        out.update(kind='fail', reason="no period at which every voice's notes recur", voice_periods_s=_own_periods(voices, wobble, K, pmin, spacing))
        return out
    dts = np.concatenate([f['dt'][f['start']:] for f in fit[1].values()])
    P_ref = int(np.median(dts)) if len(dts) else P
    if P_ref != P:
        g = _fit(voices, P_ref, wobble, K)
        if g is not None:
            P, fit = (P_ref, g)
    start_tick, fits = fit
    for mult in (2, 3, 4):
        if K - start_tick < 2 * mult * P:
            break
        hits = []
        for v, f in fits.items():
            vc = voices[v]
            n, j = (f['n'], f['start'])
            span = len(vc['t']) - j - mult * n
            if span <= n:
                continue
            R = vc['regs']
            short = np.mean(R[j:j + span] != R[j + n:j + n + span], axis=0)
            long_ = np.mean(R[j:j + span] != R[j + mult * n:j + mult * n + span], axis=0)
            hits += [f"${vc['cols'][i]:02X}" for i in np.nonzero((short >= 0.1) & (long_ <= 0.01))[0]]
        if hits:
            g = _fit(voices, mult * P, wobble, K)
            if g is not None:
                out['promoted_from'] = {'ticks': int(P), 'registers': sorted(set(hits))[:8]}
                P, (start_tick, fits) = (mult * P, g)
            break
    modulated = set()
    for v, f in fits.items():
        vc = voices[v]
        n = f['n']
        m = vc['regs'][:-n] != vc['regs'][n:]
        free = np.any(m[-2 * n:], axis=0)
        for i in np.nonzero(free)[0]:
            modulated.add(f"${vc['cols'][i]:02X}")
        own = np.zeros(m.shape[1], bool)
        own[:len(VOICE_REGS)] = True
        sysm = np.any(m[:, own & ~free], axis=1) | _systematic(np.any(m[:, ~own & ~free], axis=1))
        rows = np.nonzero(sysm)[0]
        if len(rows):
            start_tick = max(start_tick, int(vc['t'][rows[-1]]) + 1)
    out['modulated_registers'] = sorted(modulated)
    first = keyed[np.searchsorted(keyed, start_tick)] if start_tick <= keyed[-1] else None
    if first is None:
        out.update(kind='fail', reason='no notes after the loop start')
        return out
    v = int(np.log2(kon[first] & -kon[first]))
    vc, f = (voices[v], fits.get(v))
    if f is None:
        out.update(kind='fail', reason=f'voice {v} opens the loop but does not recur')
        return out
    i = int(np.searchsorted(vc['t'], first))
    lengths = []
    for k in range(i, len(vc['t']) - f['n'], f['n']):
        a0, a1 = (vc['t'][k], vc['t'][k + f['n']])
        lengths.append(int(fr[a1 - 1] - fr[a0 - 1]) if a0 > 0 else int(fr[a1 - 1] + 1))
    if not lengths:
        out.update(kind='fail', reason='no whole pass after the loop start')
        return out
    ram = recs['ram'][vc['t']]
    n = f['n']
    varying = np.any(ram != ram[0], axis=0)
    free = np.any(ram[-2 * n:-n] != ram[-n:], axis=0) & varying if len(ram) > 2 * n else varying
    out['free_running_ram'] = [f'${x:04X}' for x in np.nonzero(free)[0]]
    t0 = int(fr[first - 1] + 1) if first > 0 else 0
    period = lengths[0]
    jitter = max(lengths) - min(lengths)
    passes = (frames - t0) / float(np.mean(lengths))
    pairs = []
    for k in range(i, min(i + f['n'], len(vc['t']) - f['n'])):
        a0, a1 = (int(vc['t'][k]), int(vc['t'][k + f['n']]))
        pairs.append([int(fr[a0 - 1] + 1) if a0 > 0 else 0, int(fr[a1 - 1] + 1)])
    out['seam_pairs'] = pairs
    out.update(period_ticks=int(P), voices_in_loop=sorted((int(x) for x in fits)), pass_lengths=sorted(set(lengths))[:8], pass_jitter_frames=int(jitter), t0=t0, period=int(period), t0_s=round(t0 / spc_engine.RATE, 4), period_s=round(period / spc_engine.RATE, 4), period_mean_s=round(float(np.mean(lengths)) / spc_engine.RATE, 5), passes=round(passes, 2))
    if passes < 3:
        out.update(kind='fail', reason=f'only {passes:.2f} passes after the loop start')
    elif jitter > 2 * wobble_frames:
        out.update(kind='fail', reason=f'pass length varies by {jitter} frames')
    else:
        out['kind'] = 'loop'
    return out

def run(path: Path, seconds: int) -> dict:
    frames = seconds * spc_engine.RATE
    recs, summary = spc_engine.ticks(path, frames, SCRATCH)
    res = analyse(recs, frames)
    if res.get('kind') == 'fail' and 'passes' not in res.get('reason', ''):
        loose = analyse(recs, frames, WOBBLE_LOOSE_FRAMES)
        if loose.get('kind') != 'fail':
            res = loose
    res.update(file=path.name, timer_mask=summary['timer_mask'], non_mask=summary['non_mask'])
    if res.get('kind') == 'fail' and seconds < 1200:
        return run(path, seconds * 2)
    return res
ALBUM_JOIN = {'a88-04.spc': '32', 'a88-05.spc': '39', 'a88-06.spc': '35', 'a88-07.spc': '36', 'a88-08.spc': '37', 'a88-09.spc': '44', 'a88-10.spc': '41', 'a88-11.spc': '38', 'a88-18.spc': '45', 'a88-21.spc': '47'}
ONE_SHOTS = {'a88-16.spc', 'a88-17.spc', 'a88-19.spc', 'a88-20.spc', 'a88-s01.spc', 'a88-s02.spc'}
ALBUM_TOL = 0.0005

def validate() -> int:
    import pin_spc_sets
    sources = {x['project']: x for x in json.loads(pin_spc_sets.MANIFEST.read_text())['sets']}
    rsn = pin_spc_sets.spc_dir(None) / 'a88.rsn'
    problems = pin_spc_sets.verify('a88', rsn, sources['a88'])
    if problems:
        print('\n'.join(problems))
        return 1
    album = {}
    tsv = REPO / 'cpsplus' / 'manifests' / 'unsquad_snes_loops.tsv'
    for line in tsv.read_text().splitlines():
        f = line.split('\t')
        if line.startswith('#') or len(f) < 4 or f[1] != 'repeat':
            continue
        album[f[0]] = (int(f[3]) - int(f[2])) / 44100
    scratch = SCRATCH / 'validate_a88'
    members = spc_engine.extract(rsn, scratch)
    failures = 0
    for name in sorted((m for m in members if m.endswith('.spc'))):
        r = run(scratch / name, 300)
        want = 'one_shot' if name in ONE_SHOTS else 'loop'
        ok = r['kind'] == want
        note = ''
        if name in ALBUM_JOIN and ok:
            ref = album[ALBUM_JOIN[name]]
            err = abs(r['period_mean_s'] - ref) / ref
            ok = err <= ALBUM_TOL
            note = f'album tr{ALBUM_JOIN[name]} {ref:.3f}s, off {err * 100:.3f}%'
        failures += not ok
        print(f"{('ok ' if ok else 'BAD')} {name:12} {r['kind']:8} P={r.get('period_s')} t0={r.get('t0_s')} {note} {r.get('reason', '')}")
    print('spc loop validation:', 'PASS' if not failures else f'{failures} FAILED')
    return 1 if failures else 0
INVENTORY = REPO / 'cpsplus' / 'manifests' / 'spc_inventory.json'
KEEP = ('kind', 'period', 'period_s', 'period_mean_s', 't0', 't0_s', 'passes', 'wobble_ms', 'pass_jitter_frames', 'period_events', 'note_periods', 'promoted_from', 'modulated_registers', 'end_frame', 'reason', 'timer_mask', 'non_mask')

def inventory() -> int:
    """Loop analysis of every music/bonus member of every pinned set, keyed by"""
    import pin_spc_sets
    doc = json.loads(pin_spc_sets.MANIFEST.read_text())
    directory = pin_spc_sets.spc_dir(None)
    sets = []
    for entry in doc['sets']:
        project = entry['project']
        rsn = directory / f'{project}.rsn'
        problems = pin_spc_sets.verify(project, rsn, entry)
        if problems:
            print('\n'.join(problems))
            return 1
        scratch = SCRATCH / f'inventory_{project}'
        spc_engine.extract(rsn, scratch)
        songs = []
        for m in entry['members']:
            if m.get('kind') not in ('music', 'bonus'):
                continue
            r = run(scratch / m['name'], 300)
            row = {'name': m['name'], 'sha256': m['sha256'], 'title': m['title']}
            row.update({k: r[k] for k in KEEP if k in r})
            if m.get('seconds'):
                est = r['t0_s'] + 2 * r['period_s'] if r['kind'] == 'loop' else r.get('end_frame', 0) / spc_engine.RATE if r['kind'] == 'one_shot' else None
                if est is not None:
                    row['tag_seconds'] = m['seconds']
                    row['tag_minus_estimate_s'] = round(m['seconds'] - est, 2)
            songs.append(row)
            print(f"{project:6} {m['name']:14} {r['kind']:8} P={r.get('period_s')} t0={r.get('t0_s')} {m['title']} {r.get('reason', '')}", flush=True)
        sets.append({'project': project, 'game': entry['game'], 'songs': songs})
    INVENTORY.write_text(json.dumps({'schema': 1, 'engine': 'snes_spc 0.9.0 accurate', 'generated_by': 'cpsplus/tools/spc_loops.py --inventory', 'sets': sets}, indent=1, ensure_ascii=False) + '\n')
    bad = sum((1 for x in sets for y in x['songs'] if y['kind'] not in ('loop', 'one_shot')))
    print(f'wrote {INVENTORY.relative_to(REPO)}; {bad} song(s) without a loop or one-shot')
    return 0

def self_test() -> None:
    K, intro, q = (1200, 8, 200)
    recs = np.zeros(K, dtype=spc_engine.TICK)
    recs['frame'] = np.arange(K) * 256 + 255
    pos = np.array([k if k < intro else intro + (k - intro) % q for k in range(K)])
    sec = np.where(pos < intro, pos, intro + (pos - intro) % 100)
    recs['kon'] = np.where((sec % 5 == 0) & (sec % 7 != 3), 1 << sec % 8, 0)
    recs['regs'][:, 4] = sec % 3
    recs['regs'][:, 0] = np.where(pos - intro >= 100, 64, 127)
    recs['ram'][:, 32] = pos & 255
    recs['ram'][:, 192] = np.arange(K) & 255
    res = analyse(recs, K * 256)
    assert res['kind'] == 'loop', res
    assert res['period'] == q * 256 and res['pass_jitter_frames'] == 0, res
    assert res.get('promoted_from', {}).get('registers') == ['$00'], res
    assert '$00C0' in res['free_running_ram'], res
    recs['regs'][:, 0] = 127
    res = analyse(recs, K * 256)
    assert res['kind'] == 'loop' and res['period'] == 100 * 256, res
    recs['kon'][K // 2:] = 0
    assert analyse(recs, K * 256)['kind'] == 'one_shot'
    print('spc_loops self-test: OK')

def main(argv: list[str] | None=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('files', nargs='*', type=Path)
    ap.add_argument('--seconds', type=int, default=300)
    ap.add_argument('--json', type=Path)
    ap.add_argument('--self-test', action='store_true')
    ap.add_argument('--validate', action='store_true')
    ap.add_argument('--inventory', action='store_true')
    a = ap.parse_args(argv)
    if a.self_test:
        self_test()
        return 0
    if a.validate:
        return validate()
    if a.inventory:
        return inventory()
    results = []
    for f in a.files:
        r = run(f, a.seconds)
        results.append(r)
        brief = {k: r.get(k) for k in ('file', 'kind', 'period_s', 't0_s', 'period_ticks', 'kon_mismatch', 'sequencer_bytes', 'reason')}
        print(json.dumps(brief))
    if a.json:
        a.json.write_text(json.dumps(results, indent=1) + '\n')
    return 0
if __name__ == '__main__':
    raise SystemExit(main())
