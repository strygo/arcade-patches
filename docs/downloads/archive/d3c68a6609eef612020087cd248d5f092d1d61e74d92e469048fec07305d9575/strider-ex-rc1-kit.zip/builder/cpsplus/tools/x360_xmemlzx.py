"""XMemCompress (Xbox 360 LZX) page-file decompressor, pure Python."""
import struct
MIN_MATCH = 2
NUM_CHARS = 256
PRETREE_NUM_ELEMENTS = 20
ALIGNED_NUM_ELEMENTS = 8
NUM_PRIMARY_LENGTHS = 7
NUM_SECONDARY_LENGTHS = 249
BLOCKTYPE_VERBATIM, BLOCKTYPE_ALIGNED, BLOCKTYPE_UNCOMPRESSED = (1, 2, 3)
extra_bits = [0] * 52
position_base = [0] * 52
_j = 0
for _i in range(52):
    extra_bits[_i] = _j
    if _i >= 3 and _i & 1 == 1 and (_j < 17):
        _j += 1
_j = 0
for _i in range(52):
    position_base[_i] = _j
    _j += 1 << extra_bits[_i]

class Bits:
    """LZX bitstream: 16-bit little-endian words, bits taken MSB first."""
    __slots__ = ('data', 'pos', 'end', 'buf', 'left')

    def __init__(self, data, pos, end):
        self.data, self.pos, self.end, self.buf, self.left = (data, pos, end, 0, 0)

    def ensure(self, n):
        while self.left < n:
            if self.pos + 1 < self.end:
                w = self.data[self.pos] | self.data[self.pos + 1] << 8
                self.pos += 2
            else:
                w = 0
                self.pos += 2
            self.buf = (self.buf << 16 | w) & 4294967295
            self.left += 16

    def peek(self, n):
        self.ensure(n)
        return self.buf >> self.left - n & (1 << n) - 1

    def remove(self, n):
        self.left -= n
        self.buf &= (1 << self.left) - 1 if self.left else 0

    def read(self, n):
        if n == 0:
            return 0
        v = self.peek(n)
        self.remove(n)
        return v

    def align16(self):
        if self.left & 15:
            self.remove(self.left & 15)

def make_decode_table(nsyms, nbits, lengths):
    """Return (table, nbits) where table[code] = symbol for the first nbits bits,"""
    table = [-1] * (1 << nbits)
    slow = {}
    bl_count = [0] * 18
    for l in lengths:
        bl_count[l] += 1
    bl_count[0] = 0
    next_code = [0] * 18
    code = 0
    for b in range(1, 18):
        code = code + bl_count[b - 1] << 1
        next_code[b] = code
    for sym in range(nsyms):
        l = lengths[sym]
        if l == 0:
            continue
        c = next_code[l]
        next_code[l] += 1
        if l <= nbits:
            base = c << nbits - l
            for k in range(1 << nbits - l):
                table[base + k] = sym
        else:
            slow[l, c] = sym
    return (table, slow)

class Tree:

    def __init__(self, nsyms, nbits):
        self.nsyms, self.nbits = (nsyms, nbits)
        self.lengths = [0] * nsyms
        self.table, self.slow = (None, None)

    def build(self):
        self.table, self.slow = make_decode_table(self.nsyms, self.nbits, self.lengths)

    def decode(self, bits):
        v = bits.peek(self.nbits)
        sym = self.table[v]
        if sym >= 0:
            bits.remove(self.lengths[sym])
            return sym
        l = self.nbits
        code = v
        while l < 17:
            l += 1
            code = code << 1 | bits.peek(l) & 1
            s = self.slow.get((l, code))
            if s is not None:
                bits.remove(l)
                return s
        raise ValueError('bad huffman code')

class LzxDecoder:

    def __init__(self, window_bits):
        assert 15 <= window_bits <= 21
        self.window_size = 1 << window_bits
        posn_slots = {15: 30, 16: 32, 17: 34, 18: 36, 19: 38, 20: 42, 21: 50}[window_bits]
        self.main_elements = NUM_CHARS + (posn_slots << 3)
        self.window = bytearray(self.window_size)
        self.window_posn = 0
        self.R0 = self.R1 = self.R2 = 1
        self.header_read = False
        self.intel_filesize = 0
        self.intel_curpos = 0
        self.intel_started = False
        self.block_type = 0
        self.block_length = 0
        self.block_remaining = 0
        self.frames_read = 0
        self.pretree = Tree(PRETREE_NUM_ELEMENTS, 6)
        self.maintree = Tree(self.main_elements, 12)
        self.lengthtree = Tree(NUM_SECONDARY_LENGTHS + 1, 12)
        self.alignedtree = Tree(ALIGNED_NUM_ELEMENTS, 7)

    def read_lengths(self, bits, lens, first, last):
        for i in range(PRETREE_NUM_ELEMENTS):
            self.pretree.lengths[i] = bits.read(4)
        self.pretree.build()
        x = first
        while x < last:
            z = self.pretree.decode(bits)
            if z == 17:
                y = bits.read(4) + 4
                for _ in range(y):
                    if x < last:
                        lens[x] = 0
                    x += 1
            elif z == 18:
                y = bits.read(5) + 20
                for _ in range(y):
                    if x < last:
                        lens[x] = 0
                    x += 1
            elif z == 19:
                y = bits.read(1) + 4
                z = self.pretree.decode(bits)
                z = lens[x] - z
                if z < 0:
                    z += 17
                for _ in range(y):
                    if x < last:
                        lens[x] = z
                    x += 1
            else:
                z = lens[x] - z
                if z < 0:
                    z += 17
                lens[x] = z
                x += 1

    def decompress(self, data, pos, end, out_len):
        """Decompress one frame: bytes data[pos:end] -> out_len bytes."""
        bits = Bits(data, pos, end)
        window, wsize = (self.window, self.window_size)
        wpos = self.window_posn
        R0, R1, R2 = (self.R0, self.R1, self.R2)
        if not self.header_read:
            if bits.read(1):
                hi = bits.read(16)
                lo = bits.read(16)
                self.intel_filesize = hi << 16 | lo
            self.header_read = True
        this_run = out_len
        start = wpos
        while this_run > 0:
            if self.block_remaining == 0:
                if self.block_type == BLOCKTYPE_UNCOMPRESSED:
                    if self.block_length & 1:
                        bits.pos += 1
                    bits.left = 0
                    bits.buf = 0
                self.block_type = bits.read(3)
                hi = bits.read(16)
                lo = bits.read(8)
                self.block_remaining = self.block_length = hi << 8 | lo
                bt = self.block_type
                if bt == BLOCKTYPE_ALIGNED:
                    for i in range(ALIGNED_NUM_ELEMENTS):
                        self.alignedtree.lengths[i] = bits.read(3)
                    self.alignedtree.build()
                if bt in (BLOCKTYPE_ALIGNED, BLOCKTYPE_VERBATIM):
                    self.read_lengths(bits, self.maintree.lengths, 0, NUM_CHARS)
                    self.read_lengths(bits, self.maintree.lengths, NUM_CHARS, self.main_elements)
                    self.maintree.build()
                    if self.maintree.lengths[232] != 0:
                        self.intel_started = True
                    self.read_lengths(bits, self.lengthtree.lengths, 0, NUM_SECONDARY_LENGTHS)
                    self.lengthtree.build()
                elif bt == BLOCKTYPE_UNCOMPRESSED:
                    self.intel_started = True
                    bits.ensure(16)
                    if bits.left > 16:
                        bits.pos -= 2
                    bits.left = 0
                    bits.buf = 0
                    p = bits.pos
                    R0 = struct.unpack_from('<I', data, p)[0]
                    R1 = struct.unpack_from('<I', data, p + 4)[0]
                    R2 = struct.unpack_from('<I', data, p + 8)[0]
                    bits.pos = p + 12
                else:
                    raise ValueError('bad block type %d' % bt)
            this_block = min(self.block_remaining, this_run)
            self.block_remaining -= this_block
            this_run -= this_block
            bt = self.block_type
            if bt == BLOCKTYPE_UNCOMPRESSED:
                p = bits.pos
                n = this_block
                if wpos + n <= wsize:
                    window[wpos:wpos + n] = data[p:p + n]
                else:
                    k = wsize - wpos
                    window[wpos:] = data[p:p + k]
                    window[:n - k] = data[p + k:p + n]
                bits.pos = p + n
                wpos = (wpos + n) % wsize
                continue
            maintree, lengthtree, alignedtree = (self.maintree, self.lengthtree, self.alignedtree)
            aligned = bt == BLOCKTYPE_ALIGNED
            while this_block > 0:
                main = maintree.decode(bits)
                if main < NUM_CHARS:
                    window[wpos] = main
                    wpos += 1
                    if wpos == wsize:
                        wpos = 0
                    this_block -= 1
                    continue
                main -= NUM_CHARS
                match_length = main & NUM_PRIMARY_LENGTHS
                if match_length == NUM_PRIMARY_LENGTHS:
                    match_length += lengthtree.decode(bits)
                match_length += MIN_MATCH
                slot = main >> 3
                if slot > 2:
                    extra = extra_bits[slot]
                    if aligned and extra >= 3:
                        verbatim = bits.read(extra - 3) << 3
                        a = alignedtree.decode(bits)
                        match_offset = position_base[slot] - 2 + verbatim + a
                    else:
                        verbatim = bits.read(extra)
                        match_offset = position_base[slot] - 2 + verbatim
                    R2 = R1
                    R1 = R0
                    R0 = match_offset
                elif slot == 0:
                    match_offset = R0
                elif slot == 1:
                    match_offset = R1
                    R1 = R0
                    R0 = match_offset
                else:
                    match_offset = R2
                    R2 = R0
                    R0 = match_offset
                src = wpos - match_offset
                if src < 0:
                    src += wsize
                n = match_length
                this_block -= n
                if match_offset >= n and src + n <= wsize and (wpos + n <= wsize):
                    window[wpos:wpos + n] = window[src:src + n]
                    wpos += n
                else:
                    for _ in range(n):
                        window[wpos] = window[src]
                        wpos += 1
                        src += 1
                        if wpos == wsize:
                            wpos = 0
                        if src == wsize:
                            src = 0
                if wpos == wsize:
                    wpos = 0
            if this_block < 0:
                raise ValueError('block overrun')
        self.window_posn = wpos
        self.R0, self.R1, self.R2 = (R0, R1, R2)
        if start + out_len <= wsize:
            out = bytes(window[start:start + out_len])
        else:
            out = bytes(window[start:]) + bytes(window[:start + out_len - wsize])
        self.frames_read += 1
        if self.intel_filesize and self.intel_started and (out_len > 10):
            out = bytearray(out)
            curpos = self.intel_curpos
            fs = self.intel_filesize
            i = 0
            lim = out_len - 10
            while i < lim:
                if out[i] == 232:
                    abs_off = struct.unpack_from('<i', out, i + 1)[0]
                    cp = curpos + i
                    if -cp <= abs_off < fs:
                        rel = abs_off - cp if abs_off >= 0 else abs_off + fs
                        struct.pack_into('<i', out, i + 1, rel)
                    i += 5
                else:
                    i += 1
            out = bytes(out)
        self.intel_curpos += out_len
        return out
PAGE = 131072
MAGIC = b'\x0f\xf5\x12\xed'

def read_header(data):
    if data[:4] != MAGIC:
        raise SystemExit('not an XMemCompress page file (magic %s)' % data[:4].hex())
    npages = (len(data) + PAGE - 1) // PAGE
    table = struct.unpack('>%dI' % npages, data[16:16 + 4 * npages])
    return (npages, table, 16 + 4 * npages)

def decompress_pages(data, window_bits=17, log=None):
    """Return (bytes, bad_pages); a failed page is zero-filled to its table size."""
    npages, table, data_start = read_header(data)
    out = bytearray()
    bad = []
    for k in range(npages):
        start = data_start if k == 0 else k * PAGE
        end = min((k + 1) * PAGE, len(data))
        need = table[k]
        dec = LzxDecoder(window_bits)
        pos, got = (start, 0)
        try:
            while got < need:
                hi, lo = (data[pos], data[pos + 1])
                cs, hdr = (hi << 8 | lo, 2)
                if cs == 0:
                    out += data[pos + 2:pos + 2 + need - got]
                    got = need
                    break
                if hi == 255:
                    cs = data[pos + 3] << 8 | data[pos + 4]
                    hdr = 5
                us = min(32768, need - got)
                if pos + hdr + cs > end:
                    raise ValueError('frame runs past the page')
                out += dec.decompress(data, pos + hdr, pos + hdr + cs, us)
                got += us
                pos += hdr + cs
        except Exception as e:
            bad.append((k, str(e)))
            out += bytes(need - got)
        if log and k % 100 == 0:
            log('page %d/%d: %.1f MB' % (k, npages, len(out) / 1000000.0))
    return (bytes(out), bad)

def main():
    if len(sys.argv) != 3:
        raise SystemExit(__doc__)
    data = open(sys.argv[1], 'rb').read()
    npages, table, _ = read_header(data)
    print('%d pages, table sum %d bytes' % (npages, sum(table)))
    out, bad = decompress_pages(data, log=print)
    open(sys.argv[2], 'wb').write(out)
    print('wrote %s (%d bytes); bad pages: %s' % (sys.argv[2], len(out), bad or 'none'))
    if out[:4] == b'FKP.':
        print('FKP. archive, %d entries' % struct.unpack('<I', out[8:12])[0])
if __name__ == '__main__':
    import sys
    main()
