"""Focused, compiler-free Munt PCM comparison against a declared digest."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import wave
from qualify_optional_helpers import midi

def sha(data):
    return hashlib.sha256(data).hexdigest()

def probe(a):
    if a.work.exists():
        raise ValueError('Fresh focused probe work required')
    a.work.mkdir(parents=True)
    smf = a.work / 'synthetic.mid'
    smf.write_bytes(midi(a.program))
    wav = a.work / 'audio.wav'
    command = [str(a.renderer), '--force', '--quiet', '--rom-dir=' + str(a.roms), '--machine-id=mt32_1_07', '--sample-rate=48000', '--src-quality=3', '--max-partials=32', '--analog-output-mode=2', '--renderer-type=0', '--output-sample-format=0', '--dac-input-mode=2', '--no-nice-amp-ramp', '--record-max-start-silence=-1', '--no-wait-for-la32', '--output=' + str(wav), str(smf)]
    run = subprocess.run(command, cwd=a.work, capture_output=True, timeout=120)
    if run.returncode:
        raise ValueError(run.stderr.decode(errors='replace'))
    with wave.open(str(wav)) as w:
        frames = w.getnframes()
        pcm = w.readframes(frames)
        if (w.getnchannels(), w.getsampwidth(), w.getframerate()) != (2, 2, 48000):
            raise ValueError('Unexpected output format')
    digest = sha(pcm)
    report = dict(schema=1, status='matched' if digest == a.expected else 'different', pcm_sha256=digest, expected=a.expected, frames=frames, program=a.program, renderer_sha256=sha(a.renderer.read_bytes()), midi_sha256=sha(smf.read_bytes()), firmware={name: sha((a.roms / name).read_bytes()) for name in ('mt32_ctrl_1_07.rom', 'mt32_pcm.rom')}, recipe_sha256=sha(Path(__file__).read_bytes()))
    a.out.parent.mkdir(parents=True, exist_ok=True)
    a.out.write_bytes((json.dumps(report, indent=2, sort_keys=True) + '\n').encode())
    if digest != a.expected:
        raise ValueError('PCM differs: ' + digest)
    shutil.rmtree(a.work)
    print('PASS Munt PCM:', digest, flush=True)
if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    for name in ('renderer', 'roms', 'work', 'out'):
        p.add_argument('--' + name, type=Path, required=True)
    p.add_argument('--expected', required=True)
    p.add_argument('--program', type=int, choices=range(128), default=0)
    a = p.parse_args()
    for name, value in vars(a).items():
        if isinstance(value, Path):
            setattr(a, name, value.absolute())
    probe(a)
