"""Freeze an SPC pack's recipe: loop points, seams, stored-PCM hashes, gain."""
from __future__ import annotations
import argparse
import hashlib
import json
import sys
import tempfile
import wave
from pathlib import Path
import numpy as np
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
sys.path.insert(0, str(HERE))
from pack import build_chip, loop_bake, spc_engine
import loudness_match
import setup_spc_tools
import spc_loops
RATE = spc_engine.RATE
SILENCE = 10 ** (-80 / 20) * 32768
TOLERANCE = 1.25
GOOD_ENOUGH = 0.001

def _sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()

def plan_loop(spc: Path, r: dict) -> dict:
    last = max((b for _, b in r['seam_pairs']))
    frames = last + loop_bake.BLEND_N + RATE
    pcm = spc_engine.render(spc, frames)
    x = loop_bake.mono(pcm)
    cands = []
    for a, b in r['seam_pairs']:
        ls = int(round(a / loop_bake.GRID)) * loop_bake.GRID
        le = ls + int(round((b - a) / loop_bake.GRID)) * loop_bake.GRID
        if ls < loop_bake.BLEND_N or le > len(pcm):
            continue
        n = loop_bake.BLEND_N
        ref = x[ls - n:ls]
        cost = float(((x[le - n:le] - ref) ** 2).sum() / max((ref * ref).sum(), 1e-12))
        cands.append((ls, le, cost, a, b))
    if not cands:
        raise SystemExit(f'{spc.name}: no seam pair fits')
    best = min((c[2] for c in cands))
    accept = max(best * TOLERANCE, GOOD_ENOUGH)
    ls, le, cost, a, b = next((c for c in cands if c[2] <= accept))
    return {'mode': 'loop', 'loop_start': ls, 'loop_end': le, 'blend': loop_bake.BLEND_N, 'render_frames': le, 'seam_cost': round(cost, 5), 'seam_best': round(best, 5), 'note_start': a, 'note_end': b, 't0': r['t0'], 'period': r['period'], 'wobble_ms': r.get('wobble_ms')}

def plan_one_shot(spc: Path, r: dict) -> dict:
    frames = r['end_frame'] + 30 * RATE
    pcm = spc_engine.render(spc, frames)
    loud = np.nonzero(np.abs(pcm.astype(np.int32)).max(1) > SILENCE)[0]
    end = int(loud[-1]) + RATE // 4 if len(loud) else RATE
    if end >= frames - RATE:
        raise SystemExit(f'{spc.name}: still sounding 30 s after its last note')
    return {'mode': 'one_shot', 'end': end, 'render_frames': end}

def measure_gain(game: str, rows, src: Path, catalog: Path) -> dict:
    native = loudness_match.native_from_dir(catalog / 'clips')
    deltas = {}
    with tempfile.TemporaryDirectory() as tmp:
        for cmd, spc in rows:
            if cmd not in native:
                continue
            clip, rate = native[cmd]
            a = Path(tmp) / f'n{cmd:02x}.wav'
            loudness_match._write(a, clip, rate)
            pcm = spc_engine.render(src / spc, 30 * RATE)
            b = Path(tmp) / f's{cmd:02x}.wav'
            with wave.open(str(b), 'wb') as o:
                o.setnchannels(2)
                o.setsampwidth(2)
                o.setframerate(RATE)
                o.writeframes(np.ascontiguousarray(pcm, '<i2').tobytes())
            la, lb = (loudness_match.integrated_lufs(str(a)), loudness_match.integrated_lufs(str(b)))
            if la is not None and lb is not None and (la > -70) and (lb > -70):
                deltas[f'0x{cmd:02x}'] = round(lb - la, 2)
    med = float(np.median(list(deltas.values())))
    gain = int(round(min(127, 127 * 10 ** (-med / 20))))
    return {'trigger_gain': gain, 'loudness': {'median_delta_lu': round(med, 2), 'commands': len(deltas), 'deltas': deltas}}

def main(argv: list[str] | None=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--game', required=True, choices=sorted(build_chip.GAMES))
    ap.add_argument('--catalog', type=Path, required=True)
    ap.add_argument('--spc-dir', type=Path)
    a = ap.parse_args(argv)
    cfg = build_chip.GAMES[a.game]
    rows = build_chip.read_map(a.game)
    src = build_chip.extract_set(cfg['set'], a.spc_dir)
    sources = {x['project']: x for x in json.loads(build_chip.pin_spc_sets.MANIFEST.read_text())['sets']}
    members = {m['name']: m for m in sources[cfg['set']]['members']}
    tracks = []
    for spc in sorted({s for _, s in rows}):
        r = spc_loops.run(src / spc, 300)
        if r['kind'] == 'loop':
            t = plan_loop(src / spc, r)
        elif r['kind'] == 'one_shot':
            t = plan_one_shot(src / spc, r)
        else:
            raise SystemExit(f"{spc}: no loop and not a one-shot ({r.get('reason')})")
        t = {'spc': spc, 'title': members[spc]['title'], 'member_sha256': members[spc]['sha256'], **t}
        t['pcm_sha256'] = build_chip.pcm_sha256(build_chip.stored_pcm(src / spc, t))
        tracks.append(t)
        brief = f"loop {t['loop_start'] / RATE:.2f}..{t['loop_end'] / RATE:.2f} s cost {t['seam_cost']}" if t['mode'] == 'loop' else f"one-shot {t['end'] / RATE:.2f} s"
        print(f"{spc:14} {brief:40} {t['title']}", flush=True)
    doc = {'schema': 1, 'game': a.game, 'pack': cfg['pack'], 'set': cfg['set'], 'engine': {'core': 'snes_spc 0.9.0 accurate', 'commit': setup_spc_tools.SNES_SPC_COMMIT, 'harness': setup_spc_tools.harness_digest(), 'rate': RATE, 'filter': False}, 'analyzer_sha256': _sha(HERE / 'spc_loops.py'), 'seam': {'tolerance': TOLERANCE, 'good_enough': GOOD_ENOUGH, 'blend': loop_bake.BLEND_N}, 'catalog': f'tools/arcade_cue_catalog.py --game {a.game} (clips from --catalog)', **measure_gain(a.game, rows, src, a.catalog), 'tracks': tracks, 'triggers': [{'cmd': f'0x{c:04x}', 'spc': s} for c, s in rows]}
    build_chip.recipe_path(a.game).write_text(json.dumps(doc, indent=1, ensure_ascii=False) + '\n')
    print(f"wrote {build_chip.recipe_path(a.game).name}: {len(tracks)} tracks, gain 0x{doc['trigger_gain']:02x} (median {doc['loudness']['median_delta_lu']} LU)")
    return 0
if __name__ == '__main__':
    raise SystemExit(main())
