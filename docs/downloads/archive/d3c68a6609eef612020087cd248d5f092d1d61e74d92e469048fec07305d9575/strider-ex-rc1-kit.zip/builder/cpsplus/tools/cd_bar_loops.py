"""Place CD loop points on the recording's own bar grid."""
from __future__ import annotations
import argparse
import csv
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path
import numpy as np
TOOLS = Path(__file__).resolve().parent
sys.path.insert(0, str(TOOLS))
import hmp as hmp_mod
SR = 22050
HOP = 256
XFADE = 1.0
FADE_MARGIN = 1.5
MIN_BAR, MAX_BAR = (0.8, 6.0)

def mono(path: Path, skip: float=0.0, limit: float | None=None) -> np.ndarray:
    cmd = ['ffmpeg', '-v', 'error']
    if skip:
        cmd += ['-ss', f'{skip}']
    if limit:
        cmd += ['-t', f'{limit}']
    cmd += ['-i', str(path), '-f', 'f32le', '-ac', '1', '-ar', str(SR), '-']
    raw = subprocess.run(cmd, capture_output=True, check=True).stdout
    return np.frombuffer(raw, dtype='<f4').astype(np.float64)

def flux(x: np.ndarray, nfft: int=1024) -> np.ndarray:
    """Spectral flux: where the music puts its accents."""
    frames = [np.abs(np.fft.rfft(x[i:i + nfft] * np.hanning(nfft))) for i in range(0, len(x) - nfft, HOP)]
    if len(frames) < 8:
        return np.zeros(0)
    spec = np.array(frames)
    f = np.maximum(np.diff(spec, axis=0), 0).sum(1)
    return f - f.mean()

def grid_unit(f: np.ndarray, period: float) -> tuple[float, int, float] | None:
    """A grid unit that the loop period is a whole number of."""
    if f.size < 64:
        return None
    ac = np.correlate(f, f, 'full')[f.size - 1:]
    if ac[0] <= 0:
        return None
    ac = ac / ac[0]
    fps = SR / HOP
    lo, hi = (int(MIN_BAR * fps), min(int(MAX_BAR * fps), ac.size - 1))
    if hi <= lo:
        return None
    band = ac[lo:hi]
    peaks = [i for i in range(1, band.size - 1) if band[i] > band[i - 1] and band[i] >= band[i + 1] and (band[i] > 0)]
    if not peaks:
        return None
    best = None
    for i in peaks:
        unit = (lo + i) / fps
        n = period / unit
        k = round(n)
        if k < 2:
            continue
        err = abs(n - k)
        if err > 0.1:
            continue
        score = band[i] * (1.0 - err)
        if best is None or score > best[0]:
            best = (score, unit, k, err)
    if best is None:
        return None
    return (best[1], best[2], best[3])

def tempo_ratio(piece: Path, render: Path, seq_len: float) -> float:
    """How much slower the recording runs than the sequence render."""

    def chroma(x, nfft=2048, hop=512):
        win = np.hanning(nfft)
        freqs = np.fft.rfftfreq(nfft, 1 / SR)
        ok = (freqs > 55) & (freqs < 2000)
        pc = np.zeros(len(freqs), dtype=int)
        pc[ok] = np.round(12 * np.log2(freqs[ok] / 440.0)).astype(int) % 12
        masks = [ok & (pc == k) for k in range(12)]
        C = np.array([[float(np.abs(np.fft.rfft(x[i:i + nfft] * win))[m].sum()) for m in masks] for i in range(0, len(x) - nfft, hop)])
        if len(C) < 8:
            return None
        C = C / np.maximum(C.sum(1, keepdims=True), 1e-09)
        return ((C - C.mean(0)) / np.maximum(C.std(0), 1e-09), hop)
    got = chroma(mono(piece))
    if got is None:
        return 1.0
    cd, hop = got

    def offset(at: float, cap: float | None):
        probe = chroma(mono(render, skip=at, limit=8.0))
        if probe is None:
            return None
        b = probe[0]
        w = len(b)
        hi = len(cd) - w if cap is None else min(int(cap * SR / hop), len(cd) - w)
        if hi <= 0:
            return None
        return max(((float((cd[o:o + w] * b).sum() / (w * 12)), o * hop / SR) for o in range(0, hi, 1)))[1]
    early = offset(2.0, 6.0)
    late_at = max(min(seq_len - 12.0, 40.0), 12.0)
    late = offset(late_at, None)
    if early is None or late is None or late_at <= 2.0:
        return 1.0
    ratio = (late - early) / (late_at - 2.0)
    return ratio if 0.85 <= ratio <= 1.18 else 1.0

def bar_phase(f: np.ndarray, bar: float) -> float:
    """Offset of the first bar line, by comb response over the envelope."""
    fps = SR / HOP
    step = bar * fps
    best = (-1.0, 0.0)
    for shift in np.arange(0, step, max(step / 64, 1.0)):
        idx = np.round(np.arange(shift, f.size - 1, step)).astype(int)
        if idx.size < 4:
            continue
        score = float(f[idx].mean())
        if score > best[0]:
            best = (score, shift / fps)
    return best[1]

def fade_onset(x: np.ndarray) -> float:
    """Where the closing fade begins, in seconds."""
    win = SR // 10
    n = len(x) // win
    env = np.sqrt((x[:n * win] ** 2).reshape(n, win).mean(1))
    if n < 20:
        return len(x) / SR
    med = np.median(env[:int(n * 0.8)])
    for i in range(n - 1, 0, -1):
        if env[i] >= med * 0.6:
            return (i + 1) / 10
    return len(x) / SR

@dataclass
class Row:
    piece: str
    seconds: float
    bar: float
    bars: int
    ls: float
    le: float
    note: str
    confidence: str

def analyse(piece: Path, seq: hmp_mod.HmpFile, render: Path) -> Row:
    x = mono(piece)
    dur = len(x) / SR
    loop = seq.loop
    if loop is None:
        return Row(piece.stem, dur, 0, 0, 0, 0, 'sequence has no loop', 'one-shot')
    f = flux(x)
    ratio = tempo_ratio(piece, render, seq.seconds)
    body = (loop.end_tick - loop.start_tick) / seq.tick_rate * ratio
    got = grid_unit(f, body)
    if got is None:
        return Row(piece.stem, dur, 0, 0, 0, 0, f'no grid divides the {body:.2f}s period', 'open')
    cd_bar, bars, err = got
    phase = bar_phase(f, cd_bar)
    fade = fade_onset(x)
    limit = min(fade - FADE_MARGIN, dur - XFADE - 0.2)
    k = int((limit - phase) // cd_bar)
    le = phase + k * cd_bar
    ls = le - bars * cd_bar
    note = f'grid {cd_bar:.3f}s x{bars} = {bars * cd_bar:.2f}s (seq period {body:.2f}s, division err {err:.3f}), tempo ratio {ratio:.4f}, phase {phase:.3f}s, fade at {fade:.1f}s'
    if ls < 0.5:
        while ls < 0.5 and bars > 2:
            bars -= 1
            ls = le - bars * cd_bar
        note += f' -- shortened to {bars} bars to fit'
        if ls < 0.5:
            return Row(piece.stem, dur, cd_bar, bars, 0, 0, note + '; still does not fit', 'open')
        return Row(piece.stem, dur, cd_bar, bars, ls, le, note, 'medium')
    return Row(piece.stem, dur, cd_bar, bars, ls, le, note, 'high')

def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('pieces_dir', type=Path)
    ap.add_argument('--midi-dir', required=True, type=Path)
    ap.add_argument('--render-dir', required=True, type=Path)
    ap.add_argument('--out', required=True, type=Path)
    ap.add_argument('--only', nargs='*')
    a = ap.parse_args(argv)
    rows: list[Row] = []
    for piece in sorted(a.pieces_dir.glob('*.flac')):
        stem = piece.stem
        if a.only and stem not in a.only:
            continue
        ko = stem.endswith('_KO')
        base = stem[:-3] if ko else stem
        hmp_path = a.midi_dir / f"{base}{('_KOF' if ko else '_F')}.HMP"
        render = a.render_dir / f"{base}{('_KOG' if ko else '_G')}.flac"
        if not hmp_path.is_file() or not render.is_file():
            rows.append(Row(stem, 0, 0, 0, 0, 0, 'no sequence counterpart', 'open'))
            continue
        rows.append(analyse(piece, hmp_mod.parse(hmp_path), render))
        r = rows[-1]
        print(f'{r.piece:10s} {r.confidence:8s} ' + (f'{r.ls:6.2f} -> {r.le:6.2f}  ' if r.le else ' ' * 18) + r.note, flush=True)
    a.out.parent.mkdir(parents=True, exist_ok=True)
    with a.out.open('w', newline='', encoding='utf-8') as handle:
        handle.write("# CD loops on the recording's own bar grid (tools/cd_bar_loops.py)\n")
        w = csv.writer(handle, delimiter='\t', lineterminator='\n')
        w.writerow(['piece', 'seconds', 'loop_start', 'loop_end', 'bar', 'bars', 'confidence', 'note'])
        for r in rows:
            w.writerow([r.piece, f'{r.seconds:.2f}', f'{r.ls:.3f}' if r.le else '-', f'{r.le:.3f}' if r.le else '-', f'{r.bar:.3f}' if r.bar else '-', r.bars or '-', r.confidence, r.note])
    n = sum((1 for r in rows if r.confidence in ('high', 'medium')))
    print(f'\n{n} of {len(rows)} placed -> {a.out}')
    return 0
if __name__ == '__main__':
    sys.exit(main())
