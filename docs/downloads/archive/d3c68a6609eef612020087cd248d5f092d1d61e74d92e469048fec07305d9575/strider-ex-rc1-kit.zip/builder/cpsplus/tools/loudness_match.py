"""Measure how far a pack's arranged audio sits above the NATIVE music it"""
from __future__ import annotations
import argparse
import csv
import subprocess
import sys
import tempfile
import wave
from pathlib import Path
import numpy as np
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from pack.format import PackReader, _parse_header
from pack import audition
TRUE_REFRESH = 59.637405
PROBE_S = 8.0

def integrated_lufs(path: str) -> float | None:
    r = subprocess.run(['ffmpeg', '-hide_banner', '-nostats', '-i', path, '-filter_complex', 'ebur128=peak=true', '-f', 'null', '-'], capture_output=True, text=True).stderr
    val = None
    for ln in r.splitlines():
        if 'I:' in ln and 'LUFS' in ln:
            try:
                val = float(ln.split('I:')[1].split('LUFS')[0])
            except ValueError:
                pass
    return val

def _write(path, mono_i16, rate):
    o = wave.open(str(path), 'w')
    o.setnchannels(1)
    o.setsampwidth(2)
    o.setframerate(rate)
    o.writeframes(np.asarray(mono_i16, dtype='<i2').tobytes())
    o.close()

def native_from_dir(d: Path) -> dict[int, tuple[np.ndarray, int]]:
    """Per-command native clips: <dir>/<cmd>.wav, named 0x1a.wav or 1a.wav."""
    out = {}
    for f in sorted(d.glob('*.wav')):
        stem = f.stem[2:] if f.stem.startswith('0x') else f.stem
        stem = stem.split('_')[0].split('-')[0]
        try:
            cmd = int(stem, 16)
        except ValueError:
            continue
        w = wave.open(str(f))
        sr = w.getframerate()
        ch = w.getnchannels()
        x = np.frombuffer(w.readframes(w.getnframes()), dtype='<i2').astype(np.float32)
        if ch == 2:
            x = x.reshape(-1, 2).mean(axis=1)
        tsv = f.with_suffix('.tsv')
        start = 0
        if tsv.exists():
            rows = [r for r in csv.DictReader(open(tsv), delimiter='\t')]
            if rows:
                if 'seconds' in rows[0]:
                    start = int((float(rows[0]['seconds']) + 1.0) * sr)
                elif 'frame' in rows[0]:
                    start = int((int(rows[0]['frame']) / TRUE_REFRESH + 1.0) * sr)
        out[cmd] = (x[start:], sr)
    return out

def measure(pack: Path, sweep_tsv: Path | None, sweep_wav: Path | None, cmds: list[int] | None=None, native_dir: Path | None=None) -> dict:
    per_cmd = native_from_dir(native_dir) if native_dir else None
    if per_cmd is None:
        rows = [r for r in csv.DictReader([l for l in open(sweep_tsv) if not l.startswith('#')], delimiter='\t')]
        frames = {int(r['cmd'], 16): int(r['frame']) for r in rows if r['cmd'] != '0xff'}
        w = wave.open(str(sweep_wav))
        ch = w.getnchannels()
        sr = w.getframerate()
        p = np.frombuffer(w.readframes(w.getnframes()), dtype='<i2').astype(np.float32)
        if ch == 2:
            p = p.reshape(-1, 2).mean(axis=1)
    else:
        frames = {c: 0 for c in per_cmd}
    rd = PackReader(pack)
    d = pack.read_bytes()
    h = _parse_header(d)

    def track_of(cmd):
        b = d[h.trigger_offset + 4 * cmd:h.trigger_offset + 4 * cmd + 4]
        return b[1] | b[3] >> 4 << 8 if b and b[0] == 1 else None
    todo = cmds if cmds else sorted((c for c in frames if track_of(c) is not None))
    deltas, detail = ([], [])
    with tempfile.TemporaryDirectory() as td:
        for cmd in todo:
            ti = track_of(cmd)
            if ti is None or cmd not in frames:
                continue
            if per_cmd is not None:
                x, sr = per_cmd[cmd]
                seg = x[:int(PROBE_S * sr)]
            else:
                t = frames[cmd] / TRUE_REFRESH + 1.0
                seg = p[int(t * sr):int((t + PROBE_S) * sr)]
            if len(seg) < sr:
                continue
            nf = f'{td}/n{cmd:02x}.wav'
            _write(nf, seg, sr)
            pcm, m = audition.render(rd, ti, loops=0)
            x = np.frombuffer(pcm, dtype='<i2')
            if m.channels == 2:
                x = x.reshape(-1, 2).mean(axis=1)
            af = f'{td}/a{cmd:02x}.wav'
            _write(af, x[:int(PROBE_S * m.sample_rate)], m.sample_rate)
            nl, al = (integrated_lufs(nf), integrated_lufs(af))
            if nl is None or al is None or nl < -60 or (al < -60):
                continue
            deltas.append(al - nl)
            detail.append((cmd, nl, al, al - nl))
    if not deltas:
        return {'n': 0}
    med = float(np.median(deltas))
    gain = max(1, min(127, round(127 * 10 ** (-med / 20))))
    return {'n': len(deltas), 'median_lu': med, 'gain': gain, 'detail': detail, 'spread_lu': float(np.percentile(deltas, 75) - np.percentile(deltas, 25))}

def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--pack', type=Path, required=True)
    ap.add_argument('--sweep', type=Path)
    ap.add_argument('--wav', type=Path)
    ap.add_argument('--native-dir', type=Path, help='per-command native clips (svc_isolate output)')
    ap.add_argument('--probe-seconds', type=float, default=None, help='probe window (default 8 s)')
    ap.add_argument('--cmds')
    a = ap.parse_args(argv)
    cmds = [int(x, 0) for x in a.cmds.split(',')] if a.cmds else None
    if not a.native_dir and (not (a.sweep and a.wav)):
        ap.error('need --native-dir or both --sweep and --wav')
    if a.probe_seconds:
        global PROBE_S
        PROBE_S = a.probe_seconds
    res = measure(a.pack, a.sweep, a.wav, cmds, a.native_dir)
    if not res['n']:
        print('  no measurable pairs')
        return 1
    for cmd, nl, al, dl in res['detail']:
        print(f'    0x{cmd:02x}  native {nl:7.1f}  arranged {al:7.1f}  {dl:+6.1f} LU')
    print(f"\n  {a.pack.name}: {res['n']} pairs, median {res['median_lu']:+.1f} LU (IQR {res['spread_lu']:.1f})")
    print(f"  recommended trigger gain: 0x{res['gain']:02x} ({res['gain']}) vs 0x7f unity")
    return 0
if __name__ == '__main__':
    raise SystemExit(main())
