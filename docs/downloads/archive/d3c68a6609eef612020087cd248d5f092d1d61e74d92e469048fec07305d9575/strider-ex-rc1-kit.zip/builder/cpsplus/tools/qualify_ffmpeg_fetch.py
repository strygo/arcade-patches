"""Check the published media helper download and fail-closed offline/cache paths."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import platform
import subprocess
from unittest.mock import patch
import fetch_ffmpeg as media

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def main():
    p = argparse.ArgumentParser(description=__doc__)
    for n in ('manifest', 'out', 'record'):
        p.add_argument('--' + n, required=True, type=Path)
    a = p.parse_args()
    if a.out.exists():
        raise ValueError('Fresh fetch qualification directory required')
    a.out.mkdir(parents=True)
    host = media.common.host_id()
    lock = media.common.read_lock(a.manifest)
    record = lock['platforms'][host]
    env = dict(CPSPLUS_SWITCH_TOOLS_CACHE=str(a.out.resolve() / 'cache'), CPSPLUS_SWITCH_TOOLS_BUNDLE='', CPSPLUS_SWITCH_TOOLS_OFFLINE='')
    with patch.dict(os.environ, env):
        tools = media.setup(manifest=a.manifest)
        for tool in tools.values():
            subprocess.run([str(tool), '-version'], check=True, capture_output=True)
        os.environ['CPSPLUS_SWITCH_TOOLS_OFFLINE'] = '1'
        with patch.object(media.common, 'download', side_effect=AssertionError('network forbidden')):
            if tools != media.setup(manifest=a.manifest):
                raise ValueError('Cache chose different tools')
            os.environ['CPSPLUS_SWITCH_TOOLS_CACHE'] = str(a.out.resolve() / 'empty')
            try:
                media.setup(manifest=a.manifest)
            except media.common.SetupError as e:
                if 'not cached' not in str(e):
                    raise
            else:
                raise ValueError('Empty offline cache accepted')
        os.environ['CPSPLUS_SWITCH_TOOLS_CACHE'] = env['CPSPLUS_SWITCH_TOOLS_CACHE']
        with tools['ffprobe'].open('ab') as f:
            f.write(b'tamper-test')
        try:
            media.setup(manifest=a.manifest)
        except media.common.SetupError as e:
            if 'cache changed' not in str(e):
                raise
        else:
            raise ValueError('Changed ffprobe accepted')
    result = dict(schema=1, status='passed', host=host, system=platform.platform(), archive_sha256=record['sha256'], manifest_sha256=sha(a.manifest), url=record['url'], cold_https=True, both_tools_executed=True, offline_cache_without_network=True, empty_offline_cache_rejected=True, changed_cache_rejected=True, recipe_sha256=sha(Path(__file__)))
    a.record.parent.mkdir(parents=True, exist_ok=True)
    a.record.write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
    print('PASS live HTTPS media fetch, offline reuse and cache rejection:', host, flush=True)
if __name__ == '__main__':
    main()
