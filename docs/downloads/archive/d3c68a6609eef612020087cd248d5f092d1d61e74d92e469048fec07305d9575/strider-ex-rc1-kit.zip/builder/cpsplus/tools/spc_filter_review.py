"""Decision D5: raw snes_spc output, or blargg's SPC_Filter?  A listening page."""
from __future__ import annotations
import argparse
import html
import json
import sys
import wave
from pathlib import Path
import numpy as np
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
sys.path.insert(0, str(HERE))
from pack import album_audio, spc_engine
import pin_spc_sets
import spc_loops
CLIP_S, INTO_LOOP_S = (20, 5)

def _env(x: np.ndarray, block: int) -> np.ndarray:
    m = x.astype(np.float64).mean(1)
    n = len(m) // block
    return np.sqrt((m[:n * block].reshape(n, block) ** 2).mean(1))

def _align(album: np.ndarray, arate: int, spc: np.ndarray) -> float:
    """Seconds to add to an SPC time to find the same moment in the album"""
    a = np.log1p(_env(album, arate // 100))
    s = np.log1p(_env(spc, spc_engine.RATE // 100))
    a, s = (a - a.mean(), s - s.mean())
    n = min(len(s), len(a) - 1500, 6000)
    c = [float(np.dot(a[k:k + n], s[:n])) for k in range(0, 1500)]
    return float(np.argmax(c)) / 100.0

def _bands(x: np.ndarray, rate: int) -> np.ndarray:
    m = x.astype(np.float64).mean(1)
    spec = np.zeros(8192 // 2 + 1)
    for i in range(0, len(m) - 8192, 4096):
        spec += np.abs(np.fft.rfft(m[i:i + 8192] * np.hanning(8192))) ** 2
    f = np.fft.rfftfreq(8192, 1 / rate)
    centres = 50 * 2 ** (np.arange(24) / 3)
    out = []
    for c in centres:
        sel = (f >= c / 2 ** (1 / 6)) & (f < c * 2 ** (1 / 6))
        out.append(10 * np.log10(spec[sel].mean() + 1e-12))
    out = np.array(out)
    return out - out.mean()

def _norm(x: np.ndarray) -> np.ndarray:
    x = x.astype(np.float64)
    rms = np.sqrt((x ** 2).mean()) or 1.0
    y = x * (10 ** (-20 / 20) * 32767 / rms)
    return np.clip(np.round(y), -32768, 32767).astype('<i2')

def _write(path: Path, pcm: np.ndarray, rate: int) -> str:
    with wave.open(str(path), 'wb') as w:
        w.setnchannels(2)
        w.setsampwidth(2)
        w.setframerate(rate)
        w.writeframes(pcm.tobytes())
    return path.name

def main(argv: list[str] | None=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--album', type=Path, required=True)
    ap.add_argument('--work', type=Path, required=True)
    a = ap.parse_args(argv)
    sources = {x['project']: x for x in json.loads(pin_spc_sets.MANIFEST.read_text())['sets']}
    rsn = pin_spc_sets.spc_dir(None) / 'a88.rsn'
    problems = pin_spc_sets.verify('a88', rsn, sources['a88'])
    if problems:
        raise SystemExit('\n'.join(problems))
    work = a.work / 'review_filter'
    extract = a.work / 'extract_a88'
    spc_engine.extract(rsn, extract)
    work.mkdir(parents=True, exist_ok=True)
    titles = {m['name']: m.get('title', '') for m in sources['a88']['members']}
    rows, summary = ([], [])
    for name, track in sorted(spc_loops.ALBUM_JOIN.items()):
        spc = extract / name
        album_file = next((p for p in a.album.iterdir() if p.name.startswith(f'{track}.')))
        album, arate, bits = album_audio.decode_native(album_file)
        album = (album >> bits).astype(np.int32)
        loop = spc_loops.run(spc, 300)
        frames = int((loop['t0_s'] + INTO_LOOP_S + CLIP_S + 60) * spc_engine.RATE)
        raw = spc_engine.render(spc, frames)
        flt = spc_engine.render(spc, frames, filter=True)
        offset = _align(album, arate, raw)
        t = loop['t0_s'] + INTO_LOOP_S
        s0, s1 = (int(t * spc_engine.RATE), int((t + CLIP_S) * spc_engine.RATE))
        a0 = int((t + offset) * arate)
        a1 = a0 + CLIP_S * arate
        if a1 > len(album):
            a0, a1 = (max(0, len(album) - CLIP_S * arate), len(album))
        ref = album[a0:a1]
        bh, br, bf = (_bands(ref, arate), _bands(raw[s0:s1], spc_engine.RATE), _bands(flt[s0:s1], spc_engine.RATE))
        d_raw, d_flt = (float(np.abs(br - bh).mean()), float(np.abs(bf - bh).mean()))
        stem = name[:-4]
        rows.append({'name': name, 'title': titles[name], 'track': track, 'H': _write(work / f'{stem}_H.wav', _norm(ref), arate), 'R': _write(work / f'{stem}_R.wav', _norm(raw[s0:s1]), spc_engine.RATE), 'F': _write(work / f'{stem}_F.wav', _norm(flt[s0:s1]), spc_engine.RATE)})
        summary.append({'song': name, 'album_track': track, 'offset_s': round(offset, 2), 'raw_vs_album_db': round(d_raw, 2), 'filter_vs_album_db': round(d_flt, 2)})
        print(json.dumps(summary[-1]), flush=True)
    mean = lambda k: round(float(np.mean([x[k] for x in summary])), 2)
    print(json.dumps({'mean_raw_vs_album_db': mean('raw_vs_album_db'), 'mean_filter_vs_album_db': mean('filter_vs_album_db')}))
    (work / 'index.html').write_text(_page(rows, summary))
    print(f"page: {work / 'index.html'}")
    return 0

def _page(rows: list[dict], summary: list[dict]) -> str:
    body = []
    for r, s in zip(rows, summary):
        body.append(f'''<section data-song="{html.escape(r['name'])}">\n<h2>{html.escape(r['title'])} <small>({html.escape(r['name'])} &middot; album tr{r['track']})</small></h2>\n<div class="row"><span>H hardware (album)</span><audio controls preload="none" src="{r['H']}"></audio></div>\n<div class="row"><span>R render, raw</span><audio controls preload="none" src="{r['R']}"></audio></div>\n<div class="row"><span>F render, filtered</span><audio controls preload="none" src="{r['F']}"></audio></div>\n<p class="num">spectral distance to H: raw {s['raw_vs_album_db']} dB, filtered {s['filter_vs_album_db']} dB</p>\n<fieldset><legend>Closer to the hardware</legend>\n<label><input type="radio" name="{r['name']}" value="raw"> R raw</label>\n<label><input type="radio" name="{r['name']}" value="filter"> F filtered</label>\n<label><input type="radio" name="{r['name']}" value="same"> can't tell</label>\n<input type="text" name="{r['name']}-note" placeholder="note"></fieldset>\n</section>''')
    return '<!doctype html><html lang="en"><head><meta charset="utf-8">\n<meta name="viewport" content="width=device-width,initial-scale=1"><title>SPC output filter</title>\n<style>\n:root{--bg:#fff;--fg:#1b1b1b;--muted:#666;--line:#ddd}\n@media (prefers-color-scheme:dark){:root{--bg:#161616;--fg:#eee;--muted:#aaa;--line:#333}}\nbody{background:var(--bg);color:var(--fg);font:15px/1.45 system-ui,sans-serif;max-width:860px;margin:0 auto;padding:16px}\nsection{border-top:1px solid var(--line);padding:12px 0}\n.row{display:flex;gap:12px;align-items:center;flex-wrap:wrap}.row span{min-width:170px}\n.num,small{color:var(--muted)}fieldset{border:1px solid var(--line);margin-top:8px}\naudio{max-width:100%}\n</style></head><body>\n<h1>SPC output: raw or filtered? (D5)</h1>\n<p>Each song: the CMG album\'s recording of the real SFC (H), then the accurate\nemulator raw (R) and through blargg\'s output filter (F). Same passage, same\nloudness. Pick the render that sounds more like the hardware.</p>\n<p><button id="export">Export decisions</button> <span id="count"></span></p>\n' + '\n'.join(body) + "\n<script>\nconst KEY='spc-filter-review';\nfunction load(){try{return JSON.parse(localStorage.getItem(KEY)||'{}')}catch(e){return{}}}\nfunction save(d){try{localStorage.setItem(KEY,JSON.stringify(d))}catch(e){}}\nconst d=load();\ndocument.querySelectorAll('input').forEach(i=>{\n  if(i.type==='radio'&&d[i.name]===i.value)i.checked=true;\n  if(i.type==='text'&&d[i.name])i.value=d[i.name];\n  i.addEventListener('change',()=>{const x=load();x[i.name]=i.value;save(x);count()});\n});\nfunction count(){const x=load();const n=[...document.querySelectorAll('section')].filter(s=>x[s.dataset.song]).length;\n document.getElementById('count').textContent=n+' of '+document.querySelectorAll('section').length+' decided'}\ncount();\ndocument.getElementById('export').onclick=()=>{const b=new Blob([JSON.stringify(load(),null,1)],{type:'application/json'});\n const a=document.createElement('a');a.href=URL.createObjectURL(b);a.download='spc_filter_decisions.json';a.click()};\n</script></body></html>"
if __name__ == '__main__':
    raise SystemExit(main())
