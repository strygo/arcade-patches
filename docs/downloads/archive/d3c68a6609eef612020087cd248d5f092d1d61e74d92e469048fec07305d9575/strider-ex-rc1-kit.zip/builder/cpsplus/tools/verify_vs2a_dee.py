"""Focused native/pack handoff and production trigger checks for Dee music."""
from __future__ import annotations
import argparse
import csv
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import xml.etree.ElementTree as ET
REPO = Path(__file__).resolve().parents[2]
CP = REPO / 'cpsplus'
sys.path[:0] = [str(CP), str(CP / 'scripts'), str(CP / 'rtl/tb'), str(REPO / 'backports/vamparrange/scripts')]
from pack.build_vs2a_dee import RECIPE, require, verify_mapping
from pack.format import PackReader
from run_cpsplus_proto import export_tables_lua
import gen_trigger_vectors as vectors
from run_vs2a_plus_gate import snapshot
from run_vs2a_nightmare_gate import candidate_identity, seed_eeprom
from run_vs2a_boss_gate import FLOW, SETUP

def sha(path):
    with Path(path).open('rb') as handle:
        return hashlib.file_digest(handle, 'sha256').hexdigest()

def read_tsv(path):
    with path.open() as handle:
        return list(csv.DictReader(handle, delimiter='\t'))

def trigger_gate(pack, work):
    tables = vectors.Tables.from_pack(pack)
    run = vectors.Run(tables)
    for frame, command, argw, argb in ((1, 21, 0, 0), (2, 65280, 0, 0), (3, 127, 0, 0), (4, 1943, 0, 0), (5, 1271, 0, 0), (6, 65287, 65535, 0), (7, 65286, 512, 255), (8, 44, 0, 0), (9, 126, 0, 0), (10, 125, 0, 0), (11, 65285, 0, 0), (12, 57, 0, 0), (13, 65280, 0, 0)):
        run.record(frame, command, argw=argw, argb=argb)
    paths = run.dump(work / 'vectors', 'dee')
    binary = work / 'trigger.vvp'
    subprocess.run(['iverilog', '-g2005', '-s', 'tb_trigger', '-o', str(binary), str(CP / 'rtl/tb/tb_trigger.v'), str(CP / 'rtl/cpsplus_trigger.v')], check=True, capture_output=True)
    result = subprocess.run(['vvp', str(binary), '+NAME=dee'] + ['+' + k.upper() + '=' + str(p) for k, p in paths.items()], capture_output=True, text=True, timeout=30)
    (work / 'trigger.log').write_text(result.stdout + result.stderr)
    require(result.returncode == 0 and 'PASS dee:' in result.stdout, 'production trigger replay failed')
    return {'status': 'pass', 'rtl_sha256': sha(CP / 'rtl/cpsplus_trigger.v'), 'records': 13, 'log_sha256': sha(work / 'trigger.log')}

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('pack', 'candidate', 'runtime', 'work', 'base-mra'):
        parser.add_argument('--' + name, type=Path, required=True)
    args = parser.parse_args()
    require(not args.work.exists(), 'use an empty new --work directory')
    args.work.mkdir(parents=True)
    binary = args.runtime / 'source/hbmamecps2arrange'
    inputs = [Path(__file__), RECIPE, CP / 'pack/build_vs2a_dee.py', CP / 'pack/format.py', CP / 'lua/vs2a_dee_music_gate.lua', CP / 'lua/cpsplus_prototype.lua', CP / 'scripts/run_cpsplus_proto.py', CP / 'rtl/cpsplus_trigger.v', CP / 'rtl/tb/gen_trigger_vectors.py', CP / 'rtl/tb/tb_trigger.v', REPO / 'translations/vhunt2/lua/vh2_surface_trace.lua', REPO / 'translations/vhunt2/scripts/run_surface_trace.py', REPO / 'backports/vamparrange/scripts/run_vs2a_boss_gate.py', REPO / 'backports/vamparrange/scripts/run_vs2a_nightmare_gate.py', REPO / 'backports/vamparrange/scripts/run_vs2a_plus_gate.py']
    source = {str(p.relative_to(REPO)): sha(p) for p in inputs}
    native = candidate_identity(args.candidate)
    runtime = snapshot(args.runtime, binary)
    pack_sha, mra_sha = (sha(args.pack), sha(args.base_mra))
    recipe = json.loads(RECIPE.read_text())
    reader = PackReader(args.pack)
    try:
        verify_mapping(reader, recipe)
    finally:
        reader.close()
    trigger = trigger_gate(args.pack, args.work)
    table = args.work / 'tables.lua'
    export_tables_lua(args.pack, table, 'vsav2pj')
    root = ET.parse(args.base_mra).getroot()
    eeprom = bytes.fromhex(root.findtext("rom[@index='2']/part"))
    nvram = seed_eeprom(args.work / 'nvram', 'vsav2pj', eeprom, 8)
    for sub in ('cfg', 'snap', 'diff'):
        (args.work / sub).mkdir()
    command = [sys.executable, str(REPO / 'translations/vhunt2/scripts/run_surface_trace.py'), '--machine', 'vsav2pj', '--mame', str(binary.resolve()), '--rompath', str(args.candidate.resolve()), '--rompath-first', '--no-input-check', '--outdir', str((args.work / 'route').resolve()), '--schedule', FLOW, '--post-pokes', SETUP, '--captures', '', '--script', str(CP / 'lua/vs2a_dee_music_gate.lua')]
    options = ['-video', 'none', '-sound', 'none', '-nothrottle', '-seconds_to_run', '370']
    for option, path in (('cfg_directory', args.work / 'cfg'), ('nvram_directory', nvram), ('snapshot_directory', args.work / 'snap'), ('diff_directory', args.work / 'diff')):
        options += ['-' + option, str(path.resolve())]
    command += ['--mame-arg=' + v for v in options]
    env = dict(os.environ, SDL_VIDEODRIVER='dummy', SDL_AUDIODRIVER='dummy', VS2A_MUSIC_BASE=str(REPO / 'translations/vhunt2/lua/vh2_surface_trace.lua'), VS2A_MUSIC_PROTOTYPE=str(CP / 'lua/cpsplus_prototype.lua'), MSU_TABLES=str(table.resolve()), MSU_PREFIX=str((args.work / 'music').resolve()), MSU_FRAMES='22000', MSU_GATE='1')
    print('Running one muted real boss route with CPS+ gating', flush=True)
    result = subprocess.run(command, env=env, capture_output=True, text=True, timeout=300)
    (args.work / 'runtime.log').write_text(result.stdout + result.stderr)
    require(result.returncode == 0 and '[LUA ERROR]' not in result.stdout + result.stderr, 'boss music route failed; inspect runtime.log')
    events = [r for r in read_tsv(args.work / 'music_events.tsv') if r['kind'] == 'rec']
    starts = [r for r in events if int(r['cmd'], 16) == 127]
    require(starts and all((r['sup'] == '1' and r['verb'] == 'play' for r in starts)), 'actual boss command not gated')
    states = read_tsv(args.work / 'music_native_bgm.tsv')
    boss = [r for r in states if r['active'] == '1' and r['route'] == '1']
    require(len(boss) > 60, 'no sustained real boss music witness')
    leaks = [r for r in boss if int(r['bgm_channels'])]
    require(source == {str(p.relative_to(REPO)): sha(p) for p in inputs} and native == candidate_identity(args.candidate) and (runtime == snapshot(args.runtime, binary)) and (pack_sha == sha(args.pack)) and (mra_sha == sha(args.base_mra)), 'inputs changed across gate')
    receipt = {'schema_version': 1, 'status': 'fail' if leaks else 'pass', 'source': source, 'candidate': native, 'runtime': runtime, 'pack_sha256': pack_sha, 'base_mra_sha256': mra_sha, 'trigger': trigger, 'boss_music_frame': int(starts[0]['frame']), 'boss_frames': len(boss), 'native_bgm_leak_frames': len(leaks), 'first_leak': leaks[0] if leaks else None, 'hardware_review': False, 'scope': 'command gating and native BGM handoff; no FPGA audio listening'}
    (args.work / 'receipt.json').write_text(json.dumps(receipt, indent=2, sort_keys=True) + '\n')
    require(not leaks, 'native BGM remains audible underneath gated Dee music')
    print('PASS real boss handoff and production trigger; hardware listening pending')
if __name__ == '__main__':
    main()
