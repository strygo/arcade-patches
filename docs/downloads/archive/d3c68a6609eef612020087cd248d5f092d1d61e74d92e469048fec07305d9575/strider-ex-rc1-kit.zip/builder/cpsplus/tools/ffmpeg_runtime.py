"""Shared FFmpeg/ffprobe resolution for exported CPS+ and game kits."""
import argparse
import os
from pathlib import Path
import shutil
_managed = {}

def add_arguments(parser):
    parser.add_argument('--tools-cache', type=Path, help='verified media/helper cache')
    parser.add_argument('--tools-bundle', type=Path, help='offline tools ZIP or directory')
    parser.add_argument('--offline', action='store_true', help='never download tools')

def configure(argv):
    parser = argparse.ArgumentParser(add_help=False)
    add_arguments(parser)
    args, rest = parser.parse_known_args(argv)
    for option, key in (('tools_cache', 'CPSPLUS_SWITCH_TOOLS_CACHE'), ('tools_bundle', 'CPSPLUS_SWITCH_TOOLS_BUNDLE')):
        value = getattr(args, option)
        if value is not None:
            os.environ[key] = str(value.expanduser().resolve())
    if args.offline:
        os.environ['CPSPLUS_SWITCH_TOOLS_OFFLINE'] = '1'
    return rest

def resolve(tool='ffmpeg'):
    if tool not in ('ffmpeg', 'ffprobe'):
        raise ValueError('Unknown media executable: ' + tool)
    key = 'CPSPLUS_' + tool.upper()
    override = os.environ.get(key)
    if override and override != _managed.get(tool):
        found = shutil.which(override)
        if not found:
            raise ValueError(key + ' does not name an executable: ' + override)
        return found
    if not _managed:
        import fetch_ffmpeg
        try:
            tools = fetch_ffmpeg.setup()
        except fetch_ffmpeg.common.SetupError as exc:
            raise ValueError(str(exc)) from exc
        for name, path in tools.items():
            _managed[name] = str(path)
            os.environ.setdefault('CPSPLUS_' + name.upper(), str(path))
        os.environ['PATH'] = str(tools['ffmpeg'].parent) + os.pathsep + os.environ.get('PATH', '')
    return _managed[tool]

class Executable(os.PathLike):
    """Delay tool preparation until a command actually needs the executable."""

    def __init__(self, tool):
        self.tool = tool

    def __fspath__(self):
        return resolve(self.tool)

    def __str__(self):
        return self.__fspath__()
