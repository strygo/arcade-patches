"""Pin, and verify, the snesmusic.org SPC sets the `_spc` packs build from."""
from __future__ import annotations
import argparse
import hashlib
import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from pack import spc_engine
REPO = Path(__file__).resolve().parents[2]
MANIFEST = REPO / 'cpsplus' / 'manifests' / 'spc_sources.json'
DEFAULT_DIR = REPO / 'roms' / 'soundtracks' / 'spc'
SCRATCH = REPO / 'cpsplus' / 'work' / 'spc' / 'extract'
IA_ITEM = 'SNESmusic-03-21-2016'
IA_URL = f'https://archive.org/download/{IA_ITEM}'
PAGE = 'https://www.snesmusic.org/v2/profile.php?profile=set&selected={}'
SETS = {'ffi': {'game': 'ffight', 'title': 'Final Fight', 'page': 885, 'version': '1.04', 'date': '2011-08-04', 'ia_md5': '6df4d0aba84537b15aaa00327a4d8134'}, 'a88': {'game': 'unsquad', 'title': 'U.N. Squadron', 'page': 3115, 'version': '1.03', 'date': '2013-03-14', 'ia_md5': 'aef7b6b1c7a3810d4285e06629ec33d7'}, 'sfa2': {'game': 'sfa2', 'title': 'Street Fighter Alpha 2', 'page': 2534, 'version': '1.00', 'date': '2004-09-19', 'ia_md5': 'b8efc4a8568d6b92dbdd07587b35d0fb'}, 'sf2': {'game': 'sf2', 'title': 'Street Fighter II', 'page': 2537, 'version': '1.01', 'date': '2004-05-09', 'ia_md5': 'f07264ad7b4f6cc36b00285515c71c19'}, 'sf2t': {'game': 'sf2', 'title': 'Street Fighter II Turbo', 'page': 2540, 'version': '1.00', 'date': '2007-03-10', 'ia_md5': '8f85bccf296315d84a4a7b243a180831'}, 'ssf2': {'game': 'ssf2', 'title': 'Super Street Fighter II', 'page': 2860, 'version': '1.04', 'date': '2007-12-11', 'ia_md5': 'e6f11aeb18d855376c809254fd82b2cf'}, 'snsm': {'game': 'slammast', 'title': 'Saturday Night Slam Masters', 'page': 2253, 'version': '1.01', 'date': '2010-01-21', 'ia_md5': '4c9ec2d4d7524908a8246d3104bb59f1'}, 'mcsd': {'game': 'msword', 'title': 'Magic Sword', 'page': 1570, 'version': '1.02', 'date': '2006-05-02', 'ia_md5': '303248346df5ed22b41100fc113cade2'}, 'captc': {'game': 'captcomm', 'title': 'Captain Commando', 'page': 504, 'version': '1.02', 'date': '2012-02-05', 'ia_md5': 'cf9473988964c2bae351f3b11b8eef5e'}, 'kotr': {'game': 'knights', 'title': 'Knights of the Round', 'page': 1433, 'version': '1.01', 'date': '2004-05-04', 'ia_md5': '2a2d4d0c7c5f4bbd2b8bba6f9dda5fe6'}, 'kod': {'game': 'kod', 'title': 'The King of Dragons', 'page': 1409, 'version': '1.01', 'date': '2004-05-04', 'ia_md5': '28e5f9079eff6cbcbee2a8bb1bd544b6'}}

def spc_dir(arg: Path | None) -> Path:
    if arg:
        return arg
    env = os.environ.get('CAPCOM_SPC_PATH')
    return Path(env) if env else DEFAULT_DIR

def _classify(name: str, project: str) -> str:
    """snesmusic naming: <project>-NN is music; a letter after the dash marks"""
    tail = name[len(project) + 1:-4].lower()
    if project == 'ssf2' and name.startswith('ssf2u-'):
        tail = name[6:-4].lower()
    if tail[:1].isdigit():
        return 'music'
    return {'s': 'sfx', 'v': 'voice', 'e': 'sfx', 'b': 'bonus'}.get(tail[:1], 'other')

def pin_archive(project: str, rsn: Path) -> dict:
    data = rsn.read_bytes()
    members = spc_engine.extract(rsn, SCRATCH / project)
    rows = []
    for name, blob in sorted(members.items()):
        row = {'name': name, 'bytes': len(blob), 'sha256': spc_engine.sha256(blob)}
        if name.lower().endswith('.spc'):
            tags = spc_engine.read_tags(blob)
            row.update(ram_sha256=spc_engine.ram_sha256(blob), kind=_classify(name, project), title=tags.get('title', ''), game=tags.get('game', ''), seconds=tags.get('seconds'), fade_ms=tags.get('fade_ms'))
        rows.append(row)
    meta = SETS[project]
    return {'project': project, 'game': meta['game'], 'title': meta['title'], 'snesmusic': {'page': PAGE.format(meta['page']), 'version': meta['version'], 'date': meta['date']}, 'internet_archive': {'item': IA_ITEM, 'url': f'{IA_URL}/{project}.rsn', 'md5': meta['ia_md5']}, 'archive': {'name': f'{project}.rsn', 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(), 'md5': hashlib.md5(data).hexdigest()}, 'members': rows}

def verify(project: str, rsn: Path, pinned: dict) -> list[str]:
    """Differences between the archive on disk and its pin (empty = pass)."""
    got = {m['name']: m for m in pin_archive(project, rsn)['members']}
    want = {m['name']: m for m in pinned['members']}
    problems = []
    for name in sorted(set(want) | set(got)):
        if name not in got:
            problems.append(f'{project}: {name} missing')
        elif name not in want:
            problems.append(f'{project}: {name} not pinned')
        elif got[name]['sha256'] != want[name]['sha256']:
            same_ram = got[name].get('ram_sha256') == want[name].get('ram_sha256')
            problems.append(f'{project}: {name} differs' + (' (tags only: same RAM image)' if same_ram else ''))
    return problems

def fetch_ia(directory: Path) -> None:
    directory.mkdir(parents=True, exist_ok=True)
    for project, meta in SETS.items():
        dest = directory / f'{project}.rsn'
        if dest.exists():
            continue
        fd, tmp = tempfile.mkstemp(dir=directory, suffix='.part')
        os.close(fd)
        try:
            subprocess.run(['curl', '-sSfL', '--retry', '3', '-o', tmp, f'{IA_URL}/{project}.rsn'], check=True)
            md5 = hashlib.md5(Path(tmp).read_bytes()).hexdigest()
            if md5 != meta['ia_md5']:
                raise RuntimeError(f"{project}.rsn: md5 {md5}, item records {meta['ia_md5']}")
            os.replace(tmp, dest)
            print(f'fetched {dest.name}')
        finally:
            if os.path.exists(tmp):
                os.unlink(tmp)

def self_test() -> None:
    assert len(SETS) == 11
    assert all((len(m['ia_md5']) == 32 for m in SETS.values()))
    assert _classify('ffi-05.spc', 'ffi') == 'music'
    assert _classify('ffi-s03.spc', 'ffi') == 'sfx'
    assert _classify('ffi-b01.spc', 'ffi') == 'bonus'
    assert _classify('sf2t-v01.spc', 'sf2t') == 'voice'
    assert _classify('ssf2u-12.spc', 'ssf2') == 'music'
    assert _classify('sfa2-124a.spc', 'sfa2') == 'music'
    print('pin_spc_sets self-test: OK')

def main(argv: list[str] | None=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--spc-dir', type=Path)
    ap.add_argument('--write', action='store_true')
    ap.add_argument('--fetch-ia', action='store_true')
    ap.add_argument('--self-test', action='store_true')
    a = ap.parse_args(argv)
    if a.self_test:
        self_test()
        return 0
    directory = spc_dir(a.spc_dir)
    if a.fetch_ia:
        fetch_ia(directory)
        return 0
    if a.write:
        sets = [pin_archive(p, directory / f'{p}.rsn') for p in SETS]
        doc = {'schema': 1, 'format': 'spc', 'site': 'snesmusic.org', 'note': 'Members are the pin; see tools/pin_spc_sets.py.', 'sets': sets}
        MANIFEST.write_text(json.dumps(doc, indent=1, ensure_ascii=False) + '\n')
        print(f"wrote {MANIFEST.relative_to(REPO)}: {sum((len(s['members']) for s in sets))} members in {len(sets)} sets")
        return 0
    pinned = {s['project']: s for s in json.loads(MANIFEST.read_text())['sets']}
    problems = []
    for project in SETS:
        rsn = directory / f'{project}.rsn'
        if not rsn.exists():
            problems.append(f'{project}: {rsn} not found')
            continue
        problems += verify(project, rsn, pinned[project])
    for line in problems:
        print(line)
    print('spc sources:', 'OK' if not problems else f'{len(problems)} problem(s)')
    return 1 if problems else 0
if __name__ == '__main__':
    raise SystemExit(main())
