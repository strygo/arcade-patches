"""Minimal PS3 retail PKG lister/extractor (research tool, untracked work/)."""
import struct
import sys
from pathlib import Path
from Cryptodome.Cipher import AES
PS3_PKG_KEY = bytes.fromhex('2E7B71D7C9C9A14EA3221F188828B8F8')

class Pkg:

    def __init__(self, path):
        self.path = Path(path)
        self.f = open(self.path, 'rb')
        hdr = self.f.read(256)
        if hdr[:4] != b'\x7fPKG':
            raise SystemExit('not a PKG')
        self.revision, self.type = struct.unpack('>HH', hdr[4:8])
        self.meta_off, self.meta_cnt, self.meta_size, self.item_count = struct.unpack('>IIII', hdr[8:24])
        self.total_size, self.data_off, self.data_size = struct.unpack('>QQQ', hdr[24:48])
        self.content_id = hdr[48:84].split(b'\x00')[0].decode()
        self.riv = hdr[112:128]
        if self.type != 1:
            raise SystemExit(f'pkg type {self.type} is not PS3')
        if self.revision != 32768:
            raise SystemExit(f'revision {self.revision:#06x}: not a retail PS3 pkg (key unknown)')
        self.riv_int = int.from_bytes(self.riv, 'big')

    def dec(self, off, size):
        """Decrypt `size` bytes at data-relative offset `off`."""
        blk = off // 16
        pre = off - blk * 16
        self.f.seek(self.data_off + blk * 16)
        raw = self.f.read(pre + size)
        c = AES.new(PS3_PKG_KEY, AES.MODE_CTR, nonce=b'', initial_value=self.riv_int + blk & (1 << 128) - 1)
        return c.decrypt(raw)[pre:pre + size]

    def items(self):
        table = self.dec(0, self.item_count * 32)
        out = []
        for i in range(self.item_count):
            name_off, name_len, doff, dsize, flags, _pad = struct.unpack('>IIQQII', table[i * 32:(i + 1) * 32])
            name = self.dec(name_off, name_len).split(b'\x00')[0].decode(errors='replace')
            out.append((name, doff, dsize, flags))
        return out

    def extract(self, outdir, only=None):
        outdir = Path(outdir)
        for name, doff, dsize, flags in self.items():
            kind = flags & 255
            if kind == 4:
                (outdir / name).mkdir(parents=True, exist_ok=True)
                continue
            if only and (not any((s in name for s in only))):
                continue
            dst = outdir / name
            dst.parent.mkdir(parents=True, exist_ok=True)
            with open(dst, 'wb') as w:
                pos = 0
                while pos < dsize:
                    n = min(1 << 24, dsize - pos)
                    w.write(self.dec(doff + pos, n))
                    pos += n
            print(f'wrote {dst} ({dsize} bytes, flags {flags:#010x})')

def main():
    if len(sys.argv) < 3 or sys.argv[1] not in ('list', 'extract'):
        raise SystemExit('usage: pkg_ps3.py list <pkg> | extract <pkg> <outdir> [substr ...]')
    p = Pkg(sys.argv[2])
    print(f'{p.content_id}: rev {p.revision:#06x} type {p.type} items {p.item_count} data_off {p.data_off:#x} data_size {p.data_size:#x}')
    if sys.argv[1] == 'list':
        for name, doff, dsize, flags in p.items():
            kind = {1: 'NPDRM', 3: 'raw', 4: 'dir'}.get(flags & 255, f'type{flags & 255:#x}')
            print(f'{flags:#010x} {kind:6} {dsize:12d}  {name}')
    else:
        p.extract(sys.argv[3], sys.argv[4:] or None)
if __name__ == '__main__':
    main()
