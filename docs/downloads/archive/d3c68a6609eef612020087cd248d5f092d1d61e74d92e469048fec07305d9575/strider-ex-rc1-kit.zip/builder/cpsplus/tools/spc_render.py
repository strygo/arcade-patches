"""Render SPC (SNES SPC700 snapshot) files to WAV via libgme (game-music-emu)."""
from __future__ import annotations
import argparse, ctypes, sys, wave
from pathlib import Path
RATE = 44100
LIB = '/opt/homebrew/lib/libgme.dylib'

def render(spc: Path, out: Path, seconds: int) -> None:
    gme = ctypes.CDLL(LIB)
    gme.gme_open_file.restype = ctypes.c_char_p
    gme.gme_open_file.argtypes = [ctypes.c_char_p, ctypes.POINTER(ctypes.c_void_p), ctypes.c_int]
    emu = ctypes.c_void_p()
    err = gme.gme_open_file(str(spc).encode(), ctypes.byref(emu), RATE)
    if err:
        raise RuntimeError(f'{spc.name}: {err.decode()}')
    gme.gme_start_track.restype = ctypes.c_char_p
    err = gme.gme_start_track(emu, 0)
    if err:
        raise RuntimeError(f'{spc.name}: {err.decode()}')
    gme.gme_play.restype = ctypes.c_char_p
    n = seconds * RATE * 2
    buf = (ctypes.c_short * n)()
    err = gme.gme_play(emu, n, buf)
    if err:
        raise RuntimeError(f'{spc.name}: {err.decode()}')
    gme.gme_delete(emu)
    w = wave.open(str(out), 'w')
    w.setnchannels(2)
    w.setsampwidth(2)
    w.setframerate(RATE)
    w.writeframes(bytes(buf))
    w.close()

def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('files', nargs='+')
    ap.add_argument('--out-dir', required=True)
    ap.add_argument('--seconds', type=int, default=300)
    a = ap.parse_args(argv)
    od = Path(a.out_dir)
    od.mkdir(parents=True, exist_ok=True)
    for f in a.files:
        p = Path(f)
        out = od / (p.stem + '.wav')
        render(p, out, a.seconds)
        print(f'{p.name} -> {out.name} ({a.seconds}s)')
    return 0
if __name__ == '__main__':
    sys.exit(main())
