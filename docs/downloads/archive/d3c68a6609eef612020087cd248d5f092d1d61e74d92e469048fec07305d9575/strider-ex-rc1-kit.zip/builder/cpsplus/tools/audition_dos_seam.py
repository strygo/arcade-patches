"""Audition the loop seams of the DOS renders, exactly as the FPGA will play them."""
from __future__ import annotations
import argparse
import json
import subprocess
import sys
import wave
from pathlib import Path
REPO = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(REPO / 'cpsplus'))
from pack import xfade

class AuditionError(RuntimeError):
    pass

def probe(path: Path) -> tuple[int, dict[str, int]]:
    out = subprocess.run(['ffprobe', '-v', 'error', '-select_streams', 'a:0', '-show_entries', 'stream=sample_rate:format_tags', '-of', 'json', str(path)], capture_output=True, text=True, check=True).stdout
    info = json.loads(out)
    rate = int(info['streams'][0]['sample_rate'])
    tags = {k.upper(): int(v) for k, v in info.get('format', {}).get('tags', {}).items() if k.upper().startswith('LOOP') and v.lstrip('-').isdigit()}
    return (rate, tags)

def decode(path: Path) -> list[tuple[int, int]]:
    raw = subprocess.run(['ffmpeg', '-v', 'error', '-i', str(path), '-f', 's16le', '-acodec', 'pcm_s16le', '-ac', '2', '-'], capture_output=True, check=True).stdout
    import array
    flat = array.array('h')
    flat.frombytes(raw)
    return list(zip(flat[0::2], flat[1::2]))

def seam_clip(pcm: list[tuple[int, int]], rate: int, tags: dict[str, int], lead: float, tail: float, name: str) -> list[tuple[int, int]]:
    n = rate
    source_ls, source_le = (tags['LOOPSTART'], tags['LOOPEND'])
    pack_ls, pack_le = (source_ls - n, source_le - n)
    if pack_ls < 0:
        raise AuditionError(f'{name}: loop starts less than a crossfade in')
    if pack_le + n > len(pcm):
        raise AuditionError(f'{name}: stored audio ends at {len(pcm)}, needs {pack_le + n}')
    lead_n, tail_n = (int(lead * rate), int(tail * rate))
    out: list[tuple[int, int]] = []
    out += pcm[max(pack_le - lead_n, 0):pack_le]
    lut = xfade.make_lut(n)
    for k in range(n):
        tl, tr = pcm[pack_le + k]
        hl, hr = pcm[pack_ls + k]
        out.append(xfade.blend_pair(tl, tr, hl, hr, k, lut, n))
    resume = pack_ls + n
    out += pcm[resume:resume + tail_n]
    return out

def write_wav(pcm: list[tuple[int, int]], rate: int, dest: Path) -> None:
    import array
    flat = array.array('h')
    for left, right in pcm:
        flat.append(left)
        flat.append(right)
    with wave.open(str(dest), 'w') as handle:
        handle.setnchannels(2)
        handle.setsampwidth(2)
        handle.setframerate(rate)
        handle.writeframes(flat.tobytes())

def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('sources', nargs='+')
    ap.add_argument('--out-dir', required=True)
    ap.add_argument('--lead', type=float, default=8.0)
    ap.add_argument('--tail', type=float, default=8.0)
    ap.add_argument('--reel', help='also write all clips as one file')
    ap.add_argument('--gap', type=float, default=1.0, help='silence between clips in the reel')
    a = ap.parse_args(argv)
    out_dir = Path(a.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    reel: list[tuple[int, int]] = []
    reel_rate = None
    made = 0
    for raw in a.sources:
        path = Path(raw)
        rate, tags = probe(path)
        if 'LOOPSTART' not in tags:
            print(f'{path.stem:12s} -- one-shot, no seam')
            continue
        pcm = decode(path)
        clip = seam_clip(pcm, rate, tags, a.lead, a.tail, path.stem)
        write_wav(clip, rate, out_dir / f'{path.stem}_seam.wav')
        print(f'{path.stem:12s} seam clip {len(clip) / rate:5.1f}s (wrap at {a.lead:.0f}s)')
        made += 1
        if a.reel:
            if reel_rate is None:
                reel_rate = rate
            elif reel_rate != rate:
                raise AuditionError(f'reel needs one sample rate; {path.stem} is {rate}, reel is {reel_rate}')
            reel += clip + [(0, 0)] * int(a.gap * rate)
    if a.reel and reel:
        assert reel_rate is not None
        dest = out_dir / f'{a.reel}.wav'
        write_wav(reel, reel_rate, dest)
        print(f'\nreel: {dest} ({len(reel) / reel_rate:.1f}s, {made} seams)')
    return 0
if __name__ == '__main__':
    sys.exit(main())
