"""Hunter Dee pack mapping, production RTL and isolated native-Z80 handoffs."""
from __future__ import annotations
import argparse
import csv
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
REPO = Path(__file__).resolve().parents[2]
CP = REPO / 'cpsplus'
sys.path[:0] = [str(CP), str(CP / 'scripts'), str(CP / 'rtl/tb')]
from pack.build_vs2a_dee import require, validate_native_driver, verify_mapping
from pack.build_vh2a_dee import RECIPE
from pack.format import PackReader
from run_cpsplus_proto import export_tables_lua
import gen_trigger_vectors as vectors

def sha(path):
    with Path(path).open('rb') as handle:
        return hashlib.file_digest(handle, 'sha256').hexdigest()

def rows(path):
    with path.open() as handle:
        return list(csv.DictReader(handle, delimiter='\t'))

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--pack', type=Path, required=True)
    parser.add_argument('--work', type=Path, required=True)
    parser.add_argument('--rompath', type=Path, default=REPO / 'roms/mame0260')
    parser.add_argument('--mame', type=Path, default=Path(shutil.which('mame') or 'mame'))
    args = parser.parse_args()
    require(not args.work.exists(), 'use a new empty --work directory')
    args.work.mkdir(parents=True)
    recipe = json.loads(RECIPE.read_text())
    validate_native_driver(args.rompath, recipe)
    reader = PackReader(args.pack)
    try:
        verify_mapping(reader, recipe)
    finally:
        reader.close()
    inputs = [Path(__file__), RECIPE, CP / 'pack/build_vh2a_dee.py', CP / 'pack/build_vs2a_dee.py', CP / 'pack/format.py', CP / 'lua/vh2a_dee_music_gate.lua', CP / 'lua/cpsplus_prototype.lua', CP / 'scripts/run_cpsplus_proto.py', CP / 'rtl/cpsplus_trigger.v', CP / 'rtl/tb/gen_trigger_vectors.py', CP / 'rtl/tb/tb_trigger.v', REPO / 'translations/vhunt2/scripts/run_surface_trace.py', REPO / 'translations/vhunt2/lua/vh2_surface_trace.lua']
    source = {p.relative_to(REPO).as_posix(): sha(p) for p in inputs}
    pack_sha, mame_sha, rom_sha = (sha(args.pack), sha(args.mame), sha(args.rompath / 'vhunt2.zip'))
    tables = vectors.Tables.from_pack(args.pack)
    run = vectors.Run(tables)
    commands = [126, 1041, 1943, 2711, 127, 1925, 2693, 125, 65287, 65286, 65285, 65280] + [int(c, 0) for c in recipe['native_music_commands']]
    for frame, command in enumerate(commands, 1):
        run.record(frame, command, argw=512 if command == 65286 else 0, argb=255)
    paths = run.dump(args.work / 'vectors', 'hunter-dee')
    binary = args.work / 'trigger.vvp'
    subprocess.run(['iverilog', '-g2005', '-s', 'tb_trigger', '-o', str(binary), str(CP / 'rtl/tb/tb_trigger.v'), str(CP / 'rtl/cpsplus_trigger.v')], check=True, capture_output=True)
    result = subprocess.run(['vvp', str(binary), '+NAME=hunter-dee'] + ['+' + k.upper() + '=' + str(p) for k, p in paths.items()], capture_output=True, text=True, timeout=30)
    (args.work / 'trigger.log').write_text(result.stdout + result.stderr)
    require(result.returncode == 0 and 'PASS hunter-dee:' in result.stdout, 'Hunter trigger replay failed')
    table = args.work / 'tables.lua'
    export_tables_lua(args.pack, table, 'vhunt2')
    env = dict(os.environ, SDL_VIDEODRIVER='dummy', SDL_AUDIODRIVER='dummy', VH2A_MUSIC_BASE=str(REPO / 'translations/vhunt2/lua/vh2_surface_trace.lua'), VH2A_MUSIC_PROTOTYPE=str(CP / 'lua/cpsplus_prototype.lua'), MSU_TABLES=str(table.resolve()), MSU_PREFIX=str((args.work / 'music').resolve()), MSU_FRAMES='2100', MSU_GATE='1')
    for name in ('cfg', 'nvram', 'snap', 'diff'):
        (args.work / name).mkdir()
    command = [sys.executable, str(REPO / 'translations/vhunt2/scripts/run_surface_trace.py'), '--machine', 'vhunt2', '--mame', str(args.mame.resolve()), '--rompath', str(args.rompath.resolve()), '--rompath-first', '--no-input-check', '--outdir', str((args.work / 'runtime').resolve()), '--script', str(CP / 'lua/vh2a_dee_music_gate.lua'), '--captures', '']
    options = ['-video', 'none', '-sound', 'none', '-nothrottle', '-seconds_to_run', '40']
    for option, name in (('cfg_directory', 'cfg'), ('nvram_directory', 'nvram'), ('snapshot_directory', 'snap'), ('diff_directory', 'diff')):
        options += ['-' + option, str((args.work / name).resolve())]
    command += ['--mame-arg=' + option for option in options]
    print('Running one muted Hunter service-mailbox handoff diagnostic', flush=True)
    result = subprocess.run(command, env=env, capture_output=True, text=True, timeout=120)
    (args.work / 'runtime.log').write_text(result.stdout + result.stderr)
    require(result.returncode == 0 and '[LUA ERROR]' not in result.stdout + result.stderr, 'Hunter diagnostic failed')
    events = [r for r in rows(args.work / 'music_events.tsv') if r['kind'] == 'rec' and int(r['frame']) >= 1500]
    expected = {1500: (65280, 'ctrl_stop', 0), 1530: (25, 'stop', 0), 1590: (65285, 'ctrl_stop', 0), 1620: (126, 'play', 1), 1660: (1041, 'sfx', 0), 1710: (89, 'stop', 0), 1770: (65285, 'ctrl_stop', 0), 1810: (127, 'play', 1), 1860: (65285, 'ctrl_stop', 0), 1900: (125, 'play', 1), 1950: (64, 'stop', 0), 2000: (65280, 'ctrl_stop', 0)}
    observed = {int(r['frame']): (int(r['cmd'], 16), r['verb'], int(r['sup'])) for r in events}
    require(len(events) == len(expected) and observed == expected, 'native/suppressed command witness differs')
    states = rows(args.work / 'music_native_bgm.tsv')
    checks = {}
    for label, first, last, playing in (('normal native donor', 1570, 1589, True), ('gated normal Dee', 1640, 1659, False), ('alternate native donor', 1750, 1769, True), ('gated alternate Dee', 1830, 1859, False), ('FF05 BGM release', 1880, 1899, False), ('gated credits', 1920, 1949, False), ('FF00 release', 2020, 2050, False)):
        window = [r for r in states if first <= int(r['frame']) <= last]
        require(len(window) == last - first + 1 and all((bool(int(r['bgm_channels'])) == playing for r in window)), 'native BGM pool failed: ' + label)
        checks[label] = {'frames': len(window), 'native_bgm_active': playing}
    validate_native_driver(args.rompath, recipe)
    require(source == {p.relative_to(REPO).as_posix(): sha(p) for p in inputs} and (pack_sha, mame_sha, rom_sha) == (sha(args.pack), sha(args.mame), sha(args.rompath / 'vhunt2.zip')), 'inputs changed across complete gate')
    receipt = {'schema_version': 1, 'status': 'pass', 'pack_sha256': pack_sha, 'source': source, 'mame_sha256': mame_sha, 'canonical_archive_sha256': rom_sha, 'rtl_sha256': sha(CP / 'rtl/cpsplus_trigger.v'), 'rtl_records': len(commands), 'rtl_log_sha256': sha(args.work / 'trigger.log'), 'native_handoffs': len(recipe['native_music_commands']), 'runtime_records': len(events), 'native_bgm_checks': checks, 'identities_rechecked_after_all_tests': True, 'hardware_review': False, 'arrange_gameplay_tested': False, 'scope': 'pack/RTL and isolated stock Hunter Z80 handoff'}
    (args.work / 'receipt.json').write_text(json.dumps(receipt, indent=2, sort_keys=True) + '\n')
    print('PASS Hunter mapping, all native song trigger rows and native Z80 handoffs; hardware pending')
if __name__ == '__main__':
    main()
