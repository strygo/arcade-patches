"""Give every pack a measured gain so they all sit at the ARCADE's own music level."""
from __future__ import annotations
import argparse
import subprocess
import sys
import tempfile
import wave
from pathlib import Path
import numpy as np
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from pack.format import PackReader, _parse_header
from pack import audition
from pack.set_gain import set_gain
TARGET_LUFS = -20.6
PROBE_S = 20.0

def track_lufs(rd, ti, tmp) -> float | None:
    pcm, m = audition.render(rd, ti, loops=0)
    x = np.frombuffer(pcm, dtype='<i2')
    if m.channels == 2:
        x = x.reshape(-1, 2).mean(axis=1)
    if len(x) < m.sample_rate:
        return None
    mid = max(0, len(x) // 2 - int(PROBE_S * m.sample_rate) // 2)
    x = x[mid:mid + int(PROBE_S * m.sample_rate)]
    f = f'{tmp}/t{ti}.wav'
    o = wave.open(f, 'w')
    o.setnchannels(1)
    o.setsampwidth(2)
    o.setframerate(m.sample_rate)
    o.writeframes(x.astype('<i2').tobytes())
    o.close()
    r = subprocess.run(['ffmpeg', '-hide_banner', '-nostats', '-i', f, '-filter_complex', 'ebur128', '-f', 'null', '-'], capture_output=True, text=True).stderr
    val = None
    for ln in r.splitlines():
        if 'I:' in ln and 'LUFS' in ln:
            try:
                val = float(ln.split('I:')[1].split('LUFS')[0])
            except ValueError:
                pass
    return val if val is not None and val > -60 else None

def measure_pack(pack: Path) -> dict:
    rd = PackReader(pack)
    d = pack.read_bytes()
    h = _parse_header(d)
    used = sorted({d[h.trigger_offset + 4 * i + 1] | d[h.trigger_offset + 4 * i + 3] >> 4 << 8 for i in range(h.trigger_rows) if d[h.trigger_offset + 4 * i] != 0})
    vals = []
    with tempfile.TemporaryDirectory() as tmp:
        for ti in used:
            v = track_lufs(rd, ti, tmp)
            if v is not None:
                vals.append(v)
    if not vals:
        return {'n': 0}
    med = float(np.median(vals))
    delta = med - TARGET_LUFS
    gain = round(127 * 10 ** (-delta / 20))
    return {'n': len(vals), 'median': med, 'delta': delta, 'gain': max(1, min(127, gain)), 'clamped': gain > 127}

def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('packs', nargs='+', type=Path)
    ap.add_argument('--apply', action='store_true')
    a = ap.parse_args(argv)
    print(f'  target {TARGET_LUFS:+.1f} LUFS (SF2 native arcade median)\n')
    print(f"  {'pack':<22} {'trk':>4} {'median':>8} {'delta':>7} {'gain':>6}")
    for p in sorted(a.packs):
        r = measure_pack(p)
        if not r['n']:
            print(f"  {p.stem:<22} {'--':>4}  no measurable tracks")
            continue
        note = '  (already at/below target)' if r['clamped'] else ''
        print(f"  {p.stem:<22} {r['n']:>4} {r['median']:>7.1f}L {r['delta']:>+6.1f} 0x{r['gain']:02x}{note}")
        if a.apply:
            set_gain(p, r['gain'])
    return 0
if __name__ == '__main__':
    raise SystemExit(main())
