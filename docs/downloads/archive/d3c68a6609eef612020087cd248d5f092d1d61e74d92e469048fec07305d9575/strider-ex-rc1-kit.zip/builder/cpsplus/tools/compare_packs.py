"""Compare two builds of a pack: tables exactly, audio by level."""
from __future__ import annotations
import argparse
import dataclasses
import json
import math
import sys
from pathlib import Path
import numpy as np
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from pack import adxcodec
from pack.format import PackReader
STREAM_FIELDS = {'data_offset', 'data_length'}
HEADER_STREAM_FIELDS = {'crc_data'}

def db_below(reference: np.ndarray, difference: np.ndarray) -> float:
    """How far the difference's RMS sits below the reference's, in dB."""
    ref = math.sqrt(float(np.mean(reference.astype(np.float64) ** 2)))
    err = math.sqrt(float(np.mean(difference.astype(np.float64) ** 2)))
    if err == 0:
        return math.inf
    if ref == 0:
        return -math.inf
    return 20 * math.log10(ref / err)

def meta(track) -> dict:
    fields = dataclasses.asdict(track) if dataclasses.is_dataclass(track) else vars(track)
    return {k: v for k, v in fields.items() if k not in STREAM_FIELDS}

def pcm(reader: PackReader, index: int) -> np.ndarray:
    track = reader.tracks[index]
    raw = adxcodec.decode(reader.read_track(index), track.channels, track.sample_rate)
    return np.frombuffer(raw, '<i2').astype(np.int32)

def compare(reference: Path, candidate: Path) -> dict:
    a, b = (PackReader(reference), PackReader(candidate))
    try:
        problems = []
        ha = {k: v for k, v in vars(a.header).items() if k not in HEADER_STREAM_FIELDS}
        hb = {k: v for k, v in vars(b.header).items() if k not in HEADER_STREAM_FIELDS}
        if ha != hb:
            problems.append(f'headers differ: {sorted((k for k in ha if ha[k] != hb.get(k)))}')
        if [r.pack() for r in a.triggers] != [r.pack() for r in b.triggers]:
            rows = [i for i, (x, y) in enumerate(zip(a.triggers, b.triggers)) if x.pack() != y.pack()]
            problems.append(f'trigger rows differ: {[hex(i) for i in rows[:16]]}')
        if len(a.tracks) != len(b.tracks):
            problems.append(f'track counts differ: {len(a.tracks)} vs {len(b.tracks)}')
        tracks = []
        for i, (x, y) in enumerate(zip(a.tracks, b.tracks)):
            if meta(x) != meta(y):
                changed = sorted((k for k in meta(x) if meta(x)[k] != meta(y).get(k)))
                problems.append(f'track {i} metadata differs: {changed}')
                continue
            p, q = (pcm(a, i), pcm(b, i))
            n = min(p.size, q.size)
            d = q[:n] - p[:n]
            tracks.append({'track': i, 'name': x.name, 'db_below': round(db_below(p[:n], d), 1), 'peak_diff': int(np.abs(d).max()) if n else 0, 'samples_differ_pct': round(100 * float(np.mean(d != 0)), 1) if n else 0.0})
        finite = [t['db_below'] for t in tracks if math.isfinite(t['db_below'])]
        return {'reference': str(reference), 'candidate': str(candidate), 'problems': problems, 'tracks': tracks, 'identical_tracks': sum((1 for t in tracks if t['db_below'] == math.inf)), 'worst_db_below': min(finite) if finite else None, 'median_db_below': float(np.median(finite)) if finite else None}
    finally:
        a.close()
        b.close()

def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('reference', type=Path)
    ap.add_argument('candidate', type=Path)
    ap.add_argument('--json', type=Path, help='write the full per-track report here')
    args = ap.parse_args(argv)
    report = compare(args.reference, args.candidate)
    for t in report['tracks']:
        print(f"  {t['track']:3d} {t['name']:<24} {t['db_below']:>6} dB below  peak {t['peak_diff']:>5}  {t['samples_differ_pct']:>5}% of samples")
    for problem in report['problems']:
        print(f'PROBLEM: {problem}')
    print(f"{len(report['tracks'])} tracks compared, {report['identical_tracks']} identical; difference median {report['median_db_below']} dB, worst {report['worst_db_below']} dB below the reference")
    if args.json:
        args.json.write_text(json.dumps(report, indent=1) + '\n')
    return 1 if report['problems'] else 0
if __name__ == '__main__':
    raise SystemExit(main())
