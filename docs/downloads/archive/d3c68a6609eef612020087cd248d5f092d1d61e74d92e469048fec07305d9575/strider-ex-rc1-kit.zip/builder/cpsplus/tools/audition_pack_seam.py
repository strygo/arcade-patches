"""Cut loop-seam audition clips out of a built pack, as the FPGA plays it."""
from __future__ import annotations
import argparse
import array
import re
import sys
import wave
from pathlib import Path
REPO = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(REPO / 'cpsplus'))
from pack import audition
from pack.format import PackReader, VERB_PLAY

class SeamError(RuntimeError):
    pass

def seam_clip(reader: PackReader, track: int, ctx: float) -> tuple[array.array, int, str, float, float]:
    pcm, meta = audition.render(reader, track, loops=1)
    if not meta.loops:
        raise SeamError('track does not loop')
    _, end = audition._loop_points_samples(meta)
    blend = reader.header.xfade_samples if meta.xfade_enable else 0
    rate, channels = (meta.sample_rate, meta.channels)
    start, _ = audition._loop_points_samples(meta)
    samples = array.array('h')
    samples.frombytes(pcm)
    frames = len(samples) // channels
    first = max(end - int(ctx * rate), 0)
    last = min(end + int(ctx * rate), frames)
    if last <= first:
        raise SeamError('rendered stream is too short for the requested window')
    clip = samples[first * channels:last * channels]
    return (clip, rate, meta.name, end / rate, (start + blend) / rate)

def _scaled(clip: array.array, factor: float, name: str) -> array.array:
    out = array.array('h', (int(round(v * factor)) for v in clip))
    if out and max(max(out), -min(out)) > 32767 * 0.999:
        raise SeamError(f'{name}: --apply-gain clips; lower the makeup')
    return out

def mmss(seconds: float) -> str:
    return f'{int(seconds // 60)}:{seconds % 60:05.2f}'

def write_wav(samples: array.array, rate: int, channels: int, dest: Path) -> None:
    with wave.open(str(dest), 'w') as handle:
        handle.setnchannels(channels)
        handle.setsampwidth(2)
        handle.setframerate(rate)
        handle.writeframes(samples.tobytes())

def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('pack')
    ap.add_argument('--cmds', required=True, help='comma list of arcade commands, e.g. 0x01,0x04,0x07')
    ap.add_argument('--out-dir', required=True)
    ap.add_argument('--ctx', type=float, default=5.0, help='seconds each side of the wrap (default 5 = a 10 s clip)')
    ap.add_argument('--reel', help='also write one strung-together file; NOT the listening-gate deliverable, see the docstring')
    ap.add_argument('--gap', type=float, default=1.0)
    ap.add_argument('--names-from', metavar='PACK', action='append', default=[], help='name each clip after the track this other pack plays for the same command (for a pack whose own track names say nothing, e.g. arg_02.adx); repeat to try several, first that plays wins')
    ap.add_argument('--apply-gain', type=float, metavar='MAKEUP_DB', default=None, help='scale each clip by the gain the player applies (trigger x track, as the pack stores it) plus this makeup, so clips from different packs play at their real relative loudness; raises if a clip clips')
    ap.add_argument('--page', action='store_true', help='also write index.html: one player and a verdict per clip')
    a = ap.parse_args(argv)
    out_dir = Path(a.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    notes: list[str] = []
    clips_made: list[tuple[str, str, str]] = []
    reader = PackReader(a.pack)
    names = [PackReader(p) for p in a.names_from]
    reel = array.array('h')
    reel_rate = channels = None
    made = 0
    try:
        for text in a.cmds.split(','):
            command = int(text, 0)
            trigger = reader.triggers[command]
            if trigger.verb != VERB_PLAY:
                print(f'0x{command:02x}: not a play command, skipped')
                continue
            meta = reader.tracks[trigger.track]
            try:
                clip, rate, name, plays_to, drops_to = seam_clip(reader, trigger.track, a.ctx)
            except SeamError as exc:
                print(f'0x{command:02x} {meta.name}: {exc}')
                continue
            if reel_rate is None:
                reel_rate, channels = (rate, meta.channels)
            elif (rate, meta.channels) != (reel_rate, channels):
                raise SeamError('a reel needs one rate and channel count')
            for other in names:
                if other.triggers[command].verb == VERB_PLAY:
                    name = other.tracks[other.triggers[command].track].name
                    break
            if a.apply_gain is not None:
                clip = _scaled(clip, trigger.gain / 127 * (meta.gain / 127) * 10 ** (a.apply_gain / 20), name)
            label = re.sub('[^A-Za-z0-9.]+', '_', re.sub('\\s*\\([^)]*\\)\\s*$', '', name)).strip('_') or f'cmd{command:02x}'
            write_wav(clip, rate, meta.channels, out_dir / f'cmd{command:02x}_{label}_seam.wav')
            line = f"cmd{command:02x}_{label}_seam.wav  {label}: plays to {mmss(plays_to)}, drops back to {mmss(drops_to)}  ({('xfade' if meta.xfade_enable else 'baked')} loop, period {mmss(plays_to - drops_to)})"
            notes.append(line)
            clips_made.append((f'cmd{command:02x}_{label}_seam.wav', meta.name, line))
            print('  ' + line)
            made += 1
            if a.reel:
                reel.extend(clip)
                reel.extend([0] * int(a.gap * rate) * meta.channels)
    finally:
        reader.close()
        for other in names:
            other.close()
    if a.page and clips_made:
        (out_dir / 'index.html').write_text(_page(Path(a.pack).name, clips_made))
    if notes:
        readme = out_dir / 'README.txt'
        readme.write_text(f'Loop seams from {Path(a.pack).name}\nEach clip is {2 * a.ctx:.0f} s with the jump in the middle ({a.ctx:.0f} s before, {a.ctx:.0f} s after).\nNumbers are as they PLAY.\n\n' + '\n'.join(notes) + '\n\nA seam clip shows whether the JOIN is clean; it cannot show\nwhether the loop period is right or where the loop lands.\n', encoding='utf-8')
        print(f'\nwrote {readme}')
    if a.reel and made:
        assert reel_rate is not None and channels is not None
        dest = out_dir / f'{a.reel}.wav'
        write_wav(reel, reel_rate, channels, dest)
        print(f'\nreel: {dest} ({len(reel) / channels / reel_rate:.1f}s, {made} seams)')
    return 0

def _page(pack: str, clips: list[tuple[str, str, str]]) -> str:
    import html as h
    rows = ''.join((f'''<section data-clip="{h.escape(f)}"><h2>{h.escape(name)}</h2>\n<p class="m">{h.escape(line.split('  ', 1)[1] if '  ' in line else line)}</p>\n<audio controls preload="none" src="{h.escape(f)}"></audio>\n<fieldset><label><input type="radio" name="{h.escape(f)}" value="clean"> clean</label>\n<label><input type="radio" name="{h.escape(f)}" value="audible"> audible seam</label>\n<input type="text" name="{h.escape(f)}-note" placeholder="note"></fieldset></section>''' for f, name, line in clips))
    return '<!doctype html><html lang="en"><head><meta charset="utf-8">\n<meta name="viewport" content="width=device-width,initial-scale=1"><title>Loop seams</title>\n<style>:root{--bg:#fff;--fg:#1b1b1b;--muted:#666;--line:#ddd}\n@media (prefers-color-scheme:dark){:root{--bg:#161616;--fg:#eee;--muted:#aaa;--line:#333}}\nbody{background:var(--bg);color:var(--fg);font:15px/1.45 system-ui,sans-serif;max-width:820px;margin:0 auto;padding:16px}\nsection{border-top:1px solid var(--line);padding:10px 0}.m{color:var(--muted)}audio{width:100%}\nfieldset{border:1px solid var(--line)}</style></head><body>\n<h1>Loop seams: ' + h.escape(pack) + '</h1>\n<p>Each clip is 10 s from the built pack as the player plays it; the jump back is in the middle. Starting one pauses the others.</p>\n<p><button id="export">Export verdicts</button> <span id="count"></span></p>' + rows + "\n<script>const KEY='seams-" + h.escape(pack) + "';\nfunction load(){try{return JSON.parse(localStorage.getItem(KEY)||'{}')}catch(e){return{}}}\nfunction save(d){try{localStorage.setItem(KEY,JSON.stringify(d))}catch(e){}}\nconst d=load();document.querySelectorAll('input').forEach(i=>{\n if(i.type==='radio'&&d[i.name]===i.value)i.checked=true;if(i.type==='text'&&d[i.name])i.value=d[i.name];\n i.addEventListener('change',()=>{const x=load();x[i.name]=i.value;save(x);count()})});\nfunction count(){const x=load();document.getElementById('count').textContent=\n [...document.querySelectorAll('section')].filter(s=>x[s.dataset.clip]).length+' of '+document.querySelectorAll('section').length+' judged'}\ncount();document.addEventListener('play',e=>{document.querySelectorAll('audio').forEach(a=>{if(a!==e.target)a.pause()})},true);\ndocument.getElementById('export').onclick=()=>{const b=new Blob([JSON.stringify(load(),null,1)],{type:'application/json'});\n const a=document.createElement('a');a.href=URL.createObjectURL(b);a.download='seam_verdicts.json';a.click()};</script></body></html>"
if __name__ == '__main__':
    sys.exit(main())
