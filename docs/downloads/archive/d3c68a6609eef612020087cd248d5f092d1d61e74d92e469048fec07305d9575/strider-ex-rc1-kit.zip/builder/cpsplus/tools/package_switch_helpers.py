"""Seal per-host helper identities and a standard-library offline bundle."""
import argparse, copy, hashlib, json, sys, zipfile
from pathlib import Path
from fetch_switch_tools import inventory
from build_switch_helpers import archive

def run(a):
    if a.out.exists():
        raise ValueError('Fresh helper release output required')
    a.out.mkdir(parents=True)
    records = {}
    for folder in a.host:
        r = json.loads((folder / 'record.json').read_text())
        data = (folder / r['filename']).read_bytes()
        inventory(data, r)
        host = r['sources']['host']
        r['url'] = a.url.rstrip('/') + '/' + r['filename']
        records[host] = r
        (a.out / r['filename']).write_bytes(data)
    if 'windows-x86_64' in records:
        r = copy.deepcopy(records['windows-x86_64'])
        r['minimum_windows_build'] = 22000
        r['execution'] = 'Windows 11 ARM x64 emulation'
        records['windows-arm64'] = r
    lock = dict(schema=1, release='switch-helpers-v1', platforms=records)
    path = a.out / 'switch_helpers.json'
    path.write_text(json.dumps(lock, indent=2, sort_keys=True) + '\n')
    (a.out / 'README.txt').write_text('Switch extraction helpers v1\n\nUse the host archive named by your reconstruction kit, or supply the complete\nswitch-helpers-v1-offline.zip with --tools-bundle PATH --offline.\nThe kit verifies pinned archive/member hashes before executing either helper.\nLicenses, exact source revisions and producer recipes are inside each archive.\nLinux builds target Ubuntu 24.04 or newer with its standard C/C++ runtime.\nWindows ARM uses the tested x64 pair through Windows 11 emulation.\nNo game data or keys are included.\n')
    files = sorted(a.out.iterdir())
    out = a.out / 'switch-helpers-v1-offline.zip'
    with zipfile.ZipFile(out, 'w', zipfile.ZIP_STORED) as z:
        for p in files:
            i = zipfile.ZipInfo(p.name, (2026, 10, 23, 0, 0, 0))
            i.create_system = 3
            i.external_attr = 33188 << 16
            z.writestr(i, p.read_bytes())
    print('PASS sealed helper platforms:', ', '.join(sorted(records)), flush=True)
if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--host', action='append', required=True, type=Path)
    p.add_argument('--out', required=True, type=Path)
    p.add_argument('--url', default='https://github.com/strygo/arcade-patches/releases/download/switch-helpers-v1')
    run(p.parse_args())
