"""Measure and render Strider listening candidates; never builds a CPS+ pack."""
from __future__ import annotations
import argparse
import csv
import hashlib
import json
from pathlib import Path
import subprocess
import wave
import numpy as np
from scipy import signal
ROOT = Path(__file__).resolve().parents[2]
RATE = 48000
PCE_TRACKS = [3, 4, 8, 9, 12, 13, 14, 15, 16, 17, 18, 19, 20]
PSX_BANKS = [1, 1, 2, 2, 4, 4, 3, 3, 5, 5]
PCE_PERIOD_BOUNDS = {'pce_18': (72.4, 73.0)}

def digest(path):
    with path.open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()

def read_wav(path, start=0, frames=None):
    with wave.open(str(path)) as f:
        assert f.getsampwidth() == 2
        rate = f.getframerate()
        f.setpos(start)
        x = np.frombuffer(f.readframes(frames or f.getnframes()), '<i2')
        x = x.reshape(-1, f.getnchannels()).astype(np.float64) / 32768
    if x.shape[1] == 1:
        x = np.repeat(x, 2, axis=1)
    assert x.shape[1] == 2
    return (x, rate)

def write_wav(path, x):
    assert np.isfinite(x).all() and np.max(np.abs(x)) < 1, path
    path.parent.mkdir(parents=True, exist_ok=True)
    with wave.open(str(path), 'wb') as f:
        f.setnchannels(2)
        f.setsampwidth(2)
        f.setframerate(RATE)
        f.writeframes(np.rint(x * 32768).clip(-32768, 32767).astype('<i2').tobytes())

def corr(a, b):
    a = a.ravel() - np.mean(a)
    b = b.ravel() - np.mean(b)
    return float(np.dot(a, b) / max(1e-20, np.linalg.norm(a) * np.linalg.norm(b)))

def ncc_scan(hay, needle):
    needle = needle - np.mean(needle)
    n = len(needle)
    c = signal.correlate(hay, needle, mode='valid', method='fft')
    sq = np.r_[0.0, np.cumsum(hay ** 2)]
    sums = np.r_[0.0, np.cumsum(hay)]
    energy = sq[n:] - sq[:-n] - (sums[n:] - sums[:-n]) ** 2 / n
    return c / np.sqrt(np.maximum(1e-20, energy * np.sum(needle ** 2)))

def period(x, minimum, maximum):
    mono = x.mean(1)
    coarse = signal.resample_poly(mono, 1, 12)
    cr = RATE / 12
    width = min(15.0, len(x) / RATE * 0.18)
    size = round(width * cr)
    best = (-1.0, 0.0, 0.0)
    for frac in (0.08, 0.18, 0.28, 0.38):
        a = round(len(coarse) * frac)
        lo = a + round(minimum * cr)
        hi = min(len(coarse) - size, a + round(maximum * cr))
        if hi <= lo:
            continue
        scores = ncc_scan(coarse[lo:hi + size], coarse[a:a + size])
        j = int(np.argmax(scores))
        if scores[j] > best[0]:
            best = (float(scores[j]), (lo + j - a) / cr, a / cr)
    assert best[0] > 0, 'No non-silent repeat candidate'
    _, lag, start = best
    a, size = (round(start * RATE), round(width * RATE))
    lo, hi = (round((start + lag) * RATE) - 48, round((start + lag) * RATE) + 48)
    scores = ncc_scan(mono[lo:hi + size], mono[a:a + size])
    j = int(np.argmax(scores))
    return (lo + j - a, float(scores[j]))

def choose_seam(x, lag, earliest, latest_end, psx):
    a0 = max(round(earliest * RATE), RATE)
    a1 = min(len(x) - lag - RATE, round(latest_end * RATE) - lag - RATE)
    assert a1 > a0, (earliest, latest_end, lag / RATE)
    width = RATE // 4
    coarse = []
    early_penalty = 0.0002 if psx else 0.004
    for a in range(a0, a1, RATE // 8):
        b = a + lag
        p, q = (x[a - width:a + width], x[b - width:b + width])
        rms_p, rms_q = (np.mean(p * p), np.mean(q * q))
        gain = float(10 * np.log10(max(1e-20, rms_q) / max(1e-20, rms_p)))
        if abs(gain) > 1.25 or rms_p < 1e-05:
            continue
        n = corr(p, q)
        score = n - early_penalty * (a / RATE - earliest) - 0.015 * abs(gain)
        coarse.append((score, a, n, gain))
    assert coarse, 'No level-consistent seam before fade'
    coarse.sort(reverse=True)
    best = None
    aligned_lag = round(lag / 32) * 32
    for _, a, _, _ in coarse[:12]:
        center = round(a / 32) * 32
        for aa in range(center - 256, center + 257, 32):
            for ll in range(aligned_lag - 96, aligned_lag + 97, 32):
                bb = aa + ll
                p, q = (x[aa - width:aa + width], x[bb - width:bb + width])
                n = corr(p, q)
                score = n - early_penalty * (aa / RATE - earliest)
                if best is None or score > best[0]:
                    best = (score, aa, bb, n)
    _, a, b, n = best
    crossfade = round((0.02 if n > 0.985 else 0.06 if n > 0.9 else 0.12 if n > 0.7 else 0.2) * RATE / 32) * 32
    p, q = (x[a - crossfade:a], x[b - crossfade:b])
    gain = float(10 * np.log10(np.mean(q * q) / np.mean(p * p)))
    y = x[:b].copy()
    weights = np.linspace(0.0, 1.0, crossfade)[:, None]
    y[b - crossfade:b] = q * (1 - weights) + p * weights
    assert a % 32 == b % 32 == crossfade % 32 == 0
    return (y, dict(loop_start=a, loop_end=b, crossfade_frames=crossfade, seam_context_ncc=n, seam_gain_db=gain, loop_seconds=(b - a) / RATE, joined_peak_dbfs=float(20 * np.log10(np.max(abs(y)))), needs_close_review=n < 0.85))

def psx_sources(work, catalog):
    cap = work / 'psx/remix_clean_capture'
    rows = list(csv.DictReader((cap / 'psu_trace.tsv').open(), delimiter='\t'))
    assert any((r['label'] == 'remix_10_looped' for r in rows))
    assert 'Average speed:' in (cap / 'run.log').read_text()
    capture_hash = digest(cap / 'audio.wav')
    checks = []
    for i, bank in enumerate(PSX_BANKS):
        sep = work / f'sources/psx/files/SOUND/BGM/BGM_ST{bank}R.SEP'
        expected = sep.read_bytes()
        loaded = []
        for suffix in ['loaded', 'looped']:
            path = next(cap.glob(f'*remix_{i + 1:02}_{suffix}_ram.bin'))
            ram = path.read_bytes()
            offset = ram.find(expected)
            assert offset >= 0 and ram[317156] == 1
            assert ram[317267] == bank - 1 and ram[317904] == i % 2
            assert int.from_bytes(ram[317644:317648], 'little') == i
            loaded.append(dict(file=str(path.relative_to(ROOT)), sha256=digest(path), sep_offset=offset))
        play = next((r for r in rows if r['kind'] == 'input_down' and r['label'] == 'P1_BUTTON2' and (int(r['frame']) == 4000 + 9000 * i)))
        t = float(play['time'])
        quiet, rate = read_wav(cap / 'audio.wav', round((t - 1) * RATE), RATE)
        assert rate == RATE and (not np.any(quiet)), f'Previous cue audible before test {i + 1}'
        x, rate = read_wav(cap / 'audio.wav', round(t * RATE), round(142 * RATE))
        onset = int(np.flatnonzero(np.max(abs(x), axis=1) > 4 / 32768)[0])
        trim = max(0, onset - 480)
        source = dict(capture=str((cap / 'audio.wav').relative_to(ROOT)), capture_sha256=capture_hash, play_frame=int(play['frame']), play_time=t, capture_trim_sample=round(t * RATE) + trim, onset_sample=round(t * RATE) + onset, quiet_before_play_frames=RATE, bank=bank, sequence=i % 2, sep_sha256=digest(sep), ram_checks=loaded)
        seq = next((b for b in catalog['banks'] if b['file'] == sep.name))['sequences'][i % 2]
        start = next((c['seconds'] for c in seq['controls'] if c['controller'] == 99 and c['value'] == 20))
        end = next((c['seconds'] for c in seq['controls'] if c['controller'] == 99 and c['value'] == 30))
        checks.append(source)
        yield (f'psx_{i + 1:02}', x[trim:], source, end - start, max(1.0, start + 0.5))
    (cap / 'verified_sources.json').write_text(json.dumps(checks, indent=2) + '\n')

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--work', type=Path, default=ROOT / 'cpsplus/work/strider')
    p.add_argument('--outdir', type=Path, required=True)
    p.add_argument('--edition', choices=['pce', 'psx', 'both'], default='both')
    p.add_argument('--self-test', action='store_true')
    a = p.parse_args()
    if a.self_test:
        rng = np.random.default_rng(19)
        needle = rng.normal(size=400)
        hay = np.r_[rng.normal(size=100), needle, rng.normal(size=90)]
        scores = ncc_scan(hay, needle)
        assert np.argmax(scores) == 100 and abs(scores[100] - 1) < 1e-10
        phrase = rng.normal(0, 0.05, size=(RATE * 2, 2))
        x = np.r_[np.zeros((RATE, 2)), phrase, phrase, phrase]
        y, r = choose_seam(x, RATE * 2, 1.2, 6.8, True)
        assert r['loop_end'] - r['loop_start'] == RATE * 2
        assert r['seam_context_ncc'] > 0.999999 and np.max(abs(y - x[:len(y)])) < 1e-12
        print('self-test: FFT match, aligned repeat and unity join pass')
        return
    a.outdir.mkdir(parents=True, exist_ok=True)
    inventory = json.loads((ROOT / 'cpsplus/manifests/strider_source_inventory.json').read_text())
    result = []

    def render(key, x, source, expected=None, earliest=3.0, latest=None):
        duration = len(x) / RATE
        bounds = PCE_PERIOD_BOUNDS.get(key, (expected * 0.97, expected * 1.03) if expected else (10.0, duration * 0.8))
        lag, ncc = period(x, *bounds)
        y, recipe = choose_seam(x, lag, earliest, latest or duration - 1, expected is not None)
        start, end = (recipe['loop_start'], recipe['loop_end'])
        full = np.concatenate([y, y[start:end], y[start:end]])
        wrap = np.concatenate([y[max(start, end - 6 * RATE):end], y[start:min(end, start + 9 * RATE)]])
        write_wav(a.outdir / f'{key}_candidate.wav', y)
        write_wav(a.outdir / f'{key}_opening.wav', y[:min(len(y), 18 * RATE)])
        write_wav(a.outdir / f'{key}_wrap.wav', wrap)
        write_wav(a.outdir / f'{key}_repeated.wav', full)
        write_wav(a.outdir / f'{key}_source.wav', x)
        row = dict(id=key, status='candidate_listening_pending', rate=RATE, source=source, source_frames=len(x), measured_period_frames=lag, period_probe_ncc=ncc, period_search_bounds_seconds=bounds, trim_gain_db=0, resampling='scipy resample_poly 160/147 Kaiser 8.6' if expected is None else 'none', latest_allowed_end_seconds=latest or duration - 1, **recipe)
        row['outputs'] = {kind: dict(file=f'{key}_{kind}.wav', sha256=digest(a.outdir / f'{key}_{kind}.wav')) for kind in ['candidate', 'opening', 'wrap', 'repeated', 'source']}
        result.append(row)
        print(key, round(start / RATE, 6), round(end / RATE, 6), 'NCC', round(recipe['seam_context_ncc'], 4), flush=True)
    if a.edition in ('pce', 'both'):
        structure = list(csv.DictReader((line for line in (ROOT / 'cpsplus/manifests/strider_pce_cdda_structure.tsv').read_text().splitlines() if line and (not line.startswith('#'))), delimiter='\t'))
        for track in PCE_TRACKS:
            path = ROOT / f'cpsplus/work/listening/strider/cd_full/tr{track:02}.wav'
            inv = next((r for r in inventory['pce'] if r['track'] == track))
            assert digest(path) == inv['wav_sha256']
            x, rate = read_wav(path)
            assert rate == 44100
            structure_row = next((r for r in structure if r['track'] == f'tr{track:02}'))
            first = int(structure_row['lead_sil_frames'])
            trim = max(0, first - 441)
            x = signal.resample_poly(x[trim:], 160, 147, axis=0, window=('kaiser', 8.6))
            latest = float(structure_row['fade_onset3_s']) - trim / rate - 6
            source = dict(path=str(path.relative_to(ROOT)), sha256=inv['wav_sha256'], source_rate=rate, source_trim_frames=trim, disc_track=track, source_bin_sha256=inv['sha256'])
            render(f'pce_{track:02}', x, source, latest=latest)
    if a.edition in ('psx', 'both'):
        cat = json.loads((ROOT / 'cpsplus/manifests/strider_psx_source_catalog.json').read_text())
        for key, x, source, expected, earliest in psx_sources(a.work, cat):
            render(key, x, source, expected, earliest)
    (a.outdir / 'candidates.json').write_text(json.dumps(result, indent=2) + '\n')
if __name__ == '__main__':
    main()
