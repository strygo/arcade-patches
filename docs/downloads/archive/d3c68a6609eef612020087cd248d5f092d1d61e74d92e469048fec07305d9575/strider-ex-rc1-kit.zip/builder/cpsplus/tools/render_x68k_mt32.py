"""Render extracted X68000 MT-32 arrangements with pinned Munt."""
from __future__ import annotations
import argparse
import hashlib
import json
import struct
import subprocess
import sys
from pathlib import Path

class RenderError(RuntimeError):
    pass
SETTLE_LOOP_PASSES = 1
MACHINES = {'mt32_1_04': ('mt32_ctrl_1_04.rom', 'mt32_pcm.rom', 2), 'mt32_1_05': ('mt32_ctrl_1_05.rom', 'mt32_pcm.rom', 2), 'mt32_1_06': ('mt32_ctrl_1_06.rom', 'mt32_pcm.rom', 2), 'mt32_1_07': ('mt32_ctrl_1_07.rom', 'mt32_pcm.rom', 2), 'mt32_2_04': ('mt32_ctrl_2_04.rom', 'mt32_pcm.rom', 3), 'mt32_2_06': ('mt32_ctrl_2_06.rom', 'mt32_pcm.rom', 3), 'mt32_2_07': ('mt32_ctrl_2_07.rom', 'mt32_pcm.rom', 3)}

def _digest(path: Path, algorithm: str) -> str:
    digest = hashlib.new(algorithm)
    with path.open('rb') as source:
        for block in iter(lambda: source.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()

def _resolve(repo: Path, value: str | Path) -> Path:
    path = Path(value)
    return path if path.is_absolute() else repo / path

def _display_path(repo: Path, path: Path) -> str:
    try:
        return path.absolute().relative_to(repo.absolute()).as_posix()
    except ValueError:
        return str(path.absolute())

def _run(command: list[str]) -> str:
    result = subprocess.run(command, text=True, capture_output=True)
    if result.returncode:
        details = '\n'.join((part for part in (result.stdout, result.stderr) if part))
        raise RenderError(f"command failed ({result.returncode}): {' '.join(command)}\n{details}")
    return '\n'.join((part for part in (result.stdout, result.stderr) if part))

def _renderer_version(renderer: Path) -> str:
    output = _run([str(renderer), '--help'])
    identity = [line.strip() for line in output.splitlines() if line.startswith('Munt MT32Emu') or line.startswith('Using Munt ')]
    if len(identity) != 2:
        raise RenderError(f'could not identify Munt renderer: {renderer}')
    return '\n'.join(identity)

def _wav_info(path: Path) -> dict[str, int]:
    with path.open('rb') as source:
        header = source.read(12)
        if len(header) != 12 or header[:4] != b'RIFF' or header[8:] != b'WAVE':
            raise RenderError(f'renderer did not produce a RIFF/WAVE file: {path}')
        fmt: tuple[int, int, int, int, int] | None = None
        data_size: int | None = None
        while True:
            chunk = source.read(8)
            if not chunk:
                break
            if len(chunk) != 8:
                raise RenderError(f'truncated WAVE chunk header: {path}')
            kind, size = struct.unpack('<4sI', chunk)
            if kind == b'fmt ' and size >= 16:
                payload = source.read(size)
                if len(payload) != size:
                    raise RenderError(f'truncated WAVE fmt chunk: {path}')
                encoding, channels, rate, _, block_align, bits = struct.unpack('<HHIIHH', payload[:16])
                fmt = (encoding, channels, rate, block_align, bits)
            elif kind == b'data':
                data_size = size
                source.seek(size, 1)
            else:
                source.seek(size, 1)
            if size & 1:
                source.seek(1, 1)
        if fmt is None or data_size is None:
            raise RenderError(f'WAVE file lacks fmt/data chunks: {path}')
    encoding, channels, rate, block_align, bits = fmt
    if not block_align or data_size % block_align:
        raise RenderError(f'misaligned WAVE data: {path}')
    return {'encoding': encoding, 'channels': channels, 'sample_rate': rate, 'bits_per_sample': bits, 'frames': data_size // block_align}

def _firmware(rom_dir: Path, machine_id: str) -> dict[str, dict[str, object]]:
    control, pcm, _ = MACHINES[machine_id]
    missing = [name for name in (control, pcm) if not (rom_dir / name).is_file()]
    if missing:
        raise RenderError(f'{machine_id} firmware is incomplete in {rom_dir}; missing: ' + ', '.join(missing))
    return {role: {'path': name, 'size': (rom_dir / name).stat().st_size, 'sha1': _digest(rom_dir / name, 'sha1'), 'sha256': _digest(rom_dir / name, 'sha256')} for role, name in (('control', control), ('pcm', pcm))}

def _loop_candidate(loop: dict[str, object] | None, rate: int) -> dict[str, object] | None:
    if loop is None:
        return None
    period_ticks = int(loop['period_ticks'])
    start_tick = int(loop['start_tick']) + SETTLE_LOOP_PASSES * period_ticks
    end_tick = start_tick + period_ticks
    period_seconds = float(loop['period_seconds'])
    start_seconds = float(loop['start_seconds']) + SETTLE_LOOP_PASSES * period_seconds
    start_seconds = round(start_seconds, 9)
    end_seconds = round(start_seconds + period_seconds, 9)
    return {'strategy': 'second rendered pass after one reverb-settling pass', 'settled_passes': SETTLE_LOOP_PASSES, 'start_seconds': start_seconds, 'end_seconds': end_seconds, 'period_seconds': period_seconds, 'start_tick': start_tick, 'end_tick': end_tick, 'start_sample': round(start_seconds * rate), 'end_sample': round(end_seconds * rate), 'source_loop': loop}

def _configuration(args: argparse.Namespace) -> dict[str, object]:
    dac_mode = MACHINES[args.machine_id][2]
    return {'sample_rate': args.sample_rate, 'sample_rate_conversion': 'BEST', 'max_partials': 32, 'analog_output_mode': 'ACCURATE', 'renderer_type': 'Integer 16-bit (accurate LA32 model)', 'output_sample_format': 'signed 16-bit', 'dac_input_mode': 'GENERATION1' if dac_mode == 2 else 'GENERATION2', 'midi_delay_mode': 'delay short messages only (Munt default)', 'accurate_amplitude_ramp': True, 'preserve_start_silence': True, 'end_behavior': args.end}

def _renderer_command(args: argparse.Namespace, renderer: Path, rom_dir: Path, output: Path, source: Path) -> list[str]:
    dac_mode = MACHINES[args.machine_id][2]
    command = [str(renderer), '--force', '--quiet', f'--rom-dir={rom_dir.resolve()}', f'--machine-id={args.machine_id}', f'--sample-rate={args.sample_rate}', '--src-quality=3', '--max-partials=32', '--analog-output-mode=2', '--renderer-type=0', '--output-sample-format=0', f'--dac-input-mode={dac_mode}', '--no-nice-amp-ramp', '--record-max-start-silence=-1']
    if args.end == 'cut':
        command.append('--no-wait-for-la32')
    command.extend([f'--output={output.resolve()}', str(source.resolve())])
    return command

def render(args: argparse.Namespace, repo: Path) -> Path:
    catalog_path = args.catalog.absolute()
    if not catalog_path.is_file():
        raise RenderError(f'extraction catalog is missing: {catalog_path}')
    catalog = json.loads(catalog_path.read_text())
    if catalog.get('schema') != 'cpsplus-x68000-audio-v1':
        raise RenderError(f'unsupported extraction catalog: {catalog_path}')
    from fetch_optional_tools import resolve
    if args.renderer is None:
        args.renderer = resolve('mt32')
    renderer = args.renderer.resolve()
    if not renderer.is_file():
        raise RenderError(f'Munt renderer is missing: {renderer}; check --renderer. ')
    renderer_version = _renderer_version(renderer)
    firmware = _firmware(args.rom_dir.resolve(), args.machine_id)
    configuration = _configuration(args)
    games = [game for game in catalog['games'] if not args.game or game['game'] in args.game]
    if args.game:
        found = {game['game'] for game in games}
        missing = sorted(set(args.game) - found)
        if missing:
            raise RenderError('games not in catalog: ' + ', '.join(missing))
    selected: list[tuple[dict[str, object], dict[str, object]]] = []
    for game in games:
        for row in game.get('loop_points', {}).get('midi', []):
            if '0x16' not in row.get('source', {}).get('roland_model_ids', []):
                continue
            if args.song and row['song'] not in args.song:
                continue
            selected.append((game, row))
    if args.song:
        found_songs = {row['song'] for _, row in selected}
        missing = sorted(set(args.song) - found_songs)
        if missing:
            raise RenderError('MT-32 songs not in selection: ' + ', '.join(missing))
    if args.limit is not None:
        selected = selected[:args.limit]
    if not selected:
        raise RenderError('selection contains no Roland model-ID 0x16 songs')
    if int(catalog.get('finite_loop_passes', 0)) < 3 and any((row.get('loop') is not None for _, row in selected)):
        raise RenderError('looped MIDI was exported with fewer than three passes; rerun extract_x68k_music.py --loops 3 before capture')
    args.output = args.output.absolute()
    args.output.mkdir(parents=True, exist_ok=True)
    output_catalog = args.output / 'catalog.json'
    captures_by_song: dict[tuple[str, str], dict[str, object]] = {}
    if output_catalog.is_file():
        previous = json.loads(output_catalog.read_text())
        if previous.get('schema') != 'cpsplus-x68000-mt32-capture-v1' or previous.get('machine_id') != args.machine_id or previous.get('firmware') != firmware or (previous.get('renderer_version') != renderer_version) or (previous.get('render_configuration') != configuration):
            raise RenderError(f'existing capture catalog uses different settings: {output_catalog}; choose another --output directory')
        current_inputs = {(str(game['game']), str(row['song'])): row['source']['sha256'] for game in catalog['games'] for row in game.get('loop_points', {}).get('midi', [])}
        for record in previous.get('captures', []):
            key = (str(record['game']), str(record['song']))
            if record.get('input_sha256') == current_inputs.get(key):
                captures_by_song[key] = record
    for game, row in selected:
        source = _resolve(repo, row['source']['source'])
        if not source.is_file():
            raise RenderError(f'source MIDI is missing: {source}')
        input_hash = _digest(source, 'sha256')
        if input_hash != row['source']['sha256']:
            raise RenderError(f'source MIDI hash mismatch: {source}')
        game_dir = args.output / str(game['game'])
        game_dir.mkdir(parents=True, exist_ok=True)
        output = game_dir / f"{row['song']}.wav"
        sidecar = output.with_suffix('.json')
        command = _renderer_command(args, renderer, args.rom_dir, output, source)
        if args.dry_run:
            print(' '.join(command))
            continue
        if output.exists() or sidecar.exists():
            if not args.overwrite:
                if not output.is_file() or not sidecar.is_file():
                    raise RenderError(f'incomplete prior capture: {output}; use --overwrite')
                existing = json.loads(sidecar.read_text())
                reusable = existing.get('input_sha256') == input_hash and existing.get('renderer_version') == renderer_version and (existing.get('machine_id') == args.machine_id) and (existing.get('firmware') == firmware) and (existing.get('render_configuration') == configuration) and (existing.get('output_sha256') == _digest(output, 'sha256'))
                if not reusable:
                    raise RenderError(f'prior capture does not match this run: {output}; use --overwrite')
                print(f"reusing {game['game']}/{row['song']}", flush=True)
                captures_by_song[str(game['game']), str(row['song'])] = existing
                continue
        print(f"rendering {game['game']}/{row['song']} ...", flush=True)
        render_output = _run(command)
        if f'Using ROMs for machine {args.machine_id}.' not in render_output:
            raise RenderError(f'Munt did not confirm requested machine {args.machine_id}:\n{render_output}')
        wav = _wav_info(output)
        loop = _loop_candidate(row.get('loop'), wav['sample_rate'])
        if loop is not None and int(loop['end_sample']) > wav['frames']:
            raise RenderError(f"render ended before steady loop boundary for {output}: need {loop['end_sample']} frames, got {wav['frames']}")
        record: dict[str, object] = {'game': game['game'], 'song': row['song'], 'input': _display_path(repo, source), 'input_sha256': input_hash, 'output': _display_path(repo, output), 'output_sha256': _digest(output, 'sha256'), 'wav': wav, 'loop_status': row['loop_status'], 'loop_candidate': loop, 'renderer_version': renderer_version, 'machine_id': args.machine_id, 'firmware': firmware, 'render_configuration': configuration}
        sidecar.write_text(json.dumps(record, indent=2) + '\n')
        captures_by_song[str(game['game']), str(row['song'])] = record
    if args.dry_run:
        return output_catalog
    captures = [captures_by_song[key] for key in sorted(captures_by_song)]
    output_catalog.write_text(json.dumps({'schema': 'cpsplus-x68000-mt32-capture-v1', 'source_catalog': _display_path(repo, catalog_path), 'renderer_version': renderer_version, 'machine_id': args.machine_id, 'firmware': firmware, 'render_configuration': configuration, 'captures': captures}, indent=2) + '\n')
    print(f'captured {len(captures)} songs; catalog: {output_catalog}')
    return output_catalog

def self_test() -> None:
    loop = {'start_tick': 384, 'period_ticks': 1920, 'start_seconds': 6.956512, 'period_seconds': 34.78256}
    candidate = _loop_candidate(loop, 48000)
    assert candidate is not None
    assert candidate['start_tick'] == 2304
    assert candidate['end_tick'] == 4224
    assert candidate['start_sample'] == 2003475
    assert candidate['end_sample'] == 3673038
    assert set(MACHINES) == {'mt32_1_04', 'mt32_1_05', 'mt32_1_06', 'mt32_1_07', 'mt32_2_04', 'mt32_2_06', 'mt32_2_07'}
    print('render_x68k_mt32 self-test: OK')

def main(argv: list[str] | None=None) -> int:
    repo = Path(__file__).resolve().parents[2]
    upstream = repo / 'cpsplus' / 'work' / 'x68000' / 'upstream'
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--self-test', action='store_true')
    parser.add_argument('--catalog', type=Path, default=repo / 'cpsplus' / 'work' / 'x68000' / 'export' / 'catalog.json')
    parser.add_argument('--renderer', type=Path)
    parser.add_argument('--rom-dir', type=Path, default=repo / 'roms' / 'mt32' / 'versions', help='directory containing Munt-recognized, MAME-versioned MT-32 ROMs')
    parser.add_argument('--machine-id', choices=sorted(MACHINES), default='mt32_1_07')
    parser.add_argument('--sample-rate', type=int, default=48000)
    parser.add_argument('--output', type=Path)
    parser.add_argument('--end', choices=('cut', 'release'), default='cut')
    parser.add_argument('--game', action='append')
    parser.add_argument('--song', action='append')
    parser.add_argument('--limit', type=int)
    parser.add_argument('--overwrite', action='store_true')
    parser.add_argument('--dry-run', action='store_true')
    from tool_controls import add_arguments, configure
    add_arguments(parser)
    args = parser.parse_args(argv)
    configure(argv if argv is not None else __import__('sys').argv[1:])
    if args.self_test:
        self_test()
        return 0
    if args.limit is not None and args.limit < 1:
        parser.error('--limit must be at least one')
    if args.sample_rate < 1:
        parser.error('--sample-rate must be positive')
    if args.output is None:
        args.output = repo / 'cpsplus' / 'work' / 'x68000' / 'capture' / 'mt32' / args.machine_id
    render(args, repo)
    return 0
if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except (OSError, KeyError, json.JSONDecodeError, RenderError) as exc:
        print(f'render_x68k_mt32: error: {exc}', file=sys.stderr)
        raise SystemExit(1)
