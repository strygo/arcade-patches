"""Fetch and build the pinned tools the USF2 Remix pack reads its source with."""
from __future__ import annotations
import argparse
import os
import sys
import tempfile
from pathlib import Path
HERE = Path(os.path.abspath(__file__)).parent
sys.path.insert(0, str(HERE))
from setup_x68k_music_tools import EXE, GIT, SetupError, _run, absolute, cmake_build, require_binary
NSTOOL_REPOSITORY = 'https://github.com/jakcron/nstool.git'
NSTOOL_COMMIT = 'cfb826ca6c165fbcd816fd7949df88ef3d72a948'
OPUS_REPOSITORY = 'https://github.com/xiph/opus.git'
OPUS_COMMIT = 'ddbe48383984d56acd9e1ab6a090c54ca6b735a6'
DECODER = 'switch_opus_decode'
NSTOOL_LIBRARIES = ('libpietendo', 'libtoolchain', 'libfmt', 'liblz4', 'libmbedtls')
NSTOOL_PROJECT = 'cmake_minimum_required(VERSION 3.10)\nproject(nstool C CXX)\nif(NOT MSVC)\n  set(CMAKE_C_STANDARD 11)\nendif()\nset(CMAKE_CXX_STANDARD 11)\nset(SRC "{source}")\nif(MSVC)\n  # Use MSVC\'s default C mode, as upstream\'s Visual Studio projects do.\n  # /std:c11 enables /Zc:preprocessor and breaks older Windows SDKs\n  # (notably 10.0.16299.0\'s _VARIANT_BOOL /##/ macro in wtypes.h).\n  # NSTool\'s pinned C dependencies do not require C11 on MSVC.\n  # Upstream\'s Visual Studio projects enable ConformanceMode. Without it,\n  # MSVC rejects BKTR\'s conditional between signed/unsigned le64 wrappers.\n  add_compile_options($<$<COMPILE_LANGUAGE:CXX>:/permissive->)\n  # libtoolchain calls std::isprint without including <cctype>; clang and\n  # gcc headers pull it in transitively, MSVC\'s need not.\n  add_compile_options($<$<COMPILE_LANGUAGE:CXX>:/FIcctype>)\nendif()\nforeach(lib {libraries})\n  file(GLOB_RECURSE files "${{SRC}}/deps/${{lib}}/src/*.c"\n       "${{SRC}}/deps/${{lib}}/src/*.cc" "${{SRC}}/deps/${{lib}}/src/*.cpp")\n  add_library(${{lib}} STATIC ${{files}})\n  target_include_directories(${{lib}} PUBLIC "${{SRC}}/deps/${{lib}}/include")\nendforeach()\ntarget_link_libraries(libtoolchain PUBLIC libmbedtls libfmt)\ntarget_link_libraries(libpietendo PUBLIC libtoolchain libmbedtls libfmt)\nfile(GLOB program "${{SRC}}/src/*.c" "${{SRC}}/src/*.cpp")\nadd_executable(nstool ${{program}})\ntarget_link_libraries(nstool PRIVATE {libraries})\nif(MINGW)\n  target_link_options(nstool PRIVATE -municode -static)\nendif()\n'
DECODER_PROJECT = 'cmake_minimum_required(VERSION 3.16)\nproject({target} C)\nset(OPUS_FIXED_POINT ON CACHE BOOL "" FORCE)\nset(OPUS_DISABLE_INTRINSICS ON CACHE BOOL "" FORCE)\nset(OPUS_BUILD_SHARED_LIBRARY OFF CACHE BOOL "" FORCE)\nset(OPUS_BUILD_TESTING OFF CACHE BOOL "" FORCE)\nset(OPUS_BUILD_PROGRAMS OFF CACHE BOOL "" FORCE)\nset(OPUS_INSTALL_PKG_CONFIG_MODULE OFF CACHE BOOL "" FORCE)\nset(OPUS_INSTALL_CMAKE_CONFIG_MODULE OFF CACHE BOOL "" FORCE)\nset(BUILD_SHARED_LIBS OFF CACHE BOOL "" FORCE)\nadd_subdirectory("{opus}" opus)\nadd_executable({target} "{decoder}")\ntarget_link_libraries({target} PRIVATE opus)\nif(MINGW)\n  target_link_options({target} PRIVATE -static)\nendif()\n'

def _checkout(path: Path, repository: str, commit: str, submodules: bool=False) -> None:
    if not path.exists():
        _run([*GIT, 'clone', '--no-checkout', repository, str(path)])
        _run([*GIT, 'checkout', '--detach', commit], path)
    elif not (path / '.git').exists():
        raise SetupError(f'existing path is not a Git checkout: {path}')
    head = _run([*GIT, 'rev-parse', 'HEAD'], path)
    if head != commit:
        raise SetupError(f'{path} is at {head}, expected {commit}; move it aside rather than having this setup command overwrite it')
    if submodules:
        _run([*GIT, 'submodule', 'update', '--init', '--recursive'], path)
    dirty = _run([*GIT, 'status', '--porcelain', '--untracked-files=no', '--ignore-submodules=none'], path)
    if dirty:
        raise SetupError(f'tracked files are modified in {path}; move it aside')

def _project(directory: Path, text: str) -> Path:
    directory.mkdir(parents=True, exist_ok=True)
    cmake_lists = directory / 'CMakeLists.txt'
    if not cmake_lists.is_file() or cmake_lists.read_text() != text:
        cmake_lists.write_text(text)
    return directory

def setup(root: Path) -> dict[str, Path]:
    """Build both tools under ``root``; return {"nstool": path, "decoder": path}."""
    root = absolute(root)
    root.mkdir(parents=True, exist_ok=True)
    nstool = root / 'nstool'
    _checkout(nstool, NSTOOL_REPOSITORY, NSTOOL_COMMIT, submodules=True)
    build = root / 'nstool-build'
    project = _project(build / 'project', NSTOOL_PROJECT.format(source=nstool.as_posix(), libraries=' '.join(NSTOOL_LIBRARIES)))
    if require_or_none(build / 'bin', 'nstool') is None:
        cmake_build(project, build / 'cmake', 'nstool', output=build / 'bin')
    tools = {'nstool': require_binary(build / 'bin', 'nstool')}
    opus = root / 'opus'
    _checkout(opus, OPUS_REPOSITORY, OPUS_COMMIT)
    build = root / 'opus-build'
    project = _project(build / 'project', DECODER_PROJECT.format(target=DECODER, opus=opus.as_posix(), decoder=(HERE / f'{DECODER}.c').as_posix()))
    built = require_or_none(build / 'bin', DECODER)
    if built is None or built.stat().st_mtime < (HERE / f'{DECODER}.c').stat().st_mtime:
        cmake_build(project, build / 'cmake', DECODER, output=build / 'bin')
    tools['decoder'] = require_binary(build / 'bin', DECODER)
    for name, path in tools.items():
        print(f'ready: {path}', flush=True)
    return tools

def require_or_none(directory: Path, name: str) -> Path | None:
    try:
        return require_binary(directory, name)
    except SetupError:
        return None

def self_test() -> None:
    assert len(NSTOOL_COMMIT) == len(OPUS_COMMIT) == 40
    text = NSTOOL_PROJECT.format(source='/s', libraries=' '.join(NSTOOL_LIBRARIES))
    assert 'set(SRC "/s")' in text and '${SRC}/deps/${lib}/src/*.cpp' in text
    assert 'if(NOT MSVC)\n  set(CMAKE_C_STANDARD 11)\nendif()' in text
    assert text.count('set(CMAKE_C_STANDARD') == 1
    assert '$<$<COMPILE_LANGUAGE:CXX>:/permissive->' in text
    assert '-municode' in text
    text = DECODER_PROJECT.format(target=DECODER, opus='/o', decoder='/d.c')
    assert 'OPUS_FIXED_POINT ON' in text and 'OPUS_DISABLE_INTRINSICS ON' in text
    assert (HERE / f'{DECODER}.c').is_file()
    with tempfile.TemporaryDirectory() as temporary:
        directory = Path(temporary)
        _project(directory, 'a')
        stamp = (directory / 'CMakeLists.txt').stat().st_mtime_ns
        _project(directory, 'a')
        assert (directory / 'CMakeLists.txt').stat().st_mtime_ns == stamp
        assert require_or_none(directory, 'nothing') is None
    assert EXE in ('', '.exe')
    print('setup_switch_tools self-test: OK')

def main(argv: list[str] | None=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--self-test', action='store_true')
    parser.add_argument('--root', type=Path, default=HERE.parent / 'work' / 'switch' / 'upstream')
    args = parser.parse_args(argv)
    if args.self_test:
        self_test()
        return 0
    setup(args.root)
    return 0
if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except (OSError, SetupError) as exc:
        print(f'setup_switch_tools: error: {exc}', file=sys.stderr)
        raise SystemExit(1)
