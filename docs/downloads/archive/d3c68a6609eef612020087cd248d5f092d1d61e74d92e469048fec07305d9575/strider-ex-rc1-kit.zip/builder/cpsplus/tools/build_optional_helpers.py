"""Build standalone optional helpers from authenticated source archives."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import shutil
import shlex
import subprocess
import sys
import tarfile
import urllib.request
import zipfile
HERE = Path(__file__).resolve().parent
RECIPE_BYTES = Path(__file__).read_bytes()
HOSTS = ('macos-arm64', 'macos-x86_64', 'windows-x86_64', 'linux-arm64', 'linux-x86_64')
MUNT_RNG_C = '/* SPDX-License-Identifier: LGPL-2.1-or-later\n * Portability adapter added 2026-10-24.\n * Portable Park-Miller recurrence, seed 1. Preserves the established Darwin\n * rand() sequence used by the accepted MT-32 renders; no libc source copied.\n */\n#include <stdint.h>\nstatic uint64_t state = UINT64_C(1);\nint capcom_munt_rand(void) {\n    state = (state * UINT64_C(16807)) % UINT64_C(2147483647);\n    return (int)state;\n}\n'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def run(argv, *, cwd=None, env=None):
    print('+', ' '.join(map(str, argv)), flush=True)
    subprocess.run(list(map(str, argv)), cwd=cwd, env=env, check=True)

def source(name, a, pins):
    pin = pins[name]
    archive = a.sources / pin['filename']
    if not archive.exists():
        archive.parent.mkdir(parents=True, exist_ok=True)
        data = urllib.request.urlopen(pin['url'], timeout=60).read(pin['bytes'] + 1)
        if len(data) != pin['bytes'] or sha(data) != pin['sha256']:
            raise ValueError('Source download identity differs: ' + name)
        archive.write_bytes(data)
    data = archive.read_bytes()
    if len(data) != pin['bytes'] or sha(data) != pin['sha256']:
        raise ValueError('Source archive identity differs: ' + name)
    target = a.root / name / 'source'
    target.mkdir(parents=True)
    with tarfile.open(archive) as tar:
        tar.extractall(target, filter='data')
    roots = list(target.iterdir())
    if len(roots) != 1 or not roots[0].is_dir():
        raise ValueError('Unexpected source root: ' + name)
    return roots[0]

def flags(a):
    f = ['-DCMAKE_BUILD_TYPE=Release', '-DCMAKE_POLICY_VERSION_MINIMUM=3.5', '-DCMAKE_C_FLAGS=-ffile-prefix-map=' + str(a.root) + '=/optional-helper-source', '-DCMAKE_CXX_FLAGS=-ffile-prefix-map=' + str(a.root) + '=/optional-helper-source']
    if a.host.startswith('macos-'):
        f += ['-DCMAKE_OSX_ARCHITECTURES=' + ('arm64' if a.host.endswith('arm64') else 'x86_64'), '-DCMAKE_OSX_DEPLOYMENT_TARGET=11.0']
    elif a.host == 'windows-x86_64':
        f += ['-DCMAKE_SYSTEM_NAME=Windows', '-DCMAKE_C_COMPILER=x86_64-w64-mingw32-gcc', '-DCMAKE_CXX_COMPILER=x86_64-w64-mingw32-g++', '-DCMAKE_RC_COMPILER=x86_64-w64-mingw32-windres', '-DCMAKE_EXE_LINKER_FLAGS=-static -static-libgcc -static-libstdc++', '-DCMAKE_SHARED_LINKER_FLAGS=-static-libgcc -static-libstdc++']
    elif a.host == 'linux-x86_64' and platform.machine() not in ('x86_64', 'AMD64'):
        f += ['-DCMAKE_SYSTEM_NAME=Linux', '-DCMAKE_SYSTEM_PROCESSOR=x86_64', '-DCMAKE_C_COMPILER=x86_64-linux-gnu-gcc', '-DCMAKE_CXX_COMPILER=x86_64-linux-gnu-g++']
    return f

def cmake(name, src, a, targets, options=()):
    build = a.root / name / 'build'
    run(['cmake', '-S', src, '-B', build, '-G', 'Ninja', *flags(a), *options])
    run(['cmake', '--build', build, '--parallel', a.jobs, '--target', *targets])
    return build

def custom(name, text, a):
    p = a.root / name / 'project'
    p.mkdir(parents=True, exist_ok=True)
    (p / 'CMakeLists.txt').write_text(text)
    return p

def munt_rng_adapter(src, project):
    """Scope libc-independent jitter to Munt; do not replace process-wide rand."""
    tvp = src / 'mt32emu/src/TVP.cpp'
    text = tvp.read_text()
    if text.count('(rand() & 3)') != 1 or text.count('#include "TVP.h"') != 1:
        raise ValueError('Pinned Munt pitch-jitter source changed')
    text = text.replace('#include "TVP.h"', '#include "TVP.h"\n// capcom adapter (2026-10-24): deterministic existing Darwin pitch-jitter sequence.\nextern "C" int capcom_munt_rand(void);')
    tvp.write_text(text.replace('(rand() & 3)', '(capcom_munt_rand() & 3)'))
    (project / 'munt_rand.c').write_text(MUNT_RNG_C)
    with (project / 'CMakeLists.txt').open('a') as out:
        out.write('target_sources(mt32emu PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}/munt_rand.c")\n')

def munt_filter_adapter(src):
    """Make the accepted ARM fused FIR accumulation explicit on other CPUs."""
    path = src / 'mt32emu/src/Analog.cpp'
    text = path.read_text()
    old = 'sample += LPF_TAPS[tapIx] * ringBuffer[(delaySampleIx + ringBufferPosition) & DELAY_LINE_MASK];'
    if text.count(old) != 1 or text.count('#include <cstring>') != 1:
        raise ValueError('Pinned Munt accurate filter source changed')
    text = text.replace('#include <cstring>', '#include <cstring>\n#include <math.h>')
    text = text.replace(old, '// capcom adapter (2026-10-24): preserve accepted ARM fused multiply/add rounding.\n\t\tsample = ::fmaf(LPF_TAPS[tapIx], ringBuffer[(delaySampleIx + ringBufferPosition) & DELAY_LINE_MASK], sample);')
    path.write_text(text)

def munt_math_adapter(src):
    """Use the accepted native exp2f lookup-table calculation on every host."""
    path = src / 'mt32emu/src/mmath.h'
    text = path.read_text()
    old = '#ifdef __APPLE__\n\t// on OSX exp2f() is 1.59 times faster than "exp() and the multiplication with FLOAT_LN_2"\n\treturn exp2f(x);\n#else\n\treturn exp(FLOAT_LN_2 * x);\n#endif'
    if text.count(old) != 1:
        raise ValueError('Pinned Munt exponent calculation changed')
    path.write_text(text.replace(old, '// capcom adapter (2026-10-24): identical accepted lookup-table rounding on every host.\n\treturn exp2f(x);'))

def munt_sequence_adapter(src):
    """Preserve Darwin's amplitude/pitch/cutoff update order on every compiler."""
    path = src / 'mt32emu/src/Partial.cpp'
    text = path.read_text()
    for role, base in (('MASTER', ''), ('SLAVE', 'pair->')):
        old = f'la32PairImpl->generateNextSample(LA32PartialPair::{role}, {base}getAmpValue(), {base}tvp->nextPitch(), {base}getCutoffValue());'
        if text.count(old) != 1:
            raise ValueError('Pinned Munt partial call site changed')
        new = f'// capcom adapter (2026-10-24): pitch updates amplitude state; sequence explicitly.\n        const Bit32u amp{role} = {base}getAmpValue();\n        const Bit16u pitch{role} = {base}tvp->nextPitch();\n        const Bit32u cutoff{role} = {base}getCutoffValue();\n        la32PairImpl->generateNextSample(LA32PartialPair::{role}, amp{role}, pitch{role}, cutoff{role});'
        text = text.replace(old, new)
    path.write_text(text)

def munt_dependencies(a):
    """Build the renderer's GLib dependency statically for the selected host."""
    pins = a.source_pins
    prefix = a.root / 'munt-dependencies'
    prefix.mkdir()
    env = dict(os.environ, PATH=str(Path(sys.executable).parent) + os.pathsep + os.environ.get('PATH', ''), PKG_CONFIG_LIBDIR=str(prefix / 'lib/pkgconfig'), PKG_CONFIG_PATH=str(prefix / 'lib/pkgconfig'))
    ffi = source('libffi', a, pins)
    args = ['--prefix=' + str(prefix), '--disable-shared', '--enable-static', '--disable-docs', '--disable-multi-os-directory']
    cc, cxx, ar, strip = ('cc', 'c++', 'ar', 'strip')
    cargs = []
    system = 'darwin' if a.host.startswith('macos') else 'linux'
    cpu = 'aarch64' if a.host.endswith('arm64') else 'x86_64'
    if a.host.startswith('macos'):
        cargs = ['-arch', 'arm64' if cpu == 'aarch64' else cpu, '-mmacosx-version-min=11.0']
        env.update(CC='clang', CXX='clang++', CFLAGS=' '.join(cargs), LDFLAGS=' '.join(cargs))
        cc, cxx = ('clang', 'clang++')
        if cpu == 'x86_64' and platform.machine() != 'x86_64':
            args += ['--host=x86_64-apple-darwin']
    elif a.host == 'windows-x86_64':
        system = 'windows'
        cc, cxx, ar, strip = ['x86_64-w64-mingw32-' + t for t in ('gcc', 'g++', 'ar', 'strip')]
        args += ['--host=x86_64-w64-mingw32']
        env.update(CC=cc, CXX=cxx, AR=ar, RANLIB='x86_64-w64-mingw32-ranlib')
    elif cpu == 'x86_64' and platform.machine() != 'x86_64':
        cc, cxx, ar, strip = ['x86_64-linux-gnu-' + t for t in ('gcc', 'g++', 'ar', 'strip')]
        args += ['--host=x86_64-linux-gnu']
        env.update(CC=cc, CXX=cxx, AR=ar)
    ffi_build = a.root / 'libffi/build'
    ffi_build.mkdir()
    run([ffi / 'configure', *args], cwd=ffi_build, env=env)
    run(['make', '-j' + str(a.jobs), 'install'], cwd=ffi_build, env=env)
    pcre = source('pcre2', a, pins)
    cmake('pcre2', pcre, a, ['install'], ['-DCMAKE_INSTALL_PREFIX=' + str(prefix), '-DCMAKE_INSTALL_LIBDIR=lib', '-DBUILD_SHARED_LIBS=OFF', '-DPCRE2_BUILD_TESTS=OFF', '-DPCRE2_BUILD_PCRE2GREP=OFF', '-DPCRE2_BUILD_PCRE2_8=ON', '-DPCRE2_BUILD_PCRE2_16=OFF', '-DPCRE2_BUILD_PCRE2_32=OFF', '-DPCRE2_SUPPORT_JIT=OFF'])
    zlib = source('zlib', a, pins)
    zb = cmake('zlib', zlib, a, ['zlibstatic'], ['-DCMAKE_INSTALL_PREFIX=' + str(prefix), '-DCMAKE_INSTALL_LIBDIR=lib', '-DBUILD_SHARED_LIBS=OFF', '-DZLIB_BUILD_EXAMPLES=OFF'])
    static = [p for p in zb.iterdir() if p.name in ('libz.a', 'libzlibstatic.a')]
    if len(static) != 1:
        raise ValueError('Missing static zlib')
    (prefix / 'include').mkdir(exist_ok=True)
    shutil.copyfile(static[0], prefix / 'lib/libz.a')
    shutil.copyfile(zlib / 'zlib.h', prefix / 'include/zlib.h')
    shutil.copyfile(zb / 'zconf.h', prefix / 'include/zconf.h')
    (prefix / 'lib/pkgconfig/zlib.pc').write_text('prefix=' + str(prefix) + '\nlibdir=${prefix}/lib\nincludedir=${prefix}/include\nName: zlib\nDescription: pinned static zlib\n' + 'Version: 1.3.1\nLibs: -L${libdir} -lz\nCflags: -I${includedir}\n')
    glib = source('glib', a, pins)
    intl = source('proxy-libintl', a, pins)
    shutil.copytree(intl, glib / 'subprojects/proxy-libintl')
    glib_build = a.root / 'glib/build'
    machine = a.root / 'glib/machine.ini'
    resource = "windres = 'x86_64-w64-mingw32-windres'\n" if system == 'windows' else ''
    wrapper = ''
    if system == 'darwin' and cpu == 'x86_64' and (platform.machine() != 'x86_64'):
        wrapper = "exe_wrapper = ['arch', '-x86_64']\n"
    elif system == 'linux' and cpu == 'x86_64' and (platform.machine() != 'x86_64'):
        wrapper = "exe_wrapper = ['env', 'LD_LIBRARY_PATH=/usr/x86_64-linux-gnu/lib']\n"
    machine.write_text('[binaries]\nc = ' + repr(cc) + '\ncpp = ' + repr(cxx) + '\nobjc = ' + repr(cc) + '\nar = ' + repr(ar) + '\nstrip = ' + repr(strip) + "\npkg-config = 'pkg-config'\n" + resource + wrapper + '[host_machine]\nsystem = ' + repr(system) + '\ncpu_family = ' + repr(cpu) + '\ncpu = ' + repr(cpu) + "\nendian = 'little'\n" + '[properties]\nneeds_exe_wrapper = ' + ('true' if system == 'windows' or wrapper else 'false') + '\n[built-in options]\n' + 'c_args = ' + repr(cargs) + '\nc_link_args = ' + repr(cargs) + '\ncpp_args = ' + repr(cargs) + '\ncpp_link_args = ' + repr(cargs) + '\nobjc_args = ' + repr(cargs) + '\nobjc_link_args = ' + repr(cargs) + '\n')
    run([sys.executable, '-m', 'mesonbuild.mesonmain', 'setup', glib_build, glib, '--cross-file', machine, '--prefix', prefix, '--libdir', 'lib', '--buildtype', 'release', '--default-library', 'static', '--wrap-mode', 'nodownload', '-Dtests=false', '-Dinstalled_tests=false', '-Dintrospection=disabled', '-Dnls=disabled', '-Dlibmount=disabled', '-Dselinux=disabled', '-Dlibelf=disabled', '-Dxattr=false', '-Dman-pages=disabled', '-Dglib_debug=disabled'], env=env)
    run(['ninja', '-C', glib_build, '-j' + str(a.jobs), 'install'], env=env)
    libs = subprocess.check_output(['pkg-config', '--libs', '--static', 'glib-2.0'], env=env, text=True)
    includes = [prefix / 'include/glib-2.0', prefix / 'lib/glib-2.0/include']
    dependencies = []
    tokens = iter(shlex.split(libs))
    for token in tokens:
        if token == '-framework':
            dependencies.append('/System/Library/Frameworks/' + next(tokens) + '.framework')
        elif token == '-lglib-2.0' or token.startswith('-L'):
            continue
        elif token.startswith('-l') and (prefix / 'lib' / ('lib' + token[2:] + '.a')).is_file():
            dependencies.append(str(prefix / 'lib' / ('lib' + token[2:] + '.a')))
        else:
            dependencies.append(token)
    return (prefix, includes, dependencies)

def adlmidi_timing_adapter(src):
    """Preserve the established Darwin sample carry on every renderer host."""
    path = src / 'src/adlmidi.cpp'
    text = path.read_text()
    old = 'setup.carry += double(setup.PCM_RATE) * eat_delay;'
    if text.count(old) != 2:
        raise ValueError('Pinned ADLMIDI sample-carry sites changed')
    text = text.replace(old, 'setup.carry = ::fma(double(setup.PCM_RATE), eat_delay, setup.carry);')
    path.write_text('/* Portability adapter added 2026-10-24: preserve Darwin fused sample-carry timing. */\n' + text)

def build(name, src, a):
    exe = '.exe' if a.host.startswith('windows-') else ''
    if name == 'chdman':
        sdl_prefix = None
        if a.host.startswith('linux-'):
            sdl = source('sdl2', a, a.source_pins)
            sdl_prefix = a.root / 'chdman-sdl2'
            options = ['-DCMAKE_INSTALL_PREFIX=' + str(sdl_prefix), '-DCMAKE_INSTALL_LIBDIR=lib', '-DSDL_SHARED=OFF', '-DSDL_STATIC=ON', '-DSDL_TEST=OFF', '-DSDL_TESTS=OFF', '-DSDL_INSTALL_TESTS=OFF', '-DSDL_VIDEO=ON', '-DSDL_DUMMYVIDEO=ON', '-DSDL_OFFSCREEN=OFF', '-DSDL_VULKAN=OFF']
            options += ['-DSDL_' + feature + '=OFF' for feature in ('AUDIO', 'RENDER', 'JOYSTICK', 'HAPTIC', 'HIDAPI', 'SENSOR', 'DBUS', 'IBUS', 'ALSA', 'PULSEAUDIO', 'PIPEWIRE', 'JACK', 'X11', 'WAYLAND', 'KMSDRM', 'OPENGL', 'OPENGLES', 'LIBUDEV')]
            cmake('sdl2', sdl, a, ['install'], options)
        host_os = 'darwin' if platform.system() == 'Darwin' else 'linux'
        run(['make', '-C', src / ('3rdparty/genie/build/gmake.' + host_os), '-f', 'genie.make', '-j' + str(a.jobs)])
        args = ['make', '-j' + str(a.jobs), 'TOOLS=1', 'EMULATOR=0', 'PTR64=1', 'NOWERROR=1', 'SYMBOLS=0', 'OPTIMIZE=2', 'USE_QTDEBUG=0', 'NO_OPENGL=1', 'MAKEPARAMS=chdman', 'PYTHON_EXECUTABLE=' + sys.executable, 'NEW_GIT_VERSION=mame0288']
        env = dict(os.environ)
        if a.host.startswith('macos-'):
            arch = 'arm64' if a.host.endswith('arm64') else 'x86_64'
            args += ['TARGETOS=macosx', 'PLATFORM=' + ('arm64' if arch == 'arm64' else 'x86'), 'ARCHOPTS=-arch ' + arch + ' -mmacosx-version-min=11.0', 'LIBS=$(LDDEPS) -framework Cocoa -framework Carbon -lpthread -lm']
        elif exe:
            args += ['TARGETOS=windows', 'PLATFORM=x86', 'OSD=windows', 'TOOLCHAIN=x86_64-w64-mingw32-', 'MINGW64=1']
        else:
            args += ['TARGETOS=linux', 'PLATFORM=' + ('arm64' if a.host.endswith('arm64') else 'x86'), 'SDL_INSTALL_ROOT=' + str(sdl_prefix), 'ARCHOPTS=-I' + str(sdl_prefix / 'include'), 'LIBS=$(LDDEPS) ' + str(sdl_prefix / 'lib/libSDL2.a') + ' -lpthread -ldl -lm -lutil']
            if a.host == 'linux-x86_64' and platform.machine() != 'x86_64':
                args += ['OVERRIDE_CC=x86_64-linux-gnu-gcc', 'OVERRIDE_CXX=x86_64-linux-gnu-g++', 'OVERRIDE_LD=x86_64-linux-gnu-g++', 'OVERRIDE_AR=x86_64-linux-gnu-ar']
        run(args, cwd=src, env=env)
        return {'chdman': src / ('chdman' + exe)}
    if name == 'extractors':
        b = cmake(name, src, a, ['x68k_sps_dec'])
        return {'x68k_sps_dec': b / ('x68k_sps_dec' + exe)}
    if name == 'converters':
        p = custom(name, 'cmake_minimum_required(VERSION 3.10)\nproject(midi C)\nset(CMAKE_C_STANDARD 99)\nadd_executable(m2seq22mid "' + (src / 'm2seq22mid.c').as_posix() + '")\n', a)
        b = cmake(name, p, a, ['m2seq22mid'])
        return {'m2seq22mid': b / ('m2seq22mid' + exe)}
    if name == 'sc55':
        p = custom(name, 'cmake_minimum_required(VERSION 3.23)\nproject(nuked_helpers VERSION 0.5.6 LANGUAGES CXX)\nset(CMAKE_CXX_STANDARD 23)\nset(NUKED_SOURCE "JohnMama12/Nuked-SC55-GUI-Float@4b639496f7fa")\nset(SRC "' + src.as_posix() + '")\nconfigure_file("${SRC}/src/backend/config.h.in" backend/config.h @ONLY)\nfile(GLOB BACKEND "${SRC}/src/backend/*.cpp")\nadd_executable(nuked-sc55-render ${BACKEND}\n "${SRC}/src/renderer/main.cpp" "${SRC}/src/renderer/smf.cpp" "${SRC}/src/renderer/wav.cpp")\ntarget_include_directories(nuked-sc55-render PRIVATE "${SRC}/src/backend" "${CMAKE_CURRENT_BINARY_DIR}/backend")\n', a)
        b = cmake(name, p, a, ['nuked-sc55-render'])
        return {'sc55': b / ('nuked-sc55-render' + exe)}
    if name == 'adlmidi':
        adlmidi_timing_adapter(src)
        options = ['-DlibADLMIDI_STATIC=OFF', '-DlibADLMIDI_SHARED=ON', '-DUSE_NUKED_EMULATOR=ON', '-DWITH_MIDIPLAY=OFF', '-DWITH_HQ_RESAMPLER=OFF']
        options += ['-DUSE_' + core + '_EMULATOR=OFF' for core in ('DOSBOX', 'OPAL', 'JAVA', 'ESFMU', 'MAME', 'YMFM')]
        b = cmake(name, src, a, ['ADLMIDI_shared'], options)
        suffix = '.dll' if exe else '.dylib' if a.host.startswith('macos') else '.so'
        found = sorted({p.resolve() for p in b.rglob('*ADLMIDI*' + suffix) if p.is_file()})
        if len(found) != 1:
            raise ValueError('Missing or ambiguous ADLMIDI shared library')
        return {'adlmidi': found[0]}
    if name == 'munt':
        prefix, includes, deps = munt_dependencies(a)
        p = custom(name, 'cmake_minimum_required(VERSION 3.10)\nproject(munt_helper C CXX)\n' + 'add_library(GLib2::glib2 STATIC IMPORTED GLOBAL)\n' + 'set_target_properties(GLib2::glib2 PROPERTIES\n IMPORTED_LOCATION "' + (prefix / 'lib/libglib-2.0.a').as_posix() + '"\n INTERFACE_INCLUDE_DIRECTORIES "' + ';'.join(map(str, includes)) + '"\n INTERFACE_LINK_LIBRARIES "' + ';'.join(deps) + '")\nset(GLIB2_VERSION 2.80.5)\n' + 'add_subdirectory("' + src.as_posix() + '" munt)\n', a)
        munt_rng_adapter(src, p)
        munt_filter_adapter(src)
        munt_math_adapter(src)
        munt_sequence_adapter(src)
        b = cmake(name, p, a, ['mt32emu-smf2wav'], ['-DBUILD_SHARED_LIBS=OFF', '-Dmunt_WITH_MT32EMU_SMF2WAV=ON', '-Dmunt_WITH_MT32EMU_QT=OFF'])
        return {'mt32': b / 'munt/mt32emu_smf2wav' / ('mt32emu-smf2wav' + exe)}
    if name == 'sevenzip':
        cwd = src / 'CPP/7zip/Bundles/Alone7z'
        args = ['make', '-f', 'makefile.gcc', '-j' + str(a.jobs)]
        if a.host.startswith('macos-'):
            arch = 'arm64' if a.host.endswith('arm64') else 'x86_64'
            args += ['CC=clang -arch ' + arch, 'CXX=clang++ -arch ' + arch, 'USE_ASM=']
        elif exe:
            args += ['CC=x86_64-w64-mingw32-gcc', 'CXX=x86_64-w64-mingw32-g++', 'RC=x86_64-w64-mingw32-windres', 'IS_MINGW=1', 'LDFLAGS_STATIC=-static -static-libgcc -static-libstdc++', 'USE_ASM=']
        elif a.host == 'linux-x86_64' and platform.machine() != 'x86_64':
            args += ['CC=x86_64-linux-gnu-gcc', 'CXX=x86_64-linux-gnu-g++', 'USE_ASM=']
        run(args, cwd=cwd)
        found = sorted((p for p in cwd.rglob('7zr*') if p.is_file() and p.suffix in ('', '.exe')))
        if len(found) != 1:
            raise ValueError('Missing or ambiguous 7zr binary')
        return {'sevenzip': found[0]}
    raise ValueError('Unimplemented producer: ' + name)

def package(name, src, bins, a, pin):
    stage = a.root / name / 'stage'
    (stage / 'bin').mkdir(parents=True)
    executables = {}
    runtime = {}
    for key, binary in bins.items():
        if not binary.is_file():
            raise ValueError('Missing built helper: ' + str(binary))
        if a.host.startswith('macos-'):
            load_commands = subprocess.check_output(['otool', '-l', binary], text=True)
            for path in re.findall('cmd LC_RPATH\\s+cmdsize \\d+\\s+path (.*?) \\(offset', load_commands):
                run(['install_name_tool', '-delete_rpath', path, binary])
            if binary.suffix == '.dylib':
                run(['install_name_tool', '-id', '@rpath/' + binary.name, binary])
            lines = subprocess.check_output(['otool', '-L', binary], text=True).splitlines()[1:]
            needed = [line.strip().split(' (', 1)[0] for line in lines]
            if binary.suffix == '.dylib':
                needed = needed[1:]
            if any((not path.startswith(('/System/Library/', '/usr/lib/')) for path in needed)):
                raise ValueError('Non-system macOS dependency: ' + repr(needed))
        elif a.host.startswith('windows-'):
            text = subprocess.check_output(['x86_64-w64-mingw32-objdump', '-p', binary], text=True)
            needed = re.findall('DLL Name: (\\S+)', text)
            allowed = {'kernel32.dll', 'msvcrt.dll', 'ucrtbase.dll', 'advapi32.dll', 'user32.dll', 'gdi32.dll', 'ole32.dll', 'oleaut32.dll', 'comctl32.dll', 'comdlg32.dll', 'shell32.dll', 'shlwapi.dll', 'ws2_32.dll', 'wsock32.dll', 'winmm.dll', 'version.dll', 'bcrypt.dll', 'crypt32.dll', 'ntdll.dll', 'setupapi.dll', 'uuid.dll', 'psapi.dll', 'userenv.dll', 'iphlpapi.dll', 'dnsapi.dll', 'secur32.dll'}
            if any((d.lower() not in allowed and (not d.lower().startswith('api-ms-win-')) for d in needed)):
                raise ValueError('Non-system Windows dependency: ' + repr(needed))
        else:
            text = subprocess.check_output(['readelf', '-d', binary], text=True)
            needed = re.findall('\\(NEEDED\\).*?\\[(.*?)\\]', text)
            allowed = {'libc.so.6', 'libm.so.6', 'libstdc++.so.6', 'libgcc_s.so.1', 'libpthread.so.0', 'libdl.so.2', 'libutil.so.1', 'ld-linux-aarch64.so.1', 'ld-linux-x86-64.so.2'}
            if set(needed) - allowed:
                raise ValueError('Non-system Linux dependency: ' + repr(needed))
        runtime[key] = needed
        relative = 'bin/' + binary.name
        shutil.copyfile(binary, stage / relative)
        executables[key] = relative
    license_sources = {name: src}
    dependency_pins = {}
    if name == 'munt':
        pins = a.source_pins
        for dep in ('glib', 'libffi', 'pcre2', 'proxy-libintl', 'zlib'):
            license_sources[dep] = next((a.root / dep / 'source').iterdir())
            dependency_pins[dep] = pins[dep]
    if name == 'chdman' and a.host.startswith('linux-'):
        license_sources['sdl2'] = next((a.root / 'sdl2/source').iterdir())
        dependency_pins['sdl2'] = a.source_pins['sdl2']
    for owner, tree in license_sources.items():
        for p in sorted(tree.rglob('*')):
            if p.is_file() and p.name.lower().startswith(('license', 'copying', 'notice', 'copyright', 'authors', 'patents')):
                dst = stage / 'licenses' / owner / p.relative_to(tree)
                dst.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(p, dst)
    if a.host.startswith('windows-'):
        shutil.copytree(HERE / 'licenses/gcc-runtime', stage / 'licenses/gcc-runtime')
        compiler = Path(shutil.which('x86_64-w64-mingw32-gcc')).resolve().parents[1]
        for p in compiler.rglob('*'):
            if p.is_file() and p.name in ('COPYING', 'COPYING3', 'COPYING.RUNTIME', 'COPYING.LIB', 'DISCLAIMER'):
                dst = stage / 'licenses/toolchain' / p.relative_to(compiler)
                dst.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(p, dst)
    recipe = stage / 'recipe'
    recipe.mkdir()
    (recipe / Path(__file__).name).write_bytes(RECIPE_BYTES)
    (recipe / 'optional_helpers_sources_v1.json').write_bytes(a.lock_bytes)
    shutil.copyfile(HERE / 'optional_producer_requirements.txt', recipe / 'optional_producer_requirements.txt')
    if a.host.startswith('windows-'):
        shutil.copytree(HERE / 'licenses/gcc-runtime', recipe / 'licenses/gcc-runtime')
    project = a.root / name / 'project/CMakeLists.txt'
    if project.exists():
        text = project.read_text().replace(str(src), '{SOURCE_ROOT}').replace(str(a.root), '{BUILD_ROOT}')
        (recipe / 'CMakeLists.txt').write_text(text)
    modifications = {}
    if name == 'munt':
        shutil.copyfile(a.root / 'munt/project/munt_rand.c', recipe / 'munt_rand.c')
        for filename in ('TVP.cpp', 'Analog.cpp', 'mmath.h', 'Partial.cpp'):
            relative = 'mt32emu/src/' + filename
            modified = recipe / 'modified-source' / relative
            modified.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(src / relative, modified)
            modifications[relative] = sha(modified.read_bytes())
        modifications['munt_rand.c'] = sha((recipe / 'munt_rand.c').read_bytes())
    if name == 'adlmidi':
        relative = 'src/adlmidi.cpp'
        modified = recipe / 'modified-source' / relative
        modified.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(src / relative, modified)
        modifications[relative] = sha(modified.read_bytes())
    metadata = dict(schema=1, component=name, host=a.host, source=pin, executables=executables, recipe_sha256=sha(RECIPE_BYTES), dependencies=dependency_pins, runtime_dependencies=runtime, modifications=modifications, source_policy='Munt preserves accepted Darwin jitter, exp2f lookup tables, ARM fused FIR rounding and amplitude/pitch evaluation order; complete modified source included' if name == 'munt' else 'ADLMIDI preserves accepted Darwin fused sample-carry timing; complete modified source included' if name == 'adlmidi' else 'unmodified upstream translation units; producer project included')
    (stage / 'BUILD.json').write_text(json.dumps(metadata, indent=2, sort_keys=True) + '\n')
    (stage / 'README.txt').write_text('Optional ' + name + ' helpers for ' + a.host + '. No games or instrument firmware.\nSee licenses/ for the exact component terms and recipe/ for the build.\nCorresponding upstream source archive: ' + pin['filename'] + '\n' + ('SC-55 uses the original MAME noncommercial license; it is not GPL.\n' if name == 'sc55' else '') + ('7zr supports .7z archives only. No RAR decoder is linked.\n' if name == 'sevenzip' else ''))
    filename = 'optional-' + name + '-v1-' + a.host + '.zip'
    archive = a.out / filename
    with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for p in sorted(stage.rglob('*')):
            if p.is_file():
                info = zipfile.ZipInfo(p.relative_to(stage).as_posix(), (2026, 10, 24, 0, 0, 0))
                info.external_attr = 33188 << 16
                info.compress_type = zipfile.ZIP_DEFLATED
                z.writestr(info, p.read_bytes())
    record = dict(filename=filename, sha256=sha(archive.read_bytes()), bytes=archive.stat().st_size, qualification='not-run', executables=executables, files={p.relative_to(stage).as_posix(): sha(p.read_bytes()) for p in sorted(stage.rglob('*')) if p.is_file()}, sources=metadata)
    (a.out / (name + '-record.json')).write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
    print('BUILT', name, a.host, record['sha256'], flush=True)

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--host', required=True, choices=HOSTS)
    p.add_argument('--only', action='append', required=True, choices=('extractors', 'converters', 'sc55', 'adlmidi', 'sevenzip', 'munt', 'chdman'))
    for name in ('root', 'out', 'sources'):
        p.add_argument('--' + name, type=Path, required=True)
    local_lock = HERE / 'optional_helpers_sources_v1.json'
    p.add_argument('--lock', type=Path, default=local_lock if local_lock.is_file() else HERE.parent / 'manifests/optional_helpers_sources_v1.json')
    p.add_argument('--jobs', type=int, default=4)
    a = p.parse_args()
    a.root = a.root.resolve()
    if a.root.exists() or a.out.exists():
        raise ValueError('Fresh build root and output required')
    a.root.mkdir(parents=True)
    a.out.mkdir(parents=True)
    os.environ['SOURCE_DATE_EPOCH'] = '1792828800'
    a.lock_bytes = a.lock.read_bytes()
    pins = a.source_pins = json.loads(a.lock_bytes)['sources']
    for name in a.only:
        source_name = 'mame' if name == 'chdman' else name
        src = source(source_name, a, pins)
        package(name, src, build(name, src, a), a, pins[source_name])
if __name__ == '__main__':
    main()
