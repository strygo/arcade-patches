"""Captain Commando arcade sound census, end to end, from nothing."""
from __future__ import annotations
import argparse
import concurrent.futures as cf
import csv
import hashlib
import json
import os
import subprocess
import sys
import wave
from pathlib import Path
import numpy as np
PKG = Path(__file__).resolve().parents[1]
REPO = PKG.parent
PY = sys.executable
OUT = PKG / 'manifests' / 'captcomm_arcade_census.json'
SETS = ('captcommu', 'captcommj')
MUSIC = range(128, 159)
ROMS = REPO / 'roms' / 'mame0260'
ENV = {**os.environ, 'SDL_VIDEODRIVER': 'dummy', 'SDL_AUDIODRIVER': 'dummy'}

def mame(machine: str, lua: Path, out: Path, env: dict, wav: bool=True, seconds: int | None=None, timeout: int=900) -> None:
    out.mkdir(parents=True, exist_ok=True)
    (out / 'cfg').mkdir(exist_ok=True)
    (out / 'nvram').mkdir(exist_ok=True)
    cmd = ['mame', machine, '-rompath', str(ROMS), '-autoboot_script', str(lua), '-video', 'none', '-nothrottle', '-cfg_directory', str(out / 'cfg'), '-nvram_directory', str(out / 'nvram')]
    cmd += ['-wavwrite', str(out / 'audio.wav')] if wav else ['-sound', 'none']
    if seconds:
        cmd += ['-seconds_to_run', str(seconds)]
    if seconds:
        timeout = min(timeout, 90 + 2 * seconds)
    for attempt in (1, 2):
        try:
            subprocess.run(cmd, env={**ENV, **env}, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=timeout, check=False)
            return
        except subprocess.TimeoutExpired:
            if wav and _wav_complete(out / 'audio.wav'):
                return
            if attempt == 2:
                raise

def _wav_complete(path: Path) -> bool:
    try:
        with wave.open(str(path)) as w:
            want = 44 + w.getnframes() * w.getnchannels() * w.getsampwidth()
            return w.getnframes() > 0 and path.stat().st_size >= want
    except (OSError, EOFError, wave.Error):
        return False

def inject(machine: str, out: Path, cmds: str | None, base=900, slot=700, swallow=True) -> Path:
    env = {'MI_SUBST': '1', 'MI_BASE': str(base), 'MI_SLOT': str(slot), 'MI_MARKERS': str(out / 'markers.tsv')}
    if swallow:
        env['MI_SWALLOW'] = '1'
    if cmds is None:
        env['MI_SILENCE'] = '1'
    else:
        env['MI_CMDS'] = cmds
    n = 1 if cmds is None else len(cmds.split(','))
    mame(machine, PKG / 'lua' / 'cps1_music_inject.lua', out, env, seconds=(base + n * slot) // 59 + 5)
    return out

def pcm(path: Path) -> tuple[np.ndarray, int]:
    with wave.open(str(path)) as w:
        x = np.frombuffer(w.readframes(w.getnframes()), '<i2')
        return (x.reshape(-1, w.getnchannels()).mean(1), w.getframerate())

def markers(out: Path) -> list[float]:
    return [float(r['seconds']) for r in csv.DictReader(open(out / 'markers.tsv'), delimiter='\t')]

def db(x: np.ndarray) -> float:
    return round(float(20 * np.log10(np.sqrt(np.mean(x.astype(float) ** 2)) / 32768 + 1e-12)), 1)

def silent(out: Path) -> dict:
    x, r = pcm(out / 'audio.wav')
    nz = np.nonzero(x)[0]
    return {'seconds': round(len(x) / r, 2), 'digital_silence': not len(nz), 'first_nonzero_s': round(nz[0] / r, 2) if len(nz) else None}

def step_controls(work: Path, machine: str) -> dict:
    d = work / 'controls' / machine
    quiet = silent(inject(machine, d / 'silence', None, swallow=False))
    held = silent(inject(machine, d / 'swallow_ff', 'ff', slot=5400))
    inject_s = 900 / 59.637405
    quiet['silent_before_injection'] = quiet['digital_silence'] or quiet['first_nonzero_s'] > inject_s
    assert quiet['silent_before_injection'], f'{machine}: attract sounds before the injection'
    assert held['digital_silence'], f'{machine}: swallowed idle run not silent'
    return {'sweep_window_no_injection': quiet, 'swallow_idle_105s': held}

def step_sweep(work: Path, machine: str) -> dict:
    d = work / 'sweep' / machine
    subprocess.run(['bash', str(PKG / 'scripts' / 'mi_sweep_all.sh'), machine, str(d)], env={**ENV, 'MI_SUBST': '1', 'MI_SWALLOW': '1'}, stdout=subprocess.DEVNULL, check=True)
    cls = work / 'sweep' / f'{machine}_class.json'
    subprocess.run([PY, str(PKG / 'tools' / 'sweep_classify.py'), str(d), '--out', str(cls)], stdout=subprocess.DEVNULL, check=True)
    return json.loads(cls.read_text())

def sweep_digest(work: Path, machine: str) -> str:
    h = hashlib.sha256()
    for i in range(256):
        x, _ = pcm(work / 'sweep' / machine / f'0x{i:02x}.wav')
        h.update(x.astype('<i2').tobytes())
    return h.hexdigest()

def step_stopbytes(work: Path) -> dict:
    d = work / 'stop'
    res = {}
    for b in range(240, 256):
        o = inject('captcommu', d / f'81_{b:02x}', f'81,{b:02x}', slot=300)
        x, r = pcm(o / 'audio.wav')
        t = markers(o)[1]
        after = x[int((t + 1) * r):]
        res[f'0x{b:02x}'] = {'before_db': db(x[int((t - 3) * r):int(t * r)]), 'after_db': db(after), 'stops_music': not after.any()}
    fx = {}
    for s in ('01', '20', '40', '5f'):
        ref, _ = pcm(inject('captcommu', d / f'fx{s}_ff', f'{s},ff', slot=12) / 'audio.wav')
        for b in ('f7', 'f0'):
            x, _ = pcm(inject('captcommu', d / f'fx{s}_{b}', f'{s},{b}', slot=12) / 'audio.wav')
            n = min(len(x), len(ref))
            fx[f'0x{s} then 0x{b}'] = int((x[:n] != ref[:n]).sum())
    restart = {}
    for name, cmds in (('81,f7,82', '81,f7,82'), ('81,f0,82', '81,f0,82')):
        o = inject('captcommu', d / name.replace(',', '_'), cmds, slot=300)
        x, r = pcm(o / 'audio.wav')
        ts = markers(o) + [len(x) / r]
        restart[name] = [db(x[int((ts[i] + 0.5) * r):int(ts[i + 1] * r)]) for i in range(3)]
    return {'stop_after_0x81': res, 'effect_samples_changed_vs_idle': fx, 'segment_db': restart}

def step_resend(work: Path) -> dict:
    """Re-sending the playing song: does the driver restart or continue?"""
    one = inject('captcommu', work / 'resend' / 'once', '81', slot=900)
    two = inject('captcommu', work / 'resend' / 'twice', '81,81', slot=300)
    y, r = pcm(one / 'audio.wav')
    x, _ = pcm(two / 'audio.wav')
    t0, t1 = markers(two)
    y0 = markers(one)[0]
    seg = x[int((t1 + 0.3) * r):int((t1 + 3.3) * r)]

    def best(off):
        s = int((y0 + off) * r)
        vals = []
        for k in range(-400, 401, 4):
            b = y[s + k:s + k + len(seg)]
            a, b = (seg - seg.mean(), b - b.mean())
            vals.append(float((a * b).sum() / np.sqrt((a * a).sum() * (b * b).sum())))
        return round(max(vals), 4)
    return {'ncc_vs_fresh_start': best(0.3), 'ncc_vs_continuing': best(t1 - t0 + 0.3)}

def step_join(work: Path, disc: Path) -> dict:
    cat = work / 'psx_catalog.json'
    xa = work / 'psx_xa'
    subprocess.run([PY, str(PKG / 'tools' / 'captcomm_psx_xa_catalog.py'), '--disc', str(disc), '--out', str(cat), '--wav-dir', str(xa)], stdout=subprocess.DEVNULL, check=True)
    c = json.loads(cat.read_text())
    a_dir, b_dir = (work / 'join' / 'arcade', work / 'join' / 'psx_original')
    a_dir.mkdir(parents=True, exist_ok=True)
    b_dir.mkdir(parents=True, exist_ok=True)
    pred = {}
    for m in c['music']:
        if m.get('unused'):
            continue
        pred[m['id']] = m['original']['wav']
        src = xa / m['original']['wav']
        (b_dir / src.name).write_bytes(src.read_bytes())

    def render(i):
        o = inject('captcommu', work / 'join' / 'long' / f'{i:02x}', f'{i:02x}', slot=7200)
        x, r = pcm(o / 'audio.wav')
        t = markers(o)[0]
        with wave.open(str(a_dir / f'0x{i:02x}.wav'), 'wb') as w:
            w.setnchannels(1)
            w.setsampwidth(2)
            w.setframerate(r)
            w.writeframes(x[int(t * r):].astype('<i2').tobytes())
    with cf.ThreadPoolExecutor(4) as ex:
        list(ex.map(render, MUSIC))
    mat = work / 'join' / 'matrix.tsv'
    subprocess.run([PY, str(PKG / 'tools' / 'xcorr_id.py'), '--a', str(a_dir / '*.wav'), '--b', str(b_dir / '*.wav'), '--out', str(mat), '--top', '28', '--speed-lo', '0.85', '--speed-hi', '1.18', '--speed-steps', '12'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=True)
    rows: dict[str, list] = {}
    for r in csv.DictReader(open(mat), delimiter='\t'):
        rows.setdefault(r['a'][:-4], []).append((float(r['env_r']), r['b'], float(r['speed'])))
    out = {}
    for a, lst in sorted(rows.items()):
        lst.sort(reverse=True)
        if a not in pred:
            out[a] = {'psx_row': None, 'best': lst[0][1], 'best_env_r': lst[0][0]}
            continue
        names = [b for _, b, _ in lst]
        mine = lst[names.index(pred[a])]
        other = next((x for x in lst if x[1] != pred[a]))
        out[a] = {'psx_original': pred[a], 'rank': names.index(pred[a]) + 1, 'env_r': mine[0], 'speed': mine[2], 'best_other': other[1], 'best_other_env_r': other[0]}
    return {'psx_catalog_image_sha256': c['disc']['image_sha256'], 'rows': out}

def step_route(work: Path, machine: str) -> dict:
    d = work / 'route' / machine
    d.mkdir(parents=True, exist_ok=True)
    mame(machine, PKG / 'lua' / 'captcomm_route.lua', d, {'CR_OUT': str(d.resolve()), 'CR_FRAMES': '330000', 'CR_SNAP_EVERY': '3600', 'CR_HANDS_OFF': '8f'}, wav=False, timeout=3000)
    rows = [r for r in csv.DictReader(open(d / 'route.tsv'), delimiter='\t')]
    log = hashlib.sha256((d / 'route.tsv').read_bytes()).hexdigest()
    hand = next((float(r['seconds']) for r in rows if r['cmd'] == 'hands_off'), None)
    seq, resend, cur = ([], [], None)

    def is_song(c):
        return c.startswith('0x') and 128 <= int(c, 16) <= 159 and (c not in ('0x90', '0x91', '0x92', '0x9f'))
    for i, r in enumerate(rows):
        c = r['cmd']
        if not is_song(c):
            continue
        if c == cur:
            resend.append({'seconds': float(r['seconds']), 'cmd': c, 'preceding': [x['cmd'] for x in rows[max(0, i - 3):i]]})
        elif not seq or seq[-1]['cmd'] != c:
            seq.append({'seconds': float(r['seconds']), 'cmd': c})
        cur = c
    after = [{'seconds': float(r['seconds']), 'cmd': r['cmd']} for r in rows if hand is not None and float(r['seconds']) >= hand and r['cmd'].startswith('0x') and (int(r['cmd'], 16) >= 240 or 128 <= int(r['cmd'], 16) <= 159)]
    fades = sorted({r['cmd'] for r in rows if r['cmd'].startswith('fade:')})
    return {'log_sha256': log, 'hands_off_s': hand, 'first_play_order': seq, 'resends_of_playing_song': resend, 'untouched_after_ending': after[:12], 'fade_latch_values': fades}

def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--disc', type=Path, required=True)
    ap.add_argument('--work', type=Path, required=True)
    ap.add_argument('--out', type=Path, default=OUT)
    a = ap.parse_args()
    if a.work.exists() and any(a.work.iterdir()):
        ap.error(f'{a.work} is not empty: the census runs from nothing')
    a.work.mkdir(parents=True, exist_ok=True)
    r: dict = {'schema': 1, 'sets': list(SETS), 'mame': subprocess.run(['mame', '-version'], capture_output=True, text=True).stdout.strip()}
    with cf.ThreadPoolExecutor(4) as ex:
        ctl = {m: ex.submit(step_controls, a.work, m) for m in SETS}
        sw = {m: ex.submit(step_sweep, a.work, m) for m in SETS}
        rt = {m: ex.submit(step_route, a.work, m) for m in SETS}
        r['controls'] = {m: f.result() for m, f in ctl.items()}
        r['sweep'] = {m: {'counts': f.result()['counts'], 'class': {k: v['class'] for k, v in f.result()['commands'].items()}} for m, f in sw.items()}
        dig = {m: sweep_digest(a.work, m) for m in SETS}
        r['sweep_pcm_sha256'] = dig
        r['regions_pcm_identical'] = len(set(dig.values())) == 1
        stop = ex.submit(step_stopbytes, a.work)
        res = ex.submit(step_resend, a.work)
        r['stop_bytes'] = stop.result()
        r['resend'] = res.result()
        r['join'] = step_join(a.work, a.disc)
        r['routes'] = {m: f.result() for m, f in rt.items()}
    a.out.write_text(json.dumps(r, indent=1) + '\n')
    print(f'wrote {a.out}')
    j = r['join']['rows']
    print('regions identical:', r['regions_pcm_identical'], '| join rank-1:', sum((1 for v in j.values() if v.get('rank') == 1)), '/', sum((1 for v in j.values() if v.get('psx_original'))))
    return 0
if __name__ == '__main__':
    sys.exit(main())
