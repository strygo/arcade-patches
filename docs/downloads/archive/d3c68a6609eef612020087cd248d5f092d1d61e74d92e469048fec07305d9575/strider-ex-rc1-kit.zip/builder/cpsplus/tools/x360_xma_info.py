"""Print format and loop fields of Xbox 360 RIFF XMA1 / XMA2 files as TSV."""
import os
import struct
import sys

def info(path):
    b = open(path, 'rb').read()
    if b[:4] != b'RIFF':
        return None
    i = b.find(b'fmt ')
    if i < 0:
        return None
    size = struct.unpack('<I', b[i + 4:i + 8])[0]
    f = b[i + 8:i + 8 + size]
    tag = struct.unpack('<H', f[:2])[0]
    if tag == 358 and size >= 52:
        ch, rate, bps = struct.unpack('<HII', f[2:12])
        _ns, _mask, se, _bpb, pb, pl, lb, ll, lc, _ev, _bc = struct.unpack('<HIIIIIIIBBH', f[18:52])
        return ['XMA2', ch, rate, '%.0f' % (bps * 8 / 1000), se, 'play=%d+%d loop=%d+%d count=%d' % (pb, pl, lb, ll, lc)]
    if tag == 357 and size >= 32:
        _bits, _enc, _skip, ns, lc, _ver = struct.unpack('<HHHHBB', f[2:12])
        pbps, rate, ls, le, _sub, ch, _mask = struct.unpack('<IIIIBBH', f[12:32])
        return ['XMA1', ch, rate, '%.0f' % (pbps * 8 / 1000), '-', 'streams=%d loop_start_bits=%d loop_end_bits=%d count=%d' % (ns, ls, le, lc)]
    return ['fmt %#x' % tag, '', '', '', '', '']

def main():
    if len(sys.argv) < 2:
        raise SystemExit(__doc__)
    paths = []
    for a in sys.argv[1:]:
        if os.path.isdir(a):
            paths += sorted((os.path.join(a, n) for n in os.listdir(a)))
        else:
            paths.append(a)
    print('name\tcodec\tch\trate\tkbps\tsamples\tloop')
    for p in paths:
        r = info(p)
        if r:
            print('\t'.join([os.path.basename(p)] + [str(x) for x in r]))
if __name__ == '__main__':
    main()
