"""Compare native OPL PCM from declared owned WOPL/MIDI inputs, before encoding."""
import argparse
import hashlib
import json
import os
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from render_dos_opl import render_native
from fetch_optional_tools import resolve

def main(a):
    library = a.library or resolve('adlmidi')
    pcm = render_native(library, a.bank, a.midi).astype('<i2').tobytes()
    if a.pcm:
        a.pcm.write_bytes(pcm)
    report = dict(pcm_sha256=hashlib.sha256(pcm).hexdigest(), bytes=len(pcm), library_sha256=hashlib.sha256(library.read_bytes()).hexdigest(), midi_sha256=hashlib.sha256(a.midi.read_bytes()).hexdigest(), bank_sha256=hashlib.sha256(a.bank.read_bytes()).hexdigest(), recipe_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
    if a.encode:
        from pack import adxcodec
        stream = adxcodec.encode(pcm, 2, 49716)
        report['adx_sha256'] = hashlib.sha256(stream).hexdigest()
        report['coefficients'] = adxcodec.calc_coeffs(500, 49716)
    a.out.write_text(json.dumps(report, indent=2) + '\n')
    print('OPL PCM', len(pcm), hashlib.sha256(pcm).hexdigest())
if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    for name in ('bank', 'midi', 'out'):
        p.add_argument('--' + name, type=Path, required=True)
    p.add_argument('--encode', action='store_true')
    p.add_argument('--library', type=Path)
    p.add_argument('--pcm', type=Path)
    main(p.parse_args())
