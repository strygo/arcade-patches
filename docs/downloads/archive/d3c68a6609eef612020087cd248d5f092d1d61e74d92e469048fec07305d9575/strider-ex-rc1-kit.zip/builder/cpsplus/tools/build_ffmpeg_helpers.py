"""Build LGPL FFmpeg/ffprobe from authenticated, unmodified source."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import tarfile
import urllib.request
import zipfile
HERE = Path(__file__).resolve().parent
PIN = HERE.parent / 'manifests/ffmpeg_source_v1.json'
if not PIN.is_file():
    PIN = HERE / 'ffmpeg_source_v1.json'
OPTIONS = ['--disable-autodetect', '--disable-asm', '--disable-inline-asm', '--disable-debug', '--disable-doc', '--disable-network', '--disable-shared', '--enable-static', '--disable-gpl', '--disable-nonfree', '--disable-version3', '--disable-programs', '--enable-ffmpeg', '--enable-ffprobe', '--disable-avdevice']

def sha(data):
    return hashlib.sha256(data).hexdigest()

def archive(tree, output):
    with zipfile.ZipFile(output, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for p in sorted(tree.rglob('*')):
            if not p.is_file():
                continue
            info = zipfile.ZipInfo(p.relative_to(tree).as_posix(), (2026, 10, 23, 0, 0, 0))
            info.create_system = 3
            info.external_attr = 33188 << 16
            info.compress_type = zipfile.ZIP_DEFLATED
            z.writestr(info, p.read_bytes(), compresslevel=9)

def run(a):
    if a.root.exists() or a.out.exists():
        raise ValueError('Fresh source/build and output directories required')
    pin = json.loads(PIN.read_text())
    a.root.mkdir(parents=True)
    source_tar = a.root / pin['source_filename']
    if a.source:
        shutil.copyfile(a.source, source_tar)
    else:
        with urllib.request.urlopen(pin['source_url'], timeout=60) as r:
            source_tar.write_bytes(r.read(pin['source_bytes'] + 1))
    if source_tar.stat().st_size != pin['source_bytes'] or sha(source_tar.read_bytes()) != pin['source_sha256']:
        raise ValueError('FFmpeg source archive identity differs')
    with tarfile.open(source_tar) as tar:
        for member in tar.getmembers():
            if not (member.isfile() or member.isdir()) or not (a.root / member.name).resolve().is_relative_to(a.root):
                raise ValueError('Unsafe FFmpeg source archive')
        tar.extractall(a.root, filter='data')
    source = a.root / ('ffmpeg-' + pin['version'])
    build = a.root / 'build'
    build.mkdir()
    flags = list(OPTIONS)
    arch = 'aarch64' if a.host.endswith('arm64') else 'x86_64'
    flags += ['--arch=' + arch]
    if a.host.startswith('macos-'):
        mac_arch = 'arm64' if arch == 'aarch64' else 'x86_64'
        flags += ['--target-os=darwin', '--enable-cross-compile', '--cc=clang', '--extra-cflags=-arch ' + mac_arch + ' -mmacosx-version-min=11.0', '--extra-ldflags=-arch ' + mac_arch + ' -mmacosx-version-min=11.0']
    elif a.host == 'windows-x86_64':
        flags += ['--target-os=mingw32', '--enable-cross-compile', '--cross-prefix=x86_64-w64-mingw32-', '--extra-ldflags=-static']
    elif a.host.startswith('linux-'):
        flags += ['--target-os=linux']
        if arch == 'x86_64' and platform.machine() not in ('x86_64', 'AMD64'):
            flags += ['--enable-cross-compile', '--cross-prefix=x86_64-linux-gnu-']
    else:
        raise ValueError('Unsupported producer host')
    env = dict(os.environ, SOURCE_DATE_EPOCH='1792713600')
    with (a.root / 'configure.log').open('w') as log:
        subprocess.run([str(source / 'configure'), *flags], cwd=build, env=env, stdout=log, stderr=subprocess.STDOUT, check=True)
    with (a.root / 'build.log').open('w') as log:
        suffix = '.exe' if a.host.startswith('windows-') else ''
        subprocess.run(['make', '-j' + str(a.jobs), 'ffmpeg' + suffix, 'ffprobe' + suffix], cwd=build, env=env, stdout=log, stderr=subprocess.STDOUT, check=True)
    a.out.mkdir(parents=True)
    stage = a.out / 'stage'
    (stage / 'bin').mkdir(parents=True)
    executables = {name: 'bin/' + name + ('.exe' if a.host.startswith('windows-') else '') for name in ('ffmpeg', 'ffprobe')}
    for name in executables.values():
        shutil.copyfile(build / Path(name).name, stage / name)
    licenses = stage / 'licenses'
    licenses.mkdir()
    for name in ('LICENSE.md', 'COPYING.LGPLv2.1', 'COPYING.LGPLv3', 'COPYING.GPLv2', 'COPYING.GPLv3'):
        shutil.copyfile(source / name, licenses / name)
    if a.host.startswith('windows-'):
        prefix = Path(shutil.which('x86_64-w64-mingw32-gcc')).resolve().parents[1]
        for p in sorted(prefix.rglob('*')):
            if p.is_file() and p.name in ('COPYING', 'COPYING3', 'COPYING.RUNTIME', 'COPYING.LIB', 'DISCLAIMER'):
                dest = licenses / 'toolchain' / p.relative_to(prefix)
                dest.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(p, dest)
        shutil.copytree(HERE / 'licenses/gcc-runtime', licenses / 'gcc-runtime')
    recipe = stage / 'recipe'
    recipe.mkdir()
    shutil.copyfile(Path(__file__), recipe / Path(__file__).name)
    shutil.copyfile(PIN, recipe / PIN.name)
    shutil.copytree(HERE / 'licenses/gcc-runtime', recipe / 'licenses/gcc-runtime')
    metadata = dict(schema=1, host=a.host, source=pin, configure=flags, binary_license='LGPL-2.1-or-later', source_modified=False, source_asset_url='https://github.com/strygo/arcade-patches/releases/download/ffmpeg-helpers-v1/' + pin['source_filename'], recipe_sha256={p.relative_to(recipe).as_posix(): sha(p.read_bytes()) for p in recipe.rglob('*') if p.is_file()})
    (stage / 'BUILD.json').write_text(json.dumps(metadata, indent=2, sort_keys=True) + '\n')
    (stage / 'README.txt').write_text('FFmpeg/ffprobe ' + pin['version'] + ' helpers for ' + a.host + '. LGPL 2.1 or later.\nNo GPL, nonfree, external codec libraries or networking are enabled.\nBuilt-in codecs, formats and filters are included for CPS+ and other kits.\nUnmodified corresponding source: ' + metadata['source_asset_url'] + '\nThe offline bundle also includes that exact source archive.\nSee BUILD.json for source digest, configuration and build recipe.\n')
    filename = 'ffmpeg-helpers-v1-' + a.host + '.zip'
    archive(stage, a.out / filename)
    data = (a.out / filename).read_bytes()
    record = dict(filename=filename, sha256=sha(data), bytes=len(data), sources=metadata, executables=executables, files={p.relative_to(stage).as_posix(): sha(p.read_bytes()) for p in stage.rglob('*') if p.is_file()})
    (a.out / 'record.json').write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
    print('PASS built FFmpeg:', a.host, record['sha256'], flush=True)
if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--host', required=True, choices=('macos-arm64', 'macos-x86_64', 'windows-x86_64', 'linux-arm64', 'linux-x86_64'))
    p.add_argument('--root', required=True, type=Path)
    p.add_argument('--out', required=True, type=Path)
    p.add_argument('--source', type=Path)
    p.add_argument('--jobs', type=int, default=4)
    a = p.parse_args()
    a.root = a.root.resolve()
    a.out = a.out.resolve()
    run(a)
