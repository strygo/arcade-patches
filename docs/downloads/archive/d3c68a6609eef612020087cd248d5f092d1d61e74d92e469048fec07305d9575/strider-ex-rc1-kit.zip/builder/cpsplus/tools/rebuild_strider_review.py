"""Rebuild the Strider soundtrack listening review from the source media."""
import argparse
import concurrent.futures as cf
import hashlib
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]
WORK = ROOT / 'cpsplus/work/strider'
CD_FULL = ROOT / 'cpsplus/work/listening/strider/cd_full'
PY = sys.executable
BIOS_SHA1 = '79f5ff55dd10187c7fd7b8daab0b3ffbd1f56a2c'
BIOS_NAME = '[cd] super cd-rom system (japan) (v3.0).pce'
CENSUS = list(range(30)) + [31, 32, 34]
REF_SECONDS, REF_GAP = (90, 2)
FPS = 59.637405

def run(cmd, log=None, **kw):
    print('+', ' '.join((str(c) for c in cmd)), flush=True)
    r = subprocess.run([str(c) for c in cmd], cwd=ROOT, capture_output=True, text=True, **kw)
    if log:
        Path(log).write_text(r.stdout + r.stderr)
    if r.returncode:
        sys.exit(f'failed ({r.returncode}): {cmd[:3]}\n{(r.stdout + r.stderr)[-2000:]}')
    return r.stdout

def sha(path, algo='sha256'):
    with open(path, 'rb') as f:
        return hashlib.file_digest(f, algo).hexdigest()

def sources():
    inputs = json.loads((ROOT / 'cpsplus/manifests/strider_source_inputs.json').read_text())
    paths = {}
    for rec in inputs:
        p = Path(rec['path']).expanduser()
        p = p if p.is_absolute() else ROOT / p
        if p.stat().st_size != rec['bytes'] or sha(p) != rec['sha256']:
            sys.exit(f'{p}: does not match strider_source_inputs.json')
        paths[p.name] = p
    src = WORK / 'sources'
    psx = src / 'psx'
    psx.mkdir(parents=True)
    run(['chdman', 'extractcd', '-i', paths['Strider (USA).chd'], '-o', psx / 'strider.cue', '-ob', psx / 'strider.bin'])
    pce = src / 'pce'
    run(['7zz', 'x', '-y', f'-o{pce}', paths['Strider Hiryuu (Japan).7z']])
    for name in ('striderua', 'striderjr'):
        d = src / 'arcade' / name
        run(['7zz', 'x', '-y', f'-o{d}', paths['strider.7z']])
        run(['7zz', 'x', '-y', f'-o{d}', paths[f'{name}.7z']])
    (src / 'arcade/sets.xml').write_text(run(['mame', '-listxml', 'striderua', 'striderjr']))
    run(['7zz', 'e', '-y', f"-o{src / 'vgm'}", paths['Strider_(Arcade).zip']])
    raw = (ROOT / 'roms/pce/syscard3.pce').read_bytes()
    bios = raw[512:] if len(raw) % 1024 == 512 else raw
    if hashlib.sha1(bios).hexdigest() != BIOS_SHA1:
        sys.exit('roms/pce/syscard3.pce is not the Super System Card 3.0')
    b = pce / 'bios/pce/acardpro'
    b.mkdir(parents=True)
    (b / BIOS_NAME).write_bytes(bios)
    CD_FULL.mkdir(parents=True)
    for bin_ in sorted(pce.glob('*(Track *).bin')):
        n = int(bin_.stem.split('Track ')[1].rstrip(')'))
        if n == 1 or 3 <= n <= 29:
            run(['ffmpeg', '-loglevel', 'error', '-f', 's16le', '-ar', '44100', '-ac', '2', '-i', bin_, CD_FULL / f'tr{n:02}.wav'])
    recheck = WORK / 'source_inventory_recheck.json'
    run([PY, 'cpsplus/tools/strider_source_inventory.py', '--output', recheck])
    want = json.loads((ROOT / 'cpsplus/manifests/strider_source_inventory.json').read_text())
    got = json.loads(recheck.read_text())
    for key in ('pce', 'vgm'):
        if [r.get('sha256') for r in got[key]] != [r.get('sha256') for r in want[key]]:
            sys.exit(f'rebuilt source inventory differs from the manifest ({key})')
    for g, w in zip(got['pce'], want['pce']):
        if g.get('wav_sha256') != w.get('wav_sha256'):
            sys.exit(f"PCE track {g['track']}: WAV differs from the manifest")

def emulator_jobs():
    jobs = {}
    ref = []
    start = 1120
    step = round((REF_SECONDS + REF_GAP) * FPS)
    for i, c in enumerate(CENSUS):
        f = start + i * step
        ref.append(f'{f}:0x{c:02x};{f + round(REF_SECONDS * FPS)}:0xf0')
    end = start + len(CENSUS) * step + 60
    arcade = [PY, 'cpsplus/tools/run_strider_arcade_probe.py', '--machine', 'striderua']
    jobs['census_taps'] = arcade + ['--mode', 'census', '--outdir', WORK / 'native/census_taps']
    jobs['reference_audio'] = arcade + ['--mode', 'custom', '--events', ';'.join(ref), '--captures', f'1050=quiet;{end}=end', '--outdir', WORK / 'native/reference_audio']
    tm = WORK / 'native/third_moon_control'
    tm.mkdir(parents=True)
    jobs['third_moon'] = ['env', 'STREX_STAGE=4', 'STREX_AREA=0', 'STREX_END=1520', 'STREX_SHOTS=1500', f"STREX_PREFIX={tm / 'tm'}", 'mame', 'striderua', '-rompath', WORK / 'sources/arcade', '-nothrottle', '-video', 'none', '-sound', 'none', '-skip_gameinfo', '-noautosave', '-cfg_directory', tm / 'cfg', '-nvram_directory', tm / 'nv', '-snapshot_directory', tm, '-autoboot_script', ROOT / 'backports/striderex/lua/arcade_debug_start.lua']
    jobs['psx_remix'] = [PY, 'cpsplus/tools/run_strider_console_probe.py', '--cdrom', ROOT / 'roms/psx/Strider (USA).chd', '--remix-census', '--timeout-seconds', '1800', '--outdir', WORK / 'psx/remix_clean_capture']
    usage = json.loads((ROOT / 'cpsplus/manifests/strider_pce_scene_usage.json').read_text())
    pce = WORK / 'sources/pce'
    for name, rec in usage['runs'].items():
        inv = rec['invocation']
        c = inv['command']
        arg = lambda flag: c[c.index(flag) + 1]
        cmd = [PY, 'cpsplus/tools/run_strider_console_probe.py', '--machine', 'pce', '--cdrom', pce / 'Strider Hiryuu (Japan).cue', '--cart', 'acardpro', '--rompath', pce / 'bios', '--schedule', arg('--schedule'), '--captures', arg('--captures'), '--timeout-seconds', '1800', '--outdir', WORK / 'pce' / name]
        if '--mame-arg=-log' in c:
            cmd.append('--log')
        if inv.get('pce_state'):
            cmd.append('--pce-state')
        if inv.get('pce_start_stage') is not None:
            cmd += ['--pce-start-stage', str(inv['pce_start_stage'])]
        if inv.get('pce_checkpoint_census'):
            cmd.append('--pce-checkpoint-census')
        if inv.get('pce_first_checkpoint') is not None:
            cmd += ['--pce-first-checkpoint', str(inv['pce_first_checkpoint'])]
        if inv.get('pce_phase'):
            cmd += ['--pce-phase', inv['pce_phase']]
        jobs['pce_' + name] = cmd
    return jobs

def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('--jobs', type=int, default=6)
    a = p.parse_args()
    for d in (WORK, CD_FULL):
        if d.exists():
            sys.exit(f'{d} exists: the rebuild needs a fresh tree (work trees are disposable)')
    if not os.path.realpath(ROOT / 'cpsplus/work').startswith('/Volumes/'):
        sys.exit('cpsplus/work is not on the configured scratch filesystem')
    sources()
    jobs = emulator_jobs()
    env = os.environ | dict(SDL_VIDEODRIVER='dummy', SDL_AUDIODRIVER='dummy')
    logs = WORK / 'rebuild_logs'
    logs.mkdir()
    with cf.ThreadPoolExecutor(a.jobs) as ex:
        futs = {ex.submit(run, cmd, logs / f'{name}.log', env=env): name for name, cmd in jobs.items()}
        for f in cf.as_completed(futs):
            f.result()
            print('done', futs[f], flush=True)
    run([PY, 'cpsplus/tools/strider_psx_xa_catalog.py', '--outdir', WORK / 'psx/xa_catalog', '--output', WORK / 'psx_xa_catalog_recheck.json'])
    env1 = os.environ | dict(OPENBLAS_NUM_THREADS='1')
    audio = WORK / 'review/audio_v2'
    run([PY, 'cpsplus/tools/strider_audio_candidates.py', '--outdir', audio, '--self-test'], env=env1)
    run([PY, 'cpsplus/tools/strider_audio_candidates.py', '--outdir', audio], env=env1)
    run([PY, 'cpsplus/tools/build_strider_research_review.py', '--outdir', WORK / 'review', '--audio-dir', audio], env=env1)
    print('review:', WORK / 'review/index.html')
    return 0
if __name__ == '__main__':
    sys.exit(main())
