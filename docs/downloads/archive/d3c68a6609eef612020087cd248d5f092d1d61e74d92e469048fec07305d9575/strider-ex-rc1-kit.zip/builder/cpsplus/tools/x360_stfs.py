"""Minimal Xbox 360 STFS (LIVE/PIRS/CON) package reader: list and extract files."""
import struct, sys, os

class STFS:

    def __init__(self, path):
        self.f = open(path, 'rb')
        d = self.f.read(38682)
        self.magic = d[:4]
        self.header_size = struct.unpack('>I', d[832:836])[0]
        self.content_type = struct.unpack('>I', d[836:840])[0]
        vd = d[889:889 + 36]
        self.block_sep = vd[2]
        self.ft_count = struct.unpack('<H', vd[3:5])[0]
        self.ft_block = int.from_bytes(vd[5:8], 'little')
        self.alloc = struct.unpack('>I', vd[28:32])[0]
        self.shift = 0 if self.block_sep & 1 else 1
        self.base = self.header_size + 4095 & ~4095
        self.title = d[5905:6033].decode('utf-16-be', errors='replace').strip('\x00')

    def backing(self, b):
        r = b
        if b >= 170:
            r += b // 170 + 1 << self.shift
        if b >= 28900:
            r += b // 28900 + 1 << self.shift
        return r

    def block_off(self, b):
        return self.base + 4096 + self.backing(b) * 4096

    def read_block(self, b):
        self.f.seek(self.block_off(b))
        return self.f.read(4096)

    def hash_entry(self, b):
        g = b // 170
        tab = self.base + (g * (170 + (1 << self.shift)) + 0) * 4096 if False else self.base + (g * 170 + (g << self.shift) + g * 0) * 4096
        tab = self.base + (g * 170 + (g << self.shift) + (g > 0 and 0 or 0)) * 4096
        tab = self.base + 4096 + (self.backing(g * 170) - 1) * 4096
        self.f.seek(tab + b % 170 * 24)
        e = self.f.read(24)
        return (e[20], int.from_bytes(e[21:24], 'big'))

    def entries(self):
        raw = b''.join((self.read_block(self.ft_block + i) for i in range(self.ft_count)))
        out = []
        for i in range(len(raw) // 64):
            e = raw[i * 64:(i + 1) * 64]
            if e[0] == 0:
                break
            nl = e[40] & 63
            name = e[:nl].decode('latin1')
            flags = e[40]
            nblocks = int.from_bytes(e[41:44], 'little')
            start = int.from_bytes(e[47:50], 'little')
            parent = struct.unpack('>h', e[50:52])[0]
            size = struct.unpack('>I', e[52:56])[0]
            out.append(dict(idx=i, name=name, dir=bool(flags & 128), consec=bool(flags & 64), blocks=nblocks, start=start, parent=parent, size=size))
        return out

    def path(self, ents, e):
        p = e['name']
        while e['parent'] != -1:
            e = ents[e['parent']]
            p = e['name'] + '/' + p
        return p

    def read_file(self, e):
        data = bytearray()
        b = e['start']
        n = e['blocks']
        for i in range(n):
            data += self.read_block(b)
            if e['consec']:
                b += 1
            else:
                st, nxt = self.hash_entry(b)
                b = nxt
        return bytes(data[:e['size']])
if __name__ == '__main__':
    s = STFS(sys.argv[1])
    ents = s.entries()
    print(f'{s.magic} header {s.header_size:#x} type {s.content_type:#x} sep {s.block_sep} shift {s.shift} base {s.base:#x} ft block {s.ft_block} x{s.ft_count} alloc {s.alloc} title {s.title!r}')
    for e in ents:
        print(f"{('d' if e['dir'] else 'f')}{('c' if e['consec'] else ' ')} {e['size']:12d} blk {e['start']:6d} x{e['blocks']:6d} {s.path(ents, e)}")
    if len(sys.argv) > 3:
        out = sys.argv[2]
        os.makedirs(out, exist_ok=True)
        for e in ents:
            if e['dir'] or not any((q in e['name'] for q in sys.argv[3:])):
                continue
            p = os.path.join(out, s.path(ents, e))
            os.makedirs(os.path.dirname(p), exist_ok=True)
            open(p, 'wb').write(s.read_file(e))
            print('wrote', p)
