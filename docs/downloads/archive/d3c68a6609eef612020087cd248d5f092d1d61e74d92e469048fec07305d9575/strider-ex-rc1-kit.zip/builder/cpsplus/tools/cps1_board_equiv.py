"""Does a pack's command map carry over to another CPS1 board?"""
from __future__ import annotations
import argparse
import array
import json
import math
import subprocess
import sys
import wave
from pathlib import Path
HERE = Path(__file__).resolve().parent
CPSPLUS = HERE.parent
SVC_ISOLATE = CPSPLUS / 'scripts' / 'svc_isolate.sh'
REFRESH = 59.637405
CONTROL = 'control'

def pack_commands(pack: str) -> list[int]:
    meta = json.loads((CPSPLUS / 'packs' / f'{pack}.cpk.json').read_text())
    return sorted((int(k, 16) for k, v in meta['triggers'].items() if v['verb'] == 'play'))

def run_sweep(machine: str, out: Path, cmds: list[int]) -> None:
    subprocess.run(['bash', str(SVC_ISOLATE), machine, str(out / machine / CONTROL), ''], check=True)
    subprocess.run(['bash', str(SVC_ISOLATE), machine, str(out / machine)] + [f'0x{c:02x}' for c in cmds], check=True)

def read_mono(path: Path) -> tuple[array.array, int]:
    with wave.open(str(path)) as w:
        if w.getsampwidth() != 2:
            raise SystemExit(f'{path}: expected 16-bit PCM')
        ch, rate = (w.getnchannels(), w.getframerate())
        pcm = array.array('h', w.readframes(w.getnframes()))
    return (pcm[::ch] if ch > 1 else pcm, rate)

def inject_frame(log: Path) -> int:
    rows = [r.split('\t') for r in log.read_text().splitlines()[1:] if r.strip()]
    if len(rows) != 1:
        raise SystemExit(f'{log}: expected one injection row, found {len(rows)}')
    return int(rows[0][1])

def window(pcm: array.array, rate: int, frame: int) -> array.array:
    return pcm[int(frame / REFRESH * rate):]

def envelope(pcm: array.array, block: int) -> list[float]:
    return [math.sqrt(sum((s * s for s in pcm[i:i + block])) / block) for i in range(0, len(pcm) - block + 1, block)]

def ncc(x: list[float], y: list[float], lag: int) -> float:
    if lag >= 0:
        a, b = (x[lag:], y)
    else:
        a, b = (x, y[-lag:])
    n = min(len(a), len(b))
    if n < 10:
        return 0.0
    a, b = (a[:n], b[:n])
    ma, mb = (sum(a) / n, sum(b) / n)
    num = sum(((p - ma) * (q - mb) for p, q in zip(a, b)))
    den = math.sqrt(sum(((p - ma) ** 2 for p in a)) * sum(((q - mb) ** 2 for q in b)))
    return num / den if den else 0.0

def exact_lag(a: array.array, b: array.array, max_lag: int) -> int | None:
    n = min(len(a), len(b)) - max_lag
    if n <= 0:
        return None
    ab, bb = (a.tobytes(), b.tobytes())
    for lag in sorted(range(-max_lag, max_lag + 1), key=abs):
        if lag >= 0 and ab[2 * lag:2 * (lag + n)] == bb[:2 * n]:
            return lag
        if lag < 0 and ab[:2 * n] == bb[-2 * lag:2 * (-lag + n)]:
            return lag
    return None

def compare(out: Path, a: str, b: str, cmds: list[int], max_lag_ms: float, min_ncc: float, stateful: set[int]) -> int:
    failures = 0
    for m in (a, b):
        log = out / m / CONTROL / '.tsv'
        wav = out / m / CONTROL / '.wav'
        pcm, rate = read_mono(wav)
        first = 1200 + 120
        peak = max(map(abs, window(pcm, rate, first)), default=0)
        ok = peak <= 1
        print(f"control {m}: peak {peak} after frame {first} -> {('silent' if ok else 'NOT SILENT (board not idle)')}")
        failures += not ok
        if log.exists() and log.read_text().count('\n') > 1:
            print(f'control {m}: log shows an injection')
            failures += 1
    if failures:
        return 2
    print('cmd\tverdict\tlag_ms\tncc\tpeak_a\tpeak_b')
    counts: dict[str, int] = {}
    for c in cmds:
        name = f'0x{c:02x}'
        wa, ra = read_mono(out / a / f'{name}.wav')
        wb, rb = read_mono(out / b / f'{name}.wav')
        if ra != rb:
            raise SystemExit(f'{name}: sample rates differ ({ra}, {rb})')
        xa = window(wa, ra, inject_frame(out / a / f'{name}.tsv'))
        xb = window(wb, rb, inject_frame(out / b / f'{name}.tsv'))
        pa, pb = (max(map(abs, xa), default=0), max(map(abs, xb), default=0))
        lag_ms, score = ('', '')
        if c in stateful:
            verdict = 'STATEFUL'
        elif pa <= 1 and pb <= 1:
            verdict = 'SILENT_BOTH'
        elif pa <= 1:
            verdict = 'ABSENT_A'
        else:
            verdict, lag_ms, score = verdict_for(xa, xb, ra, max_lag_ms, min_ncc)
        counts[verdict] = counts.get(verdict, 0) + 1
        print(f'{name}\t{verdict}\t{lag_ms}\t{score}\t{pa}\t{pb}')
    print('summary: ' + ', '.join((f'{k} {v}' for k, v in sorted(counts.items()))))
    return 1 if counts.get('DIFFER') else 0

def verdict_for(xa: array.array, xb: array.array, rate: int, max_lag_ms: float, min_ncc: float) -> tuple[str, str, str]:
    if (lag := exact_lag(xa, xb, int(max_lag_ms / 1000 * rate))) is not None:
        return ('IDENTICAL', f'{lag / rate * 1000:.2f}', '1.0000')
    block = rate // 100
    ea, eb = (envelope(xa, block), envelope(xb, block))
    span = int(max_lag_ms / 10)
    best = max(range(-span, span + 1), key=lambda l: ncc(ea, eb, l))
    r = ncc(ea, eb, best)
    return ('MATCH' if r >= min_ncc else 'DIFFER', f'{best * 10}', f'{r:.4f}')

def segment(spec_a: str, spec_b: str, seconds: float, max_lag_ms: float, min_ncc: float) -> int:
    parts = []
    for spec in (spec_a, spec_b):
        path, _, frame = spec.rpartition(':')
        pcm, rate = read_mono(Path(path))
        parts.append((window(pcm, rate, int(frame)), rate))
    (xa, ra), (xb, rb) = parts
    if ra != rb:
        raise SystemExit(f'sample rates differ ({ra}, {rb})')
    n = int(seconds * ra)
    xa, xb = (xa[:n], xb[:n])
    verdict, lag_ms, score = verdict_for(xa, xb, ra, max_lag_ms, min_ncc)
    print(f'segment {seconds:g}s: {verdict}  lag {lag_ms} ms  ncc {score}  peaks {max(map(abs, xa), default=0)} / {max(map(abs, xb), default=0)}')
    return 1 if verdict == 'DIFFER' else 0

def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__.split('\n\n')[0])
    ap.add_argument('--segment', nargs=2, metavar='WAV:FRAME', help='compare two recordings from the given frames')
    ap.add_argument('--seconds', type=float, default=60.0, help='--segment length')
    ap.add_argument('--pack', help='pack name in cpsplus/packs/')
    ap.add_argument('--a', help='board to qualify (MAME set)')
    ap.add_argument('--b', help='board the pack is mapped on')
    ap.add_argument('--out', type=Path, help='sweep directory (work/)')
    ap.add_argument('--run', action='store_true', help='render the sweep first')
    ap.add_argument('--max-lag-ms', type=float, default=250.0)
    ap.add_argument('--min-ncc', type=float, default=0.98)
    ap.add_argument('--stateful', action='append', default=[], metavar='CMD', help='command whose song depends on game state (repeatable)')
    a = ap.parse_args()
    if a.segment:
        return segment(*a.segment, a.seconds, a.max_lag_ms, a.min_ncc)
    if not (a.pack and a.a and a.b and a.out):
        ap.error('--pack, --a, --b and --out are required without --segment')
    cmds = pack_commands(a.pack)
    if a.run:
        for m in (a.a, a.b):
            run_sweep(m, a.out, cmds)
    return compare(a.out, a.a, a.b, cmds, a.max_lag_ms, a.min_ncc, {int(c, 16) for c in a.stateful})
if __name__ == '__main__':
    sys.exit(main())
