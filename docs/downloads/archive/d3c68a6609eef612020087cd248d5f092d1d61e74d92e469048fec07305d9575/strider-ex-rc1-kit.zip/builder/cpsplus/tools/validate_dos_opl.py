"""Check the two OPL decisions that an ear cannot settle."""
from __future__ import annotations
import argparse
import sys
from collections import Counter
from pathlib import Path
TOOLS = Path(__file__).resolve().parent
sys.path.insert(0, str(TOOLS))
import hmp as hmp_mod
from bnk2wopl import read_bnk
from hmp2smf import device_for
PERCUSSION_CHANNEL = 9
OPL3_VOICES = 18
GM_PERCUSSION = {36: ('kick', 'bd', 'bass'), 38: ('snare', 'sd'), 40: ('snare', 'sd'), 41: ('tom',), 45: ('tom',), 47: ('tom',), 48: ('tom',), 50: ('tom',), 42: ('clshat', 'closed', 'hat'), 44: ('clshat', 'closed', 'hat'), 46: ('opnhat', 'open', 'hat'), 49: ('crash',), 57: ('crash',), 51: ('ride',), 75: ('clave',)}

def drum_notes_played(midi_dir: Path) -> Counter:
    played: Counter = Counter()
    for path in sorted(midi_dir.iterdir()):
        if path.suffix.upper() != '.HMP' or device_for(path.stem) != 'none':
            continue
        song = hmp_mod.parse(path)
        for track in song.tracks:
            if track.channel != PERCUSSION_CHANNEL:
                continue
            for ev in track.events:
                if ev.status & 240 == 144 and ev.data[1] > 0:
                    played[ev.data[0]] += 1
    return played

def check_drum_map(midi_dir: Path, bank_path: Path) -> bool:
    drums = read_bnk(bank_path)
    non_blank = {i for i, patch in enumerate(drums) if not patch.blank}
    played = drum_notes_played(midi_dir)
    ok = True
    missing = sorted((n for n in played if n not in non_blank))
    print(f'drum coverage: {len(played) - len(missing)}/{len(played)} played notes land on a non-blank slot')
    if missing:
        ok = False
        print(f'  FAIL: notes with no patch: {missing}')
    print('drum naming agreement with the General Midi percussion map:')
    scores = {}
    for offset in (-2, -1, 0, 1, 2):
        agree = total = 0
        for note, fragments in GM_PERCUSSION.items():
            slot = note + offset
            if not 0 <= slot < len(drums):
                continue
            total += 1
            name = drums[slot].name.lower()
            if any((fragment in name for fragment in fragments)):
                agree += 1
        scores[offset] = (agree, total)
        mark = '  <- as shipped' if offset == 0 else ''
        print(f'  offset {offset:+d}: {agree:2d}/{total} names agree{mark}')
    best = max(scores, key=lambda o: scores[o][0])
    if best != 0:
        ok = False
        print(f'  FAIL: offset {best:+d} agrees better than the identity map')
    elif scores[0][0] < scores[0][1]:
        print(f'  identity wins; {scores[0][1] - scores[0][0]} name(s) unconfirmed but nothing contradicts it')
    return ok

def peak_polyphony(song: hmp_mod.HmpFile) -> int:
    events: list[tuple[int, int]] = []
    for track in song.tracks:
        for ev in track.events:
            family = ev.status & 240
            if family == 144 and ev.data[1] > 0:
                events.append((ev.tick, 1))
            elif family == 128 or (family == 144 and ev.data[1] == 0):
                events.append((ev.tick, -1))
    events.sort(key=lambda item: (item[0], item[1]))
    live = peak = 0
    for _, delta in events:
        live += delta
        peak = max(peak, live)
    return peak

def check_polyphony(midi_dir: Path) -> bool:
    peaks: list[tuple[int, str]] = []
    for path in sorted(midi_dir.iterdir()):
        if path.suffix.upper() != '.HMP' or device_for(path.stem) != 'none':
            continue
        peaks.append((peak_polyphony(hmp_mod.parse(path)), path.stem))
    peaks.sort(reverse=True)
    over = [(p, n) for p, n in peaks if p > OPL3_VOICES]
    print(f'\npolyphony against one OPL3 ({OPL3_VOICES} two-operator voices):')
    for peak, name in peaks[:3]:
        print(f'  busiest: {name:12s} {peak:2d} simultaneous notes')
    print(f'  {len(peaks)} songs, highest peak {peaks[0][0]}, {OPL3_VOICES - peaks[0][0]} voices of headroom')
    if over:
        print(f'  FAIL: {len(over)} song(s) exceed one chip: {[n for _, n in over[:5]]}')
        return False
    return True

def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('midi_dir', type=Path)
    ap.add_argument('--drum-bank', required=True, type=Path)
    a = ap.parse_args(argv)
    ok = check_drum_map(a.midi_dir, a.drum_bank)
    ok = check_polyphony(a.midi_dir) and ok
    print('\n' + ('PASS' if ok else 'FAIL'))
    return 0 if ok else 1
if __name__ == '__main__':
    sys.exit(main())
