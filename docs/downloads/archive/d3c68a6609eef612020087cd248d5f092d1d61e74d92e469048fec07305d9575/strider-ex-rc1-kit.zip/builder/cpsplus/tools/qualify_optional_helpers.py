"""Run the optional helper binaries and offline/cache contracts on one host."""
import argparse
import ctypes
import hashlib
import json
import os
from pathlib import Path
import platform
import shutil
import struct
import subprocess
import sys
import tarfile
import wave
from unittest.mock import patch
import fetch_optional_tools as optional
import fetch_switch_tools as common
HERE = Path(__file__).resolve().parent
RECIPE_SHA256 = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
SC55_EXPECTED = '502484a21adaa621ad97f641217789c8e50e2d0168e50870865e93f2c8e24871'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def run(command, *, cwd, output=None, allowed=(0,)):
    with output.open('wb') if output else open(os.devnull, 'wb') as dest:
        p = subprocess.run(list(map(str, command)), cwd=cwd, stdout=dest, stderr=subprocess.PIPE, timeout=600)
    if p.returncode not in allowed:
        raise ValueError('Helper failed: ' + str(command[0]) + '\n' + p.stderr.decode(errors='replace')[-2500:])

def midi(program=0):
    track = bytes.fromhex('00ff510307a12000c1') + bytes([program]) + bytes.fromhex('00913c648360813c008360ff2f00')
    return b'MThd' + struct.pack('>IHHH', 6, 0, 1, 480) + b'MTrk' + struct.pack('>I', len(track)) + track

def qualify(a):
    if a.work.exists():
        raise ValueError('Fresh qualification work required')
    a.work.mkdir(parents=True)
    lock_bytes = a.manifest.read_bytes()
    lock = json.loads(lock_bytes)
    host = a.host or common.host_id()
    if set(lock['components']) != set(optional.EXPECTED):
        raise ValueError('Incomplete qualification cohort')
    records = {name: item['platforms'][host] for name, item in lock['components'].items()}
    os.environ.update(CPSPLUS_SWITCH_TOOLS_CACHE=str(a.work / 'cache'), CPSPLUS_SWITCH_TOOLS_BUNDLE=str(a.archives), CPSPLUS_SWITCH_TOOLS_OFFLINE='1')
    for key in list(os.environ):
        if key in {'CPSPLUS_' + name.upper() for name in optional.COMPONENTS}:
            del os.environ[key]
    tools = {}
    with patch.object(common, 'download', side_effect=AssertionError('Offline network access')):
        for tool in optional.COMPONENTS:
            tools[tool] = optional.resolve(tool, manifest=a.manifest, host=host)
    installed = {p.name for p in (a.work / 'cache' / host).iterdir()}
    if installed != {record['sha256'] for record in records.values()}:
        raise ValueError('Unexpected component installation')
    del os.environ['CPSPLUS_SWITCH_TOOLS_BUNDLE']
    with patch.object(common, 'download', side_effect=AssertionError('Warm-cache network access')):
        for name, path in tools.items():
            if optional.resolve(name, manifest=a.manifest, host=host) != path:
                raise ValueError('Unstable cache identity')
    victim = tools['m2seq22mid']
    original = victim.read_bytes()
    victim.write_bytes(original + b'changed')
    try:
        optional.resolve('m2seq22mid', manifest=a.manifest, host=host)
    except ValueError:
        pass
    else:
        raise ValueError('Tampered helper was accepted')
    victim.write_bytes(original)
    os.environ['CPSPLUS_SWITCH_TOOLS_CACHE'] = str(a.work / 'empty-offline')
    try:
        optional.resolve('chdman', manifest=a.manifest, host=host)
    except ValueError:
        pass
    else:
        raise ValueError('Empty offline cache was accepted')
    os.environ.pop('CPSPLUS_SWITCH_TOOLS_OFFLINE', None)
    rec = records['chdman']
    requests = []

    def transport(url, size):
        if url != rec['url'] or size != rec['bytes'] or (not url.startswith('https://')):
            raise ValueError('Unpinned acquisition request')
        requests.append(url)
        return (a.archives / rec['filename']).read_bytes()
    with patch.object(common, 'download', side_effect=transport):
        optional.resolve('chdman', manifest=a.manifest, host=host)
    if requests != [rec['url']]:
        raise ValueError('Unexpected acquisition count')
    os.environ.update(CPSPLUS_SWITCH_TOOLS_OFFLINE='1', CPSPLUS_SWITCH_TOOLS_CACHE=str(a.work / 'cache'))
    for name in ('x68k_sps_dec', 'm2seq22mid'):
        run([tools[name]], cwd=a.work, allowed=(0, 1))
    track = bytes.fromhex('00ff510307a12000c1008170913c648360813c008360ff2f00')
    adl_midi = a.work / 'adlmidi.mid'
    adl_midi.write_bytes(b'MThd' + struct.pack('>IHHH', 6, 0, 1, 480) + b'MTrk' + struct.pack('>I', len(track)) + track)
    if a.library_probe:
        probe = subprocess.run([str(a.library_probe), str(tools['adlmidi']), str(adl_midi)], capture_output=True, timeout=60, check=True)
        adl_pcm = probe.stdout
        adl_version = probe.stderr.decode().strip()
    else:
        adl = ctypes.CDLL(str(tools['adlmidi']))
        adl.adl_linkedLibraryVersion.restype = ctypes.c_char_p
        adl.adl_init.argtypes = [ctypes.c_long]
        adl.adl_init.restype = ctypes.c_void_p
        adl.adl_close.argtypes = [ctypes.c_void_p]
        adl.adl_openFile.argtypes = [ctypes.c_void_p, ctypes.c_char_p]
        adl.adl_setBank.argtypes = [ctypes.c_void_p, ctypes.c_int]
        adl.adl_setLoopEnabled.argtypes = [ctypes.c_void_p, ctypes.c_int]
        adl.adl_play.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.POINTER(ctypes.c_short)]
        adl.adl_play.restype = ctypes.c_int
        device = adl.adl_init(49716)
        if not device:
            raise ValueError('ADLMIDI initialization failed')
        try:
            if adl.adl_setBank(device, 0) < 0 or adl.adl_openFile(device, str(adl_midi).encode()) < 0:
                raise ValueError('ADLMIDI synthetic note failed to load')
            adl.adl_setLoopEnabled(device, 0)
            buffer = (ctypes.c_short * 4096)()
            chunks = []
            while True:
                count = adl.adl_play(device, len(buffer), buffer)
                if count < 0:
                    raise ValueError('ADLMIDI render failed')
                if count == 0:
                    break
                chunks.append(bytes(buffer)[:count * 2])
            adl_pcm = b''.join(chunks)
        finally:
            adl.adl_close(device)
        adl_version = adl.adl_linkedLibraryVersion().decode()
        if os.name == 'nt':
            import _ctypes
            _ctypes.FreeLibrary(adl._handle)
            del adl
    if len(adl_pcm) < 2048 or not any(adl_pcm) or (not adl_version):
        raise ValueError('ADLMIDI synthetic note returned no audio')
    pins = json.loads(a.sources_lock.read_text())['sources']
    source = pins['sc55']
    archive = a.sources / source['filename']
    if sha(archive.read_bytes()) != source['sha256']:
        raise ValueError('Unpinned SC-55 fixture source')
    with tarfile.open(archive) as tar:
        names = [n for n in tar.getnames() if n.endswith('/test/integration/avmidi/01.mid')]
        if len(names) != 1:
            raise ValueError('Missing upstream MIDI fixture')
        sc55_midi = tar.extractfile(names[0]).read()
    (a.work / 'upstream.mid').write_bytes(sc55_midi)
    reference_bytes = (HERE.parent / 'manifests/optional_sc55_equivalence_20261024.json').read_bytes()
    native = json.loads(reference_bytes)
    firmware_names = ('sc55_rom1.bin', 'sc55_rom2.bin', 'sc55_waverom1.bin', 'sc55_waverom2.bin', 'sc55_waverom3.bin')
    roms = a.work / 'sc55-roms'
    roms.mkdir()
    actual_firmware = {}
    for name in firmware_names:
        data = (a.sc55_roms / name).read_bytes()
        actual_firmware[name] = sha(data)
        (roms / name).write_bytes(data)
    if native['source'] != source or native['firmware'] != actual_firmware or native['fixture_sha256'] != sha(sc55_midi) or (not native['same_cold']) or (not native['same_warm']) or (native['results']['original']['runs'][0]['pcm_sha256'] != SC55_EXPECTED):
        raise ValueError('Native SC-55 reference binding differs')
    raw = a.work / 'sc55.raw'
    run([tools['sc55'], '--stdout', a.work / 'upstream.mid', '--rom-directory', roms, '--romset', 'mk1', '--reset', 'gm'], cwd=a.work, output=raw)
    if sha(raw.read_bytes()) != SC55_EXPECTED:
        raise ValueError('SC-55 isolated native audio oracle differs: ' + sha(raw.read_bytes()))
    (a.work / 'synthetic.mid').write_bytes(midi())
    mt32_wav = a.work / 'mt32.wav'
    run([tools['mt32'], '--force', '--quiet', '--rom-dir=' + str(a.mt32_roms), '--machine-id=mt32_1_07', '--sample-rate=48000', '--src-quality=3', '--max-partials=32', '--analog-output-mode=2', '--renderer-type=0', '--output-sample-format=0', '--dac-input-mode=2', '--no-nice-amp-ramp', '--record-max-start-silence=-1', '--no-wait-for-la32', '--output=' + str(mt32_wav), a.work / 'synthetic.mid'], cwd=a.work)
    with wave.open(str(mt32_wav)) as wav:
        if (wav.getframerate(), wav.getnchannels(), wav.getsampwidth()) != (48000, 2, 2):
            raise ValueError('Unexpected Munt PCM format')
        mt32_pcm = wav.readframes(wav.getnframes())
    if not mt32_pcm or not any(mt32_pcm):
        raise ValueError('Synthetic Munt note produced no audio')
    (a.work / 'sequence.mid').write_bytes(midi(24))
    sequence_wav = a.work / 'sequence.wav'
    run([tools['mt32'], '--force', '--quiet', '--rom-dir=' + str(a.mt32_roms), '--machine-id=mt32_1_07', '--sample-rate=48000', '--src-quality=3', '--max-partials=32', '--analog-output-mode=2', '--renderer-type=0', '--output-sample-format=0', '--dac-input-mode=2', '--no-nice-amp-ramp', '--record-max-start-silence=-1', '--no-wait-for-la32', '--output=' + str(sequence_wav), a.work / 'sequence.mid'], cwd=a.work)
    with wave.open(str(sequence_wav)) as wav:
        sequence_pcm = wav.readframes(wav.getnframes())
    if sha(sequence_pcm) != 'b3b07dc153d992e8861cb77d40f5ecd9da38ae07aa355836422e6d297e145f10':
        raise ValueError('Munt amplitude/pitch sequencing regression')
    payload = bytes(range(256)) * 256
    (a.work / 'payload.bin').write_bytes(payload)
    run([tools['chdman'], 'createraw', '-i', 'payload.bin', '-o', 'fixture.chd', '-us', '512', '-hs', '4096', '-c', 'none'], cwd=a.work)
    run([tools['chdman'], 'verify', '-i', 'fixture.chd'], cwd=a.work)
    run([tools['chdman'], 'extractraw', '-i', 'fixture.chd', '-o', 'extracted.bin'], cwd=a.work)
    if (a.work / 'extracted.bin').read_bytes() != payload:
        raise ValueError('CHD raw extraction differs')
    run([tools['sevenzip'], 'a', '-t7z', '-mx=0', 'fixture.7z', 'payload.bin'], cwd=a.work)
    run([tools['sevenzip'], 'x', '-y', '-ounpacked', 'fixture.7z'], cwd=a.work)
    if (a.work / 'unpacked/payload.bin').read_bytes() != payload:
        raise ValueError('7zr extraction differs')
    outputs = dict(sc55_raw_sha256=SC55_EXPECTED, mt32_pcm_sha256=sha(mt32_pcm), mt32_sequence_pcm_sha256=sha(sequence_pcm), adlmidi_pcm_sha256=sha(adl_pcm), raw_fixture_sha256=sha(payload))
    if a.reference:
        reference = json.loads(a.reference.read_text())
        if reference['status'] != 'passed' or reference['outputs'] != outputs:
            raise ValueError('Cross-platform helper outputs differ: ' + json.dumps(dict(actual=outputs, expected=reference['outputs']), sort_keys=True))
    firmware = {}
    for label, folder, names in (('sc55', a.sc55_roms, ('sc55_rom1.bin', 'sc55_rom2.bin', 'sc55_waverom1.bin', 'sc55_waverom2.bin', 'sc55_waverom3.bin')), ('mt32', a.mt32_roms, ('mt32_ctrl_1_07.rom', 'mt32_pcm.rom'))):
        firmware[label] = {name: sha((folder / name).read_bytes()) for name in names}
    report = dict(schema=1, status='passed', host=host, platform=platform.platform(), python=sys.version, archives={n: r['sha256'] for n, r in records.items()}, manifest_sha256=sha(lock_bytes), outputs=outputs, firmware=firmware, sc55_reference_sha256=sha(reference_bytes), sc55_state='isolated cold SRAM', adlmidi_version=adl_version, library_probe_sha256=sha(a.library_probe.read_bytes()) if a.library_probe else None, reference_sha256=sha(a.reference.read_bytes()) if a.reference else None, acquisition='offline/cache plus injected HTTPS response; URLs not yet published', recipe_sha256=RECIPE_SHA256, checks=['per-component offline installation', 'warm cache', 'cache tampering', 'empty offline cache', 'pinned HTTPS dispatch fixture', 'extractor/converter startup', 'ADLMIDI synthetic sequencer/PCM', 'SC-55 upstream oracle', 'Munt synthetic note', 'CHD raw round trip', '7zr round trip'])
    a.out.parent.mkdir(parents=True, exist_ok=True)
    a.out.write_bytes((json.dumps(report, indent=2, sort_keys=True) + '\n').encode())
    shutil.rmtree(a.work)
    print('PASS optional helper runtime matrix:', host, flush=True)
if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    for name in ('manifest', 'archives', 'sources', 'sources-lock', 'sc55-roms', 'mt32-roms', 'work', 'out'):
        p.add_argument('--' + name, type=Path, required=True)
    p.add_argument('--host')
    p.add_argument('--reference', type=Path)
    p.add_argument('--library-probe', type=Path, help='matching-architecture probe built from qualify_adlmidi.c')
    a = p.parse_args()
    for name, value in vars(a).items():
        if isinstance(value, Path):
            setattr(a, name, value.absolute())
    qualify(a)
