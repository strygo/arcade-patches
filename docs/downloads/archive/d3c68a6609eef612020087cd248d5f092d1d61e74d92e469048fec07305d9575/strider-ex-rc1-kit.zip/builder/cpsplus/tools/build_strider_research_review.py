"""Build the local Strider source/mapping/loop listening page from research data."""
from __future__ import annotations
import argparse
import csv
import hashlib
import html
import json
from pathlib import Path
import shutil
import wave
import numpy as np
from scipy import signal
from strider_audio_candidates import ROOT, RATE, read_wav, write_wav, digest
PSX_TITLES = ['St. Petersburg — main', 'St. Petersburg — boss', 'Siberia — main', 'Siberia — boss', 'Aerial Battleship — main', 'Aerial Battleship — boss', 'Amazon — main', 'Amazon — boss', 'Third Moon — main', 'Grandmaster Meio']

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--work', type=Path, default=ROOT / 'cpsplus/work/strider')
    p.add_argument('--outdir', type=Path, required=True)
    p.add_argument('--audio-dir', type=Path, required=True)
    p.add_argument('--page-only', action='store_true', help='Refresh navigation and reference material without rebuilding candidate audio')
    a = p.parse_args()
    a.outdir.mkdir(parents=True, exist_ok=True)
    assert a.audio_dir.parent.resolve() == a.outdir.resolve()
    if a.page_only:
        data = json.loads((a.outdir / 'review_data.json').read_text())
        revision = hashlib.sha256((a.audio_dir / 'candidates.json').read_bytes()).hexdigest()[:12]
        assert data['audio_revision'] == revision, 'audio changed; rebuild the complete review'
        receipt = json.loads((a.outdir / 'receipt.json').read_text())
        assert receipt['audio_revision'] == revision
        assert receipt['map_sha256'] == digest(ROOT / 'cpsplus/manifests/strider_review_map.json'), 'mapping changed; rebuild the complete review'
        attach_scenes(a.outdir, data)
        attach_psx_comparisons(a.outdir, data)
        (a.outdir / 'review_data.json').write_text(json.dumps(data, indent=2, ensure_ascii=False) + '\n')
        write_page(a.outdir, data)
        receipt['review_sha256'] = digest(a.outdir / 'index.html')
        receipt['review_data_sha256'] = digest(a.outdir / 'review_data.json')
        receipt['scene_evidence_sha256'] = data['scene_evidence_sha256']
        receipt['psx_xa_catalog_sha256'] = data['psx_xa_catalog_sha256']
        (a.outdir / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
        print('Refreshed navigation/reference material; candidates and mapping unchanged:', a.outdir / 'index.html')
        return
    amap = json.loads((ROOT / 'cpsplus/manifests/strider_review_map.json').read_text())
    inv = json.loads((ROOT / 'cpsplus/manifests/strider_source_inventory.json').read_text())
    candidates = json.loads((a.audio_dir / 'candidates.json').read_text())
    titles = {}
    for line in (ROOT / 'cpsplus/manifests/strider_track_titles.tsv').read_text().splitlines():
        if line.startswith('pce\t'):
            _, tr, title, *_ = line.split('\t')
            titles[f'pce_{tr}'] = title
    refs = a.outdir / 'reference'
    refs.mkdir(exist_ok=True)
    reference_run = a.work / 'native/reference_audio'
    assert 'Average speed:' in (reference_run / 'run.log').read_text()
    event_rows = list(csv.DictReader((reference_run / 'events.tsv').open(), delimiter='\t'))
    events = {int(r['cmd']): float(r['time']) for r in event_rows if r['kind'] == 'inject' and int(r['cmd']) < 48}
    assert len(events) == 33
    identity = json.loads((ROOT / 'cpsplus/manifests/strider_arcade_identity.json').read_text())
    vgm_by_file = {r['file']: r for r in inv['vgm']}
    ref_info = []
    for row in identity['commands']:
        cmd = int(row['command'], 16)
        vgm = vgm_by_file[row['vgm']]
        duration = min(88.0, vgm['samples'] / 44100 + (15 if vgm['loop_samples'] else 1))
        t = events[cmd]
        x, rate = read_wav(reference_run / 'audio.wav', round(t * RATE), round(duration * RATE))
        assert rate == RATE
        path = refs / f'arc_{cmd:02x}.wav'
        write_wav(path, x)
        ref_info.append(dict(command=row['command'], file=str(path.relative_to(a.outdir)), sha256=digest(path), source_start_frame=round(t * RATE), frames=len(x), vgm=row['vgm']))
    for tr in [5, 6, 7, 10, 11, 21, 22, 23, 24, 25, 26, 27, 28, 29]:
        key = f'pce_{tr:02}'
        path = ROOT / f'cpsplus/work/listening/strider/cd_full/tr{tr:02}.wav'
        pinned = next((r for r in inv['pce'] if r['track'] == tr))
        assert digest(path) == pinned['wav_sha256']
        x, rate = read_wav(path)
        assert rate == 44100
        onset = int(np.flatnonzero(np.max(abs(x), axis=1) > 4 / 32768)[0])
        trim = max(0, onset - 441)
        y = signal.resample_poly(x[trim:], 160, 147, axis=0, window=('kaiser', 8.6))
        y = np.pad(y, ((0, -len(y) % 32), (0, 0)))
        path = a.audio_dir / f'{key}_source.wav'
        write_wav(path, y)
        candidates.append(dict(id=key, status='source_only' if any((r['track'] == key for r in amap['pce_source_only'])) else 'one_shot_candidate', rate=RATE, source_frames=len(y), loop_start=None, loop_end=None, source=dict(path=str((ROOT / f'cpsplus/work/listening/strider/cd_full/tr{tr:02}.wav').relative_to(ROOT)), sha256=pinned['wav_sha256'], source_trim_frames=trim), outputs=dict(source=dict(file=path.name, sha256=digest(path)))))
    scenes = json.loads((ROOT / 'cpsplus/manifests/strider_scene_windows.json').read_text())['rows']
    windows = {int(r['intro_command'], 16): (r['window_seconds'], int(r['next_command'], 16)) for r in scenes if r['machine'] == 'striderua'}
    by_id = {r['id']: r for r in candidates}
    by_cmd = {int(r['command'], 16): r for r in amap['rows']}

    def candidate_file(key):
        r = by_id[key]
        return a.audio_dir / r['outputs'].get('candidate', r['outputs']['source'])['file']
    for cmd, (secs, nextcmd) in windows.items():
        r = by_cmd[cmd]
        key = r['pce']['track']
        nextr = by_cmd[nextcmd]
        x, _ = read_wav(candidate_file(key))
        nextkey = nextr['pce']['track']
        if nextkey == key:
            continue
        y, _ = read_wav(candidate_file(nextkey) if nextkey else refs / f'arc_{nextcmd:02x}.wav')
        n = round(secs * RATE)
        prefix = x[:n]
        if len(prefix) < n:
            prefix = np.pad(prefix, ((0, n - len(prefix)), (0, 0)))
        clip = np.concatenate([prefix, y[:8 * RATE]])
        path = refs / f'pce_window_{cmd:02x}.wav'
        write_wav(path, clip)
        r['pce']['window_preview'] = str(path.relative_to(a.outdir))
        r['pce']['window_seconds'] = secs
        r['pce']['window_japan_seconds'] = next((s['window_seconds'] for s in scenes if s['machine'] == 'striderjr' and s['intro_command'] == r['command']))
    for r in candidates:
        key = r['id']
        edition = key[:3]
        r['title'] = titles[key] if edition == 'pce' else PSX_TITLES[int(key[-2:]) - 1]
        r['commands'] = [q['command'] for q in amap['rows'] if q[edition]['track'] == key]
        r['needs_close_review'] = r.get('needs_close_review', False)
        r['source_only_reason'] = next((q['reason'] for q in amap['pce_source_only'] if q['track'] == key), None)
        for out in r['outputs'].values():
            out['url'] = a.audio_dir.name + '/' + out['file']
    data = dict(map=amap, candidates=candidates, reference=ref_info, audio_revision=hashlib.sha256((a.audio_dir / 'candidates.json').read_bytes()).hexdigest()[:12])
    attach_scenes(a.outdir, data)
    attach_psx_comparisons(a.outdir, data)
    (a.outdir / 'review_data.json').write_text(json.dumps(data, indent=2, ensure_ascii=False) + '\n')
    write_page(a.outdir, data)
    receipt = dict(status='research_listening_pending', audio_revision=data['audio_revision'], review_sha256=digest(a.outdir / 'index.html'), map_sha256=digest(ROOT / 'cpsplus/manifests/strider_review_map.json'), review_data_sha256=digest(a.outdir / 'review_data.json'), scene_evidence_sha256=data['scene_evidence_sha256'], psx_xa_catalog_sha256=data['psx_xa_catalog_sha256'], native_capture_sha256=digest(reference_run / 'audio.wav'), references=ref_info)
    (a.outdir / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print('Built', a.outdir / 'index.html', '—', len(candidates), 'source entries,', len(amap['rows']), 'cue rows')
PAGE = (Path(__file__).parent / 'templates/strider_review.html').read_text()

def attach_psx_comparisons(outdir, data):
    path = ROOT / 'cpsplus/manifests/strider_psx_xa_catalog.json'
    catalog = json.loads(path.read_text())
    streams = {r['channel']: r for r in catalog['streams']}
    references = {r['command']: r for r in data['reference']}
    folder = outdir / 'psx_arcade'
    folder.mkdir(exist_ok=True)
    rows = []
    for title, command, channels, note in [('Game Over', '0x0e', [7, 8], 'The PSX mix with the laugh plays when you run out of lives, before Continue Play. USA and Japan arcade have the same scene: music 0x0e plus a separate laugh, 0x9b. The arcade button here contains only the music. The PSX out-of-lives recording already contains the laugh; using it as a replacement would require suppressing the native laugh for that event.'), ('Continue', '0x15', [9], 'The PSX recording closely matches the arcade music.'), ('Stage Clear', '0x0f', [10], 'The PSX recording closely matches the arcade music.'), ('Game Clear', '0x20', [11], 'The PSX recording closely matches the arcade music.'), ('Ending', '0x00', [12], 'The arcade ending command 0x21 shares the native 0x00 tune. This comparison uses that shared tune.'), ('Ranking', '0x22', [13], 'The PSX recording closely matches the arcade music.'), ('St. Petersburg intro', '0x11', [1], 'This is the arcade-style intro recording on the PSX disc. Sound Remix ON instead begins the arranged stage music during this scene.')]:
        reference = references[command]
        assert digest(outdir / reference['file']) == reference['sha256']
        choices = [dict(label='Arcade music only' if command == '0x0e' else 'Arcade', url=reference['file'], sha256=reference['sha256'], seconds=reference['frames'] / RATE)]
        for channel in channels:
            source = streams[channel]
            original = ROOT / source['pcm_file']
            assert digest(original) == source['pcm_sha256']
            target = folder / f'ch{channel:02}.wav'
            if not target.exists() or digest(target) != source['pcm_sha256']:
                shutil.copyfile(original, target)
            label = 'PSX out of lives (laugh)' if channel == 8 else 'PSX regular mix' if channel == 7 else 'PSX'
            choices.append(dict(label=label, url=str(target.relative_to(outdir)), sha256=source['pcm_sha256'], seconds=source['seconds'], xa_channel=channel))
        rows.append(dict(title=title, arcade_command=command, note=note, choices=choices))
    data['psx_arcade_comparisons'] = rows
    data['psx_xa_catalog_sha256'] = digest(path)

def attach_scenes(outdir, data):
    path = ROOT / 'cpsplus/manifests/strider_pce_scene_usage.json'
    evidence = json.loads(path.read_text())
    assert evidence['status'] == 'source_scene_routing_researched'
    scenes = outdir / 'scenes'
    scenes.mkdir(exist_ok=True)
    for track in evidence['tracks'].values():
        for shot in track['scenes']:
            original = ROOT / shot['file']
            assert digest(original) == shot['sha256']
            target = scenes / (shot['run'] + '_' + original.name)
            shutil.copyfile(original, target)
            shot['url'] = str(target.relative_to(outdir))
    control = ROOT / 'cpsplus/work/strider/native/third_moon_control/tm_01500.png'
    target = scenes / 'arcade_third_moon_dialogue.png'
    shutil.copyfile(control, target)
    data['arcade_scene_controls'] = {'pce_28': dict(url=str(target.relative_to(outdir)), sha256=digest(control), caption='Arcade 0x1f: Meio says “Come, Hiryu”')}
    data['pce_scenes'] = evidence['tracks']
    data['scene_evidence_sha256'] = digest(path)
    shutil.copyfile(path, outdir / 'pce_scene_usage.json')

def recorded_decisions(data):
    """Reconstruction helper."""
    rec = json.loads((ROOT / 'cpsplus/manifests/strider_listening_decisions.json').read_text())
    if rec['audio_revision'] != data['audio_revision']:
        return {}
    return {d['id']: dict(verdict='good' if d['verdict'] == 'good' else 'change', note=d.get('note', '')) for d in rec['decisions']}

def write_page(outdir, data):
    data['recorded'] = recorded_decisions(data)
    page = PAGE.replace('__DATA__', json.dumps(data, ensure_ascii=False).replace('</', '<\\/'))
    (outdir / 'index.html').write_text(page)
if __name__ == '__main__':
    main()
