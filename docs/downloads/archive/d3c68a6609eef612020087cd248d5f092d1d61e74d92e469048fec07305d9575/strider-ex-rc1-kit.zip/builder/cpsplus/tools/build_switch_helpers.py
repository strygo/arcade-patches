"""Build pinned, licensed helper bundles on producer hosts. No game inputs."""
import argparse
import hashlib
import json
import os
import platform
from pathlib import Path
import shutil
import subprocess
import sys
import zipfile
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import setup_switch_tools as build
from setup_x68k_music_tools import cmake_build

def sha(data):
    return hashlib.sha256(data).hexdigest()

def archive(tree, out):
    with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for p in sorted(tree.rglob('*')):
            if not p.is_file() or '.git' in p.parts or '__pycache__' in p.parts:
                continue
            i = zipfile.ZipInfo(p.relative_to(tree).as_posix(), (2026, 10, 23, 0, 0, 0))
            i.compress_type = zipfile.ZIP_DEFLATED
            i.create_system = 3
            i.external_attr = 33188 << 16
            z.writestr(i, p.read_bytes(), compresslevel=9)

def run(a):
    os.environ['SOURCE_DATE_EPOCH'] = '1792713600'
    if a.out.exists():
        raise ValueError('Fresh output required')
    if a.root.exists():
        raise ValueError('Fresh source/build root required; choose a new --root')
    a.root.mkdir(parents=True)
    source = a.root / 'source'
    nstool = source / 'nstool'
    opus = source / 'opus'
    build._checkout(nstool, build.NSTOOL_REPOSITORY, build.NSTOOL_COMMIT, submodules=True)
    build._checkout(opus, build.OPUS_REPOSITORY, build.OPUS_COMMIT)
    options = ['-DCMAKE_C_FLAGS=-ffile-prefix-map=' + str(source) + '=/switch-helper-source', '-DCMAKE_CXX_FLAGS=-ffile-prefix-map=' + str(source) + '=/switch-helper-source']
    if a.host.startswith('macos-'):
        options += ['-DCMAKE_OSX_ARCHITECTURES=' + {'macos-arm64': 'arm64', 'macos-x86_64': 'x86_64'}[a.host], '-DCMAKE_OSX_DEPLOYMENT_TARGET=11.0']
    elif a.host == 'windows-x86_64':
        options += ['-DCMAKE_SYSTEM_NAME=Windows', '-DCMAKE_C_COMPILER=x86_64-w64-mingw32-gcc', '-DCMAKE_CXX_COMPILER=x86_64-w64-mingw32-g++', '-DCMAKE_RC_COMPILER=x86_64-w64-mingw32-windres']
    elif a.host == 'linux-x86_64' and platform.machine() not in ('x86_64', 'AMD64'):
        options += ['-DCMAKE_SYSTEM_NAME=Linux', '-DCMAKE_SYSTEM_PROCESSOR=x86_64', '-DCMAKE_C_COMPILER=x86_64-linux-gnu-gcc', '-DCMAKE_CXX_COMPILER=x86_64-linux-gnu-g++']
    elif a.host not in ('linux-x86_64', 'linux-arm64'):
        raise ValueError('Unsupported build host')
    binary = a.root / a.host / 'bin'
    project = build._project(a.root / a.host / 'nstool-project', build.NSTOOL_PROJECT.format(source=nstool.as_posix(), libraries=' '.join(build.NSTOOL_LIBRARIES)))
    cmake_build(project, a.root / a.host / 'nstool-build', 'nstool', tuple(options), binary)
    project = build._project(a.root / a.host / 'opus-project', build.DECODER_PROJECT.format(opus=opus.as_posix(), target=build.DECODER, decoder=(HERE / (build.DECODER + '.c')).as_posix()))
    cmake_build(project, a.root / a.host / 'opus-build', build.DECODER, tuple(options), binary)
    a.out.mkdir(parents=True)
    stage = a.out / 'stage'
    stage.mkdir()
    exe = '.exe' if a.host.startswith('windows-') else ''
    executables = {'nstool': 'bin/nstool' + exe, 'decoder': 'bin/' + build.DECODER + exe}
    for name in executables.values():
        dest = stage / name
        dest.parent.mkdir(exist_ok=True)
        shutil.copyfile(binary / Path(name).name, dest)
    for repo in (nstool, opus):
        for p in sorted(repo.rglob('*')):
            if not p.is_file() or '.git' in p.parts:
                continue
            if p.name.lower().startswith(('license', 'copying', 'notice', 'copyright', 'authors', 'patents')) or p.name == 'apache-2.0.txt':
                dest = stage / 'licenses' / repo.name / p.relative_to(repo)
                dest.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(p, dest)
    if a.host.startswith('windows-'):
        prefix = Path(shutil.which('x86_64-w64-mingw32-gcc')).resolve().parents[1]
        for p in sorted(prefix.rglob('*')):
            if p.is_file() and p.name in ('COPYING', 'COPYING3', 'COPYING.RUNTIME', 'COPYING.LIB', 'DISCLAIMER'):
                dest = stage / 'licenses/toolchain' / p.relative_to(prefix)
                dest.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(p, dest)
        shutil.copytree(HERE / 'licenses/gcc-runtime', stage / 'licenses/toolchain/gcc-runtime')
    for folder in ('src', 'include'):
        shutil.copytree(nstool / 'deps/libmbedtls' / folder, stage / 'licenses/mbedtls-source-notices' / folder)
    recipes = stage / 'recipe'
    recipes.mkdir()
    for name in ('build_switch_helpers.py', 'setup_switch_tools.py', 'setup_x68k_music_tools.py', 'switch_opus_decode.c'):
        shutil.copyfile(HERE / name, recipes / name)
    shutil.copytree(HERE / 'licenses', recipes / 'licenses')
    metadata = dict(schema=1, host=a.host, nstool=dict(repository=build.NSTOOL_REPOSITORY, commit=build.NSTOOL_COMMIT), opus=dict(repository=build.OPUS_REPOSITORY, commit=build.OPUS_COMMIT), nstool_submodules=subprocess.check_output(['git', '-C', str(nstool), 'submodule', 'status', '--recursive'], text=True).strip().splitlines(), build_options=[v.replace(str(source), '{SOURCE_ROOT}') for v in options], executables=executables, recipe_sha256={p.relative_to(recipes).as_posix(): sha(p.read_bytes()) for p in recipes.rglob('*') if p.is_file()})
    (stage / 'BUILD.json').write_text(json.dumps(metadata, indent=2, sort_keys=True) + '\n')
    (stage / 'README.txt').write_text('Pinned Switch extraction helpers for ' + a.host + '.\nNo keys or game assets are included. See licenses/ and recipe/.\nNSTool: MIT; libpietendo/libtoolchain/fmt: MIT; LZ4: BSD; Mbed TLS: Apache 2.0\n(file-specific exceptions retained in upstream sources); Opus: BSD.\nBuilt using the bundled recipe; upstream source files are unmodified.\n')
    filename = 'switch-helpers-v1-' + a.host + '.zip'
    out = a.out / filename
    archive(stage, out)
    record = dict(filename=filename, sha256=sha(out.read_bytes()), bytes=out.stat().st_size, executables=executables, files={p.relative_to(stage).as_posix(): sha(p.read_bytes()) for p in sorted(stage.rglob('*')) if p.is_file()}, sources=metadata)
    (a.out / 'record.json').write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
    print('PASS helper bundle', a.host, record['sha256'], flush=True)
if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--host', required=True, choices=('macos-arm64', 'macos-x86_64', 'windows-x86_64', 'linux-x86_64', 'linux-arm64'))
    p.add_argument('--root', required=True, type=Path)
    p.add_argument('--out', required=True, type=Path)
    a = p.parse_args()
    a.root = a.root.resolve()
    a.out = a.out.resolve()
    run(a)
