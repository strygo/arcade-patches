"""Classify a per-command injection sweep (mi_sweep_all.sh output) by what the"""
from __future__ import annotations
import argparse, array, json, math, sys, wave
from pathlib import Path
FLOOR_DB = -60.0
SHORT_S = 3.0
TAIL_S = 1.0
WIN_S = 0.1

def load_mono(path: Path):
    w = wave.open(str(path))
    sr, ch, n = (w.getframerate(), w.getnchannels(), w.getnframes())
    raw = w.readframes(n)
    w.close()
    a = array.array('h')
    a.frombytes(raw)
    if ch > 1:
        a = a[::ch]
    return (a, sr)

def marker_second(tsv: Path) -> float | None:
    try:
        for line in tsv.read_text().splitlines()[1:]:
            parts = line.split('\t')
            if len(parts) >= 3:
                return float(parts[2])
    except (OSError, ValueError):
        pass
    return None

def classify(wav: Path, tsv: Path) -> dict | None:
    t0 = marker_second(tsv)
    if t0 is None:
        return None
    x, sr = load_mono(wav)
    start = int(t0 * sr)
    if start >= len(x):
        return None
    seg = x[start:]
    hop = int(WIN_S * sr)
    nwin = len(seg) // hop
    if nwin == 0:
        return None
    peak_db, last_aud, first_aud = (-120.0, None, None)
    for i in range(nwin):
        w = seg[i * hop:(i + 1) * hop]
        acc = 0
        for v in w:
            acc += v * v
        rms = math.sqrt(acc / len(w)) / 32768.0
        db = 20 * math.log10(rms) if rms > 0 else -120.0
        peak_db = max(peak_db, db)
        if db > FLOOR_DB:
            last_aud = i
            if first_aud is None:
                first_aud = i
    span = 0.0 if last_aud is None else (last_aud - (first_aud or 0) + 1) * WIN_S
    window_s = nwin * WIN_S
    if last_aud is None:
        cls = 'silent'
    elif (nwin - 1 - last_aud) * WIN_S <= TAIL_S:
        cls = 'sustained'
    elif span < SHORT_S:
        cls = 'short'
    else:
        cls = 'jingle'
    return {'inject_s': round(t0, 3), 'peak_db': round(peak_db, 1), 'audible_s': round(span, 1), 'window_s': round(window_s, 1), 'class': cls}

def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('sweepdir')
    ap.add_argument('--out', required=True)
    ap.add_argument('--tsv')
    ap.add_argument('--cut', help='write injection-trimmed WAVs here')
    a = ap.parse_args(argv)
    d = Path(a.sweepdir)
    rows = {}
    for wav in sorted(d.glob('0x*.wav')):
        cmd = wav.stem
        r = classify(wav, wav.with_suffix('.tsv'))
        if r is None:
            rows[cmd] = {'class': 'unmeasurable'}
            continue
        rows[cmd] = r
        if a.cut and r['class'] != 'silent':
            x, sr = load_mono(wav)
            seg = x[int(r['inject_s'] * sr):]
            outp = Path(a.cut) / wav.name
            outp.parent.mkdir(parents=True, exist_ok=True)
            w = wave.open(str(outp), 'w')
            w.setnchannels(1)
            w.setsampwidth(2)
            w.setframerate(sr)
            w.writeframes(seg.tobytes())
            w.close()
    by = {}
    for cmd, r in rows.items():
        by.setdefault(r['class'], []).append(cmd)
    out = {'counts': {k: len(v) for k, v in sorted(by.items())}, 'by_class': {k: sorted(v) for k, v in sorted(by.items())}, 'commands': rows}
    Path(a.out).write_text(json.dumps(out, indent=1) + '\n')
    if a.tsv:
        with open(a.tsv, 'w') as f:
            f.write('cmd\tclass\tpeak_db\taudible_s\tinject_s\n')
            for cmd, r in sorted(rows.items()):
                f.write(f"{cmd}\t{r['class']}\t{r.get('peak_db', '-')}\t{r.get('audible_s', '-')}\t{r.get('inject_s', '-')}\n")
    print(json.dumps(out['counts']))
    return 0
if __name__ == '__main__':
    sys.exit(main())
