"""Paired clean-boot Strider controls: music, FM effect and OKI sample."""
import argparse
import csv
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import numpy as np
import wave
ROOT = Path(__file__).resolve().parents[2]

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--outdir', type=Path, required=True)
    p.add_argument('--machine', choices=['striderua', 'striderjr'], default='striderua')
    p.add_argument('--audit-only', action='store_true')
    p.add_argument('--resume', action='store_true', help='reuse completed matching native runs')
    a = p.parse_args()
    a.outdir.mkdir(parents=True, exist_ok=True)
    rows = []
    for kind, cmd, after in [('music', 0, 120), ('fm', 48, 8), ('oki', 129, 8)]:
        clips = {}
        register_sequences = {}
        for treatment, byte in [('baseline', None), ('idle_ff', 255), ('stop_f0', 240)]:
            out = a.outdir / f'{kind}_{treatment}'
            events = f'1120:{cmd}' + (f';{1120 + after}:{byte}' if byte is not None else '')
            reuse = a.resume and (out / 'run.log').exists()
            if reuse:
                invocation = json.loads((out / 'invocation.json').read_text())
                assert invocation['events'] == events and a.machine in invocation['command']
                assert 'Average speed:' in (out / 'run.log').read_text()
            if not a.audit_only and (not reuse):
                subprocess.run([sys.executable, str(ROOT / 'cpsplus/tools/run_strider_arcade_probe.py'), '--machine', a.machine, '--mode', 'custom', '--outdir', str(out), '--events', events, '--captures', '1050=quiet;1540=end'], check=True)
            assert 'Average speed:' in (out / 'run.log').read_text()
            trace = list(csv.DictReader((out / 'events.tsv').open(), delimiter='\t'))
            register_sequences[treatment] = [(r['addr'], r['data']) for r in trace if r['kind'] == 'ym' and int(r['frame']) >= 1120 and (int(r['addr'], 16) not in (16, 17, 18, 20))]
            event = next((r for r in trace if r['kind'] == 'inject' and int(r['frame']) == 1120))
            with wave.open(str(out / 'audio.wav')) as f:
                rate = f.getframerate()
                assert rate == 48000
                f.setpos(round(float(event['time']) * rate))
                x = np.frombuffer(f.readframes(6 * rate), '<i2').reshape(-1, 2).astype(float) / 32768
            with (out / 'audio.wav').open('rb') as f:
                h = hashlib.file_digest(f, 'sha256').hexdigest()
            clips[treatment] = x
            rows.append(dict(machine=a.machine, kind=kind, command=f'0x{cmd:02x}', treatment=treatment, injected_after_frames=after if byte is not None else None, source=str((out / 'audio.wav').absolute().relative_to(ROOT)), sha256=h, rms_dbfs=float(10 * np.log10(max(1e-20, np.mean(x * x))))))
        base = clips['baseline']
        idle = clips['idle_ff']
        stopped = clips['stop_f0']
        assert np.max(abs(base)) > 0.002, f'{kind} positive control silent'
        delta = idle - base
        ncc = float(np.sum(base * idle) / np.sqrt(np.sum(base ** 2) * np.sum(idle ** 2)))
        error_db = float(10 * np.log10(max(1e-20, np.mean(delta ** 2)) / np.mean(base ** 2)))
        assert register_sequences['baseline'] == register_sequences['idle_ff'], kind
        assert ncc > 0.999, (kind, ncc, error_db)
        tail = round((after / 59.6374 + 0.4) * rate)
        rows.append(dict(kind=kind, verdict='ff_preserves_native_playback', idle_ncc=ncc, ordered_musical_register_writes_identical=True, idle_error_relative_db=error_db, f0_audio_equals_baseline=bool(np.array_equal(stopped, base)), f0_tail_rms_dbfs=float(10 * np.log10(max(1e-20, np.mean(stopped[tail:] ** 2))))))
    result = dict(status='native_controls_verified_substitution_pending', rows=rows)
    (a.outdir / 'verification.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps([r for r in rows if 'verdict' in r], indent=2))
if __name__ == '__main__':
    main()
