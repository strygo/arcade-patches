"""Prepare a draft helper lock, or seal it after independent runtime checks."""
import argparse
import copy
import hashlib
import json
from pathlib import Path
import shutil
import zipfile
import fetch_optional_tools as optional
from fetch_switch_tools import inventory, MAX_ARCHIVE, MAX_EXPANDED
HERE = Path(__file__).resolve().parent
HOSTS = {'macos-arm64', 'macos-x86_64', 'windows-x86_64', 'linux-arm64', 'linux-x86_64'}
URL = 'https://github.com/strygo/arcade-patches/releases/download/optional-helpers-v1'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def archive(files, target):
    with zipfile.ZipFile(target, 'w', zipfile.ZIP_STORED) as z:
        for name, data in sorted(files.items()):
            i = zipfile.ZipInfo(name, (2026, 10, 24, 0, 0, 0))
            i.external_attr = 33188 << 16
            z.writestr(i, data)

def require_architecture(data, host):
    if host.startswith('linux-'):
        machine = int.from_bytes(data[18:20], 'little') if data[:6] == b'\x7fELF\x02\x01' else None
        expected = 183 if host.endswith('arm64') else 62
    elif host.startswith('windows-'):
        offset = int.from_bytes(data[60:64], 'little')
        machine = int.from_bytes(data[offset + 4:offset + 6], 'little') if data[offset:offset + 4] == b'PE\x00\x00' else None
        expected = 34404
    else:
        machine = int.from_bytes(data[4:8], 'little') if data[:4] == b'\xcf\xfa\xed\xfe' else None
        expected = 16777228 if host.endswith('arm64') else 16777223
    if machine != expected:
        raise ValueError('Wrong binary architecture for ' + host)

def package(a):
    if a.seal and a.runtime_only:
        raise ValueError('A runtime-only draft cannot be sealed')
    if a.out.exists():
        raise ValueError('Fresh output required')
    source_pin = HERE.parent / 'manifests/optional_helpers_sources_v1.json'
    source_bytes = source_pin.read_bytes()
    pins = json.loads(source_bytes)['sources']
    recipe_catalog = json.loads((HERE.parent / 'manifests/optional_helper_recipes_v1.json').read_text())
    recipes = recipe_catalog['recipes']
    components = {name: {'platforms': {}} for name in optional.EXPECTED}
    archives = {}
    records = {}
    for folder in a.host:
        for component in components:
            path = folder / (component + '-record.json')
            record = json.loads(path.read_text())
            meta = record['sources']
            host = meta['host']
            if host not in HOSTS or host in components[component]['platforms']:
                raise ValueError('Duplicate or unknown producer')
            source = 'mame' if component == 'chdman' else component
            if meta['component'] != component or meta['source'] != pins[source]:
                raise ValueError('Unexpected source identity: ' + component)
            if meta['recipe_sha256'] not in recipes or set(record['executables']) != optional.EXPECTED[component]:
                raise ValueError('Stale producer recipe or incomplete helper')
            if set(meta['runtime_dependencies']) != optional.EXPECTED[component]:
                raise ValueError('Missing producer dependency audit')
            deps = ('glib', 'libffi', 'pcre2', 'proxy-libintl', 'zlib') if component == 'munt' else ()
            if component == 'chdman' and host.startswith('linux-'):
                deps = ('sdl2',)
            if meta['dependencies'] != {name: pins[name] for name in deps}:
                raise ValueError('Unexpected transitive source identities')
            if not 0 < record['bytes'] <= MAX_ARCHIVE:
                raise ValueError('Host archive exceeds recipient limit')
            data = (folder / record['filename']).read_bytes()
            files = inventory(data, record)
            for member in record['executables'].values():
                require_architecture(files[member], host)
            if sum(map(len, files.values())) > MAX_EXPANDED:
                raise ValueError('Expanded archive exceeds recipient limit')
            if sha(files['recipe/build_optional_helpers.py']) != meta['recipe_sha256']:
                raise ValueError('Standalone recipe differs')
            modified = meta['modifications']
            expected_modified = {'mt32emu/src/TVP.cpp', 'mt32emu/src/Analog.cpp', 'mt32emu/src/mmath.h', 'munt_rand.c'} if component == 'munt' else {'src/adlmidi.cpp'} if component == 'adlmidi' else set()
            if component == 'munt' and meta['recipe_sha256'] in recipe_catalog.get('munt_explicit_sequence', []):
                expected_modified.add('mt32emu/src/Partial.cpp')
            if set(modified) != expected_modified:
                raise ValueError('Unexpected source modifications')
            for name, digest in modified.items():
                member = 'recipe/' + ('' if name == 'munt_rand.c' else 'modified-source/') + name
                if sha(files[member]) != digest:
                    raise ValueError('Modified corresponding source differs')
            if files['recipe/optional_helpers_sources_v1.json'] != source_bytes:
                raise ValueError('Standalone source lock differs')
            if not any((name.startswith('licenses/') for name in files)):
                raise ValueError('License files missing')
            if any((not any((p.startswith('licenses/' + name + '/') for p in files)) for name in deps)):
                raise ValueError('Transitive license files missing')
            record['url'] = URL + '/' + record['filename']
            archives[record['filename']] = data
            components[component]['platforms'][host] = record
            records.setdefault(host, {})[component] = record['sha256']
    for item in components.values():
        required_hosts = set(records) if a.runtime_only else HOSTS
        if not required_hosts or set(item['platforms']) != required_hosts:
            raise ValueError('All five producer hosts required')
        if 'windows-x86_64' in item['platforms']:
            alias = copy.deepcopy(item['platforms']['windows-x86_64'])
            alias.update(minimum_windows_build=22000, execution='Windows 11 ARM x64 emulation')
            item['platforms']['windows-arm64'] = alias
    qualified = {}
    qualified_outputs = None
    if a.seal:
        if len(a.qualification) != len(HOSTS):
            raise ValueError('All runtime qualification receipts required')
        for p in a.qualification:
            receipt = json.loads(p.read_text())
            host = receipt['host']
            if host not in HOSTS or host in qualified or receipt['status'] != 'passed':
                raise ValueError('Missing, duplicate or failed runtime qualification')
            if receipt['archives'] != records[host]:
                raise ValueError('Runtime receipt binds other helpers')
            if receipt['recipe_sha256'] != sha((HERE / 'qualify_optional_helpers.py').read_bytes()):
                raise ValueError('Runtime qualification recipe changed')
            if qualified_outputs is None:
                qualified_outputs = receipt['outputs']
            elif receipt['outputs'] != qualified_outputs:
                raise ValueError('Cross-host helper PCM differs')
            qualified[host] = sha(p.read_bytes())
        if set(qualified) != HOSTS:
            raise ValueError('Incomplete runtime host matrix')
    lock = dict(schema=1, release='optional-helpers-v1', components=components, status='qualified' if a.seal else 'draft-not-for-publication', qualification=qualified)
    a.out.mkdir(parents=True)
    for name, data in archives.items():
        (a.out / name).write_bytes(data)
    (a.out / 'optional_helpers.json').write_text(json.dumps(lock, indent=2, sort_keys=True) + '\n')
    for pin in pins.values():
        data = (a.sources / pin['filename']).read_bytes()
        if sha(data) != pin['sha256'] or len(data) != pin['bytes']:
            raise ValueError('Corresponding source identity differs')
    (a.out / 'README.txt').write_text('Optional helpers v1: ' + lock['status'] + '\nArchives and URLs are prepared locally, not published.\nEach recipient kit supplies its own trusted binary manifest.\nInstall only the requested component. Use package_optional_sources.py for source companions.\n')
    print('SEALED' if a.seal else 'DRAFT', len(archives), 'host/component archives', flush=True)
if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--host', action='append', type=Path, required=True)
    p.add_argument('--qualification', action='append', type=Path, default=[])
    p.add_argument('--seal', action='store_true')
    p.add_argument('--runtime-only', action='store_true', help='partial host cohort for qualification only; cannot seal')
    p.add_argument('--sources', type=Path, required=True)
    p.add_argument('--out', type=Path, required=True)
    package(p.parse_args())
