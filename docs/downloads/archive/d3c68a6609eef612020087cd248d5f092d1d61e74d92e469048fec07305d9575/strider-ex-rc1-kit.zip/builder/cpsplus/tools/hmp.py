"""Read HMI `.HMP` sequences (Human Machine Interfaces Sound Operating System)."""
from __future__ import annotations
import struct
from dataclasses import dataclass
from pathlib import Path
MAGIC = b'HMIMIDIP'
FIRST_TRACK = 904
TRACK_HEADER = 12
CC_TRACK_SYNC = 108
CC_LOOP_MARK = 109
CC_LOOP_START = 110
CC_LOOP_END = 111
LOOP_CCS = frozenset((CC_TRACK_SYNC, CC_LOOP_MARK, CC_LOOP_START, CC_LOOP_END))
META = 255
META_END_OF_TRACK = 47

class HmpError(ValueError):
    pass

@dataclass(frozen=True)
class Event:
    tick: int
    status: int
    data: bytes

    @property
    def is_end_of_track(self) -> bool:
        return self.status == META and self.data[:1] == bytes([META_END_OF_TRACK])

    @property
    def controller(self) -> int | None:
        if 176 <= self.status <= 191:
            return self.data[0]
        return None

@dataclass(frozen=True)
class Track:
    index: int
    channel: int
    events: tuple[Event, ...]

    @property
    def ticks(self) -> int:
        return self.events[-1].tick if self.events else 0

@dataclass(frozen=True)
class Loop:
    start_tick: int
    end_tick: int
    count: int

    @property
    def forever(self) -> bool:
        return self.count >= 127

@dataclass(frozen=True)
class HmpFile:
    name: str
    tick_rate: int
    header_division: int
    stored_seconds: int
    tracks: tuple[Track, ...]
    trailer: bytes

    @property
    def ticks(self) -> int:
        return max((t.ticks for t in self.tracks), default=0)

    @property
    def seconds(self) -> float:
        return self.ticks / self.tick_rate

    def tick_to_seconds(self, tick: int) -> float:
        return tick / self.tick_rate

    @property
    def loop(self) -> Loop | None:
        """The song's loop, or None for a one-shot."""
        ends = [(track, ev) for track in self.tracks for ev in track.events if ev.controller == CC_LOOP_END]
        if not ends:
            if any((ev.controller == CC_LOOP_START for track in self.tracks for ev in track.events)):
                raise HmpError(f'{self.name}: loop start with no loop end')
            return None
        if len(ends) > 1:
            raise HmpError(f'{self.name}: {len(ends)} loop ends, expected one')
        loop_track, end_ev = ends[0]
        end = end_ev.tick
        starts = [ev for ev in loop_track.events if ev.controller == CC_LOOP_START]
        if len(starts) != 1:
            raise HmpError(f'{self.name}: {len(starts)} loop starts on the track carrying the loop end, expected one')
        start, count = (starts[0].tick, starts[0].data[1])
        if end <= start:
            raise HmpError(f'{self.name}: loop end {end} precedes start {start}')
        if end > self.ticks:
            raise HmpError(f"{self.name}: loop end {end} past the song's {self.ticks} ticks")
        assert count is not None
        return Loop(start, end, count)

def _read_delta(body: bytes, pos: int) -> tuple[int, int]:
    """HMI varint: little-endian 7-bit groups, high bit SET on the last byte."""
    value = shift = 0
    while True:
        if pos >= len(body):
            raise HmpError('delta runs past the end of the track')
        byte = body[pos]
        pos += 1
        value |= (byte & 127) << shift
        shift += 7
        if byte & 128:
            return (value, pos)
        if shift > 28:
            raise HmpError('unterminated delta')

def _parse_events(body: bytes, where: str) -> tuple[Event, ...]:
    events: list[Event] = []
    pos = tick = 0
    while pos < len(body):
        delta, pos = _read_delta(body, pos)
        tick += delta
        if pos >= len(body):
            raise HmpError(f'{where}: delta with no message')
        status = body[pos]
        if status == META:
            kind = body[pos + 1]
            if kind == META_END_OF_TRACK:
                events.append(Event(tick, META, bytes([kind, 0])))
                pos += 3
                break
            length = body[pos + 2]
            events.append(Event(tick, META, body[pos + 1:pos + 3 + length]))
            pos += 3 + length
        elif status in (240, 247):
            length = body[pos + 1]
            events.append(Event(tick, status, body[pos + 2:pos + 2 + length]))
            pos += 2 + length
        elif status < 128:
            raise HmpError(f'{where}: running status at offset {pos} (the format does not use it)')
        else:
            size = 1 if status & 240 in (192, 208) else 2
            events.append(Event(tick, status, body[pos + 1:pos + 1 + size]))
            pos += 1 + size
    if pos != len(body):
        raise HmpError(f'{where}: {len(body) - pos} bytes left after the end of track')
    if not events or not events[-1].is_end_of_track:
        raise HmpError(f'{where}: track does not end with an end-of-track meta')
    return tuple(events)

def parse(source: Path | str | bytes, name: str | None=None) -> HmpFile:
    if isinstance(source, (Path, str)):
        path = Path(source)
        raw = path.read_bytes()
        name = name or path.name
    else:
        raw = bytes(source)
        name = name or '<bytes>'
    if raw[:len(MAGIC)] != MAGIC:
        raise HmpError(f'{name}: not an HMP file')
    if len(raw) < FIRST_TRACK:
        raise HmpError(f'{name}: truncated header')
    count, division, tick_rate, stored = struct.unpack_from('<IIII', raw, 48)
    if not 0 < count <= 64:
        raise HmpError(f'{name}: implausible track count {count}')
    if tick_rate <= 0:
        raise HmpError(f'{name}: invalid tick rate {tick_rate}')
    tracks: list[Track] = []
    offset = FIRST_TRACK
    for expected in range(count):
        if offset + TRACK_HEADER > len(raw):
            raise HmpError(f'{name}: track {expected} header past end of file')
        index, length, channel = struct.unpack_from('<III', raw, offset)
        if index != expected:
            raise HmpError(f'{name}: track {expected} is labelled {index}')
        if length < TRACK_HEADER or offset + length > len(raw):
            raise HmpError(f'{name}: track {expected} length {length} does not fit the file')
        if not 0 <= channel <= 15:
            raise HmpError(f'{name}: track {expected} channel {channel}')
        body = raw[offset + TRACK_HEADER:offset + length]
        tracks.append(Track(index, channel, _parse_events(body, f'{name} track {expected}')))
        offset += length
    return HmpFile(name=name, tick_rate=tick_rate, header_division=division, stored_seconds=stored, tracks=tuple(tracks), trailer=raw[offset:])
GS_RESET = bytes([65, 16, 66, 18, 64, 0, 127, 0, 65])
MT32_RESET = bytes([65, 16, 22, 18, 127, 0, 0, 0, 1])
RESETS = {'gs': GS_RESET, 'mt32': MT32_RESET, 'none': None}
SETTLE_SECONDS = {'gs': 0.5, 'mt32': 6.0, 'none': 0.0}

def hanging_notes(song: HmpFile) -> dict[int, int]:
    """Notes still sounding at the loop end, per channel."""
    loop = song.loop
    if loop is None:
        return {}
    live: dict[int, int] = {}
    for track in song.tracks:
        for ev in track.events:
            if ev.tick > loop.end_tick:
                break
            family = ev.status & 240
            if family == 144 and ev.data[1] > 0:
                live[track.channel] = live.get(track.channel, 0) + 1
            elif family == 128 or (family == 144 and ev.data[1] == 0):
                live[track.channel] = live.get(track.channel, 0) - 1
    return {ch: n for ch, n in live.items() if n > 0}

def _unrolled(track: Track, loop: Loop, passes: int) -> list[Event]:
    """``track``'s events with the loop body repeated ``passes`` extra times."""

    def body_events(events):
        return [ev for ev in events if not ev.is_end_of_track and ev.controller not in LOOP_CCS]
    body = loop.end_tick - loop.start_tick
    out = body_events((ev for ev in track.events if ev.tick <= loop.end_tick))
    for extra in range(1, passes + 1):
        shift = extra * body
        out.extend((Event(ev.tick + shift, ev.status, ev.data) for ev in body_events((ev for ev in track.events if loop.start_tick <= ev.tick <= loop.end_tick))))
    end = loop.end_tick + passes * body
    out.append(Event(end, META, bytes([META_END_OF_TRACK, 0])))
    return out

def _vlq(value: int) -> bytes:
    """Standard MIDI File varint: big-endian, high bit set on CONTINUING bytes."""
    if value < 0:
        raise ValueError('negative delta')
    out = bytearray([value & 127])
    value >>= 7
    while value:
        out.append(value & 127 | 128)
        value >>= 7
    return bytes(reversed(out))

def _chunk(tag: bytes, body: bytes) -> bytes:
    return tag + struct.pack('>I', len(body)) + body

def to_smf(hmp: HmpFile, *, reset: str='none', keep_loop_cc: bool=False, unroll_passes: int=0, tail_seconds: float=0.0) -> bytes:
    """A format-1 SMF that plays at exactly ``hmp.tick_rate`` ticks/second."""
    if reset not in RESETS:
        raise ValueError(f'unknown reset {reset!r}')
    if unroll_passes < 0:
        raise ValueError('unroll_passes must not be negative')
    settle = round(SETTLE_SECONDS[reset] * hmp.tick_rate)
    loop = hmp.loop
    per_track = [_unrolled(track, loop, unroll_passes) if loop is not None and unroll_passes else list(track.events) for track in hmp.tracks]
    total = max((evs[-1].tick for evs in per_track if evs), default=0)
    conductor = bytearray()
    conductor += _vlq(0) + bytes([META, 81, 3]) + 1000000 .to_bytes(3, 'big')
    payload = RESETS[reset]
    if payload is not None:
        conductor += _vlq(0) + bytes([240]) + _vlq(len(payload) + 1) + payload + b'\xf7'
    tail = round(tail_seconds * hmp.tick_rate)
    conductor += _vlq(max(total + settle + tail, 0)) + bytes([META, META_END_OF_TRACK, 0])
    chunks = [_chunk(b'MTrk', bytes(conductor))]
    for events in per_track:
        body = bytearray()
        previous = 0
        for ev in events:
            if not keep_loop_cc and ev.controller in LOOP_CCS:
                continue
            tick = ev.tick + settle
            if ev.is_end_of_track:
                body += _vlq(tick - previous) + bytes([META, META_END_OF_TRACK, 0])
            elif ev.status == META:
                body += _vlq(tick - previous) + bytes([META, ev.data[0], len(ev.data) - 1]) + ev.data[1:]
            elif ev.status in (240, 247):
                body += _vlq(tick - previous) + bytes([ev.status]) + _vlq(len(ev.data)) + ev.data
            else:
                body += _vlq(tick - previous) + bytes([ev.status]) + ev.data
            previous = tick
        chunks.append(_chunk(b'MTrk', bytes(body)))
    header = struct.pack('>HHH', 1, len(chunks), hmp.tick_rate)
    return _chunk(b'MThd', header) + b''.join(chunks)

def loop_samples(hmp: HmpFile, rate: int, *, reset: str='none', pass_index: int=0) -> tuple[int, int] | None:
    """The song's loop in output samples at ``rate``, including reset settle."""
    loop = hmp.loop
    if loop is None:
        return None
    if pass_index < 0:
        raise ValueError('pass_index must not be negative')
    settle = round(SETTLE_SECONDS[reset] * hmp.tick_rate)
    shift = pass_index * (loop.end_tick - loop.start_tick)
    return (round((loop.start_tick + shift + settle) * rate / hmp.tick_rate), round((loop.end_tick + shift + settle) * rate / hmp.tick_rate))
