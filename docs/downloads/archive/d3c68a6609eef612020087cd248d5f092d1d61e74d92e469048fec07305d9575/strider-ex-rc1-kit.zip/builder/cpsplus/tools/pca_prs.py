"""Capcom Saturn .PCA depacker (XvSF-era; MMPACK.PCA / INITDATA.PCA / *.pca)."""
import struct, sys

def prs_decode(data, seed=b'', maxout=64000000):
    out = bytearray(seed)
    base = len(seed)
    pos = 0
    ctrl = 0
    nb = 0
    n = len(data)
    status = 'end'

    def gb():
        nonlocal ctrl, nb, pos
        if nb == 0:
            if pos >= n:
                raise EOFError
            ctrl = data[pos]
            pos += 1
            nb = 8
        b = ctrl & 1
        ctrl >>= 1
        nb -= 1
        return b
    try:
        while pos < n and len(out) - base < maxout:
            if gb():
                if pos >= n:
                    status = 'eof-lit'
                    break
                out.append(data[pos])
                pos += 1
                continue
            if gb():
                if pos + 1 >= n:
                    status = 'eof-long'
                    break
                b1, b2 = (data[pos], data[pos + 1])
                pos += 2
                v = b1 << 8 | b2
                if v == 0:
                    status = 'terminator'
                    break
                off = (v >> 3) - 8192
                amt = v & 7
                if amt == 0:
                    if pos >= n:
                        status = 'eof-ext'
                        break
                    amt = data[pos] + 1
                    pos += 1
                else:
                    amt += 2
            else:
                a = gb()
                b = gb()
                if pos >= n:
                    status = 'eof-short'
                    break
                amt = (a << 1 | b) + 2
                off = data[pos] - 256
                pos += 1
            if -off > len(out):
                status = 'BADREF'
                break
            for _ in range(amt):
                out.append(out[off])
    except EOFError:
        status = 'eof-ctrl'
    return (bytes(out[base:]), pos, status)

def unpack_pca(path, outprefix=None):
    d = open(path, 'rb').read()
    nseg = struct.unpack('>I', d[:4])[0]
    off = 4
    segs = []
    for _ in range(nseg):
        a, s = struct.unpack('>II', d[off:off + 8])
        off += 8
        segs.append((a, s))
    payload = d[off:]
    pos = 0
    seed = b''
    results = []
    for i, (addr, clen) in enumerate(segs):
        chunk = payload[pos:pos + clen] if i < nseg - 1 else payload[pos:]
        out, used, status = prs_decode(chunk, seed=seed)
        results.append((addr, out, used, status))
        seed += out
        pos += used
        print(f'seg{i}: dest=0x{addr:08x} clen_field={clen} used={used} out={len(out)} {status}')
        if outprefix:
            fn = f'{outprefix}.seg{i}_{addr:08x}.bin'
            open(fn, 'wb').write(out)
            print('  wrote', fn)
    return results
if __name__ == '__main__':
    unpack_pca(sys.argv[1], sys.argv[2] if len(sys.argv) > 2 else sys.argv[1])
