"""Multi-hypothesis 4-bit ADPCM decoder + quality metrics for headerless .ADP files."""
import sys, struct, math
import numpy as np
IMA_INDEX = [-1, -1, -1, -1, 2, 4, 6, 8, -1, -1, -1, -1, 2, 4, 6, 8]
IMA_STEPS = [7, 8, 9, 10, 11, 12, 13, 14, 16, 17, 19, 21, 23, 25, 28, 31, 34, 37, 41, 45, 50, 55, 60, 66, 73, 80, 88, 97, 107, 118, 130, 143, 157, 173, 190, 209, 230, 253, 279, 307, 337, 371, 408, 449, 494, 544, 598, 658, 724, 796, 876, 963, 1060, 1166, 1282, 1411, 1552, 1707, 1878, 2066, 2272, 2499, 2749, 3024, 3327, 3660, 4026, 4428, 4871, 5358, 5894, 6484, 7132, 7845, 8630, 9493, 10442, 11487, 12635, 13899, 15289, 16818, 18500, 20350, 22385, 24623, 27086, 29794, 32767]
OKI_STEPS = [16, 17, 19, 21, 23, 25, 28, 31, 34, 37, 41, 45, 50, 55, 60, 66, 73, 80, 88, 97, 107, 118, 130, 143, 157, 173, 190, 209, 230, 253, 279, 307, 337, 371, 408, 449, 494, 544, 598, 658, 724, 796, 876, 963, 1060, 1166, 1282, 1411, 1552]

def nibbles(data, order):
    arr = np.frombuffer(data, dtype=np.uint8)
    hi = arr >> 4
    lo = arr & 15
    if order == 'hi':
        out = np.empty(arr.size * 2, dtype=np.uint8)
        out[0::2] = hi
        out[1::2] = lo
    else:
        out = np.empty(arr.size * 2, dtype=np.uint8)
        out[0::2] = lo
        out[1::2] = hi
    return out

def dec_ima(nib):
    out = np.empty(nib.size, dtype=np.int16)
    pred = 0
    index = 0
    steps = IMA_STEPS
    idxt = IMA_INDEX
    for i in range(nib.size):
        n = nib[i]
        step = steps[index]
        diff = step >> 3
        if n & 1:
            diff += step >> 2
        if n & 2:
            diff += step >> 1
        if n & 4:
            diff += step
        if n & 8:
            pred -= diff
        else:
            pred += diff
        if pred > 32767:
            pred = 32767
        elif pred < -32768:
            pred = -32768
        index += idxt[n]
        if index < 0:
            index = 0
        elif index > 88:
            index = 88
        out[i] = pred
    return out

def dec_oki(nib):
    out = np.empty(nib.size, dtype=np.int16)
    pred = 0
    index = 0
    for i in range(nib.size):
        n = nib[i]
        step = OKI_STEPS[index]
        diff = step >> 3
        if n & 1:
            diff += step >> 2
        if n & 2:
            diff += step >> 1
        if n & 4:
            diff += step
        if n & 8:
            pred -= diff
        else:
            pred += diff
        if pred > 2047:
            pred = 2047
        elif pred < -2048:
            pred = -2048
        index += IMA_INDEX[n]
        if index < 0:
            index = 0
        elif index > 48:
            index = 48
        out[i] = pred * 16
    return out

def dec_ymz(nib):
    F = [0.8984375, 0.8984375, 0.8984375, 0.8984375, 1.19921875, 1.59765625, 2.0, 2.3984375]
    out = np.empty(nib.size, dtype=np.int16)
    pred = 0.0
    step = 127.0
    for i in range(nib.size):
        n = int(nib[i])
        mag = n & 7
        delta = step * (2 * mag + 1) / 8.0
        if n & 8:
            pred -= delta
        else:
            pred += delta
        if pred > 32767:
            pred = 32767
        elif pred < -32768:
            pred = -32768
        step *= F[mag]
        if step < 127:
            step = 127
        elif step > 24576:
            step = 24576
        out[i] = int(pred)
    return out
DECODERS = {'ima': dec_ima, 'oki': dec_oki, 'ymz': dec_ymz}

def metrics(x):
    xf = x.astype(np.float64)
    d = np.abs(np.diff(xf))
    ma = np.mean(np.abs(xf)) or 1.0
    smooth = np.mean(d) / ma
    zcr = np.mean(np.abs(np.diff(np.signbit(xf).astype(np.int8))))
    clip = np.mean((x >= 32700) | (x <= -32700))
    w = xf[:65536] * np.hanning(min(65536, xf.size))
    sp = np.abs(np.fft.rfft(w))
    freqs = np.linspace(0, 1, sp.size)
    cent = float(np.sum(freqs * sp) / np.sum(sp)) if np.sum(sp) > 0 else 0
    rms = math.sqrt(np.mean(xf ** 2))
    return (smooth, zcr, clip, cent, rms)

def main():
    path = sys.argv[1]
    data = open(path, 'rb').read()
    if '--decode' in sys.argv:
        i = sys.argv.index('--decode')
        hyp = sys.argv[i + 1]
        order = sys.argv[sys.argv.index('--order') + 1]
        rate = int(sys.argv[sys.argv.index('--rate') + 1])
        out = sys.argv[sys.argv.index('--out') + 1]
        nib = nibbles(data, order)
        stereo = '--stereo' in sys.argv
        pcm = DECODERS[hyp](nib)
        import wave
        w = wave.open(out, 'wb')
        if stereo:
            L = DECODERS[hyp](nib[0::2])
            R = DECODERS[hyp](nib[1::2])
            inter = np.empty(L.size + R.size, dtype=np.int16)
            inter[0::2] = L
            inter[1::2] = R[:L.size]
            w.setnchannels(2)
            w.setsampwidth(2)
            w.setframerate(rate)
            w.writeframes(inter.tobytes())
        else:
            w.setnchannels(1)
            w.setsampwidth(2)
            w.setframerate(rate)
            w.writeframes(pcm.tobytes())
        w.close()
        print(f'wrote {out}: {pcm.size} samples @ {rate} = {pcm.size / rate:.2f}s')
        return
    mid = len(data) // 2 & ~4095
    win = data[mid:mid + 65536]
    print(f'{path}: {len(data)} bytes -> {len(data) * 2} nibbles/samples')
    print(f"{'hyp':6s} {'ord':3s} {'smooth':>7s} {'zcr':>6s} {'clip%':>6s} {'cent':>6s} {'rms':>7s}")
    for hyp, fn in DECODERS.items():
        for order in ('hi', 'lo'):
            nib = nibbles(win, order)
            x = fn(nib)
            sm, z, c, ce, r = metrics(x)
            print(f'{hyp:6s} {order:3s} {sm:7.3f} {z:6.3f} {c * 100:6.2f} {ce:6.3f} {r:7.0f}')
            L = fn(nib[0::2])
            R = fn(nib[1::2])
            smL, _, _, _, _ = metrics(L)
            smR, _, _, _, _ = metrics(R)
            print(f"{hyp + '-st':6s} {order:3s} {'L%.3f R%.3f' % (smL, smR):>22s}")
main()
