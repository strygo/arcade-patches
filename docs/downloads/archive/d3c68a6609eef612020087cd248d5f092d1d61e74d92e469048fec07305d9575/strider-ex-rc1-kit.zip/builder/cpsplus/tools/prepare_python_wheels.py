"""Prepare separate offline NumPy/Pillow wheels for the declared Python ABIs."""
import argparse
import hashlib
import json
from pathlib import Path
import urllib.request
import zipfile
HERE = Path(__file__).resolve().parent

def prepare(a):
    lock = json.loads((HERE.parent / 'manifests/python_wheels_v1.json').read_text())
    if a.out.exists():
        raise ValueError('Fresh output required')
    a.out.mkdir(parents=True)
    for host, records in lock['hosts'].items():
        files = {}
        requirements = []
        for pin in records:
            cache = a.cache / host / pin['filename']
            if not cache.is_file():
                cache.parent.mkdir(parents=True, exist_ok=True)
                with urllib.request.urlopen(pin['url'], timeout=90) as response:
                    data = response.read(pin['bytes'] + 1)
                cache.write_bytes(data)
            data = cache.read_bytes()
            if len(data) != pin['bytes'] or hashlib.sha256(data).hexdigest() != pin['sha256']:
                raise ValueError('Wheel identity differs: ' + cache.name)
            files[cache.name] = data
            requirements.append(pin['project'] + '==' + pin['version'] + ' --hash=sha256:' + pin['sha256'])
        files['requirements.txt'] = ('\n'.join(requirements) + '\n').encode()
        files['README.txt'] = ('Optional Python packages — ' + host + '\nUse only with the named CPython ABI and architecture. Python is not included.\nUnzip, then run: python -m pip install --no-index --find-links . --require-hashes -r requirements.txt\nUse your kit interpreter or a dedicated virtual environment.\nOriginal project and bundled-library notices are retained inside each wheel.\nThese packages are separate from the shared helper cache and tools ZIP.\n').encode()
        with zipfile.ZipFile(a.out / ('python-wheels-v1-' + host + '.zip'), 'w', compression=zipfile.ZIP_STORED) as z:
            for name, data in sorted(files.items()):
                i = zipfile.ZipInfo(name, (2026, 10, 24, 0, 0, 0))
                i.external_attr = 33188 << 16
                z.writestr(i, data)
        print('PREPARED', host)
if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--cache', type=Path, required=True)
    p.add_argument('--out', type=Path, required=True)
    prepare(p.parse_args())
