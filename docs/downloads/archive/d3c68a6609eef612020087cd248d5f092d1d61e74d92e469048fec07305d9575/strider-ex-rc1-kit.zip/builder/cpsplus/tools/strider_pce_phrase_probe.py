"""Independent pitch-class repetition measurement for PCE loop research."""
import argparse
import hashlib
import json
from pathlib import Path
import wave
import numpy as np
from scipy import signal
ROOT = Path(__file__).resolve().parents[2]

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output', type=Path, required=True)
    a = p.parse_args()
    out = []
    for tr in [3, 4, 8, 9, 12, 13, 14, 15, 16, 17, 18, 19, 20]:
        path = ROOT / f'cpsplus/work/listening/strider/cd_full/tr{tr:02}.wav'
        with wave.open(str(path)) as f:
            assert f.getframerate() == 44100 and f.getnchannels() == 2 and (f.getsampwidth() == 2)
            x = np.frombuffer(f.readframes(f.getnframes()), '<i2').reshape(-1, 2).astype(float).mean(1) / 32768
        rate = 11025
        x = signal.resample_poly(x, 1, 4)
        freq, t, z = signal.stft(x, rate, nperseg=2048, noverlap=1792, boundary=None)
        mag = abs(z)
        peaks = (mag > np.roll(mag, 1, 0)) & (mag > np.roll(mag, -1, 0))
        chroma = np.zeros((12, len(t)))
        for i in np.flatnonzero((freq >= 100) & (freq < 2500)):
            pc = int(round(69 + 12 * np.log2(freq[i] / 440))) % 12
            chroma[pc] += mag[i] ** 0.5 * peaks[i]
        chroma -= chroma.mean(0)
        chroma /= np.maximum(1e-20, np.linalg.norm(chroma, axis=0))
        curves = []
        for lag in range(round(10 * rate / 256), round(len(x) * 0.72 / 256)):
            p, q = (chroma[:, 10:-lag - 200], chroma[:, lag + 10:-200])
            if p.shape[1] < 258:
                continue
            avg = np.convolve((p * q).sum(0), np.ones(258) / 258, 'valid')
            j = int(np.argmax(avg))
            curves.append((float(avg[j]), lag * 256 / rate, (j + 10) * 256 / rate))
        curves.sort(reverse=True)
        best = []
        for score, lag, start in curves:
            if all((abs(lag - r['period_seconds']) > 0.75 for r in best)):
                best.append(dict(chroma_match=score, period_seconds=lag, passage_start_seconds=start))
            if len(best) == 5:
                break
        with path.open('rb') as f:
            h = hashlib.file_digest(f, 'sha256').hexdigest()
        out.append(dict(track=tr, source_sha256=h, candidates=best))
        print(tr, best[0], flush=True)
    a.output.parent.mkdir(parents=True, exist_ok=True)
    a.output.write_text(json.dumps(dict(status='measurement_not_listening_approval', tracks=out), indent=2) + '\n')
if __name__ == '__main__':
    main()
