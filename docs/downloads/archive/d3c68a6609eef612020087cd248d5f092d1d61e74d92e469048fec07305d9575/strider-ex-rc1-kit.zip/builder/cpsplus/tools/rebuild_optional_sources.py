"""Run the original producer offline from its verified corresponding-source bundle."""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import sys
import zipfile

def digest(path):
    with path.open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--bundle', type=Path, required=True)
    p.add_argument('--sha256', required=True)
    p.add_argument('--extract', type=Path, required=True, help='fresh source/recipe extraction directory')
    a, producer_args = p.parse_known_args()
    if a.extract.exists():
        raise ValueError('Fresh extraction required')
    if digest(a.bundle) != a.sha256:
        raise ValueError('Corresponding source bundle differs')
    with zipfile.ZipFile(a.bundle) as z:
        manifest = json.loads(z.read('corresponding_sources.json'))
        for name, pin in manifest['files'].items():
            destination = a.extract / name
            if not destination.resolve().is_relative_to(a.extract.resolve()):
                raise ValueError('Unsafe member')
            data = z.read(name)
            if hashlib.sha256(data).hexdigest() != pin['sha256']:
                raise ValueError('Source member differs: ' + name)
            if pin['kind'] == 'file':
                destination.parent.mkdir(parents=True, exist_ok=True)
                destination.write_bytes(data)
                destination.chmod(pin['mode'])
        for name, pin in manifest['files'].items():
            if pin['kind'] == 'symlink':
                destination = a.extract / name
                target = pin['target']
                if not (destination.parent / target).resolve().is_relative_to((a.extract / 'sources').resolve()):
                    raise ValueError('Unsafe source symlink')
                destination.parent.mkdir(parents=True, exist_ok=True)
                destination.symlink_to(target)
    recipe = a.extract / 'recipe/build_optional_helpers.py'
    spec = importlib.util.spec_from_file_location('offline_optional_producer', recipe)
    producer = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(producer)

    def source(name, args, pins):
        original = manifest['sources'][name]
        if original['pin'] != pins[name]:
            raise ValueError('Other upstream source identity')
        destination = args.root / name / 'source'
        shutil.copytree(a.extract / 'sources' / name, destination, symlinks=True)
        return destination / original['prefix']
    producer.source = source
    sys.argv = [str(recipe), *producer_args]
    producer.main()
if __name__ == '__main__':
    main()
