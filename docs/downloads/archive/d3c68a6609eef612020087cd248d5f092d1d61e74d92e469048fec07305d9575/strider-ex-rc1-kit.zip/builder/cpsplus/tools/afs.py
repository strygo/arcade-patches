"""AFS parser operating on a region inside a larger file (the ISO)."""
import sys, struct

def afs_entries(f, base):
    f.seek(base)
    hdr = f.read(8)
    assert hdr[:4] == b'AFS\x00', f'not AFS at 0x{base:x}: {hdr!r}'
    count = struct.unpack_from('<I', hdr, 4)[0]
    tab = f.read(8 * (count + 1))
    entries = [struct.unpack_from('<II', tab, 8 * i) for i in range(count)]
    toc = struct.unpack_from('<II', tab, 8 * count)
    return (count, entries, toc)

def read_names(f, base, count, toc):
    tocoff, tocsize = toc
    if tocoff == 0 or tocsize == 0:
        return None
    f.seek(base + tocoff)
    blk = f.read(tocsize)
    names = []
    for i in range(count):
        rec = blk[i * 48:(i + 1) * 48]
        name = rec[:32].split(b'\x00')[0].decode('ascii', 'replace')
        fsize = struct.unpack_from('<I', rec, 44)[0]
        names.append((name, fsize))
    return names
if __name__ == '__main__':
    iso = sys.argv[1]
    base = int(sys.argv[2], 0)
    size = int(sys.argv[3], 0)
    cmd = sys.argv[4]
    f = open(iso, 'rb')
    count, entries, toc = afs_entries(f, base)
    if cmd == 'list':
        print(f'AFS at 0x{base:x}: {count} entries, TOC at +0x{toc[0]:x} size 0x{toc[1]:x}')
        names = read_names(f, base, count, toc)
        for i, (o, s) in enumerate(entries):
            f.seek(base + o)
            head = f.read(16)
            nm = names[i][0] if names else ''
            print(f'#{i:4d} off=+0x{o:09x} size=0x{s:08x} ({s / 1048576:7.2f} MB) head={head.hex()} {nm}')
    elif cmd == 'dump':
        idx, out = (int(sys.argv[5]), sys.argv[6])
        o, s = entries[idx]
        f.seek(base + o)
        with open(out, 'wb') as w:
            left = s
            while left:
                c = f.read(min(left, 1 << 20))
                w.write(c)
                left -= len(c)
        print(f'dumped #{idx} ({s} bytes) -> {out}')
