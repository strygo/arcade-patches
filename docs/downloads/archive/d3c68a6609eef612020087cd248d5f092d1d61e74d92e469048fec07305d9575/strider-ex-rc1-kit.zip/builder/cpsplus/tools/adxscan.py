"""Scan ADX entries of an AFS-in-ISO and emit a TSV manifest with loop metadata."""
import sys, struct
from afs import afs_entries, read_names

def parse_adx(f, off):
    f.seek(off)
    h = f.read(64)
    if len(h) < 64 or h[0] != 128 or h[1] != 0:
        return None
    copyright_off, = struct.unpack_from('>H', h, 2)
    enc, frame, bits, ch = (h[4], h[5], h[6], h[7])
    rate, = struct.unpack_from('>I', h, 8)
    total, = struct.unpack_from('>I', h, 12)
    highpass, = struct.unpack_from('>H', h, 16)
    version, flags = (h[18], h[19])
    loop_flag = 0
    loop_start = loop_end = 0
    loop_start_byte = loop_end_byte = 0
    alignment = loop_count = 0
    if version == 3 and copyright_off + 4 >= 44:
        loop_flag, = struct.unpack_from('>I', h, 24)
        loop_start, = struct.unpack_from('>I', h, 28)
        loop_start_byte, = struct.unpack_from('>I', h, 32)
        loop_end, = struct.unpack_from('>I', h, 36)
        loop_end_byte, = struct.unpack_from('>I', h, 40)
    elif version == 4 and copyright_off + 4 >= 56:
        alignment, loop_count = struct.unpack_from('>HH', h, 32)
        loop_flag, = struct.unpack_from('>I', h, 36)
        loop_start, = struct.unpack_from('>I', h, 40)
        loop_start_byte, = struct.unpack_from('>I', h, 44)
        loop_end, = struct.unpack_from('>I', h, 48)
        loop_end_byte, = struct.unpack_from('>I', h, 52)
    return {'copyright_off': copyright_off, 'enc': enc, 'frame': frame, 'bits': bits, 'ch': ch, 'rate': rate, 'total': total, 'highpass': highpass, 'version': version, 'flags': flags, 'alignment': alignment, 'loop_count': loop_count, 'loop_flag': loop_flag, 'loop_start': loop_start, 'loop_end': loop_end, 'loop_start_byte': loop_start_byte, 'loop_end_byte': loop_end_byte, 'raw': h.hex()}
if __name__ == '__main__':
    iso, base, size = (sys.argv[1], int(sys.argv[2], 0), int(sys.argv[3], 0))
    f = open(iso, 'rb')
    count, entries, toc = afs_entries(f, base)
    names = read_names(f, base, count, toc)
    cols = 'idx name offset_in_afs size ver ch rate total_samples dur_s align loop_count loop_flag loop_start_sample loop_start_byte loop_end_sample loop_end_byte'.split()
    print('\t'.join(cols))
    for i, (o, s) in enumerate(entries):
        a = parse_adx(f, base + o)
        nm = names[i][0] if names else ''
        if a is None:
            print(f'{i}\t{nm}\t0x{o:x}\t{s}\tNOT_ADX')
            continue
        print('\t'.join((str(x) for x in (i, nm, f'0x{o:x}', s, a['version'], a['ch'], a['rate'], a['total'], f"{a['total'] / a['rate']:.2f}", a['alignment'], a['loop_count'], a['loop_flag'], a['loop_start'], a['loop_start_byte'], a['loop_end'], a['loop_end_byte']))))
