"""3DO SDX2 ("2:1 Squareroot-Delta-Exact") audio decoder."""
from __future__ import annotations
import sys
import numpy as np

def decode(data: bytes, channels: int=2) -> np.ndarray:
    """Decode an SDX2 byte stream to int16 samples, shape (frames, channels)."""
    if channels < 1:
        raise ValueError('channels must be >= 1')
    n = np.frombuffer(data, dtype=np.int8).astype(np.int64)
    n = n[:len(n) // channels * channels]
    step = n * np.abs(n) * 2
    out = np.empty(len(n), dtype=np.int64)
    for ch in range(channels):
        s = step[ch::channels]
        absolute = n[ch::channels] & 1 == 0
        csum = np.cumsum(s)
        last = np.maximum.accumulate(np.where(absolute, np.arange(len(s)), -1))
        before = np.where(last >= 0, csum[last] - s[last], 0)
        out[ch::channels] = csum - before
    if out.min() < -32768 or out.max() > 32767:
        out = _saturating(n, step, channels)
    return out.astype(np.int16).reshape(-1, channels)

def _saturating(n: np.ndarray, step: np.ndarray, channels: int) -> np.ndarray:
    out = np.empty(len(n), dtype=np.int64)
    for ch in range(channels):
        acc = 0
        col = out[ch::channels]
        for i, (b, s) in enumerate(zip(n[ch::channels].tolist(), step[ch::channels].tolist())):
            if not b & 1:
                acc = 0
            acc = max(-32768, min(32767, acc + s))
            col[i] = acc
        out[ch::channels] = col
    return out

def reference_decode(data: bytes, channels: int=2) -> np.ndarray:
    """Straight-line sample-by-sample decode: the definition above, used to"""
    acc = [0] * channels
    out = []
    for i, b in enumerate(np.frombuffer(data, dtype=np.int8).tolist()):
        ch = i % channels
        if not b & 1:
            acc[ch] = 0
        acc[ch] = max(-32768, min(32767, acc[ch] + b * abs(b) * 2))
        out.append(acc[ch])
    return np.array(out[:len(out) // channels * channels], dtype=np.int16).reshape(-1, channels)

def _self_test() -> None:
    mono = bytes(np.array([4, 3, -3, 0, 127, 127, -128, -1], dtype=np.int8))
    want = [32, 50, 32, 0, 32258, 32767, 0, -2]
    got = decode(mono, 1)[:, 0].tolist()
    want[6] = -32768
    want[7] = -32768
    assert got == want, (got, want)
    st = bytes(np.array([4, 6, 3, 5], dtype=np.int8))
    assert decode(st, 2).tolist() == [[32, 72], [50, 122]], decode(st, 2).tolist()
    rng = np.random.default_rng(7)
    for ch in (1, 2):
        for scale in (4, 40, 127):
            raw = bytes(rng.integers(-scale, scale + 1, 20000, dtype=np.int64).astype(np.int8))
            assert (decode(raw, ch) == reference_decode(raw, ch)).all(), (ch, scale)
    odd = bytes(np.full(10, 63, dtype=np.int8))
    assert decode(odd, 1)[:, 0].tolist() == [min(32767, 7938 * (k + 1)) for k in range(10)]
    print('sdx2 self-test OK')
if __name__ == '__main__':
    if '--self-test' in sys.argv:
        _self_test()
    else:
        print(__doc__)
