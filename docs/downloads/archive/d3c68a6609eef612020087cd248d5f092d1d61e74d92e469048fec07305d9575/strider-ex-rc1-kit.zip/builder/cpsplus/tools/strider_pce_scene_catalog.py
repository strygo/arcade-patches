"""Pin Strider PCE scene routing from disc tables and bounded source captures."""
from __future__ import annotations
import argparse
import csv
import hashlib
import json
from pathlib import Path
import re
import wave
import numpy as np
from scipy import signal
ROOT = Path(__file__).resolve().parents[2]
WORK = ROOT / 'cpsplus/work/strider/pce'
IMAGE_SHA = '4697a3eae018355b85240666702635066ec04192d99ebf6c94a8914bdda1fff1'
STAGES = [(0, 'St. Petersburg', 3735552, 8), (2, 'Siberia', 3997696, 9), (3, 'Aerial Battleship', 4259840, 9), (4, 'Amazon', 4521984, 5), (6, 'Third Moon', 4784128, 14), (1, 'PCE-only desert', 5046272, 5)]
SHOTS = [(3, 'checkpoints0_v3', 'checkpoint_02', 'St. Petersburg: elevator / midboss section'), (3, 'checkpoints2_v4', 'checkpoint_02', 'Siberia: mechanical gorilla encounter'), (4, 'checkpoints0_v3', 'checkpoint_08', 'St. Petersburg: Uroboros boss section'), (4, 'checkpoints2_v4', 'checkpoint_09', 'Siberia: final boss section'), (4, 'checkpoints3_v3', 'checkpoint_09', 'Aerial Battleship: final boss section'), (4, 'checkpoints4_v4', 'checkpoint_05', 'Amazon: final boss section'), (5, 'phase_stage_clear', 'phase_start', 'Stage 1 cleared'), (6, 'phase_continue', 'phase_start', 'Continue countdown'), (7, 'phase_continue', 'phase_late', 'Game Over after the countdown'), (8, 'checkpoints0_v3', 'checkpoint_01', 'St. Petersburg: starting rooftops'), (9, 'checkpoints0_v3', 'checkpoint_04', 'St. Petersburg: later city section'), (9, 'checkpoints0_v3', 'checkpoint_05', 'St. Petersburg: palace roofs'), (10, 'checkpoints1_v3', 'checkpoint_01', 'PCE-only desert stage'), (12, 'checkpoints2_v4', 'checkpoint_04', 'Siberia: downhill escape'), (13, 'checkpoints2_v4', 'checkpoint_01', 'Siberia: snowy approach'), (13, 'checkpoints2_v4', 'checkpoint_03', 'Siberia: vertical shaft after the gorilla'), (13, 'checkpoints2_v4', 'checkpoint_06', 'Siberia: later mountain section'), (14, 'checkpoints3_v3', 'checkpoint_01', 'Aerial Battleship: exterior approach'), (14, 'checkpoints3_v3', 'checkpoint_04', 'Aerial Battleship: earlier ship section'), (15, 'checkpoints3_v3', 'checkpoint_05', 'Aerial Battleship: interior section'), (15, 'checkpoints3_v3', 'checkpoint_06', 'Aerial Battleship: gravity-core section'), (16, 'checkpoints4_v4', 'checkpoint_01', 'Amazon: opening jungle section'), (16, 'checkpoints4_v4', 'checkpoint_02', 'Amazon: village / early jungle'), (17, 'checkpoints4_v4', 'checkpoint_04', 'Amazon: treetops and flying creatures'), (18, 'checkpoints6_v3', 'checkpoint_05', 'Third Moon: gravity room and later interior'), (19, 'checkpoints6_v3', 'checkpoint_01', 'Third Moon: opening platforms'), (20, 'final_room', 'final_room', 'Third Moon: laser platforms before the final encounter'), (21, 'caller_trace', 'title', 'Title / opening prologue'), (22, 'scene_recheck', 'stage_intro', 'St. Petersburg mission introduction'), (23, 'stage1_trace', 'intro1', 'PCE-only desert introduction'), (24, 'checkpoints2_v4', 'intro2', 'Siberian mission introduction'), (25, 'checkpoints3_v3', 'intro2', 'Aerial Battleship mission introduction'), (26, 'checkpoints4_v4', 'intro2', 'Amazon mission introduction'), (27, 'stage5_trace', 'intro2', 'Flight from Earth to the Third Moon'), (28, 'stage5_trace', 'transition', 'Meio welcomes Hiryu before Third Moon gameplay'), (29, 'phase_ending', 'after', 'Ending and staff credits')]

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def rel(path):
    return str(path.relative_to(ROOT))

def bcd(value):
    assert 0 <= value <= 153 and value & 15 < 10 and (value >> 4 < 10)
    return (value >> 4) * 10 + (value & 15)

def cd_commands(text):
    commands = []
    start = end = op = None
    for line in text.splitlines():
        if '0xd8 SET AUDIO' in line:
            op = 'start'
        elif '0xd9 SET AUDIO' in line:
            op = 'end'
        elif (match := re.search('TRACK=(\\d+)', line)):
            if op == 'start':
                start = int(match[1])
            elif op == 'end':
                end = int(match[1])
        elif op == 'end' and (match := re.search('Play mode = (\\d+)', line)):
            assert start is not None and end == start + 1
            commands.append(dict(track=start, end_track=end, play_mode=int(match[1])))
            op = None
    return commands

def trace_events(rows):
    events = []
    for r in rows:
        if r['kind'] != 'pce_write' or int(r['pc'], 16) not in (33105, 18109, 36705, 36728):
            continue
        v = {k: int(value, 16) for k, value in (x.split('=') for x in r['label'].split(','))}
        track = bcd(v['ram0f8'])
        mode = v.get('1f00ff', v['ram0ff']) & 15
        end = bcd(v.get('1f00fc', v['ram0fc']))
        assert end == track + 1 and mode in (1, 2)
        events.append(dict(track=track, end_track=end, play_mode=mode, frame=int(r['frame']), seconds=float(r['time']), caller_pc=r['pc'], chapter=v.get('ram0c1'), subarea=v['ramd0b']))
    return events

def stage_tables(image):
    tables = []
    signature = bytes.fromhex('851da61dbd598185f8bd748185fca98085fba98185ff2012e0c900d0e560')
    for chapter, name, base, count in STAGES:
        assert image[base + 315:base + 345] == signature
        assert [bcd(v) for v in image[base + 345:base + 372]] == list(range(3, 30))
        assert [bcd(v) for v in image[base + 372:base + 399]] == list(range(4, 31))
        code = image[base:base + 8192]
        at = code.index(bytes.fromhex('ae0b2dbd'))
        music = int.from_bytes(code[at + 4:at + 6], 'little')
        assert code[at + 6:at + 9] == bytes.fromhex('203b82')
        assert code[399:408] == bytes.fromhex('ad852c3aa20a20cd4d')
        assert code[411] == code[417] == 105
        checkpoints = code[412] | code[418] << 8
        tracks = [v + 3 for v in code[music - 32768:checkpoints - 32768]]
        assert all((3 <= t <= 29 for t in tracks))
        records = []
        for i in range(count):
            record = code[checkpoints - 32768 + i * 10:checkpoints - 32768 + (i + 1) * 10]
            assert record[1] < len(tracks)
            records.append(dict(checkpoint=i + 1, subarea=record[1], track=tracks[record[1]]))
        tables.append(dict(chapter=chapter, scene=name, overlay_file_offset=hex(base), music_table_cpu=hex(music), checkpoint_table_cpu=hex(checkpoints), tracks_by_subarea=tracks, checkpoints=records, sha256=hashlib.sha256(code).hexdigest()))
    assert image[5308731:5308761] == signature
    assert image[5555901:5555904] == bytes.fromhex('2012e0')
    return tables

def mono6k(path):
    with wave.open(str(path)) as w:
        assert w.getsampwidth() == 2
        rate = w.getframerate()
        audio = np.frombuffer(w.readframes(w.getnframes()), '<i2').astype(float)
        audio = audio.reshape(-1, w.getnchannels()).mean(axis=1) / 32768
    return signal.resample_poly(audio, 6000, rate)

def match_audio(capture, source):
    n = len(source)
    assert len(capture) >= n and np.dot(source, source) > 0
    corr = signal.correlate(capture, source, mode='valid', method='fft')
    energy = signal.convolve(capture * capture, np.ones(n), mode='valid', method='fft')
    score = np.abs(corr) / np.sqrt(np.maximum(energy, 1e-12) * np.dot(source, source))
    i = int(np.argmax(score))
    return (float(score[i]), i)

def short_cues():
    result = []
    for name, expected in [('phase_stage_clear', [5]), ('phase_continue', [6, 7])]:
        path = WORK / name / 'audio.wav'
        capture = mono6k(path)[67 * 6000:95 * 6000]
        comparisons = []
        for track in (5, 6, 7):
            source_path = ROOT / f'cpsplus/work/listening/strider/cd_full/tr{track:02}.wav'
            source = mono6k(source_path)[:8 * 6000]
            score, at = match_audio(capture, source)
            comparisons.append(dict(track=track, correlation=score, source_start_seconds=0, capture_start_seconds=67 + at / 6000, source_sha256=digest(source_path)))
            assert (score > 0.75) == (track in expected)
        result.append(dict(run=name, capture_sha256=digest(path), matches=comparisons, method='First eight seconds, mono 6 kHz, normalized waveform correlation at original speed; other short cues are controls.'))
    return result

def self_test():
    assert bcd(41) == 29
    try:
        bcd(42)
    except AssertionError:
        pass
    else:
        raise AssertionError('invalid BCD accepted')
    fixture = '0xd8 SET AUDIO\nTRACK=28\nPlay mode = 0\n0xd9 SET AUDIO\nTRACK=29\nPlay mode = 2'
    assert cd_commands(fixture) == [dict(track=28, end_track=29, play_mode=2)]
    source = np.random.default_rng(7).normal(size=1200)
    target = np.r_[np.zeros(127), source, np.zeros(200)]
    score, at = match_audio(target, source)
    assert score > 0.999999 and at == 127

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output', type=Path, default=ROOT / 'cpsplus/manifests/strider_pce_scene_usage.json')
    p.add_argument('--self-test', action='store_true')
    a = p.parse_args()
    if a.self_test:
        self_test()
        print('Strider PCE scene catalog self-tests passed')
        return
    image_path = WORK / 'analysis/track02_user.bin'
    assert digest(image_path) == IMAGE_SHA
    image = image_path.read_bytes()
    tables = stage_tables(image)
    runs = {}
    for name in sorted({r[1] for r in SHOTS}):
        folder = WORK / name
        assert 'Average speed:' in (folder / 'run.log').read_text(), name
        completion = json.loads((folder / 'completion.json').read_text())
        assert completion['exit_code'] == 0, name
        rows = list(csv.DictReader((folder / 'pce_trace.tsv').open(), delimiter='\t'))
        commands = cd_commands((folder / 'error.log').read_text())
        events = trace_events(rows)
        if events:
            assert [{k: r[k] for k in ('track', 'end_track', 'play_mode')} for r in events] == commands, name
        runs[name] = dict(invocation=json.loads((folder / 'invocation.json').read_text()), invocation_sha256=digest(folder / 'invocation.json'), trace_sha256=digest(folder / 'pce_trace.tsv'), log_sha256=digest(folder / 'error.log'), completion=completion, commands=commands, events=events)
    tracks = {f'pce_{t:02}': dict(disc_track=t, scenes=[]) for t in range(3, 30)}
    for track, run, label, caption in SHOTS:
        folder = WORK / run
        path, = folder.glob(f'pce_*_{label}.png')
        frame = int(path.name.split('_')[1])
        rows = list(csv.DictReader((folder / 'pce_trace.tsv').open(), delimiter='\t'))
        capture, = (r for r in rows if r['kind'] == 'capture' and int(r['frame']) == frame)
        if track not in (5, 6, 7):
            earlier = [r for r in runs[run]['events'] if r['frame'] <= frame]
            if earlier:
                assert earlier[-1]['track'] == track, (run, label, earlier[-1])
        tracks[f'pce_{track:02}']['scenes'].append(dict(caption=caption, run=run, file=rel(path), sha256=digest(path), frame=frame, seconds=float(capture['time']), evidence='captured_audio_match' if track in (5, 6, 7) else 'cd_command_and_scene'))
    tracks['pce_11']['note'] = 'Desert subareas 2–3 select track 11 in the disc table; not used by the arcade pack.'
    result = dict(status='source_scene_routing_researched', date='2026-09-05', image=dict(file=rel(image_path), sha256=IMAGE_SHA, pregap_sectors_included=225), scope='Source-use evidence and review mapping proposals. Assisted stage/checkpoint/outcome entries are not natural-transition or pack acceptance.', corrections=['Seven gameplay-style CD_PLAY copies, plus the menu copy; the older report named only four.', 'Gameplay music routine starts at $813b; its CD_PLAY call is $8151, not $8165.', 'Track 27 is the Earth-to-Moon flight; track 28 is the subsequent Meio dialogue matching arcade 0x1f.', 'Third Moon starts with track 19, changes to 18 for its interior, then 20 for the final sequence.'], stage_tables=tables, runs=runs, tracks=tracks, short_cue_audio_matches=short_cues(), excluded_evidence=['stage1_trace/stage2_trace/stage3_trace/stage4_trace gameplay after an initial chapter-only override had an incorrect asset cache; only their intact intro scenes may be used.', 'checkpoints4_v3 completed captures but stalled during CoreAudio shutdown; checkpoints4_v4 is the completed replacement.', 'Incomplete checkpoint sweeps do not prove all transitions. Only listed captures and observed music events are used.'])
    a.output.write_text(json.dumps(result, indent=2, ensure_ascii=False) + '\n')
    print('Verified', len(runs), 'runs and', len(SHOTS), 'scene captures;', a.output)
if __name__ == '__main__':
    main()
