"""Recover complete Strider PSX XA sectors and compare musical references."""
import argparse
import csv
import hashlib
import json
from pathlib import Path
import subprocess
import wave
import numpy as np
from scipy import signal
ROOT = Path(__file__).resolve().parents[2]

def read_mono(path, start=0, duration=None):
    with wave.open(str(path)) as f:
        rate = f.getframerate()
        f.setpos(round(start * rate))
        x = np.frombuffer(f.readframes(round(duration * rate) if duration else f.getnframes()), '<i2')
        x = x.reshape(-1, f.getnchannels()).astype(float).mean(1) / 32768
    return signal.resample_poly(x, 5512, rate)

def feature(x):
    _, _, z = signal.stft(x, 5512, nperseg=512, noverlap=384, boundary=None)
    z = np.log1p(abs(z[2:220]) * 500)
    z -= z.mean(0)
    z /= np.maximum(np.linalg.norm(z, axis=0), 1e-08)
    return z

def matches(x, arcade):
    found = []
    for cmd, y in arcade:
        n = min(86, x.shape[1], y.shape[1])
        best = (-1, 0, 0)
        for i in range(0, y.shape[1] - n + 1, 22):
            c = np.zeros(x.shape[1] - n + 1)
            for p, q in zip(x, y[:, i:i + n]):
                c += signal.correlate(p, q, mode='valid', method='fft')
            j = int(np.argmax(c))
            score = c[j] / n
            if score > best[0]:
                best = (float(score), i * 128 / 5512, j * 128 / 5512)
        found.append(dict(command=f'0x{cmd:02x}', spectral_match=best[0], arcade_seconds=best[1], xa_seconds=best[2]))
    return sorted(found, key=lambda r: r['spectral_match'], reverse=True)[:3]

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--work', type=Path, default=ROOT / 'cpsplus/work/strider')
    p.add_argument('--outdir', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    a = p.parse_args()
    a.outdir.mkdir(parents=True, exist_ok=True)
    inv = json.loads((ROOT / 'cpsplus/manifests/strider_source_inventory.json').read_text())
    rec = next((r for r in inv['psx']['files'] if r['file'] == '/SOUND/XA/37XA16.XAP'))
    with (a.work / 'sources/psx/strider.bin').open('rb') as f:
        f.seek(rec['lba'] * 2352)
        raw = f.read((rec['bytes'] + 2047) // 2048 * 2352)
    sectors = [raw[i:i + 2352] for i in range(0, len(raw), 2352)]
    assert all((len(s) == 2352 and s[15] == 2 and (s[16:20] == s[20:24]) for s in sectors))
    iso = b''.join((s[24:24 + 2048] for s in sectors))[:rec['bytes']]
    assert hashlib.sha256(iso).hexdigest() == rec['sha256']
    arcade = []
    for r in csv.DictReader((a.work / 'native/census_taps/events.tsv').open(), delimiter='\t'):
        if r['kind'] == 'inject' and int(r['cmd']) < 48:
            arcade.append((int(r['cmd']), feature(read_mono(a.work / 'native/census_taps/audio.wav', float(r['time']) + 0.05, 7.7))))
    rows = []
    for channel in sorted({s[17] for s in sectors if s[18] & 4}):
        selected = [s for s in sectors if s[17] == channel and s[18] & 4]
        assert all((s[16] == 1 and s[19] == 0 and s[18] & 32 for s in selected))
        path = a.outdir / f'ch{channel:02}.xa'
        path.write_bytes(b''.join(selected))
        subprocess.run(['ffmpeg', '-v', 'error', '-y', '-i', str(path), str(path.with_suffix('.wav'))], check=True)
        with wave.open(str(path.with_suffix('.wav'))) as f:
            rate, channels, frames = (f.getframerate(), f.getnchannels(), f.getnframes())
        assert rate == 37800 and channels == 1 and (frames == len(selected) * 4032)
        row = dict(channel=channel, sector_count=len(selected), sample_rate=rate, channels=channels, frames=frames, seconds=frames / rate, raw_sha256=hashlib.sha256(path.read_bytes()).hexdigest(), pcm_file=str(path.with_suffix('.wav').absolute().relative_to(ROOT)), pcm_sha256=hashlib.sha256(path.with_suffix('.wav').read_bytes()).hexdigest(), content_matches=matches(feature(read_mono(path.with_suffix('.wav'))), arcade), scene_routing='pending', pack_use='reference_only_no_new_arrangement_claimed')
        rows.append(row)
        print(channel, row['content_matches'][0], flush=True)
    result = dict(status='source_decoded_content_comparison_scene_routing_pending', chd_sha256=next((r['sha256'] for r in inv['inputs'] if r['path'].endswith('Strider (USA).chd'))), xa_iso_record=rec, complete_sector_sha256=hashlib.sha256(raw).hexdigest(), streams=rows)
    a.output.parent.mkdir(parents=True, exist_ok=True)
    a.output.write_text(json.dumps(result, indent=2) + '\n')
if __name__ == '__main__':
    main()
