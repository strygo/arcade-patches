"""Run bounded, focus-safe Strider probes through the repository trace runner."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
ROOT = Path(__file__).resolve().parents[2]
CENSUS = list(range(30)) + [31, 32, 34]

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--machine', choices=['striderua', 'striderjr'], default='striderua')
    p.add_argument('--mode', choices=['census', 'quiet', 'live', 'custom'], default='census')
    p.add_argument('--outdir', type=Path, required=True)
    p.add_argument('--schedule', default='')
    p.add_argument('--read-overrides', default='')
    p.add_argument('--start-stage', type=int, choices=range(5))
    p.add_argument('--post-pokes', default='')
    p.add_argument('--events', default='', help='frame:byte;frame:byte (custom mode)')
    p.add_argument('--captures', default='')
    args = p.parse_args()
    out = args.outdir.resolve()
    out.mkdir(parents=True, exist_ok=True)
    if (out / 'run.log').exists():
        p.error('choose a fresh output directory; prior evidence is preserved')
    if args.mode == 'census':
        events = ';'.join((f'{1120 + 600 * i}:0x{c:02x};{1600 + 600 * i}:0xf0' for i, c in enumerate(CENSUS)))
        captures = '1050=quiet;20920=end'
    else:
        events = args.events if args.mode == 'custom' else ''
        captures = '1050=quiet;1800=end' if args.mode == 'quiet' else '1000=boot;3600=end'
    captures = args.captures or captures
    env = os.environ | dict(SDL_VIDEODRIVER='dummy', SDL_AUDIODRIVER='dummy', CPSP_REPO=str(ROOT), STRIDER_LOG=str(out / 'events.tsv'), STRIDER_EVENTS=events, STRIDER_START_STAGE=str(args.start_stage if args.start_stage is not None else -1), STRIDER_FREEZE_FRAME='0' if args.mode == 'live' else '1000', STRIDER_CAPTURE_YM='0' if args.mode == 'live' else '1')
    cmd = [sys.executable, str(ROOT / 'translations/vhunt2/scripts/run_surface_trace.py'), '--machine', args.machine, '--outdir', str(out), '--script', str(ROOT / 'cpsplus/lua/strider_sound_probe.lua'), '--schedule', args.schedule, '--captures', captures, '--dump-range', '0xff0c00:0x600', '--read-overrides', args.read_overrides, '--post-pokes', args.post_pokes]
    for x in ['-nothrottle', '-video', 'none', '-cfg_directory', str(out / 'cfg'), '-nvram_directory', str(out / 'nvram'), '-wavwrite', str(out / 'audio.wav')]:
        cmd.append('--mame-arg=' + x)
    (out / 'invocation.json').write_text(json.dumps(dict(command=cmd, events=events, mode=args.mode), indent=2) + '\n')
    with (out / 'run.log').open('w') as log:
        result = subprocess.run(cmd, env=env, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT)
    print(f"{args.machine} {args.mode}: exit {result.returncode}; {out / 'run.log'}")
    raise SystemExit(result.returncode)
if __name__ == '__main__':
    main()
