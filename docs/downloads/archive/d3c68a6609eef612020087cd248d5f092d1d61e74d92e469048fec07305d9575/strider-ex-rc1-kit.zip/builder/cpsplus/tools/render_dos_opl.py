"""Render the MS-DOS SSF2T `_F` sequences on Nuked OPL3 as loop-tagged FLAC."""
from __future__ import annotations
import argparse
from ffmpeg_runtime import Executable
import ctypes
import hashlib
import json
import subprocess
import sys
from pathlib import Path
import numpy as np
TOOLS = Path(__file__).resolve().parent
REPO = TOOLS.parent.parent
sys.path.insert(0, str(TOOLS))
import hmp as hmp_mod
from hmp2smf import device_for
OUTPUT_RATE = 49716
CHANNELS = 2
UNROLL_PASSES = 1
STEADY_PASS = 1
ONESHOT_TAIL_SECONDS = 3.0
CHIPS = 1
FOUR_OPS = 0
DEFAULT_LIBRARY = REPO / 'cpsplus' / 'work' / 'dos' / 'upstream' / 'libADLMIDI' / 'build' / 'libADLMIDI.dylib'
ADLMIDI_VOLUME_MODEL_HMI = 10
ADLMIDI_EMU_NUKED = 0

class RenderError(RuntimeError):
    pass

def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open('rb') as handle:
        for block in iter(lambda: handle.read(1 << 20), b''):
            digest.update(block)
    return digest.hexdigest()

def render_native(library: Path, bank: Path, midi: Path) -> np.ndarray:
    """libADLMIDI's output at the chip's own rate, shape (frames, 2)."""
    adl = ctypes.CDLL(str(library))
    adl.adl_init.restype = ctypes.c_void_p
    adl.adl_init.argtypes = [ctypes.c_long]
    adl.adl_errorInfo.restype = ctypes.c_char_p
    adl.adl_errorInfo.argtypes = [ctypes.c_void_p]
    for name, args in (('adl_openBankFile', [ctypes.c_void_p, ctypes.c_char_p]), ('adl_openFile', [ctypes.c_void_p, ctypes.c_char_p]), ('adl_setNumChips', [ctypes.c_void_p, ctypes.c_int]), ('adl_setVolumeRangeModel', [ctypes.c_void_p, ctypes.c_int]), ('adl_switchEmulator', [ctypes.c_void_p, ctypes.c_int]), ('adl_setNumFourOpsChn', [ctypes.c_void_p, ctypes.c_int]), ('adl_setLoopEnabled', [ctypes.c_void_p, ctypes.c_int])):
        getattr(adl, name).argtypes = args
        getattr(adl, name).restype = ctypes.c_int
    adl.adl_play.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.POINTER(ctypes.c_short)]
    adl.adl_play.restype = ctypes.c_int
    adl.adl_close.argtypes = [ctypes.c_void_p]
    device = adl.adl_init(OUTPUT_RATE)
    if not device:
        raise RenderError('adl_init failed')
    try:

        def check(result: int, what: str) -> None:
            if result < 0:
                info = adl.adl_errorInfo(device)
                raise RenderError(f"{midi.name}: {what}: {(info.decode(errors='replace') if info else 'failed')}")
        check(adl.adl_switchEmulator(device, ADLMIDI_EMU_NUKED), 'select Nuked OPL3')
        check(adl.adl_setNumChips(device, CHIPS), 'set chip count')
        check(adl.adl_setNumFourOpsChn(device, FOUR_OPS), 'set four-op channels')
        adl.adl_setVolumeRangeModel(device, ADLMIDI_VOLUME_MODEL_HMI)
        adl.adl_setLoopEnabled(device, 0)
        check(adl.adl_openBankFile(device, str(bank).encode()), 'load the WOPL bank')
        check(adl.adl_openFile(device, str(midi).encode()), 'load the MIDI')
        block = 4096
        buffer = (ctypes.c_short * block)()
        chunks: list[bytes] = []
        while True:
            got = adl.adl_play(device, block, buffer)
            if got <= 0:
                break
            chunks.append(bytes(buffer)[:got * 2])
    finally:
        adl.adl_close(device)
    audio = np.frombuffer(b''.join(chunks), dtype='<i2')
    if audio.size % CHANNELS:
        raise RenderError(f'{midi.name}: output ends mid-frame')
    if not audio.size:
        raise RenderError(f'{midi.name}: renderer produced no audio')
    return audio.reshape(-1, CHANNELS)

def write_flac(pcm: np.ndarray, dest: Path, tags: dict[str, int]) -> None:
    args = [Executable('ffmpeg'), '-hide_banner', '-loglevel', 'error', '-y', '-f', 's16le', '-ar', str(OUTPUT_RATE), '-ac', str(CHANNELS), '-i', 'pipe:0', '-c:a', 'flac']
    for key, value in tags.items():
        args += ['-metadata', f'{key}={value}']
    args.append(str(dest))
    proc = subprocess.run(args, input=pcm.tobytes(), capture_output=True)
    if proc.returncode != 0:
        raise RenderError(f"{dest.name}: ffmpeg exited {proc.returncode}: {proc.stderr.decode(errors='replace')[-400:]}")

def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('midi_dir', help='directory of .HMP files')
    ap.add_argument('--bank', required=True, type=Path, help='WOPL bank from tools/bnk2wopl.py')
    ap.add_argument('--out-dir', required=True)
    ap.add_argument('--songs', nargs='*', help='stems to render (default: all _F)')
    ap.add_argument('--library', type=Path)
    from tool_controls import add_arguments, configure
    add_arguments(ap)
    a = ap.parse_args(argv)
    configure(argv if argv is not None else __import__('sys').argv[1:])
    if not a.bank.is_file():
        raise SystemExit(f"missing WOPL bank: {a.bank}\nmake it with tools/bnk2wopl.py from the disc's DRV/MELODIC.BNK and DRV/DRUM.BNK")
    from fetch_optional_tools import resolve
    a.library = a.library or resolve('adlmidi')
    if not a.library.is_file():
        raise SystemExit(f'Helper not found: {a.library}')
    midi_dir = Path(a.midi_dir)
    out_dir = Path(a.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    smf_dir = out_dir / 'smf'
    smf_dir.mkdir(exist_ok=True)
    stems = a.songs or sorted((p.stem for p in midi_dir.iterdir() if p.suffix.upper() == '.HMP' and device_for(p.stem) == 'none'))
    report = []
    for stem in stems:
        song = hmp_mod.parse(midi_dir / f'{stem}.HMP')
        if device_for(stem) != 'none':
            raise SystemExit(f'{stem}: not an OPL sequence')
        loop = hmp_mod.loop_samples(song, OUTPUT_RATE, reset='none', pass_index=STEADY_PASS)
        smf = smf_dir / f'{stem}.mid'
        smf.write_bytes(hmp_mod.to_smf(song, reset='none', unroll_passes=UNROLL_PASSES, tail_seconds=0.0 if loop is not None else ONESHOT_TAIL_SECONDS))
        pcm = render_native(a.library, a.bank, smf)
        tags: dict[str, int] = {}
        if loop is not None:
            start, end = loop
            if start <= OUTPUT_RATE:
                raise RenderError(f'{stem}: loop starts {start} samples in, too early to leave a one-second crossfade tail before it')
            if end > len(pcm):
                raise RenderError(f'{stem}: loop ends at {end} but the render is only {len(pcm)} frames')
            pcm = pcm[:end]
            tags = {'LOOPSTART': start, 'LOOPEND': end, 'LOOPLENGTH': end - start}
        dest = out_dir / f'{stem}.flac'
        write_flac(pcm, dest, tags)
        kind = f"loop {tags['LOOPSTART']}..{tags['LOOPEND']}" if tags else 'one-shot'
        print(f'{stem:12s} {len(pcm) / OUTPUT_RATE:7.2f}s  {dest.stat().st_size / 1000000.0:6.2f} MB  {kind}')
        report.append({'song': stem, 'frames': int(len(pcm)), 'tags': tags, 'sha256': _sha256(dest)})
    (out_dir / 'render_report.json').write_text(json.dumps({'library_sha256': _sha256(a.library), 'bank_sha256': _sha256(a.bank), 'emulator': 'Nuked OPL3', 'chips': CHIPS, 'volume_model': 'HMI Sound Operating System', 'rate': OUTPUT_RATE, 'songs': report}, indent=2), encoding='utf-8')
    print(f'\n{len(report)} songs -> {out_dir}')
    return 0
if __name__ == '__main__':
    sys.exit(main())
