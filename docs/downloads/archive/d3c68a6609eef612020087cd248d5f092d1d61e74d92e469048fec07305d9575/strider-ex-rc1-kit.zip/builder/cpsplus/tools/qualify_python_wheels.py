"""Install the matching wheel bundle in a fresh venv and check NumPy/Pillow."""
import argparse
import hashlib
import json
from pathlib import Path
import platform
import shutil
import subprocess
import sys
import zipfile
CHECK = 'import hashlib,json,numpy as np\nfrom PIL import Image\nvalues=np.arange(256,dtype=np.uint8).reshape(16,16)\nresult=np.matmul(np.arange(9,dtype=np.int64).reshape(3,3),np.eye(3,dtype=np.int64))\nassert result.tolist()==[[0,1,2],[3,4,5],[6,7,8]]\nimage=Image.fromarray(values).resize((32,32),Image.Resampling.NEAREST)\nprint(json.dumps(dict(numpy=np.__version__,pillow=Image.__version__,pixels_sha256=hashlib.sha256(image.tobytes()).hexdigest())))\n'

def main(a):
    if a.work.exists():
        raise ValueError('Fresh work required')
    a.work.mkdir(parents=True)
    folder = a.work / 'wheels'
    folder.mkdir()
    with zipfile.ZipFile(a.bundle) as z:
        for name in z.namelist():
            if Path(name).name != name:
                raise ValueError('Unexpected wheel member')
        z.extractall(folder)
    env = a.work / 'venv'
    subprocess.run([sys.executable, '-m', 'venv', str(env)], check=True)
    python = env / ('Scripts/python.exe' if sys.platform == 'win32' else 'bin/python')
    subprocess.run([str(python), '-m', 'pip', 'install', '--disable-pip-version-check', '--no-index', '--find-links', str(folder), '--require-hashes', '-r', str(folder / 'requirements.txt')], check=True)
    result = json.loads(subprocess.check_output([str(python), '-c', CHECK], text=True))
    assert result['numpy'] == '2.2.6' and result['pillow'] == '11.3.0'
    report = dict(status='passed', python=sys.version, platform=platform.platform(), result=result, bundle_sha256=hashlib.sha256(a.bundle.read_bytes()).hexdigest(), recipe_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
    a.out.write_text(json.dumps(report, indent=2) + '\n')
    shutil.rmtree(a.work)
    print('PASS offline NumPy/Pillow wheels')
if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    for name in ('bundle', 'work', 'out'):
        p.add_argument('--' + name, type=Path, required=True)
    a = p.parse_args()
    for name, value in vars(a).items():
        setattr(a, name, value.absolute())
    main(a)
