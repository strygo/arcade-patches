"""Negative and cold/offline-cache acceptance for the recipient helper loader."""
import io
import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import zipfile
import fetch_switch_tools as fetch

class Helpers(unittest.TestCase):

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name).resolve()
        self.manifest = self.root / 'lock.json'
        self.files = {'bin/nstool': b'nstool-fixture', 'bin/switch_opus_decode': b'decoder-fixture', 'licenses/LICENSE': b'license'}
        self.data = self.zip(self.files)
        self.record = dict(filename='helpers.zip', bytes=len(self.data), sha256=fetch.sha(self.data), url='https://example.invalid/pinned/helpers.zip', files={n: fetch.sha(d) for n, d in self.files.items()}, executables={'nstool': 'bin/nstool', 'decoder': 'bin/switch_opus_decode'})
        self.manifest.write_text(json.dumps(dict(schema=1, platforms={'test': self.record})))
        self.env = patch.dict(os.environ, {'CPSPLUS_SWITCH_TOOLS_CACHE': str(self.root / 'cache'), 'CPSPLUS_SWITCH_TOOLS_BUNDLE': '', 'CPSPLUS_SWITCH_TOOLS_OFFLINE': ''})
        self.env.start()
        self.addCleanup(self.env.stop)

    def zip(self, files):
        b = io.BytesIO()
        with zipfile.ZipFile(b, 'w') as z:
            for n, d in files.items():
                z.writestr(n, d)
        return b.getvalue()

    def setup(self):
        return fetch.setup(manifest=self.manifest, host='test')

    def test_cold_download_then_offline_cache(self):
        with patch.object(fetch, 'download', return_value=self.data) as download:
            tools = self.setup()
            self.assertEqual(download.call_count, 1)
        os.environ['CPSPLUS_SWITCH_TOOLS_OFFLINE'] = '1'
        with patch.object(fetch, 'download', side_effect=AssertionError('network')):
            self.assertEqual(tools, self.setup())
        self.assertEqual(tools['decoder'].read_bytes(), self.files['bin/switch_opus_decode'])

    def test_offline_empty_cache(self):
        os.environ['CPSPLUS_SWITCH_TOOLS_OFFLINE'] = '1'
        with patch.object(fetch, 'download', side_effect=AssertionError('network')):
            with self.assertRaisesRegex(fetch.SetupError, 'not cached'):
                self.setup()

    def test_all_host_offline_bundle(self):
        bundle = self.root / 'offline.zip'
        bundle.write_bytes(self.zip({'helpers.zip': self.data, 'README.txt': b'offline'}))
        os.environ['CPSPLUS_SWITCH_TOOLS_BUNDLE'] = str(bundle)
        with patch.object(fetch, 'download', side_effect=AssertionError('network')):
            self.setup()

    def test_corrupt_download_no_cache(self):
        with patch.object(fetch, 'download', return_value=self.data[:-1]):
            with self.assertRaisesRegex(fetch.SetupError, 'hash/size'):
                self.setup()
        self.assertFalse((self.root / 'cache').exists())

    def test_modified_cache_rejected(self):
        with patch.object(fetch, 'download', return_value=self.data):
            tools = self.setup()
        tools['nstool'].write_bytes(b'tamper')
        with self.assertRaisesRegex(fetch.SetupError, 'cache changed'):
            self.setup()

    def test_incomplete_cache_rejected(self):
        with patch.object(fetch, 'download', return_value=self.data):
            tools = self.setup()
        tools['decoder'].unlink()
        with self.assertRaisesRegex(fetch.SetupError, 'inventory'):
            self.setup()

    def test_unavailable_host(self):
        with self.assertRaisesRegex(fetch.SetupError, 'No qualified'):
            fetch.setup(manifest=self.manifest, host='unknown')

    def test_wrong_offline_bundle(self):
        bundle = self.root / 'offline.zip'
        bundle.write_bytes(self.zip({'wrong-host.zip': self.data}))
        os.environ['CPSPLUS_SWITCH_TOOLS_BUNDLE'] = str(bundle)
        with self.assertRaisesRegex(fetch.SetupError, 'lacks'):
            self.setup()

    def test_unsafe_inventory(self):
        for name in ('../escape', '/absolute', 'C:/escape', 'bin\\escape', 'bin//escape'):
            data = self.zip({name: b'x'})
            r = {**self.record, 'sha256': fetch.sha(data), 'bytes': len(data)}
            with self.assertRaises(fetch.SetupError):
                fetch.inventory(data, r)

    def test_symlink_inventory(self):
        b = io.BytesIO()
        with zipfile.ZipFile(b, 'w') as z:
            i = zipfile.ZipInfo('link')
            i.create_system = 3
            i.external_attr = 41471 << 16
            z.writestr(i, '/elsewhere')
        data = b.getvalue()
        r = {**self.record, 'sha256': fetch.sha(data), 'bytes': len(data)}
        with self.assertRaisesRegex(fetch.SetupError, 'member type'):
            fetch.inventory(data, r)

    def test_https_downgrade_rejected(self):
        redirect = fetch.HTTPSOnlyRedirect()
        with self.assertRaisesRegex(fetch.SetupError, 'Insecure helper redirect'):
            redirect.redirect_request(None, None, 302, 'redirect', {}, 'http://example.invalid/tool')

    def test_http_rejected(self):
        with self.assertRaisesRegex(fetch.SetupError, 'HTTPS'):
            fetch.download('http://example.invalid/tool', 1)
if __name__ == '__main__':
    unittest.main()
