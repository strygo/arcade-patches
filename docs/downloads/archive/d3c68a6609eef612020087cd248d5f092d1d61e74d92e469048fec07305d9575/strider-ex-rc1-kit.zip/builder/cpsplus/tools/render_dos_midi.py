"""Render the MS-DOS SSF2T `_G` sequences on an SC-55 as loop-tagged FLAC."""
from __future__ import annotations
import argparse
from ffmpeg_runtime import Executable
import hashlib
import json
import shutil
import tempfile
import subprocess
import sys
from pathlib import Path
import numpy as np
TOOLS = Path(__file__).resolve().parent
REPO = TOOLS.parent.parent
sys.path.insert(0, str(TOOLS))
sys.path.insert(0, str(TOOLS.parent))
import hmp as hmp_mod
from hmp2smf import device_for
from pack import resample
RENDER_RATE = 64000
OUTPUT_RATE = 48000
CHANNELS = 2
FILTER_SIZE = 64
UNROLL_PASSES = 1
STEADY_PASS = 1
ONESHOT_TAIL_SECONDS = 3.0
SC55_MK1 = {'sc55_rom1.bin': '7e1bacd1d7c62ed66e465ba05597dcd60dfc13fc23de0287fdbce6cf906c6544', 'sc55_rom2.bin': 'effc6132d68f7e300aaef915ccdd08aba93606c22d23e580daf9ea6617913af1', 'sc55_waverom1.bin': '5655509a531804f97ea2d7ef05b8fec20ebf46216b389a84c44169257a4d2007', 'sc55_waverom2.bin': 'c655b159792d999b90df9e4fa782cf56411ba1eaa0bb3ac2bdaf09e1391006b1', 'sc55_waverom3.bin': '334b2d16be3c2362210fdbec1c866ad58badeb0f84fd9bf5d0ac599baf077cc2'}
DEFAULT_RENDERER = REPO / 'cpsplus' / 'work' / 'x68000' / 'upstream' / 'Nuked-SC55-GUI-Float' / 'build' / 'nuked-sc55-render'
DEFAULT_ROMS = REPO / 'roms' / 'sc55'

class RenderError(RuntimeError):
    pass

def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open('rb') as handle:
        for block in iter(lambda: handle.read(1 << 20), b''):
            digest.update(block)
    return digest.hexdigest()

def check_roms(roms: Path) -> None:
    for name, want in SC55_MK1.items():
        path = roms / name
        if not path.is_file():
            raise RenderError(f'missing SC-55 ROM: {path}')
        got = _sha256(path)
        if got != want:
            raise RenderError(f'{name}: sha256 {got}, expected {want}')

def render_f32(renderer: Path, roms: Path, midi: Path) -> np.ndarray:
    """Nuked-SC55's raw float output, shape (frames, 2)."""
    proc = subprocess.run([str(renderer), '-d', str(roms), '--romset', 'mk1', '-f', 'f32', '--end', 'cut', '--stdout', str(midi)], capture_output=True, check=False)
    if proc.returncode != 0:
        raise RenderError(f"{midi.name}: renderer exited {proc.returncode}: {proc.stderr.decode(errors='replace')[-400:]}")
    samples = np.frombuffer(proc.stdout, dtype='<f4')
    if samples.size % CHANNELS:
        raise RenderError(f'{midi.name}: raw output ends mid-frame')
    audio = samples.reshape(-1, CHANNELS)
    if not audio.size:
        raise RenderError(f'{midi.name}: renderer produced no audio')
    if not np.all(np.isfinite(audio)):
        raise RenderError(f'{midi.name}: render holds non-finite samples')
    return audio

def to_s32(v: np.ndarray) -> np.ndarray:
    """Float to s32 as ffmpeg does it, then the FLAC encoder's 24-bit keep."""
    q31 = np.clip(np.rint(v.astype(np.float64) * 2.0 ** 31), -2.0 ** 31, 2.0 ** 31 - 1).astype(np.int64)
    return (q31 >> 8 << 8).astype('<i4')

def convert(audio: np.ndarray, *, trim: int, limit: int | None) -> np.ndarray:
    body = audio[trim:]
    pcm = resample.convolve_f32(lambda k: np.ascontiguousarray(body[:, k]), len(body), CHANNELS, RENDER_RATE, OUTPUT_RATE, to_s32, '<i4', FILTER_SIZE, limit=limit)
    if limit is not None and len(pcm) < limit:
        pcm = np.concatenate((pcm, np.zeros((limit - len(pcm), CHANNELS), '<i4')))
    return pcm

def write_flac(pcm: np.ndarray, dest: Path, tags: dict[str, int]) -> None:
    args = [Executable('ffmpeg'), '-hide_banner', '-loglevel', 'error', '-y', '-f', 's32le', '-ar', str(OUTPUT_RATE), '-ac', str(CHANNELS), '-i', 'pipe:0', '-c:a', 'flac', '-sample_fmt', 's32', '-bits_per_raw_sample', '24']
    for key, value in tags.items():
        args += ['-metadata', f'{key}={value}']
    args.append(str(dest))
    proc = subprocess.run(args, input=pcm.tobytes(), capture_output=True)
    if proc.returncode != 0:
        raise RenderError(f"{dest.name}: ffmpeg exited {proc.returncode}: {proc.stderr.decode(errors='replace')[-400:]}")

def _main(argv, state: Path) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('midi_dir', help='directory of .HMP files')
    ap.add_argument('--out-dir', required=True)
    ap.add_argument('--songs', nargs='*', help='stems to render (default: all _G)')
    ap.add_argument('--renderer', type=Path)
    ap.add_argument('--roms', type=Path, default=DEFAULT_ROMS)
    from tool_controls import add_arguments, configure
    add_arguments(ap)
    a = ap.parse_args(argv)
    configure(argv if argv is not None else __import__('sys').argv[1:])
    check_roms(a.roms)
    for name in SC55_MK1:
        shutil.copyfile(a.roms / name, state / name)
    a.roms = state
    from fetch_optional_tools import resolve
    a.renderer = a.renderer or resolve('sc55')
    if not a.renderer.is_file():
        raise SystemExit(f'Helper not found: {a.renderer}')
    midi_dir = Path(a.midi_dir)
    out_dir = Path(a.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    smf_dir = out_dir / 'smf'
    smf_dir.mkdir(exist_ok=True)
    stems = a.songs or sorted((p.stem for p in midi_dir.iterdir() if p.suffix.upper() == '.HMP' and device_for(p.stem) == 'gs'))
    report = []
    warmed = False
    for stem in stems:
        source = midi_dir / f'{stem}.HMP'
        song = hmp_mod.parse(source)
        reset = device_for(stem)
        if reset != 'gs':
            raise SystemExit(f'{stem}: not a Sound Canvas sequence')
        loop = hmp_mod.loop_samples(song, OUTPUT_RATE, reset=reset, pass_index=STEADY_PASS)
        smf = smf_dir / f'{stem}.mid'
        smf.write_bytes(hmp_mod.to_smf(song, reset=reset, unroll_passes=UNROLL_PASSES, tail_seconds=0.0 if loop is not None else ONESHOT_TAIL_SECONDS))
        if not warmed:
            if not (a.roms / 'sc55_memory.bin0').is_file():
                render_f32(a.renderer, a.roms, smf)
            warmed = True
        audio = render_f32(a.renderer, a.roms, smf)
        trim = round(hmp_mod.SETTLE_SECONDS[reset] * RENDER_RATE)
        tags: dict[str, int] = {}
        limit = None
        if loop is not None:
            settle = round(hmp_mod.SETTLE_SECONDS[reset] * OUTPUT_RATE)
            start, end = (loop[0] - settle, loop[1] - settle)
            if start <= OUTPUT_RATE:
                raise RenderError(f'{stem}: loop starts {start} samples in, too early to leave a one-second crossfade tail before it')
            tags = {'LOOPSTART': start, 'LOOPEND': end, 'LOOPLENGTH': end - start}
            limit = end
        pcm = convert(audio, trim=trim, limit=limit)
        dest = out_dir / f'{stem}.flac'
        write_flac(pcm, dest, tags)
        kind = f"loop {tags['LOOPSTART']}..{tags['LOOPEND']}" if tags else 'one-shot'
        size = dest.stat().st_size
        print(f'{stem:12s} {len(pcm) / OUTPUT_RATE:7.2f}s  {size / 1000000.0:6.2f} MB  {kind}')
        report.append({'song': stem, 'frames': int(len(pcm)), 'render_frames': int(len(audio)), 'tags': tags, 'sha256': _sha256(dest)})
    (out_dir / 'render_report.json').write_text(json.dumps({'renderer_sha256': _sha256(a.renderer), 'romset': 'SC-55 v1.21 (mk1)', 'rate': OUTPUT_RATE, 'songs': report}, indent=2), encoding='utf-8')
    print(f'\n{len(report)} songs -> {out_dir}')
    return 0

def main(argv=None) -> int:
    with tempfile.TemporaryDirectory(prefix='sc55-state-') as directory:
        return _main(argv, Path(directory))
if __name__ == '__main__':
    sys.exit(main())
