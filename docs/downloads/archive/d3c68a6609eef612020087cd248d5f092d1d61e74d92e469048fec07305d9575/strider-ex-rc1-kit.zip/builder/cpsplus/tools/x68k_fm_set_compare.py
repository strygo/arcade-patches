"""Compare two X68000 FM recording sets song by song, for a listening review."""
from __future__ import annotations
import argparse
import html
import json
import math
import shutil
import subprocess
import sys
import wave
from pathlib import Path
import numpy as np
RATE = 48000
ENVELOPE_WINDOW = RATE // 20
MAX_LAG_SECONDS = 1.0
ENVELOPE_MIN = 0.95
LEVEL_MAX_DB = 1.0
LENGTH_MAX_SECONDS = 0.1
SPECTRUM_MIN = 0.98

class CompareError(RuntimeError):
    pass

def read_wav(path: Path) -> np.ndarray:
    with wave.open(str(path), 'rb') as source:
        if (source.getframerate(), source.getnchannels(), source.getsampwidth()) != (RATE, 2, 2):
            raise CompareError(f'{path}: expected 48 kHz 16-bit stereo')
        raw = source.readframes(source.getnframes())
    return np.frombuffer(raw, dtype='<i2').reshape(-1, 2).astype(np.float64)

def envelope(samples: np.ndarray) -> np.ndarray:
    mono = samples.mean(axis=1)
    usable = len(mono) // ENVELOPE_WINDOW * ENVELOPE_WINDOW
    windows = mono[:usable].reshape(-1, ENVELOPE_WINDOW)
    return np.sqrt((windows ** 2).mean(axis=1))

def correlation(a: np.ndarray, b: np.ndarray) -> float:
    n = min(len(a), len(b))
    a, b = (a[:n] - a[:n].mean(), b[:n] - b[:n].mean())
    denominator = math.sqrt(float((a * a).sum() * (b * b).sum()))
    return float((a * b).sum() / denominator) if denominator else 0.0

def best_lag_samples(a: np.ndarray, b: np.ndarray) -> int:
    """Lag of b against a (samples) within +-1 s, from a 10 s mid-song window."""
    mono_a, mono_b = (a.mean(axis=1), b.mean(axis=1))
    n = min(len(mono_a), len(mono_b))
    window = min(RATE * 10, n // 2)
    start = max(0, n // 2 - window // 2)
    radius = int(MAX_LAG_SECONDS * RATE)
    if start < radius or start + window + radius > n:
        return 0
    reference = mono_a[start:start + window]
    excerpt = mono_b[start - radius:start + window + radius]
    size = 1 << (len(excerpt) + len(reference)).bit_length()
    cross = np.fft.irfft(np.fft.rfft(excerpt, size) * np.conj(np.fft.rfft(reference, size)), size)
    valid = cross[:len(excerpt) - len(reference) + 1]
    return int(np.argmax(valid)) - radius

def band_spectrum(samples: np.ndarray) -> np.ndarray:
    """Long-term level (dB) in third-octave bands, 50 Hz to 16 kHz."""
    mono = samples.mean(axis=1)
    size = 1 << 15
    count = max(1, len(mono) // size)
    trimmed = mono[:count * size].reshape(count, size) * np.hanning(size)
    power = (np.abs(np.fft.rfft(trimmed, axis=1)) ** 2).mean(axis=0)
    freqs = np.fft.rfftfreq(size, 1 / RATE)
    edges = 50 * 2 ** (np.arange(0, 3 * 8.5 + 1) / 3)
    levels = []
    for low, high in zip(edges[:-1], edges[1:]):
        band = power[(freqs >= low) & (freqs < high)]
        levels.append(10 * math.log10(band.sum() + 1e-09))
    return np.array(levels)

def rms_db(samples: np.ndarray) -> float:
    return 20 * math.log10(math.sqrt(float((samples ** 2).mean())) + 1e-09)

def sidecar(path: Path) -> dict:
    return json.loads(path.read_text()) if path.is_file() else {}

def loop_of(meta: dict) -> tuple[int, int] | None:
    loop = meta.get('loop_candidate')
    return (int(loop['start_sample']), int(loop['end_sample'])) if loop else None

def measure(song: str, ref_dir: Path, cand_dir: Path) -> dict:
    a, b = (read_wav(ref_dir / f'{song}.wav'), read_wav(cand_dir / f'{song}.wav'))
    meta_a, meta_b = (sidecar(d / f'{song}.json') for d in (ref_dir, cand_dir))
    loop_a, loop_b = (loop_of(meta_a), loop_of(meta_b))
    lag = best_lag_samples(a, b)
    row = {'song': song, 'seconds_ref': len(a) / RATE, 'seconds_cand': len(b) / RATE, 'level_ref_db': rms_db(a), 'level_cand_db': rms_db(b), 'peak_ref': int(np.abs(a).max()), 'peak_cand': int(np.abs(b).max()), 'envelope_corr': correlation(envelope(a), envelope(b)), 'lag_samples': lag, 'spectrum_corr': correlation(band_spectrum(a), band_spectrum(b)), 'loop_ref': loop_a, 'loop_cand': loop_b, 'status_ref': meta_a.get('loop_status', '-'), 'status_cand': meta_b.get('loop_status', '-'), 'ncc_cand': (meta_b.get('capture_timing_adjustment') or {}).get('ncc')}
    flags = []
    if row['envelope_corr'] < ENVELOPE_MIN:
        flags.append('envelope')
    if abs(row['level_cand_db'] - row['level_ref_db']) > LEVEL_MAX_DB:
        flags.append('level')
    if abs(row['seconds_cand'] - row['seconds_ref']) > LENGTH_MAX_SECONDS:
        flags.append('length')
    if row['spectrum_corr'] < SPECTRUM_MIN:
        flags.append('spectrum')
    if (loop_a is None) != (loop_b is None):
        flags.append('loop-kind')
    elif loop_a and abs(loop_a[1] - loop_a[0] - (loop_b[1] - loop_b[0])) > RATE // 100:
        flags.append('loop-period')
    row['flags'] = ','.join(flags)
    return row

def make_clip(wav: Path, target: Path, seconds: float, ffmpeg: str) -> None:
    with wave.open(str(wav), 'rb') as source:
        total = source.getnframes() / RATE
    start = 0.0 if total <= seconds + 5 else 5.0
    subprocess.run([ffmpeg, '-v', 'error', '-y', '-ss', f'{start}', '-t', f'{seconds}', '-i', str(wav), '-c:a', 'aac', '-b:a', '160k', str(target)], check=True)
TSV_COLUMNS = ('song', 'seconds_ref', 'seconds_cand', 'level_ref_db', 'level_cand_db', 'envelope_corr', 'spectrum_corr', 'lag_samples', 'status_ref', 'status_cand', 'ncc_cand', 'flags')

def write_tsv(rows: list[dict], path: Path) -> None:

    def cell(value) -> str:
        if value is None:
            return '-'
        return f'{value:.4f}' if isinstance(value, float) else str(value)
    with path.open('w', encoding='utf-8') as out:
        out.write('\t'.join(TSV_COLUMNS) + '\n')
        for row in rows:
            out.write('\t'.join((cell(row[c]) for c in TSV_COLUMNS)) + '\n')

def write_page(rows: list[dict], path: Path, titles: dict[str, str]) -> None:
    flagged = [r for r in rows if r['flags']]
    parts = ['<!doctype html><meta charset=utf-8><title>X68000 FM set comparison</title><style>body{font:14px system-ui;margin:24px;max-width:1100px}table{border-collapse:collapse;width:100%}td,th{padding:4px 8px;border-bottom:1px solid #8884;text-align:left;vertical-align:middle}.flag{background:#d9770633}audio{height:30px;width:260px}code{font-size:12px}</style>', '<h1>X68000 FM: candidate set against the reference</h1>', f'<p>{len(rows)} songs, {len(flagged)} flagged for a closer listen. <b>A</b> = reference recording, <b>B</b> = candidate. Clips are a short excerpt of each song; flags are screening only.</p>', '<table><tr><th>song<th>A<th>B<th>level A/B (dB)<th>envelope<th>spectrum<th>length A/B (s)<th>flags</tr>']
    for r in rows:
        s = r['song']
        parts.append(f"<tr class='{('flag' if r['flags'] else '')}'><td><b>{s}</b><br><small>{html.escape(titles.get(s, ''))}</small><td><audio controls preload=none src='clips/{s}-A.m4a'></audio><td><audio controls preload=none src='clips/{s}-B.m4a'></audio><td>{r['level_ref_db']:.1f} / {r['level_cand_db']:.1f}<td>{r['envelope_corr']:.3f}<td>{r['spectrum_corr']:.3f}<td>{r['seconds_ref']:.2f} / {r['seconds_cand']:.2f}<td>{html.escape(r['flags']) or '&mdash;'}</tr>")
    parts.append('</table>')
    path.write_text('\n'.join(parts), encoding='utf-8')

def main(argv: list[str] | None=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('--reference', type=Path, required=True)
    parser.add_argument('--candidate', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--clip-seconds', type=float, default=40.0)
    parser.add_argument('--titles', type=Path, help='optional TSV of song<TAB>title for the page')
    args = parser.parse_args(argv)
    ffmpeg = shutil.which('ffmpeg')
    if ffmpeg is None:
        raise CompareError('ffmpeg is required for the listening clips')
    songs = sorted((p.stem for p in args.reference.glob('song*.wav') if not p.stem.endswith('-session') and (args.candidate / p.name).is_file()))
    if not songs:
        raise CompareError('no songs are present in both sets')
    missing = sorted((p.stem for p in args.reference.glob('song*.wav') if not p.stem.endswith('-session') and (not (args.candidate / p.name).is_file())))
    if missing:
        print(f"note: not in the candidate set: {', '.join(missing)}")
    (args.out / 'clips').mkdir(parents=True, exist_ok=True)
    rows = []
    for song in songs:
        rows.append(measure(song, args.reference, args.candidate))
        for label, directory in (('A', args.reference), ('B', args.candidate)):
            make_clip(directory / f'{song}.wav', args.out / 'clips' / f'{song}-{label}.m4a', args.clip_seconds, ffmpeg)
        print(f"{song}: envelope {rows[-1]['envelope_corr']:.3f} flags {rows[-1]['flags'] or '-'}", flush=True)
    titles = {}
    if args.titles:
        for line in args.titles.read_text(encoding='utf-8').splitlines():
            song, _, title = line.partition('\t')
            titles[song] = title
    write_tsv(rows, args.out / 'metrics.tsv')
    write_page(rows, args.out / 'index.html', titles)
    flagged = sum((1 for r in rows if r['flags']))
    print(f'{len(rows)} songs compared, {flagged} flagged: {args.out}/index.html')
    return 0

def self_test() -> None:
    tone = np.sin(np.arange(RATE * 12) * 2 * math.pi * 440 / RATE) * 8000
    stereo = np.stack([tone, tone], axis=1)
    assert abs(rms_db(stereo) - 20 * math.log10(8000 / math.sqrt(2))) < 0.01
    assert correlation(envelope(stereo), envelope(stereo * 0.5)) > 0.999
    shifted = np.roll(stereo, 7, axis=0)
    shifted[:7] = 0
    noise = np.random.default_rng(1).normal(0, 3000, stereo.shape)
    base = stereo + noise
    delayed = np.roll(base, 123, axis=0)
    assert best_lag_samples(base, delayed) == 123
    assert correlation(band_spectrum(stereo), band_spectrum(stereo * 0.5)) > 0.999
    other = np.stack([noise[:, 0], noise[:, 1]], axis=1)
    assert correlation(band_spectrum(stereo), band_spectrum(other)) < 0.9
    print('x68k_fm_set_compare self-test: OK')
if __name__ == '__main__':
    if '--self-test' in sys.argv[1:]:
        self_test()
        raise SystemExit(0)
    try:
        raise SystemExit(main())
    except CompareError as exc:
        print(f'x68k_fm_set_compare: error: {exc}', file=sys.stderr)
        raise SystemExit(1)
