"""Render every candidate pack cue and loop wrap into a local listening page."""
from __future__ import annotations
import argparse
import csv
import hashlib
import html
import json
from pathlib import Path
import subprocess
import sys
import wave
import numpy as np
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from pack import audition, xfade
from pack.format import PackReader, VERB_PLAY
ROOT = Path(__file__).resolve().parents[2]
PACK_KEYS = ['ffight_di', 'msword_di', 'ssf2_hdremix']

def native_clip(key, cmd):
    game = 'ffight' if key.startswith('ffight') else 'msword' if key == 'msword_di' else 'ssf2t'
    d = ROOT / 'cpsplus/work/ps3_packs/native' / game
    individual = game == 'ffight' or (d / f'{cmd:02x}.wav').exists()
    wav = d / (f'{cmd:02x}.wav' if individual else 'audio.wav')
    tsv = d / (f'{cmd:02x}.tsv' if individual else 'sweep.tsv')
    if not wav.exists() or not tsv.exists():
        return None
    row = next((r for r in csv.DictReader(tsv.open(), delimiter='\t') if int(r['cmd'], 16) == cmd), None)
    if row is None:
        return None
    with wave.open(str(wav)) as w:
        rate = w.getframerate()
        ch = w.getnchannels()
        seconds = float(row.get('seconds', int(row['frame']) / 59.637405))
        w.setpos(int((seconds + 1) * rate))
        x = np.frombuffer(w.readframes(rate * 8), '<i2').reshape(-1, ch)
    if ch == 1:
        x = np.repeat(x, 2, axis=1)
    return (x, rate)

def preview(pcm, rate, path):
    subprocess.run(['ffmpeg', '-v', 'error', '-y', '-f', 's16le', '-ac', '2', '-ar', str(rate), '-i', '-', '-c:a', 'libmp3lame', '-b:a', '192k', str(path)], input=np.clip(pcm, -32768, 32767).astype('<i2').tobytes(), check=True)

def media_url(path):
    digest = hashlib.sha256(path.read_bytes()).hexdigest()[:16]
    return f'{path.name}?v={digest}'

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--packs', type=Path, default=ROOT / 'cpsplus/work/packs')
    ap.add_argument('--out', type=Path, default=ROOT / 'cpsplus/work/ps3_packs/review')
    ap.add_argument('--pack', choices=PACK_KEYS, action='append', help='Refresh audio for only these packs; rebuild the complete page')
    ap.add_argument('--cmd', type=lambda s: int(s, 0), action='append', help='Refresh only these commands within a single --pack')
    ap.add_argument('--page-only', action='store_true', help='Rebuild the page from existing previews without re-encoding audio')
    a = ap.parse_args()
    a.out.mkdir(parents=True, exist_ok=True)
    if a.cmd and (not a.pack or len(a.pack) != 1):
        ap.error('--cmd requires exactly one --pack')
    sections = []
    inventory = []
    for key in PACK_KEYS:
        recipe = json.loads((ROOT / 'cpsplus/manifests' / f'{key}_audio.json').read_text())
        rows = []
        rd = PackReader(a.packs / f'{key}.cpk')
        try:
            for ti, m in enumerate(rd.tracks):
                commands = [(cmd, r) for cmd, r in enumerate(rd.triggers) if r.verb == VERB_PLAY and r.track == ti]
                if not commands:
                    continue
                r = next((r for r in recipe['tracks'] if r['source'] == m.source), {})
                title = m.name or f'Track {ti}'
                start = a.out / f'{key}_{ti:02d}_start.mp3'
                seam = a.out / f'{key}_{ti:02d}_wrap.mp3'
                refresh = not a.pack or key in a.pack or (not start.exists()) or (not seam.exists())
                full_preview = key.startswith('ffight') and r.get('cmd') in (76, 85) or (key == 'ssf2_hdremix' and r.get('cmd') in (35, 46))
                full_preview = full_preview or (key == 'msword_di' and r.get('cmd') in (2, 3, 5, 15, 19, 21))
                if full_preview:
                    refresh = refresh or not (a.out / f'{key}_{ti:02d}_full.mp3').exists()
                if a.cmd and (key != a.pack[0] or not any((c in a.cmd for c, _ in commands))):
                    refresh = False
                if a.page_only:
                    refresh = False
                if refresh:
                    pcm = np.frombuffer(audition._decode_track(rd, ti), '<i2').reshape(-1, 2).astype(np.int64)
                    gain = commands[0][1].gain * m.gain / (127 * 127)
                    pcm = np.rint(pcm * gain).astype(np.int64)
                    preview(pcm[:min(len(pcm), 12 * m.sample_rate)], m.sample_rate, start)
                duration = m.data_length // (18 * m.channels) * 32 / m.sample_rate
                kind = 'ending'
                detail = f'One shot · {duration:.3f} s'
                if m.loops:
                    ls, le = (m.loop_start_sample, m.loop_end_sample)
                    n = rd.header.xfade_samples if m.xfade_enable else 0
                    if refresh:
                        before = pcm[max(0, le - 6 * m.sample_rate):le]
                        after = pcm[ls + n:min(le, ls + n + 8 * m.sample_rate)]
                        blend = np.empty((0, 2), dtype=np.int64)
                        if n:
                            lut = np.array(xfade.make_lut(n), dtype=np.int64)[:, None]
                            blend = np.clip(pcm[le:le + n] * lut + pcm[ls:ls + n] * lut[::-1] + 16384 >> 15, -32768, 32767)
                        clip = np.concatenate([before, blend, after])
                    kind = 'wrap'
                    detail = f'{ls / m.sample_rate:.3f} → {le / m.sample_rate:.3f} s'
                    if m.loop_count:
                        detail += f' · {m.loop_count} extra pass'
                elif refresh:
                    clip = pcm[max(0, len(pcm) - 12 * m.sample_rate):]
                if refresh:
                    preview(clip, m.sample_rate, seam)
                cmds = ', '.join((f'0x{c:02x}' for c, _ in commands))
                native_cmd = r.get('cmd', commands[0][0])
                native = native_clip(key, native_cmd)
                native_html = '<small>Reference not yet captured</small>'
                if native is not None:
                    native_path = a.out / f'{key}_{ti:02d}_arcade.mp3'
                    if not a.page_only and (refresh or not native_path.exists()):
                        preview(native[0], native[1], native_path)
                    native_html = f'<audio controls preload="none" src="{media_url(native_path)}"></audio>'
                    if native_cmd not in [c for c, _ in commands]:
                        native_html += f'<small>Arcade music cue 0x{native_cmd:02x}</small>'
                extra = ''
                if full_preview:
                    full = a.out / f'{key}_{ti:02d}_full.mp3'
                    if refresh:
                        full_pcm = pcm
                        if m.loops:
                            rendered, _ = audition.render(rd, ti, loops=2)
                            full_pcm = np.rint(np.frombuffer(rendered, '<i2').reshape(-1, 2).astype(np.int64) * gain)
                        preview(full_pcm, m.sample_rate, full)
                    full_label = 'Opening + two complete loop passes' if m.loops else f'Full {duration:g}-second one-shot'
                    extra = f'<small>{full_label}</small><audio controls preload="none" src="{media_url(full)}"></audio>'
                note = r.get('status', 'listening_pending').replace('_', ' ')
                start_url, seam_url = (media_url(start), media_url(seam))
                rows.append(f'<tr><td><code>{cmds}</code><br>{html.escape(title)}</td><td>{detail}<br><small>{html.escape(note)}</small></td><td>{native_html}</td><td><audio controls preload="none" src="{start_url}"></audio></td><td><audio controls preload="none" src="{seam_url}"></audio><small>{kind}</small>{extra}</td></tr>')
                inventory.append(dict(pack=key, track=ti, commands=cmds, title=title, start=start.name, seam=seam.name, start_url=start_url, seam_url=seam_url, native_cmd=native_cmd, native_present=native is not None))
                print(key, cmds, title, flush=True)
        finally:
            rd.close()
        sections.append(f'<section><h2>{html.escape(key)}</h2><table><thead><tr><th>Cue</th><th>Playback</th><th>Arcade</th><th>Remix start</th><th>Wrap / ending</th></tr></thead><tbody>' + ''.join(rows) + '</tbody></table></section>')
    page = '<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>CPS+ remix listening review</title> <style>body{font:16px system-ui;background:#13181e;color:#e7edf3;margin:32px auto;max-width:1400px;padding:0 20px}h1{font-size:32px}h2{margin-top:48px}a{color:#80d2ff}p{line-height:1.6;max-width:950px}table{width:100%;border-collapse:collapse}td,th{padding:16px 10px;text-align:left;border-bottom:1px solid #35404c;vertical-align:top}td:first-child{width:28%}small{display:block;color:#a8bacb;margin-top:6px}audio{width:260px;max-width:100%}.flag{padding:16px;background:#373020;border:1px solid #ac8638}input{padding:12px;width:60%;font:inherit;background:#202832;color:white;border:1px solid #536777}</style> <style>@media(max-width:1000px){thead{display:none}tbody,tr,td{display:block}tr{display:grid;grid-template-columns:1fr 1fr;border-bottom:1px solid #536777;padding:12px 0}tr[hidden],section[hidden]{display:none}td,td:first-child{width:auto;border:0;padding:8px 10px}td:nth-child(n+3){grid-column:1/-1}td:nth-child(3)::before{content:\'Arcade reference\'}td:nth-child(4)::before{content:\'Remix start\'}td:nth-child(5)::before{content:\'Wrap / ending\'}td:nth-child(n+3)::before{display:block;color:#a8bacb;margin-bottom:6px}audio{width:300px}input{width:100%;box-sizing:border-box}}</style> MiSTer hardware review pending. Audio below comes from the final encoded packs at their measured gain.</p> <p>Listen to each cue\'s start and wrap. Wrap clips include up to six seconds before the boundary and eight seconds after it, limited by the cue length. Check that the musical phrase continues naturally, with no gap, click, restart, or volume jump.</p> <p>Final Fight uses one shared pack for the US and Japan MRAs. Both 0x35 and 0x52 play the same 57.003-second intro: US starts on 0x35, Japan on its earlier 0x52. The CPS1 core ignores the later cue without restarting the track. Native music is suppressed; phone ringing and the answer click remain audible. Japan\'s file ends at about 69.7 seconds from boot, roughly 1.6 seconds after its title screen disappears. The arcade music reference is 0x52; “Level 5-1a” is the album\'s misleading title.</p> <p>Bonus Stage (0x4c) plays once for 32 seconds; its full cue is available below. All 19 Final Fight music tracks have arcade references.</p> Character Select plays its opening once, then repeats 3.462 → 10.625 seconds before the separate closing section. Normal selection ends after 10.329 seconds; a late second-player join extends it beyond the original file length without restarting the cue, so the loop remains necessary. Its wrap and full opening-plus-two-loop previews remain available for reference.</p> Vega plays its opening once, then repeats 3.710 → 25.779 seconds before the album fade. Ryu\'s ending (0x23) plays once for the full 30 seconds. The previews remain available for reference.</p> <p>Magic Sword\'s cue numbers now match the arcade\'s hexadecimal commands. The former 0x19 preview, Refuge, is a one-shot at 0x13; the former 0x15 preview, Onwards and Upwards, is at 0x0f. Trouble From Afar, Battle Charge and Tears for Alan belong at 0x0b–0x0d and repeat in the arcade. Eternal Struggle (0x11), Sanctuary (0x12) and Refuge (0x13) end naturally. All 25 tracks now have fresh arcade references.</p> Its accepted loop plays the opening once, then repeats 21.412 → 29.412 seconds within the earlier four-bar phrase. The full opening-plus-two-loop preview remains available below. Unmapped arcade cues remain audible through the original board.</p> <input id="filter" placeholder="Filter by pack, cue, or track title" aria-label="Filter tracks">' + ''.join(sections) + "\n<script>document.getElementById('filter').addEventListener('input',e=>{let q=e.target.value.toLowerCase();document.querySelectorAll('section').forEach(s=>{let visible=0;s.querySelectorAll('tbody tr').forEach(r=>{r.hidden=!(r.textContent+' '+s.querySelector('h2').textContent).toLowerCase().includes(q);if(!r.hidden)visible++});s.hidden=!visible})});document.addEventListener('play',e=>{document.querySelectorAll('audio').forEach(a=>{if(a!==e.target)a.pause()})},true);</script></html>"
    (a.out / 'index.html').write_text(page)
    (a.out / 'inventory.json').write_text(json.dumps(inventory, indent=2) + '\n')
if __name__ == '__main__':
    main()
