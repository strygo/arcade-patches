"""Compare renderer builds with identical isolated SC-55 firmware/SRAM state."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import tarfile

def sha(data):
    return hashlib.sha256(data).hexdigest()

def probe(a):
    if a.work.exists():
        raise ValueError('Fresh probe work required')
    a.work.mkdir(parents=True)
    pin = json.loads(a.lock.read_text())['sources']['sc55']
    source = a.sources / pin['filename']
    if sha(source.read_bytes()) != pin['sha256']:
        raise ValueError('MIDI fixture source identity differs')
    with tarfile.open(source) as tar:
        names = [n for n in tar.getnames() if n.endswith('/test/integration/avmidi/01.mid')]
        if len(names) != 1:
            raise ValueError('Missing upstream fixture')
        midi = tar.extractfile(names[0]).read()
    (a.work / 'fixture.mid').write_bytes(midi)
    firmware = {name: (a.roms / name).read_bytes() for name in ('sc55_rom1.bin', 'sc55_rom2.bin', 'sc55_waverom1.bin', 'sc55_waverom2.bin', 'sc55_waverom3.bin')}
    results = {}
    for item in a.renderer:
        name, value = item.split('=', 1)
        if not name.isidentifier() or name in results:
            raise ValueError('Use a unique identifier for each renderer')
        exe = Path(value).absolute()
        folder = a.work / name
        roms = folder / 'roms'
        roms.mkdir(parents=True)
        for filename, data in firmware.items():
            (roms / filename).write_bytes(data)
        runs = []
        for state in ('cold', 'warm'):
            saved = roms / 'sc55_memory.bin0'
            before = sha(saved.read_bytes()) if saved.exists() else None
            raw = folder / 'audio.raw'
            with raw.open('wb') as out, (folder / (state + '.log')).open('wb') as err:
                subprocess.run([str(exe), '--stdout', '--romset', 'mk1', '--rom-directory', str(roms), '--reset', a.reset, '--format', a.format, '--end', 'cut', str(a.work / 'fixture.mid')], cwd=folder, stdout=out, stderr=err, check=True, timeout=600)
            with raw.open('rb') as f:
                digest = hashlib.file_digest(f, 'sha256').hexdigest()
            runs.append(dict(state=state, sram_before=before, sram_after=sha(saved.read_bytes()), pcm_sha256=digest, bytes=raw.stat().st_size))
            raw.unlink()
            print(name, state, digest, flush=True)
        results[name] = dict(binary_sha256=sha(exe.read_bytes()), runs=runs)
    report = dict(schema=1, status='captured', source=pin, fixture_sha256=sha(midi), firmware={name: sha(data) for name, data in firmware.items()}, reset=a.reset, format=a.format, results=results, same_cold=len({r['runs'][0]['pcm_sha256'] for r in results.values()}) == 1, same_warm=len({r['runs'][1]['pcm_sha256'] for r in results.values()}) == 1, recipe_sha256=sha(Path(__file__).read_bytes()))
    a.out.parent.mkdir(parents=True, exist_ok=True)
    a.out.write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
    shutil.rmtree(a.work)
if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--renderer', action='append', required=True)
    p.add_argument('--reset', choices=('none', 'gm', 'gs'), default='gm')
    p.add_argument('--format', choices=('s16', 's32', 'f32'), default='s16')
    for name in ('work', 'out', 'lock', 'sources', 'roms'):
        p.add_argument('--' + name, type=Path, required=True)
    a = p.parse_args()
    for name, value in vars(a).items():
        if isinstance(value, Path):
            setattr(a, name, value.absolute())
    probe(a)
