"""FKP archive (Final Fight: Double Impact gamedata.fpk) lister/extractor."""
import struct, sys, os, collections
p = sys.argv[1]
f = open(p, 'rb')
magic, ver, count, hsz = struct.unpack('<4sIII', f.read(16))
assert magic == b'FKP.', magic
ents = []
for i in range(count):
    rec = f.read(64)
    name = rec[:48].split(b'\x00')[0].decode('latin1')
    h, z, size, off = struct.unpack('<IIII', rec[48:64])
    ents.append((name, size, off, h, z))
mode = sys.argv[2] if len(sys.argv) > 2 else 'list'
if mode == 'list':
    exts = collections.Counter((os.path.splitext(n)[1].lower() for n, *_ in ents))
    print('entries', count, 'by ext:', dict(exts))
    tot = sum((s for _, s, *_ in ents))
    print('total bytes', tot, 'file size', os.path.getsize(p))
    for n, s, o, h, z in ents:
        if n.lower().endswith(('.msf', '.at3', '.wav', '.mp3', '.ogg')):
            print(f'{o:#010x} {s:10d}  {n}')
elif mode == 'extract':
    outdir = sys.argv[3]
    pat = sys.argv[4:] or ['']
    os.makedirs(outdir, exist_ok=True)
    for n, s, o, h, z in ents:
        if any((q in n for q in pat)):
            f.seek(o)
            open(os.path.join(outdir, n), 'wb').write(f.read(s))
    print('extracted')
