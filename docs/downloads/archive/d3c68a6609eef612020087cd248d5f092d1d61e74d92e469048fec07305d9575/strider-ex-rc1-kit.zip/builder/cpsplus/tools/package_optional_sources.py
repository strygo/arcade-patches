"""Package corresponding build sources, excluding unused upstream music/media fixtures."""
import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import shutil
import tarfile
import zipfile
HERE = Path(__file__).resolve().parent
MEDIA = {'.aif', '.aiff', '.aac', '.m4a', '.opus', '.mp4', '.avi', '.webm', '.mod', '.xm', '.it', '.s3m', '.mid', '.midi', '.rmi', '.wav', '.mp3', '.ogg', '.flac', '.sf2', '.sfz', '.rom', '.bin', '.vgm', '.vgz', '.spc', '.nsf', '.nsp', '.xci', '.chd', '.iso', '.zip', '.7z'}

def digest(path):
    with path.open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()

def package(a):
    if a.out.exists():
        raise ValueError('Fresh source output required')
    a.out.mkdir(parents=True)
    target = a.out / 'optional-helpers-v1-sources.zip'
    files = {}
    sources = {}

    def info(name, mode=420):
        i = zipfile.ZipInfo(name, (2026, 10, 24, 0, 0, 0))
        i.external_attr = (32768 | mode) << 16
        i.compress_type = zipfile.ZIP_DEFLATED
        return i

    def write(z, name, data, mode=420):
        z.writestr(info(name, mode), data)
        files[name] = dict(kind='file', sha256=hashlib.sha256(data).hexdigest(), mode=mode)
    lock = (HERE.parent / 'manifests/optional_helpers_sources_v1.json').read_bytes()
    pins = json.loads(lock)['sources']
    with zipfile.ZipFile(target, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for name, pin in sorted(pins.items()):
            path = a.sources / pin['filename']
            if path.stat().st_size != pin['bytes'] or digest(path) != pin['sha256']:
                raise ValueError('Upstream archive differs')
            excluded = []
            count = 0
            prefixes = set()
            with tarfile.open(path) as tar:
                for member in tar:
                    if not (member.isfile() or member.issym() or member.islnk()):
                        continue
                    path_name = PurePosixPath(member.name)
                    if path_name.is_absolute() or '..' in path_name.parts:
                        raise ValueError('Unsafe upstream member')
                    prefixes.add(path_name.parts[0])
                    if path_name.suffix.lower() in MEDIA:
                        excluded.append(member.name)
                        continue
                    dest = 'sources/' + name + '/' + member.name
                    mode = 493 if member.mode & 73 else 420
                    if member.issym():
                        data = member.linkname.encode()
                        z.writestr(info(dest), data)
                        files[dest] = dict(kind='symlink', target=member.linkname, sha256=hashlib.sha256(data).hexdigest(), mode=mode)
                    else:
                        h = hashlib.sha256()
                        with tar.extractfile(member) as src, z.open(info(dest, mode), 'w') as dst:
                            while (block := src.read(1024 * 1024)):
                                h.update(block)
                                dst.write(block)
                        files[dest] = dict(kind='file', sha256=h.hexdigest(), mode=mode)
                    count += 1
            if len(prefixes) != 1:
                raise ValueError('Unexpected upstream root')
            sources[name] = dict(pin=pin, prefix=next(iter(prefixes)), included_files=count, excluded_media=excluded)
            print('SOURCE', name, count, 'files;', len(excluded), 'unused media omitted', flush=True)
        for name in ('build_optional_helpers.py', 'optional_producer_requirements.txt'):
            write(z, 'recipe/' + name, (HERE / name).read_bytes())
        write(z, 'recipe/optional_helpers_sources_v1.json', lock)
        for path in sorted((HERE / 'licenses/gcc-runtime').rglob('*')):
            if path.is_file():
                write(z, 'recipe/licenses/gcc-runtime/' + path.relative_to(HERE / 'licenses/gcc-runtime').as_posix(), path.read_bytes())
        write(z, 'rebuild_optional_sources.py', (HERE / 'rebuild_optional_sources.py').read_bytes())
        manifest = dict(schema=1, sources=sources, files=files, scope='complete build sources; unused media fixtures omitted')
        z.writestr(info('corresponding_sources.json'), json.dumps(manifest, sort_keys=True).encode())
        z.writestr(info('README.txt'), 'Corresponding optional-helper build sources. Original licenses are retained.\nUnused upstream MIDI/audio/ROM and archive fixtures are omitted; build sources are unchanged.\nNo game music, game dumps, keys or instrument firmware are included.\nThe adapter verifies every included member and supplies source trees to the original producer offline.\nUnzip rebuild_optional_sources.py, then run with the published bundle SHA-256:\npython rebuild_optional_sources.py --bundle this.zip --sha256 DIGEST --extract FRESH_DIR --host macos-arm64 --only sc55 --root FRESH_BUILD --out FRESH_OUTPUT --sources EMPTY_CACHE\nProducer prerequisites: Python with optional_producer_requirements.txt, CMake, Ninja, pkg-config, C/C++ toolchain.\nRecipients use prebuilt binaries and do not need a compiler.\n'.encode())
    record = dict(schema=1, filename=target.name, sha256=digest(target), bytes=target.stat().st_size, sources={name: {k: v for k, v in r.items() if k != 'pin'} for name, r in sources.items()}, upstream_source_lock_sha256=hashlib.sha256(lock).hexdigest(), recipe_sha256=digest(HERE / 'package_optional_sources.py'), adapter_sha256=digest(HERE / 'rebuild_optional_sources.py'), file_inventory_sha256=hashlib.sha256(json.dumps(files, sort_keys=True).encode()).hexdigest())
    (a.out / 'source-receipt.json').write_text(json.dumps(record, indent=2) + '\n')
    print('PREPARED source-only companion', record['bytes'], 'bytes', flush=True)
if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--sources', type=Path, required=True)
    p.add_argument('--out', type=Path, required=True)
    package(p.parse_args())
