"""Compare a pack's match-end fade with the board's own, on a driven route."""
from __future__ import annotations
import argparse
import csv
import json
import math
import subprocess
import sys
import wave
from pathlib import Path
import numpy as np
CPSPLUS = Path(__file__).resolve().parent.parent
PY = sys.executable
REFRESH = 59.637405
FRAMES = 14000
RATE = 48000
SCHEDULE = ';'.join(['1200-1206:COIN1', '1300-1306:COIN1', '1450-1456:START1'] + [f'{f}-{f + 6}:P1_BUTTON1' for f in range(2000, 3051, 150)])

def run(cmd: list[str], log: Path) -> None:
    with log.open('w') as fh:
        proc = subprocess.run(cmd, stdout=fh, stderr=subprocess.STDOUT)
    if proc.returncode:
        raise SystemExit(f"failed ({proc.returncode}): {' '.join(cmd)}; see {log}")

def load_mono(path: Path) -> np.ndarray:
    with wave.open(str(path)) as w:
        if w.getframerate() != RATE:
            raise SystemExit(f'{path}: expected {RATE} Hz')
        x = np.frombuffer(w.readframes(w.getnframes()), '<i2')
        return x.astype(np.float64).reshape(-1, w.getnchannels()).mean(1)

def rms(x: np.ndarray) -> float:
    return math.sqrt(float((x * x).mean()) + 1e-12)

def db(g: float) -> float:
    return 20 * math.log10(max(g, 1e-06))

def write_clip(path: Path, x: np.ndarray, a: int, b: int) -> None:
    seg = np.clip(x[a:b], -32768, 32767).astype('<i2')
    tmp = path.with_suffix('.wav')
    with wave.open(str(tmp), 'wb') as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(RATE)
        w.writeframes(seg.tobytes())
    subprocess.run(['ffmpeg', '-v', 'error', '-y', '-i', str(tmp), str(path)], check=True)
    tmp.unlink()

def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--set', required=True, help='MAME set, e.g. ssf2u')
    ap.add_argument('--pack', required=True, type=Path, help='pack whose control map maps 0xff07')
    ap.add_argument('--outdir', required=True, type=Path)
    ap.add_argument('--clips', type=Path, help='write FLAC listening clips here')
    args = ap.parse_args(argv)
    s, out = (args.set, args.outdir)
    out.mkdir(parents=True, exist_ok=True)
    proto = [PY, str(CPSPLUS / 'scripts' / 'run_cpsplus_proto.py'), '--pack', str(args.pack), '--set', s, '--frames', str(FRAMES), '--wav', '--schedule', SCHEDULE]
    run(proto + ['--outdir', str(out / 'gated')], out / 'gated.log')
    run(proto + ['--outdir', str(out / 'native'), '--no-gate'], out / 'native.log')
    events = out / 'gated' / f'{s}_events.tsv'
    rows = [r for r in csv.DictReader(events.open(), delimiter='\t') if r['kind'] == 'rec']
    fades = [int(r['frame']) for r in rows if r['cmd'].lower() == '0xff07']
    if not fades:
        raise SystemExit('the route sent no 0xff07 -- the match did not end')
    if not all((r['verb'] == 'ctrl_fade_keep' for r in rows if r['cmd'].lower() == '0xff07')):
        raise SystemExit('--pack does not map 0xff07 to fade_keep')
    jingle = min((int(r['frame']) for r in rows if r['verb'] == 'play' and int(r['frame']) > fades[0]))
    cue_frame, cue = max(((int(r['frame']), int(r['cmd'], 16)) for r in rows if int(r['frame']) < fades[0] and 0 < int(r['cmd'], 16) < 64))
    native_rows = [r for r in csv.DictReader((out / 'native' / f'{s}_events.tsv').open(), delimiter='\t') if r['kind'] == 'rec' and r['cmd'].lower() == '0xff07']
    if [int(r['frame']) for r in native_rows] != fades:
        raise SystemExit('gated and native routes diverged at the match end')
    nofade = out / f'{s}_events_nofade.tsv'
    with events.open() as fi, nofade.open('w') as fo:
        for i, line in enumerate(fi):
            if i == 0 or line.split('\t')[3].lower() != '0xff07':
                fo.write(line)
    render = [PY, str(CPSPLUS / 'scripts' / 'render_route.py'), '--pack', str(args.pack), '--sfx-wav', str(out / 'gated' / f'{s}_gated.wav'), '--total-frames', str(FRAMES)]
    for tag, ev in (('fade', events), ('nofade', nofade)):
        run(render + ['--events', str(ev), '--out', str(out / f'{tag}_mix.wav'), '--music-only', str(out / f'{tag}_music.wav')], out / f'render_{tag}.log')
    run([PY, str(CPSPLUS / 'tools' / 'qsound_isolate.py'), s, str(out / 'ref'), f'0x{cue:02x}', '--jobs', '1', '--seconds', f'{(jingle - cue_frame) / REFRESH + 2:.1f}'], out / 'ref.log')
    nat = load_mono(out / 'native' / f'{s}_control.wav')
    sfx = load_mono(out / 'gated' / f'{s}_gated.wav')
    ref = load_mono(out / 'ref' / f'0x{cue:02x}.wav')
    fm, nm = (load_mono(out / 'fade_music.wav'), load_mono(out / 'nofade_music.wav'))
    fmix, nmix = (load_mono(out / 'fade_mix.wav'), load_mono(out / 'nofade_mix.wav'))
    first_play = min((int(r['frame']) for r in rows if r['verb'] == 'play'))
    pre = slice(int(600 * len(nat) / FRAMES), int((first_play - 30) * len(nat) / FRAMES))
    if rms(nat[pre] - sfx[pre]) > 1.0:
        raise SystemExit('native minus the SFX stem is not silent before the music: the two runs did not play the same sound effects')
    music = nat - sfx
    spf = len(nat) / FRAMES
    t0 = int(fades[0] * spf)
    end_s = (jingle - fades[0]) / REFRESH
    win = RATE // 2

    def ref_ratio(t: float) -> float:
        a = t0 + int(t * RATE)
        r = int(round((1560 + a / spf - cue_frame) * RATE / REFRESH))
        return rms(music[a:a + win]) / rms(ref[r:r + win])
    base = float(np.median([ref_ratio(t) for t in np.arange(-4.0, -0.9, 0.5)]))
    repeat_s = (fades[-1] - fades[0]) / REFRESH
    frames = 300

    def model(t: float) -> float:
        if t <= 0:
            return 1.0
        k = min(int(t * REFRESH), len(fades) - 1)
        lvl = (1 - 1 / frames) ** k
        if t > repeat_s:
            lvl = (1 - 1 / frames) ** (len(fades) - 1) * max(0.0, 1 - (t - repeat_s) * REFRESH / frames)
        return lvl
    table = []
    t = -1.0
    while t <= end_s - 0.5 + 1e-09:
        a = t0 + int(t * RATE)
        table.append({'t': round(t, 2), 'board_db': round(db(ref_ratio(t) / base), 1), 'pack_db': round(db(rms(fm[a:a + win]) / rms(nm[a:a + win])), 1), 'model_db': round(db(model(t + 0.25)), 1)})
        t += 0.5
    report = {'set': s, 'pack': str(args.pack), 'cue': f'0x{cue:02x}', 'fade_commands': len(fades), 'first_fade_frame': fades[0], 'repeat_seconds': round(repeat_s, 2), 'jingle_after_s': round(end_s, 2), 'table': table}
    (out / 'report.json').write_text(json.dumps(report, indent=1))
    print(f'== {s}: cue 0x{cue:02x}, 0xff07 x{len(fades)} over {repeat_s:.2f} s, jingle at +{end_s:.2f} s')
    print('   t(s)    board    pack   model')
    for r in table:
        print(f"   {r['t']:+5.2f}  {r['board_db']:+6.1f}  {r['pack_db']:+6.1f}  {r['model_db']:+6.1f}")
    if args.clips:
        args.clips.mkdir(parents=True, exist_ok=True)
        a, b = (t0 - 4 * RATE, int(jingle * spf) + 3 * RATE)
        for tag, x in (('1_board', nat), ('2_pack_with_fade', fmix), ('3_pack_without_fade', nmix)):
            write_clip(args.clips / f'{s}_{tag}.flac', x, a, b)
        print(f'   clips -> {args.clips}')
    return 0
if __name__ == '__main__':
    raise SystemExit(main())
