"""Two-layer audio identity test, WAV vs WAV, as a full matrix."""
from __future__ import annotations
import argparse, array, glob, math, sys, wave
import numpy as np
ENV_RATE = 100
WF_RATE = 16000
WIN_S = 1.0
LAG_MS = 45

def load_mono(path: str) -> tuple[np.ndarray, int]:
    w = wave.open(path)
    sr, ch, n = (w.getframerate(), w.getnchannels(), w.getnframes())
    raw = w.readframes(n)
    w.close()
    a = array.array('h')
    a.frombytes(raw)
    x = np.asarray(a, dtype=np.float64)
    if ch > 1:
        x = x.reshape(-1, ch).mean(axis=1)
    return (x, sr)

def resample(x: np.ndarray, sr: int, target: int) -> np.ndarray:
    if sr == target:
        return x
    n_out = int(round(x.size * target / sr))
    src = np.arange(x.size, dtype=np.float64)
    dst = np.linspace(0, x.size - 1, n_out)
    return np.interp(dst, src, x)

def log_env(x: np.ndarray, sr: int) -> np.ndarray:
    """100 Hz log-RMS envelope. Log so quiet structure counts as much as loud."""
    hop = max(sr // ENV_RATE, 1)
    n = x.size // hop * hop
    if n == 0:
        return np.zeros(0)
    fr = x[:n].reshape(-1, hop)
    rms = np.sqrt((fr * fr).mean(axis=1) + 1e-09)
    return np.log10(rms + 1e-06)

def ncc(a: np.ndarray, b: np.ndarray) -> float:
    if a.size < 8 or b.size < 8:
        return 0.0
    a = a - a.mean()
    b = b - b.mean()
    da, db = (math.sqrt(float(a @ a)), math.sqrt(float(b @ b)))
    if da == 0 or db == 0:
        return 0.0
    return float(a @ b) / (da * db)

def _xcorr_fft(a: np.ndarray, b: np.ndarray, max_lag: int) -> tuple[float, int]:
    """Normalised cross-correlation at every lag, via FFT."""
    a = a - a.mean()
    b = b - b.mean()
    na, nb = (a.size, b.size)
    if na < 200 or nb < 200:
        return (0.0, 0)
    n = 1 << int(np.ceil(np.log2(na + nb)))
    A = np.fft.rfft(a, n)
    B = np.fft.rfft(b, n)
    cc = np.fft.irfft(A * np.conj(B), n)
    denom = math.sqrt(float(a @ a)) * math.sqrt(float(b @ b)) or 1.0
    cc /= denom
    ml = int(min(max_lag, na // 2, nb // 2))
    pos = cc[:ml + 1]
    neg = cc[-ml:] if ml > 0 else np.zeros(0)
    i_pos = int(np.argmax(pos))
    v_pos = float(pos[i_pos])
    if neg.size:
        i_neg = int(np.argmax(neg))
        v_neg = float(neg[i_neg])
    else:
        v_neg, i_neg = (-2.0, 0)
    if v_pos >= v_neg:
        return (v_pos, i_pos)
    return (v_neg, -(ml - i_neg))

def env_align(ea: np.ndarray, eb: np.ndarray, speeds) -> tuple[float, float, int]:
    """Layer 1: best (r, speed, lag) over a speed sweep, FFT lag search."""
    best = (-2.0, 1.0, 0)
    for sp in speeds:
        e = eb if sp == 1.0 else np.interp(np.linspace(0, eb.size - 1, max(int(round(eb.size / sp)), 8)), np.arange(eb.size, dtype=np.float64), eb)
        r, lag = _xcorr_fft(ea, e, max_lag=3000)
        if r > best[0]:
            best = (r, sp, lag)
    return best

def window_wf(a: np.ndarray, b: np.ndarray, sr: int) -> tuple[float, float, int]:
    """Layer 2: per-1 s-window waveform NCC with +/-45 ms per-window lag."""
    win = int(WIN_S * sr)
    maxlag = int(LAG_MS * sr / 1000)
    n = min(a.size, b.size)
    if n < win + 2 * maxlag:
        return (0.0, 0.0, 0)
    scores = []
    for st in range(maxlag, n - win - maxlag, win):
        seg = a[st:st + win]
        if float(np.abs(seg).max()) < 1.0:
            continue
        best = -2.0
        for lag in range(-maxlag, maxlag + 1, max(maxlag // 15, 1)):
            r = ncc(seg, b[st + lag:st + lag + win])
            if r > best:
                best = r
        scores.append(best)
    if not scores:
        return (0.0, 0.0, 0)
    s = np.asarray(scores)
    return (float(np.median(s)), float((s > 0.3).mean()), s.size)

def prep(path: str, speeds_needed: bool=True):
    x, sr = load_mono(path)
    return {'path': path, 'env': log_env(x, sr), 'wf': resample(x, sr, WF_RATE), 'dur': x.size / sr}

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('--a', required=True, help='glob: set A (e.g. arcade renders)')
    ap.add_argument('--b', required=True, help='glob: set B (e.g. CD-DA)')
    ap.add_argument('--out', help='write full matrix TSV here')
    ap.add_argument('--top', type=int, default=3, help='best-N per A row to print')
    ap.add_argument('--speed-lo', type=float, default=0.85)
    ap.add_argument('--speed-hi', type=float, default=1.18)
    ap.add_argument('--speed-steps', type=int, default=12)
    args = ap.parse_args()
    A = sorted(glob.glob(args.a))
    B = sorted(glob.glob(args.b))
    if not A or not B:
        print(f'no files: A={len(A)} B={len(B)}', file=sys.stderr)
        return 1
    speeds = np.linspace(args.speed_lo, args.speed_hi, args.speed_steps)
    print(f'# A={len(A)} files  B={len(B)} files  speeds {args.speed_lo}-{args.speed_hi} x{args.speed_steps}', file=sys.stderr)
    pa = [prep(p) for p in A]
    pb = [prep(p) for p in B]
    rows = []
    for i, x in enumerate(pa):
        cand = []
        for y in pb:
            r, sp, lag = env_align(x['env'], y['env'], speeds)
            cand.append((r, sp, lag, y))
        cand.sort(key=lambda t: -t[0])
        for r, sp, lag, y in cand[:args.top]:
            wb = y['wf'] if sp == 1.0 else np.interp(np.linspace(0, y['wf'].size - 1, max(int(round(y['wf'].size / sp)), 8)), np.arange(y['wf'].size, dtype=np.float64), y['wf'])
            off = int(lag * WF_RATE / ENV_RATE)
            xa = x['wf'][off:] if off > 0 else x['wf']
            yb = wb if off > 0 else wb[-off:]
            p50, frac, nw = window_wf(xa, yb, WF_RATE)
            rows.append(dict(a=x['path'].split('/')[-1], b=y['path'].split('/')[-1], env_r=r, speed=sp, lag=lag, p50=p50, frac=frac, nwin=nw, a_dur=x['dur'], b_dur=y['dur']))
        top = rows[-1] if rows else None
        print(f"  {x['path'].split('/')[-1]:<16} best env_r={cand[0][0]:+.3f} -> {cand[0][3]['path'].split('/')[-1]}", file=sys.stderr)
    if args.out:
        with open(args.out, 'w') as f:
            f.write('a\tb\tenv_r\tspeed\tlag\tp50\tfrac_gt_0.3\tnwin\ta_dur\tb_dur\n')
            for r in rows:
                f.write(f"{r['a']}\t{r['b']}\t{r['env_r']:.4f}\t{r['speed']:.4f}\t{r['lag']}\t{r['p50']:.4f}\t{r['frac']:.3f}\t{r['nwin']}\t{r['a_dur']:.2f}\t{r['b_dur']:.2f}\n")
        print(f'wrote {args.out} ({len(rows)} rows)', file=sys.stderr)
    return 0
if __name__ == '__main__':
    raise SystemExit(main())
