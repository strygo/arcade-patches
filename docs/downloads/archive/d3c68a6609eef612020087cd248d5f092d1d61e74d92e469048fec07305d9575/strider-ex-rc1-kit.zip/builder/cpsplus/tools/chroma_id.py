"""Timbre-invariant composition matching: are these two carriers the same TUNE?"""
from __future__ import annotations
import argparse, array, glob, math, sys, wave
import numpy as np
ANALYSIS_SR = 11025
N_FFT = 4096
HOP = 1024
F_LO, F_HI = (65.0, 1050.0)
SPEEDS = np.unique(np.concatenate([np.linspace(0.88, 1.14, 9), [1.0]]))

def load_mono(path: str) -> tuple[np.ndarray, int]:
    w = wave.open(path)
    sr, ch, n = (w.getframerate(), w.getnchannels(), w.getnframes())
    raw = w.readframes(n)
    w.close()
    a = array.array('h')
    a.frombytes(raw)
    x = np.asarray(a, dtype=np.float64)
    if ch > 1:
        x = x.reshape(-1, ch).mean(axis=1)
    return (x, sr)

def resample(x: np.ndarray, sr: int, target: int) -> np.ndarray:
    if sr == target:
        return x
    n_out = int(round(x.size * target / sr))
    return np.interp(np.linspace(0, x.size - 1, n_out), np.arange(x.size, dtype=np.float64), x)

def chroma(x: np.ndarray, sr: int) -> np.ndarray:
    """12 x T pitch-class energy, L2-normalised per frame then z-scored per bin."""
    if x.size < N_FFT * 2:
        return np.zeros((12, 0))
    win = np.hanning(N_FFT)
    n_frames = 1 + (x.size - N_FFT) // HOP
    idx = np.arange(N_FFT)[None, :] + HOP * np.arange(n_frames)[:, None]
    frames = x[idx] * win
    spec = np.abs(np.fft.rfft(frames, axis=1))
    freqs = np.fft.rfftfreq(N_FFT, 1.0 / sr)
    keep = (freqs >= F_LO) & (freqs <= F_HI)
    f = freqs[keep]
    s = spec[:, keep]
    pc = np.round(12 * np.log2(f / 440.0) + 69).astype(int) % 12
    ch = np.zeros((n_frames, 12))
    for k in range(12):
        m = pc == k
        if m.any():
            ch[:, k] = s[:, m].sum(axis=1)
    nrm = np.sqrt((ch * ch).sum(axis=1, keepdims=True))
    nrm[nrm == 0] = 1.0
    ch = ch / nrm
    mu = ch.mean(axis=0, keepdims=True)
    sd = ch.std(axis=0, keepdims=True)
    sd[sd == 0] = 1.0
    return ((ch - mu) / sd).T

def chroma_ncc(ca: np.ndarray, cb: np.ndarray, max_lag: int=400) -> tuple[float, int]:
    """Best mean-over-bins NCC across lags, via FFT per pitch class."""
    if ca.shape[1] < 40 or cb.shape[1] < 40:
        return (0.0, 0)
    n = 1 << int(np.ceil(np.log2(ca.shape[1] + cb.shape[1])))
    acc = np.zeros(n)
    denom = 0.0
    for k in range(12):
        a = ca[k] - ca[k].mean()
        b = cb[k] - cb[k].mean()
        A = np.fft.rfft(a, n)
        B = np.fft.rfft(b, n)
        acc += np.fft.irfft(A * np.conj(B), n)
        denom += math.sqrt(float(a @ a)) * math.sqrt(float(b @ b))
    if denom == 0:
        return (0.0, 0)
    acc /= denom
    ml = int(min(max_lag, ca.shape[1] // 2, cb.shape[1] // 2))
    pos = acc[:ml + 1]
    neg = acc[-ml:] if ml > 0 else np.zeros(0)
    i_p = int(np.argmax(pos))
    v_p = float(pos[i_p])
    if neg.size:
        i_n = int(np.argmax(neg))
        v_n = float(neg[i_n])
    else:
        v_n, i_n = (-2.0, 0)
    return (v_p, i_p) if v_p >= v_n else (v_n, -(ml - i_n))

def prep(path: str):
    x, sr = load_mono(path)
    x = resample(x, sr, ANALYSIS_SR)
    return {'path': path, 'x': x, 'c': chroma(x, ANALYSIS_SR), 'dur': x.size / ANALYSIS_SR}

def best_pair(pa, pb) -> tuple[float, float, int]:
    """Best (r, speed, lag) over a tempo sweep."""
    best = (-2.0, 1.0, 0)
    for sp in SPEEDS:
        xb = pb['x'] if sp == 1.0 else np.interp(np.linspace(0, pb['x'].size - 1, max(int(round(pb['x'].size / sp)), N_FFT * 2)), np.arange(pb['x'].size, dtype=np.float64), pb['x'])
        cb = pb['c'] if sp == 1.0 else chroma(xb, ANALYSIS_SR)
        r, lag = chroma_ncc(pa['c'], cb)
        if r > best[0]:
            best = (r, float(sp), lag)
    return best

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('--a', required=True)
    ap.add_argument('--b', required=True)
    ap.add_argument('--out')
    ap.add_argument('--top', type=int, default=3)
    args = ap.parse_args()
    A = sorted(glob.glob(args.a))
    B = sorted(glob.glob(args.b))
    if not A or not B:
        print(f'no files: A={len(A)} B={len(B)}', file=sys.stderr)
        return 1
    print(f'# chroma: A={len(A)} B={len(B)} speeds x{len(SPEEDS)}', file=sys.stderr)
    pa = [prep(p) for p in A]
    pb = [prep(p) for p in B]
    rows = []
    for x in pa:
        cand = sorted(((*best_pair(x, y), y) for y in pb), key=lambda t: -t[0])
        for r, sp, lag, y in cand[:args.top]:
            rows.append((x['path'].split('/')[-1], y['path'].split('/')[-1], r, sp, lag))
        r0, s0, l0, y0 = cand[0]
        print(f"  {x['path'].split('/')[-1]:<14} r={r0:+.3f} speed={s0:.2f} -> {y0['path'].split('/')[-1]}", file=sys.stderr)
    if args.out:
        with open(args.out, 'w') as f:
            f.write('a\tb\tchroma_r\tspeed\tlag\n')
            for a, b, r, sp, lag in rows:
                f.write(f'{a}\t{b}\t{r:.4f}\t{sp:.4f}\t{lag}\n')
        print(f'wrote {args.out} ({len(rows)} rows)', file=sys.stderr)
    return 0
if __name__ == '__main__':
    raise SystemExit(main())
