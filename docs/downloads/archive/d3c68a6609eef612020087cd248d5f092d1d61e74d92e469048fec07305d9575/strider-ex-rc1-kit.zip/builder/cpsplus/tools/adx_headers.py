"""Parse ADX headers of dumped Y_DATA entries: rate, channels, samples, version, loop points."""
import struct, sys
from pathlib import Path
d = Path(__file__).parent / 'adx'
print('entry\tch\trate\tsamples\tdur_s\tver\tloop\tloop_start\tloop_end\tloop_len_s\tintro_s')
for p in sorted(d.glob('*.adx'), key=lambda x: int(x.stem)):
    b = p.read_bytes()[:64]
    magic, copyr = struct.unpack_from('>HH', b, 0)
    assert magic == 32768
    enc, fsz, bps, ch = (b[4], b[5], b[6], b[7])
    rate, samples = struct.unpack_from('>II', b, 8)
    ver = struct.unpack_from('>H', b, 18)[0]
    loop_flag = loop_start = loop_end = None
    if ver == 1024 and copyr >= 40:
        alignment = struct.unpack_from('>H', b, 38)[0] if copyr >= 40 else 0
        loop_flag = struct.unpack_from('>I', b, 36)[0]
        if loop_flag and copyr >= 56:
            loop_start = struct.unpack_from('>I', b, 40)[0]
            loop_end = struct.unpack_from('>I', b, 48)[0]
    elif ver == 768 and copyr >= 44:
        loop_flag = struct.unpack_from('>I', b, 24)[0]
        if loop_flag:
            loop_start = struct.unpack_from('>I', b, 28)[0]
            loop_end = struct.unpack_from('>I', b, 36)[0]
    if loop_start is not None:
        print(f'{p.stem}\t{ch}\t{rate}\t{samples}\t{samples / rate:.3f}\t{ver:#06x}\t1\t{loop_start}\t{loop_end}\t{(loop_end - loop_start) / rate:.3f}\t{loop_start / rate:.3f}')
    else:
        print(f'{p.stem}\t{ch}\t{rate}\t{samples}\t{samples / rate:.3f}\t{ver:#06x}\t{loop_flag or 0}\t-\t-\t-\t-')
