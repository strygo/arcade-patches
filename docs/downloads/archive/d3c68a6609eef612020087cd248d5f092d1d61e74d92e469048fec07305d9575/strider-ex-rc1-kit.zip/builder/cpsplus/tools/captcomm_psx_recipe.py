"""Freeze the approved Captain Commando PSX review into the pack recipe."""
from __future__ import annotations
import argparse
import concurrent.futures as cf
import json
import re
import statistics
import subprocess
import sys
from pathlib import Path
HERE = Path(__file__).resolve().parent
PKG = HERE.parent
sys.path.insert(0, str(HERE))
import captcomm_census as census
CAND = PKG / 'manifests' / 'captcomm_psx_loop_candidates.json'
DECISIONS = PKG / 'manifests' / 'captcomm_psx_listening_decisions.json'
CATALOG = PKG / 'manifests' / 'captcomm_psx_source_catalog.json'
OUT = PKG / 'manifests' / 'captcomm_psx_audio.json'
RATE = 37800
GRID = 32
ENDING, CREDITS = ('0x8f', '0x9e')
ENDING_TO_CREDITS_S = 25.86

def lufs(path: Path, start: float, dur: float) -> float:
    r = subprocess.run(['ffmpeg', '-v', 'info', '-nostats', '-ss', str(start), '-t', str(dur), '-i', str(path), '-af', 'ebur128', '-f', 'null', '-'], capture_output=True, text=True)
    m = re.findall('I:\\s+(-?[\\d.]+) LUFS', r.stderr)
    if not m:
        raise RuntimeError(f'{path}: no ebur128 reading')
    return float(m[-1])

def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--disc', type=Path, required=True)
    ap.add_argument('--work', type=Path, required=True)
    ap.add_argument('--out', type=Path, default=OUT)
    a = ap.parse_args()
    if a.work.exists() and any(a.work.iterdir()):
        ap.error(f'{a.work} is not empty: the recipe measures from nothing')
    a.work.mkdir(parents=True)
    cand = json.loads(CAND.read_text())
    rounds = json.loads(DECISIONS.read_text())['rounds']
    assert rounds[1]['result'].startswith('all good') and 'approved' in rounds[3]['decision']
    xa = a.work / 'xa'
    subprocess.run([sys.executable, str(HERE / 'captcomm_psx_xa_catalog.py'), '--disc', str(a.disc), '--out', str(a.work / 'catalog.json'), '--wav-dir', str(xa)], stdout=subprocess.DEVNULL, check=True)
    cat = json.loads((a.work / 'catalog.json').read_text())
    if cat != json.loads(CATALOG.read_text()):
        raise SystemExit('disc decode differs from the committed source catalog')
    tracks, triggers = ([], [])
    for r in cand['rows']:
        cmd = r['cmd']
        if not r['arranged']:
            continue
        lp = r.get('loop')
        t = {'id': cmd, 'role': r['role'], 'stream': r['arranged']['stream'], 'pcm_sha256': r['arranged']['pcm_sha256'], 'frames': r['arranged']['frames']}
        if r['proposal'] == 'one-shot':
            t['mode'] = 'one_shot'
        elif lp['mode'] == 'baked':
            t.update(mode='baked', loop_start=lp['ls'], loop_end=lp['le'], blend_samples=lp['blend_samples'])
        else:
            t.update(mode='xfade', loop_start=lp['ls'], loop_end=lp['le'])
        tracks.append(t)
        triggers.append({'command': cmd, 'track': cmd})
    end = next((t for t in tracks if t['id'] == ENDING))
    cut = int(ENDING_TO_CREDITS_S * RATE) // GRID * GRID
    tracks.append({'id': '0x8f_credits', 'role': 'Ending, from the credits on', 'stream': end['stream'], 'pcm_sha256': end['pcm_sha256'], 'frames': end['frames'], 'mode': 'one_shot', 'start': cut})
    triggers.append({'command': CREDITS, 'track': '0x8f_credits'})
    looped = [t for t in tracks if t['mode'] != 'one_shot']

    def native(t):
        o = census.inject('captcommu', a.work / 'native' / t['id'], t['id'][2:], slot=900)
        x, rr = census.pcm(o / 'audio.wav')
        s = census.markers(o)[0]
        p = o / 'cue.wav'
        subprocess.run(['ffmpeg', '-v', 'error', '-y', '-ss', str(s), '-t', '12', '-i', str(o / 'audio.wav'), '-ac', '2', str(p)], check=True)
        return p
    with cf.ThreadPoolExecutor(4) as ex:
        nat = dict(zip([t['id'] for t in looped], ex.map(native, looped)))
    rows = []
    for t in looped:
        n, s = (lufs(nat[t['id']], 1, 8), lufs(xa / t['stream'], 1, 8))
        rows.append({'command': t['id'], 'native_lufs': n, 'psx_lufs': s, 'delta_lu': round(s - n, 2)})
    med = statistics.median((r['delta_lu'] for r in rows))
    gain = min(127, round(127 * 10 ** (-med / 20)))
    rec = {'schema': 1, 'pack': 'captcomm_psx', 'review_status': 'approved', 'reviewed': 'listening rounds 1-4, manifests/captcomm_psx_listening_decisions.json', 'source': {'disc': 'Captain Commando (Japan), SLPS-01567', 'image_sha256': cat['disc']['image_sha256'], 'rate': RATE}, 'xfade_samples': cand['xfade_samples'], 'trigger_gain': gain, 'loudness': {'method': 'EBU R128 integrated, seconds 1..9, native render vs arranged stream, per looping mapped command; median delta', 'median_delta_lu': round(med, 2), 'rows': rows}, 'control_stop': ['0xf0', '0xf2', '0xf7'], 'substitute': '0xf7', 'tracks': tracks, 'triggers': triggers}
    a.out.write_text(json.dumps(rec, indent=1) + '\n')
    print(f'wrote {a.out}: {len(tracks)} tracks, {len(triggers)} triggers, median delta {med:+.2f} LU -> trigger gain {gain}')
    return 0
if __name__ == '__main__':
    sys.exit(main())
