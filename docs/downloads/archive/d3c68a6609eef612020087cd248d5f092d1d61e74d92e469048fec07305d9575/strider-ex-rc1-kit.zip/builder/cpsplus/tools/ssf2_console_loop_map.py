"""Map the 3DO SSF2T and FM Towns SSF2 soundtracks onto the HSF2 AE arrange"""
from __future__ import annotations
import argparse
import csv
import hashlib
import sys
import tomllib
import wave
from dataclasses import dataclass, field
from math import gcd
from pathlib import Path
from typing import Callable
import numpy as np
from scipy.optimize import linear_sum_assignment
from scipy.signal import butter, fftconvolve, resample_poly, sosfiltfilt
TOOLS = Path(__file__).resolve().parent
ROOT = TOOLS.parent
sys.path.insert(0, str(TOOLS))
sys.path.insert(0, str(ROOT))
FEAT_SR = 8000
CHROMA_WIN, CHROMA_HOP = (2048, 4000)
FLUX_WIN, FLUX_HOP = (256, 64)
FLUX_FPS = FEAT_SR / FLUX_HOP
MATCH_MAX = 0.25
MATCH_WEAK = 0.4
ALIGN_WIN_S, ALIGN_STEP_S = (8.0, 6.0)
ALIGN_MIN_NCC = 0.5
STRAIGHT_RESID_S = 0.04
STRAIGHT_FRAC = 0.6
FADE_DB = 1.5
FADE_GUARD_S = 1.0
GAIN_MATCH_DB = 1.0
ALIGN_MIN_LOCAL = 0.8
LOCAL_BAND_HZ = 3000
MANIFESTS = ROOT / 'manifests'
OUT_TSV = MANIFESTS / 'ssf2_console_loop_map.tsv'
COVERAGE_TSV = MANIFESTS / 'ssf2_console_loop_coverage.tsv'

def mono(pcm: np.ndarray) -> np.ndarray:
    return pcm.astype(np.float32).mean(axis=1) / 32768.0

def resample(x: np.ndarray, src: int, dst: int) -> np.ndarray:
    if src == dst:
        return x
    g = gcd(src, dst)
    return resample_poly(x, dst // g, src // g).astype(np.float32)

def chroma(x: np.ndarray) -> np.ndarray:
    """Unit-norm, mean-removed log chroma per 0.5 s frame."""
    if len(x) < CHROMA_WIN:
        return np.zeros((0, 12), np.float32)
    fr = np.lib.stride_tricks.sliding_window_view(x, CHROMA_WIN)[::CHROMA_HOP]
    sp = np.abs(np.fft.rfft(fr * np.hanning(CHROMA_WIN), axis=1)) ** 2
    fq = np.fft.rfftfreq(CHROMA_WIN, 1 / FEAT_SR)
    sel = (fq > 60) & (fq < 2500)
    pc = np.floor(12 * np.log2(fq[sel] / 261.63) + 0.5).astype(int) % 12
    sp = sp[:, sel]
    c = np.stack([sp[:, pc == k].sum(axis=1) for k in range(12)], axis=1)
    c = np.log(c * 1000000.0 + 1000.0)
    c -= c.mean(axis=1, keepdims=True)
    return (c / (np.linalg.norm(c, axis=1, keepdims=True) + 1e-09)).astype(np.float32)

def flux(x: np.ndarray) -> np.ndarray:
    """Positive spectral-flux onset envelope at FLUX_FPS, unit variance."""
    if len(x) < FLUX_WIN + FLUX_HOP:
        return np.zeros(0, np.float32)
    fr = np.lib.stride_tricks.sliding_window_view(x, FLUX_WIN)[::FLUX_HOP]
    s = np.log(np.abs(np.fft.rfft(fr * np.hanning(FLUX_WIN), axis=1)) + 0.1)
    f = np.maximum(np.diff(s, axis=0), 0).sum(axis=1)
    f -= f.mean()
    return (f / (f.std() + 1e-09)).astype(np.float32)

def fade_start(x: np.ndarray) -> float:
    """Seconds after which the master never again reaches (body - FADE_DB)."""
    w = FEAT_SR // 2
    k = len(x) // w
    if k < 4:
        return len(x) / FEAT_SR
    lv = 20 * np.log10(np.sqrt((x[:k * w].reshape(k, w).astype(np.float64) ** 2).mean(axis=1)) + 1e-09)
    body = np.percentile(lv[:max(k // 2, 2)], 75)
    ok = np.where(lv >= body - FADE_DB)[0]
    return float((ok[-1] + 1) * 0.5) if len(ok) else 0.0

def dtw_cost(q: np.ndarray, r: np.ndarray, slack: int=8) -> float:
    """Open-end DTW of query frames q onto reference frames r.  Steps"""
    q = q[:len(r)]
    n, m = (len(q), len(r))
    if n < 4:
        return 1.0
    cost = 1.0 - q @ r.T
    inf = 1000000000.0
    d = np.full((n, m), inf)
    d[0, :slack + 1] = cost[0, :slack + 1]
    for i in range(1, n):
        best = np.full(m, inf)
        best[1:] = d[i - 1][:-1]
        best[2:] = np.minimum(best[2:], d[i - 1][:-2])
        if i >= 2:
            best[1:] = np.minimum(best[1:], d[i - 2][:-1])
        d[i] = cost[i] + best
    return float(d[n - 1].min() / n)

def _ncc_search(a: np.ndarray, b: np.ndarray):
    """Best normalised correlation of a inside b (valid positions), by FFT."""
    if len(b) < len(a) or len(a) < 20:
        return None
    a = a.astype(np.float64) - a.mean()
    b = b.astype(np.float64)
    num = fftconvolve(b, a[::-1], mode='valid')
    cs = np.concatenate([[0.0], np.cumsum(b)])
    cs2 = np.concatenate([[0.0], np.cumsum(b * b)])
    n = len(a)
    var = cs2[n:] - cs2[:-n] - (cs[n:] - cs[:-n]) ** 2 / n
    den = np.sqrt(np.maximum(var, 1e-12) * float((a * a).sum()))
    ncc = num / den
    k = int(np.argmax(ncc))
    return (k, float(ncc[k]))

@dataclass
class TimeMap:
    offset: float
    drift: float
    ncc: float
    ok_frac: float
    resid: float
    windows: int
    tried: int

    def __call__(self, t: float) -> float:
        return t + self.offset + self.drift * t

    @property
    def straight(self) -> bool:
        return self.tried >= 1 and self.windows >= min(3, self.tried) and (self.ok_frac >= STRAIGHT_FRAC) and (self.resid <= STRAIGHT_RESID_S)

def fit_time_map(hf: np.ndarray, cf: np.ndarray, guess: float=0.0) -> TimeMap:
    """Windowed onset-envelope correlation of the HSF2 flux hf against the"""
    hdur, cdur = (len(hf) / FLUX_FPS, len(cf) / FLUX_FPS)
    win = min(ALIGN_WIN_S, max(1.0, min(hdur, cdur - guess) - 0.5))
    wlen = int(win * FLUX_FPS)
    pts, tried = ([], 0)
    t, est = (0.2, guess)
    while t + win <= min(hdur, cdur - est - 0.3):
        a = hf[int(t * FLUX_FPS):int(t * FLUX_FPS) + wlen]
        span = 4.0 if not pts else 1.0
        lo = max(0, int((t + est - span) * FLUX_FPS))
        hi = int((t + est + win + span) * FLUX_FPS)
        res = _ncc_search(a, cf[lo:hi])
        tried += 1
        if res and res[1] >= ALIGN_MIN_NCC:
            lag = (lo + res[0]) / FLUX_FPS - t
            pts.append((t, lag, res[1]))
            est = lag
        t += ALIGN_STEP_S
    if not pts:
        return TimeMap(guess, 0.0, 0.0, 0.0, 9.9, 0, tried)
    ts, lags = (np.array([p[0] for p in pts]), np.array([p[1] for p in pts]))
    ncc = float(np.median([p[2] for p in pts]))
    if len(pts) < 3:
        off = float(np.median(lags))
        return TimeMap(off, 0.0, ncc, len(pts) / tried, float(np.abs(lags - off).max()), len(pts), tried)
    keep = np.ones(len(ts), bool)
    for _ in range(3):
        slope, icpt = np.polyfit(ts[keep], lags[keep], 1)
        res = np.abs(lags - (icpt + slope * ts))
        keep = res <= max(3 * np.median(res[keep]), 0.02)
        if keep.sum() < 3:
            keep[:] = True
            break
    slope, icpt = np.polyfit(ts[keep], lags[keep], 1)
    resid = float(np.abs(lags[keep] - (icpt + slope * ts[keep])).max())
    return TimeMap(float(icpt), float(slope), ncc, len(pts) / tried, resid, len(pts), tried)

def _band(x: np.ndarray, rate: int) -> np.ndarray:
    sos = butter(4, LOCAL_BAND_HZ, btype='low', fs=rate, output='sos')
    return sosfiltfilt(sos, x)

def align_point(h: np.ndarray, h_rate: int, c: np.ndarray, c_rate: int, t_h: float, t_c: float, before: float, after: float, search: float=0.08):
    """Where, in console mono c, the HSF2 audio around t_h sits."""
    h0, h1 = (int((t_h - before) * h_rate), int((t_h + after) * h_rate))
    if h0 < 0 or h1 > len(h):
        return (t_c, 0.0, 0.0)
    seg = resample(h[h0:h1], h_rate, c_rate)
    c0 = int((t_c - before - search) * c_rate)
    c1 = int((t_c + after + search) * c_rate) + 1
    if c0 < 0 or c1 > len(c):
        return (t_c, 0.0, 0.0)
    res = _ncc_search(_band(seg, c_rate), _band(c[c0:c1], c_rate))
    if not res:
        return (t_c, 0.0, 0.0)
    k, ncc = res
    got = c[c0 + k:c0 + k + len(seg)].astype(np.float64)
    gain = 20 * np.log10((np.sqrt((got ** 2).mean()) + 1e-09) / (np.sqrt((seg.astype(np.float64) ** 2).mean()) + 1e-09))
    return ((c0 + k) / c_rate + before, ncc, float(gain))

def level_ratio_db(hx: np.ndarray, cx: np.ndarray, tm: 'TimeMap', fade: float) -> float:
    """Median level of the console master relative to HSF2, in dB, over the"""
    hdur = len(hx) / FEAT_SR
    end = min(hdur, fade - tm.offset - 0.1)
    w = 2.0 if end >= 4.0 else max(end, 0.5)
    vals, t = ([], 0.0)
    while t + w <= end + 1e-09:
        h = hx[int(t * FEAT_SR):int((t + w) * FEAT_SR)].astype(np.float64)
        c0 = int(tm(t) * FEAT_SR)
        c = cx[max(c0, 0):max(c0, 0) + len(h)].astype(np.float64)
        if len(c) == len(h) and len(h):
            rh, rc = (np.sqrt((h * h).mean()), np.sqrt((c * c).mean()))
            if rh > 0.001 and rc > 0.0001:
                vals.append(20 * np.log10(rc / rh))
        t += w
    return float(np.median(vals)) if vals else 0.0

def second_pass_ncc(x: np.ndarray, ls_c: float, le_c: float, fade: float):
    """Evidence only: does the console's second pass repeat the first?"""
    w = min(fade - FADE_GUARD_S - le_c, 8.0)
    if w < 1.0:
        return (0.0, 0.0)
    a = x[int(ls_c * FEAT_SR):int((ls_c + w) * FEAT_SR)]
    lo = int((le_c - 0.1) * FEAT_SR)
    res = _ncc_search(a, x[lo:int((le_c + w + 0.1) * FEAT_SR)])
    return (w, res[1]) if res else (0.0, 0.0)

@dataclass
class Track:
    kind: str
    name: str
    rate: int
    seconds: float
    x: np.ndarray = field(repr=False)
    chroma: np.ndarray = field(repr=False)
    flux: np.ndarray = field(repr=False)
    load: Callable[[], np.ndarray] = field(default=None, repr=False)
    sha1: str = ''

def _track(kind, name, pcm, rate, load) -> Track:
    x = resample(mono(pcm), rate, FEAT_SR)
    return Track(kind, name, rate, len(pcm) / rate, x, chroma(x), flux(x), load, hashlib.sha1(np.ascontiguousarray(pcm, dtype='<i2').tobytes()).hexdigest()[:16])

def load_3do(disc) -> list[Track]:
    import extract_3do_bgm as e3
    fs = e3.open_disc(disc)
    out = []
    for name, a in e3.read_bgm(fs):
        pcm = e3.decode_aifc(a)
        out.append(_track('3do', name.rsplit('.', 1)[0], pcm, int(round(a.rate)), lambda a=a: e3.decode_aifc(a)))
    return out

def load_fmtowns(disc, cache: Path) -> list[Track]:
    from pack import discsrc
    discsrc.ensure_audio_cache(cache, {'tr02'}, disc, '--fmtowns')

    def read(w):
        with wave.open(str(w)) as r:
            return (np.frombuffer(r.readframes(r.getnframes()), '<i2').reshape(-1, r.getnchannels()), r.getframerate())
    out = []
    for w in sorted(cache.glob('tr*.wav')):
        pcm, rate = read(w)
        if len(pcm) / rate < 1.5:
            continue
        out.append(_track('fmtowns', w.stem, pcm, rate, lambda w=w: read(w)[0]))
    return out

@dataclass
class HsfEntry:
    entry: int
    name: str
    cmds: list[str]
    loop: bool
    ls: float
    le: float

def load_hsf2(disc) -> tuple[list[HsfEntry], dict[int, Track]]:
    from pack import adxcodec
    from pack.afs import AfsArchive
    from pack.build_common import iso_find_basename
    from pack.isofs import IsoFS
    from pack.protocols import HSF2_AFS_NAME
    from pack.sources import resolve_image
    rows: dict[int, HsfEntry] = {}
    with open(MANIFESTS / 'hsf2_bgm_command_map.tsv', newline='') as f:
        for r in csv.DictReader(f, delimiter='\t'):
            if r['set'] != 'ARRANGE' or r['in_game'] != 'yes':
                continue
            e, rate = (int(r['afs_entry']), int(r['rate']))
            h = rows.setdefault(e, HsfEntry(e, r['name'], [], r['loop'] == '1', int(r['loop_start_sample']) / rate, int(r['loop_end_sample']) / rate))
            h.cmds.append(r['cmd'])
    iso = IsoFS(resolve_image(disc, member_hint='.iso'))
    _p, lba, _s = iso_find_basename(iso, HSF2_AFS_NAME)
    afs = AfsArchive(iso.f, iso.byte_offset(lba))

    def decode(e):
        b, info = adxcodec.decode_file_bytes(afs.read(e))
        return (np.frombuffer(b, '<i2').reshape(-1, info.channels), info.sample_rate)
    tracks = {}
    for e in sorted(rows):
        pcm, rate = decode(e)
        tracks[e] = _track('hsf2', f'arg_{e:02d}', pcm, rate, lambda e=e: decode(e)[0])
    return ([rows[e] for e in sorted(rows)], tracks)

def match(srcs: list[Track], hsf: dict[int, Track]):
    ents = sorted(hsf)
    cost = np.ones((len(srcs), len(ents)))
    for i, s in enumerate(srcs):
        for j, e in enumerate(ents):
            cost[i, j] = dtw_cost(hsf[e].chroma[:150], s.chroma[:150])
    r, c = linear_sum_assignment(np.minimum(cost, 0.6))
    asg = {int(i): int(j) for i, j in zip(r, c) if cost[i, j] <= MATCH_MAX}
    return (cost, ents, asg)

def judge(src: Track, h: HsfEntry, ht: Track, tm: TimeMap, fade: float) -> dict:
    """Loop class for one matched pair, with sample-level points when it fits."""
    if not tm.straight:
        return {'cls': 'PARTIAL'}
    if not h.loop:
        return {'cls': 'ONE_SHOT'}
    ls_c, le_c = (tm(h.ls), tm(h.le))
    out = {'loop_end_c': round(le_c, 2), 'margin_s': round(fade - le_c, 2)}
    if le_c > src.seconds - 0.05:
        return {**out, 'cls': 'PAST_END'}
    if le_c > fade - FADE_GUARD_S:
        return {**out, 'cls': 'IN_FADE'}
    hm = mono(ht.load())
    cm = mono(src.load())
    ls_r, n_ls, g_ls = align_point(hm, ht.rate, cm, src.rate, h.ls, ls_c, 0.2, 0.4)
    le_r, n_le, g_le = align_point(hm, ht.rate, cm, src.rate, h.le, le_c, 0.6, 0.0)
    out.update(ncc_ls=round(n_ls, 3), ncc_le=round(n_le, 3), gain_ls_db=round(g_ls, 1), gain_le_db=round(g_le, 1))
    if min(n_ls, n_le) < ALIGN_MIN_LOCAL:
        return {**out, 'cls': 'ALIGN_FAIL'}
    if abs(g_le - g_ls) > GAIN_MATCH_DB:
        return {**out, 'cls': 'IN_FADE'}
    out.update(loop_start=int(round(ls_r * src.rate)), loop_end=int(round(le_r * src.rate)), period_err_ms=round((le_r - ls_r - (h.le - h.ls)) * 1000, 2))
    w, wave_ncc = second_pass_ncc(src.x, ls_c, le_c, fade)
    out.update(repeat_s=round(w, 1), wave_ncc=round(wave_ncc, 3))
    return {**out, 'cls': 'LOOP_OK'}

def analyse(srcs, hsf_entries, hsf_tracks, kind_guess):
    by_entry = {h.entry: h for h in hsf_entries}
    cost, ents, asg = match(srcs, hsf_tracks)
    weak = {}
    for i in sorted((i for i in range(len(srcs)) if i not in asg), key=lambda i: cost[i].min()):
        free = [j for j in range(len(ents)) if j not in asg.values() and cost[i, j] <= MATCH_WEAK]
        if not free:
            continue
        j = min(free, key=lambda j: cost[i, j])
        tm = fit_time_map(hsf_tracks[ents[j]].flux, srcs[i].flux, guess=kind_guess)
        if tm.straight:
            asg[i] = j
            weak[i] = True
    rows = []
    for i, s in enumerate(srcs):
        order = np.argsort(cost[i])
        row = {'source': s.kind, 'track': s.name, 'seconds': round(s.seconds, 2), 'pcm_sha1': s.sha1, 'best_entry': ents[order[0]], 'best_cost': round(float(cost[i, order[0]]), 3), 'second_cost': round(float(cost[i, order[1]]), 3)}
        if i not in asg:
            row.update(cls='NO_MATCH')
            rows.append(row)
            print(f'  {s.kind} {s.name}: NO_MATCH')
            continue
        e = ents[asg[i]]
        h, ht = (by_entry[e], hsf_tracks[e])
        tm = fit_time_map(ht.flux, s.flux, guess=kind_guess)
        fade = fade_start(s.x)
        row.update(match='weak' if weak.get(i) else 'strong', entry=e, hsf2_name=h.name, cmds=' '.join(h.cmds), cost=round(float(cost[i, asg[i]]), 3), offset_s=round(tm.offset, 3), drift_ppm=round(tm.drift * 1000000.0), align_ncc=round(tm.ncc, 2), windows=f'{tm.windows}/{tm.tried}', hsf2_loop=int(h.loop), hsf2_ls=round(h.ls, 3), hsf2_le=round(h.le, 3), fade_s=round(fade, 1))
        row.update(judge(s, h, ht, tm, fade))
        if tm.straight:
            row['level_db'] = round(level_ratio_db(ht.x, s.x, tm, fade), 2)
        rows.append(row)
        print(f"  {s.kind} {s.name}: hs{e} {h.name}: {row['cls']}")
    return rows
COLS = ['source', 'track', 'seconds', 'pcm_sha1', 'cls', 'match', 'entry', 'hsf2_name', 'cmds', 'cost', 'best_entry', 'best_cost', 'second_cost', 'offset_s', 'drift_ppm', 'align_ncc', 'windows', 'level_db', 'hsf2_loop', 'hsf2_ls', 'hsf2_le', 'fade_s', 'loop_end_c', 'margin_s', 'ncc_ls', 'ncc_le', 'gain_ls_db', 'gain_le_db', 'loop_start', 'loop_end', 'period_err_ms', 'repeat_s', 'wave_ncc']

def write_tsv(rows: list[dict], path: Path, cols=COLS) -> None:
    with open(path, 'w', newline='') as f:
        w = csv.DictWriter(f, cols, delimiter='\t', extrasaction='ignore', restval='')
        w.writeheader()
        w.writerows(rows)

def coverage(entries: list[HsfEntry], rows: list[dict], hsf_tracks: dict) -> list[dict]:
    """One row per HSF2 entry: which console track carries it and how it loops."""
    out = []
    for h in entries:
        row = {'entry': h.entry, 'hsf2_name': h.name, 'cmds': ' '.join(h.cmds), 'hsf2_loop': int(h.loop), 'hsf2_pcm_sha1': hsf_tracks[h.entry].sha1}
        for kind in ('3do', 'fmtowns'):
            hit = [r for r in rows if r['source'] == kind and r.get('entry') == h.entry]
            row[f'{kind}_track'] = hit[0]['track'] if hit else ''
            row[f'{kind}_class'] = hit[0]['cls'] if hit else 'ABSENT'
        out.append(row)
    return out
COV_COLS = ['entry', 'hsf2_name', 'cmds', 'hsf2_loop', 'hsf2_pcm_sha1', '3do_track', '3do_class', 'fmtowns_track', 'fmtowns_class']

def summary(rows: list[dict]) -> str:
    out = []
    for kind in ('3do', 'fmtowns'):
        rs = [r for r in rows if r['source'] == kind]
        if rs:
            counts = {}
            for r in rs:
                counts[r['cls']] = counts.get(r['cls'], 0) + 1
            out.append(f'{kind}: {len(rs)} tracks  ' + '  '.join((f'{k}={v}' for k, v in sorted(counts.items()))))
    return '\n'.join(out)

def _synth(seed: int, seconds: float, beat: float=1.0, rate: int=FEAT_SR) -> np.ndarray:
    """Tonal, rhythmic test material: a random triad per beat, each beat"""
    rng = np.random.default_rng(seed)
    n = int(seconds * rate)
    t = np.arange(n) / rate
    idx = (t / beat).astype(int) % 400
    chords = rng.integers(0, 12, (400, 3))
    x = np.zeros(n)
    for k in range(3):
        f = 220 * 2 ** (chords[idx, k] / 12)
        x += np.sin(2 * np.pi * np.cumsum(f) / rate)
    env = np.exp(-4 * (t % beat) / beat)
    return (0.3 * x * env).astype(np.float32)

def _self_test() -> None:
    a, b = (_synth(1, 70), _synth(2, 70))
    ca, cb = (chroma(a), chroma(b))
    same = dtw_cost(ca, chroma(_synth(1, 70 * 1.12, beat=1.12)))
    other = dtw_cost(ca, cb)
    assert same < 0.15 < 0.3 < other, (same, other)
    c = np.concatenate([np.zeros(int(2.0 * FEAT_SR), np.float32), a])
    c = resample_poly(c, 1000000, 1000150).astype(np.float32)
    tm = fit_time_map(flux(a), flux(c), guess=0.0)
    assert tm.straight and abs(tm.offset - 2.0) < 0.03 and (abs(tm.drift + 0.00015) < 0.00015), tm
    assert not fit_time_map(flux(a), flux(b)).straight
    short = fit_time_map(flux(a[:4 * FEAT_SR]), flux(c[:7 * FEAT_SR]), guess=0.0)
    assert short.straight and abs(short.offset - 2.0) < 0.03, short
    x = _synth(3, 30)
    x[-3 * FEAT_SR:] *= np.linspace(1, 0, 3 * FEAT_SR)
    assert 26.5 <= fade_start(x) <= 27.6, fade_start(x)
    r48 = 48000
    h = _synth(4, 20, rate=r48)
    delay = 0.0125
    cons = np.concatenate([np.zeros(int(delay * 44100), np.float32), resample(h, r48, 44100)])
    t_ref, ncc, gain = align_point(h, r48, cons, 44100, 9.0, 9.0, 0.3, 0.3)
    assert ncc > 0.95 and abs(t_ref - (9.0 + delay)) < 1.5 / 44100 and (abs(gain) < 0.5), (t_ref, ncc, gain)
    _t, ncc_h, gain_h = align_point(h, r48, cons * 0.5, 44100, 9.0, 9.0, 0.3, 0.3)
    assert ncc_h > 0.95 and abs(gain_h + 6.02) < 0.3, (ncc_h, gain_h)
    other48 = resample(_synth(9, 20, rate=r48), r48, 44100)
    assert align_point(h, r48, other48, 44100, 9.0, 9.0, 0.3, 0.3)[1] < ALIGN_MIN_LOCAL
    assert align_point(h, r48, cons, 44100, 0.1, 0.1, 0.3, 0.3)[1] == 0.0
    lv = level_ratio_db(a, 0.5 * np.concatenate([np.zeros(2 * FEAT_SR, np.float32), a]), TimeMap(2.0, 0.0, 1, 1, 0, 9, 9), 60.0)
    assert abs(lv + 6.02) < 0.05, lv
    loop, intro = (_synth(5, 12), _synth(6, 4))
    second = loop.copy()
    second[-4 * FEAT_SR:] *= np.linspace(1, 0, 4 * FEAT_SR)
    master = np.concatenate([intro, loop, second])

    def trk(name, sig):
        pcm = (np.stack([sig, sig], 1) * 32767).astype(np.int16)
        return Track('3do', name, FEAT_SR, len(pcm) / FEAT_SR, sig, chroma(sig), flux(sig), lambda p=pcm: p)
    ident = TimeMap(0.0, 0.0, 1.0, 1.0, 0.0, 9, 9)
    hs = HsfEntry(1, 'T', ['0x01'], True, 4.0, 16.0)
    ht = trk('h', np.concatenate([intro, loop, loop]))
    src = trk('c', master)
    fs = fade_start(master)
    got = judge(src, hs, ht, ident, fs)
    assert got['cls'] == 'LOOP_OK' and abs(got['loop_end'] - 16 * FEAT_SR) <= 1 and (abs(got['loop_start'] - 4 * FEAT_SR) <= 1), got
    assert judge(src, HsfEntry(1, 'T', [], True, 4.0, 40.0), ht, ident, fs)['cls'] == 'PAST_END'
    assert judge(src, HsfEntry(1, 'T', [], True, 4.0, 26.0), ht, ident, fs)['cls'] == 'IN_FADE'
    assert judge(src, HsfEntry(1, 'T', [], False, 0.0, 0.0), ht, ident, fs)['cls'] == 'ONE_SHOT'
    soft = master.copy()
    soft[int(14 * FEAT_SR):int(16.5 * FEAT_SR)] *= np.linspace(1, 0.4, int(2.5 * FEAT_SR))
    soft[int(16.5 * FEAT_SR):] *= 0.4
    assert judge(trk('s', soft), hs, ht, ident, 60.0)['cls'] == 'IN_FADE'
    bad_h = trk('bh', np.concatenate([_synth(7, 4), _synth(8, 24)]))
    assert judge(src, hs, bad_h, ident, fs)['cls'] == 'ALIGN_FAIL'
    assert judge(src, hs, ht, TimeMap(0, 0, 0.1, 0.2, 9.9, 1, 5), fs)['cls'] == 'PARTIAL'
    other = _synth(11, 40)
    ht2 = trk('h2', np.concatenate([_synth(12, 4), _synth(13, 36)]))
    ents = [hs, HsfEntry(2, 'U', ['0x02'], True, 3.0, 20.0)]
    rows = analyse([src, trk('x', other)], ents, {1: ht, 2: ht2}, 0.0)
    assert rows[0]['entry'] == 1 and rows[0]['match'] == 'strong' and (rows[0]['cls'] == 'LOOP_OK'), rows[0]
    assert rows[1]['cls'] == 'NO_MATCH', rows[1]
    cov = coverage(ents, rows, {1: ht, 2: ht2})
    assert cov[0]['3do_class'] == 'LOOP_OK' and cov[1]['3do_class'] == 'ABSENT', cov
    print('ssf2_console_loop_map self-test OK')

def _disc(cfg: dict, key: str, given: str | None) -> str:
    if given:
        return given
    if key not in cfg:
        raise SystemExit(f'no disc: pass it explicitly or set {key} in release/discs.toml')
    return cfg[key]

def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.split('\n\n')[0])
    ap.add_argument('--self-test', action='store_true')
    ap.add_argument('--3do', dest='tdo', help='3DO SSF2T disc (.chd/.cue)')
    ap.add_argument('--fmtowns', help='FM Towns SSF2 rip (.cue or a zip containing one)')
    ap.add_argument('--hsf2', help='HSF2 AE disc (.chd/.iso/zip)')
    ap.add_argument('--out', default=str(OUT_TSV))
    ap.add_argument('--coverage', default=str(COVERAGE_TSV))
    ap.add_argument('--check', action='store_true', help='rebuild into a temp dir and fail if the committed manifests differ')
    ap.add_argument('--work', help="scratch root for the disc caches (default: this tree's work/)")
    ap.add_argument('--cache', help='FM Towns CD-DA cache (default: <work>/console_loops/fmtowns)')
    a = ap.parse_args(argv)
    if a.self_test:
        _self_test()
        return 0
    work = Path(a.work) if a.work else ROOT / 'work'
    if a.work:
        from pack import discsrc, sources
        sources.CACHE_DIR = work / 'cache'
        discsrc.DISC_CACHE = work / 'discs'
    cache = Path(a.cache) if a.cache else work / 'console_loops' / 'fmtowns'
    cfg = tomllib.loads((ROOT.parent / 'release' / 'discs.toml').read_text())
    print('[hsf2] decoding the arrange bank')
    entries, htracks = load_hsf2(_disc(cfg, 'hsf2_ae_iso', a.hsf2))
    rows = []
    print('[3do] reading /BGM')
    rows += analyse(load_3do(_disc(cfg, 'ssf2t_3do_disc', a.tdo)), entries, htracks, 0.0)
    print('[fmtowns] extracting CD-DA')
    rows += analyse(load_fmtowns(_disc(cfg, 'ssf2_fmtowns_disc', a.fmtowns), cache), entries, htracks, 2.0)
    out, cov = (Path(a.out), Path(a.coverage))
    if a.check:
        import tempfile
        tmp = Path(tempfile.mkdtemp())
        out, cov = (tmp / out.name, tmp / cov.name)
    write_tsv(rows, out)
    write_tsv(coverage(entries, rows, htracks), cov, COV_COLS)
    print(summary(rows))
    if a.check:
        bad = [p.name for p, q in ((out, Path(a.out)), (cov, Path(a.coverage))) if not q.exists() or p.read_bytes() != q.read_bytes()]
        print('manifests differ: ' + ', '.join(bad) if bad else 'manifests reproduce byte-identical')
        return 1 if bad else 0
    print(f'wrote {out} and {cov}')
    return 0
if __name__ == '__main__':
    sys.exit(main())
