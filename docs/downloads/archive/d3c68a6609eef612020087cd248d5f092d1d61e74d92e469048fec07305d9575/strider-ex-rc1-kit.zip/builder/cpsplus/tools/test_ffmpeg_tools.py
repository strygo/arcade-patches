"""Shared media resolution: pairing, overrides, cache isolation and CLI controls."""
import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import fetch_ffmpeg
import ffmpeg_runtime as runtime
from test_switch_helpers import Helpers

class MediaArchive(Helpers):

    def setUp(self):
        super().setUp()
        self.files = {'bin/ffmpeg': b'ffmpeg-fixture', 'bin/ffprobe': b'ffprobe-fixture', 'licenses/LICENSE': b'LGPL'}
        self.data = self.zip(self.files)
        self.record.update(bytes=len(self.data), sha256=fetch_ffmpeg.common.sha(self.data), files={n: fetch_ffmpeg.common.sha(d) for n, d in self.files.items()}, executables={'ffmpeg': 'bin/ffmpeg', 'ffprobe': 'bin/ffprobe'})
        self.manifest.write_text(json.dumps(dict(schema=1, platforms={'test': self.record})))

    def setup(self):
        return fetch_ffmpeg.setup(manifest=self.manifest, host='test')

    def test_cold_download_then_offline_cache(self):
        with patch.object(fetch_ffmpeg.common, 'download', return_value=self.data):
            tools = self.setup()
        os.environ['CPSPLUS_SWITCH_TOOLS_OFFLINE'] = '1'
        with patch.object(fetch_ffmpeg.common, 'download', side_effect=AssertionError('network')):
            self.assertEqual(tools, self.setup())
        self.assertEqual(set(tools), {'ffmpeg', 'ffprobe'})

    def test_modified_cache_rejected(self):
        with patch.object(fetch_ffmpeg.common, 'download', return_value=self.data):
            tools = self.setup()
        tools['ffmpeg'].write_bytes(b'tamper')
        with self.assertRaisesRegex(fetch_ffmpeg.common.SetupError, 'cache changed'):
            self.setup()

    def test_incomplete_cache_rejected(self):
        with patch.object(fetch_ffmpeg.common, 'download', return_value=self.data):
            tools = self.setup()
        tools['ffprobe'].unlink()
        with self.assertRaisesRegex(fetch_ffmpeg.common.SetupError, 'inventory'):
            self.setup()

    def test_unavailable_host(self):
        with self.assertRaisesRegex(fetch_ffmpeg.common.SetupError, 'No qualified'):
            fetch_ffmpeg.setup(manifest=self.manifest, host='unknown')

class Runtime(unittest.TestCase):

    def setUp(self):
        self.env = patch.dict(os.environ, {}, clear=True)
        self.env.start()
        self.addCleanup(self.env.stop)
        runtime._managed.clear()
        self.addCleanup(runtime._managed.clear)

    def test_one_pair_and_process_local_path(self):
        pair = {'ffmpeg': Path('/p/bin/ffmpeg'), 'ffprobe': Path('/p/bin/ffprobe')}
        with patch.object(fetch_ffmpeg, 'setup', return_value=pair) as setup:
            self.assertEqual(runtime.resolve(), str(pair['ffmpeg']))
            self.assertEqual(os.fspath(runtime.Executable('ffprobe')), str(pair['ffprobe']))
            self.assertEqual(setup.call_count, 1)
        self.assertEqual(os.environ['PATH'].split(os.pathsep)[0], str(Path('/p/bin')))

    def test_explicit_override_no_download(self):
        os.environ['CPSPLUS_FFMPEG'] = 'custom'
        with patch.object(runtime.shutil, 'which', return_value='/custom/ffmpeg'), patch.object(fetch_ffmpeg, 'setup', side_effect=AssertionError('download')):
            self.assertEqual(runtime.resolve(), '/custom/ffmpeg')

    def test_invalid_override_no_fallback(self):
        os.environ['CPSPLUS_FFMPEG'] = 'missing'
        with patch.object(runtime.shutil, 'which', return_value=None), patch.object(fetch_ffmpeg, 'setup', side_effect=AssertionError('download')):
            with self.assertRaisesRegex(ValueError, 'does not name'):
                runtime.resolve()

    def test_controls_strip_before_passthrough(self):
        args = runtime.configure(['build', 'project', '--offline', '--tools-cache', './cache', '--tools-bundle', 'tools.zip'])
        self.assertEqual(args, ['build', 'project'])
        self.assertEqual(os.environ['CPSPLUS_SWITCH_TOOLS_OFFLINE'], '1')
        self.assertTrue(Path(os.environ['CPSPLUS_SWITCH_TOOLS_CACHE']).is_absolute())
if __name__ == '__main__':
    unittest.main()
