"""Audit remix pack recipes and run real tracks through the production player."""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import numpy as np
CP = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(CP), str(CP / 'rtl/tb')]
from pack import adxcodec, audition, xfade
from pack.build_remix import PACKS, self_test
from pack.format import PackReader
from gen_player_vectors import TRK_ADDR, base_plus, pcm_to_words, write_vec

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def audit(packs):
    reports = []
    for key in PACKS:
        recipe = json.loads((CP / 'manifests' / f'{key}_audio.json').read_text())
        rd = PackReader(packs / f'{key}.cpk')
        try:
            assert all(rd.crc_check()), key
            assert rd.header.xfade_samples == 0, key
            for row in recipe['tracks']:
                trigger = rd.triggers[row['cmd']]
                assert trigger.verb == 1 and trigger.suppress == 1
                meta = rd.tracks[trigger.track]
                assert not meta.xfade_enable, (key, row['cmd'])
                n = row['xfade_samples']
                finite_baked = bool(n and row['loop_count'])
                expected_start = 0 if finite_baked else row['loop_start'] + n
                expected_end = 0 if finite_baked else row['loop_end'] + n
                assert (meta.loop_start_sample, meta.loop_end_sample) == (expected_start, expected_end)
                assert meta.loop_count == (0 if finite_baked else row['loop_count'])
                if meta.loops:
                    assert meta.loop_end_byte <= meta.data_length
            reports.append(dict(pack=key, sha256=digest(rd.path), tracks=len(rd.tracks), crc=True, runtime_crossfades=0))
        finally:
            rd.close()
    return reports

def simulate(binary, folder, expect_failure=False):
    args = (folder / 'plusargs.txt').read_text().split()
    command = ['vvp', str(binary)] if binary.suffix == '.vvp' else [str(binary)]
    result = subprocess.run([*command, *args], capture_output=True, text=True, timeout=1800, check=True)
    log = result.stdout + result.stderr
    (folder / 'simulation.log').write_text(log)
    if expect_failure:
        assert 'FAIL: read outside track' in log, log[-2000:]
    else:
        assert 'TB_PLAYER PASS' in log and 'FAIL' not in log, log[-2000:]
    print(folder.name, next((line for line in log.splitlines() if 'TB_PLAYER' in line)), flush=True)
    return dict(case=folder.name, expected_failure=expect_failure, log=str(folder / 'simulation.log'), log_sha256=digest(folder / 'simulation.log'))

def rtl(packs, out, simulator):
    sources = [str(CP / 'rtl/tb/tb_player.v'), str(CP / 'rtl/cpsplus_player.v'), str(CP / 'rtl/cpsplus_adx.v')]
    if simulator == 'verilator':
        binary = (out / 'verilator/player_sim').resolve()
        command = ['verilator', '--binary', '--timing', '-Wno-fatal', '--top-module', 'tb_player', '-GXFADE_N=7200', '-GMAXM=8388608', '-GMAXG=16777216', '--Mdir', str(binary.parent), '-o', binary.name, *sources]
    else:
        binary = out / 'player.vvp'
        command = ['iverilog', '-g2005', '-Ptb_player.XFADE_N=7200', '-Ptb_player.MAXM=8388608', '-Ptb_player.MAXG=16777216', '-o', str(binary), *sources]
    with (out / 'compile.log').open('w') as log:
        subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, check=True, timeout=300)
    negative = out / 'old_4800_tail'
    n, le = (4800, 8192)
    pcm = np.zeros((le + n, 2), dtype='<i2')
    data = adxcodec.encode(pcm.tobytes(), 2, 48000)
    c1, c2 = adxcodec.calc_coeffs(adxcodec.DEFAULT_CUTOFF, 48000)
    plus = base_plus(negative, length=len(data), lstart=0, lend=le // 32 * 36, stereo=1, codec=0, c1=c1, c2=c2, ngold=le + 20000, XFEN=1, LSTART_SMP=0, LEND_SMP=le, LUT=negative / 'lut.hex')
    write_vec(negative, bytes(TRK_ADDR) + data, [0] * (le + 20000), plus)
    xfade.write_lut_hex(7200, negative / 'lut.hex')
    results = [simulate(binary, negative, expect_failure=True)]
    for key, cmd in [('msword_di', 2), ('msword_di', 3), ('ssf2_hdremix', 14), ('ssf2_hdremix', 30)]:
        folder = out / f'{key}_{cmd:02x}'
        rd = PackReader(packs / f'{key}.cpk')
        try:
            ti = rd.triggers[cmd].track
            meta = rd.tracks[ti]
            assert meta.loops and (not meta.loop_count) and (not meta.xfade_enable)
            pcm, _ = audition.render(rd, ti, loops=2)
            words = pcm_to_words(pcm, meta.channels)
            assert len(words) <= 16777216
            plus = base_plus(folder, length=meta.data_length, lstart=meta.loop_start_byte, lend=meta.loop_end_byte, stereo=meta.channels - 1, codec=meta.codec, c1=meta.coef1, c2=meta.coef2, ngold=len(words), EXPECT_NO_END=1)
            write_vec(folder, bytes(TRK_ADDR) + rd.read_track(ti), words, plus)
            results.append(simulate(binary, folder) | dict(pack_sha256=digest(rd.path), cmd=cmd, compared_pairs=len(words)))
        finally:
            rd.close()
    return results

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--packs', type=Path, default=CP / 'work/packs')
    ap.add_argument('--out', type=Path, default=CP / 'work/remix_hardware_loops')
    ap.add_argument('--rtl', action='store_true')
    ap.add_argument('--simulator', choices=['verilator', 'iverilog'], default='verilator')
    ap.add_argument('--self-test', action='store_true')
    args = ap.parse_args()
    if args.self_test:
        self_test()
        return
    args.out.mkdir(parents=True, exist_ok=True)
    report = dict(packs=audit(args.packs), rtl=rtl(args.packs, args.out, args.simulator) if args.rtl else [])
    (args.out / 'verification.json').write_text(json.dumps(report, indent=2) + '\n')
    print('Remix hardware loop checks passed')
if __name__ == '__main__':
    main()
