"""Format paths through repository links without assuming local mount names."""
from __future__ import annotations
from functools import lru_cache
import os
from pathlib import Path
SKIP = {'.git', '.claude', 'out', 'roms', 'snap', 'sta', 'work'}

@lru_cache(maxsize=8)
def _linked_roots(repo: Path) -> tuple[tuple[Path, Path], ...]:
    links = [repo / 'roms']
    for current, directories, _ in os.walk(repo, followlinks=False):
        parent = Path(current)
        if len(parent.relative_to(repo).parts) > 3:
            directories[:] = []
            continue
        if (parent / 'work').is_symlink():
            links.append(parent / 'work')
        directories[:] = [name for name in directories if name not in SKIP and (not name.startswith(('work.before', 'roms.before')))]
    return tuple(((link, link.resolve()) for link in links if link.is_symlink()))

def repo_display_path(path: Path, repo: Path) -> str:
    """Keep logical repo paths, including links, in generated records."""
    logical = path.absolute()
    if logical.is_relative_to(repo):
        return logical.relative_to(repo).as_posix()
    physical = path.resolve()
    for link, target in _linked_roots(repo):
        if physical.is_relative_to(target):
            candidate = link / physical.relative_to(target)
            if candidate.resolve() == physical:
                return candidate.relative_to(repo).as_posix()
    return str(physical)
