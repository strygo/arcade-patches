#!/usr/bin/env python3
"""Independently check reconstructed Strider EX files and every MRA binding."""
import argparse
import hashlib
import json
from pathlib import Path
import sys
import tempfile
import xml.etree.ElementTree as ET
import zipfile

HERE=Path(__file__).resolve().parent
ROOT=HERE/'builder'
sys.path[:0]=[str(ROOT),str(ROOT/'release')]
import mra_assembly as M


def sha(b):return hashlib.sha256(b).hexdigest()


def verify(out,region='both',audio='both',platform='both'):
    pins=json.loads((HERE/'outputs.json').read_text())['files']
    wanted={}
    for name,h in pins.items():
        if platform=='mister' and name.startswith('hbmame/'):continue
        if platform=='hbmame' and name.startswith('mister/'):continue
        if name.startswith('mister/'):
            if audio=='arcade' and ('/_Arrangements/' in name or name.endswith('/strider_ex.zip')):continue
            if audio=='cpsplus' and '/_Enhanced Versions/' in name:continue
        if region=='us' and ('striderjs01' in name or '/_Japan/' in name):continue
        if region=='jp' and ('striderus01' in name or name.endswith('.mra') and '/_Japan/' not in name):continue
        wanted[name]=h
    actual={p.relative_to(out).as_posix():sha(p.read_bytes()) for p in out.rglob('*')
            if p.is_file() and p.name!='.DS_Store'}
    if actual!=wanted:raise ValueError('missing, extra or changed reconstructed outputs')
    zips=sorted(out.glob('mister/games/**/*.zip'))
    source=M.ZipSource(zips);native={};arranged=[];checks=[]
    material=json.loads((HERE/'release-material.json').read_text())
    pack=None
    pp=out/'mister/games/CPS+/strider_ex.zip'
    if pp.exists():
        with zipfile.ZipFile(pp) as z:pack=z.read('strider_ex.cpk')
        if sha(pack)!=material['pack_sha256']:raise ValueError('wrong soundtrack pack')
        from cpsplus.pack.format import PackReader
        with tempfile.TemporaryDirectory() as temp:
            cp=Path(temp)/'pack.cpk';cp.write_bytes(pack);rd=PackReader(cp)
            try:
                if not all(rd.crc_check()):raise ValueError('pack CRCs failed')
                for cue in (0x03,0x79,0x7a,*range(0xa0,0xac),*range(0xb8,0xc8)):
                    row=rd.triggers[cue]
                    if row.verb==1 and not row.suppress:raise ValueError('arranged cue leaks native audio')
            finally:rd.f.close()
    for path in sorted(out.glob('mister/_Arcade/**/*.mra')):
        text=path.read_text();r=ET.fromstring(text);name=r.findtext('setname')
        if name not in ('striderus01','striderjs01') or r.findtext('rbf')!=material['core_binding']:
            raise ValueError('MRA set/core binding differs')
        rom=next(x for x in r.findall('rom') if x.get('index')=='0')
        if rom.get('zip')!='/hbmame/'+name+'.zip':raise ValueError('MRA can resolve an installed or older ROM')
        image=M.assemble(text,source)
        if image[34:39]!=bytes.fromhex('3f408873ff'):raise ValueError('incorrect EX mapper or sprite mask')
        magic=bytes(image[64+(a^1)] for a in range(0x1ffff0,0x1ffffa))
        if magic!=b'STRIDER-EX':raise ValueError('EX flag block missing')
        flag=image[64+(0x1fffff^1)];is_arranged='[Arrange' in path.name
        expected=(5 if 'English voices' in path.name else 3 if 'Japanese voices' in path.name else 1) if is_arranged else 0
        if flag!=expected:raise ValueError('incorrect regional voice/audio flag')
        # The pack pointer and its alignment-pad length occupy header 8..11.
        # Only those four bytes and the declared audio/language flag differ.
        body=bytearray(image[:64+0xa50000]);body[8:12]=b'\0'*4;body[64+(0x1fffff^1)]=0
        if is_arranged:
            if pack is None:raise ValueError('missing soundtrack dependency')
            parts=[p for p in rom.findall('part') if p.get('name','').endswith('.cpk')]
            if len(parts)!=1 or parts[0].get('zip')!='/CPS+/strider_ex.zip':raise ValueError('unbound soundtrack')
            at=int.from_bytes(image[8:10],'little')*1024
            if image[at:at+len(pack)]!=pack or len(image)!=at+len(pack):raise ValueError('MRA pack pointer or tail differs')
            arranged.append((name,sha(body)))
        else:
            if len(image)!=64+0xa50000:raise ValueError('native launcher appends audio')
            native[name]=sha(body)
        checks.append(dict(mra=path.relative_to(out).as_posix(),flag=flag,assembled_sha256=sha(image)))
    for name,h in arranged:
        if name in native and native[name]!=h:raise ValueError('audio variant changes game bytes')
    if platform!='hbmame':
        core=out/'mister/_Arcade/cores'/material['core_filename']
        if sha(core.read_bytes())!=material['core_sha256']:raise ValueError('wrong core binary')
        import cps1_core_release
        cps1_core_release.verify_core(core)
    return dict(schema='striderex-public-output-check/1',passed=True,files=len(actual),mras=checks,
        pack_sha256=sha(pack) if pack else None,hardware_review_granted=False)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--out-dir',type=Path,required=True)
    p.add_argument('--region',choices=('both','us','jp'),default='both')
    p.add_argument('--audio',choices=('both','arcade','cpsplus'),default='both')
    p.add_argument('--platform',choices=('both','mister','hbmame'),default='both')
    p.add_argument('--receipt',type=Path)
    a=p.parse_args();r=verify(a.out_dir,a.region,a.audio,a.platform)
    if a.receipt:a.receipt.write_text(json.dumps(r,indent=2)+'\n')
    print('PASS:',r['files'],'files and',len(r['mras']),'MRA assemblies')
