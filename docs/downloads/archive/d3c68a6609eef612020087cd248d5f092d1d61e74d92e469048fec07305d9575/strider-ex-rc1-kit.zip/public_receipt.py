"""Keep game metadata fixed while recording the actual reconstruction scripts."""
from copy import deepcopy
import hashlib
import json
from pathlib import Path
PRODUCERS = ('clear_music_timing', 'desert_cliff_camera', 'desert_map_edge', 'desert_pole_alias', 'moon_caption', 'moon_start')

def portable(value):
    if isinstance(value, dict):
        return {k: portable(v) for k, v in value.items() if k not in ('source_sha256', 'script_sha256', 'captions_inc_sha256', 'assembler_sha256', 'subtitles_sha256') and (not ('manifest' in k and 'sha256' in k))}
    if isinstance(value, list):
        return [portable(v) for v in value]
    if isinstance(value, str) and Path(value).is_absolute():
        return Path(value).name
    return value

def content_identity(receipt):
    value = deepcopy(receipt)
    if set(value['build']['sets']) != {'striderua', 'striderjr'}:
        raise ValueError('receipt region inventory differs')
    for spec in value['build']['sets'].values():
        for name in PRODUCERS:
            fingerprint = spec[name].pop('producer_sha256')
            if len(fingerprint) != 64 or any((c not in '0123456789abcdef' for c in fingerprint)):
                raise ValueError('invalid producer fingerprint')
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':')).encode()).hexdigest()

def check(receipt, contract):
    if contract['schema'] != 'striderex-build-receipt-contract/1' or content_identity(receipt) != contract['content_sha256']:
        raise ValueError('game metadata differs from approved receipt')

def self_test():
    receipt = {'build': {'sets': {region: {name: {'producer_sha256': 'a' * 64, 'helper_sha256': 'b' * 64} for name in PRODUCERS} for region in ('striderua', 'striderjr')}}}
    contract = {'schema': 'striderex-build-receipt-contract/1', 'content_sha256': content_identity(receipt)}
    changed = deepcopy(receipt)
    changed['build']['sets']['striderua']['moon_start']['producer_sha256'] = 'c' * 64
    check(changed, contract)
    changed['build']['sets']['striderua']['moon_start']['helper_sha256'] = 'd' * 64
    try:
        check(changed, contract)
    except ValueError:
        pass
    else:
        raise AssertionError('changed game metadata accepted')
    print('PASS receipt contract: tooling provenance allowed; changed helper identity rejected')
if __name__ == '__main__':
    self_test()
