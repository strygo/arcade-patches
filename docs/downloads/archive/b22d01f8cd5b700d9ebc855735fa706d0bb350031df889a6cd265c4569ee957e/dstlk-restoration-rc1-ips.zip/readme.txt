Darkstalkers: The Night Warriors · English restoration
======================================================

Version:  rc1 (2026-10-06)
Target:   MAME set 'vampj' (Vampire: The Night Warriors (Japan 940705))
Hardware: Capcom CPS-2
Patch by: Steve Gordon (https://x.com/strygo)
Website:  https://arcadepatches.com/dstlk-restoration/

ABOUT THIS PROJECT

The original Japanese Vampire gives each fighter a pool of win quotes, and
offers move advice after a loss. The USA version uses one English win quote
per fighter and removes the advice.

The English Restoration brings back the Japanese quote pools and bordered
result panel, the complete ending dialogue, and all 85 continue tips,
translated from the Japanese.

The voices the USA version muted are back: Morrigan’s alternate victory,
Vector Drain and throw, and Felicia’s Rolling Buckler, Dancing Flash and
special damage reaction. As in the USA release, Rikuo’s crouching heavy punch
can be blocked with a crouching guard.

It keeps the ten playable fighters and the Western character names, and adds
Free Play to the operator menu. It runs in MAME and HBMAME and on MiSTer.

This is a release candidate.

WHAT'S CHANGED

  - Japanese win-quote pools in English, with the Japanese result-panel border
  - Complete Japanese ending dialogue in English, with the original scene
    timing
  - All 85 Japanese continue tips in English, including their arcade move
    commands
  - Morrigan’s alternate victory, Vector Drain and throw voices, and Felicia’s
    Rolling Buckler, Dancing Flash and special damage voices
  - Rikuo’s crouching heavy punch can be blocked with a crouching guard, as in
    the USA release
  - Western character names, and Free Play in the operator menu

HOW TO APPLY (recommended)

    python3 apply.py /path/to/vampj.zip --out-dir out

This checks every file against the original, applies the patches, checks
the result, and writes everything you need for each platform:

  MAME / original hardware: out/mame/vampj.zip
  HBMAME:                   out/hbmame/vamprest.zip
  MiSTer:                   out/mister/_Arcade/_Arcade Patches/_Restorations/Darkstalkers The Night Warriors (USA) [English Restoration].mra

Merged, split and complete sets work, including nested or renamed ROMs.
Use --rompath DIR (repeatable) to search a collection instead of naming the
zip, and --check to check inputs before building. ZIPs and extracted folders
need no extra software; 7z archives need 7-Zip. QSound can stay in your
emulator's ROM path; valid firmware already in a source set is kept in
complete outputs.

MAME: put vampj.zip from out/mame/ ahead of the stock set in your MAME
rompath.
MAME's game menu won't start a set with patched ROMs, so start it from the
command line: mame vampj. MAME shows checksum warnings for the patched
ROMs; that's expected and the game runs normally.
To start it from a menu, use the HBMAME build.
Keep your unmodified qsound.zip in MAME's ROM path.

HBMAME: this restoration is an official HBMAME set (vamprest),
so full HBMAME collections may already carry it.
Put vamprest.zip and qsound.zip in HBMAME's roms/ folder;
it holds the complete set and loads with no checksum warnings.

MiSTer: copy the _Arcade folder from out/mister/ to the root of your SD card
and keep the stock, unmodified romset at games/mame/vampj.zip (split MAME
sets also need qsound.zip). The MRA applies the restoration in memory as the
game loads, so nothing on the card is modified. You need Jotego's jtcps2
core, which update_all installs. The MRAs are also a separate download.

HOW TO APPLY (any IPS patcher)

Extract vampj.zip, apply each file in ips/ to the ROM file of the
same name (Flips, Lunar IPS, or any IPS tool), then re-zip everything
as vampj.zip.

CHANGED FILES

    vam.13m  (4.0 MB)  CRC32 c51baf99 -> 2c48a876
    vam.15m  (4.0 MB)  CRC32 3ce83c77 -> 6465e083
    vam.17m  (4.0 MB)  CRC32 4f2408e0 -> c613f6eb
    vam.19m  (4.0 MB)  CRC32 9ff60250 -> 29424b8d
    vamj.03a  (512 KB)  CRC32 f55d3722 -> f36d0886
    vamj.04b  (512 KB)  CRC32 4d9c43c4 -> 48f49597
    vamj.09a  (512 KB)  CRC32 fc0a4aac -> 744507a9

All other files in the set are unmodified.

LEGAL

This is a free, unofficial fan patch. It is not affiliated with or endorsed
by Capcom. All game titles, characters, and artwork remain the property of
their respective owners. You must own the game to use this patch. Do not
sell this patch or distribute it applied to a ROM image.
