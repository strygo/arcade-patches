Street Fighter Alpha 2 · English restoration
============================================

Version:  rc1 (2026-10-11)
Target:   MAME set 'sfz2j' (Street Fighter Zero 2 (Japan 960430))
Hardware: Capcom CPS-2
Patch by: Steve Gordon (https://x.com/strygo)
Website:  https://arcadepatches.com/sfa2-restoration/

ABOUT THIS PROJECT

Street Fighter Alpha 2 wasn't the same game everywhere. In Japan, each
fighter's win quote depends on who they beat and how much health they had
left, and you can pick one by holding buttons. The English versions draw a few
quotes at random. They also trimmed some story and ending pages, show only the
country on the next-stage map, turned the blood white and left the Manual
guard panel blank.

The English Restoration is the Japanese game, in English. Every win quote is
back, chosen the Japanese way, and so is the button pick. The story and
endings follow Japan's pages and timing, the map names the place you're
headed, and the blood is red. Birdie's third victory pose and Dan's spoken
line in his ending return too.

The USA version's secret fighters stay: Evil Ryu, EX Dhalsim and EX Zangief
are selectable by code. The computer opponents, two-player damage and factory
settings follow the Japanese version, and Charlie's Sonic Boom and Chun-Li's
Kikoken get the fix from Capcom's later revision. An operator setting switches
the blood to white.

There are three builds. The USA build is Street Fighter Alpha 2 in English.
The Asia build is Street Fighter Zero 2 in English, with Asia's own stage
details. The Japan build keeps its Japanese text and gets the same fixes and
settings. All three run in MAME and HBMAME and on MiSTer.

This is a release candidate.

WHAT'S CHANGED

  - Every win quote from the Japanese game, in English, picked by opponent and
    remaining health
  - Win-quote pick by holding buttons, as in Japan
  - Story and ending pages in Japan's order and timing, including the pages
    the English versions cut
  - English place names on the next-stage map
  - Red blood, with a REGULATION setting for white (off by default)
  - Birdie's third victory pose, Dan's ending voice and a Manual guard panel
    that explains itself
  - Evil Ryu, EX Dhalsim and EX Zangief by code in the USA build; an operator
    setting adds them to the Japan and Asia builds
  - Computer opponents, two-player damage and factory settings as in the
    Japanese version
  - USA, Asia and Japan builds

MISTER SETUP

1. Copy the _Arcade/ folder from this download to the root of your MiSTer SD
   card (the MRAs land in _Arcade/_Arcade Patches/_Restorations/), or just the MRAs you want:
       "Street Fighter Alpha 2 (USA) [English Restoration].mra"
       "_Asia/Street Fighter Zero 2 (Asia) [English Restoration].mra"
       "_Japan/Street Fighter Zero 2 (Japan) [Restoration].mra"
2. Have the stock, unmodified romset at games/mame/sfz2j.zip
   (split sets also need the parent and QSound ZIPs named in the MRA).
3. You need Jotego's jtcps2 core; the standard MiSTer downloader /
   update_all installs it automatically.

Each MRA references your original romset and applies the restoration in
memory while the game loads. Nothing on your SD card is modified. Each
build keeps its own settings and saves under its own setname:
    USA (English)    sfa2ru
    Asia (English)   sfz2ra
    Japan (Japanese) sfz2rj

LEGAL

This is a free, unofficial fan patch. It is not affiliated with or endorsed
by Capcom. All game titles, characters, and artwork remain the property of
their respective owners. You must own the game to use this patch. Do not
sell this patch or distribute it applied to a ROM image.
