Cyberbots: Fullmetal Madness · English restoration
==================================================

Version:  rc1 (2026-11-23)
Target:   MAME set 'cybotsj' (Cyberbots: Fullmetal Madness (Japan 950420))
Hardware: Capcom CPS-2
Patch by: Steve Gordon (https://x.com/strygo)
Website:  https://arcadepatches.com/cybots-restoration/

ABOUT THIS PROJECT

Cyberbots’ English release rewrote much of its story and left parts of it out.
This restoration plays the Japanese arcade game in English that follows the
Japanese script: every campaign and ending, the chapter titles shown before
each stage, and the full set of victory quotes.

Devilotte’s servants keep their Japanese names. Story text is paced and spaced
for English, and the VA logos and name plates appear in English. The Japanese
release’s gameplay, victory voices and stage signs stay intact.

It runs on Darksoft CPS-2 hardware, on MiSTer, and in MAME. HBMAME and FBNeo
outputs use the same game data.

This is a release candidate.

WHAT'S CHANGED

  - Every story scene in all six campaigns and endings, in English that
    follows the Japanese script.
  - Chapter titles before each stage, which the English release never showed.
  - Every victory quote in English, including the distinct lines the English
    release merged into one per grade.
  - Devilotte’s servants keep their names, Jigoku Daishi and Dr. Stein.
  - Story text paced for reading, with page breaks, roomier line spacing and
    proper quotes and apostrophes.
  - English VA logos and name plates, English service menus and USA attract
    and copyright screens.
  - Japanese arcade gameplay, victory voices and stage signs.

MISTER SETUP

1. Copy the _Arcade/ folder from this download to the root of your
   MiSTer SD card (the MRA lands in _Arcade/_Arcade Patches/_Restorations/), or copy
   "Cyberbots Fullmetal Madness (USA) [Restoration].mra" anywhere under _Arcade/.
2. Have the stock, unmodified romset at games/mame/cybotsj.zip
   (split sets also need the parent and QSound ZIPs named in the MRA).
3. You need Jotego's jtcps2 core; the standard MiSTer downloader /
   update_all installs it automatically.

The MRA references your original romset and applies the restoration in
memory while the game loads. Nothing on your SD card is modified. The
restoration keeps its own settings and saves under the name
'cybotsru'.

LEGAL

This is a free, unofficial fan patch. It is not affiliated with or endorsed
by Capcom. All game titles, characters, and artwork remain the property of
their respective owners. You must own the game to use this patch. Do not
sell this patch or distribute it applied to a ROM image.
