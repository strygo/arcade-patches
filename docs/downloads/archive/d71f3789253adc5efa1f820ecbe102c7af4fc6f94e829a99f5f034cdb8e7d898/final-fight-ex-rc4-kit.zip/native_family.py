"""Kit-owned ffex native input/export implementation."""
import argparse
import hashlib
import importlib
import json
import os
from pathlib import Path
import runpy
import shutil
import subprocess
import sys
import tempfile
import zipfile
from native_support import (check, execute, require, sha, source, write_zip,
    file_sha, inventory, verify_raw, canonicalize_mras, stage_disc, stage_components)

def run(request, layout, kit, workspace):
    target = layout['targets'][request['target']]
    os.environ.pop('CAPCOM_ARCADE_ROM_PATH', None)
    os.environ.pop('CPSPLUS_PYTHON', None)
    os.environ['CPSPLUS_SWITCH_TOOLS_CACHE'] = request['tools_cache']
    key = sha(json.dumps({'kit': layout['manifest_sha256'], 'target': target, 'inputs': {k: v['sha256'] for k, v in request['bindings'].items()}}, sort_keys=True).encode())
    root = Path(request['run_cache']) / ('ffex-' + key)
    root.mkdir(parents=True, exist_ok=True)
    raw, marker = (root / 'raw', root / 'complete.json')
    response = {'status': 'ok'}
    if marker.exists():
        require(inventory(raw) == json.loads(marker.read_text()), 'Final Fight same-run cache changed')
    else:
        cue = stage_disc(request['bindings'], target['files'], target['cue'], root / 'disc')
        disc = cue if target['platform'] == 'mister' else cue.parent / target['data_file']
        inputs = root / 'inputs'
        inputs.mkdir(exist_ok=True)
        for setname, members in target['sets'].items():
            write_zip(inputs / (setname + '.zip'), {n: source(request['bindings'][k]) for n, k in members.items()})
        argv = ['--region', target['region'], '--disc-' + target['region'], disc, '--romset', inputs, '--platform', target['platform'], '--audio', 'both' if target['platform'] == 'mister' else 'arcade', '--work', root / 'work', '--out-dir', raw, '--tools-cache', request['tools_cache']]
        if request.get('offline'):
            argv += ['--offline']
        if request['operation'] == 'preflight':
            execute(kit, argv + ['--check'])
        else:
            execute(kit, argv)
            canonicalize_mras(raw, target['original_outputs'])
            verify_raw(raw, target['original_outputs'], True)
            marker.write_text(json.dumps(inventory(raw)))
    if request['operation'] == 'build':
        staging = Path(request['staging'])
        for origin, mapping in ((raw, target['mapping']), (kit, target['kit_mapping'])):
            for old, new in mapping.items():
                destination = staging / new
                destination.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(origin / old, destination)
        for name, spec in target['outputs'].items():
            check(staging / name, spec, output_name=name)
        response['outputs'] = target['outputs']
    return response


import re
import xml.etree.ElementTree as ET
import native_support as contracts

def define(root, slug, version, revision, native, registry):
    archive = contracts.Directory(root)
    qualified = dict(native)
    identity = json.loads(archive.read('kit.json'))
    resource_recipe = identity.get('recipe') == 'final-fight-source-recipes/1'
    catalog = json.loads(archive.read('rom_inputs.json'))['sets']
    release = {'game_version': version, 'kit_revision': revision, 'requires': ['file-inputs-v1', 'zip-outputs-v1', 'run-cache-v1', 'locked-wheels-v1'], 'prerequisites': {}, 'targets': {}}
    recipe = {'manifest_sha256': 'native-manifest', 'targets': {}}
    covered = set()
    world = runpy.run_path(str(Path(root) / 'ffight_sources.py'))['WORLD']
    for region, setname in (('us', 'ffightus01'), ('jp', 'ffightjs01')):
        disc = registry[region]
        names = re.findall('^FILE "([^"]+)" BINARY$', disc['cue'], re.M)
        contracts.require(names and set(names) == set(disc['files']), 'CD descriptor/component extent differs')
        track_keys = {}
        for name, pin in disc['files'].items():
            contracts.file_contract(pin)
            key = 'disc-' + pin['sha256'][:20]
            track_keys[name] = key
            release['prerequisites'][key] = {'title': f"Final Fight CD ({('USA' if region == 'us' else 'Japan')}): {name}", 'kind': 'disc', 'formats': ['loose raw CD tracks', 'ZIP containing raw CD tracks'], 'action': 'Add your matching complete Sega CD rip folder or ZIP. Tracks are identified by content; the builder supplies the verified CUE layout.', 'alternatives': [pin]}
        sources = {'ffight': {name: catalog['ffight'][name] for name in world}}
        if region == 'us':
            sources['ffightu'] = {'ffu_43.12h': catalog['ffightu']['ffu_43.12h']}
            sources['ffightj'] = {name: catalog['ffightj'][name] for name in ('ffj_30.bin', 'ffj_31.bin')}
        else:
            sources['ffightj'] = catalog['ffightj']
        sets = {}
        for set_id, members in sources.items():
            sets[set_id] = {}
            for name, pin in members.items():
                key = 'rom-' + pin['sha256'][:20]
                sets[set_id][name] = key
                release['prerequisites'][key] = {'title': f'{set_id}: {name}', 'kind': 'rom', 'formats': ['ZIP', 'loose ROM files'], 'action': 'Add your canonical MAME Final Fight ROM folder.', 'alternatives': [{k: pin[k] for k in ('size', 'sha256', 'crc32') if k in pin}]}
        regional = {n: s for n, s in qualified.items() if setname + '.zip' in n or n.startswith('mister/_Arcade/cores/') or n == 'mister/games/CPS+/' + ('ffight_arrange.zip' if region == 'us' else 'ffight_arrange_jp.zip') or (n.endswith('.mra') and ('/_Japan/' in n) == (region == 'jp'))}
        covered.update(regional)
        for platform in ('hbmame', 'mister'):
            raw = {n: s for n, s in regional.items() if n.startswith(platform + '/')}
            contracts.require(raw, 'Missing Final Fight platform contract')
            mapping = {n: 'roms/' + Path(n).name if platform == 'hbmame' else n[len('mister/'):] for n in raw}
            outputs = {mapping[n]: s for n, s in raw.items()}
            support = {'README.txt': f'support/{slug}/README.txt', 'TOOLS.md': f'support/{slug}/TOOLS.md'}
            for n, destination in support.items():
                outputs[destination] = {'sha256': hashlib.sha256(archive.read(n)).hexdigest()}
            files = track_keys if platform == 'mister' else {names[0]: track_keys[names[0]]}
            target_id = region + '-' + platform
            inputs = sorted(set(files.values()) | {k for members in sets.values() for k in members.values()})
            release['targets'][target_id] = {'platform': platform, 'variant': region, 'region': region, 'inputs': inputs, 'outputs': outputs, 'minimum_free_bytes': 6 * 1024 ** 3, 'software_notes': ['Pinned NumPy and Pillow are installed privately. MiSTer soundtrack helpers are prepared by the unchanged public kit.'], 'destination_requirements': 'HBMAME with ffightus01/ffightjs01 registrations.' if platform == 'hbmame' else 'Includes both arcade-audio and CPS+ launchers; arcade audio uses the standard jtcps1 core.'}
            if resource_recipe:
                release['targets'][target_id].update(minimum_free_bytes=2 * 1024**3,
                    software_notes=['ROMs use authenticated source recipes. Scene rendering and Pillow are no longer required.',
                                    ('Python and authenticated FFmpeg helpers reproduce the regional soundtrack; no numerical packages are needed.'
                                     if identity.get('pcm_runtime') == 'compiled-float64-weights/1' else
                                     'NumPy and authenticated FFmpeg helpers reproduce the regional soundtrack.')])
            recipe['targets'][target_id] = {'region': region, 'platform': platform, 'sets': sets, 'files': files, 'cue': disc['cue'], 'mapping': mapping, 'kit_mapping': support, 'original_outputs': raw, 'outputs': outputs, 'data_file': names[0]}
    contracts.require(covered == set(qualified), 'Unaccounted Final Fight output contracts')
    for requirement in release['prerequisites'].values():
        if '7z member' not in requirement['formats']:requirement['formats'].append('7z member')
    release['api'] = 1
    release['project'] = slug
    release['native_outputs'] = qualified
    release['requires'] = sorted(set(release['requires']) | {'native-context-v1', 'native-bindings-v1'})
    from native_cd_sources import attach
    attach(release, recipe, registry)
    return (release, recipe)
