ROM INPUT UPDATE

Merged, split, complete ZIP/7z archives and extracted ROM folders are accepted.
Use --rompath DIR (repeatable) to search a collection, or keep the existing archive argument.
Names may differ; required source contents are verified by size and strong hashes.
Use --check to verify arcade build inputs before reconstruction.
QSound is optional for game builds. Valid embedded firmware is preserved in complete game outputs.
Use --include-devices on CPS-2 kits to require and include firmware from separate archives.
Compact HBMAME outputs retain their stock-game and device dependencies.
7z input uses installed 7-Zip or a verified helper fetched on demand. ZIP needs only Python.
Original archives are never modified by collection discovery.

Night Warriors: Darkstalkers' Revenge · English restoration
===========================================================

Version:  rc1 (2026-10-06)
Target:   MAME set 'vhuntj' (Vampire Hunter: Darkstalkers' Revenge (Japan 950316))
Hardware: Capcom CPS-2
Patch by: Steve Gordon (https://x.com/strygo)
Website:  https://arcadepatches.com/nwarr-restoration/

ABOUT THIS PROJECT

Night Warriors left a lot of Vampire Hunter behind. Every export version skips
the epilogue that follows each ending. The endings were rewritten, with
different page counts on most routes, and each fighter gets a handful of fixed
win quotes where the Japanese game picks from a much larger pool.

The English Restoration brings back all 14 epilogues, rebuilds the 112 ending
pages with the Japanese scenes and pacing, and restores the full pool of 323
win quotes, all translated from the Japanese.

Sasquatch’s Japanese victory poses and their sounds are back, along with
Morrigan’s and Donovan’s extra win sounds.

It keeps the Night Warriors title, the Western character names and the English
operator menu with the USA settings. It runs in MAME and HBMAME and on MiSTer.

This is a release candidate.

WHAT'S CHANGED

  - All 14 epilogues after the endings, in English; every export version
    skipped them
  - The 112 Japanese ending pages in English, with the Japanese scenes and
    pacing
  - The full pool of 323 Japanese win quotes in English, picked as in Japan
  - Sasquatch’s Japanese victory poses and sounds, and Morrigan’s and
    Donovan’s extra win sounds
  - The Night Warriors title, Western character names and the USA operator
    menu

HOW TO APPLY (recommended)

    python3 apply.py /path/to/vhuntj.zip --out-dir out

This checks every file against the original, applies the patches, checks
the result, and writes everything you need for each platform:

  MAME:                     out/mame/vhuntj.zip
  HBMAME:                   out/hbmame/nwarrru.zip
  MiSTer:                   out/mister/_Arcade/_Arcade Patches/_Restorations/Night Warriors Darkstalkers' Revenge (USA) [English Restoration].mra

Merged, split and complete sets work, including nested or renamed ROMs.
Use --rompath DIR (repeatable) to search a collection instead of naming the
zip, and --check to check inputs before building. ZIPs and extracted folders
need no extra software; 7z archives use installed 7-Zip or a verified download.
QSound can stay in your emulator's ROM path; valid firmware already
in a source set is kept in complete outputs.

MAME: put vhuntj.zip from out/mame/ ahead of the stock set in your MAME
rompath.
MAME's game menu won't start a set with patched ROMs, so start it from the
command line: mame vhuntj. MAME shows checksum warnings for the patched
ROMs; that's expected and the game runs normally.
To start it from a menu, use the HBMAME build.

HBMAME: this restoration is an official HBMAME set (nwarrru),
so full HBMAME collections may already carry it.
Put nwarrru.zip and qsound.zip in HBMAME's roms/ folder;
it holds the complete set.

MiSTer: copy the _Arcade folder from out/mister/ to the root of your SD card
and keep the stock, unmodified romset at games/mame/vhuntj.zip (split MAME
sets also need qsound.zip). The MRA applies the restoration in memory as the
game loads, so nothing on the card is modified. You need Jotego's jtcps2
core, which update_all installs. The MRAs are also a separate download.

HOW TO APPLY (any IPS patcher)

Extract vhuntj.zip, apply each file in ips/ to the ROM file of the
same name (Flips, Lunar IPS, or any IPS tool), then re-zip everything
as vhuntj.zip.

CHANGED FILES

    vph.13m  (4.0 MB)  CRC32 c51baf99 -> da6e5f0d
    vph.15m  (4.0 MB)  CRC32 3ce83c77 -> 82fe8661
    vph.19m  (4.0 MB)  CRC32 9ff60250 -> d3789851
    vphj.03f  (512 KB)  CRC32 3de2e333 -> 8bb491f7
    vphj.04c  (512 KB)  CRC32 c95cf304 -> 5a592e49
    vphj.05d  (512 KB)  CRC32 50de5ddd -> 832ea9f4
    vphj.10b  (512 KB)  CRC32 32c7d8f0 -> daa98fe2

All other files in the set are unmodified.

LEGAL

This is a free, unofficial fan patch. It is not affiliated with or endorsed
by Capcom. All game titles, characters, and artwork remain the property of
their respective owners. You must own the game to use this patch. Do not
sell this patch or distribute it applied to a ROM image.

DARKSOFT OUTPUT

Use --platform darksoft --out-dir out, or --platform all.
Copy the game folder from out/darksoft/games to the card games folder.
Expanded hardware and streamed audio are not supported.

PYTHON PACKAGES

When a build needs NumPy or Pillow and it is not already installed, the kit
downloads its pinned prebuilt package from PyPI into your user cache. No pip,
compiler, administrator rights or changes to system Python are needed.
Patch-only builds and --help do not download Python packages.

Automatic package installation is qualified for CPython 3.12 on Apple Silicon
Macs and CPython 3.13 x64 on Windows (including x64 Python on Windows ARM).
Other interpreters can still use manually installed NumPy/Pillow. There is
no automatic source compilation or selection of an unqualified package.

Cache: ~/Library/Caches/ArcadePatches/python on Mac, or
%LOCALAPPDATA%/ArcadePatches/python on Windows. You can choose another location
with --python-cache PATH (or ARCADE_PYTHON_CACHE). --tools-cache PATH places
the Python cache under PATH/python unless --python-cache is also supplied.
You may delete this cache when no installer is running; it is recreated later.

Offline: add --python-wheels PATH --offline. PATH may name the matching
python-wheels-v1-*.zip, a folder of unzipped wheels, or a folder containing
the wheel ZIPs. The existing wheel bundles work without modification.
You can also supply --tools-bundle for the other helpers in the same command.
ARCADE_PYTHON_WHEELS is the equivalent environment variable. A warm cache
works offline without a bundle. --offline prohibits package downloads too.
Every wheel is checked against the kit's hash; cached extracted files are
verified before use. Existing manually installed packages remain supported.

The installer and its Python subprocesses share the cache. Your shell profile,
global site-packages and unrelated Python applications are not changed.
