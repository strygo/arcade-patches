"""Kit-owned ffex2 native input/export implementation."""
import argparse
import hashlib
import importlib
import json
import os
from pathlib import Path
import runpy
import shutil
import subprocess
import sys
import tempfile
import zipfile
from native_support import (check, execute, require, sha, source, write_zip,
    file_sha, inventory, verify_raw, canonicalize_mras, stage_disc, stage_components)

def cached_builder(original, shared, identity, contracts):
    """Cache only complete ROM members, against the independent public inventory."""
    stats = {'reconstructed': 0, 'reused': 0}

    def build(edition, romsets, discs, work, *args, **kwargs):
        path = shared / ('rom-' + sha(json.dumps({'inputs': identity, 'edition': edition}, sort_keys=True).encode()) + '.zip')
        expected = {'members': contracts[edition]}
        if path.exists():
            check(path, expected)
            stats['reused'] += 1
            with zipfile.ZipFile(path) as archive:
                return {n: archive.read(n) for n in archive.namelist()}
        members = original(edition, romsets, discs, work, *args, **kwargs)
        require({n: sha(data) for n, data in members.items()} == expected['members'], 'Reconstructed CPS2 ROMs differ from independent qualification')
        write_zip(path, members)
        check(path, expected)
        stats['reconstructed'] += 1
        return members
    build.stats = stats
    return build

def run(request, layout, kit, workspace):
    target = layout['targets'][request['target']]
    shared = Path(request['run_cache'])
    shared.mkdir(parents=True, exist_ok=True)
    os.environ.pop('CAPCOM_ARCADE_ROM_PATH', None)
    os.environ.pop('CPSPLUS_PYTHON', None)
    os.environ['CPSPLUS_SWITCH_TOOLS_CACHE'] = request['tools_cache']
    os.environ['ARCADE_PYTHON_CACHE'] = str(Path(request['tools_cache']) / 'python')
    if request.get('offline'):
        os.environ['CPSPLUS_SWITCH_TOOLS_OFFLINE'] = '1'
    identity = {'kit': layout['manifest_sha256'], 'disc_region': target['disc_region'], 'data': request['bindings'][target['files'][target['data_file']]]['sha256'], 'roms': {k: request['bindings'][k]['sha256'] for members in target['sets'].values() for k in members.values()}}
    key = sha(json.dumps({'inputs': identity, 'group': target['group'], 'files': {n: request['bindings'][k]['sha256'] for n, k in target['files'].items()}}, sort_keys=True).encode())
    root = shared / ('ffex2-' + key)
    root.mkdir(exist_ok=True)
    raw, marker = (root / 'raw', root / 'complete.json')
    response = {'status': 'ok'}
    response['dependencies'] = {'rom_reconstruction': {'reconstructed': 0, 'reused': 0}}
    if marker.exists():
        require(inventory(raw) == json.loads(marker.read_text()), 'CPS2 same-run output cache changed')
        verify_raw(raw, layout['groups'][target['group']], True)
    else:
        cue = stage_disc(request['bindings'], target['files'], target['cue'], root / 'disc')
        disc = cue if target['platform'] == 'mister' else cue.parent / target['data_file']
        inputs = root / 'inputs'
        inputs.mkdir(exist_ok=True)
        for setname, members in target['sets'].items():
            write_zip(inputs / (setname + '.zip'), {n: source(request['bindings'][k]) for n, k in members.items()})
        sys.path.insert(0, str(kit))
        module = importlib.import_module('ffex_kit')
        image = module.data_track(disc)
        with Path(image).open('rb') as stream:
            require(stream.read(12) == b'\x00' + b'\xff' * 10 + b'\x00' and Path(image).stat().st_size % 2352 == 0, 'Invalid raw CD data track')
        argv = ['--disc-' + target['disc_region'], disc, '--rompath', inputs, '--platform', target['platform'], '--out-dir', raw, '--tools-cache', request['tools_cache']]
        if request.get('offline'):
            argv += ['--offline']
        if request['operation'] == 'preflight':
            execute(kit, argv + ['--check'])
        else:
            module.build = cached_builder(module.build, shared, identity, layout['member_contracts'])
            execute(kit, argv)
            response['dependencies']['rom_reconstruction'] = module.build.stats
            canonicalize_mras(raw, layout['groups'][target['group']])
            verify_raw(raw, layout['groups'][target['group']], True)
            marker.write_text(json.dumps(inventory(raw)))
    if request['operation'] == 'build':
        staging = Path(request['staging'])
        for origin, mapping in ((raw, target['mapping']), (kit, target['kit_mapping'])):
            for old, new in mapping.items():
                destination = staging / new
                destination.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(origin / old, destination)
        if target['device_output']:
            write_zip(staging / target['device_output'], {'dl-1425.bin': source(request['bindings'][target['device']])})
        for name, spec in target['outputs'].items():
            check(staging / name, spec, output_name=name)
        response['outputs'] = target['outputs']
    return response


import re
import xml.etree.ElementTree as ET
import native_support as contracts

def define(root, slug, version, revision, native, registry):
    archive = contracts.Directory(root)
    qualified = dict(native)
    contracts.require(json.loads(archive.read('build-info.json'))['kit_revision'] == revision, 'CPS2 kit revision differs')
    kit = json.loads(archive.read('kit.json'))
    catalog = json.loads(archive.read('rom_inputs.json'))['sets']
    release = {'game_version': version, 'kit_revision': revision, 'requires': ['file-inputs-v1', 'zip-outputs-v1', 'run-cache-v1', 'locked-wheels-v1'], 'prerequisites': {}, 'targets': {}}
    recipe = {'manifest_sha256': 'native-manifest', 'targets': {}, 'groups': {}, 'member_contracts': {}}
    QSOUND = registry['qsound']
    QSOUND_SHA256 = QSOUND['sha256']
    sets = {}
    for setname in kit['romsets']:
        sets[setname] = {}
        for name, pin in catalog[setname].items():
            key = 'rom-' + pin['sha256'][:20]
            sets[setname][name] = key
            release['prerequisites'][key] = {'title': f'{setname}: {name}', 'kind': 'rom', 'formats': ['ZIP', 'loose ROM files'], 'action': 'Add your canonical MAME Final Fight and Street Fighter Alpha 3 inputs.', 'alternatives': [{k: pin[k] for k in ('size', 'sha256', 'crc32') if k in pin}]}
    device = 'rom-' + QSOUND_SHA256[:20]
    sets['qsound'] = {'dl-1425.bin': device}
    sets['sfa3u']['dl-1425.bin'] = device
    release['prerequisites'][device] = {'title': 'QSound firmware (dl-1425.bin)', 'kind': 'firmware', 'formats': ['ZIP', 'loose ROM files'], 'action': 'Add your canonical MAME QSound firmware.', 'alternatives': [{'size': QSOUND['size'], 'sha256': QSOUND_SHA256, 'crc32': QSOUND['crc32']}]}
    disc_files = {}
    for region in ('us', 'jp'):
        disc = registry[region]
        source = 'disc_us' if region == 'us' else 'disc_jp_img'
        if region == 'jp':
            pass
        names = re.findall('^FILE "([^"]+)" BINARY\\r?$', disc['cue'], re.M)
        contracts.require(names and set(names) == set(disc['files']), 'CPS2 disc component extent differs')
        disc_files[region] = {}
        for name, pin in disc['files'].items():
            contracts.file_contract(pin)
            key = 'disc-' + pin['sha256'][:20]
            disc_files[region][name] = key
            release['prerequisites'][key] = {'title': f"Final Fight CD ({('USA' if region == 'us' else 'Japan')}): {name}", 'kind': 'disc', 'formats': ['loose raw CD image/tracks', 'ZIP containing raw CD image/tracks'], 'action': 'Add the matching Sega CD media folder or ZIP. Japan/English use the accepted single-image Japanese rip; USA uses the accepted raw tracks.', 'alternatives': [pin]}
    covered = set()
    for edition, meta in kit['editions'].items():
        region = contracts.region_argument(ET.fromstring(archive.read('mras/' + meta['mra'] + '.mra')).findtext('region'))
        recipe['member_contracts'][edition] = qualified['hbmame/' + meta['set'] + '.zip']['members']
        for platform in ('darksoft', 'fbneo', 'hbmame', 'mame', 'mister'):
            raw = {}
            for name, spec in qualified.items():
                if platform == 'darksoft':
                    belongs = name.startswith(f"darksoft/games/{kit['darksoft']}_{edition}/") or name == f"darksoft/receipts/{kit['darksoft']}_{edition}.json"
                elif platform == 'mame':
                    belongs = name == f'mame/{edition}/sfa3ud.zip'
                elif platform == 'mister':
                    belongs = name in (f"mister/games/hbmame/{meta['set']}.zip", f"mister/games/CPS+/{meta['pack']}.zip", '/'.join((p for p in ('mister', *kit['mra_root'], kit['mra_dir'][edition], meta['mra'] + '.mra') if p)), f"mister/_Arcade/cores/{kit['core']}")
                else:
                    belongs = name == f"{platform}/{meta['set']}.zip"
                if belongs:
                    raw[name] = spec
            contracts.require(raw and any((n.endswith('.zip') or '/games/' in n for n in raw)), 'Missing CPS2 platform output')
            covered.update(raw)
            group = meta['disc'] + '-' + platform
            group_raw = recipe['groups'].setdefault(group, {})
            for name, spec in raw.items():
                contracts.require(name not in group_raw or group_raw[name] == spec, 'Conflicting CPS2 group contract')
                group_raw[name] = spec
            mapping = {n: 'roms/' + Path(n).name if platform in ('mame', 'fbneo', 'hbmame') and n.endswith('.zip') else n[len(platform) + 1:] for n in raw}
            outputs = {mapping[n]: spec for n, spec in raw.items()}
            support = {'README.txt': f'support/{slug}/README.txt', 'PYTHON-DEPENDENCIES.txt': f'support/{slug}/PYTHON-DEPENDENCIES.txt'}
            if platform == 'mister':
                for name in archive.namelist():
                    if name.startswith('core/') and (not name.endswith(('/', '.rbf'))):
                        support[name] = f"_Arcade/cores/licenses/{kit['core']}/{slug}/" + name[len('core/'):]
            for name, dest in support.items():
                outputs[dest] = {'sha256': hashlib.sha256(archive.read(name)).hexdigest()}
            if platform in ('mame', 'hbmame'):
                outputs['roms/qsound.zip'] = {'members': {'dl-1425.bin': QSOUND_SHA256}}
            if platform == 'mister':
                outputs['games/mame/qsound.zip'] = {'members': {'dl-1425.bin': QSOUND_SHA256}}
            files = disc_files[meta['disc']]
            first = next(iter(files))
            files = files if platform == 'mister' else {first: files[first]}
            target_id = edition + '-' + platform
            release['targets'][target_id] = {'platform': platform, 'variant': edition, 'region': region, 'profile': slug + '-' + edition if platform == 'mame' else 'default', 'inputs': sorted(set(files.values()) | {k for members in sets.values() for k in members.values()}), 'outputs': outputs, 'minimum_free_bytes': 8 * 1024 ** 3, 'software_notes': ['Pinned NumPy/Pillow and media helpers are prepared automatically. Verified reconstructed ROMs are reused across platform exports.'], 'destination_requirements': {'hbmame': 'An HBMAME build that includes the Final Fight EX sets.', 'fbneo': 'An FBNeo build that includes the Final Fight EX sets.'}.get(platform, 'Follow the public kit instructions.')}
            if kit.get('recipe') == 'final-fight-cps2-recipes/1':
                release['targets'][target_id]['software_notes'] = [
                    'Prepared source recipes remove scene rendering and Pillow.',
                    ('Python and authenticated media helpers reproduce the MiSTer soundtrack; no numerical packages are needed.'
                     if kit.get('pcm_runtime') == 'compiled-float64-weights/1' else
                     'NumPy and authenticated media helpers reproduce the MiSTer soundtrack.'),
                    'Verified reconstructed ROMs are reused across platform exports.']
            recipe['targets'][target_id] = {'edition': edition, 'disc_region': meta['disc'], 'platform': platform, 'group': group, 'files': files, 'data_file': first, 'cue': registry[meta['disc']]['cue'], 'sets': sets, 'device': device, 'mapping': mapping, 'kit_mapping': support, 'outputs': outputs, 'device_output': 'games/mame/qsound.zip' if platform == 'mister' else 'roms/qsound.zip' if platform in ('mame', 'hbmame') else None}
    contracts.require(covered == set(qualified), 'Unaccounted CPS2 output contracts')
    for requirement in release['prerequisites'].values():
        if '7z member' not in requirement['formats']:requirement['formats'].append('7z member')
    release['api'] = 1
    release['project'] = slug
    release['native_outputs'] = qualified
    release['requires'] = sorted(set(release['requires']) | {'native-context-v1', 'native-bindings-v1'})
    from native_cd_sources import attach
    attach(release, recipe, registry)
    return (release, recipe)
