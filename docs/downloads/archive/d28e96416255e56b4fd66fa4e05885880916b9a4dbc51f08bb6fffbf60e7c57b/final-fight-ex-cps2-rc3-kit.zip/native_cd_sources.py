"""Admit equivalent BIN/CUE carriers through exact native raw-track views."""
import hashlib
import json
from pathlib import Path
import re


def require(ok, message):
    if not ok:
        raise ValueError(message)


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def logical_tracks(disc):
    """Derive logical identities from the independently pinned split dump."""
    tracks = [];member = None;current = None
    for line in disc['cue'].splitlines():
        line = line.strip()
        if re.fullmatch(r'CATALOG \d{13}', line):
            continue  # Disc catalog metadata does not describe consumed bytes.
        if line.startswith('FILE '):
            match = re.fullmatch(r'FILE "([^"/\\]+)" BINARY', line)
            require(match, 'Unsupported canonical CD FILE')
            member = match[1]
        elif line.startswith('TRACK '):
            match = re.fullmatch(r'TRACK (\d+) (MODE1/2352|AUDIO)', line)
            require(match and member in disc['files'], 'Unsupported canonical CD TRACK')
            pin = disc['files'][member]
            current = {'track': int(match[1]), 'mode': match[2], 'bytes': pin['size'],
                       'sha256': pin['sha256'], 'index01': None}
            tracks.append((member, current))
        elif line.startswith('INDEX '):
            match = re.fullmatch(r'INDEX (00|01) (\d+):(\d+):(\d+)', line)
            require(match and current is not None, 'Unsupported canonical CD INDEX')
            sector = (int(match[2]) * 60 + int(match[3])) * 75 + int(match[4])
            if match[1] == '00':
                require(sector == 0, 'Canonical split track must start at zero')
            else:
                current['index01'] = sector
        elif line:
            raise ValueError('Unknown canonical CUE directive: ' + line.split()[0])
    require(len(tracks) == len(disc['files']) and {n for n, _ in tracks} == set(disc['files'])
            and [t['track'] for _, t in tracks] == list(range(1, len(tracks) + 1))
            and all(t['index01'] is not None for _, t in tracks), 'Incomplete canonical split CD')
    return tracks


def attach(release, layout, registry):
    """Retain the original exact-component method and add a loose CUE method."""
    views = {}
    require(set(registry) <= {'us', 'jp', 'qsound'}, 'Unknown native CD registry domain')
    for region in ('us', 'jp'):
        if region not in registry:
            continue
        disc = registry[region]
        if len(disc['files']) <= 1:
            continue  # Existing single-image routes already accept renamed BINs.
        tracks = logical_tracks(disc)
        identity = {'type': 'cue', 'tracks': [row for _, row in tracks]}
        key = 'disc-cue-' + digest(json.dumps(identity, sort_keys=True).encode())[:20]
        raw = disc['cue'].encode()
        release['prerequisites'][key] = {'title': 'Final Fight CD (' + region.upper() + '): BIN/CUE disc',
            'kind': 'disc', 'formats': ['loose CUE with adjacent raw BIN image or tracks'],
            'action': 'Add the complete matching BIN/CUE disc folder.',
            'alternatives': [{'size': len(raw), 'sha256': digest(raw)}],
            'content': [{'extensions': ['.cue'], 'identity': identity}]}
        by_name = dict(tracks)
        for name, execution in layout['targets'].items():
            selected = execution['files']
            if not selected or not set(selected) <= set(disc['files']):
                continue
            target = release['targets'][name];original = target['inputs']
            other = sorted(set(original) - set(selected.values()))
            target['inputs'] = []
            target['input_options'] = [
                {'id': 'raw-components', 'title': 'Exact raw disc components', 'inputs': original},
                {'id': 'bin-cue', 'title': 'Equivalent BIN/CUE disc', 'inputs': sorted(other + [key])}]
            views[name] = {'cue': key, 'identity': identity, 'files': {
                filename: {'binding': binding, 'track': by_name[filename]['track'], **disc['files'][filename]}
                for filename, binding in selected.items()}}
    if views:
        layout['cue_views'] = views
        release['requires'] = sorted(set(release['requires']) | {'input-options-v1'})


def normalize(bindings, view, destination):
    """Copy only declared tracks, checking their exact accepted byte identities."""
    import media_identity
    cue = bindings[view['cue']]
    require('member' not in cue, 'BIN/CUE input must be a loose disc folder')
    path = Path(cue['path'])
    media_identity.verify(path, view['identity'], lambda name: None)
    entries, _ = media_identity.companion('extract_cdda').parse_cue(path)
    destination = Path(destination);destination.mkdir(parents=True, exist_ok=True)
    result = {k: v for k, v in bindings.items() if k != view['cue']}
    for filename, pin in view['files'].items():
        require(Path(filename).name == filename and filename not in ('.', '..'), 'Unsafe native CD view name')
        rows = [row for row in entries if row[0] == pin['track']]
        require(len(rows) == 1, 'Missing or ambiguous native CD track')
        n, mode, source, i0, i1, pregap = rows[0]
        require(mode.upper() in ('MODE1/2352', 'AUDIO'), 'Unsupported raw CD view mode')
        start = (i0 if i0 is not None else i1) * 2352
        following = [row for row in entries if row[0] > n and row[2] == source]
        end = ((following[0][3] if following[0][3] is not None else following[0][4]) * 2352
               if following else source.stat().st_size)
        require(0 <= start <= end and end - start + pregap * 2352 == pin['size'], 'Native CD view extent differs')
        output = destination / filename;value = hashlib.sha256();size = 0
        try:
            with output.open('wb') as target, source.open('rb') as stream:
                remaining = pregap * 2352
                while remaining:
                    raw = bytes(min(remaining, 1024**2));target.write(raw);value.update(raw);size += len(raw);remaining -= len(raw)
                stream.seek(start);remaining = end - start
                while remaining:
                    raw = stream.read(min(remaining, 8 * 1024**2))
                    require(raw, 'Truncated native CD view')
                    target.write(raw);value.update(raw);size += len(raw);remaining -= len(raw)
            require(size == pin['size'] and value.hexdigest() == pin['sha256'], 'Native CD track content differs: ' + filename)
        except BaseException:
            output.unlink(missing_ok=True)
            raise
        result[pin['binding']] = {'path': str(output.resolve()), 'size': size, 'sha256': value.hexdigest()}
    return result
