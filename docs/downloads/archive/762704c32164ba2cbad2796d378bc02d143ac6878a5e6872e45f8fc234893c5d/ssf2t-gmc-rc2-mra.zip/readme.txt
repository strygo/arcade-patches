Super Street Fighter II Turbo: Grand Master Challenge · English restoration · Japan's Super Turbo
=================================================================================================

Version:  rc2 (2026-09-17)
Target:   MAME set 'ssf2xj' (Super Street Fighter II X: Grand Master Challenge (Japan 940311))
Hardware: Capcom CPS-2
Patch by: Steve Gordon (https://x.com/strygo)
Website:  https://strygo.github.io/arcade-patches/

ABOUT THIS PROJECT

Super Turbo came in two versions. Japan got Super Street Fighter II X, the one
competitive players swear by. The rest of the world got a slightly different
game: it plays differently, the continue screen is bare, most of the win
quotes are gone, the endings are shorter, and Akuma's story is missing.
Japan's version, of course, was in Japanese.

Grand Master Challenge is Japan's game in English. The fighting is untouched.
Everything you read is new: all 136 win quotes, the strategy tips on the
continue screen, the full endings, and Akuma's dialogue, translated fresh from
the Japanese with Capcom's own English as the style guide.

It runs anywhere Super Turbo does: MAME, HBMAME, MiSTer, or a real CPS-2
board. The patch keeps the ROM's original sizes and key, so it drops in over
the stock Japanese set.

WHAT'S CHANGED

  - Japan's game, exactly as it plays in Japan
  - The Grand Master Challenge title, and a US region
  - Balrog, Vega, M. Bison and Akuma, the names you know
  - All 136 win quotes in English
  - The continue screen's strategy tips in English
  - Every ending in full, in English, including Akuma's
  - Akuma's intro dialogue, cut from the export game

MISTER SETUP

1. Copy the _Arcade/ folder from this download to the root of your
   MiSTer SD card (the MRA lands in _Arcade/_Arcade Patches/_Restorations/), or copy
   "Super Street Fighter II Turbo Grand Master Challenge (USA) [English Restoration].mra" anywhere under _Arcade/.
2. Have the stock, unmodified romset at games/mame/ssf2xj.zip
   (split MAME sets also need qsound.zip next to it).
3. You need Jotego's jtcps2 core; the standard MiSTer downloader /
   update_all installs it automatically.

The MRA references your original romset and applies the restoration in
memory while the game loads. Nothing on your SD card is modified. The
restoration keeps its own settings and saves under the name
'ssf2tgmc'.

LEGAL

This is a free, unofficial fan patch. It is not affiliated with or endorsed
by Capcom. All game titles, characters, and artwork remain the property of
their respective owners. You must own the game to use this patch. Do not
sell this patch or distribute it applied to a ROM image.
