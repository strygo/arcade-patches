from __future__ import annotations
import argparse, base64, hashlib, json, math, shutil, struct, subprocess, sys, tempfile, zipfile, zlib
from pathlib import Path
import arrange, collection, recipe, voices, cps2tiles, cps2_crypt, tilelz, adx_native, cpk_format, prompt_native
def require(ok, message):
    if not ok: raise ValueError(message)

def sha(data): return hashlib.sha256(data).hexdigest()

def swap(data): return arrange.wordswap(data)

class Disc(collection.Disc):
    def __init__(self, path, scratch, chdman=None):
        self.path, self.scratch = Path(path), Path(scratch)
        self.chdman = chdman or shutil.which('chdman')
        require(self.path.suffix.lower() in ('.iso', '.chd'), 'declared ISO or CHD required')
        require(self.path.is_file(), 'declared Collection disc is missing')
        if self.path.suffix.lower() == '.chd': require(self.chdman, 'CHD input requires chdman')
        super().__init__(self.path)

    def _read(self, offset, size):
        if self.path.suffix.lower() == '.iso':
            with self.path.open('rb') as stream: stream.seek(offset); data = stream.read(size)
        else:
            with tempfile.TemporaryDirectory(prefix='slice-', dir=self.scratch) as directory:
                target = Path(directory)/'slice.bin'
                subprocess.run([self.chdman, 'extractraw', '-i', str(self.path), '-o', str(target),
                                '-isb', str(offset), '-ib', str(size)], check=True,
                               stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
                data = target.read_bytes()
        require(len(data) == size, 'short declared disc slice')
        return data

    def layer(self, entry, want_md5=None):
        """The native scene serializers consume all three actual tile sizes."""
        blob=self.entry(entry,want_md5);out=bytearray()
        for section,size in enumerate((32,128,512)):
            base,count,table=struct.unpack_from('<III',blob,16*section)
            if not count:continue
            require(table+4*count<=len(blob),'complete layer pointer table required')
            ptrs=struct.unpack_from('<'+str(count)+'I',blob,table)
            starts=sorted({p&0x7fffffff for p in ptrs if p})
            ends=dict(zip(starts,starts[1:]+[len(blob)]))
            for p in ptrs:
                if not p:continue
                at=p&0x7fffffff;block=blob[at:ends[at]]
                if p>>31:
                    tile,used=tilelz.decompress_verbose(block,out_len=size)
                    require(tile is not None and used<=len(block),'complete layer tile decode failed')
                else:tile=block[:size]
                require(len(tile)==size,'complete layer tile width changed')
                planar=cps2tiles.disc_to_planar(tile)
                if size==32:planar=b''.join(planar[i:i+4]*2 for i in range(0,32,4))
                out+=planar
        return bytes(out)

class Inputs(arrange.Inputs):
    def __init__(self, rompath, disc, spec, scratch, chdman=None):
        roms = {}
        for name, pins in spec['roms'].items():
            with zipfile.ZipFile(Path(rompath)/(name+'.zip')) as archive:
                require(len(archive.namelist()) == len(set(archive.namelist())), 'duplicate input member')
                roms[name] = {n: archive.read(n) for n in pins}
            require(all(sha(data) == pins[n] for n, data in roms[name].items()), 'canonical input differs: '+name)
        super().__init__(roms, Disc(disc, scratch, chdman), spec)

    def source(self, name):
        if name in self.cache: return self.cache[name]
        kind, _, rest = name.partition(':')
        if kind == 'decprogram':
            members = self.roms[rest]; names = self.spec['programs'][rest]
            raw = swap(b''.join(members[n] for n in names)); key = members[rest+'.key']
            data = cps2_crypt.decrypt_rom(raw, key)[0]
            require(sha(data) == self.spec['decrypted_sha256'][rest], 'decrypted input identity differs')
        elif kind == 'rawprogram': data = swap(b''.join(self.roms[rest][n] for n in self.spec['programs'][rest]))
        elif kind == 'pkg32':
            data = self.source('pkg:'+rest)
            require(len(data)%4 == 0, 'complete typed package required')
            data = b''.join(data[i:i+4][::-1] for i in range(0, len(data), 4))
        elif kind == 'native_staff': data = self.staff_samples()
        elif kind == 'native_phobos_pixel':
            # Source6's native-derived pen14 -> pen6 correction at (9,3).
            # Copy the complete canonical tile before clearing its one bit.
            at=(4*0x4000+0x3333)*128
            original=self.source('gfx:vsav2:m:1')[at:at+128]
            require(sha(original)=='055107a0b317a23cbc40d541b5de14f8b5eaaab8a8e481ef183bdf6e793a6245',
                    'complete native Phobos pixel preimage differs')
            data=bytearray(original);data[31]&=0xbf;data=bytes(data)
            require(sha(data)=='b28ed0d422da60fe87e18378c444365b5a53ef73560e96aef4f34038e4dc5c4a',
                    'complete corrected Phobos tile differs')
        elif kind == 'native_prompt':
            original=self.source('gfx:vsavj:m:0')[0x800000:0xa00000]
            converted,_=prompt_native.derive(original,dict(glyph_base=0x3800,sprite_tile_page=0x10000),self.spec['prompt'])
            at=((0x3800+int(self.spec['prompt']['english_word'],16))%0x4000)*128
            data=converted[at:at+128]
        elif kind == 'relocated_native':
            raw=self.source('rawprogram:'+rest);dec=self.source('decprogram:'+rest)
            data=bytearray(b'\xff'*(4<<20))
            end=0
            for row in sorted(self.spec['relocated_native']['segments'],key=lambda q:q['output']):
                at,size,old=row['output'],row['bytes'],row['source']
                require(0<=old<old+size<=len(raw) and end<=at<at+size<=len(data),
                        'typed native relocation range changed')
                body=bytearray(raw[old:old+size]);view=dec[old:old+size]
                require(sha(body)==row['raw_sha256'] and sha(view)==row['opcode_sha256'],
                        'complete native relocation preimage differs')
                for start,stop in row['opcode_runs']:
                    require(0<=start<stop<=size,'native opcode view leaves body')
                    body[start:stop]=view[start:stop]
                for patch in row['patches']:
                    p=patch['offset'];q=bytes.fromhex(patch['bytes'])
                    require(0<=p<p+len(q)<=size and sha(body[p:p+len(q)])==patch['before_sha256'],
                            'typed relocation patch preimage differs')
                    require(all(v!=raw[old+p+i] and v!=view[p+i] for i,v in enumerate(q)),
                            'unchanged native bytes must come from the input, never a literal')
                    body[p:p+len(q)]=q
                require(sha(body)==row['output_sha256'],'whole relocated body differs')
                data[at:at+size]=body;end=at+size
            data=bytes(data)
        elif kind == 'native_cursor_source':
            data = self.cursor_source()
        elif kind == 'native_select_outline':
            data = self.outline_tiles()
        elif kind == 'fill':
            fields=rest.split(':');size=int(fields[1])if len(fields)==2 else 4<<20
            require(len(fields)in(1,2)and 0<size<=4<<20,'bounded fill pool required')
            data=bytes([int(fields[0],16)])*size
        else: data = super().source(name)
        pin = self.spec.get('pool_sha256', {}).get(name)
        if pin: require(sha(data) == pin, 'derived pool differs: '+name)
        self.cache[name] = data
        return data

    def cursor_source(self):
        q = self.spec['select_outline_source']
        require(q['entry']==455 and q['section']==1 and 0<len(q['codes'])<=64,
                'unknown native cursor texture domain')
        blob = self.disc.entry(455)
        require(sha(blob)==q['source_sha256'],'complete original cursor texture differs')
        base,count,table = struct.unpack_from('<III',blob,16)
        require(count>0 and table+4*count<=len(blob),'cursor section extent differs')
        pointers=struct.unpack_from('<'+str(count)+'I',blob,table)
        offsets=sorted({v&0x7fffffff for v in pointers if v})
        ends=dict(zip(offsets,offsets[1:]+[len(blob)]));result=bytearray()
        for code in q['codes']:
            require(base<=code<base+count,'original cursor tile escaped section')
            pointer=pointers[code-base];offset=pointer&0x7fffffff
            require(pointer and 0<offset<ends[offset]<=len(blob),'cursor tile physical extent differs')
            block=blob[offset:ends[offset]]
            if pointer>>31:
                data,used=tilelz.decompress_verbose(block,out_len=128)
                require(data is not None and used<=len(block),'cursor tile decompression failed')
            else:data=block[:128]
            require(len(data)==q['decoded_bytes'][str(code)] and len(data)>=128,
                    'complete native cursor pixel view differs')
            planar=cps2tiles.disc_to_planar(data[:128])
            require(sha(planar)==q['tile_sha256'][str(code)],'complete original cursor tile differs')
            result.extend(planar)
        return bytes(result)

    def outline_tiles(self):
        q = self.spec['select_outline']; source = self.source(q['source_pool'])
        require(q['source_pool'] == 'native_cursor_source' and len(q['tiles']) == 19,
                'unknown authored cursor source/domain')
        result = bytearray()
        for copies in q['tiles']:
            tile = bytearray(b'\xff' * 128); seen = set()
            for destination, origin in copies:
                require(0 <= destination < 256 and destination not in seen and
                        0 <= origin < len(source) * 2, 'invalid cursor source-pixel projection')
                seen.add(destination)
                source_tile, pixel = divmod(origin, 256); sy, sx = divmod(pixel, 16)
                dy, dx = divmod(destination, 16)
                src = source_tile * 128 + sy * 8 + (sx >> 3) * 4
                dst = dy * 8 + (dx >> 3) * 4; sb, db = 7-(sx&7), 7-(dx&7)
                pen = 0
                for plane in range(4):
                    bit = (source[src+plane] >> sb) & 1; pen |= bit << plane
                    tile[dst+plane] = (tile[dst+plane] & ~(1 << db)) | (bit << db)
                require(pen != 15, 'opaque cursor copy refers to transparency')
            result.extend(tile)
        return bytes(result)

    def staff_samples(self):
        q = self.spec['staff']; raw = self.disc._read(q['offset'], q['bytes'])
        require(sha(raw) == q['sha256'], 'staff ADX input differs')
        info = adx_native.parse_header(raw)
        coefficients = adx_native.calc_coeffs(info.cutoff, info.sample_rate)
        decoded = adx_native.py_decode(raw[info.data_offset:], info.channels, *coefficients)
        require(info.channels == 2 and min(map(len, decoded)) >= info.total_samples, 'staff channel extent differs')
        from array import array
        pcm=array('h')
        for a,b in zip(decoded[0][:info.total_samples],decoded[1][:info.total_samples]):pcm.extend((a,b))
        if sys.byteorder!='little':pcm.byteswap()
        require(sha(pcm.tobytes())==q['decoded_s16le_sha256'],'pure ADX decode differs from the native producer')
        parts = []
        for channel in decoded:
            for section in q['sections']:
                lo, hi, count = section['source_start'], section['source_end'], section['samples']
                converted = voices.resample(channel[lo:hi], info.sample_rate,
                                           count*info.sample_rate/(hi-lo)*(1+1e-12))
                require(len(converted) >= count, 'short staff resample')
                parts.append(voices.to_pcm8(converted[:count]))
        data = b''.join(parts)
        if q.get('pcm_pool_sha256'):
            require(sha(data) == q['pcm_pool_sha256'], 'pure native staff PCM differs from producer')
        return data

def reconstruct(inputs, value):
    out = {}
    for unit in value['units']:
        pool = inputs.pool(unit['pool'])
        ops = recipe.load_ops(zlib.decompress(base64.b64decode(unit['ops'])))
        data = recipe.apply_member(ops, pool)
        require(sha(data) == unit['decoded_sha256'], 'decoded unit differs')
        if unit['level'] == 'tiles': members = cps2tiles.encode_group(data)
        elif unit['level'] in ('samples', 'extension'): members = [swap(data)]
        else: members = [data]
        require(len(members) == len(unit['members']), 'member unit shape differs')
        for name, member in zip(unit['members'], members):
            require(name not in out, 'duplicate output member'); out[name] = member
    require({n: dict(size=len(b), sha256=sha(b)) for n, b in out.items()} == value['members'],
            'complete output inventory differs')
    return out

def scene_pack(inputs, value, path):
    q = value['CPK']; protocol = dict(q['protocol'])
    protocol['control_verbs'] = {int(k): v for k, v in protocol['control_verbs'].items()}
    writer = cpk_format.PackWriter(cpk_format.Protocol(**protocol), title=q['title'])
    for command in q['native_music_handoffs']:
        writer.set_trigger(command, cpk_format.TriggerRow(verb=cpk_format.VERB_STOP, suppress=0))
    for index, row in enumerate(q['tracks']):
        raw = inputs.disc._read(row['offset'], row['bytes'])
        require(sha(raw) == row['source_sha256'], 'scene ADX source differs')
        info = adx_native.parse_header(raw); fields = dict(row['metadata'])
        length = fields.pop('data_length'); fields.pop('data_offset')
        stream = raw[info.data_offset:info.data_offset+length]
        require(sha(stream) == row['stream_sha256'], 'preserved scene ADX stream differs')
        writer.add_track(stream, cpk_format.TrackMeta(**fields))
        writer.set_trigger(row['command'], cpk_format.TriggerRow(verb=cpk_format.VERB_PLAY,
                            track=index, gain=20, suppress=1))
    writer.write(path, sidecar=False)
    require((Path(path).stat().st_size, sha(Path(path).read_bytes())) == (q['bytes'], q['sha256']),
            'complete reconstructed CPK differs')

def write_zip(path, members):
    with zipfile.ZipFile(path, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, data in sorted(members.items()):
            info = zipfile.ZipInfo(name, (1980, 1, 1, 0, 0, 0)); info.external_attr=0o600<<16
            archive.writestr(info, data)
