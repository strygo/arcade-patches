"""Explicit Arrange FBNeo exports; native HBMAME/MiSTer members stay intact."""
import hashlib
import json
from pathlib import Path


def enable(root):
    root = Path(root)
    registry = (root / 'fbneo_names.json').read_bytes()
    (root / 'fbneo-exports.json').write_text(json.dumps({'schema': 1,
        'registry_sha256': hashlib.sha256(registry).hexdigest()}, sort_keys=True) + '\n')
    config = json.loads((root / 'kit.json').read_text())
    definition = json.loads((root / 'collection.json').read_text())
    project = definition['project']
    config['fbneo_sets'] = {n: r['setname'] for n, r in json.loads(registry)['sets'].items() if r['slug'] == project}
    (root / 'kit.json').write_text(json.dumps(config, indent=2, sort_keys=True) + '\n')
    names = '\n'.join('  ' + old + ' -> ' + new + '.zip' for old, new in config['fbneo_sets'].items())
    (root / 'FBNEO.txt').write_text('FBNeo exports\n\nThe default build also writes out/fbneo/. Build only these sets with:\n'
        '  python3 apply.py --disc COLLECTION.chd --rompath ROM_DIRECTORY --platform fbneo --out-dir out\n\n'
        + names + '\n\nUse an FBNeo build containing these new set names and matching game revisions.\n'
        'The previous numbered Arrange IDs remain the HBMAME/MiSTer names.\n'
        'FBNeo configuration, NVRAM and save-state filenames use the new IDs.\n'
        'Back up old files; save-state compatibility across game revisions is untested.\n'
        'The ROM contents and all HBMAME/MiSTer outputs are unchanged.\n')


def projection(root, files, platform='all'):
    if platform not in ('all', 'hbmame', 'mister', 'fbneo'):
        raise ValueError('Unknown Arrange platform')
    files = dict(files)
    if (Path(root) / 'fbneo-exports.json').is_file():
        marker = json.loads((Path(root) / 'fbneo-exports.json').read_text())
        if marker != {'schema': 1, 'registry_sha256': hashlib.sha256((Path(root) / 'fbneo_names.json').read_bytes()).hexdigest()}:
            raise ValueError('Arrange FBNeo naming declaration changed')
        from fbneo_names import add_outputs
        add_outputs(files)
    elif platform == 'fbneo':
        raise ValueError('This kit has no FBNeo export declaration')
    return files if platform == 'all' else {n: b for n, b in files.items() if n.startswith(platform + '/')}
