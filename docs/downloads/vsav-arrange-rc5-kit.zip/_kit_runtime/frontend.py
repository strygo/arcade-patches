#!/usr/bin/env python3
"""Private one-game engine adapter for the public apply.py entry."""
import argparse
import contextlib
import hashlib
import importlib.util
import json
import os
from pathlib import Path, PurePosixPath
import sys
import tempfile
import zipfile


def require(ok, message):
    if not ok:
        raise ValueError(message)


def pin(path):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 ** 2), b''):value.update(block)
    return {'size': path.stat().st_size, 'sha256': value.hexdigest()}


def member(root, name):
    p = PurePosixPath(name)
    require(name and not p.is_absolute() and '\\' not in name and ':' not in name
            and all(part not in ('', '.', '..') for part in name.split('/')), 'Unsafe kit member')
    path = root
    for part in p.parts:
        path /= part
        require(not path.is_symlink(), 'Kit member must not be a symlink: ' + name)
    return path


def load(root):
    metadata = json.loads(member(root, 'standalone.json').read_text())
    require(metadata.get('schema') == 2 and metadata.get('payload') and metadata.get('frontend'),
            'Unknown standalone kit metadata')
    base = {'_kit_runtime/frontend.py', '_kit_runtime/arcadepatches.py'}
    companions = {'_kit_runtime/' + n + '.py' for n in ('media_identity', 'switch_source', 'extract_cdda')}
    identities = {'_kit_runtime/file_identity.py'}
    require(set(metadata['frontend']) in (base, base | companions, base | identities, base | companions | identities)
            and {'apply.py', 'collection.json'} <= set(metadata['payload'])
            and not set(metadata['payload']) & set(metadata['frontend']), 'Incomplete standalone software inventory')
    engine_path = member(root, '_kit_runtime/arcadepatches.py')
    if b'import media_identity' in engine_path.read_bytes():
        require(companions <= set(metadata['frontend']), 'Incomplete engine companion inventory')
    if b'from file_identity import' in engine_path.read_bytes():
        require(identities <= set(metadata['frontend']), 'Incomplete file identity companion inventory')
    for name, expected in (metadata['payload'] | metadata['frontend']).items():
        path = member(root, name)
        require(path.is_file() and pin(path) == expected,
                'Kit file missing or changed: ' + name + '. Restore it from the original ZIP.')
    if companions <= set(metadata['frontend']):
        helper_spec = importlib.util.spec_from_file_location('media_identity', root / '_kit_runtime/media_identity.py')
        helper = importlib.util.module_from_spec(helper_spec)
        sys.modules['media_identity'] = helper
        helper_spec.loader.exec_module(helper)
    if identities <= set(metadata['frontend']):
        identity_spec = importlib.util.spec_from_file_location('file_identity', root / '_kit_runtime/file_identity.py')
        helper = importlib.util.module_from_spec(identity_spec)
        sys.modules['file_identity'] = helper
        identity_spec.loader.exec_module(helper)
    spec = importlib.util.spec_from_file_location('_kit_engine', engine_path)
    engine = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(engine)
    definition = json.loads(member(root, 'collection.json').read_text())
    require(definition.get('api') == 1 and definition['project'] == metadata['project'], 'Kit identity differs')
    return engine, definition, metadata


def catalog(engine, definition, archive, discovery):
    key = 'standalone-kit'
    require(key not in definition.get('artifacts', {}), 'Reserved kit artifact name')
    release = {k: definition[k] for k in ('environments', 'helpers') if k in definition}
    release.update(protocol=1, minimum_launcher='0.1.0',
                   requires=sorted(set(['native-kit-v1', 'file-inputs-v1', 'archive-inputs-v1',
                                        'zip-outputs-v1', *definition.get('requires', [])])),
                   game_version=definition['game_version'], kit_revision=definition['kit_revision'],
                   runner={'api': 1, 'artifact': key, 'entry': 'apply.py'},
                   prerequisites=definition['prerequisites'], targets=definition['targets'])
    slug = definition['project']
    require(not set(discovery['artifacts']) & set(definition.get('artifacts', {})), 'Reserved discovery artifact name')
    return engine.validate_catalog({'schema': 1, 'generation': 1,
        'projects': {slug: {'title': slug.replace('-', ' ').title(), 'current': slug}},
        'releases': {slug: release},
        'source_helpers': discovery['source_helpers'],
        'artifacts': {**discovery['artifacts'], **definition.get('artifacts', {}), key: {**pin(archive), 'url': 'local:kit.zip'}}})


def cache_payload(root, metadata, home, filesystem_path=Path):
    """Stage only declared software, never user media, output or caches."""
    cache = home / 'cache/artifacts'
    require(not any(p.is_symlink() for p in (home, home / 'cache', cache)), 'State/cache must not use symlinks')
    cache = filesystem_path(cache)
    cache.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='.kit-', dir=cache) as temporary:
        archive = Path(temporary) / 'kit.zip'
        with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as output:
            for name, expected in sorted(metadata['payload'].items()):
                path = member(root, name)
                data = path.read_bytes()
                require({'size': len(data), 'sha256': hashlib.sha256(data).hexdigest()} == expected,
                        'Kit changed while staging: ' + name)
                info = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
                info.compress_type = zipfile.ZIP_DEFLATED
                info.external_attr = 0o100644 << 16
                output.writestr(info, data)
        destination = cache / pin(archive)['sha256']
        require(not destination.is_symlink(), 'Cached kit must not be a symlink')
        if destination.exists():
            require(pin(destination) == pin(archive), 'Cached kit changed')
        else:os.replace(archive, destination)
        return destination


def choices(values, allowed, label, previous='all'):
    if values is None:
        values = previous if isinstance(previous, list) else [previous]
    require(isinstance(values, list) and all(isinstance(v, str) for v in values), 'Invalid saved ' + label)
    selected = [value.strip().lower() for item in values for value in item.split(',')]
    selected = [{'usa': 'us', 'japan': 'jp', 'europe': 'eu', 'both': 'all'}.get(v, v) for v in selected]
    if selected == ['all']:return 'all'
    require(selected and 'all' not in selected and set(selected) <= set(allowed),
            'Unknown ' + label + '; use --list. Choose all by itself, or repeat the option.')
    return sorted(set(selected))


def cache_bundles(paths, artifacts, home, filesystem_path=Path):
    """Authenticate declared wheels/helper archives from offline bundles."""
    cache = home / 'cache/artifacts'
    require(not any(p.is_symlink() for p in (home, home / 'cache', cache)), 'State/cache must not use symlinks')
    cache = filesystem_path(cache)
    cache.mkdir(parents=True, exist_ok=True)
    sizes = {spec['size'] for spec in artifacts.values()}
    def store(data):
        expected = {'size': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
        if not any(all(spec[k] == v for k, v in expected.items()) for spec in artifacts.values()):return
        target = cache / expected['sha256']
        require(not target.is_symlink(), 'Cached dependency must not be a symlink')
        with tempfile.NamedTemporaryFile(dir=cache, delete=False) as stream:
            temporary = Path(stream.name)
            stream.write(data)
        try:os.replace(temporary, target)
        finally:temporary.unlink(missing_ok=True)
    for value in filter(None, paths):
        path = value.expanduser().resolve()
        require(path.exists(), 'Offline bundle is missing: ' + str(value))
        candidates = list(path.iterdir()) if path.is_dir() else [path]
        require(len(candidates) <= 10000, 'Offline bundle has too many files')
        for candidate in candidates:
            if not candidate.is_file() or candidate.is_symlink():continue
            if candidate.stat().st_size in sizes:store(candidate.read_bytes())
            if zipfile.is_zipfile(candidate):
                with zipfile.ZipFile(candidate) as archive:
                    entries = archive.infolist()
                    require(len(entries) <= 100000, 'Offline archive has too many members')
                    for info in entries:
                        if not info.is_dir() and info.file_size in sizes:store(archive.read(info))


class Cancelled(Exception):
    pass


def answer(prompt):
    value = input(prompt).strip()
    if value.lower() in ('q', 'quit', 'exit'):raise Cancelled()
    return value


def select(label, values, previous=None, labels=None):
    values = sorted(set(values))
    if len(values) == 1:return values[0]
    labels = labels or {}
    default = previous[0] if isinstance(previous, list) and len(previous) == 1 and previous[0] in values else None
    print('\n' + label + ':')
    for number, value in enumerate(values, 1):print(f'  {number}. {labels.get(value, value.replace("-", " ").title())}')
    print(f'  {len(values) + 1}. All')
    while True:
        value = answer('Choose a number' + (f' [{values.index(default) + 1}]' if default else '') + ': ')
        if not value and default:return default
        if value.isdigit() and 1 <= int(value) <= len(values) + 1:
            return values[int(value) - 1] if int(value) <= len(values) else 'all'
        print('Enter one of the numbers above, or q to quit.')


def configure_guided(root, definition, previous, *, edit_output=False, show_path=str):
    old = previous.get('roots', [])
    existing = [p for p in old if Path(p).exists()]
    default = next(iter(existing), '') or next((str(p) for p in (root / 'roms', root / 'inputs') if p.is_dir()), '')
    if len(old) > 1:
        print('Saved media locations:')
        for path in old:print('  ' + show_path(path) + ('' if Path(path).exists() else ' (missing)'))
        print('Enter keeps all existing saved locations. A new path replaces them; add more below.')
    roots = []
    while True:
        value = answer('Media folder or file' + (f' [{show_path(default)}]' if default else '') + ': ')
        if not value and existing:roots.extend(existing)
        else:
            value = value or default
            path = Path(value.strip('"')).expanduser() if value else None
            if path is None or not path.exists():
                print('That path does not exist. Enter a media folder or file, or q to quit.');continue
            roots.append(str(path.resolve()))
        if answer('Add another media folder or file? [y/N]: ').lower() not in ('y', 'yes'):break
        default = '';existing = []
    targets = list(definition['targets'].values());rules = previous.get('selection', {})
    platform = select('Platform', [t['platform'] for t in targets], rules.get('platforms'),
                      {'mame': 'MAME', 'hbmame': 'HBMAME', 'fbneo': 'FBNeo', 'mister': 'MiSTer', 'darksoft': 'Darksoft'})
    targets = [t for t in targets if platform == 'all' or t['platform'] == platform]
    regions = {r for t in targets for r in t.get('regions', [t.get('region', 'all')])}
    region = select('Region', regions, rules.get('regions'),
                    {'us': 'USA', 'jp': 'Japan', 'eu': 'Europe', 'world': 'World', 'asia': 'Asia'}) if len(targets) > 1 else 'all'
    targets = [t for t in targets if region == 'all' or region in t.get('regions', [t.get('region', 'all')])]
    variant = select('Edition', [t['variant'] for t in targets], rules.get('variants'))
    output = previous.get('output', str(root / 'out'))
    if previous or edit_output:
        value = answer(f'Output folder [{show_path(output)}]: ')
        if value:output = str(Path(value.strip('"')).expanduser().absolute())
    return roots, platform, region, variant, output


def read_guided_settings(path):
    if not path.exists():return {}
    try:
        value = json.loads(path.read_text())
        require(isinstance(value, dict) and value.get('schema') == 1, 'Unsupported settings')
        require(isinstance(value.get('roots'), list) and value['roots'] and
                all(isinstance(p, str) and Path(p).is_absolute() for p in value['roots']), 'Invalid saved media paths')
        require(isinstance(value.get('output'), str) and Path(value['output']).is_absolute(), 'Invalid saved output path')
        require(isinstance(value.get('selection'), dict), 'Invalid saved choices')
        require('kit_root' not in value or isinstance(value['kit_root'], str) and Path(value['kit_root']).is_absolute(),
                'Invalid saved kit location')
        require('tools_cache' not in value or isinstance(value['tools_cache'], str) and Path(value['tools_cache']).is_absolute(),
                'Invalid saved helper cache')
        return {k: v for k, v in value.items() if k != '_relocation'}
    except (OSError, ValueError, TypeError) as exc:
        print('Saved settings could not be read: ' + str(exc) + '. Set up your choices again.')
        return {}


def confirm_locations(root, previous, engine):
    """Never silently redirect a copied ownership receipt to another output."""
    if not previous:return previous
    current = engine.filesystem_path(root)
    anchor = engine.filesystem_path(previous['kit_root']) if previous.get('kit_root') else None
    output = engine.filesystem_path(previous['output'])
    if anchor == current or anchor is None and output.is_relative_to(current):return previous
    local = current / 'out'
    if anchor is not None and output.is_relative_to(anchor):local = current / output.relative_to(anchor)
    roots = []
    for value in previous['roots']:
        old = engine.filesystem_path(value)
        moved = current / old.relative_to(anchor) if anchor is not None and old.is_relative_to(anchor) else old
        roots.append(str(moved if moved.exists() else old))
    print('\nThe kit folder has moved.' if anchor is not None else '\nConfirm the saved locations for this kit.')
    print('  1. Use copied output here: ' + engine.subprocess_path(local))
    for old, new in zip(previous['roots'], roots):
        if engine.filesystem_path(old) != engine.filesystem_path(new):print('     Use copied media: ' + engine.subprocess_path(new))
    print('  2. Keep saved output and media: ' + engine.subprocess_path(previous['output']))
    print('  3. Choose another output folder')
    while True:
        choice = answer('Choose 1, 2 or 3: ')
        if choice not in ('1', '2', '3'):
            print('Choose one of the numbers above, or q to quit.');continue
        updated = {**previous, 'kit_root': str(root)}
        if choice == '1':
            updated.update(output=str(local), roots=roots, _relocation={
                'from': str(anchor) if anchor is not None else None, 'to': str(current),
                'old_output': previous['output'], 'new_output': str(local)})
        if choice == '3':
            value = answer('Output folder: ')
            if not value:continue
            updated['output'] = str(Path(value.strip('"')).expanduser().absolute())
        return updated


def saved_choice_problem(engine, definition, previous):
    if not previous:return None
    if any(not engine.filesystem_path(p).exists() for p in previous['roots']):return 'A saved media path is missing.'
    targets = list(definition['targets'].values());rules = previous['selection']
    if not {'platforms', 'regions', 'variants'} <= set(rules):return 'The saved build choices are incomplete.'
    try:
        selection = {'platforms': choices(None, {t['platform'] for t in targets}, 'platform', rules.get('platforms', 'all')),
            'regions': choices(None, {r for t in targets for r in t.get('regions', [t.get('region', 'all')])}, 'region', rules.get('regions', 'all')),
            'variants': choices(None, {t['variant'] for t in targets}, 'edition', rules.get('variants', 'all'))}
        if not any(engine.target_selected(selection, target) for target in targets):return 'The saved choices no longer match a build in this kit.'
    except ValueError:return 'A saved platform, region or edition is no longer available in this kit.'
    return None


def prepared_settings(previous):
    def selected(key):
        value = previous['selection'].get(key, 'all')
        return ','.join(value) if isinstance(value, list) else value
    return previous['roots'], selected('platforms'), selected('regions'), selected('variants'), previous['output']


def prepared_arguments(prepared):
    roots, platform, region, variant, output = prepared
    args = ['--platform', platform, '--region', region, '--variant', variant, '--out-dir', output]
    for path in roots:args += ['--input', path]
    return args


def guided(root):
    """Only the no-argument terminal branch calls this; explicit argv is legacy."""
    try:
        engine, definition, _ = load(root)
        config = root / '.build-state/settings.json'
        require(not config.parent.is_symlink() and not config.is_symlink(), 'Saved settings must not use symlinks')
        previous = read_guided_settings(engine.filesystem_path(config))
        manifest = root / 'manifest.json'
        info = json.loads(manifest.read_text()) if manifest.is_file() else {}
        title = info.get('title') or info.get('game') or {'cps-plus': 'CPS+', 'ng-plus': 'NG+'}.get(
            definition['project'], definition['project'].replace('-', ' ').title())
        print(f'\n{title} {definition["game_version"]}\nUse your own media. Enter q at any prompt to quit.')
        print('For command-line options, run apply.py --help.')
        prepared = None
        while True:
            print('\n1. Build or update\n2. Check requirements\n3. Change settings\n4. Exit')
            action = answer('Choose [1]: ') or '1'
            if action == '4':return 0
            if action not in ('1', '2', '3'):
                print('Choose 1, 2, 3 or 4.');continue
            if prepared is None:
                previous = confirm_locations(root, previous, engine)
                problem = saved_choice_problem(engine, definition, previous)
                if problem:print(problem + ' Please choose your settings again.')
                if previous and not problem and action != '3':prepared = prepared_settings(previous)
                else:prepared = configure_guided(root, definition, previous, edit_output=action == '3', show_path=engine.subprocess_path)
            elif action == '3':prepared = configure_guided(root, definition, previous, edit_output=True, show_path=engine.subprocess_path)
            roots, platform, region, variant, output = prepared
            labels = {'mame': 'MAME', 'hbmame': 'HBMAME', 'fbneo': 'FBNeo', 'mister': 'MiSTer',
                      'darksoft': 'Darksoft', 'us': 'USA', 'jp': 'Japan', 'eu': 'Europe', 'all': 'All'}
            display = lambda value: ', '.join(labels.get(v, v.replace('-', ' ').title()) for v in value.split(','))
            print(f'\nPlatform: {display(platform)}; region: {display(region)}')
            if variant != 'default':print('Edition: ' + display(variant))
            print('Output: ' + engine.subprocess_path(output))
            if action == '3':
                try:
                    with configuration_scope(engine, definition, root,
                            argument_parser().parse_args(prepared_arguments(prepared)), previous) as (_, previous, _):
                        pass
                    print('Settings saved.')
                except (OSError, ValueError) as exc:print('Settings were not saved: ' + str(exc))
                prepared = None
                continue
            if answer(('Build these outputs' if action == '1' else 'Check these requirements') + '? [Y/n]: ').lower() in ('n', 'no'):continue
            args = prepared_arguments(prepared)
            if action == '2':args.append('--check')
            result = main(args, root=root, previous=previous)
            if result == 0 and action == '1':
                print('\nOutput: ' + engine.subprocess_path(output))
                instructions = Path(output) / 'INSTALL.txt'
                if instructions.is_file():print('What to copy or run next: ' + engine.subprocess_path(instructions))
            return result
    except (Cancelled, EOFError):
        print('\nCancelled.');return 0
    except KeyboardInterrupt:
        print('\nCancelled.');return 130
    except Exception as exc:
        print('ERROR: ' + str(exc), file=sys.stderr);return 1


def argument_parser():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--rompath', action='append', type=Path, help='media folder, searched recursively (repeatable)')
    parser.add_argument('--input', '--disc', '--iso', '--romset', '--keys', action='append', type=Path,
                        help='specific owned file or media folder (repeatable; names may differ)')
    parser.add_argument('--platform', action='append', help='platform or all (repeatable)')
    parser.add_argument('--region', action='append', help='output region or all (repeatable)')
    parser.add_argument('--variant', action='append', help='edition/variant or all (repeatable)')
    parser.add_argument('--out-dir', type=Path, help='output folder; default: out beside this kit')
    parser.add_argument('--work', '--state-dir', dest='work', type=Path,
                        help='state/cache folder; retain it for incremental builds (default: .build-state beside this kit)')
    parser.add_argument('--tools-cache', type=Path, help='shared authenticated media/helper cache')
    parser.add_argument('--tools-bundle', type=Path, help='offline helper bundle')
    parser.add_argument('--python-wheels', type=Path, help='offline Python wheel bundle/folder')
    parser.add_argument('--offline', action='store_true', help='use cached/bundled dependencies only')
    parser.add_argument('--check', action='store_true', help='verify selected source identities and run kit preflight without exporting')
    parser.add_argument('--plan', action='store_true', help='list requirements without building or installing Python packages')
    parser.add_argument('--list', action='store_true', help='list this release and its targets without downloads')
    parser.add_argument('--json', action='store_true')
    parser.add_argument('--debug', action='store_true', help='show a diagnostic traceback')
    return parser


def managed_directory(engine, value, label):
    path = Path(value).expanduser()
    require(not path.is_symlink(), label + ' must not be a symlink')
    require(not path.exists() or path.is_dir(), label + ' must be a folder')
    return engine.filesystem_path(path)


def destination_home(engine, base, name):
    if name == 'root':return base
    parent = managed_directory(engine, base / 'destinations', 'Destination state folder')
    home = managed_directory(engine, parent / name, 'Destination state folder')
    require(parent == base / 'destinations' and home == parent / name,
            'Destination state folder escapes its recorded location')
    return home


def pending_export_outputs(engine, home):
    """Validate lifecycle records without performing recovery or cleanup."""
    outputs = []
    def contracts(value):
        require(isinstance(value, dict), 'Invalid interrupted export file records')
        for name, spec in value.items():engine.relative(name);engine.file_contract(spec, output=True)
    path = home / 'journal.json'
    if path.exists() or path.is_symlink():
        require(path.is_file() and not path.is_symlink(), 'Interrupted export record must be a regular file')
        journal = engine.read_json(path)
        require(isinstance(journal, dict) and journal.get('kind') in (None, 'files') and
                isinstance(journal.get('output'), str) and Path(journal['output']).is_absolute(), 'Invalid interrupted export record')
        engine.relative(journal.get('group'));engine.relative(journal.get('backup'))
        require(journal['backup'].startswith('.backup-') and '/' not in journal['backup'], 'Invalid interrupted export backup')
        require(not PurePosixPath(journal['group']).parts[0].startswith('.'), 'Invalid interrupted export group')
        if journal.get('kind') == 'files':
            suffix = journal['backup'][len('.backup-'):]
            require(len(suffix) == 32 and set(suffix) <= set('0123456789abcdef'), 'Invalid interrupted export backup')
        # The legacy whole-group format also accepts .backup-fixture, as bound
        # by test_arcadepatches.test_journal_rolls_back_interrupted_group.
        old = journal.get('previous')
        require(isinstance(old, dict) and isinstance(old.get('targets'), dict) and isinstance(old.get('groups'), dict),
                'Invalid interrupted export ownership records')
        for group, files in old['groups'].items():engine.relative(group);contracts(files)
        for target in old['targets'].values():
            stamp = target.get('identity') if isinstance(target, dict) else None
            require(isinstance(stamp, str) and len(stamp) == 64 and set(stamp) <= set('0123456789abcdef'),
                    'Invalid interrupted export target')
            engine.relative(target.get('group'));contracts(target.get('outputs'))
        if journal.get('kind') == 'files':contracts(journal.get('before'));contracts(journal.get('after'))
        else:
            require(type(journal.get('had_previous')) is bool, 'Invalid interrupted export state')
            if 'candidate' in journal:contracts(journal['candidate'])
        outputs.append(journal['output'])
    path = home / 'cleanup.json'
    if path.exists() or path.is_symlink():
        require(path.is_file() and not path.is_symlink(), 'Export cleanup record must be a regular file')
        ledger = engine.read_json(path)
        require(isinstance(ledger, dict) and ledger.get('schema') == 1 and isinstance(ledger.get('backups'), dict),
                'Invalid export cleanup records')
        for field, prefix in (('backups', '.backup-'), ('staging', '.staging-')):
            records = ledger.get(field, {})
            require(isinstance(records, dict), 'Invalid export cleanup records')
            for name, entry in records.items():
                require(isinstance(name, str) and name.startswith(prefix) and len(name) == len(prefix) + 32
                        and set(name[len(prefix):]) <= set('0123456789abcdef'), 'Invalid export cleanup folder')
                require(isinstance(entry, dict) and isinstance(entry.get('output'), str)
                        and Path(entry['output']).is_absolute(), 'Invalid export cleanup owner')
                if field == 'backups':contracts(entry.get('files'))
                else:
                    require(isinstance(entry.get('files'), list), 'Invalid staging cleanup files')
                    for filename in entry['files']:engine.relative(filename)
                outputs.append(entry['output'])
    return outputs


def guard_pending_exports(engine, base, root, entries, settings, previous, key):
    """Do not bypass recovery/cleanup authority by selecting another home."""
    registered = {entry['id'] for entry in entries if entry['id'] != 'root'}
    parent = base / 'destinations'
    if parent.exists():
        require(managed_directory(engine, parent, 'Destination state folder') == parent,
                'Destination state folder escapes its recorded location')
        children = list(parent.iterdir());require(len(children) <= 256, 'Too many destination state folders')
        for child in children:
            require(not child.is_symlink(), 'Destination state folder must not use a symlink')
            if child.is_dir() and child.name not in registered:
                require(child.resolve().parent == parent, 'Destination state folder escapes its recorded location')
                require(not pending_export_outputs(engine, child),
                        'An unregistered interrupted export needs its original output records')
    for entry in entries:
        for output in pending_export_outputs(engine, destination_home(engine, base, entry['id'])):
            origin = entry.get('kit_root')
            same_kit = key(origin) == key(root) if origin else Path(key(output)).is_relative_to(Path(key(root)))
            require(same_kit and not previous.get('_relocation'),
                    'Recover the interrupted export or cleanup in its original kit before moving or copying its build state')
            require(entry['output'] is not None and key(entry['output']) == key(output) == key(settings['output']),
                    'Recover the interrupted export or cleanup at its original destination before changing output folders')


def destination_scope(engine, base, root, settings, previous):
    """Keep receipt ownership bound to a destination, independent of UI settings."""
    path = base / 'outputs.json'
    require(not path.is_symlink(), 'Output location records must not use a symlink')
    key = lambda value: os.path.normcase(os.path.normpath(engine.subprocess_path(value)))
    if path.exists():
        try:registry = engine.read_json(path)
        except (OSError, ValueError) as exc:
            raise ValueError('Output location records could not be read; existing receipts were preserved') from exc
        require(isinstance(registry, dict) and registry.get('schema') == 1 and
                isinstance(registry.get('destinations'), list), 'Invalid output location records; existing receipts were preserved')
        entries = registry['destinations']
    else:
        entries = []
        if (base / 'installed.json').exists() or pending_export_outputs(engine, base):
            # Seed old receipt ownership from the *original on-disk* settings,
            # before relocation or a user-selected replacement output changes it.
            try:old = json.loads((base / 'settings.json').read_text())
            except (OSError, ValueError):old = {}
            output = old.get('output') if isinstance(old, dict) else None
            anchor = old.get('kit_root') if isinstance(old, dict) else None
            if not isinstance(output, str) or not Path(output).is_absolute():output = None
            if not isinstance(anchor, str) or not Path(anchor).is_absolute():anchor = None
            entries.append({'id': 'root', 'output': output, 'kit_root': anchor})
    require(len(entries) <= 256, 'Too many output location records')
    ids, outputs = set(), set()
    for entry in entries:
        require(isinstance(entry, dict), 'Invalid output location record')
        name = entry.get('id')
        require(isinstance(name, str) and (name == 'root' or len(name) == 64 and set(name) <= set('0123456789abcdef'))
                and name not in ids, 'Invalid or duplicate output receipt identifier')
        ids.add(name)
        value, anchor = entry.get('output'), entry.get('kit_root')
        require(value is None and name == 'root' or isinstance(value, str) and Path(value).is_absolute(), 'Invalid saved output location')
        require(anchor is None or isinstance(anchor, str) and Path(anchor).is_absolute(), 'Invalid saved kit location')
        if value is not None:
            require(key(value) not in outputs, 'Duplicate output location record');outputs.add(key(value))
    require(not ((base / 'installed.json').exists() or pending_export_outputs(engine, base))
            or 'root' in ids, 'Original output receipt binding is missing')
    guard_pending_exports(engine, base, root, entries, settings, previous, key)
    moved = previous.get('_relocation')
    if moved:
        before = Path(engine.subprocess_path(moved['from'])) if moved.get('from') else None
        for entry in entries:
            value = entry['output']
            if value is None:continue
            original = Path(engine.subprocess_path(value))
            if before is not None and original.is_relative_to(before):
                entry.update(output=str(Path(moved['to']) / original.relative_to(before)), kit_root=str(root))
            elif before is None and key(value) == key(moved['old_output']):
                entry.update(output=moved['new_output'], kit_root=str(root))
    rebound = [key(e['output']) for e in entries if e['output'] is not None]
    require(len(rebound) == len(set(rebound)), 'Copied output locations conflict with another saved destination')
    output_key = key(settings['output'])
    selected = next((e for e in entries if e['output'] is not None and key(e['output']) == output_key), None)
    new_destination = selected is None
    if selected is None:
        require(len(entries) < 256, 'Too many output location records')
        name = 'root' if not entries else engine.identity(output_key)
        require(name not in ids, 'Output receipt identifier conflict')
        selected = {'id': name, 'output': settings['output'], 'kit_root': str(root)}
        entries.append(selected)
    # Check the whole proposed registry, including destinations rebased by a
    # copied-kit move. Checking only newly added entries misses move conflicts.
    paths = [Path(key(e['output'])) for e in entries if e['output'] is not None]
    for i, first in enumerate(paths):
        require(all(not first.is_relative_to(other) and not other.is_relative_to(first) for other in paths[i + 1:]),
                'Output folders managed by this kit must not contain one another')
    home = destination_home(engine, base, selected['id'])
    if selected['id'] != 'root':
        require(not new_destination or not (home / 'installed.json').exists(),
                'Unregistered destination receipts exist; restore the output location records')
    engine.validate_settings(settings, home)
    home.mkdir(parents=True, exist_ok=True)
    engine.write_json(path, {'schema': 1, 'destinations': entries})
    return home


@contextlib.contextmanager
def configuration_scope(engine, definition, root, args, previous=None):
    base = managed_directory(engine, args.work or root / '.build-state', 'State folder')
    base.mkdir(parents=True, exist_ok=True)
    # Serialize configuration/registry changes as well as the selected build.
    # The engine retains its own worker/export locks inside each destination.
    with engine.native_lock(base / 'frontend.lock'):
        home, settings = save_configuration(engine, definition, root, args, previous)
        yield home, settings, base


def save_configuration(engine, definition, root, args, previous=None):
    home = managed_directory(engine, args.work or root / '.build-state', 'State folder')
    home.mkdir(parents=True, exist_ok=True)
    config = home / 'settings.json'
    require(not config.is_symlink(), 'Saved settings must not use a symlink')
    if previous is None:previous = engine.read_json(config) if config.exists() else {}
    roots = args.rompath or []
    roots += args.input or []
    if not roots:
        roots = previous.get('roots') or [p for p in (root / 'roms', root / 'inputs') if p.is_dir()]
    require(roots, 'Supply --rompath MEDIA_FOLDER or --input FILE. Use --list to see available targets.')
    rules = previous.get('selection', {})
    targets = definition['targets']
    output = managed_directory(engine, args.out_dir or previous.get('output', root / 'out'), 'Output')
    settings = {'schema': 1, 'preserve_unowned': True, 'kit_root': str(root),
                'roots': list(dict.fromkeys(str(Path(p).expanduser().resolve()) for p in roots)),
                'output': str(output.resolve()),
                'selection': {'projects': [definition['project']], 'include_future': False,
                    'platforms': choices(args.platform, {t['platform'] for t in targets.values()}, 'platform', rules.get('platforms', 'all')),
                    'variants': choices(args.variant, {t['variant'] for t in targets.values()}, 'variant', rules.get('variants', 'all')),
                    'regions': choices(args.region, {r for t in targets.values() for r in t.get('regions', [t.get('region', 'all')])}, 'region', rules.get('regions', 'all'))}}
    require(any(engine.target_selected(settings['selection'], t) for t in targets.values()), 'No target matches that platform/region/variant selection')
    engine.validate_settings(settings, home)
    if args.tools_cache:settings['tools_cache'] = str(args.tools_cache.expanduser().absolute())
    elif previous.get('tools_cache'):settings['tools_cache'] = previous['tools_cache']
    if settings.get('tools_cache'):
        cache = managed_directory(engine, settings['tools_cache'], 'Helper cache')
        settings['tools_cache'] = str(cache)
        require(not cache.is_relative_to(engine.filesystem_path(output)) and not engine.filesystem_path(output).is_relative_to(cache),
                'Helper cache and output overlap')
        for source in settings['roots']:
            source = engine.filesystem_path(source)
            require(not cache.is_relative_to(source) and not source.is_relative_to(cache), 'Helper cache and source overlap')
    active = destination_scope(engine, home, root, settings, previous)
    if active != home:
        require(not (active / 'settings.json').is_symlink(), 'Saved settings must not use a symlink')
        engine.write_json(active / 'settings.json', settings)
    # home already uses the canonical filesystem namespace. Keep the filename
    # unresolved so the atomic replacement cannot follow a settings-file link.
    engine.write_json(config, settings)
    return active, settings


def mirror_reports(home, base):
    for name in ('last-report.json', 'last-report.txt'):
        source, destination = home / name, base / name
        if not source.is_file():continue
        require(not source.is_symlink() and not destination.is_symlink(), 'Report must not use a symlink')
        temporary = None
        try:
            with tempfile.NamedTemporaryFile(prefix='.report-', dir=base, delete=False) as stream:
                temporary = Path(stream.name);stream.write(source.read_bytes())
            info = source.stat()
            os.utime(temporary, ns=(info.st_atime_ns, info.st_mtime_ns))
            os.replace(temporary, destination)
        finally:
            if temporary is not None:temporary.unlink(missing_ok=True)


def main(argv=None, root=None, *, previous=None):
    args = argument_parser().parse_args(argv)
    root = (root or Path(__file__).resolve().parent.parent).resolve()
    try:
        engine, definition, metadata = load(root)
        if args.list:
            if args.json:print(json.dumps(definition, indent=2))
            else:
                print(f"{definition['project']} {definition['game_version']} / kit revision {definition['kit_revision']}")
                for name, target in definition['targets'].items():
                    regions = target.get('regions', [target.get('region', 'all')])
                    print(f"  {name}: {target['platform']}, region {','.join(regions)}, variant {target['variant']}")
            return 0
        with configuration_scope(engine, definition, root, args, previous) as (home, settings, base):
            if args.tools_cache:os.environ['CPSPLUS_SWITCH_TOOLS_CACHE'] = str(args.tools_cache.expanduser().resolve())
            if args.tools_bundle:os.environ['CPSPLUS_SWITCH_TOOLS_BUNDLE'] = str(args.tools_bundle.expanduser().resolve())
            if args.python_wheels:os.environ['ARCADE_PYTHON_WHEELS'] = str(args.python_wheels.expanduser().resolve())
            archive = cache_payload(root, metadata, home, engine.filesystem_path)
            model = catalog(engine, definition, archive, metadata['discovery'])
            if home != base and (base / 'cache/artifacts').is_dir():
                cache_bundles([base / 'cache/artifacts'], model['artifacts'], home, engine.filesystem_path)
            cache_bundles([args.tools_bundle, args.python_wheels], model['artifacts'], home, engine.filesystem_path)
            command = ['check' if args.check else 'plan' if args.plan else 'update', '--home', str(home)]
            if args.check:command.append('--verify-sources')
            if args.offline:command.append('--offline')
            if args.json:command.append('--json')
            result = engine.main(command, local_catalog=model)
            if home != base:mirror_reports(home, base)
            return result
    except Exception as exc:
        if args.debug:raise
        print('ERROR: ' + str(exc), file=sys.stderr)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
