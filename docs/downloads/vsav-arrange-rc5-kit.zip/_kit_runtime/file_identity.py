"""Portable metadata stamps; Windows ctime is creation time, not change time."""
import os
from pathlib import Path


WINDOWS = os.name == 'nt'


def documentation_output(name, contract):
    """Human-readable exported support; never ROMs, packs, cores or launchers."""
    if name.startswith('mister/'):
        name = name[len('mister/'):]
    path = Path(name)
    if 'sha256' not in contract or path.suffix.lower() not in ('.txt', '.md', '.rst'):
        return False
    return (name.startswith(('support/', '_Arcade/cores/licenses/')) or
            name in ('README.txt', 'readme.txt', 'README.md', 'games/CPS+/README.txt', 'games/NG+/README.txt'))


def file_stamp(path, *, file_stat=None):
    path = Path(path)
    # DirEntry.stat() intentionally omits file IDs on Windows. Its cached
    # result cannot be compared with Path.stat() at a later boundary.
    value = path.stat() if WINDOWS or file_stat is None else file_stat
    # None explicitly means metadata cannot certify an unchanged file. Even
    # FILE_BASIC_INFO.ChangeTime mirrors restored mtime on some shared drives.
    # Consumers must recheck bytes rather than cache an authoritative result.
    change = None if WINDOWS else value.st_ctime_ns
    return (value.st_dev, value.st_ino, value.st_size, value.st_mtime_ns, change)
