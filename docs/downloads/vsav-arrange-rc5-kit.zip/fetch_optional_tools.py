#!/usr/bin/env python3
"""Obtain content-pinned Switch helpers without a compiler (standard library only)."""
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import platform
import shutil
import stat
import sys
import tempfile
import urllib.parse
import urllib.request
import zipfile

HERE = Path(__file__).resolve().parent
MAX_ARCHIVE = 64 * 1024 * 1024
MAX_EXPANDED = 128 * 1024 * 1024


class SetupError(RuntimeError):
    pass


def require(condition, message):
    if not condition:
        raise SetupError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def host_id():
    machine = platform.machine().lower()
    arch = {'amd64':'x86_64', 'x64':'x86_64', 'aarch64':'arm64'}.get(machine,machine)
    system = {'Darwin':'macos','Windows':'windows','Linux':'linux'}.get(platform.system())
    require(system and arch in ('arm64','x86_64'), 'Unsupported helper host: '+platform.platform())
    return system+'-'+arch


def default_cache():
    if os.name == 'nt':
        base = Path(os.environ.get('LOCALAPPDATA',Path.home()/'AppData/Local'))
    elif platform.system() == 'Darwin':
        base = Path.home()/'Library/Caches'
    else:
        base = Path(os.environ.get('XDG_CACHE_HOME',Path.home()/'.cache'))
    return base/'capcom/switch-helpers'




def safe_name(name):
    p = PurePosixPath(name)
    require(name and '\\' not in name and ':' not in name and not p.is_absolute()
            and all(x not in ('','.','..') for x in name.split('/')), 'Unsafe helper member: '+name)
    return name


def inventory(data, record):
    require(len(data) == record['bytes'] and sha(data) == record['sha256'],
            'Helper archive hash/size mismatch; nothing will be executed')
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        infos = z.infolist()
        require(len(infos) == len({i.filename for i in infos}), 'Duplicate helper member')
        require(sum(i.file_size for i in infos) <= MAX_EXPANDED, 'Helper archive is too large')
        files = {}
        for info in infos:
            safe_name(info.filename)
            require(not info.is_dir() and not stat.S_ISLNK(info.external_attr >> 16),
                    'Invalid helper member type')
            files[info.filename] = z.read(info)
    require(set(files) == set(record['files']), 'Helper archive inventory differs')
    for name,data in files.items():
        require(sha(data) == record['files'][name], 'Helper member hash mismatch: '+name)
    return files


def checked_cache(root, record):
    expected = set(record['files'])
    actual = {p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()}
    require(actual == expected and not root.is_symlink(),
            'Helper cache inventory changed; remove this cache directory: '+str(root))
    for name,digest in record['files'].items():
        p = root/safe_name(name)
        chain = [p]
        while chain[-1] != root:
            chain.append(chain[-1].parent)
        require(not any(q.is_symlink() for q in chain)
                and p.is_file() and sha(p.read_bytes()) == digest,
                'Helper cache changed; remove this cache directory: '+str(root))
    return {key:root/safe_name(name) for key,name in record['executables'].items()}


class HTTPSOnlyRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        require(urllib.parse.urlparse(newurl).scheme == 'https', 'Insecure helper redirect')
        return super().redirect_request(req, fp, code, msg, headers, newurl)


def download(url, size):
    require(urllib.parse.urlparse(url).scheme == 'https' and 0 < size <= MAX_ARCHIVE,
            'Helpers require HTTPS and a bounded pinned size')
    with urllib.request.build_opener(HTTPSOnlyRedirect()).open(url, timeout=60) as response:
        require(urllib.parse.urlparse(response.geturl()).scheme == 'https', 'Insecure helper redirect')
        data = response.read(size+1)
    require(len(data) == size, 'Helper download size differs')
    return data


def bundle_archive(path, record):
    path = Path(path).expanduser()
    if path.is_dir():
        path = path/record['filename']
    require(path.is_file(), 'Offline tools bundle is missing: '+str(path))
    require(path.stat().st_size <= 256*1024*1024, 'Offline tools bundle is too large')
    data = path.read_bytes()
    # A per-host archive, or the all-host offline archive containing it.
    if sha(data) == record['sha256']:
        return data
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        matches = [i for i in z.infolist() if i.filename == record['filename']]
        require(len(matches) == 1 and matches[0].file_size == record['bytes'],
                'Offline bundle lacks the required pinned host archive: '+record['filename'])
        require(matches[0].file_size <= MAX_ARCHIVE, 'Offline helper archive is too large')
        return z.read(matches[0])




def obtain(record, host, *, label):
    """Install one independently pinned tool archive using the common controls."""
    if os.name == 'nt' and record.get('minimum_windows_build'):
        require(sys.getwindowsversion().build >= record['minimum_windows_build'],
                'This helper bundle requires Windows 11 x64 emulation')
    require(record['executables'] and set(record['executables'].values()) <= set(record['files']),
            'Incomplete helper executables')
    cache = Path(os.environ.get('CPSPLUS_SWITCH_TOOLS_CACHE') or default_cache()).expanduser()
    target = cache/host/record['sha256']
    if target.exists():
        return checked_cache(target,record)
    bundle = os.environ.get('CPSPLUS_SWITCH_TOOLS_BUNDLE')
    offline = os.environ.get('CPSPLUS_SWITCH_TOOLS_OFFLINE','').lower() in ('1','true','yes')
    require(bundle or not offline, 'Required helpers are not cached. Supply --tools-bundle for offline use.')
    data = bundle_archive(bundle,record) if bundle else download(record['url'],record['bytes'])
    files = inventory(data,record)
    target.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='.helpers-',dir=target.parent) as temporary:
        stage = Path(temporary)/'tools';stage.mkdir()
        for name,data in files.items():
            path = stage/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(data)
        for name in record['executables'].values():
            (stage/name).chmod(0o755)
        try:
            stage.rename(target)
        except OSError:
            # Another verified installer may have completed the same cache.
            if not target.is_dir():
                raise
    tools = checked_cache(target,record)
    print('Ready: verified prebuilt '+label+' ('+host+')',flush=True)
    return tools

"""Authenticated optional media/disc helpers; never compile on recipient hosts."""
import os
import json
from pathlib import Path
import shutil


from tool_controls import executable_path

HERE = Path(__file__).resolve().parent
COMPONENTS = {'chdman': 'chdman', 'sevenzip': 'sevenzip'}
EXPECTED = {component: {tool for tool, owner in COMPONENTS.items() if owner == component}
            for component in set(COMPONENTS.values())}


def _resolve(tool, *, manifest=None, host=None):
    """Resolve only the requested component, with the shared cache/offline controls.

    A kit supplies its own trusted lock. Offline bundle metadata cannot change
    the lock or promote an unqualified producer. Explicit environment overrides
    remain the user's responsibility and never populate the verified cache.
    """
    require(tool in COMPONENTS, 'Unknown optional helper: '+tool)
    key = 'CPSPLUS_'+tool.upper()
    override = os.environ.get(key)
    if override:
        if tool in ('chdman','sevenzip'):
            names = ('chdman.exe','chdman') if tool == 'chdman' else ('7zz','7z','7za','7zr','7z.exe','7za.exe','7zr.exe')
            return executable_path(override,names,label=key)
        path = Path(override).expanduser()
        found = str(path.absolute()) if path.is_file() else shutil.which(override)
        require(found, key+' does not name a file: '+override)
        return Path(found)
    default = HERE/'optional_helpers.json'
    if not default.is_file():
        default = HERE.parent/'manifests/optional_helpers_v1.json'
    lock = json.loads(Path(manifest or default).read_text())
    require(lock.get('schema') == 1 and lock.get('components'), 'Invalid optional helper manifest')
    if manifest is None:
        require(lock.get('status') == 'qualified', 'Optional helpers have not completed qualification')
    component = COMPONENTS[tool]
    require(component in lock['components'], 'No qualified optional component: '+component)
    host = host or host_id()
    platforms = lock['components'][component]['platforms']
    require(host in platforms, 'No qualified '+component+' helper for '+host)
    record = platforms[host]
    require(set(record['executables']) == EXPECTED[component],
                   'Invalid optional helper record: '+component)
    return obtain(record, host, label=component)[tool]


def resolve(tool, *, manifest=None, host=None):
    try:
        return _resolve(tool, manifest=manifest, host=host)
    except SetupError as exc:
        raise ValueError(str(exc)) from exc


def disc_tool(tool, *, fetch=True):
    """Retain installed disc utilities, fetching a pinned fallback only on use.

    Discovery-only callers use fetch=False. MIDI/library helpers always use
    resolve() directly and cannot silently pick a different installed build.
    """
    if tool not in ('chdman', 'sevenzip'):
        raise ValueError('Unknown disc helper: '+tool)
    if os.environ.get('CPSPLUS_'+tool.upper()):
        return str(resolve(tool))
    names = ('chdman',) if tool == 'chdman' else ('7zz', '7z', '7za', '7zr')
    for name in names:
        found = shutil.which(name)
        if found:
            return found
    if tool == 'sevenzip' and os.name == 'nt':
        for key in ('ProgramW6432', 'ProgramFiles', 'ProgramFiles(x86)'):
            root = os.environ.get(key)
            if root and (Path(root)/'7-Zip/7z.exe').is_file():
                return str(Path(root)/'7-Zip/7z.exe')
        try:
            import winreg
            for view in (winreg.KEY_WOW64_64KEY, winreg.KEY_WOW64_32KEY):
                try:
                    with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r'SOFTWARE\7-Zip',
                                        0, winreg.KEY_READ | view) as key:
                        for field in ('Path64', 'Path'):
                            try:
                                path = Path(winreg.QueryValueEx(key, field)[0])/'7z.exe'
                                if path.is_file():return str(path)
                            except OSError:
                                pass
                except OSError:
                    pass
        except ImportError:
            pass
    return str(resolve(tool)) if fetch else None
