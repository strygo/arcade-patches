BUILD OR UPDATE

Run python apply.py in a terminal (Windows: py -3.13 apply.py).
Choose Build or update, then select your media and available outputs.
Settings are remembered; intact outputs can be reused safely.
Check requirements is optional. Change settings saves without building.
Enter q at any prompt to quit. Run apply.py --help for the existing
command-line options and specialized workflows described below.

ROM INPUT UPDATE

Merged, split, complete ZIP/7z archives and extracted ROM folders are accepted.
Use --rompath DIR (repeatable) to search a collection, or keep the existing archive argument.
Names may differ; required source contents are verified by size and strong hashes.
Use --check to verify arcade build inputs before reconstruction.
QSound is optional for game builds. Valid embedded firmware is preserved in complete game outputs.
Use --include-devices on CPS-2 kits to require and include firmware from separate archives.
Compact HBMAME outputs retain their stock-game and device dependencies.
7z input requires an installed 7-Zip executable; ZIP needs no extra archive software.
Original archives are never modified by collection discovery.

Darkstalkers: The Night Warriors · English restoration
======================================================

Version:  rc1 (2026-10-06)
Target:   MAME set 'vampj' (Vampire: The Night Warriors (Japan 940705))
Hardware: Capcom CPS-2
Patch by: Steve Gordon (https://x.com/strygo)
Website:  https://arcadepatches.com/dstlk-restoration/

ABOUT THIS PROJECT

The original Japanese Vampire gives each fighter a pool of win quotes, and
offers move advice after a loss. The USA version uses one English win quote
per fighter and removes the advice.

The English Restoration brings back the Japanese quote pools and bordered
result panel, the complete ending dialogue, and all 85 continue tips,
translated from the Japanese.

The voices the USA version muted are back: Morrigan’s alternate victory,
Vector Drain and throw, and Felicia’s Rolling Buckler, Dancing Flash and
special damage reaction. As in the USA release, Rikuo’s crouching heavy punch
can be blocked with a crouching guard.

It keeps the ten playable fighters and the Western character names, and adds
Free Play to the operator menu. It runs in MAME and HBMAME and on MiSTer.

This is a release candidate.

WHAT'S CHANGED

  - Japanese win-quote pools in English, with the Japanese result-panel border
  - Complete Japanese ending dialogue in English, with the original scene
    timing
  - All 85 Japanese continue tips in English, including their arcade move
    commands
  - Morrigan’s alternate victory, Vector Drain and throw voices, and Felicia’s
    Rolling Buckler, Dancing Flash and special damage voices
  - Rikuo’s crouching heavy punch can be blocked with a crouching guard, as in
    the USA release
  - Western character names, and Free Play in the operator menu

HOW TO APPLY (recommended)

    python3 apply.py /path/to/vampj.zip --out-dir out

This checks every file against the original, applies the patches, checks
the result, and writes everything you need for each platform:

  MAME:                     out/mame/vampj.zip
  HBMAME:                   out/hbmame/vamprest.zip
  MiSTer:                   out/mister/_Arcade/_Arcade Patches/_Restorations/Darkstalkers The Night Warriors (USA) [English Restoration].mra

Merged, split and complete sets work, including nested or renamed ROMs.
Use --rompath DIR (repeatable) to search a collection instead of naming the
zip, and --check to check inputs before building. ZIPs and extracted folders
need no extra software; 7z archives use installed 7-Zip or a verified download.
Keep your unmodified qsound.zip in the emulator's ROM path.
Device firmware is not copied into the game archives.

MAME: put vampj.zip from out/mame/ ahead of the stock set in your MAME
rompath.
MAME's game menu won't start a set with patched ROMs, so start it from the
command line: mame vampj. MAME shows checksum warnings for the patched
ROMs; that's expected and the game runs normally.
To start it from a menu, use the HBMAME build.
Keep your unmodified qsound.zip in MAME's ROM path.

HBMAME: this restoration is an official HBMAME set (vamprest),
so full HBMAME collections may already carry it.
Put vamprest.zip and qsound.zip in HBMAME's roms/ folder;
it holds the complete set.

MiSTer: copy the _Arcade folder from out/mister/ to the root of your SD card
and keep the stock, unmodified romset at games/mame/vampj.zip (split MAME
sets also need qsound.zip). The MRA applies the restoration in memory as the
game loads, so nothing on the card is modified. You need Jotego's jtcps2
core, which update_all installs. The MRAs are also a separate download.

HOW TO APPLY (any IPS patcher)

Extract vampj.zip, apply each file in ips/ to the ROM file of the
same name (Flips, Lunar IPS, or any IPS tool), then re-zip everything
as vampj.zip.

CHANGED FILES

    vam.13m  (4.0 MB)  CRC32 c51baf99 -> 2c48a876
    vam.15m  (4.0 MB)  CRC32 3ce83c77 -> 6465e083
    vam.17m  (4.0 MB)  CRC32 4f2408e0 -> c613f6eb
    vam.19m  (4.0 MB)  CRC32 9ff60250 -> 29424b8d
    vamj.03a  (512 KB)  CRC32 f55d3722 -> f36d0886
    vamj.04b  (512 KB)  CRC32 4d9c43c4 -> 48f49597
    vamj.09a  (512 KB)  CRC32 fc0a4aac -> 744507a9

All other files in the set are unmodified.

LEGAL

This is a free, unofficial fan patch. It is not affiliated with or endorsed
by Capcom. All game titles, characters, and artwork remain the property of
their respective owners. You must own the game to use this patch. Do not
sell this patch or distribute it applied to a ROM image.

DARKSOFT OUTPUT

Use --platform darksoft --out-dir out, or --platform all.
Copy the game folder from out/darksoft/games to the card games folder.
Expanded hardware and streamed audio are not supported.

PYTHON PACKAGES

When a build needs NumPy or Pillow and it is not already installed, the kit
downloads its pinned prebuilt package from PyPI into your user cache. No pip,
compiler, administrator rights or changes to system Python are needed.
Patch-only builds and --help do not download Python packages.

Automatic package installation is qualified for CPython 3.12 on Apple Silicon
Macs and CPython 3.13 x64 on Windows (including x64 Python on Windows ARM).
Other interpreters can still use manually installed NumPy/Pillow. There is
no automatic source compilation or selection of an unqualified package.

Cache: ~/Library/Caches/ArcadePatches/python on Mac, or
%LOCALAPPDATA%/ArcadePatches/python on Windows. You can choose another location
with --python-cache PATH (or ARCADE_PYTHON_CACHE). --tools-cache PATH places
the Python cache under PATH/python unless --python-cache is also supplied.
You may delete this cache when no installer is running; it is recreated later.

Offline: add --python-wheels PATH --offline. PATH may name the matching
python-wheels-v1-*.zip, a folder of unzipped wheels, or a folder containing
the wheel ZIPs. The existing wheel bundles work without modification.
You can also supply --tools-bundle for the other helpers in the same command.
ARCADE_PYTHON_WHEELS is the equivalent environment variable. A warm cache
works offline without a bundle. --offline prohibits package downloads too.
Every wheel is checked against the kit's hash; cached extracted files are
verified before use. Existing manually installed packages remain supported.

The installer and its Python subprocesses share the cache. Your shell profile,
global site-packages and unrelated Python applications are not changed.

FBNEO OUTPUT

Use --platform fbneo --out-dir out, or --platform all.
The default all-platform build also includes these complete game sets:
  default: out/fbneo/vamprest.zip
The ZIPs preserve the existing FBNeo ROM member names and contain complete game sets.
Copy the ZIPs to your FBNeo ROM folder without renaming their members.
Use an FBNeo version with definitions matching this game release.
Older definitions may reject these checksums.
