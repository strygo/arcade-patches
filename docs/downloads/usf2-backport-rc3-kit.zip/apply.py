#!/usr/bin/env python3
"""Reconstruct the selected USF2 adaptation from arcade inputs and owned NSP/XCI files."""
import argparse
import importlib.util
import json
import os
from pathlib import Path
import shutil
import tempfile
import zipfile
from nsp import file_sha, unlock
from payload import decode, post_patch, require, sha
import rom_sources
from policy import platforms_for
import stock_mame

HERE = Path(__file__).resolve().parent


def check_music_dependencies(selected, platforms, check=False):
    if check or 'mister' not in platforms or not any(n.endswith('8') for n in selected):
        return
    ffmpeg = os.environ.get('CPSPLUS_FFMPEG') or 'ffmpeg'
    require(shutil.which(ffmpeg),
            'MiSTer music requires FFmpeg. Add ffmpeg.exe (Windows) or ffmpeg to PATH, '
            'or set CPSPLUS_FFMPEG to the executable path. See README.txt.')
    require(importlib.util.find_spec('numpy') is not None,
            'MiSTer music requires NumPy in this Python installation. '
            'Run python3 -m pip install numpy (Windows: py -3 -m pip install numpy).')


def read_manifest():
    manifest = json.loads((HERE/'kit.json').read_text())
    require(manifest['schema'] == 1, 'Unsupported reconstruction kit')
    for relative, expected in manifest['files'].items():
        path = HERE/relative
        require(path.resolve().is_relative_to(HERE) and path.is_file() and file_sha(path) == expected,
                'Kit file missing or changed: ' + relative)
    return manifest


def write_zip(path, files):
    path.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(path, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, data in sorted(files.items()):
            entry = zipfile.ZipInfo(name, (1980, 1, 1, 0, 0, 0))
            entry.compress_type = zipfile.ZIP_DEFLATED; entry.create_system = 3
            entry.external_attr = 0o100644 << 16
            archive.writestr(entry, data, compresslevel=9)


def reconstruct(record, inputs, key):
    result = {}
    for name, row in record['members'].items():
        require(Path(name).name == name and '\\' not in name, 'Invalid output member')
        source = inputs[row['source']] if row['source'] else b''
        data = decode((HERE/row['payload']['file']).read_bytes(), row['payload'], source, key) if row.get('payload') else source
        data = post_patch(data, row.get('post_patch', []))
        require(len(data) == row['size'] and sha(data) == row['sha256'], 'Incorrect reconstructed member: ' + name)
        result[name] = data
    return result


def build(args):
    kit = read_manifest()
    platforms = ('mame','hbmame','mister','darksoft') if args.platform == 'all' else (args.platform,)
    selected = {n:r for n,r in kit['profiles'].items() if
                (args.region == 'all' or r['region'] == args.region) and
                (args.audio == 'all' or n.endswith(args.audio)) and platforms_for(n,platforms)}
    require(selected, 'No compatible outputs: MAME uses --audio 4; Darksoft, MiSTer and HBMAME '
            'use --audio 8. Use --audio all to include both capacities.')
    check_music_dependencies(selected, platforms, args.check)
    paths = rom_sources.search_paths(rompaths=args.rompath, kit=HERE)
    resolver = rom_sources.Resolver(paths, hints=('ssf2xj','ssf2t','qsound'),
                                   exclude=[args.out_dir] if args.out_dir else [], progress=print)
    names = {row['source'] for record in selected.values() for row in record['members'].values() if row['source']}
    inputs = resolver.resolve([r for r in kit['arcade_inputs'] if r['name'] in names])
    supplied = dict(us=args.nsp_us, jp=args.nsp_jp)
    regions = {r['region'] for r in selected.values()}
    require(args.keys and all(supplied[r] for r in regions), 'Supply --keys and a matching --source-us/--source-jp NSP or XCI for each selected region')
    require(args.work, 'Supply a disposable --work directory for the pinned source tools')
    work = args.work.resolve(); work.mkdir(parents=True, exist_ok=True)
    keys = {r:unlock(supplied[r], args.keys, kit['nsp'][r], work/'source') for r in sorted(regions)}
    if args.check:
        print('PASS complete arcade and decrypted NSP/XCI preflight'); return
    require(args.out_dir and not args.out_dir.exists(), 'Choose a fresh --out-dir')
    args.out_dir.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='.usf2-', dir=args.out_dir.parent) as temp:
        stage = Path(temp)/'output'; stage.mkdir()
        archives = {}
        for name, record in sorted(selected.items()):
            members = reconstruct(record, inputs, keys[record['region']])
            native = stage/'native'/(name+'.zip'); write_zip(native, members)
            from verify import verify_archive
            verify_archive(native, record)
            archives[name] = members
            for platform in platforms_for(name,platforms):
                if platform == 'darksoft':
                    from darksoft import tree, native_menu
                    stock_name, packed = stock_mame.repack(members, record['region'])
                    rom_sources.publish_tree(stage, tree(packed, stock_name,
                        folder='usf2_' + record['region'], menu=native_menu('usf2-backport', record['region'])))
                    # DSP firmware is not flashed; retain it only for portable
                    # reconstruction verification outside the card's games tree.
                    firmware = stage/'darksoft/verification/dl-1425.bin'
                    firmware.parent.mkdir(parents=True, exist_ok=True)
                    firmware.write_bytes(members['dl-1425.bin'])
                    continue
                if platform == 'mister':
                    dest = stage/'mister/games/mame'/(name+'.zip')
                elif platform == 'mame' and kit.get('mame_layout') == 'stock-hsf2-v1':
                    stock_name, packed = stock_mame.repack(members, record['region'])
                    dest = stage/'mame'/(stock_name+'.zip')
                    write_zip(dest, packed)
                    continue
                else:
                    dest = stage/platform/(name+'.zip')
                dest.parent.mkdir(parents=True, exist_ok=True); shutil.copyfile(native, dest)
            print('PASS exact reconstruction', name, flush=True)
        if 'mame' in platforms and kit.get('mame_layout') == 'stock-hsf2-v1' and any(n.endswith('4') for n in selected):
            stock_mame.write_instructions(stage/'mame/RUN-MAME.txt',
                [r['region'] for n,r in selected.items() if n.endswith('4')])
        shutil.rmtree(stage/'native')
        shutil.copytree(HERE/'definitions', stage/'definitions')
        shutil.copyfile(HERE/'install_driver.py', stage/'install_driver.py')
        shutil.copyfile(HERE/'payload.py', stage/'payload.py')
        shutil.copyfile(HERE/'kit.json', stage/'source-kit.json')
        if 'mister' in platforms and any(n.endswith('8')for n in selected):
            import music
            region = 'us' if 'us' in regions else 'jp'
            cpk = work/'usf2_arrange.cpk'
            require(not cpk.exists(), 'Remove the previous generated CPK from --work before rebuilding')
            music.build(supplied[region], args.keys, kit['nsp'][region], cpk, work/'music', work/'source')
            write_zip(stage/'mister/games/CPS+/usf2_arrange.zip', {'usf2_arrange.cpk':cpk.read_bytes()})
            cpk.unlink(); Path(str(cpk)+'.json').unlink()
            shutil.copytree(HERE/'core', stage/'mister/_Arcade/cores')
        if 'mister' in platforms:
            from policy import check_mras
            for name in selected:
                if 'mister' not in platforms_for(name,platforms):continue
                check_mras(name,kit['profiles'][name]['mras'])
                for row in kit['profiles'][name]['mras']:
                    target = stage/'mister'/row['destination']; target.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copyfile(HERE/row['file'], target)
        from verify import verify_output
        report = verify_output(stage, kit, selected, platforms)
        (stage/'verification.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
        for filename in ('verify.py','mra_assembly.py','verify_output.py','nsp.py','switch_source.py','policy.py','stock_mame.py','cps2_code_guard.py','cps2_crypt.py','darksoft.py','darksoft_profiles.json'):
            shutil.copyfile(HERE/filename, stage/filename)
        shutil.copyfile(HERE/'README.txt', stage/'README.txt')
        (stage/'files.json').write_text(json.dumps({str(p.relative_to(stage)):file_sha(p) for p in
            sorted(stage.rglob('*')) if p.is_file() and '__pycache__' not in p.parts},indent=2,sort_keys=True)+'\n')
        require(not args.out_dir.exists(), 'Output appeared during reconstruction')
        stage.rename(args.out_dir)
    print('PASS verified USF2 outputs:', args.out_dir, flush=True)


def argument_parser():
    p = argparse.ArgumentParser(description=__doc__)
    for r in ('us','jp'):
        p.add_argument('--source-'+r, '--nsp-'+r, '--xci-'+r, dest='nsp_'+r, type=Path,
                       help='owned regional base NSP or supported XCI; content hashes must match')
    for n in ('keys','out-dir','work'):p.add_argument('--'+n,type=Path)
    p.add_argument('--rompath',type=Path,action='append',default=[])
    p.add_argument('--region',choices=('us','jp','all'),default='all')
    p.add_argument('--audio',choices=('4','8','all'),default='all',
                   help='4: MAME; 8: Darksoft/MiSTer/HBMAME; all: both capacities (default)')
    p.add_argument('--platform',choices=('mame','hbmame','mister','darksoft','all'),default='all',
                   help='output target (default: all); MiSTer requires --audio 8 or all')
    p.add_argument('--check',action='store_true',help='check arcade/NSP/XCI inputs without generating outputs or music')
    return p


if __name__ == '__main__':
    build(argument_parser().parse_args())
