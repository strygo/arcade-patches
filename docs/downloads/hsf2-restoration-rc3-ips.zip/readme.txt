Hyper Street Fighter II: The Anniversary Edition · English restoration
======================================================================

Version:  rc3 (2026-11-14)
Target:   MAME set 'hsf2j' (Hyper Street Fighter II: The Anniversary Edition (Japan 040202))
Hardware: Capcom CPS-2
Patch by: Steve Gordon (https://x.com/strygo)
Website:  https://arcadepatches.com/hsf2-restoration/

ABOUT THIS PROJECT

Play the Japanese version of Hyper Street Fighter II in English, with its
original balance and the classic versions of each fighter. Western fighter
names and the official US regional move voices accompany English win quotes,
full endings, illustrated Continue tips and all 28 Start messages.

Stage and portrait artwork repairs, black backgrounds in affected ending and
Ryu intro scenes, and a clearer ending-choice menu complete the restoration.
Japan's factory speed and coin settings are retained, with native Free Play
available in the operator menu.

It runs in MAME and on MiSTer, and in HBMAME or FBNeo builds that include
hsf2re. Apply the patch to your stock Japanese set.

This is a release candidate.

WHAT'S CHANGED

  - Japanese 040202 gameplay and classic fighter versions
  - Western fighter names and official US regional move voices
  - English win quotes, full endings and illustrated Continue tips
  - All 28 Start-message choices in English
  - Stage and portrait artwork repairs, black backgrounds in affected ending
    and Ryu intro scenes, and a clearer ending-choice menu
  - Native operator Free Play with saved settings and no-coin starts

BUILD THE GAME

Run python3 apply.py in a terminal for guided setup.
On Windows use py -3.13 apply.py.
Choose your media folder, platform, region and output folder.
Run python3 apply.py --help for command-line options.

HOW TO APPLY (recommended)

    python3 apply.py /path/to/hsf2j.zip --out-dir out

This checks every file against the original, applies the patches, checks
the result, and writes everything you need for each platform:

  MAME:                     out/mame/hsf2j.zip
  HBMAME:                   out/hbmame/hsf2re.zip
  FBNeo:                    out/fbneo/hsf2re.zip
  MiSTer:                   out/mister/_Arcade/_Arcade Patches/_Restorations/Hyper Street Fighter II The Anniversary Edition (USA) [English Restoration].mra
                            out/mister/games/hbmame/hsf2re.zip

FBNeo: use --platform fbneo --out-dir out for complete game ZIPs.
Keep their ZIP and member names. Use an FBNeo version with definitions
matching this game release; older versions may reject its checksums.


DARKSOFT

Use --platform darksoft --out-dir out to build only Darksoft files.
The default all-platform build includes them too. Copy the selected
folder from out/darksoft/games to your card games folder.
Expanded hardware and streamed audio are not supported.

Merged, split and complete sets work, including nested or renamed ROMs.
Use --rompath DIR (repeatable) to search a collection instead of naming the
zip, and --check to check inputs before building. ZIPs and extracted folders
need no extra software; 7z archives need 7-Zip.
QSound can stay in your emulator's ROM path; valid firmware already
in a source set is kept in complete outputs.

MAME: put hsf2j.zip from out/mame/ ahead of the stock set in your MAME
rompath.
MAME's game menu won't start a set with patched ROMs, so start it from the
command line: mame hsf2j. MAME shows checksum warnings for the patched
ROMs; that's expected and the game runs normally.
To start it from a menu, use the HBMAME build.

HBMAME: use a build containing the hsf2re set definitions.
Upstream HBMAME support is pending.
Put hsf2re.zip and qsound.zip in HBMAME's roms/ folder;
it holds the complete set.

MiSTer: copy the _Arcade folder from out/mister/ to the root of your SD card
and keep the stock, unmodified romset at games/mame/hsf2j.zip (split MAME
sets also need qsound.zip). The MRA applies the restoration in memory as the
game loads, so nothing on the card is modified. You need Jotego's jtcps2
core, which update_all installs. The MRAs are also a separate download.

out/mister/games/hbmame/hsf2re.zip is a complete copy of the emulator set. The
supplied MRA uses the stock Japanese set; that extra ZIP is optional.

HOW TO APPLY (any IPS patcher)

Extract hsf2j.zip, apply each file in ips/ to the ROM file of the
same name (Flips, Lunar IPS, or any IPS tool), then re-zip everything
as hsf2j.zip.

CHANGED FILES

    hs2.13m  (8.0 MB)  CRC32 a6ecab17 -> 448c3ede
    hs2.15m  (8.0 MB)  CRC32 10a0ae4d -> 642e11ec
    hs2.17m  (8.0 MB)  CRC32 adfa7726 -> 0aeb0c24
    hs2.19m  (8.0 MB)  CRC32 bb3ae322 -> 180c1a31
    hs2j.03c  (512 KB)  CRC32 6efe661f -> 42232142
    hs2j.04b  (512 KB)  CRC32 93f2500a -> c8b569a5
    hs2j.10  (512 KB)  CRC32 20d0f9e4 -> 5299288e

All other files in the set are unmodified.

START MESSAGES

Solo: use Free Play, or start with exactly one credit so no spare credits
remain. Spare credits keep PRESS START above the vacant seat and suppress the
message, as in the Japanese game.

Hold the active player's Start while the VS screen is showing, keep it held
until the fight begins, then release. With no attack held, Challenger /
wanted! alternates with the normal join prompt. Hold LP, MP, HP, LK, MK or HK
with Start for the other six choices. Pressing Start again during the fight
cancels the stored notice.

Two-player HUD messages require a completed round: hold Start through the
transition into the next round. The two sets belong to the previous round
winner and loser. For the result-screen set, hold the match winner's Start
through the result transition. Longer messages appear in two consecutive
parts.


LEGAL

This is a free, unofficial fan patch. It is not affiliated with or endorsed
by Capcom. All game titles, characters, and artwork remain the property of
their respective owners. You must own the game to use this patch. Do not
sell this patch or distribute it applied to a ROM image.
