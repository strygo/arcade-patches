Super Street Fighter II EX: The Ultimate Championship · Japan's Super Turbo, with everything added back
=======================================================================================================

Version:  rc1 (2026-09-17)
Target:   MAME set 'ssf2xj' (Super Street Fighter II X: Grand Master Challenge (Japan 940311))
Hardware: Capcom CPS-2
Patch by: Steve Gordon (https://x.com/strygo)
Website:  https://strygo.github.io/arcade-patches/

ABOUT THIS PROJECT

Super Turbo is the version competitive players swear by, but it left things
behind. The bonus stages from Super Street Fighter II were gone. Shin Akuma
was a hidden boss you had to earn, and Ten Akuma only turned up years later at
home. Tournament Battle, the eight-player linked-cabinet mode, stayed with the
earlier Super Street Fighter II.

EX puts it together on the arcade game. Shin and Ten Akuma are playable from
the start, picked from Ryu. The car, the falling barrels and the oil drums are
back between fights. Link cabinets with the adapter and it runs Tournament
Battle; without it, it plays as normal. Every fighter gets two more colors,
the move names are the modern ones, and the new title reads The Ultimate
Championship.

Nothing about the existing fighters changes: this is Japan's Super Turbo
underneath. The USA build carries all of Grand Master Challenge's English
text; the Japan build keeps the Japanese.

EX keeps the board's own ROM layout: the same files as the Japanese set, so it
runs in MAME, HBMAME and on MiSTer, and on a real CPS-2 board.

This is a release candidate.

WHAT'S CHANGED

  - Shin Akuma and Ten Akuma, playable from the start: on Ryu, hold Start and
    press three kicks for Shin, or MP, HP, MK and HK together for Ten (hold
    Start and three punches still gives Akuma)
  - Ten Akuma has his Super gauge and the Raging Demon, with the 天 pose
  - The three bonus stages from Super Street Fighter II, back in one-player
    games: the car after three fights, the barrels after six, the oil drums
    after nine
  - Tournament Battle: with the link adapter, eight players and three matches
    across linked cabinets; without it, the game plays normally
  - A new title screen: The Ultimate Championship, with an EX mark
  - Two more colors for every fighter: pick with two punches or two kicks, or
    hold Start as well for the Old version in those colors. The VS screen and
    the fight portrait show the color you picked
  - Free Play in the Japanese build too
  - Modern move names: Cammy's Spiral Arrow, Cannon Spike and Quick Spin
    Knuckle, and Dee Jay's Air Slasher, with the Japanese voice callouts in
    the USA build
  - USA build: all of Grand Master Challenge's English. Japan build: the
    original Japanese text, with Grand Master Challenge's backdrop fixes
  - The existing fighters play exactly as in Japan's Super Turbo

MISTER SETUP

1. Copy the _Arcade/ folder from this download to the root of your MiSTer SD
   card (the MRAs land in _Arcade/_Arcade Patches/_Enhanced Versions/), or just the MRAs you want:
       "Super Street Fighter II EX The Ultimate Championship (USA).mra"
       "_Japan/Super Street Fighter II EX The Ultimate Championship (Japan).mra"
2. Have the stock, unmodified romset at games/mame/ssf2xj.zip
   (split MAME sets also need qsound.zip next to it).
3. You need Jotego's jtcps2 core; the standard MiSTer downloader /
   update_all installs it automatically.

Each MRA references your original romset and applies the edition in
memory while the game loads. Nothing on your SD card is modified. Each
build keeps its own settings and saves under its own setname:
    USA (English)    ssf2tuc
    Japan (Japanese) ssf2xuc

LEGAL

This is a free, unofficial fan patch. It is not affiliated with or endorsed
by Capcom. All game titles, characters, and artwork remain the property of
their respective owners. You must own the game to use this patch. Do not
sell this patch or distribute it applied to a ROM image.
