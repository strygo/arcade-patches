Street Fighter Alpha EX · Enhanced version
==========================================

Version:  rc2 (2026-10-29)
Target:   MAME set 'sfzj' (Street Fighter Zero (Japan 950727))
Hardware: Capcom CPS-2
Patch by: Steve Gordon (https://x.com/strygo)
Website:  https://arcadepatches.com/sfa-ex/

ABOUT THIS PROJECT

Street Fighter Alpha EX aims to be the definitive version of the first Alpha,
bringing together features from its console releases and the CPS-1 Changer
version. It builds on the regional restoration, with Akuma, Dan and M. Bison
on the visible select screen and six colors per fighter: the original two plus
four from Alpha 2.

CONSOLE mode adds a green title and a cycling mode menu: Arcade, Versus,
Training, Dramatic Battle, Survival, Akuma and Options. Versus returns to
fighter selection after each match. Training has recording and replay,
computer behavior, stage and gauge controls, and health that refills after a
combo while stopping at 1 HP.

Dramatic Battle offers the original Ryu and Ken encounter and an EX route
against Adon, Sagat, M. Bison and Akuma. Play with a computer teammate or a
second player, and choose your team in EX. Survival follows Alpha Anthology's
opponent order and health recovery. Akuma mode goes straight to the original
boss challenge.

OPTIONS covers difficulty, timer, rounds, damage, speed and sound. The
operator menu adds CONSOLE or ARCADE game mode, six or original colors,
extended Turbo and slow speeds, and optional CPS Changer route choices in
Arcade. ARCADE mode retains the arcade title and coin handling.

The USA build is Street Fighter Alpha EX, with the regional restoration's
English story, quotes and endings. Japan is Street Fighter Zero EX, in
Japanese; Asia retains the Zero title with English text. The MiSTer MRAs start
in CONSOLE mode; MAME and HBMAME start in ARCADE mode. It runs in MAME and
HBMAME and on MiSTer.

This is a release candidate.

WHAT'S CHANGED

  - Akuma, Dan, M. Bison and Random on the expanded character-select screen
  - Six colors per fighter, selected with the six attack buttons; the four
    extra colors come from Alpha 2
  - CONSOLE mode with a green title and Arcade, Versus, Training, Dramatic
    Battle, Survival, Akuma and Options
  - Training with recording and replay, computer behavior, stage and gauge
    controls, delayed health refill and a 1 HP minimum
  - Classic Dramatic Battle and a four-opponent EX route, with a computer
    teammate or two human players
  - Survival with Alpha Anthology's opponent order and health recovery,
    animated during FIGHT
  - Direct access to the original Akuma challenge, named Gouki in Japan
  - Versus rematches return to character selection, with shared win counters
    in Versus and Survival
  - Coin or a START hold opens pause in Console fights; Quit returns directly
    to the title
  - OPTIONS for difficulty, timer, rounds, damage, speed and sound; extended
    Turbo and slow speeds in operator configuration
  - Optional CPS Changer route choices after character and speed selection in
    Arcade
  - USA, Japan and Asia builds, with the regional restoration underneath

MISTER SETUP

1. Copy the _Arcade/ folder from this download to the root of your MiSTer SD
   card (the MRAs land in _Arcade/_Arcade Patches/_Enhanced Versions/), or just the MRAs you want:
       "Street Fighter Alpha EX (USA).mra"
       "_Japan/Street Fighter Zero EX (Japan).mra"
       "_Asia/Street Fighter Zero EX (Asia).mra"
2. Have the stock, unmodified romset at games/mame/sfzj.zip
   (split sets also need the parent and QSound ZIPs named in the MRA).
3. You need Jotego's jtcps2 core; the standard MiSTer downloader /
   update_all installs it automatically.

Each MRA references your original romset and applies the edition in
memory while the game loads. Nothing on your SD card is modified. Each
build keeps its own settings and saves under its own setname:
    USA (English)    sfaexu
    Japan (Japanese) sfzexj
    Asia (English)   sfzexa

LEGAL

This is a free, unofficial fan patch. It is not affiliated with or endorsed
by Capcom. All game titles, characters, and artwork remain the property of
their respective owners. You must own the game to use this patch. Do not
sell this patch or distribute it applied to a ROM image.
