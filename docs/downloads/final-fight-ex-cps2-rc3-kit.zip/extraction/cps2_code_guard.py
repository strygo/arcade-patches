"""Reject CPS-2 ROM code outside the stock key's opcode range."""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import re
import struct
import sys
import zipfile
from cps2_crypt import decode_key, decrypt_rom
ROM_LIMIT = 4194304

class CodeRangeError(ValueError):
    pass

def require(ok, message):
    if not ok:
        raise CodeRangeError('CPS-2 code guard: ' + message)

def opcode_range(key):
    require(len(key) == 20, 'expected a 20-byte CPS-2 key')
    _, lower, upper, decoded = decode_key(key)
    return (lower * 2, upper * 2, decoded[9] == 65535)

def execution_range(key):
    """Intersection of stock and legacy jtCPS2 opcode decryption ranges."""
    lower, upper, dead = opcode_range(key)
    if dead:
        return (lower, upper)
    field = decode_key(key)[3][9]
    legacy_upper = ((field & 1023) + 1) * 16384
    return (lower, min(upper, legacy_upper))

def require_code_spans(spans, *, key=None, lower=None, upper=None):
    """Check complete executable allocations, including indirect callbacks."""
    if key is not None:
        require(lower is None and upper is None, 'use either a key or explicit bounds')
        _, _, dead = opcode_range(key)
        lower, upper = execution_range(key)
        require(not dead or not spans, 'Phoenix/dead keys have no encrypted ROM code region')
    require(isinstance(lower, int) and isinstance(upper, int) and (0 <= lower < upper <= 16777216), 'invalid opcode range')
    checked = []
    for span in spans:
        name, start, size = (span['name'], span['start'], span['size'])
        require(isinstance(name, str) and name, 'code span needs an owner')
        require(type(start) is int and type(size) is int and (start >= 0) and (size > 0) and (not (start | size) & 1), f'{name}: executable start/size must be positive, word-aligned byte values')
        end = start + size
        require(lower <= start < end <= min(upper, ROM_LIMIT), f'{name}: executable span [{start:#x}, {end:#x}) escapes MiSTer-safe encrypted range [{lower:#x}, {upper:#x}); relocate the code, keep the stock key')
        checked.append(dict(span))
    return checked

def direct_rom_transfers(image, lower, upper, *, code_spans=()):
    """Conservative independent census of absolute JSR/JMP opcode candidates."""
    result = []
    end = min(len(image), upper)
    for site in range(lower, end - 1, 2):
        opcode = struct.unpack_from('>H', image, site)[0]
        if opcode in (20153, 20217) and site + 6 <= len(image):
            absolute = struct.unpack_from('>I', image, site + 2)[0]
            known_code = any((s['start'] <= site and site + 6 <= s['start'] + s['size'] for s in code_spans))
            if absolute > 16777215 and (not known_code):
                continue
            target = absolute & 16777215
        elif opcode in (20152, 20216) and site + 4 <= len(image):
            target = struct.unpack_from('>h', image, site + 2)[0] & 16777215
        else:
            continue
        if 0 <= target < ROM_LIMIT and (not lower <= target < upper):
            result.append({'site': site, 'opcode': opcode, 'target': target})
    return result

def check_opcode_image(image, key, *, code_spans=()):
    require(len(image) % 2 == 0 and len(image) <= ROM_LIMIT, 'maincpu image must be word-aligned and at most 4 MiB')
    lower, upper, dead = opcode_range(key)
    safe_lower, safe_upper = execution_range(key)
    checked = require_code_spans(code_spans, key=key)
    require(all((s['start'] + s['size'] <= len(image) for s in checked)), 'declared executable allocation is missing from maincpu image')
    report = {'status': 'passed', 'lower': lower, 'upper_exclusive': upper, 'safe_upper_exclusive': safe_upper, 'key_sha256': hashlib.sha256(key).hexdigest(), 'code_spans': checked}
    if dead:
        report['policy'] = 'plaintext-Phoenix; encrypted-ROM guard is not applicable'
        return report
    refs = direct_rom_transfers(image, safe_lower, safe_upper, code_spans=checked)
    require(not refs, 'absolute JSR/JMP leaves MiSTer-safe encrypted ROM: ' + '; '.join((f"{r['site']:#x} -> {r['target']:#x}" for r in refs[:8])) + (f' ({len(refs)} candidates)' if len(refs) > 8 else ''))
    report.update(policy='encrypted-ROM-code', direct_upper_rom_candidates=0)
    return report

def check_archive(path, *, cache=None):
    """Audit a complete canonical MAME-format CPS-2 ZIP, or return None."""
    with zipfile.ZipFile(path) as archive:
        names = archive.namelist()
        require(len(names) == len(set(names)), f'duplicate ZIP members: {path}')
        keys = [n for n in names if n.lower().endswith('.key') and archive.getinfo(n).file_size == 20]
        if not keys:
            return None
        require(len(keys) == 1, f'expected one CPS-2 key in complete archive: {path}')
        key = archive.read(keys[0])
        program = {}
        for name in names:
            match = re.fullmatch('[^/]+\\.(0[3-9]|10)[a-zA-Z0-9_-]*', name)
            role = re.fullmatch('[^/]+\\.p([1-8])', name)
            if (match or role) and archive.getinfo(name).file_size == 524288:
                index = int(match[1]) if match else int(role[1]) + 2
                require(index not in program, f'ambiguous maincpu ROM order: {path}')
                program[index] = name
        require(program and sorted(program) == list(range(3, max(program) + 1)), f'incomplete/unsupported CPS-2 maincpu layout: {path}; supply a complete MAME set')
        members = [program[i] for i in sorted(program)]
        data = b''.join((archive.read(n) for n in members))
    image = bytearray(len(data))
    image[0::2], image[1::2] = (data[1::2], data[0::2])
    image = bytes(image)
    program_sha = hashlib.sha256(image).hexdigest()
    identity = (program_sha, hashlib.sha256(key).hexdigest())
    if cache is not None and identity in cache:
        report = cache[identity]
    else:
        lower, upper = execution_range(key)
        opcodes = b'' if lower == 0 and upper >= ROM_LIMIT else decrypt_rom(image, key)[0]
        report = check_opcode_image(opcodes, key)
        if cache is not None:
            cache[identity] = report
    return {**report, 'maincpu_sha256': program_sha, 'members': members, 'key_member': keys[0]}

def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--archive', type=Path, action='append', default=[])
    parser.add_argument('--image', type=Path, help='plaintext, CPU-order maincpu image')
    parser.add_argument('--key', type=Path)
    parser.add_argument('--spans', type=Path, help='JSON array of {name,start,size}, integers in bytes')
    parser.add_argument('--self-test', action='store_true')
    args = parser.parse_args(argv)
    if args.self_test:
        import unittest
        return not unittest.TextTestRunner().run(unittest.defaultTestLoader.discover(str(Path(__file__).parent), 'test_cps2_code_guard.py')).wasSuccessful()
    if not args.archive and (not (args.image and args.key)):
        parser.error('provide archives or a plaintext image and key')
    try:
        results, cache = ({}, {})
        for path in args.archive:
            report = check_archive(path, cache=cache)
            require(report is not None, f'not a complete CPS-2 archive: {path}')
            results[str(path)] = report
        if args.image:
            require(args.key is not None, 'image needs a key')
            spans = json.loads(args.spans.read_text(encoding='utf-8')) if args.spans else []
            results[str(args.image)] = check_opcode_image(args.image.read_bytes(), args.key.read_bytes(), code_spans=spans)
        print(json.dumps(results, indent=2))
        return 0
    except (CodeRangeError, OSError, zipfile.BadZipFile) as exc:
        print(str(exc), file=sys.stderr)
        return 1
