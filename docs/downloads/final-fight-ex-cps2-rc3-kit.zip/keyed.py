"""Compressed shared resources retaining each original datum/counterpart pair."""
import hashlib
import json
from pathlib import Path
from resource_recipe import Resources, require, sha as sha256

def keystream(name, counterpart, length):
    return hashlib.shake_256(b'ffex2 keyed\x00' + name.encode() + b'\x00' + counterpart).digest(length)

def xor(a, b):
    require(len(a) == len(b), 'Keyed XOR length differs')
    return (int.from_bytes(a, 'big') ^ int.from_bytes(b, 'big')).to_bytes(len(a), 'big')

def unseal(doc, payload, resolve, selected_sources=None):
    require(doc.get('schema') == 2, 'Unknown keyed resource schema')
    items = [row for row in doc['items'] if selected_sources is None or row['counterpart']['source'] in selected_sources]
    names = {row['counterpart']['source'] for row in items}
    catalog = json.loads((Path(__file__).parent / 'resources.json').read_text(encoding='utf-8'))
    plan = dict(catalog, sources={name: doc['sources'][name] for name in names})
    resources = Resources(plan, payload, {name: resolve(name) for name in names})
    result = {}
    for item in items:
        require(item['name'] not in result, 'Duplicate keyed datum')
        ops = item['resource']['ops']
        cp = item['counterpart']
        require(len(ops) == 1 and set(ops[0]) in ({'blob'}, {'xor'}), 'Keyed datum must retain its named resource')
        if 'xor' in ops[0]:
            operand = ops[0]['xor']
            require(len(operand) == 4 and operand[:3] == [cp['source'], cp['offset'], cp['length']] and (cp['length'] == item['length']), 'Keyed delta changed its counterpart extent')
            key = operand[3]
        else:
            key = ops[0]['blob']
        require(key in plan['blobs'], 'Unknown named datum resource')
        blob = plan['blobs'][key]
        require(blob['counterpart'] == dict(source=cp['source'], offset=cp['offset'], bytes=cp['length']) and blob['mask_label'] == item['name'], 'Datum/counterpart association changed')
        data = resources.emit(item['resource'])
        require(len(data) == item['length'] and sha256(data) == item['sha256'], 'Keyed datum differs')
        result[item['name']] = data
    return result
