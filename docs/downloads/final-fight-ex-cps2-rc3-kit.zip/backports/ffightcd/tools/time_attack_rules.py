#!/usr/bin/env python3
"""Final Fight CD Time Attack: decode the rules from the disc itself.

Reads each region's PRT_1..3 (the Time Attack stage programs, one per
character) and MAIN0 (the name table), and prints or writes as JSON:

  * the timer record (PRT header entry 1): BCD start count and frames per count;
  * the spawn script (PRT header entry 11): the stage spawn engine's groups and
    16-byte records, with each record's enemy named through the disc's own
    two-level name table;
  * whether the three characters' scripts are identical.

The record layout follows the interpreter in MAINSYS (main-CPU RAM FF68DA):
the script's first word goes to the engine's $A(a6); then a trigger word (>= 0)
or a command word (0x8000 + n: n=0 sets $A from the next word, 2 stops, 4 jumps
to the long that follows).  A trigger starts a group, whose 12-byte header ends
with a long pointing at the group's trailer word.  The group's records are 16
bytes each and begin with a delay word (frames to wait before spawning); a
negative word is the trailer, 0x8000 + action.  Within a record:

  +0  w  delay in frames      +5  b  side: 02 right, 00 left
  +2  w  (0001 in every record)  +7  b  depth lane (00 / 10 / 20)
  +4  b  (F0 in every record)    +8  b  family (02 = Mad Gear enemy)
                                  +9  b  group   +A  b  member   +B  b  variant byte
                                  +C..+F     extra (FF at +C on the Andore family)

At runtime (MEASURED in stock MAME, see the ffightcps2 Time Attack receipt) the
engine queues a group's 16 records at once, deploys them into the four enemy
slots as slots free up, and starts the next group after all 16 are cleared.

Names: MAINSYS FF4A0C indexes a table in MAIN0 (US $214C54; located per region
from that instruction) by family, then group, then member x 12.

  time_attack_rules.py [--region us|jp] [--json OUT]

The disc images resolve as in ffcd/disc.py (JP_IMG, US_IMG, or paths.json).
"""
from __future__ import annotations

# BEGIN ARCADE PYTHON BOOTSTRAP
import sys as _arcade_sys
from pathlib import Path as _ArcadePath
_arcade_sys.path.insert(0, str(_ArcadePath(__file__).resolve().parents[3]))
from kit_python import bootstrap as _arcade_bootstrap
_arcade_bootstrap()
# END ARCADE PYTHON BOOTSTRAP

import argparse
import json
import struct
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from ffcd import disc  # noqa: E402

SEC, HDR = 2352, 16
PRT_BASE = 0x207800
MAIN0_BASE = 0x20B800
# MAINSYS's name lookup: lea <table>.l,a0 / move.b $12(a6),d0 / move.w (a0,d0.w),d1
NAME_LOOKUP = bytes.fromhex("41f9"), bytes.fromhex("102e001232300000")


def iso_files(img):
    def rd(lba, n=2048):
        buf = bytearray()
        with open(img, "rb") as f:
            for i in range((n + 2047) // 2048):
                f.seek((lba + i) * SEC + HDR)
                buf += f.read(2048)
        return bytes(buf[:n])
    root = rd(16)[156:190]
    d = rd(struct.unpack_from("<I", root, 2)[0], struct.unpack_from("<I", root, 10)[0])
    files, i = {}, 0
    while i < len(d):
        ln = d[i]
        if ln == 0:
            i = (i // 2048 + 1) * 2048
            continue
        r = d[i:i + ln]
        name = r[33:33 + r[32]]
        if name not in (b"\0", b"\1"):
            files[name.decode().split(";")[0]] = (struct.unpack_from("<I", r, 2)[0], struct.unpack_from("<I", r, 10)[0])
        i += ln
    return lambda n: rd(*files[n])


def name_table(mainsys):
    """The table operand of MAINSYS's single name lookup (US $214C54)."""
    head, tail = NAME_LOOKUP
    hits = [i for i in range(0, len(mainsys) - 12, 2)
            if mainsys[i:i + 2] == head and mainsys[i + 6:i + 14] == tail]
    if len(hits) != 1:
        raise ValueError(f"expected one name lookup in MAINSYS, found {len(hits)}")
    return struct.unpack_from(">I", mainsys, hits[0] + 2)[0]


def namer(main0, table):
    w = lambda a: struct.unpack_from(">h", main0, a - MAIN0_BASE)[0]

    def name(fam, grp, sub):
        a = table + w(table + fam)
        a += w(a + 2 * grp)
        if fam != 0x0A:
            a += sub * 12
        raw = main0[a - MAIN0_BASE + 2:a - MAIN0_BASE + 12]
        return raw.decode("latin1").strip().replace(";", ".").replace("[", "R")
    return name


def decode(prt, name):
    L = lambda a: struct.unpack_from(">I", prt, a - PRT_BASE)[0]
    W = lambda a: struct.unpack_from(">H", prt, a - PRT_BASE)[0]
    timer_at = L(PRT_BASE + 4 * 1)
    timer = dict(start_bcd=f"{W(timer_at):02x}", frames_per_count=W(timer_at + 2))
    a = L(PRT_BASE + 4 * 11)
    script = dict(start=f"{a:06x}", cap_word=W(a), groups=[])
    a += 2
    seen = set()
    while True:
        w0 = W(a)
        if w0 & 0x8000:
            n = w0 & 0xFFF
            if n == 0:
                script["groups"].append(dict(command="set_A", value=W(a + 2)))
                a += 4
                continue
            if n == 2:
                script["groups"].append(dict(command="stop"))
                break
            if n == 4:
                tgt = L(a + 2)
                script["loop_to"] = f"{tgt:06x}"
                break
            raise ValueError(f"unknown command {w0:04x} at {a:06x}")
        if a in seen:
            break
        seen.add(a)
        trig = w0
        hdr = prt[a + 2 - PRT_BASE:a + 14 - PRT_BASE]
        trailer = struct.unpack_from(">I", hdr, 8)[0]
        recs, r = [], a + 14
        while not W(r) & 0x8000:
            b = prt[r - PRT_BASE:r + 16 - PRT_BASE]
            fam, grp, sub = b[8], b[9], b[10]
            recs.append(dict(delay=W(r), side="right" if b[5] == 2 else "left", lane=b[7],
                             family=fam, group=grp, member=sub, variant=b[11],
                             extra=b[12:16].hex(), name=name(fam, grp, sub)))
            r += 16
        if r != trailer:
            raise ValueError(f"group at {a:06x}: trailer {trailer:06x}, records end {r:06x}")
        script["groups"].append(dict(at=f"{a:06x}", trigger=trig, header=hdr[:8].hex(),
                                     end_action=W(r) & 0xFFF, records=recs))
        a = r + 2
    return dict(timer=timer, script=script)


def main():
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--region", choices=("us", "jp"), default="us")
    ap.add_argument("--json")
    args = ap.parse_args()
    get = iso_files(disc.US_IMG if args.region == "us" else disc.JP_IMG)
    table = name_table(get("MAINSYS.BIN"))
    name = namer(get("MAIN0.BIN"), table)
    res = {"region": args.region, "name_table": f"{table:06x}"}
    for k, who in ((1, "guy"), (2, "cody"), (3, "haggar")):
        res[who] = decode(get(f"PRT_{k}.BIN"), name)
    res["scripts_identical"] = all(res[w]["script"] == res["guy"]["script"] for w in ("cody", "haggar"))
    res["timers_identical"] = all(res[w]["timer"] == res["guy"]["timer"] for w in ("cody", "haggar"))
    if args.json:
        Path(args.json).write_text(json.dumps(res, indent=1) + "\n")
    g = res["guy"]
    print(f"region {args.region} (names at {table:06x}): timer {g['timer']}, scripts identical: {res['scripts_identical']}, "
          f"timers identical: {res['timers_identical']}")
    s = g["script"]
    print(f"script at {s['start']}, first word {s['cap_word']}, loops to {s.get('loop_to')}")
    for i, grp in enumerate(x for x in s["groups"] if "records" in x):
        print(f" group {i + 1} at {grp['at']} trigger {grp['trigger']} header {grp['header']} "
              f"end action {grp['end_action']:#x}: {len(grp['records'])} records")
        for r in grp["records"]:
            print(f"   +{r['delay']:3d}f {r['name']:<10s} {r['side']:<5s} lane {r['lane']:02x} "
                  f"var {r['variant']:02x} extra {r['extra']}")


if __name__ == "__main__":
    main()
