"""Final Fight CD Time Attack: decode the rules from the disc itself."""
from __future__ import annotations
import struct
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
SEC, HDR = (2352, 16)
PRT_BASE = 2127872
MAIN0_BASE = 2144256
NAME_LOOKUP = (bytes.fromhex('41f9'), bytes.fromhex('102e001232300000'))

def iso_files(img):

    def rd(lba, n=2048):
        buf = bytearray()
        with open(img, 'rb') as f:
            for i in range((n + 2047) // 2048):
                f.seek((lba + i) * SEC + HDR)
                buf += f.read(2048)
        return bytes(buf[:n])
    root = rd(16)[156:190]
    d = rd(struct.unpack_from('<I', root, 2)[0], struct.unpack_from('<I', root, 10)[0])
    files, i = ({}, 0)
    while i < len(d):
        ln = d[i]
        if ln == 0:
            i = (i // 2048 + 1) * 2048
            continue
        r = d[i:i + ln]
        name = r[33:33 + r[32]]
        if name not in (b'\x00', b'\x01'):
            files[name.decode().split(';')[0]] = (struct.unpack_from('<I', r, 2)[0], struct.unpack_from('<I', r, 10)[0])
        i += ln
    return lambda n: rd(*files[n])
