"""Shared Final Fight USA spelling corrections, approved on 15 October 2026."""
from __future__ import annotations
import struct
GROUP1 = 427366
HUD_FIXES = ((376014, '4441', '4445', 'HUD name table: GRANADE spelled GRENADE'),)
ENGLISH = {16: ' ', 1450: '.', 1512: ',', 1509: "'", 1516: '?', 1517: '!', 45: '-', 1510: '"', 1511: '"', 1513: ':', 1514: '(', 1515: ')'}
ENGLISH.update({1451 + i: c for i, c in enumerate('abcde')})
ENGLISH.update({1472 + i: c for i, c in enumerate('fghijklmnopqrstu')})
ENGLISH.update({1504 + i: c for i, c in enumerate('vwxyz')})
ENGLISH.update({1408 + i: c for i, c in enumerate('ABCDEFGHIJKLMNOP')})
ENGLISH.update({1440 + i: c for i, c in enumerate('QRSTUVWXYZ')})
ENGLISH.update({1576 + i: c for i, c in enumerate('12345678')})
ENGLISH.update({1612: '9', 1613: '0'})

def english_text(rec):
    lines = []
    for seg in rec['segments']:
        lines.append(''.join((ENGLISH.get(g, chr(g) if 32 <= g < 127 else f'[{g:03x}]') for g in seg['glyphs'])).rstrip())
    return [line for line in lines if line]

def word(image, at):
    return struct.unpack_from('>H', image, at)[0]

def large(text):
    glyphs = {c: g for g, c in ENGLISH.items() if c != '"'}
    return [glyphs[c] for c in text]
TYPOS = {7: [('Hee hee hee, Mr.Haggar. So pleased', 'Hee hee hee, Mr. Haggar. So pleased')], 16: [("your daughter's life can not be", "your daughter's life cannot be")], 17: [("Now of course,you'll need a couple", "Now of course, you'll need a couple")], 20: [('My sweet heart since child hood.', 'My sweetheart since childhood.')], 46: [('of Ninjitsu and attacks', 'of Ninjutsu and attacks')], 47: [('He is a martialarts expert.', 'He is a martial arts expert.'), ('His girl friend, Jessica,', 'His girlfriend, Jessica,')], 54: [("we're only half way there.", "we're only halfway there.")]}
SPACE = 16

def parse(image, at):
    """A group 1 record as stored: delay, mode, and each segment's 4-byte"""
    out, end = ({'delay': image[at], 'mode': image[at + 1], 'segments': []}, at + 2)
    while True:
        head = bytes(image[end:end + 4])
        end += 4
        glyphs = []
        while (g := word(image, end)) and (not g & 32768):
            glyphs.append(g)
            end += 2
        end += 2
        out['segments'].append({'head': head, 'glyphs': glyphs, 'close': g})
        if not g:
            out['end'] = end
            return out

def encode(rec):
    return bytes([rec['delay'], rec['mode']]) + b''.join((s['head'] + b''.join((struct.pack('>H', g) for g in s['glyphs'])) + struct.pack('>H', s['close']) for s in rec['segments']))

def text(glyphs):
    return english_text({'segments': [{'glyphs': glyphs}]})

def fixed(rec, fixes, index, allow_fixed=False):
    """The record with its lines fixed and its glyph count kept: the last"""
    segs = [dict(s, glyphs=list(s['glyphs'])) for s in rec['segments']]
    count = sum((len(s['glyphs']) for s in segs))
    for old, new in fixes:
        hits = [s for s in segs if text(s['glyphs']) == [old]]
        if not hits and allow_fixed and (sum((text(s['glyphs']) == [new] for s in segs)) == 1):
            continue
        if len(hits) != 1:
            raise ValueError(f'record {index:#04x}: no single line {old!r}')
        seg = hits[0]
        if large(old) != seg['glyphs'][:len(old)]:
            raise ValueError(f'record {index:#04x}: {old!r} is not in the large font')
        seg['glyphs'] = large(new) + seg['glyphs'][len(old):]
    last = segs[-1]['glyphs']
    excess = sum((len(s['glyphs']) for s in segs)) - count
    if excess > 0:
        if len(last) < excess or any((g != SPACE for g in last[len(last) - excess:])):
            raise ValueError(f'record {index:#04x}: no trailing spaces to absorb {excess} glyphs')
        del last[len(last) - excess:]
    else:
        last.extend([SPACE] * -excess)
    return {**rec, 'segments': segs}

def patches(program, allow_fixed=False):
    """(patch entries, receipt) for the USA program."""
    image = bytes(program)
    entries, rows = ([], [])
    for index, fixes in sorted(TYPOS.items()):
        start = GROUP1 + word(image, GROUP1 + 2 * index)
        rec = parse(image, start)
        old = image[start:rec['end']]
        if encode(rec) != old:
            raise ValueError(f'record {index:#04x} does not re-encode to its stock bytes')
        new = encode(fixed(rec, fixes, index, allow_fixed=allow_fixed))
        if len(new) != len(old):
            raise ValueError(f'record {index:#04x} changes length')
        entries.append((start, old.hex(), new.hex(), f"USA story text: {'; '.join((f'{o!r} -> {n!r}' for o, n in fixes))} (usa_text.py)"))
        rows.append({'record': f'{256 + index:#05x}', 'address': f'{start:#x}', 'bytes': len(old), 'fixes': [{'stock': o, 'fixed': n} for o, n in fixes]})
    return (entries, {'records': rows, 'approved': "15 October: the USA version's typos fixed"})

def self_test():
    head1, head2 = (struct.pack('>HH', 17 * 128 + 20 * 4, 47), struct.pack('>HH', 17 * 128 + 23 * 4, 15))
    rec = {'delay': 2, 'mode': 2, 'segments': [{'head': head1, 'glyphs': large('Mr.Haggar so'), 'close': 65535}, {'head': head2, 'glyphs': large('end.') + [SPACE] * 3, 'close': 0}]}
    blob = encode(rec)
    image = bytearray(256) + blob
    assert encode(parse(image, 256)) == blob and parse(image, 256)['end'] == 256 + len(blob)
    longer = fixed(parse(image, 256), [('Mr.Haggar so', 'Mr. Haggar so')], 0)
    assert [len(s['glyphs']) for s in longer['segments']] == [13, 6] and len(encode(longer)) == len(blob)
    assert encode(longer)[2:6] == head1
    assert encode(fixed(longer, [('Mr.Haggar so', 'Mr. Haggar so')], 0, allow_fixed=True)) == encode(longer)
    try:
        fixed(longer, [('Mr.Haggar so', 'Mr. Haggar so')], 0)
    except ValueError:
        pass
    else:
        raise AssertionError('stock-only mode accepted a previously changed record')
    shorter = fixed(parse(image, 256), [('Mr.Haggar so', 'Haggar so')], 0)
    assert [len(s['glyphs']) for s in shorter['segments']] == [9, 10]
    try:
        fixed(parse(image, 256), [('Mr.Haggar so', 'Mr. Haggar so, Mike Haggar!')], 0)
    except ValueError:
        pass
    else:
        raise AssertionError('a fix longer than the trailing spaces was accepted')
    print('self-test passed')
