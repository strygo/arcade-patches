"""Final Fight story-text records."""
