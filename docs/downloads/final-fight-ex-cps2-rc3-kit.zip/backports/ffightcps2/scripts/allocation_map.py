"""Where the CPS2 build's space goes, and what is free for EX."""
from __future__ import annotations
from pathlib import Path
import build_m1_spike as spike
TRACK = Path(__file__).resolve().parents[1]

def graphics_of(members):
    """The builder's linear 32 MiB layout, from the eight graphics members."""
    halves = []
    for names in spike.SFA3U_GFX:
        part = bytearray(16777216)
        for lane, name in enumerate(names):
            data = members[name]
            part[lane * 2::8] = data[0::2]
            part[lane * 2 + 1::8] = data[1::2]
        halves.append(bytes(part))
    return spike.unshuffle(b''.join(halves))
