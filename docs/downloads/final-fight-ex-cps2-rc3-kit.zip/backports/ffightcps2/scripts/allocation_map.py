#!/usr/bin/env python3
"""Where the CPS2 build's space goes, and what is free for EX.

Builds an edition (build_m1_spike.py), rebuilds its 4 MiB program from the
archive's program members and its 32 MiB graphics layout from the graphics
members (the inverse of the builder's packing), and reports:

- the program: every span the build claims (stock Final Fight, the layer,
  the restoration's text block, the upper-ROM tables named in the build
  receipt) and every run of free (0xFF) bytes of at least ``--min`` bytes,
  below and above 1 MiB;
- the graphics: the free runs of the layout, in the object half and the
  scroll half (scroll 1/2/3 codes address the second 8 MiB at 64, 128 and
  512 bytes a code) and in the overlay's second 16 MiB.

EX's port plan (EX_PHASE0.md) reads its free-space figures from this report.

    CAPCOM_WORK_ROOT=/Volumes/CapcomScratch python3 allocation_map.py --edition english --receipt R.json
"""
from __future__ import annotations

# BEGIN ARCADE PYTHON BOOTSTRAP
import sys as _arcade_sys
from pathlib import Path as _ArcadePath
_arcade_sys.path.insert(0, str(_ArcadePath(__file__).resolve().parents[3]))
from kit_python import bootstrap as _arcade_bootstrap
_arcade_bootstrap()
# END ARCADE PYTHON BOOTSTRAP

import argparse
import json
from pathlib import Path
import sys
import zipfile

import audit_upstream as upstream
import build_m1_spike as spike

TRACK = Path(__file__).resolve().parents[1]


def free_runs(data, minimum, base=0):
    runs, start = [], None
    for at in range(0, len(data), 16):          # 16-byte granules: enough for allocation
        blank = data[at:at + 16] == b"\xff" * 16
        if blank and start is None:
            start = at
        elif not blank and start is not None:
            if at - start >= minimum:
                runs.append((base + start, at - start))
            start = None
    if start is not None and len(data) - start >= minimum:
        runs.append((base + start, len(data) - start))
    return runs


def program_of(members, phoenix):
    names = spike.PHOENIX_PROGRAM if phoenix else spike.SFA3U_PROGRAM
    return b"".join(upstream.swap_words(members[name]) for name in names)


def graphics_of(members):
    """The builder's linear 32 MiB layout, from the eight graphics members."""
    halves = []
    for names in spike.SFA3U_GFX:
        part = bytearray(0x1000000)
        for lane, name in enumerate(names):
            data = members[name]
            part[lane * 2::8] = data[0::2]
            part[lane * 2 + 1::8] = data[1::2]
        halves.append(bytes(part))
    return spike.unshuffle(b"".join(halves))


def report(build, members, minimum, gfx_minimum):
    program = program_of(members, build["phoenix_map"])
    layer = int(build["layer"]["home"], 16), build["layer"]["bytes"]
    claims = [("stock Final Fight program (non-0xFF below 0xF0000)", 0, 0xF0000), ("the layer", *layer)]
    story = build.get("english_records")
    if story:
        claims.append(("the restoration's text block", int(story["home"], 16), story["block_bytes"]))
    ov = build["overlay"]
    for name, key in (("overlay table", "table"), ("scroll 1 overlay table", "scroll1_table"),
                      ("scroll 1 safe table", "scroll1_safe_table"), ("wide Y table", "wide_y_table")):
        claims.append((name, int(ov[key]["home"], 16), ov[key]["bytes"]))
    claims.append(("conversion tables", spike.CONVERSION_TABLES, 3 * 0x10000))
    q = build["qsound_screen"]
    claims.append(("QSound screen table", int(q["home"], 16), q["bytes"]))
    if build.get("regulation"):
        r = build["regulation"]
        claims.append(("REGULATION table", int(r["home"], 16), r["bytes"]))
        w = r["white_blood"]
        claims.append(("white blood scripts", int(w["home"], 16), w["bytes"]))
    c = build["credits"]
    claims.append(("staff roll with the port's credit", int(c["home"], 16), c["bytes"]))
    graphics = graphics_of(members)
    return {
        "edition": build["edition"], "program_sha256": build["program"]["sha256"],
        "program_claims": [{"owner": n, "start": f"{a:#x}", "bytes": s} for n, a, s in claims],
        "program_free_below_1mib": [{"start": f"{a:#x}", "bytes": s} for a, s in free_runs(program[:0x100000], minimum)],
        "program_free_upper": [{"start": f"{a:#x}", "bytes": s}
                               for a, s in free_runs(program[0x100000:], minimum, 0x100000)],
        "graphics_free": [{"start": f"{a:#x}", "bytes": s, "half": "objects" if a < 0x800000 else
                           "scroll codes" if a < 0x1000000 else "overlay objects"}
                          for a, s in free_runs(graphics, gfx_minimum)],
    }


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--rompath", action="append", type=Path, default=[])
    parser.add_argument("--edition", choices=spike.EDITIONS, default="japan")
    parser.add_argument("--work", type=Path, default=TRACK / "work" / "allocation")
    parser.add_argument("--min", type=int, default=0x400, help="smallest program run to list (bytes)")
    parser.add_argument("--gfx-min", type=int, default=0x10000, help="smallest graphics run to list (bytes)")
    parser.add_argument("--receipt", type=Path)
    args = parser.parse_args(argv)
    work = args.work.resolve()
    build = spike.build(args.rompath + spike.default_rompaths(), work, edition=args.edition)
    with zipfile.ZipFile(work / "rom" / "sfa3u.zip") as z:
        members = {n: z.read(n) for n in z.namelist()}
    result = report(build, members, args.min, args.gfx_min)
    if args.receipt:
        args.receipt.write_text(json.dumps(result, indent=1) + "\n")
    for key in ("program_free_below_1mib", "program_free_upper", "graphics_free"):
        runs = result[key]
        print(f"{key}: {sum(r['bytes'] for r in runs):,} bytes in {len(runs)} runs; largest "
              + ", ".join(f"{r['start']}+{r['bytes']:#x}" for r in sorted(runs, key=lambda r: -r['bytes'])[:6]))
    return 0


if __name__ == "__main__":
    sys.exit(main())
