"""Source-bound QSound 1.71 pause with an isolated native-sample UI voice.

Gameplay sequencer RAM remains frozen. A complete native DSP write shadow
lets HOLD freeze PCM playback and silence voices; RESUME restores their rates
and volumes. Voice
15 is absent from every complete converted catalog header and plays UI only.
"""
import hashlib
import struct

PARENT = 'cda0219133f4a1d0b0b62f77f1b0a30a151c6dfff059eca359af60fc94fccbec'
DRIVER_SHA = '4481c342b7bac3b11f91fb8527aeaba891d2c134f9b0b141c1780f60ab203f03'
HOME = 0x3700
HOLD, ACK, MAGIC = 0xCFF9, 0xCFFB, 0xCFFA
SHADOW, LOW, HIGH, UI_TICKS, UI_LAST = 0xCC00, 0xCE00, 0xCE01, 0xCE02, 0xCE03
DSP_SITES = (0xc6,0x487,0x896,0x951,0xe7e,0xe9a,0xeb0,0xec6,0xeed,0xf06,
             0x11a7,0x11bf,0x11d7,0x11f5,0x1211,0x122a,0x14ab,0x14dc,
             0x1517,0x153b,0x155a,0x16a2,0x16f0,0x1a28,0x1fcc,0x213d)
VOLUMES = tuple(range(6,0x80,8))+(0xcd,0xd1,0xd5)
ECHO = (0x93,0xd9)+tuple(range(0xba,0xca))


def patch(source, parent_sha256=PARENT):
    sha=lambda b:hashlib.sha256(b).hexdigest()
    if sha(source)!=parent_sha256 or sha(source[:0x3c00])!=DRIVER_SHA:
        raise ValueError('unknown converted FF EX QSound 1.71 program')
    expected={3:'31ffff',0x18f:'210000',0x1c7:'2101f0',0x400:'ca210b',
              0xb21:'2600fd6e0111300b29197e23666fe9'}
    for at,value in expected.items():
        if source[at:at+len(bytes.fromhex(value))]!=bytes.fromhex(value):
            raise ValueError(f'complete native driver preimage differs: {at:04x}')
    if struct.unpack_from('<16H',source,0xb30)[14:]!=(0xdf8,0xb50):
        raise ValueError('native snapshot/no-op control family differs')
    # Complete DSP publisher family: all 26 literal port-write triples, with
    # their original A/HL and flags ABI. IRQ 0038 only accepts queue records;
    # all DSP publications run on this single foreground path.
    for port,delta in ((0xd001,-8),(0xd000,-4),(0xd002,0)):
        token=b'\x32'+struct.pack('<H',port)
        if tuple(i for i in range(0x3c00) if source[i:i+3]==token)!=tuple(a+delta for a in DSP_SITES):
            raise ValueError('complete native DSP port publisher census differs')
    for at in DSP_SITES:
        if source[at-9:at+3]!=bytes.fromhex('7d3201d07c3200d0f13202d0'):
            raise ValueError('native DSP publication instruction family differs')
    # Every actual score header, including the original QSound logo, must
    # leave voice 15 unused. Do not infer that from music channel counts.
    count=int.from_bytes(source[0x8c00:0x8c02],'big')
    if count!=96:raise ValueError('complete converted catalog extent differs')
    headers=[]
    for cue in range(count):
        at=int.from_bytes(source[0x8c06+cue*4:0x8c09+cue*4],'big')
        if not at:continue
        offsets=struct.unpack_from('>16H',source,at+1)
        if offsets[15]:raise ValueError('UI voice 15 has a native score owner')
        headers.append({'cue':cue,'address':at,'sha256':sha(source[at:at+33])})
    samples=[]
    for cue,wanted in ((0x39,(0x2e,0xec00,0xff0a,0xff0c,47)),
                       (0x3a,(0x5b,0x8000,0xd27f,0xd281,47))):
        at=int.from_bytes(source[0x8c06+cue*4:0x8c09+cue*4],'big')
        offsets=struct.unpack_from('>16H',source,at+1)
        body=source[at+33:at+53]
        if offsets!=tuple(33 if c==10 else 0 for c in range(16)) or body[11]!=cue or body[2:]!=bytes.fromhex('184006ff077f1f2708')+bytes([cue])+bytes.fromhex('09030b000400ec17'):
            raise ValueError('complete native menu score differs')
        bank=struct.unpack_from('<H',source,0x3c05+2*body[9])[0]
        row=struct.unpack_from('<H',source,bank+4*body[11])[0]
        desc=struct.unpack_from('<BHHHB',source,0x6000+8*row)
        if desc!=wanted:raise ValueError('native menu sample descriptor differs')
        samples.append(desc)
    volume=struct.unpack_from('<H',source,0x2e92+254)[0]-1
    if volume!=0x2cf9:raise ValueError('native full menu volume projection differs')
    code=bytearray();labels={};fix=[]
    def emit(h):code.extend(bytes.fromhex(h))
    def label(n):labels[n]=HOME+len(code)
    def absolute(op,at):code.append(op);code.extend(struct.pack('<H',at))
    def jump(op,n):code.append(op);fix.append((len(code),n));code.extend(b'\0\0')
    def write(reg,value):
        emit('11');code.extend(struct.pack('<H',value));emit('3e');code.append(reg);jump(0xcd,'write')
    label('boot');emit('31ffffaf32f9cf32fbcf32facf2100cc1101cc01030277edb0c30600')
    label('init');emit('af32f9cf32fbcf3202ce3ea532facf210000c39201')
    label('low');emit('3201d03200cec9')
    label('high');emit('3200d03201cec9')
    label('publish');emit('f5c5d5e54f0600260069291100cc193a00ce77233a01ce77')
    # A held native volume write updates the shadow but cannot unmute a game
    # voice. Fresh UI writes bypass this mirror and never touch sequence RAM.
    emit('3af9cfb7');jump(0xca,'protect_ui')
    emit('79fe80');jump(0xd2,'adpcm')
    emit('e607fe02');jump(0xca,'publish_done');emit('fe06');jump(0xca,'publish_done');jump(0xc3,'protect_ui')
    label('adpcm')
    for reg in (0xcd,0xd1,0xd5):emit('79fe');code.append(reg);jump(0xca,'publish_done')
    label('protect_ui');emit('3a02ceb7');jump(0xca,'publish_native')
    for reg in (0x70,0x8f,0xc9):emit('79fe');code.append(reg);jump(0xca,'publish_done')
    emit('79fe79');jump(0xda,'publish_native');emit('fe7f');jump(0xda,'publish_done')
    label('publish_native');emit('793202d0')
    label('publish_done');emit('e1d1c1f1c9')
    label('entry');emit('f5c5d5e5dde5fde5')
    label('poll');jump(0xcd,'tick');emit('3af9cfb7');jump(0xca,'running')
    emit('3afbcfb7');jump(0xc2,'wait')
    emit('110000');jump(0xcd,'outputs')
    # Muting does not stop the DSP sample cursor. Freeze every game PCM rate
    # as well, preserving the running address/phase until the score resumes.
    # Voice 15 belongs exclusively to UI and keeps its independent lifetime.
    emit('060f0e02110000')
    label('freeze_pcm');emit('79');jump(0xcd,'write');emit('79c6084f10f6')
    for reg in VOLUMES:write(reg,0)
    # Collapse echo to one cleared cell while master outputs remain muted.
    # No paused gameplay or old echo tail can accompany a fresh menu sample.
    write(0x93,0);write(0xd9,0)
    for reg in range(0xba,0xca):write(reg,0)
    emit('3e0132fbcf')
    label('wait');absolute(0xcd,0x3e5);emit('af3201f03202f0');jump(0xc3,'poll')
    label('running');emit('3afbcfb7');jump(0xca,'native')
    # Restore the latest native volume/echo shadow. Quit's native STOP has
    # already written zeroes into it; Continue retains the original values.
    emit('060f0e02')
    label('resume_pcm');emit('79');jump(0xcd,'restore');emit('79c6084f10f6')
    for reg in VOLUMES+ECHO:
        if reg==0x7e:continue
        emit('3e');code.append(reg);jump(0xcd,'restore')
    emit('11ff3f');jump(0xcd,'outputs');emit('af32fbcf3201f03202f0')
    label('native');emit('fde1dde1e1d1c1f12101f0c3ca01')
    label('restore');emit('f526006f291100cc195e2356f1');jump(0xc3,'write')
    label('write');emit('f5')
    label('busy');emit('3a07d007');jump(0xd2,'busy')
    emit('7b3201d07a3200d0f13202d0c9')
    label('outputs')
    for reg in range(0xe4,0xe8):emit('3e');code.append(reg);jump(0xcd,'write')
    emit('c9')
    label('tick');emit('3a00f0e6fc473a03ceb8c8783203ce3a02ceb7c82102ce35c0');write(0x7e,0);emit('c9')
    label('control');emit('f5fd7e01fe0e');jump(0xca,'hold');emit('fe0f');jump(0xca,'resume')
    emit('fe05');jump(0xca,'stop')
    emit('fe10');jump(0xca,'move');emit('fe11');jump(0xca,'confirm')
    emit('f1');absolute(0xc3,0xb21)
    label('hold');emit('f13e0132f9cfc9')
    label('resume');emit('f1af32f9cfc9')
    label('stop');emit('f1f5af32f9cff1');absolute(0xc3,0xb21)
    for name,desc,ticks in (('move',samples[0],32),('confirm',samples[1],96)):
        label(name);emit('f1f5c5d5e5')
        bank,start,loop,end,_=desc
        write(0x7e,0);write(0x70,0x8000|bank);write(0x79,start)
        write(0x7a,0x1000);write(0x7b,0);write(0x7c,end-loop);write(0x7d,end)
        write(0x8f,0x150);write(0xc9,0);write(0x7e,volume)
        emit('3e');code.append(ticks);emit('3202ce3a00f0e6fc3203ce11ff3f');jump(0xcd,'outputs')
        emit('e1d1c1f1c9')
    for at,name in fix:code[at:at+2]=struct.pack('<H',labels[name])
    if HOME+len(code)>0x3c00 or source[HOME:HOME+len(code)]!=bytes(len(code)):
        raise ValueError(f'complete pause/UI helper allocation occupied or too large: {len(code)}')
    output=bytearray(source);output[HOME:HOME+len(code)]=code
    for at,name in ((3,'boot'),(0x18f,'init'),(0x1c7,'entry'),(0x400,'control')):
        output[at:at+3]=bytes([0xca if at==0x400 else 0xc3])+struct.pack('<H',labels[name])
    for at in DSP_SITES:
        for delta,name in ((-8,'low'),(-4,'high'),(0,'publish')):
            output[at+delta:at+delta+3]=b'\xcd'+struct.pack('<H',labels[name])
    return bytes(output),{'parent_sha256':parent_sha256,'driver_sha256':DRIVER_SHA,'entries':labels,
        'helper_bytes':len(code),'output_sha256':sha(output),'hold':0xff0e,'resume':0xff0f,'ack':ACK,
        'ui':{'move':0xff10,'confirm':0xff11,'voice':15,'samples':samples,'volume':volume,
            'pitch':0x1000,'pan':0x150,'shadow':[SHADOW,SHADOW+512],
            'staging_and_ticks':[LOW,UI_LAST+1],'ui_clock':'F000 IRQ epoch / four interrupts; repeats within one epoch do not age a sample','catalog_headers':headers,
            'native_dsp_publishers':list(DSP_SITES),'frozen_pcm_voices':list(range(15)),
            'hold_policy':'zero game PCM rate and volume; retain actual sample address and phase; restore latest native rates before volumes'},
        'native_replaced_control':'FF0E snapshot (unused by FF EX producer)',
        'status':'component candidate; runtime qualification required'}
