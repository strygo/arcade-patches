"""Source-bound QSound 1.71 pause with an isolated native-sample UI voice."""
import hashlib
import struct
PARENT = 'cda0219133f4a1d0b0b62f77f1b0a30a151c6dfff059eca359af60fc94fccbec'
DRIVER_SHA = '4481c342b7bac3b11f91fb8527aeaba891d2c134f9b0b141c1780f60ab203f03'
HOME = 14080
HOLD, ACK, MAGIC = (53241, 53243, 53242)
SHADOW, LOW, HIGH, UI_TICKS, UI_LAST = (52224, 52736, 52737, 52738, 52739)
DSP_SITES = (198, 1159, 2198, 2385, 3710, 3738, 3760, 3782, 3821, 3846, 4519, 4543, 4567, 4597, 4625, 4650, 5291, 5340, 5399, 5435, 5466, 5794, 5872, 6696, 8140, 8509)
VOLUMES = tuple(range(6, 128, 8)) + (205, 209, 213)
ECHO = (147, 217) + tuple(range(186, 202))

def patch(source, parent_sha256=PARENT):
    sha = lambda b: hashlib.sha256(b).hexdigest()
    if sha(source) != parent_sha256 or sha(source[:15360]) != DRIVER_SHA:
        raise ValueError('unknown converted FF EX QSound 1.71 program')
    expected = {3: '31ffff', 399: '210000', 455: '2101f0', 1024: 'ca210b', 2849: '2600fd6e0111300b29197e23666fe9'}
    for at, value in expected.items():
        if source[at:at + len(bytes.fromhex(value))] != bytes.fromhex(value):
            raise ValueError(f'complete native driver preimage differs: {at:04x}')
    if struct.unpack_from('<16H', source, 2864)[14:] != (3576, 2896):
        raise ValueError('native snapshot/no-op control family differs')
    for port, delta in ((53249, -8), (53248, -4), (53250, 0)):
        token = b'2' + struct.pack('<H', port)
        if tuple((i for i in range(15360) if source[i:i + 3] == token)) != tuple((a + delta for a in DSP_SITES)):
            raise ValueError('complete native DSP port publisher census differs')
    for at in DSP_SITES:
        if source[at - 9:at + 3] != bytes.fromhex('7d3201d07c3200d0f13202d0'):
            raise ValueError('native DSP publication instruction family differs')
    count = int.from_bytes(source[35840:35842], 'big')
    if count != 96:
        raise ValueError('complete converted catalog extent differs')
    headers = []
    for cue in range(count):
        at = int.from_bytes(source[35846 + cue * 4:35849 + cue * 4], 'big')
        if not at:
            continue
        offsets = struct.unpack_from('>16H', source, at + 1)
        if offsets[15]:
            raise ValueError('UI voice 15 has a native score owner')
        headers.append({'cue': cue, 'address': at, 'sha256': sha(source[at:at + 33])})
    samples = []
    for cue, wanted in ((57, (46, 60416, 65290, 65292, 47)), (58, (91, 32768, 53887, 53889, 47))):
        at = int.from_bytes(source[35846 + cue * 4:35849 + cue * 4], 'big')
        offsets = struct.unpack_from('>16H', source, at + 1)
        body = source[at + 33:at + 53]
        if offsets != tuple((33 if c == 10 else 0 for c in range(16))) or body[11] != cue or body[2:] != bytes.fromhex('184006ff077f1f2708') + bytes([cue]) + bytes.fromhex('09030b000400ec17'):
            raise ValueError('complete native menu score differs')
        bank = struct.unpack_from('<H', source, 15365 + 2 * body[9])[0]
        row = struct.unpack_from('<H', source, bank + 4 * body[11])[0]
        desc = struct.unpack_from('<BHHHB', source, 24576 + 8 * row)
        if desc != wanted:
            raise ValueError('native menu sample descriptor differs')
        samples.append(desc)
    volume = struct.unpack_from('<H', source, 11922 + 254)[0] - 1
    if volume != 11513:
        raise ValueError('native full menu volume projection differs')
    code = bytearray()
    labels = {}
    fix = []

    def emit(h):
        code.extend(bytes.fromhex(h))

    def label(n):
        labels[n] = HOME + len(code)

    def absolute(op, at):
        code.append(op)
        code.extend(struct.pack('<H', at))

    def jump(op, n):
        code.append(op)
        fix.append((len(code), n))
        code.extend(b'\x00\x00')

    def write(reg, value):
        emit('11')
        code.extend(struct.pack('<H', value))
        emit('3e')
        code.append(reg)
        jump(205, 'write')
    label('boot')
    emit('31ffffaf32f9cf32fbcf32facf2100cc1101cc01030277edb0c30600')
    label('init')
    emit('af32f9cf32fbcf3202ce3ea532facf210000c39201')
    label('low')
    emit('3201d03200cec9')
    label('high')
    emit('3200d03201cec9')
    label('publish')
    emit('f5c5d5e54f0600260069291100cc193a00ce77233a01ce77')
    emit('3af9cfb7')
    jump(202, 'protect_ui')
    emit('79fe80')
    jump(210, 'adpcm')
    emit('e607fe02')
    jump(202, 'publish_done')
    emit('fe06')
    jump(202, 'publish_done')
    jump(195, 'protect_ui')
    label('adpcm')
    for reg in (205, 209, 213):
        emit('79fe')
        code.append(reg)
        jump(202, 'publish_done')
    label('protect_ui')
    emit('3a02ceb7')
    jump(202, 'publish_native')
    for reg in (112, 143, 201):
        emit('79fe')
        code.append(reg)
        jump(202, 'publish_done')
    emit('79fe79')
    jump(218, 'publish_native')
    emit('fe7f')
    jump(218, 'publish_done')
    label('publish_native')
    emit('793202d0')
    label('publish_done')
    emit('e1d1c1f1c9')
    label('entry')
    emit('f5c5d5e5dde5fde5')
    label('poll')
    jump(205, 'tick')
    emit('3af9cfb7')
    jump(202, 'running')
    emit('3afbcfb7')
    jump(194, 'wait')
    emit('110000')
    jump(205, 'outputs')
    emit('060f0e02110000')
    label('freeze_pcm')
    emit('79')
    jump(205, 'write')
    emit('79c6084f10f6')
    for reg in VOLUMES:
        write(reg, 0)
    write(147, 0)
    write(217, 0)
    for reg in range(186, 202):
        write(reg, 0)
    emit('3e0132fbcf')
    label('wait')
    absolute(205, 997)
    emit('af3201f03202f0')
    jump(195, 'poll')
    label('running')
    emit('3afbcfb7')
    jump(202, 'native')
    emit('060f0e02')
    label('resume_pcm')
    emit('79')
    jump(205, 'restore')
    emit('79c6084f10f6')
    for reg in VOLUMES + ECHO:
        if reg == 126:
            continue
        emit('3e')
        code.append(reg)
        jump(205, 'restore')
    emit('11ff3f')
    jump(205, 'outputs')
    emit('af32fbcf3201f03202f0')
    label('native')
    emit('fde1dde1e1d1c1f12101f0c3ca01')
    label('restore')
    emit('f526006f291100cc195e2356f1')
    jump(195, 'write')
    label('write')
    emit('f5')
    label('busy')
    emit('3a07d007')
    jump(210, 'busy')
    emit('7b3201d07a3200d0f13202d0c9')
    label('outputs')
    for reg in range(228, 232):
        emit('3e')
        code.append(reg)
        jump(205, 'write')
    emit('c9')
    label('tick')
    emit('3a00f0e6fc473a03ceb8c8783203ce3a02ceb7c82102ce35c0')
    write(126, 0)
    emit('c9')
    label('control')
    emit('f5fd7e01fe0e')
    jump(202, 'hold')
    emit('fe0f')
    jump(202, 'resume')
    emit('fe05')
    jump(202, 'stop')
    emit('fe10')
    jump(202, 'move')
    emit('fe11')
    jump(202, 'confirm')
    emit('f1')
    absolute(195, 2849)
    label('hold')
    emit('f13e0132f9cfc9')
    label('resume')
    emit('f1af32f9cfc9')
    label('stop')
    emit('f1f5af32f9cff1')
    absolute(195, 2849)
    for name, desc, ticks in (('move', samples[0], 32), ('confirm', samples[1], 96)):
        label(name)
        emit('f1f5c5d5e5')
        bank, start, loop, end, _ = desc
        write(126, 0)
        write(112, 32768 | bank)
        write(121, start)
        write(122, 4096)
        write(123, 0)
        write(124, end - loop)
        write(125, end)
        write(143, 336)
        write(201, 0)
        write(126, volume)
        emit('3e')
        code.append(ticks)
        emit('3202ce3a00f0e6fc3203ce11ff3f')
        jump(205, 'outputs')
        emit('e1d1c1f1c9')
    for at, name in fix:
        code[at:at + 2] = struct.pack('<H', labels[name])
    if HOME + len(code) > 15360 or source[HOME:HOME + len(code)] != bytes(len(code)):
        raise ValueError(f'complete pause/UI helper allocation occupied or too large: {len(code)}')
    output = bytearray(source)
    output[HOME:HOME + len(code)] = code
    for at, name in ((3, 'boot'), (399, 'init'), (455, 'entry'), (1024, 'control')):
        output[at:at + 3] = bytes([202 if at == 1024 else 195]) + struct.pack('<H', labels[name])
    for at in DSP_SITES:
        for delta, name in ((-8, 'low'), (-4, 'high'), (0, 'publish')):
            output[at + delta:at + delta + 3] = b'\xcd' + struct.pack('<H', labels[name])
    return (bytes(output), {'parent_sha256': parent_sha256, 'driver_sha256': DRIVER_SHA, 'entries': labels, 'helper_bytes': len(code), 'output_sha256': sha(output), 'hold': 65294, 'resume': 65295, 'ack': ACK, 'ui': {'move': 65296, 'confirm': 65297, 'voice': 15, 'samples': samples, 'volume': volume, 'pitch': 4096, 'pan': 336, 'shadow': [SHADOW, SHADOW + 512], 'staging_and_ticks': [LOW, UI_LAST + 1], 'ui_clock': 'F000 IRQ epoch / four interrupts; repeats within one epoch do not age a sample', 'catalog_headers': headers, 'native_dsp_publishers': list(DSP_SITES), 'frozen_pcm_voices': list(range(15)), 'hold_policy': 'zero game PCM rate and volume; retain actual sample address and phase; restore latest native rates before volumes'}, 'native_replaced_control': 'FF0E snapshot (unused by FF EX producer)', 'status': 'component candidate; runtime qualification required'})
