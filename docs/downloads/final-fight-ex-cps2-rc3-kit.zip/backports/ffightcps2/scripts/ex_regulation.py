"""REGULATION in EX's SEGA CD intro: the other disc's picture on Haggar's TV."""
from __future__ import annotations
import argparse
from collections import namedtuple
import hashlib
import json
import struct
import sys
import regulation
SCRIPT, PALBLOCKS, DELTAS = (1024, 36864, 167936)
COLS, ROWS, ROW0, COL0 = (20, 14, 17, 38)
LATE, SPILL, DEFERRED = (8192, 16384, 32768)
ART_BASE = 20480
CLEAR = (ART_BASE, 0)
Shot = namedtuple('Shot', 'first slide_end last')
SHOTS = {'jp': Shot(914, 945, 1444), 'us': Shot(1016, 1047, 1894)}
OTHER = {'jp': 'us', 'us': 'jp'}
PIECES = {'jp': 'japan', 'us': 'usa'}
DISC = {'jp': "Japan's", 'us': "the US disc's"}
PICTURE = (SHOTS['jp'].first, SHOTS['jp'].last)
SLIDE_END = SHOTS['jp'].slide_end
US_SHIFT = SHOTS['us'].first - SHOTS['jp'].first
PICTURE_COLUMNS = 8
TRANSPARENT = 15
HOME = 3080192

def window_offsets():
    """The 280 window cells' byte offsets in the scroll 2 map, row by row."""
    out = []
    for cy in range(ROWS):
        for cx in range(COLS):
            row, col = (ROW0 + cy, COL0 + cx)
            out.append(((row & 15) + ((col & 63) << 4) + ((row & 48) << 6)) * 4)
    return out
OFFSETS = window_offsets()
PICTURE_CELLS = [o for i, o in enumerate(OFFSETS) if i % COLS < PICTURE_COLUMNS]

def records(data):
    """The opening's script records: (bi|fade, pal|cue, delta offset, count|flags, frames, sx, sy)."""
    out, at = ([], SCRIPT)
    while data[at:at + 2] != b'\xff\xff':
        out.append(struct.unpack('>HHIHHHH', data[at:at + 16]))
        at += 16
    return out

def blob(data, record):
    """A record's now-cells and spill cells: [(offset, code, attr)], [(offset, code, attr)]."""
    at = DELTAS + record[2]
    count = record[3] & 8191
    now = [struct.unpack('>HHH', data[at + 6 * k:at + 6 * k + 6]) for k in range(count)]
    spill = []
    if record[3] & SPILL:
        at += 6 * count
        while True:
            n = struct.unpack('>H', data[at:at + 2])[0]
            at += 2
            if n == 65535:
                break
            spill += [struct.unpack('>HHH', data[at + 6 * k:at + 6 * k + 6]) for k in range(n)]
            at += 6 * n
    return (now, spill)

def map_states(data, recs, last, guard=None):
    """The scene window's cells after each event through last, as the engine"""
    state = {o: CLEAR for o in OFFSETS}
    picture = set(PICTURE_CELLS)
    out = []
    for index, record in enumerate(recs[:last + 1]):
        now, spill = blob(data, record)
        if (guard is None or index in guard) and any((o in picture for o, _, _ in spill)):
            raise ValueError(f"event {index} spills a cell into the picture's columns")
        for o, code, attr in now + spill:
            if o in state:
                state[o] = (code, attr)
        out.append(dict(state))
    return out

def picture(state):
    return tuple((state[o] for o in PICTURE_CELLS))

def palette(data, block, slot):
    at = PALBLOCKS + block * 1024 + slot * 32
    return struct.unpack('>16H', data[at:at + 32])

class Art:
    """A region's scene tiles as pens, decoded once each."""

    def __init__(self, art):
        self.art, self.cache = (art, {})

    def pens(self, code):
        if code not in self.cache:
            t = code - ART_BASE
            if not 0 <= t * 128 < len(self.art):
                raise ValueError(f'scroll 2 code {code:#x} is outside the scene art')
            self.cache[code] = regulation.tile_pens(self.art[t * 128:(t + 1) * 128])
        return self.cache[code]

    def used(self, code):
        return {p for row in self.pens(code) for p in row} - {TRANSPARENT}

def flipped(rows, attr):
    if attr & 32:
        rows = [row[::-1] for row in rows]
    if attr & 64:
        rows = rows[::-1]
    return rows

def pixels(art, data, block, cell):
    """A cell as palette words (None where transparent), flips applied."""
    code, attr = cell
    words = palette(data, block, attr & 31)
    return [[None if p == TRANSPARENT else words[p] for p in row] for row in flipped(art.pens(code), attr)]

def flicker_end(states, slide_end):
    """The last event after the slide whose picture is one of the flicker's"""
    two = {picture(states[slide_end + 1]), picture(states[slide_end + 2])}
    if len(two) != 2:
        raise ValueError('the picture does not flicker after the slide')
    j = slide_end + 1
    while j + 1 < len(states) and picture(states[j + 1]) in two:
        j += 1
    return j

def pair(base, other, region='jp'):
    """[(base event, other event)] over the picture, with the records and the"""
    shot, oshot = (SHOTS[region], SHOTS[OTHER[region]])
    name, oname = (DISC[region], DISC[OTHER[region]])
    shift = oshot.first - shot.first
    if oshot.slide_end - oshot.first != shot.slide_end - shot.first:
        raise ValueError('the two slides differ in length')
    brecs, orecs = (records(base['data.bin']), records(other['data.bin']))
    first, last = (shot.first, shot.last)
    for j in range(first, shot.slide_end + 1):
        a, b = (brecs[j], orecs[j + shift])
        if a[4] != b[4] or a[3] & LATE != b[3] & LATE:
            raise ValueError(f'{name} event {j} and {oname} {j + shift} are not the same frame')
    bstates = map_states(base['data.bin'], brecs, len(brecs) - 1, range(first - 1, last + 3))
    ostates = map_states(other['data.bin'], orecs, oshot.slide_end + 2)
    end = flicker_end(bstates, shot.slide_end)
    if last is None:
        raise ValueError(f'{name} flicker ends at event {end}; pin it in SHOTS')
    if end != last:
        raise ValueError(f'{name} flicker ends at event {end}, not {last}')
    a, b = (shot.slide_end + 1, shot.slide_end + 2)
    flicker = {picture(bstates[a]): a + shift, picture(bstates[b]): b + shift}
    if picture(ostates[a + shift]) == picture(ostates[b + shift]):
        raise ValueError(f'{oname} picture does not flicker after the slide')
    pairs = []
    for j in range(first - 1, last + 2):
        if j < first or j > last:
            u = None
        elif j <= shot.slide_end:
            u = j + shift
        else:
            u = flicker.get(picture(bstates[j]))
            if u is None:
                raise ValueError(f'{name} event {j} shows a third picture')
        pairs.append((j, u))
    while brecs[pairs[-1][0]][3] & LATE and brecs[pairs[-1][0]][4] < 2:
        pairs.append((pairs[-1][0] + 1, None))
    return (brecs, orecs, bstates, ostates, pairs)

def pack(cells, slots):
    """Assign each cell's color set to a slot: slots = {slot: (locked words,"""
    added = {s: [] for s in slots}
    where = {}
    for colors in sorted(cells, key=lambda c: (-len(c), sorted(c))):
        best = None
        for s in sorted(slots):
            have = slots[s][0] | set(added[s])
            extra = sorted(colors - have)
            if len(added[s]) + len(extra) <= slots[s][1]:
                score = (len(extra), -len(colors & have), s)
                if best is None or score < best[0]:
                    best = (score, s, extra)
        if best is None:
            raise ValueError("the other picture's colors do not fit the base's free pens")
        _, s, extra = best
        added[s] += extra
        where[colors] = s
    return (where, added)

def build(base, other, first_code, region='jp', counterparts=None):
    """(tiles [(code, 128 bytes)], table bytes, receipt) for an EX edition:"""
    jdata, udata = (base['data.bin'], other['data.bin'])
    jart, uart = (Art(base['art.bin']), Art(other['art.bin']))
    jrecs, urecs, jstates, ustates, pairs = pair(base, other, region)
    first = pairs[0][0]

    def jblock(j):
        return jrecs[j][1] & 255

    def ublock(u):
        return urecs[u][1] & 255
    shown = {}
    for j, u in pairs:
        shown[j] = {}
        if u is None:
            continue
        for o in PICTURE_CELLS:
            jc, uc = (jstates[j][o], ustates[u][o])
            if pixels(jart, jdata, jblock(j), jc) != pixels(uart, udata, ublock(u), uc):
                shown[j][o] = (uc, ublock(u))
    if shown[first] or shown[pairs[-1][0]]:
        raise ValueError("the table's first and last events must show the base's picture")
    blocks = []
    for j, u in pairs:
        if u is not None and (not blocks or blocks[-1][0] != jblock(j)):
            start = j
            while jblock(start - 1) == jblock(j):
                start -= 1
            end = j
            while jblock(end + 1) == jblock(j):
                end += 1
            if jrecs[start][3] & DEFERRED:
                raise ValueError(f'event {start} defers its palette copy')
            blocks.append((jblock(j), start, end))
    palettes, recolor, receipt_blocks = ({}, {}, [])
    for block, start, end in blocks:
        words = {s: palette(jdata, block, s) for s in range(32)}

        def lock(last):
            locked = {s: set() for s in range(32)}
            for j in range(start - 1, last + 1):
                for o in OFFSETS:
                    if o not in shown.get(j, {}):
                        code, attr = jstates[j][o]
                        locked[attr & 31] |= jart.used(code)
            return locked
        cells = {}
        for j, _ in pairs:
            if jblock(j) == block:
                for o, ((code, attr), ub) in shown[j].items():
                    uw = palette(udata, ub, attr & 31)
                    cells[code, ub, attr & 31] = frozenset((uw[p] for p in uart.used(code)))
        lag = 'either side'
        locked = lock(end + 1)
        slots = {s: ({words[s][p] for p in locked[s]}, 15 - len(locked[s])) for s in range(32)}
        try:
            where, added = pack(set(cells.values()), slots)
        except ValueError:
            if not jrecs[end + 1][3] & LATE:
                raise
            lag, locked = ('before', lock(end))
            slots = {s: ({words[s][p] for p in locked[s]}, 15 - len(locked[s])) for s in range(32)}
            where, added = pack(set(cells.values()), slots)
        built = {}
        for s, extra in added.items():
            if not extra:
                continue
            free = [p for p in range(15) if p not in locked[s]]
            pal = list(words[s])
            for p, w in zip(free, extra):
                pal[p] = w
            built[s] = pal
        palettes[block] = built
        for key, colors in cells.items():
            s = where[colors]
            pal = built.get(s, words[s])
            uw = palette(udata, key[1], key[2])
            pen_of = {}
            for p in uart.used(key[0]):
                if uw[p] not in pal[:15]:
                    raise ValueError(f"slot {s} lost the other picture's color {uw[p]:#06x}")
                pen_of[p] = pal.index(uw[p])
            recolor[block, key] = (s, pen_of)
        receipt_blocks.append({'block': block, 'events': [start, end], 'locked': lag, 'slots': {str(s): len(added[s]) for s in sorted(added) if s in set(where.values())}})
    tiles, codes = ([], {})
    for (block, (code, _, _)), (s, pen_of) in sorted(recolor.items()):
        rows = [[TRANSPARENT if p == TRANSPARENT else pen_of[p] for p in row] for row in uart.pens(code)]
        data = regulation.tile_bytes(rows)
        if data not in codes:
            codes[data] = first_code + len(tiles)
            tiles.append((codes[data], data))

    def cell_of(block, shown_cell):
        (code, attr), ub = shown_cell
        s, pen_of = recolor[block, (code, ub, attr & 31)]
        rows = [[TRANSPARENT if p == TRANSPARENT else pen_of[p] for p in row] for row in uart.pens(code)]
        return (codes[regulation.tile_bytes(rows)], attr & ~31 | s)
    lists, entries = ([], [])
    held = {}
    for j, u in pairs:
        block = jblock(j)
        cells = []
        for o in PICTURE_CELLS:
            if o in shown[j]:
                cells.append((o, *cell_of(block, shown[j][o])))
                held[o] = jstates[j][o]
            elif o in held:
                if jstates[j][o] == held[o]:
                    cells.append((o, *jstates[j][o]))
                else:
                    del held[o]
        late = jrecs[j][4] if jrecs[j][3] & LATE and j != first else 0
        pal = block if u is not None and block in palettes else None
        entries.append((late, cells, pal))
    last = pairs[-1][0]
    if shown[last] or (jrecs[last][3] & LATE and jrecs[last][4] < 2):
        raise ValueError("the table's last event must show the base's picture for a vblank of its own")
    head = 4 + 6 * len(entries)
    body, list_at, pal_at = (bytearray(), {}, {})
    for _, cells, _ in entries:
        key = tuple(cells)
        if cells and key not in list_at:
            list_at[key] = head + len(body)
            body += struct.pack('>H', len(cells) - 1)
            for o, code, attr in cells:
                body += struct.pack('>HHH', o, code, attr)
    lists_end = head + len(body)
    for block, built in palettes.items():
        if built:
            pal_at[block] = head + len(body)
            body += struct.pack('>H', len(built) - 1)
            for s, words in sorted(built.items()):
                body += struct.pack('>H16H', s * 32, *words)
    table = bytearray(struct.pack('>HH', first, len(entries)))
    for late, cells, pal in entries:
        table += struct.pack('>HHH', late, list_at[tuple(cells)] if cells else 0, pal_at[pal] if pal is not None else 0)
    table += body
    if any((o >= 32768 for o in PICTURE_CELLS)) or len(table) >= 32768:
        raise ValueError("REG_TV's offsets must fit a signed word")
    if counterparts is not None:
        where = {}
        for j, _ in pairs:
            for o, cell in shown[j].items():
                code, base_code = (cell_of(jblock(j), cell)[0], jstates[j][o][0])
                if code not in where or (where[code] == ART_BASE and base_code != ART_BASE):
                    where[code] = base_code
        counterparts += [{'item': f'tile {code:#x}', 'source': 'art.bin', 'offset': (where[code] - ART_BASE) * 128, 'length': 128} for code, _ in tiles]
        spans = [{'item': 'table lists', 'span': [0, lists_end], 'source': 'data.bin', 'offset': SCRIPT + 16 * first, 'length': 16 * (last - first + 1)}]
        for block, at in pal_at.items():
            spans.append({'item': f'table palettes {block:#x}', 'span': [at, at + 2 + 34 * len(palettes[block])], 'source': 'data.bin', 'offset': PALBLOCKS + block * 1024, 'length': 1024})
        edges = [row['span'] for row in spans]
        if edges[-1][1] != len(table) or any((a[1] != b[0] for a, b in zip(edges, edges[1:]))):
            raise ValueError("REG_TV's keyed spans do not cover the table in order")
        counterparts += spans
    receipt = {'events': [first, pairs[-1][0]], 'picture': {'region': OTHER[region], 'events': [pairs[1][1], max((u for _, u in pairs if u))], 'palette_blocks': sorted({ublock(u) for _, u in pairs if u is not None})}, 'blocks': receipt_blocks, 'tiles': {'first': f'{first_code:#x}', 'count': len(tiles), 'sha256': hashlib.sha256(b''.join((t for _, t in tiles))).hexdigest()}, 'lists': len(list_at), 'table': {'home': f'{HOME:#x}', 'bytes': len(table), 'sha256': hashlib.sha256(table).hexdigest()}}
    return (tiles, bytes(table), receipt)
