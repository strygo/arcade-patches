"""Lay out the English restoration's text as story records and render them."""
from __future__ import annotations
import build_m1_spike as spike
import text_catalog as tc
SCREEN = (384, 224)
LARGE_SPACE, SMALL_SPACE = (16, 32)
SINGLE_HEIGHT = {45, 1510, 1511}
LARGE = {c: g for g, c in tc.ENGLISH.items() if len(c) == 1 and c != ' '}
LARGE.update({"'": 1509, '“': 1510, '”': 1511, ',': 1512, ':': 1513, '(': 1514, ')': 1515, '?': 1516, '!': 1517, '.': 1450, '-': spike.CAPTION_HYPHEN, '9': 1612, '0': 1613})
LARGE.update({str(d): 1575 + d for d in range(1, 9)})
LARGE.pop('"', None)
SMALL_UNITS = {'ft.': 92, 'lb.': 93}
BANDS = {'map': (22, 29), 'story': (20, 27), 'card': (14, 15)}
PROFILE_COL, PROFILE_ROW, PROFILE_WIDTH = (27, 8, 29)
ENDING_COL, ENDING_WIDTH = (32, 24)

def large(text):
    out = []
    for c in text:
        if c == ' ':
            out.append(LARGE_SPACE)
        elif c in LARGE:
            out.append(LARGE[c])
        else:
            raise ValueError(f'the large font has no {c!r} ({text!r})')
    return out

def small(text):
    out, i = ([], 0)
    while i < len(text):
        unit = next((u for u in SMALL_UNITS if text.startswith(u, i) and i and text[i - 1].isdigit()), None)
        if unit:
            out.append(SMALL_UNITS[unit])
            i += len(unit)
            continue
        if not 32 <= ord(text[i]) < 123 or text[i] in '\\[]^_`':
            raise ValueError(f'the small font has no {text[i]!r} ({text!r})')
        out.append(ord(text[i]))
        i += 1
    return out

def words(col, row, pal, glyphs, space):
    """One segment per word: the spaces become cell offsets."""
    segs, start = ([], None)
    for k, g in enumerate(glyphs + [space]):
        if g != space and start is None:
            start = k
        elif g == space and start is not None:
            segs.append({'col': col + start, 'row': row, 'pal': pal, 'glyphs': glyphs[start:k]})
            start = None
    return segs

def caption(lines, band, pal, delay=2):
    if len(lines) > 4:
        raise ValueError('a caption has at most four lines')
    longest = max((len(line) for line in lines))
    col = max(9, (48 - longest) // 2 + 8)
    if col + longest > 56:
        raise ValueError(f'caption line too long for the screen: {longest}')
    top, bottom = BANDS[band]
    first = top + (bottom - top + 1 - 2 * len(lines)) // 2
    if first < top:
        raise ValueError(f'{len(lines)} lines do not fit the {band} band')
    segs = []
    for k, line in enumerate(lines):
        segs += words(col, first + 2 * k, pal, large(line), LARGE_SPACE)
    return {'delay': delay, 'mode': 2, 'segments': segs}

def profile(name, body, pal=14, delay=1, pitch=2):
    """The name line large (two rows), then the body small, ``pitch`` rows"""
    if len(name) > PROFILE_WIDTH or any((len(line) > PROFILE_WIDTH for line in body)):
        raise ValueError('a profile line is wider than the text area')
    top = large(name)
    segs = words(PROFILE_COL, PROFILE_ROW, pal, top, LARGE_SPACE)
    bottom = [LARGE_SPACE if g == LARGE_SPACE else g + 16 if g not in SINGLE_HEIGHT else None for g in top]
    lower = words(PROFILE_COL, PROFILE_ROW + 1, pal, [LARGE_SPACE if g is None else g for g in bottom], LARGE_SPACE)
    segs += lower
    row = PROFILE_ROW + 3
    for line in body:
        if line:
            segs += words(PROFILE_COL, row, pal, small(line), SMALL_SPACE)
            row += pitch
        else:
            row += 1
    if row - pitch > 27:
        raise ValueError(f'the profile runs past its area (row {row - pitch})')
    return {'delay': delay, 'mode': 0, 'segments': segs}

def ending(parts, delay):
    """parts: (palette, lines, first row, pause): ``pause`` spaces typed at"""
    segs = []
    for pal, lines, row, pause in parts:
        if pause:
            segs.append({'col': 0, 'row': 0, 'pal': pal, 'glyphs': [SMALL_SPACE] * pause})
        for i, line in enumerate(lines):
            if len(line) > ENDING_WIDTH:
                raise ValueError(f'ending line wider than {ENDING_WIDTH}: {line!r}')
            segs += words(ENDING_COL, row + 2 * i, pal, small(line), SMALL_SPACE)
    return {'delay': delay, 'mode': 0, 'segments': segs}
BOX_COLS, BOX_CENTER_ROW = ((12, 52), 16)
LIST_LEFT, LEFT_END, LIST_END = (17, 48, 47)
TEXT_PAL = 14

def staff_box(lines):
    longest = max((len(line) for line in lines))
    if longest > BOX_COLS[1] - BOX_COLS[0] - 2:
        raise ValueError(f'a box line is wider than the box: {longest}')
    col = BOX_COLS[0] + (BOX_COLS[1] - BOX_COLS[0] - longest) // 2
    top = BOX_CENTER_ROW - len(lines)
    if top < 8:
        raise ValueError(f'{len(lines)} lines do not fit the box')
    segs = []
    for k, line in enumerate(lines):
        segs += words(col, top + 2 * k, TEXT_PAL, small(line), SMALL_SPACE)
    return segs

def staff_list(entries):
    """entries: (lines, layout) per message, layout as text/english_staff.json"""
    segs = []
    for lines, lay in entries:
        page = 64 * lay['page']
        if lay.get('label'):
            label, lines = (lines[0], lines[1:])
            segs += words(page + lay['label']['col'], lay['label']['row'], lay['label']['pal'], small(label), SMALL_SPACE)
        body = lines[:-1] if lay.get('signature') else lines
        longest = max((len(line) for line in body))
        col = LIST_LEFT if lay['side'] == 'left' else LIST_END - longest
        if col < LIST_LEFT or col + longest > (LEFT_END if lay['side'] == 'left' else LIST_END):
            raise ValueError(f'a staff message is wider than its slot: {body}')
        for k, line in enumerate(body):
            segs += words(page + col, lay['rows'][k], TEXT_PAL, small(line), SMALL_SPACE)
        if lay.get('signature'):
            sig = lines[-1]
            segs += words(page + LIST_END - len(sig), lay['rows'][len(body)], TEXT_PAL, small(sig), SMALL_SPACE)
    return segs

def typing_frames(rec):
    return rec['delay'] * sum((len(s['glyphs']) for s in rec['segments']))
