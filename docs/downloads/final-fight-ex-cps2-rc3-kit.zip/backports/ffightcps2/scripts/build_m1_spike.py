"""Build the milestone 1 spike: stock Japanese Final Fight on our CPS2 layer."""
from __future__ import annotations
import hashlib
import json
import os
from pathlib import Path
import shutil
import struct
import sys
import zipfile
import zlib
import audit_upstream as upstream
import credits
TRACK = Path(__file__).resolve().parents[1]
ROOT = TRACK.parents[1]
LAYER_SOURCE = TRACK / 'asm' / 'hw_layer.asm'
LAYER_HOME = 983040
LAYER_MAGIC = b'FFC2'
DEAD_KEY = b'\xff' * 20
OUT_BASE_LINE = 'OUT_BASE        equ $400000'
FFIGHTJ_PROGRAM = (('ff36.bin', 0, 4188393091), ('ff42.bin', 1, 1710297621), ('ff37.bin', 262144, 3775084420), ('ff43.bin', 262145, 3068060099), ('ffj_34.10f', 524288, 210617340), ('ffj_40.10h', 524289, 2155199161), ('ffj_35.11f', 786432, 1251164449), ('ffj_41.11h', 786433, 720798036))
FFIGHTJ_GFX = (('ffj_09.4b', 0, 1527868685), ('ffj_01.4a', 1, 2170230679), ('ffj_13.9b', 2, 2267129818), ('ffj_05.9a', 3, 3506230453), ('ffj_24.5e', 4, 2712363130), ('ffj_17.5c', 5, 767659252), ('ffj_38.8h', 6, 1698014591), ('ffj_32.8f', 7, 3367782999), ('ffj_10.5b', 1048576, 1649054282), ('ffj_02.5a', 1048577, 1569846932), ('ffj_14.10b', 1048578, 170823937), ('ffj_06.10a', 1048579, 471396418), ('ffj_25.7e', 1048580, 1853981162), ('ffj_18.7c', 1048581, 2979978841), ('ffj_39.9h', 1048582, 2484515959), ('ffj_33.9f', 1048583, 1936325127))
SFA3U_SOUND = (('sz3.01', 3732996228), ('sz3.02', 1917083076), ('sz3.11m', 478801617), ('sz3.12m', 4086477114), ('dl-1425.bin', 3603914485))
EDITIONS = ('japan', 'english', 'usa')
FFIGHTU_PROGRAM = (('ff_36.11f', 0, 4188393091), ('ff_42.11h', 1, 1710297621), ('ff_37.12f', 262144, 3775084420), ('ffu_43.12h', 262145, 1285970247))
FFIGHTU_MASK = ('ff-32m.8h', 524288, 3343346030)
EDITION_LINE = 'EDITION         equ 0'
DIAG_LINE = 'DIAG            equ 0'
EX_LINE = 'EX              equ 0'
EX_ENTRIES = ('ex_next_round', 'ex_capability', 'ex_item_anim', 'ex_s3_block', 'ex_story', 'ex_story_arm', 'ex_blk2', 'ex_blk3', 'ex_arm2', 'ex_close2', 'ex_arm3', 'ex_cue_tail', 'ex_cue_call', 'ex_text_a', 'ex_text_1')
OVERRIDE_TAIL = bytes.fromhex('4bf900ff80004ef900000984')
CUT_PATCHES = ((94354, '302d9288323b00344ebb1030', (('jsr', 'ex_story'), '4e714e714e71'), "CUT SCENES: the story's dispatcher sends scenes 1-4 to EX's engine (SEGA CD) or every scene stock"), (99920, '3b7c138e006e', (('jsr', 'ex_blk2'),), "CUT SCENES: the reunion's pre-roll blackout"), (100026, '1b7c0001008d4eb8283a', (('jsr', 'ex_arm2'), '4e714e71'), "CUT SCENES: the reunion's arm and first lines"), (100044, '303c00544ef809e4', (('jsr', 'ex_cue_tail'), '4e71'), "CUT SCENES: the ending's music (Japan)"), (99890, '303c00544eb809e4', (('jsr', 'ex_cue_call'), '4e71'), "CUT SCENES: the ending's music (export)"), (100116, '1b7c0001008d4ef8283a', (('jsr', 'ex_close2'), '4e714e71'), "CUT SCENES: the reunion's closing lines"), (100970, '3b7c138e006e', (('jsr', 'ex_blk3'),), "CUT SCENES: the farewell's pre-roll blackout"), (101074, '1b7c0001008d4ef8283a', (('jsr', 'ex_arm3'), '4e714e71'), "CUT SCENES: the farewell's arm and lines"), (4878, '43f900067082', (('jsr', 'ex_text_a'),), "CUT SCENES: group A's text table (EX's copy for SEGA CD)"), (4944, '43f900067082', (('jsr', 'ex_text_a'),), "CUT SCENES: group A's text table (EX's copy for SEGA CD)"), (5022, '43f900068566', (('jsr', 'ex_text_1'),), "CUT SCENES: group 1's text table (EX's copy for SEGA CD)"))
TEXT_SITES = (4878, 4944, 5022)
ENGLISH_EX_TEXT = ((4878, '43f9000670823031000043f10000', (('jsr', 'ex_text_ae'), '4e714e714e714e71'), "restoration EX: group A's records, the restoration's or its CD captions' (english_ex.py)"), (4944, '43f9000670823031000043f10000', (('jsr', 'ex_text_ae'), '4e714e714e714e71'), "restoration EX: group A's records, the restoration's or its CD captions' (english_ex.py)"), (5022, '43f9000685663031000043f10000', (('jsr', 'ex_text_1e'), '4e714e714e714e71'), "restoration EX: group 1's records, the restoration's or its CD captions' (english_ex.py)"))
STORY_ARM = 94454
EX_TEXT_HOME = 3153920
EX_BOOT_DATE = '2026-11-03'
TEXT_STOCK = ((427319, 427328),)
FFIGHT_GFX = (('ff-5m.7a', 0, 2619883784), ('ff-7m.9a', 2, 2807582203), ('ff-1m.3a', 4, 190864964), ('ff-3m.5a', 6, 1378426066))
ENGLISH_TILES = 77
ENGLISH_TILE_SPAN = (1119872, 1199616)
ENGLISH_PATCHES = ((3748, '001a', '0039', 'boot warning: the USA warning (draw request 0x39) in the Japanese entry of the table the region word indexes (0x1A Japan, 0x39 USA, 0x1B World)'), (94926, '6704', '4e71', 'intro: the English "Sometime in the 1990\'s..." screen (0xA08, Japan 0xA09)'), (96784, '670e', '600e', 'title: the USA copyright lines (0xA07, Japan 0xA05, World 0xA06)'), (96884, '670a', '600a', 'attract: the USA "Winners Don\'t Use Drugs" FBI screen after the title (13 October)'))
TEXT_FIXES = ((376014, '4441', '4445', 'HUD name table: GRANADE spelled GRENADE'),)
EFFECT_GAINS = {59: -9.0}
START_PATCH = (19528, '422d00c1422d00be422d00bf', '3b7c{:02x}0000be4eb854d44e71', "test kit: every new game starts at the chosen level (the game's stage select, 0x54D4)")
DIAG_PATCH = (1926, '422d91014a2d0084', (('jsr', 'diag_idle'), '4e71'), 'diagnostic kit: the scheduler counts each pass (diag_idle) before its idle checks')
EX_PATCHES = ((21690, '522d00c17000', ('4ef9', ('long', 'ex_next_round')), 'EX: the round advance runs through ex_next_round, which skips the bonus rounds with BONUS STAGE OFF'), (369990, '43fa003422710000', (('jsr', 'ex_item_anim'), '4e71'), "EX: the item spawn takes its animation through ex_item_anim (ARTWORK ARCADE STADIUM's can)"), (405480, '227c00080000d3c0', (('jsr', 'ex_s3_block'), '4e71'), "EX: scroll 3's writer takes its block through ex_s3_block (ARTWORK ARCADE STADIUM's sign)"))
USA_EX_PATCHES = ((99914, '3b7c038492d0', '3b7c000292d0', "US EX: the ending music's countdown 2 frames, not 900: the music starts with the reunion, as Japan's"),)
STAGE_SELECT_PATCHES = ((4456, '4a6d92a2670c', ('4ef9', ('long', 'stage_select_title')), "EX: stage select's code check on the title's Start (its code runs the displaced 18 bytes)"), (19656, '303c00004eb8087e', (('jsr', 'stage_select_charsel'), '4e71'), 'EX: STAGE SELECT after character select, when the code was entered'), (87144, '303c0004323c0002', ('4ef9', ('long', 'stage_select_rank'), '4e71'), 'EX: a stage-select run reports not ranked'))
SFA3U_KEY = ('sfa3u.key', 1250924737)
WATCHDOG = bytes.fromhex('0c801c62f5a8')
WATCHDOG_SLOTS = ('watchdog_reset', 'watchdog_frame')
NOPS3 = bytes.fromhex('4e714e714e71')
SFA3U_PROGRAM = ('sz3u.03c', 'sz3u.04c', 'sz3.05c', 'sz3.06c', 'sz3.07c', 'sz3.08c', 'sz3.09c', 'sz3.10b')
PHOENIX_PROGRAM = ('sz3ud.03c', 'sz3ud.04c') + SFA3U_PROGRAM[2:]
SFA3U_GFX = (('sz3.13m', 'sz3.15m', 'sz3.17m', 'sz3.19m'), ('sz3.14m', 'sz3.16m', 'sz3.18m', 'sz3.20m'))
OBJECT_BYTES = 1114112
SCROLL_BYTES = (1114112, 2097152)
CENSUS = TRACK / 'manifests' / 'priority_census.json'
OVERLAY_TABLE = 1050624
CONVERSION_TABLES = 1572864
S1_BAND = 40
SCROLL2_CODES = (12288, 16384)
SCROLL3_CODES = (2432, 3072)
OVERLAY_MASK_SLOTS = 16
FILTERED_BASE = 131072
SCROLL3_BASE = 196608
SCROLL1_CODES = (17408, 19456)
SCROLL1_BASE = 229376
SCROLL1_TABLE = 2097152
SAFE1_TABLE = 1769472
WIDE_TABLE = 1900544
QSCREEN_TABLE = 3145728
QSOUND_JINGLE = 92
SFA3U_UPPER = (('sz3.09c', 2996720025), ('sz3.10b', 3736272722))
SFA3U_GFX_LOW = (('sz3.13m', 259678425), ('sz3.15m', 2392012609), ('sz3.17m', 3605627207), ('sz3.19m', 4078596746))
QSCREEN_RECORDS = (3866964, 3867156)
QSCREEN_COLUMNS = 12
QSCREEN_PALETTES = ((3408244, 16), (3448788, 48))
QSCREEN_LOGO = (336, 25, 16, 3, 16)
QSCREEN_FILL = (2831, 4930)
QSCREEN_SHA256 = {'records': '58c81c021029161a00f6040cd986d68d5256aa84a7ad4362ce828d3499a6fe2e', 'palettes': 'b5be280c374fdc11bac8e51d88c6247f3fab6423a718a96b07f2ee6e9997d1d4', 'tiles': '861542bc39668cb10333456cdfceaedb863f23d0192c6121febe9d8eacac9adc'}
QSCREEN_LOGO_EDGE = {0: (1599, 12), 1: (2157, 1083), 2: (2971, 2169), 3: (3513, 3240), 5: (1323, 9), 6: (1323, 9), 7: (808, 6), 8: (532, 3)}
TILE_BYTES = 128
TILE3_BYTES = 512
NOP = '4e71'

def jsr(entry):
    return ('jsr', entry)
PATCHES = ((4, '0005e7ac', ('long', 'reset'), 'reset vector to layer initialization'), (112, '00000400', ('long', 'raster'), 'level 4: CPS2 raster interrupt runs the late build'), (120, '00000400', ('long', 'level6'), 'level 6: raster and vblank together'), (1172, '3b7c12ce006e', '3b7c12c0006e', "warm init: scroll layers off until the name screen has cleared the RAM test's text (on CPS2 the vblank shows them before the boot task's clear runs: two frames of shifted text)"), (1368, '00800166', '00800168', 'vblank: B-04 priority mask 1 -> B-21 mask 1'), (1376, '00800170', '0080016a', 'vblank: B-04 priority mask 2 -> B-21 mask 2'), (1384, '00800168', '0080016c', 'vblank: B-04 priority mask 3 -> B-21 mask 3'), (1392, '00800172', '0080016e', 'vblank: B-04 priority mask 4 -> B-21 mask 4'), (1408, '0080016e', '00800166', 'vblank: layer control B-04 -> B-21'), (1412, '33ed009e00800100', (jsr('vblank'), NOP), 'vblank: object conversion and publication'), (1422, '003f', '000f', "vblank: copy palette pages 0-3 only; Final Fight draws no star layers, and on CPS2 hardware each page the CPS-A copies stops the 68000 for about 130 us a frame (jtcps1_dma.v's measurements)"), (1424, '0080016a', '00800170', 'vblank: palette control B-04 -> B-21'), (1506, '4cdf7fff4e73', ('4ef9', ('long', 'vblank_end')), "vblank exit: return the overlay's borrowed palette slots"), (1758, '13ed006a00800030', (jsr('coin'), NOP), 'coin counters/locks to the CPS2 output port'), (1766, '13ed006b00800031', NOP * 4, 'CPS1 coin-control low byte has no CPS2 meaning'), (1780, '103900800018', (jsr('system_d0'),), 'system inputs from CPS2 IN2'), (1792, '103900800018', (jsr('system_d0'),), 'system inputs from CPS2 IN2'), (1822, '123900800018', (jsr('system_d1'),), 'system inputs from CPS2 IN2'), (1834, '10390080001a', (jsr('dswa'),), 'DIP switch A default'), (1846, '10390080001c', (jsr('dswb'),), 'DIP switch B default'), (1858, '10390080001e', (jsr('dswc'),), 'DIP switch C default'), (2478, '00800188', '00ffffe8', "$f9's parameter latch: no QSound counterpart"), (2482, '33c200800180', (jsr('sound_d2'),), 'sound command to the QSound driver'), (2500, '33fc00ff00800180', (jsr('sound_idle'), NOP), 'sound idle frame: post anything queued'), (3126, '103900800018', (jsr('system_d0'),), 'test switch from CPS2 IN2'), (3176, '610001fa303c0080', (jsr('qsound'), NOP), "boot: Final Fight's warning, then SFA3's QSound screen and jingle"), (3214, '00800001', '00804001', 'player 1 input byte: CPS2 IN0'), (3274, '0005ebae', ('long', 'menu'), 'test switch starts the CPS2-style TEST MENU'), (9770, '41f90090c000', ('4ef9', ('long', 'map2_clear')), "scroll 2 clear also empties the overlay's column cache"), (11056, '00800000', '00804000', 'player inputs: CPS2 IN0'), (11102, '00800000', '00804000', 'player inputs: CPS2 IN0'), (11582, '00800000', '00804000', 'player inputs: CPS2 IN0'), (18274, '207c0090c000', ('4ef9', ('long', 'map2_block')), "scroll 2 block address step also marks the block's columns for the overlay"), (credits.CREDITS_POINTER, '00018f94', f'{credits.CREDITS_HOME:08x}', "the staff roll, with the port's credit (credits.py), from the upper ROM"), (137406, '227c000218e2', (jsr('reg_cut'),), "a blood object's animation: white with REGULATION ON"), (349486, '102e00144ef83ad6', ('4ef9', ('long', 'reg_effect'), NOP), "the hit effect's animation: blood white with REGULATION ON"), (387000, '13fc008000800030', NOP * 4, 'CPS1 coin-control reset pulse'), (387016, '13fc000000800030', NOP * 4, 'CPS1 coin-control reset pulse'), (387036, '0080016e', '00800166', 'init: layer control B-04 -> B-21'), (387150, '6702', '6002', 'init: skip the CPS-B-04 ID check'), (387966, '003f', '000f', "init: copy palette pages 0-3 only (as the vblank's)"), (387968, '0080016a', '00800170', 'init: palette control B-04 -> B-21'), (388216, '61001586610015cc4e75', ('207c', ('long', 'menu_resume'), '4eb80924'), 'a finished stock test returns to the CPS2-style TEST MENU'), (390658, '00800180', '00ffffea', 'OUTPUT test idle byte: no QSound counterpart'), (390670, '33c400800180', (jsr('sound_d4'),), 'OUTPUT test sound code to the QSound driver'), (390678, '33fc00f000800180', (jsr('sound_stop'), NOP), 'OUTPUT test stop to the QSound driver'), (390690, '00800188', '00ffffe8', 'OUTPUT test parameter latch: no QSound counterpart'), (404224, '3a2e00063b45002a', (jsr('stream_begin'), NOP), 'scroll 2 screen stream: note it runs, so the vblank keeps the view on screen until it ends'), (404274, '51ccffea4e75', ('4ef9', ('long', 'stream_end')), "scroll 2 screen stream: its column loop's end clears the note"), (405252, '30910658300030e9', ('4ef9', ('long', 'map2_column'), '4e71'), 'scroll 2 column streaming also marks the column for the overlay'), (405650, '309106503000316900020002', ('4ef9', ('long', 'map2_row'), '4e714e714e71'), 'scroll 2 row streaming also marks its columns for the overlay'), (465372, '00800000', '00804000', 'player inputs: CPS2 IN0'), (467240, '00800000', '00804000', 'player inputs: CPS2 IN0'), (467430, '00800000', '00804000', 'player inputs: CPS2 IN0'))
SOUND_CONTROLS = {240: ((65280, 0),), 241: tuple(((65282, c) for c in (6, 7))), 242: tuple(((65282, c) for c in range(8, 12))), 243: ((65282, 8),), 244: ((65282, 9),), 245: ((65282, 10),), 246: ((65282, 11),), 247: ((65285, 0),)}
ENTRY_ORDER = ('reset', 'vblank', 'system_d0', 'system_d1', 'dswa', 'dswb', 'dswc', 'coin', 'menu', 'menu_resume', 'vblank_end', 'raster', 'level6', 'map2_column', 'map2_row', 'map2_block', 'map2_clear', 'sound_d2', 'sound_d4', 'sound_stop', 'sound_idle', 'qsound', 'watchdog_reset', 'watchdog_frame', 'stream_begin', 'stream_end', 'reg_effect', 'reg_cut')

def sha256(data):
    return hashlib.sha256(data).hexdigest()

def identity(data):
    return {'bytes': len(data), 'sha256': sha256(data), 'crc32': f'{zlib.crc32(data):08x}'}

def default_rompaths():
    paths = [ROOT / 'roms', ROOT / 'roms' / 'mame0260']
    paths += [Path(p) for p in os.environ.get('CAPCOM_ARCADE_ROM_PATH', '').split(os.pathsep) if p]
    return paths

def find_archive(rompaths, stem):
    for base in rompaths:
        try:
            return upstream.archive(Path(base), stem)
        except ValueError:
            continue
    raise ValueError(f'missing canonical {stem}.zip or {stem}.7z in the ROM paths')

def read_checked(archive, name, crc):
    data = upstream.member(archive, name)
    if zlib.crc32(data) != crc:
        raise ValueError(f'{archive.name}:{name} CRC {zlib.crc32(data):08x}, expected {crc:08x}')
    return data

def watchdog_words(key):
    """The key's watchdog instruction words: decoded words 6, 5 and 4."""
    sys.path.insert(0, str(Path(__file__).resolve().parents[3] / 'extraction'))
    from cps2_crypt import decode_key
    decoded = decode_key(key)[3]
    return struct.pack('>3H', decoded[6], decoded[5], decoded[4])

def install_watchdog(program, entries, key):
    words = watchdog_words(key)
    if words != WATCHDOG:
        raise ValueError(f"the key's watchdog is {words.hex()}, not the pinned {WATCHDOG.hex()}")
    for name in WATCHDOG_SLOTS:
        at = entries[name]
        if program[at:at + 6] != NOPS3:
            raise ValueError(f'watchdog slot {name} at {at:#x} is not three no-ops')
        program[at:at + 6] = words
    return {'words': words.hex(), 'slots': {name: f'{entries[name]:#x}' for name in WATCHDOG_SLOTS}}

def stock_program(ffightj):
    program = bytearray(1048576)
    for name, offset, crc in FFIGHTJ_PROGRAM:
        data = read_checked(ffightj, name, crc)
        program[offset:offset + 262144:2] = data
    return program

def usa_program(ffightu):
    program = bytearray(1048576)
    for name, offset, crc in FFIGHTU_PROGRAM:
        program[offset:offset + 262144:2] = read_checked(ffightu, name, crc)
    name, offset, crc = FFIGHTU_MASK
    data = read_checked(ffightu, name, crc)
    program[offset:offset + 524288:2] = data[1::2]
    program[offset + 1:offset + 524288:2] = data[0::2]
    return program

def unshuffle(data, bank_size=2097152):
    """The inverse of upstream.reshuffle: a graphics image in the linear layout."""
    result = bytearray(len(data))
    half = bank_size // 2
    for start in range(0, len(data), bank_size):
        end = start + bank_size
        for lane in range(8):
            result[start + lane:start + half:8] = data[start + lane:end:16]
            result[start + half + lane:end:8] = data[start + 8 + lane:end:16]
    return bytes(result)

def scan1(row, col):
    """Scroll 1 map index of a cell (MAME's tilemap0_scan)."""
    return (row & 31) + ((col & 63) << 5) + ((row & 32) << 6)

def qsound_screen(rompaths):
    """(table, graphics pieces, receipt) for SFA3's QSound screen."""
    sfa3u = find_archive(rompaths, 'sfa3u')
    upper = b''.join((upstream.swap_words(read_checked(sfa3u, n, c)) for n, c in SFA3U_UPPER))

    def prog(address, size):
        return upper[address - 3145728:address - 3145728 + size]
    records = b''.join((prog(r, 192) for r in QSCREEN_RECORDS))
    palettes = b''.join((prog(a, 2 * n) for a, n in QSCREEN_PALETTES))
    cells3 = []
    for r in range(len(QSCREEN_RECORDS)):
        codes = struct.unpack_from('>64H', records, 192 * r)
        for i, (code, attr) in enumerate(zip(codes, records[192 * r + 128:192 * r + 192])):
            if 64 * r + i >= 8 * QSCREEN_COLUMNS:
                break
            code = code + 2816 & 65535
            cells3.append((4 * (64 * r + i), QSCREEN_FILL[1] if code == QSCREEN_FILL[0] else code, attr))
    first, row0, col0, rows, cols = QSCREEN_LOGO
    cells1 = [(4 * scan1(row0 + r, col0 + c), first + cols * r + c, 1) for r in range(rows) for c in range(cols)]
    part = bytearray(16777216)
    for lane, (name, crc) in enumerate(SFA3U_GFX_LOW):
        data = read_checked(sfa3u, name, crc)
        part[lane * 2::8] = data[0::2]
        part[lane * 2 + 1::8] = data[1::2]
    layout = unshuffle(bytes(part))
    codes3 = sorted({code for _, code, _ in cells3} - {QSCREEN_FILL[1]})
    pieces = [(8388608 + 512 * c, layout[8388608 + 512 * c:8388608 + 512 * (c + 1)]) for c in codes3]
    pieces.append((8388608 + 512 * QSCREEN_FILL[1], layout[8388608 + 512 * QSCREEN_FILL[0]:8388608 + 512 * (QSCREEN_FILL[0] + 1)]))
    logo = range(first, first + rows * cols)
    pieces.append((8388608 + 64 * first, layout[8388608 + 64 * first:8388608 + 64 * logo.stop]))
    found = {'records': sha256(records), 'palettes': sha256(palettes), 'tiles': sha256(b''.join((data for _, data in pieces)))}
    if QSCREEN_SHA256 and found != QSCREEN_SHA256:
        raise ValueError(f"sfa3u's QSound screen does not match its pinned hashes: {found}")
    palettes = bytearray(palettes)
    for pen, (theirs, ours) in QSCREEN_LOGO_EDGE.items():
        if struct.unpack_from('>H', palettes, 2 * pen)[0] != theirs:
            raise ValueError(f"the CAPCOM logo's pen {pen} is not SFA3's {theirs:04x}")
        struct.pack_into('>H', palettes, 2 * pen, ours)
    table = bytearray()
    for cells in (cells3, cells1):
        table += struct.pack('>H', len(cells))
        for offset, code, attr in cells:
            table += struct.pack('>HHH', offset, code, attr)
    table += palettes
    return (bytes(table), pieces, {'home': f'{QSCREEN_TABLE:#x}', **identity(bytes(table)), 'sources': found, 'scroll3_tiles': [f'{codes3[0]:04x}', f'{codes3[-1]:04x}', len(codes3)], 'fill_tile': f'{QSCREEN_FILL[1]:04x}', 'logo_edge': {str(pen): [f'{a:04x}', f'{b:04x}'] for pen, (a, b) in QSCREEN_LOGO_EDGE.items()}})

def world_graphics(ffight):
    region = bytearray(2097152)
    for name, base, crc in FFIGHT_GFX:
        data = read_checked(ffight, name, crc)
        for i in range(0, len(data), 2):
            at = base + i // 2 * 8
            region[at:at + 2] = data[i:i + 2]
    return region
CAPTION_HYPHEN = 15424

def caption_hyphen(region):
    """The caption hyphen's two tiles as (CPS2 layout offset, bytes) pieces:"""
    dash = 17453 * 64
    if region[dash + 24:dash + 40] == b'\xff' * 16 or any((b != 255 for b in region[dash:dash + 24] + region[dash + 40:dash + 64])):
        raise ValueError('the 8x8 hyphen is not a bar on rows 3-4')
    tile = bytearray(b'\xff' * 64)
    tile[48:64] = region[dash + 24:dash + 40]
    top = 8388608 + (17408 + CAPTION_HYPHEN) * 64
    return [(top, bytes(tile)), (top + 16 * 64, b'\xff' * 64)]

def english_text(region, world):
    """Copy the World set's scroll 1 text tiles over the Japanese ones. The"""
    units = [a for a in range(0, len(region), 128) if region[a:a + 128] != world[a:a + 128]]
    if len(units) != ENGLISH_TILES or not all((ENGLISH_TILE_SPAN[0] <= a < ENGLISH_TILE_SPAN[1] for a in units)):
        raise ValueError(f'the Japanese and World graphics differ in {len(units)} units, not the {ENGLISH_TILES} scroll 1 text tiles')
    for a in units:
        region[a:a + 128] = world[a:a + 128]
    return {'units': len(units), 'span': [f'{units[0]:#x}', f'{units[-1] + 128:#x}'], 'sha256': sha256(b''.join((bytes(world[a:a + 128]) for a in units)))}

def stock_graphics(ffightj):
    region = bytearray(2097152)
    for name, offset, crc in FFIGHTJ_GFX:
        region[offset:offset + 1048576:8] = read_checked(ffightj, name, crc)
    return region
SELECT_WINDOW_PIXELS = ((2512, 24, 30), (2513, 8, 30), (2513, 8, 24), (2513, 8, 25))
SELECT_WINDOW_SCREEN = ((56, 46), (200, 46), (328, 46), (72, 40), (72, 41), (200, 40), (200, 41), (328, 40), (328, 41))

def scroll3_pen(region, code, x, y):
    at = code * TILE3_BYTES + y * 16 + x // 8 * 4
    return sum(((region[at + k] >> 7 - x % 8 & 1) << k for k in range(4)))

def repair_select_windows(region):
    for code, x, y in SELECT_WINDOW_PIXELS:
        if scroll3_pen(region, code, x, y) != 15:
            raise ValueError(f'select window hole moved: tile {code:04x} ({x},{y})')
        neighbors = (x - 2, x - 1, x + 1, x + 2) if y == 30 else (x - 2, x - 1)
        if any((scroll3_pen(region, code, n, y) != 9 for n in neighbors)):
            raise ValueError(f'select window neighbors changed: tile {code:04x} ({x},{y})')
        at = code * TILE3_BYTES + y * 16 + x // 8 * 4
        bit = 1 << 7 - x % 8
        for k in range(4):
            region[at + k] = region[at + k] & ~bit | (bit if 9 >> k & 1 else 0)

def cps2_graphics(region, filtered=b'', blocks=b'', scroll1=b'', extra=()):
    """sfa3u graphics members: objects, scroll tiles at +0x800000, and the"""
    first2 = (FILTERED_BASE - 65536) * TILE_BYTES + 8388608
    first3 = (SCROLL3_BASE - 65536) * TILE_BYTES + 8388608
    first1 = (SCROLL1_BASE - 65536) * TILE_BYTES + 8388608
    if first2 + len(filtered) > first3 or first3 + len(blocks) > first1 or first1 + len(scroll1) > 33554432:
        raise ValueError('overlay tiles exceed their graphics areas')
    layout = bytearray(b'\xff' * 33554432)
    layout[:OBJECT_BYTES] = region[:OBJECT_BYTES]
    start, end = SCROLL_BYTES
    layout[8388608 + start:8388608 + end] = region[start:end]
    layout[first2:first2 + len(filtered)] = filtered
    layout[first3:first3 + len(blocks)] = blocks
    layout[first1:first1 + len(scroll1)] = scroll1
    for at, data in extra:
        if any((b != 255 for b in layout[at:at + len(data)])):
            raise ValueError(f'graphics at {at:#x} are not free')
        layout[at:at + len(data)] = data
    shuffled = upstream.reshuffle(bytes(layout))
    members = {}
    for half, names in enumerate(SFA3U_GFX):
        part = shuffled[half * 16777216:(half + 1) * 16777216]
        for lane, name in enumerate(names):
            data = bytearray(4194304)
            data[0::2] = part[lane * 2::8]
            data[1::2] = part[lane * 2 + 1::8]
            members[name] = bytes(data)
    return members

def _lane0(size):
    return int.from_bytes(bytes([255, 0, 0, 0]) * (size // 4), 'big')

def tile_planes(tile):
    whole = int.from_bytes(tile, 'big')
    lane = _lane0(len(tile))
    return [whole << 8 * k & lane for k in range(4)]

def pen_pixels(planes, size=TILE_BYTES):
    """Per pen 0-15, the pixels drawn with it, in plane-0 lanes."""
    lane = _lane0(size)
    result = []
    for pen in range(16):
        pixels = lane
        for k, plane in enumerate(planes):
            pixels &= plane if pen >> k & 1 else ~plane
        result.append(pixels & lane)
    return result

def filtered_tile(planes, keep, size=TILE_BYTES):
    """The tile with every pixel outside ``keep`` set to pen 15 (transparent)."""
    lane = _lane0(size)
    whole = 0
    for k, plane in enumerate(planes):
        whole |= (plane & keep | lane & ~keep) >> 8 * k
    return whole.to_bytes(size, 'big')

def quadrants(tile3):
    """A 32x32 tile as four 16x16 object tiles: top left, top right, bottom"""
    result = []
    for qy in range(2):
        for qx in range(2):
            result.append(b''.join((tile3[(qy * 16 + r) * 16 + qx * 8:(qy * 16 + r) * 16 + qx * 8 + 8] for r in range(16))))
    return result

def block_code(index):
    """Object code of 2x2 block ``index``: CPS2 draws a block from codes"""
    return SCROLL3_BASE + index // 8 * 32 + index % 8 * 2

def conversion_tables():
    """CPS2 X and Y words for CPS1 object positions. CPS1 uses 9 bits and"""
    xs = [(x | (512 if x >= 448 else 0)) - 64 & 1023 | 8192 for x in range(512)]
    ys = [(y | (512 if y >= 256 else 0)) - 16 & 1023 for y in range(512)]
    bands = [y | 32768 if y < S1_BAND or y >= 768 else y for y in ys]
    tables = [bytearray(struct.pack('>512H', *values) * 64) for values in (xs, ys, bands)]
    struct.pack_into('>H', tables[2], 32768, ys[0])
    return b''.join(tables)

def wide_table():
    """Y words with bit 15 set for every raw word but 0 (hw_layer.asm's"""
    ys = [(y | (512 if y >= 256 else 0)) - 16 & 1023 for y in range(512)]
    table = bytearray(struct.pack('>512H', *(y | 32768 for y in ys)) * 64)
    struct.pack_into('>H', table, 32768, ys[0])
    return bytes(table)

def scroll1_object(region, code, parity):
    """A 16x16 object tile holding scroll 1 tile ``code`` in its top-left"""
    rows = []
    for r in range(8):
        at = code * 64 + r * 8 + 4 * parity
        rows.append(bytes(region[at:at + 4]) + b'\xff' * 4)
    return b''.join(rows) + b'\xff' * 64

def safe_tables1(region, masks):
    """Where a sprite may sit under scroll 1 (hw_layer.asm's s1_safe): per"""
    first, last = SCROLL1_CODES
    opaque = []
    for parity in (0, 1):
        for code in range(first, last):
            pixels = pen_pixels(tile_planes(scroll1_object(region, code, parity)))
            opaque.append(sum((1 << pen for pen in range(15) if pixels[pen])))
    parts = [0] + list(masks) + [0] * (OVERLAY_MASK_SLOTS - len(masks))
    return b''.join((bytes((1 if not pens & ~mask else 0 for pens in opaque)) for mask in parts))

def overlay_tables1(region, masks, layer_masks):
    """The scroll 1 part: per mask slot, per column parity, a long per code"""
    first, last = SCROLL1_CODES
    count = last - first
    entries = [[0] * (2 * count) for _ in range(OVERLAY_MASK_SLOTS)]
    images = bytearray()
    index = {}
    counts = {'objects': 0, 'entries': 0}
    for code in range(first, last):
        for parity in (0, 1):
            tile = scroll1_object(region, code, parity)
            planes = tile_planes(tile)
            pixels = pen_pixels(planes)
            opaque = sum((1 << pen for pen in range(15) if pixels[pen]))
            for slot, mask in enumerate(masks):
                if mask not in layer_masks or not opaque & mask:
                    continue
                if not opaque & ~mask:
                    image = tile
                else:
                    keep = 0
                    for pen in range(15):
                        if mask >> pen & 1:
                            keep |= pixels[pen]
                    image = filtered_tile(planes, keep)
                number = index.get(image)
                if number is None:
                    number = SCROLL1_BASE + len(images) // TILE_BYTES
                    index[image] = number
                    images += image
                    counts['objects'] += 1
                entries[slot][parity * count + code - first] = number >> 16 << 13 << 16 | number & 65535
                counts['entries'] += 1
    table = b''.join((struct.pack(f'>{2 * count}I', *entries[slot]) for slot in range(OVERLAY_MASK_SLOTS)))
    return (table, bytes(images), counts)

def layer_masks(census, layer):
    return {int(p['mask'], 16) for p in census['tile_mask_pairs'] if p['layer'] == layer}

def census_masks(census):
    masks = sorted({int(pair['mask'], 16) for pair in census['tile_mask_pairs']})
    if not 0 < len(masks) <= OVERLAY_MASK_SLOTS or any((m & 32768 or not m for m in masks)):
        raise ValueError('census mask values do not fit the overlay table')
    return masks

def overlay_tables(region, masks):
    """Returns the upper-ROM table, the filtered tile bytes and counts."""
    first, last = SCROLL2_CODES
    pens_table = bytearray()
    objects = []
    filtered = bytearray()
    counts = {'direct': 0, 'filtered': 0, 'nothing_high': 0}
    for code in range(first, last):
        planes = tile_planes(region[code * TILE_BYTES:(code + 1) * TILE_BYTES])
        pixels = pen_pixels(planes)
        used = sum((1 << pen for pen in range(16) if pixels[pen]))
        pens_table += struct.pack('>H', used)
        slots = []
        for mask in masks:
            opaque = used & 32767
            if not opaque & mask:
                slots.append(0)
                counts['nothing_high'] += 1
            elif not opaque & ~mask:
                slots.append(8192 << 16 | code)
                counts['direct'] += 1
            else:
                keep = 0
                for pen in range(15):
                    if mask >> pen & 1:
                        keep |= pixels[pen]
                index = len(filtered) // TILE_BYTES
                filtered += filtered_tile(planes, keep)
                number = FILTERED_BASE + index
                slots.append(number >> 16 << 13 << 16 | number & 65535)
                counts['filtered'] += 1
        slots += [0] * (OVERLAY_MASK_SLOTS - len(slots))
        objects.append(slots)
    by_slot = b''.join((struct.pack(f'>{len(objects)}I', *(row[slot] for row in objects)) for slot in range(OVERLAY_MASK_SLOTS)))
    head = struct.pack(f'>{OVERLAY_MASK_SLOTS}H', *masks + [0] * (OVERLAY_MASK_SLOTS - len(masks)))
    return (bytes(head + pens_table + by_slot), bytes(filtered), counts)

def overlay_tables3(region, masks):
    """The scroll 3 part: per code the pens it uses, then per code 16 longs"""
    first, last = SCROLL3_CODES
    pens_table = bytearray()
    objects = bytearray()
    blocks = bytearray()
    counts = {'blocks': 0, 'nothing_high': 0}

    def add(tile3):
        code = block_code(counts['blocks'])
        while len(blocks) < (code - SCROLL3_BASE + 18) * TILE_BYTES:
            blocks.extend(b'\xff' * TILE_BYTES)
        for q, data in zip((0, 1, 16, 17), quadrants(tile3)):
            at = (code - SCROLL3_BASE + q) * TILE_BYTES
            blocks[at:at + TILE_BYTES] = data
        counts['blocks'] += 1
        return code >> 16 << 13 << 16 | code & 65535
    for code in range(first, last):
        tile3 = bytes(region[code * TILE3_BYTES:(code + 1) * TILE3_BYTES])
        planes = tile_planes(tile3)
        pixels = pen_pixels(planes, TILE3_BYTES)
        used = sum((1 << pen for pen in range(16) if pixels[pen]))
        pens_table += struct.pack('>H', used)
        opaque = used & 32767
        whole = None
        slots = []
        for mask in masks:
            if not opaque & mask:
                slots.append(0)
                counts['nothing_high'] += 1
            elif not opaque & ~mask:
                if whole is None:
                    whole = add(tile3)
                slots.append(whole)
            else:
                keep = 0
                for pen in range(15):
                    if mask >> pen & 1:
                        keep |= pixels[pen]
                slots.append(add(filtered_tile(planes, keep, TILE3_BYTES)))
        slots += [0] * (OVERLAY_MASK_SLOTS - len(slots))
        objects += struct.pack(f'>{OVERLAY_MASK_SLOTS}I', *slots)
    return (bytes(pens_table + objects), bytes(blocks), counts)

def fs_cd_song():
    import ff_sound
    return ff_sound.CD_OPENING

def arcade_rounds():
    import english_records
    return english_records.ARCADE_OPENING_ROUNDS

def fs_cd_rounds(edition):
    import ff_sound
    return ff_sound.CD_OPENING_ROUNDS[edition]

def fs_cd_ending(edition):
    import ff_sound
    return (ff_sound.cd_ending(edition), ff_sound.CD_ENDING_PASSES[edition])

def boot_yymmdd():
    return EX_BOOT_DATE[2:4] + EX_BOOT_DATE[5:7] + EX_BOOT_DATE[8:10]

def console_phase(program, members, entries, layer_size, ex_equates, edition, key, work, kit, program_names):
    """(program, members, receipt) with Console mode and Time Attack composed over the EX build"""
    if kit is None:
        raise ValueError('This recipient requires prepared kit')
    import console_compose
    raw = bytes(program)
    img = kit.disc_image(edition)
    assemble = lambda: kit.console_layer(raw, edition, img)
    ta_graphics = lambda: kit.ta_graphics(img)
    ta_receipt = None
    composed, members, receipt = console_compose.compose(raw, members, entries, layer_size, ex_equates, edition, assemble, key, ta_graphics=ta_graphics, time_attack_mode=True, img=img, program_names=program_names)
    if ta_receipt is not None:
        receipt['time_attack'] = ta_receipt
    return (bytearray(composed), members, receipt)

def boot_identity(program, edition):
    """The EX name screen's rows as the layer's menu_print records hold them, with the program address"""
    region = 'USA' if edition != 'japan' else 'JAPAN'
    date = bytes([18, 12, 1]) + ' '.join(boot_yymmdd()).encode() + b'\x00'
    at = program.find(date)
    if at < 0 or program.find(date, at + 1) >= 0:
        raise ValueError("the name screen's date record is not in the program exactly once")
    return {'rows': ['FINAL FIGHT EX', boot_yymmdd(), region], 'release_date': EX_BOOT_DATE, 'date_byte_address': f'{at + 3:#x}', 'encoding': 'spaced-yymmdd'}

def encode(replacement, entries):
    if isinstance(replacement, str):
        return bytes.fromhex(replacement)
    if replacement[0] == 'long':
        return struct.pack('>I', entries[replacement[1]])
    data = b''
    for part in replacement:
        if isinstance(part, str):
            data += bytes.fromhex(part)
        elif part[0] == 'long':
            data += struct.pack('>I', entries[part[1]])
        else:
            data += bytes.fromhex('4eb9') + struct.pack('>I', entries[part[1]])
    return data

def apply_patches(program, entries, patches=PATCHES, covered=None):
    applied = []
    covered = set() if covered is None else covered
    for address, stock_hex, replacement, reason in patches:
        stock = bytes.fromhex(stock_hex)
        new = encode(replacement, entries)
        if len(new) != len(stock):
            raise ValueError(f'patch {address:#x} changes length')
        span = set(range(address, address + len(stock)))
        if span & covered:
            raise ValueError(f'patch {address:#x} overlaps another patch')
        covered |= span
        if program[address:address + len(stock)] != stock:
            raise ValueError(f'stock bytes differ at {address:#x}')
        program[address:address + len(stock)] = new
        applied.append({'address': f'{address:#08x}', 'stock': stock_hex, 'new': new.hex(), 'reason': reason})
    return applied

def text_catalog_block(program):
    """(start, end) of the text block EX's captions edit: group A's offsets"""
    import usa_text
    import text_catalog as tc
    image = bytes(program)
    end = 0
    for index in range(tc.word(image, tc.GROUP1) // 2):
        end = max(end, usa_text.parse(image, tc.GROUP1 + tc.word(image, tc.GROUP1 + 2 * index))['end'])
    return (tc.GROUPA, end + 1 & ~1)

def build(rompaths, work, phoenix=False, encrypted=False, edition='japan', gray_blood=True, start_level=None, effect_gains=None, diag=False, ex=False, kit=None):
    """phoenix: development only. Assemble the layer for the dead-board"""
    if kit is None:
        raise ValueError('This recipient requires prepared kit')
    if phoenix is not True:
        raise ValueError('Unsupported recipient build mode')
    if encrypted is not False:
        raise ValueError('Unsupported recipient build mode')
    if diag is not False:
        raise ValueError('Unsupported recipient build mode')
    if ex is not True:
        raise ValueError('Unsupported recipient build mode')
    if edition not in EDITIONS:
        raise ValueError(f'edition must be one of {EDITIONS}')
    work.mkdir(parents=True, exist_ok=True)
    source = find_archive(rompaths, 'ffightu' if edition == 'usa' else 'ffightj')
    sfa3u = find_archive(rompaths, 'sfa3u')
    stock = usa_program(source) if edition == 'usa' else stock_program(source)
    if stock[1026:1048] != bytes.fromhex('4bf88000207c00ff0000303c3ffb720020c151c8fffc'):
        raise ValueError('native warm initialization no longer matches direct service entry')
    program = bytearray(b'\xff' * 4194304)
    program[:1048576] = stock
    scenes = None
    import ex_scenes
    scenes = kit.pieces(edition)
    ex_equates = None
    scene = {k: int(v, 16) for k, v in scenes['manifest']['entries'].items() if isinstance(v, str)}
    arm = bytes(stock[STORY_ARM:STORY_ARM + 6])
    if arm[:2] != b';|' or arm[4:] != b'\x92\xb0':
        raise ValueError("the story's arm is not move.w #n,$92b0(a5)")
    ex_equates = {'EX_OBJHOOK': scene['objhook'], 'SC_ENGINE': scene['ENGINE'], 'SC_INIT': scene['init'], 'SC_INIT2': scene['init2'], 'SC_BLK2': scene['blk2'], 'SC_INIT3': scene['init3'], 'SC_BLK3': scene['blk3'], 'SC_STORY_ARM': int.from_bytes(arm[2:4], 'big'), 'SC_TEXT': EX_TEXT_HOME}
    import ex_arrange
    ex_equates['EX_CLASSES'] = ex_arrange.HOME
    ex_equates['CD_SONG'] = fs_cd_song()
    ex_equates['CD_ENDING'] = fs_cd_ending(edition)[0]
    ex_equates['BOOT_DATE'] = int(boot_yymmdd(), 16)
    if edition == 'english':
        ex_equates['EX_OPEN_EN'] = ex_arrange.restoration_word()
    import ex_regulation
    ex_equates['REG_TV'] = ex_regulation.HOME
    english_ex_block = None
    if edition == 'english':
        import english_ex
        import english_records
        english_story, _ = english_records.build(stock)
        data, caption_timing = english_ex.retime(scenes['data.bin'])
        import english_mouths
        data, lips = english_mouths.apply(data, scenes['program.bin'])
        scenes = {**scenes, 'data.bin': data}
        _, _, table_1, table_a = english_ex.english_tables(english_story, stock)
        english_ex_block, english_ex_receipt, (cd_1, cd_a) = english_ex.build(stock, scenes['program.bin'], scenes['data.bin'], english_story)
        ex_equates.update({'EN_TABLE_1': table_1, 'EN_TABLE_A': table_a, 'EN_CD_1': cd_1, 'EN_CD_A': cd_a})
    blob, entries = kit.layer(work, phoenix, edition, diag, ex, ex_equates)
    if any((b != 255 for b in stock[LAYER_HOME:LAYER_HOME + len(blob)])):
        raise ValueError('layer home is not free in the stock program')
    sys.path.insert(0, str(ROOT / 'extraction'))
    from cps2_code_guard import require_code_spans
    require_code_spans([{'name': 'hw_layer', 'start': LAYER_HOME, 'size': len(blob)}], key=read_checked(sfa3u, *SFA3U_KEY))
    program[LAYER_HOME:LAYER_HOME + len(blob)] = blob
    covered = set()
    applied = apply_patches(program, entries, PATCHES, covered)
    applied += apply_patches(program, entries, TEXT_FIXES, covered)
    if start_level is not None:
        address, stock_hex, new_hex, reason = START_PATCH
        applied += apply_patches(program, entries, ((address, stock_hex, new_hex.format(start_level), reason),), covered)
    stage_receipt = None
    stage_code_spans = []
    classes = ex_arrange.classes(edition)
    if any((b != 255 for b in program[ex_arrange.HOME:ex_arrange.HOME + len(classes)])):
        raise ValueError(f"EX_CLASSES's home {ex_arrange.HOME:#x} is not free")
    program[ex_arrange.HOME:ex_arrange.HOME + len(classes)] = classes
    applied += apply_patches(program, entries, EX_PATCHES, covered)
    if edition == 'usa':
        applied += apply_patches(program, entries, USA_EX_PATCHES, covered)
    arm_hex = bytes(stock[STORY_ARM:STORY_ARM + 6]).hex()
    cuts = CUT_PATCHES
    if edition == 'english':
        cuts = tuple((p for p in CUT_PATCHES if p[0] not in TEXT_SITES)) + ENGLISH_EX_TEXT
        if any((b != 255 for b in program[english_ex.HOME:english_ex.HOME + len(english_ex_block)])):
            raise ValueError(f"the restoration EX's caption home {english_ex.HOME:#x} is not free")
        program[english_ex.HOME:english_ex.HOME + len(english_ex_block)] = english_ex_block
    applied += apply_patches(program, entries, cuts + ((STORY_ARM, arm_hex, (('jsr', 'ex_story_arm'),), "CUT SCENES: the story's arm"),), covered)
    sys.path.insert(0, str(ROOT / 'backports' / 'ffightcd' / 'build'))
    import stage_select
    title = stage_select.check(lambda address, length: bytes(program[address:address + length]), ending=True, hide_prompt=True)
    select, select_entries = stage_select.build(title, stage_select.CPS2_BASE, stage_select.cps2_inputs(entries['system_d1']), ending=True, hide_prompt=True)
    home = stage_select.CPS2_BASE
    sys.path.insert(0, str(ROOT / 'extraction'))
    from cps2_code_guard import require_code_spans
    stage_code_spans = [{'name': 'stage_select', 'start': home, 'size': len(select)}]
    require_code_spans(stage_code_spans, key=read_checked(sfa3u, *SFA3U_KEY))
    if any((b != 255 for b in program[home:home + len(select)])):
        raise ValueError(f"the stage select's home {home:#x} is not free")
    program[home:home + len(select)] = select
    applied += apply_patches(program, {**entries, **{f'stage_select_{k}': v for k, v in select_entries.items()}}, STAGE_SELECT_PATCHES, covered)
    stage_receipt = {'home': f'{home:#x}', **identity(select), 'entries': {k: f'{v:#x}' for k, v in select_entries.items()}}
    if edition == 'english':
        import english_records
        applied += apply_patches(program, entries, ENGLISH_PATCHES, covered)
        story, story_receipt = english_records.build(stock)
        story = [p for p in story if p[0] not in TEXT_SITES]
        story_receipt['ex'] = {**english_ex_receipt, 'caption_timing': caption_timing, 'lips': {k: v for k, v in lips.items() if k != 'plan'}}
        applied += apply_patches(program, entries, story, covered)
    usa_receipt, text_records = (None, [])
    if edition == 'usa':
        import usa_text
        typos, usa_receipt = usa_text.patches(stock)
        applied += apply_patches(program, entries, typos, covered)
        text_records = [(address, len(bytes.fromhex(old))) for address, old, _, _ in typos]
    cut_sites = {address: (len(bytes.fromhex(old)), reason) for address, old, _, reason in cuts}
    cut_sites[STORY_ARM] = (6, "CUT SCENES: the story's arm")
    cut_sites[94412] = (22, "CUT SCENES: the story's scene table stays stock (the dispatcher chooses)")
    cut_sites[94594] = (6, "CUT SCENES: scene 2's first step stays stock (CPS1 EX's stub)")
    block = text_catalog_block(stock)
    scene_graphics, scene_receipt = ex_scenes.merge(program, stock, covered, scenes, text_records, cut_sites, {'block': block, 'drop': "the restoration EX's SEGA CD text is english_ex.py's"} if edition == 'english' else {'block': block, 'home': EX_TEXT_HOME, 'stock': TEXT_STOCK}, ex_scenes.retime_addresses(ex_scenes.REGIONS[edition], stock))
    if edition == 'usa':
        import usa_text
        import text_catalog as tc
        size = block[1] - block[0]
        lowered, count = usa_text.lowered_block(program[EX_TEXT_HOME:EX_TEXT_HOME + size], tc.GROUP1 - tc.GROUPA)
        program[EX_TEXT_HOME:EX_TEXT_HOME + size] = lowered
        scene_receipt['text']['lowered_hyphen_records'] = count
    if 'REG_TV' in ex_equates:
        tail = scene['init'] - len(OVERRIDE_TAIL)
        if bytes(program[tail:tail + len(OVERRIDE_TAIL)]) != OVERRIDE_TAIL:
            raise ValueError(f"the opening override's epilogue is not at {tail:#x}")
        program[tail:tail + len(OVERRIDE_TAIL)] = b'N\xf9' + entries['ex_reg_tail'].to_bytes(4, 'big') + b'Nq' * 3
        first = ex_scenes.BASE_CODE + scenes['manifest']['art_tiles']
        region_ex = ex_scenes.REGIONS[edition]
        tiles, table, reg_receipt = kit.regulation_tv(scenes, first, region_ex)
        home = ex_regulation.HOME
        if any((b != 255 for b in program[home:home + len(table)])):
            raise ValueError(f"REG_TV's home {home:#x} is not free")
        program[home:home + len(table)] = table
        if [code for code, _ in tiles] != list(range(first, first + len(tiles))):
            raise ValueError("REGULATION's tiles are not consecutive")
        scene_graphics = scene_graphics + [(ex_scenes.SCROLL_GFX + first * 128, b''.join((t for _, t in tiles)))]
        scene_receipt['regulation'] = {'override_tail': f'{tail:#x}', **reg_receipt}
    watchdog = install_watchdog(program, entries, read_checked(sfa3u, *SFA3U_KEY))
    census_bytes = CENSUS.read_bytes()
    census = json.loads(census_bytes)
    masks = census_masks(census)
    region = world_graphics(source) if edition == 'usa' else stock_graphics(source)
    art_program, art_graphics, art_receipt = ([], [], None)
    scene_graphics = scene_graphics
    import artwork
    art_program, art_graphics, art_receipt = artwork.build(edition, stock, region, kit.artwork_asset(region))
    for home, data in art_program:
        if any((b != 255 for b in program[home:home + len(data)])):
            raise ValueError(f"ARTWORK's data home {home:#x} is not free")
        program[home:home + len(data)] = data
    portraits = []
    if ex and edition == 'usa':
        portraits += caption_hyphen(region)
    if edition == 'english':
        import english_records
        tiles = bytes(region[18688 * 64:(18688 + english_records.PORTRAIT_GLYPHS[1] - english_records.PORTRAIT_GLYPHS[0]) * 64])
        portraits = [(8388608 + (17408 + english_records.PORTRAIT_BASE) * 64, tiles)]
    english = english_text(region, world_graphics(find_archive(rompaths, 'ffight'))) if edition == 'english' else None
    if english:
        hyphen = caption_hyphen(region)
        portraits += hyphen
        english['caption_hyphen'] = {'glyph': f'{CAPTION_HYPHEN:#x}', 'codes': [f'{17408 + CAPTION_HYPHEN:#x}', f'{17424 + CAPTION_HYPHEN:#x}'], 'sha256': sha256(hyphen[0][1])}
    repair_select_windows(region)
    table, filtered, overlay_counts = overlay_tables(region, masks)
    table3, blocks, counts3 = overlay_tables3(region, masks)
    table += table3
    overlay_counts.update({f'scroll3_{k}': v for k, v in counts3.items()})
    table1, scroll1, counts1 = overlay_tables1(region, masks, layer_masks(census, 1))
    safe1 = safe_tables1(region, masks)
    wide = wide_table()
    overlay_counts.update({f'scroll1_{k}': v for k, v in counts1.items()})
    conversion = conversion_tables()
    if OVERLAY_TABLE + len(table) > CONVERSION_TABLES:
        raise ValueError('the overlay table runs into the conversion tables')
    if CONVERSION_TABLES + len(conversion) > SAFE1_TABLE or SAFE1_TABLE + len(safe1) > SCROLL1_TABLE:
        raise ValueError('the conversion and safe tables run into each other or the scroll 1 table')
    if SAFE1_TABLE + len(safe1) > WIDE_TABLE or WIDE_TABLE + len(wide) > SCROLL1_TABLE:
        raise ValueError('the wide Y table runs into the safe or scroll 1 table')
    for home, data in ((CONVERSION_TABLES, conversion), (OVERLAY_TABLE, table), (SCROLL1_TABLE, table1), (SAFE1_TABLE, safe1), (WIDE_TABLE, wide)):
        if any((b != 255 for b in program[home:home + len(data)])):
            raise ValueError(f'upper ROM table home {home:#x} is not free')
        program[home:home + len(data)] = data
    qtable, qpieces, qreceipt = qsound_screen(rompaths)
    if any((b != 255 for b in program[QSCREEN_TABLE:QSCREEN_TABLE + len(qtable)])):
        raise ValueError("the QSound screen table's home is not free")
    program[QSCREEN_TABLE:QSCREEN_TABLE + len(qtable)] = qtable
    rpieces, rreceipt = ([], None)
    if edition != 'usa':
        import regulation
        rtable, rblood, rpieces, rreceipt = regulation.build(region, rompaths, gray_blood)
        for home, data in ((regulation.REG_TABLE, rtable), (regulation.REG_BLOOD, rblood)):
            if any((b != 255 for b in program[home:home + len(data)])):
                raise ValueError(f"the REGULATION data's home {home:#x} is not free")
            program[home:home + len(data)] = data
    roll, creceipt = credits.build(program[credits.CREDITS_SRC:credits.CREDITS_SRC + credits.STOCK_BYTES], credits.EX_HEADERS)
    if creceipt['stock_rows'] != credits.STOCK_ROWS or creceipt['rows'] != credits.STOCK_ROWS + 2:
        raise ValueError(f'the staff roll is not {credits.STOCK_ROWS} rows (EX: 2 more): {creceipt}')
    tail = credits.tail_patch(creceipt['rows'])
    if tail:
        applied += apply_patches(program, entries, (tail,), covered)
    if any((b != 255 for b in program[credits.CREDITS_HOME:credits.CREDITS_HOME + len(roll)])):
        raise ValueError("the staff roll's home is not free")
    program[credits.CREDITS_HOME:credits.CREDITS_HOME + len(roll)] = roll
    cpieces = credits.pieces()
    creceipt = {'home': f'{credits.CREDITS_HOME:#x}', **identity(roll), **creceipt, 'glyphs': {ch: f'{17408 + cell:#x}' for ch, cell in credits.NEW_CELLS.items()}, 'glyph_tiles': identity(b''.join((data for _, data in cpieces)))}
    stored, encryption, key = (bytes(program), None, DEAD_KEY)
    members = {}
    names = PHOENIX_PROGRAM
    for index, name in enumerate(names):
        members[name] = upstream.swap_words(stored[index * 524288:(index + 1) * 524288])
    members.update(cps2_graphics(region, filtered, blocks, scroll1, qpieces + rpieces + portraits + cpieces + art_graphics + scene_graphics))
    import sound_members
    test_gains, effect_gains = (effect_gains, EFFECT_GAINS if effect_gains is None else effect_gains)
    opening = {**({'arcade': arcade_rounds()} if edition == 'english' else {}), **{'cd': fs_cd_rounds(edition)}, **({'ending': fs_cd_ending(edition)[1]} if ex and fs_cd_ending(edition)[1] else {})} or None
    sound, sound_receipt = kit.sound(rompaths, effect_gains, opening)
    members.update(sound)
    members['dl-1425.bin'] = read_checked(sfa3u, *SFA3U_SOUND[-1])
    members['phoenix.key'] = key
    console_receipt = None
    program, members, console_receipt = console_phase(program, members, entries, len(blob), ex_equates, edition, read_checked(sfa3u, *SFA3U_KEY), work, kit, PHOENIX_PROGRAM)
    stored = bytes(program)
    entries = console_receipt['entries']
    rom_dir = work / 'rom'
    if rom_dir.exists():
        shutil.rmtree(rom_dir)
    rom_dir.mkdir()
    archive = rom_dir / 'sfa3ud.zip'
    with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as z:
        for name in sorted(members):
            info = zipfile.ZipInfo(name, date_time=(1998, 9, 4, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            z.writestr(info, members[name])
    receipt = {'purpose': 'milestone 1 spike; development archive, not a release', 'edition': edition, 'ex': {'capability': f"{entries['ex_capability']:#x}", 'arrange': {'classes': f'{ex_arrange.HOME:#x}', 'posts': ex_arrange.describe(classes)}, 'artwork': art_receipt, 'stage_select': stage_receipt, 'scenes': scene_receipt}, 'english_text_tiles': english, 'english_records': story_receipt if edition == 'english' else None, 'usa_text': usa_receipt, 'phoenix_map': phoenix, 'encrypted': encryption, 'inputs': {'ffightu' if edition == 'usa' else 'ffightj': source.name, 'sfa3u': sfa3u.name}, 'stock_program': identity(bytes(stock)), 'program': identity(bytes(program)), 'layer': {'home': f'{LAYER_HOME:#x}', **identity(blob), 'entries': {k: f'{v:#x}' for k, v in entries.items()}}, 'patches': applied, 'watchdog': watchdog, 'overlay': {'census_sha256': sha256(census_bytes), 'masks': [f'{m:04x}' for m in masks], 'table': {'home': f'{OVERLAY_TABLE:#x}', **identity(table)}, 'filtered_tiles': identity(filtered), 'scroll3_block_tiles': identity(blocks), 'scroll1_table': {'home': f'{SCROLL1_TABLE:#x}', **identity(table1)}, 'scroll1_object_tiles': identity(scroll1), 'scroll1_safe_table': {'home': f'{SAFE1_TABLE:#x}', **identity(safe1)}, 'wide_y_table': {'home': f'{WIDE_TABLE:#x}', **identity(wide)}, **overlay_counts}, 'qsound_screen': qreceipt, 'regulation': rreceipt, **{'boot_identity': boot_identity(stored, edition)}, **{'console': console_receipt}, 'credits': creceipt, 'test_kit': {'start_level': start_level, 'diag': diag, 'effect_gains_db': {f'{c:02x}': g for c, g in (test_gains or {}).items()}} if start_level is not None or test_gains is not None or diag else None, 'select_window_pixels': [[f'{c:04x}', x, y] for c, x, y in SELECT_WINDOW_PIXELS], 'sound': {'cache_key': sound_receipt['cache_key'], 'music': sound_receipt['recipe']['music'], 'effect_gains_db': {f'{c:02x}': g for c, g in sorted(effect_gains.items())}, 'sample_bytes': sound_receipt['sample_bytes']}, 'members': {name: identity(data) for name, data in sorted(members.items())}}
    (work / 'build.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
    return receipt
