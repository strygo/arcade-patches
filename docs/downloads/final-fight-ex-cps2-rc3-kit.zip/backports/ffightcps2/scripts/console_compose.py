#!/usr/bin/env python3
"""Console mode (and Time Attack) over a finished EX program, for every producer.

compose() takes the EX build's complete program and members, composes the Console layer
(console_mode.py, time_attack.py) over the approved hw_layer.asm, and returns the new program,
members and receipt: the composed layer, every bound native hook and caller, the Console star and
PTS tiles, Time Attack's RESULT figures and arenas, and the native QSound HOLD/RESUME patch.

Its two seams keep it free of the assembler and of the disc where the public kit runs it
(RC3_RELEASE.md): assemble(source) returns the layer and its symbols (normally the bootstrapped
assembler; the kit, the shipped blob with its keyed data), and ta_graphics() returns Time Attack's
graphics (normally converted from the disc; the kit, unsealed from the user's disc files).
build_m1_spike.build runs it in every EX build (there is no separate Console build).
"""
import json
from pathlib import Path
import re
import struct
import sys

import build_m1_spike as spike
import allocation_map
import console_mode
import console_sound
import time_attack

sys.path.insert(0, str(spike.ROOT / 'extraction'))
sys.path.insert(0, str(spike.ROOT / 'backports/ffightcd/build'))
from cps2_code_guard import require_code_spans     # noqa: E402
import stage_select                                # noqa: E402  CPS1 EX's, with its CPS2 backend

STAR_SOURCE = spike.ROOT / 'backports/ffightcps2/assets/console_star.json'
PTS_SOURCE = spike.ROOT / 'backports/ffightcps2/assets/console_pts.json'
TITLE_SOUND_AUTHORITY = {
    'native_move': (0xbba, '303c00396000fe24'),
    'native_confirm': (0xbc2, '303c003a6000fe1c'),
    'select_move_right': (0x5c5a6, '4ef80bba'),
    'select_move_left': (0x5c5ca, '4ef80bba'),
    'select_confirm': (0x5c626, '0fae00004eb80bc24e75'),
    'select_effect_reset': (0x5c39e, '4eb80a22303c0055'),
    'stop_oki': (0xa22, '303c00f260d0'),
    'game_effect_reset': (0x4be0, '4eb80a10426d0000'),
    'round_effect_reset': (0x4d3c, '4eb80a101b7c0001012a'),
    'stop_all': (0xa10, '303c00f060e2'),
    'native_queue': (0x9f8, '322d001a41ed01843180100054410241007f3b41001a4e75')}
DISPLAY_AUTHORITY = {
    'layer_pipeline': (0x574, '322d00703b6d006e007033c100800166'),
    'scroll1_x_pipeline': (0x5e8, '303cffc0322d002633c10080010c3b6d00220026'),
    'scroll1_y_pipeline': (0x650, '33ed00280080010e3b6d00240028')}
# Full reservations, including unused capacity, are disjoint. The native
# GFX table census ends at 9286FF; the complete class cache ends at 928C27.
# The modal backup owns 929000..92CFFF, followed by a separate supervisor
# stack in the same CPU-visible GFX RAM (900000..92FFFF).
RAM_CLAIMS = [
    {'owner': 'native object tables', 'start': 0x920000, 'bytes': 0x8700},
    {'owner': 'sprite classification cache', 'start': 0x928800, 'bytes': 1064},
    {'owner': 'Console map backup', 'start': 0x929000, 'bytes': 0x4000},
    {'owner': 'Console saved SSP and supervisor stack', 'start': 0x92d000, 'bytes': 0x1000},
    {'owner': 'pause original palette pages', 'start': 0x92e000, 'bytes': 0x1000},
    {'owner': 'pause dim palette pages for frozen sprite lending', 'start': 0x92f000, 'bytes': 0x1000}]
# The data the composed layer carries from the disc, between these labels (the kit keys them).
TA_DATA_SPANS = (('ta_script', 'ta_script_end'), ('ta_figure_pals', 'ta_figure_pals_end'),
                 ('ta_arenas', 'ta_arenas_end'))


def require(value, message):
    if not value:
        raise ValueError(message)


def labels(path):
    """{label: address} from an assembler listing."""
    return {m[2]: int(m[1], 16) for m in re.finditer(
        r'^([0-9A-F]{8})\s+([a-zA-Z_][a-zA-Z_0-9]*):\s*$', Path(path).read_text(), re.M)}


def operands(replacement):
    """Relocations from the typed patch grammar, not coincident ROM literals."""
    if isinstance(replacement, str):
        return []
    if replacement[0] == 'long':
        return [(0, replacement[1])]
    offset, result = 0, []
    for part in replacement:
        if isinstance(part, str):
            offset += len(bytes.fromhex(part))
        elif part[0] == 'long':
            result.append((offset, part[1]))
            offset += 4
        else:
            require(part[0] == 'jsr', 'unknown patch grammar')
            result.append((offset + 2, part[1]))
            offset += 6
    return result


def stage_object(entries):
    blob, _ = stage_select.build(stage_select.TITLE_BYTES, stage_select.CPS2_BASE,
                                 stage_select.cps2_inputs(entries['system_d1']), ending=True, hide_prompt=True)
    return blob


def callers(raw, program, old, new, edition, eq):
    """Every absolute caller of the layer moved from the old entries to the new ones: the patch
    tables' typed relocations, the complete stage-select object, the regulation tail; any other
    absolute reference to an old entry outside the layer fails."""
    cuts = spike.CUT_PATCHES
    if edition == 'english':
        cuts = tuple(p for p in cuts if p[0] not in spike.TEXT_SITES) + spike.ENGLISH_EX_TEXT
    patches = (spike.PATCHES + spike.TEXT_FIXES + spike.EX_PATCHES + cuts +
               ((spike.STORY_ARM, '00' * 6, (('jsr', 'ex_story_arm'),), 'story arm'),))
    catalog, changed, spans = {}, [], []
    for address, _, replacement, reason in patches:
        refs = operands(replacement)
        if not refs:
            continue
        before, after = spike.encode(replacement, old), spike.encode(replacement, new)
        require(raw[address:address + len(before)] == before, 'published caller differs: ' + hex(address))
        program[address:address + len(after)] = after
        for offset, entry in refs:
            catalog[address + offset] = entry
        if before != after:
            changed.append({'address': hex(address), 'bytes': len(after), 'producer': reason})
    before, after = stage_object(old), stage_object(new)
    home = stage_select.CPS2_BASE
    require(len(before) == len(after) and raw[home:home + len(before)] == before,
            'published stage-select object differs')
    program[home:home + len(after)] = after
    spans.append({'name': 'stage_select', 'start': home, 'size': len(after)})
    token = b'\x4e\xb9' + struct.pack('>I', old['system_d1'])
    require(before.count(token) == 1, 'stage-select callback census differs')
    catalog[home + before.index(token) + 2] = 'system_d1'
    changed.append({'address': hex(home), 'bytes': len(after), 'producer': 'complete stage_select.build object'})
    if 'ex_reg_tail' in old:
        home = eq['SC_INIT'] - len(spike.OVERRIDE_TAIL)
        before = b'\x4e\xf9' + struct.pack('>I', old['ex_reg_tail']) + b'\x4e\x71' * 3
        after = b'\x4e\xf9' + struct.pack('>I', new['ex_reg_tail']) + b'\x4e\x71' * 3
        require(raw[home:home + len(before)] == before, 'published regulation tail differs')
        program[home:home + len(after)] = after
        catalog[home + 2] = 'ex_reg_tail'
        changed.append({'address': hex(home), 'bytes': len(after), 'producer': 'SC_INIT override epilogue'})
    owners = {value: name for name, value in old.items()}
    found = {}
    for address in range(0, 0x100000 - 3, 2):
        if address >= spike.LAYER_HOME:
            continue
        value = int.from_bytes(raw[address:address + 4], 'big')
        if value in owners and (address in (4, 0x70, 0x78) or raw[address - 2:address] in
                                (b'\x4e\xb9', b'\x4e\xf9', b'\x20\x7c')):
            found[address] = owners[value]
    require(found == catalog, 'unknown or missing layer caller: ' + repr(set(found.items()) ^ set(catalog.items())))
    return changed, spans, {hex(k): v for k, v in sorted(catalog.items())}


def layer_source(raw, edition, time_attack_mode=True, img=None):
    """(composed layer source, Time Attack receipt or None) over the approved hw_layer.asm."""
    require(raw[0x1258:0x125a] == bytes.fromhex('4ef9') and raw[0x5a0:0x5a2] == bytes.fromhex('4eb9'),
            'existing EX text/scene callback grammar differs')
    small_text_entry = int.from_bytes(raw[0x125a:0x125e], 'big')
    scene_irq_entry = int.from_bytes(raw[0x5a2:0x5a6], 'big')
    require(0xd0000 <= small_text_entry < 0xf0000 and 0xd0000 <= scene_irq_entry < 0xf0000,
            'existing EX callbacks outside owned engine')
    composed = console_mode.source(spike.LAYER_SOURCE.read_text(), small_text_entry, scene_irq_entry)
    ta_receipt = None
    if time_attack_mode:
        composed, ta_receipt = time_attack.source(composed, raw, edition=edition, img=img)
    return composed, ta_receipt


def console_tiles():
    """(star tile, PTS tiles) from the committed assets."""
    star = json.loads(STAR_SOURCE.read_text())
    tile = bytearray(b'\xff' * 64)
    for y, row in enumerate(star['glyph']):
        require(len(row) == 8, 'star row extent')
        for plane in range(4):
            tile[y * 8 + plane] = sum((1 << (7 - x)) for x, c in enumerate(row)
                                      if ((int(c, 16) if c != '0' else 15) >> plane) & 1)
    pts = json.loads(PTS_SOURCE.read_text())
    require(len(pts['glyph']) == 8 and all(len(r) == 24 for r in pts['glyph']), 'PTS extent')
    pts_tiles = bytearray(b'\xff' * 192)
    for y, row in enumerate(pts['glyph']):
        for half in range(3):
            for plane in range(4):
                pts_tiles[half * 64 + y * 8 + plane] = sum(1 << (7 - x) for x in range(8)
                                                           if (int(row[half * 8 + x], 16) >> plane) & 1)
    return bytes(tile), bytes(pts_tiles)


def compose(raw, members, base_entries, base_layer_size, equates, edition, assemble, key, *, ta_graphics=None,
            time_attack_mode=True, img=None, program_names=None):
    """(program, members, receipt). raw: the EX build's complete program; members: its set with MAME
    names; base_entries, base_layer_size: its layer's entries and length; equates: the layer's EX
    equates; assemble() -> (blob, entries, symbols) of layer_source's composition; key: the sfa3u key
    (the code guard and watchdog); ta_graphics(): Time Attack's [(graphics address, bytes)], default
    converted from img's disc."""
    for name, (at, expected) in TITLE_SOUND_AUTHORITY.items():
        require(raw[at:at + len(bytes.fromhex(expected))] == bytes.fromhex(expected),
                'native title sound authority differs: ' + name)
    for name, (at, expected) in DISPLAY_AUTHORITY.items():
        require(raw[at:at + len(bytes.fromhex(expected))] == bytes.fromhex(expected),
                'native display pipeline differs: ' + name)
    small_text_entry = int.from_bytes(raw[0x125a:0x125e], 'big')
    scene_irq_entry = int.from_bytes(raw[0x5a2:0x5a6], 'big')
    blob, entries, symbols = assemble()
    program = bytearray(raw)
    home, end = spike.LAYER_HOME, spike.LAYER_HOME + len(blob)
    previous_end = home + base_layer_size
    require(previous_end <= end < 0x100000 and raw[previous_end:end] == b'\xff' * (end - previous_end),
            'Console layer overlaps another owner')
    spans = [{'name': 'console_layer', 'start': home, 'size': len(blob)}]
    require_code_spans(spans, key=key)
    for left, right in zip(RAM_CLAIMS, RAM_CLAIMS[1:]):
        require(left['start'] + left['bytes'] <= right['start'], 'Console GFX RAM reservation overlap')
    require(RAM_CLAIMS[-1]['start'] + RAM_CLAIMS[-1]['bytes'] <= 0x930000, 'Console stack outside physical GFX RAM')
    scheduler = symbols['console_scheduler'] - home
    require(blob[scheduler:scheduler + 16] == bytes.fromhex('23cf0092d0004ff90092e00048e7fffe'),
            'complete private supervisor stack entry differs')
    require(blob.count(bytes.fromhex('4cdf7fff2e790092d000422d91014a2d00844e75')) == 1,
            'complete scheduler restoration differs')
    program[home:end] = blob
    spike.install_watchdog(program, entries, key)
    changed, other_spans, census = callers(raw, program, base_entries, entries, edition, equates)

    def hook(at, expected, target, op='4eb9'):
        before = bytes.fromhex(expected)
        require(raw[at:at + len(before)] == before, f'Console native preimage differs at {at:x}')
        after = bytes.fromhex(op) + struct.pack('>I', symbols[target])
        require(len(before) >= len(after) and (len(before) - len(after)) % 2 == 0, 'partial native hook')
        program[at:at + len(before)] = after + b'\x4e\x71' * ((len(before) - len(after)) // 2)
        changed.append({'address': hex(at), 'bytes': len(before), 'producer': target})
    hook(0x10F6, '4eb8295e4a40', 'console_title_input')
    hook(0x5c39e, '4eb80a22303c0055', 'console_select_sound')
    hook(0x4be0, '4eb80a10426d0000', 'console_game_sound')
    hook(0x4d3c, '4eb80a101b7c0001012a', 'console_round_sound')
    # Reconstruct the complete pinned stage object after callback relocation.
    stage_blob = stage_object(entries)
    require(program[stage_select.CPS2_BASE:stage_select.CPS2_BASE + len(stage_blob)] == stage_blob,
            'complete relocated stage object differs')
    pick = bytes.fromhex('4eb80bc23c3c0027')
    require(stage_blob.count(pick) == 1, 'complete stage confirmation/blink producer differs')
    pick_at = stage_select.CPS2_BASE + stage_blob.index(pick)
    require(raw[pick_at:pick_at + len(pick)] == pick, 'published stage confirmation preimage differs')
    hook(pick_at, pick.hex(), 'console_stage_accept')
    laugh = bytes.fromhex('303c00284eb809f8')
    hold = bytes.fromhex('303c00684eb8087e')
    require(stage_blob.count(laugh) == 1 and stage_blob.count(hold) == 1,
            'complete stage laugh/hold producer differs')
    laugh_at = stage_select.CPS2_BASE + stage_blob.index(laugh)
    hold_at = stage_select.CPS2_BASE + stage_blob.index(hold)
    hook(laugh_at, laugh.hex(), 'console_stage_laugh')
    require(raw[hold_at:hold_at + 8] == hold, 'stage laugh hold preimage differs')
    program[hold_at:hold_at + 8] = b'\x4e\x71' * 4
    changed.append({'address': hex(hold_at), 'bytes': 8,
                    'producer': 'remove stage laugh sleep; preserve native cue through cleanup'})
    # Replay TST.W D0: the original following branch consumes its CCR.
    # 10f6's original call is four bytes and TST is two; six-byte JSR
    # consumes both. The helper reproduces the test immediately before RTS.
    for at in (0x17E88, 0x18118):
        before = bytes.fromhex('207c0005d846')
        require(raw[at:at + 6] == before, 'native prompt owner changed')
        program[at:at + 6] = b'\x20\x7c' + struct.pack('>I', symbols['console_prompt'])
        changed.append({'address': hex(at), 'bytes': 6, 'producer': 'console_prompt task constructor'})
    hook(0x786, '422d91014a2d0084', 'console_scheduler')
    if time_attack_mode:
        for at, before, target, op in time_attack.hooks(raw):
            hook(at, before, target, op)
        for at, before, after in time_attack.classes_patch(raw):
            require(raw[at:at + len(before)] == before, f'EX_CLASSES preimage differs at {at:x}')
            program[at:at + len(after)] = after
            changed.append({'address': hex(at), 'bytes': len(after), 'producer': 'ta EX_CLASSES alias: arrange'})
    hook(0x18B8, '4a2d54806622', 'console_credit', '4ef9')
    hook(0x1258, raw[0x1258:0x125e].hex(), 'console_small_text', '4ef9')
    hook(0x5a0, raw[0x5a0:0x5a6].hex(), 'console_scene_irq')
    for at, target in ((0x14B4, 'console_big_draw'), (0x17CE, 'console_big_erase')):
        hook(at, '43f9000680f43031000043f10000', target, '4ef9')
    for at in (0x130e, 0x1350):
        name = 'ex_text_ae' if edition == 'english' else 'ex_text_a'
        before = b'\x4e\xb9' + struct.pack('>I', base_entries[name])
        before += b'\x4e\x71' * 4 if edition == 'english' else bytes.fromhex('3031000043f10000')
        hook(at, before.hex(), 'console_text_a')
    # The modal footer copier owns 128 bytes. Independently walk every
    # complete selected record from all native/restoration/CD table families.
    eq = equates
    footer_records = []
    tables = [(0x67082, False)]
    if edition == 'english':
        tables += [(eq['EN_TABLE_A'], True), (eq['EN_CD_A'], True)]
    else:
        tables += [(eq['SC_TEXT'], False)]
    for table, longs in tables:
        for index in (5, 6, 7):
            at = int.from_bytes(raw[table + index * 4:table + index * 4 + 4], 'big') if longs else \
                table + int.from_bytes(raw[table + index * 2:table + index * 2 + 2], 'big')
            cursor = at
            cells = []
            while True:
                cell, attr = struct.unpack_from('>HH', raw, cursor)
                cursor += 4
                cells.append(cell)
                require(cell % 128 // 4 + 2 <= 29 and attr < 32, 'footer cell/palette outside declared grammar')
                while True:
                    glyph = struct.unpack_from('>H', raw, cursor)[0]
                    cursor += 2
                    require(cursor - at <= 128, 'complete footer exceeds scratch allocation')
                    if glyph == 0 or glyph & 0x8000:
                        break
                if glyph == 0:
                    break
            footer_records.append({'table': hex(table), 'index': index, 'address': hex(at),
                                   'bytes': cursor - at, 'sha256': spike.sha256(raw[at:cursor]), 'cells': cells})
    # Complete source-bound prompt family: fixed cells/palettes and complete
    # byte-font records, not merely the embedded English words.
    for at, record in ((0x681a8, bytes.fromhex('040c0180') + b'\x10PUSH\x10START\x10\0'),
                       (0x681ba, bytes.fromhex('118c0180') + b'\x10PUSH\x10START\x10\0'),
                       (0x68286, bytes.fromhex('040c0180') + b' FREE PLAY \0'),
                       (0x68296, bytes.fromhex('118c0180') + b' FREE PLAY \0')):
        require(raw[at:at + len(record)] == record, 'native join prompt record differs')
    spans += other_spans
    require_code_spans(spans, key=key)
    allowed = set(range(home, end))
    for row in changed:
        allowed.update(range(int(row['address'], 16), int(row['address'], 16) + row['bytes']))
    require(len(program) == len(raw) and all(a == b or i in allowed for i, (a, b) in enumerate(zip(raw, program))),
            'Console unscoped program change')
    members = dict(members)
    for i, name in enumerate(program_names or spike.PHOENIX_PROGRAM):
        members[name] = spike.upstream.swap_words(program[i * 0x80000:(i + 1) * 0x80000])
    # Dedicated scroll-1 tiles, outside every existing allocated resource.
    graphics = bytearray(allocation_map.graphics_of(members))
    before_graphics = bytes(graphics)
    at = 0x800000 + 0x3000 * 64
    tile, pts_tiles = console_tiles()
    require(graphics[at:at + 256] == b'\xff' * 256, 'complete Console star/PTS allocation occupied')
    graphics[at:at + 256] = tile + pts_tiles
    written = [(at, 256)]
    if time_attack_mode:                # the CD's RESULT figures and arenas, each a complete blank allocation
        for gat, data in (ta_graphics() if ta_graphics else time_attack.graphics(time_attack.result_art(img), img)):
            require(gat >= 0xEE0400 and gat + len(data) <= 0x1000000, 'Time Attack graphics outside their blank run')
            require(graphics[gat:gat + len(data)] == b'\xff' * len(data), f'Time Attack graphics at {gat:x} occupied')
            graphics[gat:gat + len(data)] = data
            written.append((gat, len(data)))
    shuffled = spike.upstream.reshuffle(bytes(graphics))
    for half, group in enumerate(spike.SFA3U_GFX):
        part = shuffled[half * 0x1000000:(half + 1) * 0x1000000]
        for lane, old in enumerate(group):
            data = bytearray(0x400000)
            data[::2], data[1::2] = part[lane * 2::8], part[lane * 2 + 1::8]
            members[old] = bytes(data)
    cursor = 0
    for wat, size in sorted(written):
        require(graphics[cursor:wat] == before_graphics[cursor:wat], 'unscoped graphics change')
        cursor = wat + size
    require(graphics[cursor:] == before_graphics[cursor:], 'unscoped graphics change')
    members['sz3.01'], sound = console_sound.patch(members['sz3.01'], spike.sha256(members['sz3.01']))
    receipt = {
        'entries': entries, 'symbols': symbols, 'code_spans': spans, 'caller_census': census, 'hooks': changed,
        'sound': sound,
        'title_sound': {'move': 0x39, 'confirm': 0x3a, 'queue': 0x9f8,
                        'arcade_acceptance': 'preserve channel 10 through game and select effect stops',
                        'pending_byte': 0xfffc38,
                        'authority': {n: {'address': a, 'hex': d} for n, (a, d) in TITLE_SOUND_AUTHORITY.items()}},
        'pause_screen': {'brightness_cap': 6, 'original_palette': 0x92e000, 'dim_palette': 0x92f000,
                         'palette_bytes': 0x1000, 'ready_byte': 0xfffc3b,
                         'scope': 'frozen published sprites and game scroll layers behind bright Scroll 1 text'},
        'stage_laugh': {'pending_byte': 0xfffc3a, 'cue': 0x28, 'channel': 10, 'pick': laugh_at,
                        'removed_hold': {'address': hold_at, 'frames': 104},
                        'scope': 'Console and Arcade stage code; immediate player select'},
        'stage_acceptance': {'pending_byte': 0xfffc39, 'round_cleanup': 0x4d3c, 'pick': pick_at,
                             'object_sha256': spike.sha256(stage_blob), 'blink_frames': 40,
                             'scope': 'Console and Arcade stage picker; preserve channel 10 once'},
        'screen_restore': {'scroll1_disable_mask': 0xfffd, 'irq_handshakes': 2, 'owner': 'console_restore_screen',
                           'scope': 'Options and pause restoration',
                           'authority': {n: {'address': a, 'hex': d} for n, (a, d) in DISPLAY_AUTHORITY.items()}},
        'footer_records': footer_records, 'gfx_ram_reservations': RAM_CLAIMS,
        'pts': {'layout_offset': at + 64, 'bytes': 192, 'tiles_sha256': spike.sha256(pts_tiles),
                'source_sha256': spike.sha256(PTS_SOURCE.read_bytes())},
        'star': {'layout_offset': at, 'bytes': 64, 'tile_sha256': spike.sha256(tile),
                 'source_sha256': spike.sha256(STAR_SOURCE.read_bytes())},
        'small_text_entry': small_text_entry, 'scene_irq_entry': scene_irq_entry,
        'graphics_written': [[hex(a), n] for a, n in sorted(written)]}
    return bytes(program), members, receipt


def data_spans(symbols):
    """[(name, start, end)]: the composed layer's disc data, between TA_DATA_SPANS' labels."""
    return [(start, symbols[start], symbols[end]) for start, end in TA_DATA_SPANS if start in symbols]
