"""Compose the Console feature without changing the approved sprite repair.

All rewrites name complete source records or complete native instructions.
The ordinary repair and historical hardware-comparison builders keep using
hw_layer.asm unchanged. Every EX build composes it (console_compose.py, build_m1_spike.build).
"""
from pathlib import Path

CONSOLE = 0x10
ASM = Path(__file__).resolve().parents[1] / 'asm/console_mode.asm'


def replace(text, before, after):
    if text.count(before) != 1:
        raise ValueError('Console source binding differs: ' + before[:100])
    return text.replace(before, after)


def source(text, small_text_entry=0xd67f8, scene_irq_entry=0xd63be):
    text = (f'CM_SMALL_NATIVE equ ${small_text_entry:x}\n'
            f'CM_SCENE_NATIVE equ ${scene_irq_entry:x}\n' + text)
    text = replace(text, 'EX_NATIVE_MUSIC equ 3', 'EX_CONSOLE      equ 4\nEX_NATIVE_MUSIC equ 3')
    text = replace(text, '@done:  move.l (sp)+,d7\n        rts\n\n; Replace "move.b $80001x.l,d0"',
        '@done:  btst #EX_CONSOLE,(EX_SET).l\n        beq.s @arcade\n'
        '        ori.b #7,d6\n@arcade: move.l (sp)+,d7\n        rts\n\n; Replace "move.b $80001x.l,d0"')
    text = replace(text, '        ori.b #REG_BIT,d0               ; Freeze off; the bit holds REGULATION',
        '        btst #EX_CONSOLE,(EX_SET).l\n        beq.s @arcade\n'
        '        andi.b #$fb,d0             ; Console derives native free play\n'
        '@arcade:\n        ori.b #REG_BIT,d0               ; Freeze off; the bit holds REGULATION')
    text = replace(text, '        dc.b 4,1,1,2,6,2,18,0', '        dc.b 5,1,1,2,6,2,18,0')
    text = replace(text, '        dc.b 5,1,1,2,6,2,18,0\n        endc',
                   '        dc.b 6,1,1,2,6,2,18,0\n        endc')
    text = replace(text, '        dc.l t_ex,t_ex1,t_ex2,t_ex3,t_ex4,f_set1,f_set2,f_set3,0',
                   '        dc.l t_ex,t_mode,t_ex1,t_ex2,t_ex3,t_ex4,f_set1,f_set2,f_set3,0')
    text = replace(text, '        dc.l t_ex,t_ex1,t_ex2,t_ex3,t_ex4m,t_ex5m,f_set1,f_set2,f_set3,0',
                   '        dc.l t_ex,t_mode,t_ex1,t_ex2,t_ex3,t_ex4m,t_ex5m,f_set1,f_set2,f_set3,0')
    for name, oldrow, oldnum in (('t_ex1',6,1),('t_ex2',8,2),('t_ex3',10,3),
                                 ('t_ex4',12,4),('t_ex4m',12,4),('t_ex5m',14,5)):
        old = f'{name+":":<9}dc.b 3,{oldrow},ORANGE,"{oldnum}.'
        new = f'{name+":":<9}dc.b 3,{oldrow+2},ORANGE,"{oldnum+1}.'
        text = replace(text, old, new)
    text = replace(text, '        dc.l s_bonus,s_cuts,s_artwork,a_back',
                   '        dc.l s_mode,s_bonus,s_cuts,s_artwork,a_back')
    text = replace(text, '        dc.l s_bonus,s_cuts,s_artwork,s_music,a_back',
                   '        dc.l s_mode,s_bonus,s_cuts,s_artwork,s_music,a_back')
    text = replace(text, 'late_build:\n        lea (OV_RAM).l,a4',
        'late_build:\n        btst #EX_CONSOLE,(EX_SET).l\n        beq.s @console_native\n'
        '        tst.b (CM_REQUEST).l\n        bne console_modal_objects\n'
        '@console_native:\n        lea (OV_RAM).l,a4')
    text = replace(text, '        jsr (EX_OBJHOOK).l              ; EX\'s title slide, which ends with the',
        '        tst.b (CM_REQUEST).l\n        beq.s @cm_obj_native\n'
        '        move.w $9e(a5),($800100).l\n        bra.s @cm_obj_done\n'
        '@cm_obj_native:\n        jsr (EX_OBJHOOK).l\n@cm_obj_done:\n'
        '                                        ; EX\'s title slide, which ends with the')
    text = replace(text, '        lea (PAL_SCROLL1).l,a2\n        adda.w d2,a2',
        '        lea (PAL_SCROLL1).l,a2\n'
        '        tst.b (CM_PAUSE_READY).l\n        beq.s @cm_live_palette\n'
        '        lea (CM_DIM_PALETTE+$400).l,a2\n@cm_live_palette:\n'
        '        adda.w d2,a2')
    text = replace(text, 'code_end:', ASM.read_text() + '\ncode_end:')
    return text
