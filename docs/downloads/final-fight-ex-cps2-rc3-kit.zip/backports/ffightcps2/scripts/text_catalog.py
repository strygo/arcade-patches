"""Final Fight's story, profile, ending and staff text, both regions."""
from __future__ import annotations
from pathlib import Path
import struct
TRACK = Path(__file__).resolve().parents[1]
GROUP1, GROUPA, BYTES = (427366, 422018, 417406)
LINES = {'english': 96646, 'japan': 96673}
PALETTES = 796672
SINGLE = {1510, 1511, 45}
SCENES = [('map', d) for d in range(4)] + [('phone', d) for d in range(4, 10)] + [('tv', d) for d in range(10, 16)] + [('guy_cody', d) for d in range(16, 20)] + [('profile', d) for d in range(20, 23)] + [('interlude', d) for d in range(23, 27)]
DIRECT = {'english': [('ending', 'g1', 58), ('ending', 'g1', 60), ('ending', 'g1', 62), ('ending', 'g1', 56), ('year_card', 'gA', 8), ('title', 'gA', 7), ('staff', 'gA', 12), ('staff', 'gA', 11), ('staff', 'bytes', 58), ('staff', 'bytes', 59), ('staff', 'bytes', 186), ('unused', 'g1', 15), ('unused', 'g1', 16), ('unused', 'g1', 17)], 'japan': [('ending', 'g1', 57), ('ending', 'g1', 59), ('ending', 'g1', 61), ('ending', 'g1', 56), ('year_card', 'gA', 9), ('title', 'gA', 5), ('staff', 'gA', 10), ('staff', 'gA', 11), ('staff', 'gA', 13), ('staff', 'gA', 14), ('staff', 'gA', 141)]}

def word(image, at):
    return struct.unpack_from('>H', image, at)[0]

def segments(image, at):
    out = []
    while True:
        cell, attr = (word(image, at), word(image, at + 2))
        at += 4
        glyphs = []
        while True:
            g = word(image, at)
            at += 2
            if g == 0 or g & 32768:
                break
            glyphs.append(g)
            if len(glyphs) > 200:
                raise ValueError(f'runaway record near {at:#x}')
        out.append({'col': cell // 128, 'row': cell % 128 // 4, 'pal': attr & 31, 'glyphs': glyphs})
        if g == 0:
            return out

def byte_record(image, at):
    out, col, row, attr = ([], image[at], image[at + 1], image[at + 2])
    at += 3
    while True:
        glyphs = []
        while image[at] not in (0, 92):
            glyphs.append(image[at])
            at += 1
        out.append({'col': col, 'row': row & 127, 'page2': bool(row & 128), 'pal': attr & 31, 'glyphs': glyphs})
        if image[at] == 0:
            return out
        col, row, attr = (image[at + 1], image[at + 2], image[at + 3])
        at += 4

def record(image, kind, index):
    if kind == 'g1':
        at = GROUP1 + word(image, GROUP1 + 2 * index)
        return {'delay': image[at], 'mode': image[at + 1], 'segments': segments(image, at + 2), 'address': at}
    if kind == 'gA':
        at = GROUPA + word(image, GROUPA + 2 * index)
        return {'delay': None, 'mode': 0, 'segments': segments(image, at), 'address': at}
    at = BYTES + word(image, BYTES + 2 * index)
    return {'delay': None, 'mode': 0, 'segments': byte_record(image, at), 'address': at}
ENGLISH = {16: ' ', 1450: '.', 1512: ',', 1509: "'", 1516: '?', 1517: '!', 45: '-', 1510: '"', 1511: '"', 1513: ':', 1514: '(', 1515: ')'}
ENGLISH.update({1451 + i: c for i, c in enumerate('abcde')})
ENGLISH.update({1472 + i: c for i, c in enumerate('fghijklmnopqrstu')})
ENGLISH.update({1504 + i: c for i, c in enumerate('vwxyz')})
ENGLISH.update({1408 + i: c for i, c in enumerate('ABCDEFGHIJKLMNOP')})
ENGLISH.update({1440 + i: c for i, c in enumerate('QRSTUVWXYZ')})
ENGLISH.update({1576 + i: c for i, c in enumerate('12345678')})
ENGLISH.update({1612: '9', 1613: '0'})

def english_text(rec):
    lines = []
    for seg in rec['segments']:
        lines.append(''.join((ENGLISH.get(g, chr(g) if 32 <= g < 127 else f'[{g:03x}]') for g in seg['glyphs'])).rstrip())
    return [line for line in lines if line]

def glyph_words(rec):
    return sum((len(s['glyphs']) for s in rec['segments']))
