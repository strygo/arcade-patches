"""The USA edition's story text with stock Final Fight USA's typos fixed."""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import sys
import zipfile
import build_m1_spike as spike
import text_catalog as tc
TRACK = Path(__file__).resolve().parents[1]
FFCD = Path(__file__).resolve().parents[2] / 'ffightcd'
sys.path.insert(0, str(FFCD))
from ffcd.story_text import TYPOS, SPACE, parse, encode, text, fixed, patches, self_test
STOCK_HYPHEN = 45

def lowered(rec):
    """The record with every '-' it types (the 8x8 single-height 0x2D) as the"""
    return {**rec, 'segments': [dict(s, glyphs=[spike.CAPTION_HYPHEN if g == STOCK_HYPHEN else g for g in s['glyphs']]) for s in rec['segments']]}

def lowered_block(block, group1):
    """EX's text (its copy of the text block, SEGA CD's; EX_BUILD.md) with"""
    out, changed = (bytearray(block), 0)
    for index in range(tc.word(out, group1) // 2):
        start = group1 + tc.word(out, group1 + 2 * index)
        rec = parse(out, start)
        new = encode(lowered(rec))
        if new != bytes(out[start:start + len(new)]):
            out[start:start + len(new)] = new
            changed += 1
    return (bytes(out), changed)

def oracle(rompaths, directory):
    """Stock ffightu with the fixes, as ffightu.zip in ``directory``."""
    import english_oracle
    ffightu = spike.find_archive(rompaths, 'ffightu')
    program = spike.usa_program(ffightu)
    entries, receipt = patches(program)
    applied = spike.apply_patches(program, {}, entries)
    applied += spike.apply_patches(program, {}, spike.TEXT_FIXES)
    out = {name: spike.upstream.member(ffightu, name) for name in english_oracle.member_names(ffightu)}
    for name, offset, _ in spike.FFIGHTU_PROGRAM:
        out[name] = bytes(program[offset:offset + 262144:2])
    directory.mkdir(parents=True, exist_ok=True)
    archive = directory / 'ffightu.zip'
    with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as z:
        for name in sorted(out):
            info = zipfile.ZipInfo(name, date_time=(1990, 1, 12, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            z.writestr(info, out[name])
    receipt = {**receipt, 'source': ffightu.name, 'program_patches': applied, 'program_sha256': spike.sha256(bytes(program))}
    (directory / 'usa_oracle.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
    return (archive, receipt)
