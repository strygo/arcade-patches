from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
TRACK = Path(__file__).resolve().parents[1]
ROOT = TRACK.parents[1]
FFCD = ROOT / 'backports' / 'ffightcd'
REGIONS = {'usa': 'us', 'japan': 'jp', 'english': 'jp'}
BASE_CODE = 20480
SCROLL_GFX = 8388608
RESOLVED = {1412: "EX's object-base hook (jsr + nop): the layer's vblank_entry calls it (EX_OBJHOOK)"}
SOURCES = ('build', 'ffcd', 'data', 'control')

def changed_spans(stock, built):
    """[(start, end)] of the bytes built differs from stock in."""
    spans, start = ([], None)
    for i in range(len(stock)):
        if stock[i] != built[i]:
            if start is None:
                start = i
        elif start is not None:
            spans.append((start, i))
            start = None
    if start is not None:
        spans.append((start, len(stock)))
    return spans

def line_cells(record, start):
    """Addresses of each line's position word in a story text record at start:"""
    cells, at = ([start + 2], start + 6)
    while at + 2 <= start + len(record):
        word = int.from_bytes(record[at - start:at - start + 2], 'big')
        if word == 65535:
            cells.append(at + 2)
            at += 6
        elif word == 0:
            break
        else:
            at += 2
    return cells

def move_lines(program, stock, built, records):
    """EX's changes inside the text records this port rewrote: where EX moved"""
    handled, moves = (set(), [])
    for start, length in records:
        end = start + length
        changed = [a for a in range(start, end) if built[a] != stock[a]]
        if not changed:
            continue
        old = line_cells(bytes(stock[start:end]), start)
        new = line_cells(bytes(program[start:end]), start)
        if len(old) != len(new):
            raise SystemExit(f'text record {start:#x}: {len(old)} lines in stock, {len(new)} rewritten')
        for a in changed:
            if built[a] == program[a]:
                handled.add(a)
                continue
            line = next((k for k, c in enumerate(old) if c <= a < c + 2), None)
            if line is None:
                continue
            target = new[line] + (a - old[line])
            program[target] = built[a]
            handled.add(a)
            moves.append({'line': f'{old[line]:#x}', 'to': f'{new[line]:#x}', 'byte': f'{built[a]:02x}'})
    return (handled, moves)

def merge(program, stock, covered, scenes, records=(), sites=None, text=None, retime=frozenset()):
    """Lay the pieces into program (stock plus this port's patches; covered ="""
    built = scenes['program.bin']
    sites = {**{a: (8, why) for a, why in RESOLVED.items()}, **(sites or {})}
    trial, shadow = (bytearray(program), bytearray(program))
    handled, moves = move_lines(shadow, stock, built, records)
    lo, hi = text['block'] if text else (0, 0)
    stock_spans = [range(s, e) for s, e in (text or {}).get('stock', ())]
    drop = bool((text or {}).get('drop'))
    resolved, conflicts, applied, copied, skipped, dropped, unchanged = ({}, [], 0, 0, 0, 0, 0)
    for start, end in changed_spans(bytes(stock[:1048576]), built):
        for a in range(start, end):
            site = next((s for s, (n, _) in sites.items() if s <= a < s + n), None)
            if site is not None:
                resolved[site] = sites[site][1]
                continue
            if a in retime:
                skipped += 1
                continue
            mine = a in covered or program[a] != stock[a]
            if lo <= a < hi and drop:
                dropped += 1
                continue
            if lo <= a < hi:
                if any((a in r for r in stock_spans)):
                    unchanged += 1
                    continue
                if a in handled:
                    continue
                if mine:
                    conflicts.append(a)
                    continue
                shadow[a] = built[a]
                copied += 1
                continue
            if mine:
                conflicts.append(a)
                continue
            trial[a] = built[a]
            applied += 1
    if conflicts:
        raise SystemExit("EX's program changes collide with this port's patches at " + ', '.join((f'{a:#x}' for a in conflicts[:24])))
    receipt_text = None
    if text and drop:
        receipt_text = {'block': [f'{lo:#x}', f'{hi:#x}'], 'dropped_bytes': dropped, 'why': text['drop']}
    elif text:
        home = text['home']
        block = bytes(shadow[lo:hi])
        if any((b != 255 for b in trial[home:home + len(block)])):
            raise SystemExit(f"EX's text copy home {home:#x} is not free")
        trial[home:home + len(block)] = block
        receipt_text = {'block': [f'{lo:#x}', f'{hi:#x}'], 'home': f'{home:#x}', 'changed_bytes': copied, 'stock_bytes': unchanged, 'sha256': hashlib.sha256(block).hexdigest()}
    manifest = scenes['manifest']
    data_base = int(manifest['data'], 16)
    data = scenes['data.bin'].rstrip(b'\xff')
    if data_base + len(data) > len(trial):
        raise SystemExit(f"EX's data ROM ({len(data)} bytes at {data_base:#x}) runs past the program's end")
    if any((b != 255 for b in trial[data_base:data_base + len(data)])):
        raise SystemExit(f"EX's data ROM home {data_base:#x} is not free")
    trial[data_base:data_base + len(data)] = data
    program[:] = trial
    art_at = SCROLL_GFX + BASE_CODE * 128
    receipt = {'inputs_sha256': scenes['inputs_sha256'], 'pieces': manifest['files'], 'program_bytes': applied, 'retime_bytes_left_out': skipped, 'resolved': {f'{a:#x}': why for a, why in sorted(resolved.items())}, 'text': receipt_text, 'moved_lines': moves, 'data': {'home': f'{data_base:#x}', 'bytes': len(data)}, 'art': {'home': f'{art_at:#x}', 'bytes': len(scenes['art.bin'])}, 'entries': manifest['entries']}
    return ([(art_at, scenes['art.bin'])], receipt)

def retime_addresses(region, stock):
    """The bytes CPS1 EX's story retime to the CD timeline (its stage0 program"""
    if str(FFCD / 'build') not in sys.path:
        sys.path.insert(0, str(FFCD / 'build'))
    import stage_inputs
    even, odd = stage_inputs.retimed(region, bytes(stock[0:262144:2]), bytes(stock[1:262144:2]))
    out = set()
    for i in range(len(even)):
        if even[i] != stock[2 * i]:
            out.add(2 * i)
        if odd[i] != stock[2 * i + 1]:
            out.add(2 * i + 1)
    return frozenset(out)
