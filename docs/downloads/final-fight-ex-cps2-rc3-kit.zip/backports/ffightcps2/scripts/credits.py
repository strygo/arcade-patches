"""The port's credit in the ending's staff roll: "cps-2 port" and its author."""
from __future__ import annotations
import struct
CREDITS_SRC = 102292
CREDITS_POINTER = 101982
CREDITS_HOME = 3147008
STOCK_ROWS, STOCK_BYTES = (87, 1946)
FIELD = 16
DOT = 96
HEADER_ATTR, NAME_ATTR = (6, 0)
HEADER = 'cps-2 port'
EX_HEADERS = ('cd cutscenes', HEADER)
NAME = bytes.fromhex('535445564520474f52444f4e').decode('ascii')
DOTS = 3
BLOCK_ROWS = 7
ROW_PIXELS, FRAMES_PER_PIXEL = (8, 2)
ROLL_TAIL = (102130, 272)
LOWER = {'a': 228, 'b': 229, 'c': 230, 'd': 231, 'e': 232, 'f': 233, 'h': 234, 'i': 235, 'k': 236, 'l': 237, 'n': 256, 'o': 257, 'r': 258, 's': 259, 't': 260, 'u': 261, 'g': 267, 'j': 268, 'p': 269, ' ': 32}
PAIRS = {'m': (238, 239)}
NEW_CELLS = {'-': 15425, '2': 15426}
NEW_ART = {'-': ('........', '........', '........', '........', '........', '........', '........', '........', '.99999..', '.999998.', '..88888.', '........', '........', '........', '........', '........'), '2': ('........', '.0000...', '.eeee8..', 'dd88dd8.', 'dd8.dd8.', '.8..cc8.', '...bb88.', '..aa88..', '..998...', '.998....', '.aa8....', 'bb8.....', 'cc8.....', 'dddddd8.', 'eeeeeee8', '.8888888')}

def be16(value):
    return struct.pack('>H', value)

def row(attr, cells):
    return be16(attr) + b''.join((be16(c) for c in cells)) + be16(0)

def dot_row():
    return row(NAME_ATTR, [32] * ((FIELD - 1) // 2) + [DOT])

def header_rows(text):
    cells = []
    for ch in text:
        cells.extend(PAIRS.get(ch) or (NEW_CELLS.get(ch) or LOWER[ch],))
    if len(cells) > FIELD:
        raise ValueError(f"header {text!r} is {len(cells)} cells, wider than the roll's {FIELD}")
    lead = [32] * ((FIELD - len(cells)) // 2)
    return row(HEADER_ATTR, lead + cells) + row(HEADER_ATTR, lead + [c if c == 32 else c + 16 for c in cells])

def name_row(text):
    if len(text) > FIELD or not all((32 <= ord(c) < 127 for c in text)):
        raise ValueError(f"name {text!r} does not fit the roll's ASCII field")
    return row(NAME_ATTR, [32] * ((FIELD - len(text)) // 2) + [ord(c) for c in text])

def parse(stream):
    """The stream's rows, each with its attribute word, the terminator last."""
    rows, at = ([], 0)
    while True:
        attr = struct.unpack_from('>H', stream, at)[0]
        start = at
        at += 2
        if attr & 32768:
            rows.append((attr, bytes(stream[start:at])))
            return rows
        while struct.unpack_from('>H', stream, at)[0]:
            at += 2
        at += 2
        rows.append((attr, bytes(stream[start:at])))

def glyphs(raw):
    return [struct.unpack_from('>H', raw, k)[0] for k in range(2, len(raw) - 2, 2)]

def collapse(rows):
    """Each run of dot and blank rows holding a blank row becomes one dot."""
    out, i, saved = ([], 0, 0)
    kind = lambda attr, raw: None if attr & 32768 else 'blank' if not glyphs(raw) else 'dot' if all((g in (32, DOT) for g in glyphs(raw))) else None
    while i < len(rows):
        j = i
        while j < len(rows) and kind(*rows[j]):
            j += 1
        if j > i and any((kind(*r) == 'blank' for r in rows[i:j])):
            out.append((NAME_ATTR, dot_row()))
            saved += j - i - 1
            i = j
        elif j > i:
            out.extend(rows[i:j])
            i = j
        else:
            out.append(rows[i])
            i += 1
    return (out, saved)

def build(stream, headers=(HEADER,), name=NAME):
    """The roll with the credit, and a receipt of its rows: the headers"""
    rows = parse(stream)
    collapsed, saved = collapse(rows)
    tops = [k for k, (attr, raw) in enumerate(collapsed) if attr == HEADER_ATTR and (not any((g >= 272 for g in glyphs(raw))))]
    at = tops[-1]
    block = b''.join((header_rows(h) for h in headers)) + dot_row() * DOTS + name_row(name) + dot_row()
    out = b''.join((r for _, r in collapsed[:at])) + block + b''.join((r for _, r in collapsed[at:]))
    added = len(parse(block + be16(32768))) - 1
    return (out, {'stock_rows': len(rows), 'blank_rows_merged': saved, 'credit_rows': added, 'rows': len(rows) - saved + added, 'headers': list(headers), 'name': name})

def tail_patch(rows):
    """The patch (address, stock hex, new hex, reason) that shortens the"""
    extra = rows - STOCK_ROWS
    if not extra:
        return None
    address, stock = ROLL_TAIL
    tail = stock - extra * ROW_PIXELS
    if extra < 0 or tail < 0:
        raise ValueError(f'a roll of {rows} rows has no tail to give back')
    return (address, f'0c40{stock:04x}', f'0c40{tail:04x}', f"the staff roll's tail {tail} pixels, not {stock}: its {extra} more rows end on the stock frame (credits.py)")

def tile(art):
    """Scroll 1 tile bytes for 8 pen rows, the same 8x8 in both halves"""
    out = bytearray()
    for line in art:
        planes = [0, 0, 0, 0]
        for x, ch in enumerate(line):
            pen = 15 if ch == '.' else int(ch, 16)
            for k in range(4):
                planes[k] |= (pen >> k & 1) << 7 - x
        out += bytes(planes) * 2
    return bytes(out)

def pieces():
    """The new glyphs' tiles as (CPS2 graphics offset, bytes), top and bottom."""
    out = []
    for ch, cell in NEW_CELLS.items():
        top = 8388608 + (17408 + cell) * 64
        out += [(top, tile(NEW_ART[ch][:8])), (top + 16 * 64, tile(NEW_ART[ch][8:]))]
    return out
