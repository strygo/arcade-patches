"""QSound members for the CPS2 development archive, from a keyed cache."""
from __future__ import annotations
from pathlib import Path
import build_m1_spike as spike
import ff_sound as fs
HERE = Path(__file__).resolve().parent
CACHE = HERE.parent / 'work' / 'cache' / 'sound'
SOURCES = ('ff_audio.py', 'qsound171.py', 'ff_sound.py', 'ym_voice.py', 'ym2151_render.cpp', 'bootstrap_ymfm.py', 'sound_members.py')
NAMES = ('sz3.01', 'sz3.02', 'sz3.11m', 'sz3.12m')
SFA3_SAMPLES = (('sz3.11m', 478801617), ('sz3.12m', 4086477114))
FMLOOP = HERE.parents[1] / 'ffightcd' / 'build' / 'fmloop.py'

def music_cues(z80):
    """Every music cue: mode 0 with at least one channel."""
    return tuple((s.cue for s in fs.songs(z80) if s and s.mode == 0 and any(s.channels)))

def from_products(rompaths, products, effect_gains=None, opening=None):
    """(members, receipt) from ff_audio's products, without the renderer or"""
    import ff_audio
    music = music_cues(fs.load(rompaths)[0])
    image, receipt = ff_audio.build(rompaths, None, music, effect_gains, opening, products=products)
    built = image.members()
    receipt['members'] = {name: spike.identity(built[name]) for name in NAMES}
    receipt['cache_key'] = 'kit'
    return ({name: built[name] for name in NAMES}, receipt)
