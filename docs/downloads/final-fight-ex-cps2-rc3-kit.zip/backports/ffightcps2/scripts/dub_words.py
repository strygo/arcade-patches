"""The redub's words on the game's clock: where each English line's words fall, as the mix places them."""
from __future__ import annotations
import hashlib
import json
import re
from pathlib import Path
TRACK = Path(__file__).resolve().parents[1]
WORDS = TRACK / 'manifests' / 'dub_words.json'
DUB_MIX = TRACK / 'manifests' / 'dub_mix_receipt.json'
PAD_S = 0.25

def norm(word):
    """A word as compared: lowercase letters and digits, apostrophes dropped."""
    return re.sub('[^a-z0-9]', '', word.lower())

def receipt_digest():
    return hashlib.sha256(DUB_MIX.read_bytes()).hexdigest()

def load(scene=None):
    """{line: row} of dub_words.json, refusing one measured from another mix receipt."""
    doc = json.loads(WORDS.read_text(encoding='utf-8'))
    if doc['receipt_sha256'] != receipt_digest():
        raise ValueError("dub_words.json is not the mix receipt's: run dub_words.py measure")
    return {k: v for k, v in doc['lines'].items() if scene is None or v['scene'] == scene}

def find(words, text, after=0):
    """The index of the first word of text in words at or after index after: the first word that"""
    if not words:
        return None
    want = [norm(w) for w in text.split() if norm(w)]
    if not want:
        return after
    for k in range(after, len(words)):
        got = norm(words[k][0])
        if got and (got == want[0] or (len(want[0]) >= 3 and got.startswith(want[0][:3]))):
            return k
    return min(after, len(words) - 1)
