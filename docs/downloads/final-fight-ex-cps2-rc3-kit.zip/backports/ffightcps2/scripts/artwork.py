"""EX's ARTWORK ARCADE STADIUM: Capcom Arcade Stadium's Final Fight graphics."""
from __future__ import annotations
import json
from pathlib import Path
import build_m1_spike as spike
TRACK = Path(__file__).resolve().parents[1]
ROOT = TRACK.parents[1]
CAS_DIR = ROOT / 'extraction' / 'cas'
CAS_ZIPS = {'ffightj': ('ffightj.mameac.2', 1496859, 'e6781a82f6c5feca16214199dddc1360973c6033f86545a42b1acdc634b8102e'), 'ffightu': ('ffightu.mameac.2', 1433790, '018ff13d63d6dfd5fe0ef6d134469fe9f1f17427a330857a89613644d2d001a4')}
CAS_NSP = 'Capcom Arcade Stadium [FINAL FIGHT][01001E0013209019][US][v0].nsp'
CAS_NSP_SHA256 = '6eab18d4f07d1a6d9f701725256129c8dc3e3e9b239098e5d579b2522f0307c0'
CHANGED_BYTES = 412
TILES_ASSET = TRACK / 'assets' / 'arcade_stadium_tiles.json'
TILE_NAMES = ('can', 'sign_left', 'sign_right')
CAN_TILE = 6205
SIGN_TILES = (2898, 2899)
CAN_CODE = 22528
SIGN_CODES = (14080, 14081)
OBJ_BYTES, S3_BYTES = (128, 512)
ITEM_TABLE = 370044
ITEM_TYPES = 36
ITEM_BLOCK = (369226, 369926)
CAN_FRAME_CODE = 369586
S3_WORD_BASE = 2432
SIGN_BLOCK = 535552
SIGN_CELLS = (535652, 535656)
EX_ART = 3149824
EX_ITEM_ANIMS = EX_ART
EX_ITEM_BLOCK = EX_ART + 256
EX_SIGN_BLOCK = EX_ART + 1024

def tile_spans():
    return [(CAN_TILE * OBJ_BYTES, OBJ_BYTES)] + [(code * S3_BYTES, S3_BYTES) for code in SIGN_TILES]

def item_copies(program):
    """(table copy, block copy): the item animations with the can frame"""
    start, end = ITEM_BLOCK
    table = [int.from_bytes(program[ITEM_TABLE + 4 * i:ITEM_TABLE + 4 * i + 4], 'big') for i in range(ITEM_TYPES)]
    if not all((start <= step < end for step in table)):
        raise ValueError('an item animation starts outside the item block')
    block = bytearray(program[start:end])
    if int.from_bytes(block[CAN_FRAME_CODE - start:CAN_FRAME_CODE - start + 2], 'big') != CAN_TILE:
        raise ValueError("the can frame's code word moved")
    block[CAN_FRAME_CODE - start:CAN_FRAME_CODE - start + 2] = CAN_CODE.to_bytes(2, 'big')
    return (b''.join(((step - start + EX_ITEM_BLOCK).to_bytes(4, 'big') for step in table)), bytes(block))

def sign_copy(program):
    block = bytearray(program[SIGN_BLOCK:SIGN_BLOCK + 256])
    for cell, tile, code in zip(SIGN_CELLS, SIGN_TILES, SIGN_CODES):
        at = cell - SIGN_BLOCK
        if int.from_bytes(block[at:at + 2], 'big') != tile - S3_WORD_BASE:
            raise ValueError(f'sign cell {cell:#x} moved')
        block[at:at + 2] = (code - S3_WORD_BASE).to_bytes(2, 'big')
    return bytes(block)

def embedded_tiles(region, asset=None):
    """The asset's three tiles, after checking them, the edition's stock"""
    if asset is None:
        raise ValueError('This recipient requires prepared asset')
    doc = json.loads(asset)
    tiles, differing = ([], 0)
    for row, name, (at, n) in zip(doc['tiles'], TILE_NAMES, tile_spans()):
        data = bytes.fromhex(row['hex'])
        stock = bytes(region[at:at + n])
        if row['name'] != name or len(data) != n or spike.sha256(data) != row['sha256']:
            raise ValueError(f'{TILES_ASSET.name}: tile {name} is not as pinned')
        if spike.sha256(stock) != row['stock_sha256']:
            raise ValueError(f"the edition's stock tile {row['tile']} is not the one {name} was taken against")
        differing += sum((1 for a, b in zip(data, stock) if a != b))
        tiles.append(data)
    if differing != CHANGED_BYTES or doc['changed_bytes'] != CHANGED_BYTES:
        raise ValueError(f'the embedded tiles differ from stock by {differing} bytes, not {CHANGED_BYTES}')
    return tiles

def build(edition, stock_program, region, asset=None):
    """(program pieces, graphics pieces, receipt) for an EX build; asset: the"""
    if asset is None:
        raise ValueError('This recipient requires prepared asset')
    asset = asset
    can, *sign = embedded_tiles(region, asset)
    table, block = item_copies(stock_program)
    program = [(EX_ITEM_ANIMS, table), (EX_ITEM_BLOCK, block), (EX_SIGN_BLOCK, sign_copy(stock_program))]
    if EX_ITEM_BLOCK + len(block) > EX_SIGN_BLOCK:
        raise ValueError('the item block copy runs into the sign block copy')
    graphics = [(CAN_CODE * OBJ_BYTES, can)] + [(8388608 + code * S3_BYTES, tile) for code, tile in zip(SIGN_CODES, sign)]
    receipt = {'tiles': {'asset': TILES_ASSET.name, 'sha256': spike.sha256(asset.encode())}, 'can': {'tile': f'{CAN_TILE:#x}', 'code': f'{CAN_CODE:#x}', 'sha256': spike.sha256(can)}, 'sign': {'tiles': [f'{t:#x}' for t in SIGN_TILES], 'codes': [f'{c:#x}' for c in SIGN_CODES], 'sha256': spike.sha256(b''.join(sign))}, 'program': {f'{at:#x}': spike.identity(piece) for at, piece in program}}
    return (program, graphics, receipt)
