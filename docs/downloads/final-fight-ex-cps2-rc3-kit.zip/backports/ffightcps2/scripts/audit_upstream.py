"""Inspect pinned FFAE patches and optionally compare owner's arcade inputs."""
from __future__ import annotations
import argparse
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys
import urllib.request
import zipfile
import zlib
PINS = {'cps1_source': ('originalgrego/FinalFightAE-Source', '5250b09d128997a43e4a4fef6c683577a37bdd0e'), 'cps1_installer': ('originalgrego/FinalFightAE-Installer', 'ea53276170aa5df85915a75194803fe4655b6058'), 'cps2_installer': ('originalgrego/FinalFightAE-CPS2-Installer', 'be1fe5ab3631a0eb42b18069540a6172c3d21987'), 'rommangler_reference': ('originalgrego/RomMangler', 'f1673906a5f9493745c3cf21ecf28fc908cbdbb9'), 'hbmame_reference': ('Robbbert/hbmame', '91be9e0ad51a2a9832a72b9bd3e503c3e79e409a')}
FILES = {'cps1_program': ('cps1_installer', 'ffight_hack.ips'), 'cps1_graphics': ('cps1_installer', 'ffight_gfx_new.ips'), 'cps2_program': ('cps2_installer', 'ips/ffae_cps2_prg_patch.ips'), 'cps2_graphics': ('cps2_installer', 'ips/ffae_cps2_gfx_patch.ips'), 'cps2_audio': ('cps2_installer', 'ips/ffae_cps2_audio_prg_patch.ips'), 'cps2_installer_java': ('cps2_installer', 'src/com/feverbrainstudios/ffae_installer/FFAEInstaller.java'), 'cps2_graphics_layout': ('cps2_installer', 'split_cfgs/final_fight_recombine_gfx_cps2.cfg'), 'cps2_sample_rom': ('cps2_installer', 'data/sz3.11m'), 'cps2_phoenix_key': ('cps2_installer', 'data/phoenix.key'), 'cps2_hardware_key': ('cps2_installer', 'data/key'), 'rommangler_reference_java': ('rommangler_reference', 'src/com/feverbrainstudios/RomMangler.java'), 'hbmame_cps2_reference': ('hbmame_reference', 'src/mame/capcom/cps2.cpp'), 'hbmame_cps2_set_reference': ('hbmame_reference', 'src/hbmame/drivers/cps2mis.cpp'), 'hbmame_graphics_reference': ('hbmame_reference', 'src/mame/capcom/cps1_v.cpp')}
STOCK = {'ff_36.11f': (131072, 4188393091), 'ff_42.11h': (131072, 1710297621), 'ff_37.12f': (131072, 3775084420), 'ffe_43.12h': (131072, 2573112970), 'ff-32m.8h': (524288, 3343346030)}
STOCK_GFX = {'ff-5m.7a': 2619883784, 'ff-7m.9a': 2807582203, 'ff-1m.3a': 190864964, 'ff-3m.5a': 1378426066}
HOOKS = {'EX_object_base': (1412, 8), 'EX_palette_DMA': (1428, 8), 'EX_vblank': (1440, 6), 'EX_story_table': (94412, 10), 'EX_opening_init': (94454, 6), 'EX_opening_stub': (94594, 6), 'EX_reunion_blackout': (99920, 6), 'EX_reunion_init': (100026, 6), 'EX_farewell_blackout': (100970, 6), 'EX_farewell_init': (101074, 6), 'EX_credits_pointer': (101982, 4), 'region_word': (468480, 2), 'EX_engine1_home': (876544, 4096), 'EX_engine2_home': (880640, 4096), 'EX_engine3_home': (884736, 4096)}

def identity(data):
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(), 'crc32': f'{zlib.crc32(data):08x}'}

def download(url):
    req = urllib.request.Request(url, headers={'User-Agent': 'capcom-ffightcps2-audit'})
    with urllib.request.urlopen(req, timeout=60) as response:
        return response.read()

def raw(project, path):
    repo, revision = PINS[project]
    return download(f'https://raw.githubusercontent.com/{repo}/{revision}/{path}')

def records(data):
    if data[:5] != b'PATCH':
        raise ValueError('invalid IPS header')
    result, pos = ([], 5)
    while True:
        if pos + 3 > len(data):
            raise ValueError('truncated IPS offset')
        address = data[pos:pos + 3]
        pos += 3
        if address == b'EOF':
            if len(data) - pos not in (0, 3):
                raise ValueError('invalid IPS trailer')
            size = int.from_bytes(data[pos:], 'big') if pos < len(data) else None
            return (result, size)
        address = int.from_bytes(address, 'big')
        if pos + 2 > len(data):
            raise ValueError('truncated IPS size')
        length = int.from_bytes(data[pos:pos + 2], 'big')
        pos += 2
        if length:
            if pos + length > len(data):
                raise ValueError('truncated IPS payload')
            payload = data[pos:pos + length]
            pos += length
        else:
            if pos + 3 > len(data):
                raise ValueError('truncated IPS RLE')
            length = int.from_bytes(data[pos:pos + 2], 'big')
            if not length:
                raise ValueError('empty IPS RLE')
            payload = data[pos + 2:pos + 3] * length
            pos += 3
        result.append((address, payload))

def writes(data):
    result = {}
    for address, payload in records(data)[0]:
        result.update(((address + n, value) for n, value in enumerate(payload)))
    return result

def overlay(base, patch):
    """Reconstruct in memory for hash comparison, with no ROM file output."""
    result = bytearray(base)
    entries, size = records(patch)
    for address, payload in entries:
        end = address + len(payload)
        if end > len(result):
            result.extend(bytes(end - len(result)))
        result[address:end] = payload
    if size is not None:
        result = result[:size] + bytes(max(0, size - len(result)))
    return bytes(result)

def ips_summary(data):
    entries, size = records(data)
    positions = writes(data)
    return {**identity(data), 'records': len(entries), 'distinct_written_bytes': len(positions), 'last_written_byte_exclusive': f'0x{max(positions, default=-1) + 1:x}', 'truncate_to': size, 'written_bytes_by_64_KiB_page': {f'0x{page:x}': sum((page <= p < page + 65536 for p in positions)) for page in sorted({p & ~65535 for p in positions})}}

def swap_words(data):
    if len(data) % 2:
        raise ValueError('odd word ROM length')
    result = bytearray(len(data))
    result[0::2], result[1::2] = (data[1::2], data[0::2])
    return bytes(result)

def reshuffle(data, bank_size=2097152):
    if len(data) % bank_size or bank_size % 16:
        raise ValueError('invalid reshuffle bank size')
    result = bytearray(len(data))
    half = bank_size // 2
    for start in range(0, len(data), bank_size):
        end = start + bank_size
        for lane in range(8):
            result[start + lane:end:16] = data[start + lane:start + half:8]
            result[start + 8 + lane:end:16] = data[start + half + lane:end:8]
    return bytes(result)

def member(archive, name):
    if archive.suffix == '.zip':
        with zipfile.ZipFile(archive) as z:
            return z.read(name)
    seven = shutil.which('7zz') or shutil.which('7z')
    if not seven:
        raise ValueError('7z/7zz is required to read the supplied 7z input')
    return subprocess.run([seven, 'e', '-so', str(archive), name], check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE).stdout

def archive(root, stem):
    for ext in ('.zip', '.7z'):
        path = root / (stem + ext)
        if path.is_file():
            return path
    raise ValueError(f'missing canonical {stem}.zip or {stem}.7z in the supplied ROM path')

def compare_roms(root, assets, first, second):
    source, target = (archive(root, 'ffight'), archive(root, 'ffightae_cps2'))
    stock = {name: member(source, name) for name in STOCK}
    for name, (size, crc) in STOCK.items():
        if (len(stock[name]), zlib.crc32(stock[name])) != (size, crc):
            raise ValueError(f'stock identity mismatch for {name}')
    base = bytearray(1048576)
    for name, offset in (('ff_36.11f', 0), ('ff_42.11h', 1), ('ff_37.12f', 262144), ('ffe_43.12h', 262145)):
        base[offset:offset + 262144:2] = stock[name]
    base[524288:] = swap_words(stock['ff-32m.8h'])
    final = swap_words(member(target, 'ff-23m.8h')) + swap_words(member(target, 'ff-22m.7h'))
    rebuilt = overlay(base, assets['cps2_program'])
    if rebuilt != final:
        raise ValueError('supplied CPS2 program does not match pinned upstream patch')
    sfa = archive(root, 'sfa3')
    audio_inputs = {name: member(sfa, name) for name in ('sz3.01', 'sz3.02')}
    for name, crc in (('sz3.01', 3732996228), ('sz3.02', 1917083076)):
        if len(audio_inputs[name]) != 131072 or zlib.crc32(audio_inputs[name]) != crc:
            raise ValueError(f'SFA3 audio identity mismatch for {name}')
    audio_base = audio_inputs['sz3.01'] + audio_inputs['sz3.02']
    audio_final = member(target, 'sz3.01') + member(target, 'sz3.02')
    if overlay(audio_base, assets['cps2_audio']) != audio_final:
        raise ValueError('supplied CPS2 audio program does not match pinned upstream patch')
    sample_matches = member(target, 'sz3.11m') == assets['cps2_sample_rom']
    key_matches = member(target, 'phoenix.key') == assets['cps2_phoenix_key']
    if not sample_matches or not key_matches:
        raise ValueError('supplied CPS2 sample/key does not match pinned upstream')
    gfx = bytearray(2097152)
    gfx_inputs = {}
    for lane, (name, crc) in enumerate(STOCK_GFX.items()):
        data = member(source, name)
        if len(data) != 524288 or zlib.crc32(data) != crc:
            raise ValueError(f'stock graphics identity mismatch for {name}')
        gfx_inputs[name] = identity(data)
        gfx[lane * 2::8], gfx[lane * 2 + 1::8] = (data[0::2], data[1::2])
    layout = bytearray(b'\xff' * 16777216)
    for src, dst, size in ((0, 0, 1114112), (1114112, 9502720, 131072), (1245184, 9633792, 327680), (1572864, 9961472, 524288)):
        layout[dst:dst + size] = gfx[src:src + size]
    gfx_rebuilt = overlay(reshuffle(layout), assets['cps2_graphics'])
    gfx_final = bytearray(16777216)
    for lane, name in enumerate(STOCK_GFX):
        data = member(target, name)
        if len(data) != 4194304:
            raise ValueError(f'unexpected CPS2 graphics length for {name}')
        gfx_final[lane * 2::8], gfx_final[lane * 2 + 1::8] = (data[0::2], data[1::2])
    if gfx_rebuilt != gfx_final:
        raise ValueError('supplied CPS2 graphics do not match pinned upstream recipe')
    hooks = {}
    for name, (start, size) in HOOKS.items():
        hooks[name] = {'start': f'0x{start:x}', 'bytes': size, 'cps1_ips_covered_bytes': sum((p in first for p in range(start, start + size))), 'cps2_ips_covered_bytes': sum((p in second for p in range(start, start + size))), 'cps2_changed_bytes_from_stock': sum((a != b for a, b in zip(base[start:start + size], final[start:start + size])))}
    return {'inputs': {**{name: identity(data) for name, data in {**stock, **audio_inputs}.items()}, **gfx_inputs}, 'cps2_program': identity(final), 'cps2_program_reconstructed_exactly': True, 'cps2_audio_program_reconstructed_exactly': True, 'cps2_graphics_reconstructed_exactly': True, 'cps2_graphics': identity(gfx_final), 'sample_matches_upstream': sample_matches, 'phoenix_key_matches_upstream': key_matches, 'hooks': hooks, 'runtime_qualification': 'not_run; static comparison only'}

def contracts(assets):
    root = Path(__file__).resolve().parents[3]
    path = 'backports/ffightcd/build/engine.py'
    data = (root / path).read_bytes()
    state = int(re.search(b'^STATE\\s*=\\s*(0x[0-9a-f]+)', data, re.I | re.M)[1], 16)
    driver = assets['hbmame_cps2_reference'].decode()
    dead_map = driver.split('void cps2_state::dead_cps2_map(address_map &map)', 1)[1].split('\n}', 1)[0]
    output = re.search('map\\((0x[0-9a-f]+), (0x[0-9a-f]+)\\)\\.ram\\(\\)\\.share\\(m_output\\)', dead_map)
    low, high = (int(value, 16) for value in output.groups())
    sys.path.insert(0, str(root / 'extraction'))
    from cps2_code_guard import opcode_range
    _, _, is_dead = opcode_range(assets['cps2_phoenix_key'])
    return {'EX_engine_source': {'path': path, **identity(data)}, 'EX_state_start': f'0x{state:x}', 'Phoenix_sprite_output_start': f'0x{low:x}', 'Phoenix_sprite_output_end_inclusive': f'0x{high:x}', 'EX_state_conflicts_with_Phoenix_output': low <= state <= high, 'upstream_key_is_Phoenix_plaintext': is_dead, 'encryption_guard_status': 'Phoenix is a distinct plaintext policy; no encrypted-ROM certification inferred'}

def inspect(root=None):
    with ThreadPoolExecutor(max_workers=4) as pool:
        payloads = list(pool.map(lambda item: raw(*item), FILES.values()))
    assets = dict(zip(FILES, payloads))
    source_repo, source_rev = PINS['cps1_source']
    source_tree = json.loads(download(f'https://api.github.com/repos/{source_repo}/git/trees/{source_rev}?recursive=1'))
    names = sorted((item['path'] for item in source_tree['tree'] if item['path'].endswith('.asm')))
    with ThreadPoolExecutor(max_workers=4) as pool:
        sources = list(pool.map(lambda name: raw('cps1_source', name), names))
    first, second = (writes(assets['cps1_program']), writes(assets['cps2_program']))
    shared = first.keys() & second.keys()
    modules = {}
    org_re = re.compile('^\\s*org\\s+(0x[0-9a-f]+|\\$[0-9a-f]+|[0-9]+)\\b', re.I | re.M)
    for name, data in zip(names, sources):
        sites = [int(token[1:], 16) if token.startswith('$') else int(token, 0) for token in org_re.findall(data.decode('utf-8', errors='replace'))]
        modules[name] = {**identity(data), 'org_sites': [f'0x{s:x}' for s in sites], 'org_sites_touching_cps2_patch_within_8_bytes': sum((any((s + n in second for n in range(8))) for s in sites))}
    report = {'schema': 1, 'kind': 'static_feasibility_receipt', 'pins': {name: {'repository': repo, 'commit': rev} for name, (repo, rev) in PINS.items()}, 'files': {name: {'path': FILES[name][1], **(ips_summary(data) if FILES[name][1].endswith('.ips') else identity(data))} for name, data in assets.items()}, 'program_ips_overlap': {'shared_written_addresses': len(shared), 'shared_addresses_with_identical_final_value': sum((first[p] == second[p] for p in shared)), 'cps1_only_written_addresses': len(first.keys() - second.keys()), 'cps2_only_written_addresses': len(second.keys() - first.keys()), 'interpretation': 'Sparse IPS coverage is not semantic ownership; do not invert patches from these counts.'}, 'upstream_key_files_identical': assets['cps2_phoenix_key'] == assets['cps2_hardware_key'], 'hardware_contracts': contracts(assets), 'cps1_source_modules': modules}
    if root is not None:
        report['owner_arcade_comparison'] = compare_roms(root, assets, first, second)
    return report
