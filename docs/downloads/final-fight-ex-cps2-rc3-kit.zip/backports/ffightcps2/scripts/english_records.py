"""The English restoration's story records, on the Japanese timeline."""
from __future__ import annotations
import json
from pathlib import Path
import struct
import sys
import english_layout as layout
import text_catalog as tc
TRACK = Path(__file__).resolve().parents[1]
TEXT = TRACK / 'text'
LOOKUP = 5022
LOOKUP_STOCK = '43f9000685663031000043f10000'
HOME, HOME_END = (468482, 524288)
RECORDS = 63
STAFF_LOOKUPS = (4878, 4944)
STAFF_LOOKUP_STOCK = '43f9000670823031000043f10000'
STAFF = (10, 11, 13, 14)
PORTRAIT_GLYPHS = (1280, 1336)
PORTRAIT_BASE = 15360
PROFILE_HOLDS = {'profile-guy': 97212, 'profile-cody': 97524, 'profile-haggar': 97836}
PROFILE_HOLD = 90
STORY_LINES = 96673
STORY_HOLDS = {0: (94606, 50), 1: (94752, 50), 2: (94796, 50), 3: (94836, 50), 4: (95094, 40), 5: (95134, 40), 6: (95176, 40), 7: (95300, 40), 8: (95340, 40), 9: (95380, 40), 10: (95870, 40), 11: (95910, 40), 12: (95952, 40), 13: (96044, 40), 14: (96084, 40), 15: (96134, 40), 16: (96326, 40), 17: (96464, 40), 18: (96506, 50), 19: (96546, 40)}
ARCADE_OPENING_ROUNDS = (2, 0)
SONG_EXTRA_FRAMES = 429
YEAR = ('year', 8)
ENDINGS = {'ending-reunion': [(6, 0, 2, 6, 0), (14, 2, 2, 11, 0), (14, 4, 5, 15, 16)], 'ending-father': [(6, 0, 1, 26, 16)]}

def approved():
    """id -> (Japanese record id, layout record at delay 1)."""
    lines = {r['id']: r for r in json.loads((TEXT / 'english_decisions.json').read_text(encoding='utf-8'))['lines']}
    round2 = {p['id']: p for p in json.loads((TEXT / 'english_round2.json').read_text(encoding='utf-8'))['proposals']}
    props = {e['id']: e for e in json.loads((TEXT / 'english_proposals.json').read_text(encoding='utf-8'))['entries']}
    out = {}
    for pid, row in lines.items():
        if not row['decision'].startswith(('approved', "author's wording")):
            raise ValueError(f"{pid} is not approved: {row['decision']}")
        text = row.get('lines') or row['text']
        if pid in round2 and round2[pid]['layout'] == 'profile':
            rec = layout.profile(round2[pid]['name'], round2[pid]['body'])
        elif pid in round2:
            rec = layout.ending([(p['pal'], p['lines'], p['row'], p['pause']) for p in round2[pid]['parts']], 1)
        elif pid in ENDINGS:
            rec = layout.ending([(pal, text[a:a + n], r, pause) for pal, a, n, r, pause in ENDINGS[pid]], 1)
        elif pid == YEAR[0]:
            rec = layout.caption(text, 'card', 14, 1)
        else:
            rec = layout.caption(text, 'map' if pid.startswith('map') else 'story', 14, 1)
        out[pid] = (int(props[pid]['japan_record'], 16), rec)
    return out

def glyph_words(rec):
    return sum((len(s['glyphs']) for s in rec['segments']))

def fit(rec, jp_frames, jp_delay, mode):
    """The record at the slowest delay (up to the Japanese one) that types in"""
    words = glyph_words(rec)
    space = layout.LARGE_SPACE if mode == 2 else layout.SMALL_SPACE
    for delay in range(jp_delay, 0, -1):
        if delay * words <= jp_frames and jp_frames % delay == 0:
            pad = jp_frames // delay - words
            segs = rec['segments'] + ([{'col': 0, 'row': 0, 'pal': 0, 'glyphs': [space] * pad}] if pad else [])
            return ({**rec, 'delay': delay, 'segments': segs}, 0)
    return ({**rec, 'delay': 1}, words - jp_frames)

def fit_story(rec, jp_frames, jp_delay):
    """A story caption at the Japanese speed: (record, frames it types past"""
    words = glyph_words(rec)
    if jp_delay * words <= jp_frames:
        return fit(rec, jp_frames, jp_delay, rec['mode'])
    return ({**rec, 'delay': jp_delay}, jp_delay * words - jp_frames)

def share(total, weights):
    """total frames shared in proportion to weights {key: w}, largest"""
    whole = sum(weights.values())
    raw = {k: total * w / whole for k, w in weights.items()}
    out = {k: int(v) for k, v in raw.items()}
    for k in sorted(raw, key=lambda k: (out[k] - raw[k], k))[:total - sum(out.values())]:
        out[k] += 1
    return out

def encode(rec, header=True):
    out = bytes([rec['delay'], rec['mode']]) if header else b''
    for k, s in enumerate(rec['segments']):
        if k:
            out += b'\x80\x00'
        out += struct.pack('>HH', s['col'] * 128 + s['row'] * 4, s['pal'])
        out += b''.join((struct.pack('>H', g) for g in s['glyphs']))
    return out + b'\x00\x00'

def year_record(rec):
    """Group A draws at once, both rows given: the glyphs, then their lower"""
    segs = rec['segments']
    col, row = (segs[0]['col'], segs[0]['row'])
    line = [layout.LARGE_SPACE] * (max((s['col'] + len(s['glyphs']) for s in segs)) - col)
    for s in segs:
        line[s['col'] - col:s['col'] - col + len(s['glyphs'])] = s['glyphs']
    lower = [g if g == layout.LARGE_SPACE else g + 16 for g in line]
    return {'delay': None, 'mode': 0, 'segments': [{'col': col, 'row': row, 'pal': segs[0]['pal'], 'glyphs': line}, {'col': col, 'row': row + 1, 'pal': segs[0]['pal'], 'glyphs': lower}]}

def staff_records(stock):
    """index -> segments for the instant records of the staff messages."""
    entries = json.loads((TEXT / 'english_staff.json').read_text(encoding='utf-8'))['entries']
    out = {}
    for index in STAFF:
        mine = [e for e in entries if int(e['japan_record'], 16) == 2560 + index]
        if mine[0]['layout']['kind'] == 'box':
            segs = layout.staff_box(mine[0]['lines'])
        else:
            segs = layout.staff_list([(e['lines'], e['layout']) for e in sorted(mine, key=lambda e: e['message'])])
        for s in tc.record(stock, 'gA', index)['segments']:
            if s['glyphs'] and all((PORTRAIT_GLYPHS[0] <= g < PORTRAIT_GLYPHS[1] for g in s['glyphs'])):
                segs.append({**s, 'glyphs': [g - PORTRAIT_GLYPHS[0] + PORTRAIT_BASE for g in s['glyphs']]})
        out[index] = segs
    return out

def build(stock):
    """(patch entries, receipt) for the stock program bytes."""
    stock = bytes(stock)
    if stock[LOOKUP:LOOKUP + 14].hex() != LOOKUP_STOCK:
        raise ValueError("the typewriter's record lookup is not stock")
    if any((stock[a:a + 14].hex() != STAFF_LOOKUP_STOCK for a in STAFF_LOOKUPS)):
        raise ValueError("the instant printer's record lookups are not stock")
    table = [tc.GROUP1 + tc.word(stock, tc.GROUP1 + 2 * i) for i in range(RECORDS)]
    staff_count = tc.word(stock, tc.GROUPA) // 2
    table_a = [tc.GROUPA + tc.word(stock, tc.GROUPA + 2 * i) for i in range(staff_count)]
    lines = approved()
    code_end = HOME + 24
    story_line = {256 + stock[STORY_LINES + n]: n for n in STORY_HOLDS}
    records, holds, rows, extra = ({}, {}, [], {})
    for pid, (jp_id, rec) in lines.items():
        if pid == YEAR[0]:
            continue
        jp = tc.record(stock, 'g1', jp_id - 256)
        jp_frames = jp['delay'] * sum((len(s['glyphs']) for s in jp['segments']))
        if rec['mode'] == 2:
            pal = next((s['pal'] for s in jp['segments'] if s['glyphs']))
            rec['segments'] = [{**s, 'pal': pal} for s in rec['segments']]
        if jp_id in story_line:
            fitted, longer = fit_story(rec, jp_frames, jp['delay'])
            over = 0
            if longer:
                extra[pid] = longer
        else:
            fitted, over = fit(rec, jp_frames, jp['delay'], rec['mode'])
        if over:
            if pid not in PROFILE_HOLDS:
                raise ValueError(f'{pid} cannot type within its Japanese {jp_frames} frames')
            holds[pid] = PROFILE_HOLD - over
        records[jp_id - 256] = encode(fitted)
        rows.append({'id': pid, 'record': f'{jp_id:#05x}', 'japanese_frames': jp_frames, 'delay': fitted['delay'], 'frames': fitted['delay'] * glyph_words(fitted), 'hold_change': -over or None, 'palettes': sorted({s['pal'] for s in fitted['segments'] if s['col'] or s['row']}), 'bytes': len(records[jp_id - 256])})
    spare = SONG_EXTRA_FRAMES - sum(extra.values())
    if spare < 0:
        raise ValueError(f"the story captions type {-spare} frames past the opening song's extra round")
    added = share(spare, extra) if extra else {}
    by_id = {pid: jp_id for pid, (jp_id, _) in lines.items()}
    story_holds = {}
    for row in rows:
        if row['id'] in extra:
            line = story_line[by_id[row['id']]]
            address, stock_hold = STORY_HOLDS[line]
            row.update(line=line, extra_frames=extra[row['id']], hold=stock_hold + added[row['id']], hold_added=added[row['id']])
            story_holds[row['id']] = (address, stock_hold, stock_hold + added[row['id']])
    staff = {index: encode({'segments': segs}, header=False) for index, segs in staff_records(stock).items()}
    blob = bytearray()
    table_at = code_end
    table_a_at = table_at + 4 * RECORDS
    at = table_a_at + 4 * staff_count
    for index in sorted(records):
        table[index] = at + len(blob)
        blob += records[index]
    for index in sorted(staff):
        table_a[index] = at + len(blob)
        blob += staff[index]
    lookup = struct.pack('>HHhHHH', 53312, 17402, table_at - (HOME + 4), 8817, 0, 20085)
    lookup_a = struct.pack('>HHhHHH', 53312, 17402, table_a_at - (HOME + 16), 8817, 0, 20085)
    block = lookup + lookup_a + b''.join((struct.pack('>I', a) for a in table)) + b''.join((struct.pack('>I', a) for a in table_a)) + bytes(blob)
    if HOME + len(block) > HOME_END:
        raise ValueError("the restoration's records overrun their free space")
    if any((b != 255 for b in stock[HOME:HOME + len(block)])):
        raise ValueError("the restoration's record space is not free")
    patches = [(LOOKUP, LOOKUP_STOCK, '4eb9' + f'{HOME:08x}' + '4e71' * 4, "story text: the typewriter's record lookup calls the restoration's long-pointer table (english_records.py)"), (HOME, 'ff' * len(block), block.hex(), "story text: the lookup routines, their tables and the restoration's records (english_records.py)")] + [(a, STAFF_LOOKUP_STOCK, '4eb9' + f'{HOME + 12:08x}' + '4e71' * 4, "staff messages: the instant printer's record lookup calls the restoration's table (english_records.py)") for a in STAFF_LOOKUPS]
    for pid, value in holds.items():
        a = PROFILE_HOLDS[pid]
        patches.append((a, f'{PROFILE_HOLD:04x}', f'{value:04x}', f'{pid}: the hold after typing, {PROFILE_HOLD} -> {value} frames (english_records.py)'))
    for pid, (a, old_hold, value) in story_holds.items():
        if value != old_hold:
            patches.append((a, f'{old_hold:04x}', f'{value:04x}', f"{pid}: the hold after typing, {old_hold} -> {value} frames, its share of the opening song's extra round (english_records.py)"))
    rec = tc.record(stock, 'gA', YEAR[1])
    year = year_record(lines[YEAR[0]][1])
    year['segments'] = [{**s, 'pal': rec['segments'][0]['pal']} for s in year['segments']]
    end = rec['address']
    while True:
        end += 4
        while (g := tc.word(stock, end)) and (not g & 32768):
            end += 2
        end += 2
        if not g:
            break
    old = bytes(stock[rec['address']:end])
    new = encode(year, header=False)
    if len(new) > len(old):
        raise ValueError('the year card does not fit in place')
    new += bytes(stock[rec['address'] + len(new):rec['address'] + len(old)])
    patches.append((rec['address'], old.hex(), new.hex(), 'the year card: "Sometime in 1989..." (english_records.py)'))
    receipt = {'lookup': f'{LOOKUP:#x}', 'home': f'{HOME:#x}', 'block_bytes': len(block), 'table': f'{table_at:#x}', 'records': rows, 'staff': {'lookups': [f'{a:#x}' for a in STAFF_LOOKUPS], 'table': f'{table_a_at:#x}', 'records': {f'{2560 + i:#05x}': len(b) for i, b in staff.items()}, 'portraits': 'scroll 1 codes 0x8000-0x8037 (CPS2 only)', 'status': 'approved in round 3 (text/english_decisions.json)'}, 'profile_holds': {k: v for k, v in holds.items()}, 'story': {'arcade_opening_rounds': list(ARCADE_OPENING_ROUNDS), 'song_extra_frames': SONG_EXTRA_FRAMES, 'typing_past_japanese': dict(extra), 'holds_added': added, 'intro_longer_by_frames': sum(extra.values()) + sum(added.values())}}
    return (patches, receipt)

def hyphen_cells():
    """(column, row) of the top cell of each caption hyphen the restoration's"""
    return sorted({(s['col'] + i, s['row']) for _, rec in approved().values() for s in rec['segments'] for i, g in enumerate(s['glyphs']) if g == layout.LARGE['-']})
