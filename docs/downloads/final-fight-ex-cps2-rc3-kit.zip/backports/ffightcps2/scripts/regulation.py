"""REGULATION: Jessica in a red strapless top on the intro's TV, and white blood."""
from __future__ import annotations
import argparse
import hashlib
import struct
import sys
import build_m1_spike as spike
CELLS = ((14677, 14685, 14686, 14687, 13118), (14691, 14678, 14679, 14694, 14695), (14699, 14700, 14701, 14702, 14703), (14707, 14708, 14709, 14710, 14711), (14715, 14716, 14717, 14718, 14719))
MAP_BASE, MAP_COLUMN, MAP_ROW = (9486336, 10, 36)
SCROLL = (0, 256)
DRESS_FIRST_ROW = 2
PALETTE_ROM = 122492
PALETTE_WORDS = (1075, 3769, 3496, 3223, 2950, 2677, 2148, 1876, 1604, 3822, 3293, 2749, 2204, 1659, 2568, 0)
PICTURE_PALETTE, REG_PALETTE = (18, 31)
DRESS_PENS = range(9, 14)
DRESS_WORDS = (3635, 2851, 2083, 1587, 787)
STOCK_SHA256 = '6316ae8bd1e358d6370f53bbf5d911fc80c29778b0b98a96e560231e45605f93'
DRESSED_SHA256 = 'cd5dd2e419f096347b8aea161b2d845adfd991f72960b2b9d9fefec6712096e2'
REG_TABLE = 3146752
REG_CODES = 512
BLOOD_SCRIPTS = (349778, 137442)
BLOOD_BYTES = 62
BLOOD_ATTRIBUTES = ((30, 44), (44, 4396), (58, 4396))
BLOOD_PALETTE, WHITE_PALETTE = (12, 7)
BLOOD_PEN, GRAY_PEN = (9, 10)
GRAY_CODES = 20480
REG_BLOOD = 3146912
DRESS_ROWS = ('..................5.............................................................', '................................................................................', '..........................................................6....4................', '.............4.5566...................................0400088..00808............', '................54.....788............................5.5...5.556.66............', '.............3344............................................44444..............', '..............222.445...................................3..322244.....5678......', '..........2..11121.3...4...................................2..4431.....45.......', '.........32111111.1...........................................3222......45......', '.........2211.12...11........................................32211..............', '........22.11122....11.....................................211112...............', '.......322..122222222211.................................111112222..............', '.......22..2222222222222....................................223332..............', '.......22..222222..2...2................................12.3333322..............', '.......22.22222.........................................33333333222.............', '........2.22222...............................................33222222..........', '..........22224...............................................3332.2222.........', '...........2344...............................................333332222.........', '...........3.44...............................................333333342.........', '...........44445..............................................333333453.........', '...........44455.....................................44444..3.3433.4.73.........', '...........54.45....44................................444......443446745........', '.............45.......3333........................55.....444.555445586..........', '..........8.555..4..33333333......................3333333..44454.45.86..........', '........346.55454..3333223333...................33323222222323454.576...........', '..........586554.333.222222222................3332222.22.222223455676...........', '........734675456.cbbbaa522111223............3.221122.bbbbbbb.555577............', '..........46b5c.c..bbbbbbab2212222..............11.1abbbb.bbb.bbbb77............', '...........7b.cc..b.ccbbbbbabb12222.......5......4abbbbb.bccc.cbbbb7............', '...........7..c.bcccc.ccccbaaabb2222.3..........aabbb...ccc..c.c.bbc............', '.............c.ccccc.cbbbbccba9abb22.3...5.2..2bbbbaab.bbbbbc.c...cc............', '...........4..ccccc..bbbbbbbbbb9abb2.335.5.3.3bba.ab.bbbbb.b..cc..cc............', '...........5cccccc.bbb.b...bbbbb99bb.43555.42bb9.bbb.bb.b.b.....c..c............', '...........7cccccbbb.a.aaa..abbbb99cb4555543bb99bbbbbbaaaa...bb..c.c............', '...........cccccbb....a..aaaaaabbb99cbc5c5bbb.ab.aabbaa........bbc.c............', '...........dccc.b...99999999....abc99cccccbbaabb.a.aaa.999999...bc.c............', '............cccbb..99.......99.aabbc9acccbbabcba9aa..999....999..c.d............', '............d.cbb..........9.99.aa9bcabcccbbca9aaa..99.........9.c..............', '.............0cb.a.............9.aabbcbbbcc.ba..a.999..........abc..............', '................b..................a..ccc.c...aa.999.........aab................', '.......................aaaaa.........c.cccc..aa9999.......aaaaabc...............', '................b...aaaaaaaaaaa..a..cb..ccccc.a99..aaaaaaaaaaabcd...............', '................c..a.aaaaaaaaaa...bbb9bcbb.c.c..9aaaaaaaaaaaabcd................', '...............0dccb.a..aaaaaa..abca9accaabcb.ccbaaaaaaaaa.b....................', '...............0cdccbbbaa..a.bbaaaa99ccba9abc9ab..b......b..ccd.................', '................ccccccbbbbbbbbaaa999abba999aaba9bbb.....bccccd..................', '................8bbccbcbbbbaaaa9999aaba999999aba9aabbbbbbbbccd..................', '................dcbbccbbaaaaa99999aaba99999999aba9aabbbbbbcccd..................')

def tile_pens(tile):
    """A 16x16 tile's pens, rows of 16 (two 8-pixel groups of four planes)."""
    rows = []
    for y in range(16):
        row = []
        for half in range(2):
            planes = tile[y * 8 + half * 4:y * 8 + half * 4 + 4]
            row += [sum(((planes[k] >> 7 - x & 1) << k for k in range(4))) for x in range(8)]
        rows.append(row)
    return rows

def tile_bytes(rows):
    out = bytearray(128)
    for y, row in enumerate(rows):
        for half in range(2):
            for x in range(8):
                pen = row[half * 8 + x]
                for k in range(4):
                    if pen >> k & 1:
                        out[y * 8 + half * 4 + k] |= 128 >> x
    return bytes(out)

def picture_pens(region):
    pens = [[0] * 80 for _ in range(80)]
    for r, codes in enumerate(CELLS):
        for c, code in enumerate(codes):
            for y, row in enumerate(tile_pens(region[code * 128:(code + 1) * 128])):
                pens[r * 16 + y][c * 16:c * 16 + 16] = row
    return pens

def dressed(pens):
    top = DRESS_FIRST_ROW * 16
    if hashlib.sha256(bytes((p for row in pens[top:] for p in row))).hexdigest() != STOCK_SHA256:
        raise ValueError("ffightj's TV picture is not the one the REGULATION edit applies to")
    new = [row[:] for row in pens]
    for y, line in enumerate(DRESS_ROWS):
        for x, ch in enumerate(line):
            if ch != '.':
                new[top + y][x] = int(ch, 16)
    if hashlib.sha256(bytes((p for row in new[top:] for p in row))).hexdigest() != DRESSED_SHA256:
        raise ValueError('the REGULATION edit did not reproduce its pinned picture')
    return new

def build(region, rompaths=(), gray_blood=True):
    """(table bytes, white blood bytes for REG_BLOOD, graphics pieces for"""
    stock = bytes(spike.stock_program(spike.find_archive(list(rompaths) + spike.default_rompaths(), 'ffightj')))
    if struct.unpack_from('>16H', stock, PALETTE_ROM) != PALETTE_WORDS:
        raise ValueError(f"palette 18 at {PALETTE_ROM:#x} is not the picture's")
    pens = picture_pens(region)
    new = dressed(pens)
    cells, pieces, code = ([], [], REG_CODES)
    for r in range(DRESS_FIRST_ROW, len(CELLS)):
        for c, stock_code in enumerate(CELLS[r]):
            rows = [new[r * 16 + y][c * 16:c * 16 + 16] for y in range(16)]
            changed = rows != [pens[r * 16 + y][c * 16:c * 16 + 16] for y in range(16)]
            if not changed and (not any((p in DRESS_PENS for row in rows for p in row))):
                continue
            new_code = stock_code
            if changed:
                new_code, code = (code, code + 1)
                pieces.append((8388608 + new_code * 128, tile_bytes(rows)))
            column, row = (MAP_COLUMN + c, MAP_ROW + r)
            index = (row & 15) + ((column & 63) << 4) + ((row & 48) << 6)
            cells.append((MAP_BASE + 4 * index, stock_code, new_code))
    table = struct.pack('>3H', *SCROLL, len(cells))
    for address, stock_code, new_code in cells:
        table += struct.pack('>LHH', address, stock_code, new_code)
    offsets = [DRESS_WORDS[p - DRESS_PENS[0]] - PALETTE_WORDS[p] & 65535 if p in DRESS_PENS else 0 for p in range(16)]
    table += struct.pack('>HH16H', PICTURE_PALETTE, REG_PALETTE, *offsets)
    blood, blood_pieces, blood_receipt = blood_data(stock, region, gray_blood)
    pieces += blood_pieces
    receipt = {'home': f'{REG_TABLE:#x}', **spike.identity(table), 'scroll': [f'{v:04x}' for v in SCROLL], 'cells': len(cells), 'new_tiles': len(pieces), 'codes': [f'{REG_CODES:04x}', f'{code - 1:04x}'], 'pixels_changed': sum((a != b for ra, rb in zip(pens, new) for a, b in zip(ra, rb))), 'dress_words': [f'{w:03x}' for w in DRESS_WORDS], 'dressed_sha256': DRESSED_SHA256, 'white_blood': blood_receipt}
    return (table, blood, pieces, receipt)

def blood_data(stock, region, gray_blood=True):
    """(REG_BLOOD bytes, graphics pieces, receipt): white blood alone, from"""
    blood = white_blood(stock, GRAY_CODES if gray_blood else None)
    pieces = gray_tiles(stock, region) if gray_blood else []
    receipt = {'home': f'{REG_BLOOD:#x}', **spike.identity(blood), 'from': [f'{a:#x}' for a in BLOOD_SCRIPTS], 'palette': [BLOOD_PALETTE, WHITE_PALETTE], 'pen': GRAY_PEN if gray_blood else BLOOD_PEN}
    return (blood, pieces, receipt)

def blood_frames(stock):
    """Final Fight's blood animation block (both copies identical)."""
    blocks = {bytes(stock[a:a + BLOOD_BYTES]) for a in BLOOD_SCRIPTS}
    if len(blocks) != 1:
        raise ValueError("Final Fight's two blood animations differ")
    return bytearray(blocks.pop())

def gray_tiles(stock, region):
    """(CPS2 layout offset, tile) pieces: each blood frame's tiles with pen"""
    block, pieces = (blood_frames(stock), [])
    for k, (at, _) in enumerate(BLOOD_ATTRIBUTES):
        attr, code = struct.unpack_from('>HH', block, at)
        for r in range((attr >> 12 & 15) + 1):
            for c in range((attr >> 8 & 15) + 1):
                tile = bytearray(region[(code + c + 16 * r) * 128:(code + c + 16 * r + 1) * 128])
                for i in range(0, 128, 4):
                    planes = tile[i:i + 4]
                    for x in range(8):
                        bit = 128 >> x
                        pen = sum(((planes[q] & bit != 0) << q for q in range(4)))
                        if pen == BLOOD_PEN:
                            for q in range(4):
                                planes[q] = planes[q] | bit if GRAY_PEN >> q & 1 else planes[q] & ~bit
                    tile[i:i + 4] = planes
                pieces.append(((GRAY_CODES + 2 * k + c + 16 * r) * 128, bytes(tile)))
    return pieces

def white_blood(stock, gray_codes=None):
    """REG_BLOOD: an animation index table whose entry 3 (the hit effect's"""
    block = blood_frames(stock)
    for k, (at, word) in enumerate(BLOOD_ATTRIBUTES):
        if struct.unpack_from('>H', block, at)[0] != word or word & 31 != BLOOD_PALETTE:
            raise ValueError(f'blood frame attribute at +{at:#x} is not {word:04x}')
        struct.pack_into('>H', block, at, word & ~31 | WHITE_PALETTE)
        if gray_codes is not None:
            struct.pack_into('>H', block, at + 2, gray_codes + 2 * k)
    return struct.pack('>4H', 0, 0, 0, 8) + bytes(block)
