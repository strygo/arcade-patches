"""Convert Final Fight's CPS1 sound into a QSound driver 1.71 image."""
from __future__ import annotations
from fractions import Fraction
import hashlib
import math
from pathlib import Path
import struct
import build_m1_spike as spike
import ff_sound as fs
import qsound171 as q
PILOT_MUSIC = (64, 80)
CATALOG_COUNT = 96
ZONE_SEMITONES = 3
QSOUND_RATE = Fraction(60000000, 2496)
FM_COARSE = 60
OKI_RATE = Fraction(1000000, 132)
OKI_FAST = ((QSOUND_RATE, 60), (QSOUND_RATE / 2, 48))
OKI_NATIVE = 40
OKI_LOWEST = 24
OKI_OCTAVE, OKI_KEY = (3, 12)
OKI_NOTE = 36 + OKI_KEY
UPDATE_HZ = {'cps1': Fraction(3579545, 64 * 448 * 2), 'qsound': Fraction(125, 2)}
TEMPO_CELLS = range(224, 255)
TRIGGER_TEMPO_CELLS = range(128, 224)
DEFAULT_TEMPO = 409
SLOW_TEMPO = 128
TRIGGER_TICKS = 192
MASTER_VOLUME = 127
VOLUME_GAIN_DB = 2.96
PAN = q.PAN_DRY_CENTER
YM_ROUTE, OKI_ROUTE = (0.35, 0.3)
OKI_VOLUME = [32, 22, 16, 11, 8, 6, 4, 3, 2]
HEADROOM = 0.98
SAMPLE_SCALE = 2.032646
RENDER_SECONDS = 4.0
RELEASE_SECONDS = 1.0
RAMP_FIT_DB = 20.0
ENVELOPE_HOP = 0.01
SETTLE_DB_PER_S = 4.0
SETTLE_SPAN = 0.15
SETTLE_LATEST = 1.0
UNSETTLED_LOOP_AT = 0.15
DECAYING_DB = -30.0
ONESHOT_FLOOR_DB = -60.0
ONESHOT_MAX = q.HALF_BANK - 4
LOOP_SECONDS = (0.08, 0.3)
SEAM_CLEAN = 0.05
NOISY_LOOP_SECONDS = (0.3, 0.6)
LOOP_SEARCH_SECONDS = 0.2
LOOP_LENGTHS = 12
CROSSFADE = 256
DECAY_FLOOR_DB_PER_S = 0.5
HELD_SLOPE_RANGE = 40.0
TIMBRE_BANDS = ((0, 250), (250, 1000), (1000, 2000), (2000, 4000), (4000, 8000), (8000, 12000))
TIMBRE_DB = 3.0
TIMBRE_FLOOR_DB = -30.0
LATE_TOP_DB = -25.0
LATE_EDGE = 5500
LATE_STEP = 0.05
ENVELOPE_HZ = 62.5
HALF_LEVEL_DB = 20 * math.log10(2)
JINGLE = 92
CD_OPENING = fs.CD_OPENING
CD_ENDING = fs.CD_ENDING
FMLOOP = Path(__file__).resolve().parents[2] / 'ffightcd' / 'build'
SFA3_JINGLE = 47
SFA3_SAMPLES = (('sz3.11m', 478801617), ('sz3.12m', 4086477114))
JINGLE_SCORE = (497, '5c342c1f9a3f8304f0a25487d03c13e4b4a185b53a20fa8e0bf5ef0073fee271')
JINGLE_SAMPLES = {87: 'b446d9ec9b5ae047d9ff85831596f1b486d05e4cb5c180de2c612ca8b544c265', 100: '6415faff3a9d179670b23dcc20b38f0d627794c9353e5a1be475c4748a22547e', 103: 'e87294f8cbf9ebf9d3a9a4c1a153ffb3427e69d3609a773b475e5dfd982abcd4', 113: '0ab0bcc9cd24e04e4516f5d745d367b844975ce8d36b87e102e19ee54ee42b69'}
JINGLE_TEMPO_CELL = (90, 296)
WARM_ENTRIES_DB = (3.0, 12.0, 24.0, 40.0)
WARM_FLOOR_DB = 52.0
WARM_LEAD = 0.01

def pitch_word(flat, coarse, frac=0):
    shift = flat[8517 + coarse]
    relative = coarse - flat[8625 + shift]
    return struct.unpack_from('<H', flat, 8634 + 2 * coarse)[0] + (flat[8850 + relative * 256 + frac] << shift) & 65535

def root_for(note, coarse):
    """Descriptor root that plays note at the pitch table's coarse index."""
    return note - 1 + 60 - coarse

def global_transpose(song):
    values = {i.args[0] for c in song.channels if c for i in c.code.values() if i.op == 10}
    if len(values) > 1:
        raise ValueError(f'cue {song.cue:02x}: several global transposes {values}')
    t = values.pop() if values else 0
    return t if t < 128 else t - 256

def channel_fine(channel):
    """A channel's fine tune (op 0C, 1/256 semitone) when it holds one value"""
    values = {i.args[0] - 256 if i.args[0] > 127 else i.args[0] for i in channel.code.values() if i.op == 12}
    if len(values) > 1:
        raise ValueError(f'channel {channel.index}: a changing fine tune {sorted(values)}')
    return values.pop() if values else 0

def keyed_notes(z80, song):
    """Each FM channel's keyed notes over one cycle, as (channel, site, voice,"""
    transpose = global_transpose(song) & 255
    keyed, tied = ([], {})
    for channel in song.channels:
        if not channel or channel.index >= 8:
            continue
        events = fs.play(z80, channel, transpose)
        fine = channel_fine(channel)
        groups, i = ([], 0)
        while i < len(events):
            if events[i].tied or events[i].voice is None:
                raise ValueError(f'cue {song.cue:02x} channel {channel.index}: note at {events[i].address:04x} has no keyed start or voice')
            j = i + 1
            while j < len(events) and events[j].tied:
                tied.setdefault((channel.index, events[j].address), set()).add(events[i].address)
                j += 1
            groups.append((i, j))
            i = j
        base = len(keyed)

        def released(n, rest):
            i, j = groups[n]
            last = events[j - 1]
            if last.gate is None:
                return None
            hold = sum((e.ticks for e in events[i:j - 1])) + last.gate
            return (last.ticks - last.gate + rest, base + n, hold)
        for n, (i, j) in enumerate(groups):
            rekeys = []
            if n and events[i].after_note:
                rekeys.append(released(n - 1, events[i].rest))
            if events.wrap and events.wrap[0] == i:
                rekeys.append(released(len(groups) - 1, events.wrap[1]))
            keyed.append((channel.index, events[i].address, (events[i].voice, fine), events[i].note, max((e.note for e in events[i:j])), sum((e.ticks for e in events[i:j])), [r for r in rekeys if r is not None]))
    return (keyed, tied)

def zone_plan(z80, songs):
    """The program slot of every keyed FM note site, keyed (cue, channel,"""
    visits, links = ([], {})
    for song in songs:
        keyed, tied = keyed_notes(z80, song)
        slowest = min({DEFAULT_TEMPO} | {fs.word(i.args, 0) for c in song.channels if c for i in c.code.values() if i.op == 5})
        tick_seconds = 256 / (slowest * float(UPDATE_HZ['cps1']))
        visits += [(song.cue,) + v[:5] + (v[5] * tick_seconds,) for v in keyed]
        for (channel, site), starts in tied.items():
            links[song.cue, channel, site] = {(song.cue, channel, s) for s in starts}
    sites = {v[:3] for v in visits}
    parent = {k: k for k in sites}

    def root(k):
        while parent[k] != k:
            parent[k] = parent[parent[k]]
            k = parent[k]
        return k
    shared = sorted((k for k in links if k in sites))
    for site in shared:
        for start in links[site]:
            parent[root(start)] = root(site)
    top = {}
    for v in visits:
        r = root(v[:3])
        top[r] = max(top.get(r, 0), v[5])
    slot = {k: (top[root(k)] - 1) // ZONE_SEMITONES for k in sites}
    render, held = ({}, {})
    for cue, channel, site, voice, note, group_top, seconds in visits:
        key = (voice, slot[cue, channel, site])
        render[key] = max(render.get(key, 0), group_top)
        held[key] = max(held.get(key, 0.0), seconds)
    shifts = {}
    for cue, channel, site, voice, note, _, _ in visits:
        d = render[voice, slot[cue, channel, site]] - note
        shifts[d] = shifts.get(d, 0) + 1
    return (slot, render, held, {'keyed_notes': len(visits), 'sites': len(sites), 'shared_tie_sites': [f'{c:02x}/{ch}/{a:04x}' for c, ch, a in shared], 'shift_semitones': dict(sorted(shifts.items()))}, {k: root(k) for k in sites})

def fm_volume(image, v):
    attenuation_db = 0.75 * (127 - v)
    return image.volume_index(10 ** (-attenuation_db / 20))

def oki_volume(image, attenuation, gain_db=0.0):
    return image.volume_index(OKI_VOLUME[min(attenuation, 8)] / 32 * 10 ** (gain_db / 20))

def rel(at, size, target):
    offset = target - (at + size)
    if not -32768 <= offset < 32768:
        raise ValueError('branch out of range')
    return struct.pack('>h', offset)

def translate(song, image, tempo_cell, fm_banks, programs, oki_programs, oki_bank, effect=False):
    """One song's channels in 1.71 bytecode. Each channel gets its own copy"""
    transpose = global_transpose(song)
    first = min((c.index for c in song.channels if c))
    if effect:
        tempos = {fs.word(i.args, 0) for c in song.channels if c for i in c.code.values() if i.op == 5}
        if len(tempos) > 1:
            raise ValueError(f'cue {song.cue:02x}: an effect with several tempos {tempos}')
        effect_tempo = tempos.pop() if tempos else DEFAULT_TEMPO
    body, entries = (bytearray(), [None] * 16)
    for channel in song.channels:
        if not channel:
            continue
        is_oki = channel.index >= 8
        fine = 0 if is_oki else channel_fine(channel)

        def encode(instruction, at=0, target=0):
            op, args = (instruction.op, instruction.args)
            if op >= 32:
                if is_oki:
                    return bytes([op & 224 | OKI_KEY if op & 31 else op])
                program = programs.get((song.cue, channel.index, instruction.address))
                return (b'' if program is None else bytes([8, program])) + bytes([op])
            if op == 5:
                return bytes([5, tempo_cell[fs.word(args, 0)]])
            if op == 6 and (not is_oki):
                return bytes([6, args[0] or 1])
            if op == 7:
                return bytes([7, oki_volume(image, 8 - args[0]) if is_oki else fm_volume(image, args[0])])
            if op == 8:
                if is_oki:
                    return bytes([8, oki_programs.get(args[0] & 127, oki_programs['silent'])])
                return bytes([31, fm_banks[args[0], fine]])
            if is_oki and op in (3, 9, 11, 12, 13):
                return b''
            if op == 12:
                return b''
            if is_oki and op == 4:
                return bytes([4, args[0] & ~8])
            if op == 25:
                return b''
            if op == 24:
                raise ValueError(f'cue {song.cue:02x}: pan op not yet mapped')
            if 14 <= op <= 21:
                return bytes([op, args[0]]) + rel(at, 4, target)
            if op == 22:
                return bytes([op]) + rel(at, 3, target)
            return bytes([op]) + args
        if effect:
            prefix = bytearray([5, tempo_cell[effect_tempo]])
        else:
            prefix = bytearray([26, MASTER_VOLUME, 5, tempo_cell[DEFAULT_TEMPO]] if channel.index == first else [])
        prefix += bytes([24, PAN])
        if not is_oki:
            prefix += bytes([6, 1])
        if is_oki:
            prefix += bytes([31, oki_bank, 9, OKI_OCTAVE, 11, -transpose & 255, 4, 0])
        order = sorted(channel.code)
        sizes = {a: len(encode(channel.code[a])) for a in order}
        entries[channel.index] = len(body)
        body += prefix
        layout, cursor = ({}, len(body) + 3)
        for a in order:
            layout[a] = cursor
            cursor += sizes[a]
        body += b'\x16' + rel(len(body), 3, layout[channel.start])
        for a in order:
            instruction = channel.code[a]
            target = layout[instruction.targets[0]] if instruction.targets else 0
            encoded = encode(instruction, layout[a], target)
            if len(encoded) != sizes[a] or len(body) != layout[a]:
                raise ValueError('encoding size changed between passes')
            body += encoded
    return (body, entries)

def score(mode, body, entries):
    """Header + body; entries are channel entry offsets within body."""
    header = bytearray(33)
    header[0] = mode
    for i, entry in enumerate(entries):
        if entry is not None:
            struct.pack_into('>H', header, 1 + 2 * i, 33 + entry)
    return bytes(header) + bytes(body)

def opening_songs(z80, songs, opening):
    """songs with the opening song's variants: opening = {"arcade": (rounds,"""
    import sys
    sys.path.insert(0, str(FMLOOP))
    import fmloop
    from dataclasses import replace
    out = list(songs)
    if opening.get('arcade'):
        patched = fs.songs(fmloop.apply_opening_loop(z80, *opening['arcade'])[0])[82]
        out = [patched if s.cue == 82 else s for s in out]
    if opening.get('cd'):
        if any((s.cue == CD_OPENING for s in out)):
            raise ValueError(f'cue {CD_OPENING:02x} is taken')
        out.append(replace(fs.songs(fmloop.apply_opening_loop(z80, *opening['cd'])[0])[82], cue=CD_OPENING))
    if opening.get('ending'):
        if any((s.cue == CD_ENDING for s in out)):
            raise ValueError(f'cue {CD_ENDING:02x} is taken')
        out.append(replace(fs.songs(fs.ending_vamp(z80, opening['ending'])[0])[84], cue=CD_ENDING))
    return out

def build(rompaths, binary, music=PILOT_MUSIC, effect_gains=None, opening=None, products=None, capture=None):
    """(image, receipt). products (the public kit's kit mode, KIT.md) replaces the floating-point"""
    if products is None:
        raise ValueError('This recipient requires prepared products')
    if capture is not None:
        raise ValueError('Capture is not a recipient operation')
    z80, oki = fs.load(rompaths)
    sfa3 = spike.find_archive(rompaths, 'sfa3u')
    flat = spike.read_checked(sfa3, 'sz3.01', 3732996228) + spike.read_checked(sfa3, 'sz3.02', 1917083076)
    jingle_score, jingle = jingle_parts(flat, b''.join((q.swap_words(spike.read_checked(sfa3, *member)) for member in SFA3_SAMPLES)))
    image = q.Image(flat, CATALOG_COUNT, effect_master=MASTER_VOLUME)
    volume_top = image.scale_volumes(10 ** (VOLUME_GAIN_DB / 20))
    image.boot_register(225, image.boot_register(223))
    patched = image.effect_pan_from_score()
    table = fs.songs(z80)
    songs = [table[cue] for cue in music]
    if opening:
        songs = opening_songs(z80, songs, opening)
    scored = [song for song in table if song and 0 < song.mode < 128 and any(song.channels)]
    receipt = {'recipe': {k: str(v) if isinstance(v, Fraction) else v for k, v in {'music': [f'{c:02x}' for c in music], 'opening': opening, 'zone_semitones': ZONE_SEMITONES, 'fm_coarse': FM_COARSE, 'oki_targets': {'fast': [[str(r), c] for r, c in OKI_FAST], 'native': OKI_NATIVE, 'lowest': OKI_LOWEST}, 'oki_note': OKI_NOTE, 'render_seconds': RENDER_SECONDS, 'settle_db_per_s': SETTLE_DB_PER_S, 'timbre_db': TIMBRE_DB, 'timbre_floor_db': TIMBRE_FLOOR_DB, 'late_step': LATE_STEP, 'late_top_db': LATE_TOP_DB, 'late_edge': LATE_EDGE, 'ramp_fit_db': RAMP_FIT_DB, 'settle_span': SETTLE_SPAN, 'unsettled_loop_at': UNSETTLED_LOOP_AT, 'decaying_db': DECAYING_DB, 'oneshot_floor_db': ONESHOT_FLOOR_DB, 'loop_seconds': LOOP_SECONDS, 'seam_clean': SEAM_CLEAN, 'noisy_loop_seconds': NOISY_LOOP_SECONDS, 'loop_search_seconds': LOOP_SEARCH_SECONDS, 'loop_lengths': LOOP_LENGTHS, 'crossfade': CROSSFADE, 'decay_floor_db_per_s': DECAY_FLOOR_DB_PER_S, 'held_slope_range': HELD_SLOPE_RANGE, 'envelope_hz': ENVELOPE_HZ, 'warm_entries_db': WARM_ENTRIES_DB, 'warm_floor_db': WARM_FLOOR_DB, 'warm_lead': WARM_LEAD, 'ym_route': YM_ROUTE, 'oki_route': OKI_ROUTE, 'headroom': HEADROOM, 'sample_scale': SAMPLE_SCALE, 'master_volume': MASTER_VOLUME, 'effect_master': MASTER_VOLUME, 'volume_gain_db': VOLUME_GAIN_DB, 'volume_top': volume_top, 'pan': PAN, 'dry_delay': 'right = left', 'update_hz': {k: float(v) for k, v in UPDATE_HZ.items()}}.items()}}
    increments = {DEFAULT_TEMPO}
    for song in songs + scored:
        for c in song.channels:
            if c:
                increments |= {fs.word(i.args, 0) for i in c.code.values() if i.op == 5}
    if len(increments) >= len(TEMPO_CELLS):
        raise ValueError('more tempo increments than tempo cells')
    scale_t = UPDATE_HZ['cps1'] / UPDATE_HZ['qsound']
    tempo_cell = {}
    for cell, inc in zip(TEMPO_CELLS, sorted(increments)):
        image.tempo(cell, round(inc * scale_t))
        tempo_cell[inc] = cell
    slow_cell = TEMPO_CELLS[-1]
    image.tempo(slow_cell, SLOW_TEMPO)
    receipt['driver_changes'] = {'boot_register_e1': image.boot_register(225), 'effect_pan_gate_removed': f'{patched:04x}'}
    receipt['tempo'] = {f'{inc:04x}': {'cell': c, 'increment': image.tempo_increment(c)} for inc, c in tempo_cell.items()}
    slot, render_notes, held, plan, groups = zone_plan(z80, songs + scored)
    receipt['zones'] = plan
    if sorted(products['renders']) != sorted(render_notes):
        raise ValueError("the kit's renders are not the zones this score plays")
    renders = {key: (None, value['loop'], value['info']) for key, value in products['renders'].items()}
    warm, site_voices, receipt['warm'] = (products['warm'], products['site_voices'], products['warm_counts'])
    okis = {p: (None, value['coarse']) for p, value in products['okis'].items()}
    long_phrases, scale = (products['long_phrases'], products['scale'])
    fm_pcm = {key: value['pcm8'] for key, value in products['renders'].items()}
    oki_pcm8 = {p: value['pcm8'] for p, value in products['okis'].items()}
    oki_len = {p: value['samples'] for p, value in products['okis'].items()}
    receipt['sample_scale'] = scale
    placed = iter(image.pack([(bytes(16), None)] + [(fm_pcm[key], loop) for key, (_, loop, _) in sorted(renders.items())] + [(oki_pcm8[p], None) for p in sorted(okis)] + [(part['data'], part['loop']) for part in jingle]))
    row, art = (1, 1)
    bank_, start, loop_at, end = next(placed)
    image.descriptor(row, bank_, start, loop_at, end, root_for(OKI_NOTE, FM_COARSE))
    silent_row = row
    row += 1
    hold = art
    image.articulation(hold, [63, 0, 127, 0, 0, 0, 0, 0])
    art += 1
    rows, receipt['fm'], envelopes = ({}, [], {})
    warm_rows = [{} for _ in WARM_ENTRIES_DB]
    for (voice, zone), (y, loop, info) in sorted(renders.items()):
        bank_, start, loop_at, end = next(placed)
        root = root_for(info['note'], info['pitch_index'])
        image.descriptor(row, bank_, start, loop_at, end, root)
        if any((w is not None and w >= end - start for w in info['warm_starts'])):
            raise ValueError(f'voice {voice} zone {zone}: a warm entry past its trimmed end')
        envelope = tuple(info['articulation'])
        if envelope not in envelopes:
            image.articulation(art, info['articulation'])
            envelopes[envelope] = art
            art += 1
        rows[voice, zone] = (row, envelopes[envelope])
        receipt['fm'].append({**{k: v for k, v in info.items() if not k.startswith('_')}, 'zone': zone, 'row': row, 'articulation_index': envelopes[envelope], 'address': bank_ << 16 | start, 'bytes': end - start})
        row += 1
        receipt['fm'][-1]['warm_rows'] = []
        for k, warm_start in enumerate(info['warm_starts']):
            if warm_start is not None:
                image.descriptor(row, bank_, start + warm_start, loop_at, end, root)
                warm_rows[k][voice, zone] = (row, envelopes[envelope])
                receipt['fm'][-1]['warm_rows'].append(row)
                row += 1
    voices = sorted({voice for voice, _ in renders})
    fm_banks = {voice: bank for bank, voice in enumerate(voices)}
    last_zone = {voice: max((zone for v, zone in renders if v == voice)) for voice in voices}
    family = {voice: voice for voice in voices}

    def head(v):
        while family[v] != v:
            v = family[v]
        return v
    for vs in site_voices.values():
        first = sorted(vs)[0]
        for v in vs:
            family[head(v)] = head(first)
    width = {}
    for voice in voices:
        width[head(voice)] = max(width.get(head(voice), 0), last_zone[voice] + 1)
    family_of = {site: head(sorted(site_voices[site])[0]) for site in slot}
    used = {}
    for site, k in warm.items():
        used.setdefault(family_of[site], set()).add((slot[site], k))
    used = {h: sorted(combos) for h, combos in used.items()}
    for voice in voices:
        records = [(rows[voice, zone][0], 0, rows[voice, zone][1]) if (voice, zone) in rows else (silent_row, 0, hold) for zone in range(last_zone[voice] + 1)]
        combos = used.get(head(voice), [])
        records += [(silent_row, 0, hold)] * (width[head(voice)] - len(records) if combos else 0)
        for zone, k in combos:
            found = warm_rows[k].get((voice, zone)) or rows.get((voice, zone))
            records.append((found[0], 0, found[1]) if found else (silent_row, 0, hold))
        if len(records) > 256:
            raise ValueError(f'voice {voice}: {len(records)} programs')
        image.instrument_bank(fm_banks[voice], records)
    programs = {site: width[family_of[site]] + used[family_of[site]].index((zone, warm[site])) if site in warm else zone for site, zone in slot.items()}
    silent_bank = len(voices)
    zones = 1 + max((zone for _, zone in renders))
    image.instrument_bank(silent_bank, [(silent_row, 0, hold)] * zones)
    for song in songs + scored:
        for c in song.channels:
            if c and c.index < 8:
                for i in c.code.values():
                    if i.op == 8:
                        fm_banks.setdefault((i.args[0], channel_fine(c)), silent_bank)
    oki_bank = silent_bank + 1
    oki_programs, oki_records, receipt['oki'] = ({}, [], [])
    for program, p in enumerate(sorted(okis)):
        coarse = okis[p][1]
        bank_, start, loop_at, end = next(placed)
        image.descriptor(row, bank_, start, loop_at, end, root_for(OKI_NOTE, coarse))
        oki_records.append((row, 0, hold))
        oki_programs[p] = program
        receipt['oki'].append({'phrase': p, 'program': program, 'row': row, 'samples': oki_len[p], 'pitch_index': coarse, 'address': bank_ << 16 | start})
        row += 1
    oki_programs['silent'] = len(oki_records)
    oki_records.append((silent_row, 0, hold))
    receipt['banks'] = {'fm': {f'{v}{f:+d}' if f else str(v): b for (v, f), b in fm_banks.items()}, 'oki': oki_bank}
    receipt['oki_left_out'] = long_phrases
    receipt['sample_bytes'] = {'fm': sum((f['bytes'] for f in receipt['fm'])), 'oki': sum((o['samples'] + 2 for o in receipt['oki'])), 'used': image.sample_cursor, 'capacity': q.SAMPLE_BYTES}
    receipt['music'] = {}
    for song in songs:
        body, entries = translate(song, image, tempo_cell, fm_banks, programs, oki_programs, oki_bank)
        at = image.command(song.cue, score(0, body, entries))
        receipt['music'][f'{song.cue:02x}'] = {'address': at, 'bytes': 33 + len(body)}
    receipt['scored_effects'] = {}
    for song in scored:
        body, entries = translate(song, image, tempo_cell, fm_banks, programs, oki_programs, oki_bank, effect=True)
        at = image.command(song.cue, score(song.mode, body, entries))
        receipt['scored_effects'][f'{song.cue:02x}'] = {'mode': song.mode, 'address': at, 'bytes': 33 + len(body), 'channels': [c.index for c in song.channels if c]}
    receipt['effects'] = {}
    loop_programs, trigger_cells = ({}, {})
    free_cells = iter(TRIGGER_TEMPO_CELLS)
    for song in table:
        if song is None or not song.mode & 128:
            continue
        t = fs.oki_trigger(z80, song)
        if t['phrase'] not in oki_programs:
            continue
        o = next((o for o in receipt['oki'] if o['phrase'] == t['phrase']))
        program = oki_programs[t['phrase']]
        if t['loops']:
            if t['phrase'] not in loop_programs:
                bank_, start = (o['address'] >> 16, o['address'] & 65535)
                image.descriptor(row, bank_, start, start, start + o['samples'], root_for(OKI_NOTE, o['pitch_index']))
                loop_programs[t['phrase']] = len(oki_records)
                oki_records.append((row, 0, hold))
                row += 1
            program, cell = (loop_programs[t['phrase']], slow_cell)
        else:
            seconds = o['samples'] / (float(QSOUND_RATE) * pitch_word(image.flat, o['pitch_index']) / 4096)
            increment = min(65535, int(TRIGGER_TICKS * 256 / (float(UPDATE_HZ['qsound']) * seconds)))
            if increment not in trigger_cells:
                trigger_cells[increment] = next(free_cells)
                image.tempo(trigger_cells[increment], increment)
            cell = trigger_cells[increment]
        channel = 8 + {1: 0, 2: 1, 4: 2, 8: 3}[t['voice_bit']]
        note = 224 | OKI_KEY
        gain = (effect_gains or {}).get(song.cue, 0.0)
        body = bytes([5, cell, 24, PAN, 6, 255, 7, oki_volume(image, t['attenuation'], gain), 31, oki_bank, 8, program, 9, OKI_OCTAVE, 11, 0, 4, 0])
        if t['loops']:
            body += bytes([1, note, 22]) + rel(len(body) + 2, 3, len(body) + 1)
        else:
            body += bytes([note, 23])
        entries = [None] * 16
        entries[channel] = 0
        at = image.command(song.cue, score(max(1, t['priority']), body, entries))
        receipt['effects'][f'{song.cue:02x}'] = {**t, 'channel': channel, 'tempo_cell': cell, 'address': at, **({'gain_db': gain} if gain else {})}
    image.instrument_bank(oki_bank, oki_records)
    if image.tempo_increment(JINGLE_TEMPO_CELL[0]) != JINGLE_TEMPO_CELL[1]:
        raise ValueError("the jingle's tempo cell changed")
    jingle_bank, records, arts = (oki_bank + 1, [], {})
    for part in jingle:
        bank_, start, _, _ = next(placed)
        image.descriptor(row, bank_, start, start + part['loop'], start + part['end'], part['root'])
        if part['articulation'] not in arts:
            image.articulation(art, list(part['articulation']))
            arts[part['articulation']] = art
            art += 1
        records.append((row, part['fine'], arts[part['articulation']]))
        part.update(row=row, address=bank_ << 16 | start)
        row += 1
    image.instrument_bank(jingle_bank, records)
    at = image.command(JINGLE, relocate_jingle(jingle_score, jingle_bank, [p['program'] for p in jingle]))
    receipt['jingle'] = {'command': f'{JINGLE:02x}', 'sfa3_command': f'{SFA3_JINGLE:02x}', 'address': at, 'bank': jingle_bank, 'score_sha256': JINGLE_SCORE[1], 'samples': [{k: f'{v:#x}' if k == 'address' else v for k, v in p.items() if k in ('program', 'row', 'address')} | {'bytes': len(p['data'])} for p in jingle]}
    return (image, receipt)

def jingle_parts(sfa3_flat, sfa3_samples):
    """sfa3u's jingle: its score and, per program it selects (in the order"""
    src = int.from_bytes(sfa3_flat[q.CATALOG + 6 + 4 * SFA3_JINGLE:q.CATALOG + 9 + 4 * SFA3_JINGLE], 'big')
    length, digest = JINGLE_SCORE
    score_bytes = bytes(sfa3_flat[src:src + length])
    if hashlib.sha256(score_bytes).hexdigest() != digest:
        raise ValueError("sfa3u's jingle score does not match its pinned hash")
    bank0 = struct.unpack_from('<H', sfa3_flat, q.CONFIG + 5)[0]
    parts = []
    for program in sorted(JINGLE_SAMPLES):
        row, fine, art = struct.unpack_from('<HbB', sfa3_flat, bank0 + 4 * program)
        b, s, loop, end, root = struct.unpack_from('<BHHHB', sfa3_flat, q.DESCRIPTORS + 8 * row)
        data = bytes(sfa3_samples[b << 16 | s:(b << 16 | s) + end - s + 1])
        if hashlib.sha256(data).hexdigest() != JINGLE_SAMPLES[program]:
            raise ValueError(f"sfa3u's jingle sample for program {program:#x} does not match its pinned hash")
        parts.append({'program': program, 'data': data, 'loop': loop - s, 'end': end - s, 'root': root, 'fine': fine, 'articulation': bytes(sfa3_flat[q.ARTICULATIONS + 8 * art:q.ARTICULATIONS + 8 * art + 8])})
    return (score_bytes, parts)

def relocate_jingle(score_bytes, bank, programs):
    """The score with its bank (op 1F, all 0) and programs (op 08) pointed at"""
    out = bytearray(score_bytes)
    lengths = {**fs.ARGLEN, 5: 1, 26: 1, 31: 1}
    for entry in struct.unpack_from('>16H', out, 1):
        if not entry:
            continue
        at = entry
        while True:
            op = out[at]
            if op >= 32:
                at += 1
                continue
            if op == 23:
                break
            if 14 <= op <= 22:
                raise ValueError('the jingle score branches')
            if op == 31:
                if out[at + 1] != 0:
                    raise ValueError('the jingle score selects a bank other than 0')
                out[at + 1] = bank
            if op == 8:
                out[at + 1] = programs.index(out[at + 1])
            at += 1 + lengths[op]
    return bytes(out)
