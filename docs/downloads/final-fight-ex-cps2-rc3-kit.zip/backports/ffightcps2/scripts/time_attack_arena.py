"""The Sega CD's Time Attack arenas on CPS2 (TIME_ATTACK_PLAN.md "Arenas").

Each character's arena comes from your Final Fight CD disc:
  * tiles: GRT_n, a VRAM image of tiles 0x200 up at offset 0 (32 bytes a
    cell); tile 0x180 is the blank cell;
  * maps: two word-LZ streams in GRT_n from 0x5080 (16-bit flags, MSB first;
    1 = a literal entry, 0 = a token v copying (v & 31) + 3 entries from
    v >> 5 entries back), 32 entries a column, 64 columns each. The first
    holds plane B's rows 0-6 and plane A's rows 7-31, the second plane A's
    rows 0-6 and plane B's rows 7-31 (the PRT segment table 00 07 19);
  * palettes: CRAM line 0 is GRT_n's palette at 0x5000. Haggar's line 3 is
    MAINSYS's base palette (0x2baa US, 0x2b98 JP) with his pens 1-3 from the
    three words 6 bytes before it; his arena cells use pens 4-15.

On the CD both planes are 64 x 32 cells (512 x 256 px), shown with a
vertical scroll of 16, in horizontal bands that scroll at fixed fractions of
the camera (MEASURED, TIME_ATTACK_PLAN.md). CPS2 shows them as:
  * scroll 2 with row scroll: per band, the plane in front (A, or B where A
    is empty), at the band's speed;
  * scroll 3, one speed: plane B behind it, with the CD's backdrop color
    (line 0's color 0) where B is transparent.
The 320-pixel CD view is centered in 384 pixels, and the camera travels
+-64 px, so each band shows its CD center minus 32.

    time_attack_arena.py --self-test        # decode and compose check
"""

# BEGIN ARCADE PYTHON BOOTSTRAP
import sys as _arcade_sys
from pathlib import Path as _ArcadePath
_arcade_sys.path.insert(0, str(_ArcadePath(__file__).resolve().parents[3]))
from kit_python import bootstrap as _arcade_bootstrap
_arcade_bootstrap()
# END ARCADE PYTHON BOOTSTRAP
from pathlib import Path
import argparse
import struct
import sys

TRACK = Path(__file__).resolve().parents[1]
FFCD = TRACK.parent / 'ffightcd'
sys.path.insert(0, str(FFCD / 'tools'))
sys.path.insert(0, str(FFCD))
import time_attack_rules as rules  # noqa: E402
from ffcd import disc  # noqa: E402

TILE_BASE = 0x200           # GRT offset 0 is VRAM tile 0x200
BLANK = 0x180
STREAM = 0x5080
PALETTE = 0x5000
MAINSYS_LINE3 = {'us': 0x2BAA, 'jp': 0x2B98}   # the base palette; MAINSYS differs by disc
VSCROLL = 16                # both planes, every arena (MEASURED)
WIDTH, LINES = 512, 224
VIEW_SHIFT = 32             # (384 - 320) / 2
# jtCPS2 (jtcps1_dma.v) caches 49 scroll 2 tiles a row from 16 px left of the
# register's own column, and each line shows register + its row scroll entry:
# entries from -16 to 368 stay inside that cache (MAME has no such limit).
# time_attack.asm sets the register TA_ROW_LEAD left of the ground band, so
# each line's entry is its band's X less the ground's, plus that lead.
ROW_SCROLL_RANGE = (-16, 368)


def row_lead():
    import re
    m = re.search(r'^TA_ROW_LEAD\s+equ\s+(\d+)', (TRACK / 'asm/time_attack.asm').read_text(), re.M)
    return int(m.group(1))
# Per arena: scroll 2 bands (first line, last line, plane, speed, CD center
# offset = -hscroll mod 512 at the fight-start camera), scroll 3's speed and
# center, and the lines scroll 3 shows plane B on (MEASURED from the CD's
# line hscroll at fight start and after a move; see the plan).
ARENAS = {
    # Guy's 1/2 bands (pipe tops, bridge) have 432 px of art, 16 short of what
    # 1/2 speed needs at +-64: they travel 48 px (3/8 speed) from a center 8 px
    # right of the CD's, the plan's default.
    'guy': {'grt': 'GRT_1.BIN', 'line3': False,
            'bands': ((0, 39, 'B', (3, 8), 56), (40, 183, 'A', (3, 8), 56), (184, 223, 'A', (1, 1), 96)),
            'cd': {56: 48},
            'back': ((1, 4), 96, 40)},
    'cody': {'grt': 'GRT_2.BIN', 'line3': False,
             'bands': ((0, 39, 'B', (1, 2), 48), (40, 103, 'A', (1, 2), 48), (104, 223, 'A', (1, 1), 96)),
             'back': ((1, 4), 96, 40)},
    'haggar': {'grt': 'GRT_3.BIN', 'line3': True,
               'bands': ((0, 39, 'B', (1, 1), 96), (40, 223, 'A', (1, 1), 96)),
               'back': ((1, 2), 96, 40)},
}
ORDER = ('guy', 'cody', 'haggar')          # TA_CHAR order


# The CD's 3-bit levels as CPS nibbles, per channel: the arcade's levels at
# the same share of the pixels over the same Slum scenery on each (round 1,
# below the HUD), the chosen general tuning (3 November).
LEVELS = {'r': (0, 1, 5, 7, 9, 11, 13, 14), 'g': (0, 1, 4, 7, 9, 10, 13, 15), 'b': (0, 1, 5, 7, 9, 11, 12, 13)}
# Per arena, CD colors replaced outright. Haggar's sky (his line 0 pens 0 and
# 13, one color on the CD) is the arcade round 1 sky (MEASURED in MAME: the
# Slum's flat sky, 102 153 204), chosen over the fitted lavender.
COLORS = {'haggar': {0x0EA8: 0xF69C}}


def cps_color(md, arena=None):
    """A Mega Drive CRAM word (0000BBB0GGG0RRR0) as a CPS color, full brightness."""
    if md in COLORS.get(arena, {}):
        return COLORS[arena][md]
    r, g, b = ((md >> s) & 7 for s in (1, 5, 9))
    return 0xF000 | LEVELS['r'][r] << 8 | LEVELS['g'][g] << 4 | LEVELS['b'][b]


def unpack_words(buf, pos, count):
    res = []
    while len(res) < count:
        flags = struct.unpack_from('>H', buf, pos)[0]; pos += 2
        for b in range(16):
            if len(res) >= count:
                break
            v = struct.unpack_from('>H', buf, pos)[0]; pos += 2
            if flags & (0x8000 >> b):
                res.append(v)
                continue
            off, n = v >> 5, (v & 31) + 3
            if not 0 < off <= len(res):
                raise ValueError(f'arena stream: token {v:#06x} reaches before the start')
            for k in range(n):
                res.append(res[len(res) - off])
    return res, pos


def planes(grt):
    """(plane A, plane B) as 32 rows of 64 name-table entries."""
    first, pos = unpack_words(grt, STREAM, 2048)
    second, _ = unpack_words(grt, pos, 2048)
    a = [[0] * 64 for _ in range(32)]
    b = [[0] * 64 for _ in range(32)]
    for c in range(64):
        col1, col2 = first[c * 32:(c + 1) * 32], second[c * 32:(c + 1) * 32]
        for r in range(32):
            if r < 7:
                b[r][c], a[r][c] = col1[r], col2[r]
            else:
                a[r][c], b[r][c] = col1[r], col2[r]
    return a, b


def pixel(grt, plane, x, y):
    """The MD pen and palette line at plane pixel (x, y), wrapping 512 x 256."""
    x %= 512; y %= 256
    e = plane[y // 8][x // 8]
    t = e & 0x7FF
    if t == BLANK:
        return 0, 0
    if not TILE_BASE <= t < TILE_BASE + 0x280:
        raise ValueError(f'arena tile {t:#x} outside GRT')
    fx = 7 - x % 8 if e & 0x800 else x % 8
    fy = 7 - y % 8 if e & 0x1000 else y % 8
    byte = grt[(t - TILE_BASE) * 32 + fy * 4 + fx // 2]
    return (byte >> 4 if fx % 2 == 0 else byte & 15), e >> 13 & 3


LINE3_PENS = (0x0222, 0x0EEE, 0x0046, 0x048C, 0x08CE, 0x0E68, 0x0E0E, 0x0EE0, 0x0688, 0x002C, 0x0E84, 0x00EE)


def line3_base(mainsys):
    """(region, MAINSYS offset) of Haggar's base palette: the one known offset whose pens 4-15 are
    the base palette's (MAINSYS differs by disc)."""
    found = [(region, base) for region, base in MAINSYS_LINE3.items()
             if struct.unpack_from('>12H', mainsys, base + 8) == LINE3_PENS]
    if len(found) != 1:
        raise ValueError(f'MAINSYS line 3 palette (pens 4-15) found at {len(found)} known offsets, not one')
    return found[0]


def read(img=None):
    """{arena: (grt, plane A, plane B, {line: 16 MD colors})} from the disc (img: its data track;
    default the US disc, else the JP disc)."""
    img = img or (disc.US_IMG if Path(disc.US_IMG).exists() else disc.JP_IMG)
    get = rules.iso_files(img)
    mainsys = get('MAINSYS.BIN')
    region, base = line3_base(mainsys)          # Haggar's pens 1-3 are 6 bytes before it
    line3 = struct.unpack_from('>H', mainsys, base) + struct.unpack_from('>3H', mainsys, base - 6) + \
        struct.unpack_from('>12H', mainsys, base + 8)
    res = {}
    for name in ORDER:
        grt = get(ARENAS[name]['grt'])
        a, b = planes(grt)
        lines = {0: struct.unpack_from('>16H', grt, PALETTE)}
        if ARENAS[name]['line3']:
            lines[3] = line3
        for plane in (a, b):
            used = {e >> 13 & 3 for row in plane for e in row if e & 0x7FF != BLANK}
            if not used <= set(lines):
                raise ValueError(f'{name}: palette lines {sorted(used)} beyond {sorted(lines)}')
            if any(e & 0x8000 for row in plane for e in row):
                raise ValueError(f'{name}: a high-priority cell (over sprites) is not handled')
        res[name] = (grt, a, b, lines)
    return res


def images(name, data):
    """(front, back): 512 x 224 lists of CPS colors (None = transparent) in
    screen-line space, the front for scroll 2 and the back for scroll 3."""
    grt, a, b, lines = data
    spec = ARENAS[name]
    backdrop = cps_color(lines[0][0], name)
    front = [[None] * WIDTH for _ in range(LINES)]
    back = [[backdrop] * WIDTH for _ in range(LINES)]
    for y0, y1, which, _, _ in spec['bands']:
        plane = a if which == 'A' else b
        for y in range(y0, y1 + 1):
            for x in range(WIDTH):
                pen, line = pixel(grt, plane, x, y + VSCROLL)
                if pen:
                    front[y][x] = cps_color(lines[line][pen], name)
    first_back = spec['back'][2]
    for y in range(first_back, LINES):
        for x in range(WIDTH):
            pen, line = pixel(grt, b, x, y + VSCROLL)
            if pen:
                back[y][x] = cps_color(lines[line][pen], name)
    return front, back


def cd_screen(name, data, shift=0):
    """The CD's 320 x 224 screen at the fight-start camera, background only:
    each line takes plane A over plane B at their measured centers (moved
    `shift` px in the bands the design moves)."""
    grt, a, b, lines = data
    spec = ARENAS[name]
    backdrop = cps_color(lines[0][0], name)
    cd = spec.get('cd', {})
    centers = {}
    for y0, y1, which, _, off in spec['bands']:
        for y in range(y0, y1 + 1):
            centers[y] = (which, cd[off] + shift if off in cd else off)
    scr = [[backdrop] * 320 for _ in range(LINES)]
    speed, boff, first_back = spec['back']
    for y in range(LINES):
        which, off = centers[y]
        for x in range(320):
            col = None
            pen, line = pixel(grt, a if which == 'A' else b, x + off, y + VSCROLL)
            if pen:
                col = cps_color(lines[line][pen], name)
            elif y >= first_back:
                pen, line = pixel(grt, b, x + boff, y + VSCROLL)
                if pen:
                    col = cps_color(lines[line][pen], name)
            if col is not None:
                scr[y][x] = col
    return scr


def cps_screen(name, front, back, camera=0):
    """The CPS2 384 x 224 view: scroll 3 under scroll 2, each band at its
    speed, the camera `camera` px from center."""
    spec = ARENAS[name]
    (sn, sd), boff, _ = spec['back']
    scr = [[None] * 384 for _ in range(LINES)]
    for y0, y1, _, (n, d), off in spec['bands']:
        for y in range(y0, y1 + 1):
            fx = off - VIEW_SHIFT + camera * n // d
            bx = boff - VIEW_SHIFT + camera * sn // sd
            for x in range(384):
                c = front[y][(x + fx) % WIDTH]
                scr[y][x] = c if c is not None else back[y][(x + bx) % WIDTH]
    return scr


def tile_set(img, size, opaque):
    """Cut a 512 x 224 image into size x size tiles (the last row padded
    transparent) and dedupe them with flips. Returns (tiles, cells): tiles is a
    list of size x size color grids (None = transparent), cells[row][col] =
    (tile, flip x, flip y)."""
    rows = (LINES + size - 1) // size
    index, tiles, cells = {}, [], []
    for ty in range(rows):
        row = []
        for tx in range(WIDTH // size):
            g = tuple(tuple(img[ty * size + y][tx * size + x] if ty * size + y < LINES else None
                            for x in range(size)) for y in range(size))
            hit = None
            for fx in (0, 1):
                for fy in (0, 1):
                    v = tuple((r[::-1] if fx else r) for r in (g[::-1] if fy else g))
                    if v in index:
                        hit = (index[v], fx, fy); break
                if hit:
                    break
            if not hit:
                index[g] = len(tiles); tiles.append(g); hit = (len(tiles) - 1, 0, 0)
            row.append(hit)
        cells.append(row)
    return tiles, cells


def pack_palettes(tiles, limit=32):
    """Each tile's colors into CPS palettes of up to 15 colors (pen 15 is
    transparent): (palettes as color lists, the palette of each tile)."""
    sets = [frozenset(c for r in g for c in r if c is not None) for g in tiles]
    for s in sets:
        if len(s) > 15:
            raise ValueError(f'a tile uses {len(s)} colors, more than a CPS palette holds')
    pals, which = [], [None] * len(tiles)
    for i in sorted(range(len(tiles)), key=lambda i: -len(sets[i])):
        for k, p in enumerate(pals):
            if len(p | sets[i]) <= 15:
                pals[k] = p | sets[i]; which[i] = k; break
        else:
            pals.append(set(sets[i])); which[i] = len(pals) - 1
    if len(pals) > limit:
        raise ValueError(f'{len(pals)} palettes, more than the {limit} a layer has')
    return [sorted(p) for p in pals], which


def tile_bytes(grid, pens):
    """A tile in the linear graphics layout: rows of 8-pixel groups, four plane
    bytes each, the leftmost pixel in the top bit; pen 15 transparent."""
    size = len(grid)
    out = bytearray()
    for row in grid:
        for g in range(0, size, 8):
            px = [15 if c is None else pens[c] for c in row[g:g + 8]]
            for plane in range(4):
                out.append(sum(1 << (7 - i) for i, p in enumerate(px) if p >> plane & 1))
    return bytes(out)


def convert(name, data):
    """{'front'/'back': (tile bytes list, cells, palettes, tile palette)}."""
    front, back = images(name, data)
    res = {}
    for layer, img, size in (('front', front, 16), ('back', back, 32)):
        tiles, cells = tile_set(img, size, layer == 'back')
        pals, which = pack_palettes(tiles)
        pens = [{c: i for i, c in enumerate(p)} for p in pals]
        res[layer] = ([tile_bytes(g, pens[which[i]]) for i, g in enumerate(tiles)], cells, pals, which)
    return res


GFX_BASE = 0xEF2800         # after the RESULT figures (time_attack.FIGURE_GFX + 3 x 0x6000)
GFX_END = 0x1000000         # the clean blank run from 0xee0400 ends here


def speed_shift(n, d):
    """(multiplier, right shift) for a band speed n/d with d a power of two."""
    s = d.bit_length() - 1
    if 1 << s != d:
        raise ValueError(f'speed {n}/{d}: the denominator is not a power of two')
    return n, s


def build(img=None):
    """(assembler source, [(graphics address, bytes)], receipt) for the three arenas."""
    import hashlib
    data = read(img)
    at = GFX_BASE
    lines, gfx, receipt = ['ta_arenas:'], [], {}
    lines += [f'        dc.l ta_arena_{name}' for name in ORDER]
    for name in ORDER:
        conv = convert(name, data[name])
        spec = ARENAS[name]
        ftb, fcells, fpals, fwhich = conv['front']
        btb, bcells, bpals, bwhich = conv['back']
        front_at = at
        at += len(ftb) * 128
        at = (at + 511) // 512 * 512
        back_at = at
        at += len(btb) * 512
        if at > GFX_END:
            raise ValueError('the arenas do not fit the blank graphics run')
        gfx += [(front_at, b''.join(ftb)), (back_at, b''.join(btb))]
        fcode, bcode = (front_at - 0x800000) // 128, (back_at - 0x800000) // 512
        if fcode + len(ftb) > 0x10000 or bcode + len(btb) > 0x4000:
            raise ValueError('arena tile codes beyond the scroll ranges')
        n3, s3 = speed_shift(*spec['back'][0])
        lines += [f'ta_arena_{name}:',
                  f'        dc.w {len(fpals)},{len(fcells)},{len(fcells[0])},{len(bcells)},{len(bcells[0])}',
                  f'        dc.w {n3},{s3},{spec["back"][1] - VIEW_SHIFT}  ; scroll 3: speed, center',
                  f'        dc.l ta_arena_{name}_front,ta_arena_{name}_back,ta_arena_{name}_fpal,ta_arena_{name}_bpal',
                  '        ; scroll 2 bands: first line, last line, speed multiplier, shift, center']
        for y0, y1, _, (n, d), off in spec['bands']:
            n2, s2 = speed_shift(n, d)
            lines.append(f'        dc.w {y0},{y1},{n2},{s2},{off - VIEW_SHIFT}')
        lines.append('        dc.w -1')
        for label, cells, code, which in (('front', fcells, fcode, fwhich), ('back', bcells, bcode, bwhich)):
            lines.append(f'ta_arena_{name}_{label}:')
            for row in cells:
                words = []
                for tile, fx, fy in row:
                    words += [code + tile, which[tile] | fx << 5 | fy << 6]
                for k in range(0, len(words), 16):
                    lines.append('        dc.w ' + ','.join(f'${w:04x}' for w in words[k:k + 16]))
        for label, pals in (('fpal', fpals), ('bpal', bpals)):
            lines.append(f'ta_arena_{name}_{label}:')
            for pal in pals:
                words = pal + [0xF000] * (16 - len(pal))
                lines.append('        dc.w ' + ','.join(f'${w:04x}' for w in words))
        receipt[name] = {'front': {'graphics': hex(front_at), 'tiles': len(ftb), 'palettes': len(fpals),
                                   'sha256': hashlib.sha256(b''.join(ftb)).hexdigest()},
                         'back': {'graphics': hex(back_at), 'tiles': len(btb), 'palettes': len(bpals),
                                  'sha256': hashlib.sha256(b''.join(btb)).hexdigest()}}
    return '\n'.join(lines) + '\nta_arenas_end:\n        even\n', gfx, receipt   # the kit keys the arena data


def self_test():
    data = read()
    for name in ORDER:
        front, back = images(name, data[name])
        cd = cd_screen(name, data[name])
        cps = cps_screen(name, front, back)
        moved = ARENAS[name].get('cd', {})
        shifted = {y for y0, y1, _, _, off in ARENAS[name]['bands'] if off in moved for y in range(y0, y1 + 1)}
        bad = sum(cps[y][x + VIEW_SHIFT] != cd[y][x] for y in range(LINES) if y not in shifted for x in range(320))
        if bad:
            raise AssertionError(f'{name}: the CPS2 center view differs from the CD screen in {bad} pixels')
        if shifted:                             # the design's shift, and only it
            (off, cd_off), = moved.items()
            cd2 = cd_screen(name, data[name], off - cd_off)
            bad = sum(cps[y][x + VIEW_SHIFT] != cd2[y][x] for y in shifted for x in range(320))
            differs = sum(cd2[y][x] != cd[y][x] for y in shifted for x in range(320))
            if bad or not differs:
                raise AssertionError(f'{name}: the moved bands are not the CD bands moved {off - cd_off} px')
            print(f'  {name}: lines {min(shifted)}-{max(shifted)} are the CD bands moved {off - cd_off} px')
        lo, hi = ROW_SCROLL_RANGE
        for cam in range(-64, 65):              # every camera: each line's entry
            xs = [off - VIEW_SHIFT + cam * n // d
                  for _, _, _, (n, d), off in ARENAS[name]['bands']]
            entries = [x - xs[-1] + row_lead() for x in xs]
            if not lo <= min(entries) <= max(entries) <= hi:
                raise AssertionError(f'{name}: camera {cam:+d} row scroll entries {entries} beyond the jtCPS2 cache')
            if cam == 64 and name != 'haggar' and min(xs) - xs[-1] >= lo:   # without the lead
                raise AssertionError(f'{name}: the band offsets no longer need the lead')
        for cam in (-64, 64):                   # both limits stay inside the art
            spec = ARENAS[name]
            for y0, y1, _, (n, d), off in spec['bands']:
                lo, hi = off - VIEW_SHIFT + cam * n // d, off - VIEW_SHIFT + cam * n // d + 383
                if lo < 0 or hi > 511:
                    print(f'  {name}: band {y0}-{y1} at camera {cam:+d} shows plane x {lo}..{hi} (wraps)')
        print(f'{name}: center view equals the CD screen (320 x 224, plus 32 px each side)')
        conv = convert(name, data[name])
        for layer, (tb, cells, pals, which) in conv.items():
            print(f'  {layer}: {len(tb)} tiles ({sum(map(len, tb)):,} bytes), {len(pals)} palettes, '
                  f'{len(cells)} x {len(cells[0])} cells')
    print('self-test passed')


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument('--self-test', action='store_true')
    a = ap.parse_args(argv)
    if a.self_test:
        self_test()


if __name__ == '__main__':
    main()
