"""Compose a sound image for Capcom's QSound driver 1.71 (sfa3u)."""
from __future__ import annotations
import struct
FLAT_BYTES = 262144
MEMBER_BYTES = 131072
DRIVER_END = 15360
CONFIG = 15360
INSTRUMENTS = (16384, 24576)
DESCRIPTORS = 24576
DESCRIPTOR_ROWS = 1024
ARTICULATIONS = 32768
ARTICULATION_COUNT = 256
CATALOG = 35840
TEMPO_TABLE = 13458
VOLUME_TABLE = 11922
WINDOW = 16384
SAMPLE_BYTES = 8388608
HALF_BANK = 32768
FLAT_ARTICULATION = bytes([63, 0, 127, 0, 63, 0, 0, 0])
MASTER_SELECTOR = 127
BOOT_REGISTERS, BOOT_VALUES, BOOT_COUNT = (213, 225, 12)
PAN_DRY_CENTER = 64
EFFECT_PAN_GATE = (5824, bytes.fromhex('ca7012'))

def swap_words(data):
    out = bytearray(data)
    out[0::2], out[1::2] = (data[1::2], data[0::2])
    return bytes(out)

class Image:

    def __init__(self, sfa3_flat, catalog_count, effect_master=None):
        if len(sfa3_flat) != FLAT_BYTES:
            raise ValueError('expected the 256 KiB sz3.01+sz3.02 image')
        self.flat = bytearray(FLAT_BYTES)
        self.flat[:DRIVER_END] = sfa3_flat[:DRIVER_END]
        self.flat[CONFIG] = sfa3_flat[CONFIG] if effect_master is None else effect_master
        struct.pack_into('<HH', self.flat, CONFIG + 1, CATALOG, DESCRIPTORS)
        self.catalog_count = catalog_count
        struct.pack_into('>HBB', self.flat, CATALOG, catalog_count, MASTER_SELECTOR, MASTER_SELECTOR)
        self.score_cursor = CATALOG + 6 + 4 * catalog_count
        self.instrument_cursor = INSTRUMENTS[0]
        self.samples = bytearray(b'\x00' * SAMPLE_BYTES)
        self.sample_cursor = 0
        self.used_rows, self.used_articulations, self.commands = (set(), set(), {})
        self.articulation(0, FLAT_ARTICULATION)
        self.tempo_cells = {}

    def boot_register(self, register, value=None):
        """Read, or set, the value the driver writes to a DSP register at boot."""
        registers = self.flat[BOOT_REGISTERS:BOOT_REGISTERS + BOOT_COUNT]
        if register not in registers:
            raise ValueError(f'DSP register {register:02x} is not in the boot list')
        at = BOOT_VALUES + 2 * registers.index(register)
        if value is not None:
            struct.pack_into('<H', self.flat, at, value)
        return struct.unpack_from('<H', self.flat, at)[0]

    def effect_pan_from_score(self):
        """Let op 18 pan effect channels too (three bytes of driver code)."""
        at, code = EFFECT_PAN_GATE
        if bytes(self.flat[at:at + len(code)]) != code:
            raise ValueError('op 18 is not the driver 1.71 handler this patch expects')
        self.flat[at:at + len(code)] = bytes(len(code))
        return at

    def tempo(self, cell, increment):
        if not 0 <= cell < 256 or not 0 < increment < 65536:
            raise ValueError('tempo cell or increment out of range')
        struct.pack_into('<H', self.flat, TEMPO_TABLE + 2 * cell, increment)
        self.tempo_cells[cell] = increment

    def tempo_increment(self, cell):
        return struct.unpack_from('<H', self.flat, TEMPO_TABLE + 2 * cell)[0]

    def gain(self, index):
        """The driver's linear amplitude for volume selector index (0-127)."""
        top = struct.unpack_from('<H', self.flat, VOLUME_TABLE + 254)[0]
        return struct.unpack_from('<H', self.flat, VOLUME_TABLE + 2 * index)[0] / top

    def scale_volumes(self, factor):
        """Scale the channel volume table (index to DSP volume) by factor;"""
        values = struct.unpack_from('<128H', self.flat, VOLUME_TABLE)
        scaled = [round(v * factor) for v in values]
        if max(scaled) > 32767:
            raise ValueError("scaled volume table exceeds the DSP's signed range")
        struct.pack_into('<128H', self.flat, VOLUME_TABLE, *scaled)
        return scaled[127]

    def volume_index(self, gain):
        top = struct.unpack_from('<H', self.flat, VOLUME_TABLE + 254)[0]
        values = struct.unpack_from('<128H', self.flat, VOLUME_TABLE)
        return min(range(128), key=lambda i: (abs(values[i] - gain * top), i))

    def instrument_bank(self, bank, records):
        """records: (descriptor row, fine tune, articulation) per program."""
        size = 4 * len(records)
        if self.instrument_cursor + size > INSTRUMENTS[1] or not 0 <= bank < 256:
            raise ValueError('instrument area or bank exhausted')
        struct.pack_into('<H', self.flat, CONFIG + 5 + 2 * bank, self.instrument_cursor)
        for i, (row, fine, articulation) in enumerate(records):
            struct.pack_into('<HbB', self.flat, self.instrument_cursor + 4 * i, row, fine, articulation)
        self.instrument_cursor += size

    def articulation(self, index, values):
        if not 0 <= index < ARTICULATION_COUNT or len(values) != 8:
            raise ValueError('articulation index or size')
        a = values
        if not (a[0] < 64 and a[1] < 64 and (a[2] < 128) and (a[3] < 64) and (a[4] < 64)):
            raise ValueError(f'articulation selectors out of range: {list(a)}')
        self.flat[ARTICULATIONS + 8 * index:ARTICULATIONS + 8 * index + 8] = bytes(values)
        self.used_articulations.add(index)

    def sample(self, pcm8, loop=None):
        """Place signed 8-bit PCM; returns (bank, start, loop, end) for a"""
        data = bytes(pcm8) + (b'' if loop is not None else b'\x00\x00')
        if len(data) >= HALF_BANK:
            raise ValueError(f'sample of {len(data)} bytes exceeds a 32 KiB half-bank')
        cursor = (self.sample_cursor + 15) // 16 * 16
        if cursor // HALF_BANK != (cursor + len(data)) // HALF_BANK:
            cursor = (cursor // HALF_BANK + 1) * HALF_BANK
        if cursor + len(data) > SAMPLE_BYTES:
            raise ValueError('sample region exhausted')
        self.samples[cursor:cursor + len(data)] = data
        self.sample_cursor = cursor + len(data)
        start, end = (cursor & 65535, (cursor & 65535) + len(data))
        loop_at = start + (loop if loop is not None else len(data) - 2)
        return (cursor >> 16, start, loop_at, end)

    def pack(self, samples):
        """Place (pcm8, loop) samples at once, largest first, each in the"""
        items = [bytes(pcm8) + (b'' if loop is not None else b'\x00\x00') for pcm8, loop in samples]
        if any((len(data) >= HALF_BANK for data in items)):
            raise ValueError('a sample exceeds a 32 KiB half-bank')
        used = [HALF_BANK] * (self.sample_cursor // HALF_BANK) + [self.sample_cursor % HALF_BANK]
        used += [0] * (SAMPLE_BYTES // HALF_BANK - len(used))
        results = [None] * len(items)
        for i in sorted(range(len(items)), key=lambda i: (-len(items[i]), i)):
            data, loop = (items[i], samples[i][1])
            for half, filled in enumerate(used):
                at = (filled + 15) // 16 * 16
                if at + len(data) < HALF_BANK:
                    break
            else:
                raise ValueError(f'sample region exhausted: {len(items)} samples, {sum((len(d) for d in items))} bytes for {SAMPLE_BYTES - self.sample_cursor} free')
            cursor = half * HALF_BANK + at
            self.samples[cursor:cursor + len(data)] = data
            used[half] = at + len(data)
            start = cursor & 65535
            results[i] = (cursor >> 16, start, start + (loop if loop is not None else len(data) - 2), start + len(data))
        last = max((h for h, filled in enumerate(used) if filled))
        self.sample_cursor = max(self.sample_cursor, last * HALF_BANK + used[last])
        return results

    def descriptor(self, row, bank, start, loop, end, root):
        if not 0 <= row < DESCRIPTOR_ROWS or row in self.used_rows:
            raise ValueError(f'descriptor row {row} invalid or used')
        struct.pack_into('<BHHHB', self.flat, DESCRIPTORS + 8 * row, bank, start, loop, end, root)
        self.used_rows.add(row)

    def command(self, number, score):
        """Place a score (33-byte header and its channels) inside one window"""
        if not 0 <= number < self.catalog_count or number in self.commands:
            raise ValueError(f'command {number:#x} invalid or used')
        if len(score) > WINDOW:
            raise ValueError('score larger than a window')
        at = self.score_cursor
        if at >= 32768 and (at - 32768) // WINDOW != (at + len(score) - 1 - 32768) // WINDOW:
            at = 32768 + ((at - 32768) // WINDOW + 1) * WINDOW
        if at + len(score) > FLAT_BYTES:
            raise ValueError('score area exhausted')
        self.flat[at:at + len(score)] = score
        self.flat[CATALOG + 6 + 4 * number:CATALOG + 9 + 4 * number] = at.to_bytes(3, 'big')
        self.commands[number] = (at, len(score))
        self.score_cursor = at + len(score)
        return at

    def members(self):
        """Program members as stored (sz3.01, sz3.02) and sample members as"""
        flat = bytes(self.flat)
        return {'sz3.01': flat[:MEMBER_BYTES], 'sz3.02': flat[MEMBER_BYTES:], 'sz3.11m': swap_words(bytes(self.samples[:4194304])), 'sz3.12m': swap_words(bytes(self.samples[4194304:]))}

def score_header(mode, channels):
    """33-byte header: mode, then 16 big-endian channel offsets relative to"""
    if len(channels) > 16:
        raise ValueError('at most 16 channels')
    header = bytearray(33)
    header[0] = mode
    body = bytearray()
    for i, code in enumerate(channels):
        if code is None:
            continue
        struct.pack_into('>H', header, 1 + 2 * i, 33 + len(body))
        body += code
    return bytes(header + body)
