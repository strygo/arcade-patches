"""The restoration EX's captions: the approved English in Japanese EX's Sega CD scenes."""
from __future__ import annotations
import hashlib
import json
import struct
import sys
import dub_words
import english_layout as layout
import english_records as er
import text_catalog as tc
HOME = 3014656
CAPTAB = 704
CLEAR = 512
MARGIN = 4
CD_RECORDS = {298: ('map-0', None), 299: ('map-1', None), 300: ('map-2', (0, 2)), 290: ('map-2', (2, 4)), 301: ('map-3', None), 282: ('phone-4', None), 283: ('phone-5', None), 284: ('phone-6', None), 285: ('phone-7', None), 286: ('phone-8', None), 287: ('phone-9', None), 288: ('tv-10', None), 289: ('tv-11', None), 293: ('tv-15', None), 294: ('guycody-16', None), 295: ('guycody-17', None), 296: ('guycody-18', None), 297: ('guycody-19', None)}
SPOKEN_CAPTIONS = {'phone-5': 'dub-spoken-op07'}
YEAR_RECORD = 9
DUB_MIX = er.TRACK / 'manifests' / 'dub_mix_receipt.json'
DUB_LINES = er.TRACK / 'manifests' / 'dub_lines.json'
FRAME_HZ = 59.637
SCHEDULE_LEAD = 148
PRE_CLEAR = 6
HOLD_S = 0.4
JOIN_S = 1.0
CAPTION_LEAD_S = 0.1
ENDING_KEY_LAG = 1
FAREWELL_INIT_FRAMES = 5620
ENDING_BASE = {'ending': -ENDING_KEY_LAG, 'farewell': FAREWELL_INIT_FRAMES - ENDING_KEY_LAG}
SLOTS = (896 - 704) // 4
SHOTS = er.TRACK.parents[1] / 'backports' / 'ffightcd' / 'data' / 'ending' / 'jp_opening_shots.tsv'

def shots():
    """[(f_start, f_end)] of the Japanese opening's shots, in order, in the caption schedule's frames (the"""
    rows = []
    for line in SHOTS.read_text(encoding='utf-8').splitlines():
        if line.strip() and (not line.startswith('#')):
            cells = line.split('\t')
            rows.append((int(cells[1]) - SCHEDULE_LEAD, int(cells[2]) - SCHEDULE_LEAD))
    return rows

def in_shot(t, ja_t, ja_end, end):
    """(start, end) of a moved caption kept inside the shot its Japanese caption types in."""
    rows = shots()
    k = max((i for i, (a, _) in enumerate(rows) if a <= ja_t), default=0)
    first = rows[k][0]
    cut = rows[k][1] + 1 if k + 1 < len(rows) else None
    start = max(t, first)
    if cut is not None and ja_end <= cut:
        end = min(end, cut)
    return (start, max(end, start + 1))
DUB_CAPTIONS = {298: 'op01', 299: 'op02', 300: 'op03', 290: 'op03', 301: 'op04', 2569: 'op05', 282: 'op06', 283: 'op07', 284: 'op08', 285: 'op09', 286: 'op10', 287: 'op11', 288: 'op12', 289: 'op13', 293: 'op14', 294: 'op15', 295: 'op16', 296: 'op17', 297: 'op18'}
NEW_CAPTIONS = {291: ('dub-op19', 'op19', 294, (294, 295, 296, 297))}
YEAR_PROPOSAL = {'id': 'year-cd', 'japanese_ex': '1992年のことである・・・', 'approved': 'year', 'proposed': ['Sometime in 1992...'], 'reason': "Japanese EX's card (CPS1 EX) gives the Japanese disc's year, 1992, which its narration speaks; the restoration's approved card gives the arcade's 1989"}
ENDING = er.TEXT / 'english_ex_ending.json'
DECISIONS = er.TEXT / 'english_ex_decisions.json'

def approved_new(pid, lines):
    """Whether these exact lines are approved for a new id."""
    row = json.loads(DECISIONS.read_text(encoding='utf-8'))['approvals'].get(pid)
    return bool(row) and row['sha256'] == wording_hash(lines) and (row['lines'] == list(lines))

def ending_lines():
    """{"ending": [...], "farewell": [...]} for CPS1 EX's rom.py --captions: each"""
    plan = json.loads(ENDING.read_text(encoding='utf-8'))
    approved = decisions()
    out, joined = ({}, {})
    for key in ('ending', 'farewell'):
        out[key] = []
        for entry in plan[key]:
            if entry['id'] not in approved:
                ok = approved_new(entry['id'], entry['lines'])
                out[key].append(list(entry['lines']) if ok else None)
                continue
            joined.setdefault(entry['id'], []).extend(entry['lines'])
            out[key].append(list(entry['lines']))
    for pid, lines in joined.items():
        row = approved[pid]
        if not row['decision'].startswith(('approved', "author's wording")):
            raise ValueError(f"{pid} is not approved: {row['decision']}")
        want = row.get('lines') or row['text']
        if ' '.join(lines) != ' '.join(want):
            raise ValueError(f"the CD ending's lines for {pid} are not its approved wording")
    return out
ENDING_PALETTES = {'ending': [6, 14, 14, 14, 14, 6, 14, 6, 14], 'farewell': [6, 14, 14, 14, 6]}

def ending_palettes():
    return ENDING_PALETTES

def decisions():
    return {r['id']: r for r in json.loads((er.TEXT / 'english_decisions.json').read_text(encoding='utf-8'))['lines']}

def wording_hash(lines):
    return hashlib.sha256('\n'.join(lines).encode()).hexdigest()

def schedule(data):
    """[(frame, text id)] of the opening's caption schedule."""
    out, at = ([], CAPTAB)
    while True:
        t, tid = struct.unpack('>HH', data[at:at + 4])
        if t == 65535:
            return out
        out.append((t, tid))
        at += 4
DUB_ENDING = {'ending': ['en01', 'en02', 'en03', 'en04', 'en05', 'en06', 'en07', 'en08', 'en09'], 'farewell': ['en11', 'en12', 'en12', 'en12', 'en13']}

def ending_frames():
    """{key: [[start, end]]}: each ending caption's frames on its engine's clock (ENDING_BASE), from"""
    mix = {r['id']: r for r in json.loads(DUB_MIX.read_text(encoding='utf-8'))['scenes']['ending']['lines']}
    texts = ending_lines()
    out = {}
    for key, ids in DUB_ENDING.items():
        base = ENDING_BASE[key]
        starts = word_starts([(k, lid, ' '.join(texts[key][k] or [])) for k, lid in enumerate(ids)], 'ending')
        rows = [[round((starts.get(k, mix[lid]['start']) - CAPTION_LEAD_S) * FRAME_HZ) - base, 0] for k, lid in enumerate(ids)]
        for k, lid in enumerate(ids):
            last = k + 1 == len(ids) or ids[k + 1] != lid
            rows[k][1] = round((mix[lid]['end'] + HOLD_S) * FRAME_HZ) - base if last else rows[k + 1][0] - 1
        out[key] = rows
    return out
ALIGN_EARLY_S, ALIGN_LATE_S = (0.4, 0.1)

def opening_alignment(data):
    """[(record, line, start s, word s, clamped)] for the opening's captions as retime() schedules them:"""
    rows = schedule(data)
    order = [(rid, DUB_CAPTIONS[rid], record_text(rid)) for _, rid in rows if rid in DUB_CAPTIONS]
    order += [(rid, lid, record_text(rid)) for rid, (_, lid, _, _) in NEW_CAPTIONS.items()]
    words = word_starts(order)
    out = []
    for start, rid, _, lid in _dub_events(data):
        if rid in words:
            want = t_frame(words[rid] - CAPTION_LEAD_S)
            out.append((rid, lid, (start + SCHEDULE_LEAD) / FRAME_HZ, words[rid], start != want))
    return out

def ending_alignment(band_frames):
    """[(key, entry, line, shown s, word s)]: band_frames {(key, entry): the frame its caption showed, on"""
    texts = ending_lines()
    out = []
    for key, ids in DUB_ENDING.items():
        words = word_starts([(k, lid, ' '.join(texts[key][k] or [])) for k, lid in enumerate(ids)], 'ending')
        for k, lid in enumerate(ids):
            if (key, k) in band_frames and k in words:
                out.append((key, k, lid, (band_frames[key, k] + ENDING_BASE[key]) / FRAME_HZ, words[k]))
    return out

def t_frame(t):
    """The opening's schedule frame for game-clock time t (s)."""
    return round(t * FRAME_HZ) - SCHEDULE_LEAD

def record_text(rid):
    """The words a caption record shows: its approved lines (or the approved spoken variant), joined."""
    approvals = json.loads(DECISIONS.read_text(encoding='utf-8'))['approvals']
    if rid in CD_RECORDS:
        pid, part = CD_RECORDS[rid]
        spoken = SPOKEN_CAPTIONS.get(pid)
        if spoken and approvals.get(spoken) and approved_new(spoken, approvals[spoken]['lines']):
            return ' '.join(approvals[spoken]['caption_lines'])
        row = decisions()[pid]
        text = row.get('lines') or row['text']
        text = [text] if isinstance(text, str) else text
        return ' '.join(text[part[0]:part[1]] if part else text)
    if rid == 2560 + YEAR_RECORD:
        return ' '.join(YEAR_PROPOSAL['proposed'])
    if rid in NEW_CAPTIONS and approvals.get(NEW_CAPTIONS[rid][0]):
        return ' '.join(approvals[NEW_CAPTIONS[rid][0]]['lines'])
    return ''

def word_starts(records, scene='opening'):
    """{record: time (s) of the English word it begins with} for (record, line) pairs in their order: a"""
    words = dub_words.load(scene)
    out, at = ({}, {})
    for rid, lid, text in records:
        heard = words.get(lid, {}).get('words')
        if not heard:
            continue
        k = 0 if lid not in at else dub_words.find(heard, text, at[lid] + 1)
        at[lid] = k
        out[rid] = heard[k][1]
    return out

def _dub_events(data):
    """[(start frame, record, end frame, line)]: each caption from CAPTION_LEAD_S before the English word"""
    rows = schedule(data)
    mix = {r['id']: r for r in json.loads(DUB_MIX.read_text(encoding='utf-8'))['scenes']['opening']['lines']}
    order = [(rid, DUB_CAPTIONS[rid], record_text(rid)) for _, rid in rows if rid in DUB_CAPTIONS]
    order += [(rid, lid, record_text(rid)) for rid, (_, lid, _, _) in NEW_CAPTIONS.items()]
    starts = word_starts(order)
    out = []
    for k, (t, rid) in enumerate(rows):
        if rid == CLEAR:
            continue
        end = next((u for u, v in rows[k + 1:] if v == CLEAR))
        lid = DUB_CAPTIONS.get(rid)
        if lid in mix:
            shift = round(mix[lid]['pushed_s'] * FRAME_HZ)
            want = t_frame(starts[rid] - CAPTION_LEAD_S) if rid in starts else t + shift
            hold = t_frame(mix[lid]['end'] + HOLD_S)
            start_, end_ = in_shot(want, t, end, max(end + shift, hold))
            out.append([start_, rid, end_, lid])
        else:
            out.append([t, rid, end, lid])
    for rid, (approval, lid, _, _) in NEW_CAPTIONS.items():
        row = json.loads(DECISIONS.read_text(encoding='utf-8'))['approvals'].get(approval)
        if lid not in mix or not row or (not approved_new(approval, row['lines'])):
            continue
        t_new = t_frame((starts.get(rid) or mix[lid]['start']) - CAPTION_LEAD_S)
        start_, end_ = in_shot(t_new, t_new, t_new, t_frame(mix[lid]['end'] + HOLD_S))
        out.append([start_, rid, end_, lid])
    return sorted(out)

def retime(data):
    """(data with the dub's caption schedule at CAPTAB, receipt): each caption"""
    events = _dub_events(data)
    entries = []
    for k, (start, rid, end, lid) in enumerate(events):
        nxt = events[k + 1][0] if k + 1 < len(events) else None
        if entries and entries[-1][0] >= start - PRE_CLEAR:
            raise ValueError(f'caption {rid:#05x} at {start} runs into the one before it')
        if not (entries and entries[-1][1] == CLEAR and (entries[-1][0] == start - PRE_CLEAR)):
            entries.append((start - PRE_CLEAR, CLEAR))
        entries.append((start, rid))
        if nxt is None or end < nxt - PRE_CLEAR - round(JOIN_S * FRAME_HZ):
            entries.append((min(end, nxt - PRE_CLEAR - 1) if nxt is not None else end, CLEAR))
    if len(entries) + 1 > SLOTS:
        raise ValueError(f"the dub's caption schedule needs {len(entries) + 1} entries, room for {SLOTS}")
    out = bytearray(data)
    block = b''.join((struct.pack('>HH', t, rid) for t, rid in entries)) + b'\xff\xff\x00\x00'
    out[CAPTAB:CAPTAB + 4 * SLOTS] = block + bytes(out[CAPTAB + len(block):CAPTAB + 4 * SLOTS])
    receipt = {'rule': f"Japanese EX's caption start plus its line's push; held to the English voice's end plus {HOLD_S} s; new lines' captions at their voices' start plus the neighbours' median offset", 'frame_hz': FRAME_HZ, 'schedule_lead_frames': SCHEDULE_LEAD, 'mix_sha256': hashlib.sha256(DUB_MIX.read_bytes()).hexdigest(), 'entries': len(entries), 'captions': [{'record': f'{rid:#05x}', 'line': lid, 'start': s_, 'end': e, 'start_s': round((s_ + SCHEDULE_LEAD) / FRAME_HZ, 2)} for s_, rid, e, lid in events]}
    return (bytes(out), receipt)

def windows(data):
    """{text id: frames from its job to the band's next clear}."""
    rows = schedule(data)
    out = {}
    for k, (t, tid) in enumerate(rows):
        if tid != CLEAR:
            nxt = next((u for u, v in rows[k + 1:] if v == CLEAR), None)
            if nxt is None:
                raise ValueError(f'caption {tid:#05x} at {t} is never cleared')
            out[tid] = min(out.get(tid, 1 << 30), nxt - t)
    return out

def english_tables(story_patches, stock):
    """The restoration's group 1 and group A long-pointer tables, from its block patch."""
    block = next((bytes.fromhex(new) for address, _, new, _ in story_patches if address == er.HOME))
    staff_count = tc.word(stock, tc.GROUPA) // 2
    at = 24
    table = list(struct.unpack(f'>{er.RECORDS}I', block[at:at + 4 * er.RECORDS]))
    at += 4 * er.RECORDS
    table_a = list(struct.unpack(f'>{staff_count}I', block[at:at + 4 * staff_count]))
    return (table, table_a, er.HOME + 24, er.HOME + 24 + 4 * er.RECORDS)

def build(stock, scenes_program, scenes_data, story_patches):
    """(block, receipt, (cd table 1, cd table A)) for the restoration EX."""
    stock = bytes(stock)
    lines = decisions()
    table, table_a, _, _ = english_tables(story_patches, stock)
    wins = windows(scenes_data)
    records, rows = ({}, [])
    for jp_id, (pid, part) in sorted(CD_RECORDS.items()):
        row = lines[pid]
        if not row['decision'].startswith(('approved', "author's wording")):
            raise ValueError(f"{pid} is not approved: {row['decision']}")
        text = row.get('lines') or row['text']
        shown = text[part[0]:part[1]] if part else text
        decision = row['decision']
        spoken = SPOKEN_CAPTIONS.get(pid)
        if spoken:
            approval = json.loads(DECISIONS.read_text(encoding='utf-8'))['approvals'].get(spoken)
            if approval and approved_new(spoken, approval['lines']):
                if ' '.join(approval['caption_lines']) != ' '.join(approval['lines']):
                    raise ValueError(f'{spoken}: its caption lines are not its spoken words')
                shown, text = (list(approval['caption_lines']), list(approval['lines']))
                decision = f'the approved spoken variant ({spoken}), captioned as spoken'
        jp = tc.record(scenes_program, 'g1', jp_id - 256)
        pal = next((s['pal'] for s in jp['segments'] if s['glyphs']))
        rec = layout.caption(shown, 'story', pal, jp['delay'])
        glyphs = er.glyph_words(rec)
        window = wins.get(jp_id)
        if window is None:
            raise ValueError(f"{jp_id:#05x} is not in the opening's caption schedule")
        delay = next((d for d in range(jp['delay'], 0, -1) if d * glyphs <= window - MARGIN), None)
        if delay is None:
            raise ValueError(f'{pid} ({jp_id:#05x}) cannot type in its {window}-frame window')
        rec['delay'] = delay
        records[jp_id - 256] = er.encode(rec)
        rows.append({'record': f'{jp_id:#05x}', 'id': pid, 'lines': shown, 'wording_sha256': wording_hash(text), 'decision': decision, 'palette': pal, 'delay': delay, 'frames': delay * glyphs, 'window': window, 'rows': sorted({s['row'] for s in rec['segments']})})
    for jp_id, (approval, lid, like_pal, _) in NEW_CAPTIONS.items():
        row = json.loads(DECISIONS.read_text(encoding='utf-8'))['approvals'].get(approval)
        if jp_id not in wins or not row or (not approved_new(approval, row['lines'])):
            continue
        shown = list(row['lines'])
        like = tc.record(scenes_program, 'g1', like_pal - 256)
        pal = next((s_['pal'] for s_ in like['segments'] if s_['glyphs']))
        rec = layout.caption(shown, 'story', pal, like['delay'])
        glyphs = er.glyph_words(rec)
        delay = next((d for d in range(like['delay'], 0, -1) if d * glyphs <= wins[jp_id] - MARGIN), None)
        if delay is None:
            raise ValueError(f'{approval} ({jp_id:#05x}) cannot type in its {wins[jp_id]}-frame window')
        rec['delay'] = delay
        records[jp_id - 256] = er.encode(rec)
        rows.append({'record': f'{jp_id:#05x}', 'id': approval, 'lines': shown, 'wording_sha256': wording_hash(shown), 'decision': f'the approved new line ({approval}), captioned as spoken', 'palette': pal, 'delay': delay, 'frames': delay * glyphs, 'window': wins[jp_id], 'rows': sorted({s_['row'] for s_ in rec['segments']})})
    year = lines[YEAR_PROPOSAL['approved']]
    year_text = year.get('lines') or year['text']
    year_decision = year['decision']
    if approved_new(YEAR_PROPOSAL['id'], YEAR_PROPOSAL['proposed']):
        year_text, year_decision = (YEAR_PROPOSAL['proposed'], 'approved 17 October (english_ex_decisions.json)')
    jp_year = tc.record(scenes_program, 'gA', YEAR_RECORD)
    year_rec = er.year_record(layout.caption(year_text, 'story', jp_year['segments'][0]['pal'], 1))
    year_bytes = er.encode(year_rec, header=False)
    cd_table, cd_table_a = (list(table), list(table_a))
    blob = bytearray()
    at = HOME + 4 * (len(table) + len(table_a))
    for index in sorted(records):
        cd_table[index] = at + len(blob)
        blob += records[index]
    cd_table_a[YEAR_RECORD] = at + len(blob)
    blob += year_bytes
    block = b''.join((struct.pack('>I', a) for a in cd_table)) + b''.join((struct.pack('>I', a) for a in cd_table_a)) + bytes(blob)
    receipt = {'home': f'{HOME:#x}', 'bytes': len(block), 'sha256': hashlib.sha256(block).hexdigest(), 'table_1': f'{HOME:#x}', 'table_a': f'{HOME + 4 * len(table):#x}', 'records': rows, 'year_card': {'record': f'{2560 + YEAR_RECORD:#05x}', 'lines': year_text, 'wording_sha256': wording_hash(year_text), 'decision': year_decision}}
    return (block, receipt, (HOME, HOME + 4 * len(table)))
