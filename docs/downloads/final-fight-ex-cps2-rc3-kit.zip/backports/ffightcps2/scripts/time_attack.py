"""Compose TIME ATTACK over the Console source (TIME_ATTACK_PLAN.md, Phase 2).

Every EX build applies source() after console_mode.source() (console_compose.py).
Every rewrite names one complete source record. The CD's spawn script comes
from your Final Fight CD disc (PRT_1, identical for every character
and both regions), with its group and loop pointers relocated to this ROM.
"""
import hashlib
from pathlib import Path
import struct
import sys

TRACK = Path(__file__).resolve().parents[1]
ASM = TRACK / 'asm/time_attack.asm'
FFCD = TRACK.parent / 'ffightcd'
sys.path.insert(0, str(FFCD / 'tools'))
sys.path.insert(0, str(FFCD))
import time_attack_rules as rules  # noqa: E402
from ffcd import disc  # noqa: E402

# The seven enemy families' kill-point blocks: block, then the family's
# shared-kill flag offset (0: the family has no shared kill).
KILL_BLOCKS = (
    ('bred', 0x21F4C, 0x81), ('jtwop', 0x282B6, 0x81), ('axl', 0x2A49C, 0x81),
    ('andore', 0x2CE4E, 0xB0), ('oriber', 0x327D0, 0), ('holly', 0x3633C, 0),
    ('roxy', 0x3A194, 0))
KILL_PREFIX = bytes.fromhex('7000102e0014103b')
# Lane 0 depth for the Phase 2 stand-in arena (round 1, Slum 1-0): the Slum's
# own wave records place enemies at depths $21-$34.
TA_FLOOR = 0x20


def replace(text, before, after):
    if text.count(before) != 1:
        raise ValueError('Time Attack source binding differs: ' + before[:100])
    return text.replace(before, after)


def kill_tables(raw):
    """Each block's complete prefix and the absolute point table it reads."""
    tables = []
    for name, at, shared in KILL_BLOCKS:
        if raw[at:at + 8] != KILL_PREFIX:
            raise ValueError(f'kill block {name} at {at:x} differs')
        disp = struct.unpack_from('>h', raw, at + 8)[0]
        if shared and raw[at + 10:at + 14] != bytes.fromhex('4a2e00%02x' % shared):
            raise ValueError(f'kill block {name}: shared-kill test differs')
        if not shared and raw[at + 10:at + 14] != bytes.fromhex('4a2e0069'):
            raise ValueError(f'kill block {name}: attacker test differs')
        tables.append((name, at, at + 8 + disp, shared))
    return tables


def kill_helpers(tables):
    out = []
    for name, _, table, shared in tables:
        lines = [f'ta_kill_{name}:',
                 '        moveq #0,d0',
                 '        move.b $14(a6),d0',
                 '        move.l a0,-(sp)',
                 f'        lea (${table:x}).l,a0',
                 '        move.b 0(a0,d0.w),d0',
                 '        movea.l (sp)+,a0',
                 '        tst.b (TA_ACTIVE).l',
                 '        beq.s @done']
        if shared:
            lines += [f'        tst.b ${shared:x}(a6)', '        bne.s @both']
        lines += ['        tst.b $69(a6)',
                  '        bmi.s @none',
                  '        move.b #1,(TA_KILL).l',
                  '        bra.s @done',
                  '@both:  move.b #2,(TA_KILL).l',
                  '        bra.s @done',
                  '@none:  clr.b (TA_KILL).l',
                  '@done:  rts']
        out.append('\n'.join(lines))
    return '\n'.join(out)


def disc_script(img=None):
    """The CD script's groups as raw bytes from PRT_1 (img: the disc's data track; default the US
    disc, else JP)."""
    img = img or (disc.US_IMG if Path(disc.US_IMG).exists() else disc.JP_IMG)
    get = rules.iso_files(img)
    name = rules.namer(get('MAIN0.BIN'), rules.name_table(get('MAINSYS.BIN')))
    prt = get('PRT_1.BIN')
    decoded = rules.decode(prt, name)['script']
    for other in ('PRT_2.BIN', 'PRT_3.BIN'):
        if rules.decode(get(other), name)['script'] != decoded:
            raise ValueError('Time Attack scripts differ between characters')
    if decoded.get('loop_to') is None or decoded['cap_word'] != 2:
        raise ValueError('Time Attack script structure differs')
    at = lambda a: a - rules.PRT_BASE
    groups = []
    for g in (x for x in decoded['groups'] if 'records' in x):
        start = int(g['at'], 16)
        header = prt[at(start + 2):at(start + 10)]
        records = prt[at(start + 14):at(start + 14) + 16 * len(g['records'])]
        groups.append((struct.unpack_from('>H', prt, at(start))[0], header, records, g['end_action']))
    if int(decoded['loop_to'], 16) != int(decoded['groups'][0]['at'], 16):
        raise ValueError('Time Attack script does not loop to its first group')
    return {'image': img, 'groups': groups, 'decoded': decoded}


# RESULT art (TIME_ATTACK_PLAN.md "RESULT art from the CD"): each disc's
# GRT files share it after their arena portion, as a VRAM image at 0x4000
# (32 bytes a cell), three CRAM lines and three 13x23-cell maps of full
# name-table entries. In TA_CHAR order: (name, map, palette line, CRAM line).
RESULT_ART = (('guy', 0x10D80, 0xDD42, 2), ('cody', 0x10FD6, 0xDD22, 1), ('haggar', 0x1122C, 0xDD02, 0))
RESULT_VRAM = 0x4000
RESULT_CELLS = (13, 23)
FIGURE_GFX = 0xEE0800       # linear graphics address of the first figure: a 16-code row
FIGURE_STRIDE = 0x6000      # one figure: 12 rows of 16 object codes, 128 bytes a code
FIGURE_TILES = (7, 12)      # 16x16 object tiles: 112x192 pixels hold the 104x184 figure


def cps_color(md):
    """A Mega Drive CRAM word (0000BBB0GGG0RRR0) as a CPS color, full brightness."""
    r, g, b = ((md >> s) & 7 for s in (1, 5, 9))
    return 0xF000 | sum(round(v * 15 / 7) << s for v, s in ((r, 8), (g, 4), (b, 0)))


def result_art(img=None):
    """[(name, 16 CPS palette words, graphics bytes)] in TA_CHAR order, from
    the US disc, else the JP disc: the same offsets, and only the tile
    numbering inside the maps differs. CPS pen 15 is transparent, so MD pen p
    draws as pen p-1 with color p."""
    img = img or (disc.US_IMG if Path(disc.US_IMG).exists() else disc.JP_IMG)
    get = rules.iso_files(img)
    grt = get('GRT_1.BIN')
    shared = 0x5B84                             # the arena portion (0x20-0x5b83) ends here
    for other in ('GRT_2.BIN', 'GRT_3.BIN'):
        if get(other)[shared:] != grt[shared:]:
            raise ValueError('RESULT art differs between the GRT files')
    cw, ch = RESULT_CELLS
    tw, th = FIGURE_TILES
    out = []
    for name, at, pal, line in RESULT_ART:
        md = struct.unpack_from('>16H', grt, pal - 2)   # pen 0 first; the CD leaves it 0
        colors = [cps_color(c) for c in md[1:]] + [0xF000]
        pixels = [[15] * (tw * 16) for _ in range(th * 16)]
        for y in range(ch):
            for x in range(cw):
                e = struct.unpack_from('>H', grt, at + 2 * (y * cw + x))[0]
                if e >> 13 & 3 != line or e & 0x8000:
                    raise ValueError(f'{name}: cell ({x},{y}) is not on its palette line at low priority')
                tile = RESULT_VRAM + (e & 0x7FF) * 32
                for yy in range(8):
                    for xx in range(8):
                        sx = 7 - xx if e & 0x800 else xx
                        sy = 7 - yy if e & 0x1000 else yy
                        b = grt[tile + sy * 4 + sx // 2]
                        pen = b >> 4 if sx % 2 == 0 else b & 15
                        if pen:
                            pixels[y * 8 + yy][x * 8 + xx] = pen - 1
        gfx = bytearray(b'\xff' * FIGURE_STRIDE)
        for ty in range(th):
            for tx in range(tw):
                code = ty * 16 + tx
                for row in range(16):
                    for half in range(2):
                        px = pixels[ty * 16 + row][tx * 16 + half * 8:tx * 16 + half * 8 + 8]
                        for plane in range(4):
                            gfx[code * 128 + row * 8 + half * 4 + plane] = sum(
                                1 << (7 - i) for i, p in enumerate(px) if p >> plane & 1)
        out.append((name, colors, bytes(gfx)))
    return out


def graphics(art, img=None):
    """(linear graphics address, bytes) for each RESULT figure, then the arenas (img: the disc)."""
    import time_attack_arena
    return [(FIGURE_GFX + i * FIGURE_STRIDE, gfx) for i, (_, _, gfx) in enumerate(art)] + time_attack_arena.build(img)[1]


def result_source(art):
    lines = ['ta_figure_codes:']
    for i in range(len(art)):
        code = (FIGURE_GFX + i * FIGURE_STRIDE) // 128
        if code >> 16 != 1 or code & 0xF:
            raise ValueError('figure code is not a row in the scroll half')
        lines.append(f'        dc.w ${code & 0xFFFF:04x}                  ; + $10000: Y bit 13')
    lines.append('ta_figure_pals:')
    for name, colors, _ in art:
        lines.append(f'        dc.w ' + ','.join(f'${c:04x}' for c in colors) + f'  ; {name}')
    lines.append('ta_figure_pals_end:')         # the disc's palettes end here (the kit keys them)
    return '\n'.join(lines)


def script_source(script):
    lines = ['ta_script:', '        dc.w 2                          ; X-scroll triggers, as on the CD']
    for i, (trigger, header, records, action) in enumerate(script['groups'], 1):
        lines.append(f'ta_group_{i}:')
        lines.append(f'        dc.w ${trigger:04x}')
        lines.append('        dc.w ' + ','.join(f'${w:04x}' for w in struct.unpack('>4H', header)))
        lines.append(f'        dc.l ta_trailer_{i}')
        for r in range(0, len(records), 16):
            lines.append('        dc.b ' + ','.join(f'${b:02x}' for b in records[r:r + 16]))
        lines.append(f'ta_trailer_{i}:')
        lines.append(f'        dc.w ${0x8000 | action:04x}')
    lines += ['        dc.w $8004', '        dc.l ta_group_1', 'ta_script_end:']   # the kit keys the script
    return '\n'.join(lines)


# The JP disc's RESULT wording and colors, for the Japanese edition: HIGH for
# TOP (a column wider, so one column left), its message, RESULT in yellow and
# the headings in white.
JP_RESULT = (('TA_TITLE_PAL    equ TA_SILVER', 'TA_TITLE_PAL    equ TA_YELLOW'),
             ('TA_HEAD_PAL     equ GREEN ', 'TA_HEAD_PAL     equ TA_SILVER '),
             ('TA_TOP_COL      equ 4 ', 'TA_TOP_COL      equ 3 '),
             ('ta_s_top:      dc.b "TOP",0', 'ta_s_top:      dc.b "HIGH",0'),
             ('ta_s_new:      dc.b "YOU MADE A NEW RECORD!",0', 'ta_s_new:      dc.b "YOU MAKE A NEW RECORD!",0'))


def source(text, raw, floor=TA_FLOOR, edition='english', img=None):
    """(composed layer source, receipt); img: the edition's disc (default the US disc, else JP)."""
    tables = kill_tables(raw)
    script = disc_script(img)
    body = ASM.read_text().replace('TA_KILL_HELPERS', kill_helpers(tables))
    body = body.replace('TA_FLOOR ', f'${floor:x} ', 1)
    if edition == 'japan':
        for before, after in JP_RESULT:
            body = replace(body, before, after)
    art = result_art(img)
    import time_attack_arena
    arena_src, _, arena_receipt = time_attack_arena.build(img)
    body += '\n' + script_source(script) + '\n        even\n' + result_source(art) + '\n        even\n' + arena_src
    # Title: ARCADE / TIME ATTACK / OPTIONS; CONTINUE on RESULT restarts here.
    text = replace(text, '''@navigate:
        andi.b #$0c,d1
        beq.s @draw
        eori.b #1,(CM_TITLE).l
        bsr console_title_move_sound
@draw:  bsr console_title_footer
        lea cm_title_arcade(pc),a1
        tst.b (CM_TITLE).l
        beq.s @choice
        lea cm_title_options(pc),a1
@choice: bsr console_large_print
        movem.l (sp)+,d0-d7/a0-a4
        tst.w d0
        beq.s @done
        bsr console_title_confirm_sound
        tst.b (CM_TITLE).l
        bne.s @options_selected
        st (CM_ACCEPT).l''', '''@navigate:
        tst.b (TA_AUTOSTART).l
        beq.s @ta_keys
        clr.b (TA_AUTOSTART).l          ; RESULT CONTINUE: TIME ATTACK again
        move.b #1,(CM_TITLE).l
        moveq #1,d0
        move.l d0,(sp)                  ; the saved d0: a P1 Start
        bra.s @draw
@ta_keys:
        andi.b #$0c,d1
        beq.s @draw
        moveq #0,d2
        move.b (CM_TITLE).l,d2
        btst #3,d1                      ; Up
        beq.s @ta_down
        subq.b #1,d2
        bpl.s @ta_down
        moveq #2,d2
@ta_down:
        btst #2,d1                      ; Down
        beq.s @ta_store
        addq.b #1,d2
        cmpi.b #3,d2
        bcs.s @ta_store
        moveq #0,d2
@ta_store:
        move.b d2,(CM_TITLE).l
        bsr console_title_move_sound
@draw:  bsr console_title_footer
        lea cm_title_arcade(pc),a1
        tst.b (CM_TITLE).l
        beq.s @choice
        lea cm_title_time_attack(pc),a1
        cmpi.b #1,(CM_TITLE).l
        beq.s @choice
        lea cm_title_options(pc),a1
@choice: bsr console_large_print
        movem.l (sp)+,d0-d7/a0-a4
        tst.w d0
        beq.s @done
        bsr console_title_confirm_sound
        cmpi.b #2,(CM_TITLE).l
        beq.s @options_selected
        clr.b (TA_ACTIVE).l
        cmpi.b #1,(CM_TITLE).l
        bne.s @ta_arcade
        bsr ta_begin
@ta_arcade:
        st (CM_ACCEPT).l''')
    # CONTINUE re-enters the title's choice state directly.
    text = replace(text, '''        tst.b (CM_ACTIVE).l
        bne.s @menu
        tst.w d0
        beq @inactive_title''', '''        tst.b (CM_ACTIVE).l
        bne.s @menu
        tst.b (TA_AUTOSTART).l
        bne.s @ta_auto
        tst.w d0
        beq @inactive_title
@ta_auto:''')
    # The widest choice, TIME ATTACK, spans columns 21-42.
    text = replace(text, '''console_title_footer:
        lea (SCROLL1_MAP+21*128+24*4).l,a0
        moveq #18,d0''', '''console_title_footer:
        lea (SCROLL1_MAP+21*128+24*4).l,a0
        moveq #21,d0''')
    # No round intro in Time Attack: the intro flag $12a drives the Metro City
    # map and ROUND text (round intro task $5c908) and holds the clock.
    text = replace(text, '''@native: jsr ($a10).w
@done:  move.b #1,$12a(a5)             ; displaced round initialization
        rts''', '''@native: jsr ($a10).w
@done:  tst.b (TA_ACTIVE).l
        bne.s @ta_no_intro
        move.b #1,$12a(a5)             ; displaced round initialization
@ta_no_intro:
        rts''')
    # A pause QUIT, or RESULT's CONTINUE / EXIT, ends Time Attack as the
    # title task takes over (ta_quit); CONTINUE instead starts Time Attack
    # again from the title Start task's click-in (ta_continue), unseen.
    text = replace(text, '''        lea ($1096).w,a0
        jmp (TASK_REPLACE).w           ; reuse stopped title Start task''', '''        bsr ta_quit
        tst.b (TA_AUTOSTART).l
        bne ta_continue
        lea ($1096).w,a0
        jmp (TASK_REPLACE).w           ; reuse stopped title Start task''')
    # RESULT is the scheduler's third modal request.
    text = replace(text, '''        tst.b (CM_REQUEST).l
        bne.s @open
        tst.b d1
        beq @done''', '''        cmpi.b #3,(CM_REQUEST).l
        bne.s @cm_not_result
        bsr ta_result
        bra @done
@cm_not_result:
        tst.b (CM_REQUEST).l
        bne.s @open
        tst.b d1
        beq @done''')
    # Time Attack music aliases $7a-$7c, ahead of EX's $70-$78: natively the
    # characters' stage themes (chosen 2 November); EX_CLASSES marks them
    # arrange-only, so MUSIC ARRANGE posts the pack's Time Attack words.
    text = replace(text, '''        cmpi.b #$70,d0                  ; EX's cue aliases (EX_PHASE0.md item 8)''',
                   '''        cmpi.b #$7a,d0                  ; Time Attack's aliases (TIME_ATTACK_PLAN.md)
        bcs.s @ta_cue_native
        cmpi.b #$7c,d0
        bhi.s @ta_cue_native
        lea (ta_cues-$7a).l,a0
        move.b 0(a0,d0.w),d0
        bra.s @wrap
@ta_cue_native:
        cmpi.b #$70,d0                  ; EX's cue aliases (EX_PHASE0.md item 8)''')
    text = replace(text, '''ex_cues:
        dc.b 0,0,0,0,$28,$35,CD_SONG,$36,CD_ENDING
        even''', '''ex_cues:
        dc.b 0,0,0,0,$28,$35,CD_SONG,$36,CD_ENDING
        even
ta_cues:
        dc.b $40,$43,$45                ; Haggar R1 Slum, Cody R2 Subway Park 2, Guy R5 Bay Area 1
        even''')
    # A modal's own object list carries RESULT's figure.
    text = replace(text, '''        move.l #$00008000,(OBJ_BACK).l
        move.l #$0000ff00,(OBJ_BACK+4).l''', '''        bsr ta_modal_objects''')
    text = replace(text, 'code_end:', body + '\ncode_end:')
    return text, {'kill_blocks': [{'family': n, 'block': hex(a), 'table': hex(t), 'shared_flag': hex(s)}
                                  for n, a, t, s in tables],
                  'script_groups': len(script['groups']), 'disc_image': Path(script['image']).name,
                  'floor': floor, 'arenas': arena_receipt, 'result_text': 'jp disc' if edition == 'japan' else 'us disc',
                  'result_art': [{'name': n, 'graphics': hex(at), 'bytes': len(g), 'sha256': hashlib.sha256(g).hexdigest(),
                                  'palette': [f'{c:04x}' for c in cols]}
                                 for (n, cols, g), (at, _) in zip(art, graphics(art))]}


# Hooks over complete native instructions: (address, preimage, helper, opcode).
HOOKS = (
    (0x9F80, '196d00850080', 'ta_lives', '4eb9'),
    (0x9FA8, '196d00850080', 'ta_lives', '4eb9'),
    (0x51AE, '7000102d00be', 'ta_timer_init', '4ef9'),
    (0x51FA, '102d012a802d0129', 'ta_clock', '4ef9'),
    (0x4E02, '4ef90005d9f4', 'ta_all_out', '4ef9'),
    (0x603C, '267c000062e0', 'ta_level_script', '4ef9'),
    (0x601E, '267c00006330', 'ta_start_objects', '4ef9'),
    (0xA3F0, '203300006b10', 'ta_player_intro', '4ef9'),
    (0x1A2E, '226d050c2c11', 'ta_hiscore', '4ef9'),
    (0x2D8C, '70001016d000', 'ta_click_p1', '4ef9'),
    (0x2E1E, '70001016d000', 'ta_click_p2', '4ef9'),
    (0x1595E, '4a2d007e6632', 'ta_prompt_p1', '4ef9'),
    (0x159A0, '4a2d007e6638', 'ta_unprompt_p1', '4ef9'),
    (0x161D2, '4a2d007e6632', 'ta_prompt_p2', '4ef9'),
    (0x16214, '4a2d007e6632', 'ta_unprompt_p2', '4ef9'),
    (0x91A4, '3b40569847eb0006', 'ta_music', '4ef9'),
    (0x5ADC, '47fa04424a7900072600', 'ta_wave_table', '4eb9'),
    (0x5DE2, '2b7c00ff11a491a4', 'ta_tracked_top', '4eb9'),
    (0x5DEE, '2b7c00ff11d291d2', 'ta_pending_top', '4eb9'),
    (0x5E10, '0c6d000a91a8', 'ta_tracked_full', '4eb9'),
    (0x5E2E, '0c6d000a91d6', 'ta_pending_full', '4eb9'),
    (0x5E6A, '102b00094eb83e4e662a', 'ta_enemy_slot', '4ef9'),
    (0x5EAE, '342b00046a12', 'ta_spawn_x', '4ef9'),
    (0x5ECA, '342b00066a12', 'ta_spawn_y', '4ef9'),
    (0x2852, '41ed0204322d001e', 'ta_score', '4ef9'),
    (0x61D56, '102d056802000001', 'ta_scroll', '4ef9'),   # the level scroll routine: the CD arena
    (0x5AAC, '4a2d56ac6618', 'ta_wave_gate', '4ef9'),    # the wave engine waits for the opening
    (0x2B80, '102d005c1b4005ea', 'ta_input_p1', '4eb9'),  # the players' input: the walk-in
    (0x2B96, '102d005e1b4006aa', 'ta_input_p2', '4eb9'),
)


EX_CLASSES = 0x2EFF00          # ex_arrange.HOME: one posting class per command
TA_ALIASES = (0x7A, 0x7B, 0x7C)


def classes_patch(raw):
    """(address, before, after) for the aliases' EX_CLASSES bytes: native (0)
    in the public members, arrange (1) here, so MUSIC ARRANGE posts the pack's
    Time Attack words 0x017a-0x017c and MUSIC ORIGINAL the stage themes."""
    sys.path.insert(0, str(TRACK / 'scripts'))
    import ex_arrange
    if ex_arrange.HOME != EX_CLASSES:
        raise ValueError('EX_CLASSES home differs')
    for region in ('us', 'jp'):
        if ex_arrange.builder().time_attack_words(region) != [0x100 | a for a in TA_ALIASES]:
            raise ValueError(f'the pack map\'s {region} time_attack rows are not the aliases')
    rows = []
    for alias in TA_ALIASES:
        if raw[EX_CLASSES + alias] != 0:
            raise ValueError(f'EX_CLASSES[{alias:#x}] is not native in the public members')
        rows.append((EX_CLASSES + alias, b'\x00', b'\x01'))
    return rows


def hooks(raw, kills=True):
    """kills=False leaves the kill blocks native: the qualifier's rejecting control."""
    rows = list(HOOKS)
    for name, at, _, _ in kill_tables(raw) if kills else ():
        rows.append((at, raw[at:at + 10].hex(), f'ta_kill_{name}', '4eb9'))
    return rows
