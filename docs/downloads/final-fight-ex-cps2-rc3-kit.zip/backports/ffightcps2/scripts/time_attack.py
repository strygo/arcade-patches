"""Compose TIME ATTACK over the Console source (TIME_ATTACK_PLAN.md, Phase 2)."""
from pathlib import Path
import struct
import sys
TRACK = Path(__file__).resolve().parents[1]
ASM = TRACK / 'asm/time_attack.asm'
FFCD = TRACK.parent / 'ffightcd'
sys.path.insert(0, str(FFCD / 'tools'))
sys.path.insert(0, str(FFCD))
KILL_BLOCKS = (('bred', 139084, 129), ('jtwop', 164534, 129), ('axl', 173212, 129), ('andore', 183886, 176), ('oriber', 206800, 0), ('holly', 222012, 0), ('roxy', 237972, 0))
KILL_PREFIX = bytes.fromhex('7000102e0014103b')
TA_FLOOR = 32

def kill_tables(raw):
    """Each block's complete prefix and the absolute point table it reads."""
    tables = []
    for name, at, shared in KILL_BLOCKS:
        if raw[at:at + 8] != KILL_PREFIX:
            raise ValueError(f'kill block {name} at {at:x} differs')
        disp = struct.unpack_from('>h', raw, at + 8)[0]
        if shared and raw[at + 10:at + 14] != bytes.fromhex('4a2e00%02x' % shared):
            raise ValueError(f'kill block {name}: shared-kill test differs')
        if not shared and raw[at + 10:at + 14] != bytes.fromhex('4a2e0069'):
            raise ValueError(f'kill block {name}: attacker test differs')
        tables.append((name, at, at + 8 + disp, shared))
    return tables
RESULT_ART = (('guy', 68992, 56642, 2), ('cody', 69590, 56610, 1), ('haggar', 70188, 56578, 0))
RESULT_VRAM = 16384
RESULT_CELLS = (13, 23)
FIGURE_GFX = 15599616
FIGURE_STRIDE = 24576
FIGURE_TILES = (7, 12)
JP_RESULT = (('TA_TITLE_PAL    equ TA_SILVER', 'TA_TITLE_PAL    equ TA_YELLOW'), ('TA_HEAD_PAL     equ GREEN ', 'TA_HEAD_PAL     equ TA_SILVER '), ('TA_TOP_COL      equ 4 ', 'TA_TOP_COL      equ 3 '), ('ta_s_top:      dc.b "TOP",0', 'ta_s_top:      dc.b "HIGH",0'), ('ta_s_new:      dc.b "YOU MADE A NEW RECORD!",0', 'ta_s_new:      dc.b "YOU MAKE A NEW RECORD!",0'))
HOOKS = ((40832, '196d00850080', 'ta_lives', '4eb9'), (40872, '196d00850080', 'ta_lives', '4eb9'), (20910, '7000102d00be', 'ta_timer_init', '4ef9'), (20986, '102d012a802d0129', 'ta_clock', '4ef9'), (19970, '4ef90005d9f4', 'ta_all_out', '4ef9'), (24636, '267c000062e0', 'ta_level_script', '4ef9'), (24606, '267c00006330', 'ta_start_objects', '4ef9'), (41968, '203300006b10', 'ta_player_intro', '4ef9'), (6702, '226d050c2c11', 'ta_hiscore', '4ef9'), (11660, '70001016d000', 'ta_click_p1', '4ef9'), (11806, '70001016d000', 'ta_click_p2', '4ef9'), (88414, '4a2d007e6632', 'ta_prompt_p1', '4ef9'), (88480, '4a2d007e6638', 'ta_unprompt_p1', '4ef9'), (90578, '4a2d007e6632', 'ta_prompt_p2', '4ef9'), (90644, '4a2d007e6632', 'ta_unprompt_p2', '4ef9'), (37284, '3b40569847eb0006', 'ta_music', '4ef9'), (23260, '47fa04424a7900072600', 'ta_wave_table', '4eb9'), (24034, '2b7c00ff11a491a4', 'ta_tracked_top', '4eb9'), (24046, '2b7c00ff11d291d2', 'ta_pending_top', '4eb9'), (24080, '0c6d000a91a8', 'ta_tracked_full', '4eb9'), (24110, '0c6d000a91d6', 'ta_pending_full', '4eb9'), (24170, '102b00094eb83e4e662a', 'ta_enemy_slot', '4ef9'), (24238, '342b00046a12', 'ta_spawn_x', '4ef9'), (24266, '342b00066a12', 'ta_spawn_y', '4ef9'), (10322, '41ed0204322d001e', 'ta_score', '4ef9'), (400726, '102d056802000001', 'ta_scroll', '4ef9'), (23212, '4a2d56ac6618', 'ta_wave_gate', '4ef9'), (11136, '102d005c1b4005ea', 'ta_input_p1', '4eb9'), (11158, '102d005e1b4006aa', 'ta_input_p2', '4eb9'))
EX_CLASSES = 3079936
TA_ALIASES = (122, 123, 124)

def classes_patch(raw):
    """(address, before, after) for the aliases' EX_CLASSES bytes: native (0)"""
    sys.path.insert(0, str(TRACK / 'scripts'))
    import ex_arrange
    if ex_arrange.HOME != EX_CLASSES:
        raise ValueError('EX_CLASSES home differs')
    for region in ('us', 'jp'):
        if ex_arrange.builder().time_attack_words(region) != [256 | a for a in TA_ALIASES]:
            raise ValueError(f"the pack map's {region} time_attack rows are not the aliases")
    rows = []
    for alias in TA_ALIASES:
        if raw[EX_CLASSES + alias] != 0:
            raise ValueError(f'EX_CLASSES[{alias:#x}] is not native in the public members')
        rows.append((EX_CLASSES + alias, b'\x00', b'\x01'))
    return rows

def hooks(raw, kills=True):
    """kills=False leaves the kill blocks native: the qualifier's rejecting control."""
    rows = list(HOOKS)
    for name, at, _, _ in kill_tables(raw) if kills else ():
        rows.append((at, raw[at:at + 10].hex(), f'ta_kill_{name}', '4eb9'))
    return rows
