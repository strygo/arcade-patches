"""Read Final Fight's CPS1 sound data: Capcom sound driver 2.00."""
from __future__ import annotations
import argparse
from dataclasses import dataclass, field
import json
import sys
import audit_upstream as upstream
import build_m1_spike as spike
Z80_MEMBER = ('ff_09.12b', 3090579125)
OKI_MEMBERS = (('ff_18.11c', 928802535), ('ff_19.12c', 519124985))
SONG_TABLE = 4096
CHANNELS = 12
VOICE_BYTES = 32
OKI_RATE = 1000000 / 132
END = 23
ARGLEN = {0: 0, 1: 0, 2: 0, 3: 0, 4: 1, 5: 2, 6: 1, 7: 1, 8: 1, 9: 1, 10: 1, 11: 1, 12: 1, 13: 1, 14: 3, 15: 3, 16: 3, 17: 3, 18: 3, 19: 3, 20: 3, 21: 3, 22: 2, 23: 0, 24: 1, 25: 1}
CD_OPENING = 91
CD_OPENING_ROUNDS = {'usa': (12, 1), 'japan': (12, 0), 'english': (12, 0)}
CD_ENDING = 90
CD_ENDING_PASSES = {'usa': 0, 'japan': 5, 'english': 5}
DURATION_TABLES = {'plain': 2897, 'alternate': 2904, 'single': 2911}

@dataclass
class Instruction:
    address: int
    op: int
    args: bytes
    targets: tuple = ()
    falls_through: bool = True

    @property
    def size(self):
        return 1 + len(self.args)

@dataclass
class Channel:
    index: int
    start: int
    code: dict = field(default_factory=dict)

    def ops(self, op):
        return [i for i in self.code.values() if i.op == op]

@dataclass
class Song:
    cue: int
    header: int
    mode: int
    channels: list

    @property
    def music(self):
        return self.mode == 0

def load(rompaths):
    ffight = spike.find_archive(rompaths, 'ffight')
    z80 = spike.read_checked(ffight, *Z80_MEMBER)
    oki = b''.join((spike.read_checked(ffight, *member) for member in OKI_MEMBERS))
    return (z80, oki)

def word(data, address):
    return data[address] << 8 | data[address + 1]

def walk(z80, start):
    """Every instruction reachable from a channel's start, following the"""
    code, pending = ({}, [start])
    while pending:
        address = pending.pop()
        while address not in code:
            op = z80[address]
            length = ARGLEN.get(op, 0) if op < 32 else 0
            if op < 32 and op not in ARGLEN:
                raise ValueError(f'unknown op {op:02x} at {address:04x}')
            args = bytes(z80[address + 1:address + 1 + length])
            targets, falls = ((), True)
            if 14 <= op <= 21:
                targets = (word(args, 1),)
            elif op == 22:
                targets, falls = ((word(args, 0),), False)
            elif op == END:
                falls = False
            code[address] = Instruction(address, op, args, targets, falls)
            pending.extend(targets)
            if not falls:
                break
            address += 1 + length
    return code

@dataclass
class Note:
    address: int
    voice: int
    note: int
    tied: bool
    ticks: int = 0
    gate: int | None = None
    rest: int = 0
    after_note: bool = False

class Notes(list):
    """play()'s notes, and wrap: (index of the note the cycle returns to,"""
    wrap = None

def play(z80, channel, transpose=0, limit=200000):
    """Run one channel as the driver does (handlers 0626, 0A5B, 0AB4) and"""
    pc, flags, octave, shift, voice, ratio = (channel.start, 0, 0, 0, None, 0)
    counters, seen, notes, rest = ([0, 0, 0, 0], {}, Notes(), 0)
    for _ in range(limit):
        instruction = channel.code[pc]
        op, args = (instruction.op, instruction.args)
        state = (pc, flags, octave, shift, voice, ratio, tuple(counters))
        if state in seen:
            index, rest_then = seen[state]
            if index < len(notes):
                notes.wrap = (index, rest + notes[index].rest - rest_then)
            return notes
        seen[state] = (len(notes), rest)
        nxt = pc + instruction.size
        if op >= 32:
            table = DURATION_TABLES['plain'] if not flags & 48 else DURATION_TABLES['single'] if flags & 16 else DURATION_TABLES['alternate']
            ticks = z80[table + (op >> 5) - 1]
            if op & 31 == 0:
                flags |= 1
                rest += ticks
            else:
                note = (op & 31) + octave + (24 if flags & 8 else 0) + transpose + shift
                tied = bool(flags & 128)
                flags = flags & 126 | (flags & 64) << 1
                gate = None if flags & 128 else ratio * ticks >> 8
                notes.append(Note(pc, voice, min(note & 255, 97), tied, ticks, gate, rest, bool(notes)))
                rest = 0
            flags &= ~16
        elif op in (0, 1, 3):
            flags ^= {0: 32, 1: 64, 3: 8}[op]
        elif op == 2:
            flags |= 16
        elif op == 4:
            flags = flags & 151 | args[0]
        elif op == 6:
            ratio = args[0]
        elif op == 8:
            voice = args[0]
        elif op == 9:
            octave = 12 * args[0] & 255
        elif op == 10:
            transpose = args[0]
        elif op == 11:
            shift = args[0]
        elif 14 <= op <= 17:
            k = op - 14
            if counters[k] == 0:
                counters[k], nxt = (args[0], instruction.targets[0])
            else:
                counters[k] -= 1
                if counters[k]:
                    nxt = instruction.targets[0]
        elif 18 <= op <= 21:
            k = op - 18
            if counters[k] == 1:
                counters[k] = 0
                flags = flags & 151 | args[0]
                nxt = instruction.targets[0]
        elif op == 22:
            nxt = instruction.targets[0]
        elif op == END:
            return notes
        pc = nxt
    raise ValueError(f'channel {channel.index} did not settle in {limit} steps')

def cd_ending(edition):
    """The command the layer's EX alias $78 plays in this edition."""
    return CD_ENDING if CD_ENDING_PASSES[edition] else 84
ENDING_HEADER = 22907
ENDING_VAMP = {1: (23154, 2), 2: (23212, 2), 3: (23264, 2), 4: (23418, 2), 5: (23666, 2), 6: (23806, 3)}
ENDING_CH0 = (22932, bytes.fromhex('0501740902080606f0077d0400cdcff1cdcff1cdcfecedeff0f1edefcdcff10e01599fedeff1ced0edefcdcfeccdcfeccdcfec050111cdcfec17'))
ENDING_CH0_LOOP = 31
ENDING_CH0_PASS = (42, bytes.fromhex('cdcfec'))
ENDING_CH7 = (23819, bytes.fromhex('165aee'))
ENDING_COPY = 34816

def ending_vamp(z80, extra):
    """(z80 with extra more passes of cue 0x54's closing vamp, summary): each"""
    if not 1 <= extra <= 40:
        raise ValueError('extra passes must be 1-40')
    rom, stock = (bytearray(z80), bytes(z80))
    for ch, (site, count) in ENDING_VAMP.items():
        if stock[site] != 14 or stock[site + 1] != count:
            raise ValueError(f'cue 0x54 channel {ch}: no vamp repeat at {site:#06x}')
        rom[site + 1] = count + extra
    at, code = ENDING_CH0
    pass_at, one = ENDING_CH0_PASS
    if stock[at:at + len(code)] != code or word(stock, ENDING_HEADER + 1) != at or stock[ENDING_CH7[0]:ENDING_CH7[0] + 3] != ENDING_CH7[1] or (code[ENDING_CH0_LOOP:ENDING_CH0_LOOP + 4] != bytes([14, 1]) + (at + 11).to_bytes(2, 'big')) or (code[pass_at:pass_at + 9] != one * 3) or (code[pass_at + 9] != 5):
        raise ValueError("cue 0x54's channels are not the stock ones")
    copy = bytearray(code[:pass_at] + one * (3 + extra) + code[pass_at + 9:])
    copy[ENDING_CH0_LOOP + 2:ENDING_CH0_LOOP + 4] = (ENDING_COPY + 11).to_bytes(2, 'big')
    if any((b != 255 for b in stock[ENDING_COPY:ENDING_COPY + len(copy)])):
        raise ValueError("the copy's space is not free")
    rom[ENDING_COPY:ENDING_COPY + len(copy)] = copy
    rom[ENDING_HEADER + 1:ENDING_HEADER + 3] = ENDING_COPY.to_bytes(2, 'big')
    return (bytes(rom), f'ending vamp +{extra}: {len(ENDING_VAMP)} counts, channel 0 at {ENDING_COPY:04X}')

def songs(z80):
    count = z80[SONG_TABLE]
    result = []
    for cue in range(count):
        header = word(z80, SONG_TABLE + 3 + 2 * cue)
        if not header:
            result.append(None)
            continue
        mode = z80[header]
        if mode & 128:
            result.append(Song(cue, header, mode, [None] * CHANNELS))
            continue
        channels = []
        for index in range(CHANNELS):
            start = word(z80, header + 1 + 2 * index)
            channels.append(None if z80[start] == END else Channel(index, start, walk(z80, start)))
        result.append(Song(cue, header, mode, channels))
    return result

def oki_trigger(z80, song):
    """A mode-0x80 cue (handler 0x031B): one OKI phrase on one OKI voice."""
    b = z80[song.header:song.header + 5]
    return {'cue': song.cue, 'phrase': b[1], 'attenuation': b[2], 'voice_bit': b[3], 'priority': b[4], 'loops': bool(b[0] & 1)}

def voice_table(z80):
    return word(z80, SONG_TABLE + 1)

def voice(z80, number):
    base = voice_table(z80) + VOICE_BYTES * number
    raw = bytes(z80[base:base + VOICE_BYTES])
    return {'number': number, 'key_mask': raw[0], 'lfo': None if raw[1] == 0 else {'waveform': raw[2] & 127, 'rate': raw[3], 'pmd': raw[4], 'amd': raw[5], 'pms_ams': raw[6]}, 'feedback_connection': raw[7], 'dt1_mul': list(raw[8:12]), 'tl': list(raw[12:16]), 'ks_ar': list(raw[16:20]), 'ams_d1r': list(raw[20:24]), 'dt2_d2r': list(raw[24:28]), 'd1l_rr': list(raw[28:32]), 'raw': raw.hex()}

def durations(z80):
    return {name: list(z80[address:address + 7]) for name, address in DURATION_TABLES.items()}

def oki_phrases(oki):
    phrases = {}
    for number in range(1, 128):
        entry = oki[number * 8:number * 8 + 8]
        start, end = (int.from_bytes(entry[0:3], 'big'), int.from_bytes(entry[3:6], 'big'))
        if start and start < end < len(oki):
            phrases[number] = (start, end)
    return phrases
STEPS = [int(16 * (11 / 10) ** n) for n in range(49)]
ADJUST = (-1, -1, -1, -1, 2, 4, 6, 8)

def decode_oki(oki, start, end):
    """OKI MSM6295 ADPCM (high nibble first) to 12-bit samples."""
    signal, step, out = (0, 0, [])
    for byte in oki[start:end + 1]:
        for nibble in (byte >> 4, byte & 15):
            size = STEPS[step]
            delta = size >> 3
            if nibble & 1:
                delta += size >> 2
            if nibble & 2:
                delta += size >> 1
            if nibble & 4:
                delta += size
            signal = max(-2048, min(2047, signal - delta if nibble & 8 else signal + delta))
            step = max(0, min(48, step + ADJUST[nibble & 7]))
            out.append(signal)
    return out

def summary(z80, oki):
    table = songs(z80)
    used_voices, tempos, music, effects = (set(), set(), [], [])
    for song in table:
        if song is None or song.mode & 128:
            continue
        (music if song.music else effects).append(song.cue)
        for channel in song.channels:
            if channel is None:
                continue
            for instruction in channel.code.values():
                if instruction.op == 8 and channel.index < 8:
                    used_voices.add(instruction.args[0])
                if instruction.op == 5:
                    tempos.add(word(instruction.args, 0))
    phrases = oki_phrases(oki)
    return {'songs': len(table), 'music_cues': [f'{c:02x}' for c in music], 'effect_cues': [f'{c:02x}' for c in effects], 'oki_trigger_cues': [f'{s.cue:02x}' for s in table if s and s.mode & 128], 'voice_table': f'{voice_table(z80):04x}', 'fm_voices_used': sorted(used_voices), 'tempo_increments': sorted((f'{t:04x}' for t in tempos)), 'durations': durations(z80), 'oki_phrases': len(phrases), 'oki_seconds': round(sum((2 * (e - s + 1) for s, e in phrases.values())) / OKI_RATE, 1)}
