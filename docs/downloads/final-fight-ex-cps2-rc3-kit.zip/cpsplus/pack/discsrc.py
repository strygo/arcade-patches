"""Turn a user-supplied CD rip into a directory of trNN.wav files."""
from __future__ import annotations
import importlib.util
import json
import os
import shutil
import subprocess
import zipfile
from pathlib import Path
from .build_common import PKG_ROOT
from .sources import cd_chd_to_cue
_spec = importlib.util.spec_from_file_location('extract_cdda', Path(__file__).resolve().parent.parent / 'tools' / 'extract_cdda.py')
extract_cdda = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(extract_cdda)
DISC_CACHE = PKG_ROOT / 'work' / 'discs'
STAMP = '.cpsplus_source.json'
EXTRACT_VERSION = 2

def find_7z() -> str | None:
    """Find an installed 7-Zip, or obtain the verified .7z helper on use."""
    from .media_tools import disc_tool
    return disc_tool('sevenzip')

def _file_id(p: Path) -> dict:
    st = p.stat()
    return {'path': str(p.resolve()), 'size': st.st_size, 'mtime_ns': st.st_mtime_ns}

def source_stamp(source: Path, **settings) -> dict:
    """What a cache made from `source` depends on.  A .cue or .mds counts"""
    source = Path(source)
    files = [source]
    suffix = source.suffix.lower()
    if suffix == '.cue':
        try:
            files += [f for f in extract_cdda.cue_files(source) if f.exists()]
        except (OSError, ValueError):
            pass
    elif suffix == '.mds' and source.with_suffix('.mdf').exists():
        files.append(source.with_suffix('.mdf'))
    return {'extractor': EXTRACT_VERSION, **settings, 'files': [_file_id(f) for f in files]}

def read_stamp(cache: Path) -> dict | None:
    try:
        return json.loads((cache / STAMP).read_text(encoding='utf-8'))
    except (OSError, ValueError):
        return None

def stamp_matches(cache: Path, stamp: dict) -> bool:
    have = read_stamp(cache)
    return have is not None and {k: v for k, v in have.items() if k != 'aligned'} == stamp

def _replace_dir(tmp: Path, dest: Path) -> None:
    if dest.exists():
        shutil.rmtree(dest)
    tmp.rename(dest)

def _fresh_partial(dest: Path) -> Path:
    tmp = dest.with_name(dest.name + '.partial')
    if tmp.exists():
        shutil.rmtree(tmp)
    tmp.mkdir(parents=True)
    return tmp

def _unpack(archive: Path) -> Path:
    """Unpack `archive` into the disc cache (once) and return the cache dir."""
    dest = Path(os.environ.get('CAPCOM_DISC_CACHE', DISC_CACHE)) / archive.stem
    stamp = source_stamp(archive)
    if stamp_matches(dest, stamp):
        return dest
    if archive.suffix.lower() not in ('.zip', '.7z'):
        raise ValueError(f'{archive}: unsupported input — pass a .cue, .chd, .zip or .7z')
    exe = find_7z() if archive.suffix.lower() == '.7z' else None
    if archive.suffix.lower() == '.7z' and (not exe):
        raise FileNotFoundError(f'{archive.name}: need a 7-Zip binary to unpack it (brew install sevenzip, or 7-Zip from 7-zip.org on Windows), or pre-extract the rip and pass the .cue directly')
    print(f'[discsrc] unpacking {archive.name} ...', flush=True)
    tmp = _fresh_partial(dest)
    if archive.suffix.lower() == '.zip':
        with zipfile.ZipFile(archive) as z:
            z.extractall(tmp)
    else:
        r = subprocess.run([exe, 'x', '-y', f'-o{tmp}', str(archive)], capture_output=True)
        if r.returncode:
            shutil.rmtree(tmp, ignore_errors=True)
            raise ValueError(f"{archive.name}: 7-Zip failed: {(r.stderr or r.stdout).decode(errors='replace').strip()[:400]}")
    (tmp / STAMP).write_text(json.dumps(stamp, indent=1), encoding='utf-8')
    _replace_dir(tmp, dest)
    return dest

def _descriptor(source: Path) -> Path:
    if source.suffix.lower() in ('.cue', '.mds'):
        return source
    if source.suffix.lower() == '.chd':
        return cd_chd_to_cue(source, cache_dir=os.environ.get('CAPCOM_DISC_CACHE'))
    udir = _unpack(source)
    cues = sorted(udir.glob('**/*.cue')) or sorted(udir.glob('**/*.mds'))
    if not cues:
        raise FileNotFoundError(f"{source.name}: no .cue or .mds descriptor inside the archive — pass the rip's descriptor file directly")
    if len(cues) > 1:
        names = ', '.join((c.name for c in cues))
        raise FileExistsError(f'{source.name}: multiple cue sheets inside ({names}) — pass the one you mean directly')
    return cues[0]

def descriptor(source: Path) -> Path:
    """The cue sheet (or .mds) of the rip at `source`: a .cue as given, a CD"""
    return _descriptor(Path(source))

def extract_disc(source: Path, dest: Path, pregap: str='trim') -> None:
    """Extract every audio track of the rip at `source` to `dest`/trNN.wav."""
    source = Path(source)
    if not source.exists():
        raise FileNotFoundError(f'{source} does not exist')
    cue = _descriptor(source)
    print(f"[discsrc] {dest.name.removesuffix('.partial')}: extracting CD-DA from {cue.name} (pregap={pregap})")
    extract_cdda.extract(cue, dest, quiet=True, pregap=pregap)

def ensure_audio_cache(dest: Path, needed: set[str], disc, flag: str, pregap: str='trim') -> None:
    """Fill the trNN.wav extraction cache at `dest` from the user-supplied"""
    if not disc:
        if all(((dest / f'{t}.wav').exists() for t in needed)):
            return
        raise FileNotFoundError(f'{dest} is missing tracks and no disc was given -- pass {flag} pointing at the rip (.cue, .chd, or a .zip/.7z containing one)')
    source = Path(disc)
    if not source.exists():
        raise FileNotFoundError(f'{source} does not exist')
    stamp = source_stamp(source, pregap=pregap)
    if stamp_matches(dest, stamp) and all(((dest / f'{t}.wav').exists() for t in needed)):
        return
    if read_stamp(dest) is not None or dest.exists():
        print(f'[discsrc] {dest.name}: cache was made from another rip or settings, or is incomplete -- extracting again')
    tmp = _fresh_partial(dest)
    extract_disc(source, tmp, pregap=pregap)
    missing = sorted((t for t in needed if not (tmp / f'{t}.wav').exists()))
    if missing:
        shutil.rmtree(tmp, ignore_errors=True)
        raise FileNotFoundError(f'extraction from {disc} ran but tracks are still missing: {missing} -- is this the right disc?')
    (tmp / STAMP).write_text(json.dumps(stamp, indent=1), encoding='utf-8')
    _replace_dir(tmp, dest)

def check_audio_cache(dest: Path, needed: set[str], pins_path: Path, title: str, tag: str) -> dict:
    """Check the extracted tracks against the pack's input pins and print"""
    from . import inputpins
    pins = inputpins.load_pins(pins_path)
    if pins is None:
        return {}

    def num(p: Path) -> int:
        return int(p.stem[2:]) if p.stem[2:].isdigit() else 1 << 30
    order = sorted(dest.glob('tr*.wav'), key=num)
    want = {t: dest / f'{t}.wav' for t in sorted(needed)}
    checks = inputpins.check_tracks(pins, want, [order], 'wav')
    stamp = read_stamp(dest) or {}
    aligned = dict(stamp.get('aligned', {}))
    redo = [c for c in checks.values() if c.status == 'ALIGNED']
    staged = []
    for c in redo:
        pcm = inputpins.load_checked(c, 'wav')
        tmp = dest / f'{c.key}.wav.aligned'
        extract_cdda.write_wav(tmp, pcm.tobytes())
        staged.append((tmp, dest / f'{c.key}.wav'))
        aligned[c.key] = c.notes[0] if c.notes else 're-cut'
    for tmp, final in staged:
        tmp.replace(final)
    for key, c in checks.items():
        if c.status == 'MATCH' and key in aligned:
            c.notes.append(f're-cut earlier in this cache: {aligned[key]}')
    if staged and stamp:
        stamp['aligned'] = aligned
        (dest / STAMP).write_text(json.dumps(stamp, indent=1), encoding='utf-8')
    print(inputpins.format_report(title, checks, pins_path.name))
    return checks
