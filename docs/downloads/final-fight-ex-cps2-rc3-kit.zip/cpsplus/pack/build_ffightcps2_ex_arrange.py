"""`build_ffightcps2_ex_arrange.py` — Final Fight EX on CPS2: ARRANGE and voiced cut scenes.

Final Fight EX's CPS2 port plays CPS1
Final Fight EX's Sega CD scenes and, under its CPS+ Arrange MRA, CPS1 EX's
arranged soundtrack and voiced scene audio.  This builder RE-TABLES CPS1 EX's
accepted region packs for it -- ``ffight_arrange`` (US) and
``ffight_arrange_jp`` (JP), hash-pinned -- the way pack/retable_ssf2t_dos.py
re-tables the DOS packs: every track (audio and loop metadata) is carried byte
for byte, so the CPS2 packs play exactly the accepted, hardware-validated
CPS1 audio, and only the header and trigger table change:

  * PROTOCOL -- protocols.PROTOCOLS["ffightcps2_ex"]: the port's SFA3 sz3 1.71
    records on the CPS2 QSound latch (0x618000), with CPS1 ffight's control
    semantics (0xff05, the port's $f7, stops; nothing else does).
  * TRIGGERS -- the 16-bit 0x1200-row table.  The port posts a Final Fight
    command byte b as 0x00bb; under its Arrange MRA it posts 0x0100|b for the
    commands of manifests/ffightcps2_ex_arrange_trigger_map.tsv (the map says
    when; see its header).  Every source row moves from b to 0x0100|b with
    suppress=1: a 0x01xx word must never reach the driver, and CPS1's one
    unsuppressed play row (the US opening's entry on the ring) is a companion
    the port posts beside the native ring.  Rows 0x0000-0x00ff stay empty, so
    native commands (MUSIC ORIGINAL, no MRA) never trigger the pack.
  * GAIN -- the play rows' trigger gain, TRIG_GAIN, is unity, measured against
    the port's own QSound music (tools/loudness_match.py: EBU R128 on
    matched pairs, 17 October 2026): the arranged tracks sit at its level,
    median -0.7 LU over 18 US pairs (IQR 3.0) and -0.6 LU over 19 Japanese
    (IQR 3.2), and a trigger gain cannot exceed 0x7f.  CPS1's packs ship
    unity against the YM2151/OKI board too; the port's conversion keeps that
    board's loudness.

The map is checked against each source pack's table: the same commands, verbs
and tracks, the posting class following from the CPS1 row (an unsuppressed
play row a companion, the rest arrange).  The port's build reads the same map for its posting table.

RESTORATION rows are this port's own, not CPS1's: the English restoration EX
posts one in place of another row's word (the map's header).  Its track is a
DERIVED track: a source track's audio byte for byte with new loop metadata
(derived()), here Japan's opening with its own one-bar seam wrapped three
times instead of once (its loop start in CPS1's builder coordinates moved by
Japan's loop shift, as build_ffight_arrange moves it).  Derived tracks follow
the source's tracks, so every source track keeps its index.

ENGLISH (the restoration EX's redub): the en pack is the JP pack with
two tracks of its own, the redub's mixed scenes (on the game's
clock, so sample for sample as long as Japan's voiced tracks), and the JP map's two voiced keys,
0x0172 and 0x0173, pointing at them.  Every JP track stays byte for byte; the English WAVs must be
the approved English scene renders (--english DIR holds them).

TIME ATTACK (backports/ffightcps2/TIME_ATTACK_PLAN.md): the Console + Time
Attack build posts its music aliases $7a-$7c as the map's time_attack rows,
0x017a-0x017c, all three the Sega CD's Time Attack song (track 20).  CPS1's
packs never carried it, so --time-attack adds it as the pack's own track from
the region's disc (--us-disc / --jp-disc, the rips build_ffight_arrange takes),
its loop authored here in US sample coordinates and moved by Japan's
loop_shift like every other authored loop.  Without --time-attack the rows are
left out and every pack builds exactly as before.

Run (uniform entry point):
  build_pack.py ffightcps2-ex [--region us|jp|en|both] [--english DIR] [--out-dir DIR]
                              [--time-attack --us-disc CUE --jp-disc CUE]
INPUT: the accepted packs in packs/ (or packs/retired/ if superseded), whose
SHA-256 SOURCE_SHA256 pins.  Output: work/packs, for normal promotion.
"""
from __future__ import annotations

# BEGIN ARCADE PYTHON BOOTSTRAP
import sys as _arcade_sys
from pathlib import Path as _ArcadePath
_arcade_sys.path.insert(0, str(_ArcadePath(__file__).resolve().parents[2]))
from kit_python import bootstrap as _arcade_bootstrap
_arcade_bootstrap()
# END ARCADE PYTHON BOOTSTRAP

import argparse
import hashlib
from dataclasses import dataclass, replace
from pathlib import Path

from . import protocols
from .format import (DEFAULT_TRIGGER_ROWS, VERB_NAMES, VERB_NONE, VERB_PLAY,
                     VERB_STOP, PackReader, PackWriter, TriggerRow)

CP = Path(__file__).resolve().parents[1]
ACCEPTED = CP / "packs"
RETIRED = ACCEPTED / "retired"
SCRATCH = CP / "work" / "packs"
TRIGGER_TSV = CP / "manifests" / "ffightcps2_ex_arrange_trigger_map.tsv"

REGIONS = {
    "us": {"source": "ffight_arrange.cpk", "pack": "ffightcps2_ex_arrange.cpk",
           "title": "Final Fight EX CPS2 (Arrange)"},
    "jp": {"source": "ffight_arrange_jp.cpk", "pack": "ffightcps2_ex_arrange_jp.cpk",
           "title": "Final Fight EX CPS2 (Arrange, Japan)"},
    "en": {"source": "ffight_arrange_jp.cpk", "pack": "ffightcps2_ex_arrange_en.cpk", "rows": "jp",
           "title": "Final Fight EX CPS2 (Arrange, English restoration)"},
}
# The en pack's own tracks: {track: (the JP track it replaces, the redub scene, its map row)}.
ENGLISH = {"en_tr23": ("jp_tr23", "opening", 0x0172), "en_tr24": ("jp_tr24", "ending", 0x0173)}
DUB_RECEIPT = CP.parent / "backports" / "ffightcps2" / "manifests" / "dub_mix_receipt.json"


def english_pcm(english_dir: Path, scene: str) -> bytes:
    """The redub's mixed scene: s16le stereo at 44.1 kHz, its WAV the one the receipt records."""
    import json
    import wave
    path = english_dir / f"{scene}_en.wav"
    want = json.loads(DUB_RECEIPT.read_text())["scenes"][scene]["sha256"]
    if digest(path) != want:
        raise SystemExit(f"{path}: not the redub mix {DUB_RECEIPT.name} records ({want[:12]})")
    with wave.open(str(path)) as w:
        if (w.getnchannels(), w.getsampwidth(), w.getframerate()) != (2, 2, 44100):
            raise SystemExit(f"{path}: not 16-bit stereo at 44.1 kHz")
        return w.readframes(w.getnframes())
SOURCE_SHA256 = {
    "ffight_arrange.cpk": "fd8f3b6cda24fd8398f858cf8d555126e39ea2c75686ca4d208f279807748a19",
    "ffight_arrange_jp.cpk": "5e0ca87e2ab617738c6a3f3f3431b24eccf329fd25d547fdc048886971b442b2",
}
PAGE = 0x0100               # the port's pack page: 0x0100 | Final Fight byte
POSTS = ("arrange", "companion")
OWN_POSTS = ("restoration", "time_attack")  # this port's rows (the map's header)

# The Time Attack song: the disc's track 20 (both discs number it 20), its
# extraction's SHA-256 per region (pregap trimmed, as discsrc cuts it), and its
# authored loop in US samples: (loop_start, loop_end), each a downbeat of the
# measured 1.7502 s bar grid, blended with the pack's 7200-sample seam.
# Candidate C of TIME_ATTACK_PLAN.md: bar 12 -> bar 60 (84.01 s), chosen in the
# listening review on 3 November.
# Its level follows the pack's rule (TRIG_GAIN): a trigger gain measured
# against the native music the rows replace, tools/loudness_match.py's method
# (EBU R128 integrated, mono, the first 8 s; its arranged side reproduces the
# receipts' -21.9 / -24.2 / -17.9 for 0x40 / 0x43 / 0x45). Natively the three
# aliases play placeholder stage themes, so one gain serves all three rows
# (chosen 3 November): tr20 measures -19.3 LUFS against the native 0x40
# -21.3, 0x43 -23.2 and 0x45 -20.9 (backports/ffightcps2/manifests/
# ex_arrange_gain_*.json), deltas +2.0 / +3.9 / +1.6 LU, median +2.0:
# round(0x7f x 10^(-2.0 / 20)) = 0x65. The track itself stays at unity, as
# every track in the pack does.
TIME_ATTACK_TRIG_GAIN = 0x65
TIME_ATTACK = {"track": "tr20", "name": "tr20-time-attack", "loop": (949152, 4653952),
               "wav_sha256": {"us": "08bf3bdf5f2b641ee362c8acb1e8b2fbea2d4aee5b325807bf420930243ccff1",
                              "jp": "10410202be14638a852e4f098b2987592e151e42201f01dd6973741064c01cf5"}}


def derived():
    """{region: {derived track: (source track, loop start sample, loop count)}}.
    The restoration's opening: Japan's own accepted one-bar seam, wrapped
    three times instead of once (17 October: the USA pack's longer
    wrap, moved onto Japan's master, did not sound seamless)."""
    from .build_ffight_arrange import REGIONS as FFA
    return {"jp": {"tr25-restoration": ("tr25", FFA["jp"]["opening_loop"][0] + FFA["jp"]["loop_shift"], 3)}}
TRIG_GAIN = 0x7f            # play rows: measured, see the module docstring


@dataclass(frozen=True)
class Row:
    cmd: int
    region: str
    post: str
    verb: int
    track: str | None
    cue: str


def load_map(path: Path = TRIGGER_TSV) -> list[Row]:
    rows = []
    for line in path.read_text().splitlines():
        if not line.strip() or line.startswith("#"):
            continue
        cells = line.split("\t")
        if len(cells) != 6:
            raise ValueError(f"{path.name}: expected 6 columns: {line!r}")
        cmd_s, region, post, verb_s, track_s, cue = cells
        cmd = int(cmd_s, 16)
        if cmd >> 8 != PAGE >> 8 or (cmd & 0xFF) >= 0xF0:
            raise ValueError(f"{path.name}: 0x{cmd:04x} is not a pack-page word")
        if region not in ("us", "jp", "both") or post not in POSTS + OWN_POSTS:
            raise ValueError(f"{path.name}: bad region or post in {line!r}")
        verb = {"play": VERB_PLAY, "none": VERB_NONE}[verb_s]
        track = None if track_s == "-" else track_s
        if (verb == VERB_PLAY) != (track is not None):
            raise ValueError(f"{path.name}: 0x{cmd:04x}: play needs a track, none none")
        rows.append(Row(cmd, region, post, verb, track, cue))
    return rows


def region_rows(region: str, path: Path = TRIGGER_TSV) -> dict[int, Row]:
    out = {}
    for row in load_map(path):
        if row.region in (region, "both"):
            if row.cmd in out:
                raise ValueError(f"0x{row.cmd:04x} twice for {region}")
            out[row.cmd] = row
    return out


def posting_classes(region: str, path: Path = TRIGGER_TSV) -> bytes:
    """The port's posting table for a region: one byte per Final Fight command
    below $f0, 0 native, 1 arrange, 2 companion (the map's header)."""
    table = bytearray(0xF0)
    for row in region_rows(region, path).values():
        if row.post in POSTS:
            table[row.cmd & 0xFF] = POSTS.index(row.post) + 1
    return bytes(table)


def time_attack_words(region: str, path: Path = TRIGGER_TSV) -> list[int]:
    """The pack words the Time Attack aliases post, in alias order."""
    return sorted(cmd for cmd, row in region_rows(region, path).items() if row.post == "time_attack")


def time_attack_track(region: str, disc: str | None) -> tuple[bytes, object]:
    """(ADX stream, TrackMeta) for the Time Attack song from the region's disc."""
    from . import adxcodec
    from .adxencode import encode_adx_track, read_wav
    from .build_ffight_arrange import CD_DIR, REGIONS as FFA, XFADE_SAMPLES, ensure_disc_audio
    from .format import CODEC_ADX, TrackMeta
    disc_region = "us" if region == "us" else "jp"
    cfg = FFA[disc_region]
    cache = CD_DIR.parent / cfg["cd_subdir"]
    ensure_disc_audio(cache, {TIME_ATTACK["track"]}, disc, cfg["disc_flag"])
    wav = cache / f"{TIME_ATTACK['track']}.wav"
    if digest(wav) != TIME_ATTACK["wav_sha256"][disc_region]:
        raise SystemExit(f"{wav}: not the {disc_region.upper()} disc's track 20 "
                         f"(SHA-256 {TIME_ATTACK['wav_sha256'][disc_region]})")
    pcm, rate, ch, n = read_wav(wav)
    ls, le = (s + cfg["loop_shift"] for s in TIME_ATTACK["loop"])
    if ls % 32 or le % 32 or not 0 < ls < le - XFADE_SAMPLES or le + XFADE_SAMPLES > n:
        raise ValueError(f"Time Attack loop {ls}..{le} is not frame-aligned inside the track")
    data, coef1, coef2, _ = encode_adx_track(pcm, rate, ch, n, TIME_ATTACK["name"], False)
    le_byte = adxcodec.samples_to_stream_byte(le, ch)
    data = data[:le_byte + XFADE_SAMPLES // 32 * 18 * ch]      # infinite crossfade: loop end + blend tail
    return data, TrackMeta(sample_rate=rate, channels=ch, codec=CODEC_ADX, gain=0x7f,
                           loop_start_sample=ls, loop_start_byte=adxcodec.samples_to_stream_byte(ls, ch),
                           loop_end_sample=le, loop_end_byte=le_byte, coef1=coef1, coef2=coef2,
                           xfade_enable=1, loop_count=0, name=f"{TIME_ATTACK['name']} (inner loop)",
                           source=f"ffightcd/{cfg['cd_subdir']}/{TIME_ATTACK['track']}.wav[0:{n}] "
                                  f"sha256 {TIME_ATTACK['wav_sha256'][disc_region]}")


def own_word(region: str, post: str, path: Path = TRIGGER_TSV) -> int:
    """The pack word of a region's own row (the port's layer equate)."""
    words = [cmd for cmd, row in region_rows(region, path).items() if row.post == post]
    if len(words) != 1:
        raise ValueError(f"{region}: {len(words)} {post} rows")
    return words[0]


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def source_pack(name: str) -> Path:
    for candidate in (ACCEPTED / name, *sorted(RETIRED.rglob(name))):
        if candidate.is_file() and digest(candidate) == SOURCE_SHA256[name]:
            return candidate
    raise SystemExit(f"{name}: no accepted copy with SHA-256 {SOURCE_SHA256[name]} "
                     f"in {ACCEPTED} (build it: build_pack.py ffight-arrange)")


def track_name(meta) -> str:
    return meta.name.split(" (", 1)[0]


def expected_rows(source: PackReader) -> dict[int, tuple[str, int, str | None]]:
    """{0x0100|b: (post, verb, track)} following from a CPS1 source table."""
    out = {}
    for b, t in enumerate(source.triggers):
        if t.verb == VERB_NONE and not t.suppress:
            continue                            # unmapped or fail-open
        if t.verb not in (VERB_PLAY, VERB_NONE) or b >= 0xF0:
            raise ValueError(f"source row 0x{b:02x}: verb {VERB_NAMES[t.verb]}")
        post = "companion" if t.verb == VERB_PLAY and not t.suppress else "arrange"
        track = track_name(source.tracks[t.track]) if t.verb == VERB_PLAY else None
        out[PAGE | b] = (post, t.verb, track)
    return out


def retable(region: str, out_dir: Path = SCRATCH, english: Path | None = None, source: Path | None = None,
            english_streams: dict[str, tuple[bytes, str]] | None = None,
            time_attack: bool = False, disc: str | None = None) -> Path:
    """The region's pack.  source: the CPS1 pack to re-table, a file with the SHA-256 SOURCE_SHA256 pins
    (default: the accepted one in packs/).  english_streams: the en pack's own tracks ready as ADX streams,
    {track: (stream, its WAV's SHA-256)}, as the public reconstruction kit rebuilds them,
    in place of --english's WAVs.  time_attack: add the Time Attack song from
    disc (the region's rip) and its rows; without it they are left out."""
    cfg = REGIONS[region]
    if source is not None and digest(Path(source)) != SOURCE_SHA256[cfg["source"]]:
        raise SystemExit(f"{source}: not {cfg['source']} (SHA-256 {SOURCE_SHA256[cfg['source']]})")
    src = Path(source) if source is not None else source_pack(cfg["source"])
    rows = region_rows(cfg.get("rows", region))
    if not time_attack:
        rows = {cmd: row for cmd, row in rows.items() if row.post != "time_attack"}
    if region == "en" and english is None and english_streams is None:
        raise SystemExit("the en pack needs --english DIR (the redub's opening_en.wav and ending_en.wav)")
    source = PackReader(src)
    try:
        if source.crc_check() != (True, True):
            raise ValueError(f"{src}: CRC check failed")
        want = expected_rows(source)
        got = {cmd: (r.post, r.verb, r.track) for cmd, r in rows.items() if r.post in POSTS}
        if got != want:
            diff = sorted(set(got.items()) ^ set(want.items()))
            raise ValueError(f"{TRIGGER_TSV.name} ({region}) differs from {src.name}: {diff}")
        h = source.header
        writer = PackWriter(protocols.PROTOCOLS["ffightcps2_ex"], title=cfg["title"],
                            trigger_rows=DEFAULT_TRIGGER_ROWS, default_rate=h.default_rate,
                            xfade_samples=h.xfade_samples)
        index = {}
        for i, meta in enumerate(source.tracks):
            name = track_name(meta)
            if name in index:
                raise ValueError(f"{src}: two tracks named {name}")
            index[name] = writer.add_track(source.read_track(i), replace(meta))
        made = {}
        rows_of = cfg.get("rows", region)           # en carries Japan's derived track too (the restoration's row)
        for name, (base, loop_start, count) in derived().get(rows_of, {}).items():
            meta = source.tracks[index[base]]
            if loop_start % 32 or not 0 < loop_start < meta.loop_end_sample or not 1 <= count <= 3:
                raise ValueError(f"{name}: loop start {loop_start} (count {count}) is not a 32-sample frame "
                                 "before the loop end, or the count is not 1-3")
            made[name] = replace(meta, name=meta.name.replace(base, name, 1), loop_start_sample=loop_start,
                                 loop_start_byte=loop_start // 32 * 18 * meta.channels, loop_count=count)
            index[name] = writer.add_track(source.read_track(index[base]), made[name])
        own = {}
        if region == "en":                          # the redub's scenes in place of Japan's voiced tracks
            from . import adxcodec
            for name, (base, scene, cmd) in ENGLISH.items():
                meta = source.tracks[index[base]]
                if english_streams is not None:         # ready streams: each checked by its keyed blocks
                    stream, wav_sha256 = english_streams[name]
                    if len(stream) != meta.data_length or meta.loops:
                        raise SystemExit(f"{scene}: a {len(stream)}-byte stream, not as long as {base} (one shot)")
                    own[name] = (stream, None)
                else:
                    pcm = english_pcm(english, scene)
                    n = len(pcm) // 4
                    if adxcodec.stream_bytes_for_samples(n, 2) != meta.data_length or meta.loops:
                        raise SystemExit(f"{scene}: {n} samples, not as long as {base} (one shot)")
                    own[name] = (adxcodec.encode(pcm, 2, 44100), pcm)
                    wav_sha256 = digest(english / f"{scene}_en.wav")
                index[name] = writer.add_track(own[name][0], replace(
                    meta, name=meta.name.replace(base, name, 1),
                    source=f"Final Fight EX CPS2 redub, {scene}_en.wav sha256 {wav_sha256}"))
                if rows[cmd].track != base:
                    raise ValueError(f"0x{cmd:04x} is not {base}'s row")
                rows[cmd] = replace(rows[cmd], track=name)
        ta = None
        if time_attack:
            if h.xfade_samples != 7200:
                raise ValueError(f"{src}: seam blend {h.xfade_samples}, not the 7200 the loop was rendered with")
            ta = time_attack_track(region, disc)
            index[TIME_ATTACK["name"]] = writer.add_track(*ta)
        for cmd, row in sorted(rows.items()):
            gain = (TIME_ATTACK_TRIG_GAIN if row.post == "time_attack" else TRIG_GAIN) if row.verb == VERB_PLAY else 0x7f
            writer.set_trigger(cmd, TriggerRow(
                verb=row.verb, track=index[row.track] if row.track else 0, gain=gain, suppress=1))
        out = out_dir / cfg["pack"]
        out.parent.mkdir(parents=True, exist_ok=True)
        writer.write(out)

        built = PackReader(out)
        try:
            if built.crc_check() != (True, True):
                raise ValueError(f"{out}: CRC check failed")
            n = h.track_count
            if (built.header.track_count != n + len(made) + len(own) + (ta is not None)
                    or (not made and not own and ta is None and (built.header.data_size != h.data_size
                                                  or built._raw_idx != source._raw_idx))
                    or [replace(m, data_offset=0) for m in built.tracks[:n]]
                    != [replace(m, data_offset=0) for m in source.tracks]):
                raise ValueError(f"{out}: the audio index changed")
            for i in range(n):
                if built.read_track(i) != source.read_track(i):
                    raise ValueError(f"{out}: audio track {i} changed")
            for name, meta in made.items():             # a derived track: its base's audio, its own loop
                i = index[name]
                base = derived()[rows_of][name][0]
                if built.read_track(i) != source.read_track(index[base]) or built.tracks[i].loop_start_sample != \
                        meta.loop_start_sample or built.tracks[i].loop_count != meta.loop_count:
                    raise ValueError(f"{out}: derived track {name} is not its base's audio with its own loop")
            for name, (stream, pcm) in own.items():      # an English track: its encoding, decoding to the mix
                import numpy as np
                from . import adxcodec
                if built.read_track(index[name]) != stream:
                    raise ValueError(f"{out}: {name} is not its encoding")
                if pcm is None:
                    continue
                got = np.frombuffer(adxcodec.decode(stream, 2, 44100), "<i2").astype(float)[:len(pcm) // 2]
                ref = np.frombuffer(pcm, "<i2").astype(float)
                snr = 10 * np.log10((ref ** 2).sum() / max(((got - ref) ** 2).sum(), 1.0))
                if snr < 20:
                    raise ValueError(f"{out}: {name} decodes {snr:.1f} dB from the mix")
            if ta is not None:
                i = index[TIME_ATTACK["name"]]
                got = built.tracks[i]
                if built.read_track(i) != ta[0] or (got.loop_start_sample, got.loop_end_sample, got.xfade_enable) != \
                        (ta[1].loop_start_sample, ta[1].loop_end_sample, 1):
                    raise ValueError(f"{out}: the Time Attack track is not its encoding and loop")
            p = built.header.proto
            if (p.latch_page != 0x618000 or built.header.trigger_rows != DEFAULT_TRIGGER_ROWS
                    or p.control_verbs != {0xff05: VERB_STOP, **protocols.CONTROL_EX_PAUSE}):
                raise ValueError(f"{out}: not the CPS2 port's descriptor")
            for cmd, t in enumerate(built.triggers):
                row = rows.get(cmd)
                if row is None:
                    if t.verb != VERB_NONE or t.suppress:
                        raise ValueError(f"{out}: row 0x{cmd:04x} written outside the map")
                elif (t.verb != row.verb or t.suppress != 1
                      or (row.track and t.track != index[row.track])):
                    raise ValueError(f"{out}: row 0x{cmd:04x} is not the map's")
        finally:
            built.close()
    finally:
        source.close()
    print(f"[ffightcps2-ex] {region}: {out} ({out.stat().st_size:,} B), {len(rows)} rows "
          f"from {src.name}" + (f" + derived {sorted(made)}" if made else "") + (f" + English {sorted(own)}" if own else "")
          + (" + Time Attack" if ta is not None else "")
          + f", gain 0x{TRIG_GAIN:02x}, SHA-256 {digest(out)}")
    return out


def self_test() -> None:
    for region in ("us", "jp"):                     # the map's regions (en takes the JP rows)
        rows = {c: r for c, r in region_rows(region).items() if r.post in POSTS}
        classes = posting_classes(region)
        assert all(classes[c & 0xFF] for c in rows) and sum(1 for c in classes if c) == len(rows)
        assert classes[0x70 if region == "us" else 0x72] == 1 and classes[0x40] == 1
        assert classes[0x35] == (2 if region == "us" else 0)
        assert all(classes[b] == 1 for b in range(0x74, 0x79))
    assert own_word("jp", "restoration") == 0x0179 and posting_classes("jp")[0x79] == 0
    for region in ("us", "jp"):                     # own rows, never in the public posting table
        assert time_attack_words(region) == [0x017a, 0x017b, 0x017c]
        assert not any(posting_classes(region)[0x7a:0x7d])
        assert {region_rows(region)[w].track for w in time_attack_words(region)} == {TIME_ATTACK["name"]}
    from .build_ffight_arrange import REGIONS as FFA
    assert all((s + FFA[r]["loop_shift"]) % 32 == 0 for r in ("us", "jp") for s in TIME_ATTACK["loop"])
    jp = region_rows("jp")
    assert all(jp[cmd].track == base for base, _, cmd in ENGLISH.values()) and REGIONS["en"]["rows"] == "jp"
    (name, (base, start, count)), = derived()["jp"].items()
    assert base == "tr25" and start == 1056928 - 128 and count == 3
    print("self-test passed")


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="build_pack.py ffightcps2-ex", description=__doc__.splitlines()[0])
    ap.add_argument("--region", choices=("us", "jp", "en", "both"), default="both")
    ap.add_argument("--english", type=Path, help="the redub's mixed scenes (en: opening_en.wav, ending_en.wav)")
    ap.add_argument("--out-dir", type=Path, default=SCRATCH)
    ap.add_argument("--time-attack", action="store_true", help="add the Time Attack song and its rows")
    ap.add_argument("--us-disc", help="US Final Fight CD rip (.cue/.zip/.7z/.chd), for --time-attack")
    ap.add_argument("--jp-disc", help="JP Final Fight CD rip, for --time-attack (jp and en)")
    ap.add_argument("--self-test", action="store_true")
    a = ap.parse_args(argv)
    if a.self_test:
        self_test()
        return 0
    for region in ("us", "jp") if a.region == "both" else (a.region,):
        retable(region, a.out_dir, a.english, time_attack=a.time_attack,
                disc=a.us_disc if region == "us" else a.jp_disc)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
