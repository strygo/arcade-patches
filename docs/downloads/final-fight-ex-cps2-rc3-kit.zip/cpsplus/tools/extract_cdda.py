"""Extract CD-DA audio tracks from a cue sheet rip to WAV files."""
import argparse
import struct
import wave
from pathlib import Path, PureWindowsPath
SECTOR = 2352
FPS = 75
MDS_NEXT_PREGAP_SECTORS = 150

def msf_to_sector(msf: str) -> int:
    m, s, f = (int(x) for x in msf.split(':'))
    return (m * 60 + s) * FPS + f
CUE_ENCODINGS = ('utf-8-sig', 'cp932', 'cp1252')

def _file_name(line: str) -> str:
    """The name in `FILE "name" TYPE` or an unquoted `FILE name TYPE`."""
    rest = line.strip()[4:].strip()
    if rest.startswith('"'):
        end = rest.find('"', 1)
        if end > 0:
            return rest[1:end]
    parts = rest.rsplit(None, 1)
    return parts[0].strip('"') if len(parts) == 2 else rest.strip('"')

def _resolve(cue_dir: Path, name: str) -> Path:
    """The image file a cue names: as written, with Windows separators, by"""
    for cand in (cue_dir / name, cue_dir.joinpath(*PureWindowsPath(name).parts), cue_dir / PureWindowsPath(name).name):
        try:
            if cand.is_file():
                return cand
        except OSError:
            pass
    low = PureWindowsPath(name).name.lower()
    for f in cue_dir.iterdir():
        if f.name.lower() == low:
            return f
    return cue_dir / name

def _cue_lines(cue_path: Path) -> list[str]:
    raw = cue_path.read_bytes()
    decoded = []
    for enc in CUE_ENCODINGS:
        try:
            decoded.append(raw.decode(enc).splitlines())
        except UnicodeDecodeError:
            continue
    if not decoded:
        return raw.decode('latin-1').splitlines()
    for lines in decoded:
        names = [_file_name(t) for t in lines if t.strip().upper().startswith('FILE')]
        if names and all((_resolve(cue_path.parent, n).is_file() for n in names)):
            return lines
    return decoded[0]

def cue_files(cue_path: Path) -> list[Path]:
    """Every image file the cue names, resolved beside it."""
    return [_resolve(cue_path.parent, _file_name(t)) for t in _cue_lines(cue_path) if t.strip().upper().startswith('FILE')]

def parse_cue(cue_path: Path):
    """Returns [(n, mode, file_path, i0_sector|None, i1_sector, pregap_sectors)],"""
    entries = []
    files = set()
    cur_file = None
    cur = None
    for line in _cue_lines(cue_path):
        t = line.strip()
        word = t.split(None, 1)[0].upper() if t else ''
        if word == 'FILE':
            cur_file = _resolve(cue_path.parent, _file_name(t))
            files.add(cur_file)
        elif word == 'TRACK':
            parts = t.split()
            if cur:
                entries.append(tuple(cur))
            cur = [int(parts[1]), parts[2], cur_file, None, None, 0]
        elif word == 'INDEX' and cur is not None:
            parts = t.split()
            if int(parts[1]) == 0:
                cur[3] = msf_to_sector(parts[2])
            elif int(parts[1]) == 1:
                cur[4] = msf_to_sector(parts[2])
        elif word == 'PREGAP' and cur is not None:
            cur[5] = msf_to_sector(t.split()[1])
        elif word == 'POSTGAP' and cur is not None:
            print(f'note: {cue_path.name} track {cur[0]} has a POSTGAP; its generated silence is not added')
    if cur:
        entries.append(tuple(cur))
    for e in entries:
        if e[2] is None or not e[2].is_file():
            raise FileNotFoundError(f"{cue_path.name}: track {e[0]} names an image file that is not beside the cue ({(e[2].name if e[2] else 'no FILE line')})")
        if e[4] is None:
            raise ValueError(f'{cue_path.name}: track {e[0]} has no INDEX 01')
    return (entries, len(files) > 1)

def track_pcm(entries, multi_file, n, pregap='trim') -> bytes:
    by_n = {e[0]: e for e in entries}
    num, mode, fpath, i0, i1, pregap_sectors = by_n[n]
    if not mode.upper().startswith('AUDIO'):
        raise SystemExit(f'track {n} is {mode}, not AUDIO')
    start = i1 if pregap == 'trim' else i0 if i0 is not None else i1
    nxt = [e for e in entries if e[0] > n and e[2] == fpath]
    size_sectors = fpath.stat().st_size // SECTOR
    end = (nxt[0][3] if nxt[0][3] is not None else nxt[0][4]) if nxt else size_sectors
    with open(fpath, 'rb') as fh:
        fh.seek(start * SECTOR)
        data = fh.read() if multi_file and (not nxt) else fh.read((end - start) * SECTOR)
    if pregap == 'keep' and pregap_sectors:
        data = bytes(pregap_sectors * SECTOR) + data
    return data

def write_wav(path: Path, pcm: bytes) -> None:
    """16-bit stereo 44.1 kHz WAV, the extractor's one output format."""
    w = wave.open(str(path), 'wb')
    w.setnchannels(2)
    w.setsampwidth(2)
    w.setframerate(44100)
    w.writeframes(pcm)
    w.close()

def parse_mds(mds_path: Path):
    """Alcohol descriptor -> [(track_no, is_audio, byte_offset, sector_size)]."""
    mds = mds_path.read_bytes()
    if mds[:16] != b'MEDIA DESCRIPTOR':
        raise SystemExit(f'{mds_path}: not an Alcohol 120% .mds')
    sess_off = struct.unpack_from('<I', mds, 80)[0]
    n_blocks = mds[sess_off + 10]
    tb_off = struct.unpack_from('<I', mds, sess_off + 20)[0]
    out = []
    for i in range(n_blocks):
        b = mds[tb_off + i * 80:tb_off + (i + 1) * 80]
        if b[4] >= 160:
            continue
        sector_size = struct.unpack_from('<H', b, 16)[0]
        start_off = struct.unpack_from('<Q', b, 40)[0]
        out.append((b[4], b[0] == 169, start_off, sector_size))
    return sorted(out)

def extract_mds(mds_path: Path, outdir: Path, tracks=None, quiet=False) -> list[Path]:
    entries = parse_mds(mds_path)
    mdf = mds_path.with_suffix('.mdf')
    if not mdf.exists():
        raise SystemExit(f'{mdf} missing (must sit beside the .mds)')
    data = mdf.read_bytes()
    want = tracks if tracks else [n for n, au, _, _ in entries if au]
    outdir.mkdir(parents=True, exist_ok=True)
    outs = []
    by_n = {e[0]: e for e in entries}
    order = [e[0] for e in entries]
    for n in want:
        num, is_audio, start, ssize = by_n[n]
        if not is_audio:
            raise SystemExit(f'track {n} is not audio')
        nxt = [m for m in order if m > n]
        end = by_n[nxt[0]][2] if nxt else len(data)
        end -= MDS_NEXT_PREGAP_SECTORS * ssize
        pcm = b''.join((data[o:o + SECTOR] for o in range(start, end, ssize)))
        out = outdir / f'tr{n:02d}.wav'
        w = wave.open(str(out), 'wb')
        w.setnchannels(2)
        w.setsampwidth(2)
        w.setframerate(44100)
        w.writeframes(pcm)
        w.close()
        outs.append(out)
        if not quiet:
            print(f'  tr{n:02d}: {len(pcm) // 4 / 44100:7.1f}s -> {out}')
    return outs

def extract(cue: Path, outdir: Path, tracks=None, quiet=False, pregap='trim') -> list[Path]:
    assert pregap in ('trim', 'keep'), pregap
    if Path(cue).suffix.lower() == '.mds':
        if pregap != 'trim':
            raise SystemExit('--pregap keep is not defined for .mds rips')
        return extract_mds(Path(cue), outdir, tracks, quiet)
    entries, multi_file = parse_cue(cue)
    want = tracks if tracks else [e[0] for e in entries if e[1].upper().startswith('AUDIO')]
    outdir.mkdir(parents=True, exist_ok=True)
    outs = []
    for n in want:
        pcm = track_pcm(entries, multi_file, n, pregap)
        out = outdir / f'tr{n:02d}.wav'
        write_wav(out, pcm)
        outs.append(out)
        if not quiet:
            print(f'  tr{n:02d}: {len(pcm) // 4 / 44100:7.1f}s -> {out}')
    return outs

def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('cue', type=Path, help='cue sheet or Alcohol .mds')
    ap.add_argument('outdir', type=Path)
    ap.add_argument('--tracks', help='comma list; default = every AUDIO track')
    ap.add_argument('--pregap', choices=('trim', 'keep'), default='trim')
    a = ap.parse_args(argv)
    want = [int(x) for x in a.tracks.split(',')] if a.tracks else None
    extract(a.cue, a.outdir, want, pregap=a.pregap)
    return 0
