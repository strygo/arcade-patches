"""Replay compiled float64 splice weights using bounded standard-library PCM work."""
import base64
import hashlib
import math
import struct
import zlib


def decode_weights(value, frames):
    if not isinstance(value, dict) or value.get('frames') != frames or not 0 < frames <= 65536:
        raise ValueError('Missing or invalid compiled PCM splice weights')
    decoder = zlib.decompressobj()
    raw = decoder.decompress(base64.b64decode(value['data'], validate=True), frames * 16 + 1)
    if (len(raw) != frames * 16 or not decoder.eof or decoder.unused_data or decoder.unconsumed_tail
            or hashlib.sha256(raw).hexdigest() != value['sha256']):
        raise ValueError('Compiled PCM splice weights differ')
    return struct.iter_unpack('<dd', raw)


def arcade_cut(pcm, ch, rate, lead_samples, cut_at, bars, bpm, xfade, *, weights=None):
    if (type(ch) is not int or not 1 <= ch <= 8 or type(rate) is not int or rate <= 0
            or type(lead_samples) is not int or lead_samples < 0 or len(pcm) % (2 * ch)
            or not all(math.isfinite(v) for v in (cut_at, bars, bpm, xfade))
            or cut_at < 0 or bars < 0 or bpm <= 0 or xfade < 0):
        raise ValueError('Invalid PCM splice parameters')
    width = ch * 2
    frames = len(pcm) // width + lead_samples
    t0 = int(cut_at * rate)
    t1 = t0 + int(((60.0 / bpm) * 4 * bars) * rate)
    xf = int(xfade * rate)
    if t1 + xf > frames:
        raise ValueError('arcade cut runs past the end of the track')
    n = min(xf, t0, frames - t1)
    raw = memoryview(pcm)
    def parts(start, end):
        result = []
        if start < min(end, lead_samples):result.append(bytes((min(end, lead_samples) - start) * width))
        if end > lead_samples:result.append(raw[max(0, start - lead_samples) * width:(end - lead_samples) * width])
        return result
    blend = bytearray(n * width)
    if n:
        def sample(frame, channel):
            return 0 if frame < lead_samples else struct.unpack_from('<h', raw, (frame - lead_samples) * width + channel * 2)[0]
        for index, (left, right) in enumerate(decode_weights(weights, n)):
            if not (math.isfinite(left) and math.isfinite(right) and 0 <= left <= 1 and 0 <= right <= 1):
                raise ValueError('Invalid PCM splice coefficient')
            for channel in range(ch):
                value = sample(t0 - n + index, channel) * left + sample(t1 + index, channel) * right
                struct.pack_into('<h', blend, index * width + channel * 2, int(max(-32768, min(32767, value))))
    out = b''.join(parts(0, t0 - n) + [blend] + parts(t1 + n, frames))
    return out, len(out) // width
