#!/usr/bin/env python3
"""Final Fight EX (CPS-2)'s CPS+ Arrange packs, from the user's own Final Fight CD discs (KIT.md).

CPS+'s own builders make them, as the public CPS+ kit makes its Final Fight packs:
``build_ffight_arrange`` turns a disc into CPS1 Final Fight EX's arrange pack for its region
(``ffight_arrange`` from the US disc, ``ffight_arrange_jp`` from the Japanese one; ffmpeg's ADX encoder,
which the CPS+ kit needs for them too), and ``build_ffightcps2_ex_arrange`` re-tables that pack for the
port: USA EX takes the US disc, Japan EX and the English restoration the Japanese one.

The English restoration's pack also carries the redub's two mixed scenes (backports/ffightcps2 DUB.md),
which cannot be rebuilt in plain Python identically everywhere. They ship keyed (KIT.md, "Keyed data,
item by item"): each block of their ADX streams to the same block of the Japanese voiced track it
replaces in the pack, which the user's disc gives. A block is BLOCK_FRAMES stereo ADX frames, the most
whole frames within one second (44,096 samples), so every key is the same second of the Japanese scene
and a differing rip fails at the second it differs.

    packs.py --self-test
    packs.py build --edition english --disc-jp JP.cue --work WORK --keyed DIR --out PACK
"""
from __future__ import annotations

# BEGIN ARCADE PYTHON BOOTSTRAP
import sys as _arcade_sys
from pathlib import Path as _ArcadePath
_arcade_sys.path.insert(0, str(_ArcadePath(__file__).resolve().parents[0]))
from kit_python import bootstrap as _arcade_bootstrap
_arcade_bootstrap()
# END ARCADE PYTHON BOOTSTRAP

import argparse
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from keyed import keystream, sha256, xor     # noqa: E402  (KIT.md's keystream, shared with ffex_kit)
# The kit ships CPS+'s pack package beside this file (cpsplus/pack, cpsplus/manifests); the repository
# has it at its root.
CPSPLUS_PARENT = HERE if (HERE / "cpsplus" / "pack").is_dir() else HERE.parents[2]

# The packs the kit builds, and the SHA-256 each must have (the test kits' and the release's): with
# the Time Attack song from the edition's disc and its rows (build_ffightcps2_ex_arrange.TIME_ATTACK).
PACKS = {
    "usa": ("us", "ffightcps2_ex_arrange.cpk",
            "fe12b5f231b76878d7ee747f4a304d00c74e9ead9e2a402ee71664b16f032bb3"),
    "japan": ("jp", "ffightcps2_ex_arrange_jp.cpk",
              "19d53e380a67641a77a7301970c7c7e2c936c5cdac0188225ac94f92f4806017"),
    "english": ("en", "ffightcps2_ex_arrange_en.cpk",      # redub mix 18 (manifests/dub_mix_receipt.json)
                "b66ba28ec17ec72818e173447a7071153cf99415255450d095348568981d6328"),
}
DISC_REGION = {"usa": "us", "japan": "jp", "english": "jp"}
FRAME_BYTES = 36                    # a stereo ADX frame: 18 bytes a channel, 32 samples
BLOCK_FRAMES = 1378                 # the most whole frames within one second at 44.1 kHz
BLOCK_BYTES = FRAME_BYTES * BLOCK_FRAMES


def cpsplus():
    """CPS+'s pack builders, from CPSPLUS_PARENT (never a different copy on the path)."""
    if str(CPSPLUS_PARENT) not in sys.path:
        sys.path.insert(0, str(CPSPLUS_PARENT))
    from cpsplus.pack import build_ffight_arrange, build_ffightcps2_ex_arrange, format as fmt
    if Path(build_ffightcps2_ex_arrange.__file__).resolve().parents[2] != CPSPLUS_PARENT.resolve():
        raise ImportError(f"cpsplus resolved to {build_ffightcps2_ex_arrange.__file__}, not {CPSPLUS_PARENT}")
    return build_ffight_arrange, build_ffightcps2_ex_arrange, fmt


def tracks(pack: Path) -> dict[str, bytes]:
    """{track name: stream} of a pack."""
    _, ex, fmt = cpsplus()
    reader = fmt.PackReader(pack)
    try:
        return {ex.track_name(m): reader.read_track(i) for i, m in enumerate(reader.tracks)}
    finally:
        reader.close()


def blocks(length: int):
    for offset in range(0, length, BLOCK_BYTES):
        yield offset, min(BLOCK_BYTES, length - offset)


# --- generator side: the keyed English scenes from a built English pack ----------------------------

def make_keyed(english_pack: Path, jp_source_pack: Path) -> tuple[dict, bytes]:
    """(manifest, payload): the English pack's own tracks, keyed block by block to the Japanese source
    pack's voiced tracks they replace (KIT.md's keyed-items interface).  A built pack keeps its track
    names in a sidecar only, so its own tracks are found by place: the source's tracks, its derived
    tracks, then ENGLISH's in order (build_ffightcps2_ex_arrange.retable)."""
    _, ex, fmt = cpsplus()
    jp = tracks(jp_source_pack)
    reader = fmt.PackReader(english_pack)
    try:
        first = len(jp) + len(ex.derived().get("jp", {}))
        # then the Time Attack song, last (retable's time_attack), which the kit rebuilds from the disc
        if reader.header.track_count != first + len(ex.ENGLISH) + 1:
            raise ValueError(f"{english_pack}: {reader.header.track_count} tracks, not the English pack's")
        own = {name: reader.read_track(first + i) for i, name in enumerate(ex.ENGLISH)}
    finally:
        reader.close()
    receipt = json.loads(ex.DUB_RECEIPT.read_text())
    source = Path(jp_source_pack).stem
    items, payload = [], bytearray()
    for name, (base, scene, _) in ex.ENGLISH.items():
        stream, counterpart = own[name], jp[base]
        if len(stream) != len(counterpart) or len(stream) % FRAME_BYTES:
            raise ValueError(f"{name}: {len(stream)} bytes against {base}'s {len(counterpart)}")
        for k, (offset, length) in enumerate(blocks(len(stream))):
            item = f"{name}/{k:04d}"
            data = stream[offset:offset + length]
            key = keystream(item, counterpart[offset:offset + length], length)
            items.append({"name": item, "counterpart": {"source": f"pack:{source}:{base}", "offset": offset,
                                                        "length": length},
                          "offset": len(payload), "length": length, "sha256": sha256(data)})
            payload += xor(data, key)
    tracks_wav = {name: receipt["scenes"][scene]["sha256"] for name, (_, scene, _) in ex.ENGLISH.items()}
    return {"schema": 1, "what": "the English restoration pack's redub scenes, keyed block by block to the "
            "Japanese voiced tracks they replace", "block_frames": BLOCK_FRAMES, "mix": receipt.get("mix"),
            "tracks": tracks_wav, "items": items}, bytes(payload)


# --- kit side ------------------------------------------------------------------------------------

def rebuild_keyed(manifest: dict, payload: bytes, jp_source_pack: Path) -> dict[str, tuple[bytes, str]]:
    """{own track: (stream, its WAV's SHA-256)}: every block XORed with its counterpart's key and checked."""
    if manifest.get("schema") != 1 or manifest.get("block_frames") != BLOCK_FRAMES:
        raise ValueError("keyed manifest: unsupported schema or block size")
    jp = tracks(jp_source_pack)
    parts: dict[str, bytearray] = {}
    for item in manifest["items"]:
        track, k = item["name"].split("/")
        kind, source, base = item["counterpart"]["source"].split(":")
        if kind != "pack" or source != Path(jp_source_pack).stem:
            raise ValueError(f"{item['name']}: counterpart {item['counterpart']['source']} is not this pack's")
        off, length = item["counterpart"]["offset"], item["counterpart"]["length"]
        counterpart = jp[base][off:off + length]
        if len(counterpart) != length or item["length"] != length:
            raise ValueError(f"{item['name']}: the counterpart is shorter than the item")
        data = xor(payload[item["offset"]:item["offset"] + length], keystream(item["name"], counterpart, length))
        if sha256(data) != item["sha256"]:
            raise ValueError(f"{item['name']}: differs (second {int(k)} of {base}): wrong or damaged Japanese disc?")
        stream = parts.setdefault(track, bytearray())
        if len(stream) != off:
            raise ValueError(f"{item['name']}: blocks out of order")
        stream += data
    return {name: (bytes(stream), manifest["tracks"][name]) for name, stream in parts.items()}


def source_pack(region: str, disc: Path, work: Path) -> Path:
    """CPS1 Final Fight EX's arrange pack for the region, from the user's disc, as the CPS+ kit builds it."""
    ffa, ex, _ = cpsplus()
    name = ffa.REGIONS[region]["pack"] + ".cpk"
    out = work / "source" / name
    if not (out.is_file() and sha256(out.read_bytes()) == ex.SOURCE_SHA256[name]):
        out.parent.mkdir(parents=True, exist_ok=True)
        ffa.build("adx", out=str(out), cd_dir=str(work / f"cd_{region}"), measure_snr=False,
                  **{f"{region}_disc": str(disc)}, region=region)
    if sha256(out.read_bytes()) != ex.SOURCE_SHA256[name]:
        raise ValueError(f"{name}: built from {disc}, but not the verified pack: a different rip or release?")
    return out


def build(disc_jp: Path | None, disc_us: Path | None, edition: str, out_path: Path, *, work: Path,
          keyed: Path | None = None, expect_sha256: str | None = None) -> Path:
    """The edition's pack at out_path, from its region's disc (and, for the English restoration, the
    keyed redub scenes in keyed/: english_pack.json and english_pack.bin), checked against its SHA-256."""
    region = DISC_REGION[edition]
    disc = disc_us if region == "us" else disc_jp
    if disc is None:
        raise ValueError(f"{edition}: needs the {'US' if region == 'us' else 'Japanese'} disc")
    _, ex, _ = cpsplus()
    pack_region, name, pinned = PACKS[edition]
    source = source_pack(region, Path(disc), Path(work))
    streams = None
    if edition == "english":
        if keyed is None:
            raise ValueError("english: needs the keyed redub scenes (--keyed)")
        manifest = json.loads((Path(keyed) / "english_pack.json").read_text())
        streams = rebuild_keyed(manifest, (Path(keyed) / "english_pack.bin").read_bytes(), source)
    staged = ex.retable(pack_region, Path(work) / "packs", source=source, english_streams=streams,
                        time_attack=True, disc=str(disc))
    want = expect_sha256 or pinned
    got = sha256(staged.read_bytes())
    if want and got != want:
        raise ValueError(f"{name}: SHA-256 {got}, not {want}")
    out_path = Path(out_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_bytes(staged.read_bytes())
    return out_path


def self_test():
    # keystream: deterministic, depends on the name and on every counterpart byte, any length
    a = keystream("en_tr23/0000", b"\x01" * 64, 100)
    assert len(a) == 100 and a == keystream("en_tr23/0000", b"\x01" * 64, 100)
    assert a != keystream("en_tr23/0001", b"\x01" * 64, 100) and a != keystream("en_tr23/0000", b"\x01" * 63 + b"\x02", 100)
    assert xor(xor(b"abc", a[:3]), a[:3]) == b"abc"
    assert list(blocks(BLOCK_BYTES * 2 + 36)) == [(0, BLOCK_BYTES), (BLOCK_BYTES, BLOCK_BYTES), (2 * BLOCK_BYTES, 36)]
    assert BLOCK_FRAMES * 32 <= 44100 < (BLOCK_FRAMES + 1) * 32
    # a synthetic round trip through the item format, and a counterpart that differs fails at its block
    stream = bytes(range(256)) * (BLOCK_BYTES * 2 // 256 + 1)
    stream = stream[:BLOCK_BYTES + FRAME_BYTES * 3]
    counterpart = bytes(reversed(stream))
    items, payload = [], bytearray()
    for k, (off, n) in enumerate(blocks(len(stream))):
        name = f"t/{k:04d}"
        items.append({"name": name, "offset": len(payload), "length": n, "sha256": sha256(stream[off:off + n]),
                      "counterpart": {"source": "pack:jp:base", "offset": off, "length": n}})
        payload += xor(stream[off:off + n], keystream(name, counterpart[off:off + n], n))

    def rebuild(cp):
        out = bytearray()
        for item in items:
            off, n = item["counterpart"]["offset"], item["length"]
            data = xor(payload[item["offset"]:item["offset"] + n], keystream(item["name"], cp[off:off + n], n))
            if sha256(data) != item["sha256"]:
                return item["name"]
            out += data
        return bytes(out)
    assert rebuild(counterpart) == stream
    damaged = bytearray(counterpart)
    damaged[BLOCK_BYTES + 5] ^= 1
    assert rebuild(bytes(damaged)) == "t/0001"
    print("self-test passed")


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--self-test", action="store_true")
    sub = ap.add_subparsers(dest="command")
    b = sub.add_parser("build", help="one edition's pack from its disc")
    b.add_argument("--edition", choices=sorted(PACKS), required=True)
    b.add_argument("--disc-jp", type=Path)
    b.add_argument("--disc-us", type=Path)
    b.add_argument("--work", type=Path, required=True)
    b.add_argument("--keyed", type=Path, help="the keyed redub scenes (english_pack.json/.bin)")
    b.add_argument("--out", type=Path, required=True)
    b.add_argument("--sha256", help="the SHA-256 the pack must have")
    k = sub.add_parser("keyed", help="generator: key a built English pack's redub scenes")
    k.add_argument("--english-pack", type=Path, required=True)
    k.add_argument("--jp-source-pack", type=Path, required=True)
    k.add_argument("--out-dir", type=Path, required=True)
    a = ap.parse_args(argv)
    if a.self_test:
        self_test()
        return 0
    if a.command == "build":
        out = build(a.disc_jp, a.disc_us, a.edition, a.out, work=a.work, keyed=a.keyed, expect_sha256=a.sha256)
        print(f"{out}: {sha256(out.read_bytes())}")
    elif a.command == "keyed":
        manifest, payload = make_keyed(a.english_pack, a.jp_source_pack)
        a.out_dir.mkdir(parents=True, exist_ok=True)
        (a.out_dir / "english_pack.json").write_text(json.dumps(manifest, indent=1) + "\n")
        (a.out_dir / "english_pack.bin").write_bytes(payload)
        print(f"{len(manifest['items'])} items, {len(payload)} payload bytes into {a.out_dir}")
    else:
        ap.print_help()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
