"""Final Fight EX (CPS-2): the public kit's build of one edition (KIT.md)."""
from __future__ import annotations
import argparse
from contextlib import contextmanager
import hashlib
import json
import os
from pathlib import Path
import sys
import zipfile
HERE = Path(__file__).resolve().parent
ROOT = HERE if (HERE / 'backports' / 'ffightcps2').is_dir() else HERE.parents[2]
SCRIPTS = ROOT / 'backports' / 'ffightcps2' / 'scripts'
FFCD = ROOT / 'backports' / 'ffightcd'
EDITIONS = {'usa': 'us', 'japan': 'jp', 'english': 'jp'}
ROMSETS = ('ffight', 'ffightu', 'ffightj', 'sfa3u')
QSOUND_FIRMWARE = 'dl-1425.bin'
sys.path.insert(0, str(HERE))
from keyed import sha256, unseal

def decode(value):
    if isinstance(value, list):
        return [decode(v) for v in value]
    if isinstance(value, dict):
        if '__tuple__' in value:
            return tuple((decode(v) for v in value['__tuple__']))
        if '__set__' in value:
            return {decode(v) for v in value['__set__']}
        if '__items__' in value:
            return {decode(k): decode(v) for k, v in value['__items__']}
        return {k: decode(v) for k, v in value.items()}
    return value

def data_track(disc):
    """The image holding the disc's first track as CPS1 EX's chain reads it (2352-byte MODE1 sectors"""
    disc = Path(disc)
    if disc.suffix.lower() in ('.bin', '.img'):
        return disc
    if str(ROOT) not in sys.path:
        sys.path.insert(0, str(ROOT))
    from cpsplus.pack import discsrc
    cue = discsrc.descriptor(disc)
    if cue.suffix.lower() != '.cue':
        raise ValueError(f"{disc.name}: give the disc's .cue sheet")
    tracks, _ = discsrc.extract_cdda.parse_cue(cue)
    number, mode, image, _, start, _ = tracks[0]
    if number != 1 or mode.upper() != 'MODE1/2352' or start != 0:
        raise ValueError(f'{cue.name}: track 1 is not a MODE1/2352 data track at the start of its image')
    return image

@contextmanager
def disc_workspace(work):
    """Own compressed-disc extraction during ROM or pack reconstruction."""
    before = os.environ.get('CAPCOM_DISC_CACHE')
    os.environ['CAPCOM_DISC_CACHE'] = str(Path(work).resolve() / 'disc-cache')
    try:
        yield
    finally:
        if before is None:
            os.environ.pop('CAPCOM_DISC_CACHE', None)
        else:
            os.environ['CAPCOM_DISC_CACHE'] = before

def write_romsets(romsets, folder):
    """Canonical archives of the user's romsets ({set: {member: bytes}}); the QSound firmware joins"""
    folder.mkdir(parents=True, exist_ok=True)
    for name in ROMSETS:
        if name not in romsets:
            raise ValueError(f'the {name} romset is missing')
        members = dict(romsets[name])
        if name == 'sfa3u' and QSOUND_FIRMWARE not in members:
            firmware = romsets.get('qsound', {}).get(QSOUND_FIRMWARE)
            if firmware is None:
                raise ValueError(f'sfa3u has no {QSOUND_FIRMWARE} and no QSound firmware was found')
            members[QSOUND_FIRMWARE] = firmware
        with zipfile.ZipFile(folder / f'{name}.zip', 'w', zipfile.ZIP_DEFLATED) as z:
            for member in sorted(members):
                z.writestr(member, members[member])
    return folder

class Kit:
    """Kit mode's sites for build_m1_spike.build (its kit argument)."""

    def __init__(self, edition, data, work, roms, discs):
        self.edition, self.data, self.work, self.roms, self.discs = (edition, data, work, roms, discs)
        self.meta = json.loads((data / 'kitdata' / f'{edition}.json').read_text(encoding='utf-8'))
        if self.meta['edition'] != edition:
            raise ValueError(f"kit data for {self.meta['edition']}, not {edition}")
        self.keyed = json.loads((data / 'keyed' / f'{edition}.json').read_text(encoding='utf-8'))
        self.payload = (data / 'resources.bin').read_bytes()
        if sha256(self.payload) != self.meta['keyed_sha256']:
            raise ValueError(f'keyed/{edition}.bin is damaged')

    def open(self, sources):
        return unseal(self.keyed, self.payload, sources.__getitem__, sources)

    def layer(self, work, phoenix, edition, diag, ex, ex_equates):
        layer = self.meta['layer']
        if (phoenix, edition, diag, ex) != (True, self.edition, False, True):
            raise ValueError('the kit builds the Phoenix EX build of its edition only')
        if {k: f'{v:#x}' for k, v in ex_equates.items()} != layer['equates']:
            raise ValueError("the scenes built from your disc are laid out differently from the kit's layer; check the disc image")
        blob = (self.data / 'kitdata' / layer['file']).read_bytes()
        if sha256(blob) != layer['sha256']:
            raise ValueError(f"kitdata/{layer['file']} is damaged")
        return (blob, {k: int(v, 16) for k, v in layer['entries'].items()})

    def pieces(self, edition):
        from scene_recipes import pieces
        return pieces(edition, self.discs, self.roms, self.work)

    def regulation_tv(self, scenes, first, region):
        reg = self.meta['regulation']
        if f'{first:#x}' != reg['first_code'] or region != reg['region']:
            raise ValueError("the scenes built from your disc end at a different tile from the kit's")
        items = self.open({'scenes data.bin': scenes['data.bin'], 'scenes art.bin': scenes['art.bin']})
        tiles = [(int(code, 16), items[f'regulation tile {code}']) for code in reg['tiles']]
        table = b''.join((items[f'regulation {name}'] for name in reg['table']))
        return (tiles, table, reg['receipt'])

    def artwork_asset(self, region):
        doc = json.loads(json.dumps(self.meta['artwork']['skeleton']))
        items = self.open({'stock graphics': bytes(region)})
        for row in doc['tiles']:
            row['hex'] = items[f"artwork {row['name']}"].hex()
        return json.dumps(doc, indent=2) + '\n'

    def disc_image(self, edition):
        """The edition's disc's data track (USA: the US disc; Japan and English: the Japanese disc)."""
        region = EDITIONS[edition]
        disc = self.discs.get(region)
        if disc is None:
            raise ValueError(f"the {edition} build needs the {('Japanese' if region == 'jp' else 'USA')} disc")
        return data_track(disc)

    def disc_sources(self, img):
        """The disc files Time Attack's keyed items are tied to (console_disc_sources)."""
        return console_disc_sources(img)

    def console_layer(self, raw, edition, img):
        """(blob, entries, symbols): the shipped Console layer with its disc data unsealed."""
        meta = self.meta['console']
        blob = bytearray((self.data / 'kitdata' / meta['file']).read_bytes())
        if sha256(bytes(blob)) != meta['shipped_sha256']:
            raise ValueError(f"kitdata/{meta['file']} is damaged")
        items = self.open(self.disc_sources(img))
        for span in meta['spans']:
            data = items[span['item']]
            if len(data) != span['end'] - span['start']:
                raise ValueError(f"{span['item']}: wrong length")
            blob[span['start']:span['end']] = data
        if sha256(bytes(blob)) != meta['sha256']:
            raise ValueError('the Console layer built from your disc differs from the known build')
        return (bytes(blob), {k: int(v, 16) for k, v in meta['entries'].items()}, {k: int(v, 16) for k, v in meta['symbols'].items()})

    def ta_graphics(self, img):
        """Time Attack's [(graphics address, bytes)], unsealed from the user's disc files."""
        items = self.open(self.disc_sources(img))
        return [(int(row['address'], 16), items[row['item']]) for row in self.meta['ta_graphics']]

    def sound(self, rompaths, effect_gains, opening):
        import ff_sound as fs
        import sound_members
        sound = self.meta['sound']
        z80, oki = fs.load(rompaths)
        items = self.open({'sound program': z80, 'sound samples': oki})
        products = {'renders': {decode(r['key']): {'loop': decode(r['loop']), 'info': decode(r['info']), 'pcm8': items[r['item']]} for r in sound['renders']}, 'okis': {o['phrase']: {'coarse': o['coarse'], 'samples': o['samples'], 'pcm8': items[o['item']]} for o in sound['okis']}, **{k: decode(sound[k]) for k in ('warm', 'site_voices', 'warm_counts', 'long_phrases', 'scale')}}
        return sound_members.from_products(rompaths, products, effect_gains, opening)

def console_disc_sources(img):
    """{source: bytes} of the disc files the Console layer's keyed items are tied to."""
    if str(FFCD / 'tools') not in sys.path:
        sys.path.insert(0, str(FFCD / 'tools'))
    import time_attack_rules as rules
    get = rules.iso_files(str(img))
    files = {name: get(name) for name in ('PRT_1.BIN', 'GRT_1.BIN', 'GRT_2.BIN', 'GRT_3.BIN', 'MAINSYS.BIN')}
    return {'disc PRT_1.BIN': files['PRT_1.BIN'], 'disc GRT_1.BIN': files['GRT_1.BIN'], 'disc arenas': files['GRT_1.BIN'] + files['GRT_2.BIN'] + files['GRT_3.BIN'] + files['MAINSYS.BIN']}

def builder():
    """The builder's modules, from SCRIPTS (never a different copy on the path)."""
    if str(SCRIPTS) not in sys.path:
        sys.path.insert(0, str(SCRIPTS))
    import build_m1_spike as spike
    if Path(spike.__file__).resolve().parent != SCRIPTS.resolve():
        raise ImportError(f'build_m1_spike resolved to {spike.__file__}, not {SCRIPTS}')
    return spike

def build(edition, romsets, discs, work, data=None):
    """{member: bytes}: the edition's set, every member checked against its pinned SHA-256. romsets:"""
    if edition not in EDITIONS:
        raise ValueError(f'edition must be one of {sorted(EDITIONS)}')
    data = Path(data) if data else HERE
    work = Path(work)
    work.mkdir(parents=True, exist_ok=True)
    roms = write_romsets(romsets, work / 'roms')
    spike = builder()
    kit = Kit(edition, data, work, roms, discs)
    if kit.meta['release_date'] != spike.EX_BOOT_DATE:
        raise ValueError(f"kit data for the {kit.meta['release_date']} build, builder at {spike.EX_BOOT_DATE}")
    with disc_workspace(work):
        spike.build([roms], work / 'build', phoenix=True, edition=edition, ex=True, kit=kit)
    with zipfile.ZipFile(work / 'build' / 'rom' / 'sfa3ud.zip') as z:
        members = {name: z.read(name) for name in z.namelist()}
    pinned = kit.meta['members']
    if sorted(members) != sorted(pinned):
        raise ValueError(f"the set's members differ from the kit's: {sorted(set(members) ^ set(pinned))}")
    for name in sorted(members):
        if sha256(members[name]) != pinned[name]:
            raise ValueError(f'{name} does not match the known build (a romset or disc differs from the expected dump)')
    return members
