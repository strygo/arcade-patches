#!/usr/bin/env python3
"""Final Fight EX (CPS-2): the public kit's build of one edition (KIT.md).

The kit tool (arcade-patches/tools/ffightcps2_builder/apply.py) calls build(edition, romsets, discs,
work). It writes the user's romsets as canonical archives, then runs this repository's builder
(build_m1_spike.build) in kit mode: the builder's own Python over the user's romsets, and CPS1 Final
Fight EX's disc chain over the user's disc for the scene pieces. The kit object below supplies what
cannot run there in plain Python, from the kit data (stage_public_kit.py writes it):

- the assembled layer (our own code), after checking that the user's scene pieces give the layer the
  equates it was assembled with;
- the sound members' floating-point products: each FM render and OKI phrase sample keyed to the voice
  patch or ADPCM phrase it came from, and their loops and analysis;
- REGULATION's other-region picture: each tile keyed to the user's own scene tile in the screen cell
  where it first shows, the table's events and cell lists to the user's script records over those
  events, each palette set to the user's palette block it amends;
- the three Capcom Arcade Stadium tiles, each keyed to the stock tile it replaces;
- the Console layer (Console mode and Time Attack, console_compose.py), shipped assembled with its
  disc data blank: Time Attack's spawn script keyed to the user's PRT_1.BIN, its RESULT palettes to
  GRT_1.BIN and its arena tables to the three arenas' GRT files and MAINSYS.BIN; and Time Attack's
  RESULT figures and arena tiles, keyed to the same files.

Every member of the built set is then checked against its pinned SHA-256. The kit stages the
repository's subtree (inventory.json) beside this file; in the repository it runs from
backports/ffightcps2/kit.

    ffex_kit.py --edition english --romsets DIR --disc-jp JP.img --work WORK --out SET.zip
"""
from __future__ import annotations

# BEGIN ARCADE PYTHON BOOTSTRAP
import sys as _arcade_sys
from pathlib import Path as _ArcadePath
_arcade_sys.path.insert(0, str(_ArcadePath(__file__).resolve().parents[0]))
from kit_python import bootstrap as _arcade_bootstrap
_arcade_bootstrap()
# END ARCADE PYTHON BOOTSTRAP

import argparse
import hashlib
import json
from pathlib import Path
import sys
import zipfile

HERE = Path(__file__).resolve().parent
# The staged kit carries the repository's subtree beside this file; the repository has it at its root.
ROOT = HERE if (HERE / "backports" / "ffightcps2").is_dir() else HERE.parents[2]
SCRIPTS = ROOT / "backports" / "ffightcps2" / "scripts"
FFCD = ROOT / "backports" / "ffightcd"
EDITIONS = {"usa": "us", "japan": "jp", "english": "jp"}
ROMSETS = ("ffight", "ffightu", "ffightj", "sfa3u")
QSOUND_FIRMWARE = "dl-1425.bin"
sys.path.insert(0, str(HERE))
from keyed import sha256, unseal    # noqa: E402


def encode(value):
    """Kit data as JSON, keeping what JSON loses: tuples, sets, and dicts whose keys are not strings."""
    if isinstance(value, tuple):
        return {"__tuple__": [encode(v) for v in value]}
    if isinstance(value, (set, frozenset)):
        return {"__set__": sorted((encode(v) for v in value), key=json.dumps)}
    if isinstance(value, list):
        return [encode(v) for v in value]
    if isinstance(value, dict):
        if all(isinstance(k, str) and not k.startswith("__") for k in value):
            return {k: encode(v) for k, v in value.items()}
        return {"__items__": [[encode(k), encode(v)] for k, v in value.items()]}
    if value is None or isinstance(value, (bool, str)):
        return value
    if isinstance(value, int):
        return int(value)
    if isinstance(value, float):
        return float(value)
    if hasattr(value, "item"):              # a numpy scalar
        return encode(value.item())
    raise TypeError(f"kit data cannot hold {type(value).__name__}")


def decode(value):
    if isinstance(value, list):
        return [decode(v) for v in value]
    if isinstance(value, dict):
        if "__tuple__" in value:
            return tuple(decode(v) for v in value["__tuple__"])
        if "__set__" in value:
            return {decode(v) for v in value["__set__"]}
        if "__items__" in value:
            return {decode(k): decode(v) for k, v in value["__items__"]}
        return {k: decode(v) for k, v in value.items()}
    return value


def data_track(disc):
    """The image holding the disc's first track as CPS1 EX's chain reads it (2352-byte MODE1 sectors
    from the image's start): a .bin or .img as given, or track 1 of a .cue, a CD .chd or a .zip/.7z
    holding one (CPS+'s disc reader, as the music packs read the disc)."""
    disc = Path(disc)
    if disc.suffix.lower() in (".bin", ".img"):
        return disc
    if str(ROOT) not in sys.path:
        sys.path.insert(0, str(ROOT))
    from cpsplus.pack import discsrc
    cue = discsrc.descriptor(disc)
    if cue.suffix.lower() != ".cue":
        raise ValueError(f"{disc.name}: give the disc's .cue sheet")
    tracks, _ = discsrc.extract_cdda.parse_cue(cue)
    number, mode, image, _, start, _ = tracks[0]
    if number != 1 or mode.upper() != "MODE1/2352" or start != 0:
        raise ValueError(f"{cue.name}: track 1 is not a MODE1/2352 data track at the start of its image")
    return image


def write_romsets(romsets, folder):
    """Canonical archives of the user's romsets ({set: {member: bytes}}); the QSound firmware joins
    sfa3u when the user's sfa3u leaves it out."""
    folder.mkdir(parents=True, exist_ok=True)
    for name in ROMSETS:
        if name not in romsets:
            raise ValueError(f"the {name} romset is missing")
        members = dict(romsets[name])
        if name == "sfa3u" and QSOUND_FIRMWARE not in members:
            firmware = romsets.get("qsound", {}).get(QSOUND_FIRMWARE)
            if firmware is None:
                raise ValueError(f"sfa3u has no {QSOUND_FIRMWARE} and no QSound firmware was found")
            members[QSOUND_FIRMWARE] = firmware
        with zipfile.ZipFile(folder / f"{name}.zip", "w", zipfile.ZIP_DEFLATED) as z:
            for member in sorted(members):
                z.writestr(member, members[member])
    return folder


class Kit:
    """Kit mode's sites for build_m1_spike.build (its kit argument)."""

    def __init__(self, edition, data, work, roms, discs):
        self.edition, self.data, self.work, self.roms, self.discs = edition, data, work, roms, discs
        self.meta = json.loads((data / "kitdata" / f"{edition}.json").read_text())
        if self.meta["edition"] != edition:
            raise ValueError(f"kit data for {self.meta['edition']}, not {edition}")
        self.keyed = json.loads((data / "keyed" / f"{edition}.json").read_text())
        self.payload = (data / "keyed" / f"{edition}.bin").read_bytes()
        if sha256(self.payload) != self.meta["keyed_sha256"]:
            raise ValueError(f"keyed/{edition}.bin is damaged")

    def open(self, sources):
        """The keyed items whose counterparts come from sources ({source: bytes})."""
        items = [i for i in self.keyed["items"] if i["counterpart"]["source"] in sources]
        return unseal({"schema": self.keyed["schema"], "items": items}, self.payload, sources.__getitem__)

    def layer(self, work, phoenix, edition, diag, ex, ex_equates):
        layer = self.meta["layer"]
        if (phoenix, edition, diag, ex) != (True, self.edition, False, True):
            raise ValueError("the kit builds the Phoenix EX build of its edition only")
        if {k: f"{v:#x}" for k, v in ex_equates.items()} != layer["equates"]:
            raise ValueError("the scenes built from your disc are laid out differently from the kit's layer; "
                             "check the disc image")
        blob = (self.data / "kitdata" / layer["file"]).read_bytes()
        if sha256(blob) != layer["sha256"]:
            raise ValueError(f"kitdata/{layer['file']} is damaged")
        return blob, {k: int(v, 16) for k, v in layer["entries"].items()}

    def pieces(self, edition):
        import ex_scenes
        region = EDITIONS[edition]
        disc = self.discs.get(region)
        if disc is None:
            raise ValueError(f"the {edition} build needs the {'Japanese' if region == 'jp' else 'USA'} disc")
        # The chain's stages are separate interpreters: paths.json beside it names the disc and romsets
        # (backports/ffightcd/ffcd/disc.py). Any paths.json there is put back afterwards.
        config = FFCD / "paths.json"
        before = config.read_bytes() if config.exists() else None
        config.write_text(json.dumps({region: str(data_track(disc).resolve()), "romset": str(self.roms.resolve())}))
        try:
            out = ex_scenes.build_pieces(region, self.work / "scenes", captions=ex_scenes.captions_for(edition),
                                         romset=self.roms)
        finally:
            if before is None:
                config.unlink()
            else:
                config.write_bytes(before)
        return ex_scenes.load(out, "kit")

    def regulation_tv(self, scenes, first, region):
        reg = self.meta["regulation"]
        if f"{first:#x}" != reg["first_code"] or region != reg["region"]:
            raise ValueError("the scenes built from your disc end at a different tile from the kit's")
        items = self.open({"scenes data.bin": scenes["data.bin"], "scenes art.bin": scenes["art.bin"]})
        tiles = [(int(code, 16), items[f"regulation tile {code}"]) for code in reg["tiles"]]
        table = b"".join(items[f"regulation {name}"] for name in reg["table"])
        return tiles, table, reg["receipt"]

    def artwork_asset(self, region):
        doc = json.loads(json.dumps(self.meta["artwork"]["skeleton"]))
        items = self.open({"stock graphics": bytes(region)})
        for row in doc["tiles"]:
            row["hex"] = items[f"artwork {row['name']}"].hex()
        return json.dumps(doc, indent=2) + "\n"

    def disc_image(self, edition):
        """The edition's disc's data track (USA: the US disc; Japan and English: the Japanese disc)."""
        region = EDITIONS[edition]
        disc = self.discs.get(region)
        if disc is None:
            raise ValueError(f"the {edition} build needs the {'Japanese' if region == 'jp' else 'USA'} disc")
        return data_track(disc)

    def disc_sources(self, img):
        """The disc files Time Attack's keyed items are tied to (console_disc_sources)."""
        return console_disc_sources(img)

    def console_layer(self, raw, edition, img):
        """(blob, entries, symbols): the shipped Console layer with its disc data unsealed."""
        meta = self.meta["console"]
        blob = bytearray((self.data / "kitdata" / meta["file"]).read_bytes())
        if sha256(bytes(blob)) != meta["shipped_sha256"]:
            raise ValueError(f"kitdata/{meta['file']} is damaged")
        items = self.open(self.disc_sources(img))
        for span in meta["spans"]:
            data = items[span["item"]]
            if len(data) != span["end"] - span["start"]:
                raise ValueError(f"{span['item']}: wrong length")
            blob[span["start"]:span["end"]] = data
        if sha256(bytes(blob)) != meta["sha256"]:
            raise ValueError("the Console layer built from your disc differs from the known build")
        return bytes(blob), {k: int(v, 16) for k, v in meta["entries"].items()}, \
            {k: int(v, 16) for k, v in meta["symbols"].items()}

    def ta_graphics(self, img):
        """Time Attack's [(graphics address, bytes)], unsealed from the user's disc files."""
        items = self.open(self.disc_sources(img))
        return [(int(row["address"], 16), items[row["item"]]) for row in self.meta["ta_graphics"]]

    def sound(self, rompaths, effect_gains, opening):
        import ff_sound as fs
        import sound_members
        sound = self.meta["sound"]
        z80, oki = fs.load(rompaths)
        items = self.open({"sound program": z80, "sound samples": oki})
        products = {
            "renders": {decode(r["key"]): {"loop": decode(r["loop"]), "info": decode(r["info"]),
                                           "pcm8": items[r["item"]]} for r in sound["renders"]},
            "okis": {o["phrase"]: {"coarse": o["coarse"], "samples": o["samples"], "pcm8": items[o["item"]]}
                     for o in sound["okis"]},
            **{k: decode(sound[k]) for k in ("warm", "site_voices", "warm_counts", "long_phrases", "scale")},
        }
        return sound_members.from_products(rompaths, products, effect_gains, opening)


def console_disc_sources(img):
    """{source: bytes} of the disc files the Console layer's keyed items are tied to."""
    if str(FFCD / "tools") not in sys.path:
        sys.path.insert(0, str(FFCD / "tools"))
    import time_attack_rules as rules
    get = rules.iso_files(str(img))
    files = {name: get(name) for name in ("PRT_1.BIN", "GRT_1.BIN", "GRT_2.BIN", "GRT_3.BIN", "MAINSYS.BIN")}
    return {"disc PRT_1.BIN": files["PRT_1.BIN"], "disc GRT_1.BIN": files["GRT_1.BIN"],
            "disc arenas": files["GRT_1.BIN"] + files["GRT_2.BIN"] + files["GRT_3.BIN"] + files["MAINSYS.BIN"]}


def builder():
    """The builder's modules, from SCRIPTS (never a different copy on the path)."""
    if str(SCRIPTS) not in sys.path:
        sys.path.insert(0, str(SCRIPTS))
    import build_m1_spike as spike
    if Path(spike.__file__).resolve().parent != SCRIPTS.resolve():
        raise ImportError(f"build_m1_spike resolved to {spike.__file__}, not {SCRIPTS}")
    return spike


def build(edition, romsets, discs, work, data=None):
    """{member: bytes}: the edition's set, every member checked against its pinned SHA-256. romsets:
    {set: {member: bytes}} (ffight, ffightu, ffightj, sfa3u, and qsound when sfa3u lacks the
    firmware); discs: {"jp": path or None, "us": path or None}; data: the kit data's folder (HERE)."""
    if edition not in EDITIONS:
        raise ValueError(f"edition must be one of {sorted(EDITIONS)}")
    data = Path(data) if data else HERE
    work = Path(work)
    work.mkdir(parents=True, exist_ok=True)
    roms = write_romsets(romsets, work / "roms")
    spike = builder()
    kit = Kit(edition, data, work, roms, discs)
    if kit.meta["release_date"] != spike.EX_BOOT_DATE:
        raise ValueError(f"kit data for the {kit.meta['release_date']} build, builder at {spike.EX_BOOT_DATE}")
    spike.build([roms], work / "build", phoenix=True, edition=edition, ex=True, kit=kit)
    with zipfile.ZipFile(work / "build" / "rom" / "sfa3ud.zip") as z:
        members = {name: z.read(name) for name in z.namelist()}
    pinned = kit.meta["members"]
    if sorted(members) != sorted(pinned):
        raise ValueError(f"the set's members differ from the kit's: {sorted(set(members) ^ set(pinned))}")
    for name in sorted(members):
        if sha256(members[name]) != pinned[name]:
            raise ValueError(f"{name} does not match the known build (a romset or disc differs from the "
                             "expected dump)")
    return members


def self_test():
    value = {((3, -1), 2): {"loop": (10, 20), "info": {"peak": 0.5, "notes": [1, 2]}}, "x": None, 5: [1.25],
             "s": {(1, 2), (0, 5)}}
    assert decode(json.loads(json.dumps(encode(value)))) == value
    assert decode(encode({"__tuple__": 1})) == {"__tuple__": 1}
    print("self-test passed")


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--self-test", action="store_true")
    parser.add_argument("--edition", choices=sorted(EDITIONS))
    parser.add_argument("--romsets", type=Path, help="a folder of the romsets as .zip archives")
    parser.add_argument("--disc-jp", type=Path)
    parser.add_argument("--disc-us", type=Path)
    parser.add_argument("--work", type=Path)
    parser.add_argument("--data", type=Path, help="the kit data's folder (default: beside this file)")
    parser.add_argument("--out", type=Path, help="write the set here")
    args = parser.parse_args(argv)
    if args.self_test:
        self_test()
        return 0
    if not (args.edition and args.romsets and args.work and args.out):
        parser.error("give --edition, --romsets, --work and --out")
    romsets = {}
    for name in (*ROMSETS, "qsound"):
        path = args.romsets / f"{name}.zip"
        if path.is_file():
            with zipfile.ZipFile(path) as z:
                romsets[name] = {m: z.read(m) for m in z.namelist()}
    members = build(args.edition, romsets, {"jp": args.disc_jp, "us": args.disc_us}, args.work, args.data)
    with zipfile.ZipFile(args.out, "w", zipfile.ZIP_DEFLATED) as z:
        for name in sorted(members):
            z.writestr(name, members[name])
    print(json.dumps({"edition": args.edition, "members": {n: sha256(d) for n, d in sorted(members.items())}},
                     indent=1))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
