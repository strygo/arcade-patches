import wave
from resource_recipe import require, sha
def read_pcm(path):
    with wave.open(str(path), 'rb') as w:
        require((w.getframerate(), w.getnchannels(), w.getsampwidth()) == (44100, 2, 2),
                'Expected original 44.1 kHz stereo CD audio')
        data = w.readframes(w.getnframes())
        require(len(data) == w.getnframes() * 4, 'Truncated CD audio')
    return data
def pcm(row, source):
    require(sha(source) == row['source_sha256'], 'Original CD audio track differs')
    data = source
    if row['cut'] is not None:
        data, _ = arcade_cut(data, 2, 44100, *row['cut'], weights=row.get('splice_weights'))
    elif row['lead']:
        data = bytes(row['lead'] * 4) + data
    require(sha(data) == row['pcm_sha256'], 'Prepared audio PCM differs')
    return data
def arcade_cut(pcm, ch, rate, lead_samples, cut_at, bars, bpm, xfade, *, weights=None):
    from pcm_splice import arcade_cut as splice
    return splice(pcm, ch, rate, lead_samples, cut_at, bars, bpm, xfade, weights=weights)
