"""Bundled standard-library source staging and native output checks."""
import contextlib
import hashlib
import json
import os
from pathlib import Path
import runpy
import shutil
import sys
import tempfile
import zipfile

def require(ok, message):
    if not ok:
        raise ValueError(message)

def sha(data):
    return hashlib.sha256(data).hexdigest()

def check(path, spec):
    if 'members' in spec:
        with zipfile.ZipFile(path) as archive:
            require(len(archive.namelist()) == len(set(archive.namelist())) and set(archive.namelist()) == set(spec['members']), 'Native ZIP extent differs')
            for name, expected in spec['members'].items():
                value = hashlib.sha256()
                with archive.open(name) as stream:
                    for block in iter(lambda: stream.read(1024 ** 2), b''):value.update(block)
                require(value.hexdigest() == expected, 'Native ZIP member differs: ' + name)
    else:
        require(file_sha(Path(path)) == spec['sha256'], 'Native output content differs: ' + Path(path).name)

def source(binding):
    from kit_collection import read_binding
    return read_binding(binding)

def write_zip(path, members):
    path.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as archive:
        for name, data in sorted(members.items()):
            item = zipfile.ZipInfo(name, (1980, 1, 1, 0, 0, 0))
            item.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(item, data)

def execute(kit, args):
    sys.path.insert(0, str(kit))
    sys.argv = [str(kit / "apply.py"), *map(str, args)]
    try:
        runpy.run_path(str(kit / "apply.py"), run_name="__main__")
    except SystemExit as exc:
        require(exc.code in (None, 0), f"Published installer exited {exc.code}")

def file_sha(path):
    value = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            value.update(block)
    return value.hexdigest()

def inventory(root):
    return {p.relative_to(root).as_posix(): file_sha(p) for p in sorted(root.rglob("*")) if p.is_file()}

def verify_raw(raw, expected, firmware):
    actual = {p.relative_to(raw).as_posix() for p in raw.rglob("*") if p.is_file()}
    require(actual == set(expected), "Native installer output extent differs from independent qualification")
    for name, spec in expected.items():
        if not firmware and "members" in spec:
            spec = {"members": {n: h for n, h in spec["members"].items() if n != "dl-1425.bin"}}
        check(raw / name, spec)

def canonicalize_mras(root, expected):
    """Accept native text newlines only when they recover the pinned MRA bytes."""
    for name, spec in expected.items():
        if name.lower().endswith(".mra") and "sha256" in spec:
            path = root / name
            data = path.read_bytes()
            if sha(data) != spec["sha256"]:
                canonical = data.replace(b"\r\n", b"\n")
                require(sha(canonical) == spec["sha256"], "MRA content differs from independent qualification")
                path.write_bytes(canonical)

def stage_disc(bindings, files, cue, destination):
    stage_components(bindings, files, destination)
    path = destination / 'disc.cue'
    path.write_bytes(cue.encode('utf-8'))
    return path

def stage_components(bindings, files, destination):
    """Stream complete, content-bound components without assuming a CD layout."""
    destination.mkdir(parents=True, exist_ok=True)
    for name, key in files.items():
        require(Path(name).name == name and name not in ('.', '..', 'disc.cue'), 'Unsafe CD component name')
        binding = bindings[key]
        original = Path(binding['path'])
        before = original.stat()
        temporary = None
        try:
            with contextlib.ExitStack() as stack:
                if 'member' in binding:
                    archive = stack.enter_context(zipfile.ZipFile(original))
                    source = stack.enter_context(archive.open(binding['member']))
                else:
                    source = stack.enter_context(original.open('rb'))
                output = stack.enter_context(tempfile.NamedTemporaryFile(dir=destination, prefix='.disc-', delete=False))
                temporary = Path(output.name)
                digest, size = hashlib.sha256(), 0
                for block in iter(lambda: source.read(1024 * 1024), b''):
                    output.write(block); digest.update(block); size += len(block)
            after = original.stat()
            require((before.st_ino, before.st_size, before.st_mtime_ns) == (after.st_ino, after.st_size, after.st_mtime_ns) and
                    size == binding['size'] and digest.hexdigest() == binding['sha256'], 'Source changed since discovery')
            os.replace(temporary, destination / name)
        finally:
            if temporary is not None:
                temporary.unlink(missing_ok=True)


class Directory:
    """The producer's own kit data, without a second downloaded recipe."""
    def __init__(self, root):self.root = Path(root)
    def read(self, name):
        relative(name)
        return (self.root / name).read_bytes()
    def namelist(self):return sorted(p.relative_to(self.root).as_posix() for p in self.root.rglob('*') if p.is_file())


def relative(name):
    from kit_collection import safe_name
    return safe_name(name)


def file_contract(value, output=False):
    import re
    if 'members' in value:
        require(output and value['members'] and all(re.fullmatch('[0-9a-f]{64}', v) for v in value['members'].values()), 'Invalid native member contract')
    elif 'any_of' in value:
        require(output and value['any_of'], 'Invalid native alternatives')
        for variant in value['any_of']:file_contract(variant, output=True)
    else:
        require(re.fullmatch('[0-9a-f]{64}', value.get('sha256', '')), 'Native file needs SHA-256')
        require(output or type(value.get('size')) is int and value['size'] >= 0, 'Native input needs a size')


def region_argument(value):
    aliases = {'usa': 'us', 'japan': 'jp', 'europe': 'eu', 'asia': 'asia', 'world': 'world', 'hispanic': 'hispanic',
               'us': 'us', 'jp': 'jp', 'eu': 'eu'}
    key = str(value).strip().lower();require(key in aliases, 'Unknown native region: ' + key);return aliases[key]


def output_inventory(root):
    result = {}
    for path in sorted(Path(root).rglob('*')):
        if not path.is_file():continue
        name = path.relative_to(root).as_posix();relative(name)
        if path.suffix == '.zip':
            with zipfile.ZipFile(path) as archive:
                require(len(archive.namelist()) == len(set(archive.namelist())), 'Duplicate native output ZIP member')
                members = {}
                for member in archive.namelist():
                    relative(member);value = hashlib.sha256()
                    with archive.open(member) as stream:
                        for block in iter(lambda: stream.read(1024 ** 2), b''):value.update(block)
                    members[member] = value.hexdigest()
                result[name] = {'members': members}
        else:result[name] = {'sha256': file_sha(path)}
    require(result, 'Empty native producer output tree');return result
