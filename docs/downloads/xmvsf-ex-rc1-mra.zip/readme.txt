X-Men vs. Street Fighter EX · Enhanced version
==============================================

Version:  rc1 (2026-11-18)
Target:   MAME set 'xmvsfj' (X-Men vs. Street Fighter (Japan 970113))
Hardware: Capcom CPS-2
Patch by: Steve Gordon (https://x.com/strygo)
Website:  https://arcadepatches.com/xmvsf-ex/

ABOUT THIS PROJECT

X-Men vs. Street Fighter EX keeps the arcade tag-team game and adds a home-
style Console mode. Start opens a title menu with Arcade, Versus, Training and
Options. Versus supports a friend or the computer, with handicap and stage
choices and win totals that carry through rematches. Training offers dummy,
guard, gauge, speed and stage controls.

Apocalypse is fully playable: he fights alone in his own arena with his six
native commands, has a seven-fight Arcade route with Magneto and M. Bison as
the final opponents, and gets his own ending. Akuma and Apocalypse have
visible places on character select. The other fighters get the Saturn
version's two extra colors, carried through portraits and effects, and mirror
matches keep both sides' colors distinct. Holding Start on Chun-Li previews
her alternate outfit.

The USA build includes the English Restoration: win quotes translated from the
Japanese, restored Apocalypse conversations and complete endings. The Japan
build keeps the original Japanese text and adds Japanese for Apocalypse's
final conversation, his ending and the service menus. Both builds share the
Japanese release's default settings, eight Turbo levels and the original
Normal speed. Console mode needs no credits; the service menu also retains
ordinary Arcade operation.

This is a release candidate.

WHAT'S CHANGED

  - Fully playable Apocalypse with his six native commands, a solo Arcade
    route with Magneto and M. Bison as the final opponents, and his own
    ending; visible Akuma and Apocalypse select spaces
  - Console mode with Arcade, Versus, Training and Options; MiSTer starts in
    Console mode
  - Updated stage select in Versus and Training, with previews and inline
    handicap
  - Two extra Saturn colors for the ordinary fighters, with matching portraits
    and effects, and correct colors in mirror matches; select with HP or HK
  - Full English Restoration content in the USA build: win quotes translated
    from the Japanese, restored Apocalypse conversations, complete endings and
    speaker labels
  - Pause with Coin or a Start hold, immediate Quit to the title, and Options
    settings that persist
  - Japan build with the original Japanese text, a Japanese Apocalypse
    conversation and ending, and Japanese service menus
  - Hold Start on Chun-Li for about two seconds to preview her alternate
    outfit; eight Turbo levels plus Normal

MISTER SETUP

1. Copy the _Arcade/ folder from this download to the root of your MiSTer SD
   card (the MRAs land in _Arcade/_Arcade Patches/_Enhanced Versions/), or just the MRAs you want:
       "X-Men Vs. Street Fighter EX (USA).mra"
       "X-Men Vs. Street Fighter EX (Japan).mra"
2. Have the stock, unmodified romset at games/mame/xmvsfj.zip
   (split sets also need the parent and QSound ZIPs named in the MRA).
3. You need Jotego's jtcps2 core; the standard MiSTer downloader /
   update_all installs it automatically.

Each MRA references your original romset and applies the patch in
memory while the game loads. Nothing on your SD card is modified. Each
build keeps its own settings and saves under its own setname:
    USA              xmvsfex
    Japan            xmvsfexj

LEGAL

This is a free, unofficial fan patch. It is not affiliated with or endorsed
by Capcom. All game titles, characters, and artwork remain the property of
their respective owners. You must own the game to use this patch. Do not
sell this patch or distribute it applied to a ROM image.
