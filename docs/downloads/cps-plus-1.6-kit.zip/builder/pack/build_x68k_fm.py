"""Build the SSF2 X68000 FM soundtrack pack.

The X68000 port of SSF2 carries two versions of every song -- an FM bank for
the machine's own YM2151 + OKIM6258 and a MIDI bank for an external module --
and the two pair up song for song.  The MIDI pack
(build_ssf2_x68k_midi.py) holds the reviewed arcade command join and each
song's loop/one-shot decision; this FM pack reuses both unchanged and puts
the FM performance in their place.  Like every ssf2_<source> pack it serves
the whole SSF2 family (pack/ssf2_family.py).

SF2CE and Daimakaimura got the same treatment and were retired on
2026-09-28: their CPS1 boards play the same YM2151, and the X68000
ports replay the arcade score closely enough to count as renders of the
original hardware. GAMES is a table so another port can join.

Audio: ``tools/capture_x68k_fm_mame.py --all-songs``, which boots the
original disks in MAME and records each song through the game's own music
test.  Captures are deterministic (fresh SRAM and a pinned RTC per boot), so
``manifests/x68k_fm_captures.tsv`` pins every one by SHA-256 together with
its measured loop.  MAME keeps some levels in floating point, so its macOS
(arm64) and Windows (x64) builds record a few samples one step apart
(inaudible): each build has its own rows (``build`` column) and the pack
builds from whichever set the captures match, to its own pack hash.  A looped capture holds the intro and three passes, with
its loop over a measured pass; the pack keeps that period exactly, shifted
one second earlier on the 32-sample ADX grid so a real continuation remains
for the CPS+ crossfade, as the MIDI packs do.

Run:
  python3 build_pack.py x68k-fm --game ssf2 --capture-dir <dir>
  python3 build_pack.py x68k-fm --game ssf2 --capture-dir <dir> --pin [--build windows]
      (rewrite this game's rows for that build in the pin manifest from the
      capture sidecars)
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import wave
from dataclasses import dataclass
from pathlib import Path
from types import ModuleType

from . import adxcodec, ssf2_family
from . import build_ssf2_x68k_midi as midi_ssf2
from .adxencode import encode_adx_track
from .build_common import MANIFESTS, PACKS_DIR, PKG_ROOT
from .format import (CODEC_ADX, VERB_NONE, VERB_PLAY, PackReader, PackWriter,
                     TrackMeta, TriggerRow)

PINS_TSV = MANIFESTS / "x68k_fm_captures.tsv"
CAPTURE_ROOT = PKG_ROOT / "work" / "x68000" / "capture" / "fm"
RATE = 48_000
CHANNELS = 2
XFADE_SAMPLES = RATE                         # one second, 32-sample aligned
ADX_GRID = 32


@dataclass(frozen=True)
class Game:
    capture: str          # the extraction/capture game name
    pack: str
    title: str
    midi: ModuleType
    trig_gain: int


# Gain: EBU R128 against isolated native board cues (tools/loudness_match.py
# --native-dir on tools/qsound_isolate.py ssf2u renders), median over every
# mapped pair, 2026-09-28: +0.7 LU over the board (61 pairs, IQR 2.5), 0x75.
GAMES = {
    "ssf2": Game(
        "ssf2", "ssf2_x68k_fm.cpk",
        "Super Street Fighter II: The New Challengers (X68000 FM Soundtrack)",
        midi_ssf2, 0x75),
}


@dataclass(frozen=True)
class Pin:
    sha256: str
    frames: int
    loop_start: int | None
    loop_end: int | None
    status: str


def looped_songs(key: str) -> set[str]:
    """The songs the MIDI pack loops -- the reviewed per-song decision."""
    return {song for song, row in GAMES[key].midi.load_audio_manifest().items()
            if row.loops}


def song_of_command(key: str, music: list) -> dict[int, str]:
    """The MIDI builder's own trigger rule, applied to its reviewed map."""
    out = {row.command: row.song for row in music
           if row.in_game and row.command not in midi_ssf2.NATIVE_RESTORE_CMDS}
    for cmd, src in ssf2_family.TURBO_STAND_INS.items():
        out[cmd] = out[src]
    return out


def writer_for(key: str, title: str) -> PackWriter:
    proto = ssf2_family.PROTOCOL
    ssf2_family.check_protocol(proto)
    return PackWriter(proto, title=title, trigger_rows=midi_ssf2.TRIGGER_ROWS,
                      default_rate=RATE, xfade_samples=XFADE_SAMPLES)


def _rows(path: Path):
    with path.open(newline="", encoding="utf-8") as f:
        yield from csv.DictReader(
            (line for line in f if line.strip() and not line.startswith("#")),
            delimiter="\t")


def _opt(value: str) -> int | None:
    return None if value in ("", "-") else int(value)


DEFAULT_BUILD = "mac"


def _build_of(raw: dict) -> str:
    return raw.get("build") or DEFAULT_BUILD


def builds_for(key: str, path: Path = PINS_TSV) -> list[str]:
    game = GAMES[key].capture
    seen: list[str] = []
    for raw in _rows(path):
        if raw["game"] == game and _build_of(raw) not in seen:
            seen.append(_build_of(raw))
    return seen


def load_pins(key: str, path: Path = PINS_TSV, build: str = DEFAULT_BUILD) -> dict[str, Pin]:
    game = GAMES[key].capture
    out: dict[str, Pin] = {}
    for raw in _rows(path):
        if raw["game"] != game or _build_of(raw) != build:
            continue
        if raw["song"] in out:
            raise ValueError(f"{game} {raw['song']}: duplicate pin")
        out[raw["song"]] = Pin(raw["sha256"], int(raw["frames"]),
                               _opt(raw["loop_start"]), _opt(raw["loop_end"]),
                               raw["status"])
    return out


PIN_HEADER = """\
# X68000 FM captures, one row per song: tools/capture_x68k_fm_mame.py
# --all-songs output, pinned by SHA-256 of the delivered 48 kHz stereo WAV.
# loop_start/loop_end (exclusive) address that WAV: the settled second pass of
# a looped capture, '-' for a one-shot.  status is the capture's loop_status.
# build names the MAME build that made the recording: mac = 0.288 macOS arm64,
# windows = 0.288 Windows x64.
# Rewrite a game's rows with: build_pack.py x68k-fm --game <g> --pin [--build <b>]
game\tsong\tsha256\tframes\tloop_start\tloop_end\tstatus\tloop_ncc\tbuild
"""


def write_pins(key: str, capture_dir: Path, path: Path = PINS_TSV,
               build: str = DEFAULT_BUILD) -> int:
    game = GAMES[key].capture
    keep = []
    for raw in (_rows(path) if path.exists() else []):
        raw["build"] = _build_of(raw)
        if not (raw["game"] == game and raw["build"] == build):
            keep.append(raw)
    fresh = []
    for sidecar in sorted(capture_dir.glob("song*.json")):
        if sidecar.stem.endswith("-session"):
            continue
        m = json.loads(sidecar.read_text())
        loop = m.get("loop_candidate") or {}
        ncc = (m.get("capture_timing_adjustment") or {}).get("ncc")
        fresh.append({
            "game": game, "song": m["song"], "sha256": m["output_sha256"],
            "frames": str(m["wav"]["frames"]),
            "loop_start": str(loop["start_sample"]) if loop else "-",
            "loop_end": str(loop["end_sample"]) if loop else "-",
            "status": m["loop_status"],
            "loop_ncc": f"{ncc:.4f}" if ncc is not None else "-",
            "build": build,
        })
    rows = sorted(keep + fresh, key=lambda r: (r["game"], r["build"], r["song"]))
    cols = PIN_HEADER.strip().splitlines()[-1].split("\t")
    with path.open("w", encoding="utf-8", newline="") as f:
        f.write(PIN_HEADER)
        for r in rows:
            f.write("\t".join(r[c] for c in cols) + "\n")
    return len(fresh)


def read_capture(path: Path, pin: Pin) -> bytes:
    data = path.read_bytes()
    if hashlib.sha256(data).hexdigest() != pin.sha256:
        raise ValueError(f"{path}: SHA-256 does not match its pin")
    with wave.open(str(path), "rb") as w:
        if (w.getframerate(), w.getnchannels(), w.getsampwidth()) != (
                RATE, CHANNELS, 2):
            raise ValueError(f"{path}: expected {RATE} Hz 16-bit stereo")
        if w.getnframes() != pin.frames:
            raise ValueError(f"{path}: frame count does not match its pin")
        return w.readframes(pin.frames)


def pack_loop(pin: Pin, frames: int) -> tuple[int, int, int]:
    """(pack_ls, pack_le, keep): the capture's period, one second earlier."""
    assert pin.loop_start is not None and pin.loop_end is not None
    period = round((pin.loop_end - pin.loop_start) / ADX_GRID) * ADX_GRID
    ls = (pin.loop_start - XFADE_SAMPLES) // ADX_GRID * ADX_GRID
    le = ls + period
    keep = le + XFADE_SAMPLES
    if ls <= 0 or keep > frames:
        raise ValueError("loop leaves no intro or no crossfade tail")
    if abs(period - (pin.loop_end - pin.loop_start)) > ADX_GRID // 2:
        raise ValueError("pack loop changes the captured period")
    return ls, le, keep


def select_build(key: str, capture_dir: Path, music: list,
                 pins_path: Path = PINS_TSV) -> tuple[str, dict[str, Pin]]:
    """The recording set (macOS or Windows MAME) these captures belong to.

    The first song's capture decides; every other song must then match that
    same set, so a mix of two machines' recordings is refused."""
    first = music[0].song
    tried = []
    for name in builds_for(key, pins_path):
        pins = load_pins(key, pins_path, name)
        missing = sorted({row.song for row in music} - set(pins))
        if missing:
            tried.append(f"{name}: songs without a pin {missing}")
            continue
        src = capture_dir / f"{first}.wav"
        if src.is_file() and hashlib.sha256(src.read_bytes()).hexdigest() == pins[first].sha256:
            return name, pins
        tried.append(f"{name}: {first} does not match")
    raise ValueError(f"{key}: the captures match no pinned recording ({'; '.join(tried)}). "
                     "A different MAME build or different disk images record different audio.")


def build(key: str, *, capture_dir: Path | None = None, out: Path | None = None,
          pins_path: Path = PINS_TSV, measure_snr: bool = False) -> dict:
    game = GAMES[key]
    capture_dir = capture_dir or CAPTURE_ROOT / game.capture
    music = game.midi.load_music_map()
    loops = looped_songs(key)
    build_name, pins = select_build(key, capture_dir, music, pins_path)
    print(f"[{key}-fm] captures match the {build_name} recording")

    writer = writer_for(key, game.title)
    track_of: dict[str, int] = {}
    snrs: list[tuple[str, float]] = []
    print(f"[{key}-fm] === {game.title} ===")
    for row in music:
        pin = pins[row.song]
        src = capture_dir / f"{row.song}.wav"
        pcm = read_capture(src, pin)
        if row.song in loops:
            if pin.loop_start is None:
                raise ValueError(
                    f"{row.song}: the MIDI pack loops it but its FM capture "
                    f"is a one-shot ({pin.status})")
            ls, le, keep = pack_loop(pin, pin.frames)
            pcm = pcm[:keep * CHANNELS * 2]
            kind, xfade = "xfade loop", 1
        else:
            if pin.loop_start is not None:
                raise ValueError(
                    f"{row.song}: the MIDI pack plays it once but its FM "
                    "capture loops -- decide which before building")
            keep, ls, le, xfade = pin.frames, 0, 0, 0
            kind = "one-shot"
        data, coef1, coef2, snr = encode_adx_track(
            pcm, RATE, CHANNELS, keep, row.song, measure_snr)
        if snr is not None:
            snrs.append((row.song, snr))
        looped = bool(xfade)
        meta = TrackMeta(
            sample_rate=RATE, channels=CHANNELS, codec=CODEC_ADX, gain=0x7f,
            loop_start_sample=ls,
            loop_start_byte=(adxcodec.samples_to_stream_byte(ls, CHANNELS)
                             if looped else 0),
            loop_end_sample=le,
            loop_end_byte=(adxcodec.samples_to_stream_byte(le, CHANNELS)
                           if looped else 0),
            coef1=coef1, coef2=coef2, xfade_enable=xfade,
            name=f"{row.song} {row.role} ({kind})",
            source=f"{game.capture}/{src.name}; sha256 {pin.sha256[:16]}")
        ti = writer.add_track(data, meta)
        track_of[row.song] = ti
        print(f"[{key}-fm] t{ti:02d} {row.song} {keep / RATE:7.2f}s  "
              f"{kind:<11} {len(data) / 1e6:6.2f} MB  {row.role}")

    mapping = song_of_command(key, music)
    for cmd, song in sorted(mapping.items()):
        writer.set_trigger(cmd, TriggerRow(
            verb=VERB_PLAY, track=track_of[song], gain=game.trig_gain,
            suppress=1))

    out_path = out or (PACKS_DIR / game.pack)
    writer.write(out_path)
    reader = PackReader(out_path)
    try:
        for cmd, song in mapping.items():
            got = reader.triggers[cmd]
            if (got.verb, got.track, got.gain, got.suppress) != (
                    VERB_PLAY, track_of[song], game.trig_gain, 1):
                raise ValueError(f"readback: 0x{cmd:02x} does not map to {song}")
        controls = set(reader.header.proto.control_verbs)
        for cmd, got in enumerate(reader.triggers):
            if cmd not in mapping and cmd not in controls and (
                    got.verb != VERB_NONE or got.suppress):
                raise ValueError(f"readback: unmapped 0x{cmd:02x} does not "
                                 "fail open")
    finally:
        reader.close()
    _check_against_midi(key, out_path)

    size = out_path.stat().st_size
    if snrs:
        mean = sum(v for _, v in snrs) / len(snrs)
        worst = min(snrs, key=lambda v: v[1])
        print(f"[{key}-fm] ADX SNR mean {mean:.2f} dB, worst "
              f"{worst[0]} {worst[1]:.2f} dB")
    print(f"[{key}-fm] {out_path}: {len(music)} tracks, {len(mapping)} play "
          f"commands, {sum(1 for r in music if r.song in loops)} loops, "
          f"{size / 1e6:.1f} MB")
    return {"path": out_path, "size": size, "tracks": len(music),
            "commands": len(mapping), "snrs": snrs}


def _check_against_midi(key: str, fm_path: Path) -> None:
    """Every command plays the same song as in the accepted MIDI pack.

    Skipped (with a note) when the MIDI pack is not in the accepted store."""
    midi_path = PKG_ROOT / "packs" / GAMES[key].midi.PACK_NAME
    if not midi_path.is_file():
        print(f"[{key}-fm] note: {midi_path.name} not in packs/, "
              "MIDI parity not checked")
        return
    fm, mid = PackReader(fm_path), PackReader(midi_path)
    try:
        def songs(reader):
            if not reader.sidecar:
                raise ValueError(f"{reader.path.name}: no .cpk.json sidecar")
            names = [t["name"].split()[0] for t in reader.sidecar["tracks"]]
            return {cmd: names[row.track] for cmd, row in
                    enumerate(reader.triggers) if row.verb == VERB_PLAY}
        if songs(fm) != songs(mid):
            raise ValueError(f"{key}: FM command map differs from the MIDI pack")
        if fm.header.proto != mid.header.proto:
            raise ValueError(f"{key}: FM protocol differs from the MIDI pack")
    finally:
        fm.close()
        mid.close()


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(
        description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--game", required=True, choices=sorted(GAMES))
    ap.add_argument("--capture-dir", type=Path)
    ap.add_argument("--out", type=Path)
    ap.add_argument("--pins", type=Path, default=PINS_TSV)
    ap.add_argument("--pin", action="store_true",
                    help="rewrite this game's pins from the capture sidecars")
    ap.add_argument("--build", default=DEFAULT_BUILD,
                    help="with --pin: which recording set these captures are "
                         "(mac or windows; default mac)")
    ap.add_argument("--measure-snr", action="store_true")
    a = ap.parse_args(argv)
    capture_dir = a.capture_dir or CAPTURE_ROOT / GAMES[a.game].capture
    if a.pin:
        n = write_pins(a.game, capture_dir, a.pins, a.build)
        print(f"pinned {n} {a.game} captures in {a.pins}")
        return 0
    build(a.game, capture_dir=capture_dir, out=a.out, pins_path=a.pins,
          measure_snr=a.measure_snr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
