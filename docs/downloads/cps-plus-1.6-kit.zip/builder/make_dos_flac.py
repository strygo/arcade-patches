#!/usr/bin/env python3
"""Render one MS-DOS Super Street Fighter II Turbo soundtrack to FLAC, from a
copy of the game you own.

The DOS release (GameTek/Eurocom 1995) shipped its score on FOUR carriers, and
they sound nothing alike, so each one is its own pack.  This is the kit-side
driver for all four; make_packs.py calls it before build_pack.py, and you can
also run it by hand.  It chains the tools in tools/:

  fm    the game's own OPL3 chiptune.  bnk2wopl.py converts the disc's own
        DRV/MELODIC.BNK and DRV/DRUM.BNK -- so the timbres are the game's,
        not a generic substitute -- and render_dos_opl.py plays the `_F`
        sequences through Nuked OPL3 at the chip's own 49716 Hz.
        Uses the verified prebuilt libADLMIDI helper; no compiler is needed.
  sc55  render_dos_midi.py plays the `_G` sequences through the Nuked-SC55
        emulation.  Needs your own SC-55 ROM dump (--sc55-rom-dir).
  mt32  render_dos_mt32.py plays the `_M` sequences through Munt.  Needs your
        own MT-32 ROM dump (--mt32-rom-dir).
  cd    the disc's Red Book audio, extracted with extract_cdda.py and cut
        into pieces by slice_dos_cd.py.  No renderer, no ROMs, and by far the
        fastest of the four.

Only pinned helper binaries are downloaded, or installed from an offline bundle.
Game data and synthesizer firmware are never fetched, and the renders stay
under work/ on your machine.

Usage:
  python3 make_dos_flac.py --device sc55 --archive /dos/ssf2t_cd.zip \\
      --sc55-rom-dir /roms/sc55 [--work DIR] [--keep-wav]

--archive is the installed game -- a folder, or a .zip/.7z of one, holding
the game's MIDI/ and DRV/ folders and the CD image, as an eXoDOS package does
-- or the disc image alone (.cue or .chd), which is enough for the CD pack
only.  The CD carries no MIDI sequences (its installer holds the game and the
FM instrument banks, not the MIDI/ folder), so the other three need the
installed copy; given only the disc they exit with status 3 and make_packs.py
reports them skipped.

The last line printed is the directory holding the finished FLACs.
"""
from __future__ import annotations

# BEGIN ARCADE PYTHON BOOTSTRAP
import sys as _arcade_sys
from pathlib import Path as _ArcadePath
_arcade_sys.path.insert(0, str(_ArcadePath(__file__).resolve().parents[1]))
from kit_python import bootstrap as _arcade_bootstrap
_arcade_bootstrap()
# END ARCADE PYTHON BOOTSTRAP

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path

# abspath, not resolve(): on Windows resolve() turns a mapped drive into \\server\share
HERE = Path(os.path.abspath(__file__)).parent
TOOLS = HERE / "tools"
sys.path.insert(0, str(TOOLS))


sys.path.insert(0, str(HERE))
NEEDS_INSTALLED = 3   # exit status: this carrier needs the installed game, not just the disc

MANIFESTS = HERE / "manifests"
MAP_TSV = MANIFESTS / "ssf2t_dos_map.tsv"
CD_TRACKS_TSV = MANIFESTS / "ssf2t_dos_cd_tracks.tsv"

# device: (title, sequence letter, ROM option it needs)
DEVICES = {
    "fm": ("OPL3 chiptune", "F", None),
    "sc55": ("Roland Sound Canvas", "G", "sc55_rom_dir"),
    "mt32": ("Roland MT-32", "M", "mt32_rom_dir"),
    "cd": ("Red Book CD audio", "", None),
}


def run(argv: list) -> None:
    print("+ " + " ".join(str(a) for a in argv), flush=True)
    r = subprocess.run([str(a) for a in argv])
    if r.returncode:
        sys.exit(f"step failed ({r.returncode}); see the message above")


def need(binary: str, why: str) -> None:
    if shutil.which(binary) is None:
        sys.exit(f"{binary} is not on PATH; it is needed to {why}")


def source_name(stem: str, letter: str) -> str:
    """The rendered file's stem for a map entry on a given device.

    The disc infixes KO for a critical variant rather than suffixing it:
    base CHUN is CHUN_G, its critical variant CHUN_KOG.  Kept identical to
    pack/build_ssf2t_dos.py, which reads what this writes.
    """
    if not letter:
        return stem
    return f"{stem}{letter}" if stem.endswith("_KO") else f"{stem}_{letter}"


def _rows(path: Path) -> list[list[str]]:
    if not path.is_file():
        sys.exit(f"missing {path}")
    out = []
    for line in path.read_text(encoding="utf-8").splitlines():
        if line and not line.startswith("#"):
            out.append(line.split("\t"))
    return out[1:] if out else []            # drop the header


def wanted_songs(device: str, letter: str) -> list[str]:
    """Every file the pack builder will look for on this device.

    The command map is the authority for the three SYNTH devices: each maps
    one stem per command.  It is NOT the authority for the CD, which carries
    less than the sequences do. Its expectation comes from its own cut list,
    where a `base+critical` track yields two pieces.
    """
    if device == "cd":
        want = set()
        for cols in _rows(CD_TRACKS_TSV):
            if len(cols) < 4:
                continue
            stem, half = cols[2].strip(), cols[3].strip()
            if not stem or stem == "-":
                continue
            want.add(stem)
            if half == "base+critical":
                want.add(f"{stem}_KO")
        return sorted(want)
    stems = [cols[2].strip() for cols in _rows(MAP_TSV)
             if len(cols) >= 3 and cols[2].strip() and cols[2].strip() != "-"]
    return sorted({source_name(s, letter) for s in stems})


def flac_ready(flac_dir: Path, songs: list[str]) -> bool:
    try:
        rows = json.loads((flac_dir/'render_report.json').read_text())['songs']
        identities = {row['song']: row['sha256'] for row in rows}
        return all((flac_dir/f'{song}.flac').is_file()
                   and hashlib.sha256((flac_dir/f'{song}.flac').read_bytes()).hexdigest()
                   == identities[song] for song in songs)
    except (OSError, ValueError, KeyError):
        return False


def unpack(archive: Path, dest: Path) -> Path:
    """Unpack the game archive once; returns the folder it landed in."""
    if archive.is_dir():
        return archive
    stamp = dest / '.unpacked.json'
    digest = hashlib.sha256(archive.read_bytes()).hexdigest()
    try:
        cache = json.loads(stamp.read_text())
        if cache['source_sha256'] == digest and cache['files'] and all(
                (dest/name).is_file() and hashlib.sha256((dest/name).read_bytes()).hexdigest() == identity
                for name, identity in cache['files'].items()):
            return dest
    except (OSError, ValueError, KeyError):
        pass
    if dest.exists():
        shutil.rmtree(dest, ignore_errors=True)
    dest.mkdir(parents=True, exist_ok=True)
    suffix = archive.suffix.lower()
    print(f"unpacking {archive.name}", flush=True)
    if suffix == ".zip":
        with zipfile.ZipFile(archive) as z:
            z.extractall(dest)
    elif suffix == ".7z":
        from pack.media_tools import optional_tool
        exe = optional_tool('sevenzip')
        run([exe, "x", "-y", f"-o{dest}", archive])
    else:
        sys.exit(f"{archive.name}: expected a folder, a .zip or a .7z")
    stamp.write_text(json.dumps(dict(source_sha256=digest, files={
        f.relative_to(dest).as_posix(): hashlib.sha256(f.read_bytes()).hexdigest()
        for f in dest.rglob('*') if f.is_file() and f != stamp}), sort_keys=True)+'\n')
    return dest


def find_dir(root: Path, name: str, holding: str) -> Path | None:
    """The disc keeps the game's folders under GAMETEK/SSF2T/, but a rip may
    be rooted anywhere, so look rather than assume.  A name alone is not
    enough: the disc also carries ULTRASND/MIDI/, the Gravis config folder,
    which holds no sequences and sits shallower than the real one -- so the
    folder must actually contain what we came for."""
    cands = [root] if root.name.upper() == name else []
    cands += [p for p in root.rglob("*") if p.is_dir() and p.name.upper() == name]
    hits = sorted((p for p in cands if any(p.glob(holding))),
                  key=lambda p: len(p.parts))
    return hits[0] if hits else None


def find_cue(root: Path) -> Path | None:
    hits = sorted(root.rglob("*.cue"), key=lambda p: len(p.parts))
    return hits[0] if hits else None


def main() -> int:
    from pack.media_tools import configure, add_arguments, ffmpeg_exe, ffprobe_exe, optional_tool
    ap = argparse.ArgumentParser(
        description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--device", required=True, choices=sorted(DEVICES))
    ap.add_argument("--archive", required=True, type=Path,
                    help="the installed game as a folder, .zip or .7z; or the disc image "
                         "alone (.cue or .chd), which is enough for --device cd")
    ap.add_argument("--sc55-rom-dir", type=Path,
                    help="directory holding your SC-55 v1.21 ROM dump")
    ap.add_argument("--mt32-rom-dir", type=Path,
                    help="directory holding your MT-32 ROM dump")
    ap.add_argument("--work", type=Path, default=HERE / "work" / "dos",
                    help="work directory (default: builder/work/dos)")
    ap.add_argument("--keep-wav", action="store_true",
                    help="keep the raw CD extraction after the FLAC export")
    add_arguments(ap)
    ap.add_argument('--debug', action='store_true', help='show a traceback for troubleshooting')
    a = ap.parse_args(configure(sys.argv[1:]))

    title, letter, rom_opt = DEVICES[a.device]
    songs = wanted_songs(a.device, letter)
    work = Path(os.path.abspath(a.work.expanduser()))
    flac_dir = work / "flac" / a.device

    if flac_ready(flac_dir, songs):
        print(f"{title}: {len(songs)} FLACs already rendered, reusing {flac_dir}")
        print(flac_dir)
        return 0

    archive = Path(os.path.abspath(a.archive.expanduser()))
    if not archive.exists():
        sys.exit(f"not found: {archive}")

    suffix = archive.suffix.lower()
    if suffix in (".cue", ".chd"):
        root = None                      # the disc image alone
        if suffix == ".cue":
            cue = archive
        else:
            from pack.sources import cd_chd_to_cue
            cue = cd_chd_to_cue(archive, work / "cache")
    else:
        root = unpack(archive, work / "game")
        cue = find_cue(root)
    midi_dir = find_dir(root, "MIDI", "*.HMP") if root else None
    if a.device != "cd" and midi_dir is None:
        if cue is not None:
            print(f"{title}: {archive.name} is the disc without the installed game.  This "
                  f"pack plays the game's MIDI sequences, and the CD carries none: they "
                  f"come with the installed copy (an eXoDOS package holds them in its "
                  f"MIDI/ folder).  Point ssf2t_dos_disc at that installed copy to build "
                  f"it.  The CD soundtrack pack builds from the disc alone.")
            return NEEDS_INSTALLED
        sys.exit(f"{archive.name} has no MIDI/ folder of .HMP sequences -- is this the MS-DOS "
                 f"Super Street Fighter II Turbo release?")

    if rom_opt:
        given = a.sc55_rom_dir if a.device == "sc55" else a.mt32_rom_dir
        if given is None:
            sys.exit(f"--{rom_opt.replace('_', '-')} is required for {a.device}")
        rom_dir = Path(os.path.abspath(given.expanduser()))
        if not rom_dir.is_dir():
            sys.exit(f"ROM directory not found: {rom_dir}")
    else:
        rom_dir = None

    ffmpeg_exe()
    ffprobe_exe()
    flac_dir.mkdir(parents=True, exist_ok=True)

    if a.device == "cd":
        if cue is None:
            sys.exit(f"{archive.name} has no .cue holding the Red Book audio -- point "
                     f"ssf2t_dos_disc at the disc image (.cue or .chd) or a copy that has it")
        cdda = work / "cdda"
        print(f"\n== {title}: extracting the Red Book audio from {cue.name}")
        run([sys.executable, TOOLS / "extract_cdda.py", cue, cdda])
        print(f"\n== {title}: cutting the tracks into their pieces")
        run([sys.executable, TOOLS / "slice_dos_cd.py", cdda,
             "--out-dir", flac_dir, "--map", MANIFESTS / "ssf2t_dos_cd_tracks.tsv"])
        if not a.keep_wav:
            freed = sum(w.stat().st_size for w in cdda.glob("*.wav"))
            shutil.rmtree(cdda, ignore_errors=True)
            if freed:
                print(f"removed the raw extraction ({freed / 1e9:.1f} GB)")
    else:
        if a.device == "fm":
            drv = find_dir(root, "DRV", "*.BNK")
            if drv is None:
                sys.exit("no DRV/ folder holding MELODIC.BNK and DRUM.BNK")
            lib = optional_tool('adlmidi')
            bank = work / "ssf2t_dos.wopl"
            print(f"\n== {title}: converting the disc's own OPL banks")
            run([sys.executable, TOOLS / "bnk2wopl.py",
                 "--melodic", drv / "MELODIC.BNK", "--drum", drv / "DRUM.BNK",
                 "--out", bank])
            print(f"\n== {title}: rendering {len(songs)} songs through Nuked OPL3")
            run([sys.executable, TOOLS / "render_dos_opl.py", midi_dir,
                 "--bank", bank, "--out-dir", flac_dir, "--library", lib])
        elif a.device == "sc55":
            renderer = optional_tool('sc55')
            print(f"\n== {title}: rendering {len(songs)} songs through the SC-55 "
                  f"(this is the slow part)")
            run([sys.executable, TOOLS / "render_dos_midi.py", midi_dir,
                 "--out-dir", flac_dir, "--renderer", renderer, "--roms", rom_dir])
        else:
            renderer = optional_tool('mt32')
            print(f"\n== {title}: rendering {len(songs)} songs through Munt "
                  f"(this is the slow part)")
            run([sys.executable, TOOLS / "render_dos_mt32.py", midi_dir,
                 "--out-dir", flac_dir, "--renderer", renderer, "--roms", rom_dir])

    missing = [s for s in songs if not (flac_dir / f"{s}.flac").is_file()]
    if missing:
        sys.exit(f"{title}: {len(missing)} of {len(songs)} renders are missing, "
                 f"first: {missing[0]}.flac in {flac_dir}")
    print(f"\n{title}: {len(songs)} FLACs ready")
    print(flac_dir)
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except (OSError, ValueError) as exc:
        if '--debug' in sys.argv:
            raise
        print('ERROR: '+str(exc), file=sys.stderr)
        sys.exit(1)
