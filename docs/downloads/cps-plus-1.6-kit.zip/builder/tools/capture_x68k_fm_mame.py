#!/usr/bin/env python3
"""Capture X68000 FM/ADPCM audio through the original game and MAME.

This is the reference FM/ADPCM capture path: MAME boots the original disk
images and records the emulated YM2151 plus OKIM6258 mix.  It requires a
user-supplied MAME ``x68000`` BIOS set.  Interactive capture remains available;
every game with a PROFILES entry (Final Fight, SF2CE, SSF2, Daimakaimura) can
also be driven headlessly by naming a ``--song``, or ``--all-songs``.

Each profile boots the game's own disks, performs any disk swap its loader
asks for (eject, insert, answer Human68k's Retry prompt), opens the option
mode's music test, steps its value to the song and presses play.  The
Capcom/SPS ports count from 00 = stop, so bank song N is value N+1;
Daimakaimura's test is zero-based (00 plays song00), measured by sequence
length.
Songs whose FM sequence has a global loop keep an intro plus --loop-passes
passes and a RIFF smpl loop over the settled pass; the rest are captured as
one-shots for the sequence's length plus a release tail.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import re
import shutil
import struct
import subprocess
import sys
import tempfile
import threading
import wave
import zipfile
from array import array
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from pathlib import Path, PurePosixPath

from x68k_midi import audit as audit_midi
from x68k_midi import parse_midi, tick_to_seconds


class CaptureError(RuntimeError):
    pass


FFIGHT_BASE_ACTIONS = (
    (6000, "P1 A", "skip_intro"),
    (6180, "P1 Down", "select_option_mode"),
    (6240, "P1 B", "enter_option_mode"),
    (6780, "P1 Down", "menu_down_1"),
    (6840, "P1 Down", "menu_down_2"),
    (6900, "P1 Down", "menu_down_3"),
    (6960, "P1 Down", "menu_down_4"),
)

# Human68k's "no disk -- Abort/Retry/Ignore" prompt takes R to retry.
RETRY_KEY = "R  す"

# A one-shot is captured for its sequence's length plus this tail, so the
# last notes' release is kept; the delivered WAV ends ONE_SHOT_RELEASE after
# the last audible sample.  Still sounding at the capture's end is an error.
ONE_SHOT_TAIL_SECONDS = 4.0
ONE_SHOT_RELEASE_SECONDS = 0.25
AUDIBLE = 16


@dataclass(frozen=True)
class Profile:
    """One game's deterministic route to its music test.

    ``disks`` are catalog image indexes (1-based) for drives 1..n.  A swap
    is (frame, drive, image index or None to eject).  Frames count from
    boot; MAME replays them identically because nothing else feeds input.
    """
    name: str
    disks: tuple[int, ...] | None
    swaps: tuple[tuple[int, int, int | None], ...]
    actions: tuple[tuple[int, str, str], ...]
    value_frame: int
    value_step: int
    play: str
    increment: str = "P1 Right"
    value_offset: int = 1        # music-test value of bank song00
    # Songs past the menu's last value: (last value, address, original
    # bytes, replacement) -- a RAM patch to the menu's own range check, made
    # only for those songs and only after the original bytes are verified.
    menu_limit: tuple[int, int, bytes, bytes] | None = None


def _downs(first: int, count: int, step: int = 60) -> tuple[tuple[int, str, str], ...]:
    return tuple((first + index * step, "P1 Down", f"menu_down_{index + 1}")
                 for index in range(count))


PROFILES = {
    "ffight": Profile(
        "ffight-option-music-test-v1", None, (), FFIGHT_BASE_ACTIONS,
        7020, 60, "XF1"),
    # System disk stays in A: (it holds PIT.SLD); the loader reads Disk 1 from
    # B:, then asks for Disk 2 there.  OPTION MODE row 4 is MUSIC TEST.
    "sf2ce": Profile(
        "sf2ce-option-music-test-v1", (1, 2),
        ((3600, 2, None), (3720, 2, 3)),
        ((3800, RETRY_KEY, "retry_disk_2"),
         (6620, "P1 B", "open_title_menu"),
         (6800, "P1 Down", "select_option"),
         (6920, "P1 B", "enter_option_mode"))
        + _downs(7300, 3),
        7500, 40, "P1 B"),
    # Same loader shape: SYSTEM in A:, DISK_1 then DISK_2 in B:.  The title
    # menu is SUPER BATTLE / TOURNAMENT BATTLE / OPTION.
    "ssf2": Profile(
        "ssf2-option-music-test-v1", (7, 1),
        ((3000, 2, None), (3120, 2, 2)),
        ((3200, RETRY_KEY, "retry_disk_2"),
         (6400, "P1 B", "open_title_menu"),
         (6600, "P1 Down", "select_tournament"),
         (6680, "P1 Down", "select_option"),
         (6800, "P1 B", "enter_option_mode"))
        + _downs(7200, 3),
        7400, 40, "P1 B"),
    # No swap.  OPTION MODE row 6 is MUSIC TEST; its value displays in hex.
    "daimakaimura": Profile(
        "daimakaimura-option-music-test-v1", (1, 2), (),
        ((3700, "P1 B", "open_title_menu"),
         (3900, "P1 Down", "select_option"),
         (4000, "P1 B", "enter_option_mode"))
        + _downs(4200, 5),
        4520, 40, "P1 B", value_offset=0,
        # The test stops at 19 and wraps to 00, but the bank also has song1a
        # (Ending variant B), which the game plays only in play.  DM.X's
        # handler at 0x8ff42 adds the Left/Right step to the counter
        # (0x98490), wraps it with `cmpi.b #$1a,d7` every frame, and on A/B
        # calls the driver at 0x62ff8 with it.  Raising that bound to 0x1b
        # lets the menu itself step to 1A and play it.
        menu_limit=(0x19, 0x8ff4a, bytes.fromhex("0c07001a"),
                    bytes.fromhex("0c07001b"))),
}


def _sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for block in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _seven_zip() -> str:
    executable = shutil.which("7zz") or shutil.which("7z")
    if executable is None:
        raise CaptureError("7zz/7z is required to read the SSFII archive")
    return executable


def _read_member(archive: Path, member: str) -> bytes:
    if archive.suffix.lower() == ".zip":
        with zipfile.ZipFile(archive) as container:
            return container.read(member)
    executable = _seven_zip()
    result = subprocess.run(
        [executable, "x", "-so", str(archive), member], capture_output=True
    )
    if result.returncode:
        raise CaptureError(
            result.stderr.decode(errors="replace").strip()
            or f"cannot extract {member} from {archive}"
        )
    return result.stdout


def _rompath(repo: Path, additions: list[Path] | None) -> str:
    paths = [repo / "roms", repo / "roms" / "mame0260"]
    paths.extend(additions or [])
    unique: list[str] = []
    for path in paths:
        value = str(path.resolve())
        if value not in unique:
            unique.append(value)
    return ";".join(unique)


def _verify_bios(mame: Path, rompath: str) -> None:
    result = subprocess.run(
        [str(mame), "x68000", "-rompath", rompath, "-verifyroms"],
        text=True, capture_output=True,
    )
    if result.returncode:
        details = "\n".join(part for part in (result.stdout, result.stderr) if part)
        raise CaptureError(
            "MAME cannot verify the x68000 BIOS set. Put x68000.zip in one "
            f"of these ROM paths: {rompath}\n{details}"
        )


def _song_number(song: str) -> int:
    match = re.fullmatch(r"song([0-9a-fA-F]{2})", song)
    if match is None:
        raise CaptureError("--song must use the form song00 through songff")
    return int(match.group(1), 16)


def _profile_actions(
    profile: Profile, song: str
) -> tuple[list[tuple[int, str, str]], int]:
    """Return a profile's deterministic menu, music-test and play inputs.

    The value starts at 00 and each increment adds one; song N sits at
    N + profile.value_offset.
    """
    value = _song_number(song) + profile.value_offset
    actions = list(profile.actions)
    for offset in range(value):
        frame = profile.value_frame + offset * profile.value_step
        actions.append(
            (frame, profile.increment, f"select_music_test_{offset + 1:02x}"))
    play_frame = max(actions[-1][0], profile.value_frame - 60) + 60
    actions.append((play_frame, profile.play, f"play_{song}"))
    return actions, play_frame


def _profile_patches(
    profile: Profile, song: str
) -> list[tuple[int, int, bytes, bytes]]:
    """(frame, address, original, replacement) for songs past the menu."""
    value = _song_number(song) + profile.value_offset
    if profile.menu_limit is None or value <= profile.menu_limit[0]:
        return []
    last, address, original, replacement = profile.menu_limit
    if value > last + 1:
        raise CaptureError(f"{song}: value {value:02x} is past the patched menu")
    return [(profile.value_frame - 60, address, original, replacement)]


def _lua_str(value: str) -> str:
    """A Lua string literal; UTF-8 passes through (Lua has no \\u escape)."""
    return json.dumps(value, ensure_ascii=False)


def _automation_lua(
    profile: Profile, song: str, capture_seconds: float,
    swap_paths: dict[int, str] | None = None,
) -> str:
    """MAME Lua that performs the profile's swaps and inputs, then exits.

    ``swap_paths`` maps a catalog image index to its extracted path.  A swap
    to None ejects the drive, which is what makes Human68k notice the
    change: an in-place image load goes unseen, and the game keeps asking.
    """
    actions, play_frame = _profile_actions(profile, song)
    rows = "\n".join(
        f'  {{ {frame}, {_lua_str(field)}, {_lua_str(label)} }},'
        for frame, field, label in actions
    )
    action_names = sorted({field for _, field, _ in actions})
    names = "\n".join(f'  [{_lua_str(name)}] = true,' for name in action_names)
    patch_rows = "\n".join(
        f'  {{ {frame}, {address}, "{original.hex()}", "{replacement.hex()}" }},'
        for frame, address, original, replacement in _profile_patches(profile, song)
    )
    swap_rows = "\n".join(
        f'  {{ {frame}, {drive - 1}, '
        f'{_lua_str((swap_paths or {})[image]) if image else "nil"} }},'
        for frame, drive, image in profile.swaps
    )
    return f'''local machine = manager.machine
-- Pin the RP5C15 clock.  MAME seeds it from the host's time, which made
-- otherwise identical captures differ run to run (about -35 dB of
-- residual); a fixed 1994-01-01 00:00:00 makes the capture reproducible.
do
  local program = machine.devices[":maincpu"].spaces["program"]
  local function rtc(register, value)
    program:write_u8(0xe8a001 + register * 2, value)
  end
  rtc(0xd, 0x0)       -- bank 0, timer halted while the counters are set
  for register, value in pairs({{
    [0x0] = 0, [0x1] = 0, [0x2] = 0, [0x3] = 0, [0x4] = 0, [0x5] = 0,
    [0x6] = 6, [0x7] = 1, [0x8] = 0, [0x9] = 1, [0xa] = 0, [0xb] = 4,
    [0xc] = 1,
  }}) do rtc(register, value) end
  rtc(0xd, 0x8)       -- timer running
end
local frame = 0
local play_time = nil
local capture_seconds = {capture_seconds:.9f}
local fields = {{}}
local action_names = {{
{names}
}}
local schedule = {{
{rows}
}}
local swaps = {{
{swap_rows}
}}
local patches = {{
{patch_rows}
}}
local drives = {{}}
for tag, image in pairs(machine.images) do
  local unit = tag:match(":upd72065:(%d+):")
  if unit then drives[tonumber(unit)] = image end
end

for _, port in pairs(machine.ioport.ports) do
  for _, field in pairs(port.fields) do
    if action_names[field.name] then
      fields[field.name] = fields[field.name] or {{}}
      table.insert(fields[field.name], field)
    end
  end
end

local function set_fields(name, pressed)
  for _, field in ipairs(fields[name] or {{}}) do
    if pressed then field:set_value(1) else field:clear_value() end
  end
end

emu.register_frame_done(function()
  frame = frame + 1
  for _, swap in ipairs(swaps) do
    if frame == swap[1] then
      local drive = assert(drives[swap[2]], "no floppy drive " .. swap[2])
      if swap[3] then drive:load(swap[3]) else drive:unload() end
      print(string.format(
        "X68K_FM_CAPTURE frame=%d time=%.9f action=%s_drive_%d",
        frame, machine.time.seconds, swap[3] and "insert" or "eject",
        swap[2] + 1
      ))
    end
  end
  for _, patch in ipairs(patches) do
    if frame == patch[1] then
      local program = machine.devices[":maincpu"].spaces["program"]
      local found = ""
      for i = 0, #patch[3] // 2 - 1 do
        found = found .. string.format("%02x", program:read_u8(patch[2] + i))
      end
      assert(found == patch[3], string.format(
        "menu patch: expected %s at %06x, found %s", patch[3], patch[2], found))
      for i = 0, #patch[4] // 2 - 1 do
        program:write_u8(patch[2] + i, tonumber(patch[4]:sub(2 * i + 1, 2 * i + 2), 16))
      end
      print(string.format(
        "X68K_FM_CAPTURE frame=%d time=%.9f action=patch_menu_%06x",
        frame, machine.time.seconds, patch[2]))
    end
  end
  local pressed = {{}}
  for _, action in ipairs(schedule) do
    if frame >= action[1] and frame < action[1] + 6 then
      pressed[action[2]] = true
    end
    if frame == action[1] then
      print(string.format(
        "X68K_FM_CAPTURE frame=%d time=%.9f action=%s",
        frame, machine.time.seconds, action[3]
      ))
    end
  end
  for name, _ in pairs(action_names) do
    set_fields(name, pressed[name] == true)
  end
  if frame == {play_frame} then play_time = machine.time.seconds end
  if play_time and machine.time.seconds - play_time >= capture_seconds then
    print(string.format(
      "X68K_FM_CAPTURE frame=%d time=%.9f action=exit",
      frame, machine.time.seconds
    ))
    machine:exit()
  end
end)
'''


def _wav_info(path: Path) -> dict[str, int]:
    with wave.open(str(path), "rb") as source:
        return {
            "encoding": 1,
            "channels": source.getnchannels(),
            "sample_rate": source.getframerate(),
            "bits_per_sample": source.getsampwidth() * 8,
            "frames": source.getnframes(),
        }


def _first_audible_frame(
    path: Path, search_start_seconds: float, threshold: int = 16
) -> int:
    with wave.open(str(path), "rb") as source:
        if source.getsampwidth() != 2:
            raise CaptureError("automated post-processing requires 16-bit PCM")
        channels = source.getnchannels()
        if channels < 1:
            raise CaptureError("MAME WAV has no channels")
        start = min(
            int(search_start_seconds * source.getframerate()),
            source.getnframes(),
        )
        source.setpos(start)
        position = start
        while True:
            raw = source.readframes(4096)
            if not raw:
                break
            samples = array("h")
            samples.frombytes(raw)
            if sys.byteorder != "little":
                samples.byteswap()
            for offset in range(0, len(samples), channels):
                right = samples[offset + 1] if channels > 1 else samples[offset]
                if max(abs(samples[offset]), abs(right)) >= threshold:
                    return position + offset // channels
            position += len(samples) // channels
    raise CaptureError("no song audio was detected after the automated trigger")


def _write_stereo_segment(
    source_path: Path, target_path: Path, start_frame: int, frames: int
) -> dict[str, int]:
    with wave.open(str(source_path), "rb") as source:
        channels = source.getnchannels()
        if source.getsampwidth() != 2 or source.getcomptype() != "NONE":
            raise CaptureError("MAME WAV must be uncompressed 16-bit PCM")
        if start_frame + frames > source.getnframes():
            available = max(source.getnframes() - start_frame, 0)
            raise CaptureError(
                f"capture is too short: need {frames} song frames, have {available}"
            )
        source.setpos(start_frame)
        with wave.open(str(target_path), "wb") as target:
            target.setnchannels(2)
            target.setsampwidth(2)
            target.setframerate(source.getframerate())
            remaining = frames
            while remaining:
                count = min(remaining, 32768)
                raw = source.readframes(count)
                if channels == 2:
                    target.writeframesraw(raw)
                else:
                    samples = array("h")
                    samples.frombytes(raw)
                    if sys.byteorder != "little":
                        samples.byteswap()
                    stereo = array("h")
                    for offset in range(0, len(samples), channels):
                        left = samples[offset]
                        right = samples[offset + 1] if channels > 1 else left
                        stereo.append(left)
                        stereo.append(right)
                    if sys.byteorder != "little":
                        stereo.byteswap()
                    target.writeframesraw(stereo.tobytes())
                remaining -= count
    return _wav_info(target_path)


def _read_first_channel(
    path: Path, start_frame: int, frames: int
) -> tuple[array, int]:
    with wave.open(str(path), "rb") as source:
        if source.getsampwidth() != 2 or source.getcomptype() != "NONE":
            raise CaptureError("MAME WAV must be uncompressed 16-bit PCM")
        channels = source.getnchannels()
        if start_frame < 0 or start_frame + frames > source.getnframes():
            raise CaptureError("capture is too short for loop-clock analysis")
        source.setpos(start_frame)
        samples = array("h")
        samples.frombytes(source.readframes(frames))
        if sys.byteorder != "little":
            samples.byteswap()
        return samples[0::channels], source.getframerate()


def _measure_repeat_period(
    path: Path,
    song_start_frame: int,
    source_start_seconds: float,
    source_period_seconds: float,
    radius_fraction: float = 0.0002,
    first_pass: int = 2,
) -> dict[str, float | int]:
    """Measure the game clock against a converted sequence's loop period.

    The converter's tempo is an excellent structural reference but can differ
    from the emulated driver clock by tens of parts per million.  Compare a
    long slice in captured pass two with pass three, first testing lag
    candidates every four samples and then every sample around the strongest
    candidate.  Waveform samples are decimated 16:1 for efficiency.
    """
    wav = _wav_info(path)
    sample_rate = wav["sample_rate"]
    nominal = round(source_period_seconds * sample_rate)
    guard_seconds = min(3.0, source_period_seconds * 0.1)
    window_seconds = min(12.0, source_period_seconds - 2 * guard_seconds)
    if window_seconds < 0.25:
        raise CaptureError("source loop is too short for loop-clock analysis")
    window = round(window_seconds * sample_rate)
    guard = round(guard_seconds * sample_rate)
    nominal_pass = round(
        (source_start_seconds + (first_pass - 1) * source_period_seconds)
        * sample_rate
    )
    first = song_start_frame + nominal_pass + guard
    radius = max(256, round(nominal * radius_fraction))
    source, captured_rate = _read_first_channel(path, first, window)
    target, target_rate = _read_first_channel(
        path, first + nominal - radius, window + 2 * radius
    )
    if captured_rate != sample_rate or target_rate != sample_rate:
        raise CaptureError("inconsistent sample rates during loop-clock analysis")

    stride = 16
    reference = [float(source[index]) for index in range(0, window, stride)]
    mean = sum(reference) / len(reference)
    reference = [value - mean for value in reference]
    reference_energy = sum(value * value for value in reference)

    def score(delta: int) -> float:
        offset = radius + delta
        candidate = [
            float(target[offset + index])
            for index in range(0, window, stride)
        ]
        candidate_mean = sum(candidate) / len(candidate)
        dot = sum(
            left * (right - candidate_mean)
            for left, right in zip(reference, candidate)
        )
        candidate_energy = sum(
            (value - candidate_mean) ** 2 for value in candidate
        )
        denominator = math.sqrt(reference_energy * candidate_energy)
        return dot / denominator if denominator else 0.0

    coarse = max(
        ((score(delta), delta) for delta in range(-radius, radius + 1, 4)),
        key=lambda row: row[0],
    )
    low = max(-radius, coarse[1] - 5)
    high = min(radius, coarse[1] + 5)
    best = max(
        ((score(delta), delta) for delta in range(low, high + 1)),
        key=lambda row: row[0],
    )
    if best[0] < 0.35:
        raise CaptureError(
            "captured passes do not correlate strongly enough to refine the "
            f"loop clock (NCC {best[0]:.3f})"
        )
    measured = nominal + best[1]
    return {
        "method": (f"pass-{first_pass}-to-pass-{first_pass + 1}-"
                   "strided-waveform-ncc-v1"),
        "analysis_window_seconds": round(window_seconds, 9),
        "analysis_stride_samples": stride,
        "search_radius_samples": radius,
        "ncc": round(best[0], 9),
        "nominal_period_samples": nominal,
        "measured_period_samples": measured,
        "period_delta_samples": best[1],
        "clock_scale": measured / (source_period_seconds * sample_rate),
        "first_pass": first_pass,
    }


def _append_smpl_loop(path: Path, start: int, end: int, sample_rate: int) -> None:
    if not 0 <= start < end:
        raise CaptureError(f"invalid sample loop: {start}..{end}")
    # RIFF smpl loop ends are inclusive.  Project JSON uses an exclusive end.
    payload = struct.pack(
        "<15I",
        0, 0, round(1_000_000_000 / sample_rate), 60, 0, 0, 0, 1, 0,
        0, 0, start, end - 1, 0, 0,
    )
    with path.open("r+b") as target:
        if target.read(4) != b"RIFF":
            raise CaptureError(f"not a RIFF WAV: {path}")
        target.seek(0, os.SEEK_END)
        target.write(b"smpl")
        target.write(struct.pack("<I", len(payload)))
        target.write(payload)
        size = target.tell()
        target.seek(4)
        target.write(struct.pack("<I", size - 8))


def _loop_for_song(
    game: dict[str, object], song: str
) -> tuple[Path, dict[str, object]]:
    fm = game["fm"]
    if not isinstance(fm, dict):
        raise CaptureError(f"game has no FM catalog: {game['game']}")
    native = {
        Path(str(row["name"])).stem.casefold()
        for row in fm["native_files"]
    }
    if song.casefold() not in native:
        raise CaptureError(f"FM sequence is not present for {game['game']}: {song}")
    midi_path = next(
        (
            Path(str(value))
            for value in fm["songs"]
            if Path(str(value)).stem.casefold() == song.casefold()
        ),
        None,
    )
    if midi_path is None or not midi_path.is_file():
        raise CaptureError(f"converted FM timing reference is missing for {song}")
    result = audit_midi(midi_path)
    loop = result.get("global_loop")
    if not isinstance(loop, dict):
        consensus = _consensus_loop(midi_path, result)
        if consensus:
            return midi_path, consensus
        # No loop at all: captured whole, as a one-shot.
        first, last = _note_span(midi_path)
        return midi_path, {"start_seconds": None, "period_seconds": None,
                           "duration_seconds": result["duration_seconds"],
                           "first_note_seconds": first,
                           "last_note_off_seconds": last}
    return midi_path, {**loop, "duration_seconds": result["duration_seconds"]}


def _note_span(midi_path: Path) -> tuple[float, float]:
    """Seconds of the first note-on and the last note-off."""
    midi = parse_midi(midi_path.read_bytes())
    ons, offs = [], []
    for event in midi.events:
        kind = event.status & 0xf0 if event.status is not None else None
        velocity = event.data[1] if len(event.data) > 1 else 0
        if kind == 0x90 and velocity:
            ons.append(event.tick)
        elif kind == 0x80 or (kind == 0x90 and not velocity):
            offs.append(event.tick)
    if not ons:
        raise CaptureError(f"{midi_path.name}: sequence plays no notes")
    return (tick_to_seconds(midi, min(ons)),
            tick_to_seconds(midi, max(offs or ons)))


def _consensus_loop(
    midi_path: Path, result: dict[str, object]
) -> dict[str, object] | None:
    """The loop most parts share, for sequences whose parts loop separately.

    Two SSF2 FM songs (song18, song26) loop every part on its own and one part
    disagrees (a 25-tick conversion drift; a long pad), so the extractor finds
    no short common cycle.  On the X68000 that part simply slides against the
    rest on every repeat.  The capture loops at the period most parts share,
    from the latest entry among them, and the measured pass-to-pass
    correlation must still hold.  Majority only: never a minority period.
    """
    tracks = [row for row in result.get("loop_tracks") or []
              if isinstance(row, dict) and row.get("period_ticks")]
    if not tracks:
        return None
    periods = [int(row["period_ticks"]) for row in tracks]
    # The cycle that the most parts divide evenly (shortest on a tie): nested
    # percussion cycles of 72/144/288 all repeat inside a 1152-tick phrase.
    period = max(sorted(set(periods)),
                 key=lambda p: sum(p % q == 0 for q in periods))
    members = [row for row in tracks if period % int(row["period_ticks"]) == 0]
    if 2 * len(members) <= len(tracks):
        return None
    midi = parse_midi(midi_path.read_bytes())
    entry = max(int(row["start_tick"]) for row in members)
    start = tick_to_seconds(midi, entry)
    end = tick_to_seconds(midi, entry + period)
    return {
        "start_tick": entry, "end_tick": entry + period,
        "period_ticks": period, "start_seconds": start,
        "end_seconds": end, "period_seconds": end - start,
        "basis": (f"consensus period of {len(members)}/{len(tracks)} looping "
                  "parts; the others drift against it on each repeat"),
        "consensus": True,
        "duration_seconds": result["duration_seconds"],
    }


EXIT_GRACE_SECONDS = 30
WALL_LIMIT_SECONDS = 7200


def _run_mame(command: list[str], environment: dict[str, str]) -> tuple[str, bool]:
    """Run MAME, returning (stdout, hung_on_exit).

    MAME sometimes finishes a -wavwrite session, closes the WAV, and then
    hangs at 0% CPU instead of exiting (seen on CPS1 sweeps and here).  Once
    the Lua has printed its exit action the capture is complete, so a process
    still alive EXIT_GRACE_SECONDS later is killed and the run counts; any
    other nonzero exit, or no exit action at all, is an error.
    """
    proc = subprocess.Popen(command, env=environment, text=True,
                            stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    errors: list[str] = []
    drain = threading.Thread(
        target=lambda: errors.append(proc.stderr.read()), daemon=True)
    drain.start()
    watchdog = threading.Timer(WALL_LIMIT_SECONDS, proc.kill)
    watchdog.start()
    lines: list[str] = []
    exit_seen = hung = False
    try:
        for line in proc.stdout:
            lines.append(line)
            if "action=exit" in line and not exit_seen:
                exit_seen = True
                grace = threading.Timer(EXIT_GRACE_SECONDS, proc.kill)
                grace.start()
                try:
                    proc.wait()
                finally:
                    grace.cancel()
                hung = proc.returncode != 0
                break
        proc.wait()
    finally:
        watchdog.cancel()
    drain.join(timeout=5)
    stdout = "".join(lines) + (proc.stdout.read() if not proc.stdout.closed else "")
    if not exit_seen:
        raise CaptureError(
            f"MAME exited with status {proc.returncode} before the capture "
            f"finished: {''.join(errors).strip()[-400:]}")
    if proc.returncode and not hung:
        raise CaptureError(f"MAME exited with status {proc.returncode}")
    return stdout, hung


def _capture_events(stdout: str) -> dict[str, float]:
    """Emulated time of every X68K_FM_CAPTURE action the Lua printed."""
    events: dict[str, float] = {}
    for match in re.finditer(
            r"X68K_FM_CAPTURE frame=\d+ time=([0-9.]+) action=(\S+)", stdout):
        events.setdefault(match.group(2), float(match.group(1)))
    return events


def _last_audible_frame(path: Path, start_frame: int) -> int:
    with wave.open(str(path), "rb") as source:
        channels = source.getnchannels()
        source.setpos(start_frame)
        last, position = start_frame, start_frame
        while True:
            raw = source.readframes(48000)
            if not raw:
                return last
            samples = array("h")
            samples.frombytes(raw)
            if sys.byteorder != "little":
                samples.byteswap()
            frames = len(samples) // channels
            left = samples[0::channels]
            right = samples[1::channels] if channels > 1 else left
            for index in range(frames - 1, -1, -1):
                if abs(left[index]) >= AUDIBLE or abs(right[index]) >= AUDIBLE:
                    last = position + index
                    break
            position += frames


def _finish_one_shot(
    args: argparse.Namespace, profile: Profile, game: dict[str, object],
    archive: Path, mame: Path, mame_version: str,
    disks: list[dict[str, object]], midi_path: Path, loop: dict[str, object],
    session_output: Path, session_wav: dict[str, int], onset: int,
    play_time: float, capture_seconds: float, output: Path,
) -> Path:
    rate = session_wav["sample_rate"]
    last = _last_audible_frame(session_output, onset)
    if session_wav["frames"] - last < round(0.5 * rate):
        raise CaptureError(
            f"{args.song}: one-shot is still sounding at the end of its "
            f"{capture_seconds:.1f} s capture")
    frames = last + round(ONE_SHOT_RELEASE_SECONDS * rate) - onset
    # The sounding length must agree with the sequence's note span (first
    # note-on to last note-off; the onset trim drops any lead-in rest): the
    # check that the music test played the intended song, since a one-shot
    # has no loop period to confirm it.  Measured on SSF2's ten FM one-shots,
    # captures sound 0.0-1.2 s short of the span (FM decay before the last
    # note-off); the upper bound allows for release.
    sounding = (last - onset) / rate
    span = float(loop["last_note_off_seconds"]) - float(loop["first_note_seconds"])
    if not span - max(1.5, 0.05 * span) <= sounding <= span + ONE_SHOT_TAIL_SECONDS:
        raise CaptureError(
            f"{args.song}: sounded {sounding:.2f} s against a "
            f"{span:.2f} s note span -- wrong song or truncated")
    wav = _write_stereo_segment(session_output, output, onset, frames)
    manifest = {
        "schema": "cpsplus-x68000-mame-song-v1",
        "game": args.game,
        "song": args.song,
        "machine": "x68000",
        "mame": str(mame.resolve()),
        "mame_version": mame_version,
        "archive": str(archive.resolve()),
        "archive_sha256": game["archive_sha256"],
        "disks": disks,
        "timing_reference": str(midi_path.resolve()),
        "timing_reference_sha256": _sha256_file(midi_path),
        "automation": {
            "profile": profile.name,
            "music_test_value": _song_number(args.song) + profile.value_offset,
            "play_seconds": round(play_time, 9),
            "capture_seconds_after_trigger": round(capture_seconds, 9),
        },
        "session": {
            "path": str(session_output),
            "sha256": _sha256_file(session_output),
            "wav": session_wav,
            "detected_song_start_frame": onset,
            "detected_song_start_seconds": round(onset / rate, 9),
            "last_audible_frame": last,
        },
        "output": str(output),
        "output_sha256": _sha256_file(output),
        "wav": wav,
        "loop_status": "one-shot",
        "source_duration_seconds": round(float(loop["duration_seconds"]), 9),
        "source_note_span_seconds": round(span, 9),
        "captured_seconds": round(frames / rate, 9),
    }
    output.with_suffix(".json").write_text(json.dumps(manifest, indent=2) + "\n")
    print(f"captured one-shot: {output} ({frames / rate:.2f} s)")
    return output


def _default_disk_indexes(images: list[dict[str, object]]) -> list[int]:
    indexes = list(range(1, len(images) + 1))
    boot = next(
        (
            index for index, image in enumerate(images, 1)
            if "system" in str(image["member"]).casefold()
        ),
        1,
    )
    return [boot, *(index for index in indexes if index != boot)][:4]


def capture(args: argparse.Namespace, repo: Path) -> Path:
    catalog_path = args.catalog.resolve()
    if not catalog_path.is_file():
        raise CaptureError(f"extraction catalog is missing: {catalog_path}")
    catalog = json.loads(catalog_path.read_text())
    games = [game for game in catalog["games"] if game["game"] == args.game]
    if len(games) != 1:
        raise CaptureError(f"game is not present exactly once in catalog: {args.game}")
    game = games[0]
    archive = Path(game["archive"])
    if not archive.is_file():
        raise CaptureError(f"source disk archive is missing: {archive}")
    profile = PROFILES.get(args.game)
    indexes = (args.disk or (profile.disks if profile else None)
               or _default_disk_indexes(game["images"]))
    if len(indexes) > 4 or len(set(indexes)) != len(indexes):
        raise CaptureError("select one to four unique --disk indexes")
    if any(index < 1 or index > len(game["images"]) for index in indexes):
        raise CaptureError(
            f"--disk index must be between 1 and {len(game['images'])}"
        )

    # One private copy per song: a game may write to its disks, and parallel
    # captures must never share a writable image.
    disk_dir = args.disk_dir / args.game / (args.song or "session")
    disk_dir.mkdir(parents=True, exist_ok=True)
    swap_images = sorted({image for _, _, image in (profile.swaps if profile else ())
                          if image})

    def extract(index: int) -> tuple[dict[str, object], Path]:
        image = game["images"][index - 1]
        data = _read_member(archive, image["member"])
        digest = _sha256_bytes(data)
        if digest != image["sha256"]:
            raise CaptureError(
                f"disk image hash mismatch: {archive}:{image['member']}"
            )
        extension = PurePosixPath(image["member"]).suffix.lower()
        target = disk_dir / f"disk{index:02d}{extension}"
        target.write_bytes(data)
        return image, target

    disks: list[dict[str, object]] = []
    for slot, index in enumerate(indexes, 1):
        image, target = extract(index)
        disks.append({
            "slot": slot,
            "source_index": index,
            "member": image["member"],
            "path": str(target.resolve()),
            "sha256": image["sha256"],
        })
    swap_paths: dict[int, str] = {}
    for index in swap_images:
        image, target = extract(index)
        swap_paths[index] = str(target.resolve())
        disks.append({
            "slot": None,
            "source_index": index,
            "member": image["member"],
            "path": str(target.resolve()),
            "sha256": image["sha256"],
            "swapped_in": [
                {"frame": frame, "drive": drive}
                for frame, drive, swap in profile.swaps if swap == index
            ],
        })

    mame = args.mame or (Path(shutil.which("mame")) if shutil.which("mame") else None)
    if mame is None or not mame.is_file():
        raise CaptureError("MAME is not installed or --mame does not name a file")
    rompath = _rompath(repo, args.rompath)
    _verify_bios(mame, rompath)
    output = args.output.resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    if output.exists() and not args.overwrite:
        raise CaptureError(f"capture already exists: {output}; use --overwrite")
    mame_version = subprocess.run(
        [str(mame), "-version"], text=True, capture_output=True
    ).stdout.strip()

    if args.song:
        if profile is None:
            raise CaptureError(
                f"no headless profile for {args.game}; "
                f"profiles exist for {', '.join(sorted(PROFILES))}")
        midi_path, loop = _loop_for_song(game, args.song)
        if loop.get("start_seconds") is None:
            source_start = period = 0.0
            body_seconds = float(loop["duration_seconds"]) + ONE_SHOT_TAIL_SECONDS
        else:
            source_start = float(loop["start_seconds"])
            period = float(loop["period_seconds"])
            body_seconds = source_start + args.loop_passes * period
        # Leave enough raw tail for onset detection and clock granularity.  The
        # delivered WAV is cut to the measured, clock-adjusted duration below.
        capture_seconds = body_seconds + 4.0
        session_output = (
            args.session_output.resolve()
            if args.session_output
            else output.with_name(f"{output.stem}-session{output.suffix}")
        )
        if session_output == output:
            raise CaptureError("--session-output and --output must differ")
        session_output.parent.mkdir(parents=True, exist_ok=True)
        if session_output.exists() and not args.overwrite:
            raise CaptureError(
                f"session capture already exists: {session_output}; use --overwrite"
            )
        lua = _automation_lua(profile, args.song, capture_seconds, swap_paths)
        with tempfile.NamedTemporaryFile(
            "w", suffix=".lua", prefix="x68k-fm-", dir=output.parent,
            encoding="utf-8",
            delete=False,
        ) as script:
            script.write(lua)
            script_path = Path(script.name)
        # A fresh SRAM per boot.  MAME's default nvram directory is shared by
        # every x68000 session, and the IPL updates SRAM on each boot, so a
        # shared file makes captures drift run to run (and races in --jobs).
        state_dir = disk_dir / "mame_state"
        shutil.rmtree(state_dir, ignore_errors=True)
        (state_dir / "nvram").mkdir(parents=True)
        (state_dir / "cfg").mkdir()
        command = [
            str(mame), "x68000",
            "-rompath", rompath,
            "-noreadconfig",
            "-nvram_directory", str(state_dir / "nvram"),
            "-cfg_directory", str(state_dir / "cfg"),
            "-nothrottle",
            "-video", "none",
            "-seconds_to_run", str(math.ceil(180 + capture_seconds)),
            "-volume", "0",
            "-samplerate", str(args.sample_rate),
            "-wavwrite", str(session_output),
            "-skip_gameinfo",
            "-autoboot_script", str(script_path),
        ]
        for disk in disks:
            if disk["slot"]:
                command.extend((f"-flop{disk['slot']}", str(disk["path"])))
        if args.dry_run:
            print(" ".join(command))
            script_path.unlink(missing_ok=True)
            return output
        print(
            f"Capturing {args.game} {args.song} headlessly through MAME...",
            flush=True,
        )
        environment = os.environ.copy()
        environment["SDL_VIDEODRIVER"] = "dummy"
        environment["SDL_AUDIODRIVER"] = "dummy"
        try:
            stdout, exit_hang = _run_mame(command, environment)
        finally:
            script_path.unlink(missing_ok=True)
        events = _capture_events(stdout)
        play_event = f"play_{args.song}"
        if play_event not in events:
            raise CaptureError(f"MAME never reached {play_event}")
        play_time = events[play_event]
        if not session_output.is_file():
            raise CaptureError(
                f"MAME exited without producing {session_output}"
            )
        session_wav = _wav_info(session_output)
        actual_rate = session_wav["sample_rate"]
        if actual_rate != args.sample_rate:
            raise CaptureError(
                "MAME ignored the requested sample rate: "
                f"requested {args.sample_rate}, captured {actual_rate}"
            )
        for disk in disks:
            after = _sha256_file(Path(str(disk["path"])))
            disk["sha256_after"] = after
            disk["modified_during_session"] = after != disk["sha256"]

        if exit_hang:
            print(f"note: MAME hung after exiting {args.song}; killed it "
                  "once the session WAV was closed", flush=True)
        onset = _first_audible_frame(session_output, play_time)
        if not period:
            return _finish_one_shot(
                args, profile, game, archive, mame, mame_version, disks,
                midi_path, loop, session_output, session_wav, onset,
                play_time, capture_seconds, output)
        try:
            timing = _measure_repeat_period(
                session_output, onset, source_start, period
            )
        except CaptureError:
            # A converted tempo can round the period by a few hundredths of a
            # percent (Daimakaimura song09: 20.864 s played against 20.870 s
            # nominal), just past the default +-0.02% search.  Retry at
            # +-0.1%; the same NCC floor still has to be met.
            try:
                timing = _measure_repeat_period(
                    session_output, onset, source_start, period, 0.001
                )
            except CaptureError:
                # The YM2151 keeps operator phase across key-on, so a later
                # pass can repeat in its envelope yet not in its waveform
                # (SF2CE song10: pass 1->2 NCC 0.6, pass 2->3 below zero).
                # Measure the first pair instead; same floor.
                timing = _measure_repeat_period(
                    session_output, onset, source_start, period, 0.001, 1
                )
        measured_period = int(timing["measured_period_samples"])
        clock_scale = float(timing["clock_scale"])
        first_loop_start = round(source_start * actual_rate * clock_scale)
        output_frames = first_loop_start + args.loop_passes * measured_period
        wav = _write_stereo_segment(
            session_output, output, onset, output_frames
        )
        # Loop over the pair that was measured: the settled second pass
        # normally, the first when only passes 1->2 agree in waveform, so the
        # crossfade always joins two in-phase copies.
        settled_passes = (1 if args.loop_passes >= 2
                          and timing.get("first_pass", 2) == 2 else 0)
        loop_start = first_loop_start + settled_passes * measured_period
        loop_end = loop_start + measured_period
        loop_start_seconds = loop_start / actual_rate
        loop_end_seconds = loop_end / actual_rate
        _append_smpl_loop(output, loop_start, loop_end, actual_rate)
        wav = _wav_info(output)
        source_loop = {
            key: value for key, value in loop.items()
            if key != "duration_seconds"
        }
        manifest = {
            "schema": "cpsplus-x68000-mame-song-v1",
            "game": args.game,
            "song": args.song,
            "machine": "x68000",
            "mame": str(mame.resolve()),
            "mame_version": mame_version,
            "archive": str(archive.resolve()),
            "archive_sha256": game["archive_sha256"],
            "disks": disks,
            "timing_reference": str(midi_path.resolve()),
            "timing_reference_sha256": _sha256_file(midi_path),
            "capture_timing_adjustment": timing,
            "automation": {
                "profile": profile.name,
                "music_test_value": _song_number(args.song) + profile.value_offset,
                "play_seconds": round(play_time, 9),
                "capture_seconds_after_trigger": round(capture_seconds, 9),
            },
            "session": {
                "path": str(session_output),
                "sha256": _sha256_file(session_output),
                "wav": session_wav,
                "detected_song_start_frame": onset,
                "detected_song_start_seconds": round(
                    onset / actual_rate, 9
                ),
            },
            "output": str(output),
            "output_sha256": _sha256_file(output),
            "wav": wav,
            "loop_status": ("consensus-period" if loop.get("consensus")
                            else "embedded-global"),
            "loop_candidate": {
                "strategy": (
                    "second captured pass after one FM/ADPCM settling pass"
                    if settled_passes else "first captured pass"
                ),
                "settled_passes": settled_passes,
                "start_seconds": round(loop_start_seconds, 9),
                "end_seconds": round(loop_end_seconds, 9),
                "period_seconds": round(measured_period / actual_rate, 9),
                "source_period_seconds": round(period, 9),
                "start_sample": loop_start,
                "end_sample": loop_end,
                "wav_smpl_end_is_inclusive": loop_end - 1,
                "source_loop": source_loop,
            },
        }
        sidecar = output.with_suffix(".json")
        sidecar.write_text(json.dumps(manifest, indent=2) + "\n")
        print(f"captured song: {output}; manifest: {sidecar}")
        return output

    command = [
        str(mame), "x68000",
        "-rompath", rompath,
        "-noreadconfig",
        "-window", "-nomaximize",
        "-volume", "0",
        "-samplerate", str(args.sample_rate),
        "-wavwrite", str(output),
        "-skip_gameinfo",
    ]
    for disk in disks:
        if disk["slot"]:
            command.extend((f"-flop{disk['slot']}", str(disk["path"])))
    if args.dry_run:
        print(" ".join(command))
        return output
    print(
        "MAME is recording the complete session. Select/play one song, let "
        "a looped cue run for at least three passes, then exit MAME.",
        flush=True,
    )
    result = subprocess.run(command)
    if result.returncode:
        raise CaptureError(f"MAME exited with status {result.returncode}")
    if not output.is_file():
        raise CaptureError(f"MAME exited without producing {output}")
    for disk in disks:
        after = _sha256_file(Path(str(disk["path"])))
        disk["sha256_after"] = after
        disk["modified_during_session"] = after != disk["sha256"]
    session = {
        "schema": "cpsplus-x68000-mame-session-v1",
        "game": args.game,
        "machine": "x68000",
        "mame": str(mame.resolve()),
        "mame_version": mame_version,
        "sample_rate": args.sample_rate,
        "archive": str(archive.resolve()),
        "archive_sha256": game["archive_sha256"],
        "disks": disks,
        "output": str(output),
        "output_sha256": _sha256_file(output),
        "note": (
            "Session WAV includes boot/menu audio. Isolate the selected song, "
            "then apply its cataloged FM loop relative to the musical start."
        ),
    }
    sidecar = output.with_suffix(".json")
    sidecar.write_text(json.dumps(session, indent=2) + "\n")
    print(f"captured session: {output}; manifest: {sidecar}")
    return output


def self_test() -> None:
    assert _sha256_bytes(b"test") == (
        "9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08"
    )
    assert PurePosixPath("folder/DISK_1.XDF").suffix.lower() == ".xdf"
    assert _default_disk_indexes([
        {"member": "DISK_1.XDF"}, {"member": "DISK_2.XDF"},
        {"member": "SYSTEM.XDF"},
    ]) == [3, 1, 2]
    assert _song_number("song00") == 0
    assert _song_number("song0A") == 10
    actions, play_frame = _profile_actions(PROFILES["ffight"], "song02")
    assert [field for _, field, _ in actions].count("P1 Right") == 3
    assert actions[-1] == (7200, "XF1", "play_song02")
    assert play_frame == 7200
    lua = _automation_lua(PROFILES["ffight"], "song00", 12.5)
    assert "local capture_seconds = 12.500000000" in lua
    assert "pressed[action[2]] = true" in lua
    actions, play_frame = _profile_actions(PROFILES["sf2ce"], "song00")
    assert actions[-2] == (7500, "P1 Right", "select_music_test_01")
    assert actions[-1] == (7560, "P1 B", "play_song00")
    actions, play_frame = _profile_actions(PROFILES["daimakaimura"], "song00")
    assert actions[-1] == (4520, "P1 B", "play_song00")
    actions, play_frame = _profile_actions(PROFILES["daimakaimura"], "song02")
    assert actions[-1] == (4620, "P1 B", "play_song02")
    actions, play_frame = _profile_actions(PROFILES["daimakaimura"], "song1a")
    assert actions[-1] == (4520 + 26 * 40 + 20, "P1 B", "play_song1a")
    assert _profile_patches(PROFILES["daimakaimura"], "song1a") == [
        (4460, 0x8ff4a, bytes.fromhex("0c07001a"), bytes.fromhex("0c07001b"))]
    assert _profile_patches(PROFILES["daimakaimura"], "song19") == []
    assert '{ 4460, 589642, "0c07001a", "0c07001b" },' in _automation_lua(
        PROFILES["daimakaimura"], "song1a", 1.0)
    lua = _automation_lua(PROFILES["sf2ce"], "song00", 1.0, {3: "/d/disk03.dim"})
    assert '{ 3600, 1, nil },' in lua and '{ 3720, 1, "/d/disk03.dim" },' in lua
    assert _lua_str(RETRY_KEY) in lua and "\\u" not in lua
    with tempfile.TemporaryDirectory() as temporary:
        # 96 ticks per quarter at the default 120 BPM: 96 ticks = 0.5 s.
        midi_path = Path(temporary) / "loops.mid"
        track = b"\x00\xff\x2f\x00"
        midi_path.write_bytes(
            b"MThd" + struct.pack(">IHHH", 6, 0, 1, 96)
            + b"MTrk" + struct.pack(">I", len(track)) + track)

        def parts(*rows):
            return {"duration_seconds": 10.0, "loop_tracks": [
                {"start_tick": start, "period_ticks": period}
                for start, period in rows]}
        # song26's shape: nested 72/144/192/288 cycles inside 1152, one pad off
        loop = _consensus_loop(midi_path, parts(
            (672, 1152), (96, 288), (96, 72), (96, 192), (96, 144), (38, 1786)))
        assert loop and loop["period_ticks"] == 1152 and loop["start_tick"] == 672
        assert loop["start_seconds"] == 3.5 and loop["period_seconds"] == 6.0
        assert _consensus_loop(midi_path, parts((0, 100), (0, 170), (0, 230))) is None
    events = _capture_events(
        "X68K_FM_CAPTURE frame=7560 time=128.250000000 action=play_song00\n")
    assert events == {"play_song00": 128.25}

    with tempfile.TemporaryDirectory() as temporary:
        root = Path(temporary)
        source_path = root / "six-channel.wav"
        target_path = root / "stereo.wav"
        sample_rate = 8000
        silent_frames = 100
        audible_frames = 300
        samples = array("h")
        samples.extend([0] * silent_frames * 6)
        for frame in range(audible_frames):
            samples.extend((100 + frame, -(100 + frame), 0, 0, 0, 0))
        if sys.byteorder != "little":
            samples.byteswap()
        with wave.open(str(source_path), "wb") as target:
            target.setnchannels(6)
            target.setsampwidth(2)
            target.setframerate(sample_rate)
            target.writeframes(samples.tobytes())
        assert _first_audible_frame(source_path, 0.0) == silent_frames
        info = _write_stereo_segment(
            source_path, target_path, silent_frames, audible_frames
        )
        assert info == {
            "encoding": 1,
            "channels": 2,
            "sample_rate": sample_rate,
            "bits_per_sample": 16,
            "frames": audible_frames,
        }
        _append_smpl_loop(target_path, 80, 240, sample_rate)
        payload = target_path.read_bytes()
        offset = payload.index(b"smpl")
        assert struct.unpack_from("<I", payload, offset + 4)[0] == 60
        loop_start, loop_end = struct.unpack_from(
            "<II", payload, offset + 8 + 44
        )
        assert (loop_start, loop_end) == (80, 239)
        assert struct.unpack_from("<I", payload, 4)[0] == len(payload) - 8

        repeat_path = root / "repeat.wav"
        source_start = 800
        nominal_period = 4000
        actual_period = 4004
        pattern = array(
            "h",
            (((index * 7919) % 20001) - 10000 for index in range(actual_period)),
        )
        repeated = array("h", [0] * source_start)
        for _ in range(3):
            repeated.extend(pattern)
        stereo = array("h")
        for sample in repeated:
            stereo.extend((sample, sample))
        if sys.byteorder != "little":
            stereo.byteswap()
        with wave.open(str(repeat_path), "wb") as target:
            target.setnchannels(2)
            target.setsampwidth(2)
            target.setframerate(sample_rate)
            target.writeframes(stereo.tobytes())
        timing = _measure_repeat_period(
            repeat_path, 0, source_start / sample_rate,
            nominal_period / sample_rate,
        )
        assert timing["period_delta_samples"] == 4
        assert timing["measured_period_samples"] == actual_period
        assert float(timing["ncc"]) > 0.99
    print("capture_x68k_fm_mame self-test: OK")


def main(argv: list[str] | None = None) -> int:
    repo = Path(__file__).resolve().parents[2]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--self-test", action="store_true")
    parser.add_argument(
        "--catalog", type=Path,
        default=repo / "cpsplus" / "work" / "x68000" / "export" / "catalog.json",
    )
    parser.add_argument(
        "--disk-dir", type=Path,
        default=repo / "cpsplus" / "work" / "x68000" / "mame_disks",
    )
    parser.add_argument(
        "--output", type=Path,
        default=repo / "cpsplus" / "work" / "x68000" / "capture" / "fm" / "session.wav",
    )
    parser.add_argument("--mame", type=Path)
    parser.add_argument("--rompath", type=Path, action="append")
    parser.add_argument("--game", required=False)
    parser.add_argument(
        "--disk", type=int, action="append",
        help=(
            "1-based source disk to mount (repeatable; default: system/boot "
            "disk followed by up to three data disks)"
        ),
    )
    parser.add_argument("--sample-rate", type=int, default=48000)
    parser.add_argument(
        "--song",
        help=(
            "capture one song headlessly (songXX; currently Final Fight only)"
        ),
    )
    parser.add_argument(
        "--session-output", type=Path,
        help="optional path for the complete boot/menu/song MAME WAV",
    )
    parser.add_argument(
        "--loop-passes", type=int, default=3,
        help="complete source loop passes to retain (default: 3)",
    )
    parser.add_argument(
        "--all-songs", type=Path, metavar="DIR",
        help="capture every FM song of --game headlessly into DIR",
    )
    parser.add_argument(
        "--jobs", type=int, default=4,
        help="parallel MAME sessions for --all-songs (default: 4)",
    )
    parser.add_argument(
        "--keep-sessions", action="store_true",
        help="with --all-songs, keep each complete session WAV",
    )
    parser.add_argument("--overwrite", action="store_true")
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args(argv)
    if args.self_test:
        self_test()
        return 0
    if not args.game:
        parser.error("--game is required")
    if args.sample_rate < 8000:
        parser.error("--sample-rate must be at least 8000")
    if args.loop_passes < 2:
        parser.error("--loop-passes must be at least 2")
    if args.all_songs:
        return capture_all(args, repo)
    capture(args, repo)
    return 0


def capture_all(args: argparse.Namespace, repo: Path) -> int:
    """Capture every FM song of one game, one fresh MAME boot per song."""
    catalog = json.loads(args.catalog.resolve().read_text())
    game = next(g for g in catalog["games"] if g["game"] == args.game)
    # Converted sequences only: a bank file without one (Daimakaimura's
    # song1b) has no timing reference and is not a song of the reviewed map.
    songs = sorted(Path(str(path)).stem.lower() for path in game["fm"]["songs"])
    out_dir = args.all_songs.resolve()
    out_dir.mkdir(parents=True, exist_ok=True)

    def one(song: str) -> tuple[str, str | None]:
        output = out_dir / f"{song}.wav"
        if (output.is_file() and output.with_suffix(".json").is_file()
                and not args.overwrite):
            return song, None
        song_args = argparse.Namespace(**vars(args))
        song_args.song, song_args.output = song, output
        song_args.session_output = out_dir / f"{song}-session.wav"
        song_args.overwrite = True
        try:
            capture(song_args, repo)
        except CaptureError as exc:
            return song, str(exc)
        if not args.keep_sessions:
            song_args.session_output.unlink(missing_ok=True)
        return song, None

    with ThreadPoolExecutor(max_workers=max(1, args.jobs)) as pool:
        results = list(pool.map(one, songs))
    failed = [(song, error) for song, error in results if error]
    for song, error in failed:
        print(f"FAILED {song}: {error}", file=sys.stderr)
    print(f"{args.game}: {len(songs) - len(failed)}/{len(songs)} songs captured "
          f"in {out_dir}")
    return 1 if failed else 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (
        CaptureError, KeyError, OSError, ValueError, wave.Error,
        json.JSONDecodeError, zipfile.BadZipFile,
    ) as exc:
        print(f"capture_x68k_fm_mame: error: {exc}", file=sys.stderr)
        raise SystemExit(1)
