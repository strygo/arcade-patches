#!/usr/bin/env python3
"""Render one X68000 external-MIDI soundtrack to FLAC, from a disk-image
archive you own and an SC-55 ROM set you own.

This is the kit-side driver for the three X68000 MIDI packs
(Daimakaimura / Ghouls'n Ghosts, Street Fighter II' CE, Super Street
Fighter II).  make_packs.py calls it before build_pack.py; you can also run
it by hand.  It chains the tools in tools/:

  1. Fetch the verified prebuilt decoders and headless SC-55 renderer,
       or install them from the offline tools bundle. No compiler is needed.
  2. extract_x68k_music.py   disk images -> the game's MIDI sequence bank
  3. render_x68k_sc55.py     each song through the SC-55 emulation (the slow
                             part: roughly 15 s of render per minute of music,
                             so 10 min to an hour per game; --jobs helps)
  4. export_x68k_midi_flac.py  48 kHz loop-tagged FLAC, what build_pack.py reads

Only pinned helper binaries are downloaded. Disk images and SC-55 firmware are never fetched, and the
renders stay under work/ on your machine.

Usage:
  python3 make_x68k_flac.py --game ssf2 --archive /disks/ssf2_x68000.zip \\
      --sc55-rom-dir /roms/sc55 [--jobs 4] [--work DIR] [--keep-wav]

The last line printed is the directory holding the finished FLACs.
"""
from __future__ import annotations

# BEGIN ARCADE PYTHON BOOTSTRAP
import sys as _arcade_sys
from pathlib import Path as _ArcadePath
_arcade_sys.path.insert(0, str(_ArcadePath(__file__).resolve().parents[1]))
from kit_python import bootstrap as _arcade_bootstrap
_arcade_bootstrap()
# END ARCADE PYTHON BOOTSTRAP

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

# abspath, not resolve(): on Windows resolve() turns a mapped drive into \\server\share
HERE = Path(os.path.abspath(__file__)).parent
TOOLS = HERE / "tools"
sys.path.insert(0, str(TOOLS))
from render_x68k_sc55 import KNOWN_ROMSETS, ROM_FILES, _firmware  # noqa: E402

REQUIRED_FIRMWARE = "SC-55 v1.21"
GAMES = {
    # slug: (title, expected FLAC count)
    "daimakaimura": ("Daimakaimura / Ghouls'n Ghosts", 27),
    "sf2ce": ("Street Fighter II' Champion Edition", 46),
    "ssf2": ("Super Street Fighter II", 63),
}


def run(argv: list[str]) -> None:
    print("+ " + " ".join(str(a) for a in argv), flush=True)
    r = subprocess.run([str(a) for a in argv])
    if r.returncode:
        sys.exit(f"step failed ({r.returncode}); see the message above")


def need(binary: str, why: str) -> None:
    if shutil.which(binary) is None:
        sys.exit(f"{binary} is not on PATH; it is needed to {why}")


def check_firmware(rom_dir: Path) -> None:
    try:
        _, revision = _firmware(rom_dir, "mk1")
    except Exception as exc:  # RenderError or OSError
        sys.exit(str(exc))
    if revision != REQUIRED_FIRMWARE:
        want = KNOWN_ROMSETS[REQUIRED_FIRMWARE]
        sys.exit(
            f"{rom_dir} holds an SC-55 ROM set this kit does not recognize "
            f"({revision}).  The packs were rendered with the original "
            f"{REQUIRED_FIRMWARE} set: " + ", ".join(ROM_FILES["mk1"])
            + " with sha256 " + ", ".join(f"{k}={v[:12]}…" for k, v in want.items())
        )


def flac_ready(flac_dir: Path, count: int) -> bool:
    catalog = flac_dir.parent / "catalog.json"
    if not catalog.is_file():
        return False
    try:
        files = json.loads(catalog.read_text(encoding="utf-8")).get("files", [])
    except (OSError, ValueError):
        return False
    done = [f for f in files if (flac_dir / f"{f['song']}.flac").is_file()
            and hashlib.sha256((flac_dir / f"{f['song']}.flac").read_bytes()).hexdigest()
            == f.get('output_sha256')]
    return len(done) == count and len(list(flac_dir.glob("song*.flac"))) == count


def main() -> int:
    from pack.media_tools import configure, add_arguments, ffmpeg_exe, ffprobe_exe, optional_tool
    ap = argparse.ArgumentParser(
        description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--game", required=True, choices=sorted(GAMES))
    ap.add_argument("--archive", required=True, type=Path,
                    help="zip of the game's X68000 DIM/XDF disk images "
                         "(.7z extraction helpers are fetched when needed)")
    ap.add_argument("--sc55-rom-dir", required=True, type=Path,
                    help="directory holding your SC-55 v1.21 ROM dump")
    ap.add_argument("--work", type=Path, default=HERE / "work" / "x68000",
                    help="work directory (default: builder/work/x68000)")
    ap.add_argument("--jobs", type=int, default=max(1, (os.cpu_count() or 2) // 2),
                    help="songs to render at once (default: half your cores)")
    ap.add_argument("--keep-wav", action="store_true",
                    help="keep the raw SC-55 WAV captures after the FLAC "
                         "export (they are large; deleted by default)")
    add_arguments(ap)
    ap.add_argument('--debug', action='store_true', help='show a traceback for troubleshooting')
    a = ap.parse_args(configure(sys.argv[1:]))

    title, count = GAMES[a.game]
    archive = Path(os.path.abspath(a.archive.expanduser()))
    if not archive.is_file():
        sys.exit(f"archive not found: {archive}")
    rom_dir = Path(os.path.abspath(a.sc55_rom_dir.expanduser()))
    work = Path(os.path.abspath(a.work.expanduser()))
    game_work = work / a.game
    flac_dir = game_work / "flac" / a.game

    if flac_ready(flac_dir, count):
        print(f"{title}: {count} FLACs already rendered, reusing {flac_dir}")
        print(flac_dir)
        return 0

    # Preflight: everything that would otherwise fail deep inside a stage.
    check_firmware(rom_dir)
    ffmpeg_exe()
    ffprobe_exe()
    sps_tool = optional_tool('x68k_sps_dec')
    m2_conv = optional_tool('m2seq22mid')
    renderer = optional_tool('sc55')

    export = game_work / "export"
    print(f"\n== {title}: extracting the MIDI bank from {archive.name}")
    run([sys.executable, TOOLS / "extract_x68k_music.py",
         "--archive", f"{a.game}={archive}", "--game", a.game,
         "--output", export, "--sps-tool", sps_tool, "--m2-converter", m2_conv,
         "--loops", "3"])

    capture = game_work / "capture"
    print(f"\n== {title}: rendering {count} songs through the SC-55 "
          f"({a.jobs} at a time; this is the slow part)")
    run([sys.executable, TOOLS / "render_x68k_sc55.py",
         "--catalog", export / "catalog.json", "--renderer", renderer,
         "--rom-dir", rom_dir, "--output", capture, "--game", a.game,
         "--jobs", str(a.jobs)])

    print(f"\n== {title}: exporting loop-tagged FLAC")
    run([sys.executable, TOOLS / "export_x68k_midi_flac.py",
         "--sc55-catalog", capture / "catalog.json",
         "--output", game_work / "flac", "--game", a.game])

    if not flac_ready(flac_dir, count):
        sys.exit(f"{title}: expected {count} FLACs in {flac_dir}")
    if not a.keep_wav:
        freed = 0
        for wav in (capture / a.game).glob("*.wav"):
            freed += wav.stat().st_size
            wav.unlink()
        if freed:
            print(f"removed the raw captures ({freed / 1e9:.1f} GB); the FLACs "
                  f"keep everything the pack builder needs")
    print(f"\n{title}: {count} FLACs ready")
    print(flac_dir)
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except (OSError, ValueError) as exc:
        if '--debug' in sys.argv:
            raise
        print('ERROR: '+str(exc), file=sys.stderr)
        sys.exit(1)
