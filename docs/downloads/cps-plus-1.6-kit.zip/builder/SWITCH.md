# The USF2 Remix pack: from the Switch game

Ultra Street Fighter II: The Final Challengers on Nintendo Switch carries
two scores: the arcade originals and a complete remixed soundtrack. This
pack is the remix, mapped onto the arcade music commands, so it plays in
Super Street Fighter II, Super Street Fighter II Turbo (with SSF2X), the
EX and Grand Master Challenge builds, and Hyper Street Fighter II. It holds
65 tracks. The select screen of Turbo, which USF2 does not score separately,
uses the remix's SSF2 select theme. The "Here comes a new challenger" sting
and HSF2's READY TO FIGHT cue stay as the arcade plays them.

## What you need

- **The game's .nsp**: the USA base game, title 01007330027EE000, version 0.
  Not an update or DLC package, and not inside a .zip or .rar: extract it
  first. The builder checks the file against the verified one and refuses
  any other.
- **Your prod.keys**. The builder hands its path to NSTool, which decrypts
  the game's files with it. The keys are read where they are, and never
  copied into the kit, the output or the packs.
- **Verified prebuilt helpers**, fetched on demand or supplied through
  --tools-bundle and --offline. No compiler is needed for this pack.
- **About 4 GB of free space** while it runs. NSTool writes a temporary copy
  of the game's 2.9 GB program archive to extract the music, and the build
  deletes it afterwards.

Fill in `usf2_nsp` and `switch_prod_keys` in `discs.toml` and run
`make_packs.py` as usual, or build just this pack with
`python3 make_packs.py --only usf2-remix`.

## What "verified" means here

The game stores its music as Opus. The decoder is libopus built in fixed
point, with its processor-specific code turned off, so decoding is integer
arithmetic and every computer produces the same samples. That is what lets
the kit check your pack against one published hash, the same on a Mac, on
Windows and on Linux. A floating-point Opus decoder would not do this:
ffmpeg's, for one, rounds differently depending on the processor's vector
instructions.

If the build stops before decoding, it names the file that differed: the
.nsp (a different region, version or dump), or the program archive NSTool
extracted from it (usually a keys file without the keys this game needs).
