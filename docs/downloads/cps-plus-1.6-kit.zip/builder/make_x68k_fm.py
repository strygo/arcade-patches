#!/usr/bin/env python3
"""Record the X68000 FM soundtrack of Super Street Fighter II with MAME.

The X68000 port plays its own FM music (YM2151 + OKI ADPCM) through the
game's music test.  This script boots your disk images in MAME once per song,
plays that song from the music test and records it, then leaves the
recordings for the pack builder, which checks each against its pinned digest.

You supply the game's disk images and MAME's x68000 BIOS set; nothing is
downloaded except the two small open-source converters the MIDI packs already
fetch as verified prebuilt helpers (they read the game's sequence data, which the recording is timed
against).

  python3 make_x68k_fm.py --game ssf2 --archive /disks/ssf2_x68000.zip \\
      --bios-dir /mame/roms [--mame /path/to/mame] [--jobs 4] [--work DIR]

The last line printed is the directory holding the finished recordings.
"""
from __future__ import annotations

# BEGIN ARCADE PYTHON BOOTSTRAP
import sys as _arcade_sys
from pathlib import Path as _ArcadePath
_arcade_sys.path.insert(0, str(_ArcadePath(__file__).resolve().parents[1]))
from kit_python import bootstrap as _arcade_bootstrap
_arcade_bootstrap()
# END ARCADE PYTHON BOOTSTRAP

import argparse
import csv
import hashlib
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

# abspath, not resolve(): on Windows resolve() turns a mapped drive into \\server\share
HERE = Path(os.path.abspath(__file__)).parent
TOOLS = HERE / "tools"
sys.path.insert(0, str(TOOLS))
from fetch_optional_tools import resolve as optional_tool  # noqa: E402
from tool_controls import add_arguments, configure  # noqa: E402

GAMES = {
    # slug: (title, expected recordings)
    "ssf2": ("Super Street Fighter II", 63),
}
PINS = HERE / "manifests" / "x68k_fm_captures.tsv"


def run(argv: list) -> None:
    print("+ " + " ".join(str(a) for a in argv), flush=True)
    r = subprocess.run([str(a) for a in argv])
    if r.returncode:
        sys.exit(f"step failed ({r.returncode}); see the message above")


def find_mame(configured: Path | None) -> Path | None:
    names = ("mame", "mame.exe", "mame64", "mame64.exe")
    if configured:
        if configured.is_dir():
            return next((configured / n for n in names if (configured / n).is_file()), None)
        return configured if configured.is_file() else None
    for n in names:
        if shutil.which(n):
            return Path(shutil.which(n))
    return None


def pinned_songs(game: str) -> list[str]:
    with PINS.open(newline="", encoding="utf-8") as f:
        rows = csv.DictReader((l for l in f if l.strip() and not l.startswith("#")),
                              delimiter="\t")
        return sorted(r["song"] for r in rows if r["game"] == game)


def captures_ready(out_dir: Path, game: str) -> bool:
    songs = pinned_songs(game)
    try:
        return bool(songs) and all(
            (out_dir / f"{song}.wav").is_file()
            and hashlib.sha256((out_dir / f"{song}.wav").read_bytes()).hexdigest()
            == json.loads((out_dir / f"{song}.json").read_text())['output_sha256']
            for song in songs)
    except (OSError, ValueError, KeyError):
        return False


def main() -> int:
    ap = argparse.ArgumentParser(
        description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--game", required=True, choices=sorted(GAMES))
    ap.add_argument("--archive", required=True, type=Path,
                    help="zip of the game's X68000 DIM/XDF disk images "
                         "(.7z works too if a 7zz/7z binary is on PATH)")
    ap.add_argument("--bios-dir", required=True, type=Path,
                    help="folder holding MAME's x68000 BIOS set (x68000.zip)")
    ap.add_argument("--mame", type=Path,
                    help="MAME executable or its folder (default: PATH)")
    ap.add_argument("--work", type=Path, default=HERE / "work" / "x68000",
                    help="work directory (default: builder/work/x68000)")
    ap.add_argument("--jobs", type=int, default=max(1, (os.cpu_count() or 2) // 2),
                    help="MAME sessions at once (default: half your cores)")
    ap.add_argument("--allow-unpinned", action="store_true",
                    help="also record from a system disk the kit recognizes "
                         "but has no pinned recordings for (the pack is then "
                         "built unverified; see X68000.md)")
    add_arguments(ap)
    ap.add_argument("--debug", action="store_true", help="show diagnostic traceback")
    a = ap.parse_args()
    configure(sys.argv[1:])
    title, count = GAMES[a.game]
    archive = Path(os.path.abspath(a.archive.expanduser()))
    if not archive.is_file():
        sys.exit(f"archive not found: {archive}")
    bios = Path(os.path.abspath(a.bios_dir.expanduser()))
    if not bios.is_dir():
        sys.exit(f"BIOS folder not found: {bios}")
    work = Path(os.path.abspath(a.work.expanduser()))
    game_work = work / a.game
    out_dir = game_work / "capture_fm" / a.game

    if captures_ready(out_dir, a.game):
        print(f"{title}: {count} recordings already made, reusing {out_dir}")
        print(out_dir)
        return 0

    mame = find_mame(a.mame)
    if mame is None:
        sys.exit("MAME was not found. Install it, or pass --mame (set mame_bin "
                 "in discs.toml).")

    binaries = {name: optional_tool(name) for name in ("x68k_sps_dec", "m2seq22mid")}

    export = game_work / "export"
    print(f"\n== {title}: reading the sound driver and sequences from {archive.name}")
    run([sys.executable, TOOLS / "extract_x68k_music.py",
         "--archive", f"{a.game}={archive}", "--game", a.game,
         "--output", export, "--sps-tool", binaries["x68k_sps_dec"],
         "--m2-converter", binaries["m2seq22mid"], "--loops", "3"])

    print(f"\n== {title}: recording {count} songs in MAME ({a.jobs} at a time)")
    run([sys.executable, TOOLS / "capture_x68k_fm_mame.py",
         "--game", a.game, "--catalog", export / "catalog.json",
         "--disk-dir", game_work / "mame_disks", "--mame", mame,
         "--rompath", bios, "--all-songs", out_dir, "--jobs", str(a.jobs)]
        + (["--allow-unpinned"] if a.allow_unpinned else []))

    if not captures_ready(out_dir, a.game):
        sys.exit(f"{title}: expected {count} recordings in {out_dir}")
    shutil.rmtree(game_work / "mame_disks", ignore_errors=True)
    print(f"\n{title}: {count} recordings ready")
    print(out_dir)
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except (OSError, ValueError) as exc:
        if "--debug" in sys.argv:
            raise
        sys.exit(f"Error: {exc}")
