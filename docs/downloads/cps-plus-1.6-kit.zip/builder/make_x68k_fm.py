#!/usr/bin/env python3
"""Record the X68000 FM soundtrack of Super Street Fighter II with MAME.

The X68000 port plays its own FM music (YM2151 + OKI ADPCM) through the
game's music test.  This script boots your disk images in MAME once per song,
plays that song from the music test and records it, then checks every
recording against the pinned digest the pack builder reads.

You supply the game's disk images and MAME's x68000 BIOS set; nothing is
downloaded except the two small open-source converters the MIDI packs already
build (they read the game's sequence data, which the recording is timed
against).

  python3 make_x68k_fm.py --game ssf2 --archive /disks/ssf2_x68000.zip \\
      --bios-dir /mame/roms [--mame /path/to/mame] [--jobs 4] [--work DIR]

The last line printed is the directory holding the finished recordings.
"""
from __future__ import annotations

import argparse
import csv
import os
import shutil
import subprocess
import sys
from pathlib import Path

# abspath, not resolve(): on Windows resolve() turns a mapped drive into \\server\share
HERE = Path(os.path.abspath(__file__)).parent
TOOLS = HERE / "tools"
sys.path.insert(0, str(TOOLS))
from setup_x68k_music_tools import EXE, find_binary, have_compiler  # noqa: E402

GAMES = {
    # slug: (title, expected recordings)
    "ssf2": ("Super Street Fighter II", 63),
}
PINS = HERE / "manifests" / "x68k_fm_captures.tsv"


def run(argv: list) -> None:
    print("+ " + " ".join(str(a) for a in argv), flush=True)
    r = subprocess.run([str(a) for a in argv])
    if r.returncode:
        sys.exit(f"step failed ({r.returncode}); see the message above")


def need(binary: str, why: str) -> None:
    if shutil.which(binary) is None:
        sys.exit(f"{binary} is not on PATH; it is needed to {why}")


def find_mame(configured: Path | None) -> Path | None:
    names = ("mame", "mame.exe", "mame64", "mame64.exe")
    if configured:
        if configured.is_dir():
            return next((configured / n for n in names if (configured / n).is_file()), None)
        return configured if configured.is_file() else None
    for n in names:
        if shutil.which(n):
            return Path(shutil.which(n))
    return None


def put_7zip_on_path() -> None:
    """A Windows install of 7-Zip is not on PATH; the capture tools look there."""
    if shutil.which("7zz") or shutil.which("7z"):
        return
    if os.name == "nt":
        for var in ("ProgramW6432", "ProgramFiles", "ProgramFiles(x86)"):
            root = os.environ.get(var)
            if root and (Path(root) / "7-Zip" / "7z.exe").is_file():
                os.environ["PATH"] = str(Path(root) / "7-Zip") + os.pathsep + os.environ.get("PATH", "")
                return


def pinned_songs(game: str) -> list[str]:
    with PINS.open(newline="", encoding="utf-8") as f:
        rows = csv.DictReader((l for l in f if l.strip() and not l.startswith("#")),
                              delimiter="\t")
        return sorted(r["song"] for r in rows if r["game"] == game)


def captures_ready(out_dir: Path, game: str) -> bool:
    songs = pinned_songs(game)
    return bool(songs) and all(
        (out_dir / f"{s}.wav").is_file() and (out_dir / f"{s}.json").is_file()
        for s in songs)


def main() -> int:
    ap = argparse.ArgumentParser(
        description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--game", required=True, choices=sorted(GAMES))
    ap.add_argument("--archive", required=True, type=Path,
                    help="zip of the game's X68000 DIM/XDF disk images "
                         "(.7z works too if a 7zz/7z binary is on PATH)")
    ap.add_argument("--bios-dir", required=True, type=Path,
                    help="folder holding MAME's x68000 BIOS set (x68000.zip)")
    ap.add_argument("--mame", type=Path,
                    help="MAME executable or its folder (default: PATH)")
    ap.add_argument("--work", type=Path, default=HERE / "work" / "x68000",
                    help="work directory (default: builder/work/x68000)")
    ap.add_argument("--jobs", type=int, default=max(1, (os.cpu_count() or 2) // 2),
                    help="MAME sessions at once (default: half your cores)")
    a = ap.parse_args()

    put_7zip_on_path()
    title, count = GAMES[a.game]
    archive = Path(os.path.abspath(a.archive.expanduser()))
    if not archive.is_file():
        sys.exit(f"archive not found: {archive}")
    bios = Path(os.path.abspath(a.bios_dir.expanduser()))
    if not bios.is_dir():
        sys.exit(f"BIOS folder not found: {bios}")
    work = Path(os.path.abspath(a.work.expanduser()))
    upstream = work / "upstream"
    game_work = work / a.game
    out_dir = game_work / "capture_fm" / a.game

    if captures_ready(out_dir, a.game):
        print(f"{title}: {count} recordings already made, reusing {out_dir}")
        print(out_dir)
        return 0

    need("git", "fetch the pinned open-source tools")
    need("cmake", "build the pinned open-source tools")
    if not have_compiler():
        if os.name != "nt":
            sys.exit("no C/C++ compiler found (cc/gcc/clang, or set CC)")
        print("note: no cl/gcc/clang on PATH; letting CMake look for "
              "Visual Studio (see X68000.md)")
    if archive.suffix.lower() == ".7z" and not (shutil.which("7zz") or shutil.which("7z")):
        sys.exit(f"{archive.name} is a .7z; either install 7-Zip (7zz/7z on "
                 "PATH) or repack the disk images as a .zip")
    mame = find_mame(a.mame)
    if mame is None:
        sys.exit("MAME was not found. Install it, or pass --mame (set mame_bin "
                 "in discs.toml).")

    builds = {
        "x68k_sps_dec": upstream / "ExtractorsDecoders" / "build",
        "m2seq22mid": upstream / "MidiConverters" / "build",
    }
    binaries = {name: find_binary(build, name) for name, build in builds.items()}
    if not all(binaries.values()):
        print(f"\n== {title}: building the music extractors (one-time)")
        run([sys.executable, TOOLS / "setup_x68k_music_tools.py", "--root", upstream])
        binaries = {name: find_binary(build, name) for name, build in builds.items()}
        for name, found in binaries.items():
            if found is None:
                sys.exit(f"{name + EXE} was not found after the build: looked "
                         f"in {builds[name]}")

    export = game_work / "export"
    print(f"\n== {title}: reading the sound driver and sequences from {archive.name}")
    run([sys.executable, TOOLS / "extract_x68k_music.py",
         "--archive", f"{a.game}={archive}", "--game", a.game,
         "--output", export, "--sps-tool", binaries["x68k_sps_dec"],
         "--m2-converter", binaries["m2seq22mid"], "--loops", "3"])

    print(f"\n== {title}: recording {count} songs in MAME ({a.jobs} at a time)")
    run([sys.executable, TOOLS / "capture_x68k_fm_mame.py",
         "--game", a.game, "--catalog", export / "catalog.json",
         "--disk-dir", game_work / "mame_disks", "--mame", mame,
         "--rompath", bios, "--all-songs", out_dir, "--jobs", str(a.jobs)])

    if not captures_ready(out_dir, a.game):
        sys.exit(f"{title}: expected {count} recordings in {out_dir}")
    shutil.rmtree(game_work / "mame_disks", ignore_errors=True)
    print(f"\n{title}: {count} recordings ready")
    print(out_dir)
    return 0


if __name__ == "__main__":
    sys.exit(main())
