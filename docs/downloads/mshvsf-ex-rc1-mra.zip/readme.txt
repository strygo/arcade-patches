Marvel Super Heroes vs. Street Fighter EX · Norimaro, the bosses and more, in every region
==========================================================================================

Version:  rc1 (2026-09-17)
Target:   MAME set 'mshvsfj' (Marvel Super Heroes vs. Street Fighter (Japan 970707))
Hardware: Capcom CPS-2
Patch by: Steve Gordon (https://x.com/strygo)
Website:  https://strygo.github.io/arcade-patches/

ABOUT THIS PROJECT

Marvel Super Heroes vs. Street Fighter kept a lot from you. Outside Japan
there was no Norimaro. Nowhere could you play as Cyber-Akuma or Apocalypse, or
put the same fighter on a team twice. The console ports later added extra
colors and more speeds, but only at home.

EX gives the arcade game all of it. Norimaro is on the select screen in both
builds, with his own ending. Hold Start on any fighter for two seconds and
their hidden version appears, no codes needed, though the old codes still
work. Any two fighters make a team. Cyber-Akuma and Apocalypse are playable
too: hold Start on Akuma for one, on Norimaro for the other. Every fighter
gets the Saturn version's two extra colors, on the HP and HK buttons, and the
service menu goes from three speeds to eight.

The fighting itself is untouched: no changes to moves, damage, hitboxes or the
computer. The USA build also gets a new translation, straight from the
Japanese: sixteen win quotes per fighter instead of eight, and every ending
retold. It comes in two builds, USA and Japan, both with Free Play, and runs
in MAME, HBMAME and on MiSTer.

This is a release candidate. Everything builds and boots; longer play testing
and a MiSTer hardware pass are still to come.

WHAT'S CHANGED

  - Norimaro in both builds, with his own ending
  - Cyber-Akuma and Apocalypse playable: hold Start on Akuma, or on Norimaro.
    Their special moves work on the Easy control setting too
  - Hidden characters with a two-second Start hold; the old codes still work
  - Any team, including the same fighter twice, in a different color (one
    Apocalypse per match, so his stage stays intact)
  - Every ending in both languages, including Mech-Zangief's, Shadow's and
    Dark Sakura's
  - A new English translation from the Japanese: sixteen win quotes per
    fighter instead of eight, and all seventeen standard endings
  - U.S. Agent, Mephisto and Shadow get their names in the fight HUD, which
    the boards leave blank
  - M. Bison's Hyper Combo is Knee Press Nightmare in every region, the name
    Capcom has used since Alpha 3
  - Two extra colors per fighter from the Saturn version: pick your fighter
    with HP or HK
  - Eight game speeds instead of three
  - USA and Japan builds, both with Free Play
  - Gameplay untouched

MISTER SETUP

1. Copy the _Arcade/ folder from this download to the root of your MiSTer SD
   card (the MRAs land in _Arcade/_Arcade Patches/_Enhanced Versions/), or just the MRAs you want:
       "Marvel Super Heroes Vs. Street Fighter EX (USA).mra"
       "_Japan/Marvel Super Heroes Vs. Street Fighter EX (Japan).mra"
2. Have the stock, unmodified romset at games/mame/mshvsfj.zip
   (split MAME sets also need qsound.zip next to it).
3. You need Jotego's jtcps2 core; the standard MiSTer downloader /
   update_all installs it automatically.

Each MRA references your original romset and applies the patch in
memory while the game loads. Nothing on your SD card is modified. Each
build keeps its own settings and saves under its own setname:
    USA              mshvsfex
    Japan            mshvsfej

LEGAL

This is a free, unofficial fan patch. It is not affiliated with or endorsed
by Capcom. All game titles, characters, and artwork remain the property of
their respective owners. You must own the game to use this patch. Do not
sell this patch or distribute it applied to a ROM image.
