CPS+ — arranged CD-era soundtracks for CPS1/CPS2 arcade games on MiSTer
=======================================================================

Version:     1.2 (release candidate)
Hardware:    MiSTer FPGA — CPS-1.0, CPS-1.5 and CPS-2 cores
Project by:  Steve Gordon (https://x.com/strygo)
Website:     https://strygo.github.io/arcade-patches/cps-plus/

CPS+ adds the arranged (CD-quality) soundtracks Capcom recorded for its
console releases to the original arcade games, running on real FPGA
recreations of the arcade hardware.  The game's own sound engine stays
live — the core passively watches the sound commands the game issues and
streams the matching arranged track, while sound effects keep playing
through the original QSound/OKI hardware path.  No game code is modified.

  core source:   https://github.com/strygo/jtcores/tree/cpsplus   (GPL-3.0)

WHAT'S IN THIS KIT — AND WHAT ISN'T
-----------------------------------
This kit contains no copyrighted material: no ROMs, no audio.

  builder/           the pack generator (Python), the per-game trigger maps,
                     the three CPS+ cores, the MRA definitions, the X68000
                     render tools and the PlayStation sound-test recorder
                     (builder/tools/, see X68000.md and PSX.md)
  out/mister/        built by the generator, laid out like your SD card.
                     This is the only folder you copy across.

You supply, as with any MiSTer arcade setup:
  * the arcade ROM zips (MAME naming) in games/mame/ or games/hbmame/
  * disc rips of the Capcom releases that carry each arranged soundtrack
    (see builder/discs.toml for the exact list per pack)
  * for the three X68000 MIDI packs: the games' X68000 disk images and
    your SC-55 ROM set -- the soundtrack is rendered on your machine
    (builder/X68000.md explains what that involves)
  * for the Double Impact and HD Remix packs: the albums themselves, both
    free official downloads -- Capcom's Final Fight: Double Impact remixed
    soundtrack (http://www.finalfightgame.com/remix) and OC ReMix's SSF2T
    HD Remix soundtrack (https://ocremix.org/album/12); discs.toml has the
    direct links
  * for the Strider (PSX Soundtrack) pack: your Strider (USA) PlayStation
    disc, MAME, and MAME's PlayStation ROM sets -- the kit records the
    game's own sound test (builder/PSX.md explains what that involves)

QUICK START
-----------
  1. Edit builder/discs.toml — point it at the disc rips you own.
     Or skip the file and pass discs on the command line:
       python3 builder/make_packs.py --disc mtwins_pce_disc=/discs/chiki.7z
     Run make_packs.py --list to see every pack and the disc it wants.
  2. python3 builder/make_packs.py
       (needs Python 3.11+, numpy, ffmpeg on PATH; the X68000 packs also
       need git, cmake and a C/C++ compiler, and take up to an hour each
       to render -- see builder/X68000.md; the Strider pack needs MAME and
       takes about five minutes to record -- see builder/PSX.md)
     Each built pack is verified byte-for-byte against the published hash,
     so your build is exactly the authored, hardware-tested pack.
  3. Copy the contents of out/mister/ onto your MiSTer SD card
     (/media/fat/), merging with what's already there.  It holds the
     cores, your packs, and the MRAs those packs can load.  See
     INSTALL.md for details.

THREE SPECIAL SETS: GOLD, CD-CUTSCENES AND 30TH ANNIVERSARY MRAS
-----------------------------------------------------------------
Most MRAs here target the stock arcade ROM sets.  Three groups pair CPS+
audio with sets that are not stock:

  * "Street Fighter Alpha 2 Gold (Arrange)" + the other Gold MRAs load
    the SFA2 Gold 8 MiB sets — reconstructed from your own game data by
    the SFA2 Gold kit:  https://strygo.github.io/arcade-patches/sfa2-gold/

  * "Final Fight (Arrange + CD Cutscenes)" loads the Final Fight CD
    cutscene backport set (ffightus01), built by the Final Fight CD
    project:  https://strygo.github.io/arcade-patches/final-fight-cd/

  * "Final Fight 30th Anniversary CPS2 Edition (Arrange)" loads the CPS2
    conversion of Final Fight by grego2d and rotwang (ffightae_cps2.zip),
    distributed through the Arcade Offset project for MiSTer:
    https://github.com/Toryalai1/Arcade_Offset  -- its pack is built from
    the same US Final Fight CD as the CPS-1 arrange pack.

Without those sets installed, these specific MRAs will not load; every
other MRA works with stock MAME-naming ROM sets.

MAKING YOUR OWN PACKS
---------------------
Everything you need is in builder/: PACK_FORMAT.md specifies the trigger
contract and the pack binary layout, builder/pack/README.md is the manual
for the build modes, and build_pack.py is the tool (init <game> →
pack.toml → build → embed into an MRA).  Community packs for any QSound
CPS2 title are a first-class goal of the format.

LICENSES
--------
Cores: GPL-3.0 (see builder/cores/SOURCE_AND_LICENSE.txt).  MRAs, trigger
manifests and the builder are configuration/metadata and code from the
CPS+ project.  The X68000 render path fetches and builds two open-source
projects at pinned revisions (ValleyBell's X68000 decoders and the
Nuked-SC55 emulator, each under its own licence in its checkout), and the
Strider pack runs your own installation of MAME; none of their code is
bundled here.  The arranged recordings remain (c) Capcom —
which is why they are never distributed and always built from your own
discs, disks and ROMs.
