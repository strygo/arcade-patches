#!/usr/bin/env python3
"""Render one X68000 external-MIDI soundtrack to FLAC, from a disk-image
archive you own and an SC-55 ROM set you own.

This is the kit-side driver for the three X68000 MIDI packs
(Daimakaimura / Ghouls'n Ghosts, Street Fighter II' CE, Super Street
Fighter II).  make_packs.py calls it before build_pack.py; you can also run
it by hand.  It chains the tools in tools/:

  1. setup_x68k_music_tools.py / setup_x68k_capture_tools.py
       fetch and build the pinned open-source decoders and the headless
       SC-55 renderer (git + cmake + a C/C++ compiler; one-time, ~5 min)
  2. extract_x68k_music.py   disk images -> the game's MIDI sequence bank
  3. render_x68k_sc55.py     each song through the SC-55 emulation (the slow
                             part: roughly 15 s of render per minute of music,
                             so 10 min to an hour per game; --jobs helps)
  4. export_x68k_midi_flac.py  48 kHz loop-tagged FLAC, what build_pack.py reads

Nothing is downloaded except the two open-source tool repositories at their
pinned revisions.  Disk images and SC-55 firmware are never fetched, and the
renders stay under work/ on your machine.

Usage:
  python3 make_x68k_flac.py --game ssf2 --archive /disks/ssf2_x68000.zip \\
      --sc55-rom-dir /roms/sc55 [--jobs 4] [--work DIR] [--keep-wav]

The last line printed is the directory holding the finished FLACs.
"""
from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
TOOLS = HERE / "tools"
sys.path.insert(0, str(TOOLS))
from render_x68k_sc55 import KNOWN_ROMSETS, ROM_FILES, _firmware  # noqa: E402

REQUIRED_FIRMWARE = "SC-55 v1.21"
GAMES = {
    # slug: (title, expected FLAC count)
    "daimakaimura": ("Daimakaimura / Ghouls'n Ghosts", 27),
    "sf2ce": ("Street Fighter II' Champion Edition", 46),
    "ssf2": ("Super Street Fighter II", 63),
}


def run(argv: list[str]) -> None:
    print("+ " + " ".join(str(a) for a in argv), flush=True)
    r = subprocess.run([str(a) for a in argv])
    if r.returncode:
        sys.exit(f"step failed ({r.returncode}); see the message above")


def need(binary: str, why: str) -> None:
    if shutil.which(binary) is None:
        sys.exit(f"{binary} is not on PATH; it is needed to {why}")


def check_firmware(rom_dir: Path) -> None:
    try:
        _, revision = _firmware(rom_dir, "mk1")
    except Exception as exc:  # RenderError or OSError
        sys.exit(str(exc))
    if revision != REQUIRED_FIRMWARE:
        want = KNOWN_ROMSETS[REQUIRED_FIRMWARE]
        sys.exit(
            f"{rom_dir} holds an SC-55 ROM set this kit does not recognize "
            f"({revision}).  The packs were rendered with the original "
            f"{REQUIRED_FIRMWARE} set: " + ", ".join(ROM_FILES["mk1"])
            + " with sha256 " + ", ".join(f"{k}={v[:12]}…" for k, v in want.items())
        )


def flac_ready(flac_dir: Path, count: int) -> bool:
    catalog = flac_dir.parent / "catalog.json"
    if not catalog.is_file():
        return False
    try:
        files = json.loads(catalog.read_text()).get("files", [])
    except (OSError, ValueError):
        return False
    done = [f for f in files if (flac_dir / f"{f['song']}.flac").is_file()]
    return len(done) == count and len(list(flac_dir.glob("song*.flac"))) == count


def main() -> int:
    ap = argparse.ArgumentParser(
        description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--game", required=True, choices=sorted(GAMES))
    ap.add_argument("--archive", required=True, type=Path,
                    help="zip of the game's X68000 DIM/XDF disk images "
                         "(.7z works too if a 7zz/7z binary is on PATH)")
    ap.add_argument("--sc55-rom-dir", required=True, type=Path,
                    help="directory holding your SC-55 v1.21 ROM dump")
    ap.add_argument("--work", type=Path, default=HERE / "work" / "x68000",
                    help="work directory (default: builder/work/x68000)")
    ap.add_argument("--jobs", type=int, default=max(1, (os.cpu_count() or 2) // 2),
                    help="songs to render at once (default: half your cores)")
    ap.add_argument("--keep-wav", action="store_true",
                    help="keep the raw SC-55 WAV captures after the FLAC "
                         "export (they are large; deleted by default)")
    a = ap.parse_args()

    title, count = GAMES[a.game]
    archive = a.archive.expanduser().resolve()
    if not archive.is_file():
        sys.exit(f"archive not found: {archive}")
    rom_dir = a.sc55_rom_dir.expanduser().resolve()
    work = a.work.expanduser().resolve()
    upstream = work / "upstream"
    game_work = work / a.game
    flac_dir = game_work / "flac" / a.game

    if flac_ready(flac_dir, count):
        print(f"{title}: {count} FLACs already rendered, reusing {flac_dir}")
        print(flac_dir)
        return 0

    # Preflight: everything that would otherwise fail deep inside a stage.
    need("git", "fetch the pinned open-source tools")
    need("cmake", "build the pinned open-source tools")
    if not (os.environ.get("CC") or shutil.which("cc") or shutil.which("gcc")
            or shutil.which("clang")):
        sys.exit("no C compiler found (cc/gcc/clang, or set CC)")
    need("ffmpeg", "write the FLAC files")
    need("ffprobe", "verify the FLAC files")
    if archive.suffix.lower() == ".7z" and not (shutil.which("7zz") or shutil.which("7z")):
        sys.exit(f"{archive.name} is a .7z; either install 7-Zip (7zz/7z on "
                 "PATH) or repack the disk images as a .zip")
    check_firmware(rom_dir)

    sps_tool = upstream / "ExtractorsDecoders" / "build" / "x68k_sps_dec"
    m2_conv = upstream / "MidiConverters" / "build" / "m2seq22mid"
    renderer = upstream / "Nuked-SC55-GUI-Float" / "build" / "nuked-sc55-render"
    if not (sps_tool.is_file() and m2_conv.is_file()):
        print(f"\n== {title}: building the music extractors (one-time)")
        run([sys.executable, TOOLS / "setup_x68k_music_tools.py", "--root", upstream])
    if not renderer.is_file():
        print(f"\n== {title}: building the SC-55 renderer (one-time)")
        run([sys.executable, TOOLS / "setup_x68k_capture_tools.py", "--root", upstream])

    export = game_work / "export"
    print(f"\n== {title}: extracting the MIDI bank from {archive.name}")
    run([sys.executable, TOOLS / "extract_x68k_music.py",
         "--archive", f"{a.game}={archive}", "--game", a.game,
         "--output", export, "--sps-tool", sps_tool, "--m2-converter", m2_conv,
         "--loops", "3"])

    capture = game_work / "capture"
    print(f"\n== {title}: rendering {count} songs through the SC-55 "
          f"({a.jobs} at a time; this is the slow part)")
    run([sys.executable, TOOLS / "render_x68k_sc55.py",
         "--catalog", export / "catalog.json", "--renderer", renderer,
         "--rom-dir", rom_dir, "--output", capture, "--game", a.game,
         "--jobs", str(a.jobs)])

    print(f"\n== {title}: exporting loop-tagged FLAC")
    run([sys.executable, TOOLS / "export_x68k_midi_flac.py",
         "--sc55-catalog", capture / "catalog.json",
         "--output", game_work / "flac", "--game", a.game])

    if not flac_ready(flac_dir, count):
        sys.exit(f"{title}: expected {count} FLACs in {flac_dir}")
    if not a.keep_wav:
        freed = 0
        for wav in (capture / a.game).glob("*.wav"):
            freed += wav.stat().st_size
            wav.unlink()
        if freed:
            print(f"removed the raw captures ({freed / 1e9:.1f} GB); the FLACs "
                  f"keep everything the pack builder needs")
    print(f"\n{title}: {count} FLACs ready")
    print(flac_dir)
    return 0


if __name__ == "__main__":
    sys.exit(main())
