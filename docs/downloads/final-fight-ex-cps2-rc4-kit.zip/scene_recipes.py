"""Replay the qualified scene pieces without the authoring VM or image renderer."""
import json
from pathlib import Path
import sys
from resource_recipe import Resources, require
HERE = Path(__file__).resolve().parent

def scene_bytes(image, extents):
    out = bytearray()
    with Path(image).open('rb') as stream:
        for lba, count in extents:
            data = bytearray()
            for sector in range((count + 2047) // 2048):
                stream.seek((lba + sector) * 2352 + 16)
                block = stream.read(2048)
                require(len(block) == 2048, 'Truncated source scene')
                data.extend(block)
            out.extend(data[:count])
    return bytes(out)

def pieces(edition, discs, roms, work):
    from ffex_kit import builder, data_track
    spike = builder()
    plan = json.loads((HERE / 'scene-recipes.json').read_text(encoding='utf-8'))[edition]
    region = 'us' if edition == 'usa' else 'jp'
    require(discs.get(region) is not None, 'Missing original regional disc')
    image = data_track(discs[region])
    stock = spike.find_archive([roms], 'ffightu' if edition == 'usa' else 'ffightj')
    program = spike.usa_program(stock) if edition == 'usa' else spike.stock_program(stock)
    sources = {'original program': bytes(program), 'original scenes': scene_bytes(image, plan['extents'])}
    catalog = json.loads((HERE / 'resources.json').read_text(encoding='utf-8'))
    resources = Resources(dict(catalog, sources=plan['sources']), (HERE / 'resources.bin').read_bytes(), sources)
    result = dict(manifest=plan['manifest'], inputs_sha256=plan['inputs_sha256'], **{name: resources.emit(row) for name, row in plan['pieces'].items()})
    transform = json.loads((HERE / 'kit.json').read_text(encoding='utf-8')).get('scene_transform')
    require(transform in (None, 'black-cut-prefetch/1'), 'Unknown scene transform')
    if transform:
        from recipe_scene_repairs import credit_checks
        result['program.bin'] = credit_checks(result['program.bin'], result['manifest'])
        from intro_cut_prefetch import transform as prefetch
        result['data.bin'], result['intro_cut_prefetch'] = prefetch(result['program.bin'], result['data.bin'], result['art.bin'])
        result['manifest'] = {**result['manifest'], 'files': {**result['manifest']['files']}}
        from resource_recipe import sha
        result['manifest']['files']['data.bin'] = {**result['manifest']['files']['data.bin'], 'sha256': sha(result['data.bin'])}
        result['manifest']['files']['program.bin'] = {**result['manifest']['files']['program.bin'], 'sha256': sha(result['program.bin'])}
    return result
