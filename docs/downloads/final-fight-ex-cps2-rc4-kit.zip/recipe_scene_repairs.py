"""Bring authenticated November 6 scene recipes to the current engine contract."""

def credit_checks(program, manifest):
    old = bytes.fromhex('4a3900ff80016600000a323c348e')
    new = bytes.fromhex('4a7900ff804c6600000a323c348e')
    result = bytearray(program)
    entries = manifest['entries']
    for name, length in (('ENGINE', 'engine1_len'), ('ENGINE2', 'engine2_len'), ('ENGINE3', 'engine3_len')):
        start = int(entries[name], 16)
        end = start + int(entries[length], 16)
        block = program[start:end]
        if block.count(old) != 1 or new in block:
            raise ValueError('Unknown original title-return credit consumer: ' + name)
        at = start + block.index(old)
        result[at:at + len(old)] = new
    return bytes(result)
