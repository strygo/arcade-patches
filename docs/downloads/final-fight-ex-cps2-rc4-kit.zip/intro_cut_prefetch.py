"""Prepare opaque-black cut cells before a late head changes the camera."""
import hashlib
import struct
DATA = 3211264
DELTAS = 3379200
PALETTES = 3248128
BASE = 20480

def require(ok, message):
    if not ok:
        raise ValueError(message)

def sha(b):
    return hashlib.sha256(b).hexdigest()

def transform(code, data, art):
    require(code[876704:876706] == bytes.fromhex('0c40') and code[876720:876722] == bytes.fromhex('43f9'), 'Unknown opening table consumer')
    count = int.from_bytes(code[876706:876708], 'big')
    table = int.from_bytes(code[876722:876726], 'big')
    require(0 < count < 4096 and DATA <= table and (table + count * 16 <= PALETTES), 'Unknown opening table extent')
    original = bytes(data)
    out = bytearray(data)
    recs = [list(struct.unpack_from('>HHIHHHH', data, table - DATA + i * 16)) for i in range(count)]
    nodes = []
    end = 0
    intervals = []
    for r in recs:
        offset = r[2]
        n = r[3] & 8191
        at = DELTAS - DATA + offset
        require(r[4] > 0 and at >= 0 and (at + n * 6 <= len(data)), 'Unknown delta record extent')
        cells = list(struct.iter_unpack('>3H', data[at:at + n * 6]))
        at += n * 6
        spill = []
        if r[3] & 16384:
            for _ in range(r[4] + 1):
                require(at + 2 <= len(data), 'Unterminated spill stream')
                size = int.from_bytes(data[at:at + 2], 'big')
                at += 2
                if size == 65535:
                    break
                require(at + size * 6 <= len(data), 'Incomplete spill extent')
                spill.append(list(struct.iter_unpack('>3H', data[at:at + size * 6])))
                at += size * 6
            else:
                raise ValueError('Unknown spill lifetime')
        for o, t, p in cells + sum(spill, []):
            require(o % 4 == 0 and o < 16384 and (p < 65536), 'Unknown cell ABI')
        stop = at - (DELTAS - DATA)
        end = max(end, stop)
        if stop > offset:
            intervals.append((offset, stop))
        nodes.append((cells, spill))
    cursor = 0
    for lo, hi in sorted(intervals):
        require(lo == cursor, 'Overlapping or unbound opening delta bytes')
        cursor = hi
    require(cursor == end, 'Incomplete opening delta ownership')
    pens = {}

    def used(tile):
        if tile not in pens:
            off = (tile - BASE) * 128
            require(0 <= off and off + 128 <= len(art), 'Unknown complete source tile')
            raw = art[off:off + 128]
            values = set()
            for y in range(16):
                for x in range(16):
                    b = y * 8 + x // 8 * 4
                    values.add(sum(((raw[b + p] >> 7 - x % 8 & 1) << p for p in range(4))))
            pens[tile] = values
        return pens[tile]

    def black(cell, pal):
        tile, attr = cell
        offset = PALETTES - DATA + pal * 1024 + (attr & 31) * 32
        require(offset >= 0 and offset + 32 <= len(data), 'Unknown palette block')
        return all((p == 15 or int.from_bytes(data[offset + p * 2:offset + p * 2 + 2], 'big') & 4095 == 0 for p in used(tile)))

    def visible(off, r):
        i = off >> 2
        row = i & 15 | (i >> 10 & 3) << 4
        col = i >> 4 & 63
        x = col * 16 - (r[5] + 64) & 1023
        y = row * 16 - (r[6] + 16) & 1023
        return (x < 384 or x > 1008) and (y < 224 or y > 1008)
    start = []
    time = 0
    for r in recs:
        start.append(time)
        time += r[4]
    live = []
    for i, r in enumerate(recs):
        live.extend([i] * r[4])
    stream = {}
    for i, (cells, spills) in enumerate(nodes):
        stream.setdefault(start[i] + bool(recs[i][3] & 8192), []).extend(cells)
        for j, cells2 in enumerate(spills, 1):
            stream.setdefault(start[i] + j, []).extend(cells2)
    before_states = {}
    state = {}
    candidates = []
    frontiers = []
    for i in range(2, count):
        r = recs[i]
        prev = recs[i - 1]
        donor = recs[i - 2]
        jump = abs(r[5] - prev[5]) >= 16 or abs(r[6] - prev[6]) >= 16
        if not (jump and r[3] & 8192 and nodes[i][0]):
            continue
        if not (donor[4] == prev[4] == 1 and (not nodes[i][1]) and (not nodes[i - 2][1])):
            frontiers.append(dict(event=i, reason='no preceding single-frame sink'))
            continue
        prior_palettes = {recs[j][1] & 255 for j in range(max(0, i - 3), i)}
        if len(prior_palettes) != 1 or any((recs[j][3] & 32768 for j in range(i - 2, i + 1))):
            frontiers.append(dict(event=i, reason='unbound preceding palette publication'))
            continue
        candidates.append(i)
    pref_frame = lambda i: start[i - 2] + bool(recs[i - 2][3] & 8192)
    wanted = {f for i in candidates for f in range(pref_frame(i), start[i] + 1)}
    for frame in range(time + 1):
        for o, t, p in stream.get(frame, []):
            state[o] = (t, p)
        if frame in wanted:
            before_states[frame] = dict(state)
    cases = []
    for i in candidates:
        cells = nodes[i][0]
        intervening = {}
        for frame in range(pref_frame(i) + 1, start[i] + 1):
            for o, t, p in stream.get(frame, []):
                intervening.setdefault(o, set()).add((t, p))
        palettes = {recs[j][1] & 255 for j in range(i - 2, min(i + 2, count))}
        old_palette = recs[i - 1][1] & 255
        checked = 0
        eligible = []
        retained = []
        for o, t, p in cells:
            ok = all((black((t, p), pal) for pal in palettes))
            if any((value != (t, p) for value in intervening.get(o, ()))):
                ok = False
            for frame in range(pref_frame(i), start[i] + 1):
                if not ok:
                    break
                old = before_states[frame].get(o, (BASE, 0))
                if visible(o, recs[live[frame]]):
                    if not black(old, old_palette):
                        ok = False
                        break
                    checked += 1
            (eligible if ok else retained).append((o, t, p))
        if not eligible:
            frontiers.append(dict(event=i, reason='no black-equivalent, unsuperseded prefill cells'))
            continue
        nodes[i - 2][0].extend(eligible)
        nodes[i] = (retained, nodes[i][1])
        require(len(nodes[i - 2][0]) <= 8191, 'Prefetch list count overflow')
        cases.append(dict(event=i, donor=i - 2, cells=len(eligible), retained_head_cells=len(retained), visible_black_equivalence_cases=checked, prepared_frames_before_camera=start[i] - pref_frame(i), palette_generations=sorted(palettes), camera_before=recs[i - 1][5:7], camera_after=recs[i][5:7]))
    blob = bytearray()
    for i, (cells, spill) in enumerate(nodes):
        recs[i][2] = len(blob)
        recs[i][3] = recs[i][3] & 57344 | len(cells)
        for cell in cells:
            blob += struct.pack('>3H', *cell)
        if recs[i][3] & 16384:
            for chunk in spill:
                blob += struct.pack('>H', len(chunk))
                for cell in chunk:
                    blob += struct.pack('>3H', *cell)
            blob += b'\xff\xff'
    require(len(blob) == end, 'Prefetch changed the complete delta allocation size')
    for i, r in enumerate(recs):
        struct.pack_into('>HHIHHHH', out, table - DATA + i * 16, *r)
    out[DELTAS - DATA:DELTAS - DATA + end] = blob
    if not cases:
        require(bytes(out) == original, 'No-case profile changed bytes')
    return (bytes(out), dict(schema=1, status='source_bound_black_cut_prefetch', cases=cases, frontiers=frontiers, table=table, records=count, delta_base=DELTAS, delta_bytes=end, original_data_sha256=sha(original), data_sha256=sha(out), no_new_ROM_or_RAM_allocation=True, unchanged_durations_palettes_camera_fields=True, hardware_review=False))
