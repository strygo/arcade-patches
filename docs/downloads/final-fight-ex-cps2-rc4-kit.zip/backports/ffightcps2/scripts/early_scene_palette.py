"""Move the opening's existing palette request ahead of vblank bookkeeping."""
import re
import struct
import hashlib
MAGIC = 17744
MAIN = 877760
CONTROL = 1420
CLAIMS = ((9527296, 9535488, 'complete staged object list'), (9568000, 9568004, 'early palette IRQ tag and emitted flag'))
NAMES = {'palette_main_publish', 'palette_frame_control', 'palette_early_vblank'}
ASM = "\n; Preserve the original vblank body, watchdog and all its entry ABI.\nvblank_entry:\n        bsr.w palette_early_vblank\n        jmp native_vblank_entry\n\npalette_early_vblank:\n        move.w sr,-(sp)\n        movem.l d0-d1/a0-a1,-(sp)\n        move.w #$4550,($91ff00).l\n        clr.w ($91ff02).l\n        cmpi.w #$cafe,($ffffb0).l\n        bne.w @done\n        ori.w #$0700,sr\n        lea ($ffffb0).l,a0\n        move.w 2(a0),d0\n        cmpi.w #2239,d0\n        bcc.w @done                    ; includes FFFF: no valid event yet\n        cmpi.w #OV_MAGIC,(OV_RAM+OV_TAG).l\n        bne.w @done\n        tst.b (OV_RAM+OV_LIVE_N).l\n        bne.w @done\n        tst.b (OV_RAM+OV_PEND_N).l\n        bne.w @done\n        tst.b (OV_RAM+OV_PUB_N).l\n        bne.w @done                    ; preserve native loan/copy/restore order\n        move.w ($ff1288).l,d1\n        cmpi.w #2,d1\n        blt.w @done\n        cmpi.w #8,d1\n        bgt.w @done\n        move.w 8(a0),d1\n        addq.w #1,d1\n        cmpi.w #3,d1\n        bge.w @done                    ; exactly the native liveness decision\n        tst.w ($ff804c).l\n        bne.w @done\n        bsr.w line_now\n        cmpi.w #-22,d1\n        blt.w @done\n        cmpi.w #-12,d1\n        bgt.w @done                    ; late entry keeps the native path\n        ; The original predicate, before this frame advances the record.\n        cmpi.w #1,($ff12ae).l\n        beq.w @fire\n        move.w 2(a0),d0\n        ext.l d0\n        lsl.l #4,d0\n        lea ($310400).l,a1\n        adda.l d0,a1\n        move.w 10(a1),d1\n        btst #7,8(a1)\n        beq.s @normal\n        subq.w #1,d1\n@normal:\n        cmp.w 4(a0),d1\n        bne.w @done\n        tst.w 2(a0)\n        beq.s @fire\n        move.w 2(a1),d0\n        move.w -14(a1),d1\n        eor.w d1,d0\n        andi.w #$00ff,d0\n        beq.s @done\n@fire: move.w #7,($800170).l\n        move.w #$9140,($80010a).l\n        move.w #1,($91ff02).l\n@done: movem.l (sp)+,d0-d1/a0-a1\n        move.w (sp)+,sr\n        rts\n\n; Called only at the original opening's main trigger, with native flags.\npalette_main_publish:\n        move.w sr,-(sp)\n        cmpi.w #$4550,($91ff00).l\n        bne.s @native\n        cmpi.w #1,($91ff02).l\n        bne.s @native\n        move.w (sp)+,ccr\n        move.w #$9140,-(sp)             ; displaced MOVE's exact flags\n        addq.l #2,sp\n        rts\n@native:\n        move.w (sp)+,ccr\n        bra.w palette_publish\n\n; The stock frame writes 003F after the vblank hook. Do not expand the\n; selected pages while the early DMA can still be reading them.\npalette_frame_control:\n        move.w sr,-(sp)\n        cmpi.w #$4550,($91ff00).l\n        bne.s @full\n        cmpi.w #1,($91ff02).l\n        bne.s @full\n        move.w (sp)+,ccr\n        move.w #7,($800170).l\n        rts\n@full: move.w (sp)+,ccr\n        move.w #$003f,($800170).l\n        rts\n"

def entries(listing):
    result = {n: int(pc, 16) for pc, n in re.findall('^([0-9A-F]{8})\\s+(palette_\\w+):\\s*$', listing, re.M) if n in NAMES}
    if set(result) != NAMES:
        raise ValueError('Incomplete early palette callback family')
    return result

def assembly(binding=None):
    if binding is None:
        return ASM
    e = binding['engines'][0]
    if e['name'] != 'opening' or e['main'] != MAIN:
        raise ValueError('Unknown opening binding')
    return ASM.replace('cmpi.w #2239,d0', f"cmpi.w #{e['count']},d0").replace('lea ($310400).l,a1', f"lea (${e['table']:x}).l,a1")

def install(program, labels, publish, binding=None):
    expected = b'N\xb9' + struct.pack('>I', publish) + b'Nq'
    if program[MAIN:MAIN + 8] != expected:
        raise ValueError('Opening main palette request changed')
    if program[CONTROL:CONTROL + 8] != bytes.fromhex('33fc003f00800170'):
        raise ValueError('Native frame palette control writer changed')
    e = binding['engines'][0] if binding else None
    expected_hash = e['prefix_sha256'] if e else '7b03d4e7530ff333add30e60222c29b915a3699701e6a3264e055b058a2fd430'
    if hashlib.sha256(program[877674:MAIN]).hexdigest() != expected_hash:
        raise ValueError('Opening palette predicate entry changed')
    for pc, name in ((MAIN, 'palette_main_publish'), (CONTROL, 'palette_frame_control')):
        program[pc:pc + 8] = b'N\xb9' + struct.pack('>I', labels[name]) + b'Nq'
    return dict(main=MAIN, frame_control=CONTROL, **{'binding': binding} if binding else {})

def callers(raw, program, old, new):
    result = []
    for pc, name in ((MAIN, 'palette_main_publish'), (CONTROL, 'palette_frame_control')):
        if raw[pc:pc + 8] != b'N\xb9' + struct.pack('>I', old[name]) + b'Nq':
            raise ValueError('Unbound early palette callback: ' + name)
        program[pc + 2:pc + 6] = struct.pack('>I', new[name])
        result.append((pc, name))
    return result
