"""Independent output-port contracts on complete final Phoenix archives."""
import argparse
import hashlib
import json
from pathlib import Path
import struct
import zipfile

def require(ok, message):
    if not ok:
        raise ValueError(message)

def sha(data):
    return hashlib.sha256(data).hexdigest()

def program(archive):
    with zipfile.ZipFile(archive) as z:
        names = ('sz3ud.03c', 'sz3ud.04c', 'sz3.05c', 'sz3.06c', 'sz3.07c', 'sz3.08c', 'sz3.09c', 'sz3.10b')
        require(z.read('phoenix.key') == b'\xff' * 20, 'Expected complete dead-key archive')
        data = b''.join((z.read(n) for n in names))
        image = bytearray(len(data))
        image[0::2], image[1::2] = (data[1::2], data[0::2])
        return (bytes(image), {n: sha(z.read(n)) for n in z.namelist()})
SEND = bytes.fromhex('5341744f03006702745f13c20080404008c2000513c2008040400882000513c20080404051c9ffdc4e75')

def audit(image):
    reset = int.from_bytes(image[4:8], 'big')
    require(image[reset:reset + 20] == bytes.fromhex('46fc270033fc0000008040a033fc0f0000804040'), 'Missing reset board initialization')
    refs = []
    data_collisions = []
    allowed = {8405056: {'33fc': {3840, 4040}, '13fc': {15, 79, 111}, '13c2': None}, 8405057: {'13c0': None}, 8405152: {'33fc': {0}}}
    for address, forms in allowed.items():
        target = address.to_bytes(4, 'big')
        for at in range(0, len(image) - 3, 2):
            if image[at:at + 4] != target:
                continue
            if at == 240320 and address == 8405056:
                require(sha(image[240290:240418]) == 'fd7002177464ed7b5cbf0e9f23fa5a72f80da54d150e1cb6b9b13c03dcd38109' and image[238624:238658] == bytes.fromhex('700049f90003aaa2102b0060e54849f400004eb83bec0240001f222c000001016604'), 'Native data collision no longer matches its source/consumer binding')
                data_collisions.append({'address': hex(at), 'table_root': '0x3aaa2', 'consumer': '0x3a420'})
                continue
            immediate = image[at - 4:at - 2].hex()
            register = image[at - 2:at].hex()
            if immediate in forms and forms[immediate] is not None:
                value = int.from_bytes(image[at - 2:at], 'big')
                require(value in forms[immediate], f'Unsafe port immediate at {at:x}: {value:x}')
                start = at - 4
            else:
                require(register in forms and forms[register] is None, f'Unknown port reference at {at:x}')
                start = at - 2
            refs.append({'pc': hex(start), 'port': hex(address), 'operand': hex(at)})
    require(len(refs) == 13, f'Changed port-reference census: {len(refs)}')
    send = image.find(SEND)
    require(send >= 0 and image.find(SEND, send + 1) < 0, 'EEPROM serializer contract differs')
    register_writes = {int(r['pc'], 16) for r in refs if image[int(r['pc'], 16):int(r['pc'], 16) + 2] == b'\x13\xc2'}
    require(register_writes == {send + 10, send + 20, send + 30}, 'Unbound register-based high-byte writer')
    coin = bytes.fromhex('2f002f01102d006a1200020100030200000ce5088001000000c813c000804041221f201f4e75')
    require(image.count(coin) == 1, 'Coin-control conversion contract differs')
    return {'reset_pc': hex(reset), 'serializer_pc': hex(send), 'port_references': refs, 'retained_data_collisions': data_collisions}

def bus_rows(rows):
    require(len(rows) > 100, 'Missing EEPROM traffic')
    require(rows[:3] == [(8405152, 0, 65535), (8405056, 3840, 65535), (8405056, 4040, 65535)], 'Reset/release bus sequence differs')
    require(6389760 <= rows[3][0] <= 6397951, 'Z80 release must precede shared RAM')
    high, low = (set(), set())
    for address, value, mask in rows:
        if address != 8405056:
            continue
        if mask & 65280:
            require(value & 3840 == 3840, 'Board control bits cleared on bus')
            high.add(value >> 8)
        if mask & 255 and (address, value, mask) != rows[1]:
            require(value & 8, 'Z80 reset asserted after release')
            low.add(value & 255)
    require({15, 79, 95, 111, 127} <= high, 'Incomplete EEPROM transition coverage')
    return {'events': len(rows), 'high_bytes': sorted(high), 'low_bytes': sorted(low)}

def bus(path):
    rows = [tuple((int(v, 16) for v in s.split('\t'))) for s in path.read_text(encoding='utf-8').splitlines()[1:]]
    return {'sha256': sha(path.read_bytes()), **bus_rows(rows)}

def rejected(fn):
    try:
        fn()
    except ValueError as error:
        return str(error)
    raise ValueError('Rejecting control unexpectedly passed')

def controls(image):
    result = {}
    reset = int.from_bytes(image[4:8], 'big')
    bad = bytearray(image)
    bad[reset + 4:reset + 20] = b'Nq' * 8
    result['missing_original_reset_initialization'] = rejected(lambda: audit(bytes(bad)))
    for before, after, label in [('13fc000f00804040', '13fc000000804040', 'deselect'), ('13fc004f00804040', '13fc004000804040', 'select'), ('13fc006f00804040', '13fc006000804040', 'read_clock'), ('744f03006702745f', '7440030067027450', 'serializer')]:
        old = bytes.fromhex(before)
        require(old in image, 'Missing mutation site: ' + label)
        result[label] = rejected(lambda: audit(image.replace(old, bytes.fromhex(after))))
    return result
