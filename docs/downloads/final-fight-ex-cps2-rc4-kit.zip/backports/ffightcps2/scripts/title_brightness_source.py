"""Full-brightness title-only native palette inputs; no animation-time work."""
import hashlib, struct
CONTRACTS = ((410934, 794624, 1024, '30d2edbf7394fb5e269e4ce6be749d3cafcee11c98af9cd61de5fa3e88b19156'), (411018, 801280, 512, '4143099fb553dae99fb80eaaf4dabee2417270a6cd4c328c6a6801fb6ef887cd'), (411086, 810496, 1024, '7e41fdee67071a98e26760461688419f1d18f32a654c3e48b090f6d555586a9a'), (411154, 820704, 1024, '382eda31f9ef441ddaeaed22e308aa265225cdb7f6a2f145530a2b2dbec539a6'))

def install(program):
    spans = []
    for table, at, size, digest in CONTRACTS:
        pointers = struct.unpack_from('>10I', program, table)
        if pointers[8] != at or any((max(at, p) < min(at + size, p + size) for i, p in enumerate(pointers) if i != 8)):
            raise ValueError('Title palette index/other-stage ownership changed')
        before = bytes(program[at:at + size])
        if hashlib.sha256(before).hexdigest() != digest:
            raise ValueError('Complete title palette preimage changed')
        after = bytearray((v | 240 if i % 2 == 0 else v for i, v in enumerate(before)))
        if at == 810496:
            if after[:2] != b'\xf1\x11':
                raise ValueError('Title canvas pen changed')
            after[:2] = b'\xf0\x00'
        program[at:at + size] = after
        spans.append(dict(table=table, index=8, start=at, size=size, before_sha256=digest, after_sha256=hashlib.sha256(after).hexdigest()))
    return dict(policy='full brightness before native title palette load; true-black empty Scroll2 canvas', spans=spans, RGB_unchanged=False, RGB_exception=dict(address=810496, before=61713, after=61440), runtime_code_unchanged=True)
