"""Source-owned, separately selectable palette and object publication candidates."""
import re
import struct
PALETTE_TRIGGER = bytes.fromhex('33fc91400080010a')
ENGINE_SPAN = (876544, 888832)
CLAIMS = ((9527296, 9535488, 'complete staged object list'), (9535488, 9541632, 'palette snapshot A'), (9543680, 9549824, 'palette snapshot B'), (9568000, 9568006, 'palette snapshot ownership'))
PALETTES = "\n; The scene engine writes its next palette after requesting the previous one.\n; Publish the snapshot completed at the previous IRQ exit. Never copy over the\n; bank currently owned by hardware. The working palette and overlay loan stay\n; at their native addresses. Outside converted scenes use the native source.\npalette_publish:\n        move.w sr,-(sp)\n        movem.l d0/a0,-(sp)\n        bsr palette_scene\n        bne.s @native\n        cmpi.w #$5053,($91ff00).l\n        bne.s @native\n        move.b ($91ff02).l,d0\n        andi.w #1,d0\n        move.b d0,($91ff03).l\n        lea ($918000).l,a0\n        tst.b d0\n        beq.s @bank\n        lea ($91a000).l,a0\n@bank:  move.l a0,d0\n        lsr.l #8,d0\n        move.w d0,($80010a).l\n        movem.l (sp)+,d0/a0\n        move.w (sp)+,ccr\n        ; Match displaced MOVE's CCR, including retained X.\n        move.w #$9140,-(sp)\n        addq.l #2,sp\n        rts\n@native:\n        movem.l (sp)+,d0/a0\n        move.w (sp)+,ccr\n        move.w #$9140,($80010a).l\n        rts\npalette_scene:\n        cmpi.w #$cafe,($ffffb0).l\n        beq.s @event\n        cmpi.w #$cafd,($ffffb0).l\n        beq.s @event\n        cmpi.w #$cafc,($ffffb0).l\n        bne.s @out\n@event: cmpi.w #$ffff,($ffffb2).l\n        beq.s @no\n        moveq #0,d0\n        rts\n@no:    moveq #1,d0\n@out:   rts\npalette_prepare:\n        move.w sr,-(sp)\n        movem.l d0-d2/a0-a1,-(sp)\n        tst.b ($91ff04).l\n        beq.s @done\n        clr.b ($91ff04).l\n        bsr palette_scene\n        bne.s @inactive\n        moveq #0,d2\n        cmpi.w #$5053,($91ff00).l\n        bne.s @first\n        move.b ($91ff03).l,d2\n        eori.b #1,d2\n        andi.w #1,d2\n@first: lea ($918000).l,a1\n        tst.b d2\n        beq.s @copy\n        lea ($91a000).l,a1\n@copy:  lea ($914000).l,a0\n        move.w #191,d1\n@block: rept 8\n        move.l (a0)+,(a1)+\n        endr\n        dbra d1,@block\n        move.b d2,($91ff02).l\n        move.w #$5053,($91ff00).l\n        bra.s @done\n@inactive:\n        clr.w ($91ff00).l\n@done:  movem.l (sp)+,d0-d2/a0-a1\n        move.w (sp)+,ccr\n        rts\n"
OBJECTS = '\n; The scene engine parks unused entries after its live prefix. Count that\n; prefix instead of converting/copying all 128 slots, including blank scenes.\n; Only the complete documented park record is removable.\ntrim_scene_objects:\n        lea ($920400).l,a0\n@tail:  cmpi.l #$01f00000,-8(a0)\n        bne.s @done\n        tst.l -4(a0)\n        bne.s @done\n        subq.l #8,a0\n        subq.w #1,d5\n        bne.s @tail\n@done:  rts\n; Transform and read back objects in ordinary CPU-visible GFX RAM. Copy only\n; a complete, terminated list to the back bank, then recheck the deadline.\nobjects_publish:\n        movem.l d0/a0/a2,-(sp)\n        move.l a1,d0\n        subi.l #OBJ_BACK,d0\n        addq.l #8,d0\n        cmpi.l #8,d0\n        bcs.s @invalid\n        cmpi.l #$2000,d0\n        bhi.s @invalid\n        move.w d0,d1\n        andi.w #7,d1\n        bne.s @invalid\n        lsr.w #2,d0\n        subq.w #1,d0\n        lea (OBJ_BACK).l,a0\n        lea ($708000).l,a2\n@copy:  move.l (a0)+,(a2)+\n        dbra d0,@copy\n        movem.l (sp)+,d0/a0/a2\n        bra line_now\n@invalid:\n        movem.l (sp)+,d0/a0/a2\n        move.w #$7fff,d1\n        rts\n'

def replace(text, before, after, count=1):
    if text.count(before) != count:
        raise ValueError('Publication source boundary changed: ' + before[:80])
    return text.replace(before, after)

def source(text, mode, binding=None):
    if type(mode) is not int or mode not in (0, 1, 2, 3, 6, 14, 22, 54, 118, 246):
        raise ValueError('Unknown publication mode')
    if mode == 0:
        return text
    helpers = ''
    if mode & 1:
        text = replace(text, '@out:   lea (OV_RAM).l,a4               ; start the build once this interrupt', '@out:   move.b #1,($91ff04).l\n        lea (OV_RAM).l,a4               ; start the build once this interrupt')
        text = replace(text, '        bsr.s late_build\n        movem.l (sp)+,d0-d7/a0-a6', '        bsr.w late_build\n        bsr palette_prepare\n        movem.l (sp)+,d0-d7/a0-a6', count=2)
        text = replace(text, '        tst.b LB_STATE(a4)              ;   the state the game left last frame\n        beq.s @back2\n        move.w #$8001,(RASTER1).l', '        tst.b LB_STATE(a4)              ;   the state the game left last frame\n        bne.s @prepare\n        tst.b ($91ff04).l\n        beq.s @back2\n@prepare:\n        move.w #$8001,(RASTER1).l')
        helpers += PALETTES
    if mode & 2:
        text = replace(text, 'OBJ_BACK        equ $708000', 'OBJ_BACK        equ $916000')
        if not mode & 4:
            text = replace(text, '        move.w #128,d5                  ;   and park the rest (their INITs park all 256),', '        move.w #128,d5\n        bsr trim_scene_objects             ; only complete parked tail records')
            text = replace(text, '@expage:\n        lsl.w #2,d7', '@expage:\n        move.w d7,d0\n        or.w d5,d0\n        beq.w @overlay\n        lsl.w #2,d7')
        text = replace(text, '        lea (OV_RAM).l,a4\n        move.b OV_PEND_N(a4),OV_PUB_N(a4)', '        bsr objects_publish\n        cmpi.w #LB_LAST_LINE,d1\n        bgt.s @out\n        lea (OV_RAM).l,a4\n        move.b OV_PEND_N(a4),OV_PUB_N(a4)')
        marker = '        move.l #$0000ff00,(OBJ_BACK+4).l\n'
        if marker in text:
            text = replace(text, marker, marker + '        move.l a1,-(sp)\n        lea (OBJ_BACK).l,a1\n        bsr objects_publish\n        movea.l (sp)+,a1\n')
        elif 'ta_modal_objects:\n' in text:
            text = replace(text, '@end:   move.l #$00008000,(a0)+\n        move.l #$0000ff00,(a0)\n        movem.l (sp)+,d0/a0-a1\n', '@end:   move.l #$00008000,(a0)+\n        move.l #$0000ff00,(a0)\n        lea -4(a0),a1\n        bsr objects_publish\n        movem.l (sp)+,d0/a0-a1\n')
        if mode in (54, 118, 246):
            import scene_pages_source
            helpers += scene_pages_source.OBJECTS_FAST
        else:
            helpers += OBJECTS[OBJECTS.index('; Transform'):] if mode & 4 else OBJECTS
    if mode == 14:
        import palette_fence_source
        helpers += palette_fence_source.helpers()
    if mode in (22, 54, 118, 246):
        import scene_pages_source
        helpers += scene_pages_source.PAGES
    if mode in (118, 246):
        import early_scene_palette
        text = replace(text, 'vblank_entry:\n', 'native_vblank_entry:\n')
        if mode == 246:
            import ending_early_palette
            helpers += ending_early_palette.assembly(binding)
        else:
            helpers += early_scene_palette.assembly(binding)
    text = text.replace('bsr objects_publish', 'jsr (objects_publish).l')
    helpers = helpers.replace('bsr.w line_now', 'jsr (line_now).l').replace('bra line_now', 'jmp (line_now).l')
    return replace(text, 'code_end:\n', helpers + '\ncode_end:\n')

def entry(listing):
    matches = re.findall('^([0-9A-F]{8})\\s+palette_publish:\\s*$', listing, re.M)
    if len(matches) != 1:
        raise ValueError('Palette publication entry is not uniquely assembled')
    return int(matches[0], 16)

def trigger_sites(program):
    """Bind complete emitted MOVE instructions within the owned engine span."""
    sites = []
    for pc in range(*ENGINE_SPAN, 2):
        if program[pc:pc + 8] == PALETTE_TRIGGER:
            sites.append(pc)
    if len(sites) != 8:
        raise ValueError('Unknown scene palette-trigger family: ' + repr(sites))
    return sites

def install(program, target):
    sites = trigger_sites(program)
    for pc in sites:
        program[pc:pc + 8] = b'N\xb9' + struct.pack('>I', target) + b'Nq'
    return sites

def callers(raw, program, old, new):
    pattern = b'N\xb9' + struct.pack('>I', old) + b'Nq'
    sites = [pc for pc in range(*ENGINE_SPAN, 2) if raw[pc:pc + 8] == pattern]
    if len(sites) != 8:
        raise ValueError('Incomplete source-bound scene publication callbacks')
    for pc in sites:
        program[pc + 2:pc + 6] = struct.pack('>I', new)
    return sites
