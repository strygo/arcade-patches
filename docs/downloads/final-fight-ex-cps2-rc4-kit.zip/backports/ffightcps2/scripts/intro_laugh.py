"""Bind the Japan-derived CD laugh to its first moving mouth event."""
import argparse
import hashlib
import struct
TABLE = 3212288
COUNT = 1930
OLD_EVENT = 1509
NEW_EVENT = 1478
OLD_TIME = 5622
NEW_TIME = 5561
PREIMAGES = {'japan': ('93425074199e7b45956f200da809052ffe86bd281fe6bb1b637a5e8deced413e', 'e097a35afb18c4a5c706bed04669fd307a837e4837c89ab13c67698b9107ad6b'), 'english': ('9429a1b7247af22b4eb408c4168cea0f9bc118c67132450031387f90c4025f58', '39ab03d9fa6b5134a8b4771da5fde955cd97143cc4a1a910fd0f0f564aa9a643')}

def install(image, edition):
    if edition == 'usa':
        return dict(applied=False, reason='USA CD scene is static/silent')
    if edition not in PREIMAGES:
        raise ValueError('Unknown intro sound edition')
    if len(image) != 4194304:
        raise ValueError('Complete canonical program required')
    if image[876704:876706] != bytes.fromhex('0c40') or image[876720:876722] != bytes.fromhex('43f9'):
        raise ValueError('Native opening count/table consumer changed')
    count = int.from_bytes(image[876706:876708], 'big')
    table = int.from_bytes(image[876722:876726], 'big')
    if (count, table) != (COUNT, TABLE):
        raise ValueError('Native opening resource extent changed')
    original = bytes(image[table:table + count * 16])
    if hashlib.sha256(original).hexdigest() not in PREIMAGES[edition]:
        raise ValueError('Complete opening resource changed; rebind animation/audio')
    records = list(struct.iter_unpack('>HHIHHHH', original))
    cues = [(i, r[1] >> 8) for i, r in enumerate(records) if r[1] >> 8]
    if cues != [(0, 118), (735, 117), (810, 119), (OLD_EVENT, 116)]:
        raise ValueError('Opening cue family changed')
    starts = []
    t = 0
    for r in records:
        starts.append(t)
        t += r[4]
    if starts[OLD_EVENT] != OLD_TIME or starts[NEW_EVENT] != NEW_TIME or records[NEW_EVENT][1] >> 8:
        raise ValueError('Mouth event or original laugh changed')
    old = table + OLD_EVENT * 16 + 2
    new = table + NEW_EVENT * 16 + 2
    image[old] = 0
    image[new] = 116
    return dict(applied=True, table=table, count=count, old_event=OLD_EVENT, new_event=NEW_EVENT, old_time=OLD_TIME, new_time=NEW_TIME, advance_frames=OLD_TIME - NEW_TIME, native_alias=116, posted_command=40, table_before_sha256=hashlib.sha256(original).hexdigest(), table_after_sha256=hashlib.sha256(image[table:table + count * 16]).hexdigest(), writes=[dict(address=old, before=116, after=0), dict(address=new, before=0, after=116)])
