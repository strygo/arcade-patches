"""Prepared game memory allocation claims."""
CLAIMS = ({'owner': 'immutable title palette and overlapping black DMA source', 'start': 9535488, 'bytes': 10240}, {'owner': 'immutable title palette initialization tag', 'start': 9568028, 'bytes': 4})
