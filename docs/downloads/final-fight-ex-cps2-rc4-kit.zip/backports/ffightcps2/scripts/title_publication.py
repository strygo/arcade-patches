"""Bind the native wall constructor and emit its immutable CPS2 fields."""
import hashlib
import struct

def native_delta(edition):
    if edition not in ('usa', 'japan', 'english'):
        raise ValueError('Unknown title region')
    return 0 if edition == 'usa' else -10

def source(raw, edition):
    delta = native_delta(edition)
    contracts = ((98678, 52, 'ad2f596d9de55904f4ac8202ec702f41e5c6518b63a19e356dd9c8f655dc6d6c'), (827456, 560, '137cb30f5c1d5cf2f0d87ebc3d76a9ced440ae0a6204289944c9e7c5c8a52fe6'), (878674, 160, 'f1e001c31ff28da529ca28ee1ad31718e796d7858c294fe7118820f288225895'), (878328, 156, '5d5e21da80ea6c56f7923991273b51efcefb98e5cadf51d29b5acdbbfbc6ad62'), (878938, 204, '94c513aeaf3d0d4b5109bab53b37cb809598a223abeea0491bf88bd3aacf399b'), (879142, 168, '1aca35b45ef471b664c2cd9a9a72b351c446d8e5cc051f7542e291cfb8efeb3a'))
    for at, size, digest in contracts:
        if at >= 851968:
            at += delta
        if hashlib.sha256(raw[at:at + size]).hexdigest() != digest:
            raise ValueError('Unknown complete native title producer/resource at %x' % at)
    if raw[98662:98672] != bytes.fromhex('4eb825fc3b7c9000009e'):
        raise ValueError('Native title object clear/constructor admission changed')
    if raw[98360:98364] != bytes.fromhex('610000e8') or raw[98590:98600] != bytes.fromhex('4eb808263b7c18ce006e'):
        raise ValueError('Native title return/constructor entry changed')
    if raw[98672:98678] != bytes.fromhex('4eb9') + struct.pack('>I', 879142 + delta):
        raise ValueError('Native constructor resource pointer producer changed')
    first = int.from_bytes(raw[4128768:4128772], 'big')
    if first != 4129012 or raw[first:first + 2] != b'\x00\x00':
        raise ValueError('The initial EX animation record is no longer empty')
    cells = list(struct.iter_unpack('>HH', raw[827456:827456 + 560]))
    records = []
    for i, (code, attr) in enumerate(cells):
        if code & 32768:
            continue
        x = 112 + i % 20 * 16
        records.append((x - 64 & 1023 | 8192, 496, code, attr))
    if len(records) != 108 or any((r[3] & 65280 for r in records)):
        raise ValueError('Native title object extent/shape changed')
    lines = ['CM_NATIVE_DELTA equ ' + str(delta), 'CM_WALL_COUNT equ 108', 'cm_wall_template:']
    for r in reversed(records):
        lines.append('        dc.w ' + ','.join(('$%04x' % v for v in r)))
    lines += ['        dc.w 0,$8000,0,$ff00', 'cm_wall_template_end:', 'cm_wall_completed_template:']
    resting = []
    for i, (code, attr) in enumerate(cells):
        if code & 32768:
            continue
        x = 112 + i % 20 * 16
        y = 72 + i // 20 * 16
        converted = int.from_bytes(raw[1671168 + y * 2:1671170 + y * 2], 'big')
        if converted != y - 16 & 1023:
            raise ValueError('Native completed wall Y projection changed')
        resting.append((x - 64 & 1023 | 8192, converted, code, attr))
    for r in reversed(resting):
        lines.append('        dc.w ' + ','.join(('$%04x' % v for v in r)))
    lines += ['        dc.w 0,$8000,0,$ff00', 'cm_wall_completed_template_end:']
    return '\n'.join(lines) + '\n'
