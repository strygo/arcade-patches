"""Bind complete native EX title instructions and its hidden settle canvas."""
import hashlib
ARM = bytes.fromhex('3b7c000a9288426d928a30bc51de317c00000004317c00a80002317c00d0000645f900920000363c00ff34bc01f0426a0002426a0004426a0006508a51cbffec33fc920000ff809e317cffff00084e75')
SETTLE = bytes.fromhex('43f900800140337c348c00266000')
MOVING = bytes.fromhex('43f900800140337c348e0026203c4420001f223c44200000')

def unique(image, token):
    hits = [i for i in range(876544, 880640 - len(token) + 1) if image.startswith(token, i)]
    if len(hits) != 1:
        raise ValueError('Native EX title object missing or ambiguous')
    return hits[0]

def bindings(image):
    return dict(arm=unique(image, ARM), settle=unique(image, SETTLE), moving=unique(image, MOVING), arm_bytes=len(ARM), arm_sha256=hashlib.sha256(ARM).hexdigest())

def install(image):
    b = bindings(image)
    at = b['settle']
    if image[at + 6:at + 12] != bytes.fromhex('337c348c0026'):
        raise ValueError('Unknown settle layer writer')
    image[at + 8:at + 10] = bytes.fromhex('3480')
    at = b['moving']
    if image[at + 6:at + 12] != bytes.fromhex('337c348e0026'):
        raise ValueError('Unknown moving layer writer')
    return {**b, 'settle_instruction_before': '337c348c0026', 'settle_instruction_after': '337c34800026', 'moving_instruction_before': '337c348e0026', 'moving_instruction_after': '337c348e0026'}
