"""Prepared game memory allocation claims."""
CLAIMS = ((9527296, 9535488, 'complete staged object list'),)
