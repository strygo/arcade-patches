"""Region-bound ending admission for the early palette protocol."""
import hashlib
import struct
import early_scene_palette as opening
ENGINES = (dict(name='reunion', magic=51965, entry=881558, main=881690, table=3997696, count=264, prefix_sha256='5faf1273d06bd5010944862174a81b8204a9e19daf5f2613e31c9e3fb3822734'), dict(name='farewell', magic=51964, entry=885602, main=885734, table=3882736, count=363, prefix_sha256='960f86819eef450a8ea32be0b0725285babe8c37bc36df518b35611cdd9edf68'))
ASM = '\n; Preserve the proven opening routine, including its distinct liveness gates.\npalette_all_early_vblank:\n        move.w sr,-(sp)\n        cmpi.w #$cafd,($ffffb0).l\n        beq.s @ending\n        cmpi.w #$cafc,($ffffb0).l\n        beq.s @ending\n        move.w (sp)+,ccr\n        bra.w palette_early_vblank\n@ending:\n        move.w (sp)+,ccr\n        bra.w palette_ending_early_vblank\n\npalette_ending_early_vblank:\n        move.w sr,-(sp)\n        movem.l d0-d1/a0-a1,-(sp)\n        move.w #$4550,($91ff00).l\n        clr.w ($91ff02).l\n        ori.w #$0700,sr\n        lea ($ffffb0).l,a0\n        move.w 2(a0),d0\n        cmpi.w #$cafd,(a0)\n        bne.s @farewell\n        cmpi.w #264,d0\n        bcc.w @done\n        lea ($3d0000).l,a1\n        bra.s @admit\n@farewell:\n        cmpi.w #$cafc,(a0)\n        bne.w @done\n        cmpi.w #363,d0\n        bcc.w @done\n        lea ($3b3ef0).l,a1\n@admit:\n        cmpi.w #OV_MAGIC,(OV_RAM+OV_TAG).l\n        bne.w @done\n        tst.b (OV_RAM+OV_LIVE_N).l\n        bne.w @done\n        tst.b (OV_RAM+OV_PEND_N).l\n        bne.w @done\n        tst.b (OV_RAM+OV_PUB_N).l\n        bne.w @done\n        bsr.w line_now\n        cmpi.w #-22,d1\n        blt.w @done\n        cmpi.w #-12,d1\n        bgt.w @done\n        ; Native ending prefix maps counter 8000 to zero before this test.\n        ; Both raw 8000 and normalized zero fail the equality to one.\n        cmpi.w #1,($ff12ae).l\n        beq.w @fire\n        ext.l d0\n        lsl.l #4,d0\n        adda.l d0,a1\n        move.w 10(a1),d1\n        btst #7,8(a1)\n        beq.s @normal\n        subq.w #1,d1\n@normal:\n        cmp.w 4(a0),d1\n        bne.w @done\n        tst.w 2(a0)\n        beq.s @fire\n        move.w 2(a1),d0\n        move.w -14(a1),d1\n        eor.w d1,d0\n        andi.w #$00ff,d0\n        beq.s @done\n@fire: move.w #7,($800170).l\n        move.w #$9140,($80010a).l\n        move.w #1,($91ff02).l\n@done: movem.l (sp)+,d0-d1/a0-a1\n        move.w (sp)+,sr\n        rts\n'

def assembly(binding=None):
    text = opening.assembly(binding)
    token = '        bsr.w palette_early_vblank\n'
    if text.count(token) != 1:
        raise ValueError('Original IRQ wrapper changed')
    tail = ASM
    if binding:
        a, b = binding['engines'][1:]
        if a['name'] != 'reunion' or b['name'] != 'farewell':
            raise ValueError('Unknown ending bindings')
        for before, after in (('cmpi.w #264,d0', f"cmpi.w #{a['count']},d0"), ('cmpi.w #363,d0', f"cmpi.w #{b['count']},d0"), ('lea ($3d0000).l,a1', f"lea (${a['table']:x}).l,a1"), ('lea ($3b3ef0).l,a1', f"lea (${b['table']:x}).l,a1")):
            if tail.count(before) != 1:
                raise ValueError('Regional ending source template changed')
            tail = tail.replace(before, after)
    return text.replace(token, '        bsr.w palette_all_early_vblank\n', 1) + tail

def install(program, labels, publish, binding=None):
    result = []
    for e in binding['engines'][1:] if binding else ENGINES:
        pc = e['main']
        if program[pc:pc + 8] != b'N\xb9' + struct.pack('>I', publish) + b'Nq':
            raise ValueError('Ending palette request changed: ' + e['name'])
        if hashlib.sha256(program[e['entry']:pc]).hexdigest() != e['prefix_sha256']:
            raise ValueError('Complete ending admission/predicate prefix changed: ' + e['name'])
        if program[e['entry'] + 10:e['entry'] + 12] != bytes.fromhex('6600'):
            raise ValueError('Ending entry branch grammar changed')
        program[pc:pc + 8] = b'N\xb9' + struct.pack('>I', labels['palette_main_publish']) + b'Nq'
        result.append(e)
    return result

def callers(raw, program, old, new):
    result = []
    for e in ENGINES:
        pc = e['main']
        name = 'palette_main_publish'
        if raw[pc:pc + 8] != b'N\xb9' + struct.pack('>I', old[name]) + b'Nq':
            raise ValueError('Unbound ending callback: ' + e['name'])
        program[pc + 2:pc + 6] = struct.pack('>I', new[name])
        result.append((pc, name))
    return result
