"""Bind regional palette admission to complete emitted native consumers."""
import hashlib
import struct
DATA_HOME = 3211264
DESCRIPTORS = (dict(name='opening', magic=51966, base=876544, limit=876704, entry=877674, main=877760, canonical_table=3212288, prefix_sha256='7b03d4e7530ff333add30e60222c29b915a3699701e6a3264e055b058a2fd430'), dict(name='reunion', magic=51965, base=880640, limit=880742, entry=881558, main=881690, canonical_table=3997696, canonical_exit=1494, prefix_sha256='5faf1273d06bd5010944862174a81b8204a9e19daf5f2613e31c9e3fb3822734'), dict(name='farewell', magic=51964, base=884736, limit=884838, entry=885602, main=885734, canonical_table=3882736, canonical_exit=2086, prefix_sha256='960f86819eef450a8ea32be0b0725285babe8c37bc36df518b35611cdd9edf68'))

def sha(b):
    return hashlib.sha256(b).hexdigest()

def bind(code, data, edition):
    if edition not in ('usa', 'japan', 'english'):
        raise ValueError('Unknown palette edition')
    result = dict(edition=edition, engines=[])
    for d in DESCRIPTORS:
        pc = d['limit']
        entry = d['entry']
        main = d['main']
        if code[pc:pc + 2] != b'\x0c@' or code[pc + 4:pc + 6] != b'l\x00' or code[pc + 8:pc + 18] != bytes.fromhex('3140000248c0e98843f9'):
            raise ValueError('Unknown native event index/table grammar: ' + d['name'])
        count = int.from_bytes(code[pc + 2:pc + 4], 'big')
        table = int.from_bytes(code[pc + 18:pc + 22], 'big')
        if not 1 <= count < 32768:
            raise ValueError('Unsupported native signed event extent')
        lo = table - DATA_HOME
        records = data[lo:lo + count * 16]
        if lo < 0 or len(records) != count * 16:
            raise ValueError('Incomplete regional event domain')
        if code[main:main + 8] != bytes.fromhex('33fc91400080010a'):
            raise ValueError('Native main palette request changed: ' + d['name'])
        prefix = code[entry:main]
        normalized = bytearray(prefix)
        lea = b'C\xf9' + table.to_bytes(4, 'big')
        if prefix.count(lea) != 1:
            raise ValueError('Ambiguous regional palette table projection')
        at = prefix.index(lea)
        normalized[at + 2:at + 6] = d['canonical_table'].to_bytes(4, 'big')
        exit_target = None
        if d['name'] != 'opening':
            if prefix[10:12] != b'f\x00':
                raise ValueError('Unknown native ending admission branch')
            exit_target = entry + 12 + int.from_bytes(prefix[12:14], 'big', signed=True)
            if not d['base'] <= exit_target < d['base'] + 4096 or code[exit_target:exit_target + 12] != bytes.fromhex('4bf900ff80004ef900000984'):
                raise ValueError('Unknown complete native ending exit')
            normalized[12:14] = d['canonical_exit'].to_bytes(2, 'big')
        if sha(normalized) != d['prefix_sha256']:
            raise ValueError('Unknown complete native palette predicate/entry: ' + d['name'])
        result['engines'].append(dict(name=d['name'], magic=d['magic'], entry=entry, main=main, table=table, count=count, limit_pc=pc, prefix_sha256=sha(prefix), exit_target=exit_target, record_bytes=len(records), records_sha256=sha(records), duration_frames=sum((struct.unpack_from('>H', records, i + 10)[0] for i in range(0, len(records), 16)))))
    return result
