Marvel Super Heroes - English Restoration
rc1 (2026-11-23)

This USA edition brings the Japanese 951117 arcade script to English. Victory quotes, continue prompts, Automode tips and endings have been retranslated.

- Read the Japanese revision’s victory quotes, continue prompts, Automode tips and endings in English.
- Unlock Doctor Doom, Thanos and Anita with their original Japanese codes. Anita has a nameplate on both lifebars.
- Both outcomes of Thanos’s ending retain their original timing.

Supply your stock Japan 951117 MAME ROMs. Merged or split sets can use --rompath.
  python3 apply.py --rompath /path/to/stock-roms --platform mame --out-dir ./restoration
Keep MAME's stock qsound_hle.zip available in your ROM path. Start the mshj machine with the new restoration/mame folder first in the ROM path. MAME will report expected checksum differences for the patched ROM members.

MiSTer
Copy the contents of the mister folder to the MiSTer SD card, keeping the _Arcade folder layout. Keep the stock Japan 951117 ROMs and qsound_hle.zip in your usual arcade ROM folder. Use the installed jtCPS2 core. The MRA applies the patch when MiSTer loads the game.

HBMAME and FBNeo
Use a build of your emulator that includes the mshrest definition. Select --platform hbmame or --platform fbneo and add the resulting mshrest.zip to your emulator's ROM folder. Keep the usual QSound files available to HBMAME.

Darksoft
Run the same command with --platform darksoft. Inside your chosen output directory, copy the generated folder under darksoft/games to the card's games folder. Keep all flash files, key and NAME together.
