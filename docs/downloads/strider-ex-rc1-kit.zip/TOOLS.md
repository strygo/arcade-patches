Strider EX recipient dependencies

Python 3.12+, NumPy and SciPy perform the qualified stereo resampling. FFmpeg encodes the direct-disc ADX streams. ffmpeg_helpers.json preserves the complete supported-host archive, executable, source and license identities. The downloader verifies archives and installed tools by content; --tools-cache, --tools-bundle and --offline are supported.

7-Zip (7zz, 7z or 7za) is needed only for 7z media. ZIP and loose canonical inputs use the standard library. No emulator, BIOS, Pillow, compiler, assembler, source checkout or retained capture is used by this recipient.
