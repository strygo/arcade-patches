"""Validate reconstructed contents, independent of ZIP container compression."""
import hashlib
from pathlib import Path
import zipfile
import zlib

def sha(data):
    return hashlib.sha256(data).hexdigest()

def selected_outputs(pins, region='both', audio='both', platform='both'):
    wanted = {}
    for name, digest in pins['files'].items():
        if platform == 'mister' and name.startswith('hbmame/'):
            continue
        if platform == 'hbmame' and name.startswith('mister/'):
            continue
        if name.startswith('mister/'):
            if audio == 'arcade' and ('/_Arrangements/' in name or name.endswith('/strider_ex.zip')):
                continue
            if audio == 'cpsplus' and '/_Enhanced Versions/' in name:
                continue
        if region == 'us' and ('striderjs01' in name or '/_Japan/' in name):
            continue
        if region == 'jp' and ('striderus01' in name or (name.endswith('.mra') and '/_Japan/' not in name)):
            continue
        wanted[name] = digest
    return wanted

def check_file(path, name, pins):
    """Require every original ROM/pack hash; only ZIP representation may vary."""
    if path.is_symlink():
        raise ValueError('reconstructed output is a symbolic link: ' + name)
    if not name.endswith('.zip'):
        actual = sha(path.read_bytes())
        expected = pins['files'][name]
        if actual != expected:
            raise ValueError('reconstructed file differs: ' + name + '\nExpected SHA-256: ' + expected + '\nActual SHA-256: ' + actual)
        return
    expected = pins.get('inventory', {}).get(name, {}).get('members')
    if not isinstance(expected, dict) or not expected:
        raise ValueError('missing ZIP member checksum inventory: ' + name)
    try:
        with zipfile.ZipFile(path) as archive:
            entries = archive.infolist()
            names = [entry.filename for entry in entries]
            seen = set()
            for member in names:
                if member in seen:
                    raise ValueError('duplicate reconstructed archive member: ' + name + ':' + member)
                seen.add(member)
            missing, extra = (sorted(set(expected) - seen), sorted(seen - set(expected)))
            if missing or extra:
                raise ValueError('reconstructed archive contents differ: ' + name + '\nMissing members: ' + ', '.join(missing) + '\nUnexpected members: ' + ', '.join(extra))
            for entry in entries:
                member = entry.filename
                if entry.compress_type not in (zipfile.ZIP_STORED, zipfile.ZIP_DEFLATED):
                    raise ValueError('unsupported reconstructed ZIP compression: ' + name + ':' + member)
                if entry.flag_bits & 1:
                    raise ValueError('encrypted reconstructed archive member: ' + name + ':' + member)
                actual = sha(archive.read(entry))
                if actual != expected[member]:
                    raise ValueError('reconstructed archive member differs: ' + name + ':' + member + '\nExpected SHA-256: ' + expected[member] + '\nActual SHA-256: ' + actual)
    except (zipfile.BadZipFile, EOFError, RuntimeError, NotImplementedError, zlib.error) as exc:
        raise ValueError('cannot read reconstructed archive ' + name + ': ' + str(exc)) from exc

def check_outputs(root, pins, region='both', audio='both', platform='both'):
    root = Path(root)
    wanted = selected_outputs(pins, region, audio, platform)
    actual = {path.relative_to(root).as_posix() for path in root.rglob('*') if path.is_file() and path.name != '.DS_Store'}
    missing, extra = (sorted(set(wanted) - actual), sorted(actual - set(wanted)))
    if missing or extra:
        raise ValueError('reconstructed output inventory differs' + '\nMissing outputs: ' + ', '.join(missing) + '\nUnexpected outputs: ' + ', '.join(extra))
    for name in sorted(wanted):
        check_file(root / name, name, pins)
    return len(actual)
