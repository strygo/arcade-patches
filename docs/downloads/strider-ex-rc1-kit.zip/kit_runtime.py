"""Keep Windows reconstruction text and child Python processes in UTF-8."""
import os
import subprocess
import sys

def enable_utf8():
    if os.name != 'nt':
        return
    os.environ['PYTHONUTF8'] = '1'
    os.environ['PYTHONIOENCODING'] = 'utf-8'
    if not sys.flags.utf8_mode:
        options = ['-B'] if sys.flags.dont_write_bytecode else []
        raise SystemExit(subprocess.call([sys.executable, *options, '-X', 'utf8', *sys.argv]))
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, 'reconfigure'):
            stream.reconfigure(encoding='utf-8', errors='backslashreplace')
