"""Resolve and preflight MAME without changing the user's installed emulator."""
import json
import os
from pathlib import Path
import platform
import re
import shutil
import subprocess
import zipfile
HERE = Path(__file__).resolve().parent
REQUIRED_VERSION = '0.288'
LINUX_PACKAGES = 'On Debian/Ubuntu install the runtime libraries with: sudo apt install libsdl2-2.0-0 libsdl2-ttf-2.0-0 libfontconfig1 libegl1 libstdc++6. The included helper requires Ubuntu 24.04+ or a compatible glibc 2.39 system.'

class MameError(ValueError):
    pass

def linux_hint():
    return ' On Linux, omit --mame to use the included pinned helper.' if platform.system() == 'Linux' else ''

def query(executable, *args):
    try:
        result = subprocess.run([str(executable), *args], capture_output=True, text=True, encoding='utf-8', errors='replace', timeout=30)
    except (OSError, subprocess.TimeoutExpired) as exc:
        detail = str(exc)
        if platform.system() == 'Linux':
            detail += ' ' + LINUX_PACKAGES
        raise MameError('Cannot run MAME at ' + str(executable) + ': ' + detail) from exc
    if result.returncode:
        detail = (result.stderr or result.stdout).strip()
        if platform.system() == 'Linux' and ('shared librar' in detail or 'GLIBC' in detail):
            detail += ' ' + LINUX_PACKAGES
        raise MameError('MAME at ' + str(executable) + ' failed ' + args[0] + ' (exit ' + str(result.returncode) + '): ' + detail)
    return result.stdout.strip()

def preflight(executable):
    executable = Path(executable).resolve()
    version = query(executable, '-version')
    if not re.match('^0\\.288(?:\\s|$)', version):
        raise MameError('Detected MAME ' + repr(version) + ' at ' + str(executable) + '. This reconstruction requires exactly MAME ' + REQUIRED_VERSION + ' to reproduce the verified scene and audio data.' + linux_hint())
    usage = query(executable, '-showusage')
    if not re.search('^\\s*-autoboot_script\\b', usage, re.M):
        raise MameError('MAME ' + version + ' at ' + str(executable) + ' does not expose the required Lua -autoboot_script option.' + linux_hint())
    for machine in ('pce', 'striderua', 'striderjr'):
        listing = query(executable, '-listfull', machine)
        if not re.search('^' + machine + '\\s', listing, re.M):
            raise MameError('MAME ' + version + ' at ' + str(executable) + ' does not include the required ' + machine + ' driver.' + linux_hint())
    print('Ready: MAME ' + version + ' at ' + str(executable) + ' (Lua and source drivers checked)', flush=True)
    return executable

def bundled_linux():
    import fetch_switch_tools as common
    try:
        host = common.host_id()
        lock = json.loads((HERE / 'mame_helpers.json').read_text(encoding='utf-8'))
        common.require(lock.get('schema') == 1 and lock.get('version') == REQUIRED_VERSION, 'Invalid MAME helper lock')
        common.require(host in lock['platforms'], 'No included MAME helper for ' + host)
        record = lock['platforms'][host]
        common.require(set(record['executables']) == {'mame'}, 'Invalid MAME executable inventory')
        libc, version = platform.libc_ver()
        if libc != 'glibc' or tuple(map(int, version.split('.')[:2])) < (2, 39):
            raise MameError('The included ' + host + ' MAME helper requires glibc 2.39 or later; detected ' + libc + ' ' + version + '. Supply a compatible MAME 0.288 with --mame.')
        key = 'CPSPLUS_SWITCH_TOOLS_BUNDLE'
        old = os.environ.get(key)
        os.environ[key] = str(HERE / 'tools' / record['filename'])
        try:
            return common.obtain(record, host, label='MAME 0.288')['mame']
        finally:
            if old is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = old
    except (common.SetupError, OSError, KeyError, ValueError, zipfile.BadZipFile) as exc:
        if isinstance(exc, MameError):
            raise
        raise MameError('Cannot prepare the included Linux MAME helper: ' + str(exc) + '. Supply an existing MAME 0.288 with --mame if needed.') from exc

def resolve(override=None):
    if override is not None:
        value = str(override)
        path = Path(value).expanduser()
        found = path if path.is_file() else shutil.which(value)
        if not found:
            raise MameError('MAME executable not found: ' + value + '. --mame must name a MAME 0.288 executable or a command on PATH.' + linux_hint())
    elif platform.system() == 'Linux':
        found = bundled_linux()
    else:
        found = shutil.which('mame')
        if not found:
            raise MameError('MAME executable not found on PATH. Install MAME 0.288 and pass --mame /path/to/mame (mame.exe on Windows). Official releases: https://github.com/mamedev/mame/releases/tag/mame0288')
    return preflight(found)
