"""Read invariant or decimal-comma numbers from MAME's tab-separated traces."""
import math
import re

def decimal(text):
    text = str(text).strip()
    if not re.fullmatch('[+-]?(?:\\d+(?:[.,]\\d*)?|[.,]\\d+)(?:[eE][+-]?\\d+)?', text):
        raise ValueError('invalid trace number: ' + repr(text))
    value = float(text.replace(',', '.'))
    if not math.isfinite(value):
        raise ValueError('non-finite trace number')
    return value
