"""Restore Strider's unused ending and Aerial Battleship intro tunes into the"""
from __future__ import annotations
import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import wave
import zipfile
from pathlib import Path
ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / 'cpsplus' / 'tools'))
LUA = ROOT / 'backports' / 'striderex' / 'lua' / 'restore_tunes_gate.lua'
SOUND_SHA1 = 'c120ecfe25c3c50bc51bc7d5a9ef1c8ca6591240'
SOUND_MEMBERS = {'striderua': '09.12b', 'striderjr': 'sth_09.12a'}
X68K_ARCHIVE = 'x68000/Strider Hiryuu (1992)(Capcom).zip'
X68K_ARCHIVE_SHA256 = '1a354b855a64d22c710eebea388d442dad5261f650d313f8d595d20ceee2ccf9'
X68K_DISKS = ['Strider Hiryuu (1992)(Capcom)(Disk 1 of 3)(System).dim', 'Strider Hiryuu (1992)(Capcom)(Disk 2 of 3)(Disk A).dim', 'Strider Hiryuu (1992)(Capcom)(Disk 3 of 3)(Disk B).dim']
SYSTEM_DIM_SHA256 = 'c611d2ccfbdaf0abc5fdc1c5bfc6cfd4bde4dc7f76b4b224a6f663b0e57fdc7c'
SHSOUND_SHA256 = 'c6d190d803cfc296fa2c3683a6e227812a4054ab33c572077c1499e2d05705d2'
BANK_SHA256 = 'b66a23cce472ca18545966f22bedc9518aaf43841aa1347a1646d307ab81fb1c'
BANK_SIZE = 23406
RESTORE = [30, 33]
FREE_BASE = 24832
FREE_END = 32768
OPLEN = [1, 1, 2, 3, 3, 3, 0, 1, 1, 1, 1, 2, 1, 1, 1, 0]
ADDR_AT = {2: 0, 3: 1, 4: 1, 5: 1}
OP09_TO_ARCADE = {255: 240, 15: 176}
INSTR_ARCADE, INSTR_X68K, INSTR_SIZE = (3763, 744, 40)
KC_ARCADE, KC_X68K_COPY, KC_X68K_BASE, KC_LEN = (2854, 384, 382, 96)
KC_ARCADE_CODE = (1457, bytes.fromhex('21260bdd7e11e7'))

class RestoreError(RuntimeError):
    pass

def sha1(b: bytes) -> str:
    return hashlib.sha1(b).hexdigest()

def sha256(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()

def read_set_member(rom_dir: Path, set_name: str, member: str) -> bytes:
    d = rom_dir / set_name
    if (d / member).is_file():
        return (d / member).read_bytes()
    z = rom_dir / f'{set_name}.zip'
    if z.is_file():
        with zipfile.ZipFile(z) as zf:
            for info in zf.infolist():
                if Path(info.filename).name.lower() == member.lower():
                    return zf.read(info)
    s = rom_dir / f'{set_name}.7z'
    if s.is_file():
        tool = shutil.which('7zz') or shutil.which('7z')
        if not tool:
            raise RestoreError('7zz/7z is needed to read ' + str(s))
        with tempfile.TemporaryDirectory() as tmp:
            subprocess.run([tool, 'e', '-y', f'-o{tmp}', str(s), member], check=True, capture_output=True)
            p = Path(tmp) / member
            if p.is_file():
                return p.read_bytes()
    raise RestoreError(f'{set_name}/{member} not found under {rom_dir}')

def load_sound(rom_dir: Path) -> tuple[bytes, dict]:
    found = {}
    for set_name, member in SOUND_MEMBERS.items():
        try:
            found[set_name] = read_set_member(rom_dir, set_name, member)
        except RestoreError:
            continue
    if 'striderua' not in found:
        raise RestoreError(f'striderua/09.12b not found under {rom_dir}')
    for set_name, data in found.items():
        if sha1(data) != SOUND_SHA1 or len(data) != 65536:
            raise RestoreError(f'{set_name} sound ROM sha1 {sha1(data)} is not the rev-2 09.12b {SOUND_SHA1}')
    return (found['striderua'], {k: {'member': SOUND_MEMBERS[k], 'sha1': sha1(v)} for k, v in found.items()})

def lzss_decode(src: bytes) -> bytes:
    """SHSOUND.SLD: flag byte, MSB first, 1 = literal; a reference is two"""
    out = bytearray()
    i = 0
    while i < len(src):
        flags = src[i]
        i += 1
        for bit in range(8):
            if i >= len(src):
                break
            if flags & 128 >> bit:
                out.append(src[i])
                i += 1
            else:
                if i + 1 >= len(src):
                    raise RestoreError('truncated LZSS reference')
                b0, b1 = (src[i], src[i + 1])
                i += 2
                dist = (b0 & 240) << 4 | b1
                if dist == 0 or dist > len(out):
                    raise RestoreError(f'LZSS distance {dist} at output {len(out)}')
                for _ in range((b0 & 15) + 3):
                    out.append(out[-dist])
    return bytes(out)

def load_bank(archive: Path) -> tuple[bytes, dict]:
    from x68k_disk import Human68kDisk
    blob = archive.read_bytes()
    if sha256(blob) != X68K_ARCHIVE_SHA256:
        raise RestoreError(f'{archive}: sha256 {sha256(blob)} != {X68K_ARCHIVE_SHA256}')
    with zipfile.ZipFile(archive) as zf:
        dim = zf.read(X68K_DISKS[0])
    if sha256(dim) != SYSTEM_DIM_SHA256:
        raise RestoreError('System disk image digest mismatch')
    disk = Human68kDisk(dim, X68K_DISKS[0])
    entry = next((e for e in disk.entries() if e.path.name.upper() == 'SHSOUND.SLD'), None)
    if entry is None:
        raise RestoreError('SHSOUND.SLD not on the System disk')
    sld = disk.read(entry)
    if sha256(sld) != SHSOUND_SHA256:
        raise RestoreError('SHSOUND.SLD digest mismatch')
    bank = lzss_decode(sld)
    if len(bank) != BANK_SIZE or sha256(bank) != BANK_SHA256:
        raise RestoreError(f'decoded bank {len(bank):#x} bytes, sha256 {sha256(bank)} != {BANK_SHA256}')
    return (bank, {'archive_sha256': X68K_ARCHIVE_SHA256, 'system_dim_sha256': SYSTEM_DIM_SHA256, 'shsound_sld_sha256': SHSOUND_SHA256, 'shsound_sld_size': len(sld), 'bank_sha256': BANK_SHA256, 'bank_size': BANK_SIZE})

def arcade_table(snd: bytes) -> tuple[int, int]:
    """(entries address, count) from `ld hl,count; ld de,entries; ld b,a; ld a,0; ld (F004),a`."""
    m = re.search(b'\\x21(..)\\x11(..)\\x47\\x3e\\x00\\x32\\x04\\xf0', snd, re.S)
    if not m:
        raise RestoreError('arcade tune-table dispatch not found')
    cnt = int.from_bytes(m.group(1), 'little')
    return (int.from_bytes(m.group(2), 'little'), snd[cnt] + 1)

def x68k_table(bank: bytes) -> tuple[int, int]:
    return (484, bank[481] + 1)

def table_ptrs(buf: bytes, at: int, count: int) -> list[int]:
    return [buf[at + 2 * i] | buf[at + 2 * i + 1] << 8 for i in range(count)]

def header_ptrs(buf: bytes, start: int, base: int=0) -> list[int]:
    o = start - base
    return [buf[o + 1 + 2 * k] | buf[o + 2 + 2 * k] << 8 for k in range(8)]

def walk(buf: bytes, start: int, lo: int, hi: int, base: int=0) -> dict[int, tuple[int, bytes]]:
    """Every instruction reachable from a track start: {address: (op, operand)}."""
    ops: dict[int, tuple[int, bytes]] = {}
    todo = [start]
    while todo:
        p = todo.pop()
        while p not in ops:
            if not lo <= p < hi:
                raise RestoreError(f'track reaches {p:#06x}, outside {lo:#06x}-{hi:#06x}')
            b = buf[p - base]
            if 16 <= b < 32:
                raise RestoreError(f'unknown sequence opcode {b:#04x} at {p:#06x}')
            n = OPLEN[b] if b < 16 else 0
            if p + 1 + n > hi:
                raise RestoreError(f'operand of {b:#04x} at {p:#06x} runs past {hi:#06x}')
            opr = bytes(buf[p - base + 1:p - base + 1 + n])
            ops[p] = (b, opr)
            if b in ADDR_AT:
                o = ADDR_AT[b]
                todo.append(opr[o] | opr[o + 1] << 8)
            if b == 15:
                break
            p += 1 + n
    return ops

def song_bounds(ptrs: list[int], idx: int, limit: int) -> tuple[int, int]:
    start = ptrs[idx]
    later = sorted((p for p in set(ptrs) if p > start))
    return (start, later[0] if later else limit)

def song_walk(buf: bytes, start: int, end: int, base: int=0) -> tuple[list[dict], set[int]]:
    tracks, covered = ([], set(range(start, start + 17)))
    for k, t in enumerate(header_ptrs(buf, start, base)):
        if not t:
            continue
        ops = walk(buf, t, start, end, base)
        for p, (b, opr) in ops.items():
            covered.update(range(p, p + 1 + len(opr)))
        tracks.append({'track': k, 'start': t, 'ops': ops})
    return (tracks, covered)

def relocate(bank: bytes, start: int, end: int, new: int, op09: str='arcade') -> tuple[bytes, dict]:
    """The song bytes [start, end) moved to `new`, every address rebased."""
    tracks, covered = song_walk(bank, start, end)
    missing = sorted(set(range(start, end)) - covered)
    if missing and (not (all((bank[m] == 15 for m in missing)) and missing[-1] == end - 1 and (missing == list(range(missing[0], end))))):
        raise RestoreError(f'song {start:#06x}-{end:#06x}: {len(missing)} bytes not reached by any track (first {missing[0]:#06x}); refusing to copy unknown data')
    out = bytearray(bank[start:end])
    delta = new - start

    def put(at: int, addr: int) -> None:
        v = addr + delta
        out[at - start], out[at - start + 1] = (v & 255, v >> 8)
    fields = {'header': 0, 'jumps': 0, 'op09': {}, 'instruments': set(), 'unreached_tail_0f': len(missing)}
    for k, t in enumerate(header_ptrs(bank, start)):
        if t:
            put(start + 1 + 2 * k, t)
            fields['header'] += 1
    for tr in tracks:
        for p, (b, opr) in tr['ops'].items():
            if b in ADDR_AT:
                o = ADDR_AT[b]
                put(p + 1 + o, opr[o] | opr[o + 1] << 8)
                fields['jumps'] += 1
            elif b == 9:
                v = opr[0]
                if op09 == 'arcade':
                    if v not in OP09_TO_ARCADE:
                        raise RestoreError(f'op 0x09 operand {v:#04x} at {p:#06x} has no known arcade value')
                    out[p - start + 1] = OP09_TO_ARCADE[v]
                fields['op09'][f'{v:#04x}'] = fields['op09'].get(f'{v:#04x}', 0) + 1
            elif b == 12:
                fields['instruments'].add(opr[0])
    fields['instruments'] = sorted(fields['instruments'])
    fields['tracks'] = len(tracks)
    return (bytes(out), fields)

def build_patch(snd: bytes, bank: bytes, op09: str='arcade') -> tuple[bytes, dict]:
    if len(snd) != 65536:
        raise RestoreError('sound ROM must be 64 KiB')
    at, count = arcade_table(snd)
    xat, xcount = x68k_table(bank)
    if count != 48 or xcount != 48:
        raise RestoreError(f'tune tables hold {count} (arcade) / {xcount} (X68000) entries, expected 48')
    aptr, xptr = (table_ptrs(snd, at, count), table_ptrs(bank, xat, xcount))
    for i in RESTORE:
        if aptr[i] != aptr[0]:
            raise RestoreError(f'arcade entry {i:#04x} is {aptr[i]:#06x}, expected the tune-0x00 alias')
        if xptr[i] == xptr[0]:
            raise RestoreError(f'X68000 entry {i:#04x} has no tune of its own')
    if snd[KC_ARCADE_CODE[0]:KC_ARCADE_CODE[0] + 7] != KC_ARCADE_CODE[1]:
        raise RestoreError('arcade key-code lookup is not at 0x05B1')
    if bank[KC_X68K_COPY:KC_X68K_COPY + KC_LEN] != snd[KC_ARCADE:KC_ARCADE + KC_LEN]:
        raise RestoreError('X68000 bank key-code table differs from the arcade table')
    data_end = 0
    for s in set(aptr):
        data_end = max(data_end, s + 17)
        for t in header_ptrs(snd, s):
            if t:
                for p, (b, opr) in walk(snd, t, 0, FREE_BASE).items():
                    data_end = max(data_end, p + 1 + len(opr))
    if data_end > FREE_BASE:
        raise RestoreError(f'arcade song data reaches {data_end:#06x}, past {FREE_BASE:#06x}')
    patched = bytearray(snd)
    where = FREE_BASE
    songs = []
    instr_used = set()
    for i in RESTORE:
        s, e = song_bounds(xptr, i, BANK_SIZE)
        data, fields = relocate(bank, s, e, where, op09)
        for n in fields['instruments']:
            a = snd[INSTR_ARCADE + INSTR_SIZE * n:INSTR_ARCADE + INSTR_SIZE * (n + 1)]
            x = bank[INSTR_X68K + INSTR_SIZE * n:INSTR_X68K + INSTR_SIZE * (n + 1)]
            if a != x:
                raise RestoreError(f'song {i:#04x} uses instrument {n:#04x}, which differs between the banks')
            instr_used.add(n)
        if where + len(data) > FREE_END:
            raise RestoreError('restored songs do not fit below 0x8000')
        if any((b not in (0, 255) for b in patched[where:where + len(data)])):
            raise RestoreError(f'target {where:#06x}-{where + len(data):#06x} is not empty')
        patched[where:where + len(data)] = data
        patched[at + 2 * i], patched[at + 2 * i + 1] = (where & 255, where >> 8)
        tracks, cov = song_walk(bytes(patched), where, where + len(data))
        if cov | set(range(where + len(data) - fields['unreached_tail_0f'], where + len(data))) != set(range(where, where + len(data))):
            raise RestoreError('relocated song does not walk cleanly')
        songs.append({'command': f'{i:#04x}', 'x68k_offset': f'{s:#06x}', 'x68k_end': f'{e:#06x}', 'arcade_address': f'{where:#06x}', 'size': len(data), 'sha256': sha256(data), 'tracks': fields['tracks'], 'header_pointers': fields['header'], 'address_operands': fields['jumps'], 'op09_x68k_values': fields['op09'], 'op09_written': op09, 'unreached_tail_0f': fields['unreached_tail_0f'], 'instruments': [f'{n:#04x}' for n in fields['instruments']]})
        where = where + len(data) + 15 & ~15
    changed = [k for k in range(len(snd)) if snd[k] != patched[k]]
    allowed = set()
    for i in RESTORE:
        allowed |= {at + 2 * i, at + 2 * i + 1}
    for sg in songs:
        a = int(sg['arcade_address'], 16)
        allowed |= set(range(a, a + sg['size']))
    if not set(changed) <= allowed:
        raise RestoreError('patch touched bytes outside the two table entries and the new songs')
    report = {'tool': 'backports/striderex/scripts/restore_tunes.py', 'sound_rom_in': {'sha1': sha1(snd), 'sha256': sha256(snd)}, 'sound_rom_out': {'sha1': sha1(bytes(patched)), 'sha256': sha256(bytes(patched)), 'size': len(patched)}, 'tune_table': f'{at:#06x}', 'arcade_song_data_end': f'{data_end:#06x}', 'free_range': f'{FREE_BASE:#06x}-{FREE_END - 1:#06x}', 'free_range_fill': {f'{v:#04x}': snd[FREE_BASE:FREE_END].count(v) for v in sorted(set(snd[FREE_BASE:FREE_END]))}, 'table_entries_changed': {f'{i:#04x}': {'from': f'{aptr[i]:#06x}', 'to': sg['arcade_address']} for i, sg in zip(RESTORE, songs)}, 'bytes_changed': len(changed), 'songs': songs, 'pitch': {'arcade_kc_table': f'{KC_ARCADE:#06x}', 'x68k_kc_base': f'{KC_X68K_BASE:#06x}', 'x68k_kc_table_copy': f'{KC_X68K_COPY:#06x}', 'x68k_note_offset_steps': -2, 'data_transposed': False}, 'instruments_checked_identical': [f'{n:#04x}' for n in sorted(instr_used)]}
    return (bytes(patched), report)

def cmd_build(a) -> int:
    snd, sets = load_sound(a.rom_dir)
    bank, bank_info = load_bank(a.x68k_archive)
    patched, report = build_patch(snd, bank, a.op09)
    report['inputs'] = {'sound_sets': sets, 'x68k': bank_info}
    a.out.mkdir(parents=True, exist_ok=True)
    for name in ('09.12b', 'sth_09.12a'):
        (a.out / name).write_bytes(patched)
    (a.out / 'restore_report.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({k: report[k] for k in ('sound_rom_out', 'table_entries_changed', 'bytes_changed')}, indent=2))
    return 0

def mame_env() -> dict:
    return os.environ | {'SDL_VIDEODRIVER': 'dummy', 'SDL_AUDIODRIVER': 'dummy'}

def run_mame(machine: str, rompath: str, out: Path, env: dict, seconds: int, extra: list[str]=(), wav: Path | None=None, timeout: int=1500) -> Path:
    out.mkdir(parents=True, exist_ok=True)
    log = out / 'ym.tsv'
    cmd = ['mame', machine, '-rompath', rompath, '-video', 'none', '-nothrottle', '-cfg_directory', str(out / 'cfg'), '-nvram_directory', str(out / 'nvram'), '-seconds_to_run', str(seconds), '-autoboot_script', str(LUA), *extra]
    cmd += ['-sound', 'sdl', '-samplerate', '48000', '-wavwrite', str(wav)] if wav else ['-sound', 'none']
    with (out / 'run.log').open('w') as fh:
        r = subprocess.run(cmd, env=mame_env() | env | {'RT_LOG': str(log)}, stdout=fh, stderr=subprocess.STDOUT, timeout=timeout)
    text = log.read_text() if log.exists() else ''
    if r.returncode or not text.rstrip().endswith('done'):
        raise RestoreError(f'{machine} run in {out} failed (exit {r.returncode}); see run.log')
    return log

def parse_log(path: Path) -> dict[int, dict]:
    """{command: {'t0': time, 'writes': [(dt, reg, data)], 'keyons': {ch: [(dt, kc)]}}} for music commands."""
    songs, cur, kc = ({}, None, {})
    for line in path.read_text().splitlines():
        f = line.split('\t')
        if f[0] == 'done':
            continue
        t = float(f[0])
        if f[1] == 'cmd':
            c = int(f[2], 16)
            if c >= 240:
                cur = None
            else:
                cur = songs.setdefault(c, {'t0': t, 'writes': [], 'keyons': {}})
                cur['t0'] = t
            continue
        if f[1] != 'ym' or cur is None:
            continue
        reg, data = (int(f[2], 16), int(f[3], 16))
        dt = round(t - cur['t0'], 6)
        cur['writes'].append((dt, reg, data))
        if 40 <= reg <= 47:
            kc[reg - 40] = data
        elif reg == 8 and data & 120:
            ch = data & 7
            cur['keyons'].setdefault(ch, []).append((dt, kc.get(ch, -1)))
    return songs

def kc_map(snd: bytes) -> dict[int, int]:
    """X68000 key code -> the arcade key code of the same sequence note."""
    t = snd[KC_ARCADE:KC_ARCADE + KC_LEN]
    m = {}
    for j in range(1, KC_LEN - 2):
        if t[j] in m:
            raise RestoreError(f'key-code table value {t[j]:#04x} is not unique')
        m[t[j]] = t[j + 2]
    return m

def compare_song(arc: dict, x68: dict, kmap: dict[int, int], ratio: float | None, slot: float) -> dict:
    res = {'channels': sorted(arc['keyons']), 'problems': []}
    if sorted(arc['keyons']) != sorted(x68['keyons']):
        res['problems'].append(f"channels {sorted(arc['keyons'])} vs X68000 {sorted(x68['keyons'])}")
    pairs = []
    n_notes = 0
    for ch in sorted(set(arc['keyons']) & set(x68['keyons'])):
        a, x = (arc['keyons'][ch], x68['keyons'][ch])
        want = [kmap.get(k, -1) for _, k in x]
        got = [k for _, k in a]
        n_notes += len(got)
        if got != want:
            i = next((i for i, (g, w) in enumerate(zip(got, want)) if g != w), min(len(got), len(want)))
            res['problems'].append(f'ch{ch}: {len(got)} vs {len(want)} key-ons, first difference at #{i}')
        else:
            pairs += [(tx, ta) for (tx, _), (ta, _) in zip(x, a)]
    res['keyons'] = n_notes
    if pairs:
        sx = sum((p[0] for p in pairs))
        sa = sum((p[1] for p in pairs))
        sxx = sum((p[0] * p[0] for p in pairs))
        sxa = sum((p[0] * p[1] for p in pairs))
        r = sxa / sxx if sxx else 0.0
        res['time_ratio'] = round(r, 5)
        res['max_time_residual_s'] = round(max((abs(ta - r * tx) for tx, ta in pairs)), 4)
        if ratio is not None and abs(r / ratio - 1) > 0.01:
            res['problems'].append(f'time ratio {r:.4f} vs calibration {ratio:.4f}')
        if res['max_time_residual_s'] > 0.25:
            res['problems'].append(f"note timing residual {res['max_time_residual_s']} s")
    last_a = max((v[-1][0] for v in arc['keyons'].values()), default=0)
    last_x = max((v[-1][0] for v in x68['keyons'].values()), default=0)
    res['last_keyon_s'] = round(last_a, 3)
    res['x68k_last_keyon_s'] = round(last_x, 3)
    res['one_shot'] = last_a < slot - 10
    if not res['one_shot'] or last_x >= slot - 10:
        res['problems'].append('not a one-shot within the slot')
    if ratio is not None and abs(last_a - ratio * last_x) > 0.25:
        res['problems'].append(f'length {last_a:.2f} s vs expected {ratio * last_x:.2f} s')
    res['pass'] = not res['problems']
    return res

def split_wav(src: Path, log: dict[int, dict], dest: Path, names: dict[int, str], slot: float) -> list[str]:
    dest.mkdir(parents=True, exist_ok=True)
    w = wave.open(str(src))
    sr, ch, sw = (w.getframerate(), w.getnchannels(), w.getsampwidth())
    raw = w.readframes(w.getnframes())
    out = []
    for c, name in names.items():
        t0 = log[c]['t0']
        last = max((v[-1][0] for v in log[c]['keyons'].values()))
        a, b = (int(t0 * sr), int(min(t0 + last + 6.0, t0 + slot - 1.0) * sr))
        with wave.open(str(dest / name), 'wb') as o:
            o.setnchannels(ch)
            o.setsampwidth(sw)
            o.setframerate(sr)
            o.writeframes(raw[a * ch * sw:b * ch * sw])
        out.append(str(dest / name))
    return out

def cmd_gate(a) -> int:
    work = a.workdir.resolve()
    if work.exists() and any(work.iterdir()):
        raise RestoreError(f'{work} is not empty; choose a fresh work directory')
    work.mkdir(parents=True, exist_ok=True)
    rep_path = a.patched / 'restore_report.json'
    report = json.loads(rep_path.read_text())
    patched = (a.patched / '09.12b').read_bytes()
    if sha256(patched) != report['sound_rom_out']['sha256']:
        raise RestoreError('patched 09.12b does not match its restore_report.json')
    stock, _ = load_sound(a.rom_dir)
    proms = work / 'roms' / 'striderua'
    proms.mkdir(parents=True)
    (proms / '09.12b').write_bytes(patched)
    patched_path = f"{work / 'roms'};{a.rom_dir}"
    stock_path = str(a.rom_dir)
    disks = work / 'x68k_disks'
    disks.mkdir()
    blob = a.x68k_archive.read_bytes()
    if sha256(blob) != X68K_ARCHIVE_SHA256:
        raise RestoreError('X68000 archive digest mismatch')
    with zipfile.ZipFile(a.x68k_archive) as zf:
        for n in X68K_DISKS:
            (disks / n).write_bytes(zf.read(n))
    slot = 70.0
    cal = 14
    music = [cal] + RESTORE
    others = [c for c in range(36) if c not in RESTORE]
    n_arc = lambda n, s: int(n * s + 20)
    jobs = {'arcade_stock_restore': ('striderua', stock_path, {'RT_MODE': 'arcade', 'RT_CMDS': ','.join((f'{c:02x}' for c in music)), 'RT_SLOT': str(slot)}, n_arc(3, slot), None), 'arcade_patched_restore': ('striderua', patched_path, {'RT_MODE': 'arcade', 'RT_CMDS': ','.join((f'{c:02x}' for c in music)), 'RT_SLOT': str(slot)}, n_arc(3, slot), work / 'arcade_patched_restore.wav'), 'arcade_stock_others': ('striderua', stock_path, {'RT_MODE': 'arcade', 'RT_CMDS': ','.join((f'{c:02x}' for c in others)), 'RT_SLOT': '30'}, n_arc(len(others), 30), None), 'arcade_patched_others': ('striderua', patched_path, {'RT_MODE': 'arcade', 'RT_CMDS': ','.join((f'{c:02x}' for c in others)), 'RT_SLOT': '30'}, n_arc(len(others), 30), None), 'x68k_restore': ('x68000', a.bios_rompath, {'RT_MODE': 'x68k', 'RT_CMDS': ','.join((f'{c:02x}' for c in music)), 'RT_SLOT': str(slot), 'RT_DISKS': '|'.join((str(disks / n) for n in X68K_DISKS))}, int(3 * slot + 80), None)}
    from concurrent.futures import ThreadPoolExecutor
    logs = {}

    def run(name):
        machine, rp, env, secs, wav = jobs[name]
        extra = ['-flop1', str(disks / X68K_DISKS[0]), '-flop2', str(disks / X68K_DISKS[1])] if machine == 'x68000' else []
        logs[name] = run_mame(machine, rp, work / name, env, secs, extra, wav)
        return name
    with ThreadPoolExecutor(max_workers=5) as ex:
        for f in [ex.submit(run, n) for n in jobs]:
            f.result()
    if 'WRONG CHECKSUMS' not in (work / 'arcade_patched_restore' / 'run.log').read_text():
        raise RestoreError('the patched run did not load the patched 09.12b (no checksum warning)')
    P = {n: parse_log(p) for n, p in logs.items()}
    kmap = kc_map(stock)
    result = {'patched_sha256': sha256(patched), 'checks': {}}
    calib = compare_song(P['arcade_stock_restore'][cal], P['x68k_restore'][cal], kmap, None, slot)
    ratio = calib.get('time_ratio')
    result['calibration'] = {'command': f'{cal:#04x}', **calib}
    ok = calib['pass'] and ratio is not None
    for c in RESTORE:
        r = compare_song(P['arcade_patched_restore'][c], P['x68k_restore'][c], kmap, ratio, slot)
        neg = compare_song(P['arcade_stock_restore'][c], P['x68k_restore'][c], kmap, ratio, slot)
        result['checks'][f'{c:#04x}'] = {'patched': r, 'stock_negative_control': {'pass': neg['pass'], 'problems': neg['problems'][:3]}}
        ok &= r['pass'] and (not neg['pass'])
    ident = {}
    for c in others:
        s, p = (P['arcade_stock_others'].get(c), P['arcade_patched_others'].get(c))
        same = bool(s and p and s['writes'] and (s['writes'] == p['writes']))
        ident[f'{c:#04x}'] = {'identical': same, 'ym_writes': len(s['writes']) if s else 0}
        ok &= same
    result['others_identical'] = ident
    result['wavs'] = split_wav(work / 'arcade_patched_restore.wav', P['arcade_patched_restore'], a.wav_dir, {30: 'arcade_restored_1e_aerial_battleship_intro.wav', 33: 'arcade_restored_21_ending.wav'}, slot)
    result['pass'] = bool(ok)
    (work / 'gate_result.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'pass': result['pass'], 'calibration_ratio': ratio, 'restored': {k: {'pass': v['patched']['pass'], 'keyons': v['patched']['keyons'], 'last_keyon_s': v['patched']['last_keyon_s'], 'x68k_last_keyon_s': v['patched']['x68k_last_keyon_s'], 'problems': v['patched']['problems'], 'stock_fails': not v['stock_negative_control']['pass']} for k, v in result['checks'].items()}, 'others_identical': sum((v['identical'] for v in ident.values())), 'others': len(ident), 'result': str(work / 'gate_result.json')}, indent=2))
    return 0 if ok else 1

def cmd_freespace(a) -> int:
    work = a.workdir.resolve()
    if work.exists() and any(work.iterdir()):
        raise RestoreError(f'{work} is not empty')
    rng = f'{FREE_BASE:04x}-{FREE_END - 1:04x}'
    jobs = {'live_attract': {'RT_MODE': 'arcade', 'RT_LIVE': str(a.attract_seconds), 'RT_TAP': rng}, 'census_all_commands': {'RT_MODE': 'arcade', 'RT_TAP': rng, 'RT_SLOT': '8', 'RT_CMDS': ','.join((f'{c:02x}' for c in range(256)))}}
    secs = {'live_attract': a.attract_seconds + 5, 'census_all_commands': 256 * 8 + 25}
    from concurrent.futures import ThreadPoolExecutor
    with ThreadPoolExecutor(2) as ex:
        futs = {n: ex.submit(run_mame, 'striderua', str(a.rom_dir), work / n, env, secs[n]) for n, env in jobs.items()}
        logs = {n: f.result() for n, f in futs.items()}
    out = {}
    for n, p in logs.items():
        lines = p.read_text().splitlines()
        reads = [l for l in lines if '\tread\t' in l]
        out[n] = {'reads_in_range': len(reads), 'first': reads[:5], 'ym_writes': sum(('\tym\t' in l for l in lines))}
    out['range'] = rng
    out['pass'] = all((v['reads_in_range'] == 0 and v['ym_writes'] > 0 for k, v in out.items() if isinstance(v, dict)))
    print(json.dumps(out, indent=2))
    return 0 if out['pass'] else 1

def self_test() -> int:
    dec = lzss_decode(bytes([232, 1, 2, 3, 4, 1, 9, 0, 5]))
    assert dec == bytes([1, 2, 3]) + b'\x03' * 7 + bytes([9]) + bytes([3, 3, 3]), dec.hex()
    hdr = 256
    t0 = hdr + 17
    track0 = bytes([9, 255, 12, 1, 69, 3, 2, t0 + 4 & 255, t0 + 4 >> 8, 15])
    t1 = t0 + len(track0)
    track1 = bytes([48, 65, 15])
    song = bytearray(hdr) + bytes([8, t0 & 255, t0 >> 8, t1 & 255, t1 >> 8]) + bytes(12) + track0 + track1
    end = len(song)
    data, f = relocate(bytes(song), hdr, end, 24832)
    assert f['header'] == 2 and f['jumps'] == 1 and (f['op09'] == {'0xff': 1}), f
    assert data[1] | data[2] << 8 == t0 - hdr + 24832
    assert data[t0 - hdr + 1] == 240
    loop = t0 - hdr + 5
    assert data[loop + 2] | data[loop + 3] << 8 == t0 + 4 - hdr + 24832
    bad = bytearray(song)
    bad[t0 + 4] = 18
    try:
        relocate(bytes(bad), hdr, end, 24832)
        raise AssertionError('unknown opcode accepted')
    except RestoreError:
        pass
    pad = bytes(song) + b'\x00'
    try:
        relocate(pad, hdr, end + 1, 24832)
        raise AssertionError('unreached byte accepted')
    except RestoreError:
        pass
    snd = bytearray(65536)
    tbl = bytes([14] + [o << 4 | n for o in range(8) for n in (0, 1, 2, 4, 5, 6, 8, 9, 10, 12, 13, 14)])[:KC_LEN]
    snd[KC_ARCADE:KC_ARCADE + KC_LEN] = tbl
    km = kc_map(bytes(snd))
    assert km[9] == 12 and km[14] == 17
    x = {'keyons': {0: [(0.0, 9), (1.0, 14)]}}
    good = {'keyons': {0: [(0.0, 12), (1.1, 17)]}}
    assert compare_song(good, x, km, 1.1, 70)['pass']
    assert not compare_song({'keyons': {0: [(0.0, 9), (1.1, 14)]}}, x, km, 1.1, 70)['pass']
    print('restore_tunes self-test: ok')
    return 0

def main(argv=None) -> int:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('--self-test', action='store_true')
    sub = p.add_subparsers(dest='cmd')
    roms = ROOT / 'roms'
    for name in ('build', 'gate', 'freespace'):
        s = sub.add_parser(name)
        s.add_argument('--rom-dir', type=Path, default=roms / 'mame0260', help='directory holding the striderua (and striderjr) MAME sets')
        s.add_argument('--x68k-archive', type=Path, default=roms / X68K_ARCHIVE)
        if name == 'build':
            s.add_argument('--out', type=Path, required=True)
            s.add_argument('--op09', choices=['arcade', 'verbatim'], default='arcade')
        else:
            s.add_argument('--workdir', type=Path, required=True)
        if name == 'gate':
            s.add_argument('--patched', type=Path, required=True, help='the build --out directory')
            s.add_argument('--wav-dir', type=Path, required=True)
            s.add_argument('--bios-rompath', default=f"{roms};{roms / 'mame0260'}")
        if name == 'freespace':
            s.add_argument('--attract-seconds', type=int, default=300)
    a = p.parse_args(argv)
    if a.self_test:
        return self_test()
    try:
        return {'build': cmd_build, 'gate': cmd_gate, 'freespace': cmd_freespace}[a.cmd](a)
    except (RestoreError, KeyError) as e:
        if isinstance(e, KeyError) and a.cmd:
            raise
        print(f'restore_tunes: {e}', file=sys.stderr)
        return 2
if __name__ == '__main__':
    raise SystemExit(main())
