"""Canonicalize only authenticated MAME PCM rounding profiles."""
import base64
import hashlib
import json
from pathlib import Path
import zlib
import numpy as np
PROFILE = Path(__file__).resolve().parents[1] / 'manifests/pce_sfx_rounding.json'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def canonicalize(clips, primary, profiles=None):
    raw = {effect: sha(clip.tobytes()) for effect, clip in clips.items()}
    if raw == primary:
        return clips
    if profiles is None:
        profiles = json.loads(PROFILE.read_text(encoding='utf-8'))
    if profiles['schema'] != 'striderex-sfx-rounding/1':
        raise ValueError('unknown PCM rounding profile schema')
    for profile in profiles['profiles']:
        rows = {int(key, 16): value for key, value in profile['effects'].items()}
        if raw != {key: value['raw_sha256'] for key, value in rows.items()}:
            continue
        out = {}
        for effect, row in rows.items():
            clip = clips[effect]
            if clip.shape != (row['samples'], 2) or clip.dtype != np.dtype('<i2') or row['canonical_sha256'] != primary[effect]:
                raise ValueError('PCM rounding shape or target differs')
            packed = base64.b85decode(row['delta_b85'])
            decoder = zlib.decompressobj()
            delta = decoder.decompress(packed, clip.size + 1)
            if len(delta) != clip.size or not decoder.eof or decoder.unused_data or decoder.unconsumed_tail or (sha(delta) != row['delta_sha256']):
                raise ValueError('damaged PCM rounding correction')
            adjustment = np.frombuffer(delta, dtype='i1').reshape(clip.shape)
            if np.abs(adjustment.astype(np.int16)).max() > 1:
                raise ValueError('PCM correction exceeds one unit')
            corrected = clip.astype(np.int32) + adjustment
            if corrected.min() < -32768 or corrected.max() > 32767:
                raise ValueError('PCM correction overflows')
            corrected = corrected.astype('<i2')
            if sha(corrected.tobytes()) != primary[effect]:
                raise ValueError('PCM correction does not reproduce its approved clip')
            out[effect] = corrected
        return out
    actual = ', '.join((f'{key:#04x}={value[:16]}' for key, value in raw.items()))
    raise SystemExit("pce_sfx: unrecognized PCM capture; none of the verified MAME 0.288 profiles matches all five effects. On Linux, use the kit's included MAME helper; otherwise supply a verified MAME 0.288 build. Clip hashes: " + actual)
