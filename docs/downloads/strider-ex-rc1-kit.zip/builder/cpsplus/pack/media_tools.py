from ffmpeg_runtime import Executable, add_arguments, configure, resolve
def ffmpeg_exe(): return resolve("ffmpeg")
def ffprobe_exe(): return resolve("ffprobe")
