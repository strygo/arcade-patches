"""Qualify the actual installer while refusing compiler and assembler calls."""
import argparse
import atexit
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import threading

def command_arguments(command):
    if not isinstance(command, str):
        return list(command)
    if os.name != 'nt':
        raise ValueError('unexpected string subprocess arguments')
    import ctypes
    from ctypes import wintypes
    shell = ctypes.WinDLL('shell32', use_last_error=True)
    kernel = ctypes.WinDLL('kernel32', use_last_error=True)
    shell.CommandLineToArgvW.argtypes = [wintypes.LPCWSTR, ctypes.POINTER(ctypes.c_int)]
    shell.CommandLineToArgvW.restype = ctypes.POINTER(wintypes.LPWSTR)
    kernel.LocalFree.argtypes = [wintypes.HLOCAL]
    kernel.LocalFree.restype = wintypes.HLOCAL
    count = ctypes.c_int()
    argv = shell.CommandLineToArgvW(command, ctypes.byref(count))
    if not argv:
        raise ctypes.WinError(ctypes.get_last_error())
    try:
        return [argv[i] for i in range(count.value)]
    finally:
        kernel.LocalFree(argv)

def python_options(command):
    result = []
    for value in command[1:]:
        if not value.startswith('-') or value in ('-c', '-m', '--'):
            break
        result.append(value)
    return result

def install():
    folder = Path(os.environ['STREX_RECIPIENT_AUDIT'])
    calls = []
    lock = threading.Lock()

    def finish():
        if folder.is_dir():
            with lock:
                (folder / (str(os.getpid()) + '.json')).write_text(json.dumps(dict(pid=os.getpid(), parent=os.getppid(), calls=calls)))
    finish()

    def after_fork():
        nonlocal lock, calls
        lock = threading.Lock()
        calls = []
        finish()
    if hasattr(os, 'register_at_fork'):
        os.register_at_fork(after_in_child=after_fork)

    def audit(event, args):
        if event == 'subprocess.Popen':
            command = command_arguments(args[1])
            name = Path(os.fsdecode(args[0] or command[0])).name.lower().removesuffix('.exe')
            calls.append(name)
            finish()
            if name in ('git', 'make', 'cmake', 'ninja', 'cc', 'c++', 'gcc', 'g++', 'clang', 'clang++', 'cl', 'xcrun') or any((word in name for word in ('vasm', 'gcc', 'clang'))):
                raise RuntimeError('Compiler or assembler is forbidden: ' + name)
            if name.startswith('python'):
                if any((v in ('-I', '-S', '-E') for v in python_options(command))):
                    raise RuntimeError('Recipient Python bypasses the inherited audit')
                if args[3] is not None and args[3].get('STREX_RECIPIENT_AUDIT') != str(folder):
                    raise RuntimeError('Recipient Python removes the inherited audit')
    sys.addaudithook(audit)
    atexit.register(finish)

def self_test():
    assert python_options(['python', '-B', 'asm_payload.py', '--', '-I', 'includes']) == ['-B']
    assert python_options(['python', '-I', '-B', '-c', 'pass']) == ['-I', '-B']
    if os.name == 'nt':
        command = ['C:\\Program Files\\Python\\python.exe', '-B', 'two words', '', 'café']
        assert command_arguments(subprocess.list2cmdline(command)) == command
    with tempfile.TemporaryDirectory(prefix='strider-audit-test-') as temp:
        root = Path(temp)
        module = Path(__file__).resolve().parent
        (root / 'sitecustomize.py').write_text('from compiler_free_recipient import install\ninstall()\n')
        env = dict(os.environ, STREX_RECIPIENT_AUDIT=str(root), PYTHONPATH=os.pathsep.join([str(root), str(module)]))
        child = root / 'child.py'
        child.write_text('pass\n')
        normal = subprocess.run([sys.executable, str(child), '-I', 'include'], env=env, capture_output=True)
        assert normal.returncode == 0
        code = 'import subprocess,sys; subprocess.run([sys.executable,' + repr(str(child)) + ',"-I","include"],check=True)'
        normal = subprocess.run([sys.executable, '-c', code], env=env, capture_output=True)
        assert normal.returncode == 0
        for executable in ('make', 'vasmm68k_mot'):
            code = 'import subprocess; subprocess.run([' + repr(executable) + '])'
            run = subprocess.run([sys.executable, '-c', code], env=env, capture_output=True, text=True)
            assert run.returncode and 'Compiler or assembler is forbidden: ' + executable in run.stderr
        code = 'import subprocess,sys; subprocess.run([sys.executable,"-I","-c","pass"])'
        run = subprocess.run([sys.executable, '-c', code], env=env, capture_output=True, text=True)
        assert run.returncode and 'bypasses the inherited audit' in run.stderr
    print('PASS recipient audit: include flags accepted; make, assembler and Python isolation refused')

def main():
    from kit_runtime import enable_utf8
    enable_utf8()
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--receipt', type=Path)
    p.add_argument('--self-test', action='store_true')
    a, argv = p.parse_known_args()
    if a.self_test:
        self_test()
        return
    if a.receipt is None:
        p.error('--receipt is required')
    if argv and argv[0] == '--':
        argv = argv[1:]
    kit = Path(__file__).resolve().parent
    with tempfile.TemporaryDirectory(prefix='strider-recipient-') as temp:
        temp = Path(temp)
        (temp / 'sitecustomize.py').write_text('from compiler_free_recipient import install\ninstall()\n')
        env = dict(os.environ, STREX_RECIPIENT_AUDIT=str(temp), PYTHONPATH=os.pathsep.join([str(temp), str(kit), os.environ.get('PYTHONPATH', '')]))
        env.pop('STREX_RECORD_ASSEMBLY', None)
        run = subprocess.run([sys.executable, '-B', str(kit / 'apply.py'), *argv], env=env)
        rows = [json.loads(q.read_text()) for q in temp.glob('*.json')]
        calls = [c for row in rows for c in row['calls']]
        python_calls = sum((name.startswith('python') for name in calls))
        passed = run.returncode == 0 and len(rows) >= python_calls + 1
        receipt = dict(schema='striderex-compiler-free-recipient/1', passed=passed, exit_code=run.returncode, audited_python_processes=len(rows), python_subprocesses=python_calls, compiler_and_assembler_calls_refused=True, subprocess_counts={name: calls.count(name) for name in sorted(set(calls))})
        a.receipt.parent.mkdir(parents=True, exist_ok=True)
        a.receipt.write_text(json.dumps(receipt, sort_keys=True, indent=2) + '\n')
        if not passed:
            raise SystemExit('Compiler-free recipient qualification failed')
        print('PASS compiler-free recipient:', len(rows), 'audited Python processes', flush=True)
if __name__ == '__main__':
    main()
