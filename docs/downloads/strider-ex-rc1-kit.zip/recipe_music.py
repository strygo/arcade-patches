"""Emit the accepted soundtrack once from final ordered track recipes."""
import hashlib
import numpy as np
from scipy import signal
from cpsplus.pack import adxcodec
from cpsplus.pack.format import PackWriter, Protocol, TrackMeta, TriggerRow
from recipe_engine import require, sha

def pcm(row, source):
    x = np.frombuffer(source, '<i2').reshape(-1, 2).astype(np.float64) / 32768
    x = signal.resample_poly(x[row['trim']:], 160, 147, axis=0, window=('kaiser', 8.6))
    loop = row['blend']
    if loop is None:
        y = np.pad(x, ((0, -len(x) % 32), (0, 0)))
    else:
        a, b, n = loop
        require(0 < n <= a < b <= len(x) and all((v % 32 == 0 for v in loop)), 'invalid music loop')
        y = x[:b].copy()
        weight = np.linspace(0.0, 1.0, n)[:, None]
        y[b - n:b] = x[b - n:b] * (1 - weight) + x[a - n:a] * weight
    if row['clip_float'] and (not np.isfinite(y).all() or np.max(np.abs(y)) >= 1):
        y = np.clip(y, -32767 / 32768, 32767 / 32768)
    raw = np.rint(y * 32768).clip(-32768, 32767).astype('<i2').tobytes()
    require(sha(raw) == row['pcm_sha256'], 'music PCM differs')
    return raw

def build(plan, resources, out):
    spec = dict(plan['protocol'])
    spec['control_verbs'] = {int(k): v for k, v in spec['control_verbs'].items()}
    spec['arg_commands'] = set(spec['arg_commands'])
    w = PackWriter(Protocol(**spec), title=plan['title'], trigger_rows=len(plan['triggers']), default_rate=plan['default_rate'], xfade_samples=plan['xfade_samples'])
    for index, row in enumerate(plan['tracks']):
        if row['kind'] == 'disc':
            stream = adxcodec.encode(pcm(row, resources.sources[row['source']]), 2, 48000)
        elif row['kind'] == 'resource':
            stream = resources.emit(row['resource'])
        elif row['kind'] == 'xor_track':
            base = row['base_track']
            require(type(base) is int and 0 <= base < index, 'invalid audio stream reference')
            require(plan['tracks'][base]['kind'] == 'disc' and plan['tracks'][base]['source'] == row['source'], 'wrong audio source family')
            original = w.tracks[base][0]
            require(sha(original) == row['base_sha256'], 'audio reference identity differs')
            delta = resources.emit(row['resource'])
            require(len(original) == len(delta), 'audio reference extent differs')
            stream = bytes((a ^ b for a, b in zip(original, delta)))
        else:
            raise ValueError('unknown music recipe')
        require(sha(stream) == row['sha256'], 'music stream differs: ' + str(index))
        w.add_track(stream, TrackMeta(**row['meta']))
    w.triggers = [TriggerRow(**row) for row in plan['triggers']]
    w.write(out, sidecar=False)
    require(sha(out.read_bytes()) == plan['sha256'], 'complete soundtrack differs')
