"""Bounded source-copy and source-keyed resource recipes; standard library only."""
import hashlib
import lzma
import struct
import zlib
SCHEMA = 'striderex-resource-recipes/1'
MAX_RESOURCE = 32 * 1024 * 1024

def sha(data):
    return hashlib.sha256(data).hexdigest()

def require(condition, message):
    if not condition:
        raise ValueError(message)

def source_key(source):
    return hashlib.sha512(b'Strider EX resource source v1\x00' + source).digest()

def mask(data, key, label):
    seed = hashlib.sha512(key + label.encode('ascii')).digest()
    stream = b''.join((hashlib.sha512(seed + struct.pack('<Q', i)).digest() for i in range((len(data) + 63) // 64)))
    return bytes((a ^ b for a, b in zip(data, stream)))

class Resources:

    def __init__(self, recipe, payload, sources):
        require(recipe.get('schema') == SCHEMA, 'unknown resource recipe schema')
        require(len(payload) == recipe['payload']['bytes'] and sha(payload) == recipe['payload']['sha256'], 'resource container differs')
        self.recipe, self.payload, self.sources = (recipe, payload, sources)
        require(set(sources) == set(recipe['sources']), 'source inventory differs')
        self.keys = {}
        at = 0
        for name, row in sorted(recipe['blobs'].items(), key=lambda pair: pair[1]['offset']):
            require(row['offset'] == at and 0 < row['bytes'] <= MAX_RESOURCE, 'resource container gap, overlap or invalid size')
            require(0 < row['decoded_bytes'] <= MAX_RESOURCE, 'invalid decoded resource size')
            at += row['bytes']
            require(at <= len(payload) and sha(payload[row['offset']:at]) == name, 'resource fragment differs')
            require(row['source'] in sources, 'unknown resource source')
            require(row.get('compression', 'zlib') in ('zlib', 'xz'), 'unknown resource compression')
        require(at == len(payload), 'resource container has trailing bytes')
        for name, data in sources.items():
            spec = recipe['sources'].get(name)
            require(spec is not None and len(data) == spec['bytes'] and (sha(data) == spec['sha256']), 'source identity differs: ' + name)

    def blob(self, name):
        row = self.recipe['blobs'][name]
        source = row['source']
        if source not in self.keys:
            self.keys[source] = source_key(self.sources[source])
        data = self.payload[row['offset']:row['offset'] + row['bytes']]
        packed = mask(data, self.keys[source], row['label'])
        if row.get('compression', 'zlib') == 'xz':
            decoder = lzma.LZMADecompressor(format=lzma.FORMAT_XZ, memlimit=64 * 1024 * 1024)
            raw = decoder.decompress(packed, max_length=row['decoded_bytes'] + 1)
            bounded = decoder.eof and (not decoder.unused_data)
        else:
            decoder = zlib.decompressobj()
            raw = decoder.decompress(packed, row['decoded_bytes'] + 1)
            bounded = decoder.eof and (not decoder.unused_data) and (not decoder.unconsumed_tail)
        require(bounded and len(raw) == row['decoded_bytes'] and (sha(raw) == row['decoded_sha256']), 'source-bound resource decode failed')
        return raw

    def emit(self, row):
        require(0 < row['bytes'] <= MAX_RESOURCE, 'invalid output extent')
        out = bytearray()
        for op in row['ops']:
            require(len(op) == 1, 'invalid recipe operation')
            if 'copy' in op:
                name, at, count = op['copy']
                require(name in self.sources and isinstance(at, int) and isinstance(count, int) and (at >= 0) and (count > 0) and (at + count <= len(self.sources[name])), 'invalid source-copy extent')
                data = self.sources[name][at:at + count]
            elif 'fill' in op:
                value, count = op['fill']
                require(isinstance(value, int) and 0 <= value <= 255 and isinstance(count, int) and (0 < count <= row['bytes'] - len(out)), 'invalid fill extent')
                data = bytes([value]) * count
            elif 'blob' in op:
                data = self.blob(op['blob'])
            elif 'xor' in op:
                source, blob = op['xor']
                require(source in self.sources, 'unknown XOR source')
                delta = self.blob(blob)
                require(len(delta) == len(self.sources[source]), 'XOR source extent differs')
                data = bytes((a ^ b for a, b in zip(self.sources[source], delta)))
            else:
                raise ValueError('unknown recipe operation')
            require(len(out) + len(data) <= row['bytes'], 'recipe exceeds output extent')
            out.extend(data)
        require(len(out) == row['bytes'] and sha(out) == row['sha256'], 'reconstructed resource differs')
        return bytes(out)
