Night Warriors: Darkstalkers' Revenge · English restoration
===========================================================

Version:  rc1 (2026-10-06)
Target:   MAME set 'vhuntj' (Vampire Hunter: Darkstalkers' Revenge (Japan 950316))
Hardware: Capcom CPS-2
Patch by: Steve Gordon (https://x.com/strygo)
Website:  https://strygo.github.io/arcade-patches/

ABOUT THIS PROJECT

Night Warriors left a lot of Vampire Hunter behind. Every export version skips
the epilogue that follows each ending. The endings were rewritten, with
different page counts on most routes, and each fighter gets a handful of fixed
win quotes where the Japanese game picks from a much larger pool.

The English Restoration brings back all 14 epilogues, rebuilds the 112 ending
pages with the Japanese scenes and pacing, and restores the full pool of 323
win quotes, all translated from the Japanese.

Sasquatch’s Japanese victory poses and their sounds are back, along with
Morrigan’s and Donovan’s extra win sounds.

It keeps the Night Warriors title, the Western character names and the English
operator menu with the USA settings. It runs in MAME and HBMAME and on MiSTer.

This is a release candidate.

WHAT'S CHANGED

  - All 14 epilogues after the endings, in English; every export version
    skipped them
  - The 112 Japanese ending pages in English, with the Japanese scenes and
    pacing
  - The full pool of 323 Japanese win quotes in English, picked as in Japan
  - Sasquatch’s Japanese victory poses and sounds, and Morrigan’s and
    Donovan’s extra win sounds
  - The Night Warriors title, Western character names and the USA operator
    menu

HOW TO APPLY (recommended)

    python3 apply.py /path/to/vhuntj.zip --out-dir out

This checks every file against the original, applies the patches, checks
the result, and writes everything you need for each platform:

  MAME / original hardware: out/mame/vhuntj.zip
  HBMAME:                   out/hbmame/nwarrru.zip
  MiSTer:                   out/mister/_Arcade/_Arcade Patches/_Restorations/Night Warriors Darkstalkers' Revenge (USA) [English Restoration].mra

MAME: put vhuntj.zip from out/mame/ ahead of the stock set in your MAME
rompath.
MAME reports checksum warnings for the patched ROMs; that's expected and
the game runs normally.

HBMAME: this restoration is an official HBMAME set (nwarrru),
so full HBMAME collections may already carry it.
Put nwarrru.zip and qsound.zip in HBMAME's roms/ folder;
it holds the complete set and loads with no checksum warnings.

MiSTer: copy the _Arcade folder from out/mister/ to the root of your SD card
and keep the stock, unmodified romset at games/mame/vhuntj.zip (split MAME
sets also need qsound.zip). The MRA applies the restoration in memory as the
game loads, so nothing on the card is modified. You need Jotego's jtcps2
core, which update_all installs. The MRAs are also a separate download.

HOW TO APPLY (any IPS patcher)

Extract vhuntj.zip, apply each file in ips/ to the ROM file of the
same name (Flips, Lunar IPS, or any IPS tool), then re-zip everything
as vhuntj.zip.

CHANGED FILES

    vph.13m  (4.0 MB)  CRC32 c51baf99 -> da6e5f0d
    vph.15m  (4.0 MB)  CRC32 3ce83c77 -> 82fe8661
    vph.19m  (4.0 MB)  CRC32 9ff60250 -> d3789851
    vphj.03f  (512 KB)  CRC32 3de2e333 -> 8bb491f7
    vphj.04c  (512 KB)  CRC32 c95cf304 -> 5a592e49
    vphj.05d  (512 KB)  CRC32 50de5ddd -> 832ea9f4
    vphj.10b  (512 KB)  CRC32 32c7d8f0 -> daa98fe2

All other files in the set are unmodified.

LEGAL

This is a free, unofficial fan patch. It is not affiliated with or endorsed
by Capcom. All game titles, characters, and artwork remain the property of
their respective owners. You must own the game to use this patch. Do not
sell this patch or distribute it applied to a ROM image.
