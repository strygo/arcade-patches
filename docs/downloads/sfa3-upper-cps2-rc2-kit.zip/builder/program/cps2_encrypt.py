#!/usr/bin/env python3
"""
cps2_encrypt.py -- exact inverse of cps2_crypt.py (CPS-2 program opcode
decryption, Andreas Naive / Nicola Salmoria algorithm).

Given a plaintext 68K opcode word at a word address, produce the ciphertext
word such that cps2_crypt.decrypt returns the original plaintext. This lets a
custom-built plaintext maincpu image be packaged as an encrypted CPS-2 romset
that MAME decrypts back to the intended code.

Only the crypto (GPL, mirroring MAME src/mame/capcom/cps2crypt.cpp) is
reproduced here; no game code is embedded.

WHY A CLEAN INVERSE EXISTS
--------------------------
The CPS-2 data transform is a 4-round Feistel network operating on a 16-bit
word.  _feistel(val, gA, gB, s, k) is:

    split:   l,r  <- disjoint bit-permutation of the 16 input bits
             (bit i of l = bit gB[i] of val; bit i of r = bit gA[i] of val)
    rounds:  l ^= fn(r,k0); r ^= fn(l,k1); l ^= fn(r,k2); r ^= fn(l,k3)
    unsplit: bit gA[i] of out = bit i of l; bit gB[i] of out = bit i of r
             (exactly the inverse permutation of `split`)

A Feistel round is self-inverting when its subkeys are applied in reverse, and
the split/unsplit permutations are mutual inverses.  Hence the inverse of the
whole primitive is:

    split
    r ^= fn(l,k3); l ^= fn(r,k2); r ^= fn(l,k1); l ^= fn(r,k0)
    unsplit

Encryption reuses the ENTIRE key schedule of the decryptor unchanged (FN1 seed
generation over the address index, master-key mixing, _expand/_ES subkey
derivation).  Only the final FN2 data permutation is inverted.  The per-word
key2 depends solely on (address & 0xffff) and master_key, so encryption is a
per-index bijection -- no brute force needed.
"""

from cps2_crypt import (
    BIT, _FN1, _FN2, _mkboxes, _fn, _bs8,
    FN1_GA, FN1_GB, FN2_GA, FN2_GB,
    _E1, _E2, _expand, _expand_subkey, _feistel,
    decode_key,
)
import hashlib
import os
import pickle


KEY2_CACHE_VERSION = 1


def _feistel_dec(val, gA, gB, rounds, k):
    """Inverse of cps2_crypt._feistel.

    Note the forward primitive has a built-in L/R swap: its input `split`
    fills l from the gB bit-group and r from the gA group, while its output
    `unsplit` writes l back to the gA group and r to the gB group.  Because of
    that swap, inverting is NOT simply "same split, reversed rounds, same
    unsplit" -- the two endpoints must be swapped too.

    Forward, in terms of the shared helpers:
        l0 = val@gB, r0 = val@gA                 (split)
        l ^= fn(r,k0); r ^= fn(l,k1); l ^= fn(r,k2); r ^= fn(l,k3)
        out@gA = l4, out@gB = r4                 (unsplit)

    So applying `split` to the CIPHERTEXT yields (out@gB, out@gA) = (r4, l4).
    We reverse the rounds, then reconstruct the plaintext with a swapped
    `unsplit` (val@gA = r0, val@gB = l0).  Verified to invert _feistel exactly
    over all 65536 inputs for arbitrary key vectors.
    """
    # split(ciphertext) = (r4, l4)  -->  recover l4, r4
    a = _bs8(val, [gB[7], gB[6], gB[5], gB[4], gB[3], gB[2], gB[1], gB[0]])  # r4
    b = _bs8(val, [gA[7], gA[6], gA[5], gA[4], gA[3], gA[2], gA[1], gA[0]])  # l4
    l, r = b, a
    # rounds reversed
    r ^= _fn(l, rounds[3], k[3])
    l ^= _fn(r, rounds[2], k[2])
    r ^= _fn(l, rounds[1], k[1])
    l ^= _fn(r, rounds[0], k[0])
    # now l == l0 (val@gB), r == r0 (val@gA); rebuild val with swapped unsplit
    o = 0
    for i in range(8):
        o |= BIT(r, i) << gA[i]
        o |= BIT(l, i) << gB[i]
    return o


def _key2_schedule(master_key):
    """Build the per-low-address FN2 key schedule for a CPS-2 master key.

    This is independent of the ROM bytes and dominates repeated pack time, so mamepack can persist it
    under extraction/link/ for quick iteration.
    """
    s1 = _mkboxes(_FN1)

    # ---- FN1 first-stage key schedule: identical to the decryptor ----
    key1 = _expand(_E1, master_key, 4)
    key1[0] ^= BIT(key1[0], 1) << 4
    key1[0] ^= BIT(key1[0], 2) << 5
    key1[0] ^= BIT(key1[0], 8) << 11
    key1[1] ^= BIT(key1[1], 0) << 5
    key1[1] ^= BIT(key1[1], 8) << 11
    key1[2] ^= BIT(key1[2], 1) << 5
    key1[2] ^= BIT(key1[2], 8) << 11

    sched = []
    for i in range(0x10000):
        seed = _feistel(i, FN1_GA, FN1_GB, s1, key1)
        sk = _expand_subkey(seed)
        sk[0] ^= master_key[0]
        sk[1] ^= master_key[1]
        key2 = _expand(_E2, sk, 4)
        key2[0] ^= BIT(key2[0], 0) << 5
        key2[0] ^= BIT(key2[0], 6) << 11
        key2[1] ^= BIT(key2[1], 0) << 5
        key2[1] ^= BIT(key2[1], 1) << 4
        key2[2] ^= BIT(key2[2], 2) << 5
        key2[2] ^= BIT(key2[2], 3) << 4
        key2[2] ^= BIT(key2[2], 7) << 11
        key2[3] ^= BIT(key2[3], 1) << 5
        sched.append(tuple(key2))
    return sched


def load_key2_schedule(master_key, key_bytes=None, cache_dir=None):
    """Return the FN2 key schedule, optionally using a persistent cache."""
    if not cache_dir:
        return _key2_schedule(master_key)
    os.makedirs(cache_dir, exist_ok=True)
    if key_bytes is None:
        ident = '%08x%08x' % (master_key[0], master_key[1])
    else:
        ident = hashlib.sha1(key_bytes).hexdigest()[:16]
    path = os.path.join(cache_dir, 'cps2_key2_%s.pkl' % ident)
    try:
        with open(path, 'rb') as f:
            version, sched = pickle.load(f)
        if version == KEY2_CACHE_VERSION and len(sched) == 0x10000:
            return sched
    except (OSError, EOFError, pickle.PickleError, ValueError):
        pass
    sched = _key2_schedule(master_key)
    tmp = path + '.tmp'
    with open(tmp, 'wb') as f:
        pickle.dump((KEY2_CACHE_VERSION, sched), f, protocol=pickle.HIGHEST_PROTOCOL)
    os.replace(tmp, path)
    return sched


def encrypt_words(plain_words, master_key, lower_w, upper_w, key2_schedule=None):
    """Inverse of decrypt_words: plaintext words -> ciphertext words.

    plain_words : list of 16-bit LE-native word values (same convention MAME
                  and cps2_crypt use for the maincpu region).
    Returns a new list; words outside [lower_w, upper_w] pass through verbatim
    (CPS-2 encrypts only the opcode region, exactly like the decryptor).
    """
    s2 = _mkboxes(_FN2)
    sched = key2_schedule if key2_schedule is not None else _key2_schedule(master_key)

    n = len(plain_words)
    enc = list(plain_words)
    for i, key2 in enumerate(sched):
        a = i
        while a < n:
            if lower_w <= a <= upper_w:
                # INVERSE FN2 permutation (subkeys reversed)
                enc[a] = _feistel_dec(plain_words[a], FN2_GA, FN2_GB, s2, key2)
            a += 0x10000
    return enc


def encrypt_word(plain_word, address, master_key, lower_w=0x0, upper_w=0xffffffff):
    """Encrypt a single plaintext opcode word at the given WORD address.

    address is a word address (byte address >> 1), matching the indexing used
    throughout cps2_crypt.  Outside [lower_w, upper_w] the word is returned
    unchanged.  Convenience wrapper; encrypt_words is far faster for bulk work
    because it builds the key schedule once per 16-bit index.
    """
    if not (lower_w <= address <= upper_w):
        return plain_word
    s1 = _mkboxes(_FN1)
    s2 = _mkboxes(_FN2)
    key1 = _expand(_E1, master_key, 4)
    key1[0] ^= BIT(key1[0], 1) << 4
    key1[0] ^= BIT(key1[0], 2) << 5
    key1[0] ^= BIT(key1[0], 8) << 11
    key1[1] ^= BIT(key1[1], 0) << 5
    key1[1] ^= BIT(key1[1], 8) << 11
    key1[2] ^= BIT(key1[2], 1) << 5
    key1[2] ^= BIT(key1[2], 8) << 11

    i = address & 0xffff
    seed = _feistel(i, FN1_GA, FN1_GB, s1, key1)
    sk = _expand_subkey(seed)
    sk[0] ^= master_key[0]
    sk[1] ^= master_key[1]
    key2 = _expand(_E2, sk, 4)
    key2[0] ^= BIT(key2[0], 0) << 5
    key2[0] ^= BIT(key2[0], 6) << 11
    key2[1] ^= BIT(key2[1], 0) << 5
    key2[1] ^= BIT(key2[1], 1) << 4
    key2[2] ^= BIT(key2[2], 2) << 5
    key2[2] ^= BIT(key2[2], 3) << 4
    key2[2] ^= BIT(key2[2], 7) << 11
    key2[3] ^= BIT(key2[3], 1) << 5
    return _feistel_dec(plain_word, FN2_GA, FN2_GB, s2, key2)


def encrypt(plain_bytes, key_bytes, cache_dir=None, *, code_spans=(), profile=None):
    """Encrypt a raw plaintext maincpu image (BE/LE-native 16-bit words, same
    byte convention as cps2_crypt.decrypt_rom).

    Returns (enc_bytes, master_key, lower_w, upper_w, decoded). The shared
    code-range guard runs before key scheduling or encryption. Pass complete
    executable allocations as code_spans to cover indirect callback bodies.
    `profile` (8 or 12) declares the CPS-2+ program profile of the image this
    program belongs to; without it the guard runs exactly as before.
    """
    from cps2_code_guard import check_opcode_image
    if profile is None:
        check_opcode_image(plain_bytes, key_bytes, code_spans=code_spans)
    else:
        check_opcode_image(plain_bytes, key_bytes, code_spans=code_spans, profile=profile)
    mk, lo, hi, decoded = decode_key(key_bytes)
    sched = load_key2_schedule(mk, key_bytes, cache_dir)
    # Big-endian 68000 words, matching cps2_crypt.decrypt_rom's convention
    # (ROM_LOAD16_WORD_SWAP layout read as native LE on a LE host == true BE).
    words = [((plain_bytes[2 * a] << 8) | plain_bytes[2 * a + 1])
             for a in range(len(plain_bytes) // 2)]
    enc = encrypt_words(words, mk, lo, hi, sched)
    out = bytearray(len(plain_bytes))
    for a, w in enumerate(enc):
        out[2 * a] = (w >> 8) & 0xff
        out[2 * a + 1] = w & 0xff
    return bytes(out), mk, lo, hi, decoded


if __name__ == '__main__':
    import sys
    plain = b''.join(open(f, 'rb').read() for f in sys.argv[1].split(','))
    key = open(sys.argv[2], 'rb').read()
    enc, mk, lo, hi, decoded = encrypt(plain, key)
    print(f"master_key = {mk[0]:08x} {mk[1]:08x}  enc range words "
          f"[{lo:#x},{hi:#x}] = bytes [{lo*2:#x},{hi*2:#x}]  "
          f"decoded[9]={decoded[9]:#06x}")
    if len(sys.argv) > 3:
        open(sys.argv[3], 'wb').write(enc)
        print(f"wrote {sys.argv[3]} ({len(enc)} bytes)")
