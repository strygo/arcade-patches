"""Materialize public reconstruction pools from supplied original media.

All binary files emitted here are private temporary build inputs. They are
recreated by this same module on the recipient's machine, never distributed.
"""
from __future__ import annotations
import hashlib
import json
from pathlib import Path
import zipfile

import public_kit_media as media
import public_kit_graphics as gfx


def arcade(pins, roots):
    wanted = {row['sha1']: (region, name, row['bytes'])
              for region, data in pins['arcade'].items() for name, row in data['members'].items()}
    found = {}
    for root in roots:
        for machine in pins['arcade_search_sets']:
            path = Path(root)/(machine+'.zip')
            if not path.is_file():
                continue
            with zipfile.ZipFile(path) as archive:
                for info in archive.infolist():
                    if info.is_dir():
                        continue
                    data = archive.read(info)
                    sha = hashlib.sha1(data).hexdigest()
                    if sha in wanted:
                        media.require(len(data) == wanted[sha][2], 'Stock member extent differs')
                        found[sha] = data
    result = {}
    for region, source in pins['arcade'].items():
        missing = [name for name, pin in source['members'].items() if pin['sha1'] not in found]
        media.require(not missing, 'Missing canonical '+source['set']+' members: '+', '.join(missing))
        result[region] = {name: found[pin['sha1']] for name, pin in source['members'].items()}
    return result


def produce(args):
    import bizlz
    import naomi_graphics
    import public_kit_extra_graphics as extra
    config = json.loads(args.contract.read_text())
    pins = config['inputs']
    media.require(not args.out.exists(), 'Source pool output must be fresh')
    args.out.mkdir()
    catalog = {'schema': 1, 'contract_sha256': media.digest(args.contract.read_bytes()), 'pools': {}}

    def save(name, data, **metadata):
        media.require(name not in catalog['pools'] and Path(name).name == name, 'Duplicate/unsafe pool')
        (args.out/name).write_bytes(data)
        catalog['pools'][name] = {'bytes': len(data), 'sha256': media.digest(data), **metadata}

    for region, members in arcade(pins, args.rompath).items():
        for name, data in members.items():
            save('arcade-'+region+'-'+name, data, kind='rom', region=region, member=name)
        pixels = gfx.planar_to_pixels(gfx.shuffle_bus(gfx.graphics_bus(members)))
        save('arcade-'+region+'-pixels.bin', pixels, kind='graphics', region=region, tile_bytes=128)
        save('arcade-'+region+'-cloud-continuation.bin', gfx.cloud_continuation(pixels),
             kind='graphics', region=region, tile_bytes=128)
        print('Canonical '+region+' graphics pool complete', flush=True)
    attract_metadata = {}
    for region in ('us', 'jp'):
        with media.ps2(getattr(args, 'ps2_'+region), pins['ps2'][region], args.scratch, args.chdman) as disc:
            for index, component in enumerate(disc.components()):
                save('ps2-'+region+'-comp'+str(index+1)+'.bin', component, kind='program', region=region)
            for number, sections in sorted(config['ps2_tiles'].items(), key=lambda row: int(row[0])):
                blob = disc.entry(int(number))
                for index, section in enumerate(sections):
                    pixels, mask = gfx.decode_tiles(blob, section['count'], section['table'], section['tile_bytes'])
                    name = 'ps2-'+region+'-entry'+number+'-s'+str(index)
                    save(name+'.bin', pixels, kind='graphics', region=region, tile_bytes=section['tile_bytes'],
                         validity=name+'.mask')
                    save(name+'.mask', mask, kind='validity', region=region)
            font, _ = bizlz.decompress(disc.entry(353))
            media.require(font is not None and len(font) % 128 == 0, 'Invalid Upper raw font pool')
            save('ps2-'+region+'-font353.bin', font, kind='graphics', region=region, tile_bytes=128)
            coords, _ = bizlz.decompress(disc.entry(390))
            media.require(coords is not None and len(coords) % 4 == 0, 'Coordinate table extent')
            save('ps2-'+region+'-coords390.bin', coords, kind='coordinates', region=region)
            attract_metadata[region] = bizlz.decompress(disc.entry(522), max_out=16*1024**2)[0]
            print('PS2 '+region+' graphic and program pools complete', flush=True)
    with media.naomi(args.naomi_chd, args.naomi_pic, pins['naomi'], args.scratch, args.chdman) as (data, files):
        save('naomi-program.bin', data[:0x1000000], kind='program', region='shared')
        for name in [*(f'PL{number:02X}.PAC' for number in range(38)), 'TITLE.PAC']:
            offset, size = files[name]
            sections = naomi_graphics.read_pac_sections(data[offset:offset+size])
            # TITLE's established producer selects section index 1, which has
            # a different type tag from PL fighter resources. Bind its actual
            # title tile below instead of assigning it the fighter tag.
            if name != 'TITLE.PAC':
                media.require(sections[1][0] == 0x200000, 'Unknown NAOMI fighter graphics section')
            records = naomi_graphics.parse_pl_record_stream(sections[1][1])
            decoded = {}
            pixels = bytearray()
            for record in records:
                if record not in decoded:
                    tile = naomi_graphics.decode_pl_runtime_record(record)
                    linear = naomi_graphics.untwiddle_clut4_texture(tile, 16, 16)
                    decoded[record] = bytes(((b & 15)-1) & 15 | (((b >> 4)-1) & 15) << 4 for b in linear)
                pixels.extend(decoded[record])
            if name == 'TITLE.PAC':
                media.require(media.digest(gfx.pixels_to_planar(pixels[282*128:283*128])) ==
                              'c397e97fbdd08af22fd38ac867028f0f18e8f9ff07fa7008e4f00d25773773ca',
                              'Original title registration tile differs')
            save('naomi-'+name+'.bin', bytes(pixels), kind='graphics', region='shared', tile_bytes=128)
            if name == 'TITLE.PAC':
                original = (args.out/'arcade-us-pixels.bin').read_bytes()
                save('derived-title.bin', extra.title(original, pixels), kind='graphics', region='shared', tile_bytes=128)
            print('NAOMI '+name+' graphics pool complete', flush=True)
        offset, size = files['WIN0B.PAC']
        glyph = gfx.naomi_quote_glyph(naomi_graphics.read_pac_sections(data[offset:offset+size]), 0x40)
        media.require(media.digest(glyph) == '7cec0b43664a5af76cdd8cb2e139c7154a0b34e057707a7f8f6ee91fdb32ce4e',
                      'Restored Sagat glyph differs from the declared original')
        save('naomi-WIN0B-glyph40.bin', glyph, kind='graphics', region='shared', tile_bytes=128)
        offset, size = files['OPEN.PAC']
        for region in ('us', 'jp'):
            name = 'ps2-'+region+'-entry455-s0'
            pixels = extra.attract(attract_metadata[region], (args.out/(name+'.bin')).read_bytes(),
                                   (args.out/(name+'.mask')).read_bytes(), data[offset:offset+size])
            save('derived-'+region+'-attract.bin', pixels, kind='graphics', region=region,
                 tile_bytes=128, validity=name+'.mask')
    (args.out/'pools.json').write_text(json.dumps(catalog, indent=2, sort_keys=True)+'\n')
    return catalog


def main():
    import argparse
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--contract', type=Path, required=True)
    parser.add_argument('--rompath', type=Path, action='append', required=True)
    for name in ('ps2-us', 'ps2-jp', 'naomi-chd', 'naomi-pic', 'chdman', 'scratch', 'out'):
        parser.add_argument('--'+name, type=Path, required=True)
    args = parser.parse_args()
    gfx.self_test()
    produce(args)


if __name__ == '__main__':
    main()
