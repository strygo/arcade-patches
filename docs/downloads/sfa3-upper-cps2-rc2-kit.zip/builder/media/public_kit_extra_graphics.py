"""Source-derived title lettering and original arcade attract shading.

No candidate pixels are inputs. All ink comes from canonical arcade glyphs,
the original title mark, or the original Naomi OPEN resource.
"""
import hashlib
import struct
from public_kit_graphics import require


def pens(tile):
    return [v for b in tile for v in (b & 15, b >> 4)]


def packed(values):
    return bytes(values[i] | values[i+1] << 4 for i in range(0, len(values), 2))


def title(arcade, original):
    """Retained compact footer plus the green projection of the original R."""
    width = 208
    image = [15]*(width*16)
    lines = ('@CAPCOM CO.,LTD. 1998, 2001,',
             '@CAPCOM U.S.A., INC. 1998, 2001 ALL RIGHTS RESERVED.')
    for line, text in enumerate(lines):
        for n, ch in enumerate(text):
            if ch == ' ':
                continue
            at = (0x16c00+ord(ch))*128
            glyph = pens(arcade[at:at+128])
            # BOX's integer source coverage for the established 8x8 -> 4x6
            # reduction. The threshold is applied to the averaged mask.
            for y in range(6):
                lo, hi = (y*8*2+6)//12, ((y+1)*8*2+6)//12
                for x in range(4):
                    ink = sum(glyph[yy*16+xx] != 15
                              for yy in range(lo, hi) for xx in (x*2, x*2+1))
                    if (ink*255+(hi-lo))//((hi-lo)*2) >= 96:
                        px, py = n*4+x, line*8+y
                        image[(py+1)*width+px+1] = 0
            for y in range(6):
                lo, hi = (y*8*2+6)//12, ((y+1)*8*2+6)//12
                for x in range(4):
                    ink = sum(glyph[yy*16+xx] != 15
                              for yy in range(lo, hi) for xx in (x*2, x*2+1))
                    if (ink*255+(hi-lo))//((hi-lo)*2) >= 96:
                        image[(line*8+y)*width+n*4+x] = 5
    cells = [packed([image[y*width+n*16+x] for y in range(16) for x in range(16)])
             for n in range(13)]
    mark = pens(original[282*128:283*128])
    mapping = {0: 0, 1: 0, 2: 0, 11: 3, 12: 4, 13: 6, 14: 7, 15: 15}
    require(set(mark) == set(mapping), 'Complete original title mark pen domain')
    return b''.join(cells)+packed([mapping[v] for v in mark])


def attract(metadata, pixels, valid, resource):
    """Project Naomi Evil Ryu shading onto the matching PS2 pose tiles."""
    import naomi_graphics as decoder
    require(hashlib.sha256(metadata).hexdigest() ==
            '3e0635eeadfc2c6925e0ac712e0ce3647ba2c20e76ab98ad419e2263940a0f4f',
            'Original attract metadata identity')
    require(hashlib.sha256(resource).hexdigest() ==
            '6209e3a9dd6548ef331dc7e655e4354bdd0e3c25712a38fc236f2fc86fb25f51',
            'Original arcade OPEN identity')
    base = 0xb83800
    def read(at, size):
        require(base <= at <= base+len(metadata)-size, 'Original attract metadata extent')
        return metadata[at-base:at-base+size]
    root = base+0x94
    offsets = struct.unpack('<42h', read(root, 84))
    require(offsets[-1] == 0 and min(offsets[:-1]) == 84, 'Original attract directory')
    cel = struct.unpack('<I', read(root+offsets[23]+4, 4))[0]
    kind, area, last = struct.unpack('<3H', read(cel, 6))
    require(kind == 2 and last < 64, 'Original attract cel grammar')
    pointer = (cel+9) & ~3
    xy = struct.unpack('<I', read(pointer, 4))[0]
    blocks = [(x, y, word & 65535, word >> 16) for (x, y), (word,) in zip(
        struct.iter_unpack('<2h', read(xy, (last+1)*4)),
        struct.iter_unpack('<I', read(pointer+4, (last+1)*4)))]
    require(sum(((a >> 8 & 15)+1)*((a >> 12 & 15)+1) for _, _, _, a in blocks) == area,
            'Complete original attract tile area')
    def cells():
        for x, y, code, attr in blocks:
            w, h = (attr >> 8 & 15)+1, (attr >> 12 & 15)+1
            for yy in range(h):
                for xx in range(w):
                    sx, sy = (w-1-xx if attr & 32 else xx), (h-1-yy if attr & 64 else yy)
                    tile = (code & ~15)+((code+sx) & 15)+sy*16
                    require(tile < len(valid) and valid[tile], 'Original attract tile supply')
                    for py in range(16):
                        for px in range(16):
                            ix, iy = (15-px if attr & 32 else px), (15-py if attr & 64 else py)
                            at, shift = tile*128+iy*8+ix//2, 4*(ix%2)
                            yield (x+xx*16+px, y+yy*16+py), at, shift
    old = {p: pixels[at] >> shift & 15 for p, at, shift in cells()
           if pixels[at] >> shift & 15 != 15}
    sections = dict(decoder.read_pac_sections(resource))
    desc = sections[0x100000c]
    records = decoder.parse_pl_record_stream(sections[0x200000c])
    at, geometry, _ = struct.unpack_from('<III', desc, 20*12)
    w, h = geometry & 255, geometry >> 8 & 255
    require((w, h) == (4, 7), 'Original arcade Evil body extent')
    arcade = {}
    for cell in range(w*h):
        if desc[at] == 255:
            at += 1
            continue
        code = int.from_bytes(desc[at:at+2], 'big'); flags = desc[at+2]; at += 3
        require(code < len(records) and flags in (0, 0x20), 'Original arcade cell mode')
        tile = decoder.untwiddle_clut4_texture(decoder.decode_pl_runtime_record(records[code]), 16, 16)
        for y in range(16):
            for x in range(16):
                pen = tile[y*8+x//2] >> (4*(x%2)) & 15
                if pen:
                    arcade[cell%w*16+x, cell//w*16+y] = (pen-1) & 15
    dx = min(x for x, y in arcade)-min(x for x, y in old)
    dy = min(y for x, y in arcade)-min(y for x, y in old)
    target = {(x-dx, y-dy): v for (x, y), v in arcade.items()}
    require(set(old) == set(target) and sum(v != target[p] for p, v in old.items()) == 167,
            'Complete original regional/arcade silhouette and shading difference')
    changed = bytearray(pixels)
    for point, at, shift in cells():
        if pixels[at] >> shift & 15 != 15:
            changed[at] = (changed[at] & ~(15 << shift)) | target[point] << shift
    require({p: changed[at] >> shift & 15 for p, at, shift in cells()
             if changed[at] >> shift & 15 != 15} == target, 'Complete arcade shading projection')
    return bytes(changed)
