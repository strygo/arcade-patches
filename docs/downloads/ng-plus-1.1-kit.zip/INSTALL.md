# NG+ — MiSTer installation

Run the builder first (see `README.txt`), then copy everything inside
`out/mister/` to the root of your MiSTer SD card (`/media/fat/`), merging
with what is already there.

```
out/mister/
  _Arcade/
    _Arcade Patches/
      _Arrangements/
        _NG+/
          <Title>.mgl      one launcher per title: the menu entry
          cores/
            NeoGeoPlus_<date>.rbf   the NG+ core (not listed in the menu)
  games/
    NG+/
      <set>.nga            the game images you built
```

The leading underscores are required for MiSTer to show each folder in the
menu.  Every project from this site lives under `_Arcade Patches`, so you
can find (or remove) all of it in one place.

**Saves.**  Nothing here touches your saves.  The MiSTer creates
`saves/NG+/<set>.sav` the first time a title saves (its backup RAM and memory
card), exactly as the stock Neo Geo core does, and keeps it across updates.

Keep the core's file name as it is.  The launchers name the core, and a
renamed core stops resolving.

The NG+ core has its own name, so it keeps its own games, saves and settings
folders.  Your stock Neo Geo core, its games folder and its settings are
never read or changed.

## System and BIOS

NG+ starts every title as the US arcade release: arcade (MVS) mode with the
original BIOS, which the builder takes from your `neogeo.zip` (`sp-u2.sp1`,
the US MVS BIOS).  The core's menu switches **System Type** to console (AES)
and **BIOS** to UniBIOS.  Each title keeps its own settings and its own
button map, as arcade games on the MiSTer do: the menu reads "Define samsho2
buttons" and so on, and a change in one title leaves the others as they are.
Settings saved by earlier NG+ kits under the shared name "NG+" are not
carried over, so each title starts at the US arcade default.

## Verifying the arranged audio

Start a title from the NG+ folder.  The title screen music is the Neo Geo CD
arrangement.  In the core's menu, Audio & Video > Arranged Volume sets its
level against the cartridge's sound effects and voices.
