#!/usr/bin/env python3
"""Build NG+ images or export one complete collection title."""

# BEGIN ARCADE PYTHON BOOTSTRAP
import sys as _arcade_sys
from pathlib import Path as _ArcadePath
_arcade_sys.path.insert(0, str(_ArcadePath(__file__).resolve().parents[0]))
from kit_python import bootstrap as _arcade_bootstrap
_arcade_bootstrap()
# END ARCADE PYTHON BOOTSTRAP
from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parent
sys.path[:0] = [str(ROOT), str(ROOT / 'builder')]
try:
    if '--collection-layout' in sys.argv or '--describe-json' in sys.argv:
        from collection_export import main
        raise SystemExit(main(ROOT))
    from make_ngplus import main
    raise SystemExit(main())
except (OSError, ValueError) as exc:
    if '--debug' in sys.argv:
        raise
    raise SystemExit(f'ERROR: {exc}')
