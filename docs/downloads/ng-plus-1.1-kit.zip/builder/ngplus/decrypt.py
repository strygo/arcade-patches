"""Decryption for the encrypted cartridges the builder reads from MAME sets.

MAME keeps two sets as their chips hold them and decrypts them when the game
starts.  The core runs the decrypted form (the form a Darksoft set or a .neo
carries), so the builder does the same work once, while it reads the set:

  kof98   the 68K program.  The board's protection chip unscrambles the first
          P ROM, whose 2 MiB hold the cartridge's first 1 MiB.
  kof99   the 68K program (the SMA chip's data-line and address-line
          scramble; the chip's own 256 KiB ROM sits at 0x0c0000) and the
          sprites (CMC42).  The fix layer is the last 128 KiB of the
          decrypted sprites, reordered.

Every function here is a port of MAME's code, which is BSD-3-Clause:

  src/devices/bus/neogeo/prot_kof98.cpp  (S. Smith, David Haywood, Fabio Priuli)
  src/devices/bus/neogeo/prot_sma.cpp    (S. Smith, David Haywood, Fabio Priuli,
                                          Razoola, Mr.K)
  src/devices/bus/neogeo/prot_cmc.cpp    (S. Smith, David Haywood, Fabio Priuli)

LICENSE-MAME.txt, next to make_ngplus.py, holds the notice and license text.

Data is in MAME's form: a program region as 16-bit words, low byte first
(the P ROM files' order and the builder's P), and the sprite region as the
byte interleave of each C ROM pair.  Standard library only; the loops MAME
runs per byte or word run here as bytes.translate, big-integer XOR/OR and
array slicing, so the 64 MiB KOF '99 sprite region takes about two seconds.
"""
from __future__ import annotations

import array

SCHEMES = ("kof98", "kof99")

_W16 = "H"
_W32 = next(c for c in "IL" if array.array(c).itemsize == 4)
assert array.array(_W16).itemsize == 2


def program(scheme: str, region: bytes) -> bytes:
    """The cartridge's P image (what it addresses, LE words) from MAME's
    program region with every ROM at its offset."""
    if scheme == "kof98":
        return kof98_program(region)
    if scheme == "kof99":
        return kof99_program(region)
    raise ValueError(f"unknown decryption {scheme!r}")


def sprites(scheme: str, region: bytes) -> tuple[bytes, bytes | None]:
    """(decrypted sprite region, fix layer taken from it or None)."""
    if scheme == "kof98":
        return region, None             # kof98's sprites are not encrypted
    if scheme == "kof99":
        spr = cmc42_sprites(region)
        return spr, sfix_from_sprites(spr, 0x20000)
    raise ValueError(f"unknown decryption {scheme!r}")


# --- bit and byte helpers ----------------------------------------------------

def _contrib(order: tuple[int, ...], shift: int, bits: int) -> list[int]:
    """MAME's bitswap<N>(v, order...) -- result bit N-1-k is bit order[k] of
    v -- as a table: what each value of v's `bits` bits from `shift` adds to
    the result.  A bitswap is the OR of its parts' tables."""
    n = len(order)
    out = []
    for x in range(1 << bits):
        v = x << shift
        out.append(sum(1 << (n - 1 - k) for k, b in enumerate(order) if v >> b & 1))
    return out


def _or(a: bytes, b: bytes) -> bytes:
    return (int.from_bytes(a, "little") | int.from_bytes(b, "little")).to_bytes(len(a), "little")


def _xor(a: bytes, b: bytes) -> bytes:
    return (int.from_bytes(a, "little") ^ int.from_bytes(b, "little")).to_bytes(len(a), "little")


def _bitswap16_words(data: bytes, order: tuple[int, ...]) -> bytes:
    """bitswap<16> on every little-endian word of `data`."""
    lo, hi = data[0::2], data[1::2]
    from_lo, from_hi = _contrib(order, 0, 8), _contrib(order, 8, 8)
    out = bytearray(len(data))
    out[0::2] = _or(lo.translate(bytes(c & 0xFF for c in from_lo)), hi.translate(bytes(c & 0xFF for c in from_hi)))
    out[1::2] = _or(lo.translate(bytes(c >> 8 for c in from_lo)), hi.translate(bytes(c >> 8 for c in from_hi)))
    return bytes(out)


# --- kof98: prot_kof98.cpp kof98_prot_device::decrypt_68k -------------------

_KOF98_SEC = (0x000000, 0x100000, 0x000004, 0x100004, 0x10000A, 0x00000A, 0x10000E, 0x00000E)
_KOF98_POS = (0x000, 0x004, 0x00A, 0x00E)


def kof98_program(region: bytes) -> bytes:
    """MAME's region is 6 MiB (242-p1 at 0, 242-p2 at 0x200000).  The
    decryption turns 242-p1's 2 MiB into the cartridge's first 1 MiB and
    moves 242-p2 down behind it: 5 MiB.  (MAME moves it in place, which
    leaves a stale copy of 242-p2's last MiB past the end; the cartridge
    banks only 242-p2's four.)  Word moves, in MAME's order."""
    if len(region) != 0x600000:
        raise ValueError(f"kof98 program region is {len(region)} bytes, expected 6 MiB")
    src = array.array(_W16, region[:0x200000])      # word index = byte offset / 2
    dst = array.array(_W16, region[:0x200000])
    for i in range(0x800, 0x100000, 0x200):
        for j in range(0, 0x100, 0x10):
            a = (i + j) >> 1
            for k in range(8):
                s = (i + j + _KOF98_SEC[k]) >> 1
                src[a + k] = dst[s + 0x80]
                src[a + k + 0x80] = dst[s]
            if 0x080000 <= i < 0x0C0000:
                for p in _KOF98_POS:
                    q = a + (p >> 1)
                    src[q] = dst[q]
                    src[q + 0x80] = dst[q + 0x80]
            elif i >= 0x0C0000:
                for p in _KOF98_POS:
                    q = a + (p >> 1)
                    src[q] = dst[q + 0x80]
                    src[q + 0x80] = dst[q]
        w = i >> 1
        src[w] = dst[w]
        src[w + 1] = dst[w + 0x80000]
        src[w + 0x80] = dst[w + 0x80]
        src[w + 0x81] = dst[w + 0x80080]
    return src.tobytes()[:0x100000] + region[0x200000:]


# --- kof99: prot_sma.cpp sma_prot_device::kof99_decrypt_68k -----------------

_KOF99_DATA = (13, 7, 3, 0, 9, 4, 5, 6, 1, 12, 8, 14, 10, 11, 2, 15)          # bitswap<16>
_KOF99_BANKED = (6, 2, 4, 9, 8, 3, 1, 7, 0, 5)                                 # bitswap<10>
_KOF99_FIXED = (18, 11, 6, 14, 17, 16, 5, 8, 10, 12, 0, 4, 3, 2, 7, 9, 15, 13, 1)  # bitswap<19>


def kof99_program(region: bytes) -> bytes:
    """MAME's region is 9 MiB: the SMA chip's ROM at 0x0c0000, 251-p1 and
    251-p2 from 0x100000.  All 9 MiB are the cartridge's P (the MiSTer
    loader's quirk table takes KOF '99 only with a 9 MiB P); the first
    0x0c0000 bytes are rebuilt from 251-p2."""
    if len(region) != 0x900000:
        raise ValueError(f"kof99 program region is {len(region)} bytes, expected 9 MiB")
    # swap data lines on the whole ROMs
    w = array.array(_W16, _bitswap16_words(region[0x100000:], _KOF99_DATA))
    # swap address lines for the banked part: within each 0x800-byte block,
    # word j comes from word bitswap<10>(j)
    size = 0x600000 >> 1
    banked = w[:size]
    for j, s in enumerate(_contrib(_KOF99_BANKED, 0, 10)):
        w[j:size:0x400] = banked[s:size:0x400]
    # swap address lines and relocate the fixed part (read from 0x700000)
    lo, hi = _contrib(_KOF99_FIXED, 0, 10), _contrib(_KOF99_FIXED, 10, 9)
    base = (0x700000 - 0x100000) >> 1
    fixed = array.array(_W16, [w[base + (lo[i & 0x3FF] | hi[i >> 10])] for i in range(0x0C0000 >> 1)])
    return fixed.tobytes() + region[0x0C0000:0x100000] + w.tobytes()


# --- kof99 sprites: prot_cmc.cpp cmc42_gfx_decrypt, sfix_decrypt ------------

# The CMC42 tables (MAME's kof99_* tables, which every CMC42 game shares).
_CMC42 = {
    "type0_t03": bytes.fromhex(
        "fb869df1bf80d543abb39f6a33d9dbb666086988ccb7de4997641fa6c02f5242"
        "445af2289887968a830b036171996bb51a8efe04e1f77dddedca37fcef3972da"
        "b8beee7fe53178f3919ad21119b9094cfd6d2a4d65a189c7755021fa1600e912"
        "742b1e4f1401703a4e3ff5f41d3d1527a7ff45e06ef954c848ada50af62d2ce2"
        "6867d685b4c334bc62d35f84065b0d95ea5e9ed4eb907a058157e8602e20257c"
        "460c93cbbd177eec79b2c22241b110aca8bb9b824b9c8b07473524568dafe626"
        "4038c45d1bc5d10f6c7bb0e3a3236f58c1bacfd7a2e7d0635cf873a013dc29cd"
        "c976ae8fe45930aa941c3c0e55927732c6ce1836dfa98cd8a4f03b514a023e53"
    ),
    "type0_t12": bytes.fromhex(
        "1fac4dcdca70026b184062b23f9b5bef6968713bcbd430bc4772745e844c1bdb"
        "6a351df5a1b3875d57282fc4fd242636adbe616373aa82ee29d0df8c15b596f3"
        "dd7e3a37587f0cfc0b07e8f7f414b881b6d71ec885e69d3360c595d55500a3b7"
        "7d500dd2c112e5edd8a49c8f2a4fa801528365ea9a6c444ae2a52b46e13425f8"
        "c3dac76e48387c7806536416983c914239ccb0f1eb13bb0532860ea20a9efa66"
        "548ed3e7192077ecffbd6d432303ab753dcfd1de9231a7454bc297f97a88d91c"
        "e9e410c9222d9076177904511a5a5f2c216f3ee0f0bfd6940f8011a05ca9492e"
        "ceafa69f7b99b9b4e3fbf627f293fe0867ae0989dc4ec6c08ab1598b41568dba"
    ),
    "type1_t03": bytes.fromhex(
        "a917af0d346e53b67f58e9145f55dbd442809959a83a575dd56f4c683546a6e7"
        "7b71e093a21f6421e3b19826abadeee5bbd91e2e9536ef23794504ed131df485"
        "96ecc232aa7c15d8da92909db7566a6641fc00f65024cffb11fe82489b271b67"
        "4e8469976d8cd2ba74f98fa5545ccd7307d10109f1193b5e873076ccc05aa749"
        "22fa1602dfa4ffb37533bd882fcb2a44b8bf1c0f811043b4c87e9a25ea834b38"
        "7ad73d1a4f6251c9470ece3fc74d2ca186b9c5cadd6b706c919cbe0a9ff594bc"
        "182b602029f7f228c4a00b65de8d78123ed077088bae05313cd6a38906dc5272"
        "b0b537d3c38ac6f0c161fd4a5b7d9ef363402de8b2e63903eb8ee10ce4e2f8ac"
    ),
    "type1_t12": bytes.fromhex(
        "eae65ea78eac34033097525376f2620b0afc94b8673611bcaecafa15042b17c4"
        "3e5b590157e2bab7d13ff06a9c2acba9e32cc00f46918ad098c5a61b96291209"
        "63ede0a28677bee565dbbd50b39d1a4e790c0043df3d54338f89a87bf9d52782"
        "bbc28c47886bb4c3f8aa061e837d057885f66e2eec5a31453814168b02e44fb0"
        "bfaba49e4860193508dedd669051cca3af709b7595496c64727e44a073256855"
        "1f407a740e8ddc1c71c8cfd7e8ceeb323aee07614dfe5c7c562f2d5f6f9f8122"
        "584baddab9101823e1f36de7e928d6d8f44c3921b284c12426f19337c64acd20"
        "c9d9c7b1ff99d45db5a1870d69921380d2d3fd1df53ba57fef9ab642fb3cf741"
    ),
    "address_8_15_xor1": bytes.fromhex(
        "00b11ec53d40455ef2f80463368788bfabcc7808dd20d435098e44ae33a99ecd"
        "b3e5ad41dabef416572e5367afdb8ad834173c015573cfe3e8c70de9a3130cf6"
        "904efb976d5fa87111fcd19581ba8c1b39fea215a6524d5b59a5e096d98f7bed"
        "29d31f0eec230fb86c6f7d1846d6e4b59a7902f503c060665c2f76859d541a6a"
        "28ce7f7c91994c833eb41d05c1c3d747debc626e86148077ebf3073156d2c2c6"
        "6bdcfd2292f006512d38e6a025dfd52c1c94129cb09bc40bc8d0f730cb27fa7a"
        "1061aaa470b72a5ac9f10a4965ee694b3a8d325d68b99f75193fac374fe79389"
        "7e4a3bea747243bd24efb6ff6458848ba7bbb2e1262b50ca21f998a1e2428248"
    ),
    "address_8_15_xor2": bytes.fromhex(
        "9b9dc13da9b8f46ff625c747d597df6beb90a4b25df566b0b98b9364ec7b658c"
        "f143426e459fb335067196dba0fb0b3a1ff88e69cd26ab86a20cbd63a57ae76a"
        "5f189ebfad55b11c5c0330c63720e3c952e8ee4f0170c477292aba5312047daf"
        "338fa84daa5bb40f92bbede12f506cd22c95d9f998c3764cf2e4e52bef9c49b6"
        "313bbca1cade6274ea8100dda646883f39d62354244ad8dcd7d1ccbe577cda44"
        "61ced3d4e92880e0568a09059a891bf7f3996d5e4891c0d0c579784159212eff"
        "c24b388332e6e27f1e17581d1afa858294c8727eb7ac0efcfd1627758dcb08fe"
        "0a020d3611228440343e2d685aa767ae8707106014733c5119a3b5cf13f0154e"
    ),
    "address_16_23_xor1": bytes.fromhex(
        "005f0352cee37d8f6bf820de7b7e39bef594187880c97f7a3e63f2e04ef78727"
        "696ca41d855be644250c98c70102a3260938dbc31ecf23456876d6225d5aae16"
        "9fa2b5cd81ea5eb8b99d9c1a0fffe1e774aad4affcc633295cab95f019475967"
        "f396601f6292bd89ee281306fefa326d573c54502c5849fb17ccefb2b4f90770"
        "c5a9dfd53b862b0d6e4d0a904331c1f6880bda5314dc758eb0eb9946a11571c8"
        "e93f4ad973e57c3077d3b34b3772c204970836b13a61ece21c9a8bd11b2e9e8a"
        "d841e4c4402fadc0b6845166bb12e8ddcbbc6fd01183564ccabf0510d7bafded"
        "8c0e4f3d3591b7ac34642af1796a9b2d65f442a08da74855219324d2a6a5a882"
    ),
    "address_16_23_xor2": bytes.fromhex(
        "29971a2c0b943e75010d1be14d38398fe7d06090b20fbb701fe65b87b443fdf5"
        "f6f9adc098179f91155155646c18610ed993abd6242f6a3a22b14faa2348edb9"
        "888ba36b264ce82d1c99bd5c580850f22a62c172660410376efc44a9dfd420dd"
        "ee41db73de54ecc9f34b2eae5a4a5e47072b76a4e328feb0f00206d1af42c2a5"
        "e067bf168e35ce8ae53d7b96d779521ea1fb9bbe219ce956147fa0e4c3c446ea"
        "f7d21d310a5feba2688db5c5740cdc8280091995719a1157774ec6ff1203a7c7"
        "f4c8b67a59363c53e2698c25054563f83489333f8527bc65faa86d845dba4032"
        "30ef8313a678cc819edacad37e9d6fcdb7b3d8cf3b0092b886ac497cf1d5cb7d"
    ),
    "address_0_7_xor": bytes.fromhex(
        "74ad5d1d9ec3fa4ef7dbcaa26436560c4fcf43661e91e3a558c2c1d4b9dd7616"
        "ce6175012b22385550ef6c9905e9e8e02da44b4a42aeba8c6f9314bd7121b002"
        "15c4e660d744fd857e788f0081f1a73ba010f49f39883562cb19311151fb2a20"
        "45d37d921bf2090d97a9b53cee5caf7bd23a498eb6cdd9de8a296ed80be16987"
        "1a9618ccdfe7c5c7f852c9f0b7e533da679da3030e722679e2b8fcaafeb486c8"
        "d1bc120877eb408d04254d5a6a7a2e41651c1394b26328595e9a3007c6bf17f5"
        "0f89f31fea6db3c07047f953f6d654ed6b4ce48b832490b17cbb73abd52f5fec"
        "9c2ca834463727a10a068068823284ff48ac7f3f95dc989bbe23573e5bd03da6"
    ),
}


def _cmc_keys(t0hi: bytes, t0lo: bytes, t1: bytes, a07: bytes) -> tuple[bytes, bytes]:
    """MAME's cmc_prot_device::decrypt xor values for one byte pair, for
    every value of the low 16 bits of the word index (all they depend on)."""
    x0, x1 = bytearray(0x10000), bytearray(0x10000)
    for m in range(256):
        e, hi, lo = a07[m], t0hi[m] & 0xFE, t0lo[m] & 0x01
        for l in range(256):
            tmp = t1[l ^ e]
            x0[m << 8 | l] = hi | (tmp & 0x01)
            x1[m << 8 | l] = (tmp & 0xFE) | lo
    return bytes(x0), bytes(x1)


def cmc42_sprites(region: bytes) -> bytes:
    """cmc_prot_device::gfx_decrypt with the CMC42 tables and KOF '99's key
    (extra_xor 0), for a 64 MiB sprite region."""
    if len(region) != 0x4000000:
        raise ValueError(f"CMC42 sprite region is {len(region)} bytes, expected 64 MiB")
    t = _CMC42
    a07 = t["address_0_7_xor"]
    n = len(region) >> 2                    # 32-bit words, index rpos
    # Data xor.  Bytes 0 and 3, and 1 and 2, of each word are decrypted as
    # pairs; a pair is swapped first, for 0/3 on bit 8 of rpos, for 1/2 on
    # bit 16 xor a table of bits 8-15: constant over each 256-word block.
    planes = [memoryview(region[k::4]) for k in range(4)]
    blocks = n >> 8
    swap03 = [b & 1 for b in range(blocks)]
    swap12 = [((b >> 8) ^ t["address_16_23_xor2"][b & 0xFF]) & 1 for b in range(blocks)]

    def take(keep: int, other: int, swap: list[int]) -> bytes:
        return b"".join(planes[other if s else keep][b << 8:(b + 1) << 8] for b, s in enumerate(swap))

    k0, k3 = _cmc_keys(t["type0_t03"], t["type0_t12"], t["type1_t03"], a07)
    k1, k2 = _cmc_keys(t["type0_t12"], t["type0_t03"], t["type1_t12"], a07)
    reps = n >> 16
    buf = bytearray(len(region))
    buf[0::4] = _xor(take(0, 3, swap03), k0 * reps)
    buf[3::4] = _xor(take(3, 0, swap03), k3 * reps)
    buf[1::4] = _xor(take(1, 2, swap12), k1 * reps)
    buf[2::4] = _xor(take(2, 1, swap12), k2 * reps)
    del planes
    # Address xor: rom[rpos] = buf[baser], where baser is rpos after five
    # steps, each xoring one byte of it (h = bits 16-23, m = 8-15, l = 0-7)
    # with a table of another:
    #   1 m ^= A[h]   2 m ^= B[l]   3 h ^= C[l]   4 h ^= D[m]   5 l ^= E[m]
    # So rom = buf gathered through step 5, then 4, 3, 2 and 1, each pass
    # T[y] = previous[step(y)].  Steps 1 and 4 move whole 256-word rows
    # (h, m); steps 2, 3 and 5 move words, 256 at a time with a stride.
    A, B = t["address_8_15_xor1"], t["address_8_15_xor2"]
    C, D, E = t["address_16_23_xor1"], t["address_16_23_xor2"], a07
    x = array.array(_W32, buf)
    del buf
    y = array.array(_W32, bytes(len(x) * 4))
    for m in range(256):                                # 5: l ^= E[m]
        e = E[m]
        for l in range(256):
            y[m << 8 | l::0x10000] = x[m << 8 | (l ^ e)::0x10000]
    xb, yb = memoryview(x).cast("B"), memoryview(y).cast("B")
    for h in range(256):                                # 4: h ^= D[m]
        for m in range(256):
            s = ((h ^ D[m]) << 16 | m << 8) << 2
            d = (h << 16 | m << 8) << 2
            xb[d:d + 0x400] = yb[s:s + 0x400]
    for h in range(256):                                # 3: h ^= C[l]
        for l in range(256):
            s = h ^ C[l]
            y[h << 16 | l:(h + 1) << 16:0x100] = x[s << 16 | l:(s + 1) << 16:0x100]
    for m in range(256):                                # 2: m ^= B[l]
        for l in range(256):
            x[m << 8 | l::0x10000] = y[(m ^ B[l]) << 8 | l::0x10000]
    for h in range(256):                                # 1: m ^= A[h]
        a = A[h]
        for m in range(256):
            s = (h << 16 | (m ^ a) << 8) << 2
            d = (h << 16 | m << 8) << 2
            yb[d:d + 0x400] = xb[s:s + 0x400]
    del xb
    out = bytes(yb)
    del yb
    return out


def sfix_from_sprites(spr: bytes, size: int) -> bytes:
    """cmc_prot_device::sfix_decrypt: the fix layer is the sprite region's
    last `size` bytes, reordered within each 32-byte tile group."""
    src = spr[len(spr) - size:]
    out = bytearray(size)
    for k in range(32):
        s = (k & 7) << 2 | ((~k & 8) >> 2) | ((k & 0x10) >> 4)
        out[k::32] = src[s::32]
    return bytes(out)
