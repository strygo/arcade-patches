"""The core config word: which cartridge chips and timings a title needs.

A title's `cart` block in title.json holds the resolved attributes (the
same attributes the MiSTer Neo Geo romset list records per game); this
module turns them into the 32-bit word the image header carries.

Bit map:
  [17] ms5p_bank  [18] xram  [19] ADPCM-A over 16 MiB  [22:20] protection
  chip (2 = PVC, 2+sma = SMA type)  [23] use_pcm  [25:24] cartridge chip
  (1 PRO-CT0, 2 Link MCU)  [27:26] cmc  [28] rom_wait  [30:29] p_wait
"""
from __future__ import annotations

from dataclasses import dataclass, fields


@dataclass
class CartConfig:
    hw_type: int = 0
    cmc: int = 0
    pvc: int = 0
    sma: int = 0
    xram: int = 0
    ms5p: int = 0
    rom_wait: int = 0
    p_wait: int = 0
    vrom_mirror: int = 1
    vromb_offset: int = 0
    pcm: int | None = None      # explicit use_pcm override

    @classmethod
    def from_dict(cls, d: dict) -> "CartConfig":
        names = {f.name for f in fields(cls)}
        return cls(**{k: v for k, v in d.items() if k in names})

    def cfg_word(self, has_v2: bool, v1_size: int = 0) -> int:
        # use_pcm is 1 unless the set has a separate ADPCM-B region (or a
        # V1/V2 split point); a V1 over 16 MiB with no V2 is the double
        # ADPCM-A space (use_pcm = 2).  An explicit pcm attribute wins.
        if self.pcm is not None:
            use_pcm = self.pcm
        elif has_v2 or self.vromb_offset:
            use_pcm = 0
        elif v1_size > 16 * 1024 * 1024:
            use_pcm = 2
        else:
            use_pcm = 1
        cfg = 0
        cfg |= (self.ms5p & 1) << 17
        cfg |= (self.xram & 1) << 18
        cfg |= (1 if use_pcm == 2 else 0) << 19
        if self.pvc:
            cfg |= 2 << 20
        elif self.sma:
            cfg |= ((2 + self.sma) & 7) << 20
        cfg |= (1 if use_pcm else 0) << 23
        cfg |= (self.hw_type & 3) << 24
        cfg |= (self.cmc & 3) << 26
        cfg |= (self.rom_wait & 1) << 28
        cfg |= (self.p_wait & 3) << 29
        return cfg
