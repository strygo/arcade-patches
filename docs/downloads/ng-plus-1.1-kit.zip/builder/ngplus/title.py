"""A title's published data (titles/<set>/).

  title.json    names, the disc's audio track checksums, cartridge config,
                the sound driver's protocol, trigger gain, sample mutes
  triggers.tsv  music command -> disc track, and how the CD plays it
                (loop / once / stop)
  loops.tsv     loop start and end sample for every looping track, and
                whether the player crossfades the wrap (optional column
                crossfade, default 1; 0 is a hard cut, for loops whose
                repeat is an exact copy of the recording), and for a
                crossfaded loop over a copy or near copy the samples between
                how the player's crossfade tail is prepared (optional column
                tail: "align:<samples>" for a copy or near copy, "match" for
                a splice; see pack)
  romset.json   the ROM set definition (see romset)
"""
from __future__ import annotations

import csv
import json
from dataclasses import dataclass, field
from pathlib import Path

from . import romset


@dataclass
class Trigger:
    cmd: int
    mode: str        # loop | once | stop
    track: int       # disc track number; 0 = no CD track


@dataclass
class Title:
    set: str
    name: str
    pack_title: str
    disc_name: str
    disc_tracks: dict[int, dict]
    cart: dict
    driver: dict
    trigger_gain: int
    crossfade_seconds: float
    sound_mutes: list[dict]
    triggers: list[Trigger] = field(default_factory=list)
    loops: dict[int, tuple[int, int]] = field(default_factory=dict)
    crossfade: dict[int, bool] = field(default_factory=dict)
    tail: dict[int, str] = field(default_factory=dict)
    dir: Path = Path(".")

    def used_tracks(self) -> list[int]:
        return sorted({t.track for t in self.triggers if t.mode != "stop" and t.track})

    def romset(self) -> romset.SetInfo:
        return romset.load(self.dir)


def load(title_dir: Path) -> Title:
    d = Path(title_dir)
    j = json.loads((d / "title.json").read_text(encoding="utf-8"))
    t = Title(set=j["set"], name=j["title"], pack_title=j["pack_title"],
              disc_name=j["disc"]["name"],
              disc_tracks={int(k): v for k, v in j["disc"]["tracks"].items()},
              cart=j["cart"], driver=j["driver"], trigger_gain=int(j["trigger_gain"]),
              crossfade_seconds=float(j["crossfade_seconds"]), sound_mutes=j.get("sound_mutes", []),
              dir=d)
    for r in csv.DictReader(open(d / "triggers.tsv", newline="", encoding="utf-8"), delimiter="\t"):
        t.triggers.append(Trigger(int(r["cmd"], 16), r["mode"], int(r["track"])))
    for r in csv.DictReader(open(d / "loops.tsv", newline="", encoding="utf-8"), delimiter="\t"):
        t.loops[int(r["track"])] = (int(r["loop_start"]), int(r["loop_end"]))
        t.crossfade[int(r["track"])] = r.get("crossfade", "1") != "0"
        if (r.get("tail") or "").strip():
            t.tail[int(r["track"])] = r["tail"].strip()
    missing = [x.track for x in t.triggers if x.mode == "loop" and x.track and x.track not in t.loops]
    if missing:
        raise ValueError(f"{d.name}: looping tracks without loop points: {missing}")
    return t


def available(titles_dir: Path) -> list[Title]:
    return [load(p) for p in sorted(Path(titles_dir).iterdir()) if (p / "title.json").exists()]
