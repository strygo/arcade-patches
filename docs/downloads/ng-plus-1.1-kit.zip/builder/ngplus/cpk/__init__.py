"""The CPS+ pack (.cpk) format, its ADX encoder and the reader that
takes a pasted path out of a config file, shared unchanged with CPS+: NG+
packs use the same file format and the same FPGA player, and both kits ask
their users for paths the same way.  The format specification is
docs/PACK_FORMAT.md."""
