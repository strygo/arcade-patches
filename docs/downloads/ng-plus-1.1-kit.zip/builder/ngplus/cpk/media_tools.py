"""Shared executable resolver for the standalone image builder."""
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[2]/'tools'))
from ffmpeg_runtime import Executable, add_arguments, configure, resolve


def ffmpeg_exe():
    return resolve('ffmpeg')


def ffprobe_exe():
    return resolve('ffprobe')


def disc_tool(name, *, fetch=True):
    from fetch_optional_tools import disc_tool as find
    return find(name, fetch=fetch)
