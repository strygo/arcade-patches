"""Audio tracks from a Neo Geo CD rip, verified.

Accepts a cue sheet with its image files beside it, a .zip holding one cue
sheet and its images (read in place, nothing is extracted to disk), or MAME's
CHD, which chdman (it comes with MAME) turns back into a cue sheet and one
image in a folder of the builder's own, removed when the disc is closed.
Both the one-file-per-track layout and a single image are supported.

A track's audio is taken from its INDEX 01, which is where the Neo Geo CD
starts playback: a pregap stored ahead of it (the first audio track after
the data track usually carries 3 s of silence there) is not part of the
music.  Each track's audio is checked against the CRC32 and length the
title lists, so a pack is only built from the exact published audio.
"""
from __future__ import annotations

import io
import os
import shutil
import subprocess
import tempfile
import zipfile
import zlib
from dataclasses import dataclass
from pathlib import Path, PureWindowsPath

SECTOR = 2352
FPS = 75
CUE_ENCODINGS = ("utf-8-sig", "cp932", "cp1252")
# chdman: $NGPLUS_CHDMAN, else PATH.  Needed only for a .chd.
CHDMAN = os.environ.get("NGPLUS_CHDMAN") or shutil.which("chdman")


def msf_to_sector(msf: str) -> int:
    m, s, f = (int(x) for x in msf.split(":"))
    return (m * 60 + s) * FPS + f


@dataclass
class Track:
    number: int
    mode: str
    file: str
    index0: int | None
    index1: int


class Disc:
    """A cue sheet and the image files it names, on disk or inside a zip, or a
    CHD.  Close it when done (or use it in a with statement): a CHD's
    converted image is removed then."""

    def __init__(self, path: Path, work: Path | None = None):
        self.path = Path(path)           # what the user gave, for messages
        self._cue = self.path            # the cue sheet actually read
        self._zip = None
        self._tmp: Path | None = None
        if self.path.suffix.lower() == ".chd":
            self._cue = self._from_chd(work)
        if self.path.suffix.lower() == ".zip":
            self._zip = zipfile.ZipFile(self.path)
            cues = [n for n in self._zip.namelist() if n.lower().endswith(".cue")]
            if len(cues) != 1:
                raise ValueError(f"{self.path.name}: expected one cue sheet in the zip, found {len(cues)}")
            self._base = str(PureWindowsPath(cues[0]).parent).replace("\\", "/").strip(".")
            raw = self._zip.read(cues[0])
        elif self._cue.suffix.lower() == ".cue":
            raw = self._cue.read_bytes()
        else:
            raise ValueError(f"{self.path.name}: pass the disc's .cue sheet, a .zip holding it, or a .chd")
        self.tracks = self._parse(raw)

    def _from_chd(self, work: Path | None) -> Path:
        """chdman extractcd: the CHD back to a cue sheet and one image.  The
        track checksums still decide: a CHD made from another rip, or
        converted differently, fails them like any other wrong disc."""
        if not CHDMAN:
            raise ValueError(f"{self.path.name}: a .chd needs chdman, which comes with MAME -- "
                             f"put it on PATH or set NGPLUS_CHDMAN to it")
        if work:
            work.mkdir(parents=True, exist_ok=True)
        self._tmp = Path(tempfile.mkdtemp(prefix="chd_", dir=work))
        cue = self._tmp / "disc.cue"
        try:
            r = subprocess.run([CHDMAN, "extractcd", "-i", str(self.path), "-o", str(cue),
                                "-ob", str(self._tmp / "disc.bin"), "-f"],
                               stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        except OSError as e:
            self.close()
            raise ValueError(f"{self.path.name}: could not run chdman ({CHDMAN}): {e.strerror}") from e
        if r.returncode or not cue.exists():
            err = [l for l in r.stderr.decode(errors="replace").strip().splitlines()
                   if l.strip() and not l.startswith(("chdman -", "Fatal error occurred"))]
            self.close()
            why = err[-1].split("): ")[-1] if err else f"exit {r.returncode}"   # "Error opening CHD file (...): Invalid file"
            raise ValueError(f"{self.path.name}: chdman could not extract it: {why}")
        return cue

    def close(self) -> None:
        if self._zip:
            self._zip.close()
            self._zip = None
        if self._tmp:
            shutil.rmtree(self._tmp, ignore_errors=True)
            self._tmp = None

    def __enter__(self) -> "Disc":
        return self

    def __exit__(self, *exc) -> None:
        self.close()

    # -- image files -------------------------------------------------------
    def _names(self) -> dict[str, str]:
        if self._zip:
            return {PureWindowsPath(n).name.lower(): n for n in self._zip.namelist() if not n.endswith("/")}
        return {p.name.lower(): str(p) for p in self._cue.parent.iterdir() if p.is_file()}

    def _exists(self, name: str) -> bool:
        return PureWindowsPath(name).name.lower() in self._names()

    def _size(self, name: str) -> int:
        key = self._names()[PureWindowsPath(name).name.lower()]
        return self._zip.getinfo(key).file_size if self._zip else Path(key).stat().st_size

    def _read(self, name: str, start: int, length: int | None) -> bytes:
        key = self._names()[PureWindowsPath(name).name.lower()]
        f = self._zip.open(key) if self._zip else open(key, "rb")
        with f:
            f.seek(start)
            return f.read() if length is None else f.read(length)

    # -- cue sheet ---------------------------------------------------------
    @staticmethod
    def _file_name(line: str) -> str:
        rest = line.strip()[4:].strip()
        if rest.startswith('"'):
            end = rest.find('"', 1)
            if end > 0:
                return rest[1:end]
        parts = rest.rsplit(None, 1)
        return parts[0].strip('"') if len(parts) == 2 else rest.strip('"')

    def _parse(self, raw: bytes) -> list[Track]:
        readings = []
        for enc in CUE_ENCODINGS:
            try:
                readings.append(raw.decode(enc).splitlines())
            except UnicodeDecodeError:
                continue
        lines = readings[0] if readings else raw.decode("latin-1").splitlines()
        for cand in readings:              # the reading whose image files exist
            names = [self._file_name(t) for t in cand if t.strip().upper().startswith("FILE")]
            if names and all(self._exists(n) for n in names):
                lines = cand
                break
        tracks: list[Track] = []
        cur_file, cur = None, None
        for line in lines:
            t = line.strip()
            word = t.split(None, 1)[0].upper() if t else ""
            if word == "FILE":
                cur_file = self._file_name(t)
            elif word == "TRACK":
                if cur:
                    tracks.append(cur)
                parts = t.split()
                cur = Track(int(parts[1]), parts[2], cur_file, None, -1)
            elif word == "INDEX" and cur is not None:
                parts = t.split()
                if int(parts[1]) == 0:
                    cur.index0 = msf_to_sector(parts[2])
                elif int(parts[1]) == 1:
                    cur.index1 = msf_to_sector(parts[2])
        if cur:
            tracks.append(cur)
        for tr in tracks:
            if tr.file is None or not self._exists(tr.file):
                raise FileNotFoundError(f"{self.path.name}: track {tr.number} image file is missing ({tr.file})")
            if tr.index1 < 0:
                raise ValueError(f"{self.path.name}: track {tr.number} has no INDEX 01")
        return tracks

    # -- audio -------------------------------------------------------------
    def audio(self, number: int) -> bytes:
        """s16le stereo 44.1 kHz PCM of one audio track, from its INDEX 01."""
        by_n = {t.number: t for t in self.tracks}
        if number not in by_n:
            raise ValueError(f"{self.path.name}: no track {number}")
        tr = by_n[number]
        if not tr.mode.upper().startswith("AUDIO"):
            raise ValueError(f"{self.path.name}: track {number} is {tr.mode}, not audio")
        later = [t for t in self.tracks if t.number > number and t.file == tr.file]
        start = tr.index1 * SECTOR
        if later:
            nxt = later[0]
            end = (nxt.index0 if nxt.index0 is not None else nxt.index1) * SECTOR
            return self._read(tr.file, start, end - start)
        return self._read(tr.file, start, None)


def crc32(data: bytes) -> str:
    return f"{zlib.crc32(data) & 0xFFFFFFFF:08x}"


def verified_audio(disc: Disc, number: int, expect: dict) -> bytes:
    """Track audio, checked against {"frames": n, "crc32": "..."}."""
    pcm = disc.audio(number)
    frames = len(pcm) // 4
    got = crc32(pcm)
    if frames != expect["frames"] or got != expect["crc32"]:
        raise ValueError(f"track {number}: {frames} frames CRC {got}, expected "
                         f"{expect['frames']} frames CRC {expect['crc32']} (a different pressing or a damaged rip)")
    return pcm
