"""ROM set definitions: what a title's ROM data must be.

Each title ships `titles/<set>/romset.json`, the MAME set definition reduced
to what the builder checks: every ROM's name, size, CRC32 and load offset,
grouped by board region.  Every input layout (MAME zip, Darksoft folder or
zip, .neo) is split back into these ROMs and CRC-checked, so an image is never
built from bytes that could not be verified.

Regions:
  p    68000 program, ROMs in offset order
  s    fix layer
  m1   Z80 sound program
  v1   ADPCM-A sample ROMs in offset order
  v2   ADPCM-B sample ROMs in offset order (empty: shared ADPCM space)
  c    sprite ROMs, (even, odd) pairs by offset parity; a ROM loaded in
       two halves carries `cont`, the address of its second half
BIOS: `bios` (system ROMs by name), `sfix` (fix layer), `lo` (zoom table).

An encrypted set (KOF '98, '99) also carries `decrypt`: the scheme the
builder decrypts it with (the decrypt module) and the size and CRC32 of each
region that decryption produces, measured from MAME's own decrypted regions.
Its ROMs are checked as stored, the decrypted regions against those digests.
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field, asdict
from pathlib import Path


@dataclass
class Rom:
    name: str
    size: int
    crc: str
    offset: int
    # A sprite ROM loaded in two halves (MAME ROM_CONTINUE on a few early
    # boards): the cartridge address of its second half; 0 = loaded whole.
    cont: int = 0


def _rom_dict(r: Rom | None) -> dict | None:
    if r is None:
        return None
    d = asdict(r)
    if not d["cont"]:
        del d["cont"]            # keep every other set's romset.json as it was
    return d


@dataclass
class SetInfo:
    name: str
    description: str
    cloneof: str | None
    romof: str | None
    p: list[Rom] = field(default_factory=list)
    s: list[Rom] = field(default_factory=list)
    m1: list[Rom] = field(default_factory=list)
    v1: list[Rom] = field(default_factory=list)
    v2: list[Rom] = field(default_factory=list)
    c: list[Rom] = field(default_factory=list)
    bios: dict = field(default_factory=dict)
    sfix: Rom | None = None
    lo: Rom | None = None
    # {"scheme": "kof99", "p": {"size", "crc"}, ...}: see the module docstring
    decrypt: dict | None = None

    def c_pairs(self) -> list[tuple[Rom, Rom]]:
        even = sorted((r for r in self.c if r.offset % 2 == 0), key=lambda r: r.offset)
        odd = sorted((r for r in self.c if r.offset % 2 == 1), key=lambda r: r.offset)
        if len(even) != len(odd):
            raise ValueError(f"{self.name}: unpaired sprite ROMs")
        return list(zip(even, odd))

    def to_json(self) -> str:
        d = {"name": self.name, "description": self.description, "cloneof": self.cloneof, "romof": self.romof}
        for k in ("p", "s", "m1", "v1", "v2", "c"):
            d[k] = [_rom_dict(r) for r in getattr(self, k)]
        d["bios"] = {k: _rom_dict(v) for k, v in self.bios.items()}
        d["sfix"], d["lo"] = _rom_dict(self.sfix), _rom_dict(self.lo)
        if self.decrypt:
            d["decrypt"] = self.decrypt   # only encrypted sets: every other romset.json stays as it was
        return json.dumps(d, indent=1)

    @classmethod
    def from_json(cls, text: str) -> "SetInfo":
        d = json.loads(text)
        for k in ("p", "s", "m1", "v1", "v2", "c"):
            d[k] = [Rom(**r) for r in d[k]]
        d["bios"] = {k: Rom(**v) for k, v in d["bios"].items()}
        d["sfix"] = Rom(**d["sfix"]) if d["sfix"] else None
        d["lo"] = Rom(**d["lo"]) if d["lo"] else None
        return cls(**d)


def load(title_dir: Path) -> SetInfo:
    return SetInfo.from_json((Path(title_dir) / "romset.json").read_text(encoding="utf-8"))
