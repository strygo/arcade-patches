"""Build a title's arranged-audio pack (.cpk) from its disc tracks.

The pack maps the game's own music commands to the CD's tracks:
  * a command the CD plays looping becomes a looping track with the title's
    loop points (loops.tsv) and the player's crossfade at the wrap, unless
    the title marks the loop as a hard cut.  Loop points sit on 32-sample
    ADX frames, so a loop is up to 16 samples off the song's repeat; where
    the repeat is an exact copy, a crossfade would mix the music with itself
    that many samples late for a second (a comb filter), while a hard cut
    plays the disc's own audio.  A crossfaded loop over a near copy (the
    passes differ slightly, so a hard cut would jump between them) marks
    tail_align: the stored tail, which the player only ever blends, is taken
    that many samples later so it lines up with the loop head, and scaled so
    the player's equal-power blend of the two copies sums to a constant-gain
    one; a crossfaded splice (no repeat at all) marks `match`, and the tail's
    envelope is matched to the head's, so a quiet moment in the outgoing
    music cannot pull the wrap's level down (see shape_tail);
  * a command the CD plays once becomes a one-shot track;
  * the CD's pause command becomes the STOP control verb, the driver's
    fade-out ($0A + speed) the FADE_OUT verb under the title's fade law, and
    fade-stop ($11) RESTORE;
  * every mapped command is suppressed on the sound board, so the arranged
    track replaces the board's music while sound effects keep playing.

Audio is encoded to ADX with FFmpeg's encoder.  The encoder is integer-only,
so the same input gives the same bytes on any machine; the result is checked
against the published hash.
"""
from __future__ import annotations

import math
from array import array
from math import isqrt, sqrt
from pathlib import Path
from typing import Callable

from .cpk import format as cpk
from .title import Title

VERBS = {"stop": cpk.VERB_STOP, "fade_out": cpk.VERB_FADE_OUT, "restore": cpk.VERB_RESTORE}
FADE_LAWS = {"NG_MAKOTO": cpk.FADE_NG_MAKOTO}
RATE = 44100


def protocol(t: Title) -> cpk.Protocol:
    d = t.driver
    return cpk.Protocol(
        game_id=t.set, latch_page=0x320000,
        off_cmd_hi=0, off_cmd_lo=0, off_arg_hi=0, off_arg_lo=0, off_arg_byte=0,
        off_handshake=0, handshake_pending=0, handshake_ready=0,
        fade_law=FADE_LAWS[d["fade_law"]], fade_const1=int(d["fade_const1"]),
        fade_const2=int(d["fade_const2"]),
        control_default_verb=cpk.VERB_NONE, control_region_start=0x0000,
        control_verbs={int(c, 16): VERBS[v] for c, v in d["control_verbs"].items()},
        dialect=cpk.DIALECT_NEOGEO_BYTE, arg_commands={int(x, 16) for x in d["arg_commands"]})


def blend_lut(n: int) -> list[int]:
    """The player's Q15 equal-power weights: w_out(k) = lut[k], w_in(k) =
    lut[n-1-k] (identical to the core's table; every entry sits at least
    1e-5 from a rounding boundary, so the values are the same on any libm)."""
    return [round(math.cos((k + 0.5) / n * (math.pi / 2)) * 32768) for k in range(n)]


def shape_tail(pcm: bytes, le: int, n: int, ls: int = 0, offset: int | None = None) -> bytes:
    """Rewrite the n-sample tail after loop_end, which the player only ever
    blends into the loop head, so the wrap keeps the music's own level.

    The player mixes w_out * tail + w_in * head with equal-power weights
    (w_out^2 + w_in^2 = 1).  That holds the level only when the two sides are
    unrelated and equally loud; a loop's two sides are usually neither.  Two
    identical copies sum to +3 dB, copies a few samples apart comb-filter,
    and a quiet outgoing side
    -- a splice ending in the track's closing fade -- drops the wrap by 3 to
    14 dB.

    So the stored tail is prepared, per 100 ms and interpolated per sample,
    from what the two sides actually are:
      * `offset` shifts it to line up with the head (a copy or near copy),
        which removes the comb filtering;
      * it is scaled to the head's level, so neither side can pull the wrap
        down;
      * and scaled again by the correlation-aware factor that makes the
        player's fixed weights come out at constant level:
            g = (-r * w_in + sqrt(r^2 * w_in^2 + 1 - w_in^2)) / w_out
        r = 1 (the same audio) gives (1 - w_in) / w_out, a constant-gain
        crossfade; r = 0 (unrelated) gives 1, the player's own blend; in
        between it lands where the two partly cancel or reinforce.

    Integer arithmetic, so every machine writes the same bytes."""
    src, s = array("h", pcm), array("h", pcm)     # read from the untouched copy
    o = offset or 0
    gains = tail_gains(src, ls, le + o, n)
    for k in range(n):
        g = gains[k]
        for ch in (0, 1):
            v = (src[2 * (le + o + k) + ch] * g + (1 << 14)) >> 15
            s[2 * (le + k) + ch] = -32768 if v < -32768 else 32767 if v > 32767 else v
    return s.tobytes()


ENV_STEPS = 40                 # 25 ms windows over a 1 s crossfade
GAIN_LIMIT = 92682             # Q15, +9 dB; its reciprocal is the floor
G_STEP = 256                   # samples between gain points (interpolated)


def tail_gains(src: array, ls: int, le: int, n: int) -> list[int]:
    """Per-sample Q15 gain for the stored tail.

    Per 25 ms window the two sides give their power (Pt, Ph) and correlation
    r.  The wrap should move smoothly from the outgoing music's level to the
    incoming one's, so the target power is interpolated between them by the
    player's own fade shape, and the gain is the positive root of

        g^2 * w_out^2 * Pt + 2 * r * g * w_out * w_in * sqrt(Pt * Ph)
            + w_in^2 * Ph = Ptarget

    which for two copies of the same audio (Pt = Ph, r = 1) is the
    constant-gain crossfade, and for unrelated audio at one level is 1, the
    player's own blend.  Bounded to +-9 dB and interpolated per sample.  All
    integer, so every machine writes the same bytes."""
    win = n // ENV_STEPS
    lut = blend_lut(n)
    pt_w, ph_w, cor_w = [], [], []
    for i in range(ENV_STEPS):
        a, b = le + i * win, ls + i * win
        pt = ph = ch = 0
        for k in range(win):
            for c in (0, 1):
                x, y = src[2 * (a + k) + c], src[2 * (b + k) + c]
                pt += x * x
                ph += y * y
                ch += x * y
        pt_w.append(max(pt // win, 1))
        ph_w.append(max(ph // win, 1))
        d = isqrt(pt * ph)
        cor_w.append(max(-32768, min(32768, (ch << 15) // d if d else 0)))

    def point(k: int) -> int:
        """The positive root of g^2*a + 2*g*b + c = 0.  Only *, /, and sqrt
        on doubles, all exactly specified by IEEE 754, so the result is the
        same on any machine; the weight table is the only cos, and its
        entries sit 1e-5 clear of a rounding boundary."""
        k = min(k, n - 1)
        i = min(k // win, ENV_STEPS - 1)
        wi, wo = lut[n - 1 - k] / 32768, lut[k] / 32768
        pt, ph, r = float(pt_w[i]), float(ph_w[i]), cor_w[i] / 32768
        u = wi * wi                                   # the player's own fade shape
        target = pt * (1 - u) + ph * u                # level ramps tail -> head
        a = wo * wo * pt
        if a <= 0:
            return GAIN_LIMIT
        b = r * wo * wi * sqrt(pt * ph)
        c = wi * wi * ph - target
        g = (-b + sqrt(max(b * b - a * c, 0.0))) / a
        return max((32768 * 32768) // GAIN_LIMIT, min(int(g * 32768 + 0.5), GAIN_LIMIT))

    pts = {k: point(k) for k in range(0, n + G_STEP, G_STEP)}
    out = []
    last = max(pts)
    for k in range(n):
        a = k // G_STEP * G_STEP
        f = k - a
        out.append(pts[a] + (pts[min(a + G_STEP, last)] - pts[a]) * f // G_STEP)
    return out


def build(t: Title, audio: Callable[[int], bytes], out: Path,
          log: Callable[[str], None] = print) -> Path:
    """audio(track_number) -> s16le stereo PCM of that disc track."""
    from .cpk import adxcodec, adxencode       # needs ffmpeg: imported only to build

    xfade_samples = int(t.crossfade_seconds * RATE) // 32 * 32
    w = cpk.PackWriter(protocol(t), title=t.pack_title, trigger_rows=256,
                       default_rate=RATE, xfade_samples=xfade_samples)
    index: dict[int, int] = {}
    for row in sorted(t.triggers, key=lambda r: r.cmd):
        if row.mode == "stop" or row.track == 0:
            continue                       # stop is a control verb; track 0 = no CD track
        if row.track not in index:
            pcm = audio(row.track)
            n = len(pcm) // 4
            loop = row.mode == "loop"
            ls = le = xf = 0
            if loop:
                lp = t.loops.get(row.track)
                if lp is None:
                    raise ValueError(f"{t.set}: track {row.track} loops on the CD but has no loop points")
                ls, le = lp
                xf = 1 if (xfade_samples and n - le >= xfade_samples and t.crossfade.get(row.track, True)) else 0
                mode = t.tail.get(row.track)
                if xf and mode is not None:
                    a_ls, a_le = ls - ls % 32, le - le % 32
                    off = None if mode == "match" else int(mode.split(":")[1])
                    if off is not None and not (0 <= a_le + off and a_le + off + xfade_samples <= n):
                        raise ValueError(f"{t.set}: track {row.track} tail {mode} reaches outside the track")
                    pcm = shape_tail(pcm, a_le, xfade_samples, a_ls, off)
            stream, c1, c2, _snr = adxencode.encode_adx_track(pcm, RATE, 2, n, f"track{row.track:02d}",
                                                              measure=False)
            meta = cpk.TrackMeta(sample_rate=RATE, channels=2, codec=cpk.CODEC_ADX, coef1=c1, coef2=c2,
                                 name=f"track{row.track:02d}")
            if loop:
                ls -= ls % 32
                le -= le % 32
                if le > n:
                    le = (n // 32) * 32 - 32
                meta.loop_start_sample, meta.loop_end_sample = ls, le
                meta.loop_start_byte = adxcodec.samples_to_stream_byte(ls, 2)
                meta.loop_end_byte = adxcodec.samples_to_stream_byte(le, 2)
                meta.xfade_enable = xf
                keep = le + xfade_samples if xf else le
                stream = stream[:adxcodec.samples_to_stream_byte(keep, 2)]
            index[row.track] = w.add_track(stream, meta)
            log(f"    track {row.track:2d}  {n / RATE:6.1f} s  {'loop' if loop else 'once'}")
        w.set_trigger(row.cmd, cpk.TriggerRow(verb=cpk.VERB_PLAY, track=index[row.track],
                                              gain=t.trigger_gain, suppress=1))
    return w.write(out, sidecar=False)
