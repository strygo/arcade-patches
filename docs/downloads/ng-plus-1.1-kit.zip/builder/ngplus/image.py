"""NG+ game image (.nga) format, version 2.

One file per title.  The core's file entry carries a DDR load address, so
the MiSTer firmware writes the whole file straight into DDR at 0x30000000.
When the load ends, the core's loader reads the header from DDR and:

  * copies the SDRAM-bound regions (system ROM, SFIX, P, S1, C) from DDR to
    SDRAM with the core's own copy engine, one record per region (index,
    length, copy flag: the records the MiSTer Neo Geo loader sends);
  * copies the LO ROM (64 KiB, raw bytes) into its BRAM;
  * leaves M1, V1/V2 and the pack where they are and takes their DDR
    offsets from the table (V1 and M1 offsets are used at 64 KiB
    granularity, so every region starts 64 KiB aligned).

Every region holds exactly the bytes the MiSTer Neo Geo loader would have
staged for that index, its conversions already applied: fix-converted
S/SFIX, consolidated + spr_convert_dbl C, P in logical order as LE words
padded to a 1 MiB multiple (the loader rounds the P record), V padded
to 16 MiB when the cart does not mirror (0x08 fill), LO raw.

    header  4096 bytes (little-endian)
      0x000  magic "NGA2"
      0x004  u16 version (2), u16 header size (4096)
      0x008  u32 CRC32 of the header with this field zeroed
      0x00c  u32 core config word  (cartridge chips and timing, see cartconfig)
      0x010  u32 NGH id            (P ROM header word at 0x108)
      0x014  u32 region count      (<= 16)
      0x018  char[16] set name     (MAME set name, NUL padded)
      0x028  char[64] title
      0x068  u32 pack file offset, 0x06c u32 pack length   (0 = no pack)
      0x070  u32 body CRC32        (all bytes after the header)
      0x080  region table, 16 x 16 bytes:
               u8  dest index      (core ioctl index: 0 sys ROM, 1 LO, 2 SFIX,
                                    4/5/6 P, 8 S1, 9 M1, 15 C, 16 V1, 48 V2)
               u8  flags           bit0 BIOS_UNI (index 0 only: this is the
                                   UniBIOS copy; clear = original), bit7 PACK
               u16 reserved
               u32 file offset     (= DDR offset from the image base; 64 KiB aligned)
               u32 length          (bytes)
               u32 address base    (informational: 0x1000000 for V2, else 0)
    body    regions in table order, then the pack (.cpk, format v2)

Table order is the record order: P before C (the core places C after the
P it has seen).  A V2 region must start exactly 16 MiB after V1 (the core
addresses both from the V1 offset), so V1 is padded to 16 MiB when V2
exists.  The core reads the first 1 KiB of the header, so the table must
fit there (16 entries do).  The whole image must fit the 256 MiB DDR window
(0x30000000..0x3FFFFFFF, the firmware's load-address range).
"""
from __future__ import annotations

import struct
import zlib
from dataclasses import dataclass, field
from pathlib import Path

MAGIC = b"NGA2"
VERSION = 2
HEADER_SIZE = 4096
MAX_REGIONS = 16
REGION_TABLE_OFF = 0x80
REGION_ENTRY = struct.Struct("<BBHIII")
ALIGN = 0x10000                 # region start alignment (V / M1 bases at 64 KiB granularity)
VROM_SIZE = 0x1000000           # V1 window; V2 sits 16 MiB after V1
LO_BYTES = 0x10000              # the core copies exactly this many LO bytes
DDR_WINDOW = 0x10000000         # the image loads at 0x30000000; the firmware's range ends at 0x40000000

FLAG_BIOS_UNI = 0x01
FLAG_PACK = 0x80

# core load indexes
IDX_SPROM, IDX_LOROM, IDX_SFIX = 0, 1, 2
IDX_P1, IDX_P1B, IDX_P2 = 4, 5, 6
IDX_S1, IDX_M1, IDX_CROM0 = 8, 9, 15
IDX_V1, IDX_V2 = 16, 48
IDX_PACK = 0xFF

INDEX_NAMES = {0: "sprom", 1: "lo", 2: "sfix", 4: "p1", 5: "p1b", 6: "p2",
               8: "s1", 9: "m1", 15: "c", 16: "v1", 48: "v2", 0xFF: "pack"}
COPY_DESTS = (IDX_SPROM, IDX_SFIX, IDX_P1, IDX_P1B, IDX_P2, IDX_S1, IDX_CROM0)   # DDR -> SDRAM
DDR_DESTS = (IDX_M1, IDX_V1, IDX_V2)                                              # stay in DDR


@dataclass
class Region:
    dest: int
    data: bytes
    flags: int = 0
    addr_base: int = 0
    name: str = ""

    @property
    def length(self) -> int:
        return len(self.data)


@dataclass
class ImageSpec:
    setname: str
    title: str
    ngh: int
    cfg: int
    regions: list[Region] = field(default_factory=list)
    pack: bytes | None = None


def _pad(n: int, a: int) -> int:
    return (n + a - 1) // a * a


def write_image(spec: ImageSpec, out: Path, align: int = ALIGN, strict: bool = True) -> dict:
    """Write the image; returns a manifest dict (offsets, sizes, crcs).
    strict: enforce the core's layout rules (LO = 64 KiB, V2 16 MiB after
    V1, P a 1 MiB multiple); the RTL testbench's synthetic image turns it off."""
    regions = list(spec.regions)
    if spec.pack is not None:
        regions.append(Region(IDX_PACK, spec.pack, FLAG_PACK, 0, "pack"))
    if len(regions) > MAX_REGIONS:
        raise ValueError(f"{len(regions)} regions > {MAX_REGIONS}")
    if align % 8 or align < 8:
        raise ValueError(f"alignment {align} is not a multiple of 8")

    hdr = bytearray(HEADER_SIZE)
    hdr[0:4] = MAGIC
    struct.pack_into("<HH", hdr, 0x004, VERSION, HEADER_SIZE)
    struct.pack_into("<III", hdr, 0x00C, spec.cfg & 0xFFFFFFFF, spec.ngh & 0xFFFFFFFF, len(regions))
    hdr[0x018:0x028] = spec.setname.encode()[:16].ljust(16, b"\0")
    hdr[0x028:0x068] = spec.title.encode("utf-8")[:64].ljust(64, b"\0")

    off = _pad(HEADER_SIZE, align)
    table = []
    body = bytearray(b"\0" * (off - HEADER_SIZE))
    manifest = {"setname": spec.setname, "cfg": f"0x{spec.cfg:08x}", "ngh": f"0x{spec.ngh:04x}",
                "regions": []}
    v1_off = None
    for i, r in enumerate(regions):
        file_off = HEADER_SIZE + len(body)
        if strict:
            if r.dest == IDX_LOROM and r.length != LO_BYTES:
                raise ValueError(f"LO region is {r.length} bytes, the core copies {LO_BYTES}")
            if r.dest in (IDX_P1, IDX_P2) and r.length % 0x100000:
                raise ValueError(f"P region {r.length} is not a 1 MiB multiple")
            if r.dest == IDX_V1:
                v1_off = file_off
            if r.dest == IDX_V2:
                if v1_off is None or file_off != v1_off + VROM_SIZE:
                    raise ValueError("V2 must start exactly 16 MiB after V1 (pad V1 to 16 MiB)")
        body += r.data
        body += b"\0" * (_pad(len(body) + HEADER_SIZE, align) - HEADER_SIZE - len(body))
        table.append((r.dest, r.flags, 0, file_off, r.length, r.addr_base))
        manifest["regions"].append({
            "dest": r.dest, "name": r.name or INDEX_NAMES.get(r.dest, str(r.dest)),
            "flags": r.flags, "offset": file_off, "length": r.length,
            "addr_base": r.addr_base, "crc32": f"{zlib.crc32(r.data) & 0xFFFFFFFF:08x}"})
        if r.flags & FLAG_PACK:
            struct.pack_into("<II", hdr, 0x068, file_off, r.length)
    for i, ent in enumerate(table):
        REGION_ENTRY.pack_into(hdr, REGION_TABLE_OFF + i * REGION_ENTRY.size, *ent)
    if strict and HEADER_SIZE + len(body) > DDR_WINDOW:
        sizes = ", ".join(f"{m['name']} {m['length'] / 2**20:.1f}" for m in manifest["regions"])
        raise ValueError(f"{spec.setname}: image is {(HEADER_SIZE + len(body)) / 2**20:.1f} MiB, over the "
                         f"{DDR_WINDOW // 2**20} MiB DDR window the core loads it into (MiB: {sizes})")
    struct.pack_into("<I", hdr, 0x070, zlib.crc32(body) & 0xFFFFFFFF)
    struct.pack_into("<I", hdr, 0x008, 0)
    struct.pack_into("<I", hdr, 0x008, zlib.crc32(hdr) & 0xFFFFFFFF)

    out.parent.mkdir(parents=True, exist_ok=True)
    with open(out, "wb") as f:
        f.write(hdr)
        f.write(body)
    manifest["size"] = HEADER_SIZE + len(body)
    return manifest


@dataclass
class ImageHeader:
    cfg: int
    ngh: int
    setname: str
    title: str
    pack_offset: int
    pack_length: int
    body_crc: int
    regions: list[tuple[int, int, int, int, int]]   # dest, flags, offset, length, addr_base


def read_header(path: Path, verify: bool = True) -> ImageHeader:
    with open(path, "rb") as f:
        hdr = bytearray(f.read(HEADER_SIZE))
        if hdr[0:4] != MAGIC:
            raise ValueError(f"{path}: bad magic {bytes(hdr[0:4])!r}")
        ver, hsize = struct.unpack_from("<HH", hdr, 0x004)
        if ver != VERSION or hsize != HEADER_SIZE:
            raise ValueError(f"{path}: version {ver} header {hsize}")
        stored = struct.unpack_from("<I", hdr, 0x008)[0]
        struct.pack_into("<I", hdr, 0x008, 0)
        if (zlib.crc32(hdr) & 0xFFFFFFFF) != stored:
            raise ValueError(f"{path}: header CRC mismatch")
        cfg, ngh, count = struct.unpack_from("<III", hdr, 0x00C)
        setname = bytes(hdr[0x018:0x028]).split(b"\0", 1)[0].decode()
        title = bytes(hdr[0x028:0x068]).split(b"\0", 1)[0].decode("utf-8", "replace")
        pack_off, pack_len = struct.unpack_from("<II", hdr, 0x068)
        body_crc = struct.unpack_from("<I", hdr, 0x070)[0]
        regions = []
        for i in range(count):
            dest, flags, _r, off, ln, base = REGION_ENTRY.unpack_from(hdr, REGION_TABLE_OFF + i * REGION_ENTRY.size)
            regions.append((dest, flags, off, ln, base))
        if verify:
            f.seek(HEADER_SIZE)
            crc = 0
            while True:
                chunk = f.read(1 << 20)
                if not chunk:
                    break
                crc = zlib.crc32(chunk, crc)
            if (crc & 0xFFFFFFFF) != body_crc:
                raise ValueError(f"{path}: body CRC mismatch")
    return ImageHeader(cfg, ngh, setname, title, pack_off, pack_len, body_crc, regions)


def read_region(path: Path, region: tuple[int, int, int, int, int]) -> bytes:
    _dest, _flags, off, ln, _base = region
    with open(path, "rb") as f:
        f.seek(off)
        return f.read(ln)
