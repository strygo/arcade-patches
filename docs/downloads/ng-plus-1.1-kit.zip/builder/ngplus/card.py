"""The MiSTer SD card tree: image, launcher, core.

    games/NG+/<set>.nga                                    the game image
    _Arcade/_Arcade Patches/_Arrangements/_NG+/<Title>.mgl the launcher (menu entry)
    _Arcade/_Arcade Patches/_Arrangements/_NG+/cores/      the NG+ core (not listed in the menu)

The core's name is NG+, so the firmware gives it its own games, saves and
config folders: nothing of a stock Neo Geo setup is read or written.  Each
launcher also names its game with <setname same_dir="1">, as an arcade MRA
does: the menu reads "Define <set> buttons", and each game keeps its own
button map and menu settings (<set>.CFG), while same_dir keeps the games and
saves folders on the core's own name.  The launcher loads the image by name
from games/NG+; the firmware mounts
saves/NG+/<set>.sav itself at the end of that load and creates it on the
first write (the core's file entry asks for it), so the card tree carries no
save file and an existing one is never touched.
"""
from __future__ import annotations

import shutil
from pathlib import Path

from . import convert, soundpatch
from .cartconfig import CartConfig
from .image import (ImageSpec, Region, write_image, read_header, IDX_SPROM, IDX_LOROM, IDX_SFIX,
                    IDX_P1, IDX_S1, IDX_M1, IDX_CROM0, IDX_V1, IDX_V2, FLAG_BIOS_UNI)
from .roms import GameRoms, BiosRoms
from .title import Title

CORE = "NG+"
LAUNCHER_FOLDER = "_Arcade/_Arcade Patches/_Arrangements/_NG+"
SD_ROOT = "/media/fat"
VROM_SIZE = 16 * 1024 * 1024


def p_region(p: bytes) -> bytes:
    """The loader copies P in whole MiB: pad so the copy reads defined bytes."""
    return p + b"\0" * (-len(p) % 0x100000)


def v_region(data: bytes, mirror: int, pad_full: bool = False) -> bytes:
    """A cartridge without V ROM mirroring reads 0x08 (ADPCM silence) past the
    ROM, up to 16 MiB.  pad_full: a V2 follows, 16 MiB after V1."""
    if (mirror and not pad_full) or len(data) >= VROM_SIZE:
        return data
    return data + bytes([0x08]) * (VROM_SIZE - len(data))


def image_spec(t: Title, game: GameRoms, bios: BiosRoms, pack: bytes | None) -> tuple[ImageSpec, list[str]]:
    cart = CartConfig.from_dict(t.cart)
    m1, notes = soundpatch.apply(game.m1, t.sound_mutes)
    regions: list[Region] = []
    if bios.sprom_orig:
        regions.append(Region(IDX_SPROM, bios.sprom_orig, 0, 0, "sprom_orig"))
    if bios.sprom_uni:
        regions.append(Region(IDX_SPROM, bios.sprom_uni, FLAG_BIOS_UNI, 0, "sprom_uni"))
    regions.append(Region(IDX_LOROM, bios.lo, 0, 0, "lo"))
    regions.append(Region(IDX_SFIX, convert.fix_convert(bios.sfix), 0, 0, "sfix"))
    regions.append(Region(IDX_P1, p_region(game.p), 0, 0, "p"))
    regions.append(Region(IDX_S1, convert.fix_convert(game.s), 0, 0, "s1"))
    regions.append(Region(IDX_M1, m1, 0, 0, "m1"))
    if cart.vromb_offset and game.v2 is None:
        v1, v2 = game.v1[:cart.vromb_offset], game.v1[cart.vromb_offset:]   # one V file split at vromb_offset
    else:
        v1, v2 = game.v1, game.v2
    regions.append(Region(IDX_V1, v_region(v1, cart.vrom_mirror, pad_full=bool(v2)), 0, 0, "v1"))
    if v2:
        regions.append(Region(IDX_V2, v_region(v2, cart.vrom_mirror), 0, 0x1000000, "v2"))
    regions.append(Region(IDX_CROM0, convert.core_c_from_crom0(game.crom0), 0, 0, "c"))
    if pack is not None and pack[:4] != b"CP2A":
        raise ValueError("not a CPS+ format pack")
    cfg = cart.cfg_word(v2 is not None, len(game.v1))
    return ImageSpec(t.set, t.name, game.ngh, cfg, regions, pack), notes


def mgl_text(t: Title, rbf_base: str, launcher: str = LAUNCHER_FOLDER) -> str:
    return (
        "<mistergamedescription>\n"
        f"\t<rbf>{launcher}/cores/{rbf_base}</rbf>\n"
        f"\t<setname same_dir=\"1\">{t.set}</setname>\n"
        f"\t<file delay=\"1\" type=\"f\" index=\"1\" path=\"{t.set}.nga\"/>\n"
        "</mistergamedescription>\n"
    )


def launcher_name(title: str) -> str:
    """The launcher's file name: the title, minus what a card cannot hold.

    FAT32 and Windows forbid the same handful of characters, so a title with,
    say, a colon in it would build here and fail there; dropping them on every
    platform keeps one name for one title wherever the kit is run.
    """
    name = " ".join("".join(" " if c in '\\/:*?"<>|' else c for c in title).split())
    return name.rstrip(" .") or "untitled"


def write_title(out: Path, t: Title, game: GameRoms, bios: BiosRoms, pack: bytes | None,
                rbf_base: str, launcher: str = LAUNCHER_FOLDER) -> dict:
    """Image and launcher for one title under the card root `out`."""
    spec, notes = image_spec(t, game, bios, pack)
    img = out / "games" / CORE / f"{t.set}.nga"
    manifest = write_image(spec, img)
    read_header(img, verify=True)
    (out / launcher).mkdir(parents=True, exist_ok=True)
    (out / launcher / f"{launcher_name(t.name)}.mgl").write_text(mgl_text(t, rbf_base, launcher), encoding="utf-8", newline="\n")
    manifest["notes"] = notes
    return manifest


def install_core(out: Path, rbf: Path, launcher: str = LAUNCHER_FOLDER) -> Path:
    dst = out / launcher / "cores" / rbf.name
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(rbf, dst)
    return dst


def rbf_base(rbf: Path) -> str:
    """The launcher names the core without its date: NeoGeoPlus_20260915.rbf -> NeoGeoPlus."""
    stem = rbf.stem
    head, _, date = stem.rpartition("_")
    return head if head and date.isdigit() and len(date) == 8 else stem
