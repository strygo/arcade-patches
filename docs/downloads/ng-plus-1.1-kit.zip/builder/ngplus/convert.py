"""ROM conversions the MiSTer Neo Geo loader applies, reproduced byte-exact.

The MiSTer firmware reorders sprite (C) and fix-layer (S / SFIX) data before
it reaches the core, so that one SDRAM burst fetches a whole tile line.  The
builder does the same work ahead of time, so the image holds core-ready
bytes.  Every function here mirrors one firmware routine; `selftest()` checks
the firmware's two sprite paths (consolidated `crom0` vs per-file c1/c2)
against each other, which is what makes the consolidated form safe for
MAME-named input.

  fix_convert        fix_convert()          S1 / SFIX, 32-byte tile groups
  spr_convert_dbl    spr_convert_dbl()      consolidated C (index 15)
  spr_convert_skp    spr_convert_skp()      per-file C (index 64+), stride 2
  spr_bswap          spr_bswap()            .neo C block: 32-bit byte swap
  consolidate_c      c1/c2 pairs -> the Darksoft crom0 word interleave
"""
from __future__ import annotations

import array


def _words(b: bytes) -> array.array:
    a = array.array("H")
    a.frombytes(b)
    return a


def fix_convert(data: bytes) -> bytes:
    """S ROM: In FEDCBA9876543210 -> Out FEDCBA9876510432 (byte index bits)."""
    n = len(data)
    if n % 32:
        raise ValueError("fix data must be a multiple of 32 bytes")
    out = bytearray(n)
    src = data
    for i in range(n):
        out[i] = src[(i & ~0x1F) | ((i >> 2) & 7) | ((i & 1) << 3) | (((i & 2) << 3) ^ 0x10)]
    return bytes(out)


def spr_convert_dbl(data: bytes) -> bytes:
    """Consolidated C ROM (crom0 / .neo after bswap): 16-bit word permutation
    within 64-word blocks (the firmware's spr_convert_dbl)."""
    w = _words(data)
    n = len(w)
    if n % 64:
        raise ValueError("sprite data must be a multiple of 128 bytes")
    out = array.array("H", bytes(2 * n))
    for i in range(n):
        out[i] = w[(i & ~0x3F) | ((i ^ 1) & 1) | ((i >> 1) & 0x1E) | (((i & 2) ^ 2) << 4)]
    return out.tobytes()


def spr_convert_skp(data: bytes) -> array.array:
    """Per-file C ROM (index 64+): the firmware writes file word k to staging
    word 2*k + ((index ^ 1) & 1) after this permutation of the file's own
    words (32-word blocks).  Returns the permuted words (not yet strided)."""
    w = _words(data)
    n = len(w)
    out = array.array("H", bytes(2 * n))
    for i in range(n):
        out[i] = w[(i & ~0x1F) | ((i >> 1) & 0xF) | (((i & 1) ^ 1) << 4)]
    return out


def spr_bswap(data: bytes) -> bytes:
    """.neo C block: within each 32-bit little-endian word swap the two
    middle bytes (firmware spr_bswap)."""
    if len(data) % 4:
        raise ValueError("bswap needs a multiple of 4 bytes")
    out = bytearray(data)
    out[1::4], out[2::4] = data[2::4], data[1::4]
    return bytes(out)


def interleave16(a: bytes, b: bytes) -> bytes:
    """Darksoft crom0 layout: c1 words in even slots, c2 words in odd slots."""
    if len(a) != len(b):
        raise ValueError("C ROM pair sizes differ")
    out = bytearray(2 * len(a))
    out[0::4] = a[0::2]
    out[1::4] = a[1::2]
    out[2::4] = b[0::2]
    out[3::4] = b[1::2]
    return bytes(out)


def consolidate_c(pairs: list[tuple[bytes, bytes]],
                  bases: list[int] | None = None) -> bytes:
    """MAME c1/c2, c3/c4, ... -> crom0 (Darksoft consolidated) in order.

    With `bases`, each pair's interleaved block lands at its address on the
    cartridge and the space between blocks stays empty.  A board need not
    populate every sprite socket: KOF '95 leaves 4 MB unpopulated before its
    last pair, and its tile numbers address the pair past that hole, so a
    crom0 packed without it draws the wrong tiles.
    """
    blocks = [interleave16(a, b) for a, b in pairs]
    if bases is None:
        return b"".join(blocks)
    out = bytearray(max(b + len(blk) for b, blk in zip(bases, blocks)))
    for base, blk in zip(bases, blocks):
        out[base:base + len(blk)] = blk
    return bytes(out)


def core_c_from_pairs(pairs: list[tuple[bytes, bytes]]) -> bytes:
    """Core-ready consolidated C from MAME pairs (index 15 stream)."""
    return spr_convert_dbl(consolidate_c(pairs))


def core_c_from_crom0(crom0: bytes) -> bytes:
    return spr_convert_dbl(crom0)


def core_c_from_neo(cblock: bytes) -> bytes:
    return spr_convert_dbl(spr_bswap(cblock))


def per_file_path(pairs: list[tuple[bytes, bytes]]) -> bytes:
    """What the firmware's index-64+ path (load_crom_to_mem) produces for the
    same pairs: reference for selftest only."""
    out = bytearray()
    for k, (a, b) in enumerate(pairs):
        n = len(a) // 2
        st = array.array("H", bytes(4 * n))
        for data, idx in ((a, 64 + 2 * k), (b, 65 + 2 * k)):
            conv = spr_convert_skp(data)
            off = (idx ^ 1) & 1
            st[off::2] = conv
        out += st.tobytes()
    return bytes(out)


def selftest() -> None:
    import os
    import random
    random.seed(7)
    # permutations must be bijections (every source index used once)
    for fn, unit in ((fix_convert, 32), (spr_convert_dbl, 128)):
        probe = bytes(range(256)) * (unit // 32) if unit > 256 else bytes(range(unit))
        probe = bytes(i & 0xFF for i in range(unit * 4))
        out = fn(probe)
        assert sorted(out) == sorted(probe), fn.__name__
    pairs = [(os.urandom(4096), os.urandom(4096)) for _ in range(2)]
    assert core_c_from_pairs(pairs) == per_file_path(pairs), "crom0 path != per-file path"
    # .neo = crom0 with the middle bytes of every 32-bit word swapped
    crom0 = consolidate_c(pairs)
    assert core_c_from_neo(spr_bswap(crom0)) == core_c_from_crom0(crom0)
    assert spr_bswap(spr_bswap(crom0)) == crom0
    print("convert selftest ok")


if __name__ == "__main__":
    selftest()
