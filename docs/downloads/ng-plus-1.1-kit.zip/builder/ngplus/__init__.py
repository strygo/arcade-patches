"""NG+ builder: Neo Geo cartridge games with their arranged Neo Geo CD
soundtracks, built as MiSTer images from the ROM sets and disc rips you own."""

__version__ = "0.1"
