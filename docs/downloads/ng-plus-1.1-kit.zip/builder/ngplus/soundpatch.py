"""Voices the arranged tracks already carry: per-title ADPCM sample mutes.

Some Neo Geo CD discs record a voice into the Red Book track itself
(Samurai Shodown II: the narrator's line at "TIME HAS PASSED..." is part of
the track that cue plays), and the CD version leaves the cartridge's ADPCM
copy of that voice out of the scene's sample bank so it is heard once.  NG+
runs the cartridge program with the cartridge's sample ROMs, so without a
mute the voice would play from ADPCM and again from the arranged track.

The SNK sound driver decides per (start command, sample) whether a sample
may play: each ADPCM start command ($18..$1E, the set differs per driver
build; start_commands() reads them) has a 256-bit enable bitmap it tests
before allocating a channel (`ld hl,BITMAP / call BITTEST / ret z`, or in
later builds `ld c,CLASS / call CHECK / ret z`).  Clearing a sample's bit
makes the driver ignore that start command, exactly as the CD version's
missing data does, without touching the sample data or the channel logic.

A title lists its mutes in title.json:
    "sound_mutes": [{"cmd": "0x1e", "sample": "0x44", "note": "..."}]
"""
from __future__ import annotations

import re
from dataclasses import dataclass

# class 1..3 start handlers: call POP / cp $10 / jp c,ERR / ld hl,TABLE /
# call BITTEST / ret z / ld a,$18 / ld ($FE3E),a / ld a,CLASS / ld ($FEB2),a
_PROLOGUE_A = re.compile(rb"\xcd..\xfe\x10\xda..\x21(..)\xcd..\xc8\x3e\x18\x32\x3e\xfe\x3e(.)\x32\xb2\xfe", re.S)
# class 0 ($18): the same without the class store
_PROLOGUE_B = re.compile(rb"\xcd..\xfe\x10\xda..\x21(..)\xcd..\xc8\x3e\x18\x32\x3e\xfe\x3a\x3d\xfe\xf3", re.S)
# later build (KOF '95): each start handler is `ld c,CLASS / call CHECK /
# ret z`, and CHECK pops the sample, then indexes a table of bitmap addresses
# by class: push bc / call POP / pop bc / cp $10 / jp nc,.. / pop bc / jp .. /
# ld b,0 / ld hl,PTRS / add hl,bc x2 / ld b,(hl) / inc hl / ld h,(hl) / ld l,b
_START_C = re.compile(rb"\x0e([\x00-\x03])\xcd(..)\xc8", re.S)
_CHECK_C = re.compile(rb"\xc5\xcd..\xc1\xfe\x10\xd2..\xc1\xc3..\x06\x00\x21(..)\x09\x09\x46\x23\x66\x68", re.S)
CMD_CLASS = {0x18: 0, 0x1A: 1, 0x1C: 2, 0x1E: 3}


def class_tables(m1: bytes) -> dict[int, int]:
    """{start class: enable-bitmap address} for the ADPCM-A starts $18/$1A/
    $1C/$1E (CMD_CLASS), found from the handler prologues.  start_commands()
    reads every start command a driver has."""
    tables: dict[int, int] = {}
    for m in _PROLOGUE_A.finditer(m1):
        tables[m.group(2)[0]] = int.from_bytes(m.group(1), "little")
    for m in _PROLOGUE_B.finditer(m1):
        tables.setdefault(0, int.from_bytes(m.group(1), "little"))
    if tables:
        return tables
    for m in _START_C.finditer(m1):
        check = _CHECK_C.match(m1, int.from_bytes(m.group(2), "little"))
        if check:
            ptrs, cls = int.from_bytes(check.group(1), "little"), m.group(1)[0]
            tables.setdefault(cls, int.from_bytes(m1[ptrs + 2 * cls:ptrs + 2 * cls + 2], "little"))
    return tables


# ---------------------------------------------------------------------------
# Reading each start command's handler
#
# Four builds of the driver are known.  They differ in where a start command
# names its enable bitmap and its sample table:
#
#   2.0a (Fatal Fury, Last Resort, Baseball Stars 2): call POP / or a /
#     jp z,ERR / cp $10 / jp c,ERR / ld hl,BITMAP / push bc / call BITTEST /
#     pop bc / or a / ret z / ... / jp PLAY, and PLAY calls a routine that
#     turns the sample into ix = TABLE + sample * entry.
#   3.0, early (Samurai Shodown II, KOF '94, Fatal Fury Special, Art of
#     Fighting 2): call POP / cp $10 / jp c,ERR / ld hl,BITMAP /
#     call BITTEST / ret z / ... / jp PLAY, PLAY as in 2.0a.
#   3.0, KOF '95: ld c,CLASS / call CHECK / ret z / ld a,CLASS /
#     ld hl,TABLE / ... / jp PLAY; CHECK pops the sample and takes the
#     class's bitmap from a pointer table, PLAY stores hl and its entry
#     routine reads it back (ld ix,(VAR)).  Class 0 loads its table in PLAY.
#   3.0, later (Samurai Shodown III, Real Bout Fatal Fury, Art of Fighting 3):
#     the same CHECK; ld c,CLASS / call CHECK / ret z / ld a,CMD /
#     ld ix,TABLE / jp PLAY, and PLAY adds sample * 6 (or * 11) to ix inline.
#     Classes run past 3 here: $1B is class 4, $19 class 5, $1D class 7.
#
# Every build plays ADPCM-A from 6- or 11-byte entries and ADPCM-B from 16-
# or 26-byte ones (read from the play routines: the ADPCM-A ones write the
# YM2610's second register port, the ADPCM-B ones its first), and every
# entry holds the sample's start and end address, in 256-byte units, at
# bytes 1-4.  A handler is followed from its first instruction: constant
# loads into hl and ix are tracked, unconditional jumps are taken, a
# conditional branch is assumed not taken (the handlers branch away only to
# reject), and the walk ends at the routine that indexes the table.

@dataclass(frozen=True)
class Start:
    """One ADPCM start command, as its handler reads it."""
    cmd: int
    handler: int
    cls: int | None      # the driver's class number (None where the build has none for it)
    bitmap: int | None   # 256-bit enable bitmap: sample n is bit 0x80 >> (n & 7) of byte n >> 3
    table: int           # sample table
    entry: int           # bytes per table entry
    channel: str         # "A" or "B" (ADPCM-A or ADPCM-B)
    limit: int | None    # samples from here up go to another routine, not this table


def _u16(m: bytes, a: int) -> int:
    return m[a] | (m[a + 1] << 8)


_LEN3 = frozenset({0x01, 0x11, 0x21, 0x31, 0x22, 0x2A, 0x32, 0x3A,
                   0xC2, 0xC3, 0xCA, 0xD2, 0xDA, 0xE2, 0xEA, 0xF2, 0xFA,
                   0xC4, 0xCC, 0xCD, 0xD4, 0xDC, 0xE4, 0xEC, 0xF4, 0xFC})
_LEN2 = frozenset({0x06, 0x0E, 0x16, 0x1E, 0x26, 0x2E, 0x36, 0x3E, 0x10, 0x18, 0x20, 0x28, 0x30, 0x38,
                   0xC6, 0xCE, 0xD6, 0xDE, 0xE6, 0xEE, 0xF6, 0xFE, 0xD3, 0xDB, 0xCB})
# the (hl) forms, which take a displacement after a DD/FD prefix
_IXD = frozenset({0x34, 0x35, 0x46, 0x4E, 0x56, 0x5E, 0x66, 0x6E, 0x7E, 0x70, 0x71, 0x72, 0x73,
                  0x74, 0x75, 0x77, 0x86, 0x8E, 0x96, 0x9E, 0xA6, 0xAE, 0xB6, 0xBE})
# instructions that change hl, or (after DD) ix, other than the loads tracked
_HL_SET = frozenset({0x2A, 0x09, 0x19, 0x29, 0x39, 0x23, 0x2B, 0x26, 0x2E, 0xE1, 0xEB, 0xE3, 0xD9}
                    | set(range(0x60, 0x70)))
_HL_SET_ED = frozenset({0x42, 0x4A, 0x52, 0x5A, 0x62, 0x6A, 0x72, 0x7A, 0x6B})
_IX_SET = frozenset({0xE1, 0x09, 0x19, 0x29, 0x39, 0x23, 0x2B, 0x26, 0x2E, 0xE3} | set(range(0x60, 0x70)))


def _length(m: bytes, pc: int) -> int:
    op = m[pc]
    if op == 0xED:
        return 4 if m[pc + 1] in (0x43, 0x4B, 0x53, 0x5B, 0x63, 0x6B, 0x73, 0x7B) else 2
    if op in (0xDD, 0xFD):
        op2 = m[pc + 1]
        if op2 in (0xCB, 0x21, 0x22, 0x2A, 0x36):
            return 4
        return 3 if op2 in _IXD else 1 + _length(m, pc + 1)
    return 3 if op in _LEN3 else 2 if op in _LEN2 else 1


# 2.0a/early-build bit test: (push bc) / ld c,a / and 7 / ld b,3 / srl c /
# djnz / add hl,bc / ...: the sample's bit in the bitmap hl points at
_BITTEST = re.compile(rb"\xc5?\x4f\xe6\x07\x06\x03\xcb\x39\x10\xfc\x09", re.S)
# routines the play routine calls to point ix at the sample's entry:
# (pattern, bytes per entry, channel, where the table comes from)
_LOOKUPS = (
    # (push de) / ld l,e / ld h,0 / ld d,h (or ld d,0) / add hl,hl x3 /
    # add hl,de x3 / ld de,TABLE / add hl,de / push hl / pop ix
    (re.compile(rb"\xd5?\x6b\x26\x00(?:\x54|\x16\x00)\x29\x29\x29\x19\x19\x19\x11(..)\x19\xe5\xdd\xe1", re.S),
     11, "A", "const"),
    # push de / ld l,e / ld h,0 / ld d,h / add hl,hl x3 / add hl,de x3 /
    # ex de,hl / ld ix,(VAR) / add ix,de
    (re.compile(rb"\xd5?\x6b\x26\x00\x54\x29\x29\x29\x19\x19\x19\xeb\xdd\x2a(..)\xdd\x19", re.S), 11, "A", "var"),
    # ld l,a / ld h,0 / ld c,l / ld b,0 / add hl,hl x4 / ex de,hl /
    # ld ix,TABLE / add ix,de
    (re.compile(rb"\x6f\x26\x00\x4d\x06\x00\x29\x29\x29\x29\xeb\xdd\x21(..)\xdd\x19", re.S), 16, "B", "const"),
    # ld l,a / ld h,0 / ld c,l / ld b,0 / add hl,hl x3 / push hl / add hl,hl /
    # pop de / add hl,de / add hl,bc x2 / ld de,TABLE / add hl,de / push hl / pop ix
    (re.compile(rb"\x6f\x26\x00\x4d\x06\x00\x29\x29\x29\xe5\x29\xd1\x19\x09\x09\x11(..)\x19\xe5\xdd\xe1", re.S),
     26, "B", "const"),
)
# the later build's play routines, table already in ix: ld l,e / ld h,0 /
# ld d,h / add hl,hl / add hl,de / add hl,hl / (add hl,hl / or a /
# sbc hl,de) / ex de,hl / add ix,de
_INLINE = (
    (re.compile(rb"\x6b\x26\x00\x54\x29\x19\x29\xeb\xdd\x19"), 6, "A"),
    (re.compile(rb"\x6b\x26\x00\x54\x29\x19\x29\x29\xb7\xed\x52\xeb\xdd\x19"), 11, "A"),
)


def _read_start(m1: bytes, cmd: int, handler: int, legacy: dict[int, int]) -> Start | None:
    """Follow one system command's handler to the routine that indexes a
    sample table; None if it never gets there (not a start command)."""
    pc, hl, ix, mem = handler, None, None, {}
    bitmap = cls = limit = None
    prev = -1                                  # the previous instruction's address
    seen = set()
    for _ in range(160):
        if pc in seen or not 0 <= pc < len(m1) - 4:
            return None
        seen.add(pc)
        for rx, entry, channel in _INLINE:
            if rx.match(m1, pc):
                return Start(cmd, handler, cls, bitmap, ix, entry, channel, limit) if ix is not None else None
        op, op2, n = m1[pc], m1[pc + 1], _length(m1, pc)
        if op == 0xCD:
            t = _u16(m1, pc + 1)
            check = _CHECK_C.match(m1, t)
            if check and prev >= 0 and m1[prev] == 0x0E:          # ld c,CLASS / call CHECK
                cls = m1[prev + 1]
                bitmap = _u16(m1, _u16(m1, check.start(1)) + 2 * cls)
            elif _BITTEST.match(m1, t) and hl is not None:        # ld hl,BITMAP / call BITTEST
                bitmap = hl
                cls = {v: k for k, v in legacy.items()}.get(bitmap)
            else:
                for rx, entry, channel, src in _LOOKUPS:
                    lk = rx.match(m1, t)
                    if lk:
                        table = _u16(m1, lk.start(1)) if src == "const" else mem.get(_u16(m1, lk.start(1)))
                        return Start(cmd, handler, cls, bitmap, table, entry, channel, limit) \
                            if table is not None else None
                hl = ix = None                                    # anything else may change them
        elif (op & 0xC7) in (0xC4, 0xC7):                        # call cc / rst
            hl = ix = None
        elif op == 0xC3:
            prev, pc = pc, _u16(m1, pc + 1)
            continue
        elif op == 0x18:
            prev, pc = pc, pc + 2 + (op2 - 256 if op2 & 0x80 else op2)
            continue
        elif op in (0xC9, 0xE9, 0x76) or (op == 0xED and op2 in (0x45, 0x4D)) \
                or (op in (0xDD, 0xFD) and op2 == 0xE9):
            return None                                           # ret / jp (hl) / halt / reti / retn
        elif op in (0xD2, 0x30, 0xD0) and prev >= 0 and m1[prev] == 0xFE and bitmap is not None:
            limit = m1[prev + 1]                                  # cp N / jp nc: N and up go elsewhere
        elif op == 0x21:
            hl = _u16(m1, pc + 1)
        elif op == 0x22:
            mem[_u16(m1, pc + 1)] = hl
        elif op in _HL_SET or (op == 0xED and op2 in _HL_SET_ED):
            hl = None
        elif op == 0xDD and op2 == 0x21:
            ix = _u16(m1, pc + 2)
        elif op == 0xDD and op2 == 0x2A:
            ix = mem.get(_u16(m1, pc + 2))
        elif op == 0xDD and op2 in _IX_SET:
            ix = None
        prev, pc = pc, pc + n
    return None


# the command dispatcher (3.0: value and type tables, `dec a / jp z` per
# type; 2.0a: a type table and `cp N / jp z`) and the system-command table
# its type-1 handler jumps through (3-byte `jp` entries, or 2-byte addresses
# with a bound in the later builds)
_DISPATCH = re.compile(rb"\x5f\x16\x00\x21(..)\x19\x7e\x32..\x21(..)\x19\x7e\x32..\xb7\xc8"
                       rb"((?:\x3d\xca..)+)", re.S)
_DISPATCH_20 = re.compile(rb"\x5f\x16\x00\x21(..)\x19\x7e\x32..\x3a..\xb7\xc8((?:\xfe.\xca..)+)", re.S)
_SYS_JT = re.compile(rb"\x3a(..)\x5f\x16\x00\x21(..)\x19\x19\x19\xe9", re.S)
_SYS_PT = re.compile(rb"\x3a(..)\xfe(.)\xd0\x5f\x16\x00\x21(..)\x19\x19\x5e\x23\x56\xeb\xe9", re.S)


def system_handlers(m1: bytes) -> dict[int, int]:
    """{system command: handler address}, from the driver's dispatcher."""
    m = _DISPATCH.search(m1)
    if m:
        types, first = _u16(m1, m.start(2)), _u16(m1, m.start(3) + 2)
    else:
        m = _DISPATCH_20.search(m1)
        if not m:
            return {}
        chain = {m.group(2)[i + 1]: _u16(m.group(2), i + 3) for i in range(0, len(m.group(2)), 5)}
        if 1 not in chain:
            return {}
        types, first = _u16(m1, m.start(1)), chain[1]
    cmds = [c for c in range(256) if m1[types + c] == 1]
    sj, sp = _SYS_JT.match(m1, first), _SYS_PT.match(m1, first)
    if sj:
        jt = _u16(m1, sj.start(2))
        return {c: _u16(m1, jt + 3 * c + 1) for c in cmds
                if m1[jt + 3 * c] == 0xC3 and _u16(m1, jt + 3 * c + 1) < len(m1)}
    if sp:
        bound, jt = sp.group(2)[0], _u16(m1, sp.start(3))
        return {c: _u16(m1, jt + 2 * c) for c in cmds if c < bound and _u16(m1, jt + 2 * c) < len(m1)}
    return {}


def start_commands(m1: bytes, handlers: dict[int, int] | None = None) -> dict[int, Start]:
    """{command: Start} for every system command whose handler starts an
    ADPCM sample.  `handlers` ({command: address}) defaults to the ones the
    driver's own dispatcher names."""
    if handlers is None:
        handlers = system_handlers(m1)
    legacy = class_tables(m1)
    out = {}
    for cmd, h in sorted(handlers.items()):
        st = _read_start(m1, cmd, h, legacy)
        if st is not None:
            out[cmd] = st
    return out


def sample_enabled(m1: bytes, table: int, sample: int) -> bool:
    return bool(m1[table + (sample >> 3)] & (0x80 >> (sample & 7)))


def apply(m1: bytes, mutes: list[dict]) -> tuple[bytes, list[str]]:
    """Return the sound ROM with the listed samples disabled, and notes."""
    if not mutes:
        return m1, []
    starts = start_commands(m1)
    legacy = class_tables(m1)
    out = bytearray(m1)
    notes = []
    for mu in mutes:
        cmd, sample = int(mu["cmd"], 16), int(mu["sample"], 16)
        st = starts.get(cmd)
        if st is None or st.bitmap is None:
            raise ValueError(f"no enable table for ADPCM start ${cmd:02X} in the sound ROM")
        table = st.bitmap
        if CMD_CLASS.get(cmd) in legacy and legacy[CMD_CLASS[cmd]] != table:
            raise ValueError(f"ADPCM start ${cmd:02X}: its handler names enable table 0x{table:04X}, "
                             f"the prologue scan 0x{legacy[CMD_CLASS[cmd]]:04X}")
        if not sample_enabled(bytes(out), table, sample):
            raise ValueError(f"sample ${sample:02X} of ${cmd:02X} is already disabled")
        out[table + (sample >> 3)] &= ~(0x80 >> (sample & 7)) & 0xFF
        notes.append(f"sample mute ${cmd:02X} ${sample:02X} (enable bit at 0x{table + (sample >> 3):04X})")
    return bytes(out), notes
