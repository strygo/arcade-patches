# NG+ pack format (.cpk)

An NG+ pack holds a title's arranged soundtrack and the map from the game's
own sound commands to it.  The format is the CPS+ pack format, format
version 2, with the Neo Geo byte-latch dialect.  `ngplus/cpk/format.py` writes
and reads it and is the normative reference; this document mirrors it.  The
pack is the last region of the game image, and the core plays it from DDR.

All integers are little-endian.

```
0x0000  HEADER           4096 B
0x1000  TRIGGER TABLE    256 rows x 4 B, one row per command byte
......  TRACK INDEX      track_count x 32 B
......  TRACK DATA       64 B aligned per track
```

## Binary layout

### Header

| off | type | field |
|---|---|---|
| 0x000 | 4s  | magic `"CP2A"` |
| 0x004 | u16 | format_version = 2 |
| 0x006 | u16 | header_size = 4096 |
| 0x008 | 16s | game id (the MAME set name), NUL-padded ASCII |
| 0x018 | 64s | title, NUL-padded UTF-8 |
| 0x058 | u16 | builder_version |
| 0x05a | u16 | default sample rate (44100; tracks carry their own) |
| 0x05c | u32 | trigger table offset |
| 0x060 | u32 | trigger table rows (256) |
| 0x064 | u32 | track index offset |
| 0x068 | u32 | track count |
| 0x06c | u64 | track data offset |
| 0x074 | u64 | track data size |
| 0x07c | u64 | total file size |
| 0x084 | u32 | crc32(trigger table + track index) |
| 0x088 | u32 | crc32(track data section, including alignment padding) |
| 0x08c | u32 | sound latch address (0x320000) |
| 0x090 | u8 x 8 | unused by this dialect (0) |
| 0x098 | u8  | fade law (3: `frames = const2 + const1 / speed`) |
| 0x099 | u8  | control default verb (0) |
| 0x09a | u16 | control region start (0) |
| 0x09c | u32 | fade const1 |
| 0x0a0 | u32 | fade const2 |
| 0x0a4 | u32 | control verb count N (at most 32) |
| 0x0a8 | N x {u16 cmd, u8 verb, u8 0} | control verb map |
| 0x128 | u16 | loop crossfade length in samples (a multiple of 32; 0 = none) |
| 0x12a | u8  | dialect (2 = Neo Geo byte latch with argument commands) |
| 0x130 | 32 B | argument-command bitmap: bit c set = command c takes the next byte as its argument |

Verbs: 0 none, 1 play, 2 stop, 3 fade out (loop off), 5 restore volume.
Neo Geo sound commands are single bytes; some system commands take one
argument byte, and argument values routinely fall in the music range, so
the player skips the byte after any command in the bitmap.

Fade law 3: a fade-out command's argument is the sound driver's speed
byte.  The player fades over `const2 + const1 / speed` frames, linear in
decibels in 64 steps of 0.75 dB, then stops the track.  A fade command that
arrives while a fade is already running is ignored, as the driver does.

### Trigger row (4 B, one per command byte)

| byte | field |
|---|---|
| 0 | verb (0 none, 1 play) |
| 1 | track index low byte |
| 2 | gain, linear 0..0x7f (0x7f = unity) |
| 3 | bit 0: suppress the command on the sound board; bits 4-7: track index high nibble |

### Track index entry (32 B)

| off | type | field |
|---|---|---|
| 0x00 | u32 | data offset, relative to the track data section |
| 0x04 | u32 | data length in bytes |
| 0x08 | u32 | loop start sample |
| 0x0c | u32 | loop start byte (ADX frame aligned) |
| 0x10 | u32 | loop end sample |
| 0x14 | u32 | loop end byte; 0 = the track does not loop |
| 0x18 | u16 | sample rate |
| 0x1a | u8  | bits 0-3 channels, bit 4 codec (0 ADX, 1 PCM), bit 5 loop crossfade, bits 6-7 loop count (0 = forever) |
| 0x1b | u8  | track gain, linear 0..0x7f |
| 0x1c | s16 | ADX predictor coefficient 1 |
| 0x1e | s16 | ADX predictor coefficient 2 |

Track data is raw ADX frames (18 bytes per channel per 32 samples) with the
container header removed.  The coefficients are the 500 Hz cutoff values
FFmpeg's encoder uses.

## Loops

The player wraps after `loop_end_byte` bytes and continues at
`loop_start_byte`, restoring the ADX predictor state it saved at the first
crossing of the loop start.

A track with the crossfade bit keeps `crossfade length` samples of audio
past the loop end.  At the wrap the player blends that continuation into the
start of the loop body with an equal-power curve,
`out[k] = cos((k + 0.5) / N * pi/2) * tail[k] + sin(...) * head[k]`, so the
loop is seamless without re-encoding any audio.  The loop period stays
`loop_end - loop_start`.

## Runtime

The core watches the byte the 68000 writes to the sound latch.  A command
with a play row starts its track and, with the suppress bit, the core
withholds that command from the sound board's Z80, so the board's own music
never starts while its sound effects keep playing.  Control verbs stop and
fade the arranged track.  Commands without a row pass through untouched.
With no pack loaded, the core behaves like the stock Neo Geo core.
