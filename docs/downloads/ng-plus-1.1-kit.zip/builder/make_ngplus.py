#!/usr/bin/env python3
"""NG+ builder: Neo Geo games with their arranged Neo Geo CD soundtracks,
built from the ROM sets and disc rips you own.

This kit ships no game data.  For every title you have the cartridge set and
the Neo Geo CD disc for, the builder:
  1. checks every ROM against the set's published CRCs;
  2. reads the disc's audio tracks and checks each against its published
     checksum;
  3. builds the arranged-audio pack and checks it byte-for-byte against the
     published pack hash, so what you hear is exactly what was tested;
  4. writes the game image and a launcher into out/mister/, laid out like
     your SD card, with the NG+ core.

Quick start:
  1. Edit titles.toml (next to this script): the path to your Neo Geo BIOS
     set (neogeo.zip) and, per title, the cartridge set and the disc rip.
     Or pass them with --bios PATH, --rom SET=PATH and --disc SET=PATH.
  2. Run:   python3 make_ngplus.py
  3. Copy the contents of out/mister/ to your MiSTer SD card root.  Your
     saves are untouched: the core asks the firmware for saves/NG+/<game>.sav
     itself, and nothing here writes there.

Inputs:
  cartridge set   a MAME-named zip, a Darksoft folder or zip, or a .neo file
  BIOS            neogeo.zip, or a folder with sp-u2.sp1 and/or uni-bios*.rom,
                  sfix.sfix and 000-lo.lo
  disc            the disc's .cue sheet (image files beside it), a .zip
                  holding the cue sheet and its images, or a .chd

Requirements: Python 3.11+ and ffmpeg on PATH (or CPSPLUS_FFMPEG set to the
binary).  macOS, Linux and Windows build the same bytes: python.org's
installer and a release ffmpeg build are all Windows needs, and if a build
ever did encode differently the pack hash check below would catch it.
A .chd disc also needs chdman on PATH (or NGPLUS_CHDMAN set to it); it comes
with MAME.
Disk: about 150 MB per title in out/, plus about 120 MB per title in work/
while building (deleted after a successful build unless --cache); a .chd
adds about 700 MB in work/ while that title builds.

Options:
  --list          show every title, its inputs and whether they are set
  --only SET      build just one title (repeatable)
  --check-inputs  check the ROM sets and disc rips and exit; builds nothing
  --no-verify     stage a pack even if its hash differs (not recommended:
                  the result is not the tested pack)
  --bios PATH, --rom SET=PATH, --disc SET=PATH
                  inputs without editing titles.toml (repeatable)
  --out DIR       card tree root (default out/mister)
  --cache         keep work/ after a successful build
  --clean-only    delete work/ and exit
"""
from __future__ import annotations

import sys

if sys.version_info < (3, 11):
    sys.exit(f"make_ngplus.py needs Python 3.11 or newer (it reads titles.toml with tomllib); "
             f"this is Python {sys.version.split()[0]}.")

for _stream in (sys.stdout, sys.stderr):    # a legacy code page must not turn
    try:                                    # a title into a UnicodeEncodeError
        _stream.reconfigure(errors="replace")
    except (AttributeError, ValueError):
        pass

import argparse
import hashlib
import json
import os
import shutil
from pathlib import Path, PureWindowsPath

# not resolve(): on Windows that rewrites a mapped drive (Z:\...) to its
# network form, which some tools cannot use
HERE = Path(os.path.abspath(__file__)).parent
sys.path.insert(0, str(HERE))

from ngplus import card, disc, pack, roms, title  # noqa: E402
from ngplus.cpk import tomlpaths                   # noqa: E402

TITLES = HERE / "titles"
WORK = HERE / "work"
CORES = HERE / "cores"
HASHES = HERE / "pack_hashes.json"


def user_path(value: str, base: Path) -> Path:
    """A path from titles.toml or the command line: absolute or relative to
    `base`, pasted Windows paths (with or without quotes) accepted."""
    v = tomlpaths.unquote(value)
    p = Path(v) if "\\" not in v else Path(*PureWindowsPath(v).parts)
    return p if p.is_absolute() else (base / p)


def load_config(args) -> tuple[Path | None, dict[str, dict[str, Path]]]:
    cfg_file = HERE / "titles.toml"
    raw = tomlpaths.load(cfg_file) if cfg_file.exists() else {}
    bios = user_path(raw["bios"], HERE) if raw.get("bios") else None
    inputs: dict[str, dict[str, Path]] = {}
    for key, entry in raw.items():
        if isinstance(entry, dict):
            inputs[key] = {k: user_path(v, HERE) for k, v in entry.items() if k in ("rom", "disc") and v}
    if args.bios:
        bios = user_path(args.bios, Path.cwd())
    for kind in ("rom", "disc"):
        for spec in getattr(args, kind) or []:
            setname, _, path = spec.partition("=")
            if not path:
                sys.exit(f"--{kind} wants SET=PATH, got {spec!r}")
            inputs.setdefault(setname, {})[kind] = user_path(path, Path.cwd())
    return bios, inputs


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def newest_core() -> Path | None:
    rbfs = sorted(CORES.glob("NeoGeoPlus_*.rbf"))
    return rbfs[-1] if rbfs else None


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--list", action="store_true")
    ap.add_argument("--only", action="append")
    ap.add_argument("--check-inputs", action="store_true")
    ap.add_argument("--no-verify", action="store_true")
    ap.add_argument("--bios")
    ap.add_argument("--rom", action="append")
    ap.add_argument("--disc", action="append")
    ap.add_argument("--out", type=Path, default=HERE.parent / "out" / "mister")
    ap.add_argument("--cache", action="store_true")
    ap.add_argument("--clean-only", action="store_true")
    a = ap.parse_args()

    if a.clean_only:
        shutil.rmtree(WORK, ignore_errors=True)
        print(f"removed {WORK}")
        return 0

    titles = title.available(TITLES)
    hashes = json.loads(HASHES.read_text(encoding="utf-8")) if HASHES.exists() else {}
    bios, inputs = load_config(a)
    if a.only:
        unknown = set(a.only) - {t.set for t in titles}
        if unknown:
            sys.exit(f"unknown title(s): {', '.join(sorted(unknown))} (see --list)")
        titles = [t for t in titles if t.set in a.only]

    if a.list:
        print(f"BIOS: {bios or 'not set'}")
        for t in titles:
            got = inputs.get(t.set, {})
            print(f"{t.set:10s} {t.name}")
            print(f"    rom   {got.get('rom', 'not set')}")
            print(f"    disc  {got.get('disc', 'not set')}   ({t.disc_name})")
        return 0

    core = newest_core()
    if not a.check_inputs and core is None:
        sys.exit(f"no NG+ core (NeoGeoPlus_*.rbf) in {CORES}")
    if bios is None:
        sys.exit("set the Neo Geo BIOS set: bios = \"...\" in titles.toml, or --bios PATH")

    failed, built, skipped = [], [], []
    for t in titles:
        got = inputs.get(t.set, {})
        if "rom" not in got or "disc" not in got:
            skipped.append(t.set)
            continue
        print(f"\n{t.set}: {t.name}")
        d = None
        try:
            info = t.romset()
            game = roms.read_game(got["rom"], info)
            bios_roms = roms.read_bios(bios, info)
            files = [c for c in bios_roms.checks if not c.startswith("note:")]
            print(f"  ROMs: {len(game.checks)} checks passed ({game.source.split(':', 1)[0]} layout); "
                  f"BIOS: {len(files)} files")
            for c in bios_roms.checks:
                if c.startswith("note:"):
                    print(f"  {c}")
            d = disc.Disc(got["disc"], work=WORK)
            for n in t.used_tracks():
                disc.verified_audio(d, n, t.disc_tracks[n])
            print(f"  disc: {len(t.used_tracks())} audio tracks match")
            if a.check_inputs:
                built.append(t.set)
                continue

            pk = WORK / "packs" / f"{t.set}.cpk"
            print("  pack:")
            pack.build(t, lambda n: disc.verified_audio(d, n, t.disc_tracks[n]), pk,
                       log=lambda s: print("  " + s))
            digest = sha256(pk)
            if digest != hashes.get(t.set):
                want = hashes.get(t.set)
                msg = (f"pack hash {digest[:16]}... differs from the published {want[:16]}..." if want else
                       f"pack hash {digest[:16]}...: this title has no published hash yet")
                if not a.no_verify:
                    raise ValueError(msg + (" (a different ffmpeg ADX encoder?" if want else " (") +
                                     "  --no-verify stages it anyway)")
                print("  WARNING: " + msg)
            else:
                print("  pack verified against the published hash")
            m = card.write_title(a.out, t, game, bios_roms, pk.read_bytes(), card.rbf_base(core))
            print(f"  image: games/{card.CORE}/{t.set}.nga ({m['size'] / 2**20:.1f} MiB)")
            built.append(t.set)
        except (ValueError, FileNotFoundError, OSError) as e:
            print(f"  FAILED: {e}")
            failed.append(t.set)
        finally:
            if d:
                d.close()                  # a CHD's converted image goes now, not at the end

    if built and not a.check_inputs:
        card.install_core(a.out, core)
        print(f"\ncore: {card.LAUNCHER_FOLDER}/cores/{core.name}")
        if not a.cache:
            shutil.rmtree(WORK, ignore_errors=True)
    print(f"\n{'checked' if a.check_inputs else 'built'}: {', '.join(built) or 'none'}")
    if skipped:
        print(f"skipped (inputs not set): {', '.join(skipped)}")
    if failed:
        print(f"failed: {', '.join(failed)}")
    if built and not a.check_inputs:
        print(f"copy the contents of {a.out} to your MiSTer SD card root")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
