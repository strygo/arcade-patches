"""Prepare FFmpeg only when the recipient requests music generation."""
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent


def prepare():
    sys.path.insert(0, str(HERE/'sound/tools'))
    import ffmpeg_runtime
    return ffmpeg_runtime.resolve('ffmpeg')
