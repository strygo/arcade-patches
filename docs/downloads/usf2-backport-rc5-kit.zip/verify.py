"""Independent final ROM/MRA/CPK checks, usable outside the source kit."""
import json
import copy
from pathlib import Path
import struct
import xml.etree.ElementTree as ET
import zipfile
import stock_mame
from payload import require, sha
from nsp import file_sha
from policy import check_mras, native_name, platforms_for


def verify_archive(path, record):
    """Check exact ROM contents independently of ZIP compressor/version."""
    with zipfile.ZipFile(path) as archive:
        names = archive.namelist()
        require(len(names) == len(set(names)), 'Duplicate ROM ZIP member')
        require(set(names) == set(record['members']), 'Final ROM member inventory differs')
        files = {}
        for member, row in record['members'].items():
            require(Path(member).name == member and '\\' not in member, 'Non-flat ROM archive')
            require(archive.getinfo(member).file_size == row['size'], 'Final ROM member size differs: '+member)
            data = archive.read(member)  # Also verifies the ZIP CRC.
            require(sha(data) == row['sha256'], 'Final ROM member differs: '+member)
            files[member] = data
    return files


def verify_stock_archive(path, name, record):
    with zipfile.ZipFile(path) as archive:
        names = archive.namelist()
        require(len(names) == len(set(names)), 'Duplicate stock MAME ZIP member')
        expected = stock_mame.sizes(record['region'])
        require(set(names) == set(expected), 'Stock MAME member inventory differs')
        require(all(archive.getinfo(n).file_size == size for n,size in expected.items()),
                'Stock MAME member size differs')
        packed = {n:archive.read(n) for n in names}
    files = stock_mame.unpack(packed, record['region'], name.endswith('4'))
    require(set(files) == set(record['members']), 'Recovered native member inventory differs')
    for member,row in record['members'].items():
        require(len(files[member]) == row['size'] and sha(files[member]) == row['sha256'],
                'Stock MAME native member differs: '+member)
    return files


def assemble(root, members, cpk, flag, arrange):
    import mra_assembly as mapper
    root = copy.deepcopy(root)
    root.find('rbf').text = 'jtcps2'
    node = root.find("./rom[@index='0']")
    patches = node.findall('patch')
    for p in patches:node.remove(p)
    if arrange:
        part = node.find("part[@name='usf2_arrange.cpk']")
        require(part is not None and part.get('zip') == '/CPS+/usf2_arrange.zip', 'Wrong CPK reference')
        node.remove(part)
        padding = node.findall('part[@repeat]')
        require(len(padding) <= 1, 'Unexpected CPK alignment data')
        for p in padding:node.remove(p)
    native = mapper.assemble(root, members)
    if flag is not None:require(native[64+(flag^1)] == 0, 'ROM capability default differs')
    if not arrange:
        require(not patches, 'Ordinary MRA patches the ROM'); return native
    require(flag is not None,'CPS+ capability address missing')
    offset = (len(native)+1023)//1024*1024; pad = offset-len(native)
    require(len(padding) == int(bool(pad)) and (not pad or
        (padding[0].get('repeat') == str(pad) and bytes.fromhex(padding[0].text) == b'\0')),
        'CPK padding differs')
    expected = {8:struct.pack('<HH',offset//1024,pad),64+(flag^1):b'\x01'}
    actual = {int(p.get('offset'),0):bytes.fromhex(p.text) for p in patches}
    require(len(patches) == 2 and actual == expected, 'Exclusive CPK pointer/capability patches differ')
    image = bytearray(native+bytes(pad)+cpk)
    for at,b in actual.items():image[at:at+len(b)] = b
    return bytes(image)


def verify_output(root, kit, selected, platforms):
    import mra_assembly as mapper
    import cps2_code_guard
    results = {}
    for name, record in sorted(selected.items()):
        members = None
        guarded = False
        archive_digest = None
        archive_digests = {}
        selected_platforms=platforms_for(name,platforms)
        require(selected_platforms, 'Profile has no output in the requested shipping matrix')
        stock_name = None
        for platform in selected_platforms:
            if platform == 'darksoft':
                from darksoft import profile, unpack, native_menu
                stock_name,_ = stock_mame.destination(record['region'])
                mapping = profile(stock_name)
                folder = root/'darksoft/games'/('usf2_' + record['region'])
                blobs = {p.name:p.read_bytes() for p in folder.iterdir() if p.is_file()}
                receipt = json.loads((root/'darksoft/receipts'/('usf2_' + record['region'] + '.json')).read_text())
                require({n:{'size':len(b),'sha256':sha(b)} for n,b in blobs.items()} == receipt['files'],
                        'Darksoft file receipt differs')
                require(blobs.pop('NAME') == native_menu('usf2-backport', record['region']).encode('ascii'), 'Darksoft menu differs')
                packed = unpack(blobs, mapping)
                firmware = (root/'darksoft/verification/dl-1425.bin').read_bytes()
                require(sha(firmware) == record['members']['dl-1425.bin']['sha256'], 'DSP verification firmware differs')
                packed['dl-1425.bin'] = firmware
                recovered = stock_mame.unpack(packed,record['region'],False)
                require(set(recovered) == set(record['members']) and all(
                    len(recovered[n]) == r['size'] and sha(recovered[n]) == r['sha256']
                    for n,r in record['members'].items()), 'Darksoft recovered native bytes differ')
                if members is not None:require(recovered == members, 'Darksoft/platform ROMs differ')
                members = recovered
                # Audit the recovered program/key with the guard this kit already ships for its other outputs.
                import io, zipfile
                stream = io.BytesIO()
                with zipfile.ZipFile(stream, 'w') as archive:
                    for member in sorted({n for n,_,_,_ in mapping['files']['flash.02']} | {mapping['key']}):
                        archive.writestr(member, packed[member])
                stream.seek(0)
                report = cps2_code_guard.check_archive(stream)
                require(report is not None and report['policy'] == 'encrypted-ROM-code',
                        'Darksoft requires the original encrypted program/key')
                guarded = True
                continue
            if platform == 'mame' and kit.get('mame_layout') == 'stock-hsf2-v1':
                stock_name,_ = stock_mame.destination(record['region'])
                path = root/'mame'/(stock_name+'.zip')
                files = verify_stock_archive(path,name,record)
            else:
                path = root/platform/('games/mame/' if platform == 'mister' else '')/(native_name(name)+'.zip' if platform in ('hbmame','mister') else name+'.zip')
                files = verify_archive(path, record)
            digest = file_sha(path)
            if archive_digest is None:archive_digest = digest
            # Stock HSF2 and native USF2 ZIPs have different member layouts.
            # Compare their independently recovered native bytes below.
            archive_digests[platform] = digest
            if members is not None:require(files == members, 'Platform ROMs differ')
            members = files
            if not guarded:
                cps2_code_guard.check_archive(path); guarded = True
        regions = mapper.mame_regions_from_ops(record['mame_load_ops'],
                                      {k:v for k,v in members.items() if k != 'dl-1425.bin'})
        mras = []
        if 'mister' in selected_platforms:
            check_mras(name,record['mras'])
            cpk=b''
            if name.endswith('8'):
                pack_zip = root/'mister/games/CPS+/usf2_arrange.zip'
                cpk_files = mapper.read_archive(pack_zip)
                require(set(cpk_files) == {'usf2_arrange.cpk'}, 'Unexpected music ZIP')
                cpk = cpk_files['usf2_arrange.cpk']
                require(sha(cpk) == kit['cpk_sha256'] and cpk[:4] == b'CP2A', 'Final music differs')
            for row in record['mras']:
                mra = ET.parse(root/'mister'/row['destination']).getroot()
                require(mra.find("./rom[@index='0']").get('zip') ==
                    '/mame/'+native_name(name)+'.zip|qsound.zip|qsound_hle.zip', 'Native ROM dependency differs')
                native = assemble(mra, members, cpk, record['capability_address'], row['arrange'])
                require(len(native) == row['assembled_bytes'] and sha(native) == row['assembled_sha256'],
                        'Final assembled MiSTer image differs: ' + name)
                flag = record['capability_address']
                if flag is not None:
                    actual = native[64+(flag^1)]
                    require(actual == int(row['arrange']), 'Exclusive CPS+ capability flag differs')
                require(mra.findtext('rbf') == ('jtcps2-cpsplus' if row['arrange'] else 'jtcps2'),
                        'Core binding differs')
                require(bytes.fromhex(mra.find("./rom[@index='2']/part").text) ==
                        bytes.fromhex(kit['factory_eeprom'][record['region']]), 'Factory EEPROM differs')
                if row['arrange']:
                    offset, pad = struct.unpack_from('<HH', native, 8)
                    require(native[offset*1024:] == cpk, 'CPK pointer/contents differ')
                # Independently verify the base regions even when the only
                # shipped launcher is CPS+. Its two patches do not replace
                # the underlying key, program, PCM or graphics mapping.
                base_root=copy.deepcopy(mra)
                base_rom=base_root.find("./rom[@index='0']")
                for child in list(base_rom):
                    if child.tag=='patch' or child.tag=='part' and (child.get('repeat') or child.get('name')=='usf2_arrange.cpk'):
                        base_rom.remove(child)
                base_root.find('rbf').text='jtcps2'
                base_image=mapper.assemble(base_root,members)
                require(sha(base_image)==record['native_assembled_sha256'],'Base native image differs')
                # Compare the complete native image with independent MAME
                # loading, not another copy of the MRA producer algorithm.
                start = 64
                program = base_image[start:start+0x400000]
                require(program == mapper.swap(regions['maincpu']), 'MAME/MRA program mapping differs')
                audio,pcm,gfx,dsp = [int.from_bytes(base_image[i:i+2],'little')*1024 for i in range(0,8,2)]
                body = base_image[64:]
                require((audio,pcm,gfx,dsp) == (0x400000,0x440000,
                    0x440000+len(regions['qsound']),0x2440000+len(regions['qsound'])) and
                    len(body) == dsp+8192, 'MiSTer memory offsets/capacities differ')
                expected = {'audiocpu':regions['audiocpu'][:0x8000]+regions['audiocpu'][0x10000:0x48000],
                    'qsound':regions['qsound'],'gfx':regions['gfx'],'firmware':members['dl-1425.bin'][:8192]}
                actual = {'audiocpu':body[audio:pcm],'qsound':body[pcm:gfx],
                    'gfx':body[gfx:dsp],'firmware':body[dsp:]}
                require(actual == expected and base_image[44:64] == regions['key'][:20],
                    'Independent MAME/MRA key, Z80, sample, graphics or DSP mapping differs')
                mras.append(dict(arrange=row['arrange'],image_sha256=sha(native)))
            if name.endswith('8'):
                core = root/'mister/_Arcade/cores'/kit['core']['filename']
                require(file_sha(core) == kit['core']['sha256'], 'Approved CPS+ core differs')
        results[name] = dict(archive_sha256=archive_digest,
            platform_archive_sha256=archive_digests,
            regions={r:sha(b) for r,b in regions.items()},mras=mras)
        if stock_name:
            results[name]['stock_mame_set'] = stock_name
            results[name]['native_archive_sha256'] = record['archive_sha256']
        elif archive_digest != record['archive_sha256']:
            results[name]['candidate_archive_sha256'] = record['archive_sha256']
    return dict(schema=1,status='verified_reconstruction_outputs',profiles=results,
                platforms=list(platforms),hardware_review=False,public_release=False)
