#!/usr/bin/env python3
"""Independently assemble USF2 MRAs and compare their regions with MAME loads.

This file also runs inside the exported private kit without repository imports.
Only the explicit USF2 MRA/MAME grammar is accepted; unsupported tags fail closed.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
from pathlib import Path
import xml.etree.ElementTree as ET
import zipfile
import zlib


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read_archive(path):
    with zipfile.ZipFile(path) as archive:
        require(len(archive.namelist()) == len(set(archive.namelist())), 'Duplicate ZIP member')
        require(all(Path(n).name == n for n in archive.namelist()), 'Non-flat ROM archive')
        return {n: archive.read(n) for n in archive.namelist()}


def swap(data):
    require(len(data) % 2 == 0, 'Odd word-swap size')
    result = bytearray(len(data))
    result[0::2], result[1::2] = data[1::2], data[0::2]
    return bytes(result)


def mame_regions(definition, files):
    """Interpret ROM_REGION/LOAD/CONTINUE, independently of the MRA generator."""
    regions, loads = {}, []
    region = None
    cursor = 0
    source = b''
    kind = None
    sizes = {'CODE_SIZE': 0x400000, 'QSOUND_SIZE': 0x50000}
    for line in definition.splitlines():
        if 'ROM_REGION(' in line:
            match = re.search(r'ROM_REGION\(\s*(\w+),\s*"(\w+)"', line)
            require(match is not None, 'Unsupported MAME region')
            value, region = match.groups()
            size = sizes[value] if value in sizes else int(value, 0)
            require(region not in regions, 'Duplicate MAME region')
            regions[region] = bytearray(size)
        elif 'ROM_LOAD' in line:
            match = re.search(r'(ROM_LOAD\w*)\(\s*"([^"]+)",\s*(0x\w+),\s*(0x\w+),\s*CRC\((\w+)\)\s*SHA1\((\w+)\)', line)
            require(match is not None and region is not None, 'Unsupported MAME load')
            kind, name, offset, size, crc, digest = match.groups()
            require(name in files, 'Missing MAME member ' + name)
            source = files[name]
            require(f'{zlib.crc32(source) & 0xffffffff:08x}' == crc and
                    hashlib.sha1(source).hexdigest() == digest, 'MAME member identity differs: ' + name)
            cursor = 0
            loads.append(name)
            place(regions[region], source[:int(size, 0)], int(offset, 0), kind)
            cursor = int(size, 0)
        elif 'ROM_CONTINUE(' in line:
            match = re.search(r'ROM_CONTINUE\(\s*(0x\w+),\s*(0x\w+)', line)
            require(match is not None, 'Unsupported MAME continuation')
            offset, size = map(lambda s: int(s, 0), match.groups())
            place(regions[region], source[cursor:cursor + size], offset, kind)
            cursor += size
        elif any(tag in line for tag in ('ROM_RELOAD', 'ROM_FILL', 'ROM_COPY')):
            raise ValueError('Unsupported MAME load operation')
    require(set(regions) == {'maincpu', 'gfx', 'audiocpu', 'qsound', 'key'}, 'Unexpected MAME regions')
    require(set(loads) == set(files) and len(loads) == len(files), 'Archive has missing or unused ROM members')
    return {name: bytes(data) for name, data in regions.items()}


def place(region, data, offset, kind):
    require(kind in ('ROM_LOAD', 'ROM_LOAD16_WORD_SWAP', 'ROM_LOAD64_WORD'), 'Unsupported MAME load kind')
    if kind == 'ROM_LOAD64_WORD':
        require(len(data) % 2 == 0 and offset + (len(data) // 2 - 1) * 8 + 2 <= len(region), 'GFX load overflow')
        region[offset:offset + len(data) * 4:8] = data[0::2]
        region[offset + 1:offset + len(data) * 4:8] = data[1::2]
    else:
        require(offset + len(data) <= len(region), 'MAME region overflow')
        region[offset:offset + len(data)] = swap(data) if kind.endswith('WORD_SWAP') else data


def part_bytes(part, files):
    require(part.tag == 'part' and set(part.attrib) <= {'name', 'crc', 'length', 'map'}, 'Unsupported MRA part')
    name = part.get('name')
    if name is None:
        require(not part.attrib, 'Inline part attributes are unsupported')
        return bytes.fromhex(part.text or '')
    require(name in files, 'Missing MRA member ' + name)
    data = files[name]
    require(part.get('crc') == f'{zlib.crc32(data) & 0xffffffff:08x}', 'MRA CRC differs: ' + name)
    length = int(part.get('length', str(len(data))), 0)
    require(0 < length <= len(data), 'Invalid MRA length')
    return data[:length]


def interleave(node, files):
    """Apply Main_MiSTer's nibble map, rather than using known USF2 lane order."""
    require(set(node.attrib) == {'output'}, 'Unsupported interleave attributes')
    unit = int(node.get('output')) // 8
    require(unit in (2, 8) and list(node), 'Unsupported interleave width')
    parts = []
    size = None
    used = set()
    for part in node:
        data = part_bytes(part, files)
        mapping = int(part.get('map', '1'), 16)
        nibbles = [(mapping >> (4 * i)) & 15 for i in range(unit)]
        first = next((i for i, value in enumerate(nibbles) if value), None)
        require(first is not None and mapping >> (unit * 4) == 0, 'Invalid interleave map')
        offsets, gaps = [], 0
        for value in nibbles[first:]:
            if value:
                offsets.append(first + value - 1 + gaps)
            else:
                gaps += 1
        require(len(data) % len(offsets) == 0 and all(o < unit for o in offsets), 'Invalid interleave size/map')
        require(len(set(offsets)) == len(offsets) and not used.intersection(offsets), 'Overlapping MRA lanes')
        used.update(offsets)
        length = len(data) // len(offsets) * unit
        require(size in (None, length), 'Unequal MRA lane lengths')
        size = length
        parts.append((data, offsets))
    require(used == set(range(unit)), 'Missing MRA lanes')
    result = bytearray(size)
    for data, offsets in parts:
        for index, offset in enumerate(offsets):
            result[offset::unit] = data[index::len(offsets)]
    return bytes(result)


def assemble(root, files):
    require(root.findtext('rbf') == 'jtcps2', 'Stock jtCPS2 core required')
    node = root.find("./rom[@index='0']")
    require(node is not None and node.get('address') == '0x30000000', 'Missing standard ROM download')
    result = bytearray()
    for child in node:
        require(child.tag in ('part', 'interleave'), 'Unsupported ROM operation')
        result.extend(part_bytes(child, files) if child.tag == 'part' else interleave(child, files))
    return bytes(result)


def verify_mra(mra, definition, archive, firmware, contract):
    files = read_archive(archive)
    fw = read_archive(firmware)
    required = contract['firmware']
    require(set(fw) == {required['member']} and len(fw[required['member']]) == required['full_bytes'] and
            sha(fw[required['member']]) == required['full_sha256'], 'Canonical DSP firmware identity differs')
    require(files.get(required['member']) == fw[required['member']], 'Complete archive DSP differs from canonical fallback')
    mame = mame_regions(definition.read_text(), {n: d for n, d in files.items() if n != required['member']})
    name = archive.stem
    root = ET.parse(mra).getroot()
    require(root.findtext('setname') == name, 'MRA set identity differs')
    rom0 = root.find("./rom[@index='0']")
    require(rom0.get('zip') == name + '.zip|qsound.zip', 'Unexpected MRA archive search path')
    loaded_names = [p.get('name') for p in rom0.iter('part') if p.get('name')]
    require(set(loaded_names) == set(files) and len(loaded_names) == len(files), 'MRA omitted or duplicated members')
    image = assemble(root, {**files, **fw})
    header = image[:44]
    template = bytes.fromhex(contract['header_template_hex'])
    require(len(template) == 44 and header[8:] == template[8:], 'CPS2 header flags differ')
    starts = [int.from_bytes(header[i:i + 2], 'little') * 1024 for i in range(0, 8, 2)]
    audio, pcm, gfx, dsp = starts
    require(starts == sorted(starts) and audio == 0x400000 and pcm - audio == 0x40000 and
            gfx - pcm in (0x400000, 0x800000) and dsp - gfx == 0x2000000,
            'CPS2 header region offsets/capacities differ')
    body = image[44:]
    require(len(body) == 20 + dsp + 8192, 'Assembled ROM body length differs')
    # Key is streamed separately and excluded from the core's KB offsets.
    regions = {'key': body[:20], 'maincpu': body[20:20 + audio],
               'audiocpu': body[20 + audio:20 + pcm], 'qsound': body[20 + pcm:20 + gfx],
               'gfx': body[20 + gfx:20 + dsp], 'firmware': body[20 + dsp:]}
    expected = {'key': mame['key'][:20], 'maincpu': swap(mame['maincpu']),
                'audiocpu': mame['audiocpu'][:0x8000] + mame['audiocpu'][0x10000:0x48000],
                'qsound': mame['qsound'], 'gfx': mame['gfx'],
                'firmware': fw['dl-1425.bin'][:8192]}
    require(all(regions[n] == data for n, data in expected.items()), 'MRA assembly differs from independent MAME region loading')
    region = 'us' if name.startswith('usf2t') else 'jp'
    eeprom = bytes.fromhex(root.find("./rom[@index='2']/part").text)
    require(sha(eeprom) == contract['eeprom'][region]['sha256'] and len(eeprom) == 128, 'Regional factory EEPROM differs')
    require(root.find("./nvram[@index='2']").get('size') == '128', 'EEPROM persistence declaration differs')
    require(bytes.fromhex(root.find("./rom[@index='1']/part").text) == bytes.fromhex('0080'), 'Core switch defaults differ')
    return {'set': name, 'mra_sha256': sha(mra.read_bytes()), 'archive_sha256': sha(archive.read_bytes()),
            'definition_sha256': sha(definition.read_bytes()), 'assembled_sha256': sha(image),
            'assembled_bytes': len(image), 'header_hex': header.hex(), 'eeprom_sha256': sha(eeprom),
            'regions': {n: {'bytes': len(d), 'sha256': sha(d)} for n, d in regions.items()},
            'all_archive_members_loaded_once': True, 'independent_mame_region_match': True,
            'hardware_review': False}


def supported_profiles(names):
    names=set(names)
    require(names in ({'usf2t4','usf2t8','usf2j4','usf2j8'}, {'usf2t8','usf2j8'}),
            'Complete USA/Japan four-profile or 8 MiB-only matrix required')
    return names


def verify_pack(pack):
    if (Path(pack) / 'private-mister.json').is_file():
        import sys
        sys.path.insert(0, str(Path(pack).resolve()))
        import private_mister
        with private_mister.qualified_view(pack) as source:
            return verify_pack(source)
    manifest = json.loads((pack / 'manifest.json').read_text())
    require(manifest['hardware_review'] is False and manifest['status'] in
            ('private_playtest', 'layout_development_only'), 'Unexpected pack claims')
    for name, digest in manifest['files'].items():
        path = pack / name
        require(path.resolve().is_relative_to(pack.resolve()) and path.is_file() and sha(path.read_bytes()) == digest,
                'Pack member identity differs: ' + name)
    results = {}
    for name, row in manifest['profiles'].items():
        result = verify_mra(pack / row['mra'], pack / row['definition'], pack / row['archive'],
                            pack / 'SD/_Arcade/mame/qsound.zip', manifest['layout_contract'])
        require(result == row['verification'], 'Pack reconstruction receipt differs: ' + name)
        source_files = read_archive(pack / row['archive'])
        native = mame_regions((pack / row['definition']).read_text(), {n: d for n, d in source_files.items() if n != 'dl-1425.bin'})
        for filename, bank in row['hardware_banks'].items():
            data = (pack / 'hardware' / name / filename).read_bytes()
            require(len(data) == bank['bytes'] and sha(data) == bank['sha256'], 'Hardware bank identity differs')
            if bank['region'] == 'gfx':
                start = bank['bank'] * 0x1000000 + bank['lane'] * 2
                expected = bytearray(0x400000)
                expected[0::2] = native['gfx'][start:start + 0x1000000:8]
                expected[1::2] = native['gfx'][start + 1:start + 0x1000000:8]
                require(data == bytes(expected), 'Physical graphics lane reconstruction differs')
            else:
                start = bank['bank'] * 0x400000
                require(swap(data) == native['qsound'][start:start + 0x400000], 'Physical sample bank reconstruction differs')
        eeprom = (pack / 'hardware' / name / 'factory-eeprom.bin').read_bytes()
        require(sha(eeprom) == result['eeprom_sha256'], 'Physical factory EEPROM differs')
        results[name] = result
    supported_profiles(results)
    pinned=json.loads((pack/'profiles.json').read_text())
    require(set(results)==set(pinned['profiles']), 'Manifest and pinned profile scope differ')
    if 'arrangement' in manifest:
        import verify_usf2_arrange
        verify_usf2_arrange.verify(pack,manifest,assemble,read_archive)
    return results


def self_test():
    data = {'a': bytes((0x10, 0x11, 0x20, 0x21)), 'b': bytes((0x30, 0x31, 0x40, 0x41)),
            'c': bytes((0x50, 0x51, 0x60, 0x61)), 'd': bytes((0x70, 0x71, 0x80, 0x81))}
    def node(maps, output=16):
        root = ET.Element('interleave', output=str(output))
        for name, mapping in maps:
            ET.SubElement(root, 'part', name=name, crc=f'{zlib.crc32(data[name]):08x}', map=mapping)
        return root
    require(interleave(node([('a', '12')]), data) == bytes((0x11, 0x10, 0x21, 0x20)), 'PCM map self-test')
    require(interleave(node([('a', '21')]), data) == data['a'], 'Main map self-test')
    gfx = interleave(node([('a', '00000021'), ('b', '00002100'),
                           ('c', '00210000'), ('d', '21000000')], 64), data)
    require(gfx == bytes((0x10, 0x11, 0x30, 0x31, 0x50, 0x51, 0x70, 0x71,
                          0x20, 0x21, 0x40, 0x41, 0x60, 0x61, 0x80, 0x81)), 'GFX lane self-test')
    target = bytearray(16)
    for lane, name in enumerate(('a', 'b', 'c', 'd')):
        place(target, data[name], lane * 2, 'ROM_LOAD64_WORD')
    require(bytes(target) == gfx, 'Independent MAME 64-bit load differs')
    target = bytearray(4)
    place(target, data['a'], 0, 'ROM_LOAD16_WORD_SWAP')
    require(bytes(target) == bytes((0x11, 0x10, 0x21, 0x20)), 'Independent MAME word swap differs')
    negatives = [node([('a', '21'), ('b', '21')]), node([('a', '10')]), node([('a', '31')])]
    for bad in negatives:
        try:
            interleave(bad, data)
        except ValueError:
            continue
        raise AssertionError('Invalid lane map accepted')
    supported_profiles({'usf2t8','usf2j8'})
    supported_profiles({'usf2t4','usf2t8','usf2j4','usf2j8'})
    for bad in ({'usf2t8'}, {'usf2t4','usf2j4'}, {'usf2t8','usf2j8','foreign'}):
        try:supported_profiles(bad)
        except ValueError:pass
        else:raise AssertionError('Incomplete or foreign profile matrix accepted')
    print('PASS independent MRA mapper, swaps, profile matrices and malformed/overlapping/missing lanes')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--pack', type=Path)
    parser.add_argument('--self-test', action='store_true')
    args = parser.parse_args()
    if args.self_test:
        self_test()
    if args.pack:
        results = verify_pack(args.pack)
        print('PASS independent MRA/MAME region reconstructions: ' + ', '.join(sorted(results)))
    require(args.self_test or args.pack, 'Specify --pack or --self-test')


if __name__ == '__main__':
    main()
