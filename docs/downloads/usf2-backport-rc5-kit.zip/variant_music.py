"""Portable, pinned Switch ending additions to the qualified 65-track pack."""
import copy,hashlib,json,shutil,sys,tempfile
from pathlib import Path
from nsp import authenticate,file_sha,open_program,toolset
from payload import require

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'sound'if(HERE/'sound/pack').is_dir()else HERE.parents[2]/'cpsplus'))
from pack import adxcodec,ssf2_family
from pack.build_usf2_remix import read_switch_opus,decode_pcm,align_loop,bake_join,run,DEFAULT_GAIN
from pack.format import PackReader,PackWriter,TrackMeta,TriggerRow,VERB_PLAY,CODEC_ADX
from pack.switch_source import extract


def obtain(nsp,keys,pin,config,work,tools=None,pinning=False):
    """A missing cache reconstructs from the authenticated regional NSP/XCI."""
    work=Path(work);work.mkdir(parents=True,exist_ok=True)
    found=authenticate(nsp,pin);tools=tools or toolset(work/'tools')
    paths={r['identity']:work/Path(r['source']).name for r in config['tracks']}
    missing=[r for r in config['tracks']if not paths[r['identity']].is_file()or
        not r.get('sha256')or file_sha(paths[r['identity']])!=r['sha256']]
    if missing:
        with open_program(nsp,pin,work)as(program,ticket,_):
            temp=program.parent
            # Parent-directory extraction is portable on Windows too.
            for parent in sorted({str(Path(r['source']).parent).replace('\\','/')for r in missing}):
                dest=temp/'streams';dest.mkdir(exist_ok=True)
                extract(tools['nstool'],keys,program,ticket,
                    '/1/nativeNXx64/app/sound/bgm/wav/'+parent,dest)
                for r in missing:
                    if str(Path(r['source']).parent).replace('\\','/')!=parent:continue
                    matches=list(dest.rglob(Path(r['source']).name));require(len(matches)==1,'Missing or ambiguous ending stream')
                    shutil.copyfile(matches[0],paths[r['identity']])
    for r in config['tracks']:
        digest=file_sha(paths[r['identity']])
        if pinning:r['sha256']=digest
        require(digest==r['sha256'],'Ending source stream changed')
    return paths,tools


def append(source,out,config,paths,decoder,work):
    require(file_sha(source)==config['base_cpk_sha256'],'Qualified base music differs')
    reader=PackReader(source);require(reader.crc_check()==(True,True)and len(reader.tracks)==65,'Base pack is incomplete')
    writer=PackWriter(ssf2_family.PROTOCOL,title='Ultra SFII backport with variant endings',
        trigger_rows=reader.header.trigger_rows,default_rate=reader.header.default_rate,
        xfade_samples=reader.header.xfade_samples)
    writer.triggers=copy.deepcopy(reader.triggers)
    for i,meta in enumerate(reader.tracks):writer.add_track(reader.read_track(i),copy.deepcopy(meta))
    rows=[];work=Path(work);work.mkdir(parents=True,exist_ok=True)
    for r in config['tracks']:
        path=paths[r['identity']];require(file_sha(path)==r['sha256'],'Ending source changed before encoding')
        command=r['command'];require(writer.triggers[command].verb==0,'Ending command already has an owner')
        opus=read_switch_opus(path);require(opus.channels==2,'Stereo source required')
        with tempfile.TemporaryDirectory(dir=work)as tmp:pcm=decode_pcm(decoder,opus,Path(tmp))
        meta=TrackMeta(sample_rate=48000,channels=2,codec=CODEC_ADX,
            coef1=adxcodec.calc_coeffs(adxcodec.DEFAULT_CUTOFF,48000)[0],
            coef2=adxcodec.calc_coeffs(adxcodec.DEFAULT_CUTOFF,48000)[1],name=path.stem,source='USF2:'+r['source'])
        if opus.loop_end:
            start,end=align_loop(opus.loop_start,opus.loop_end,opus.total)
            meta.loop_start_sample,meta.loop_end_sample=start,end
            meta.loop_start_byte=adxcodec.samples_to_stream_byte(start,2);meta.loop_end_byte=adxcodec.samples_to_stream_byte(end,2)
        # Frame alignment shifts Ken's loop head by eleven samples and creates
        # a measured 7,871-count step. Use the established 1,024-sample tail
        # blend, preserving the source loop times and every earlier sample.
        blend=1024 if r['identity']==18 else 0
        if blend:pcm=bake_join(pcm,start,end,blend)
        stream=adxcodec.encode(pcm,2,48000)
        if opus.loop_end:stream=stream[:meta.loop_end_byte]
        track=writer.add_track(stream,meta);writer.set_trigger(command,TriggerRow(verb=VERB_PLAY,track=track,gain=DEFAULT_GAIN,suppress=1))
        rows.append(dict(identity=r['identity'],command=command,track=track,source=r['source'],source_sha256=r['sha256'],
            PCM_sha256=hashlib.sha256(pcm).hexdigest(),source_samples=opus.total,source_loop=[opus.loop_start,opus.loop_end],
            ADX_sha256=hashlib.sha256(stream).hexdigest(),ADX_bytes=len(stream),loop=[meta.loop_start_sample,meta.loop_end_sample],loop_tail_blend_samples=blend))
    writer.write(out);final=PackReader(out)
    require(final.crc_check()==(True,True)and len(final.tracks)==67,'Final pack is incomplete')
    for i in range(65):
        require(reader.read_track(i)==final.read_track(i),'An existing music stream changed')
        before=copy.copy(reader.tracks[i]);after=copy.copy(final.tracks[i]);before.data_offset=after.data_offset=0
        require(before==after,'An existing track loop/codec changed')
    additions={r['command']for r in config['tracks']}
    require(all(x.pack()==y.pack()for i,(x,y)in enumerate(zip(reader.triggers,final.triggers))if i not in additions),
        'Existing music routing changed')
    final.close();reader.close()
    report=dict(status='verified_source_variant_ending_tracks',base_cpk_sha256=config['base_cpk_sha256'],
        sha256=file_sha(out),tracks=rows,existing_65_streams_metadata_and_routes_preserved=True,hardware_review=False)
    Path(str(out)+'.variant.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n');return report
