"""Compiler-free recipient adapter; producer source builds remain separate."""
from fetch_switch_tools import SetupError, setup
