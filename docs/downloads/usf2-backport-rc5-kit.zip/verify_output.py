#!/usr/bin/env python3
"""Verify a relocated generated USF2 output directory."""
import argparse,json
from pathlib import Path
from verify import verify_output
from nsp import file_sha
from payload import require

if __name__ == '__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--root',type=Path,default=Path(__file__).resolve().parent)
    a=p.parse_args();kit=json.loads((a.root/'source-kit.json').read_text())
    report=json.loads((a.root/'verification.json').read_text());selected={n:kit['profiles'][n]for n in report['profiles']}
    require(verify_output(a.root,kit,selected,report['platforms'])==report,'Verification receipt differs')
    for name,digest in json.loads((a.root/'files.json').read_text()).items():
        require(file_sha(a.root/name)==digest,'Output file changed: '+name)
    print('PASS relocated exact ROM, independent MRA and CPK verification')
