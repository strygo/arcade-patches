"""Repack verified USF2 archives for the stock HSF2 loader without ROM edits."""
import argparse
import hashlib
import json
from pathlib import Path
import tempfile
import zipfile


PROGRAM = ('sfxj.03d', 'sfxj.04a', 'sfxj.05', 'sfxj.06b',
           'sfxj.07a', 'sfxj.08', 'sfx.09', 'usf2.10')


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def destination(region):
    require(region in ('us', 'jp'), 'Unsupported USF2 region')
    if region == 'us':
        return 'hsf2', ('hs2u.03', 'hs2u.04') + tuple(f'hs2.{i:02}' for i in range(5, 11))
    return 'hsf2j', ('hs2j.03c', 'hs2j.04b') + tuple(f'hs2j.{i:02}' for i in range(5, 11))


def sizes(region):
    name, program = destination(region)
    result = {n: 0x80000 for n in program}
    result.update({f'hs2.{i}m': 0x800000 for i in (13, 15, 17, 19)})
    result.update({'hs2.01': 0x20000, 'hs2.02': 0x20000, 'hs2.11m': 0x800000,
                   name + '.key': 20, 'dl-1425.bin': 24576})
    return result


def identify(path, profiles):
    with zipfile.ZipFile(path) as z:
        names = z.namelist()
        require(len(names) == len(set(names)), 'Duplicate input ZIP member')
        candidates = [(n, r) for n, r in profiles.items() if set(names) == set(r['members'])
                      and all(z.getinfo(m).file_size == v['size'] for m, v in r['members'].items())]
        require(candidates, 'This ZIP is not a supported complete USF2 RC1 output')
        files = {n: z.read(n) for n in names}
    matches = [(n, r) for n, r in candidates
               if all(sha(files[m]) == v['sha256'] for m, v in r['members'].items())]
    require(len(matches) == 1, 'USF2 source ROM hashes do not match the supported RC1 build')
    return *matches[0], files


def repack(files, region):
    name, program = destination(region)
    result = {target: files[source] for source, target in zip(PROGRAM, program)}
    for lane in range(4):
        result[f'hs2.{13 + lane * 2}m'] = b''.join(files[n] for n in (
            f'sfx.{13 + lane * 2}m', f'sfx.{14 + lane * 2}m',
            f'sfx.{21 + lane * 2}m', f'usf2.{29 + lane * 2}m'))
    for i in (1, 2):
        result[f'hs2.{i:02}'] = files[f'sfx.{i:02}']
    pcm = files['sfx.11m'] + files['sfx.12m']
    if 'usf2.13m' in files:
        pcm += files['usf2.13m'] + files['usf2.14m']
    else:
        # Preserve the 4 MiB address mask when the stock loader allocates 8 MiB.
        # Any upper-half access sees the same bytes as the original wrapped read.
        pcm *= 2
    result['hs2.11m'] = pcm
    result[name + '.key'] = files['ssf2xj.key']
    result['dl-1425.bin'] = files['dl-1425.bin']
    require({n: len(b) for n, b in result.items()} == sizes(region), 'Unexpected stock loader layout')
    return name, result


def unpack(files, region, compact):
    """Recover the native members for independent hash and region verification."""
    name, program = destination(region)
    require({n: len(b) for n, b in files.items()} == sizes(region), 'Wrong stock MAME member layout')
    result = {target: files[source] for target, source in zip(PROGRAM, program)}
    for lane in range(4):
        data = files[f'hs2.{13 + lane*2}m']
        for member, start, end in (
                (f'sfx.{13 + lane*2}m', 0, 0x200000),
                (f'sfx.{14 + lane*2}m', 0x200000, 0x300000),
                (f'sfx.{21 + lane*2}m', 0x300000, 0x400000),
                (f'usf2.{29 + lane*2}m', 0x400000, 0x800000)):
            result[member] = data[start:end]
    for i in (1, 2):
        result[f'sfx.{i:02}'] = files[f'hs2.{i:02}']
    pcm = files['hs2.11m']
    result['sfx.11m'], result['sfx.12m'] = pcm[:0x200000], pcm[0x200000:0x400000]
    if compact:
        require(pcm[:0x400000] == pcm[0x400000:], 'Compact PCM mirror differs')
    else:
        result['usf2.13m'], result['usf2.14m'] = pcm[0x400000:0x600000], pcm[0x600000:]
    result['ssf2xj.key'] = files[name + '.key']
    result['dl-1425.bin'] = files['dl-1425.bin']
    return result


def write_instructions(path, regions):
    lines = ['Ultra Street Fighter II for stock MAME', '',
             'Keep these ZIPs in their own folder, separate from original HSF2 ROMs.',
             'From your MAME folder, launch the selected region:', '']
    for region in sorted(set(regions)):
        name, _ = destination(region)
        lines.append(f'  mame {name} -rompath "FULL_PATH_TO_THIS_MAME_FOLDER" -nvram_directory nvram-usf2')
    lines += ['', 'MAME shows the Hyper Street Fighter II name and checksum warnings.',
              'Accept the warnings to run Ultra Street Fighter II. The ZIPs contain',
              'verified USF2 ROMs packed for an existing MAME loader.',
              'If a frontend hides the game after auditing, use the command above.',
              'Native QSound music plays in MAME. The arranged music is a MiSTer feature.',
              'In Test Mode, open ULTRA CONFIGURATION and change SOUND EFFECTS',
              'with left/right to select MODERN or CLASSIC. Exit normally to save.',
              'These ZIPs are for stock MAME.', '']
    path.write_text('\n'.join(lines), encoding='utf-8')


def write_zip(path, files):
    with zipfile.ZipFile(path, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for name, data in sorted(files.items()):
            entry = zipfile.ZipInfo(name, (1980, 1, 1, 0, 0, 0))
            entry.compress_type = zipfile.ZIP_DEFLATED
            entry.create_system = 3
            entry.external_attr = 0o100644 << 16
            z.writestr(entry, data, compresslevel=9)


def convert(source, out, profiles):
    import cps2_code_guard
    source = source.resolve()
    out = out.resolve()
    require(not out.exists(), 'Choose a fresh --out-dir; existing files are never overwritten')
    profile, record, files = identify(source, profiles)
    input_guard = cps2_code_guard.check_archive(source)
    require(input_guard is not None, 'Source archive did not pass the complete CPS-2 code guard')
    name, result = repack(files, record['region'])
    out.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='.usf2-mame-', dir=out.parent) as temp:
        stage = Path(temp) / 'output'
        stage.mkdir()
        archive = stage / (name + '.zip')
        write_zip(archive, result)
        with zipfile.ZipFile(archive) as z:
            require({n: z.read(n) for n in z.namelist()} == result, 'Written ZIP verification failed')
        guard = cps2_code_guard.check_archive(archive)
        require(guard is not None and guard['maincpu_sha256'] == input_guard['maincpu_sha256']
                and guard['key_sha256'] == input_guard['key_sha256'], 'Program/key preservation failed')
        report = dict(schema=1, source_profile=profile, stock_mame_set=name,
                      source_archive_sha256=sha(source.read_bytes()), archive_sha256=sha(archive.read_bytes()),
                      members={n: dict(size=len(b), sha256=sha(b)) for n, b in sorted(result.items())},
                      code_guard=guard, compact_pcm_mirrored=profile.endswith('4'),
                      original_program_and_key_preserved=True)
        (stage / 'conversion.json').write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
        (stage / 'RUN-MAME.txt').write_text(
            'USF2 for stock MAME\n\n'
            f'Keep {name}.zip in this separate folder. From your MAME directory run:\n'
            f'  mame {name} -rompath "FULL_PATH_TO_THIS_FOLDER"\n\n'
            'MAME displays the Hyper Street Fighter II name and checksum warnings.\n'
            'Those are expected: this archive uses its loader with verified USF2 ROMs.\n'
            'Accept the warning to run Ultra Street Fighter II. If a frontend hides\n'
            'the game after an audit, launch with the command above.\n'
            'Keep this folder separate from your original HSF2 ROMs and use a fresh\n'
            'NVRAM directory if you have previously played HSF2.\n'
            'This is an emulator layout; do not use it to program an arcade board.\n', encoding='utf-8')
        require(not out.exists(), 'Output appeared during conversion')
        stage.rename(out)
    print(f'PASS: {profile} converted to {out / (name + ".zip")}', flush=True)
    return report


def main(profiles=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--rom', type=Path, required=True, help='existing usf2t4/usf2j4/usf2t8/usf2j8 ZIP')
    parser.add_argument('--out-dir', type=Path, required=True, help='fresh folder for the converted set')
    if profiles is None:
        parser.add_argument('--kit-json', type=Path, default=Path(__file__).with_name('kit.json'))
    args = parser.parse_args()
    if profiles is None:
        profiles = json.loads(args.kit_json.read_text())['profiles']
    convert(args.rom, args.out_dir, profiles)


if __name__ == '__main__':
    main()
