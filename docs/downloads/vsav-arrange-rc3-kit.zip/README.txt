Vampire Savior Arrange — reconstruction kit



Version: rc3 (2026-10-21)

Backport by: Steve Gordon (https://x.com/strygo)



Vampire Savior Arrange is one of the arranged editions in Capcom’s 2005 PlayStation 2 Vampire: Darkstalkers Collection, and it never had an arcade release. This backport rebuilds it as a CPS-2 game.

It keeps Vampire Savior’s game system, with recoverable health and Dark Force, and brings back Donovan, Huitzil and Pyron (Donovan, Phobos and Pyron in Japan). Dee, the fighter Capcom made for the Arrange, joins them on his own cell at the bottom of the select screen.

The restored fighters have their moves, voices, endings and win quotes. The Arrange’s character changes and colors are included.

The bottom cell also offers roulette and Shadow, which takes over the defeated opponent after a win. Oboro Bishamon and Jon Talbain’s dark form are selectable with Start.

On MiSTer, the Collection’s music plays for the restored scenes and Dee’s boss fight, and the arcade music everywhere else.

The USA build is in English, with our translation; the Japan build keeps the Japanese.

This is a release candidate.



Changes:

- Donovan, Huitzil and Pyron (Phobos in Japan) return to the roster

- Dee on his own select cell, with his own moves and voice

- The Arrange’s character changes and colors

- Restored endings, dialogue and win quotes

- Roulette and Shadow from the bottom cell; Oboro Bishamon and Jon Talbain’s dark form with Start

- The Collection’s music for the restored scenes and Dee’s boss fight, on MiSTer

- USA (English) and Japan builds

WHAT YOU NEED
-------------
Your Japanese Vampire: Darkstalkers Collection disc image (ISO or CHD),
canonical Vampire Savior Japan (vsavj) and Vampire Savior 2 Japan (vsav2)
arcade ROM sets, and Python 3.10 or newer. CHD input also requires chdman.
Merged, split and complete ZIP/7z sets and extracted folders are accepted.
7z input requires 7-Zip. Your source files are never modified.

BUILD
-----
    python3 apply.py --iso COLLECTION.iso --rompath ROM_DIRECTORY --out-dir out
For CHD input, add --chdman PATH. Use --region us or --region jp for one region;
the default builds both. --romset FILE is repeatable for explicit archives.

The kit verifies every ROM member and the complete music pack. It contains
converters and recipes, with no original game ROMs or music recordings.

ON MISTER
---------
Copy the contents of out/mister/ to the root of the MiSTer SD card. This
includes the dated CPS+ core, ROMs, the music pack and one entry per region.
The entry plays the Collection music for the restored scenes and Dee boss, and
the original arcade music elsewhere; it needs the music pack in games/CPS+.
The core requires 128 MB SDRAM. Keep qsound.zip or qsound_hle.zip in games/mame.
USA entries are under _Arcade/_Arcade Patches/_Restorations; Japanese entries
are in its _Japan folder. The public sets are vsavs01 (USA) and vsavs02 (Japan).

ON HBMAME
---------
out/hbmame/ contains the reconstructed sets. They require the CPS+ machine
driver and the included matching set declarations. External Collection music
playback is available on MiSTer; HBMAME uses the native QSound music.

CHARACTER SELECT
----------------
Random: highlight the bottom-center Dee cell, release the joystick, then
press Down again. Confirm with an attack button. Up, Left or Right stops it.
Shadow: highlight Dee and press that player's Start button five separate
times. Move to the desired first fighter and confirm with an attack button.
Hold Start when selecting Bishamon or Gallon for Oboro Bishamon or Dark Gallon.

LEGAL
-----
Unofficial fan backport, not affiliated with or endorsed by Capcom. Game
characters, titles, artwork and recordings belong to their owners. Own the
ROMs and disc used as inputs. Do not sell or redistribute applied game images.
The converters are covered by LICENSE.txt. Core sources and licenses are
included in core/.

PYTHON PACKAGES

When a build needs NumPy or Pillow and it is not already installed, the kit
downloads its pinned prebuilt package from PyPI into your user cache. No pip,
compiler, administrator rights or changes to system Python are needed.
Patch-only builds and --help do not download Python packages.

Automatic package installation is qualified for CPython 3.12 on Apple Silicon
Macs and CPython 3.13 x64 on Windows (including x64 Python on Windows ARM).
Other interpreters can still use manually installed NumPy/Pillow. There is
no automatic source compilation or selection of an unqualified package.

Cache: ~/Library/Caches/ArcadePatches/python on Mac, or
%LOCALAPPDATA%/ArcadePatches/python on Windows. You can choose another location
with --python-cache PATH (or ARCADE_PYTHON_CACHE). --tools-cache PATH places
the Python cache under PATH/python unless --python-cache is also supplied.
You may delete this cache when no installer is running; it is recreated later.

Offline: add --python-wheels PATH --offline. PATH may name the matching
python-wheels-v1-*.zip, a folder of unzipped wheels, or a folder containing
the wheel ZIPs. The existing wheel bundles work without modification.
You can also supply --tools-bundle for the other helpers in the same command.
ARCADE_PYTHON_WHEELS is the equivalent environment variable. A warm cache
works offline without a bundle. --offline prohibits package downloads too.
Every wheel is checked against the kit's hash; cached extracted files are
verified before use. Existing manually installed packages remain supported.

The installer and its Python subprocesses share the cache. Your shell profile,
global site-packages and unrelated Python applications are not changed.
