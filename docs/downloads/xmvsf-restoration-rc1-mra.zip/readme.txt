X-Men vs. Street Fighter · English restoration
==============================================

Version:  rc1 (2026-11-16)
Target:   MAME set 'xmvsfj' (X-Men vs. Street Fighter (Japan 970113))
Hardware: Capcom CPS-2
Patch by: Steve Gordon (https://x.com/strygo)
Website:  https://arcadepatches.com/xmvsf-restoration/

ABOUT THIS PROJECT

X-Men vs. Street Fighter’s Japanese release has more to say. This restoration
brings its full victory quotes, Apocalypse dialogue, endings and tips into
English while keeping the Japanese fighting rules.

The USA presentation uses Western fighter names and regional voices. Text is
centered in the game’s original dialogue and ending panels.

It runs on Darksoft CPS-2 hardware, on MiSTer, and in MAME. HBMAME and FBNeo
outputs use the same game data.

This is a release candidate.

WHAT'S CHANGED

  - All 288 win quotes in English, including Apocalypse’s sixteen quotes.
  - All 54 Apocalypse dialogue passages, 104 ending captions and seventeen
    tips in English.
  - Western fighter names and USA regional voices, with Japanese 970113
    gameplay.
  - Centered English text and complete ending illustrations.

MISTER SETUP

1. Copy the _Arcade/ folder from this download to the root of your
   MiSTer SD card (the MRA lands in _Arcade/_Arcade Patches/_Restorations/), or copy
   "X-Men vs. Street Fighter (USA) [Restoration].mra" anywhere under _Arcade/.
2. Have the stock, unmodified romset at games/mame/xmvsfj.zip
   (split sets also need the parent and QSound ZIPs named in the MRA).
3. You need Jotego's jtcps2 core; the standard MiSTer downloader /
   update_all installs it automatically.

The MRA references your original romset and applies the restoration in
memory while the game loads. Nothing on your SD card is modified. The
restoration keeps its own settings and saves under the name
'xmvsfre'.

LEGAL

This is a free, unofficial fan patch. It is not affiliated with or endorsed
by Capcom. All game titles, characters, and artwork remain the property of
their respective owners. You must own the game to use this patch. Do not
sell this patch or distribute it applied to a ROM image.
