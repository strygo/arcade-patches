#!/usr/bin/env python3
"""Apply this GD-ROM patch to your own CHD dump of the game.

Usage:
    python3 apply.py /path/to/sfz3ugd/gdl-0002.chd
    python3 apply.py /path/to/gdl-0002.chd -o gdl-0002-patched.chd
    python3 apply.py gdl-0002.chd --chdman /path/to/chdman --tmp /big/disk

Requires Python 3.8+ and chdman (part of every MAME distribution). The patch
contains no game data: it records which bytes of your own disc image change.
Your CHD is verified before anything runs, the rebuilt CHD is verified after,
and about 2.5 GB of temporary disk space is used in between.

The whole pipeline is checksummed end to end: if anything does not match the
expected original, nothing is written.
"""

# BEGIN ARCADE PYTHON BOOTSTRAP
import sys as _arcade_sys
from pathlib import Path as _ArcadePath
_arcade_sys.path.insert(0, str(_ArcadePath(__file__).resolve().parents[0]))
from kit_python import bootstrap as _arcade_bootstrap
_arcade_bootstrap()
# END ARCADE PYTHON BOOTSTRAP

import sys as _native_sys
from pathlib import Path as _NativePath
if __name__ == '__main__' and ('--collection-layout' in _native_sys.argv or '--describe-json' in _native_sys.argv):
    _native_sys.path.insert(0, str(_NativePath(__file__).resolve().parent))
    from chd_collection import main as _native_main
    raise SystemExit(_native_main(_NativePath(__file__).resolve().parent))

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path


def fail(msg: str) -> None:
    print(f"ERROR: {msg}", file=sys.stderr)
    sys.exit(1)


def run_chdman(chdman, args):
    proc = subprocess.run([chdman] + args, capture_output=True, text=True)
    if proc.returncode != 0:
        fail(f"chdman {' '.join(args[:1])} failed:\n{proc.stderr.strip()}")
    return proc.stdout + proc.stderr


def chd_hashes(chdman, path):
    """Return (sha1, data_sha1) reported by chdman info."""
    out = run_chdman(chdman, ["info", "-i", path])
    sha1 = data_sha1 = None
    for line in out.splitlines():
        line = line.strip()
        if line.startswith("SHA1:"):
            sha1 = line.split(":", 1)[1].strip()
        elif line.startswith("Data SHA1:"):
            data_sha1 = line.split(":", 1)[1].strip()
    if not sha1:
        fail(f"could not parse chdman info output for {path}")
    return sha1, data_sha1


def sha1_file(path):
    h = hashlib.sha1()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 22), b""):
            h.update(chunk)
    return h.hexdigest()


def main():
    ap = argparse.ArgumentParser(
        description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter
    )
    ap.add_argument("chd", help="your dump of the game (gdl-0002.chd)")
    ap.add_argument("-o", "--output", help="output CHD path (default: <name>-patched.chd)")
    ap.add_argument("--chdman", help="path to chdman (default: installed or verified download)")
    ap.add_argument("--tmp", help="directory for ~2.5 GB of temporary files")
    ap.add_argument("--debug", action="store_true", help="show a traceback for troubleshooting")
    from tool_controls import add_arguments, configure
    add_arguments(ap)
    args = ap.parse_args()
    configure(sys.argv[1:])
    source = Path(args.chd).expanduser().resolve()
    if not source.is_file():
        hint = ("\nOn Windows, /inputs is at the drive root; use a full drive path or a relative path."
                if os.name == "nt" and args.chd.startswith("/") else "")
        fail(f"Input CHD not found: {args.chd}\nResolved path: {source}\nCurrent folder: {Path.cwd()}{hint}")
    args.chd = str(source)
    if args.tmp and not Path(args.tmp).expanduser().is_dir():
        fail(f"--tmp must be an existing folder: {args.tmp}")


    here = os.path.dirname(os.path.abspath(__file__))
    with open(os.path.join(here, "manifest.json"), encoding="utf-8") as f:
        m = json.load(f)
    patch = m["patch"]

    print(f"{m['title']} ({m['version']})")
    print(f"Target: MAME set '{m['set']}' - {m['game']}\n")

    out_path = args.output
    if not out_path:
        base, ext = os.path.splitext(args.chd)
        out_path = base + "-patched" + (ext or ".chd")
        index = 2
        while os.path.lexists(out_path):
            out_path = base + f"-patched-{index}" + (ext or ".chd")
            index += 1
    if os.path.abspath(out_path) == os.path.abspath(args.chd):
        fail("output path must differ from input path")

    if os.path.lexists(out_path):
        fail(f"Output already exists: {out_path}. Choose a new --output path.")
    Path(out_path).expanduser().resolve().parent.mkdir(parents=True, exist_ok=True)
    out_path = str(Path(out_path).expanduser().resolve())

    from fetch_optional_tools import disc_tool
    if args.chdman:
        from tool_controls import executable_path
        args.chdman = str(executable_path(args.chdman, ('chdman','chdman.exe'), label='chdman'))
    else:
        args.chdman = disc_tool('chdman')

    apply_chd(m, args.chd, out_path, args.chdman, args.tmp or os.path.dirname(out_path))

    print(f"\nWrote {out_path}")
    print(f"  SHA1: {m['target']['chd_sha1']} (verified)")
    print(f"\nPlace it as {m['set']}/{m['chd']} in a MAME rompath ahead of the")
    print(f"stock set, keeping {m['set']}.zip available. MAME will report a")
    print("checksum warning for the CHD; that is expected and the game runs")
    print("on Japanese, USA, and Export BIOS regions.")


def apply_chd(m, source, out_path, chdman, tmp_parent):
    """The single patch pipeline shared by standalone and collection execution."""
    patch = m['patch']
    # 1. Verify the input dump. The CHD SHA1 covers the decompressed data and
    #    metadata, so this check is independent of which chdman version made
    #    the container.
    print("Checking your dump...")
    sha1, data_sha1 = chd_hashes(chdman, source)
    if sha1 == m["target"]["chd_sha1"]:
        fail("this CHD is already patched")
    if sha1 != m["source"]["chd_sha1"] and data_sha1 != m["source"]["data_sha1"]:
        fail(
            f"this CHD does not match the expected original.\n"
            f"  expected SHA1 {m['source']['chd_sha1']}\n"
            f"  found    SHA1 {sha1}\n"
            f"You need the unmodified {m['set']} GD-ROM dump ({m['chd']})."
        )

    tmpdir = tempfile.mkdtemp(prefix="chdpatch-", dir=tmp_parent)
    try:
        # 2. Unpack the disc image.
        print("Extracting disc image (this takes a minute)...")
        gdi = os.path.join(tmpdir, "disc.gdi")
        run_chdman(chdman, ["extractcd", "-i", source, "-o", gdi])

        # 3. Locate the track file and apply the byte patch.
        with open(gdi, encoding="ascii") as f:
            lines = f.read().split()
        # gdi: count, then 6 fields per track; field 5 (index 4) is the filename
        track_files = {}
        fields = lines[1:]
        for t in range(int(lines[0])):
            row = fields[t * 6 : (t + 1) * 6]
            track_files[int(row[0])] = row[4]
        track_path = os.path.join(tmpdir, track_files[patch["track"]])

        old = bytes.fromhex(patch["old"])
        new = bytes.fromhex(patch["new"])
        with open(track_path, "r+b") as f:
            f.seek(patch["offset"])
            cur = f.read(len(old))
            if cur != old:
                fail(
                    f"track {patch['track']} bytes at {patch['offset']:#x} do not "
                    f"match the original (found {cur.hex()}, expected {old.hex()})"
                )
            f.seek(patch["offset"])
            f.write(new)
        print(f"Patched {len(new)} bytes in track {patch['track']}.")

        print("Verifying patched track...")
        if sha1_file(track_path) != patch["track_sha1_after"]:
            fail("patched track checksum mismatch")

        # 4. Rebuild the CHD.
        print("Rebuilding CHD (this takes a few minutes)...")
        run_chdman(chdman, ["createcd", "-i", gdi, "-o", out_path])

        # 5. Verify the result.
        out_sha1, _ = chd_hashes(chdman, out_path)
        if out_sha1 != m["target"]["chd_sha1"]:
            os.remove(out_path)
            fail(
                f"rebuilt CHD SHA1 {out_sha1} does not match the expected "
                f"{m['target']['chd_sha1']}"
            )
    finally:
        shutil.rmtree(tmpdir, ignore_errors=True)



if __name__ == "__main__":
    try:
        main()
    except (OSError, ValueError) as exc:
        if "--debug" in sys.argv:
            raise
        fail(str(exc))
