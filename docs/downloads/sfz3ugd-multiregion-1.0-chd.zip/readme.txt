Street Fighter Alpha 3 Upper · NAOMI GD-ROM multi-region patch
==============================================================

Version:  1.0 (2026-07-10)
Target:   MAME set 'sfz3ugd' (Street Fighter Zero 3 Upper (Japan, GDL-0002))
Hardware: Sega NAOMI GD-ROM
Patch by: Steve Gordon (https://x.com/strygo)
Website:  https://strygo.github.io/arcade-patches/

ABOUT THIS PROJECT

Street Fighter Zero 3 Upper is an enhanced version of Street Fighter Alpha 3
that only came to arcades in Japan, on Sega's NAOMI hardware. Because it's
flagged as a Japanese release, a US or Export machine rejects the disc on
sight with "THIS GAME IS NOT ACCEPTABLE BY MAIN BOARD."

This patch flips that region flag so the very same disc boots on Japanese, US,
and Export systems. Nothing about the game itself changes. On a US or Export
machine it now comes up with its Western Street Fighter Alpha 3 branding
instead of the Japanese Street Fighter Zero 3, exactly as an overseas release
would have.

It is the smallest change possible. Only the region flag is touched, and the
game, its language and its settings are left just as Capcom shipped them.

WHAT'S CHANGED

  - NAOMI header region mask: Japan → Japan + USA + Export (one byte in the
    game header, eight encrypted bytes on disc)
  - Nothing else. This is a region unlock only, and it does not translate or
    otherwise modify the game

WHAT THIS DOWNLOAD IS

This patch contains no game data at all. It records which few bytes of
the disc image change, and the apply script uses your own copy of
chdman (which ships with MAME) to unpack your dump, patch it, and
rebuild it. Every step is checksum-verified: if your dump is not the
expected original, or the rebuilt image does not verify, nothing is
kept.

REQUIREMENTS

  - your own dump of the game: sfz3ugd/gdl-0002.chd (plus sfz3ugd.zip)
  - Python 3.8+
  - chdman, from any reasonably recent MAME
  - about 2.5 GB of free temporary disk space

HOW TO APPLY

    python3 apply.py /path/to/sfz3ugd/gdl-0002.chd

This writes a verified gdl-0002-patched.chd. Rename it
to gdl-0002.chd inside an sfz3ugd/ folder placed ahead of the stock set in
your MAME rompath. MAME reports a checksum warning for the patched
CHD; that is expected and the game runs on Japanese, USA, and Export
BIOS regions.

LEGAL

This is a free, unofficial fan patch. It is not affiliated with or endorsed
by Capcom. All game titles, characters, and artwork remain the property of
their respective owners. You must own the game to use this patch. Do not
sell this patch or distribute it applied to a ROM image.
