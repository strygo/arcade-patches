BUILD OR UPDATE

Run python apply.py in a terminal (Windows: py -3.13 apply.py).
Choose Build or update, then select your media and available outputs.
Settings are remembered; intact outputs can be reused safely.
Check requirements is optional. Change settings saves without building.
Enter q at any prompt to quit. Run apply.py --help for the existing
command-line options and specialized workflows described below.

Street Fighter Alpha 3 Upper · NAOMI GD-ROM multi-region patch
==============================================================

Version:  1.0 (2026-07-10)
Target:   MAME set 'sfz3ugd' (Street Fighter Zero 3 Upper (Japan, GDL-0002))
Hardware: Sega NAOMI GD-ROM
Patch by: Steve Gordon (https://x.com/strygo)
Website:  https://arcadepatches.com/sfz3ugd-multiregion/

ABOUT THIS PROJECT

Street Fighter Zero 3 Upper is an enhanced version of Street Fighter Alpha 3
that only came to arcades in Japan, on Sega's NAOMI hardware. Because it's
flagged as a Japanese release, a US or Export machine rejects the disc on
sight with "THIS GAME IS NOT ACCEPTABLE BY MAIN BOARD."

This patch flips that region flag so the very same disc boots on Japanese, US,
and Export systems. Nothing about the game itself changes. On a US or Export
machine it now comes up with its Western Street Fighter Alpha 3 branding
instead of the Japanese Street Fighter Zero 3, exactly as an overseas release
would have.

It is the smallest change possible. Only the region flag is touched, and the
game, its language and its settings are left just as Capcom shipped them.

WHAT'S CHANGED

  - NAOMI header region mask: Japan → Japan + USA + Export (one byte in the
    game header, eight encrypted bytes on disc)
  - Nothing else. This is a region unlock only, and it does not translate or
    otherwise modify the game

WHAT THIS DOWNLOAD IS

This patch contains no game data at all. It records which few bytes of
the disc image change, and the apply script uses your own copy of
chdman (which ships with MAME) to unpack your dump, patch it, and
rebuild it. Every step is checksum-verified: if your dump is not the
expected original, or the rebuilt image does not verify, nothing is
kept.

REQUIREMENTS

  - your own dump of the game: sfz3ugd/gdl-0002.chd (plus sfz3ugd.zip)
  - Python 3.8+
  - chdman, from any reasonably recent MAME
  - about 2.5 GB of free temporary disk space

HOW TO APPLY

    python3 apply.py /path/to/sfz3ugd/gdl-0002.chd

This writes a verified gdl-0002-patched.chd. Rename it
to gdl-0002.chd inside an sfz3ugd/ folder placed ahead of the stock set in
your MAME rompath. MAME reports a checksum warning for the patched
CHD; that is expected and the game runs on Japanese, USA, and Export
BIOS regions.

LEGAL

This is a free, unofficial fan patch. It is not affiliated with or endorsed
by Capcom. All game titles, characters, and artwork remain the property of
their respective owners. You must own the game to use this patch. Do not
sell this patch or distribute it applied to a ROM image.

PYTHON PACKAGES

When a build needs NumPy or Pillow and it is not already installed, the kit
downloads its pinned prebuilt package from PyPI into your user cache. No pip,
compiler, administrator rights or changes to system Python are needed.
Patch-only builds and --help do not download Python packages.

Automatic package installation is qualified for CPython 3.12 on Apple Silicon
Macs and CPython 3.13 x64 on Windows (including x64 Python on Windows ARM).
Other interpreters can still use manually installed NumPy/Pillow. There is
no automatic source compilation or selection of an unqualified package.

Cache: ~/Library/Caches/ArcadePatches/python on Mac, or
%LOCALAPPDATA%/ArcadePatches/python on Windows. You can choose another location
with --python-cache PATH (or ARCADE_PYTHON_CACHE). --tools-cache PATH places
the Python cache under PATH/python unless --python-cache is also supplied.
You may delete this cache when no installer is running; it is recreated later.

Offline: add --python-wheels PATH --offline. PATH may name the matching
python-wheels-v1-*.zip, a folder of unzipped wheels, or a folder containing
the wheel ZIPs. The existing wheel bundles work without modification.
You can also supply --tools-bundle for the other helpers in the same command.
ARCADE_PYTHON_WHEELS is the equivalent environment variable. A warm cache
works offline without a bundle. --offline prohibits package downloads too.
Every wheel is checked against the kit's hash; cached extracted files are
verified before use. Existing manually installed packages remain supported.

The installer and its Python subprocesses share the cache. Your shell profile,
global site-packages and unrelated Python applications are not changed.
