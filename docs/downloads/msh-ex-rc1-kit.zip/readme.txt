Marvel Super Heroes EX - Enhanced version
rc1 (2026-11-25)

Marvel Super Heroes EX adds a free-play Console mode alongside the original Arcade mode. Choose from 13 fighters in both editions. The USA edition includes the full English Restoration.

- Open Versus, Training and Options from the Console mode title screen. Play Versus against a friend or the computer with handicap and stage selection.
- Select all 13 fighters directly, including Doctor Doom, Thanos and Anita.
- Choose from four colors for every fighter, including two extra colors.
- Play the full English Restoration in the USA edition, including retranslated victory quotes, continue prompts, Automode tips and endings. The Japan edition retains the original Japanese text.
- Practice without a time limit and adjust the dummy's behavior, guard, gauges, speed and Gems.
- Choose Thanos's ending after clearing Arcade as Thanos.

Player Select
Light or Medium Punch picks the original color. Light or Medium Kick picks the original alternate.
Heavy Punch and Heavy Kick pick the two extra colors.

Requirements
Use your stock Japan 951117 arcade ROMs and the stock QSound device.

ArcadePatches
Choose Japan or USA and the MAME or MiSTer target.

MAME
Rebuild both editions with Python 3:
  python3 apply.py --rompath /path/to/stock-roms --platform mame --out-dir ./marvel-ex
The Japan and USA archives go into separate folders under marvel-ex/mame.
Launch mshj with your chosen region's folder first in the ROM path.
MAME may report checksum warnings for the patched ROMs.

MiSTer
Copy the contents of mister/ to the SD card, preserving the folder layout.
Keep the stock arcade ROMs and qsound_hle.zip in the arcade ROM folder.
Use the installed jtCPS2 core. Choose Japan or USA in the arcade menu.
