Super Street Fighter II Turbo: Grand Master Challenge · English restoration · Japan's Super Turbo
=================================================================================================

Version:  rc2 (2026-09-17)
Target:   MAME set 'ssf2xj' (Super Street Fighter II X: Grand Master Challenge (Japan 940311))
Hardware: Capcom CPS-2
Patch by: Steve Gordon (https://x.com/strygo)
Website:  https://strygo.github.io/arcade-patches/

ABOUT THIS PROJECT

Super Turbo came in two versions. Japan got Super Street Fighter II X, the one
competitive players swear by. The rest of the world got a slightly different
game: it plays differently, the continue screen is bare, most of the win
quotes are gone, the endings are shorter, and Akuma's story is missing.
Japan's version, of course, was in Japanese.

Grand Master Challenge is Japan's game in English. The fighting is untouched.
Everything you read is new: all 136 win quotes, the strategy tips on the
continue screen, the full endings, and Akuma's dialogue, translated fresh from
the Japanese with Capcom's own English as the style guide.

It runs anywhere Super Turbo does: MAME, HBMAME, MiSTer, or a real CPS-2
board. The patch keeps the ROM's original sizes and key, so it drops in over
the stock Japanese set.

WHAT'S CHANGED

  - Japan's game, exactly as it plays in Japan
  - The Grand Master Challenge title, and a US region
  - Balrog, Vega, M. Bison and Akuma, the names you know
  - All 136 win quotes in English
  - The continue screen's strategy tips in English
  - Every ending in full, in English, including Akuma's
  - Akuma's intro dialogue, cut from the export game

HOW TO APPLY (recommended)

    python3 apply.py /path/to/ssf2xj.zip --out-dir out

This checks every file against the original, applies the patches, checks
the result, and writes everything you need for each platform:

  MAME / original hardware: out/mame/ssf2xj.zip
  HBMAME:                   out/hbmame/ssf2tgmc.zip
  MiSTer:                   out/mister/_Arcade/_Arcade Patches/_Restorations/Super Street Fighter II Turbo Grand Master Challenge (USA) [English Restoration].mra

MAME: put ssf2xj.zip from out/mame/ ahead of the stock set in your MAME
rompath.
MAME reports checksum warnings for the patched ROMs; that's expected and
the game runs normally. The same files can be burned for an original board.

HBMAME: the set definition (ssf2tgmc) ships with the project;
an upstream HBMAME submission is pending.
Put the zip in HBMAME's roms/ folder next to your stock ssf2xj.zip.
It loads with no checksum warnings.

MiSTer: copy the _Arcade folder from out/mister/ to the root of your SD card
and keep the stock, unmodified romset at games/mame/ssf2xj.zip (split MAME
sets also need qsound.zip). The MRA applies the restoration in memory as the
game loads, so nothing on the card is modified. You need Jotego's jtcps2
core, which update_all installs. The MRAs are also a separate download.

HOW TO APPLY (any IPS patcher)

Extract ssf2xj.zip, apply each file in ips/ to the ROM file of the
same name (Flips, Lunar IPS, or any IPS tool), then re-zip everything
as ssf2xj.zip.

CHANGED FILES

    sfx.13m  (2.0 MB)  CRC32 cf94d275 -> 75dac0eb
    sfx.15m  (2.0 MB)  CRC32 5eb703af -> 84dcc039
    sfx.17m  (2.0 MB)  CRC32 ffa60e0f -> bfcaf206
    sfx.19m  (2.0 MB)  CRC32 34e825c5 -> 13a55fd3
    sfxj.03d  (512 KB)  CRC32 50b52b37 -> b8a10ee0
    sfxj.04a  (512 KB)  CRC32 af7767b4 -> 86104c3a
    sfxj.08  (512 KB)  CRC32 2de76f10 -> ea0d1d90

All other files in the set are unmodified.

LEGAL

This is a free, unofficial fan patch. It is not affiliated with or endorsed
by Capcom. All game titles, characters, and artwork remain the property of
their respective owners. You must own the game to use this patch. Do not
sell this patch or distribute it applied to a ROM image.
