Street Fighter Alpha 2 · English restoration
============================================

Version:  rc2 (2026-10-13)
Target:   MAME set 'sfz2j' (Street Fighter Zero 2 (Japan 960430))
Hardware: Capcom CPS-2
Patch by: Steve Gordon (https://x.com/strygo)
Website:  https://arcadepatches.com/sfa2-restoration/

ABOUT THIS PROJECT

Street Fighter Alpha 2 wasn't the same game everywhere. In Japan, each
fighter's win quote depends on who they beat and how much health they had
left, and you can pick one by holding buttons. The English versions draw a few
quotes at random. They also trimmed some story and ending pages, show only the
country on the next-stage map, turned the blood white and left the Manual
guard panel blank.

The English Restoration is the Japanese game, in English. Every win quote is
back, chosen the Japanese way, and so is the button pick. The story and
endings follow Japan's pages and timing, the map names the place you're
headed, and the blood is red. Birdie's third victory pose and Dan's spoken
line in his ending return too.

The USA version's secret fighters stay: Evil Ryu, EX Dhalsim and EX Zangief
are selectable by code. The computer opponents, two-player damage and factory
settings follow the Japanese version, and Charlie's Sonic Boom and Chun-Li's
Kikoken get the fix from Capcom's later revision. An operator setting switches
the blood to white.

There are three builds. The USA build is Street Fighter Alpha 2 in English.
The Asia build is Street Fighter Zero 2 in English, with Asia's own stage
details. The Japan build keeps its Japanese text and gets the same fixes and
settings. All three run in MAME and HBMAME and on MiSTer.

This is a release candidate.

WHAT'S CHANGED

  - Every win quote from the Japanese game, in English, picked by opponent and
    remaining health
  - Win-quote pick by holding buttons, as in Japan
  - Story and ending pages in Japan's order and timing, including the pages
    the English versions cut
  - English place names on the next-stage map
  - Red blood, with a REGULATION setting for white (off by default)
  - Birdie's third victory pose, Dan's ending voice and a Manual guard panel
    that explains itself
  - Evil Ryu, EX Dhalsim and EX Zangief by code in the USA build; an operator
    setting adds them to the Japan and Asia builds
  - Computer opponents, two-player damage and factory settings as in the
    Japanese version
  - USA, Asia and Japan builds

BUILDS IN THIS DOWNLOAD

    usa        USA (English)
    asia       Asia (English)
    japan      Japan (Japanese)

HOW TO APPLY (recommended)

    python3 apply.py /path/to/sfz2j.zip --out-dir out

This checks every file against the original, applies the patches, checks
the result, and writes everything you need for every build (add
--variant <build> to make just one):

  USA (English):
    MAME:                     out/mame/usa/sfz2j.zip
    HBMAME:                   out/hbmame/sfa2ru.zip
    MiSTer:                   out/mister/_Arcade/_Arcade Patches/_Restorations/Street Fighter Alpha 2 (USA) [English Restoration].mra
  Asia (English):
    MAME:                     out/mame/asia/sfz2j.zip
    HBMAME:                   out/hbmame/sfz2ra.zip
    MiSTer:                   out/mister/_Arcade/_Arcade Patches/_Restorations/_Asia/Street Fighter Zero 2 (Asia) [English Restoration].mra
  Japan (Japanese):
    MAME:                     out/mame/japan/sfz2j.zip
    HBMAME:                   out/hbmame/sfz2rj.zip
    MiSTer:                   out/mister/_Arcade/_Arcade Patches/_Restorations/_Japan/Street Fighter Zero 2 (Japan) [Restoration].mra

Merged, split and complete sets work, including nested or renamed ROMs.
Use --rompath DIR (repeatable) to search a collection instead of naming the
zip, and --check to check inputs before building. ZIPs and extracted folders
need no extra software; 7z archives need 7-Zip. QSound can stay in your
emulator's ROM path; valid firmware already in a source set is kept in
complete outputs.

MAME: put sfz2j.zip from out/mame/ ahead of the stock set in your MAME
rompath (one build at a time: they share the set name).
MAME's game menu won't start a set with patched ROMs, so start it from the
command line: mame sfz2j. MAME shows checksum warnings for the patched
ROMs; that's expected and the game runs normally.
To start it from a menu, use the HBMAME build.

HBMAME: the set definition (sfa2ru, sfz2ra, sfz2rj) ships with the project;
an upstream HBMAME submission is pending.
Put the zip in HBMAME's roms/ folder next to your stock sfz2j.zip.

MiSTer: copy the _Arcade folder from out/mister/ to the root of your SD card
and keep the stock, unmodified romset at games/mame/sfz2j.zip (split MAME
sets also need qsound.zip). The MRA applies the restoration in memory as the
game loads, so nothing on the card is modified. You need Jotego's jtcps2
core, which update_all installs. The MRAs are also a separate download.

HOW TO APPLY (any IPS patcher)

Extract sfz2j.zip, apply each file in ips/<build>/ to the ROM file of the
same name (Flips, Lunar IPS, or any IPS tool), then re-zip everything
as sfz2j.zip.

CHANGED FILES

  USA (English) (--variant usa):
    sz2.13m  (4.0 MB)  CRC32 4d1f1f22 -> 9bd4263f
    sz2.15m  (4.0 MB)  CRC32 19cea680 -> d941803d
    sz2.17m  (4.0 MB)  CRC32 e01b4588 -> 73f31124
    sz2.19m  (4.0 MB)  CRC32 0feeda64 -> 33e41f41
    sz2j.03b  (512 KB)  CRC32 3e1e2e85 -> f528583f
    sz2j.04b  (512 KB)  CRC32 f53d6c45 -> bdc00d52
    sz2j.07b  (512 KB)  CRC32 6352f038 -> c6500e15

  Asia (English) (--variant asia):
    sz2.13m  (4.0 MB)  CRC32 4d1f1f22 -> 9bd4263f
    sz2.15m  (4.0 MB)  CRC32 19cea680 -> d941803d
    sz2.17m  (4.0 MB)  CRC32 e01b4588 -> 73f31124
    sz2.19m  (4.0 MB)  CRC32 0feeda64 -> 33e41f41
    sz2j.03b  (512 KB)  CRC32 3e1e2e85 -> 3b0d6071
    sz2j.04b  (512 KB)  CRC32 f53d6c45 -> bdc00d52
    sz2j.07b  (512 KB)  CRC32 6352f038 -> c6500e15

  Japan (Japanese) (--variant japan):
    sz2.13m  (4.0 MB)  CRC32 4d1f1f22 -> 9bd4263f
    sz2.15m  (4.0 MB)  CRC32 19cea680 -> d941803d
    sz2.17m  (4.0 MB)  CRC32 e01b4588 -> 73f31124
    sz2.19m  (4.0 MB)  CRC32 0feeda64 -> 33e41f41
    sz2j.03b  (512 KB)  CRC32 3e1e2e85 -> 2715551e
    sz2j.04b  (512 KB)  CRC32 f53d6c45 -> bdc00d52
    sz2j.07b  (512 KB)  CRC32 6352f038 -> c6500e15

All other files in the set are unmodified.

LEGAL

This is a free, unofficial fan patch. It is not affiliated with or endorsed
by Capcom. All game titles, characters, and artwork remain the property of
their respective owners. You must own the game to use this patch. Do not
sell this patch or distribute it applied to a ROM image.
