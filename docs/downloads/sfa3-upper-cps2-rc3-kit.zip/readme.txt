Street Fighter Alpha 3 Upper (CPS-2) — reconstruction kit

Version: rc3 (2026-11-18)
Backport by: Steve Gordon (https://x.com/strygo)

Street Fighter Alpha 3 Upper comes to CPS-2 with Guile, Fei Long, Dee Jay, T. Hawk, Evil Ryu and Shin Akuma. The boxer, Juli and Juni have their own cells on the select screen.
Guile, Fei Long, Dee Jay and T. Hawk bring their stages, music and arcade endings. The USA build includes the Street Fighter Alpha 3 English restoration; the Japan build keeps Japanese text and names.
This version includes Arcade mode and its two-player challenge. World Tour, Dramatic Battle and the other console modes are not included.
On MiSTer, it requires the included CPS+ core and 128 MB SDRAM. Computer play requires an HBMAME or FBNeo build that includes the Upper sets. This is a release candidate.

Changes in RC3:
- Fixed the computer-controlled Fei Long sometimes flying across the stage and out of bounds during his Rekka.
- Fixed the slowdown on the Las Vegas stage.
- Fixed Guile’s Level 3 Sonic Hurricane dealing only a few tiny hits, and some fighters taking the wrong amount of damage.
- Guile’s supers show their darkened startup with the gathering light and afterimages again.
- Fixed Dee Jay’s throws holding the wrong pose and running at the wrong speed, and ground throws reading held buttons incorrectly.
- Every winning ending was checked against the NAOMI original. Final scenes now use the original backgrounds and colors instead of moving fight stages, and Ken’s cave, Karin’s market, Evil Ryu’s cave, T. Hawk’s cockpit clouds and Rolento’s truck scene use their original artwork.
- Ending colors match the original, including Ryu and Ken’s opening colors, the dialogue portraits, Chun-Li’s outfit, Akuma and Shin Akuma’s emblems, Evil Ryu’s gloves and gray clouds, and the orange aircraft.
- Fixed ending glitches: stray lightning, Dee Jay’s musical notes, misplaced heads, Sagat facing the wrong way, backgrounds vanishing early, a magenta flash in Cody’s ending, Dhalsim’s mask, the Game Over logo after an ending and a gap in Sakura’s credits.
- Endings close with a thank-you card.
- Birdie, Blanka, Dan, R. Mika and Rolento fight Balrog on the evening Secret Point stage.
- Restored the rival intros for Ryu and Evil Ryu, Cody and Dee Jay, and Gen and Shin Akuma, and the fighters’ stances in boss conversations.
- Four stage themes play their instruments at higher quality, and Dee Jay’s victory claps sound correctly.
- Fixed the X-ISM portraits on the world map, Chun-Li’s and Juli’s portrait colors, the boxer’s victory colors, the X-ISM costume on the select screen and the speaker names in story scenes.
- The USA version uses the taller win-quote panel from the Street Fighter Alpha 3 English restoration.

INPUTS AND BUILD

The Arcade Patches builder app prepares everything it needs. To build by
hand, use Python 3.12 or 3.13 with NumPy 2.2.6, SciPy 1.18.0 and chdman.
On Windows, Python 3.13 can be installed alongside newer Python versions:
  py -3.13 -m pip install numpy==2.2.6 scipy==1.18.0
  py -3.13 apply.py <the arguments shown below>
Supply the original arcade ROM sets, USA Alpha
Anthology and Japanese Zero Fighter’s Generation PS2 discs, and the
Zero 3 Upper NAOMI GD-ROM CHD and sfz3ugd.zip security PIC archive.
The exact accepted input identities are listed in builder/media/inputs.json.

The manual command accepts the original PS2 ISOs or their matching CHDs.
python3 apply.py --rompath /path/to/roms --ps2-us /path/to/us.chd \
  --ps2-jp /path/to/jp.chd --naomi-chd /path/to/gdl-0002.chd \
  --naomi-pic /path/to/sfz3ugd.zip --chdman /path/to/chdman \
  --work /external/fresh-work --out-dir /external/fresh-output

Both output directories must be new. Allow at least 8 GiB of free storage.
Inputs and tools may be kept inside the extracted kit, and --work and
--out-dir may point to new folders there. Their parent folders must exist.
Keep work and output separate; choose new paths when retrying a failed run.
--chdman accepts the executable, its containing folder, or a command on PATH.
Required kit files are checked for missing files and changes; extra files
and folders are allowed. Restore damaged kit files from the original ZIP.
--rompath may be repeated; --platform selects hbmame, fbneo or mister.
The default builds all three layouts. No network download is needed.

OUTPUTS

hbmame/ and fbneo/ contain the regional game ZIPs. Use an HBMAME or FBNeo
build that includes the Upper sets. The mister/ tree contains
the regional launchers, game ZIPs and CPS+ core; copy its contents to the
root of your MiSTer SD card. MiSTer requires 128 MB SDRAM.
The builder never uploads or installs files automatically.
