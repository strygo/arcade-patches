"""Original Naomi ending art converted to native tiles for derived graphics pools.

Ports the development converters of the post-RC2 ending leaves (final scenes,
all private stills, Ken's cave, Karin's market, Hawk's sky, Evil Ryu's early
cave, Rolento's truck and the ending music glyph). Every picture is decoded
from the recipient's original END PACs and Naomi executable; the recipe holds
only scene numbers, cameras, layer orders and source cells. No tile, pen or
color is an input. The converters are copied without behavior changes.

Outputs are kit-pixel pools (linear 4-bit, low nibble first):
* large: every 16x16 and 32x32 tile, split into 128-byte rows of 128 bytes;
* cells: every 8x8 cell as 32 bytes, expanded by the recipe's scroll1 operation.
"""
from collections import Counter
import hashlib
import struct
import numpy as np

EXECUTABLE_BASE = 0x8c020000


def require(ok, message):
    if not ok:
        raise ValueError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def morton_indices(side):
    bits = side.bit_length() - 1
    return np.array([sum(((y >> b & 1) << (2 * b)) | ((x >> b & 1) << (2 * b + 1))
                         for b in range(bits)) for y in range(side) for x in range(side)])


def texture(payload):
    """Private-map texture; hidden RGB is preserved because opaque cells disable alpha."""
    require(payload[:4]==b'GBIX'and payload[16:20]==b'PVRT'and payload[24]in(0,1)and
            payload[25]==1 and struct.unpack_from('<2H',payload,28)==(256,256)and len(payload)==131104,
            'Complete private texture format changed')
    words=np.frombuffer(payload[32:],'<u2')[morton_indices(256)].reshape(256,256)
    if payload[24]==0:
        return ((words&32768)|((words>>11&15)<<8)|((words>>6&15)<<4)|(words>>1&15)).astype(np.uint16)
    return (32768|((words>>12&15)<<8)|((words>>7&15)<<4)|(words>>1&15)).astype(np.uint16)


def texture_words(payload):
    require(payload[:4] == b'GBIX' and payload[16:20] == b'PVRT' and
            payload[24:26] == bytes((0, 1)), 'Original twiddled ARGB1555 required')
    width, height = struct.unpack_from('<2H', payload, 28)
    require(width == height and width & (width - 1) == 0 and len(payload) == 32 + width * height * 2,
            'Original texture extent changed')
    v = np.frombuffer(payload[32:], dtype='<u2')[morton_indices(width)]
    rgb = np.where(v & 32768, 32768 | ((v >> 11 & 15) << 8) |
                   ((v >> 6 & 15) << 4) | (v >> 1 & 15), 0).astype('>u2')
    return rgb.reshape(height, width)


def direct_texture(payload):
    require(payload[:4] == b'GBIX' and payload[16:20] == b'PVRT' and payload[25] == 1
            and payload[24] in (0, 1), 'Ending texture requires twiddled ARGB1555/RGB565')
    width, height = struct.unpack_from('<2H', payload, 28)
    require(width == height and width > 0 and not width & (width-1)
            and len(payload) == 32+width*height*2, 'Original ending direct texture extent')
    if payload[24] == 0:
        return texture_words(payload)
    words = np.frombuffer(payload[32:], dtype='<u2')[morton_indices(width)]
    return (32768 | ((words >> 12 & 15) << 8) | ((words >> 7 & 15) << 4) |
            (words >> 1 & 15)).astype('>u2').reshape(height, width)


def layers(gd, pac, cameras):
    sections = dict(gd.read_pac_sections(pac))
    maps = sections[16]
    require(len(maps) == 0xc000 and len(cameras) == 3, 'Private map/camera extent')
    textures = {}
    output = []
    for layer, (cx, cy) in enumerate(cameras):
        if layer==2:
            require(not any(maps[0x4000:0x4800]), 'Active private third map needs its actual renderer binding')
            output.append(np.zeros((256,384),dtype=np.uint16))
            continue
        cells = np.frombuffer(maps[layer*8192:(layer+1)*8192], dtype='<u4').reshape(32,64)
        canvas = np.zeros((512,1024),dtype=np.uint16)
        for y,x in zip(*np.where(cells & 0x80000000)):
            word = int(cells[y,x])
            require(word & 0x0fff0000 == 0, 'Unknown private cell flags')
            code = word & 65535
            page = code >> 8
            if page not in textures:
                textures[page] = texture(sections[0x10000c00+page])
            page_pixels = textures[page]
            ty,tx = (code & 255)//16*16, code%16*16
            tile = page_pixels[ty:ty+16,tx:tx+16]
            require(tile.shape == (16,16), 'Private tile escaped texture page')
            if not word&0x40000000:tile=tile|32768
            if word & 0x10000000: tile = tile[:,::-1]
            if word & 0x20000000: tile = tile[::-1,:]
            canvas[y*16:y*16+16,x*16:x*16+16] = tile
        crop = canvas[np.ix_((np.arange(256)+cy)%512,(np.arange(384)+cx)%1024)]
        output.append(crop)
    return output


def composite(parts, order):
    require(sorted(order)==[0,1,2], 'All three layers must be ordered explicitly')
    output=np.zeros_like(parts[0])
    for n in order:
        mask=(parts[n]&32768)!=0
        output[mask]=parts[n][mask]
    return output


def original_picture(gd, pac):
    sections = dict(gd.read_pac_sections(pac))
    maps = sections[16]
    require(len(maps) == 0xc000, 'Original private map extent')
    require(not any(maps[:0x2000]) and not any(maps[0x4000:0x4800]),
            'Private final scene has additional active layers')
    cells = np.frombuffer(maps[0x2000:0x4000], dtype='<u4').reshape(32, 64)
    ys, xs = np.where(cells & 0x80000000)
    require(len(xs) and xs.min() == 28 and xs.max() <= 51 and ys.min() == 0 and ys.max() <= 15,
            'Private final scene exceeds declared scene rectangle')
    pages = {}
    output = np.zeros((256, 384), dtype=np.uint16)
    for y, x in zip(ys, xs):
        word = int(cells[y, x]); code = word & 65535; page = code >> 8
        require(word & 0x0fff0000 == 0, 'Unknown original private cell flags')
        if page not in pages:
            payload = sections[0x10000c00+page]
            require(payload[25] == 1, 'Private still requires unbound paletted texture')
            pages[page] = direct_texture(payload)
        texture_page = pages[page]
        tile = texture_page[(code & 255)//16*16:((code & 255)//16+1)*16,
                            code%16*16:(code%16+1)*16]
        require(tile.shape == (16, 16), 'Private still tile extent')
        if word & 0x10000000: tile = tile[:, ::-1]
        if word & 0x20000000: tile = tile[::-1, :]
        output[y*16:y*16+16, (x-28)*16:(x-27)*16] = tile
    return output


def blocks(picture, side):
    return [(y, x, picture[y:y+side, x:x+side])
            for y in range(0, picture.shape[0], side)
            for x in range(0, picture.shape[1], side)]


def choices(picture, side):
    counts = []
    for y, x, tile in blocks(picture, side):
        count = Counter(map(int, tile[(tile & 0x8000) != 0]))
        counts.append(count)
    candidates = {frozenset(c for c, _ in count.most_common(15)) for count in counts if count}
    bins = []
    remaining = set(candidates)
    best = np.zeros(len(counts), dtype=np.int64)
    while remaining and len(bins) < 32:
        selected = None; score = -1; coverage = None
        for palette in sorted(remaining, key=lambda v: tuple(sorted(v))):
            value = np.array([sum(count[c] for c in palette) for count in counts])
            gain = int(np.maximum(value-best, 0).sum())
            if gain > score:
                selected, score, coverage = palette, gain, value
        if score <= 0: break
        bins.append(selected); remaining.remove(selected); best = np.maximum(best, coverage)
    return bins


def decompose(picture):
    """Lossless decomposition of one original picture into native 32/16/8 layers."""
    require(picture.shape == (256, 384), 'Declared original final still dimensions')
    left = picture.copy(); result = []
    for side in (32, 16, 8):
        palettes = choices(left, side) if side > 8 else []
        if side == 8:
            sets = {frozenset(map(int, tile[(tile & 0x8000) != 0])) for _, _, tile in blocks(left, side)}
            for colors in sorted(sets, key=lambda v: (-len(v), tuple(sorted(v)))):
                if not colors: continue
                require(len(colors) <= 15, 'Residual final still tile exceeds native pen domain')
                merges = [(len(set(p)|colors)-len(p), n) for n, p in enumerate(palettes)
                          if len(set(p)|colors) <= 15]
                if merges:
                    n = min(merges)[1]; palettes[n] = set(palettes[n])|colors
                else: palettes.append(colors)
            require(len(palettes) <= 32, 'Residual final still needs too many palette rows')
        output = np.full(picture.shape, 15, dtype=np.uint8); cells = []
        palettes = [tuple(sorted(p)) for p in palettes]
        for y, x, tile in blocks(left, side):
            count = Counter(map(int, tile[(tile & 0x8000) != 0]))
            scores = [sum(count[c] for c in palette) for palette in palettes]
            if not scores or not max(scores): continue
            index = max(range(len(scores)), key=lambda n: (scores[n], -n))
            for pen, color in enumerate(palettes[index]):
                mask = tile == color
                output[y:y+side, x:x+side][mask] = pen
                tile[mask] = 0
            cells.append((x, y, index))
        result.append(dict(side=side, palettes=palettes, pixels=output, cells=cells))
    require(not np.any(left & 0x8000), 'Final still conversion left opaque source pixels')
    restored = np.zeros_like(picture)
    for layer in result:
        side = layer['side']
        for x, y, index in layer['cells']:
            tile = layer['pixels'][y:y+side, x:x+side]
            for pen, color in enumerate(layer['palettes'][index]):
                restored[y:y+side, x:x+side][tile == pen] = color
    require(np.array_equal(restored, np.where(picture & 0x8000, picture, 0)),
            'Complete original still RGB4A differs after native layer decomposition')
    return result


def decomposed_tiles(picture):
    """Every native tile the still compiler emits, including each plane's blank tile."""
    for layer in sorted(decompose(picture), key=lambda r: r['side']):
        side = layer['side']
        yield side, np.full((side, side), 15, np.uint8)
        for x, y, _ in layer['cells']:
            yield side, layer['pixels'][y:y+side, x:x+side]


def sky(gd, pac):
    sections=dict(gd.read_pac_sections(pac));maps=sections[16]
    require(len(maps)==0xc000,'Complete original mode2 map resource required')
    cells=np.frombuffer(maps[0xa800:0xc000],'<u4').reshape(64,24)
    canvas=np.zeros((128,384),np.uint16);pages={}
    for y,x in zip(*np.where(cells[:4,:12]&0x80000000)):
        cell=int(cells[y,x]);require(cell&0x0fff0000==0,'Unknown original sky tile flag')
        code=cell&65535;page=code>>8
        if page not in pages:pages[page]=texture(sections[0x10000c00+page])
        px,py=(code&15)*16,code&240;tile=pages[page][py:py+32,px:px+32]
        require(tile.shape==(32,32),'Original sky tile escaped its texture page')
        if not cell&0x40000000:tile=tile|32768
        if cell&0x10000000:tile=tile[:,::-1]
        if cell&0x20000000:tile=tile[::-1]
        canvas[y*32:y*32+32,x*32:x*32+32]=tile
    return canvas[:128,:384]


def sky_tiles(picture):
    """Hawk's lossless 8x8 cloud-window palette fit."""
    require(picture.shape==(128,384)and np.all(picture&32768),'Original cloud window is not fully opaque')
    needed={frozenset(map(int,picture[y:y+8,x:x+8].flatten()))for y in range(0,128,8)for x in range(0,384,8)}
    palettes=[]
    for colorset in sorted(needed,key=lambda p:(-len(p),tuple(sorted(p)))):
        require(len(colorset)<=15,'Original sky cell exceeds native opaque pen capacity')
        candidates=[(len(colorset-p),-len(colorset&p),i)for i,p in enumerate(palettes)if len(p|colorset)<=15]
        if candidates:
            i=min(candidates)[2];palettes[i]=palettes[i]|colorset
        else:palettes.append(colorset)
    require(1<=len(palettes)<=32,'Complete original sky palette capacity exceeded')
    ordered=[sorted(palette)for palette in palettes]
    yield 8,np.full((8,8),15,np.uint8)
    for y in range(0,128,8):
        for x in range(0,384,8):
            tile=picture[y:y+8,x:x+8];values=set(map(int,tile.flatten()))
            index=next((i for i,p in enumerate(palettes)if values<=p),None)
            require(index is not None,'Original sky cell does not fit a lossless native palette')
            pens=np.full((8,8),15,np.uint8)
            for pen,color in enumerate(ordered[index]):pens[tile==color]=pen
            yield 8,pens


def convert_colors(raw):
    require(len(raw)%32==0,'Complete original 16-color rows required');out=bytearray()
    for n in range(0,len(raw),32):
        words=struct.unpack('<16H',raw[n:n+32])
        for w in words[1:]+words[:1]:out.extend(struct.pack('>H',0xf000|((w>>11&15)<<8)|((w>>6&15)<<4)|(w>>1&15)))
    return bytes(out)


def sprite_grid(gd, pac, index):
    sections=dict(gd.read_pac_sections(pac));meta=sections[0x1000019]
    value1,value2,payload,_=gd.grid_descriptor_payload(meta,index,'Original ending sprite')
    records=gd.parse_pl_record_stream(sections[0x2000019]);width,height=value1&255,value1>>8&255
    pens=np.full((height*16,width*16),15,np.uint8);rows=np.full_like(pens,255);cells=[];cursor=0;tiles={}
    for n in range(width*height):
        if payload[cursor]==255:cursor+=1;continue
        handle=int.from_bytes(payload[cursor:cursor+2],'big');attr=payload[cursor+2];cursor+=3
        require(handle<len(records),'Original cell escaped its complete record stream')
        if handle not in tiles:
            raw=gd.decode_pl_runtime_record(records[handle]);linear=gd.untwiddle_clut4_texture(raw,16,16)
            tiles[handle]=((np.asarray(gd.unpack_clut4(linear),np.int16)-1)&15).astype(np.uint8).reshape(16,16)
        tile=tiles[handle];tile=tile[:,::-1]if attr&64 else tile;tile=tile[::-1,:]if attr&128 else tile
        x=n%width*16;y=n//width*16;pens[y:y+16,x:x+16]=tile;rows[y:y+16,x:x+16]=attr&31
        cells.append(dict(attribute=attr,x=x,y=y))
    require(cursor==len(payload),'Complete original descriptor payload required')
    return pens,rows,dict(index=index,scalar=[value1,value2],cells=cells)


def sprite_coverage(pens,proof):
    mask=np.zeros_like(pens,dtype=bool)
    for cell in proof['cells']:
        x,y=cell['x'],cell['y']
        mask[y:y+16,x:x+16]=(pens[y:y+16,x:x+16]!=15)if cell['attribute']&32 else True
    return mask


def sprite_chain(gd,pac,index):
    result=[]
    for n in range(64):
        pens,rows,proof=sprite_grid(gd,pac,index+n);flag=proof['scalar'][1]>>16
        require(flag in(0,1),'Unknown original descriptor-chain continuation')
        result.append((pens,rows,proof))
        if not flag:return result
    raise ValueError('Unterminated original descriptor chain')


def cave_picture(gd, exe, pac, job):
    """Evil Ryu's early cave: original background layers plus its two original actors."""
    read=lambda a,n:exe[a-EXECUTABLE_BASE:a-EXECUTABLE_BASE+n]
    ptr=lambda a:struct.unpack('<I',read(a,4))[0]
    header=ptr(job['directory']+job['owner']*4);bank=ptr(header+20)
    palettes=np.frombuffer(convert_colors(read(bank,20*32)),dtype='>u2').reshape(20,16)
    canvas=composite(layers(gd,pac,job['cameras']),tuple(job['order']))
    for index,frame,last in job['actors']:
        require(read(frame,8)==struct.pack('<4H',0x40ff,0,index,0),'Original cave sprite frame changed')
        chain=sprite_chain(gd,pac,index)
        require([r[2]['index']for r in chain]==list(range(index,last)),'Complete original cave actor chain changed')
        for pens,rows,record in reversed(chain):
            x=job['origin'][0]-(record['scalar'][0]>>16);y=240-job['origin'][1]-(record['scalar'][1]&65535)
            require(y==0 and x>=0 and x+pens.shape[1]<=384 and pens.shape[0]==128,'Original cave viewport changed')
            opaque=sprite_coverage(pens,record)
            require(set(map(int,rows[opaque].flatten()))<=set(job['rows']),'Cave palette escaped its original rows')
            colors=palettes[np.minimum(rows,19),pens]&4095
            target=canvas[job['raster_y']:job['raster_y']+128,x:x+pens.shape[1]];target[opaque]=colors[opaque]|0x8000
    return canvas


def mode2_picture(gd, pac, job):
    """Rolento's mode2 truck scene with its three original planes."""
    sections=dict(gd.read_pac_sections(pac));maps=sections[16]
    require(len(maps)==0xc000,'Complete original mode2 map required')
    parts=[];pages={}
    for (lo,hi,cols,side),(cx,cy)in zip(((0x4800,0x6800,64,16),(0x6800,0xa800,64,16),(0xa800,0xc000,24,32)),job['cameras']):
        cells=np.frombuffer(maps[lo:hi],'<u4').reshape(-1,cols)
        canvas=np.zeros((cells.shape[0]*side,cols*side),np.uint16)
        wanted_rows=set(((np.arange(128)+cy)%canvas.shape[0]//side).tolist())
        wanted_cols=set(((np.arange(384)+cx)%canvas.shape[1]//side).tolist())
        for y,x in zip(*np.where(cells&0x80000000)):
            if y not in wanted_rows or x not in wanted_cols:continue
            word=int(cells[y,x]);require(not word&0x0fff0000,'Unknown original mode2 cell flags')
            code=word&65535;page=code>>8
            if page not in pages:pages[page]=texture(sections[0x10000c00+page])
            px,py=(code&15)*16,code&240;tile=pages[page][py:py+side,px:px+side]
            require(tile.shape==(side,side),'Original mode2 tile escaped its texture page')
            if not word&0x40000000:tile=tile|32768
            if word&0x10000000:tile=tile[:,::-1]
            if word&0x20000000:tile=tile[::-1,:]
            canvas[y*side:y*side+side,x*side:x*side+side]=tile
        part=canvas[np.ix_((np.arange(128)+cy)%canvas.shape[0],(np.arange(384)+cx)%canvas.shape[1])]
        parts.append(np.pad(part,((0,128),(0,0))))
    return composite(parts,tuple(job['order']))


PVR_FONT_PENS={0xfbde:9,0xe318:10,0xd294:11,0xb9ce:12,0xa108:13,0x9084:14,0x01d0:15}


def glyph_halves(gd, pac, job):
    """The original ending music glyph, split into two left-aligned 16x16 halves."""
    sections=dict(gd.read_pac_sections(pac));raw=sections[job['section']]
    require(raw[:4]==b'GBIX'and raw[24:26]==bytes((0,1))and struct.unpack_from('<2H',raw,28)==(256,256),
            'Original caption atlas format differs')
    x,y,w,h=job['cell']
    words=np.frombuffer(raw[32:],'<u2')[morton_indices(256)].reshape(256,256)[y:y+h,x:x+w]
    require(set(map(int,words.flat))<=PVR_FONT_PENS.keys(),'Unknown original font color')
    pens=np.array([PVR_FONT_PENS[int(v)]for v in words.flat],dtype='uint8').reshape(h,w)
    for n in(0,1):
        half=np.full((16,16),15,dtype='uint8');half[:,:8]=pens[:,n*8:(n+1)*8]
        yield 16,half


def linear(tile):
    raw=np.ascontiguousarray(tile,dtype=np.uint8).reshape(-1)
    return (raw[::2]|raw[1::2]<<4).tobytes()


def produce(gd, exe, pac, recipe):
    """Return (large, cells, report): deduplicated tiles in first-emitted order."""
    require(recipe.get('schema')==1 and digest(exe)==recipe['executable_sha256'],'Original executable or recipe differs')
    large,cells,seen=bytearray(),bytearray(),set();report=[]
    for job in recipe['jobs']:
        blob=pac(job['pac']);require(digest(blob)==job['pac_sha256'],'Original ending resource differs: '+job['pac'])
        kind=job['kind']
        if kind=='layers':tiles=decomposed_tiles(composite(layers(gd,blob,job['cameras']),tuple(job['order'])))
        elif kind=='original':tiles=decomposed_tiles(original_picture(gd,blob))
        elif kind=='sky':tiles=sky_tiles(sky(gd,blob))
        elif kind=='cave':tiles=decomposed_tiles(cave_picture(gd,exe,blob,job))
        elif kind=='mode2':tiles=decomposed_tiles(mode2_picture(gd,blob,job))
        elif kind=='glyph':tiles=glyph_halves(gd,blob,job)
        else:raise ValueError('Unknown ending art job: '+str(kind))
        added=0
        for side,tile in tiles:
            require(tile.shape==(side,side)and int(tile.max())<=15,'Native tile domain')
            data=linear(tile);key=side,data
            if key in seen:continue
            seen.add(key);added+=1
            (cells if side==8 else large).extend(data)
        report.append(dict(job=job['name'],new_tiles=added))
    return bytes(large),bytes(cells),report


def self_test():
    """Decomposition is lossless and a changed picture changes the emitted tiles."""
    rng=np.random.default_rng(7)
    colors=np.array([32768|c for c in range(1,9)],np.uint16)
    picture=colors[rng.integers(0,len(colors),(256,384))]
    picture[:64]=0
    first=[(s,linear(t))for s,t in decomposed_tiles(picture.copy())]
    picture[100,100]=colors[0] if picture[100,100]!=colors[0] else colors[1]
    second=[(s,linear(t))for s,t in decomposed_tiles(picture.copy())]
    require(first!=second and all(len(b)==s*s//2 for s,b in first),'Ending art decomposition control')
    return dict(passed=True,tiles=len(first))
