X-Men vs. Street Fighter · English restoration
==============================================

Version:  rc1 (2026-11-16)
Target:   MAME set 'xmvsfj' (X-Men vs. Street Fighter (Japan 970113))
Hardware: Capcom CPS-2
Patch by: Steve Gordon (https://x.com/strygo)
Website:  https://arcadepatches.com/xmvsf-restoration/

ABOUT THIS PROJECT

X-Men vs. Street Fighter’s Japanese release has more to say. This restoration
brings its full victory quotes, Apocalypse dialogue, endings and tips into
English while keeping the Japanese fighting rules.

The USA presentation uses Western fighter names and regional voices. Text is
centered in the game’s original dialogue and ending panels.

It runs on Darksoft CPS-2 hardware, on MiSTer, and in MAME. HBMAME and FBNeo
outputs use the same game data.

This is a release candidate.

WHAT'S CHANGED

  - All 288 win quotes in English, including Apocalypse’s sixteen quotes.
  - All 54 Apocalypse dialogue passages, 104 ending captions and seventeen
    tips in English.
  - Western fighter names and USA regional voices, with Japanese 970113
    gameplay.
  - Centered English text and complete ending illustrations.

BUILD THE GAME

Run python3 apply.py in a terminal for guided setup.
On Windows use py -3.13 apply.py.
Choose your media folder, platform, region and output folder.
Run python3 apply.py --help for command-line options.

HOW TO APPLY (recommended)

    python3 apply.py /path/to/xmvsfj.zip --out-dir out

This checks every file against the original, applies the patches, checks
the result, and writes everything you need for each platform:

  MAME:                     out/mame/xmvsfj.zip
  HBMAME:                   out/hbmame/xmvsfre.zip
  FBNeo:                    out/fbneo/xmvsfre.zip
  MiSTer:                   out/mister/_Arcade/_Arcade Patches/_Restorations/X-Men vs. Street Fighter (USA) [Restoration].mra

FBNeo: use --platform fbneo --out-dir out for complete game ZIPs.
Keep their ZIP and member names. Use an FBNeo version with definitions
matching this game release; older versions may reject its checksums.


DARKSOFT

Use --platform darksoft --out-dir out to build only Darksoft files.
The default all-platform build includes them too. Copy the selected
folder from out/darksoft/games to your card games folder.
Expanded hardware and streamed audio are not supported.

Merged, split and complete sets work, including nested or renamed ROMs.
Use --rompath DIR (repeatable) to search a collection instead of naming the
zip, and --check to check inputs before building. ZIPs and extracted folders
need no extra software; 7z archives need 7-Zip.
QSound can stay in your emulator's ROM path; valid firmware already
in a source set is kept in complete outputs.

MAME: put xmvsfj.zip from out/mame/ ahead of the stock set in your MAME
rompath.
MAME's game menu won't start a set with patched ROMs, so start it from the
command line: mame xmvsfj. MAME shows checksum warnings for the patched
ROMs; that's expected and the game runs normally.
To start it from a menu, use the HBMAME build.

HBMAME: use a build containing the xmvsfre set definitions.
Upstream HBMAME support is pending.
Put xmvsfre.zip and qsound.zip in HBMAME's roms/ folder;
it holds the complete set.

MiSTer: copy the _Arcade folder from out/mister/ to the root of your SD card
and keep the stock, unmodified romset at games/mame/xmvsfj.zip (split MAME
sets also need qsound.zip). The MRA applies the restoration in memory as the
game loads, so nothing on the card is modified. You need Jotego's jtcps2
core, which update_all installs. The MRAs are also a separate download.

HOW TO APPLY (any IPS patcher)

Extract xmvsfj.zip, apply each file in ips/ to the ROM file of the
same name (Flips, Lunar IPS, or any IPS tool), then re-zip everything
as xmvsfj.zip.

CHANGED FILES

    xvs.05a  (512 KB)  CRC32 7db6025d -> 82dc383d
    xvs.06a  (512 KB)  CRC32 e8e2c75c -> b71c0900
    xvs.09  (512 KB)  CRC32 9641f36b -> f239c68b
    xvsj.03m  (512 KB)  CRC32 e2944372 -> 4ae5878b
    xvsj.04m  (512 KB)  CRC32 c20b8524 -> 97cb4c9c

All other files in the set are unmodified.

LEGAL

This is a free, unofficial fan patch. It is not affiliated with or endorsed
by Capcom. All game titles, characters, and artwork remain the property of
their respective owners. You must own the game to use this patch. Do not
sell this patch or distribute it applied to a ROM image.
