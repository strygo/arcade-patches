"""Kit-owned collection interface for the shared IPS builder (API 1).

Definitions are generated while packaging from accepted native outputs. They
are descriptions, not executable recipes. Release QA remains the independent
acceptance authority. This module uses only bundled code and the standard library.
"""
import contextlib
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import tempfile
import xml.etree.ElementTree as ET
import zipfile
from file_identity import file_stamp, documentation_output

API = 1
PLATFORMS = ('mame', 'hbmame', 'fbneo', 'mister', 'darksoft')


def require(ok, message):
    if not ok:
        raise ValueError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def safe_name(value):
    require(isinstance(value, str) and value and '\\' not in value, 'Invalid relative output name')
    path = PurePosixPath(value)
    require(not path.is_absolute() and path.as_posix() == value and all(p not in ('.', '..') for p in path.parts),
            'Output path escapes export')
    return value


def load_bindings(path):
    value = json.loads(Path(path).read_text())
    require(value.get('schema') == 1 and isinstance(value.get('files'), list), 'Unknown bound-input schema')
    for row in value['files']:
        require(type(row.get('size')) is int and row['size'] >= 0 and
                re.fullmatch('[0-9a-f]{64}', row.get('sha256', '')) and Path(row['path']).is_absolute(),
                'Bound input needs an absolute path, size and SHA-256')
    return value['files']


def read_binding(row, archive=None):
    path = Path(row['path'])
    if 'member' in row:
        with (zipfile.ZipFile(path) if archive is None else contextlib.nullcontext(archive)) as archive:
            matches = [i for i in archive.infolist() if i.filename == row['member']]
            require(len(matches) == 1 and not matches[0].is_dir() and matches[0].file_size == row['size'],
                    'Bound ZIP member missing, ambiguous or changed')
            data = archive.read(matches[0])
    else:
        require(path.stat().st_size == row['size'], 'Bound source size changed')
        data = path.read_bytes()
    require(len(data) == row['size'] and sha(data) == row['sha256'], 'Bound source content changed')
    return data


class BindingArchives:
    """At most four open containers for one input-resolution boundary."""
    def __init__(self):self.opened = {}
    def __enter__(self):return self
    def __exit__(self, *args):
        for archive in self.opened.values():archive.close()
        self.opened.clear()
    def open(self, path):
        archive = self.opened.pop(path, None)
        if archive is None:
            if len(self.opened) >= 4:self.opened.pop(next(iter(self.opened))).close()
            archive = zipfile.ZipFile(path)
        self.opened[path] = archive
        return archive


def resolve_bound(requirements, bindings, verify, optional=False, *, cache=None):
    found = {}
    with BindingArchives() as archives:
        for spec in requirements:
            for row in bindings:
                if row['size'] != spec['size'] or (spec.get('sha256') and row['sha256'] != spec['sha256']):continue
                if cache is not None:row = cached_binding(row, cache, open_archive=archives.open)
                archive = archives.open(row['path']) if 'member' in row else None
                data = read_binding(row, archive)
                if verify(data, spec):
                    found[spec['name']] = data
                    break
            require(optional or spec['name'] in found, 'Missing declared input: ' + spec['name'])
    return found


def contracts(outputs):
    return {name: {'members': {n: sha(data) for n, data in value.items()}} if isinstance(value, dict)
            else {'sha256': sha(value)} for name, value in outputs.items()}


def complete_outputs(base, variant, platform, outputs, stock):
    """One layout/ownership rule used by packaging and native execution."""
    require(platform in PLATFORMS, 'Select exactly one collection platform')
    result = {}
    for name, value in outputs.items():
        safe_name(name)
        require(name.startswith(platform + '/'), 'Unexpected native platform output')
        destination = ('roms/' + PurePosixPath(name).name if platform in ('mame', 'hbmame', 'fbneo')
                       else name[len(platform) + 1:])
        require(destination.casefold() not in {n.casefold() for n in result}, 'Collection output collision')
        result[destination] = value
    if platform in ('mame', 'hbmame', 'mister'):
        require('dl-1425.bin' in stock, 'Complete runtime export requires QSound firmware')
        if platform == 'mister' or (platform == 'hbmame' and not variant['hbmame'].get('complete')):
            name = ('games/mame/' if platform == 'mister' else 'roms/') + base['set'] + '.zip'
            require(name not in result, 'Stock parent conflicts with patched output')
            result[name] = dict(stock)
        if platform != 'mister':
            require('roms/qsound.zip' not in result, 'Device output collision')
            result['roms/qsound.zip'] = {'dl-1425.bin': stock['dl-1425.bin']}
    return result


def define(root, project, base, bundles, stock, build_outputs):
    """Produce kit metadata using the native builder, never an external adapter."""
    from rom_sources import QSOUND
    require(re.fullmatch('[a-z0-9][a-z0-9-]*', project), 'Invalid collection project ID')
    targets, prerequisites, native = {}, {}, {}
    for manifest, patches in bundles:
        variant = manifest.get('variant', {}).get('key') or 'default'
        specs = [m for m in manifest['members'] if m['action'] != 'add' and m.get('role') != 'device'
                 and m['name'] != 'dl-1425.bin']
        ids = []
        for spec in [*specs, QSOUND]:
            identity = spec.get('stock_sha256', spec.get('sha256'))
            require(identity and len(identity) == 64, 'Collection input requires SHA-256')
            key = 'source-' + identity[:20]
            prerequisites[key] = {'title': spec['name'], 'kind': 'device' if spec['name'] == 'dl-1425.bin' else 'rom',
                'search_names': [spec['name'], base['set'], base['set'] + '.zip', base['set'] + '.7z', 'qsound.zip', 'qsound_hle.zip'],
                'formats': ['loose file', 'ZIP member', '7z member'],
                'action': 'Add the canonical ' + base['set'] + ' arcade set and QSound firmware to a media folder.',
                'alternatives': [{'size': spec['size'], 'sha256': identity,
                                  'crc32': spec.get('stock_crc32', spec.get('crc32'))}]}
            if prerequisites[key]['alternatives'][0]['crc32'] is None:
                prerequisites[key]['alternatives'][0].pop('crc32')
            ids.append(key)
        source = {m['name']: stock[m['name']] for m in specs}
        source['dl-1425.bin'] = stock['dl-1425.bin']
        devices = {'dl-1425.bin': stock['dl-1425.bin']} if base.get('mame_include_devices', True) else {}
        raw = build_outputs(base, [(manifest, patches)], source, devices, 'all')
        native.update(contracts(raw))
        region = None
        if manifest.get('mra'):
            xml = ET.fromstring((Path(root) / manifest['mra']).read_bytes())
            text = (xml.findtext('region') or '').strip().lower()
            region = {'usa': 'us', 'japan': 'jp', 'europe': 'eu'}.get(text, text)
            require(re.fullmatch('[a-z0-9-]+', region or ''), 'MRA requires a declared output region')
        for platform in PLATFORMS:
            selected = {p: value for p, value in raw.items() if p.startswith(platform + '/')}
            if not selected:
                continue
            target = {'platform': platform, 'variant': variant,
                'native_variant': manifest.get('variant', {}).get('key'),
                'profile': project + '-' + variant if platform == 'mame' else 'default',
                'inputs': sorted(ids if platform in ('mame', 'hbmame', 'mister') else ids[:-1]),
                'outputs': contracts(complete_outputs(base, manifest, platform, selected, source))}
            target['destination_requirements'] = (
                'Use emulator definitions matching this release.' if platform in ('mame', 'hbmame', 'fbneo') else
                'Use the MiSTer core named by the included MRA.' if platform == 'mister' else
                "Use the Darksoft hardware and layout described in this kit's readme.")
            if region:
                target['region'] = region
            targets[variant + '-' + platform] = target
    return {'api': API, 'project': project, 'game_version': base['version'], 'kit_revision': base.get('kit_revision', 1),
        'manifest_sha256': sha((Path(root) / 'manifest.json').read_bytes()),
        'prerequisites': prerequisites, 'targets': targets, 'native_outputs': native}


def describe(root):
    root = Path(root)
    value = json.loads((root / 'collection.json').read_text())
    require(value.get('api') == API and value['manifest_sha256'] == sha((root / 'manifest.json').read_bytes()),
            'Kit definition differs from its manifest; regenerate it while packaging')
    return value


def verify_outputs(outputs, expected):
    actual = contracts(outputs)
    # Documentation remains in the exported inventory, but its prose is not a
    # game acceptance condition. Software/package seals still authenticate it.
    for name in actual.keys() & expected.keys():
        if documentation_output(name, expected[name]) and isinstance(outputs[name], bytes):
            actual[name] = expected[name]
    if actual == expected:
        return
    differences = []
    def compare(found, wanted, path):
        if isinstance(found, dict) and isinstance(wanted, dict):
            for key in sorted(set(found) | set(wanted)):
                name = path + '/' + key if path else key
                if key not in found:
                    differences.append(name + ': missing')
                elif key not in wanted:
                    differences.append(name + ': unexpected')
                else:
                    compare(found[key], wanted[key], name)
        elif found != wanted:
            differences.append(f'{path}: expected {wanted}, found {found}')
    compare(actual, expected, '')
    raise ValueError('Collection output differs from packaged contract: ' + '; '.join(differences))


def report(path, operation, target, status='ok', outputs=None, message=None):
    if path:
        result = {'api': API, 'operation': operation, 'target': target, 'status': status}
        if outputs is not None:
            result['outputs'] = outputs
        if message:
            result['message'] = message
        path = Path(path)
        temporary = path.with_name(path.name + '.tmp')
        temporary.write_text(json.dumps(result, sort_keys=True) + '\n')
        temporary.replace(path)


def package_archive(path, project, sources):
    """Add a freshly generated definition as part of normal kit packaging."""
    import subprocess
    import sys
    import tempfile
    path = Path(path)
    with tempfile.TemporaryDirectory(prefix='kit-definition-') as temporary:
        root = Path(temporary)
        with zipfile.ZipFile(path) as archive:
            infos = archive.infolist()
            require(len({i.filename for i in infos}) == len(infos), 'Duplicate packaged member')
            for info in infos:
                safe_name(info.filename.rstrip('/'))
            archive.extractall(root)
        command = [sys.executable, str(root / 'apply.py'), '--emit-definition', project]
        for source in sources:
            command += ['--rompath', str(Path(source).resolve())]
        subprocess.run(command, cwd=root, check=True)
        data = (root / 'collection.json').read_bytes()
        target = path.with_name(path.name + '.native')
        try:
            with zipfile.ZipFile(path) as original, zipfile.ZipFile(target, 'w') as updated:
                for info in original.infolist():
                    if info.filename != 'collection.json':
                        updated.writestr(info, original.read(info))
                info = zipfile.ZipInfo('collection.json', date_time=(1980, 1, 1, 0, 0, 0))
                info.compress_type = zipfile.ZIP_DEFLATED
                info.external_attr = 0o100644 << 16
                updated.writestr(info, data)
            target.replace(path)
        finally:
            target.unlink(missing_ok=True)
    from standalone_kit import package_archive as add_frontend
    add_frontend(path)


def check_bound_input(binding, size, digest, stable):
    """Distinguish a failed candidate match from a source changing during I/O."""
    failures = []
    if size != binding['size']:
        failures.append(f"size expected {binding['size']}, read {size}")
    if digest != binding['sha256']:
        failures.append(f"SHA-256 expected {binding['sha256']}, read {digest}")
    if not stable:
        failures.append('file metadata changed while reading')
    source = str(binding['path'])
    if 'member' in binding:source += ' :: ' + binding['member']
    require(not failures, 'Bound input changed since discovery or did not match the selected candidate: '
            + source + '; ' + '; '.join(failures))


def bound_file(binding, destination):
    """Verify large bound inputs by streaming; materialize only archive members."""
    path = Path(binding['path'])
    require(path.is_absolute(), 'Bound file path must be absolute')
    before = path.stat();destination = Path(destination)
    if 'member' in binding:
        destination.parent.mkdir(parents=True, exist_ok=True)
        copy_binding(binding, destination)
        return destination
    else:result = path
    value = hashlib.sha256();size = 0
    with result.open('rb') as source:
        for block in iter(lambda: source.read(1024 ** 2), b''):
            value.update(block);size += len(block)
    after = path.stat()
    check_bound_input(binding, size, value.hexdigest(),
                      (before.st_ino, before.st_size, before.st_mtime_ns) == (after.st_ino, after.st_size, after.st_mtime_ns))
    return result


def binding_stamp(path):
    return file_stamp(path)


def copy_binding(binding, destination, *, archive=None):
    """Authenticate while copying, without a second pass over extracted bytes."""
    path = Path(binding['path']);before = binding_stamp(path);destination = Path(destination)
    digest = hashlib.sha256();size = 0
    try:
        with contextlib.ExitStack() as stack:
            if 'member' in binding:
                archive = stack.enter_context(zipfile.ZipFile(path) if archive is None else contextlib.nullcontext(archive))
                rows = [r for r in archive.infolist() if r.filename == binding['member'] and not r.is_dir()]
                source_name = str(path) + ' :: ' + binding['member']
                require(len(rows) == 1, 'Bound archive member missing or ambiguous: ' + source_name)
                require(rows[0].file_size == binding['size'],
                        f"Bound archive member changed: {source_name}; size expected {binding['size']}, found {rows[0].file_size}")
                stream = stack.enter_context(archive.open(rows[0]))
            else:stream = stack.enter_context(path.open('rb'))
            output = stack.enter_context(destination.open('wb'))
            os.chmod(destination, 0o600)
            for block in iter(lambda: stream.read(1024 ** 2), b''):
                size += len(block)
                require(size <= binding['size'], f"Bound input exceeds declared size: {path}; expected {binding['size']}, read at least {size}")
                digest.update(block);output.write(block)
        check_bound_input(binding, size, digest.hexdigest(), before == binding_stamp(path))
    except BaseException:
        destination.unlink(missing_ok=True)
        raise


def cached_binding(binding, cache, *, open_archive=None):
    """Bound same-run staging; retain original-source checks on every reuse."""
    path = Path(binding['path'])
    # Keep staging optional on small cards; large disc inputs retain their
    # original streaming readers instead of requiring another complete copy.
    if binding['size'] > 128 * 1024 ** 2:return binding
    root = Path(cache) / 'input-files'
    require(Path(cache).is_absolute() and not root.is_symlink(), 'Invalid input cache directory')
    root.mkdir(parents=True, exist_ok=True)
    stamp = list(binding_stamp(path))
    key = sha(json.dumps({'binding': binding, 'stat': stamp}, sort_keys=True).encode())
    suffix = Path(binding.get('member', path.name)).suffix
    destination = root / (key + suffix)
    if destination.exists():
        require(not destination.is_symlink(), 'Input cache must not contain symlinks')
        if stamp[-1] is None:
            verify_binding(binding, archive=open_archive(binding['path']) if open_archive is not None and 'member' in binding else None)
        verify_binding({'path': str(destination), 'size': binding['size'], 'sha256': binding['sha256']})
        require(tuple(stamp) == binding_stamp(path), 'Original source changed during cache verification')
    else:
        retained = sum(p.stat().st_size for p in root.iterdir() if p.is_file() and not p.is_symlink())
        if retained + binding['size'] > 512 * 1024 ** 2 or shutil.disk_usage(root).free < binding['size'] + 64 * 1024 ** 2:
            return binding
        with tempfile.NamedTemporaryFile(prefix='.input-', dir=root, delete=False) as stream:temporary = Path(stream.name)
        try:
            archive = open_archive(binding['path']) if open_archive is not None and 'member' in binding else None
            copy_binding(binding, temporary, archive=archive)
            temporary.replace(destination)
        finally:temporary.unlink(missing_ok=True)
    return {k: v for k, v in binding.items() if k not in ('path', 'member')} | {'path': str(destination)}


def stage_bindings(bindings, cache):
    with BindingArchives() as archives:
        return {key: cached_binding(binding, cache, open_archive=archives.open) for key, binding in bindings.items()}


def verify_binding(binding, *, archive=None):
    """Stream-check a physical source even when a native build cache is reused."""
    import contextlib
    path = Path(binding['path'])
    require(path.is_absolute() and type(binding.get('size')) is int and binding['size'] >= 0
            and re.fullmatch('[0-9a-f]{64}', binding.get('sha256', '')), 'Invalid bound source identity')
    before = path.stat();value = hashlib.sha256();size = 0
    with contextlib.ExitStack() as stack:
        if 'member' in binding:
            archive = stack.enter_context(zipfile.ZipFile(path) if archive is None else contextlib.nullcontext(archive))
            rows = [row for row in archive.infolist() if row.filename == binding['member'] and not row.is_dir()]
            require(len(rows) == 1 and rows[0].file_size == binding['size'], 'Bound ZIP member changed')
            stream = stack.enter_context(archive.open(rows[0]))
        else:stream = stack.enter_context(path.open('rb'))
        for block in iter(lambda: stream.read(1024 ** 2), b''):
            size += len(block);value.update(block)
    after = path.stat()
    require(size == binding['size'] and value.hexdigest() == binding['sha256'] and
            (before.st_ino, before.st_size, before.st_mtime_ns) == (after.st_ino, after.st_size, after.st_mtime_ns),
            'Bound source changed since discovery')
