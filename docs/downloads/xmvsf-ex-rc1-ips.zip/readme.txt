X-Men vs. Street Fighter EX · Enhanced version
==============================================

Version:  rc1 (2026-11-18)
Target:   MAME set 'xmvsfj' (X-Men vs. Street Fighter (Japan 970113))
Hardware: Capcom CPS-2
Patch by: Steve Gordon (https://x.com/strygo)
Website:  https://arcadepatches.com/xmvsf-ex/

ABOUT THIS PROJECT

X-Men vs. Street Fighter EX keeps the arcade tag-team game and adds a home-
style Console mode. Start opens a title menu with Arcade, Versus, Training and
Options. Versus supports a friend or the computer, with handicap and stage
choices and win totals that carry through rematches. Training offers dummy,
guard, gauge, speed and stage controls.

Apocalypse is fully playable: he fights alone in his own arena with his six
native commands, has a seven-fight Arcade route with Magneto and M. Bison as
the final opponents, and gets his own ending. Akuma and Apocalypse have
visible places on character select. The other fighters get the Saturn
version's two extra colors, carried through portraits and effects, and mirror
matches keep both sides' colors distinct. Holding Start on Chun-Li previews
her alternate outfit.

The USA build includes the English Restoration: win quotes translated from the
Japanese, restored Apocalypse conversations and complete endings. The Japan
build keeps the original Japanese text and adds Japanese for Apocalypse's
final conversation, his ending and the service menus. Both builds share the
Japanese release's default settings, eight Turbo levels and the original
Normal speed. Console mode needs no credits; the service menu also retains
ordinary Arcade operation.

This is a release candidate.

WHAT'S CHANGED

  - Fully playable Apocalypse with his six native commands, a solo Arcade
    route with Magneto and M. Bison as the final opponents, and his own
    ending; visible Akuma and Apocalypse select spaces
  - Console mode with Arcade, Versus, Training and Options; MiSTer starts in
    Console mode
  - Updated stage select in Versus and Training, with previews and inline
    handicap
  - Two extra Saturn colors for the ordinary fighters, with matching portraits
    and effects, and correct colors in mirror matches; select with HP or HK
  - Full English Restoration content in the USA build: win quotes translated
    from the Japanese, restored Apocalypse conversations, complete endings and
    speaker labels
  - Pause with Coin or a Start hold, immediate Quit to the title, and Options
    settings that persist
  - Japan build with the original Japanese text, a Japanese Apocalypse
    conversation and ending, and Japanese service menus
  - Hold Start on Chun-Li for about two seconds to preview her alternate
    outfit; eight Turbo levels plus Normal

BUILD THE GAME

Run python3 apply.py in a terminal for guided setup.
On Windows use py -3.13 apply.py.
Choose your media folder, platform, region and output folder.
Run python3 apply.py --help for command-line options.

BUILDS IN THIS DOWNLOAD

    usa        USA
    japan      Japan

HOW TO APPLY (recommended)

    python3 apply.py /path/to/xmvsfj.zip --out-dir out

This checks every file against the original, applies the patches, checks
the result, and writes everything you need for every build (add
--variant <build> to make just one):

  USA:
    MAME:                     out/mame/usa/xmvsfj.zip
    HBMAME:                   out/hbmame/xmvsfex.zip
    FBNeo:                    out/fbneo/xmvsfex.zip
    MiSTer:                   out/mister/_Arcade/_Arcade Patches/_Enhanced Versions/X-Men Vs. Street Fighter EX (USA).mra
  Japan:
    MAME:                     out/mame/japan/xmvsfj.zip
    HBMAME:                   out/hbmame/xmvsfexj.zip
    FBNeo:                    out/fbneo/xmvsfexj.zip
    MiSTer:                   out/mister/_Arcade/_Arcade Patches/_Enhanced Versions/X-Men Vs. Street Fighter EX (Japan).mra

FBNeo: use --platform fbneo --out-dir out for complete game ZIPs.
Keep their ZIP and member names. Use an FBNeo version with definitions
matching this game release; older versions may reject its checksums.


Merged, split and complete sets work, including nested or renamed ROMs.
Use --rompath DIR (repeatable) to search a collection instead of naming the
zip, and --check to check inputs before building. ZIPs and extracted folders
need no extra software; 7z archives need 7-Zip.
QSound can stay in your emulator's ROM path; valid firmware already
in a source set is kept in complete outputs.

MAME: put xmvsfj.zip from out/mame/ ahead of the stock set in your MAME
rompath (one build at a time: they share the set name).
MAME's game menu won't start a set with patched ROMs, so start it from the
command line: mame xmvsfj. MAME shows checksum warnings for the patched
ROMs; that's expected and the game runs normally.
To start it from a menu, use the HBMAME build.

HBMAME: use a build containing the xmvsfex, xmvsfexj set definitions.
Upstream HBMAME support is pending.
Put xmvsfex.zip, xmvsfexj.zip and qsound.zip in HBMAME's roms/ folder;
it holds the complete set.

MiSTer: copy the _Arcade folder from out/mister/ to the root of your SD card
and keep the stock, unmodified romset at games/mame/xmvsfj.zip (split MAME
sets also need qsound.zip). The MRA applies the patch in memory as the
game loads, so nothing on the card is modified. You need Jotego's jtcps2
core, which update_all installs. The MRAs are also a separate download.

HOW TO APPLY (any IPS patcher)

Extract xmvsfj.zip, apply each file in ips/<build>/ to the ROM file of the
same name (Flips, Lunar IPS, or any IPS tool), then re-zip everything
as xmvsfj.zip.

CHANGED FILES

  USA (--variant usa):
    xvs.01  (128 KB)  CRC32 3999e93a -> b28fa987
    xvs.05a  (512 KB)  CRC32 7db6025d -> 1f529c46
    xvs.06a  (512 KB)  CRC32 e8e2c75c -> d092a016
    xvs.07  (512 KB)  CRC32 08f0abed -> 3c5a5031
    xvs.09  (512 KB)  CRC32 9641f36b -> 0940b4c6
    xvs.13m  (4.0 MB)  CRC32 f6684efd -> cf87c0be
    xvs.15m  (4.0 MB)  CRC32 29109221 -> 3a12cda0
    xvs.17m  (4.0 MB)  CRC32 92db3474 -> 763cc53a
    xvs.19m  (4.0 MB)  CRC32 3733473c -> e3c599b0
    xvsj.03m  (512 KB)  CRC32 e2944372 -> 1c84f758
    xvsj.04m  (512 KB)  CRC32 c20b8524 -> 29ba42f3

  Japan (--variant japan):
    xvs.01  (128 KB)  CRC32 3999e93a -> b28fa987
    xvs.05a  (512 KB)  CRC32 7db6025d -> b955087d
    xvs.07  (512 KB)  CRC32 08f0abed -> ea60b417
    xvs.09  (512 KB)  CRC32 9641f36b -> 0940b4c6
    xvs.13m  (4.0 MB)  CRC32 f6684efd -> cf87c0be
    xvs.15m  (4.0 MB)  CRC32 29109221 -> 3a12cda0
    xvs.17m  (4.0 MB)  CRC32 92db3474 -> 763cc53a
    xvs.19m  (4.0 MB)  CRC32 3733473c -> e3c599b0
    xvsj.03m  (512 KB)  CRC32 e2944372 -> 2e1de732
    xvsj.04m  (512 KB)  CRC32 c20b8524 -> 1841d050

All other files in the set are unmodified.

LEGAL

This is a free, unofficial fan patch. It is not affiliated with or endorsed
by Capcom. All game titles, characters, and artwork remain the property of
their respective owners. You must own the game to use this patch. Do not
sell this patch or distribute it applied to a ROM image.
