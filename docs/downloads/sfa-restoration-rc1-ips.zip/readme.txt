ROM INPUT UPDATE

Merged, split, complete ZIP/7z archives and extracted ROM folders are accepted.
Use --rompath DIR (repeatable) to search a collection, or keep the existing archive argument.
Names may differ; required source contents are verified by size and strong hashes.
Use --check to verify arcade build inputs before reconstruction.
QSound is optional for game builds. Valid embedded firmware is preserved in complete game outputs.
Use --include-devices on CPS-2 kits to require and include firmware from separate archives.
Compact HBMAME outputs retain their stock-game and device dependencies.
7z input requires an installed 7-Zip executable; ZIP needs no extra archive software.
Original archives are never modified by collection discovery.

Street Fighter Alpha: Warriors' Dreams · English restoration
============================================================

Version:  rc1 (2026-10-13)
Target:   MAME set 'sfzj' (Street Fighter Zero (Japan 950727))
Hardware: Capcom CPS-2
Patch by: Steve Gordon (https://x.com/strygo)
Website:  https://arcadepatches.com/sfa-restoration/

ABOUT THIS PROJECT

Street Fighter Alpha's English versions have a smaller win-quote pool than
Street Fighter Zero in Japan. The English Restoration brings the Japanese pool
and its quote choices to the USA and Asia games, along with English rival
dialogue, endings and continue advice based on the Japanese script.

Win quotes are centered in a wider box. The Manual guard panel explains the
difference between Manual and Auto. Red blood, the Japanese Auto guard
default, Japanese move selection for computer opponents and Dramatic Battle
music return, along with Capcom's later fixes for guard behavior and Rose's
crouching heavy kick.

The USA build keeps Street Fighter Alpha's title and character names. Asia
keeps Street Fighter Zero's title with English text and export character
names. Japan keeps its Japanese text and names and receives the shared fixes.

This is a release candidate.

WHAT'S CHANGED

  - The Japanese win quotes in English, with Japan's quote selection and
    button choices
  - Rival dialogue, endings and continue advice translated from the Japanese
    game
  - A wider win-quote box with centered English text
  - The Manual guard panel explains itself
  - Red blood and Japan's Auto guard default
  - Japanese move selection for computer opponents and Dramatic Battle music
  - Capcom's November fixes for guard behavior and Rose's crouching heavy kick
  - USA, Asia and Japan builds

BUILDS IN THIS DOWNLOAD

    usa        USA (English)
    asia       Asia (English)
    japan      Japan (Japanese)

HOW TO APPLY (recommended)

    python3 apply.py /path/to/sfzj.zip --out-dir out

This checks every file against the original, applies the patches, checks
the result, and writes everything you need for every build (add
--variant <build> to make just one):

  USA (English):
    MAME:                     out/mame/usa/sfzj.zip
    HBMAME:                   out/hbmame/sfaru.zip
    MiSTer:                   out/mister/_Arcade/_Arcade Patches/_Restorations/Street Fighter Alpha (USA) [English Restoration].mra
  Asia (English):
    MAME:                     out/mame/asia/sfzj.zip
    HBMAME:                   out/hbmame/sfzra.zip
    MiSTer:                   out/mister/_Arcade/_Arcade Patches/_Restorations/_Asia/Street Fighter Zero (Asia) [English Restoration].mra
  Japan (Japanese):
    MAME:                     out/mame/japan/sfzj.zip
    HBMAME:                   out/hbmame/sfzrj.zip
    MiSTer:                   out/mister/_Arcade/_Arcade Patches/_Restorations/_Japan/Street Fighter Zero (Japan) [Restoration].mra

Merged, split and complete sets work, including nested or renamed ROMs.
Use --rompath DIR (repeatable) to search a collection instead of naming the
zip, and --check to check inputs before building. ZIPs and extracted folders
need no extra software; 7z archives need 7-Zip.
Keep your unmodified qsound.zip in the emulator's ROM path.
Device firmware is not copied into the game archives.

MAME: put sfzj.zip from out/mame/ ahead of the stock set in your MAME
rompath (one build at a time: they share the set name).
MAME's game menu won't start a set with patched ROMs, so start it from the
command line: mame sfzj. MAME shows checksum warnings for the patched
ROMs; that's expected and the game runs normally.
To start it from a menu, use the HBMAME build.
Keep your unmodified qsound.zip in MAME's ROM path.

HBMAME: the set definition (sfaru, sfzra, sfzrj) ships with the project;
an upstream HBMAME submission is pending.
The matching driver declarations are included in hbmame/sfarest.cpp.inc.
Put sfaru.zip, sfzra.zip, sfzrj.zip and qsound.zip in HBMAME's roms/ folder;
it holds the complete set.

MiSTer: copy the _Arcade folder from out/mister/ to the root of your SD card
and keep the stock, unmodified romset at games/mame/sfzj.zip (split MAME
sets also need qsound.zip). The MRA applies the restoration in memory as the
game loads, so nothing on the card is modified. You need Jotego's jtcps2
core, which update_all installs. The MRAs are also a separate download.

HOW TO APPLY (any IPS patcher)

Extract sfzj.zip, apply each file in ips/<build>/ to the ROM file of the
same name (Flips, Lunar IPS, or any IPS tool), then re-zip everything
as sfzj.zip.

CHANGED FILES

  USA (English) (--variant usa):
    sfz.04b  (512 KB)  CRC32 8b73b0e5 -> 8d9b2480
    sfz.05a  (512 KB)  CRC32 0810544d -> 8cf0a98f
    sfz.06  (512 KB)  CRC32 806e8f38 -> 63b58796
    sfz.14m  (2.0 MB)  CRC32 90fefdb3 -> abb29988
    sfz.16m  (2.0 MB)  CRC32 5354c948 -> 2be26e22
    sfz.18m  (2.0 MB)  CRC32 41a1e790 -> c0331453
    sfz.20m  (2.0 MB)  CRC32 a549df98 -> fa05882c
    sfzj.03c  (512 KB)  CRC32 f5444120 -> 1cc762a9

  Asia (English) (--variant asia):
    sfz.04b  (512 KB)  CRC32 8b73b0e5 -> 8d9b2480
    sfz.05a  (512 KB)  CRC32 0810544d -> 8cf0a98f
    sfz.06  (512 KB)  CRC32 806e8f38 -> 63b58796
    sfz.14m  (2.0 MB)  CRC32 90fefdb3 -> abb29988
    sfz.16m  (2.0 MB)  CRC32 5354c948 -> 2be26e22
    sfz.18m  (2.0 MB)  CRC32 41a1e790 -> c0331453
    sfz.20m  (2.0 MB)  CRC32 a549df98 -> fa05882c
    sfzj.03c  (512 KB)  CRC32 f5444120 -> c4e79fb7

  Japan (Japanese) (--variant japan):
    sfz.04b  (512 KB)  CRC32 8b73b0e5 -> 8d9b2480
    sfz.05a  (512 KB)  CRC32 0810544d -> fa9ceda6
    sfzj.03c  (512 KB)  CRC32 f5444120 -> 2c69cf4c

All other files in the set are unmodified.

LEGAL

This is a free, unofficial fan patch. It is not affiliated with or endorsed
by Capcom. All game titles, characters, and artwork remain the property of
their respective owners. You must own the game to use this patch. Do not
sell this patch or distribute it applied to a ROM image.

DARKSOFT OUTPUT

Use --platform darksoft --out-dir out, or --platform all.
Copy the game folder from out/darksoft/games to the card games folder.
Expanded hardware and streamed audio are not supported.
