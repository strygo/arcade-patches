#!/usr/bin/env python3
"""Run an actual kit with third-party imports and compiler subprocesses refused."""

# BEGIN ARCADE PYTHON BOOTSTRAP
import sys as _arcade_sys
from pathlib import Path as _ArcadePath
_arcade_sys.path.insert(0, str(_ArcadePath(__file__).resolve().parents[0]))
from kit_python import bootstrap as _arcade_bootstrap
_arcade_bootstrap()
# END ARCADE PYTHON BOOTSTRAP
import argparse,hashlib,importlib.abc,json,os,runpy,shlex,sys
from pathlib import Path


def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--kit',required=True,type=Path);p.add_argument('--receipt',required=True,type=Path);p.add_argument('--helper-host',help='qualification-only cross-architecture execution')
 a,argv=p.parse_known_args();kit=a.kit.resolve()
 if argv and argv[0]=='--':argv=argv[1:]
 if any('site-packages' in s for s in sys.path):raise RuntimeError('Invoke Python with -S')
 calls=[];blocked=[]
 if a.helper_host:
  sys.path.insert(0,str(kit/'sound/tools'))
  import fetch_switch_tools
  fetch_switch_tools.host_id=lambda:a.helper_host
 class NoNumPy(importlib.abc.MetaPathFinder):
  def find_spec(self,fullname,path=None,target=None):
   if fullname.split('.')[0]=='numpy':
    blocked.append(fullname);raise ImportError('NumPy is forbidden in compiler-free qualification')
 sys.meta_path.insert(0,NoNumPy())
 def audit(event,args):
  if event=='subprocess.Popen':
   program=args[0]
   if program is None:
    command=args[1]
    program=shlex.split(command,posix=False)[0] if isinstance(command,str) else command[0]
   executable=Path(os.fsdecode(program).strip('"')).name.lower();calls.append(executable)
   stem=executable.removesuffix('.exe')
   if stem in ('git','cmake','make','ninja','cc','c++','gcc','g++','clang','clang++','cl','pip') or 'gcc' in stem or 'clang' in stem:
    raise RuntimeError('Compiler/source setup invoked: '+executable)
 sys.addaudithook(audit);sys.path.insert(0,str(kit));sys.argv=[str(kit/'apply.py'),*argv]
 code=0
 try:runpy.run_path(str(kit/'apply.py'),run_name='__main__')
 except SystemExit as exc:
  code=exc.code if isinstance(exc.code,int) else (0 if exc.code is None else 1)
  raise
 except BaseException:
  code=1;raise
 finally:
  a.receipt.parent.mkdir(parents=True,exist_ok=True)
  a.receipt.write_text(json.dumps(dict(schema=1,exit_code=code,third_party_site_packages_disabled=True,numpy_imports=blocked,
   compiler_calls_refused=True,helper_host_override=a.helper_host,subprocess_counts={n:calls.count(n)for n in sorted(set(calls))},
   kit_sha256=hashlib.sha256((kit/'kit.json').read_bytes()).hexdigest()),indent=2,sort_keys=True)+'\n')


if __name__=='__main__':main()
