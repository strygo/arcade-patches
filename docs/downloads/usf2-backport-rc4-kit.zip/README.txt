Ultra Street Fighter II — reconstruction kit



Version: rc4 (2026-10-23)

Backport by: Steve Gordon (https://x.com/strygo)



Ultra Street Fighter II: The Final Challengers is the 2017 Nintendo Switch edition of Super Street Fighter II Turbo, and it never had an arcade release. This backport rebuilds it as a CPS-2 game.

Akuma has his own select cell, and Evil Ryu and Violent Ken join the original sixteen fighters with their Ultra moves, colors and endings. Shin Akuma stays hidden, for twenty fighters in all.

Ultra's presentation comes with them: the Ultra title and intro, "The Final Challengers" lettering, a color select for the new fighters, and a choice of sixteen stages or Random once you have picked a fighter.

The Switch edition's sound effects play in every build, and on MiSTer its arranged music plays too. Choose MODERN or CLASSIC sound effects in ULTRA CONFIGURATION; on MiSTer you can choose the music there too.

The USA build is in English; the Japan build keeps the Japanese.

This is a release candidate.



Changes:

- Akuma on his own select cell, with Evil Ryu and Violent Ken: twenty fighters with the hidden Shin Akuma

- Ultra's classic colors for the new fighters, chosen on a color select screen

- Sixteen stages and Random to choose from after you pick a fighter

- The Ultra title and intro, and ULTRA on the VS, Continue and Game Over screens

- The Switch edition's sound effects, and its arranged music on MiSTer; MODERN or CLASSIC options

- USA (English) and Japan builds

INPUTS
  - Canonical MAME-format ssf2xj and its parent/shared members (ssf2t).
    Complete, merged, split ZIP/7z and loose layouts are supported by hash.
    7z needs installed 7-Zip. Supply canonical QSound dl-1425.bin as well.
  - USA base USF2 NSP or supported US card XCI for USA output; Japanese base
    NSP for Japanese output. XCI files are read directly; no conversion needed.
    Both are required when you explicitly select --region all. Supported identities are in kit.json.
    Container packaging may differ: the complete Program NCA and decrypted
    regional resource must match the supported hashes in kit.json. Filenames
    and the outer NSP/XCI hash are not acceptance criteria. Only declared
    Program variants are supported. Update-only images do not supply the base
    game; separately bundled updates are ignored, never applied.
  - Your own prod.keys. Keys are never bundled or downloaded.
  - Python 3.10+. No Git, CMake, C/C++ compiler or NumPy is required.
    The installer downloads the current host's pinned extraction helpers,
    verifies their archive and member SHA-256 hashes, and caches them.
  - MiSTer music generation fetches the pinned FFmpeg/ffprobe pair on demand.
    No separate FFmpeg installation is required. It uses fixed-point Opus
    decoding and the qualified ADX conversion. Any differing final music
    bytes fail the published CPK hash check.
    Advanced users can set CPSPLUS_FFMPEG to their own executable.

CHOOSE YOUR OUTPUT FIRST
  Target       Switches               Result
  MiSTer       --platform mister      Core, MRA, ROMs and music
  Stock MAME   --platform mame        hsf2/hsf2j ROM ZIP
  Darksoft     --platform darksoft    Best native-audio flash files
  HBMAME       --platform hbmame      Custom ROM ZIP + definitions
  Everything   --platform all         All supported outputs

  --platform is optional and defaults to all. Every supported output uses
  8 MiB with selectable MODERN/CLASSIC sound effects. Older commands with
  --audio 4, 8 or all are accepted and produce the same current 8 MiB output.
  The region follows the supplied game files: USA only, Japan only, or both.
  Use --region us, jp or all to override this; explicit all requires both.
  --source-us and --source-jp accept supported NSP/XCI inputs. --nsp-us/--nsp-jp
  remain aliases for existing commands; --xci-us/--xci-jp are also accepted.
  Only the US card variant has been qualified; a different region or changed
  Program NCA requires a separately verified identity.

  Darksoft uses the best 8 MiB CLASSIC/MODERN effects version with native music.
  Copy darksoft/games/usf2_us or usf2_jp to the card games folder. The menu
  identifies USF2 separately from HSF2. CPS+ streamed arrangements are
  unavailable on this target. Keep receipts and
  the verification folder on your computer; only the game folder goes on the card.

WINDOWS QUICK START (COMMAND PROMPT OR POWERSHELL)
  Extract the kit into a short local folder, for example C:\USF2. Open a
  terminal in that folder, containing apply.py. Put your arcade ZIPs in roms/,
  your USA base NSP in inputs/usf2-us.nsp and your keys in inputs/prod.keys.
  Keep complete paths in quotes if they contain spaces. Use the actual NSP
  filename, or rename your owned file to match these examples.

  Check dependencies:
    py -3 --version
  No compiler or Python package installation is required.

  MiSTer USA (paste this entire command on one line):
    py -3 apply.py --rompath roms --nsp-us inputs/usf2-us.nsp --keys inputs/prod.keys --region us --platform mister --work scratch-mister --out-dir output-mister

  Stock MAME USA (one line; does not require FFmpeg):
    py -3 apply.py --rompath roms --nsp-us inputs/usf2-us.nsp --keys inputs/prod.keys --region us --platform mame --work scratch-mame --out-dir output-mame

  Stock MAME USA from an XCI (one line):
    py -3 apply.py --rompath roms --source-us "inputs/USF2 USA.xci" --keys inputs/prod.keys --region us --platform mame --work scratch-xci --out-dir output-xci

  HBMAME USA (one line; matching emulator definitions are required below):
    py -3 apply.py --rompath roms --nsp-us inputs/usf2-us.nsp --keys inputs/prod.keys --region us --platform hbmame --work scratch-hbmame --out-dir output-hbmame

  If your Python command is python or python3, substitute it for py -3,
  --work and --out-dir are optional. Without --work, the installer uses a
  temporary scratch folder and removes it when the command finishes or fails.
  Without --out-dir, it chooses output-usf2 in your current folder, then
  output-usf2-2, output-usf2-3, etc. if needed. An explicit output folder must
  not already exist; existing results are never overwritten.
  Setup errors print a short explanation. Add --debug to your command if
  you need the full Python traceback when reporting a problem.
  A MiSTer build checks for FFmpeg before extracting game resources.

  Paths may be relative to the terminal's current folder or absolute. For
  example, --nsp-us "D:\Switch dumps\USF2 USA.nsp" is one argument. Do not
  paste the Unix backslash line continuations below into a Windows shell.
  One Windows recipient reported success using local subfolders after failures
  with absolute paths; the failing command and diagnostics are not available
  to establish the cause. If affected, use the layout and commands above with
  a fresh --work directory. Keep the full failing command and console output
  for diagnosis. Prefer a short local --work path over network/mapped drives
  or cloud-synced folders for extraction and reconstruction.

BUILD ALL OUTPUTS
  macOS/Linux shell (both regional NSPs):
  python3 apply.py --rompath ROM_DIRECTORY --nsp-us USA_BASE.nsp \
    --nsp-jp JAPAN_BASE.nsp --keys prod.keys --work scratch --out-dir output \
    --platform all

  --region us|jp|all      Optional override; otherwise inferred from game files.
  --out-dir PATH         Optional fresh destination (default: unused output-usf2).
  --work PATH            Optional scratch folder to retain instead of a temporary one.
  --platform mame|hbmame|mister|darksoft|all (default: all).
  --check                Verify arcade inputs and decrypt NSP/XCI resources only.

  The installer checks input paths and arcade ROMs before preparing helpers
  or extracting game resources. Missing-file errors show the supplied path,
  resolved path and current folder. On Windows, inputs/game.nsp is relative
  to the current folder; /inputs/game.nsp starts at the current drive root.
  Valid absolute paths are supported and are never silently rewritten.
  It prints each major stage, then lists the finished ZIPs and the launch or
  copy instructions for your selected target.

  Output must be fresh. Inputs are never modified. The build stages privately
  and publishes the completed tree only after exact ROM/MRA/music checks pass.
  Source tools are fetched as pinned verified binaries; no game data is downloaded.

OFFLINE TOOLS AND CACHE
  --tools-bundle PATH    Use the offline tools ZIP or directory of per-host ZIPs.
                        No helper downloads are attempted when this is supplied.
  --tools-cache PATH     Choose the shared verified helper cache location.
  --offline              Never download helpers; require a cache or tools bundle.

  Download the matching offline tools bundle on a connected computer, copy it
  alongside this kit, then add --tools-bundle cpsplus-tools-v2-offline.zip
  --offline to the normal apply.py command. Tools are selected for the current
  Python architecture. A missing host archive, changed helper or unsupported
  host fails before any helper is executed. Cached tools are rechecked on use.
  The toolkit never substitutes a different decoder or compiles a fallback.
  The combined bundle includes FFmpeg/ffprobe and their corresponding source.
  Shared tools and offline bundle:
  https://github.com/strygo/arcade-patches/releases/tag/ffmpeg-helpers-v1

OUTPUTS
  mame/hsf2.zip               USA, stock MAME (8 MiB MODERN/CLASSIC audio).
  mame/hsf2j.zip              Japan, stock MAME (8 MiB MODERN/CLASSIC audio).
  mame/RUN-MAME.txt           Launch commands for stock MAME.
  hbmame/<set>.zip            USA/Japan 8 MiB CLASSIC/MODERN game archives.
  definitions/*.cpp.inc       Exact ROM and GAME registrations for all four.
  mister/games/mame/          Complete native archives (firmware included).
  mister/games/CPS+/          The generated usf2_arrange.zip / CPK.
  mister/_Arcade/             Two 8 MiB CPS+ MRAs and the CPS2+ core.
  verification.json          Exact selected profile and assembled-image hashes.

  Copy the contents of mister/ to the MiSTer card. Both MRAs use the included
  CPS2+ core and require 128 MiB SDRAM. Demo sounds, MODERN sound effects and
  MODERN music are enabled by default. In Test Mode, ULTRA CONFIGURATION has
  SOUND EFFECTS and MUSIC, each using MODERN / CLASSIC. MUSIC appears only
  when the MRA enables it. The unmodified ROM hides it on emulators/hardware.
  Existing saved settings take precedence. Clear that launcher's NVRAM to
  reload the supplied MRA EEPROM defaults. MAME and HBMAME retain sequenced
  QSound music. MAME also offers MODERN/CLASSIC SOUND EFFECTS under Test Mode
  > ULTRA CONFIGURATION. Change with left/right and exit normally to save.
  Compact 4 MiB builds are retained only for internal legacy requirements.

MAME
  The MAME ZIPs run in unmodified MAME using its existing Hyper Street
  Fighter II loader. Keep them in a separate folder from original HSF2 ROMs.
  From your MAME folder, launch USA or Japan:
    mame hsf2 -rompath "FULL_PATH_TO_OUTPUT/mame" -nvram_directory nvram-usf2
    mame hsf2j -rompath "FULL_PATH_TO_OUTPUT/mame" -nvram_directory nvram-usf2
  MAME displays the Hyper Street Fighter II description and checksum warnings.
  Accept the warnings to play Ultra Street Fighter II. A frontend may hide
  sets that fail its ROM audit; use the command above in that case.
  The original USF2 program, graphics, key and sound data are preserved.

HBMAME
  The custom usf2t8/usf2j8 sets require matching compiled definitions.
  In a clean HBMAME source checkout, install them before compiling:
    python3 install_driver.py --driver PATH_TO_CPS2_CPP --list PATH_TO_GAME_LIST
  Use src/hbmame/drivers/cps2.cpp and src/hbmame/hbmame.lst. Both the
  C++ definitions and game-list registration are installed together. Existing
  conflicting USF2 definitions fail instead of being overwritten.
  Then build HBMAME and launch by usf2t8/usf2j8. Definitions for all four
  native profiles are included for custom emulator users.
  Emulators use native QSound music; CPK playback is a MiSTer CPS+ feature.

MUSIC ONLY
  python3 music.py --nsp USA_BASE.nsp --keys prod.keys \
    --work music-scratch --out usf2_arrange.cpk
  Use --source "USA_BASE.xci" for a supported card dump. --nsp and --xci are
  aliases for --source; both require the same content and final music checks.
  The normal MiSTer/all build does this automatically. No existing CPK is an
  input shortcut. Tracks, conversion, loop points and trigger mapping must
  reproduce the qualified arrangement exactly.

VERIFY AFTER MOVING THE OUTPUT
  python3 output/verify_output.py --root output

RECONSTRUCTION FORMAT
  Unchanged bytes come from canonical arcade inputs. Changed/added bytes are
  source-relative XOR deltas, compressed and masked using actual decrypted
  Switch resource bytes with separate payload identities. This includes authored
  and embedded donor art and the frozen converted game resources. The public
  download contains no usable artwork masters. A published input checksum is
  not a decryption key. This is an input dependency, not redistribution control
  over the files someone has already reconstructed.

  This frozen installer does not rerun the development artwork pipeline or
  artistic tools. The CPK is freshly generated from NSP/XCI music. Every result
  is checked against the selected native candidate before publication.

SOURCE AND LICENSES
  core/SOURCE_AND_LICENSE.txt and cps2_core_release.json identify the approved
  CPS+ binary, corresponding source revision and licenses. The bundled source
  tools carry their original notices. Do not distribute this kit together
  with reconstructed game archives, NSP/XCI files, keys or generated copyrighted audio.

CREDITS
  Akuma's imported artwork is Tyrone's, from Super Street Fighter II Turbo: New Legacy.
