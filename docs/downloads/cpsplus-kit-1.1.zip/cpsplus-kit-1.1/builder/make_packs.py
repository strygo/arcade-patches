#!/usr/bin/env python3
"""CPS+ pack generator — builds the audio packs from YOUR disc images.

This kit ships no game audio.  Every pack is generated on your machine from
CD/DVD rips you own, and verified byte-for-byte against the published pack
hashes, so what you hear is exactly what was authored and tested.

Quick start:
  1. Edit discs.toml (next to this script) and fill in paths for the discs
     you own, or pass them with --disc KEY=PATH.  Every entry is optional:
     a pack whose disc you do not have is skipped, by name.
  2. Run:   python3 make_packs.py
  3. Copy the contents of out/mister/ to your MiSTer SD card root.

out/mister/ is built for you, laid out like the card: the three cores, the
packs you built, and only the MRAs those packs can actually load.

Requirements: Python 3.11+, numpy, ffmpeg on PATH (ADX packs), and a 7-Zip
binary (7zz/7z) only if your rips are .7z archives.  The three X68000 MIDI
packs additionally need git, cmake and a C/C++ compiler (they build two
pinned open-source tools once) and your SC-55 ROM set -- see X68000.md.

Disk: a full run needs roughly 15 GB free.  About 1.8 GB of that is the packs
themselves; the rest is work/ -- extracted discs, decode cache and
intermediates -- which a successful build deletes for you.  Pass --cache to
keep it instead, which makes a re-run much faster.

Options:
  --list          show every pack, its required disc entries, and status
  --only NAME     build just one pack group (repeatable)
  --no-verify     skip the published-hash check (not recommended; a mismatch
                  usually means a bad rip or a changed ffmpeg ADX encoder)
  --disc KEY=PATH point at one disc without editing discs.toml, e.g.
                  --disc mtwins_pce_disc=/discs/chiki.7z (repeatable)
  --cache         keep work/ after a successful build, so a re-run can reuse
                  the extracted discs and decode cache
  --clean-only    delete work/ and exit, without building anything
  --jobs N        X68000 packs: render N songs at once (default: half your
                  cores); the SC-55 render is the slow part of those builds
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path

HERE = Path(__file__).resolve().parent          # kit/builder/
KIT = HERE.parent                               # kit root
OUT = KIT / "out" / "mister"                    # laid out like the SD card
GAMES = OUT / "games" / "CPS+"
PACKS_DIR = HERE / "work" / "packs"             # build_pack.py output
MRA_SRC = HERE / "mras"                         # master set, never modified
CORE_SRC = HERE / "cores"
MRA_OUT = OUT / "_Arcade" / "_CPS+"
CORE_OUT = OUT / "_Arcade" / "cores"
HASHES = json.loads((HERE / "pack_hashes.json").read_text())

# Pack groups: one build command each, in the same order as pack/README.md.
# (group, required disc keys, build argv (relative to builder/), produced cpks)
# argv None = special-cased in build_group(); an X68K(...) marker means the
# FLAC set is rendered first by make_x68k_flac.py, then built like any other.
def X68K(slug: str, mode: str) -> dict:
    return {"x68k": slug, "mode": mode}


GROUPS = [
    ("ffight",     ["ffight_us_disc", "ffight_jp_disc"], None,  # special-cased
     ["ffight_arrange", "ffight_arrange_jp"]),
    ("ffightae-cps2", ["ffight_us_disc"],
     ["ffightae-cps2", "--us-disc", "{ffight_us_disc}"],
     ["ffightae_cps2_arrange"]),
    ("ffight-ost", ["ffight_ost_dir"],
     ["ffight-ost", "--ost", "{ffight_ost_dir}"],
     ["ffight_snes", "ffight_x68k_fm", "ffight_x68k_midi"]),
    ("hsf2",       ["hsf2_ae_iso"],
     ["hsf2", "--iso", "{hsf2_ae_iso}"],
     ["hsf2_arrange"]),
    ("hsf2-cps1",  ["hsf2_ae_iso"],
     ["hsf2", "--iso", "{hsf2_ae_iso}", "--bank", "cps1"],
     ["hsf2_cps1"]),
    ("sf2",        ["hsf2_ae_iso"],
     ["sf2-arrange", "--iso", "{hsf2_ae_iso}"],
     ["sf2_arrange"]),
    ("ssf2",       ["hsf2_ae_iso"],
     ["ssf2-arrange", "--game", "ssf2", "--iso", "{hsf2_ae_iso}"],
     ["ssf2_arrange"]),
    ("ssf2t",      ["hsf2_ae_iso"],
     ["ssf2-arrange", "--game", "ssf2t", "--iso", "{hsf2_ae_iso}"],
     ["ssf2t_arrange"]),
    ("sfa1",       ["sfa1_saturn_disc"],
     ["sfa1-arrange", "--disc", "{sfa1_saturn_disc}"],
     ["sfa1_arrange"]),
    ("sfa2-snes",  ["anthology_iso"],
     # this builder writes next to its module unless told otherwise
     ["sfa2-snes", "--iso", "{anthology_iso}",
      "--out", "work/packs/sfa2_snes.cpk"],
     ["sfa2_snes"]),
    ("sfa2",       ["sfz2_saturn"],
     ["sfa2-arrange", "--game", "sfa2", "--iso", "{sfz2_saturn}"],
     ["sfa2_arrange"]),
    ("sfz2al",     ["sfz2dash_saturn"],
     ["sfa2-arrange", "--iso", "{sfz2dash_saturn}"],
     ["sfz2al_arrange"]),
    ("spf2t",      ["spf2t_saturn"],
     ["spf2t", "--disc", "{spf2t_saturn}"],
     ["spf2t_arrange"]),
    ("mtwins",     ["mtwins_pce_disc"],
     ["mtwins", "--disc", "{mtwins_pce_disc}"],
     ["mtwins_arrange"]),
    ("forgottn",   ["forgottn_pce_disc"],
     ["forgottn", "--disc", "{forgottn_pce_disc}"],
     ["forgottn_arrange"]),
    ("mbomber",    ["mbomber_fmt_disc"],
     ["mbomber", "--disc", "{mbomber_fmt_disc}"],
     ["mbomber_arrange"]),
    ("unsquad-snes", ["unsquad_ost_dir"],
     ["unsquad-snes", "--ost", "{unsquad_ost_dir}"],
     ["unsquad_snes"]),
    ("ghouls-x68k-midi", ["x68k_daimakaimura_disk", "sc55_rom_dir"],
     X68K("daimakaimura", "ghouls-x68k-midi"), ["ghouls_x68k_midi"]),
    ("sf2ce-x68k-midi",  ["x68k_sf2ce_disk", "sc55_rom_dir"],
     X68K("sf2ce", "sf2ce-x68k-midi"), ["sf2ce_x68k_midi"]),
    ("ssf2-x68k-midi",   ["x68k_ssf2_disk", "sc55_rom_dir"],
     X68K("ssf2", "ssf2-x68k-midi"), ["ssf2_x68k_midi"]),
]


def assemble_out() -> None:
    """Build out/mister/ into the shape of a MiSTer SD card.

    The cores always go out. An MRA only goes out once the one pack it names
    is in games/CPS+/, because MiSTer lists every MRA it finds and one whose
    pack is missing is a menu entry that fails on load. builder/mras/ stays
    untouched, so this is a copy rather than a shuffle, and re-running after
    building more packs simply emits more.
    """
    ref = re.compile(r'zip="/CPS\+/([A-Za-z0-9_]+)\.zip"')

    CORE_OUT.mkdir(parents=True, exist_ok=True)
    for f in sorted(CORE_SRC.iterdir()) if CORE_SRC.is_dir() else []:
        if f.is_file():
            shutil.copy2(f, CORE_OUT / f.name)

    GAMES.mkdir(parents=True, exist_ok=True)
    readme = HERE / "games_readme.txt"
    if readme.exists():
        shutil.copy2(readme, GAMES / "README.txt")

    emitted = held = 0
    for mra in sorted(MRA_SRC.rglob("*.mra")) if MRA_SRC.is_dir() else []:
        m = ref.search(mra.read_text(encoding="utf-8", errors="replace"))
        dst = MRA_OUT / mra.relative_to(MRA_SRC)
        if m and (GAMES / f"{m.group(1)}.zip").exists():
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(mra, dst)
            emitted += 1
        else:
            dst.unlink(missing_ok=True)          # a pack removed since last run
            held += 1
    for d in sorted(MRA_OUT.rglob("*"), reverse=True) if MRA_OUT.is_dir() else []:
        if d.is_dir() and not any(d.iterdir()):
            d.rmdir()

    print(f"\nout/mister/ holds {emitted} MRA(s) and the three cores.")
    if held:
        print(f"{held} MRA(s) are not in it, because the pack each one needs has "
              f"not been built.\nThey are still in builder/mras/, and appear here "
              f"once their pack exists.")


def load_discs() -> dict:
    import tomllib
    path = HERE / "discs.toml"
    if not path.exists():
        sys.exit("discs.toml not found — copy/edit the template next to this script")
    with open(path, "rb") as fh:
        raw = tomllib.load(fh)
    out, bad = {}, []
    for k, v in raw.items():
        if not isinstance(v, str) or not v.strip():
            continue
        p = Path(v).expanduser()
        if not p.is_absolute():
            p = (HERE / p).resolve()
        if not p.exists():
            bad.append((k, p))
            continue
        out[k] = p
    for k, p in bad:
        print(f"discs.toml: {k} points at {p}\n"
              f"            which does not exist, so it is being ignored")
    return out


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for blk in iter(lambda: fh.read(1 << 20), b""):
            h.update(blk)
    return h.hexdigest()


def stage_zip(cpk: Path, dest: Path) -> None:
    """STORED (-X -0) zip holding exactly the .cpk — the on-SD pack format."""
    dest.parent.mkdir(parents=True, exist_ok=True)
    tmp = dest.with_suffix(".zip.tmp")
    tmp.unlink(missing_ok=True)
    if shutil.which("zip"):
        r = subprocess.run(["zip", "-q", "-X", "-0", str(tmp.resolve()), cpk.name],
                           cwd=cpk.parent, capture_output=True)
        if r.returncode:
            sys.exit(f"zip failed for {cpk.name}: {r.stderr.decode()}")
    else:
        with zipfile.ZipFile(tmp, "w", zipfile.ZIP_STORED) as z:
            z.write(cpk, cpk.name)
    tmp.replace(dest)


def render_x68k(slug: str, archive: Path, rom_dir: Path, jobs: int) -> Path | None:
    """Run make_x68k_flac.py for one game; returns the FLAC dir, or None."""
    cmd = [sys.executable, str(HERE / "make_x68k_flac.py"), "--game", slug,
           "--archive", str(archive), "--sc55-rom-dir", str(rom_dir),
           "--work", str(HERE / "work" / "x68000"), "--jobs", str(jobs)]
    print(f"\n=== {slug}: python3 make_x68k_flac.py --game {slug} ...", flush=True)
    # Stream the driver's progress (a render can run for an hour) while
    # remembering its last line, which names the finished FLAC directory.
    proc = subprocess.Popen(cmd, cwd=HERE, stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT, text=True)
    last = ""
    assert proc.stdout is not None
    for line in proc.stdout:
        sys.stdout.write(line)
        sys.stdout.flush()
        if line.strip():
            last = line.strip()
    if proc.wait():
        return None
    flac_dir = Path(last) if last else None
    return flac_dir if flac_dir and flac_dir.is_dir() else None


def build_group(name, keys, argv, cpks, discs, verify, jobs=1) -> str:
    if isinstance(argv, dict):
        absent = [k for k in keys if k not in discs]
        if absent:
            return "skipped: needs " + ", ".join(absent)
        disk_key = next(k for k in keys if k.startswith("x68k_"))
        flac_dir = render_x68k(argv["x68k"], discs[disk_key],
                               discs["sc55_rom_dir"], jobs)
        if flac_dir is None:
            return "FAILED (X68000 render error above)"
        args = [argv["mode"], "--flac-dir", str(flac_dir)]
        produced = cpks
    elif name == "ffight":
        # region adapts to which discs you have
        have = [k for k in keys if k in discs]
        if not have:
            return "skipped: needs " + " or ".join(keys)
        if len(have) == 2:
            args = ["ffight", "--variant", "adx", "--region", "both",
                    "--us-disc", str(discs["ffight_us_disc"]),
                    "--jp-disc", str(discs["ffight_jp_disc"])]
            produced = cpks
        elif "ffight_us_disc" in discs:
            args = ["ffight", "--variant", "adx", "--region", "us",
                    "--us-disc", str(discs["ffight_us_disc"])]
            produced = ["ffight_arrange"]
        else:
            args = ["ffight", "--variant", "adx", "--region", "jp",
                    "--jp-disc", str(discs["ffight_jp_disc"])]
            produced = ["ffight_arrange_jp"]
    else:
        absent = [k for k in keys if k not in discs]
        if absent:
            return "skipped: needs " + ", ".join(absent)
        args = [a.format(**{k: str(v) for k, v in discs.items()}) for a in argv]
        produced = cpks

    print(f"\n=== {name}: python3 build_pack.py {' '.join(args)}")
    PACKS_DIR.mkdir(parents=True, exist_ok=True)
    r = subprocess.run([sys.executable, str(HERE / "build_pack.py")] + args,
                       cwd=HERE)
    if r.returncode:
        return "FAILED (build error above)"

    # sf2/sf2ce/sf2hf share one pack: all six MRAs name sf2_arrange, so
    # building a separate clone per MRA would put 217 MB of byte-identical
    # duplicate audio on the card.

    results = []
    for pack in produced:
        cpk = PACKS_DIR / f"{pack}.cpk"
        if not cpk.exists():
            results.append(f"{pack}: FAILED (no output)")
            continue
        digest = sha256(cpk)
        want = HASHES.get(pack)
        if verify and want and digest != want:
            results.append(
                f"{pack}: HASH MISMATCH (built {digest[:12]}, published "
                f"{want[:12]}) — bad rip or different ffmpeg ADX encoder; "
                f"pack NOT staged (rerun with --no-verify to stage anyway)")
            continue
        stage_zip(cpk, GAMES / f"{pack}.zip")
        tag = "ok, verified" if (verify and want) else "ok (unverified)"
        results.append(f"{pack}: {tag} -> games/CPS+/{pack}.zip")
    return "; ".join(results)


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--list", action="store_true")
    ap.add_argument("--only", action="append", default=[])
    ap.add_argument("--no-verify", action="store_true")
    ap.add_argument("--disc", action="append", default=[], metavar="KEY=PATH",
                    help="supply one disc on the command line instead of "
                         "editing discs.toml, e.g. --disc "
                         "mtwins_pce_disc=/discs/chiki.7z (repeatable; wins "
                         "over discs.toml)")
    ap.add_argument("--cache", action="store_true",
                    help="keep work/ after a successful build; the extraction "
                         "and decode cache makes a re-run much faster")
    # A successful build has removed work/ by default since the flag below was
    # the way to ask for it; accept it so older instructions still work.
    ap.add_argument("--clean", action="store_true", help=argparse.SUPPRESS)
    ap.add_argument("--clean-only", action="store_true",
                    help="delete work/ and exit -- reclaim the disk without "
                         "rebuilding anything; your packs are not touched")
    ap.add_argument("--jobs", type=int, default=max(1, (os.cpu_count() or 2) // 2),
                    help="X68000 packs: songs to render at once (default: "
                         "half your cores)")
    args = ap.parse_args()

    # Before load_discs(): reclaiming disk must not need a filled-in discs.toml.
    if args.clean_only:
        work = HERE / "work"
        if not work.is_dir():
            print("nothing to clean -- work/ does not exist")
            return 0
        mb = sum(f.stat().st_size for f in work.rglob("*") if f.is_file()) / 1e6
        shutil.rmtree(work)
        print(f"removed work/ ({mb/1000:.1f} GB); the packs in "
              f"{GAMES} are untouched.")
        return 0

    discs = load_discs()
    known = {k for _, keys, _, _ in GROUPS for k in keys}
    for item in args.disc:
        key, _, val = item.partition("=")
        key, val = key.strip(), val.strip()
        if not val:
            sys.exit(f"--disc wants KEY=PATH, got {item!r}")
        if key not in known:
            sys.exit(f"--disc: no such disc {key!r}.\nKnown discs: "
                     + ", ".join(sorted(known)))
        path = Path(val).expanduser()
        if not path.is_absolute():
            path = (Path.cwd() / path).resolve()
        if not path.exists():
            sys.exit(f"--disc {key}: {path} does not exist")
        discs[key] = path
    if args.list:
        for name, keys, _, cpks in GROUPS:
            have = all(k in discs for k in keys) or (
                name == "ffight" and any(k in discs for k in keys))
            print(f"{name:16} needs: {', '.join(keys)}  "
                  f"[{'ready' if have else 'missing'}]  -> {', '.join(cpks)}")
        return 0

    # Preflight, before any disc is touched: both of these surface deep inside
    # a build otherwise, as a raw traceback, after the packs that do not need
    # them have already spent an hour encoding.
    if shutil.which("ffmpeg") is None:
        print("WARNING: ffmpeg not on PATH — ADX packs will fail to build.")
    try:
        import numpy  # noqa: F401
    except ImportError:
        print("WARNING: numpy not installed — packs whose audio is ADX-encoded "
              "here (rather than copied from the disc) will fail to build.\n"
              "         install it with:  python3 -m pip install numpy")
    if any(k.startswith("x68k_") for k in discs):
        for tool in ("git", "cmake"):
            if shutil.which(tool) is None:
                print(f"WARNING: {tool} not on PATH — the X68000 MIDI packs "
                      f"build two pinned open-source tools and will fail "
                      f"without it (see X68000.md).")
        if "sc55_rom_dir" not in discs:
            print("WARNING: X68000 disk images are listed but sc55_rom_dir is "
                  "not — the X68000 MIDI packs also need your SC-55 ROM set.")

    summary = []
    for name, keys, argv, cpks in GROUPS:
        if args.only and name not in args.only:
            continue
        outcome = build_group(name, keys, argv, cpks, discs,
                              verify=not args.no_verify, jobs=args.jobs)
        summary.append((name, outcome))

    print("\n================ summary ================")
    built = skipped = failed = 0
    for name, outcome in summary:
        print(f"{name:12} {outcome}")
        if outcome.startswith("skipped"):
            skipped += 1
        elif "FAILED" in outcome or "MISMATCH" in outcome:
            failed += 1
        else:
            built += 1
    print(f"\n{built} group(s) built, {skipped} skipped, {failed} failed")
    if skipped:
        print("Skipped groups are waiting on a discs.toml entry, named above. "
              "Fill it in and re-run to add those packs.")
    assemble_out()
    print(f"\nCopy the contents of {OUT} to your MiSTer SD card root.")

    # The finished packs live in games/CPS+/; work/ is only extraction cache and
    # intermediates, and it dwarfs them -- so a build that got everything clears
    # it.  Never remove it when anything failed: that is exactly when the cache
    # saves the re-run.
    work = HERE / "work"
    if work.is_dir():
        mb = sum(f.stat().st_size for f in work.rglob("*") if f.is_file()) / 1e6
        if failed:
            print(f"\nwork/ kept ({mb/1000:.1f} GB) because {failed} group(s) "
                  f"failed -- the cache makes the re-run much faster. Delete it, "
                  f"or run --clean-only, once you are done.")
        elif not built:
            print(f"\nwork/ kept ({mb/1000:.1f} GB): this run built nothing, so "
                  f"there is nothing to tidy up after. Run --clean-only to "
                  f"reclaim it.")
        elif args.only:
            print(f"\nwork/ kept ({mb/1000:.1f} GB): --only builds part of the "
                  f"set, and the cache belongs to the rest of it. Run "
                  f"--clean-only when you are done.")
        elif args.cache:
            print(f"\n--cache: work/ kept ({mb/1000:.1f} GB of extraction cache "
                  f"and intermediates). Run --clean-only to reclaim it.")
        else:
            shutil.rmtree(work)
            print(f"\nremoved work/ ({mb/1000:.1f} GB of cache and "
                  f"intermediates); your packs are untouched. Pass --cache to "
                  f"keep it and speed up a re-run.")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
