This folder is where the CPS+ audio packs land when you run the builder:

    python3 ../builder/make_packs.py

The kit ships EMPTY here on purpose: the packs contain Capcom's arranged
soundtrack recordings, so they are generated on your machine from disc
images you own — never distributed.  After building, copy this games/
folder (together with _Arcade/) to your MiSTer SD card.
