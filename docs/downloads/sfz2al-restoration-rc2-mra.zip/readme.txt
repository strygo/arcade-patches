Street Fighter Zero 2 Alpha · English restoration
=================================================

Version:  rc2 (2026-10-11)
Target:   MAME set 'sfz2al' (Street Fighter Zero 2 Alpha (Asia 960826))
Hardware: Capcom CPS-2
Patch by: Steve Gordon (https://x.com/strygo)
Website:  https://arcadepatches.com/sfz2al-restoration/

ABOUT THIS PROJECT

Street Fighter Zero 2 Alpha is the updated Alpha 2, and its Asian version
plays in English. But that English script was a shortened one. Story scenes
lost pages, Evil Ryu borrowed Ryu's ending, and each fighter picked from four
random win quotes instead of the hundreds the Japanese game has.

The English Restoration is the Japanese script, in English. Every story and
ending page is back, in the Japanese order. Evil Ryu has his own ending again,
and his scene with Akuma. All 452 win quotes are here, picked by who you beat
and how much health you had left, just like in Japan. Where Capcom's English
said the same thing as the Japanese it's kept; everything else is newly
translated.

A few smaller things come along: red blood on hits, as in Japan; Birdie's
third victory pose, which the export version swapped out; English place names
on the next-stage map; and the Manual guard panel on the select screen now
explains itself.

The fighting follows the Japanese version, and the ROM sizes and key stay
stock, so it drops in over the Asian set in MAME, HBMAME, on MiSTer or on
original CPS-2 hardware. The same restoration is in the English builds of
Street Fighter Alpha 2 Gold.

This is a release candidate.

WHAT'S CHANGED

  - Every story page from the Japanese game, in the Japanese order, including
    the scenes the English script cut short
  - Evil Ryu's own ending, with his narration, instead of Ryu's
  - Evil Ryu's scene with Akuma, back in
  - All 452 win quotes from the Japanese game, in English, picked by opponent
    and remaining health, and centered on screen
  - Every ending in full, in English
  - Story, ending and quote text translated from the Japanese, keeping
    Capcom's English wherever it matched
  - Red blood on hits, as in Japan
  - English place names on the next-stage map, as in Japan
  - Win-quote pick by holding buttons, as in Japan
  - A REGULATION setting for white blood (off by default)
  - Birdie's third victory pose, back
  - The Manual guard panel explains itself
  - Computer opponents and two-player damage as in the Japanese version

MISTER SETUP

1. Copy the _Arcade/ folder from this download to the root of your
   MiSTer SD card (the MRA lands in _Arcade/_Arcade Patches/_Restorations/), or copy
   "Street Fighter Zero 2 Alpha (Asia) [English Restoration].mra" anywhere under _Arcade/.
2. Have the stock, unmodified romset at games/mame/sfz2al.zip
   (split sets also need the parent and QSound ZIPs named in the MRA).
3. You need Jotego's jtcps2 core; the standard MiSTer downloader /
   update_all installs it automatically.

The MRA references your original romset and applies the restoration in
memory while the game loads. Nothing on your SD card is modified. The
restoration keeps its own settings and saves under the name
'sfz2alr'.

LEGAL

This is a free, unofficial fan patch. It is not affiliated with or endorsed
by Capcom. All game titles, characters, and artwork remain the property of
their respective owners. You must own the game to use this patch. Do not
sell this patch or distribute it applied to a ROM image.
