"""Public pack-side interface to the bundled media-tool runtime."""
from pathlib import Path
import sys

from ffmpeg_runtime import Executable, add_arguments, configure, resolve


def ffmpeg_exe():
    return resolve('ffmpeg')


def ffprobe_exe():
    return resolve('ffprobe')


def optional_tool(name):
    from fetch_optional_tools import resolve as optional
    return optional(name)


def disc_tool(name, *, fetch=True):
    from fetch_optional_tools import disc_tool as disc
    return disc(name, fetch=fetch)
