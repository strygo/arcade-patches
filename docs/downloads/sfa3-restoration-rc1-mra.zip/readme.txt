Street Fighter Alpha 3 · English restoration
============================================

Version:  rc1 (2026-10-11)
Target:   MAME set 'sfz3j' (Street Fighter Zero 3 (Japan 980904))
Hardware: Capcom CPS-2
Patch by: Steve Gordon (https://x.com/strygo)
Website:  https://arcadepatches.com/sfa3-restoration/

ABOUT THIS PROJECT

Street Fighter Alpha 3's US arcade version cut each character's win quotes
down to eight generic lines. The Japanese game also has a quote for each
opponent. This restoration brings back all 625 opponent-specific quotes, with
all 825 of the Japanese game's win quotes in English.

Detailed stage locations return in English, in the original stage panels.
Biographies, rival dialogue and endings follow the Japanese script in natural
English that fits each character. Capcom's English stays where it was
accurate, and Alpha 3 MAX's official wording is used where it fits.

The game uses the Japanese 980904 revision's gameplay and secret-character
access, with its original difficulty and Turbo 1 defaults. Regulation starts
OFF, restoring red hit blood and the full defeat and ending effects; the
operator can still switch it ON. The US arcade endings already contain the
same scenes and page timing, so this restoration preserves them.

Alpha branding in the animated intro, character selection, player
introductions and win screens, English A/X/V-ISM labels, descriptions and
score rankings, Western names in the intro and fights, title and entry
announcements, and English operator menus retain the USA presentation. It runs
in MAME and on MiSTer with the jtcps2 core. Supply your own original Japanese
sfz3j romset; split sets also need their sfa3 parent and QSound firmware.

This is a release candidate.

WHAT'S CHANGED

  - All 825 Japanese win quotes in English, including 625 opponent-specific
    quotes the US arcade version left out
  - All 24 detailed stage locations in English, centered in the original
    panels
  - Biographies, rival and boss dialogue, and endings that follow the Japanese
    script, keeping Capcom's wording where it was accurate
  - Japanese Regulation OFF by default, with its operator switch and
    uncensored effects
  - Japanese 980904 gameplay, difficulty, Turbo 1 defaults and secret-
    character access
  - Alpha branding in the intro, selection, player introductions and win
    screens; English A/X/V-ISM descriptions and score rankings, Western names,
    title and entry announcements, and operator menus

MISTER SETUP

1. Copy the _Arcade/ folder from this download to the root of your
   MiSTer SD card (the MRA lands in _Arcade/_Arcade Patches/_Restorations/), or copy
   "Street Fighter Alpha 3 (USA) [Restoration].mra" anywhere under _Arcade/.
2. Have the stock, unmodified romset at games/mame/sfz3j.zip
   (split sets also need the parent and QSound ZIPs named in the MRA).
3. You need Jotego's jtcps2 core; the standard MiSTer downloader /
   update_all installs it automatically.

The MRA references your original romset and applies the restoration in
memory while the game loads. Nothing on your SD card is modified. The
restoration keeps its own settings and saves under the name
'sfa3r'.

LEGAL

This is a free, unofficial fan patch. It is not affiliated with or endorsed
by Capcom. All game titles, characters, and artwork remain the property of
their respective owners. You must own the game to use this patch. Do not
sell this patch or distribute it applied to a ROM image.
