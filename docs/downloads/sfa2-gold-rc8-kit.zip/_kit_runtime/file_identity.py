"""Portable metadata stamps; Windows ctime is creation time, not change time."""
import os
from pathlib import Path


WINDOWS = os.name == 'nt'


def file_stamp(path, *, file_stat=None):
    path = Path(path)
    # DirEntry.stat() intentionally omits file IDs on Windows. Its cached
    # result cannot be compared with Path.stat() at a later boundary.
    value = path.stat() if WINDOWS or file_stat is None else file_stat
    # None explicitly means metadata cannot certify an unchanged file. Even
    # FILE_BASIC_INFO.ChangeTime mirrors restored mtime on some shared drives.
    # Consumers must recheck bytes rather than cache an authoritative result.
    change = None if WINDOWS else value.st_ctime_ns
    return (value.st_dev, value.st_ino, value.st_size, value.st_mtime_ns, change)
