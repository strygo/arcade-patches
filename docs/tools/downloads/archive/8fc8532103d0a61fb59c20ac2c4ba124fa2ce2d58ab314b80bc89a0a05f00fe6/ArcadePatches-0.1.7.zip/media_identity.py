"""Portable media identities, independent of compression and descriptive tags.

CHD and FLAC headers are discovery hints. Consumers must verify decoded data
and final outputs; a header claim is never a substitute for that verification.
"""
import hashlib
import importlib
import importlib.util
from pathlib import Path
import struct
import subprocess
import sys
import wave


def require(value, message):
    if not value:
        raise ValueError(message)


def companion(name):
    """Load only bundled helpers, including in Python's isolated mode."""
    if name in sys.modules:
        return sys.modules[name]
    root = Path(__file__).resolve().parent
    for path in (root / (name + '.py'), root / 'builder' / (name + '.py'),
                 root / 'builder/tools' / (name + '.py'), root / 'builder/pack' / (name + '.py')):
        if path.is_file():
            spec = importlib.util.spec_from_file_location(name, path)
            module = importlib.util.module_from_spec(spec);sys.modules[name] = module
            spec.loader.exec_module(module)
            return module
    return importlib.import_module(name)


def switch_authenticate(path, pin):
    return companion('switch_source').authenticate(path, pin)


def identify(stream, kind):
    stream.seek(0)
    if kind == 'chd':
        header = stream.read(124)
        require(header[:8] == b'MComprHD', 'Not a CHD')
        size, version = struct.unpack_from('>II', header, 8)
        require((version, size) in ((4, 108), (5, 124)) and len(header) >= size, 'Unsupported CHD header')
        at = 64 if version == 5 else 88
        logical_at = 32 if version == 5 else 28
        return dict(type='chd', data_sha1=header[at:at + 20].hex(),
                    logical_bytes=struct.unpack_from('>Q', header, logical_at)[0])
    if kind == 'pcm':
        magic = stream.read(4)
        if magic == b'fLaC':
            header = stream.read(4)
            require(len(header) == 4 and header[0] & 127 == 0 and int.from_bytes(header[1:], 'big') == 34,
                    'FLAC needs a complete STREAMINFO block')
            info = stream.read(34)
            require(len(info) == 34 and any(info[18:]), 'FLAC has no usable decoded-sample MD5')
            value = int.from_bytes(info[10:18], 'big')
            return dict(type='pcm', rate=value >> 44, channels=((value >> 41) & 7) + 1,
                        bits=((value >> 36) & 31) + 1, frames=value & ((1 << 36) - 1), md5=info[18:].hex())
        stream.seek(0)
        with wave.open(stream, 'rb') as audio:
            require(audio.getcomptype() == 'NONE', 'WAV must contain integer PCM')
            result = dict(type='pcm', rate=audio.getframerate(), channels=audio.getnchannels(),
                          bits=audio.getsampwidth() * 8, frames=audio.getnframes())
            digest = hashlib.md5()
            remaining = audio.getnframes() * audio.getsampwidth() * audio.getnchannels()
            while remaining:
                block = audio.readframes(65536)
                require(block and len(block) <= remaining, 'Truncated WAV')
                digest.update(block);remaining -= len(block)
            return dict(result, md5=digest.hexdigest())
    if kind == 'mp3':
        # Preserve the complete encoded payload, including gapless/decoder
        # information. Only outer ID3 tags are ignored.
        header = stream.read(10)
        start = 0
        if header[:3] == b'ID3':
            require(len(header) == 10 and all(v < 128 for v in header[6:]), 'Invalid ID3 size')
            start = 10 + sum(v << (7 * (3 - i)) for i, v in enumerate(header[6:]))
            if header[3] == 4 and header[5] & 16:
                start += 10
        stream.seek(0, 2);end = stream.tell()
        if end >= 128:
            stream.seek(end - 128)
            if stream.read(3) == b'TAG':end -= 128
        require(start < end, 'Empty MP3 payload')
        stream.seek(start);digest = hashlib.sha256();remaining = end - start
        while remaining:
            block = stream.read(min(1024 * 1024, remaining))
            require(block, 'Truncated MP3')
            digest.update(block);remaining -= len(block)
        return dict(type='mp3', payload_sha256=digest.hexdigest())
    raise ValueError('Unknown media identity type')


def matches(stream, contract):
    try:
        found = identify(stream, contract['type'])
    except (wave.Error, EOFError, struct.error) as error:
        raise ValueError('Malformed media header') from error
    return all(found.get(k) == v for k, v in contract.items())


def cue_identity(path):
    parse_cue = companion('extract_cdda').parse_cue
    entries, _ = parse_cue(Path(path))
    require(entries and [e[0] for e in entries] == sorted({e[0] for e in entries}), 'Invalid CUE track IDs')
    tracks = []
    for n, mode, source, i0, i1, pregap in entries:
        mode = mode.upper()
        require(mode == 'AUDIO' or mode in ('MODE1/2048', 'MODE1/2352', 'MODE2/2336', 'MODE2/2352'), 'Unsupported CUE mode')
        sector = 2352 if mode == 'AUDIO' else int(mode.split('/')[1])
        start = i0 if i0 is not None else i1
        following = [e for e in entries if e[0] > n and e[2] == source]
        end = ((following[0][3] if following[0][3] is not None else following[0][4]) * sector
               if following else source.stat().st_size)
        require(0 <= start <= i1 and start * sector <= end <= source.stat().st_size and
                end % sector == 0 and pregap >= 0, 'Invalid CUE track boundaries')
        digest = hashlib.sha256();length = end - start * sector + pregap * sector
        remaining_silence = pregap * sector
        while remaining_silence:
            block = bytes(min(remaining_silence, 1024 * 1024));digest.update(block);remaining_silence -= len(block)
        before = source.stat()
        with source.open('rb') as stream:
            stream.seek(start * sector);remaining = end - start * sector
            while remaining:
                block = stream.read(min(remaining, 8 * 1024 * 1024))
                require(block, 'Truncated CUE track');digest.update(block);remaining -= len(block)
        after = source.stat()
        require((before.st_ino, before.st_size, before.st_mtime_ns) == (after.st_ino, after.st_size, after.st_mtime_ns),
                'CUE image changed during identification')
        tracks.append(dict(track=n, mode=mode, bytes=length, sha256=digest.hexdigest(), index01=i1 - start + pregap))
    return dict(type='cue', tracks=tracks)


def verify(path, contract, tool):
    """Authenticate consumed data, including claims made by container headers."""
    path = Path(path)
    if contract['type'] == 'cue':
        require(cue_identity(path) == contract, 'Logical CUE tracks differ')
        return
    if contract['type'] == 'switch':
        switch_authenticate(path, contract['pin'])
        return
    with path.open('rb') as stream:
        require(matches(stream, contract), 'Media content identity differs')
        stream.seek(0);magic = stream.read(4)
    if contract['type'] == 'chd':
        subprocess.run([str(tool('chdman')), 'verify', '-i', str(path)], check=True,
                       stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
    elif contract['type'] == 'pcm' and magic == b'fLaC':
        require(contract['bits'] in (16, 24), 'Unsupported lossless audio depth')
        result = subprocess.run([str(tool('ffmpeg')), '-v', 'error', '-nostdin', '-i', str(path),
            '-map', '0:a:0', '-c:a', 'pcm_s16le' if contract['bits'] == 16 else 'pcm_s24le',
            '-f', 'md5', '-'], check=True, capture_output=True, text=True)
        require(result.stdout.strip() == 'MD5=' + contract['md5'], 'Decoded FLAC samples differ')


def validate(contract):
    require(isinstance(contract, dict), 'Invalid media identity')
    kind = contract.get('type')
    keys = {'chd': {'type', 'data_sha1', 'logical_bytes'},
            'pcm': {'type', 'rate', 'channels', 'bits', 'frames', 'md5'},
            'mp3': {'type', 'payload_sha256'}, 'switch': {'type', 'pin'}, 'cue': {'type', 'tracks'}}
    require(kind in keys and (set(contract) == keys[kind] or kind == 'chd' and
            set(contract) == {'type', 'data_sha1'}), 'Unknown or incomplete media identity')
    for key, length in [('data_sha1', 40), ('md5', 32), ('payload_sha256', 64)]:
        if key in contract:
            value = contract[key]
            require(isinstance(value, str) and len(value) == length and all(c in '0123456789abcdef' for c in value)
                    and any(c != '0' for c in value), 'Invalid media digest')
    for key in ('logical_bytes', 'rate', 'channels', 'bits', 'frames'):
        if key in contract:
            require(type(contract[key]) is int and contract[key] > 0, 'Invalid media dimensions')
    if kind == 'switch':
        pin = contract['pin']
        require(isinstance(pin, dict) and all(k in pin for k in ('program_name', 'program_sha256')), 'Invalid Switch pin')
    if kind == 'cue':
        require(isinstance(contract['tracks'], list) and 0 < len(contract['tracks']) <= 99, 'Invalid CUE track contract')
        for track in contract['tracks']:
            require(set(track) == {'track', 'mode', 'bytes', 'sha256', 'index01'} and
                    type(track['track']) is int and type(track['bytes']) is int and track['bytes'] > 0 and
                    type(track['index01']) is int and track['index01'] >= 0 and
                    len(track['sha256']) == 64, 'Invalid logical CUE track')
