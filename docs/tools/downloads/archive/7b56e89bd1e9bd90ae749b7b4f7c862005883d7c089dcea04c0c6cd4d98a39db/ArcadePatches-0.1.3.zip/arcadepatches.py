#!/usr/bin/env python3
"""Build a selected Arcade Patches collection. Requires Python 3.10 or newer."""
from __future__ import annotations

import argparse
import contextlib
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import platform
import re
import shutil
import signal
import stat
import subprocess
import sys
import sysconfig
import tempfile
import threading
import time
import urllib.parse
import urllib.request
import unicodedata
import uuid
import venv
import zipfile

VERSION = "0.1.3"
LOGO = r"""
     _    ____   ____    _    ____  _____
    / \  |  _ \ / ___|  / \  |  _ \| ____|
   / _ \ | |_) | |     / _ \ | | | |  _|
  / ___ \|  _ <| |___ / ___ \| |_| | |___
 /_/   \_\_| \_\\____/_/   \_\____/|_____|
  ____   _  _____ ____ _   _ _____ ____
 |  _ \ / \|_   _/ ___| | | | ____/ ___|
 | |_) / _ \ | || |   | |_| |  _| \___ \
 |  __/ ___ \| || |___|  _  | |___ ___) |
 |_| /_/   \_\_| \____|_| |_|_____|____/
""".strip("\n")
CATALOG = "https://arcadepatches.com/catalog/v1/index.json"
PLATFORMS = {"mister": "MiSTer", "mame": "MAME", "hbmame": "HBMAME",
             "fbneo": "FBNeo", "darksoft": "Darksoft"}
REGIONS = {"us": "USA", "jp": "Japan", "eu": "Europe", "asia": "Asia", "world": "World"}
FEATURES = {"native-dependencies-v1", "native-bindings-v1", "native-kit-v1", "native-context-v1", "file-inputs-v1", "archive-inputs-v1", "text-keys-v1", "input-options-v1", "output-options-v1", "external-tools-v1", "worker-timeout-v1", "locked-wheels-v1", "zip-outputs-v1",
            "disc-inputs-v1", "run-cache-v1", "target-regions-v1"}
LIMIT = 16 * 1024 * 1024
_UI = None


class TerminalUI:
    """Optional terminal decoration; plain logs and machine output stay plain."""
    COLORS = {'cyan': '36', 'green': '32', 'yellow': '33', 'red': '31'}
    STATUS = {'ready': 'cyan', 'available': 'cyan', 'built': 'green', 'current': 'green', 'failed': 'red',
              'blocked': 'yellow', 'unsupported': 'yellow', 'retired': 'yellow', 'pending': 'yellow'}

    def __init__(self, quiet=False, output=None, errors=None):
        self.quiet = quiet
        self.output, self.errors = output or sys.stdout, errors or sys.stderr
        self.color = self.animated = False
        self.state = None
        self.lock, self.stop = threading.RLock(), threading.Event()
        self.thread = None
        self.restore_modes = []

    @staticmethod
    def windows_mode(stream):
        import ctypes
        import msvcrt
        kernel = ctypes.WinDLL('kernel32', use_last_error=True)
        kernel.GetConsoleMode.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_ulong)]
        kernel.SetConsoleMode.argtypes = [ctypes.c_void_p, ctypes.c_ulong]
        handle = msvcrt.get_osfhandle(stream.fileno()); mode = ctypes.c_ulong()
        if not kernel.GetConsoleMode(handle, ctypes.byref(mode)):return None
        if not kernel.SetConsoleMode(handle, mode.value | 4):return None
        return lambda: kernel.SetConsoleMode(handle, mode.value)

    def __enter__(self):
        global _UI
        self.previous, _UI = _UI, self
        capable = (not self.quiet and 'NO_COLOR' not in os.environ and os.environ.get('TERM') != 'dumb'
                   and self.output.isatty() and self.errors.isatty())
        if capable and os.name == 'nt':
            try:
                for stream in (self.output, self.errors):
                    restore = self.windows_mode(stream)
                    if restore is None:capable = False; break
                    self.restore_modes.append(restore)
            except (ImportError, OSError, ValueError, AttributeError):capable = False
        self.color = self.animated = capable
        return self

    def __exit__(self, kind, value, traceback):
        global _UI
        self.stop.set()
        if self.thread is not None:self.thread.join(timeout=2)
        try:
            self.finish('Interrupted' if kind is KeyboardInterrupt else 'Stopped' if kind else '')
        finally:
            for restore in reversed(self.restore_modes):restore()
            _UI = self.previous

    def paint(self, text, color):
        return f'\033[{self.COLORS[color]}m{text}\033[0m' if self.color else text

    def clear_screen(self):
        if self.animated:
            self.output.write('\033[2J\033[H'); self.output.flush()

    @staticmethod
    def elapsed(seconds):
        minutes, seconds = divmod(int(max(0, seconds)), 60)
        return f'{minutes:02d}:{seconds:02d}'

    @staticmethod
    def fit(text, width):
        text = text.replace('\r', ' ').replace('\n', ' ')
        def cells(c):return 0 if unicodedata.combining(c) else 2 if unicodedata.east_asian_width(c) in 'WF' else 1
        if sum(map(cells, text)) <= width:return text
        result = ''; used = 0
        for char in text:
            size = cells(char)
            if used + size > max(0, width - 3):break
            result += char; used += size
        return result + '.' * min(3, max(0, width))

    def clear(self):
        if self.animated:self.errors.write('\r\033[2K')

    def render(self, frame=0):
        with self.lock:
            if not self.animated or self.state is None:return
            try:width = os.get_terminal_size(self.errors.fileno()).columns
            except (OSError, ValueError):width = shutil.get_terminal_size().columns
            state = self.state
            clock = ' | ' + self.elapsed(time.monotonic() - state['start'])
            budget = max(0, width - len(clock) - 3)
            label = self.fit(state['label'], budget // 2 if state['detail'] else budget)
            detail = ' | ' + self.fit(state['detail'], max(0, budget - len(label) - 3)) if state['detail'] else ''
            line = self.fit('|/-\\'[frame % 4] + ' ' + label + detail + clock, max(0, width - 1))
            self.clear(); self.errors.write(self.paint(line, 'cyan')); self.errors.flush()

    def animate(self):
        frame = 0
        while not self.stop.wait(0.1):
            self.render(frame); frame += 1

    def begin(self, label):
        self.state = {'label': label, 'detail': '', 'start': time.monotonic(), 'reported': time.monotonic()}
        if self.animated:
            if self.thread is None:
                self.thread = threading.Thread(target=self.animate, name='arcadepatches-progress', daemon=True)
                self.thread.start()
            self.render()
        else:print(label, file=self.errors, flush=True)

    def finish(self, outcome=''):
        with self.lock:
            if self.quiet or self.state is None:return
            state = self.state; self.clear()
            if self.animated and outcome:
                text = state['label'] + (' | ' + state['detail'] if state['detail'] else '')
                print(outcome + ': ' + text + ' | ' + self.elapsed(time.monotonic() - state['start']), file=self.errors, flush=True)
            elif not self.animated and state['detail']:print('  ' + state['detail'], file=self.errors, flush=True)
            self.errors.flush()
            self.state = None

    def phase(self, label):
        if self.quiet:return
        with self.lock:self.finish(); self.begin(label)

    def meter(self, text):
        if self.quiet:return
        with self.lock:
            if self.state is not None:
                self.state['detail'] = text
                if not self.animated and time.monotonic() - self.state['reported'] >= 2:
                    print(self.state['label'] + ' | ' + text, file=self.errors, flush=True)
                    self.state['reported'] = time.monotonic()

    def worker_phase(self, text):
        if self.quiet:return
        with self.lock:
            if self.animated:self.meter(text)
            else:print('  ' + text, file=self.errors, flush=True)

    @contextlib.contextmanager
    def activity(self, label):
        if self.quiet:yield self; return
        with self.lock:
            previous = self.state
            prefix = re.match(r'^\[\d+/\d+\]', previous['label']) if previous else None
            if prefix:label = prefix.group() + ' ' + label
            self.clear(); self.begin(label)
        try:yield self
        finally:
            with self.lock:self.finish(); self.state = previous; self.render()


@contextlib.contextmanager
def ui_activity(label):
    if _UI is None or _UI.quiet:yield None
    else:
        with _UI.activity(label) as ui:yield ui


def ui_meter(text):
    if _UI is not None:_UI.meter(text)


def byte_progress(count, total=None):
    def size(value):
        for unit in ('B', 'KiB', 'MiB', 'GiB'):
            if value < 1024 or unit == 'GiB':return f'{int(value)} B' if unit == 'B' else f'{value:.1f} {unit}'
            value /= 1024
    return (f'{size(count)} / {size(total)} ({count * 100 // total}%)'
            if total and count <= total else size(count))


class Error(Exception):
    """An actionable collection error."""


class ExportCleanupError(OSError):
    """The export committed successfully; backup cleanup remains retryable."""


def require(condition, message):
    if not condition:
        raise Error(message)


def digest(path):
    value = hashlib.sha256()
    path = Path(path); size = path.stat().st_size
    with path.open("rb") as stream:
        count = 0
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            value.update(block); count += len(block)
            if size >= 8 * 1024 ** 2:ui_meter('Verifying ' + path.name + ' | ' + byte_progress(count, size))
    return value.hexdigest()


def identity(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def read_json(path):
    require(Path(path).stat().st_size <= LIMIT, f"JSON file is too large: {path}")
    return json.loads(Path(path).read_text(encoding="utf-8"))


def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".new")
    with temporary.open("w", encoding="utf-8") as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, path)


def token(value):
    require(isinstance(value, str) and re.fullmatch(r"[a-z0-9][a-z0-9_-]*", value),
            f"Invalid stable ID: {value!r}")
    return value


def relative(value):
    require(isinstance(value, str) and value and not any(c in value for c in '\\:<>"|?*')
            and not any(ord(c) < 32 for c in value),
            f"Invalid relative path: {value!r}")
    path = PurePosixPath(value)
    require(not path.is_absolute() and all(p not in ("", ".", "..") for p in value.split("/")),
            f"Unsafe relative path: {value!r}")
    require(all(not p.endswith((" ", ".")) and p.split(".")[0].upper() not in
                {"CON", "PRN", "AUX", "NUL", *[f"COM{i}" for i in range(1, 10)],
                 *[f"LPT{i}" for i in range(1, 10)]} for p in path.parts),
            f"Nonportable relative path: {value!r}")
    return value


def safe_path(root, name):
    target = Path(root) / relative(name)
    require(target.resolve().is_relative_to(Path(root).resolve()), f"Path escapes its root: {name}")
    current = target
    while current != Path(root):
        require(not current.is_symlink(), f"Symlink is not allowed: {current}")
        current = current.parent
    return target


def file_contract(value, output=False):
    if output and isinstance(value,dict):
        require('any_of' not in value or set(value)=={'any_of'},'Ambiguous output alternatives')
        require('members' not in value or set(value)=={'members'},'Ambiguous ZIP output contract')
    if output and isinstance(value,dict) and set(value)=={'any_of'}:
        alternatives=value['any_of']
        require(isinstance(alternatives,list) and 1<len(alternatives)<=32,'Invalid output alternatives')
        require(all(isinstance(s,dict) and 'any_of' not in s for s in alternatives),'Nested output alternatives are unsupported')
        require(len({identity(s) for s in alternatives})==len(alternatives),'Duplicate output alternatives')
        for spec in alternatives:file_contract(spec,output=True)
        return
    if output and isinstance(value, dict) and set(value) == {"members"}:
        require(isinstance(value["members"], dict) and value["members"], "ZIP contract needs complete members")
        folded = set()
        for name, sha in value["members"].items():
            relative(name)
            require(name.casefold() not in folded, "ZIP contract has case aliases")
            folded.add(name.casefold())
            file_contract({"sha256": sha}, output=True)
        return
    require(isinstance(value, dict) and (output and "size" not in value or
            type(value.get("size")) is int and value["size"] >= 0),
            "A file contract requires a nonnegative size")
    require(isinstance(value.get("sha256"), str) and re.fullmatch(r"[0-9a-f]{64}", value["sha256"]),
            "A file contract requires SHA-256")
    require('crc32' not in value or isinstance(value['crc32'], str) and re.fullmatch('[0-9a-f]{8}', value['crc32']),
            'Invalid CRC32 in file contract')


def matches(path, contract):
    if not Path(path).is_file() or Path(path).is_symlink():
        return False
    if 'any_of' in contract:
        return any(matches(path,s) for s in contract['any_of'])
    if "members" in contract:
        try:
            with zipfile.ZipFile(path) as archive:
                names = archive.namelist()
                if len(names) != len(set(names)) or set(names) != set(contract["members"]):
                    return False
                return all(hashlib.sha256(archive.read(name)).hexdigest() == sha
                           for name, sha in contract["members"].items())
        except (zipfile.BadZipFile, RuntimeError):
            return False
    return ("size" not in contract or Path(path).stat().st_size == contract["size"]) and digest(path) == contract["sha256"]


def verify_outputs(root, expected):
    return set(tree_contract(root)) == set(expected) and all(matches(safe_path(root, name), spec) for name, spec in expected.items())


def estimated_size(spec):
    if 'any_of' in spec:return max(estimated_size(s) for s in spec['any_of'])
    return spec.get("size", 128 * 1024 ** 2 if "members" in spec else 16 * 1024 ** 2)


def host():
    machine = platform.machine().lower()
    if platform.system() == "Windows":
        # Windows ARM can run an AMD64 interpreter. Wheels must match that
        # interpreter, rather than the native machine reported by Windows.
        machine = {"win-amd64": "x86_64", "win-arm64": "arm64", "win32": "x86"}.get(
            sysconfig.get_platform(), machine)
    machine = {"amd64": "x86_64", "aarch64": "arm64"}.get(machine, machine)
    return f"{platform.system().lower()}-{machine}"


def version_tuple(value):
    require(isinstance(value, str) and re.fullmatch(r"[0-9]+\.[0-9]+\.[0-9]+", value),
            "Launcher version constraints must use major.minor.patch")
    return tuple(int(part) for part in value.split("."))


def validate_catalog(value):
    require(isinstance(value, dict) and value.get("schema") == 1, "Unsupported catalog schema; update the launcher")
    require(type(value.get("generation")) is int and value["generation"] >= 1, "Invalid catalog generation")
    for field in ("projects", "releases", "artifacts"):
        require(isinstance(value.get(field), dict), f"Catalog requires {field}")
    for key, artifact in value["artifacts"].items():
        token(key)
        file_contract(artifact)
        require(isinstance(artifact.get("url"), str), f"Artifact {key} needs a URL")
    for key, project in value["projects"].items():
        token(key)
        require(isinstance(project.get("title"), str), f"Project {key} needs a title")
        require(project.get("status", "active") in ("active", "retired"), "Unknown project lifecycle")
        require(project.get("current") in value["releases"], f"Project {key} has no current release")
    for key, release in value["releases"].items():
        token(key)
        require(isinstance(release.get("game_version"), str) and type(release.get("kit_revision")) is int,
                f"Release {key} needs game_version and kit_revision")
        require(isinstance(release.get("requires", []), list), "Release requires must be a list")
        version_tuple(release.get("minimum_launcher", "0.1.0"))
        require(isinstance(release.get("prerequisites"), dict), f"Release {key} needs prerequisites")
        for name, prereq in release["prerequisites"].items():
            token(name)
            require(all(isinstance(prereq.get(k), str) and prereq[k] for k in ("title", "action", "kind")),
                    f"Prerequisite {name} needs kind, title and action")
            require(isinstance(prereq.get("formats"), list) and prereq["formats"],
                    f"Prerequisite {name} needs accepted formats")
            if 'text_keys' in prereq:
                fields=prereq['text_keys']
                require('text-keys-v1' in release.get('requires',[]) and ('alternatives' not in prereq or prereq['alternatives']==[]) and
                    isinstance(fields,dict) and 0<len(fields)<=64 and
                    all(isinstance(k,str) and re.fullmatch(r'[a-z0-9_]+',k) and type(n) is int and 2<=n<=512 and n%2==0
                        for k,n in fields.items()), 'Invalid private key-file declaration')
            else:
                require(isinstance(prereq.get("alternatives"), list) and prereq["alternatives"],
                        f"Prerequisite {name} needs input alternatives")
            for alternative in prereq.get("alternatives",[]):
                file_contract(alternative)
        require(isinstance(release.get("targets"), dict) and release["targets"], "Release needs targets")
        destinations = {}
        for name, target in release["targets"].items():
            token(name)
            token(target.get("platform"))
            token(target.get("variant"))
            if "region" in target:
                token(target["region"])
            if "regions" in target:
                require("region" not in target and isinstance(target["regions"], list) and target["regions"]
                        and all(isinstance(r, str) for r in target["regions"])
                        and len(target["regions"]) == len(set(target["regions"])), "Invalid multi-region target")
                for region in target["regions"]:
                    token(region)
                require("target-regions-v1" in release.get("requires", []), "Multi-region targets need their capability")
            token(target.get("profile", "default"))
            require(isinstance(target.get("inputs"), list), "Target inputs must be a list")
            require(type(target.get("minimum_free_bytes", 0)) is int and target.get("minimum_free_bytes", 0) >= 0,
                    "Target storage requirement must be a nonnegative integer")
            require(isinstance(target.get("software_notes", []), list) and
                    all(isinstance(n, str) for n in target.get("software_notes", [])), "Invalid software notes")
            require(isinstance(target.get('destination_requirements',''),str),'Invalid destination requirements')
            require(len(target["inputs"]) == len(set(target["inputs"])), "Duplicate target prerequisites")
            require(all(p in release["prerequisites"] for p in target["inputs"]), "Unknown prerequisite reference")
            if 'timeout_seconds' in target:
                require('worker-timeout-v1' in release.get('requires',[]) and type(target['timeout_seconds']) is int and 1<=target['timeout_seconds']<=14400,'Invalid worker timeout')
            if 'external_tools' in target:
                require('external-tools-v1' in release.get('requires',[]) and isinstance(target['external_tools'],list) and len(target['external_tools'])<=16,'Invalid external software declarations')
                for tool in target['external_tools']:
                    require(isinstance(tool,dict) and all(isinstance(tool.get(k),str) and tool[k] for k in ('id','title','action','version_pattern')),'External software needs its identity, version and action')
                    token(tool['id'])
                    for key in ('commands','args'):
                        require(isinstance(tool.get(key),list) and 0<len(tool[key])<=16 and all(isinstance(n,str) and n and len(n)<=256 for n in tool[key]),'Invalid external software command')
                    require(all(re.fullmatch(r'[a-zA-Z0-9_.-]+',n) for n in tool['commands']),'External command must be a PATH program name')
                    for key in ('methods','hosts'):
                        require(isinstance(tool.get(key,[]),list) and all(isinstance(n,str) for n in tool.get(key,[])),'Invalid external software applicability')
                    require(len(tool['version_pattern'])<=256,'External version pattern is too long');re.compile(tool['version_pattern'])
            if 'input_options' in target:
                options=target['input_options']
                require('input-options-v1' in release.get('requires',[]) and isinstance(options,list) and 0<len(options)<=64,'Invalid target input options')
                seen=set()
                for option in options:
                    require(isinstance(option,dict) and set(option)=={'id','title','inputs'},'Invalid input option')
                    token(option['id']);require(option['id'] not in seen,'Duplicate input option');seen.add(option['id'])
                    require(isinstance(option['title'],str) and option['title'],'Input option needs a title')
                    names=option['inputs']
                    require(isinstance(names,list) and names and all(isinstance(n,str) and n in release['prerequisites'] for n in names) and len(set(names))==len(names),'Invalid input option prerequisites')
            require(isinstance(target.get("outputs"), dict) and target["outputs"], "Target needs complete outputs")
            for path, spec in target["outputs"].items():
                relative(path)
                file_contract(spec, output=True)
                require('any_of' not in spec or 'output-options-v1' in release.get('requires',[]),'Output options need their capability')
                folded = path.casefold()
                require(folded not in destinations.get(name, set()), "Case-colliding output paths")
                destinations.setdefault(name, set()).add(folded)
        require('adapter' not in release and 'payloads' not in release, 'Only native kit execution is supported')
        executor = release.get('runner', {})
        require('native-kit-v1' in release.get('requires', []) and executor.get('api') == 1,
                'Unknown native kit interface')
        require(executor.get('artifact') in value['artifacts'], 'Unknown kit executable artifact')
        relative(executor.get('entry'))
        require(isinstance(release.get("environments", {}), dict), "Invalid environment map")
        for env in release.get("environments", {}).values():
            require(isinstance(env.get("wheels"), list) and env["wheels"], "Environment needs locked wheels")
            require(all(w in value["artifacts"] for w in env["wheels"]), "Unknown wheel artifact")
            if "python" in env:
                require(isinstance(env["python"], list) and len(env["python"]) == 2 and
                        all(type(n) is int and n >= 0 for n in env["python"]), "Invalid environment Python version")
        for helpers in release.get("helpers", {}).values():
            require(isinstance(helpers, dict), "Helpers must be keyed by tool ID")
            for helper in helpers.values():
                require(helper.get("artifact") in value["artifacts"], "Unknown helper artifact")
                relative(helper.get("entry"))
    source_helpers = value.get('source_helpers', {})
    require(isinstance(source_helpers, dict), 'Invalid source helper map')
    for helpers in source_helpers.values():
        require(isinstance(helpers, dict) and set(helpers) == {'sevenzip'}, 'Invalid source archive helper')
        helper = helpers['sevenzip']
        require(isinstance(helper, dict), 'Invalid source helper entry')
        require(helper.get('artifact') in value['artifacts'], 'Unknown source helper artifact')
        relative(helper.get('entry'))
    return value


def allowed_url(url):
    parsed = urllib.parse.urlsplit(url)
    require(parsed.scheme == "https" and parsed.hostname == "arcadepatches.com"
            and parsed.port in (None, 443) and not parsed.username and not parsed.password,
            "Downloads must use HTTPS on arcadepatches.com")
    return url


class OfficialRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        allowed_url(newurl)
        return super().redirect_request(req, fp, code, msg, headers, newurl)


def fetch(url, destination, maximum):
    allowed_url(url)
    request = urllib.request.Request(url, headers={"User-Agent": f"ArcadePatches/{VERSION}"})
    name = re.sub(r'^[0-9a-f]{64}-', '', Path(urllib.parse.urlsplit(url).path).name)
    with ui_activity('Downloading ' + name) as ui, urllib.request.build_opener(OfficialRedirect()).open(request, timeout=30) as source:
        allowed_url(source.url)
        length = source.headers.get('Content-Length', '')
        total = int(length) if length.isdigit() and 0 < int(length) <= maximum else None
        with Path(destination).open("wb") as target:
            count = 0
            while block := source.read(1024 * 1024):
                count += len(block)
                require(count <= maximum, "Download exceeds its declared size limit")
                target.write(block)
                if ui:ui.meter(byte_progress(count, total))


def artifact_file(artifact, cache, offline=False, local_root=None):
    """Local artifact paths are accepted only with an explicitly local catalog."""
    destination = cache / artifact["sha256"]
    if matches(destination, artifact):
        os.utime(destination, None)
        return destination
    require(not offline, f"Verified artifact is not cached: {artifact['url']}")
    cache.mkdir(parents=True, exist_ok=True)
    temporary = destination.with_suffix(".part")
    try:
        if local_root is not None and artifact["url"].startswith("local:"):
            source = safe_path(local_root, artifact["url"][6:])
            require(matches(source, artifact), f"Local artifact differs: {source}")
            shutil.copyfile(source, temporary)
        else:
            fetch(artifact["url"], temporary, artifact["size"])
        require(matches(temporary, artifact), "Downloaded artifact hash/size mismatch")
        os.replace(temporary, destination)
        os.utime(destination, None)
    finally:
        temporary.unlink(missing_ok=True)
    return destination


def extract(archive, destination):
    """Reject links, aliases, duplicate paths and oversized expansion before writing."""
    with zipfile.ZipFile(archive) as source:
        entries = source.infolist()
        require(len(entries) <= 100000, "Too many archive entries")
        seen = set()
        total = 0
        for item in entries:
            name = relative(item.filename.rstrip("/"))
            require(name.casefold() not in seen, "Duplicate/case-colliding archive path")
            seen.add(name.casefold())
            mode = item.external_attr >> 16
            require(stat.S_IFMT(mode) in (0, stat.S_IFREG, stat.S_IFDIR), "Archive contains a special file")
            total += item.file_size
        require(total <= 4 * 1024 ** 3, "Kit archive expansion exceeds 4 GiB")
        require(shutil.disk_usage(destination.parent).free > total + 64 * 1024 ** 2, "Insufficient space for kit extraction")
        destination.mkdir()
        for item in entries:
            path = safe_path(destination, item.filename.rstrip("/"))
            if item.is_dir():
                path.mkdir(parents=True, exist_ok=True)
            else:
                path.parent.mkdir(parents=True, exist_ok=True)
                with source.open(item) as src, path.open("wb") as dst:
                    shutil.copyfileobj(src, dst)


class SourceDiscoveryCache:
    """Disposable stat-bound archive listings and source identifications."""
    def __init__(self, home):
        self.path = home / 'cache/source-discovery.json'
        self.data = {'schema': 1, 'archives': {}, 'keys': {}, 'digests': {}}
        try:
            require(self.path.stat().st_size <= 16 * 1024 ** 2, 'Discovery cache is too large')
            value = read_json(self.path)
            if value.get('schema') == 1 and all(isinstance(value.get(k), dict) for k in ('archives', 'keys', 'digests')):
                self.data = value
        except (OSError, ValueError, Error):pass

    def save(self):
        for name, limit in (('archives', 2048), ('keys', 8192), ('digests', 32768)):
            self.data[name] = dict(list(self.data[name].items())[-limit:])
        # Oversized or corrupt caches may always be discarded and rebuilt.
        if len(json.dumps(self.data)) > 16 * 1024 ** 2:
            self.data = {'schema': 1, 'archives': {}, 'keys': {}, 'digests': {}}
        write_json(self.path, self.data)


def source_marker(binding):
    config = binding.get('_7z', {})
    path = Path(config.get('archive', binding['path']))
    stat = path.stat()
    return identity({'path': str(path), 'member': config.get('member', binding.get('member')),
        'stat': [stat.st_dev, stat.st_ino, stat.st_size, stat.st_mtime_ns, stat.st_ctime_ns]})


def archived_key_candidate(binding):
    name = binding.get('_7z', {}).get('member', binding.get('member'))
    if name is None:return Path(binding['path']).suffix.lower() not in ('.zip', '.7z')
    name = Path(name).name.lower()
    return name.endswith('.keys') or name in ('keys.txt', 'prod.keys.txt', 'title.keys.txt')


def disc_diagnostic(spec, index, status, unreadable):
    """Explain discovery without hashing large images or guessing their identity."""
    pins = spec.get('alternatives', [])
    formats = sorted({p['format'].lower() for p in pins if p.get('format')})
    sizes = {p['size'] for p in pins}
    extensions = {'.iso', '.chd', '.cue', '.img', '.mdf', '.nrg', '.cso',
                  '.gdi', '.rvz', '.wbfs', '.isz', '.zso'}
    files = []
    counts = {}
    for size in sorted(index, key=lambda size: size not in sizes):
        candidates = index[size]
        for candidate in candidates:
            name = candidate.get('_7z', {}).get('member', candidate.get('member', candidate['path']))
            suffix = Path(name).suffix.lower()
            # Bare .bin files are commonly arcade ROMs, not disc images.
            if suffix not in extensions and suffix[1:] not in formats and size not in sizes:continue
            archived = 'member' in candidate or '_7z' in candidate
            reason = ('archived_image' if archived else
                      'format_not_declared' if formats and suffix in extensions and suffix[1:] not in formats else
                      'size_not_accepted' if size not in sizes else
                      'size_candidate' if status in ('candidate', 'found', 'ambiguous') else 'not_matched')
            counts[reason] = counts.get(reason, 0) + 1
            if len(files) < 20:
                item = {'path': candidate['path'], 'size': size, 'extension': suffix, 'reason': reason}
                if archived:item['member'] = name
                files.append(item)
    total = sum(counts.values())
    state = (status if status in ('found', 'candidate', 'ambiguous') else
             'unavailable' if unreadable or status == 'unavailable' else
             'absent' if not total else
             'unsupported' if set(counts) <= {'archived_image', 'format_not_declared'} else 'unrecognized')
    accepted = ', '.join(f.upper() for f in formats) or 'the catalog’s declared images'
    message = {'absent': 'No disc image candidates were found in the scanned media folders.',
               'unavailable': 'Media could not be fully checked; see source inspection issues.',
               'unsupported': 'Disc-like files were found, but their format or archive location is not declared by this kit.',
               'unrecognized': 'Disc-like files were found, but none matched this kit’s accepted image.',
               'candidate': 'A possible disc image was found; its contents are verified when building.',
               'found': 'An accepted disc image was found.',
               'ambiguous': 'Multiple accepted disc images were found.'}[state]
    action = message + ' This kit accepts: ' + accepted + '. '
    if state in ('unsupported', 'unrecognized') and 'archived_image' in counts:
        action += 'Extract disc images from their archives into a media folder. '
    if state in ('absent', 'unsupported', 'unrecognized'):
        action += 'Check the required game and region, image format, and selected media folders. '
        if files:
            action += 'Found: ' + '; '.join(Path(f.get('member', f['path'])).name + f" ({f['size']:,} bytes)" for f in files[:3]) + '. '
        action += 'See build-report.json for accepted sizes/hashes and candidate details.'
    return {'state': state, 'message': message, 'accepted_images': pins,
            'accepted_formats': formats, 'candidates': files, 'candidate_count': total,
            'omitted_candidates': max(0, total - len(files)), 'reason_counts': counts,
            'candidate_basis': 'Filename extensions and declared byte sizes; listed files may belong to other games. No image identity is inferred from a filename.',
            'identity_verified': status == 'found'}, action.strip()


def explain_disc(row, spec, index, unreadable):
    if spec.get('kind') == 'disc':
        row['disc_diagnostic'], row['action'] = disc_diagnostic(spec, index, row['status'], unreadable)
        declared = row['disc_diagnostic']['accepted_formats']
        if declared:row['formats'] = [f.upper() for f in declared]
    return row


def preview_inputs(prerequisites, target, index, unreadable):
    """Use sizes/CRCs only. A candidate is never a verified input binding."""
    def inputs(required):
        rows = []
        for key in required:
            spec = prerequisites[key]
            if 'text_keys' in spec:
                status = 'unchecked'
                action = 'Your private key file is checked when building. Keep it loose in a media folder, or use prod.keys/title.keys inside an archive.'
            else:
                candidates = [(pin, b) for pin in spec['alternatives'] for b in index.get(pin['size'], [])
                    if not (pin.get('crc32') and b.get('crc32') and pin['crc32'] != b['crc32'])]
                status = 'candidate' if candidates else 'unavailable' if unreadable else 'missing'
                action = spec['action']
            rows.append(explain_disc({'id': key, 'title': spec['title'], 'kind': spec['kind'], 'status': status,
                         'formats': spec['formats'], 'action': action}, spec, index, unreadable))
        return rows
    common = inputs(target['inputs']); options = []; chosen = None; chosen_rows = []
    for option in target.get('input_options', []):
        rows = inputs(option['inputs']) if chosen is None else []
        ready = all(row['status'] in ('candidate', 'unchecked') for row in rows)
        options.append({'id': option['id'], 'title': option['title'],
                        'status': 'not_checked' if chosen is not None else 'available' if ready else 'blocked', 'prerequisites': rows})
        if chosen is None and ready:chosen = option['id']; chosen_rows = rows
    if options and chosen is None:
        common.append({'id': 'input-method', 'title': 'One complete input method', 'kind': 'input method',
            'status': 'missing', 'formats': ['one of the methods below'], 'action': 'Supply one complete method; partial methods cannot be combined.'})
    existing = {row['id'] for row in common}
    common.extend(row for row in chosen_rows if row['id'] not in existing)
    return common, {}, options, chosen


class SevenZipSources:
    """List lazily and materialize candidate members inside this invocation only."""
    def __init__(self, catalog, home, offline=False, local_root=None, progress=None, discovery=None):
        self.catalog, self.home = catalog, filesystem_path(home)
        self.offline, self.local_root, self.progress = offline, local_root, progress
        self.temporary = None
        self.failure = None
        self.archive_count = 0
        self.discovery = discovery

    def __enter__(self):
        return self

    def __exit__(self, *args):
        if self.temporary is not None:self.temporary.cleanup()

    def tool(self):
        if self.failure:raise Error(self.failure)
        if self.temporary is None:
            require(host() in self.catalog.get('source_helpers', {}),
                    'This catalog has no 7z helper for this host; extract the archive and scan its folder')
            if self.progress and _UI is None:self.progress('Preparing verified 7-Zip source reader...')
            runs = self.home / 'runs'; runs.mkdir(parents=True, exist_ok=True)
            self.temporary = tempfile.TemporaryDirectory(prefix='sources-', dir=runs)
            self.root = filesystem_path(self.temporary.name)
            write_json(self.root / 'run-owner.json', {'schema': 1, 'home': str(self.home)})
            try:
                with ui_activity('Preparing verified 7-Zip source reader'):
                    self.executable = prepare_helpers({'helpers': self.catalog['source_helpers']}, self.catalog,
                        self.home / 'cache', self.root, self.offline, self.local_root)['sevenzip']
            except (Error, OSError, ValueError, subprocess.SubprocessError) as exc:
                self.failure = str(exc)
                raise
        return self.executable

    def members(self, path):
        tool = self.tool(); before = path.stat()
        folder = self.root / ('list-' + uuid.uuid4().hex); folder.mkdir()
        config = {'tool': tool, 'archive': str(path), 'limit': LIMIT,
                  'output': str(folder / 'listing'), 'operation': 'list',
                  'stat': [before.st_ino, before.st_size, before.st_mtime_ns]}
        self.archive_count += 1
        ui_meter(f'7z archive {self.archive_count}: {path.name}')
        marker = source_marker({'path': str(path)})
        listings = self.discovery.data['archives'] if self.discovery is not None else {}
        text = listings.get(marker)
        if not isinstance(text, str):
            sevenzip_run(config, folder, self.home / 'worker.lock', 120)
            text = (folder / 'listing').read_text(encoding='utf-8-sig')
            require(marker == source_marker({'path': str(path)}), '7z source changed while listing')
        if not text.strip():
            listings[marker] = text
            return
        seen = set(); count = 0; entries = []
        for block in text.replace('\r\n', '\n').strip().split('\n\n'):
            fields = {}
            for line in block.splitlines():
                require(' = ' in line, 'Unsupported 7z member metadata')
                key, value = line.split(' = ', 1)
                require(key not in fields, 'Ambiguous 7z member metadata')
                fields[key] = value
            require('Path' in fields, 'Missing 7z member path')
            name = relative(fields['Path'].replace('\\', '/')); folded = name.casefold()
            count += 1
            require(count <= 100000 and folded not in seen, 'Duplicate/case-colliding 7z members')
            seen.add(folded)
            require(not fields.get('Symbolic Link') and not fields.get('Hard Link') and
                    fields.get('Encrypted', '-') == '-' and
                    not re.search(r'(?:^|\s)[bclps][rwxstST-]{9}', fields.get('Attributes', '')),
                    'Encrypted archives and links are not supported as 7z sources')
            if fields.get('Folder') == '+' or fields.get('Attributes', '').startswith('D'):continue
            require(fields.get('Size', '').isdigit(), 'Invalid 7z member size')
            size = int(fields['Size']); key = identity({'archive': str(path), 'stat': config['stat'], 'member': name})
            candidate = {'path': str(self.root / (key + '.source')), '_7z': {
                **config, 'operation': 'extract', 'member': name, 'limit': size,
                'folder': str(folder), 'lease': str(self.home / 'worker.lock')}}
            crc = fields.get('CRC', '').lower()
            if re.fullmatch('[0-9a-f]{8}', crc):candidate['crc32'] = crc
            entries.append((size, candidate))
        listings[marker] = text
        yield from entries


def sevenzip_run(config, folder, lease, timeout=3600):
    path = folder / 'sevenzip.json'; write_json(path, config)
    code = run_supervised([sys.executable, '-I', '-S', '-B', str(Path(__file__).resolve()),
                           '_sevenzip', str(path)], folder, folder, timeout, lease)
    require(code == 0, '7z source could not be read (corrupt, encrypted, unsupported, changed, or insufficient space); extract it manually and retry')


def materialize_sevenzip(binding):
    if '_7z' not in binding:return
    target = filesystem_path(binding['path'])
    if target.exists():return
    config = dict(binding['_7z'], output=str(target))
    ui_meter('Reading ' + Path(config['member']).name + ' from ' + Path(config['archive']).name)
    sevenzip_run(config, filesystem_path(config['folder']), filesystem_path(config['lease']))


def read_sevenzip(config_path):
    config = read_json(config_path); archive = filesystem_path(config['archive']); before = archive.stat()
    require([before.st_ino, before.st_size, before.st_mtime_ns] == config['stat'], '7z source changed since discovery')
    output = filesystem_path(config['output']); limit = config['limit']
    require(shutil.disk_usage(output.parent).free > limit + 64 * 1024 ** 2, 'Insufficient space for selected 7z member')
    command = [config['tool'], 'l' if config['operation'] == 'list' else 'x', '-t7z', '-y', '-bd',
               '-sccUTF-8', '-bse0', '-pArcadePatches-does-not-open-encrypted-archives']
    if config['operation'] == 'list':command += ['-slt', '-ba']
    else:command += ['-so', '-spd', '-i!' + config['member']]
    command += ['--', subprocess_path(archive)]
    process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, stdin=subprocess.DEVNULL)
    try:
        size = 0
        with output.open('xb') as stream:
            while block := process.stdout.read(1024 * 1024):
                size += len(block); require(size <= limit, '7z output exceeds declared extent'); stream.write(block)
        require(process.wait(timeout=10) == 0 and (config['operation'] == 'list' or size == limit), 'Incomplete 7z source')
        after = archive.stat()
        require([after.st_ino, after.st_size, after.st_mtime_ns] == config['stat'], '7z source changed while reading')
    except BaseException:
        output.unlink(missing_ok=True)
        raise
    finally:
        if process.poll() is None:process.kill(); process.wait(timeout=10)
        process.stdout.close()


def index_sources(roots, excluded, archives=None):
    index, findings = {}, []
    checked = 0
    for root in roots:
        root = filesystem_path(root)
        ui_meter(f'{checked} files found | Opening {root.name or root}')
        if not root.is_dir():
            findings.append({"root": str(root), "status": "unavailable", "message": "Folder is unavailable"})
            continue
        def error(exc):
            findings.append({"root": str(root), "status": "unavailable", "message": str(exc)})
        for folder, dirs, files in os.walk(root, onerror=error, followlinks=False):
            ui_meter(f'{checked} files found | {Path(folder).name}')
            dirs[:] = sorted(d for d in dirs if d not in (".AppleDouble", "__MACOSX") and not (Path(folder) / d).is_symlink()
                             and not any((Path(folder) / d).resolve().is_relative_to(p) for p in excluded))
            for name in sorted(files):
                if name == ".DS_Store" or name.startswith("._"):
                    continue
                path = Path(folder) / name
                if path.is_symlink() or not path.is_file():
                    continue
                checked += 1
                ui_meter(f'{checked} files found | {name}')
                try:
                    # Containers can themselves be canonical disc/cartridge inputs.
                    index.setdefault(path.stat().st_size, []).append({"path": str(path)})
                    if path.suffix.lower() == ".zip":
                        ui_meter(f'{checked} files found | Reading ZIP {name}')
                        with zipfile.ZipFile(path) as archive:
                            members = archive.infolist()
                            require(len(members) <= 100000, "Too many source archive entries")
                            names = [m.filename for m in members]
                            require(len(names) == len(set(names)), "Duplicate source ZIP members")
                            for member in members:
                                if not member.is_dir():
                                    index.setdefault(member.file_size, []).append({"path": str(path), "member": member.filename,
                                                                                 "crc32": f"{member.CRC:08x}"})
                    elif path.suffix.lower() == '.7z':
                        require(archives is not None, '7z source needs the managed reader; use the launcher or extract it manually')
                        for size, candidate in archives.members(path):index.setdefault(size, []).append(candidate)
                except (OSError, Error, ValueError, subprocess.SubprocessError, zipfile.BadZipFile) as exc:
                    helper_failure = getattr(archives, 'failure', None)
                    finding = ({'root': '7-Zip source reader', 'kind': 'helper', 'status': 'unavailable',
                                'message': 'Could not prepare the archive reader: ' + helper_failure + '. Loose files and ZIPs are still checked.'}
                               if helper_failure else {'root': str(path), 'kind': 'archive', 'status': 'unavailable', 'message': str(exc)})
                    if finding not in findings:findings.append(finding)
    return index, findings


def source_digest(binding):
    materialize_sevenzip(binding)
    path = Path(binding["path"])
    before = path.stat()
    value = hashlib.sha256()
    with contextlib.ExitStack() as stack:
        if "member" in binding:
            archive = stack.enter_context(zipfile.ZipFile(path))
            stream = stack.enter_context(archive.open(binding["member"]))
            size = archive.getinfo(binding['member']).file_size
        else:
            stream = stack.enter_context(path.open("rb"))
            size = before.st_size
        label = 'Identifying ' + Path(binding.get('member', binding.get('_7z', {}).get('member', str(path)))).name
        count = 0
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            value.update(block); count += len(block)
            if size >= 8 * 1024 ** 2:ui_meter(label + ' | ' + byte_progress(count, size))
    after = path.stat()
    require((before.st_ino, before.st_size, before.st_mtime_ns) == (after.st_ino, after.st_size, after.st_mtime_ns),
            f"Source changed while reading: {path}")
    return value.hexdigest()


def text_key_binding(candidate, size, fields):
    """Recognize a bounded private text key map without returning key values."""
    materialize_sevenzip(candidate)
    path=Path(candidate['path']);before=path.stat()
    with contextlib.ExitStack() as stack:
        if 'member' in candidate:
            archive=stack.enter_context(zipfile.ZipFile(path))
            require(archive.getinfo(candidate['member']).file_size==size, 'Key source changed since discovery')
            stream=stack.enter_context(archive.open(candidate['member']))
        else:
            require(before.st_size==size, 'Key source changed since discovery')
            stream=stack.enter_context(path.open('rb'))
        prefix=stream.read(min(size,4096))
        if any(b<32 and b not in (9,10,13) for b in prefix):return False
        data=prefix+stream.read(1024*1024+1-len(prefix))
    after=path.stat()
    require(len(data)==size and size<=1024*1024 and
        (before.st_ino,before.st_size,before.st_mtime_ns)==(after.st_ino,after.st_size,after.st_mtime_ns), 'Key source changed while reading')
    try:text=data.decode('utf-8-sig')
    except UnicodeDecodeError:return False
    found={}
    for line in text.splitlines():
        match=re.fullmatch(r'\s*([a-z0-9_]+)\s*=\s*([0-9a-f]+)\s*(?:[#;].*)?',line,re.I)
        if match:
            name,value=match.group(1).lower(),match.group(2).lower()
            if name in found and found[name]!=value:return False
            found[name]=value
    if not all(name in found and len(found[name])==length for name,length in fields.items()):return False
    return {**{k:v for k,v in candidate.items() if k!='_7z'},'size':size,'sha256':hashlib.sha256(data).hexdigest(),'equivalence':identity(found)}


def resolve_inputs(prerequisites, required, index, unreadable, measured=None):
    results, bindings = [], {}
    if measured is None:
        measured = {}
    # Recognize exact game media before a broad semantic key-file search.
    # Missing game media cannot be made buildable by unpacking unrelated keys.
    for key in sorted(required, key=lambda name: 'text_keys' in prerequisites[name]):
        spec = prerequisites[key]
        found = []
        failed_reads = False
        if 'text_keys' in spec:
            if any(row['status'] != 'found' for row in results if 'text_keys' not in prerequisites[row['id']]):
                results.append({'id': key, 'title': spec['title'], 'kind': spec['kind'], 'status': 'deferred',
                    'formats': spec['formats'], 'action': 'Add the other required game media first. Key files will then be checked automatically. ' + spec['action']})
                continue
            loose = [(size, b) for size, candidates in index.items() if 0 < size <= 1024*1024
                     for b in candidates if 'member' not in b and '_7z' not in b and archived_key_candidate(b)]
            archived = [(size, b) for size, candidates in index.items() if 0 < size <= 1024*1024
                        for b in candidates if ('member' in b or '_7z' in b) and archived_key_candidate(b)]
            for pool in (loose, archived):
                if found:break
                for size, candidate in pool:
                    marker='text:'+identity({'source':source_marker(candidate),'size':size,'fields':spec['text_keys']})
                    if marker not in measured:
                        remembered = measured.get('_key_cache', {})
                        cached = remembered.get(marker)
                        if cached is False:measured[marker] = False
                        elif isinstance(cached, dict) and set(cached) == {'sha256', 'equivalence'} and all(
                                isinstance(value, str) and re.fullmatch('[0-9a-f]{64}', value) for value in cached.values()):
                            materialize_sevenzip(candidate)
                            measured[marker] = {**{k:v for k,v in candidate.items() if k!='_7z'}, 'size': size, **cached}
                        else:
                            try:measured[marker]=text_key_binding(candidate,size,spec['text_keys'])
                            except (OSError,Error,ValueError,RuntimeError,subprocess.SubprocessError,zipfile.BadZipFile):measured[marker]=None
                            if measured[marker] is not None:
                                remembered[marker] = ({k: measured[marker][k] for k in ('sha256', 'equivalence')}
                                                      if measured[marker] else False)
                    failed_reads=failed_reads or measured[marker] is None
                    if measured[marker]:found.append(measured[marker])
        for alternative in spec.get("alternatives",[]):
            for candidate in index.get(alternative["size"], []):
                if alternative.get("crc32") and candidate.get("crc32") and alternative["crc32"] != candidate["crc32"]:
                    continue
                marker = json.dumps(candidate, sort_keys=True) + (alternative["sha256"] if measured.get("_defer_verification") else "")
                if marker not in measured:
                    try:
                        cached = measured.get('_source_cache', {})
                        stable = source_marker(candidate)
                        # CRC-matched archive members can bind the expected digest.
                        # Native producers check the actual bytes while consuming them.
                        crc_match = (measured.get('_defer_verification') and alternative.get('crc32') and
                                     candidate.get('crc32') == alternative['crc32'])
                        remembered = cached.get(stable)
                        candidates = [b for b in index.get(alternative['size'], []) if not (
                            alternative.get('crc32') and b.get('crc32') and alternative['crc32'] != b['crc32'])]
                        unique_size = (measured.get('_defer_verification') and len(spec.get('alternatives', [])) == 1
                                       and len(candidates) == 1)
                        if crc_match or unique_size:measured[marker] = alternative['sha256']
                        elif isinstance(remembered, str) and re.fullmatch('[0-9a-f]{64}', remembered):
                            measured[marker] = remembered
                        else:
                            measured[marker] = source_digest(candidate)
                            cached[stable] = measured[marker]
                    except (OSError, Error, ValueError, subprocess.SubprocessError, zipfile.BadZipFile):
                        measured[marker] = None
                failed_reads = failed_reads or measured[marker] is None
                if measured[marker] == alternative["sha256"]:
                    materialize_sevenzip(candidate)
                    found.append({**{k:v for k,v in candidate.items() if k!='_7z'}, "size": alternative["size"], "sha256": measured[marker]})
                    # Other copies of this same accepted digest cannot add an
                    # ambiguous edition. Still check every distinct alternative.
                    break
        # Identical bytes in several locations are interchangeable, not ambiguous editions.
        by_hash = {b.get('equivalence',b['sha256']): b for b in found}
        status = "found" if len(by_hash) == 1 else "ambiguous" if by_hash else "unavailable" if unreadable or failed_reads else "missing"
        if status == "found":
            bindings[key] = next(iter(by_hash.values()))
        action = spec['action']
        if 'text_keys' in spec and status != 'found':
            action += ' Keep key maps loose (any filename), or named prod.keys/title.keys inside an archive. Extract other archived key maps first.'
        results.append(explain_disc({"id": key, "title": spec["title"], "kind": spec["kind"], "status": status,
                        "formats": spec["formats"], "action": action}, spec, index, unreadable or failed_reads))
    positions = {key: number for number, key in enumerate(required)}
    results.sort(key=lambda row: positions[row['id']])
    return results, bindings


def resolve_target_inputs(prerequisites,target,index,unreadable,measured=None):
    """Choose the first complete declared method; keep incomplete methods visible."""
    common,bindings=resolve_inputs(prerequisites,target['inputs'],index,unreadable,measured)
    options=[];chosen=None;chosen_rows=[]
    for option in target.get('input_options',[]):
        if chosen is not None:
            options.append({'id':option['id'],'title':option['title'],'status':'not_checked','prerequisites':[]})
            continue
        rows,found=resolve_inputs(prerequisites,option['inputs'],index,unreadable,measured)
        ready=all(r['status']=='found' for r in rows)
        options.append({'id':option['id'],'title':option['title'],'status':'ready' if ready else 'blocked','prerequisites':rows})
        if chosen is None and ready:
            chosen=option['id'];chosen_rows=rows;bindings.update(found)
    if options and chosen is None:
        # Report individual findings below each method, without pretending that
        # all methods must be satisfied together.
        common.append({'id':'input-method','title':'One complete input method','kind':'input method','status':'missing',
            'formats':['one of the methods below'],'action':'Supply one complete method; partial methods cannot be combined.'})
    existing={r['id'] for r in common}
    common.extend(r for r in chosen_rows if r['id'] not in existing)
    return common,bindings,options,chosen


def external_software(target,method,measured):
    results=[]
    for spec in target.get('external_tools',[]):
        if spec.get('hosts') and host() not in spec['hosts']:continue
        if spec.get('methods') and method not in spec['methods']:continue
        key='tool:'+identity(spec)
        if key not in measured:
            row={'id':spec['id'],'title':spec['title'],'action':spec['action'],'status':'missing'}
            executable=next((path for n in spec['commands'] if (path:=shutil.which(n))),None)
            if executable:
                try:
                    query=subprocess.run([executable,*spec['args']],capture_output=True,text=True,errors='replace',timeout=10)
                    version=query.stdout.strip()[:256]
                    row.update(status='found' if query.returncode==0 and re.search(spec['version_pattern'],version) else 'incompatible',detected_version=version)
                except (OSError,subprocess.TimeoutExpired):row['status']='unavailable'
            measured[key]=row
        results.append(measured[key])
    return results


def selected(rule, field, value):
    choice = rule.get(field, "all")
    require(choice == "all" or isinstance(choice, list), f"Invalid selection rule: {field}")
    return choice == "all" or value in choice


def target_selected(rule, target):
    regions = target.get('regions', [target['region']] if target.get('region') else [])
    return (selected(rule, 'platforms', target['platform']) and selected(rule, 'variants', target['variant'])
            and (not regions or any(selected(rule, 'regions', region) for region in regions)))


def target_identity(catalog, release, target):
    relevant = {release['runner']['artifact']}
    relevant.update(release.get('environments', {}).get(host(), {}).get('wheels', []))
    relevant.update(h['artifact'] for h in release.get('helpers', {}).get(host(), {}).values())
    return identity({'game_version': release.get('game_version'), 'kit_revision': release.get('kit_revision', 1),
        'executor': release['runner'],
        'target': {k: v for k, v in target.items() if k not in ('software_notes', 'destination_requirements')},
        'environment': release.get('environments', {}).get(host(), {}),
        'helpers': release.get('helpers', {}).get(host(), {}),
        'artifacts': {k: {f: catalog['artifacts'][k][f] for f in ('size', 'sha256')} for k in relevant}})


def game_outputs(outputs):
    """Outputs outside support/, the folder kits use for documents and verification aids."""
    return {path: spec for path, spec in outputs.items() if not path.startswith('support/')}


def same_game(old, target):
    """A recorded build whose game outputs equal this release's: a tooling-only revision needs no rebuild."""
    games = game_outputs(target['outputs'])
    return bool(games) and isinstance(old.get('outputs'), dict) and game_outputs(old['outputs']) == games


def keep_same_games(rows):
    """Rebuild every target of a project's export group when any of them rebuilds, so shared support files agree."""
    rebuilding = {(r['project'], r['group']) for r in rows if r['status'] != 'current'}
    for row in rows:
        rebuild = row.pop('_rebuild', None)
        if rebuild is not None and (row['project'], row['group']) in rebuilding:
            row.update(rebuild)
    return rows


def apple_metadata(path):
    """Recognize filesystem metadata without hiding arbitrary dotfiles."""
    if path.name.startswith('._'):
        with path.open('rb') as stream:
            return stream.read(8) in (b'\x00\x05\x16\x07\x00\x02\x00\x00',
                                      b'\x00\x05\x16\x07\x00\x01\x00\x00')
    if path.name == '.DS_Store':
        with path.open('rb') as stream:
            return stream.read(8) == b'\x00\x00\x00\x01Bud1'
    return False


def remove_export_tree(root):
    # On macOS/exFAT, removing a file can also remove its AppleDouble entry.
    # Python 3.12's rmtree may subsequently try to remove that stale entry.
    def onerror(function, path, info):
        if isinstance(info[1], FileNotFoundError) and Path(path) != Path(root):
            return
        raise info[1]
    shutil.rmtree(root, onerror=onerror)


def tree_contract(root, hash_files=True):
    result = {}
    if not root.exists():
        return result
    for folder, dirs, files in os.walk(root, followlinks=False):
        for name in dirs + files:
            require(not (Path(folder) / name).is_symlink(), "Export contains a symlink")
        for name in files:
            path = Path(folder) / name
            require(path.is_file(), "Export contains a special file")
            if apple_metadata(path):
                continue
            result[path.relative_to(root).as_posix()] = ({"size": path.stat().st_size, "sha256": digest(path)}
                                                       if hash_files else None)
    return result


def output_group(target):
    base = PLATFORMS.get(target["platform"], target["platform"])
    profile = target.get("profile", "default")
    return base if profile == "default" else f"{base}-profiles/{profile}"


def validate_settings(settings, home):
    cache_limits(settings)
    home = filesystem_path(home)
    require(settings.get("schema", 1) == 1, "Unsupported settings version")
    output = filesystem_path(settings["output"])
    require(not home.is_relative_to(output), "Tool state cannot be inside the output folder")
    roots = [filesystem_path(p) for p in settings["roots"]]
    require(roots, "At least one media folder is required")
    for root in roots:
        require(not output.is_relative_to(root) and not root.is_relative_to(output), "Media and output folders overlap")
        require(not home.is_relative_to(root) and not root.is_relative_to(home / "cache"), "Media and tool state folders overlap")


def plan(catalog, settings, home, installed, offline=False, archives=None, metadata_only=False):
    validate_settings(settings, home)
    output = filesystem_path(settings["output"])
    roots = [filesystem_path(p) for p in settings["roots"]]
    index, findings = index_sources(roots, [output, home / "cache", home / "runs"], archives)
    if _UI is not None:_UI.phase('Checking prerequisites and existing exports...')
    checked_exports = {}
    def export_matches(path, contract):
        key = (str(path), identity(contract))
        if key not in checked_exports:checked_exports[key] = matches(path, contract)
        return checked_exports[key]
    rows = []
    measured = {}
    rule = settings["selection"]
    for project_id, project in sorted(catalog["projects"].items()):
        if not selected(rule, "projects", project_id):
            continue
        release_id = project["current"]
        release = catalog["releases"][release_id]
        for target_id, target in sorted(release["targets"].items()):
            if not target_selected(rule, target):
                continue
            region = target.get("region")
            regions = target.get("regions", [region] if region is not None else [])
            if regions and not any(selected(rule, "regions", r) for r in regions):
                continue
            unknown_region = not regions and rule.get("regions", "all") != "all"
            row_id = f"{project_id}/{target_id}"
            ui_meter(f'Target {len(rows) + 1} | {project["title"]} / {target_id}')
            supported = (not unknown_region and release.get("protocol", 1) == 1 and set(release.get("requires", [])) <= FEATURES
                         and target["platform"] in PLATFORMS
                         and version_tuple(release.get("minimum_launcher", "0.1.0")) <= version_tuple(VERSION)
                         and host() in release.get("hosts", [host()])
                         and (not release.get("environments") or host() in release["environments"])
                         and list(sys.version_info[:2]) == release.get("environments", {}).get(host(), {}).get("python", list(sys.version_info[:2]))
                         and (not release.get("helpers") or host() in release["helpers"])
                         and list(sys.version_info[:2]) in release.get("python", [list(sys.version_info[:2])]))
            requirements, bindings, input_options, input_option = (preview_inputs(release['prerequisites'], target, index, bool(findings))
                if metadata_only else resolve_target_inputs(release['prerequisites'], target, index, bool(findings), measured))
            stamp = target_identity(catalog, release, target)
            group = output_group(target)
            old = installed.get("targets", {}).get(row_id, {})
            intact = all(export_matches(safe_path(output / group, p), c) for p, c in target["outputs"].items())
            current = old.get("identity") == stamp and intact
            needed = {release["runner"]["artifact"]}
            needed.update(release.get("environments", {}).get(host(), {}).get("wheels", []))
            needed.update(helper["artifact"] for helper in release.get("helpers", {}).get(host(), {}).values())
            software = [{"id": key, "title": catalog["artifacts"][key].get("filename", key),
                         "status": "cached" if export_matches(home / "cache/artifacts" / catalog["artifacts"][key]["sha256"],
                                                       catalog["artifacts"][key]) else "download_required",
                         "action": "Prepared automatically; no manual installation needed"} for key in sorted(needed)]
            external=external_software(target,input_option,measured) if supported else []
            offline_missing = offline and any(s["status"] == "download_required" for s in software)
            status = ("retired" if project.get("status") == "retired" else "unsupported" if unknown_region else "current" if current else
                      "unsupported" if not supported else ("available" if metadata_only else "ready") if not offline_missing and
                      all(r["status"] in (("candidate", "unchecked", "found") if metadata_only else ("found",)) for r in requirements+external) else "blocked")
            low_space = shutil.disk_usage(home).free < target.get("minimum_free_bytes", 0)
            if low_space and status in ("ready", "available"):
                status = "blocked"
            previous_outputs = old.get("outputs", {})
            previous_intact = bool(previous_outputs) and all(
                export_matches(safe_path(output / group, p), c) for p, c in previous_outputs.items())
            rows.append({"id": row_id, "project": project_id, "release": release_id, "target": target_id,
                         "title": project["title"], "platform": target["platform"], "group": group, "region": region, "regions": regions,
                         "identity": stamp, "status": status, "prerequisites": requirements,
                         "input_options": input_options, "input_option": input_option,
                         "change": "new" if not old else "update" if old.get("identity") != stamp else
                                   "repair" if not intact else "none",
                         "software": software,
                         "external_software": external,
                         "software_notes": target.get("software_notes", []),
                         "destination_requirements": target.get('destination_requirements',''),
                         "bindings": bindings, "outputs": target["outputs"],
                         "previous_export": "verified" if previous_intact else "absent_or_modified",
                         "message": "This catalog does not declare the output region; update the catalog or select all regions" if unknown_region else
                                    ("Requires a supported Python, host or launcher feature. Package environments: " +
                                     ", ".join(f"{h}: Python {'.'.join(map(str, e['python']))}" for h, e in
                                               release.get("environments", {}).items() if "python" in e)) if not supported else
                                    "Offline: required software is not cached" if offline_missing and not current else
                                    f"Needs {target['minimum_free_bytes'] / 1024 ** 3:g} GiB free in the tool workspace" if low_space and not current else ""})
            if (not current and status not in ("retired",) and not unknown_region and same_game(old, target)
                    and old.get("group") == group and previous_intact):
                # Tooling-only revision: the recorded build stays, under its own identity and outputs.
                row = rows[-1]
                row["_rebuild"] = {k: row[k] for k in ("status", "identity", "outputs", "change", "message")}
                row.update(status="current", identity=old["identity"], outputs=old["outputs"], change="none", message="")
    keep_same_games(rows)
    # Detect complete group conflicts before building either producer.
    claims = {}
    conflicts = set()
    for row in rows:
        for path, spec in row["outputs"].items():
            key = (row["group"], path.casefold())
            if key in claims and claims[key] != (path, spec):
                conflicts.add(row["group"])
            if any(group == row["group"] and (other.startswith(path.casefold() + "/")
                       or path.casefold().startswith(other + "/")) for group, other in claims):
                conflicts.add(row["group"])
            claims[key] = (path, spec)
    for row in rows:
        if row["group"] in conflicts:
            row.update(status="blocked", message="Conflicting exports; select separate declared profiles")
    for group in {r["group"] for r in rows}:
        expected = installed.get("groups", {}).get(group, {})
        try:
            actual = tree_contract(safe_path(output, group))
            valid = all(path in expected and expected[path] == spec for path, spec in actual.items())
        except (OSError, Error):
            valid = False
        if not valid:
            for row in rows:
                if row["group"] == group:
                    row.update(status="blocked", message="Export has unowned, modified or unreadable files; preserve or relocate them before updating")
    desired = {(r["group"], path) for r in rows for path in r["outputs"]}
    obsolete = [{"group": group, "path": path} for group, files in installed.get("groups", {}).items()
                for path in files if (group, path) not in desired]
    unavailable = [p for p in catalog.get("not_integrated", []) if selected(rule, "projects", p["id"])]
    return {"schema": 1, "catalog_sha256": identity(catalog), "generation": catalog["generation"],
            "targets": rows, "source_findings": findings, "obsolete_paths": obsolete, "not_integrated": unavailable,
            "media_scan": {"roots": [str(p) for p in roots], "indexed_entries": sum(map(len, index.values())),
                           "inspection_issues": len(findings)},
            **({"_source_index": index, "verification": "Archive sizes and CRCs only; source candidates and private keys are verified when building."} if metadata_only else {})}


def subprocess_path(value):
    """Use native process paths so Windows' DLL loader can resolve extensions."""
    path = str(value)
    if os.name == "nt":
        if path.startswith('\\\\?\\UNC\\'):
            return '\\\\' + path[8:]
        if path.startswith('\\\\?\\'):
            return path[4:]
    return path


@contextlib.contextmanager
def native_lock(path):
    """Kernel-owned leases survive stale files and release on process exit."""
    require(not path.is_symlink(), 'Lock must not be a symlink')
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('a+b') as stream:
        if stream.seek(0, 2) == 0:
            stream.write(b' ');stream.flush()
        stream.seek(0)
        try:
            if os.name == 'nt':
                import msvcrt
                msvcrt.locking(stream.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(stream.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError as exc:
            raise Error('Another run is active or finishing an interrupted worker; retry when it exits') from exc
        try:
            yield stream
        finally:
            stream.seek(0)
            if os.name == 'nt':
                msvcrt.locking(stream.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                fcntl.flock(stream.fileno(), fcntl.LOCK_UN)


def process_alive(pid):
    if not isinstance(pid, int) or pid <= 0:
        return False
    if os.name == 'nt':
        import ctypes
        from ctypes import wintypes as w
        kernel = ctypes.WinDLL('kernel32', use_last_error=True)
        kernel.OpenProcess.argtypes = (w.DWORD, w.BOOL, w.DWORD)
        kernel.OpenProcess.restype = w.HANDLE
        kernel.GetExitCodeProcess.argtypes = (w.HANDLE, ctypes.POINTER(w.DWORD))
        kernel.CloseHandle.argtypes = (w.HANDLE,)
        handle = kernel.OpenProcess(0x1000, False, pid)
        if not handle:
            return ctypes.get_last_error() != 87  # Access denied is not proof of death.
        try:
            code = w.DWORD()
            return not kernel.GetExitCodeProcess(handle, ctypes.byref(code)) or code.value == 259
        finally:
            kernel.CloseHandle(handle)
    try:
        os.kill(pid, 0)
        return True
    except ProcessLookupError:
        return False
    except PermissionError:
        return True


def windows_job():
    """Own the supervisor and every descendant until its last job handle closes."""
    import ctypes as c
    from ctypes import wintypes as w
    class Basic(c.Structure):
        _fields_ = [('process_time', c.c_int64), ('job_time', c.c_int64), ('flags', w.DWORD),
                    ('minimum', c.c_size_t), ('maximum', c.c_size_t), ('active', w.DWORD),
                    ('affinity', c.c_size_t), ('priority', w.DWORD), ('scheduling', w.DWORD)]
    class Counters(c.Structure):
        _fields_ = [(name, c.c_uint64) for name in ('read_ops','write_ops','other_ops','read_bytes','write_bytes','other_bytes')]
    class Extended(c.Structure):
        _fields_ = [('basic', Basic), ('io', Counters), ('process_memory', c.c_size_t),
                    ('job_memory', c.c_size_t), ('peak_process', c.c_size_t), ('peak_job', c.c_size_t)]
    k = c.WinDLL('kernel32', use_last_error=True)
    k.CreateJobObjectW.argtypes = (c.c_void_p, w.LPCWSTR);k.CreateJobObjectW.restype = w.HANDLE
    k.SetInformationJobObject.argtypes = (w.HANDLE, c.c_int, c.c_void_p, w.DWORD)
    k.AssignProcessToJobObject.argtypes = (w.HANDLE, w.HANDLE)
    k.GetCurrentProcess.restype = w.HANDLE
    k.TerminateJobObject.argtypes = (w.HANDLE, w.UINT)
    handle = k.CreateJobObjectW(None, None)
    require(bool(handle), 'Cannot create the worker process job')
    limits = Extended();limits.basic.flags = 0x2000  # JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE
    require(k.SetInformationJobObject(handle, 9, c.byref(limits), c.sizeof(limits)) and
            k.AssignProcessToJobObject(handle, k.GetCurrentProcess()), 'Cannot contain worker descendants')
    # Intentionally retained until ExitProcess: closing it earlier kills this worker too.
    return lambda: k.TerminateJobObject(handle, 1)


def worker_pids(marker, pid=None):
    """Return only this worker's same-user processes; never retain/log environments."""
    selection=['-p',str(pid)] if pid is not None else ['-U',str(os.getuid())]
    result=subprocess.run(['ps','e','-ww',*selection,'-o','pid=,command='],capture_output=True,text=True,errors='replace',timeout=5)
    require(result.returncode==0 or pid is not None and result.returncode==1,'Cannot inspect owned worker processes')
    pattern=re.compile(r'(?:^|\s)ARCADEPATCHES_WORKER_ID='+re.escape(marker)+r'(?::[0-9a-f]{32})*(?:\s|$)')
    return {int(line.split(None,1)[0]) for line in result.stdout.splitlines() if pattern.search(line) and line.split(None,1)[0].isdigit()}


def stop_posix_tree(pid, marker=None):
    """Freeze the owned family before killing nested sessions used by MAME probes."""
    owned = {pid}
    try:
        if marker:
            if pid in worker_pids(marker,pid):
                try:os.kill(pid,signal.SIGSTOP)
                except ProcessLookupError:pass
        else:
            try:os.killpg(pid, signal.SIGSTOP)
            except ProcessLookupError:pass
        for _ in range(64):
            before = set(owned)
            if marker:
                owned.update(worker_pids(marker))
            else:
                result = subprocess.run(['ps','-axo','pid=,ppid='], check=True, capture_output=True, text=True, timeout=5)
                pairs = [tuple(map(int, line.split())) for line in result.stdout.splitlines() if line.strip()]
                while True:
                    descendants = {child for child,parent in pairs if parent in owned}
                    if descendants <= owned:break
                    owned.update(descendants)
            for child in owned - before:
                if marker and child not in worker_pids(marker,child):continue
                try:os.kill(child, signal.SIGSTOP)
                except ProcessLookupError:pass
            if owned == before:break
        else:
            raise Error('Worker process tree did not become quiescent')
    finally:
        for child in owned if marker else owned - {pid}:
            if marker and child not in worker_pids(marker,child):continue
            try:os.kill(child, signal.SIGKILL)
            except ProcessLookupError:pass
        if not marker:
            try:os.killpg(pid, signal.SIGKILL)
            except ProcessLookupError:pass


def supervise(config_path, lease):
    with native_lock(filesystem_path(lease)):
        terminate_job = windows_job() if os.name == 'nt' else None
        config = read_json(config_path)
        sys.stdout.buffer.write(b'ARCADEPATCHES-WORKER-READY\n');sys.stdout.buffer.flush()
        if os.read(sys.stdin.fileno(), 1) != b'G':
            return 1
        ancestor=os.environ.get('ARCADEPATCHES_WORKER_ID','')
        require(not ancestor or len(ancestor)<=32*16+15 and re.fullmatch(r'[0-9a-f]{32}(?::[0-9a-f]{32})*',ancestor),'Invalid worker ownership context')
        marker=(ancestor+':' if ancestor else '')+uuid.uuid4().hex
        if os.name!='nt':worker_pids(marker)  # Fail before spawning if ownership inspection is unavailable.
        environment=dict(os.environ,ARCADEPATCHES_WORKER_ID=marker)
        process = subprocess.Popen(config['command'], cwd=config['cwd'], stdin=subprocess.DEVNULL,
                                   start_new_session=os.name != 'nt',env=environment)
        stop_lock = threading.Lock()
        def stop_tree():
            with stop_lock:
                if terminate_job:
                    terminate_job()
                else:
                    stop_posix_tree(process.pid,marker)
        def parent_watch():
            os.read(sys.stdin.fileno(), 1)
            stop_tree()
        threading.Thread(target=parent_watch, daemon=True).start()
        try:
            return process.wait()
        finally:
            if not terminate_job:
                stop_tree()


def run_supervised(command, folder, cwd, timeout=3600, lease=None):
    temp = folder / "tmp"
    temp.mkdir(exist_ok=True)
    env = {k: v for k, v in os.environ.items() if k not in ("PYTHONPATH", "PYTHONHOME")}
    env.update(TMPDIR=str(temp), TMP=str(temp), TEMP=str(temp), PYTHONDONTWRITEBYTECODE="1")
    # Drain continuously and retain at most 1 MiB, including for noisy failures.
    log = folder / "worker.log"
    config_path = folder / 'supervisor.json'
    write_json(config_path, {'command':command, 'cwd':str(cwd)})
    process = subprocess.Popen([sys.executable, '-I', '-S', '-B', str(Path(__file__).resolve()), '_supervise',
                                str(config_path), str(lease or folder / 'worker.lock')], env=env,
                               stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                               start_new_session=os.name != 'nt')
    tail = bytearray()
    ready, handshake = threading.Event(), []
    def drain():
        first = process.stdout.readline()
        handshake.append(first == b'ARCADEPATCHES-WORKER-READY\n')
        if not handshake[0]:tail.extend(first)
        ready.set()
        phases = {b'Creating private Python environment', b'Installing hash-pinned wheels',
                  b'Checking installed dependency requirements', b'Hashing complete private environment inventory',
                  b'Private package environment ready'}
        pending = b''
        while block := process.stdout.read1(65536):
            tail.extend(block)
            del tail[:-1024 * 1024]
            if _UI is not None and not _UI.quiet:
                pending += block
                while b'\n' in pending:
                    line, pending = pending.split(b'\n', 1)
                    if line.rstrip(b'\r') in phases:_UI.worker_phase(line.rstrip(b'\r').decode('ascii'))
                pending = pending[-4096:]
    reader = threading.Thread(target=drain, daemon=True)
    reader.start()
    try:
        if not ready.wait(min(30, timeout)):
            raise subprocess.TimeoutExpired(command, timeout)
        require(handshake[0], 'Worker supervisor did not acquire its lease')
        process.stdin.write(b'G');process.stdin.flush()
        code = process.wait(timeout=timeout)
    except BaseException:
        process.stdin.close()  # EOF also reaches the guardian if this launcher dies abruptly.
        try:process.wait(timeout=10)
        except subprocess.TimeoutExpired:
            process.kill();process.wait()
        raise
    finally:
        process.stdin.close()
        reader.join(timeout=5)
        require(not reader.is_alive(), "Worker left a process holding its log pipe open")
        process.stdout.close()
        log.write_bytes(tail)
    return code


def run_native(python, entry, request, folder, timeout=3600, lease=None, target_spec=None):
    inputs, response = folder / 'native-inputs.json', folder / 'native-result.json'
    response.unlink(missing_ok=True)
    write_json(inputs, {'schema': 1, 'target': request['target'], 'files': list(request['bindings'].values()),
        'bindings': request['bindings'],
        'context': {k: request.get(k) for k in ('run_cache', 'tools_cache', 'offline', 'input_option', 'helpers')}})
    command = [subprocess_path(python), '-I', '-B', str(entry), '--inputs-json', str(inputs),
        '--collection-layout', '--platform', target_spec['platform'], '--out-dir', request['staging'],
        '--report-json', str(response)]
    variant = target_spec.get('native_variant', target_spec['variant'] if target_spec['variant'] != 'default' else None)
    if variant is not None:
        command += ['--variant', variant]
    operation = 'check' if request['operation'] == 'preflight' else 'build'
    if operation == 'check':
        command.append('--check')
    code = run_supervised(command, folder, entry.parent, timeout, lease)
    require(response.is_file(), f'Native kit did not report a result (exit {code})')
    result = read_json(response)
    require(result.get('api') == 1 and result.get('operation') == operation and
            result.get('target') == request['target'], 'Native kit result identity differs')
    require(code == 0 and result.get('status') == 'ok', 'Native kit failed: ' + result.get('message', 'unknown result'))
    return result




def filesystem_path(value):
    """Canonical absolute paths, including Windows' long filesystem namespace."""
    path = Path(value).expanduser().resolve()
    if os.name == "nt":
        absolute = str(path)
        if not absolute.startswith('\\\\?\\'):
            absolute = '\\\\?\\UNC\\' + absolute[2:] if absolute.startswith('\\\\') else '\\\\?\\' + absolute
        path = Path(absolute)
    return path


def environment_python(release, catalog, cache, offline, local_root):
    spec = release.get("environments", {}).get(host())
    if not spec:
        require(not release.get("environments"), "No qualified package environment for this host")
        return Path(sys.executable)
    require(list(sys.version_info[:2]) == spec.get("python", list(sys.version_info[:2])),
            "No qualified package environment for this Python version")
    key = identity({"interpreter": str(Path(sys.executable).resolve()), "executable_sha256": digest(sys.executable), "version": sys.version,
                    "host": host(), "lock": spec})
    root = cache / "environments" / key
    root = filesystem_path(root)
    executable = root / ("Scripts/python.exe" if os.name == "nt" else "bin/python")
    if (root / "complete.json").is_file() and executable.is_file():
        marker = read_json(root / "complete.json")
        if marker.get("identity") == key and marker.get("inventory") == environment_inventory(root):
            os.utime(root, None)
            return executable
    wheels = [artifact_file(catalog["artifacts"][w], cache / "artifacts", offline, local_root) for w in spec["wheels"]]
    root.parent.mkdir(parents=True, exist_ok=True)
    shutil.rmtree(root, ignore_errors=True)
    try:
        with tempfile.TemporaryDirectory(prefix='.setup-', dir=root.parent) as temporary:
            folder=Path(temporary)
            config=folder/'environment.json'
            write_json(config, {'root':str(root),'identity':key,
                'wheels':[{'source':str(source),'artifact':catalog['artifacts'][w]} for w,source in zip(spec['wheels'],wheels)]})
            command=[sys.executable,'-I','-S','-B',str(Path(__file__).resolve()),'_environment',str(config)]
            try:
                code=run_supervised(command,folder,folder,timeout=1800,lease=cache.parent/'worker.lock')
            except subprocess.TimeoutExpired as exc:
                log=folder/'worker.log'
                raise Error('Private package setup timed out: '+(log.read_text(errors='replace')[-4096:] if log.exists() else 'no installer phase recorded')) from exc
            require(code==0, 'Private package setup failed: '+(folder/'worker.log').read_text(errors='replace')[-4096:])
        require(executable.is_file() and read_json(root/'complete.json')['identity']==key, 'Package setup did not finish')
        return executable
    except BaseException:
        shutil.rmtree(root, ignore_errors=True)
        raise


def create_environment(config_path):
    config=read_json(config_path)
    root=filesystem_path(config['root'])
    executable=str(root/('Scripts/python.exe' if os.name=='nt' else 'bin/python'))
    print('Creating private Python environment',flush=True)
    # venv's implicit ensurepip omits -I. Its nested pip then scans the current
    # directory, which pip 24.2 can turn into an invalid extended Windows \\. path.
    # Keep extended filesystem paths, but isolate every package subprocess.
    venv.EnvBuilder(with_pip=False).create(root)
    subprocess.run([executable, '-I', '-m', 'ensurepip', '--upgrade', '--default-pip'],
                   check=True, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, timeout=180)
    with tempfile.TemporaryDirectory(prefix='.wheels-', dir=root.parent) as temporary:
        wheelhouse=Path(temporary)
        lines=[]
        for wheel in config['wheels']:
            source=filesystem_path(wheel['source']);artifact=wheel['artifact']
            name = artifact.get("filename", "")
            require(relative(name) == Path(name).name and name.endswith(".whl"), "Wheel needs its original filename")
            destination = wheelhouse / name
            shutil.copyfile(source, destination)
            uri_path = subprocess_path(destination)
            lines.append(f"{Path(uri_path).as_uri()} --hash=sha256:{artifact['sha256']}")
        requirements = wheelhouse / "requirements.txt"
        requirements.write_text("\n".join(lines) + "\n")
        print('Installing hash-pinned wheels',flush=True)
        subprocess.run([executable, "-I", "-m", "pip", "install", "--no-index", "--no-deps",
                            "--require-hashes", "--only-binary=:all:", "-r", str(requirements)], check=True,
                           stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, timeout=1200)
        print('Checking installed dependency requirements',flush=True)
        subprocess.run([executable, "-I", "-m", "pip", "check"], check=True,
                           stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, timeout=180)
    print('Hashing complete private environment inventory',flush=True)
    write_json(root/'complete.json', {'identity':config['identity'],'inventory':environment_inventory(root)})
    print('Private package environment ready',flush=True)


def environment_inventory(root):
    result = {}
    for path in sorted(root.rglob("*")):
        name = path.relative_to(root).as_posix()
        if name == "complete.json":
            continue
        if path.is_symlink():
            result[name] = {"link": os.readlink(path)}
        elif path.is_file():
            result[name] = {"size": path.stat().st_size, "sha256": digest(path)}
    return result


def environment_worker(config_path):
    try:
        create_environment(config_path)
    except subprocess.CalledProcessError as exc:
        # venv's ensurepip uses check_output with stderr merged into stdout;
        # pip install/check above capture stderr instead. Preserve both forms.
        detail = exc.stderr or exc.output or ''
        if isinstance(detail, bytes):
            detail = detail.decode('utf-8', errors='replace')
        print(f'Private package command failed (exit {exc.returncode}):\n{detail[-4096:]}', file=sys.stderr)
        return 1
    return 0


def prepare_helpers(release, catalog, cache, folder, offline, local_root):
    if release.get("helpers"):
        require(host() in release["helpers"], "No qualified helpers for this host")
    result = {}
    for name, helper in release.get("helpers", {}).get(host(), {}).items():
        token(name)
        archive = artifact_file(catalog["artifacts"][helper["artifact"]], cache / "artifacts", offline, local_root)
        destination = folder / ("helper-" + name)
        extract(archive, destination)
        entry = safe_path(destination, helper["entry"])
        require(entry.is_file(), f"Helper entry missing: {name}")
        entry.chmod(entry.stat().st_mode | stat.S_IXUSR)
        result[name] = str(entry)
    return result


def recover(home, output):
    path = home / "journal.json"
    if not path.exists():
        return
    journal = read_json(path)
    require(journal.get("output") == str(output), "Unfinished export belongs to a different output; restore that configuration first")
    if journal.get('kind') == 'files':
        destination = safe_path(output, journal['group'])
        backup = safe_path(output, journal['backup'])
        before, after = journal['before'], journal['after']
        # Remove only this interrupted batch's new files. An absent backup
        # means the old file was never moved, or was already restored.
        for name in sorted(after, key=lambda n: (-n.count('/'), n)):
            file = safe_path(destination, name)
            saved = safe_path(backup, name)
            if name in before and not saved.exists():
                continue
            if file.is_file():
                require(matches(file, after[name]), 'Interrupted export was modified; preserve it before recovery')
                file.unlink()
        for name, spec in before.items():
            file = safe_path(destination, name)
            saved = safe_path(backup, name)
            if saved.exists():
                require(matches(saved, spec), 'Export recovery backup was modified')
                require(not file.is_file(), 'Interrupted export was modified; preserve it before recovery')
                if file.is_dir():
                    remove_empty_directories(file)
                    file.rmdir()
                file.parent.mkdir(parents=True, exist_ok=True)
                os.replace(saved, file)
            else:
                require(matches(file, spec), 'Interrupted export lost its previous file')
        write_json(home / 'installed.json', journal['previous'])
        path.unlink()
        if backup.exists():
            require(not tree_contract(backup), 'Unexpected export recovery files')
            remove_export_tree(backup)
        return
    # Always roll an interrupted group back; replay is safe after an interrupted rollback.
    group = relative(journal["group"])
    destination = safe_path(output, group)
    backup = safe_path(output, journal["backup"])
    if backup.exists():
        if destination.exists():
            if 'candidate' in journal:
                require(tree_contract(destination) == journal['candidate'], 'Interrupted export was modified; preserve it before recovery')
            remove_export_tree(destination)
        os.replace(backup, destination)
    elif not journal["had_previous"] and destination.exists():
        remove_export_tree(destination)
    write_json(home / "installed.json", journal["previous"])
    path.unlink()


def cleanup_backups(home, output):
    path = home/'cleanup.json'
    if not path.exists():
        return
    ledger = read_json(path)
    require(ledger.get('schema') == 1, 'Unknown backup cleanup ledger')
    for name, entry in list(ledger.get('staging', {}).items()):
        require(re.fullmatch(r'\.staging-[0-9a-f]{32}', name) and entry['output'] == str(output), 'Invalid staging cleanup owner')
        staged = safe_path(output, name)
        if staged.exists():
            require(set(tree_contract(staged)) <= set(entry['files']), 'Interrupted staging has unmanaged files; preserve them before cleanup')
            remove_export_tree(staged)
        del ledger['staging'][name]
        write_json(path, ledger)
    for name, entry in list(ledger['backups'].items()):
        require(re.fullmatch(r'\.backup-[0-9a-f]{32}', name) and entry['output'] == str(output),
                'Backup cleanup belongs to another export')
        backup = safe_path(output, name)
        if backup.exists():
            require(tree_contract(backup) == entry['files'], 'Export backup was modified; preserve it before retrying cleanup')
            remove_export_tree(backup)
        del ledger['backups'][name]
        write_json(path, ledger)


def remove_empty_directories(root):
    if root.exists():
        for folder, dirs, files in os.walk(root, topdown=False):
            for name in dirs:
                directory = Path(folder) / name
                contents = list(directory.iterdir())
                if all(p.is_file() and not p.is_symlink() and apple_metadata(p) for p in contents):
                    for file in contents:
                        file.unlink(missing_ok=True)
                    directory.rmdir()


def commit_group(home, output, group, staged, manifest):
    """Commit a verified file delta; earlier games stay in their output paths."""
    previous_path = home / "installed.json"
    previous = read_json(previous_path) if previous_path.exists() else {"targets": {}, "groups": {}}
    destination = safe_path(output, group)
    expected = previous.get("groups", {}).get(group, {})
    after = tree_contract(staged)
    desired = manifest['groups'].get(group, {})
    # The plan checked existing file contents. Enumerate ownership again here,
    # but rehash only files this batch will replace or remove.
    actual = set(tree_contract(destination, hash_files=False))
    require(actual <= set(expected), f'Export has unowned files: {group}')
    changed = set(after) | (set(expected) - set(desired))
    before = {name: expected[name] for name in changed & actual}
    require(all(matches(safe_path(destination, name), spec) for name, spec in before.items()),
            f'Export has modified files: {group}')
    backup_name = f".backup-{uuid.uuid4().hex}"
    backup = output / backup_name
    cleanup_path = home/'cleanup.json'
    journal = {"output": str(output), "group": group, "backup": backup_name,
               'kind': 'files', 'before': before, 'after': after, "previous": previous}
    write_json(home / "journal.json", journal)
    try:
        backup.mkdir()
        for name in before:
            saved = safe_path(backup, name)
            saved.parent.mkdir(parents=True, exist_ok=True)
            os.replace(safe_path(destination, name), saved)
        remove_empty_directories(destination)
        for name in after:
            file = safe_path(destination, name)
            file.parent.mkdir(parents=True, exist_ok=True)
            os.replace(safe_path(staged, name), file)
        write_json(previous_path, manifest)
        cleanup = read_json(cleanup_path) if cleanup_path.exists() else {'schema':1,'backups':{}}
        cleanup['backups'][backup_name] = {'output':str(output),'files':before}
        write_json(cleanup_path, cleanup)
        # Removing journal commits the transaction; an orphaned backup is harmless.
        (home / "journal.json").unlink()
    except BaseException:
        recover(home, output)
        raise
    try:
        cleanup_backups(home, output)
    except (Error, OSError) as exc:
        raise ExportCleanupError(str(exc)) from exc


def group_transition(rows, built, installed, group, final=True):
    """Keep pending owners; reject updates that would invalidate their resources."""
    previous = {k: v for k, v in installed["targets"].items() if v["group"] == group}
    active = {r["id"]: r for r in rows if r["status"] == "current" or r["id"] in built}
    while True:
        targets = {k: v for k, v in previous.items() if k not in active}
        targets.update({key: {"group": group, "identity": row["identity"], "outputs": row["outputs"]}
                        for key, row in active.items()})
        claims = {}
        conflicts = []
        for owner, target in targets.items():
            for name, spec in target["outputs"].items():
                folded = name.casefold()
                for old_owner, old_name, old_spec in claims.get(folded, []):
                    if old_name != name or old_spec != spec:
                        conflicts.append({owner, old_owner})
                claims.setdefault(folded, []).append((owner, name, spec))
        for name, entries in claims.items():
            parts = name.split('/')
            for length in range(1, len(parts)):
                ancestor = '/'.join(parts[:length])
                if ancestor in claims:
                    conflicts.append({entry[0] for entry in entries + claims[ancestor]})
        blocked = set().union(*conflicts) & set(active) if conflicts else set()
        if not blocked:
            require(not conflicts, "Retained target resource contracts conflict")
            return active, targets
        for owner in blocked:
            if final:
                active[owner].update(status="blocked", message="Shared resource update needs a pending target; previous files retained")
            del active[owner]


def publish_completed(home, output, group, report, built, installed, tell, checked, final=False):
    rows = [r for r in report['targets'] if r['group'] == group]
    staged = None
    pending = {}
    try:
        active, targets = group_transition(rows, built, installed, group, final=final)
        pending = {key: row for key, row in active.items() if key in built}
        if not pending:
            return installed
        tell('Saving completed games: ' + group)
        desired = {path for target in targets.values() for path in target['outputs']}
        previous = installed['groups'].get(group, {})
        retained = {path: spec for path, spec in previous.items() if path in desired}
        copies = {}
        for owner, row in pending.items():
            for path, spec in row['outputs'].items():
                same = path in retained and safe_path(output / group, path).is_file() and any(
                    old['group'] == group and old['outputs'].get(path) == spec
                    for old in installed['targets'].values())
                if same:
                    file = safe_path(output / group, path)
                    key = (source_marker({'path': str(file)}), identity(spec))
                    if key not in checked:
                        checked[key] = matches(file, spec)
                    require(checked[key], f'Shared export changed during build: {path}')
                else:
                    copies.setdefault(path, (safe_path(built[owner], path), spec))
        staged = output / f'.staging-{uuid.uuid4().hex}'
        cleanup_path = home / 'cleanup.json'
        cleanup = read_json(cleanup_path) if cleanup_path.exists() else {'schema': 1, 'backups': {}}
        cleanup.setdefault('staging', {})[staged.name] = {'output': str(output), 'files': sorted(copies)}
        write_json(cleanup_path, cleanup)
        staged.mkdir()
        for path, (source, spec) in copies.items():
            destination = safe_path(staged, path)
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(source, destination)
        require(verify_outputs(staged, {path: spec for path, (_, spec) in copies.items()}),
                'Completed export differs from its accepted contract')
        next_state = json.loads(json.dumps(installed))
        next_state['targets'] = {k: v for k, v in next_state['targets'].items() if v['group'] != group}
        next_state['targets'].update(targets)
        next_state['groups'][group] = retained | tree_contract(staged)
        obsolete = {(item['group'], item['path']) for item in installed.get('obsolete_paths', [])}
        obsolete.update((group, path) for path in previous if path not in desired)
        obsolete = {(g, p) for g, p in obsolete if p not in next_state['groups'].get(g, {})}
        next_state['obsolete_paths'] = [{'group': g, 'path': p} for g, p in sorted(obsolete)]
        commit_group(home, output, group, staged, next_state)
        installed = next_state
        for key, row in pending.items():
            row.update(status='built', message='')
            del built[key]
        count = sum(r['status'] == 'built' for r in report['targets'])
        tell(f'{count} saved to output | ' + group)
    except (Error, OSError) as exc:
        # A cleanup error after commit must not turn a published game back into
        # a pending build, or let a later batch overwrite its ownership record.
        state = home / 'installed.json'
        installed = read_json(state) if state.exists() else installed
        for key, row in pending.items():
            committed = isinstance(exc, ExportCleanupError)
            row.update(status='built' if committed else 'failed', message=str(exc))
            built.pop(key, None)
    finally:
        if staged is not None and staged.exists():
            remove_export_tree(staged)
    return installed


def update(catalog, settings, home, report, offline=False, local_root=None, progress=None):
    tell = progress or (lambda message: None)
    output = filesystem_path(settings["output"])
    output.mkdir(parents=True, exist_ok=True)
    installed_path = home / "installed.json"
    installed = read_json(installed_path) if installed_path.exists() else {"targets": {}, "groups": {}}
    cache = filesystem_path(home / "cache")
    runs = filesystem_path(home / "runs")
    runs.mkdir(exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="build-", dir=runs) as temporary:
        run = Path(temporary)
        write_json(run/'run-owner.json', {'schema':1,'home':str(home)})
        (run / 'shared').mkdir()
        built = {}
        checked_exports = {}
        prepared_environments = {}
        verified_inputs = {'_key_cache': report.get('_key_cache', {}), '_source_cache': report.get('_source_cache', {}),
                           '_defer_verification': '_source_index' in report}
        ready_count = sum(row["status"] in ("ready", "available") for row in report["targets"])
        position = 0
        for number, row in enumerate(report["targets"]):
            if row["status"] not in ("ready", "available"):
                continue
            position += 1
            game_names = [PurePosixPath(path).stem for path in row['outputs'] if path.lower().endswith('.mra')]
            game_name = game_names[0] if len(game_names) == 1 else row['title']
            label = f"[{position}/{ready_count}] {game_name} ({row['target']})"
            tell(label + ": preparing tools and inputs")
            folder = run / str(number)
            folder.mkdir()
            try:
                release = catalog["releases"][row["release"]]
                if '_source_index' in report:
                    target = release['targets'][row['target']]
                    requirements, bindings, options, method = resolve_target_inputs(release['prerequisites'], target,
                        report['_source_index'], bool(report['source_findings']), verified_inputs)
                    external = external_software(target, method, verified_inputs)
                    row.update(prerequisites=requirements, bindings=bindings, input_options=options,
                               input_option=method, external_software=external)
                    if not all(r['status'] == 'found' for r in requirements + external):
                        row.update(status='blocked', message='Source verification needs attention; see the requirements below.')
                        continue
                    row['status'] = 'ready'
                runner = release["runner"]
                archive = artifact_file(catalog["artifacts"][runner["artifact"]], cache / "artifacts", offline, local_root)
                kit = folder / "kit"
                extract(archive, kit)
                environment_key=identity(release.get('environments',{}).get(host(),{}))
                if environment_key not in prepared_environments:
                    with ui_activity('Checking and preparing private Python packages') if release.get('environments') else contextlib.nullcontext():
                        prepared_environments[environment_key]=environment_python(release, catalog, cache, offline, local_root)
                python=prepared_environments[environment_key]
                helpers = prepare_helpers(release, catalog, cache, folder, offline, local_root)
                entry = safe_path(kit, runner["entry"])
                require(entry.is_file(), "Worker entry is missing")
                staging = folder / "output"
                staging.mkdir()
                require(shutil.disk_usage(staging).free > sum(estimated_size(c) for c in row["outputs"].values()) + 64 * 1024 ** 2,
                        "Insufficient space for declared build outputs")
                if '_source_index' not in report:
                    for binding in row["bindings"].values():
                        require(source_digest(binding) == binding["sha256"], "Input changed after discovery")
                request = {"release": row["release"], "descriptor_sha256": identity(release),
                           "target": row["target"], "bindings": row["bindings"], "staging": str(staging),
                           "input_option": row.get('input_option'),
                           "helpers": helpers, "run_cache": str(run / "shared"),
                           "tools_cache": str(cache / "kit-tools"), "offline": offline}
                tell(label + ": checking prerequisites")
                (cache/'kit-tools').mkdir(exist_ok=True)
                os.utime(cache/'kit-tools', None)
                timeout=release['targets'][row['target']].get('timeout_seconds',3600)
                execute = lambda *a, **kw: run_native(*a, target_spec=release['targets'][row['target']], **kw)
                preflight = execute(python, entry, {**request, "operation": "preflight"}, folder, timeout=timeout, lease=home/'worker.lock')
                require(preflight["status"] == "ok", "Kit preflight blocked: " +
                        json.dumps(preflight.get("diagnostics", []))[:4096])
                tell(label + ": building")
                response = execute(python, entry, {**request, "operation": "build"}, folder, timeout=timeout, lease=home/'worker.lock')
                require(response["status"] == "ok" and response.get("outputs") == row["outputs"], "Worker output report differs from accepted contract")
                if response.get("dependencies"):
                    row["dependencies"] = response["dependencies"]
                require(verify_outputs(staging, row["outputs"]), "Actual output differs from accepted contract")
                built[row["id"]] = staging
                installed = publish_completed(home, output, row['group'], report, built, installed, tell, checked_exports)
                if row['id'] in built:
                    tell(label + ": verified; waiting for shared resources")
            except (Error, OSError, ValueError, zipfile.BadZipFile, subprocess.SubprocessError) as exc:
                row.update(status="failed", message=str(exc))
                tell(label + ": failed (see final report)")
                if (folder / "worker.log").exists():
                    row["worker_log_tail"] = (folder / "worker.log").read_bytes()[-16384:].decode("utf-8", errors="replace")
        for group in sorted({r['group'] for r in report['targets']}):
            installed = publish_completed(home, output, group, report, built, installed, tell, checked_exports, final=True)
    report["obsolete_paths"] = installed.get("obsolete_paths", [])
    cleanup_backups(home, output)
    return report


@contextlib.contextmanager
def locked(home):
    path = home / "running.lock"
    with native_lock(path) as stream:
        stream.seek(0)
        old = stream.read().strip()
        require(not (old.isdigit() and process_alive(int(old))), 'A legacy launcher is still running')
        with native_lock(home/'worker.lock'):
            pass
        stream.seek(0);stream.truncate()
        stream.write(json.dumps({'schema':1,'pid':os.getpid()}).encode());stream.flush()
        yield


def cleanup_runs(home):
    runs = home/'runs'
    if not runs.exists():
        return
    for run in runs.iterdir():
        marker = run/'run-owner.json'
        if run.is_dir() and not run.is_symlink() and marker.is_file():
            owner = read_json(marker)
            require(owner == {'schema':1,'home':str(home)}, 'Build scratch belongs to another state folder')
            shutil.rmtree(run)


def cache_limits(settings):
    limits = settings.get('cache_limits', {'max_bytes':20*1024**3,'max_entries':256})
    require(isinstance(limits, dict) and set(limits) == {'max_bytes','max_entries'} and
            all(type(n) is int and n >= 0 for n in limits.values()), 'Invalid cache limits')
    return limits


def cache_size(path):
    if path.is_symlink():
        return 0
    if path.is_file():
        return path.stat().st_size
    return sum(p.stat().st_size for p in path.rglob('*') if p.is_file() and not p.is_symlink())


def prune_cache(home, limits):
    cache = home/'cache'
    if not cache.exists():
        return
    units = []
    for family in ('artifacts','environments'):
        parent = cache/family
        if not parent.is_dir():
            continue
        require(not parent.is_symlink(), 'Cache must not contain redirected directories')
        for path in parent.iterdir():
            owned = re.fullmatch(r'[0-9a-f]{64}(?:\.part)?', path.name) or (family == 'environments' and path.name.startswith(('.wheels-','.setup-')))
            if not owned or path.is_symlink():
                continue
            if path.name.endswith('.part') or path.name.startswith(('.wheels-','.setup-')):
                if path.is_dir():shutil.rmtree(path)
                else:path.unlink()
            else:
                units.append((path.stat().st_mtime_ns, path, cache_size(path)))
    tools = cache/'kit-tools'
    if tools.exists():
        require(not tools.is_symlink(), 'Tool cache must not be redirected')
        units.append((tools.stat().st_mtime_ns, tools, cache_size(tools)))
    total = cache_size(cache)
    count = len(units)
    for _, path, size in sorted(units, key=lambda item:(item[0],str(item[1]))):
        if total <= limits['max_bytes'] and count <= limits['max_entries']:
            break
        if path.is_dir():shutil.rmtree(path)
        else:path.unlink()
        total -= size;count -= 1
    require(total <= limits['max_bytes'], 'Cache has unmanaged files exceeding its budget; preserve or relocate them before retrying')


@contextlib.contextmanager
def maintained(home):
    with locked(home):
        cleanup_runs(home)
        settings_path = home/'settings.json'
        if settings_path.exists():
            prune_cache(home, cache_limits(read_json(settings_path)))
        try:
            yield
        finally:
            if settings_path.exists():
                prune_cache(home, cache_limits(read_json(settings_path)))


def validate_index(value):
    if value.get('schema') == 1:
        return validate_catalog(value)  # Internal local producer fixtures.
    require(value.get('schema') == 2 and isinstance(value.get('generation'), int)
            and value['generation'] > 0 and value.get('projects') and value.get('releases'),
            'Unknown or empty discovery index')
    for project in value['projects'].values():
        require(isinstance(project.get('title'), str) and project.get('current') in value['releases'],
                'Invalid discovery project')
    for pointer in value['releases'].values():
        spec = pointer.get('definition', {})
        require(spec.get('kind') == 'native-kit-v1'
                and isinstance(spec.get('size'), int) and 0 < spec['size'] <= LIMIT
                and isinstance(spec.get('sha256'), str) and re.fullmatch('[0-9a-f]{64}', spec['sha256'])
                and isinstance(spec.get('url'), str), 'Invalid definition reference')
    return value


def expand_catalog(index, home, offline=False, local_root=None):
    if index['schema'] == 1:
        return validate_catalog(index)
    value = json.loads(json.dumps(index));value['schema'] = 1
    for slug, project in index['projects'].items():
        key = project['current'];pointer = index['releases'][key];spec = pointer['definition']
        path = artifact_file(spec, home / 'definitions', offline, local_root)
        definition = read_json(path)
        if spec['kind'] == 'native-kit-v1':
            require(all(index['artifacts'].get(key) == spec for key, spec in definition.get('artifacts', {}).items()),
                    'Native dependency differs from kit definition')
            require(definition.get('api') == 1 and definition.get('project') == slug,
                    'Native definition identity differs')
            definition = {**{k: definition[k] for k in ('environments', 'helpers') if k in definition},
                'protocol': 1, 'minimum_launcher': '0.1.0',
                'requires': sorted(set(['native-kit-v1', 'file-inputs-v1', 'archive-inputs-v1', 'zip-outputs-v1',
                                       *definition.get('requires', [])])),
                'game_version': definition['game_version'], 'kit_revision': definition['kit_revision'],
                'runner': {'api': 1, 'artifact': pointer['kit'], 'entry': 'apply.py'},
                'prerequisites': definition['prerequisites'], 'targets': definition['targets']}
        require(all(definition[k] == pointer[k] for k in ('game_version', 'kit_revision')),
                'Definition revision differs from index')
        value['releases'][key] = definition
    return validate_catalog(value)


def load_catalog(args, home):
    cached = home / "catalog.json"
    if args.catalog:
        source = Path(args.catalog).expanduser().resolve()
        require(not args.offline, "Use --offline with a previously cached catalog, without --catalog")
        index = validate_index(read_json(source))
        catalog = expand_catalog(index, home, local_root=source.parent)
        # Local fixtures are never persisted as the official online/offline snapshot.
        return catalog, source.parent
    if args.offline:
        require(cached.is_file(), "No cached catalog; run online first")
        return expand_catalog(validate_index(read_json(cached)), home, offline=True), None
    temporary = home / "catalog.download"
    try:
        fetch(CATALOG, temporary, LIMIT)
        catalog = validate_index(read_json(temporary))
        require(catalog["schema"] == 2, "Official catalog must be a discovery index")
        if cached.exists():
            previous = validate_index(read_json(cached))
            require(catalog["generation"] >= previous["generation"], "Catalog rollback rejected")
            require(catalog["generation"] != previous["generation"] or identity(catalog) == identity(previous),
                    "Catalog changed without a new generation")
        expanded = expand_catalog(catalog, home)
        write_json(cached, catalog)
        # Retain only metadata needed by the committed offline snapshot.
        active = {r['definition']['sha256'] for r in catalog['releases'].values()}
        for path in (home / 'definitions').iterdir():
            if re.fullmatch('[0-9a-f]{64}', path.name) and path.name not in active:
                path.unlink()
        return expanded, None
    finally:
        temporary.unlink(missing_ok=True)


def grouped_requirements(specs, group_roms=True):
    groups = {}
    for spec in specs:
        if spec['status'] == 'found':continue
        key = ((spec['status'], spec['action']) if group_roms and spec.get('kind') in ('rom', 'device', 'firmware')
               else ('single', len(groups)))
        groups.setdefault(key, []).append(spec)
    for rows in groups.values():
        if len(rows) == 1:yield rows[0]
        else:yield {**rows[0], 'title': str(len(rows)) + ' ROM files', 'formats': []}


def show(report, compact=False, group_roms=True, details=False):
    if report.get('verification') and not details:print('Quick check: matching files are verified when building.')
    if compact:
        attention = {}
        for row in report['targets']:
            if row['status'] in ('ready', 'available', 'built', 'current'):continue
            issues = attention.setdefault(row['title'], set())
            if row.get('message'):issues.add(row['message'])
            for spec in grouped_requirements(row['prerequisites'] + row.get('external_software', []), group_roms):
                if spec['status'] != 'found':issues.add(spec['title'] + ': ' + spec['action'])
            for option in row.get('input_options', []):
                if row.get('input_option') is None:
                    for spec in grouped_requirements(option['prerequisites'], group_roms):
                        if spec['status'] != 'found':issues.add(spec['title'] + ': ' + spec['action'])
            if not issues:issues.add(row['status'].capitalize())
        for title, issues in list(attention.items())[:8]:
            print(ui_style(title, 'yellow'))
            for issue in sorted(issues)[:4]:print('  ' + issue)
            if len(issues) > 4:print(f'  {len(issues) - 4} more requirements in the detailed report.')
        if len(attention) > 8:print(f'{len(attention) - 8} more games need attention; see the detailed report.')
        if not attention and report['targets']:print('Selected games have source candidates or are already current.')
    for row in ([] if compact else report["targets"]):
        label = f"{row['status'].upper()} ({row['change']})" if row["change"] != "none" else row["status"].upper()
        color = TerminalUI.STATUS.get(row['status'], 'yellow')
        print(f"{ui_style(f'{label:18}', color)} {ui_style(row['title'], color)} / {row['target']} / {PLATFORMS.get(row['platform'], row['platform'])}")
        if row["message"]:
            print(f"  {row['message']}")
        for spec in grouped_requirements(row['prerequisites'], group_roms):
            if spec["status"] != "found":
                formats = " (" + ', '.join(spec['formats']) + ")" if details and spec['formats'] else ''
                name = ui_style(spec['title'], 'cyan' if spec['status'] == 'candidate' else 'yellow')
                print(f"  {spec['status']}: {name}{formats}")
                print(f"  {spec['action']}")
        for option in row.get('input_options',[]):
            label='selected' if option['id']==row.get('input_option') else option['status']
            print(f"  Input method ({label}): {option['title']}")
            if row.get('input_option') is None:
                for spec in grouped_requirements(option['prerequisites'], group_roms):
                    if spec['status']!='found':print(f"    {spec['status']}: {spec['title']}. {spec['action']}")
        for software in (row["software"] if details else []):
            if software["status"] == "download_required" and row["status"] != "current":
                print(f"  Software: {software['title']} will be downloaded and prepared automatically")
        for software in row.get('external_software',[]):
            if software['status']!='found':print(f"  Software {software['status']}: {software['title']}. {software['action']}")
        for note in (row.get("software_notes", []) if details else []):
            print("  Software: " + note)
        if details and row.get('destination_requirements'):print('  Destination: '+row['destination_requirements'])
    for finding in report["source_findings"][:8] if compact else report["source_findings"]:
        print(f"{finding.get('root', 'Source inspection')}: {finding['message']}")
    for project in report.get("not_integrated", []):
        print(ui_style('PENDING           ', 'yellow') + f" {project['title']}: {project['reason']}")
        print(f"  Requirements and standalone kit: {project['page_url']}")
    if not report["targets"]:
        print("No catalog targets match the saved selection.")
    counts = {status: sum(r['status'] == status for r in report['targets'])
              for status in {r['status'] for r in report['targets']} | {'built', 'current', 'blocked', 'failed'}}
    order = ['built', 'current', 'ready', 'available', 'blocked', 'failed', 'unsupported', 'retired']
    order += sorted(set(counts) - set(order))
    totals = [ui_style(f'{counts[status]} {status}', TerminalUI.STATUS.get(status, 'yellow')) if counts[status] else f'0 {status}'
              for status in order if status in counts]
    print(f"\nSummary ({len(report['targets'])} targets): " + ' | '.join(totals))
    if report['source_findings']:print(ui_style(f"  {len(report['source_findings'])} source inspection issues; see details above", 'yellow'))
    if report.get('not_integrated'):print(ui_style(f"  {len(report['not_integrated'])} catalog integrations pending", 'yellow'))


def redact(value, private_paths):
    if isinstance(value, dict):
        return {k: redact(v, private_paths) for k, v in value.items() if k not in ("bindings", "_source_index", "_key_cache", "_source_cache")}
    if isinstance(value, list):
        return [redact(v, private_paths) for v in value]
    if isinstance(value, str):
        for path in sorted(private_paths, key=len, reverse=True):
            value = value.replace(path, "<local-path>")
    return value


def check_export_metadata(home, output):
    state = home / "export-metadata.json"
    expected = read_json(state) if state.exists() else {}
    for name in ("INSTALL.txt", "build-report.json"):
        path = output / name
        require(not path.is_symlink() and (not path.exists() or (name in expected and matches(path, expected[name]))),
                f"Export metadata is unowned or modified: {path}")


def ui_style(text, color):
    return _UI.paint(text, color) if _UI is not None else text


def selection_summary(rule):
    labels = {'projects': ('Games', {}), 'platforms': ('Platforms', PLATFORMS),
              'regions': ('Regions', REGIONS), 'variants': ('Variants', {})}
    lines = []
    for key, (label, names) in labels.items():
        choice = rule.get(key, 'all')
        value = 'All' if choice == 'all' else ', '.join(names.get(item, item) for item in choice) or 'None'
        if key != 'variants' or choice != 'all':lines.append(f'  {label}: {value}')
    if rule.get('include_future', True):lines.append('  Future matching games, platforms and regions: included')
    return 'Selection:\n' + '\n'.join(lines)


def catalog_snapshot(catalog):
    projects = {}
    for slug, project in catalog['projects'].items():
        release = catalog['releases'][project['current']]
        projects[slug] = {'version': release['game_version'], 'kit_revision': release['kit_revision'],
            'identity': identity({k: release[k] for k in ('game_version', 'kit_revision')} |
                                 {'kit': catalog['artifacts'][release['runner']['artifact']]['sha256']}),
            'inputs': {key: identity({k: spec[k] for k in ('kind', 'text_keys') if k in spec} |
                        {'alternatives': [{k:v for k,v in pin.items() if k != 'crc32'} for pin in spec.get('alternatives', [])]})
                       for key, spec in release['prerequisites'].items()},
            'target_inputs': {key: sorted(set(target['inputs']) | {name for option in target.get('input_options', []) for name in option['inputs']})
                              for key, target in release['targets'].items()},
            'tools': sorted({identity(tool) for target in release['targets'].values() for tool in target.get('external_tools', [])})}
    return {'schema': 2, 'projects': projects}


def release_notice(catalog, settings, installed, previous):
    """Compare metadata and recorded builds only; never inspect media or exports."""
    snapshot = catalog_snapshot(catalog); rule = settings['selection']
    known = previous.get('projects', {}) if previous else {}
    result = {'new': [], 'changed': [], 'kits': [], 'requirements': [], 'pending_games': 0, 'pending_targets': 0,
              'selected_games': 0, 'snapshot': snapshot, 'launcher': launcher_update(catalog)}
    for slug, project in sorted(catalog['projects'].items()):
        release = catalog['releases'][project['current']]
        targets = {key: target for key, target in release['targets'].items()
                   if selected(rule, 'projects', slug) and target_selected(rule, target)}
        label = project['title'] + ' ' + release['game_version']
        if previous and slug not in known:
            result['new'].append(label + ('' if targets else ' (choose 2 to include it)'))
        elif targets and slug in known:
            if known[slug]['version'] != release['game_version']:result['changed'].append(label)
            elif known[slug].get('kit_revision', release['kit_revision']) != release['kit_revision']:
                result['kits'].append(project['title'])
        if not targets:continue
        result['selected_games'] += 1
        olds = {key: installed.get('targets', {}).get(slug + '/' + key, {}) for key in targets}
        stale = {key for key, target in targets.items() if olds[key].get('identity') != target_identity(catalog, release, target)}
        # Tooling-only revisions keep their builds unless another build in the same export group changes.
        kept = {key for key in stale if same_game(olds[key], targets[key]) and olds[key].get('group') == output_group(targets[key])}
        rebuilding = {output_group(targets[key]) for key in stale - kept}
        pending = sum(key not in kept or output_group(targets[key]) in rebuilding for key in stale)
        result['pending_targets'] += pending; result['pending_games'] += bool(pending)
        if previous:
            inputs = {}
            for target in targets.values():
                for key in target['inputs']:inputs[key] = 'Source requirement'
                for option in target.get('input_options', []):
                    for key in option['inputs']:inputs.setdefault(key, 'Input option: ' + option['title'])
            messages = set()
            for key, kind in inputs.items():
                prior = known.get(slug, {})
                old_required = {name for target_id in targets for name in prior.get('target_inputs', {}).get(target_id, [])}
                changed = (key not in old_required or prior.get('inputs', {}).get(key) != snapshot['projects'][slug]['inputs'][key])
                # Old preview snapshots hashed CRC hints as prerequisites. They
                # can still identify game versions, but cannot compare input sets.
                if previous.get('schema') != 2:
                    changed = not prior or prior.get('version') != release['game_version']
                if changed:
                    spec = release['prerequisites'][key]
                    # ROM members from one required set share one player action.
                    messages.add(kind + ': ' + (spec['title'] + '. ' if spec['kind'] not in ('rom', 'device', 'firmware') else '') + spec['action'])
            for target in targets.values():
                for tool in target.get('external_tools', []):
                    if tool.get('hosts') and host() not in tool['hosts']:continue
                    if identity(tool) not in known.get(slug, {}).get('tools', []):
                        kind = 'Input option software' if tool.get('methods') else 'Software requirement'
                        messages.add(kind + ': ' + tool['title'] + '. ' + tool['action'])
            if messages:result['requirements'].append((project['title'], sorted(messages)))
    return result


def show_release_notice(notice, warning=''):
    print(ui_style('Release check', 'cyan'))
    if notice.get('launcher'):print(ui_style(launcher_message(notice['launcher']), 'yellow'))
    if warning:print(ui_style(warning, 'yellow'))
    for field, title in (('new', 'New games'), ('changed', 'New versions'), ('kits', 'Tooling updates')):
        if notice.get(field):
            print(ui_style(title + ':', 'cyan'))
            for name in notice[field][:5]:print('  ' + ui_style(name, 'green'))
            if len(notice[field]) > 5:print(f'  {len(notice[field]) - 5} more. Choose V for the full list.')
    if notice['requirements']:print(ui_style('Updated requirements (checked when building):', 'cyan'))
    for title, messages in notice['requirements'][:4]:
        print('  ' + ui_style(title, 'yellow'))
        for message in messages[:2]:print('    ' + message.removeprefix('Source requirement: '))
        if len(messages) > 2:print(f'    Plus {len(messages) - 2} other requirements.')
    if len(notice['requirements']) > 4:print(f"  {len(notice['requirements']) - 4} more games have updated requirements. Choose V for the full list.")
    if not notice['selected_games']:
        print('No games match these choices. Choose 2 to select games, platforms and regions.')
    elif notice['pending_targets']:
        games = str(notice['pending_games']) + (' game' if notice['pending_games'] == 1 else ' games')
        builds = str(notice['pending_targets']) + (' platform build' if notice['pending_targets'] == 1 else ' platform builds')
        print('To build or update: ' + ui_style(games + ' / ' + builds, 'cyan') + '.')
        print(ui_style('Next: choose 1.', 'cyan') + ' It checks your files and builds the ready games.')
    else:
        print('No new releases for your selected games.')
        print('Choose 1 to check or repair your exports, or 4 to exit.')


def release_snapshot(home):
    try:
        value = read_json(home / 'release-notices.json')
        require(isinstance(value, dict) and value.get('schema') in (1, 2) and isinstance(value.get('projects'), dict) and
                all(isinstance(row, dict) and isinstance(row.get('version'), str) and
                    isinstance(row.get('inputs'), dict) and isinstance(row.get('tools'), list)
                    for row in value['projects'].values()), 'Invalid release notice cache')
        return value
    except (OSError, Error, ValueError):return None


def release_history(home):
    path = home / 'release-changes.json'
    try:
        value = read_json(path)
        require(isinstance(value, dict) and value.get('schema') == 1 and isinstance(value.get('checks'), list) and len(value['checks']) <= 20,
                'Unknown release change cache')
        require(all(isinstance(row, dict) and isinstance(row.get('changes'), dict) and
                    all(isinstance(row['changes'].get(key), list) for key in ('new', 'changed', 'kits', 'requirements'))
                    for row in value['checks']), 'Invalid release change cache')
        return value
    except (OSError, Error, ValueError):return {'schema': 1, 'checks': []}


def record_release_changes(home, history, notice):
    changes = {key: notice.get(key, []) for key in ('new', 'changed', 'kits', 'requirements')}
    if any(changes.values()):
        history['checks'].append({'changes': changes, 'unread': True})
        history['checks'] = history['checks'][-20:]
        write_json(home / 'release-changes.json', history)


def launcher_update(catalog):
    """The catalog's newer launcher, if any. A malformed or unknown entry is ignored, never fatal."""
    entry = catalog.get('launcher') if isinstance(catalog, dict) else None
    if not (isinstance(entry, dict) and isinstance(entry.get('version'), str) and isinstance(entry.get('url'), str)
            and re.fullmatch(r'[0-9]+\.[0-9]+\.[0-9]+', entry['version'])
            and re.fullmatch(r'https://arcadepatches\.com/[A-Za-z0-9._~/-]*', entry['url'])):
        return None
    if version_tuple(entry['version']) <= version_tuple(VERSION):
        return None
    return {'version': entry['version'], 'url': entry['url']}


def launcher_message(update):
    return f"ArcadePatches {update['version']} is available (this is {VERSION}). Download it from {update['url']}"


def unread_release_changes(notice, history):
    result = dict(notice)
    for key in ('new', 'changed', 'kits', 'requirements'):
        result[key] = []
        for check in history['checks']:
            if check.get('unread'):
                for row in check['changes'][key]:
                    if row not in result[key]:result[key].append(row)
    return result


def acknowledge_release_changes(home, history):
    for check in history['checks']:check['unread'] = False
    write_json(home / 'release-changes.json', history)


def show_release_changes(history):
    print(ui_style('Recent release changes', 'cyan'))
    for number, check in enumerate(history['checks'], 1):
        if len(history['checks']) > 1:print(ui_style(f'Update {number}', 'cyan'))
        for field, title in (('new', 'New games'), ('changed', 'New versions'), ('kits', 'Tooling updates')):
            if check['changes'][field]:
                print(ui_style(title + ':', 'cyan'))
                for name in check['changes'][field]:print('  ' + ui_style(name, 'green'))
        for title, messages in check['changes']['requirements']:
            print(ui_style(title, 'yellow'))
            for message in messages:print('  ' + message.removeprefix('Source requirement: '))
    print('All changes from the saved release checks are shown above.')


def menu_catalog(args, home):
    try:
        catalog, local = load_catalog(args, home)
        return catalog, local, args.offline, 'Offline: using the saved catalog; new releases have not been checked.' if args.offline else ''
    except (urllib.error.URLError, TimeoutError) as exc:
        if args.catalog:raise
        warning = 'Could not check new releases online: ' + str(exc)
        if (home / 'catalog.json').is_file():
            catalog, local = load_catalog(argparse.Namespace(catalog=None, offline=True), home)
            return catalog, local, True, warning + '. Using the saved catalog for this session.'
        return None, None, args.offline, warning + '. Connect to the internet, then choose 1 to retry.'


def show_banner():
    if shutil.get_terminal_size().columns >= max(map(len, LOGO.splitlines())):
        print(ui_style(LOGO, 'cyan'))
    else:
        print(ui_style('[ ArcadePatches ]', 'cyan'))
    print(f"  arcadepatches.com | v{VERSION}\n", flush=True)


def prompt_roots(previous=()):
    print('Enter a folder containing your ROMs or other game media. Everything inside it,')
    print('including subfolders, will be scanned. Loose files, ZIPs and supported 7z archives')
    print('can stay as they are—no need to extract or rename them.\n')
    print(ui_style('Enter ROM/media folders, one per line. Blank finishes the list.', 'cyan'))
    if previous:
        print("Current folders:\n" + "\n".join("  " + p for p in previous))
        print("Leave the first entry blank to keep these folders.")
    roots = []
    while True:
        value = input("Media folder: ").strip()
        if not value:
            if roots or previous:
                return roots or list(previous)
            print("Enter at least one folder.")
            continue
        path = str(Path(value).expanduser().resolve())
        if path not in roots:
            roots.append(path)


def prompt_selection(title, choices, previous):
    choices = dict(choices)
    if previous != "all":
        for key in previous:
            choices.setdefault(key, key + " (not in this catalog)")
    entries = sorted(choices)
    print(ui_style(title + ':', 'cyan'))
    print("  all. Everything, including future additions")
    for number, key in enumerate(entries, 1):
        print(f"  {number}. {choices[key]}")
    print("Current: " + ("all" if previous == "all" else ", ".join(choices[k] for k in previous)))
    while True:
        answer = input("Choose all or comma-separated numbers (blank keeps current): ").strip().lower()
        if not answer:
            return previous
        if answer == "all":
            return "all"
        parts = answer.split(",")
        if all(part.strip().isdigit() and 1 <= int(part) <= len(entries) for part in parts):
            return sorted({entries[int(part) - 1] for part in parts})
        print("Choose all or numbers from the list.")


def prompt_settings(previous, catalog, home):
    settings = json.loads(json.dumps(previous))
    settings["roots"] = prompt_roots(previous["roots"])
    print("Current output folder: " + previous["output"])
    output = input("Output folder (blank keeps current): ").strip()
    if output:
        settings["output"] = str(Path(output).expanduser().resolve())
    validate_settings(settings, home)
    rule = settings["selection"]
    rule["platforms"] = prompt_selection("Platforms", PLATFORMS, rule["platforms"])
    projects = {key: spec["title"] for key, spec in catalog["projects"].items()}
    projects.update({p["id"]: p["title"] + " (integration pending)" for p in catalog.get("not_integrated", [])})
    rule["projects"] = prompt_selection("Games", projects, rule["projects"])
    regions = dict(REGIONS)
    for release in catalog["releases"].values():
        for target in release["targets"].values():
            for region in target.get("regions", [target["region"]] if target.get("region") else []):
                regions.setdefault(region, region.replace("-", " ").title())
    rule["regions"] = prompt_selection("Regions", regions, rule.get("regions", "all"))
    return settings


def region_argument(value):
    value = value.lower()
    value = {"usa": "us", "japan": "jp", "europe": "eu"}.get(value, value)
    try:
        token(value)
    except Error as exc:
        raise argparse.ArgumentTypeError(str(exc)) from exc
    return value


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", nargs="?", choices=("configure", "scan", "plan", "update", "status", "doctor"))
    parser.add_argument("--home", type=Path, default=Path.home() / "ArcadePatches")
    parser.add_argument("--catalog", type=Path, help="explicit local development catalog; never used implicitly")
    parser.add_argument("--offline", action="store_true")
    parser.add_argument("--json", action="store_true", help="emit a machine-readable report")
    parser.add_argument("--verify-sources", action="store_true", help="fully read and hash source candidates during scan/plan (slower diagnostic)")
    parser.add_argument("--rompath", action="append", type=Path)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--platform", action="append", choices=sorted(PLATFORMS), help="configure selected platforms; default all")
    parser.add_argument("--project", action="append", help="configure selected stable project IDs; default all")
    parser.add_argument('--cache-gb', type=int, help='configure reusable cache byte budget in GiB (default 20)')
    parser.add_argument('--cache-entries', type=int, help='configure reusable cache entry budget (default 256)')
    parser.add_argument("--region", action="append", type=region_argument,
                        help="configure output regions (us, jp, eu, asia, world); repeatable; default all")
    args = parser.parse_args(argv)
    with TerminalUI(quiet=args.json or args.command in ('status', 'doctor')) as ui:
        # Status and doctor already emit JSON even without the explicit flag.
        if not args.json and args.command not in ("status", "doctor"):
            if args.command is None:ui.clear_screen()
            show_banner()
        progress = None if ui.quiet else ui.phase
        try:
            home = filesystem_path(args.home)
            home.mkdir(parents=True, exist_ok=True)
            with maintained(home), contextlib.ExitStack() as source_stack:
                config_path = home / "settings.json"
                if args.command == "doctor":
                    print(json.dumps({"python": sys.version.split()[0], "host": host(), "home": str(home),
                                      "free_bytes": shutil.disk_usage(home).free, "launcher": VERSION, "features": sorted(FEATURES)}, indent=2))
                    return 0
                if args.command == "configure" or not config_path.exists():
                    roots = args.rompath
                    output = args.output
                    if not roots:
                        require(sys.stdin.isatty(), "Configure first using --rompath and --output")
                        roots = [Path(p) for p in prompt_roots()]
                    if not output:
                        require(sys.stdin.isatty(), "Specify --output")
                        value = input("Output folder: ").strip()
                        require(value, "Specify an output folder")
                        output = Path(value)
                    settings = {"schema": 1, "roots": [str(p.expanduser().resolve()) for p in roots],
                                "output": str(output.expanduser().resolve()),
                                "selection": {"projects": args.project or "all", "platforms": args.platform or "all",
                                              "variants": "all", "regions": "all" if not args.region or args.region == ["all"] else sorted(set(args.region)),
                                              "include_future": True}}
                    prior = read_json(config_path) if config_path.exists() else {}
                    limits = cache_limits(prior)
                    settings['cache_limits'] = {'max_bytes':args.cache_gb*1024**3 if args.cache_gb is not None else limits['max_bytes'],
                        'max_entries':args.cache_entries if args.cache_entries is not None else limits['max_entries']}
                    require(not args.region or "all" not in args.region or args.region == ["all"], "Use --region all by itself")
                    validate_settings(settings, home)
                    write_json(config_path, settings)
                    if args.command == "configure":
                        print(f"Saved selection (including future matching releases) in {config_path}")
                        return 0
                settings = read_json(config_path)
                require(settings.get("schema") == 1, "Unsupported settings version")
                validate_settings(settings, home)
                output = filesystem_path(settings["output"])
                require(not home.is_relative_to(output) and output != home, "Tool state cannot be inside the output folder")
                recover(home, output)
                cleanup_backups(home, output)
                if args.command == "status":
                    state = read_json(home / "installed.json") if (home / "installed.json").exists() else {"groups": {}}
                    measured = {g: tree_contract(safe_path(output, g)) == spec for g, spec in state["groups"].items()}
                    print(json.dumps({"groups_intact": measured, "currency": "not checked online"}, indent=2))
                    return 0 if all(measured.values()) else 2
                command = args.command
                menu_data = None
                seen_path = home / 'release-notices.json'
                previous_notice = release_snapshot(home) if args.command is None else None
                history = release_history(home) if args.command is None else {'schema': 1, 'checks': []}
                if args.command is None:
                    if progress:progress('Checking releases (catalog only)...')
                    menu_data = menu_catalog(args, home)
                    ui.finish()
                while True:
                    while command is None:
                        require(sys.stdin.isatty(), "Specify scan, plan or update for unattended use")
                        print("Media folders:\n" + "\n".join("  " + p for p in settings["roots"]))
                        print("Output: " + settings["output"])
                        print(selection_summary(settings["selection"]))
                        recorded = read_json(home / 'installed.json') if (home / 'installed.json').exists() else {}
                        if menu_data[0] is not None:
                            notice = release_notice(menu_data[0], settings, recorded, previous_notice)
                            record_release_changes(home, history, notice)
                            show_release_notice(unread_release_changes(notice, history), menu_data[3])
                            previous_notice = notice['snapshot']; write_json(seen_path, previous_notice)
                        else:print(ui_style(menu_data[3], 'yellow'))
                        print(ui_style('[1] ' + ('Update' if recorded.get('targets') else 'Build'), 'cyan'))
                        print('[2] Change games, platforms, regions and folders')
                        print('[3] Check requirements only (optional; does not build)')
                        if history['checks']:print('[V] View all release changes')
                        prompt = 'Choose 1, 2, 3, 4 or V: ' if history['checks'] else 'Choose 1, 2, 3 or 4: '
                        choice = input('[4] Exit\n' + prompt).strip()
                        if choice.lower() == 'v' and history['checks']:
                            show_release_changes(history)
                            acknowledge_release_changes(home, history)
                            continue
                        if choice == "4":
                            return 0
                        if choice == "2":
                            if menu_data[0] is None:
                                if progress:progress('Checking releases (catalog only)...')
                                menu_data = menu_catalog(args, home); ui.finish()
                            if menu_data[0] is None:
                                print(menu_data[3]); continue
                            revised = prompt_settings(settings, menu_data[0], home)
                            write_json(config_path, revised)
                            settings = revised
                            output = filesystem_path(settings["output"])
                            print("Setup saved. Existing exports are retained; changes apply to the next update.")
                            continue
                        if choice not in ("1", "3"):
                            print("Choose 1, 2, 3 or 4.")
                            continue
                        command = "update" if choice == "1" else "scan"
                    if args.command is None:
                        if menu_data[0] is None:
                            if progress:progress('Checking releases (catalog only)...')
                            menu_data = menu_catalog(args, home); ui.finish()
                        catalog, local_root, operation_offline, _ = menu_data
                        if catalog is None:
                            print(menu_data[3]); command = None; continue
                    else:
                        if progress:progress('Loading catalog...')
                        catalog, local_root = load_catalog(args, home)
                        operation_offline = args.offline
                    installed = read_json(home / "installed.json") if (home / "installed.json").exists() else {}
                    if progress:
                        progress("Identifying ROMs and media; checking prerequisites...")
                    discovery = SourceDiscoveryCache(home)
                    source_stack.callback(discovery.save)
                    archives = source_stack.enter_context(SevenZipSources(catalog, home, operation_offline, local_root, progress, discovery))
                    report = plan(catalog, settings, home, installed, offline=operation_offline, archives=archives, metadata_only=not args.verify_sources)
                    report['_key_cache'] = discovery.data['keys']
                    report['_source_cache'] = discovery.data['digests']
                    report["offline"] = operation_offline
                    update_notice = launcher_update(catalog)
                    if update_notice:report["launcher_update"] = update_notice
                    if command == "update":
                        check_export_metadata(home, output)
                        report = update(catalog, settings, home, report, operation_offline, local_root, progress)
                    # Shareable reports omit source bindings and configured media paths.
                    public = redact(report, settings["roots"] + [str(filesystem_path(p)) for p in settings["roots"]]
                                    + [str(home), str(output)])
                    write_json(home / "last-report.json", public)
                    if command == "update":
                        write_json(output / "build-report.json", public)
                        (output / "INSTALL.txt").write_text(
                            "Copy each completed platform folder to its target.\n"
                            "See build-report.json for blocked/failed updates and retained older outputs.\n"
                            "This tool does not install emulators or synchronize destinations.\n"
                            "Destination prerequisites for selected targets:\n" +
                            "".join(f"  {platform}: {requirement}\n" for platform,requirement in sorted({
                                (PLATFORMS.get(r['platform'],r['platform']),r['destination_requirements']) for r in report['targets'] if r.get('destination_requirements')})) +
                            "Obsolete paths from prior exports (manual destination review):\n" +
                            "".join(f"  {item['group']}/{item['path']}\n" for item in report["obsolete_paths"]), encoding="utf-8")
                        write_json(home / "export-metadata.json", {name: {"size": (output / name).stat().st_size,
                                   "sha256": digest(output / name)} for name in ("INSTALL.txt", "build-report.json")})
                    ui.finish()
                    if args.json:
                        print(json.dumps(public, indent=2))
                    else:
                        if update_notice and args.command is not None:print(ui_style(launcher_message(update_notice), 'yellow'))
                        show(report, compact=args.command is None)
                        details = io.StringIO()
                        with contextlib.redirect_stdout(details):show(public, group_roms=False, details=True)
                        (home / "last-report.txt").write_text(re.sub(r"\033\[[0-9;]*m", "", details.getvalue()), encoding="utf-8")
                        if args.command is not None or report['source_findings'] or any(
                                row['status'] in ('blocked', 'failed', 'unsupported') for row in report['targets']):
                            print("Detailed report: " + str(home / "last-report.txt"))
                        if args.command is None:
                            if command == 'scan':print('Next: choose 1 to verify the source candidates and build. Add any missing media to your folders first.')
                            elif any(row['status'] in ('built', 'current') for row in report['targets']):
                                print('Next: copy the platform folders from ' + str(output) + ' to your setup. Read INSTALL.txt there.')
                            else:print('No games were built. Add the listed media or resolve the requirements, then choose 1 again.')
                    source_stack.close()
                    if args.command is None and command == 'update':acknowledge_release_changes(home, history)
                    if args.command is None:
                        command = None
                        continue
                    return 0 if all(r["status"] in ("ready", "available", "built", "current") for r in report["targets"]) and not report["source_findings"] and not report["not_integrated"] else 2
        except (EOFError, KeyboardInterrupt):
            ui.finish("Interrupted")
            print(ui.paint("Input cancelled.", "yellow"), file=sys.stderr)
            return 130
        except (Error, OSError, ValueError, KeyError, TypeError, zipfile.BadZipFile, subprocess.SubprocessError) as exc:
            ui.finish("Stopped")
            print(ui.paint(f"ERROR: {exc}", "red"), file=sys.stderr)
            return 1


if __name__ == "__main__":
    if len(sys.argv) == 3 and sys.argv[1] == '_sevenzip':
        read_sevenzip(sys.argv[2])
        raise SystemExit(0)
    if len(sys.argv) == 3 and sys.argv[1] == '_environment':
        raise SystemExit(environment_worker(sys.argv[2]))
    if len(sys.argv) == 4 and sys.argv[1] == '_supervise':
        raise SystemExit(supervise(sys.argv[2], sys.argv[3]))
    raise SystemExit(main())
