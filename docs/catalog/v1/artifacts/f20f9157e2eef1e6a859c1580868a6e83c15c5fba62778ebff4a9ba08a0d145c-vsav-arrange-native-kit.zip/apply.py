#!/usr/bin/env python3
"""Rebuild Vampire Savior Arrange from your own arcade ROMs and Collection disc."""

# BEGIN ARCADE PYTHON BOOTSTRAP
import sys as _arcade_sys
from pathlib import Path as _ArcadePath
_arcade_sys.path.insert(0, str(_ArcadePath(__file__).resolve().parents[0]))
from kit_python import bootstrap as _arcade_bootstrap
_arcade_bootstrap()
# END ARCADE PYTHON BOOTSTRAP
import sys as _native_sys
from pathlib import Path as _NativePath
if __name__ == '__main__' and ('--collection-layout' in _native_sys.argv or '--describe-json' in _native_sys.argv):
    _native_sys.path.insert(0, str(_NativePath(__file__).resolve().parent))
    from arrange_collection import main as _native_main
    raise SystemExit(_native_main(_NativePath(__file__).resolve().parent))
import argparse,json,shutil,tempfile,sys
from pathlib import Path
from rom_sources import Resolver,search_paths,write_zip,publish_tree,require_path,default_output,check_output,print_completion
from vsa_codec import Inputs,reconstruct,scene_pack
from cps2_code_guard import check_archive,require_code_spans
HERE=Path(__file__).resolve().parent


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--iso',required=True);p.add_argument('--chdman')
    p.add_argument('--romset',action='append',default=[]);p.add_argument('--rompath',action='append',default=[])
    p.add_argument('--region',choices=('us','jp','all'),default='all');p.add_argument('--out-dir')
    p.add_argument('--debug',action='store_true',help='show a traceback for troubleshooting')
    a=p.parse_args()
    a.iso=require_path(a.iso,'--iso',file=True)
    out=check_output(a.out_dir or default_output('output-vsav-arrange'),[a.iso,*a.romset,*a.rompath])
    # Validate every explicit source before reading any ROM or creating scratch.
    search_paths(None,[*a.romset,*a.rompath],HERE)
    out.parent.mkdir(parents=True,exist_ok=True)
    print('[1/3] Checking arcade and Collection inputs...')
    value=json.loads((HERE/'reconstruction.json').read_text());catalog=json.loads((HERE/'rom_inputs.json').read_text())['sets']
    paths=[]
    for path in a.romset:paths+=search_paths(path,a.rompath,HERE)
    resolver=Resolver(dict.fromkeys(paths or search_paths(None,a.rompath,HERE)),hints=[*catalog,'qsound','qsound_hle'],exclude=[out],progress=print)
    roms={name:resolver.resolve(list(pins.values()))for name,pins in catalog.items()}
    files=build_native_outputs(a.iso,roms,None,a.region,a.chdman)
    publish_tree(out,files);print_completion(out,files)
    print('Built '+a.region+'; all ROM members and the music pack verified.')


def check_native_disc(iso):
    import collection
    return collection.Disc(str(iso))


def build_native_outputs(iso,roms,firmware,region,chdman=None):
    check_native_disc(iso)
    value=json.loads((HERE/'reconstruction.json').read_text());catalog=json.loads((HERE/'rom_inputs.json').read_text())['sets']
    with tempfile.TemporaryDirectory(prefix='.vsa-',)as directory:
        work=Path(directory);romroot=work/'roms';romroot.mkdir();stage=work/'stage'
        for name,pins in catalog.items():write_zip(romroot/(name+'.zip'),roms[name])
        print('[2/3] Reconstructing and verifying outputs...')
        inputs=Inputs(romroot,iso,value['spec'],work,chdman)
        regions=('us','jp')if region=='all'else(region,)
        for region in regions:
            q=value['regions'][region];native=reconstruct(inputs,q)
            require_code_spans(value['spec']['code_spans'],key=native['vsavj.key'])
            members={q['names'][n]:b for n,b in native.items()}
            game=stage/'hbmame'/(q['set']+'.zip');write_zip(game,members)
            if check_archive(game)['status']!='passed':raise ValueError('complete executable range audit failed')
            write_zip(stage/'mister/games/hbmame'/game.name,members)
            folder=stage/'mister/_Arcade/_Arcade Patches/_Restorations'/('_Japan'if region=='jp'else'');folder.mkdir(parents=True)
            for title in q['mras']:shutil.copyfile(HERE/'mras'/(title+'.mra'),folder/(title+'.mra'))
        cpk=work/'vampire_arrange.cpk';scene_pack(inputs,value,cpk)
        write_zip(stage/'mister/games/CPS+/vampire_arrange.zip',{'vampire_arrange.cpk':cpk.read_bytes()})
        core=json.loads((HERE/'kit.json').read_text())['core'];dst=stage/'mister/_Arcade/cores'/core;dst.parent.mkdir(parents=True)
        shutil.copyfile(HERE/'core'/core,dst)
        from arrange_collection import tree_outputs
        return tree_outputs(stage)

if __name__=='__main__':
    try:main()
    except (OSError,ValueError) as exc:
        if '--debug' in sys.argv:raise
        raise SystemExit(f'ERROR: {exc}')
