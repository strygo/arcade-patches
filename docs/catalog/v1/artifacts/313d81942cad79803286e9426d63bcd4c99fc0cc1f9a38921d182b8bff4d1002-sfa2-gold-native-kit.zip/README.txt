ROM INPUT UPDATE

Merged, split, complete ZIP/7z archives and extracted ROM folders are accepted.
Use --rompath DIR (repeatable) to search a collection, or keep the existing archive argument.
Names may differ; required source contents are verified by size and strong hashes.
Use --check to verify arcade build inputs before reconstruction.
QSound is optional for game builds. Valid embedded firmware is preserved in complete game outputs.
Use --include-devices on CPS-2 kits to require and include firmware from separate archives.
Compact HBMAME outputs retain their stock-game and device dependencies.
7z input requires an installed 7-Zip executable; ZIP needs no extra archive software.
Original archives are never modified by collection discovery.

Street Fighter Alpha 2 Gold / Zero 2 Dash — reconstruction kit
==============================================================

Version:      rc7 (2026-10-12)
Language:     Approved English restoration; Japan retains Japanese text
Hardware:     Capcom CPS-2
Target:       MAME and HBMAME sets, and MiSTer (jtcps2) — 4 regions
Backport by:  Steve Gordon (https://x.com/strygo)
Website:      https://arcadepatches.com/sfa2-gold/

This kit builds the CPS-2 arcade backport of Street Fighter Alpha 2 Gold /
Zero 2 Dash from your own PlayStation 2 disc image and arcade romset. Original
game ROMs are not included.

WHAT YOU NEED
-------------

  1. Your PlayStation 2 anthology disc image:
       - USA / Asia : "Street Fighter Alpha Anthology" (USA)
       - Japan      : "Street Fighter Zero - Fighter's Generation" (Japan)
       - Europe     : "Street Fighter Alpha Anthology" (Europe)
  2. Your arcade Street Fighter Zero 2 Alpha romset:
       - sfz2al.zip  for the USA / Europe / Asia sets
       - sfz2alj.zip for the Japan set
  3. Python 3.10 or newer. Nothing else — no emulator, no assembler.

USAGE (recommended — build every platform for one region)
----------------------------------------------------------

    python3 apply.py --iso <anthology.iso> --romset <sfz2al.zip> \
                     --region <jp|us|eu|asia> --out-dir out

This creates:

    out/mame/<region>/<set>.zip  4MB — stock MAME or real CPS-2 hardware
    out/hbmame/<set>.zip         8MB — HBMAME, with every sound uncompressed
    out/mister/                  8MB — ready to copy to a MiSTer SD card

Use the same output folder when building more than one region. Each region
needs the matching disc listed above.

REGIONS
-------

    us    Street Fighter Alpha 2 Gold
    eu    Street Fighter Alpha 2 Dash
    jp    Street Fighter Zero 2 Dash (Japan)
    asia  Street Fighter Zero 2 Dash (English)

USAGE (single file)
-------------------

    python3 apply.py --iso ... --romset ... --region us --size 8mb --out sfa2g.zip

The kit verifies the finished files automatically. It stops with an error if
the supplied disc or romset does not match the selected region.

MAME and HBMAME will show checksum warnings because this is an unofficial
build. Those warnings are expected.

ON MISTER
---------

Copy the contents of out/mister/ to the root of the MiSTer SD card:

    _Arcade/_Arcade Patches/_Restorations/<name>.mra          the USA MRA
    _Arcade/_Arcade Patches/_Restorations/_Europe/<name>.mra  the other
    _Arcade/_Arcade Patches/_Restorations/_Asia/<name>.mra    regions, each
    _Arcade/_Arcade Patches/_Restorations/_Japan/<name>.mra   in its folder
    games/hbmame/<set>.zip                                    the 8MB sets

Earlier releases put these MRAs in _Arcade/_Arcade Patches/_Enhanced Versions
or _Arcade/_Backports; delete them from there when you copy the new ones over.

The standard Jotego jtCPS2 core is required. If QSound was absent from your input, keep qsound.zip or qsound_hle.zip in
games/mame on MiSTer. MAME/HBMAME can find it in their normal ROM paths.

LEGAL
-----

Unofficial fan reconstruction. Not affiliated with or endorsed by Capcom. All
game titles, characters, and artwork remain the property of their owners. You
must own the disc and romset used as inputs. The recipes carry one piece of
Capcom data: about 4 KB of Cammy's theme score from X-Men vs. Street Fighter
(Capcom, 1996), which her stage music is built from. Do not sell this kit or distribute
it applied to game images.

ROM COLLECTIONS
---------------
Merged, split and complete ZIP/7z sets and extracted folders are accepted.
Use --rompath DIR (repeatable) to search a collection. Names may differ;
required contents are verified by strong hashes. 7z uses installed 7-Zip or a verified download.
Use --check to preflight arcade inputs without supplying the disc.
--out-dir builds all supported platforms; --platform selects just one.
Source archives are never modified.
QSound is optional when building. Valid embedded firmware is preserved.
--include-devices requires and includes firmware from any supplied archive.

DARKSOFT OUTPUT

Use --platform darksoft --out-dir out, or --platform all.
Copy the game folder from out/darksoft/games to the card games folder.
Gold uses the best 8 MiB native-sample version, matching HBMAME.
Expanded hardware and streamed audio are not supported.

PYTHON PACKAGES

When a build needs NumPy or Pillow and it is not already installed, the kit
downloads its pinned prebuilt package from PyPI into your user cache. No pip,
compiler, administrator rights or changes to system Python are needed.
Patch-only builds and --help do not download Python packages.

Automatic package installation is qualified for CPython 3.12 on Apple Silicon
Macs and CPython 3.13 x64 on Windows (including x64 Python on Windows ARM).
Other interpreters can still use manually installed NumPy/Pillow. There is
no automatic source compilation or selection of an unqualified package.

Cache: ~/Library/Caches/ArcadePatches/python on Mac, or
%LOCALAPPDATA%/ArcadePatches/python on Windows. You can choose another location
with --python-cache PATH (or ARCADE_PYTHON_CACHE). --tools-cache PATH places
the Python cache under PATH/python unless --python-cache is also supplied.
You may delete this cache when no installer is running; it is recreated later.

Offline: add --python-wheels PATH --offline. PATH may name the matching
python-wheels-v1-*.zip, a folder of unzipped wheels, or a folder containing
the wheel ZIPs. The existing wheel bundles work without modification.
You can also supply --tools-bundle for the other helpers in the same command.
ARCADE_PYTHON_WHEELS is the equivalent environment variable. A warm cache
works offline without a bundle. --offline prohibits package downloads too.
Every wheel is checked against the kit's hash; cached extracted files are
verified before use. Existing manually installed packages remain supported.

The installer and its Python subprocesses share the cache. Your shell profile,
global site-packages and unrelated Python applications are not changed.

FBNEO OUTPUT

The default build also writes complete game ZIPs under out/fbneo/, preserving FBNeo set and ROM member names.
Use --platform fbneo --out-dir out to build only those sets. Use an FBNeo version with matching game definitions.

FBNEO OUTPUT

The default build also writes complete game ZIPs under out/fbneo/, preserving FBNeo set and ROM member names.
Use --platform fbneo --out-dir out to build only those sets. Use an FBNeo version with matching game definitions.
