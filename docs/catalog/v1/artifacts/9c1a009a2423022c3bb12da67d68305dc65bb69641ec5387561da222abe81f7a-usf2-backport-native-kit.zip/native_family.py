"""Kit-owned usf2 native input/export implementation."""
import argparse
import hashlib
import importlib
import json
import os
from pathlib import Path
import runpy
import shutil
import subprocess
import sys
import tempfile
import zipfile
from native_support import (check, execute, require, sha, source, write_zip,
    file_sha, inventory, verify_raw, canonicalize_mras, stage_disc, stage_components)

def digest(path):
    result = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            result.update(block)
    return result.hexdigest()

def original_source(binding, destination):
    if 'member' in binding:
        stage_components({'game': binding}, {'game.nsp': 'game'}, destination)
        return destination / 'game.nsp'
    path = Path(binding['path'])
    before = path.stat()
    require(before.st_size == binding['size'] and digest(path) == binding['sha256'], 'Owned base game changed after discovery')
    after = path.stat()
    require((before.st_ino, before.st_size, before.st_mtime_ns) == (after.st_ino, after.st_size, after.st_mtime_ns), 'Owned base game changed while reading')
    return path

def cached_unlock(original, request, layout, target, shared, counters):
    binding = request['bindings'][target['nsp']]
    key_binding = request['bindings'][layout['keys']]
    identity = hashlib.sha256(json.dumps({'kit': layout['manifest_sha256'], 'source': binding['sha256'], 'private_keys': key_binding['sha256'], 'region': target['region']}, sort_keys=True).encode()).hexdigest()
    root = shared / ('usf2-unlock-' + identity)

    def unlock(path, keys, pin, work, tools_source=None):
        marker, keyfile = (root / 'complete.json', root / 'source.key')
        if marker.exists():
            metadata = json.loads(marker.read_text())
            require(metadata['identity'] == identity and keyfile.is_file() and (digest(keyfile) == metadata['sha256']), 'Same-run USF2 resource-key cache changed')
            counters['verified_reuses'] += 1
            return keyfile.read_bytes()
        root.mkdir(parents=True, exist_ok=True)
        key = original(path, keys, pin, work, tools_source)
        require(isinstance(key, bytes) and len(key) <= 4096, 'Unexpected original resource-key format')
        keyfile.write_bytes(key)
        marker.write_text(json.dumps({'identity': identity, 'sha256': digest(keyfile)}))
        counters['unlocks'] += 1
        shutil.rmtree(work)
        return key
    return unlock

def run(request, layout, kit, workspace):
    target = layout['targets'][request['target']]
    inputs = workspace / 'usf2-inputs'
    inputs.mkdir(exist_ok=True)
    rompath = inputs / 'roms'
    rompath.mkdir(exist_ok=True)
    roms = {n: source(request['bindings'][key]) for n, key in target['sources'].items()}
    write_zip(rompath / 'ssf2xj.zip', roms)
    write_zip(rompath / 'qsound.zip', {'dl-1425.bin': roms['dl-1425.bin']})
    keys = inputs / 'private.keys'
    keys.write_bytes(source(request['bindings'][layout['keys']]))
    game = original_source(request['bindings'][target['nsp']], inputs)
    os.environ.pop('CAPCOM_ARCADE_ROM_PATH', None)
    os.environ.pop('CPSPLUS_PYTHON', None)
    os.environ['ARCADE_PYTHON_CACHE'] = str(Path(request['tools_cache']) / 'python')
    sys.path.insert(0, str(kit))
    shared = Path(request['run_cache'])
    shared.mkdir(parents=True, exist_ok=True)
    nsp = importlib.import_module('nsp')
    counters = {'unlocks': 0, 'verified_reuses': 0}
    nsp.unlock = cached_unlock(nsp.unlock, request, layout, target, shared, counters)
    work = workspace / 'usf2-work'
    raw = workspace / 'usf2-raw'
    argv = ['--region', target['region'], '--source-' + target['region'], game, '--keys', keys, '--rompath', rompath, '--platform', target['platform'], '--work', work, '--tools-cache', request['tools_cache']]
    if request.get('offline'):
        argv.append('--offline')
    if request['operation'] == 'preflight':
        argv.append('--check')
    else:
        argv += ['--out-dir', raw]
    try:
        execute(kit, argv)
        response = {'status': 'ok', 'dependencies': {'source_resource': counters}}
        if request['operation'] == 'build':
            sys.argv = [str(kit / 'verify_output.py'), '--root', str(raw)]
            try:
                runpy.run_path(str(kit / 'verify_output.py'), run_name='__main__')
            except SystemExit as exc:
                require(exc.code in (None, 0), 'Public relocated USF2 verification failed')
            for name, spec in layout['common'].items():
                check(raw / name, spec)
            permitted = set(layout['common']) | {'files.json', 'verification.json'} | set(target['mapping'])
            if target['platform'] == 'mame':
                permitted.add('mame/RUN-MAME.txt')
            actual = {f.relative_to(raw).as_posix() for f in raw.rglob('*') if f.is_file()}
            require(actual == permitted, 'USF2 original output extent differs')
            staging = Path(request['staging'])
            for origin, mapping in ((raw, target['mapping']), (kit, target['kit_mapping'])):
                for old, new in mapping.items():
                    destination = staging / new
                    destination.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copyfile(origin / old, destination)
            if target['device_output']:
                write_zip(staging / target['device_output'], {'dl-1425.bin': roms['dl-1425.bin']})
            require({f.relative_to(staging).as_posix() for f in staging.rglob('*') if f.is_file()} == set(target['outputs']), 'Unexpected USF2 exported files')
            for name, spec in target['outputs'].items():
                check(staging / name, spec)
            response['outputs'] = target['outputs']
        return response
    finally:
        shutil.rmtree(inputs)


import re
import xml.etree.ElementTree as ET
import native_support as contracts

def define(root, slug, version, revision, native, registry):
    archive = contracts.Directory(root)
    qualified = dict(native)
    for report in ('files.json', 'verification.json'):qualified.setdefault(report, {'sha256': '0' * 64})
    kit = json.loads(archive.read('kit.json'))
    contracts.require(kit.get('mame_layout') == 'stock-hsf2-v1' and json.loads(archive.read('build-info.json'))['kit_revision'] == revision, 'Unknown USF2 layout/revision')
    policy = {'__name__': 'public_usf2_policy'}
    exec(compile(archive.read('policy.py'), 'public_usf2_policy.py', 'exec'), policy)
    profiles = {n: r for n, r in kit['profiles'].items() if policy['platforms_for'](n, ('mame', 'hbmame', 'mister', 'darksoft'))}
    contracts.require({r['region'] for r in profiles.values()} == {'us', 'jp'}, 'Incomplete USF2 shipping profile matrix')
    private_reports = {'files.json', 'verification.json', 'mame/RUN-MAME.txt'}
    common = {n: s for n, s in qualified.items() if n not in private_reports and (not n.startswith(('mame/', 'hbmame/', 'mister/', 'darksoft/')))}
    known_support = {'README.txt', 'cps2_code_guard.py', 'cps2_crypt.py', 'darksoft.py', 'darksoft_profiles.json', 'install_driver.py', 'mra_assembly.py', 'nsp.py', 'payload.py', 'policy.py', 'source-kit.json', 'stock_mame.py', 'switch_source.py', 'verify.py', 'verify_output.py'}
    contracts.require(all((n in known_support or (n.startswith('definitions/') and n.endswith('.cpp.inc')) for n in common)), 'Unknown USF2 producer support/output role')
    for name, spec in common.items():
        original = 'kit.json' if name == 'source-kit.json' else name
        contracts.require({'sha256': hashlib.sha256(archive.read(original)).hexdigest()} == spec, 'USF2 immutable verifier/support differs: ' + name)
    release = {'game_version': version, 'kit_revision': revision, 'requires': ['file-inputs-v1', 'run-cache-v1', 'locked-wheels-v1', 'text-keys-v1'], 'prerequisites': {}, 'targets': {}}
    keyfile = 'switch-production-keys'
    release['prerequisites'][keyfile] = {'title': 'Your own Nintendo Switch prod.keys', 'kind': 'keyfile', 'formats': ['UTF-8 private key map, loose or ZIP member'], 'text_keys': {'header_key': 64}, 'action': 'Add your own private key file to a scanned folder. Keep one intended key map; the original producer verifies that it decrypts the game. Key values are never reported.'}
    roms = {row['name']: row for row in kit['arcade_inputs']}
    romkeys = {}
    for name, row in roms.items():
        key = 'rom-' + row['sha256'][:20]
        romkeys[name] = key
        release['prerequisites'][key] = {'title': 'QSound firmware' if name == 'dl-1425.bin' else 'Super Street Fighter II X: ' + name, 'kind': 'firmware' if name == 'dl-1425.bin' else 'rom', 'formats': ['MAME ZIP members', 'loose canonical ROMs'], 'action': 'Add your canonical MAME SSF2XJ and QSound inputs; names may differ.', 'alternatives': [{k: row[k] for k in ('size', 'sha256', 'crc32') if k in row}]}
    nsps = {}
    for region in ('us', 'jp'):
        pin = registry['inputs']['nsp_' + region]
        contracts.require(pin['sha256'] == kit['nsp'][region]['nsp_sha256'], 'Native USF2 media declaration differs from producer')
        key = 'game-' + pin['sha256'][:20]
        nsps[region] = key
        release['prerequisites'][key] = {'title': 'Ultra Street Fighter II ' + ('USA' if region == 'us' else 'Japan') + ' base NSP', 'kind': 'game', 'formats': ['NSP', 'ZIP member containing the base NSP'], 'action': 'Add your owned regional base NSP, not an update-only image. This initial catalog accepts the independently qualified NSP encoding; XCI is not yet catalogued.', 'alternatives': [{'size': pin['size'], 'sha256': pin['sha256']}]}
    recipe = {'manifest_sha256': 'native-manifest', 'keys': keyfile, 'common': common, 'private_reports': {n: qualified[n] for n in private_reports}, 'targets': {}}
    covered = set(common) | private_reports
    for profile, record in sorted(profiles.items()):
        region = record['region']
        native = policy['native_name'](profile)
        sources = {name: romkeys[name] for name in {r['source'] for r in record['members'].values() if r['source']}}
        sources['dl-1425.bin'] = romkeys['dl-1425.bin']
        for platform in policy['platforms_for'](profile, ('mame', 'hbmame', 'mister', 'darksoft')):
            mapping = {}
            if platform == 'mame':
                stock = {'us': 'hsf2', 'jp': 'hsf2j'}[region]
                mapping['mame/' + stock + '.zip'] = 'roms/' + stock + '.zip'
            elif platform == 'hbmame':
                mapping['hbmame/' + native + '.zip'] = 'roms/' + native + '.zip'
            elif platform == 'darksoft':
                mapping = {n: n[len('darksoft/'):] for n in qualified if n.startswith('darksoft/games/usf2_' + region + '/')}
                receipt = 'darksoft/receipts/usf2_' + region + '.json'
                mapping[receipt] = receipt[len('darksoft/'):]
                mapping['darksoft/verification/dl-1425.bin'] = 'support/' + slug + '/verification/dl-1425.bin'
            else:
                mras = record['mras']
                contracts.require(len(mras) == 1 and mras[0]['arrange'], 'Unsupported USF2 MRA matrix')
                names = ['mister/games/mame/' + native + '.zip', 'mister/games/CPS+/usf2_arrange.zip', 'mister/' + mras[0]['destination']]
                names += [n for n in qualified if n.startswith('mister/_Arcade/cores/')]
                for name in names:
                    new = name[len('mister/'):]
                    if name.startswith('mister/_Arcade/cores/') and (not name.endswith('.rbf')):
                        new = '_Arcade/cores/licenses/' + kit['core']['filename'] + '/' + slug + '/' + Path(name).name
                    mapping[name] = new
            contracts.require(mapping and all((n in qualified for n in mapping)), 'USF2 platform has unqualified outputs')
            covered.update(mapping)
            outputs = {new: qualified[old] for old, new in mapping.items()}
            extra = {'README.txt': 'support/' + slug + '/README-original.txt'}
            if platform == 'hbmame':
                extra['definitions/' + native + '.cpp.inc'] = 'support/' + slug + '/definitions/' + native + '.cpp.inc'
            outputs.update({new: common[old] for old, new in extra.items()})
            device = 'roms/qsound.zip' if platform in ('mame', 'hbmame') else None
            if device:
                outputs[device] = {'members': {'dl-1425.bin': roms['dl-1425.bin']['sha256']}}
            target = profile + '-' + platform
            release['targets'][target] = {'platform': platform, 'variant': profile, 'region': region, 'profile': slug + '-' + region if platform == 'mame' else 'default', 'inputs': sorted({*sources.values(), keyfile, nsps[region]}), 'minimum_free_bytes': 16 * 1024 ** 3 if platform == 'mister' else 8 * 1024 ** 3, 'outputs': outputs, 'software_notes': ['An owned regional base game and valid private Switch keys are required for every build.', 'The pinned Switch extraction helpers are prepared automatically. Private key values are never included in reports.', 'HBMAME requires definitions matching this release; stock MAME uses the HSF2 layout in this edition profile.']}
            recipe['targets'][target] = {'profile': profile, 'region': region, 'platform': platform, 'sources': sources, 'nsp': nsps[region], 'mapping': mapping, 'kit_mapping': extra, 'outputs': outputs, 'device_output': device, 'device_key': romkeys['dl-1425.bin']}
    contracts.require(covered == set(qualified), 'Unaccounted USF2 public outputs: ' + str(sorted(set(qualified) - covered)))
    for requirement in release['prerequisites'].values():
        if '7z member' not in requirement['formats']:requirement['formats'].append('7z member')
    release['api'] = 1
    release['project'] = slug
    release['native_outputs'] = qualified
    release['requires'] = sorted(set(release['requires']) | {'native-context-v1', 'native-bindings-v1'})
    return (release, recipe)
