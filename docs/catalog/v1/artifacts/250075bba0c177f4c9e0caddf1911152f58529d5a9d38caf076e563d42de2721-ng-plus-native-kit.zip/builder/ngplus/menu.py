"""Shared dependency-free NG+ launcher naming and serialization."""
from __future__ import annotations
from pathlib import Path

LAUNCHER_FOLDER = "_Arcade/_Arcade Patches/_Arrangements/_NG+"

def mgl_text(t: Title, rbf_base: str, launcher: str = LAUNCHER_FOLDER) -> str:
    return (
        "<mistergamedescription>\n"
        f"\t<rbf>{launcher}/cores/{rbf_base}</rbf>\n"
        f"\t<setname same_dir=\"1\">{t.set}</setname>\n"
        f"\t<file delay=\"1\" type=\"f\" index=\"1\" path=\"{t.set}.nga\"/>\n"
        "</mistergamedescription>\n"
    )

def launcher_name(title: str) -> str:
    """The launcher's file name: the title, minus what a card cannot hold.

    FAT32 and Windows forbid the same handful of characters, so a title with,
    say, a colon in it would build here and fail there; dropping them on every
    platform keeps one name for one title wherever the kit is run.
    """
    name = " ".join("".join(" " if c in '\\/:*?"<>|' else c for c in title).split())
    return name.rstrip(" .") or "untitled"

def rbf_base(rbf: Path) -> str:
    """The launcher names the core without its date: NeoGeoPlus_20260915.rbf -> NeoGeoPlus."""
    stem = rbf.stem
    head, _, date = stem.rpartition("_")
    return head if head and date.isdigit() and len(date) == 8 else stem
