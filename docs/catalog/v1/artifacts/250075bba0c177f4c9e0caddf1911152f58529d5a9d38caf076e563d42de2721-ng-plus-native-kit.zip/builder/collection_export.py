"""NG+ kit-owned discovery and bound invocation of the standalone image builder."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys
import tempfile
from types import SimpleNamespace

from kit_collection import require, safe_name
from ngplus.menu import mgl_text, launcher_name, rbf_base, LAUNCHER_FOLDER


def digest(path):
    value = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 ** 2), b''):value.update(block)
    return value.hexdigest()


def encoded(value):return (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()


def definitions(root, version, revision):
    root = Path(root);builder = root / 'builder'
    inputs = json.loads((builder / 'collection_inputs.json').read_text())
    images = json.loads((builder / 'image_hashes.json').read_text());packs = json.loads((builder / 'pack_hashes.json').read_text())
    require(set(images) == set(packs), 'Every selected NG+ title needs its accepted native image identity')
    require(set(inputs) == {'bios', *[kind + '.' + name for name in packs for kind in ('rom', 'disc')]}, 'Native NG+ title/input extent differs')
    cores = sorted((builder / 'cores').glob('NeoGeoPlus_*.rbf'));require(len(cores) == 1, 'Select exactly one NG+ core')
    core = cores[0];core_output = LAUNCHER_FOLDER + '/cores/' + core.name
    support = {n: 'support/ng-plus/' + Path(n).name for n in ('README.txt', 'INSTALL.md', 'builder/LICENSE-MAME.txt',
        'builder/cores/BUILD_PROVENANCE.txt', 'builder/cores/SOURCE_AND_LICENSE.txt')}
    prerequisites = {};keys = {}
    for name, pin in inputs.items():
        key = 'archive-' + pin['sha256'][:20];keys[name] = key
        prerequisites[key] = {'title': 'Neo Geo BIOS archive' if name == 'bios' else name.replace('.', ': ', 1),
            'kind': 'firmware' if name == 'bios' else 'disc' if name.startswith('disc.') else 'rom',
            'formats': ['ZIP archive', 'ZIP/7z member containing the archive'],
            'action': 'Add your canonical MAME/Neo Geo CD ZIP archives to a scanned folder. Filenames may differ.',
            'alternatives': [{k: pin[k] for k in ('size', 'sha256')}]}
    targets = {};native = {core_output: {'sha256': digest(core)}}
    for name in sorted(packs):
        title = json.loads((builder / 'titles' / name / 'title.json').read_text())
        require(title['set'] == name, 'NG+ title identity differs')
        menu = SimpleNamespace(set=name, name=title['title'])
        mgl = LAUNCHER_FOLDER + '/' + launcher_name(menu.name) + '.mgl'
        files = {'games/NG+/' + name + '.nga': {'sha256': images[name]}, mgl: {'sha256': hashlib.sha256(mgl_text(menu, rbf_base(core)).encode()).hexdigest()},
                 core_output: {'sha256': digest(core)}}
        native.update(files)
        outputs = {**files, **{new: {'sha256': digest(root / old)} for old, new in support.items()}}
        targets[name + '-mister'] = {'platform': 'mister', 'variant': name, 'region': 'us',
            'inputs': sorted({keys['bios'], keys['rom.' + name], keys['disc.' + name]}), 'outputs': outputs,
            'minimum_free_bytes': 4 * 1024 ** 3, 'destination_requirements': 'Includes the unchanged NG+ core and its source/license notices.'}
    definition = {'api': 1, 'project': 'ng-plus', 'game_version': version, 'kit_revision': revision,
        'requires': ['native-context-v1', 'native-bindings-v1'], 'prerequisites': prerequisites, 'targets': targets,
        'native_outputs': native}
    definition.update(json.loads((builder / 'collection_dependencies.json').read_text()))
    if definition.get('environments'):definition['requires'] += ['locked-wheels-v1', 'native-dependencies-v1']
    return definition, keys, support, core_output


def seal(root, version, revision):
    root = Path(root);value, _, _, _ = definitions(root, version, revision)
    manifest = {'api': 1, 'project': 'ng-plus', 'version': version, 'kit_revision': revision,
        'files': {p.relative_to(root).as_posix(): digest(p) for p in sorted(root.rglob('*')) if p.is_file()
                  and p.relative_to(root).as_posix() not in ('manifest.json', 'collection.json') and '__pycache__' not in p.parts}}
    (root / 'manifest.json').write_bytes(encoded(manifest));value['manifest_sha256'] = digest(root / 'manifest.json')
    (root / 'collection.json').write_bytes(encoded(value));return value


def describe(root):
    root = Path(root);manifest = json.loads((root / 'manifest.json').read_text())
    value = json.loads((root / 'collection.json').read_text())
    require(value['manifest_sha256'] == digest(root / 'manifest.json'), 'NG+ native manifest differs')
    for name, expected in manifest['files'].items():safe_name(name);require(digest(root / name) == expected, 'NG+ producer changed: ' + name)
    expected, _, _, _ = definitions(root, manifest['version'], manifest['kit_revision'])
    require({k: v for k, v in value.items() if k != 'manifest_sha256'} == expected, 'NG+ definition differs from producer')
    return value


def run(root, args):
    from kit_collection import bound_file
    root = Path(root);definition = describe(root);target_id = args.variant + '-mister'
    require(args.platform == 'mister' and target_id in definition['targets'], 'Unknown NG+ collection title')
    value = json.loads(args.inputs_json.read_text());bindings = value['bindings'];context = value['context']
    target = definition['targets'][target_id]
    require(value['schema'] == 1 and set(bindings) == set(target['inputs']), 'Incomplete or unexpected NG+ bindings')
    require(Path(context['run_cache']).is_absolute() and Path(context['tools_cache']).is_absolute(), 'Native cache paths must be absolute')
    _, keys, support, core_output = definitions(root, definition['game_version'], definition['kit_revision'])
    with tempfile.TemporaryDirectory(prefix='ng-inputs-', dir=context['run_cache']) as temporary:
        temporary = Path(temporary);paths = {}
        for key, row in bindings.items():
            require(any(row['size'] == pin['size'] and row['sha256'] == pin['sha256']
                        for pin in definition['prerequisites'][key]['alternatives']), 'Undeclared NG+ input identity')
            paths[key] = bound_file(row, temporary / (key + '.zip'))
        os.environ['ARCADE_PYTHON_CACHE'] = str(Path(context['tools_cache']) / 'python')
        import make_ngplus
        argv = ['--only', args.variant, '--tools-cache', context['tools_cache']]
        if context['offline']:argv.append('--offline')
        if args.check:argv.append('--check-inputs')
        else:argv += ['--out', str(args.out_dir)]
        selected = {'rom': paths[keys['rom.' + args.variant]], 'disc': paths[keys['disc.' + args.variant]]}
        require(make_ngplus.main(argv, bound_inputs=(paths[keys['bios']], {args.variant: selected})) == 0, 'Native NG+ input/build verification failed')
        if not args.check:
            raw = {'games/NG+/' + args.variant + '.nga', core_output,
                   next(n for n in target['outputs'] if n.endswith('.mgl'))}
            require({p.relative_to(args.out_dir).as_posix() for p in args.out_dir.rglob('*') if p.is_file()} == raw, 'NG+ native output extent differs')
            for old, new in support.items():
                output = args.out_dir / new;output.parent.mkdir(parents=True, exist_ok=True);shutil.copyfile(root / old, output)
            for name, spec in target['outputs'].items():require(digest(args.out_dir / name) == spec['sha256'], 'NG+ export differs from accepted image/layout')
    return {'api': 1, 'target': target_id, 'operation': 'check' if args.check else 'build', 'status': 'ok',
            **({'outputs': target['outputs']} if not args.check else {})}


def main(root):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--describe-json', action='store_true');parser.add_argument('--collection-layout', action='store_true')
    parser.add_argument('--inputs-json', type=Path);parser.add_argument('--report-json', type=Path)
    parser.add_argument('--platform');parser.add_argument('--variant');parser.add_argument('--out-dir', type=Path);parser.add_argument('--check', action='store_true')
    args = parser.parse_args()
    if args.describe_json:print(json.dumps(describe(root), sort_keys=True));return 0
    require(args.collection_layout and args.inputs_json and args.report_json and args.out_dir, 'Use exact bound NG+ inputs')
    try:result = run(root, args)
    except (ValueError, OSError, KeyError, SystemExit) as exc:
        args.report_json.write_bytes(encoded({'api': 1, 'target': str(args.variant) + '-mister', 'operation': 'check' if args.check else 'build',
            'status': 'error', 'message': str(exc)}));return 2
    args.report_json.write_bytes(encoded(result));return 0
